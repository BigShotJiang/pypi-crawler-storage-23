/**
 * 뉴스 검색 UI 모듈 (news-search.js)
 *
 * stockclaw-kit-ui.html에서 <script src="/ui/news-search.js">로 로드
 * 컨테이너: <div id="news-search-content"></div>
 * 진입점: window.initNewsSearch()
 */

// ============================================================
// CSS 주입 (중복 방지)
// ============================================================

function injectNewsSearchCSS() {
    if (document.getElementById('news-search-css')) return;
    const style = document.createElement('style');
    style.id = 'news-search-css';
    style.textContent = `
.ns-container { padding: 8px; }
.ns-toolbar { display: flex; gap: 8px; align-items: center; flex-wrap: wrap; margin-bottom: 12px; padding: 12px; background: var(--bg-card); border: 1px solid var(--border); border-radius: 8px; }
.ns-input { background: var(--bg-dark); border: 1px solid var(--border); color: var(--text, var(--text-primary, #c9d1d9)); padding: 8px 12px; border-radius: 6px; font-size: 13px; }
.ns-input:focus { border-color: var(--accent); outline: none; }
.ns-input-num { width: 70px; }
.ns-btn { padding: 8px 16px; border-radius: 6px; border: none; cursor: pointer; font-size: 13px; font-weight: 500; transition: all 0.2s; }
.ns-btn-primary { background: var(--accent); color: #fff; }
.ns-btn-success { background: var(--success); color: #fff; }
.ns-btn-danger { background: var(--danger); color: #fff; }
.ns-btn-secondary { background: var(--bg-hover, var(--surface2, #232733)); color: var(--text, var(--text-primary, #c9d1d9)); border: 1px solid var(--border); }
.ns-btn:hover { opacity: 0.85; }
.ns-btn:disabled { opacity: 0.5; cursor: not-allowed; }

.ns-keyword-tags { display: flex; gap: 6px; flex-wrap: wrap; margin-bottom: 12px; min-height: 32px; }
.ns-keyword-tags-empty { color: var(--text-muted); font-size: 12px; line-height: 32px; }
.ns-keyword-tag { display: inline-flex; align-items: center; gap: 6px; padding: 4px 10px; background: rgba(88,166,255,0.15); border: 1px solid rgba(88,166,255,0.3); border-radius: 16px; color: var(--accent); font-size: 12px; cursor: pointer; transition: all 0.2s; user-select: none; }
.ns-keyword-tag:hover { background: rgba(88,166,255,0.25); }
.ns-keyword-tag .ns-tag-remove { color: var(--text-muted); cursor: pointer; font-size: 10px; line-height: 1; margin-left: 2px; }
.ns-keyword-tag .ns-tag-remove:hover { color: var(--danger); }

.ns-tabs { display: flex; gap: 2px; background: var(--bg-dark); border-radius: 8px; padding: 3px; margin-bottom: 12px; width: fit-content; }
.ns-tab { padding: 8px 20px; border-radius: 6px; border: none; background: transparent; color: var(--text-muted); cursor: pointer; font-size: 13px; transition: all 0.2s; }
.ns-tab.active { background: var(--accent); color: #fff; }

.ns-status-bar { display: flex; gap: 16px; align-items: center; margin-bottom: 12px; font-size: 12px; color: var(--text-muted); flex-wrap: wrap; }
.ns-status-item { display: flex; align-items: center; gap: 4px; }
.ns-status-dot { width: 8px; height: 8px; border-radius: 50%; display: inline-block; }
.ns-status-dot.active { background: var(--success); animation: ns-pulse 1.5s infinite; }
.ns-status-dot.inactive { background: var(--text-muted); }
@keyframes ns-pulse { 0%, 100% { opacity: 1; } 50% { opacity: 0.4; } }

.ns-table-wrap { overflow-x: auto; max-height: calc(100vh - 320px); overflow-y: auto; }
.ns-table { width: 100%; border-collapse: collapse; font-size: 13px; table-layout: fixed; }
.ns-table thead th { background: var(--bg-dark); color: var(--text-muted); padding: 10px 8px; text-align: left; font-weight: 600; border-bottom: 2px solid var(--border); position: sticky; top: 0; z-index: 1; white-space: nowrap; }
.ns-table thead th.ns-th-check { width: 36px; }
.ns-table tbody tr { border-bottom: 1px solid var(--border); transition: background 0.15s; }
.ns-table tbody tr:hover { background: var(--bg-hover, var(--surface2, #232733)); }
.ns-table tbody td { padding: 8px; color: var(--text, var(--text-primary, #c9d1d9)); vertical-align: top; }
.ns-title-link { color: var(--accent); text-decoration: none; display: block; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.ns-title-link:hover { text-decoration: underline; }
.ns-press { color: var(--text-muted); font-size: 11px; }
.ns-time { color: var(--text-muted); font-size: 11px; white-space: nowrap; }
.ns-keyword-badge { display: inline-block; padding: 2px 8px; background: rgba(88,166,255,0.15); color: var(--accent); border-radius: 10px; font-size: 11px; }
.ns-new-article { border-left: 3px solid var(--warning) !important; background: rgba(210,153,34,0.08) !important; }
.ns-desc { color: var(--text-muted); font-size: 12px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; display: block; }

.ns-no-api-key { padding: 48px 24px; text-align: center; color: var(--text-muted); }
.ns-no-api-key-icon { font-size: 40px; margin-bottom: 12px; }
.ns-no-api-key p { font-size: 14px; }

.ns-empty { padding: 40px; text-align: center; color: var(--text-muted); font-size: 13px; }

.ns-filter-btns { display: flex; gap: 6px; flex-wrap: wrap; margin-bottom: 10px; }
.ns-filter-btn { padding: 4px 12px; border-radius: 14px; border: 1px solid var(--border); background: transparent; color: var(--text-muted); cursor: pointer; font-size: 12px; transition: all 0.2s; }
.ns-filter-btn.active { background: var(--accent); color: #fff; border-color: var(--accent); }
.ns-filter-btn:hover:not(.active) { border-color: var(--accent); color: var(--accent); }

.ns-pagination { display: flex; gap: 8px; align-items: center; justify-content: center; margin-top: 12px; padding: 8px; }
.ns-pagination .ns-btn { padding: 6px 12px; font-size: 12px; }
.ns-page-info { color: var(--text-muted); font-size: 12px; }

.ns-hist-toolbar { display: flex; gap: 8px; align-items: center; flex-wrap: wrap; margin-bottom: 10px; }
.ns-hist-toolbar select { background: var(--bg-dark); border: 1px solid var(--border); color: var(--text, #c9d1d9); padding: 6px 10px; border-radius: 6px; font-size: 12px; }
.ns-hist-toolbar select:focus { border-color: var(--accent); outline: none; }

.ns-checkbox { width: 14px; height: 14px; cursor: pointer; accent-color: var(--accent); }

.ns-tab-panel { display: none; }
.ns-tab-panel.active { display: block; }

.ns-api-warning { padding: 8px 12px; background: rgba(248,81,73,0.1); border: 1px solid rgba(248,81,73,0.3); border-radius: 6px; font-size: 12px; color: var(--danger); margin-bottom: 12px; }
    `;
    document.head.appendChild(style);
}

// ============================================================
// 상태
// ============================================================

const NS = {
    pollingInterval: null,
    pollingActive: false,
    lastPollTime: null,
    // 실시간 결과: Map<link, {keyword, item, collectedAt}>
    realtimeResults: new Map(),
    realtimeFilter: 'all',  // 현재 선택된 필터 키워드
    // 히스토리
    histPage: 0,
    histLimit: 50,
    histKeyword: '',
    histTotal: 0,
    histData: [],
    // API 키 상태
    hasApiKey: null,
    // DB 키워드 목록 (히스토리 필터용)
    dbKeywords: [],
    // 히스토리 선택된 ID 목록
    selectedIds: new Set(),
};

// ============================================================
// 유틸리티
// ============================================================

function parsePressName(link) {
    try {
        const url = new URL(link);
        const host = url.hostname.replace(/^www\./, '');
        const pressMap = {
            'news.naver.com': '네이버',
            'n.news.naver.com': '네이버',
            'chosun.com': '조선일보',
            'joongang.co.kr': '중앙일보',
            'donga.com': '동아일보',
            'hani.co.kr': '한겨레',
            'khan.co.kr': '경향신문',
            'mk.co.kr': '매경',
            'hankyung.com': '한경',
            'sedaily.com': '서울경제',
            'edaily.co.kr': '이데일리',
            'mt.co.kr': '머투',
            'newsis.com': '뉴시스',
            'yna.co.kr': '연합',
            'yonhapnews.co.kr': '연합',
        };
        return pressMap[host] || host;
    } catch { return ''; }
}

function formatRelativeTime(dateStr) {
    try {
        const date = new Date(dateStr);
        if (isNaN(date.getTime())) return dateStr || '';
        const diff = (Date.now() - date.getTime()) / 1000;
        if (diff < 60) return `${Math.floor(diff)}초 전`;
        if (diff < 3600) return `${Math.floor(diff / 60)}분 전`;
        if (diff < 86400) return `${Math.floor(diff / 3600)}시간 전`;
        return `${Math.floor(diff / 86400)}일 전`;
    } catch { return dateStr || ''; }
}

function formatAbsTime(dateStr) {
    try {
        const date = new Date(dateStr);
        if (isNaN(date.getTime())) return dateStr || '';
        const pad = n => String(n).padStart(2, '0');
        return `${date.getFullYear()}-${pad(date.getMonth()+1)}-${pad(date.getDate())} ${pad(date.getHours())}:${pad(date.getMinutes())}:${pad(date.getSeconds())}`;
    } catch { return dateStr || ''; }
}

function cleanHtml(text) {
    if (!text) return '';
    return text
        .replace(/<[^>]+>/g, '')
        .replace(/&quot;/g, '"')
        .replace(/&amp;/g, '&')
        .replace(/&lt;/g, '<')
        .replace(/&gt;/g, '>')
        .replace(/&nbsp;/g, ' ')
        .replace(/&apos;/g, "'");
}

function escapeHtml(text) {
    if (!text) return '';
    return String(text)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#039;');
}

function numberWithCommas(n) {
    return String(n).replace(/\B(?=(\d{3})+(?!\d))/g, ',');
}

// ============================================================
// localStorage 키워드 관리
// ============================================================

const LS_KEY = 'news_search_keywords';

function getKeywords() {
    try {
        return JSON.parse(localStorage.getItem(LS_KEY) || '[]');
    } catch { return []; }
}

function saveKeywords(arr) {
    localStorage.setItem(LS_KEY, JSON.stringify(arr));
}

function addKeyword(keyword, display) {
    keyword = keyword.trim();
    if (!keyword) return false;
    const list = getKeywords();
    if (list.find(k => k.keyword === keyword)) return false; // 중복
    list.push({ keyword, display: display || 100 });
    saveKeywords(list);
    return true;
}

function removeKeyword(keyword) {
    const list = getKeywords().filter(k => k.keyword !== keyword);
    saveKeywords(list);
}

// ============================================================
// API 키 확인
// ============================================================

async function checkApiKey() {
    try {
        const resp = await fetch('/api/keys');
        if (!resp.ok) { NS.hasApiKey = false; return; }
        const data = await resp.json();
        // NAVER_CLIENT_ID 유무 확인
        NS.hasApiKey = !!(data.NAVER_CLIENT_ID || (data.keys && data.keys.NAVER_CLIENT_ID));
    } catch {
        NS.hasApiKey = false;
    }
}

// ============================================================
// 실시간 결과 병합 (중복: link 기준)
// ============================================================

function mergeResults(keyword, items) {
    const now = Date.now();
    for (const item of items) {
        const key = item.link || item.originallink || item.title;
        if (!NS.realtimeResults.has(key)) {
            NS.realtimeResults.set(key, { keyword, item, collectedAt: now });
        }
    }
}

// ============================================================
// 실시간 탭 렌더링
// ============================================================

function renderRealtimeTable() {
    const tbody = document.getElementById('ns-realtime-body');
    if (!tbody) return;

    const now = Date.now();
    const HIGHLIGHT_MS = 10000; // 10초 이내

    // 필터 적용
    let entries = Array.from(NS.realtimeResults.values());
    if (NS.realtimeFilter !== 'all') {
        entries = entries.filter(e => e.keyword === NS.realtimeFilter);
    }

    // 최신순 정렬 (collectedAt)
    entries.sort((a, b) => b.collectedAt - a.collectedAt);

    if (entries.length === 0) {
        tbody.innerHTML = `<tr><td colspan="6" class="ns-empty">수집된 뉴스가 없습니다.</td></tr>`;
        return;
    }

    const rows = entries.map((entry, idx) => {
        const { keyword, item, collectedAt } = entry;
        const isNew = (now - collectedAt) < HIGHLIGHT_MS;
        const title = cleanHtml(item.title || '');
        const desc = cleanHtml(item.description || '');
        const link = item.originallink || item.link || '#';
        const press = parsePressName(item.originallink || item.link || '');
        const timeStr = item.pubDate ? formatAbsTime(item.pubDate) : '';
        const rowClass = isNew ? ' class="ns-new-article"' : '';
        return `<tr${rowClass}>
            <td>${idx + 1}</td>
            <td><span class="ns-keyword-badge">${escapeHtml(keyword)}</span></td>
            <td><a class="ns-title-link" href="${escapeHtml(link)}" target="_blank" rel="noopener noreferrer">${escapeHtml(title)}</a></td>
            <td><span class="ns-desc">${escapeHtml(desc)}</span></td>
            <td><span class="ns-press">${escapeHtml(press)}</span></td>
            <td><span class="ns-time">${escapeHtml(timeStr)}</span></td>
        </tr>`;
    });

    tbody.innerHTML = rows.join('');
}

// ============================================================
// 실시간 탭 필터 버튼 렌더링
// ============================================================

function renderRealtimeFilters() {
    const wrap = document.getElementById('ns-realtime-filters');
    if (!wrap) return;

    const keywords = getKeywords().map(k => k.keyword);
    const btns = ['all', ...keywords].map(kw => {
        const label = kw === 'all' ? '전체' : kw;
        const active = NS.realtimeFilter === kw ? ' active' : '';
        return `<button class="ns-filter-btn${active}" data-kw="${escapeHtml(kw)}">${escapeHtml(label)}</button>`;
    });
    wrap.innerHTML = btns.join('');

    wrap.querySelectorAll('.ns-filter-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            NS.realtimeFilter = btn.dataset.kw;
            renderRealtimeFilters();
            renderRealtimeTable();
        });
    });
}

// ============================================================
// 히스토리 탭
// ============================================================

async function loadDbKeywords() {
    try {
        const resp = await fetch('/api/news/db/keywords');
        const data = await resp.json();
        if (data.ok && Array.isArray(data.keywords)) {
            NS.dbKeywords = data.keywords;
        }
    } catch { /* 무시 */ }
}

async function loadHistory() {
    const offset = NS.histPage * NS.histLimit;
    const params = new URLSearchParams({
        limit: NS.histLimit,
        offset,
    });
    if (NS.histKeyword) params.set('keyword', NS.histKeyword);

    try {
        const resp = await fetch(`/api/news/db/history?${params.toString()}`);
        const data = await resp.json();
        if (data.ok) {
            NS.histData = data.data || [];
            NS.histTotal = data.total || 0;
        }
    } catch {
        NS.histData = [];
        NS.histTotal = 0;
    }
    renderHistoryTable();
    renderHistoryPagination();
}

function renderHistoryTable() {
    const tbody = document.getElementById('ns-history-body');
    if (!tbody) return;

    NS.selectedIds.clear();
    updateHistDeleteBtn();

    if (NS.histData.length === 0) {
        tbody.innerHTML = `<tr><td colspan="7" class="ns-empty">저장된 뉴스가 없습니다.</td></tr>`;
        return;
    }

    const rows = NS.histData.map(row => {
        const title = cleanHtml(row.title || '');
        const desc = cleanHtml(row.description || '');
        const link = row.originallink || row.link || '#';
        const press = parsePressName(row.originallink || row.link || '');
        const timeStr = row.pub_date ? formatAbsTime(row.pub_date) : '';
        const id = row.id;
        return `<tr>
            <td><input type="checkbox" class="ns-checkbox ns-hist-check" data-id="${id}"></td>
            <td>${id}</td>
            <td><span class="ns-keyword-badge">${escapeHtml(row.keyword || '')}</span></td>
            <td><a class="ns-title-link" href="${escapeHtml(link)}" target="_blank" rel="noopener noreferrer">${escapeHtml(title)}</a></td>
            <td><span class="ns-desc">${escapeHtml(desc)}</span></td>
            <td><span class="ns-press">${escapeHtml(press)}</span></td>
            <td><span class="ns-time">${escapeHtml(timeStr)}</span></td>
        </tr>`;
    });

    tbody.innerHTML = rows.join('');

    // 체크박스 이벤트
    tbody.querySelectorAll('.ns-hist-check').forEach(cb => {
        cb.addEventListener('change', () => {
            const id = Number(cb.dataset.id);
            if (cb.checked) NS.selectedIds.add(id);
            else NS.selectedIds.delete(id);
            updateHistDeleteBtn();
        });
    });
}

function renderHistoryPagination() {
    const wrap = document.getElementById('ns-hist-pagination');
    if (!wrap) return;

    const totalPages = Math.max(1, Math.ceil(NS.histTotal / NS.histLimit));
    const currentPage = NS.histPage + 1;

    wrap.innerHTML = `
        <button class="ns-btn ns-btn-secondary" id="ns-hist-prev" ${NS.histPage === 0 ? 'disabled' : ''}>◀ 이전</button>
        <span class="ns-page-info">${currentPage} / ${totalPages} 페이지 (${numberWithCommas(NS.histTotal)}건)</span>
        <button class="ns-btn ns-btn-secondary" id="ns-hist-next" ${currentPage >= totalPages ? 'disabled' : ''}>다음 ▶</button>
    `;

    const prevBtn = document.getElementById('ns-hist-prev');
    const nextBtn = document.getElementById('ns-hist-next');
    if (prevBtn) prevBtn.addEventListener('click', () => { NS.histPage--; loadHistory(); });
    if (nextBtn) nextBtn.addEventListener('click', () => { NS.histPage++; loadHistory(); });
}

function renderHistKeywordSelect() {
    const sel = document.getElementById('ns-hist-keyword-filter');
    if (!sel) return;
    const opts = ['<option value="">전체 키워드</option>',
        ...NS.dbKeywords.map(kw => `<option value="${escapeHtml(kw)}" ${NS.histKeyword === kw ? 'selected' : ''}>${escapeHtml(kw)}</option>`)
    ];
    sel.innerHTML = opts.join('');
}

function updateHistDeleteBtn() {
    const btn = document.getElementById('ns-hist-delete-selected');
    if (!btn) return;
    btn.disabled = NS.selectedIds.size === 0;
    btn.textContent = NS.selectedIds.size > 0 ? `선택 삭제 (${NS.selectedIds.size})` : '선택 삭제';
}

// ============================================================
// 폴링 로직
// ============================================================

function updatePollingUI(active) {
    const startBtn = document.getElementById('ns-poll-start');
    const stopBtn = document.getElementById('ns-poll-stop');
    const dot = document.getElementById('ns-poll-dot');
    const statusText = document.getElementById('ns-poll-status');

    if (startBtn) startBtn.disabled = active;
    if (stopBtn) stopBtn.disabled = !active;
    if (dot) {
        dot.className = 'ns-status-dot ' + (active ? 'active' : 'inactive');
    }
    if (statusText) {
        statusText.textContent = active ? '폴링 중 (10초)' : '대기 중';
    }
}

function updateLastPollTime() {
    NS.lastPollTime = new Date();
    const el = document.getElementById('ns-last-poll');
    if (el) {
        const t = NS.lastPollTime;
        const pad = n => String(n).padStart(2, '0');
        el.textContent = `마지막 검색: ${pad(t.getHours())}:${pad(t.getMinutes())}:${pad(t.getSeconds())}`;
    }
    updateCountBadge();
}

function updateCountBadge() {
    const el = document.getElementById('ns-count-badge');
    if (!el) return;
    el.textContent = `실시간 ${numberWithCommas(NS.realtimeResults.size)}건`;
}

async function pollOnce() {
    const keywords = getKeywords();
    if (keywords.length === 0) {
        if (NS.pollingActive) stopPolling();
        return;
    }

    for (const kw of keywords) {
        try {
            const resp = await fetch('/api/news/search', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ query: kw.keyword, display: kw.display || 100 }),
            });
            if (!resp.ok) continue;
            const data = await resp.json();
            if (data.items && Array.isArray(data.items)) {
                mergeResults(kw.keyword, data.items);
                // DB 자동 저장 (fire-and-forget)
                fetch('/api/news/db/save', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ keyword: kw.keyword, articles: data.items }),
                }).catch(() => {});
            }
        } catch (err) {
            console.error(`[뉴스검색] 실패 (${kw.keyword}):`, err);
        }
    }

    // 활성 탭이 실시간이면 테이블 갱신
    const realtimePanel = document.getElementById('ns-panel-realtime');
    if (realtimePanel && realtimePanel.classList.contains('active')) {
        renderRealtimeTable();
    }
    updateLastPollTime();
    renderRealtimeFilters();
}

function startPolling() {
    if (NS.pollingActive) return;
    NS.pollingActive = true;
    updatePollingUI(true);
    pollOnce();
    NS.pollingInterval = setInterval(pollOnce, 10000);
}

function stopPolling() {
    NS.pollingActive = false;
    clearInterval(NS.pollingInterval);
    NS.pollingInterval = null;
    updatePollingUI(false);
}

// ============================================================
// 키워드 태그 렌더링
// ============================================================

function renderKeywordTags() {
    const wrap = document.getElementById('ns-keyword-tags');
    if (!wrap) return;

    const keywords = getKeywords();
    if (keywords.length === 0) {
        wrap.innerHTML = '<span class="ns-keyword-tags-empty">등록된 키워드가 없습니다.</span>';
        return;
    }

    const tags = keywords.map(kw => `
        <span class="ns-keyword-tag" data-kw="${escapeHtml(kw.keyword)}">
            ${escapeHtml(kw.keyword)}
            <span class="ns-tag-remove" data-kw="${escapeHtml(kw.keyword)}" title="삭제">✕</span>
        </span>
    `);
    wrap.innerHTML = tags.join('');

    // 태그 클릭 → 즉시 해당 키워드 단건 검색
    wrap.querySelectorAll('.ns-keyword-tag').forEach(tag => {
        tag.addEventListener('click', async (e) => {
            if (e.target.classList.contains('ns-tag-remove')) return;
            const kw = tag.dataset.kw;
            const kwObj = getKeywords().find(k => k.keyword === kw);
            if (!kwObj) return;
            try {
                const resp = await fetch('/api/news/search', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ query: kw, display: kwObj.display || 100 }),
                });
                if (!resp.ok) return;
                const data = await resp.json();
                if (data.items) {
                    mergeResults(kw, data.items);
                    fetch('/api/news/db/save', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ keyword: kw, articles: data.items }),
                    }).catch(() => {});
                }
            } catch (err) {
                console.error('[뉴스검색] 단건 검색 실패:', err);
            }
            // 실시간 탭으로 전환 후 테이블 갱신
            switchTab('realtime');
            NS.realtimeFilter = kw;
            renderRealtimeFilters();
            renderRealtimeTable();
            updateLastPollTime();
        });
    });

    // X 버튼 이벤트
    wrap.querySelectorAll('.ns-tag-remove').forEach(btn => {
        btn.addEventListener('click', (e) => {
            e.stopPropagation();
            const kw = btn.dataset.kw;
            removeKeyword(kw);
            // 폴링 중이면 해당 키워드 필터 초기화
            if (NS.realtimeFilter === kw) NS.realtimeFilter = 'all';
            renderKeywordTags();
            renderRealtimeFilters();
        });
    });
}

// ============================================================
// 탭 전환
// ============================================================

function switchTab(tab) {
    ['realtime', 'history'].forEach(t => {
        const panel = document.getElementById(`ns-panel-${t}`);
        const btn = document.getElementById(`ns-tab-${t}`);
        if (!panel || !btn) return;
        if (t === tab) {
            panel.classList.add('active');
            btn.classList.add('active');
        } else {
            panel.classList.remove('active');
            btn.classList.remove('active');
        }
    });

    if (tab === 'history') {
        NS.histPage = 0;
        loadDbKeywords().then(() => {
            renderHistKeywordSelect();
            loadHistory();
        });
    }
}

// ============================================================
// HTML 구조 빌드
// ============================================================

function buildHTML() {
    return `
<div class="ns-container">

    <!-- API 키 경고 (동적) -->
    <div id="ns-api-warning" style="display:none" class="ns-api-warning">
        ⚠ 네이버 API 키(NAVER_CLIENT_ID)가 설정되지 않았습니다. /api/keys 에서 확인하세요.
    </div>

    <!-- 툴바 -->
    <div class="ns-toolbar">
        <input id="ns-kw-input" class="ns-input" type="text" placeholder="키워드 입력 (예: 삼성전자)" style="flex:1; min-width:150px;" />
        <input id="ns-display-input" class="ns-input ns-input-num" type="number" value="100" min="1" max="100" title="검색 개수" />
        <button id="ns-add-btn" class="ns-btn ns-btn-primary">추가</button>
        <button id="ns-search-once" class="ns-btn ns-btn-primary" style="padding:8px 12px;">1회 검색</button>
        <button id="ns-poll-start" class="ns-btn ns-btn-success">폴링 시작 ▶</button>
        <button id="ns-poll-stop" class="ns-btn ns-btn-secondary" disabled>폴링 중지 ■</button>
    </div>

    <!-- 키워드 태그 바 -->
    <div id="ns-keyword-tags" class="ns-keyword-tags"></div>

    <!-- 상태 바 -->
    <div class="ns-status-bar">
        <span class="ns-status-item">
            <span id="ns-poll-dot" class="ns-status-dot inactive"></span>
            <span id="ns-poll-status">대기 중</span>
        </span>
        <span id="ns-last-poll"></span>
        <span id="ns-count-badge">실시간 0건</span>
    </div>

    <!-- 탭 -->
    <div class="ns-tabs">
        <button id="ns-tab-realtime" class="ns-tab active" data-tab="realtime">실시간</button>
        <button id="ns-tab-history" class="ns-tab" data-tab="history">히스토리</button>
    </div>

    <!-- 실시간 패널 -->
    <div id="ns-panel-realtime" class="ns-tab-panel active">
        <div id="ns-realtime-filters" class="ns-filter-btns"></div>
        <div class="ns-table-wrap">
            <table class="ns-table">
                <thead>
                    <tr>
                        <th style="width:36px">#</th>
                        <th style="width:80px">키워드</th>
                        <th style="width:35%">제목</th>
                        <th style="width:auto">내용</th>
                        <th style="width:70px">언론사</th>
                        <th style="width:130px">기사시간</th>
                    </tr>
                </thead>
                <tbody id="ns-realtime-body">
                    <tr><td colspan="6" class="ns-empty">폴링을 시작하거나 키워드 태그를 클릭하세요.</td></tr>
                </tbody>
            </table>
        </div>
    </div>

    <!-- 히스토리 패널 -->
    <div id="ns-panel-history" class="ns-tab-panel">
        <div class="ns-hist-toolbar">
            <select id="ns-hist-keyword-filter">
                <option value="">전체 키워드</option>
            </select>
            <button id="ns-hist-reload" class="ns-btn ns-btn-secondary" style="padding:6px 12px; font-size:12px;">새로고침</button>
            <button id="ns-hist-delete-selected" class="ns-btn ns-btn-danger" style="padding:6px 12px; font-size:12px;" disabled>선택 삭제</button>
            <button id="ns-hist-delete-all" class="ns-btn ns-btn-danger" style="padding:6px 12px; font-size:12px; background: rgba(248,81,73,0.3);">전체 삭제</button>
            <span id="ns-hist-count" style="font-size:12px; color:var(--text-muted);"></span>
        </div>
        <div class="ns-table-wrap">
            <table class="ns-table">
                <thead>
                    <tr>
                        <th class="ns-th-check" style="width:36px"><input type="checkbox" id="ns-hist-check-all" class="ns-checkbox"></th>
                        <th style="width:36px">#</th>
                        <th style="width:80px">키워드</th>
                        <th style="width:30%">제목</th>
                        <th style="width:auto">내용</th>
                        <th style="width:70px">언론사</th>
                        <th style="width:130px">기사시간</th>
                    </tr>
                </thead>
                <tbody id="ns-history-body">
                    <tr><td colspan="7" class="ns-empty">히스토리 탭을 클릭하여 로드하세요.</td></tr>
                </tbody>
            </table>
        </div>
        <div id="ns-hist-pagination" class="ns-pagination"></div>
    </div>

</div>
    `;
}

// ============================================================
// 이벤트 바인딩
// ============================================================

function bindEvents() {
    // 키워드 추가 버튼
    const addBtn = document.getElementById('ns-add-btn');
    const kwInput = document.getElementById('ns-kw-input');
    const displayInput = document.getElementById('ns-display-input');

    function doAddKeyword() {
        const kw = kwInput ? kwInput.value.trim() : '';
        const display = displayInput ? (parseInt(displayInput.value) || 100) : 100;
        if (!kw) return;
        const added = addKeyword(kw, display);
        if (!added) {
            // 이미 있는 키워드
            if (kwInput) kwInput.select();
            return;
        }
        if (kwInput) kwInput.value = '';
        renderKeywordTags();
        renderRealtimeFilters();
    }

    if (addBtn) addBtn.addEventListener('click', doAddKeyword);
    if (kwInput) {
        kwInput.addEventListener('keydown', (e) => {
            if (e.key === 'Enter') doAddKeyword();
        });
    }

    // 1회 검색 버튼
    const searchOnceBtn = document.getElementById('ns-search-once');
    if (searchOnceBtn) {
        searchOnceBtn.addEventListener('click', async () => {
            searchOnceBtn.disabled = true;
            searchOnceBtn.textContent = '검색 중...';
            try {
                await pollOnce();
            } finally {
                searchOnceBtn.disabled = false;
                searchOnceBtn.textContent = '1회 검색';
            }
        });
    }

    // 폴링 버튼
    const pollStartBtn = document.getElementById('ns-poll-start');
    const pollStopBtn = document.getElementById('ns-poll-stop');
    if (pollStartBtn) pollStartBtn.addEventListener('click', startPolling);
    if (pollStopBtn) pollStopBtn.addEventListener('click', stopPolling);

    // 탭 버튼
    ['realtime', 'history'].forEach(tab => {
        const btn = document.getElementById(`ns-tab-${tab}`);
        if (btn) btn.addEventListener('click', () => switchTab(tab));
    });

    // 히스토리: 키워드 필터 변경
    const histKeywordSel = document.getElementById('ns-hist-keyword-filter');
    if (histKeywordSel) {
        histKeywordSel.addEventListener('change', () => {
            NS.histKeyword = histKeywordSel.value;
            NS.histPage = 0;
            loadHistory();
        });
    }

    // 히스토리: 새로고침
    const histReloadBtn = document.getElementById('ns-hist-reload');
    if (histReloadBtn) {
        histReloadBtn.addEventListener('click', () => {
            loadDbKeywords().then(() => {
                renderHistKeywordSelect();
                loadHistory();
            });
        });
    }

    // 히스토리: 전체 선택
    const histCheckAll = document.getElementById('ns-hist-check-all');
    if (histCheckAll) {
        histCheckAll.addEventListener('change', () => {
            const tbody = document.getElementById('ns-history-body');
            if (!tbody) return;
            const checks = tbody.querySelectorAll('.ns-hist-check');
            checks.forEach(cb => {
                cb.checked = histCheckAll.checked;
                const id = Number(cb.dataset.id);
                if (histCheckAll.checked) NS.selectedIds.add(id);
                else NS.selectedIds.delete(id);
            });
            updateHistDeleteBtn();
        });
    }

    // 히스토리: 선택 삭제
    const histDelBtn = document.getElementById('ns-hist-delete-selected');
    if (histDelBtn) {
        histDelBtn.addEventListener('click', async () => {
            if (NS.selectedIds.size === 0) return;
            if (!confirm(`선택한 ${NS.selectedIds.size}건을 삭제하시겠습니까?`)) return;
            try {
                const resp = await fetch('/api/news/db/delete', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ ids: Array.from(NS.selectedIds) }),
                });
                const data = await resp.json();
                if (data.ok) {
                    NS.selectedIds.clear();
                    const histCheckAllEl = document.getElementById('ns-hist-check-all');
                    if (histCheckAllEl) histCheckAllEl.checked = false;
                    loadHistory();
                }
            } catch (err) {
                console.error('[뉴스검색] 선택 삭제 실패:', err);
            }
        });
    }

    // 히스토리: 전체 삭제
    const histDelAllBtn = document.getElementById('ns-hist-delete-all');
    if (histDelAllBtn) {
        histDelAllBtn.addEventListener('click', async () => {
            if (!confirm('DB에 저장된 모든 뉴스를 삭제하시겠습니까?\n이 작업은 되돌릴 수 없습니다.')) return;
            try {
                const resp = await fetch('/api/news/db/delete-all', { method: 'POST' });
                const data = await resp.json();
                if (data.ok) {
                    NS.selectedIds.clear();
                    NS.histPage = 0;
                    loadHistory();
                }
            } catch (err) {
                console.error('[뉴스검색] 전체 삭제 실패:', err);
            }
        });
    }
}

// ============================================================
// 진입점
// ============================================================

async function initNewsSearch() {
    const container = document.getElementById('news-search-content');
    if (!container) {
        console.error('[뉴스검색] #news-search-content 컨테이너가 없습니다.');
        return;
    }
    // 중복 로드 방지
    if (container.dataset.loaded === '1') return;
    container.dataset.loaded = '1';

    // CSS 주입
    injectNewsSearchCSS();

    // HTML 렌더링
    container.innerHTML = buildHTML();

    // API 키 확인
    await checkApiKey();
    if (NS.hasApiKey === false) {
        const warn = document.getElementById('ns-api-warning');
        if (warn) warn.style.display = '';
    }

    // 초기 렌더링
    renderKeywordTags();
    renderRealtimeFilters();
    updateCountBadge();

    // 이벤트 바인딩
    bindEvents();

    console.log('[뉴스검색] 초기화 완료');
}

// ============================================================
// 전역 노출
// ============================================================

window.initNewsSearch = initNewsSearch;
