/**
 * AI Quant Chart Manager
 *
 * 키움증권 API 기반 주식 차트 매니저
 * TradingView Lightweight Charts 사용
 *
 */

class AIQuantChartManager {
    constructor(options = {}) {
        this.containerId = options.containerId || 'aiQuantChartContainer';
        this.container = document.getElementById(this.containerId);
        // Electron 환경에서는 IPC 사용, 브라우저에서는 서버 API 사용
        this.useIPC = !!window.electronAPI;
        this.proxyUrl = options.proxyUrl || 'https://readinginvestor.com/thematracker';
        // 차트 인스턴스
        this.chart = null;
        this.candlestickSeries = null;
        this.volumeSeries = null;
        this.maSeries = {};  // { ma5: LineSeries, ma20: LineSeries, ... }

        // 상태
        this.currentCode = null;
        this.currentName = null;
        this.currentPeriod = 'daily';
        this.chartData = null;

        // 이동평균선 색상
        this.maColors = {
            ma5: '#ef4444',    // 빨간색
            ma20: '#3b82f6',   // 파란색
            ma60: '#8b5cf6',   // 보라색
            ma120: '#ef4444',  // 빨간색
            ma240: '#3b82f6'   // 파란색
        };

        // 이동평균선 굵기
        this.maLineWidths = {
            ma5: 2,
            ma20: 2,
            ma60: 1,
            ma120: 4,
            ma240: 4
        };

        // 일목균형표/볼린저밴드 시리즈
        this.ichimokuSeries = {};
        this.bollingerUpperSeries = null;

        // 3분봉 전용 지표
        this.todayOpenSeries = null;  // 당일시가 라인
        this.dateBoundaryMarkers = []; // 일자 경계선

        // 3분봉 지표 표시 상태
        this.minuteIndicatorSettings = {
            todayOpen: true,
            dateBoundary: true
        };

        // 범례 오버레이
        this.legendOverlay = null;

        // 드래그 줌 상태
        this.dragZoom = {
            isDragging: false,
            startX: 0,
            startTime: null,
            overlay: null
        };

        // 보이는 범위 최고가/최저가 표시
        this.visibleHighLow = {
            canvas: null,
            data: null,
            updateHandler: null
        };

        // 스크롤바 상태
        this.scrollbar = {
            container: null,
            thumb: null,
            isDragging: false,
            startX: 0,
            startLeft: 0
        };

        // 드로잉 도구 상태
        this.drawing = {
            tool: null,           // 'hline', 'trendline', 'rect', 'quad', null
            isDrawing: false,
            startPoint: null,     // { time, price, x, y }
            objects: [],          // 그려진 객체들
            history: [],          // Ctrl+Z 히스토리
            canvas: null,         // 오버레이 캔버스
            ctx: null
        };

        // 드로잉 버튼 참조 (selectDrawingTool용)
        this.drawingButtons = {};

        // 우측 경계 제한 핸들러
        this._rightEdgeLimitHandler = null;

        // 과거 데이터 로드 상태
        this.isLoadingMore = false;

        // 일자 경계선 캔버스
        this.dateBoundaryCanvas = null;
        this.dateBoundaryCtx = null;
        this.dateBoundaryInfo = null;
        this._dateBoundaryHandler = null;

        // 드래그 줌 이벤트 바인딩 저장
        this._boundMouseDown = null;
        this._boundMouseMove = null;
        this._boundMouseUp = null;
        this._boundMouseLeave = null;
        this._boundWheel = null;

        // 초기화
        if (this.container) {
            this.init();
        }

        console.log('[AIQuantChartManager] 초기화 완료');
    }

    /**
     * 초기화
     */
    init() {
        this.setupResizeObserver();
        this.setupKeyboardShortcuts();
        this.setupDoubleClickReset();
        // setupDragZoom()은 renderChart() 후에 호출 (차트 생성 후 오버레이 추가 필요)
        this.setupWheelScroll();
    }

    /**
     * 리사이즈 옵저버 설정
     */
    setupResizeObserver() {
        if (!this.container) return;

        const resizeObserver = new ResizeObserver(entries => {
            for (const entry of entries) {
                if (this.chart) {
                    this.chart.applyOptions({
                        width: entry.contentRect.width
                    });
                }
            }
        });

        resizeObserver.observe(this.container);
    }

    /**
     * 키보드 단축키 설정
     */
    setupKeyboardShortcuts() {
        document.addEventListener('keydown', (e) => {
            if (!this.chart || !this.chartData) return;

            const totalBars = this.chartData.candlestick?.length || 0;
            if (totalBars === 0) return;

            switch (e.key) {
                case 'Home':
                    // 처음으로
                    this.chart.timeScale().setVisibleLogicalRange({ from: 0, to: Math.min(240, totalBars) });
                    break;
                case 'End':
                    // 끝으로
                    this.chart.timeScale().setVisibleLogicalRange({ from: Math.max(0, totalBars - 240), to: totalBars });
                    break;
                case 'r':
                case 'R':
                    // 리셋 (전체 표시)
                    if (!e.ctrlKey && !e.metaKey) {
                        this.chart.timeScale().fitContent();
                    }
                    break;
                case '+':
                case '=':
                    // 줌 인
                    this.zoomChart(1.2);
                    break;
                case '-':
                case '_':
                    // 줌 아웃
                    this.zoomChart(0.8);
                    break;
                case 'ArrowLeft':
                    // 왼쪽 이동
                    this.scrollChart(-20);
                    break;
                case 'ArrowRight':
                    // 오른쪽 이동
                    this.scrollChart(20);
                    break;
                case ' ':
                    // 스페이스: 과거 데이터 추가 로드
                    e.preventDefault();
                    this.loadMoreHistory();
                    break;
                case 's':
                case 'S':
                    // S: 스크린샷 저장
                    if (!e.ctrlKey && !e.metaKey) {
                        this.takeScreenshot();
                    }
                    break;
            }
        });
    }

    /**
     * 차트 줌
     */
    zoomChart(factor) {
        if (!this.chart) return;
        const visibleRange = this.chart.timeScale().getVisibleLogicalRange();
        if (!visibleRange) return;

        const center = (visibleRange.from + visibleRange.to) / 2;
        const halfRange = (visibleRange.to - visibleRange.from) / 2 / factor;

        this.chart.timeScale().setVisibleLogicalRange({
            from: center - halfRange,
            to: center + halfRange
        });
    }

    /**
     * 차트 스크롤
     */
    scrollChart(bars) {
        if (!this.chart) return;
        const visibleRange = this.chart.timeScale().getVisibleLogicalRange();
        if (!visibleRange) return;

        this.chart.timeScale().setVisibleLogicalRange({
            from: visibleRange.from + bars,
            to: visibleRange.to + bars
        });
    }

    /**
     * 더블클릭 이벤트 설정
     */
    setupDoubleClickReset() {
        if (!this.container) return;

        this.container.addEventListener('dblclick', () => {
            if (this.chart) {
                this.chart.timeScale().fitContent();
            }
        });
    }

    /**
     * 드래그 줌 설정
     * 오른쪽 드래그: 선택 영역 확대
     * 왼쪽 드래그: 전체 데이터 표시
     */
    setupDragZoom() {
        if (!this.container || !this.chart) return;

        // 기존 이벤트 정리
        this.removeDragZoomEvents();

        // 드래그 선택 오버레이 생성
        this.createDragOverlay();

        // 이벤트 핸들러 바인딩
        this._boundMouseDown = this.handleDragMouseDown.bind(this);
        this._boundMouseMove = this.handleDragMouseMove.bind(this);
        this._boundMouseUp = this.handleDragMouseUp.bind(this);
        this._boundMouseLeave = this.handleDragMouseLeave.bind(this);

        // 이벤트 등록
        this.container.addEventListener('mousedown', this._boundMouseDown);
        document.addEventListener('mousemove', this._boundMouseMove);
        document.addEventListener('mouseup', this._boundMouseUp);
        this.container.addEventListener('mouseleave', this._boundMouseLeave);
    }

    /**
     * 드래그 선택 오버레이 생성
     */
    createDragOverlay() {
        if (this.dragZoom.overlay) {
            this.dragZoom.overlay.remove();
        }

        const overlay = document.createElement('div');
        overlay.className = 'drag-zoom-overlay';
        overlay.style.cssText = `
            position: absolute;
            top: 0;
            height: 100%;
            background: rgba(102, 126, 234, 0.2);
            border-left: 2px solid #667eea;
            border-right: 2px solid #667eea;
            pointer-events: none;
            display: none;
            z-index: 50;
        `;

        this.container.style.position = 'relative';
        this.container.appendChild(overlay);
        this.dragZoom.overlay = overlay;
    }

    /**
     * 마우스 다운 핸들러
     */
    handleDragMouseDown(e) {
        if (e.button !== 0 || e.ctrlKey || e.metaKey) return;
        if (!this.chart) return;

        e.preventDefault();

        const rect = this.container.getBoundingClientRect();
        const x = e.clientX - rect.left;

        this.dragZoom.isDragging = true;
        this.dragZoom.startX = x;

        const timeScale = this.chart.timeScale();
        this.dragZoom.startTime = timeScale.coordinateToTime(x);

        if (this.dragZoom.overlay) {
            this.dragZoom.overlay.style.left = x + 'px';
            this.dragZoom.overlay.style.width = '0px';
            this.dragZoom.overlay.style.display = 'block';
        }
    }

    /**
     * 마우스 이동 핸들러
     */
    handleDragMouseMove(e) {
        if (!this.dragZoom.isDragging) return;

        const rect = this.container.getBoundingClientRect();
        let currentX = e.clientX - rect.left;
        const startX = this.dragZoom.startX;

        if (currentX < 0) currentX = 0;
        if (currentX > rect.width) currentX = rect.width;

        const deltaX = currentX - startX;

        if (this.dragZoom.overlay) {
            if (deltaX > 0) {
                // 오른쪽 드래그 - 확대 영역 (파란색)
                this.dragZoom.overlay.style.left = startX + 'px';
                this.dragZoom.overlay.style.width = deltaX + 'px';
                this.dragZoom.overlay.style.background = 'rgba(102, 126, 234, 0.2)';
                this.dragZoom.overlay.style.borderColor = '#667eea';
            } else {
                // 왼쪽 드래그 - 전체보기 영역 (빨간색)
                this.dragZoom.overlay.style.left = (startX + deltaX) + 'px';
                this.dragZoom.overlay.style.width = (-deltaX) + 'px';
                this.dragZoom.overlay.style.background = 'rgba(239, 68, 68, 0.2)';
                this.dragZoom.overlay.style.borderColor = '#ef4444';
            }
        }
    }

    /**
     * 마우스 업 핸들러
     */
    handleDragMouseUp(e) {
        if (!this.dragZoom.isDragging) return;

        const rect = this.container.getBoundingClientRect();
        let currentX = e.clientX - rect.left;
        const startX = this.dragZoom.startX;

        if (currentX < 0) currentX = 0;
        if (currentX > rect.width) currentX = rect.width;

        const deltaX = currentX - startX;
        const minDragDistance = 10;

        if (Math.abs(deltaX) >= minDragDistance && this.chart) {
            const timeScale = this.chart.timeScale();

            if (deltaX < 0) {
                // 왼쪽 드래그 - 전체 데이터 표시
                timeScale.fitContent();
            } else {
                // 오른쪽 드래그 - 선택 영역 확대
                let endTime = timeScale.coordinateToTime(currentX);
                const startTime = this.dragZoom.startTime;

                if (!endTime && this.chartData?.candlestick?.length > 0) {
                    const lastCandle = this.chartData.candlestick[this.chartData.candlestick.length - 1];
                    endTime = lastCandle.time;
                }

                if (startTime && endTime) {
                    timeScale.setVisibleRange({ from: startTime, to: endTime });
                }
            }
        }

        // 상태 초기화
        this.dragZoom.isDragging = false;
        this.dragZoom.startX = 0;
        this.dragZoom.startTime = null;

        if (this.dragZoom.overlay) {
            this.dragZoom.overlay.style.display = 'none';
        }
    }

    /**
     * 마우스 떠남 핸들러
     */
    handleDragMouseLeave(e) {
        if (this.dragZoom.isDragging) return;

        if (this.dragZoom.overlay) {
            this.dragZoom.overlay.style.display = 'none';
        }
    }

    /**
     * 휠 스크롤 설정 (좌우 이동)
     */
    setupWheelScroll() {
        if (!this.container) return;

        this.container.addEventListener('wheel', (e) => {
            if (!this.chart || !this.chartData?.candlestick) return;

            e.preventDefault();

            const timeScale = this.chart.timeScale();
            const visibleRange = timeScale.getVisibleLogicalRange();
            if (!visibleRange) return;

            // 스크롤 방향에 따라 이동량 계산
            // deltaY > 0: 아래로 스크롤 (오른쪽으로 이동 = 과거 데이터)
            // deltaY < 0: 위로 스크롤 (왼쪽으로 이동 = 최신 데이터)
            const scrollAmount = e.deltaY > 0 ? 10 : -10;

            const rangeWidth = visibleRange.to - visibleRange.from;
            const totalBars = this.chartData.candlestick.length;

            let newFrom = visibleRange.from + scrollAmount;
            let newTo = visibleRange.to + scrollAmount;

            // 범위 제한
            if (newFrom < 0) {
                newFrom = 0;
                newTo = rangeWidth;
            }
            if (newTo > totalBars + 10) {
                newTo = totalBars + 10;
                newFrom = newTo - rangeWidth;
            }

            timeScale.setVisibleLogicalRange({ from: newFrom, to: newTo });
        }, { passive: false });
    }

    /**
     * 차트 컨트롤 버튼 생성 (- + A)
     */
    createChartControls() {
        // 기존 컨트롤 제거
        const existingControls = this.container.querySelector('.chart-zoom-controls');
        if (existingControls) {
            existingControls.remove();
        }

        const controlsDiv = document.createElement('div');
        controlsDiv.className = 'chart-zoom-controls';
        controlsDiv.style.cssText = `
            position: absolute;
            top: 8px;
            right: 12px;
            z-index: 100;
            display: flex;
            gap: 4px;
        `;

        // 축소 버튼 (-)
        const zoomOutBtn = document.createElement('button');
        zoomOutBtn.innerHTML = '−';
        zoomOutBtn.title = '축소 (-)';
        zoomOutBtn.style.cssText = `
            width: 28px;
            height: 28px;
            border: 1px solid #d1d5db;
            border-radius: 4px;
            background: #fff;
            cursor: pointer;
            font-size: 16px;
            font-weight: bold;
            color: #374151;
        `;
        zoomOutBtn.addEventListener('click', () => this.zoomChart(0.8));

        // 확대 버튼 (+)
        const zoomInBtn = document.createElement('button');
        zoomInBtn.innerHTML = '+';
        zoomInBtn.title = '확대 (+)';
        zoomInBtn.style.cssText = zoomOutBtn.style.cssText;
        zoomInBtn.addEventListener('click', () => this.zoomChart(1.2));

        // 전체보기 버튼 (A)
        const fitBtn = document.createElement('button');
        fitBtn.innerHTML = 'A';
        fitBtn.title = '전체보기 (R)';
        fitBtn.style.cssText = zoomOutBtn.style.cssText;
        fitBtn.addEventListener('click', () => {
            if (this.chart) this.chart.timeScale().fitContent();
        });

        controlsDiv.appendChild(zoomOutBtn);
        controlsDiv.appendChild(zoomInBtn);
        controlsDiv.appendChild(fitBtn);

        this.container.appendChild(controlsDiv);
    }

    /**
     * 보이는 범위 조절 (-/+ 버튼용)
     */
    adjustVisibleRange(days) {
        if (!this.chart || !this.chartData?.candlestick) return;

        const timeScale = this.chart.timeScale();
        const visibleRange = timeScale.getVisibleLogicalRange();
        if (!visibleRange) return;

        const totalBars = this.chartData.candlestick.length;
        const currentWidth = visibleRange.to - visibleRange.from;

        // 새로운 너비 계산 (최소 20일, 최대 전체 데이터)
        let newWidth = currentWidth + days;
        if (newWidth < 20) newWidth = 20;
        if (newWidth > totalBars) newWidth = totalBars;

        // 오른쪽 끝(최신) 기준으로 범위 조정
        const newFrom = visibleRange.to - newWidth;

        timeScale.setVisibleLogicalRange({
            from: Math.max(0, newFrom),
            to: visibleRange.to
        });

        console.log(`[ChartControls] 범위 조정: ${Math.round(currentWidth)}일 → ${Math.round(newWidth)}일`);
    }

    /**
     * 전체 데이터 표시
     */
    showAllData() {
        if (!this.chart) return;
        this.chart.timeScale().fitContent();
        console.log('[ChartControls] 전체 보기');
    }

    /**
     * 크로스헤어 이동 시 툴팁 표시
     */
    handleCrosshairMove(param) {
        // 툴팁 요소 가져오기 또는 생성
        let tooltip = document.getElementById('candleTooltip');
        if (!tooltip) {
            tooltip = document.createElement('div');
            tooltip.id = 'candleTooltip';
            tooltip.style.cssText = `
                position: absolute;
                background: rgba(0, 0, 0, 0.85);
                color: #ffffff;
                padding: 8px 12px;
                border-radius: 4px;
                font-size: 12px;
                line-height: 1.6;
                pointer-events: none;
                z-index: 100;
                white-space: nowrap;
                display: none;
                box-shadow: 0 2px 8px rgba(0,0,0,0.3);
            `;
            this.container.appendChild(tooltip);
        }

        // 마우스가 차트 영역을 벗어났거나 데이터가 없는 경우
        if (!param.time || !param.seriesData || param.point === undefined) {
            tooltip.style.display = 'none';
            return;
        }

        const candleData = param.seriesData.get(this.candlestickSeries);
        if (!candleData) {
            tooltip.style.display = 'none';
            return;
        }

        // 날짜 포맷팅
        let formattedDate = param.time;
        if (typeof param.time === 'number') {
            const date = new Date(param.time * 1000);
            const year = date.getUTCFullYear();
            const month = String(date.getUTCMonth() + 1).padStart(2, '0');
            const day = String(date.getUTCDate()).padStart(2, '0');

            if (this.currentPeriod === 'minute3' || this.currentPeriod === 'minute') {
                const hour = String(date.getUTCHours()).padStart(2, '0');
                const minute = String(date.getUTCMinutes()).padStart(2, '0');
                formattedDate = `${year}.${month}.${day} ${hour}:${minute}`;
            } else {
                formattedDate = `${year}.${month}.${day}`;
            }
        }

        // 거래대금
        let tradeValue = '-';
        if (this.chartData?.candlestick) {
            const matchingCandle = this.chartData.candlestick.find(c => c.time === param.time);
            if (matchingCandle && matchingCandle.tradeValue > 0) {
                tradeValue = Math.round(matchingCandle.tradeValue).toLocaleString() + '억';
            }
        }

        // 툴팁 내용
        tooltip.innerHTML = `
            <div style="margin-bottom: 4px; font-weight: bold; color: #9ca3af;">날짜: ${formattedDate}</div>
            <div>시가: ${candleData.open?.toLocaleString() || '-'}</div>
            <div>고가: <span style="color: #ef4444;">${candleData.high?.toLocaleString() || '-'}</span></div>
            <div>저가: <span style="color: #3b82f6;">${candleData.low?.toLocaleString() || '-'}</span></div>
            <div>종가: ${candleData.close?.toLocaleString() || '-'}</div>
            <div style="margin-top: 4px; padding-top: 4px; border-top: 1px solid #4b5563;">거래대금: ${tradeValue}</div>
        `;

        // 툴팁 위치 계산
        const containerRect = this.container.getBoundingClientRect();
        let x = param.point.x + 15;
        let y = param.point.y - 80;

        const tooltipWidth = 150;
        if (x + tooltipWidth > containerRect.width) {
            x = param.point.x - tooltipWidth - 15;
        }
        if (y < 10) {
            y = param.point.y + 15;
        }

        tooltip.style.left = x + 'px';
        tooltip.style.top = y + 'px';
        tooltip.style.display = 'block';
    }

    /**
     * 지표 패널 전환 (3분봉 전용 지표 <-> 일반 지표)
     */
    switchIndicatorPanel(period) {
        const dailyIndicators = document.getElementById('dailyIndicators');
        const minuteIndicators = document.getElementById('minuteIndicators');

        if (!dailyIndicators || !minuteIndicators) return;

        const isMinute = period === 'minute3' || period === 'minute';

        if (isMinute) {
            dailyIndicators.classList.add('hidden');
            minuteIndicators.classList.remove('hidden');
        } else {
            dailyIndicators.classList.remove('hidden');
            minuteIndicators.classList.add('hidden');
        }
    }

    /**
     * 차트 로드
     */
    async loadChart(stockCode, period = 'daily', stockName = null) {
        if (!stockCode) return;

        this.currentCode = stockCode.replace('A', '');
        this.currentPeriod = period;
        if (stockName) this.currentName = stockName;

        console.log(`[AIQuantChartManager] loadChart 호출: code=${this.currentCode}, period=${period}, name=${stockName}, useIPC=${this.useIPC}`);

        this.showLoading();

        try {
            let result;

            // Electron 환경: IPC 사용
            if (this.useIPC && window.electronAPI?.kiwoom) {
                if (period === 'minute3') {
                    result = await window.electronAPI.kiwoom.minuteChart({
                        stkCd: this.currentCode,
                        interval: 3,
                        count: 600
                    });
                } else {
                    result = await window.electronAPI.kiwoom.dailyChart({
                        stkCd: this.currentCode,
                        count: 600
                    });
                }
            } else {
                // 브라우저 환경: fetch 사용
                const today = new Date();
                const baseDate = today.toISOString().slice(0, 10).replace(/-/g, '');
                const token = localStorage.getItem('kiwoom_token') || '';
                const host = localStorage.getItem('kiwoom_host') || 'https://mockapi.kiwoom.com';

                if (!token) {
                    this.showError('토큰이 없습니다. API 인증에서 토큰을 발급받으세요.');
                    return;
                }

                let endpoint;
                if (period === 'minute3') {
                    endpoint = `${this.proxyUrl}/api/chart/minute?code=${this.currentCode}&interval=3&count=600`;
                } else {
                    endpoint = `${this.proxyUrl}/api/chart/${period}?code=${this.currentCode}&count=600`;
                }

                const response = await fetch(endpoint, {
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': `Bearer ${token}`
                    }
                });
                result = await response.json();
            }

            // 디버그: API 응답 확인
            console.log('[AIQuantChartManager] dailyChart 원본 result:', result);
            console.log('[AIQuantChartManager] result.success:', result?.success);
            console.log('[AIQuantChartManager] result.data 키:', result?.data ? Object.keys(result.data) : 'null');
            console.log('[AIQuantChartManager] candlestick 개수:', result?.data?.candlestick?.length);
            // 메인 프로세스 디버그 정보 출력
            if (result?._debug) {
                console.log('[AIQuantChartManager] _debug.rawKeys:', result._debug.rawKeys);
                console.log('[AIQuantChartManager] _debug.rawSample:', result._debug.rawSample);
            }

            if (result.success && result.data) {
                this.chartData = result.data;
                this.renderChart(result.data);
                this.updateStockInfo();
            } else {
                this.showError(result.message || result.error || '차트 데이터를 불러올 수 없습니다.');
            }
        } catch (error) {
            console.error('[AIQuantChartManager] 차트 로드 오류:', error);
            this.showError('차트 로드 중 오류가 발생했습니다.');
        }
    }

    /**
     * 차트 렌더링
     */
    renderChart(data) {
        // 기존 차트 제거
        if (this.chart) {
            this.chart.remove();
            this.chart = null;
        }

        // 시리즈 참조 초기화
        this.maSeries = {};
        this.ichimokuSeries = {};
        this.bollingerUpperSeries = null;
        this.candlestickSeries = null;
        this.volumeSeries = null;
        this.tradeValueSeries = null;  // 거래대금 시리즈 초기화 추가

        // 컨테이너 초기화
        this.container.innerHTML = '';

        // 컨테이너 크기 - getBoundingClientRect 사용하여 더 정확하게 측정
        const rect = this.container.getBoundingClientRect();
        const containerWidth = rect.width || this.container.clientWidth || 600;
        const containerHeight = rect.height || this.container.clientHeight || 400;
        console.log('[Chart] 컨테이너 크기:', containerWidth, 'x', containerHeight);

        // 차트 생성 (chart_viewer.py 스펙: 밝은 배경 #EAEAEA)
        this.chart = LightweightCharts.createChart(this.container, {
            width: containerWidth,
            height: containerHeight,
            autoSize: true,  // 컨테이너 크기에 맞게 자동 조정
            layout: {
                background: { type: 'solid', color: '#EAEAEA' },
                textColor: '#333333',
            },
            grid: {
                vertLines: { visible: false },
                horzLines: { visible: false },
            },
            crosshair: {
                mode: LightweightCharts.CrosshairMode.Normal,
                vertLine: {
                    color: '#ef4444',
                    width: 1,
                    style: LightweightCharts.LineStyle.Solid,
                    labelBackgroundColor: '#1f2937',
                },
                horzLine: {
                    color: '#ef4444',
                    width: 1,
                    style: LightweightCharts.LineStyle.Solid,
                    labelBackgroundColor: '#1f2937',
                },
            },
            rightPriceScale: {
                borderColor: '#e5e7eb',
            },
            timeScale: {
                borderColor: '#e5e7eb',
                timeVisible: true,
                secondsVisible: false,
                rightOffset: 3,
            },
            localization: {
                locale: 'ko-KR',
                priceFormatter: (price) => price.toLocaleString('ko-KR'),
            },
            handleScroll: {
                mouseWheel: false,          // 커스텀 휠 스크롤 사용
                pressedMouseMove: false,    // 드래그로 스크롤 비활성화 (커스텀 드래그 줌 사용)
                horzTouchDrag: true,        // 터치 드래그는 허용
                vertTouchDrag: true,
            },
            handleScale: {
                axisPressedMouseMove: true,
                mouseWheel: false,          // 커스텀 휠 스크롤 사용
                pinch: true,
            },
        });

        // 분봉 차트인 경우
        const isMinuteChart = this.currentPeriod === 'minute3';

        // 상단 범례/정보 영역 생성
        this.createLegendOverlay();

        // ===== 원본 stock-chart.js와 동일한 순서로 시리즈 추가 =====

        // ★★★ 분봉 차트인 경우 노란색 배경 영역을 캔들보다 먼저 추가 (z-order) ★★★
        // 2026-01-05: Area 시리즈 Value is null 오류로 완전 비활성화
        // lightweight-charts Area 시리즈가 특정 조건에서 null 값을 처리하지 못함
        // 추후 원인 파악 후 재활성화 예정

        // 1. 캔들스틱 시리즈 추가
        this.candlestickSeries = this.chart.addCandlestickSeries({
            upColor: '#ef4444',
            downColor: '#3b82f6',
            borderUpColor: '#ef4444',
            borderDownColor: '#3b82f6',
            wickUpColor: '#ef4444',
            wickDownColor: '#3b82f6',
        });
        this.candlestickSeries.setData(data.candlestick);

        // 2. 거래대금 시리즈 (억 단위, 원본 stock-chart.js와 동일)
        console.log('[AIQuantChartManager] 거래대금 데이터 체크:', {
            hasTradeValue: !!data.tradeValue,
            length: data.tradeValue?.length || 0,
            isMinuteChart,
            period: this.currentPeriod
        });

        if (data.tradeValue && data.tradeValue.length > 0) {
            const maxValue = Math.max(...data.tradeValue.map(d => d.value));
            const minValue = Math.min(...data.tradeValue.map(d => d.value));
            console.log(`[AIQuantChartManager] 거래대금 범위: ${minValue.toFixed(2)}억 ~ ${maxValue.toFixed(2)}억`);
            console.log('[AIQuantChartManager] 거래대금 처음 3개:', data.tradeValue?.slice(0, 3));
            console.log('[AIQuantChartManager] 거래대금 마지막 3개:', data.tradeValue?.slice(-3));

            this.tradeValueSeries = this.chart.addHistogramSeries({
                color: '#ef4444',  // 기본 색상 (개별 데이터에서 덮어씌움)
                priceFormat: {
                    type: 'price',
                    precision: 0,  // 억 단위 정수
                    minMove: 1,
                },
                priceScaleId: 'tradeValue',  // 별도의 가격 스케일 사용
            });

            // 메인 가격 스케일 설정 (상단 영역에 캔들 표시) - stock-chart.js와 동일
            this.chart.priceScale('right').applyOptions({
                scaleMargins: {
                    top: 0.02,
                    bottom: 0.25,  // 하단 25%는 거래대금 영역
                },
            });

            // 거래대금 가격 스케일 설정 (하단 영역에 표시) - stock-chart.js와 동일
            this.chart.priceScale('tradeValue').applyOptions({
                scaleMargins: {
                    top: 0.78,   // 상단 78%는 캔들 영역
                    bottom: 0.02,
                },
            });

            this.tradeValueSeries.setData(data.tradeValue);
        }

        // 3. 지표 렌더링
        if (!isMinuteChart) {
            // 일봉/주봉/월봉: MA, 일목, 볼린저
            this.renderDailyIndicators(data.candlestick);
        } else {
            // 3분봉: 피봇, 당일시가, 일자경계선
            this.renderMinuteIndicators(data.candlestick);
        }

        // 크로스헤어 이동 시 OHLCV 업데이트
        this.setupCrosshairMove(data);

        // 초기 표시 범위 설정 (chart_viewer.py 스펙: 일봉 240개)
        const totalBars = data.candlestick.length;
        if (isMinuteChart && totalBars > 0) {
            // 분봉: 당일 캔들만 표시
            this.setTodayVisibleRange(data.candlestick);
        } else if (totalBars > 240) {
            this.chart.timeScale().setVisibleLogicalRange({
                from: totalBars - 240,
                to: totalBars
            });
        } else {
            this.chart.timeScale().fitContent();
        }

        // 컨트롤 버튼 표시
        this.showChartControls();

        // 보이는 범위 고가/저가 표시 초기화
        this.initVisibleHighLow(data.candlestick);

        // 스크롤바 초기화
        this.initScrollbar(data.candlestick.length);

        // 드로잉 캔버스 초기화
        this.initDrawingCanvas();

        // 우측 경계 제한 설정
        this.setupRightEdgeLimit();

        // 드래그 줌 재설정 (renderChart에서 container.innerHTML = ''로 오버레이가 삭제되므로)
        this.setupDragZoom();

        console.log(`[AIQuantChartManager] 차트 렌더링 완료: ${data.candlestick.length}개 데이터`);
    }

    /**
     * 일봉/주봉/월봉 지표 렌더링
     */
    renderDailyIndicators(candlestickData) {
        // 이동평균선: 5, 20, 60, 120, 240일선
        this.addMA(candlestickData, 5);
        this.addMA(candlestickData, 20);
        this.addMA(candlestickData, 60);
        this.addMA(candlestickData, 120);
        this.addMA(candlestickData, 240);

        // 일목균형표 기준선
        this.addIchimokuKijunsen(candlestickData);

        // 볼린저밴드 상단선
        this.addBollingerUpperBand(candlestickData);
    }

    /**
     * 3분봉 전용 지표 렌더링
     */
    renderMinuteIndicators(candlestickData) {
        console.log('[AIQuantChartManager] 3분봉 지표 렌더링 시작');

        // 당일시가 라인 (보라색)
        this.addTodayOpenLine(candlestickData);

        // 일자 경계선 (빨간 수직선)
        this.addDateBoundaryLines(candlestickData);

        console.log('[AIQuantChartManager] 3분봉 지표 렌더링 완료');
    }

    /**
     * 이동평균선 추가
     */
    addMA(candlestickData, period) {
        const maKey = `ma${period}`;
        if (this.maSeries[maKey]) return;

        const maData = this.calculateMA(candlestickData, period);

        this.maSeries[maKey] = this.chart.addLineSeries({
            color: this.maColors[maKey] || '#666666',
            lineWidth: this.maLineWidths[maKey] || 1,
            priceLineVisible: false,
            lastValueVisible: false,
        });

        this.maSeries[maKey].setData(maData);
    }

    /**
     * 이동평균 계산
     */
    calculateMA(candlestickData, period) {
        const maData = [];
        for (let i = period - 1; i < candlestickData.length; i++) {
            let sum = 0;
            for (let j = 0; j < period; j++) {
                sum += candlestickData[i - j].close;
            }
            maData.push({
                time: candlestickData[i].time,
                value: Math.round(sum / period)
            });
        }
        return maData;
    }

    /**
     * 볼린저밴드 계산
     */
    calculateBollingerBands(candlestickData, period = 20, multiplier = 2) {
        const middle = this.calculateMA(candlestickData, period);
        const upper = [];
        const lower = [];

        for (let i = period - 1; i < candlestickData.length; i++) {
            let sum = 0;
            const avg = middle[i - (period - 1)].value;

            for (let j = 0; j < period; j++) {
                sum += Math.pow(candlestickData[i - j].close - avg, 2);
            }
            const stdDev = Math.sqrt(sum / period);

            upper.push({
                time: candlestickData[i].time,
                value: Math.round(avg + multiplier * stdDev)
            });

            lower.push({
                time: candlestickData[i].time,
                value: Math.round(avg - multiplier * stdDev)
            });
        }

        return { middle, upper, lower };
    }

    /**
     * 일목균형표 기준선 계산 (26일 최고가/최저가 평균)
     */
    calculateIchimokuKijunsen(candlestickData, period = 26) {
        const kijunsenData = [];

        for (let i = period - 1; i < candlestickData.length; i++) {
            let highest = -Infinity;
            let lowest = Infinity;

            for (let j = 0; j < period; j++) {
                const candle = candlestickData[i - j];
                if (candle.high > highest) highest = candle.high;
                if (candle.low < lowest) lowest = candle.low;
            }

            kijunsenData.push({
                time: candlestickData[i].time,
                value: Math.round((highest + lowest) / 2)
            });
        }

        return kijunsenData;
    }

    /**
     * 볼린저밴드 제거 (전체)
     */
    removeBollingerBands() {
        if (this.bollingerUpperSeries) {
            try {
                this.chart.removeSeries(this.bollingerUpperSeries);
            } catch (e) {}
            this.bollingerUpperSeries = null;
        }
    }

    /**
     * 일목균형표 기준선 추가
     */
    addIchimokuKijunsen(candlestickData, period = 26) {
        if (this.ichimokuSeries.kijunsen) return;

        const kijunsenData = [];
        for (let i = period - 1; i < candlestickData.length; i++) {
            let highest = -Infinity;
            let lowest = Infinity;
            for (let j = 0; j < period; j++) {
                const candle = candlestickData[i - j];
                if (candle.high > highest) highest = candle.high;
                if (candle.low < lowest) lowest = candle.low;
            }
            kijunsenData.push({
                time: candlestickData[i].time,
                value: Math.round((highest + lowest) / 2)
            });
        }

        this.ichimokuSeries.kijunsen = this.chart.addLineSeries({
            color: '#22c55e',
            lineWidth: 2,
            priceLineVisible: false,
            lastValueVisible: false,
        });
        this.ichimokuSeries.kijunsen.setData(kijunsenData);
    }

    /**
     * 볼린저밴드 상단선 추가
     */
    addBollingerUpperBand(candlestickData, period = 20, multiplier = 2) {
        if (this.bollingerUpperSeries) return;

        const maData = this.calculateMA(candlestickData, period);
        const upperData = [];

        for (let i = period - 1; i < candlestickData.length; i++) {
            let sum = 0;
            const avg = maData[i - (period - 1)].value;
            for (let j = 0; j < period; j++) {
                sum += Math.pow(candlestickData[i - j].close - avg, 2);
            }
            const stdDev = Math.sqrt(sum / period);
            upperData.push({
                time: candlestickData[i].time,
                value: Math.round(avg + multiplier * stdDev)
            });
        }

        this.bollingerUpperSeries = this.chart.addLineSeries({
            color: '#000000',
            lineWidth: 3,
            priceLineVisible: false,
            lastValueVisible: false,
        });
        this.bollingerUpperSeries.setData(upperData);
    }

    /**
     * 당일시가 라인 제거
     */
    removeTodayOpenLine() {
        if (this.todayOpenSeries) {
            try {
                this.chart.removeSeries(this.todayOpenSeries);
            } catch (e) {}
            this.todayOpenSeries = null;
        }
    }

    /**
     * 당일시가 라인 추가 (보라색)
     */
    addTodayOpenLine(candlestickData) {
        if (!candlestickData || candlestickData.length === 0) return;

        // 기존 라인 제거
        if (this.todayOpenSeries) {
            try { this.chart.removeSeries(this.todayOpenSeries); } catch (e) {}
            this.todayOpenSeries = null;
        }

        // 당일 첫 캔들 찾기
        const todayStartIndex = this.findTodayStartIndex(candlestickData);
        if (todayStartIndex >= candlestickData.length) return;

        const todayCandles = candlestickData.slice(todayStartIndex);
        if (todayCandles.length === 0) return;

        const todayOpenPrice = todayCandles[0].open;
        const firstTime = todayCandles[0].time;
        const lastTime = todayCandles[todayCandles.length - 1].time;

        this.todayOpenSeries = this.chart.addLineSeries({
            color: '#8b5cf6',  // 보라색
            lineWidth: 2,
            priceLineVisible: false,
            lastValueVisible: true,
            visible: this.minuteIndicatorSettings.todayOpen,
        });

        this.todayOpenSeries.setData([
            { time: firstTime, value: todayOpenPrice },
            { time: lastTime, value: todayOpenPrice }
        ]);
    }

    /**
     * 일자 경계선 추가 (빨간 수직선)
     * TradingView Lightweight Charts는 수직선을 직접 지원하지 않으므로
     * 마커로 표현하거나, 프라이스 라인으로 대체
     */
    addDateBoundaryLines(candlestickData) {
        if (!candlestickData || candlestickData.length < 2) return;

        // 기존 마커 제거
        this.dateBoundaryMarkers = [];

        const getDateStr = (timestamp) => {
            const date = new Date(timestamp * 1000);
            return `${date.getUTCFullYear()}-${String(date.getUTCMonth() + 1).padStart(2, '0')}-${String(date.getUTCDate()).padStart(2, '0')}`;
        };

        // 날짜가 바뀌는 지점 찾기
        const boundaries = [];
        let prevDate = getDateStr(candlestickData[0].time);

        for (let i = 1; i < candlestickData.length; i++) {
            const currDate = getDateStr(candlestickData[i].time);
            if (currDate !== prevDate) {
                boundaries.push({
                    time: candlestickData[i].time,
                    position: 'aboveBar',
                    color: '#FF0000',
                    shape: 'arrowDown',
                    text: currDate.slice(5)  // MM-DD만 표시
                });
                prevDate = currDate;
            }
        }

        // 캔들스틱 시리즈에 마커 추가
        if (boundaries.length > 0 && this.candlestickSeries) {
            this.candlestickSeries.setMarkers(boundaries);
            this.dateBoundaryMarkers = boundaries;
        }
    }

    /**
     * 당일 첫 캔들 인덱스 찾기
     */
    findTodayStartIndex(candlestickData) {
        if (!candlestickData || candlestickData.length === 0) return 0;

        const getDateStr = (timestamp) => {
            const date = new Date(timestamp * 1000);
            return `${date.getUTCFullYear()}-${String(date.getUTCMonth() + 1).padStart(2, '0')}-${String(date.getUTCDate()).padStart(2, '0')}`;
        };

        const lastDate = getDateStr(candlestickData[candlestickData.length - 1].time);

        for (let i = candlestickData.length - 1; i >= 0; i--) {
            if (getDateStr(candlestickData[i].time) !== lastDate) {
                return i + 1;
            }
        }
        return 0;
    }

    /**
     * 당일 캔들만 보이도록 범위 설정
     */
    setTodayVisibleRange(candlestickData) {
        const totalBars = candlestickData.length;
        if (totalBars === 0) return;

        // time 필드에서 날짜 추출 헬퍼
        const getDateStr = (candle) => {
            if (typeof candle.time === 'string') {
                return candle.time.slice(0, 10);  // "2026-01-05 09:30" → "2026-01-05"
            } else if (typeof candle.time === 'number') {
                return new Date(candle.time * 1000).toISOString().slice(0, 10);
            }
            return '';
        };

        const lastCandle = candlestickData[totalBars - 1];
        const lastDateStr = getDateStr(lastCandle);

        let todayStartIndex = totalBars - 1;
        for (let i = totalBars - 1; i >= 0; i--) {
            const candleDateStr = getDateStr(candlestickData[i]);
            if (candleDateStr === lastDateStr) {
                todayStartIndex = i;
            } else {
                break;
            }
        }

        // 날짜별 캔들 개수 확인 (디버깅용)
        const dateCounts = {};
        for (let i = Math.max(0, totalBars - 100); i < totalBars; i++) {
            const dateStr = getDateStr(candlestickData[i]);
            dateCounts[dateStr] = (dateCounts[dateStr] || 0) + 1;
        }
        console.log('[AIQuantChartManager] 최근 100개 캔들 날짜 분포:', dateCounts);
        console.log(`[AIQuantChartManager] setTodayVisibleRange: totalBars=${totalBars}, todayStartIndex=${todayStartIndex}, lastDate=${lastDateStr}`);
        console.log(`[AIQuantChartManager] 표시할 캔들 개수: ${totalBars - todayStartIndex}개`);

        this.chart.timeScale().setVisibleLogicalRange({
            from: todayStartIndex,
            to: totalBars
        });
    }

    /**
     * 기간 변경
     */
    async changePeriod(period) {
        if (!this.currentCode) return;

        // 버튼 상태 업데이트
        document.querySelectorAll('.chart-period-btn').forEach(btn => {
            btn.classList.toggle('active', btn.dataset.period === period);
        });

        // 지표 패널 전환
        const dailyIndicators = document.getElementById('dailyIndicators');
        const minuteIndicators = document.getElementById('minuteIndicators');
        if (dailyIndicators && minuteIndicators) {
            if (period === 'minute3') {
                dailyIndicators.classList.add('hidden');
                minuteIndicators.classList.remove('hidden');
            } else {
                dailyIndicators.classList.remove('hidden');
                minuteIndicators.classList.add('hidden');
            }
        }

        await this.loadChart(this.currentCode, period, this.currentName);
    }

    /**
     * 새로고침
     */
    async refresh() {
        if (this.currentCode) {
            await this.loadChart(this.currentCode, this.currentPeriod, this.currentName);
        }
    }

    /**
     * 종목 정보 업데이트
     */
    updateStockInfo() {
        // 외부 표시 요소 업데이트
        const codeEl = document.getElementById('chartStockCodeDisplay');
        const nameEl = document.getElementById('chartStockNameDisplay');

        if (codeEl) codeEl.textContent = this.currentCode || '-';
        if (nameEl) nameEl.textContent = this.currentName || '-';

        // 차트 내부 범례 오버레이 업데이트
        if (this.legendOverlay) {
            const legendNameEl = this.legendOverlay.querySelector('.legend-stock-name');
            const legendCodeEl = this.legendOverlay.querySelector('.legend-stock-code');
            if (legendNameEl) legendNameEl.textContent = this.currentName || '';
            if (legendCodeEl) legendCodeEl.textContent = this.currentCode || '';
        }
    }

    /**
     * 차트 컨트롤 표시
     */
    showChartControls() {
        const controls = document.getElementById('chartControls');
        if (controls) {
            controls.classList.remove('hidden');
        }
        // 줌 버튼 생성
        this.createChartControls();
    }

    /**
     * 로딩 표시
     */
    showLoading() {
        if (this.container) {
            this.container.innerHTML = `
                <div style="display: flex; align-items: center; justify-content: center; height: 100%; color: #888;">
                    <i class="fas fa-spinner fa-spin" style="margin-right: 8px;"></i>
                    차트 로딩 중...
                </div>
            `;
        }
    }

    /**
     * 에러 표시
     */
    showError(message) {
        if (this.container) {
            this.container.innerHTML = `
                <div style="display: flex; flex-direction: column; align-items: center; justify-content: center; height: 100%; color: #888;">
                    <i class="fas fa-exclamation-triangle" style="font-size: 32px; margin-bottom: 12px; color: #ef4444;"></i>
                    <p>${message}</p>
                </div>
            `;
        }
    }

    /**
     * 지표 토글 (일봉)
     */
    toggleMA(maKey, enabled) {
        const period = parseInt(maKey.replace('ma', ''));
        if (enabled) {
            if (this.chartData?.candlestick) {
                this.addMA(this.chartData.candlestick, period);
            }
        } else {
            if (this.maSeries[maKey]) {
                this.chart.removeSeries(this.maSeries[maKey]);
                delete this.maSeries[maKey];
            }
        }
    }

    toggleIchimoku(enabled) {
        if (enabled) {
            if (this.chartData?.candlestick) {
                this.addIchimokuKijunsen(this.chartData.candlestick);
            }
        } else {
            if (this.ichimokuSeries.kijunsen) {
                this.chart.removeSeries(this.ichimokuSeries.kijunsen);
                delete this.ichimokuSeries.kijunsen;
            }
        }
    }

    toggleBollinger(enabled) {
        if (enabled) {
            if (this.chartData?.candlestick) {
                this.addBollingerUpperBand(this.chartData.candlestick);
            }
        } else {
            if (this.bollingerUpperSeries) {
                this.chart.removeSeries(this.bollingerUpperSeries);
                this.bollingerUpperSeries = null;
            }
        }
    }

    /**
     * 3분봉 지표 토글
     */
    toggleMinuteIndicator(indicator, enabled) {
        this.minuteIndicatorSettings[indicator] = enabled;
    }

    /**
     * 보이는 범위 최고가/최저가 표시 초기화
     */
    initVisibleHighLow(candlestickData) {
        // 기존 캔버스 및 핸들러 정리
        if (this.visibleHighLow.canvas) {
            this.visibleHighLow.canvas.remove();
        }
        if (this.visibleHighLow.updateHandler && this.chart) {
            this.chart.timeScale().unsubscribeVisibleLogicalRangeChange(this.visibleHighLow.updateHandler);
        }

        // 캔버스 생성
        const canvas = document.createElement('canvas');
        canvas.className = 'visible-high-low-canvas';
        canvas.style.cssText = `
            position: absolute;
            top: 0;
            left: 0;
            pointer-events: none;
            z-index: 50;
        `;
        const rect = this.container.getBoundingClientRect();
        canvas.width = rect.width;
        canvas.height = rect.height;
        canvas.style.width = `${rect.width}px`;
        canvas.style.height = `${rect.height}px`;
        this.container.appendChild(canvas);
        this.visibleHighLow.canvas = canvas;
        this.visibleHighLow.data = candlestickData;

        // 업데이트 핸들러
        const updateHandler = () => this.updateVisibleHighLow();
        this.visibleHighLow.updateHandler = updateHandler;

        // 보이는 범위 변경 시 업데이트
        this.chart.timeScale().subscribeVisibleLogicalRangeChange(updateHandler);

        // 초기 업데이트
        setTimeout(() => this.updateVisibleHighLow(), 100);
    }

    /**
     * 보이는 범위 내 최고가/최저가 업데이트
     */
    updateVisibleHighLow() {
        const canvas = this.visibleHighLow.canvas;
        if (!canvas || !this.visibleHighLow.data || !this.candlestickSeries || !this.chart) return;

        const ctx = canvas.getContext('2d');
        const rect = this.container.getBoundingClientRect();
        const cssWidth = rect.width;
        const cssHeight = rect.height;

        // 캔버스 크기 동기화
        if (canvas.width !== cssWidth || canvas.height !== cssHeight) {
            canvas.width = cssWidth;
            canvas.height = cssHeight;
            canvas.style.width = `${cssWidth}px`;
            canvas.style.height = `${cssHeight}px`;
        }

        ctx.clearRect(0, 0, cssWidth, cssHeight);

        // 현재 보이는 범위 가져오기
        const logicalRange = this.chart.timeScale().getVisibleLogicalRange();
        if (!logicalRange) return;

        const data = this.visibleHighLow.data;
        const fromIndex = Math.max(0, Math.floor(logicalRange.from));
        const toIndex = Math.min(data.length - 1, Math.ceil(logicalRange.to));

        if (fromIndex >= toIndex) return;

        // 보이는 범위 내 최고가/최저가 찾기
        let highestPrice = -Infinity;
        let lowestPrice = Infinity;
        let highestTime = null;
        let lowestTime = null;

        for (let i = fromIndex; i <= toIndex; i++) {
            const candle = data[i];
            if (!candle) continue;

            if (candle.high > highestPrice) {
                highestPrice = candle.high;
                highestTime = candle.time;
            }
            if (candle.low < lowestPrice) {
                lowestPrice = candle.low;
                lowestTime = candle.time;
            }
        }

        if (highestPrice === -Infinity || lowestPrice === Infinity) return;

        // 좌표 변환
        const highY = this.candlestickSeries.priceToCoordinate(highestPrice);
        const lowY = this.candlestickSeries.priceToCoordinate(lowestPrice);
        const highX = this.chart.timeScale().timeToCoordinate(highestTime);
        const lowX = this.chart.timeScale().timeToCoordinate(lowestTime);

        if (highY === null || lowY === null || highX === null || lowX === null) return;

        // 최고가 표시 (빨간색)
        this.drawHighLowMarker(ctx, highX, highY, highestPrice, '#ef4444', true, cssWidth);

        // 최저가 표시 (파란색)
        this.drawHighLowMarker(ctx, lowX, lowY, lowestPrice, '#3b82f6', false, cssWidth);
    }

    /**
     * 최고가/최저가 마커 그리기
     */
    drawHighLowMarker(ctx, x, y, price, color, isHigh, canvasWidth) {
        const priceText = price.toLocaleString();
        ctx.font = 'bold 11px sans-serif';
        const textWidth = ctx.measureText(priceText).width;

        const arrowLength = 20;
        const boxPadding = 6;
        const boxWidth = textWidth + boxPadding * 2;
        const boxHeight = 18;
        const totalWidth = arrowLength + boxWidth + 5;

        // 오른쪽에 공간이 있으면 오른쪽, 없으면 왼쪽에 표시
        const showOnRight = (x + totalWidth + 30) < canvasWidth;

        if (showOnRight) {
            const arrowStartX = x + 8;
            const arrowEndX = arrowStartX + arrowLength;
            const boxX = arrowEndX + 3;

            // 화살표 선
            ctx.strokeStyle = color;
            ctx.lineWidth = 2;
            ctx.beginPath();
            ctx.moveTo(arrowStartX, y);
            ctx.lineTo(arrowEndX, y);
            ctx.stroke();

            // 화살표 머리
            ctx.fillStyle = color;
            ctx.beginPath();
            ctx.moveTo(arrowStartX, y);
            ctx.lineTo(arrowStartX + 6, y - 4);
            ctx.lineTo(arrowStartX + 6, y + 4);
            ctx.closePath();
            ctx.fill();

            // 가격 박스
            ctx.fillStyle = color;
            ctx.beginPath();
            ctx.roundRect(boxX, y - boxHeight / 2, boxWidth, boxHeight, 3);
            ctx.fill();

            // 가격 텍스트
            ctx.fillStyle = '#ffffff';
            ctx.font = 'bold 11px sans-serif';
            ctx.textAlign = 'left';
            ctx.fillText(priceText, boxX + boxPadding, y + 4);
        } else {
            const arrowEndX = x - 8;
            const arrowStartX = arrowEndX - arrowLength;
            const boxX = arrowStartX - boxWidth - 3;

            // 화살표 선
            ctx.strokeStyle = color;
            ctx.lineWidth = 2;
            ctx.beginPath();
            ctx.moveTo(arrowStartX, y);
            ctx.lineTo(arrowEndX, y);
            ctx.stroke();

            // 화살표 머리
            ctx.fillStyle = color;
            ctx.beginPath();
            ctx.moveTo(arrowEndX, y);
            ctx.lineTo(arrowEndX - 6, y - 4);
            ctx.lineTo(arrowEndX - 6, y + 4);
            ctx.closePath();
            ctx.fill();

            // 가격 박스
            ctx.fillStyle = color;
            ctx.beginPath();
            ctx.roundRect(boxX, y - boxHeight / 2, boxWidth, boxHeight, 3);
            ctx.fill();

            // 가격 텍스트
            ctx.fillStyle = '#ffffff';
            ctx.font = 'bold 11px sans-serif';
            ctx.textAlign = 'left';
            ctx.fillText(priceText, boxX + boxPadding, y + 4);
        }
    }

    /**
     * 상단 범례/정보 오버레이 생성
     */
    createLegendOverlay() {
        // 기존 오버레이 제거
        const existingOverlay = this.container.querySelector('.chart-legend-overlay');
        if (existingOverlay) {
            existingOverlay.remove();
        }

        // 오버레이 컨테이너 생성
        const overlay = document.createElement('div');
        overlay.className = 'chart-legend-overlay';
        overlay.style.cssText = `
            position: absolute;
            top: 8px;
            left: 12px;
            z-index: 100;
            pointer-events: none;
            font-family: 'Noto Sans KR', sans-serif;
        `;

        // 종목명/코드 표시 영역
        const stockInfo = document.createElement('div');
        stockInfo.className = 'legend-stock-info';
        stockInfo.style.cssText = `
            font-size: 14px;
            font-weight: 600;
            color: #1f2937;
            margin-bottom: 4px;
        `;
        stockInfo.innerHTML = `
            <span class="legend-stock-name">${this.currentName || ''}</span>
            <span class="legend-stock-code" style="color: #6b7280; font-weight: 400; margin-left: 6px;">${this.currentCode || ''}</span>
        `;
        overlay.appendChild(stockInfo);

        // OHLCV 정보 표시 영역
        const ohlcvInfo = document.createElement('div');
        ohlcvInfo.className = 'legend-ohlcv-info';
        ohlcvInfo.style.cssText = `
            font-size: 12px;
            color: #374151;
            display: flex;
            gap: 12px;
            flex-wrap: wrap;
        `;
        ohlcvInfo.innerHTML = `
            <span>시 <span class="legend-open" style="font-weight: 500;">-</span></span>
            <span>고 <span class="legend-high" style="color: #ef4444; font-weight: 500;">-</span></span>
            <span>저 <span class="legend-low" style="color: #3b82f6; font-weight: 500;">-</span></span>
            <span>종 <span class="legend-close" style="font-weight: 500;">-</span></span>
            <span>거래량 <span class="legend-volume" style="font-weight: 500;">-</span></span>
        `;
        overlay.appendChild(ohlcvInfo);

        // 컨테이너에 추가
        this.container.style.position = 'relative';
        this.container.appendChild(overlay);

        // 오버레이 참조 저장
        this.legendOverlay = overlay;
    }

    /**
     * 크로스헤어 이동 시 OHLCV 업데이트
     */
    setupCrosshairMove(data) {
        if (!this.chart || !this.candlestickSeries) return;

        this.chart.subscribeCrosshairMove((param) => {
            if (!this.legendOverlay) return;

            const ohlcvEl = this.legendOverlay.querySelector('.legend-ohlcv-info');
            if (!ohlcvEl) return;

            // 차트 영역 밖이면 마지막 데이터 표시
            if (!param.time || !param.point) {
                this.updateLegendWithLastData(data);
                return;
            }

            // 크로스헤어 위치의 데이터 가져오기
            const candleData = param.seriesData.get(this.candlestickSeries);
            const volumeData = this.volumeSeries ? param.seriesData.get(this.volumeSeries) : null;

            if (candleData) {
                const open = candleData.open;
                const high = candleData.high;
                const low = candleData.low;
                const close = candleData.close;
                const volume = volumeData ? volumeData.value : 0;

                // 등락 색상 결정
                const changeColor = close >= open ? '#ef4444' : '#3b82f6';

                ohlcvEl.innerHTML = `
                    <span>시 <span class="legend-open" style="font-weight: 500;">${open.toLocaleString()}</span></span>
                    <span>고 <span class="legend-high" style="color: #ef4444; font-weight: 500;">${high.toLocaleString()}</span></span>
                    <span>저 <span class="legend-low" style="color: #3b82f6; font-weight: 500;">${low.toLocaleString()}</span></span>
                    <span>종 <span class="legend-close" style="color: ${changeColor}; font-weight: 500;">${close.toLocaleString()}</span></span>
                    <span>거래량 <span class="legend-volume" style="font-weight: 500;">${this.formatVolume(volume)}</span></span>
                `;
            }
        });

        // 초기에 마지막 데이터로 표시
        this.updateLegendWithLastData(data);
    }

    /**
     * 범례를 마지막 데이터로 업데이트
     */
    updateLegendWithLastData(data) {
        if (!this.legendOverlay || !data.candlestick || data.candlestick.length === 0) return;

        const ohlcvEl = this.legendOverlay.querySelector('.legend-ohlcv-info');
        if (!ohlcvEl) return;

        const lastCandle = data.candlestick[data.candlestick.length - 1];
        const lastVolume = data.volume && data.volume.length > 0
            ? data.volume[data.volume.length - 1].value
            : 0;

        const open = lastCandle.open;
        const high = lastCandle.high;
        const low = lastCandle.low;
        const close = lastCandle.close;
        const changeColor = close >= open ? '#ef4444' : '#3b82f6';

        ohlcvEl.innerHTML = `
            <span>시 <span class="legend-open" style="font-weight: 500;">${open.toLocaleString()}</span></span>
            <span>고 <span class="legend-high" style="color: #ef4444; font-weight: 500;">${high.toLocaleString()}</span></span>
            <span>저 <span class="legend-low" style="color: #3b82f6; font-weight: 500;">${low.toLocaleString()}</span></span>
            <span>종 <span class="legend-close" style="color: ${changeColor}; font-weight: 500;">${close.toLocaleString()}</span></span>
            <span>거래량 <span class="legend-volume" style="font-weight: 500;">${this.formatVolume(lastVolume)}</span></span>
        `;
    }

    /**
     * 거래량 포맷팅 (억/만 단위)
     */
    formatVolume(volume) {
        if (volume >= 100000000) {
            return (volume / 100000000).toFixed(1) + '억';
        } else if (volume >= 10000) {
            return (volume / 10000).toFixed(0) + '만';
        } else {
            return volume.toLocaleString();
        }
    }

    // ============================================================
    // 스크롤바
    // ============================================================

    /**
     * 스크롤바 초기화
     */
    initScrollbar(totalBars) {
        // 기존 스크롤바 제거
        if (this.scrollbar.container) {
            this.scrollbar.container.remove();
        }

        this.totalBars = totalBars;

        // 스크롤바 컨테이너
        const scrollbarContainer = document.createElement('div');
        scrollbarContainer.className = 'chart-scrollbar';
        scrollbarContainer.style.cssText = `
            width: 100%;
            height: 16px;
            background: #f0f0f0;
            border-radius: 8px;
            position: relative;
            margin-top: 4px;
            cursor: pointer;
        `;

        // 스크롤바 썸 (드래그 핸들)
        const scrollThumb = document.createElement('div');
        scrollThumb.className = 'chart-scroll-thumb';
        scrollThumb.style.cssText = `
            height: 12px;
            background: #a0a0a0;
            border-radius: 6px;
            position: absolute;
            top: 2px;
            cursor: grab;
            min-width: 40px;
            transition: background 0.15s;
        `;

        scrollbarContainer.appendChild(scrollThumb);

        // 차트 컨테이너 다음에 스크롤바 추가
        this.container.parentNode.insertBefore(scrollbarContainer, this.container.nextSibling);

        this.scrollbar.container = scrollbarContainer;
        this.scrollbar.thumb = scrollThumb;

        // 스크롤바 업데이트 함수
        const updateScrollbar = () => {
            const timeScale = this.chart.timeScale();
            const visibleRange = timeScale.getVisibleLogicalRange();
            if (!visibleRange) return;

            const visibleBars = visibleRange.to - visibleRange.from;
            const scrollbarWidth = scrollbarContainer.offsetWidth;

            // 썸 크기 계산 (최소 40px)
            const thumbWidth = Math.max(40, (visibleBars / this.totalBars) * scrollbarWidth);
            scrollThumb.style.width = `${thumbWidth}px`;

            // 썸 위치 계산
            const scrollableWidth = scrollbarWidth - thumbWidth;
            const scrollPosition = (visibleRange.from / (this.totalBars - visibleBars)) * scrollableWidth;
            scrollThumb.style.left = `${Math.max(0, Math.min(scrollableWidth, scrollPosition))}px`;
        };

        // 차트 범위 변경 시 스크롤바 업데이트
        this.chart.timeScale().subscribeVisibleLogicalRangeChange(updateScrollbar);

        // 초기 스크롤바 설정
        setTimeout(updateScrollbar, 100);

        // 스크롤바 드래그 이벤트
        scrollThumb.addEventListener('mousedown', (e) => {
            this.scrollbar.isDragging = true;
            this.scrollbar.startX = e.clientX;
            this.scrollbar.startLeft = parseFloat(scrollThumb.style.left) || 0;
            scrollThumb.style.cursor = 'grabbing';
            scrollThumb.style.background = '#808080';
            e.preventDefault();
        });

        document.addEventListener('mousemove', (e) => {
            if (!this.scrollbar.isDragging) return;

            const deltaX = e.clientX - this.scrollbar.startX;
            const scrollbarWidth = scrollbarContainer.offsetWidth;
            const thumbWidth = scrollThumb.offsetWidth;
            const scrollableWidth = scrollbarWidth - thumbWidth;

            let newLeft = this.scrollbar.startLeft + deltaX;
            newLeft = Math.max(0, Math.min(scrollableWidth, newLeft));
            scrollThumb.style.left = `${newLeft}px`;

            // 차트 범위 업데이트
            const visibleRange = this.chart.timeScale().getVisibleLogicalRange();
            if (!visibleRange) return;

            const visibleBars = visibleRange.to - visibleRange.from;
            const scrollRatio = newLeft / scrollableWidth;
            const newFrom = scrollRatio * (this.totalBars - visibleBars);

            this.chart.timeScale().setVisibleLogicalRange({
                from: newFrom,
                to: newFrom + visibleBars
            });
        });

        document.addEventListener('mouseup', () => {
            if (this.scrollbar.isDragging) {
                this.scrollbar.isDragging = false;
                scrollThumb.style.cursor = 'grab';
                scrollThumb.style.background = '#a0a0a0';
            }
        });

        // 스크롤바 트랙 클릭 (점프)
        scrollbarContainer.addEventListener('click', (e) => {
            if (e.target === scrollThumb) return;

            const rect = scrollbarContainer.getBoundingClientRect();
            const clickX = e.clientX - rect.left;
            const thumbWidth = scrollThumb.offsetWidth;
            const scrollbarWidth = scrollbarContainer.offsetWidth;
            const scrollableWidth = scrollbarWidth - thumbWidth;

            const visibleRange = this.chart.timeScale().getVisibleLogicalRange();
            if (!visibleRange) return;

            const visibleBars = visibleRange.to - visibleRange.from;

            // 클릭 위치로 썸 중앙 이동
            let newLeft = clickX - thumbWidth / 2;
            newLeft = Math.max(0, Math.min(scrollableWidth, newLeft));

            const scrollRatio = newLeft / scrollableWidth;
            const newFrom = scrollRatio * (this.totalBars - visibleBars);

            this.chart.timeScale().setVisibleLogicalRange({
                from: newFrom,
                to: newFrom + visibleBars
            });
        });

        // 호버 효과
        scrollThumb.addEventListener('mouseenter', () => {
            if (!this.scrollbar.isDragging) {
                scrollThumb.style.background = '#909090';
            }
        });
        scrollThumb.addEventListener('mouseleave', () => {
            if (!this.scrollbar.isDragging) {
                scrollThumb.style.background = '#a0a0a0';
            }
        });
    }

    // ============================================================
    // 드로잉 도구
    // ============================================================

    /**
     * 드로잉 캔버스 초기화
     */
    initDrawingCanvas() {
        // 기존 캔버스 제거
        if (this.drawing.canvas) {
            this.drawing.canvas.remove();
        }

        // 캔버스 생성
        const canvas = document.createElement('canvas');
        canvas.className = 'drawing-canvas';
        canvas.style.cssText = `
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            pointer-events: none;
            z-index: 10;
        `;
        canvas.width = this.container.clientWidth;
        canvas.height = this.container.clientHeight;

        this.container.appendChild(canvas);
        this.drawing.canvas = canvas;
        this.drawing.ctx = canvas.getContext('2d');

        // 드로잉 이벤트 설정
        this.setupDrawingEvents();
    }

    /**
     * 드로잉 이벤트 설정
     */
    setupDrawingEvents() {
        // 마우스 다운
        this.container.addEventListener('mousedown', (e) => {
            if (!this.drawing.tool || e.button !== 0) return;
            if (this.dragZoom.isDragging) return;

            const rect = this.container.getBoundingClientRect();
            const x = e.clientX - rect.left;
            const y = e.clientY - rect.top;

            // 좌표를 시간/가격으로 변환
            const timeScale = this.chart.timeScale();
            const time = timeScale.coordinateToTime(x);
            let price = this.candlestickSeries.coordinateToPrice(y);

            if (!time || !price) return;

            // 수평선: 자석 기능 적용된 가격으로 고정 (고점)
            if (this.drawing.tool === 'hline') {
                const snappedPrice = this.getSnappedPriceByX(x, 'high');
                if (snappedPrice !== null) {
                    this.addHorizontalLine(snappedPrice);
                }
                this.clearTemporaryDrawing();
                e.preventDefault();
                e.stopPropagation();
                return;
            }

            // 4등분선: 드래그 구간의 최저~최고점으로 설정
            if (this.drawing.tool === 'quad') {
                const startTime = this.getClosestCandleTime(x);
                if (startTime !== null) {
                    this.drawing.startPoint = { time: startTime, x, y };
                    this.drawing.isDrawing = true;
                }
                e.preventDefault();
                e.stopPropagation();
                return;
            }

            this.drawing.isDrawing = true;
            this.drawing.startPoint = { time, price, x, y };

            e.preventDefault();
            e.stopPropagation();
        });

        // 마우스 이동
        this.container.addEventListener('mousemove', (e) => {
            if (!this.drawing.tool) return;

            const rect = this.container.getBoundingClientRect();
            const x = e.clientX - rect.left;
            const y = e.clientY - rect.top;

            // 수평선 도구: 마우스 따라다니며 미리보기 (고점 자석)
            if (this.drawing.tool === 'hline') {
                const snappedPrice = this.getSnappedPriceByX(x, 'high');
                if (snappedPrice !== null) {
                    this.drawHlinePreview(snappedPrice);
                }
                return;
            }

            // 4등분선 도구: 미리보기
            if (this.drawing.tool === 'quad') {
                if (!this.drawing.startPoint) {
                    // 첫 클릭 전: 현재 위치 표시만
                    this.clearTemporaryDrawing();
                } else {
                    // 드래그 중: 구간 내 최저~최고점 범위 미리보기
                    const endTime = this.getClosestCandleTime(x);
                    if (endTime !== null) {
                        const minMax = this.getRangeMinMax(this.drawing.startPoint.time, endTime);
                        if (minMax) {
                            this.drawQuadPreview(minMax.low, minMax.high);
                        }
                    }
                }
                return;
            }

            // 다른 도구: 드래그 중에만 임시 그리기
            if (!this.drawing.isDrawing || !this.drawing.startPoint) return;
            this.drawTemporary(x, y);
        });

        // 마우스 업
        this.container.addEventListener('mouseup', (e) => {
            if (!this.drawing.isDrawing || !this.drawing.startPoint) return;
            if (this.drawing.tool === 'hline') return;

            const rect = this.container.getBoundingClientRect();
            const x = e.clientX - rect.left;
            const y = e.clientY - rect.top;

            const timeScale = this.chart.timeScale();
            const endTime = timeScale.coordinateToTime(x);
            const endPrice = this.candlestickSeries.coordinateToPrice(y);

            // 4등분선: 드래그 구간의 최저~최고점으로 추가
            if (this.drawing.tool === 'quad') {
                const endTime = this.getClosestCandleTime(x);
                if (endTime !== null) {
                    const minMax = this.getRangeMinMax(this.drawing.startPoint.time, endTime);
                    if (minMax && minMax.high > minMax.low) {
                        this.addQuadLines(minMax.low, minMax.high);
                    }
                }
                this.clearTemporaryDrawing();
                this.drawing.isDrawing = false;
                this.drawing.startPoint = null;
                return;
            }

            if (endTime && endPrice) {
                if (this.drawing.tool === 'trendline') {
                    this.addTrendLine(this.drawing.startPoint.time, this.drawing.startPoint.price, endTime, endPrice);
                } else if (this.drawing.tool === 'rect') {
                    this.addRectangle(this.drawing.startPoint.time, this.drawing.startPoint.price, endTime, endPrice);
                }
            }

            // 임시 그림 지우기
            this.clearTemporaryDrawing();

            this.drawing.isDrawing = false;
            this.drawing.startPoint = null;
        });

        // 마우스가 컨테이너를 벗어날 때 미리보기 제거
        this.container.addEventListener('mouseleave', () => {
            if (this.drawing.tool === 'hline' || this.drawing.tool === 'quad') {
                this.clearTemporaryDrawing();
            }
        });

        // Ctrl+Z 단축키
        document.addEventListener('keydown', (e) => {
            if (e.ctrlKey && e.key === 'z') {
                e.preventDefault();
                this.undoDrawing();
            }
            // ESC로 드로잉 모드 해제
            if (e.key === 'Escape') {
                this.setDrawingTool(null);
            }
        });
    }

    /**
     * 마우스 X 좌표에서 가장 가까운 캔들의 고점/저점 반환 (자석 기능)
     */
    getSnappedPriceByX(mouseX, snapTo = 'high') {
        if (!this.chartData?.candlestick || this.chartData.candlestick.length === 0) return null;

        const timeScale = this.chart.timeScale();

        // X 좌표로 가장 가까운 캔들 찾기
        let closestCandle = null;
        let closestDist = Infinity;

        for (const c of this.chartData.candlestick) {
            const cx = timeScale.timeToCoordinate(c.time);
            if (cx === null) continue;

            const dist = Math.abs(cx - mouseX);
            if (dist < closestDist) {
                closestDist = dist;
                closestCandle = c;
            }
        }

        // 가장 가까운 캔들의 지정된 가격 반환
        if (closestCandle) {
            return snapTo === 'low' ? closestCandle.low : closestCandle.high;
        }
        return null;
    }

    /**
     * 수평선 미리보기 그리기
     */
    drawHlinePreview(price) {
        if (!this.drawing.ctx) return;

        const ctx = this.drawing.ctx;
        const canvas = this.drawing.canvas;

        // 캔버스 클리어
        ctx.clearRect(0, 0, canvas.width, canvas.height);

        // 가격을 Y 좌표로 변환
        const y = this.candlestickSeries.priceToCoordinate(price);
        if (y === null) return;

        // 점선 수평선 그리기
        ctx.strokeStyle = '#000000';
        ctx.lineWidth = 2;
        ctx.setLineDash([5, 5]);
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(canvas.width, y);
        ctx.stroke();
        ctx.setLineDash([]);

        // 가격 레이블 표시
        ctx.fillStyle = '#000000';
        ctx.font = '12px sans-serif';
        ctx.textAlign = 'right';
        ctx.fillText(price.toLocaleString() + '원', canvas.width - 10, y - 5);
    }

    /**
     * 임시 그리기 (마우스 이동 중)
     */
    drawTemporary(endX, endY) {
        if (!this.drawing.ctx || !this.drawing.startPoint) return;

        const ctx = this.drawing.ctx;
        const start = this.drawing.startPoint;

        // 캔버스 클리어
        ctx.clearRect(0, 0, this.drawing.canvas.width, this.drawing.canvas.height);

        ctx.strokeStyle = '#667eea';
        ctx.lineWidth = 2;
        ctx.setLineDash([5, 5]);

        if (this.drawing.tool === 'trendline') {
            ctx.beginPath();
            ctx.moveTo(start.x, start.y);
            ctx.lineTo(endX, endY);
            ctx.stroke();
        } else if (this.drawing.tool === 'rect') {
            ctx.strokeRect(start.x, start.y, endX - start.x, endY - start.y);
        }
    }

    /**
     * 임시 그림 지우기
     */
    clearTemporaryDrawing() {
        if (this.drawing.ctx) {
            this.drawing.ctx.clearRect(0, 0, this.drawing.canvas.width, this.drawing.canvas.height);
        }
    }

    /**
     * 수평선 추가
     */
    addHorizontalLine(price) {
        const line = this.chart.addLineSeries({
            color: '#000000',
            lineWidth: 2,
            lineStyle: 0,  // Solid
            priceLineVisible: true,
            lastValueVisible: true,
            crosshairMarkerVisible: false,
            priceLineWidth: 1,
            priceLineColor: '#000000',
            priceLineStyle: 2,  // Dashed
        });

        // 전체 시간 범위에 걸쳐 수평선 그리기
        const data = this.chartData.candlestick;
        if (data.length > 0) {
            line.setData([
                { time: data[0].time, value: price },
                { time: data[data.length - 1].time, value: price }
            ]);
        }

        const drawingObj = { type: 'hline', series: line, price };
        this.drawing.objects.push(drawingObj);
        this.drawing.history.push({ action: 'add', object: drawingObj });

        console.log(`[Drawing] 수평선 추가: ${price.toLocaleString()}원`);
    }

    /**
     * 추세선 추가
     */
    addTrendLine(startTime, startPrice, endTime, endPrice) {
        const line = this.chart.addLineSeries({
            color: '#667eea',
            lineWidth: 2,
            lineStyle: 0,
            priceLineVisible: false,
            lastValueVisible: false,
            crosshairMarkerVisible: false,
        });

        line.setData([
            { time: startTime, value: startPrice },
            { time: endTime, value: endPrice }
        ]);

        const drawingObj = { type: 'trendline', series: line, startTime, startPrice, endTime, endPrice };
        this.drawing.objects.push(drawingObj);
        this.drawing.history.push({ action: 'add', object: drawingObj });

        console.log(`[Drawing] 추세선 추가: ${startPrice.toLocaleString()} → ${endPrice.toLocaleString()}`);
    }

    /**
     * 사각형 추가 (영역 시리즈로 구현 + 세로선 캔버스)
     */
    addRectangle(startTime, startPrice, endTime, endPrice) {
        // 시간/가격 정렬
        const [t1, t2] = startTime < endTime ? [startTime, endTime] : [endTime, startTime];
        const [p1, p2] = startPrice < endPrice ? [startPrice, endPrice] : [endPrice, startPrice];

        // 사각형 ID 생성
        const rectId = Date.now();

        // 상단 라인
        const topLine = this.chart.addLineSeries({
            color: '#667eea',
            lineWidth: 2,
            lineStyle: 0,
            priceLineVisible: false,
            lastValueVisible: false,
            crosshairMarkerVisible: false,
        });
        topLine.setData([
            { time: t1, value: p2 },
            { time: t2, value: p2 }
        ]);

        // 하단 라인
        const bottomLine = this.chart.addLineSeries({
            color: '#667eea',
            lineWidth: 2,
            lineStyle: 0,
            priceLineVisible: false,
            lastValueVisible: false,
            crosshairMarkerVisible: false,
        });
        bottomLine.setData([
            { time: t1, value: p1 },
            { time: t2, value: p1 }
        ]);

        // 세로선 캔버스 생성
        const verticalCanvas = this.createRectVerticalLines(t1, t2, p2, p1, rectId);

        const drawingObj = {
            type: 'rect',
            id: rectId,
            series: [topLine, bottomLine],
            verticalCanvas: verticalCanvas,
            startTime: t1, startPrice: p2, endTime: t2, endPrice: p1
        };
        this.drawing.objects.push(drawingObj);
        this.drawing.history.push({ action: 'add', object: drawingObj });

        console.log(`[Drawing] 사각형 추가: ${p1.toLocaleString()} ~ ${p2.toLocaleString()}`);
    }

    /**
     * 사각형 세로선 캔버스 생성 및 그리기
     */
    createRectVerticalLines(timeStart, timeEnd, topPrice, bottomPrice, rectId) {
        // 세로선 전용 캔버스 생성
        const canvas = document.createElement('canvas');
        canvas.className = `rect-vertical-canvas-${rectId}`;
        canvas.style.cssText = `
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            pointer-events: none;
            z-index: 5;
        `;
        canvas.width = this.container.clientWidth;
        canvas.height = this.container.clientHeight;
        this.container.appendChild(canvas);

        // 세로선 그리기
        this.drawRectVerticalLines(canvas, timeStart, timeEnd, topPrice, bottomPrice);

        // 차트 스크롤/줌 시 세로선 위치 업데이트
        const updateHandler = () => {
            this.drawRectVerticalLines(canvas, timeStart, timeEnd, topPrice, bottomPrice);
        };

        this.chart.timeScale().subscribeVisibleLogicalRangeChange(updateHandler);

        // 핸들러 참조 저장 (나중에 제거용)
        canvas._updateHandler = updateHandler;

        return canvas;
    }

    /**
     * 사각형 세로선 실제 그리기
     */
    drawRectVerticalLines(canvas, timeStart, timeEnd, topPrice, bottomPrice) {
        const ctx = canvas.getContext('2d');
        ctx.clearRect(0, 0, canvas.width, canvas.height);

        const timeScale = this.chart.timeScale();

        // 시간을 X 좌표로 변환
        const x1 = timeScale.timeToCoordinate(timeStart);
        const x2 = timeScale.timeToCoordinate(timeEnd);

        // 가격을 Y 좌표로 변환
        const y1 = this.candlestickSeries.priceToCoordinate(topPrice);
        const y2 = this.candlestickSeries.priceToCoordinate(bottomPrice);

        if (x1 === null || x2 === null || y1 === null || y2 === null) return;

        ctx.strokeStyle = '#667eea';
        ctx.lineWidth = 2;
        ctx.setLineDash([]);

        // 왼쪽 세로선
        ctx.beginPath();
        ctx.moveTo(x1, y1);
        ctx.lineTo(x1, y2);
        ctx.stroke();

        // 오른쪽 세로선
        ctx.beginPath();
        ctx.moveTo(x2, y1);
        ctx.lineTo(x2, y2);
        ctx.stroke();
    }

    /**
     * 마우스 X 좌표에서 가장 가까운 캔들의 time 반환
     */
    getClosestCandleTime(mouseX) {
        if (!this.chartData?.candlestick || this.chartData.candlestick.length === 0) return null;

        const timeScale = this.chart.timeScale();
        let closestCandle = null;
        let closestDist = Infinity;

        for (const c of this.chartData.candlestick) {
            const cx = timeScale.timeToCoordinate(c.time);
            if (cx === null) continue;

            const dist = Math.abs(cx - mouseX);
            if (dist < closestDist) {
                closestDist = dist;
                closestCandle = c;
            }
        }

        return closestCandle ? closestCandle.time : null;
    }

    /**
     * 두 시간 구간 사이의 캔들들 중 최저점/최고점 찾기
     */
    getRangeMinMax(startTime, endTime) {
        if (!this.chartData?.candlestick || this.chartData.candlestick.length === 0) return null;

        // 시간 순서 정렬
        const [t1, t2] = startTime < endTime ? [startTime, endTime] : [endTime, startTime];

        // 구간 내 캔들 필터링
        const candlesInRange = this.chartData.candlestick.filter(c => c.time >= t1 && c.time <= t2);

        if (candlesInRange.length === 0) return null;

        // 최저/최고 찾기
        let minLow = Infinity;
        let maxHigh = -Infinity;

        for (const c of candlesInRange) {
            if (c.low < minLow) minLow = c.low;
            if (c.high > maxHigh) maxHigh = c.high;
        }

        return { low: minLow, high: maxHigh };
    }

    /**
     * 4등분선 미리보기 그리기
     */
    drawQuadPreview(lowPrice, highPrice) {
        if (!this.drawing.ctx) return;

        const ctx = this.drawing.ctx;
        const canvas = this.drawing.canvas;

        // 캔버스 클리어
        ctx.clearRect(0, 0, canvas.width, canvas.height);

        const range = highPrice - lowPrice;
        const prices = [
            lowPrice,                    // 0% (저점)
            lowPrice + range * 0.25,     // 25% (무릎선)
            lowPrice + range * 0.5,      // 50%
            lowPrice + range * 0.75,     // 75%
            highPrice                    // 100% (고점)
        ];
        const colors = ['#000000', '#DAA520', '#000000', '#000000', '#000000'];

        ctx.lineWidth = 1;
        ctx.setLineDash([5, 5]);

        prices.forEach((price, i) => {
            const y = this.candlestickSeries.priceToCoordinate(price);
            if (y === null) return;

            ctx.strokeStyle = colors[i];
            ctx.beginPath();
            ctx.moveTo(0, y);
            ctx.lineTo(canvas.width, y);
            ctx.stroke();
        });

        ctx.setLineDash([]);
    }

    /**
     * 4등분선 추가 (저점~고점 사이 5개 수평선)
     * - 가는 검은색 실선으로 통일
     * - 25% 선 (무릎선)만 황금색
     * - 가격은 좌측에 캔버스로 표시
     */
    addQuadLines(lowPrice, highPrice) {
        const range = highPrice - lowPrice;
        const prices = [
            lowPrice,                    // 0% (저점)
            lowPrice + range * 0.25,     // 25% (무릎선 - 황금색)
            lowPrice + range * 0.5,      // 50%
            lowPrice + range * 0.75,     // 75%
            highPrice                    // 100% (고점)
        ];
        const labels = ['0%', '25%', '50%', '75%', '100%'];
        const colors = ['#000000', '#DAA520', '#000000', '#000000', '#000000'];
        const series = [];

        const data = this.chartData.candlestick;
        if (data.length === 0) return;

        prices.forEach((price, i) => {
            const lineColor = colors[i];
            const line = this.chart.addLineSeries({
                color: lineColor,
                lineWidth: 1,
                lineStyle: 0,
                priceLineVisible: false,
                lastValueVisible: false,
                crosshairMarkerVisible: false,
            });

            line.setData([
                { time: data[0].time, value: price },
                { time: data[data.length - 1].time, value: price }
            ]);

            series.push(line);
        });

        // 좌측 가격 레이블용 캔버스 생성
        const quadId = Date.now();
        const labelCanvas = this.createQuadLabelCanvas(prices, labels, colors, quadId);

        const drawingObj = {
            type: 'quad',
            series: series,
            labelCanvas: labelCanvas,
            lowPrice,
            highPrice,
            prices,
            labels,
            colors
        };
        this.drawing.objects.push(drawingObj);
        this.drawing.history.push({ action: 'add', object: drawingObj });

        console.log(`[Drawing] 4등분선 추가: ${lowPrice.toLocaleString()} ~ ${highPrice.toLocaleString()}`);
    }

    /**
     * 4등분선 좌측 가격 레이블 캔버스 생성
     */
    createQuadLabelCanvas(prices, labels, colors, quadId) {
        const canvas = document.createElement('canvas');
        canvas.className = `quad-label-canvas-${quadId}`;
        canvas.style.cssText = `
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            pointer-events: none;
            z-index: 6;
        `;
        canvas.width = this.container.clientWidth;
        canvas.height = this.container.clientHeight;
        this.container.appendChild(canvas);

        // 레이블 그리기
        this.drawQuadLabels(canvas, prices, labels, colors);

        // 차트 스크롤/줌 시 레이블 위치 업데이트
        const updateHandler = () => {
            this.drawQuadLabels(canvas, prices, labels, colors);
        };

        this.chart.timeScale().subscribeVisibleLogicalRangeChange(updateHandler);
        canvas._updateHandler = updateHandler;

        return canvas;
    }

    /**
     * 4등분선 좌측 가격 레이블 그리기
     */
    drawQuadLabels(canvas, prices, labels, colors) {
        const ctx = canvas.getContext('2d');
        ctx.clearRect(0, 0, canvas.width, canvas.height);

        prices.forEach((price, i) => {
            const y = this.candlestickSeries.priceToCoordinate(price);
            if (y === null) return;

            const text = price.toLocaleString();
            ctx.font = '11px sans-serif';
            const textWidth = ctx.measureText(text).width;

            // 배경 박스
            ctx.fillStyle = colors[i];
            ctx.fillRect(5, y - 10, textWidth + 10, 14);

            // 흰색 텍스트
            ctx.fillStyle = '#ffffff';
            ctx.textAlign = 'left';
            ctx.fillText(text, 10, y + 2);
        });
    }

    // ============================================================
    // 우측 경계 제한
    // ============================================================

    /**
     * 우측 스크롤 경계 제한 설정
     */
    setupRightEdgeLimit() {
        if (!this.chart || !this.chartData?.candlestick) return;

        const totalBars = this.chartData.candlestick.length;
        const maxRightOffset = 3;  // 우측 최대 공백 (캔들 3개)
        const maxTo = totalBars + maxRightOffset;

        // 이전 핸들러 제거 (중복 방지)
        if (this._rightEdgeLimitHandler) {
            this.chart.timeScale().unsubscribeVisibleLogicalRangeChange(this._rightEdgeLimitHandler);
            this._rightEdgeLimitHandler = null;
        }

        // 범위 변경 감지 핸들러
        let isAdjusting = false;  // 재귀 호출 방지 플래그
        this._rightEdgeLimitHandler = () => {
            if (isAdjusting) return;

            const timeScale = this.chart.timeScale();
            const visibleRange = timeScale.getVisibleLogicalRange();
            if (!visibleRange) return;

            // 우측 끝이 제한을 초과했는지 확인
            if (visibleRange.to > maxTo) {
                isAdjusting = true;
                const rangeWidth = visibleRange.to - visibleRange.from;
                const newTo = maxTo;
                let newFrom = newTo - rangeWidth;

                // 좌측 범위 제한 (0 이하 방지)
                if (newFrom < 0) {
                    newFrom = 0;
                }

                timeScale.setVisibleLogicalRange({
                    from: newFrom,
                    to: newTo
                });

                // 다음 프레임에 플래그 해제
                requestAnimationFrame(() => {
                    isAdjusting = false;
                });
            }
        };

        this.chart.timeScale().subscribeVisibleLogicalRangeChange(this._rightEdgeLimitHandler);
        console.log(`[AIQuantChartManager] 우측 끝 제한 설정: maxTo=${maxTo}`);
    }

    // ============================================================
    // 지표 제거 메서드
    // ============================================================

    /**
     * 이동평균선 제거
     */
    removeMA(period) {
        const maKey = `ma${period}`;
        if (this.maSeries[maKey]) {
            this.chart.removeSeries(this.maSeries[maKey]);
            delete this.maSeries[maKey];
        }
    }

    /**
     * 이동평균선 토글
     */
    toggleMA(maKey, enabled) {
        const period = parseInt(maKey.replace('ma', ''));
        if (enabled) {
            if (this.chartData?.candlestick) {
                this.addMA(this.chartData.candlestick, period);
            }
        } else {
            this.removeMA(period);
        }
    }

    /**
     * 볼린저밴드 상단선 제거
     */
    removeBollingerUpperBand() {
        if (this.bollingerUpperSeries) {
            this.chart.removeSeries(this.bollingerUpperSeries);
            this.bollingerUpperSeries = null;
        }
    }

    /**
     * 볼린저밴드 토글
     */
    toggleBollinger(enabled) {
        if (enabled) {
            if (this.chartData?.candlestick) {
                this.addBollingerUpperBand(this.chartData.candlestick);
            }
        } else {
            this.removeBollingerUpperBand();
        }
    }

    /**
     * 일목균형표 기준선 제거
     */
    removeIchimokuKijunsen() {
        if (this.ichimokuSeries.kijunsen) {
            this.chart.removeSeries(this.ichimokuSeries.kijunsen);
            delete this.ichimokuSeries.kijunsen;
        }
    }

    /**
     * 일목균형표 토글
     */
    toggleIchimoku(enabled) {
        if (enabled) {
            if (this.chartData?.candlestick) {
                this.addIchimokuKijunsen(this.chartData.candlestick);
            }
        } else {
            this.removeIchimokuKijunsen();
        }
    }

    /**
     * 드로잉 실행 취소 (Ctrl+Z)
     */
    undoDrawing() {
        if (this.drawing.history.length === 0) return;

        const lastAction = this.drawing.history.pop();
        if (lastAction.action === 'add') {
            const obj = lastAction.object;
            if ((obj.type === 'rect' || obj.type === 'quad') && Array.isArray(obj.series)) {
                obj.series.forEach(s => this.chart.removeSeries(s));
                // 사각형 세로선 캔버스 제거
                if (obj.verticalCanvas) {
                    if (obj.verticalCanvas._updateHandler) {
                        this.chart.timeScale().unsubscribeVisibleLogicalRangeChange(obj.verticalCanvas._updateHandler);
                    }
                    obj.verticalCanvas.remove();
                }
                // 4등분선 라벨 캔버스 제거
                if (obj.labelCanvas) {
                    if (obj.labelCanvas._updateHandler) {
                        this.chart.timeScale().unsubscribeVisibleLogicalRangeChange(obj.labelCanvas._updateHandler);
                    }
                    obj.labelCanvas.remove();
                }
            } else if (obj.series) {
                this.chart.removeSeries(obj.series);
            }
            const idx = this.drawing.objects.indexOf(obj);
            if (idx > -1) {
                this.drawing.objects.splice(idx, 1);
            }
            console.log(`[Drawing] 실행 취소: ${obj.type}`);
        }
    }

    /**
     * 드로잉 도구 설정
     */
    setDrawingTool(tool) {
        this.drawing.tool = tool;
        this.drawing.isDrawing = false;
        this.drawing.startPoint = null;
        this.clearTemporaryDrawing();

        // 커서 스타일 변경
        if (tool) {
            this.container.style.cursor = 'crosshair';
            console.log(`[Drawing] 도구 선택: ${tool}`);
        } else {
            this.container.style.cursor = 'default';
            console.log('[Drawing] 도구 해제');
        }
    }

    /**
     * 드로잉 도구 선택 (버튼 스타일 포함)
     */
    selectDrawingTool(tool, btnElement) {
        // 같은 도구 클릭 시 해제
        if (this.drawing.tool === tool) {
            this.drawing.tool = null;
            this.container.style.cursor = 'default';
            if (btnElement) {
                btnElement.style.background = '#ffffff';
                btnElement.style.borderColor = '#d1d5db';
            }
            return;
        }

        // 다른 도구 버튼들 스타일 초기화
        if (this.drawingButtons) {
            Object.values(this.drawingButtons).forEach(btn => {
                btn.style.background = '#ffffff';
                btn.style.borderColor = '#d1d5db';
            });
        }

        // 선택된 도구 활성화
        this.drawing.tool = tool;
        this.container.style.cursor = 'crosshair';
        if (btnElement) {
            btnElement.style.background = '#dbeafe';
            btnElement.style.borderColor = '#3b82f6';
        }

        console.log(`[Drawing] 도구 선택: ${tool}`);
    }

    /**
     * 모든 드로잉 삭제
     */
    clearAllDrawings() {
        for (const obj of this.drawing.objects) {
            if ((obj.type === 'rect' || obj.type === 'quad') && Array.isArray(obj.series)) {
                obj.series.forEach(s => this.chart.removeSeries(s));
                // 사각형 세로선 캔버스 제거
                if (obj.verticalCanvas) {
                    if (obj.verticalCanvas._updateHandler) {
                        this.chart.timeScale().unsubscribeVisibleLogicalRangeChange(obj.verticalCanvas._updateHandler);
                    }
                    obj.verticalCanvas.remove();
                }
                // 4등분선 라벨 캔버스 제거
                if (obj.labelCanvas) {
                    if (obj.labelCanvas._updateHandler) {
                        this.chart.timeScale().unsubscribeVisibleLogicalRangeChange(obj.labelCanvas._updateHandler);
                    }
                    obj.labelCanvas.remove();
                }
            } else if (obj.series) {
                this.chart.removeSeries(obj.series);
            }
        }
        this.drawing.objects = [];
        this.drawing.history = [];
        console.log('[Drawing] 모든 드로잉 삭제');
    }

    // ============================================================
    // 1. 스크린샷 저장
    // ============================================================

    /**
     * 차트 스크린샷 저장
     */
    takeScreenshot() {
        if (!this.chart) {
            this.showError('차트가 없습니다.');
            return;
        }

        try {
            const canvas = this.chart.takeScreenshot();
            const dataUrl = canvas.toDataURL('image/png');

            const link = document.createElement('a');
            link.download = `chart_${this.currentCode}_${this.currentPeriod}_${Date.now()}.png`;
            link.href = dataUrl;
            link.click();

            console.log('[AIQuantChartManager] 스크린샷 저장 완료');
        } catch (error) {
            console.error('[AIQuantChartManager] 스크린샷 오류:', error);
            this.showError('스크린샷 저장에 실패했습니다.');
        }
    }

    // ============================================================
    // 2. 과거 데이터 추가 로드
    // ============================================================

    /**
     * 과거 데이터 추가 로드 (스페이스 키)
     */
    async loadMoreHistory() {
        if (!this.currentCode || !this.chartData || this.isLoadingMore) {
            return;
        }

        const candlestick = this.chartData.candlestick;
        if (!candlestick || candlestick.length === 0) {
            console.log('[AIQuantChartManager] 로드할 데이터가 없습니다');
            return;
        }

        this.isLoadingMore = true;
        console.log('[AIQuantChartManager] 과거 데이터 추가 로드 시작...');

        try {
            // 현재 데이터 개수 + 600개 더 요청
            const currentCount = candlestick.length;
            const requestCount = currentCount + 600;

            let data;

            // Electron 환경: IPC 사용
            if (this.useIPC && window.electronAPI?.kiwoom) {
                if (this.currentPeriod === 'minute3') {
                    data = await window.electronAPI.kiwoom.minuteChart({
                        stkCd: this.currentCode,
                        interval: 3,
                        count: requestCount
                    });
                } else {
                    data = await window.electronAPI.kiwoom.dailyChart({
                        stkCd: this.currentCode,
                        count: requestCount
                    });
                }
            } else {
                // 브라우저 환경: fetch 사용
                let apiUrl;
                if (this.currentPeriod === 'minute3') {
                    apiUrl = `${this.proxyUrl}/api/chart/minute?code=${this.currentCode}&interval=3&count=${requestCount}`;
                } else {
                    apiUrl = `${this.proxyUrl}/api/chart/${this.currentPeriod}?code=${this.currentCode}&count=${requestCount}`;
                }

                const response = await fetch(apiUrl);
                data = await response.json();
            }

            if (data.success && data.data.candlestick && data.data.candlestick.length > 0) {
                // 기존 데이터보다 이전 데이터만 필터링
                const oldestTime = candlestick[0].time;
                const newCandlestick = data.data.candlestick.filter(c => c.time < oldestTime);
                const newVolume = data.data.volume ? data.data.volume.filter(v => v.time < oldestTime) : [];

                if (newCandlestick.length > 0) {
                    // 기존 데이터 앞에 추가
                    this.chartData.candlestick = [...newCandlestick, ...candlestick];
                    if (this.chartData.volume) {
                        this.chartData.volume = [...newVolume, ...this.chartData.volume];
                    }

                    // 차트 업데이트
                    this.candlestickSeries.setData(this.chartData.candlestick);
                    if (this.volumeSeries && this.chartData.volume) {
                        this.volumeSeries.setData(this.chartData.volume);
                    }

                    // 이동평균선 재계산
                    this.recalculateIndicators();

                    // 분봉 날짜변경선 재계산
                    if (this.dateBoundaryInfo) {
                        if (this._dateBoundaryHandler && this.chart) {
                            try { this.chart.timeScale().unsubscribeVisibleLogicalRangeChange(this._dateBoundaryHandler); } catch(e) {}
                        }
                        this.addDateBoundaryLines(this.chartData.candlestick);
                    }

                    // 최고가/최저가 데이터 업데이트
                    this.visibleHighLow.data = this.chartData.candlestick;

                    // totalBars 업데이트
                    this.totalBars = this.chartData.candlestick.length;

                    console.log(`[AIQuantChartManager] ${newCandlestick.length}개 과거 데이터 추가 완료 (총 ${this.chartData.candlestick.length}개)`);
                } else {
                    console.log('[AIQuantChartManager] 더 이상 과거 데이터가 없습니다');
                }
            } else {
                console.log('[AIQuantChartManager] 추가 데이터 없음');
            }
        } catch (error) {
            console.error('[AIQuantChartManager] 과거 데이터 로드 오류:', error);
        } finally {
            this.isLoadingMore = false;
        }
    }

    /**
     * 지표 재계산 (데이터 추가 후)
     */
    recalculateIndicators() {
        const candlestick = this.chartData.candlestick;
        if (!candlestick || candlestick.length === 0) return;

        // 이동평균선 재계산
        ['ma5', 'ma20', 'ma60', 'ma120', 'ma240'].forEach(ma => {
            if (this.maSeries[ma]) {
                const period = parseInt(ma.replace('ma', ''));
                const maData = this.calculateMA(candlestick, period);
                this.maSeries[ma].setData(maData);
            }
        });

        // 볼린저밴드 재계산
        if (this.bollingerUpperSeries) {
            const bands = this.calculateBollingerBands(candlestick, 20, 2);
            this.bollingerUpperSeries.setData(bands.upper);
        }

        // 일목균형표 재계산
        if (this.ichimokuSeries.kijunsen) {
            const kijunData = this.calculateIchimokuKijunsen(candlestick, 26);
            this.ichimokuSeries.kijunsen.setData(kijunData);
        }

        console.log('[AIQuantChartManager] 지표 재계산 완료');
    }

    // ============================================================
    // 3. 로딩 스피너 표시
    // ============================================================

    /**
     * 로딩 표시
     */
    showLoading() {
        this.container.innerHTML = `
            <div class="chart-loading" style="
                display: flex;
                flex-direction: column;
                align-items: center;
                justify-content: center;
                height: 100%;
                color: #666;
                font-size: 14px;
            ">
                <div style="
                    width: 40px;
                    height: 40px;
                    border: 3px solid #e0e0e0;
                    border-top: 3px solid #3b82f6;
                    border-radius: 50%;
                    animation: spin 1s linear infinite;
                "></div>
                <p style="margin-top: 12px;">차트를 불러오는 중...</p>
            </div>
            <style>
                @keyframes spin {
                    0% { transform: rotate(0deg); }
                    100% { transform: rotate(360deg); }
                }
            </style>
        `;
    }

    // ============================================================
    // 4. 에러 메시지 표시
    // ============================================================

    /**
     * 에러 표시
     */
    showError(message) {
        this.container.innerHTML = `
            <div class="chart-error" style="
                display: flex;
                flex-direction: column;
                align-items: center;
                justify-content: center;
                height: 100%;
                color: #ef4444;
                font-size: 14px;
            ">
                <div style="font-size: 32px; margin-bottom: 8px;">⚠️</div>
                <p>${message}</p>
            </div>
        `;
    }

    // ============================================================
    // 5. 일자 경계선 캔버스 방식
    // ============================================================

    /**
     * 일자 경계선 캔버스 생성
     */
    createDateBoundaryCanvas() {
        // 기존 캔버스 제거
        if (this.dateBoundaryCanvas) {
            this.dateBoundaryCanvas.remove();
        }

        const canvas = document.createElement('canvas');
        canvas.id = 'dateBoundaryCanvas';
        canvas.style.cssText = `
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            pointer-events: none;
            z-index: 5;
        `;

        // 차트 컨테이너에 추가
        this.container.style.position = 'relative';
        this.container.appendChild(canvas);

        // 캔버스 크기 설정
        const rect = this.container.getBoundingClientRect();
        canvas.width = rect.width;
        canvas.height = rect.height;

        this.dateBoundaryCanvas = canvas;
        this.dateBoundaryCtx = canvas.getContext('2d');
    }

    /**
     * 일자 경계선 정보 계산 및 설정
     * @param {Array} candlestickData - 캔들스틱 데이터
     */
    addDateBoundaryLines(candlestickData) {
        if (!candlestickData || candlestickData.length < 2) return;

        // 캔버스 생성
        this.createDateBoundaryCanvas();

        // 일자 경계 찾기 (실제 거래일 기준)
        // 서버에서 KST 시간을 UTC처럼 저장했으므로, 그대로 사용
        // 경계 조건: 전일 마지막 캔들 시간 > 15:00 AND 당일 첫 캔들 시간 < 10:00 (다음 거래일 시작)
        this.dateBoundaryInfo = [];
        for (let i = 1; i < candlestickData.length; i++) {
            const prevTime = new Date(candlestickData[i - 1].time * 1000);
            const currTime = new Date(candlestickData[i].time * 1000);

            const prevHour = prevTime.getUTCHours();
            const currHour = currTime.getUTCHours();

            // 전일: 15시 이후(시간외), 당일: 10시 이전(장 시작) → 실제 날짜 변경
            // 또는 날짜 차이가 1일 이상 (휴일 등)
            const prevDateNum = prevTime.getUTCDate();
            const currDateNum = currTime.getUTCDate();
            const prevMonth = prevTime.getUTCMonth();
            const currMonth = currTime.getUTCMonth();

            const isDifferentDay = (prevDateNum !== currDateNum) || (prevMonth !== currMonth);
            const isMarketClose = prevHour >= 15 && currHour < 10;

            if (isDifferentDay && isMarketClose) {
                this.dateBoundaryInfo.push({
                    prevTimestamp: candlestickData[i - 1].time,
                    firstTimestamp: candlestickData[i].time
                });
            }
        }

        // 초기 렌더링
        this.renderDateBoundaryLines();

        // 스크롤/줌 시 다시 렌더링
        this._dateBoundaryHandler = () => {
            this.renderDateBoundaryLines();
        };
        this.chart.timeScale().subscribeVisibleLogicalRangeChange(this._dateBoundaryHandler);

        // 경계선 정보 디버깅
        this.dateBoundaryInfo.forEach((b, i) => {
            const prevTime = new Date(b.prevTimestamp * 1000).toISOString();
            const firstTime = new Date(b.firstTimestamp * 1000).toISOString();
            console.log(`[경계선 ${i}] 전일마지막: ${prevTime}, 당일첫번째: ${firstTime}`);
        });
        console.log(`[AIQuantChartManager] 일자 경계선 ${this.dateBoundaryInfo.length}개 추가`);
    }

    /**
     * 일자 경계선 렌더링
     */
    renderDateBoundaryLines() {
        if (!this.dateBoundaryCanvas || !this.dateBoundaryCtx || !this.dateBoundaryInfo) {
            return;
        }

        const ctx = this.dateBoundaryCtx;
        const canvas = this.dateBoundaryCanvas;

        // 캔버스 크기 업데이트
        const rect = this.container.getBoundingClientRect();
        if (canvas.width !== rect.width || canvas.height !== rect.height) {
            canvas.width = rect.width;
            canvas.height = rect.height;
        }

        // 캔버스 클리어
        ctx.clearRect(0, 0, canvas.width, canvas.height);

        // 차트 영역 계산
        const chartCanvas = this.container.querySelector('table canvas');
        if (!chartCanvas) return;

        const chartRect = chartCanvas.getBoundingClientRect();
        const containerRect = this.container.getBoundingClientRect();
        const chartLeft = chartRect.left - containerRect.left;
        const chartWidth = chartRect.width;
        const chartHeight = chartRect.height;

        // 경계선 스타일 설정
        ctx.strokeStyle = '#FF0000';
        ctx.lineWidth = 1;
        ctx.setLineDash([]);

        // 각 경계에 대해 수직선 그리기
        for (const boundary of this.dateBoundaryInfo) {
            const x1 = this.chart.timeScale().timeToCoordinate(boundary.prevTimestamp);
            const x2 = this.chart.timeScale().timeToCoordinate(boundary.firstTimestamp);

            if (x1 === null || x2 === null) continue;

            // 두 캔들 사이의 중간 지점
            const x = (x1 + x2) / 2;

            if (x < 0 || x > chartWidth) continue;

            // 수직선 그리기
            ctx.beginPath();
            ctx.moveTo(chartLeft + x, 0);
            ctx.lineTo(chartLeft + x, chartHeight);
            ctx.stroke();
        }
    }

    /**
     * 일자 경계선 제거
     */
    removeDateBoundaryLines() {
        // Canvas 제거
        if (this.dateBoundaryCanvas) {
            this.dateBoundaryCanvas.remove();
            this.dateBoundaryCanvas = null;
            this.dateBoundaryCtx = null;
        }

        // 이벤트 핸들러 제거
        if (this._dateBoundaryHandler && this.chart) {
            try {
                this.chart.timeScale().unsubscribeVisibleLogicalRangeChange(this._dateBoundaryHandler);
            } catch (e) {}
            this._dateBoundaryHandler = null;
        }

        // 경계 정보 초기화
        this.dateBoundaryInfo = null;
    }

    // ============================================================
    // 6. 드래그 줌 이벤트 정리
    // ============================================================

    /**
     * 드래그 줌 이벤트 제거
     */
    removeDragZoomEvents() {
        if (this._boundMouseDown) {
            this.container.removeEventListener('mousedown', this._boundMouseDown);
            this._boundMouseDown = null;
        }
        if (this._boundMouseMove) {
            document.removeEventListener('mousemove', this._boundMouseMove);
            this._boundMouseMove = null;
        }
        if (this._boundMouseUp) {
            document.removeEventListener('mouseup', this._boundMouseUp);
            this._boundMouseUp = null;
        }
        if (this._boundMouseLeave) {
            this.container.removeEventListener('mouseleave', this._boundMouseLeave);
            this._boundMouseLeave = null;
        }
        if (this._boundWheel) {
            this.container.removeEventListener('wheel', this._boundWheel);
            this._boundWheel = null;
        }

        // 오버레이 제거
        if (this.dragZoom.overlay) {
            this.dragZoom.overlay.remove();
            this.dragZoom.overlay = null;
        }

        console.log('[AIQuantChartManager] 드래그 줌 이벤트 제거 완료');
    }

    /**
     * 차트 제거
     */
    destroy() {
        // 드래그 줌 이벤트 제거
        this.removeDragZoomEvents();

        // 일자 경계선 제거
        this.removeDateBoundaryLines();

        if (this.chart) {
            this.chart.remove();
            this.chart = null;
        }
        // 오버레이 제거
        if (this.legendOverlay) {
            this.legendOverlay.remove();
            this.legendOverlay = null;
        }
        // 스크롤바 제거
        if (this.scrollbar.container) {
            this.scrollbar.container.remove();
            this.scrollbar.container = null;
        }
        // 드로잉 캔버스 제거
        if (this.drawing.canvas) {
            this.drawing.canvas.remove();
            this.drawing.canvas = null;
        }
    }
}

// 전역에 노출
window.AIQuantChartManager = AIQuantChartManager;
