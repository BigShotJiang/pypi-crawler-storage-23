# kiwoom-market — 시세/호가/차트 (37개 API)

키움증권 REST API 중 시세 조회, 호가, 차트 데이터를 다루는 도구 모음이다.
모든 API는 KIWOOM_APP_KEY + KIWOOM_SECRET_KEY 환경변수가 필요하다.

> **⚠️ 키움 토큰/연결 공유 정책**: 이 도구들은 REST API이므로 자유롭게 호출 가능. 단, 새 WebSocket 연결을 만들지 말 것. 상세 규칙은 마스터 SKILL.md의 "키움 토큰/연결 공유 정책" 참조.

**Rate Limit**: 실전 20회/s, 모의 2회/s. 429 에러 시 지수 백오프 적용.
**연속조회**: 응답의 cont-yn=Y이면 다음 페이지 존재. next-key를 다음 요청에 전달. 연속조회도 Rate Limit에 합산.
**차트 데이터**: 1회 요청 최대 600개. 이후 next-key로 추가 페이징.

## 기본 호출 패턴

```bash
stockclaw-kit run kiwoom_call_api '{"tr_id":"CODE","inputs":{...}}' 2>/dev/null
```

파라미터를 모르면 먼저 스펙을 확인한다:
```bash
stockclaw-kit run kiwoom_api_spec '{"tr_id":"ka10001"}' 2>/dev/null
```

---

## 종목정보 (stkinfo) — 10개

| API 코드 | 설명 |
|----------|------|
| ka10001 | 주식기본정보 (현재가) |
| ka10003 | 체결 조회 |
| ka10019 | 가격 급등락 |
| ka10095 | 관심종목정보 |
| ka10099 | 종목정보 리스트 |
| ka10100 | 종목정보 조회 |
| ka10101 | 업종코드 리스트 |
| ka10102 | 회원사 리스트 |
| kt20016 | 신용가능 종목 |
| kt20017 | 신용가능 잔고 |

### ka10001 — 주식 현재가 (가장 많이 사용)

```bash
stockclaw-kit run kiwoom_call_api '{"tr_id":"ka10001","inputs":{"종목코드":"005930"}}' 2>/dev/null
```

주요 응답 필드: 현재가, 전일대비, 등락률, 거래량, 시가, 고가, 저가, 시가총액

### ka10003 — 체결 조회

```bash
stockclaw-kit run kiwoom_call_api '{"tr_id":"ka10003","inputs":{"종목코드":"005930"}}' 2>/dev/null
```

---

## 시세/호가 (mrkcond) — 14개

| API 코드 | 설명 |
|----------|------|
| ka10002 | 주식거래원 |
| ka10004 | 호가잔량 |
| ka10005 | 주식 일/주/월/시분 |
| ka10006 | 주식 시분 |
| ka10007 | 시세표성 정보 |
| ka10055 | 당일전일 체결량 |
| ka10084 | 당일전일 체결 |
| ka10086 | 일별주가 |
| ka10087 | 시간외단일가 |
| ka50010 | 금현물 체결추이 |
| ka50012 | 금현물 일별추이 |
| ka50087 | 금현물 예상체결 |
| ka50100 | 금현물 시세정보 |
| ka50101 | 금현물 호가 |

### ka10004 — 호가잔량

```bash
stockclaw-kit run kiwoom_call_api '{"tr_id":"ka10004","inputs":{"종목코드":"005930"}}' 2>/dev/null
```

매도/매수 각 10호가 잔량을 반환한다.

### ka10005 — 주식 일/주/월/시분

```bash
stockclaw-kit run kiwoom_call_api '{"tr_id":"ka10005","inputs":{"종목코드":"005930","기준일자":"20260220","수정주가구분":"1"}}' 2>/dev/null
```

수정주가구분: 1=수정주가 적용, 0=미적용

### ka10087 — 시간외단일가

```bash
stockclaw-kit run kiwoom_call_api '{"tr_id":"ka10087","inputs":{"종목코드":"005930"}}' 2>/dev/null
```

---

## 차트 (chart) — 13개

| API 코드 | 설명 |
|----------|------|
| ka10079 | 틱 차트 |
| ka10080 | 분봉 차트 |
| ka10081 | 일봉 차트 |
| ka10082 | 주봉 차트 |
| ka10083 | 월봉 차트 |
| ka10094 | 년봉 차트 |
| ka50079 | 금현물 틱 차트 |
| ka50080 | 금현물 분봉 차트 |
| ka50081 | 금현물 일봉 차트 |
| ka50082 | 금현물 주봉 차트 |
| ka50083 | 금현물 월봉 차트 |
| ka50091 | 금현물 당일 틱 차트 |
| ka50092 | 금현물 당일 분봉 차트 |

### ka10079 — 틱 차트

```bash
stockclaw-kit run kiwoom_call_api '{"tr_id":"ka10079","inputs":{"종목코드":"005930","틱범위":"3"}}' 2>/dev/null
```

틱범위: 1, 3, 5, 10, 30

### ka10080 — 분봉 차트

```bash
stockclaw-kit run kiwoom_call_api '{"tr_id":"ka10080","inputs":{"종목코드":"005930","틱범위":"5"}}' 2>/dev/null
```

틱범위(분): 1, 3, 5, 10, 15, 30, 45, 60

### ka10081 — 일봉 차트

```bash
stockclaw-kit run kiwoom_call_api '{"tr_id":"ka10081","inputs":{"종목코드":"005930","기준일자":"20260220","수정주가구분":"1"}}' 2>/dev/null
```

수정주가구분: 1=수정주가 적용, 0=미적용

### ka10082 — 주봉 차트

```bash
stockclaw-kit run kiwoom_call_api '{"tr_id":"ka10082","inputs":{"종목코드":"005930","기준일자":"20260220","수정주가구분":"1"}}' 2>/dev/null
```

수정주가구분: 1=수정주가 적용, 0=미적용

### ka10083 — 월봉 차트

```bash
stockclaw-kit run kiwoom_call_api '{"tr_id":"ka10083","inputs":{"종목코드":"005930","기준일자":"20260220","수정주가구분":"1"}}' 2>/dev/null
```

수정주가구분: 1=수정주가 적용, 0=미적용

### ka10094 — 년봉 차트

```bash
stockclaw-kit run kiwoom_call_api '{"tr_id":"ka10094","inputs":{"종목코드":"005930","기준일자":"20260220","수정주가구분":"1"}}' 2>/dev/null
```

수정주가구분: 1=수정주가 적용, 0=미적용

---

## 환경 정보 확인

```bash
stockclaw-kit run kiwoom_get_env_info 2>/dev/null
```

## API 목록 전체 조회

```bash
stockclaw-kit run kiwoom_list_apis 2>/dev/null
```
