# 왜 올라? — 종목 상승 이유 분석

사용자가 특정 종목의 상승/하락 이유를 물으면, 여러 데이터 소스를 조합하여 원인을 분석한다.

## 트리거

- "현대차 왜 올라?"
- "삼성전자 왜 떨어져?"
- "SK하이닉스 상승 이유"
- "엔켐 왜 급등?"
- "오늘 005380 왜 올랐어?"

## 실행 흐름

| 단계 | API 호출 | 목적 |
|------|---------|------|
| 1 | ka-002 (stock=종목코드) | 오늘 매칭된 뉴스 확인 |
| 2 | ka-004 (stock_code=종목코드, topic=stock_reasons, days=60) | 과거 상승/하락 이유 검색 |
| 3 | ka-007 (theme=관련테마) | 해당 종목 소속 테마의 현재 점수 |
| 4 | LLM 종합 | 뉴스+과거패턴+테마 → 원인 답변 |

## CLI 예시

```bash
# 1단계: 오늘 뉴스 매칭 확인
stockclaw-kit run themalab_call '{"api_id":"ka-002","params":{"stock":"005380","limit":10}}' 2>/dev/null

# 2단계: 과거 60거래일 상승 이유 검색
stockclaw-kit run themalab_call '{"api_id":"ka-004","params":{"stock_code":"005380","topic":"stock_reasons","days":60}}' 2>/dev/null

# 3단계: 관련 테마 점수
stockclaw-kit run themalab_call '{"api_id":"ka-007","params":{"top":10}}' 2>/dev/null
```

## 응답 형식

1. 오늘 뉴스에서 확인된 직접 원인 (있으면)
2. 소속 테마의 현재 강도 (테마 점수)
3. 과거 유사 패턴 (있으면)
4. 종합 판단 1~2문장

## 주의사항

- 뉴스 데이터: 제목 + 링크 + AI 요약 제공
- 과거 데이터는 60거래일 기본. 더 긴 기간은 days 파라미터 조정
- 종목코드를 모르면 먼저 종목 검색(kiwoom/pykrx) 후 이 스킬 호출
