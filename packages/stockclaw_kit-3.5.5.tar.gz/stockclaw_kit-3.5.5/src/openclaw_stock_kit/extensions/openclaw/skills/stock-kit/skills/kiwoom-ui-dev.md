# kiwoom-ui-dev — 브라우저 UI 개발 가이드

StockClaw Kit 통합 UI(`stockclaw-kit-ui.html`)에서 키움증권 API를 호출하는 패널을 개발하거나 수정할 때의 필수 규칙과 패턴.

> **이 문서의 대상**: UI HTML/JS 코드를 수정하는 개발자 (CLI 도구 사용법은 `kiwoom-market.md` 등 참조)

---

## 1. callKiwoom() 래퍼 — 유일한 호출 수단

브라우저에서 키움 REST API를 호출할 때는 반드시 `callKiwoom()`을 사용한다.

```javascript
const result = await callKiwoom('themeGroups', { qry_tp: '0', stex_tp: '1' });
```

### 동작 원리

1. **메서드명 → API 코드 변환**: `KIWOOM_METHODS` 맵에서 `themeGroups` → `ka90001` 변환
2. **서버 호출**: `POST /api/kiwoom/call` → 서버가 `{ok: true, data: {...}}` 반환
3. **응답 래핑**: 클라이언트가 `{success: true, data: rawData, ...spreadFields}` 형태로 변환
4. **토큰 자동 갱신**: 인증 오류 감지 시 토큰 재발급 후 자동 재시도

### 응답 접근 패턴

```javascript
// 두 가지 모두 동작 (래퍼가 필드를 스프레딩)
result.data.thema_grp    // 정석
result.thema_grp         // 단축 (스프레딩된 필드)

// 성공 여부 확인
if (result.success) { ... }   // callKiwoom() 래퍼가 변환한 필드
```

### ⚠️ 직접 fetch()와의 차이

| 항목 | `callKiwoom()` | 직접 `fetch('/api/...')` |
|------|---------------|------------------------|
| 성공 필드 | `result.success` | `result.ok` (서버 원본) |
| 데이터 접근 | `result.data.xxx` 또는 `result.xxx` | `result.xxx` (그대로) |
| 토큰 갱신 | 자동 | 수동 처리 필요 |

**실수 사례**: 종토방 API(`/api/naver/forum`)는 직접 fetch하므로 `result.ok`로 체크해야 하는데, `result.success`로 체크하여 데이터가 표시되지 않았음.

---

## 2. 듀얼모드 패턴 (Electron vs Browser)

UI는 Electron 데스크톱 앱과 브라우저 모드 두 가지에서 실행된다. 새 패널을 만들 때 반드시 양쪽 모드를 지원해야 한다.

### 표준 패턴

```javascript
let result;
if (window.electronAPI?.kiwoom?.viStocks) {
    // Electron (IPC) — 데스크톱 앱
    result = await window.electronAPI.kiwoom.viStocks(params);
} else if (typeof callKiwoom === 'function') {
    // Browser (REST) — 웹 브라우저
    result = await callKiwoom('ka10054', params);
} else {
    throw new Error('API 연결 없음');
}
```

### 모드 감지

```javascript
const isElectron = !!window.electronAPI;
const isBrowser = typeof callKiwoom === 'function';
```

---

## 3. 필수 파라미터 함정

### 빈 문자열 금지

키움 API는 빈 문자열(`''`)을 파라미터로 보내면 `return_code: 2` (필수 입력 파라미터 누락) 에러를 반환한다.

```javascript
// ❌ 에러 발생
callKiwoom('ka10054', { min_trde_qty: '', max_trde_qty: '' });

// ✅ 올바른 호출
callKiwoom('ka10054', { min_trde_qty: '0', max_trde_qty: '100000000' });
```

### stex_tp 필수

대부분의 분석/테마/순위 API에서 `stex_tp` (거래소 구분)는 필수 파라미터다. 누락하면 `return_code: 2` 에러.

```javascript
// ❌ stex_tp 누락 → return_code: 2
callKiwoom('themeStocks', { thema_grp_cd: code });

// ✅ stex_tp 포함
callKiwoom('themeStocks', { thema_grp_cd: code, stex_tp: '1' });
```

stex_tp 값: `'1'` = 코스피+코스닥

### 파라미터 확인 방법

모르는 API의 필수 파라미터를 확인하려면:

```bash
stockclaw-kit run kiwoom_api_spec '{"tr_id":"ka90002"}' 2>/dev/null
```

---

## 4. 응답 필드명 불일치

Electron IPC와 REST API가 동일 API를 호출해도 응답 필드명이 다를 수 있다. 반드시 양쪽 필드를 체크한다.

### 알려진 불일치 목록

| API | Electron (IPC) | REST (callKiwoom) | 대응 |
|-----|----------------|-------------------|------|
| ka10054 (VI 발동) | `vi_motn_stk` | `motn_stk` | `data?.vi_motn_stk \|\| data?.motn_stk` |

### 안전한 패턴

```javascript
// 양쪽 필드명 모두 체크
const viStocks = result.data?.vi_motn_stk || result.data?.motn_stk || [];
```

새 API를 연동할 때는 **반드시 양쪽 모드에서 실제 응답을 확인**하고, 필드명이 다르면 fallback 패턴을 적용한다.

---

## 5. KIWOOM_METHODS 매핑 참조

`callKiwoom()`의 첫 번째 인자에 사용할 수 있는 메서드명 → API 코드 매핑:

| 메서드명 | API 코드 | 설명 |
|----------|---------|------|
| `stockInfo` | ka10001 | 주식기본정보 (현재가) |
| `orderBook` | ka10004 | 호가잔량 |
| `dailyChart` | ka10081 | 일봉 차트 |
| `minuteChart` | ka10080 | 분봉 차트 |
| `themeGroups` | ka90001 | 테마그룹별 |
| `themeStocks` | ka90002 | 테마구성종목 |
| `conditionList` | ka10171 | 조건검색식 목록 |
| `conditionSearch` | ka10172 | 조건검색 실행 |

> 전체 목록은 `stockclaw-kit-ui.html`의 `KIWOOM_METHODS` 객체를 참조.
> 메서드명 대신 API 코드(`ka10054`)를 직접 사용해도 된다.

---

## 6. 에러 처리 체크리스트

새 패널 개발 시 아래 항목을 반드시 확인:

- [ ] `callKiwoom()` 사용 시 `result.success`로 체크했는가?
- [ ] 직접 `fetch()` 사용 시 `result.ok`로 체크했는가? (혼동 주의)
- [ ] 필수 파라미터에 빈 문자열(`''`)을 보내지 않았는가?
- [ ] `stex_tp` 등 거래소 구분 파라미터를 포함했는가?
- [ ] Electron과 Browser 양쪽 모드에서 테스트했는가?
- [ ] 응답 필드명이 양쪽 모드에서 동일한지 확인했는가?
- [ ] 토큰 만료 시나리오를 고려했는가? (callKiwoom은 자동, fetch는 수동)

---

## 7. 실전 사례: VI 모니터 구현

ka10054 (변동성완화장치발동종목) API를 브라우저에서 호출하는 전체 예시:

```javascript
async function fetchViStocks() {
    let result;
    if (window.electronAPI?.kiwoom?.viStocks) {
        result = await window.electronAPI.kiwoom.viStocks({
            mrkt_tp: '000', bf_mkrt_tp: '1', stk_cd: '',
            motn_tp: '0', skip_stk: '000000011',
            trde_qty_tp: '0', min_trde_qty: '0', max_trde_qty: '100000000',
            trde_prica_tp: '0', min_trde_prica: '0', max_trde_prica: '100000000',
            motn_drc: '0', stex_tp: '1'
        });
    } else if (typeof callKiwoom === 'function') {
        result = await callKiwoom('ka10054', {
            mrkt_tp: '000', bf_mkrt_tp: '1', stk_cd: '',
            motn_tp: '0', skip_stk: '000000011',
            trde_qty_tp: '0', min_trde_qty: '0', max_trde_qty: '100000000',
            trde_prica_tp: '0', min_trde_prica: '0', max_trde_prica: '100000000',
            motn_drc: '0', stex_tp: '1'
        });
    } else {
        throw new Error('API 연결 없음');
    }

    // 필드명 불일치 대응
    const viData = result.data?.vi_motn_stk || result.data?.motn_stk || [];
    return viData;
}
```

핵심 포인트:
- `min_trde_qty: '0'` (빈 문자열 아님)
- `stex_tp: '1'` (필수)
- `vi_motn_stk || motn_stk` (필드명 fallback)
- Electron/Browser 양쪽 분기
