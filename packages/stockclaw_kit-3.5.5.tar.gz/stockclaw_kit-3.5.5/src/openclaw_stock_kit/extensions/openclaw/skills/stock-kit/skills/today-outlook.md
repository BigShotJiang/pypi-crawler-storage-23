# 오늘 전망 — 장전 종합 판단

장 시작 전 여러 소스를 종합하여 오늘 시장과 특정 종목의 전망을 분석한다.

## 트리거

- "오늘 시장 어때?"
- "오늘 현대차 오를까?"
- "오늘 전망 알려줘"
- "장전 분석해줘"
- "오늘 주목할 종목"

## 실행 흐름

| 단계 | API 호출 | 목적 |
|------|---------|------|
| 1 | ka-003 (topic=pre_market_news) | 장전 뉴스 호재/악재 |
| 2 | ka-003 (topic=ny_market) | 뉴욕증시 마감 동향 |
| 3 | ka-003 (topic=leading_stocks) | 어제 주도주 현황 |
| 4 | ka-003 (topic=after_hours) | 시간외 상승 종목 |
| 5 | ka-003 (topic=watch_points) | AI 핵심 관전 포인트 |
| 6 | LLM 종합 | 전체 맥락 → 전망 답변 |

특정 종목 질문 시:

| 추가 | ka-002 (stock=종목코드) | 해당 종목 최근 뉴스 |

## CLI 예시

```bash
# 전체 오전장 브리핑
stockclaw-kit run themalab_call '{"api_id":"ka-003","params":{"topic":"full"}}' 2>/dev/null

# 장전 뉴스만
stockclaw-kit run themalab_call '{"api_id":"ka-003","params":{"topic":"pre_market_news"}}' 2>/dev/null

# 뉴욕증시
stockclaw-kit run themalab_call '{"api_id":"ka-003","params":{"topic":"ny_market"}}' 2>/dev/null
```

## 응답 형식

1. 글로벌 환경 (뉴욕증시, 환율 등)
2. 국내 시장 분위기 (시간외, 주도주)
3. 장전 뉴스 핵심 (호재/악재 요약)
4. 오늘 관전 포인트
5. (특정 종목 질문 시) 해당 종목 전망

## 주의사항

- 오전 7시 이후 데이터 존재 (자동 생성 시간)
- 전일 데이터를 원하면 date 파라미터 지정
- 전망은 참고 정보이며, 투자 판단은 사용자 책임
