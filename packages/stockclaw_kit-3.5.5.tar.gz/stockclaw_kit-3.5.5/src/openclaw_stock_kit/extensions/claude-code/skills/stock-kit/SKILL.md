---
name: stock-kit
description: |
  Korean stock market expert skill. Provides real-time quotes, trading, news, and disclosures via CLI tools.
  Delegates all work to the stock-kit agent which handles tool routing.

  Triggers: 주식, 현재가, 시세, 매매, 주문, 잔고, 뉴스, 공시, 차트,
  종목, 코스피, 코스닥, 환율, 금리, 시가총액, 급등주, 호가, 배당,
  stock, price, trade, order, balance, news, disclosure, chart, KOSPI

  Do NOT use for: general knowledge, coding, non-stock questions, cryptocurrency
argument-hint: "[종목명|질문]"
user-invocable: true
agent: stock-kit:stock-kit
allowed-tools:
  - Bash
  - Read
---

# Stock Analysis Skill

## Overview

Korean stock market analysis skill powered by CLI tools.
All queries are routed to the `stock-kit` agent which interprets intent and calls the optimal tool via `stockclaw-kit run <tool> key=value`.

## 최초 설치 (command not found 시)

1. `pip install stockclaw-kit`
2. `stockclaw-kit setup claude-code` → 플러그인 자동 배치
3. Claude Code 재시작

## First-Time Setup

Agent는 첫 사용 시 반드시 설치 → `stockclaw-kit setup` → PM2 설정 서버 시작 → 브라우저 안내 순서를 따른다.
상세 절차는 agent 프롬프트의 "First-Time Setup" 섹션 참조.

## Actions

| Action | Description | Example |
|--------|-------------|---------|
| Price query | Real-time stock price | `/stock 삼성전자 현재가` |
| Market ranking | Top gainers, volume, market cap | `/stock 급등주 순위` |
| Chart data | Daily/weekly/monthly OHLCV | `/stock 삼성전자 일봉` |
| Historical data | Past price trends | `/stock 삼성전자 최근 3개월` |
| News | Stock-related news | `/stock 삼성전자 뉴스` |
| Disclosure | DART corporate filings | `/stock 삼성전자 공시` |
| Fundamentals | PER, PBR, dividend yield | `/stock 삼성전자 PER` |
| Economic data | Interest rates, GDP, exchange rates | `/stock 원달러 환율` |
| Index | KOSPI/KOSDAQ index data | `/stock 코스피 지수` |
| Trading | Buy/sell orders (with confirmation) | `/stock 삼성전자 10주 매수` |
| Portfolio | Account balance and P&L | `/stock 내 잔고` |
| Condition search | Kiwoom condition-based screening | `/stock 조건검색 목록` |
| Realtime data | WebSocket realtime quotes | `/stock 삼성전자 실시간 등록` |
| Telegram | Channel messages and alerts | `/stock 텔레그램 채널 목록` |
| 멤버십 데이터 | AI market summary and theme events | `/stock 멤버십 데이터 함수 목록` |

## Data Sources

| Source | Coverage | Key Feature |
|--------|----------|-------------|
| Kiwoom (키움) | 159 APIs | Real-time quotes, trading |
| DataKit (PyKRX) | Free historical data | No API key required |
| DataKit (DART) | Corporate disclosures | Financial statements |
| DataKit (ECOS) | Economic indicators | Interest rates, GDP |
| News (Naver) | Stock/keyword news | Latest articles |
| Telegram | Channel messages | Community sentiment |
| KIS | 166 APIs | Alternative broker |
| 멤버십 데이터 | 8 Feed APIs | AI market summary, leading stocks, theme events |

## CLI Tool Pattern

모든 도구 호출은 `stockclaw-kit run <tool> '<params>'` 패턴 사용:

```bash
stockclaw-kit run list                                          # 전체 도구 목록 (38개)
stockclaw-kit run kiwoom_call_api '{"api_code":"ka10001","payload_json":"{\"stk_cd\":\"005930\"}"}'
stockclaw-kit run kiwoom_condition_list '{}'
stockclaw-kit run kiwoom_realtime_register '{"items":["005930"],"types":["0H"]}'
stockclaw-kit run datakit_call '{"function":"get_ohlcv","params_json":"{\"ticker\":\"005930\",\"days\":30}"}'
stockclaw-kit run news_search_stock '{"stock_name":"삼성전자"}'
stockclaw-kit run telegram_get_channels '{}'
stockclaw-kit run themalab_list_functions '{}'
```

## Usage Examples

```
/stock 삼성전자                    → 현재가 조회
/stock 오늘 급등주                 → 상승률 순위
/stock 삼성전자 최근 6개월 추이    → 과거 주가 데이터
/stock 반도체 관련 뉴스            → 키워드 뉴스 검색
/stock 코스피 지수                 → KOSPI 지수 조회
/stock 원달러 환율                 → 환율 조회
/stock 내 잔고                     → 계좌 잔고 조회
/stock 조건검색 목록               → 키움 조건검색식 목록
/stock 텔레그램 채널 목록          → 텔레그램 채널 조회
```
