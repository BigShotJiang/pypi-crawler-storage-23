"""StockClaw Kit — Korean stock market data & trading toolkit.

Usage:
    pip install stockclaw-kit             # install
    stockclaw-kit                         # start settings server
    stockclaw-kit run list               # list available tools
    stockclaw-kit run gateway_status     # direct CLI call
"""

__version__ = "3.5.2"
