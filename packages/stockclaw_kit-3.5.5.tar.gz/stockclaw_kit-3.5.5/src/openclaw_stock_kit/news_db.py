#!/usr/bin/env python3
"""News DB Module

SQLite 기반 뉴스 기사 저장/조회 모듈.
DB 파일 위치: {config_dir}/news.db
"""

import re
import sqlite3
from pathlib import Path


# ─── HTML 엔티티 정규화 (기존 유지) ─────────────────────────────
_HTML_TAG_RE = re.compile(r"<[^>]+>")
_HTML_ENTITIES = {
    "&quot;": '"',
    "&amp;": "&",
    "&lt;": "<",
    "&gt;": ">",
    "&nbsp;": " ",
    "&apos;": "'",
}


def _clean_html(text: str) -> str:
    """HTML 태그 및 기본 엔티티 제거."""
    if not text:
        return text or ""
    text = _HTML_TAG_RE.sub("", text)
    for entity, replacement in _HTML_ENTITIES.items():
        text = text.replace(entity, replacement)
    return text.strip()


# ─── DDL (기존 유지) ───────────────────────────────────────────
_CREATE_TABLE_SQL = """
CREATE TABLE IF NOT EXISTS news_articles (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    keyword       TEXT NOT NULL,
    title         TEXT NOT NULL,
    description   TEXT,
    link          TEXT,
    originallink  TEXT,
    pub_date      TEXT,
    press         TEXT,
    collected_at  TEXT DEFAULT (datetime('now', 'localtime'))
);
"""

_CREATE_IDX_LINK_SQL = """
CREATE UNIQUE INDEX IF NOT EXISTS idx_link ON news_articles(link);
"""

_CREATE_IDX_KEYWORD_SQL = """
CREATE INDEX IF NOT EXISTS idx_keyword ON news_articles(keyword);
"""

_CREATE_IDX_COLLECTED_SQL = """
CREATE INDEX IF NOT EXISTS idx_collected ON news_articles(collected_at DESC);
"""


class NewsDB:
    """뉴스 기사 SQLite 저장소. 요청마다 커넥션을 열고 닫음."""

    def __init__(self, config_dir: str):
        db_dir = Path(config_dir)
        db_dir.mkdir(parents=True, exist_ok=True)
        self._db_path = str(db_dir / "news.db")
        # 초기화: 스키마 생성
        with self._connect() as conn:
            conn.execute(_CREATE_TABLE_SQL)
            conn.execute(_CREATE_IDX_LINK_SQL)
            conn.execute(_CREATE_IDX_KEYWORD_SQL)
            conn.execute(_CREATE_IDX_COLLECTED_SQL)
            conn.commit()

    def _connect(self):
        """새 커넥션을 열고 WAL + busy_timeout 설정."""
        conn = sqlite3.connect(self._db_path, timeout=10)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA busy_timeout=5000")
        return conn

    def save_articles(self, keyword: str, articles: list) -> dict:
        saved = 0
        duplicates = 0
        with self._connect() as conn:
            cur = conn.cursor()
            for article in articles:
                title = _clean_html(article.get("title", ""))
                description = _clean_html(article.get("description", ""))
                link = article.get("link", "")
                originallink = article.get("originallink", "")
                pub_date = article.get("pubDate", "")
                press = article.get("press", "")
                if not title:
                    duplicates += 1
                    continue
                cur.execute(
                    """INSERT OR IGNORE INTO news_articles
                        (keyword, title, description, link, originallink, pub_date, press)
                    VALUES (?, ?, ?, ?, ?, ?, ?)""",
                    (keyword, title, description, link, originallink, pub_date, press),
                )
                if cur.rowcount == 1:
                    saved += 1
                else:
                    duplicates += 1
            conn.commit()
        return {"saved": saved, "duplicates": duplicates}

    def get_history(self, keyword: str = "", limit: int = 100, offset: int = 0) -> dict:
        with self._connect() as conn:
            cur = conn.cursor()
            if keyword:
                where = "WHERE keyword = ?"
                params_count = (keyword,)
                params_data = (keyword, limit, offset)
            else:
                where = ""
                params_count = ()
                params_data = (limit, offset)
            cur.execute(f"SELECT COUNT(*) FROM news_articles {where}", params_count)
            total = cur.fetchone()[0]
            cur.execute(
                f"""SELECT id, keyword, title, description, link, originallink,
                       pub_date, press, collected_at
                FROM news_articles {where}
                ORDER BY collected_at DESC
                LIMIT ? OFFSET ?""",
                params_data,
            )
            data = [dict(row) for row in cur.fetchall()]
        return {"data": data, "total": total}

    def get_keywords(self) -> list:
        with self._connect() as conn:
            cur = conn.cursor()
            cur.execute("SELECT DISTINCT keyword FROM news_articles ORDER BY keyword")
            return [row[0] for row in cur.fetchall()]

    def delete_articles(self, ids: list) -> int:
        if not ids:
            return 0
        placeholders = ",".join("?" * len(ids))
        with self._connect() as conn:
            cur = conn.cursor()
            cur.execute(f"DELETE FROM news_articles WHERE id IN ({placeholders})", ids)
            conn.commit()
            return cur.rowcount

    def delete_all(self) -> int:
        with self._connect() as conn:
            cur = conn.cursor()
            cur.execute("DELETE FROM news_articles")
            conn.commit()
            return cur.rowcount

    def close(self) -> None:
        """호환성 유지 (이제 no-op)."""
        pass
