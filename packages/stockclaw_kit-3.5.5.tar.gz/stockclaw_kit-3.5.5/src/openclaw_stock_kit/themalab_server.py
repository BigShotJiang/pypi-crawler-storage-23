#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
멤버십 데이터 피드 서버 (readinginvestor.com)
API 8개: ka-002~009 (종목매칭, 오전장, 오후장, 시간별, 일일, 테마점수, 타임라인, 급등감지)
도구 3개: themalab_call, themalab_list_functions, themalab_get_env_info
Rate Limit: 분당 120회 (sliding window, threading.Lock)
"""

import os, sys, json, threading, time, hashlib
from collections import deque
from datetime import datetime, timezone, timedelta
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from response import ok_response, error_response, ErrorCode

try:
    import requests as _requests
    _HAS_REQUESTS = True
except ImportError:
    _HAS_REQUESTS = False

import db_local  # 로컬 SQLite 모듈

_BASE_URL = "https://readinginvestor.com/api/feed"
_USER_AGENT = "stockclaw-kit/3.5"
_TIMEOUT = 15
_RATE_LIMIT_PER_MINUTE = 120
_KST = timezone(timedelta(hours=9))

_API_CATALOG = {
    "ka-002": {
        "name": "종목-뉴스 매칭",
        "required_params": [],
        "optional_params": ["stock", "theme", "since", "limit", "page", "match_type"],
        "description": "종목코드/테마 기준 뉴스 매칭 메타데이터 (제목+링크+AI요약). stock은 종목코드 또는 종목명",
        "example": {"stock": "005930"},
    },
    "ka-003": {
        "name": "오전장 브리핑",
        "required_params": [],
        "optional_params": ["date", "topic"],
        "description": "AI 생성 오전장 분석. topic: pre_market_news, ny_market, leading_stocks, after_hours, watch_points, full(기본)",
        "example": {"topic": "pre_market_news"},
    },
    "ka-004": {
        "name": "오후장 분석",
        "required_params": [],
        "optional_params": ["date", "topic", "stock_code", "days"],
        "description": "AI 생성 장마감 분석. 과거검색(기본60거래일)+종목/주제 필터. topic: surge_stocks, theme_ranking, leading_analysis, stock_reasons, awake, full(기본)",
        "example": {"stock_code": "005380", "topic": "stock_reasons", "days": "60"},
    },
    "ka-005": {
        "name": "장중 시간별 요약",
        "required_params": [],
        "optional_params": ["date", "hour"],
        "description": "매시 1시간 단위 뉴스/이벤트 AI 요약. hour: 9~15 (장중 시간대)",
        "example": {"hour": "10"},
    },
    "ka-006": {
        "name": "일일 종합 요약",
        "required_params": [],
        "optional_params": ["date", "type"],
        "description": "당일 전체 테마별/종목별 종합 요약. type: morning, afternoon, all(기본)",
        "example": {},
    },
    "ka-007": {
        "name": "테마 실시간 점수",
        "required_params": [],
        "optional_params": ["theme", "top"],
        "description": "조회순위 기반 테마별 가중치 점수 (자체 알고리즘). top: 상위 N개(기본 10)",
        "example": {"top": "10"},
    },
    "ka-008": {
        "name": "테마 타임라인",
        "required_params": [],
        "optional_params": ["theme", "hours", "top", "interval"],
        "description": "테마 점수 시계열 변화. hours: 1~24(기본24), top: 1~10(기본5), interval: 30~300초(기본30)",
        "example": {"hours": "6", "top": "5"},
    },
    "ka-009": {
        "name": "거래대금 급등 감지",
        "required_params": [],
        "optional_params": ["stock_code", "limit"],
        "description": "거래대금 급증 종목 실시간 감지. stock_code로 특정 종목 필터 가능",
        "example": {"limit": "20"},
    },
}


class _RateLimiter:
    """Sliding window rate limiter: max N calls per 60 seconds."""

    def __init__(self, max_per_minute: int = _RATE_LIMIT_PER_MINUTE):
        self._max = max_per_minute
        self._window = deque()  # timestamps of recent calls
        self._lock = threading.Lock()

    def acquire(self) -> tuple[bool, float]:
        """Returns (allowed, wait_seconds). wait_seconds=0 if allowed."""
        now = time.monotonic()
        with self._lock:
            # remove timestamps older than 60s
            cutoff = now - 60.0
            while self._window and self._window[0] < cutoff:
                self._window.popleft()
            if len(self._window) < self._max:
                self._window.append(now)
                return True, 0.0
            oldest = self._window[0]
            wait = 60.0 - (now - oldest)
            return False, max(0.0, wait)


_rate_limiter = _RateLimiter()


def register_tools(registry, get_pg=None):
    """멤버십 데이터 도구 3개 등록

    get_pg: 하위 호환성을 위해 유지하되 내부에서 무시 (SQLite 사용)
    """

    # ------------------------------------------------------------------ helpers

    def _call_feed_api(api_id: str, params: dict, api_key: str) -> dict:
        """Call readinginvestor.com feed API and return parsed JSON."""
        if not _HAS_REQUESTS:
            return {"error": "requests 패키지 미설치. pip install requests"}

        url = f"{_BASE_URL}/{api_id}"
        headers = {
            "x-api-key": api_key,
            "User-Agent": _USER_AGENT,
            "Accept": "application/json",
        }
        try:
            resp = _requests.get(url, params=params, headers=headers, timeout=_TIMEOUT)
            if resp.status_code == 401:
                return {"__auth_error__": "401"}
            if resp.status_code == 403:
                return {"__auth_error__": "403"}
            resp.raise_for_status()
            return resp.json()
        except _requests.Timeout:
            return {"__timeout__": True}
        except Exception as e:
            return {"__request_error__": str(e)}

    def _db_save(api_id: str, params: dict, raw: dict):
        """raw 응답을 로컬 SQLite hub_api_responses에 저장."""
        db_local.save_hub(f"themalab:{api_id}", params, raw)

    def _db_save_normalized(api_id: str, raw: dict):
        """api_id 기반 정규화 테이블에 upsert (SQLite)."""
        try:
            conn = db_local.get_conn()
            today_kst = datetime.now(_KST).date().isoformat()

            if api_id in ("ka-002",):  # stock_events (종목-뉴스 매칭만)
                items = raw.get("items") or raw.get("data") or []
                if not isinstance(items, list):
                    items = []
                for item in items:
                    stock_code = item.get("stock_code") or item.get("code")
                    event_date = item.get("date") or today_kst
                    event_type = item.get("type") or api_id
                    title = item.get("title") or item.get("headline") or ""
                    summary = item.get("summary") or item.get("content") or ""
                    score = item.get("score")
                    conn.execute(
                        """
                        INSERT INTO themalab_stock_events
                            (api_id, stock_code, event_date, event_type,
                             title, summary, score, created_at)
                        VALUES (?, ?, ?, ?, ?, ?, ?, datetime('now'))
                        ON CONFLICT (api_id, stock_code, event_date, event_type)
                        DO UPDATE SET title=excluded.title,
                                      summary=excluded.summary,
                                      score=excluded.score,
                                      created_at=datetime('now')
                        """,
                        (api_id, stock_code, event_date, event_type,
                         title, summary, score),
                    )

            elif api_id in ("ka-003", "ka-004", "ka-005", "ka-006", "ka-007", "ka-008", "ka-009"):  # 요약/분석 계열
                summary_text = (
                    raw.get("summary") or raw.get("content")
                    or json.dumps(raw, ensure_ascii=False)[:2000]
                )
                report_date = raw.get("date") or today_kst
                conn.execute(
                    """
                    INSERT INTO themalab_daily_summary
                        (api_id, report_date, summary_text, created_at)
                    VALUES (?, ?, ?, datetime('now'))
                    ON CONFLICT (api_id, report_date)
                    DO UPDATE SET summary_text=excluded.summary_text,
                                  created_at=datetime('now')
                    """,
                    (api_id, report_date, summary_text),
                )

            conn.commit()
        except Exception as e:
            print(f"[DB] themalab normalized save failed ({api_id}): {e}")

    # ------------------------------------------------------------------ tools

    @registry.tool()
    def themalab_call(api_id: str, params: dict = None) -> dict:
        """
        멤버십 데이터 피드 API를 호출합니다.

        Args:
            api_id: API 식별자.
                - ka-002: 종목-뉴스 매칭
                - ka-003: 오전장 브리핑 (topic 필터)
                - ka-004: 오후장 분석 (과거검색, topic/stock_code 필터)
                - ka-005: 장중 시간별 요약
                - ka-006: 일일 종합 요약
                - ka-007: 테마 실시간 점수
                - ka-008: 테마 타임라인
                - ka-009: 거래대금 급등 감지
            params: API별 파라미터. 예) {"stock": "005930"}, {"topic": "pre_market_news"}

        Returns:
            피드 응답 JSON. error 필드가 있으면 실패.
        """
        if api_id not in _API_CATALOG:
            valid = ", ".join(sorted(_API_CATALOG.keys()))
            return error_response(
                ErrorCode.INVALID_PARAMS,
                f"api_id '{api_id}' 유효하지 않음. 유효값: {valid}",
            )

        meta = _API_CATALOG[api_id]
        params = params or {}

        # validate required params
        missing = [p for p in meta["required_params"] if p not in params]
        if missing:
            return error_response(
                ErrorCode.INVALID_PARAMS,
                f"{api_id} 필수 파라미터 누락: {missing}",
            )

        # check API key
        api_key = os.environ.get("THEMALAB_API_KEY", "").strip()
        if not api_key:
            return error_response(
                "AUTH_MISSING",
                "THEMALAB_API_KEY 환경변수가 설정되지 않았습니다. "
                ".env에 THEMALAB_API_KEY=tt_live_... 형식으로 설정하세요.",
            )

        # rate limit check
        allowed, wait_sec = _rate_limiter.acquire()
        if not allowed:
            return error_response(
                ErrorCode.RATE_LIMITED,
                f"멤버십 API Rate Limit (분당 {_RATE_LIMIT_PER_MINUTE}회). "
                f"{wait_sec:.1f}초 대기 후 재시도하세요.",
            )

        # call API
        raw = _call_feed_api(api_id, params, api_key)

        # handle auth errors
        if "__auth_error__" in raw:
            code = raw["__auth_error__"]
            if code == "401":
                return error_response(
                    "AUTH_INVALID",
                    "THEMALAB_API_KEY가 유효하지 않습니다. 키를 확인하세요.",
                )
            return error_response(
                "AUTH_FORBIDDEN",
                "멤버십 API 접근이 거부되었습니다. 구독 플랜을 확인하세요.",
            )
        if raw.get("__timeout__"):
            return error_response(ErrorCode.TIMEOUT, "멤버십 API 타임아웃 (15s)")
        if "__request_error__" in raw:
            return error_response(ErrorCode.CONNECTION_ERROR, raw["__request_error__"])

        # save to DB (best-effort)
        try:
            _db_save(api_id, params, raw)
            _db_save_normalized(api_id, raw)
        except Exception as _e:
            print(f"[DB] themalab save failed ({api_id}): {_e}")

        return ok_response({
            "api_id": api_id,
            "name": meta["name"],
            "params": params,
            "data": raw,
        })

    @registry.tool()
    def themalab_list_functions() -> dict:
        """
        사용 가능한 멤버십 API 목록을 반환합니다.

        Returns:
            api_id 목록, 이름, 필수/선택 파라미터, 설명
        """
        catalog = []
        for aid, meta in sorted(_API_CATALOG.items()):
            catalog.append({
                "api_id": aid,
                "name": meta["name"],
                "required_params": meta["required_params"],
                "optional_params": meta["optional_params"],
                "description": meta["description"],
                "example_params": meta["example"],
            })
        return ok_response({
            "count": len(catalog),
            "rate_limit": f"분당 {_RATE_LIMIT_PER_MINUTE}회",
            "apis": catalog,
        })

    @registry.tool()
    def themalab_get_env_info() -> dict:
        """
        멤버십 API 환경 정보를 확인합니다 (키 노출 없이).

        Returns:
            API 키 설정 여부, 키 형식 (앞 12자 마스크), DB 연결 여부
        """
        api_key = os.environ.get("THEMALAB_API_KEY", "").strip()
        if not api_key:
            key_status = "설정되지 않음"
            key_preview = None
            key_valid_format = False
        else:
            key_status = "설정됨"
            key_preview = api_key[:12] + "..." if len(api_key) > 12 else api_key
            key_valid_format = api_key.startswith("tt_live_") and len(api_key) == 72

        return ok_response({
            "api_key_set": bool(api_key),
            "api_key_status": key_status,
            "api_key_preview": key_preview,
            "api_key_valid_format": key_valid_format,
            "key_format_hint": "tt_live_ + 64자 hex (전체 72자)",
            "db_backend": "sqlite",
            "requests_available": _HAS_REQUESTS,
            "base_url": _BASE_URL,
            "rate_limit_per_minute": _RATE_LIMIT_PER_MINUTE,
        })

