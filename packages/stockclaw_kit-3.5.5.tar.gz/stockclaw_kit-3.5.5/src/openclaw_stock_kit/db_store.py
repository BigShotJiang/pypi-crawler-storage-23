"""StockClaw Kit — API 호출 히스토리 영구 저장 모듈

SQLite 기반 히스토리 로그. 캐시/만료 없음 — 모든 API 호출을 영구 기록.
DB 경로: ~/.stockclaw-kit/market.db
"""
import json
import os
import sqlite3
import threading
from pathlib import Path

_CONFIG_DIR = Path.home() / ".stockclaw-kit"
_DEFAULT_DB_PATH = _CONFIG_DIR / "market.db"

_DDL = """
CREATE TABLE IF NOT EXISTS api_history (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    tool       TEXT NOT NULL,
    params     TEXT NOT NULL,
    result     TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);
CREATE INDEX IF NOT EXISTS idx_tool_time   ON api_history(tool, created_at);
CREATE INDEX IF NOT EXISTS idx_tool_params ON api_history(tool, params);
"""


class DBStore:
    """API 호출 히스토리를 SQLite에 영구 저장하는 스토어.

    특징:
    - TTL/만료 없음 (캐시가 아닌 히스토리 로그)
    - save() 호출마다 무조건 새 행 추가 (중복 제거 없음)
    - WAL 모드로 멀티스레드 동시 접근 안전
    - 외부 의존성 없음 (표준 라이브러리 sqlite3만 사용)
    """

    def __init__(self, db_path: Path = None):
        """스토어 초기화.

        Args:
            db_path: DB 파일 경로. None이면 ~/.stockclaw-kit/market.db 사용.
        """
        self._db_path = Path(db_path) if db_path is not None else _DEFAULT_DB_PATH
        self._db_path.parent.mkdir(parents=True, exist_ok=True)
        self._local = threading.local()
        # 메인 스레드에서 즉시 테이블 생성
        self._ensure_schema(self._get_conn())

    # ------------------------------------------------------------------
    # 내부 연결 관리
    # ------------------------------------------------------------------

    def _get_conn(self) -> sqlite3.Connection:
        """스레드별 SQLite 연결 반환 (WAL 모드)."""
        conn = getattr(self._local, "conn", None)
        if conn is not None:
            return conn
        conn = sqlite3.connect(
            str(self._db_path),
            timeout=5,
            check_same_thread=False,
        )
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA busy_timeout=5000")
        conn.execute("PRAGMA synchronous=NORMAL")
        self._local.conn = conn
        return conn

    def _ensure_schema(self, conn: sqlite3.Connection) -> None:
        """테이블 및 인덱스가 없으면 생성."""
        conn.executescript(_DDL)
        conn.commit()

    # ------------------------------------------------------------------
    # 공개 API
    # ------------------------------------------------------------------

    def save(self, tool: str, params: dict, result: str) -> int:
        """API 호출 결과를 히스토리에 저장. 호출마다 새 행 추가.

        Args:
            tool:   도구(API) 이름
            params: 입력 파라미터 dict (JSON 직렬화됨)
            result: API 응답 원본 JSON 문자열

        Returns:
            삽입된 행의 id (INTEGER PRIMARY KEY)
        """
        conn = self._get_conn()
        params_json = json.dumps(params, ensure_ascii=False, sort_keys=True)
        cur = conn.execute(
            "INSERT INTO api_history (tool, params, result) VALUES (?, ?, ?)",
            (tool, params_json, result),
        )
        conn.commit()
        return cur.lastrowid

    def query(self, sql: str, params: tuple = ()) -> list[dict]:
        """임의의 SELECT 쿼리를 실행하고 결과를 dict 리스트로 반환.

        Args:
            sql:    실행할 SQL 쿼리 (SELECT 권장)
            params: 바인딩 파라미터 tuple

        Returns:
            각 행을 dict로 변환한 리스트
        """
        conn = self._get_conn()
        cur = conn.execute(sql, params)
        return [dict(row) for row in cur.fetchall()]

    def get_history(self, tool: str = None, limit: int = 100) -> list[dict]:
        """호출 히스토리를 반환. tool이 None이면 전체.

        Args:
            tool:  도구 이름 (None이면 전체)
            limit: 반환할 최대 행 수 (기본 100)

        Returns:
            최신 순으로 정렬된 히스토리 목록
        """
        if tool:
            return self.query(
                "SELECT id, tool, params, result, created_at "
                "FROM api_history WHERE tool = ? "
                "ORDER BY created_at DESC, id DESC LIMIT ?",
                (tool, limit),
            )
        return self.query(
            "SELECT id, tool, params, result, created_at "
            "FROM api_history "
            "ORDER BY created_at DESC, id DESC LIMIT ?",
            (limit,),
        )

    def get_stats(self) -> dict:
        """DB 통계 정보를 반환.

        Returns:
            total_rows: 전체 행 수
            db_size_bytes: DB 파일 크기 (바이트)
            db_size_human: 사람이 읽기 쉬운 파일 크기
            tools: 도구별 호출 횟수 및 최근 호출 시각
        """
        total_rows_result = self.query("SELECT COUNT(*) AS cnt FROM api_history")
        total_rows = total_rows_result[0]["cnt"] if total_rows_result else 0

        db_size_bytes = 0
        if self._db_path.exists():
            db_size_bytes = self._db_path.stat().st_size

        tools_result = self.query(
            "SELECT tool, COUNT(*) AS call_count, MAX(created_at) AS last_called "
            "FROM api_history "
            "GROUP BY tool "
            "ORDER BY call_count DESC"
        )

        return {
            "total_rows": total_rows,
            "db_size_bytes": db_size_bytes,
            "db_size_human": _human_size(db_size_bytes),
            "db_path": str(self._db_path),
            "tools": [dict(row) for row in tools_result],
        }

    def close(self) -> None:
        """스레드 로컬 SQLite 연결을 닫음."""
        conn = getattr(self._local, "conn", None)
        if conn is not None:
            conn.close()
            self._local.conn = None


# ------------------------------------------------------------------
# 유틸리티
# ------------------------------------------------------------------

def _human_size(size_bytes: int) -> str:
    """바이트 크기를 사람이 읽기 쉬운 문자열로 변환."""
    for unit in ("B", "KB", "MB", "GB"):
        if size_bytes < 1024:
            return f"{size_bytes:.1f} {unit}"
        size_bytes /= 1024
    return f"{size_bytes:.1f} TB"


# ------------------------------------------------------------------
# 모듈 수준 싱글턴 (선택적으로 사용)
# ------------------------------------------------------------------

_default_store: DBStore | None = None
_store_lock = threading.Lock()


def get_default_store() -> DBStore:
    """모듈 수준 싱글턴 DBStore를 반환 (필요 시 초기화)."""
    global _default_store
    if _default_store is None:
        with _store_lock:
            if _default_store is None:
                _default_store = DBStore()
    return _default_store
