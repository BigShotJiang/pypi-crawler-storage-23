#!/usr/bin/env python3
"""News & Telegram Server

Tools 8:
  - news_search           : Naver News API keyword search
  - news_search_stock     : Stock-specific news search (date filter + dedup)
  - telegram_auth         : Telegram authentication (send_code/verify/status)
  - telegram_get_channels : List subscribed channels/groups
  - telegram_get_messages : Get channel messages (ad filter, Telethon + web fallback)
  - telegram_send_message : Send message to channel/group/user
  - telegram_send_alert   : Send formatted stock alert to Telegram
  - news_get_env_info     : Environment info

Naver News API:
  NAVER_CLIENT_ID + NAVER_CLIENT_SECRET required
  https://developers.naver.com/ (search > news)
  Multi-key rotation: NAVER_NEWS_API_KEY_N_ID / NAVER_NEWS_API_KEY_N_SECRET (N=1..10)

Telegram:
  TELEGRAM_API_ID + TELEGRAM_API_HASH + TELEGRAM_PHONE required
  https://my.telegram.org/
  Public channels: web scraping fallback (no key needed)
"""

import asyncio
import os
import re
import json
import hashlib
import html as html_mod
from datetime import datetime, timedelta
from pathlib import Path

import requests

try:
    from telethon import TelegramClient
    from telethon.tl.types import Channel, Chat
    _HAS_TELETHON = True
except ImportError:
    _HAS_TELETHON = False

import db_local  # 로컬 SQLite 모듈

# ─── Constants ────────────────────────────────────────────
NAVER_API_URL = "https://openapi.naver.com/v1/search/news.json"
TELEGRAM_WEB_URL = "https://t.me/s/"

# ─── Ad Filtering v2.5 ─────────────────────────────────
# Stage 1: Top priority (bypass whitelist)
_TOP_PRIORITY_AD = [re.compile(p, re.IGNORECASE) for p in [
    r'공유하기\s*:\s*t\.me/',
    r't\.me\/.*공유하기',
    r'공유는\s*맘껏',
    r'forms\.gle/',
    r'유튜브\s*(방송|영상).*업로드',
    r'(아침|저녁|오전|오후)방송\s*업로드',
    r'(아침|저녁|오전|오후)\s*(주식\s*)?방송',
    r'당장\s*사면\s*급등',
    r'눈뜨자마자\s*사야',
    r'미친듯이\s*오를',
    r'클래스\s*[&+]\s*(특징|뉴스|문의)',
    r'문의\s*@[a-zA-Z]',
]]

# Stage 2: Whitelist (news/disclosure = NOT ad)
_WHITELIST = [re.compile(p, re.IGNORECASE) for p in [
    r'공시링크\s*:',
    r'dart\.fss\.or\.kr',
    r'finance\.naver\.com',
    r'n\.news\.naver\.com',
    r'코스피\s*\d+',
    r'코스닥\s*\d+',
    r'애널리스트',
    r'목표주가',
    r'투자의견',
    r'연합인포맥스',
    r'시가총액\s*:',
    r'배당기준일\s*:',
    r'주식등의대량보유',
    r'현금.*현물배당\s*결정',
]]

# Stage 3: Definite ad patterns
_DEFINITE_AD = [re.compile(p, re.IGNORECASE) for p in [
    r'강의\s*보러\s*가기',
    r'VIP\s*(회원|멤버|룸|클래스)',
    r'수익\s*인증.*클래스',
    r'클래스.*수익\s*인증',
    r'클래스.*문의',
    r'무료\s*(강의|체험)\s*(바로|보러)',
    r'매매\s*신호\s*(무료|공개)',
    r'시그널\s*(무료|공개|제공)',
    r'프리미엄채널.*오픈',
    r'\[.*네프콘\]',
    r'네프콘\s*구독',
    r'강의\s*\d+강.*검색기',
]]

# Stage 4: Suspicious keywords (2+ = ad)
_SUSPICIOUS_KW = [
    '무료강의', '무료체험', '무료상담', '수익인증', '수익공개',
    '선착순', '마감임박', '프로모션', '특가', '할인가',
]


def _is_ad(text):
    """Ad detection v2.5 (4-stage). Returns (is_ad: bool, reason: str|None)"""
    if not text:
        return False, None

    # 1) Top priority (bypass whitelist)
    for p in _TOP_PRIORITY_AD:
        if p.search(text):
            return True, p.pattern[:40]

    # 2) Whitelist (news/disclosure)
    for p in _WHITELIST:
        if p.search(text):
            return False, None

    # 3) Definite ad
    for p in _DEFINITE_AD:
        if p.search(text):
            return True, p.pattern[:40]

    # 4) Suspicious keywords (2+)
    normalized = text.lower().replace(' ', '')
    count = sum(1 for kw in _SUSPICIOUS_KW if kw in normalized)
    if count >= 2:
        return True, f"suspicious_kw_{count}"

    # 5) Too many non-news URLs
    urls = re.findall(r'https?://\S+', text)
    non_news = [u for u in urls if not any(d in u for d in
                ['dart.fss.or.kr', 'naver.com', 'finance.naver'])]
    if len(non_news) >= 5:
        return True, "too_many_urls"

    return False, None


# ─── Utilities ────────────────────────────────────────────
def _strip_html(text):
    """Remove HTML tags and unescape entities"""
    text = re.sub(r'<[^>]+>', '', text)
    text = html_mod.unescape(text)
    return text.strip()


def _extract_domain(url):
    m = re.match(r'https?://(?:www\.)?([^/]+)', url)
    return m.group(1) if m else ""


def _db_save(tool_name, params, result):
    """news API 응답을 로컬 SQLite hub_api_responses에 저장"""
    db_local.save_hub(f"news:{tool_name}", params, result)


# ─── Naver News API ──────────────────────────────────────
def _naver_search(query, display=10, start=1, sort="date"):
    """Naver News search API call (supports single key + multi-key rotation)"""
    cid = os.getenv("NAVER_CLIENT_ID", "")
    csecret = os.getenv("NAVER_CLIENT_SECRET", "")

    # Fallback: numbered keys (NAVER_NEWS_API_KEY_N_ID/SECRET)
    if not cid:
        for i in range(1, 11):
            cid = os.getenv(f"NAVER_NEWS_API_KEY_{i}_ID", "")
            csecret = os.getenv(f"NAVER_NEWS_API_KEY_{i}_SECRET", "")
            if cid and csecret:
                break

    if not cid or not csecret:
        return {
            "success": False,
            "error": "NAVER_CLIENT_ID/SECRET not configured. "
                     "Get keys at https://developers.naver.com/",
            "error_type": "AUTH_MISSING",
        }

    try:
        resp = requests.get(
            NAVER_API_URL,
            headers={
                "X-Naver-Client-Id": cid,
                "X-Naver-Client-Secret": csecret,
            },
            params={
                "query": query,
                "display": min(max(int(display), 1), 100),
                "start": min(max(int(start), 1), 1000),
                "sort": sort if sort in ("date", "sim") else "date",
            },
            timeout=10,
        )
        if resp.status_code == 429:
            return {"success": False, "error": "Naver API rate limit (429)",
                    "error_type": "RATE_LIMIT"}
        resp.raise_for_status()
        data = resp.json()

        items = []
        for item in data.get("items", []):
            items.append({
                "title": _strip_html(item.get("title", "")),
                "link": item.get("originallink") or item.get("link", ""),
                "description": _strip_html(item.get("description", "")),
                "pubDate": item.get("pubDate", ""),
                "source": _extract_domain(
                    item.get("originallink") or item.get("link", "")),
            })

        return {
            "success": True,
            "query": query,
            "total": data.get("total", 0),
            "start": data.get("start", 1),
            "display": data.get("display", len(items)),
            "items": items,
        }
    except requests.RequestException as e:
        return {"success": False, "error": str(e), "error_type": "REQUEST_ERROR"}


# ─── Telegram (Telethon + Web Fallback) ──────────────────
_tg_client = None
_tg_phone_code_hash = None
_tg_lock = asyncio.Lock()  # SQLite session 동시접근 방지 (database is locked 에러 차단)


def _config_dir():
    d = Path(os.getenv("OPENCLAW_STOCK_KIT_HOME",
                       Path.home() / ".stockclaw-kit"))
    d.mkdir(parents=True, exist_ok=True)
    return d


async def _ensure_tg():
    """Get connected + authorized Telegram client. Returns None if unavailable."""
    global _tg_client

    if not _HAS_TELETHON:
        return None

    api_id = int(os.getenv("TELEGRAM_API_ID", "0"))
    api_hash = os.getenv("TELEGRAM_API_HASH", "")
    if not api_id or not api_hash:
        return None

    # Reuse existing client
    if _tg_client is not None:
        try:
            if not _tg_client.is_connected():
                await _tg_client.connect()
            if await _tg_client.is_user_authorized():
                return _tg_client
        except Exception:
            _tg_client = None

    # Create new client with saved session
    session_path = str(_config_dir() / "telegram")
    try:
        _tg_client = TelegramClient(session_path, api_id, api_hash)
        await _tg_client.connect()
        if await _tg_client.is_user_authorized():
            return _tg_client
    except Exception:
        pass

    return None


def _scrape_telegram_web(channel, limit=20):
    """Fallback: scrape public Telegram channel via t.me/s/ web preview"""
    username = channel.lstrip("@").strip()
    if "/" in username:
        username = username.split("/")[-1]

    try:
        resp = requests.get(
            f"{TELEGRAM_WEB_URL}{username}",
            timeout=15,
            headers={
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                              "AppleWebKit/537.36 (KHTML, like Gecko) "
                              "Chrome/120.0.0.0 Safari/537.36",
                "Accept-Language": "ko-KR,ko;q=0.9",
            },
        )
        if resp.status_code == 404:
            return {"success": False,
                    "error": f"@{username} not found or private",
                    "error_type": "NOT_FOUND"}
        resp.raise_for_status()

        messages = _parse_telegram_html(resp.text)
        return {
            "success": True,
            "channel": f"@{username}",
            "method": "web_scrape",
            "count": min(len(messages), limit),
            "messages": messages[-limit:] if len(messages) > limit else messages,
        }
    except requests.RequestException as e:
        return {"success": False, "error": str(e), "error_type": "REQUEST_ERROR"}


def _parse_telegram_html(html_text):
    """Parse t.me/s/ HTML for messages"""
    messages = []
    parts = re.split(r'(?=data-post=")', html_text)

    for part in parts:
        post_m = re.search(r'data-post="([^"]+/(\d+))"', part)
        if not post_m:
            continue

        post_id = post_m.group(1)
        msg_num = int(post_m.group(2))

        text_m = re.search(
            r'class="tgme_widget_message_text[^"]*"[^>]*>(.*?)</div>',
            part, re.DOTALL,
        )
        text = _strip_html(text_m.group(1)).strip() if text_m else ""
        if not text:
            continue

        time_m = re.search(r'datetime="([^"]+)"', part)
        views_m = re.search(
            r'class="tgme_widget_message_views"[^>]*>([^<]+)', part)

        is_ad_flag, _ = _is_ad(text)
        messages.append({
            "id": msg_num,
            "text": text[:2000],
            "date": time_m.group(1) if time_m else "",
            "views": views_m.group(1).strip() if views_m else "",
            "link": f"https://t.me/{post_id}",
            "is_ad": is_ad_flag,
        })

    return messages


# ─── Tools ────────────────────────────────────────────
def register_tools(registry, get_pg=None):
    """Register 8 news/telegram tools on ToolRegistry instance

    get_pg: 하위 호환성을 위해 유지하되 내부에서 무시 (SQLite 사용)
    """

    @registry.tool()
    def news_search(query: str, display: int = 10,
                    start: int = 1, sort: str = "date") -> dict:
        """Naver News API keyword search (general keyword)

        USE THIS WHEN: general news search ("반도체 수출", "금리 인상")
        DO NOT USE: stock-specific news → news_search_stock, stock price → datakit_call

        Args:
            query: Search keyword (e.g. "반도체 수출", "AI 규제")
            display: Results count (1-100, default 10)
            start: Start position (1-1000, pagination)
            sort: "date" (newest) or "sim" (relevance)

        Returns:
            {success, total, items: [{title, link, description, pubDate, source}]}

        Note:
            Requires NAVER_CLIENT_ID + NAVER_CLIENT_SECRET.
        """
        result = _naver_search(query, display, start, sort)
        try:
            _db_save("search", {"query": query, "display": display,
                                "start": start, "sort": sort}, result)
        except Exception:
            pass
        return result

    @registry.tool()
    def news_search_stock(stock_name: str, days: int = 7,
                          count: int = 20) -> dict:
        """Stock-specific news search with date filter + deduplication

        USE THIS WHEN: specific stock news ("삼성전자 뉴스", "SK하이닉스 최근 소식")
        DO NOT USE: general keyword → news_search, stock price → datakit_call

        Args:
            stock_name: Stock name (e.g. "삼성전자", "SK하이닉스")
            days: Recent N days only (default 7)
            count: Max results (default 20, max 100)

        Returns:
            {success, stock_name, period, count, items: [...]}
        """
        count = min(max(count, 1), 100)
        result = _naver_search(f'"{stock_name}"', display=count, sort="date")

        if not result.get("success"):
            return result

        cutoff = datetime.now() - timedelta(days=days)
        filtered = []
        seen = set()

        for item in result.get("items", []):
            # Date filter
            try:
                pub = datetime.strptime(
                    item["pubDate"], "%a, %d %b %Y %H:%M:%S %z")
                if pub.replace(tzinfo=None) < cutoff:
                    continue
            except (ValueError, KeyError):
                pass  # Include if parse fails

            # Dedup by title prefix
            title_key = re.sub(r'\s+', '', item.get("title", ""))[:30]
            if title_key in seen:
                continue
            seen.add(title_key)
            filtered.append(item)

        stock_result = {
            "success": True,
            "stock_name": stock_name,
            "period": f"{days}d",
            "count": len(filtered),
            "items": filtered,
        }
        try:
            _db_save("search_stock",
                     {"stock_name": stock_name, "days": days}, stock_result)
        except Exception:
            pass
        return stock_result

    @registry.tool()
    async def telegram_auth(action: str = "status",
                            code: str = "", password: str = "") -> dict:
        """Telegram authentication management

        Args:
            action: "status" / "send_code" / "verify" / "verify_2fa"
            code: SMS code (for action="verify")
            password: 2FA password (for action="verify_2fa")

        Returns:
            {success, status: "connected"/"code_sent"/"need_2fa"/"not_configured"}

        Flow:
            1. telegram_auth(action="status")
            2. telegram_auth(action="send_code")
            3. telegram_auth(action="verify", code="12345")
            4. (if 2FA) telegram_auth(action="verify_2fa", password="xxx")

        Note:
            Requires TELEGRAM_API_ID + TELEGRAM_API_HASH + TELEGRAM_PHONE.
            Get at https://my.telegram.org/
        """
        global _tg_client, _tg_phone_code_hash

        if not _HAS_TELETHON:
            return {"success": False, "status": "telethon_not_installed",
                    "error": "pip install telethon"}

        api_id = int(os.getenv("TELEGRAM_API_ID", "0"))
        api_hash = os.getenv("TELEGRAM_API_HASH", "")
        phone = os.getenv("TELEGRAM_PHONE", "")

        if not api_id or not api_hash:
            return {"success": False, "status": "not_configured",
                    "error": "Set TELEGRAM_API_ID + TELEGRAM_API_HASH"}

        session_path = str(_config_dir() / "telegram")

        async with _tg_lock:
            if action == "status":
                client = await _ensure_tg()
                if client:
                    me = await client.get_me()
                    return {"success": True, "status": "connected",
                            "user": me.first_name if me else "unknown"}
                return {"success": True, "status": "disconnected",
                        "telethon": True, "api_id_set": bool(api_id)}

            elif action == "send_code":
                if not phone:
                    return {"success": False,
                            "error": "Set TELEGRAM_PHONE env var"}

                if _tg_client is None:
                    _tg_client = TelegramClient(session_path, api_id, api_hash)
                if not _tg_client.is_connected():
                    await _tg_client.connect()

                result = await _tg_client.send_code_request(phone)
                _tg_phone_code_hash = result.phone_code_hash
                masked = phone[:4] + "****" + phone[-2:] if len(phone) > 6 else phone
                return {"success": True, "status": "code_sent", "phone": masked}

            elif action == "verify":
                if not code:
                    return {"success": False, "error": "code required"}
                if not _tg_client or not _tg_phone_code_hash:
                    return {"success": False, "error": "call send_code first"}

                try:
                    await _tg_client.sign_in(
                        phone, code, phone_code_hash=_tg_phone_code_hash)
                    return {"success": True, "status": "connected"}
                except Exception as e:
                    err = str(e)
                    etype = type(e).__name__
                    if "password" in err.lower() or "SessionPasswordNeeded" in etype:
                        return {"success": True, "status": "need_2fa"}
                    return {"success": False, "error": err}

            elif action == "verify_2fa":
                if not password:
                    return {"success": False, "error": "password required"}
                if not _tg_client:
                    return {"success": False, "error": "not connected"}

                try:
                    await _tg_client.sign_in(password=password)
                    return {"success": True, "status": "connected"}
                except Exception as e:
                    return {"success": False, "error": str(e)}

            return {"success": False, "error": f"unknown action: {action}"}

    @registry.tool()
    async def telegram_get_channels() -> dict:
        """List subscribed Telegram channels and groups

        Returns:
            {success, count, channels: [{id, title, username, type, unread}]}

        Note:
            Requires authenticated session (see telegram_auth).
        """
        async with _tg_lock:
            client = await _ensure_tg()
            if not client:
                return {"success": False,
                        "error": "Telegram not connected. Use telegram_auth."}

            try:
                channels = []
                async for dialog in client.iter_dialogs():
                    entity = dialog.entity
                    if isinstance(entity, (Channel, Chat)):
                        channels.append({
                            "id": str(dialog.id),
                            "title": dialog.title or dialog.name or "",
                            "username": getattr(entity, "username", None) or "",
                            "type": ("channel" if getattr(entity, "broadcast", False)
                                     else "group"),
                            "unread": dialog.unread_count or 0,
                        })

                return {"success": True, "count": len(channels),
                        "channels": channels}
            except Exception as e:
                return {"success": False, "error": str(e)}

    @registry.tool()
    async def telegram_get_messages(channel: str, limit: int = 20,
                                    filter_ads: bool = True,
                                    start_date: str = "",
                                    end_date: str = "") -> dict:
        """Get messages from a Telegram channel (stock tips, analyst posts)

        USE THIS WHEN: reading stock-related Telegram channels, analyst posts
        DO NOT USE: Naver news → news_search_stock, stock data → datakit_call

        Args:
            channel: Username (@name), ID, or URL (https://t.me/name)
            limit: Max messages (default 20, max 200)
            filter_ads: Auto-filter ad messages (default True)
            start_date: Start date (YYYY-MM-DD) for date range filtering
            end_date: End date (YYYY-MM-DD) for date range filtering

        Returns:
            {success, channel, method, count, messages: [{id, text, date, views, link}]}

        Note:
            Authenticated: all subscribed channels (Telethon).
            Not authenticated: public channels only (web scrape fallback).
        """
        from datetime import datetime, timezone
        if start_date and end_date:
            # 날짜 범위 크롤링: 제한 없이 전부 가져오기
            limit = max(limit, 1)
        else:
            limit = min(max(limit, 1), 200)

        # Try Telethon first
        async with _tg_lock:
            client = await _ensure_tg()
            if client:
                try:
                    username = channel.lstrip("@").strip()
                    if "/" in username:
                        username = username.split("/")[-1]

                    # 숫자 ID인 경우 int로 변환 (Telethon은 int ID 직접 처리 가능)
                    try:
                        entity = await client.get_entity(int(username))
                    except (ValueError, TypeError):
                        entity = await client.get_entity(username)
                    messages = []

                    if start_date and end_date:
                        iter_kwargs = {}  # 날짜 범위: 제한 없이 전부
                    else:
                        iter_kwargs = {"limit": limit * 2}
                    if end_date:
                        try:
                            ed = datetime.fromisoformat(end_date)
                            ed = ed.replace(hour=23, minute=59, second=59,
                                            tzinfo=timezone.utc)
                            iter_kwargs["offset_date"] = ed
                        except ValueError:
                            pass

                    sd = None
                    if start_date:
                        try:
                            sd = datetime.fromisoformat(start_date).replace(
                                tzinfo=timezone.utc)
                        except ValueError:
                            pass

                    async for msg in client.iter_messages(entity, **iter_kwargs):
                        if not msg.text:
                            continue

                        # 날짜 범위 필터: start_date 이전이면 종료
                        if sd and msg.date and msg.date.replace(
                                tzinfo=timezone.utc) < sd:
                            break

                        is_ad_flag, ad_reason = _is_ad(msg.text)
                        if filter_ads and is_ad_flag:
                            continue

                        messages.append({
                            "id": msg.id,
                            "text": msg.text[:2000],
                            "date": msg.date.isoformat() if msg.date else "",
                            "views": msg.views or 0,
                            "forwards": msg.forwards or 0,
                            "link": f"https://t.me/{username}/{msg.id}",
                            "is_ad": is_ad_flag,
                        })
                        if not (start_date and end_date) and len(messages) >= limit:
                            break

                    result = {
                        "success": True,
                        "channel": f"@{username}",
                        "method": "telethon",
                        "count": len(messages),
                        "messages": messages,
                    }
                    try:
                        _db_save("telegram",
                                 {"channel": channel, "limit": limit}, result)
                    except Exception:
                        pass
                    return result
                except Exception:
                    pass  # Fall through to web scraping

        # Fallback: web scraping (public channels only)
        result = _scrape_telegram_web(channel, limit)
        if result.get("success") and filter_ads:
            result["messages"] = [
                m for m in result["messages"] if not m.get("is_ad")]
            result["count"] = len(result["messages"])

        try:
            _db_save("telegram",
                     {"channel": channel, "limit": limit, "method": "web"},
                     result)
        except Exception:
            pass
        return result

    @registry.tool()
    async def telegram_send_message(target: str, text: str, parse_mode: str = "md") -> dict:
        """Send a message to a Telegram channel, group, or user

        USE THIS WHEN: sending analysis results, alerts, or summaries to Telegram
        DO NOT USE: reading messages -> telegram_get_messages

        Args:
            target: Channel username (@channel), channel ID, or "me" for Saved Messages
            text: Message text (Markdown supported: **bold**, _italic_, `code`)
            parse_mode: "md" for Markdown, "html" for HTML, "none" for plain text

        Returns:
            {success, message_id, target}

        Note:
            Requires authenticated Telegram session (see telegram_auth).
        """
        async with _tg_lock:
            client = await _ensure_tg()
            if not client:
                return {"success": False,
                        "error": "Telegram not connected. Use telegram_auth first."}

            try:
                if target == "me":
                    entity = await client.get_me()
                else:
                    username = target.lstrip("@").strip()
                    entity = await client.get_entity(username)

                pm = None if parse_mode == "none" else parse_mode
                msg = await client.send_message(entity, text, parse_mode=pm)
                return {"success": True, "message_id": msg.id, "target": target}
            except Exception as e:
                return {"success": False, "error": str(e)}

    @registry.tool()
    async def telegram_send_alert(target: str, stock_name: str,
                                  stock_code: str, alert_type: str,
                                  detail: str) -> dict:
        """Send a formatted stock alert to Telegram

        USE THIS WHEN: sending stock price alerts, surge notifications, condition matches
        DO NOT USE: general messages -> telegram_send_message

        Args:
            target: Channel username (@channel), channel ID, or "me"
            stock_name: Stock name (e.g. "삼성전자")
            stock_code: Stock code (e.g. "005930")
            alert_type: Alert category - one of:
                        "급등", "급락", "거래량폭증", "조건충족", "뉴스", "공시"
            detail: Alert detail text (price, volume, reason, etc.)

        Returns:
            {success, message_id, target}

        Note:
            Requires authenticated Telegram session (see telegram_auth).
        """
        emoji_map = {
            "급등": "\U0001f53a", "급락": "\U0001f53b",
            "거래량폭증": "\U0001f4ca", "조건충족": "\U0001f3af",
            "뉴스": "\U0001f4f0", "공시": "\U0001f4cb",
        }
        emoji = emoji_map.get(alert_type, "\u26a1")
        formatted = (
            f"{emoji} **[{alert_type}] {stock_name} ({stock_code})**\n\n"
            f"{detail}"
        )
        return await telegram_send_message(target=target, text=formatted)

    @registry.tool()
    def news_get_env_info() -> dict:
        """News & Telegram environment info

        Returns:
            {success, data: {naver_configured, telegram_telethon, telegram_connected, ...}}
        """
        naver_id = os.getenv("NAVER_CLIENT_ID", "")
        naver_secret = os.getenv("NAVER_CLIENT_SECRET", "")

        # Check numbered keys
        if not naver_id:
            for i in range(1, 11):
                if os.getenv(f"NAVER_NEWS_API_KEY_{i}_ID"):
                    naver_id = f"multi_key_{i}"
                    naver_secret = "set"
                    break

        tg_ok = (_tg_client is not None and _tg_client.is_connected()
                 if _tg_client else False)

        return {
            "success": True,
            "data": {
                "naver_configured": bool(naver_id and naver_secret),
                "naver_client_id": (naver_id[:8] + "..."
                                    if len(naver_id) > 8
                                    else ("set" if naver_id else "not set")),
                "telegram_telethon": _HAS_TELETHON,
                "telegram_api_id": ("set" if os.getenv("TELEGRAM_API_ID")
                                    else "not set"),
                "telegram_connected": tg_ok,
                "telegram_web_fallback": True,
                "ad_filter": "v2.5",
                "db_backend": "sqlite",
            },
        }


if __name__ == "__main__":
    from openclaw_stock_kit.tool_registry import ToolRegistry
    registry = ToolRegistry("News & Telegram")
    register_tools(registry)

    naver_ok = "configured" if os.getenv("NAVER_CLIENT_ID") else "not configured"
    tg_mode = "telethon" if _HAS_TELETHON else "web only"
    print("News & Telegram — standalone test")
    print(f"   Naver: {naver_ok}")
    print(f"   Telegram: {tg_mode}")
    print(f"   Tools: {[t['name'] for t in registry.list_tools()]}")
