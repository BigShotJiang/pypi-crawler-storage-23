from dependency_injector.wiring import Provide

from frogml._proto.qwak.deployment.alert_pb2 import (
    NotificationChannel,
    NotificationChannelSettings,
)
from frogml._proto.qwak.deployment.alert_service_pb2 import (
    ApplyNotificationChannelRequest,
    DeleteNotificationChannelRequest,
    GetNotificationChannelDetailsListRequest,
)
from frogml._proto.qwak.deployment.alert_service_pb2_grpc import (
    AlertManagementServiceStub,
)
from frogml.core.inner.di_configuration import FrogmlContainer
from frogml.core.inner.tool.grpc.grpc_try_wrapping import grpc_try_catch_wrapper


class AlertsManagementClient:
    def __init__(self, grpc_channel=Provide[FrogmlContainer.core_grpc_channel]):
        self._alerts_management_service = AlertManagementServiceStub(grpc_channel)

    @grpc_try_catch_wrapper(
        error_message="Failed to save notification channel {channel_name}",
        operation="Configure Notification Channel",
    )
    def configure_channel(
        self, channel_name: str, notification_settings: NotificationChannelSettings
    ):
        self._alerts_management_service.ApplyNotificationChannel(
            ApplyNotificationChannelRequest(
                notification_channel=NotificationChannel(
                    notification_channel_name=channel_name,
                    notification_settings=notification_settings,
                ),
            )
        )

    @grpc_try_catch_wrapper(
        error_message="Failed to fetch notification channels",
        operation="List Notification Channels",
    )
    def list_channels(self):
        return self._alerts_management_service.GetNotificationChannelDetailsList(
            GetNotificationChannelDetailsListRequest()
        )

    @grpc_try_catch_wrapper(
        error_message="Failed to delete notification channel {notification_channel_id}",
        operation="Delete Notification Channel",
    )
    def delete_channel(self, notification_channel_id):
        self._alerts_management_service.DeleteNotificationChannel(
            DeleteNotificationChannelRequest(
                notification_channel_id=notification_channel_id
            )
        )
