from __future__ import annotations

from http import HTTPStatus

from dependency_injector.wiring import Provide

from frogml._proto.qwak.deployment.deployment_pb2 import (
    DeploymentHostingServiceType,
    EnvironmentDeploymentMessage,
    EnvironmentUndeploymentMessage,
    RuntimeDeploymentSettings,
    Variation,
)
from frogml._proto.qwak.deployment.deployment_service_pb2 import (
    ApplyModelTrafficRequest,
    DeployModelRequest,
    GetDeploymentDetailsRequest,
    GetDeploymentDetailsResponse,
    GetDeploymentHistoryRequest,
    GetDeploymentHistoryResponse,
    GetDeploymentStatusRequest,
    GetDeploymentStatusResponse,
    GetModelTrafficRequest,
    GetModelTrafficResponse,
    UndeployModelRequest,
    UndeployModelResponse,
    UpdateDeploymentRuntimeSettingsRequest,
    UpdateDeploymentRuntimeSettingsResponse,
)
from frogml._proto.qwak.deployment.deployment_service_pb2_grpc import (
    DeploymentManagementServiceStub,
)
from frogml.core.exceptions import FrogmlException, FrogmlNotFoundException
from frogml.core.inner.di_configuration import FrogmlContainer
from frogml.core.inner.tool.grpc.grpc_try_wrapping import grpc_try_catch_wrapper


class DeploymentManagementClient:
    def __init__(self, grpc_channel=Provide[FrogmlContainer.core_grpc_channel]):
        self.deployment_management = DeploymentManagementServiceStub(grpc_channel)

    @grpc_try_catch_wrapper(
        error_message="Failed to deploy model {model_id}",
        operation="Deploy Model",
    )
    def deploy_model(
        self,
        model_id: str,
        build_id: str,
        env_deployment_messages: dict[str, EnvironmentDeploymentMessage],
    ):
        request = DeployModelRequest(
            model_id=model_id,
            build_id=build_id,
            hosting_service=list(env_deployment_messages.values())[0].hosting_service,
            environment_to_deployment=env_deployment_messages,
        )

        deployment_result = self.deployment_management.DeployModel(
            request,
            timeout=40,
        )

        return deployment_result

    @grpc_try_catch_wrapper(
        error_message="Failed to get model status for deployment {deployment_named_id}",
        operation="Get Deployment Status",
    )
    def get_deployment_status(
        self, deployment_named_id: str
    ) -> GetDeploymentStatusResponse:
        return self.deployment_management.GetDeploymentStatus(
            GetDeploymentStatusRequest(
                deployment_named_id=deployment_named_id,
                hosting_service_type=DeploymentHostingServiceType.KUBE_DEPLOYMENT,
            )
        )

    @grpc_try_catch_wrapper(
        error_message="Failed to get model status for model {model_id}",
        operation="Get Deployment Details",
    )
    def get_deployment_details(
        self, model_id: str, model_uuid: str, **kwargs
    ) -> GetDeploymentDetailsResponse:
        _model_uuid = model_uuid if model_uuid else kwargs.get("branch_id")
        if not _model_uuid:
            raise FrogmlException(
                error_message="Missing argument model uuid or branch id",
                operation="Get Deployment Details",
                status_code=HTTPStatus.BAD_REQUEST,
            )

        return self.deployment_management.GetDeploymentDetails(
            GetDeploymentDetailsRequest(
                model_id=model_id,
                model_uuid=_model_uuid,
            )
        )

    @grpc_try_catch_wrapper(
        error_message="Failed to undeploy model {model_id}",
        operation="Undeploy Model",
    )
    def undeploy_model(
        self,
        model_id: str,
        model_uuid: str,
        env_undeployment_requests: dict[str, EnvironmentUndeploymentMessage],
    ) -> UndeployModelResponse:
        undeployment_result = self.deployment_management.UndeployModel(
            UndeployModelRequest(
                model_id=model_id,
                model_uuid=model_uuid,
                hosting_service_type=DeploymentHostingServiceType.KUBE_DEPLOYMENT,
                environment_to_undeployment=env_undeployment_requests,
            )
        )

        return undeployment_result

    @grpc_try_catch_wrapper(
        error_message="Failed to update runtime settings for model {model_id}",
        operation="Update Runtime Settings",
    )
    def update_runtime_configurations(
        self, model_id: str, model_uuid: str, log_level: str
    ) -> UpdateDeploymentRuntimeSettingsResponse:
        return self.deployment_management.UpdateDeploymentRuntimeSettings(
            UpdateDeploymentRuntimeSettingsRequest(
                model_id=model_id,
                model_uuid=model_uuid,
                deployment_settings=RuntimeDeploymentSettings(
                    root_logger_level=RuntimeDeploymentSettings.LogLevel.Value(
                        log_level
                    )
                ),
            )
        )

    @grpc_try_catch_wrapper(
        error_message="Failed to get model traffic for model {model_id}",
        operation="Get Model Traffic",
    )
    def get_model_traffic_config(self, model_id: str) -> GetModelTrafficResponse:
        return self.deployment_management.GetModelTraffic(
            GetModelTrafficRequest(
                model_id=model_id,
            )
        )

    def get_deployed_variations_to_build_id(
        self, model_id: str, model_uuid: str
    ) -> dict[str, str]:
        deployment_details = self.get_deployment_details(
            model_id=model_id, model_uuid=model_uuid
        )
        if not deployment_details:
            raise FrogmlNotFoundException(
                error_message=f"There are currently no deployed variations for model {model_id}",
                operation="Get Deployed Variations",
            )

        return {
            deployment.variation.name: deployment.build_id
            for deployment in deployment_details.current_deployments_details
        }

    @grpc_try_catch_wrapper(
        error_message="Failed to apply model traffic for model {model_id}",
        operation="Apply Model Traffic",
    )
    def apply_model_traffic_config(
        self,
        model_id: str,
        requested_variations: list[Variation],
        environment_ids: list[str],
    ) -> GetDeploymentStatusResponse:
        return self.deployment_management.ApplyModelTraffic(
            ApplyModelTrafficRequest(
                model_id=model_id,
                variations=requested_variations,
                environment_ids=environment_ids,
            )
        )

    @grpc_try_catch_wrapper(
        error_message="Failed to get deployment history",
        operation="Get Deployment History",
    )
    def get_deployment_history(
        self, model_uuid: str = None, build_id: str = None
    ) -> GetDeploymentHistoryResponse:
        return self.deployment_management.GetDeploymentHistory(
            GetDeploymentHistoryRequest(model_uuid=model_uuid, build_id=build_id)
        )
