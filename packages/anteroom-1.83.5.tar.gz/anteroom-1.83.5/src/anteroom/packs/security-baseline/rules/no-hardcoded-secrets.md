# No Hardcoded Secrets

Never hardcode secrets, API keys, passwords, or tokens in source code.

- Use environment variables or secrets managers
- Never commit `.env` files with real credentials
- No credentials in URLs, logs, or error messages
- Use placeholder values in examples and tests
