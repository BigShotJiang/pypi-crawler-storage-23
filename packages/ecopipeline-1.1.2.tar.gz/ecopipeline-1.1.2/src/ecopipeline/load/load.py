import configparser
import mysql.connector
import mysql.connector.cursor
import sys
import pandas as pd
import os
import math
pd.set_option('display.max_columns', None)
import mysql.connector.errors as mysqlerrors
from ecopipeline import ConfigManager
from datetime import datetime, timedelta
import numpy as np

data_map = {'int64':'float',
            'int32':'float',
            'float64': 'float',
            'M8[ns]':'datetime',
            'datetime64[ns]':'datetime',
            'object':'varchar(25)',
            'bool': 'boolean'}

def check_table_exists(cursor : mysql.connector.cursor.MySQLCursor, table_name: str, dbname: str) -> int:
    """
    Check if the given table name already exists in database.

    Parameters
    ---------- 
    cursor : mysql.connector.cursor.MySQLCursor
        Database cursor object and the table name.
    table_name : str 
        Name of the table
    dbname : str
        Name of the database

    Returns
    ------- 
    int: 
        The number of tables in the database with the given table name.
        This can directly be used as a boolean!
    """

    cursor.execute(f"SELECT count(*) "
                   f"FROM information_schema.TABLES "
                   f"WHERE (TABLE_SCHEMA = '{dbname}') AND (TABLE_NAME = '{table_name}')")

    num_tables = cursor.fetchall()[0][0]
    return num_tables


def create_new_table(cursor : mysql.connector.cursor.MySQLCursor, table_name: str, table_column_names: list, table_column_types: list, primary_key: str = "time_pt", has_primary_key : bool = True) -> bool:
    """
    Creates a new table in the mySQL database.

    Parameters
    ---------- 
    cursor : mysql.connector.cursor.MySQLCursor
        A cursor object and the name of the table to be created.
    table_name : str
        Name of the table
    table_column_names : list
        list of columns names in the table must be passed.
    primary_key: str
        The name of the primary index of the table. Should be a datetime. If has_primary_key is set to False, this will just be a column not a key.
    has_primary_key : bool
        Set to False if the table should not establish a primary key. Defaults to True

    Returns
    ------- 
    bool: 
        A boolean value indicating if a table was sucessfully created. 
    """
    if(len(table_column_names) != len(table_column_types)):
        raise Exception("Cannot create table. Type list and Field Name list are different lengths.")

    create_table_statement = f"CREATE TABLE {table_name} (\n{primary_key} datetime,\n"

    for i in range(len(table_column_names)):
        create_table_statement += f"{table_column_names[i]} {table_column_types[i]} DEFAULT NULL,\n"
    if has_primary_key:
        create_table_statement += f"PRIMARY KEY ({primary_key})\n"

    create_table_statement += ");"
    cursor.execute(create_table_statement)

    return True


def find_missing_columns(cursor : mysql.connector.cursor.MySQLCursor, dataframe: pd.DataFrame, config_dict: dict, table_name: str):
    """
    Finds the column names which are not in the database table currently but are present
    in the pandas DataFrame to be written to the database. If communication with database
    is not possible, an empty list will be returned meaning no column will be added. 

    Parameters
    ---------- 
    cursor : mysql.connector.cursor.MySQLCursor 
        A cursor object and the name of the table to be created.
    dataframe : pd.DataFrame
        the pandas DataFrame to be written into the mySQL server. 
    config_info : dict
        The dictionary containing the configuration information 
    data_type : str
        the header name corresponding to the table you wish to write data to.  

    Returns
    ------- 
    list: 
        list of column names which must be added to the database table for the pandas 
        DataFrame to be properly written into the database. 
    """

    try:
        cursor.execute(f"SELECT column_name FROM information_schema.columns WHERE table_schema = '"
                            f"{config_dict['database']}' AND table_name = '"
                            f"{table_name}'")
    except mysqlerrors.DatabaseError as e:
        print("Check if the mysql table to be written to exists.", e)
        return [], []
    
    current_table_names = list(cursor.fetchall())
    current_table_names = [name[0] for name in current_table_names]
    df_names = list(dataframe.columns)
    
    cols_to_add = [sensor_name for sensor_name in df_names if sensor_name not in current_table_names]
    data_types = [dataframe[column].dtype.name for column in cols_to_add]
    
    data_types = [data_map[data_type] for data_type in data_types]
    
    return cols_to_add, data_types


def create_new_columns(cursor : mysql.connector.cursor.MySQLCursor, table_name: str, new_columns: list, data_types: str):
    """
    Create the new, necessary column in the database. Catches error if communication with mysql database
    is not possible.

    Parameters
    ----------  
    cursor : mysql.connector.cursor.MySQLCursor
        A cursor object and the name of the table to be created.
    config_info : dict
        The dictionary containing the configuration information.
    data_type : str
        the header name corresponding to the table you wish to write data to.  
    new_columns : list
        list of columns that must be added to the database table.

    Returns
    ------- 
    bool:
        boolean indicating if the the column were successfully added to the database. 
    """
    alter_table_statements = [f"ALTER TABLE {table_name} ADD COLUMN {column} {data_type} DEFAULT NULL;" for column, data_type in zip(new_columns, data_types)]

    for sql_statement in alter_table_statements:
        try:
            cursor.execute(sql_statement)
        except mysqlerrors.DatabaseError as e:
            print(f"Error communicating with the mysql database: {e}")
            return False

    return True

def load_overwrite_database(config : ConfigManager, dataframe: pd.DataFrame, config_info: dict, data_type: str, 
                            primary_key: str = "time_pt", table_name: str = None, auto_log_data_loss : bool = False,
                            config_key : str = "minute"):
    """
    Loads given pandas DataFrame into a MySQL table overwriting any conflicting data. Uses an UPSERT strategy to ensure any gaps in data are filled.
    Note: will not overwrite values with NULL. Must have a new value to overwrite existing values in database

    Parameters
    ----------  
    config : ecopipeline.ConfigManager
        The ConfigManager object that holds configuration data for the pipeline.
    dataframe: pd.DataFrame
        The pandas DataFrame to be written into the mySQL server.
    config_info: dict
        The dictionary containing the configuration information in the data upload. This can be aquired through the get_login_info() function in this package
    data_type: str
        The header name corresponding to the table you wish to write data to. 
    primary_key : str
        The name of the primary key in the database to upload to. Default as 'time_pt'
    table_name : str
        overwrites table name from config_info if needed
    auto_log_data_loss : bool
        if set to True, a data loss event will be reported if no data exits in the dataframe 
        for the last two days from the current date OR if an error occurs
    config_key : str 
        The key in the config.ini file that points to the minute table data for the site. The name of this table is also the site name.
        

    Returns
    ------- 
    bool: 
        A boolean value indicating if the data was successfully written to the database. 
    """
    # Database Connection
    db_connection, cursor = config.connect_db()
    try:

        # Drop empty columns
        dataframe = dataframe.dropna(axis=1, how='all')

        dbname = config_info['database']
        if table_name == None:
            table_name = config_info[data_type]["table_name"]   
        
        if(len(dataframe.index) <= 0):
            print(f"Attempted to write to {table_name} but dataframe was empty.")
            ret_value = True
        else:

            print(f"Attempting to write data for {dataframe.index[0]} to {dataframe.index[-1]} into {table_name}")
            if auto_log_data_loss and dataframe.index[-1] < datetime.now() - timedelta(days=3):
                report_data_loss(config, config.get_site_name(config_key))
            
            # Get string of all column names for sql insert
            sensor_names = primary_key
            sensor_types = ["datetime"]
            for column in dataframe.columns:
                sensor_names += "," + column    
                sensor_types.append(data_map[dataframe[column].dtype.name])

            # create SQL statement
            insert_str = "INSERT INTO " + table_name + " (" + sensor_names + ") VALUES ("
            for column in dataframe.columns:
                insert_str += "%s, "
            insert_str += "%s)"
            
            # last_time = datetime.strptime('20/01/1990', "%d/%m/%Y") # arbitrary past date
            existing_rows_list = []

            # create db table if it does not exist, otherwise add missing columns to existing table
            if not check_table_exists(cursor, table_name, dbname):
                if not create_new_table(cursor, table_name, sensor_names.split(",")[1:], sensor_types[1:], primary_key=primary_key): #split on colums and remove first column aka time_pt
                    ret_value = False
                    raise Exception(f"Could not create new table {table_name} in database {dbname}")
            else:
                try:
                    # find existing times in database for upsert statement
                    cursor.execute(
                        f"SELECT {primary_key} FROM {table_name} WHERE {primary_key} >= '{dataframe.index.min()}'")
                    # Fetch the results into a DataFrame
                    existing_rows = pd.DataFrame(cursor.fetchall(), columns=[primary_key])

                    # Convert the primary_key column to a list
                    existing_rows_list = existing_rows[primary_key].tolist()

                except mysqlerrors.Error:
                    print(f"Table {table_name} has no data.")

                missing_cols, missing_types = find_missing_columns(cursor, dataframe, config_info, table_name)
                if len(missing_cols):
                    if not create_new_columns(cursor, table_name, missing_cols, missing_types):
                        print("Unable to add new columns due to database error.")
            
            updatedRows = 0
            for index, row in dataframe.iterrows():
                time_data = row.values.tolist()
                #remove nans and infinites
                time_data = [None if (x is None or pd.isna(x)) else x for x in time_data]
                time_data = [None if (x == float('inf') or x == float('-inf')) else x for x in time_data]

                if index in existing_rows_list:
                    statement, values = _generate_mysql_update(row, index, table_name, primary_key)
                    if statement != "":
                        cursor.execute(statement, values)
                        updatedRows += 1
                else:
                    cursor.execute(insert_str, (index, *time_data))

            db_connection.commit()
            print(f"Successfully wrote {len(dataframe.index)} rows to table {table_name} in database {dbname}. {updatedRows} existing rows were overwritten.")
            ret_value = True
    except Exception as e:
        print(f"Unable to load data into database. Exception: {e}")
        if auto_log_data_loss:
            report_data_loss(config, config.get_site_name(config_key))
        ret_value = False

    db_connection.close()
    cursor.close()
    return ret_value


def load_event_table(config : ConfigManager, event_df: pd.DataFrame, site_name : str = None):
    """
    Loads given pandas DataFrame into a MySQL table overwriting any conflicting data. Uses an UPSERT strategy to ensure any gaps in data are filled.
    Note: will not overwrite values with NULL. Must have a new value to overwrite existing values in database

    Parameters
    ----------  
    config : ecopipeline.ConfigManager
        The ConfigManager object that holds configuration data for the pipeline.
    event_df: pd.DataFrame
        The pandas DataFrame to be written into the mySQL server. Must have columns event_type and event_detail 
    site_name : str
        the name of the site to correspond the events with. If left blank will default to minute table name

    Returns
    ------- 
    bool: 
        A boolean value indicating if the data was successfully written to the database. 
    """
    if event_df.empty:
        print("No events to load. DataFrame is empty.")
        return True
    if site_name is None:
        site_name = config.get_site_name()
    if 'alarm_type' in event_df.columns:
        print("Alarm dataframe detected... redirecting dataframe to load_alarms() function...")
        return load_alarms(config, event_df, site_name)
    # define constants
    proj_cop_filters = ['MV_COMMISSIONED','PLANT_COMMISSIONED','DATA_LOSS_COP','SYSTEM_MAINTENANCE','SYSTEM_TESTING']
    optim_cop_filters = ['MV_COMMISSIONED','PLANT_COMMISSIONED','DATA_LOSS_COP','INSTALLATION_ERROR_COP',
                            'PARTIAL_OCCUPANCY','SOO_PERIOD_COP','SYSTEM_TESTING','EQUIPMENT_MALFUNCTION',
                            'SYSTEM_MAINTENANCE']
    # Drop empty columns
    event_df = event_df.dropna(axis=1, how='all')

    dbname = config.get_db_name()
    table_name = "site_events"   
    
    if(len(event_df.index) <= 0):
        print(f"Attempted to write to {table_name} but dataframe was empty.")
        return True

    print(f"Attempting to write data for {event_df.index[0]} to {event_df.index[-1]} into {table_name}")
    
    # Get string of all column names for sql insert
    column_names = f"start_time_pt,site_name"
    column_types = ["datetime","varchar(25)","datetime",
                    "ENUM('MISC_EVENT','DATA_LOSS','DATA_LOSS_COP','SITE_VISIT','SYSTEM_MAINTENANCE','EQUIPMENT_MALFUNCTION','PARTIAL_OCCUPANCY','INSTALLATION_ERROR','ALARM','SILENT_ALARM','MV_COMMISSIONED','PLANT_COMMISSIONED','INSTALLATION_ERROR_COP','SOO_PERIOD','SOO_PERIOD_COP','SYSTEM_TESTING')",
                    "varchar(800)"]
    column_list = ['end_time_pt','event_type', 'event_detail']
    if not set(column_list).issubset(event_df.columns):
        raise Exception(f"event_df should contain a dataframe with columns start_time_pt, end_time_pt, event_type, and event_detail. Instead, found dataframe with columns {event_df.columns}")

    for column in column_list:
        column_names += "," + column

    # create SQL statement
    insert_str = "INSERT INTO " + table_name + " (" + column_names + ", variable_name, summary_filtered, optim_filtered, last_modified_date, last_modified_by) VALUES (%s, %s, %s,%s,%s,%s,%s,%s,'"+datetime.now().strftime('%Y-%m-%d %H:%M:%S')+"','automatic_upload')"

    if not 'variable_name' in event_df.columns:
        event_df['variable_name'] = None
    # add aditional columns for db creation
    full_column_names = column_names.split(",")[1:]
    full_column_names.append('last_modified_date')
    full_column_names.append('last_modified_by')
    full_column_names.append('variable_name')
    full_column_names.append('summary_filtered')
    full_column_names.append('optim_filtered')

    full_column_types = column_types[1:]
    full_column_types.append('datetime')
    full_column_types.append('varchar(60)')
    full_column_types.append('varchar(70)')
    full_column_types.append('tinyint(1)')
    full_column_types.append('tinyint(1)')

    existing_rows = pd.DataFrame({
        'start_time_pt' : [],
        'end_time_pt' : [],
        'event_type' : [],
        'variable_name' : [],
        'last_modified_by' : []
    })

    connection, cursor = config.connect_db() 

    # create db table if it does not exist, otherwise add missing columns to existing table
    if not check_table_exists(cursor, table_name, dbname):
        if not create_new_table(cursor, table_name, full_column_names, full_column_types, primary_key='start_time_pt', has_primary_key=False): #split on colums and remove first column aka time_pt
            print(f"Could not create new table {table_name} in database {dbname}")
            return False
    else:
        try:
            # find existing times in database for upsert statement
            cursor.execute(
                f"SELECT id, start_time_pt, end_time_pt, event_detail, event_type, variable_name, last_modified_by FROM {table_name} WHERE start_time_pt >= '{event_df.index.min()}' AND site_name = '{site_name}'")
            # Fetch the results into a DataFrame
            existing_rows = pd.DataFrame(cursor.fetchall(), columns=['id','start_time_pt', 'end_time_pt', 'event_detail', 'event_type', 'variable_name', 'last_modified_by'])
            existing_rows['start_time_pt'] = pd.to_datetime(existing_rows['start_time_pt'])
            existing_rows['end_time_pt'] = pd.to_datetime(existing_rows['end_time_pt'])

        except mysqlerrors.Error as e:
            print(f"Retrieving data from {table_name} caused exception: {e}")
    
    updatedRows = 0
    ignoredRows = 0
    try:
        for index, row in event_df.iterrows():
            time_data = [index,site_name,row['end_time_pt'],row['event_type'],row['event_detail'],row['variable_name'], row['event_type'] in proj_cop_filters, row['event_type'] in optim_cop_filters]
            #remove nans and infinites
            time_data = [None if (x is None or pd.isna(x)) else x for x in time_data]
            time_data = [None if (x == float('inf') or x == float('-inf')) else x for x in time_data]
            filtered_existing_rows = existing_rows[
                (existing_rows['start_time_pt'] == index) &
                (existing_rows['event_type'] == row['event_type'])
            ]
            if not time_data[-1] is None and not filtered_existing_rows.empty:
                # silent alarm only
                filtered_existing_rows = filtered_existing_rows[(filtered_existing_rows['variable_name'] == row['variable_name']) &
                                                                (filtered_existing_rows['event_detail'].str[:20] == row['event_detail'][:20])] # the [:20] part is a bug fix for partial days for silent alarms 

            if not filtered_existing_rows.empty:
                first_matching_row = filtered_existing_rows.iloc[0]  # Retrieves the first row
                statement, values = _generate_mysql_update_event_table(row, first_matching_row['id'])
                if statement != "" and first_matching_row['last_modified_by'] == 'automatic_upload':
                    cursor.execute(statement, values)
                    updatedRows += 1
                else:
                    ignoredRows += 1
            else:
                cursor.execute(insert_str, time_data)
        connection.commit()
        print(f"Successfully wrote {len(event_df.index) - ignoredRows} rows to table {table_name} in database {dbname}. {updatedRows} existing rows were overwritten.")
    except Exception as e:
        # Print the exception message
        print(f"Caught an exception when uploading to site_events table: {e}")
    connection.close()
    cursor.close()
    return True

def report_data_loss(config : ConfigManager, site_name : str = None):
    """
    Logs data loss event in event database (assumes one exists) as a DATA_LOSS_COP event to 
    note that COP calculations have been effected

    Parameters
    ----------  
    config : ecopipeline.ConfigManager
        The ConfigManager object that holds configuration data for the pipeline.
    site_name : str
        the name of the site to correspond the events with. If left blank will default to minute table name

    Returns
    ------- 
    bool: 
        A boolean value indicating if the data was successfully written to the database. 
    """
    # Drop empty columns

    dbname = config.get_db_name()
    table_name = "site_events"
    if site_name is None:
        site_name = config.get_site_name()
    error_string = "Error processing data. Please check logs to resolve."

    print(f"logging DATA_LOSS_COP into {table_name}")

    # create SQL statement
    insert_str = "INSERT INTO " + table_name + " (start_time_pt, site_name, event_detail, event_type, summary_filtered, optim_filtered, last_modified_date, last_modified_by) VALUES "
    insert_str += f"('{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}','{site_name}','{error_string}','DATA_LOSS_COP', true, true, '{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}','automatic_upload')"

    existing_rows = pd.DataFrame({
        'id' : []
    })

    connection, cursor = config.connect_db() 

    # create db table if it does not exist, otherwise add missing columns to existing table
    if not check_table_exists(cursor, table_name, dbname):
        print(f"Cannot log data loss. {table_name} does not exist in database {dbname}")
        return False
    else:
        try:
            # find existing times in database for upsert statement
            cursor.execute(
                f"SELECT id FROM {table_name} WHERE end_time_pt IS NULL AND site_name = '{site_name}' AND event_type = 'DATA_LOSS_COP'")
            # Fetch the results into a DataFrame
            existing_rows = pd.DataFrame(cursor.fetchall(), columns=['id'])

        except mysqlerrors.Error as e:
            print(f"Retrieving data from {table_name} caused exception: {e}")
    try:
        
        if existing_rows.empty:
            cursor.execute(insert_str)
            connection.commit()
            print("Successfully logged data loss.")
        else:
            print("Data loss already logged.")
    except Exception as e:
        # Print the exception message
        print(f"Caught an exception when uploading to site_events table: {e}")
    connection.close()
    cursor.close()
    return True

def load_data_statistics(config : ConfigManager, daily_stats_df : pd.DataFrame, config_daily_indicator : str = "day", custom_table_name : str = None):
    """
    Logs data statistics for the site in a table with name "{daily table name}_stats"

    Parameters
    ----------  
    config : ecopipeline.ConfigManager
        The ConfigManager object that holds configuration data for the pipeline.
    daily_stats_df : pd.DataFrame
        dataframe created by the create_data_statistics_df() function in ecopipeline.transform
    config_daily_indicator : str
        the indicator of the daily_table name in the config.ini file of the data pipeline
    custom_table_name : str
        custom table name for data statistics. Overwrites the name "{daily table name}_stats" to your custom name. 
        In this sense config_daily_indicator's pointer is no longer used. 

    Returns
    ------- 
    bool: 
        A boolean value indicating if the data was successfully written to the database. 
    """
    table_name = custom_table_name
    if table_name is None:
        table_name = f"{config.get_table_name(config_daily_indicator)}_stats"
    return load_overwrite_database(config, daily_stats_df, config.get_db_table_info([]), config_daily_indicator, table_name=table_name)

def _generate_mysql_update_event_table(row, id):
    statement = f"UPDATE site_events SET "
    statment_elems = []
    values = []
    for column, value in row.items():
        if not value is None and not pd.isna(value) and not (value == float('inf') or value == float('-inf')):
            statment_elems.append(f"{column} = %s")
            values.append(value)

    if values:
        statement += ", ".join(statment_elems)
        statement += f", last_modified_by = 'automatic_upload', last_modified_date = '{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}'"
        statement += f" WHERE id = {id};"
        # statement += f" WHERE start_time_pt = '{start_time_pt}' AND end_time_pt = '{end_time_pt}' AND event_type = '{event_type}' AND site_name = '{site_name}';"
    else:
        statement = ""

    return statement, values

def _generate_mysql_update(row, index, table_name, primary_key):
    statement = f"UPDATE {table_name} SET "
    statment_elems = []
    values = []
    for column, value in row.items():
        if not value is None and not pd.isna(value) and not (value == float('inf') or value == float('-inf')):
            statment_elems.append(f"{column} = %s")
            values.append(value)

    if values:
        statement += ", ".join(statment_elems)
        statement += f" WHERE {primary_key} = '{index}';"
    else:
        statement = ""

    return statement, values


def load_alarms(config: ConfigManager, alarm_df: pd.DataFrame, site_name: str = None) -> bool:
    """
    Loads alarm data from central_alarm_df_creator() output into the alarm and alarm_inst tables.

    For each alarm instance in the DataFrame:
    - Checks if a matching alarm record exists (same site_name, alarm_type, variable_name)
    - If no matching alarm exists, creates a new record in the alarm table
    - Inserts the alarm instance (with start/end times and certainty) into the alarm_inst table

    Certainty-based overlap handling for alarm instances:
    - If new alarm has higher certainty than existing overlapping instance: existing is split
      around the new alarm so each time segment has the highest certainty available
    - If new alarm has lower certainty than existing: only non-overlapping portions of new
      alarm are inserted
    - If same certainty: existing instance is extended to encompass both time periods

    Parameters
    ----------
    config : ecopipeline.ConfigManager
        The ConfigManager object that holds configuration data for the pipeline.
    alarm_df : pd.DataFrame
        The pandas DataFrame output from central_alarm_df_creator(). Must have columns:
        start_time_pt, end_time_pt, alarm_type, variable_name. Optional column: certainty
        (defaults to 3 if not present). Certainty values: 3=high, 2=med, 1=low.
    site_name : str
        The name of the site to associate alarms with. If None, defaults to config.get_site_name()

    Returns
    -------
    bool:
        A boolean value indicating if the data was successfully written to the database.
    """
    if alarm_df.empty:
        print("No alarms to load. DataFrame is empty.")
        return True

    # Validate required columns
    required_columns = ['start_time_pt', 'end_time_pt', 'alarm_type', 'variable_name']
    missing_columns = [col for col in required_columns if col not in alarm_df.columns]
    if missing_columns:
        raise Exception(f"alarm_df is missing required columns: {missing_columns}")

    # Sort by start_time_pt to process alarms in chronological order
    alarm_df = alarm_df.sort_values(by='start_time_pt').reset_index(drop=True)

    if site_name is None:
        site_name = config.get_site_name()

    dbname = config.get_db_name()
    alarm_table = "alarm"
    alarm_inst_table = "alarm_inst"

    connection, cursor = config.connect_db()

    try:
        # Check if tables exist
        if not check_table_exists(cursor, alarm_table, dbname):
            create_table_statement = """
                CREATE TABLE alarm (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    var_names_id VARCHAR(40),
                    start_time_pt DATETIME NOT NULL,
                    end_time_pt DATETIME NULL,
                    site_name VARCHAR(20),
                    alarm_type VARCHAR(20),
                    variable_name VARCHAR(70),
                    silenced BOOLEAN,
                    closing_event_id INT NULL,
                    FOREIGN KEY (closing_event_id) REFERENCES site_events(id),
                    UNIQUE INDEX unique_alarm (site_name, alarm_type, variable_name, start_time_pt, end_time_pt)
                );
                """
            cursor.execute(create_table_statement)
        if not check_table_exists(cursor, alarm_inst_table, dbname):
            create_table_statement = """
            CREATE TABLE alarm_inst (
                inst_id INT AUTO_INCREMENT PRIMARY KEY,
                id INT,
                start_time_pt DATETIME NOT NULL,
                end_time_pt DATETIME NOT NULL,
                certainty INT NOT NULL,
                FOREIGN KEY (id) REFERENCES alarm(id)
            );
            """
            cursor.execute(create_table_statement)

        # Get existing alarms for this site
        cursor.execute(
            f"SELECT id, alarm_type, variable_name, start_time_pt, end_time_pt FROM {alarm_table} WHERE site_name = %s",
            (site_name,)
        )
        existing_alarms = cursor.fetchall()
        # Create lookup dict: (alarm_type, variable_name) -> list of (alarm_id, start_time, end_time)
        # Using a list because there can be multiple alarms with same type/variable but different date ranges
        alarm_lookup = {}
        for row in existing_alarms:
            key = (row[1], row[2])  # (alarm_type, variable_name)
            if key not in alarm_lookup:
                alarm_lookup[key] = []
            alarm_lookup[key].append({
                'id': row[0],
                'start_time': row[3],
                'end_time': row[4]
            })

        # SQL statements
        insert_alarm_sql = f"""
            INSERT INTO {alarm_table} (var_names_id, start_time_pt, end_time_pt, site_name, alarm_type, variable_name, silenced)
            VALUES (%s, %s, %s, %s, %s, %s, %s)
        """
        update_alarm_dates_sql = f"""
            UPDATE {alarm_table} SET start_time_pt = %s, end_time_pt = %s WHERE id = %s
        """
        insert_inst_sql = f"""
            INSERT INTO {alarm_inst_table} (id, start_time_pt, end_time_pt, certainty)
            VALUES (%s, %s, %s, %s)
        """
        update_inst_sql = f"""
            UPDATE {alarm_inst_table} SET start_time_pt = %s, end_time_pt = %s WHERE inst_id = %s
        """
        delete_inst_sql = f"""
            DELETE FROM {alarm_inst_table} WHERE inst_id = %s
        """

        new_alarms = 0
        updated_alarms = 0
        new_instances = 0
        updated_instances = 0
        max_gap_days = 3

        for _, row in alarm_df.iterrows():
            start_time = row['start_time_pt']
            end_time = row['end_time_pt']
            alarm_type = row['alarm_type']
            variable_name = row['variable_name']
            certainty = row.get('certainty', 3)  # Default to high certainty if not specified

            lookup_key = (alarm_type, variable_name)
            alarm_id = None

            if lookup_key in alarm_lookup:
                # Find matching alarm based on date range logic
                for alarm_record in alarm_lookup[lookup_key]:
                    alarm_start = alarm_record['start_time']
                    alarm_end = alarm_record['end_time']

                    # Case 1: Alarm dates encapsulate row dates - just use this alarm
                    if alarm_start <= start_time and alarm_end >= end_time:
                        alarm_id = alarm_record['id']
                        break

                    # Calculate gap between date ranges
                    if end_time < alarm_start:
                        gap = (alarm_start - end_time).days
                    elif start_time > alarm_end:
                        gap = (start_time - alarm_end).days
                    else:
                        gap = 0  # Overlapping

                    # Case 2: Overlapping or within 3 days - extend the alarm dates
                    if gap <= max_gap_days:
                        alarm_id = alarm_record['id']
                        new_start = min(alarm_start, start_time)
                        new_end = max(alarm_end, end_time)

                        # Only update if dates actually changed
                        if new_start != alarm_start or new_end != alarm_end:
                            cursor.execute(update_alarm_dates_sql, (new_start, new_end, alarm_id))
                            # Update the lookup cache
                            alarm_record['start_time'] = new_start
                            alarm_record['end_time'] = new_end
                            updated_alarms += 1
                        break

                # Case 3: No matching alarm found (gap > 3 days for all existing alarms)
                # Will create a new alarm below

            if alarm_id is None:
                # Create new alarm record
                cursor.execute(insert_alarm_sql, (
                    "No ID",  # TODO add actual ID?
                    start_time,
                    end_time,
                    site_name,
                    alarm_type,
                    variable_name,
                    False  # silenced = False by default
                ))
                # Retrieve the ID from database to handle concurrent inserts safely
                cursor.execute(
                    f"""SELECT id FROM {alarm_table}
                        WHERE site_name = %s AND alarm_type = %s AND variable_name = %s
                        AND start_time_pt = %s AND end_time_pt = %s""",
                    (site_name, alarm_type, variable_name, start_time, end_time)
                )
                result = cursor.fetchone()
                if result is None:
                    raise Exception(f"Failed to retrieve alarm ID after insert for {alarm_type}/{variable_name}")
                alarm_id = result[0]
                # Add to lookup cache
                if lookup_key not in alarm_lookup:
                    alarm_lookup[lookup_key] = []
                alarm_lookup[lookup_key].append({
                    'id': alarm_id,
                    'start_time': start_time,
                    'end_time': end_time
                })
                new_alarms += 1

            # Get existing alarm instances for this alarm_id that might overlap
            cursor.execute(
                f"""SELECT inst_id, start_time_pt, end_time_pt, certainty
                    FROM {alarm_inst_table}
                    WHERE id = %s AND start_time_pt <= %s AND end_time_pt >= %s""",
                (alarm_id, end_time, start_time)
            )
            existing_instances = cursor.fetchall()

            # Track segments of the new alarm to insert (may be split by higher-certainty existing alarms)
            new_segments = [(start_time, end_time, certainty)]

            for existing in existing_instances:
                existing_inst_id, existing_start, existing_end, existing_certainty = existing

                # Process each new segment against this existing instance
                updated_segments = []
                for seg_start, seg_end, seg_certainty in new_segments:
                    # Check if there's overlap
                    if seg_end <= existing_start or seg_start >= existing_end:
                        # No overlap, keep segment as is
                        updated_segments.append((seg_start, seg_end, seg_certainty))
                        continue

                    # There is overlap - handle based on certainty comparison
                    if existing_certainty < seg_certainty:
                        # Case 1: New alarm has higher certainty - split existing around new
                        # Part before new alarm (if any)
                        if existing_start < seg_start:
                            cursor.execute(update_inst_sql, (existing_start, seg_start, existing_inst_id))
                            updated_instances += 1
                            # Insert the part after new alarm (if any)
                            if existing_end > seg_end:
                                cursor.execute(insert_inst_sql, (alarm_id, seg_end, existing_end, existing_certainty))
                                new_instances += 1
                        elif existing_end > seg_end:
                            # No part before, but there's a part after
                            cursor.execute(update_inst_sql, (seg_end, existing_end, existing_inst_id))
                            updated_instances += 1
                        else:
                            # Existing is completely encompassed by new - delete it
                            cursor.execute(delete_inst_sql, (existing_inst_id,))
                        # Keep the new segment as is
                        updated_segments.append((seg_start, seg_end, seg_certainty))

                    elif existing_certainty > seg_certainty:
                        # Case 2: Existing has higher certainty - trim new segment to non-overlapping parts
                        # Part before existing (if any)
                        if seg_start < existing_start:
                            updated_segments.append((seg_start, existing_start, seg_certainty))
                        # Part after existing (if any)
                        if seg_end > existing_end:
                            updated_segments.append((existing_end, seg_end, seg_certainty))
                        # The overlapping part of new segment is discarded

                    else:
                        # Case 3: Same certainty - merge to encompass both
                        merged_start = min(seg_start, existing_start)
                        merged_end = max(seg_end, existing_end)
                        cursor.execute(update_inst_sql, (merged_start, merged_end, existing_inst_id))
                        updated_instances += 1
                        # Remove this segment from new_segments (it's been merged into existing)
                        # Don't add to updated_segments

                new_segments = updated_segments

            # Insert any remaining new segments
            for seg_start, seg_end, seg_certainty in new_segments:
                if seg_start < seg_end:  # Only insert valid segments
                    cursor.execute(insert_inst_sql, (alarm_id, seg_start, seg_end, seg_certainty))
                    new_instances += 1

        connection.commit()
        print(f"Successfully loaded alarms: {new_alarms} new alarm records, {updated_alarms} updated alarm records, {new_instances} new instances, {updated_instances} updated instances.")
        return True

    except Exception as e:
        print(f"Error loading alarms: {e}")
        connection.rollback()
        return False

    finally:
        cursor.close()
        connection.close()