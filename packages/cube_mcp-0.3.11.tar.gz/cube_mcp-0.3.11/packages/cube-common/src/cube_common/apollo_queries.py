"""All Apollo GraphQL query and mutation strings."""

# ---------------------------------------------------------------------------
# Environment queries
# ---------------------------------------------------------------------------

GET_ENVIRONMENT_BY_RID = """
query GetEnv($rid: RID!) {
    apollo {
        environment(rid: $rid) {
            id
            rid
            name
        }
    }
}
"""

LIST_ENVIRONMENTS = """
query ListEnvs {
    apollo {
        environments(pageSize: 200) {
            environments {
                id
                rid
                name
                namespaceId
            }
            nextPageToken
        }
    }
}
"""

CREATE_ENVIRONMENT = """
mutation CreateEnv($request: CreateApolloEnvironmentRequest!) {
    apollo {
        createEnvironment(request: $request) {
            id
            rid
            name
            spaceId
            namespaceId
            accreditation
        }
    }
}
"""

# ---------------------------------------------------------------------------
# Module queries
# ---------------------------------------------------------------------------

INSTALL_MODULE = """
mutation InstallModule($request: InstallApolloProductModuleInputV2!) {
    apollo {
        installModuleV2(request: $request) {
            rid
            displayName
            moduleMavenCoordinate
            state {
                __typename
            }
        }
    }
}
"""

# ---------------------------------------------------------------------------
# Entity queries
# ---------------------------------------------------------------------------

ENTITY_HEALTH_FIELDS = """
    id
    rid
    displayName
    lifecycleStatus
    product { productId }
    entityLocator {
        ... on ApolloEntityLocator_ApolloEntity { entityName }
    }
    reportedStatus {
        version
        rolloutStatus
        configStatus
        healthStatus
        upgradeBlockerTypes
    }
    planStatus {
        __typename
    }
    nonGenericPlans(pageSize: 5) {
        plans {
            rid
            agentId
            status {
                type
                result { summary }
                reason { summary }
            }
            startTime
            endTime
            tasks {
                description { type summary }
                status {
                    type
                    updatedAt
                }
            }
        }
    }
"""

ENVIRONMENT_ENTITIES = f"""
query EnvironmentEntities($id: String!) {{
    apollo {{
        environmentById(id: $id) {{
            name
            entities(pageSize: 100) {{
                entities {{
                    {ENTITY_HEALTH_FIELDS}
                }}
            }}
        }}
    }}
}}
"""

INSTALL_ENTITIES = """
mutation InstallEntities($envId: String!, $entities: InstallApolloEntitiesOnEnvironmentRequest!) {
    apollo {
        installEntitiesOnEnvironment(apolloEnvironmentId: $envId, entities: $entities) {
            rid
            title
            requestStatus
        }
    }
}
"""

UNINSTALL_ENTITY = """
mutation UninstallEntity($rid: RID!) {
    apollo {
        uninstallEntity(rid: $rid) {
            rid
            requestStatus
        }
    }
}
"""

# ---------------------------------------------------------------------------
# Replication queries
# ---------------------------------------------------------------------------

SOURCE_ENVIRONMENT = """
query SourceEnv($id: String!) {
    apollo {
        environmentById(id: $id) {
            name
            accreditation
            moduleInstallationsV2 {
                moduleInstallations {
                    displayName
                    moduleMavenCoordinate
                    variables {
                        variableName
                        variableValue {
                            __typename
                            ... on ApolloProductModuleVariableValue_StringValue { value }
                            ... on ApolloProductModuleVariableValue_OptionValue { value }
                        }
                    }
                }
            }
            entities(pageSize: 200) {
                entities {
                    id
                    entityLocator {
                        ... on ApolloEntityLocator_ApolloEntity { entityName type }
                    }
                    product { productId }
                    declaredState { releaseChannel }
                    installedByModuleV2 { rid }
                    reportedConfigOverrides {
                        ... on ApolloEntityReportedConfigOverrides_Default {
                            overrides
                        }
                    }
                    secrets {
                        name
                        specification {
                            ... on ApolloSecretSpecification_MultiKey {
                                keys { key }
                            }
                        }
                    }
                }
            }
        }
    }
}
"""

TARGET_ENVIRONMENT = """
query TargetEnv($id: String!) {
    apollo {
        environmentById(id: $id) {
            moduleInstallationsV2 {
                moduleInstallations {
                    moduleMavenCoordinate
                }
            }
            entities(pageSize: 200) {
                entities {
                    entityLocator {
                        ... on ApolloEntityLocator_ApolloEntity { entityName }
                    }
                }
            }
        }
    }
}
"""

CLEANUP_CHECK = """
query CleanupCheck($id: String!) {
    apollo {
        environmentById(id: $id) {
            entities(pageSize: 200) {
                entities {
                    rid
                    entityLocator {
                        ... on ApolloEntityLocator_ApolloEntity { entityName }
                    }
                }
            }
        }
    }
}
"""

# ---------------------------------------------------------------------------
# Plan details query
# ---------------------------------------------------------------------------

PLAN_DETAILS = """
query PlanDetails($id: String!) {
    apollo {
        environmentById(id: $id) {
            name
            entities(pageSize: 200) {
                entities {
                    id
                    displayName
                    lifecycleStatus
                    product { productId }
                    entityLocator {
                        ... on ApolloEntityLocator_ApolloEntity { entityName }
                    }
                    reportedStatus { version }
                    nonGenericPlans(pageSize: 10) {
                        plans {
                            rid
                            agentId
                            proposedTime
                            startTime
                            endTime
                            status {
                                type
                                result { type summary metadataMap }
                                reason { type summary metadataMap }
                            }
                            stateChanges {
                                entityType
                                changeType
                            }
                            tasks {
                                rid
                                origin
                                description { type summary }
                                createdAt
                                status {
                                    type
                                    updatedAt
                                    description { type summary metadataMap }
                                }
                                latestEvent {
                                    timestamp
                                    description { summary }
                                }
                                events {
                                    timestamp
                                    description { summary }
                                }
                                subtasks {
                                    origin
                                    description { type summary }
                                    createdAt
                                    status {
                                        type
                                        updatedAt
                                        description { type summary metadataMap }
                                    }
                                    latestEvent {
                                        timestamp
                                        description { summary }
                                    }
                                    events {
                                        timestamp
                                        description { summary }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
"""
