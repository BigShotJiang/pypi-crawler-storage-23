"""Application configuration via environment variables."""

from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    """cube-cloud configuration loaded from environment variables."""

    # AWS
    aws_region: str = "us-west-2"

    # DynamoDB table for API keys
    dynamodb_table: str = "cube-mcp-api-keys"

    # Secrets Manager prefix for profile credentials
    secrets_prefix: str = "cube-mcp/profiles/"

    # Cognito (browser login)
    cognito_user_pool_id: str = ""
    cognito_app_client_id: str = ""
    cognito_domain: str = ""  # e.g. "cube-mcp-prod.auth.us-west-2.amazoncognito.com"

    # Public domain (used to build OAuth callback URLs behind a load balancer)
    domain: str = ""  # e.g. "cube.edgescaleai-cube.com"

    # Server
    host: str = "0.0.0.0"
    port: int = 8000
    log_level: str = "info"

    model_config = {"env_prefix": "CUBE_CLOUD_"}


settings = Settings()
