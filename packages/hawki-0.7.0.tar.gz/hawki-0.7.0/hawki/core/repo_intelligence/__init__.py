# --------------------
# File: hawki/core/repo_intelligence/__init__.py
# --------------------
"""
Repository intelligence: cloning, parsing, indexing.
"""