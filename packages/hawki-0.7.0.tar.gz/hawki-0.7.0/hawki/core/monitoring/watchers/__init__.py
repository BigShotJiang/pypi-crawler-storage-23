# --------------------
# File: hawki/core/monitoring/watchers/__init__.py
# --------------------
"""
Watcher modules – each file defines a Watcher subclass.
"""