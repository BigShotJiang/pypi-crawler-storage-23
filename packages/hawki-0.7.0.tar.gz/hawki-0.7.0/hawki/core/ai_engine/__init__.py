# --------------------
# File: hawki/core/ai_engine/__init__.py
# --------------------
"""
AI reasoning engine using LiteLLM.
Provides dynamic prompt loading and multi‑LLM support.
"""