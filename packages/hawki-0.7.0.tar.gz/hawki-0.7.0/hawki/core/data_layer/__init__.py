# --------------------
# File: hawki/core/data_layer/__init__.py
# --------------------
"""
Data persistence and reporting.
"""