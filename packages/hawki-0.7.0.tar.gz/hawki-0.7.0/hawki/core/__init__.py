# --------------------
# File: hawki/core/__init__.py
# --------------------
"""
Core subsystems for Hawk-i.
"""