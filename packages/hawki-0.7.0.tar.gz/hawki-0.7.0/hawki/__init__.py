# --------------------
# File: hawki/__init__.py
# --------------------
"""
Hawk-i package root.
"""
__version__ = "0.7.0"