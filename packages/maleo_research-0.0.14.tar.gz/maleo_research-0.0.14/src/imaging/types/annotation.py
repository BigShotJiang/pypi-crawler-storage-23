from uuid import UUID
from ..enums.annotation import DiagnosisType, StatusReviewType


IdentifierValueType = int | UUID
ListOfDiagnosisTypes = list[DiagnosisType]
OptListOfDiagnosisTypes = ListOfDiagnosisTypes | None

ListOfStatusReviewTypes = list[StatusReviewType]
OptStatusReviewType = StatusReviewType | None
