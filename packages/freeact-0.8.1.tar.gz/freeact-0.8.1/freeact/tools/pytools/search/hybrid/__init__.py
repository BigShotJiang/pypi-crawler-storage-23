"""Hybrid BM25/vector search for tool discovery.

Run as MCP server::

    python -m freeact.tools.pytools.search.hybrid

"""
