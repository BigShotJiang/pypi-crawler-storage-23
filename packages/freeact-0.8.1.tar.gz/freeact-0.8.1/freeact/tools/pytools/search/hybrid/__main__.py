"""Entry point for running the hybrid search server as a module."""

from freeact.tools.pytools.search.hybrid.server import main

if __name__ == "__main__":
    main()
