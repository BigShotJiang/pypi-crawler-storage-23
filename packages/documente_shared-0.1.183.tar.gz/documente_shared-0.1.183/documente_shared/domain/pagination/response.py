from dataclasses import dataclass
from typing import Any

from documente_shared.domain.pagination.entities import Page



@dataclass
class PaginationResponse(object):
    instance: Page
    presenter_class: Any

    def render(self) -> dict:
        return {
            "pagination": self.instance.to_pagination_dict,
            "data": [self.presenter_class(item).to_dict for item in self.instance.items],
        }
