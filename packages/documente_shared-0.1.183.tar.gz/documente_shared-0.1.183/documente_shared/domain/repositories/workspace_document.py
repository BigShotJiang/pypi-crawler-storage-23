from abc import ABC, abstractmethod
from uuid import UUID

from documente_shared.domain.entities.workspace_document import WorkspaceDocument
from documente_shared.domain.filters.workspace_document import WorkspaceDocumentFilters
from documente_shared.domain.pagination.entities import Page


class WorkspaceDocumentRepository(ABC):
    @abstractmethod
    def find(self, instance_id: UUID) -> WorkspaceDocument | None:
        raise NotImplementedError

    @abstractmethod
    def filter(
        self,
        filters: WorkspaceDocumentFilters,
    ) -> list[WorkspaceDocument]:
        raise NotImplementedError

    @abstractmethod
    def filter_paginated(
        self,
        filters: WorkspaceDocumentFilters,
    ) -> Page[WorkspaceDocument]:
        raise NotImplementedError

    @abstractmethod
    def persist(
        self,
        instance: WorkspaceDocument,
    ) -> WorkspaceDocument:
        raise NotImplementedError

    @abstractmethod
    def delete(
        self,
        instance_id: UUID,
    ) -> None:
        raise NotImplementedError
