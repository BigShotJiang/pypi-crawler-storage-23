from abc import ABC, abstractmethod
from typing import Any, List, Optional
from uuid import UUID

from documente_shared.domain.entities.workspace_document_page import (
    WorkspaceDocumentPage,
)
from documente_shared.domain.filters.workspace_document_page import (
    WorkspaceDocumentPageFilters,
)
from documente_shared.domain.pagination.entities import Page


class WorkspaceDocumentPageRepository(ABC):
    @abstractmethod
    def find(self, instance_id: UUID) -> WorkspaceDocumentPage | None:
        raise NotImplementedError

    @abstractmethod
    def find_by_document(
        self,
        workspace_document_id: UUID,
        include_bytes: bool = False,
    ) -> list[WorkspaceDocumentPage]:
        raise NotImplementedError

    @abstractmethod
    def find_by_document_and_page_number(
        self,
        workspace_document_id: UUID,
        page_number: int,
    ) -> WorkspaceDocumentPage | None:
        raise NotImplementedError

    @abstractmethod
    def filter(
        self,
        filters: WorkspaceDocumentPageFilters,
    ) -> list[WorkspaceDocumentPage]:
        raise NotImplementedError

    @abstractmethod
    def filter_paginated(
        self,
        filters: WorkspaceDocumentPageFilters,
    ) -> Page[WorkspaceDocumentPage]:
        raise NotImplementedError

    @abstractmethod
    def persist(self, instance: WorkspaceDocumentPage, update: bool=False) -> WorkspaceDocumentPage:
        raise NotImplementedError

    @abstractmethod
    def delete(self, instance_id: UUID) -> None:
        raise NotImplementedError

    @abstractmethod
    def delete_by_document(self, workspace_document_id: UUID) -> None:
        raise NotImplementedError
