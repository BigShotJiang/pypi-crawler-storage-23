# -*- coding: utf-8 -*-

from abc import ABC, abstractmethod
from uuid import UUID

from documente_shared.domain.entities.document_type import DocumentType
from documente_shared.domain.filters.document_type import DocumentTypeFilters
from documente_shared.domain.pagination.entities import Page


class DocumentTypeRepository(ABC):
    @abstractmethod
    def find(self, uuid: UUID) -> DocumentType | None:
        raise NotImplementedError

    @abstractmethod
    def find_with_tenant(self, tenant_id: UUID, instance_id: UUID) -> DocumentType | None:
        raise NotImplementedError

    @abstractmethod
    def find_by_tenant(self, tenant_id: UUID, shareable_only: bool = False) -> list[DocumentType]:
        raise NotImplementedError

    @abstractmethod
    def filter(
        self,
        filters: DocumentTypeFilters,
    ) -> list[DocumentType]:
        raise NotImplementedError

    @abstractmethod
    def filter_paginated(
        self,
        filters: DocumentTypeFilters,
    ) -> Page[DocumentType]:
        raise NotImplementedError

    @abstractmethod
    def persist(self, instance: DocumentType) -> DocumentType:
        raise NotImplementedError

    @abstractmethod
    def delete(self, uuid: UUID) -> None:
        raise NotImplementedError
