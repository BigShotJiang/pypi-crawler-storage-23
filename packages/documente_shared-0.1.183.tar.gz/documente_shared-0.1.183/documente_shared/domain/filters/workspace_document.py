from datetime import datetime
from uuid import UUID
from pydantic import Field

from documente_shared.application.query_params import QueryParams
from documente_shared.domain.enums.common import ProcessingStatus
from documente_shared.domain.helpers.dicts import filter_none_values
from documente_shared.domain.helpers.lists import enum_list_to_comma_string
from documente_shared.domain.pagination.entities import ListFilters

from documente_shared.domain.constants import DEFAULT_PAGINATION_PAGE_SIZE


class WorkspaceDocumentFilters(ListFilters):
    tenant_ids: list[UUID] | None = Field(default_factory=list)
    workspace_ids: list[UUID] | None = Field(default_factory=list)
    created_by_ids: list[UUID] | None = Field(default_factory=list)
    statuses: list[ProcessingStatus] | None = Field(default_factory=list)
    search: str | None = Field(default=None)
    digest: str | None = Field(default=None)
    init_date: datetime | None = Field(default=None)
    end_date: datetime | None = Field(default=None)

    @property
    def to_params(self) -> dict:
        return filter_none_values({
            **super().to_dict,
            "tenant_ids": self.tenant_ids,
            "workspace_ids": self.workspace_ids,
            "created_by_ids": self.created_by_ids,
            "search": self.search,
            "digest": self.digest,
            "statuses": enum_list_to_comma_string(self.statuses),
            "init_date": self.init_date.strftime("%Y-%m-%d") if self.init_date else None,
            "end_date": self.end_date.strftime("%Y-%m-%d") if self.end_date else None,
        })

    @classmethod
    def from_params(cls, params: QueryParams) -> "WorkspaceDocumentFilters":
        search_term = params.get_str(key="search", default=None)
        return cls(
            cursor=params.get("cursor", None),
            limit=params.get_int(key="limit", default=DEFAULT_PAGINATION_PAGE_SIZE),
            tenant_ids=params.get_uuid_list(key="tenant_ids", default=None),
            workspace_ids=params.get_uuid_list(key="workspace_ids", default=None),
            created_by_ids=params.get_uuid_list(key="created_by_ids", default=None),
            search=search_term.strip() if search_term else None,
            digest=params.get_str(key="digest", default=None),
            statuses=params.get_enum_list(
                key="statuses",
                enum_class=ProcessingStatus,
                default=None,
            ),
            init_date=params.get_datetime(key="init_date", default=None),
            end_date=params.get_datetime(key="end_date", default=None),
        )
