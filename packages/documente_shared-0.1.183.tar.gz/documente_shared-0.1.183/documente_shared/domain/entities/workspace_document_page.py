from datetime import datetime
from uuid import UUID

from pydantic import BaseModel, Field

from documente_shared.application.time_utils import get_datetime_from_data
from documente_shared.domain.entities.in_memory_document import InMemoryDocument


class WorkspaceDocumentPage(BaseModel):
    uuid: UUID
    workspace_id: UUID
    workspace_document_id: UUID
    page_number: int
    tenant_id: UUID | None = Field(default=None)
    tenant_slug: str | None = Field(default=None)
    page_file: InMemoryDocument | None = Field(default=None)
    page_file_url: str | None = Field(default=None)
    cleaned_page_file: InMemoryDocument | None = Field(default=None)
    cleaned_page_file_url: str | None = Field(default=None)
    created_at: datetime | None = Field(default=None)
    synced_at: datetime | None = Field(default=None)

    @property
    def to_persist_dict(self) -> dict:
        return {
            "tenant_id": self.tenant_id,
            "workspace_id": str(self.workspace_id),
            "workspace_document_id": str(self.workspace_document_id),
            "page_number": self.page_number,
            "synced_at": (
                self.synced_at.isoformat()
                if self.synced_at else None
            ),
        }

    @property
    def to_update_dict(self) -> dict:
        return {
            **self.to_persist_dict,
            "cleaned_page_file": (
                self.cleaned_page_file.to_dict
                if self.cleaned_page_file else None
            ),
        }

    @property
    def to_dict(self) -> dict:
        return {
            "uuid": str(self.uuid),
            "tenant_id": self.tenant_id,
            "tenant_slug": self.tenant_slug,
            "workspace_id": str(self.workspace_id),
            "workspace_document_id": str(self.workspace_document_id),
            "page_number": self.page_number,
            "page_file": (
                self.page_file.to_dict
                if self.page_file else None
            ),
            "page_file_url": self.page_file_url,
            "cleaned_page_file": (
                self.cleaned_page_file.to_dict
                if self.cleaned_page_file else None
            ),
            "cleaned_page_file_url": self.cleaned_page_file_url,
            "created_at": (
                self.created_at.isoformat()
                if self.created_at else None
            ),
            "synced_at": (
                self.synced_at.isoformat()
                if self.synced_at else None
            ),
        }

    @classmethod
    def from_dict(cls, data: dict) -> 'WorkspaceDocumentPage':
        return cls(
            uuid=data.get('uuid'),
            tenant_id=data.get('tenant_id'),
            tenant_slug=data.get('tenant_slug'),
            workspace_id=data.get('workspace_id'),
            workspace_document_id=data.get('workspace_document_id'),
            page_number=data.get('page_number'),
            page_file=(
                InMemoryDocument.from_dict(data.get('page_file'))
                if data.get('page_file') else None
            ),
            page_file_url=data.get('page_file_url'),
            cleaned_page_file=(
                InMemoryDocument.from_dict(data.get('cleaned_page_file'))
                if data.get('cleaned_page_file') else None
            ),
            cleaned_page_file_url=data.get('cleaned_page_file_url'),
            created_at=get_datetime_from_data(input_datetime=data.get('created_at')),
            synced_at=get_datetime_from_data(input_datetime=data.get('synced_at')),
        )
