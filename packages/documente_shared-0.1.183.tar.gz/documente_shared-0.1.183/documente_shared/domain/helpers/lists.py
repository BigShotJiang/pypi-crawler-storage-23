"""Utilities for parsing lists to/from comma-separated strings."""

from typing import TypeVar, Type
from enum import Enum

T = TypeVar("T")
E = TypeVar("E", bound=Enum)


def list_to_comma_string(items: list[T] | None) -> str | None:
    """
    Convert a list of items to a comma-separated string.

    Args:
        items: List of items to convert (can be None or empty)

    Returns:
        Comma-separated string or None if list is empty/None

    Examples:
        >>> list_to_comma_string([1, 2, 3])
        '1,2,3'
        >>> list_to_comma_string(None)
        None
        >>> list_to_comma_string([])
        None
    """
    if not items:
        return None
    return ",".join(str(item) for item in items)


def comma_string_to_list(
    value: str | None,
    item_type: Type[T] = str,
) -> list[T] | None:
    """
    Convert a comma-separated string to a list of items.

    Args:
        value: Comma-separated string
        item_type: Type to convert each item to (default: str)

    Returns:
        List of items or None if string is empty/None

    Examples:
        >>> comma_string_to_list("1,2,3", int)
        [1, 2, 3]
        >>> comma_string_to_list("a,b,c")
        ['a', 'b', 'c']
        >>> comma_string_to_list(None)
        None
    """
    if not value:
        return None

    items = [item.strip() for item in value.split(",")]

    if item_type == str:
        return items

    return [item_type(item) for item in items if item]


def enum_list_to_comma_string(enums: list[E] | None) -> str | None:
    """
    Convert a list of enums to a comma-separated string of their values.

    Args:
        enums: List of enum instances

    Returns:
        Comma-separated string of enum values or None

    Examples:
        >>> class Status(Enum):
        ...     ACTIVE = "active"
        ...     INACTIVE = "inactive"
        >>> enum_list_to_comma_string([Status.ACTIVE, Status.INACTIVE])
        'active,inactive'
    """
    if not enums:
        return None
    return ",".join(enum.value for enum in enums)


def comma_string_to_enum_list(
    value: str | None,
    enum_class: Type[E],
) -> list[E] | None:
    """
    Convert a comma-separated string to a list of enum instances.

    Args:
        value: Comma-separated string of enum values
        enum_class: The enum class to convert to

    Returns:
        List of enum instances or None

    Examples:
        >>> class Status(Enum):
        ...     ACTIVE = "active"
        ...     INACTIVE = "inactive"
        >>> comma_string_to_enum_list("active,inactive", Status)
        [Status.ACTIVE, Status.INACTIVE]
    """
    if not value:
        return None

    items = [item.strip() for item in value.split(",")]
    return [enum_class(item) for item in items if item]
