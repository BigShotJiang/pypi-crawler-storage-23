from abc import ABC, abstractmethod


class QueueService(ABC):
    @abstractmethod
    def send_message(self, payload: dict, *args, **kwargs):
        raise NotImplementedError

    @abstractmethod
    def delete_message(self, *args, **kwargs):
        raise NotImplementedError

    @abstractmethod
    def fetch_messages(self, *args, **kwargs) -> list[dict]:
        raise NotImplementedError
