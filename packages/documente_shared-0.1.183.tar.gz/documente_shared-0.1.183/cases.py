from datetime import datetime

from documente_shared.domain.constants import DOCUMENTE_API_URL, DOCUMENTE_API_KEY
from documente_shared.infrastructure.repositories.http_processing_case import HttpProcessingCaseRepository
from documente_shared.infrastructure.repositories.http_processing_case_item import HttpProcessingCaseItemRepository
from documente_shared.infrastructure.lambdas import invoke_lambda
from documente_shared.infrastructure.services.http_scaling import HttpScalingService

# case_repository = HttpProcessingCaseRepository(
#     api_url=DOCUMENTE_API_URL,
#     api_key=DOCUMENTE_API_KEY,
# )
# case_item_repository = HttpProcessingCaseItemRepository(
#     api_url=DOCUMENTE_API_URL,
#     api_key=DOCUMENTE_API_KEY,
# )
#
# processing_case = case_repository.find(uuid="e374bacf-38f7-487a-8b2c-2e7e7a9a34aa")
#
# print(processing_case)
#
# processing_case_item = case_item_repository.find(uuid="ec573f1e-5d7e-4769-a3b9-6b9ce49cb8d2")
# processing_case_item.document.file_path = "raw-images/case_item.txt"
# processing_case_item.completed_at = datetime.now()
# processing_case_item.started_at = datetime.now()
#
# processing_case_item = case_item_repository.persist(processing_case_item)
#
# print(processing_case_item)


# response = invoke_lambda(
#     function_name="scale-processing-dev",
#     payload={
#         "uuid": "e374bacf-38f7-487a-8b2c-2e7e7a9a34aa"
#     }
# )

scaling_service = HttpScalingService(
    api_url=DOCUMENTE_API_URL,
    api_key=DOCUMENTE_API_KEY,
)

requirements = scaling_service.get_requirements()

print(requirements.to_dict)