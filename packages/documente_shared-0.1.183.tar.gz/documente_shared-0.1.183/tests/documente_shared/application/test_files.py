from expects import expect, equal
from documente_shared.application.files import build_bucket_file_key

def test_build_bucket_file_key_with_full_url():
    url = "https://api-dev.documenteai.com/media/univida_soat/unprocessed/cdb8df7599034963.pdf"
    expected = "media/univida_soat/unprocessed/cdb8df7599034963.pdf"
    
    result = build_bucket_file_key(url)
    
    expect(result).to(equal(expected))

def test_build_bucket_file_key_with_path():
    path = "/media/univida_soat/unprocessed/cdb8df7599034963.pdf"
    expected = "media/univida_soat/unprocessed/cdb8df7599034963.pdf"
    
    result = build_bucket_file_key(path)

    expect(result).to(equal(expected))

def test_build_bucket_file_key_with_path_without_slash():
    path = "media/univida_soat/unprocessed/cdb8df7599034963.pdf"
    expected = "media/univida_soat/unprocessed/cdb8df7599034963.pdf"
    
    result = build_bucket_file_key(path)

    expect(result).to(equal(expected))
