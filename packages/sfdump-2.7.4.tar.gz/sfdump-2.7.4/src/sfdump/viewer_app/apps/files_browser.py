#!/usr/bin/env python
from __future__ import annotations

from pathlib import Path

import pandas as pd
import streamlit as st

from sfdump.viewer_app.ui.documents_panel import render_documents_panel_from_rows

SCRIPT_DIR = Path(__file__).resolve().parent


def guess_exports_base() -> Path:
    """Try to guess where the 'exports' root lives.

    Preference order:
      1. <current working dir>/exports
      2. <repo>/exports (one level above scripts)
      3. ~/sfdump-exports
    """
    home = Path.home()
    candidates = [
        Path.cwd() / "exports",
        SCRIPT_DIR.parent / "exports",
        home / "sfdump-exports",
    ]

    for c in candidates:
        if c.exists():
            return c.resolve()

    # Fallback to the first candidate even if it doesn't exist yet
    return candidates[0]


@st.cache_data
def load_master_index(path: Path) -> pd.DataFrame:
    df = pd.read_csv(path, dtype=str).fillna("")
    # Helpful derived column for search
    df["search_blob"] = (
        df.get("file_name", "")
        + " "
        + df.get("record_name", "")
        + " "
        + df.get("object_type", "")
        + " "
        + df.get("account_name", "")
        + " "
        + df.get("opp_name", "")
    ).str.lower()
    return df


def main() -> None:
    st.set_page_config(page_title="Salesforce Documents Browser", layout="wide")
    st.title("Salesforce Documents Browser")

    # ------------------------------------------------------------------
    # Sidebar: choose exports base + specific export run
    # ------------------------------------------------------------------
    st.sidebar.header("Location")

    default_exports_base = guess_exports_base()

    exports_base_str = st.sidebar.text_input(
        "Exports base directory (contains export-YYYY-MM-DD folders)",
        value=str(default_exports_base),
        help=(
            "This folder should contain subfolders like 'export-2025-11-15', "
            "each one being a full SF export with csv/, files/, meta/."
        ),
    )

    exports_base = Path(exports_base_str).expanduser().resolve()

    if not exports_base.exists():
        st.error(
            f"Exports folder not found:\n\n{exports_base}\n\n"
            "If this is your first time running the viewer, please run:\n"
            "`make export-all`\n"
            "to generate your first export."
        )
        st.stop()

    # Find export-* subdirectories
    run_dirs = sorted(
        [p for p in exports_base.iterdir() if p.is_dir() and p.name.startswith("export-")]
    )

    if not run_dirs:
        st.error(
            f"No 'export-YYYY-MM-DD' directories found under:\n{exports_base}\n\n"
            "Run 'make export-all' first to generate your first export."
        )
        st.stop()

    # Auto-detect the latest export directory
    latest_run = run_dirs[-1]

    st.sidebar.markdown(f"**Latest export detected:** `{latest_run.name}`")

    # Allow manual override, but default to latest
    selected_run_name = st.sidebar.selectbox(
        "Choose export run",
        options=[p.name for p in run_dirs],
        index=[p.name for p in run_dirs].index(latest_run.name),
    )

    export_root = exports_base / selected_run_name
    master_index_path = export_root / "meta" / "master_documents_index.csv"

    st.sidebar.write(f"Using export root: `{export_root}`")
    st.sidebar.write(f"Master index: `{master_index_path}`")

    if not master_index_path.exists():
        st.error(f"Master index not found at:\n{master_index_path}")
        st.stop()

    df = load_master_index(master_index_path)

    # ------------------------------------------------------------------
    # Sidebar: filters
    # ------------------------------------------------------------------
    st.sidebar.header("Filters")

    # Object types
    object_types = sorted(df["object_type"].dropna().unique())
    selected_types = st.sidebar.multiselect(
        "Object types",
        options=object_types,
        default=object_types,
    )

    # File extensions
    extensions = sorted([e for e in df.get("file_extension", "").dropna().unique() if e])
    selected_ext = st.sidebar.multiselect(
        "File extensions",
        options=extensions,
        default=extensions,
    )

    # Global search
    query = st.text_input(
        "Search (supports * wildcard; searches file, record, account, opp):",
        "",
    )

    # Column-specific filters
    col_filters: dict[str, str] = {}
    with st.sidebar.expander("More column filters", expanded=False):
        if "record_name" in df.columns:
            col_filters["record_name"] = st.text_input("Record name contains", "")
        if "account_name" in df.columns:
            col_filters["account_name"] = st.text_input("Account name contains", "")
        if "opp_name" in df.columns:
            col_filters["opp_name"] = st.text_input("Opportunity name contains", "")
        if "opp_stage" in df.columns:
            col_filters["opp_stage"] = st.text_input("Stage contains", "")

    # ------------------------------------------------------------------
    # Apply filters
    # ------------------------------------------------------------------
    mask = pd.Series(True, index=df.index)

    if selected_types:
        mask &= df["object_type"].isin(selected_types)

    if selected_ext:
        mask &= df["file_extension"].isin(selected_ext)

    if query:
        q = query.strip().lower().replace("*", "")
        if q:
            mask &= df["search_blob"].str.contains(q, case=False, na=False)

    for col, value in col_filters.items():
        if value:
            mask &= df[col].str.contains(value, case=False, na=False)

    filtered = df[mask].copy()
    filtered_count = len(filtered)

    st.write(f"Showing up to 500 of {filtered_count:,} matching documents:")
    st.info(f"Displaying the first 500 of {filtered_count:,} matching documents.")

    # ----------------------------------------------------------------------
    # Columns to show
    # ----------------------------------------------------------------------
    preferred_cols = [
        "file_source",
        "file_name",
        "file_extension",
        "object_type",
        "record_name",
        "account_name",
        "opp_name",
        "opp_stage",
        "opp_amount",
        "opp_close_date",
        "local_path",
        "path",
    ]
    available_cols = [col for col in preferred_cols if col in filtered.columns]

    if not available_cols:
        st.warning(
            "None of the expected index columns were found.\n"
            "This export may be incomplete or the index format has changed."
        )
        st.stop()

    with st.sidebar.expander("Columns to display", expanded=False):
        show_cols = st.multiselect(
            "Select columns",
            options=available_cols,
            default=available_cols,
        )
    if not show_cols:
        show_cols = available_cols

    display = filtered[show_cols].head(500)
    st.dataframe(display, width="stretch")

    st.success(f"Viewer loaded successfully — {len(df):,} total documents indexed.")
    st.caption("Tip: Narrow down with filters and search, then preview/open a document below.")

    # ------------------------------------------------------------------
    # Preview / open a document (standard renderer)
    # ------------------------------------------------------------------
    st.subheader("Preview / Open a document")

    if filtered.empty:
        st.info("No matching documents. Adjust your filters/search.")
        return

    path_col = (
        "local_path"
        if "local_path" in filtered.columns
        else ("path" if "path" in filtered.columns else "")
    )
    if not path_col:
        st.warning(
            "This export does not include file paths ('local_path' or 'path').\n"
            "You can still browse the index, but preview/open is unavailable."
        )
        return

    limited = filtered.head(200)

    rows = []
    for _, r in limited.iterrows():
        rel = (r.get(path_col) or "").strip()
        rows.append(
            {
                "file_source": r.get("file_source", ""),
                "file_id": r.get("file_id", ""),
                "file_name": r.get("file_name", ""),
                "title": r.get("file_name", ""),
                "path": rel,
                "local_path": rel,
            }
        )

    render_documents_panel_from_rows(
        export_root=export_root,
        rows=rows,
        title="Global documents preview",
        key_prefix=f"global_docs_{selected_run_name}",
        pdf_height=800,
    )


if __name__ == "__main__":
    main()
