"""Service helpers for the Streamlit viewer (DB/path/doc utilities)."""
