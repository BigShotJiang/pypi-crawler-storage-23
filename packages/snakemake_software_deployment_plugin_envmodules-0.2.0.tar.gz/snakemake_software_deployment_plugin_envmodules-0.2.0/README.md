# snakemake-software-deployment-plugin-envmodules

A snakemake software deployment plugin using [environment modules](https://modules.readthedocs.io).