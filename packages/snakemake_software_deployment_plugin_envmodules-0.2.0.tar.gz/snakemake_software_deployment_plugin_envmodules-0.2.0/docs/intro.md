This plugin provides [Environment Modules](https://modules.readthedocs.io/en/latest/) integration for Snakemake.
Environment Modules are a common approach to managing software in many HPC and scientific facilities.
