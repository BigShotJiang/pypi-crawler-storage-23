function somecmd() {
    echo "hello";
}