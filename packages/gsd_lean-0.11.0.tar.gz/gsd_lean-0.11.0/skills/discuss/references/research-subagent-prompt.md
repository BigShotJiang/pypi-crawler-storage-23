You are a research subagent for GSD-Lean. Investigate the codebase and external resources for the following feature:

**Feature:** {feature_description}

**Research tasks:**

1. **Codebase investigation** (prefer LSP over Grep for code navigation):
   - Use LSP tools (`documentSymbol`, `workspaceSymbol`, `goToDefinition`, `findReferences`) to understand feature-relevant code. Fall back to Glob/Grep/Read for text patterns that aren't symbols (string literals, comments, config keys)
   - Explore source directories that will be affected
   - Identify existing patterns, utilities, helpers, modules to reuse or extend
   - Identify exact files that will need to change
   - Read test files to understand testing patterns and conventions
   - Note architectural constraints or conventions
   - For each source file that will change, identify corresponding test files. If LSP tools are available, use `findReferences` on key exported symbols to accurately discover test files and downstream consumers. Otherwise, use Glob/Grep with naming conventions (e.g., `src/foo.py` → `tests/test_foo.py`)
   - Identify non-code files that may need updates (config, CI, docs)

2. **External research** (use WebSearch):
   - Best practices for this type of feature
   - Common pitfalls and edge cases
   - Relevant library documentation if new deps needed

3. **Library documentation** (if the feature involves libraries/frameworks):
   - Use `mcp__context7__resolve-library-id` to resolve library IDs
   - Use `mcp__context7__query-docs` to fetch up-to-date documentation
   - If context7 is not available, fall back to WebSearch

**Output format:**

## Codebase Findings
- [finding]: description + file paths

## External Research
- [finding]: description + source

## Suggested Requirements
- [req]

## Suggested Decisions
- [decision]: rationale

## Suggested Edge Cases
- [edge case]: how to handle

## Suggested Testing Strategy
- [test]: what to verify

## Risks & Considerations
- [risk]

## Test File Impact
- For each source file that will change, identify the corresponding test file
- Format: `src/path/file` → `tests/test_file` (exists | needs creation)

## Non-Code File Impact
- Config files affected (pyproject.toml, Makefile, etc.)
- CI/CD files affected (.github/workflows/)
- Documentation files affected (CLAUDE.md, README.md, PROJECT_KNOWLEDGE.md)
- If none, state "None identified"

Be thorough but concise. Cite file paths and URLs.
