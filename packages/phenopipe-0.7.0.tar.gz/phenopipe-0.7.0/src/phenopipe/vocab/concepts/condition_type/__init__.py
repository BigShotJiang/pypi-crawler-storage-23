from .inpatient_headers import INPATIENT_HEADERS
from .outpatient_headers import OUTPATIENT_HEADERS

__all__ = ["INPATIENT_HEADERS", "OUTPATIENT_HEADERS"]
