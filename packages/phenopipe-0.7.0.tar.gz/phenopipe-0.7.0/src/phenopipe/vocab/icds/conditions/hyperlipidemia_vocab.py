HYPERLIPIDEMIA_ICDS = {"icd9": ["272.%"], "icd10": ["E78.%", "E88.%"]}
