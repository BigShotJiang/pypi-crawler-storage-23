POTS_ICDS = {"icd9": ["337.9"], "icd10": ["G90.A", "G90.9"]}
