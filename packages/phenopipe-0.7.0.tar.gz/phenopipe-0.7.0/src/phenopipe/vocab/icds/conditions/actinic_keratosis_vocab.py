ACTINIC_KERATOSIS_ICDS = {"icd9": ["702.0"], "icd10": ["L57.0"]}
