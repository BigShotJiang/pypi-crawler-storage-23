COPD_EXACERBATION_ICDS = {"icd9": ["491.21"], "icd10": ["J44.1", "J44.0"]}
