MIGRAINE_ICDS = {"icd9": ["346.%"], "icd10": ["G43.%"]}
