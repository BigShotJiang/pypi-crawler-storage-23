INSOMNIA_EXPANDED_ICDS = {
    "icd9": ["307.%", "780.51", "780.52"],
    "icd10": ["F51.%", "G47.%"],
}
