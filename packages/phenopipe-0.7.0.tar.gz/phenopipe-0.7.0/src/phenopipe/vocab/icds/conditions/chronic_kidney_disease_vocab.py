CHRONIC_KIDNEY_DISEASE_ICDS = {"icd9": ["585", "585.%"], "icd10": ["N18", "N18.%"]}
