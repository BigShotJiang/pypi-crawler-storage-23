NON_ALCOHOLIC_LIVER_DISEASE_ICDS = {
    "icd9": ["571.8", "571.9"],
    "icd10": ["K76.0", "K74.1", "K76.89", "K76.8", "K74.2", "K75.81"],
}
