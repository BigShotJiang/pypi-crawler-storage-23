DIABETES_T1_TERMS = [
    "insulin",
    "pramlintide",
    "insulin glulisine",
    "insulin lispro",
    "insulin aspart",
    "insulin glargine",
    "insulin detemir",
    "insulin degludec",
    "insulin NPH",
]
