MINERALOCORTICOID_ANTAGONISTS_TERMS = [
    "spironolactone",
    "aldactone",
    "eplerenone",
    "inspra",
]
