SGLT2_INHIBITORS_TERMS = [
    "empagliflozin",
    "jardiance",
    "canagliflozin",
    "invokana",
    "dapagliflozin",
    "farxiga",
    "ertugliflozin",
    "steglatro",
]
