SEMAGLUTIDE_TERMS = ["semaglutide", "ozempic", "rybelsus", "wegovy"]
