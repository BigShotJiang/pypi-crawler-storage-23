LOOP_DIURETICS_TERMS = [
    "bumetanide",
    "bumex",
    "ethacrynic acid",
    "ethacrynate",
    "edecrin",
    "sodium edicrin",
    "torsemide",
    "demadex",
    "furosemide",
    "lasix",
]
