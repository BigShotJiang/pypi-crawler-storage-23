LIRAGLUTIDE_TERMS = ["liraglutide", "saxenda", "victoza"]
