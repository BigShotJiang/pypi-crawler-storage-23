ASPIRIN_TERMS = ["aspirin", "asprin"]
