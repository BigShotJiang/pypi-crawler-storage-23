FASTING_GLUCOSE_TERMS = {
    "concept_codes": None,
    "concept_names": [
        "Fasting glucose [Mass/volume] in Serum or Plasma",
        "Fasting glucose [Moles/volume] in Blood",
    ],
}
