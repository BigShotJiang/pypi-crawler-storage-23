CHOLESTEROL_TERMS = {
    "concept_codes": None,
    "concept_names": ["Cholesterol [Mass/volume] in Serum or Plasma"],
}
