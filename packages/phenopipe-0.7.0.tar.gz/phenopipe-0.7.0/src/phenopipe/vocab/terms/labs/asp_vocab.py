ASP_TERMS = {
    "concept_codes": None,
    "concept_names": [
        "Aspartate aminotransferase",
        "Aspartate aminotransferase | Serum or Plasma | Chemistry - non-challenge",
        "Aspartate aminotransferase [Enzymatic activity/volume] in Serum or Plasma",
    ],
}
