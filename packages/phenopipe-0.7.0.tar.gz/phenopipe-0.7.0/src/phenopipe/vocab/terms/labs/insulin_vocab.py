INSULIN_TERMS = {
    "concept_codes": None,
    "concept_names": [
        "Insulin",
        "Insulin | Serum or Plasma | Chemistry - non-challenge",
        "Insulin [Units/volume] in Serum or Plasma",
    ],
}
