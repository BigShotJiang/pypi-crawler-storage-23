CREATININE_TERMS = {
    "concept_codes": None,
    "concept_names": [
        "Creatinine",
        "Creatinine | Serum or Plasma | Chemistry - non-challenge",
        "Creatinine [Mass/volume] in Serum or Plasma",
    ],
}
