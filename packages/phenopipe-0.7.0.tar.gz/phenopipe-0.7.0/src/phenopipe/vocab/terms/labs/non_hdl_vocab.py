NON_HDL_TERMS = {
    "concept_codes": None,
    "concept_names": ["Cholesterol non HDL [Mass/volume] in Serum or Plasma"],
}
