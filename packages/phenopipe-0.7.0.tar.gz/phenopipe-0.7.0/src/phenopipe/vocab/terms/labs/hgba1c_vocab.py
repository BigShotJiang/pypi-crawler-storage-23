HGBA1C_TERMS = {
    "concept_codes": None,
    "concept_names": [
        "Hemoglobin A1c/Hemoglobin.total in Blood by Electrophoresis",
        "Hemoglobin A1c/Hemoglobin.total in Blood by calculation",
        "Hemoglobin A1c/Hemoglobin.total in Blood by IFCC protocol",
        "Hemoglobin A1c/Hemoglobin.total in Blood",
        "Hemoglobin A1c/Hemoglobin.total in Blood by HPLC",
    ],
}
