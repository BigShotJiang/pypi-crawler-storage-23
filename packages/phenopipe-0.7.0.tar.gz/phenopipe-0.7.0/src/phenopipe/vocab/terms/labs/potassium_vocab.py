POTASSIUM_TERMS = {
    "concept_codes": None,
    "concept_names": [
        "Potassium",
        "Potassium [Moles/volume] in Serum or Plasma",
        "Potassium | Serum or Plasma | Chemistry - non-challenge",
    ],
}
