BUN_TERMS = {
    "concept_codes": None,
    "concept_names": ["Urea nitrogen [Mass/volume] in Serum or Plasma"],
}
