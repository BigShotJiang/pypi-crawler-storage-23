LDL_TERMS = {
    "concept_codes": None,
    "concept_names": [
        "Cholesterol in LDL [Mass/volume] in Serum or Plasma by calculation",
        "Cholesterol in LDL [Mass/volume] in Serum or Plasma",
        "Cholesterol in LDL [Mass/volume] in Serum or Plasma by Direct assay",
        "Cholesterol in LDL [Mass/volume] in Serum or Plasma by Electrophoresis",
    ],
}
