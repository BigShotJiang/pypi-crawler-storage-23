TRIGS_TERMS = {
    "concept_codes": None,
    "concept_names": [
        "Triglyceride [Mass/volume] in Serum or Plasma",
        "Triglyceride [Mass/volume] in Blood",
    ],
}
