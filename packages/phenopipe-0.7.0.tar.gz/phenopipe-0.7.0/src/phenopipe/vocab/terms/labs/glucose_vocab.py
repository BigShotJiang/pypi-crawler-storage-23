GLUCOSE_TERMS = {
    "concept_codes": None,
    "concept_names": [
        "Glucose [Mass/volume] in Serum or Plasma",
        "Glucose [Mass/volume] in Blood",
    ],
}
