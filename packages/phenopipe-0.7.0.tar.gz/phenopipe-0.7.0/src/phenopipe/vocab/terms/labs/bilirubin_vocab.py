BILIRUBIN_TERMS = {
    "concept_codes": None,
    "concept_names": [
        "Bilirubin",
        "Bilirubin | Serum or Plasma | Chemistry - non-challenge",
        "Bilirubin.total [Mass/volume] in Serum or Plasma",
    ],
}
