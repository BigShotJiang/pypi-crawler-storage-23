CARBON_DIOXIDE_TERMS = {
    "concept_codes": None,
    "concept_names": [
        "Carbon dioxide",
        "Carbon dioxide | Serum or Plasma | Chemistry - non-challenge",
        "Carbon dioxide, total [Moles/volume] in Serum or Plasma",
    ],
}
