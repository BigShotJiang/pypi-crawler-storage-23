ALT_TERMS = {
    "concept_codes": None,
    "concept_names": [
        "Alanine aminotransferase",
        "Alanine aminotransferase [Enzymatic activity/volume] in Serum or Plasma",
        "Alanine aminotransferase | Serum or Plasma | Chemistry - non-challenge",
    ],
}
