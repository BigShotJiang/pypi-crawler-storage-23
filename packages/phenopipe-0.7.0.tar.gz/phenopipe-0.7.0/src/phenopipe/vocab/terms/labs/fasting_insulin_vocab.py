FASTING_INSULIN_TERMS = {
    "concept_codes": None,
    "concept_names": [
        "Insulin [Units/volume] in Serum or Plasma --fasting",
        "Insulin [Units/volume] in Serum or Plasma --12 hours fasting",
    ],
}
