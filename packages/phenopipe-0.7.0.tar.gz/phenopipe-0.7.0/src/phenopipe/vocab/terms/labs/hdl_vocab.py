HDL_TERMS = {
    "concept_codes": None,
    "concept_names": ["Cholesterol in HDL [Mass/volume] in Serum or Plasma"],
}
