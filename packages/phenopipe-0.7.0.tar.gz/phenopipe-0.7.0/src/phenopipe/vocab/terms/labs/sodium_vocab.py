SODIUM_TERMS = {
    "concept_codes": None,
    "concept_names": [
        "Sodium",
        "Sodium | Serum or Plasma | Chemistry - non-challenge",
        "Sodium [Moles/volume] in Serum or Plasma",
    ],
}
