CHLORIDE_TERMS = {
    "concept_codes": None,
    "concept_names": [
        "Chloride",
        "Chloride [Moles/volume] in Serum or Plasma",
        "Chloride | Serum or Plasma | Chemistry - non-challenge",
    ],
}
