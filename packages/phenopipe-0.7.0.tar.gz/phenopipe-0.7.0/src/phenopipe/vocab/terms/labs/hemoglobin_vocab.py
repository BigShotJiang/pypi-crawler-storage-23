HEMOGLOBIN_TERMS = {
    "concept_codes": None,
    "concept_names": ["Hemoglobin [Mass/volume] in Blood"],
}
