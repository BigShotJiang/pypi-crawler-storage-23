ALP_TERMS = {
    "concept_codes": None,
    "concept_names": [
        "Alkaline phosphatase",
        "Alkaline phosphatase [Enzymatic activity/volume] in Serum or Plasma",
        "Alkaline phosphatase | Serum or Plasma | Chemistry - non-challenge",
    ],
}
