# ------------------------------------------------------------------------
# RF-DETR
# Copyright (c) 2025 Roboflow. All Rights Reserved.
# Licensed under the Apache License, Version 2.0 [see LICENSE for details]
# ------------------------------------------------------------------------
# Copied and modified from LW-DETR (https://github.com/Atten4Vis/LW-DETR)
# Copyright (c) 2024 Baidu. All Rights Reserved.
# ------------------------------------------------------------------------
"""
CustomOpSymbolicRegistry class
"""



class CustomOpSymbolicRegistry:
    # _SYMBOLICS = {}
    _OPTIMIZER = []

    @classmethod
    def optimizer(cls, fn):
        cls._OPTIMIZER.append(fn)


def register_optimizer():
    def optimizer_wrapper(fn):
        CustomOpSymbolicRegistry.optimizer(fn)
        return fn
    return optimizer_wrapper
