"""Parsing utilities for Futu OpenD data types."""
