"""OAuth support for MCP servers — token storage, browser flow, CLI commands."""
