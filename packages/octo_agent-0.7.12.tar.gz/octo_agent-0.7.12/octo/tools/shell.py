"""Backward-compat shim — moved to octo.core.tools.shell."""
from octo.core.tools.shell import *  # noqa: F401,F403
from octo.core.tools.shell import bash_tool
