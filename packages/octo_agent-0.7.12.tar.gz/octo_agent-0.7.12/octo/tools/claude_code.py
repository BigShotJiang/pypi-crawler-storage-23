"""Backward-compat shim — moved to octo.core.tools.claude_code."""
from octo.core.tools.claude_code import *  # noqa: F401,F403
from octo.core.tools.claude_code import claude_code, claude_code_tool
