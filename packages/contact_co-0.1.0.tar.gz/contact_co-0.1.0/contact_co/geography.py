import phonenumbers
from phonenumbers import geocoder

class ZoneDetector:
    def detect_region(self, phone_str: str, default_region="General"):
        """
        Intenta detectar la región basada en el número telefónico (Fijos).
        Para celulares, retorna default_region a menos que se implemente
        lógica adicional con base de datos externa.
        """
        try:
            # Parsear número (asumiendo CO si no tiene +57)
            if not phone_str.startswith('+'):
                phone_str = "+57" + phone_str
            
            parsed_num = phonenumbers.parse(phone_str, "CO")
            
            if not phonenumbers.is_valid_number(parsed_num):
                 return default_region

            # Obtener ubicación geográfica (solo funciona bien para fijos)
            location_desc = geocoder.description_for_number(parsed_num, "es")
            location_lower = location_desc.lower()
            
            # Mapeo simple de keywords a regiones
            caribe_keywords = ['atlántico', 'bolívar', 'magdalena', 'cesar', 'córdoba', 'sucre', 'la guajira', 'barranquilla', 'cartagena', 'santa marta']
            andina_keywords = ['bogotá', 'cundinamarca', 'boyacá', 'antioquia', 'medellín', 'tolima', 'huila', 'manizales', 'pereira']
            
            if any(k in location_lower for k in caribe_keywords):
                return "Caribe"
            
            if any(k in location_lower for k in andina_keywords):
                return "Andina"
                
            return default_region
            
        except Exception as e:
            # En caso de error de parseo, asumimos general
            return default_region
