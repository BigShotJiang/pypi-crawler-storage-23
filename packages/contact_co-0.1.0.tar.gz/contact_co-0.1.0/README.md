# contact-co

Librería de validación sociodemográfica y legal para contacto en Colombia.

## Instalación

```bash
pip install contact-co
```

## Uso

```python
from contact_co import ContactScorer

scorer = ContactScorer(...)
```

## Dependencias

- `holidays`
- `phonenumbers`
- `sodapy`
- `pandas`

## Licencia

Propietario — PECS CPSS
