from setuptools import setup, find_packages

setup(
    name="contact_co",
    version="0.1.0",
    packages=find_packages(where="."),
    package_dir={"": "."},
    include_package_data=True,
    install_requires=[
        "holidays",
        "phonenumbers",
        "sodapy",
        "pandas"
    ],
    author="PECS CPSS",
    description="Librería de validación sociodemográfica y legal para contacto en Colombia",
    python_requires=">=3.8",
)
