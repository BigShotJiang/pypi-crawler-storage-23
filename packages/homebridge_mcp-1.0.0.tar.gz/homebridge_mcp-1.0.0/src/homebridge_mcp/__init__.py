"""Homebridge MCP Server - Control Homebridge devices via Claude Code."""

__version__ = "1.0.0"
