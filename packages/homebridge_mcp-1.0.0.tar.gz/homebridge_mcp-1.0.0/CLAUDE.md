# Homebridge MCP Server

MCP server for controlling Homebridge smart home devices via Claude Code.

## Tech Stack

- Python 3.10+
- MCP SDK
- httpx, pydantic
- macOS launchctl integration
- Hatchling build system

## Available Tools (7 total)

- `homebridge_list_devices` - List all accessories with current status
- `homebridge_get_device` - Get device details by name/UUID
- `homebridge_status` - Get service status and configuration
- `homebridge_logs` - View recent logs
- `homebridge_restart` - Restart Homebridge service
- `homebridge_config` - View configuration (view, get_platforms, get_accessories)
- `homebridge_search_device` - Search by name, type, or manufacturer

## Device Support

- LG ThinQ devices (refrigerators, washers, ACs)
- Standard HomeKit accessories (lights, switches, sensors)
- Temperature/thermostat devices
- Contact and motion sensors

## Setup

```bash
cd ~/personal-projects/homebridge-mcp
uv venv && uv pip install -e .

# Add to Claude Code
claude mcp add homebridge -- uv --directory ~/personal-projects/homebridge-mcp run homebridge-mcp
```

Or in `~/.claude.json`:
```json
{
  "homebridge": {
    "type": "stdio",
    "command": "uv",
    "args": ["run", "--directory", "/path/to/homebridge-mcp", "homebridge-mcp"]
  }
}
```

## File Paths

- Config: `~/.homebridge/config.json`
- Cached accessories: `~/.homebridge/accessories/cachedAccessories`
- Logs: `~/.homebridge/homebridge.log`

## Key Files

- `src/homebridge_mcp/server.py` - MCP server and tool implementations
- `pyproject.toml` - Dependencies and build config

## Service Management

Uses macOS launchctl to manage Homebridge:
- Service label: `com.homebridge.server`
- Restart waits for service stabilization
