def main():
    print("Hello from airflow-unfactor!")


if __name__ == "__main__":
    main()
