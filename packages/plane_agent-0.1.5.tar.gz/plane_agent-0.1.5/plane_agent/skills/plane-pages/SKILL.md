---
description: Tools for managing Plane pages.
name: plane-pages
tools:
- retrieve_workspace_page
- retrieve_project_page
- create_workspace_page
- create_project_page
---
# plane-pages

Tools for managing Plane pages.

## Tools
- retrieve_workspace_page
- retrieve_project_page
- create_workspace_page
- create_project_page
