---
description: Tools for managing Plane work item activities.
name: plane-work-item-activities
tools:
- list_work_item_activities
- retrieve_work_item_activity
---
# plane-work-item-activities

Tools for managing Plane work item activities.

## Tools
- list_work_item_activities
- retrieve_work_item_activity
