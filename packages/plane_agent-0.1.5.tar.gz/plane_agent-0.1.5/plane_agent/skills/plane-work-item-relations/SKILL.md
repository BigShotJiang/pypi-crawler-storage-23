---
description: Tools for managing Plane work item relations.
name: plane-work-item-relations
tools:
- list_work_item_relations
- create_work_item_relation
- remove_work_item_relation
---
# plane-work-item-relations

Tools for managing Plane work item relations.

## Tools
- list_work_item_relations
- create_work_item_relation
- remove_work_item_relation
