---
description: Tools for managing Plane work logs.
name: plane-work-logs
tools:
- list_work_logs
- create_work_log
- update_work_log
- delete_work_log
---
# plane-work-logs

Tools for managing Plane work logs.

## Tools
- list_work_logs
- create_work_log
- update_work_log
- delete_work_log
