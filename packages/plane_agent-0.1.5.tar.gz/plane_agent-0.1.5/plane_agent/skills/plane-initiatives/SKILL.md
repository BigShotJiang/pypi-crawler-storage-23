---
description: Tools for managing Plane initiatives.
name: plane-initiatives
tools:
- list_initiatives
- create_initiative
- retrieve_initiative
- update_initiative
- delete_initiative
---
# plane-initiatives

Tools for managing Plane initiatives.

## Tools
- list_initiatives
- create_initiative
- retrieve_initiative
- update_initiative
- delete_initiative
