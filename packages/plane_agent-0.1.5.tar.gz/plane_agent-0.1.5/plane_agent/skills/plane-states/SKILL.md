---
description: Tools for managing Plane states.
name: plane-states
tools:
- list_states
- create_state
- retrieve_state
- update_state
- delete_state
---
# plane-states

Tools for managing Plane states.

## Tools
- list_states
- create_state
- retrieve_state
- update_state
- delete_state
