---
description: Tools for managing Plane projects.
name: plane-projects
tools:
- list_projects
- create_project
- retrieve_project
- update_project
- delete_project
- get_project_worklog_summary
- get_project_members
- get_project_features
- update_project_features
---
# plane-projects

Tools for managing Plane projects.

## Tools
- list_projects
- create_project
- retrieve_project
- update_project
- delete_project
- get_project_worklog_summary
- get_project_members
- get_project_features
- update_project_features
