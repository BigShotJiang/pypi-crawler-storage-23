---
description: Tools for managing Plane work item comments.
name: plane-work-item-comments
tools:
- list_work_item_comments
- retrieve_work_item_comment
- create_work_item_comment
- update_work_item_comment
- delete_work_item_comment
---
# plane-work-item-comments

Tools for managing Plane work item comments.

## Tools
- list_work_item_comments
- retrieve_work_item_comment
- create_work_item_comment
- update_work_item_comment
- delete_work_item_comment
