import json
from enum import Enum, auto
from pathlib import Path
from .geometry import process_points, process_lines, process_polygons, process_jetstreamwindsymbol
from lxml import etree
from .constants import extract_wmo_data

class SigwxParser:
    """
    Parses WAFS IWXXM SIGWX XML files into a list of forecast objects.

    Because SIGWX data is grouped into specific 3-hour forecast blocks, this parser
    isolates each block, extracting its specific valid time and issue time. It then
    processes all meteorological features (icing, turbulence, jetstreams, etc.) within
    that block into a FeatureCollection in one of three supported output formats:
    ``"geojson"``, ``"wkt"``, or ``"wkb"``.

    The top-level key of the feature collection in the returned dict matches the
    ``output_format`` value (e.g. ``"geojson"``, ``"wkt"``, or ``"wkb"``).

    **GeoJSON output** (``output_format="geojson"``, default)::

        [
            {
                "valid_time": "2024-02-22T12:00:00Z",
                "issue_time": "2024-02-21T18:00:00Z",
                "geojson": {
                    "type": "FeatureCollection",
                    "features": [
                        {
                            "type": "Feature",
                            "geometry": {
                                "type": "Polygon",
                                "coordinates": [ [ [lon, lat], ... ] ]
                            },
                            "properties": {
                                "feature_id": "uuid.12345...",
                                "phenomenon": "AIRFRAME_ICING",
                                "upper_fl": "240",
                                "lower_fl": "100"
                            }
                        }
                    ]
                }
            }
        ]

    **WKT output** (``output_format="wkt"``)::

        [
            {
                "valid_time": "2024-02-22T12:00:00Z",
                "issue_time": "2024-02-21T18:00:00Z",
                "wkt": {
                    "features": [
                        {
                            "geometry": "POLYGON ((lon lat, ...))",
                            "properties": {
                                "feature_id": "uuid.12345...",
                                "phenomenon": "AIRFRAME_ICING",
                                "upper_fl": "240",
                                "lower_fl": "100"
                            }
                        }
                    ]
                }
            }
        ]

    **WKB output** (``output_format="wkb"``)::

        [
            {
                "valid_time": "2024-02-22T12:00:00Z",
                "issue_time": "2024-02-21T18:00:00Z",
                "wkb": {
                    "features": [
                        {
                            "geometry": "0103000000...",
                            "properties": {
                                "feature_id": "uuid.12345...",
                                "phenomenon": "AIRFRAME_ICING",
                                "upper_fl": "240",
                                "lower_fl": "100"
                            }
                        }
                    ]
                }
            }
        ]

    Note: WKB geometries are hex-encoded strings for JSON compatibility.
    Convert to raw bytes for database storage with ``bytes.fromhex(feature["geometry"])``.
    """
    def __init__(self, file_path: str, xml_content: str = None):
        """
        Initializes the parser with either a file path or raw XML content.

        Args:
            file_path (str): The path to the SIGWX XML file. Can be None if xml_content is provided.
            xml_content (str, optional): Raw XML string content. Defaults to None.

        Raises:
            FileNotFoundError: If the provided file_path does not exist.
            ValueError: If neither a valid file_path nor xml_content is provided.
        """
        self.file_path = file_path
        self.xml_content = xml_content
        self.root = None

        if file_path:
            path = Path(file_path)
            if not path.is_file():
                raise FileNotFoundError(f"Could not find a file at: {path.absolute()}")
            raw_text = path.read_text(encoding='utf-8')
        elif xml_content:
            raw_text = xml_content
        else:
            raise ValueError("Either file_path or xml_content must be provided.")
        self.root = self._clean_xml_string(raw_text)

    @staticmethod
    def _clean_xml_string(raw_text: str):
        """
        Strips namespaces, BOM characters, and whitespace from the raw XML text.

        Args:
            raw_text (str): The raw XML string.

        Returns:
            lxml.etree._Element: The cleaned root element of the XML tree.
        """
        clean_text = raw_text.replace('\uFEFF', '').strip()
        parser = etree.XMLParser(recover=True)
        root = etree.fromstring(clean_text.encode('utf-8'), parser=parser)

        for elem in root.iter():
            elem.tag = etree.QName(elem).localname

            clean_attribs = {etree.QName(k).localname: v for k, v in elem.attrib.items()}
            elem.attrib.clear()
            elem.attrib.update(clean_attribs)

        etree.cleanup_namespaces(root)

        return root

    @staticmethod
    def _safe_text(element, default="N/A"):
        """
        Safely extracts and strips text from an lxml element.

        Args:
            element (lxml.etree._Element): The XML element to extract text from.
            default (str, optional): The value to return if the element or its text is None. Defaults to "N/A".

        Returns:
            str: The extracted text or the default value.
        """
        if element is not None and element.text is not None:
            return element.text.strip()
        return default

    @staticmethod
    def _safe_href(element, default="N/A"):
        """
        Safely extracts and strips the ``href`` attribute from an lxml element.

        Args:
            element (lxml.etree._Element): The XML element to extract the href from.
            default (str, optional): The value to return if the element is None or
                has no href attribute. Defaults to "N/A".

        Returns:
            str: The extracted href value or the default value.
        """
        if element is not None:
            href = element.get("href")
            if href:
                return href.strip()
        return default

    def parse(self, exclude: set = {}, output_format: str = "geojson") -> list:
        """
        Executes the main parsing loop over the cleaned XML tree.

        Iterates through each WAFSSignificantWeatherForecast block, extracts
        the valid and issue times, and processes all associated meteorological
        features (polygons, points, lines) into a feature collection.

        Args:
            exclude (set, optional): A set of phenomenon type strings to skip
                during parsing. Features whose phenomenon type matches any
                value in this set will be excluded from the output.
                Defaults to an empty set (no features excluded).

                Valid values are:
                    - ``AIRFRAME_ICING``
                    - ``CLOUD``
                    - ``JETSTREAM``
                    - ``TROPOPAUSE``
                    - ``TURBULENCE``
                    - ``RADIATION``
                    - ``TROPICAL_CYCLONE``
                    - ``VOLCANO``

            output_format (str, optional): Controls the geometry representation.
                Defaults to ``"geojson"``.

                Supported values:

                - ``"geojson"`` — Returns standard GeoJSON FeatureCollections.
                  Antimeridian splitting and polygon winding order correction are applied.
                - ``"wkt"`` — Returns geometries as WKT strings (e.g. ``"POLYGON ((...))"``).
                - ``"wkb"`` — Returns geometries as WKB hex-encoded strings
                  (e.g. ``"0103000000..."``). Use ``bytes.fromhex(geom)`` to get
                  raw bytes suitable for database insertion.

        Returns:
            list: A list of forecast dictionaries. Each dict contains ``valid_time``,
                ``issue_time``, and a feature collection keyed by the ``output_format``
                value (i.e. ``"geojson"``, ``"wkt"``, or ``"wkb"``).
        """
        forecasts = self.root.xpath("//WAFSSignificantWeatherForecast")
        collections = []
        for f in forecasts:
            valid_time = self._safe_text(f.find(".//beginPosition"))
            issue_time = self._safe_text(f.find(".//timePosition"))

            feature_collection = {
                "type": "FeatureCollection",
                "features": []
            } if output_format == "geojson" else {"features": []}
            met_features = f.xpath(".//MeteorologicalFeature")

            for feature in met_features:
                feature_type = self._safe_href(feature.find(".//phenomenon")).split("/")[-1] or "N/A"
                if feature_type in exclude:
                    continue

                feature_id = feature.get("id").strip() if feature.get("id") else "N/A"
                upper_fl = self._safe_text(feature.find(".//upperElevation"))
                lower_fl = self._safe_text(feature.find(".//lowerElevation"))

                match feature_type:
                    case "AIRFRAME_ICING":
                        degree_of_icing = self._safe_href(feature.find(".//DegreeOfIcing"))
                        processed_polygon = process_polygons(output_format=output_format,
                                                             feature_type=feature_type,
                                                             polygon_patch=feature.find(".//PolygonPatch"),
                                                             feature_id=feature_id,
                                                             upper_fl=upper_fl,
                                                             lower_fl=lower_fl,
                                                             **extract_wmo_data(degree_of_icing))
                        feature_collection.get("features").append(processed_polygon)
                    case "CLOUD":
                        cloud_distribution = self._safe_href(feature.find(".//CloudDistribution"))
                        cloud_type = self._safe_href(feature.find(".//CloudType"))
                        processed_polygon = process_polygons(output_format=output_format,
                                                             feature_type=feature_type,
                                                             polygon_patch=feature.find(".//PolygonPatch"),
                                                             feature_id=feature_id,
                                                             upper_fl=upper_fl,
                                                             lower_fl=lower_fl,
                                                             **extract_wmo_data(cloud_distribution),
                                                             **extract_wmo_data(cloud_type))
                        feature_collection.get("features").append(processed_polygon)
                    case "TURBULENCE":
                        degree_of_turbulence = self._safe_href(feature.find(".//DegreeOfTurbulence"))
                        processed_polygon = process_polygons(output_format=output_format,
                                                             feature_type=feature_type,
                                                             polygon_patch=feature.find(".//PolygonPatch"),
                                                             feature_id=feature_id,
                                                             upper_fl=upper_fl,
                                                             lower_fl=lower_fl,
                                                             **extract_wmo_data(degree_of_turbulence))
                        feature_collection.get("features").append(processed_polygon)
                    case "JETSTREAM":
                        processed_line = process_lines(output_format=output_format,
                                                       feature_type=feature_type,
                                                       line=feature.find(".//CubicSpline"),
                                                       feature_id=feature_id)
                        feature_collection.get("features").append(processed_line)
                        jetstreamsymbols = feature.findall(".//WAFSJetStreamWindSymbol")
                        for idx, symbol in enumerate(jetstreamsymbols):
                            symbol_id = symbol.get("id").strip() if symbol.get("id") else "N/A"
                            fl = self._safe_text(symbol.find(".//elevation"))
                            windspeed= self._safe_text(symbol.find("./windSpeed"))
                            processed_symbol = process_jetstreamwindsymbol(output_format=output_format,
                                                                           feature_type=feature_type,
                                                                           symbol=symbol,
                                                                           feature_id=symbol_id,
                                                                           fl=fl,
                                                                           windspeed=windspeed)
                            feature_collection.get("features").append(processed_symbol)
                    case "TROPOPAUSE":
                        elevation = self._safe_text(feature.find(".//elevation"))
                        processed_polygon = process_polygons(output_format=output_format,
                                                             feature_type=feature_type,
                                                             polygon_patch=feature.find(".//Polygon"),
                                                             feature_id=feature_id,
                                                             fl=elevation
                                                             )
                        feature_collection.get("features").append(processed_polygon)
                    case "RADIATION":
                        continue
                    case "TROPICAL_CYCLONE":
                        name = self._safe_text(feature.find(".//name"))
                        processed_point = process_points(output_format=output_format,
                                                         feature_type=feature_type,
                                                         point=feature.find(".//Point"),
                                                         feature_id=feature_id,
                                                         name=name)
                        feature_collection.get("features").append(processed_point)
                    case "VOLCANO":
                        name = self._safe_text(feature.find(".//name"))
                        processed_point = process_points(output_format=output_format,
                                                         feature_type=feature_type,
                                                         point=feature.find(".//Point"),
                                                         feature_id=feature_id,
                                                         name=name)
                        feature_collection.get("features").append(processed_point)


            collections.append({
                "valid_time": valid_time,
                "issue_time": issue_time,
                output_format: feature_collection})
        return collections