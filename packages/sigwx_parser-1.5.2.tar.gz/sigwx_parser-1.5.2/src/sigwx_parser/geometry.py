from typing import Optional
from xml.etree.ElementTree import Element

import antimeridian
from shapely.geometry import shape, mapping
from shapely.geometry.polygon import orient
from shapely.geometry import Point, LineString, Polygon


def _parse_poslist(element: Element) -> list:
    """Parse a GML posList element into [[lon, lat], ...] coordinates.

    Args:
        element: An XML element whose text contains space-separated lat/lon pairs.

    Returns:
        A list of [lon, lat] coordinate pairs as floats.

    Raises:
        ValueError: If the element has no text content.
    """
    if element.text is None:
        raise ValueError("posList element has no text content")
    raw = element.text.strip().split()
    return [[float(y), float(x)] for x, y in zip(raw[::2], raw[1::2])]


def _build_feature(geometry: dict, feature_type: str, feature_id: str, **kwargs) -> dict:
    """Build a GeoJSON Feature dict from geometry and properties.

    Args:
        geometry: A GeoJSON geometry dict (e.g. ``{"type": "Polygon", "coordinates": [...]}``.
        feature_type: The phenomenon type label for the feature.
        feature_id: A unique identifier for the feature.
        **kwargs: Additional properties to merge into the feature's ``properties`` object.

    Returns:
        A GeoJSON Feature dict.
    """
    feature = {
        "type": "Feature",
        "geometry": geometry,
        "properties": {
            "feature_id": feature_id,
            "phenomenon": feature_type,
        },
    }
    feature["properties"].update(kwargs)
    return feature

def _build_wk_feature(geometry: str, feature_type: str, feature_id: str, **kwargs) -> dict:
    """Build a WKT or WKB feature dict from geometry and properties.

    Args:
        geometry: A WKT geometry string (e.g. ``"POLYGON ((...))"``), or a
            WKB hex-encoded string (e.g. ``"0103000000..."``).
        feature_type: The phenomenon type label for the feature.
        feature_id: A unique identifier for the feature.
        **kwargs: Additional properties to merge into the feature's ``properties`` object.

    Returns:
        A dict with ``'geometry'`` (WKT string or WKB hex string) and ``'properties'``.
        Note: WKB is returned as a hex-encoded string so that it remains JSON-serializable.
        To get raw bytes for database storage, call ``bytes.fromhex(feature["geometry"])``.
    """
    feature = {
        "geometry": geometry,
        "properties": {
            "feature_id": feature_id,
            "phenomenon": feature_type,
        },
    }
    feature["properties"].update(kwargs)
    return feature
def process_polygons(output_format: str, feature_type: str, polygon_patch: Element, feature_id: str,
                     **kwargs) -> dict:
    """Parse a GML PolygonPatch element and return a GeoJSON Feature with Polygon geometry.

    Args:
        feature_type: The phenomenon type label for the feature.
        polygon_patch: An XML element containing the GML PolygonPatch data.
        feature_id: A unique identifier for the feature.
        **kwargs: Additional properties to include in the feature (e.g. ``upper_fl``,
            ``lower_fl``, ``degree_of_icing``, ``cloud_type``, ``fl``, etc.).

    Returns:
        A GeoJSON Feature dict with Polygon geometry.

    Raises:
        ValueError: If required XML elements are missing or have no text content.
    """
    if polygon_patch is None:
        raise ValueError(f"Missing PolygonPatch element in feature {feature_id}")
    exterior_el = polygon_patch.find(".//exterior//posList")
    if exterior_el is None or exterior_el.text is None:
        raise ValueError(f"Missing exterior posList in feature {feature_id}")
    exterior = _parse_poslist(exterior_el)

    interiors = []
    for interior in polygon_patch.findall(".//interior//posList"):
        if interior.text is None:
            raise ValueError(f"Missing interior posList text in feature {feature_id}")
        interiors.append(_parse_poslist(interior))

    if output_format != "geojson":
        fixed = antimeridian.fix_polygon(Polygon(exterior, interiors))
        match output_format:
            case "wkt":
                return _build_wk_feature(fixed.wkt, feature_type, feature_id, **kwargs)
            case "wkb":
                return _build_wk_feature(fixed.wkb_hex, feature_type, feature_id, **kwargs)
            case _:
                raise ValueError(f"Unsupported output format: {output_format}")
    feature = _build_feature(
        {"type": "Polygon", "coordinates": [exterior, *interiors]},
        feature_type,
        feature_id,
        **kwargs,
    )
    raw_shape = shape(feature["geometry"])
    properly_wound_shape = orient(raw_shape, sign=1.0)
    feature["geometry"] = mapping(properly_wound_shape)

    fixed_feature = antimeridian.fix_geojson(feature)
    return fixed_feature


def process_points(output_format: str, feature_type: str, point: Element, feature_id: str,
                   **kwargs) -> dict:
    """Parse a GML Point element and return a GeoJSON Feature with Point geometry.

    Args:
        feature_type: The phenomenon type label for the feature.
        point: An XML element containing the GML Point data.
        feature_id: A unique identifier for the feature.
        **kwargs: Additional properties to include in the feature (e.g. ``upper_fl``,
            ``lower_fl``, ``name``, etc.).

    Returns:
        A GeoJSON Feature dict with Point geometry.

    Raises:
        ValueError: If required XML elements are missing or have no text content.
    """
    if point is None:
        raise ValueError(f"Missing Point element in feature {feature_id}")
    pos_el = point.find(".//pos")
    if pos_el is None or pos_el.text is None:
        raise ValueError(f"Missing pos element in feature {feature_id}")
    coords = pos_el.text.strip().split()
    coords[1], coords[0] = float(coords[0]), float(coords[1])  # Swap to [lon, lat] (GeoJSON order)
    if output_format != "geojson":
        match output_format:
            case "wkt":
                wkt_point = Point(coords).wkt
                return _build_wk_feature(wkt_point, feature_type, feature_id, **kwargs)
            case "wkb":
                wkb_point = Point(coords).wkb_hex
                return _build_wk_feature(wkb_point, feature_type, feature_id, **kwargs)
            case _:
                raise ValueError(f"Unsupported output format: {output_format}")
    return _build_feature(
        {"type": "Point", "coordinates": coords},
        feature_type,
        feature_id,
        **kwargs
    )


def process_lines(output_format: str, feature_type: str, line: Element, feature_id: str,
                  **kwargs) -> dict:
    """Parse a GML curve/line element and return a GeoJSON Feature with LineString geometry.

    Args:
        feature_type: The phenomenon type label for the feature.
        line: An XML element containing the GML line data.
        feature_id: A unique identifier for the feature.
        **kwargs: Additional properties to include in the feature.

    Returns:
        A GeoJSON Feature dict with LineString geometry.

    Raises:
        ValueError: If required XML elements are missing or have no text content.
        :param output_format: "geojson", "wkt", or "wkb" to specify the desired output geometry format.
    """
    if line is None:
        raise ValueError(f"Missing line element in feature {feature_id}")
    poslist_el = line.find(".//posList")
    if poslist_el is None or poslist_el.text is None:
        raise ValueError(f"Missing posList element in feature {feature_id}")
    coords = _parse_poslist(poslist_el)
    if output_format != "geojson":
        fixed = antimeridian.fix_line_string(LineString(coords), great_circle=True)
        match output_format:
            case "wkt":
                return _build_wk_feature(fixed.wkt, feature_type, feature_id, **kwargs)
            case "wkb":
                return _build_wk_feature(fixed.wkb_hex, feature_type, feature_id, **kwargs)
            case _:
                raise ValueError(f"Unsupported output format: {output_format}")
    feature = _build_feature(
        {"type": "LineString", "coordinates": coords},
        feature_type,
        feature_id,
        **kwargs
    )
    fixed_feature = antimeridian.fix_geojson(feature)
    return fixed_feature

def process_jetstreamwindsymbol(output_format: str, feature_type: str, symbol: Element, feature_id: str,
                                **kwargs) -> dict:
    """Parse a GML JetStreamWindSymbol element and return a GeoJSON Feature with Point geometry.

    Args:
        feature_type: The phenomenon type label for the feature.
        symbol: An XML element containing the GML JetStreamWindSymbol data.
        feature_id: A unique identifier for the feature.
        **kwargs: Additional properties to include in the feature (e.g. ``fl``,
            ``windspeed``, etc.).

    Returns:
        A GeoJSON Feature dict with Point geometry.

    Raises:
        ValueError: If required XML elements are missing or have no text content.
        :param output_format: "geojson", "wkt", or "wkb" to specify the desired output geometry format.
    """
    if symbol is None:
        raise ValueError(f"Missing symbol element in feature {feature_id}")
    pos_el = symbol.find(".//pos")
    if pos_el is None or pos_el.text is None:
        raise ValueError(f"Missing pos element in feature {feature_id}")
    coords = pos_el.text.strip().split()
    coords[1], coords[0] = float(coords[0]), float(coords[1])  # Swap to [lon, lat] (GeoJSON order)
    if output_format != "geojson":
        match output_format:
            case "wkt":
                wkt_point = Point(coords).wkt
                return _build_wk_feature(wkt_point, feature_type, feature_id, **kwargs)
            case "wkb":
                wkb_point = Point(coords).wkb_hex
                return _build_wk_feature(wkb_point, feature_type, feature_id, **kwargs)
            case _:
                raise ValueError(f"Unsupported output format: {output_format}")
    feature = _build_feature(
        {"type": "Point", "coordinates": coords},
        feature_type,
        feature_id,
        **kwargs
    )
    return feature

