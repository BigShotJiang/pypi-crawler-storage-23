"""Event hooks system for customizing agent behavior at key execution points."""

from grip.hooks.manager import HooksManager

__all__ = ["HooksManager"]
