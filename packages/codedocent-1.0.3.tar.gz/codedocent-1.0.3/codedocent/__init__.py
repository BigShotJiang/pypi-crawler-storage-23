"""codedocent — code visualization for non-programmers."""
