"""Allow running codedocent as `python3 -m codedocent`."""
from codedocent.cli import main

main()
