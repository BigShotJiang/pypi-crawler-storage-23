"""Guard type implementations."""
