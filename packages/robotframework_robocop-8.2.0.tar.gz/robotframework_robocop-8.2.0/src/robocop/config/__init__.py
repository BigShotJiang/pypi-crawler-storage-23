from robocop.config.manager import ConfigManager
from robocop.config.schema import Config

__all__ = ["Config", "ConfigManager"]
