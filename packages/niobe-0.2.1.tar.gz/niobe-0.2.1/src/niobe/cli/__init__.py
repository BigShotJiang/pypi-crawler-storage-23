"""Niobe CLI."""
