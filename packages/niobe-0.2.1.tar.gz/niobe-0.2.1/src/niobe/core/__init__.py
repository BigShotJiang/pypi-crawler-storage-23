"""Niobe core logic."""
