==========
 Notifier
==========

.. currentmodule:: oslo_messaging

.. autoclass:: Notifier
   :members:

.. autoclass:: LoggingNotificationHandler
   :members:

.. autoclass:: LoggingErrorNotificationHandler
   :members:

Available Notifier Drivers
==========================

.. list-plugins:: oslo.messaging.notify.drivers
   :detailed:
