---------------------
Notification Listener
---------------------

.. automodule:: oslo_messaging.notify.listener

.. currentmodule:: oslo_messaging

.. autofunction:: get_notification_listener

.. autofunction:: get_batch_notification_listener
