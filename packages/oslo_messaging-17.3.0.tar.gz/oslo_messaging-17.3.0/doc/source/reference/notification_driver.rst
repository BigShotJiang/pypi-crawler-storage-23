-------------------
Notification Driver
-------------------

.. automodule:: oslo_messaging.notify.messaging

.. autoclass:: MessagingDriver

.. autoclass:: MessagingV2Driver

.. currentmodule:: oslo_messaging.notify.notifier

.. autoclass:: Driver
   :members:
   :noindex:
