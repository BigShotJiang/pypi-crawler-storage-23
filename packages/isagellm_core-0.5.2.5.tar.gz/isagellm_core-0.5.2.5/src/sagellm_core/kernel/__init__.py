"""Kernel injection framework for sageLLM.

This module implements the kernel injection framework that connects
backend kernel implementations to core model layers.

Architecture (issue #36, #39):
1. KernelRegistry: Central registry for all kernel implementations
2. KernelInjector: Injects kernels into model layers
3. KernelLoader: Loads kernels from backend providers
4. FusionDetector: Detects and applies fusion opportunities

Depends on:
- issue #34: Operator mapping protocol
- issue #35: Layer-wise model builder
"""

from __future__ import annotations

from sagellm_core.kernel.kernel_registry import KernelRegistry, KernelSpec
from sagellm_core.kernel.kernel_injector import KernelInjector
from sagellm_core.kernel.kernel_loader import KernelLoader
from sagellm_core.kernel.fusion_detector import (
    FusionDetector,
    FusionStats,
    detect_and_apply_fusions,
)

__all__ = [
    "KernelRegistry",
    "KernelSpec",
    "KernelInjector",
    "KernelLoader",
    "FusionDetector",
    "FusionStats",
    "detect_and_apply_fusions",
]
