"""Entry point for: python -m antaris_guard.mcp_server"""
from antaris_guard.mcp_server import main
main()
