"""
FeatrixSphere main client class.

This is the entry point for the new FeatrixSphere API.
"""

import io
import gzip
import json
import logging
import os
import requests
from pathlib import Path
from typing import Dict, Any, Optional, List, Union, TYPE_CHECKING

if TYPE_CHECKING:
    import pandas as pd
    from .prediction_grid import PredictionGrid

from .http_client import HTTPClientMixin, ClientContext
from .foundational_model import FoundationalModel
from .predictor import Predictor
from .published_predictor import PublishedPredictor
from .vector_database import VectorDatabase
from .prediction_result import PredictionFeedback
from .api_endpoint import APIEndpoint
from .notebook_helper import FeatrixNotebookHelper

logger = logging.getLogger(__name__)

# Config file location
FEATRIX_CONFIG_FILE = Path.home() / ".featrix"


def _load_config() -> Dict[str, str]:
    """Load config from ~/.featrix file.

    Supports two formats:
    1. JSON: {"api_key": "sk_live_...", "base_url": "https://..."}
    2. Env-style: api_key=sk_live_...

    Also checks FEATRIX_API_KEY environment variable.

    Returns:
        Dict with 'api_key' and optionally 'base_url'.
    """
    config = {}

    # Check environment variable first
    env_key = os.getenv("FEATRIX_API_KEY")
    if env_key:
        config["api_key"] = env_key

    env_url = os.getenv("FEATRIX_BASE_URL")
    if env_url:
        config["base_url"] = env_url

    # Then check config file (env vars take precedence)
    if FEATRIX_CONFIG_FILE.exists():
        try:
            content = FEATRIX_CONFIG_FILE.read_text().strip()

            # Try JSON format first
            if content.startswith('{'):
                file_config = json.loads(content)
            else:
                # Parse env-style format: key=value
                file_config = {}
                for line in content.splitlines():
                    line = line.strip()
                    if '=' in line and not line.startswith('#'):
                        key, value = line.split('=', 1)
                        value = value.strip()
                        # Strip surrounding quotes (single or double)
                        if len(value) >= 2 and value[0] == value[-1] and value[0] in ('"', "'"):
                            value = value[1:-1]
                        file_config[key.strip().lower()] = value

            # Only use file values if not already set from env
            # Support both "api_key" and "featrix_api_key" in config file
            if "api_key" not in config:
                if "api_key" in file_config:
                    config["api_key"] = file_config["api_key"]
                elif "featrix_api_key" in file_config:
                    config["api_key"] = file_config["featrix_api_key"]
            if "base_url" not in config:
                if "base_url" in file_config:
                    config["base_url"] = file_config["base_url"]
                elif "featrix_base_url" in file_config:
                    config["base_url"] = file_config["featrix_base_url"]

        except Exception as e:
            logger.debug(f"Failed to read config from {FEATRIX_CONFIG_FILE}: {e}")

    return config


class FeatrixSphere(HTTPClientMixin):
    """
    Main client for interacting with FeatrixSphere.

    This is the entry point for the new object-oriented API.

    Usage:
        from featrixsphere.api import FeatrixSphere

        # Option 1: API key from ~/.featrix or FEATRIX_API_KEY env var
        featrix = FeatrixSphere()

        # Option 2: Explicit API key
        featrix = FeatrixSphere(api_key="sk_live_your_api_key")

        # Create foundational model
        fm = featrix.create_foundational_model(
            name="my_model",
            data_file="data.csv"
        )
        fm.wait_for_training()

        # Create predictor
        predictor = fm.create_binary_classifier(
            name="my_classifier",
            target_column="target"
        )
        predictor.wait_for_training()

        # Make predictions
        result = predictor.predict({"feature1": "value1"})
        print(result.predicted_class)
        print(result.confidence)

    Configuration:
        Create ~/.featrix with your API key:

            echo 'api_key=sk_live_your_api_key' > ~/.featrix

        Or use JSON format:

            {"api_key": "sk_live_...", "base_url": "https://..."}

        Or set environment variable:

            export FEATRIX_API_KEY=sk_live_your_api_key

    On-Premises Deployment:
        Featrix offers on-premises data processing with qualified NVIDIA
        hardware configurations. The API works exactly the same - just
        point your client to your on-premises endpoint:

        featrix = FeatrixSphere(base_url="https://your-on-premises-server.com")
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        base_url: str = "https://sphere-api.featrix.com",
        compute_cluster: Optional[str] = None,
        project: Optional[str] = None,
        default_max_retries: int = 5,
        default_timeout: int = 30,
        retry_base_delay: float = 2.0,
        retry_max_delay: float = 60.0,
    ):
        """
        Initialize the FeatrixSphere client.

        Args:
            api_key: Your Featrix API key. If not provided, looks for:
                1. FEATRIX_API_KEY environment variable
                2. api_key in ~/.featrix config file
            base_url: API server URL. Can also be set via FEATRIX_BASE_URL env var
                or base_url in ~/.featrix config file.
            compute_cluster: Compute cluster name (e.g., "burrito", "churro")
            project: Project name or ID. If provided, verifies the project exists
                and sets it as the current project for all subsequent operations.
            default_max_retries: Default retry count for failed requests
            default_timeout: Default request timeout in seconds
            retry_base_delay: Base delay for exponential backoff
            retry_max_delay: Maximum delay for exponential backoff

        Raises:
            ValueError: If api_key is not found in arguments, env vars, or config file

        Config file format (~/.featrix):
            JSON:  {"api_key": "sk_live_...", "base_url": "https://..."}
            or
            Env:   api_key=sk_live_...
                   base_url=https://...
        """
        # Load config from env vars and ~/.featrix
        config = _load_config()

        # Use provided api_key, or fall back to config
        if not api_key:
            api_key = config.get("api_key")

        if not api_key:
            raise ValueError(
                "api_key is required. Provide it as an argument, set FEATRIX_API_KEY "
                "environment variable, or add it to ~/.featrix config file."
            )

        if not api_key.startswith("fx_"):
            raise ValueError(
                f"Invalid API key (must start with 'fx_'). Got: {api_key[:20]}... "
                "Check ~/.featrix or FEATRIX_API_KEY environment variable."
            )

        # Use provided base_url, or fall back to config (only if not the default)
        if base_url == "https://sphere-api.featrix.com" and "base_url" in config:
            base_url = config["base_url"]

        self._base_url = base_url.rstrip('/')
        self._session = requests.Session()
        self._session.timeout = default_timeout

        # Set API key header
        self._session.headers.update({'X-Api-Key': api_key})

        # Set User-Agent
        try:
            from featrixsphere import __version__
            self._session.headers.update({'User-Agent': f'FeatrixSphere {__version__}'})
        except ImportError:
            self._session.headers.update({'User-Agent': 'FeatrixSphere'})

        # Compute cluster
        self._compute_cluster = compute_cluster
        if compute_cluster:
            self._session.headers.update({'X-Featrix-Node': compute_cluster})

        # Retry config
        self._default_max_retries = default_max_retries
        self._retry_base_delay = retry_base_delay
        self._retry_max_delay = retry_max_delay

        # Client context for resource classes
        self._ctx = ClientContext(self)

        # Current project (set via constructor or set_current_project())
        self._current_project_id: Optional[str] = None
        self._current_project: Optional[Dict[str, Any]] = None
        if project:
            self.set_current_project(project)

    def set_compute_cluster(self, cluster: Optional[str]) -> None:
        """
        Set the compute cluster for all subsequent requests.

        Args:
            cluster: Cluster name or None for default
        """
        self._compute_cluster = cluster
        if cluster:
            self._session.headers.update({'X-Featrix-Node': cluster})
        else:
            self._session.headers.pop('X-Featrix-Node', None)

    def set_current_project(self, project: str) -> Dict[str, Any]:
        """
        Set the current project for all subsequent operations.

        Verifies the project exists and belongs to your organization by
        calling the API immediately. If the project is not found, raises
        an error.

        Args:
            project: Project name, project_id, or UUID

        Returns:
            Project info dict from the API

        Raises:
            requests.HTTPError: If project not found (404) or auth fails (401)

        Example:
            featrix = FeatrixSphere(api_key="fx_...")
            featrix.set_current_project("my-project")

            # All subsequent creates are scoped to this project
            fm = featrix.create_foundational_model(...)
        """
        response = self._get_json(f"/projects/{project}")
        self._current_project_id = response.get('id')
        self._current_project = response
        self._session.headers.update({'X-Featrix-Project': self._current_project_id})
        logger.info(f"Current project set to: {response.get('name')} ({self._current_project_id})")
        return response

    def clear_current_project(self) -> None:
        """
        Clear the current project.

        Subsequent creation operations will not be associated with any project.
        """
        self._current_project_id = None
        self._current_project = None
        self._session.headers.pop('X-Featrix-Project', None)

    @property
    def current_project(self) -> Optional[Dict[str, Any]]:
        """The currently set project, or None."""
        return self._current_project

    def create_foundational_model(
        self,
        name: Optional[str] = None,
        data_file: Optional[str] = None,
        df: Optional['pd.DataFrame'] = None,
        ignore_columns: Optional[List[str]] = None,
        column_overrides: Optional[Dict[str, str]] = None,
        epochs: Optional[int] = None,
        webhooks: Optional[Dict[str, str]] = None,
        user_metadata: Optional[Dict[str, Any]] = None,
        foundation_mode: Optional[bool] = None,
        session_name_prefix: Optional[str] = None,
        **kwargs
    ) -> FoundationalModel:
        """
        Create a foundational model (embedding space).

        Args:
            name: Model name - also used as session directory prefix unless
                session_name_prefix is explicitly provided. Session directory
                will be named {name}-{uuid} instead of {uuid}-{timestamp}.
            data_file: Data source — one of:
                - S3 URL (s3://bucket/path/to/file.csv)
                - Local CSV file path (/path/to/data.csv)
                - Local Parquet file path (/path/to/data.parquet)
                - Local JSON file path (/path/to/data.json)
            df: DataFrame with training data (alternative to data_file)
            ignore_columns: Columns to ignore during training
            column_overrides: Override auto-detected column types. Dict mapping
                column name to type string. Example:
                {"activities": "sparse_multihot", "codes": "sparse_multihot<fips>"}
            epochs: Number of training epochs (None = auto)
            webhooks: Webhook URLs for events
            user_metadata: Custom metadata (max 32KB)
            foundation_mode: Force foundation training mode for large datasets.
                If True, uses foundation training (chunked iteration, SQLite-backed
                splits). If False, uses standard training. If None (default),
                auto-detects based on dataset size (>=100k rows).
            session_name_prefix: Optional explicit prefix for session directory name.
                If provided, overrides the name parameter for directory naming.
                Session directory will be named {prefix}-{uuid}.
            **kwargs: Additional parameters

        Returns:
            FoundationalModel object (training started)

        Example:
            # Name controls both metadata AND directory name
            fm = featrix.create_foundational_model(
                name="xx13-xxlarge",  # Directory: xx13-xxlarge-{uuid}
                data_file="customers.csv",
                ignore_columns=["id", "timestamp"]
            )

            # Override directory name separately
            fm = featrix.create_foundational_model(
                name="Customer Model v2",           # Metadata name
                data_file="s3://my-bucket/customers.parquet",
                session_name_prefix="customer-prod"  # Directory: customer-prod-{uuid}
            )

            fm.wait_for_training()
        """
        if df is None and not data_file:
            raise ValueError("Either data_file or df must be provided")

        # If session_name_prefix not provided, use name for directory naming
        if session_name_prefix is None and name:
            session_name_prefix = name

        # S3 URL path — use the create-embedding-space endpoint (JSON, no file upload)
        if data_file and data_file.startswith('s3://'):
            return self._create_foundational_model_s3(
                name=name,
                s3_url=data_file,
                ignore_columns=ignore_columns,
                column_overrides=column_overrides,
                epochs=epochs,
                webhooks=webhooks,
                user_metadata=user_metadata,
                foundation_mode=foundation_mode,
                session_name_prefix=session_name_prefix,
                **kwargs
            )

        # Local file / DataFrame path — upload via multipart
        if df is not None:
            file_content, filename = self._dataframe_to_file(df)
        else:
            file_content, filename = self._read_file(data_file)

        # Build form data
        form_data = {}
        if name:
            form_data['name'] = name
        if session_name_prefix:
            form_data['session_name_prefix'] = session_name_prefix
        if ignore_columns:
            form_data['ignore_columns'] = json.dumps(ignore_columns)
        if column_overrides:
            form_data['column_overrides'] = json.dumps(column_overrides)
        if epochs is not None:
            form_data['epochs'] = str(epochs)
        if webhooks:
            form_data['webhooks'] = json.dumps(webhooks)
        if user_metadata:
            form_data['user_metadata'] = json.dumps(user_metadata)
        if foundation_mode is not None:
            form_data['foundation_mode'] = str(foundation_mode).lower()
        if self._current_project_id:
            form_data['project_id'] = self._current_project_id

        # Add any extra kwargs
        for key, value in kwargs.items():
            if value is not None:
                if isinstance(value, (dict, list)):
                    form_data[key] = json.dumps(value)
                else:
                    form_data[key] = str(value)

        # Upload file and create session
        files = {'file': (filename, file_content)}

        response = self._post_multipart(
            "/compute/upload_with_new_session/",
            data=form_data,
            files=files
        )

        session_id = response.get('session_id', '')

        # Handle warnings
        warnings = response.get('warnings', [])
        if warnings:
            for warning in warnings:
                logger.warning(f"Upload warning: {warning}")

        return FoundationalModel(
            id=session_id,
            name=name,
            status="training",
            created_at=None,
            _ctx=self._ctx,
        )

    def _create_foundational_model_s3(
        self,
        name: Optional[str],
        s3_url: str,
        ignore_columns: Optional[List[str]] = None,
        column_overrides: Optional[Dict[str, str]] = None,
        epochs: Optional[int] = None,
        webhooks: Optional[Dict[str, str]] = None,
        user_metadata: Optional[Dict[str, Any]] = None,
        foundation_mode: Optional[bool] = None,
        session_name_prefix: Optional[str] = None,
        **kwargs
    ) -> FoundationalModel:
        """Create foundational model from S3 URL via the create-embedding-space endpoint."""

        data = {
            "name": name or "",
            "s3_file_data_set_training": s3_url,
        }
        if session_name_prefix:
            data['session_name_prefix'] = session_name_prefix
        if ignore_columns:
            data['ignore_columns'] = ignore_columns
        if column_overrides:
            data['column_overrides'] = column_overrides
        if epochs is not None:
            data['epochs'] = epochs
        if webhooks:
            data['webhooks'] = webhooks
        if user_metadata:
            data['user_metadata'] = json.dumps(user_metadata)
        if foundation_mode is not None:
            data['foundation_mode'] = foundation_mode
        if self._current_project_id:
            data['project_id'] = self._current_project_id

        for key, value in kwargs.items():
            if value is not None:
                data[key] = value

        response = self._post_json(
            "/compute/create-embedding-space",
            data=data
        )

        session_id = response.get('session_id', '')

        return FoundationalModel(
            id=session_id,
            name=name,
            status="training",
            created_at=None,
            _ctx=self._ctx,
        )

    def foundational_model(self, fm_id: str) -> FoundationalModel:
        """
        Get an existing foundational model by ID.

        Args:
            fm_id: Foundational model (session) ID

        Returns:
            FoundationalModel object

        Example:
            fm = featrix.foundational_model("abc123")
            print(fm.status)
        """
        return FoundationalModel.from_session_id(fm_id, self._ctx)

    def predictor(self, session_id: str, predictor_id: Optional[str] = None) -> Predictor:
        """
        Get the predictor for a session.

        Each session has exactly one predictor. Just pass the session_id.

        Args:
            session_id: Session ID (each session has one predictor)
            predictor_id: Optional predictor ID filter (legacy, usually not needed)

        Returns:
            Predictor object
        """
        # Get session info
        response = self._get_json(f"/compute/session/{session_id}")
        session = response.get('session', {})

        # Find the train_single_predictor entry in job_plan
        target_column = None
        target_type = "set"
        for job_entry in session.get('job_plan', []):
            if job_entry.get('job_type') == 'train_single_predictor':
                spec = job_entry.get('spec', {})
                target_column = spec.get('target_column', job_entry.get('target_column', ''))
                target_type = spec.get('target_column_type', job_entry.get('target_column_type', 'set'))
                break

        if target_column is None:
            raise ValueError(f"No predictor found in session {session_id}")

        return Predictor(
            id=predictor_id or session_id,
            session_id=session_id,
            target_column=target_column,
            target_type=target_type,
            name=session.get('name'),
            status=session.get('status'),
            _ctx=self._ctx,
        )

    def vector_database(self, vdb_id: str) -> VectorDatabase:
        """
        Get an existing vector database by ID.

        Args:
            vdb_id: Vector database (session) ID

        Returns:
            VectorDatabase object
        """
        return VectorDatabase.from_session(vdb_id, ctx=self._ctx)

    def api_endpoint(self, endpoint_id: str, session_id: str) -> APIEndpoint:
        """
        Get an existing API endpoint by ID.

        Args:
            endpoint_id: API endpoint ID
            session_id: Session ID

        Returns:
            APIEndpoint object
        """
        response = self._get_json(f"/session/{session_id}/endpoint/{endpoint_id}")

        return APIEndpoint.from_response(
            response=response,
            predictor_id=response.get('predictor_id', ''),
            session_id=session_id,
            ctx=self._ctx,
        )

    def published_predictor(
        self,
        org: str,
        name: str,
        api_key: str,
        base_url: str = "https://production-ai.featrix.com"
    ) -> PublishedPredictor:
        """
        Load a published predictor for making predictions.

        Published predictors are deployed to production-ai.featrix.com
        and serve predictions via a REST API with API key authentication.

        Args:
            org: Organization ID
            name: Model name
            api_key: API key for authentication
            base_url: Production server URL (default: https://production-ai.featrix.com)

        Returns:
            PublishedPredictor instance

        Example:
            # Load a published predictor
            predictor = client.published_predictor(
                org="alph",
                name="my-model",
                api_key="sk_alph_xxx"
            )

            # Make single prediction
            result = predictor.predict({"age": 35, "income": 50000})
            print(result.predicted_class)
            print(result.confidence)

            # Batch predictions
            results = predictor.batch_predict([
                {"age": 35, "income": 50000},
                {"age": 42, "income": 75000}
            ])
        """
        return PublishedPredictor(
            org=org,
            name=name,
            api_key=api_key,
            base_url=base_url,
            _ctx=self._ctx,
        )

    def get_notebook(self) -> FeatrixNotebookHelper:
        """
        Get the Jupyter notebook visualization helper.

        Returns a helper object with methods for visualizing training,
        embedding spaces, and model analysis in Jupyter notebooks.

        Returns:
            FeatrixNotebookHelper instance

        Example:
            notebook = featrix.get_notebook()
            fig = notebook.training_loss(fm)
            fig.show()
        """
        return FeatrixNotebookHelper(ctx=self._ctx)

    def prediction_feedback(
        self,
        prediction_uuid: str,
        ground_truth: Union[str, float]
    ) -> Dict[str, Any]:
        """
        Send feedback for a prediction.

        Convenience method that creates and sends feedback in one call.

        Args:
            prediction_uuid: UUID from PredictionResult.prediction_uuid
            ground_truth: The correct label/value

        Returns:
            Server response
        """
        return PredictionFeedback.create_and_send(
            ctx=self._ctx,
            prediction_uuid=prediction_uuid,
            ground_truth=ground_truth
        )

    def predict_grid(
        self,
        fm_id: str,
        degrees_of_freedom: int,
        grid_shape: tuple = None,
        target_column: str = None,
        predictor_id: str = None,
    ) -> 'PredictionGrid':
        """
        Create a prediction grid for exploring parameter surfaces with visualization.

        Resolves the predictor from the foundational model, then creates a grid.

        Args:
            fm_id: Foundational model (session) ID
            degrees_of_freedom: Number of dimensions (1, 2, or 3)
            grid_shape: Custom grid shape tuple (default: auto-sized)
            target_column: Target column to find predictor for (if multiple predictors)
            predictor_id: Specific predictor ID to use

        Returns:
            PredictionGrid object with predict() and plotting methods

        Example:
            grid = featrix.predict_grid(fm_id, degrees_of_freedom=2, grid_shape=(19, 8))
            grid.set_axis_labels(["Spend ($)", "Ad Set Campaign"])

            for i, spend in enumerate(spend_levels):
                for j, ad_set in enumerate(ad_sets):
                    grid.predict({"spend": spend, "ad_set_name": ad_set}, grid_position=(i, j))

            grid.process_batch()
            grid.plot_heatmap()
        """
        from .prediction_grid import PredictionGrid

        # Resolve predictor
        if predictor_id:
            pred = self.predictor(fm_id, predictor_id=predictor_id)
        else:
            fm = self.foundational_model(fm_id)
            predictors = fm.list_predictors()
            if not predictors:
                raise ValueError(f"No predictors found for foundational model {fm_id}")
            if target_column:
                matches = [p for p in predictors if p.target_column == target_column]
                if not matches:
                    available = [p.target_column for p in predictors]
                    raise ValueError(
                        f"No predictor found for target_column='{target_column}'. "
                        f"Available: {available}"
                    )
                pred = matches[0]
            elif len(predictors) == 1:
                pred = predictors[0]
            else:
                available = [f"{p.id} (target={p.target_column})" for p in predictors]
                raise ValueError(
                    f"Multiple predictors found. Specify target_column or predictor_id. "
                    f"Available: {available}"
                )

        return PredictionGrid(predictor=pred, degrees_of_freedom=degrees_of_freedom, grid_shape=grid_shape)

    def list_sessions(
        self,
        name_prefix: str = "",
    ) -> List[str]:
        """
        List sessions matching a name prefix/search term.

        Searches session directory names on the compute cluster for
        partial matches (not just prefix).

        Args:
            name_prefix: Term to match in session names

        Returns:
            List of matching session ID strings

        Example:
            sessions = featrix.list_sessions(name_prefix="customer")
            for sid in sessions:
                fm = featrix.foundational_model(sid)
                print(f"{sid}: {fm.status}")
        """
        params = {}
        if name_prefix:
            params['name_prefix'] = name_prefix
        response = self._get_json("/compute/sessions-for-org", params=params)
        return response.get('sessions', [])

    def health_check(self) -> Dict[str, Any]:
        """
        Check if the API server is healthy.

        Returns:
            Health status dictionary
        """
        return self._get_json("/health")

    def whoami(self) -> Dict[str, Any]:
        """
        Return identity info for the authenticated API key.

        Returns:
            Dictionary with user_id, org_id, org_name, org_slug,
            api_key_id, scopes, and authenticated_at.
        """
        return self._get_json("/auth/whoami")

    def _dataframe_to_file(self, df: 'pd.DataFrame') -> tuple:
        """Convert DataFrame to file content and filename."""
        # Try parquet first (more efficient)
        try:
            import pyarrow
            buffer = io.BytesIO()
            df.to_parquet(buffer, index=False)
            return buffer.getvalue(), "data.parquet"
        except ImportError:
            pass

        # Fall back to CSV
        csv_buffer = io.StringIO()
        df.to_csv(csv_buffer, index=False)
        content = csv_buffer.getvalue().encode('utf-8')

        # Compress if large
        if len(content) > 100_000:
            compressed = gzip.compress(content)
            if len(compressed) < len(content):
                return compressed, "data.csv.gz"

        return content, "data.csv"

    def _read_file(self, file_path: str) -> tuple:
        """Read file content and return with filename."""
        path = Path(file_path)
        filename = path.name

        with open(path, 'rb') as f:
            content = f.read()

        # Compress if large and not already compressed
        if len(content) > 100_000 and not filename.endswith('.gz'):
            compressed = gzip.compress(content)
            if len(compressed) < len(content):
                return compressed, filename + '.gz'

        return content, filename

    def __repr__(self) -> str:
        cluster_str = f", cluster='{self._compute_cluster}'" if self._compute_cluster else ""
        return f"FeatrixSphere(url='{self._base_url}'{cluster_str})"
