"""
PublishedPredictor class for FeatrixSphere API.

Represents a predictor deployed to production-ai.featrix.com for serving predictions.
"""

import logging
from dataclasses import dataclass, field
from typing import Dict, Any, Optional, List, Union, TYPE_CHECKING

if TYPE_CHECKING:
    from .http_client import ClientContext
    import pandas as pd

from .prediction_result import PredictionResult

logger = logging.getLogger(__name__)


@dataclass
class PublishedPredictor:
    """
    Represents a predictor deployed to production for serving predictions.

    Attributes:
        org: Organization ID
        name: Model name
        api_key: API key for authentication
        base_url: Production server URL (default: https://production-ai.featrix.com)

    Usage:
        # Load a published predictor
        predictor = client.published_predictor(
            org="alph",
            name="my-model",
            api_key="sk_alph_xxx"
        )

        # Make prediction
        result = predictor.predict({"age": 35, "income": 50000})
        print(result.predicted_class)
        print(result.confidence)

        # Batch predictions
        results = predictor.batch_predict([
            {"age": 35, "income": 50000},
            {"age": 42, "income": 75000}
        ])
    """

    org: str
    name: str
    api_key: str
    base_url: str = "https://production-ai.featrix.com"

    # Internal
    _ctx: Optional['ClientContext'] = field(default=None, repr=False)

    @property
    def endpoint_url(self) -> str:
        """Get the full prediction endpoint URL."""
        return f"{self.base_url}/predict/{self.org}/{self.name}"

    def predict(
        self,
        record: Dict[str, Any],
    ) -> PredictionResult:
        """
        Make a single prediction.

        Args:
            record: Input record dictionary

        Returns:
            PredictionResult with prediction, confidence, and probabilities.

        Example:
            result = predictor.predict({"age": 35, "income": 50000})
            print(result.predicted_class)  # "churned"
            print(result.confidence)       # 0.87
        """
        # Clean the record
        cleaned_record = self._clean_record(record)

        # Make batch request with single record
        results = self.batch_predict([cleaned_record])

        return results[0] if results else None

    def batch_predict(
        self,
        records: Union[List[Dict[str, Any]], 'pd.DataFrame'],
        batch_size: int = 256,
    ) -> List[PredictionResult]:
        """
        Make batch predictions.

        Args:
            records: List of record dictionaries or DataFrame
            batch_size: Number of records to process per batch

        Returns:
            List of PredictionResult objects

        Example:
            results = predictor.batch_predict([
                {"age": 35, "income": 50000},
                {"age": 42, "income": 75000}
            ])
            for result in results:
                print(result.predicted_class, result.confidence)
        """
        # Convert DataFrame to list of dicts if needed
        if hasattr(records, 'to_dict'):
            records = records.to_dict('records')

        # Clean records
        cleaned_records = [self._clean_record(r) for r in records]

        # Build request
        request_payload = {
            "records": cleaned_records,
            "batch_size": batch_size,
        }

        # Make request to production API with authentication
        import requests

        headers = {
            "X-API-Key": self.api_key,
            "Content-Type": "application/json",
        }

        response = requests.post(
            self.endpoint_url,
            json=request_payload,
            headers=headers,
            timeout=300,  # 5 minute timeout for large batches
        )

        # Check for errors
        if response.status_code != 200:
            error_msg = f"Prediction failed with status {response.status_code}"
            try:
                error_data = response.json()
                error_msg = error_data.get('error', error_msg)
            except:
                error_msg = response.text or error_msg
            raise RuntimeError(error_msg)

        # Parse response
        response_data = response.json()

        if not response_data.get('success'):
            error = response_data.get('error', 'Unknown error')
            raise RuntimeError(f"Prediction failed: {error}")

        # Parse results
        results = []
        predictions = response_data.get('predictions', [])

        for i, pred in enumerate(predictions):
            record = cleaned_records[i] if i < len(cleaned_records) else {}

            # Production API nests prediction data under 'results' key
            pred_results = pred.get('results', pred)

            # Create PredictionResult from production API response
            result = PredictionResult(
                predicted_class=pred_results.get('prediction', pred_results.get('predicted_class')),
                confidence=pred_results.get('confidence'),
                probabilities=pred_results.get('probabilities', {}),
                threshold=pred_results.get('threshold'),
                query_record=record,
                guardrails=pred.get('guardrails'),
                ignored_query_columns=pred.get('ignored_query_columns'),
                available_query_columns=pred.get('available_query_columns'),
                prediction_uuid=None,
                _ctx=None,
            )
            results.append(result)

        return results

    def predict_csv_file(
        self,
        csv_path: str,
        batch_size: int = 256,
    ) -> List[PredictionResult]:
        """
        Load a CSV file and run batch predictions on all rows.

        Args:
            csv_path: Path to the CSV file
            batch_size: Number of records to process per batch

        Returns:
            List of PredictionResult objects

        Example:
            results = predictor.predict_csv_file("test_data.csv")
            for r in results:
                print(r.predicted_class, r.confidence)
        """
        import pandas as pd
        df = pd.read_csv(csv_path)
        return self.batch_predict(df, batch_size=batch_size)

    def _clean_record(self, record: Dict[str, Any]) -> Dict[str, Any]:
        """Clean a record for API submission."""
        import math

        cleaned = {}
        for key, value in record.items():
            # Handle NaN/Inf
            if isinstance(value, float):
                if math.isnan(value) or math.isinf(value):
                    value = None
            # Handle numpy types
            if hasattr(value, 'item'):
                value = value.item()
            cleaned[key] = value
        return cleaned

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary representation."""
        return {
            'org': self.org,
            'name': self.name,
            'base_url': self.base_url,
            'endpoint_url': self.endpoint_url,
        }

    def __repr__(self) -> str:
        return f"PublishedPredictor(org='{self.org}', name='{self.name}')"
