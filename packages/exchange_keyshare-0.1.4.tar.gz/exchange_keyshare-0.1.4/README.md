# exchange-keyshare

CLI tool for market makers to securely share exchange API credentials.

## Before You Start

The credential consumer will provide you with two values:
- **Principal ARN**
- **External ID**

Keep these ready for the setup process.

## Prerequisites

- Python 3.12+
- AWS CLI configured with credentials that can create CloudFormation stacks

## Installation

```bash
pip install exchange-keyshare
```

## Quick Start

### 1. Set up infrastructure

```bash
exchange-keyshare setup
```

This creates:
- An S3 bucket for storing credentials (KMS-encrypted, versioned)
- A KMS key for encryption (you control it)
- An IAM role for the credential consumer to assume (read-only access)

After setup, share the displayed Role ARN and Bucket with the credential consumer.

### 2. Add credentials

```bash
exchange-keyshare keys create
```

Follow the interactive prompts to select an exchange and enter your API credentials.

### 3. Manage credentials

```bash
# List all credentials
exchange-keyshare keys list

# Update pairs or labels
exchange-keyshare keys update <key>

# Delete a credential
exchange-keyshare keys delete <key>
```

## Configuration

Config is stored at `~/.config/exchange-keyshare/config.yaml` after running setup.
