"""Configuration file handling for exchange-keyshare."""

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml


def _default_config_path() -> Path:
    """Get default config path, respecting EXCHANGE_KEYSHARE_CONFIG env var."""
    env_path = os.environ.get("EXCHANGE_KEYSHARE_CONFIG")
    if env_path:
        return Path(env_path)

    home = Path.home()
    return home / ".config" / "exchange-keyshare" / "config.yaml"


@dataclass
class Config:
    """Configuration container."""

    config_path: Path = field(default_factory=_default_config_path)
    bucket: str | None = None
    region: str | None = None
    stack_name: str | None = None
    stack_id: str | None = None
    role_arn: str | None = None
    external_id: str | None = None
    kms_key_arn: str | None = None

    def load(self) -> None:
        """Load config from file."""
        data = load_config(self.config_path)
        self.bucket = data.get("bucket")
        self.region = data.get("region")
        self.stack_name = data.get("stack_name")
        self.stack_id = data.get("stack_id")
        self.role_arn = data.get("role_arn")
        self.external_id = data.get("external_id")
        self.kms_key_arn = data.get("kms_key_arn")

    def save(self) -> None:
        """Save config to file."""
        data: dict[str, Any] = {}
        if self.bucket:
            data["bucket"] = self.bucket
        if self.region:
            data["region"] = self.region
        if self.stack_name:
            data["stack_name"] = self.stack_name
        if self.stack_id:
            data["stack_id"] = self.stack_id
        if self.role_arn:
            data["role_arn"] = self.role_arn
        if self.external_id:
            data["external_id"] = self.external_id
        if self.kms_key_arn:
            data["kms_key_arn"] = self.kms_key_arn
        save_config(self.config_path, data)


def load_config(path: Path) -> dict[str, Any]:
    """Load config from YAML file. Returns empty dict if file doesn't exist."""
    if not path.exists():
        return {}

    with open(path) as f:
        data = yaml.safe_load(f)
        return data if data else {}


def save_config(path: Path, data: dict[str, Any]) -> None:
    """Save config to YAML file. Creates parent directories if needed.

    Config file is created with 0600 permissions (owner read/write only)
    since it may contain sensitive data like external_id.
    """
    path.parent.mkdir(parents=True, exist_ok=True)

    # Create with restrictive permissions (owner read/write only)
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    try:
        with os.fdopen(fd, "w") as f:
            yaml.dump(data, f, default_flow_style=False)
    except Exception:
        os.close(fd)
        raise
