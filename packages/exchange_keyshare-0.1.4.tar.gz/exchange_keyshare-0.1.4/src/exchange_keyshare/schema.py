"""Credential schema validation."""

from dataclasses import dataclass
from typing import Any, cast


SUPPORTED_EXCHANGES = frozenset({
    "binance",
    "bybit",
    "coinbase",
    "gate",
    "kraken",
    "kucoin",
    "bitget",
    "okx",
})

PASSPHRASE_REQUIRED_EXCHANGES = frozenset({
    "coinbase",
    "kucoin",
    "bitget",
    "okx",
})


class SchemaError(Exception):
    """Raised when credential schema validation fails."""
    pass


@dataclass
class CredentialSchema:
    """Validated credential data."""

    version: str
    exchange: str
    credential: dict[str, str]
    pairs: list[str] | None = None
    labels: list[dict[str, str]] | None = None

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for YAML serialization."""
        data: dict[str, Any] = {
            "version": self.version,
            "exchange": self.exchange,
            "credential": self.credential,
        }
        if self.pairs is not None:
            data["pairs"] = self.pairs
        if self.labels is not None:
            data["labels"] = self.labels
        return data


def validate_credential(data: dict[str, Any]) -> CredentialSchema:
    """Validate credential data and return structured result.

    Raises:
        SchemaError: If validation fails.
    """
    # Check required top-level fields
    if "version" not in data:
        raise SchemaError("missing required field: version")
    if "exchange" not in data:
        raise SchemaError("missing required field: exchange")
    if "credential" not in data:
        raise SchemaError("missing required field: credential")

    exchange = data["exchange"]
    if exchange not in SUPPORTED_EXCHANGES:
        raise SchemaError(f"unsupported exchange: {exchange}")

    credential_raw = data["credential"]
    if not isinstance(credential_raw, dict):
        raise SchemaError("credential must be a mapping")
    credential = cast(dict[str, str], credential_raw)
    if "api_key" not in credential:
        raise SchemaError("missing required field: credential.api_key")
    api_key = credential["api_key"]
    if not api_key or not api_key.strip():
        raise SchemaError("credential.api_key cannot be empty")
    if "api_secret" not in credential:
        raise SchemaError("missing required field: credential.api_secret")
    api_secret = credential["api_secret"]
    if not api_secret or not api_secret.strip():
        raise SchemaError("credential.api_secret cannot be empty")

    # Check passphrase requirement for certain exchanges
    if exchange in PASSPHRASE_REQUIRED_EXCHANGES:
        if "passphrase" not in credential or not credential["passphrase"]:
            raise SchemaError(f"passphrase required for {exchange}")

    # Validate optional pairs field
    pairs: list[str] | None = None
    pairs_raw = data.get("pairs")
    if pairs_raw is not None:
        if not isinstance(pairs_raw, list):
            raise SchemaError("pairs must be a list")
        for pair in cast(list[Any], pairs_raw):
            if not isinstance(pair, str):
                raise SchemaError("each pair must be a string")
        pairs = cast(list[str], pairs_raw)

    # Validate optional labels field
    labels: list[dict[str, str]] | None = None
    labels_raw = data.get("labels")
    if labels_raw is not None:
        if not isinstance(labels_raw, list):
            raise SchemaError("labels must be a list")
        for label in cast(list[Any], labels_raw):
            if not isinstance(label, dict) or "key" not in label or "value" not in label:
                raise SchemaError("label must have 'key' and 'value'")
        labels = cast(list[dict[str, str]], labels_raw)

    return CredentialSchema(
        version=str(data["version"]),
        exchange=str(exchange),
        credential=credential,
        pairs=pairs,
        labels=labels,
    )
