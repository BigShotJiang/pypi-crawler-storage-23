"""CloudFormation operations for exchange-keyshare."""

from pathlib import Path


def get_template_path() -> Path:
    """Get path to CloudFormation template."""
    return Path(__file__).parent / "templates" / "stack.yaml"


def load_template() -> str:
    """Load CloudFormation template as string."""
    path = get_template_path()
    return path.read_text()
