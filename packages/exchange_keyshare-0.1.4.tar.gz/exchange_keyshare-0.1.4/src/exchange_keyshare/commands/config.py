"""Config command for displaying current configuration."""

import click
from rich.console import Console
from rich.table import Table

from exchange_keyshare.config import Config


@click.command()
@click.pass_context
def config(ctx: click.Context) -> None:
    """Display current configuration."""
    cfg: Config = ctx.obj["config"]
    console = Console()

    if not cfg.stack_name:
        console.print("Not configured. Run [cyan]exchange-keyshare setup[/cyan] first.")
        return

    table = Table(show_header=False, box=None)
    table.add_column("Key", style="dim")
    table.add_column("Value", style="cyan")

    table.add_row("Bucket", cfg.bucket or "")
    table.add_row("Region", cfg.region or "")
    table.add_row("Stack Name", cfg.stack_name or "")
    table.add_row("Stack ID", cfg.stack_id or "")
    table.add_row("Role ARN", cfg.role_arn or "")
    table.add_row("External ID", cfg.external_id or "")
    table.add_row("KMS Key ARN", cfg.kms_key_arn or "")
    table.add_row("Config Path", str(cfg.config_path))

    console.print(table)
