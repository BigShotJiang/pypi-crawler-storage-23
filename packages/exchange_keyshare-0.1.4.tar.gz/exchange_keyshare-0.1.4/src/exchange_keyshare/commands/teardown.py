"""Teardown command for deleting AWS infrastructure."""

import click
from rich.console import Console, Group, RenderableType
from rich.live import Live
from rich.panel import Panel
from rich.spinner import Spinner
from rich.table import Table
from rich.text import Text

from exchange_keyshare.config import Config
from exchange_keyshare.keys import CredentialInfo, list_credentials
from exchange_keyshare.setup import (
    ResourceStatus,
    StackProgress,
    get_friendly_type,
    get_stack_console_url,
    poll_stack_deletion,
    start_stack_deletion,
)


def get_delete_status_style(status: str) -> str:
    """Get rich style for a deletion status."""
    if "DELETE_COMPLETE" in status or "DELETE_SKIPPED" in status:
        return "green"
    elif "IN_PROGRESS" in status:
        return "yellow"
    elif "FAILED" in status:
        return "red"
    return "white"


def get_delete_status_icon(status: str) -> str:
    """Get icon for a deletion status."""
    if "DELETE_COMPLETE" in status or "DELETE_SKIPPED" in status:
        return "[green]✓[/green]"
    elif "IN_PROGRESS" in status:
        return "[yellow]⋯[/yellow]"
    elif "FAILED" in status:
        return "[red]✗[/red]"
    return " "


def build_deletion_progress_display(progress: StackProgress) -> RenderableType:
    """Build a rich display showing resource deletion progress with spinner."""
    table = Table(show_header=True, header_style="bold", box=None)
    table.add_column("", width=2)
    table.add_column("Resource", style="cyan", min_width=25)
    table.add_column("Type", style="dim")
    table.add_column("Status")

    # Sort resources: in_progress first, then by name
    def sort_key(item: tuple[str, ResourceStatus]) -> tuple[int, str]:
        _, r = item
        if "IN_PROGRESS" in r.status:
            return (0, r.logical_id)
        elif "COMPLETE" in r.status or "SKIPPED" in r.status:
            return (2, r.logical_id)
        else:
            return (1, r.logical_id)

    sorted_resources = sorted(progress.resources.items(), key=sort_key)

    for _logical_id, resource in sorted_resources:
        icon = get_delete_status_icon(resource.status)
        style = get_delete_status_style(resource.status)
        friendly_type = get_friendly_type(resource.resource_type)

        # Simplify status text
        status_text = resource.status.replace("_", " ").title()

        table.add_row(
            icon,
            resource.logical_id,
            friendly_type,
            f"[{style}]{status_text}[/{style}]",
        )

    # Add spinner header if still in progress
    if not progress.is_complete and not progress.is_failed:
        spinner = Spinner("dots", text=Text(" Deleting infrastructure...", style="bold"))
        return Group(spinner, Text(""), table)

    return table


@click.command()
@click.pass_context
def teardown(ctx: click.Context) -> None:
    """Delete AWS infrastructure and revoke access.

    This permanently deletes all infrastructure created by setup.
    The S3 bucket and KMS key are retained but access is revoked.
    """
    cfg: Config = ctx.obj["config"]
    console = Console()

    if not cfg.stack_name:
        console.print("Nothing to teardown. Run [cyan]exchange-keyshare setup[/cyan] first.")
        return

    region = cfg.region or "us-east-1"

    # Try to list existing credentials (gracefully handle failure)
    credentials: list[CredentialInfo] = []
    if cfg.bucket and cfg.region:
        try:
            credentials = list_credentials(cfg.bucket, cfg.region)
        except Exception:
            pass  # Gracefully ignore - permissions may already be revoked

    # Build credential list for warning
    cred_text = ""
    if credentials:
        cred_text = "\n[bold]Credentials that will become inaccessible:[/bold]\n"
        for cred in credentials:
            cred_text += f"  - [cyan]{cred.exchange}[/cyan]\n"
            if cred.pairs:
                cred_text += f"    Pairs: {', '.join(cred.pairs)}\n"
            if cred.labels:
                labels_str = ", ".join(f"{lbl['key']}={lbl['value']}" for lbl in cred.labels)
                cred_text += f"    Labels: {labels_str}\n"
        cred_text += "\n"

    # Build console URL if we have a stack ID
    console_url = ""
    if cfg.stack_id:
        console_url = get_stack_console_url(cfg.stack_id, region)

    # Show scary warning with specific resources
    manual_cmd = f"aws cloudformation delete-stack --stack-name {cfg.stack_name} --region {region}"

    warning = Panel(
        "[bold red]WARNING: This action cannot be undone![/bold red]\n\n"
        "[bold]Resources that will be DELETED:[/bold]\n"
        f"  - IAM Role: [cyan]{cfg.role_arn}[/cyan]\n"
        f"  - KMS Key Alias: [cyan]alias/{cfg.bucket}[/cyan]\n"
        "  - S3 Bucket Policies\n\n"
        "[bold]Resources that will be RETAINED (but inaccessible):[/bold]\n"
        f"  - S3 Bucket: [cyan]{cfg.bucket}[/cyan]\n"
        f"  - KMS Key: [cyan]{cfg.kms_key_arn}[/cyan]\n"
        f"{cred_text}\n"
        f"Stack: [cyan]{cfg.stack_name}[/cyan]\n"
        f"Region: [cyan]{region}[/cyan]\n\n"
        f"[dim]Manual command: {manual_cmd}[/dim]",
        title="[bold red]Teardown Infrastructure[/bold red]",
        border_style="red",
    )
    console.print(warning)
    console.print()

    # Require typing the stack name to confirm
    console.print(f"To confirm, type the stack name: [bold]{cfg.stack_name}[/bold]")
    confirmation = click.prompt("", default="", show_default=False)

    if confirmation != cfg.stack_name:
        console.print("[yellow]Aborted.[/yellow] Stack name did not match.")
        raise SystemExit(1)

    console.print()

    # Show console URL before starting deletion
    if console_url:
        console.print(f"[dim]Monitor progress in AWS Console:[/dim]")
        console.print(f"[link={console_url}]{console_url}[/link]")
        console.print()
        console.print("[dim]You can safely cancel this command (Ctrl+C) - deletion will continue in AWS.[/dim]")
        console.print()

    # Start deletion and poll with live display
    try:
        cfn = start_stack_deletion(cfg.stack_name, region)
    except Exception as e:
        console.print(f"[red]Error starting deletion: {e}[/red]")
        raise SystemExit(1)

    final_progress: StackProgress | None = None

    try:
        with Live(console=console, refresh_per_second=10) as live:
            for progress in poll_stack_deletion(cfg.stack_name, cfn):
                display = build_deletion_progress_display(progress)
                live.update(display)
                final_progress = progress

                if progress.is_complete or progress.is_failed:
                    break
    except KeyboardInterrupt:
        console.print()
        console.print("[yellow]Interrupted.[/yellow] Deletion continues in AWS.")
        if console_url:
            console.print(f"[dim]Monitor progress:[/dim] {console_url}")
        raise SystemExit(0)

    if final_progress is None or final_progress.is_failed:
        console.print()
        console.print(f"[red]Error: {final_progress.failure_reason if final_progress else 'Unknown error'}[/red]")
        if console_url:
            console.print(f"[dim]Check AWS Console:[/dim] {console_url}")
        raise SystemExit(1)

    # Delete config file
    if cfg.config_path.exists():
        cfg.config_path.unlink()

    console.print()
    console.print("[green]Teardown complete.[/green] All access has been revoked.")
