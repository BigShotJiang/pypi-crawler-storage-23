"""Setup command for creating AWS infrastructure."""

import click
from rich.console import Console, Group, RenderableType
from rich.live import Live
from rich.spinner import Spinner
from rich.table import Table
from rich.text import Text

from exchange_keyshare.config import Config
from exchange_keyshare.setup import (
    ResourceStatus,
    StackProgress,
    get_default_region,
    get_friendly_type,
    get_stack_outputs,
    poll_stack_progress,
    start_stack_creation,
)


def get_status_style(status: str) -> str:
    """Get rich style for a resource status."""
    if "COMPLETE" in status and "ROLLBACK" not in status:
        return "green"
    elif "IN_PROGRESS" in status:
        return "yellow"
    elif "FAILED" in status or "ROLLBACK" in status:
        return "red"
    return "white"


def get_status_icon(status: str) -> str:
    """Get icon for a resource status."""
    if "COMPLETE" in status and "ROLLBACK" not in status:
        return "[green]✓[/green]"
    elif "IN_PROGRESS" in status:
        return "[yellow]⋯[/yellow]"
    elif "FAILED" in status or "ROLLBACK" in status:
        return "[red]✗[/red]"
    return " "


def build_progress_display(progress: StackProgress) -> RenderableType:
    """Build a rich display showing resource creation progress with spinner."""
    table = Table(show_header=True, header_style="bold", box=None)
    table.add_column("", width=2)
    table.add_column("Resource", style="cyan", min_width=25)
    table.add_column("Type", style="dim")
    table.add_column("Status")

    # Sort resources: in_progress first, then by name
    def sort_key(item: tuple[str, ResourceStatus]) -> tuple[int, str]:
        _, r = item
        if "IN_PROGRESS" in r.status:
            return (0, r.logical_id)
        elif "COMPLETE" in r.status:
            return (2, r.logical_id)
        else:
            return (1, r.logical_id)

    sorted_resources = sorted(progress.resources.items(), key=sort_key)

    for _logical_id, resource in sorted_resources:
        icon = get_status_icon(resource.status)
        style = get_status_style(resource.status)
        friendly_type = get_friendly_type(resource.resource_type)

        # Simplify status text
        status_text = resource.status.replace("_", " ").title()

        table.add_row(
            icon,
            resource.logical_id,
            friendly_type,
            f"[{style}]{status_text}[/{style}]",
        )

    # Add spinner header if still in progress
    if not progress.is_complete and not progress.is_failed:
        spinner = Spinner("dots", text=Text(" Creating infrastructure...", style="bold"))
        return Group(spinner, Text(""), table)

    return table


@click.command()
@click.pass_context
def setup(ctx: click.Context) -> None:
    """Create AWS infrastructure for credential storage."""
    config: Config = ctx.obj["config"]
    console = Console()

    if config.stack_name:
        console.print(f"Already set up with stack: [cyan]{config.stack_name}[/cyan]")
        console.print(f"  Bucket: {config.bucket}")
        console.print(f"  Region: {config.region}")
        console.print(f"  Role ARN: {config.role_arn}")
        console.print(f"\nTo reconfigure, delete {config.config_path}")
        return

    console.print("[bold]Exchange Keyshare Setup[/bold]")
    console.print("=" * 40)
    console.print()

    principal_arn = click.prompt("Principal ARN (provided by the credential consumer)", type=str)
    external_id = click.prompt("External ID (provided by the credential consumer)", type=str)

    bucket_name = click.prompt(
        "Bucket name (leave empty for auto-generated)",
        default="",
        show_default=False,
    )
    if not bucket_name:
        bucket_name = None

    default_region = get_default_region()
    region = click.prompt("AWS region", default=default_region)

    console.print()
    console.print("[bold]Creating infrastructure...[/bold]")
    console.print()

    try:
        stack_name, region, cfn = start_stack_creation(
            external_id=external_id,
            principal_arn=principal_arn,
            bucket_name=bucket_name,
            region=region,
        )
    except Exception as e:
        console.print(f"[red]Error: {e}[/red]")
        raise SystemExit(1)

    # Poll with live display
    final_progress: StackProgress | None = None

    with Live(console=console, refresh_per_second=10) as live:
        for progress in poll_stack_progress(stack_name, cfn):
            display = build_progress_display(progress)
            live.update(display)
            final_progress = progress

            if progress.is_complete or progress.is_failed:
                break

    if final_progress is None or final_progress.is_failed:
        console.print()
        console.print(f"[red]Error: {final_progress.failure_reason if final_progress else 'Unknown error'}[/red]")
        raise SystemExit(1)

    # Get outputs and save config
    result = get_stack_outputs(stack_name, region)

    config.bucket = result.bucket
    config.region = result.region
    config.stack_name = result.stack_name
    config.stack_id = result.stack_id
    config.role_arn = result.role_arn
    config.external_id = result.external_id
    config.kms_key_arn = result.kms_key_arn
    config.save()

    console.print()
    console.print("[green bold]Setup complete![/green bold]")
    console.print()
    console.print("[bold]Connection details (provide to credential consumer):[/bold]")
    console.print(f"  Role ARN:    [cyan]{result.role_arn}[/cyan]")
    console.print(f"  Bucket:      [cyan]{result.bucket}[/cyan]")
    console.print(f"  External ID: [cyan]{result.external_id}[/cyan]")
    console.print(f"  Region:      [cyan]{result.region}[/cyan]")
