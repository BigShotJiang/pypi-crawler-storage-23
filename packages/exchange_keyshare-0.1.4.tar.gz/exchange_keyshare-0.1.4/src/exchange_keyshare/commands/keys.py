"""Keys subcommands for managing exchange credentials."""

import click
import questionary
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from exchange_keyshare.config import Config
from exchange_keyshare.keys import (
    delete_credential,
    get_credential,
    list_credentials,
    upload_credential,
)
from exchange_keyshare.schema import (
    PASSPHRASE_REQUIRED_EXCHANGES,
    SUPPORTED_EXCHANGES,
    CredentialSchema,
)


def require_setup(config: Config) -> tuple[str, str, str]:
    """Check that setup has been run, exit with error if not.

    Returns (bucket, region, kms_key_arn) guaranteed to be non-None.
    """
    if not config.bucket or not config.region or not config.kms_key_arn:
        click.echo(
            "Error: No bucket configured. Run 'exchange-keyshare setup' to create the AWS infrastructure.",
            err=True,
        )
        raise SystemExit(1)
    return config.bucket, config.region, config.kms_key_arn


def format_labels(labels: list[dict[str, str]]) -> str:
    """Format labels as key=value, key=value string."""
    return ", ".join(f"{l['key']}={l['value']}" for l in labels)


def parse_pairs(input_str: str) -> list[str]:
    """Parse comma-separated pairs input into list."""
    return [p.strip() for p in input_str.split(",") if p.strip()]


def format_credential_info(cred: CredentialSchema, key: str) -> str:
    """Format credential info for display."""
    lines = [
        f"  Key:      {key}",
        f"  Exchange: {cred.exchange}",
    ]
    if cred.pairs:
        lines.append(f"  Pairs:    {', '.join(cred.pairs)}")
    if cred.labels:
        lines.append(f"  Labels:   {format_labels(cred.labels)}")
    return "\n".join(lines)


@click.group()
def keys() -> None:
    """Manage exchange credentials."""
    pass


@keys.command("list")
@click.pass_context
def keys_list(ctx: click.Context) -> None:
    """List all credentials."""
    config: Config = ctx.obj["config"]
    bucket, region, _kms_key_arn = require_setup(config)
    console = Console()

    try:
        credentials = list_credentials(bucket, region)
    except Exception as e:
        console.print(f"[red]Error:[/red] {e}")
        raise SystemExit(1)

    if not credentials:
        console.print("No credentials found.")
        return

    table = Table(title=f"{len(credentials)} Credential(s)")
    table.add_column("Key", style="cyan")
    table.add_column("Exchange")
    table.add_column("Pairs", style="dim")
    table.add_column("Labels", style="dim")

    for cred in credentials:
        table.add_row(
            cred.key,
            cred.exchange,
            ", ".join(cred.pairs) if cred.pairs else "-",
            format_labels(cred.labels) if cred.labels else "-",
        )

    console.print()
    console.print(table)


def _prompt_cancelled() -> None:
    """Handle user cancellation (Ctrl+C or Escape)."""
    click.echo("\nAborted.", err=True)
    raise SystemExit(1)


def _validate_required(text: str) -> bool | str:
    """Validate that a field is not empty."""
    return True if text else "This field is required"


def _validate_pairs(text: str) -> bool | str:
    """Validate trading pairs format (optional, but must be BASE/QUOTE if provided)."""
    if not text.strip():
        return True  # Empty is fine, it's optional

    pairs = [p.strip() for p in text.split(",") if p.strip()]
    invalid: list[str] = []
    for pair in pairs:
        # Must contain exactly one "/" with non-empty base and quote
        parts = pair.split("/")
        if len(parts) != 2 or not parts[0] or not parts[1]:
            invalid.append(pair)

    if invalid:
        return f"Invalid format: {', '.join(invalid)}. Use BASE/QUOTE (e.g. BTC/USDT)"

    return True


@keys.command("create")
@click.pass_context
def keys_create(ctx: click.Context) -> None:
    """Create a new credential (interactive)."""
    config: Config = ctx.obj["config"]
    bucket, region, kms_key_arn = require_setup(config)
    console = Console()

    console.print()
    console.print(Panel.fit("[bold]Create New Credential[/bold]", border_style="blue"))
    console.print()

    # Exchange selection (arrow keys)
    exchanges = sorted(SUPPORTED_EXCHANGES)
    exchange = questionary.select(
        "Select exchange:",
        choices=exchanges,
        style=questionary.Style([("highlighted", "bold")]),
    ).ask()

    if exchange is None:
        _prompt_cancelled()

    console.print()

    # API credentials (with asterisks)
    api_key = questionary.password("API Key:", validate=_validate_required).ask()

    if api_key is None:
        _prompt_cancelled()

    api_secret = questionary.password("API Secret:", validate=_validate_required).ask()

    if api_secret is None:
        _prompt_cancelled()

    credential_data: dict[str, str] = {
        "api_key": api_key,
        "api_secret": api_secret,
    }

    # Passphrase
    if exchange in PASSPHRASE_REQUIRED_EXCHANGES:
        passphrase = questionary.password(
            "Passphrase (required for this exchange):",
            validate=_validate_required,
        ).ask()

        if passphrase is None:
            _prompt_cancelled()

        credential_data["passphrase"] = passphrase
    else:
        passphrase = questionary.password("Passphrase (optional):").ask()

        if passphrase is None:
            _prompt_cancelled()

        if passphrase:
            credential_data["passphrase"] = passphrase

    console.print()

    # Trading pairs
    pairs_input = questionary.text(
        "Trading pairs (optional, BASE/QUOTE format, e.g. BTC/USDT, ETH/USDT):",
        validate=_validate_pairs,
    ).ask()

    if pairs_input is None:
        _prompt_cancelled()

    pairs: list[str] | None = parse_pairs(pairs_input) or None

    # Labels - always prompt for name first
    labels: list[dict[str, str]] = []

    name_label = questionary.text("Credential name (optional):").ask()

    if name_label is None:
        _prompt_cancelled()

    if name_label:
        labels.append({"key": "name", "value": name_label})

    # Additional labels
    add_more = questionary.confirm(
        "Add more labels? (key/value tags for your own organization)",
        default=False,
    ).ask()

    if add_more is None:
        _prompt_cancelled()

    if add_more:
        while True:
            label_key = questionary.text("Label key (Enter to finish):").ask()

            if label_key is None:
                _prompt_cancelled()

            if not label_key:
                break

            label_value = questionary.text(f"Value for '{label_key}':").ask()

            if label_value is None:
                _prompt_cancelled()

            labels.append({"key": label_key, "value": label_value})

    # Build credential
    credential = CredentialSchema(
        version="1",
        exchange=exchange,
        credential=credential_data,
        pairs=pairs,
        labels=labels or None,
    )

    # Summary
    console.print()
    table = Table(title="Credential Summary", show_header=False, box=None)
    table.add_column("Field", style="dim")
    table.add_column("Value")

    table.add_row("Exchange", f"[cyan]{exchange}[/cyan]")
    if pairs:
        table.add_row("Pairs", ", ".join(pairs))
    if labels:
        table.add_row("Labels", format_labels(labels))

    console.print(table)
    console.print()

    # Confirm upload
    confirm = questionary.confirm("Upload this credential?", default=True).ask()

    if not confirm:
        click.echo("Aborted.")
        raise SystemExit(0)

    # Upload
    try:
        s3_key = upload_credential(bucket, region, credential, kms_key_arn)
        console.print()
        console.print("[green]✓[/green] Credential uploaded successfully!")
        console.print(f"  Key: [cyan]{s3_key}[/cyan]")
    except Exception as e:
        console.print(f"[red]Error:[/red] {e}", style="red")
        raise SystemExit(1)


@keys.command("delete")
@click.argument("key")
@click.option("-y", "--yes", is_flag=True, help="Skip confirmation prompt")
@click.pass_context
def keys_delete(ctx: click.Context, key: str, yes: bool) -> None:
    """Delete a credential by S3 key."""
    config: Config = ctx.obj["config"]
    bucket, region, _kms_key_arn = require_setup(config)
    console = Console()

    # Get credential info before deletion
    try:
        credential = get_credential(bucket, region, key)
    except Exception as e:
        console.print(f"[red]Error:[/red] Could not find credential: {e}")
        raise SystemExit(1)

    # Show credential info
    console.print()
    table = Table(title="Credential to Delete", show_header=False, box=None)
    table.add_column("Field", style="dim")
    table.add_column("Value")

    table.add_row("Key", f"[cyan]{key}[/cyan]")
    table.add_row("Exchange", credential.exchange)
    if credential.pairs:
        table.add_row("Pairs", ", ".join(credential.pairs))
    if credential.labels:
        table.add_row("Labels", format_labels(credential.labels))

    console.print(table)
    console.print()

    if not yes:
        confirm = questionary.confirm("Delete this credential?", default=False).ask()
        if not confirm:
            console.print("Aborted.")
            raise SystemExit(0)

    # Delete
    try:
        delete_credential(bucket, region, key)
        console.print("[green]✓[/green] Credential deleted successfully.")
    except Exception as e:
        console.print(f"[red]Error:[/red] {e}")
        raise SystemExit(1)


@keys.command("update")
@click.argument("key")
@click.pass_context
def keys_update(ctx: click.Context, key: str) -> None:
    """Update a credential's pairs and labels (interactive)."""
    config: Config = ctx.obj["config"]
    bucket, region, kms_key_arn = require_setup(config)
    console = Console()

    try:
        credential = get_credential(bucket, region, key)
    except Exception as e:
        console.print(f"[red]Error:[/red] Could not find credential: {e}")
        raise SystemExit(1)

    # Show current credential
    console.print()
    table = Table(title="Current Credential", show_header=False, box=None)
    table.add_column("Field", style="dim")
    table.add_column("Value")

    table.add_row("Key", f"[cyan]{key}[/cyan]")
    table.add_row("Exchange", credential.exchange)
    if credential.pairs:
        table.add_row("Pairs", ", ".join(credential.pairs))
    if credential.labels:
        table.add_row("Labels", format_labels(credential.labels))

    console.print(table)
    console.print()

    # Pairs
    current_pairs = list(credential.pairs) if credential.pairs else []
    current_pairs_str = ", ".join(current_pairs) if current_pairs else ""
    pairs_input = questionary.text(
        "Trading pairs (BASE/QUOTE format, Enter to keep current):",
        default=current_pairs_str,
        validate=_validate_pairs,
    ).ask()

    if pairs_input is None:
        _prompt_cancelled()

    new_pairs = parse_pairs(pairs_input) if pairs_input else []

    # Labels
    new_labels: list[dict[str, str]] = list(credential.labels) if credential.labels else []

    while True:
        # Build choices - "Done" first as default
        choices = ["Done editing labels", "Add label"]
        if new_labels:
            choices.append("Remove label")
            choices.append("Clear all labels")

        action = questionary.select("Labels:", choices=choices).ask()

        if action is None:
            _prompt_cancelled()

        if action == "Done editing labels":
            break

        if action == "Add label":
            label_key = questionary.text("Label key:").ask()
            if label_key is None:
                _prompt_cancelled()
            if label_key:
                label_value = questionary.text(f"Value for '{label_key}':").ask()
                if label_value is None:
                    _prompt_cancelled()
                new_labels = [l for l in new_labels if l["key"] != label_key]
                new_labels.append({"key": label_key, "value": label_value})

        elif action == "Remove label" and new_labels:
            label_key = questionary.select(
                "Label to remove:",
                choices=[l["key"] for l in new_labels],
            ).ask()
            if label_key is None:
                _prompt_cancelled()
            new_labels = [l for l in new_labels if l["key"] != label_key]

        elif action == "Clear all labels":
            new_labels = []

        # Show current state after changes
        if action != "Done editing labels":
            if new_labels:
                console.print(f"  Labels: {format_labels(new_labels)}")
            else:
                console.print("  Labels: (none)")

    # Check for changes
    old_pairs_set = set(current_pairs)
    new_pairs_set = set(new_pairs)
    old_labels_dict = {l["key"]: l["value"] for l in (credential.labels or [])}
    new_labels_dict = {l["key"]: l["value"] for l in new_labels}

    if old_pairs_set == new_pairs_set and old_labels_dict == new_labels_dict:
        console.print("\nNo changes to apply.")
        return

    # Show diff
    console.print()
    console.print("[bold]Changes:[/bold]")

    if old_pairs_set != new_pairs_set:
        old_display = ", ".join(sorted(old_pairs_set)) or "(none)"
        new_display = ", ".join(sorted(new_pairs_set)) or "(none)"
        console.print(f"  Pairs: {old_display} → {new_display}")

    if old_labels_dict != new_labels_dict:
        for k, v in new_labels_dict.items():
            if k not in old_labels_dict:
                console.print(f"  Labels: [green]+{k}={v}[/green]")
            elif old_labels_dict[k] != v:
                console.print(f"  Labels: {k}={old_labels_dict[k]} → {k}={v}")
        for k in old_labels_dict:
            if k not in new_labels_dict:
                console.print(f"  Labels: [red]-{k}={old_labels_dict[k]}[/red]")

    console.print()

    confirm = questionary.confirm("Apply these changes?", default=True).ask()

    if not confirm:
        console.print("Aborted.")
        raise SystemExit(0)

    updated = CredentialSchema(
        version=credential.version,
        exchange=credential.exchange,
        credential=credential.credential,
        pairs=new_pairs or None,
        labels=new_labels or None,
    )

    try:
        upload_credential(bucket, region, updated, kms_key_arn, s3_key=key)
        console.print("[green]✓[/green] Credential updated successfully.")
    except Exception as e:
        console.print(f"[red]Error:[/red] {e}")
        raise SystemExit(1)
