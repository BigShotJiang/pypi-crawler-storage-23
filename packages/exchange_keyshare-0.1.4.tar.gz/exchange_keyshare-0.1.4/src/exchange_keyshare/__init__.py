"""Exchange Keyshare - CLI for market makers to securely share exchange credentials."""

__version__ = "0.1.0"
