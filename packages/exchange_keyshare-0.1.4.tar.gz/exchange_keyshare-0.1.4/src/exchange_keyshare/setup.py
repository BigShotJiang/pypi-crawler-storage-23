"""Setup command logic for creating AWS infrastructure."""

from __future__ import annotations

import os
import secrets
import string
import time
from collections.abc import Generator
from dataclasses import dataclass
from typing import TYPE_CHECKING, cast

import boto3
from botocore.exceptions import ClientError

if TYPE_CHECKING:
    from mypy_boto3_cloudformation import CloudFormationClient

from exchange_keyshare.cfn import load_template


def generate_bucket_name() -> str:
    """Generate a unique S3 bucket name."""
    chars = string.ascii_lowercase + string.digits
    suffix = "".join(secrets.choice(chars) for _ in range(12))
    return f"exchange-keyshare-{suffix}"


def get_default_region() -> str:
    """Get default AWS region from env or fallback."""
    return os.environ.get("AWS_REGION", os.environ.get("AWS_DEFAULT_REGION", "us-east-1"))


@dataclass
class SetupResult:
    """Result of setup operation."""

    bucket: str
    region: str
    role_arn: str
    external_id: str
    stack_name: str
    stack_id: str
    kms_key_arn: str


@dataclass
class ResourceStatus:
    """Status of a CloudFormation resource."""

    logical_id: str
    resource_type: str
    status: str
    reason: str | None = None


@dataclass
class StackProgress:
    """Progress update for stack creation."""

    resources: dict[str, ResourceStatus]
    stack_status: str
    is_complete: bool
    is_failed: bool
    failure_reason: str | None = None


# Friendly names for CloudFormation resource types
RESOURCE_TYPE_NAMES: dict[str, str] = {
    "AWS::S3::Bucket": "S3 Bucket",
    "AWS::S3::BucketPolicy": "Bucket Policy",
    "AWS::KMS::Key": "KMS Key",
    "AWS::KMS::Alias": "KMS Alias",
    "AWS::IAM::Role": "IAM Role",
}


def get_friendly_type(resource_type: str) -> str:
    """Get a friendly name for a resource type."""
    return RESOURCE_TYPE_NAMES.get(resource_type, resource_type)


def start_stack_creation(
    external_id: str,
    principal_arn: str,
    bucket_name: str | None = None,
    region: str | None = None,
) -> tuple[str, str, CloudFormationClient]:
    """Start CloudFormation stack creation. Returns (stack_name, region, cfn_client)."""
    bucket = bucket_name or generate_bucket_name()
    region = region or get_default_region()
    stack_name = bucket  # Bucket name already has unique suffix

    cfn = cast("CloudFormationClient", boto3.client("cloudformation", region_name=region))  # pyright: ignore[reportUnknownMemberType]
    template = load_template()

    try:
        cfn.create_stack(
            StackName=stack_name,
            TemplateBody=template,
            Parameters=[
                {"ParameterKey": "BucketName", "ParameterValue": bucket},
                {"ParameterKey": "ConsumerPrincipalArn", "ParameterValue": principal_arn},
                {"ParameterKey": "ExternalId", "ParameterValue": external_id},
            ],
            Capabilities=["CAPABILITY_NAMED_IAM"],
            OnFailure="DELETE",
        )
    except ClientError as e:
        if "AlreadyExistsException" in str(e):
            raise Exception(f"Stack {stack_name} already exists") from e
        raise

    return stack_name, region, cfn


def poll_stack_progress(
    stack_name: str,
    cfn: CloudFormationClient,
    poll_interval: float = 2.0,
    max_attempts: int = 300,
) -> Generator[StackProgress, None, None]:
    """Poll stack creation progress and yield updates."""
    resources: dict[str, ResourceStatus] = {}

    for _ in range(max_attempts):
        # Get current stack status
        try:
            stacks_response = cfn.describe_stacks(StackName=stack_name)
        except ClientError:
            # Stack might be deleted on failure
            yield StackProgress(
                resources=resources,
                stack_status="DELETE_IN_PROGRESS",
                is_complete=False,
                is_failed=True,
                failure_reason="Stack creation failed and is being deleted",
            )
            return

        stack = stacks_response["Stacks"][0]
        stack_status = stack.get("StackStatus", "UNKNOWN")

        # Get resource events
        events_response = cfn.describe_stack_events(StackName=stack_name)
        for event in events_response["StackEvents"]:
            logical_id = event.get("LogicalResourceId", "")
            resource_type = event.get("ResourceType", "")
            status = event.get("ResourceStatus", "")
            reason = event.get("ResourceStatusReason")

            # Skip the stack itself
            if resource_type == "AWS::CloudFormation::Stack":
                continue

            # Update if this is a newer status for this resource
            if logical_id not in resources or _is_newer_status(status, resources[logical_id].status):
                resources[logical_id] = ResourceStatus(
                    logical_id=logical_id,
                    resource_type=resource_type,
                    status=status,
                    reason=reason,
                )

        # Check for completion
        is_complete = stack_status == "CREATE_COMPLETE"
        is_failed = stack_status in ("CREATE_FAILED", "ROLLBACK_COMPLETE", "ROLLBACK_IN_PROGRESS", "DELETE_IN_PROGRESS")

        failure_reason: str | None = None
        if is_failed:
            # Find failure reasons
            failed_resources = [r for r in resources.values() if "FAILED" in r.status]
            if failed_resources:
                reasons = [r.reason for r in failed_resources if r.reason]
                failure_reason = "; ".join(reasons[:3]) if reasons else "Unknown error"

        yield StackProgress(
            resources=resources,
            stack_status=stack_status,
            is_complete=is_complete,
            is_failed=is_failed,
            failure_reason=failure_reason,
        )

        if is_complete or is_failed:
            return

        time.sleep(poll_interval)

    # Timeout
    yield StackProgress(
        resources=resources,
        stack_status="TIMEOUT",
        is_complete=False,
        is_failed=True,
        failure_reason="Stack creation timed out",
    )


def _is_newer_status(new_status: str, old_status: str) -> bool:
    """Check if new_status is more recent than old_status."""
    # Status progression order
    status_order = [
        "CREATE_IN_PROGRESS",
        "CREATE_COMPLETE",
        "CREATE_FAILED",
        "DELETE_IN_PROGRESS",
        "DELETE_COMPLETE",
    ]

    try:
        new_idx = status_order.index(new_status)
        old_idx = status_order.index(old_status)
        return new_idx > old_idx
    except ValueError:
        # Unknown status, assume it's newer
        return True


def get_stack_console_url(stack_id: str, region: str) -> str:
    """Get AWS Console URL for a CloudFormation stack."""
    # URL-encode the stack ID (it contains special characters)
    from urllib.parse import quote
    encoded_stack_id = quote(stack_id, safe="")
    return f"https://{region}.console.aws.amazon.com/cloudformation/home?region={region}#/stacks/stackinfo?stackId={encoded_stack_id}"


def start_stack_deletion(stack_name: str, region: str) -> "CloudFormationClient":
    """Start CloudFormation stack deletion. Returns cfn_client for polling."""
    cfn = cast("CloudFormationClient", boto3.client("cloudformation", region_name=region))  # pyright: ignore[reportUnknownMemberType]

    try:
        cfn.delete_stack(StackName=stack_name)  # pyright: ignore[reportUnknownMemberType]
    except ClientError as e:
        raise Exception(f"Failed to delete stack: {e}") from e

    return cfn


def poll_stack_deletion(
    stack_name: str,
    cfn: "CloudFormationClient",
    poll_interval: float = 2.0,
    max_attempts: int = 300,
) -> Generator[StackProgress, None, None]:
    """Poll stack deletion progress and yield updates."""
    resources: dict[str, ResourceStatus] = {}

    for _ in range(max_attempts):
        # Get current stack status
        try:
            stacks_response = cfn.describe_stacks(StackName=stack_name)
        except ClientError as e:
            # Stack not found means deletion complete
            if "does not exist" in str(e):
                yield StackProgress(
                    resources=resources,
                    stack_status="DELETE_COMPLETE",
                    is_complete=True,
                    is_failed=False,
                )
                return
            raise

        stack = stacks_response["Stacks"][0]
        stack_status = stack.get("StackStatus", "UNKNOWN")

        # Get resource events (only delete-related)
        try:
            events_response = cfn.describe_stack_events(StackName=stack_name)
            for event in events_response["StackEvents"]:
                logical_id = event.get("LogicalResourceId", "")
                resource_type = event.get("ResourceType", "")
                status = event.get("ResourceStatus", "")
                reason = event.get("ResourceStatusReason")

                # Skip the stack itself
                if resource_type == "AWS::CloudFormation::Stack":
                    continue

                # Only track delete-related statuses
                if "DELETE" not in status:
                    continue

                # Update if this is a newer status for this resource
                if logical_id not in resources or _is_newer_delete_status(status, resources[logical_id].status):
                    resources[logical_id] = ResourceStatus(
                        logical_id=logical_id,
                        resource_type=resource_type,
                        status=status,
                        reason=reason,
                    )
        except ClientError:
            pass  # Stack events may not be available

        # Check for completion
        is_complete = stack_status == "DELETE_COMPLETE"
        is_failed = stack_status == "DELETE_FAILED"

        failure_reason: str | None = None
        if is_failed:
            failed_resources = [r for r in resources.values() if "FAILED" in r.status]
            if failed_resources:
                reasons = [r.reason for r in failed_resources if r.reason]
                failure_reason = "; ".join(reasons[:3]) if reasons else "Unknown error"

        yield StackProgress(
            resources=resources,
            stack_status=stack_status,
            is_complete=is_complete,
            is_failed=is_failed,
            failure_reason=failure_reason,
        )

        if is_complete or is_failed:
            return

        time.sleep(poll_interval)

    # Timeout
    yield StackProgress(
        resources=resources,
        stack_status="TIMEOUT",
        is_complete=False,
        is_failed=True,
        failure_reason="Stack deletion timed out",
    )


def _is_newer_delete_status(new_status: str, old_status: str) -> bool:
    """Check if new_status is more recent than old_status for deletion."""
    status_order = [
        "CREATE_COMPLETE",
        "DELETE_IN_PROGRESS",
        "DELETE_COMPLETE",
        "DELETE_FAILED",
        "DELETE_SKIPPED",
    ]

    try:
        new_idx = status_order.index(new_status)
        old_idx = status_order.index(old_status)
        return new_idx > old_idx
    except ValueError:
        return True


def get_stack_outputs(stack_name: str, region: str) -> SetupResult:
    """Get outputs from a completed stack."""
    cfn = cast("CloudFormationClient", boto3.client("cloudformation", region_name=region))  # pyright: ignore[reportUnknownMemberType]

    response = cfn.describe_stacks(StackName=stack_name)
    stack = response["Stacks"][0]
    stack_id = stack.get("StackId", "")
    stack_outputs = stack.get("Outputs", [])
    outputs: dict[str, str] = {
        o["OutputKey"]: o["OutputValue"]
        for o in stack_outputs
        if "OutputKey" in o and "OutputValue" in o
    }

    return SetupResult(
        bucket=outputs["BucketName"],
        region=region,
        role_arn=outputs["RoleArn"],
        external_id=outputs["ExternalId"],
        stack_name=stack_name,
        stack_id=stack_id,
        kms_key_arn=outputs["KmsKeyArn"],
    )


def create_stack(
    external_id: str,
    principal_arn: str,
    bucket_name: str | None = None,
    region: str | None = None,
) -> SetupResult:
    """Create CloudFormation stack with credential storage infrastructure.

    This is the simple blocking API. For progress updates, use
    start_stack_creation() + poll_stack_progress() + get_stack_outputs().
    """
    stack_name, region, cfn = start_stack_creation(
        external_id, principal_arn, bucket_name, region
    )

    # Poll until complete
    for progress in poll_stack_progress(stack_name, cfn):
        if progress.is_failed:
            raise Exception(f"Stack creation failed: {progress.failure_reason}")
        if progress.is_complete:
            break

    return get_stack_outputs(stack_name, region)
