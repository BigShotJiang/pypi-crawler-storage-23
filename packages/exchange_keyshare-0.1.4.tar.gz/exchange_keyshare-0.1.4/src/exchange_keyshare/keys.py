"""Key management operations."""

from __future__ import annotations

import secrets
import string
from dataclasses import dataclass
from typing import TYPE_CHECKING, cast

import boto3
import yaml

if TYPE_CHECKING:
    from mypy_boto3_s3 import S3Client

from exchange_keyshare.schema import CredentialSchema, validate_credential


def generate_s3_key(exchange: str) -> str:
    """Generate a unique S3 key for a credential."""
    chars = string.ascii_lowercase + string.digits
    suffix = "".join(secrets.choice(chars) for _ in range(12))
    return f"exchange-credentials/{exchange}-{suffix}.yaml"


def parse_credential_from_yaml(content: str) -> CredentialSchema:
    """Parse and validate credential from YAML string."""
    data = yaml.safe_load(content)
    return validate_credential(data)


@dataclass
class CredentialInfo:
    """Info about a stored credential (for listing)."""

    key: str
    exchange: str
    pairs: list[str] | None
    labels: list[dict[str, str]] | None


def list_credentials(bucket: str, region: str) -> list[CredentialInfo]:
    """List all credentials in the bucket."""
    s3 = cast("S3Client", boto3.client("s3", region_name=region))  # pyright: ignore[reportUnknownMemberType]

    result: list[CredentialInfo] = []

    paginator = s3.get_paginator("list_objects_v2")
    for page in paginator.paginate(Bucket=bucket, Prefix="exchange-credentials/"):
        for obj in page.get("Contents", []):
            key = obj.get("Key")
            if not key or not key.endswith(".yaml"):
                continue

            response = s3.get_object(Bucket=bucket, Key=key)
            content = response["Body"].read().decode("utf-8")
            cred = parse_credential_from_yaml(content)
            result.append(CredentialInfo(
                key=key,
                exchange=cred.exchange,
                pairs=cred.pairs,
                labels=cred.labels,
            ))

    return result


def upload_credential(
    bucket: str,
    region: str,
    credential: CredentialSchema,
    kms_key_arn: str,
    s3_key: str | None = None,
) -> str:
    """Upload credential to S3. Returns the S3 key used."""
    s3 = cast("S3Client", boto3.client("s3", region_name=region))  # pyright: ignore[reportUnknownMemberType]

    key = s3_key or generate_s3_key(credential.exchange)
    content = yaml.dump(credential.to_dict(), default_flow_style=False)

    s3.put_object(
        Bucket=bucket,
        Key=key,
        Body=content.encode("utf-8"),
        ContentType="application/x-yaml",
        ServerSideEncryption="aws:kms",
        SSEKMSKeyId=kms_key_arn,
    )

    return key


def get_credential(bucket: str, region: str, key: str) -> CredentialSchema:
    """Get a credential from S3."""
    s3 = cast("S3Client", boto3.client("s3", region_name=region))  # pyright: ignore[reportUnknownMemberType]

    response = s3.get_object(Bucket=bucket, Key=key)
    content = response["Body"].read().decode("utf-8")

    return parse_credential_from_yaml(content)


def delete_credential(bucket: str, region: str, key: str) -> None:
    """Delete a credential from S3."""
    s3 = cast("S3Client", boto3.client("s3", region_name=region))  # pyright: ignore[reportUnknownMemberType]
    s3.delete_object(Bucket=bucket, Key=key)
