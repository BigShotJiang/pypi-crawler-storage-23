"""CLI entrypoint for exchange-keyshare."""

from pathlib import Path

import click

from exchange_keyshare.commands.config import config
from exchange_keyshare.commands.keys import keys
from exchange_keyshare.commands.setup import setup
from exchange_keyshare.commands.teardown import teardown
from exchange_keyshare.config import Config


@click.group()
@click.version_option()
@click.option(
    "--config",
    "config_path",
    envvar="EXCHANGE_KEYSHARE_CONFIG",
    type=click.Path(),
    help="Path to config file",
)
@click.pass_context
def main(ctx: click.Context, config_path: str | None) -> None:
    """Exchange Keyshare - Securely share exchange API credentials."""
    ctx.ensure_object(dict)
    config = Config()
    if config_path:
        config.config_path = Path(config_path)
    config.load()
    ctx.obj["config"] = config


main.add_command(setup)
main.add_command(config)
main.add_command(teardown)
main.add_command(keys)


if __name__ == "__main__":
    main()
