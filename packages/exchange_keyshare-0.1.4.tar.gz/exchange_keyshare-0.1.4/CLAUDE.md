# CLAUDE.md - exchange-keyshare

CLI tool for market makers to securely share exchange API credentials.

## Tech Stack

- Python 3.12+
- Click (CLI framework)
- boto3 (AWS SDK)
- rich (terminal UI)
- questionary (interactive prompts)
- uv (package manager)
- pyright strict mode

## Project Structure

```
src/exchange_keyshare/
├── cli.py              # CLI entrypoint
├── config.py           # Config file handling (~/.config/exchange-keyshare/)
├── setup.py            # Stack creation logic
├── keys.py             # S3 credential operations
├── schema.py           # Credential validation
├── cfn.py              # CloudFormation template loading
├── templates/
│   └── stack.yaml      # CloudFormation template
└── commands/
    ├── setup.py        # `exchange-keyshare setup` command
    ├── config.py       # `exchange-keyshare config` command
    ├── teardown.py     # `exchange-keyshare teardown` command
    └── keys.py         # `exchange-keyshare keys` subcommands
```

## Commands

```bash
exchange-keyshare setup          # Create AWS infrastructure
exchange-keyshare config         # Display current configuration
exchange-keyshare teardown       # Delete AWS infrastructure (revoke access)
exchange-keyshare keys list      # List credentials
exchange-keyshare keys create    # Create credential (interactive)
exchange-keyshare keys delete    # Delete credential
exchange-keyshare keys update    # Update pairs/labels
```

## Configuration

Config file: `~/.config/exchange-keyshare/config.yaml`

Created by `setup` command with:
- `bucket`: S3 bucket name
- `region`: AWS region
- `stack_name`: CloudFormation stack name
- `stack_id`: CloudFormation stack ID (ARN)
- `role_arn`: IAM role ARN
- `external_id`: External ID for role assumption
- `kms_key_arn`: KMS key ARN

## Environment Variables

| Variable | Description |
|----------|-------------|
| `EXCHANGE_KEYSHARE_CONFIG` | Override config file path |
| `AWS_REGION` / `AWS_DEFAULT_REGION` | Default AWS region |

## CloudFormation Template

The `setup` command deploys `templates/stack.yaml` which creates:

**Resources:**
- `CredentialsBucket` - S3 bucket for credentials (versioned, KMS-encrypted)
- `AccessLogsBucket` - S3 access logs (90-day retention)
- `CredentialsKey` - KMS key for encryption (auto-rotating)
- `CredentialsKeyAlias` - KMS key alias
- `ConsumerAccessRole` - IAM role for credential consumer to assume (read-only)
- `CredentialsBucketPolicy` - Enforces KMS encryption on uploads
- `AccessLogsBucketPolicy` - Allows S3 logging service

**Security hardening:**
- `DeletionPolicy: Retain` on bucket and KMS key (prevents accidental data loss)
- Bucket policy denies unencrypted uploads or wrong KMS key
- External ID required for role assumption (confused deputy protection)
- All public access blocked
- S3 access logging enabled

**Consumer role permissions (read-only):**
- `s3:ListBucket` (only `exchange-credentials/*` prefix)
- `s3:GetObject` (only `exchange-credentials/*`)
- `kms:Decrypt`, `kms:DescribeKey`

## Credential Schema

Credentials stored as YAML in S3 under `exchange-credentials/` prefix:

```yaml
version: "1"
exchange: binance  # binance, coinbase, kraken, kucoin, bitget, okx
credential:
  api_key: "..."
  api_secret: "..."
  passphrase: "..."  # Required for coinbase, kucoin, bitget, okx
pairs:              # Optional, BASE/QUOTE format
  - BTC/USDT
  - ETH/USDT
labels:             # Optional
  - key: environment
    value: production
```

## Development

```bash
# Install dependencies
uv sync

# Run tests
uv run pytest

# Type checking
uv run pyright

# Linting
uv run ruff check src/
```

## Worktrees

Use `.worktrees/` directory for feature branches (already in `.gitignore`).
