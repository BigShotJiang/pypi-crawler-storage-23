"""Tests for CloudFormation operations."""

from exchange_keyshare.cfn import get_template_path, load_template


def test_template_path_exists() -> None:
    """Template file should exist."""
    path = get_template_path()
    assert path.exists()
    assert path.name == "stack.yaml"


def test_load_template_returns_string() -> None:
    """Template should be loadable as string."""
    template = load_template()
    assert isinstance(template, str)
    assert "AWSTemplateFormatVersion" in template
    assert "CredentialsBucket" in template
    assert "CredentialsKey" in template
    assert "ConsumerAccessRole" in template
