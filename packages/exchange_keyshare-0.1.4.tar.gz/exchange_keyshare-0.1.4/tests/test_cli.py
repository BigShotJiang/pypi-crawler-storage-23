"""Tests for CLI commands."""

from pathlib import Path
from unittest.mock import MagicMock, patch

from click.testing import CliRunner

from exchange_keyshare.cli import main
from exchange_keyshare.config import save_config


def test_config_command_displays_configuration(tmp_path: Path) -> None:
    """Config command displays all configuration fields."""
    config_path = tmp_path / "config.yaml"

    save_config(
        config_path,
        {
            "bucket": "test-bucket",
            "region": "us-east-1",
            "stack_name": "test-stack",
            "stack_id": "arn:aws:cloudformation:us-east-1:123456789:stack/test-stack/abc123",
            "role_arn": "arn:aws:iam::123456789:role/test-role",
            "external_id": "test-external-id",
            "kms_key_arn": "arn:aws:kms:us-east-1:123456789:key/abc123",
        },
    )

    runner = CliRunner()
    result = runner.invoke(main, ["--config", str(config_path), "config"])

    assert result.exit_code == 0
    assert "test-bucket" in result.output
    assert "us-east-1" in result.output
    assert "test-stack" in result.output
    # Stack ID may be truncated by Rich table rendering, just check it starts showing
    assert "arn:aws:cloudformation" in result.output
    assert "arn:aws:iam" in result.output
    assert "test-external-id" in result.output


def test_config_command_shows_message_when_not_configured(tmp_path: Path) -> None:
    """Config command shows helpful message when no config exists."""
    config_path = tmp_path / "config.yaml"

    runner = CliRunner()
    result = runner.invoke(main, ["--config", str(config_path), "config"])

    assert result.exit_code == 0
    assert "not configured" in result.output.lower() or "setup" in result.output.lower()


def test_teardown_requires_confirmation(tmp_path: Path) -> None:
    """Teardown command requires typing confirmation to proceed."""
    config_path = tmp_path / "config.yaml"
    save_config(
        config_path,
        {
            "bucket": "test-bucket",
            "region": "us-east-1",
            "stack_name": "test-stack",
            "stack_id": "arn:aws:cloudformation:us-east-1:123456789:stack/test-stack/abc123",
        },
    )

    runner = CliRunner()
    # User types wrong confirmation
    result = runner.invoke(main, ["--config", str(config_path), "teardown"], input="wrong\n")

    assert result.exit_code == 1
    assert "aborted" in result.output.lower() or "cancelled" in result.output.lower()
    # Config file should still exist
    assert config_path.exists()


def test_teardown_shows_scary_warning(tmp_path: Path) -> None:
    """Teardown command shows a scary warning about irreversibility."""
    config_path = tmp_path / "config.yaml"
    save_config(
        config_path,
        {
            "bucket": "test-bucket",
            "region": "us-east-1",
            "stack_name": "test-stack",
            "stack_id": "arn:aws:cloudformation:us-east-1:123456789:stack/test-stack/abc123",
        },
    )

    runner = CliRunner()
    result = runner.invoke(main, ["--config", str(config_path), "teardown"], input="\n")

    # Should show warning text about irreversibility
    output_lower = result.output.lower()
    assert "warning" in output_lower or "cannot be undone" in output_lower or "permanent" in output_lower


@patch("exchange_keyshare.commands.teardown.poll_stack_deletion")
@patch("exchange_keyshare.commands.teardown.start_stack_deletion")
def test_teardown_deletes_stack_and_config_on_confirmation(
    mock_start_deletion: MagicMock,
    mock_poll_deletion: MagicMock,
    tmp_path: Path,
) -> None:
    """Teardown deletes CloudFormation stack and config file when confirmed."""
    from exchange_keyshare.setup import StackProgress

    # Mock successful deletion
    mock_start_deletion.return_value = MagicMock()
    mock_poll_deletion.return_value = iter([
        StackProgress(
            resources={},
            stack_status="DELETE_COMPLETE",
            is_complete=True,
            is_failed=False,
        )
    ])

    config_path = tmp_path / "config.yaml"
    save_config(
        config_path,
        {
            "bucket": "test-bucket",
            "region": "us-east-1",
            "stack_name": "test-stack",
            "stack_id": "arn:aws:cloudformation:us-east-1:123456789:stack/test-stack/abc123",
        },
    )

    runner = CliRunner()
    # User types correct confirmation (the stack name)
    result = runner.invoke(main, ["--config", str(config_path), "teardown"], input="test-stack\n")

    assert result.exit_code == 0
    mock_start_deletion.assert_called_once_with("test-stack", "us-east-1")
    # Config file should be deleted
    assert not config_path.exists()


def test_teardown_shows_message_when_not_configured(tmp_path: Path) -> None:
    """Teardown shows helpful message when no config exists."""
    config_path = tmp_path / "config.yaml"

    runner = CliRunner()
    result = runner.invoke(main, ["--config", str(config_path), "teardown"])

    assert result.exit_code == 0
    assert "not configured" in result.output.lower() or "nothing to teardown" in result.output.lower()


@patch("exchange_keyshare.commands.teardown.list_credentials")
def test_teardown_shows_existing_credentials_with_pairs_and_labels(
    mock_list_credentials: MagicMock, tmp_path: Path
) -> None:
    """Teardown shows existing credentials with pairs and labels in the warning."""
    from exchange_keyshare.keys import CredentialInfo

    mock_list_credentials.return_value = [
        CredentialInfo(
            key="exchange-credentials/binance-abc123.yaml",
            exchange="binance",
            pairs=["BTC/USDT", "ETH/USDT"],
            labels=[{"key": "environment", "value": "production"}],
        ),
        CredentialInfo(
            key="exchange-credentials/coinbase-def456.yaml",
            exchange="coinbase",
            pairs=None,
            labels=None,
        ),
    ]

    config_path = tmp_path / "config.yaml"
    save_config(
        config_path,
        {
            "bucket": "test-bucket",
            "region": "us-east-1",
            "stack_name": "test-stack",
        },
    )

    runner = CliRunner()
    result = runner.invoke(main, ["--config", str(config_path), "teardown"], input="\n")

    # Should show credentials in output
    assert "binance" in result.output.lower()
    assert "coinbase" in result.output.lower()
    # Should show pairs
    assert "BTC/USDT" in result.output
    assert "ETH/USDT" in result.output
    # Should show labels
    assert "environment=production" in result.output


@patch("exchange_keyshare.commands.teardown.list_credentials")
def test_teardown_gracefully_handles_list_credentials_failure(
    mock_list_credentials: MagicMock, tmp_path: Path
) -> None:
    """Teardown continues gracefully if listing credentials fails."""
    mock_list_credentials.side_effect = Exception("Access denied")

    config_path = tmp_path / "config.yaml"
    save_config(
        config_path,
        {
            "bucket": "test-bucket",
            "region": "us-east-1",
            "stack_name": "test-stack",
        },
    )

    runner = CliRunner()
    result = runner.invoke(main, ["--config", str(config_path), "teardown"], input="\n")

    # Should still show the warning and prompt (not crash)
    assert "warning" in result.output.lower() or "cannot be undone" in result.output.lower()


@patch("exchange_keyshare.commands.teardown.poll_stack_deletion")
@patch("exchange_keyshare.commands.teardown.start_stack_deletion")
def test_teardown_shows_console_url_and_cancel_message(
    mock_start_deletion: MagicMock,
    mock_poll_deletion: MagicMock,
    tmp_path: Path,
) -> None:
    """Teardown shows AWS Console URL and message about safe cancellation."""
    from exchange_keyshare.setup import StackProgress

    mock_start_deletion.return_value = MagicMock()
    mock_poll_deletion.return_value = iter([
        StackProgress(
            resources={},
            stack_status="DELETE_COMPLETE",
            is_complete=True,
            is_failed=False,
        )
    ])

    config_path = tmp_path / "config.yaml"
    save_config(
        config_path,
        {
            "bucket": "test-bucket",
            "region": "us-east-1",
            "stack_name": "test-stack",
            "stack_id": "arn:aws:cloudformation:us-east-1:123456789:stack/test-stack/abc123",
        },
    )

    runner = CliRunner()
    result = runner.invoke(main, ["--config", str(config_path), "teardown"], input="test-stack\n")

    assert result.exit_code == 0
    # Should show console URL
    assert "console.aws.amazon.com" in result.output
    # Should show message about safe cancellation
    assert "ctrl+c" in result.output.lower() or "cancel" in result.output.lower()
