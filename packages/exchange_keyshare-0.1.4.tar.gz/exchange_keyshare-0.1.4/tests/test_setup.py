"""Tests for setup command logic."""

from exchange_keyshare.setup import generate_bucket_name


def test_generate_bucket_name() -> None:
    """Generated bucket names have correct format and are unique."""
    name = generate_bucket_name()
    assert name.startswith("exchange-keyshare-")
    assert len(name) <= 63

    # Names should be unique
    names = {generate_bucket_name() for _ in range(10)}
    assert len(names) == 10
