"""Tests for keys module."""

import pytest

from exchange_keyshare.keys import generate_s3_key, parse_credential_from_yaml


def test_generate_s3_key() -> None:
    """Generated keys have correct format and are unique."""
    key = generate_s3_key("binance")
    assert key.startswith("exchange-credentials/binance-")
    assert key.endswith(".yaml")

    # Keys should be unique
    keys = {generate_s3_key("binance") for _ in range(10)}
    assert len(keys) == 10


def test_parse_credential_from_yaml_valid() -> None:
    """Valid YAML is parsed correctly."""
    yaml_content = """
version: "1.0"
exchange: binance
credential:
  api_key: test_key
  api_secret: test_secret
pairs:
  - BTC/USDT
"""
    result = parse_credential_from_yaml(yaml_content)
    assert result.exchange == "binance"
    assert result.pairs == ["BTC/USDT"]


def test_parse_credential_from_yaml_invalid() -> None:
    """Invalid YAML raises error."""
    yaml_content = """
version: "1.0"
exchange: unknown_exchange
credential:
  api_key: test
  api_secret: test
"""
    with pytest.raises(Exception):
        parse_credential_from_yaml(yaml_content)
