"""Tests for credential schema validation."""

import pytest

from exchange_keyshare.schema import SchemaError, validate_credential


class TestValidateCredential:
    def test_valid_minimal_credential(self) -> None:
        """Minimal valid credential with just required fields."""
        data = {
            "version": "1.0",
            "exchange": "binance",
            "credential": {
                "api_key": "test_key",
                "api_secret": "test_secret",
            },
        }
        result = validate_credential(data)
        assert result.exchange == "binance"
        assert result.credential["api_key"] == "test_key"
        assert result.pairs is None
        assert result.labels is None

    def test_valid_full_credential(self) -> None:
        """Full credential with all optional fields."""
        data = {
            "version": "1.0",
            "exchange": "coinbase",
            "credential": {
                "api_key": "test_key",
                "api_secret": "test_secret",
                "passphrase": "test_pass",
            },
            "pairs": ["BTC/USDT", "ETH/USDT"],
            "labels": [
                {"key": "name", "value": "Main Account"},
            ],
        }
        result = validate_credential(data)
        assert result.exchange == "coinbase"
        assert result.pairs == ["BTC/USDT", "ETH/USDT"]
        assert result.labels == [{"key": "name", "value": "Main Account"}]

    def test_missing_version_raises_error(self) -> None:
        data = {
            "exchange": "binance",
            "credential": {"api_key": "k", "api_secret": "s"},
        }
        with pytest.raises(SchemaError, match="missing required field: version"):
            validate_credential(data)

    def test_missing_exchange_raises_error(self) -> None:
        data = {
            "version": "1.0",
            "credential": {"api_key": "k", "api_secret": "s"},
        }
        with pytest.raises(SchemaError, match="missing required field: exchange"):
            validate_credential(data)

    def test_unsupported_exchange_raises_error(self) -> None:
        data = {
            "version": "1.0",
            "exchange": "unknown_exchange",
            "credential": {"api_key": "k", "api_secret": "s"},
        }
        with pytest.raises(SchemaError, match="unsupported exchange"):
            validate_credential(data)

    def test_missing_credential_raises_error(self) -> None:
        data = {
            "version": "1.0",
            "exchange": "binance",
        }
        with pytest.raises(SchemaError, match="missing required field: credential"):
            validate_credential(data)

    def test_missing_api_key_raises_error(self) -> None:
        data = {
            "version": "1.0",
            "exchange": "binance",
            "credential": {"api_secret": "s"},
        }
        with pytest.raises(SchemaError, match="missing required field: credential.api_key"):
            validate_credential(data)

    def test_missing_api_secret_raises_error(self) -> None:
        data = {
            "version": "1.0",
            "exchange": "binance",
            "credential": {"api_key": "k"},
        }
        with pytest.raises(SchemaError, match="missing required field: credential.api_secret"):
            validate_credential(data)

    def test_empty_api_key_raises_error(self) -> None:
        data = {
            "version": "1.0",
            "exchange": "binance",
            "credential": {"api_key": "", "api_secret": "s"},
        }
        with pytest.raises(SchemaError, match="api_key cannot be empty"):
            validate_credential(data)

    def test_empty_api_secret_raises_error(self) -> None:
        data = {
            "version": "1.0",
            "exchange": "binance",
            "credential": {"api_key": "k", "api_secret": "   "},
        }
        with pytest.raises(SchemaError, match="api_secret cannot be empty"):
            validate_credential(data)

    def test_passphrase_required_for_coinbase(self) -> None:
        data = {
            "version": "1.0",
            "exchange": "coinbase",
            "credential": {"api_key": "k", "api_secret": "s"},
        }
        with pytest.raises(SchemaError, match="passphrase required for coinbase"):
            validate_credential(data)

    def test_passphrase_required_for_kucoin(self) -> None:
        data = {
            "version": "1.0",
            "exchange": "kucoin",
            "credential": {"api_key": "k", "api_secret": "s"},
        }
        with pytest.raises(SchemaError, match="passphrase required for kucoin"):
            validate_credential(data)

    def test_passphrase_required_for_bitget(self) -> None:
        data = {
            "version": "1.0",
            "exchange": "bitget",
            "credential": {"api_key": "k", "api_secret": "s"},
        }
        with pytest.raises(SchemaError, match="passphrase required for bitget"):
            validate_credential(data)

    def test_invalid_pairs_type_raises_error(self) -> None:
        data = {
            "version": "1.0",
            "exchange": "binance",
            "credential": {"api_key": "k", "api_secret": "s"},
            "pairs": "BTC/USDT",  # Should be list
        }
        with pytest.raises(SchemaError, match="pairs must be a list"):
            validate_credential(data)

    def test_invalid_labels_type_raises_error(self) -> None:
        data = {
            "version": "1.0",
            "exchange": "binance",
            "credential": {"api_key": "k", "api_secret": "s"},
            "labels": "not a list",
        }
        with pytest.raises(SchemaError, match="labels must be a list"):
            validate_credential(data)

    def test_invalid_label_structure_raises_error(self) -> None:
        data = {
            "version": "1.0",
            "exchange": "binance",
            "credential": {"api_key": "k", "api_secret": "s"},
            "labels": [{"key": "name"}],  # Missing 'value'
        }
        with pytest.raises(SchemaError, match="label must have 'key' and 'value'"):
            validate_credential(data)
