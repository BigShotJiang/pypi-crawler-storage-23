"""Tests for configuration handling."""

from pathlib import Path

import pytest

from exchange_keyshare.config import Config, load_config, save_config


def test_default_config_path(monkeypatch: pytest.MonkeyPatch) -> None:
    """Config path defaults to ~/.config/exchange-keyshare/config.yaml."""
    monkeypatch.setenv("HOME", "/home/testuser")
    monkeypatch.delenv("EXCHANGE_KEYSHARE_CONFIG", raising=False)

    config = Config()
    assert config.config_path == Path("/home/testuser/.config/exchange-keyshare/config.yaml")


def test_config_path_from_env(monkeypatch: pytest.MonkeyPatch) -> None:
    """Config path can be overridden via EXCHANGE_KEYSHARE_CONFIG env var."""
    monkeypatch.setenv("EXCHANGE_KEYSHARE_CONFIG", "/custom/path/config.yaml")

    config = Config()
    assert config.config_path == Path("/custom/path/config.yaml")


def test_load_missing_config_returns_empty(tmp_path: Path) -> None:
    """Loading a missing config file returns empty dict."""
    config_path = tmp_path / "config.yaml"
    data = load_config(config_path)
    assert data == {}


def test_save_and_load_config(tmp_path: Path) -> None:
    """Config can be saved and loaded."""
    config_path = tmp_path / "config.yaml"

    data = {
        "bucket": "test-bucket",
        "region": "us-east-1",
        "stack_name": "exchange-keyshare-stack",
    }

    save_config(config_path, data)
    loaded = load_config(config_path)

    assert loaded == data


def test_save_creates_parent_directories(tmp_path: Path) -> None:
    """Saving config creates parent directories if needed."""
    config_path = tmp_path / "nested" / "dir" / "config.yaml"

    save_config(config_path, {"bucket": "test"})

    assert config_path.exists()
    assert load_config(config_path) == {"bucket": "test"}


def test_save_config_sets_restrictive_permissions(tmp_path: Path) -> None:
    """Config file is created with 0600 permissions."""
    import stat

    config_path = tmp_path / "config.yaml"
    save_config(config_path, {"bucket": "test"})

    mode = config_path.stat().st_mode
    # Check only owner read/write bits are set
    assert mode & stat.S_IRWXU == stat.S_IRUSR | stat.S_IWUSR  # owner rw
    assert mode & stat.S_IRWXG == 0  # no group permissions
    assert mode & stat.S_IRWXO == 0  # no other permissions


def test_config_saves_and_loads_stack_id(tmp_path: Path) -> None:
    """Config can save and load stack_id field."""
    config_path = tmp_path / "config.yaml"

    config = Config(config_path=config_path)
    config.bucket = "test-bucket"
    config.region = "us-east-1"
    config.stack_name = "test-stack"
    config.stack_id = "arn:aws:cloudformation:us-east-1:123456789:stack/test-stack/abc123"
    config.save()

    loaded = Config(config_path=config_path)
    loaded.load()

    assert loaded.stack_id == "arn:aws:cloudformation:us-east-1:123456789:stack/test-stack/abc123"
