from decimal import Decimal

from wbportfolio.models.utils import get_adjusted_shares


def test_get_adjusted_shares():
    assert get_adjusted_shares(Decimal("150"), Decimal("100"), Decimal("200")) == Decimal("75")
