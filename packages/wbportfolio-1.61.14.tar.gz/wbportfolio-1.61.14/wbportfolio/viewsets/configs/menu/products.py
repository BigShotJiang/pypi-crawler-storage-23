from wbcore.menus import ItemPermission, MenuItem

PRODUCTCUSTOMER_MENUITEM = MenuItem(
    label="Product Lists",
    endpoint="wbportfolio:productcustomer-list",
    permission=ItemPermission(method=lambda request: not request.user.is_internal and not request.user.is_superuser),
)
PRODUCT_MENUITEM = MenuItem(
    label="Products",
    endpoint="wbportfolio:product-list",
    permission=ItemPermission(
        method=lambda request: request.user.is_internal, permissions=["wbportfolio.view_product"]
    ),
)
