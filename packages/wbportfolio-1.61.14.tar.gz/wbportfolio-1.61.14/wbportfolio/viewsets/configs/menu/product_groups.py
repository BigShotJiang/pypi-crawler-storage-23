from wbcore.menus import ItemPermission, MenuItem

PRODUCTGROUP_MENUITEM = MenuItem(
    label="Product Groups",
    endpoint="wbportfolio:product_group-list",
    permission=ItemPermission(
        method=lambda request: request.user.is_internal, permissions=["wbportfolio.view_productgroup"]
    ),
)
