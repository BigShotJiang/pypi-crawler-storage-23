from datetime import date

from django.db.models import Exists, OuterRef
from django.dispatch import receiver
from wbcore import filters as wb_filters
from wbcore.signals.filters import add_filters
from wbcrm.filters import AccountFilter
from wbfdm.filters import BaseClassifiedInstrumentFilterSet, ClassificationFilter
from wbfdm.models import InstrumentClassificationThroughModel

from wbportfolio.models import AssetPosition, Claim, Portfolio, Trade


@receiver(add_filters, sender=ClassificationFilter)
def add_portfolio_filter(sender, request=None, *args, **kwargs):
    def _filter_portfolio(queryset, name, value):
        if value:
            try:
                last_position_date = value.assets.latest("date").date
            except AssetPosition.DoesNotExist:
                last_position_date = (
                    AssetPosition.objects.latest("date").date if AssetPosition.objects.exists() else date.today()
                )
            invested_instruments = AssetPosition.get_invested_instruments(last_position_date, portfolio=value)
            rels = InstrumentClassificationThroughModel.objects.filter(
                instrument__in=invested_instruments.values("root")
            )
            return queryset.filter(id__in=rels.values("classification"))
        return queryset

    def _filter_invested(queryset, name, value):
        if value:
            last_position_date = (
                AssetPosition.objects.latest("date").date if AssetPosition.objects.exists() else date.today()
            )
            invested_instruments = AssetPosition.get_invested_instruments(last_position_date)
            rels = InstrumentClassificationThroughModel.objects.filter(
                instrument__in=invested_instruments.values("root")
            )
            return queryset.filter(id__in=rels.values("classification"))
        return queryset

    return {
        "portfolio": wb_filters.ModelChoiceFilter(
            label="Associated Portfolio",
            queryset=Portfolio.objects.all(),
            endpoint=Portfolio.get_representation_endpoint(),
            value_key=Portfolio.get_representation_value_key(),
            label_key=Portfolio.get_representation_label_key(),
            method=_filter_portfolio,
        ),
        "only_invested": wb_filters.BooleanFilter(
            label="Only invested instruments (anytime)",
            method=_filter_invested,
        ),
    }


@receiver(add_filters, sender=BaseClassifiedInstrumentFilterSet)
def add_classification_instrument_filter(sender, request=None, *args, **kwargs):
    def _filter_invested(queryset, name, value):
        if value:
            last_invested_date = (
                AssetPosition.objects.latest("date").date if AssetPosition.objects.exists() else date.today()
            )
            invested_instruments = AssetPosition.get_invested_instruments(last_invested_date)
            return queryset.filter(Exists(invested_instruments.filter(root=OuterRef("instrument"))))
        return queryset

    return {
        "only_invested": wb_filters.BooleanFilter(
            method=_filter_invested, label="Invested Instruments (last date)", initial=False
        )
    }


@receiver(add_filters, sender=AccountFilter)
def add_claim_filter(sender, request=None, *args, **kwargs):
    def _filter_trade_invested_in(queryset, name, value):
        if value:
            claims = Claim.objects.filter(trade=value).exclude(status=Claim.Status.WITHDRAWN)
            return queryset.filter(id__in=claims.values("account"))
        return queryset

    return {
        "trade_invested_in": wb_filters.ModelChoiceFilter(
            hidden=True,
            queryset=Trade.objects.all(),
            endpoint=Trade.get_representation_endpoint(),
            value_key=Trade.get_representation_value_key(),
            label_key=Trade.get_representation_label_key(),
            method=_filter_trade_invested_in,
            label="Trade Invested",
        )
    }
