"""Tightwad: Mixed-vendor GPU inference cluster manager with speculative decoding."""

__version__ = "0.1.3"
