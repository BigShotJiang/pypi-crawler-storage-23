"""
面向对象封装：

- Demoboard：继承 SerialDevice，并增加显示回显（display）、日志记录和高层方法（shell, check_alive）；
- Relay：继承 SerialDevice，仅保留基础串口能力。
"""

from __future__ import annotations

import re
import sys
from typing import Generator, Iterable, List, Literal, Optional, Union

from loguru import logger

from .core import SerialDevice
from .demoboard import check_alive as _check_alive_func
from .demoboard import shell as _shell_func

# 配色方案（仅用于 Demoboard 显示）
_GREY = "\033[90m"
_GREEN = "\033[32m"
_YELLOW = "\033[33m"
_RESET = "\033[0m"

# ANSI 颜色转义正则
_ANSI_ESCAPE_RE = re.compile(r"\x1b\[[0-9;]*m")


class Demoboard(SerialDevice):
    """
    Demoboard 设备：
    - 具备完整的显示回显和着色能力；
    - 提供 shell() / check_alive() 等交互式方法。
    """

    def __init__(self, port: str, baudrate: int = 115200, check_alive: bool = True):
        super().__init__(port, baudrate)
        self._auto_check_alive = check_alive
        self._display = True
        self._last_output_ends_with_newline = True

    def connect(self) -> None:
        """连接并自动执行 check_alive。"""
        if self._is_connected:
            return
        super().connect()
        if self._auto_check_alive:
            self.check_alive()

    # --- 高级显示与日志逻辑 (重写基类接口) ---

    def _write_raw(self, text: str) -> None:
        """重写：增加终端输出。silence 模式下不输出任何内容。"""
        if self._silent:
            return
        if text:
            self._last_output_ends_with_newline = text.endswith("\n")
            sys.stdout.write(text)
            sys.stdout.flush()

    def _ensure_newline(self) -> None:
        """重写：增加自动补全换行逻辑。silence 模式下不输出任何内容。"""
        if self._silent:
            return
        if not self._last_output_ends_with_newline:
            sys.stdout.write("\n")
            sys.stdout.flush()
            self._last_output_ends_with_newline = True

    def silence(self) -> None:
        """执行后不再输出任何日志及终端回显（info/success/warning/error 与 _write_raw/_ensure_newline 均为空操作）。"""
        super().silence()

    def info(self, msg: str) -> None:
        if self._silent:
            return
        self._ensure_newline()
        logger.info(msg)

    def success(self, msg: str) -> None:
        if self._silent:
            return
        self._ensure_newline()
        logger.success(msg)

    def warning(self, msg: str) -> None:
        if self._silent:
            return
        self._ensure_newline()
        logger.warning(msg)

    def error(self, msg: str) -> None:
        if self._silent:
            return
        self._ensure_newline()
        logger.error(msg)

    def _echo_normal(self, line: str) -> None:
        self._write_raw(f"{_GREY}{line}{_RESET}")

    def display(
        self,
        lines: Iterable[str],
        flag: Optional[str] = None,
        flag_type: Optional[Literal["end_flag", "prompt"]] = None,
        raw_color: bool = False,
    ) -> Generator[str, None, None]:
        """重写：增加局部着色回显。"""
        for line in lines:
            if self._display:
                if raw_color:
                    self._write_raw(line)
                elif flag is None:
                    self._echo_normal(line)
                else:
                    # 高亮模式：仅对匹配到的 flag 部分加色
                    plain = _ANSI_ESCAPE_RE.sub("", line)
                    if flag and flag in plain:
                        parts = plain.split(flag, 1)
                        # 如果是 prompt (输入命令回显)，使用 Yellow；如果是 end_flag (提示符)，使用 Green
                        color = _GREEN if flag_type == "end_flag" else _YELLOW
                        formatted = f"{_GREY}{parts[0]}{_RESET}{color}{flag}{_RESET}{_GREY}{parts[1]}{_RESET}"
                        self._write_raw(formatted)
                    else:
                        self._echo_normal(plain)
            yield line

    # --- 高层业务方法 ---

    def shell(
        self,
        cmd: str,
        *,
        prompt_flag: str = " #",
        timeout: Optional[float] = None,
        stream: bool = False,
    ) -> Union[List[str], Generator[str, None, None]]:
        return _shell_func(self, cmd, prompt_flag=prompt_flag, timeout=timeout, stream=stream)

    def execute_command(
        self,
        cmd: str,
        flag: str = " #",
        timeout: Optional[float] = None,
        stream: bool = False,
    ) -> Union[List[str], Generator[str, None, None]]:
        """兼容旧版签名的 shell 别名。"""
        return self.shell(cmd, prompt_flag=flag, timeout=timeout, stream=stream)

    def check_alive(
        self,
        *,
        uboot_flag: str = "uboot#",
        prompt_flag: str = " #",
        timeout: float = 2.0,
        block: bool = True,
    ) -> None:
        _check_alive_func(
            self,
            uboot_flag=uboot_flag,
            prompt_flag=prompt_flag,
            timeout=timeout,
            block=block,
        )

    def __exit__(self, exc_type, exc_value, traceback) -> None:
        super().__exit__(exc_type, exc_value, traceback)
        self._ensure_newline()


class Relay(SerialDevice):
    """
    继电器设备：仅继承基础串口能力，不具备 Demoboard 的显示回显功能。
    """

    def __init__(self, port: str, baudrate: int = 115200, **kwargs):
        kwargs.pop("check_alive", None)
        super().__init__(port, baudrate)


__all__ = ["Demoboard", "Relay"]
