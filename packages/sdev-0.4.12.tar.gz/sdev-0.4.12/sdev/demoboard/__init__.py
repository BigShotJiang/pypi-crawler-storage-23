"""
Demoboard 顶层导出：

- 函数式 API：shell, check_alive
"""

from .functional import check_alive, shell

__all__ = ["shell", "check_alive"]

