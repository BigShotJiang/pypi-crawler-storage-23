# Repo Flow Analyzer

A universal tool to analyze and visualize code flow in any repository, helping developers understand functionality by searching for keywords.

## 🎯 Features

- **Multi-Language Support**: Works with Java, Python, JavaScript/TypeScript, Go, C#, and more
- **Multiple Output Formats**: Markdown, Mermaid diagrams, and JSON
- **Customizable**: Configure component patterns, exclusions, and output preferences
- **Repository Agnostic**: Works with any codebase structure
- **Fast & Efficient**: Handles large repositories with smart file filtering

## 📦 Installation

### Via pip (recommended)

```bash
pip install repo-flow-analyzer
```

### From source

```bash
git clone https://github.com/yourorg/repo-flow-analyzer.git
cd repo-flow-analyzer
pip install -e .
```

## 🚀 Quick Start

### Basic Usage

```bash
# Analyze credit-related functionality
flow-analyzer credit

# Search for user authentication flow
flow-analyzer authentication

# Find payment processing components
flow-analyzer payment
```

### Generate Visual Diagrams

```bash
# Create a Mermaid diagram
flow-analyzer credit --format=mermaid --output=credit-flow.mmd

# Generate markdown documentation
flow-analyzer user --format=markdown --output=docs/user-flow.md

# Export as JSON for custom processing
flow-analyzer api --format=json --output=api-analysis.json
```

### Custom Configuration

```bash
# Generate a configuration template
flow-analyzer --init

# Use custom config
flow-analyzer credit --config=.flow-analyzer.yaml
```

## 📖 Documentation

### Command Line Options

```
Usage: flow-analyzer [OPTIONS] KEYWORD

Arguments:
  KEYWORD  The search term to find in your codebase

Options:
  -f, --format [markdown|mermaid|json]  Output format (default: markdown)
  -o, --output PATH                      Output file (default: stdout)
  -c, --config PATH                      Path to custom config file
  -p, --base-path PATH                   Base path of the repository (default: .)
  --version                              Show version
  --help                                 Show this message
```

### Configuration File

Create a `.flow-analyzer.yaml` in your project root:

```yaml
languages:
  java:
    extensions: [".java"]
    component_patterns:
      controller: ["controller", "resource"]
      service: ["service", "manager"]
      repository: ["repository", "dao"]
      
analysis:
  max_files: 10000
  exclude_patterns:
    - "**/node_modules/**"
    - "**/target/**"
    - "**/.git/**"
    
output:
  mermaid:
    max_nodes: 50
    color_scheme:
      controller: "#e1f5ff"
      service: "#f3e5f5"
```

## 🎨 Output Formats

### Markdown
- Human-readable documentation
- Organized by component type
- Includes file paths, methods, and dependencies
- Perfect for README files and documentation

### Mermaid
- Visual flow diagrams
- Color-coded components
- Shows relationships between layers
- Renders in GitHub, GitLab, and Confluence

### JSON
- Machine-readable format
- Complete component metadata
- Ideal for custom integrations
- Can be processed by other tools

## 💡 Use Cases

### For New Developers
"I need to understand how the payment system works"
```bash
flow-analyzer payment --format=mermaid --output=payment-flow.mmd
```

### For Code Reviews
"What components does this feature affect?"
```bash
flow-analyzer feature-name --format=markdown
```

### For Documentation
"Generate architecture diagrams for documentation"
```bash
flow-analyzer core --format=mermaid --output=docs/architecture.mmd
```

### For Debugging
"Where is Kafka used in the application?"
```bash
flow-analyzer kafka --format=json
```

## 🔧 Supported Languages

- **Java**: Controllers, Services, DAOs, Entities
- **Python**: Views, Services, Repositories, Models
- **JavaScript/TypeScript**: Components, Services, Routes
- **Go**: Handlers, Services, Repositories
- **C#**: Controllers, Services, Repositories

## 🤝 Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

### Development Setup

```bash
git clone https://github.com/yourorg/repo-flow-analyzer.git
cd repo-flow-analyzer
pip install -e ".[dev]"
```

### Running Tests

```bash
pytest tests/
```

## 📄 License

MIT License - see LICENSE file for details

## 🙏 Acknowledgments

Built for multi-team collaboration in monorepo environments.

## 📞 Support

- Issues: https://github.com/yourorg/repo-flow-analyzer/issues
- Discussions: https://github.com/yourorg/repo-flow-analyzer/discussions
- Documentation: https://repo-flow-analyzer.readthedocs.io

---

Made with ❤️ for developers who want to understand code faster