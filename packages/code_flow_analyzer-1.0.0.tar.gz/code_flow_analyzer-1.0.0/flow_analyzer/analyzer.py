"""
Core Flow Analyzer implementation - Universal code flow analysis
"""

import re
from pathlib import Path
from typing import Dict, List, Optional, Set
from collections import defaultdict
from .config import Config

class FlowAnalyzer:
    """Universal code flow analyzer for any programming language"""
    
    def __init__(self, base_path: str = ".", config: Optional[Config] = None):
        """Initialize the analyzer
        
        Args:
            base_path: Base directory of the repository
            config: Optional Config object
        """
        self.base_path = Path(base_path).resolve()
        self.config = config or Config()
        self.flow_data = None
        
    def analyze(self, keyword: str) -> Dict:
        """Analyze code flow for the given keyword
        
        Args:
            keyword: Search keyword
            
        Returns:
            Dictionary containing analysis results
        """
        print(f"🔍 Analyzing flow for keyword: '{keyword}'...")
        
        try:
            # Find all matching files
            matching_files = self._find_files_by_keyword(keyword)
            print(f"Found {len(matching_files)} matching files")
            
            # Analyze each file
            components = self._categorize_components(matching_files)
        except Exception as e:
            print(f"Error during analysis: {e}")
            import traceback
            traceback.print_exc()
            raise
        
        # Build flow data
        self.flow_data = {
            "keyword": keyword,
            "total_files": len(matching_files),
            "components": components,
            "flow_summary": self._build_flow_summary(components)
        }
        
        return self.flow_data
    
    def _find_files_by_keyword(self, keyword: str) -> List[Dict]:
        """Find all source files containing the keyword"""
        matching_files = []
        keyword_pattern = re.compile(re.escape(keyword), re.IGNORECASE)
        
        # Get all supported extensions
        all_extensions = set()
        for lang_config in self.config.get("languages", {}).values():
            all_extensions.update(lang_config.get("extensions", []))
        
        # Search through repository
        max_files = self.config.get("analysis", "max_files", default=10000)
        max_size_bytes = self.config.get("analysis", "max_file_size_mb", default=10) * 1024 * 1024
        
        for source_file in self.base_path.rglob("*"):
            if len(matching_files) >= max_files:
                break
                
            if not source_file.is_file():
                continue
                
            if source_file.suffix not in all_extensions:
                continue
                
            if self.config.is_excluded(source_file, self.base_path):
                continue
            
            try:
                # Check file size
                if source_file.stat().st_size > max_size_bytes:
                    continue
                    
                content = source_file.read_text(encoding='utf-8', errors='ignore')
                if keyword_pattern.search(content):
                    lang_config = self.config.get_language_config(source_file.suffix)
                    if lang_config:
                        info = self._extract_file_info(source_file, content, lang_config)
                        if info:
                            matching_files.append(info)
            except Exception as e:
                # Skip files that can't be read
                continue
        
        return matching_files
    
    def _extract_file_info(self, file_path: Path, content: str, lang_config: Dict) -> Optional[Dict]:
        """Extract information from a source file"""
        info = {
            "file": str(file_path.relative_to(self.base_path)),
            "language": lang_config["name"],
            "type": self._determine_component_type(file_path, lang_config),
            "class_name": "",
            "methods": [],
            "dependencies": [],
            "annotations": []
        }
        
        # Extract class/struct name
        class_pattern = lang_config.get("class_pattern") or lang_config.get("struct_pattern")
        if class_pattern:
            class_match = re.search(class_pattern, content)
            if class_match:
                info["class_name"] = class_match.group(1)
        
        # Extract methods/functions
        method_pattern = lang_config.get("method_pattern")
        if method_pattern:
            try:
                methods = re.findall(method_pattern, content)
                max_methods = self.config.get("analysis", "max_methods_display", default=15)
                # Handle tuples from regex groups - convert to strings
                processed_methods = []
                for m in methods[:max_methods]:
                    if isinstance(m, str):
                        processed_methods.append(m)
                    elif isinstance(m, tuple):
                        # Take first non-empty string from tuple
                        method_name = next((x for x in m if x and isinstance(x, str)), "")
                        if method_name:
                            processed_methods.append(method_name)
                    # Ignore other types (dict, list, etc.)
                info["methods"] = processed_methods
            except Exception:
                info["methods"] = []
        
        # Extract imports/dependencies (language-specific)
        import_pattern = lang_config.get("import_pattern") or lang_config.get("using_pattern")
        if import_pattern:
            try:
                imports = re.findall(import_pattern, content)
                max_deps = self.config.get("analysis", "max_dependencies_display", default=20)
                # Ensure all dependencies are strings
                processed_deps = []
                for imp in imports[:max_deps]:
                    if isinstance(imp, str):
                        processed_deps.append(imp)
                    elif isinstance(imp, tuple):
                        dep_str = next((x for x in imp if x and isinstance(x, str)), "")
                        if dep_str:
                            processed_deps.append(dep_str)
                    # Ignore other types (dict, list, etc.)
                info["dependencies"] = processed_deps
            except Exception:
                info["dependencies"] = []
        
        # Extract annotations (Java, C#, Python decorators)
        annotation_pattern = lang_config.get("annotation_pattern")
        if annotation_pattern:
            try:
                annotations = re.findall(annotation_pattern, content)
                # Ensure annotations are strings and deduplicate
                str_annotations = []
                for ann in annotations:
                    if isinstance(ann, str):
                        str_annotations.append(ann)
                    elif isinstance(ann, tuple):
                        ann_str = next((x for x in ann if x and isinstance(x, str)), "")
                        if ann_str:
                            str_annotations.append(ann_str)
                    # Ignore any other types (dict, list, etc.)
                # Use set only on strings, avoid unhashable types
                unique_annotations = []
                seen = set()
                for ann in str_annotations:
                    if ann not in seen:
                        seen.add(ann)
                        unique_annotations.append(ann)
                info["annotations"] = unique_annotations[:10]
            except Exception:
                # If annotation extraction fails, just skip it
                info["annotations"] = []
        
        return info
    
    def _determine_component_type(self, file_path: Path, lang_config: Dict) -> str:
        """Determine the type of component based on file path and name"""
        path_str = str(file_path).lower()
        file_name = file_path.stem.lower()
        
        component_patterns = lang_config.get("component_patterns", {})
        
        # Check path and filename against patterns
        for comp_type, patterns in component_patterns.items():
            for pattern in patterns:
                if pattern in path_str or pattern in file_name:
                    return comp_type.capitalize()
        
        return "Utility"
    
    def _categorize_components(self, files: List[Dict]) -> Dict:
        """Categorize files by component type"""
        components = defaultdict(list)
        
        for file_info in files:
            comp_type = file_info["type"].lower()
            components[comp_type].append(file_info)
        
        return dict(components)
    
    def _build_flow_summary(self, components: Dict) -> List[str]:
        """Build a simple flow summary"""
        summary = []
        
        # Define the typical flow order
        flow_order = [
            ("controller", "🌐 API Entry Points (Controllers)"),
            ("service", "⚙️ Business Logic (Services)"),
            ("repository", "💾 Data Access (Repositories/DAOs)"),
            ("connector", "🔌 External Integrations (Connectors)"),
            ("consumer", "📬 Message Consumers"),
            ("producer", "📤 Message Producers"),
        ]
        
        for comp_key, comp_title in flow_order:
            if comp_key in components and components[comp_key]:
                summary.append(f"\n{comp_title}")
                for comp in components[comp_key][:10]:  # Show first 10
                    class_name = comp.get("class_name") or Path(comp["file"]).stem
                    methods_str = ""
                    if comp.get("methods"):
                        # Ensure all methods are strings
                        str_methods = [str(m) for m in comp['methods'] if m]
                        if str_methods:
                            methods_str = f": {', '.join(str_methods[:3])}"
                            if len(str_methods) > 3:
                                methods_str += "..."
                    summary.append(f"  → {class_name}{methods_str}")
                    
                if len(components[comp_key]) > 10:
                    summary.append(f"  ... and {len(components[comp_key]) - 10} more")
        
        return summary
    
    def get_statistics(self) -> Dict:
        """Get analysis statistics"""
        if not self.flow_data:
            return {}
        
        stats = {
            "total_files": self.flow_data["total_files"],
            "components_by_type": {}
        }
        
        for comp_type, files in self.flow_data["components"].items():
            stats["components_by_type"][comp_type] = len(files)
        
        return stats