from collections import defaultdict
import time
import uuid

class PrettyHospitalMap:
    def __init__(self):
        self.nodes = set()
        self.edges = defaultdict(list)
        self.receipts = []

    def add_node(self, node, emoji=None):
        self.nodes.add(node)
        if emoji:
            self.nodes.add(f"{emoji} {node}")

    def connect(self, a, b, relation, observer="System", icon="→"):
        edge_id = str(uuid.uuid4())
        ts = int(time.time())
        self.edges[a].append((b, relation, icon, edge_id))
        self.edges[b].append((a, relation, icon, edge_id))
        receipt = {
            "edge_id": edge_id,
            "from": a,
            "to": b,
            "relation": relation,
            "timestamp": ts,
            "observer": observer,
            "icon": icon
        }
        self.receipts.append(receipt)

    def section(self, title, char="═"):
        bar = char * 78
        print(f"\n{bar}\n║ {title.center(74)} ║\n{bar}")

    def show_patient_journey(self, patient, steps):
        self.section(f"🦴 Orthopaedic Surgery Case – Patient: {patient}")
        for i, (stage, details) in enumerate(steps, 1):
            print(f"\n  {i}. {stage}")
            for line in details:
                print(f"      {line}")

    def show_connections(self, node, depth=1, visited=None, layer=0):
        if visited is None:
            visited = set()
        indent = "    " * layer
        if node in visited or layer > depth:
            return
        visited.add(node)
        print(f"{indent}- {node}")
        for neighbor, relation, icon, edge_id in self.edges[node]:
            print(f"{indent}    {icon} [{relation}] {neighbor}")
            self.show_connections(neighbor, depth, visited, layer + 1)

    def print_receipts(self, filter_by=None):
        self.section("🗂 AUDIT TRAIL")
        for r in self.receipts:
            if filter_by and (r['from'] != filter_by and r['to'] != filter_by):
                continue
            print(f"  {r['observer']}: {r['from']} {r['icon']}[{r['relation']}]{r['icon']} {r['to']} (edge: {r['edge_id'][:8]}) @ {r['timestamp']}")

# === Example: Ortho Knee Replacement, Dr. Yiannis Pappou ===
if __name__ == "__main__":
    h = PrettyHospitalMap()

    # Core nodes (roles, entities, devices, family, with icons)
    h.add_node("Dr. Yiannis Pappou (Ortho Surgeon)", "🩺")
    h.add_node("OR #2", "🏥")
    h.add_node("Patient: Michael Reyes", "🧑‍🦽")
    h.add_node("Nurse: Jasmine", "👩‍⚕️")
    h.add_node("PA: Mark", "🧑‍⚕️")
    h.add_node("Device: Stryker Drill", "🔧")
    h.add_node("Implant: Zimmer Knee", "🦵")
    h.add_node("Order: Pre-op Labs", "🧪")
    h.add_node("Order: Post-op X-ray", "📸")
    h.add_node("Bed #14", "🛏️")
    h.add_node("Family: Linda Reyes", "👩")
    h.add_node("Insurance: UnitedHealth", "💳")
    h.add_node("Admin: Carla", "👩‍💼")
    h.add_node("Physical Therapy", "🏃")
    h.add_node("Pharmacy", "💊")
    h.add_node("Anesthesiologist: Dr. Chen", "🧑‍🔬")
    h.add_node("Rep: Stryker Field Tech", "🔩")

    # Map workflow, using icons for easy scanning
    h.connect("Dr. Yiannis Pappou (Ortho Surgeon)", "OR #2", "scheduled_in", "OR Scheduler", "🏥")
    h.connect("Patient: Michael Reyes", "OR #2", "surgery_performed_in", "Charge Nurse", "🔪")
    h.connect("Patient: Michael Reyes", "Bed #14", "post_op_bed", "Bed Manager", "🛏️")
    h.connect("Dr. Yiannis Pappou (Ortho Surgeon)", "Patient: Michael Reyes", "performed_surgery_on", "Hospital IT", "🦴")
    h.connect("Nurse: Jasmine", "Patient: Michael Reyes", "perioperative_care", "OR Nurse", "👩‍⚕️")
    h.connect("PA: Mark", "Patient: Michael Reyes", "assisted_in_surgery", "OR Log", "🧑‍⚕️")
    h.connect("Anesthesiologist: Dr. Chen", "Patient: Michael Reyes", "provided_anesthesia_for", "Anesthesia Record", "💉")
    h.connect("Device: Stryker Drill", "OR #2", "used_in_room", "Biomed", "🔧")
    h.connect("Implant: Zimmer Knee", "Patient: Michael Reyes", "implanted_in", "Device Traceability", "🦵")
    h.connect("Order: Pre-op Labs", "Patient: Michael Reyes", "ordered_for", "Dr. Yiannis Pappou (Ortho Surgeon)", "🧪")
    h.connect("Order: Post-op X-ray", "Patient: Michael Reyes", "ordered_for", "PA: Mark", "📸")
    h.connect("Family: Linda Reyes", "Patient: Michael Reyes", "emergency_contact_for", "Admin: Carla", "👩")
    h.connect("Patient: Michael Reyes", "Insurance: UnitedHealth", "insured_by", "Admin: Carla", "💳")
    h.connect("Patient: Michael Reyes", "Physical Therapy", "discharged_to", "Case Manager", "🏃")
    h.connect("Pharmacy", "Patient: Michael Reyes", "dispensed_meds_to", "Pharmacy Tech", "💊")
    h.connect("Rep: Stryker Field Tech", "Device: Stryker Drill", "serviced_device", "Biomed", "🔩")

    # Show patient journey in a clear, stepwise format
    patient_journey = [
        ("Admission & Pre-op", [
            "Patient Michael Reyes admitted, insurance verified.",
            "Labs drawn, family notified, pre-op checklist completed.",
        ]),
        ("Surgery", [
            "Brought to OR #2, anesthesia by Dr. Chen.",
            "Stryker Drill and Zimmer Knee implant prepped.",
            "Surgery performed by Dr. Yiannis Pappou (assisted by PA Mark and Nurse Jasmine).",
        ]),
        ("Post-op", [
            "Transferred to Bed #14, post-op x-ray ordered.",
            "Pain meds dispensed, case reviewed by pharmacy.",
        ]),
        ("Rehab & Discharge", [
            "Physical therapy initiated.",
            "Family given discharge education, patient released when stable.",
        ]),
    ]
    h.show_patient_journey("Michael Reyes", patient_journey)

    # Section: Relationships Web
    h.section("🕸️ INTERCONNECTEDNESS MAP")
    h.show_connections("Patient: Michael Reyes", depth=2)

    # Section: Audit Trail
    h.print_receipts(filter_by="Dr. Yiannis Pappou (Ortho Surgeon)")