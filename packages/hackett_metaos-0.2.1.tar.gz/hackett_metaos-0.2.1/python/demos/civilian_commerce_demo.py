import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from ledger import Ledger
import time

ledger = Ledger()
print("═════════════════════════════════════════════════════════════════════════════")
print("║ HACKETT META OS - CIVILIAN COMMERCE TRANSACTION DEMO")
print("═════════════════════════════════════════════════════════════════════════════\n")

ts = int(time.time())

ledger.log_event(f"Purchase initiated at {ts}, Store: TampaMart, POS #17, Customer: 302149", observer_id="POS_System")
ledger.log_event(f"Payment processed at {ts+1}, Method: Visa, Amount: $78.44", observer_id="PaymentGateway")
ledger.log_nullreceipt(f"Loyalty discount not applied at {ts+2}, System error", observer_id="PromoEngine")
ledger.log_event(f"Receipt issued at {ts+3}, ReceiptID: TM-2026-88217", observer_id="POS_System")
ledger.log_event(f"Return processed at {ts+4}, Item: SKU#2338, Reason: Defective", observer_id="ReturnsDesk")
ledger.compress_ledger()
ledger.audit()

print("\n═════════════════════════════════════════════════════════════════════════════")
print("║ 🛒 CIVILIAN COMMERCE VALUE")
print("═════════════════════════════════════════════════════════════════════════════")
print("✓ Every purchase, payment, omission, and return cryptographically receipted")
print("✓ NullReceipts flag missed promos, fraud attempts, or POS glitches")
print("✓ Instant audit/export for regulators, banks, and customer disputes")
print("✓ Tamper-proof, receipts-native commerce for retail, e-comm, POS, and more")
print("✓ Reduces fraud, chargebacks, and compliance costs at scale")
print("═════════════════════════════════════════════════════════════════════════════")