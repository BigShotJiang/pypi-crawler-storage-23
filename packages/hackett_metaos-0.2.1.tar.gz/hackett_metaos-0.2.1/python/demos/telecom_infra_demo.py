import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from ledger import Ledger
import time

ledger = Ledger()
print("═════════════════════════════════════════════════════════════════════════════")
print("║ HACKETT META OS - TELECOM INFRASTRUCTURE RECEIPTS DEMO")
print("═════════════════════════════════════════════════════════════════════════════\n")

ts = int(time.time())

ledger.log_event(f"Call initiated at {ts}, Orig: 212-555-1234, Dest: 415-555-6789", observer_id="CoreSwitch01")
ledger.log_event(f"Routing through backbone, Node: NY-Metro", observer_id="BackboneRouter")
ledger.log_event(f"Compression engine activated: 72% size reduction", observer_id="CompressionModule")
ledger.log_nullreceipt(f"Packet loss detected at {ts+1}, Segment: NY → Chicago", observer_id="QoSMonitor")
ledger.log_event(f"Auto-retransmit triggered, alt route: NY → Atlanta → SF", observer_id="RoutingAI")
ledger.log_event(f"Call completed at {ts+2}, Duration: 241s, MOS: 4.8", observer_id="EdgeSwitch_SF")

ledger.compress_ledger()
ledger.audit()

print("\n═════════════════════════════════════════════════════════════════════════════")
print("║ 📡 TELECOM INDUSTRY VALUE")
print("═════════════════════════════════════════════════════════════════════════════")
print("✓ Every call, route, packet loss, and recovery cryptographically receipted")
print("✓ NullReceipts catch outages and fraud attempts in real-time")
print("✓ Compression events: multi-million $ annual storage/bandwidth savings")
print("✓ One-click, receipts-native CDR/audit for FCC, SEC, internal review")
print("✓ Tamper-proof, global comms audit (prevents call spoofing, toll fraud, etc.)")
print("═════════════════════════════════════════════════════════════════════════════")