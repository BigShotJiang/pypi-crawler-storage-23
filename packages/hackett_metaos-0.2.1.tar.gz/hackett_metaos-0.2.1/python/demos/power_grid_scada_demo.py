import sys, os, time
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from ledger import Ledger

ledger = Ledger()
print("═════════════════════════════════════════════════════════════════════════════")
print("║ HACKETT META OS - POWER GRID SCADA EVENT AUDIT DEMO")
print("═════════════════════════════════════════════════════════════════════════════\n")

ts = int(time.time())
ledger.log_event(f"SCADA command: load-shed at {ts}, Substation: Tampa-07", observer_id="GridOperator")
ledger.log_event(f"Breaker tripped at {ts+1}, Cause: Overcurrent", observer_id="RemoteRelay")
ledger.log_nullreceipt(f"Telemetry loss at {ts+2}, RTU offline", observer_id="SCADAMonitor")
ledger.log_event(f"Grid balance restored at {ts+3}, all circuits nominal", observer_id="ControlCenter")
ledger.log_event(f"Event archive sent to NERC at {ts+4}", observer_id="AuditSystem")
ledger.compress_ledger()
ledger.audit()

print("\n═════════════════════════════════════════════════════════════════════════════")
print("║ ⚡️ POWER GRID / SCADA VALUE")
print("═════════════════════════════════════════════════════════════════════════════")
print("✓ Every SCADA command, telemetry gap, and breaker event cryptographically receipted")
print("✓ NullReceipts for RTU loss/telemetry gaps = anti-tamper, blackouts, cyber-physical attacks")
print("✓ Tamper-proof audit for NERC/FERC, state regulators, and insurance")
print("✓ One-click compliance and post-incident review")
print("═════════════════════════════════════════════════════════════════════════════")