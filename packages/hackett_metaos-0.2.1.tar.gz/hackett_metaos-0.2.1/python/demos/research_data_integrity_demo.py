import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from ledger import Ledger
import time

ledger = Ledger()
print("═════════════════════════════════════════════════════════════════════════════")
print("║ HACKETT META OS - RESEARCH DATA INTEGRITY DEMO")
print("═════════════════════════════════════════════════════════════════════════════\n")

ts = int(time.time())

ledger.log_event(f"Experiment registered at {ts}, Project: Quantum Entanglement Study", observer_id="LabManager")
ledger.log_event(f"Trial 1: entangled pairs observed, result: positive correlation", observer_id="Researcher_01")
ledger.log_nullreceipt(f"Trial 2: data missing, instrument error at {ts+1}", observer_id="QualityControl")
ledger.log_event(f"Trial 3: control group, result: null", observer_id="Researcher_02")
ledger.log_event(f"Final report submitted at {ts+2}, all raw data hashed and archived", observer_id="PI_Dr_Smith")
ledger.compress_ledger()
ledger.audit()

print("\n═════════════════════════════════════════════════════════════════════════════")
print("║ 🧪 RESEARCH DATA INTEGRITY VALUE")
print("═════════════════════════════════════════════════════════════════════════════")
print("✓ Every experiment, observation, and omission cryptographically receipted")
print("✓ NullReceipts make data fabrication structurally impossible")
print("✓ Audit trail for journals, funders, and peer reviewers")
print("✓ Tamper-proof chain for open science and replication")
print("✓ Empowers reproducible, trustworthy scientific progress")
print("═════════════════════════════════════════════════════════════════════════════")