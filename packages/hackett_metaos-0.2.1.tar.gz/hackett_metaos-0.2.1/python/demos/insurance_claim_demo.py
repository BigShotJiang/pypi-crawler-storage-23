import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from ledger import Ledger
import time

# ANSI color and style codes for beautiful output
BOLD = "\033[1m"
END = "\033[0m"
GREEN = "\033[92m"
YELLOW = "\033[93m"
RED = "\033[91m"
CYAN = "\033[96m"
GRAY = "\033[90m"
BOX = "═" * 78

def print_header(title):
    print(f"\n{CYAN}{BOX}{END}")
    print(f"{CYAN}║{END} {BOLD}{title}{END}")
    print(f"{CYAN}{BOX}{END}")

def print_section(title, icon=""):
    print(f"\n{CYAN}{BOX}\n║{END} {BOLD}{icon} {title}{END}\n{CYAN}{BOX}{END}")

def print_event(msg, receipt_id, sig, observer, is_omission=False):
    color = RED if is_omission else GREEN
    prefix = "✗" if is_omission else "✓"
    who = f"{GRAY}Observer: {observer}{END}"
    print(f"{color}{prefix} {msg}{END}   {who}")
    print(f"{GRAY}    Receipt ID: {receipt_id} | Sig: {sig[:12]}...{END}")

def print_audit(ledger):
    print_section("AUDIT SUMMARY", "🗂")
    compressed = ledger.compress_ledger()
    print(f"{CYAN}Audit trail compressed: {len(compressed)} bytes{END}")
    print(f"{CYAN}Events: {len(ledger.events)} | Omissions: {len(ledger.nullreceipts)}{END}")

def print_benefits():
    print_section("INSURANCE & LEGAL VALUE", "💼")
    print(f"{BOLD}✓{END} Every claim event and omission is cryptographically receipted")
    print(f"{BOLD}✓{END} Omission detection prevents fraud and missing documentation")
    print(f"{BOLD}✓{END} Instant audit trail for adjusters, underwriters, and legal review")
    print(f"{BOLD}✓{END} Tamper/backdate resistant, insurance-grade compliance")
    print(f"{BOLD}✓{END} One-click, enterprise-class claims audit export")
    print(f"{CYAN}{BOX}{END}")

if __name__ == "__main__":
    print_header("HACKETT META OS - INSURANCE CLAIM DEMO")
    print_section("CLAIMS WORKFLOW", "📝")
    ledger = Ledger()
    ts = int(time.time())

    # Step 1: Claim submitted
    claim = f"Auto claim submitted at {ts} for rear-end collision"
    r1 = ledger.log_event(claim, observer_id="Customer")
    print_event(claim, r1['event_id'], r1['sig'], r1['observer'])

    # Step 2: Photo evidence uploaded
    evidence = f"Photo evidence uploaded at {ts+1} (3 photos, location geotagged)"
    r2 = ledger.log_event(evidence, observer_id="MobileApp")
    print_event(evidence, r2['event_id'], r2['sig'], r2['observer'])

    # Step 3: Omission - Missing police report
    omission = f"Police report missing at {ts+2}"
    nr = ledger.log_nullreceipt(omission, observer_id="ComplianceBot")
    print_event(omission, nr['event_id'], nr['sig'], nr['observer'], is_omission=True)

    # Step 4: Adjuster review/override
    review = f"Adjuster review completed at {ts+3}, override: proceed without police report"
    r3 = ledger.log_event(review, observer_id="Adjuster")
    print_event(review, r3['event_id'], r3['sig'], r3['observer'])

    print_audit(ledger)
    print_benefits()
    print(f"{CYAN}{BOX}{END}")
    print(f"{CYAN}{BOLD}Demo Complete | github.com/adhack121-create/hackett-meta-os{END}")
    print(f"{CYAN}{BOX}{END}\n")