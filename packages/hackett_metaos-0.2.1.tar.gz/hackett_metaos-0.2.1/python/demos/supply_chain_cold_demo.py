import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from ledger import Ledger
import time

ledger = Ledger()
print("═════════════════════════════════════════════════════════════════════════════")
print("║ HACKETT META OS - SUPPLY CHAIN COLD CHAIN BREAK DEMO")
print("═════════════════════════════════════════════════════════════════════════════\n")

ts = int(time.time())

ledger.log_event(f"Shipment departed at {ts}, temp 2°C, Lot #PFZ-8472", observer_id="WarehouseSensor")
ledger.log_event(f"In-transit reading at {ts+1}, temp 3°C", observer_id="TruckSensor")
ledger.log_nullreceipt(f"Hourly reading missing at {ts+2}", observer_id="MonitoringSystem")
ledger.log_event(f"Arrival reading at {ts+3}, temp 12°C (BREACH)", observer_id="ReceivingSensor")

ledger.compress_ledger()
ledger.audit()

print("\n═════════════════════════════════════════════════════════════════════════════")
print("║ ❄️ SUPPLY CHAIN VALUE")
print("═════════════════════════════════════════════════════════════════════════════")
print("✓ All sensor readings and omissions cryptographically receipted")
print("✓ Cold chain breaks detected instantly, liability pinpointed")
print("✓ One-click, receipts-native audit for insurance, FDA, pharma")
print("✓ Tamper-proof chain of custody for vaccines, food, and drugs")
print("═════════════════════════════════════════════════════════════════════════════")