import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from ledger import Ledger

ledger = Ledger()
print("═════════════════════════════════════════════════════════════════════════════")
print("║ HACKETT META OS - MAUDE (ADVERSE EVENT) DEMO")
print("═════════════════════════════════════════════════════════════════════════════\n")

ledger.log_event("Device implanted at 1770300583, Serial #SJM-2847, Patient #10234", observer_id="SurgeonWorkstation")
ledger.log_event("Post-op monitoring at 1770300584, vitals normal", observer_id="MonitoringSystem")
ledger.log_nullreceipt("30-day follow-up missing at 1770300585", observer_id="ComplianceEngine")
ledger.log_event("Adverse event reported at 1770300586, device malfunction", observer_id="PhysicianPortal")

ledger.compress_ledger()
ledger.audit()

print("\n═════════════════════════════════════════════════════════════════════════════")
print("║ 🚨 MAUDE / FDA VALUE")
print("═════════════════════════════════════════════════════════════════════════════")
print("✓ All events, omissions, and overrides cryptographically receipted")
print("✓ Missing follow-ups are instantly detected—no hidden risk")
print("✓ One-click, MAUDE-ready export for FDA submission")
print("✓ Complete, tamper-proof audit chain (every event links to the last)")
print("═════════════════════════════════════════════════════════════════════════════")