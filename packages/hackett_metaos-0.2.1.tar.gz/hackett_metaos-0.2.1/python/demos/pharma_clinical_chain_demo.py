import sys, os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from ledger import Ledger
import time

# ANSI color/style codes
BOLD = "\033[1m"
END = "\033[0m"
GREEN = "\033[92m"
RED = "\033[91m"
CYAN = "\033[96m"
YELLOW = "\033[93m"
GRAY = "\033[90m"
BOX = "═" * 78

def print_header(title):
    print(f"\n{CYAN}{BOX}{END}")
    print(f"{CYAN}║{END} {BOLD}{title}{END}")
    print(f"{CYAN}{BOX}{END}")

def print_section(title, icon=""):
    print(f"\n{CYAN}{BOX}\n║{END} {BOLD}{icon} {title}{END}\n{CYAN}{BOX}{END}")

def print_event(msg, receipt_id, sig, observer, is_omission=False):
    color = RED if is_omission else GREEN
    prefix = "✗" if is_omission else "✓"
    who = f"{GRAY}Observer: {observer}{END}"
    print(f"{color}{prefix} {msg}{END}   {who}")
    print(f"{GRAY}    Receipt ID: {receipt_id} | Sig: {sig[:12]}...{END}")

def print_audit(ledger):
    print_section("AUDIT SUMMARY", "🗂")
    compressed = ledger.compress_ledger()
    print(f"{CYAN}Audit trail compressed: {len(compressed)} bytes{END}")
    print(f"{CYAN}Events: {len(ledger.events)} | Omissions: {len(ledger.nullreceipts)}{END}")

def print_benefits():
    print_section("CLINICAL TRIAL & REGULATORY VALUE", "💊")
    print(f"{BOLD}✓{END} Every sample, handoff, and omission is cryptographically receipted")
    print(f"{BOLD}✓{END} Detects and logs missing results, signatures, or custody breaks")
    print(f"{BOLD}✓{END} Full compliance for FDA, EMA, GxP, 21 CFR Part 11, ICH E6(R2)")
    print(f"{BOLD}✓{END} Compress and export full chain of custody for audits, sponsors, or regulators")
    print(f"{BOLD}✓{END} Instantly prove integrity and traceability of every trial artifact")
    print(f"{CYAN}{BOX}{END}")

if __name__ == "__main__":
    print_header("HACKETT META OS - PHARMA CLINICAL TRIAL CHAIN OF CUSTODY DEMO")
    print_section("TRIAL SAMPLE WORKFLOW", "🔬")
    ledger = Ledger()
    ts = int(time.time())

    # Step 1: Sample collected from Patient A
    s1 = f"Sample #001 collected from Patient A, ts={ts}"
    r1 = ledger.log_event(s1, observer_id="Site_Nurse")
    print_event(s1, r1['event_id'], r1['sig'], r1['observer'])

    # Step 2: Transferred to central lab
    s2 = f"Sample #001 transferred to Central Lab, ts={ts+1}"
    r2 = ledger.log_event(s2, observer_id="Courier")
    print_event(s2, r2['event_id'], r2['sig'], r2['observer'])

    # Step 3: Omission - Lab test result not recorded
    omission = f"Lab result missing for Sample #001, ts={ts+2}"
    nr = ledger.log_nullreceipt(omission, observer_id="Lab")
    print_event(omission, nr['event_id'], nr['sig'], nr['observer'], is_omission=True)

    # Step 4: Sponsor notified, override approved (documented)
    s3 = f"Sponsor override: proceed to next step, pending result, ts={ts+3}"
    r3 = ledger.log_event(s3, observer_id="Sponsor")
    print_event(s3, r3['event_id'], r3['sig'], r3['observer'])

    # Step 5: Regulatory authority review
    s4 = f"Regulatory review: chain of custody validated, ts={ts+4}"
    r4 = ledger.log_event(s4, observer_id="Reg_Authority")
    print_event(s4, r4['event_id'], r4['sig'], r4['observer'])

    print_audit(ledger)
    print_benefits()
    print(f"{CYAN}{BOX}{END}")
    print(f"{CYAN}{BOLD}Demo Complete | github.com/adhack121-create/hackett-meta-os{END}")
    print(f"{CYAN}{BOX}{END}\n")