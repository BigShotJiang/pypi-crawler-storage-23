import sys, os, time
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from ledger import Ledger

ledger = Ledger()
print("═════════════════════════════════════════════════════════════════════════════")
print("║ HACKETT META OS - SCIENTIFIC INTEGRITY / PEER REVIEW DEMO")
print("═════════════════════════════════════════════════════════════════════════════\n")

ts = int(time.time())
ledger.log_event(f"Manuscript submitted at {ts}, Journal: Nature Quantum", observer_id="SubmissionPortal")
ledger.log_event(f"Reviewer #1 assigned at {ts+1}", observer_id="EditorialBoard")
ledger.log_event(f"Reviewer #2 assigned at {ts+2}", observer_id="EditorialBoard")
ledger.log_nullreceipt(f"Review report missing from Reviewer #1 at {ts+3}", observer_id="EditorInChief")
ledger.log_event(f"Revision submitted at {ts+4}, Response: Major Revisions", observer_id="Author")
ledger.log_event(f"Acceptance at {ts+5}, Publication scheduled", observer_id="EditorialBoard")
ledger.compress_ledger()
ledger.audit()

print("\n═════════════════════════════════════════════════════════════════════════════")
print("║ 🧬 SCIENTIFIC INTEGRITY VALUE")
print("═════════════════════════════════════════════════════════════════════════════")
print("✓ Every submission, review, and omission cryptographically receipted")
print("✓ NullReceipts catch missing/late/fabricated reviews")
print("✓ Tamper-proof, audit-native peer review for journals and funders")
print("✓ Trustworthy scientific publication and reproducibility")
print("═════════════════════════════════════════════════════════════════════════════")