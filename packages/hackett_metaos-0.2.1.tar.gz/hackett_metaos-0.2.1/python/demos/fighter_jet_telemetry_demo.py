import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from ledger import Ledger
import time

ledger = Ledger()
print("═════════════════════════════════════════════════════════════════════════════")
print("║ HACKETT META OS - FIGHTER JET TELEMETRY & MISSION AUDIT DEMO")
print("═════════════════════════════════════════════════════════════════════════════\n")

ts = int(time.time())

ledger.log_event(f"Mission start at {ts}, Aircraft: F-35A, Pilot: Maj. Evans", observer_id="MissionControl")
ledger.log_event(f"Takeoff at {ts+1}, runway 19L, gear up at 320kts", observer_id="FlightComputer")
ledger.log_event(f"Supersonic event at {ts+2}, Mach 1.15, FL400", observer_id="FlightDataRecorder")
ledger.log_nullreceipt(f"Telemetry dropout at {ts+3}, lost signal with AOA Sensor", observer_id="TelemetryMonitor")
ledger.log_event(f"Weapon deployment at {ts+4}, AMRAAM x1, Confirmed hit", observer_id="WeaponsSystem")
ledger.log_event(f"Landing at {ts+5}, gear down at 165kts, debriefing start", observer_id="MissionDebrief")

ledger.compress_ledger()
ledger.audit()

print("\n═════════════════════════════════════════════════════════════════════════════")
print("║ ✈️ FIGHTER JET / DEFENSE VALUE")
print("═════════════════════════════════════════════════════════════════════════════")
print("✓ Every flight event, sensor reading, and weapon deployment cryptographically receipted")
print("✓ NullReceipts expose missing telemetry or suspected tampering")
print("✓ Instant, tamper-proof, mission audit for pilots, command, and Congress")
print("✓ Real-time, receipts-native after-action review (AAR) and training")
print("✓ $B+ savings in warranty, maintenance, and mission dispute resolution")
print("═════════════════════════════════════════════════════════════════════════════")