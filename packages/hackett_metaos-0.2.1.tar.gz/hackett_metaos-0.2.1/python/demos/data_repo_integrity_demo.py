import sys, os, time
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from ledger import Ledger

ledger = Ledger()
print("═════════════════════════════════════════════════════════════════════════════")
print("║ HACKETT META OS - DATA REPOSITORY INTEGRITY DEMO")
print("═════════════════════════════════════════════════════════════════════════════\n")

ts = int(time.time())
ledger.log_event(f"Dataset uploaded at {ts}, Repo: OpenScienceCloud, DOI: 10.18488/osc-55821", observer_id="DataManager")
ledger.log_event(f"Access granted at {ts+1}, User: Dr. Jones", observer_id="AccessControl")
ledger.log_nullreceipt(f"Integrity check missed at {ts+2}, hash verification skipped", observer_id="QA_Automation")
ledger.log_event(f"Version control: dataset updated at {ts+3}, new schema applied", observer_id="DataManager")
ledger.log_event(f"Peer citation: dataset referenced in new publication", observer_id="BibliometricsBot")
ledger.compress_ledger()
ledger.audit()

print("\n═════════════════════════════════════════════════════════════════════════════")
print("║ 🗂️ DATA REPO INTEGRITY VALUE")
print("═════════════════════════════════════════════════════════════════════════════")
print("✓ Every upload, access, omission, and versioning event cryptographically receipted")
print("✓ NullReceipts for missing QC = audit, compliance, and trust")
print("✓ Tamper-proof, receipts-native scientific record keeping")
print("✓ Solves for “lost dataset”, unverified research, and grant fraud")
print("═════════════════════════════════════════════════════════════════════════════")