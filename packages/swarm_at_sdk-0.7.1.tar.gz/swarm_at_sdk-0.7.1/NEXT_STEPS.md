# Next Steps

Prioritized work items for swarm.at. Updated 2026-02-27, version 0.7.0.

## Critical — DONE

### 1. Workflow State API + CLI (DONE)
The fork/execute flow is opaque. After forking a blueprint, there's no way to inspect molecule state.

- `GET /v1/molecules/{id}` — query molecule, bead list, execution status
- `GET /v1/molecules` — list agent's molecules
- `swarm molecules list`, `swarm molecules get <id>`
- SDK: `get_molecule()`, `list_molecules()`
- Files: `api/main.py`, `cli.py`, `sdk/client.py`

### 2. Batch Settlement (DONE)
Single-proposal endpoint is the only path. Polymarket batch trades and code review batches need a batch endpoint.

- `POST /v1/settle/batch` — array of proposals, returns array of results
- SDK: `settle_batch(proposals)`
- MCP: `settle_batch` tool
- Files: `api/main.py`, `sdk/client.py`, `mcp/server.py`

### 3. SDK Authorship Session Lifecycle (DONE)
SDK has claim/verify but missing session lifecycle. Feature parity table says "Y" but it's incomplete.

- `start_session()`, `record_event()`, `approve_writing()`, `delete_session()`
- These map to existing API endpoints that already work
- Files: `sdk/client.py`, tests

### 4. Adapter Base Protocol (DONE)
8 adapters, 8 different signatures. No common interface.

- Define `SwarmAdapter(Protocol)` with `settle()` method
- Add adapter registry / factory: `get_adapter("langgraph")`
- Add health check: verify framework imports before settling
- Files: `adapters/__init__.py` (new), all adapter files

## High — DONE

### 5. Multi-Python CI (DONE)
CI only tests py3.12 but package claims py3.10+.

- Added matrix: `python-version: ["3.10", "3.11", "3.12"]`
- Added pip-audit dependency check
- File: `.github/workflows/ci.yml`

### 6. Adapter Integration Guide (DONE)
Biggest adoption blocker. Each adapter has a docstring but no standalone guide.

- One page per adapter: install, configure, usage example, full code snippet
- Files: `docs/adapters.md`

### 7. Ledger Indexing (DONE)
All ledger reads are O(n) — `read_all()` then filter. Fine at 789 entries, slow at 100k.

- In-memory cache with task_id and agent_id indexes
- `find_by_task_id()`, `find_by_agent_id()`, `latest_hash`, `entry_count` — all O(1)
- `invalidate_cache()` for external writers (git merge)
- Files: `settler.py`, `gitplane.py`

### 8. Blueprint Lifecycle API (DONE)
Authors can publish but not maintain blueprints.

- `PATCH /v1/blueprints/{id}` — update metadata
- `DELETE /v1/blueprints/{id}` — remove blueprint
- `POST /v1/blueprints/{id}/deprecate` — mark obsolete
- `deprecated` field on Blueprint model
- Files: `api/main.py`, `blueprints.py`, `seed_blueprints.py`

### 9. Rate Limit Headers (DONE)
slowapi is configured but clients can't see their limits.

- `X-RateLimit-Limit`, `X-RateLimit-Remaining`, `X-RateLimit-Reset` headers on public endpoints
- `GET /v1/rate-limits` — query limits per endpoint
- Files: `api/main.py`

### 10. Settlement Types Catalog (DONE)
75 settlement types exist but aren't documented anywhere for users.

- Table with type name, description, when to use, example payload
- Files: `docs/settlement-types.md`

## Medium — DONE

### 11. Missing Test Files (DONE)
- `test_context.py` — 41 tests for context slicing, keyword filtering
- `test_auditor.py` — 43 tests for shadow audit divergence detection

### 12. SDK Error Hierarchy (DONE)
SDK throws raw `httpx` exceptions. Need domain-specific errors.

- `SwarmError` (base), `AuthError`, `RateLimitError`, `NotFoundError`, `ValidationError`, `ServerError`
- `_handle_response()` dispatches on status code, replaces all `raise_for_status()` calls
- Files: `sdk/errors.py` (new), `sdk/client.py`, 37 tests

### 13. Observability (DONE)
No structured logging, no metrics, no trace IDs.

- `ObservabilityMiddleware`: correlation IDs (X-Request-ID), structured JSON logging (SWARM_LOG_FORMAT=json)
- `GET /metrics` — Prometheus text exposition format (counters, histogram, error labels)
- Files: `api/middleware.py` (new), `api/main.py`, 20 tests

### 14. Developer Experience (DONE)
- `Makefile` — 11 targets (test, lint, typecheck, format, serve, mcp, install, check, clean, build, publish)
- `docker-compose.yml` — single API service with hot reload
- `.env.example` — 7 documented environment variables

### 15. Webhook Testing (DONE)
- `POST /v1/webhooks/test` — send test payload, report delivery status
- SDK: `test_webhook(url, event)` method
- Files: `api/main.py`, `sdk/client.py`, 14 tests

## Low — DONE

### 16. Getting Started Guide (DONE)
- 5-minute quickstart: install, settle, verify, SDK, remote API
- Files: `docs/quickstart.md`

### 17. Code Coverage (DONE)
- pytest-cov with XML + term-missing output
- Codecov upload on Python 3.12 only, informational (non-blocking)
- Files: `.github/workflows/ci.yml`, `.codecov.yml`, `pyproject.toml`

### 18. Docker Image (DONE)
- Multi-stage Dockerfile (builder + runtime), non-root user
- .dockerignore for clean builds
- Files: `Dockerfile`, `.dockerignore`

### 19. CLI Config Subcommand (DONE)
- `swarm config get [key]`, `swarm config set <key> <value>`, `swarm config path`
- 9 tests
- File: `cli.py`

### 20. Polymarket Edge Cases (DONE)
- `settle_liquidation()` — margin calls, forced closes (confidence >= 0.99)
- `settle_dispute()` — cancelled market outcomes
- 18 tests
- File: `adapters/polymarket.py`

## Current State

| Metric | Value |
|--------|-------|
| Version | 0.7.0 |
| PyPI | swarm-at-sdk 0.7.0 |
| MCP Registry | io.github.Mediaeater/swarm-at 0.7.0 |
| Blueprints | 48 across 9 categories |
| MCP Tools | 19 (incl. settle_batch) |
| API Endpoints | 58 (+ batch, lifecycle, rate-limits, molecules) |
| Framework Adapters | 8 |
| Tests | 1711 passing, ~18s |
| Settlement Types | 75 |
| Public Ledger | 789 entries |
