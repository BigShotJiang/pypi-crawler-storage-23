"""Tests for MCP blueprint tools."""

from __future__ import annotations

from swarm_at.mcp.server import SettlementMCPServer


class TestMcpListBlueprints:
    """list_blueprints method on SettlementMCPServer."""

    def test_returns_all_when_no_tag(self, mcp_server: SettlementMCPServer) -> None:
        result = mcp_server.list_blueprints()
        assert result["total"] == 48
        assert len(result["blueprints"]) == 48

    def test_filters_by_tag(self, mcp_server: SettlementMCPServer) -> None:
        result = mcp_server.list_blueprints(tag="audit")
        assert result["total"] == 4
        assert any(bp["blueprint_id"] == "audit-chain" for bp in result["blueprints"])

    def test_unknown_tag_returns_empty(self, mcp_server: SettlementMCPServer) -> None:
        result = mcp_server.list_blueprints(tag="nonexistent")
        assert result["total"] == 0
        assert result["blueprints"] == []

    def test_blueprint_shape(self, mcp_server: SettlementMCPServer) -> None:
        result = mcp_server.list_blueprints()
        bp = result["blueprints"][0]
        for field in ("blueprint_id", "name", "tags", "step_count", "validated"):
            assert field in bp, f"Missing field: {field}"


class TestMcpGetBlueprint:
    """get_blueprint method on SettlementMCPServer."""

    def test_returns_detail(self, mcp_server: SettlementMCPServer) -> None:
        result = mcp_server.get_blueprint("audit-chain")
        assert result["blueprint_id"] == "audit-chain"
        assert len(result["steps"]) == 3

    def test_step_structure(self, mcp_server: SettlementMCPServer) -> None:
        result = mcp_server.get_blueprint("code-review-pipeline")
        step = result["steps"][0]
        for field in ("step_id", "name", "description", "depends_on", "agent_role", "complexity"):
            assert field in step, f"Missing step field: {field}"

    def test_unknown_id_returns_error(self, mcp_server: SettlementMCPServer) -> None:
        result = mcp_server.get_blueprint("nonexistent")
        assert "error" in result

    def test_includes_fork_count(self, mcp_server: SettlementMCPServer) -> None:
        result = mcp_server.get_blueprint("research-workflow")
        assert "fork_count" in result
        assert result["fork_count"] == 0
