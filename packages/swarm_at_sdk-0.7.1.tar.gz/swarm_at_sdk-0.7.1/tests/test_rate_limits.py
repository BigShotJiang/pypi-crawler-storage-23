"""Tests for rate limit response headers and /v1/rate-limits info endpoint."""

from __future__ import annotations

from fastapi.testclient import TestClient

import swarm_at.api.state as api_state


# ---------------------------------------------------------------------------
# Rate limit info endpoint
# ---------------------------------------------------------------------------


def test_rate_limit_info_endpoint(authed_api_client: TestClient) -> None:
    """GET /v1/rate-limits returns the configured limit list."""
    resp = authed_api_client.get("/v1/rate-limits")
    assert resp.status_code == 200
    data = resp.json()
    assert "limits" in data
    limits = data["limits"]
    assert isinstance(limits, list)
    assert len(limits) > 0
    # Each entry has endpoint and limit fields
    for entry in limits:
        assert "endpoint" in entry
        assert "limit" in entry
    # Spot-check known entries
    endpoints = [e["endpoint"] for e in limits]
    assert "/public/ledger" in endpoints
    assert "/public/agents" in endpoints


def test_rate_limit_info_requires_auth(api_client: TestClient) -> None:
    """GET /v1/rate-limits returns 401 without auth when auth is enabled."""
    api_state.api_keys = {"sk-test-key"}
    resp = api_client.get("/v1/rate-limits")
    assert resp.status_code == 401


def test_rate_limit_info_limit_format(authed_api_client: TestClient) -> None:
    """Each rate limit entry has a valid limit string like '60/minute'."""
    resp = authed_api_client.get("/v1/rate-limits")
    assert resp.status_code == 200
    for entry in resp.json()["limits"]:
        limit_str = entry["limit"]
        # Format: <number>/<period>
        assert "/" in limit_str, f"Expected '<count>/<period>', got: {limit_str!r}"
        count, period = limit_str.split("/", 1)
        assert count.isdigit(), f"Count part should be numeric, got: {count!r}"
        assert period in ("second", "minute", "hour", "day"), (
            f"Unknown period: {period!r}"
        )


# ---------------------------------------------------------------------------
# Rate limit response headers
# ---------------------------------------------------------------------------


def test_response_has_rate_limit_headers(api_client: TestClient) -> None:
    """A request to a rate-limited endpoint returns X-RateLimit-* headers."""
    resp = api_client.get("/public/ledger")
    assert resp.status_code == 200
    assert "x-ratelimit-limit" in resp.headers, (
        "Expected X-RateLimit-Limit header on rate-limited endpoint"
    )
    assert "x-ratelimit-remaining" in resp.headers, (
        "Expected X-RateLimit-Remaining header on rate-limited endpoint"
    )
    assert "x-ratelimit-reset" in resp.headers, (
        "Expected X-RateLimit-Reset header on rate-limited endpoint"
    )


def test_rate_limit_headers_on_public_endpoint(api_client: TestClient) -> None:
    """Rate limit headers are present on /public/ledger and have valid values."""
    resp = api_client.get("/public/ledger")
    assert resp.status_code == 200

    limit = resp.headers.get("x-ratelimit-limit")
    remaining = resp.headers.get("x-ratelimit-remaining")
    reset = resp.headers.get("x-ratelimit-reset")

    assert limit is not None
    assert remaining is not None
    assert reset is not None

    # Values should be numeric — limit and remaining are integers, reset is a float timestamp
    assert limit.isdigit(), f"X-RateLimit-Limit should be numeric, got: {limit!r}"
    assert remaining.isdigit(), (
        f"X-RateLimit-Remaining should be numeric, got: {remaining!r}"
    )
    assert float(reset) > 0, f"X-RateLimit-Reset should be a positive number, got: {reset!r}"

    # Limit should match the configured 60/minute
    assert int(limit) == 60
    # Remaining should be non-negative and at most limit
    assert 0 <= int(remaining) <= int(limit)


def test_rate_limit_headers_on_public_agents(api_client: TestClient) -> None:
    """Rate limit headers are present on /public/agents."""
    resp = api_client.get("/public/agents")
    assert resp.status_code == 200
    assert "x-ratelimit-limit" in resp.headers
    assert "x-ratelimit-remaining" in resp.headers
    assert "x-ratelimit-reset" in resp.headers


def test_rate_limit_remaining_decrements(api_client: TestClient) -> None:
    """X-RateLimit-Remaining decrements with each request."""
    r1 = api_client.get("/public/ledger")
    r2 = api_client.get("/public/ledger")
    assert r1.status_code == 200
    assert r2.status_code == 200

    remaining1 = int(r1.headers["x-ratelimit-remaining"])
    remaining2 = int(r2.headers["x-ratelimit-remaining"])
    assert remaining2 == remaining1 - 1
