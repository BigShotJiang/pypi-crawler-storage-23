"""Tests for the Dispatcher."""

import pytest

from swarm_at.dispatcher import ModelTier, dispatch, score_complexity, select_tier


@pytest.mark.parametrize(
    "complexity, expected_tier",
    [
        (0.0, ModelTier.THRIFTY),
        (0.3, ModelTier.THRIFTY),
        (0.31, ModelTier.STANDARD),
        (0.7, ModelTier.STANDARD),
        (0.71, ModelTier.PREMIUM),
        (1.0, ModelTier.PREMIUM),
    ],
    ids=["min-thrifty", "max-thrifty", "min-standard", "max-standard", "min-premium", "max-premium"],
)
def test_select_tier(complexity: float, expected_tier: ModelTier) -> None:
    assert select_tier(complexity) == expected_tier


@pytest.mark.parametrize(
    "task, expected_tier",
    [
        ({"description": "Look up a name"}, ModelTier.THRIFTY),
        ({"description": "Simple lookup"}, ModelTier.THRIFTY),
        (
            {
                "description": "Analyze and synthesize complex reasoning across multiple evaluate and compare design steps",
                "steps": list(range(15)),
            },
            ModelTier.PREMIUM,
        ),
    ],
    ids=["simple", "lookup", "complex"],
)
def test_dispatch(task: dict, expected_tier: ModelTier) -> None:
    assert dispatch(task).tier == expected_tier


def test_score_complexity_bounded() -> None:
    """Score is always in [0.0, 1.0]."""
    huge = {"description": " ".join(["analyze synthesize compare evaluate design reasoning multi-step"] * 50), "steps": list(range(100))}
    assert 0.0 <= score_complexity(huge) <= 1.0
    assert 0.0 <= score_complexity({}) <= 1.0
