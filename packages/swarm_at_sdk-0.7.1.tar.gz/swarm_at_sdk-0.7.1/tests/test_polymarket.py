"""Tests for SwarmPolymarketAdapter.settle_liquidation and settle_dispute."""

from __future__ import annotations

from pathlib import Path
from unittest.mock import patch

import pytest

from swarm_at.adapters.polymarket import SwarmPolymarketAdapter
from swarm_at.models import SettlementStatus
from swarm_at.settle import SettlementContext
from swarm_at.settler import Ledger
from swarm_at.tiers import SettlementTier


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture()
def sandbox_ctx(tmp_path: Path) -> SettlementContext:
    """Sandbox context: synthetic hashes, no chain enforcement."""
    return SettlementContext(tier=SettlementTier.SANDBOX, ledger_path=str(tmp_path / "l.jsonl"))


@pytest.fixture()
def ledger(tmp_path: Path) -> Ledger:
    """Isolated ledger for payload inspection."""
    return Ledger(path=tmp_path / "poly.jsonl")


@pytest.fixture()
def production_ctx(ledger: Ledger) -> SettlementContext:
    """Production context wired to the inspectable ledger."""
    from swarm_at.engine import SwarmAtEngine
    from swarm_at.tiers import get_policy

    ctx = SettlementContext.__new__(SettlementContext)
    ctx.tier = SettlementTier.PRODUCTION
    ctx.policy = get_policy(SettlementTier.PRODUCTION)
    ctx._engine = SwarmAtEngine(ledger=ledger)
    ctx._client = None
    ctx._mode = "local"
    ctx._parent_hash = ledger.get_latest_hash()
    return ctx


# ---------------------------------------------------------------------------
# settle_liquidation — task and payload
# ---------------------------------------------------------------------------


class TestSettleLiquidation:
    def test_returns_settled_status(self, sandbox_ctx: SettlementContext) -> None:
        adapter = SwarmPolymarketAdapter(context=sandbox_ctx)
        result = adapter.settle_liquidation(
            agent_id="risk-bot",
            market_id="0xabc",
            position={"token": "0x1", "size": 200},
            reason="margin-call",
        )
        assert result.status == SettlementStatus.SETTLED

    def test_task_is_liquidation_event(self, sandbox_ctx: SettlementContext) -> None:
        """settle() is called with task='polymarket:liquidation-event'."""
        adapter = SwarmPolymarketAdapter(context=sandbox_ctx)
        with patch.object(sandbox_ctx, "settle", wraps=sandbox_ctx.settle) as mock_settle:
            adapter.settle_liquidation(
                agent_id="risk-bot",
                market_id="0xabc",
                position={"token": "0x1", "size": 200},
                reason="margin-call",
            )
        mock_settle.assert_called_once()
        _, kwargs = mock_settle.call_args
        assert kwargs["task"] == "polymarket:liquidation-event"

    def test_payload_contains_market_and_position(
        self, production_ctx: SettlementContext, ledger: Ledger
    ) -> None:
        adapter = SwarmPolymarketAdapter(context=production_ctx)
        adapter.settle_liquidation(
            agent_id="risk-bot",
            market_id="0xdeadbeef",
            position={"token": "0x2", "size": 500},
            reason="forced-close",
        )
        entry = ledger.read_all()[0]
        # entry.payload IS the data_update dict
        assert entry.payload["market_id"] == "0xdeadbeef"
        assert "500" in entry.payload["position"]
        assert entry.payload["reason"] == "forced-close"

    def test_enforces_confidence_floor(self, sandbox_ctx: SettlementContext) -> None:
        """Confidence below 0.99 is clamped to 0.99 before settling."""
        adapter = SwarmPolymarketAdapter(confidence=0.5, context=sandbox_ctx)
        with patch.object(sandbox_ctx, "settle", wraps=sandbox_ctx.settle) as mock_settle:
            adapter.settle_liquidation(
                agent_id="risk-bot",
                market_id="0xabc",
                position="short 100",
                reason="margin-call",
                confidence=0.50,
            )
        _, kwargs = mock_settle.call_args
        assert kwargs["confidence"] >= 0.99

    def test_confidence_exactly_099_accepted(self, sandbox_ctx: SettlementContext) -> None:
        adapter = SwarmPolymarketAdapter(context=sandbox_ctx)
        with patch.object(sandbox_ctx, "settle", wraps=sandbox_ctx.settle) as mock_settle:
            adapter.settle_liquidation(
                agent_id="risk-bot",
                market_id="0xabc",
                position="long 50",
                reason="stop-loss",
                confidence=0.99,
            )
        _, kwargs = mock_settle.call_args
        assert kwargs["confidence"] == 0.99

    def test_confidence_above_099_preserved(self, sandbox_ctx: SettlementContext) -> None:
        adapter = SwarmPolymarketAdapter(context=sandbox_ctx)
        with patch.object(sandbox_ctx, "settle", wraps=sandbox_ctx.settle) as mock_settle:
            adapter.settle_liquidation(
                agent_id="risk-bot",
                market_id="0xabc",
                position="long 50",
                reason="protocol-rule",
                confidence=1.0,
            )
        _, kwargs = mock_settle.call_args
        assert kwargs["confidence"] == 1.0


# ---------------------------------------------------------------------------
# settle_dispute — task and payload
# ---------------------------------------------------------------------------


class TestSettleDispute:
    def test_returns_settled_status(self, sandbox_ctx: SettlementContext) -> None:
        adapter = SwarmPolymarketAdapter(context=sandbox_ctx)
        result = adapter.settle_dispute(
            agent_id="arbiter",
            market_id="0xfeed",
            outcome="INVALID",
            resolution="Market cancelled — no resolution event occurred.",
        )
        assert result.status == SettlementStatus.SETTLED

    def test_task_is_market_dispute(self, sandbox_ctx: SettlementContext) -> None:
        """settle() is called with task='polymarket:market-dispute'."""
        adapter = SwarmPolymarketAdapter(context=sandbox_ctx)
        with patch.object(sandbox_ctx, "settle", wraps=sandbox_ctx.settle) as mock_settle:
            adapter.settle_dispute(
                agent_id="arbiter",
                market_id="0xfeed",
                outcome="CANCELLED",
                resolution="Event postponed indefinitely.",
            )
        mock_settle.assert_called_once()
        _, kwargs = mock_settle.call_args
        assert kwargs["task"] == "polymarket:market-dispute"

    def test_payload_contains_resolution(
        self, production_ctx: SettlementContext, ledger: Ledger
    ) -> None:
        adapter = SwarmPolymarketAdapter(context=production_ctx)
        resolution_text = "Judged void — oracle unavailable at close."
        adapter.settle_dispute(
            agent_id="arbiter",
            market_id="0xbeef",
            outcome="VOID",
            resolution=resolution_text,
        )
        entry = ledger.read_all()[0]
        assert entry.payload["resolution"] == resolution_text
        assert entry.payload["market_id"] == "0xbeef"
        assert entry.payload["outcome"] == "VOID"

    def test_default_confidence_is_095(self, sandbox_ctx: SettlementContext) -> None:
        adapter = SwarmPolymarketAdapter(context=sandbox_ctx)
        with patch.object(sandbox_ctx, "settle", wraps=sandbox_ctx.settle) as mock_settle:
            adapter.settle_dispute(
                agent_id="arbiter",
                market_id="0x1",
                outcome="DISPUTED",
                resolution="Under review.",
            )
        _, kwargs = mock_settle.call_args
        assert kwargs["confidence"] == 0.95

    def test_custom_confidence_respected(self, sandbox_ctx: SettlementContext) -> None:
        adapter = SwarmPolymarketAdapter(context=sandbox_ctx)
        with patch.object(sandbox_ctx, "settle", wraps=sandbox_ctx.settle) as mock_settle:
            adapter.settle_dispute(
                agent_id="arbiter",
                market_id="0x1",
                outcome="DISPUTED",
                resolution="Clear case.",
                confidence=0.80,
            )
        _, kwargs = mock_settle.call_args
        assert kwargs["confidence"] == 0.80


# ---------------------------------------------------------------------------
# Chain integrity across consecutive settlements
# ---------------------------------------------------------------------------


class TestChainIntegrity:
    def test_chain_intact_after_liquidation_and_dispute(
        self, production_ctx: SettlementContext, ledger: Ledger
    ) -> None:
        adapter = SwarmPolymarketAdapter(context=production_ctx)

        adapter.settle_liquidation(
            agent_id="risk-bot",
            market_id="0xaaa",
            position="long 100",
            reason="margin-call",
        )
        adapter.settle_dispute(
            agent_id="arbiter",
            market_id="0xaaa",
            outcome="VOID",
            resolution="Position unwound before resolution.",
        )

        assert ledger.verify_chain() is True
        assert ledger.entry_count == 2

    def test_chain_intact_after_mixed_settlements(
        self, production_ctx: SettlementContext, ledger: Ledger
    ) -> None:
        adapter = SwarmPolymarketAdapter(context=production_ctx)

        adapter.settle_market_read([{"id": "0x1", "question": "Will Y?"}])
        adapter.settle_liquidation(
            agent_id="risk-bot",
            market_id="0x1",
            position={"size": 50},
            reason="stop-loss",
        )
        adapter.settle_dispute(
            agent_id="arbiter",
            market_id="0x1",
            outcome="CANCELLED",
            resolution="Market never resolved.",
        )

        assert ledger.verify_chain() is True
        assert ledger.entry_count == 3

    def test_hashes_advance_between_calls(
        self, production_ctx: SettlementContext, ledger: Ledger
    ) -> None:
        adapter = SwarmPolymarketAdapter(context=production_ctx)

        r1 = adapter.settle_liquidation(
            agent_id="risk-bot",
            market_id="0x1",
            position="long 10",
            reason="margin-call",
        )
        r2 = adapter.settle_dispute(
            agent_id="arbiter",
            market_id="0x1",
            outcome="VOID",
            resolution="Cancelled.",
        )

        assert r1.hash != r2.hash
        assert r1.hash is not None
        assert r2.hash is not None
        assert len(r1.hash) == 64
        assert len(r2.hash) == 64
