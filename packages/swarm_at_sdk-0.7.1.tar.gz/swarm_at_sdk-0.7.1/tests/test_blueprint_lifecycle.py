"""Tests for blueprint lifecycle management endpoints.

Covers PATCH /v1/blueprints/{id}, DELETE /v1/blueprints/{id},
and POST /v1/blueprints/{id}/deprecate.
"""

from __future__ import annotations

import pytest
from fastapi.testclient import TestClient

import swarm_at.api.state as api_state
from swarm_at.blueprints import BlueprintStore
from swarm_at.seed_blueprints import seed_blueprints


@pytest.fixture()
def seeded_store() -> BlueprintStore:
    """Seed the API state blueprint store and return it."""
    seed_blueprints(api_state.blueprint_store)
    return api_state.blueprint_store


# ---------------------------------------------------------------------------
# PATCH /v1/blueprints/{blueprint_id}
# ---------------------------------------------------------------------------


class TestUpdateBlueprint:
    """PATCH /v1/blueprints/{blueprint_id}"""

    def test_update_blueprint_name(
        self, authed_api_client: TestClient, seeded_store: BlueprintStore
    ) -> None:
        resp = authed_api_client.patch(
            "/v1/blueprints/audit-chain",
            json={"name": "Audit Chain v2"},
        )
        assert resp.status_code == 200
        data = resp.json()
        assert data["name"] == "Audit Chain v2"
        assert data["blueprint_id"] == "audit-chain"

    def test_update_blueprint_tags(
        self, authed_api_client: TestClient, seeded_store: BlueprintStore
    ) -> None:
        resp = authed_api_client.patch(
            "/v1/blueprints/audit-chain",
            json={"tags": ["custom", "updated"]},
        )
        assert resp.status_code == 200
        data = resp.json()
        assert data["tags"] == ["custom", "updated"]

    def test_update_blueprint_description(
        self, authed_api_client: TestClient, seeded_store: BlueprintStore
    ) -> None:
        resp = authed_api_client.patch(
            "/v1/blueprints/audit-chain",
            json={"description": "Updated description text"},
        )
        assert resp.status_code == 200
        assert resp.json()["description"] == "Updated description text"

    def test_update_blueprint_credit_cost(
        self, authed_api_client: TestClient, seeded_store: BlueprintStore
    ) -> None:
        resp = authed_api_client.patch(
            "/v1/blueprints/audit-chain",
            json={"credit_cost": 9.99},
        )
        assert resp.status_code == 200
        assert resp.json()["credit_cost"] == 9.99

    def test_update_partial_only_changes_given_fields(
        self, authed_api_client: TestClient, seeded_store: BlueprintStore
    ) -> None:
        original = authed_api_client.get("/public/blueprints/audit-chain").json()
        original_tags = original["tags"]

        resp = authed_api_client.patch(
            "/v1/blueprints/audit-chain",
            json={"name": "New Name Only"},
        )
        assert resp.status_code == 200
        data = resp.json()
        assert data["name"] == "New Name Only"
        # tags should be unchanged
        assert data["tags"] == original_tags

    def test_update_blueprint_not_found(
        self, authed_api_client: TestClient
    ) -> None:
        resp = authed_api_client.patch(
            "/v1/blueprints/does-not-exist",
            json={"name": "Ghost"},
        )
        assert resp.status_code == 404

    def test_update_requires_auth(self, api_client: TestClient, seeded_store: BlueprintStore) -> None:
        api_state.api_keys = {"sk-test-key"}
        resp = api_client.patch(
            "/v1/blueprints/audit-chain",
            json={"name": "Should Fail"},
        )
        assert resp.status_code == 401

    def test_update_response_includes_deprecated_field(
        self, authed_api_client: TestClient, seeded_store: BlueprintStore
    ) -> None:
        resp = authed_api_client.patch(
            "/v1/blueprints/audit-chain",
            json={"name": "Check Fields"},
        )
        assert resp.status_code == 200
        assert "deprecated" in resp.json()


# ---------------------------------------------------------------------------
# DELETE /v1/blueprints/{blueprint_id}
# ---------------------------------------------------------------------------


class TestDeleteBlueprint:
    """DELETE /v1/blueprints/{blueprint_id}"""

    def test_delete_blueprint(
        self, authed_api_client: TestClient, seeded_store: BlueprintStore
    ) -> None:
        resp = authed_api_client.delete("/v1/blueprints/audit-chain")
        assert resp.status_code == 200
        data = resp.json()
        assert data["status"] == "deleted"
        assert data["blueprint_id"] == "audit-chain"

    def test_delete_removes_from_list(
        self, authed_api_client: TestClient, seeded_store: BlueprintStore
    ) -> None:
        authed_api_client.delete("/v1/blueprints/audit-chain")
        list_resp = authed_api_client.get("/public/blueprints")
        ids = [bp["blueprint_id"] for bp in list_resp.json()["blueprints"]]
        assert "audit-chain" not in ids

    def test_delete_blueprint_not_found(
        self, authed_api_client: TestClient
    ) -> None:
        resp = authed_api_client.delete("/v1/blueprints/does-not-exist")
        assert resp.status_code == 404

    def test_delete_requires_auth(self, api_client: TestClient, seeded_store: BlueprintStore) -> None:
        api_state.api_keys = {"sk-test-key"}
        resp = api_client.delete("/v1/blueprints/audit-chain")
        assert resp.status_code == 401

    def test_delete_then_get_returns_404(
        self, authed_api_client: TestClient, seeded_store: BlueprintStore
    ) -> None:
        authed_api_client.delete("/v1/blueprints/audit-chain")
        get_resp = authed_api_client.get("/public/blueprints/audit-chain")
        assert get_resp.status_code == 404


# ---------------------------------------------------------------------------
# POST /v1/blueprints/{blueprint_id}/deprecate
# ---------------------------------------------------------------------------


class TestDeprecateBlueprint:
    """POST /v1/blueprints/{blueprint_id}/deprecate"""

    def test_deprecate_blueprint(
        self, authed_api_client: TestClient, seeded_store: BlueprintStore
    ) -> None:
        resp = authed_api_client.post("/v1/blueprints/audit-chain/deprecate")
        assert resp.status_code == 200
        data = resp.json()
        assert data["deprecated"] is True
        assert data["blueprint_id"] == "audit-chain"

    def test_deprecate_not_found(
        self, authed_api_client: TestClient
    ) -> None:
        resp = authed_api_client.post("/v1/blueprints/does-not-exist/deprecate")
        assert resp.status_code == 404

    def test_deprecate_requires_auth(self, api_client: TestClient, seeded_store: BlueprintStore) -> None:
        api_state.api_keys = {"sk-test-key"}
        resp = api_client.post("/v1/blueprints/audit-chain/deprecate")
        assert resp.status_code == 401

    def test_deprecated_still_visible_in_list(
        self, authed_api_client: TestClient, seeded_store: BlueprintStore
    ) -> None:
        authed_api_client.post("/v1/blueprints/audit-chain/deprecate")
        list_resp = authed_api_client.get("/public/blueprints")
        ids = [bp["blueprint_id"] for bp in list_resp.json()["blueprints"]]
        assert "audit-chain" in ids

    def test_deprecated_still_visible_in_detail(
        self, authed_api_client: TestClient, seeded_store: BlueprintStore
    ) -> None:
        authed_api_client.post("/v1/blueprints/audit-chain/deprecate")
        detail_resp = authed_api_client.get("/public/blueprints/audit-chain")
        assert detail_resp.status_code == 200

    def test_deprecate_idempotent(
        self, authed_api_client: TestClient, seeded_store: BlueprintStore
    ) -> None:
        authed_api_client.post("/v1/blueprints/audit-chain/deprecate")
        resp = authed_api_client.post("/v1/blueprints/audit-chain/deprecate")
        assert resp.status_code == 200
        assert resp.json()["deprecated"] is True

    def test_deprecate_response_includes_validated(
        self, authed_api_client: TestClient, seeded_store: BlueprintStore
    ) -> None:
        resp = authed_api_client.post("/v1/blueprints/audit-chain/deprecate")
        assert resp.status_code == 200
        assert "validated" in resp.json()
