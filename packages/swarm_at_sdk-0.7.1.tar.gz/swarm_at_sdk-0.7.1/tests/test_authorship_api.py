"""Tests for authorship provenance API endpoints."""

from __future__ import annotations

import swarm_at.api.state as state
from fastapi.testclient import TestClient


class TestCreateSession:
    def test_create(self, authed_api_client: TestClient) -> None:
        resp = authed_api_client.post(
            "/v1/authorship/sessions",
            json={"writer": "jane", "tool": "claude"},
        )
        assert resp.status_code == 200
        data = resp.json()
        assert "session_id" in data
        assert data["writer"] == "jane"

    def test_requires_auth(self, api_client: TestClient) -> None:
        state.api_keys = {"sk-test"}
        resp = api_client.post(
            "/v1/authorship/sessions",
            json={"writer": "jane", "tool": "claude"},
        )
        assert resp.status_code == 401


class TestRecordEvent:
    def _create_session(self, client: TestClient) -> str:
        resp = client.post(
            "/v1/authorship/sessions",
            json={"writer": "jane", "tool": "claude"},
        )
        return resp.json()["session_id"]

    def test_direction(self, authed_api_client: TestClient) -> None:
        sid = self._create_session(authed_api_client)
        resp = authed_api_client.post(
            f"/v1/authorship/sessions/{sid}/events",
            json={"event_type": "direction", "action": "premise", "chose": "noir", "phase": "concept"},
        )
        assert resp.status_code == 200
        assert resp.json()["status"] == "SETTLED"

    def test_generation(self, authed_api_client: TestClient) -> None:
        sid = self._create_session(authed_api_client)
        resp = authed_api_client.post(
            f"/v1/authorship/sessions/{sid}/events",
            json={"event_type": "generation", "output_hash": "a" * 64},
        )
        assert resp.status_code == 200

    def test_unknown_session(self, authed_api_client: TestClient) -> None:
        resp = authed_api_client.post(
            "/v1/authorship/sessions/nonexistent/events",
            json={"event_type": "direction", "action": "test", "chose": "test"},
        )
        assert resp.status_code == 404

    def test_invalid_event_type(self, authed_api_client: TestClient) -> None:
        sid = self._create_session(authed_api_client)
        resp = authed_api_client.post(
            f"/v1/authorship/sessions/{sid}/events",
            json={"event_type": "invalid"},
        )
        assert resp.status_code == 400


class TestApprove:
    def _create_session(self, client: TestClient) -> str:
        resp = client.post(
            "/v1/authorship/sessions",
            json={"writer": "jane", "tool": "claude"},
        )
        return resp.json()["session_id"]

    def test_approve(self, authed_api_client: TestClient) -> None:
        sid = self._create_session(authed_api_client)
        resp = authed_api_client.post(
            f"/v1/authorship/sessions/{sid}/approve",
            json={"content_hash": "c" * 64},
        )
        assert resp.status_code == 200
        assert resp.json()["status"] == "SETTLED"

    def test_unknown_session(self, authed_api_client: TestClient) -> None:
        resp = authed_api_client.post(
            "/v1/authorship/sessions/nonexistent/approve",
            json={"content_hash": "c" * 64},
        )
        assert resp.status_code == 404


class TestDeleteSession:
    def _create_session(self, client: TestClient) -> str:
        resp = client.post(
            "/v1/authorship/sessions",
            json={"writer": "jane", "tool": "claude"},
        )
        return resp.json()["session_id"]

    def test_delete_existing(self, authed_api_client: TestClient) -> None:
        sid = self._create_session(authed_api_client)
        resp = authed_api_client.delete(f"/v1/authorship/sessions/{sid}")
        assert resp.status_code == 200
        assert resp.json()["status"] == "deleted"
        # Verify it's gone
        list_resp = authed_api_client.get("/v1/authorship/sessions")
        assert list_resp.json()["total"] == 0

    def test_delete_unknown(self, authed_api_client: TestClient) -> None:
        resp = authed_api_client.delete("/v1/authorship/sessions/nonexistent")
        assert resp.status_code == 404

    def test_requires_auth(self, api_client: TestClient) -> None:
        state.api_keys = {"sk-test"}
        resp = api_client.delete("/v1/authorship/sessions/any-id")
        assert resp.status_code == 401


class TestReport:
    def _create_session_with_events(self, client: TestClient) -> str:
        resp = client.post(
            "/v1/authorship/sessions",
            json={"writer": "jane", "tool": "claude"},
        )
        sid = resp.json()["session_id"]
        client.post(
            f"/v1/authorship/sessions/{sid}/events",
            json={"event_type": "direction", "action": "premise", "chose": "noir", "phase": "concept"},
        )
        return sid

    def test_json_report(self, authed_api_client: TestClient) -> None:
        sid = self._create_session_with_events(authed_api_client)
        resp = authed_api_client.get(f"/v1/authorship/sessions/{sid}/report")
        assert resp.status_code == 200
        data = resp.json()
        assert data["writer"] == "jane"
        assert "work_agency" in data

    def test_text_report(self, authed_api_client: TestClient) -> None:
        sid = self._create_session_with_events(authed_api_client)
        resp = authed_api_client.get(f"/v1/authorship/sessions/{sid}/report/text")
        assert resp.status_code == 200
        assert "text/plain" in resp.headers["content-type"]
        assert "AUTHORSHIP PROVENANCE REPORT" in resp.text

    def test_unknown_session(self, authed_api_client: TestClient) -> None:
        resp = authed_api_client.get("/v1/authorship/sessions/nonexistent/report")
        assert resp.status_code == 404


class TestListSessions:
    def _create_session(self, client: TestClient, writer: str = "jane") -> str:
        resp = client.post(
            "/v1/authorship/sessions",
            json={"writer": writer, "tool": "claude"},
        )
        return resp.json()["session_id"]

    def test_empty_list(self, authed_api_client: TestClient) -> None:
        resp = authed_api_client.get("/v1/authorship/sessions")
        assert resp.status_code == 200
        data = resp.json()
        assert data["sessions"] == []
        assert data["total"] == 0

    def test_lists_created_sessions(self, authed_api_client: TestClient) -> None:
        self._create_session(authed_api_client)
        self._create_session(authed_api_client, writer="bob")
        resp = authed_api_client.get("/v1/authorship/sessions")
        assert resp.status_code == 200
        data = resp.json()
        assert data["total"] == 2
        assert len(data["sessions"]) == 2

    def test_filter_by_writer(self, authed_api_client: TestClient) -> None:
        self._create_session(authed_api_client, writer="jane")
        self._create_session(authed_api_client, writer="bob")
        resp = authed_api_client.get("/v1/authorship/sessions?writer=jane")
        data = resp.json()
        assert data["total"] == 1
        assert data["sessions"][0]["writer"] == "jane"

    def test_pagination(self, authed_api_client: TestClient) -> None:
        for i in range(5):
            self._create_session(authed_api_client, writer=f"writer-{i}")
        resp = authed_api_client.get("/v1/authorship/sessions?page_size=2&page=1")
        data = resp.json()
        assert len(data["sessions"]) == 2
        assert data["total"] == 5
        assert data["has_more"] is True

    def test_requires_auth(self, api_client: TestClient) -> None:
        state.api_keys = {"sk-test"}
        resp = api_client.get("/v1/authorship/sessions")
        assert resp.status_code == 401

    def test_session_metadata_shape(self, authed_api_client: TestClient) -> None:
        sid = self._create_session(authed_api_client)
        resp = authed_api_client.get("/v1/authorship/sessions")
        data = resp.json()
        session = data["sessions"][0]
        for key in ("session_id", "writer", "tool", "event_count", "work_agency", "started_at"):
            assert key in session, f"Missing key: {key}"
        assert session["session_id"] == sid


class TestAuthorshipTags:
    def test_authorship_endpoints_tagged(self, api_client: TestClient) -> None:
        from swarm_at.api.main import app

        schema = app.openapi()
        authorship_paths = [
            p for p in schema["paths"]
            if p.startswith("/v1/authorship")
        ]
        assert len(authorship_paths) >= 5
        for path in authorship_paths:
            for method_spec in schema["paths"][path].values():
                assert "authorship" in method_spec.get("tags", []), (
                    f"{path} missing authorship tag"
                )
