"""Tests for the adapter registry and SwarmAdapter Protocol."""

from __future__ import annotations

import importlib

import pytest

from swarm_at.adapters import (
    ADAPTER_REGISTRY,
    check_adapter,
    get_adapter,
    list_adapters,
)
from swarm_at.adapters.protocol import SwarmAdapter


# ---------------------------------------------------------------------------
# list_adapters
# ---------------------------------------------------------------------------


def test_list_adapters_returns_8() -> None:
    adapters = list_adapters()
    assert len(adapters) == 8
    assert adapters == sorted(adapters), "list_adapters() should be sorted"
    expected = {
        "autogen",
        "crewai",
        "haystack",
        "langgraph",
        "openai_agents",
        "openai_assistants",
        "polymarket",
        "strands",
    }
    assert set(adapters) == expected


# ---------------------------------------------------------------------------
# get_adapter — known adapters
# Our adapters have no external deps, so these always succeed.
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(
    ("name", "expected_class"),
    [
        ("langgraph", "SwarmNodeWrapper"),
        ("crewai", "SwarmTaskCallback"),
        ("autogen", "SwarmReplyCallback"),
        ("openai_assistants", "SwarmRunHandler"),
        ("openai_agents", "SwarmAgentHook"),
        ("strands", "SwarmStrandsCallback"),
        ("haystack", "SwarmSettlementComponent"),
        ("polymarket", "SwarmPolymarketAdapter"),
    ],
    ids=[
        "langgraph",
        "crewai",
        "autogen",
        "openai_assistants",
        "openai_agents",
        "strands",
        "haystack",
        "polymarket",
    ],
)
def test_get_adapter_returns_correct_class(name: str, expected_class: str) -> None:
    cls = get_adapter(name)
    assert cls.__name__ == expected_class
    assert isinstance(cls, type)


# Explicit named tests for the two called out in the spec
def test_get_adapter_langgraph() -> None:
    cls = get_adapter("langgraph")
    assert cls.__name__ == "SwarmNodeWrapper"


def test_get_adapter_crewai() -> None:
    cls = get_adapter("crewai")
    assert cls.__name__ == "SwarmTaskCallback"


# ---------------------------------------------------------------------------
# get_adapter — error cases
# ---------------------------------------------------------------------------


def test_get_adapter_unknown_raises_key_error() -> None:
    with pytest.raises(KeyError, match="nonexistent"):
        get_adapter("nonexistent")


def test_get_adapter_unknown_message_lists_available() -> None:
    with pytest.raises(KeyError) as exc_info:
        get_adapter("unknown_framework")
    # The error message should hint at valid names
    assert "Available" in str(exc_info.value)


# ---------------------------------------------------------------------------
# check_adapter
# ---------------------------------------------------------------------------


def test_check_adapter_returns_true_for_known() -> None:
    assert check_adapter("langgraph") is True
    assert check_adapter("polymarket") is True


def test_check_adapter_returns_false_for_unknown() -> None:
    assert check_adapter("nonexistent") is False


def test_check_adapter_returns_bool() -> None:
    result = check_adapter("crewai")
    assert isinstance(result, bool)
    result_bad = check_adapter("bad_name")
    assert isinstance(result_bad, bool)


@pytest.mark.parametrize("name", list_adapters(), ids=list_adapters())
def test_check_adapter_true_for_all_registered(name: str) -> None:
    """All 8 registered adapters are importable (no external deps)."""
    assert check_adapter(name) is True


# ---------------------------------------------------------------------------
# SwarmAdapter Protocol
# ---------------------------------------------------------------------------


def test_protocol_is_runtime_checkable() -> None:
    # runtime_checkable lets isinstance() work against the Protocol
    assert hasattr(SwarmAdapter, "__protocol_attrs__") or hasattr(
        SwarmAdapter, "_is_protocol"
    )
    # Verify isinstance() doesn't raise (it won't check method signatures,
    # just presence — that's the point of runtime_checkable)
    class FakeAdapter:
        def settle(self, action: str, agent_id: str, **kwargs: object) -> None:
            pass

    assert isinstance(FakeAdapter(), SwarmAdapter)


def test_protocol_rejects_object_without_settle() -> None:
    class NotAnAdapter:
        def publish(self) -> None:
            pass

    assert not isinstance(NotAnAdapter(), SwarmAdapter)


# ---------------------------------------------------------------------------
# Registry keys match valid module paths
# ---------------------------------------------------------------------------


def test_registry_keys_match_module_names() -> None:
    """Every value in ADAPTER_REGISTRY is a dot-path that ends with the key."""
    for name, module_path in ADAPTER_REGISTRY.items():
        # Module path must end with the adapter name
        assert module_path.endswith(name), (
            f"Registry entry {name!r} points to {module_path!r}, "
            f"expected it to end with {name!r}"
        )
        # Module path must be importable
        try:
            importlib.import_module(module_path)
        except ImportError as exc:
            pytest.fail(f"Could not import {module_path!r}: {exc}")


def test_registry_has_no_duplicates() -> None:
    module_paths = list(ADAPTER_REGISTRY.values())
    assert len(module_paths) == len(set(module_paths)), (
        "ADAPTER_REGISTRY contains duplicate module paths"
    )
