"""Tests for GET /v1/whoami — agent self-check endpoint."""

from __future__ import annotations

import pytest
from fastapi.testclient import TestClient

import swarm_at.api.state as api_state
from swarm_at.agents import AgentRole
from swarm_at.api.main import app


@pytest.fixture()
def authed_client() -> TestClient:
    api_state.api_keys = {"sk-test-key"}
    client = TestClient(app)
    client.headers["Authorization"] = "Bearer sk-test-key"
    return client


@pytest.fixture()
def registered_agent(authed_client: TestClient) -> str:
    """Register an agent and return its ID."""
    agent_id = "test-whoami-agent"
    api_state.agent_registry.register(
        agent_id=agent_id,
        role=AgentRole.WORKER,
        capabilities=["task-execution"],
    )
    return agent_id


class TestWhoami:
    """GET /v1/whoami"""

    def test_returns_agent_info(self, authed_client: TestClient, registered_agent: str) -> None:
        resp = authed_client.get(f"/v1/whoami?agent_id={registered_agent}")
        assert resp.status_code == 200
        data = resp.json()
        assert data["agent_id"] == registered_agent
        assert data["role"] == "worker"
        assert data["trust_level"] == "untrusted"

    def test_includes_reputation(self, authed_client: TestClient, registered_agent: str) -> None:
        resp = authed_client.get(f"/v1/whoami?agent_id={registered_agent}")
        data = resp.json()
        assert "reputation_score" in data
        assert "bayesian_lower_bound" in data

    def test_includes_cooldown(self, authed_client: TestClient, registered_agent: str) -> None:
        resp = authed_client.get(f"/v1/whoami?agent_id={registered_agent}")
        data = resp.json()
        assert "is_in_cooldown" in data
        assert data["is_in_cooldown"] is False
        assert "cooldown_until" in data

    def test_includes_review_status(self, authed_client: TestClient, registered_agent: str) -> None:
        resp = authed_client.get(f"/v1/whoami?agent_id={registered_agent}")
        data = resp.json()
        assert "under_review" in data
        assert data["under_review"] is False

    def test_includes_allowed_tools(self, authed_client: TestClient, registered_agent: str) -> None:
        resp = authed_client.get(f"/v1/whoami?agent_id={registered_agent}")
        data = resp.json()
        assert "allowed_tools" in data
        assert isinstance(data["allowed_tools"], list)

    def test_includes_next_promotion(self, authed_client: TestClient, registered_agent: str) -> None:
        resp = authed_client.get(f"/v1/whoami?agent_id={registered_agent}")
        data = resp.json()
        promo = data["next_promotion"]
        assert promo is not None
        assert promo["target_level"] == "provisional"
        assert "required_volume" in promo
        assert "required_lower_bound" in promo

    def test_senior_has_no_next_promotion(self, authed_client: TestClient) -> None:
        agent_id = "senior-whoami-agent"
        api_state.agent_registry.register(
            agent_id=agent_id,
            role=AgentRole.ORCHESTRATOR,
        )
        # Build up to senior trust
        for _ in range(150):
            api_state.agent_registry.record_settlement(agent_id, success=True, complexity=0.5)
        resp = authed_client.get(f"/v1/whoami?agent_id={agent_id}")
        data = resp.json()
        assert data["trust_level"] == "senior"
        assert data["next_promotion"] is None

    def test_not_found(self, authed_client: TestClient) -> None:
        resp = authed_client.get("/v1/whoami?agent_id=nonexistent-agent")
        assert resp.status_code == 404

    def test_requires_auth(self) -> None:
        api_state.api_keys = {"sk-test-key"}
        client = TestClient(app)
        resp = client.get("/v1/whoami?agent_id=test")
        assert resp.status_code == 401

    def test_requires_agent_id_param(self, authed_client: TestClient) -> None:
        resp = authed_client.get("/v1/whoami")
        assert resp.status_code == 422
