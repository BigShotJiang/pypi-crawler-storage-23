"""Tests for trust verification endpoints."""

from __future__ import annotations

import swarm_at.api.state as state
from swarm_at.agents import AgentRole, TrustLevel


class TestVerifyTrust:
    """GET /public/verify-trust endpoint."""

    def test_meets_requirement(self, api_client):
        agent = state.agent_registry.register("trusted-agent", role=AgentRole.WORKER)
        agent.trust_level = TrustLevel.TRUSTED
        resp = api_client.get(
            "/public/verify-trust",
            params={"agent_id": "trusted-agent", "min_trust": "trusted"},
        )
        assert resp.status_code == 200
        data = resp.json()
        assert data["agent_id"] == "trusted-agent"
        assert data["meets_requirement"] is True
        assert data["trust_level"] == "trusted"

    def test_below_threshold(self, api_client):
        state.agent_registry.register("newbie", role=AgentRole.WORKER)
        resp = api_client.get(
            "/public/verify-trust",
            params={"agent_id": "newbie", "min_trust": "trusted"},
        )
        assert resp.status_code == 200
        assert resp.json()["meets_requirement"] is False

    def test_unknown_agent_404(self, api_client):
        resp = api_client.get(
            "/public/verify-trust",
            params={"agent_id": "ghost", "min_trust": "trusted"},
        )
        assert resp.status_code == 404

    def test_invalid_trust_level_400(self, api_client):
        state.agent_registry.register("valid-agent", role=AgentRole.WORKER)
        resp = api_client.get(
            "/public/verify-trust",
            params={"agent_id": "valid-agent", "min_trust": "mega-trusted"},
        )
        assert resp.status_code == 400

    def test_untrusted_meets_untrusted(self, api_client):
        state.agent_registry.register("zero-agent", role=AgentRole.WORKER)
        resp = api_client.get(
            "/public/verify-trust",
            params={"agent_id": "zero-agent", "min_trust": "untrusted"},
        )
        assert resp.status_code == 200
        assert resp.json()["meets_requirement"] is True

    def test_includes_reputation_score(self, api_client):
        state.agent_registry.register("rep-agent", role=AgentRole.WORKER)
        resp = api_client.get(
            "/public/verify-trust",
            params={"agent_id": "rep-agent", "min_trust": "untrusted"},
        )
        assert "reputation_score" in resp.json()


class TestTrustSummary:
    """GET /public/trust-summary endpoint."""

    def test_empty_registry(self, api_client):
        resp = api_client.get("/public/trust-summary")
        assert resp.status_code == 200
        data = resp.json()
        assert data["total_agents"] == 0
        assert data["by_trust_level"]["untrusted"] == 0

    def test_counts_by_level(self, api_client):
        state.agent_registry.register("agent-x1", role=AgentRole.WORKER)
        a2 = state.agent_registry.register("agent-x2", role=AgentRole.WORKER)
        a2.trust_level = TrustLevel.TRUSTED
        resp = api_client.get("/public/trust-summary")
        data = resp.json()
        assert data["total_agents"] == 2
        assert data["by_trust_level"]["untrusted"] == 1
        assert data["by_trust_level"]["trusted"] == 1
