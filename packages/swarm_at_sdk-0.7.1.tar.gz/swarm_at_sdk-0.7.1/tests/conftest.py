"""Shared test fixtures and helpers for swarm.at.

Follows datasette-enrichments patterns:
- All shared fixtures in conftest.py
- autouse fixtures for state reset
- Factory functions for test data
- Helper functions for common assertions
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

import pytest
from fastapi.testclient import TestClient

import swarm_at.api.state as api_state
from swarm_at.agents import AgentRegistry
from swarm_at.api.main import app
from swarm_at.blueprints import BlueprintStore
from swarm_at.consensus import ConsensusEngine
from swarm_at.credits import CreditLedger
from swarm_at.engine import SwarmAtEngine
from swarm_at.heartbeat import SettlementPulse
from swarm_at.mcp.server import SettlementMCPServer
from swarm_at.models import Header, Payload, Proposal
from swarm_at.sdk.client import SwarmClient
from swarm_at.settler import GENESIS_HASH, Ledger
from swarm_at.webhooks import WebhookRegistry


# ---------------------------------------------------------------------------
# Proposal factories (like datasette-enrichments defines enrichment classes
# inline in conftest for all tests to share)
# ---------------------------------------------------------------------------


def make_proposal(
    parent_hash: str = GENESIS_HASH,
    confidence: float = 0.95,
    data: dict[str, Any] | None = None,
    task_id: str = "test-task-1",
) -> Proposal:
    """Build a Proposal with sensible defaults. Used across all test files."""
    return Proposal(
        header=Header(task_id=task_id, parent_hash=parent_hash),
        payload=Payload(
            data_update=data or {"result": "found"},
            confidence_score=confidence,
        ),
    )


def make_settle_request(
    parent_hash: str = GENESIS_HASH,
    confidence: float = 0.95,
    data: dict[str, Any] | None = None,
    task_id: str = "api-test-1",
) -> dict[str, Any]:
    """Build a JSON settle request body for API/SDK tests."""
    return {
        "primary": {
            "header": {
                "task_id": task_id,
                "parent_hash": parent_hash,
                "agent_metadata": {"model": "test", "version": "1.0"},
            },
            "payload": {
                "data_update": data or {"found": "result"},
                "confidence_score": confidence,
            },
        }
    }


# ---------------------------------------------------------------------------
# Assertion helpers (like datasette-enrichments' get_status())
# ---------------------------------------------------------------------------


def assert_settled(result: Any, *, hash_len: int = 64) -> str:
    """Assert a settlement result is SETTLED and return the hash."""
    if hasattr(result, "status"):
        # SettlementResult object
        assert result.status.value == "SETTLED"
        assert result.hash is not None
        assert len(result.hash) == hash_len
        return result.hash
    # Dict from API/SDK
    assert result["status"] == "SETTLED"
    assert result["hash"] is not None
    assert len(result["hash"]) == hash_len
    return result["hash"]


def assert_rejected(result: Any, *, reason_contains: str = "") -> None:
    """Assert a settlement result is REJECTED with optional reason check."""
    status = result.status.value if hasattr(result, "status") else result["status"]
    assert status == "REJECTED"
    if reason_contains:
        reason = result.reason if hasattr(result, "reason") else result.get("reason", "")
        assert reason_contains.lower() in reason.lower()


def assert_escrowed(result: Any) -> None:
    """Assert a settlement result is ESCROWED."""
    status = result.status.value if hasattr(result, "status") else result["status"]
    assert status == "ESCROWED"


def get_ledger_status(ledger: Ledger) -> dict[str, Any]:
    """Quick ledger status snapshot — like datasette-enrichments' get_status()."""
    return {
        "latest_hash": ledger.get_latest_hash(),
        "entry_count": len(ledger.read_all()),
        "chain_intact": ledger.verify_chain(),
    }


# ---------------------------------------------------------------------------
# Core fixtures — isolated ledger + engine per test
# (like datasette-enrichments creates a fresh Datasette per test)
# ---------------------------------------------------------------------------


@pytest.fixture()
def tmp_ledger(tmp_path: Path) -> Ledger:
    """Isolated ledger on temp filesystem."""
    return Ledger(path=tmp_path / "test_ledger.jsonl")


@pytest.fixture()
def engine(tmp_ledger: Ledger) -> SwarmAtEngine:
    """Engine wired to the temp ledger."""
    return SwarmAtEngine(ledger=tmp_ledger)


# ---------------------------------------------------------------------------
# API fixtures — reset global state before each test
# (like datasette-enrichments' autouse plugin fixture with try/finally cleanup)
# ---------------------------------------------------------------------------


@pytest.fixture(autouse=True)
def _reset_api_state(tmp_path: Path):
    """Reset API module state for every test. Autouse ensures no leakage.

    Follows the datasette-enrichments pattern of autouse + finally cleanup.
    """
    from swarm_at.workflow import WorkflowEngine

    tmp_ledger = Ledger(path=tmp_path / "api_ledger.jsonl")
    api_state.ledger = tmp_ledger
    api_state.engine = SwarmAtEngine(ledger=tmp_ledger)
    api_state.shared_state = {}
    api_state.api_keys = set()  # dev mode by default
    api_state.agent_registry = AgentRegistry()
    api_state.blueprint_store = BlueprintStore()
    api_state.credit_ledger = CreditLedger()
    api_state.webhook_registry = WebhookRegistry()
    api_state.workflow_engine = WorkflowEngine(engine=api_state.engine)
    api_state.jwt_auth = None
    from swarm_at.authorship import WritingSessionStore
    api_state.writing_sessions = WritingSessionStore()
    try:
        yield
    finally:
        api_state.api_keys = set()
        api_state.jwt_auth = None


@pytest.fixture()
def api_client() -> TestClient:
    """FastAPI TestClient for HTTP-level tests."""
    return TestClient(app)


@pytest.fixture()
def authed_api_client() -> TestClient:
    """API client with a valid Bearer token pre-configured."""
    api_state.api_keys = {"sk-test-key"}
    client = TestClient(app)
    client.headers["Authorization"] = "Bearer sk-test-key"
    return client


@pytest.fixture()
def sdk_client() -> SwarmClient:
    """SDK client backed by FastAPI TestClient transport."""
    test_client = TestClient(app)
    sdk = SwarmClient.__new__(SwarmClient)
    sdk.api_url = "http://testserver"
    sdk._http = test_client
    return sdk


# ---------------------------------------------------------------------------
# Component fixtures
# ---------------------------------------------------------------------------


@pytest.fixture()
def git_ledger(tmp_path: Path):
    """Git-backed ledger in temp directory."""
    from swarm_at.gitplane import GitLedger

    return GitLedger(repo_path=tmp_path / "git_repo")


@pytest.fixture()
def mcp_server(tmp_path: Path) -> SettlementMCPServer:
    """Isolated MCP server with its own ledger and seeded blueprints."""
    from swarm_at.seed_blueprints import seed_blueprints

    ledger = Ledger(path=tmp_path / "mcp_ledger.jsonl")
    store = BlueprintStore()
    seed_blueprints(store)
    return SettlementMCPServer(ledger=ledger, blueprint_store=store, credit_ledger=CreditLedger())


@pytest.fixture()
def consensus(tmp_path: Path) -> ConsensusEngine:
    """Consensus engine requiring 2 verifications."""
    ledger = Ledger(path=tmp_path / "consensus_ledger.jsonl")
    engine = SwarmAtEngine(ledger=ledger)
    return ConsensusEngine(engine=engine, required_verifications=2)


@pytest.fixture()
def pulse(tmp_path: Path) -> SettlementPulse:
    """Settlement pulse with 1-second interval for fast tests."""
    ledger = Ledger(path=tmp_path / "pulse_ledger.jsonl")
    engine = SwarmAtEngine(ledger=ledger)
    return SettlementPulse(engine=engine, agent_id="test-agent", interval_seconds=1.0)


@pytest.fixture()
def registry() -> AgentRegistry:
    """Fresh agent registry."""
    return AgentRegistry()


@pytest.fixture()
def workflow_engine(tmp_path: Path):
    """Workflow engine with isolated ledger."""
    from swarm_at.workflow import WorkflowEngine

    ledger = Ledger(path=tmp_path / "workflow_ledger.jsonl")
    engine = SwarmAtEngine(ledger=ledger)
    return WorkflowEngine(engine=engine)


@pytest.fixture(autouse=True)
def _reset_settle_context():
    """Reset settle module singleton between tests. Prevents leakage."""
    from swarm_at.settle import reset_context

    reset_context()
    yield
    reset_context()
