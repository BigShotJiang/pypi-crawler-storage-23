"""Tests for Settlement Pulse (Heartbeat)."""

from __future__ import annotations

import pytest

from swarm_at.heartbeat import SettlementPulse



class TestDriftDetection:
    def test_drift_detected_on_nonempty_state(self, pulse: SettlementPulse) -> None:
        result = pulse.check_drift({"some": "state"})
        assert result.drifted is True
        assert "!=" in result.details

    def test_drift_result_has_both_hashes(self, pulse: SettlementPulse) -> None:
        result = pulse.check_drift({})
        assert len(result.local_hash) == 64
        assert len(result.ledger_hash) == 64


class TestPulse:
    def test_pulse_settles_to_ledger(self, pulse: SettlementPulse) -> None:
        result = pulse.pulse({"tasks_completed": 3, "status": "healthy"})
        assert result["status"] == "SETTLED"
        assert result["hash"] is not None
        assert result["timestamp"] > 0

    def test_chained_pulses(self, pulse: SettlementPulse) -> None:
        r1 = pulse.pulse({"step": 1})
        r2 = pulse.pulse({"step": 2})
        assert r1["hash"] != r2["hash"]
        assert pulse.engine.ledger.verify_chain() is True

    @pytest.mark.parametrize("field, expected", [
        ("type", "settlement_pulse"),
        ("agent_id", "test-agent"),
    ])
    def test_pulse_content_in_ledger(self, pulse: SettlementPulse, field: str, expected: str) -> None:
        pulse.pulse({"tasks_completed": 5})
        entry = pulse.engine.ledger.read_all()[0]
        assert entry.payload[field] == expected

    def test_work_summary_persisted(self, pulse: SettlementPulse) -> None:
        pulse.pulse({"tasks_completed": 5})
        entry = pulse.engine.ledger.read_all()[0]
        assert entry.payload["work_summary"]["tasks_completed"] == 5


class TestScheduling:
    def test_is_due_initially(self, pulse: SettlementPulse) -> None:
        assert pulse.is_due() is True

    def test_not_due_after_pulse(self, pulse: SettlementPulse) -> None:
        pulse.pulse({"status": "ok"})
        assert pulse.is_due() is False

    def test_pulse_if_due_returns_none_when_not_due(self, pulse: SettlementPulse) -> None:
        pulse.pulse({"status": "ok"})
        assert pulse.pulse_if_due({"status": "again"}) is None

    def test_pulse_if_due_fires_when_due(self, pulse: SettlementPulse) -> None:
        pulse._last_pulse = 0.0
        result = pulse.pulse_if_due({"status": "overdue"})
        assert result is not None
        assert result["status"] == "SETTLED"

    def test_last_pulse_time_updates(self, pulse: SettlementPulse) -> None:
        assert pulse.last_pulse_time == 0.0
        pulse.pulse({"status": "ok"})
        assert pulse.last_pulse_time > 0.0
