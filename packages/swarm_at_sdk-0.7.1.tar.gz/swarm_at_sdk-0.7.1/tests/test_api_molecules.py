"""Tests for GET /v1/molecules and GET /v1/molecules/{molecule_id}."""

from __future__ import annotations

import pytest
from fastapi.testclient import TestClient

import swarm_at.api.state as api_state
from swarm_at.api.main import app


# ---------------------------------------------------------------------------
# Fixtures (conftest autouse _reset_api_state handles state isolation)
# ---------------------------------------------------------------------------


@pytest.fixture()
def api_client() -> TestClient:
    return TestClient(app)


@pytest.fixture()
def authed_api_client() -> TestClient:
    api_state.api_keys = {"sk-test-key"}
    client = TestClient(app)
    client.headers["Authorization"] = "Bearer sk-test-key"
    return client


def _seed_blueprints() -> None:
    from swarm_at.seed_blueprints import seed_blueprints
    seed_blueprints(api_state.blueprint_store)


def _fork(client: TestClient, blueprint_id: str = "audit-chain", agent_id: str = "agent-x") -> str:
    """Fork a blueprint and return the molecule_id."""
    api_state.credit_ledger.register(agent_id, initial_balance=500.0)
    r = client.post(f"/v1/blueprints/{blueprint_id}/fork?agent_id={agent_id}")
    assert r.status_code == 200, r.text
    return r.json()["molecule_id"]


# ---------------------------------------------------------------------------
# List molecules
# ---------------------------------------------------------------------------


class TestListMolecules:
    def test_list_molecules_empty(self, authed_api_client: TestClient) -> None:
        r = authed_api_client.get("/v1/molecules")
        assert r.status_code == 200
        body = r.json()
        assert body["molecules"] == []
        assert body["total"] == 0

    def test_list_molecules_after_fork(self, authed_api_client: TestClient) -> None:
        _seed_blueprints()
        molecule_id = _fork(authed_api_client)
        r = authed_api_client.get("/v1/molecules")
        assert r.status_code == 200
        body = r.json()
        assert body["total"] == 1
        mol = body["molecules"][0]
        assert mol["molecule_id"] == molecule_id
        assert mol["bead_count"] > 0
        assert mol["status"] == "pending"
        assert "progress" in mol
        assert "created_at" in mol

    def test_list_returns_pagination_fields(self, authed_api_client: TestClient) -> None:
        r = authed_api_client.get("/v1/molecules?limit=10&offset=0")
        assert r.status_code == 200
        body = r.json()
        assert body["limit"] == 10
        assert body["offset"] == 0

    def test_list_requires_auth(self, api_client: TestClient) -> None:
        api_state.api_keys = {"sk-test-key"}
        r = api_client.get("/v1/molecules")
        assert r.status_code == 401


# ---------------------------------------------------------------------------
# Get molecule
# ---------------------------------------------------------------------------


class TestGetMolecule:
    def test_get_molecule(self, authed_api_client: TestClient) -> None:
        _seed_blueprints()
        molecule_id = _fork(authed_api_client)
        r = authed_api_client.get(f"/v1/molecules/{molecule_id}")
        assert r.status_code == 200
        body = r.json()
        assert body["molecule_id"] == molecule_id
        assert "name" in body
        assert "status" in body
        assert "progress" in body
        assert "beads" in body
        assert isinstance(body["beads"], list)
        assert len(body["beads"]) > 0

    def test_get_molecule_bead_fields(self, authed_api_client: TestClient) -> None:
        _seed_blueprints()
        molecule_id = _fork(authed_api_client)
        r = authed_api_client.get(f"/v1/molecules/{molecule_id}")
        assert r.status_code == 200
        bead = r.json()["beads"][0]
        assert "bead_id" in bead
        assert "name" in bead
        assert "status" in bead
        assert bead["status"] == "pending"
        assert "depends_on" in bead
        assert "settlement_hash" in bead

    def test_get_molecule_not_found(self, authed_api_client: TestClient) -> None:
        r = authed_api_client.get("/v1/molecules/does-not-exist")
        assert r.status_code == 404
        assert "not found" in r.json()["detail"].lower()

    def test_get_requires_auth(self, api_client: TestClient) -> None:
        api_state.api_keys = {"sk-test-key"}
        r = api_client.get("/v1/molecules/some-id")
        assert r.status_code == 401


# ---------------------------------------------------------------------------
# Filter by agent
# ---------------------------------------------------------------------------


class TestFilterByAgent:
    def test_filter_by_agent(self, authed_api_client: TestClient) -> None:
        _seed_blueprints()
        mol_a = _fork(authed_api_client, agent_id="agent-alice")
        _fork(authed_api_client, agent_id="agent-bob")

        r = authed_api_client.get("/v1/molecules?agent_id=agent-alice")
        assert r.status_code == 200
        body = r.json()
        assert body["total"] == 1
        assert body["molecules"][0]["molecule_id"] == mol_a

    def test_filter_returns_empty_for_unknown_agent(self, authed_api_client: TestClient) -> None:
        _seed_blueprints()
        _fork(authed_api_client, agent_id="agent-alice")

        r = authed_api_client.get("/v1/molecules?agent_id=nobody")
        assert r.status_code == 200
        assert r.json()["total"] == 0

    def test_no_filter_returns_all(self, authed_api_client: TestClient) -> None:
        _seed_blueprints()
        _fork(authed_api_client, agent_id="agent-alice")
        _fork(authed_api_client, agent_id="agent-bob")

        r = authed_api_client.get("/v1/molecules")
        assert r.status_code == 200
        assert r.json()["total"] == 2
