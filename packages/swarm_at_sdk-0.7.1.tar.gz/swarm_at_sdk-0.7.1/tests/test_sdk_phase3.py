"""Tests for SDK Phase 3 methods: credits, fork, and auth."""

from __future__ import annotations

import pytest

import swarm_at.api.state as api_state
from swarm_at.auth import JWTAuth
from swarm_at.sdk.client import SwarmClient
from swarm_at.sdk.errors import NotFoundError, SwarmError
from swarm_at.seed_blueprints import seed_blueprints


@pytest.fixture()
def sdk_client() -> SwarmClient:
    """SDK client backed by authed TestClient transport."""
    from fastapi.testclient import TestClient
    from swarm_at.api.main import app

    api_state.api_keys = {"sk-test-key"}
    test_client = TestClient(app)
    test_client.headers["Authorization"] = "Bearer sk-test-key"
    sdk = SwarmClient.__new__(SwarmClient)
    sdk.api_url = "http://testserver"
    sdk._http = test_client
    return sdk


class TestGetCredits:
    def test_returns_balance_for_registered_agent(self, sdk_client: SwarmClient) -> None:
        api_state.credit_ledger.register("agent-a", initial_balance=50.0)
        data = sdk_client.get_credits("agent-a")
        assert data["agent_id"] == "agent-a"
        assert data["balance"] == 50.0

    def test_raises_on_unknown_agent(self, sdk_client: SwarmClient) -> None:
        with pytest.raises(NotFoundError) as exc_info:
            sdk_client.get_credits("unknown-agent")
        assert exc_info.value.status_code == 404


class TestTopupCredits:
    def test_adds_credits(self, sdk_client: SwarmClient) -> None:
        api_state.credit_ledger.register("agent-b", initial_balance=10.0)
        data = sdk_client.topup_credits("agent-b", amount=25.0)
        assert data["agent_id"] == "agent-b"
        assert data["balance"] == 35.0

    def test_topup_unknown_agent_creates(self, sdk_client: SwarmClient) -> None:
        # topup auto-registers with default balance (100.0) then adds amount
        data = sdk_client.topup_credits("new-agent", amount=100.0)
        assert data["agent_id"] == "new-agent"
        assert data["balance"] == 200.0  # default 100.0 + topup 100.0


class TestForkBlueprint:
    @pytest.fixture()
    def seeded_store(self):
        seed_blueprints(api_state.blueprint_store)

    def test_returns_molecule_with_bead_count(
        self, sdk_client: SwarmClient, seeded_store,
    ) -> None:
        # audit-chain costs 3.0 credits
        api_state.credit_ledger.register("tester", initial_balance=10.0)
        data = sdk_client.fork_blueprint("audit-chain", agent_id="tester")
        assert "molecule_id" in data
        assert data["name"] == "Audit Chain"
        assert data["bead_count"] == 3
        assert "metadata" in data

    def test_defaults_to_anonymous(
        self, sdk_client: SwarmClient, seeded_store,
    ) -> None:
        # research-workflow costs 4.0 credits
        api_state.credit_ledger.register("anonymous", initial_balance=10.0)
        data = sdk_client.fork_blueprint("research-workflow")
        assert data["name"] == "Research Workflow"
        assert data["bead_count"] == 3

    def test_raises_on_unknown_blueprint(self, sdk_client: SwarmClient) -> None:
        with pytest.raises(NotFoundError) as exc_info:
            sdk_client.fork_blueprint("nonexistent-blueprint")
        assert exc_info.value.status_code == 404

    def test_raises_402_when_insufficient_credits(
        self, sdk_client: SwarmClient, seeded_store,
    ) -> None:
        api_state.credit_ledger.register("broke-agent", initial_balance=1.0)
        with pytest.raises(SwarmError) as exc_info:
            sdk_client.fork_blueprint("audit-chain", agent_id="broke-agent")
        assert exc_info.value.status_code == 402


class TestCreateToken:
    def test_returns_token_when_jwt_configured(self, sdk_client: SwarmClient) -> None:
        api_state.jwt_auth = JWTAuth(secret="test-secret-at-least-32-bytes!!")
        data = sdk_client.create_token("token-agent", role="worker")
        assert "token" in data
        assert data["agent_id"] == "token-agent"
        assert data["role"] == "worker"
        assert isinstance(data["token"], str)
        assert len(data["token"]) > 0

    def test_defaults_to_worker_role(self, sdk_client: SwarmClient) -> None:
        api_state.jwt_auth = JWTAuth(secret="test-secret-at-least-32-bytes!!")
        data = sdk_client.create_token("default-role-agent")
        assert data["role"] == "worker"

    def test_raises_501_when_jwt_not_configured(self, sdk_client: SwarmClient) -> None:
        api_state.jwt_auth = None
        with pytest.raises(SwarmError) as exc_info:
            sdk_client.create_token("no-jwt-agent")
        assert exc_info.value.status_code == 501
