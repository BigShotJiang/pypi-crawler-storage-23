"""Tests for credit incentives: auto-seed, author rewards, free tier, blueprint publish."""

from __future__ import annotations

import swarm_at.api.state as state
from swarm_at.blueprints import Blueprint, BlueprintStep
from swarm_at.credits import FREE_SETTLEMENT_QUOTA, CreditLedger


class TestAutoSeedCredits:
    """Agent registration auto-seeds 100 credits."""

    def test_register_seeds_credits(self, authed_api_client):
        resp = authed_api_client.post(
            "/v1/agents/register",
            json={"agent_id": "seed-agent", "role": "worker"},
        )
        assert resp.status_code == 200
        data = resp.json()
        assert data["credits"] == 100.0

    def test_credits_queryable_after_register(self, authed_api_client):
        authed_api_client.post(
            "/v1/agents/register",
            json={"agent_id": "query-agent", "role": "worker"},
        )
        resp = authed_api_client.get("/v1/credits/query-agent")
        assert resp.status_code == 200
        assert resp.json()["balance"] == 100.0


class TestAuthorRewards:
    """Forking a blueprint credits the author."""

    def _setup_author_blueprint(self):
        """Register a validated blueprint by an external author."""
        bp = Blueprint(
            blueprint_id="author-bp",
            name="Author Test",
            author="author-agent",
            credit_cost=10.0,
            author_reward_rate=0.1,
            validated=True,
            steps=[BlueprintStep(step_id="s1", name="step1")],
        )
        state.blueprint_store.register_blueprint(bp)
        state.credit_ledger.register("author-agent")
        state.credit_ledger.register("forker-agent", initial_balance=200.0)

    def test_fork_credits_author(self, authed_api_client):
        self._setup_author_blueprint()
        author_before = state.credit_ledger.balance("author-agent")
        authed_api_client.post(
            "/v1/blueprints/author-bp/fork",
            params={"agent_id": "forker-agent"},
        )
        author_after = state.credit_ledger.balance("author-agent")
        assert author_after == author_before + 1.0  # 10% of 10.0

    def test_author_reward_skipped_for_swarm_at(self, authed_api_client):
        bp = Blueprint(
            blueprint_id="internal-bp",
            name="Internal",
            author="swarm.at",
            credit_cost=10.0,
            validated=True,
            steps=[BlueprintStep(step_id="s1", name="step1")],
        )
        state.blueprint_store.register_blueprint(bp)
        state.credit_ledger.register("fork-user", initial_balance=200.0)

        authed_api_client.post(
            "/v1/blueprints/internal-bp/fork",
            params={"agent_id": "fork-user"},
        )
        # swarm.at shouldn't have a credit balance at all (not registered)
        assert "swarm.at" not in state.credit_ledger.all_balances()


class TestFreeTier:
    """debit_or_free() skips debit within quota."""

    def test_free_within_quota(self):
        cl = CreditLedger()
        cl.register("free-agent", initial_balance=50.0)
        balance, remaining = cl.debit_or_free("free-agent", 1.0)
        assert balance == 50.0  # no debit
        assert remaining == FREE_SETTLEMENT_QUOTA - 1

    def test_free_quota_exhausted(self):
        cl = CreditLedger()
        cl.register("paid-agent", initial_balance=200.0)
        # Exhaust free quota
        for _ in range(FREE_SETTLEMENT_QUOTA):
            cl.debit_or_free("paid-agent", 1.0)
        # Next one should debit
        balance, remaining = cl.debit_or_free("paid-agent", 1.0)
        assert balance == 199.0
        assert remaining == 0

    def test_free_counter_tracks_per_agent(self):
        cl = CreditLedger()
        cl.register("agent-a", initial_balance=100.0)
        cl.register("agent-b", initial_balance=100.0)
        cl.debit_or_free("agent-a", 1.0)
        _, remaining_b = cl.debit_or_free("agent-b", 1.0)
        assert remaining_b == FREE_SETTLEMENT_QUOTA - 1  # independent counter


class TestBlueprintPublish:
    """POST /v1/blueprints/publish creates unvalidated blueprint."""

    def test_publish_creates_blueprint(self, authed_api_client):
        resp = authed_api_client.post(
            "/v1/blueprints/publish",
            json={
                "name": "My Blueprint",
                "description": "Test",
                "tags": ["test"],
                "steps": [{"step_id": "s1", "name": "Do thing"}],
                "credit_cost": 5.0,
                "agent_id": "publisher",
            },
        )
        assert resp.status_code == 200
        data = resp.json()
        assert data["name"] == "My Blueprint"
        assert data["author"] == "publisher"
        assert data["validated"] is False
        assert data["step_count"] == 1

    def test_publish_blueprint_visible_publicly(self, authed_api_client, api_client):
        resp = authed_api_client.post(
            "/v1/blueprints/publish",
            json={
                "name": "Public BP",
                "tags": ["public"],
                "credit_cost": 2.0,
                "agent_id": "pub-agent",
            },
        )
        bp_id = resp.json()["blueprint_id"]
        detail = api_client.get(f"/public/blueprints/{bp_id}")
        assert detail.status_code == 200
        assert detail.json()["name"] == "Public BP"

    def test_publish_requires_auth(self, api_client):
        state.api_keys = {"sk-test-key"}
        resp = api_client.post(
            "/v1/blueprints/publish",
            json={"name": "No Auth", "agent_id": "anon"},
        )
        assert resp.status_code == 401
