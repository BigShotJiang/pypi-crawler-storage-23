"""Tests for the trust badge endpoint and SVG generator."""

from __future__ import annotations

import pytest
from fastapi.testclient import TestClient

import swarm_at.api.state as api_state
from swarm_at.openclaw import generate_trust_badge


class TestGenerateTrustBadge:
    """Pure function tests for SVG badge generation."""

    @pytest.mark.parametrize(
        "level, expected_color",
        [
            ("untrusted", "#e05d44"),
            ("provisional", "#dfb317"),
            ("trusted", "#4c1"),
            ("senior", "#007ec6"),
        ],
        ids=["untrusted-red", "provisional-yellow", "trusted-green", "senior-blue"],
    )
    def test_badge_colors(self, level: str, expected_color: str) -> None:
        svg = generate_trust_badge("test-agent", level)
        assert expected_color in svg
        assert "<svg" in svg
        assert level in svg


class TestBadgeEndpoint:
    """API-level tests for GET /badge/{agent_id}."""

    def test_badge_returns_svg(self, api_client: TestClient) -> None:
        api_state.agent_registry.register("badge-agent")
        resp = api_client.get("/badge/badge-agent")
        assert resp.status_code == 200
        assert "image/svg+xml" in resp.headers["content-type"]
        assert "<svg" in resp.text

    def test_badge_404_unknown_agent(self, api_client: TestClient) -> None:
        resp = api_client.get("/badge/nonexistent-agent")
        assert resp.status_code == 404

    def test_badge_shows_trust_level(self, api_client: TestClient) -> None:
        api_state.agent_registry.register("trusted-badge")
        for _ in range(25):
            api_state.agent_registry.record_settlement("trusted-badge", success=True)
        resp = api_client.get("/badge/trusted-badge")
        assert resp.status_code == 200
        assert "trusted" in resp.text
