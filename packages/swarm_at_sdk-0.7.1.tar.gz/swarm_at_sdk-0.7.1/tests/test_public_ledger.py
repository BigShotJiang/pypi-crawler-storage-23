"""Tests for public read-only ledger endpoints."""

from __future__ import annotations

from fastapi.testclient import TestClient

import swarm_at.api.state as api_state
from tests.conftest import make_settle_request


class TestPublicLedger:
    """GET /public/ledger — paginated entries list."""

    def test_empty_ledger_returns_empty_list(self, api_client: TestClient) -> None:
        resp = api_client.get("/public/ledger")
        assert resp.status_code == 200
        data = resp.json()
        assert data["entries"] == []
        assert data["total"] == 0

    def test_returns_entries_after_settlement(self, api_client: TestClient) -> None:
        api_client.post("/v1/settle", json=make_settle_request(task_id="pub-1"))
        resp = api_client.get("/public/ledger")
        assert resp.status_code == 200
        data = resp.json()
        assert data["total"] == 1
        assert data["entries"][0]["task_id"] == "pub-1"

    def test_pagination_offset_and_limit(self, api_client: TestClient) -> None:
        for i in range(5):
            prev = api_client.get("/public/ledger/latest").json()["latest_hash"]
            api_client.post(
                "/v1/settle",
                json=make_settle_request(task_id=f"pub-{i}", parent_hash=prev),
            )
        resp = api_client.get("/public/ledger", params={"offset": 1, "limit": 2})
        data = resp.json()
        assert data["total"] == 5
        assert len(data["entries"]) == 2
        assert data["entries"][0]["task_id"] == "pub-1"
        assert data["offset"] == 1
        assert data["limit"] == 2

    def test_no_auth_required_when_auth_enabled(self, api_client: TestClient) -> None:
        """Public endpoints work even when API auth is enabled."""
        api_state.api_keys = {"sk-secret"}
        resp = api_client.get("/public/ledger")
        assert resp.status_code == 200


class TestPublicLedgerLatest:
    """GET /public/ledger/latest"""

    def test_returns_genesis_hash_on_empty(self, api_client: TestClient) -> None:
        resp = api_client.get("/public/ledger/latest")
        assert resp.status_code == 200
        assert resp.json()["latest_hash"] == "0" * 64

    def test_returns_latest_after_settlement(self, api_client: TestClient) -> None:
        api_client.post("/v1/settle", json=make_settle_request())
        resp = api_client.get("/public/ledger/latest")
        assert resp.status_code == 200
        assert len(resp.json()["latest_hash"]) == 64
        assert resp.json()["latest_hash"] != "0" * 64

    def test_no_auth_required(self, api_client: TestClient) -> None:
        api_state.api_keys = {"sk-secret"}
        resp = api_client.get("/public/ledger/latest")
        assert resp.status_code == 200


class TestPublicLedgerVerify:
    """GET /public/ledger/verify"""

    def test_empty_chain_is_intact(self, api_client: TestClient) -> None:
        resp = api_client.get("/public/ledger/verify")
        assert resp.status_code == 200
        data = resp.json()
        assert data["intact"] is True
        assert data["entry_count"] == 0

    def test_chain_intact_after_settlements(self, api_client: TestClient) -> None:
        api_client.post("/v1/settle", json=make_settle_request(task_id="v-1"))
        resp = api_client.get("/public/ledger/verify")
        data = resp.json()
        assert data["intact"] is True
        assert data["entry_count"] == 1

    def test_no_auth_required(self, api_client: TestClient) -> None:
        api_state.api_keys = {"sk-secret"}
        resp = api_client.get("/public/ledger/verify")
        assert resp.status_code == 200


class TestPublicLedgerEntry:
    """GET /public/ledger/entry/{task_id}"""

    def test_returns_entry_by_task_id(self, api_client: TestClient) -> None:
        api_client.post("/v1/settle", json=make_settle_request(task_id="lookup-1"))
        resp = api_client.get("/public/ledger/entry/lookup-1")
        assert resp.status_code == 200
        assert resp.json()["task_id"] == "lookup-1"

    def test_404_for_unknown_task_id(self, api_client: TestClient) -> None:
        resp = api_client.get("/public/ledger/entry/nonexistent")
        assert resp.status_code == 404

    def test_no_auth_required(self, api_client: TestClient) -> None:
        api_state.api_keys = {"sk-secret"}
        api_client.post(
            "/v1/settle",
            json=make_settle_request(task_id="auth-test"),
            headers={"Authorization": "Bearer sk-secret"},
        )
        # Public endpoint works without auth
        resp = api_client.get("/public/ledger/entry/auth-test")
        assert resp.status_code == 200
