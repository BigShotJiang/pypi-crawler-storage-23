"""Test rate limiting for public endpoints."""

from __future__ import annotations

import pytest
from fastapi.testclient import TestClient


def test_rate_limit_headers_present(api_client: TestClient) -> None:
    """Rate-limited endpoints should include X-RateLimit headers."""
    resp = api_client.get("/public/ledger")
    assert resp.status_code == 200
    assert "X-RateLimit-Limit" in resp.headers
    assert "X-RateLimit-Remaining" in resp.headers
    # Limit should be 60 for public/ledger
    assert resp.headers["X-RateLimit-Limit"] == "60"


def test_public_blueprints_rate_limit(api_client: TestClient) -> None:
    """Public blueprints endpoint should have 60/minute rate limit."""
    resp = api_client.get("/public/blueprints")
    assert resp.status_code == 200
    assert "X-RateLimit-Limit" in resp.headers
    assert resp.headers["X-RateLimit-Limit"] == "60"

    # Remaining should decrease with each request
    first_remaining = int(resp.headers["X-RateLimit-Remaining"])

    resp2 = api_client.get("/public/blueprints?page=2")
    assert resp2.status_code == 200
    second_remaining = int(resp2.headers["X-RateLimit-Remaining"])

    assert second_remaining < first_remaining


def test_public_agents_rate_limit(api_client: TestClient) -> None:
    """Public agents endpoint should have 60/minute rate limit."""
    resp = api_client.get("/public/agents")
    assert resp.status_code == 200
    assert "X-RateLimit-Limit" in resp.headers
    assert resp.headers["X-RateLimit-Limit"] == "60"


def test_public_ledger_rate_limit(api_client: TestClient) -> None:
    """Public ledger endpoint should have 60/minute rate limit."""
    resp = api_client.get("/public/ledger")
    assert resp.status_code == 200
    assert "X-RateLimit-Limit" in resp.headers
    assert resp.headers["X-RateLimit-Limit"] == "60"


@pytest.mark.parametrize(
    "endpoint,method",
    [
        ("/public/blueprints", "GET"),
        ("/public/agents", "GET"),
        ("/public/ledger", "GET"),
    ],
    ids=["blueprints", "agents", "ledger"],
)
def test_rate_limit_headers_format(
    api_client: TestClient, endpoint: str, method: str
) -> None:
    """All rate-limited endpoints should have properly formatted headers."""
    if method == "GET":
        resp = api_client.get(endpoint)
    else:
        resp = api_client.post(endpoint, json={})

    assert resp.status_code == 200
    assert "X-RateLimit-Limit" in resp.headers
    assert "X-RateLimit-Remaining" in resp.headers

    # Headers should be integers
    limit = int(resp.headers["X-RateLimit-Limit"])
    remaining = int(resp.headers["X-RateLimit-Remaining"])

    assert limit > 0
    assert remaining >= 0
    assert remaining <= limit
