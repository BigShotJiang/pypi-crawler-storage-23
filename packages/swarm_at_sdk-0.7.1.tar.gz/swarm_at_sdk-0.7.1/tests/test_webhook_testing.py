"""Tests for the POST /v1/webhooks/test endpoint and SDK test_webhook method."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import httpx
import pytest
from fastapi.testclient import TestClient

import swarm_at.api.state as state
from swarm_at.sdk.client import SwarmClient


class TestWebhookTestEndpoint:
    """Tests for POST /v1/webhooks/test."""

    def test_successful_delivery(self, authed_api_client: TestClient):
        """Returns delivered status and response code on success."""
        mock_response = MagicMock()
        mock_response.status_code = 200

        with patch("httpx.Client") as mock_client_cls:
            mock_client = MagicMock()
            mock_client.__enter__ = MagicMock(return_value=mock_client)
            mock_client.__exit__ = MagicMock(return_value=False)
            mock_client.post.return_value = mock_response
            mock_client_cls.return_value = mock_client

            resp = authed_api_client.post(
                "/v1/webhooks/test",
                json={"url": "https://example.com/hook", "event": "settlement.created"},
            )

        assert resp.status_code == 200
        data = resp.json()
        assert data["status"] == "delivered"
        assert data["status_code"] == 200
        assert "response_time_ms" in data
        assert isinstance(data["response_time_ms"], int)

    def test_successful_delivery_non_200_receiver(self, authed_api_client: TestClient):
        """Reports the receiver's actual status code even when it's not 200."""
        mock_response = MagicMock()
        mock_response.status_code = 404

        with patch("httpx.Client") as mock_client_cls:
            mock_client = MagicMock()
            mock_client.__enter__ = MagicMock(return_value=mock_client)
            mock_client.__exit__ = MagicMock(return_value=False)
            mock_client.post.return_value = mock_response
            mock_client_cls.return_value = mock_client

            resp = authed_api_client.post(
                "/v1/webhooks/test",
                json={"url": "https://example.com/hook", "event": "settlement.created"},
            )

        assert resp.status_code == 200
        data = resp.json()
        assert data["status"] == "delivered"
        assert data["status_code"] == 404

    def test_failed_delivery_connection_refused(self, authed_api_client: TestClient):
        """Returns failed status with error message on connection refused."""
        with patch("httpx.Client") as mock_client_cls:
            mock_client = MagicMock()
            mock_client.__enter__ = MagicMock(return_value=mock_client)
            mock_client.__exit__ = MagicMock(return_value=False)
            mock_client.post.side_effect = httpx.ConnectError("Connection refused")
            mock_client_cls.return_value = mock_client

            resp = authed_api_client.post(
                "/v1/webhooks/test",
                json={"url": "https://example.com/hook", "event": "settlement.created"},
            )

        assert resp.status_code == 200
        data = resp.json()
        assert data["status"] == "failed"
        assert data["error"] == "Connection refused"

    def test_failed_delivery_timeout(self, authed_api_client: TestClient):
        """Returns failed status with timeout error message."""
        with patch("httpx.Client") as mock_client_cls:
            mock_client = MagicMock()
            mock_client.__enter__ = MagicMock(return_value=mock_client)
            mock_client.__exit__ = MagicMock(return_value=False)
            mock_client.post.side_effect = httpx.TimeoutException("timed out")
            mock_client_cls.return_value = mock_client

            resp = authed_api_client.post(
                "/v1/webhooks/test",
                json={"url": "https://example.com/hook", "event": "settlement.created"},
            )

        assert resp.status_code == 200
        data = resp.json()
        assert data["status"] == "failed"
        assert data["error"] == "Request timed out"

    def test_requires_auth(self, api_client: TestClient):
        """Endpoint requires authentication."""
        state.api_keys = {"sk-test-key"}
        resp = api_client.post(
            "/v1/webhooks/test",
            json={"url": "https://example.com/hook", "event": "settlement.created"},
        )
        assert resp.status_code == 401

    def test_invalid_url_missing_returns_422(self, authed_api_client: TestClient):
        """Missing URL field returns 422 validation error."""
        resp = authed_api_client.post(
            "/v1/webhooks/test",
            json={"event": "settlement.created"},
        )
        assert resp.status_code == 422

    def test_default_event_is_settlement_created(self, authed_api_client: TestClient):
        """Event defaults to settlement.created when omitted."""
        mock_response = MagicMock()
        mock_response.status_code = 200
        captured: list[dict] = []  # type: ignore[type-arg]

        def capture_post(url: str, json: dict) -> MagicMock:  # type: ignore[type-arg]
            captured.append(json)
            return mock_response

        with patch("httpx.Client") as mock_client_cls:
            mock_client = MagicMock()
            mock_client.__enter__ = MagicMock(return_value=mock_client)
            mock_client.__exit__ = MagicMock(return_value=False)
            mock_client.post.side_effect = capture_post
            mock_client_cls.return_value = mock_client

            resp = authed_api_client.post(
                "/v1/webhooks/test",
                json={"url": "https://example.com/hook"},
            )

        assert resp.status_code == 200
        assert len(captured) == 1
        assert captured[0]["event"] == "settlement.created"

    def test_payload_includes_test_flag(self, authed_api_client: TestClient):
        """Outbound payload marks the request as a test."""
        mock_response = MagicMock()
        mock_response.status_code = 200
        captured: list[dict] = []  # type: ignore[type-arg]

        def capture_post(url: str, json: dict) -> MagicMock:  # type: ignore[type-arg]
            captured.append(json)
            return mock_response

        with patch("httpx.Client") as mock_client_cls:
            mock_client = MagicMock()
            mock_client.__enter__ = MagicMock(return_value=mock_client)
            mock_client.__exit__ = MagicMock(return_value=False)
            mock_client.post.side_effect = capture_post
            mock_client_cls.return_value = mock_client

            authed_api_client.post(
                "/v1/webhooks/test",
                json={"url": "https://example.com/hook", "event": "blueprint.forked"},
            )

        assert len(captured) == 1
        payload = captured[0]
        assert payload["test"] is True
        assert payload["event"] == "blueprint.forked"
        assert "data" in payload

    @pytest.mark.parametrize(
        "event",
        ["settlement.created", "settlement.rejected", "blueprint.forked"],
        ids=["created", "rejected", "forked"],
    )
    def test_all_valid_events_accepted(self, authed_api_client: TestClient, event: str):
        """Any event string is accepted — validation is the receiver's concern."""
        mock_response = MagicMock()
        mock_response.status_code = 200

        with patch("httpx.Client") as mock_client_cls:
            mock_client = MagicMock()
            mock_client.__enter__ = MagicMock(return_value=mock_client)
            mock_client.__exit__ = MagicMock(return_value=False)
            mock_client.post.return_value = mock_response
            mock_client_cls.return_value = mock_client

            resp = authed_api_client.post(
                "/v1/webhooks/test",
                json={"url": "https://example.com/hook", "event": event},
            )

        assert resp.status_code == 200
        assert resp.json()["status"] == "delivered"


class TestSDKTestWebhook:
    """Tests for SwarmClient.test_webhook."""

    def test_calls_correct_endpoint(self, sdk_client: SwarmClient):
        """SDK method posts to /v1/webhooks/test with correct body."""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "status": "delivered",
            "status_code": 200,
            "response_time_ms": 42,
        }
        mock_response.raise_for_status = MagicMock()

        with patch.object(sdk_client._http, "post", return_value=mock_response) as mock_post:
            result = sdk_client.test_webhook(
                url="https://example.com/hook",
                event="settlement.created",
            )
            mock_post.assert_called_once_with(
                "/v1/webhooks/test",
                json={"url": "https://example.com/hook", "event": "settlement.created"},
            )

        assert result["status"] == "delivered"
        assert result["status_code"] == 200
        assert result["response_time_ms"] == 42

    def test_default_event(self, sdk_client: SwarmClient):
        """SDK method defaults event to settlement.created."""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"status": "delivered", "status_code": 200, "response_time_ms": 10}
        mock_response.raise_for_status = MagicMock()

        with patch.object(sdk_client._http, "post", return_value=mock_response) as mock_post:
            sdk_client.test_webhook(url="https://example.com/hook")
            _, kwargs = mock_post.call_args
            assert kwargs["json"]["event"] == "settlement.created"

    def test_returns_failed_response(self, sdk_client: SwarmClient):
        """SDK method returns failed dict when delivery fails."""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"status": "failed", "error": "Connection refused"}
        mock_response.raise_for_status = MagicMock()

        with patch.object(sdk_client._http, "post", return_value=mock_response):
            result = sdk_client.test_webhook(url="https://unreachable.example.com/hook")

        assert result["status"] == "failed"
        assert result["error"] == "Connection refused"
