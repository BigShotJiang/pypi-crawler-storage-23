"""Tests for ledger factory and mode selection."""

from __future__ import annotations

from pathlib import Path

import pytest

from swarm_at.ledger_factory import create_ledger, get_ledger_mode, ledger_status


class TestGetLedgerMode:
    def test_defaults_to_file_when_env_not_set(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.delenv("SWARM_LEDGER_MODE", raising=False)
        assert get_ledger_mode() == "file"

    def test_reads_from_env_var(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("SWARM_LEDGER_MODE", "git")
        assert get_ledger_mode() == "git"

    def test_case_insensitive(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("SWARM_LEDGER_MODE", "GIT")
        assert get_ledger_mode() == "git"

        monkeypatch.setenv("SWARM_LEDGER_MODE", "FILE")
        assert get_ledger_mode() == "file"

    def test_strips_whitespace(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("SWARM_LEDGER_MODE", "  git  ")
        assert get_ledger_mode() == "git"

    def test_invalid_mode_raises_value_error(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("SWARM_LEDGER_MODE", "invalid")
        with pytest.raises(ValueError, match="Invalid SWARM_LEDGER_MODE"):
            get_ledger_mode()


class TestCreateLedger:
    def test_creates_ledger_in_file_mode(self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.delenv("SWARM_LEDGER_MODE", raising=False)
        ledger_path = tmp_path / "test_ledger.jsonl"
        ledger = create_ledger(path=ledger_path, mode="file")

        from swarm_at.settler import Ledger

        assert isinstance(ledger, Ledger)
        assert ledger.path == ledger_path

    def test_creates_git_ledger_in_git_mode(self, tmp_path: Path) -> None:
        repo_path = tmp_path / "test_repo"
        ledger = create_ledger(path=repo_path, mode="git")

        from swarm_at.gitplane import GitLedger

        assert isinstance(ledger, GitLedger)
        assert ledger.repo_path == repo_path

    def test_passes_kwargs_to_git_ledger(self, tmp_path: Path) -> None:
        repo_path = tmp_path / "test_repo"
        ledger = create_ledger(path=repo_path, mode="git", branch="develop")

        from swarm_at.gitplane import GitLedger

        assert isinstance(ledger, GitLedger)
        assert ledger.branch == "develop"

    def test_raises_value_error_for_unknown_mode(self, tmp_path: Path) -> None:
        with pytest.raises(ValueError, match="Invalid ledger mode"):
            create_ledger(path=tmp_path / "test.jsonl", mode="unknown")

    def test_respects_env_var_when_mode_is_none(self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("SWARM_LEDGER_MODE", "file")
        ledger_path = tmp_path / "env_test.jsonl"
        ledger = create_ledger(path=ledger_path)

        from swarm_at.settler import Ledger

        assert isinstance(ledger, Ledger)

    def test_respects_env_var_git_mode(self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("SWARM_LEDGER_MODE", "git")
        repo_path = tmp_path / "env_git_test"
        ledger = create_ledger(path=repo_path)

        from swarm_at.gitplane import GitLedger

        assert isinstance(ledger, GitLedger)


class TestLedgerStatus:
    def test_returns_status_for_file_ledger(self, tmp_path: Path) -> None:
        from swarm_at.settler import GENESIS_HASH, Ledger

        ledger_path = tmp_path / "status_test.jsonl"
        ledger = Ledger(path=ledger_path)

        status = ledger_status(ledger)

        assert status["mode"] == "file"
        assert status["latest_hash"] == GENESIS_HASH
        assert status["entry_count"] == 0
        assert status["chain_intact"] is True
        assert "branch" not in status

    def test_returns_status_for_git_ledger(self, tmp_path: Path) -> None:
        from swarm_at.gitplane import GitLedger
        from swarm_at.settler import GENESIS_HASH

        repo_path = tmp_path / "git_status_test"
        ledger = GitLedger(repo_path=repo_path, branch="main")

        status = ledger_status(ledger)

        assert status["mode"] == "git"
        assert status["latest_hash"] == GENESIS_HASH
        assert status["entry_count"] == 0
        assert status["chain_intact"] is True
        assert status["branch"] == "main"

    def test_reflects_ledger_with_entries(self, tmp_path: Path) -> None:
        from swarm_at.models import LedgerEntry
        from swarm_at.settler import GENESIS_HASH, Ledger, generate_hash

        ledger_path = tmp_path / "entries_test.jsonl"
        ledger = Ledger(path=ledger_path)

        # Add an entry
        entry_dict = {
            "timestamp": 1234567890.0,
            "task_id": "test-task",
            "parent_hash": GENESIS_HASH,
            "payload": {"type": "test", "value": "data"},
            "current_hash": "",
        }
        entry_dict["current_hash"] = generate_hash(entry_dict)
        entry = LedgerEntry.model_validate(entry_dict)
        ledger.append_entry(entry)

        status = ledger_status(ledger)

        assert status["mode"] == "file"
        assert status["latest_hash"] == entry_dict["current_hash"]
        assert status["entry_count"] == 1
        assert status["chain_intact"] is True
