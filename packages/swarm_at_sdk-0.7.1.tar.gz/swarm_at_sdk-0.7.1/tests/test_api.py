"""Tests for the FastAPI service."""

from __future__ import annotations

import pytest
from fastapi.testclient import TestClient

from swarm_at.settler import GENESIS_HASH

from tests.conftest import make_settle_request


class TestSettle:
    @pytest.mark.parametrize(
        "parent_hash, confidence, expected_status",
        [
            (GENESIS_HASH, 0.95, "SETTLED"),
            ("a" * 64, 0.95, "REJECTED"),
            (GENESIS_HASH, 0.5, "REJECTED"),
        ],
        ids=["success", "drift", "low-confidence"],
    )
    def test_settle_outcomes(
        self, api_client: TestClient, parent_hash: str, confidence: float, expected_status: str
    ) -> None:
        resp = api_client.post("/v1/settle", json=make_settle_request(parent_hash=parent_hash, confidence=confidence))
        assert resp.status_code == 200
        assert resp.json()["status"] == expected_status

    def test_settled_hash_is_64_chars(self, api_client: TestClient) -> None:
        data = api_client.post("/v1/settle", json=make_settle_request()).json()
        assert len(data["hash"]) == 64


class TestLedger:
    def test_latest_hash_empty(self, api_client: TestClient) -> None:
        assert api_client.get("/v1/ledger/latest").json()["latest_hash"] == GENESIS_HASH

    def test_latest_hash_after_settle(self, api_client: TestClient) -> None:
        settled_hash = api_client.post("/v1/settle", json=make_settle_request()).json()["hash"]
        assert api_client.get("/v1/ledger/latest").json()["latest_hash"] == settled_hash

    def test_verify_empty(self, api_client: TestClient) -> None:
        assert api_client.get("/v1/ledger/verify").json() == {"intact": True, "entry_count": 0}

    def test_verify_after_settle(self, api_client: TestClient) -> None:
        api_client.post("/v1/settle", json=make_settle_request())
        data = api_client.get("/v1/ledger/verify").json()
        assert data["intact"] is True
        assert data["entry_count"] == 1


class TestStatus:
    def test_not_found(self, api_client: TestClient) -> None:
        assert api_client.get("/v1/status/nonexistent").status_code == 404

    def test_found_after_settle(self, api_client: TestClient) -> None:
        api_client.post("/v1/settle", json=make_settle_request())
        resp = api_client.get("/v1/status/api-test-1")
        assert resp.status_code == 200
        assert resp.json()["task_id"] == "api-test-1"


class TestContext:
    def test_empty_state(self, api_client: TestClient) -> None:
        resp = api_client.get("/v1/context", params={"keywords": "anything"})
        assert resp.status_code == 200
        assert resp.json() == {}
