"""Tests for the SDK domain-specific error hierarchy.

Verifies that SwarmClient raises the correct error subclass for each HTTP
status code, that error attributes are populated, and that existing SDK
methods surface domain errors instead of raw httpx errors.
"""

from __future__ import annotations

from typing import Any
from unittest.mock import MagicMock

import httpx
import pytest

import swarm_at.api.state as api_state
from swarm_at.sdk.client import SwarmClient
from swarm_at.sdk.errors import (
    AuthError,
    NotFoundError,
    RateLimitError,
    ServerError,
    SwarmError,
    ValidationError,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_mock_response(
    status_code: int,
    json_body: dict[str, Any] | None = None,
    text_body: str = "",
    headers: dict[str, str] | None = None,
) -> httpx.Response:
    """Build a minimal httpx.Response stub for unit tests."""
    raw_headers: dict[str, str] = headers or {}
    if json_body is not None:
        import json
        content = json.dumps(json_body).encode()
        raw_headers.setdefault("content-type", "application/json")
    else:
        content = text_body.encode()
    return httpx.Response(status_code, content=content, headers=raw_headers)


@pytest.fixture()
def bare_client() -> SwarmClient:
    """SwarmClient with no real HTTP transport — used for unit-testing _handle_response."""
    sdk = SwarmClient.__new__(SwarmClient)
    sdk.api_url = "http://testserver"
    sdk._http = MagicMock()  # type: ignore[assignment]
    return sdk


# ---------------------------------------------------------------------------
# Error hierarchy — class structure
# ---------------------------------------------------------------------------


class TestErrorHierarchy:
    def test_swarm_error_is_exception(self) -> None:
        err = SwarmError(500, "boom")
        assert isinstance(err, Exception)

    def test_auth_error_is_swarm_error(self) -> None:
        assert issubclass(AuthError, SwarmError)

    def test_rate_limit_error_is_swarm_error(self) -> None:
        assert issubclass(RateLimitError, SwarmError)

    def test_not_found_error_is_swarm_error(self) -> None:
        assert issubclass(NotFoundError, SwarmError)

    def test_validation_error_is_swarm_error(self) -> None:
        assert issubclass(ValidationError, SwarmError)

    def test_server_error_is_swarm_error(self) -> None:
        assert issubclass(ServerError, SwarmError)


# ---------------------------------------------------------------------------
# _handle_response — unit tests, no real HTTP needed
# ---------------------------------------------------------------------------


class TestHandleResponse:
    @pytest.mark.parametrize(
        "status_code,error_cls",
        [
            (401, AuthError),
            (403, AuthError),
            (404, NotFoundError),
            (422, ValidationError),
            (429, RateLimitError),
            (500, ServerError),
            (502, ServerError),
            (503, ServerError),
        ],
        ids=["401", "403", "404", "422", "429", "500", "502", "503"],
    )
    def test_raises_correct_error_class(
        self,
        bare_client: SwarmClient,
        status_code: int,
        error_cls: type[SwarmError],
    ) -> None:
        resp = _make_mock_response(status_code, json_body={"detail": "err"})
        with pytest.raises(error_cls):
            bare_client._handle_response(resp)

    def test_other_4xx_raises_swarm_error(self, bare_client: SwarmClient) -> None:
        resp = _make_mock_response(402, json_body={"detail": "payment required"})
        with pytest.raises(SwarmError) as exc_info:
            bare_client._handle_response(resp)
        # Should be base SwarmError, not a subclass
        assert type(exc_info.value) is SwarmError

    def test_2xx_does_not_raise(self, bare_client: SwarmClient) -> None:
        resp = _make_mock_response(200, json_body={"ok": True})
        bare_client._handle_response(resp)  # no exception

    def test_201_does_not_raise(self, bare_client: SwarmClient) -> None:
        resp = _make_mock_response(201, json_body={"created": True})
        bare_client._handle_response(resp)  # no exception


# ---------------------------------------------------------------------------
# Error attributes — status_code, message, body
# ---------------------------------------------------------------------------


class TestErrorAttributes:
    def test_status_code_stored(self, bare_client: SwarmClient) -> None:
        resp = _make_mock_response(404, json_body={"detail": "not found"})
        with pytest.raises(NotFoundError) as exc_info:
            bare_client._handle_response(resp)
        assert exc_info.value.status_code == 404

    def test_message_from_detail_field(self, bare_client: SwarmClient) -> None:
        resp = _make_mock_response(422, json_body={"detail": "field required"})
        with pytest.raises(ValidationError) as exc_info:
            bare_client._handle_response(resp)
        assert exc_info.value.message == "field required"

    def test_body_is_response_dict(self, bare_client: SwarmClient) -> None:
        payload = {"detail": "not found", "extra": "info"}
        resp = _make_mock_response(404, json_body=payload)
        with pytest.raises(NotFoundError) as exc_info:
            bare_client._handle_response(resp)
        assert exc_info.value.body == payload

    def test_plain_text_body(self, bare_client: SwarmClient) -> None:
        resp = _make_mock_response(500, text_body="internal server error")
        with pytest.raises(ServerError) as exc_info:
            bare_client._handle_response(resp)
        assert exc_info.value.body == "internal server error"
        assert "internal server error" in exc_info.value.message

    def test_str_representation_includes_status_and_message(
        self, bare_client: SwarmClient,
    ) -> None:
        resp = _make_mock_response(403, json_body={"detail": "forbidden"})
        with pytest.raises(AuthError) as exc_info:
            bare_client._handle_response(resp)
        assert "403" in str(exc_info.value)
        assert "forbidden" in str(exc_info.value)


# ---------------------------------------------------------------------------
# RateLimitError — retry_after
# ---------------------------------------------------------------------------


class TestRateLimitError:
    def test_retry_after_seconds_parsed(self, bare_client: SwarmClient) -> None:
        resp = _make_mock_response(
            429,
            json_body={"detail": "rate limit"},
            headers={"Retry-After": "30"},
        )
        with pytest.raises(RateLimitError) as exc_info:
            bare_client._handle_response(resp)
        assert exc_info.value.retry_after == 30.0

    def test_retry_after_float(self, bare_client: SwarmClient) -> None:
        resp = _make_mock_response(
            429,
            json_body={"detail": "slow down"},
            headers={"Retry-After": "1.5"},
        )
        with pytest.raises(RateLimitError) as exc_info:
            bare_client._handle_response(resp)
        assert exc_info.value.retry_after == 1.5

    def test_retry_after_none_when_header_absent(self, bare_client: SwarmClient) -> None:
        resp = _make_mock_response(429, json_body={"detail": "rate limit"})
        with pytest.raises(RateLimitError) as exc_info:
            bare_client._handle_response(resp)
        assert exc_info.value.retry_after is None

    def test_retry_after_none_when_header_not_numeric(self, bare_client: SwarmClient) -> None:
        resp = _make_mock_response(
            429,
            json_body={"detail": "rate limit"},
            headers={"Retry-After": "Fri, 01 Jan 2027 00:00:00 GMT"},
        )
        with pytest.raises(RateLimitError) as exc_info:
            bare_client._handle_response(resp)
        assert exc_info.value.retry_after is None

    def test_status_code_stored(self, bare_client: SwarmClient) -> None:
        resp = _make_mock_response(429, json_body={"detail": "too many"})
        with pytest.raises(RateLimitError) as exc_info:
            bare_client._handle_response(resp)
        assert exc_info.value.status_code == 429


# ---------------------------------------------------------------------------
# Integration — SDK methods raise domain errors via TestClient transport
# ---------------------------------------------------------------------------


class TestSdkMethodsDomainErrors:
    """Verify that real SDK methods surface domain errors, not raw httpx errors."""

    def test_get_credits_unknown_agent_raises_not_found(
        self, sdk_client: SwarmClient,
    ) -> None:
        with pytest.raises(NotFoundError) as exc_info:
            sdk_client.get_credits("nobody")
        assert exc_info.value.status_code == 404

    def test_get_agent_unknown_raises_not_found(
        self, sdk_client: SwarmClient,
    ) -> None:
        with pytest.raises(NotFoundError) as exc_info:
            sdk_client.get_agent("ghost-agent")
        assert exc_info.value.status_code == 404

    def test_get_blueprint_unknown_raises_not_found(
        self, sdk_client: SwarmClient,
    ) -> None:
        with pytest.raises(NotFoundError) as exc_info:
            sdk_client.get_blueprint("nonexistent-blueprint")
        assert exc_info.value.status_code == 404

    def test_fork_blueprint_unknown_raises_not_found(
        self, sdk_client: SwarmClient,
    ) -> None:
        with pytest.raises(NotFoundError) as exc_info:
            sdk_client.fork_blueprint("nonexistent-blueprint")
        assert exc_info.value.status_code == 404

    def test_fork_blueprint_insufficient_credits_raises_swarm_error(
        self, sdk_client: SwarmClient,
    ) -> None:
        from swarm_at.seed_blueprints import seed_blueprints
        seed_blueprints(api_state.blueprint_store)
        api_state.credit_ledger.register("broke", initial_balance=0.0)
        with pytest.raises(SwarmError) as exc_info:
            sdk_client.fork_blueprint("audit-chain", agent_id="broke")
        assert exc_info.value.status_code == 402

    def test_domain_errors_are_not_httpx_errors(
        self, sdk_client: SwarmClient,
    ) -> None:
        """SwarmError must not be an httpx.HTTPStatusError."""
        assert not issubclass(SwarmError, httpx.HTTPStatusError)
        assert not issubclass(NotFoundError, httpx.HTTPStatusError)
        with pytest.raises(SwarmError):
            sdk_client.get_credits("nobody")

    def test_auth_error_on_protected_route_without_key(self) -> None:
        """Routes requiring auth return 401 when no key provided."""
        from fastapi.testclient import TestClient
        from swarm_at.api.main import app

        api_state.api_keys = {"sk-real-key"}  # key required
        test_client = TestClient(app)
        sdk = SwarmClient.__new__(SwarmClient)
        sdk.api_url = "http://testserver"
        sdk._http = test_client  # no auth header set

        with pytest.raises(AuthError) as exc_info:
            sdk.topup_credits("agent-x", amount=10.0)
        assert exc_info.value.status_code == 401

    def test_validation_error_on_bad_settle_body(
        self, sdk_client: SwarmClient,
    ) -> None:
        """Malformed JSON body should surface as ValidationError (422)."""
        resp = sdk_client._http.post("/v1/settle", json={"bad": "body"})
        with pytest.raises(ValidationError):
            sdk_client._handle_response(resp)

    def test_not_found_error_has_message(self, sdk_client: SwarmClient) -> None:
        with pytest.raises(NotFoundError) as exc_info:
            sdk_client.get_agent("missing")
        assert exc_info.value.message  # non-empty

    def test_not_found_error_has_body(self, sdk_client: SwarmClient) -> None:
        with pytest.raises(NotFoundError) as exc_info:
            sdk_client.get_agent("missing")
        assert exc_info.value.body is not None
