"""Tests for the dead-simple settle() public API."""

from __future__ import annotations

from pathlib import Path

import pytest

from swarm_at.models import SettlementStatus
from swarm_at.settle import SettlementContext, reset_context, settle
from swarm_at.tiers import SettlementTier


class TestSettlementContextLocal:
    """Local-mode context with in-process engine."""

    def test_settle_returns_settled(self, tmp_path: Path) -> None:
        ctx = SettlementContext(ledger_path=str(tmp_path / "ledger.jsonl"))
        result = ctx.settle(agent="test-agent", task="research")
        assert result.status == SettlementStatus.SETTLED
        assert result.hash is not None
        assert len(result.hash) == 64

    def test_chained_settlements(self, tmp_path: Path) -> None:
        ctx = SettlementContext(ledger_path=str(tmp_path / "ledger.jsonl"))
        r1 = ctx.settle(agent="agent-a", task="step-1")
        r2 = ctx.settle(agent="agent-a", task="step-2")
        assert r1.hash != r2.hash
        assert r2.status == SettlementStatus.SETTLED

    def test_custom_data(self, tmp_path: Path) -> None:
        ctx = SettlementContext(ledger_path=str(tmp_path / "ledger.jsonl"))
        result = ctx.settle(
            agent="agent-b",
            task="classify",
            data={"label": "positive", "score": 0.99},
        )
        assert result.status == SettlementStatus.SETTLED

    def test_low_confidence_rejected(self, tmp_path: Path) -> None:
        ctx = SettlementContext(ledger_path=str(tmp_path / "ledger.jsonl"))
        result = ctx.settle(agent="agent-c", task="guess", confidence=0.1)
        assert result.status == SettlementStatus.REJECTED

    def test_custom_task_id(self, tmp_path: Path) -> None:
        ctx = SettlementContext(ledger_path=str(tmp_path / "ledger.jsonl"))
        result = ctx.settle(agent="agent-d", task="work", task_id="my-task-42")
        assert result.status == SettlementStatus.SETTLED


class TestSettlementContextSandbox:
    """Sandbox tier: log-only, no ledger writes."""

    def test_sandbox_returns_settled(self, tmp_path: Path) -> None:
        ctx = SettlementContext(
            tier=SettlementTier.SANDBOX,
            ledger_path=str(tmp_path / "ledger.jsonl"),
        )
        result = ctx.settle(agent="sandbox-agent", task="explore")
        assert result.status == SettlementStatus.SETTLED
        assert result.hash is not None
        assert len(result.hash) == 64

    def test_sandbox_no_ledger_file(self, tmp_path: Path) -> None:
        ledger_path = tmp_path / "ledger.jsonl"
        ctx = SettlementContext(
            tier=SettlementTier.SANDBOX,
            ledger_path=str(ledger_path),
        )
        ctx.settle(agent="sandbox-agent", task="explore")
        assert not ledger_path.exists()

    def test_sandbox_deterministic_hash(self, tmp_path: Path) -> None:
        ctx1 = SettlementContext(
            tier=SettlementTier.SANDBOX,
            ledger_path=str(tmp_path / "l1.jsonl"),
        )
        ctx2 = SettlementContext(
            tier=SettlementTier.SANDBOX,
            ledger_path=str(tmp_path / "l2.jsonl"),
        )
        r1 = ctx1.settle(agent="a", task="t", task_id="fixed-id")
        r2 = ctx2.settle(agent="a", task="t", task_id="fixed-id")
        assert r1.hash == r2.hash

    def test_sandbox_chaining(self, tmp_path: Path) -> None:
        ctx = SettlementContext(
            tier=SettlementTier.SANDBOX,
            ledger_path=str(tmp_path / "ledger.jsonl"),
        )
        r1 = ctx.settle(agent="a", task="step1", task_id="s1")
        r2 = ctx.settle(agent="a", task="step2", task_id="s2")
        assert r1.hash != r2.hash


class TestSettlementContextStaging:
    """Staging tier: writes ledger but skips chain enforcement."""

    def test_staging_writes_ledger(self, tmp_path: Path) -> None:
        ledger_path = tmp_path / "ledger.jsonl"
        ctx = SettlementContext(
            tier=SettlementTier.STAGING,
            ledger_path=str(ledger_path),
        )
        ctx.settle(agent="staging-agent", task="process")
        assert ledger_path.exists()
        assert len(ledger_path.read_text().strip().splitlines()) == 1

    def test_staging_skips_chain_enforcement(self, tmp_path: Path) -> None:
        """Even with a stale parent_hash, staging re-syncs and settles."""
        ctx = SettlementContext(
            tier=SettlementTier.STAGING,
            ledger_path=str(tmp_path / "ledger.jsonl"),
        )
        # Force a stale parent hash
        ctx._parent_hash = "f" * 64
        result = ctx.settle(agent="staging-agent", task="work")
        assert result.status == SettlementStatus.SETTLED


class TestModuleLevelSettle:
    """Module-level settle() function with lazy singleton."""

    def test_settle_function(self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("SWARM_TIER", "sandbox")
        reset_context()
        result = settle(agent="quick-agent", task="ping")
        assert result.status == SettlementStatus.SETTLED

    def test_reset_context(self) -> None:
        """reset_context() clears the singleton."""
        reset_context()
        # After reset, next call creates a fresh context
        # (just verify no exception)
        reset_context()
