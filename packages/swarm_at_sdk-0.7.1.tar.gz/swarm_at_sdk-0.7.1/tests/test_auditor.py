"""Tests for the Shadow Auditor (swarm_at/auditor.py).

shadow_audit() is a decorator that runs a shadow function alongside the primary,
computes structural divergence between their results, and raises DivergenceError
when the divergence exceeds max_drift.
"""

from __future__ import annotations

import functools
from typing import Any
from unittest.mock import MagicMock

import pytest

from swarm_at.auditor import DivergenceError, _result_to_proposal, shadow_audit
from swarm_at.engine import calculate_divergence


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def make_fn(return_value: dict[str, Any]) -> Any:
    """Return a simple callable that ignores args and returns a fixed dict."""

    def fn(*args: Any, **kwargs: Any) -> dict[str, Any]:
        return return_value

    return fn


def make_capturing_fn(return_value: dict[str, Any]) -> tuple[Any, list[tuple[Any, ...]], list[dict[str, Any]]]:
    """Return (fn, captured_args, captured_kwargs) so call sites can be inspected."""
    captured_args: list[tuple[Any, ...]] = []
    captured_kwargs: list[dict[str, Any]] = []

    def fn(*args: Any, **kwargs: Any) -> dict[str, Any]:
        captured_args.append(args)
        captured_kwargs.append(kwargs)
        return return_value

    return fn, captured_args, captured_kwargs


# ---------------------------------------------------------------------------
# Basic pass / fail behaviour
# ---------------------------------------------------------------------------


class TestShadowAuditDecoratorBasics:
    def test_returns_primary_result_when_no_divergence(self) -> None:
        primary = make_fn({"result": "A"})
        shadow = make_fn({"result": "A"})
        decorated = shadow_audit(shadow_fn=shadow)(primary)
        assert decorated({}) == {"result": "A"}

    def test_raises_divergence_error_on_mismatch(self) -> None:
        primary = make_fn({"result": "A"})
        shadow = make_fn({"result": "B"})
        decorated = shadow_audit(shadow_fn=shadow)(primary)
        with pytest.raises(DivergenceError):
            decorated({})

    def test_does_not_raise_when_divergence_equals_max_drift(self) -> None:
        """Strictly greater-than check: divergence == max_drift is allowed."""
        # Single key mismatch → divergence = 1.0; max_drift = 1.0 → no raise
        primary = make_fn({"x": "A"})
        shadow = make_fn({"x": "B"})
        decorated = shadow_audit(shadow_fn=shadow, max_drift=1.0)(primary)
        assert decorated({}) == {"x": "A"}

    def test_raises_when_divergence_just_above_max_drift(self) -> None:
        # 1 of 2 keys differ → divergence = 0.5; max_drift = 0.49
        primary = make_fn({"a": 1, "b": 2})
        shadow = make_fn({"a": 1, "b": 99})
        decorated = shadow_audit(shadow_fn=shadow, max_drift=0.49)(primary)
        with pytest.raises(DivergenceError):
            decorated({})

    def test_default_max_drift_is_0_15(self) -> None:
        """Divergence of 0.5 should raise with the default 0.15 threshold."""
        primary = make_fn({"a": 1, "b": 2})
        shadow = make_fn({"a": 1, "b": 99})
        decorated = shadow_audit(shadow_fn=shadow)(primary)  # default max_drift=0.15
        with pytest.raises(DivergenceError):
            decorated({})

    def test_empty_matching_payloads_no_raise(self) -> None:
        primary = make_fn({})
        shadow = make_fn({})
        decorated = shadow_audit(shadow_fn=shadow)(primary)
        assert decorated({}) == {}


# ---------------------------------------------------------------------------
# DivergenceError attributes
# ---------------------------------------------------------------------------


class TestDivergenceErrorAttributes:
    def test_error_has_primary_attribute(self) -> None:
        primary_result = {"answer": "A"}
        primary = make_fn(primary_result)
        shadow = make_fn({"answer": "B"})
        decorated = shadow_audit(shadow_fn=shadow)(primary)
        with pytest.raises(DivergenceError) as exc_info:
            decorated({})
        assert exc_info.value.primary == primary_result

    def test_error_has_shadow_attribute(self) -> None:
        shadow_result = {"answer": "B"}
        primary = make_fn({"answer": "A"})
        shadow = make_fn(shadow_result)
        decorated = shadow_audit(shadow_fn=shadow)(primary)
        with pytest.raises(DivergenceError) as exc_info:
            decorated({})
        assert exc_info.value.shadow == shadow_result

    def test_error_divergence_attribute_above_threshold(self) -> None:
        primary = make_fn({"result": "A"})
        shadow = make_fn({"result": "B"})
        decorated = shadow_audit(shadow_fn=shadow, max_drift=0.15)(primary)
        with pytest.raises(DivergenceError) as exc_info:
            decorated({})
        assert exc_info.value.divergence > 0.15

    def test_error_message_contains_divergence_and_threshold(self) -> None:
        primary = make_fn({"k": "A"})
        shadow = make_fn({"k": "B"})
        decorated = shadow_audit(shadow_fn=shadow, max_drift=0.15)(primary)
        with pytest.raises(DivergenceError) as exc_info:
            decorated({})
        msg = str(exc_info.value)
        assert "0.15" in msg
        assert "divergence" in msg.lower() or "drift" in msg.lower() or "1.00" in msg

    def test_error_is_exception_subclass(self) -> None:
        assert issubclass(DivergenceError, Exception)

    def test_divergence_error_direct_instantiation(self) -> None:
        err = DivergenceError(
            "test error",
            primary={"p": 1},
            shadow={"s": 2},
            divergence=0.9,
        )
        assert err.primary == {"p": 1}
        assert err.shadow == {"s": 2}
        assert err.divergence == 0.9
        assert str(err) == "test error"


# ---------------------------------------------------------------------------
# Divergence threshold parametrisation
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(
    "primary_result, shadow_result, max_drift, should_raise",
    [
        ({"result": "A"}, {"result": "A"}, 0.15, False),
        ({"result": "A"}, {"result": "B"}, 0.15, True),
        ({"result": "A"}, {"result": "B"}, 1.0, False),
        ({}, {}, 0.15, False),
        ({"a": 1, "b": 2}, {"a": 1, "b": 99}, 0.15, True),
        ({"a": 1, "b": 2}, {"a": 1, "b": 99}, 0.5, False),
        ({"a": 1, "b": 2}, {"a": 1, "b": 99}, 0.50, False),  # exactly equal
        ({"a": 1, "b": 2, "c": 3}, {"a": 1, "b": 99, "c": 99}, 0.60, True),
    ],
    ids=[
        "matching",
        "divergent-default-threshold",
        "high-threshold-passes",
        "both-empty",
        "partial-mismatch-raises",
        "partial-mismatch-passes-at-0.5",
        "partial-mismatch-at-boundary",
        "two-of-three-mismatch-raises",
    ],
)
def test_shadow_audit_parametrized(
    primary_result: dict[str, Any],
    shadow_result: dict[str, Any],
    max_drift: float,
    should_raise: bool,
) -> None:
    primary = make_fn(primary_result)
    shadow = make_fn(shadow_result)
    decorated = shadow_audit(shadow_fn=shadow, max_drift=max_drift)(primary)

    if should_raise:
        with pytest.raises(DivergenceError) as exc_info:
            decorated({})
        assert exc_info.value.divergence > max_drift
    else:
        result = decorated({})
        assert result == primary_result


# ---------------------------------------------------------------------------
# Argument forwarding
# ---------------------------------------------------------------------------


class TestArgumentForwarding:
    def test_positional_args_forwarded_to_primary(self) -> None:
        received: list[tuple[Any, ...]] = []

        def primary(ctx: Any, extra: str) -> dict[str, Any]:
            received.append((ctx, extra))
            return {"ok": True}

        shadow = make_fn({"ok": True})
        decorated = shadow_audit(shadow_fn=shadow)(primary)
        decorated("ctx_value", "extra_value")
        assert received == [("ctx_value", "extra_value")]

    def test_keyword_args_forwarded_to_primary(self) -> None:
        received: list[dict[str, Any]] = []

        def primary(**kwargs: Any) -> dict[str, Any]:
            received.append(kwargs)
            return {"ok": True}

        shadow = make_fn({"ok": True})
        decorated = shadow_audit(shadow_fn=shadow)(primary)
        decorated(agent="agent-1", task="settle")
        assert received == [{"agent": "agent-1", "task": "settle"}]

    def test_same_args_forwarded_to_shadow(self) -> None:
        shadow_fn, shadow_args, _ = make_capturing_fn({"result": "ok"})
        primary = make_fn({"result": "ok"})
        decorated = shadow_audit(shadow_fn=shadow_fn)(primary)
        decorated("arg1", "arg2")
        assert shadow_args[0] == ("arg1", "arg2")

    def test_same_kwargs_forwarded_to_shadow(self) -> None:
        shadow_fn, _, shadow_kwargs = make_capturing_fn({"result": "ok"})
        primary = make_fn({"result": "ok"})
        decorated = shadow_audit(shadow_fn=shadow_fn)(primary)
        decorated(key="value")
        assert shadow_kwargs[0] == {"key": "value"}


# ---------------------------------------------------------------------------
# Decorator metadata preservation (functools.wraps)
# ---------------------------------------------------------------------------


class TestDecoratorMetadata:
    def test_wraps_preserves_name(self) -> None:
        def my_primary_function(ctx: Any) -> dict[str, Any]:
            return {"ok": True}

        shadow = make_fn({"ok": True})
        decorated = shadow_audit(shadow_fn=shadow)(my_primary_function)
        assert decorated.__name__ == "my_primary_function"

    def test_wraps_preserves_docstring(self) -> None:
        def my_primary_function(ctx: Any) -> dict[str, Any]:
            """This is my docstring."""
            return {"ok": True}

        shadow = make_fn({"ok": True})
        decorated = shadow_audit(shadow_fn=shadow)(my_primary_function)
        assert decorated.__doc__ == "This is my docstring."

    def test_decorator_stacking_works(self) -> None:
        """shadow_audit should compose cleanly with other decorators."""
        call_log: list[str] = []

        def logging_decorator(fn: Any) -> Any:
            @functools.wraps(fn)
            def wrapper(*args: Any, **kwargs: Any) -> Any:
                call_log.append("before")
                result = fn(*args, **kwargs)
                call_log.append("after")
                return result

            return wrapper

        def primary(ctx: Any) -> dict[str, Any]:
            call_log.append("primary")
            return {"ok": True}

        shadow = make_fn({"ok": True})
        decorated = logging_decorator(shadow_audit(shadow_fn=shadow)(primary))
        decorated({})
        assert call_log == ["before", "primary", "after"]


# ---------------------------------------------------------------------------
# _result_to_proposal helper
# ---------------------------------------------------------------------------


class TestResultToProposal:
    def test_wraps_dict_in_proposal(self) -> None:
        result = {"answer": 42}
        proposal = _result_to_proposal(result)
        assert proposal.payload.data_update == result

    def test_proposal_confidence_is_1_0(self) -> None:
        proposal = _result_to_proposal({"x": 1})
        assert proposal.payload.confidence_score == 1.0

    def test_proposal_parent_hash_is_genesis(self) -> None:
        proposal = _result_to_proposal({})
        assert len(proposal.header.parent_hash) == 64
        assert proposal.header.parent_hash == "0" * 64

    def test_empty_dict_wraps_correctly(self) -> None:
        proposal = _result_to_proposal({})
        assert proposal.payload.data_update == {}

    def test_complex_nested_dict_preserved(self) -> None:
        data = {"nested": {"key": [1, 2, 3]}, "flag": True}
        proposal = _result_to_proposal(data)
        assert proposal.payload.data_update == data


# ---------------------------------------------------------------------------
# Integration with calculate_divergence
# ---------------------------------------------------------------------------


class TestDivergenceCalculationIntegration:
    """Verify that shadow_audit uses the same divergence logic as calculate_divergence."""

    @pytest.mark.parametrize(
        "p_data, s_data, expected_divergence",
        [
            ({"a": 1, "b": 2}, {"a": 1, "b": 2}, 0.0),
            ({"a": 1}, {"a": 2}, 1.0),
            ({"a": 1, "b": 2}, {"a": 1, "b": 99}, 0.5),
            ({}, {}, 0.0),
            ({"x": 1}, {"y": 1}, 1.0),   # disjoint keys → no matches
            ({"x": 1, "y": 2}, {"x": 1, "z": 3}, 2 / 3),  # 1 match of 3 total keys
        ],
        ids=[
            "identical",
            "completely-different",
            "half-different",
            "both-empty",
            "disjoint-keys",
            "partial-disjoint",
        ],
    )
    def test_divergence_values(
        self, p_data: dict[str, Any], s_data: dict[str, Any], expected_divergence: float
    ) -> None:
        p_proposal = _result_to_proposal(p_data)
        s_proposal = _result_to_proposal(s_data)
        divergence = calculate_divergence(p_proposal, s_proposal)
        assert divergence == pytest.approx(expected_divergence)

    def test_shadow_audit_raises_iff_calculate_divergence_exceeds_threshold(self) -> None:
        """Manual divergence calculation must agree with decorator behaviour."""
        p_data = {"a": 1, "b": 2, "c": 3}
        s_data = {"a": 1, "b": 99, "c": 3}
        threshold = 0.15

        expected_divergence = calculate_divergence(
            _result_to_proposal(p_data), _result_to_proposal(s_data)
        )
        # divergence = 1/3 ≈ 0.333 > 0.15 → should raise
        assert expected_divergence == pytest.approx(1 / 3)

        decorated = shadow_audit(shadow_fn=make_fn(s_data), max_drift=threshold)(make_fn(p_data))
        with pytest.raises(DivergenceError) as exc_info:
            decorated({})
        assert exc_info.value.divergence == pytest.approx(expected_divergence)


# ---------------------------------------------------------------------------
# Shadow function called exactly once per invocation
# ---------------------------------------------------------------------------


class TestShadowCallCount:
    def test_shadow_called_once_per_primary_call(self) -> None:
        shadow_mock = MagicMock(return_value={"ok": True})
        primary = make_fn({"ok": True})
        decorated = shadow_audit(shadow_fn=shadow_mock)(primary)
        decorated({})
        shadow_mock.assert_called_once()

    def test_shadow_called_each_time_decorated_is_called(self) -> None:
        shadow_mock = MagicMock(return_value={"ok": True})
        primary = make_fn({"ok": True})
        decorated = shadow_audit(shadow_fn=shadow_mock)(primary)
        for _ in range(3):
            decorated({})
        assert shadow_mock.call_count == 3

    def test_primary_called_once_per_invocation(self) -> None:
        primary_mock = MagicMock(return_value={"ok": True})
        shadow = make_fn({"ok": True})
        decorated = shadow_audit(shadow_fn=shadow)(primary_mock)
        decorated({})
        primary_mock.assert_called_once()


# ---------------------------------------------------------------------------
# Primary result is always returned (not the shadow result)
# ---------------------------------------------------------------------------


class TestPrimaryResultReturned:
    def test_primary_value_returned_not_shadow(self) -> None:
        primary = make_fn({"source": "primary"})
        shadow = make_fn({"source": "shadow", "extra": "field"})
        # Force low enough drift threshold to NOT raise but with distinct results
        # Both have "source" key but different value → divergence = 0.5
        # Use max_drift=1.0 so it never raises
        decorated = shadow_audit(shadow_fn=shadow, max_drift=1.0)(primary)
        result = decorated({})
        assert result == {"source": "primary"}
        assert result.get("extra") is None
