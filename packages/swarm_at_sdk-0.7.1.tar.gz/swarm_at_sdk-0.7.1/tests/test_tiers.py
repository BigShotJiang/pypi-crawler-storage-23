"""Tests for settlement tier system."""

from __future__ import annotations

import pytest

from swarm_at.tiers import (
    TIER_POLICIES,
    SettlementTier,
    get_policy,
    get_tier,
)


class TestSettlementTier:
    """Tier enum values and membership."""

    def test_tier_values(self) -> None:
        assert SettlementTier.SANDBOX.value == "sandbox"
        assert SettlementTier.STAGING.value == "staging"
        assert SettlementTier.PRODUCTION.value == "production"

    def test_tier_count(self) -> None:
        assert len(SettlementTier) == 3


class TestTierPolicy:
    """Policy fields and tier mapping."""

    @pytest.mark.parametrize(
        "tier,expected_chain,expected_write,expected_log",
        [
            (SettlementTier.SANDBOX, False, False, True),
            (SettlementTier.STAGING, False, True, False),
            (SettlementTier.PRODUCTION, True, True, False),
        ],
        ids=["sandbox", "staging", "production"],
    )
    def test_tier_policies(
        self,
        tier: SettlementTier,
        expected_chain: bool,
        expected_write: bool,
        expected_log: bool,
    ) -> None:
        policy = TIER_POLICIES[tier]
        assert policy.enforce_chain is expected_chain
        assert policy.write_ledger is expected_write
        assert policy.log_only is expected_log

    def test_all_tiers_have_policies(self) -> None:
        for tier in SettlementTier:
            assert tier in TIER_POLICIES

    def test_sandbox_skips_confidence(self) -> None:
        assert TIER_POLICIES[SettlementTier.SANDBOX].enforce_confidence is False

    def test_staging_enforces_confidence(self) -> None:
        assert TIER_POLICIES[SettlementTier.STAGING].enforce_confidence is True

    def test_production_enforces_everything(self) -> None:
        policy = TIER_POLICIES[SettlementTier.PRODUCTION]
        assert policy.enforce_chain is True
        assert policy.enforce_confidence is True
        assert policy.write_ledger is True
        assert policy.log_only is False


class TestGetTier:
    """Env var reading with fallback."""

    def test_default_is_production(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.delenv("SWARM_TIER", raising=False)
        assert get_tier() == SettlementTier.PRODUCTION

    @pytest.mark.parametrize(
        "env_val,expected",
        [
            ("sandbox", SettlementTier.SANDBOX),
            ("SANDBOX", SettlementTier.SANDBOX),
            ("staging", SettlementTier.STAGING),
            ("Staging", SettlementTier.STAGING),
            ("production", SettlementTier.PRODUCTION),
        ],
        ids=["sandbox-lower", "sandbox-upper", "staging-lower", "staging-mixed", "production"],
    )
    def test_env_var_values(
        self,
        monkeypatch: pytest.MonkeyPatch,
        env_val: str,
        expected: SettlementTier,
    ) -> None:
        monkeypatch.setenv("SWARM_TIER", env_val)
        assert get_tier() == expected

    def test_invalid_falls_back_to_production(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("SWARM_TIER", "invalid-tier")
        assert get_tier() == SettlementTier.PRODUCTION


class TestGetPolicy:
    """Policy lookup with optional tier arg."""

    def test_explicit_tier(self) -> None:
        policy = get_policy(SettlementTier.SANDBOX)
        assert policy.log_only is True

    def test_none_reads_env(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("SWARM_TIER", "sandbox")
        policy = get_policy()
        assert policy.log_only is True
