"""Tests for webhook registry and API endpoints."""

from __future__ import annotations

import pytest
from fastapi.testclient import TestClient

from swarm_at.webhooks import WebhookRegistry


class TestWebhookRegistry:
    """Unit tests for WebhookRegistry class."""

    def test_register_adds_url_to_event(self):
        """Register a webhook URL for a specific event."""
        reg = WebhookRegistry()
        reg.register("settlement.created", "https://example.com/webhook")
        assert reg.get_urls("settlement.created") == ["https://example.com/webhook"]

    def test_register_prevents_duplicates(self):
        """Registering the same URL twice is idempotent."""
        reg = WebhookRegistry()
        reg.register("settlement.created", "https://example.com/webhook")
        reg.register("settlement.created", "https://example.com/webhook")
        assert reg.get_urls("settlement.created") == ["https://example.com/webhook"]

    def test_register_multiple_urls_for_same_event(self):
        """Multiple URLs can listen to the same event."""
        reg = WebhookRegistry()
        reg.register("settlement.created", "https://example.com/webhook1")
        reg.register("settlement.created", "https://example.com/webhook2")
        urls = reg.get_urls("settlement.created")
        assert len(urls) == 2
        assert "https://example.com/webhook1" in urls
        assert "https://example.com/webhook2" in urls

    def test_register_same_url_for_different_events(self):
        """Same URL can listen to multiple events."""
        reg = WebhookRegistry()
        reg.register("settlement.created", "https://example.com/webhook")
        reg.register("settlement.rejected", "https://example.com/webhook")
        assert reg.get_urls("settlement.created") == ["https://example.com/webhook"]
        assert reg.get_urls("settlement.rejected") == ["https://example.com/webhook"]

    def test_unregister_removes_url(self):
        """Unregister removes a specific webhook."""
        reg = WebhookRegistry()
        reg.register("settlement.created", "https://example.com/webhook")
        removed = reg.unregister("settlement.created", "https://example.com/webhook")
        assert removed is True
        assert reg.get_urls("settlement.created") == []

    def test_unregister_returns_false_when_not_found(self):
        """Unregister returns False if webhook doesn't exist."""
        reg = WebhookRegistry()
        removed = reg.unregister("settlement.created", "https://example.com/webhook")
        assert removed is False

    def test_unregister_wrong_event(self):
        """Unregister with wrong event returns False."""
        reg = WebhookRegistry()
        reg.register("settlement.created", "https://example.com/webhook")
        removed = reg.unregister("settlement.rejected", "https://example.com/webhook")
        assert removed is False
        assert reg.get_urls("settlement.created") == ["https://example.com/webhook"]

    def test_get_urls_empty_event(self):
        """Get URLs for an event with no registrations returns empty list."""
        reg = WebhookRegistry()
        assert reg.get_urls("settlement.created") == []

    def test_list_hooks_all_events(self):
        """List all hooks across all events."""
        reg = WebhookRegistry()
        reg.register("settlement.created", "https://example.com/webhook1")
        reg.register("settlement.rejected", "https://example.com/webhook2")
        hooks = reg.list_hooks()
        assert "settlement.created" in hooks
        assert "settlement.rejected" in hooks
        assert hooks["settlement.created"] == ["https://example.com/webhook1"]
        assert hooks["settlement.rejected"] == ["https://example.com/webhook2"]

    def test_list_hooks_filtered_by_event(self):
        """List hooks filtered by a specific event."""
        reg = WebhookRegistry()
        reg.register("settlement.created", "https://example.com/webhook1")
        reg.register("settlement.rejected", "https://example.com/webhook2")
        hooks = reg.list_hooks(event="settlement.created")
        assert "settlement.created" in hooks
        assert "settlement.rejected" not in hooks
        assert hooks["settlement.created"] == ["https://example.com/webhook1"]

    def test_list_hooks_nonexistent_event(self):
        """List hooks for a nonexistent event returns empty list."""
        reg = WebhookRegistry()
        hooks = reg.list_hooks(event="nonexistent")
        assert hooks == {"nonexistent": []}

    def test_clear_removes_all_hooks(self):
        """Clear removes all registered webhooks."""
        reg = WebhookRegistry()
        reg.register("settlement.created", "https://example.com/webhook1")
        reg.register("settlement.rejected", "https://example.com/webhook2")
        reg.clear()
        assert reg.get_urls("settlement.created") == []
        assert reg.get_urls("settlement.rejected") == []
        assert reg.count == 0

    def test_count_property(self):
        """Count property returns total number of registered webhooks."""
        reg = WebhookRegistry()
        assert reg.count == 0
        reg.register("settlement.created", "https://example.com/webhook1")
        assert reg.count == 1
        reg.register("settlement.created", "https://example.com/webhook2")
        assert reg.count == 2
        reg.register("settlement.rejected", "https://example.com/webhook3")
        assert reg.count == 3
        reg.unregister("settlement.created", "https://example.com/webhook1")
        assert reg.count == 2


class TestWebhookAPI:
    """Tests for webhook API endpoints."""

    def test_register_webhook_success(self, authed_api_client: TestClient):
        """Register a webhook via API."""
        resp = authed_api_client.post(
            "/v1/webhooks",
            json={"event": "settlement.created", "url": "https://example.com/webhook"},
        )
        assert resp.status_code == 200
        data = resp.json()
        assert data["event"] == "settlement.created"
        assert data["url"] == "https://example.com/webhook"
        assert data["status"] == "registered"

    def test_register_webhook_invalid_event(self, authed_api_client: TestClient):
        """Register with invalid event returns 400."""
        resp = authed_api_client.post(
            "/v1/webhooks",
            json={"event": "invalid.event", "url": "https://example.com/webhook"},
        )
        assert resp.status_code == 400
        assert "Invalid event" in resp.json()["detail"]
        assert "settlement.created" in resp.json()["detail"]

    def test_register_webhook_requires_auth(self, api_client: TestClient):
        """Register webhook requires authentication."""
        import swarm_at.api.state as state

        state.api_keys = {"sk-test-key"}
        resp = api_client.post(
            "/v1/webhooks",
            json={"event": "settlement.created", "url": "https://example.com/webhook"},
        )
        assert resp.status_code == 401

    def test_list_webhooks_empty(self, authed_api_client: TestClient):
        """List webhooks when none are registered."""
        resp = authed_api_client.get("/v1/webhooks")
        assert resp.status_code == 200
        data = resp.json()
        assert data["webhooks"] == {}
        assert data["total"] == 0

    def test_list_webhooks_all(self, authed_api_client: TestClient):
        """List all registered webhooks."""
        authed_api_client.post(
            "/v1/webhooks",
            json={"event": "settlement.created", "url": "https://example.com/webhook1"},
        )
        authed_api_client.post(
            "/v1/webhooks",
            json={"event": "settlement.rejected", "url": "https://example.com/webhook2"},
        )
        resp = authed_api_client.get("/v1/webhooks")
        assert resp.status_code == 200
        data = resp.json()
        assert "settlement.created" in data["webhooks"]
        assert "settlement.rejected" in data["webhooks"]
        assert data["total"] == 2

    def test_list_webhooks_filtered_by_event(self, authed_api_client: TestClient):
        """List webhooks filtered by event."""
        authed_api_client.post(
            "/v1/webhooks",
            json={"event": "settlement.created", "url": "https://example.com/webhook1"},
        )
        authed_api_client.post(
            "/v1/webhooks",
            json={"event": "settlement.rejected", "url": "https://example.com/webhook2"},
        )
        resp = authed_api_client.get("/v1/webhooks?event=settlement.created")
        assert resp.status_code == 200
        data = resp.json()
        assert "settlement.created" in data["webhooks"]
        assert "settlement.rejected" not in data["webhooks"]
        assert data["webhooks"]["settlement.created"] == ["https://example.com/webhook1"]

    def test_list_webhooks_requires_auth(self, api_client: TestClient):
        """List webhooks requires authentication."""
        import swarm_at.api.state as state

        state.api_keys = {"sk-test-key"}
        resp = api_client.get("/v1/webhooks")
        assert resp.status_code == 401

    def test_unregister_webhook_success(self, authed_api_client: TestClient):
        """Unregister a webhook via API."""
        authed_api_client.post(
            "/v1/webhooks",
            json={"event": "settlement.created", "url": "https://example.com/webhook"},
        )
        resp = authed_api_client.request(
            "DELETE",
            "/v1/webhooks",
            json={"event": "settlement.created", "url": "https://example.com/webhook"},
        )
        assert resp.status_code == 200
        data = resp.json()
        assert data["event"] == "settlement.created"
        assert data["url"] == "https://example.com/webhook"
        assert data["status"] == "removed"

    def test_unregister_webhook_not_found(self, authed_api_client: TestClient):
        """Unregister nonexistent webhook returns 404."""
        resp = authed_api_client.request(
            "DELETE",
            "/v1/webhooks",
            json={"event": "settlement.created", "url": "https://example.com/webhook"},
        )
        assert resp.status_code == 404
        assert "not found" in resp.json()["detail"].lower()

    def test_unregister_webhook_requires_auth(self, api_client: TestClient):
        """Unregister webhook requires authentication."""
        import swarm_at.api.state as state

        state.api_keys = {"sk-test-key"}
        resp = api_client.request(
            "DELETE",
            "/v1/webhooks",
            json={"event": "settlement.created", "url": "https://example.com/webhook"},
        )
        assert resp.status_code == 401

    def test_webhook_lifecycle(self, authed_api_client: TestClient):
        """Full webhook lifecycle: register, list, unregister."""
        # Register
        resp = authed_api_client.post(
            "/v1/webhooks",
            json={"event": "settlement.created", "url": "https://example.com/webhook"},
        )
        assert resp.status_code == 200

        # List
        resp = authed_api_client.get("/v1/webhooks")
        assert resp.status_code == 200
        assert resp.json()["total"] == 1

        # Unregister
        resp = authed_api_client.request(
            "DELETE",
            "/v1/webhooks",
            json={"event": "settlement.created", "url": "https://example.com/webhook"},
        )
        assert resp.status_code == 200

        # Verify removed
        resp = authed_api_client.get("/v1/webhooks")
        assert resp.status_code == 200
        assert resp.json()["total"] == 0

    @pytest.mark.parametrize(
        "event",
        ["settlement.created", "settlement.rejected", "blueprint.forked"],
        ids=["created", "rejected", "forked"],
    )
    def test_valid_event_types(self, authed_api_client: TestClient, event: str):
        """All three valid event types can be registered."""
        resp = authed_api_client.post(
            "/v1/webhooks",
            json={"event": event, "url": "https://example.com/webhook"},
        )
        assert resp.status_code == 200
        assert resp.json()["event"] == event
