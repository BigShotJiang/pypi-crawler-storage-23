"""Tests for workflow chaining: Beads, Molecules, Formulas, and Convoys."""

from __future__ import annotations

import pytest

from swarm_at.workflow import (
    Bead,
    BeadStatus,
    Convoy,
    ConvoyStatus,
    Formula,
    FormulaStep,
    Molecule,
    MoleculeStatus,
    WorkflowEngine,
    WorkflowError,
)


class TestBead:
    def test_bead_starts_pending(self):
        """New beads start in PENDING state."""
        bead = Bead(name="test-bead")
        assert bead.status == BeadStatus.PENDING
        assert bead.settlement_hash is None
        assert bead.started_at is None
        assert bead.completed_at is None

    def test_is_ready_no_dependencies(self):
        """Bead with no dependencies is always ready."""
        bead = Bead(name="test-bead", depends_on=[])
        assert bead.is_ready(set())
        assert bead.is_ready({"other-bead-id"})

    @pytest.mark.parametrize(
        ("completed", "expected"),
        [
            (set(), False),
            ({"dep1"}, False),
            ({"dep2"}, False),
            ({"dep1", "dep2"}, True),
            ({"dep1", "dep2", "extra"}, True),
        ],
        ids=["no-deps", "only-dep1", "only-dep2", "both-deps", "extra-deps"],
    )
    def test_is_ready_with_dependencies(self, completed, expected):
        """Bead is ready only when all dependencies are satisfied."""
        bead = Bead(name="test-bead", depends_on=["dep1", "dep2"])
        assert bead.is_ready(completed) == expected


class TestMolecule:
    def test_add_bead_creates_bead(self):
        """add_bead adds a new bead to the molecule."""
        mol = Molecule(name="test-molecule")
        bead = mol.add_bead(name="step-1", agent_id="agent-a")

        assert len(mol.beads) == 1
        assert mol.beads[0] == bead
        assert bead.name == "step-1"
        assert bead.agent_id == "agent-a"
        assert bead.status == BeadStatus.PENDING

    def test_add_bead_with_dependencies(self):
        """add_bead can specify dependencies on other beads."""
        mol = Molecule(name="test-molecule")
        bead1 = mol.add_bead(name="step-1")
        bead2 = mol.add_bead(name="step-2", depends_on=[bead1.bead_id])

        assert bead2.depends_on == [bead1.bead_id]

    def test_get_bead_returns_bead(self):
        """get_bead retrieves bead by ID."""
        mol = Molecule(name="test-molecule")
        bead = mol.add_bead(name="step-1")

        found = mol.get_bead(bead.bead_id)
        assert found == bead

    def test_get_bead_returns_none_if_not_found(self):
        """get_bead returns None for unknown bead IDs."""
        mol = Molecule(name="test-molecule")
        assert mol.get_bead("nonexistent") is None

    @pytest.mark.parametrize(
        ("beads_config", "expected_ready_names"),
        [
            ([], []),
            ([("a", [])], ["a"]),
            ([("a", []), ("b", ["a"])], ["a"]),
            ([("a", []), ("b", []), ("c", ["a", "b"])], ["a", "b"]),
        ],
        ids=["no-beads", "single-bead", "chained-beads", "parallel-beads"],
    )
    def test_ready_beads_returns_correct_set(self, beads_config, expected_ready_names):
        """ready_beads returns beads with satisfied dependencies."""
        mol = Molecule(name="test-molecule")
        bead_map = {}

        for name, deps in beads_config:
            dep_ids = [bead_map[d].bead_id for d in deps]
            bead_map[name] = mol.add_bead(name=name, depends_on=dep_ids)

        ready = mol.ready_beads()
        ready_names = [b.name for b in ready]
        assert sorted(ready_names) == sorted(expected_ready_names)

    def test_ready_beads_excludes_settled(self):
        """ready_beads excludes beads that are already settled."""
        mol = Molecule(name="test-molecule")
        bead1 = mol.add_bead(name="step-1")
        bead2 = mol.add_bead(name="step-2")

        bead1.status = BeadStatus.SETTLED
        ready = mol.ready_beads()

        assert bead1 not in ready
        assert bead2 in ready

    @pytest.mark.parametrize(
        ("total", "settled", "expected"),
        [
            (0, 0, 0.0),
            (1, 0, 0.0),
            (1, 1, 1.0),
            (4, 0, 0.0),
            (4, 1, 0.25),
            (4, 2, 0.5),
            (4, 3, 0.75),
            (4, 4, 1.0),
        ],
        ids=[
            "empty",
            "none-settled",
            "all-settled",
            "four-none",
            "four-one",
            "four-half",
            "four-three",
            "four-all",
        ],
    )
    def test_progress_tracks_correctly(self, total, settled, expected):
        """progress returns fraction of settled beads."""
        mol = Molecule(name="test-molecule")

        for i in range(total):
            bead = mol.add_bead(name=f"step-{i}")
            if i < settled:
                bead.status = BeadStatus.SETTLED

        assert mol.progress == expected

    @pytest.mark.parametrize(
        ("statuses", "expected"),
        [
            ([], False),
            ([BeadStatus.PENDING], False),
            ([BeadStatus.SETTLED], True),
            ([BeadStatus.SETTLED, BeadStatus.SETTLED], True),
            ([BeadStatus.SETTLED, BeadStatus.PENDING], False),
            ([BeadStatus.SETTLED, BeadStatus.SKIPPED], True),
            ([BeadStatus.SKIPPED, BeadStatus.SKIPPED], True),
            ([BeadStatus.SETTLED, BeadStatus.FAILED], False),
        ],
        ids=[
            "empty",
            "pending",
            "single-settled",
            "all-settled",
            "mixed-pending",
            "settled-and-skipped",
            "all-skipped",
            "has-failed",
        ],
    )
    def test_is_complete_when_all_settled_or_skipped(self, statuses, expected):
        """is_complete is True only when all beads are settled/skipped."""
        mol = Molecule(name="test-molecule")

        for i, status in enumerate(statuses):
            bead = mol.add_bead(name=f"step-{i}")
            bead.status = status

        assert mol.is_complete == expected

    @pytest.mark.parametrize(
        ("statuses", "expected"),
        [
            ([], False),
            ([BeadStatus.PENDING], False),
            ([BeadStatus.SETTLED], False),
            ([BeadStatus.FAILED], True),
            ([BeadStatus.SETTLED, BeadStatus.FAILED], True),
            ([BeadStatus.PENDING, BeadStatus.RUNNING], False),
        ],
        ids=["empty", "pending", "settled", "failed", "mixed-with-failure", "running"],
    )
    def test_has_failures_detects_failed_beads(self, statuses, expected):
        """has_failures is True if any bead is FAILED."""
        mol = Molecule(name="test-molecule")

        for i, status in enumerate(statuses):
            bead = mol.add_bead(name=f"step-{i}")
            bead.status = status

        assert mol.has_failures == expected


class TestFormula:
    def test_instantiate_creates_molecule_with_correct_beads(self):
        """Formula.instantiate creates a Molecule with beads matching steps."""
        formula = Formula(name="test-formula")
        formula.steps = [
            FormulaStep(name="gather", agent_role="researcher"),
            FormulaStep(name="analyze", agent_role="analyst"),
            FormulaStep(name="report", agent_role="reporter"),
        ]

        mol = formula.instantiate()

        assert mol.name == "test-formula (instance)"
        assert len(mol.beads) == 3
        assert mol.beads[0].name == "gather"
        assert mol.beads[0].agent_id == "researcher"
        assert mol.beads[1].name == "analyze"
        assert mol.beads[1].agent_id == "analyst"
        assert mol.beads[2].name == "report"
        assert mol.beads[2].agent_id == "reporter"

    def test_dependencies_resolved_by_name(self):
        """Formula step dependencies are resolved to bead IDs."""
        formula = Formula(name="test-formula")
        formula.steps = [
            FormulaStep(name="step-a"),
            FormulaStep(name="step-b", depends_on=["step-a"]),
            FormulaStep(name="step-c", depends_on=["step-a", "step-b"]),
        ]

        mol = formula.instantiate()

        assert len(mol.beads) == 3
        assert mol.beads[0].depends_on == []
        assert mol.beads[1].depends_on == [mol.beads[0].bead_id]
        assert mol.beads[2].depends_on == [mol.beads[0].bead_id, mol.beads[1].bead_id]

    def test_context_passed_to_input_data(self):
        """Context provided to instantiate is set as input_data on beads."""
        formula = Formula(name="test-formula")
        formula.steps = [FormulaStep(name="step-1")]

        context = {"user_id": "123", "task": "analyze"}
        mol = formula.instantiate(context=context)

        assert mol.beads[0].input_data == context

    def test_instantiate_with_no_context(self):
        """Instantiate works with no context provided."""
        formula = Formula(name="test-formula")
        formula.steps = [FormulaStep(name="step-1")]

        mol = formula.instantiate()

        assert mol.beads[0].input_data == {}


class TestConvoy:
    def test_create_convoy(self):
        """Convoy can be created with a name."""
        convoy = Convoy(name="feature-x")
        assert convoy.name == "feature-x"
        assert convoy.status == ConvoyStatus.ACTIVE
        assert convoy.molecule_ids == []

    def test_convoy_tracks_molecules(self):
        """Convoy can track multiple molecule IDs."""
        convoy = Convoy(name="feature-x", molecule_ids=["mol-1", "mol-2"])
        assert len(convoy.molecule_ids) == 2
        assert "mol-1" in convoy.molecule_ids


class TestWorkflowEngine:
    def test_register_molecule(self, workflow_engine):
        """WorkflowEngine can register molecules for tracking."""
        mol = Molecule(name="test-molecule")
        result = workflow_engine.register_molecule(mol)

        assert result == mol
        assert workflow_engine.get_molecule(mol.molecule_id) == mol

    def test_execute_bead_settles_to_ledger(self, workflow_engine):
        """execute_bead settles the bead to the ledger and updates status."""
        mol = Molecule(name="test-molecule")
        bead = mol.add_bead(name="step-1")
        workflow_engine.register_molecule(mol)

        output = {"result": "success", "value": 42}
        result_bead = workflow_engine.execute_bead(mol.molecule_id, bead.bead_id, output)

        assert result_bead.status == BeadStatus.SETTLED
        assert result_bead.output_data == output
        assert result_bead.settlement_hash is not None
        assert len(result_bead.settlement_hash) == 64
        assert result_bead.started_at is not None
        assert result_bead.completed_at is not None

        # Verify ledger entry
        entries = workflow_engine.engine.ledger.read_all()
        assert len(entries) == 1
        assert entries[0].payload["type"] == "bead_settlement"
        assert entries[0].payload["bead_id"] == bead.bead_id
        assert entries[0].payload["output"] == output

    def test_execute_bead_with_unmet_deps_raises(self, workflow_engine):
        """execute_bead raises WorkflowError if dependencies not satisfied."""
        mol = Molecule(name="test-molecule")
        bead1 = mol.add_bead(name="step-1")
        bead2 = mol.add_bead(name="step-2", depends_on=[bead1.bead_id])
        workflow_engine.register_molecule(mol)

        with pytest.raises(WorkflowError, match="unmet dependencies"):
            workflow_engine.execute_bead(mol.molecule_id, bead2.bead_id, {"data": "value"})

    def test_execute_bead_on_non_pending_raises(self, workflow_engine):
        """execute_bead raises if bead is not in PENDING state."""
        mol = Molecule(name="test-molecule")
        bead = mol.add_bead(name="step-1")
        bead.status = BeadStatus.SETTLED
        workflow_engine.register_molecule(mol)

        with pytest.raises(WorkflowError, match="expected pending"):
            workflow_engine.execute_bead(mol.molecule_id, bead.bead_id, {"data": "value"})

    def test_execute_bead_unknown_molecule_raises(self, workflow_engine):
        """execute_bead raises if molecule not found."""
        with pytest.raises(WorkflowError, match="Molecule .* not found"):
            workflow_engine.execute_bead("unknown-mol", "unknown-bead", {})

    def test_execute_bead_unknown_bead_raises(self, workflow_engine):
        """execute_bead raises if bead not found in molecule."""
        mol = Molecule(name="test-molecule")
        workflow_engine.register_molecule(mol)

        with pytest.raises(WorkflowError, match="Bead .* not found"):
            workflow_engine.execute_bead(mol.molecule_id, "unknown-bead", {})

    def test_fail_bead_marks_failed(self, workflow_engine):
        """fail_bead marks a bead as FAILED and sets error message."""
        mol = Molecule(name="test-molecule")
        bead = mol.add_bead(name="step-1")
        workflow_engine.register_molecule(mol)

        error_msg = "Network timeout"
        result_bead = workflow_engine.fail_bead(mol.molecule_id, bead.bead_id, error_msg)

        assert result_bead.status == BeadStatus.FAILED
        assert result_bead.error == error_msg
        assert result_bead.completed_at is not None
        assert mol.status == MoleculeStatus.FAILED

    def test_full_workflow_three_beads_chained(self, workflow_engine):
        """Complete workflow: 3 beads executed in dependency order."""
        mol = Molecule(name="data-pipeline")
        bead1 = mol.add_bead(name="fetch")
        bead2 = mol.add_bead(name="transform", depends_on=[bead1.bead_id])
        bead3 = mol.add_bead(name="load", depends_on=[bead2.bead_id])
        workflow_engine.register_molecule(mol)

        # Execute in order
        workflow_engine.execute_bead(mol.molecule_id, bead1.bead_id, {"data": "raw"})
        assert bead1.status == BeadStatus.SETTLED
        assert mol.status == MoleculeStatus.RUNNING

        workflow_engine.execute_bead(mol.molecule_id, bead2.bead_id, {"data": "transformed"})
        assert bead2.status == BeadStatus.SETTLED
        assert mol.status == MoleculeStatus.RUNNING

        workflow_engine.execute_bead(mol.molecule_id, bead3.bead_id, {"data": "loaded"})
        assert bead3.status == BeadStatus.SETTLED
        assert mol.status == MoleculeStatus.COMPLETED
        assert mol.is_complete
        assert mol.progress == 1.0

    def test_molecule_completes_when_all_beads_settle(self, workflow_engine):
        """Molecule status becomes COMPLETED when all beads settle."""
        mol = Molecule(name="test-molecule")
        bead1 = mol.add_bead(name="step-1")
        bead2 = mol.add_bead(name="step-2")
        workflow_engine.register_molecule(mol)

        assert mol.status == MoleculeStatus.PENDING

        workflow_engine.execute_bead(mol.molecule_id, bead1.bead_id, {})
        assert mol.status == MoleculeStatus.RUNNING

        workflow_engine.execute_bead(mol.molecule_id, bead2.bead_id, {})
        assert mol.status == MoleculeStatus.COMPLETED
        assert mol.completed_at is not None

    def test_molecule_fails_when_bead_fails(self, workflow_engine):
        """Molecule status becomes FAILED when any bead fails."""
        mol = Molecule(name="test-molecule")
        bead = mol.add_bead(name="step-1")
        workflow_engine.register_molecule(mol)

        workflow_engine.fail_bead(mol.molecule_id, bead.bead_id, "error")
        assert mol.status == MoleculeStatus.FAILED

    def test_convoy_progress_across_molecules(self, workflow_engine):
        """convoy_progress aggregates progress across multiple molecules."""
        mol1 = Molecule(name="mol-1")
        mol1.add_bead(name="a")
        mol1.add_bead(name="b")
        workflow_engine.register_molecule(mol1)

        mol2 = Molecule(name="mol-2")
        bead_c = mol2.add_bead(name="c")
        bead_d = mol2.add_bead(name="d")
        workflow_engine.register_molecule(mol2)

        convoy = workflow_engine.create_convoy("feature-x", [mol1.molecule_id, mol2.molecule_id])

        # No beads settled: progress = 0.0
        assert workflow_engine.convoy_progress(convoy.convoy_id) == 0.0

        # mol2: 1 of 2 beads settled -> 0.5
        # mol1: 0 of 2 beads settled -> 0.0
        # convoy: (0.5 + 0.0) / 2 = 0.25
        workflow_engine.execute_bead(mol2.molecule_id, bead_c.bead_id, {})
        assert workflow_engine.convoy_progress(convoy.convoy_id) == 0.25

        # mol2: 2 of 2 beads settled -> 1.0
        # mol1: 0 of 2 beads settled -> 0.0
        # convoy: (1.0 + 0.0) / 2 = 0.5
        workflow_engine.execute_bead(mol2.molecule_id, bead_d.bead_id, {})
        assert workflow_engine.convoy_progress(convoy.convoy_id) == 0.5

    def test_create_convoy(self, workflow_engine):
        """create_convoy creates a new convoy."""
        convoy = workflow_engine.create_convoy("feature-x")
        assert convoy.name == "feature-x"
        assert convoy.molecule_ids == []

    def test_add_to_convoy(self, workflow_engine):
        """add_to_convoy adds a molecule to an existing convoy."""
        mol = Molecule(name="test-molecule")
        workflow_engine.register_molecule(mol)

        convoy = workflow_engine.create_convoy("feature-x")
        result = workflow_engine.add_to_convoy(convoy.convoy_id, mol.molecule_id)

        assert mol.molecule_id in result.molecule_ids

    def test_add_to_convoy_prevents_duplicates(self, workflow_engine):
        """add_to_convoy does not add duplicate molecule IDs."""
        mol = Molecule(name="test-molecule")
        workflow_engine.register_molecule(mol)

        convoy = workflow_engine.create_convoy("feature-x")
        workflow_engine.add_to_convoy(convoy.convoy_id, mol.molecule_id)
        workflow_engine.add_to_convoy(convoy.convoy_id, mol.molecule_id)

        assert convoy.molecule_ids.count(mol.molecule_id) == 1

    def test_convoy_progress_unknown_convoy_raises(self, workflow_engine):
        """convoy_progress raises if convoy not found."""
        with pytest.raises(WorkflowError, match="Convoy .* not found"):
            workflow_engine.convoy_progress("unknown-convoy")

    def test_convoy_progress_empty_convoy(self, workflow_engine):
        """convoy_progress returns 0.0 for convoy with no molecules."""
        convoy = workflow_engine.create_convoy("empty")
        assert workflow_engine.convoy_progress(convoy.convoy_id) == 0.0


class TestAtomicMolecule:
    """Tests for atomic molecule rollback on failure."""

    def test_rollback_on_failure(self, workflow_engine):
        """Atomic molecule rolls back all settled beads when one fails."""
        mol = Molecule(name="atomic-mol", atomic=True)
        bead1 = mol.add_bead(name="step-1")
        mol.add_bead(name="step-2", depends_on=[bead1.bead_id])
        workflow_engine.register_molecule(mol)

        # First bead settles
        workflow_engine.execute_bead(mol.molecule_id, bead1.bead_id, {"data": "ok"})
        assert bead1.status == BeadStatus.SETTLED

        # Fail the second bead explicitly
        workflow_engine.fail_bead(mol.molecule_id, mol.beads[1].bead_id, "crash")
        assert mol.status == MoleculeStatus.FAILED

    def test_non_atomic_keeps_settled_beads(self, workflow_engine):
        """Non-atomic molecule keeps settled beads when another fails."""
        mol = Molecule(name="normal-mol")
        bead1 = mol.add_bead(name="step-1")
        bead2 = mol.add_bead(name="step-2")
        workflow_engine.register_molecule(mol)

        workflow_engine.execute_bead(mol.molecule_id, bead1.bead_id, {"data": "ok"})
        assert bead1.status == BeadStatus.SETTLED
        workflow_engine.fail_bead(mol.molecule_id, bead2.bead_id, "crash")
        # bead1 stays settled in non-atomic mode
        assert bead1.status == BeadStatus.SETTLED

    def test_rollback_writes_compensation_entries(self, workflow_engine):
        """rollback_molecule writes compensation entries to ledger."""
        mol = Molecule(name="atomic-mol", atomic=True)
        bead1 = mol.add_bead(name="step-1")
        bead2 = mol.add_bead(name="step-2", depends_on=[bead1.bead_id])
        workflow_engine.register_molecule(mol)

        workflow_engine.execute_bead(mol.molecule_id, bead1.bead_id, {"data": "ok"})
        workflow_engine.execute_bead(mol.molecule_id, bead2.bead_id, {"data": "ok2"})
        assert bead2.status == BeadStatus.SETTLED

        hashes = workflow_engine.rollback_molecule(mol.molecule_id, "manual rollback")
        assert len(hashes) == 2  # one compensation per settled bead
        assert mol.status == MoleculeStatus.ROLLED_BACK
        assert bead1.status == BeadStatus.ROLLED_BACK
        assert bead2.status == BeadStatus.ROLLED_BACK

        # Check compensation entries in ledger
        entries = workflow_engine.engine.ledger.read_all()
        rollback_entries = [e for e in entries if e.payload.get("type") == "bead_rollback"]
        assert len(rollback_entries) == 2

    def test_parent_hash_captured_on_first_bead(self, workflow_engine):
        """Atomic molecule captures parent hash on first bead execution."""
        mol = Molecule(name="atomic-mol", atomic=True)
        bead1 = mol.add_bead(name="step-1")
        workflow_engine.register_molecule(mol)

        assert mol.molecule_parent_hash is None
        workflow_engine.execute_bead(mol.molecule_id, bead1.bead_id, {"data": "ok"})
        assert mol.molecule_parent_hash is not None

    def test_rollback_unknown_molecule_raises(self, workflow_engine):
        """rollback_molecule raises for unknown molecule ID."""
        with pytest.raises(WorkflowError, match="not found"):
            workflow_engine.rollback_molecule("nonexistent", "reason")

    def test_drift_detection_triggers_rollback(self, workflow_engine):
        """External writes during atomic molecule trigger rollback."""
        mol = Molecule(name="atomic-mol", atomic=True)
        bead1 = mol.add_bead(name="step-1")
        bead2 = mol.add_bead(name="step-2", depends_on=[bead1.bead_id])
        workflow_engine.register_molecule(mol)

        workflow_engine.execute_bead(mol.molecule_id, bead1.bead_id, {"data": "ok"})

        # Simulate external write — append entry directly to ledger
        from swarm_at.models import Header, Payload, Proposal
        ext_proposal = Proposal(
            header=Header(
                task_id="external-write",
                parent_hash=workflow_engine.engine.ledger.get_latest_hash(),
            ),
            payload=Payload(data_update={"external": True}, confidence_score=0.95),
        )
        workflow_engine.engine.verify_and_settle(ext_proposal)

        # Now execute bead2 — drift should be detected
        result_bead = workflow_engine.execute_bead(mol.molecule_id, bead2.bead_id, {"data": "ok2"})
        assert result_bead.status == BeadStatus.ROLLED_BACK
        assert mol.status == MoleculeStatus.ROLLED_BACK


class TestShadowAudit:
    """Tests for shadow audit integration in workflow engine."""

    def test_shadow_audit_with_rate_1_always_audits(self, tmp_path):
        """With audit_rate=1.0, every bead is shadow-audited."""
        from swarm_at.engine import SwarmAtEngine
        from swarm_at.settler import Ledger

        ledger = Ledger(path=tmp_path / "shadow.jsonl")
        engine = SwarmAtEngine(ledger=ledger)

        # Shadow function returns same data — no divergence
        shadow_fn = lambda data: {"type": "shadow_check", **data}  # noqa: E731
        we = WorkflowEngine(engine=engine, audit_rate=1.0, shadow_fn=shadow_fn)

        mol = Molecule(name="audited-mol")
        bead = mol.add_bead(name="step-1")
        we.register_molecule(mol)
        we.execute_bead(mol.molecule_id, bead.bead_id, {"result": "ok"})
        # Should settle regardless of shadow check
        assert bead.status == BeadStatus.SETTLED

    def test_no_shadow_when_fn_is_none(self, workflow_engine):
        """No shadow audit when shadow_fn is None."""
        mol = Molecule(name="no-shadow")
        bead = mol.add_bead(name="step-1")
        workflow_engine.register_molecule(mol)
        workflow_engine.execute_bead(mol.molecule_id, bead.bead_id, {"data": "ok"})
        assert bead.status == BeadStatus.SETTLED

    def test_shadow_rate_zero_never_audits(self, tmp_path):
        """With audit_rate=0, shadow function is never called."""
        from swarm_at.engine import SwarmAtEngine
        from swarm_at.settler import Ledger

        ledger = Ledger(path=tmp_path / "noshadow.jsonl")
        engine = SwarmAtEngine(ledger=ledger)

        call_count = {"n": 0}
        def shadow_fn(data):
            call_count["n"] += 1
            return data

        we = WorkflowEngine(engine=engine, audit_rate=0.0, shadow_fn=shadow_fn)
        mol = Molecule(name="no-audit")
        bead = mol.add_bead(name="step-1")
        we.register_molecule(mol)
        we.execute_bead(mol.molecule_id, bead.bead_id, {"data": "ok"})
        assert call_count["n"] == 0

    def test_divergence_records_in_registry(self, tmp_path):
        """Shadow audit divergence records penalty in agent registry."""
        from swarm_at.agents import AgentRegistry
        from swarm_at.engine import SwarmAtEngine
        from swarm_at.settler import Ledger

        ledger = Ledger(path=tmp_path / "div.jsonl")
        engine = SwarmAtEngine(ledger=ledger)
        registry = AgentRegistry()
        registry.register("agent-aa")
        for _ in range(8):
            registry.record_settlement("agent-aa", success=True)

        # Shadow returns very different data to trigger escrow
        def divergent_shadow(data):
            return {"completely": "different", "data": "here"}

        we = WorkflowEngine(
            engine=engine, audit_rate=1.0, shadow_fn=divergent_shadow, registry=registry,
        )
        mol = Molecule(name="div-mol")
        bead = mol.add_bead(name="step-1", agent_id="agent-aa")
        we.register_molecule(mol)
        we.execute_bead(mol.molecule_id, bead.bead_id, {"result": "ok"})
        # If divergence was detected (ESCROWED), penalty was recorded
        # Note: whether it's ESCROWED depends on engine's divergence threshold
        # With max_divergence 0.15 and very different data, it should escrow
        assert bead.status == BeadStatus.SETTLED  # still settles for workflow
