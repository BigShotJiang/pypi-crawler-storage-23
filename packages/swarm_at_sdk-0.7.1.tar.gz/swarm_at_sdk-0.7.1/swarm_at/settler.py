"""Ledger operations: read, append, verify hash-chain integrity."""

from __future__ import annotations

import hashlib
import json
import threading
from pathlib import Path
from typing import Any

from swarm_at.models import LedgerEntry

GENESIS_HASH = "0" * 64


def content_fingerprint(content: str) -> str:
    """SHA-256 fingerprint of content for authorship claims."""
    return hashlib.sha256(content.encode()).hexdigest()


def generate_hash(content: dict[str, Any]) -> str:
    """Deterministic SHA-256 hash of a dict (sorted keys)."""
    raw = json.dumps(content, sort_keys=True).encode()
    return hashlib.sha256(raw).hexdigest()


class Ledger:
    def __init__(self, path: str | Path = "ledger.jsonl"):
        self.path = Path(path)
        self._write_lock = threading.Lock()
        # In-memory cache — None means "not yet loaded"
        self._cache: list[LedgerEntry] | None = None
        self._task_index: dict[str, LedgerEntry] = {}
        self._agent_index: dict[str, list[LedgerEntry]] = {}
        # Counts how many times the file was read — useful for tests.
        self._load_count: int = 0

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _load_cache(self) -> None:
        """Populate cache and indexes by reading the JSONL file once."""
        self._load_count += 1
        if not self.path.exists():
            self._cache = []
            self._task_index = {}
            self._agent_index = {}
            return
        entries: list[LedgerEntry] = []
        task_index: dict[str, LedgerEntry] = {}
        agent_index: dict[str, list[LedgerEntry]] = {}
        for line in self.path.read_text().strip().splitlines():
            if not line:
                continue
            entry = LedgerEntry.model_validate_json(line)
            entries.append(entry)
            task_index[entry.task_id] = entry
            agent_id = entry.payload.get("agent_id", "")
            if agent_id:
                agent_index.setdefault(agent_id, []).append(entry)
        self._cache = entries
        self._task_index = task_index
        self._agent_index = agent_index

    def _ensure_loaded(self) -> None:
        """Load cache from disk if not already in memory."""
        if self._cache is None:
            self._load_cache()

    def invalidate_cache(self) -> None:
        """Drop the in-memory cache so the next read re-loads from disk.

        Call this after external processes (e.g. git merge) write directly
        to the underlying file.
        """
        self._cache = None
        self._task_index = {}
        self._agent_index = {}

    def _index_entry(self, entry: LedgerEntry) -> None:
        """Add a single entry to the in-memory indexes."""
        assert self._cache is not None  # always called after _ensure_loaded
        self._cache.append(entry)
        self._task_index[entry.task_id] = entry
        agent_id = entry.payload.get("agent_id", "")
        if agent_id:
            self._agent_index.setdefault(agent_id, []).append(entry)

    # ------------------------------------------------------------------
    # Public API — lookup methods
    # ------------------------------------------------------------------

    def find_by_task_id(self, task_id: str) -> LedgerEntry | None:
        """Return the entry for *task_id*, or None if not found.

        O(1) after the first read.
        """
        self._ensure_loaded()
        return self._task_index.get(task_id)

    def find_by_agent_id(self, agent_id: str) -> list[LedgerEntry]:
        """Return all entries whose payload carries *agent_id*.

        Returns an empty list when the agent has no entries.
        O(1) lookup, O(k) copy where k is the number of matching entries.
        """
        self._ensure_loaded()
        return list(self._agent_index.get(agent_id, []))

    @property
    def latest_hash(self) -> str:
        """Current hash of the last entry, or the genesis hash.

        O(1) after the first read.
        """
        self._ensure_loaded()
        assert self._cache is not None
        if not self._cache:
            return GENESIS_HASH
        return self._cache[-1].current_hash

    @property
    def entry_count(self) -> int:
        """Number of entries in the ledger.

        O(1) after the first read.
        """
        self._ensure_loaded()
        assert self._cache is not None
        return len(self._cache)

    # ------------------------------------------------------------------
    # Original public API — preserved for backward compatibility
    # ------------------------------------------------------------------

    def get_latest_hash(self) -> str:
        """Return the current_hash of the last ledger entry, or genesis hash."""
        self._ensure_loaded()
        assert self._cache is not None
        if not self._cache:
            return GENESIS_HASH
        return self._cache[-1].current_hash

    def append_entry(self, entry: LedgerEntry) -> None:
        """Append a settled entry to the ledger. Thread-safe via lock."""
        with self._write_lock:
            # Warm the cache before writing so _load_cache reads the pre-append
            # state from disk.  After the file write we add the new entry only
            # to the in-memory structures, avoiding a double-count.
            self._ensure_loaded()
            with self.path.open("a") as f:
                f.write(entry.model_dump_json() + "\n")
            self._index_entry(entry)

    def read_all(self) -> list[LedgerEntry]:
        """Return all entries from the ledger.

        Reads from disk on the first call; returns from the in-memory cache
        on subsequent calls. The cache is kept current by ``append_entry``.
        """
        self._ensure_loaded()
        assert self._cache is not None
        return list(self._cache)

    def verify_chain(self) -> bool:
        """Walk the full ledger and verify every hash link.

        Returns True if the chain is intact, False otherwise.
        """
        entries = self.read_all()
        if not entries:
            return True

        expected_parent = GENESIS_HASH
        for entry in entries:
            if entry.parent_hash != expected_parent:
                return False
            # Recompute the hash to verify integrity
            entry_dict = entry.model_dump()
            entry_dict["current_hash"] = ""
            computed = generate_hash(entry_dict)
            if entry.current_hash != computed:
                return False
            expected_parent = entry.current_hash

        return True
