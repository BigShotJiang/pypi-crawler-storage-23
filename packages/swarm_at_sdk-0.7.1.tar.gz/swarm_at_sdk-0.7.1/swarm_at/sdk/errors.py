"""Domain-specific error hierarchy for the swarm.at SDK.

All errors carry the HTTP status code, a human-readable message,
and the raw response body for debugging.
"""

from __future__ import annotations

from typing import Any


class SwarmError(Exception):
    """Base class for all swarm.at SDK errors.

    Attributes:
        status_code: HTTP status code returned by the server.
        message: Human-readable error description.
        body: Raw response body (dict if JSON, str otherwise).

    Example:
        try:
            client.get_credits("unknown")
        except SwarmError as e:
            print(e.status_code, e.message)
    """

    def __init__(self, status_code: int, message: str, body: Any = None) -> None:
        self.status_code = status_code
        self.message = message
        self.body = body
        super().__init__(f"HTTP {status_code}: {message}")


class AuthError(SwarmError):
    """Raised on 401 Unauthorized or 403 Forbidden responses.

    Indicates a missing, invalid, or insufficiently privileged API key.
    """


class RateLimitError(SwarmError):
    """Raised on 429 Too Many Requests responses.

    Attributes:
        retry_after: Seconds to wait before retrying, if the server
            returned a Retry-After header. None if not provided.

    Example:
        except RateLimitError as e:
            if e.retry_after:
                time.sleep(e.retry_after)
    """

    def __init__(
        self,
        status_code: int,
        message: str,
        body: Any = None,
        retry_after: float | None = None,
    ) -> None:
        super().__init__(status_code, message, body)
        self.retry_after = retry_after


class NotFoundError(SwarmError):
    """Raised on 404 Not Found responses."""


class ValidationError(SwarmError):
    """Raised on 422 Unprocessable Entity responses.

    The body typically contains Pydantic validation details.
    """


class ServerError(SwarmError):
    """Raised on 5xx server error responses."""
