"""MCP Settlement Server: gatekeeper for high-risk agent actions.

Exposes tools via the Model Context Protocol that validate agent actions
against Institutional DNA before allowing execution.

Run via stdio:
    python -m swarm_at.mcp.server

Or add to an agent config:
    mcp add swarm-at -- python -m swarm_at.mcp.server
"""

from __future__ import annotations

from typing import Any

from swarm_at.agents import AgentRegistry
from swarm_at.blueprints import BlueprintError, BlueprintStore
from swarm_at.credits import CreditError, CreditLedger
from swarm_at.engine import SwarmAtEngine
from swarm_at.models import (
    AuthorshipClaim,
    Header,
    InstitutionalRules,
    Payload,
    Proposal,
    SettlementStatus,
)
from swarm_at.settler import Ledger, content_fingerprint


class SettlementMCPServer:
    """Core logic for the MCP settlement tools.

    Used both by the FastMCP transport layer and directly in tests.
    """

    def __init__(
        self,
        ledger: Ledger | None = None,
        rules: InstitutionalRules | None = None,
        blocked_commands: list[str] | None = None,
        agent_registry: AgentRegistry | None = None,
        blueprint_store: BlueprintStore | None = None,
        credit_ledger: CreditLedger | None = None,
    ):
        self.engine = SwarmAtEngine(ledger=ledger, rules=rules)
        self.ledger = self.engine.ledger
        self.blocked_commands = set(blocked_commands or [
            "rm -rf /",
            "rm -rf ~",
            "mkfs",
            "dd if=/dev/zero",
            ":(){:|:&};:",
        ])
        self.agent_registry = agent_registry
        self.blueprint_store = blueprint_store or BlueprintStore()
        self.credit_ledger = credit_ledger or CreditLedger()
        from swarm_at.authorship import WritingSessionStore
        self._writing_sessions: WritingSessionStore = WritingSessionStore()

    def check_tool_permission(self, agent_id: str | None, tool_name: str) -> str | None:
        """Check if an agent has permission to use a tool. Returns error message or None."""
        if self.agent_registry is None or agent_id is None:
            return None
        try:
            agent = self.agent_registry.get(agent_id)
        except Exception:
            return f"Agent {agent_id} not found in registry."
        if not agent.can_use_tool(tool_name):
            return f"Agent {agent_id} lacks permission for tool '{tool_name}'."
        return None

    def settle_action(
        self,
        action: str,
        context: dict[str, Any] | None = None,
        parent_hash: str | None = None,
        confidence: float = 0.9,
        agent_id: str | None = None,
    ) -> dict[str, Any]:
        """Validate a proposed action against institutional rules.

        Returns proceed/deny with reason and optional settlement token.
        """
        perm_error = self.check_tool_permission(agent_id, "settle_action")
        if perm_error:
            return {"proceed": False, "reason": perm_error, "settlement_token": None}

        for blocked in self.blocked_commands:
            if blocked in action:
                return {
                    "proceed": False,
                    "reason": f"Action contains blocked command pattern: {blocked}",
                    "settlement_token": None,
                }

        actual_parent = parent_hash or self.ledger.get_latest_hash()
        proposal = Proposal(
            header=Header(parent_hash=actual_parent),
            payload=Payload(
                data_update={"action": action, "context": context or {}},
                confidence_score=confidence,
            ),
            proof=f"MCP settle_action request: {action}",
        )

        result = self.engine.verify_and_settle(proposal)

        if result.status == SettlementStatus.SETTLED:
            return {
                "proceed": True,
                "reason": "Action settled and verified.",
                "settlement_token": result.hash,
            }

        return {
            "proceed": False,
            "reason": result.reason,
            "settlement_token": None,
        }

    def check_settlement(self, task_id: str | None = None, hash: str | None = None, agent_id: str | None = None) -> dict[str, Any]:
        """Query ledger status for a given task or hash."""
        perm_error = self.check_tool_permission(agent_id, "check_settlement")
        if perm_error:
            return {"found": False, "reason": perm_error}

        entries = self.ledger.read_all()

        if task_id:
            for entry in reversed(entries):
                if entry.task_id == task_id:
                    return {
                        "found": True,
                        "task_id": entry.task_id,
                        "hash": entry.current_hash,
                        "timestamp": entry.timestamp,
                    }

        if hash:
            for entry in entries:
                if entry.current_hash == hash:
                    return {
                        "found": True,
                        "task_id": entry.task_id,
                        "hash": entry.current_hash,
                        "timestamp": entry.timestamp,
                    }

        return {"found": False, "reason": "No matching entry in ledger."}

    def list_blueprints(self, tag: str | None = None) -> dict[str, Any]:
        """List available blueprints with optional tag filter."""
        blueprints = self.blueprint_store.list_blueprints(tag=tag)
        return {
            "blueprints": [
                {
                    "blueprint_id": bp.blueprint_id,
                    "name": bp.name,
                    "description": bp.description,
                    "tags": bp.tags,
                    "step_count": len(bp.steps),
                    "validated": bp.validated,
                }
                for bp in blueprints
            ],
            "total": len(blueprints),
        }

    def get_blueprint(self, blueprint_id: str) -> dict[str, Any]:
        """Get full blueprint details including steps."""
        try:
            bp = self.blueprint_store.get_blueprint(blueprint_id)
        except BlueprintError:
            return {"error": f"Blueprint {blueprint_id} not found."}

        try:
            forks = self.blueprint_store.fork_count(blueprint_id)
        except BlueprintError:
            forks = 0

        return {
            "blueprint_id": bp.blueprint_id,
            "name": bp.name,
            "description": bp.description,
            "tags": bp.tags,
            "steps": [
                {
                    "step_id": s.step_id,
                    "name": s.name,
                    "description": s.description,
                    "depends_on": s.depends_on,
                    "agent_role": s.agent_role,
                    "complexity": s.complexity,
                }
                for s in bp.steps
            ],
            "validated": bp.validated,
            "fork_count": forks,
        }

    def get_credits(self, agent_id: str) -> dict[str, Any]:
        """Get agent credit balance."""
        try:
            balance = self.credit_ledger.balance(agent_id)
            return {
                "agent_id": agent_id,
                "balance": balance,
            }
        except CreditError as e:
            return {"error": str(e)}

    def topup_credits(self, agent_id: str, amount: float) -> dict[str, Any]:
        """Add credits to agent balance."""
        new_balance = self.credit_ledger.topup(agent_id, amount)
        return {
            "agent_id": agent_id,
            "balance": new_balance,
            "topup_amount": amount,
        }

    def fork_blueprint(self, blueprint_id: str, agent_id: str = "anonymous") -> dict[str, Any]:
        """Fork a blueprint into an executable workflow."""
        from swarm_at.workflow import fork_blueprint as _fork

        try:
            bp = self.blueprint_store.get_blueprint(blueprint_id)
        except BlueprintError:
            return {"error": f"Blueprint {blueprint_id} not found."}

        molecule = _fork(bp, agent_id=agent_id)
        return {
            "molecule_id": molecule.molecule_id,
            "name": molecule.name,
            "bead_count": len(molecule.beads),
            "metadata": molecule.metadata,
        }

    def verify_receipt(self, hash: str) -> dict[str, Any]:
        """Look up a ledger entry by hash and return receipt-shaped data."""
        entries = self.ledger.read_all()
        for entry in entries:
            if entry.current_hash == hash:
                return {
                    "found": True,
                    "task_id": entry.task_id,
                    "hash": hash,
                    "timestamp": entry.timestamp,
                    "parent_hash": entry.parent_hash,
                }
        return {"found": False, "reason": "No entry with that hash."}

    def check_trust(self, agent_id: str, min_trust: str = "trusted") -> dict[str, Any]:
        """Check if an agent meets a trust threshold."""
        if not self.agent_registry:
            return {"error": "No agent registry configured."}

        from swarm_at.agents import AgentError, TrustLevel

        try:
            level = TrustLevel(min_trust)
        except ValueError:
            return {"error": f"Invalid trust level: {min_trust}"}

        try:
            agent = self.agent_registry.get(agent_id)
        except AgentError:
            return {"error": f"Agent {agent_id} not found."}

        trust_order = list(TrustLevel)
        meets = trust_order.index(agent.trust_level) >= trust_order.index(level)
        return {
            "agent_id": agent.agent_id,
            "meets_requirement": meets,
            "trust_level": agent.trust_level.value,
            "min_trust": min_trust,
        }

    def start_writing_session(self, writer: str, tool: str) -> dict[str, Any]:
        """Create a new authorship provenance session."""
        from swarm_at.authorship import WritingSession

        session = WritingSession(
            writer=writer, tool=tool,
            ledger_path=str(self.ledger.path),
        )
        self._writing_sessions.create(session)
        return {"session_id": session.session_id, "writer": writer, "tool": tool}

    def record_writing_event(
        self,
        session_id: str,
        event_type: str,
        action: str = "",
        chose: str = "",
        rejected: list[str] | None = None,
        text: str = "",
        output_hash: str = "",
        model: str = "",
        description: str = "",
        kept_ratio: float = 0.0,
        reason: str = "",
        phase: str = "scene",
    ) -> dict[str, Any]:
        """Record a creative event in an authorship session."""
        from swarm_at.authorship import CreativePhase

        session = self._writing_sessions.get(session_id)
        if not session:
            return {"error": f"Session {session_id} not found."}
        try:
            cp = CreativePhase(phase)
        except ValueError:
            return {"error": f"Invalid phase: {phase}. Valid: {[p.value for p in CreativePhase]}"}

        if event_type == "direction":
            result = session.direct(action=action, chose=chose, rejected=rejected, phase=cp)
        elif event_type == "prompt":
            result = session.prompt(text=text, phase=cp)
        elif event_type == "generation":
            result = session.generate(output_hash=output_hash, model=model, phase=cp)
        elif event_type == "revision":
            result = session.revise(description=description, kept_ratio=kept_ratio, phase=cp)
        elif event_type == "rejection":
            result = session.reject(output_hash=output_hash, reason=reason, phase=cp)
        else:
            return {"error": f"Invalid event_type: {event_type}. Valid: direction, prompt, generation, revision, rejection"}

        return {"status": result.status.value, "hash": result.hash}

    def approve_writing(
        self, session_id: str, content_hash: str, version: str = "",
    ) -> dict[str, Any]:
        """Record final approval of content."""
        session = self._writing_sessions.get(session_id)
        if not session:
            return {"error": f"Session {session_id} not found."}
        result = session.approve(content_hash=content_hash, version=version)
        return {"status": result.status.value, "hash": result.hash}

    def get_provenance_report(self, session_id: str) -> dict[str, Any]:
        """Generate a verifiable provenance report."""
        session = self._writing_sessions.get(session_id)
        if not session:
            return {"error": f"Session {session_id} not found."}
        result: dict[str, Any] = session.report().model_dump()
        return result

    def list_writing_sessions(self, writer: str | None = None) -> dict[str, Any]:
        """List active authorship sessions with optional writer filter."""
        sessions = self._writing_sessions.list_sessions(writer=writer)
        return {
            "sessions": [
                {
                    "session_id": s.session_id,
                    "writer": s.writer,
                    "tool": s.tool,
                    "event_count": len(s.events),
                    "work_agency": s.work_agency,
                }
                for s in sessions
            ],
            "total": len(sessions),
        }


    def settle_batch(self, proposals: list[dict[str, Any]]) -> dict[str, Any]:
        """Settle multiple proposals sequentially. Continues on individual failures."""
        from swarm_at.models import SettleRequest

        results = []
        settled = 0
        rejected = 0

        for raw in proposals:
            try:
                req = SettleRequest.model_validate(raw)
                result = self.engine.verify_and_settle(req.primary, shadow=req.shadow)
                results.append({"status": result.status.value, "hash": result.hash, "reason": result.reason})
                if result.status.value == "SETTLED":
                    settled += 1
                else:
                    rejected += 1
            except Exception as exc:
                results.append({"status": "REJECTED", "hash": None, "reason": str(exc)})
                rejected += 1

        return {"results": results, "settled": settled, "rejected": rejected}

    def claim_authorship(
        self,
        agent_id: str,
        content: str,
        content_type: str = "",
        label: str = "",
        confidence: float = 0.95,
    ) -> dict[str, Any]:
        """Claim authorship of content. Fingerprints and settles to ledger."""
        c_hash = content_fingerprint(content)
        claim = AuthorshipClaim(
            agent_id=agent_id,
            content_hash=c_hash,
            content_type=content_type,
            label=label,
        )
        proposal = Proposal(
            header=Header(parent_hash=self.ledger.get_latest_hash()),
            payload=Payload(
                data_update=claim.model_dump(),
                confidence_score=confidence,
            ),
            proof=f"authorship-claim by {agent_id}",
        )
        result = self.engine.verify_and_settle(proposal)
        if result.status == SettlementStatus.SETTLED:
            return {
                "claimed": True,
                "content_hash": c_hash,
                "settlement_hash": result.hash,
                "agent_id": agent_id,
            }
        return {
            "claimed": False,
            "reason": result.reason,
        }

    def verify_authorship(
        self,
        content_hash: str,
        agent_id: str = "",
    ) -> dict[str, Any]:
        """Verify an authorship claim by content hash."""
        return self.engine.verify_authorship(content_hash, agent_id=agent_id)


def create_mcp_app(ledger_path: str = "ledger.jsonl") -> Any:
    """Create a FastMCP app wired to the settlement engine.

    Returns the FastMCP instance ready for stdio or SSE transport.
    """
    from mcp.server import FastMCP

    mcp = FastMCP(
        name="swarm-at",
        instructions=(
            "Happy path: register_agent to get your agent ID and 100 free credits, "
            "then check_credits before doing work, then guard_action before any "
            "destructive or irreversible operation (file deletion, payment, deploy, "
            "shell command), then verify_receipt with the returned hash to prove "
            "the action was approved. Each settlement costs 1 credit. "
            "A 402 response means insufficient credits -- call topup_credits to add more. "
            "Use check_trust to verify a peer agent meets a trust threshold before "
            "delegating work to it. "
            "Use list_blueprints to browse 32 reusable multi-step workflow templates "
            "across categories like audit, code-review, and finance. "
            "Use start_writing_session and record_writing_event to track human-AI "
            "authorship provenance and generate compliance reports."
        ),
    )

    from swarm_at.seed_blueprints import seed_blueprints

    store = BlueprintStore()
    seed_blueprints(store)
    server = SettlementMCPServer(ledger=Ledger(path=ledger_path), blueprint_store=store)

    @mcp.tool()  # type: ignore[misc,untyped-decorator]
    def settle_action(
        action: str,
        context: str = "{}",
        confidence: float = 0.9,
    ) -> str:
        """Use before any high-stakes action (file deletion, payment, deploy, shell command).

        Validates the action against institutional rules and returns a settlement
        token as proof of approval.

        Args:
            action: Description of the action to validate (e.g. "rm -rf /tmp/cache")
            context: JSON string of additional context for the action
            confidence: Confidence score for this action (0.0-1.0)
        """
        import json
        ctx = json.loads(context) if context else {}
        result = server.settle_action(action=action, context=ctx, confidence=confidence)
        return json.dumps(result, indent=2)

    @mcp.tool()  # type: ignore[misc,untyped-decorator]
    def check_settlement(
        task_id: str = "",
        hash: str = "",
    ) -> str:
        """Use when you need to verify that a previous action was actually approved.

        Look up by task ID or settlement hash.

        Args:
            task_id: The task ID to look up
            hash: The settlement hash to look up
        """
        import json
        result = server.check_settlement(
            task_id=task_id or None,
            hash=hash or None,
        )
        return json.dumps(result, indent=2)

    @mcp.tool()  # type: ignore[misc,untyped-decorator]
    def ledger_status() -> str:
        """Use to check ledger health — latest hash, entry count, and whether the chain is intact."""
        import json
        latest = server.ledger.get_latest_hash()
        intact = server.ledger.verify_chain()
        count = len(server.ledger.read_all())
        return json.dumps({
            "latest_hash": latest,
            "entry_count": count,
            "chain_intact": intact,
        }, indent=2)

    @mcp.tool()  # type: ignore[misc,untyped-decorator]
    def list_blueprints(tag: str = "") -> str:
        """Use to find pre-built multi-step workflows.

        Filter by tag (e.g. 'audit', 'code-review', 'finance'). Returns 32
        blueprints across 6 categories.

        Args:
            tag: Filter blueprints by tag (e.g. "audit", "code-review"). Empty for all.
        """
        import json
        result = server.list_blueprints(tag=tag or None)
        return json.dumps(result, indent=2)

    @mcp.tool()  # type: ignore[misc,untyped-decorator]
    def get_blueprint(blueprint_id: str) -> str:
        """Use to inspect a specific blueprint's steps and roles before forking it.

        Args:
            blueprint_id: The blueprint ID to look up (e.g. "audit-chain")
        """
        import json
        result = server.get_blueprint(blueprint_id)
        return json.dumps(result, indent=2)

    @mcp.tool()  # type: ignore[misc,untyped-decorator]
    def get_credits(agent_id: str) -> str:
        """Use to check how many settlement credits an agent has remaining.

        Each settlement costs credits.

        Args:
            agent_id: The agent identifier to look up
        """
        import json
        result = server.get_credits(agent_id)
        return json.dumps(result, indent=2)

    @mcp.tool()  # type: ignore[misc,untyped-decorator]
    def topup_credits(agent_id: str, amount: float) -> str:
        """Use to add settlement credits to an agent's balance when running low.

        Args:
            agent_id: The agent identifier
            amount: Amount of credits to add
        """
        import json
        result = server.topup_credits(agent_id, amount)
        return json.dumps(result, indent=2)

    @mcp.tool()  # type: ignore[misc,untyped-decorator]
    def guard_action(
        agent_id: str,
        action: str,
        data: str = "{}",
    ) -> str:
        """Use before any destructive or irreversible operation.

        Takes your agent ID and action description, settles it against the
        ledger, and returns a receipt. Rejected actions get a clear reason.

        Args:
            agent_id: The agent performing the action
            action: Description of the action to guard
            data: JSON string of action parameters
        """
        import json
        ctx = json.loads(data) if data else {}
        result = server.settle_action(action=action, context=ctx, agent_id=agent_id)
        return json.dumps(result, indent=2)

    @mcp.tool()  # type: ignore[misc,untyped-decorator]
    def fork_blueprint(blueprint_id: str, agent_id: str = "anonymous") -> str:
        """Use to create an executable workflow from a blueprint template.

        Assigns the workflow to your agent.

        Args:
            blueprint_id: The blueprint ID to fork (e.g. "audit-chain")
            agent_id: The agent who will execute the workflow (default: "anonymous")
        """
        import json
        result = server.fork_blueprint(blueprint_id, agent_id)
        return json.dumps(result, indent=2)

    @mcp.tool()  # type: ignore[misc,untyped-decorator]
    def verify_receipt(hash: str) -> str:
        """Use to prove a past action was approved.

        Given a 64-char settlement hash, returns the full receipt with task ID,
        timestamp, and parent hash.

        Args:
            hash: The 64-character settlement hash to verify
        """
        import json
        result = server.verify_receipt(hash)
        return json.dumps(result, indent=2)

    @mcp.tool()  # type: ignore[misc,untyped-decorator]
    def check_trust(agent_id: str, min_trust: str = "trusted") -> str:
        """Use before delegating work to another agent.

        Checks if they meet a trust threshold (untrusted/provisional/trusted/senior).

        Args:
            agent_id: The agent identifier to check
            min_trust: Minimum trust level (untrusted, provisional, trusted, senior)
        """
        import json
        result = server.check_trust(agent_id, min_trust)
        return json.dumps(result, indent=2)

    @mcp.tool()  # type: ignore[misc,untyped-decorator]
    def start_writing_session(writer: str, tool: str) -> str:
        """Start tracking authorship provenance for human-AI creative work.

        Creates a session that records every creative decision and AI action
        to the settlement ledger. Use this when a human is working with an AI
        tool and needs to prove creative control.

        Args:
            writer: Human writer identifier (e.g. "jane-doe")
            tool: AI tool identifier (e.g. "claude-sonnet-4-5")
        """
        import json
        result = server.start_writing_session(writer, tool)
        return json.dumps(result, indent=2)

    @mcp.tool()  # type: ignore[misc,untyped-decorator]
    def record_writing_event(
        session_id: str,
        event_type: str,
        action: str = "",
        chose: str = "",
        rejected: str = "[]",
        text: str = "",
        output_hash: str = "",
        model: str = "",
        description: str = "",
        kept_ratio: float = 0.0,
        reason: str = "",
        phase: str = "scene",
    ) -> str:
        """Record a creative event in an authorship session.

        Event types and their required parameters:
        - direction: action, chose (optional: rejected as JSON array)
        - prompt: text (the prompt text, hashed not stored)
        - generation: output_hash (optional: model)
        - revision: description, kept_ratio (0.0-1.0)
        - rejection: output_hash, reason

        Phase: concept, structure, character, scene, dialogue, revision

        Args:
            session_id: Session ID from start_writing_session
            event_type: One of: direction, prompt, generation, revision, rejection
            action: What decision was made (direction)
            chose: What was chosen (direction)
            rejected: JSON array of rejected alternatives (direction)
            text: Prompt text given to AI (prompt)
            output_hash: SHA-256 of AI output (generation, rejection)
            model: AI model identifier (generation)
            description: What the human changed (revision)
            kept_ratio: Fraction of AI output kept, 0.0-1.0 (revision)
            reason: Why output was rejected (rejection)
            phase: Creative phase (concept/structure/character/scene/dialogue/revision)
        """
        import json
        rej_list = json.loads(rejected) if rejected and rejected != "[]" else None
        result = server.record_writing_event(
            session_id=session_id,
            event_type=event_type,
            action=action,
            chose=chose,
            rejected=rej_list,
            text=text,
            output_hash=output_hash,
            model=model,
            description=description,
            kept_ratio=kept_ratio,
            reason=reason,
            phase=phase,
        )
        return json.dumps(result, indent=2)

    @mcp.tool()  # type: ignore[misc,untyped-decorator]
    def approve_writing(
        session_id: str,
        content_hash: str,
        version: str = "",
    ) -> str:
        """Record final approval of creative content.

        The content_hash should be the SHA-256 of the final approved content.
        This closes the provenance chain for the session.

        Args:
            session_id: Session ID from start_writing_session
            content_hash: SHA-256 hash of the approved final content
            version: Optional version label (e.g. "v1", "final-draft")
        """
        import json
        result = server.approve_writing(session_id, content_hash, version)
        return json.dumps(result, indent=2)

    @mcp.tool()  # type: ignore[misc,untyped-decorator]
    def get_provenance_report(session_id: str) -> str:
        """Generate a verifiable authorship provenance report.

        Returns work agency score (0.0-1.0), compliance assessments
        (USCO copyright, WGA credit, SAG-AFTRA, EU AI Act), behavioral
        flags, and full event timeline with settlement hashes.

        Scores >= 90% trigger the professional safe harbor.

        Args:
            session_id: Session ID from start_writing_session
        """
        import json
        result = server.get_provenance_report(session_id)
        return json.dumps(result, indent=2, default=str)

    @mcp.tool()  # type: ignore[misc,untyped-decorator]
    def list_writing_sessions(writer: str = "") -> str:
        """List active authorship provenance sessions.

        Shows all tracked writing sessions with their current work agency scores.
        Filter by writer to see only their sessions.

        Args:
            writer: Filter by writer name. Empty for all sessions.
        """
        import json
        result = server.list_writing_sessions(writer=writer or None)
        return json.dumps(result, indent=2, default=str)

    @mcp.tool()  # type: ignore[misc,untyped-decorator]
    def claim_authorship(
        agent_id: str,
        content: str,
        content_type: str = "",
        label: str = "",
    ) -> str:
        """Use after producing content to create a verifiable authorship record.

        Fingerprints the content (not stored), settles the claim to the ledger,
        and returns a settlement hash you can share as proof.

        Args:
            agent_id: Your agent identifier
            content: The content you authored (fingerprinted, not stored)
            content_type: Type of content (text, code, blueprint, analysis)
            label: Short description of what the content is
        """
        import json
        result = server.claim_authorship(agent_id, content, content_type, label)
        return json.dumps(result, indent=2)

    @mcp.tool()  # type: ignore[misc,untyped-decorator]
    def verify_authorship(
        content_hash: str,
        agent_id: str = "",
    ) -> str:
        """Use to check if an agent authored specific content.

        Provide the SHA-256 content hash and optional agent ID. Returns the
        earliest claim with timestamp and trust level.

        Args:
            content_hash: SHA-256 hash of the content to verify (64-char hex)
            agent_id: Optional agent ID to verify against (empty checks all)
        """
        import json
        result = server.verify_authorship(content_hash, agent_id)
        return json.dumps(result, indent=2)

    @mcp.tool()  # type: ignore[misc,untyped-decorator]
    def settle_batch(proposals: str) -> str:
        """Settle multiple proposals in one call. Continues past individual failures.

        Use when you have several actions to settle at once (e.g. a batch of
        Polymarket trades or code-review steps). Each proposal is settled
        sequentially to preserve hash-chain order. Returns per-proposal results
        with aggregate settled/rejected counts.

        Args:
            proposals: JSON array of proposal objects. Each must have a "primary"
                key with header and payload. Example:
                [{"primary": {"header": {"parent_hash": "<64-char-hash>"},
                              "payload": {"data_update": {}, "confidence_score": 0.9}}}]
        """
        import json
        proposal_list = json.loads(proposals)
        result = server.settle_batch(proposal_list)
        return json.dumps(result, indent=2)

    return mcp
