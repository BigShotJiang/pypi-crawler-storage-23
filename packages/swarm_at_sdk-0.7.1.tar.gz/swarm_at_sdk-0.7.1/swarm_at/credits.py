"""Credit tracking for swarm.at agent operations."""

from __future__ import annotations

import json
import logging
from pathlib import Path


class CreditError(Exception):
    """Raised on insufficient balance or unknown agent."""
    pass


FREE_SETTLEMENT_QUOTA = 100


class CreditLedger:
    """In-memory credit tracking for agent operations.

    Manages agent credit balances with basic accounting operations.
    """

    def __init__(self, default_balance: float = 100.0) -> None:
        """Initialize credit ledger with default balance for new agents.

        Args:
            default_balance: Initial balance assigned to new agents (default: 100.0)
        """
        self._balances: dict[str, float] = {}
        self._default_balance = default_balance
        self._free_used: dict[str, int] = {}

    def balance(self, agent_id: str) -> float:
        """Get current balance for an agent.

        Args:
            agent_id: Agent identifier

        Returns:
            Current credit balance

        Raises:
            CreditError: If agent is not registered
        """
        if agent_id not in self._balances:
            raise CreditError(f"Agent {agent_id} not registered.")
        return self._balances[agent_id]

    def topup(self, agent_id: str, amount: float) -> float:
        """Add credits to an agent's balance.

        Creates agent entry if not exists. Auto-registers with default balance
        before adding the topup amount.

        Args:
            agent_id: Agent identifier
            amount: Credits to add

        Returns:
            New balance after topup
        """
        if agent_id not in self._balances:
            self._balances[agent_id] = self._default_balance
        self._balances[agent_id] += amount
        return self._balances[agent_id]

    def debit(self, agent_id: str, amount: float) -> float:
        """Subtract credits from an agent's balance.

        Args:
            agent_id: Agent identifier
            amount: Credits to deduct

        Returns:
            New balance after debit

        Raises:
            CreditError: If agent not registered or insufficient balance
        """
        if agent_id not in self._balances:
            raise CreditError(f"Agent {agent_id} not registered.")
        if self._balances[agent_id] < amount:
            raise CreditError(
                f"Insufficient credits: agent {agent_id} has "
                f"{self._balances[agent_id]}, needs {amount}."
            )
        self._balances[agent_id] -= amount
        return self._balances[agent_id]

    def can_afford(self, agent_id: str, amount: float) -> bool:
        """Check if agent has sufficient balance without debiting.

        Args:
            agent_id: Agent identifier
            amount: Credits required

        Returns:
            True if agent has sufficient balance, False otherwise
        """
        if agent_id not in self._balances:
            return False
        return self._balances[agent_id] >= amount

    def debit_or_free(self, agent_id: str, amount: float) -> tuple[float, int]:
        """Debit credits, or use free quota if available.

        Returns (balance, free_remaining). If the agent has free settlements
        remaining, the debit is skipped and the free counter incremented.
        """
        used = self._free_used.get(agent_id, 0)
        if used < FREE_SETTLEMENT_QUOTA:
            self._free_used[agent_id] = used + 1
            balance = self._balances.get(agent_id, 0.0)
            return (balance, FREE_SETTLEMENT_QUOTA - used - 1)
        new_balance = self.debit(agent_id, amount)
        return (new_balance, 0)

    def register(
        self, agent_id: str, initial_balance: float | None = None
    ) -> float:
        """Register agent with initial balance.

        If agent already registered, returns existing balance without modification.

        Args:
            agent_id: Agent identifier
            initial_balance: Starting balance (uses default if None)

        Returns:
            Agent's balance after registration (existing or new)
        """
        if agent_id in self._balances:
            return self._balances[agent_id]
        balance = initial_balance if initial_balance is not None else self._default_balance
        self._balances[agent_id] = balance
        return balance

    def all_balances(self) -> dict[str, float]:
        """Get snapshot of all agent balances.

        Returns:
            Dictionary mapping agent_id to balance
        """
        return dict(self._balances)


class PersistentCreditLedger(CreditLedger):
    """CreditLedger backed by an append-only JSONL event log.

    Every mutation appends an event to credits.jsonl. On init, replays
    the log to rebuild in-memory balances.
    """

    def __init__(
        self, path: str | Path = "credits.jsonl", default_balance: float = 100.0
    ) -> None:
        super().__init__(default_balance=default_balance)
        self.path = Path(path)
        self._log = logging.getLogger("swarm_at.credits.persistent")
        self._replay()

    def _append(self, event: dict[str, object]) -> None:
        with open(self.path, "a") as f:
            f.write(json.dumps(event) + "\n")

    def _replay(self) -> None:
        if not self.path.exists():
            return
        count = 0
        for line in self.path.read_text().splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                event = json.loads(line)
                self._apply(event)
                count += 1
            except (json.JSONDecodeError, KeyError) as exc:
                self._log.warning("Skipping bad credit event: %s (%s)", line[:80], exc)
        self._log.info("Replayed %d credit events from %s", count, self.path)

    def _apply(self, event: dict[str, object]) -> None:
        kind = str(event["event"])
        agent_id = str(event["agent_id"])
        if kind == "register":
            balance = float(event.get("balance", self._default_balance))  # type: ignore[arg-type]
            super().register(agent_id, initial_balance=balance)
        elif kind == "topup":
            amount = float(event["amount"])  # type: ignore[arg-type]
            super().topup(agent_id, amount)
        elif kind == "debit":
            amount = float(event["amount"])  # type: ignore[arg-type]
            super().debit(agent_id, amount)

    def register(
        self, agent_id: str, initial_balance: float | None = None
    ) -> float:
        result = super().register(agent_id, initial_balance=initial_balance)
        if agent_id in self._balances:
            self._append({
                "event": "register",
                "agent_id": agent_id,
                "balance": result,
            })
        return result

    def topup(self, agent_id: str, amount: float) -> float:
        result = super().topup(agent_id, amount)
        self._append({
            "event": "topup",
            "agent_id": agent_id,
            "amount": amount,
        })
        return result

    def debit(self, agent_id: str, amount: float) -> float:
        result = super().debit(agent_id, amount)
        self._append({
            "event": "debit",
            "agent_id": agent_id,
            "amount": amount,
        })
        return result

    def debit_or_free(self, agent_id: str, amount: float) -> tuple[float, int]:
        result = super().debit_or_free(agent_id, amount)
        used = self._free_used.get(agent_id, 0)
        if used <= FREE_SETTLEMENT_QUOTA:
            self._append({
                "event": "free_settlement",
                "agent_id": agent_id,
                "free_used": used,
            })
        return result


def check_blueprint_cost(
    credit_ledger: CreditLedger, agent_id: str, blueprint_cost: float
) -> None:
    """Check if agent can afford blueprint cost.

    Convenience function for affordability checks before operations.

    Args:
        credit_ledger: CreditLedger instance
        agent_id: Agent identifier
        blueprint_cost: Required credits

    Raises:
        CreditError: If agent cannot afford the blueprint cost
    """
    if not credit_ledger.can_afford(agent_id, blueprint_cost):
        raise CreditError(
            f"Agent {agent_id} cannot afford blueprint cost {blueprint_cost}."
        )
