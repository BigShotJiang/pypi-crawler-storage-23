"""Settlement tiers: graduated adoption from sandbox to production."""

from __future__ import annotations

import os
from enum import Enum

from pydantic import BaseModel


class SettlementTier(str, Enum):
    """Graduated settlement tiers for adoption ramp."""

    SANDBOX = "sandbox"  # Log-only, no ledger writes
    STAGING = "staging"  # Writes ledger, no chain enforcement
    PRODUCTION = "production"  # Full verification + chain integrity


class TierPolicy(BaseModel):
    """Controls what a tier enforces."""

    enforce_chain: bool = True
    enforce_confidence: bool = True
    write_ledger: bool = True
    log_only: bool = False


TIER_POLICIES: dict[SettlementTier, TierPolicy] = {
    SettlementTier.SANDBOX: TierPolicy(
        enforce_chain=False,
        enforce_confidence=False,
        write_ledger=False,
        log_only=True,
    ),
    SettlementTier.STAGING: TierPolicy(
        enforce_chain=False,
        enforce_confidence=True,
        write_ledger=True,
        log_only=False,
    ),
    SettlementTier.PRODUCTION: TierPolicy(
        enforce_chain=True,
        enforce_confidence=True,
        write_ledger=True,
        log_only=False,
    ),
}


def get_tier() -> SettlementTier:
    """Read tier from SWARM_TIER env var, default to PRODUCTION."""
    raw = os.environ.get("SWARM_TIER", "production").lower()
    try:
        return SettlementTier(raw)
    except ValueError:
        return SettlementTier.PRODUCTION


def get_policy(tier: SettlementTier | None = None) -> TierPolicy:
    """Return the policy for a tier. Uses get_tier() if tier not provided."""
    if tier is None:
        tier = get_tier()
    return TIER_POLICIES[tier]
