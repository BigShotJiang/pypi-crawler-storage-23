"""LangGraph adapter: settle node outputs as Beads."""

from __future__ import annotations

import functools
from typing import Any, Callable

from swarm_at.settle import SettlementContext
from swarm_at.tiers import SettlementTier


class SwarmNodeWrapper:
    """Wraps LangGraph node functions to settle their outputs.

    Usage::

        wrapper = SwarmNodeWrapper(agent="research-agent")

        @wrapper.wrap
        def research_node(state: dict) -> dict:
            return {"findings": "..."}

    Maps: node function -> Bead, graph state -> Payload, node name -> agent.
    """

    def __init__(
        self,
        agent: str = "langgraph-node",
        confidence: float = 0.95,
        context: SettlementContext | None = None,
        tier: SettlementTier | None = None,
    ) -> None:
        self.agent = agent
        self.confidence = confidence
        self.context = context or SettlementContext(tier=tier)

    def wrap(self, fn: Callable[..., Any]) -> Callable[..., Any]:
        """Decorator: runs node function, settles output, returns original result."""

        @functools.wraps(fn)
        def wrapped(*args: Any, **kwargs: Any) -> Any:
            result = fn(*args, **kwargs)
            node_name = getattr(fn, "__name__", self.agent)
            data: dict[str, Any] = {}
            if isinstance(result, dict):
                data = result
            else:
                data = {"output": str(result)}
            self.context.settle(
                agent=node_name,
                task=f"langgraph:{node_name}",
                data=data,
                confidence=self.confidence,
            )
            return result

        return wrapped
