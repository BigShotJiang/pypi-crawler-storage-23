"""OpenAI Assistants adapter: settle runs and run steps."""

from __future__ import annotations

from typing import Any

from swarm_at.settle import SettlementContext
from swarm_at.tiers import SettlementTier


class SwarmRunHandler:
    """Settles OpenAI Assistant runs and individual run steps.

    Usage::

        handler = SwarmRunHandler(assistant_id="asst_abc123")
        # After polling run to completion:
        handler.settle_run(run, messages)
        # Or per-step:
        handler.settle_step("tool_calls", step_data)

    Maps: Run -> Molecule, RunStep -> Bead, Assistant -> agent_id.
    """

    def __init__(
        self,
        assistant_id: str = "openai-assistant",
        context: SettlementContext | None = None,
        confidence: float = 0.95,
        tier: SettlementTier | None = None,
    ) -> None:
        self.assistant_id = assistant_id
        self.confidence = confidence
        self.context = context or SettlementContext(tier=tier)

    def settle_run(self, run: Any, messages: Any = None) -> Any:
        """Settle a completed run as a molecule-level settlement."""
        run_id = getattr(run, "id", str(run))
        run_status = getattr(run, "status", "completed")

        msg_data: list[str] = []
        if isinstance(messages, list):
            for m in messages:
                content = getattr(m, "content", "")
                if isinstance(content, list):
                    for block in content:
                        text = getattr(block, "text", None)
                        if text:
                            msg_data.append(getattr(text, "value", str(text)))
                else:
                    msg_data.append(str(content))

        return self.context.settle(
            agent=self.assistant_id,
            task=f"openai:run:{run_id}",
            data={
                "run_id": str(run_id),
                "status": str(run_status),
                "messages": msg_data,
            },
            confidence=self.confidence,
            task_id=str(run_id),
        )

    def settle_step(self, step_type: str, step_data: Any = None) -> Any:
        """Settle an individual run step as a bead-level settlement."""
        data: dict[str, Any] = {"step_type": step_type}
        if isinstance(step_data, dict):
            data.update(step_data)
        elif step_data is not None:
            step_id = getattr(step_data, "id", None)
            if step_id:
                data["step_id"] = str(step_id)
            step_detail = getattr(step_data, "step_details", None)
            if step_detail:
                data["details"] = str(step_detail)

        return self.context.settle(
            agent=self.assistant_id,
            task=f"openai:step:{step_type}",
            data=data,
            confidence=self.confidence,
        )
