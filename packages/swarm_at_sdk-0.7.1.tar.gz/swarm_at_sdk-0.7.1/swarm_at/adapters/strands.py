"""Strands Agents (AWS) adapter: settle tool and agent completions."""

from __future__ import annotations

from typing import Any

from swarm_at.settle import SettlementContext
from swarm_at.tiers import SettlementTier


class SwarmStrandsCallback:
    """Callback for Strands Agent lifecycle events.

    Usage::

        callback = SwarmStrandsCallback()
        # After tool execution:
        callback.on_tool_complete("search", {"query": "test"}, {"results": [...]})
        # After agent completes:
        callback.on_agent_complete("research-agent", result)

    Duck-types Strands objects via getattr — no hard dependency on strands-agents.
    """

    def __init__(
        self,
        context: SettlementContext | None = None,
        confidence: float = 0.95,
        tier: SettlementTier | None = None,
    ) -> None:
        self.confidence = confidence
        self.context = context or SettlementContext(tier=tier)

    def on_tool_complete(
        self, tool_name: str, tool_input: Any, tool_output: Any,
    ) -> Any:
        """Settle a completed tool execution."""
        return self.context.settle(
            agent=f"strands:{tool_name}",
            task=f"strands:tool:{tool_name}",
            data={
                "tool": tool_name,
                "input": str(tool_input),
                "output": str(tool_output),
            },
            confidence=self.confidence,
        )

    def on_agent_complete(self, agent_name: str, result: Any) -> Any:
        """Settle a completed agent run."""
        output = getattr(result, "output", str(result))
        return self.context.settle(
            agent=str(agent_name),
            task=f"strands:agent:{agent_name}",
            data={
                "agent": str(agent_name),
                "output": str(output),
            },
            confidence=self.confidence,
        )
