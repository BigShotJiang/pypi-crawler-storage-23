"""Observability middleware for the swarm.at API.

Provides:
- Correlation IDs (X-Request-ID header, generated if absent)
- Structured JSON request logging when SWARM_LOG_FORMAT=json
- In-memory Prometheus-compatible metrics counters
"""

from __future__ import annotations

import json
import logging
import os
import time
import uuid
from collections import defaultdict
from typing import Any

from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import Response
from starlette.types import ASGIApp

# ---------------------------------------------------------------------------
# Logging setup
# ---------------------------------------------------------------------------

_LOG_FORMAT = os.environ.get("SWARM_LOG_FORMAT", "").lower()
_JSON_LOGGING = _LOG_FORMAT == "json"


class _JsonFormatter(logging.Formatter):
    """Emit log records as single-line JSON objects."""

    def format(self, record: logging.LogRecord) -> str:
        data: dict[str, Any] = {
            "timestamp": self.formatTime(record, "%Y-%m-%dT%H:%M:%S"),
            "level": record.levelname,
            "logger": record.name,
            "message": record.getMessage(),
        }
        # Merge any extra fields attached to the record
        for key, value in record.__dict__.items():
            if key not in (
                "args", "created", "exc_info", "exc_text", "filename",
                "funcName", "levelname", "levelno", "lineno", "message",
                "module", "msecs", "msg", "name", "pathname", "process",
                "processName", "relativeCreated", "stack_info", "taskName",
                "thread", "threadName",
            ):
                data[key] = value
        if record.exc_info:
            data["exc_info"] = self.formatException(record.exc_info)
        return json.dumps(data)


def _configure_request_logger() -> logging.Logger:
    logger = logging.getLogger("swarm_at.api.requests")
    logger.setLevel(logging.INFO)
    if not logger.handlers:
        handler = logging.StreamHandler()
        if _JSON_LOGGING:
            handler.setFormatter(_JsonFormatter())
        else:
            handler.setFormatter(
                logging.Formatter("%(asctime)s %(levelname)s %(name)s %(message)s")
            )
        logger.addHandler(handler)
    logger.propagate = False
    return logger


_request_logger = _configure_request_logger()


# ---------------------------------------------------------------------------
# In-memory metrics store
# ---------------------------------------------------------------------------

class _Metrics:
    """Thread-safe-enough in-memory metrics store.

    All counters and histograms live here. The /metrics route reads from this
    singleton. It resets when the process restarts (which is fine for
    Prometheus scraping — the server handles rate calculation).
    """

    # Predefined histogram buckets for request duration (seconds)
    DURATION_BUCKETS: tuple[float, ...] = (
        0.005, 0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 1.0, 2.5, 5.0, 10.0
    )

    def __init__(self) -> None:
        self.total_requests: int = 0
        self.total_settlements: int = 0
        # status_code -> count
        self.error_count_by_status: dict[int, int] = defaultdict(int)
        # duration histogram: bucket_le -> count
        self._duration_buckets: dict[float, int] = {b: 0 for b in self.DURATION_BUCKETS}
        self._duration_inf: int = 0  # +Inf bucket
        self._duration_sum: float = 0.0
        self._duration_count: int = 0

    def record_request(self, status_code: int, duration_seconds: float, path: str) -> None:
        self.total_requests += 1
        if status_code >= 400:
            self.error_count_by_status[status_code] += 1
        # Update histogram
        for bucket in self.DURATION_BUCKETS:
            if duration_seconds <= bucket:
                self._duration_buckets[bucket] += 1
        self._duration_inf += 1
        self._duration_sum += duration_seconds
        self._duration_count += 1

    def record_settlement(self) -> None:
        self.total_settlements += 1

    def prometheus_text(self) -> str:
        """Render metrics in Prometheus text exposition format (v0.0.4)."""
        lines: list[str] = []

        # total_requests counter
        lines.append("# HELP swarm_total_requests Total HTTP requests received")
        lines.append("# TYPE swarm_total_requests counter")
        lines.append(f"swarm_total_requests_total {self.total_requests}")

        # total_settlements counter
        lines.append("# HELP swarm_total_settlements Total proposals settled")
        lines.append("# TYPE swarm_total_settlements counter")
        lines.append(f"swarm_total_settlements_total {self.total_settlements}")

        # error_count_by_status counter
        lines.append("# HELP swarm_errors_total Total error responses by status code")
        lines.append("# TYPE swarm_errors_total counter")
        for status_code, count in sorted(self.error_count_by_status.items()):
            lines.append(f'swarm_errors_total{{status="{status_code}"}} {count}')

        # request_duration_seconds histogram
        lines.append("# HELP swarm_request_duration_seconds HTTP request latency histogram")
        lines.append("# TYPE swarm_request_duration_seconds histogram")
        for bucket, count in sorted(self._duration_buckets.items()):
            lines.append(
                f'swarm_request_duration_seconds_bucket{{le="{bucket}"}} {count}'
            )
        lines.append(f'swarm_request_duration_seconds_bucket{{le="+Inf"}} {self._duration_inf}')
        lines.append(f"swarm_request_duration_seconds_sum {self._duration_sum:.6f}")
        lines.append(f"swarm_request_duration_seconds_count {self._duration_count}")

        return "\n".join(lines) + "\n"


# Module-level singleton — imported by main.py and the middleware
metrics = _Metrics()


# ---------------------------------------------------------------------------
# Request logging + correlation ID middleware
# ---------------------------------------------------------------------------

class ObservabilityMiddleware(BaseHTTPMiddleware):
    """Add correlation IDs and structured request logging to every request.

    - Reads X-Request-ID from the incoming request, or generates a new UUID4.
    - Stores the correlation ID on request.state.correlation_id.
    - Echoes the ID back in the X-Request-ID response header.
    - Logs method, path, status, duration_ms, and correlation_id after the
      response is sent.
    - Records request duration in the metrics store.
    """

    def __init__(self, app: ASGIApp) -> None:
        super().__init__(app)

    async def dispatch(self, request: Request, call_next: Any) -> Response:
        # Resolve or generate correlation ID
        correlation_id = request.headers.get("X-Request-ID") or str(uuid.uuid4())
        request.state.correlation_id = correlation_id

        start = time.monotonic()
        response: Response = await call_next(request)
        duration_ms = (time.monotonic() - start) * 1000

        # Echo correlation ID in response
        response.headers["X-Request-ID"] = correlation_id

        # Update metrics (skip /metrics itself to avoid self-scraping noise)
        if request.url.path != "/metrics":
            metrics.record_request(
                status_code=response.status_code,
                duration_seconds=duration_ms / 1000,
                path=request.url.path,
            )
            # Count settlement hits by path pattern
            if request.url.path in ("/v1/settle", "/v1/settle/batch") and response.status_code == 200:
                metrics.record_settlement()

        # Log the request
        log_extra: dict[str, Any] = {
            "method": request.method,
            "path": request.url.path,
            "status": response.status_code,
            "duration_ms": round(duration_ms, 2),
            "correlation_id": correlation_id,
        }

        if _JSON_LOGGING:
            _request_logger.info("request", extra=log_extra)
        else:
            _request_logger.info(
                "%s %s %d %.2fms [%s]",
                request.method,
                request.url.path,
                response.status_code,
                duration_ms,
                correlation_id,
                extra=log_extra,
            )

        return response
