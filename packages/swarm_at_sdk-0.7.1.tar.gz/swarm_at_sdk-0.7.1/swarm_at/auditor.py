"""Shadow Auditor: cross-model divergence detection."""

from __future__ import annotations

import functools
from typing import Any, Callable

from swarm_at.engine import calculate_divergence
from swarm_at.models import Header, Payload, Proposal


def shadow_audit(
    shadow_fn: Callable[..., dict[str, Any]],
    max_drift: float = 0.15,
) -> Callable[[Callable[..., dict[str, Any]]], Callable[..., dict[str, Any]]]:
    """Decorator that runs a shadow function alongside the primary and checks divergence.

    Usage:
        @shadow_audit(shadow_fn=cheap_model_call)
        def primary_task(context):
            return expensive_model_call(context)

    If divergence exceeds max_drift, raises DivergenceError with details.
    Otherwise returns the primary result.
    """

    def decorator(primary_fn: Callable[..., dict[str, Any]]) -> Callable[..., dict[str, Any]]:
        @functools.wraps(primary_fn)
        def wrapper(*args: Any, **kwargs: Any) -> dict[str, Any]:
            primary_result = primary_fn(*args, **kwargs)
            shadow_result = shadow_fn(*args, **kwargs)

            primary_proposal = _result_to_proposal(primary_result)
            shadow_proposal = _result_to_proposal(shadow_result)

            divergence = calculate_divergence(primary_proposal, shadow_proposal)
            if divergence > max_drift:
                raise DivergenceError(
                    f"Shadow audit failed: divergence {divergence:.2f} > {max_drift:.2f}",
                    primary=primary_result,
                    shadow=shadow_result,
                    divergence=divergence,
                )

            return primary_result

        return wrapper

    return decorator


def _result_to_proposal(result: dict[str, Any]) -> Proposal:
    """Wrap a plain dict result into a Proposal for divergence calculation."""
    return Proposal(
        header=Header(parent_hash="0" * 64),
        payload=Payload(data_update=result, confidence_score=1.0),
    )


class DivergenceError(Exception):
    """Raised when shadow audit detects divergence above threshold."""

    def __init__(
        self,
        message: str,
        primary: dict[str, Any],
        shadow: dict[str, Any],
        divergence: float,
    ):
        super().__init__(message)
        self.primary = primary
        self.shadow = shadow
        self.divergence = divergence
