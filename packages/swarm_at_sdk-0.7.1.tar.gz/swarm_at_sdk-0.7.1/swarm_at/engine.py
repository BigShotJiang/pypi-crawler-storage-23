"""Core Settlement Engine: verify proposals and commit to ledger."""

from __future__ import annotations

import time
from typing import Any

from swarm_at.models import (
    AgentMetadata,
    AuthorshipClaim,
    AuthorshipReceipt,
    Header,
    InstitutionalRules,
    LedgerEntry,
    Payload,
    Proposal,
    SettlementReceipt,
    SettlementResult,
    SettlementStatus,
)
from swarm_at.settler import Ledger, generate_hash


class SwarmAtEngine:
    """Orchestrates verification and settlement of agent proposals."""

    def __init__(
        self,
        ledger: Ledger | None = None,
        rules: InstitutionalRules | None = None,
    ):
        self.ledger = ledger or Ledger()
        self.rules = rules or InstitutionalRules()

    def verify_and_settle(
        self,
        primary: Proposal,
        shadow: Proposal | None = None,
    ) -> SettlementResult:
        """Run the full verification pipeline and settle if valid.

        Steps:
        1. Hash-chain integrity check
        2. Confidence threshold check
        3. Shadow audit divergence check (if shadow provided)
        4. Commit to ledger
        """
        latest_hash = self.ledger.get_latest_hash()

        # 1. Integrity check
        if primary.header.parent_hash != latest_hash:
            return SettlementResult(
                status=SettlementStatus.REJECTED,
                reason="State drift: parent_hash is stale. Fetch GET /v1/ledger/latest for the current hash and retry.",
            )

        # 2. Confidence check
        if primary.payload.confidence_score < self.rules.min_confidence:
            return SettlementResult(
                status=SettlementStatus.REJECTED,
                reason=f"Insufficient confidence score: {primary.payload.confidence_score} < {self.rules.min_confidence}",
            )

        # 3. Shadow audit
        if shadow is not None:
            divergence = calculate_divergence(primary, shadow)
            if divergence > self.rules.max_drift_allowed:
                return SettlementResult(
                    status=SettlementStatus.ESCROWED,
                    reason=f"High model divergence: {divergence} > {self.rules.max_drift_allowed}",
                )

        # 4. Finality — build entry, hash it, append
        entry_dict = {
            "timestamp": time.time(),
            "task_id": primary.header.task_id,
            "parent_hash": latest_hash,
            "payload": primary.payload.data_update,
            "current_hash": "",
        }
        entry_dict["current_hash"] = generate_hash(entry_dict)

        entry = LedgerEntry.model_validate(entry_dict)
        self.ledger.append_entry(entry)

        return SettlementResult(
            status=SettlementStatus.SETTLED,
            hash=entry.current_hash,
        )

    def settle_with_receipt(
        self,
        primary: Proposal,
        shadow: Proposal | None = None,
        agent_id: str = "",
        credit_cost: float = 0.0,
        trust_level: str = "",
    ) -> SettlementReceipt:
        """Settle and return a rich receipt for third-party verification."""
        result = self.verify_and_settle(primary, shadow=shadow)

        receipt = SettlementReceipt(
            status=result.status,
            hash=result.hash,
            reason=result.reason,
            task_id=primary.header.task_id,
            agent_id=agent_id,
            credit_cost=credit_cost,
            trust_level=trust_level,
        )

        # Enrich with ledger data on success
        if result.status == SettlementStatus.SETTLED and result.hash:
            entries = self.ledger.read_all()
            for entry in reversed(entries):
                if entry.current_hash == result.hash:
                    receipt.timestamp = entry.timestamp
                    receipt.parent_hash = entry.parent_hash
                    break

        return receipt


    def claim_authorship(
        self,
        agent_id: str,
        content_hash: str,
        content_type: str = "",
        label: str = "",
        metadata: dict[str, Any] | None = None,
        confidence: float = 0.95,
        trust_level: str = "",
        credit_cost: float = 0.0,
    ) -> AuthorshipReceipt:
        """Settle an authorship claim. Binds agent_id + content_hash in the ledger."""
        claim = AuthorshipClaim(
            agent_id=agent_id,
            content_hash=content_hash,
            content_type=content_type,
            label=label,
            metadata=metadata or {},
        )
        proposal = Proposal(
            header=Header(
                parent_hash=self.ledger.get_latest_hash(),
                agent_metadata=AgentMetadata(model=agent_id),
            ),
            payload=Payload(
                data_update=claim.model_dump(),
                confidence_score=confidence,
            ),
            proof=f"authorship-claim by {agent_id}",
        )
        result = self.verify_and_settle(proposal)

        receipt = AuthorshipReceipt(
            status=result.status,
            hash=result.hash,
            reason=result.reason,
            task_id=proposal.header.task_id,
            agent_id=agent_id,
            credit_cost=credit_cost,
            trust_level=trust_level,
            content_hash=content_hash,
            content_type=content_type,
        )

        if result.status == SettlementStatus.SETTLED and result.hash:
            entries = self.ledger.read_all()
            for entry in reversed(entries):
                if entry.current_hash == result.hash:
                    receipt.timestamp = entry.timestamp
                    receipt.parent_hash = entry.parent_hash
                    break

        return receipt

    def verify_authorship(
        self,
        content_hash: str,
        agent_id: str = "",
    ) -> dict[str, Any]:
        """Find authorship claims for a content hash in the ledger."""
        claims: list[dict[str, Any]] = []
        entries = self.ledger.read_all()
        for i, entry in enumerate(entries):
            payload = entry.payload
            if payload.get("type") != "authorship-claim":
                continue
            if payload.get("content_hash") != content_hash:
                continue
            if agent_id and payload.get("agent_id") != agent_id:
                continue
            claims.append({
                "agent_id": payload.get("agent_id", ""),
                "content_hash": content_hash,
                "settlement_hash": entry.current_hash,
                "timestamp": entry.timestamp,
                "chain_position": i,
                "content_type": payload.get("content_type", ""),
                "label": payload.get("label", ""),
            })

        if not claims:
            return {"verified": False, "reason": "No authorship claim found for this content hash"}

        claims.sort(key=lambda c: c["timestamp"])
        first = claims[0]
        return {
            "verified": True,
            "agent_id": first["agent_id"],
            "content_hash": content_hash,
            "settlement_hash": first["settlement_hash"],
            "timestamp": first["timestamp"],
            "chain_position": first["chain_position"],
            "claims": claims,
            "first_claim": {"agent_id": first["agent_id"], "timestamp": first["timestamp"]},
        }


def calculate_divergence(primary: Proposal, shadow: Proposal) -> float:
    """Calculate divergence between primary and shadow proposals.

    Returns 0.0 if payloads match, 1.0 if they differ.
    Can be extended with NLP similarity for partial matches.
    """
    p1 = primary.payload.data_update
    p2 = shadow.payload.data_update

    if p1 == p2:
        return 0.0

    # Structural comparison: count matching vs total keys
    all_keys = set(p1.keys()) | set(p2.keys())
    if not all_keys:
        return 0.0

    matching = sum(1 for k in all_keys if p1.get(k) == p2.get(k))
    return 1.0 - (matching / len(all_keys))
