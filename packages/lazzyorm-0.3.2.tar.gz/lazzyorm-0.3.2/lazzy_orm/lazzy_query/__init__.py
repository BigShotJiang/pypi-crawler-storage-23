from lazzy_orm.lazzy_query.lazzy_query import LazyQuery

__all__ = ['LazyQuery']
