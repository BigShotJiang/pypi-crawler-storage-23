from lazzy_orm.lazzy_update.lazzy_update import LazyUpdate

__all__ = ['LazyUpdate']
