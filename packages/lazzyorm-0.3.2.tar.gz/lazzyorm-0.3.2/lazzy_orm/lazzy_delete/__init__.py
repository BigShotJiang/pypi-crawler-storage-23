from lazzy_orm.lazzy_delete.lazzy_delete import LazyDelete

__all__ = ['LazyDelete']
