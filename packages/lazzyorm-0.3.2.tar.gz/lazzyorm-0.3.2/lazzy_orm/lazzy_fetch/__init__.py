from lazzy_orm.lazzy_fetch.lazzy_fetch import LazyFetch
