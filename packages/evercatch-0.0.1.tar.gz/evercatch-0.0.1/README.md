# 📦 Evercatch Python

> Official Python SDK for Evercatch webhook infrastructure platform.

---

## 🧭 Overview

This repository contains the official Python SDK for the Evercatch platform. Its purpose is to provide a simple and convenient interface for developers to interact with the Evercatch API, manage webhooks, and handle events within their Python applications.

**⚠️ This SDK is currently under active development and is not yet ready for production use. The package published on PyPI is a placeholder to reserve the name.**

---

## 🛠️ Tech Stack

The final technology stack is being determined. The planned stack is as follows:

| Layer | Technology |
| :--- | :--- |
| Language | Python |
| Framework | None (Standard Library + Minimal Dependencies) |
| Key Dependencies | `httpx` or `requests` (for HTTP), `Pydantic` (for data models) |

---

## 🚀 Getting Started

### Prerequisites

- Python 3.12+

### Installation (Future)

Once released, the package will be available on PyPI:
```bash
# This will not work until the first official release
pip install evercatch
```

### Local Development

The repository can be cloned for contribution or testing once development is further along.

```bash
# Clone the repo
git clone https://git.psmattas.com/Evercatch/evercatch-python.git

cd evercatch-python

# Note: The project is not yet functional.
```

---

## 🌿 Branching & Commits

All work follows the Evercatch contribution guide defined in the org README.

**Branch format:** `EC-ID-short-description`
**Commit format:** `EC-00: type(scope): message`

See [Evercatch Org README](https://git.psmattas.com/Evercatch) for full conventions.

---

## ⚙️ CI/CD

Automated via Jenkins. Merges to `main` trigger staging deployments.

| Pipeline | Status |
| :--- | :---: |
| Build | ![Build Status](https://img.shields.io/badge/build-pending-lightgrey) |
| Lint | ![Lint Status](https://img.shields.io/badge/lint-pending-lightgrey) |
| Test | ![Test Status](https://img.shields.io/badge/tests-pending-lightgrey) |

---

## 📄 License

**Copyright © 2026 Evercatch.**
Proprietary and confidential. Unauthorised distribution is strictly prohibited.
