"""Web route mixins — extracted from web.py to reduce god object."""
