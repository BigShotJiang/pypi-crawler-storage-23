# PicoClaw — Lightweight Remote Shell & AI Agent Client for Python

[![PyPI](https://img.shields.io/pypi/v/picoclaw.svg)](https://pypi.org/project/picoclaw/) [![Python](https://img.shields.io/pypi/pyversions/picoclaw.svg)](https://pypi.org/project/picoclaw/) [![license](https://img.shields.io/pypi/l/picoclaw.svg)](https://github.com/commandoperator/cmdop-sdk-python/blob/main/LICENSE)

![CMDOP Architecture](https://cmdop.com/images/architecture/vs-personal-agent.png)

PicoClaw provides a lightweight SSH alternative Python developers can use for minimal remote execution. Unlike SSH2, node-ssh, simple-ssh, and execa, PicoClaw offers a fast AI agent client and zero-config remote shell. Start scripting remote tasks and interacting with AI agents rapidly, bypassing complex setups.

## Features

- Execute remote commands with a lightweight SSH alternative Python interface.
- Enable minimal remote execution without complex configurations.
- Provide a fast AI agent client for quick interactions with remote AI models.
- Establish a zero-config remote shell for immediate access.
- Simplify remote file operations with a Pythonic API.

## Use Cases

- Execute shell commands on remote machines in one line
- Ask the AI agent questions and get instant answers
- Read and write remote files without SSH setup

## Installation

```bash
pip install picoclaw
```

## Quick Start

```python
from picoclaw import PicoClaw

client = PicoClaw.remote(api_key="cmdop_live_xxx")

uptime = client.run("uptime")
answer = client.ask("What is the most memory-hungry process right now?")

config = client.read("/etc/nginx/nginx.conf")
client.write("/tmp/backup.conf", config)

print(answer)
```

## Links

- [CMDOP Homepage](https://cmdop.com)
- [Documentation](https://cmdop.com/docs/sdk/python/)
- [picoclaw on PyPI](https://pypi.org/project/picoclaw/)
- [GitHub](https://github.com/commandoperator/cmdop-sdk-python)
