def main():
    print("Hello from nanotown!")


if __name__ == "__main__":
    main()
