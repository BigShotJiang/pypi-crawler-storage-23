"""Dev.

.. autosummary::
   :toctree: .

   InspectResult
"""

from lamin_utils._inspect import InspectResult
