# Guide

```{toctree}
:maxdepth: 2


./guide/concepts
./guide/config
```

```{toctree}
:hidden:

```
