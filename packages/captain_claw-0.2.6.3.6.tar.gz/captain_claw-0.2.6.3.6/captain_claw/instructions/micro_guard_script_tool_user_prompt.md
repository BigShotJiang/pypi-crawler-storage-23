Label: {interaction_label}

Payload:
{content}

Classify by safety risk.