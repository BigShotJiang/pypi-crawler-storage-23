Extract list members and per-member action.

User request:
{user_input}

Context:
{context_excerpt}

JSON only.