Interaction label: {interaction_label}

Content to evaluate:
{content}

Classify strictly by safety risk.
