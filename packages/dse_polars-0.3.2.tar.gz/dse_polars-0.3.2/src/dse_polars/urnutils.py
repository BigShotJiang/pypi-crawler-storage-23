passagecomponent_re = r":[^:]*$"
