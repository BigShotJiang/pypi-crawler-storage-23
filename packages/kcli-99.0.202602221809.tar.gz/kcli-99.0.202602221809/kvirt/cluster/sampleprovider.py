def scale(config, plandir, cluster, overrides):
    return {'result': 'success'}


def create(config, plandir, cluster, overrides, dnsconfig=None):
    return {'result': 'success'}
