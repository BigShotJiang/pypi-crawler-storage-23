import json
import os
import threading
from PyQt6.QtCore import QObject, pyqtSlot, pyqtSignal
from Orange.widgets import widget
from Orange.widgets.settings import Setting
from .web_utils import WebEngineMixin
from .settings_business_logic import _gid, _cl, _al, _dal


class SettingsBridge(QObject):
    def __init__(self, _v, _pw):
        super().__init__()
        self._v = _v
        self._pw = _pw
        self._pj = []
        self._ld = False
        self._v.loadFinished.connect(self._ol)

    def _ol(self, _ok):
        if _ok:
            self._ld = True
            for _j in self._pj:
                self._v.page().runJavaScript(_j)
            self._pj.clear()

    def _rj(self, _j):
        if self._ld:
            self._v.page().runJavaScript(_j)
        else:
            self._pj.append(_j)

    def sendDataToJs(self, _jd):
        _e = _jd.replace("\\", "\\\\").replace("`", "\\`").replace("${", "\\${")
        self._rj(
            f"window.receiveDataFromPython && window.receiveDataFromPython(`{_e}`);"
        )

    def showNoDataMessage(self):
        self._rj("window.showNoDataMessage && showNoDataMessage();")

    @pyqtSlot(str)
    def uiEvent(self, _js: str):
        self._pw.on_ui_event(_js)


class OWSettings(WebEngineMixin, widget.OWWidget):
    name = "Settings"
    description = "License management & application settings"
    category = "Altera Data Suite"
    icon = "icons/settings.svg"
    priority = 200
    want_main_area = True
    want_control_area = False
    resizing_enabled = True
    dummy_setting = Setting("")
    _ss = pyqtSignal(str)

    def __init__(self):
        super().__init__()
        self.resize(800, 600)
        self._mid: str = _gid()
        self._ss.connect(self._pu)
        _h = os.path.join(os.path.dirname(__file__), "UI", "settings", "index.html")
        self.setup_webengine_lazy(_h, SettingsBridge, zoom_factor=0.9)

    def on_webengine_ready(self):
        pass

    def on_webengine_show(self):
        pass

    @pyqtSlot(str)
    def on_ui_event(self, _js: str):
        try:
            _ev = json.loads(_js)
        except Exception:
            return
        _t = _ev.get("type")
        if _t == "get_machine_id":
            self._snd({"type": "machine_id", "machine_id": self._mid})
        elif _t == "check_license":
            threading.Thread(
                target=_cl, args=(self._mid, self._snd), daemon=True
            ).start()
        elif _t == "activate":
            threading.Thread(
                target=_al,
                args=(
                    _ev.get("license_key", ""),
                    _ev.get("machine_id", self._mid),
                    self._snd,
                ),
                daemon=True,
            ).start()
        elif _t == "deactivate":
            threading.Thread(
                target=_dal,
                args=(_ev.get("machine_id", self._mid), self._snd),
                daemon=True,
            ).start()

    def _snd(self, _p: dict):
        self._ss.emit(json.dumps(_p))

    @pyqtSlot(str)
    def _pu(self, _js: str):
        self.bridge.sendDataToJs(_js)
