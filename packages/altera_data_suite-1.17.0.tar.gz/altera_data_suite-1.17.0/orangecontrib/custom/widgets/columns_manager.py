import os
import json
from PyQt6.QtCore import QObject, pyqtSlot
from Orange.widgets import widget
from Orange.widgets.widget import Input, Output
from Orange.widgets.settings import Setting
from Orange.data import Table
from .web_utils import WebEngineMixin
from .auxiliary_functions import _o2do, _gci, _icc, _asc, _acc, _d2ocm, _bpp


class _Br(QObject):
    def __init__(self, _v, _pw):
        super().__init__()
        self._v = _v
        self._pw = _pw
        self._pj = []
        self._ld = False
        self._v.loadFinished.connect(self._ol)

    def _ol(self, ok):
        if ok:
            self._ld = True
            for _j in self._pj:
                self._v.page().runJavaScript(_j)
            self._pj.clear()

    def _rj(self, _j):
        if self._ld:
            self._v.page().runJavaScript(_j)
        else:
            self._pj.append(_j)

    def _std(self, _d):
        self._rj(f"window.initializeTable&&initializeTable({_d});")

    def _sn(self):
        self._rj("window.showNoDataMessage&&showNoDataMessage();")

    def _rs(self, _s):
        self._rj(f"window.restoreColumnState&&restoreColumnState({_s});")

    @pyqtSlot(str)
    def columnsChanged(self, _s):
        self._pw._occ(_s)

    @pyqtSlot()
    def resetRequested(self):
        self._pw._orr()


class OWColumnManager(WebEngineMixin, widget.OWWidget):
    name = "Column Manager"
    description = (
        "Reorder, rename, add, and delete columns with drag-and-drop interface"
    )
    category = "Altera Data Suite"
    icon = "icons/column_manager.svg"
    priority = 20

    class Inputs:
        data = Input("Input Table", Table)

    class Outputs:
        modified_data = Output("Modified Data", Table)

    column_state = Setting('{"columns":[],"originalInputFields":[]}', schema_only=True)
    want_main_area = True
    want_control_area = False
    resizing_enabled = True

    class Error(widget.OWWidget.Error):
        invalid_data = widget.Msg("Unable to process data: {}")
        license_error = widget.Msg("License error: {}")

    def __init__(self):
        super().__init__()
        self._id = None
        self._od = None
        self._df = None
        self.setMinimumWidth(800)
        self.setMinimumHeight(600)
        _h = os.path.join(
            os.path.dirname(__file__), "UI", "columns_manager_ui", "index.html"
        )
        self.setup_webengine_lazy(_h, _Br, zoom_factor=0.9)

    def on_webengine_ready(self):
        if self._id is not None:
            self.set_data(self._id)
        elif self.web_loaded and self.bridge:
            self.bridge._sn()

    @Inputs.data
    def set_data(self, data):
        self.Error.clear()
        if data is None:
            self._id = None
            self._df = None
            self._od = None
            self.Outputs.modified_data.send(None)
            if self.web_loaded and self.bridge:
                self.bridge._sn()
            return
        self._id = data
        self._od = data.domain
        self._df = _o2do(data)
        _ci = _gci(data, self._df)
        _oif = {c["field"] for c in _ci}
        _sdc = []
        try:
            _ss = json.loads(self.column_state)
            _sc = _ss.get("columns", [])
            _sdc = _ss.get("deletedColumns", [])
            _sof = _ss.get("originalInputFields", [])
            if _sc:
                if set(_sof) == _oif or _icc(_sc, _ci):
                    _ci = _asc(_sc, _ci, self.column_state)
                    if set(_sof) != _oif:
                        self.column_state = json.dumps(
                            {
                                "columns": _ci,
                                "deletedColumns": _sdc,
                                "originalInputFields": list(_oif),
                            }
                        )
                else:
                    _sdc = []
                    self.column_state = json.dumps(
                        {
                            "columns": _ci,
                            "deletedColumns": [],
                            "originalInputFields": list(_oif),
                        }
                    )
            else:
                _sdc = []
                self.column_state = json.dumps(
                    {
                        "columns": _ci,
                        "deletedColumns": [],
                        "originalInputFields": list(_oif),
                    }
                )
        except Exception:
            _sdc = []
            self.column_state = json.dumps(
                {
                    "columns": _ci,
                    "deletedColumns": [],
                    "originalInputFields": list(_oif),
                }
            )
        try:
            self._df = _acc(self._df, _ci)
            _js = _bpp(self._df, _ci, _sdc, preview_rows=100)
            if self.web_loaded and self.bridge:
                self.bridge._std(_js)
            self._ao()
        except RuntimeError as _e:
            self.Error.license_error(str(_e))
            self.Outputs.modified_data.send(None)

    def _occ(self, _s):
        try:
            _st = json.loads(_s)
            _ci = _st.get("columns", [])
            _dc = _st.get("deletedColumns", [])
            try:
                _oif = json.loads(self.column_state).get("originalInputFields", [])
            except Exception:
                _oif = (
                    [c["field"] for c in _gci(self._id, self._df)] if self._id else []
                )
            self.column_state = json.dumps(
                {"columns": _ci, "deletedColumns": _dc, "originalInputFields": _oif}
            )
            if self._df is not None:
                self._df = _acc(self._df, _ci)
                self._ao()
        except RuntimeError as _e:
            self.Error.license_error(str(_e))
            self.Outputs.modified_data.send(None)
        except Exception:
            import traceback

            traceback.print_exc()

    def _orr(self):
        if self._id is not None:
            self.column_state = (
                '{"columns":[],"deletedColumns":[],"originalInputFields":[]}'
            )
            self.set_data(self._id)

    def _ao(self):
        if self._df is None or len(self._df.columns) == 0:
            self.Outputs.modified_data.send(None)
            return
        try:
            _ci = json.loads(self.column_state).get("columns", [])
            if not _ci:
                self.Outputs.modified_data.send(self._id)
                return
            self.Outputs.modified_data.send(_d2ocm(self._df, _ci, self._od))
        except RuntimeError as _e:
            self.Error.license_error(str(_e))
            self.Outputs.modified_data.send(None)
        except Exception as _e:
            import traceback

            traceback.print_exc()
            self.Error.invalid_data(str(_e))
            self.Outputs.modified_data.send(None)
