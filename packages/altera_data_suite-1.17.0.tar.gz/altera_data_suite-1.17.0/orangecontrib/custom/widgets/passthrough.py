from Orange.widgets import widget, gui
from Orange.widgets.widget import Input, Output
from Orange.data import Table

_SS = """QLabel{font-family:'Roboto','Segoe UI',sans-serif;font-size:12px;color:#333333;padding:6px;background-color:#e3f2fd;border-radius:4px;border-left:3px solid #2196f3;}"""
_SO = """QLabel{font-family:'Roboto','Segoe UI',sans-serif;font-size:12px;color:#1b5e20;padding:6px;background-color:#e8f5e9;border-radius:4px;border-left:3px solid #4caf50;}"""
_ST = """QLabel{font-family:'Roboto','Segoe UI',sans-serif;font-size:11px;color:#666666;padding:3px 6px;background-color:#f5f5f5;border-radius:3px;}"""
_SB = """QGroupBox{font-family:'Roboto','Segoe UI',sans-serif;font-size:11px;font-weight:600;color:#333333;border:1px solid #e0e0e0;border-radius:6px;margin-top:8px;padding:12px;background-color:white;}QGroupBox::title{subcontrol-origin:margin;left:10px;padding:0 5px;color:#333333;font-weight:600;}"""


class OWPassthrough(widget.OWWidget):
    name = "Passthrough"
    description = "Passes data through without modifications"
    category = "Altera Data Suite"
    icon = "icons/passthrough.svg"
    priority = 100

    class Inputs:
        data = Input("Input Table", Table)

    class Outputs:
        data = Output("Output Table", Table)

    want_main_area = False
    resizing_enabled = True

    def __init__(self):
        super().__init__()
        self._id = None
        self.resize(340, 250)
        self._su()

    def _su(self):
        self.controlArea.setStyleSheet(
            "QWidget{font-family:'Roboto','Segoe UI',sans-serif;background-color:#fafafa;}"
        )
        _ib = gui.widgetBox(self.controlArea, "Data Information", spacing=8)
        _ib.setStyleSheet(_SB)
        self._sl = gui.widgetLabel(_ib, "Waiting for data...")
        self._sl.setWordWrap(True)
        self._sl.setStyleSheet(_SS)
        self._dl = gui.widgetLabel(_ib, "")
        self._dl.setWordWrap(True)
        self._dl.setStyleSheet(
            "QLabel{font-family:'Roboto','Segoe UI',sans-serif;font-size:11px;color:#666666;padding:4px;}"
        )
        _sb = gui.widgetBox(self.controlArea, "Statistics", spacing=8)
        _sb.setStyleSheet(_SB)
        _sc = gui.widgetBox(_sb, box=None, spacing=4)
        self._rl = gui.widgetLabel(_sc, "Rows: —")
        self._cl = gui.widgetLabel(_sc, "Columns: —")
        self._al = gui.widgetLabel(_sc, "Attributes: —")
        self._ml = gui.widgetLabel(_sc, "Meta columns: —")
        for _l in [self._rl, self._cl, self._al, self._ml]:
            _l.setStyleSheet(_ST)

    @Inputs.data
    def set_data(self, data):
        if data is None:
            self._id = None
            self.Outputs.data.send(None)
            self._sl.setText("⏳ Waiting for data...")
            self._sl.setStyleSheet(_SS)
            self._dl.setText("Connect a data table to pass it through")
            self._rl.setText("Rows: —")
            self._cl.setText("Columns: —")
            self._al.setText("Attributes: —")
            self._ml.setText("Meta columns: —")
        else:
            self._id = data
            self.Outputs.data.send(data)
            _nr = len(data)
            _na = len(data.domain.attributes)
            _nm = len(data.domain.metas)
            _nc = len(data.domain.class_vars)
            self._sl.setText(f"✓ Passing {_nr:,} rows through")
            self._sl.setStyleSheet(_SO)
            self._dl.setText("Data flowing through widget\nNo modifications applied")
            self._rl.setText(f"Rows: {_nr:,}")
            self._cl.setText(f"Columns: {_na + _nm + _nc}")
            self._al.setText(f"Attributes: {_na}")
            self._ml.setText(
                f"Meta columns: {_nm}" + (f" • Target: {_nc}" if _nc > 0 else "")
            )
