"""qa 节点 — 统一导出。"""

from .router import make_router

__all__ = ["make_router"]
