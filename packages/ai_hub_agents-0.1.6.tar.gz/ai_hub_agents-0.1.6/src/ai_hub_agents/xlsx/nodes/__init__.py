"""xlsx 节点 — 统一导出。"""

from .init_output import auto_init_output

__all__ = ["auto_init_output"]
