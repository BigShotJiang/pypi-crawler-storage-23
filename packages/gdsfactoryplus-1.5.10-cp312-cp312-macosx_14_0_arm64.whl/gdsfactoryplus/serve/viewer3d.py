"""3D viewer routes."""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING, Any, NoReturn

from fastapi import HTTPException
from fastapi.responses import HTMLResponse
from jinja2 import Environment, FileSystemLoader

from .app import app

if TYPE_CHECKING:
    import gdsfactoryplus.core.pdk as gfp_pdk
    import gdsfactoryplus.core.show3d as show3d  # noqa: PLR0402
else:
    from gdsfactoryplus.core.lazy import lazy_import

    gfp_pdk = lazy_import("gdsfactoryplus.core.pdk")
    show3d = lazy_import("gdsfactoryplus.core.show3d")

TEMPLATES_DIR = (
    Path(__file__).resolve().parent.parent / "assets" / "templates" / "viewer3d"
)
_jinja_env = Environment(
    loader=FileSystemLoader(TEMPLATES_DIR),
    autoescape=True,
)


def _render_template(template_name: str, **kwargs: Any) -> str:
    """Render a Jinja2 template."""
    template = _jinja_env.get_template(template_name)
    return template.render(**kwargs)


def _raise_not_found(name: str) -> NoReturn:
    """Raise 404 for missing factory."""
    raise HTTPException(status_code=404, detail=f"Factory '{name}' not found")


@app.get("/viewer3d/{name}")
def viewer3d_page(name: str, output: str = "layer") -> HTMLResponse:
    """Display 3D viewer for a factory."""
    html = _render_template(
        "base.html",
        name=name,
        output=output,
    )
    return HTMLResponse(html)


@app.get("/api/viewer3d/{name}/data")
def viewer3d_get_data(
    name: str,
    output: str = "layer",
    z_scale: float = 1.0,
    curve_tolerance: float = 0.01,
) -> dict[str, Any]:
    """Get 3D viewer data for a factory.

    Args:
        name: Factory name
        output: Output type - "layer" or "cell"
        z_scale: Scale factor for z-axis
        curve_tolerance: Tolerance for curve simplification

    Returns:
        3D viewer data dict
    """
    try:
        pdk = gfp_pdk.get_pdk()

        if name not in pdk.cells:
            _raise_not_found(name)

        factory = pdk.cells[name]
        cell = factory()

        output_enum = show3d.Output.LAYER if output == "layer" else show3d.Output.CELL

        viewer_data = show3d.to_3D_viewer(
            cell,
            output=output_enum,
            z_scale=z_scale,
            curve_tolerance=curve_tolerance,
            as_dict=True,
        )

        # Encode numpy arrays to base64 for JSON serialization
        encoded_data = show3d.numpy_to_buffer_json(viewer_data)

    except HTTPException:
        raise
    except (TypeError, ValueError, KeyError, AttributeError, AssertionError) as e:
        return {"detail": str(e)}
    else:
        return {"data": encoded_data}


@app.post("/api/viewer3d/{name}/data")
def viewer3d_post_data(
    name: str,
    request: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Get 3D viewer data for a factory with POST request body.

    Args:
        name: Factory name
        request: Request body with options

    Returns:
        3D viewer data dict
    """
    request = request or {}
    output = request.get("output", "layer")
    z_scale = request.get("z_scale", 1.0)
    curve_tolerance = request.get("curve_tolerance", 0.01)
    exclude_layers = request.get("exclude_layers")

    try:
        pdk = gfp_pdk.get_pdk()

        if name not in pdk.cells:
            _raise_not_found(name)

        factory = pdk.cells[name]
        cell = factory()

        output_enum = show3d.Output.LAYER if output == "layer" else show3d.Output.CELL

        viewer_data = show3d.to_3D_viewer(
            cell,
            output=output_enum,
            z_scale=z_scale,
            curve_tolerance=curve_tolerance,
            exclude_layers=exclude_layers,
            as_dict=True,
        )

        # Encode numpy arrays to base64 for JSON serialization
        encoded_data = show3d.numpy_to_buffer_json(viewer_data)

    except HTTPException:
        raise
    except (TypeError, ValueError, KeyError, AttributeError, AssertionError) as e:
        return {"detail": str(e)}
    else:
        return {"data": encoded_data}
