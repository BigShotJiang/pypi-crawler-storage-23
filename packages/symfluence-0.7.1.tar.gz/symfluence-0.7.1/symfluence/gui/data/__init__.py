# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2024-2026 SYMFLUENCE Team <dev@symfluence.org>

"""
Gauge station data providers, caching, and results loading for the SYMFLUENCE GUI.

Provides uniform access to hydrometric station metadata from multiple
networks (WSC, USGS, SMHI, LamaH-ICE) with local CSV caching, plus
a results loader for project output visualization.
"""

from .gauge_provider import (
    GaugeProvider,
    LamaHICEProvider,
    SMHIProvider,
    USGSProvider,
    WSCProvider,
)
from .gauge_store import GaugeStationStore
from .results_loader import ResultsLoader

__all__ = [
    'GaugeProvider',
    'WSCProvider',
    'USGSProvider',
    'SMHIProvider',
    'LamaHICEProvider',
    'GaugeStationStore',
    'ResultsLoader',
]
