#!/usr/bin/env python
"""Template: Enrich one date -> Delta Lake.

Pipeline (stays lazy until merge_forward):
  scan_trade -> fill enrichment -> parse_time  (lazy)
  scan_alpha -> parse_time                     (lazy)
  asof join (alpha predictions -> trade)       (lazy)
  merge_forward (bid/ask/size at horizons)     (collect here)
  base/forward split -> Delta Lake

Derived enrichments (mid, spread, return, touch, markout) are NOT stored.
They are computed lazily at analysis time (see explore_dashboard.py template).

Delta Lake write strategy:
  - Partition-level overwrite via predicate (concurrent-safe, idempotent)
  - Completeness check: skips dates where all expected sub-partitions exist
  - Use --force to reprocess even if complete

To use this template:
  1. Copy: vf.templates.copy_template("enrich_by_date.py", "my_enrich.py")
  2. Edit CONFIG section with your data paths and schemas
  3. Edit FORWARD MERGE CONFIG with your horizons and ref_cols
  4. Run: python my_enrich.py --date 20240827

Output: enriched/base/ and enriched/forward/ (Delta Lake)

Requires: pip install deltalake
"""
from __future__ import annotations

import argparse
from pathlib import Path

import polars as pl
import vizflow as vf

try:
    from deltalake import DeltaTable, write_deltalake
except ImportError:
    raise ImportError("deltalake required. Install: pip install deltalake")


# ═══════════════════════════════════════════════════════════════
# CONFIG — edit for your environment
# ═══════════════════════════════════════════════════════════════
ALPHA_DIR = Path("/gpfs/.../jyao/alpha")
ALPHA_PATTERN = "alpha_{date}.feather"
ALPHA_SCHEMA = "jyao_v20251114"

TRADE_DIR = Path("/gpfs/.../ylin/trade/sc_0")
TRADE_PATTERN = "{date}.meords"
TRADE_SCHEMA = "sim_standard"

# Optional: use real quote data instead of alpha for forward merge (denser, more accurate)
# Requires: pip install vizflow[fst]
# QUOTE_DIR = Path("/gpfs/.../stock_sorted_t5ob")
# QUOTE_PATTERN = "{date}.fst"
# QUOTE_SCHEMA = "stock_sorted_t5ob"

OUTPUT_DIR = Path("./enriched")
MARKET = "CN"


# ═══════════════════════════════════════════════════════════════
# FORWARD MERGE CONFIG — edit for your analysis
# ═══════════════════════════════════════════════════════════════
HORIZONS = [-10, -5, -1, 0, 1, 5, 10, 30, 60, 120, 180, 300, 600, 1200, 1800, 2400, 3600]
REF_COLS = ["bid_px0", "ask_px0", "bid_size0", "ask_size0"]
ALPHA_PRED_COLS = ["x_10s", "x_60s", "x_3m", "x_30m"]

TRADE_TIME_COL = "update_exchange_ts"
ALPHA_TIME_COL = "ticktime"
# QUOTE_TIME_COL = "ticktime"  # Same HHMMSSMMM format as alpha


# ═══════════════════════════════════════════════════════════════
# TRADE ENRICHMENT (before merge)
# ═══════════════════════════════════════════════════════════════
fill_qty = (
    pl.col("order_filled_qty")
    - pl.col("order_filled_qty").shift(1).over("order_id").fill_null(0)
)
fill_notional = (
    pl.col("order_filled_notional")
    - pl.col("order_filled_notional").shift(1).over("order_id").fill_null(0)
)
time_to_fill = pl.col("update_exchange_ts") - pl.col("create_exchange_ts")

TRADE_ENRICHMENTS = [
    fill_qty.alias("fill_qty"),
    fill_notional.alias("fill_notional"),
    time_to_fill.alias("time_to_fill"),
]


# ═══════════════════════════════════════════════════════════════
# DELTA LAKE HELPERS
# ═══════════════════════════════════════════════════════════════
def _is_date_complete(
    forward_path: str,
    date_iso: str,
    ref_cols: list[str],
    horizons: list[float],
) -> bool:
    """Check if all expected sub-partitions exist for a date (metadata-only).

    Reads only the Delta transaction log — no data file scanning.
    Returns False if table doesn't exist or any expected (ref_col, horizon_ms) is missing.
    """
    try:
        dt = DeltaTable(forward_path)
    except Exception:
        return False
    parts = dt.partitions()
    existing = {
        (p["ref_col"], p["horizon_ms"])
        for p in parts if p["data_date"] == date_iso
    }
    expected = {
        (rc, str(vf.horizon_ms(h))) for rc in ref_cols for h in horizons
    }
    return expected <= existing


def _write_delta(
    df: pl.DataFrame,
    table_path: str,
    partition_by: list[str],
    predicate: str,
) -> None:
    """Write DataFrame to Delta Lake with partition-level overwrite.

    First write creates the table (mode="error").
    Subsequent writes overwrite only the matching partition (mode="overwrite" + predicate).
    """
    if not DeltaTable.is_deltatable(table_path):
        write_deltalake(table_path, df.to_arrow(), partition_by=partition_by, mode="error")
    else:
        write_deltalake(table_path, df.to_arrow(), mode="overwrite", predicate=predicate)


# ═══════════════════════════════════════════════════════════════
# PROCESS ONE DATE
# ═══════════════════════════════════════════════════════════════
def process_date(date: str) -> tuple[pl.DataFrame, pl.DataFrame]:
    """Process one date: enrich + merge forward.

    Returns:
        (df_base, df_forward) tuple
    """
    elapsed_trade = f"elapsed_{TRADE_TIME_COL}"
    elapsed_alpha = f"elapsed_{ALPHA_TIME_COL}"

    # Load (lazy)
    lf_trade = (
        vf.scan_trade(date)
        .filter(pl.col("order_filled_qty") > 0)
        .with_columns(TRADE_ENRICHMENTS)
        .pipe(vf.parse_time, TRADE_TIME_COL)
    )
    lf_alpha = vf.scan_alpha(date).pipe(vf.parse_time, ALPHA_TIME_COL)

    # Alpha predictions -> trade via asof join (stays lazy)
    lf_trade = (
        lf_trade
        .sort(["ukey", elapsed_trade])
        .join_asof(
            lf_alpha.select(["ukey", elapsed_alpha] + ALPHA_PRED_COLS).sort(["ukey", elapsed_alpha]),
            left_on=elapsed_trade,
            right_on=elapsed_alpha,
            by="ukey",
            strategy="backward",
        )
    )

    # Forward merge (collects here)
    # Default: use alpha as ref source (downsampled quote)
    # Alternative: use real quote data (denser, more accurate)
    #   elapsed_quote = f"elapsed_{QUOTE_TIME_COL}"
    #   lf_ref = vf.scan_quote(date, columns=["ukey", QUOTE_TIME_COL] + REF_COLS)
    #            .pipe(vf.parse_time, QUOTE_TIME_COL)
    #   Then pass lf_ref and elapsed_quote below instead of lf_alpha and elapsed_alpha
    df = vf.merge_forward(
        lf_trade, lf_alpha,
        ref_cols=REF_COLS,
        horizons=HORIZONS,
        trade_time_col=elapsed_trade,
        ref_time_col=elapsed_alpha,
    )

    # Base table: trade-level columns (no forward columns)
    forward_col_names = [
        f"{col}_{vf.horizon_suffix(h)}" for col in REF_COLS for h in HORIZONS
    ]
    base_cols = [c for c in df.columns if c not in forward_col_names]
    df_base = df.select(base_cols)

    # Forward table: melted long format
    # Cast size columns for uniform forward_value type in melt
    size_cast = [
        pl.col(f"{col}_{vf.horizon_suffix(h)}").cast(pl.Float64)
        for col in ["bid_size0", "ask_size0"]
        for h in HORIZONS
        if f"{col}_{vf.horizon_suffix(h)}" in df.columns
    ]
    if size_cast:
        df = df.with_columns(size_cast)
    df_forward = vf.melt_forward(df, ref_cols=REF_COLS, horizons=HORIZONS, id_cols=["seq", "data_date"])

    return df_base, df_forward


# ═══════════════════════════════════════════════════════════════
# CLI + MAIN
# ═══════════════════════════════════════════════════════════════
def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--date", required=True, help="Date in YYYYMMDD format")
    parser.add_argument("--force", action="store_true",
                        help="Force reprocess even if date is complete")
    args = parser.parse_args()

    vf.set_config(vf.Config(
        alpha_dir=ALPHA_DIR,
        alpha_pattern=ALPHA_PATTERN,
        alpha_schema=ALPHA_SCHEMA,
        trade_dir=TRADE_DIR,
        trade_pattern=TRADE_PATTERN,
        trade_schema=TRADE_SCHEMA,
        # quote_dir=QUOTE_DIR,       # Uncomment to use quote for forward merge
        # quote_pattern=QUOTE_PATTERN,
        # quote_schema=QUOTE_SCHEMA,
        market=MARKET,
    ))

    # YYYYMMDD -> YYYY-MM-DD (Delta Lake partition format for pl.Date)
    date_iso = f"{args.date[:4]}-{args.date[4:6]}-{args.date[6:8]}"
    base_path = str(OUTPUT_DIR / "base")
    forward_path = str(OUTPUT_DIR / "forward")

    # Skip if already complete (default behavior; --force overrides)
    if not args.force and _is_date_complete(forward_path, date_iso, REF_COLS, HORIZONS):
        print(f"  skip {args.date} (complete)")
        return

    print(f"Processing {args.date}...")
    df_base, df_forward = process_date(args.date)
    print(f"  {len(df_base)} fills, {len(df_base.columns)} base columns")
    print(f"  {len(df_forward)} forward rows (long format)")

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    predicate = f"data_date = '{date_iso}'"

    _write_delta(df_base, base_path, ["data_date"], predicate)
    if len(df_forward) > 0:
        _write_delta(df_forward, forward_path, ["data_date", "ref_col", "horizon_ms"], predicate)

    print(f"  Saved to {OUTPUT_DIR}")


if __name__ == "__main__":
    main()
