"""High-dimensional data visualization using datashader.

This module provides heatmap visualization for exploring high-dimensional
data compressed to 2D with custom aggregation functions.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Callable

import polars as pl

from .core import _prepare_data

if TYPE_CHECKING:
    import holoviews as hv
    import pandas as pd
    import xarray as xr
    import datashader as dsh

# Type alias for aggregation function
AggFunc = Callable[["pd.DataFrame", "dsh.Canvas", str, str], "xr.DataArray"]


def heatmap(
    df: pl.LazyFrame | pl.DataFrame,
    x: str,
    y: str,
    agg: AggFunc,
    *,
    resolution: int = 10,
    clim: tuple[float, float] | None = None,
    x_range: tuple[float, float] | None = None,
    y_range: tuple[float, float] | None = None,
    width: int = 800,
    height: int = 500,
    cmap: str = "RdBu_r",
    symmetric: bool = False,
    title: str | None = None,
) -> "hv.DynamicMap":
    """Interactive heatmap with custom aggregation.

    Creates a datashader-backed heatmap that re-aggregates on pan/zoom.
    Accepts Polars LazyFrame/DataFrame, converts to pandas for datashader.

    Args:
        df: Polars LazyFrame or DataFrame with data to visualize
        x: Column name for x-axis
        y: Column name for y-axis
        agg: Aggregation function. Use vf.viz.raster.* functions:
            - vf.viz.raster.wmean("value", "weight") - weighted mean
            - vf.viz.raster.mean("value") - simple mean
            - vf.viz.raster.sum("value") - sum
            - vf.viz.raster.count() - point count
            Or define your own: func(sub, cvs, x, y) -> xr.DataArray
        resolution: Pixel size multiplier. Higher = coarser, faster.
            Canvas size = (width // resolution, height // resolution)
        clim: Color limits (min, max). Auto-computed if None.
        x_range: Initial x-axis range. Full data range if None.
        y_range: Initial y-axis range. Full data range if None.
        width: Plot width in pixels
        height: Plot height in pixels
        cmap: Colormap name (matplotlib colormap)
        symmetric: If True, center colormap at zero
        title: Plot title

    Returns:
        HoloViews DynamicMap that updates on pan/zoom

    Example:
        >>> import vizflow as vf
        >>> import holoviews as hv
        >>> hv.extension('bokeh')
        >>>
        >>> lf = pl.scan_parquet("data.parquet")
        >>> viz = vf.viz.heatmap(
        ...     lf,
        ...     x="elapsed_seconds",
        ...     y="alpha_bin",
        ...     agg=vf.viz.raster.wmean("y_60s", "qty"),
        ...     clim=(-0.001, 0.001),
        ... )
        >>> viz  # Display in notebook
    """
    import datashader as dsh
    import holoviews as hv
    from holoviews.streams import RangeXY

    # Convert to pandas for datashader
    pdf = _prepare_data(df)

    # Compute full data range
    x_full = (pdf[x].min(), pdf[x].max())
    y_full = (pdf[y].min(), pdf[y].max())

    # Use provided ranges or full range
    initial_x_range = x_range or x_full
    initial_y_range = y_range or y_full

    def callback(x_range, y_range):
        """Callback for dynamic re-aggregation on pan/zoom."""
        # Use current range or initial range
        x_rng = x_range if x_range else initial_x_range
        y_rng = y_range if y_range else initial_y_range

        # Create canvas with appropriate resolution
        cvs = dsh.Canvas(
            plot_width=width // resolution,
            plot_height=height // resolution,
            x_range=x_rng,
            y_range=y_rng,
        )

        # Apply user-provided aggregation function
        result = agg(pdf, cvs, x, y)

        # Build HoloViews Image
        img = hv.Image(result, kdims=[x, y])

        # Apply options
        opts = {
            "width": width,
            "height": height,
            "cmap": cmap,
            "colorbar": True,
            "tools": ["hover", "box_select"],
        }

        if clim:
            opts["clim"] = clim
        if symmetric:
            opts["symmetric"] = True
        if title:
            opts["title"] = title

        return img.opts(**opts)

    # Create DynamicMap with RangeXY stream for pan/zoom
    stream = RangeXY()
    dmap = hv.DynamicMap(callback, streams=[stream])

    return dmap
