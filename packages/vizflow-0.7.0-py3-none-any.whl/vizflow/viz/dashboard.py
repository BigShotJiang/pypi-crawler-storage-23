"""Interactive exploration dashboard using Panel + Datashader + HoloViews.

This module provides a Panel-based dashboard that composes a weighted-mean
heatmap with a horizon curve for interactive exploration with linked selection.

Architecture
============

Data flow::

    Polars DataFrame
      → to_pandas (once)
      → _precompute_wv(): NaN-safe _wv/_w columns for ALL horizons on full pdf
      → _rebuild_sub(): extract [x, y, weight, _wv_*, _w_*], dropna(x,y)
      → _heatmap_callback():  dsh.summary() → xarray.Dataset → hv.Image
      → HoloViews DynamicMap → Bokeh → browser

Rendering layers (fast → slow, top → bottom)::

    Display layer   – clim / horizon / mode (cache hit, xarray lookup)
    Rasterize layer – resolution / pan / zoom (single dsh.summary() pass)
    Data layer      – Apply button (full recompute: _precompute_wv + _rebuild_sub)

Key design decisions:

1. **Clean sub-DataFrame** (matches reference ``quick_look`` pattern):
   Full ``pdf`` has ~350 columns and NaN in x/y. Datashader receives only
   the needed columns with ``dropna(subset=[x, y])`` — avoids xarray 2D
   boolean indexing errors in HoloViews' ``finite_range``.

2. **NaN → 0 for _wv/_w** (mathematically equivalent to per-horizon dropna):
   ``mask = np.isnan(v) | np.isnan(w); np.where(mask, 0, v*w)``
   Rows with NaN value or weight contribute 0/0 to the heatmap bin,
   which becomes NaN in the ratio — correct behavior without dropping rows.

3. **Pass xarray DataArray directly to hv.Image** (NOT ``.values``):
   ``dsh.summary()`` returns an ``xarray.Dataset``. Each variable is a DataArray
   with coordinate metadata. MUST pass DataArray directly to ``hv.Image`` —
   using ``.values`` (numpy) + ``bounds=`` loses coordinate metadata and
   **inverts Y-axis panning** (numpy row 0 = lowest y ≠ hv.Image row 0 = highest y).

4. **DynamicMap recreation on Apply** (axis range reset):
   ``RangeXY`` stream persists previous pan/zoom ranges. When columns change,
   Bokeh feeds back the old range to the stream, overriding new data extents
   (HoloViews #1434). ``framewise=True`` alone cannot overcome persistent
   stream values. Solution: create a fresh ``RangeXY()`` + ``DynamicMap`` on
   Apply, then set ``heatmap_pane.object = new_dmap`` — Panel recreates the
   entire Bokeh plot with correct axis ranges.

5. **Memoization** (``cache_key``):
   ``key = (x_range, y_range, resolution)`` — no horizon, no mode. One
   ``dsh.summary()`` computes all horizons' ``sum(_wv_*)`` and ``sum(_w_*)``
   in a single pass. Horizon slider and mode toggle extract from cached
   ``xarray.Dataset`` via pure xarray division — microsecond latency.
"""

from __future__ import annotations

import numpy as np
import polars as pl


class _ServerHandle:
    """Handle for a Panel server running in a background thread."""

    def __init__(self, server, port: int):
        self._server = server
        self.port = port

    def stop(self):
        """Stop the server."""
        self._server.stop()

    @property
    def is_alive(self):
        return self._server._started


def dashboard(
    df: pl.DataFrame,
    ref_cols: list[str],
    horizons: list[float],
    axis_cols: list[str],
    *,
    port: int = 5006,
    show: bool = True,
    title: str = "VizFlow Explorer",
) -> _ServerHandle:
    """Launch interactive exploration dashboard.

    Layout:
    - Sidebar: column selectors (Apply button), ref_col dropdown, horizon slider
    - Left: heatmap with box select (colors by wmean of selected ref_col at selected horizon)
    - Right: horizon curve for selected region + weight stats

    Args:
        df: Polars DataFrame with wide-format data (output of pivot_horizons).
            Must be collected — use pivot_horizons() which collects internally.
        ref_cols: Column prefixes for value types (e.g., ["markout", "return", "mid"]).
            Combined with horizons to generate column names via horizon_suffix().
        horizons: Available horizons in seconds (e.g., [60, 180, 600, 1800]).
            Used for both the horizon slider and the curve x-axis.
        axis_cols: Columns to show in X/Y/Weight axis selectors.
            Order matters: 1st = default X, 2nd = default Y, 3rd = default Weight.
        port: Port for Panel server (default: 5006)
        show: Open browser automatically (default: True)
        title: Browser tab title

    Returns:
        Server handle. Call handle.stop() to stop the server.

    Example:
        >>> df = vf.pivot_horizons(lf, ref_cols=all_ref_cols, horizons=horizons)
        >>> server = vf.viz.dashboard(
        ...     df,
        ...     ref_cols=["markout", "return"],
        ...     horizons=[0, 60, 180, 600, 1800],
        ...     axis_cols=["elapsed_minutes", "mid_0s", "fill_qty"],
        ...     port=5100,
        ... )
        >>> server.stop()
    """
    import datashader as dsh
    import holoviews as hv
    import panel as pn
    from holoviews.streams import BoundsXY, RangeXY

    from vizflow.ops import horizon_cols as _horizon_cols
    from vizflow.ops import horizon_suffix as _horizon_suffix

    hv.extension("bokeh")
    pn.extension()

    # Convert to pandas once (full DataFrame kept for Apply column switching)
    pdf = df.to_pandas()

    # Axis columns that actually exist
    numeric_cols = [c for c in axis_cols if c in pdf.columns]

    # Defaults from axis_cols order
    default_x = numeric_cols[0] if len(numeric_cols) > 0 else None
    default_y = numeric_cols[1] if len(numeric_cols) > 1 else None
    default_weight = numeric_cols[2] if len(numeric_cols) > 2 else None

    # Build horizon label mapping: {"1m": 60, "3m": 180, ...}
    horizon_options = {_horizon_suffix(h): h for h in horizons}

    # Validate ref_cols have at least some matching columns
    for rc in ref_cols:
        cols = _horizon_cols(rc, horizons)
        found = [c for c in cols if c in pdf.columns]
        if not found:
            raise ValueError(
                f"No columns found for ref_col='{rc}' with given horizons. "
                f"Expected columns like: {cols[:3]}..."
            )

    # ═══════════════════════════════════════════════════════════════
    # Mutable state — closures capture these
    # ═══════════════════════════════════════════════════════════════
    state = {
        "x_col": default_x,
        "y_col": default_y,
        "weight_col": default_weight,
        "ref_col": ref_cols[0],
        "horizon_val": horizons[0],
        "resolution": 10,
        "c_min": -0.001,
        "c_max": 0.001,
        "bounds": None,
        "sub": None,          # clean sub-DataFrame for datashader
        "heatmap_mode": "wmean",  # "wmean" or "sum(weight)"
        # Single cache — dsh.summary() for ALL horizons in one pass
        "cache_key": None,   # (x_rng, y_rng, res) — no horizon, no mode
        "agg": None,         # xarray.Dataset from dsh.summary()
    }

    def _precompute_wv():
        """Pre-compute _wv_{suffix} and _w_{suffix} for ALL horizons."""
        weight_col = state["weight_col"]
        ref_col = state["ref_col"]
        if not weight_col or weight_col not in pdf.columns:
            return
        w = pdf[weight_col].values
        for h in horizons:
            suffix = _horizon_suffix(h)
            value_col = f"{ref_col}_{suffix}"
            if value_col not in pdf.columns:
                continue
            v = pdf[value_col].values
            mask = np.isnan(v) | np.isnan(w)
            pdf[f"_wv_{suffix}"] = np.where(mask, 0.0, v * w)
            pdf[f"_w_{suffix}"] = np.where(mask, 0.0, w)

    def _rebuild_sub():
        """Build clean sub-DataFrame: only needed columns, no NaN in x/y."""
        x_col, y_col = state["x_col"], state["y_col"]
        w_col = state["weight_col"]
        wv_cols = [f"_wv_{_horizon_suffix(h)}" for h in horizons]
        w_cols = [f"_w_{_horizon_suffix(h)}" for h in horizons]
        cols = [x_col, y_col]
        if w_col and w_col not in (x_col, y_col):
            cols.append(w_col)
        cols.extend(wv_cols + w_cols)
        existing = [c for c in cols if c in pdf.columns]
        state["sub"] = pdf[existing].dropna(subset=[x_col, y_col]).reset_index(drop=True)
        state["cache_key"] = None  # invalidate cache

    # Initial pre-computation
    _precompute_wv()
    _rebuild_sub()

    # ═══════════════════════════════════════════════════════════════
    # Heatmap — DynamicMap (recreated on Apply to reset axis ranges)
    # ═══════════════════════════════════════════════════════════════
    state["range_stream"] = RangeXY()

    def _heatmap_callback(x_range, y_range, heatmap_mode="wmean",
                          horizon_val=None, resolution=10,
                          c_min=-0.001, c_max=0.001):
        """Render heatmap via dsh.summary() — single pass for all horizons.

        Cache key = (x_range, y_range, resolution). On cache miss (pan/zoom/res),
        one datashader pass computes all horizons' wv + w. On cache hit (horizon
        slider or mode toggle), pure xarray lookup from cached Dataset.
        Returns xarray DataArray to hv.Image (preserves coordinate metadata).
        """
        sub = state["sub"]
        x_col = state["x_col"]
        y_col = state["y_col"]
        mode = heatmap_mode or "wmean"
        if horizon_val is None:
            horizon_val = horizons[0]
        res = resolution or 10
        c_min_val = c_min if c_min is not None else -0.001
        c_max_val = c_max if c_max is not None else 0.001
        # Sync back to state for _build_curve / _build_stats
        state["heatmap_mode"] = mode
        state["horizon_val"] = horizon_val
        state["resolution"] = res
        state["c_min"] = c_min_val
        state["c_max"] = c_max_val

        if not x_col or not y_col or sub is None:
            return hv.Image(np.array([[np.nan]]), bounds=(0, 0, 1, 1))

        xs = sub[x_col].values
        ys = sub[y_col].values
        x_rng = x_range if x_range else (float(np.nanmin(xs)), float(np.nanmax(xs)))
        y_rng = y_range if y_range else (float(np.nanmin(ys)), float(np.nanmax(ys)))

        cvs = None  # lazily created

        def _get_canvas():
            nonlocal cvs
            if cvs is None:
                cvs = dsh.Canvas(
                    plot_width=max(1, 600 // res),
                    plot_height=max(1, 400 // res),
                    x_range=x_rng,
                    y_range=y_rng,
                )
            return cvs

        # --- Single-pass aggregation for ALL horizons (cache by range+resolution) ---
        cache_key = (x_rng, y_rng, res)
        if cache_key != state["cache_key"]:
            suffixes = [_horizon_suffix(h) for h in horizons]
            agg_spec = {}
            for s in suffixes:
                wv_c, w_c = f"_wv_{s}", f"_w_{s}"
                if wv_c in sub.columns and w_c in sub.columns:
                    agg_spec[f"wv_{s}"] = dsh.sum(wv_c)
                    agg_spec[f"w_{s}"] = dsh.sum(w_c)
            if agg_spec:
                agg = _get_canvas().points(
                    sub, x_col, y_col, agg=dsh.summary(**agg_spec),
                )
                state["cache_key"] = cache_key
                state["agg"] = agg

        # --- Return the active mode's image from cached Dataset ---
        suffix = _horizon_suffix(horizon_val)
        agg = state["agg"]
        shared_opts = dict(
            frame_width=550, frame_height=370, colorbar=True,
            tools=["hover", "box_select"],
        )

        if agg is None or f"wv_{suffix}" not in agg:
            return hv.Image(np.array([[np.nan]]), bounds=(0, 0, 1, 1))

        if mode == "wmean":
            da = agg[f"wv_{suffix}"] / agg[f"w_{suffix}"]  # xarray DataArray
            return hv.Image(da, kdims=[x_col, y_col]).opts(
                **shared_opts,
                cmap="RdBu_r",
                clim=(c_min_val, c_max_val),
                title=f"wmean({state['ref_col']}_{suffix})",
            )
        else:
            da = agg[f"w_{suffix}"]  # xarray DataArray
            finite = da.values[np.isfinite(da.values)]
            if len(finite) > 0:
                data_clim = (float(finite.min()), float(finite.max()))
            else:
                data_clim = (0, 1)
            return hv.Image(da, kdims=[x_col, y_col]).opts(
                **shared_opts,
                cmap="viridis",
                clim=data_clim,
                title="sum(weight)",
            )

    # ═══════════════════════════════════════════════════════════════
    # Widgets (defined before DynamicMap so Params streams can reference them)
    # ═══════════════════════════════════════════════════════════════
    x_w = pn.widgets.Select(name="X-axis", options=numeric_cols, value=default_x, width=240)
    y_w = pn.widgets.Select(name="Y-axis", options=numeric_cols, value=default_y, width=240)
    w_w = pn.widgets.Select(name="Weight", options=numeric_cols, value=default_weight, width=240)
    rc_w = pn.widgets.Select(name="Value", options=ref_cols, value=ref_cols[0], width=240)
    apply_btn = pn.widgets.Button(name="Apply", button_type="primary", width=240)
    mode_w = pn.widgets.RadioButtonGroup(
        name="Heatmap", options=["wmean", "sum(weight)"], value="wmean", width=240,
    )
    hz_w = pn.widgets.DiscreteSlider(
        name="Horizon", options=horizon_options, value=horizons[0], width=240,
    )
    res_w = pn.widgets.IntSlider(
        name="Resolution", start=1, end=20, value=10, width=240,
    )
    cmin_w = pn.widgets.FloatInput(name="Color min", value=-0.001, width=110)
    cmax_w = pn.widgets.FloatInput(name="Color max", value=0.001, width=110)

    # Params streams — widget changes become DynamicMap input changes
    _widget_streams = [
        hv.streams.Params(mode_w, ["value"], rename={"value": "heatmap_mode"}),
        hv.streams.Params(hz_w, ["value"], rename={"value": "horizon_val"}),
        hv.streams.Params(res_w, ["value"], rename={"value": "resolution"}),
        hv.streams.Params(cmin_w, ["value"], rename={"value": "c_min"}),
        hv.streams.Params(cmax_w, ["value"], rename={"value": "c_max"}),
    ]

    def _make_dmap():
        """Create DynamicMap with current range_stream + all widget streams."""
        return hv.DynamicMap(
            _heatmap_callback,
            streams=[state["range_stream"]] + _widget_streams,
        ).opts(framewise=True)

    heatmap_dmap = _make_dmap()

    # Box select stream — subscriber is reused when DynamicMap is recreated on Apply
    def _on_bounds(bounds):
        state["bounds"] = bounds
        curve_container.objects = [_build_curve()]
        stats_container.objects = [_build_stats()]

    BoundsXY(source=heatmap_dmap).add_subscriber(_on_bounds)

    # ═══════════════════════════════════════════════════════════════
    # Horizon curve
    # ═══════════════════════════════════════════════════════════════
    def _build_curve():
        """Build horizon curve for current selection."""
        sub = state["sub"]
        x_col = state["x_col"]
        y_col = state["y_col"]
        ref_col = state["ref_col"]
        bounds = state["bounds"]

        if not x_col or not y_col or not ref_col or sub is None:
            return pn.pane.Markdown("**Select columns first**")

        if bounds is None:
            selected = sub
        else:
            x0, y0, x1, y1 = bounds
            mask = (
                (sub[x_col] >= x0) & (sub[x_col] <= x1)
                & (sub[y_col] >= y0) & (sub[y_col] <= y1)
            )
            selected = sub[mask]

        if len(selected) == 0:
            return pn.pane.Markdown("**No data in selection**")

        pts = []
        for h in horizons:
            suffix = _horizon_suffix(h)
            wv_col = f"_wv_{suffix}"
            w_col = f"_w_{suffix}"
            if wv_col not in selected.columns or w_col not in selected.columns:
                continue
            total_w = selected[w_col].sum()
            if total_w == 0:
                pts.append((h, np.nan))
            else:
                pts.append((h, selected[wv_col].sum() / total_w))

        if not pts:
            return pn.pane.Markdown(f"**No columns for '{ref_col}'**")

        n_rows = len(selected)
        curve = hv.Curve(pts, kdims=["Horizon (s)"], vdims=["Value"])
        return pn.pane.HoloViews(
            curve.opts(
                width=400, height=300, tools=["hover"],
                title=f"{ref_col} curve ({n_rows:,} rows)",
            )
        )

    # ═══════════════════════════════════════════════════════════════
    # Selection stats
    # ═══════════════════════════════════════════════════════════════
    def _build_stats():
        """Build stats for current selection."""
        sub = state["sub"]
        x_col = state["x_col"]
        y_col = state["y_col"]
        weight_col = state["weight_col"]
        bounds = state["bounds"]

        if not weight_col or sub is None or weight_col not in sub.columns:
            return pn.pane.Markdown("")

        total_weight = sub[weight_col].sum()

        if bounds is None:
            selected = sub
            label = "All data"
        else:
            x0, y0, x1, y1 = bounds
            mask = (
                (sub[x_col] >= x0) & (sub[x_col] <= x1)
                & (sub[y_col] >= y0) & (sub[y_col] <= y1)
            )
            selected = sub[mask]
            label = "Selection"

        n_rows = len(selected)
        sel_weight = selected[weight_col].sum()
        pct = (sel_weight / total_weight * 100) if total_weight and total_weight > 0 else 0

        def _fmt(v):
            if abs(v) >= 1e9:
                return f"{v / 1e9:.2f}B"
            if abs(v) >= 1e6:
                return f"{v / 1e6:.2f}M"
            if abs(v) >= 1e3:
                return f"{v / 1e3:.1f}K"
            return f"{v:.0f}"

        text = f"""### {label}
- **Rows**: {n_rows:,}
- **Weight ({weight_col})**: {_fmt(sel_weight)}
- **% of total**: {pct:.1f}%
"""
        return pn.pane.Markdown(text, width=380)

    # ═══════════════════════════════════════════════════════════════
    # Event handlers (only Apply — all others handled by Params streams)
    # ═══════════════════════════════════════════════════════════════
    def _on_apply(event):
        """Apply button: update state, recompute, recreate DynamicMap with fresh stream."""
        state["x_col"] = x_w.value
        state["y_col"] = y_w.value
        state["weight_col"] = w_w.value
        state["ref_col"] = rc_w.value
        state["bounds"] = None
        _precompute_wv()
        _rebuild_sub()
        # Recreate DynamicMap with fresh RangeXY — no stale ranges.
        state["range_stream"] = RangeXY()
        new_dmap = _make_dmap()
        BoundsXY(source=new_dmap).add_subscriber(_on_bounds)
        heatmap_pane.object = new_dmap
        curve_container.objects = [_build_curve()]
        stats_container.objects = [_build_stats()]

    apply_btn.on_click(_on_apply)

    # ═══════════════════════════════════════════════════════════════
    # Layout
    # ═══════════════════════════════════════════════════════════════
    # Initialize right panels as Column containers (swappable content)
    curve_container = pn.Column(_build_curve())
    stats_container = pn.Column(_build_stats())

    stop_btn = pn.widgets.Button(name="Stop Server", button_type="danger", width=240)
    _server_ref = {}

    def _on_stop(event):
        if "handle" in _server_ref:
            _server_ref["handle"].stop()

    stop_btn.on_click(_on_stop)

    sidebar = pn.Column(
        "## Controls",
        x_w, y_w, w_w, rc_w,
        apply_btn,
        pn.Spacer(height=10),
        mode_w,
        pn.Spacer(height=10),
        hz_w,
        pn.Spacer(height=10),
        res_w,
        pn.Spacer(height=5),
        pn.Row(cmin_w, cmax_w),
        pn.Spacer(height=20),
        stop_btn,
        width=280,
        margin=(5, 15, 5, 5),
    )

    right = pn.Column(curve_container, stats_container)
    heatmap_pane = pn.pane.HoloViews(heatmap_dmap, linked_axes=False)
    main_area = pn.Row(heatmap_pane, right)
    layout = pn.Row(sidebar, main_area)

    # ═══════════════════════════════════════════════════════════════
    # Serve in-process
    # ═══════════════════════════════════════════════════════════════
    print(f"Starting dashboard at http://localhost:{port}/app")
    server = pn.serve(
        {"app": layout},
        port=port,
        show=show,
        start=True,
        threaded=True,
        title=title,
    )

    handle = _ServerHandle(server, port)
    _server_ref["handle"] = handle
    return handle
