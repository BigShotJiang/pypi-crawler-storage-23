class xuan类:
    def helloworld(self, name: str = "xuan"):
        return f"hello {name}!"


xuan = xuan类()
