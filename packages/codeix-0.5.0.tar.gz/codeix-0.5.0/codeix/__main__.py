"""Allow running as `python -m codeix`."""

from codeix import main

main()
