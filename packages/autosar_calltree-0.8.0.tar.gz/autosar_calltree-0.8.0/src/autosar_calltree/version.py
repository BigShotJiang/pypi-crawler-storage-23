"""Version information for autosar-calltree package."""

__version__ = "0.8.0"
__author__ = "melodypapa"
__email__ = "melodypapa@outlook.com"
