"""
Pipeline allows you to sequentially apply preprocessors and sampler to your data.
"""


from .pipeline import Pipeline

