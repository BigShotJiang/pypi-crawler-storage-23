"""
jbqlab - A local-first quantitative backtesting and strategy analytics toolkit.

This package provides both a Python SDK and CLI for backtesting trading strategies
on historical price data.

Example usage (SDK):
    >>> import pandas as pd
    >>> from jbqlab import run_backtest
    >>> result = run_backtest("data.csv", strategy="sma_crossover", fast=10, slow=30)
    >>> print(result.metrics)

Example usage (CLI):
    $ jbqlab backtest data.csv --strategy sma_crossover --fast 10 --slow 30

"""

__version__ = "1.0.2"

from jbqlab.benchmark import benchmark_summary, run_benchmark, save_benchmark
from jbqlab.data import load_csv, validate_dataframe
from jbqlab.engine import run_backtest
from jbqlab.metrics import compute_metrics
from jbqlab.montecarlo import (
    MonteCarloResult,
    bootstrap_returns,
    monte_carlo_simulation,
    simulate_paths,
)
from jbqlab.optimize import GridSearchResult, grid_search
from jbqlab.portfolio import (
    PortfolioStats,
    calculate_portfolio_stats,
    kelly_criterion,
    position_sizing,
    risk_parity_weights,
)
from jbqlab.report import generate_comparison_report, generate_report
from jbqlab.strategies import get_available_strategies, get_strategy
from jbqlab.types import BacktestConfig, BacktestResult, StrategyInfo
from jbqlab.validation import (
    ValidationResult,
    check_data_quality,
    detect_outliers,
    fill_missing_dates,
    validate_ohlcv,
)

__all__ = [
    # Version
    "__version__",
    # Main API
    "run_backtest",
    # Benchmarking
    "run_benchmark",
    "benchmark_summary",
    "save_benchmark",
    # Optimization
    "grid_search",
    "GridSearchResult",
    # Reporting
    "generate_report",
    "generate_comparison_report",
    # Data
    "load_csv",
    "validate_dataframe",
    # Validation
    "ValidationResult",
    "validate_ohlcv",
    "check_data_quality",
    "fill_missing_dates",
    "detect_outliers",
    # Portfolio
    "calculate_portfolio_stats",
    "PortfolioStats",
    "position_sizing",
    "kelly_criterion",
    "risk_parity_weights",
    # Monte Carlo
    "monte_carlo_simulation",
    "MonteCarloResult",
    "bootstrap_returns",
    "simulate_paths",
    # Strategies
    "get_strategy",
    "get_available_strategies",
    # Metrics
    "compute_metrics",
    # Types
    "BacktestConfig",
    "BacktestResult",
    "StrategyInfo",
]

