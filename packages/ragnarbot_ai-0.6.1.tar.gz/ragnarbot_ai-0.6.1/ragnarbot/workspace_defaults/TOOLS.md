# Tool Preferences & Custom Notes

This file is maintained by the agent based on conversations with the user.
It stores user preferences, custom scripts, workflows, and tool-related
notes learned over time.

DO NOT clear or overwrite this header. Only append new sections below the separator.
Document here when the user:
- Expresses a preference about how a tool should be used
- Sets up a custom workflow or script
- Wants specific tool behavior remembered across sessions

---

