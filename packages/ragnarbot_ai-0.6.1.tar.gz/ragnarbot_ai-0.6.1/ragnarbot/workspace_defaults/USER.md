# User Profile

_Everything you know about your user. Names, preferences, friends, pets, projects, routines, habits, inside jokes, opinions, goals — anything that helps you be a better agent for this specific person._

_Update proactively whenever you learn something new. Keep it organized. Remove what's outdated._
