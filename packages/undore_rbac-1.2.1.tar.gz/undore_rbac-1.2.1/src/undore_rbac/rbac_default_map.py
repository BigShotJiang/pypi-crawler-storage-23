DEFAULT_RBAC_MAP = {
    "undore_rbac.wildcard": {
        "_config": {
            "explicit": True,
            "default": False
        }
    }
}