# 🎯 DataTunner - Novas Funcionalidades Implementadas

## Resumo das Implementações

Este documento descreve as novas funcionalidades implementadas no DataTunner, incluindo **CTGAN**, **Stable Diffusion** e **Modelos Clássicos de ML**.

---

## 🔬 CTGAN - Geração de Dados Tabulares

### Arquivo: [`generators/ctgan.py`](file:///c:/Users/leandro.rocha/PycharmProjects/DTunner/datatunner/generators/ctgan.py)

### O que foi implementado:

#### 1. **CTGANGenerator** (Principal)
- ✅ Baseado na biblioteca SDV (Synthetic Data Vault)
- ✅ Suporte a variáveis mistas (contínuas e categóricas)
- ✅ Geração condicional (gerar amostras específicas de uma classe)
- ✅ Balanceamento automático de classes
- ✅ Salvamento e carregamento de modelos treinados
- ✅ Metadados automáticos para colunas

**Principais recursos:**
```python
from datatunner.generators.ctgan import CTGANGenerator

# Criar e treinar
ctgan = CTGANGenerator(epochs=300, batch_size=500)
ctgan.fit(data, labels, categorical_columns=['col1', 'col2'])

# Gerar dados balanceados
X_syn, y_syn = ctgan.generate_balanced(n_samples_per_class=5000)

# Gerar condicionalmente
X_syn_class0 = ctgan.generate(n_samples=1000, conditions={'target': 0})

# Salvar modelo
ctgan.save_model('models/ctgan.pkl')
```

#### 2. **TVAEGenerator** (Alternativa)
- ✅ Tabular Variational AutoEncoder
- ✅ Mais rápido que CTGAN
- ✅ Melhor para datasets menores
- ✅ Mesma interface que CTGAN

**Vantagens do CTGAN/TVAE:**
- Lida com dados mistos (categóricos + numéricos)
- Preserva correlações entre features
- Gera dados de alta qualidade
- Suporta geração condicional
- Ideal para balanceamento de classes

---

## 🎨 Stable Diffusion - Geração de Imagens

### Arquivo: [`generators/diffusion.py`](file:///c:/Users/leandro.rocha/PycharmProjects/DTunner/datatunner/generators/diffusion.py)

### O que foi implementado:

#### 1. **StableDiffusionGenerator** (Principal)
- ✅ Text-to-Image generation
- ✅ Image-to-Image generation (variações)
- ✅ Geração balanceada por classes
- ✅ Negative prompts (melhor qualidade)
- ✅ Otimizações de VRAM (attention slicing, VAE tiling)
- ✅ Suporte a GPU e CPU

**Principais recursos:**
```python
from datatunner.generators.diffusion import StableDiffusionGenerator

# Inicializar (baixa modelo automaticamente)
sd_gen = StableDiffusionGenerator(
    model_id="stabilityai/stable-diffusion-2-1",
    device="cuda"
)

# Gerar imagens por classe
class_prompts = {
    0: "a photo of a cat, high quality",
    1: "a photo of a dog, high quality"
}

paths, labels = sd_gen.generate_from_class_prompts(
    class_prompts=class_prompts,
    n_samples_per_class=100,
    output_dir='data/synthetic',
    num_inference_steps=25,
    guidance_scale=7.5
)

# Image-to-Image (variações)
new_img = sd_gen.image_to_image(
    init_image='original.jpg',
    prompt='same image with different lighting',
    strength=0.75
)
```

#### 2. **DreamBoothGenerator** (Stub)
- ⚠️ Base implementada para fine-tuning futuro
- Permite personalização em poucas imagens

**Vantagens do Stable Diffusion:**
- Gera imagens fotorrealistas
- Altamente customizável via prompts
- Pode gerar variações infinitas
- Ideal para data augmentation extremo

**Requisitos:**
- GPU NVIDIA com 8GB+ VRAM (recomendado)
- Bibliotecas: `diffusers`, `transformers`, `accelerate`

---

## 🌲 Modelos Clássicos de Machine Learning

### Arquivo: [`models/classical.py`](file:///c:/Users/leandro.rocha/PycharmProjects/DTunner/datatunner/models/classical.py)

### Modelos Implementados:

| Modelo | Classe | Biblioteca | Uso Recomendado |
|--------|--------|------------|-----------------|
| **Decision Tree** | `DecisionTreeClassifier` | scikit-learn | Baseline, interpretabilidade |
| **Random Forest** | `RandomForestClassifier` | scikit-learn | Geral, robusto |
| **XGBoost** | `XGBoostClassifier` | xgboost | Alto desempenho |
| **LightGBM** | `LightGBMClassifier` | lightgbm | Datasets grandes |
| **CatBoost** | `CatBoostClassifier` | catboost | Muitas categóricas |
| **SVM** | `SVMClassifier` | scikit-learn | Margens claras |
| **Logistic Regression** | `LogisticRegressionClassifier` | scikit-learn | Baseline linear |
| **Naive Bayes** | `NaiveBayesClassifier` | scikit-learn | Texto, rápido |
| **K-Nearest Neighbors** | `KNNClassifier` | scikit-learn | Pequenos datasets |

### Características Comuns:

✅ Interface unificada (fit, predict, predict_proba)
✅ Suporte a feature importance (quando aplicável)
✅ Paralelização automática (n_jobs=-1)
✅ Suporte a GPU (XGBoost, LightGBM, CatBoost)

**Exemplo de uso:**
```python
from datatunner.models.classical import XGBoostClassifier, RandomForestClassifier

# XGBoost
xgb = XGBoostClassifier(
    n_estimators=100,
    max_depth=6,
    learning_rate=0.1,
    use_gpu=True
)
xgb.fit(X_train, y_train)
y_pred = xgb.predict(X_test)
importance = xgb.get_feature_importance()

# Random Forest
rf = RandomForestClassifier(
    n_estimators=200,
    max_depth=15,
    n_jobs=-1
)
rf.fit(X_train, y_train)
```

---

## 📦 Dependências Adicionadas

Novas bibliotecas em [`requirements.txt`](file:///c:/Users/leandro.rocha/PycharmProjects/DTunner/requirements.txt):

```text
# CTGAN e dados sintéticos
sdv>=1.2.0

# Stable Diffusion
diffusers>=0.25.0
transformers>=4.35.0
accelerate>=0.25.0

# Modelos clássicos
xgboost>=2.0.0
lightgbm>=4.0.0
catboost>=1.2.0
```

**Instalação:**
```bash
# Tudo
pip install -r requirements.txt

# Apenas CTGAN
pip install sdv>=1.2.0

# Apenas Stable Diffusion
pip install diffusers transformers accelerate

# Apenas modelos clássicos
pip install xgboost lightgbm catboost
```

---

## 📚 Novos Exemplos

### 1. [`example_ctgan.py`](file:///c:/Users/leandro.rocha/PycharmProjects/DTunner/examples/example_ctgan.py)
- Workflow completo de CTGAN
- Integração com modelos clássicos
- Comparação real vs sintético

### 2. [`example_stable_diffusion.py`](file:///c:/Users/leandro.rocha/PycharmProjects/DTunner/examples/example_stable_diffusion.py)
- Geração text-to-image
- Geração image-to-image
- Prompts e parâmetros recomendados
- Requisitos de hardware

---

## 🎯 Casos de Uso

### Caso 1: Dados Tabulares Desbalanceados
```python
# Usar CTGAN para balancear
from datatunner.generators.ctgan import CTGANGenerator
from datatunner.models.classical import XGBoostClassifier

ctgan = CTGANGenerator(epochs=300)
ctgan.fit(X_train, y_train)
X_syn, y_syn = ctgan.generate_balanced(n_samples_per_class=5000)

# Treinar com dados balanceados
model = XGBoostClassifier()
model.fit(np.vstack([X_train, X_syn]), np.hstack([y_train, y_syn]))
```

### Caso 2: Geração de Imagens Customizadas
```python
# Usar Stable Diffusion para criar dataset
from datatunner.generators.diffusion import StableDiffusionGenerator

sd = StableDiffusionGenerator()
class_prompts = {
    0: "medical scan showing normal tissue",
    1: "medical scan showing abnormal tissue"
}

paths, labels = sd.generate_from_class_prompts(
    class_prompts, n_samples_per_class=500, output_dir='medical_data'
)
```

### Caso 3: Comparação de Modelos
```python
# Testar múltiplos modelos facilmente
from datatunner.models.classical import *

models = {
    'XGBoost': XGBoostClassifier(),
    'LightGBM': LightGBMClassifier(),
    'Random Forest': RandomForestClassifier(),
    'Decision Tree': DecisionTreeClassifier()
}

for name, model in models.items():
    model.fit(X_train, y_train)
    score = model.score(X_test, y_test)
    print(f"{name}: {score:.4f}")
```

---

## 🔧 Integração com DataTunner

Todos os novos módulos se integram perfeitamente com o DataTunner existente:

```python
from datatunner import DataTunner
from datatunner.generators.ctgan import CTGANGenerator
from datatunner.models.classical import XGBoostClassifier

# Gerar dados sintéticos
ctgan = CTGANGenerator()
ctgan.fit(X_train, y_train)
X_syn, y_syn = ctgan.generate(n_samples=10000)

# Usar DataTunner para encontrar proporção ideal
tunner = DataTunner(data_type='tabular')
model = XGBoostClassifier()

results = tunner.optimize(
    model=model,
    synthetic_data=(X_syn, y_syn),
    proportions=[0.0, 0.2, 0.5, 0.7, 1.0]
)
```

---

## ✅ Checklist de Implementação

- [x] CTGAN completo com geração condicional
- [x] TVAE como alternativa ao CTGAN
- [x] Stable Diffusion text-to-image
- [x] Stable Diffusion image-to-image
- [x] Geração balanceada por classes (ambos)
- [x] 9 modelos clássicos de ML
- [x] Suporte a feature importance
- [x] Importações condicionais (evita erros)
- [x] Exemplos completos para CTGAN
- [x] Exemplos completos para Stable Diffusion
- [x] Documentação atualizada
- [x] Exports atualizados em __init__

---

## 🚀 Próximos Passos Sugeridos

1. **Testes Unitários** para novos módulos
2. **Notebook Tutorial** mostrando uso prático
3. **Fine-tuning de Stable Diffusion** (DreamBooth completo)
4. **Validação de qualidade** dos dados sintéticos
5. **Benchmark** de performance dos modelos
6. **CLI** para facilitar uso

---

**Desenvolvido com ❤️ para DataTunner**

Instagram: [@leandrocr.adv](https://instagram.com/leandrocr.adv)
