"""
Configurações do módulo config
"""

from datatunner.config.settings import get_config, setup_directories

__all__ = ["get_config", "setup_directories"]
