"""
Exemplo de uso do DataTunner com imagens (CIFAR-10 style)

Este exemplo demonstra como usar o DataTunner para encontrar a proporção
ideal de dados sintéticos para um dataset de imagens.
"""

import torch
import numpy as np
from pathlib import Path

from datatunner import DataTunner
from datatunner.models.cnn import ResNetClassifier
from datatunner.generators.augmentation import ImageAugmentation


def main():
    """Exemplo principal"""
    
    # Configuração
    random_seed = 42
    torch.manual_seed(random_seed)
    np.random.seed(random_seed)
    
    print("="*60)
    print("DataTunner - Exemplo CIFAR-10")
    print("="*60)
    
    # Caminhos dos dados
    # NOTA: Ajuste estes caminhos para seus dados
    real_data_path = "data/cifar10/train"
    test_data_path = "data/cifar10/test"
    
    # Gerar dados sintéticos via augmentation
    print("\n1. Gerando dados sintéticos via Data Augmentation...")
    
    # O DataTunner pode usar o gerador automaticamente ou você pode
    # gerar dados sintéticos previamente
    synthetic_data_path = "data/cifar10/synthetic"
    
    # Configurar DataTunner
    print("\n2. Configurando DataTunner...")
    tunner = DataTunner(
        data_type='image',
        real_data_path=real_data_path,
        synthetic_data_path=synthetic_data_path,  # Se já tiver dados sintéticos
        test_data_path=test_data_path,
        output_dir='results/cifar10',
        random_seed=random_seed
    )
    
    # Definir modelo
    print("\n3. Definindo modelo ResNet18...")
    num_classes = 10  # CIFAR-10 tem 10 classes
    model = ResNetClassifier(
        num_classes=num_classes,
        architecture='resnet18',
        pretrained=True
    )
    
    print(f"Modelo: {model.model_name}")
    print(f"Parâmetros treináveis: {model.count_parameters():,}")
    
    # Definir proporções a testar
    proportions = [0.0, 0.1, 0.2, 0.3, 0.5]
    
    print(f"\n4. Testando proporções: {proportions}")
    
    # Executar otimização
    print("\n5. Iniciando otimização...")
    results = tunner.optimize(
        model=model,
        proportions=proportions,
        epochs=30,
        batch_size=64,
        learning_rate=0.001,
        n_trials=1,  # Aumente para maior robustez
        balance_classes=True
    )
    
    # Visualizar resultados
    print("\n6. Gerando visualizações...")
    tunner.plot_results(metric='accuracy')
    tunner.plot_multiple_metrics(['accuracy', 'precision', 'recall', 'f1_score'])
    tunner.create_interactive_plot()
    
    # Gerar relatório
    print("\n7. Gerando relatório...")
    tunner.generate_report(format='html')
    
    # Resultados finais
    print("\n" + "="*60)
    print("RESULTADOS FINAIS")
    print("="*60)
    print(f"Melhor proporção: {results['best_proportion']:.1%}")
    print(f"Accuracy: {results['best_metrics']['accuracy']:.4f}")
    print(f"F1-Score: {results['best_metrics']['f1_score']:.4f}")
    print("\nResultados salvos em: results/cifar10/")
    print("="*60)


if __name__ == "__main__":
    main()
