"""
Exemplo de uso do Stable Diffusion para geração de imagens sintéticas

Este exemplo demonstra como usar Stable Diffusion para gerar
imagens sintéticas a partir de prompts de texto.
"""

from datatunner.generators.diffusion import StableDiffusionGenerator


def main():
    """Exemplo principal"""
    
    print("="*60)
    print("DataTunner - Exemplo Stable Diffusion")
    print("="*60)
    
    print("""
    IMPORTANTE: Stable Diffusion requer GPU potente e bastante memória!
    
    REQUISITOS:
    -----------
    - GPU NVIDIA com 8GB+ VRAM (recomendado)
    - CUDA instalado
    - Bibliotecas: diffusers, transformers, accelerate
    
    Instalar:
    pip install diffusers transformers accelerate
    
    WORKFLOW COMPLETO:
    ------------------
    
    1. Inicializar Stable Diffusion
    --------------------------------
    ```python
    from datatunner.generators.diffusion import StableDiffusionGenerator
    
    # Criar gerador (baixa modelo automaticamente na primeira vez)
    sd_gen = StableDiffusionGenerator(
        model_id="stabilityai/stable-diffusion-2-1",
        device="cuda",  # ou "cpu" (muito mais lento)
        dtype="float16"  # para economizar VRAM
    )
    
    print(sd_gen.get_generator_info())
    ```
    
    2. Geração Text-to-Image
    -------------------------
    ```python
    # Definir prompts para cada classe
    class_prompts = {
        0: "a photo of a cat, high quality, detailed",
        1: "a photo of a dog, high quality, detailed",
        2: "a photo of a bird flying, high quality, detailed"
    }
    
    # Gerar imagens balanceadas por classe
    image_paths, labels = sd_gen.generate_from_class_prompts(
        class_prompts=class_prompts,
        n_samples_per_class=100,
        output_dir='data/synthetic_images',
        num_inference_steps=25,
        guidance_scale=7.5,
        height=512,
        width=512
    )
    
    print(f"Geradas {len(image_paths)} imagens")
    print(f"Classes: {set(labels)}")
    ```
    
    3. Geração com Prompts Customizados
    ------------------------------------
    ```python
    # Lista de prompts variados
    prompts = [
        "a fluffy orange cat sitting on a windowsill",
        "a golden retriever playing in a park",
        "a parrot with colorful feathers",
        "a siamese cat with blue eyes",
        "a husky dog in the snow"
    ]
    
    # Gerar
    images = sd_gen.generate(
        n_samples=len(prompts),
        prompts=prompts,
        output_dir='data/custom_images',
        num_inference_steps=30,
        guidance_scale=8.0,
        return_images=True
    )
    
    # Salvar individualmente
    for i, img in enumerate(images):
        img.save(f'data/custom_images/custom_{i}.png')
    ```
    
    4. Image-to-Image (Variações)
    ------------------------------
    ```python
    # Gerar variações de uma imagem existente
    output_img = sd_gen.image_to_image(
        init_image='data/original_cat.jpg',
        prompt='a photo of a cat in different lighting, high quality',
        strength=0.75,  # 0.0 = sem mudança, 1.0 = mudança total
        num_inference_steps=50,
        output_path='data/variation_cat.png'
    )
    ```
    
    5. Prompt Negativo (melhor qualidade)
    --------------------------------------
    ```python
    # Usar negative prompt para evitar características indesejadas
    images = sd_gen.generate(
        n_samples=10,
        prompts=["a beautiful landscape"],
        negative_prompt="blurry, low quality, distorted, ugly, pixelated",
        num_inference_steps=30,
        guidance_scale=8.5,
        output_dir='data/landscapes'
    )
    ```
    
    DICAS PARA MELHORES RESULTADOS:
    --------------------------------
    
    1. Prompts Detalhados:
       ✗ "cat"
       ✓ "a photo of a fluffy orange cat with green eyes, sitting on a couch, 
          high quality, detailed, professional photography"
    
    2. Parâmetros Recomendados:
       - num_inference_steps: 25-50 (25 = rápido, 50 = alta qualidade)
       - guidance_scale: 7.0-12.0 (7.5 = balanceado)
       - Use negative_prompt sempre que possível
    
    3. Economizar VRAM:
       - Use dtype="float16"
       - Enable attention slicing (automático)
       - Reduza height/width para 384x384 se necessário
    
    4. Modelos Alternativos:
       - "runwayml/stable-diffusion-v1-5" (mais rápido)
       - "stabilityai/stable-diffusion-2-1" (melhor qualidade)
       - Fine-tuned models no HuggingFace Hub
    
    INTEGRAÇÃO COM DATATUNNER:
    --------------------------
    ```python
    from datatunner import DataTunner
    from datatunner.models.cnn import ResNetClassifier
    
    # Gerar dados sintéticos com Stable Diffusion
    # (primeiro gere as imagens como mostrado acima)
    
    # Então use o DataTunner normalmente
    tunner = DataTunner(
        data_type='image',
        real_data_path='data/real_images',
        synthetic_data_path='data/synthetic_images',  # Geradas com SD
        output_dir='results'
    )
    
    model = ResNetClassifier(num_classes=3)
    
    results = tunner.optimize(
        model=model,
        proportions=[0.0, 0.2, 0.5, 0.8, 1.0],
        epochs=50
    )
    ```
    
    CUSTOS E TEMPO:
    ---------------
    - GPU NVIDIA RTX 3090: ~2-3 segundos por imagem (512x512)
    - GPU NVIDIA RTX 4090: ~1-2 segundos por imagem
    - CPU: ~30-60 segundos por imagem (NÃO RECOMENDADO)
    
    MEMÓRIA NECESSÁRIA:
    - float16: ~6-8GB VRAM
    - float32: ~12-16GB VRAM
    ```
    
    Para mais informações, consulte:
    - https://huggingface.co/docs/diffusers
    - https://github.com/CompVis/stable-diffusion
    """)
    
    print("\n" + "="*60)
    print("STABLE DIFFUSION REQUER GPU POTENTE")
    print("="*60)
    print("Consulte os exemplos acima para uso completo")
    print("="*60)


if __name__ == "__main__":
    main()
