"""
Exemplo de uso do DataTunner com dados tabulares (Adult dataset style)

Este exemplo demonstra como usar o DataTunner para encontrar a proporção
ideal de dados sintéticos para um dataset tabular.
"""

import numpy as np
import pandas as pd
from pathlib import Path

from datatunner import DataTunner
from datatunner.models.mlp import MLPClassifier
from datatunner.generators.smote import SMOTEGenerator


def main():
    """Exemplo principal"""
    
    # Configuração
    random_seed = 42
    np.random.seed(random_seed)
    
    print("="*60)
    print("DataTunner - Exemplo Adult Dataset")
    print("="*60)
    
    # NOTA: Este é um exemplo simplificado
    # Para uso real, ajuste os caminhos e parâmetros
    
    print("\n1. Carregando dados...")
    # Exemplo: carregar dados do Adult dataset
    # real_data_path = "data/adult/train.csv"
    # test_data_path = "data/adult/test.csv"
    
    print("""
    NOTA: Para executar este exemplo, você precisa:
    
    1. Preparar seus dados tabulares em formato CSV
    2. Especificar a coluna target
    3. Pré-processar os dados (encoding, normalização)
    4. Gerar dados sintéticos usando SMOTE ou outro método
    
    Exemplo de código:
    
    ```python
    from datatunner.utils.data_loader import DataLoader
    
    # Carregar dados
    loader = DataLoader()
    X_train, y_train, X_test, y_test = loader.load_tabular_data(
        file_path='data/adult/train.csv',
        target_column='income',
        test_size=0.2
    )
    
    # Pré-processar
    X_train_proc, X_test_proc, preproc_info = loader.preprocess_tabular_data(
        X_train, X_test
    )
    
    # Gerar dados sintéticos com SMOTE
    generator = SMOTEGenerator(k_neighbors=5)
    generator.fit(X_train_proc, y_train)
    X_synthetic, y_synthetic = generator.generate(n_samples=5000)
    
    # Configurar DataTunner
    tunner = DataTunner(
        data_type='tabular',
        output_dir='results/adult',
        random_seed=42
    )
    
    # Definir modelo MLP
    input_dim = X_train_proc.shape[1]
    num_classes = len(np.unique(y_train))
    
    model = MLPClassifier(
        input_dim=input_dim,
        num_classes=num_classes,
        hidden_layers=[128, 64, 32],
        dropout=0.3
    )
    
    # Executar otimização
    results = tunner.optimize(
        model=model,
        synthetic_data=(X_synthetic, y_synthetic),
        proportions=[0.0, 0.1, 0.2, 0.3, 0.5, 0.7, 1.0],
        epochs=100,
        batch_size=128,
        learning_rate=0.001,
        n_trials=3
    )
    
    # Visualizar resultados
    tunner.plot_results()
    tunner.generate_report()
    ```
    """)
    
    print("\n" + "="*60)
    print("IMPLEMENTAÇÃO COMPLETA REQUER DADOS REAIS")
    print("="*60)
    print("Siga o exemplo acima e ajuste para seus dados específicos")
    print("="*60)


if __name__ == "__main__":
    main()
