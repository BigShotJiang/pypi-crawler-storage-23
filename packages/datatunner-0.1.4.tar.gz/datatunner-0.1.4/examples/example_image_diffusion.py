"""
DataTunner - Exemplo de Imagem com Stable Diffusion
=====================================================

Demonstra o uso do DataTunner para dados de imagem usando
Stable Diffusion como gerador de dados sinteticos.

Gerador: StableDiffusionGenerator
Modelo: ResNetClassifier, CustomCNN

Instalacao:
    pip install datatunner diffusers transformers accelerate torch

Uso:
    python example_image_diffusion.py

NOTA: Requer GPU com pelo menos 6GB VRAM para Stable Diffusion.
      Se nao tiver GPU, o exemplo usa fallback com ImageAugmentation.

NOTA 2: O download do modelo Stable Diffusion pode levar varios minutos
        na primeira execucao (~5GB).
"""

import os
import sys
import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import DataLoader
from PIL import Image
from pathlib import Path

# ============================================================
# SETUP
# ============================================================
# Adicionar path se executando localmente (compatível com Colab/Jupyter)
try:
    sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
except NameError:
    sys.path.insert(0, os.getcwd())

from datatunner.generators.augmentation import ImageAugmentation
from datatunner.models.cnn import CustomCNN, ResNetClassifier
from datatunner.core.evaluator import ModelEvaluator
from datatunner.core.mixer import DataMixer
from datatunner.utils.visualization import ResultsVisualizer
from datatunner.utils.data_loader import ImageDataset, DataLoader as DTDataLoader

# Verificar Stable Diffusion
try:
    from datatunner.generators.diffusion import StableDiffusionGenerator
    DIFFUSION_AVAILABLE = torch.cuda.is_available()
    if DIFFUSION_AVAILABLE:
        print("Stable Diffusion + GPU detectados!")
    else:
        print("GPU nao disponivel. Stable Diffusion precisa de GPU.")
        print("Usando fallback com ImageAugmentation.")
except ImportError:
    DIFFUSION_AVAILABLE = False
    print("diffusers nao encontrado. Usando fallback com ImageAugmentation.")
    print("Para usar: pip install diffusers transformers accelerate")

# ============================================================
# CONFIGURACAO
# ============================================================
RANDOM_SEED = 42
EPOCHS = 5
BATCH_SIZE = 16
LEARNING_RATE = 0.001
PROPORTIONS = [0.0, 0.25, 0.5, 0.75, 1.0]
IMAGE_SIZE = (64, 64)
NUM_SAMPLES = 30
OUTPUT_DIR = 'results/image_diffusion'
DATA_DIR = 'data/diffusion_shapes'

os.makedirs(OUTPUT_DIR, exist_ok=True)
np.random.seed(RANDOM_SEED)
torch.manual_seed(RANDOM_SEED)

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt


# ============================================================
# FUNCOES AUXILIARES
# ============================================================
CLASS_NAMES = ['gato', 'cachorro', 'passaro']
CLASS_COLORS = [(255, 150, 50), (50, 150, 255), (50, 255, 150)]


def generate_simple_image(class_idx, size=64, variation=True):
    """Gera imagem simplificada de animal (representacao geometrica)"""
    from PIL import ImageDraw

    img = Image.new('RGB', (size, size), (30, 30, 40))
    draw = ImageDraw.Draw(img)

    offset_x = np.random.randint(-3, 3) if variation else 0
    offset_y = np.random.randint(-3, 3) if variation else 0
    color = CLASS_COLORS[class_idx]

    cx, cy = size // 2 + offset_x, size // 2 + offset_y
    r = size // 4

    if class_idx == 0:  # "gato" - circulo + orelhas triangulares
        draw.ellipse([cx - r, cy - r, cx + r, cy + r], fill=color)
        draw.polygon([(cx - r, cy - r), (cx - r - 5, cy - r - 12), (cx - r + 10, cy - r)], fill=color)
        draw.polygon([(cx + r, cy - r), (cx + r + 5, cy - r - 12), (cx + r - 10, cy - r)], fill=color)
    elif class_idx == 1:  # "cachorro" - quadrado + retangulo (focinho)
        draw.rectangle([cx - r, cy - r, cx + r, cy + r], fill=color)
        draw.rectangle([cx - 5, cy + r, cx + 5, cy + r + 8], fill=color)
    elif class_idx == 2:  # "passaro" - triangulo (corpo) + linha (bico)
        draw.polygon([(cx, cy - r), (cx - r, cy + r), (cx + r, cy + r)], fill=color)
        draw.line([(cx + r, cy), (cx + r + 10, cy - 5)], fill=color, width=2)

    # Adicionar ruido leve
    if variation:
        arr = np.array(img).astype(np.float32)
        arr += np.random.normal(0, 5, arr.shape)
        arr = np.clip(arr, 0, 255).astype(np.uint8)
        img = Image.fromarray(arr)

    return img


def create_dataset(base_dir, n_per_class=30, name="dataset"):
    """Cria dataset de imagens em disco"""
    paths = []
    labels = []

    for class_idx, class_name in enumerate(CLASS_NAMES):
        class_dir = os.path.join(base_dir, class_name)
        os.makedirs(class_dir, exist_ok=True)

        for i in range(n_per_class):
            img = generate_simple_image(class_idx, size=IMAGE_SIZE[0])
            img_path = os.path.join(class_dir, f'{class_name}_{i:04d}.png')
            img.save(img_path)
            paths.append(img_path)
            labels.append(class_idx)

    print(f"   {name}: {len(paths)} imagens ({n_per_class}/classe)")
    return paths, labels


# ============================================================
# 1. PREPARAR DATASET
# ============================================================
print("\n" + "=" * 60)
print("DATATUNNER - Exemplo de Imagem com Stable Diffusion")
print("=" * 60)

print("\n1. Criando dataset de imagens...")
real_dir = os.path.join(DATA_DIR, 'real')
test_dir = os.path.join(DATA_DIR, 'test')

real_paths, real_labels = create_dataset(real_dir, NUM_SAMPLES, "Treino")
test_paths, test_labels = create_dataset(test_dir, NUM_SAMPLES // 2, "Teste")


# ============================================================
# 2. GERAR DADOS SINTETICOS
# ============================================================
print("\n2. Gerando dados sinteticos...")

generators_data = {}

# --- Stable Diffusion (se disponivel) ---
if DIFFUSION_AVAILABLE:
    print("\n   [STABLE DIFFUSION]")
    try:
        sd_gen = StableDiffusionGenerator(
            model_id="stabilityai/stable-diffusion-2-1",
            device="cuda",
            dtype="float16",
            random_seed=RANDOM_SEED
        )

        # Definir prompts por classe
        class_prompts = {
            0: "a simple drawing of a cat, minimal, colorful, digital art",
            1: "a simple drawing of a dog, minimal, colorful, digital art",
            2: "a simple drawing of a bird, minimal, colorful, digital art"
        }

        sd_output_dir = os.path.join(DATA_DIR, 'synthetic_sd')
        sd_paths, sd_labels = sd_gen.generate_from_class_prompts(
            class_prompts=class_prompts,
            n_samples_per_class=NUM_SAMPLES,
            output_dir=sd_output_dir,
            num_inference_steps=20,
            guidance_scale=7.5,
            height=IMAGE_SIZE[0],
            width=IMAGE_SIZE[1]
        )

        generators_data['StableDiffusion'] = (sd_paths, np.array(sd_labels))
        print(f"   Gerado: {len(sd_paths)} imagens")

    except Exception as e:
        print(f"   Stable Diffusion falhou: {e}")
        print("   Usando Augmentation como fallback")
        DIFFUSION_AVAILABLE = False

# --- Data Augmentation (sempre disponivel, usado como fallback e comparacao) ---
print("\n   [DATA AUGMENTATION - Heavy]")
aug_gen = ImageAugmentation(
    random_seed=RANDOM_SEED,
    augmentation_strength='heavy'
)
aug_gen.fit(real_paths, real_labels)

aug_dir = os.path.join(DATA_DIR, 'synthetic_aug')
aug_paths, aug_labels = aug_gen.generate(
    n_samples=NUM_SAMPLES * len(CLASS_NAMES),
    output_dir=aug_dir,
    save_images=True
)
generators_data['Augmentation'] = (aug_paths, np.array(aug_labels))
print(f"   Gerado: {len(aug_paths)} imagens")

# --- Augmentation Light (comparacao) ---
print("\n   [DATA AUGMENTATION - Light]")
aug_light = ImageAugmentation(
    random_seed=RANDOM_SEED,
    augmentation_strength='light'
)
aug_light.fit(real_paths, real_labels)

aug_light_dir = os.path.join(DATA_DIR, 'synthetic_aug_light')
aug_light_paths, aug_light_labels = aug_light.generate(
    n_samples=NUM_SAMPLES * len(CLASS_NAMES),
    output_dir=aug_light_dir,
    save_images=True
)
generators_data['Augmentation_Light'] = (aug_light_paths, np.array(aug_light_labels))
print(f"   Gerado: {len(aug_light_paths)} imagens")

print(f"\n   Geradores: {list(generators_data.keys())}")


# ============================================================
# 3. OTIMIZACAO DE PROPORCAO
# ============================================================
print("\n3. Otimizando proporcoes...")

mixer = DataMixer(random_seed=RANDOM_SEED)
evaluator = ModelEvaluator(device='cpu', task_type='classification')
criterion = nn.CrossEntropyLoss()

transforms = DTDataLoader.get_image_transforms(
    image_size=IMAGE_SIZE, augment=False, normalize=True
)
test_dataset = ImageDataset(test_paths, test_labels, transform=transforms)
test_loader = DataLoader(test_dataset, batch_size=BATCH_SIZE, shuffle=False)

all_results = {}

for gen_name, (synth_paths, synth_labels) in generators_data.items():
    print(f"\n   === {gen_name} ===")
    results = {}

    for prop in PROPORTIONS:
        if prop > 0:
            mixed_paths, mixed_labels = mixer.mix_image_data(
                real_paths, real_labels,
                synth_paths, synth_labels,
                proportion=prop, balance_classes=True
            )
        else:
            mixed_paths = list(real_paths)
            mixed_labels = real_labels.copy()

        train_dataset = ImageDataset(mixed_paths, mixed_labels, transform=transforms)
        train_loader = DataLoader(train_dataset, batch_size=BATCH_SIZE, shuffle=True)

        model = CustomCNN(num_classes=len(CLASS_NAMES), input_channels=3, dropout=0.3)
        optimizer = torch.optim.Adam(model.parameters(), lr=LEARNING_RATE)

        metrics, _ = evaluator.train_and_evaluate(
            model=model,
            train_loader=train_loader,
            val_loader=test_loader,
            test_loader=test_loader,
            optimizer=optimizer,
            criterion=criterion,
            epochs=EPOCHS,
            early_stopping_patience=3,
            class_names=CLASS_NAMES
        )

        results[prop] = metrics
        print(f"   a={prop:.2f}: acc={metrics['accuracy']:.4f}")

    all_results[gen_name] = results
    best = max(results, key=lambda p: results[p]['accuracy'])
    print(f"   >> MELHOR a={best:.2f}, acc={results[best]['accuracy']:.4f}")


# ============================================================
# 4. VISUALIZACOES
# ============================================================
print("\n4. Gerando graficos...")

fig, axes = plt.subplots(1, 2, figsize=(16, 6))

for gen_name, results in all_results.items():
    props = sorted(results.keys())
    accs = [results[p]['accuracy'] for p in props]
    f1s = [results[p]['f1_score'] for p in props]

    marker = 'o' if 'Diffusion' in gen_name else ('s' if 'Light' in gen_name else '^')
    axes[0].plot(props, accs, f'{marker}-', label=gen_name, linewidth=2, markersize=8)
    axes[1].plot(props, f1s, f'{marker}-', label=gen_name, linewidth=2, markersize=8)

axes[0].set_xlabel('Proporcao (a)', fontsize=12)
axes[0].set_ylabel('Accuracy', fontsize=12)
axes[0].set_title('Accuracy: Geradores de Imagem', fontsize=14)
axes[0].legend(fontsize=11)
axes[0].grid(True, alpha=0.3)

axes[1].set_xlabel('Proporcao (a)', fontsize=12)
axes[1].set_ylabel('F1-Score', fontsize=12)
axes[1].set_title('F1-Score: Geradores de Imagem', fontsize=14)
axes[1].legend(fontsize=11)
axes[1].grid(True, alpha=0.3)

plt.tight_layout()
plt.savefig(os.path.join(OUTPUT_DIR, 'comparacao_geradores.png'), dpi=150)
plt.close()
print(f"   Salvo: {OUTPUT_DIR}/comparacao_geradores.png")

# Relatorios
viz = ResultsVisualizer(output_dir=OUTPUT_DIR)
for gen_name, results in all_results.items():
    best = max(results, key=lambda p: results[p]['accuracy'])
    viz.generate_summary_report(
        results=results,
        best_proportion=best,
        experiment_info={
            'data_type': 'image',
            'model_name': 'CustomCNN',
            'epochs': EPOCHS,
            'batch_size': BATCH_SIZE,
            'generator': gen_name,
            'dataset': f'Formas ({IMAGE_SIZE[0]}x{IMAGE_SIZE[1]})'
        },
        save_name=f'relatorio_{gen_name.lower().replace(" ", "_")}.html'
    )


# ============================================================
# 5. RESUMO FINAL
# ============================================================
print("\n" + "=" * 60)
print("RESUMO FINAL")
print("=" * 60)

for gen_name, results in all_results.items():
    best = max(results, key=lambda p: results[p]['accuracy'])
    print(f"\n  {gen_name}:")
    print(f"    Melhor a = {best:.2f}")
    print(f"    Accuracy: {results[best]['accuracy']:.4f}")
    print(f"    F1-Score: {results[best]['f1_score']:.4f}")

if DIFFUSION_AVAILABLE:
    print("\n  Stable Diffusion usado com sucesso!")
else:
    print("\n  Stable Diffusion nao disponivel (sem GPU/diffusers)")
    print("  Para habilitar: pip install diffusers transformers accelerate")
    print("  E use uma maquina com GPU (min 6GB VRAM)")

print(f"\n  Arquivos em: {OUTPUT_DIR}/")
print("\n" + "=" * 60)
print("Exemplo concluido com sucesso!")
print("=" * 60)
