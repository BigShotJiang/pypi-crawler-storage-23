"""
Script de verificação de instalação do DataTunner
"""

import sys

print("="*70)
print("🔍 DATATUNNER - VERIFICAÇÃO DE INSTALAÇÃO")
print("="*70)

print("\n1️⃣  Versão do Python:")
print(f"   {sys.version}")
print(f"   ✅ Python {sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}")

if sys.version_info < (3, 8):
    print("   ⚠️  AVISO: DataTunner requer Python 3.8+")

print("\n2️⃣  Verificando bibliotecas essenciais:")

libraries = {
    'numpy': 'NumPy',
    'pandas': 'Pandas',
    'torch': 'PyTorch',
    'sklearn': 'Scikit-learn',
    'matplotlib': 'Matplotlib',
    'seaborn': 'Seaborn'
}

for module, name in libraries.items():
    try:
        __import__(module)
        print(f"   ✅ {name}")
    except ImportError:
        print(f"   ❌ {name} NÃO INSTALADO")

print("\n3️⃣  Verificando bibliotecas opcionais:")

optional = {
    'albumentations': 'Albumentations (Data Augmentation)',
    'imbalanced_learn': 'Imbalanced-learn (SMOTE)',
    'sdv': 'SDV (CTGAN)',
    'xgboost': 'XGBoost',
    'lightgbm': 'LightGBM',
    'catboost': 'CatBoost',
    'diffusers': 'Diffusers (Stable Diffusion)',
    'transformers': 'Transformers (Stable Diffusion)'
}

for module, name in optional.items():
    try:
        __import__(module)
        print(f"   ✅ {name}")
    except ImportError:
        print(f"   ⚠️  {name} não instalado (opcional)")

print("\n4️⃣  Verificando GPU:")

try:
    import torch
    if torch.cuda.is_available():
        print(f"   ✅ CUDA disponível")
        print(f"   GPU: {torch.cuda.get_device_name(0)}")
        print(f"   VRAM: {torch.cuda.get_device_properties(0).total_memory / 1e9:.1f} GB")
    else:
        print("   ⚠️  CUDA não disponível (usará CPU)")
except:
    print("   ❌ Não foi possível verificar GPU")

print("\n5️⃣  Verificando DataTunner:")

try:
    import datatunner
    print(f"   ✅ DataTunner v{datatunner.__version__}")
    
    # Testar imports principais
    from datatunner import DataTunner
    from datatunner.models.mlp import MLPClassifier
    from datatunner.generators.smote import SMOTEGenerator
    from datatunner.utils.metrics import MetricsCalculator
    
    print("   ✅ Todos os módulos principais importados")
    
except ImportError as e:
    print(f"   ❌ DataTunner não instalado corretamente")
    print(f"      Erro: {e}")
    print("\n   Solução:")
    print("   1. Certifique-se de estar no diretório do projeto")
    print("   2. Ative o ambiente virtual: venv\\Scripts\\activate")
    print("   3. Execute: pip install -e .")

print("\n6️⃣  Resumo:")

try:
    import datatunner
    import torch
    import numpy
    import pandas
    import sklearn
    
    print(f"""
   ✅ DataTunner: INSTALADO
   ✅ Bibliotecas essenciais: OK
   {'✅' if torch.cuda.is_available() else '⚠️ '} GPU: {'Disponível' if torch.cuda.is_available() else 'Não disponível (usará CPU)'}
   
   STATUS: PRONTO PARA USO!
   
   Próximos passos:
   1. Execute o teste rápido: python examples/quick_test.py
   2. Veja exemplos em: examples/
   3. Leia TESTING.md para guia completo
    """)
    
except ImportError:
    print("""
   ❌ INSTALAÇÃO INCOMPLETA
   
   Execute os seguintes comandos:
   1. cd c:\\Users\\leandro.rocha\\PycharmProjects\\DTunner
   2. venv\\Scripts\\activate
   3. pip install -e .
   4. python examples/verify_installation.py
    """)

print("="*70)
