"""
============================================================================
🎯 Titanic - Exemplo Usando DataTunner (Dados Tabulares)
============================================================================

Este exemplo demonstra como usar o DataTunner para otimizar proporções
de dados sintéticos em datasets tabulares usando SMOTE.

INSTALAÇÃO:
    pip install datatunner

USO NO GOOGLE COLAB:
    !pip install datatunner scikit-learn imbalanced-learn pandas seaborn
    
============================================================================
"""

# ============================================================================
# 1. INSTALAÇÃO (Descomente no Google Colab)
# ============================================================================
# !pip install -q datatunner scikit-learn imbalanced-learn pandas seaborn

print("📦 Importando bibliotecas...")

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder, StandardScaler

# IMPORTAR DATATUNNER
from datatunner import DataTunner
from datatunner.generators import SMOTEGenerator
from datatunner.models import MLPClassifier, RandomForestClassifier

print("✅ Bibliotecas importadas!\n")

# ============================================================================
# 2. CARREGAR E PREPARAR DADOS
# ============================================================================
print("=" * 70)
print("🎯 TITANIC COM DATATUNNER")
print("=" * 70)

print("\n📂 Carregando dataset Titanic...")

# Carregar dados (do seaborn)
df = sns.load_dataset('titanic')

print(f"✅ Dados carregados: {df.shape}")
print(f"\nPrimeiras linhas:")
print(df.head())

# Pré-processamento
print("\n🔧 Pré-processando dados...")

# Selecionar features
features = ['pclass', 'sex', 'age', 'sibsp', 'parch', 'fare', 'embarked']
target = 'survived'

# Remover linhas com valores faltantes
df_clean = df[features + [target]].dropna()

# Codificar variáveis categóricas
le = LabelEncoder()
df_clean['sex'] = le.fit_transform(df_clean['sex'])
df_clean['embarked'] = le.fit_transform(df_clean['embarked'])

# Separar features e target
X = df_clean[features].values
y = df_clean[target].values

# Normalizar features
scaler = StandardScaler()
X = scaler.fit_transform(X)

# Split train/test
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)

print(f"✅ Dados preparados!")
print(f"   Treino: {X_train.shape}")
print(f"   Teste: {X_test.shape}")
print(f"   Classes: {np.unique(y_train, return_counts=True)}")

# ============================================================================
# 3. CONFIGURAR GERADOR SMOTE
# ============================================================================
print("\n🔄 Configurando SMOTE...")

generator = SMOTEGenerator(
    k_neighbors=5,
    sampling_strategy='auto',  # Balancear classes minoritárias
    random_state=42
)

print("✅ SMOTE configurado!")

# ============================================================================
# 4. CONFIGURAR MODELOS
# ============================================================================
print("\n🧠 Configurando modelos...")

# Modelo 1: MLP
mlp_model = MLPClassifier(
    hidden_layer_sizes=(64, 32),
    activation='relu',
    max_iter=200,
    random_state=42,
    early_stopping=True
)

# Modelo 2: Random Forest
rf_model = RandomForestClassifier(
    n_estimators=100,
    max_depth=10,
    random_state=42
)

print("✅ Modelos configurados!")
print("   - MLP (2 camadas: 64→32)")
print("   - Random Forest (100 árvores)")

# ============================================================================
# 5. OTIMIZAR COM MLP
# ============================================================================
print("\n🚀 Testando com MLP...")
print("   (Aguarde ~2-3 minutos...)\n")

tunner_mlp = DataTunner(
    data_type='tabular',
    output_dir='results/titanic_mlp',
    random_seed=42
)

results_mlp = tunner_mlp.optimize(
    X_train=X_train,
    y_train=y_train,
    X_test=X_test,
    y_test=y_test,
    generator=generator,
    model=mlp_model,
    proportions=[0.0, 0.25, 0.5, 0.75, 1.0],
    epochs=50,
    batch_size=32,
    metrics=['accuracy', 'f1_score', 'precision', 'recall'],
    n_trials=1,
    verbose=True
)

print(f"\n✅ MLP - Melhor α: {results_mlp['best_proportion']:.2f}")
print(f"   Acurácia: {results_mlp['best_metrics']['accuracy']:.4f}")

# ============================================================================
# 6. OTIMIZAR COM RANDOM FOREST
# ============================================================================
print("\n🚀 Testando com Random Forest...")
print("   (Aguarde ~2-3 minutos...)\n")

tunner_rf = DataTunner(
    data_type='tabular',
    output_dir='results/titanic_rf',
    random_seed=42
)

results_rf = tunner_rf.optimize(
    X_train=X_train,
    y_train=y_train,
    X_test=X_test,
    y_test=y_test,
    generator=generator,
    model=rf_model,
    proportions=[0.0, 0.25, 0.5, 0.75, 1.0],
    metrics=['accuracy', 'f1_score', 'precision', 'recall'],
    n_trials=1,
    verbose=True
)

print(f"\n✅ RF - Melhor α: {results_rf['best_proportion']:.2f}")
print(f"   Acurácia: {results_rf['best_metrics']['accuracy']:.4f}")

# ============================================================================
# 7. VISUALIZAÇÕES
# ============================================================================
print("\n📈 Gerando visualizações...\n")

# MLP
tunner_mlp.plot_results(metric='accuracy', save=True)
tunner_mlp.plot_multiple_metrics(['accuracy', 'f1_score'], save=True)
tunner_mlp.plot_confusion_matrix(proportion=results_mlp['best_proportion'], save=True)

# Random Forest
tunner_rf.plot_results(metric='accuracy', save=True)
tunner_rf.plot_multiple_metrics(['accuracy', 'f1_score'], save=True)
tunner_rf.plot_confusion_matrix(proportion=results_rf['best_proportion'], save=True)

# Comparação
fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 5))

# Comparar acurácia
ax1.plot(results_mlp['proportions_tested'], 
         [results_mlp['proportions'][p]['metrics']['accuracy'] for p in results_mlp['proportions_tested']], 
         'o-', label='MLP', linewidth=2)
ax1.plot(results_rf['proportions_tested'], 
         [results_rf['proportions'][p]['metrics']['accuracy'] for p in results_rf['proportions_tested']], 
         's-', label='Random Forest', linewidth=2)
ax1.set_xlabel('Proporção α (SMOTE)', fontweight='bold')
ax1.set_ylabel('Acurácia', fontweight='bold')
ax1.set_title('Comparação: MLP vs Random Forest', fontweight='bold', pad=15)
ax1.legend()
ax1.grid(True, alpha=0.3)

# Comparar F1-Score
ax2.plot(results_mlp['proportions_tested'], 
         [results_mlp['proportions'][p]['metrics']['f1_score'] for p in results_mlp['proportions_tested']], 
         'o-', label='MLP', linewidth=2)
ax2.plot(results_rf['proportions_tested'], 
         [results_rf['proportions'][p]['metrics']['f1_score'] for p in results_rf['proportions_tested']], 
         's-', label='Random Forest', linewidth=2)
ax2.set_xlabel('Proporção α (SMOTE)', fontweight='bold')
ax2.set_ylabel('F1-Score', fontweight='bold')
ax2.set_title('Comparação: F1-Score', fontweight='bold', pad=15)
ax2.legend()
ax2.grid(True, alpha=0.3)

plt.tight_layout()
plt.savefig('titanic_comparison.png', dpi=150, bbox_inches='tight')
print("💾 Comparação salva: titanic_comparison.png")
plt.show()

# ============================================================================
# 8. RELATÓRIOS
# ============================================================================
print("\n📄 Gerando relatórios...")

tunner_mlp.generate_report(format='html')
tunner_rf.generate_report(format='html')

# ============================================================================
# 9. RESULTADOS FINAIS
# ============================================================================
print("\n" + "=" * 70)
print("📊 RESULTADOS FINAIS")
print("=" * 70)

print(f"""
🧠 MLP (Multi-Layer Perceptron):
   - Melhor α: {results_mlp['best_proportion']:.2f}
   - Acurácia: {results_mlp['best_metrics']['accuracy']:.4f}
   - F1-Score: {results_mlp['best_metrics']['f1_score']:.4f}
   - Precision: {results_mlp['best_metrics']['precision']:.4f}
   - Recall: {results_mlp['best_metrics']['recall']:.4f}

🌲 Random Forest:
   - Melhor α: {results_rf['best_proportion']:.2f}
   - Acurácia: {results_rf['best_metrics']['accuracy']:.4f}
   - F1-Score: {results_rf['best_metrics']['f1_score']:.4f}
   - Precision: {results_rf['best_metrics']['precision']:.4f}
   - Recall: {results_rf['best_metrics']['recall']:.4f}

🏆 MELHOR MODELO:
""")

if results_mlp['best_metrics']['accuracy'] > results_rf['best_metrics']['accuracy']:
    print(f"   ✅ MLP com {results_mlp['best_metrics']['accuracy']:.4f} de acurácia")
else:
    print(f"   ✅ Random Forest com {results_rf['best_metrics']['accuracy']:.4f} de acurácia")

print(f"""
💡 INTERPRETAÇÃO:
   - SMOTE ajudou a balancear classes (sobreviventes vs não sobreviventes)
   - α ideal varia por modelo
   - Random Forest geralmente mais robusto para dados tabulares

📚 ARQUIVOS GERADOS:
   - MLP: results/titanic_mlp/
   - RF: results/titanic_rf/
   - Comparação: titanic_comparison.png

🔗 DATATUNNER:
   - PyPI: https://pypi.org/project/datatunner/
   - GitHub: https://github.com/leandrocrx/datatunner
   - Autor: Leandro Costa Rocha
""")

print("=" * 70)
print("✅ ANÁLISE CONCLUÍDA!")
print("=" * 70)
