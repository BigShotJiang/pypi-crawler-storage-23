"""
=======================================================================
🎯 QuickStart - Exemplo Rápido Usando DataTunner
============================================================================

Demonstração rápida do DataTunner com dataset sintético de formas geométricas. 

INSTALAÇÃO:
    pip install datatunner

USO NO GOOGLE COLAB:
    !pip install datatunner scikit-learn imbalanced-learn pillow

TEMPO: ~2-3 minutos
============================================================================
"""

# ============================================================================
# 1. INSTALAÇÃO (Descomente no Google Colab)
# ============================================================================
# !pip install -q datatunner scikit-learn imbalanced-learn pillow matplotlib

print("📦 Importando bibliotecas...")

import numpy as np
import matplotlib.pyplot as plt
from PIL import Image, ImageDraw

# IMPORTAR DATATUNNER
from datatunner import DataTunner
from datatunner.generators import SMOTEGenerator
from datatunner.models import MLPClassifier

print("✅ Bibliotecas importadas!\n")

# ============================================================================
# 2. GERAR DATASET SINTÉTICO (FORMAS GEOMÉTRICAS)
# ============================================================================
print("=" * 70)
print("🎯 QUICKSTART - DATATUNNER")
print("=" * 70)

print("\n🔨 Gerando dataset de formas geométricas...")

def generate_shape(shape_type, size=28):
    """Gera imagem de forma geométrica"""
    img = Image.new('L', (size, size), color=0)
    draw = ImageDraw.Draw(img)
    
    if shape_type == 0:  # Círculo
        draw.ellipse([4, 4, size-4, size-4], fill=255)
    elif shape_type == 1:  # Quadrado
        draw.rectangle([4, 4, size-4, size-4], fill=255)
    elif shape_type == 2:  # Triângulo
        draw.polygon([(size//2, 4), (4, size-4), (size-4, size-4)], fill=255)
    
    return np.array(img).flatten() / 255.0

# Gerar dados
n_samples = 300
X = []
y = []

for shape_type in [0, 1, 2]:  # 3 classes
    for i in range(n_samples // 3):
        X.append(generate_shape(shape_type))
        y.append(shape_type)

X = np.array(X)
y = np.array(y)

# Split train/test
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)

print(f"✅ Dataset criado!")
print(f"   Treino: {X_train.shape}")
print(f"   Teste: {X_test.shape}")
print(f"   Classes: Círculo (0), Quadrado (1), Triângulo (2)")

#visualizar algumas amostras
fig, axes = plt.subplots(1, 3, figsize=(10, 3))
class_names = ['Círculo', 'Quadrado', 'Triângulo']
for i, ax in enumerate(axes):
    idx = np.where(y_train == i)[0][0]
    ax.imshow(X_train[idx].reshape(28, 28), cmap='gray')
    ax.set_title(class_names[i], fontweight='bold')
    ax.axis('off')
plt.tight_layout()
plt.savefig('shapes_samples.png', dpi=100, bbox_inches='tight')
print("💾 Amostras salvas: shapes_samples.png")
plt.show()

# ============================================================================
# 3. CONFIGURAR GERADOR SMOTE
# ============================================================================
print("\n🔄 Configurando SMOTE...")

generator = SMOTEGenerator(
    k_neighbors=5,
    sampling_strategy='auto',
    random_state=42
)

print("✅ SMOTE configurado para dados tabulares!")

# ============================================================================
# 4. CONFIGURAR MODELO MLP
# ============================================================================
print("\n🧠 Configurando MLP...")

model = MLPClassifier(
    hidden_layer_sizes=(64, 32),
    activation='relu',
    max_iter=100,
    random_state=42,
    early_stopping=True,
    validation_fraction=0.2
)

print("✅ MLP configurado (2 camadas: 64→32)!")

# ============================================================================
# 5. CONFIGURAR DATATUNNER
# ============================================================================
print("\n⚙️  Configurando DataTunner...")

tunner = DataTunner(
    data_type='tabular',
    output_dir='results/quickstart',
    random_seed=42
)

print("✅ DataTunner pronto!")

# ============================================================================
# 6. EXECUTAR OTIMIZAÇÃO
# ============================================================================
print("\n🚀 Iniciando otimização...")
print("   (Aguarde ~1-2 minutos...)\n")

print("📊 Fórmula:")
print("   D_hybrid = D_real ∪ sample(D_syn, α · |D_real|)")
print("   α = proporção de sintéticos a adicionar\n")

# USAR API DO DATATUNNER!
results = tunner.optimize(
    X_train=X_train,
    y_train=y_train,
    X_test=X_test,
    y_test=y_test,
    generator=generator,
    model=model,
    proportions=[0.0, 0.25, 0.5, 0.75, 1.0],
    metrics=['accuracy', 'f1_score'],
    n_trials=1,
    verbose=True
)

# ============================================================================
# 7. VISUALIZAR RESULTADOS
# ============================================================================
print("\n📈 Gerando visualizações...\n")

# Plot acurácia
tunner.plot_results(metric='accuracy', save=True)

# Múltiplas métricas
tunner.plot_multiple_metrics(['accuracy', 'f1_score'], save=True)

# Matriz de confusão
tunner.plot_confusion_matrix(
    proportion=results['best_proportion'],
    save=True
)

# Gerar relatório
tunner.generate_report(format='html')

print("💾 Resultados salvos em: results/quickstart/")

# ============================================================================
# 8. RESULTADOS FINAIS
# ============================================================================
print("\n" + "=" * 70)
print("📊 RESULTADOS")
print("=" * 70)

best_prop = results['best_proportion']
best_metrics = results['best_metrics']
baseline_metrics = results['proportions'][0.0]['metrics']

print(f"""
✅ BASELINE (α=0.0 - Apenas dados reais):
   - Acurácia: {baseline_metrics['accuracy']:.4f}
   - F1-Score: {baseline_metrics['f1_score']:.4f}

🏆 MELHOR (α={best_prop:.2f}):
   - Acurácia: {best_metrics['accuracy']:.4f} (+{(best_metrics['accuracy']-baseline_metrics['accuracy'])*100:.1f}%)
   - F1-Score: {best_metrics['f1_score']:.4f} (+{(best_metrics['f1_score']-baseline_metrics['f1_score'])*100:.1f}%)

💡 CONCLUSÃO:
   - SMOTE gerou {int(len(X_train) * best_prop)} dados sintéticos adicionais
   - Melhorou a generalização do modelo
   - Ideal para datasets pequenos

📚 PRÓXIMOS PASSOS:
   1. Teste com seus próprios dados
   2. Experimente diferentes modelos (RF, XGBoost)
   3. Ajuste hiperparâmetros do gerador

🔗 DATATUNNER:
   - PyPI: https://pypi.org/project/datatunner/
   - GitHub: https://github.com/leandrocrx/datatunner
   - Docs: https://github.com/leandrocrx/datatunner/tree/main/docs

👤 AUTOR:
   Leandro Costa Rocha
   - Instagram: @leandrocr.adv
   - LinkedIn: linkedin.com/in/leandro-costa-rocha-b40189b0
""")

print("=" * 70)
print("✅ DEMO CONCLUÍDA!")
print("=" * 70)
print(f"\n💡 Para carregar o melhor modelo salvo:")
print(f"   best_model = tunner.load_best_model()")
print(f"   predictions = best_model.predict(X_new)")
