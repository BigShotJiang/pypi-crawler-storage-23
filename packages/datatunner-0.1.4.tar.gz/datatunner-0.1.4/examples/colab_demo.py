"""
DataTunner - Demo para Google Colab

Execute este código no Google Colab para testar o DataTunner.
Copie célula por célula para um novo notebook.
"""

# ============================================================================
# CÉLULA 1: Instalação
# ============================================================================
"""
!pip install datatunner torch torchvision scikit-learn matplotlib seaborn
"""

# ============================================================================
# CÉLULA 2: Importações e Verificação
# ============================================================================
"""
import datatunner
print(f"✅ DataTunner v{datatunner.__version__} instalado!")

import torch
import numpy as np
from sklearn.datasets import make_classification
from sklearn.model_selection import train_test_split

print(f"✅ PyTorch: {torch.__version__}")
print(f"✅ NumPy: {np.__version__}")
print(f"✅ GPU: {'Disponível' if torch.cuda.is_available() else 'CPU apenas'}")
"""

# ============================================================================
# CÉLULA 3: Gerar Dados Sintéticos
# ============================================================================
"""
print("="*70)
print("1️⃣  GERANDO DADOS SINTÉTICOS")
print("="*70)

# Criar dataset sintético
X, y = make_classification(
    n_samples=1000,
    n_features=20,
    n_informative=15,
    n_classes=3,
    random_state=42
)

# Split treino/teste
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

print(f"✅ Dataset criado:")
print(f"   Treino: {X_train.shape[0]} amostras")
print(f"   Teste: {X_test.shape[0]} amostras")
print(f"   Features: {X_train.shape[1]}")
print(f"   Classes: {len(np.unique(y))}")
"""

# ============================================================================
# CÉLULA 4: Gerar Dados Sintéticos com SMOTE
# ============================================================================
"""
from datatunner.generators.smote import SMOTEGenerator

print("\\n" + "="*70)
print("2️⃣  GERANDO DADOS SINTÉTICOS COM SMOTE")
print("="*70)

generator = SMOTEGenerator(k_neighbors=5, random_seed=42)
generator.fit(X_train, y_train)
X_synthetic, y_synthetic = generator.generate(n_samples=500)

print(f"✅ {len(X_synthetic)} dados sintéticos gerados!")
print(f"   Distribuição: {np.bincount(y_synthetic)}")
"""

# ============================================================================
# CÉLULA 5: Criar e Treinar Modelo
# ============================================================================
"""
from datatunner.models.mlp import MLPClassifier
from datatunner.core.evaluator import ModelEvaluator
from torch.utils.data import TensorDataset, DataLoader

print("\\n" + "="*70)
print("3️⃣  CRIANDO E TREINANDO MODELO")
print("="*70)

# Criar modelo
model = MLPClassifier(
    input_dim=X_train.shape[1],
    num_classes=len(np.unique(y_train)),
    hidden_layers=[128, 64, 32],
    dropout=0.3
)

print(f"✅ Modelo: {model.model_name}")
print(f"✅ Parâmetros: {model.count_parameters():,}")

# Preparar dados
train_dataset = TensorDataset(
    torch.FloatTensor(X_train),
    torch.LongTensor(y_train)
)
train_loader = DataLoader(train_dataset, batch_size=64, shuffle=True)

test_dataset = TensorDataset(
    torch.FloatTensor(X_test),
    torch.LongTensor(y_test)
)
test_loader = DataLoader(test_dataset, batch_size=64)

# Treinar
evaluator = ModelEvaluator(
    task_type='classification',
    num_classes=len(np.unique(y_train)),
    device='cuda' if torch.cuda.is_available() else 'cpu'
)

print("\\n🔄 Treinando modelo (10 epochs)...")
results = evaluator.train_and_evaluate(
    model=model,
    train_loader=train_loader,
    val_loader=test_loader,
    epochs=10,
    learning_rate=0.001
)

print(f"\\n📊 Resultados:")
print(f"   Train Loss: {results['train_loss']:.4f}")
print(f"   Val Loss: {results['val_loss']:.4f}")
print(f"   Accuracy: {results['metrics']['accuracy']:.4f}")
print(f"   F1-Score: {results['metrics']['f1_score']:.4f}")
"""

# ============================================================================
# CÉLULA 6: Testar DataTunner Completo (Opcional)
# ============================================================================
"""
from datatunner import DataTunner

print("\\n" + "="*70)
print("4️⃣  TESTANDO DATATUNNER COMPLETO")
print("="*70)

# Configurar DataTunner
tunner = DataTunner(
    data_type='tabular',
    output_dir='/content/results',
    random_seed=42
)

# Criar novo modelo
model_tunner = MLPClassifier(
    input_dim=X_train.shape[1],
    num_classes=len(np.unique(y_train)),
    hidden_layers=[64, 32]
)

# Otimizar proporções
print("\\n🔄 Otimizando proporções de dados sintéticos...")
results_tunner = tunner.optimize(
    model=model_tunner,
    synthetic_data=(X_synthetic, y_synthetic),
    proportions=[0.0, 0.2, 0.5],  # Poucas proporções para demo
    epochs=5,  # Poucos epochs para demo rápida
    batch_size=64
)

print(f"\\n🎯 Melhor Proporção: {results_tunner['best_proportion']:.1%}")
print(f"📊 Melhor Accuracy: {results_tunner['best_metrics']['accuracy']:.4f}")
"""

# ============================================================================
# CÉLULA 7: Visualizar Resultados (Se executou DataTunner)
# ============================================================================
"""
# Plotar resultados
tunner.plot_results(metric='accuracy')

# Ver resultados detalhados
import json
with open('/content/results/results.json', 'r') as f:
    detailed_results = json.load(f)

print("\\n📈 Resultados Detalhados:")
for prop, metrics in detailed_results.items():
    if prop != 'best_proportion':
        print(f"\\nProporção {prop}:")
        print(f"  Accuracy: {metrics['accuracy']:.4f}")
        print(f"  F1-Score: {metrics['f1_score']:.4f}")
"""

# ============================================================================
# CÉLULA 8: Testar Modelos Clássicos (Opcional)
# ============================================================================
"""
try:
    from datatunner.models.classical import (
        RandomForestClassifier,
        XGBoostClassifier
    )
    
    print("\\n" + "="*70)
    print("5️⃣  TESTANDO MODELOS CLÁSSICOS")
    print("="*70)
    
    # Random Forest
    rf = RandomForestClassifier(n_estimators=100, max_depth=10)
    rf.fit(X_train, y_train)
    y_pred_rf = rf.predict(X_test)
    acc_rf = np.mean(y_pred_rf == y_test)
    
    print(f"✅ Random Forest - Accuracy: {acc_rf:.4f}")
    
    # XGBoost (se instalado)
    try:
        xgb = XGBoostClassifier(n_estimators=100)
        xgb.fit(X_train, y_train)
        y_pred_xgb = xgb.predict(X_test)
        acc_xgb = np.mean(y_pred_xgb == y_test)
        
        print(f"✅ XGBoost - Accuracy: {acc_xgb:.4f}")
    except:
        print("⚠️  XGBoost não disponível")
        
except ImportError as e:
    print(f"⚠️  Modelos clássicos não disponíveis: {e}")
"""

# ============================================================================
# CÉLULA 9: Resumo e Links Úteis
# ============================================================================
"""
print("\\n" + "="*70)
print("✅ DEMO COMPLETA DO DATATUNNER!")
print("="*70)

print(\"\"\"
📚 Recursos Adicionais:

1. Documentação: https://github.com/leandro-rocha/datatunner
2. Exemplos: https://github.com/leandro-rocha/datatunner/tree/main/examples
3. Issues: https://github.com/leandro-rocha/datatunner/issues

🚀 Próximos Passos:

1. Experimente com seus próprios dados
2. Teste CTGAN: pip install sdv
3. Teste outros modelos: XGBoost, LightGBM
4. Ajuste hiperparâmetros
5. Explore visualizações

💡 Dicas para o Colab:

- Use GPU: Runtime → Change runtime type → GPU
- Monte Google Drive para salvar resultados
- Aumente epochs para resultados melhores
- Experimente diferentes proporções

Instagram: @leandrocr.adv
\"\"\"
)
"""

# ============================================================================
# INSTRUÇÕES DE USO
# ============================================================================
"""
COMO USAR NO GOOGLE COLAB:

1. Acesse: https://colab.research.google.com/
2. Crie um novo notebook
3. Copie cada seção de código (entre aspas triplas) para células separadas
4. Remova as aspas triplas de cada célula
5. Execute célula por célula (Shift+Enter)

DICA: Cole este arquivo inteiro em uma célula e execute para ver o código,
depois crie células individuais com cada seção.
"""
