"""
DataTunner - Demo com Dataset de Formas Geométricas
====================================================

Este notebook demonstra o uso do DataTunner com um dataset simples
de formas geométricas (círculos, quadrados, triângulos).

Execute cada célula sequencialmente no Google Colab.
"""

# ==============================================================================
# CÉLULA 1: Instalação
# ==============================================================================
"""
!pip install --index-url https://test.pypi.org/simple/ --extra-index-url https://pypi.org/simple/ datatunner
!pip install numpy pillow matplotlib scikit-learn
"""

# ==============================================================================
# CÉLULA 2: Imports e Configuração
# ==============================================================================

import numpy as np
import matplotlib.pyplot as plt
from PIL import Image, ImageDraw
import os
from sklearn.model_selection import train_test_split

# Criar diretórios
os.makedirs('data/shapes/train', exist_ok=True)
os.makedirs('data/shapes/test', exist_ok=True)

print("✅ Bibliotecas importadas e diretórios criados!")

# ==============================================================================
# CÉLULA 3: Funções para Gerar Formas Geométricas
# ==============================================================================

def create_circle(size=64, color='white'):
    """Cria imagem de um círculo"""
    img = Image.new('RGB', (size, size), 'black')
    draw = ImageDraw.Draw(img)
    margin = size // 8
    draw.ellipse([margin, margin, size-margin, size-margin], fill=color)
    return np.array(img)

def create_square(size=64, color='white'):
    """Cria imagem de um quadrado"""
    img = Image.new('RGB', (size, size), 'black')
    draw = ImageDraw.Draw(img)
   margin = size // 8
    draw.rectangle([margin, margin, size-margin, size-margin], fill=color)
    return np.array(img)

def create_triangle(size=64, color='white'):
    """Cria imagem de um triângulo"""
    img = Image.new('RGB', (size, size), 'black')
    draw = ImageDraw.Draw(img)
    margin = size // 8
    points = [
        (size//2, margin),  # Topo
        (margin, size-margin),  # Esquerda embaixo
        (size-margin, size-margin)  # Direita embaixo
    ]
    draw.polygon(points, fill=color)
    return np.array(img)

def add_noise(img, noise_level=0.1):
    """Adiciona ruído gaussiano à imagem"""
    noise = np.random.normal(0, noise_level * 255, img.shape)
    noisy_img = np.clip(img + noise, 0, 255).astype(np.uint8)
    return noisy_img

print("✅ Funções de geração de formas criadas!")

# ==============================================================================
# CÉLULA 4: Geração do Dataset
# ==============================================================================

def generate_dataset(n_samples_per_class=100, size=64, with_noise=True):
    """Gera dataset de formas geométricas"""
    
    X = []
    y = []
    
    # Labels: 0 = círculo, 1 = quadrado, 2 = triângulo
    shapes = [
        (create_circle, 0, 'Circle'),
        (create_square, 1, 'Square'),
        (create_triangle, 2, 'Triangle')
    ]
    
    for shape_func, label, name in shapes:
        for i in range(n_samples_per_class):
            # Criar forma
            img = shape_func(size=size, color='white')
            
            # Adicionar variação
            if with_noise and i % 2 == 0:  # 50% com ruído
                img = add_noise(img, noise_level=0.05)
            
            # Pequena rotação aleatória (simula variação)
            if np.random.rand() > 0.5:
                angle = np.random.randint(-15, 15)
                pil_img = Image.fromarray(img)
                pil_img = pil_img.rotate(angle, fillcolor='black')
                img = np.array(pil_img)
            
            X.append(img)
            y.append(label)
    
    return np.array(X), np.array(y)

# Gerar dados reais (treino + teste)
print("Gerando dados reais...")
X_real, y_real = generate_dataset(n_samples_per_class=150, with_noise=True)

# Dividir em treino e teste
X_train, X_test, y_train, y_test = train_test_split(
    X_real, y_real, test_size=0.3, random_state=42, stratify=y_real
)

print(f"✅ Dataset criado!")
print(f"  - Treino: {len(X_train)} imagens")
print(f"  - Teste: {len(X_test)} imagens")
print(f"  - Shape: {X_train[0].shape}")
print(f"  - Classes: Círculo (0), Quadrado (1), Triângulo (2)")

# ==============================================================================
# CÉLULA 5: Visualização das Formas
# ==============================================================================

fig, axes = plt.subplots(3, 5, figsize=(12, 8))
fig.suptitle('Exemplos do Dataset - Formas Geométricas', fontsize=16)

class_names = ['Círculo', 'Quadrado', 'Triângulo']

for class_idx in range(3):
    # Pegar 5 exemplos de cada classe
    samples = X_train[y_train == class_idx][:5]
    
    for i, img in enumerate(samples):
        axes[class_idx, i].imshow(img)
        axes[class_idx, i].axis('off')
        if i == 0:
            axes[class_idx, i].set_ylabel(class_names[class_idx], fontsize=12)

plt.tight_layout()
plt.show()

print("✅ Visualização completa!")

# ==============================================================================
# CÉLULA 6: Geração de Dados Sintéticos (SMOTE-like manual)
# ==============================================================================

def generate_synthetic_shapes(X, y, n_synthetic=100):
    """
    Gera formas sintéticas interpolando entre exemplos reais
    (versão simplificada do SMOTE para imagens)
    """
    X_synthetic = []
    y_synthetic = []
    
    for _ in range(n_synthetic):
        # Escolher classe aleatória
        target_class = np.random.randint(0, 3)
        
        # Pegar dois exemplos da mesma classe
        class_samples = X[y == target_class]
        idx1, idx2 = np.random.choice(len(class_samples), 2, replace=False)
        
        # Interpolar (média ponderada)
        alpha = np.random.rand()
        synthetic_img = (alpha * class_samples[idx1] + 
                        (1 - alpha) * class_samples[idx2]).astype(np.uint8)
        
        # Adicionar pequeno ruído
        synthetic_img = add_noise(synthetic_img, noise_level=0.03)
        
        X_synthetic.append(synthetic_img)
        y_synthetic.append(target_class)
    
    return np.array(X_synthetic), np.array(y_synthetic)

print("Gerando dados sintéticos...")
X_synthetic, y_synthetic = generate_synthetic_shapes(X_train, y_train, n_synthetic=200)

print(f"✅ Dados sintéticos criados: {len(X_synthetic)} imagens")

# ==============================================================================
# CÉLULA 7: Comparação Real vs Sintético
# ==============================================================================

fig, axes = plt.subplots(2, 5, figsize=(12, 5))
fig.suptitle('Real (topo) vs Sintético (baixo)', fontsize=16)

for i in range(5):
    # Real
    axes[0, i].imshow(X_train[i])
    axes[0, i].axis('off')
    if i == 0:
        axes[0, i].set_ylabel('Real', fontsize=12)
    
    # Sintético
    axes[1, i].imshow(X_synthetic[i])
    axes[1, i].axis('off')
    if i == 0:
        axes[1, i].set_ylabel('Sintético', fontsize=12)

plt.tight_layout()
plt.show()

print("✅ Dados sintéticos parecem realistas!")

# ==============================================================================
# CÉLULA 8: Teste Rápido com DataTunner
# ==============================================================================

print("\n" + "="*60)
print("TESTE DO DATATUNNER")
print("="*60)

try:
    from datatunner.generators.smote import SMOTEGenerator
    from datatunner.models.mlp import MLPClassifier
    from datatunner.core.optimizer import DataTunner
    
    print("✅ DataTunner importado com sucesso!")
    
    # Preparar dados (flatten para MLP)
    X_train_flat = X_train.reshape(len(X_train), -1) / 255.0  # Normalizar
    X_test_flat = X_test.reshape(len(X_test), -1) / 255.0
    X_synthetic_flat = X_synthetic.reshape(len(X_synthetic), -1) / 255.0
    
    print(f"\nDados preparados:")
    print(f"  - X_train: {X_train_flat.shape}")
    print(f"  - X_test: {X_test_flat.shape}")
    print(f"  - X_synthetic: {X_synthetic_flat.shape}")
    
    # Criar gerador SMOTE
    print("\nCriando gerador SMOTE...")
    generator = SMOTEGenerator(k_neighbors=3)
    generator.fit(X_train_flat, y_train)
    
    # Gerar dados sintéticos com SMOTE
    print("Gerando dados com SMOTE...")
    X_smote, y_smote = generator.generate(n_samples=100)
    print(f"✅ SMOTE gerado: {X_smote.shape}")
    
    # Criar modelo MLP
    print("\nCriando modelo MLP...")
    model = MLPClassifier(
        input_size=X_train_flat.shape[1],
        hidden_layers=[64, 32],
        num_classes=3,
        dropout=0.2
    )
    print("✅ Modelo criado!")
    
    # Criar DataTunner
    print("\nCriando DataTunner...")
    tunner = DataTunner(
        generator=generator,
        model=model,
        proportions=[0.0, 0.3, 0.5, 0.7, 1.0],
        n_trials=2,  # Reduzido para demo rápida
        random_seed=42
    )
   print("✅ DataTunner configurado!")
    
    # Otimizar!
    print("\n🚀 Iniciando otimização...")
    print("(Isso pode levar alguns minutos...)\n")
    
    results = tunner.optimize(X_train_flat, y_train, X_test_flat, y_test)
    
    print("\n" + "="*60)
    print("RESULTADOS")
    print("="*60)
    print(f"✅ Melhor proporção: {results['best_proportion']}")
    print(f"✅ Melhor acurácia: {results['best_score']:.4f}")
    print(f"✅ Scores por proporção:")
    for prop, score in zip(results['proportions'], results['scores']):
        print(f"     {prop:.1f}: {score:.4f}")
    
    # Visualizar resultados
    plt.figure(figsize=(10, 6))
    plt.plot(results['proportions'], results['scores'], 'o-', linewidth=2, markersize=8)
    plt.xlabel('Proporção de Dados Sintéticos', fontsize=12)
    plt.ylabel('Acurácia', fontsize=12)
    plt.title('DataTunner - Otimização de Proporções\n(Dataset de Formas Geométricas)', fontsize=14)
    plt.grid(True, alpha=0.3)
    plt.axvline(results['best_proportion'], color='r', linestyle='--', label=f'Melhor: {results["best_proportion"]:.1f}')
    plt.legend()
    plt.tight_layout()
    plt.show()
    
    print("\n🎉 Teste concluído com sucesso!")
    
except ImportError as e:
    print(f"❌ Erro ao importar DataTunner: {e}")
    print("\nVerifique se o pacote foi instalado corretamente:")
    print("  !pip install --index-url https://test.pypi.org/simple/ --extra-index-url https://pypi.org/simple/ datatunner")

except Exception as e:
    print(f"❌ Erro durante execução: {e}")
    import traceback
    traceback.print_exc()

# ==============================================================================
# CÉLULA 9: Resumo e Próximos Passos
# ==============================================================================

print("\n" + "="*60)
print("RESUMO DO TESTE")
print("="*60)
print("""
✅ O que testamos:
  - Criação de dataset sintético de formas geométricas
  - Geração de dados sintéticos com interpolação
  - Importação e uso do DataTunner
  - Otimização de proporções de dados sintéticos
  - Visualização de resultados

🎯 Próximos passos:
  1. Testar com datasets reais (MNIST, CIFAR-10)
  2. Experimentar diferentes geradores (CTGAN, Stable Diffusion)
  3. Testar com modelos mais complexos (CNNs, ResNet)
  4. Ajustar hiperparâmetros e proporções

📚 Documentação:
  - GitHub: https://github.com/leandrocrx/datatunner
  - Exemplos: https://github.com/leandrocrx/datatunner/tree/main/examples

🐛 Encontrou um problema?
  - Issues: https://github.com/leandrocrx/datatunner/issues
""")
