from .InstagramApiExeption import InstagramApiException

__all__ = ["InstagramApiException"]

