import pandas as pd
import numpy as np
import matplotlib.pyplot as plt


df = pd.read_csv("data.csv")

U1 = df["Ustart"].values
U2 = df["Ufinish"].values
w  = df["omega"].values
