# Text processing library
```
<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <title>Serial</title>
</head>

<body onclick="start()" style="overflow: hidden">
    <canvas id="c"></canvas>
</body>

<script>
    let WINDOW = 20000;
    let COLORS = ['blue', 'green', 'orange', 'red', 'purple'];
    let NAMES = ['Напряжение (В)', 'Ток (мА)', 'Мощность (мВт)', 'Заряд (Кл)', 'Угл. скорость (рад/с)'];
    let data = [[], [], [], [], []];

    async function start() {
        document.body.onclick = null;

        let port = await navigator.serial.requestPort();
        await port.open({ baudRate: 57600 });

        let reader = port.readable.pipeThrough(new TextDecoderStream()).getReader();
        let buf = '';

        while (true) {
            let { value } = await reader.read();
            buf += value;

            let nl;

            while ((nl = buf.indexOf('\n')) !== -1) {
                parseLine(buf.slice(0, nl).trim());
                buf = buf.slice(nl + 1);
            }
        }
    }

    function parseLine(line) {
        let raw = line.split(',').map(Number);

        if (raw.some(isNaN)) {
            return;
        }

        let [a, b, c, d] = raw;
        let vals = [a, b, c, d, a + b + c + d];

        let t = Date.now();
        let lim = t - WINDOW;

        vals.forEach((v, i) => {
            data[i].push({ t, v });
            while (data[i][0].t < lim) {
                data[i].shift();
            }
        });
    }

    let canvas = document.getElementById('c');

    function draw() {
        let W = window.innerWidth;
        let H = window.innerHeight;

        canvas.width = W;
        canvas.height = H;

        let ctx = canvas.getContext('2d');
        ctx.clearRect(0, 0, W, H);

        let cols = 3, rows = 2;
        let cW = W / cols, cH = H / rows;

        for (let i = 0; i < 5; i++) {
            let ox = (i % cols) * cW, oy = (Math.floor(i / cols)) * cH;

            let pad = { l: 52, r: 8, t: 18, b: 20 };
            let gW = cW - pad.l - pad.r;
            let gH = cH - pad.t - pad.b;
            
            let points = data[i];

            ctx.strokeStyle = '#000';
            ctx.lineWidth = 1;
            ctx.strokeRect(ox, oy, cW, cH);

            ctx.fillStyle = '#000';
            ctx.font = 'bold 14px monospace';
            ctx.textAlign = 'left';

            ctx.fillText(NAMES[i], ox + pad.l + 4, oy + 14);

            if (points.length < 2) continue;

            let now = Date.now();
            let vMin = Infinity, vMax = -Infinity;

            points.forEach(p => {
                vMin = Math.min(vMin, p.v);
                vMax = Math.max(vMax, p.v);
            });
            // if (vMin === vMax) { 
            //     vMin -= 1; 
            //     vMax += 1;
            // }

            vMin = vMin * 0.9;
            vMax = vMax * 1.1;
    

            let xP = t => ox + pad.l + (t - (now - WINDOW)) / WINDOW * gW;
            let yP = v => oy + pad.t + (1 - (v - vMin) / (vMax - vMin)) * gH;

            ctx.strokeStyle = '#000'; 
            ctx.lineWidth = 0.3;

            for (let k = 0; k <= 4; k++) {
                let v = vMin + (vMax - vMin) * k / 4, y = yP(v);

                ctx.beginPath();
                ctx.moveTo(ox + pad.l, y);
                ctx.lineTo(ox + pad.l + gW, y);
                ctx.stroke();

                ctx.fillStyle = '#000';
                ctx.font = '10px monospace';
                ctx.textAlign = 'right';

                ctx.fillText(v.toFixed(1), ox + pad.l - 3, y + 3);
            }

            ctx.fillStyle = '#000';
            ctx.font = '10px monospace';
            ctx.textAlign = 'center';

            [0, 5, 10, 15, 20].forEach(
                s => ctx.fillText(
                    '-' + s + 's',
                    ox + pad.l + (1 - s / 20) * gW, 
                    oy + cH - 4
                )
            );

            ctx.strokeStyle = COLORS[i];
            ctx.lineWidth = 1.5;
            ctx.beginPath();

            points.forEach(
                (p, j) => j === 0 ? ctx.moveTo(xP(p.t), yP(p.v))
                    : ctx.lineTo(xP(p.t), yP(p.v))
            );
            ctx.stroke();

            let last = points[points.length - 1];

            ctx.fillStyle = "#000";
            ctx.font = 'bold 12px monospace';
            ctx.textAlign = 'left';

            ctx.fillText(last.v.toFixed(3), ox + pad.l + 4, oy + pad.t + 14);
        }

        if (document.body.onclick) {
            ctx.fillStyle = '#f00';
            ctx.font = '28px monospace';
            ctx.textAlign = 'center';

            ctx.fillText('подключить', W / 2, H / 2.5);
        }

        requestAnimationFrame(draw);
    }
    draw();
</script>

</html>
```