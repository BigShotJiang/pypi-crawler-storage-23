"""tval - Table data validator for pre-analysis data validation."""

from importlib.metadata import version

__version__ = version("tval-cli")
