"""Allow running the MCP server with: python -m pywiim.mcp"""

from . import run

if __name__ == "__main__":
    run()
