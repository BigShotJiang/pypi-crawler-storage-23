"""
Message types example: Demonstrating SystemMessage, UserMessage, etc.

This example shows:
1. Creating different message types
2. Building conversation history
3. Serialization to JSON
4. Working with tool calls

Run with: uv run python examples/message-types-example.py
"""

from agentbyte.llm import (
    SystemMessage,
    UserMessage,
    AssistantMessage,
    ToolMessage,
    ToolCall,
    MessageRole,
)


def example_1_basic_messages():
    """Example 1: Creating basic message types."""
    print("\n" + "=" * 70)
    print("EXAMPLE 1: Basic Message Types")
    print("=" * 70)

    # System message
    system = SystemMessage(
        content="You are a helpful assistant who answers questions concisely."
    )
    print(f"\n1. SystemMessage:")
    print(f"   Role: {system.role}")
    print(f"   Content: {system.content}")

    # User message
    user = UserMessage(content="What is the capital of France?")
    print(f"\n2. UserMessage:")
    print(f"   Role: {user.role}")
    print(f"   Content: {user.content}")

    # Assistant message (text only)
    assistant = AssistantMessage(content="The capital of France is Paris.")
    print(f"\n3. AssistantMessage (text only):")
    print(f"   Role: {assistant.role}")
    print(f"   Content: {assistant.content}")
    print(f"   Tool calls: {assistant.tool_calls}")


def example_2_tool_calls():
    """Example 2: Assistant message with tool calls."""
    print("\n" + "=" * 70)
    print("EXAMPLE 2: Tool Calls")
    print("=" * 70)

    # Create tool calls
    tool_call = ToolCall(
        id="call_abc123",
        name="get_weather",
        arguments={"location": "Paris", "units": "celsius"}
    )

    print(f"\n1. ToolCall:")
    print(f"   ID: {tool_call.id}")
    print(f"   Name: {tool_call.name}")
    print(f"   Arguments: {tool_call.arguments}")

    # Assistant message with tool calls
    assistant = AssistantMessage(
        content="I'll check the weather for you.",
        tool_calls=[tool_call]
    )

    print(f"\n2. AssistantMessage with tool calls:")
    print(f"   Content: {assistant.content}")
    print(f"   Tool calls: {len(assistant.tool_calls)} call(s)")
    for tc in assistant.tool_calls:
        print(f"      - {tc.name}({tc.arguments})")


def example_3_tool_response():
    """Example 3: Tool message with results."""
    print("\n" + "=" * 70)
    print("EXAMPLE 3: Tool Response Messages")
    print("=" * 70)

    # Tool message (response from tool execution)
    tool_result = ToolMessage(
        content="Weather in Paris: Sunny, 22°C, light wind",
        tool_call_id="call_abc123"
    )

    print(f"\n1. ToolMessage (tool result):")
    print(f"   Role: {tool_result.role}")
    print(f"   Content: {tool_result.content}")
    print(f"   Responding to: {tool_result.tool_call_id}")


def example_4_conversation_history():
    """Example 4: Building a conversation history."""
    print("\n" + "=" * 70)
    print("EXAMPLE 4: Conversation History")
    print("=" * 70)

    messages = [
        SystemMessage(content="You are a weather assistant."),
        UserMessage(content="What's the weather in Paris?"),
        AssistantMessage(
            content="I'll check that for you.",
            tool_calls=[
                ToolCall(
                    id="call_1",
                    name="get_weather",
                    arguments={"location": "Paris"}
                )
            ]
        ),
        ToolMessage(
            content="Sunny, 22°C",
            tool_call_id="call_1"
        ),
        AssistantMessage(
            content="The weather in Paris is sunny and 22°C."
        ),
    ]

    print(f"\nConversation with {len(messages)} messages:")
    for i, msg in enumerate(messages, 1):
        role = msg.role
        preview = msg.content[:50] + "..." if len(msg.content) > 50 else msg.content
        print(f"{i:2}. [{role:10}] {preview}")


def example_5_serialization():
    """Example 5: JSON serialization."""
    print("\n" + "=" * 70)
    print("EXAMPLE 5: JSON Serialization")
    print("=" * 70)

    # Create a message with tool calls
    assistant = AssistantMessage(
        content="I found the information.",
        tool_calls=[
            ToolCall(
                id="call_1",
                name="search",
                arguments={"query": "Paris capital"}
            )
        ]
    )

    # Serialize to JSON
    json_data = assistant.model_dump_json(indent=2)
    print(f"\nAssistantMessage as JSON:")
    print(json_data)

    # Deserialize from JSON
    json_str = json_data
    restored = AssistantMessage.model_validate_json(json_str)
    print(f"\nRestored from JSON:")
    print(f"  Content: {restored.content}")
    print(f"  Tool calls: {len(restored.tool_calls)} call(s)")


def example_6_message_roles():
    """Example 6: Understanding message roles."""
    print("\n" + "=" * 70)
    print("EXAMPLE 6: Message Roles")
    print("=" * 70)

    print(f"\nAvailable roles:")
    for role in MessageRole:
        print(f"  - {role.name:10} = '{role.value}'")

    print(f"\nUse cases:")
    print(f"  • SYSTEM:    Defines behavior and instructions")
    print(f"  • USER:      User's input or questions")
    print(f"  • ASSISTANT: Model's responses and tool calls")
    print(f"  • TOOL:      Results from tool execution")


def example_7_immutability():
    """Example 7: Pydantic validation."""
    print("\n" + "=" * 70)
    print("EXAMPLE 7: Pydantic Validation")
    print("=" * 70)

    # Valid message
    msg1 = UserMessage(content="Hello")
    print(f"\n1. Valid message created: {msg1.content}")

    # Try invalid (missing required field)
    try:
        msg2 = UserMessage()  # Missing required 'content'
    except Exception as e:
        print(f"\n2. Invalid message (missing content):")
        print(f"   Error: {type(e).__name__}")

    # Verify role defaults work
    system = SystemMessage(content="Test")
    user = UserMessage(content="Test")
    assistant = AssistantMessage(content="Test")
    tool = ToolMessage(content="Test", tool_call_id="1")

    print(f"\n3. Role defaults:")
    print(f"   SystemMessage role: {system.role}")
    print(f"   UserMessage role: {user.role}")
    print(f"   AssistantMessage role: {assistant.role}")
    print(f"   ToolMessage role: {tool.role}")


# Run all examples
def main():
    """Run all examples."""
    print("\n" + "=" * 70)
    print("AGENTBYTE MESSAGE TYPES EXAMPLE")
    print("=" * 70)

    example_1_basic_messages()
    example_2_tool_calls()
    example_3_tool_response()
    example_4_conversation_history()
    example_5_serialization()
    example_6_message_roles()
    example_7_immutability()

    print("\n" + "=" * 70)
    print("✅ All examples completed!")
    print("=" * 70 + "\n")


if __name__ == "__main__":
    main()
