"""
Example: OpenAI Chat Completion Client with Dependency Injection

Demonstrates how to use OpenAIChatCompletionClient with different configurations
and authentication methods through dependency injection.

Key Pattern:
    1. Create and configure an AsyncOpenAI client (authentication handled separately)
    2. Inject into OpenAIChatCompletionClient at initialization
    3. Use the client for both single and streaming requests
    4. All error handling is unified through the ModelClientError hierarchy
"""

import asyncio

from agentbyte.llm import OpenAIChatCompletionClient


# ============================================================================
# Example 1: Basic Setup with API Key
# ============================================================================

async def example_basic():
    """Basic OpenAI setup with API key."""
    print("\n" + "=" * 70)
    print("Example 1: Basic Setup with API Key")
    print("=" * 70)

    try:
        from openai import AsyncOpenAI

        # Step 1: Create and configure the AsyncOpenAI client
        # (In real code, use environment variable or secure credentials)
        openai_client = AsyncOpenAI(api_key="sk-test-key")

        # Step 2: Inject into agentbyte
        llm = OpenAIChatCompletionClient(
            model="gpt-4.1-mini",
            client=openai_client,
        )

        print("✓ OpenAI client created with dependency injection")
        print(f"  Model: {llm.model}")
        print(f"  Client type: {type(llm.client).__name__}")

    except ImportError:
        print("⚠ OpenAI package not installed (this is a demo)")


# ============================================================================
# Example 2: Configuration with Default Parameters
# ============================================================================

async def example_with_config():
    """Setup with default configuration."""
    print("\n" + "=" * 70)
    print("Example 2: Setup with Default Configuration")
    print("=" * 70)

    try:
        from openai import AsyncOpenAI

        # Create client
        openai_client = AsyncOpenAI(api_key="sk-test-key")

        # Inject with default configuration
        config = {
            "temperature": 0.7,
            "max_tokens": 2000,
            "top_p": 0.9,
        }

        OpenAIChatCompletionClient(
            model="gpt-4.1-mini",
            client=openai_client,
            config=config,
        )

        print("✓ Client created with default configuration")
        print(f"  Default config: {config}")

        # These defaults will be used for all requests unless overridden

    except ImportError:
        print("⚠ OpenAI package not installed (this is a demo)")


# ============================================================================
# Example 3: Custom Configuration per Request
# ============================================================================

async def example_override_config():
    """Override default config per request."""
    print("\n" + "=" * 70)
    print("Example 3: Override Configuration Per Request")
    print("=" * 70)

    print("✓ Configuration override pattern shown")
    print("  Default config: temperature=0.7")
    print("  Override in request: temperature=0.1 (more deterministic)")
    print()
    print("  Example code:")
    print("    llm = OpenAIChatCompletionClient(")
    print("        model='gpt-4.1-mini',")
    print("        client=openai_client,")
    print("        config={'temperature': 0.7}")
    print("    )")
    print()
    print("    # Override for specific request")
    print("    result = await llm.create(")
    print("        messages=[...],")
    print("        temperature=0.1  # Override default config")
    print("    )")


# ============================================================================
# Example 4: Organization-Based Billing
# ============================================================================

async def example_organization():
    """Setup with organization for billing."""
    print("\n" + "=" * 70)
    print("Example 4: Organization-Based Billing")
    print("=" * 70)

    try:
        from openai import AsyncOpenAI

        # Create client with organization for billing
        openai_client = AsyncOpenAI(
            api_key="sk-test-key",
            organization="org-123",  # Bill to specific organization
        )

        OpenAIChatCompletionClient(
            model="gpt-4.1-mini",
            client=openai_client,
        )

        print("✓ Client created with organization billing")
        print("  Requests will be billed to: org-123")

    except ImportError:
        print("⚠ OpenAI package not installed (this is a demo)")


# ============================================================================
# Example 5: Proxy and Timeout Configuration
# ============================================================================

async def example_proxy():
    """Setup with corporate proxy."""
    print("\n" + "=" * 70)
    print("Example 5: Proxy and Timeout Configuration")
    print("=" * 70)

    try:
        from openai import AsyncOpenAI

        # Create client with proxy and custom timeout
        base_url = "https://corporate-proxy.company.com/openai"
        timeout = 60.0

        openai_client = AsyncOpenAI(
            api_key="sk-test-key",
            base_url=base_url,
            timeout=timeout,
        )

        OpenAIChatCompletionClient(
            model="gpt-4.1-mini",
            client=openai_client,
        )

        print("✓ Client created with custom configuration")
        print(f"  Proxy: {base_url}")
        print(f"  Timeout: {timeout} seconds")

    except ImportError:
        print("⚠ OpenAI package not installed (this is a demo)")


# ============================================================================
# Example 6: Environment-Based Configuration
# ============================================================================

async def example_environment():
    """Different configs per environment."""
    print("\n" + "=" * 70)
    print("Example 6: Environment-Based Configuration")
    print("=" * 70)

    import os

    env = os.getenv("ENVIRONMENT", "development")

    # Environment-specific configs
    configs = {
        "development": {
            "base_url": None,
            "timeout": 30.0,
            "llm_config": {"temperature": 0.9, "max_tokens": 1000},
        },
        "staging": {
            "base_url": "https://staging-proxy.company.com/openai",
            "timeout": 45.0,
            "llm_config": {"temperature": 0.7, "max_tokens": 2000},
        },
        "production": {
            "base_url": "https://prod-proxy.company.com/openai",
            "timeout": 60.0,
            "llm_config": {"temperature": 0.5, "max_tokens": 2000},
        },
    }

    config = configs[env]
    print(f"✓ Configuration loaded for: {env}")
    print(f"  Base URL: {config['base_url'] or 'Default (api.openai.com)'}")
    print(f"  Timeout: {config['timeout']} seconds")
    print(f"  Temperature: {config['llm_config']['temperature']}")


# ============================================================================
# Example 7: Mock Client for Testing
# ============================================================================

class MockOpenAIClient:
    """Mock client for testing without real API calls."""

    async def chat_completions_create(self, **kwargs):
        """Return mock response."""
        return MockResponse()


class MockResponse:
    """Mock OpenAI response."""

    def __init__(self):
        self.choices = [MockChoice()]
        self.usage = MockUsage()
        self.model = "gpt-4.1-mini"


class MockChoice:
    """Mock choice."""

    def __init__(self):
        self.message = MockMessage()
        self.finish_reason = "stop"


class MockMessage:
    """Mock message."""

    def __init__(self):
        self.content = "Mock response"
        self.tool_calls = None


class MockUsage:
    """Mock usage."""

    def __init__(self):
        self.prompt_tokens = 10
        self.completion_tokens = 20


async def example_testing_mock():
    """Using mock client for testing."""
    print("\n" + "=" * 70)
    print("Example 7: Mock Client for Testing")
    print("=" * 70)

    # Create mock client
    mock_client = MockOpenAIClient()

    # Inject for testing (same pattern as real client!)
    llm_with_mock = OpenAIChatCompletionClient(
        model="gpt-4.1-mini",
        client=mock_client,
    )

    print("✓ Mock client created for testing")
    print(f"  Client type: {type(llm_with_mock).__name__}")
    print("  Same OpenAIChatCompletionClient used with mock instead of real client")
    print("  Enables unit tests without real API calls")


# ============================================================================
# Example 8: Error Handling with Unified Exception Hierarchy
# ============================================================================

async def example_error_handling():
    """Error handling with unified exceptions."""
    print("\n" + "=" * 70)
    print("Example 8: Error Handling with Unified Exceptions")
    print("=" * 70)

    print("✓ Unified error handling pattern")
    print()
    print("All OpenAI errors convert to agentbyte exception hierarchy:")
    print()
    print("  try:")
    print("      result = await llm.create(messages=[...])")
    print("  except RateLimitError:")
    print("      # Handle rate limits with exponential backoff")
    print("      pass")
    print("  except AuthenticationError:")
    print("      # Handle auth failures")
    print("      pass")
    print("  except InvalidRequestError:")
    print("      # Handle invalid requests")
    print("      pass")
    print("  except ModelClientError:")
    print("      # Handle other LLM errors")
    print("      pass")


# ============================================================================
# Example 9: Single Request Pattern
# ============================================================================

async def example_single_request():
    """Single LLM request pattern."""
    print("\n" + "=" * 70)
    print("Example 9: Single Request Pattern")
    print("=" * 70)

    print("✓ Single request code pattern")
    print()
    print("  result: ChatCompletionResult = await llm.create(")
    print("      messages=[")
    print("          SystemMessage(content='You are helpful.'),")
    print("          UserMessage(content='What is 2+2?')")
    print("      ],")
    print("      temperature=0.7  # Override config")
    print("  )")
    print()
    print("  # Access response")
    print("  print(result.message.content)      # 'The answer is 4'")
    print("  print(result.usage.total_tokens)   # 45")
    print("  print(result.model)                # 'gpt-4.1-mini'")


# ============================================================================
# Example 10: Streaming Request Pattern
# ============================================================================

async def example_streaming():
    """Streaming LLM request pattern."""
    print("\n" + "=" * 70)
    print("Example 10: Streaming Request Pattern")
    print("=" * 70)

    print("✓ Streaming request code pattern")
    print()
    print("  # Real-time updates as response arrives")
    print("  async for chunk in llm.create_stream(")
    print("      messages=[UserMessage(content='Write a haiku')],")
    print("      max_tokens=100")
    print("  ):")
    print("      print(chunk.content, end='', flush=True)")
    print()
    print("  Chunks stream real-time from API:")
    print("  - Reduced perceived latency")
    print("  - Enable cancellation mid-stream")
    print("  - Real-time user feedback")


# ============================================================================
# Example 11: Tool Calling Pattern
# ============================================================================

async def example_tool_calling():
    """Tool calling / function calling pattern."""
    print("\n" + "=" * 70)
    print("Example 11: Tool Calling (Function Calling) Pattern")
    print("=" * 70)

    print("✓ Function calling code pattern")
    print()
    print("  tools = [")
    print("    {")
    print("        'type': 'function',")
    print("        'function': {")
    print("            'name': 'get_weather',")
    print("            'description': 'Get weather for a location',")
    print("            'parameters': {")
    print("                'type': 'object',")
    print("                'properties': {")
    print("                    'location': {'type': 'string'}")
    print("                },")
    print("                'required': ['location']")
    print("            }")
    print("        }")
    print("    }")
    print("  ]")
    print()
    print("  result = await llm.create(")
    print("      messages=[UserMessage(content=\"What's the weather?\")],")
    print("      tools=tools")
    print("  )")
    print()
    print("  # Check if model called tools")
    print("  if result.message.tool_calls:")
    print("      for tool_call in result.message.tool_calls:")
    print("          print(f'Tool: {tool_call.name}')")
    print("          print(f'Args: {tool_call.arguments}')")


# ============================================================================
# Main: Run All Examples
# ============================================================================

async def main():
    """Run all examples."""
    print("\n" + "=" * 70)
    print("OpenAI Chat Completion Client - Dependency Injection Examples")
    print("=" * 70)

    examples = [
        ("Basic Setup", example_basic),
        ("With Config", example_with_config),
        ("Override Config", example_override_config),
        ("Organization", example_organization),
        ("Proxy & Timeout", example_proxy),
        ("Environment-Based", example_environment),
        ("Mock Testing", example_testing_mock),
        ("Error Handling", example_error_handling),
        ("Single Request", example_single_request),
        ("Streaming", example_streaming),
        ("Tool Calling", example_tool_calling),
    ]

    for name, example_func in examples:
        try:
            await example_func()
        except Exception as e:
            print(f"  ✗ Error: {e}")

    print("\n" + "=" * 70)
    print("All examples completed!")
    print("=" * 70 + "\n")

    print("Key Takeaways - Dependency Injection Pattern:")
    print("  1. Create and configure AsyncOpenAI client (auth handled separately)")
    print("  2. Inject into OpenAIChatCompletionClient at initialization")
    print("  3. Use same client for both single and streaming requests")
    print("  4. All errors unified through ModelClientError hierarchy")
    print("  5. Easy testing with mock clients - same interface as real")
    print("  6. Supports multiple environments with different configs")
    print()


if __name__ == "__main__":
    asyncio.run(main())
