# Agentbyte Codebase Guide for AI Agents

## Project Overview
**Agentbyte** is an **enterprise-ready** Python toolkit for designing scalable, production-grade multiagent systems. This project serves a dual purpose:

1. **Learning Journey:** Master advanced AI engineering concepts by studying [picoagents](../external_lib/designing-multiagent-systems/picoagents/) architecture, patterns, and design decisions
2. **Knowledge Application:** Build Agentbyte step-by-step based on personal knowledge and preferences, deepening expertise in multiagent systems
3. **Enterprise Library:** Create a production-ready library with multi-framework and multi-LLM support
4. **Cross-Framework Compatibility:** Enable seamless composition of agents from Agentbyte, [Microsoft Agent Framework](https://github.com/microsoft/agent-framework), and [Pydantic AI](https://ai.pydantic.dev/)

The development approach is iterative and intentional: understand a pattern from picoagents → implement it in Agentbyte with custom enhancements → validate with examples → move to next pattern. This methodology builds both library quality and deep AI engineering expertise.

## Learning & Implementation Goal

We will work **chapter-by-chapter** starting from **Chapter 4** in [docs/chapters](../docs/chapters/), studying each chapter, then **implementing the concepts ourselves** in Agentbyte. Chapters may be **skipped when not relevant** to the current implementation phase. Each chapter follows a **learn → implement → validate** loop, with examples used only as references (no direct copying). We will skip certain chapters and comeback to them later when relevant to the current implementation phase. The focus is on **deep understanding** and **intentional design**, not just code replication.

- Study plan should be created for chapters in [study](../docs/study/)
- When implementing tools (Chapter 4.6.4), follow the step-by-step guide in [docs/study/topic_tools.md](../docs/study/topic_tools.md). Use its file creation steps, class responsibilities, and parity checklist as the execution plan.

**Core Stack:**
- Python 3.13+
- [picoagents](../external_lib/designing-multiagent-systems/picoagents/) >= 0.2.3 (reference framework for learning agent orchestration patterns)
- [picoagents](../external_lib/designing-multiagent-systems/examples/) Example References mentioned in the book
- [pydantic](https://docs.pydantic.dev/) for data validation and settings management
- **LLM Providers:**
  - OpenAI API (GPT-4.1, GPT-5.1 series models)
  - AWS Bedrock (future integration)
- **Frameworks:**
  - Pydantic AI (integration in progress)
  - Microsoft Agent Framework (integration in progress)

## Supporting Books & Resources
- ** Books Reference Chapters: [Designing Multiagent Systems with LLMs](../docs/chapters/)

## Architecture

### Directory Structure & Naming Conventions

**Core Principle**: Agentbyte mirrors the [picoagents structure](../external_lib/designing-multiagent-systems/picoagents/src/picoagents/) to maintain consistency and reduce cognitive load when switching between frameworks.

**Picoagents Reference Structure**:
```
picoagents/
  messages.py           # Public: Message types (core types for all agents)
  types.py              # Public: Framework types (Usage, ChatCompletionResult, etc.)
  context.py            # Public: Agent context and state
  _base.py              # Private: Base classes for framework internals
  _component_config.py  # Private: Internal component configuration
  agents/
    _base.py            # Private: Abstract base classes
    _agent.py           # Implementation (could be public or private)
  llm/
    _base.py            # Private: Abstract base for LLM clients
    _openai.py          # Implementation (could be public or private)
    _azure_openai.py    # Implementation (could be public or private)
  tools/
    _base.py            # Private: Abstract base for tools
    _core_tools.py      # Implementation
```

**Agentbyte Implementation Rules**:

1. **Mirror the Package Structure**: Create same folder layout as picoagents (agents/, llm/, tools/, memory/, orchestration/, etc.)

2. **Naming Convention for Files**:
   - **Public modules** (no underscore): Used when you want to expose the module/class in `__init__.py`
     - Example: `llm/openai.py` → exported as `from agentbyte.llm import OpenAIChatCompletionClient`
   - **Private modules** (with underscore): Use `_` prefix ONLY when:
     - Module is internal/base only (e.g., `_base.py` for abstract classes)
     - Module should NEVER be imported directly by users
     - Module is implementation detail not part of public API
   - **Decision**: If a module's class is exported in `__init__.py`, it should NOT have underscore

3. **Location Rule for Core Types**:
   - **Top-level modules** (directly under agentbyte/):
     - `messages.py` - Message types (SystemMessage, UserMessage, AssistantMessage, ToolMessage)
     - `types.py` - Framework types (ToolResult, and other root-level types)
     - `context.py` - Agent context (when implemented)
   - **Package-specific types** (in subpackage):
     - `llm/types.py` - LLM-specific types (ChatCompletionResult, ChatCompletionChunk, Usage)
     - `tools/types.py` - Tool-specific types (if needed)
     - `agents/types.py` - Agent-specific types (if needed)

4. **Class Naming & Organization**:
   - Follow picoagents class hierarchy
   - Use picoagents field names and structures for message types
   - Document when custom enhancements differ from picoagents

** Picoagents is the reference architecture, but Agentbyte is not a copy—it's an implementation based on understanding picoagents patterns, with intentional design decisions for enterprise readiness and cross-framework compatibility. But should follow same module structure and naming conventions for consistency and ease of learning. Also picoagent use unnecessary _ to make a module private when it should be public and part of the API. Agentbyte should avoid this and only use _ for actual private/internal modules that are not part of the public API.

Picoagents Structure: `tree external_lib/designing-multiagent-systems/picoagents/src/picoagents`
```
external_lib/designing-multiagent-systems/picoagents/src/picoagents
├── __init__.py
├── _cancellation_token.py
├── _component_config.py
├── _middleware.py
├── _otel.py
├── agents
│   ├── __init__.py
│   ├── _agent.py
│   ├── _agent_as_tool.py
│   ├── _base.py
│   └── _computer_use
│       ├── __init__.py
│       ├── _computer_use.py
│       ├── _interface_clients.py
│       ├── _planning_models.py
│       └── _playwright_tools.py
├── cli
│   ├── __init__.py
│   └── _main.py
├── context.py
├── eval
│   ├── __init__.py
│   ├── _base.py
│   ├── _runner.py
│   ├── _targets.py
│   ├── examples
│   │   ├── __init__.py
│   │   └── basic_evaluation.py
│   └── judges
│       ├── __init__.py
│       ├── _base.py
│       ├── _composite.py
│       ├── _llm.py
│       └── _reference.py
├── llm
│   ├── __init__.py
│   ├── _anthropic.py
│   ├── _azure_openai.py
│   ├── _base.py
│   └── _openai.py
├── memory
│   ├── __init__.py
│   ├── _base.py
│   └── _chromadb.py
├── messages.py
├── orchestration
│   ├── __init__.py
│   ├── _ai.py
│   ├── _base.py
│   ├── _handoff.py
│   ├── _plan.py
│   └── _round_robin.py
├── termination
│   ├── __init__.py
│   ├── _base.py
│   ├── _cancellation.py
│   ├── _composite.py
│   ├── _external.py
│   ├── _function_call.py
│   ├── _handoff.py
│   ├── _max_message.py
│   ├── _text_mention.py
│   ├── _timeout.py
│   └── _token_usage.py
├── tools
│   ├── __init__.py
│   ├── _base.py
│   ├── _coding_tools.py
│   ├── _core_tools.py
│   ├── _decorator.py
│   ├── _mcp
│   │   ├── __init__.py
│   │   ├── _client.py
│   │   ├── _config.py
│   │   ├── _integration.py
│   │   ├── _tool.py
│   │   └── _transports.py
│   ├── _memory_tool.py
│   └── _research_tools.py
├── types.py
├── webui
│   ├── __init__.py
│   ├── _cli.py
│   ├── _discovery.py
│   ├── _execution.py
│   ├── _models.py
│   ├── _registry.py
│   ├── _server.py
│   ├── _session_store.py
│   ├── _sessions.py
│   ├── agent_framework_devui
│   │   └── ui
│   │       ├── assets
│   │       │   ├── index-BzhEszHZ.css
│   │       │   └── index-DByFJNGD.js
│   │       ├── index.html
│   │       └── vite.svg
│   ├── frontend
│   │   ├── README.md
│   │   ├── components.json
│   │   ├── eslint.config.js
│   │   ├── index.html
│   │   ├── package.json
│   │   ├── plan.md
│   │   ├── public
│   │   │   └── vite.svg
│   │   ├── src
│   │   │   ├── App.css
│   │   │   ├── App.tsx
│   │   │   ├── assets
│   │   │   │   └── react.svg
│   │   │   ├── components
│   │   │   │   ├── agent
│   │   │   │   │   └── agent-view.tsx
│   │   │   │   ├── message_renderer
│   │   │   │   │   ├── ContentRenderer.tsx
│   │   │   │   │   ├── MessageRenderer.tsx
│   │   │   │   │   ├── index.ts
│   │   │   │   │   └── types.ts
│   │   │   │   ├── mode-toggle.tsx
│   │   │   │   ├── orchestrator
│   │   │   │   │   └── orchestrator-view.tsx
│   │   │   │   ├── shared
│   │   │   │   │   ├── app-header.tsx
│   │   │   │   │   ├── chat-base.tsx
│   │   │   │   │   ├── context-inspector.tsx
│   │   │   │   │   ├── debug-panel.tsx
│   │   │   │   │   ├── entity-selector.tsx
│   │   │   │   │   ├── example-tasks-display.tsx
│   │   │   │   │   ├── examples-gallery.tsx
│   │   │   │   │   ├── session-switcher.tsx
│   │   │   │   │   └── tool-approval-banner.tsx
│   │   │   │   ├── theme-provider.tsx
│   │   │   │   ├── ui
│   │   │   │   │   ├── attachment-gallery.tsx
│   │   │   │   │   ├── badge.tsx
│   │   │   │   │   ├── button.tsx
│   │   │   │   │   ├── card.tsx
│   │   │   │   │   ├── dialog.tsx
│   │   │   │   │   ├── dropdown-menu.tsx
│   │   │   │   │   ├── file-upload.tsx
│   │   │   │   │   ├── input.tsx
│   │   │   │   │   ├── label.tsx
│   │   │   │   │   ├── loading-spinner.tsx
│   │   │   │   │   ├── loading-state.tsx
│   │   │   │   │   ├── message-input.tsx
│   │   │   │   │   ├── scroll-area.tsx
│   │   │   │   │   ├── slider.tsx
│   │   │   │   │   ├── tabs.tsx
│   │   │   │   │   └── textarea.tsx
│   │   │   │   └── workflow
│   │   │   │       └── workflow-view.tsx
│   │   │   ├── hooks
│   │   │   │   ├── messageHandlers.ts
│   │   │   │   └── useEntityExecution.ts
│   │   │   ├── index.css
│   │   │   ├── main.tsx
│   │   │   ├── services
│   │   │   │   └── api.ts
│   │   │   ├── types
│   │   │   │   ├── index.ts
│   │   │   │   └── picoagents.ts
│   │   │   ├── utils
│   │   │   │   └── message-utils.ts
│   │   │   └── vite-env.d.ts
│   │   ├── tsconfig.app.json
│   │   ├── tsconfig.json
│   │   ├── tsconfig.node.json
│   │   ├── vite.config.ts
│   │   └── yarn.lock
│   └── ui
│       ├── assets
│       │   ├── index-CWk64UM3.js
│       │   └── index-vt1cujlT.css
│       ├── index.html
│       └── vite.svg
└── workflow
    ├── __init__.py
    ├── core
    │   ├── __init__.py
    │   ├── _checkpoint.py
    │   ├── _models.py
    │   ├── _runner.py
    │   └── _workflow.py
    ├── defaults.py
    ├── schema_utils.py
    └── steps
        ├── __init__.py
        ├── _echo.py
        ├── _function.py
        ├── _http.py
        ├── _step.py
        ├── _transform.py
        └── picoagent.py
```

We should always stick on this folder structure and naming convention for consistency and ease of learning. The goal is to learn deeply and create a production-ready library, not just copy code.

**Current Agentbyte Structure** (should follow above):
```
src/agentbyte/
  __init__.py
  messages.py           # ✅ Message types (Message, SystemMessage, UserMessage, AssistantMessage, ToolMessage)
  types.py              # ✅ Core framework types (ToolResult, etc.)
  llm/
    __init__.py
    base.py             # Implementation of BaseChatCompletionClient
    openai.py           # OpenAIChatCompletionClient implementation
    azure_openai.py     # AzureOpenAIChatCompletionClient implementation
    auth.py             # Authentication utilities (agentbyte-specific)
    types.py            # LLM types (ChatCompletionResult, ChatCompletionChunk, Usage)
  agents/               # (Not yet implemented)
  tools/                # (Not yet implemented)
  settings/
  orchestration/        # (Not yet implemented)
```

**Key Difference from Picoagents**: Agentbyte does NOT use underscore prefix for base classes (base.py instead of _base.py, openai.py instead of _openai.py) since they ARE part of the public API and are exported in __init__.py.

---

## Types Organization Strategy

### ⚠️ Important: Avoid Picoagents' Monolithic Types Antipattern

**Problem with picoagents**: All types (504 lines) packed into single `types.py` module causes:
1. **Forward reference cascades**: Requires `model_rebuild()` calls at module end
2. **Circular import temptation**: Forces `if TYPE_CHECKING` imports
3. **Poor separation of concerns**: Everything mixed together (Usage, ToolResult, ChatCompletionResult, AgentResponse, 14 Event types, Evaluation types, etc.)
4. **Maintenance burden**: Hard to find and modify specific types
5. **Import overhead**: Importing one type pulls in entire 504-line module

**Agentbyte Solution**: Distribute types by module/domain—cleaner, fewer hacks needed.

### Type Placement Rules

**Root-level `types.py`** (fundamental framework types used everywhere):
- `ToolResult` - Used by tools module and potentially orchestration
- Future: `AgentResponse` scope TBD when agents module implemented
- Future: Global response enums/constants if any
- **Principle**: Only types that truly belong at framework root level

**`messages.py`** (at root level):
- All message types (SystemMessage, UserMessage, AssistantMessage, ToolMessage, MultiModalMessage, ToolCallRequest)
- **Usage** (moved here in Phase 1) ← Key decision to avoid forward references
- **Rationale**: Usage is message-adjacent metadata, not a separate domain type
- **Benefit**: Eliminates `model_rebuild()` calls and TYPE_CHECKING imports

**`llm/types.py`** (LLM-specific types):
- `ChatCompletionResult` - LLM API response
- `ChatCompletionChunk` - Streaming chunk
- `ModelClientError` - LLM error exception
- **Principle**: Only types specific to LLM request/response protocol

**`tools/core_tools.py`** (when implemented, tool-specific logic):
- Tool implementations (ThinkTool, CalculatorTool, etc.)
- Tool factory functions
- No separate types module for tools unless needed

**Future Modules** (when implemented):

`agents/types.py` (if needed):
- `AgentResponse` (potentially—scope TBD)
- Agent-specific types (not core framework types)

`orchestration/types.py` (if needed):
- `OrchestrationResponse`
- `StopMessage`
- Orchestration-specific types

`events.py` (if stream events become significant):
- Event hierarchy (BaseEvent, TaskStartEvent, ToolCallEvent, etc.)
- Separate from core types due to size (14+ event types in picoagents)

`evaluation/types.py` (if needed):
- `EvalTask`, `EvalTrajectory`, `EvalScore`, `EvalResult`
- Only when evaluation framework is built

### Anti-Patterns to Avoid

❌ **Don't**: Put all types in `types.py` (picoagents antipattern)
- Creates forward reference chains
- Requires `model_rebuild()` patches
- Bloats single module with unrelated types

❌ **Don't**: Use `if TYPE_CHECKING` to hide circular imports
- Defeats purpose of static type checking
- Hides dependency issues that should be architectural problems
- Requires runtime model rebuilding as workaround

❌ **Don't**: Create `tools/types.py` for single `ToolResult`
- Too granular; root `types.py` is appropriate for framework fundamentals
- `ToolResult` is as fundamental as Message types

✅ **Do**: Co-locate types with the modules that primarily use them
- `messages.py` has Usage (message metadata)
- `llm/types.py` has LLM response types
- `tools/base.py` imports ToolResult from root (fundamental type)

✅ **Do**: Use module-specific types files only for significant type groups
- When a module has 3+ cohesive types
- When types are rarely imported outside that module
- When keeping them separate reduces circular dependencies

### Current Agentbyte Type Organization

```
src/agentbyte/
  types.py                    # ✅ ToolResult (fundamental)
  messages.py                 # ✅ Message types + Usage (no hacks needed!)
  llm/
    types.py                  # ✅ ChatCompletionResult, ChatCompletionChunk
  tools/
    base.py                   # ✅ Imports ToolResult from agentbyte.types
    core_tools.py             # ✅ Implementations of tools
  # Future modules will follow same pattern
```

**Why this is better than picoagents**:
- No `model_rebuild()` calls anywhere
- No `if TYPE_CHECKING` conditional imports
- No forward reference strings ("Usage", "AssistantMessage")
- Direct imports throughout
- Clean separation by module concern
- Usage class logically placed with messages (its domain)

---

## Framework & Provider Compatibility Roadmap

### Current Phase: Foundation & OpenAI Integration
- Build core abstractions based on picoagents patterns
- Implement agentbyte abstractions for agent orchestration
- Full OpenAI GPT-4 and GPT-5 series model support
- Create reproducible examples and enterprise patterns
- Establish settings and configuration management for production deployments

### Phase 2: Pydantic AI Integration
- Integrate [Pydantic AI](https://ai.pydantic.dev/) for validation-heavy agent tasks
- Build adapters for transparent Pydantic AI agent composition
- Create examples showing specialized agent selection patterns
- Enable mixed Agentbyte + Pydantic AI deployments
- Reference: [https://ai.pydantic.dev/](https://ai.pydantic.dev/)

### Phase 3: Open Telemetry & Observability
- Integrate Open Telemetry for distributed tracing and monitoring

### Phase 4: Microsoft Agent Framework Integration
- Study [Microsoft Agent Framework](https://github.com/microsoft/agent-framework) agent model and orchestration patterns
- Create adapter layers for seamless interoperability
- Design shared abstractions for enterprise agent lifecycle management
- Enable mixed Agentbyte + Microsoft Agent Framework deployments
- Reference: [https://github.com/microsoft/agent-framework](https://github.com/microsoft/agent-framework)


### Phase 5: AWS Bedrock LLM Support
- Implement Bedrock client adapter for Claude, Llama, and other Bedrock models
- Build multi-LLM provider abstraction layer
- Create cost-optimization patterns (e.g., use cheaper models for simple tasks)
- Support cross-region and failover strategies
- Enable enterprises to avoid OpenAI lock-in

### Cross-Framework & Multi-LLM Composition Patterns
- **Design Goal:** Enterprise deployments mixing frameworks and LLM providers transparently
- **Approach:** 
  - Adapter interfaces normalize agent execution, tool invocation, and messaging
  - Provider abstraction enables seamless LLM switching without code changes
  - Orchestrators manage intelligent agent and provider selection
- **Enterprise Use Cases:**
  - Use Pydantic AI for strict validation tasks + Agentbyte for orchestration
  - Route tasks to specialized agents (e.g., Microsoft Agent Framework for Azure-native scenarios)
  - Switch LLM providers based on cost, latency, or capability requirements
  - Implement fallback chains: GPT-4 → Bedrock Claude → GPT-4-turbo
- **Implementation Pattern:** Adapters and orchestrators handle all framework/provider differences transparently

## What NOT to Do

- Don't copy code directly from picoagents—study it, understand it, then implement with your own understanding and enhancements
- Don't hard-code API keys or configuration—always use settings classes (enterprise requirement)
- Don't skip the learning phase to rush implementation—understanding patterns deeply is the goal
- Avoid notebook-only code; move reusable patterns into src/agentbyte/ (this is the actual library)
- Don't ignore cross-framework compatibility during design—keep Microsoft Agent Framework and Pydantic AI patterns in mind


## Conding Tips and Tricks
- When picking certain topics from certain sections of the book, first only focus on that section and not the whole chapter if not relevant to the current implementation phase

## Coding Rules:
- Try to create minimal tests with pytest and pytest async for testing any code. **AVOID heredoc blocks** (`uv run python3 << 'EOF'`) as they tend to hang/freeze in terminal output:
  - ✅ Good: `uv run python3 -c "from agentbyte.llm import X; print(X)"`
  - ✅ Good: `uv run pytest tests/test_file.py -v`
  - ❌ Bad: Multi-line heredoc blocks get stuck in terminal display
  - If complex testing needed, create a temporary test file instead
- Use settings classes for all configuration management, never hard-code values
- Our code is uv to have a packaged applciation which means we do not need to import from src but from agentbyte directly. For example, in our notebooks we should import from agentbyte like `from agentbyte.tools import FunctionTool` instead of `from src.agentbyte.tools import FunctionTool`
- Notebook already has a async main thread so do not use `asyncio.run()` in the notebooks, just call the async function directly like `await test_example1()`
- **Run ruff check after creating any code** to ensure code quality:
  - Check for unused imports: `uv run ruff check <file_or_dir> --select F401`
  - Run full checks: `uv run ruff check <file_or_dir>`
  - Auto-fix fixable issues: `uv run ruff check <file_or_dir> --fix`
  - This catches unused imports, style issues, and other code quality concerns early
## Success Criteria

✓ **Deep Understanding:** Can explain the "why" behind each pattern and design decision
✓ **Documented Code:** Each component has clear rationale for its design approach
✓ **Working Examples:** Practical demonstrations of each pattern from Agentbyte
✓ **Cross-Framework Ready:** Abstractions are designed to integrate with MS Agent Framework and Pydantic AI
✓ **Enterprise Quality:** Settings, error handling, and configuration management suitable for production
✓ **Iterative Growth:** Library grows step-by-step with learning, not all at once
