"""
OpenAI chat completion client implementation.

This module provides a concrete implementation of BaseChatCompletionClient
for OpenAI's GPT models (GPT-4, GPT-3.5-turbo, etc.).

Design Pattern:
    Follows the Three-Step Conversion Pattern:
    1. Convert Agentbyte Message types to OpenAI API format
    2. Make API call using the injected AsyncOpenAI client
    3. Convert OpenAI response back to unified ChatCompletionResult

Authentication:
    The OpenAI client is injected at initialization, enabling:
    - Different authentication methods (API keys, OAuth, etc.)
    - Custom configuration (proxies, timeouts, base URLs, etc.)
    - Multi-environment support with different credentials
    - Easy testing with mock clients
"""

import asyncio
import json
import logging
from collections.abc import AsyncGenerator
from typing import Any, Callable, Dict, List, Optional

from openai import AsyncOpenAI

from agentbyte.messages import AssistantMessage, Message, ToolCallRequest

from .base import (
    BaseChatCompletionClient,
    BaseChatCompletionClientConfig,
    RateLimitError,
    AuthenticationError,
    InvalidRequestError,
)
from .types import (
    ChatCompletionChunk,
    ChatCompletionResult,
    ModelClientError,
    Usage,
)

logger = logging.getLogger(__name__)


class OpenAIChatCompletionClientConfig(BaseChatCompletionClientConfig):
    """
    Configuration for OpenAIChatCompletionClient serialization.

    Captures all state needed to reconstruct an OpenAI client,
    enabling configuration file management and cross-environment deployment.

    Attributes:
        model: Model identifier (e.g., "gpt-4.1-mini", "gpt-4")
        config: Default configuration dict (temperature, max_tokens, etc.)
        max_retries: Maximum retry attempts for transient errors
        initial_retry_delay: Initial backoff delay in seconds
        max_retry_delay: Maximum backoff delay in seconds

    Note:
        API key and client configuration (base_url, organization, etc.)
        are managed by the user and not serialized here. This ensures
        credentials are never accidentally written to config files.
        Users reconstruct the AsyncOpenAI client and inject it at initialization.
    """
    max_retries: int = 3
    initial_retry_delay: float = 1.0
    max_retry_delay: float = 60.0


class OpenAIChatCompletionClient(BaseChatCompletionClient):
    """
    OpenAI chat completion client implementation.

    Supports GPT-4, GPT-4 Turbo, GPT-3.5-turbo, and other OpenAI models
    with streaming, function calling, and vision capabilities.

    Strict Dependency Injection Pattern:
        The user creates and fully configures AsyncOpenAI with:
        - Authentication (API key, custom base URL, organization, etc.)
        - Custom configuration (proxies, timeouts, etc.)
        
        Then injects the configured client here. This enforces:
        - Separation of concerns: User owns transport/auth, we own agent patterns
        - Enterprise flexibility: Support any authentication method
        - Testability: Mock clients can be injected for testing
        - No credential hardcoding: Credentials managed externally

    Minimal Wrapper:
        The wrapper only needs:
        - `model`: Model name to use in API calls
        - `client`: Pre-configured AsyncOpenAI
        - `config`: Default LLM parameters (temperature, max_tokens, etc.)
        - Retry logic: Exponential backoff for transient errors

    Features:
        - Automatic retry logic with exponential backoff for transient errors
        - Support for function calling / tool use
        - Streaming for real-time token delivery
        - Vision capabilities through OpenAI SDK

    Example:
        ```python
        from openai import AsyncOpenAI
        from agentbyte.llm import OpenAIChatCompletionClient, UserMessage

        # 1. User creates and configures OpenAI client
        openai_client = AsyncOpenAI(
            api_key="sk-...",
            organization="org-123"
        )

        # 2. Inject configured client into agentbyte wrapper
        llm = OpenAIChatCompletionClient(
            model="gpt-4.1-mini",
            client=openai_client,
            config={"temperature": 0.7, "max_tokens": 2000},
            max_retries=3,
            initial_retry_delay=1.0,
            max_retry_delay=60.0
        )

        # 3. Use it - with automatic retry on transient errors
        result = await llm.create(
            messages=[UserMessage(content="What is 2+2?")]
        )
        print(result.message.content)  # "2+2 equals 4"

        # Streaming with retry
        async for chunk in llm.create_stream(
            messages=[UserMessage(content="Write a haiku")]
        ):
            print(chunk.content, end="", flush=True)
        ```

    Attributes:
        model: The model identifier (e.g., "gpt-4.1-mini", "gpt-4", "gpt-3.5-turbo")
        client: Injected AsyncOpenAI HTTP client
        config: Default configuration dict (temperature, max_tokens, etc.)
        max_retries: Maximum number of retries for transient errors (default: 3)
        initial_retry_delay: Initial delay in seconds before first retry (default: 1.0)
        max_retry_delay: Maximum delay in seconds between retries (default: 60.0)
    """

    def __init__(
        self,
        model: str,
        client: AsyncOpenAI,
        config: Optional[Dict[str, Any]] = None,
        max_retries: int = 3,
        initial_retry_delay: float = 1.0,
        max_retry_delay: float = 60.0,
    ):
        """
        Initialize OpenAI client with pre-configured dependency.

        Args:
            model: Model name (e.g., "gpt-4.1-mini", "gpt-4", "gpt-3.5-turbo")
                   This is what gets passed as the `model` parameter to OpenAI API.
            
            client: Pre-configured AsyncOpenAI HTTP client (REQUIRED)
                   User must create this with their preferred authentication and config:
                   
                   Example with API Key:
                       >>> from openai import AsyncOpenAI
                       >>> openai_client = AsyncOpenAI(
                       ...     api_key="sk-...",
                       ...     organization="org-123"
                       ... )
                   
                   Example with Custom Base URL:
                       >>> openai_client = AsyncOpenAI(
                       ...     api_key="sk-...",
                       ...     base_url="https://api.openai.com/v1",
                       ...     organization="org-123"
                       ... )
            
            config: Default LLM configuration dict (optional)
                   Applied to all API calls, can be overridden per-call.
                   Example: {"temperature": 0.7, "max_tokens": 2000}
            
            max_retries: Maximum retry attempts for transient errors (default: 3)
            
            initial_retry_delay: Initial backoff delay in seconds (default: 1.0)
            
            max_retry_delay: Maximum backoff delay in seconds (default: 60.0)

        Example:
            >>> from openai import AsyncOpenAI
            >>> from agentbyte.llm import OpenAIChatCompletionClient, UserMessage
            >>> 
            >>> # 1. User creates and configures OpenAI client (handles auth/config)
            >>> openai_client = AsyncOpenAI(
            ...     api_key="sk-...",
            ...     organization="org-123"
            ... )
            >>> 
            >>> # 2. Inject configured client into agentbyte wrapper
            >>> llm = OpenAIChatCompletionClient(
            ...     model="gpt-4.1-mini",
            ...     client=openai_client,
            ...     config={"temperature": 0.7}
            ... )
            >>> 
            >>> # 3. Use it
            >>> result = await llm.create(
            ...     messages=[UserMessage(content="Hello")]
            ... )
        """
        super().__init__(model, client, config)
        self.max_retries = max_retries
        self.initial_retry_delay = initial_retry_delay
        self.max_retry_delay = max_retry_delay

    async def _retry_with_backoff(
        self, func: Callable[..., Any], *args: Any, **kwargs: Any
    ) -> Any:
        """
        Execute a function with exponential backoff retry logic.

        Retries on transient errors (RateLimitError, generic API errors).
        Does NOT retry on authentication or request validation errors.

        Args:
            func: Async function to execute
            *args: Positional arguments for the function
            **kwargs: Keyword arguments for the function

        Returns:
            Function result

        Raises:
            The original exception if all retries are exhausted or error is non-transient

        Implementation Notes:
            - RateLimitError: Always transient, always retried
            - ModelClientError: Transient, retried (e.g., temporary API issues)
            - AuthenticationError: Non-transient, never retried
            - InvalidRequestError: Non-transient, never retried
            - Uses exponential backoff: delay *= 2, capped at max_retry_delay
        """
        last_exception = None
        current_delay = self.initial_retry_delay

        for attempt in range(self.max_retries + 1):
            try:
                return await func(*args, **kwargs)
            except (RateLimitError, ModelClientError) as e:
                # RateLimitError and generic ModelClientError are transient
                last_exception = e

                if attempt >= self.max_retries:
                    logger.warning(
                        f"Max retries ({self.max_retries}) reached for {func.__name__}"
                    )
                    raise

                # Log retry attempt
                logger.debug(
                    f"Transient error in {func.__name__} (attempt {attempt + 1}/{self.max_retries + 1}): {str(e)}. "
                    f"Retrying in {current_delay:.1f}s"
                )

                # Wait before retry with exponential backoff
                await asyncio.sleep(current_delay)
                current_delay = min(current_delay * 2, self.max_retry_delay)

            except (AuthenticationError, InvalidRequestError) as e:
                # Non-transient errors: don't retry
                logger.error(f"Non-transient error in {func.__name__}: {str(e)}")
                raise

            except Exception as e:
                # Unknown errors: don't retry
                logger.error(f"Unexpected error in {func.__name__}: {str(e)}")
                raise

        # Should not reach here, but just in case
        raise last_exception or ModelClientError("Retry logic error")

    async def create(
        self,
        messages: List[Message],
        tools: Optional[List[Dict[str, Any]]] = None,
        output_format: Optional[type] = None,
        **kwargs: Any,
    ) -> ChatCompletionResult:
        """
        Make a single OpenAI API call.

        Follows the Three-Step Conversion Pattern:
        1. Convert Agentbyte messages to OpenAI format
        2. Call OpenAI API with the injected client
        3. Parse response and convert back to unified format

        Args:
            messages: Conversation history with Agentbyte Message types
            tools: Optional list of tool/function schemas for function calling
            output_format: Optional Pydantic model for structured output validation
                          The model will attempt to parse the response as JSON
                          and validate it against this schema
            **kwargs: OpenAI-specific parameters that override self.config
                     (temperature, max_tokens, top_p, frequency_penalty, etc.)

        Returns:
            ChatCompletionResult with:
            - message: AssistantMessage with content and optional tool_calls
            - usage: Token consumption statistics
            - model: Model used
            - metadata: Provider-specific data (finish_reason, etc.)
            - structured_output: Parsed output if output_format was provided (optional)

        Raises:
            RateLimitError: OpenAI rate limits exceeded
            AuthenticationError: Invalid API key or credentials
            InvalidRequestError: Request format is invalid
            ModelClientError: Other API errors

        Implementation Notes:
            - Merges self.config with kwargs (kwargs takes precedence)
            - Handles tool calls in response and creates ToolCall objects
            - Extracts usage statistics for cost tracking
            - Automatically retries transient errors with exponential backoff
            - Structured output uses OpenAI Structured Outputs API (requires compatible model)
            - If structured output parsing fails, continues with text response
        """
        try:
            # Delegate to retry wrapper
            return await self._retry_with_backoff(
                self._create_internal, messages, tools, output_format, **kwargs
            )

        except Exception as e:
            # Convert OpenAI exceptions to unified error hierarchy
            self._handle_error(e)

    async def _create_internal(
        self,
        messages: List[Message],
        tools: Optional[List[Dict[str, Any]]] = None,
        output_format: Optional[type] = None,
        **kwargs: Any,
    ) -> ChatCompletionResult:
        """
        Internal create implementation (handles API call, gets retried by wrapper).

        This is the actual API call that gets wrapped by retry logic.

        Args:
            messages: Conversation history
            tools: Optional tool definitions
            output_format: Optional Pydantic model for structured output
            **kwargs: Additional OpenAI parameters

        Returns:
            ChatCompletionResult

        Raises:
        """
        # Merge configuration: base config + request-specific kwargs
        api_kwargs = {**self.config, **kwargs}

        # Step 1: Convert internal Message types to OpenAI format
        api_messages = self._convert_messages_to_api_format(messages)

        # Handle structured output if requested
        structured_output = None
        if output_format:
            try:
                # Convert Pydantic model to JSON schema for OpenAI
                schema = output_format.model_json_schema()
                
                # Ensure OpenAI Structured Outputs compatibility
                schema = self._make_schema_compatible(schema)
                
                # Add response_format to request
                api_kwargs["response_format"] = {
                    "type": "json_schema",
                    "json_schema": {
                        "name": schema.get("title", output_format.__name__),
                        "description": schema.get(
                            "description",
                            f"Structured output for {output_format.__name__}",
                        ),
                        "strict": True,
                        "schema": schema,
                    },
                }
            except Exception as e:
                # If schema conversion fails, log warning but continue
                logger.warning(
                    f"Failed to convert {output_format.__name__} to JSON schema: {e}. "
                    f"Continuing without structured output."
                )

        # Step 2: Make API call using the injected client
        response = await self.client.chat.completions.create(
            model=self.model,
            messages=api_messages,
            tools=tools,
            **api_kwargs,
        )

        # Step 3: Parse response and convert to unified format
        choice = response.choices[0]
        message_content = choice.message.content or ""

        # Handle tool calls if present
        tool_calls = None
        if choice.message.tool_calls:
            tool_calls = [
                ToolCallRequest(
                    call_id=tc.id,
                    tool_name=tc.function.name,
                    parameters=json.loads(tc.function.arguments),
                )
                for tc in choice.message.tool_calls
            ]

        # Parse structured output if requested
        if output_format and message_content:
            try:
                structured_output = output_format.model_validate_json(message_content)
            except Exception as e:
                logger.warning(
                    f"Failed to parse structured output: {e}. Using raw content."
                )
                structured_output = None

        return ChatCompletionResult(
            message=AssistantMessage(
                content=message_content,
                source=self.model,
                tool_calls=tool_calls,
            ),
            usage=Usage(
                tokens_input=response.usage.prompt_tokens,
                tokens_output=response.usage.completion_tokens,
                cost_estimate=self._estimate_cost(
                    response.usage.prompt_tokens,
                    response.usage.completion_tokens,
                )
            ),
            model=response.model,
            metadata={
                "finish_reason": choice.finish_reason,
            },
            structured_output=structured_output,
        )


    async def create_stream(
        self,
        messages: List[Message],
        tools: Optional[List[Dict[str, Any]]] = None,
        output_format: Optional[type] = None,
        **kwargs: Any,
    ) -> AsyncGenerator[ChatCompletionChunk, None]:
        """
        Make a streaming OpenAI API call.

        Yields response chunks as they arrive from the API, enabling real-time
        updates and reduced time-to-first-token perception.

        Args:
            messages: Conversation history with Agentbyte Message types
            output_format: Optional Pydantic model for structured output
                          Note: Structured output is not fully supported in streaming
                          (OpenAI API limitation). Parameter accepted for API consistency.
            **kwargs: OpenAI-specific parameters that override self.config

        Yields:
            ChatCompletionChunk with:
            - content: Partial text content from this chunk
            - model: Model name
            - metadata: Provider-specific data (finish_reason for final chunk)

        Raises:
            Same exception hierarchy as create()

        Implementation Notes:
            - Enables stream=True on OpenAI API call
            - Yields chunks as they arrive
            - Final chunk may have empty content but includes finish_reason
            - Accumulate chunks by concatenating .content for full response
            - Includes retry logic for transient errors (rate limits, API errors)
            - Note: Entire stream is retried as a unit if transient error occurs
            - Structured output not supported in streaming (OpenAI limitation)
        """
        try:
            # Delegate to retry wrapper for streaming
            async for chunk in await self._retry_with_backoff(
                self._create_stream_internal, messages, tools, output_format, **kwargs
            ):
                yield chunk

        except Exception as e:
            # Convert exceptions to unified error hierarchy
            self._handle_error(e)

        except Exception as e:
            # Convert exceptions to unified error hierarchy
            self._handle_error(e)

    async def _create_stream_internal(
        self,
        messages: List[Message],
        tools: Optional[List[Dict[str, Any]]] = None,
        output_format: Optional[type] = None,
        **kwargs: Any,
    ) -> AsyncGenerator[ChatCompletionChunk, None]:
        """
        Internal streaming implementation (handles API call, gets retried by wrapper).
        This is the actual streaming API call that gets wrapped by retry logic.

        Args:
            messages: Conversation history
            tools: Optional tool definitions
            output_format: Optional Pydantic model (not used in streaming, for API consistency)
            **kwargs: Additional OpenAI parameters

        Yields:
            ChatCompletionChunk objects

        Raises:
            OpenAI exceptions (converted by caller)

        Note:
            Structured output (output_format) is not used here because OpenAI's
            streaming API does not support structured output. For structured responses,
            use create() instead.
        """
        # Merge configuration
        api_kwargs = {**self.config, **kwargs}

        # Convert messages to OpenAI format
        api_messages = self._convert_messages_to_api_format(messages)

        # Make streaming API call
        async with await self.client.chat.completions.create(
            model=self.model,
            messages=api_messages,
            tools=tools,
            stream=True,  # Enable streaming
            **api_kwargs,
        ) as response:
            # Yield chunks as they arrive
            async for chunk in response:
                # Skip chunks without choices (e.g., ping/empty chunks)
                if not chunk.choices:
                    continue
                
                # Extract content (may be None or empty string)
                content = chunk.choices[0].delta.content or ""

                yield ChatCompletionChunk(
                    content=content,
                    model=chunk.model,
                    metadata={
                        "finish_reason": chunk.choices[0].finish_reason,
                    },
                )

    def _make_schema_compatible(self, schema: Dict[str, Any]) -> Dict[str, Any]:
        """
        Modify JSON schema to be compatible with OpenAI Structured Outputs.

        OpenAI's Structured Outputs require certain schema constraints:
        - Object types must have additionalProperties=False
        - All properties must be defined in the schema
        - Schemas must be strict and unambiguous

        Args:
            schema: The JSON schema to make compatible

        Returns:
            Modified schema with OpenAI compatibility fixes
        """
        # Make a copy to avoid modifying the original
        compatible_schema = schema.copy()

        # Ensure additionalProperties is False (required by OpenAI)
        if compatible_schema.get("type") == "object":
            compatible_schema["additionalProperties"] = False

            # Recursively apply to nested objects
            properties = compatible_schema.get("properties", {})
            for prop_name, prop_schema in properties.items():
                if isinstance(prop_schema, dict):
                    compatible_schema["properties"][prop_name] = self._make_schema_compatible(prop_schema)

        # Handle arrays with object items
        if compatible_schema.get("type") == "array":
            items = compatible_schema.get("items")
            if isinstance(items, dict):
                compatible_schema["items"] = self._make_schema_compatible(items)

        return compatible_schema

    def _estimate_cost(self, prompt_tokens: int, completion_tokens: int) -> float:
        """
        Estimate the cost of the API call based on token usage.

        Uses current OpenAI pricing for different model families.
        Note: These are approximate rates and may not reflect real-time changes.

        Args:
            prompt_tokens: Number of tokens in the prompt
            completion_tokens: Number of tokens generated

        Returns:
            Estimated cost in USD

        Model Pricing (as of 2024):
            - GPT-4.1 mini: $0.15 per 1M input tokens, $0.60 per 1M output tokens
            - GPT-4: $0.03 per 1K input tokens, $0.06 per 1K output tokens
            - GPT-4 Turbo: $0.01 per 1K input tokens, $0.03 per 1K output tokens
            - GPT-3.5 Turbo: $0.50 per 1M input tokens, $1.50 per 1M output tokens
            - Falls back to GPT-4 pricing for unknown models
        """
        # Model pricing mapping (per 1M tokens)
        pricing = {
            "gpt-4.1-mini": {"input_per_1m": 0.15, "output_per_1m": 0.60},
            "gpt-4.1-nano": {"input_per_1m": 0.10, "output_per_1m": 0.40},
            "gpt-4.1": {"input_per_1m": 0.40, "output_per_1m": 1.60},
            "gpt-4o-mini": {"input_per_1m": 0.15, "output_per_1m": 0.60},
            "gpt-4": {"input_per_1m": 30.0, "output_per_1m": 60.0},  # $0.03/$0.06 per 1K
            "gpt-4-turbo": {"input_per_1m": 10.0, "output_per_1m": 30.0},  # $0.01/$0.03 per 1K
            "gpt-3.5-turbo": {"input_per_1m": 0.50, "output_per_1m": 1.50},
            "gpt-5": {"input_per_1m": 2.50, "output_per_1m": 20.00},
            "gpt-5-mini": {"input_per_1m": 0.25, "output_per_1m": 2.00},
            "gpt-5.1": {"input_per_1m": 1.25, "output_per_1m": 10.00},
            "gpt-5.2": {"input_per_1m": 1.75, "output_per_1m": 7.00},
            "gpt-5.2-mini": {"input_per_1m": 0.45, "output_per_1m": 3.60}
        }


        # Find matching pricing; try to match model name prefix
        model_pricing = None
        for model_key, pricing_data in pricing.items():
            if self.model.startswith(model_key):
                model_pricing = pricing_data
                break

        # Default to GPT-4 pricing if no match found
        if not model_pricing:
            model_pricing = pricing["gpt-4"]

        # Calculate cost in USD
        input_cost = (prompt_tokens / 1_000_000) * model_pricing["input_per_1m"]
        output_cost = (completion_tokens / 1_000_000) * model_pricing["output_per_1m"]

        return round(input_cost + output_cost, 6)

    def _to_config(self) -> OpenAIChatCompletionClientConfig:
        """
        Convert client to configuration for serialization.

        Extracts settings that define this client's behavior, enabling
        configuration file storage and cross-environment deployment.

        Returns:
            Configuration object with all necessary state

        Note:
            API key and client configuration are NOT serialized (credentials
            are managed externally). Users reconstruct AsyncOpenAI with their
            authentication method and inject it when creating a new client.
        """
        return OpenAIChatCompletionClientConfig(
            model=self.model,
            config=self.config.copy(),
            max_retries=self.max_retries,
            initial_retry_delay=self.initial_retry_delay,
            max_retry_delay=self.max_retry_delay,
        )

    @classmethod
    def _from_config(cls, config: OpenAIChatCompletionClientConfig) -> "OpenAIChatCompletionClient":
        """
        Create client from configuration.

        Reconstructs a client from saved configuration, but requires the user
        to provide an authenticated AsyncOpenAI client.

        Args:
            config: Client configuration with model, retry settings, etc.

        Returns:
            Partially configured OpenAIChatCompletionClient (still needs client injection)

        Example:
            >>> # In config file:
            >>> config_json = '''
            >>> {
            ...   "model": "gpt-4.1-mini",
            ...   "config": {"temperature": 0.7},
            ...   "max_retries": 3
            ... }
            >>> '''
            >>> 
            >>> # At runtime:
            >>> config = OpenAIChatCompletionClientConfig.model_validate_json(config_json)
            >>> 
            >>> # User creates authenticated client
            >>> from openai import AsyncOpenAI
            >>> openai_client = AsyncOpenAI(api_key="sk-...")
            >>> 
            >>> # Reconstruct agentbyte client
            >>> llm = OpenAIChatCompletionClient._from_config(config)
            >>> llm.client = openai_client  # Inject authentication
        """
        # Create instance with placeholder client (user will inject real one)
        return cls(
            model=config.model,
            client=None,  # type: ignore  # Will be set by user
            config=config.config,
            max_retries=config.max_retries,
            initial_retry_delay=config.initial_retry_delay,
            max_retry_delay=config.max_retry_delay,
        )

    def _handle_error(self, error: Exception) -> None:
        """
        Convert OpenAI-specific exceptions to unified error hierarchy.

        Maps OpenAI exceptions to agentbyte error types for consistent
        error handling across providers.

        Args:
            error: Exception raised by OpenAI API

        Raises:
            RateLimitError: API rate limits exceeded
            AuthenticationError: Authentication failed
            InvalidRequestError: Request format is invalid
            ModelClientError: Other API errors
        """
        # Import here to avoid circular imports and handle optional dependency
        try:
            from openai import (
                RateLimitError as OpenAIRateLimitError,
                AuthenticationError as OpenAIAuthenticationError,
                BadRequestError,
                APIError,
            )
        except ImportError:
            # If openai not installed, convert to generic ModelClientError
            raise ModelClientError(f"OpenAI error: {str(error)}") from error

        error_msg = str(error)
        error_type = type(error).__name__

        if isinstance(error, OpenAIRateLimitError):
            raise RateLimitError(f"OpenAI rate limit exceeded: {error_msg}") from error

        elif isinstance(error, OpenAIAuthenticationError):
            raise AuthenticationError(
                f"OpenAI authentication failed: {error_msg}"
            ) from error

        elif isinstance(error, BadRequestError):
            raise InvalidRequestError(
                f"OpenAI request invalid: {error_msg}"
            ) from error

        elif isinstance(error, APIError):
            # Generic API error - try to extract more details
            raise ModelClientError(
                f"OpenAI API error ({error_type}): {error_msg}"
            ) from error

        else:
            # Unknown error type
            raise ModelClientError(
                f"Unexpected error from OpenAI ({error_type}): {error_msg}"
            ) from error


__all__ = ["OpenAIChatCompletionClient", "OpenAIChatCompletionClientConfig"]
