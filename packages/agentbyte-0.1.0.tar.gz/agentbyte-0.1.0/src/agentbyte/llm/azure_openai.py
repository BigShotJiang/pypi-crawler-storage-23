"""
Azure OpenAI chat completion client implementation.

This module provides a concrete implementation of BaseChatCompletionClient
for Azure OpenAI's GPT models (GPT-4, GPT-3.5-turbo, etc.) deployed on Azure.

Design Pattern:
    Follows the Three-Step Conversion Pattern:
    1. Convert Agentbyte Message types to Azure OpenAI API format
    2. Make API call using the injected AsyncAzureOpenAI client
    3. Convert Azure OpenAI response back to unified ChatCompletionResult

Dependency Injection Pattern:
    User is responsible for:
    - Creating AsyncAzureOpenAI with authentication (API key, credential chain, etc.)
    - Configuring Azure endpoint, API version, deployment
    - Passing the fully-configured client to this wrapper

    This wrapper only needs:
    - `model`: Deployment name for API calls
    - `client`: The configured AsyncAzureOpenAI
    - `config`: Default LLM parameters
    - Retry logic: Transient error handling

Authentication Examples:
    Pattern 1 - API Key:
        >>> from openai import AsyncAzureOpenAI
        >>> azure_client = AsyncAzureOpenAI(
        ...     api_key="your-key",
        ...     azure_endpoint="https://myresource.openai.azure.com/",
        ...     api_version="2024-10-21",
        ...     azure_deployment="gpt-4-prod"
        ... )
        >>> llm = AzureOpenAIChatCompletionClient(
        ...     model="gpt-4-prod",
        ...     client=azure_client,
        ...     config={"temperature": 0.7}
        ... )

    Pattern 2 - DefaultAzureCredential (managed identity, CLI, environment):
        >>> from openai import AsyncAzureOpenAI
        >>> from azure.identity import DefaultAzureCredential, get_bearer_token_provider
        >>> token_provider = get_bearer_token_provider(
        ...     DefaultAzureCredential(),
        ...     "https://cognitiveservices.azure.com/.default"
        ... )
        >>> azure_client = AsyncAzureOpenAI(
        ...     azure_ad_token_provider=token_provider,
        ...     azure_endpoint="https://myresource.openai.azure.com/",
        ...     api_version="2024-10-21",
        ...     azure_deployment="gpt-4-prod"
        ... )
        >>> llm = AzureOpenAIChatCompletionClient(
        ...     model="gpt-4-prod",
        ...     client=azure_client
        ... )

    Pattern 3 - Certificate-based authentication
        >>> # Implementation deferred to Phase 2
        >>> # Users construct AsyncAzureOpenAI with certificate credentials
        >>> # from app settings
"""

import asyncio
import json
import logging
from collections.abc import AsyncGenerator
from typing import Any, Callable, Dict, List, Optional, TypeVar

from openai import AsyncAzureOpenAI

from agentbyte.messages import AssistantMessage, Message, ToolCallRequest

from .base import (
    BaseChatCompletionClient,
    BaseChatCompletionClientConfig,
    RateLimitError,
    AuthenticationError,
    InvalidRequestError,
)
from .types import (
    ChatCompletionChunk,
    ChatCompletionResult,
    ModelClientError,
    Usage,
)

logger = logging.getLogger(__name__)

T = TypeVar("T")


class AzureOpenAIChatCompletionClientConfig(BaseChatCompletionClientConfig):
    """
    Configuration for AzureOpenAIChatCompletionClient serialization.

    Captures settings needed to reconstruct an Azure OpenAI client,
    enabling configuration file management and cross-environment deployment.

    Attributes:
        model: Deployment name (e.g., "gpt-4-prod", "gpt-35-turbo-dev")
        config: Default configuration dict (temperature, max_tokens, etc.)
        max_retries: Maximum retry attempts for transient errors
        initial_retry_delay: Initial backoff delay in seconds
        max_retry_delay: Maximum backoff delay in seconds

    Note:
        API key, Azure endpoint, and API version are managed by the user
        and not serialized here. Users reconstruct the AsyncAzureOpenAI client
        with their authentication method (API key, credential chain, etc.)
        and inject it at initialization.
    """
    max_retries: int = 3
    initial_retry_delay: float = 1.0
    max_retry_delay: float = 60.0


class AzureOpenAIChatCompletionClient(BaseChatCompletionClient):
    """
    Azure OpenAI chat completion client implementation.

    Supports Azure-deployed GPT-4, GPT-4 Turbo, GPT-3.5-turbo, and other OpenAI models
    with streaming, function calling, and vision capabilities.

    Strict Dependency Injection Pattern:
        The user creates and fully configures AsyncAzureOpenAI with:
        - Authentication (API key, DefaultAzureCredential, certificates, etc.)
        - Azure endpoint URL
        - API version
        - Any other OpenAI SDK configuration (proxies, timeouts, etc.)
        
        Then injects the configured client here. This enforces:
        - Separation of concerns: User owns transport/auth, we own agent patterns
        - Enterprise flexibility: Support any authentication method
        - Testability: Mock clients can be injected for testing
        - No credential hardcoding: Credentials managed externally

    Minimal Wrapper:
        The wrapper only needs:
        - `model`: Deployment name to use in API calls
        - `client`: Pre-configured AsyncAzureOpenAI
        - `config`: Default LLM parameters (temperature, max_tokens, etc.)
        - Retry logic: Exponential backoff for transient errors

    Features:
        - Automatic retry logic with exponential backoff for transient errors
        - Support for function calling / tool use
        - Streaming for real-time token delivery
        - Vision capabilities through OpenAI SDK
    """

    def __init__(
        self,
        model: str,
        client: AsyncAzureOpenAI,
        config: Optional[Dict[str, Any]] = None,
        max_retries: int = 3,
        initial_retry_delay: float = 1.0,
        max_retry_delay: float = 60.0,
    ):
        """
        Initialize Azure OpenAI client with pre-configured dependency.

        Args:
            model: Deployment name to use in API calls
                   This is what gets passed as the `model` parameter to Azure OpenAI API.
                   Example: "gpt-4-prod"
            
            client: Pre-configured AsyncAzureOpenAI HTTP client (REQUIRED)
                   User must create this with their preferred authentication and Azure config:
                   
                   Example with API Key:
                       >>> from openai import AsyncAzureOpenAI
                       >>> azure_client = AsyncAzureOpenAI(
                       ...     api_key="your-key",
                       ...     azure_endpoint="https://myresource.openai.azure.com/",
                       ...     api_version="2024-10-21",
                       ...     azure_deployment="gpt-4-prod"
                       ... )
                   
                   Example with DefaultAzureCredential:
                       >>> from azure.identity import DefaultAzureCredential, get_bearer_token_provider
                       >>> token_provider = get_bearer_token_provider(
                       ...     DefaultAzureCredential(),
                       ...     "https://cognitiveservices.azure.com/.default"
                       ... )
                       >>> azure_client = AsyncAzureOpenAI(
                       ...     azure_ad_token_provider=token_provider,
                       ...     azure_endpoint="https://myresource.openai.azure.com/",
                       ...     api_version="2024-10-21",
                       ...     azure_deployment="gpt-4-prod"
                       ... )
            
            config: Default LLM configuration dict (optional)
                   Applied to all API calls, can be overridden per-call.
                   Example: {"temperature": 0.7, "max_tokens": 2000}
            
            max_retries: Maximum retry attempts for transient errors (default: 3)
            
            initial_retry_delay: Initial backoff delay in seconds (default: 1.0)
            
            max_retry_delay: Maximum backoff delay in seconds (default: 60.0)

        Example:
            >>> from openai import AsyncAzureOpenAI
            >>> from agentbyte.llm import AzureOpenAIChatCompletionClient, UserMessage
            >>> 
            >>> # 1. User creates and configures Azure client (handles all auth/endpoint config)
            >>> azure_client = AsyncAzureOpenAI(
            ...     api_key="your-key",
            ...     azure_endpoint="https://myresource.openai.azure.com/",
            ...     api_version="2024-10-21",
            ...     azure_deployment="gpt-4-prod"
            ... )
            >>> 
            >>> # 2. Inject configured client into agentbyte wrapper
            >>> llm = AzureOpenAIChatCompletionClient(
            ...     model="gpt-4-prod",  # Deployment name for API calls
            ...     client=azure_client,  # Pre-configured with endpoint, auth, version
            ...     config={"temperature": 0.7}
            ... )
            >>> 
            >>> # 3. Use it
            >>> result = await llm.create(
            ...     messages=[UserMessage(content="Hello")]
            ... )
        """
        super().__init__(model, client, config)

        self.max_retries = max_retries
        self.initial_retry_delay = initial_retry_delay
        self.max_retry_delay = max_retry_delay

    async def _retry_with_backoff(
        self, func: Callable[..., Any], *args: Any, **kwargs: Any
    ) -> Any:
        """
        Execute a function with exponential backoff retry logic.

        Retries on transient errors (RateLimitError, generic API errors).
        Does NOT retry on authentication or request validation errors.

        Args:
            func: Async function to execute
            *args: Positional arguments for the function
            **kwargs: Keyword arguments for the function

        Returns:
            Function result

        Raises:
            The original exception if all retries are exhausted or error is non-transient

        Implementation Notes:
            - RateLimitError: Always transient, always retried
            - ModelClientError: Transient, retried (e.g., temporary API issues)
            - AuthenticationError: Non-transient, never retried
            - InvalidRequestError: Non-transient, never retried
            - Uses exponential backoff: delay *= 2, capped at max_retry_delay
        """
        last_exception = None
        current_delay = self.initial_retry_delay

        for attempt in range(self.max_retries + 1):
            try:
                return await func(*args, **kwargs)
            except (RateLimitError, ModelClientError) as e:
                # RateLimitError and generic ModelClientError are transient
                last_exception = e

                if attempt >= self.max_retries:
                    logger.warning(
                        f"Max retries ({self.max_retries}) reached for {func.__name__}"
                    )
                    raise

                # Log retry attempt
                logger.debug(
                    f"Transient error in {func.__name__} (attempt {attempt + 1}/{self.max_retries + 1}): {str(e)}. "
                    f"Retrying in {current_delay:.1f}s"
                )

                # Wait before retry with exponential backoff
                await asyncio.sleep(current_delay)
                current_delay = min(current_delay * 2, self.max_retry_delay)

            except (AuthenticationError, InvalidRequestError) as e:
                # Non-transient errors: don't retry
                logger.error(f"Non-transient error in {func.__name__}: {str(e)}")
                raise

            except Exception as e:
                # Unknown errors: don't retry
                logger.error(f"Unexpected error in {func.__name__}: {str(e)}")
                raise

        # Should not reach here, but just in case
        raise last_exception or ModelClientError("Retry logic error")

    async def create(
        self,
        messages: List[Message],
        tools: Optional[List[Dict[str, Any]]] = None,
        output_format: Optional[type] = None,
        **kwargs: Any,
    ) -> ChatCompletionResult:
        """
        Make a single Azure OpenAI API call.

        Follows the Three-Step Conversion Pattern:
        1. Convert Agentbyte messages to Azure OpenAI format
        2. Call Azure OpenAI API with the injected client
        3. Parse response and convert back to unified format

        Args:
            messages: Conversation history with Agentbyte Message types
            tools: Optional list of tool/function schemas for function calling
            output_format: Optional Pydantic model for structured output validation
                          The model will attempt to parse the response as JSON
                          and validate it against this schema
            **kwargs: Azure OpenAI-specific parameters that override self.config
                     (temperature, max_tokens, top_p, frequency_penalty, etc.)

        Returns:
            ChatCompletionResult with:
            - message: AssistantMessage with content and optional tool_calls
            - usage: Token consumption statistics
            - model: Model used
            - metadata: Provider-specific data (finish_reason, etc.)
            - structured_output: Parsed output if output_format was provided (optional)

        Raises:
            RateLimitError: Azure OpenAI rate limits exceeded
            AuthenticationError: Invalid API key or credentials
            InvalidRequestError: Request format is invalid
            ModelClientError: Other API errors

        Implementation Notes:
            - Merges self.config with kwargs (kwargs takes precedence)
            - Handles tool calls in response and creates ToolCall objects
            - Extracts usage statistics for cost tracking
            - Automatically retries transient errors with exponential backoff
            - Structured output uses Azure OpenAI Structured Outputs API
            - If structured output parsing fails, continues with text response
        """
        try:
            # Delegate to retry wrapper
            return await self._retry_with_backoff(
                self._create_internal, messages, tools, output_format, **kwargs
            )

        except Exception as e:
            # Convert Azure OpenAI exceptions to unified error hierarchy
            self._handle_error(e)

    async def _create_internal(
        self,
        messages: List[Message],
        tools: Optional[List[Dict[str, Any]]] = None,
        output_format: Optional[type] = None,
        **kwargs: Any,
    ) -> ChatCompletionResult:
        """
        Internal create implementation (handles API call, gets retried by wrapper).

        This is the actual API call that gets wrapped by retry logic.

        Args:
            messages: Conversation history
            tools: Optional tool definitions
            output_format: Optional Pydantic model for structured output
            **kwargs: Additional Azure OpenAI parameters

        Returns:
            ChatCompletionResult

        Raises:
            Azure OpenAI exceptions (converted by caller)
        """
        # Merge configuration: base config + request-specific kwargs
        api_kwargs = {**self.config, **kwargs}

        # Step 1: Convert internal Message types to Azure OpenAI format
        api_messages = self._convert_messages_to_api_format(messages)

        # Handle structured output if requested
        structured_output = None
        if output_format:
            try:
                # Convert Pydantic model to JSON schema for Azure OpenAI
                schema = output_format.model_json_schema()
                
                # Ensure Azure OpenAI Structured Outputs compatibility
                schema = self._make_schema_compatible(schema)
                
                # Add response_format to request
                api_kwargs["response_format"] = {
                    "type": "json_schema",
                    "json_schema": {
                        "name": schema.get("title", output_format.__name__),
                        "description": schema.get(
                            "description",
                            f"Structured output for {output_format.__name__}",
                        ),
                        "strict": True,
                        "schema": schema,
                    },
                }
            except Exception as e:
                # If schema conversion fails, log warning but continue
                logger.warning(
                    f"Failed to convert {output_format.__name__} to JSON schema: {e}. "
                    f"Continuing without structured output."
                )

        # Step 2: Make API call using the injected client
        # Pass model (which is the deployment name)
        response = await self.client.chat.completions.create(
            model=self.model,
            messages=api_messages,
            tools=tools,
            **api_kwargs,
        )

        # Step 3: Parse response and convert to unified format
        choice = response.choices[0]
        message_content = choice.message.content or ""

        # Handle tool calls if present
        tool_calls = None
        if choice.message.tool_calls:
            tool_calls = [
                ToolCallRequest(
                    call_id=tc.id,
                    tool_name=tc.function.name,
                    parameters=json.loads(tc.function.arguments),
                )
                for tc in choice.message.tool_calls
            ]

        # Parse structured output if requested
        if output_format and message_content:
            try:
                structured_output = output_format.model_validate_json(message_content)
            except Exception as e:
                logger.warning(
                    f"Failed to parse structured output: {e}. Using raw content."
                )
                structured_output = None

        return ChatCompletionResult(
            message=AssistantMessage(
                content=message_content,
                source=self.model,
                tool_calls=tool_calls,
            ),
            usage=Usage(
                tokens_input=response.usage.prompt_tokens,
                tokens_output=response.usage.completion_tokens,
                cost_estimate=self._estimate_cost(
                    response.usage.prompt_tokens,
                    response.usage.completion_tokens,
                )
            ),
            model=response.model,
            metadata={
                "finish_reason": choice.finish_reason,
            },
            structured_output=structured_output,
        )

    async def create_stream(
        self,
        messages: List[Message],
        tools: Optional[List[Dict[str, Any]]] = None,
        output_format: Optional[type] = None,
        **kwargs: Any,
    ) -> AsyncGenerator[ChatCompletionChunk, None]:
        """
        Make a streaming Azure OpenAI API call.

        Yields response chunks as they arrive from the API, enabling real-time
        updates and reduced time-to-first-token perception.

        Args:
            messages: Conversation history with Agentbyte Message types
            tools: Optional list of tool/function schemas
            **kwargs: Azure OpenAI-specific parameters that override self.config

        Yields:
            ChatCompletionChunk with:
            - content: Partial text content from this chunk
            - model: Model name
            - metadata: Provider-specific data (finish_reason for final chunk)

        Raises:
            Same exception hierarchy as create()

        Implementation Notes:
            - Enables stream=True on Azure OpenAI API call
            - Yields chunks as they arrive
            - Final chunk may have empty content but includes finish_reason
            - Accumulate chunks by concatenating .content for full response
            - Includes retry logic for transient errors (rate limits, API errors)
            - Note: Entire stream is retried as a unit if transient error occurs
            - Structured output not supported in streaming (Azure limitation)
        """
        try:
            # For streaming, call the internal method directly without await
            # since it's an async generator, not a regular async function
            async for chunk in self._create_stream_internal(messages, tools, output_format, **kwargs):
                yield chunk

        except Exception as e:
            # Convert exceptions to unified error hierarchy
            self._handle_error(e)

    async def _create_stream_internal(
        self,
        messages: List[Message],
        tools: Optional[List[Dict[str, Any]]] = None,
        output_format: Optional[type] = None,
        **kwargs: Any,
    ) -> AsyncGenerator[ChatCompletionChunk, None]:
        """
        Internal streaming implementation (handles API call, gets retried by wrapper).

        This is the actual streaming API call that gets wrapped by retry logic.

        Args:
            messages: Conversation history
            tools: Optional tool definitions
            **kwargs: Additional Azure OpenAI parameters

        Yields:
            ChatCompletionChunk objects

        Raises:
            Azure OpenAI exceptions (converted by caller)
        """
        # Merge configuration
        api_kwargs = {**self.config, **kwargs}

        # Convert messages to Azure OpenAI format
        api_messages = self._convert_messages_to_api_format(messages)

        # Make streaming API call
        async with await self.client.chat.completions.create(
            model=self.model,
            messages=api_messages,
            tools=tools,
            stream=True,  # Enable streaming
            **api_kwargs,
        ) as response:
            # Yield chunks as they arrive
            async for chunk in response:
                # Skip chunks without choices (e.g., ping/empty chunks)
                if not chunk.choices:
                    continue
                
                # Extract content (may be None or empty string)
                content = chunk.choices[0].delta.content or ""

                yield ChatCompletionChunk(
                    content=content,
                    model=chunk.model,
                    metadata={
                        "finish_reason": chunk.choices[0].finish_reason,
                    },
                )

    def _make_schema_compatible(self, schema: Dict[str, Any]) -> Dict[str, Any]:
        """
        Modify JSON schema to be compatible with Azure OpenAI Structured Outputs.

       Azure OpenAI's Structured Outputs require certain schema constraints:
        - Object types must have additionalProperties=False
        - All properties must be defined in the schema
        - Schemas must be strict and unambiguous

        Args:
            schema: The JSON schema to make compatible

        Returns:
            Modified schema with Azure OpenAI compatibility fixes
        """
        # Make a copy to avoid modifying the original
        compatible_schema = schema.copy()

        # Ensure additionalProperties is False (required by Azure OpenAI)
        if compatible_schema.get("type") == "object":
            compatible_schema["additionalProperties"] = False

            # Recursively apply to nested objects
            properties = compatible_schema.get("properties", {})
            for prop_name, prop_schema in properties.items():
                if isinstance(prop_schema, dict):
                    compatible_schema["properties"][prop_name] = self._make_schema_compatible(prop_schema)

        # Handle arrays with object items
        if compatible_schema.get("type") == "array":
            items = compatible_schema.get("items")
            if isinstance(items, dict):
                compatible_schema["items"] = self._make_schema_compatible(items)

        return compatible_schema

    def _estimate_cost(self, prompt_tokens: int, completion_tokens: int) -> float:
        """
        Estimate the cost of the API call based on token usage.

        Uses current Azure OpenAI pricing for different model families.
        Note: These are approximate rates and may not reflect real-time changes.
        Azure pricing differs from standard OpenAI pricing.

        Args:
            prompt_tokens: Number of tokens in the prompt
            completion_tokens: Number of tokens generated

        Returns:
            Estimated cost in USD

        Azure Model Pricing (as of 2024):
            - GPT-4o: $0.005 per 1K input tokens, $0.015 per 1K output tokens
            - GPT-4 Turbo: $0.01 per 1K input tokens, $0.03 per 1K output tokens
            - GPT-4: $0.03 per 1K input tokens, $0.06 per 1K output tokens
            - GPT-3.5 Turbo: $0.0005 per 1K input tokens, $0.0015 per 1K output tokens
            - Falls back to GPT-4 pricing for unknown models

        Note:
            Azure pricing is typically lower than standard OpenAI pricing.
            For production, validate pricing against your Azure account.
        """
        # Model pricing mapping (per 1K tokens) - Azure rates
        pricing = {
            "gpt-4.1-mini": {"input_per_1m": 0.40, "output_per_1m": 1.60},
            "gpt-4o-mini": {"input_per_1m": 0.15, "output_per_1m": 0.60},
            "gpt-4": {"input_per_1m": 30.0, "output_per_1m": 60.0},  # $0.03/$0.06 per 1K
            "gpt-4-turbo": {"input_per_1m": 10.0, "output_per_1m": 30.0},  # $0.01/$0.03 per 1K
            "gpt-3.5-turbo": {"input_per_1m": 0.50, "output_per_1m": 1.50},
            "gpt-4.1": {"input_per_1m": 2.0, "output_per_1m": 8.0},
            "gpt-4.1-nano": {"input_per_1m": 0.10, "output_per_1m": 0.40},
            "gpt-5-mini": {"input_per_1m": 0.25, "output_per_1m": 2.0},
            "gpt-5.1-chat": {"input_per_1m": 1.25, "output_per_1m": 10.0}
            }

        # Find matching pricing; try to match model name prefix
        model_pricing = None
        for model_key, pricing_data in pricing.items():
            if model_key in self.model.lower():
                model_pricing = pricing_data
                break

        # Default to GPT-4 pricing if no match found
        if not model_pricing:
            model_pricing = pricing["gpt-4"]

        # Calculate cost in USD
        input_cost = (prompt_tokens / 1000) * model_pricing["input_per_1k"]
        output_cost = (completion_tokens / 1000) * model_pricing["output_per_1k"]

        return round(input_cost + output_cost, 6)

    def _to_config(self) -> AzureOpenAIChatCompletionClientConfig:
        """
        Convert client to configuration for serialization.

        Extracts settings that define this client's behavior, enabling
        configuration file storage and cross-environment deployment.

        Returns:
            Configuration object with all necessary state

        Note:
            API key, Azure endpoint, and API version are NOT serialized
            (credentials are managed externally). Users reconstruct
            AsyncAzureOpenAI with their authentication method and inject it
            when creating a new client.
        """
        return AzureOpenAIChatCompletionClientConfig(
            model=self.model,
            config=self.config.copy(),
            max_retries=self.max_retries,
            initial_retry_delay=self.initial_retry_delay,
            max_retry_delay=self.max_retry_delay,
        )

    @classmethod
    def _from_config(cls, config: AzureOpenAIChatCompletionClientConfig) -> "AzureOpenAIChatCompletionClient":
        """
        Create client from configuration.

        Reconstructs a client from saved configuration, but requires the user
        to provide an authenticated AsyncAzureOpenAI client.

        Args:
            config: Client configuration with model, retry settings, etc.

        Returns:
            Partially configured AzureOpenAIChatCompletionClient (needs client injection)

        Example:
            >>> # In config file:
            >>> config_json = '''
            >>> {
            ...   "model": "gpt-4-prod",
            ...   "config": {"temperature": 0.7},
            ...   "max_retries": 3
            ... }
            >>> '''
            >>> 
            >>> # At runtime:
            >>> config = AzureOpenAIChatCompletionClientConfig.model_validate_json(config_json)
            >>> 
            >>> # User creates authenticated client
            >>> from openai import AsyncAzureOpenAI
            >>> azure_client = AsyncAzureOpenAI(
            ...     api_key="...",
            ...     azure_endpoint="https://myresource.openai.azure.com/",
            ...     api_version="2024-10-21"
            ... )
            >>> 
            >>> # Reconstruct agentbyte client
            >>> llm = AzureOpenAIChatCompletionClient._from_config(config)
            >>> llm.client = azure_client  # Inject authentication
        """
        # Create instance with placeholder client (user will inject real one)
        return cls(
            model=config.model,
            client=None,  # type: ignore  # Will be set by user
            config=config.config,
            max_retries=config.max_retries,
            initial_retry_delay=config.initial_retry_delay,
            max_retry_delay=config.max_retry_delay,
        )

    def _handle_error(self, error: Exception) -> None:
        """
        Convert Azure OpenAI-specific exceptions to unified error hierarchy.

        Maps Azure OpenAI exceptions to agentbyte error types for consistent
        error handling across providers.

        Args:
            error: Exception raised by Azure OpenAI API

        Raises:
            RateLimitError: API rate limits exceeded
            AuthenticationError: Authentication failed
            InvalidRequestError: Request format is invalid
            ModelClientError: Other API errors
        """
        # Import here to avoid circular imports and handle optional dependency
        try:
            from openai import (
                RateLimitError as OpenAIRateLimitError,
                AuthenticationError as OpenAIAuthenticationError,
                BadRequestError,
                APIError,
            )
        except ImportError:
            # If openai not installed, convert to generic ModelClientError
            raise ModelClientError(f"Azure OpenAI error: {str(error)}") from error

        error_msg = str(error)
        error_type = type(error).__name__

        if isinstance(error, OpenAIRateLimitError):
            raise RateLimitError(f"Azure OpenAI rate limit exceeded: {error_msg}") from error

        elif isinstance(error, OpenAIAuthenticationError):
            raise AuthenticationError(
                f"Azure OpenAI authentication failed: {error_msg}"
            ) from error

        elif isinstance(error, BadRequestError):
            raise InvalidRequestError(
                f"Azure OpenAI request invalid: {error_msg}"
            ) from error

        elif isinstance(error, APIError):
            # Generic API error - try to extract more details
            raise ModelClientError(
                f"Azure OpenAI API error ({error_type}): {error_msg}"
            ) from error

        else:
            # Unknown error type
            raise ModelClientError(
                f"Unexpected error from Azure OpenAI ({error_type}): {error_msg}"
            ) from error


__all__ = ["AzureOpenAIChatCompletionClient", "AzureOpenAIChatCompletionClientConfig"]
