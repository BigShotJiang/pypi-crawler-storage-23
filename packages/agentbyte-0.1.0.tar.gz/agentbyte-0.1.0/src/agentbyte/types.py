"""
Core types for Agentbyte framework.

This module defines fundamental data structures used throughout Agentbyte,
including tool execution results and type definitions.
"""
from typing import Any, Dict, Optional

from pydantic import BaseModel, ConfigDict, Field


class ToolResult(BaseModel):
    """
    Standardized result from tool execution.

    Provides consistent error handling and result formatting across all tools.
    This immutable structure ensures tool execution results are predictable
    and can be safely logged, serialized, or passed to LLMs.

    Attributes:
        success: Whether tool executed successfully
        result: Tool output data (can be None)
        error: Error message if execution failed
        metadata: Additional execution context (tool name, timing, exception type, etc.)

    Example:
        # Success case
        result = ToolResult(
            success=True,
            result="Weather in Paris: sunny",
            metadata={"tool_name": "get_weather", "execution_time": 0.234}
        )

        # Failure case
        result = ToolResult(
            success=False,
            result=None,
            error="Invalid location: 'Paris' not found",
            metadata={"tool_name": "get_weather", "exception_type": "ValueError"}
        )

    Note:
        - Immutable after creation (frozen=True) to prevent accidental modifications
        - Pydantic validation ensures all fields are properly typed
        - Metadata is extensible for custom tools to add their own context
    """

    success: bool = Field(
        ..., description="Whether tool executed successfully"
    )
    result: Any = Field(
        None, description="Tool output data"
    )
    error: Optional[str] = Field(
        None, description="Error message if tool execution failed"
    )
    metadata: Dict[str, Any] = Field(
        default_factory=dict,
        description="Additional execution context (tool name, timing, exception info, etc.)"
    )

    model_config = ConfigDict(frozen=True)


__all__ = ["ToolResult"]
