"""
Tool system for Agentbyte framework.

This module provides the foundation for tools that agents can use to
interact with the world beyond text generation.

Tools enable agents to:
- Execute functions
- Query databases
- Call APIs
- Perform calculations
- And more

Core tools include:
- ThinkTool: Structured reasoning during complex tasks
- TaskStatusTool: Explicit task completion evaluation
- CalculatorTool: Safe mathematical expression evaluation
- DateTimeTool: Date/time operations
- JSONParserTool: JSON parsing and extraction
- RegexTool: Regular expression operations

Example usage:
    from agentbyte.tools import tool, BaseTool, FunctionTool, ApprovalMode, create_core_tools

    # Simple function tool
    @tool
    def get_weather(city: str) -> str:
        '''Get current weather for a city.'''
        return f"Weather in {city}: sunny"

    # Tool requiring approval
    @tool(approval_mode="always_require")
    def delete_file(path: str) -> str:
        '''Delete a file (requires approval).'''
        os.remove(path)
        return f"Deleted {path}"

    # Custom tool implementation
    class DatabaseTool(BaseTool):
        @property
        def parameters(self):
            return {"type": "object", "properties": {"query": {"type": "string"}}}

        async def execute(self, parameters):
            # ... database logic ...
            return ToolResult(success=True, result=data)

    # Use core tools
    tools = create_core_tools()
"""

from .base import ApprovalMode, BaseTool, FunctionTool
from .core_tools import (
    CalculatorTool,
    DateTimeTool,
    JSONParserTool,
    RegexTool,
    TaskStatusTool,
    ThinkTool,
    create_core_tools,
)
from .decorator import tool

__all__ = [
    "ApprovalMode",
    "BaseTool",
    "FunctionTool",
    "tool",
    "ThinkTool",
    "TaskStatusTool",
    "CalculatorTool",
    "DateTimeTool",
    "JSONParserTool",
    "RegexTool",
    "create_core_tools",
]
