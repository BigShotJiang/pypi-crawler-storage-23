"""
Tool decorator for creating tools from functions with ergonomic syntax.

Provides the @tool decorator that converts Python functions into FunctionTool
instances, supporting both @tool and @tool(...) syntaxes.
"""
from typing import Callable, Optional, TypeVar, Union

from .base import ApprovalMode, FunctionTool

T = TypeVar("T")


def tool(
    func: Optional[Callable[..., T]] = None,
    *,
    name: Optional[str] = None,
    description: Optional[str] = None,
    approval_mode: Union[str, ApprovalMode] = "never_require",
) -> Union[FunctionTool, Callable[[Callable[..., T]], FunctionTool]]:
    """
    Decorator to create a tool from a function with approval support.

    This decorator can be used in three ways:

    1. Without parentheses (uses all defaults):
        @tool
        def get_weather(city: str) -> str:
            '''Get weather for a city.'''
            return f"Weather in {city}: Sunny"

    2. With approval required:
        @tool(approval_mode="always_require")
        def delete_file(path: str) -> str:
            '''Delete a file from the filesystem.'''
            os.remove(path)
            return f"Deleted {path}"

    3. With custom name and description:
        @tool(name="weather_tool", description="Gets weather info")
        def my_weather_func(city: str) -> str:
            return f"Weather in {city}"

    Args:
        func: The function to wrap (when used without parentheses)
        name: Tool name (defaults to function name)
        description: Tool description (defaults to docstring)
        approval_mode: When to require approval ("always_require" or "never_require")

    Returns:
        FunctionTool instance or decorator function
    """

    def decorator(f: Callable[..., T]) -> FunctionTool:
        # Convert string to enum if needed
        mode = (
            ApprovalMode(approval_mode)
            if isinstance(approval_mode, str)
            else approval_mode
        )

        tool_name = name or f.__name__
        tool_desc = description or f.__doc__ or ""

        return FunctionTool(
            func=f,
            name=tool_name,
            description=tool_desc,
            approval_mode=mode,
        )

    # If func is provided, we're being used without parentheses
    if func is not None:
        return decorator(func)

    # Otherwise, we're being used with parentheses
    return decorator


__all__ = ["tool"]
