"""Settings package for agentbyte environment configuration."""
