"""
Agentbyte - Enterprise-ready agent framework with DDD principles.

Building agents from scratch following Chapter 4 patterns with:
- Async-first architecture
- Event-based streaming
- Clean Architecture (Port/Adapter pattern)
- Domain-Driven Design

Architecture Layers:
- domain/         - Core business logic (entities, value objects, services)
- application/    - Use cases, ports (interfaces)
- infrastructure/ - Adapters, external integrations
"""
from agentbyte.__about__ import VERSION

def main():
    print("Agentbyte version:", VERSION)