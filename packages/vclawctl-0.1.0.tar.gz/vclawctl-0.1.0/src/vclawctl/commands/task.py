"""Task history command handlers."""

from __future__ import annotations

from collections import deque
from typing import Any

from vclawctl.adapters.sqlite.db import connect, loads_json
from vclawctl.commands.transport import invoke
from vclawctl.context import CLIContext
from vclawctl.domain.validators import normalize_positive_int, parse_bool
from vclawctl.errors import CLIError


def _row_to_task(row: Any) -> dict[str, Any]:
    return {
        "task_id": str(row["task_id"]),
        "agent_id": str(row["agent_id"]),
        "session_id": str(row["session_id"]),
        "title": str(row["title"]),
        "prompt": str(row["prompt"]),
        "session_kind": str(row["session_kind"] or "task"),
        "workspace_path": str(row["workspace_path"] or ""),
        "workspace_source": str(row["workspace_source"] or "global_default"),
        "status": str(row["status"] or "running"),
        "cycles_count": int(row["cycles_count"] or 0),
        "created_at": float(row["created_at"]),
        "finished_at": float(row["finished_at"]) if row["finished_at"] is not None else None,
        "is_favorite": bool(int(row["is_favorite"] or 0)),
        "progress": loads_json(row["progress_json"], []),
        "final_answer": str(row["final_answer"] or ""),
        "token_usage": loads_json(row["token_usage_json"], {}),
        "agent_name": str(row["agent_name"] or ""),
        "model_name": str(row["model_name"] or ""),
        "parent_task_id": str(row["parent_task_id"] or ""),
        "is_sub_task": bool(int(row["is_sub_task"] or 0)),
    }


def _list_descendants(conn: Any, root_task_id: str) -> list[dict[str, str]]:
    results: list[dict[str, str]] = []
    pending: deque[str] = deque([root_task_id])
    visited: set[str] = set()

    while pending:
        current = pending.popleft()
        if current in visited:
            continue
        visited.add(current)

        row = conn.execute(
            "SELECT task_id, session_id FROM task_history WHERE task_id = ? LIMIT 1",
            (current,),
        ).fetchone()
        if row:
            results.append(
                {
                    "task_id": str(row["task_id"]),
                    "session_id": str(row["session_id"] or ""),
                }
            )

        child_rows = conn.execute(
            "SELECT task_id FROM task_history WHERE parent_task_id = ?",
            (current,),
        ).fetchall()
        for child in child_rows:
            child_id = str(child["task_id"] or "").strip()
            if child_id and child_id not in visited:
                pending.append(child_id)

    return results


def list_tasks(ctx: CLIContext, params: dict[str, Any]) -> dict[str, Any]:
    limit = normalize_positive_int(params.get("limit"), default=50)
    offset = max(int(params.get("offset", 0) or 0), 0)
    include_sub_tasks = parse_bool(params.get("include_sub_tasks"), default=False)
    include_chat_tasks = parse_bool(params.get("include_chat_tasks"), default=False)
    agent_id = str(params.get("agent_id") or "").strip()
    status = str(params.get("status") or "").strip()

    where: list[str] = []
    values: list[Any] = []
    if not include_sub_tasks:
        where.append("is_sub_task = 0")
    if not include_chat_tasks:
        where.append("session_kind != 'chat'")
    if agent_id:
        where.append("agent_id = ?")
        values.append(agent_id)
    if status:
        where.append("status = ?")
        values.append(status)

    where_clause = f"WHERE {' AND '.join(where)}" if where else ""

    with connect(ctx.db_path) as conn:
        rows = conn.execute(
            f"""
            SELECT * FROM task_history
            {where_clause}
            ORDER BY created_at DESC
            LIMIT ? OFFSET ?
            """,
            tuple(values + [limit, offset]),
        ).fetchall()
    return {"tasks": [_row_to_task(row) for row in rows]}


def get_task(ctx: CLIContext, params: dict[str, Any]) -> dict[str, Any]:
    task_id = str(params.get("task_id") or "").strip()
    if not task_id:
        raise CLIError("task_id required", code="missing_required")

    with connect(ctx.db_path) as conn:
        row = conn.execute(
            "SELECT * FROM task_history WHERE task_id = ? LIMIT 1",
            (task_id,),
        ).fetchone()
    if not row:
        raise CLIError("Task not found", code="not_found")
    return {"task": _row_to_task(row)}


def get_by_session(ctx: CLIContext, params: dict[str, Any]) -> dict[str, Any]:
    session_id = str(params.get("session_id") or "").strip()
    if not session_id:
        raise CLIError("session_id required", code="missing_required")
    with connect(ctx.db_path) as conn:
        row = conn.execute(
            "SELECT * FROM task_history WHERE session_id = ? LIMIT 1",
            (session_id,),
        ).fetchone()
    if not row:
        raise CLIError("Task not found", code="not_found")
    return {"task": _row_to_task(row)}


def toggle_favorite(ctx: CLIContext, params: dict[str, Any]) -> dict[str, Any]:
    task_id = str(params.get("task_id") or "").strip()
    if not task_id:
        raise CLIError("task_id required", code="missing_required")

    with connect(ctx.db_path, write=True) as conn:
        row = conn.execute(
            "SELECT is_favorite FROM task_history WHERE task_id = ? LIMIT 1",
            (task_id,),
        ).fetchone()
        if not row:
            return {"ok": False}
        next_value = 0 if int(row["is_favorite"] or 0) else 1
        cur = conn.execute(
            "UPDATE task_history SET is_favorite = ? WHERE task_id = ?",
            (next_value, task_id),
        )
    return {"ok": bool(cur.rowcount), "is_favorite": bool(next_value)}


def delete_task(ctx: CLIContext, params: dict[str, Any]) -> dict[str, Any]:
    task_id = str(params.get("task_id") or "").strip()
    if not task_id:
        raise CLIError("task_id required", code="missing_required")

    with connect(ctx.db_path, write=True) as conn:
        descendants = _list_descendants(conn, task_id)
        task_ids = [item["task_id"] for item in descendants if item.get("task_id")]
        if not task_ids:
            return {"ok": False, "deleted": 0, "task_ids": []}

        placeholders = ", ".join("?" for _ in task_ids)
        cur = conn.execute(
            f"DELETE FROM task_history WHERE task_id IN ({placeholders})",
            tuple(task_ids),
        )

    deleted_count = int(cur.rowcount if cur.rowcount >= 0 else len(task_ids))
    return {
        "ok": deleted_count > 0,
        "deleted": deleted_count,
        "task_ids": task_ids,
    }


def recent_tasks(ctx: CLIContext, params: dict[str, Any]) -> dict[str, Any]:
    payload = dict(params)
    payload["offset"] = 0
    return list_tasks(ctx, payload)


def dispatch(method: str, params: dict[str, Any], ctx: CLIContext) -> dict[str, Any]:
    handlers = {
        "list": list_tasks,
        "get": get_task,
        "get_by_session": get_by_session,
        "toggle_favorite": toggle_favorite,
        "delete": delete_task,
        "recent": recent_tasks,
    }
    handler = handlers.get(method)
    if not handler:
        raise CLIError(f"Unknown task method: {method}", code="unknown_method")
    return handler(ctx, params)


def _invoke_task(method: str, params: dict[str, Any], ctx: CLIContext) -> dict[str, Any]:
    return invoke(
        method=f"task_history.{method}",
        params=params,
        ctx=ctx,
        local_call=lambda: dispatch(method, params, ctx),
    )


def register(subparsers: Any) -> None:
    parser = subparsers.add_parser("task", help="Manage task history")
    task_sub = parser.add_subparsers(dest="task_cmd", required=True)

    list_parser = task_sub.add_parser("list", help="List tasks")
    list_parser.add_argument("--agent-id", default="")
    list_parser.add_argument("--status", default="")
    list_parser.add_argument("--limit", type=int, default=50)
    list_parser.add_argument("--offset", type=int, default=0)
    list_parser.add_argument("--include-sub-tasks", action="store_true")
    list_parser.add_argument("--include-chat-tasks", action="store_true")
    list_parser.set_defaults(func=_cmd_list)

    get_parser = task_sub.add_parser("get", help="Get task by task_id")
    get_parser.add_argument("--task-id", required=True)
    get_parser.set_defaults(func=_cmd_get)

    by_session_parser = task_sub.add_parser("by-session", help="Get task by session_id")
    by_session_parser.add_argument("--session-id", required=True)
    by_session_parser.set_defaults(func=_cmd_by_session)

    fav_parser = task_sub.add_parser("toggle-favorite", help="Toggle favorite")
    fav_parser.add_argument("--task-id", required=True)
    fav_parser.set_defaults(func=_cmd_toggle_favorite)

    delete_parser = task_sub.add_parser("delete", help="Delete task recursively")
    delete_parser.add_argument("--task-id", required=True)
    delete_parser.add_argument("--yes", action="store_true")
    delete_parser.set_defaults(func=_cmd_delete)

    recent_parser = task_sub.add_parser("recent", help="List recent tasks")
    recent_parser.add_argument("--limit", type=int, default=5)
    recent_parser.add_argument("--include-sub-tasks", action="store_true")
    recent_parser.add_argument("--include-chat-tasks", action="store_true")
    recent_parser.set_defaults(func=_cmd_recent)


def _cmd_list(args: Any, ctx: CLIContext) -> dict[str, Any]:
    params = {
        "agent_id": args.agent_id,
        "status": args.status,
        "limit": args.limit,
        "offset": args.offset,
        "include_sub_tasks": args.include_sub_tasks,
        "include_chat_tasks": args.include_chat_tasks,
    }
    return _invoke_task("list", params, ctx)


def _cmd_get(args: Any, ctx: CLIContext) -> dict[str, Any]:
    params = {"task_id": args.task_id}
    return _invoke_task("get", params, ctx)


def _cmd_by_session(args: Any, ctx: CLIContext) -> dict[str, Any]:
    params = {"session_id": args.session_id}
    return _invoke_task("get_by_session", params, ctx)


def _cmd_toggle_favorite(args: Any, ctx: CLIContext) -> dict[str, Any]:
    params = {"task_id": args.task_id}
    return _invoke_task("toggle_favorite", params, ctx)


def _cmd_delete(args: Any, ctx: CLIContext) -> dict[str, Any]:
    if not args.yes:
        raise CLIError("delete requires --yes", code="confirmation_required")
    params = {"task_id": args.task_id}
    return _invoke_task("delete", params, ctx)


def _cmd_recent(args: Any, ctx: CLIContext) -> dict[str, Any]:
    params = {
        "limit": args.limit,
        "include_sub_tasks": args.include_sub_tasks,
        "include_chat_tasks": args.include_chat_tasks,
    }
    return _invoke_task("recent", params, ctx)
