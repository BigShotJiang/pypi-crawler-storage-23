"""Config command handlers."""

from __future__ import annotations

from typing import Any

from vclawctl.adapters.sqlite.db import connect, read_config_json, upsert_config_json
from vclawctl.commands.transport import invoke
from vclawctl.context import CLIContext
from vclawctl.domain.validators import parse_json_object, parse_json_value
from vclawctl.errors import CLIError


def _deep_merge(base: dict[str, Any], override: dict[str, Any]) -> dict[str, Any]:
    merged = dict(base)
    for key, value in override.items():
        if isinstance(merged.get(key), dict) and isinstance(value, dict):
            merged[key] = _deep_merge(merged[key], value)
        else:
            merged[key] = value
    return merged


def _get_by_path(data: dict[str, Any], key_path: str, default: Any = None) -> Any:
    cursor: Any = data
    for key in key_path.split("."):
        if not isinstance(cursor, dict):
            return default
        if key not in cursor:
            return default
        cursor = cursor[key]
    return cursor


def _set_by_path(data: dict[str, Any], key_path: str, value: Any) -> None:
    parts = [part for part in key_path.split(".") if part]
    if not parts:
        raise CLIError("key path is empty", code="invalid_key")

    cursor: dict[str, Any] = data
    for part in parts[:-1]:
        child = cursor.get(part)
        if not isinstance(child, dict):
            child = {}
            cursor[part] = child
        cursor = child
    cursor[parts[-1]] = value


def get_config(ctx: CLIContext, params: dict[str, Any]) -> dict[str, Any]:
    key = str(params.get("key") or "").strip()
    default = params.get("default")
    with connect(ctx.db_path) as conn:
        cfg = read_config_json(conn)
    if not key:
        return {"config": cfg}
    return {"value": _get_by_path(cfg, key, default)}


def update_config(ctx: CLIContext, params: dict[str, Any]) -> dict[str, Any]:
    partial = params.get("config", {})
    if not isinstance(partial, dict):
        raise CLIError("config must be object", code="invalid_payload")

    with connect(ctx.db_path, write=True) as conn:
        current = read_config_json(conn)
        next_cfg = _deep_merge(current, partial)
        upsert_config_json(conn, next_cfg)
    return {"ok": True}


def set_value(ctx: CLIContext, params: dict[str, Any]) -> dict[str, Any]:
    key = str(params.get("key") or "").strip()
    if not key:
        raise CLIError("key required", code="missing_required")
    value = params.get("value")

    with connect(ctx.db_path, write=True) as conn:
        current = read_config_json(conn)
        _set_by_path(current, key, value)
        upsert_config_json(conn, current)
    return {"ok": True}


def dispatch(method: str, params: dict[str, Any], ctx: CLIContext) -> dict[str, Any]:
    handlers = {
        "get_config": get_config,
        "update_config": update_config,
        "set_value": set_value,
        "get_value": get_config,
    }
    handler = handlers.get(method)
    if not handler:
        raise CLIError(f"Unknown config method: {method}", code="unknown_method")
    return handler(ctx, params)


def _invoke_config(method: str, params: dict[str, Any], ctx: CLIContext) -> dict[str, Any]:
    method_name = f"settings.{method}"
    return invoke(
        method=method_name,
        params=params,
        ctx=ctx,
        local_call=lambda: dispatch(method, params, ctx),
    )


def register(subparsers: Any) -> None:
    parser = subparsers.add_parser("config", help="Manage v-claw config")
    cfg_sub = parser.add_subparsers(dest="config_cmd", required=True)

    get_parser = cfg_sub.add_parser("get", help="Get config or key")
    get_parser.add_argument("--key", default="")
    get_parser.add_argument("--default-json", default="null")
    get_parser.set_defaults(func=_cmd_get)

    set_parser = cfg_sub.add_parser("set", help="Set config key with JSON value")
    set_parser.add_argument("--key", required=True)
    set_parser.add_argument("--value-json", required=True)
    set_parser.set_defaults(func=_cmd_set)

    patch_parser = cfg_sub.add_parser("patch", help="Deep-merge config patch")
    patch_parser.add_argument("--params-json", required=True)
    patch_parser.set_defaults(func=_cmd_patch)


def _cmd_get(args: Any, ctx: CLIContext) -> dict[str, Any]:
    default = parse_json_value(args.default_json, field_name="default_json")
    key = str(args.key or "").strip()
    if key:
        params = {"key": key, "default": default}
        return _invoke_config("get_value", params, ctx)
    return _invoke_config("get_config", {"key": key, "default": default}, ctx)


def _cmd_set(args: Any, ctx: CLIContext) -> dict[str, Any]:
    value = parse_json_value(args.value_json, field_name="value_json")
    key = str(args.key or "").strip()
    partial: dict[str, Any] = {}
    _set_by_path(partial, key, value)
    params = {"config": partial}
    return _invoke_config("update_config", params, ctx)


def _cmd_patch(args: Any, ctx: CLIContext) -> dict[str, Any]:
    partial = parse_json_object(args.params_json, field_name="params_json")
    return _invoke_config("update_config", {"config": partial}, ctx)
