"""Generic call command dispatcher."""

from __future__ import annotations

from typing import Any

from vclawctl.commands import agent, chat, config, schedule, session, task
from vclawctl.commands.transport import invoke
from vclawctl.context import CLIContext
from vclawctl.domain.validators import parse_json_object
from vclawctl.errors import CLIError


def _split_method(raw_method: str) -> tuple[str, str]:
    method = str(raw_method or "").strip()
    if not method:
        raise CLIError("method required", code="missing_required")

    namespace, dot, op = method.partition(".")
    if not dot or not namespace.strip() or not op.strip():
        raise CLIError("method must be namespace.method", code="invalid_method")
    return namespace.strip(), op.strip()


def dispatch_call(method: str, params: dict[str, Any], ctx: CLIContext) -> dict[str, Any]:
    namespace, op = _split_method(method)

    if namespace == "schedule":
        return schedule.dispatch(op, params, ctx)
    if namespace in {"agent", "agent_profile"}:
        mapped = {
            "list": "list",
            "get": "get",
            "create": "create",
            "update": "update",
            "delete": "delete",
        }.get(op, op)
        return agent.dispatch(mapped, params, ctx)
    if namespace == "task_history":
        mapped = {
            "list": "list",
            "get": "get",
            "get_by_session": "get_by_session",
            "toggle_favorite": "toggle_favorite",
            "delete": "delete",
            "recent": "recent",
        }.get(op, op)
        return task.dispatch(mapped, params, ctx)
    if namespace == "settings":
        mapped = {
            "get_config": "get_config",
            "update_config": "update_config",
            "get_value": "get_value",
            "set_value": "set_value",
        }.get(op, op)
        return config.dispatch(mapped, params, ctx)
    if namespace == "chat":
        return chat.dispatch(op, params, ctx)
    if namespace == "session":
        return session.dispatch(op, params, ctx)

    raise CLIError(f"Unsupported namespace: {namespace}", code="unsupported_namespace")


def register(subparsers: Any) -> None:
    parser = subparsers.add_parser("call", help="Call namespace.method with JSON params")
    parser.add_argument("--method", required=True)
    parser.add_argument("--params-json", default="{}")
    parser.set_defaults(func=_cmd_call)


def _cmd_call(args: Any, ctx: CLIContext) -> dict[str, Any]:
    params = parse_json_object(args.params_json, field_name="params_json")
    method = str(args.method or "").strip()
    return invoke(
        method=method,
        params=params,
        ctx=ctx,
        local_call=lambda: dispatch_call(method, params, ctx),
    )
