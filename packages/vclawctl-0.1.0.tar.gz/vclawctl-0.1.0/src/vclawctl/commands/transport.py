"""Transport helper for api/auto/db execution modes."""

from __future__ import annotations

from collections.abc import Callable
from typing import Any

from vclawctl.adapters.runtime.client import RuntimeClient
from vclawctl.context import CLIContext
from vclawctl.errors import CLIError, ExitCode


def _normalize_runtime_result(payload: dict[str, Any]) -> dict[str, Any]:
    if "ok" not in payload:
        return payload

    ok = bool(payload.get("ok"))
    if not ok:
        raise CLIError(
            str(payload.get("error") or "runtime call failed"),
            code=str(payload.get("code") or "runtime_error"),
            exit_code=ExitCode.BUSINESS_ERROR,
        )

    if (
        "data" in payload
        and isinstance(payload.get("data"), dict)
        and set(payload.keys()).issubset({"ok", "data", "error", "code"})
    ):
        return dict(payload.get("data") or {})

    result = dict(payload)
    result.pop("ok", None)
    result.pop("error", None)
    result.pop("code", None)
    return result


def invoke(
    *,
    method: str,
    params: dict[str, Any],
    ctx: CLIContext,
    local_call: Callable[[], dict[str, Any]],
) -> dict[str, Any]:
    mode = str(ctx.mode or "api").strip().lower()
    if mode not in {"api", "auto", "db"}:
        mode = "api"

    if mode == "db":
        return local_call()

    client = RuntimeClient(
        base_url=ctx.api_base_url,
        auth_token=ctx.auth_token,
        timeout_seconds=ctx.timeout_seconds,
    )
    try:
        payload = client.call(method, params)
        return _normalize_runtime_result(payload)
    except CLIError:
        if mode != "auto":
            raise
        return local_call()
