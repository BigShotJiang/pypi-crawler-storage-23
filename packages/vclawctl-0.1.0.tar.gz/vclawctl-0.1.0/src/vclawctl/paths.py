"""Path resolution helpers."""

from __future__ import annotations

import platform
from pathlib import Path


def default_data_dir() -> Path:
    system = platform.system().lower()
    if system == "windows":
        return Path.home() / "AppData" / "Local" / "v-claw"
    if system == "darwin":
        return Path.home() / "Library" / "Application Support" / "v-claw"
    return Path.home() / ".v-claw"


def resolve_data_dir(raw: str | None) -> Path:
    candidate = Path(raw).expanduser() if raw else default_data_dir()
    return candidate.resolve()


def resolve_db_path(data_dir: Path) -> Path:
    return data_dir / "v_claw.db"
