"""Domain models and validators."""
