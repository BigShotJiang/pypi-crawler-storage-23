"""SQLite access helpers for vclawctl."""

from __future__ import annotations

import json
import sqlite3
import time
from contextlib import contextmanager
from pathlib import Path
from typing import Any

from vclawctl.errors import CLIError


@contextmanager
def connect(db_path: Path, *, write: bool = False):
    if not db_path.exists():
        raise CLIError(f"Database not found: {db_path}", code="db_not_found")
    conn = sqlite3.connect(str(db_path))
    conn.row_factory = sqlite3.Row
    try:
        yield conn
        if write:
            conn.commit()
    finally:
        conn.close()


def loads_json(raw: Any, default: Any) -> Any:
    if raw in (None, ""):
        return default
    try:
        return json.loads(str(raw))
    except Exception:  # noqa: BLE001
        return default


def upsert_config_json(conn: sqlite3.Connection, payload: dict[str, Any]) -> None:
    conn.execute(
        """
        INSERT INTO config(id, config_json, updated_at)
        VALUES(1, ?, ?)
        ON CONFLICT(id) DO UPDATE SET
            config_json = excluded.config_json,
            updated_at = excluded.updated_at
        """,
        (json.dumps(payload, ensure_ascii=False), time.time()),
    )


def read_config_json(conn: sqlite3.Connection) -> dict[str, Any]:
    row = conn.execute("SELECT config_json FROM config WHERE id = 1").fetchone()
    if not row:
        return {}
    return loads_json(row["config_json"], {})
