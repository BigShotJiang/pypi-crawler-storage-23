# vclawctl

`vclawctl` is an independent control-plane CLI for managing v-claw data.

All command outputs are JSON on stdout.

## Quick Start

```bash
uv tool install vclawctl
vclawctl --help
```

## Control Channel Modes

`vclawctl` supports three execution modes:

```bash
vclawctl --mode api   ...   # API only
vclawctl --mode auto  ...   # API first, fallback to DB
vclawctl --mode db    ...   # DB only
```

Default mode is `api`.

## API Auth

When using API mode, provide:

- `VCLAWCTL_API_BASE_URL` (for example `http://127.0.0.1:7799/api/control/v1`)
- `VCLAWCTL_AUTH_TOKEN`

or pass flags directly:

```bash
vclawctl \
  --mode api \
  --api-base-url "http://127.0.0.1:7799/api/control/v1" \
  --auth-token "YOUR_TOKEN" \
  schedule status
```

## Examples

```bash
# List schedule tasks (default api mode)
vclawctl schedule list

# Create one-time schedule task
vclawctl schedule create --params-json '{"name":"once-hi","prompt":"Hi","schedule_type":"once","schedule_config":{"at":"2026-03-01T12:00:00Z"}}'

# Generic method call
vclawctl call --method settings.get_value --params-json '{"key":"chat.default_agent_id"}'
```
