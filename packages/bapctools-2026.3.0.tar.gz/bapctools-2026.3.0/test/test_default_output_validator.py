import hashlib
import os
import tempfile
from pathlib import Path

import pytest
import yaml

from bapctools import config, problem, testcase, util, validate

RUN_DIR = Path.cwd().absolute()
# Note: the python version isn't tested by default, because it's quite slow.
DEFAULT_OUTPUT_VALIDATOR = ["default_output_validator.cpp"]

config.args.add_if_not_set(config.ARGS("test_default_output_validator.py", verbose=2, error=True))


# return list of (flags, ans, out, expected result)
def read_tests():
    docs = yaml.load_all(
        (RUN_DIR / "test/default_output_validator/default_output_validator.yaml").read_text(),
        Loader=yaml.SafeLoader,
    )

    tests = []

    for doc in docs:
        doc["ans"] = str(doc["ans"])
        if "ac" in doc:
            for out in doc["ac"]:
                tests.append((doc["flags"], doc["ans"], str(out), util.ExecStatus.ACCEPTED))
        if "wa" in doc:
            for out in doc["wa"]:
                tests.append((doc["flags"], doc["ans"], str(out), util.ExecStatus.REJECTED))

    print(tests)
    return tests


@pytest.fixture(scope="class", params=DEFAULT_OUTPUT_VALIDATOR)
def validator(request):
    problem_dir = RUN_DIR / "test/problems/identity"
    os.chdir(problem_dir)

    h = hashlib.sha256(bytes(Path().cwd())).hexdigest()[-6:]
    tmpdir = Path(tempfile.gettempdir()) / ("bapctools_" + h)
    tmpdir.mkdir(exist_ok=True)
    p = problem.Problem(Path("."), tmpdir)
    validator = validate.OutputValidator(p, config.RESOURCES_ROOT / "support" / request.param)
    print(util.ProgressBar.current_bar)
    bar = util.ProgressBar("build", max_len=1)
    validator.build(bar)
    bar.finalize()
    yield (p, validator)
    os.chdir(RUN_DIR)


class MockRun:
    pass


@pytest.mark.usefixtures("validator")
class TestDefaultOutputValidator:
    @pytest.mark.parametrize("test_data", read_tests())
    def test_default_output_validator(self, validator, test_data):
        problem, validator = validator
        flags, ans, out, exp = test_data
        flags = flags.split()

        (problem.tmpdir / "data").mkdir(exist_ok=True, parents=True)
        in_path = problem.tmpdir / "data/test.in"
        ans_path = problem.tmpdir / "data/test.ans"
        out_path = problem.tmpdir / "data/test.out"
        ans_path.write_text(ans)
        out_path.write_text(out)

        in_path.write_text("")

        t = testcase.Testcase(problem, in_path, short_path=Path("test"))
        r = MockRun()
        r.in_path = in_path
        r.out_path = out_path
        r.feedbackdir = problem.tmpdir / "data"

        # TODO: the validator should probably be able to figure the flags out from the Problem config
        result = validator.run(t, r, args=flags)

        if result.status != exp:
            print(test_data)
            for k in vars(result):
                print(k, " -> ", getattr(result, k))
        assert result.status == exp
