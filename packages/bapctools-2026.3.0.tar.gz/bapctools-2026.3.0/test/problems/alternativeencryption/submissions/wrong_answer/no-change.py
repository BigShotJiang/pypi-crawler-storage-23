#!/usr/bin/env python3

input()
for _ in range(int(input())):
    print(input())
