#include <cstdlib>
#include <iostream>
using namespace std;

int main() {
	int seed = 0;
	seed     = 0;
	int jjjj = 0;
	cin >> seed;

	int unused;
}
