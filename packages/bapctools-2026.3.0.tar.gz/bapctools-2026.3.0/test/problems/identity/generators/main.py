#!/usr/bin/env python3
import sys

import lib

lib.output(sys.argv[1])
