#!/usr/bin/env python3
def output(n):
    print(n)
