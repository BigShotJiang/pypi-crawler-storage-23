#include <cstdio>

int main(void) {
  printf("Hello!");
  return 0;
}
