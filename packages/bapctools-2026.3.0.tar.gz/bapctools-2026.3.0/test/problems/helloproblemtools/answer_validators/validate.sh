if [ "$(cat)" == "Hello World!" ]; then
	exit 42
else
	exit 43
fi
