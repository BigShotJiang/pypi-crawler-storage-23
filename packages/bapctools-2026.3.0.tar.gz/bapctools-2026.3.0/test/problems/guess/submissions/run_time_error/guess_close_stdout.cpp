#include <cassert>
#include <cstdio>
int main() {
	std::fclose(stdout);
	assert(false);
}
