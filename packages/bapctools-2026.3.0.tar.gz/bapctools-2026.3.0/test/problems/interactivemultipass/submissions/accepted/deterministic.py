#!/usr/bin/env python3
input()
print(500)
