#!/usr/bin/env python3
# WA after first pass since number must not be negative
print(-3)
