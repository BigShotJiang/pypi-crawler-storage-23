#!/usr/bin/env python3

print(sum(map(int, input().split())))
