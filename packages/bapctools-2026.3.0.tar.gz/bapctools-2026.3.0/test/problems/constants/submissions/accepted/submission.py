#!/usr/bin/python3
print(5)
