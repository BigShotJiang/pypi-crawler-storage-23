#!/usr/bin/env python3

a, b, c, d = input().split()
print(float(a) / float(b), "".join(sorted(c + d)))
