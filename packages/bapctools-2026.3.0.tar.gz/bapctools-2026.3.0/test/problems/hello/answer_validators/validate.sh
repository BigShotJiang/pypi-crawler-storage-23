if [ "$(cat)" == "Hello world!" ]; then
	exit 42
else
	exit 43
fi
