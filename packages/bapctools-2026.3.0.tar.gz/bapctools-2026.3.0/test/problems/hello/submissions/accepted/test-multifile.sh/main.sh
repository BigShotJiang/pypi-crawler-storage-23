# This multifile submission should give CORRECT on the default problem 'hello'.

# Use explicit path, since "." may not be included in PATH
. ${0%/*}/secondary.sh

exit 0
