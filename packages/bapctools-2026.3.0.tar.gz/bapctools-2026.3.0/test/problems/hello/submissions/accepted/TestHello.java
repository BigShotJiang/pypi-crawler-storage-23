/*
 * This should give CORRECT on the default problem 'hello'.
 */

import java.io.*;

class TestHello {
    public static void main(String[] args) throws Exception {
		System.out.print("Hello world!\n");
    }
}
