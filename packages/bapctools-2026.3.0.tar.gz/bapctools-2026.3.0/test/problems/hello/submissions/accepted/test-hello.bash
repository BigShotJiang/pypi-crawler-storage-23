# This should give CORRECT on the default problem 'hello'.

echo "Hello world!"

exit 0
