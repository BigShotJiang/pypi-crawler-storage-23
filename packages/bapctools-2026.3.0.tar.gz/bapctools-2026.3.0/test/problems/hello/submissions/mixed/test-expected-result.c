/*
 * This should fail with NO-OUTPUT, even though it is in the accepted directory.
 *
 * @EXPECTED_RESULTS@: CORRECT, NO-OUTPUT
 */

int main()
{
	return 0;
}
