from bapctools.cli import main

main()
