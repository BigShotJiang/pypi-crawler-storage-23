def test_1():
    assert(True)