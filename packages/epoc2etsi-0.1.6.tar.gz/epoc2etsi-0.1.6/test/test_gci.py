from epoc2etsi.forms.globalcaseid import GlobalCaseID, INSTRUMENTS

from datetime import date, datetime, timedelta
from random import choice, randrange

LETTERS = list([chr(x) for x in range(ord('A'),ord('Z') + 1)])

def random_instrument():
    return choice(INSTRUMENTS)

def random_country():
    return choice(LETTERS) + choice(LETTERS)

def random_date():
    return date.fromtimestamp((datetime(1970,1,1) +  timedelta(days = randrange(47,482))).timestamp())

def random_date_seq():
    return randrange(0, GlobalCaseID.MAX_DATE_SEQ)

def random_des():
    return randrange(0, GlobalCaseID.MAX_NATIONAL_ID)

def random_tid():
    return randrange(0, GlobalCaseID.MAX_IDENTIFIER_ID)


def random_gci():
    gci = GlobalCaseID(random_instrument(),
                       random_country(), 
                       random_country(),
                       random_date(),
                       random_date_seq(),
                       random_des())
    return gci

def test_1():
    gci = GlobalCaseID("EPOC", "AA", "ZZ", date.today(), 0, 0)

def check_translation(gci : GlobalCaseID):
    u = gci.as_uuid()
    s = gci.as_gci()
    assert(GlobalCaseID.parse_from_gci(s).as_uuid() == u)
    assert(GlobalCaseID.parse_from_uuid(str(u)).as_gci() == s)

def test_instruments():
    for instrument in INSTRUMENTS:
        gci = random_gci()
        gci.instrument = instrument
        check_translation(gci)

def test_countries():
    for a in LETTERS:
        for b in LETTERS:
            gci = random_gci()
            gci.issuing_country = a + b
            check_translation(gci)
            gci.issuing_country = gci.executing_country
            gci.executing_country = a + b
            check_translation(gci)

def test_dates():
    early_date = date(1970,1,1)
    late_date = date(2100,1,1)
    gci = random_gci()
    gci.issue_date = early_date
    check_translation(gci)
    gci.issue_date = late_date
    check_translation(gci)
    for i in range(100):
        gci = random_gci()
        check_translation(gci)

def test_date_seq():
    for i in range(0, GlobalCaseID.MAX_DATE_SEQ):
        gci = random_gci()
        gci.issue_date_sequence = i
        check_translation(gci)

def test_national_id():
    gci = random_gci()
    for i in range(0, GlobalCaseID.MAX_NATIONAL_ID):
        gci.national_id = i
        check_translation(gci)

def test_identifier_id():
    gci = random_gci()
    for i in range(1, GlobalCaseID.MAX_IDENTIFIER_ID):
        gci.identifier_id = i
        check_translation(gci)
