from fastapi.testclient import TestClient
from turbo_agent_auth.app import create_app


def test_health():
    client = TestClient(create_app())
    resp = client.get("/health")
    assert resp.status_code == 200
    assert resp.json() == {"status": "ok"}


def test_ping():
    client = TestClient(create_app())
    resp = client.get("/v1/ping")
    assert resp.status_code == 200
    assert resp.json() == {"pong": True}
