-- AlterTable
ALTER TABLE "AuthMethod"
ADD COLUMN     "authFieldPlacements" JSONB,
ADD COLUMN     "authFieldsSchema" JSONB;
