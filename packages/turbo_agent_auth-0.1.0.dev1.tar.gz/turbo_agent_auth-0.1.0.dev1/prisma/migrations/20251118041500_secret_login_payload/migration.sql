-- AlterTable
ALTER TABLE "Secret"
ADD COLUMN     "autoLoginEnabled" BOOLEAN NOT NULL DEFAULT false,
ADD COLUMN     "lastLoginAt" TIMESTAMP(3),
ADD COLUMN     "lastLoginError" TEXT,
ADD COLUMN     "lastLoginStatus" TEXT,
ADD COLUMN     "loginPayload" JSONB;
