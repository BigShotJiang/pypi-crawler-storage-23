-- AlterTable
ALTER TABLE "Secret"
ADD COLUMN     "authDataSources" JSONB;
