-- DropIndex
DROP INDEX "Secret_authMethodId_name_key";

-- DropIndex
DROP INDEX "Secret_isValid_idx";

-- DropIndex
DROP INDEX "Secret_status_idx";

-- CreateIndex
CREATE INDEX "Secret_authMethodId_name_createdAt_idx" ON "Secret"("authMethodId", "name", "createdAt");
