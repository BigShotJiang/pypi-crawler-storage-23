-- Secret: add user binding, credential and reminder fields
ALTER TABLE "Secret" ADD COLUMN IF NOT EXISTS "userEmail" TEXT;
ALTER TABLE "Secret" ADD COLUMN IF NOT EXISTS "credentialUsername" TEXT;
ALTER TABLE "Secret" ADD COLUMN IF NOT EXISTS "credentialPassword" TEXT;
ALTER TABLE "Secret" ADD COLUMN IF NOT EXISTS "credentialConsent" BOOLEAN NOT NULL DEFAULT false;
ALTER TABLE "Secret" ADD COLUMN IF NOT EXISTS "lastReminderAt" TIMESTAMP(3);

-- Index for userEmail lookups
DO $$ BEGIN
  CREATE INDEX IF NOT EXISTS "Secret_userEmail_idx" ON "Secret"("userEmail");
EXCEPTION WHEN duplicate_table THEN NULL; END $$;
