-- AlterTable
ALTER TABLE "Secret" ADD COLUMN     "isValid" BOOLEAN NOT NULL DEFAULT true;

-- CreateIndex
CREATE INDEX "Secret_isValid_idx" ON "Secret"("isValid");

-- CreateIndex
CREATE INDEX "Secret_status_idx" ON "Secret"("status");
