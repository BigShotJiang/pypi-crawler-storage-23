/*
  Warnings:

  - You are about to drop the column `credentialConsent` on the `Secret` table. All the data in the column will be lost.
  - You are about to drop the column `credentialPassword` on the `Secret` table. All the data in the column will be lost.
  - You are about to drop the column `credentialUsername` on the `Secret` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE "Secret" DROP COLUMN "credentialConsent",
DROP COLUMN "credentialPassword",
DROP COLUMN "credentialUsername",
ADD COLUMN     "invalidNotified" BOOLEAN NOT NULL DEFAULT false;
