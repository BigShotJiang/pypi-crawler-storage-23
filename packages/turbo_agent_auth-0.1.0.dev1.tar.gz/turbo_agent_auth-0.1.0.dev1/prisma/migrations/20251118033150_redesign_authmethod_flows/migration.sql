/*
  Warnings:

  - You are about to drop the column `config` on the `AuthMethod` table. All the data in the column will be lost.
  - You are about to drop the column `fieldSchema` on the `AuthMethod` table. All the data in the column will be lost.
  - You are about to drop the column `keyLocation` on the `AuthMethod` table. All the data in the column will be lost.
  - You are about to drop the column `requestContentType` on the `AuthMethod` table. All the data in the column will be lost.
  - You are about to drop the column `requestMethod` on the `AuthMethod` table. All the data in the column will be lost.
  - A unique constraint covering the columns `[id]` on the table `AuthMethod` will be added. If there are existing duplicate values, this will fail.

*/
-- AlterTable
ALTER TABLE "AuthMethod" DROP COLUMN "config",
DROP COLUMN "fieldSchema",
DROP COLUMN "keyLocation",
DROP COLUMN "requestContentType",
DROP COLUMN "requestMethod",
ADD COLUMN     "description" TEXT,
ADD COLUMN     "loginFieldsSchema" JSONB,
ADD COLUMN     "loginFlow" JSONB,
ADD COLUMN     "refreshFieldsSchema" JSONB,
ADD COLUMN     "refreshFlow" JSONB;

-- CreateIndex
CREATE UNIQUE INDEX "AuthMethod_id_key" ON "AuthMethod"("id");
