from prisma import Prisma

# Prisma 全局客户端，避免循环引用
client = Prisma()

__all__ = ["client"]
