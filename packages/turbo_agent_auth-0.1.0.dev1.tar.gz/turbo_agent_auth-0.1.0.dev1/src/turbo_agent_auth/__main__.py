# Allow `python -m turbo_agent_auth run-api` execution
from .cli import app

if __name__ == "__main__":
    app()
