import typer
import uvicorn
from turbo_agent_auth.app import create_app
from turbo_agent_auth.logging import setup_logging, patch_standard_logging

# 根命令组
app = typer.Typer(help="turbo-agent-auth 命令行工具")

# 子命令组：服务运行
serve_app = typer.Typer(help="服务运行相关命令")


@serve_app.command("run")
def serve_run(
    host: str = typer.Option("0.0.0.0", help="绑定主机地址"),
    port: int = typer.Option(8000, help="绑定端口"),
    reload: bool = typer.Option(True, help="开发模式下启用自动重载"),
    log_level: str = typer.Option("INFO", help="日志级别: DEBUG/INFO/WARNING/ERROR"),
    json: bool = typer.Option(False, "--json/--no-json", help="启用 JSON 日志输出"),
    log_file: str | None = typer.Option(None, help="可选日志文件路径"),
    rotation: str | None = typer.Option(None, help="日志轮转规则, 例如 '10 MB' 或 '00:00'"),
    retention: str | None = typer.Option(None, help="日志保留规则, 例如 '7 days'"),
    api_key: str | None = typer.Option(None, help="API Key (亦可用环境变量 AUTH_API_KEY)"),
):
    """通过 Uvicorn 运行 FastAPI 服务。"""
    # Configure logging
    setup_logging(level=log_level, json=json, log_file=log_file, rotation=rotation, retention=retention)
    patch_standard_logging()

    # 若提供 api_key 参数则写入环境变量，便于后续依赖读取
    if api_key:
        import os
        os.environ.setdefault("AUTH_API_KEY", api_key)

    if reload:
        # Use factory import for proper reload
        target = "turbo_agent_auth.app:create_app"
        uvicorn.run(target, host=host, port=port, reload=True, factory=True)
    else:
        uvicorn.run(create_app(), host=host, port=port, reload=False)


# 兼容旧用法：根级命令 run-api（转发到 serve run）
@app.command("run-api")
def run_api(
    host: str = typer.Option("0.0.0.0", help="绑定主机地址"),
    port: int = typer.Option(8000, help="绑定端口"),
    reload: bool = typer.Option(True, help="开发模式下启用自动重载"),
    log_level: str = typer.Option("INFO", help="日志级别: DEBUG/INFO/WARNING/ERROR"),
    json: bool = typer.Option(False, "--json/--no-json", help="启用 JSON 日志输出"),
    log_file: str | None = typer.Option(None, help="可选日志文件路径"),
    rotation: str | None = typer.Option(None, help="日志轮转规则, 例如 '10 MB' 或 '00:00'"),
    retention: str | None = typer.Option(None, help="日志保留规则, 例如 '7 days'"),
    api_key: str | None = typer.Option(None, help="API Key (亦可用环境变量 AUTH_API_KEY)"),
):
    serve_run(host=host, port=port, reload=reload, log_level=log_level, json=json, log_file=log_file, rotation=rotation, retention=retention, api_key=api_key)


# 挂载子命令组
app.add_typer(serve_app, name="serve", help="服务运行")


def main():
    """Console script entrypoint that invokes the Typer app."""
    app()
