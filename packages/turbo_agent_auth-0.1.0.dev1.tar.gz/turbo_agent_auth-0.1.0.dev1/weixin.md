```bash
curl -X POST http://127.0.0.1:8000/v1/platforms \
  -H 'content-type: application/json' \
  -d '{
    "id": "plat_wechat_official",
    "orgId": "org_wechat",
    "nameId": "wechat_official",
    "name": "微信公众平台",
    "code": "wechat_official"
  }'
curl -X POST http://127.0.0.1:8000/v1/auth-methods \
  -H 'content-type: application/json' \
  -d '{
    "id": "am_wechat_official_oauth1",
    "platformId": "plat_wechat_official",
    "name": "wechat_official_oauth1",
    "type": "OAuth1",
    "description": "微信公众平台稳定版 access_token 获取流程，两步：配置账号与调用 stable_token 接口。",
    "loginFieldsSchema": {
      "type": "object",
      "required": ["appid", "secret"],
      "properties": {
        "appid": { "type": "string", "title": "AppID" },
        "secret": { "type": "string", "title": "AppSecret" },
        "grant_type": {
          "type": "string",
          "title": "grant_type",
          "default": "client_credential"
        },
        "force_refresh": {
          "type": "boolean",
          "title": "force_refresh",
          "default": false
        },
        "callback_url": {
          "type": "string",
          "title": "回调地址(只读)",
          "readOnly": true,
          "description": "由服务端环境变量注入，禁止人工填写"
        }
      }
    },
    "loginFlow": {
      "url": "https://api.weixin.qq.com/cgi-bin/stable_token",
      "method": "POST",
      "headers": { "Content-Type": "application/json" },
      "body_template": {
        "grant_type": "{{grant_type}}",
        "appid": "{{appid}}",
        "secret": "{{secret}}",
        "force_refresh": "{{force_refresh}}"
      }
    },
    "responseMapping": {
      "fields": {
        "access_token": "access_token",
        "expires_in": "expires_in"
      }
    },
    "defaultValiditySeconds": 7200,
    "refreshBeforeSeconds": 300
  }'
  curl -X POST http://127.0.0.1:8000/v1/auth-methods/am_wechat_official_oauth1/secret \
  -H 'content-type: application/json' \
  -d '{
    "id": "sec_wechat_official_demo",
    "name": "wechat_official_demo",
    "tags": ["wechat", "official"],
    "data": {},
    "loginPayload": {
      "appid": "<替换为公众号AppID>",
      "secret": "<替换为公众号AppSecret>",
      "force_refresh": false
    },
    "autoLoginEnabled": true
  }'
```