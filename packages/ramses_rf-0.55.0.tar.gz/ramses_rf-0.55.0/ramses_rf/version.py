"""RAMSES RF - a RAMSES-II protocol decoder & analyser (application layer)."""

__version__ = "0.55.0"
VERSION = __version__
