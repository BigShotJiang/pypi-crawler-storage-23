#!/usr/bin/env python3
"""RAMSES RF - Test eavesdropping of the DHW sensor."""
