import json
import os
from typing import Iterator

import pandas as pd

from csv_detective.output.dataframe import cast_df_chunks
from csv_detective.output.profile import create_profile
from csv_detective.output.schema import generate_table_schema
from csv_detective.utils import is_url


def generate_output(
    table: pd.DataFrame,
    analysis: dict,
    file_path: str,
    num_rows: int = 500,
    limited_output: bool = True,
    save_results: bool | str = True,
    output_profile: bool = False,
    output_schema: bool = False,
    output_df: bool = False,
    cast_json: bool = True,
    verbose: bool = False,
    sheet_name: str | int | None = None,
    _col_values: dict[str, pd.Series] | None = None,
) -> dict | tuple[dict, Iterator[pd.DataFrame]]:
    if output_profile:
        analysis["profile"] = create_profile(
            table=table,
            columns=analysis["columns"],
            num_rows=num_rows,
            limited_output=limited_output,
            cast_json=cast_json,
            verbose=verbose,
            _col_values=_col_values,
        )

    if save_results:
        if isinstance(save_results, str):
            output_path = save_results
        else:
            output_path = os.path.splitext(file_path)[0]
            if is_url(output_path):
                output_path = output_path.split("/")[-1]
            if analysis.get("sheet_name"):
                output_path += "_sheet-" + str(sheet_name)
            output_path += ".json"
        with open(output_path, "w", encoding="utf8") as fp:
            json.dump(
                analysis, fp, indent=4, separators=(",", ": "), ensure_ascii=False, default=str
            )

    if output_schema:
        analysis["schema"] = generate_table_schema(analysis, save_results=False, verbose=verbose)

    if output_df:
        return analysis, cast_df_chunks(
            df=table,
            analysis=analysis,
            file_path=file_path,
            cast_json=cast_json,
            verbose=verbose,
        )
    return analysis
