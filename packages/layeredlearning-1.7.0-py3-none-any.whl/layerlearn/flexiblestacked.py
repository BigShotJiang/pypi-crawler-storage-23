import numpy as np
from sklearn.base import BaseEstimator, ClassifierMixin, clone, RegressorMixin

class FlexibleStackedClassifier(BaseEstimator, ClassifierMixin):

    def __init__(self, base_model=None, meta_model=None):

        self.base_model = base_model
        self.meta_model = meta_model

    def _get_base_predictions(self, X):
        # Collect predicted probabilities from all base models
        predictions = []
        for model in self.base_models_:
            predictions.append(model.predict_proba(X))
        return np.hstack(predictions)

    def fit(self, X, y):

        # Support both a single model and a list of models
        if isinstance(self.base_model, list):
            self.base_models_ = [clone(m) for m in self.base_model]
        else:
            self.base_models_ = [clone(self.base_model)]
        self.meta_model_ = clone(self.meta_model)

        # Step 1: Train all base models
        for model in self.base_models_:
            model.fit(X, y)
        
        # Step 2: Get the predicted probabilities from all base models
        base_predictions = self._get_base_predictions(X)
        
        # Step 3: Create the new feature set by combining original features
        # with the base models' predicted probabilities.
        X_meta = np.c_[X, base_predictions]
        
        # Step 4: Train the meta model on the new feature set
        self.meta_model_.fit(X_meta, y)
        
        return self

    def predict(self, X):

        # Get probabilities from all base models and create the meta feature set
        base_predictions = self._get_base_predictions(X)
        X_meta = np.c_[X, base_predictions]
        
        # Make the final prediction using the meta model's .predict() method
        return self.meta_model_.predict(X_meta)

    def predict_proba(self, X):

        # Get probabilities from all base models and create the meta feature set
        base_predictions = self._get_base_predictions(X)
        X_meta = np.c_[X, base_predictions]
        
        # Get the final probabilities from the meta model's .predict_proba() method
        return self.meta_model_.predict_proba(X_meta)
    
class FlexibleStackedRegressor(BaseEstimator, RegressorMixin):
    def __init__(self, base_model, meta_model):

        # Use clone to ensure that the original models are not modified
        # Support both a single model and a list of models
        if isinstance(base_model, list):
            self.base_model = [clone(m) for m in base_model]
        else:
            self.base_model = [clone(base_model)]
        self.meta_model = clone(meta_model)

    def _get_base_predictions(self, X):
        # Collect predictions from all base models
        predictions = []
        for model in self.base_model:
            predictions.append(model.predict(X))
        return np.column_stack(predictions)

    def fit(self, X, y):
        # Step 1: Train all base models
        for model in self.base_model:
            model.fit(X, y)
        
        # Step 2: Get predictions from all base models
        base_predictions = self._get_base_predictions(X)
        
        # Step 3: Create the new feature set by combining original features
        # with the base models' predictions.
        X_meta = np.c_[X, base_predictions]
        
        # Step 4: Train the meta model on the new feature set
        self.meta_model.fit(X_meta, y)
        
        return self

    def predict(self, X):
        # Step 1: Get predictions from all base models
        base_predictions = self._get_base_predictions(X)
        
        # Step 2: Create the meta feature set for prediction
        X_meta = np.c_[X, base_predictions]
        
        # Step 3: Make the final prediction using the meta model
        return self.meta_model.predict(X_meta)