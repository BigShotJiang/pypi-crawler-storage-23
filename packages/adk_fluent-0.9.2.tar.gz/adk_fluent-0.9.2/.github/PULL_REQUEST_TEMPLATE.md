## Summary

<!-- What does this PR do? 1-2 sentences. -->

## Changes

<!-- Bullet list of what changed. -->

-

## Checklist

- [ ] Tests pass (`just test`)
- [ ] Pre-commit hooks pass
- [ ] CHANGELOG.md updated (if user-facing change)
- [ ] Cookbook example added (if new feature)
- [ ] Generator pipeline updated (if touching generated files)
