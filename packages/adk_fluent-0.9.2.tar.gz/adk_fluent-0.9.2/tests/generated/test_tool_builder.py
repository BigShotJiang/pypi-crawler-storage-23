"""Auto-generated builder-mechanics tests. Verify fluent API surface without constructing ADK objects."""

import pytest  # noqa: F401 (used inside test methods)

from adk_fluent.tool import (
    ActiveStreamingTool,
    AgentTool,
    APIHubToolset,
    ApplicationIntegrationToolset,
    BaseAuthenticatedTool,
    BaseRetrievalTool,
    BaseTool,
    BaseToolset,
    BigQueryToolset,
    BigtableToolset,
    CalendarToolset,
    ComputerUseTool,
    ComputerUseToolset,
    DataAgentToolset,
    DiscoveryEngineSearchTool,
    DocsToolset,
    EnterpriseWebSearchTool,
    ExampleTool,
    FunctionTool,
    GmailToolset,
    GoogleApiTool,
    GoogleApiToolset,
    GoogleMapsGroundingTool,
    GoogleSearchAgentTool,
    GoogleSearchTool,
    GoogleTool,
    IntegrationConnectorTool,
    LoadArtifactsTool,
    LoadMcpResourceTool,
    LoadMemoryTool,
    LoadSkillResourceTool,
    LoadSkillTool,
    LongRunningFunctionTool,
    MCPTool,
    McpTool,
    MCPToolset,
    McpToolset,
    OpenAPIToolset,
    PreloadMemoryTool,
    PubSubToolset,
    RestApiTool,
    SetModelResponseTool,
    SheetsToolset,
    SkillToolset,
    SlidesToolset,
    SpannerToolset,
    ToolboxToolset,
    TransferToAgentTool,
    UrlContextTool,
    VertexAiSearchTool,
    YoutubeToolset,
)


class TestActiveStreamingToolBuilder:
    """Tests for ActiveStreamingTool builder mechanics (no .build() calls)."""

    def test_builder_creation(self):
        """Builder constructor stores args in _config."""
        builder = ActiveStreamingTool()
        assert builder is not None
        assert isinstance(builder._config, dict)

    def test_chaining_returns_self(self):
        """.task() returns the builder instance for chaining."""
        builder = ActiveStreamingTool()
        result = builder.task(None)
        assert result is builder

    def test_config_accumulation(self):
        """Setting .task() stores the value in builder._config."""
        builder = ActiveStreamingTool()
        builder.task(None)
        assert builder._config["task"] == None

    def test_typo_detection(self):
        """Typos in method names raise clear AttributeError."""
        builder = ActiveStreamingTool()
        with pytest.raises(AttributeError, match="not a recognized field"):
            builder.zzz_not_a_real_field("oops")


class TestAgentToolBuilder:
    """Tests for AgentTool builder mechanics (no .build() calls)."""

    def test_builder_creation(self):
        """Builder constructor stores args in _config."""
        builder = AgentTool("test_agent")
        assert builder is not None
        assert isinstance(builder._config, dict)

    def test_chaining_returns_self(self):
        """.skip_summarization() returns the builder instance for chaining."""
        builder = AgentTool("test_agent")
        result = builder.skip_summarization(True)
        assert result is builder

    def test_config_accumulation(self):
        """Setting .skip_summarization() stores the value in builder._config."""
        builder = AgentTool("test_agent")
        builder.skip_summarization(True)
        assert builder._config["skip_summarization"] == True

    def test_typo_detection(self):
        """Typos in method names raise clear AttributeError."""
        builder = AgentTool("test_agent")
        with pytest.raises(AttributeError, match="not a recognized parameter"):
            builder.zzz_not_a_real_field("oops")


class TestAPIHubToolsetBuilder:
    """Tests for APIHubToolset builder mechanics (no .build() calls)."""

    def test_builder_creation(self):
        """Builder constructor stores args in _config."""
        builder = APIHubToolset("test_apihub_resource_name")
        assert builder is not None
        assert isinstance(builder._config, dict)

    def test_chaining_returns_self(self):
        """.access_token() returns the builder instance for chaining."""
        builder = APIHubToolset("test_apihub_resource_name")
        result = builder.access_token("test_value")
        assert result is builder

    def test_config_accumulation(self):
        """Setting .access_token() stores the value in builder._config."""
        builder = APIHubToolset("test_apihub_resource_name")
        builder.access_token("test_value")
        assert builder._config["access_token"] == "test_value"

    def test_typo_detection(self):
        """Typos in method names raise clear AttributeError."""
        builder = APIHubToolset("test_apihub_resource_name")
        with pytest.raises(AttributeError, match="not a recognized parameter"):
            builder.zzz_not_a_real_field("oops")


class TestApplicationIntegrationToolsetBuilder:
    """Tests for ApplicationIntegrationToolset builder mechanics (no .build() calls)."""

    def test_builder_creation(self):
        """Builder constructor stores args in _config."""
        builder = ApplicationIntegrationToolset("test_project", "test_location")
        assert builder is not None
        assert isinstance(builder._config, dict)

    def test_chaining_returns_self(self):
        """.connection_template_override() returns the builder instance for chaining."""
        builder = ApplicationIntegrationToolset("test_project", "test_location")
        result = builder.connection_template_override("test_value")
        assert result is builder

    def test_config_accumulation(self):
        """Setting .connection_template_override() stores the value in builder._config."""
        builder = ApplicationIntegrationToolset("test_project", "test_location")
        builder.connection_template_override("test_value")
        assert builder._config["connection_template_override"] == "test_value"

    def test_typo_detection(self):
        """Typos in method names raise clear AttributeError."""
        builder = ApplicationIntegrationToolset("test_project", "test_location")
        with pytest.raises(AttributeError, match="not a recognized parameter"):
            builder.zzz_not_a_real_field("oops")


class TestIntegrationConnectorToolBuilder:
    """Tests for IntegrationConnectorTool builder mechanics (no .build() calls)."""

    def test_builder_creation(self):
        """Builder constructor stores args in _config."""
        builder = IntegrationConnectorTool("test_name", "test_description", "test_connection_name")
        assert builder is not None
        assert isinstance(builder._config, dict)

    def test_chaining_returns_self(self):
        """.connection_host() returns the builder instance for chaining."""
        builder = IntegrationConnectorTool("test_name", "test_description", "test_connection_name")
        result = builder.connection_host("test_value")
        assert result is builder

    def test_config_accumulation(self):
        """Setting .connection_host() stores the value in builder._config."""
        builder = IntegrationConnectorTool("test_name", "test_description", "test_connection_name")
        builder.connection_host("test_value")
        assert builder._config["connection_host"] == "test_value"

    def test_typo_detection(self):
        """Typos in method names raise clear AttributeError."""
        builder = IntegrationConnectorTool("test_name", "test_description", "test_connection_name")
        with pytest.raises(AttributeError, match="not a recognized parameter"):
            builder.zzz_not_a_real_field("oops")


class TestBaseAuthenticatedToolBuilder:
    """Tests for BaseAuthenticatedTool builder mechanics (no .build() calls)."""

    def test_builder_creation(self):
        """Builder constructor stores args in _config."""
        builder = BaseAuthenticatedTool("test_name", "test_description")
        assert builder is not None
        assert isinstance(builder._config, dict)

    def test_chaining_returns_self(self):
        """.response_for_auth_required() returns the builder instance for chaining."""
        builder = BaseAuthenticatedTool("test_name", "test_description")
        result = builder.response_for_auth_required("test_value")
        assert result is builder

    def test_config_accumulation(self):
        """Setting .response_for_auth_required() stores the value in builder._config."""
        builder = BaseAuthenticatedTool("test_name", "test_description")
        builder.response_for_auth_required("test_value")
        assert builder._config["response_for_auth_required"] == "test_value"

    def test_typo_detection(self):
        """Typos in method names raise clear AttributeError."""
        builder = BaseAuthenticatedTool("test_name", "test_description")
        with pytest.raises(AttributeError, match="not a recognized parameter"):
            builder.zzz_not_a_real_field("oops")


class TestBaseToolBuilder:
    """Tests for BaseTool builder mechanics (no .build() calls)."""

    def test_builder_creation(self):
        """Builder constructor stores args in _config."""
        builder = BaseTool("test_name", "test_description")
        assert builder is not None
        assert isinstance(builder._config, dict)

    def test_chaining_returns_self(self):
        """.is_long_running() returns the builder instance for chaining."""
        builder = BaseTool("test_name", "test_description")
        result = builder.is_long_running(True)
        assert result is builder

    def test_config_accumulation(self):
        """Setting .is_long_running() stores the value in builder._config."""
        builder = BaseTool("test_name", "test_description")
        builder.is_long_running(True)
        assert builder._config["is_long_running"] == True

    def test_typo_detection(self):
        """Typos in method names raise clear AttributeError."""
        builder = BaseTool("test_name", "test_description")
        with pytest.raises(AttributeError, match="not a recognized parameter"):
            builder.zzz_not_a_real_field("oops")


class TestBaseToolsetBuilder:
    """Tests for BaseToolset builder mechanics (no .build() calls)."""

    def test_builder_creation(self):
        """Builder constructor stores args in _config."""
        builder = BaseToolset()
        assert builder is not None
        assert isinstance(builder._config, dict)

    def test_chaining_returns_self(self):
        """.tool_filter() returns the builder instance for chaining."""
        builder = BaseToolset()
        result = builder.tool_filter(None)
        assert result is builder

    def test_config_accumulation(self):
        """Setting .tool_filter() stores the value in builder._config."""
        builder = BaseToolset()
        builder.tool_filter(None)
        assert builder._config["tool_filter"] == None

    def test_typo_detection(self):
        """Typos in method names raise clear AttributeError."""
        builder = BaseToolset()
        with pytest.raises(AttributeError, match="not a recognized parameter"):
            builder.zzz_not_a_real_field("oops")


class TestBigQueryToolsetBuilder:
    """Tests for BigQueryToolset builder mechanics (no .build() calls)."""

    def test_builder_creation(self):
        """Builder constructor stores args in _config."""
        builder = BigQueryToolset()
        assert builder is not None
        assert isinstance(builder._config, dict)

    def test_chaining_returns_self(self):
        """.tool_filter() returns the builder instance for chaining."""
        builder = BigQueryToolset()
        result = builder.tool_filter(None)
        assert result is builder

    def test_config_accumulation(self):
        """Setting .tool_filter() stores the value in builder._config."""
        builder = BigQueryToolset()
        builder.tool_filter(None)
        assert builder._config["tool_filter"] == None

    def test_typo_detection(self):
        """Typos in method names raise clear AttributeError."""
        builder = BigQueryToolset()
        with pytest.raises(AttributeError, match="not a recognized parameter"):
            builder.zzz_not_a_real_field("oops")


class TestBigtableToolsetBuilder:
    """Tests for BigtableToolset builder mechanics (no .build() calls)."""

    def test_builder_creation(self):
        """Builder constructor stores args in _config."""
        builder = BigtableToolset()
        assert builder is not None
        assert isinstance(builder._config, dict)

    def test_chaining_returns_self(self):
        """.tool_filter() returns the builder instance for chaining."""
        builder = BigtableToolset()
        result = builder.tool_filter(None)
        assert result is builder

    def test_config_accumulation(self):
        """Setting .tool_filter() stores the value in builder._config."""
        builder = BigtableToolset()
        builder.tool_filter(None)
        assert builder._config["tool_filter"] == None

    def test_typo_detection(self):
        """Typos in method names raise clear AttributeError."""
        builder = BigtableToolset()
        with pytest.raises(AttributeError, match="not a recognized parameter"):
            builder.zzz_not_a_real_field("oops")


class TestComputerUseToolBuilder:
    """Tests for ComputerUseTool builder mechanics (no .build() calls)."""

    def test_builder_creation(self):
        """Builder constructor stores args in _config."""
        builder = ComputerUseTool("test_func", "test_screen_size")
        assert builder is not None
        assert isinstance(builder._config, dict)

    def test_typo_detection(self):
        """Typos in method names raise clear AttributeError."""
        builder = ComputerUseTool("test_func", "test_screen_size")
        with pytest.raises(AttributeError, match="not a recognized parameter"):
            builder.zzz_not_a_real_field("oops")


class TestComputerUseToolsetBuilder:
    """Tests for ComputerUseToolset builder mechanics (no .build() calls)."""

    def test_builder_creation(self):
        """Builder constructor stores args in _config."""
        builder = ComputerUseToolset("test_computer")
        assert builder is not None
        assert isinstance(builder._config, dict)

    def test_typo_detection(self):
        """Typos in method names raise clear AttributeError."""
        builder = ComputerUseToolset("test_computer")
        with pytest.raises(AttributeError, match="not a recognized parameter"):
            builder.zzz_not_a_real_field("oops")


class TestDataAgentToolsetBuilder:
    """Tests for DataAgentToolset builder mechanics (no .build() calls)."""

    def test_builder_creation(self):
        """Builder constructor stores args in _config."""
        builder = DataAgentToolset()
        assert builder is not None
        assert isinstance(builder._config, dict)

    def test_chaining_returns_self(self):
        """.tool_filter() returns the builder instance for chaining."""
        builder = DataAgentToolset()
        result = builder.tool_filter(None)
        assert result is builder

    def test_config_accumulation(self):
        """Setting .tool_filter() stores the value in builder._config."""
        builder = DataAgentToolset()
        builder.tool_filter(None)
        assert builder._config["tool_filter"] == None

    def test_typo_detection(self):
        """Typos in method names raise clear AttributeError."""
        builder = DataAgentToolset()
        with pytest.raises(AttributeError, match="not a recognized parameter"):
            builder.zzz_not_a_real_field("oops")


class TestDiscoveryEngineSearchToolBuilder:
    """Tests for DiscoveryEngineSearchTool builder mechanics (no .build() calls)."""

    def test_builder_creation(self):
        """Builder constructor stores args in _config."""
        builder = DiscoveryEngineSearchTool()
        assert builder is not None
        assert isinstance(builder._config, dict)

    def test_chaining_returns_self(self):
        """.data_store_id() returns the builder instance for chaining."""
        builder = DiscoveryEngineSearchTool()
        result = builder.data_store_id("test_value")
        assert result is builder

    def test_config_accumulation(self):
        """Setting .data_store_id() stores the value in builder._config."""
        builder = DiscoveryEngineSearchTool()
        builder.data_store_id("test_value")
        assert builder._config["data_store_id"] == "test_value"

    def test_typo_detection(self):
        """Typos in method names raise clear AttributeError."""
        builder = DiscoveryEngineSearchTool()
        with pytest.raises(AttributeError, match="not a recognized parameter"):
            builder.zzz_not_a_real_field("oops")


class TestEnterpriseWebSearchToolBuilder:
    """Tests for EnterpriseWebSearchTool builder mechanics (no .build() calls)."""

    def test_builder_creation(self):
        """Builder constructor stores args in _config."""
        builder = EnterpriseWebSearchTool()
        assert builder is not None
        assert isinstance(builder._config, dict)

    def test_typo_detection(self):
        """Typos in method names raise clear AttributeError."""
        builder = EnterpriseWebSearchTool()
        with pytest.raises(AttributeError, match="not a recognized parameter"):
            builder.zzz_not_a_real_field("oops")


class TestExampleToolBuilder:
    """Tests for ExampleTool builder mechanics (no .build() calls)."""

    def test_builder_creation(self):
        """Builder constructor stores args in _config."""
        builder = ExampleTool("test_examples")
        assert builder is not None
        assert isinstance(builder._config, dict)

    def test_typo_detection(self):
        """Typos in method names raise clear AttributeError."""
        builder = ExampleTool("test_examples")
        with pytest.raises(AttributeError, match="not a recognized parameter"):
            builder.zzz_not_a_real_field("oops")


class TestFunctionToolBuilder:
    """Tests for FunctionTool builder mechanics (no .build() calls)."""

    def test_builder_creation(self):
        """Builder constructor stores args in _config."""
        builder = FunctionTool("test_func")
        assert builder is not None
        assert isinstance(builder._config, dict)

    def test_typo_detection(self):
        """Typos in method names raise clear AttributeError."""
        builder = FunctionTool("test_func")
        with pytest.raises(AttributeError, match="not a recognized parameter"):
            builder.zzz_not_a_real_field("oops")


class TestGoogleApiToolBuilder:
    """Tests for GoogleApiTool builder mechanics (no .build() calls)."""

    def test_builder_creation(self):
        """Builder constructor stores args in _config."""
        builder = GoogleApiTool("test_rest_api_tool")
        assert builder is not None
        assert isinstance(builder._config, dict)

    def test_chaining_returns_self(self):
        """.client_id() returns the builder instance for chaining."""
        builder = GoogleApiTool("test_rest_api_tool")
        result = builder.client_id("test_value")
        assert result is builder

    def test_config_accumulation(self):
        """Setting .client_id() stores the value in builder._config."""
        builder = GoogleApiTool("test_rest_api_tool")
        builder.client_id("test_value")
        assert builder._config["client_id"] == "test_value"

    def test_typo_detection(self):
        """Typos in method names raise clear AttributeError."""
        builder = GoogleApiTool("test_rest_api_tool")
        with pytest.raises(AttributeError, match="not a recognized parameter"):
            builder.zzz_not_a_real_field("oops")


class TestGoogleApiToolsetBuilder:
    """Tests for GoogleApiToolset builder mechanics (no .build() calls)."""

    def test_builder_creation(self):
        """Builder constructor stores args in _config."""
        builder = GoogleApiToolset("test_api_name", "test_api_version")
        assert builder is not None
        assert isinstance(builder._config, dict)

    def test_chaining_returns_self(self):
        """.client_id() returns the builder instance for chaining."""
        builder = GoogleApiToolset("test_api_name", "test_api_version")
        result = builder.client_id("test_value")
        assert result is builder

    def test_config_accumulation(self):
        """Setting .client_id() stores the value in builder._config."""
        builder = GoogleApiToolset("test_api_name", "test_api_version")
        builder.client_id("test_value")
        assert builder._config["client_id"] == "test_value"

    def test_typo_detection(self):
        """Typos in method names raise clear AttributeError."""
        builder = GoogleApiToolset("test_api_name", "test_api_version")
        with pytest.raises(AttributeError, match="not a recognized parameter"):
            builder.zzz_not_a_real_field("oops")


class TestCalendarToolsetBuilder:
    """Tests for CalendarToolset builder mechanics (no .build() calls)."""

    def test_builder_creation(self):
        """Builder constructor stores args in _config."""
        builder = CalendarToolset()
        assert builder is not None
        assert isinstance(builder._config, dict)

    def test_chaining_returns_self(self):
        """.client_id() returns the builder instance for chaining."""
        builder = CalendarToolset()
        result = builder.client_id("test_value")
        assert result is builder

    def test_config_accumulation(self):
        """Setting .client_id() stores the value in builder._config."""
        builder = CalendarToolset()
        builder.client_id("test_value")
        assert builder._config["client_id"] == "test_value"

    def test_typo_detection(self):
        """Typos in method names raise clear AttributeError."""
        builder = CalendarToolset()
        with pytest.raises(AttributeError, match="not a recognized parameter"):
            builder.zzz_not_a_real_field("oops")


class TestDocsToolsetBuilder:
    """Tests for DocsToolset builder mechanics (no .build() calls)."""

    def test_builder_creation(self):
        """Builder constructor stores args in _config."""
        builder = DocsToolset()
        assert builder is not None
        assert isinstance(builder._config, dict)

    def test_chaining_returns_self(self):
        """.client_id() returns the builder instance for chaining."""
        builder = DocsToolset()
        result = builder.client_id("test_value")
        assert result is builder

    def test_config_accumulation(self):
        """Setting .client_id() stores the value in builder._config."""
        builder = DocsToolset()
        builder.client_id("test_value")
        assert builder._config["client_id"] == "test_value"

    def test_typo_detection(self):
        """Typos in method names raise clear AttributeError."""
        builder = DocsToolset()
        with pytest.raises(AttributeError, match="not a recognized parameter"):
            builder.zzz_not_a_real_field("oops")


class TestGmailToolsetBuilder:
    """Tests for GmailToolset builder mechanics (no .build() calls)."""

    def test_builder_creation(self):
        """Builder constructor stores args in _config."""
        builder = GmailToolset()
        assert builder is not None
        assert isinstance(builder._config, dict)

    def test_chaining_returns_self(self):
        """.client_id() returns the builder instance for chaining."""
        builder = GmailToolset()
        result = builder.client_id("test_value")
        assert result is builder

    def test_config_accumulation(self):
        """Setting .client_id() stores the value in builder._config."""
        builder = GmailToolset()
        builder.client_id("test_value")
        assert builder._config["client_id"] == "test_value"

    def test_typo_detection(self):
        """Typos in method names raise clear AttributeError."""
        builder = GmailToolset()
        with pytest.raises(AttributeError, match="not a recognized parameter"):
            builder.zzz_not_a_real_field("oops")


class TestSheetsToolsetBuilder:
    """Tests for SheetsToolset builder mechanics (no .build() calls)."""

    def test_builder_creation(self):
        """Builder constructor stores args in _config."""
        builder = SheetsToolset()
        assert builder is not None
        assert isinstance(builder._config, dict)

    def test_chaining_returns_self(self):
        """.client_id() returns the builder instance for chaining."""
        builder = SheetsToolset()
        result = builder.client_id("test_value")
        assert result is builder

    def test_config_accumulation(self):
        """Setting .client_id() stores the value in builder._config."""
        builder = SheetsToolset()
        builder.client_id("test_value")
        assert builder._config["client_id"] == "test_value"

    def test_typo_detection(self):
        """Typos in method names raise clear AttributeError."""
        builder = SheetsToolset()
        with pytest.raises(AttributeError, match="not a recognized parameter"):
            builder.zzz_not_a_real_field("oops")


class TestSlidesToolsetBuilder:
    """Tests for SlidesToolset builder mechanics (no .build() calls)."""

    def test_builder_creation(self):
        """Builder constructor stores args in _config."""
        builder = SlidesToolset()
        assert builder is not None
        assert isinstance(builder._config, dict)

    def test_chaining_returns_self(self):
        """.client_id() returns the builder instance for chaining."""
        builder = SlidesToolset()
        result = builder.client_id("test_value")
        assert result is builder

    def test_config_accumulation(self):
        """Setting .client_id() stores the value in builder._config."""
        builder = SlidesToolset()
        builder.client_id("test_value")
        assert builder._config["client_id"] == "test_value"

    def test_typo_detection(self):
        """Typos in method names raise clear AttributeError."""
        builder = SlidesToolset()
        with pytest.raises(AttributeError, match="not a recognized parameter"):
            builder.zzz_not_a_real_field("oops")


class TestYoutubeToolsetBuilder:
    """Tests for YoutubeToolset builder mechanics (no .build() calls)."""

    def test_builder_creation(self):
        """Builder constructor stores args in _config."""
        builder = YoutubeToolset()
        assert builder is not None
        assert isinstance(builder._config, dict)

    def test_chaining_returns_self(self):
        """.client_id() returns the builder instance for chaining."""
        builder = YoutubeToolset()
        result = builder.client_id("test_value")
        assert result is builder

    def test_config_accumulation(self):
        """Setting .client_id() stores the value in builder._config."""
        builder = YoutubeToolset()
        builder.client_id("test_value")
        assert builder._config["client_id"] == "test_value"

    def test_typo_detection(self):
        """Typos in method names raise clear AttributeError."""
        builder = YoutubeToolset()
        with pytest.raises(AttributeError, match="not a recognized parameter"):
            builder.zzz_not_a_real_field("oops")


class TestGoogleMapsGroundingToolBuilder:
    """Tests for GoogleMapsGroundingTool builder mechanics (no .build() calls)."""

    def test_builder_creation(self):
        """Builder constructor stores args in _config."""
        builder = GoogleMapsGroundingTool()
        assert builder is not None
        assert isinstance(builder._config, dict)

    def test_typo_detection(self):
        """Typos in method names raise clear AttributeError."""
        builder = GoogleMapsGroundingTool()
        with pytest.raises(AttributeError, match="not a recognized parameter"):
            builder.zzz_not_a_real_field("oops")


class TestGoogleSearchAgentToolBuilder:
    """Tests for GoogleSearchAgentTool builder mechanics (no .build() calls)."""

    def test_builder_creation(self):
        """Builder constructor stores args in _config."""
        builder = GoogleSearchAgentTool("test_agent")
        assert builder is not None
        assert isinstance(builder._config, dict)

    def test_typo_detection(self):
        """Typos in method names raise clear AttributeError."""
        builder = GoogleSearchAgentTool("test_agent")
        with pytest.raises(AttributeError, match="not a recognized parameter"):
            builder.zzz_not_a_real_field("oops")


class TestGoogleSearchToolBuilder:
    """Tests for GoogleSearchTool builder mechanics (no .build() calls)."""

    def test_builder_creation(self):
        """Builder constructor stores args in _config."""
        builder = GoogleSearchTool()
        assert builder is not None
        assert isinstance(builder._config, dict)

    def test_chaining_returns_self(self):
        """.bypass_multi_tools_limit() returns the builder instance for chaining."""
        builder = GoogleSearchTool()
        result = builder.bypass_multi_tools_limit(True)
        assert result is builder

    def test_config_accumulation(self):
        """Setting .bypass_multi_tools_limit() stores the value in builder._config."""
        builder = GoogleSearchTool()
        builder.bypass_multi_tools_limit(True)
        assert builder._config["bypass_multi_tools_limit"] == True

    def test_typo_detection(self):
        """Typos in method names raise clear AttributeError."""
        builder = GoogleSearchTool()
        with pytest.raises(AttributeError, match="not a recognized parameter"):
            builder.zzz_not_a_real_field("oops")


class TestGoogleToolBuilder:
    """Tests for GoogleTool builder mechanics (no .build() calls)."""

    def test_builder_creation(self):
        """Builder constructor stores args in _config."""
        builder = GoogleTool("test_func")
        assert builder is not None
        assert isinstance(builder._config, dict)

    def test_chaining_returns_self(self):
        """.credentials_config() returns the builder instance for chaining."""
        builder = GoogleTool("test_func")
        result = builder.credentials_config(None)
        assert result is builder

    def test_config_accumulation(self):
        """Setting .credentials_config() stores the value in builder._config."""
        builder = GoogleTool("test_func")
        builder.credentials_config(None)
        assert builder._config["credentials_config"] == None

    def test_typo_detection(self):
        """Typos in method names raise clear AttributeError."""
        builder = GoogleTool("test_func")
        with pytest.raises(AttributeError, match="not a recognized parameter"):
            builder.zzz_not_a_real_field("oops")


class TestLoadArtifactsToolBuilder:
    """Tests for LoadArtifactsTool builder mechanics (no .build() calls)."""

    def test_builder_creation(self):
        """Builder constructor stores args in _config."""
        builder = LoadArtifactsTool()
        assert builder is not None
        assert isinstance(builder._config, dict)

    def test_typo_detection(self):
        """Typos in method names raise clear AttributeError."""
        builder = LoadArtifactsTool()
        with pytest.raises(AttributeError, match="not a recognized parameter"):
            builder.zzz_not_a_real_field("oops")


class TestLoadMcpResourceToolBuilder:
    """Tests for LoadMcpResourceTool builder mechanics (no .build() calls)."""

    def test_builder_creation(self):
        """Builder constructor stores args in _config."""
        builder = LoadMcpResourceTool("test_mcp_toolset")
        assert builder is not None
        assert isinstance(builder._config, dict)

    def test_typo_detection(self):
        """Typos in method names raise clear AttributeError."""
        builder = LoadMcpResourceTool("test_mcp_toolset")
        with pytest.raises(AttributeError, match="not a recognized parameter"):
            builder.zzz_not_a_real_field("oops")


class TestLoadMemoryToolBuilder:
    """Tests for LoadMemoryTool builder mechanics (no .build() calls)."""

    def test_builder_creation(self):
        """Builder constructor stores args in _config."""
        builder = LoadMemoryTool()
        assert builder is not None
        assert isinstance(builder._config, dict)

    def test_typo_detection(self):
        """Typos in method names raise clear AttributeError."""
        builder = LoadMemoryTool()
        with pytest.raises(AttributeError, match="not a recognized parameter"):
            builder.zzz_not_a_real_field("oops")


class TestLongRunningFunctionToolBuilder:
    """Tests for LongRunningFunctionTool builder mechanics (no .build() calls)."""

    def test_builder_creation(self):
        """Builder constructor stores args in _config."""
        builder = LongRunningFunctionTool("test_func")
        assert builder is not None
        assert isinstance(builder._config, dict)

    def test_typo_detection(self):
        """Typos in method names raise clear AttributeError."""
        builder = LongRunningFunctionTool("test_func")
        with pytest.raises(AttributeError, match="not a recognized parameter"):
            builder.zzz_not_a_real_field("oops")


class TestMCPToolBuilder:
    """Tests for MCPTool builder mechanics (no .build() calls)."""

    def test_builder_creation(self):
        """Builder constructor stores args in _config."""
        builder = MCPTool("test_args", "test_kwargs")
        assert builder is not None
        assert isinstance(builder._config, dict)

    def test_typo_detection(self):
        """Typos in method names raise clear AttributeError."""
        builder = MCPTool("test_args", "test_kwargs")
        with pytest.raises(AttributeError, match="not a recognized parameter"):
            builder.zzz_not_a_real_field("oops")


class TestMcpToolBuilder:
    """Tests for McpTool builder mechanics (no .build() calls)."""

    def test_builder_creation(self):
        """Builder constructor stores args in _config."""
        builder = McpTool("test_mcp_tool", "test_mcp_session_manager")
        assert builder is not None
        assert isinstance(builder._config, dict)

    def test_chaining_returns_self(self):
        """.auth_scheme() returns the builder instance for chaining."""
        builder = McpTool("test_mcp_tool", "test_mcp_session_manager")
        result = builder.auth_scheme(None)
        assert result is builder

    def test_config_accumulation(self):
        """Setting .auth_scheme() stores the value in builder._config."""
        builder = McpTool("test_mcp_tool", "test_mcp_session_manager")
        builder.auth_scheme(None)
        assert builder._config["auth_scheme"] == None

    def test_typo_detection(self):
        """Typos in method names raise clear AttributeError."""
        builder = McpTool("test_mcp_tool", "test_mcp_session_manager")
        with pytest.raises(AttributeError, match="not a recognized parameter"):
            builder.zzz_not_a_real_field("oops")


class TestMCPToolsetBuilder:
    """Tests for MCPToolset builder mechanics (no .build() calls)."""

    def test_builder_creation(self):
        """Builder constructor stores args in _config."""
        builder = MCPToolset("test_args", "test_kwargs")
        assert builder is not None
        assert isinstance(builder._config, dict)

    def test_typo_detection(self):
        """Typos in method names raise clear AttributeError."""
        builder = MCPToolset("test_args", "test_kwargs")
        with pytest.raises(AttributeError, match="not a recognized parameter"):
            builder.zzz_not_a_real_field("oops")


class TestMcpToolsetBuilder:
    """Tests for McpToolset builder mechanics (no .build() calls)."""

    def test_builder_creation(self):
        """Builder constructor stores args in _config."""
        builder = McpToolset("test_connection_params")
        assert builder is not None
        assert isinstance(builder._config, dict)

    def test_chaining_returns_self(self):
        """.tool_filter() returns the builder instance for chaining."""
        builder = McpToolset("test_connection_params")
        result = builder.tool_filter(None)
        assert result is builder

    def test_config_accumulation(self):
        """Setting .tool_filter() stores the value in builder._config."""
        builder = McpToolset("test_connection_params")
        builder.tool_filter(None)
        assert builder._config["tool_filter"] == None

    def test_typo_detection(self):
        """Typos in method names raise clear AttributeError."""
        builder = McpToolset("test_connection_params")
        with pytest.raises(AttributeError, match="not a recognized parameter"):
            builder.zzz_not_a_real_field("oops")


class TestOpenAPIToolsetBuilder:
    """Tests for OpenAPIToolset builder mechanics (no .build() calls)."""

    def test_builder_creation(self):
        """Builder constructor stores args in _config."""
        builder = OpenAPIToolset()
        assert builder is not None
        assert isinstance(builder._config, dict)

    def test_chaining_returns_self(self):
        """.spec_dict() returns the builder instance for chaining."""
        builder = OpenAPIToolset()
        result = builder.spec_dict({})
        assert result is builder

    def test_config_accumulation(self):
        """Setting .spec_dict() stores the value in builder._config."""
        builder = OpenAPIToolset()
        builder.spec_dict({})
        assert builder._config["spec_dict"] == {}

    def test_typo_detection(self):
        """Typos in method names raise clear AttributeError."""
        builder = OpenAPIToolset()
        with pytest.raises(AttributeError, match="not a recognized parameter"):
            builder.zzz_not_a_real_field("oops")


class TestRestApiToolBuilder:
    """Tests for RestApiTool builder mechanics (no .build() calls)."""

    def test_builder_creation(self):
        """Builder constructor stores args in _config."""
        builder = RestApiTool("test_name", "test_description", "test_endpoint")
        assert builder is not None
        assert isinstance(builder._config, dict)

    def test_chaining_returns_self(self):
        """.operation() returns the builder instance for chaining."""
        builder = RestApiTool("test_name", "test_description", "test_endpoint")
        result = builder.operation("test_value")
        assert result is builder

    def test_config_accumulation(self):
        """Setting .operation() stores the value in builder._config."""
        builder = RestApiTool("test_name", "test_description", "test_endpoint")
        builder.operation("test_value")
        assert builder._config["operation"] == "test_value"

    def test_typo_detection(self):
        """Typos in method names raise clear AttributeError."""
        builder = RestApiTool("test_name", "test_description", "test_endpoint")
        with pytest.raises(AttributeError, match="not a recognized parameter"):
            builder.zzz_not_a_real_field("oops")


class TestPreloadMemoryToolBuilder:
    """Tests for PreloadMemoryTool builder mechanics (no .build() calls)."""

    def test_builder_creation(self):
        """Builder constructor stores args in _config."""
        builder = PreloadMemoryTool()
        assert builder is not None
        assert isinstance(builder._config, dict)

    def test_typo_detection(self):
        """Typos in method names raise clear AttributeError."""
        builder = PreloadMemoryTool()
        with pytest.raises(AttributeError, match="not a recognized parameter"):
            builder.zzz_not_a_real_field("oops")


class TestPubSubToolsetBuilder:
    """Tests for PubSubToolset builder mechanics (no .build() calls)."""

    def test_builder_creation(self):
        """Builder constructor stores args in _config."""
        builder = PubSubToolset()
        assert builder is not None
        assert isinstance(builder._config, dict)

    def test_chaining_returns_self(self):
        """.tool_filter() returns the builder instance for chaining."""
        builder = PubSubToolset()
        result = builder.tool_filter(None)
        assert result is builder

    def test_config_accumulation(self):
        """Setting .tool_filter() stores the value in builder._config."""
        builder = PubSubToolset()
        builder.tool_filter(None)
        assert builder._config["tool_filter"] == None

    def test_typo_detection(self):
        """Typos in method names raise clear AttributeError."""
        builder = PubSubToolset()
        with pytest.raises(AttributeError, match="not a recognized parameter"):
            builder.zzz_not_a_real_field("oops")


class TestBaseRetrievalToolBuilder:
    """Tests for BaseRetrievalTool builder mechanics (no .build() calls)."""

    def test_builder_creation(self):
        """Builder constructor stores args in _config."""
        builder = BaseRetrievalTool("test_name", "test_description")
        assert builder is not None
        assert isinstance(builder._config, dict)

    def test_chaining_returns_self(self):
        """.is_long_running() returns the builder instance for chaining."""
        builder = BaseRetrievalTool("test_name", "test_description")
        result = builder.is_long_running(True)
        assert result is builder

    def test_config_accumulation(self):
        """Setting .is_long_running() stores the value in builder._config."""
        builder = BaseRetrievalTool("test_name", "test_description")
        builder.is_long_running(True)
        assert builder._config["is_long_running"] == True

    def test_typo_detection(self):
        """Typos in method names raise clear AttributeError."""
        builder = BaseRetrievalTool("test_name", "test_description")
        with pytest.raises(AttributeError, match="not a recognized parameter"):
            builder.zzz_not_a_real_field("oops")


class TestSetModelResponseToolBuilder:
    """Tests for SetModelResponseTool builder mechanics (no .build() calls)."""

    def test_builder_creation(self):
        """Builder constructor stores args in _config."""
        builder = SetModelResponseTool("test_output_schema")
        assert builder is not None
        assert isinstance(builder._config, dict)

    def test_typo_detection(self):
        """Typos in method names raise clear AttributeError."""
        builder = SetModelResponseTool("test_output_schema")
        with pytest.raises(AttributeError, match="not a recognized parameter"):
            builder.zzz_not_a_real_field("oops")


class TestLoadSkillResourceToolBuilder:
    """Tests for LoadSkillResourceTool builder mechanics (no .build() calls)."""

    def test_builder_creation(self):
        """Builder constructor stores args in _config."""
        builder = LoadSkillResourceTool("test_toolset")
        assert builder is not None
        assert isinstance(builder._config, dict)

    def test_typo_detection(self):
        """Typos in method names raise clear AttributeError."""
        builder = LoadSkillResourceTool("test_toolset")
        with pytest.raises(AttributeError, match="not a recognized parameter"):
            builder.zzz_not_a_real_field("oops")


class TestLoadSkillToolBuilder:
    """Tests for LoadSkillTool builder mechanics (no .build() calls)."""

    def test_builder_creation(self):
        """Builder constructor stores args in _config."""
        builder = LoadSkillTool("test_toolset")
        assert builder is not None
        assert isinstance(builder._config, dict)

    def test_typo_detection(self):
        """Typos in method names raise clear AttributeError."""
        builder = LoadSkillTool("test_toolset")
        with pytest.raises(AttributeError, match="not a recognized parameter"):
            builder.zzz_not_a_real_field("oops")


class TestSkillToolsetBuilder:
    """Tests for SkillToolset builder mechanics (no .build() calls)."""

    def test_builder_creation(self):
        """Builder constructor stores args in _config."""
        builder = SkillToolset("test_skills")
        assert builder is not None
        assert isinstance(builder._config, dict)

    def test_typo_detection(self):
        """Typos in method names raise clear AttributeError."""
        builder = SkillToolset("test_skills")
        with pytest.raises(AttributeError, match="not a recognized parameter"):
            builder.zzz_not_a_real_field("oops")


class TestSpannerToolsetBuilder:
    """Tests for SpannerToolset builder mechanics (no .build() calls)."""

    def test_builder_creation(self):
        """Builder constructor stores args in _config."""
        builder = SpannerToolset()
        assert builder is not None
        assert isinstance(builder._config, dict)

    def test_chaining_returns_self(self):
        """.tool_filter() returns the builder instance for chaining."""
        builder = SpannerToolset()
        result = builder.tool_filter(None)
        assert result is builder

    def test_config_accumulation(self):
        """Setting .tool_filter() stores the value in builder._config."""
        builder = SpannerToolset()
        builder.tool_filter(None)
        assert builder._config["tool_filter"] == None

    def test_typo_detection(self):
        """Typos in method names raise clear AttributeError."""
        builder = SpannerToolset()
        with pytest.raises(AttributeError, match="not a recognized parameter"):
            builder.zzz_not_a_real_field("oops")


class TestToolboxToolsetBuilder:
    """Tests for ToolboxToolset builder mechanics (no .build() calls)."""

    def test_builder_creation(self):
        """Builder constructor stores args in _config."""
        builder = ToolboxToolset("test_server_url", "test_kwargs")
        assert builder is not None
        assert isinstance(builder._config, dict)

    def test_chaining_returns_self(self):
        """.toolset_name() returns the builder instance for chaining."""
        builder = ToolboxToolset("test_server_url", "test_kwargs")
        result = builder.toolset_name("test_value")
        assert result is builder

    def test_config_accumulation(self):
        """Setting .toolset_name() stores the value in builder._config."""
        builder = ToolboxToolset("test_server_url", "test_kwargs")
        builder.toolset_name("test_value")
        assert builder._config["toolset_name"] == "test_value"

    def test_typo_detection(self):
        """Typos in method names raise clear AttributeError."""
        builder = ToolboxToolset("test_server_url", "test_kwargs")
        with pytest.raises(AttributeError, match="not a recognized parameter"):
            builder.zzz_not_a_real_field("oops")


class TestTransferToAgentToolBuilder:
    """Tests for TransferToAgentTool builder mechanics (no .build() calls)."""

    def test_builder_creation(self):
        """Builder constructor stores args in _config."""
        builder = TransferToAgentTool("test_agent_names")
        assert builder is not None
        assert isinstance(builder._config, dict)

    def test_typo_detection(self):
        """Typos in method names raise clear AttributeError."""
        builder = TransferToAgentTool("test_agent_names")
        with pytest.raises(AttributeError, match="not a recognized parameter"):
            builder.zzz_not_a_real_field("oops")


class TestUrlContextToolBuilder:
    """Tests for UrlContextTool builder mechanics (no .build() calls)."""

    def test_builder_creation(self):
        """Builder constructor stores args in _config."""
        builder = UrlContextTool()
        assert builder is not None
        assert isinstance(builder._config, dict)

    def test_typo_detection(self):
        """Typos in method names raise clear AttributeError."""
        builder = UrlContextTool()
        with pytest.raises(AttributeError, match="not a recognized parameter"):
            builder.zzz_not_a_real_field("oops")


class TestVertexAiSearchToolBuilder:
    """Tests for VertexAiSearchTool builder mechanics (no .build() calls)."""

    def test_builder_creation(self):
        """Builder constructor stores args in _config."""
        builder = VertexAiSearchTool()
        assert builder is not None
        assert isinstance(builder._config, dict)

    def test_chaining_returns_self(self):
        """.data_store_id() returns the builder instance for chaining."""
        builder = VertexAiSearchTool()
        result = builder.data_store_id("test_value")
        assert result is builder

    def test_config_accumulation(self):
        """Setting .data_store_id() stores the value in builder._config."""
        builder = VertexAiSearchTool()
        builder.data_store_id("test_value")
        assert builder._config["data_store_id"] == "test_value"

    def test_typo_detection(self):
        """Typos in method names raise clear AttributeError."""
        builder = VertexAiSearchTool()
        with pytest.raises(AttributeError, match="not a recognized parameter"):
            builder.zzz_not_a_real_field("oops")
