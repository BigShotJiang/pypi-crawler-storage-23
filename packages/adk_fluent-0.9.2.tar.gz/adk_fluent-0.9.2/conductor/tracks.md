# Project Tracks

This file tracks all major tracks for the project. Each track has its own detailed plan in its respective folder.

______________________________________________________________________

- [ ] **Track: Implement v5.1 Phase B: C Atoms (SELECT, COMPRESS, BUDGET primitives - No LLM)**
  *Link: [./tracks/c_atoms_phase_b_20260220/](./tracks/c_atoms_phase_b_20260220/)*
