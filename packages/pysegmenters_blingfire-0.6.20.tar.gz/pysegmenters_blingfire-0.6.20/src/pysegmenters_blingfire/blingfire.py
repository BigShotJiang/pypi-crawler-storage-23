from abc import ABC

from blingfire import text_to_sentences_and_offsets
from pydantic import BaseModel
from pymultirole_plugins.v1.schema import Document, Sentence
from pymultirole_plugins.v1.segmenter import SegmenterBase, SegmenterParameters


class BlingFireParameters(SegmenterParameters, ABC):
    pass


class BlingFireSegmenter(SegmenterBase, ABC):
    """[BlingFire](https://github.com/microsoft/BlingFire) segmenter."""

    def segment(
        self,
        documents: list[Document],
        parameters: SegmenterParameters,  # noqa: ARG002
    ) -> list[Document]:
        for document in documents:
            document.sentences = []
            if not document.text:
                continue
            result = text_to_sentences_and_offsets(document.text)
            if result:
                for start, end in result[1]:
                    document.sentences.append(Sentence(start=start, end=end))
        return documents

    @classmethod
    def get_model(cls) -> type[BaseModel]:
        return BlingFireParameters
