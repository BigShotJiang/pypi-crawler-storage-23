import os
from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from logging.handlers import RotatingFileHandler
from typing import TypeAlias

import orjson
from aiohttp import (
    BasicAuth,
    ClientConnectorError,
    ClientOSError,
    ClientSession,
    ClientTimeout,
    ServerDisconnectedError,
)

from .abc import AbstractRetryTimer, Communicator
from .config import ClientConfig
from .log import INFO, TRACE, StructuredLogger
from .types import ClientStatus, JsonDict, JsonValue

# HTTP method, HTTP path, JSON payload, metadata
HttpRequestData: TypeAlias = tuple[str, str, JsonDict | None, JsonDict | None]


@dataclass
class HttpClient(Communicator[HttpRequestData | None]):
    config: ClientConfig  # Client configuration
    logger: StructuredLogger  # Logger instance
    retry_timer: AbstractRetryTimer  # Retry timer for connection attempts
    timeout: int = 0  # Request timeout (in seconds)
    converter: Callable[[HttpRequestData], Awaitable[HttpRequestData]] | None = (
        None  # Message converter
    )
    init: Callable[['HttpClient'], Awaitable[None]] | None = None  # Initializer coroutine
    hook: Callable[[JsonValue | Exception, JsonDict | None], Awaitable[None]] | None = (
        None  # Coroutine to handle request result
    )

    def __post_init__(self) -> None:
        super().__post_init__()
        self._status: ClientStatus = ClientStatus.UNINITIALIZED
        kwargs = {}
        if self.timeout:
            kwargs['timeout'] = ClientTimeout(total=self.timeout)  # In seconds
        if self.config.client_user:
            kwargs['auth'] = BasicAuth(self.config.client_user, self.config.client_pswd, 'utf-8')
        self._session = ClientSession(**kwargs)
        self._request_counter = 0
        self._logger_trace: StructuredLogger | None = None
        if self.logger.isEnabledFor(TRACE) and self.config.comm_log:
            logger_name: str = 'http_' + self.name
            self._logger_trace = StructuredLogger(
                logger_name=logger_name,
                level=TRACE,
                handler=RotatingFileHandler(
                    filename=os.path.join(self.config.log_dir, logger_name),
                    maxBytes=self.config.log_max_bytes,
                    backupCount=self.config.log_backup_count,
                    encoding='utf-8',
                ),
                include_timestamp=False,
                include_level=False,
            )

    @property
    def status(self) -> ClientStatus:
        return self._status

    async def request(self, request_data: HttpRequestData) -> JsonValue:
        """
        Sends HTTP request and returns text or JSON payload if available.
        """
        seq: int = self._request_counter
        self._request_counter += 1
        method, path, msg, metadata = request_data
        if path:
            url: str = '/'.join((self.config.url, path))
        else:
            url: str = self.config.url
        if path == 'status':
            url = url.replace('api/sms/', 'api/')  # TODO: Hack until getting rid of legacy mode
        if self._logger_trace:
            self._logger_trace.trace(
                'Sending HTTP request', seq=seq, method=method, url=url, json=msg
            )
        try:
            async with self._session.request(method, url, json=msg) as resp:
                if not 200 <= resp.status <= 299:
                    error_msg: str = await resp.text()
                    self.logger.error(
                        'HTTP request denied',
                        seq=seq,
                        client=self.name,
                        method=method,
                        url=url,
                        json=msg,
                        status=resp.status,
                        message=error_msg,
                    )
                    raise RuntimeError('HTTP request denied: ' + error_msg)
                force_json: bool = bool(metadata and metadata.get('force_json'))
                if force_json or resp.content_type == 'application/json':
                    json_result: JsonValue = orjson.loads(await resp.read())
                    if self._logger_trace:
                        self._logger_trace.trace(
                            'Received JSON response',
                            seq=seq,
                            client=self.name,
                            status=resp.status,
                            message=json_result,
                        )
                    return json_result
                if resp.content_type.startswith('text/'):
                    text: str = await resp.text()
                    if self._logger_trace:
                        self._logger_trace.trace(
                            'Received text response',
                            seq=seq,
                            client=self.name,
                            status=resp.status,
                            message=text,
                        )
                    return text
                if self._logger_trace:
                    self._logger_trace.trace(
                        'Received response', seq=seq, client=self.name, status=resp.status
                    )
        except ClientConnectorError:
            self.logger.exception(
                'Error while connecting to web server',
                seq=seq,
                client=self.name,
                method=method,
                url=url,
                json=msg,
            )
            raise
        except ServerDisconnectedError:
            self.logger.exception(
                'Web server disconnected unexpectedly',
                seq=seq,
                client=self.name,
                method=method,
                url=url,
                json=msg,
            )
            raise
        except ClientOSError:
            self.logger.exception(
                'HTTP transport error', seq=seq, client=self.name, method=method, url=url, json=msg
            )
            raise
        except TimeoutError:
            self.logger.exception(
                'Timeout while connecting to web server',
                seq=seq,
                client=self.name,
                method=method,
                url=url,
                json=msg,
            )
            raise
        except ConnectionResetError:
            self.logger.exception(
                'HTTP server connection lost',
                seq=seq,
                client=self.name,
                method=method,
                url=url,
                json=msg,
            )
            raise
        except OSError:
            self.logger.exception(
                'Unexpected exception', seq=seq, client=self.name, method=method, url=url, json=msg
            )
            raise

        return None

    async def start(self) -> None:
        self.logger.debug('Starting HTTP client task', client=self.name)

        self._status = ClientStatus.CONNECTING
        current_data: HttpRequestData | None = None
        self.connect_attempted_event.set()  # No initial connection, so set immediately
        while True:
            try:
                if self.init and self._status != ClientStatus.CONNECTED:
                    # Should raise exception on error
                    await self.init(self)
                if not current_data:
                    current_data = await self.queue.get()
                    if current_data is None:
                        break
                    if self.converter:
                        current_data = await self.converter(current_data)
                request_result: JsonValue = await self.request(current_data)
                if self.hook:
                    await self.hook(request_result, current_data[3])  # Result, metadata
                self.queue.task_done()
                current_data = None
                if self._status != ClientStatus.CONNECTED:
                    self.retry_timer.reset()
                    self._status = ClientStatus.CONNECTED
                continue
            except Exception as exc:  # pylint: disable=broad-except
                self._status = ClientStatus.ERROR
                if self.hook and current_data:
                    await self.hook(exc, current_data[3])  # Exception, metadata
                    self.queue.task_done()
                    current_data = None

            if self.logger.isEnabledFor(INFO):
                delay: float = self.retry_timer.next_delay()
                if delay > 0.0:
                    self.logger.info('Delaying next connect attempt', delay=delay, client=self.name)
            await self.retry_timer.wait()

        await self._session.close()
        self.logger.debug('HTTP client task stopped', client=self.name)

    async def stop(self) -> None:
        self.logger.debug('Stopping HTTP client task', client=self.name)
        await self.queue.put(None)
        self._status = ClientStatus.UNINITIALIZED
        self.connect_attempted_event.clear()

    def is_running(self) -> bool:
        return self.status == ClientStatus.CONNECTED
