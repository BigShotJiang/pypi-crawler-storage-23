from __future__ import annotations

import contextlib
import os
import sys
import traceback
from asyncio import (
    AbstractEventLoop,
    CancelledError,
    Event,
    Task,
    all_tasks,
    get_running_loop,
    sleep,
    wait_for,
)
from collections.abc import Awaitable, Callable, Collection, Coroutine
from email import encoders
from email.header import Header
from email.mime.base import MIMEBase
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.utils import formatdate
from typing import TypeVar

import orjson
from aiohttp import web
from aiosmtplib import SMTP

from .config import SmtpServerConfig
from .exceptions import ArgumentError
from .types import JsonDict, JsonValue, T
from .utils import from_str

_SOCKET_TIMEOUT: int = 15  # In seconds
_J = TypeVar('_J', bound=JsonValue)


def run_task(
    coro: Coroutine[None, None, T], name: str = '', loop: AbstractEventLoop | None = None
) -> Task[T]:
    if loop is None:
        loop = get_running_loop()
    task: Task[T] = loop.create_task(coro, name=name)
    task.add_done_callback(task_result)
    return task


def task_result(task: Task[T]) -> None:
    try:
        task.result()
    except Exception as err:  # pylint: disable=broad-except
        # Call global exception handler with appropriate context
        task.get_loop().call_exception_handler(
            {
                'message': str(err),
                'exception': err,
                'task': task,
            }
        )


async def end_task(task_def: Task[T] | str) -> bool:
    '''
    Cancels an asyncio task by name or reference
    '''
    task_name: str
    task: Task[T] | None
    if isinstance(task_def, str):
        task_name = task_def
        task = next((t for t in all_tasks() if t.get_name() == task_name), None)
    else:
        task_name = task_def.get_name()
        task = task_def
    if not task or task.done():
        return False

    task.cancel()
    try:
        await task  # Will raise CancelledError
    except CancelledError:
        pass
    except RuntimeError:
        # If the coroutine sleeps, Runtime error "await wasn't used with future" will be raised
        pass
    except Exception as err:  # pylint: disable=broad-except
        print('Error while cancelling task ' + task_name, file=sys.stderr)
        traceback.print_tb(err.__traceback__, file=sys.stderr)
        sys.stderr.flush()

    return True


# Tries to read request body as JSON
# Returns JSON content as variable or HTTP 400 response if unsuccessful
async def read_json(
    request: web.Request, body_type: type[T], mandatory_params: Collection[str] = ()
) -> T:
    if not request.body_exists:
        if body_type is dict and not mandatory_params:
            return body_type()
        raise ArgumentError('Could not read request body')
    body: JsonValue = orjson.loads(await request.read())
    if not isinstance(body, body_type):
        raise ArgumentError('Invalid type of request body')
    if isinstance(body, dict) and mandatory_params:
        for param_name in mandatory_params:
            if param_name not in body:
                raise ArgumentError('Missing required parameter: ' + param_name)
    return body


# Reads query parameters and tries to convert them to appropriate type
# Returns dict with new values or HTTP 400 response if unsuccessful
async def read_query_params(
    request: web.Request,
    type_map: dict[str, Callable[..., _J] | type[_J]],
    mandatory_params: Collection[str] = (),
) -> JsonDict:
    result: JsonDict = {}
    unknown_params = [param for param in request.query if param not in type_map]
    if unknown_params:
        raise ArgumentError('Unknown query parameter(s): ' + ','.join(unknown_params))
    for param_name, converter in type_map.items():
        param_values: list[str] | None = request.query.getall(param_name, None)
        if not param_values:
            if mandatory_params and param_name in mandatory_params:
                raise ArgumentError('Missing required parameter: ' + param_name)
        elif len(param_values) > 1:
            raise ArgumentError('Parameter ' + param_name + ' specified more than once')
        else:
            result[param_name] = from_str(param_values[0], converter)
    return result


# Performs TCP socket operation with timeout
async def socket_operation(operation: Awaitable[T], timeout: int = _SOCKET_TIMEOUT) -> T:
    return await wait_for(operation, timeout)


# Schedules async operation to be performed at a later time
async def schedule_after(seconds: float, operation: Awaitable[T]) -> T:
    await sleep(seconds)
    return await operation


async def event_wait(event: Event, timeout: float) -> bool:
    # Suppress TimeoutError because we'll return False in case of timeout
    with contextlib.suppress(TimeoutError):
        await wait_for(event.wait(), timeout)
    return event.is_set()


async def send_email(
    server: SmtpServerConfig,
    sender: str,
    to: Collection[str],
    subject: str,
    text: str,
    text_type: str = 'plain',
    attachments: Collection[str] = (),
    cc: Collection[str] = (),
    bcc: Collection[str] = (),
) -> None:
    # Prepare Message
    msg: MIMEMultipart = MIMEMultipart()
    msg['Date'] = formatdate(localtime=True)
    msg['Subject'] = Header(subject, 'utf-8').encode()
    msg['From'] = sender
    msg['To'] = ', '.join(to)
    if cc:
        msg['Cc'] = ', '.join(cc)
    if bcc:
        msg['Bcc'] = ', '.join(bcc)

    msg.attach(MIMEText(text, text_type, 'utf-8'))

    for path in attachments:
        part: MIMEBase = MIMEBase('application', "octet-stream")
        with open(path, 'rb') as att_file:
            part.set_payload(att_file.read())
        encoders.encode_base64(part)
        filename: str = os.path.basename(path)
        part.add_header('Content-Disposition', f'attachment; filename={filename}')
        msg.attach(part)

    # Contact SMTP server and send Message
    smtp: SMTP = SMTP(
        hostname=server.host,
        port=server.port,
        use_tls=server.ssl,
        start_tls=False,
        validate_certs=server.validate_certs,
    )
    async with smtp:  # Will connect and disconnect automatically
        if server.tls:
            await smtp.starttls()
        if smtp.is_ehlo_or_helo_needed:
            await smtp.ehlo()
        if server.user:
            await smtp.login(server.user, server.pswd)
        await smtp.send_message(msg)
