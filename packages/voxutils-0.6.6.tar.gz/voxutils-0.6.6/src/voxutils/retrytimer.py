from asyncio import sleep
from functools import reduce
from itertools import repeat

from .abc import AbstractRetryTimer


class SimpleExponentialBackoff(AbstractRetryTimer):
    """
    This is an implementation of AbstractRetryTimer using simple truncated exponential backoff.
    Retry delay starts at the minimum and is doubled up to the maximum.
    """

    def __init__(self, min_delay: int = 1000, max_increases: int = 5) -> None:
        """
        Parameters:
            min_delay: Minimum (starting) delay in milliseconds.
            max_increases: Maximum times to double the initial (minimum) delay.
        """
        if min_delay < 1:
            raise ValueError('Parameter `min_delay` must be larger than zero.')
        if max_increases < 0:
            raise ValueError('Parameter `max_increases` must not be negative.')

        self._min_delay: int = min_delay
        self._max_delay: int = reduce(int.__mul__, repeat(2, max_increases), min_delay)
        self._next_delay: int = 0

    def _advance(self) -> float:
        wait_time: float = self._next_delay / 1000
        if self._next_delay == 0:
            self._next_delay = self._min_delay
            return 0.0
        if self._next_delay < self._max_delay:
            self._next_delay *= 2
        return wait_time

    async def wait(self) -> float:
        wait_time: float = self._advance()
        await sleep(wait_time)  # Sleep even if time is 0, to release control to the event loop
        return wait_time

    def reset(self) -> None:
        self._next_delay = 0

    def next(self) -> float:
        return self._advance()

    def next_delay(self) -> float:
        return self._next_delay / 1000
