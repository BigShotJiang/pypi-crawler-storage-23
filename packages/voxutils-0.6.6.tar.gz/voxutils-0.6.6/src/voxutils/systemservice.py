import os
import signal
import ssl
import sys
import traceback
from abc import ABC, abstractmethod
from asyncio import (
    FIRST_COMPLETED,
    AbstractEventLoop,
    AbstractServer,
    CancelledError,
    Event,
    IncompleteReadError,
    Queue,
    StreamReader,
    StreamWriter,
    Task,
    all_tasks,
    create_task,
    get_event_loop,
    new_event_loop,
    set_event_loop,
    sleep,
    start_server,
    wait,
)
from collections.abc import Awaitable, Callable, Sequence
from functools import partial
from ipaddress import IPv4Address, ip_address
from logging.handlers import RotatingFileHandler
from pathlib import Path
from typing import Any, Generic, TypeAlias, TypeVar

import magic
import orjson
import uvloop
from aiohttp import BasicAuth, hdrs, web

from .asyncutils import end_task, run_task, socket_operation
from .config import ClientConfig, ClientType, NetServiceConfig, ServiceConfig
from .exceptions import (
    ArgumentError,
    AuthorizationError,
    DataIntegrityError,
    InternalError,
    ResourceError,
    ServiceUnavailableError,
)
from .httpclient import HttpClient
from .log import TRACE, StructuredLogger
from .retrytimer import SimpleExponentialBackoff
from .types import JsonDict, JsonValue, T

_HttpPreHook: TypeAlias = Callable[[web.Request], Awaitable[web.StreamResponse | None]]
_HttpPostHook: TypeAlias = Callable[[web.Request, web.StreamResponse], Awaitable[None]]
HttpHandler: TypeAlias = Callable[[web.Request], Awaitable[JsonValue]]
HttpRoute: TypeAlias = tuple[str, str, HttpHandler | None]  # HTTP method, HTTP path, handler
C = TypeVar('C', bound=ServiceConfig)
CN = TypeVar('CN', bound=NetServiceConfig)

class SystemService(ABC, Generic[C]):
    def __init__(self, config: C, name: str) -> None:
        self._config: C = config
        self._name: str = name
        self._return_value: int = 0
        self._error_occured: bool = False
        self._is_shutting_down: bool = False
        self._logger: StructuredLogger = StructuredLogger(
            logger_name=name,
            level=config.log_level,
            include_timestamp=False,
        )

        uvloop.install()  # Use faster replacement for asyncio event loop
        try:
            self._loop: AbstractEventLoop = get_event_loop()
        except RuntimeError:
            self._loop = new_event_loop()
            set_event_loop(self._loop)
        self._loop.set_debug(self._config.async_debug)
        self._loop.set_exception_handler(self._handle_exception)
        self._loop.run_until_complete(self.__ainit__())
        self._attach_signal_handlers()

    def __init_subclass__(cls) -> None:
        return super().__init_subclass__()

    async def __ainit__(self) -> None:
        self._ready_event: Event = Event()

    @property
    def ready(self) -> Event:
        return self._ready_event

    def _attach_signal_handlers(self) -> None:
        """
        Attaches shutdown signal handlers to asyncio loop
        """

        def signal_handler(sig: signal.Signals) -> None:
            self._loop.create_task(self.shutdown(sig.name + ' signal'))

        signals: set[signal.Signals] = {signal.SIGTERM, signal.SIGINT, signal.SIGQUIT}
        for sig in signals:
            self._loop.add_signal_handler(sig, signal_handler, sig)

    def _handle_exception(self, loop: AbstractEventLoop, context: dict[str, Any]) -> None:
        """
        Global asyncio exception handler
        """
        err: Exception | None = context.get('exception')
        task: Task[T] | None = context.get('task')
        task_name: str = task.get_name() if task else ''
        if err:
            if isinstance(err, Warning):
                self._logger.warning('Unexpected warning', warning=str(err), task_name=task_name)
                return  # Ignore
            if isinstance(err, RuntimeError) and task:
                self._logger.debug(
                    'RuntimeError in task callback', error_message=str(err), task_name=task_name
                )
                return  # Coroutine was probably already awaited on
            if isinstance(err, CancelledError):
                if task_name:
                    self._logger.debug('%s cancelled', task_name)
                return
        self._error_occured = True
        self._return_value = 1
        self._logger.critical(
            'Unexpected exception', task_name=task_name, message=context['message']
        )
        if err and err.__traceback__:
            self._logger.critical(traceback.format_exception(err))
        elif 'source_traceback' in context:
            self._logger.critical(context['source_traceback'])
        self._ready_event.set()  # If error occured during startup, we must allow shutdown to run
        # context["message"] will always be there; but context["exception"] may not be
        msg: str = repr(err) if err else context['message']
        loop.create_task(self.shutdown('Unexpected exception ' + msg))

    @abstractmethod
    async def _start(self) -> None:
        raise NotImplementedError()

    def start(self) -> None:
        self._logger.info('The service is starting.')

        try:
            self._loop.run_until_complete(self._start())
            self._ready_event.set()
            self._logger.info('The service is running.')
            self._loop.run_forever()
        except Exception:  # pylint: disable=broad-except
            self._logger.exception('Unhandled service error.')
        finally:
            self._loop.close()
            self._logger.info('The service is shut down.')
            sys.exit(self._return_value)

    @abstractmethod
    async def _cleanup(self) -> None:
        raise NotImplementedError()

    async def shutdown(self, reason: str) -> None:
        if self._is_shutting_down:
            return  # Prevent running the function again if multiple signals are sent
        self._is_shutting_down = True
        await self._ready_event.wait()  # Wait for startup to complete
        self._logger.info('The service is shutting down', reason=reason)

        await self._cleanup()

        pending_tasks: set[Task[T]] = all_tasks()
        if pending_tasks:
            self._logger.debug('Cancelling all pending tasks')
            for task in pending_tasks:
                await end_task(task)

        # Stop event loop, thus closing the application
        self._loop.stop()


class NetService(SystemService[CN], Generic[CN]):
    def __init__(self, config: CN, name: str) -> None:
        super().__init__(config, name)
        self._routes: Sequence[HttpRoute] = ()  # HTTP server routes
        self._web_app_runner: web.AppRunner | None = None  # Web app runner
        self._tcp_server: AbstractServer | None = None  # TCP server
        self._pre_hook: _HttpPreHook | None = None  # Hook called before handling HTTP request
        self._post_hook: _HttpPostHook | None = None  # Hook called after handling HTTP request
        self._request_counter = 0  # HTTP request counter (for logging)
        self._message_delimiter: str = '\n\n'  # Outbound TCP message delimiter
        self._data_events: dict[str, Event] = {}  # TCP client data received events
        self._reply_events: dict[str, Event] = {}  # TCP client reply received events
        self._client_queues: dict[str, Queue[JsonDict]] = {}  # TCP client outbound queues
        self._expected_replies: dict[str, str] = {}  # TCP client expected reply cache
        self._last_messages: dict[str, JsonDict] = {}  # TCP client last message cache
        self._receiving_clients: dict[str, HttpClient] = {}  # Receiving HTTP clients
        self._tcp_clients: set[str] = set()  # Active TCP clients
        self._mime_detector: magic.Magic = magic.Magic(
            mime=True
        )  # Mime detector for HTTP file response
        self._loggers_client: dict[str, StructuredLogger] = {}  # Client trace loggers
        self._create_loggers(config.clients)

    def _create_loggers(self, clients: dict[str, ClientConfig]) -> None:
        if self._logger.isEnabledFor(TRACE):
            log_dir: str = self._config.net_server_config.log_dir
            for clnt, clnt_conf in clients.items():
                if clnt_conf.comm_log:
                    logger_name: str = 'comm_' + clnt
                    self._loggers_client[clnt] = StructuredLogger(
                        logger_name=logger_name,
                        level=TRACE,
                        handler=RotatingFileHandler(
                            filename=os.path.join(log_dir, logger_name),
                            maxBytes=clnt_conf.log_max_bytes,
                            backupCount=clnt_conf.log_backup_count,
                            encoding='utf-8',
                        ),
                        include_timestamp=False,
                        include_level=False,
                    )

    async def _start(self) -> None:
        for client, client_conf in self._config.clients.items():
            await self._setup_client(client, client_conf)
        await self._start_web_app()
        await self._start_tcp_server()

    async def _start_web_app(self) -> None:
        self._logger.debug('Setting up web server')
        web_app: web.Application
        if not self._web_app_runner:
            web_app = web.Application()
            # Each is a tuple with method, path and coroutine function
            for http_method, path, handler in self._routes:
                web_app.router.add_route(
                    http_method, path, partial(self._handle_client_request, handler)
                )
            self._web_app_runner = web.AppRunner(web_app)
        await self._web_app_runner.setup()

        bind_addr: str = self._config.net_server_config.http_bind_address
        if bind_addr:
            bind_port: int = self._config.net_server_config.http_bind_port
            self._logger.debug('Starting HTTP site', address=bind_addr, port=bind_port)
            http_site: web.TCPSite = web.TCPSite(self._web_app_runner, bind_addr, bind_port)
            await http_site.start()
        bind_addr = self._config.net_server_config.https_bind_address
        if bind_addr:
            bind_port: int = self._config.net_server_config.https_bind_port
            self._logger.debug('Starting HTTPS site', address=bind_addr, port=bind_port)
            cert_file: str = self._config.net_server_config.secure_cert_file
            key_file: str = self._config.net_server_config.secure_key_file
            ssl_context: ssl.SSLContext = ssl.create_default_context(ssl.Purpose.CLIENT_AUTH)
            ssl_context.load_cert_chain(cert_file, key_file)
            ssl_context.minimum_version = self._config.net_server_config.min_tls_version
            https_site: web.TCPSite = web.TCPSite(
                self._web_app_runner, bind_addr, bind_port, ssl_context=ssl_context
            )
            await https_site.start()

    async def _stop_web_app(self) -> None:
        if self._web_app_runner:
            self._logger.debug('Stopping web server')
            try:
                await self._web_app_runner.cleanup()
            except Exception as err:  # pylint: disable=broad-except
                self._logger.warning('Unexpected error while stopping web server', exc_info=err)
            self._logger.debug('Web server stopped')

    async def _start_tcp_server(self) -> None:
        bind_addr: str = self._config.net_server_config.tcp_bind_address
        if not bind_addr:
            return
        bind_port: int = self._config.net_server_config.tcp_bind_port
        self._logger.debug('Starting TCP server', address=bind_addr, port=bind_port)
        server: AbstractServer = await start_server(self._handle_tcp_client, bind_addr, bind_port)
        run_task(server.serve_forever(), 'TCP server')

    async def _stop_tcp_server(self) -> None:
        await end_task('TCP server')

        # Stop client connections
        for client in self._tcp_clients:
            await end_task(f'{client} Connection monitor')
            await end_task(f'{client} TCP receiver')
            await end_task(f'{client} TCP sender')

    # Monitors TCP client connection, and exits if no data was received within predefied timeout
    async def _conn_monitor(self, client: str) -> None:
        self._logger.debug('Starting TCP client connection monitor', client=client)
        client_conf: ClientConfig = self._config.clients[client]
        data_event: Event = self._data_events[client]
        sleep_task: Task[None] | None = None
        event_task: Task[bool] | None = None
        try:
            while True:
                # Wait for interval to expire or data event to be triggered, whichever comes first
                # clients's receiver will trigger the event after data is received
                sleep_task = create_task(sleep(client_conf.idle_timeout))
                event_task = create_task(data_event.wait())
                done, _pending = await wait({sleep_task, event_task}, return_when=FIRST_COMPLETED)
                if sleep_task in done:
                    # Interval expired, break connection
                    await sleep_task
                    self._logger.info(
                        'Closing TCP client connection due to inactivity',
                        client=client,
                        timeout=client_conf.idle_timeout,
                    )
                    raise CancelledError

                # Data was received, cancel sleep task and start over
                await end_task(sleep_task)
                await event_task

                data_event.clear()
        except CancelledError:
            if sleep_task:
                await end_task(sleep_task)
            if event_task:
                await end_task(event_task)
            raise

    async def _setup_client(self, client: str, client_conf: ClientConfig) -> None:
        if client_conf.type == ClientType.TCP:
            self._client_queues[client] = Queue()
            self._last_messages[client] = {}
        elif client_conf.host:
            http_client: HttpClient = HttpClient(
                name=client,
                config=client_conf,
                queue=Queue(),
                logger=self._logger,
                retry_timer=SimpleExponentialBackoff(),
                init=self._client_init,
            )
            self._receiving_clients[client] = http_client
            run_task(http_client.start())

    async def _client_init(self, http_client: HttpClient) -> None:
        # pylint: disable=unused-argument
        # Override in subclass
        return

    async def _find_tcp_client(
        self, user: str, pswd: str, client_ip: IPv4Address
    ) -> tuple[str, ClientConfig | None]:
        client: str = ''
        client_conf: ClientConfig | None = None
        for clnt, clnt_conf in self._config.clients.items():
            if clnt_conf.type == ClientType.TCP:
                if clnt_conf.server_user == user and clnt_conf.server_pswd == pswd:
                    if not clnt_conf.allowed_ips or any(
                        client_ip in allowed_net for allowed_net in clnt_conf.allowed_ips
                    ):
                        client, client_conf = clnt, clnt_conf
                        break
                    self._logger.warning(
                        'Client passed authentication from disallowed IP.',
                        peer=str(client_ip),
                        client=clnt,
                    )
                    return '', None
        if not client:
            self._logger.warning('Client failed authentication.', peer=str(client_ip))
        elif client in self._data_events:
            # We set client, but not client_conf.
            # This informs the calling function that the client is already connected.
            client_conf = None
            self._logger.warning('Client already connected.', peer=str(client_ip), client=client)
        return client, client_conf

    async def _auth_tcp_client(
        self, reader: StreamReader, writer: StreamWriter, client_ip: IPv4Address
    ) -> tuple[str, ClientConfig | None]:
        # pylint: disable=unused-argument
        # Override in subclass
        return '', None

    async def _handle_tcp_client(self, reader: StreamReader, writer: StreamWriter) -> None:
        client: str = ''
        client_conf: ClientConfig | None = None
        peer = writer.get_extra_info('peername')
        self._logger.debug('TCP connection initiated', peer=peer)
        try:
            client_ip: IPv4Address = IPv4Address(peer[0])
            client, client_conf = await self._auth_tcp_client(reader, writer, client_ip)
            if not client_conf:
                return
            self._logger.info('Authenticated successfully', client=client)
            self._data_events[client] = Event()
            self._reply_events[client] = Event()
            self._expected_replies[client] = ''
            self._tcp_clients.add(client)
            # Wait until any task fails
            done, pending = await wait(
                {
                    run_task(self._tcp_sender(client, writer), f'{client} TCP sender'),
                    run_task(self._tcp_receiver(client, reader, writer), f'{client} TCP receiver'),
                    run_task(self._conn_monitor(client), f'{client} Connection monitor'),
                },
                return_when=FIRST_COMPLETED,
            )
            self._tcp_clients.remove(client)
            for task in done:
                await task
            for task in pending:
                await end_task(task)
        except ConnectionError:
            self._logger.error('TCP connection lost', peer=peer)
        except TimeoutError:
            self._logger.error('TCP connection timed out', peer=peer)
        except IncompleteReadError:
            self._logger.error('Incomplete read error', peer=peer)
        except OSError:
            self._logger.exception('TCP network error', peer=peer)
        except Exception:  # pylint: disable=broad-except
            self._logger.exception('Unexpected TCP client communication error', peer=peer)
        except CancelledError:
            if client:
                await end_task(f'{client} TCP receiver')
                await end_task(f'{client} TCP sender')
                await end_task(f'{client} Connection monitor')
                self._logger.debug('TCP connection handler cancelled', peer=peer, client=client)
            raise
        finally:
            if client:
                del self._data_events[client]
                del self._reply_events[client]
                del self._expected_replies[client]
                # _last_messages need to be preserved between reconnects
            if not writer.is_closing():
                writer.close()

    async def _tcp_receiver(self, client: str, reader: StreamReader, writer: StreamWriter) -> None:
        # Override in subclass
        pass

    async def _tcp_sender(self, client: str, writer: StreamWriter) -> None:
        # Override in subclass
        pass

    async def _sock_read(
        self,
        client: str,
        reader: StreamReader,
        timeout: int = 0,
        delimiter: bytes = b'\n',
        encoding: str = '',
    ) -> str | None:
        if timeout:
            data: bytes = await socket_operation(reader.readuntil(delimiter), timeout)
        else:
            data: bytes = await reader.readuntil(delimiter)
        if client:
            self._data_events[client].set()
            if not encoding:
                encoding = self._config.clients[client].encoding
        if not encoding:
            encoding = 'utf-8'  # Default
        client_logger: StructuredLogger | None = self._loggers_client.get(client)
        try:
            message: str = data.decode(encoding)
        except Exception:  # pylint: disable=broad-except
            if client_logger:
                client_logger.exception('Could not decode client message', message=data)
            return None
        if client_logger:
            client_logger.trace('RCVD', message=message)
        return message.rstrip()

    async def _sock_write(
        self, client: str, writer: StreamWriter, message: str, encoding: str = ''
    ) -> None:
        message += self._message_delimiter
        if client:
            if not encoding:
                encoding = self._config.clients[client].encoding
        if not encoding:
            encoding = 'utf-8'  # Default
        client_logger: StructuredLogger | None = self._loggers_client.get(client)
        if client_logger:
            client_logger.trace('SENT', message=message)
        writer.write(message.encode(encoding))
        await socket_operation(writer.drain())

    @staticmethod
    def _get_api_key(request: web.Request) -> str:
        key_name: str = 'X-API-KEY'
        key_headers: list[str] | None = request.headers.getall(key_name, None)
        if key_headers:
            if len(key_headers) > 1 or ' ' in key_headers[0]:
                raise ArgumentError(f'{key_name} header specified more than once')
            return key_headers[0]
        key_cookie: str | None = request.cookies.get(key_name)
        if key_cookie:
            return key_cookie
        key_params: list[str] | None = request.query.getall('apiKey', None)
        if key_params:
            if len(key_params) > 1:
                raise ArgumentError('API key query parameter specified more than once')
            return key_params[0]
        return ''

    @staticmethod
    def _http_authenticate(request: web.Request) -> tuple[str, str]:
        auth_header: str | None = request.headers.get(hdrs.AUTHORIZATION)
        if not auth_header:
            return '', ''
        try:
            auth: BasicAuth = BasicAuth.decode(auth_header=auth_header)
            return auth.login, auth.password
        except ValueError:
            return '', ''

    @staticmethod
    def _http_challenge(realm: str = '') -> web.Response:
        return web.Response(
            body=b'',
            status=401,
            reason='UNAUTHORIZED',
            headers={
                hdrs.WWW_AUTHENTICATE: f'Basic realm="{realm}"',
                hdrs.CONTENT_TYPE: 'text/html; charset=utf-8',
                hdrs.CONNECTION: 'keep-alive',
            },
        )

    async def _http_response(self, coroutine: Awaitable[JsonValue]) -> web.StreamResponse:
        """
        Executes a coroutine and returns appropriate HTTP response.
        The coroutine should raise an appropriate exception in case of an error.
        """
        try:
            result: JsonValue = await coroutine
        except ArgumentError as err:
            return web.Response(status=400, text=str(err))
        except AuthorizationError as err:
            return web.Response(status=401, text=str(err))
        except ResourceError as err:
            return web.Response(status=404, text=str(err))
        except DataIntegrityError as err:
            return web.Response(status=409, text=str(err))
        except ServiceUnavailableError as err:
            return web.Response(status=503, text=str(err))
        except InternalError as err:
            return web.Response(status=500, text=str(err))
        except ValueError as err:
            self._logger.exception('Unexpected ValueError')
            return web.Response(status=400, text=str(err))
        except Exception as err:  # pylint: disable=broad-except
            self._logger.exception('Unexpected Exception')
            return web.Response(status=500, text=str(err))

        if result is None:
            return web.Response()
        if isinstance(result, web.StreamResponse):
            return result
        if isinstance(result, Path):
            response: web.FileResponse = web.FileResponse(result)
            response.content_type = self._mime_detector.from_file(str(result))
            return response
        return web.json_response(body=orjson.dumps(result))

    async def _handle_client_request(
        self, handler: HttpHandler | None, request: web.Request
    ) -> web.StreamResponse:
        seq: int = self._request_counter
        self._request_counter += 1

        async def respond(client: str, resp: web.StreamResponse) -> web.StreamResponse:
            if self._post_hook is not None:
                await self._post_hook(request, resp)
            self._logger.trace('Responding to HTTP request', seq=seq, status=resp.status)
            client_logger: StructuredLogger | None = self._loggers_client.get(client)
            if client_logger:
                if isinstance(resp, web.Response):
                    if resp.content_type == 'application/json':
                        assert isinstance(resp.body, bytes)  # For type checkers
                        json_result: JsonValue = orjson.loads(resp.body)
                        client_logger.trace(
                            'Responding with JSON',
                            seq=seq,
                            client=client,
                            status=resp.status,
                            message=json_result,
                        )
                    else:
                        text: str = resp.text or ''
                        client_logger.trace(
                            'Responding with text',
                            seq=seq,
                            client=client,
                            status=resp.status,
                            message=text,
                        )
                elif isinstance(resp, web.FileResponse):
                    # pylint: disable=protected-access; don't even know why is this protected
                    client_logger.trace(
                        'Responding with file',
                        seq=seq,
                        client=client,
                        status=resp.status,
                        path=resp._path,
                        content_type=resp.content_type,
                    )
            return resp

        rel_url: str = request.rel_url.human_repr()
        clients: dict[str, ClientConfig] = self._config.clients
        client: str = ''
        client_conf: ClientConfig | None = None
        response: web.StreamResponse | None
        ip_str: str | None = request.headers.get('X-Real-IP') or request.remote
        self._logger.trace(
            'Received HTTP request', seq=seq, method=request.method, url=rel_url, ip=ip_str
        )
        try:
            # Try to identify client by IP
            try:
                if not ip_str:
                    raise ValueError()
                remote_ip = ip_address(ip_str)
            except ValueError:
                response = web.Response(status=500, text='Could not detect client IP address')
                return await respond('', response)
            client, client_conf = next(
                (
                    (clnt, clnt_conf)
                    for clnt, clnt_conf in clients.items()
                    for allowed_net in clnt_conf.allowed_ips
                    if remote_ip in allowed_net
                ),
                ('', None),
            )

            api_key: str = self._get_api_key(request)
            if client_conf and client_conf.api_key != api_key:
                self._logger.info(
                    'Client identified by IP sent wrong API key',
                    seq=seq,
                    method=request.method,
                    url=rel_url,
                    ip=ip_str,
                )
                response = web.Response(status=401)
                return await respond(client, response)
            if api_key:
                if request.scheme != 'https':
                    if request.headers.get(hdrs.X_FORWARDED_PROTO) != 'https':
                        self._logger.info(
                            'Client tried to identify with API key over insecure connection',
                            seq=seq,
                            method=request.method,
                            url=rel_url,
                            ip=ip_str,
                        )
                        raise ArgumentError('API key authentication requires secure connection')
                client, client_conf = next(
                    (
                        (clnt, clnt_def)
                        for clnt, clnt_def in clients.items()
                        if clnt_def.api_key == api_key
                    ),
                    ('', None),
                )

            possible_clients: dict[str, ClientConfig] = {}
            if client_conf:
                if client_conf.server_user:
                    # Found client by IP and/or API key, but authentication is still required
                    possible_clients = {client: client_conf}
                    client = ''
            else:
                possible_clients = {
                    clnt: clnt_def for clnt, clnt_def in clients.items() if clnt_def.server_user
                }

            if not client_conf:
                self._logger.trace('Performing basic authentication', seq=seq)
                username, password = self._http_authenticate(request)
                client, client_conf = next(
                    (
                        (clnt, clnt_conf)
                        for clnt, clnt_conf in possible_clients.items()
                        if clnt_conf.server_user == username and clnt_conf.server_pswd == password
                    ),
                    ('', None),
                )
                if not client_conf:
                    self._logger.warning(
                        'Authentication failed',
                        seq=seq,
                        remote_ip=str(remote_ip),
                        method=request.method,
                        url=rel_url,
                    )
                    response = self._http_challenge()
                    return await respond(client, response)
            if client_conf:
                if client_conf.api_key != api_key:
                    self._logger.info(
                        'Client identified by basic auth sent wrong API key',
                        seq=seq,
                        method=request.method,
                        url=rel_url,
                        ip=ip_str,
                    )
                    response = web.Response(status=401)
                    return await respond(client, response)
                if any(pattern.match(rel_url) for pattern in client_conf.path_deny):
                    self._logger.info(
                        'HTTP path explicitly denied',
                        seq=seq,
                        method=request.method,
                        url=rel_url,
                        ip=ip_str,
                        client=client,
                    )
                    response = web.Response(status=401)
                    return await respond(client, response)
                if not any(pattern.match(rel_url) for pattern in client_conf.path_allow):
                    self._logger.info(
                        'HTTP path not allowed',
                        seq=seq,
                        method=request.method,
                        url=rel_url,
                        ip=ip_str,
                        client=client,
                    )
                    response = web.Response(status=401)
                    return await respond(client, response)
                client_logger: StructuredLogger | None = self._loggers_client.get(client)
                if client_logger:
                    payload: str
                    if request.body_exists:
                        payload = (await request.read()).decode('utf-8')
                    else:
                        payload = ''
                    client_logger.trace(
                        'Request accepted',
                        seq=seq,
                        remote_ip=str(remote_ip),
                        method=request.method,
                        url=rel_url,
                        payload=payload,
                    )
                request['client'] = client
                if self._pre_hook is not None:
                    response = await self._pre_hook(request)
                    if response:
                        return await respond(client, response)
                if not handler:
                    response = web.Response()
                else:
                    response = await self._http_response(handler(request))
                return await respond(client, response)
        except ArgumentError as err:
            response = web.Response(status=400, text=str(err))
            return await respond(client, response)
        raise InternalError('Request processing error')
