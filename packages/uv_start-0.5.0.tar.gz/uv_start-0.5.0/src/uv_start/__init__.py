__version__ = "0.5.0"
import __main__

__all__ = ["__version__", "__main__"]
