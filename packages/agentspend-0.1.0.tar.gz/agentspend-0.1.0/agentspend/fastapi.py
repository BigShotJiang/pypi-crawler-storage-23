"""FastAPI integration for AgentSpend."""

from __future__ import annotations

from typing import Any, Optional

from fastapi import Depends, Request
from fastapi.responses import JSONResponse

from agentspend.core import AgentSpendClient
from agentspend.types import (
    AgentSpendOptions,
    ChargeOptions,
    ChargeResponse,
    PaywallOptions,
    PaywallPaymentContext,
    PaywallRequest,
    PaywallResult,
)

_PAYMENT_CONTEXT_ATTR = "_agentspend_payment_context"


def get_payment_context(request: Request) -> PaywallPaymentContext | None:
    """Retrieve the payment context set by the paywall dependency."""
    return getattr(request.state, _PAYMENT_CONTEXT_ATTR, None)


class AgentSpend:
    """FastAPI AgentSpend integration.

    Usage::

        from agentspend.fastapi import AgentSpend, get_payment_context

        spend = AgentSpend(AgentSpendOptions(service_api_key="sk_..."))

        @app.post("/paid", dependencies=[Depends(spend.paywall(PaywallOptions(amount=500)))])
        async def paid_endpoint(request: Request):
            ctx = get_payment_context(request)
            return {"paid": True, "method": ctx.method}
    """

    def __init__(self, options: AgentSpendOptions):
        self._client = AgentSpendClient(options)

    def charge(self, card_id: str, opts: ChargeOptions) -> ChargeResponse:
        return self._client.charge(card_id, opts)

    def paywall(self, opts: PaywallOptions):
        """Return a FastAPI dependency that gates a route behind a paywall."""
        client = self._client

        async def paywall_dependency(request: Request) -> Optional[PaywallPaymentContext]:
            body: Any
            try:
                body = await request.json()
            except Exception:
                body = {}

            headers = {
                "x-card-id": request.headers.get("x-card-id"),
                "payment-signature": request.headers.get("payment-signature"),
                "x-payment": request.headers.get("x-payment"),
                "x-request-id": request.headers.get("x-request-id"),
                "idempotency-key": request.headers.get("idempotency-key"),
            }

            paywall_req = PaywallRequest(
                url=str(request.url),
                method=request.method,
                headers=headers,
                body=body,
            )

            result = client.process_paywall(opts, paywall_req)

            if result.outcome in ("charged", "crypto_paid"):
                setattr(request.state, _PAYMENT_CONTEXT_ATTR, result.payment_context)
                return result.payment_context

            if result.outcome == "payment_required":
                raise _PaywallResponseException(
                    status_code=result.status_code or 402,
                    body=result.body or {},
                    headers=result.headers,
                )

            raise _PaywallResponseException(
                status_code=result.status_code or 500,
                body=result.body or {},
            )

        return paywall_dependency


class _PaywallResponseException(Exception):
    """Internal exception to short-circuit FastAPI request processing."""

    def __init__(self, status_code: int, body: dict[str, Any], headers: dict[str, str] | None = None):
        self.status_code = status_code
        self.body = body
        self.headers = headers or {}


def install_exception_handler(app: Any) -> None:
    """Install the AgentSpend exception handler on a FastAPI app.

    Call this once during app startup::

        from agentspend.fastapi import install_exception_handler
        install_exception_handler(app)
    """

    @app.exception_handler(_PaywallResponseException)
    async def _handle_paywall_exception(request: Request, exc: _PaywallResponseException) -> JSONResponse:
        return JSONResponse(
            status_code=exc.status_code,
            content=exc.body,
            headers=exc.headers,
        )
