"""Flask integration for AgentSpend."""

from __future__ import annotations

from functools import wraps
from typing import Any, Callable

from flask import Response as FlaskResponse, g, jsonify, request

from agentspend.core import AgentSpendClient
from agentspend.types import (
    AgentSpendOptions,
    ChargeOptions,
    ChargeResponse,
    PaywallOptions,
    PaywallPaymentContext,
    PaywallRequest,
    PaywallResult,
)


def get_payment_context() -> PaywallPaymentContext | None:
    """Retrieve the payment context set by the paywall decorator."""
    return getattr(g, "payment_context", None)


class AgentSpend:
    """Flask AgentSpend integration.

    Usage::

        from agentspend.flask import AgentSpend

        spend = AgentSpend(AgentSpendOptions(service_api_key="sk_..."))

        @app.route("/paid", methods=["POST"])
        @spend.paywall(PaywallOptions(amount=500))
        def paid_endpoint():
            ctx = get_payment_context()
            return jsonify({"paid": True, "method": ctx.method})
    """

    def __init__(self, options: AgentSpendOptions):
        self._client = AgentSpendClient(options)

    def charge(self, card_id: str, opts: ChargeOptions) -> ChargeResponse:
        return self._client.charge(card_id, opts)

    def paywall(self, opts: PaywallOptions) -> Callable[..., Any]:
        """Decorator that gates a Flask route behind a paywall."""

        def decorator(fn: Callable[..., Any]) -> Callable[..., Any]:
            @wraps(fn)
            def wrapper(*args: Any, **kwargs: Any) -> Any:
                headers = {
                    "x-card-id": request.headers.get("x-card-id"),
                    "payment-signature": request.headers.get("payment-signature"),
                    "x-payment": request.headers.get("x-payment"),
                    "x-request-id": request.headers.get("x-request-id"),
                    "idempotency-key": request.headers.get("idempotency-key"),
                }

                body = request.get_json(silent=True) or {}

                paywall_req = PaywallRequest(
                    url=request.url,
                    method=request.method,
                    headers=headers,
                    body=body,
                )

                result = self._client.process_paywall(opts, paywall_req)

                if result.outcome in ("charged", "crypto_paid"):
                    g.payment_context = result.payment_context
                    return fn(*args, **kwargs)
                elif result.outcome == "payment_required":
                    resp = jsonify(result.body)
                    resp.status_code = result.status_code or 402
                    for key, value in result.headers.items():
                        resp.headers[key] = value
                    return resp
                else:
                    resp = jsonify(result.body)
                    resp.status_code = result.status_code or 500
                    return resp

            return wrapper

        return decorator
