"""Django integration for AgentSpend."""

from __future__ import annotations

import json
from typing import Any, Callable, Optional

from django.http import HttpRequest, JsonResponse

from agentspend.core import AgentSpendClient
from agentspend.types import (
    AgentSpendOptions,
    ChargeOptions,
    ChargeResponse,
    PaywallOptions,
    PaywallPaymentContext,
    PaywallRequest,
)

_PAYMENT_CONTEXT_ATTR = "_agentspend_payment_context"


def get_payment_context(request: HttpRequest) -> PaywallPaymentContext | None:
    """Retrieve the payment context set by the paywall middleware."""
    return getattr(request, _PAYMENT_CONTEXT_ATTR, None)


class AgentSpendMiddleware:
    """Django middleware for AgentSpend paywalls.

    Configure in settings.py::

        AGENTSPEND_OPTIONS = AgentSpendOptions(service_api_key="sk_...")
        AGENTSPEND_PAYWALL_ROUTES = {
            "/paid/": PaywallOptions(amount=500),
        }

    Then use the ``agentspend_paywall`` decorator for per-view control,
    or this middleware for route-based configuration.
    """

    def __init__(self, get_response: Callable[[HttpRequest], Any]):
        self.get_response = get_response
        # Import from Django settings
        from django.conf import settings

        options: AgentSpendOptions = getattr(settings, "AGENTSPEND_OPTIONS", None)
        if options is None:
            raise ValueError("AGENTSPEND_OPTIONS must be set in Django settings")

        self._client = AgentSpendClient(options)
        self._routes: dict[str, PaywallOptions] = getattr(settings, "AGENTSPEND_PAYWALL_ROUTES", {})

    def __call__(self, request: HttpRequest) -> Any:
        opts = self._routes.get(request.path)
        if opts is None:
            return self.get_response(request)

        result = self._process(request, opts)
        if result is not None:
            return result

        return self.get_response(request)

    def _process(self, request: HttpRequest, opts: PaywallOptions) -> Optional[JsonResponse]:
        try:
            body = json.loads(request.body) if request.body else {}
        except (json.JSONDecodeError, ValueError):
            body = {}

        headers = {
            "x-card-id": request.headers.get("x-card-id"),
            "payment-signature": request.headers.get("payment-signature"),
            "x-payment": request.headers.get("x-payment"),
            "x-request-id": request.headers.get("x-request-id"),
            "idempotency-key": request.headers.get("idempotency-key"),
        }

        paywall_req = PaywallRequest(
            url=request.build_absolute_uri(),
            method=request.method,
            headers=headers,
            body=body,
        )

        result = self._client.process_paywall(opts, paywall_req)

        if result.outcome in ("charged", "crypto_paid"):
            setattr(request, _PAYMENT_CONTEXT_ATTR, result.payment_context)
            return None

        if result.outcome == "payment_required":
            resp = JsonResponse(result.body, status=result.status_code or 402)
            for key, value in result.headers.items():
                resp[key] = value
            return resp

        return JsonResponse(result.body, status=result.status_code or 500)


def agentspend_paywall(options: AgentSpendOptions, paywall_opts: PaywallOptions) -> Callable[..., Any]:
    """Decorator for individual Django views.

    Usage::

        from agentspend.django import agentspend_paywall, get_payment_context

        @agentspend_paywall(AgentSpendOptions(service_api_key="sk_..."), PaywallOptions(amount=500))
        def paid_view(request):
            ctx = get_payment_context(request)
            return JsonResponse({"paid": True, "method": ctx.method})
    """
    client = AgentSpendClient(options)

    def decorator(fn: Callable[..., Any]) -> Callable[..., Any]:
        def wrapper(request: HttpRequest, *args: Any, **kwargs: Any) -> Any:
            try:
                body = json.loads(request.body) if request.body else {}
            except (json.JSONDecodeError, ValueError):
                body = {}

            headers = {
                "x-card-id": request.headers.get("x-card-id"),
                "payment-signature": request.headers.get("payment-signature"),
                "x-payment": request.headers.get("x-payment"),
                "x-request-id": request.headers.get("x-request-id"),
                "idempotency-key": request.headers.get("idempotency-key"),
            }

            paywall_req = PaywallRequest(
                url=request.build_absolute_uri(),
                method=request.method,
                headers=headers,
                body=body,
            )

            result = client.process_paywall(paywall_opts, paywall_req)

            if result.outcome in ("charged", "crypto_paid"):
                setattr(request, _PAYMENT_CONTEXT_ATTR, result.payment_context)
                return fn(request, *args, **kwargs)

            if result.outcome == "payment_required":
                resp = JsonResponse(result.body, status=result.status_code or 402)
                for key, value in result.headers.items():
                    resp[key] = value
                return resp

            return JsonResponse(result.body, status=result.status_code or 500)

        return wrapper

    return decorator
