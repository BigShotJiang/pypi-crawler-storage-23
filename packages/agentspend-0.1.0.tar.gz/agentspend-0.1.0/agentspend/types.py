from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable, Optional, Union


class AgentSpendChargeError(Exception):
    """Raised when a charge or paywall operation fails."""

    def __init__(self, message: str, status_code: int, details: Any = None):
        super().__init__(message)
        self.status_code = status_code
        self.details = details


@dataclass
class AgentSpendOptions:
    """Configuration for the AgentSpend client."""

    platform_api_base_url: Optional[str] = None
    service_api_key: Optional[str] = None
    crypto: Optional[CryptoConfig] = None


@dataclass
class CryptoConfig:
    """Crypto / x402 configuration."""

    receiver_address: Optional[str] = None
    network: str = "eip155:8453"
    facilitator_url: str = "https://facilitator.openx402.ai"


@dataclass
class ChargeOptions:
    amount_cents: int
    currency: str = "usd"
    description: Optional[str] = None
    metadata: Optional[dict[str, str]] = None
    idempotency_key: Optional[str] = None


@dataclass
class ChargeResponse:
    charged: bool
    card_id: str
    amount_cents: int
    currency: str
    remaining_limit_cents: int
    stripe_payment_intent_id: str
    stripe_charge_id: str
    charge_attempt_id: str


@dataclass
class PaywallOptions:
    """Paywall configuration.

    amount can be:
    - int: fixed price in cents (e.g. 500 = $5.00)
    - str: body field name to read amount from (e.g. "amount_cents")
    - callable: custom dynamic pricing ``(body) -> int``
    """

    amount: Union[int, str, Callable[[Any], int]]
    currency: str = "usd"
    description: Optional[str] = None
    metadata: Optional[Callable[[Any], dict[str, Any]]] = None


@dataclass
class PaywallPaymentContext:
    method: str  # "card" | "crypto"
    amount_cents: int
    currency: str
    card_id: Optional[str] = None
    remaining_limit_cents: Optional[int] = None
    transaction_hash: Optional[str] = None
    payer_address: Optional[str] = None
    network: Optional[str] = None


@dataclass
class PaywallRequest:
    url: str
    method: str
    headers: dict[str, Optional[str]]
    body: Any


@dataclass
class PaywallResult:
    """Result from processPaywall.

    outcome is one of: "charged", "crypto_paid", "payment_required", "error"
    """

    outcome: str
    payment_context: Optional[PaywallPaymentContext] = None
    status_code: Optional[int] = None
    body: Optional[dict[str, Any]] = None
    headers: dict[str, str] = field(default_factory=dict)
