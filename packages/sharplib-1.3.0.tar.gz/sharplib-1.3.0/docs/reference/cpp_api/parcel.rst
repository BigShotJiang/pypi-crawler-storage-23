parcel
======

Parcel Lifters
--------------
.. doxygenstruct:: sharp::lifter_wobus
   :members:

.. doxygenstruct:: sharp::lifter_cm1
   :members:

Parcels
-------
.. doxygenenum:: sharp::LPL
.. doxygenstruct:: sharp::Parcel 
   :members:

.. doxygenstruct:: sharp::DowndraftParcel 
   :members:
