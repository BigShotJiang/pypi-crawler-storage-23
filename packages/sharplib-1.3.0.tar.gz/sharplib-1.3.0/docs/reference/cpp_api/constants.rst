constants
=========

.. doxygenfile:: constants.h 
   :project: SHARPlib
   :sections: briefdescription innernamespace var 

