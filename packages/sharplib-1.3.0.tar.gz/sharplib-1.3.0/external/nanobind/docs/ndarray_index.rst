.. _ndarrays:

N-dimensional arrays
====================

nanobind provides two alternative interfaces to exchange array data between
Python and C++.

.. toctree::
   :maxdepth: 1

   ndarray
   eigen
