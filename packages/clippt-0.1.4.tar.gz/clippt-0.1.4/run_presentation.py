# /// script
# requires-python = ">=3.14"
# dependencies = [
#     "clippt>=0.1.3",
# ]
# ///
from io import StringIO

from clippt.app import PresentationApp
from clippt.presentation import load_presentation

CONTENT = '''
title = "Pražské Pyvo #177"

[[slides]]
source = """
<!-- date: 18/2/2026 -->
# Pražské Pyvo #177
Programme starts 19:00
"""

[[slides]]
source = """
# Start moved!
- Why? For many people start (and end) was too late.
- How much: half an hour sooner: 18:30 is door opened.
- Programme starts at 19:00 now (30 to 60 minutes sooner than usual)
"""

[[slides]]
source = """
# House rules
"""

[[slides]]
source = """
# Go outside to the garden only ⬆
- neighbour relations 🥚🔇
- if not leaving
"""

[[slides]]
source = """
# Don't forget to pay before leaving 💸
"""

[[slides]]
source = """
# Cash only 💰
If you don't have cash on you ask organizers.
"""

[[slides]]
source = """
# Be nice to each other
Everybody should feel welcome and safe. Contact organizers if you're not.
"""

[[slides]]
source = """
# Program

18:30 – Doors open
19:00 – 🗣️ Talk "Cyber Resilience Act and Open-Source"
19:45 – ⚡ Lightning talks: add yours to https://bit.ly/prpylight
after 20:00 – 👯 Chat, singing etc. until midnight
"""

[[slides]]
source = """
# Lightning talks
- any topic
- 5 minutes per talk maximum
- sign up bit.ly/prpylight
"""

[[slides]]
source = """
# Introductions
Please tell everybody **Try to speak **LOUDLY** in CZ, SK or EN.**
1. Your name
2. Did you ever start solving cyber resilience (yes/no)?
"""

[[slides]]
source = """
# praha@pyvo.cz
- feedback 👂
- offer help 💪
- talk suggestions 👩‍🏫
"""
'''

if __name__ == "__main__":
    presentation = load_presentation(StringIO(CONTENT))
    slides = list(presentation.create_slides())
    app = PresentationApp(slides=slides, title=presentation.title or "")
    app.run()
