# zen_of_python.py

import this