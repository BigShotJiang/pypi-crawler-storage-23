## List of examples

- **fibonacci/fibonacci.toml** - Vibe-coded implementation of the fibonacci series in many languages to show the syntax-highlighting features

- **fibonacci-inline.toml** - Version of the above, with all slides fully embedded in the configuration file.

- **run_presentation.py** - Example of how to run a presentation from a Python script.
