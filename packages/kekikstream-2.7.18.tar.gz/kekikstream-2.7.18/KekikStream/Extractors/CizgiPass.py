# Bu araç @keyiflerolsun tarafından | @KekikAkademi için yazılmıştır.

from KekikStream.Core import BePlayerExtractor

class CizgiPass(BePlayerExtractor):
    name     = "CizgiPass"
    main_url = "https://cizgipass100.online"
