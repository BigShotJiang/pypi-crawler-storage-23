# Test gallery examples for SolverMVA
