"""
Flow-Equivalent Server (FES) Aggregation Example

This example demonstrates how to use ModelAdapter.aggregate_fes to replace
a subset of stations in a closed product-form queueing network with a
single Flow-Equivalent Server (FES).

NOTE: FES aggregation is not yet implemented in native Python.
This example is provided for API compatibility documentation.
Use python-wrapper for full FES aggregation functionality.

Copyright (c) 2012-2026, Imperial College London
All rights reserved.
"""

from line_solver import *

print('=== Flow-Equivalent Server (FES) Aggregation Example ===\n')

# Create original 4-station tandem network with 2 classes
print('Creating original 4-station network...')

N1 = 3  # number of class-1 jobs
N2 = 2  # number of class-2 jobs

model = Network('OriginalModel')

# Create stations
delay = Delay(model, 'ThinkTime')
queue1 = Queue(model, 'Queue1', SchedStrategy.PS)
queue2 = Queue(model, 'Queue2', SchedStrategy.PS)
queue3 = Queue(model, 'Queue3', SchedStrategy.PS)

# Create job classes
jobclass1 = ClosedClass(model, 'Class1', N1, delay, 0)
jobclass2 = ClosedClass(model, 'Class2', N2, delay, 0)

# Set service times
delay.set_service(jobclass1, Exp.fit_mean(5.0))
delay.set_service(jobclass2, Exp.fit_mean(4.0))

queue1.set_service(jobclass1, Exp.fit_mean(1.5))
queue1.set_service(jobclass2, Exp.fit_mean(2.0))

queue2.set_service(jobclass1, Exp.fit_mean(1.0))
queue2.set_service(jobclass2, Exp.fit_mean(1.2))

queue3.set_service(jobclass1, Exp.fit_mean(0.8))
queue3.set_service(jobclass2, Exp.fit_mean(1.0))

# Set up tandem routing (all jobs visit all stations in order)
P = model.init_routing_matrix()
P[0][0] = model.serial_routing([delay, queue1, queue2, queue3])
P[1][1] = model.serial_routing([delay, queue1, queue2, queue3])
model.link(P)

# Solve original model with MVA
print('\n--- Solving Original Model ---')
solver_original = MVA(model)
avg_table_original = solver_original.getAvgTable()
print('Original model results:')
print(avg_table_original)

# Check if FES aggregation is available
print('\n--- FES Aggregation ---')
try:
    from line_solver.io.model_adapter import ModelAdapter
    if hasattr(ModelAdapter, 'aggregate_fes'):
        station_subset = [queue1, queue2]
        options = {'verbose': True, 'solver': 'mva'}
        result = ModelAdapter.aggregate_fes(model, station_subset, options)

        print('\nFES model created successfully!')
        print(f'FES station name: {result.fesStation.get_name()}')
        print(f'Number of stations in FES model: {result.model.get_number_of_stations()}')

        # Solve FES model
        print('\n--- Solving FES Model ---')
        solver_fes = MVA(result.model)
        avg_table_fes = solver_fes.getAvgTable()
        print('FES model results:')
        print(avg_table_fes)
    else:
        print('NOTE: ModelAdapter.aggregate_fes is not yet implemented in native Python.')
        print('      Use python-wrapper for full FES aggregation functionality.')
except (ImportError, AttributeError) as e:
    print('NOTE: FES aggregation is not yet implemented in native Python.')
    print('      Use python-wrapper for full FES aggregation functionality.')
    print(f'      ({e})')

print('\n=== Example Complete ===')
