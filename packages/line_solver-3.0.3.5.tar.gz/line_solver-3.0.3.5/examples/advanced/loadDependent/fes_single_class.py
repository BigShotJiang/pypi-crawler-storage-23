"""
Single-Class FES Aggregation Example

This tests FES aggregation with a single job class, where it should be exact.

NOTE: FES aggregation is not yet implemented in native Python.
This example is provided for API compatibility documentation.
Use python-wrapper for full FES aggregation functionality.

Copyright (c) 2012-2026, Imperial College London
All rights reserved.
"""

from line_solver import *

print('=== Single-Class FES Aggregation Example ===\n')

# Create original 4-station tandem network with 1 class
print('Creating original 4-station network...')

N1 = 5  # number of jobs

model = Network('OriginalModel')

# Create stations
delay = Delay(model, 'ThinkTime')
queue1 = Queue(model, 'Queue1', SchedStrategy.PS)
queue2 = Queue(model, 'Queue2', SchedStrategy.PS)
queue3 = Queue(model, 'Queue3', SchedStrategy.PS)

# Create job class
jobclass1 = ClosedClass(model, 'Class1', N1, delay, 0)

# Set service times
delay.set_service(jobclass1, Exp.fit_mean(5.0))
queue1.set_service(jobclass1, Exp.fit_mean(1.5))
queue2.set_service(jobclass1, Exp.fit_mean(1.0))
queue3.set_service(jobclass1, Exp.fit_mean(0.8))

# Set up tandem routing
P = model.init_routing_matrix()
P[0][0] = model.serial_routing([delay, queue1, queue2, queue3])
model.link(P)

# Solve original model with MVA
print('\n--- Solving Original Model ---')
solver_original = MVA(model)
avg_table_original = solver_original.getAvgTable()
print('Original model results:')
print(avg_table_original)

# Check if FES aggregation is available
print('\n--- FES Aggregation ---')
try:
    from line_solver.io.model_adapter import ModelAdapter
    if hasattr(ModelAdapter, 'aggregate_fes'):
        station_subset = [queue1, queue2]
        options = {'verbose': True, 'solver': 'mva'}
        result = ModelAdapter.aggregate_fes(model, station_subset, options)

        print('\nFES model created successfully!')
        print(f'FES station name: {result.fesStation.get_name()}')
        print(f'Number of stations in FES model: {result.model.get_number_of_stations()}')

        # Solve FES model
        print('\n--- Solving FES Model ---')
        solver_fes = MVA(result.model)
        avg_table_fes = solver_fes.getAvgTable()
        print('FES model results:')
        print(avg_table_fes)
    else:
        print('NOTE: ModelAdapter.aggregate_fes is not yet implemented in native Python.')
        print('      Use python-wrapper for full FES aggregation functionality.')
except (ImportError, AttributeError) as e:
    print('NOTE: FES aggregation is not yet implemented in native Python.')
    print('      Use python-wrapper for full FES aggregation functionality.')
    print(f'      ({e})')

print('\n=== Example Complete ===')
