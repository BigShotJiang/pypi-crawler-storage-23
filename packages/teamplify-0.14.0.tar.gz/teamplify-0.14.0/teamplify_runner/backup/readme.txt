This folder serves as a mount point for DB backups
