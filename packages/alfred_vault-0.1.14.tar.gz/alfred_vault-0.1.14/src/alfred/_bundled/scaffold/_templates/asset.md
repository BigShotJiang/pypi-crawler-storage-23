---
type: asset
status: active # active | retired | maintenance | disposed
name:
description:
asset_type: # software | hardware | license | domain | infrastructure | equipment | ip
owner: # Link to Person (responsible party)
vendor: # Link to Org (who provides/sold it)
account: # Link to Account (associated account)
project: # Link to Project (if project-specific)
location: # Link to Location (where it physically lives)
cost:
acquired:
renewal_date:
related: []
relationships: []
created: "{{date}}"
tags: []
---

# {{title}}

## Details

<!-- What this asset is, what it's used for, any configuration notes -->

## Related
![[asset.base#Related]]
