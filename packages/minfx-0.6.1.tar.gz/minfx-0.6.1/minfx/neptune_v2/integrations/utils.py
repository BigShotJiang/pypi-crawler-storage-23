#
# Copyright (c) 2022, Neptune Labs Sp. z o.o.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
__all__ = ["RunType", "check_not_neptune_sdk_run", "expect_not_an_experiment", "join_paths", "verify_type"]

from typing import Union

from minfx.neptune_v2 import Run
from minfx.neptune_v2.common.experiments import LegacyExperiment as Experiment
from minfx.neptune_v2.exceptions import NeptuneLegacyIncompatibilityException
from minfx.neptune_v2.handler import Handler
from minfx.neptune_v2.internal.types.neptune_sdk_compat import check_not_neptune_sdk_run
from minfx.neptune_v2.internal.utils import verify_type
from minfx.neptune_v2.internal.utils.paths import join_paths


def expect_not_an_experiment(run: Run):
    check_not_neptune_sdk_run(run)
    if isinstance(run, Experiment):
        raise NeptuneLegacyIncompatibilityException


RunType = Union[Run, Handler]
