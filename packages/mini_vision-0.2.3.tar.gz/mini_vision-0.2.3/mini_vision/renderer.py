import cv2


class SegmentationRenderer:

    COLOR_MAP = {
        "red": (0,0,255),
        "green": (0,255,0),
        "blue": (255,0,0),
        "yellow": (0,255,255),
        "cyan": (255,255,0),
        "magenta": (255,0,255),
        "white": (255,255,255),
        "black": (0,0,0),
        "orange": (0,165,255),
        "purple": (128,0,128),
        "pink": (203,192,255),

        "neon_pink": (147,20,255),
        "lime": (50,205,50),
        "teal": (128,128,0),
        "gold": (0,215,255),
        "navy": (128,0,0)
        }
    
    def _get_color(self, label, detect_object, detect_color):

        if not detect_object or not detect_color:
            return (0,255,0)

        for i, obj in enumerate(detect_object):

            if obj == label and i < len(detect_color):

                color = detect_color[i]

                if isinstance(color, tuple):
                    return color

                if isinstance(color, str):
                    return self.COLOR_MAP.get(color.lower(), (0,255,0))

        return (0,255,0)

    def draw(
        self,
        frame,
        detections,
        mode="contour",
        detect_object=None,
        detect_color=None,
        thickness=2
    ):

        for det in detections:

            mask = det["mask"]
            label = det.get("label", "")
            score = det.get("score", None)

            color = self._get_color(label, detect_object, detect_color)

            contours, _ = cv2.findContours(
                mask,
                cv2.RETR_EXTERNAL,
                cv2.CHAIN_APPROX_SIMPLE
            )

            for cnt in contours:

                x, y, w, h = cv2.boundingRect(cnt)

                if mode == "contour":

                    cv2.drawContours(
                        frame,
                        [cnt],
                        -1,
                        color,
                        thickness
                    )

                elif mode == "box":

                    cv2.rectangle(
                        frame,
                        (x,y),
                        (x+w, y+h),
                        color,
                        thickness
                    )

                text = label

                if score is not None:
                    text = f"{label} {score:.2f}"

                if text:

                    cv2.putText(
                        frame,
                        text,
                        (x, y-5),
                        cv2.FONT_HERSHEY_SIMPLEX,
                        0.5,
                        color,
                        thickness
                    )
        return frame