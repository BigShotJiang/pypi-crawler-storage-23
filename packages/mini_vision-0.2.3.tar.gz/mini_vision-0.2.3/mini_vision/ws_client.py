import asyncio
import websockets
import cv2
import numpy as np


class WSFrameClient:

    def __init__(self, url):
        self.url = url

    async def frames(self):

        async with websockets.connect(self.url) as ws:

            while True:

                data = await ws.recv()

                np_arr = np.frombuffer(data, np.uint8)

                frame = cv2.imdecode(np_arr, cv2.IMREAD_COLOR)

                if frame is not None:
                    yield frame