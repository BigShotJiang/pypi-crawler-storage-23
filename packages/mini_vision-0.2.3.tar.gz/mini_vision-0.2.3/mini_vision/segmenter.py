from ultralytics import YOLO
import cv2


class YoloSegmenter:

    def __init__(self, model_path):
        self.model = YOLO(model_path)
        self.names = self.model.names

    def segment(self, frame):

        results = self.model(frame)

        detections = []

        for r in results:

            if r.masks is None:
                continue

            masks = r.masks.data
            classes = r.boxes.cls
            confs = r.boxes.conf

            for mask, cls, conf in zip(masks, classes, confs):

                label = self.names[int(cls)]

                mask = mask.cpu().numpy()

                mask = cv2.resize(mask, (frame.shape[1], frame.shape[0]))

                mask = (mask > 0.5).astype("uint8") * 255

                detections.append({
                    "label": label,
                    "confidence": float(conf),
                    "mask": mask
                })

        return detections