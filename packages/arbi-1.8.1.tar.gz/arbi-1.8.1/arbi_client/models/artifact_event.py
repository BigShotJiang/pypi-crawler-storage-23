from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.artifact_event_mode import ArtifactEventMode
from ..types import UNSET, Unset
from typing import cast
from typing import Literal, cast






T = TypeVar("T", bound="ArtifactEvent")



@_attrs_define
class ArtifactEvent:
    r""" A generated artifact (document/draft) for the artifact panel.

    Artifacts ARE documents (wp_type='artifact') - the doc_ext_id is the single
    identifier used throughout. They support versioning for redline/track-changes
    functionality (useful for legal document review).

    The frontend should:
    - Open the artifact panel when receiving an artifact event
    - Stream content updates while is_complete=False
    - Enable redline view when multiple versions exist

    Examples:
        {"type": "arbi.artifact", "doc_ext_id": "doc-abc12345", "title": "Contract Summary",
         "mode": "markdown", "content": "# Summary\n...", "is_complete": false}
        {"type": "arbi.artifact", "doc_ext_id": "doc-abc12345", "title": "Contract Summary",
         "mode": "markdown", "content": "# Summary\n...", "is_complete": true, "version": 1}

        Attributes:
            doc_ext_id (str): Document external ID (artifacts are documents)
            title (str): Display title for the artifact
            content (str): The artifact content (markdown, html, or plain text)
            t (float | None | Unset): Seconds elapsed since stream start.
            type_ (Literal['arbi.artifact'] | Unset):  Default: 'arbi.artifact'.
            mode (ArtifactEventMode | Unset): Rendering mode: markdown (default, supports redlines), html, or plain text
                Default: ArtifactEventMode.MARKDOWN.
            is_complete (bool | Unset): Whether the artifact is fully generated (False during streaming) Default: False.
            version (int | Unset): Version number for tracking changes/redlines Default: 1.
            message_ext_id (None | str | Unset): External ID of the assistant message that generated this artifact
     """

    doc_ext_id: str
    title: str
    content: str
    t: float | None | Unset = UNSET
    type_: Literal['arbi.artifact'] | Unset = 'arbi.artifact'
    mode: ArtifactEventMode | Unset = ArtifactEventMode.MARKDOWN
    is_complete: bool | Unset = False
    version: int | Unset = 1
    message_ext_id: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        doc_ext_id = self.doc_ext_id

        title = self.title

        content = self.content

        t: float | None | Unset
        if isinstance(self.t, Unset):
            t = UNSET
        else:
            t = self.t

        type_ = self.type_

        mode: str | Unset = UNSET
        if not isinstance(self.mode, Unset):
            mode = self.mode.value


        is_complete = self.is_complete

        version = self.version

        message_ext_id: None | str | Unset
        if isinstance(self.message_ext_id, Unset):
            message_ext_id = UNSET
        else:
            message_ext_id = self.message_ext_id


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "doc_ext_id": doc_ext_id,
            "title": title,
            "content": content,
        })
        if t is not UNSET:
            field_dict["t"] = t
        if type_ is not UNSET:
            field_dict["type"] = type_
        if mode is not UNSET:
            field_dict["mode"] = mode
        if is_complete is not UNSET:
            field_dict["is_complete"] = is_complete
        if version is not UNSET:
            field_dict["version"] = version
        if message_ext_id is not UNSET:
            field_dict["message_ext_id"] = message_ext_id

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        doc_ext_id = d.pop("doc_ext_id")

        title = d.pop("title")

        content = d.pop("content")

        def _parse_t(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        t = _parse_t(d.pop("t", UNSET))


        type_ = cast(Literal['arbi.artifact'] | Unset , d.pop("type", UNSET))
        if type_ != 'arbi.artifact'and not isinstance(type_, Unset):
            raise ValueError(f"type must match const 'arbi.artifact', got '{type_}'")

        _mode = d.pop("mode", UNSET)
        mode: ArtifactEventMode | Unset
        if isinstance(_mode,  Unset):
            mode = UNSET
        else:
            mode = ArtifactEventMode(_mode)




        is_complete = d.pop("is_complete", UNSET)

        version = d.pop("version", UNSET)

        def _parse_message_ext_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        message_ext_id = _parse_message_ext_id(d.pop("message_ext_id", UNSET))


        artifact_event = cls(
            doc_ext_id=doc_ext_id,
            title=title,
            content=content,
            t=t,
            type_=type_,
            mode=mode,
            is_complete=is_complete,
            version=version,
            message_ext_id=message_ext_id,
        )


        artifact_event.additional_properties = d
        return artifact_event

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
