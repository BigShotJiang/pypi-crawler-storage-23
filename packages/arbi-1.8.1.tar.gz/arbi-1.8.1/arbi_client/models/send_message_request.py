from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast

if TYPE_CHECKING:
  from ..models.message_recipient import MessageRecipient





T = TypeVar("T", bound="SendMessageRequest")



@_attrs_define
class SendMessageRequest:
    """ Send E2E encrypted messages to one or more users.

    Each recipient gets the same logical message, encrypted with their
    individual shared key (derived from X25519 DH).

        Attributes:
            messages (list[MessageRecipient]):
     """

    messages: list[MessageRecipient]





    def to_dict(self) -> dict[str, Any]:
        from ..models.message_recipient import MessageRecipient
        messages = []
        for messages_item_data in self.messages:
            messages_item = messages_item_data.to_dict()
            messages.append(messages_item)




        field_dict: dict[str, Any] = {}

        field_dict.update({
            "messages": messages,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.message_recipient import MessageRecipient
        d = dict(src_dict)
        messages = []
        _messages = d.pop("messages")
        for messages_item_data in (_messages):
            messages_item = MessageRecipient.from_dict(messages_item_data)



            messages.append(messages_item)


        send_message_request = cls(
            messages=messages,
        )

        return send_message_request

