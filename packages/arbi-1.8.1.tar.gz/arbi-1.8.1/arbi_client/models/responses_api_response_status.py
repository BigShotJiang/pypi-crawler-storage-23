from enum import Enum

class ResponsesAPIResponseStatus(str, Enum):
    CANCELLED = "cancelled"
    COMPLETED = "completed"
    FAILED = "failed"
    INCOMPLETE = "incomplete"
    IN_PROGRESS = "in_progress"
    QUEUED = "queued"

    def __str__(self) -> str:
        return str(self.value)
