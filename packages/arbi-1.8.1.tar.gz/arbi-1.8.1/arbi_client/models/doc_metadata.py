from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from dateutil.parser import isoparse
from typing import cast
import datetime






T = TypeVar("T", bound="DocMetadata")



@_attrs_define
class DocMetadata:
    """ Structured model for document metadata stored in JSONB column.

        Attributes:
            doc_nature (None | str | Unset):
            doc_author (None | str | Unset):
            doc_subject (None | str | Unset):
            doc_date (datetime.date | None | Unset):
            title (None | str | Unset):
     """

    doc_nature: None | str | Unset = UNSET
    doc_author: None | str | Unset = UNSET
    doc_subject: None | str | Unset = UNSET
    doc_date: datetime.date | None | Unset = UNSET
    title: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        doc_nature: None | str | Unset
        if isinstance(self.doc_nature, Unset):
            doc_nature = UNSET
        else:
            doc_nature = self.doc_nature

        doc_author: None | str | Unset
        if isinstance(self.doc_author, Unset):
            doc_author = UNSET
        else:
            doc_author = self.doc_author

        doc_subject: None | str | Unset
        if isinstance(self.doc_subject, Unset):
            doc_subject = UNSET
        else:
            doc_subject = self.doc_subject

        doc_date: None | str | Unset
        if isinstance(self.doc_date, Unset):
            doc_date = UNSET
        elif isinstance(self.doc_date, datetime.date):
            doc_date = self.doc_date.isoformat()
        else:
            doc_date = self.doc_date

        title: None | str | Unset
        if isinstance(self.title, Unset):
            title = UNSET
        else:
            title = self.title


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if doc_nature is not UNSET:
            field_dict["doc_nature"] = doc_nature
        if doc_author is not UNSET:
            field_dict["doc_author"] = doc_author
        if doc_subject is not UNSET:
            field_dict["doc_subject"] = doc_subject
        if doc_date is not UNSET:
            field_dict["doc_date"] = doc_date
        if title is not UNSET:
            field_dict["title"] = title

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        def _parse_doc_nature(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        doc_nature = _parse_doc_nature(d.pop("doc_nature", UNSET))


        def _parse_doc_author(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        doc_author = _parse_doc_author(d.pop("doc_author", UNSET))


        def _parse_doc_subject(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        doc_subject = _parse_doc_subject(d.pop("doc_subject", UNSET))


        def _parse_doc_date(data: object) -> datetime.date | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                doc_date_type_0 = isoparse(data).date()



                return doc_date_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.date | None | Unset, data)

        doc_date = _parse_doc_date(d.pop("doc_date", UNSET))


        def _parse_title(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        title = _parse_title(d.pop("title", UNSET))


        doc_metadata = cls(
            doc_nature=doc_nature,
            doc_author=doc_author,
            doc_subject=doc_subject,
            doc_date=doc_date,
            title=title,
        )


        doc_metadata.additional_properties = d
        return doc_metadata

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
