from enum import Enum

class TagFormatType(str, Enum):
    CHECKBOX = "checkbox"
    DATE = "date"
    NUMBER = "number"
    SEARCH = "search"
    SELECT = "select"
    TEXT = "text"

    def __str__(self) -> str:
        return str(self.value)
