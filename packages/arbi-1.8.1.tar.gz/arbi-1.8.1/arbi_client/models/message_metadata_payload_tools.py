from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast

if TYPE_CHECKING:
  from ..models.compaction_tool import CompactionTool
  from ..models.model_citation_tool import ModelCitationTool
  from ..models.personal_agent_tool import PersonalAgentTool
  from ..models.retrieval_chunk_tool import RetrievalChunkTool
  from ..models.retrieval_full_context_tool import RetrievalFullContextTool
  from ..models.retrieval_toc_tool import RetrievalTOCTool
  from ..models.stream_events_tool import StreamEventsTool
  from ..models.trace_tool import TraceTool





T = TypeVar("T", bound="MessageMetadataPayloadTools")



@_attrs_define
class MessageMetadataPayloadTools:
    """ 
     """

    additional_properties: dict[str, CompactionTool | ModelCitationTool | PersonalAgentTool | RetrievalChunkTool | RetrievalFullContextTool | RetrievalTOCTool | StreamEventsTool | TraceTool] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.retrieval_chunk_tool import RetrievalChunkTool
        from ..models.model_citation_tool import ModelCitationTool
        from ..models.retrieval_toc_tool import RetrievalTOCTool
        from ..models.stream_events_tool import StreamEventsTool
        from ..models.trace_tool import TraceTool
        from ..models.personal_agent_tool import PersonalAgentTool
        from ..models.compaction_tool import CompactionTool
        from ..models.retrieval_full_context_tool import RetrievalFullContextTool
        
        field_dict: dict[str, Any] = {}
        for prop_name, prop in self.additional_properties.items():
            
            if isinstance(prop, ModelCitationTool):
                field_dict[prop_name] = prop.to_dict()
            elif isinstance(prop, RetrievalChunkTool):
                field_dict[prop_name] = prop.to_dict()
            elif isinstance(prop, RetrievalFullContextTool):
                field_dict[prop_name] = prop.to_dict()
            elif isinstance(prop, RetrievalTOCTool):
                field_dict[prop_name] = prop.to_dict()
            elif isinstance(prop, TraceTool):
                field_dict[prop_name] = prop.to_dict()
            elif isinstance(prop, CompactionTool):
                field_dict[prop_name] = prop.to_dict()
            elif isinstance(prop, PersonalAgentTool):
                field_dict[prop_name] = prop.to_dict()
            else:
                field_dict[prop_name] = prop.to_dict()



        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.compaction_tool import CompactionTool
        from ..models.model_citation_tool import ModelCitationTool
        from ..models.personal_agent_tool import PersonalAgentTool
        from ..models.retrieval_chunk_tool import RetrievalChunkTool
        from ..models.retrieval_full_context_tool import RetrievalFullContextTool
        from ..models.retrieval_toc_tool import RetrievalTOCTool
        from ..models.stream_events_tool import StreamEventsTool
        from ..models.trace_tool import TraceTool
        d = dict(src_dict)
        message_metadata_payload_tools = cls(
        )


        additional_properties = {}
        for prop_name, prop_dict in d.items():
            def _parse_additional_property(data: object) -> CompactionTool | ModelCitationTool | PersonalAgentTool | RetrievalChunkTool | RetrievalFullContextTool | RetrievalTOCTool | StreamEventsTool | TraceTool:
                try:
                    if not isinstance(data, dict):
                        raise TypeError()
                    additional_property_type_0 = ModelCitationTool.from_dict(data)



                    return additional_property_type_0
                except (TypeError, ValueError, AttributeError, KeyError):
                    pass
                try:
                    if not isinstance(data, dict):
                        raise TypeError()
                    additional_property_type_1 = RetrievalChunkTool.from_dict(data)



                    return additional_property_type_1
                except (TypeError, ValueError, AttributeError, KeyError):
                    pass
                try:
                    if not isinstance(data, dict):
                        raise TypeError()
                    additional_property_type_2 = RetrievalFullContextTool.from_dict(data)



                    return additional_property_type_2
                except (TypeError, ValueError, AttributeError, KeyError):
                    pass
                try:
                    if not isinstance(data, dict):
                        raise TypeError()
                    additional_property_type_3 = RetrievalTOCTool.from_dict(data)



                    return additional_property_type_3
                except (TypeError, ValueError, AttributeError, KeyError):
                    pass
                try:
                    if not isinstance(data, dict):
                        raise TypeError()
                    additional_property_type_4 = TraceTool.from_dict(data)



                    return additional_property_type_4
                except (TypeError, ValueError, AttributeError, KeyError):
                    pass
                try:
                    if not isinstance(data, dict):
                        raise TypeError()
                    additional_property_type_5 = CompactionTool.from_dict(data)



                    return additional_property_type_5
                except (TypeError, ValueError, AttributeError, KeyError):
                    pass
                try:
                    if not isinstance(data, dict):
                        raise TypeError()
                    additional_property_type_6 = PersonalAgentTool.from_dict(data)



                    return additional_property_type_6
                except (TypeError, ValueError, AttributeError, KeyError):
                    pass
                if not isinstance(data, dict):
                    raise TypeError()
                additional_property_type_7 = StreamEventsTool.from_dict(data)



                return additional_property_type_7

            additional_property = _parse_additional_property(prop_dict)

            additional_properties[prop_name] = additional_property

        message_metadata_payload_tools.additional_properties = additional_properties
        return message_metadata_payload_tools

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> CompactionTool | ModelCitationTool | PersonalAgentTool | RetrievalChunkTool | RetrievalFullContextTool | RetrievalTOCTool | StreamEventsTool | TraceTool:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: CompactionTool | ModelCitationTool | PersonalAgentTool | RetrievalChunkTool | RetrievalFullContextTool | RetrievalTOCTool | StreamEventsTool | TraceTool) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
