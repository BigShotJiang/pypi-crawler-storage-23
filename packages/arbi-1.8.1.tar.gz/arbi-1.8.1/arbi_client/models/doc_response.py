from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from dateutil.parser import isoparse
from typing import cast
import datetime

if TYPE_CHECKING:
  from ..models.doc_metadata import DocMetadata
  from ..models.doc_tag_response import DocTagResponse





T = TypeVar("T", bound="DocResponse")



@_attrs_define
class DocResponse:
    """ 
        Attributes:
            external_id (str):
            workspace_ext_id (str):
            created_by_ext_id (str):
            created_at (datetime.datetime):
            updated_at (datetime.datetime):
            file_name (None | str | Unset):
            status (None | str | Unset):
            n_pages (int | None | Unset):
            n_chunks (int | None | Unset):
            tokens (int | None | Unset):
            file_type (None | str | Unset):
            file_size (int | None | Unset):
            storage_type (None | str | Unset):
            storage_uri (None | str | Unset):
            content_hash (None | str | Unset):
            shared (bool | None | Unset):
            re_ocred (bool | None | Unset):
            config_ext_id (None | str | Unset):
            parent_ext_id (None | str | Unset):
            updated_by_ext_id (None | str | Unset):
            wp_type (None | str | Unset):
            folder (None | str | Unset):
            doctags (list[DocTagResponse] | Unset):
            doc_metadata (DocMetadata | None | Unset):
     """

    external_id: str
    workspace_ext_id: str
    created_by_ext_id: str
    created_at: datetime.datetime
    updated_at: datetime.datetime
    file_name: None | str | Unset = UNSET
    status: None | str | Unset = UNSET
    n_pages: int | None | Unset = UNSET
    n_chunks: int | None | Unset = UNSET
    tokens: int | None | Unset = UNSET
    file_type: None | str | Unset = UNSET
    file_size: int | None | Unset = UNSET
    storage_type: None | str | Unset = UNSET
    storage_uri: None | str | Unset = UNSET
    content_hash: None | str | Unset = UNSET
    shared: bool | None | Unset = UNSET
    re_ocred: bool | None | Unset = UNSET
    config_ext_id: None | str | Unset = UNSET
    parent_ext_id: None | str | Unset = UNSET
    updated_by_ext_id: None | str | Unset = UNSET
    wp_type: None | str | Unset = UNSET
    folder: None | str | Unset = UNSET
    doctags: list[DocTagResponse] | Unset = UNSET
    doc_metadata: DocMetadata | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.doc_metadata import DocMetadata
        from ..models.doc_tag_response import DocTagResponse
        external_id = self.external_id

        workspace_ext_id = self.workspace_ext_id

        created_by_ext_id = self.created_by_ext_id

        created_at = self.created_at.isoformat()

        updated_at = self.updated_at.isoformat()

        file_name: None | str | Unset
        if isinstance(self.file_name, Unset):
            file_name = UNSET
        else:
            file_name = self.file_name

        status: None | str | Unset
        if isinstance(self.status, Unset):
            status = UNSET
        else:
            status = self.status

        n_pages: int | None | Unset
        if isinstance(self.n_pages, Unset):
            n_pages = UNSET
        else:
            n_pages = self.n_pages

        n_chunks: int | None | Unset
        if isinstance(self.n_chunks, Unset):
            n_chunks = UNSET
        else:
            n_chunks = self.n_chunks

        tokens: int | None | Unset
        if isinstance(self.tokens, Unset):
            tokens = UNSET
        else:
            tokens = self.tokens

        file_type: None | str | Unset
        if isinstance(self.file_type, Unset):
            file_type = UNSET
        else:
            file_type = self.file_type

        file_size: int | None | Unset
        if isinstance(self.file_size, Unset):
            file_size = UNSET
        else:
            file_size = self.file_size

        storage_type: None | str | Unset
        if isinstance(self.storage_type, Unset):
            storage_type = UNSET
        else:
            storage_type = self.storage_type

        storage_uri: None | str | Unset
        if isinstance(self.storage_uri, Unset):
            storage_uri = UNSET
        else:
            storage_uri = self.storage_uri

        content_hash: None | str | Unset
        if isinstance(self.content_hash, Unset):
            content_hash = UNSET
        else:
            content_hash = self.content_hash

        shared: bool | None | Unset
        if isinstance(self.shared, Unset):
            shared = UNSET
        else:
            shared = self.shared

        re_ocred: bool | None | Unset
        if isinstance(self.re_ocred, Unset):
            re_ocred = UNSET
        else:
            re_ocred = self.re_ocred

        config_ext_id: None | str | Unset
        if isinstance(self.config_ext_id, Unset):
            config_ext_id = UNSET
        else:
            config_ext_id = self.config_ext_id

        parent_ext_id: None | str | Unset
        if isinstance(self.parent_ext_id, Unset):
            parent_ext_id = UNSET
        else:
            parent_ext_id = self.parent_ext_id

        updated_by_ext_id: None | str | Unset
        if isinstance(self.updated_by_ext_id, Unset):
            updated_by_ext_id = UNSET
        else:
            updated_by_ext_id = self.updated_by_ext_id

        wp_type: None | str | Unset
        if isinstance(self.wp_type, Unset):
            wp_type = UNSET
        else:
            wp_type = self.wp_type

        folder: None | str | Unset
        if isinstance(self.folder, Unset):
            folder = UNSET
        else:
            folder = self.folder

        doctags: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.doctags, Unset):
            doctags = []
            for doctags_item_data in self.doctags:
                doctags_item = doctags_item_data.to_dict()
                doctags.append(doctags_item)



        doc_metadata: dict[str, Any] | None | Unset
        if isinstance(self.doc_metadata, Unset):
            doc_metadata = UNSET
        elif isinstance(self.doc_metadata, DocMetadata):
            doc_metadata = self.doc_metadata.to_dict()
        else:
            doc_metadata = self.doc_metadata


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "external_id": external_id,
            "workspace_ext_id": workspace_ext_id,
            "created_by_ext_id": created_by_ext_id,
            "created_at": created_at,
            "updated_at": updated_at,
        })
        if file_name is not UNSET:
            field_dict["file_name"] = file_name
        if status is not UNSET:
            field_dict["status"] = status
        if n_pages is not UNSET:
            field_dict["n_pages"] = n_pages
        if n_chunks is not UNSET:
            field_dict["n_chunks"] = n_chunks
        if tokens is not UNSET:
            field_dict["tokens"] = tokens
        if file_type is not UNSET:
            field_dict["file_type"] = file_type
        if file_size is not UNSET:
            field_dict["file_size"] = file_size
        if storage_type is not UNSET:
            field_dict["storage_type"] = storage_type
        if storage_uri is not UNSET:
            field_dict["storage_uri"] = storage_uri
        if content_hash is not UNSET:
            field_dict["content_hash"] = content_hash
        if shared is not UNSET:
            field_dict["shared"] = shared
        if re_ocred is not UNSET:
            field_dict["re_ocred"] = re_ocred
        if config_ext_id is not UNSET:
            field_dict["config_ext_id"] = config_ext_id
        if parent_ext_id is not UNSET:
            field_dict["parent_ext_id"] = parent_ext_id
        if updated_by_ext_id is not UNSET:
            field_dict["updated_by_ext_id"] = updated_by_ext_id
        if wp_type is not UNSET:
            field_dict["wp_type"] = wp_type
        if folder is not UNSET:
            field_dict["folder"] = folder
        if doctags is not UNSET:
            field_dict["doctags"] = doctags
        if doc_metadata is not UNSET:
            field_dict["doc_metadata"] = doc_metadata

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.doc_metadata import DocMetadata
        from ..models.doc_tag_response import DocTagResponse
        d = dict(src_dict)
        external_id = d.pop("external_id")

        workspace_ext_id = d.pop("workspace_ext_id")

        created_by_ext_id = d.pop("created_by_ext_id")

        created_at = isoparse(d.pop("created_at"))




        updated_at = isoparse(d.pop("updated_at"))




        def _parse_file_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        file_name = _parse_file_name(d.pop("file_name", UNSET))


        def _parse_status(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        status = _parse_status(d.pop("status", UNSET))


        def _parse_n_pages(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        n_pages = _parse_n_pages(d.pop("n_pages", UNSET))


        def _parse_n_chunks(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        n_chunks = _parse_n_chunks(d.pop("n_chunks", UNSET))


        def _parse_tokens(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        tokens = _parse_tokens(d.pop("tokens", UNSET))


        def _parse_file_type(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        file_type = _parse_file_type(d.pop("file_type", UNSET))


        def _parse_file_size(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        file_size = _parse_file_size(d.pop("file_size", UNSET))


        def _parse_storage_type(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        storage_type = _parse_storage_type(d.pop("storage_type", UNSET))


        def _parse_storage_uri(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        storage_uri = _parse_storage_uri(d.pop("storage_uri", UNSET))


        def _parse_content_hash(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        content_hash = _parse_content_hash(d.pop("content_hash", UNSET))


        def _parse_shared(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        shared = _parse_shared(d.pop("shared", UNSET))


        def _parse_re_ocred(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        re_ocred = _parse_re_ocred(d.pop("re_ocred", UNSET))


        def _parse_config_ext_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        config_ext_id = _parse_config_ext_id(d.pop("config_ext_id", UNSET))


        def _parse_parent_ext_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        parent_ext_id = _parse_parent_ext_id(d.pop("parent_ext_id", UNSET))


        def _parse_updated_by_ext_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        updated_by_ext_id = _parse_updated_by_ext_id(d.pop("updated_by_ext_id", UNSET))


        def _parse_wp_type(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        wp_type = _parse_wp_type(d.pop("wp_type", UNSET))


        def _parse_folder(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        folder = _parse_folder(d.pop("folder", UNSET))


        _doctags = d.pop("doctags", UNSET)
        doctags: list[DocTagResponse] | Unset = UNSET
        if _doctags is not UNSET:
            doctags = []
            for doctags_item_data in _doctags:
                doctags_item = DocTagResponse.from_dict(doctags_item_data)



                doctags.append(doctags_item)


        def _parse_doc_metadata(data: object) -> DocMetadata | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                doc_metadata_type_0 = DocMetadata.from_dict(data)



                return doc_metadata_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(DocMetadata | None | Unset, data)

        doc_metadata = _parse_doc_metadata(d.pop("doc_metadata", UNSET))


        doc_response = cls(
            external_id=external_id,
            workspace_ext_id=workspace_ext_id,
            created_by_ext_id=created_by_ext_id,
            created_at=created_at,
            updated_at=updated_at,
            file_name=file_name,
            status=status,
            n_pages=n_pages,
            n_chunks=n_chunks,
            tokens=tokens,
            file_type=file_type,
            file_size=file_size,
            storage_type=storage_type,
            storage_uri=storage_uri,
            content_hash=content_hash,
            shared=shared,
            re_ocred=re_ocred,
            config_ext_id=config_ext_id,
            parent_ext_id=parent_ext_id,
            updated_by_ext_id=updated_by_ext_id,
            wp_type=wp_type,
            folder=folder,
            doctags=doctags,
            doc_metadata=doc_metadata,
        )


        doc_response.additional_properties = d
        return doc_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
