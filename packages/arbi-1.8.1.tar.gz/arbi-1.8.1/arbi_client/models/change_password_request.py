from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast

if TYPE_CHECKING:
  from ..models.change_password_request_rewrapped_workspace_keys import ChangePasswordRequestRewrappedWorkspaceKeys





T = TypeVar("T", bound="ChangePasswordRequest")



@_attrs_define
class ChangePasswordRequest:
    """ Password change request with signature-based auth.

    Client proves knowledge of current password by signing with Ed25519 key.
    Server derives new X25519 encryption key from new Ed25519 signing key.

        Attributes:
            signature (str):
            timestamp (int):
            new_signing_key (str):
            rewrapped_workspace_keys (ChangePasswordRequestRewrappedWorkspaceKeys):
     """

    signature: str
    timestamp: int
    new_signing_key: str
    rewrapped_workspace_keys: ChangePasswordRequestRewrappedWorkspaceKeys





    def to_dict(self) -> dict[str, Any]:
        from ..models.change_password_request_rewrapped_workspace_keys import ChangePasswordRequestRewrappedWorkspaceKeys
        signature = self.signature

        timestamp = self.timestamp

        new_signing_key = self.new_signing_key

        rewrapped_workspace_keys = self.rewrapped_workspace_keys.to_dict()


        field_dict: dict[str, Any] = {}

        field_dict.update({
            "signature": signature,
            "timestamp": timestamp,
            "new_signing_key": new_signing_key,
            "rewrapped_workspace_keys": rewrapped_workspace_keys,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.change_password_request_rewrapped_workspace_keys import ChangePasswordRequestRewrappedWorkspaceKeys
        d = dict(src_dict)
        signature = d.pop("signature")

        timestamp = d.pop("timestamp")

        new_signing_key = d.pop("new_signing_key")

        rewrapped_workspace_keys = ChangePasswordRequestRewrappedWorkspaceKeys.from_dict(d.pop("rewrapped_workspace_keys"))




        change_password_request = cls(
            signature=signature,
            timestamp=timestamp,
            new_signing_key=new_signing_key,
            rewrapped_workspace_keys=rewrapped_workspace_keys,
        )

        return change_password_request

