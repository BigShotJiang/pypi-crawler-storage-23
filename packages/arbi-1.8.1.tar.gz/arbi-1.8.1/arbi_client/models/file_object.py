from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast






T = TypeVar("T", bound="FileObject")



@_attrs_define
class FileObject:
    """ OpenAI-compatible file object response.

    Matches the OpenAI FileObject schema:
    https://platform.openai.com/docs/api-reference/files/object

        Attributes:
            id (str):
            bytes_ (int):
            created_at (int):
            filename (str):
            object_ (str | Unset):  Default: 'file'.
            purpose (str | Unset):  Default: 'assistants'.
            status (str | Unset):  Default: 'uploaded'.
            expires_at (int | None | Unset):
            status_details (None | str | Unset):
     """

    id: str
    bytes_: int
    created_at: int
    filename: str
    object_: str | Unset = 'file'
    purpose: str | Unset = 'assistants'
    status: str | Unset = 'uploaded'
    expires_at: int | None | Unset = UNSET
    status_details: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        id = self.id

        bytes_ = self.bytes_

        created_at = self.created_at

        filename = self.filename

        object_ = self.object_

        purpose = self.purpose

        status = self.status

        expires_at: int | None | Unset
        if isinstance(self.expires_at, Unset):
            expires_at = UNSET
        else:
            expires_at = self.expires_at

        status_details: None | str | Unset
        if isinstance(self.status_details, Unset):
            status_details = UNSET
        else:
            status_details = self.status_details


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "id": id,
            "bytes": bytes_,
            "created_at": created_at,
            "filename": filename,
        })
        if object_ is not UNSET:
            field_dict["object"] = object_
        if purpose is not UNSET:
            field_dict["purpose"] = purpose
        if status is not UNSET:
            field_dict["status"] = status
        if expires_at is not UNSET:
            field_dict["expires_at"] = expires_at
        if status_details is not UNSET:
            field_dict["status_details"] = status_details

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        id = d.pop("id")

        bytes_ = d.pop("bytes")

        created_at = d.pop("created_at")

        filename = d.pop("filename")

        object_ = d.pop("object", UNSET)

        purpose = d.pop("purpose", UNSET)

        status = d.pop("status", UNSET)

        def _parse_expires_at(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        expires_at = _parse_expires_at(d.pop("expires_at", UNSET))


        def _parse_status_details(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        status_details = _parse_status_details(d.pop("status_details", UNSET))


        file_object = cls(
            id=id,
            bytes_=bytes_,
            created_at=created_at,
            filename=filename,
            object_=object_,
            purpose=purpose,
            status=status,
            expires_at=expires_at,
            status_details=status_details,
        )


        file_object.additional_properties = d
        return file_object

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
