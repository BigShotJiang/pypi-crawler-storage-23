from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast
from typing import Literal, cast

if TYPE_CHECKING:
  from ..models.output_message import OutputMessage





T = TypeVar("T", bound="ResponseCreatedPayload")



@_attrs_define
class ResponseCreatedPayload:
    """ The ``response`` dict in a ``response.created`` SSE event.

        Attributes:
            id (str): Response ID (assistant_message_ext_id)
            created_at (int): Unix epoch timestamp when the response was created
            model (str): Model name used for the response
            output (list[OutputMessage]): Initial output messages (content is empty)
            object_ (Literal['response'] | Unset):  Default: 'response'.
            status (Literal['in_progress'] | Unset):  Default: 'in_progress'.
     """

    id: str
    created_at: int
    model: str
    output: list[OutputMessage]
    object_: Literal['response'] | Unset = 'response'
    status: Literal['in_progress'] | Unset = 'in_progress'
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.output_message import OutputMessage
        id = self.id

        created_at = self.created_at

        model = self.model

        output = []
        for output_item_data in self.output:
            output_item = output_item_data.to_dict()
            output.append(output_item)



        object_ = self.object_

        status = self.status


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "id": id,
            "created_at": created_at,
            "model": model,
            "output": output,
        })
        if object_ is not UNSET:
            field_dict["object"] = object_
        if status is not UNSET:
            field_dict["status"] = status

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.output_message import OutputMessage
        d = dict(src_dict)
        id = d.pop("id")

        created_at = d.pop("created_at")

        model = d.pop("model")

        output = []
        _output = d.pop("output")
        for output_item_data in (_output):
            output_item = OutputMessage.from_dict(output_item_data)



            output.append(output_item)


        object_ = cast(Literal['response'] | Unset , d.pop("object", UNSET))
        if object_ != 'response'and not isinstance(object_, Unset):
            raise ValueError(f"object must match const 'response', got '{object_}'")

        status = cast(Literal['in_progress'] | Unset , d.pop("status", UNSET))
        if status != 'in_progress'and not isinstance(status, Unset):
            raise ValueError(f"status must match const 'in_progress', got '{status}'")

        response_created_payload = cls(
            id=id,
            created_at=created_at,
            model=model,
            output=output,
            object_=object_,
            status=status,
        )


        response_created_payload.additional_properties = d
        return response_created_payload

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
