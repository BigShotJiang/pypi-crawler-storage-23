from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast






T = TypeVar("T", bound="ChunkMetadata")



@_attrs_define
class ChunkMetadata:
    """ 
        Attributes:
            chunk_ext_id (str):
            chunk_pg_idx (int):
            chunk_doc_idx (int):
            page_number (int):
            created_at (str):
            workspace_ext_id (None | str | Unset):
            doc_ext_id (None | str | Unset):
            doc_title (None | str | Unset):
            chunk_id (None | str | Unset):
            score (float | None | Unset):
            rerank_score (float | None | Unset):
            tokens (int | None | Unset):
            heading (bool | Unset):  Default: False.
            bbox (list[float] | None | Unset):
            element_type (None | str | Unset):
            heading_level (int | None | Unset):
     """

    chunk_ext_id: str
    chunk_pg_idx: int
    chunk_doc_idx: int
    page_number: int
    created_at: str
    workspace_ext_id: None | str | Unset = UNSET
    doc_ext_id: None | str | Unset = UNSET
    doc_title: None | str | Unset = UNSET
    chunk_id: None | str | Unset = UNSET
    score: float | None | Unset = UNSET
    rerank_score: float | None | Unset = UNSET
    tokens: int | None | Unset = UNSET
    heading: bool | Unset = False
    bbox: list[float] | None | Unset = UNSET
    element_type: None | str | Unset = UNSET
    heading_level: int | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        chunk_ext_id = self.chunk_ext_id

        chunk_pg_idx = self.chunk_pg_idx

        chunk_doc_idx = self.chunk_doc_idx

        page_number = self.page_number

        created_at = self.created_at

        workspace_ext_id: None | str | Unset
        if isinstance(self.workspace_ext_id, Unset):
            workspace_ext_id = UNSET
        else:
            workspace_ext_id = self.workspace_ext_id

        doc_ext_id: None | str | Unset
        if isinstance(self.doc_ext_id, Unset):
            doc_ext_id = UNSET
        else:
            doc_ext_id = self.doc_ext_id

        doc_title: None | str | Unset
        if isinstance(self.doc_title, Unset):
            doc_title = UNSET
        else:
            doc_title = self.doc_title

        chunk_id: None | str | Unset
        if isinstance(self.chunk_id, Unset):
            chunk_id = UNSET
        else:
            chunk_id = self.chunk_id

        score: float | None | Unset
        if isinstance(self.score, Unset):
            score = UNSET
        else:
            score = self.score

        rerank_score: float | None | Unset
        if isinstance(self.rerank_score, Unset):
            rerank_score = UNSET
        else:
            rerank_score = self.rerank_score

        tokens: int | None | Unset
        if isinstance(self.tokens, Unset):
            tokens = UNSET
        else:
            tokens = self.tokens

        heading = self.heading

        bbox: list[float] | None | Unset
        if isinstance(self.bbox, Unset):
            bbox = UNSET
        elif isinstance(self.bbox, list):
            bbox = self.bbox


        else:
            bbox = self.bbox

        element_type: None | str | Unset
        if isinstance(self.element_type, Unset):
            element_type = UNSET
        else:
            element_type = self.element_type

        heading_level: int | None | Unset
        if isinstance(self.heading_level, Unset):
            heading_level = UNSET
        else:
            heading_level = self.heading_level


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "chunk_ext_id": chunk_ext_id,
            "chunk_pg_idx": chunk_pg_idx,
            "chunk_doc_idx": chunk_doc_idx,
            "page_number": page_number,
            "created_at": created_at,
        })
        if workspace_ext_id is not UNSET:
            field_dict["workspace_ext_id"] = workspace_ext_id
        if doc_ext_id is not UNSET:
            field_dict["doc_ext_id"] = doc_ext_id
        if doc_title is not UNSET:
            field_dict["doc_title"] = doc_title
        if chunk_id is not UNSET:
            field_dict["chunk_id"] = chunk_id
        if score is not UNSET:
            field_dict["score"] = score
        if rerank_score is not UNSET:
            field_dict["rerank_score"] = rerank_score
        if tokens is not UNSET:
            field_dict["tokens"] = tokens
        if heading is not UNSET:
            field_dict["heading"] = heading
        if bbox is not UNSET:
            field_dict["bbox"] = bbox
        if element_type is not UNSET:
            field_dict["element_type"] = element_type
        if heading_level is not UNSET:
            field_dict["heading_level"] = heading_level

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        chunk_ext_id = d.pop("chunk_ext_id")

        chunk_pg_idx = d.pop("chunk_pg_idx")

        chunk_doc_idx = d.pop("chunk_doc_idx")

        page_number = d.pop("page_number")

        created_at = d.pop("created_at")

        def _parse_workspace_ext_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        workspace_ext_id = _parse_workspace_ext_id(d.pop("workspace_ext_id", UNSET))


        def _parse_doc_ext_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        doc_ext_id = _parse_doc_ext_id(d.pop("doc_ext_id", UNSET))


        def _parse_doc_title(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        doc_title = _parse_doc_title(d.pop("doc_title", UNSET))


        def _parse_chunk_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        chunk_id = _parse_chunk_id(d.pop("chunk_id", UNSET))


        def _parse_score(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        score = _parse_score(d.pop("score", UNSET))


        def _parse_rerank_score(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        rerank_score = _parse_rerank_score(d.pop("rerank_score", UNSET))


        def _parse_tokens(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        tokens = _parse_tokens(d.pop("tokens", UNSET))


        heading = d.pop("heading", UNSET)

        def _parse_bbox(data: object) -> list[float] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                bbox_type_0 = cast(list[float], data)

                return bbox_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[float] | None | Unset, data)

        bbox = _parse_bbox(d.pop("bbox", UNSET))


        def _parse_element_type(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        element_type = _parse_element_type(d.pop("element_type", UNSET))


        def _parse_heading_level(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        heading_level = _parse_heading_level(d.pop("heading_level", UNSET))


        chunk_metadata = cls(
            chunk_ext_id=chunk_ext_id,
            chunk_pg_idx=chunk_pg_idx,
            chunk_doc_idx=chunk_doc_idx,
            page_number=page_number,
            created_at=created_at,
            workspace_ext_id=workspace_ext_id,
            doc_ext_id=doc_ext_id,
            doc_title=doc_title,
            chunk_id=chunk_id,
            score=score,
            rerank_score=rerank_score,
            tokens=tokens,
            heading=heading,
            bbox=bbox,
            element_type=element_type,
            heading_level=heading_level,
        )


        chunk_metadata.additional_properties = d
        return chunk_metadata

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
