from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.response_complete_message_status import ResponseCompleteMessageStatus
from ..types import UNSET, Unset
from typing import Literal, cast






T = TypeVar("T", bound="ResponseCompleteMessage")



@_attrs_define
class ResponseCompleteMessage:
    """ Background response finished — frontend can reload the conversation.

        Attributes:
            response_id (str):
            status (ResponseCompleteMessageStatus):
            type_ (Literal['response_complete'] | Unset):  Default: 'response_complete'.
     """

    response_id: str
    status: ResponseCompleteMessageStatus
    type_: Literal['response_complete'] | Unset = 'response_complete'
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        response_id = self.response_id

        status = self.status.value

        type_ = self.type_


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "response_id": response_id,
            "status": status,
        })
        if type_ is not UNSET:
            field_dict["type"] = type_

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        response_id = d.pop("response_id")

        status = ResponseCompleteMessageStatus(d.pop("status"))




        type_ = cast(Literal['response_complete'] | Unset , d.pop("type", UNSET))
        if type_ != 'response_complete'and not isinstance(type_, Unset):
            raise ValueError(f"type must match const 'response_complete', got '{type_}'")

        response_complete_message = cls(
            response_id=response_id,
            status=status,
            type_=type_,
        )


        response_complete_message.additional_properties = d
        return response_complete_message

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
