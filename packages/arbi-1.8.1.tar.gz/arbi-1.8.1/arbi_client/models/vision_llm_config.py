from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.vision_llm_config_api_type import VisionLLMConfigApiType
from ..types import UNSET, Unset






T = TypeVar("T", bound="VisionLLMConfig")



@_attrs_define
class VisionLLMConfig:
    """ Configuration for VisionLLM — visually inspects document pages.

    Used as a targeted fallback when text extraction (get_document_passages)
    is insufficient, e.g. for figures, charts, tables, scanned pages.
    The prompt is constructed dynamically per call (no system instruction).

        Attributes:
            api_type (VisionLLMConfigApiType | Unset): The inference type (local or remote). Default:
                VisionLLMConfigApiType.REMOTE.
            model_name (str | Unset): The vision-capable model name (must support image inputs). Default: 'dummy'.
            temperature (float | Unset): Temperature for vision analysis. Default: 0.1.
            max_tokens (int | Unset): Maximum tokens for the vision response. Default: 4000.
            max_pages_per_call (int | Unset): Maximum number of pages that can be inspected in a single call. Default: 5.
            image_max_dimension (int | Unset): Resize images so the longest side does not exceed this value (pixels).
                Default: 1280.
     """

    api_type: VisionLLMConfigApiType | Unset = VisionLLMConfigApiType.REMOTE
    model_name: str | Unset = 'dummy'
    temperature: float | Unset = 0.1
    max_tokens: int | Unset = 4000
    max_pages_per_call: int | Unset = 5
    image_max_dimension: int | Unset = 1280
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        api_type: str | Unset = UNSET
        if not isinstance(self.api_type, Unset):
            api_type = self.api_type.value


        model_name = self.model_name

        temperature = self.temperature

        max_tokens = self.max_tokens

        max_pages_per_call = self.max_pages_per_call

        image_max_dimension = self.image_max_dimension


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if api_type is not UNSET:
            field_dict["API_TYPE"] = api_type
        if model_name is not UNSET:
            field_dict["MODEL_NAME"] = model_name
        if temperature is not UNSET:
            field_dict["TEMPERATURE"] = temperature
        if max_tokens is not UNSET:
            field_dict["MAX_TOKENS"] = max_tokens
        if max_pages_per_call is not UNSET:
            field_dict["MAX_PAGES_PER_CALL"] = max_pages_per_call
        if image_max_dimension is not UNSET:
            field_dict["IMAGE_MAX_DIMENSION"] = image_max_dimension

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        _api_type = d.pop("API_TYPE", UNSET)
        api_type: VisionLLMConfigApiType | Unset
        if isinstance(_api_type,  Unset):
            api_type = UNSET
        else:
            api_type = VisionLLMConfigApiType(_api_type)




        model_name = d.pop("MODEL_NAME", UNSET)

        temperature = d.pop("TEMPERATURE", UNSET)

        max_tokens = d.pop("MAX_TOKENS", UNSET)

        max_pages_per_call = d.pop("MAX_PAGES_PER_CALL", UNSET)

        image_max_dimension = d.pop("IMAGE_MAX_DIMENSION", UNSET)

        vision_llm_config = cls(
            api_type=api_type,
            model_name=model_name,
            temperature=temperature,
            max_tokens=max_tokens,
            max_pages_per_call=max_pages_per_call,
            image_max_dimension=image_max_dimension,
        )


        vision_llm_config.additional_properties = d
        return vision_llm_config

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
