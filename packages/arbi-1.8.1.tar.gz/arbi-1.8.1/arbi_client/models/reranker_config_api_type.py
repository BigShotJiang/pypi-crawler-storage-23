from enum import Enum

class RerankerConfigApiType(str, Enum):
    LOCAL = "local"
    REMOTE = "remote"

    def __str__(self) -> str:
        return str(self.value)
