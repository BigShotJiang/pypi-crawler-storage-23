from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset






T = TypeVar("T", bound="RunCodeConfig")



@_attrs_define
class RunCodeConfig:
    """ Configuration for the run_code agent tool (Docker sandbox).

        Attributes:
            enabled (bool | Unset): Enable the run_code tool for sandboxed code execution. Default: False.
            image (str | Unset): Docker image for sandbox containers. Default: 'arbi-sandbox:bookworm-slim'.
            timeout_seconds (int | Unset): Maximum execution time per run_code call (seconds). Default: 60.
            memory_limit (str | Unset): Container memory limit (Docker format, e.g. '256m', '1g'). Default: '512m'.
            network (str | Unset): Container network mode. 'bridge' allows internet (pip/npm install). 'none' for full
                isolation. Default: 'bridge'.
     """

    enabled: bool | Unset = False
    image: str | Unset = 'arbi-sandbox:bookworm-slim'
    timeout_seconds: int | Unset = 60
    memory_limit: str | Unset = '512m'
    network: str | Unset = 'bridge'
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        enabled = self.enabled

        image = self.image

        timeout_seconds = self.timeout_seconds

        memory_limit = self.memory_limit

        network = self.network


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if enabled is not UNSET:
            field_dict["ENABLED"] = enabled
        if image is not UNSET:
            field_dict["IMAGE"] = image
        if timeout_seconds is not UNSET:
            field_dict["TIMEOUT_SECONDS"] = timeout_seconds
        if memory_limit is not UNSET:
            field_dict["MEMORY_LIMIT"] = memory_limit
        if network is not UNSET:
            field_dict["NETWORK"] = network

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        enabled = d.pop("ENABLED", UNSET)

        image = d.pop("IMAGE", UNSET)

        timeout_seconds = d.pop("TIMEOUT_SECONDS", UNSET)

        memory_limit = d.pop("MEMORY_LIMIT", UNSET)

        network = d.pop("NETWORK", UNSET)

        run_code_config = cls(
            enabled=enabled,
            image=image,
            timeout_seconds=timeout_seconds,
            memory_limit=memory_limit,
            network=network,
        )


        run_code_config.additional_properties = d
        return run_code_config

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
