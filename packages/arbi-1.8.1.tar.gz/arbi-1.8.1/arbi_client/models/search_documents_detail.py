from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import Literal, cast






T = TypeVar("T", bound="SearchDocumentsDetail")



@_attrs_define
class SearchDocumentsDetail:
    """ Detail for a search_documents tool call.

        Attributes:
            query (str): Search query (truncated to 80 chars)
            search_mode (str): Search mode: hybrid, semantic, keyword
            tool (Literal['search_documents'] | Unset):  Default: 'search_documents'.
     """

    query: str
    search_mode: str
    tool: Literal['search_documents'] | Unset = 'search_documents'
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        query = self.query

        search_mode = self.search_mode

        tool = self.tool


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "query": query,
            "search_mode": search_mode,
        })
        if tool is not UNSET:
            field_dict["tool"] = tool

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        query = d.pop("query")

        search_mode = d.pop("search_mode")

        tool = cast(Literal['search_documents'] | Unset , d.pop("tool", UNSET))
        if tool != 'search_documents'and not isinstance(tool, Unset):
            raise ValueError(f"tool must match const 'search_documents', got '{tool}'")

        search_documents_detail = cls(
            query=query,
            search_mode=search_mode,
            tool=tool,
        )


        search_documents_detail.additional_properties = d
        return search_documents_detail

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
