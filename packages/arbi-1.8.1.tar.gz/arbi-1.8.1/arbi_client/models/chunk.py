from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast

if TYPE_CHECKING:
  from ..models.chunk_metadata import ChunkMetadata





T = TypeVar("T", bound="Chunk")



@_attrs_define
class Chunk:
    """ 
        Attributes:
            metadata (ChunkMetadata):
            content (str):
     """

    metadata: ChunkMetadata
    content: str
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.chunk_metadata import ChunkMetadata
        metadata = self.metadata.to_dict()

        content = self.content


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "metadata": metadata,
            "content": content,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.chunk_metadata import ChunkMetadata
        d = dict(src_dict)
        metadata = ChunkMetadata.from_dict(d.pop("metadata"))




        content = d.pop("content")

        chunk = cls(
            metadata=metadata,
            content=content,
        )


        chunk.additional_properties = d
        return chunk

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
