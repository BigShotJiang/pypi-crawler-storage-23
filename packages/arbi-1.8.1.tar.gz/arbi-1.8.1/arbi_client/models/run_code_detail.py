from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import Literal, cast






T = TypeVar("T", bound="RunCodeDetail")



@_attrs_define
class RunCodeDetail:
    """ Detail for a run_code tool call.

        Attributes:
            task_length (int): Length of the task description
            tool (Literal['run_code'] | Unset):  Default: 'run_code'.
     """

    task_length: int
    tool: Literal['run_code'] | Unset = 'run_code'
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        task_length = self.task_length

        tool = self.tool


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "task_length": task_length,
        })
        if tool is not UNSET:
            field_dict["tool"] = tool

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        task_length = d.pop("task_length")

        tool = cast(Literal['run_code'] | Unset , d.pop("tool", UNSET))
        if tool != 'run_code'and not isinstance(tool, Unset):
            raise ValueError(f"tool must match const 'run_code', got '{tool}'")

        run_code_detail = cls(
            task_length=task_length,
            tool=tool,
        )


        run_code_detail.additional_properties = d
        return run_code_detail

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
