from enum import Enum

class AgentsConfigAgentApiType(str, Enum):
    LOCAL = "local"
    REMOTE = "remote"

    def __str__(self) -> str:
        return str(self.value)
