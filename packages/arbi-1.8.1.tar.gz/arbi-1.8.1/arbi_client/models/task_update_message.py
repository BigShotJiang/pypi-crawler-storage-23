from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.task_update_message_status import TaskUpdateMessageStatus
from ..types import UNSET, Unset
from typing import Literal, cast






T = TypeVar("T", bound="TaskUpdateMessage")



@_attrs_define
class TaskUpdateMessage:
    """ Document processing progress update.

        Attributes:
            doc_ext_id (str):
            workspace_ext_id (str):
            file_name (str):
            status (TaskUpdateMessageStatus):
            progress (int):
            type_ (Literal['task_update'] | Unset):  Default: 'task_update'.
     """

    doc_ext_id: str
    workspace_ext_id: str
    file_name: str
    status: TaskUpdateMessageStatus
    progress: int
    type_: Literal['task_update'] | Unset = 'task_update'
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        doc_ext_id = self.doc_ext_id

        workspace_ext_id = self.workspace_ext_id

        file_name = self.file_name

        status = self.status.value

        progress = self.progress

        type_ = self.type_


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "doc_ext_id": doc_ext_id,
            "workspace_ext_id": workspace_ext_id,
            "file_name": file_name,
            "status": status,
            "progress": progress,
        })
        if type_ is not UNSET:
            field_dict["type"] = type_

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        doc_ext_id = d.pop("doc_ext_id")

        workspace_ext_id = d.pop("workspace_ext_id")

        file_name = d.pop("file_name")

        status = TaskUpdateMessageStatus(d.pop("status"))




        progress = d.pop("progress")

        type_ = cast(Literal['task_update'] | Unset , d.pop("type", UNSET))
        if type_ != 'task_update'and not isinstance(type_, Unset):
            raise ValueError(f"type must match const 'task_update', got '{type_}'")

        task_update_message = cls(
            doc_ext_id=doc_ext_id,
            workspace_ext_id=workspace_ext_id,
            file_name=file_name,
            status=status,
            progress=progress,
            type_=type_,
        )


        task_update_message.additional_properties = d
        return task_update_message

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
