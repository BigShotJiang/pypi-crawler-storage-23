from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.message_metadata_payload_role import MessageMetadataPayloadRole
from ..types import UNSET, Unset
from dateutil.parser import isoparse
from typing import cast
from typing import Literal, cast
import datetime

if TYPE_CHECKING:
  from ..models.context_usage import ContextUsage
  from ..models.message_metadata_payload_tools import MessageMetadataPayloadTools





T = TypeVar("T", bound="MessageMetadataPayload")



@_attrs_define
class MessageMetadataPayload:
    """ ``message_metadata`` payload within ``response.completed.response.metadata``.

    Contains the full assistant :class:`MessageResponse` plus context_usage and
    optional suggested_query.

        Attributes:
            role (MessageMetadataPayloadRole):
            content (str):
            external_id (str):
            created_at (datetime.datetime):
            created_by_ext_id (str):
            conversation_ext_id (str):
            tools (MessageMetadataPayloadTools | Unset):
            config_ext_id (None | str | Unset):
            shared (bool | Unset):  Default: False.
            tokens (int | Unset):  Default: 0.
            parent_message_ext_id (None | str | Unset):
            type_ (Literal['message_metadata'] | Unset):  Default: 'message_metadata'.
            context_usage (ContextUsage | None | Unset):
            suggested_query (None | str | Unset):
     """

    role: MessageMetadataPayloadRole
    content: str
    external_id: str
    created_at: datetime.datetime
    created_by_ext_id: str
    conversation_ext_id: str
    tools: MessageMetadataPayloadTools | Unset = UNSET
    config_ext_id: None | str | Unset = UNSET
    shared: bool | Unset = False
    tokens: int | Unset = 0
    parent_message_ext_id: None | str | Unset = UNSET
    type_: Literal['message_metadata'] | Unset = 'message_metadata'
    context_usage: ContextUsage | None | Unset = UNSET
    suggested_query: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.context_usage import ContextUsage
        from ..models.message_metadata_payload_tools import MessageMetadataPayloadTools
        role = self.role.value

        content = self.content

        external_id = self.external_id

        created_at = self.created_at.isoformat()

        created_by_ext_id = self.created_by_ext_id

        conversation_ext_id = self.conversation_ext_id

        tools: dict[str, Any] | Unset = UNSET
        if not isinstance(self.tools, Unset):
            tools = self.tools.to_dict()

        config_ext_id: None | str | Unset
        if isinstance(self.config_ext_id, Unset):
            config_ext_id = UNSET
        else:
            config_ext_id = self.config_ext_id

        shared = self.shared

        tokens = self.tokens

        parent_message_ext_id: None | str | Unset
        if isinstance(self.parent_message_ext_id, Unset):
            parent_message_ext_id = UNSET
        else:
            parent_message_ext_id = self.parent_message_ext_id

        type_ = self.type_

        context_usage: dict[str, Any] | None | Unset
        if isinstance(self.context_usage, Unset):
            context_usage = UNSET
        elif isinstance(self.context_usage, ContextUsage):
            context_usage = self.context_usage.to_dict()
        else:
            context_usage = self.context_usage

        suggested_query: None | str | Unset
        if isinstance(self.suggested_query, Unset):
            suggested_query = UNSET
        else:
            suggested_query = self.suggested_query


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "role": role,
            "content": content,
            "external_id": external_id,
            "created_at": created_at,
            "created_by_ext_id": created_by_ext_id,
            "conversation_ext_id": conversation_ext_id,
        })
        if tools is not UNSET:
            field_dict["tools"] = tools
        if config_ext_id is not UNSET:
            field_dict["config_ext_id"] = config_ext_id
        if shared is not UNSET:
            field_dict["shared"] = shared
        if tokens is not UNSET:
            field_dict["tokens"] = tokens
        if parent_message_ext_id is not UNSET:
            field_dict["parent_message_ext_id"] = parent_message_ext_id
        if type_ is not UNSET:
            field_dict["type"] = type_
        if context_usage is not UNSET:
            field_dict["context_usage"] = context_usage
        if suggested_query is not UNSET:
            field_dict["suggested_query"] = suggested_query

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.context_usage import ContextUsage
        from ..models.message_metadata_payload_tools import MessageMetadataPayloadTools
        d = dict(src_dict)
        role = MessageMetadataPayloadRole(d.pop("role"))




        content = d.pop("content")

        external_id = d.pop("external_id")

        created_at = isoparse(d.pop("created_at"))




        created_by_ext_id = d.pop("created_by_ext_id")

        conversation_ext_id = d.pop("conversation_ext_id")

        _tools = d.pop("tools", UNSET)
        tools: MessageMetadataPayloadTools | Unset
        if isinstance(_tools,  Unset):
            tools = UNSET
        else:
            tools = MessageMetadataPayloadTools.from_dict(_tools)




        def _parse_config_ext_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        config_ext_id = _parse_config_ext_id(d.pop("config_ext_id", UNSET))


        shared = d.pop("shared", UNSET)

        tokens = d.pop("tokens", UNSET)

        def _parse_parent_message_ext_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        parent_message_ext_id = _parse_parent_message_ext_id(d.pop("parent_message_ext_id", UNSET))


        type_ = cast(Literal['message_metadata'] | Unset , d.pop("type", UNSET))
        if type_ != 'message_metadata'and not isinstance(type_, Unset):
            raise ValueError(f"type must match const 'message_metadata', got '{type_}'")

        def _parse_context_usage(data: object) -> ContextUsage | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                context_usage_type_0 = ContextUsage.from_dict(data)



                return context_usage_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(ContextUsage | None | Unset, data)

        context_usage = _parse_context_usage(d.pop("context_usage", UNSET))


        def _parse_suggested_query(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        suggested_query = _parse_suggested_query(d.pop("suggested_query", UNSET))


        message_metadata_payload = cls(
            role=role,
            content=content,
            external_id=external_id,
            created_at=created_at,
            created_by_ext_id=created_by_ext_id,
            conversation_ext_id=conversation_ext_id,
            tools=tools,
            config_ext_id=config_ext_id,
            shared=shared,
            tokens=tokens,
            parent_message_ext_id=parent_message_ext_id,
            type_=type_,
            context_usage=context_usage,
            suggested_query=suggested_query,
        )


        message_metadata_payload.additional_properties = d
        return message_metadata_payload

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
