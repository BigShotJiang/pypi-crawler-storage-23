from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.agent_step_event import AgentStepEvent
  from ..models.artifact_event import ArtifactEvent
  from ..models.ask_user_detail import AskUserDetail
  from ..models.context_usage import ContextUsage
  from ..models.create_artifact_detail import CreateArtifactDetail
  from ..models.create_plan_detail import CreatePlanDetail
  from ..models.evaluation_detail import EvaluationDetail
  from ..models.get_document_passages_detail import GetDocumentPassagesDetail
  from ..models.get_full_document_detail import GetFullDocumentDetail
  from ..models.get_table_of_contents_detail import GetTableOfContentsDetail
  from ..models.message_metadata_payload import MessageMetadataPayload
  from ..models.output_tokens_details import OutputTokensDetails
  from ..models.personal_agent_detail import PersonalAgentDetail
  from ..models.read_url_detail import ReadUrlDetail
  from ..models.response_completed_event import ResponseCompletedEvent
  from ..models.response_content_part_added_event import ResponseContentPartAddedEvent
  from ..models.response_created_event import ResponseCreatedEvent
  from ..models.response_failed_event import ResponseFailedEvent
  from ..models.response_output_item_added_event import ResponseOutputItemAddedEvent
  from ..models.response_output_item_done_event import ResponseOutputItemDoneEvent
  from ..models.response_output_text_delta_event import ResponseOutputTextDeltaEvent
  from ..models.response_output_text_done_event import ResponseOutputTextDoneEvent
  from ..models.response_usage import ResponseUsage
  from ..models.run_code_detail import RunCodeDetail
  from ..models.save_skill_detail import SaveSkillDetail
  from ..models.search_documents_detail import SearchDocumentsDetail
  from ..models.token_budget_context import TokenBudgetContext
  from ..models.tool_progress_detail import ToolProgressDetail
  from ..models.user_input_request_event import UserInputRequestEvent
  from ..models.user_message_event import UserMessageEvent
  from ..models.view_document_pages_detail import ViewDocumentPagesDetail
  from ..models.web_search_detail import WebSearchDetail





T = TypeVar("T", bound="SSESchemas")



@_attrs_define
class SSESchemas:
    """ Container for all SSE event schemas — drives OpenAPI component generation.

    Each field exposes an event type to the OpenAPI spec so the TS frontend
    can autogenerate types.  The endpoint returns defaults (None) — only the
    schema components matter.

    Sub-model fields (token_budget_context, response_usage, context_usage) are
    included so their schemas appear as OpenAPI components even though they are
    only used as nested types within the event models.

        Attributes:
            response_created (None | ResponseCreatedEvent | Unset):
            response_output_item_added (None | ResponseOutputItemAddedEvent | Unset):
            response_content_part_added (None | ResponseContentPartAddedEvent | Unset):
            agent_step (AgentStepEvent | None | Unset):
            user_input_request (None | Unset | UserInputRequestEvent):
            user_message (None | Unset | UserMessageEvent):
            response_output_text_delta (None | ResponseOutputTextDeltaEvent | Unset):
            response_output_text_done (None | ResponseOutputTextDoneEvent | Unset):
            response_output_item_done (None | ResponseOutputItemDoneEvent | Unset):
            response_completed (None | ResponseCompletedEvent | Unset):
            response_failed (None | ResponseFailedEvent | Unset):
            artifact (ArtifactEvent | None | Unset):
            token_budget_context (None | TokenBudgetContext | Unset):
            response_usage (None | ResponseUsage | Unset):
            output_tokens_details (None | OutputTokensDetails | Unset):
            context_usage (ContextUsage | None | Unset):
            message_metadata (MessageMetadataPayload | None | Unset):
            detail_search_documents (None | SearchDocumentsDetail | Unset):
            detail_get_document_passages (GetDocumentPassagesDetail | None | Unset):
            detail_get_table_of_contents (GetTableOfContentsDetail | None | Unset):
            detail_view_document_pages (None | Unset | ViewDocumentPagesDetail):
            detail_get_full_document (GetFullDocumentDetail | None | Unset):
            detail_web_search (None | Unset | WebSearchDetail):
            detail_personal_agent (None | PersonalAgentDetail | Unset):
            detail_read_url (None | ReadUrlDetail | Unset):
            detail_create_plan (CreatePlanDetail | None | Unset):
            detail_save_skill (None | SaveSkillDetail | Unset):
            detail_run_code (None | RunCodeDetail | Unset):
            detail_create_artifact (CreateArtifactDetail | None | Unset):
            detail_ask_user (AskUserDetail | None | Unset):
            detail_evaluation (EvaluationDetail | None | Unset):
            detail_tool_progress (None | ToolProgressDetail | Unset):
     """

    response_created: None | ResponseCreatedEvent | Unset = UNSET
    response_output_item_added: None | ResponseOutputItemAddedEvent | Unset = UNSET
    response_content_part_added: None | ResponseContentPartAddedEvent | Unset = UNSET
    agent_step: AgentStepEvent | None | Unset = UNSET
    user_input_request: None | Unset | UserInputRequestEvent = UNSET
    user_message: None | Unset | UserMessageEvent = UNSET
    response_output_text_delta: None | ResponseOutputTextDeltaEvent | Unset = UNSET
    response_output_text_done: None | ResponseOutputTextDoneEvent | Unset = UNSET
    response_output_item_done: None | ResponseOutputItemDoneEvent | Unset = UNSET
    response_completed: None | ResponseCompletedEvent | Unset = UNSET
    response_failed: None | ResponseFailedEvent | Unset = UNSET
    artifact: ArtifactEvent | None | Unset = UNSET
    token_budget_context: None | TokenBudgetContext | Unset = UNSET
    response_usage: None | ResponseUsage | Unset = UNSET
    output_tokens_details: None | OutputTokensDetails | Unset = UNSET
    context_usage: ContextUsage | None | Unset = UNSET
    message_metadata: MessageMetadataPayload | None | Unset = UNSET
    detail_search_documents: None | SearchDocumentsDetail | Unset = UNSET
    detail_get_document_passages: GetDocumentPassagesDetail | None | Unset = UNSET
    detail_get_table_of_contents: GetTableOfContentsDetail | None | Unset = UNSET
    detail_view_document_pages: None | Unset | ViewDocumentPagesDetail = UNSET
    detail_get_full_document: GetFullDocumentDetail | None | Unset = UNSET
    detail_web_search: None | Unset | WebSearchDetail = UNSET
    detail_personal_agent: None | PersonalAgentDetail | Unset = UNSET
    detail_read_url: None | ReadUrlDetail | Unset = UNSET
    detail_create_plan: CreatePlanDetail | None | Unset = UNSET
    detail_save_skill: None | SaveSkillDetail | Unset = UNSET
    detail_run_code: None | RunCodeDetail | Unset = UNSET
    detail_create_artifact: CreateArtifactDetail | None | Unset = UNSET
    detail_ask_user: AskUserDetail | None | Unset = UNSET
    detail_evaluation: EvaluationDetail | None | Unset = UNSET
    detail_tool_progress: None | ToolProgressDetail | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.output_tokens_details import OutputTokensDetails
        from ..models.response_failed_event import ResponseFailedEvent
        from ..models.message_metadata_payload import MessageMetadataPayload
        from ..models.view_document_pages_detail import ViewDocumentPagesDetail
        from ..models.evaluation_detail import EvaluationDetail
        from ..models.user_message_event import UserMessageEvent
        from ..models.get_full_document_detail import GetFullDocumentDetail
        from ..models.personal_agent_detail import PersonalAgentDetail
        from ..models.token_budget_context import TokenBudgetContext
        from ..models.response_usage import ResponseUsage
        from ..models.web_search_detail import WebSearchDetail
        from ..models.artifact_event import ArtifactEvent
        from ..models.response_content_part_added_event import ResponseContentPartAddedEvent
        from ..models.create_plan_detail import CreatePlanDetail
        from ..models.response_output_item_added_event import ResponseOutputItemAddedEvent
        from ..models.search_documents_detail import SearchDocumentsDetail
        from ..models.tool_progress_detail import ToolProgressDetail
        from ..models.response_output_text_delta_event import ResponseOutputTextDeltaEvent
        from ..models.response_completed_event import ResponseCompletedEvent
        from ..models.ask_user_detail import AskUserDetail
        from ..models.read_url_detail import ReadUrlDetail
        from ..models.create_artifact_detail import CreateArtifactDetail
        from ..models.agent_step_event import AgentStepEvent
        from ..models.save_skill_detail import SaveSkillDetail
        from ..models.user_input_request_event import UserInputRequestEvent
        from ..models.context_usage import ContextUsage
        from ..models.run_code_detail import RunCodeDetail
        from ..models.response_output_text_done_event import ResponseOutputTextDoneEvent
        from ..models.get_table_of_contents_detail import GetTableOfContentsDetail
        from ..models.get_document_passages_detail import GetDocumentPassagesDetail
        from ..models.response_created_event import ResponseCreatedEvent
        from ..models.response_output_item_done_event import ResponseOutputItemDoneEvent
        response_created: dict[str, Any] | None | Unset
        if isinstance(self.response_created, Unset):
            response_created = UNSET
        elif isinstance(self.response_created, ResponseCreatedEvent):
            response_created = self.response_created.to_dict()
        else:
            response_created = self.response_created

        response_output_item_added: dict[str, Any] | None | Unset
        if isinstance(self.response_output_item_added, Unset):
            response_output_item_added = UNSET
        elif isinstance(self.response_output_item_added, ResponseOutputItemAddedEvent):
            response_output_item_added = self.response_output_item_added.to_dict()
        else:
            response_output_item_added = self.response_output_item_added

        response_content_part_added: dict[str, Any] | None | Unset
        if isinstance(self.response_content_part_added, Unset):
            response_content_part_added = UNSET
        elif isinstance(self.response_content_part_added, ResponseContentPartAddedEvent):
            response_content_part_added = self.response_content_part_added.to_dict()
        else:
            response_content_part_added = self.response_content_part_added

        agent_step: dict[str, Any] | None | Unset
        if isinstance(self.agent_step, Unset):
            agent_step = UNSET
        elif isinstance(self.agent_step, AgentStepEvent):
            agent_step = self.agent_step.to_dict()
        else:
            agent_step = self.agent_step

        user_input_request: dict[str, Any] | None | Unset
        if isinstance(self.user_input_request, Unset):
            user_input_request = UNSET
        elif isinstance(self.user_input_request, UserInputRequestEvent):
            user_input_request = self.user_input_request.to_dict()
        else:
            user_input_request = self.user_input_request

        user_message: dict[str, Any] | None | Unset
        if isinstance(self.user_message, Unset):
            user_message = UNSET
        elif isinstance(self.user_message, UserMessageEvent):
            user_message = self.user_message.to_dict()
        else:
            user_message = self.user_message

        response_output_text_delta: dict[str, Any] | None | Unset
        if isinstance(self.response_output_text_delta, Unset):
            response_output_text_delta = UNSET
        elif isinstance(self.response_output_text_delta, ResponseOutputTextDeltaEvent):
            response_output_text_delta = self.response_output_text_delta.to_dict()
        else:
            response_output_text_delta = self.response_output_text_delta

        response_output_text_done: dict[str, Any] | None | Unset
        if isinstance(self.response_output_text_done, Unset):
            response_output_text_done = UNSET
        elif isinstance(self.response_output_text_done, ResponseOutputTextDoneEvent):
            response_output_text_done = self.response_output_text_done.to_dict()
        else:
            response_output_text_done = self.response_output_text_done

        response_output_item_done: dict[str, Any] | None | Unset
        if isinstance(self.response_output_item_done, Unset):
            response_output_item_done = UNSET
        elif isinstance(self.response_output_item_done, ResponseOutputItemDoneEvent):
            response_output_item_done = self.response_output_item_done.to_dict()
        else:
            response_output_item_done = self.response_output_item_done

        response_completed: dict[str, Any] | None | Unset
        if isinstance(self.response_completed, Unset):
            response_completed = UNSET
        elif isinstance(self.response_completed, ResponseCompletedEvent):
            response_completed = self.response_completed.to_dict()
        else:
            response_completed = self.response_completed

        response_failed: dict[str, Any] | None | Unset
        if isinstance(self.response_failed, Unset):
            response_failed = UNSET
        elif isinstance(self.response_failed, ResponseFailedEvent):
            response_failed = self.response_failed.to_dict()
        else:
            response_failed = self.response_failed

        artifact: dict[str, Any] | None | Unset
        if isinstance(self.artifact, Unset):
            artifact = UNSET
        elif isinstance(self.artifact, ArtifactEvent):
            artifact = self.artifact.to_dict()
        else:
            artifact = self.artifact

        token_budget_context: dict[str, Any] | None | Unset
        if isinstance(self.token_budget_context, Unset):
            token_budget_context = UNSET
        elif isinstance(self.token_budget_context, TokenBudgetContext):
            token_budget_context = self.token_budget_context.to_dict()
        else:
            token_budget_context = self.token_budget_context

        response_usage: dict[str, Any] | None | Unset
        if isinstance(self.response_usage, Unset):
            response_usage = UNSET
        elif isinstance(self.response_usage, ResponseUsage):
            response_usage = self.response_usage.to_dict()
        else:
            response_usage = self.response_usage

        output_tokens_details: dict[str, Any] | None | Unset
        if isinstance(self.output_tokens_details, Unset):
            output_tokens_details = UNSET
        elif isinstance(self.output_tokens_details, OutputTokensDetails):
            output_tokens_details = self.output_tokens_details.to_dict()
        else:
            output_tokens_details = self.output_tokens_details

        context_usage: dict[str, Any] | None | Unset
        if isinstance(self.context_usage, Unset):
            context_usage = UNSET
        elif isinstance(self.context_usage, ContextUsage):
            context_usage = self.context_usage.to_dict()
        else:
            context_usage = self.context_usage

        message_metadata: dict[str, Any] | None | Unset
        if isinstance(self.message_metadata, Unset):
            message_metadata = UNSET
        elif isinstance(self.message_metadata, MessageMetadataPayload):
            message_metadata = self.message_metadata.to_dict()
        else:
            message_metadata = self.message_metadata

        detail_search_documents: dict[str, Any] | None | Unset
        if isinstance(self.detail_search_documents, Unset):
            detail_search_documents = UNSET
        elif isinstance(self.detail_search_documents, SearchDocumentsDetail):
            detail_search_documents = self.detail_search_documents.to_dict()
        else:
            detail_search_documents = self.detail_search_documents

        detail_get_document_passages: dict[str, Any] | None | Unset
        if isinstance(self.detail_get_document_passages, Unset):
            detail_get_document_passages = UNSET
        elif isinstance(self.detail_get_document_passages, GetDocumentPassagesDetail):
            detail_get_document_passages = self.detail_get_document_passages.to_dict()
        else:
            detail_get_document_passages = self.detail_get_document_passages

        detail_get_table_of_contents: dict[str, Any] | None | Unset
        if isinstance(self.detail_get_table_of_contents, Unset):
            detail_get_table_of_contents = UNSET
        elif isinstance(self.detail_get_table_of_contents, GetTableOfContentsDetail):
            detail_get_table_of_contents = self.detail_get_table_of_contents.to_dict()
        else:
            detail_get_table_of_contents = self.detail_get_table_of_contents

        detail_view_document_pages: dict[str, Any] | None | Unset
        if isinstance(self.detail_view_document_pages, Unset):
            detail_view_document_pages = UNSET
        elif isinstance(self.detail_view_document_pages, ViewDocumentPagesDetail):
            detail_view_document_pages = self.detail_view_document_pages.to_dict()
        else:
            detail_view_document_pages = self.detail_view_document_pages

        detail_get_full_document: dict[str, Any] | None | Unset
        if isinstance(self.detail_get_full_document, Unset):
            detail_get_full_document = UNSET
        elif isinstance(self.detail_get_full_document, GetFullDocumentDetail):
            detail_get_full_document = self.detail_get_full_document.to_dict()
        else:
            detail_get_full_document = self.detail_get_full_document

        detail_web_search: dict[str, Any] | None | Unset
        if isinstance(self.detail_web_search, Unset):
            detail_web_search = UNSET
        elif isinstance(self.detail_web_search, WebSearchDetail):
            detail_web_search = self.detail_web_search.to_dict()
        else:
            detail_web_search = self.detail_web_search

        detail_personal_agent: dict[str, Any] | None | Unset
        if isinstance(self.detail_personal_agent, Unset):
            detail_personal_agent = UNSET
        elif isinstance(self.detail_personal_agent, PersonalAgentDetail):
            detail_personal_agent = self.detail_personal_agent.to_dict()
        else:
            detail_personal_agent = self.detail_personal_agent

        detail_read_url: dict[str, Any] | None | Unset
        if isinstance(self.detail_read_url, Unset):
            detail_read_url = UNSET
        elif isinstance(self.detail_read_url, ReadUrlDetail):
            detail_read_url = self.detail_read_url.to_dict()
        else:
            detail_read_url = self.detail_read_url

        detail_create_plan: dict[str, Any] | None | Unset
        if isinstance(self.detail_create_plan, Unset):
            detail_create_plan = UNSET
        elif isinstance(self.detail_create_plan, CreatePlanDetail):
            detail_create_plan = self.detail_create_plan.to_dict()
        else:
            detail_create_plan = self.detail_create_plan

        detail_save_skill: dict[str, Any] | None | Unset
        if isinstance(self.detail_save_skill, Unset):
            detail_save_skill = UNSET
        elif isinstance(self.detail_save_skill, SaveSkillDetail):
            detail_save_skill = self.detail_save_skill.to_dict()
        else:
            detail_save_skill = self.detail_save_skill

        detail_run_code: dict[str, Any] | None | Unset
        if isinstance(self.detail_run_code, Unset):
            detail_run_code = UNSET
        elif isinstance(self.detail_run_code, RunCodeDetail):
            detail_run_code = self.detail_run_code.to_dict()
        else:
            detail_run_code = self.detail_run_code

        detail_create_artifact: dict[str, Any] | None | Unset
        if isinstance(self.detail_create_artifact, Unset):
            detail_create_artifact = UNSET
        elif isinstance(self.detail_create_artifact, CreateArtifactDetail):
            detail_create_artifact = self.detail_create_artifact.to_dict()
        else:
            detail_create_artifact = self.detail_create_artifact

        detail_ask_user: dict[str, Any] | None | Unset
        if isinstance(self.detail_ask_user, Unset):
            detail_ask_user = UNSET
        elif isinstance(self.detail_ask_user, AskUserDetail):
            detail_ask_user = self.detail_ask_user.to_dict()
        else:
            detail_ask_user = self.detail_ask_user

        detail_evaluation: dict[str, Any] | None | Unset
        if isinstance(self.detail_evaluation, Unset):
            detail_evaluation = UNSET
        elif isinstance(self.detail_evaluation, EvaluationDetail):
            detail_evaluation = self.detail_evaluation.to_dict()
        else:
            detail_evaluation = self.detail_evaluation

        detail_tool_progress: dict[str, Any] | None | Unset
        if isinstance(self.detail_tool_progress, Unset):
            detail_tool_progress = UNSET
        elif isinstance(self.detail_tool_progress, ToolProgressDetail):
            detail_tool_progress = self.detail_tool_progress.to_dict()
        else:
            detail_tool_progress = self.detail_tool_progress


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if response_created is not UNSET:
            field_dict["response_created"] = response_created
        if response_output_item_added is not UNSET:
            field_dict["response_output_item_added"] = response_output_item_added
        if response_content_part_added is not UNSET:
            field_dict["response_content_part_added"] = response_content_part_added
        if agent_step is not UNSET:
            field_dict["agent_step"] = agent_step
        if user_input_request is not UNSET:
            field_dict["user_input_request"] = user_input_request
        if user_message is not UNSET:
            field_dict["user_message"] = user_message
        if response_output_text_delta is not UNSET:
            field_dict["response_output_text_delta"] = response_output_text_delta
        if response_output_text_done is not UNSET:
            field_dict["response_output_text_done"] = response_output_text_done
        if response_output_item_done is not UNSET:
            field_dict["response_output_item_done"] = response_output_item_done
        if response_completed is not UNSET:
            field_dict["response_completed"] = response_completed
        if response_failed is not UNSET:
            field_dict["response_failed"] = response_failed
        if artifact is not UNSET:
            field_dict["artifact"] = artifact
        if token_budget_context is not UNSET:
            field_dict["token_budget_context"] = token_budget_context
        if response_usage is not UNSET:
            field_dict["response_usage"] = response_usage
        if output_tokens_details is not UNSET:
            field_dict["output_tokens_details"] = output_tokens_details
        if context_usage is not UNSET:
            field_dict["context_usage"] = context_usage
        if message_metadata is not UNSET:
            field_dict["message_metadata"] = message_metadata
        if detail_search_documents is not UNSET:
            field_dict["detail_search_documents"] = detail_search_documents
        if detail_get_document_passages is not UNSET:
            field_dict["detail_get_document_passages"] = detail_get_document_passages
        if detail_get_table_of_contents is not UNSET:
            field_dict["detail_get_table_of_contents"] = detail_get_table_of_contents
        if detail_view_document_pages is not UNSET:
            field_dict["detail_view_document_pages"] = detail_view_document_pages
        if detail_get_full_document is not UNSET:
            field_dict["detail_get_full_document"] = detail_get_full_document
        if detail_web_search is not UNSET:
            field_dict["detail_web_search"] = detail_web_search
        if detail_personal_agent is not UNSET:
            field_dict["detail_personal_agent"] = detail_personal_agent
        if detail_read_url is not UNSET:
            field_dict["detail_read_url"] = detail_read_url
        if detail_create_plan is not UNSET:
            field_dict["detail_create_plan"] = detail_create_plan
        if detail_save_skill is not UNSET:
            field_dict["detail_save_skill"] = detail_save_skill
        if detail_run_code is not UNSET:
            field_dict["detail_run_code"] = detail_run_code
        if detail_create_artifact is not UNSET:
            field_dict["detail_create_artifact"] = detail_create_artifact
        if detail_ask_user is not UNSET:
            field_dict["detail_ask_user"] = detail_ask_user
        if detail_evaluation is not UNSET:
            field_dict["detail_evaluation"] = detail_evaluation
        if detail_tool_progress is not UNSET:
            field_dict["detail_tool_progress"] = detail_tool_progress

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.agent_step_event import AgentStepEvent
        from ..models.artifact_event import ArtifactEvent
        from ..models.ask_user_detail import AskUserDetail
        from ..models.context_usage import ContextUsage
        from ..models.create_artifact_detail import CreateArtifactDetail
        from ..models.create_plan_detail import CreatePlanDetail
        from ..models.evaluation_detail import EvaluationDetail
        from ..models.get_document_passages_detail import GetDocumentPassagesDetail
        from ..models.get_full_document_detail import GetFullDocumentDetail
        from ..models.get_table_of_contents_detail import GetTableOfContentsDetail
        from ..models.message_metadata_payload import MessageMetadataPayload
        from ..models.output_tokens_details import OutputTokensDetails
        from ..models.personal_agent_detail import PersonalAgentDetail
        from ..models.read_url_detail import ReadUrlDetail
        from ..models.response_completed_event import ResponseCompletedEvent
        from ..models.response_content_part_added_event import ResponseContentPartAddedEvent
        from ..models.response_created_event import ResponseCreatedEvent
        from ..models.response_failed_event import ResponseFailedEvent
        from ..models.response_output_item_added_event import ResponseOutputItemAddedEvent
        from ..models.response_output_item_done_event import ResponseOutputItemDoneEvent
        from ..models.response_output_text_delta_event import ResponseOutputTextDeltaEvent
        from ..models.response_output_text_done_event import ResponseOutputTextDoneEvent
        from ..models.response_usage import ResponseUsage
        from ..models.run_code_detail import RunCodeDetail
        from ..models.save_skill_detail import SaveSkillDetail
        from ..models.search_documents_detail import SearchDocumentsDetail
        from ..models.token_budget_context import TokenBudgetContext
        from ..models.tool_progress_detail import ToolProgressDetail
        from ..models.user_input_request_event import UserInputRequestEvent
        from ..models.user_message_event import UserMessageEvent
        from ..models.view_document_pages_detail import ViewDocumentPagesDetail
        from ..models.web_search_detail import WebSearchDetail
        d = dict(src_dict)
        def _parse_response_created(data: object) -> None | ResponseCreatedEvent | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                response_created_type_0 = ResponseCreatedEvent.from_dict(data)



                return response_created_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | ResponseCreatedEvent | Unset, data)

        response_created = _parse_response_created(d.pop("response_created", UNSET))


        def _parse_response_output_item_added(data: object) -> None | ResponseOutputItemAddedEvent | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                response_output_item_added_type_0 = ResponseOutputItemAddedEvent.from_dict(data)



                return response_output_item_added_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | ResponseOutputItemAddedEvent | Unset, data)

        response_output_item_added = _parse_response_output_item_added(d.pop("response_output_item_added", UNSET))


        def _parse_response_content_part_added(data: object) -> None | ResponseContentPartAddedEvent | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                response_content_part_added_type_0 = ResponseContentPartAddedEvent.from_dict(data)



                return response_content_part_added_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | ResponseContentPartAddedEvent | Unset, data)

        response_content_part_added = _parse_response_content_part_added(d.pop("response_content_part_added", UNSET))


        def _parse_agent_step(data: object) -> AgentStepEvent | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                agent_step_type_0 = AgentStepEvent.from_dict(data)



                return agent_step_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(AgentStepEvent | None | Unset, data)

        agent_step = _parse_agent_step(d.pop("agent_step", UNSET))


        def _parse_user_input_request(data: object) -> None | Unset | UserInputRequestEvent:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                user_input_request_type_0 = UserInputRequestEvent.from_dict(data)



                return user_input_request_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Unset | UserInputRequestEvent, data)

        user_input_request = _parse_user_input_request(d.pop("user_input_request", UNSET))


        def _parse_user_message(data: object) -> None | Unset | UserMessageEvent:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                user_message_type_0 = UserMessageEvent.from_dict(data)



                return user_message_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Unset | UserMessageEvent, data)

        user_message = _parse_user_message(d.pop("user_message", UNSET))


        def _parse_response_output_text_delta(data: object) -> None | ResponseOutputTextDeltaEvent | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                response_output_text_delta_type_0 = ResponseOutputTextDeltaEvent.from_dict(data)



                return response_output_text_delta_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | ResponseOutputTextDeltaEvent | Unset, data)

        response_output_text_delta = _parse_response_output_text_delta(d.pop("response_output_text_delta", UNSET))


        def _parse_response_output_text_done(data: object) -> None | ResponseOutputTextDoneEvent | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                response_output_text_done_type_0 = ResponseOutputTextDoneEvent.from_dict(data)



                return response_output_text_done_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | ResponseOutputTextDoneEvent | Unset, data)

        response_output_text_done = _parse_response_output_text_done(d.pop("response_output_text_done", UNSET))


        def _parse_response_output_item_done(data: object) -> None | ResponseOutputItemDoneEvent | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                response_output_item_done_type_0 = ResponseOutputItemDoneEvent.from_dict(data)



                return response_output_item_done_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | ResponseOutputItemDoneEvent | Unset, data)

        response_output_item_done = _parse_response_output_item_done(d.pop("response_output_item_done", UNSET))


        def _parse_response_completed(data: object) -> None | ResponseCompletedEvent | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                response_completed_type_0 = ResponseCompletedEvent.from_dict(data)



                return response_completed_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | ResponseCompletedEvent | Unset, data)

        response_completed = _parse_response_completed(d.pop("response_completed", UNSET))


        def _parse_response_failed(data: object) -> None | ResponseFailedEvent | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                response_failed_type_0 = ResponseFailedEvent.from_dict(data)



                return response_failed_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | ResponseFailedEvent | Unset, data)

        response_failed = _parse_response_failed(d.pop("response_failed", UNSET))


        def _parse_artifact(data: object) -> ArtifactEvent | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                artifact_type_0 = ArtifactEvent.from_dict(data)



                return artifact_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(ArtifactEvent | None | Unset, data)

        artifact = _parse_artifact(d.pop("artifact", UNSET))


        def _parse_token_budget_context(data: object) -> None | TokenBudgetContext | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                token_budget_context_type_0 = TokenBudgetContext.from_dict(data)



                return token_budget_context_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | TokenBudgetContext | Unset, data)

        token_budget_context = _parse_token_budget_context(d.pop("token_budget_context", UNSET))


        def _parse_response_usage(data: object) -> None | ResponseUsage | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                response_usage_type_0 = ResponseUsage.from_dict(data)



                return response_usage_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | ResponseUsage | Unset, data)

        response_usage = _parse_response_usage(d.pop("response_usage", UNSET))


        def _parse_output_tokens_details(data: object) -> None | OutputTokensDetails | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                output_tokens_details_type_0 = OutputTokensDetails.from_dict(data)



                return output_tokens_details_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | OutputTokensDetails | Unset, data)

        output_tokens_details = _parse_output_tokens_details(d.pop("output_tokens_details", UNSET))


        def _parse_context_usage(data: object) -> ContextUsage | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                context_usage_type_0 = ContextUsage.from_dict(data)



                return context_usage_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(ContextUsage | None | Unset, data)

        context_usage = _parse_context_usage(d.pop("context_usage", UNSET))


        def _parse_message_metadata(data: object) -> MessageMetadataPayload | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                message_metadata_type_0 = MessageMetadataPayload.from_dict(data)



                return message_metadata_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(MessageMetadataPayload | None | Unset, data)

        message_metadata = _parse_message_metadata(d.pop("message_metadata", UNSET))


        def _parse_detail_search_documents(data: object) -> None | SearchDocumentsDetail | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                detail_search_documents_type_0 = SearchDocumentsDetail.from_dict(data)



                return detail_search_documents_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | SearchDocumentsDetail | Unset, data)

        detail_search_documents = _parse_detail_search_documents(d.pop("detail_search_documents", UNSET))


        def _parse_detail_get_document_passages(data: object) -> GetDocumentPassagesDetail | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                detail_get_document_passages_type_0 = GetDocumentPassagesDetail.from_dict(data)



                return detail_get_document_passages_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(GetDocumentPassagesDetail | None | Unset, data)

        detail_get_document_passages = _parse_detail_get_document_passages(d.pop("detail_get_document_passages", UNSET))


        def _parse_detail_get_table_of_contents(data: object) -> GetTableOfContentsDetail | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                detail_get_table_of_contents_type_0 = GetTableOfContentsDetail.from_dict(data)



                return detail_get_table_of_contents_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(GetTableOfContentsDetail | None | Unset, data)

        detail_get_table_of_contents = _parse_detail_get_table_of_contents(d.pop("detail_get_table_of_contents", UNSET))


        def _parse_detail_view_document_pages(data: object) -> None | Unset | ViewDocumentPagesDetail:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                detail_view_document_pages_type_0 = ViewDocumentPagesDetail.from_dict(data)



                return detail_view_document_pages_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Unset | ViewDocumentPagesDetail, data)

        detail_view_document_pages = _parse_detail_view_document_pages(d.pop("detail_view_document_pages", UNSET))


        def _parse_detail_get_full_document(data: object) -> GetFullDocumentDetail | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                detail_get_full_document_type_0 = GetFullDocumentDetail.from_dict(data)



                return detail_get_full_document_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(GetFullDocumentDetail | None | Unset, data)

        detail_get_full_document = _parse_detail_get_full_document(d.pop("detail_get_full_document", UNSET))


        def _parse_detail_web_search(data: object) -> None | Unset | WebSearchDetail:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                detail_web_search_type_0 = WebSearchDetail.from_dict(data)



                return detail_web_search_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Unset | WebSearchDetail, data)

        detail_web_search = _parse_detail_web_search(d.pop("detail_web_search", UNSET))


        def _parse_detail_personal_agent(data: object) -> None | PersonalAgentDetail | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                detail_personal_agent_type_0 = PersonalAgentDetail.from_dict(data)



                return detail_personal_agent_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | PersonalAgentDetail | Unset, data)

        detail_personal_agent = _parse_detail_personal_agent(d.pop("detail_personal_agent", UNSET))


        def _parse_detail_read_url(data: object) -> None | ReadUrlDetail | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                detail_read_url_type_0 = ReadUrlDetail.from_dict(data)



                return detail_read_url_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | ReadUrlDetail | Unset, data)

        detail_read_url = _parse_detail_read_url(d.pop("detail_read_url", UNSET))


        def _parse_detail_create_plan(data: object) -> CreatePlanDetail | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                detail_create_plan_type_0 = CreatePlanDetail.from_dict(data)



                return detail_create_plan_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(CreatePlanDetail | None | Unset, data)

        detail_create_plan = _parse_detail_create_plan(d.pop("detail_create_plan", UNSET))


        def _parse_detail_save_skill(data: object) -> None | SaveSkillDetail | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                detail_save_skill_type_0 = SaveSkillDetail.from_dict(data)



                return detail_save_skill_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | SaveSkillDetail | Unset, data)

        detail_save_skill = _parse_detail_save_skill(d.pop("detail_save_skill", UNSET))


        def _parse_detail_run_code(data: object) -> None | RunCodeDetail | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                detail_run_code_type_0 = RunCodeDetail.from_dict(data)



                return detail_run_code_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | RunCodeDetail | Unset, data)

        detail_run_code = _parse_detail_run_code(d.pop("detail_run_code", UNSET))


        def _parse_detail_create_artifact(data: object) -> CreateArtifactDetail | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                detail_create_artifact_type_0 = CreateArtifactDetail.from_dict(data)



                return detail_create_artifact_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(CreateArtifactDetail | None | Unset, data)

        detail_create_artifact = _parse_detail_create_artifact(d.pop("detail_create_artifact", UNSET))


        def _parse_detail_ask_user(data: object) -> AskUserDetail | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                detail_ask_user_type_0 = AskUserDetail.from_dict(data)



                return detail_ask_user_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(AskUserDetail | None | Unset, data)

        detail_ask_user = _parse_detail_ask_user(d.pop("detail_ask_user", UNSET))


        def _parse_detail_evaluation(data: object) -> EvaluationDetail | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                detail_evaluation_type_0 = EvaluationDetail.from_dict(data)



                return detail_evaluation_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(EvaluationDetail | None | Unset, data)

        detail_evaluation = _parse_detail_evaluation(d.pop("detail_evaluation", UNSET))


        def _parse_detail_tool_progress(data: object) -> None | ToolProgressDetail | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                detail_tool_progress_type_0 = ToolProgressDetail.from_dict(data)



                return detail_tool_progress_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | ToolProgressDetail | Unset, data)

        detail_tool_progress = _parse_detail_tool_progress(d.pop("detail_tool_progress", UNSET))


        sse_schemas = cls(
            response_created=response_created,
            response_output_item_added=response_output_item_added,
            response_content_part_added=response_content_part_added,
            agent_step=agent_step,
            user_input_request=user_input_request,
            user_message=user_message,
            response_output_text_delta=response_output_text_delta,
            response_output_text_done=response_output_text_done,
            response_output_item_done=response_output_item_done,
            response_completed=response_completed,
            response_failed=response_failed,
            artifact=artifact,
            token_budget_context=token_budget_context,
            response_usage=response_usage,
            output_tokens_details=output_tokens_details,
            context_usage=context_usage,
            message_metadata=message_metadata,
            detail_search_documents=detail_search_documents,
            detail_get_document_passages=detail_get_document_passages,
            detail_get_table_of_contents=detail_get_table_of_contents,
            detail_view_document_pages=detail_view_document_pages,
            detail_get_full_document=detail_get_full_document,
            detail_web_search=detail_web_search,
            detail_personal_agent=detail_personal_agent,
            detail_read_url=detail_read_url,
            detail_create_plan=detail_create_plan,
            detail_save_skill=detail_save_skill,
            detail_run_code=detail_run_code,
            detail_create_artifact=detail_create_artifact,
            detail_ask_user=detail_ask_user,
            detail_evaluation=detail_evaluation,
            detail_tool_progress=detail_tool_progress,
        )


        sse_schemas.additional_properties = d
        return sse_schemas

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
