from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.workspace_role import WorkspaceRole
from ..types import UNSET, Unset
from typing import cast






T = TypeVar("T", bound="AddWorkspaceUsersRequest")



@_attrs_define
class AddWorkspaceUsersRequest:
    """ Request to add users to a workspace (POST /workspace/{id}/users).

    All invited users receive the same role.

        Attributes:
            emails (list[str]):
            role (WorkspaceRole | Unset): Role of a user within a workspace.
     """

    emails: list[str]
    role: WorkspaceRole | Unset = UNSET





    def to_dict(self) -> dict[str, Any]:
        emails = self.emails



        role: str | Unset = UNSET
        if not isinstance(self.role, Unset):
            role = self.role.value



        field_dict: dict[str, Any] = {}

        field_dict.update({
            "emails": emails,
        })
        if role is not UNSET:
            field_dict["role"] = role

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        emails = cast(list[str], d.pop("emails"))


        _role = d.pop("role", UNSET)
        role: WorkspaceRole | Unset
        if isinstance(_role,  Unset):
            role = UNSET
        else:
            role = WorkspaceRole(_role)




        add_workspace_users_request = cls(
            emails=emails,
            role=role,
        )

        return add_workspace_users_request

