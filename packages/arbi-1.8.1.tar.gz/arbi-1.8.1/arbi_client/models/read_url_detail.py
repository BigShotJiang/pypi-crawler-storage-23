from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import Literal, cast






T = TypeVar("T", bound="ReadUrlDetail")



@_attrs_define
class ReadUrlDetail:
    """ Detail for a read_url tool call.

        Attributes:
            url (str): URL to fetch (truncated to 120 chars)
            tool (Literal['read_url'] | Unset):  Default: 'read_url'.
     """

    url: str
    tool: Literal['read_url'] | Unset = 'read_url'
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        url = self.url

        tool = self.tool


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "url": url,
        })
        if tool is not UNSET:
            field_dict["tool"] = tool

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        url = d.pop("url")

        tool = cast(Literal['read_url'] | Unset , d.pop("tool", UNSET))
        if tool != 'read_url'and not isinstance(tool, Unset):
            raise ValueError(f"tool must match const 'read_url', got '{tool}'")

        read_url_detail = cls(
            url=url,
            tool=tool,
        )


        read_url_detail.additional_properties = d
        return read_url_detail

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
