from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import Literal, cast






T = TypeVar("T", bound="SaveSkillDetail")



@_attrs_define
class SaveSkillDetail:
    """ Detail for a save_skill tool call.

        Attributes:
            name (str): Skill name
            title (str): Skill title (truncated to 80 chars)
            tool (Literal['save_skill'] | Unset):  Default: 'save_skill'.
     """

    name: str
    title: str
    tool: Literal['save_skill'] | Unset = 'save_skill'
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        name = self.name

        title = self.title

        tool = self.tool


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "name": name,
            "title": title,
        })
        if tool is not UNSET:
            field_dict["tool"] = tool

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        name = d.pop("name")

        title = d.pop("title")

        tool = cast(Literal['save_skill'] | Unset , d.pop("tool", UNSET))
        if tool != 'save_skill'and not isinstance(tool, Unset):
            raise ValueError(f"tool must match const 'save_skill', got '{tool}'")

        save_skill_detail = cls(
            name=name,
            title=title,
            tool=tool,
        )


        save_skill_detail.additional_properties = d
        return save_skill_detail

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
