from enum import Enum

class BatchCompleteMessageBatchType(str, Enum):
    DOCTAG_GENERATE = "doctag_generate"
    UPLOAD = "upload"

    def __str__(self) -> str:
        return str(self.value)
