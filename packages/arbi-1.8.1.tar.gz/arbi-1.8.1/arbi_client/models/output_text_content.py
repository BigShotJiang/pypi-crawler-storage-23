from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast
from typing import Literal, cast






T = TypeVar("T", bound="OutputTextContent")



@_attrs_define
class OutputTextContent:
    """ A text content block in an output message.

        Attributes:
            text (str): The text content
            type_ (Literal['output_text'] | Unset):  Default: 'output_text'.
            annotations (list[Any] | Unset): Content annotations (reserved)
     """

    text: str
    type_: Literal['output_text'] | Unset = 'output_text'
    annotations: list[Any] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        text = self.text

        type_ = self.type_

        annotations: list[Any] | Unset = UNSET
        if not isinstance(self.annotations, Unset):
            annotations = self.annotations




        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "text": text,
        })
        if type_ is not UNSET:
            field_dict["type"] = type_
        if annotations is not UNSET:
            field_dict["annotations"] = annotations

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        text = d.pop("text")

        type_ = cast(Literal['output_text'] | Unset , d.pop("type", UNSET))
        if type_ != 'output_text'and not isinstance(type_, Unset):
            raise ValueError(f"type must match const 'output_text', got '{type_}'")

        annotations = cast(list[Any], d.pop("annotations", UNSET))


        output_text_content = cls(
            text=text,
            type_=type_,
            annotations=annotations,
        )


        output_text_content.additional_properties = d
        return output_text_content

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
