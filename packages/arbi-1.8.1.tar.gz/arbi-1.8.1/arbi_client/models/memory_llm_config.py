from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.memory_llm_config_api_type import MemoryLLMConfigApiType
from ..types import UNSET, Unset






T = TypeVar("T", bound="MemoryLLMConfig")



@_attrs_define
class MemoryLLMConfig:
    r""" Configuration for MemoryLLM - synthesizes memory documents (skills, memories, reports).

    Produces markdown documents from gathered context (learnings, retrieval results,
    conversation history). Output is saved as a document through the standard
    upload pipeline with wp_type indicating the document category.

        Attributes:
            api_type (MemoryLLMConfigApiType | Unset): The inference type (local or remote). Default:
                MemoryLLMConfigApiType.REMOTE.
            model_name (str | Unset): The model for memory synthesis. Defaults to reasoning model. Default: 'dummy'.
            system_instruction (str | Unset): System instruction for memory classification and synthesis. Default: 'You are
                a knowledge synthesizer. You receive the full agent scratchpad from a completed conversation and decide what, if
                anything, is worth saving.\n\n## Work Product Types\n- **\\"memory\\"**: Facts, findings, reference data — for
                *looking up* information.\n- **\\"skill\\"**: Procedures, workflows, step-by-step instructions — for *doing*
                something.\n\nWhen ambiguous, default to memory.\n\n## Rules\n- Return an empty work_products array if the
                conversation is trivial or produced nothing substantive.\n- Each work product must cover ONE coherent topic.
                Never combine disparate subjects into a single document — create separate documents for each distinct topic.\n-
                Ground everything in the provided context. Do not invent information.\n- Be concise. These are reference
                documents, not essays.\n\n## Output Format\nJSON with a `work_products` array. Each item has `wp_type`, `title`,
                and `content` (markdown).\n\nMemory content: `# Title`, date, source, key findings as bullets, source
                documents.\nSkill content: `# Title`, prerequisites, numbered steps, when to apply.'.
            temperature (float | Unset): Temperature for synthesis. Default: 0.3.
            max_tokens (int | Unset): Maximum tokens for memory content. Default: 8000.
            max_char_context (int | Unset): Maximum characters of input context. Default: 100000.
            max_concurrent (int | Unset): Maximum concurrent synthesis operations. Default: 5.
     """

    api_type: MemoryLLMConfigApiType | Unset = MemoryLLMConfigApiType.REMOTE
    model_name: str | Unset = 'dummy'
    system_instruction: str | Unset = 'You are a knowledge synthesizer. You receive the full agent scratchpad from a completed conversation and decide what, if anything, is worth saving.\n\n## Work Product Types\n- **\\"memory\\"**: Facts, findings, reference data — for *looking up* information.\n- **\\"skill\\"**: Procedures, workflows, step-by-step instructions — for *doing* something.\n\nWhen ambiguous, default to memory.\n\n## Rules\n- Return an empty work_products array if the conversation is trivial or produced nothing substantive.\n- Each work product must cover ONE coherent topic. Never combine disparate subjects into a single document — create separate documents for each distinct topic.\n- Ground everything in the provided context. Do not invent information.\n- Be concise. These are reference documents, not essays.\n\n## Output Format\nJSON with a `work_products` array. Each item has `wp_type`, `title`, and `content` (markdown).\n\nMemory content: `# Title`, date, source, key findings as bullets, source documents.\nSkill content: `# Title`, prerequisites, numbered steps, when to apply.'
    temperature: float | Unset = 0.3
    max_tokens: int | Unset = 8000
    max_char_context: int | Unset = 100000
    max_concurrent: int | Unset = 5
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        api_type: str | Unset = UNSET
        if not isinstance(self.api_type, Unset):
            api_type = self.api_type.value


        model_name = self.model_name

        system_instruction = self.system_instruction

        temperature = self.temperature

        max_tokens = self.max_tokens

        max_char_context = self.max_char_context

        max_concurrent = self.max_concurrent


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if api_type is not UNSET:
            field_dict["API_TYPE"] = api_type
        if model_name is not UNSET:
            field_dict["MODEL_NAME"] = model_name
        if system_instruction is not UNSET:
            field_dict["SYSTEM_INSTRUCTION"] = system_instruction
        if temperature is not UNSET:
            field_dict["TEMPERATURE"] = temperature
        if max_tokens is not UNSET:
            field_dict["MAX_TOKENS"] = max_tokens
        if max_char_context is not UNSET:
            field_dict["MAX_CHAR_CONTEXT"] = max_char_context
        if max_concurrent is not UNSET:
            field_dict["MAX_CONCURRENT"] = max_concurrent

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        _api_type = d.pop("API_TYPE", UNSET)
        api_type: MemoryLLMConfigApiType | Unset
        if isinstance(_api_type,  Unset):
            api_type = UNSET
        else:
            api_type = MemoryLLMConfigApiType(_api_type)




        model_name = d.pop("MODEL_NAME", UNSET)

        system_instruction = d.pop("SYSTEM_INSTRUCTION", UNSET)

        temperature = d.pop("TEMPERATURE", UNSET)

        max_tokens = d.pop("MAX_TOKENS", UNSET)

        max_char_context = d.pop("MAX_CHAR_CONTEXT", UNSET)

        max_concurrent = d.pop("MAX_CONCURRENT", UNSET)

        memory_llm_config = cls(
            api_type=api_type,
            model_name=model_name,
            system_instruction=system_instruction,
            temperature=temperature,
            max_tokens=max_tokens,
            max_char_context=max_char_context,
            max_concurrent=max_concurrent,
        )


        memory_llm_config.additional_properties = d
        return memory_llm_config

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
