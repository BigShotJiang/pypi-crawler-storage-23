from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.notification_type import NotificationType
from ..types import UNSET, Unset
from dateutil.parser import isoparse
from typing import cast
import datetime

if TYPE_CHECKING:
  from ..models.user_response import UserResponse





T = TypeVar("T", bound="NotificationResponse")



@_attrs_define
class NotificationResponse:
    """ Notification response model for API and WebSocket.

    Bilateral: both sender and recipient see the same row.
    Client determines perspective: sender == me → I sent it, else I received it.

        Attributes:
            type_ (NotificationType): Notification types - all persisted AND delivered via WebSocket.

                Type is self-descriptive, no need to parse content field.
            external_id (str):
            sender (UserResponse): Standard user representation used across all endpoints.

                Used for: login response, workspace users, contacts (when registered).
            recipient (UserResponse): Standard user representation used across all endpoints.

                Used for: login response, workspace users, contacts (when registered).
            created_at (datetime.datetime):
            updated_at (datetime.datetime):
            workspace_ext_id (None | str | Unset):
            content (None | str | Unset):
            read (bool | Unset):  Default: False.
     """

    type_: NotificationType
    external_id: str
    sender: UserResponse
    recipient: UserResponse
    created_at: datetime.datetime
    updated_at: datetime.datetime
    workspace_ext_id: None | str | Unset = UNSET
    content: None | str | Unset = UNSET
    read: bool | Unset = False
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.user_response import UserResponse
        type_ = self.type_.value

        external_id = self.external_id

        sender = self.sender.to_dict()

        recipient = self.recipient.to_dict()

        created_at = self.created_at.isoformat()

        updated_at = self.updated_at.isoformat()

        workspace_ext_id: None | str | Unset
        if isinstance(self.workspace_ext_id, Unset):
            workspace_ext_id = UNSET
        else:
            workspace_ext_id = self.workspace_ext_id

        content: None | str | Unset
        if isinstance(self.content, Unset):
            content = UNSET
        else:
            content = self.content

        read = self.read


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "type": type_,
            "external_id": external_id,
            "sender": sender,
            "recipient": recipient,
            "created_at": created_at,
            "updated_at": updated_at,
        })
        if workspace_ext_id is not UNSET:
            field_dict["workspace_ext_id"] = workspace_ext_id
        if content is not UNSET:
            field_dict["content"] = content
        if read is not UNSET:
            field_dict["read"] = read

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.user_response import UserResponse
        d = dict(src_dict)
        type_ = NotificationType(d.pop("type"))




        external_id = d.pop("external_id")

        sender = UserResponse.from_dict(d.pop("sender"))




        recipient = UserResponse.from_dict(d.pop("recipient"))




        created_at = isoparse(d.pop("created_at"))




        updated_at = isoparse(d.pop("updated_at"))




        def _parse_workspace_ext_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        workspace_ext_id = _parse_workspace_ext_id(d.pop("workspace_ext_id", UNSET))


        def _parse_content(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        content = _parse_content(d.pop("content", UNSET))


        read = d.pop("read", UNSET)

        notification_response = cls(
            type_=type_,
            external_id=external_id,
            sender=sender,
            recipient=recipient,
            created_at=created_at,
            updated_at=updated_at,
            workspace_ext_id=workspace_ext_id,
            content=content,
            read=read,
        )


        notification_response.additional_properties = d
        return notification_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
