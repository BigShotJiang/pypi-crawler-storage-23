from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.evaluator_llm_config_api_type import EvaluatorLLMConfigApiType
from ..types import UNSET, Unset






T = TypeVar("T", bound="EvaluatorLLMConfig")



@_attrs_define
class EvaluatorLLMConfig:
    """ 
        Attributes:
            api_type (EvaluatorLLMConfigApiType | Unset): The inference type (local or remote). Default:
                EvaluatorLLMConfigApiType.REMOTE.
            model_name (str | Unset): The name of the non-reasoning model to be used. Default: 'dummy'.
            system_instruction (str | Unset): The system instruction for chunk evaluation. Default: "You are a chunk
                evaluator. Analyze retrieved chunks to determine which are relevant to the user's query and extract key
                learnings from the RELEVANT chunks only. You must return your response as valid JSON matching the provided
                schema.".
            temperature (float | Unset): Low temperature for consistent evaluation. Default: 0.1.
            max_tokens (int | Unset): Maximum tokens for evaluation response. Default: 20000.
            max_char_size_to_answer (int | Unset): Maximum character size for evaluation context. Default: 100000.
     """

    api_type: EvaluatorLLMConfigApiType | Unset = EvaluatorLLMConfigApiType.REMOTE
    model_name: str | Unset = 'dummy'
    system_instruction: str | Unset = "You are a chunk evaluator. Analyze retrieved chunks to determine which are relevant to the user's query and extract key learnings from the RELEVANT chunks only. You must return your response as valid JSON matching the provided schema."
    temperature: float | Unset = 0.1
    max_tokens: int | Unset = 20000
    max_char_size_to_answer: int | Unset = 100000
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        api_type: str | Unset = UNSET
        if not isinstance(self.api_type, Unset):
            api_type = self.api_type.value


        model_name = self.model_name

        system_instruction = self.system_instruction

        temperature = self.temperature

        max_tokens = self.max_tokens

        max_char_size_to_answer = self.max_char_size_to_answer


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if api_type is not UNSET:
            field_dict["API_TYPE"] = api_type
        if model_name is not UNSET:
            field_dict["MODEL_NAME"] = model_name
        if system_instruction is not UNSET:
            field_dict["SYSTEM_INSTRUCTION"] = system_instruction
        if temperature is not UNSET:
            field_dict["TEMPERATURE"] = temperature
        if max_tokens is not UNSET:
            field_dict["MAX_TOKENS"] = max_tokens
        if max_char_size_to_answer is not UNSET:
            field_dict["MAX_CHAR_SIZE_TO_ANSWER"] = max_char_size_to_answer

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        _api_type = d.pop("API_TYPE", UNSET)
        api_type: EvaluatorLLMConfigApiType | Unset
        if isinstance(_api_type,  Unset):
            api_type = UNSET
        else:
            api_type = EvaluatorLLMConfigApiType(_api_type)




        model_name = d.pop("MODEL_NAME", UNSET)

        system_instruction = d.pop("SYSTEM_INSTRUCTION", UNSET)

        temperature = d.pop("TEMPERATURE", UNSET)

        max_tokens = d.pop("MAX_TOKENS", UNSET)

        max_char_size_to_answer = d.pop("MAX_CHAR_SIZE_TO_ANSWER", UNSET)

        evaluator_llm_config = cls(
            api_type=api_type,
            model_name=model_name,
            system_instruction=system_instruction,
            temperature=temperature,
            max_tokens=max_tokens,
            max_char_size_to_answer=max_char_size_to_answer,
        )


        evaluator_llm_config.additional_properties = d
        return evaluator_llm_config

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
