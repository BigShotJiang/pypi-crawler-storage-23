from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast
from typing import Literal, cast

if TYPE_CHECKING:
  from ..models.response_error import ResponseError





T = TypeVar("T", bound="ResponseFailedPayload")



@_attrs_define
class ResponseFailedPayload:
    """ The ``response`` dict in a ``response.failed`` SSE event.

        Attributes:
            id (str): Response ID (may be empty for early failures)
            error (ResponseError): Error object in a failed response.
            object_ (Literal['response'] | Unset):  Default: 'response'.
            status (Literal['failed'] | Unset):  Default: 'failed'.
     """

    id: str
    error: ResponseError
    object_: Literal['response'] | Unset = 'response'
    status: Literal['failed'] | Unset = 'failed'
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.response_error import ResponseError
        id = self.id

        error = self.error.to_dict()

        object_ = self.object_

        status = self.status


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "id": id,
            "error": error,
        })
        if object_ is not UNSET:
            field_dict["object"] = object_
        if status is not UNSET:
            field_dict["status"] = status

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.response_error import ResponseError
        d = dict(src_dict)
        id = d.pop("id")

        error = ResponseError.from_dict(d.pop("error"))




        object_ = cast(Literal['response'] | Unset , d.pop("object", UNSET))
        if object_ != 'response'and not isinstance(object_, Unset):
            raise ValueError(f"object must match const 'response', got '{object_}'")

        status = cast(Literal['failed'] | Unset , d.pop("status", UNSET))
        if status != 'failed'and not isinstance(status, Unset):
            raise ValueError(f"status must match const 'failed', got '{status}'")

        response_failed_payload = cls(
            id=id,
            error=error,
            object_=object_,
            status=status,
        )


        response_failed_payload.additional_properties = d
        return response_failed_payload

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
