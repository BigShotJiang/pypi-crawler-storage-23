from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from dateutil.parser import isoparse
from typing import cast
import datetime

if TYPE_CHECKING:
  from ..models.doc_tag_response_citations_type_0 import DocTagResponseCitationsType0





T = TypeVar("T", bound="DocTagResponse")



@_attrs_define
class DocTagResponse:
    """ Response for doctag operations - the link between a document and a tag.

        Attributes:
            doc_ext_id (str):
            tag_ext_id (str):
            created_by_ext_id (str):
            created_at (datetime.datetime):
            updated_at (datetime.datetime):
            note (None | str | Unset):
            citations (DocTagResponseCitationsType0 | None | Unset):
            updated_by_ext_id (None | str | Unset):
     """

    doc_ext_id: str
    tag_ext_id: str
    created_by_ext_id: str
    created_at: datetime.datetime
    updated_at: datetime.datetime
    note: None | str | Unset = UNSET
    citations: DocTagResponseCitationsType0 | None | Unset = UNSET
    updated_by_ext_id: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.doc_tag_response_citations_type_0 import DocTagResponseCitationsType0
        doc_ext_id = self.doc_ext_id

        tag_ext_id = self.tag_ext_id

        created_by_ext_id = self.created_by_ext_id

        created_at = self.created_at.isoformat()

        updated_at = self.updated_at.isoformat()

        note: None | str | Unset
        if isinstance(self.note, Unset):
            note = UNSET
        else:
            note = self.note

        citations: dict[str, Any] | None | Unset
        if isinstance(self.citations, Unset):
            citations = UNSET
        elif isinstance(self.citations, DocTagResponseCitationsType0):
            citations = self.citations.to_dict()
        else:
            citations = self.citations

        updated_by_ext_id: None | str | Unset
        if isinstance(self.updated_by_ext_id, Unset):
            updated_by_ext_id = UNSET
        else:
            updated_by_ext_id = self.updated_by_ext_id


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "doc_ext_id": doc_ext_id,
            "tag_ext_id": tag_ext_id,
            "created_by_ext_id": created_by_ext_id,
            "created_at": created_at,
            "updated_at": updated_at,
        })
        if note is not UNSET:
            field_dict["note"] = note
        if citations is not UNSET:
            field_dict["citations"] = citations
        if updated_by_ext_id is not UNSET:
            field_dict["updated_by_ext_id"] = updated_by_ext_id

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.doc_tag_response_citations_type_0 import DocTagResponseCitationsType0
        d = dict(src_dict)
        doc_ext_id = d.pop("doc_ext_id")

        tag_ext_id = d.pop("tag_ext_id")

        created_by_ext_id = d.pop("created_by_ext_id")

        created_at = isoparse(d.pop("created_at"))




        updated_at = isoparse(d.pop("updated_at"))




        def _parse_note(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        note = _parse_note(d.pop("note", UNSET))


        def _parse_citations(data: object) -> DocTagResponseCitationsType0 | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                citations_type_0 = DocTagResponseCitationsType0.from_dict(data)



                return citations_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(DocTagResponseCitationsType0 | None | Unset, data)

        citations = _parse_citations(d.pop("citations", UNSET))


        def _parse_updated_by_ext_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        updated_by_ext_id = _parse_updated_by_ext_id(d.pop("updated_by_ext_id", UNSET))


        doc_tag_response = cls(
            doc_ext_id=doc_ext_id,
            tag_ext_id=tag_ext_id,
            created_by_ext_id=created_by_ext_id,
            created_at=created_at,
            updated_at=updated_at,
            note=note,
            citations=citations,
            updated_by_ext_id=updated_by_ext_id,
        )


        doc_tag_response.additional_properties = d
        return doc_tag_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
