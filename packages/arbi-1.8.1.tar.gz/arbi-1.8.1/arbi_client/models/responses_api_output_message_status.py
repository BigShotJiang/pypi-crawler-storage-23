from enum import Enum

class ResponsesAPIOutputMessageStatus(str, Enum):
    COMPLETED = "completed"
    IN_PROGRESS = "in_progress"

    def __str__(self) -> str:
        return str(self.value)
