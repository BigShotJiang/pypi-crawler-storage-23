from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.output_message_status import OutputMessageStatus
from ..types import UNSET, Unset
from typing import cast
from typing import Literal, cast

if TYPE_CHECKING:
  from ..models.output_text_content import OutputTextContent





T = TypeVar("T", bound="OutputMessage")



@_attrs_define
class OutputMessage:
    """ A single output message entry in a response.

        Attributes:
            id (str): Message external ID
            status (OutputMessageStatus): Message status
            type_ (Literal['message'] | Unset):  Default: 'message'.
            role (Literal['assistant'] | Unset):  Default: 'assistant'.
            content (list[OutputTextContent] | Unset): Message content blocks
     """

    id: str
    status: OutputMessageStatus
    type_: Literal['message'] | Unset = 'message'
    role: Literal['assistant'] | Unset = 'assistant'
    content: list[OutputTextContent] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.output_text_content import OutputTextContent
        id = self.id

        status = self.status.value

        type_ = self.type_

        role = self.role

        content: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.content, Unset):
            content = []
            for content_item_data in self.content:
                content_item = content_item_data.to_dict()
                content.append(content_item)




        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "id": id,
            "status": status,
        })
        if type_ is not UNSET:
            field_dict["type"] = type_
        if role is not UNSET:
            field_dict["role"] = role
        if content is not UNSET:
            field_dict["content"] = content

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.output_text_content import OutputTextContent
        d = dict(src_dict)
        id = d.pop("id")

        status = OutputMessageStatus(d.pop("status"))




        type_ = cast(Literal['message'] | Unset , d.pop("type", UNSET))
        if type_ != 'message'and not isinstance(type_, Unset):
            raise ValueError(f"type must match const 'message', got '{type_}'")

        role = cast(Literal['assistant'] | Unset , d.pop("role", UNSET))
        if role != 'assistant'and not isinstance(role, Unset):
            raise ValueError(f"role must match const 'assistant', got '{role}'")

        _content = d.pop("content", UNSET)
        content: list[OutputTextContent] | Unset = UNSET
        if _content is not UNSET:
            content = []
            for content_item_data in _content:
                content_item = OutputTextContent.from_dict(content_item_data)



                content.append(content_item)


        output_message = cls(
            id=id,
            status=status,
            type_=type_,
            role=role,
            content=content,
        )


        output_message.additional_properties = d
        return output_message

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
