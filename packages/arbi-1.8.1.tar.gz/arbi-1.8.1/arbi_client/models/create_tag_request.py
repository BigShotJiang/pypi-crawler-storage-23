from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.tag_format import TagFormat





T = TypeVar("T", bound="CreateTagRequest")



@_attrs_define
class CreateTagRequest:
    """ Request to create a new tag in a workspace.

        Attributes:
            name (str):
            instruction (None | str | Unset):
            tag_type (TagFormat | Unset): Tag format configuration stored as JSONB.

                Type-specific fields:
                - select: options (list of choices, can be single or multi-select)
                - search: tag name is the query, chunks include relevance scores
                - checkbox, text, number: type only
            shared (bool | None | Unset):
            parent_ext_id (None | str | Unset):
     """

    name: str
    instruction: None | str | Unset = UNSET
    tag_type: TagFormat | Unset = UNSET
    shared: bool | None | Unset = UNSET
    parent_ext_id: None | str | Unset = UNSET





    def to_dict(self) -> dict[str, Any]:
        from ..models.tag_format import TagFormat
        name = self.name

        instruction: None | str | Unset
        if isinstance(self.instruction, Unset):
            instruction = UNSET
        else:
            instruction = self.instruction

        tag_type: dict[str, Any] | Unset = UNSET
        if not isinstance(self.tag_type, Unset):
            tag_type = self.tag_type.to_dict()

        shared: bool | None | Unset
        if isinstance(self.shared, Unset):
            shared = UNSET
        else:
            shared = self.shared

        parent_ext_id: None | str | Unset
        if isinstance(self.parent_ext_id, Unset):
            parent_ext_id = UNSET
        else:
            parent_ext_id = self.parent_ext_id


        field_dict: dict[str, Any] = {}

        field_dict.update({
            "name": name,
        })
        if instruction is not UNSET:
            field_dict["instruction"] = instruction
        if tag_type is not UNSET:
            field_dict["tag_type"] = tag_type
        if shared is not UNSET:
            field_dict["shared"] = shared
        if parent_ext_id is not UNSET:
            field_dict["parent_ext_id"] = parent_ext_id

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.tag_format import TagFormat
        d = dict(src_dict)
        name = d.pop("name")

        def _parse_instruction(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        instruction = _parse_instruction(d.pop("instruction", UNSET))


        _tag_type = d.pop("tag_type", UNSET)
        tag_type: TagFormat | Unset
        if isinstance(_tag_type,  Unset):
            tag_type = UNSET
        else:
            tag_type = TagFormat.from_dict(_tag_type)




        def _parse_shared(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        shared = _parse_shared(d.pop("shared", UNSET))


        def _parse_parent_ext_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        parent_ext_id = _parse_parent_ext_id(d.pop("parent_ext_id", UNSET))


        create_tag_request = cls(
            name=name,
            instruction=instruction,
            tag_type=tag_type,
            shared=shared,
            parent_ext_id=parent_ext_id,
        )

        return create_tag_request

