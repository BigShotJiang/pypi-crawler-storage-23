from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.subscription_info import SubscriptionInfo
  from ..models.table_view import TableView





T = TypeVar("T", bound="UserSettingsResponse")



@_attrs_define
class UserSettingsResponse:
    """ User settings response.

        Attributes:
            subscription (None | SubscriptionInfo | Unset):
            last_workspace (None | str | Unset):
            pinned_workspaces (list[str] | Unset):
            pinned_templates (list[str] | Unset):
            tableviews (list[TableView] | Unset):
            developer (bool | Unset):  Default: False.
            show_document_navigator (bool | Unset):  Default: False.
            show_thread_visualization (bool | Unset):  Default: False.
            show_smart_search (bool | Unset):  Default: False.
            show_security_settings (bool | Unset):  Default: False.
            show_invite_tab (bool | Unset):  Default: False.
            show_help_page (bool | Unset):  Default: False.
            show_templates (bool | Unset):  Default: True.
            show_pa_mode (bool | Unset):  Default: False.
            hide_online_status (bool | Unset):  Default: False.
            muted_users (list[str] | Unset):
     """

    subscription: None | SubscriptionInfo | Unset = UNSET
    last_workspace: None | str | Unset = UNSET
    pinned_workspaces: list[str] | Unset = UNSET
    pinned_templates: list[str] | Unset = UNSET
    tableviews: list[TableView] | Unset = UNSET
    developer: bool | Unset = False
    show_document_navigator: bool | Unset = False
    show_thread_visualization: bool | Unset = False
    show_smart_search: bool | Unset = False
    show_security_settings: bool | Unset = False
    show_invite_tab: bool | Unset = False
    show_help_page: bool | Unset = False
    show_templates: bool | Unset = True
    show_pa_mode: bool | Unset = False
    hide_online_status: bool | Unset = False
    muted_users: list[str] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.subscription_info import SubscriptionInfo
        from ..models.table_view import TableView
        subscription: dict[str, Any] | None | Unset
        if isinstance(self.subscription, Unset):
            subscription = UNSET
        elif isinstance(self.subscription, SubscriptionInfo):
            subscription = self.subscription.to_dict()
        else:
            subscription = self.subscription

        last_workspace: None | str | Unset
        if isinstance(self.last_workspace, Unset):
            last_workspace = UNSET
        else:
            last_workspace = self.last_workspace

        pinned_workspaces: list[str] | Unset = UNSET
        if not isinstance(self.pinned_workspaces, Unset):
            pinned_workspaces = self.pinned_workspaces



        pinned_templates: list[str] | Unset = UNSET
        if not isinstance(self.pinned_templates, Unset):
            pinned_templates = self.pinned_templates



        tableviews: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.tableviews, Unset):
            tableviews = []
            for tableviews_item_data in self.tableviews:
                tableviews_item = tableviews_item_data.to_dict()
                tableviews.append(tableviews_item)



        developer = self.developer

        show_document_navigator = self.show_document_navigator

        show_thread_visualization = self.show_thread_visualization

        show_smart_search = self.show_smart_search

        show_security_settings = self.show_security_settings

        show_invite_tab = self.show_invite_tab

        show_help_page = self.show_help_page

        show_templates = self.show_templates

        show_pa_mode = self.show_pa_mode

        hide_online_status = self.hide_online_status

        muted_users: list[str] | Unset = UNSET
        if not isinstance(self.muted_users, Unset):
            muted_users = self.muted_users




        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if subscription is not UNSET:
            field_dict["subscription"] = subscription
        if last_workspace is not UNSET:
            field_dict["last_workspace"] = last_workspace
        if pinned_workspaces is not UNSET:
            field_dict["pinned_workspaces"] = pinned_workspaces
        if pinned_templates is not UNSET:
            field_dict["pinned_templates"] = pinned_templates
        if tableviews is not UNSET:
            field_dict["tableviews"] = tableviews
        if developer is not UNSET:
            field_dict["developer"] = developer
        if show_document_navigator is not UNSET:
            field_dict["show_document_navigator"] = show_document_navigator
        if show_thread_visualization is not UNSET:
            field_dict["show_thread_visualization"] = show_thread_visualization
        if show_smart_search is not UNSET:
            field_dict["show_smart_search"] = show_smart_search
        if show_security_settings is not UNSET:
            field_dict["show_security_settings"] = show_security_settings
        if show_invite_tab is not UNSET:
            field_dict["show_invite_tab"] = show_invite_tab
        if show_help_page is not UNSET:
            field_dict["show_help_page"] = show_help_page
        if show_templates is not UNSET:
            field_dict["show_templates"] = show_templates
        if show_pa_mode is not UNSET:
            field_dict["show_pa_mode"] = show_pa_mode
        if hide_online_status is not UNSET:
            field_dict["hide_online_status"] = hide_online_status
        if muted_users is not UNSET:
            field_dict["muted_users"] = muted_users

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.subscription_info import SubscriptionInfo
        from ..models.table_view import TableView
        d = dict(src_dict)
        def _parse_subscription(data: object) -> None | SubscriptionInfo | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                subscription_type_0 = SubscriptionInfo.from_dict(data)



                return subscription_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | SubscriptionInfo | Unset, data)

        subscription = _parse_subscription(d.pop("subscription", UNSET))


        def _parse_last_workspace(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        last_workspace = _parse_last_workspace(d.pop("last_workspace", UNSET))


        pinned_workspaces = cast(list[str], d.pop("pinned_workspaces", UNSET))


        pinned_templates = cast(list[str], d.pop("pinned_templates", UNSET))


        _tableviews = d.pop("tableviews", UNSET)
        tableviews: list[TableView] | Unset = UNSET
        if _tableviews is not UNSET:
            tableviews = []
            for tableviews_item_data in _tableviews:
                tableviews_item = TableView.from_dict(tableviews_item_data)



                tableviews.append(tableviews_item)


        developer = d.pop("developer", UNSET)

        show_document_navigator = d.pop("show_document_navigator", UNSET)

        show_thread_visualization = d.pop("show_thread_visualization", UNSET)

        show_smart_search = d.pop("show_smart_search", UNSET)

        show_security_settings = d.pop("show_security_settings", UNSET)

        show_invite_tab = d.pop("show_invite_tab", UNSET)

        show_help_page = d.pop("show_help_page", UNSET)

        show_templates = d.pop("show_templates", UNSET)

        show_pa_mode = d.pop("show_pa_mode", UNSET)

        hide_online_status = d.pop("hide_online_status", UNSET)

        muted_users = cast(list[str], d.pop("muted_users", UNSET))


        user_settings_response = cls(
            subscription=subscription,
            last_workspace=last_workspace,
            pinned_workspaces=pinned_workspaces,
            pinned_templates=pinned_templates,
            tableviews=tableviews,
            developer=developer,
            show_document_navigator=show_document_navigator,
            show_thread_visualization=show_thread_visualization,
            show_smart_search=show_smart_search,
            show_security_settings=show_security_settings,
            show_invite_tab=show_invite_tab,
            show_help_page=show_help_page,
            show_templates=show_templates,
            show_pa_mode=show_pa_mode,
            hide_online_status=hide_online_status,
            muted_users=muted_users,
        )


        user_settings_response.additional_properties = d
        return user_settings_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
