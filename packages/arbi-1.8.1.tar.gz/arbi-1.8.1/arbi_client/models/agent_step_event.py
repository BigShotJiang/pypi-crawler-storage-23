from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast
from typing import Literal, cast

if TYPE_CHECKING:
  from ..models.agent_step_event_detail_type_0_item import AgentStepEventDetailType0Item
  from ..models.token_budget_context import TokenBudgetContext





T = TypeVar("T", bound="AgentStepEvent")



@_attrs_define
class AgentStepEvent:
    r""" A single agent step with a sequential index.

    Tool call steps have a detail list; lifecycle steps have a step string.
    The focus field carries the agent's current focus: what it's zeroing in on.
    The content field carries extended text (e.g. the research plan).

    Examples:
        {"type": "arbi.agent_step", "index": 1, "step": "planning",
         "content": "1. Search for force majeure clauses across all three contracts\n2. Compare scope and exclusions"}
        {"type": "arbi.agent_step", "index": 2,
         "focus": "Searching for force majeure clauses across the selected contracts.",
         "detail": [
            {"tool": "search_documents", "query": "force majeure", "search_mode": "hybrid"},
            {"tool": "get_table_of_contents", "doc_count": 2, "doc_ext_ids": ["doc-abc12345", "doc-def67890"]}
        ]}
        {"type": "arbi.agent_step", "index": 3,
         "focus": "Comparing the provisions found in Contract A with Contract B.",
         "detail": [
            {"tool": "get_document_passages", "doc_ext_id": "doc-abc12345", "from_ref": "5", "to_ref": "8"}
        ]}
        {"type": "arbi.agent_step", "index": 3, "detail": [
            {"tool": "web_search", "query": "latest arbitration developments 2026"}
        ]}
        {"type": "arbi.agent_step", "index": 3, "detail": [
            {"tool": "personal_agent", "task": "Execute Python code to compute the SHA256 hash..."}
        ]}
        {"type": "arbi.agent_step", "index": 3, "detail": [
            {"tool": "read_url", "url": "https://example.com/article"}
        ]}
        {"type": "arbi.agent_step", "index": 4, "step": "evaluation", "detail": [
            {"statement": "Newton prosecuted 28 coiners", "chunk_ids": ["chunk-abc"]},
            {"statement": "Counterfeiting was high treason", "chunk_ids": ["chunk-def"]}
        ]}
        {"type": "arbi.agent_step", "index": 5, "step": "tool_progress", "detail": [
            {"tool": "read_url", "message": "Fetching page"}
        ]}
        {"type": "arbi.agent_step", "index": 6, "step": "answering"}
        {"type": "arbi.agent_step", "index": 7, "step": "reviewing"}

        Attributes:
            index (int): Sequential step number (1-based)
            t (float | None | Unset): Seconds elapsed since stream start.
            type_ (Literal['arbi.agent_step'] | Unset):  Default: 'arbi.agent_step'.
            step (None | str | Unset): Lifecycle step (planning, answering, reviewing). Absent for tool calls.
            focus (None | str | Unset): Agent's current focus (single sentence). Present on tool call steps.
            content (None | str | Unset): Extended text content (e.g. research plan). Present on planning step.
            detail (list[AgentStepEventDetailType0Item] | None | Unset): Tool calls list. Each entry has 'tool' key plus
                tool-specific params.
            context (None | TokenBudgetContext | Unset): Token budget context snapshot. Present when retrieval counts
                change.
     """

    index: int
    t: float | None | Unset = UNSET
    type_: Literal['arbi.agent_step'] | Unset = 'arbi.agent_step'
    step: None | str | Unset = UNSET
    focus: None | str | Unset = UNSET
    content: None | str | Unset = UNSET
    detail: list[AgentStepEventDetailType0Item] | None | Unset = UNSET
    context: None | TokenBudgetContext | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.agent_step_event_detail_type_0_item import AgentStepEventDetailType0Item
        from ..models.token_budget_context import TokenBudgetContext
        index = self.index

        t: float | None | Unset
        if isinstance(self.t, Unset):
            t = UNSET
        else:
            t = self.t

        type_ = self.type_

        step: None | str | Unset
        if isinstance(self.step, Unset):
            step = UNSET
        else:
            step = self.step

        focus: None | str | Unset
        if isinstance(self.focus, Unset):
            focus = UNSET
        else:
            focus = self.focus

        content: None | str | Unset
        if isinstance(self.content, Unset):
            content = UNSET
        else:
            content = self.content

        detail: list[dict[str, Any]] | None | Unset
        if isinstance(self.detail, Unset):
            detail = UNSET
        elif isinstance(self.detail, list):
            detail = []
            for detail_type_0_item_data in self.detail:
                detail_type_0_item = detail_type_0_item_data.to_dict()
                detail.append(detail_type_0_item)


        else:
            detail = self.detail

        context: dict[str, Any] | None | Unset
        if isinstance(self.context, Unset):
            context = UNSET
        elif isinstance(self.context, TokenBudgetContext):
            context = self.context.to_dict()
        else:
            context = self.context


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "index": index,
        })
        if t is not UNSET:
            field_dict["t"] = t
        if type_ is not UNSET:
            field_dict["type"] = type_
        if step is not UNSET:
            field_dict["step"] = step
        if focus is not UNSET:
            field_dict["focus"] = focus
        if content is not UNSET:
            field_dict["content"] = content
        if detail is not UNSET:
            field_dict["detail"] = detail
        if context is not UNSET:
            field_dict["context"] = context

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.agent_step_event_detail_type_0_item import AgentStepEventDetailType0Item
        from ..models.token_budget_context import TokenBudgetContext
        d = dict(src_dict)
        index = d.pop("index")

        def _parse_t(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        t = _parse_t(d.pop("t", UNSET))


        type_ = cast(Literal['arbi.agent_step'] | Unset , d.pop("type", UNSET))
        if type_ != 'arbi.agent_step'and not isinstance(type_, Unset):
            raise ValueError(f"type must match const 'arbi.agent_step', got '{type_}'")

        def _parse_step(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        step = _parse_step(d.pop("step", UNSET))


        def _parse_focus(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        focus = _parse_focus(d.pop("focus", UNSET))


        def _parse_content(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        content = _parse_content(d.pop("content", UNSET))


        def _parse_detail(data: object) -> list[AgentStepEventDetailType0Item] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                detail_type_0 = []
                _detail_type_0 = data
                for detail_type_0_item_data in (_detail_type_0):
                    detail_type_0_item = AgentStepEventDetailType0Item.from_dict(detail_type_0_item_data)



                    detail_type_0.append(detail_type_0_item)

                return detail_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[AgentStepEventDetailType0Item] | None | Unset, data)

        detail = _parse_detail(d.pop("detail", UNSET))


        def _parse_context(data: object) -> None | TokenBudgetContext | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                context_type_0 = TokenBudgetContext.from_dict(data)



                return context_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | TokenBudgetContext | Unset, data)

        context = _parse_context(d.pop("context", UNSET))


        agent_step_event = cls(
            index=index,
            t=t,
            type_=type_,
            step=step,
            focus=focus,
            content=content,
            detail=detail,
            context=context,
        )


        agent_step_event.additional_properties = d
        return agent_step_event

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
