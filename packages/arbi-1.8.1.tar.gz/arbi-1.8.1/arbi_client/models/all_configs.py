from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.agents_config import AgentsConfig
  from ..models.chunker_config import ChunkerConfig
  from ..models.code_agent_config import CodeAgentConfig
  from ..models.doctag_llm_config import DoctagLLMConfig
  from ..models.embedder_config import EmbedderConfig
  from ..models.evaluator_llm_config import EvaluatorLLMConfig
  from ..models.keyword_embedder_config import KeywordEmbedderConfig
  from ..models.memory_llm_config import MemoryLLMConfig
  from ..models.model_citation_config import ModelCitationConfig
  from ..models.parser_config import ParserConfig
  from ..models.planning_llm_config import PlanningLLMConfig
  from ..models.query_llm_config import QueryLLMConfig
  from ..models.reranker_config import RerankerConfig
  from ..models.retriever_config import RetrieverConfig
  from ..models.review_llm_config import ReviewLLMConfig
  from ..models.summarise_llm_config import SummariseLLMConfig
  from ..models.title_llm_config import TitleLLMConfig
  from ..models.vision_llm_config import VisionLLMConfig





T = TypeVar("T", bound="AllConfigs")



@_attrs_define
class AllConfigs:
    """ 
        Attributes:
            agents (AgentsConfig | Unset): Configuration for agent workflow.
            query_llm (QueryLLMConfig | Unset):
            review_llm (ReviewLLMConfig | Unset): Configuration for ReviewLLM - reviews agent draft answers against source
                material.
            evaluator_llm (EvaluatorLLMConfig | Unset):
            title_llm (TitleLLMConfig | Unset):
            summarise_llm (SummariseLLMConfig | Unset): Configuration for conversation summarisation. Used for compaction
                and general summaries.
            doctag_llm (DoctagLLMConfig | Unset): Configuration for DoctagLLM - extracts information from documents based on
                tag instructions.
            memory_llm (MemoryLLMConfig | Unset): Configuration for MemoryLLM - synthesizes memory documents (skills,
                memories, reports).

                Produces markdown documents from gathered context (learnings, retrieval results,
                conversation history). Output is saved as a document through the standard
                upload pipeline with wp_type indicating the document category.
            planning_llm (PlanningLLMConfig | Unset): Configuration for PlanningLLM — generates research plans on demand.

                Backed by a reasoning model. The agent calls the create_plan tool when it
                deems a task complex enough; the plan text is returned as a tool result.
            vision_llm (VisionLLMConfig | Unset): Configuration for VisionLLM — visually inspects document pages.

                Used as a targeted fallback when text extraction (get_document_passages)
                is insufficient, e.g. for figures, charts, tables, scanned pages.
                The prompt is constructed dynamically per call (no system instruction).
            code_agent (CodeAgentConfig | Unset): Configuration for CodeAgent — sub-agent that writes and executes code via
                sandbox.
            model_citation (ModelCitationConfig | Unset):
            retriever (RetrieverConfig | Unset):
            reranker (RerankerConfig | Unset):
            parser (ParserConfig | Unset):
            chunker (ChunkerConfig | Unset):
            embedder (EmbedderConfig | Unset):
            keyword_embedder (KeywordEmbedderConfig | Unset): Configuration for keyword embedder with BM25 scoring.
     """

    agents: AgentsConfig | Unset = UNSET
    query_llm: QueryLLMConfig | Unset = UNSET
    review_llm: ReviewLLMConfig | Unset = UNSET
    evaluator_llm: EvaluatorLLMConfig | Unset = UNSET
    title_llm: TitleLLMConfig | Unset = UNSET
    summarise_llm: SummariseLLMConfig | Unset = UNSET
    doctag_llm: DoctagLLMConfig | Unset = UNSET
    memory_llm: MemoryLLMConfig | Unset = UNSET
    planning_llm: PlanningLLMConfig | Unset = UNSET
    vision_llm: VisionLLMConfig | Unset = UNSET
    code_agent: CodeAgentConfig | Unset = UNSET
    model_citation: ModelCitationConfig | Unset = UNSET
    retriever: RetrieverConfig | Unset = UNSET
    reranker: RerankerConfig | Unset = UNSET
    parser: ParserConfig | Unset = UNSET
    chunker: ChunkerConfig | Unset = UNSET
    embedder: EmbedderConfig | Unset = UNSET
    keyword_embedder: KeywordEmbedderConfig | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.summarise_llm_config import SummariseLLMConfig
        from ..models.review_llm_config import ReviewLLMConfig
        from ..models.vision_llm_config import VisionLLMConfig
        from ..models.evaluator_llm_config import EvaluatorLLMConfig
        from ..models.agents_config import AgentsConfig
        from ..models.embedder_config import EmbedderConfig
        from ..models.keyword_embedder_config import KeywordEmbedderConfig
        from ..models.reranker_config import RerankerConfig
        from ..models.memory_llm_config import MemoryLLMConfig
        from ..models.doctag_llm_config import DoctagLLMConfig
        from ..models.chunker_config import ChunkerConfig
        from ..models.planning_llm_config import PlanningLLMConfig
        from ..models.model_citation_config import ModelCitationConfig
        from ..models.query_llm_config import QueryLLMConfig
        from ..models.parser_config import ParserConfig
        from ..models.title_llm_config import TitleLLMConfig
        from ..models.code_agent_config import CodeAgentConfig
        from ..models.retriever_config import RetrieverConfig
        agents: dict[str, Any] | Unset = UNSET
        if not isinstance(self.agents, Unset):
            agents = self.agents.to_dict()

        query_llm: dict[str, Any] | Unset = UNSET
        if not isinstance(self.query_llm, Unset):
            query_llm = self.query_llm.to_dict()

        review_llm: dict[str, Any] | Unset = UNSET
        if not isinstance(self.review_llm, Unset):
            review_llm = self.review_llm.to_dict()

        evaluator_llm: dict[str, Any] | Unset = UNSET
        if not isinstance(self.evaluator_llm, Unset):
            evaluator_llm = self.evaluator_llm.to_dict()

        title_llm: dict[str, Any] | Unset = UNSET
        if not isinstance(self.title_llm, Unset):
            title_llm = self.title_llm.to_dict()

        summarise_llm: dict[str, Any] | Unset = UNSET
        if not isinstance(self.summarise_llm, Unset):
            summarise_llm = self.summarise_llm.to_dict()

        doctag_llm: dict[str, Any] | Unset = UNSET
        if not isinstance(self.doctag_llm, Unset):
            doctag_llm = self.doctag_llm.to_dict()

        memory_llm: dict[str, Any] | Unset = UNSET
        if not isinstance(self.memory_llm, Unset):
            memory_llm = self.memory_llm.to_dict()

        planning_llm: dict[str, Any] | Unset = UNSET
        if not isinstance(self.planning_llm, Unset):
            planning_llm = self.planning_llm.to_dict()

        vision_llm: dict[str, Any] | Unset = UNSET
        if not isinstance(self.vision_llm, Unset):
            vision_llm = self.vision_llm.to_dict()

        code_agent: dict[str, Any] | Unset = UNSET
        if not isinstance(self.code_agent, Unset):
            code_agent = self.code_agent.to_dict()

        model_citation: dict[str, Any] | Unset = UNSET
        if not isinstance(self.model_citation, Unset):
            model_citation = self.model_citation.to_dict()

        retriever: dict[str, Any] | Unset = UNSET
        if not isinstance(self.retriever, Unset):
            retriever = self.retriever.to_dict()

        reranker: dict[str, Any] | Unset = UNSET
        if not isinstance(self.reranker, Unset):
            reranker = self.reranker.to_dict()

        parser: dict[str, Any] | Unset = UNSET
        if not isinstance(self.parser, Unset):
            parser = self.parser.to_dict()

        chunker: dict[str, Any] | Unset = UNSET
        if not isinstance(self.chunker, Unset):
            chunker = self.chunker.to_dict()

        embedder: dict[str, Any] | Unset = UNSET
        if not isinstance(self.embedder, Unset):
            embedder = self.embedder.to_dict()

        keyword_embedder: dict[str, Any] | Unset = UNSET
        if not isinstance(self.keyword_embedder, Unset):
            keyword_embedder = self.keyword_embedder.to_dict()


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if agents is not UNSET:
            field_dict["Agents"] = agents
        if query_llm is not UNSET:
            field_dict["QueryLLM"] = query_llm
        if review_llm is not UNSET:
            field_dict["ReviewLLM"] = review_llm
        if evaluator_llm is not UNSET:
            field_dict["EvaluatorLLM"] = evaluator_llm
        if title_llm is not UNSET:
            field_dict["TitleLLM"] = title_llm
        if summarise_llm is not UNSET:
            field_dict["SummariseLLM"] = summarise_llm
        if doctag_llm is not UNSET:
            field_dict["DoctagLLM"] = doctag_llm
        if memory_llm is not UNSET:
            field_dict["MemoryLLM"] = memory_llm
        if planning_llm is not UNSET:
            field_dict["PlanningLLM"] = planning_llm
        if vision_llm is not UNSET:
            field_dict["VisionLLM"] = vision_llm
        if code_agent is not UNSET:
            field_dict["CodeAgent"] = code_agent
        if model_citation is not UNSET:
            field_dict["ModelCitation"] = model_citation
        if retriever is not UNSET:
            field_dict["Retriever"] = retriever
        if reranker is not UNSET:
            field_dict["Reranker"] = reranker
        if parser is not UNSET:
            field_dict["Parser"] = parser
        if chunker is not UNSET:
            field_dict["Chunker"] = chunker
        if embedder is not UNSET:
            field_dict["Embedder"] = embedder
        if keyword_embedder is not UNSET:
            field_dict["KeywordEmbedder"] = keyword_embedder

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.agents_config import AgentsConfig
        from ..models.chunker_config import ChunkerConfig
        from ..models.code_agent_config import CodeAgentConfig
        from ..models.doctag_llm_config import DoctagLLMConfig
        from ..models.embedder_config import EmbedderConfig
        from ..models.evaluator_llm_config import EvaluatorLLMConfig
        from ..models.keyword_embedder_config import KeywordEmbedderConfig
        from ..models.memory_llm_config import MemoryLLMConfig
        from ..models.model_citation_config import ModelCitationConfig
        from ..models.parser_config import ParserConfig
        from ..models.planning_llm_config import PlanningLLMConfig
        from ..models.query_llm_config import QueryLLMConfig
        from ..models.reranker_config import RerankerConfig
        from ..models.retriever_config import RetrieverConfig
        from ..models.review_llm_config import ReviewLLMConfig
        from ..models.summarise_llm_config import SummariseLLMConfig
        from ..models.title_llm_config import TitleLLMConfig
        from ..models.vision_llm_config import VisionLLMConfig
        d = dict(src_dict)
        _agents = d.pop("Agents", UNSET)
        agents: AgentsConfig | Unset
        if isinstance(_agents,  Unset):
            agents = UNSET
        else:
            agents = AgentsConfig.from_dict(_agents)




        _query_llm = d.pop("QueryLLM", UNSET)
        query_llm: QueryLLMConfig | Unset
        if isinstance(_query_llm,  Unset):
            query_llm = UNSET
        else:
            query_llm = QueryLLMConfig.from_dict(_query_llm)




        _review_llm = d.pop("ReviewLLM", UNSET)
        review_llm: ReviewLLMConfig | Unset
        if isinstance(_review_llm,  Unset):
            review_llm = UNSET
        else:
            review_llm = ReviewLLMConfig.from_dict(_review_llm)




        _evaluator_llm = d.pop("EvaluatorLLM", UNSET)
        evaluator_llm: EvaluatorLLMConfig | Unset
        if isinstance(_evaluator_llm,  Unset):
            evaluator_llm = UNSET
        else:
            evaluator_llm = EvaluatorLLMConfig.from_dict(_evaluator_llm)




        _title_llm = d.pop("TitleLLM", UNSET)
        title_llm: TitleLLMConfig | Unset
        if isinstance(_title_llm,  Unset):
            title_llm = UNSET
        else:
            title_llm = TitleLLMConfig.from_dict(_title_llm)




        _summarise_llm = d.pop("SummariseLLM", UNSET)
        summarise_llm: SummariseLLMConfig | Unset
        if isinstance(_summarise_llm,  Unset):
            summarise_llm = UNSET
        else:
            summarise_llm = SummariseLLMConfig.from_dict(_summarise_llm)




        _doctag_llm = d.pop("DoctagLLM", UNSET)
        doctag_llm: DoctagLLMConfig | Unset
        if isinstance(_doctag_llm,  Unset):
            doctag_llm = UNSET
        else:
            doctag_llm = DoctagLLMConfig.from_dict(_doctag_llm)




        _memory_llm = d.pop("MemoryLLM", UNSET)
        memory_llm: MemoryLLMConfig | Unset
        if isinstance(_memory_llm,  Unset):
            memory_llm = UNSET
        else:
            memory_llm = MemoryLLMConfig.from_dict(_memory_llm)




        _planning_llm = d.pop("PlanningLLM", UNSET)
        planning_llm: PlanningLLMConfig | Unset
        if isinstance(_planning_llm,  Unset):
            planning_llm = UNSET
        else:
            planning_llm = PlanningLLMConfig.from_dict(_planning_llm)




        _vision_llm = d.pop("VisionLLM", UNSET)
        vision_llm: VisionLLMConfig | Unset
        if isinstance(_vision_llm,  Unset):
            vision_llm = UNSET
        else:
            vision_llm = VisionLLMConfig.from_dict(_vision_llm)




        _code_agent = d.pop("CodeAgent", UNSET)
        code_agent: CodeAgentConfig | Unset
        if isinstance(_code_agent,  Unset):
            code_agent = UNSET
        else:
            code_agent = CodeAgentConfig.from_dict(_code_agent)




        _model_citation = d.pop("ModelCitation", UNSET)
        model_citation: ModelCitationConfig | Unset
        if isinstance(_model_citation,  Unset):
            model_citation = UNSET
        else:
            model_citation = ModelCitationConfig.from_dict(_model_citation)




        _retriever = d.pop("Retriever", UNSET)
        retriever: RetrieverConfig | Unset
        if isinstance(_retriever,  Unset):
            retriever = UNSET
        else:
            retriever = RetrieverConfig.from_dict(_retriever)




        _reranker = d.pop("Reranker", UNSET)
        reranker: RerankerConfig | Unset
        if isinstance(_reranker,  Unset):
            reranker = UNSET
        else:
            reranker = RerankerConfig.from_dict(_reranker)




        _parser = d.pop("Parser", UNSET)
        parser: ParserConfig | Unset
        if isinstance(_parser,  Unset):
            parser = UNSET
        else:
            parser = ParserConfig.from_dict(_parser)




        _chunker = d.pop("Chunker", UNSET)
        chunker: ChunkerConfig | Unset
        if isinstance(_chunker,  Unset):
            chunker = UNSET
        else:
            chunker = ChunkerConfig.from_dict(_chunker)




        _embedder = d.pop("Embedder", UNSET)
        embedder: EmbedderConfig | Unset
        if isinstance(_embedder,  Unset):
            embedder = UNSET
        else:
            embedder = EmbedderConfig.from_dict(_embedder)




        _keyword_embedder = d.pop("KeywordEmbedder", UNSET)
        keyword_embedder: KeywordEmbedderConfig | Unset
        if isinstance(_keyword_embedder,  Unset):
            keyword_embedder = UNSET
        else:
            keyword_embedder = KeywordEmbedderConfig.from_dict(_keyword_embedder)




        all_configs = cls(
            agents=agents,
            query_llm=query_llm,
            review_llm=review_llm,
            evaluator_llm=evaluator_llm,
            title_llm=title_llm,
            summarise_llm=summarise_llm,
            doctag_llm=doctag_llm,
            memory_llm=memory_llm,
            planning_llm=planning_llm,
            vision_llm=vision_llm,
            code_agent=code_agent,
            model_citation=model_citation,
            retriever=retriever,
            reranker=reranker,
            parser=parser,
            chunker=chunker,
            embedder=embedder,
            keyword_embedder=keyword_embedder,
        )


        all_configs.additional_properties = d
        return all_configs

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
