from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.workspace_role import WorkspaceRole
from typing import cast






T = TypeVar("T", bound="UpdateWorkspaceUserRolesRequest")



@_attrs_define
class UpdateWorkspaceUserRolesRequest:
    """ Request to update user roles in a workspace (PATCH /workspace/{id}/users).

    All specified users are updated to the same role.

        Attributes:
            user_ext_ids (list[str]):
            role (WorkspaceRole): Role of a user within a workspace.
     """

    user_ext_ids: list[str]
    role: WorkspaceRole





    def to_dict(self) -> dict[str, Any]:
        user_ext_ids = self.user_ext_ids



        role = self.role.value


        field_dict: dict[str, Any] = {}

        field_dict.update({
            "user_ext_ids": user_ext_ids,
            "role": role,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        user_ext_ids = cast(list[str], d.pop("user_ext_ids"))


        role = WorkspaceRole(d.pop("role"))




        update_workspace_user_roles_request = cls(
            user_ext_ids=user_ext_ids,
            role=role,
        )

        return update_workspace_user_roles_request

