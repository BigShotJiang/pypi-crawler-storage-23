from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.message_input_tools import MessageInputTools





T = TypeVar("T", bound="MessageInput")



@_attrs_define
class MessageInput:
    """ 
        Attributes:
            input_ (str):
            tools (MessageInputTools | Unset):
            workspace_ext_id (str | Unset):  Default: ''.
            previous_response_id (None | str | Unset):
            model (None | str | Unset):
            stream (bool | Unset):  Default: False.
            background (bool | Unset):  Default: False.
            store (bool | Unset):  Default: True.
            instructions (None | str | Unset):
            max_output_tokens (int | None | Unset):
            temperature (float | None | Unset):
            top_p (float | None | Unset):
     """

    input_: str
    tools: MessageInputTools | Unset = UNSET
    workspace_ext_id: str | Unset = ''
    previous_response_id: None | str | Unset = UNSET
    model: None | str | Unset = UNSET
    stream: bool | Unset = False
    background: bool | Unset = False
    store: bool | Unset = True
    instructions: None | str | Unset = UNSET
    max_output_tokens: int | None | Unset = UNSET
    temperature: float | None | Unset = UNSET
    top_p: float | None | Unset = UNSET





    def to_dict(self) -> dict[str, Any]:
        from ..models.message_input_tools import MessageInputTools
        input_ = self.input_

        tools: dict[str, Any] | Unset = UNSET
        if not isinstance(self.tools, Unset):
            tools = self.tools.to_dict()

        workspace_ext_id = self.workspace_ext_id

        previous_response_id: None | str | Unset
        if isinstance(self.previous_response_id, Unset):
            previous_response_id = UNSET
        else:
            previous_response_id = self.previous_response_id

        model: None | str | Unset
        if isinstance(self.model, Unset):
            model = UNSET
        else:
            model = self.model

        stream = self.stream

        background = self.background

        store = self.store

        instructions: None | str | Unset
        if isinstance(self.instructions, Unset):
            instructions = UNSET
        else:
            instructions = self.instructions

        max_output_tokens: int | None | Unset
        if isinstance(self.max_output_tokens, Unset):
            max_output_tokens = UNSET
        else:
            max_output_tokens = self.max_output_tokens

        temperature: float | None | Unset
        if isinstance(self.temperature, Unset):
            temperature = UNSET
        else:
            temperature = self.temperature

        top_p: float | None | Unset
        if isinstance(self.top_p, Unset):
            top_p = UNSET
        else:
            top_p = self.top_p


        field_dict: dict[str, Any] = {}

        field_dict.update({
            "input": input_,
        })
        if tools is not UNSET:
            field_dict["tools"] = tools
        if workspace_ext_id is not UNSET:
            field_dict["workspace_ext_id"] = workspace_ext_id
        if previous_response_id is not UNSET:
            field_dict["previous_response_id"] = previous_response_id
        if model is not UNSET:
            field_dict["model"] = model
        if stream is not UNSET:
            field_dict["stream"] = stream
        if background is not UNSET:
            field_dict["background"] = background
        if store is not UNSET:
            field_dict["store"] = store
        if instructions is not UNSET:
            field_dict["instructions"] = instructions
        if max_output_tokens is not UNSET:
            field_dict["max_output_tokens"] = max_output_tokens
        if temperature is not UNSET:
            field_dict["temperature"] = temperature
        if top_p is not UNSET:
            field_dict["top_p"] = top_p

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.message_input_tools import MessageInputTools
        d = dict(src_dict)
        input_ = d.pop("input")

        _tools = d.pop("tools", UNSET)
        tools: MessageInputTools | Unset
        if isinstance(_tools,  Unset):
            tools = UNSET
        else:
            tools = MessageInputTools.from_dict(_tools)




        workspace_ext_id = d.pop("workspace_ext_id", UNSET)

        def _parse_previous_response_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        previous_response_id = _parse_previous_response_id(d.pop("previous_response_id", UNSET))


        def _parse_model(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        model = _parse_model(d.pop("model", UNSET))


        stream = d.pop("stream", UNSET)

        background = d.pop("background", UNSET)

        store = d.pop("store", UNSET)

        def _parse_instructions(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        instructions = _parse_instructions(d.pop("instructions", UNSET))


        def _parse_max_output_tokens(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        max_output_tokens = _parse_max_output_tokens(d.pop("max_output_tokens", UNSET))


        def _parse_temperature(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        temperature = _parse_temperature(d.pop("temperature", UNSET))


        def _parse_top_p(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        top_p = _parse_top_p(d.pop("top_p", UNSET))


        message_input = cls(
            input_=input_,
            tools=tools,
            workspace_ext_id=workspace_ext_id,
            previous_response_id=previous_response_id,
            model=model,
            stream=stream,
            background=background,
            store=store,
            instructions=instructions,
            max_output_tokens=max_output_tokens,
            temperature=temperature,
            top_p=top_p,
        )

        return message_input

