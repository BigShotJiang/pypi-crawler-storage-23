from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.code_agent_config_api_type import CodeAgentConfigApiType
from ..types import UNSET, Unset






T = TypeVar("T", bound="CodeAgentConfig")



@_attrs_define
class CodeAgentConfig:
    r""" Configuration for CodeAgent — sub-agent that writes and executes code via sandbox.

        Attributes:
            api_type (CodeAgentConfigApiType | Unset): The inference type (local or remote). Default:
                CodeAgentConfigApiType.REMOTE.
            model_name (str | Unset): Model for code generation. Should be a strong coding model. Default: ''.
            system_instruction (str | Unset): System prompt for the code execution agent. Default: "You are a code execution
                agent. You write and run code to accomplish tasks.\n\nYou have access to an execute_code tool that runs code in
                a sandboxed Docker container.\n\nThe sandbox has:\n- Python 3.12 with numpy, pandas, matplotlib, requests,
                beautifulsoup4,\n  httpx, pillow, sympy, pyyaml (plus uv for installing more)\n- Node.js 22 with TypeScript (ts-
                node) and npm\n- Bash with git, curl, wget, jq, sqlite3, build-essential\n- Network access (can pip/npm install
                additional packages)\n\nInstructions:\n1. Write clean, correct code to accomplish the user's task\n2. Always
                call execute_code to run your code — never guess the output\n3. If execution errors, analyze the traceback, fix
                the code, and retry\n4. Once you have the correct output, respond with ONLY the final result\n\nKeep code simple
                and direct. Prefer Python unless the task specifically requires another language.".
            temperature (float | Unset):  Default: 0.2.
            max_tokens (int | Unset):  Default: 8000.
            max_iterations (int | Unset): Maximum code-execute-fix retry cycles. Default: 3.
     """

    api_type: CodeAgentConfigApiType | Unset = CodeAgentConfigApiType.REMOTE
    model_name: str | Unset = ''
    system_instruction: str | Unset = "You are a code execution agent. You write and run code to accomplish tasks.\n\nYou have access to an execute_code tool that runs code in a sandboxed Docker container.\n\nThe sandbox has:\n- Python 3.12 with numpy, pandas, matplotlib, requests, beautifulsoup4,\n  httpx, pillow, sympy, pyyaml (plus uv for installing more)\n- Node.js 22 with TypeScript (ts-node) and npm\n- Bash with git, curl, wget, jq, sqlite3, build-essential\n- Network access (can pip/npm install additional packages)\n\nInstructions:\n1. Write clean, correct code to accomplish the user's task\n2. Always call execute_code to run your code — never guess the output\n3. If execution errors, analyze the traceback, fix the code, and retry\n4. Once you have the correct output, respond with ONLY the final result\n\nKeep code simple and direct. Prefer Python unless the task specifically requires another language."
    temperature: float | Unset = 0.2
    max_tokens: int | Unset = 8000
    max_iterations: int | Unset = 3
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        api_type: str | Unset = UNSET
        if not isinstance(self.api_type, Unset):
            api_type = self.api_type.value


        model_name = self.model_name

        system_instruction = self.system_instruction

        temperature = self.temperature

        max_tokens = self.max_tokens

        max_iterations = self.max_iterations


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if api_type is not UNSET:
            field_dict["API_TYPE"] = api_type
        if model_name is not UNSET:
            field_dict["MODEL_NAME"] = model_name
        if system_instruction is not UNSET:
            field_dict["SYSTEM_INSTRUCTION"] = system_instruction
        if temperature is not UNSET:
            field_dict["TEMPERATURE"] = temperature
        if max_tokens is not UNSET:
            field_dict["MAX_TOKENS"] = max_tokens
        if max_iterations is not UNSET:
            field_dict["MAX_ITERATIONS"] = max_iterations

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        _api_type = d.pop("API_TYPE", UNSET)
        api_type: CodeAgentConfigApiType | Unset
        if isinstance(_api_type,  Unset):
            api_type = UNSET
        else:
            api_type = CodeAgentConfigApiType(_api_type)




        model_name = d.pop("MODEL_NAME", UNSET)

        system_instruction = d.pop("SYSTEM_INSTRUCTION", UNSET)

        temperature = d.pop("TEMPERATURE", UNSET)

        max_tokens = d.pop("MAX_TOKENS", UNSET)

        max_iterations = d.pop("MAX_ITERATIONS", UNSET)

        code_agent_config = cls(
            api_type=api_type,
            model_name=model_name,
            system_instruction=system_instruction,
            temperature=temperature,
            max_tokens=max_tokens,
            max_iterations=max_iterations,
        )


        code_agent_config.additional_properties = d
        return code_agent_config

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
