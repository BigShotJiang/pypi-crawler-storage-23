from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast
from typing import Literal, cast

if TYPE_CHECKING:
  from ..models.responses_api_output_text_annotations_item import ResponsesAPIOutputTextAnnotationsItem





T = TypeVar("T", bound="ResponsesAPIOutputText")



@_attrs_define
class ResponsesAPIOutputText:
    """ Text output content item.

        Attributes:
            text (str):
            type_ (Literal['output_text'] | Unset):  Default: 'output_text'.
            annotations (list[ResponsesAPIOutputTextAnnotationsItem] | Unset):
     """

    text: str
    type_: Literal['output_text'] | Unset = 'output_text'
    annotations: list[ResponsesAPIOutputTextAnnotationsItem] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.responses_api_output_text_annotations_item import ResponsesAPIOutputTextAnnotationsItem
        text = self.text

        type_ = self.type_

        annotations: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.annotations, Unset):
            annotations = []
            for annotations_item_data in self.annotations:
                annotations_item = annotations_item_data.to_dict()
                annotations.append(annotations_item)




        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "text": text,
        })
        if type_ is not UNSET:
            field_dict["type"] = type_
        if annotations is not UNSET:
            field_dict["annotations"] = annotations

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.responses_api_output_text_annotations_item import ResponsesAPIOutputTextAnnotationsItem
        d = dict(src_dict)
        text = d.pop("text")

        type_ = cast(Literal['output_text'] | Unset , d.pop("type", UNSET))
        if type_ != 'output_text'and not isinstance(type_, Unset):
            raise ValueError(f"type must match const 'output_text', got '{type_}'")

        _annotations = d.pop("annotations", UNSET)
        annotations: list[ResponsesAPIOutputTextAnnotationsItem] | Unset = UNSET
        if _annotations is not UNSET:
            annotations = []
            for annotations_item_data in _annotations:
                annotations_item = ResponsesAPIOutputTextAnnotationsItem.from_dict(annotations_item_data)



                annotations.append(annotations_item)


        responses_api_output_text = cls(
            text=text,
            type_=type_,
            annotations=annotations,
        )


        responses_api_output_text.additional_properties = d
        return responses_api_output_text

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
