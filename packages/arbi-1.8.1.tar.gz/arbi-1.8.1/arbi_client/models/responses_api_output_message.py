from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.responses_api_output_message_status import ResponsesAPIOutputMessageStatus
from ..types import UNSET, Unset
from typing import cast
from typing import Literal, cast

if TYPE_CHECKING:
  from ..models.responses_api_output_message_content_item_type_1 import ResponsesAPIOutputMessageContentItemType1
  from ..models.responses_api_output_text import ResponsesAPIOutputText





T = TypeVar("T", bound="ResponsesAPIOutputMessage")



@_attrs_define
class ResponsesAPIOutputMessage:
    """ Message output item.

        Attributes:
            id (str):
            status (ResponsesAPIOutputMessageStatus):
            type_ (Literal['message'] | Unset):  Default: 'message'.
            role (Literal['assistant'] | Unset):  Default: 'assistant'.
            content (list[ResponsesAPIOutputMessageContentItemType1 | ResponsesAPIOutputText] | Unset):
     """

    id: str
    status: ResponsesAPIOutputMessageStatus
    type_: Literal['message'] | Unset = 'message'
    role: Literal['assistant'] | Unset = 'assistant'
    content: list[ResponsesAPIOutputMessageContentItemType1 | ResponsesAPIOutputText] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.responses_api_output_message_content_item_type_1 import ResponsesAPIOutputMessageContentItemType1
        from ..models.responses_api_output_text import ResponsesAPIOutputText
        id = self.id

        status = self.status.value

        type_ = self.type_

        role = self.role

        content: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.content, Unset):
            content = []
            for content_item_data in self.content:
                content_item: dict[str, Any]
                if isinstance(content_item_data, ResponsesAPIOutputText):
                    content_item = content_item_data.to_dict()
                else:
                    content_item = content_item_data.to_dict()

                content.append(content_item)




        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "id": id,
            "status": status,
        })
        if type_ is not UNSET:
            field_dict["type"] = type_
        if role is not UNSET:
            field_dict["role"] = role
        if content is not UNSET:
            field_dict["content"] = content

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.responses_api_output_message_content_item_type_1 import ResponsesAPIOutputMessageContentItemType1
        from ..models.responses_api_output_text import ResponsesAPIOutputText
        d = dict(src_dict)
        id = d.pop("id")

        status = ResponsesAPIOutputMessageStatus(d.pop("status"))




        type_ = cast(Literal['message'] | Unset , d.pop("type", UNSET))
        if type_ != 'message'and not isinstance(type_, Unset):
            raise ValueError(f"type must match const 'message', got '{type_}'")

        role = cast(Literal['assistant'] | Unset , d.pop("role", UNSET))
        if role != 'assistant'and not isinstance(role, Unset):
            raise ValueError(f"role must match const 'assistant', got '{role}'")

        _content = d.pop("content", UNSET)
        content: list[ResponsesAPIOutputMessageContentItemType1 | ResponsesAPIOutputText] | Unset = UNSET
        if _content is not UNSET:
            content = []
            for content_item_data in _content:
                def _parse_content_item(data: object) -> ResponsesAPIOutputMessageContentItemType1 | ResponsesAPIOutputText:
                    try:
                        if not isinstance(data, dict):
                            raise TypeError()
                        content_item_type_0 = ResponsesAPIOutputText.from_dict(data)



                        return content_item_type_0
                    except (TypeError, ValueError, AttributeError, KeyError):
                        pass
                    if not isinstance(data, dict):
                        raise TypeError()
                    content_item_type_1 = ResponsesAPIOutputMessageContentItemType1.from_dict(data)



                    return content_item_type_1

                content_item = _parse_content_item(content_item_data)

                content.append(content_item)


        responses_api_output_message = cls(
            id=id,
            status=status,
            type_=type_,
            role=role,
            content=content,
        )


        responses_api_output_message.additional_properties = d
        return responses_api_output_message

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
