from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast
from typing import Literal, cast

if TYPE_CHECKING:
  from ..models.output_message import OutputMessage





T = TypeVar("T", bound="ResponseOutputItemDoneEvent")



@_attrs_define
class ResponseOutputItemDoneEvent:
    """ OpenAI response.output_item.done: completed output message with full content.

        Attributes:
            sequence_number (int): Monotonic sequence number for event ordering
            item (OutputMessage): A single output message entry in a response.
            type_ (Literal['response.output_item.done'] | Unset):  Default: 'response.output_item.done'.
            output_index (int | Unset):  Default: 0.
     """

    sequence_number: int
    item: OutputMessage
    type_: Literal['response.output_item.done'] | Unset = 'response.output_item.done'
    output_index: int | Unset = 0
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.output_message import OutputMessage
        sequence_number = self.sequence_number

        item = self.item.to_dict()

        type_ = self.type_

        output_index = self.output_index


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "sequence_number": sequence_number,
            "item": item,
        })
        if type_ is not UNSET:
            field_dict["type"] = type_
        if output_index is not UNSET:
            field_dict["output_index"] = output_index

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.output_message import OutputMessage
        d = dict(src_dict)
        sequence_number = d.pop("sequence_number")

        item = OutputMessage.from_dict(d.pop("item"))




        type_ = cast(Literal['response.output_item.done'] | Unset , d.pop("type", UNSET))
        if type_ != 'response.output_item.done'and not isinstance(type_, Unset):
            raise ValueError(f"type must match const 'response.output_item.done', got '{type_}'")

        output_index = d.pop("output_index", UNSET)

        response_output_item_done_event = cls(
            sequence_number=sequence_number,
            item=item,
            type_=type_,
            output_index=output_index,
        )


        response_output_item_done_event.additional_properties = d
        return response_output_item_done_event

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
