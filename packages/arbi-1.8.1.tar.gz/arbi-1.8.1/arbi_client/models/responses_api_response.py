from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.responses_api_response_status import ResponsesAPIResponseStatus
from ..types import UNSET, Unset
from typing import cast
from typing import Literal, cast

if TYPE_CHECKING:
  from ..models.responses_api_output_message import ResponsesAPIOutputMessage
  from ..models.responses_api_response_error_type_0 import ResponsesAPIResponseErrorType0
  from ..models.responses_api_response_metadata_type_0 import ResponsesAPIResponseMetadataType0
  from ..models.responses_api_usage import ResponsesAPIUsage





T = TypeVar("T", bound="ResponsesAPIResponse")



@_attrs_define
class ResponsesAPIResponse:
    """ OpenAI Responses API response envelope.

        Attributes:
            id (str):
            status (ResponsesAPIResponseStatus):
            object_ (Literal['response'] | Unset):  Default: 'response'.
            created_at (int | None | Unset):
            model (None | str | Unset):
            background (bool | Unset):  Default: False.
            output (list[ResponsesAPIOutputMessage] | Unset):
            usage (None | ResponsesAPIUsage | Unset):
            error (None | ResponsesAPIResponseErrorType0 | Unset):
            metadata (None | ResponsesAPIResponseMetadataType0 | Unset):
     """

    id: str
    status: ResponsesAPIResponseStatus
    object_: Literal['response'] | Unset = 'response'
    created_at: int | None | Unset = UNSET
    model: None | str | Unset = UNSET
    background: bool | Unset = False
    output: list[ResponsesAPIOutputMessage] | Unset = UNSET
    usage: None | ResponsesAPIUsage | Unset = UNSET
    error: None | ResponsesAPIResponseErrorType0 | Unset = UNSET
    metadata: None | ResponsesAPIResponseMetadataType0 | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.responses_api_response_error_type_0 import ResponsesAPIResponseErrorType0
        from ..models.responses_api_usage import ResponsesAPIUsage
        from ..models.responses_api_output_message import ResponsesAPIOutputMessage
        from ..models.responses_api_response_metadata_type_0 import ResponsesAPIResponseMetadataType0
        id = self.id

        status = self.status.value

        object_ = self.object_

        created_at: int | None | Unset
        if isinstance(self.created_at, Unset):
            created_at = UNSET
        else:
            created_at = self.created_at

        model: None | str | Unset
        if isinstance(self.model, Unset):
            model = UNSET
        else:
            model = self.model

        background = self.background

        output: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.output, Unset):
            output = []
            for output_item_data in self.output:
                output_item = output_item_data.to_dict()
                output.append(output_item)



        usage: dict[str, Any] | None | Unset
        if isinstance(self.usage, Unset):
            usage = UNSET
        elif isinstance(self.usage, ResponsesAPIUsage):
            usage = self.usage.to_dict()
        else:
            usage = self.usage

        error: dict[str, Any] | None | Unset
        if isinstance(self.error, Unset):
            error = UNSET
        elif isinstance(self.error, ResponsesAPIResponseErrorType0):
            error = self.error.to_dict()
        else:
            error = self.error

        metadata: dict[str, Any] | None | Unset
        if isinstance(self.metadata, Unset):
            metadata = UNSET
        elif isinstance(self.metadata, ResponsesAPIResponseMetadataType0):
            metadata = self.metadata.to_dict()
        else:
            metadata = self.metadata


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "id": id,
            "status": status,
        })
        if object_ is not UNSET:
            field_dict["object"] = object_
        if created_at is not UNSET:
            field_dict["created_at"] = created_at
        if model is not UNSET:
            field_dict["model"] = model
        if background is not UNSET:
            field_dict["background"] = background
        if output is not UNSET:
            field_dict["output"] = output
        if usage is not UNSET:
            field_dict["usage"] = usage
        if error is not UNSET:
            field_dict["error"] = error
        if metadata is not UNSET:
            field_dict["metadata"] = metadata

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.responses_api_output_message import ResponsesAPIOutputMessage
        from ..models.responses_api_response_error_type_0 import ResponsesAPIResponseErrorType0
        from ..models.responses_api_response_metadata_type_0 import ResponsesAPIResponseMetadataType0
        from ..models.responses_api_usage import ResponsesAPIUsage
        d = dict(src_dict)
        id = d.pop("id")

        status = ResponsesAPIResponseStatus(d.pop("status"))




        object_ = cast(Literal['response'] | Unset , d.pop("object", UNSET))
        if object_ != 'response'and not isinstance(object_, Unset):
            raise ValueError(f"object must match const 'response', got '{object_}'")

        def _parse_created_at(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        created_at = _parse_created_at(d.pop("created_at", UNSET))


        def _parse_model(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        model = _parse_model(d.pop("model", UNSET))


        background = d.pop("background", UNSET)

        _output = d.pop("output", UNSET)
        output: list[ResponsesAPIOutputMessage] | Unset = UNSET
        if _output is not UNSET:
            output = []
            for output_item_data in _output:
                output_item = ResponsesAPIOutputMessage.from_dict(output_item_data)



                output.append(output_item)


        def _parse_usage(data: object) -> None | ResponsesAPIUsage | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                usage_type_0 = ResponsesAPIUsage.from_dict(data)



                return usage_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | ResponsesAPIUsage | Unset, data)

        usage = _parse_usage(d.pop("usage", UNSET))


        def _parse_error(data: object) -> None | ResponsesAPIResponseErrorType0 | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                error_type_0 = ResponsesAPIResponseErrorType0.from_dict(data)



                return error_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | ResponsesAPIResponseErrorType0 | Unset, data)

        error = _parse_error(d.pop("error", UNSET))


        def _parse_metadata(data: object) -> None | ResponsesAPIResponseMetadataType0 | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                metadata_type_0 = ResponsesAPIResponseMetadataType0.from_dict(data)



                return metadata_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | ResponsesAPIResponseMetadataType0 | Unset, data)

        metadata = _parse_metadata(d.pop("metadata", UNSET))


        responses_api_response = cls(
            id=id,
            status=status,
            object_=object_,
            created_at=created_at,
            model=model,
            background=background,
            output=output,
            usage=usage,
            error=error,
            metadata=metadata,
        )


        responses_api_response.additional_properties = d
        return responses_api_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
