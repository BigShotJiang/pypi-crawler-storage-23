from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.user_message_event_role import UserMessageEventRole
from ..types import UNSET, Unset
from dateutil.parser import isoparse
from typing import cast
from typing import Literal, cast
import datetime

if TYPE_CHECKING:
  from ..models.user_message_event_tools import UserMessageEventTools





T = TypeVar("T", bound="UserMessageEvent")



@_attrs_define
class UserMessageEvent:
    """ ``arbi.user_message`` — saved user message echoed back at stream start.

        Attributes:
            role (UserMessageEventRole):
            content (str):
            external_id (str):
            created_at (datetime.datetime):
            created_by_ext_id (str):
            conversation_ext_id (str):
            tools (UserMessageEventTools | Unset):
            config_ext_id (None | str | Unset):
            shared (bool | Unset):  Default: False.
            tokens (int | Unset):  Default: 0.
            parent_message_ext_id (None | str | Unset):
            type_ (Literal['user_message'] | Unset):  Default: 'user_message'.
     """

    role: UserMessageEventRole
    content: str
    external_id: str
    created_at: datetime.datetime
    created_by_ext_id: str
    conversation_ext_id: str
    tools: UserMessageEventTools | Unset = UNSET
    config_ext_id: None | str | Unset = UNSET
    shared: bool | Unset = False
    tokens: int | Unset = 0
    parent_message_ext_id: None | str | Unset = UNSET
    type_: Literal['user_message'] | Unset = 'user_message'
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.user_message_event_tools import UserMessageEventTools
        role = self.role.value

        content = self.content

        external_id = self.external_id

        created_at = self.created_at.isoformat()

        created_by_ext_id = self.created_by_ext_id

        conversation_ext_id = self.conversation_ext_id

        tools: dict[str, Any] | Unset = UNSET
        if not isinstance(self.tools, Unset):
            tools = self.tools.to_dict()

        config_ext_id: None | str | Unset
        if isinstance(self.config_ext_id, Unset):
            config_ext_id = UNSET
        else:
            config_ext_id = self.config_ext_id

        shared = self.shared

        tokens = self.tokens

        parent_message_ext_id: None | str | Unset
        if isinstance(self.parent_message_ext_id, Unset):
            parent_message_ext_id = UNSET
        else:
            parent_message_ext_id = self.parent_message_ext_id

        type_ = self.type_


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "role": role,
            "content": content,
            "external_id": external_id,
            "created_at": created_at,
            "created_by_ext_id": created_by_ext_id,
            "conversation_ext_id": conversation_ext_id,
        })
        if tools is not UNSET:
            field_dict["tools"] = tools
        if config_ext_id is not UNSET:
            field_dict["config_ext_id"] = config_ext_id
        if shared is not UNSET:
            field_dict["shared"] = shared
        if tokens is not UNSET:
            field_dict["tokens"] = tokens
        if parent_message_ext_id is not UNSET:
            field_dict["parent_message_ext_id"] = parent_message_ext_id
        if type_ is not UNSET:
            field_dict["type"] = type_

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.user_message_event_tools import UserMessageEventTools
        d = dict(src_dict)
        role = UserMessageEventRole(d.pop("role"))




        content = d.pop("content")

        external_id = d.pop("external_id")

        created_at = isoparse(d.pop("created_at"))




        created_by_ext_id = d.pop("created_by_ext_id")

        conversation_ext_id = d.pop("conversation_ext_id")

        _tools = d.pop("tools", UNSET)
        tools: UserMessageEventTools | Unset
        if isinstance(_tools,  Unset):
            tools = UNSET
        else:
            tools = UserMessageEventTools.from_dict(_tools)




        def _parse_config_ext_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        config_ext_id = _parse_config_ext_id(d.pop("config_ext_id", UNSET))


        shared = d.pop("shared", UNSET)

        tokens = d.pop("tokens", UNSET)

        def _parse_parent_message_ext_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        parent_message_ext_id = _parse_parent_message_ext_id(d.pop("parent_message_ext_id", UNSET))


        type_ = cast(Literal['user_message'] | Unset , d.pop("type", UNSET))
        if type_ != 'user_message'and not isinstance(type_, Unset):
            raise ValueError(f"type must match const 'user_message', got '{type_}'")

        user_message_event = cls(
            role=role,
            content=content,
            external_id=external_id,
            created_at=created_at,
            created_by_ext_id=created_by_ext_id,
            conversation_ext_id=conversation_ext_id,
            tools=tools,
            config_ext_id=config_ext_id,
            shared=shared,
            tokens=tokens,
            parent_message_ext_id=parent_message_ext_id,
            type_=type_,
        )


        user_message_event.additional_properties = d
        return user_message_event

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
