from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast






T = TypeVar("T", bound="CopyRequest")



@_attrs_define
class CopyRequest:
    """ 
        Attributes:
            target_workspace_ext_id (str):
            target_workspace_key (str): SealedBox-encrypted target workspace key (same format as
                WorkspaceOpenRequest.workspace_key)
            items (list[str]): List of document external IDs to copy (e.g., ['doc-a1b2c3d4', 'doc-e5f6g7h8'])
     """

    target_workspace_ext_id: str
    target_workspace_key: str
    items: list[str]





    def to_dict(self) -> dict[str, Any]:
        target_workspace_ext_id = self.target_workspace_ext_id

        target_workspace_key = self.target_workspace_key

        items = self.items




        field_dict: dict[str, Any] = {}

        field_dict.update({
            "target_workspace_ext_id": target_workspace_ext_id,
            "target_workspace_key": target_workspace_key,
            "items": items,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        target_workspace_ext_id = d.pop("target_workspace_ext_id")

        target_workspace_key = d.pop("target_workspace_key")

        items = cast(list[str], d.pop("items"))


        copy_request = cls(
            target_workspace_ext_id=target_workspace_ext_id,
            target_workspace_key=target_workspace_key,
            items=items,
        )

        return copy_request

