from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import Literal, cast






T = TypeVar("T", bound="ResponseOutputTextDeltaEvent")



@_attrs_define
class ResponseOutputTextDeltaEvent:
    """ OpenAI response.output_text.delta: a chunk of the assistant's answer text.

        Attributes:
            delta (str):
            type_ (Literal['response.output_text.delta'] | Unset):  Default: 'response.output_text.delta'.
            item_id (str | Unset): ID of the parent output message Default: ''.
            output_index (int | Unset):  Default: 0.
            content_index (int | Unset):  Default: 0.
            sequence_number (int | Unset): Monotonic sequence number for event ordering Default: 0.
     """

    delta: str
    type_: Literal['response.output_text.delta'] | Unset = 'response.output_text.delta'
    item_id: str | Unset = ''
    output_index: int | Unset = 0
    content_index: int | Unset = 0
    sequence_number: int | Unset = 0
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        delta = self.delta

        type_ = self.type_

        item_id = self.item_id

        output_index = self.output_index

        content_index = self.content_index

        sequence_number = self.sequence_number


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "delta": delta,
        })
        if type_ is not UNSET:
            field_dict["type"] = type_
        if item_id is not UNSET:
            field_dict["item_id"] = item_id
        if output_index is not UNSET:
            field_dict["output_index"] = output_index
        if content_index is not UNSET:
            field_dict["content_index"] = content_index
        if sequence_number is not UNSET:
            field_dict["sequence_number"] = sequence_number

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        delta = d.pop("delta")

        type_ = cast(Literal['response.output_text.delta'] | Unset , d.pop("type", UNSET))
        if type_ != 'response.output_text.delta'and not isinstance(type_, Unset):
            raise ValueError(f"type must match const 'response.output_text.delta', got '{type_}'")

        item_id = d.pop("item_id", UNSET)

        output_index = d.pop("output_index", UNSET)

        content_index = d.pop("content_index", UNSET)

        sequence_number = d.pop("sequence_number", UNSET)

        response_output_text_delta_event = cls(
            delta=delta,
            type_=type_,
            item_id=item_id,
            output_index=output_index,
            content_index=content_index,
            sequence_number=sequence_number,
        )


        response_output_text_delta_event.additional_properties = d
        return response_output_text_delta_event

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
