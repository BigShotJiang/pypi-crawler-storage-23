from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.chat_completion_request_logit_bias_type_0 import ChatCompletionRequestLogitBiasType0
  from ..models.chat_completion_request_messages_item import ChatCompletionRequestMessagesItem
  from ..models.chat_completion_request_metadata_type_0 import ChatCompletionRequestMetadataType0
  from ..models.chat_completion_request_response_format_type_0 import ChatCompletionRequestResponseFormatType0
  from ..models.chat_completion_request_stream_options_type_0 import ChatCompletionRequestStreamOptionsType0
  from ..models.chat_completion_request_tool_choice_type_1 import ChatCompletionRequestToolChoiceType1
  from ..models.chat_completion_request_tools_type_0_item import ChatCompletionRequestToolsType0Item





T = TypeVar("T", bound="ChatCompletionRequest")



@_attrs_define
class ChatCompletionRequest:
    """ OpenAI-compatible chat completion request.

        Attributes:
            model (str):
            messages (list[ChatCompletionRequestMessagesItem]):
            stream (bool | Unset):  Default: False.
            temperature (float | None | Unset):
            max_tokens (int | None | Unset):
            max_completion_tokens (int | None | Unset):
            top_p (float | None | Unset):
            n (int | None | Unset):
            stop (list[str] | None | str | Unset):
            presence_penalty (float | None | Unset):
            frequency_penalty (float | None | Unset):
            logit_bias (ChatCompletionRequestLogitBiasType0 | None | Unset):
            logprobs (bool | None | Unset):
            top_logprobs (int | None | Unset):
            seed (int | None | Unset):
            user (None | str | Unset):
            tools (list[ChatCompletionRequestToolsType0Item] | None | Unset):
            tool_choice (ChatCompletionRequestToolChoiceType1 | None | str | Unset):
            parallel_tool_calls (bool | None | Unset):
            response_format (ChatCompletionRequestResponseFormatType0 | None | Unset):
            stream_options (ChatCompletionRequestStreamOptionsType0 | None | Unset):
            service_tier (None | str | Unset):
            store (bool | None | Unset):
            metadata (ChatCompletionRequestMetadataType0 | None | Unset):
     """

    model: str
    messages: list[ChatCompletionRequestMessagesItem]
    stream: bool | Unset = False
    temperature: float | None | Unset = UNSET
    max_tokens: int | None | Unset = UNSET
    max_completion_tokens: int | None | Unset = UNSET
    top_p: float | None | Unset = UNSET
    n: int | None | Unset = UNSET
    stop: list[str] | None | str | Unset = UNSET
    presence_penalty: float | None | Unset = UNSET
    frequency_penalty: float | None | Unset = UNSET
    logit_bias: ChatCompletionRequestLogitBiasType0 | None | Unset = UNSET
    logprobs: bool | None | Unset = UNSET
    top_logprobs: int | None | Unset = UNSET
    seed: int | None | Unset = UNSET
    user: None | str | Unset = UNSET
    tools: list[ChatCompletionRequestToolsType0Item] | None | Unset = UNSET
    tool_choice: ChatCompletionRequestToolChoiceType1 | None | str | Unset = UNSET
    parallel_tool_calls: bool | None | Unset = UNSET
    response_format: ChatCompletionRequestResponseFormatType0 | None | Unset = UNSET
    stream_options: ChatCompletionRequestStreamOptionsType0 | None | Unset = UNSET
    service_tier: None | str | Unset = UNSET
    store: bool | None | Unset = UNSET
    metadata: ChatCompletionRequestMetadataType0 | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.chat_completion_request_stream_options_type_0 import ChatCompletionRequestStreamOptionsType0
        from ..models.chat_completion_request_logit_bias_type_0 import ChatCompletionRequestLogitBiasType0
        from ..models.chat_completion_request_response_format_type_0 import ChatCompletionRequestResponseFormatType0
        from ..models.chat_completion_request_messages_item import ChatCompletionRequestMessagesItem
        from ..models.chat_completion_request_tool_choice_type_1 import ChatCompletionRequestToolChoiceType1
        from ..models.chat_completion_request_tools_type_0_item import ChatCompletionRequestToolsType0Item
        from ..models.chat_completion_request_metadata_type_0 import ChatCompletionRequestMetadataType0
        model = self.model

        messages = []
        for messages_item_data in self.messages:
            messages_item = messages_item_data.to_dict()
            messages.append(messages_item)



        stream = self.stream

        temperature: float | None | Unset
        if isinstance(self.temperature, Unset):
            temperature = UNSET
        else:
            temperature = self.temperature

        max_tokens: int | None | Unset
        if isinstance(self.max_tokens, Unset):
            max_tokens = UNSET
        else:
            max_tokens = self.max_tokens

        max_completion_tokens: int | None | Unset
        if isinstance(self.max_completion_tokens, Unset):
            max_completion_tokens = UNSET
        else:
            max_completion_tokens = self.max_completion_tokens

        top_p: float | None | Unset
        if isinstance(self.top_p, Unset):
            top_p = UNSET
        else:
            top_p = self.top_p

        n: int | None | Unset
        if isinstance(self.n, Unset):
            n = UNSET
        else:
            n = self.n

        stop: list[str] | None | str | Unset
        if isinstance(self.stop, Unset):
            stop = UNSET
        elif isinstance(self.stop, list):
            stop = self.stop


        else:
            stop = self.stop

        presence_penalty: float | None | Unset
        if isinstance(self.presence_penalty, Unset):
            presence_penalty = UNSET
        else:
            presence_penalty = self.presence_penalty

        frequency_penalty: float | None | Unset
        if isinstance(self.frequency_penalty, Unset):
            frequency_penalty = UNSET
        else:
            frequency_penalty = self.frequency_penalty

        logit_bias: dict[str, Any] | None | Unset
        if isinstance(self.logit_bias, Unset):
            logit_bias = UNSET
        elif isinstance(self.logit_bias, ChatCompletionRequestLogitBiasType0):
            logit_bias = self.logit_bias.to_dict()
        else:
            logit_bias = self.logit_bias

        logprobs: bool | None | Unset
        if isinstance(self.logprobs, Unset):
            logprobs = UNSET
        else:
            logprobs = self.logprobs

        top_logprobs: int | None | Unset
        if isinstance(self.top_logprobs, Unset):
            top_logprobs = UNSET
        else:
            top_logprobs = self.top_logprobs

        seed: int | None | Unset
        if isinstance(self.seed, Unset):
            seed = UNSET
        else:
            seed = self.seed

        user: None | str | Unset
        if isinstance(self.user, Unset):
            user = UNSET
        else:
            user = self.user

        tools: list[dict[str, Any]] | None | Unset
        if isinstance(self.tools, Unset):
            tools = UNSET
        elif isinstance(self.tools, list):
            tools = []
            for tools_type_0_item_data in self.tools:
                tools_type_0_item = tools_type_0_item_data.to_dict()
                tools.append(tools_type_0_item)


        else:
            tools = self.tools

        tool_choice: dict[str, Any] | None | str | Unset
        if isinstance(self.tool_choice, Unset):
            tool_choice = UNSET
        elif isinstance(self.tool_choice, ChatCompletionRequestToolChoiceType1):
            tool_choice = self.tool_choice.to_dict()
        else:
            tool_choice = self.tool_choice

        parallel_tool_calls: bool | None | Unset
        if isinstance(self.parallel_tool_calls, Unset):
            parallel_tool_calls = UNSET
        else:
            parallel_tool_calls = self.parallel_tool_calls

        response_format: dict[str, Any] | None | Unset
        if isinstance(self.response_format, Unset):
            response_format = UNSET
        elif isinstance(self.response_format, ChatCompletionRequestResponseFormatType0):
            response_format = self.response_format.to_dict()
        else:
            response_format = self.response_format

        stream_options: dict[str, Any] | None | Unset
        if isinstance(self.stream_options, Unset):
            stream_options = UNSET
        elif isinstance(self.stream_options, ChatCompletionRequestStreamOptionsType0):
            stream_options = self.stream_options.to_dict()
        else:
            stream_options = self.stream_options

        service_tier: None | str | Unset
        if isinstance(self.service_tier, Unset):
            service_tier = UNSET
        else:
            service_tier = self.service_tier

        store: bool | None | Unset
        if isinstance(self.store, Unset):
            store = UNSET
        else:
            store = self.store

        metadata: dict[str, Any] | None | Unset
        if isinstance(self.metadata, Unset):
            metadata = UNSET
        elif isinstance(self.metadata, ChatCompletionRequestMetadataType0):
            metadata = self.metadata.to_dict()
        else:
            metadata = self.metadata


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "model": model,
            "messages": messages,
        })
        if stream is not UNSET:
            field_dict["stream"] = stream
        if temperature is not UNSET:
            field_dict["temperature"] = temperature
        if max_tokens is not UNSET:
            field_dict["max_tokens"] = max_tokens
        if max_completion_tokens is not UNSET:
            field_dict["max_completion_tokens"] = max_completion_tokens
        if top_p is not UNSET:
            field_dict["top_p"] = top_p
        if n is not UNSET:
            field_dict["n"] = n
        if stop is not UNSET:
            field_dict["stop"] = stop
        if presence_penalty is not UNSET:
            field_dict["presence_penalty"] = presence_penalty
        if frequency_penalty is not UNSET:
            field_dict["frequency_penalty"] = frequency_penalty
        if logit_bias is not UNSET:
            field_dict["logit_bias"] = logit_bias
        if logprobs is not UNSET:
            field_dict["logprobs"] = logprobs
        if top_logprobs is not UNSET:
            field_dict["top_logprobs"] = top_logprobs
        if seed is not UNSET:
            field_dict["seed"] = seed
        if user is not UNSET:
            field_dict["user"] = user
        if tools is not UNSET:
            field_dict["tools"] = tools
        if tool_choice is not UNSET:
            field_dict["tool_choice"] = tool_choice
        if parallel_tool_calls is not UNSET:
            field_dict["parallel_tool_calls"] = parallel_tool_calls
        if response_format is not UNSET:
            field_dict["response_format"] = response_format
        if stream_options is not UNSET:
            field_dict["stream_options"] = stream_options
        if service_tier is not UNSET:
            field_dict["service_tier"] = service_tier
        if store is not UNSET:
            field_dict["store"] = store
        if metadata is not UNSET:
            field_dict["metadata"] = metadata

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.chat_completion_request_logit_bias_type_0 import ChatCompletionRequestLogitBiasType0
        from ..models.chat_completion_request_messages_item import ChatCompletionRequestMessagesItem
        from ..models.chat_completion_request_metadata_type_0 import ChatCompletionRequestMetadataType0
        from ..models.chat_completion_request_response_format_type_0 import ChatCompletionRequestResponseFormatType0
        from ..models.chat_completion_request_stream_options_type_0 import ChatCompletionRequestStreamOptionsType0
        from ..models.chat_completion_request_tool_choice_type_1 import ChatCompletionRequestToolChoiceType1
        from ..models.chat_completion_request_tools_type_0_item import ChatCompletionRequestToolsType0Item
        d = dict(src_dict)
        model = d.pop("model")

        messages = []
        _messages = d.pop("messages")
        for messages_item_data in (_messages):
            messages_item = ChatCompletionRequestMessagesItem.from_dict(messages_item_data)



            messages.append(messages_item)


        stream = d.pop("stream", UNSET)

        def _parse_temperature(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        temperature = _parse_temperature(d.pop("temperature", UNSET))


        def _parse_max_tokens(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        max_tokens = _parse_max_tokens(d.pop("max_tokens", UNSET))


        def _parse_max_completion_tokens(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        max_completion_tokens = _parse_max_completion_tokens(d.pop("max_completion_tokens", UNSET))


        def _parse_top_p(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        top_p = _parse_top_p(d.pop("top_p", UNSET))


        def _parse_n(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        n = _parse_n(d.pop("n", UNSET))


        def _parse_stop(data: object) -> list[str] | None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                stop_type_1 = cast(list[str], data)

                return stop_type_1
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[str] | None | str | Unset, data)

        stop = _parse_stop(d.pop("stop", UNSET))


        def _parse_presence_penalty(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        presence_penalty = _parse_presence_penalty(d.pop("presence_penalty", UNSET))


        def _parse_frequency_penalty(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        frequency_penalty = _parse_frequency_penalty(d.pop("frequency_penalty", UNSET))


        def _parse_logit_bias(data: object) -> ChatCompletionRequestLogitBiasType0 | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                logit_bias_type_0 = ChatCompletionRequestLogitBiasType0.from_dict(data)



                return logit_bias_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(ChatCompletionRequestLogitBiasType0 | None | Unset, data)

        logit_bias = _parse_logit_bias(d.pop("logit_bias", UNSET))


        def _parse_logprobs(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        logprobs = _parse_logprobs(d.pop("logprobs", UNSET))


        def _parse_top_logprobs(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        top_logprobs = _parse_top_logprobs(d.pop("top_logprobs", UNSET))


        def _parse_seed(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        seed = _parse_seed(d.pop("seed", UNSET))


        def _parse_user(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        user = _parse_user(d.pop("user", UNSET))


        def _parse_tools(data: object) -> list[ChatCompletionRequestToolsType0Item] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                tools_type_0 = []
                _tools_type_0 = data
                for tools_type_0_item_data in (_tools_type_0):
                    tools_type_0_item = ChatCompletionRequestToolsType0Item.from_dict(tools_type_0_item_data)



                    tools_type_0.append(tools_type_0_item)

                return tools_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[ChatCompletionRequestToolsType0Item] | None | Unset, data)

        tools = _parse_tools(d.pop("tools", UNSET))


        def _parse_tool_choice(data: object) -> ChatCompletionRequestToolChoiceType1 | None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                tool_choice_type_1 = ChatCompletionRequestToolChoiceType1.from_dict(data)



                return tool_choice_type_1
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(ChatCompletionRequestToolChoiceType1 | None | str | Unset, data)

        tool_choice = _parse_tool_choice(d.pop("tool_choice", UNSET))


        def _parse_parallel_tool_calls(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        parallel_tool_calls = _parse_parallel_tool_calls(d.pop("parallel_tool_calls", UNSET))


        def _parse_response_format(data: object) -> ChatCompletionRequestResponseFormatType0 | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                response_format_type_0 = ChatCompletionRequestResponseFormatType0.from_dict(data)



                return response_format_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(ChatCompletionRequestResponseFormatType0 | None | Unset, data)

        response_format = _parse_response_format(d.pop("response_format", UNSET))


        def _parse_stream_options(data: object) -> ChatCompletionRequestStreamOptionsType0 | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                stream_options_type_0 = ChatCompletionRequestStreamOptionsType0.from_dict(data)



                return stream_options_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(ChatCompletionRequestStreamOptionsType0 | None | Unset, data)

        stream_options = _parse_stream_options(d.pop("stream_options", UNSET))


        def _parse_service_tier(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        service_tier = _parse_service_tier(d.pop("service_tier", UNSET))


        def _parse_store(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        store = _parse_store(d.pop("store", UNSET))


        def _parse_metadata(data: object) -> ChatCompletionRequestMetadataType0 | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                metadata_type_0 = ChatCompletionRequestMetadataType0.from_dict(data)



                return metadata_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(ChatCompletionRequestMetadataType0 | None | Unset, data)

        metadata = _parse_metadata(d.pop("metadata", UNSET))


        chat_completion_request = cls(
            model=model,
            messages=messages,
            stream=stream,
            temperature=temperature,
            max_tokens=max_tokens,
            max_completion_tokens=max_completion_tokens,
            top_p=top_p,
            n=n,
            stop=stop,
            presence_penalty=presence_penalty,
            frequency_penalty=frequency_penalty,
            logit_bias=logit_bias,
            logprobs=logprobs,
            top_logprobs=top_logprobs,
            seed=seed,
            user=user,
            tools=tools,
            tool_choice=tool_choice,
            parallel_tool_calls=parallel_tool_calls,
            response_format=response_format,
            stream_options=stream_options,
            service_tier=service_tier,
            store=store,
            metadata=metadata,
        )


        chat_completion_request.additional_properties = d
        return chat_completion_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
