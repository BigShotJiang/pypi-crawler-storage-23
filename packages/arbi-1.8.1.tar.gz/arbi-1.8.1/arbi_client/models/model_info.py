from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast






T = TypeVar("T", bound="ModelInfo")



@_attrs_define
class ModelInfo:
    """ 
        Attributes:
            model_name (str):
            api_type (str):
            tags (list[str] | None | Unset):
            max_input_tokens (int | None | Unset):
            max_output_tokens (int | None | Unset):
            input_cost_per_token (float | None | Unset):
            output_cost_per_token (float | None | Unset):
            provider (None | str | Unset):
            mode (None | str | Unset):
            supports_vision (bool | None | Unset):
            supports_reasoning (bool | None | Unset):
            supports_function_calling (bool | None | Unset):
            supports_response_schema (bool | None | Unset):
     """

    model_name: str
    api_type: str
    tags: list[str] | None | Unset = UNSET
    max_input_tokens: int | None | Unset = UNSET
    max_output_tokens: int | None | Unset = UNSET
    input_cost_per_token: float | None | Unset = UNSET
    output_cost_per_token: float | None | Unset = UNSET
    provider: None | str | Unset = UNSET
    mode: None | str | Unset = UNSET
    supports_vision: bool | None | Unset = UNSET
    supports_reasoning: bool | None | Unset = UNSET
    supports_function_calling: bool | None | Unset = UNSET
    supports_response_schema: bool | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        model_name = self.model_name

        api_type = self.api_type

        tags: list[str] | None | Unset
        if isinstance(self.tags, Unset):
            tags = UNSET
        elif isinstance(self.tags, list):
            tags = self.tags


        else:
            tags = self.tags

        max_input_tokens: int | None | Unset
        if isinstance(self.max_input_tokens, Unset):
            max_input_tokens = UNSET
        else:
            max_input_tokens = self.max_input_tokens

        max_output_tokens: int | None | Unset
        if isinstance(self.max_output_tokens, Unset):
            max_output_tokens = UNSET
        else:
            max_output_tokens = self.max_output_tokens

        input_cost_per_token: float | None | Unset
        if isinstance(self.input_cost_per_token, Unset):
            input_cost_per_token = UNSET
        else:
            input_cost_per_token = self.input_cost_per_token

        output_cost_per_token: float | None | Unset
        if isinstance(self.output_cost_per_token, Unset):
            output_cost_per_token = UNSET
        else:
            output_cost_per_token = self.output_cost_per_token

        provider: None | str | Unset
        if isinstance(self.provider, Unset):
            provider = UNSET
        else:
            provider = self.provider

        mode: None | str | Unset
        if isinstance(self.mode, Unset):
            mode = UNSET
        else:
            mode = self.mode

        supports_vision: bool | None | Unset
        if isinstance(self.supports_vision, Unset):
            supports_vision = UNSET
        else:
            supports_vision = self.supports_vision

        supports_reasoning: bool | None | Unset
        if isinstance(self.supports_reasoning, Unset):
            supports_reasoning = UNSET
        else:
            supports_reasoning = self.supports_reasoning

        supports_function_calling: bool | None | Unset
        if isinstance(self.supports_function_calling, Unset):
            supports_function_calling = UNSET
        else:
            supports_function_calling = self.supports_function_calling

        supports_response_schema: bool | None | Unset
        if isinstance(self.supports_response_schema, Unset):
            supports_response_schema = UNSET
        else:
            supports_response_schema = self.supports_response_schema


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "model_name": model_name,
            "api_type": api_type,
        })
        if tags is not UNSET:
            field_dict["tags"] = tags
        if max_input_tokens is not UNSET:
            field_dict["max_input_tokens"] = max_input_tokens
        if max_output_tokens is not UNSET:
            field_dict["max_output_tokens"] = max_output_tokens
        if input_cost_per_token is not UNSET:
            field_dict["input_cost_per_token"] = input_cost_per_token
        if output_cost_per_token is not UNSET:
            field_dict["output_cost_per_token"] = output_cost_per_token
        if provider is not UNSET:
            field_dict["provider"] = provider
        if mode is not UNSET:
            field_dict["mode"] = mode
        if supports_vision is not UNSET:
            field_dict["supports_vision"] = supports_vision
        if supports_reasoning is not UNSET:
            field_dict["supports_reasoning"] = supports_reasoning
        if supports_function_calling is not UNSET:
            field_dict["supports_function_calling"] = supports_function_calling
        if supports_response_schema is not UNSET:
            field_dict["supports_response_schema"] = supports_response_schema

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        model_name = d.pop("model_name")

        api_type = d.pop("api_type")

        def _parse_tags(data: object) -> list[str] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                tags_type_0 = cast(list[str], data)

                return tags_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[str] | None | Unset, data)

        tags = _parse_tags(d.pop("tags", UNSET))


        def _parse_max_input_tokens(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        max_input_tokens = _parse_max_input_tokens(d.pop("max_input_tokens", UNSET))


        def _parse_max_output_tokens(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        max_output_tokens = _parse_max_output_tokens(d.pop("max_output_tokens", UNSET))


        def _parse_input_cost_per_token(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        input_cost_per_token = _parse_input_cost_per_token(d.pop("input_cost_per_token", UNSET))


        def _parse_output_cost_per_token(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        output_cost_per_token = _parse_output_cost_per_token(d.pop("output_cost_per_token", UNSET))


        def _parse_provider(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        provider = _parse_provider(d.pop("provider", UNSET))


        def _parse_mode(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        mode = _parse_mode(d.pop("mode", UNSET))


        def _parse_supports_vision(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        supports_vision = _parse_supports_vision(d.pop("supports_vision", UNSET))


        def _parse_supports_reasoning(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        supports_reasoning = _parse_supports_reasoning(d.pop("supports_reasoning", UNSET))


        def _parse_supports_function_calling(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        supports_function_calling = _parse_supports_function_calling(d.pop("supports_function_calling", UNSET))


        def _parse_supports_response_schema(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        supports_response_schema = _parse_supports_response_schema(d.pop("supports_response_schema", UNSET))


        model_info = cls(
            model_name=model_name,
            api_type=api_type,
            tags=tags,
            max_input_tokens=max_input_tokens,
            max_output_tokens=max_output_tokens,
            input_cost_per_token=input_cost_per_token,
            output_cost_per_token=output_cost_per_token,
            provider=provider,
            mode=mode,
            supports_vision=supports_vision,
            supports_reasoning=supports_reasoning,
            supports_function_calling=supports_function_calling,
            supports_response_schema=supports_response_schema,
        )


        model_info.additional_properties = d
        return model_info

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
