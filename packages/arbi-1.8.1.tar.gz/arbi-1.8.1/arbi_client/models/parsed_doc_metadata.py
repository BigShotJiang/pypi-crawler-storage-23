from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast






T = TypeVar("T", bound="ParsedDocMetadata")



@_attrs_define
class ParsedDocMetadata:
    """ 
        Attributes:
            doc_ext_id (None | str | Unset):
            file_name (None | str | Unset):
            total_number_of_pages (int | Unset):  Default: 1.
            re_ocred (bool | None | Unset):
            output_mode (str | Unset):  Default: 'markdown'.
     """

    doc_ext_id: None | str | Unset = UNSET
    file_name: None | str | Unset = UNSET
    total_number_of_pages: int | Unset = 1
    re_ocred: bool | None | Unset = UNSET
    output_mode: str | Unset = 'markdown'
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        doc_ext_id: None | str | Unset
        if isinstance(self.doc_ext_id, Unset):
            doc_ext_id = UNSET
        else:
            doc_ext_id = self.doc_ext_id

        file_name: None | str | Unset
        if isinstance(self.file_name, Unset):
            file_name = UNSET
        else:
            file_name = self.file_name

        total_number_of_pages = self.total_number_of_pages

        re_ocred: bool | None | Unset
        if isinstance(self.re_ocred, Unset):
            re_ocred = UNSET
        else:
            re_ocred = self.re_ocred

        output_mode = self.output_mode


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if doc_ext_id is not UNSET:
            field_dict["doc_ext_id"] = doc_ext_id
        if file_name is not UNSET:
            field_dict["file_name"] = file_name
        if total_number_of_pages is not UNSET:
            field_dict["total_number_of_pages"] = total_number_of_pages
        if re_ocred is not UNSET:
            field_dict["re_ocred"] = re_ocred
        if output_mode is not UNSET:
            field_dict["output_mode"] = output_mode

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        def _parse_doc_ext_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        doc_ext_id = _parse_doc_ext_id(d.pop("doc_ext_id", UNSET))


        def _parse_file_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        file_name = _parse_file_name(d.pop("file_name", UNSET))


        total_number_of_pages = d.pop("total_number_of_pages", UNSET)

        def _parse_re_ocred(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        re_ocred = _parse_re_ocred(d.pop("re_ocred", UNSET))


        output_mode = d.pop("output_mode", UNSET)

        parsed_doc_metadata = cls(
            doc_ext_id=doc_ext_id,
            file_name=file_name,
            total_number_of_pages=total_number_of_pages,
            re_ocred=re_ocred,
            output_mode=output_mode,
        )


        parsed_doc_metadata.additional_properties = d
        return parsed_doc_metadata

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
