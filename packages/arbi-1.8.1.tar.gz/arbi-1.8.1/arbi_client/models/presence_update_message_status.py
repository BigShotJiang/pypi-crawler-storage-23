from enum import Enum

class PresenceUpdateMessageStatus(str, Enum):
    ONLINE = "online"
    UNKNOWN = "unknown"

    def __str__(self) -> str:
        return str(self.value)
