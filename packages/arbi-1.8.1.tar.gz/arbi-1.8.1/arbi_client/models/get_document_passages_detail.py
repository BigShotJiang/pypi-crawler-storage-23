from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import Literal, cast






T = TypeVar("T", bound="GetDocumentPassagesDetail")



@_attrs_define
class GetDocumentPassagesDetail:
    """ Detail for a get_document_passages tool call.

        Attributes:
            doc_ext_id (str): Document external ID
            from_ref (str): Start reference (page.chunk)
            to_ref (str): End reference (page.chunk)
            tool (Literal['get_document_passages'] | Unset):  Default: 'get_document_passages'.
     """

    doc_ext_id: str
    from_ref: str
    to_ref: str
    tool: Literal['get_document_passages'] | Unset = 'get_document_passages'
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        doc_ext_id = self.doc_ext_id

        from_ref = self.from_ref

        to_ref = self.to_ref

        tool = self.tool


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "doc_ext_id": doc_ext_id,
            "from_ref": from_ref,
            "to_ref": to_ref,
        })
        if tool is not UNSET:
            field_dict["tool"] = tool

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        doc_ext_id = d.pop("doc_ext_id")

        from_ref = d.pop("from_ref")

        to_ref = d.pop("to_ref")

        tool = cast(Literal['get_document_passages'] | Unset , d.pop("tool", UNSET))
        if tool != 'get_document_passages'and not isinstance(tool, Unset):
            raise ValueError(f"tool must match const 'get_document_passages', got '{tool}'")

        get_document_passages_detail = cls(
            doc_ext_id=doc_ext_id,
            from_ref=from_ref,
            to_ref=to_ref,
            tool=tool,
        )


        get_document_passages_detail.additional_properties = d
        return get_document_passages_detail

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
