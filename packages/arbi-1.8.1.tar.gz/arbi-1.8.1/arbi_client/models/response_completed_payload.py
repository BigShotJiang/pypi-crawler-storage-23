from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast
from typing import Literal, cast

if TYPE_CHECKING:
  from ..models.message_metadata_payload import MessageMetadataPayload
  from ..models.output_message import OutputMessage
  from ..models.response_usage import ResponseUsage





T = TypeVar("T", bound="ResponseCompletedPayload")



@_attrs_define
class ResponseCompletedPayload:
    """ The ``response`` dict in a ``response.completed`` SSE event.

        Attributes:
            id (str): Response ID (assistant_message_ext_id)
            created_at (int): Unix epoch timestamp when the response was created
            model (str): Model name used for the response
            output (list[OutputMessage]): Final output messages with content
            usage (ResponseUsage): Token usage summary in a completed response (OpenAI format).
            metadata (MessageMetadataPayload): ``message_metadata`` payload within ``response.completed.response.metadata``.

                Contains the full assistant :class:`MessageResponse` plus context_usage and
                optional suggested_query.
            object_ (Literal['response'] | Unset):  Default: 'response'.
            status (Literal['completed'] | Unset):  Default: 'completed'.
     """

    id: str
    created_at: int
    model: str
    output: list[OutputMessage]
    usage: ResponseUsage
    metadata: MessageMetadataPayload
    object_: Literal['response'] | Unset = 'response'
    status: Literal['completed'] | Unset = 'completed'
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.message_metadata_payload import MessageMetadataPayload
        from ..models.response_usage import ResponseUsage
        from ..models.output_message import OutputMessage
        id = self.id

        created_at = self.created_at

        model = self.model

        output = []
        for output_item_data in self.output:
            output_item = output_item_data.to_dict()
            output.append(output_item)



        usage = self.usage.to_dict()

        metadata = self.metadata.to_dict()

        object_ = self.object_

        status = self.status


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "id": id,
            "created_at": created_at,
            "model": model,
            "output": output,
            "usage": usage,
            "metadata": metadata,
        })
        if object_ is not UNSET:
            field_dict["object"] = object_
        if status is not UNSET:
            field_dict["status"] = status

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.message_metadata_payload import MessageMetadataPayload
        from ..models.output_message import OutputMessage
        from ..models.response_usage import ResponseUsage
        d = dict(src_dict)
        id = d.pop("id")

        created_at = d.pop("created_at")

        model = d.pop("model")

        output = []
        _output = d.pop("output")
        for output_item_data in (_output):
            output_item = OutputMessage.from_dict(output_item_data)



            output.append(output_item)


        usage = ResponseUsage.from_dict(d.pop("usage"))




        metadata = MessageMetadataPayload.from_dict(d.pop("metadata"))




        object_ = cast(Literal['response'] | Unset , d.pop("object", UNSET))
        if object_ != 'response'and not isinstance(object_, Unset):
            raise ValueError(f"object must match const 'response', got '{object_}'")

        status = cast(Literal['completed'] | Unset , d.pop("status", UNSET))
        if status != 'completed'and not isinstance(status, Unset):
            raise ValueError(f"status must match const 'completed', got '{status}'")

        response_completed_payload = cls(
            id=id,
            created_at=created_at,
            model=model,
            output=output,
            usage=usage,
            metadata=metadata,
            object_=object_,
            status=status,
        )


        response_completed_payload.additional_properties = d
        return response_completed_payload

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
