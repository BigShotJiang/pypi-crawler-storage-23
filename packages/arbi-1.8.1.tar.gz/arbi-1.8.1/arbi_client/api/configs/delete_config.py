from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.config_delete_response import ConfigDeleteResponse
from ...models.http_validation_error import HTTPValidationError
from typing import cast



def _get_kwargs(
    config_ext_id: str,

) -> dict[str, Any]:
    

    

    

    _kwargs: dict[str, Any] = {
        "method": "delete",
        "url": "/v1/configs/{config_ext_id}".format(config_ext_id=quote(str(config_ext_id), safe=""),),
    }


    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> ConfigDeleteResponse | HTTPValidationError | None:
    if response.status_code == 200:
        response_200 = ConfigDeleteResponse.from_dict(response.json())



        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())



        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[ConfigDeleteResponse | HTTPValidationError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    config_ext_id: str,
    *,
    client: AuthenticatedClient | Client,

) -> Response[ConfigDeleteResponse | HTTPValidationError]:
    """ Delete Config Config Ext Id

     Delete a specific configuration from database

    Args:
        config_ext_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ConfigDeleteResponse | HTTPValidationError]
     """


    kwargs = _get_kwargs(
        config_ext_id=config_ext_id,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    config_ext_id: str,
    *,
    client: AuthenticatedClient | Client,

) -> ConfigDeleteResponse | HTTPValidationError | None:
    """ Delete Config Config Ext Id

     Delete a specific configuration from database

    Args:
        config_ext_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ConfigDeleteResponse | HTTPValidationError
     """


    return sync_detailed(
        config_ext_id=config_ext_id,
client=client,

    ).parsed

async def asyncio_detailed(
    config_ext_id: str,
    *,
    client: AuthenticatedClient | Client,

) -> Response[ConfigDeleteResponse | HTTPValidationError]:
    """ Delete Config Config Ext Id

     Delete a specific configuration from database

    Args:
        config_ext_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ConfigDeleteResponse | HTTPValidationError]
     """


    kwargs = _get_kwargs(
        config_ext_id=config_ext_id,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    config_ext_id: str,
    *,
    client: AuthenticatedClient | Client,

) -> ConfigDeleteResponse | HTTPValidationError | None:
    """ Delete Config Config Ext Id

     Delete a specific configuration from database

    Args:
        config_ext_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ConfigDeleteResponse | HTTPValidationError
     """


    return (await asyncio_detailed(
        config_ext_id=config_ext_id,
client=client,

    )).parsed
