from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.http_validation_error import HTTPValidationError
from ...models.notification_response import NotificationResponse
from ...models.update_notifications_request import UpdateNotificationsRequest
from typing import cast



def _get_kwargs(
    *,
    body: UpdateNotificationsRequest,

) -> dict[str, Any]:
    headers: dict[str, Any] = {}


    

    

    _kwargs: dict[str, Any] = {
        "method": "patch",
        "url": "/v1/notifications/",
    }

    _kwargs["json"] = body.to_dict()


    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> HTTPValidationError | list[NotificationResponse] | None:
    if response.status_code == 200:
        response_200 = []
        _response_200 = response.json()
        for response_200_item_data in (_response_200):
            response_200_item = NotificationResponse.from_dict(response_200_item_data)



            response_200.append(response_200_item)

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())



        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[HTTPValidationError | list[NotificationResponse]]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: UpdateNotificationsRequest,

) -> Response[HTTPValidationError | list[NotificationResponse]]:
    """ Update Notifications

     Bulk update notifications.

    Supports:
    - content: Re-encrypt content (sender OR recipient can do this)
    - read: Mark as read (only recipient can do this)

    Returns the updated notifications.

    Args:
        body (UpdateNotificationsRequest): Bulk update notifications.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | list[NotificationResponse]]
     """


    kwargs = _get_kwargs(
        body=body,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    *,
    client: AuthenticatedClient | Client,
    body: UpdateNotificationsRequest,

) -> HTTPValidationError | list[NotificationResponse] | None:
    """ Update Notifications

     Bulk update notifications.

    Supports:
    - content: Re-encrypt content (sender OR recipient can do this)
    - read: Mark as read (only recipient can do this)

    Returns the updated notifications.

    Args:
        body (UpdateNotificationsRequest): Bulk update notifications.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | list[NotificationResponse]
     """


    return sync_detailed(
        client=client,
body=body,

    ).parsed

async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: UpdateNotificationsRequest,

) -> Response[HTTPValidationError | list[NotificationResponse]]:
    """ Update Notifications

     Bulk update notifications.

    Supports:
    - content: Re-encrypt content (sender OR recipient can do this)
    - read: Mark as read (only recipient can do this)

    Returns the updated notifications.

    Args:
        body (UpdateNotificationsRequest): Bulk update notifications.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | list[NotificationResponse]]
     """


    kwargs = _get_kwargs(
        body=body,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: UpdateNotificationsRequest,

) -> HTTPValidationError | list[NotificationResponse] | None:
    """ Update Notifications

     Bulk update notifications.

    Supports:
    - content: Re-encrypt content (sender OR recipient can do this)
    - read: Mark as read (only recipient can do this)

    Returns the updated notifications.

    Args:
        body (UpdateNotificationsRequest): Bulk update notifications.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | list[NotificationResponse]
     """


    return (await asyncio_detailed(
        client=client,
body=body,

    )).parsed
