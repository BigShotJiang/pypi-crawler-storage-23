from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.http_validation_error import HTTPValidationError
from ...models.upload_documents_body import UploadDocumentsBody
from ...models.upload_documents_response import UploadDocumentsResponse
from ...types import UNSET, Unset
from typing import cast



def _get_kwargs(
    *,
    body: UploadDocumentsBody | Unset = UNSET,
    shared: bool | Unset = True,
    config_ext_id: None | str | Unset = UNSET,
    parent_ext_id: None | str | Unset = UNSET,
    wp_type: None | str | Unset = UNSET,
    tag_ext_id: None | str | Unset = UNSET,
    folder: None | str | Unset = UNSET,

) -> dict[str, Any]:
    headers: dict[str, Any] = {}


    

    params: dict[str, Any] = {}

    params["shared"] = shared

    json_config_ext_id: None | str | Unset
    if isinstance(config_ext_id, Unset):
        json_config_ext_id = UNSET
    else:
        json_config_ext_id = config_ext_id
    params["config_ext_id"] = json_config_ext_id

    json_parent_ext_id: None | str | Unset
    if isinstance(parent_ext_id, Unset):
        json_parent_ext_id = UNSET
    else:
        json_parent_ext_id = parent_ext_id
    params["parent_ext_id"] = json_parent_ext_id

    json_wp_type: None | str | Unset
    if isinstance(wp_type, Unset):
        json_wp_type = UNSET
    else:
        json_wp_type = wp_type
    params["wp_type"] = json_wp_type

    json_tag_ext_id: None | str | Unset
    if isinstance(tag_ext_id, Unset):
        json_tag_ext_id = UNSET
    else:
        json_tag_ext_id = tag_ext_id
    params["tag_ext_id"] = json_tag_ext_id

    json_folder: None | str | Unset
    if isinstance(folder, Unset):
        json_folder = UNSET
    else:
        json_folder = folder
    params["folder"] = json_folder


    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}


    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v1/document/upload",
        "params": params,
    }

    if not isinstance(body, Unset):
        _kwargs["files"] = body.to_multipart()



    _kwargs["headers"] = headers
    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> HTTPValidationError | UploadDocumentsResponse | None:
    if response.status_code == 200:
        response_200 = UploadDocumentsResponse.from_dict(response.json())



        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())



        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[HTTPValidationError | UploadDocumentsResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: UploadDocumentsBody | Unset = UNSET,
    shared: bool | Unset = True,
    config_ext_id: None | str | Unset = UNSET,
    parent_ext_id: None | str | Unset = UNSET,
    wp_type: None | str | Unset = UNSET,
    tag_ext_id: None | str | Unset = UNSET,
    folder: None | str | Unset = UNSET,

) -> Response[HTTPValidationError | UploadDocumentsResponse]:
    """ Upload Documents

     Upload multiple documents to a workspace with encryption.
    Documents are queued for processing, parsed, and indexed for vector search.

    Supports both file uploads and programmatic document creation:
    - For file uploads: standard multipart form with files
    - For artifacts/content: create a file from text content on the client side

    Optional parameters for version tracking and document typing:
    - parent_ext_id: Links new document as child of parent (version chain)
    - wp_type: Document type (source, skill, memory, artifact). Defaults to 'source'.
    - tag_ext_id: Links document to a tag
    - folder: Logical folder path for grouping (URL safe, e.g., 'skills/weather')

    Requires active subscription (paid/trial/dev) if Stripe is configured.

    Args:
        shared (bool | Unset): Whether the document should be shared with workspace members
            Default: True.
        config_ext_id (None | str | Unset): Configuration to use for processing
        parent_ext_id (None | str | Unset): Parent document ID for version tracking
        wp_type (None | str | Unset): Work product type: source, skill, memory, artifact
        tag_ext_id (None | str | Unset): Tag to link the document to
        folder (None | str | Unset): Optional logical folder path (URL safe)
        body (UploadDocumentsBody | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | UploadDocumentsResponse]
     """


    kwargs = _get_kwargs(
        body=body,
shared=shared,
config_ext_id=config_ext_id,
parent_ext_id=parent_ext_id,
wp_type=wp_type,
tag_ext_id=tag_ext_id,
folder=folder,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    *,
    client: AuthenticatedClient | Client,
    body: UploadDocumentsBody | Unset = UNSET,
    shared: bool | Unset = True,
    config_ext_id: None | str | Unset = UNSET,
    parent_ext_id: None | str | Unset = UNSET,
    wp_type: None | str | Unset = UNSET,
    tag_ext_id: None | str | Unset = UNSET,
    folder: None | str | Unset = UNSET,

) -> HTTPValidationError | UploadDocumentsResponse | None:
    """ Upload Documents

     Upload multiple documents to a workspace with encryption.
    Documents are queued for processing, parsed, and indexed for vector search.

    Supports both file uploads and programmatic document creation:
    - For file uploads: standard multipart form with files
    - For artifacts/content: create a file from text content on the client side

    Optional parameters for version tracking and document typing:
    - parent_ext_id: Links new document as child of parent (version chain)
    - wp_type: Document type (source, skill, memory, artifact). Defaults to 'source'.
    - tag_ext_id: Links document to a tag
    - folder: Logical folder path for grouping (URL safe, e.g., 'skills/weather')

    Requires active subscription (paid/trial/dev) if Stripe is configured.

    Args:
        shared (bool | Unset): Whether the document should be shared with workspace members
            Default: True.
        config_ext_id (None | str | Unset): Configuration to use for processing
        parent_ext_id (None | str | Unset): Parent document ID for version tracking
        wp_type (None | str | Unset): Work product type: source, skill, memory, artifact
        tag_ext_id (None | str | Unset): Tag to link the document to
        folder (None | str | Unset): Optional logical folder path (URL safe)
        body (UploadDocumentsBody | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | UploadDocumentsResponse
     """


    return sync_detailed(
        client=client,
body=body,
shared=shared,
config_ext_id=config_ext_id,
parent_ext_id=parent_ext_id,
wp_type=wp_type,
tag_ext_id=tag_ext_id,
folder=folder,

    ).parsed

async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: UploadDocumentsBody | Unset = UNSET,
    shared: bool | Unset = True,
    config_ext_id: None | str | Unset = UNSET,
    parent_ext_id: None | str | Unset = UNSET,
    wp_type: None | str | Unset = UNSET,
    tag_ext_id: None | str | Unset = UNSET,
    folder: None | str | Unset = UNSET,

) -> Response[HTTPValidationError | UploadDocumentsResponse]:
    """ Upload Documents

     Upload multiple documents to a workspace with encryption.
    Documents are queued for processing, parsed, and indexed for vector search.

    Supports both file uploads and programmatic document creation:
    - For file uploads: standard multipart form with files
    - For artifacts/content: create a file from text content on the client side

    Optional parameters for version tracking and document typing:
    - parent_ext_id: Links new document as child of parent (version chain)
    - wp_type: Document type (source, skill, memory, artifact). Defaults to 'source'.
    - tag_ext_id: Links document to a tag
    - folder: Logical folder path for grouping (URL safe, e.g., 'skills/weather')

    Requires active subscription (paid/trial/dev) if Stripe is configured.

    Args:
        shared (bool | Unset): Whether the document should be shared with workspace members
            Default: True.
        config_ext_id (None | str | Unset): Configuration to use for processing
        parent_ext_id (None | str | Unset): Parent document ID for version tracking
        wp_type (None | str | Unset): Work product type: source, skill, memory, artifact
        tag_ext_id (None | str | Unset): Tag to link the document to
        folder (None | str | Unset): Optional logical folder path (URL safe)
        body (UploadDocumentsBody | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | UploadDocumentsResponse]
     """


    kwargs = _get_kwargs(
        body=body,
shared=shared,
config_ext_id=config_ext_id,
parent_ext_id=parent_ext_id,
wp_type=wp_type,
tag_ext_id=tag_ext_id,
folder=folder,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: UploadDocumentsBody | Unset = UNSET,
    shared: bool | Unset = True,
    config_ext_id: None | str | Unset = UNSET,
    parent_ext_id: None | str | Unset = UNSET,
    wp_type: None | str | Unset = UNSET,
    tag_ext_id: None | str | Unset = UNSET,
    folder: None | str | Unset = UNSET,

) -> HTTPValidationError | UploadDocumentsResponse | None:
    """ Upload Documents

     Upload multiple documents to a workspace with encryption.
    Documents are queued for processing, parsed, and indexed for vector search.

    Supports both file uploads and programmatic document creation:
    - For file uploads: standard multipart form with files
    - For artifacts/content: create a file from text content on the client side

    Optional parameters for version tracking and document typing:
    - parent_ext_id: Links new document as child of parent (version chain)
    - wp_type: Document type (source, skill, memory, artifact). Defaults to 'source'.
    - tag_ext_id: Links document to a tag
    - folder: Logical folder path for grouping (URL safe, e.g., 'skills/weather')

    Requires active subscription (paid/trial/dev) if Stripe is configured.

    Args:
        shared (bool | Unset): Whether the document should be shared with workspace members
            Default: True.
        config_ext_id (None | str | Unset): Configuration to use for processing
        parent_ext_id (None | str | Unset): Parent document ID for version tracking
        wp_type (None | str | Unset): Work product type: source, skill, memory, artifact
        tag_ext_id (None | str | Unset): Tag to link the document to
        folder (None | str | Unset): Optional logical folder path (URL safe)
        body (UploadDocumentsBody | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | UploadDocumentsResponse
     """


    return (await asyncio_detailed(
        client=client,
body=body,
shared=shared,
config_ext_id=config_ext_id,
parent_ext_id=parent_ext_id,
wp_type=wp_type,
tag_ext_id=tag_ext_id,
folder=folder,

    )).parsed
