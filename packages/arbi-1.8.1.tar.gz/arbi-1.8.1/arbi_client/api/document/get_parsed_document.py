from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.http_validation_error import HTTPValidationError
from ...models.parsed_doc import ParsedDoc
from ...models.parsed_stage import ParsedStage
from typing import cast



def _get_kwargs(
    document_ext_id: str,
    stage: ParsedStage,

) -> dict[str, Any]:
    

    

    

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/document/{document_ext_id}/parsed-{stage}".format(document_ext_id=quote(str(document_ext_id), safe=""),stage=quote(str(stage), safe=""),),
    }


    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> HTTPValidationError | ParsedDoc | None:
    if response.status_code == 200:
        response_200 = ParsedDoc.from_dict(response.json())



        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())



        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[HTTPValidationError | ParsedDoc]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    document_ext_id: str,
    stage: ParsedStage,
    *,
    client: AuthenticatedClient | Client,

) -> Response[HTTPValidationError | ParsedDoc]:
    """ Get Parsed Document

     Retrieve the full parsed document to be handled by the frontend.
    Only requires document_ext_id, workspace is determined through RLS.

    Args:
        document_ext_id (str):
        stage (ParsedStage):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | ParsedDoc]
     """


    kwargs = _get_kwargs(
        document_ext_id=document_ext_id,
stage=stage,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    document_ext_id: str,
    stage: ParsedStage,
    *,
    client: AuthenticatedClient | Client,

) -> HTTPValidationError | ParsedDoc | None:
    """ Get Parsed Document

     Retrieve the full parsed document to be handled by the frontend.
    Only requires document_ext_id, workspace is determined through RLS.

    Args:
        document_ext_id (str):
        stage (ParsedStage):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | ParsedDoc
     """


    return sync_detailed(
        document_ext_id=document_ext_id,
stage=stage,
client=client,

    ).parsed

async def asyncio_detailed(
    document_ext_id: str,
    stage: ParsedStage,
    *,
    client: AuthenticatedClient | Client,

) -> Response[HTTPValidationError | ParsedDoc]:
    """ Get Parsed Document

     Retrieve the full parsed document to be handled by the frontend.
    Only requires document_ext_id, workspace is determined through RLS.

    Args:
        document_ext_id (str):
        stage (ParsedStage):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | ParsedDoc]
     """


    kwargs = _get_kwargs(
        document_ext_id=document_ext_id,
stage=stage,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    document_ext_id: str,
    stage: ParsedStage,
    *,
    client: AuthenticatedClient | Client,

) -> HTTPValidationError | ParsedDoc | None:
    """ Get Parsed Document

     Retrieve the full parsed document to be handled by the frontend.
    Only requires document_ext_id, workspace is determined through RLS.

    Args:
        document_ext_id (str):
        stage (ParsedStage):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | ParsedDoc
     """


    return (await asyncio_detailed(
        document_ext_id=document_ext_id,
stage=stage,
client=client,

    )).parsed
