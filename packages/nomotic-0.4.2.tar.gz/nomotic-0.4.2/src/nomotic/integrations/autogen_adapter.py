"""AutoGen integration -- governance-aware agent wrapper.

Usage:
    from autogen import AssistantAgent
    from nomotic.integrations.autogen_adapter import GovernedAutoGenAgent

    agent = GovernedAutoGenAgent(
        name="researcher",
        nomotic_agent_id="claims-bot",
        llm_config=llm_config,
        system_message="You are a research assistant.",
    )
"""

from __future__ import annotations

from typing import Any


class GovernedAutoGenAgent:
    """AutoGen AssistantAgent with Nomotic governance on function calls.

    Wraps AutoGen's function execution to route through governance.
    All function calls are evaluated before execution.
    """

    def __init__(
        self,
        name: str,
        nomotic_agent_id: str,
        *,
        test_mode: bool = False,
        base_dir: str | None = None,
        **autogen_kwargs: Any,
    ):
        try:
            from autogen import AssistantAgent
        except ImportError:
            raise ImportError("AutoGen is required: pip install pyautogen")

        from nomotic.executor import GovernedToolExecutor
        from pathlib import Path

        kw: dict[str, Any] = {"test_mode": test_mode}
        if base_dir:
            kw["base_dir"] = Path(base_dir)

        self._executor = GovernedToolExecutor.connect(nomotic_agent_id, **kw)

        # Create the AutoGen agent
        self._agent = AssistantAgent(name=name, **autogen_kwargs)

        # Wrap function map
        self._wrap_function_map()

    def _wrap_function_map(self) -> None:
        """Wrap all registered functions with governance."""
        original_map = self._agent.function_map or {}
        governed_map = {}

        for fn_name, fn in original_map.items():
            governed_map[fn_name] = self._govern_function(fn_name, fn)

        self._agent.function_map = governed_map

    def _govern_function(self, fn_name: str, fn: Any) -> Any:
        """Wrap a single function with governance evaluation."""
        executor = self._executor

        def governed(*args: Any, **kwargs: Any) -> Any:
            target = ""
            if args:
                target = str(args[0])

            result = executor.execute(
                action=fn_name,
                target=target,
                params=kwargs,
                tool_fn=lambda: fn(*args, **kwargs),
            )

            if result.allowed:
                return result.data
            return f"[GOVERNANCE DENIED] {result.reason}"

        return governed

    @property
    def agent(self) -> Any:
        """Access the underlying AutoGen agent."""
        return self._agent
