"""AGICOMPLY integration — push Nomotic audit records to AGICOMPLY's runtime governance ingestion API.

Transforms hash-chained PersistentLogRecords into AGICOMPLY's expected payload
format and POSTs them to the ingestion endpoint, where they are deterministically
mapped to AI regulatory frameworks (OMB M-25-21, EO 14179, NYC AEDT, etc.) and
packaged into procurement-ready audit artifacts.

Usage::

    from nomotic.integrations.agicomply import AGICOMPLYClient, AGICOMPLYConfig

    config = AGICOMPLYConfig.from_env()
    client = AGICOMPLYClient(config)
    result = client.push_record(record)

Environment variables::

    AGICOMPLY_API_URL    — Base URL (e.g. "https://api.agicomply.com")
    AGICOMPLY_API_TOKEN  — Bearer token for authentication
    AGICOMPLY_SYSTEM_ID  — UUID identifying this AI system in AGICOMPLY
"""

from __future__ import annotations

import datetime
import json
import os
import urllib.request
from dataclasses import dataclass
from typing import Any

import nomotic
from nomotic.audit_store import PersistentLogRecord

__all__ = [
    "AGICOMPLYClient",
    "AGICOMPLYConfig",
    "AGICOMPLYError",
]


class AGICOMPLYError(Exception):
    """Raised when an AGICOMPLY push fails."""


@dataclass
class AGICOMPLYConfig:
    """Configuration for the AGICOMPLY integration."""

    api_url: str  # Base URL, e.g. "https://api.agicomply.com"
    api_token: str  # Bearer token
    system_id: str  # UUID identifying this AI system in AGICOMPLY
    timeout_seconds: float = 10.0
    endpoint: str = "/api/runtime-governance/ingest"  # Configurable for sandbox

    @classmethod
    def from_env(cls) -> AGICOMPLYConfig:
        """Load from environment variables.

        Required:
            AGICOMPLY_API_URL
            AGICOMPLY_API_TOKEN
            AGICOMPLY_SYSTEM_ID

        Raises:
            ValueError: If any required environment variable is missing.
        """
        url = os.environ.get("AGICOMPLY_API_URL", "").rstrip("/")
        token = os.environ.get("AGICOMPLY_API_TOKEN", "")
        system_id = os.environ.get("AGICOMPLY_SYSTEM_ID", "")
        if not url or not token or not system_id:
            raise ValueError(
                "AGICOMPLY integration requires AGICOMPLY_API_URL, "
                "AGICOMPLY_API_TOKEN, and AGICOMPLY_SYSTEM_ID environment variables"
            )
        return cls(api_url=url, api_token=token, system_id=system_id)


def _build_payload(
    record: PersistentLogRecord,
    system_id: str,
) -> dict[str, Any]:
    """Transform a Nomotic audit record into AGICOMPLY's ingestion payload."""
    ts = datetime.datetime.fromtimestamp(record.timestamp, datetime.UTC).strftime(
        "%Y-%m-%dT%H:%M:%SZ"
    )
    return {
        "source": "nomotic",
        "system_id": system_id,
        "artifact_type": "runtime_governance_log",
        "timestamp": ts,
        "action": {
            "type": record.action_type,
            "target": record.action_target,
        },
        "governance_verdict": {
            "decision": record.verdict,
            "ucs_score": record.ucs,
            "dimensions": record.dimension_scores,
            "veto_triggered": len(record.vetoed_by) > 0,
            "vetoed_by": record.vetoed_by,
        },
        "trust_state": {
            "previous_score": round(record.trust_score - record.trust_delta, 4),
            "updated_score": record.trust_score,
            "delta": record.trust_delta,
            "trend": record.trust_trend,
        },
        "hash_chain": {
            "record_id": record.record_id,
            "record_hash": record.record_hash,
            "previous_hash": record.previous_hash,
        },
        "agent_id": record.agent_id,
        "severity": record.severity,
        "justification": record.justification,
    }


class AGICOMPLYClient:
    """Push Nomotic audit records to AGICOMPLY's ingestion API."""

    def __init__(self, config: AGICOMPLYConfig):
        self._config = config

    def push_record(self, record: PersistentLogRecord) -> dict[str, Any]:
        """Push a single audit record. Returns the AGICOMPLY response body.

        Raises:
            AGICOMPLYError: If the push fails.
        """
        payload = _build_payload(record, self._config.system_id)
        return self._post(payload)

    def push_records(
        self,
        records: list[PersistentLogRecord],
        *,
        stop_on_error: bool = False,
    ) -> dict[str, Any]:
        """Push multiple records. Returns summary of delivered/failed counts.

        Args:
            records: Records to push.
            stop_on_error: If True, stop on first failure. Default: continue.

        Returns:
            {"delivered": int, "failed": int, "errors": list[str]}
        """
        delivered = 0
        failed = 0
        errors: list[str] = []
        for record in records:
            try:
                self.push_record(record)
                delivered += 1
            except AGICOMPLYError as e:
                failed += 1
                errors.append(str(e))
                if stop_on_error:
                    break
        return {"delivered": delivered, "failed": failed, "errors": errors}

    def _post(self, payload: dict[str, Any]) -> dict[str, Any]:
        """POST payload to AGICOMPLY ingestion endpoint."""
        url = self._config.api_url + self._config.endpoint
        data = json.dumps(payload).encode("utf-8")
        req = urllib.request.Request(
            url,
            data=data,
            method="POST",
            headers={
                "Authorization": f"Bearer {self._config.api_token}",
                "Content-Type": "application/json",
                "User-Agent": f"nomotic/{nomotic.__version__}",
            },
        )
        try:
            with urllib.request.urlopen(
                req, timeout=self._config.timeout_seconds
            ) as resp:
                body = resp.read().decode("utf-8")
                return json.loads(body) if body else {}
        except Exception as e:
            raise AGICOMPLYError(f"Push failed: {e}") from e
