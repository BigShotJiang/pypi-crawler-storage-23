"""Policy-as-Code — declarative governance pre-filters.

Policies are evaluated before dimensional evaluation.  If a policy
matches, its verdict (DENY or ESCALATE) takes precedence — dimensional
evaluation is skipped entirely.

Policies can only DENY or ESCALATE.  They CANNOT ALLOW — only dimensional
evaluation can approve an action.  This ensures that the 13-dimension
evaluation remains the authoritative source for approval decisions.

Policy files are loaded from:
  1. ``./nomotic-policies/`` (project-level, higher priority)
  2. ``~/.nomotic/policies/`` (user-level)

JSON (``.json``) is the native policy file format — no extra dependencies.
YAML (``.yaml`` / ``.yml``) is supported when PyYAML is installed.  If a
YAML file is encountered without PyYAML, a ``PolicyLoadError`` is raised.
"""

from __future__ import annotations

import fnmatch
import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from nomotic.types import Action, AgentContext

__all__ = ["PolicyEngine", "PolicyLoadError", "PolicyResult", "PolicyRule"]


class PolicyLoadError(Exception):
    """Raised when a policy file cannot be loaded."""


@dataclass
class PolicyRule:
    """A single governance policy rule."""

    name: str
    description: str = ""
    when: dict[str, Any] = field(default_factory=dict)
    then: dict[str, Any] = field(default_factory=dict)
    enabled: bool = True
    priority: int = 0  # Higher priority rules evaluated first

    def matches(self, action: Action, context: AgentContext) -> bool:
        """Check if this policy matches the given action and context."""
        if not self.when:
            return False
        for key, expected in self.when.items():
            actual = self._resolve_field(key, action, context)
            if not self._compare(actual, expected):
                return False
        return True

    def _resolve_field(
        self, key: str, action: Action, context: AgentContext
    ) -> Any:
        """Resolve a dotted field path to a value.

        Supported fields:
        - action_type -> action.action_type
        - target -> action.target
        - agent_id -> action.agent_id or context.agent_id
        - zone_path -> context.zone_path (via getattr)
        - parameters.* -> action.parameters[*]
        - metadata.* -> action.metadata[*]
        """
        if key == "action_type":
            return action.action_type
        if key == "target":
            return action.target
        if key == "agent_id":
            return action.agent_id or context.agent_id
        if key == "zone_path":
            return getattr(context, "zone_path", "")
        if key.startswith("parameters."):
            param_key = key[len("parameters."):]
            return action.parameters.get(param_key)
        if key.startswith("metadata."):
            meta_key = key[len("metadata."):]
            return action.metadata.get(meta_key)
        return None

    def _compare(self, actual: Any, expected: Any) -> bool:
        """Compare actual value against expected.

        Supports:
        - Exact match: ``"delete"`` matches ``"delete"``
        - Wildcard: ``"production/*"`` matches ``"production/db"``
        - Numeric comparison: ``"> 1000"``, ``"< 50"``, ``">= 100"``
        - List membership: ``["delete", "drop"]`` matches if actual is in list
        """
        if actual is None:
            return False

        # List membership
        if isinstance(expected, list):
            return actual in expected

        # String comparison with operators
        if isinstance(expected, str):
            # Numeric comparison operators
            for op, fn in [
                (">=", lambda a, b: a >= b),
                ("<=", lambda a, b: a <= b),
                (">", lambda a, b: a > b),
                ("<", lambda a, b: a < b),
                ("==", lambda a, b: a == b),
            ]:
                if expected.startswith(op + " "):
                    try:
                        return fn(
                            float(actual),
                            float(expected[len(op) + 1:].strip()),
                        )
                    except (ValueError, TypeError):
                        return False

            # Glob-style wildcard
            if "*" in expected:
                return fnmatch.fnmatch(str(actual), expected)

        # Exact match
        return str(actual) == str(expected)

    def to_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "description": self.description,
            "when": self.when,
            "then": self.then,
            "enabled": self.enabled,
            "priority": self.priority,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> PolicyRule:
        policy_data = data.get("policy", data)
        return cls(
            name=policy_data["name"],
            description=policy_data.get("description", ""),
            when=policy_data.get("when", {}),
            then=policy_data.get("then", {}),
            enabled=policy_data.get("enabled", True),
            priority=policy_data.get("priority", 0),
        )


@dataclass
class PolicyResult:
    """Result of a policy evaluation."""

    matched_policy: str
    verdict: str  # "DENY" or "ESCALATE"
    reason: str
    require_human: bool = False


class PolicyEngine:
    """Loads and evaluates governance policies.

    Policies are loaded from JSON and YAML files in:
      1. ``./nomotic-policies/`` (project-level)
      2. ``~/.nomotic/policies/`` (user-level)

    Project policies take priority over user policies.
    """

    def __init__(self, policy_dirs: list[Path] | None = None) -> None:
        self._policies: list[PolicyRule] = []
        dirs = policy_dirs or [
            Path("./nomotic-policies"),
            Path.home() / ".nomotic" / "policies",
        ]
        for d in dirs:
            self._load_from_dir(d)
        # Sort by priority (highest first)
        self._policies.sort(key=lambda p: p.priority, reverse=True)

    def evaluate(
        self, action: Action, context: AgentContext
    ) -> PolicyResult | None:
        """Evaluate all policies against an action.

        Returns a :class:`PolicyResult` if a policy matched, ``None`` if no
        policies matched (action should proceed to dimensional evaluation).
        """
        for policy in self._policies:
            if not policy.enabled:
                continue
            if policy.matches(action, context):
                return PolicyResult(
                    matched_policy=policy.name,
                    verdict=policy.then.get("verdict", "DENY"),
                    reason=policy.then.get(
                        "reason", f"Policy '{policy.name}' triggered"
                    ),
                    require_human=policy.then.get("require_human", False),
                )
        return None

    def add_policy(self, policy: PolicyRule) -> None:
        """Add a policy programmatically."""
        self._policies.append(policy)
        self._policies.sort(key=lambda p: p.priority, reverse=True)

    def list_policies(self) -> list[PolicyRule]:
        """List all loaded policies."""
        return list(self._policies)

    def validate_all(self) -> list[dict[str, str]]:
        """Validate all loaded policies.  Returns list of issues."""
        issues: list[dict[str, str]] = []

        names: set[str] = set()
        for p in self._policies:
            if p.name in names:
                issues.append({
                    "policy": p.name,
                    "issue": "Duplicate policy name",
                })
            names.add(p.name)

            if not p.when:
                issues.append({
                    "policy": p.name,
                    "issue": "No 'when' conditions defined",
                })

            if not p.then:
                issues.append({
                    "policy": p.name,
                    "issue": "No 'then' outcome defined",
                })

            verdict = p.then.get("verdict", "")
            if verdict not in ("DENY", "ESCALATE"):
                issues.append({
                    "policy": p.name,
                    "issue": (
                        f"Invalid verdict '{verdict}'. "
                        "Must be DENY or ESCALATE."
                    ),
                })

        return issues

    # ── Internal helpers ──────────────────────────────────────────────

    def _load_from_dir(self, directory: Path) -> None:
        """Load policy files (JSON and YAML) from a directory."""
        if not directory.exists():
            return
        for path in sorted(directory.glob("*.json")):
            self._load_file(path)
        for path in sorted(directory.glob("*.yaml")):
            self._load_file(path)
        for path in sorted(directory.glob("*.yml")):
            self._load_file(path)

    def _load_file(self, path: Path) -> None:
        """Load a single policy file.

        JSON files are loaded natively.  YAML files require PyYAML;
        a ``PolicyLoadError`` is raised if PyYAML is not installed.
        """
        suffix = path.suffix.lower()

        if suffix == ".json":
            try:
                text = path.read_text()
                data = json.loads(text)
                if isinstance(data, dict):
                    policy = PolicyRule.from_dict(data)
                    self._policies.append(policy)
            except Exception:
                pass  # Skip invalid files — validate_all catches structural issues

        elif suffix in (".yaml", ".yml"):
            try:
                import yaml
            except ImportError:
                raise PolicyLoadError(
                    f"YAML policy files require PyYAML: pip install pyyaml. File: {path}"
                )

            try:
                text = path.read_text()
                data = yaml.safe_load(text)
                if isinstance(data, dict):
                    policy = PolicyRule.from_dict(data)
                    self._policies.append(policy)
            except PolicyLoadError:
                raise
            except Exception:
                pass  # Skip invalid files — validate_all catches structural issues
