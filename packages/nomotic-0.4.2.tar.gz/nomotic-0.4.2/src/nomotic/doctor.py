"""Nomotic Doctor — governance infrastructure diagnostics.

Provides a single ``run_doctor(base_dir)`` entry-point that checks the health
of a Nomotic installation and returns a structured :class:`DoctorReport`.

The module is independently importable and testable — ``cli.py`` calls it as
a thin dispatcher.
"""

from __future__ import annotations

import hashlib
import json
import platform
import sys
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

__all__ = ["DoctorCheck", "DoctorReport", "run_doctor"]


@dataclass
class DoctorCheck:
    """Result of a single health check."""

    category: str  # "Installation", "Configuration", etc.
    name: str  # Short name — shown in report
    status: str  # "ok", "warning", "error"
    message: str  # Human-readable detail
    fix_hint: str = ""  # If non-empty, --fix can attempt this

    def is_ok(self) -> bool:
        return self.status == "ok"

    def is_warning(self) -> bool:
        return self.status == "warning"

    def is_error(self) -> bool:
        return self.status == "error"

    def to_dict(self) -> dict[str, Any]:
        return {
            "category": self.category,
            "name": self.name,
            "status": self.status,
            "message": self.message,
        }


@dataclass
class DoctorReport:
    """Full health report from all checks."""

    checks: list[DoctorCheck] = field(default_factory=list)
    generated_at: float = field(default_factory=time.time)

    @property
    def errors(self) -> list[DoctorCheck]:
        return [c for c in self.checks if c.is_error()]

    @property
    def warnings(self) -> list[DoctorCheck]:
        return [c for c in self.checks if c.is_warning()]

    @property
    def ok(self) -> list[DoctorCheck]:
        return [c for c in self.checks if c.is_ok()]

    @property
    def has_errors(self) -> bool:
        return len(self.errors) > 0

    def to_dict(self) -> dict[str, Any]:
        return {
            "generated_at": self.generated_at,
            "summary": {
                "errors": len(self.errors),
                "warnings": len(self.warnings),
                "ok": len(self.ok),
            },
            "checks": [c.to_dict() for c in self.checks],
        }


def run_doctor(base_dir: Path) -> DoctorReport:
    """Run all health checks and return a DoctorReport."""
    report = DoctorReport()

    _check_installation(report)
    _check_configuration(report, base_dir)
    _check_certificate_store(report, base_dir)
    _check_audit_trail(report, base_dir)
    _check_signing_keys(report, base_dir)

    return report


# ── Check implementations ────────────────────────────────────────────────


def _check_installation(report: DoctorReport) -> None:
    """Check 1: Installation — version, Python, importable package."""

    # Nomotic version
    try:
        import nomotic

        report.checks.append(
            DoctorCheck(
                category="Installation",
                name="Nomotic version",
                status="ok",
                message=f"Nomotic {getattr(nomotic, '__version__', 'unknown')}",
            )
        )
    except ImportError as exc:
        report.checks.append(
            DoctorCheck(
                category="Installation",
                name="Nomotic version",
                status="error",
                message=f"Cannot import nomotic: {exc}",
            )
        )

    # Python version (3.10+ required)
    py_ver = sys.version_info
    if py_ver >= (3, 10):
        report.checks.append(
            DoctorCheck(
                category="Installation",
                name="Python version",
                status="ok",
                message=f"Python {sys.version.split()[0]}",
            )
        )
    else:
        report.checks.append(
            DoctorCheck(
                category="Installation",
                name="Python version",
                status="error",
                message=f"Python {sys.version.split()[0]} — Nomotic requires Python 3.10+",
            )
        )

    # Key dependencies importable
    for dep in ["cryptography", "yaml"]:
        try:
            __import__(dep)
            report.checks.append(
                DoctorCheck(
                    category="Installation",
                    name=f"Dependency: {dep}",
                    status="ok",
                    message=f"{dep} importable",
                )
            )
        except ImportError:
            report.checks.append(
                DoctorCheck(
                    category="Installation",
                    name=f"Dependency: {dep}",
                    status="warning",
                    message=f"{dep} not installed — some features unavailable",
                    fix_hint=f"pip install {dep}",
                )
            )


def _check_configuration(report: DoctorReport, base_dir: Path) -> None:
    """Check 2: Configuration — config.json and issuer setup."""

    config_path = base_dir / "config.json"
    if not config_path.exists():
        report.checks.append(
            DoctorCheck(
                category="Configuration",
                name="config.json",
                status="warning",
                message=f"{config_path} not found — run 'nomotic setup' to initialize",
                fix_hint="nomotic setup",
            )
        )
        return

    try:
        with open(config_path) as f:
            config = json.load(f)
        report.checks.append(
            DoctorCheck(
                category="Configuration",
                name="config.json",
                status="ok",
                message=f"{config_path} valid",
            )
        )
    except (json.JSONDecodeError, OSError) as exc:
        report.checks.append(
            DoctorCheck(
                category="Configuration",
                name="config.json",
                status="error",
                message=f"{config_path} invalid: {exc}",
            )
        )
        return

    # Check for organization name
    org = config.get("organization") or config.get("org")
    if org:
        report.checks.append(
            DoctorCheck(
                category="Configuration",
                name="Organization",
                status="ok",
                message=f"Organization: {org}",
            )
        )
    else:
        report.checks.append(
            DoctorCheck(
                category="Configuration",
                name="Organization",
                status="warning",
                message="No organization configured — set 'organization' in config.json",
            )
        )

    # Check default preset if present
    preset = config.get("default_preset")
    valid_presets = {"permissive", "moderate", "strict", "ultra_strict"}
    if preset:
        if preset in valid_presets:
            report.checks.append(
                DoctorCheck(
                    category="Configuration",
                    name="Default preset",
                    status="ok",
                    message=f"Default preset: {preset}",
                )
            )
        else:
            report.checks.append(
                DoctorCheck(
                    category="Configuration",
                    name="Default preset",
                    status="warning",
                    message=f"Unknown preset '{preset}' — valid: {', '.join(sorted(valid_presets))}",
                )
            )


def _check_certificate_store(report: DoctorReport, base_dir: Path) -> None:
    """Check 3: Certificate store — active/expired/orphaned counts."""

    certs_dir = base_dir / "certs"
    if not certs_dir.exists():
        report.checks.append(
            DoctorCheck(
                category="Certificate Store",
                name="Certs directory",
                status="warning",
                message=f"{certs_dir} does not exist — no certificates issued yet",
            )
        )
        return

    try:
        from nomotic.certificate import CertStatus
        from nomotic.store import FileCertificateStore

        store = FileCertificateStore(base_dir)
        certs = store.list()
        revoked = store.list_revoked()
        all_certs = certs + revoked
    except Exception as exc:
        report.checks.append(
            DoctorCheck(
                category="Certificate Store",
                name="Certs directory",
                status="error",
                message=f"Cannot read certificate store: {exc}",
            )
        )
        return

    counts: dict[str, int] = {}
    expired: list[str] = []

    for cert in all_certs:
        status_name = cert.status.name if cert.status else "UNKNOWN"
        counts[status_name] = counts.get(status_name, 0) + 1

        # Check expiry on ACTIVE certs
        if cert.status == CertStatus.ACTIVE:
            try:
                from datetime import datetime, timezone

                if cert.expires_at:
                    exp = cert.expires_at
                    if not exp.tzinfo:
                        exp = exp.replace(tzinfo=timezone.utc)
                    if exp < datetime.now(timezone.utc):
                        expired.append(cert.certificate_id)
            except (AttributeError, ValueError):
                pass

    total = sum(counts.values())
    active = counts.get("ACTIVE", 0)

    other_parts = ", ".join(
        f"{k.lower()}:{v}" for k, v in sorted(counts.items()) if k != "ACTIVE"
    )
    msg = f"{total} total — active:{active}"
    if other_parts:
        msg += f", {other_parts}"

    report.checks.append(
        DoctorCheck(
            category="Certificate Store",
            name="Certificate counts",
            status="ok",
            message=msg,
        )
    )

    if expired:
        suffix = "..." if len(expired) > 3 else ""
        report.checks.append(
            DoctorCheck(
                category="Certificate Store",
                name="Expired active certificates",
                status="warning",
                message=f"{len(expired)} active certificate(s) past expiry: "
                + ", ".join(expired[:3])
                + suffix,
                fix_hint="nomotic revoke <cert-id> --reason 'expired'",
            )
        )
    else:
        report.checks.append(
            DoctorCheck(
                category="Certificate Store",
                name="Expired active certificates",
                status="ok",
                message="No expired active certificates",
            )
        )

    if active == 0 and total == 0:
        report.checks.append(
            DoctorCheck(
                category="Certificate Store",
                name="Active agents",
                status="warning",
                message="No agents exist — run 'nomotic birth --name <agent>' to create one",
            )
        )


def _check_audit_trail(report: DoctorReport, base_dir: Path) -> None:
    """Check 4: Audit trail — record counts, hash chain integrity, silent agents."""

    audit_dir = base_dir / "audit"
    if not audit_dir.exists():
        report.checks.append(
            DoctorCheck(
                category="Audit Trail",
                name="Audit directory",
                status="warning",
                message="No audit records exist — agents have not been evaluated yet",
            )
        )
        return

    try:
        from nomotic.audit_store import AuditStore

        store = AuditStore(base_dir)
        agents = store.list_agents()
    except Exception as exc:
        report.checks.append(
            DoctorCheck(
                category="Audit Trail",
                name="Audit directory",
                status="error",
                message=f"Cannot read audit store: {exc}",
            )
        )
        return

    total_records = 0
    chain_failures: list[str] = []
    empty_agents: list[str] = []

    for agent_name in agents:
        summary = store.summary(agent_name)
        count = summary.get("total", 0)
        total_records += count

        if count == 0:
            empty_agents.append(agent_name)
            continue

        is_valid, _, message = store.verify_chain(agent_name)
        if not is_valid:
            chain_failures.append(f"{agent_name}: {message}")

    report.checks.append(
        DoctorCheck(
            category="Audit Trail",
            name="Audit records",
            status="ok",
            message=f"{total_records} records across {len(agents)} agent(s)",
        )
    )

    if chain_failures:
        report.checks.append(
            DoctorCheck(
                category="Audit Trail",
                name="Hash chain integrity",
                status="error",
                message=f"CHAIN BREAK detected in {len(chain_failures)} agent(s): "
                + "; ".join(chain_failures[:2]),
            )
        )
    else:
        report.checks.append(
            DoctorCheck(
                category="Audit Trail",
                name="Hash chain integrity",
                status="ok",
                message=f"All {len(agents)} agent audit chain(s) verified",
            )
        )

    if empty_agents:
        report.checks.append(
            DoctorCheck(
                category="Audit Trail",
                name="Silent agents",
                status="warning",
                message=f"{len(empty_agents)} agent(s) have no audit records: "
                + ", ".join(empty_agents[:3]),
            )
        )


def _check_signing_keys(report: DoctorReport, base_dir: Path) -> None:
    """Check 5: Signing keys — issuer key present and loadable."""

    issuer_dir = base_dir / "issuer"
    if not issuer_dir.exists():
        report.checks.append(
            DoctorCheck(
                category="Signing Keys",
                name="Issuer key",
                status="warning",
                message=f"{issuer_dir} not found — run 'nomotic setup' to generate keys",
                fix_hint="nomotic setup",
            )
        )
        return

    key_files = list(issuer_dir.glob("*.key")) + list(issuer_dir.glob("issuer*"))
    # Deduplicate (issuer.key would match both globs)
    key_files = list(dict.fromkeys(key_files))
    if not key_files:
        report.checks.append(
            DoctorCheck(
                category="Signing Keys",
                name="Issuer key",
                status="error",
                message=f"No key file found in {issuer_dir}",
            )
        )
        return

    try:
        from nomotic.keys import SigningKey

        # Try to load the first .key file (prefer issuer.key if present)
        key_path = None
        for kf in key_files:
            if kf.name == "issuer.key":
                key_path = kf
                break
        if key_path is None:
            key_path = key_files[0]

        key_bytes = key_path.read_bytes()
        sk = SigningKey.from_bytes(key_bytes)
        fingerprint = hashlib.sha256(sk.verify_key().to_bytes()).hexdigest()[:16]
        report.checks.append(
            DoctorCheck(
                category="Signing Keys",
                name="Issuer key",
                status="ok",
                message=f"Key present and valid — fingerprint: {fingerprint}...",
            )
        )
    except Exception as exc:
        report.checks.append(
            DoctorCheck(
                category="Signing Keys",
                name="Issuer key",
                status="error",
                message=f"Cannot load issuer key: {exc}",
            )
        )
