"""Reversibility-aware governance for single actions and workflows.

Formalizes the scattered irreversibility logic from workflow_governor.py
into a reusable assessment that integrates with the 13-dimension evaluation
pipeline. Answers: "If this action goes wrong, can we undo it?"

The reversibility assessment affects governance in three ways:
1. Modifies the cascading_impact dimension weight (irreversible = higher weight)
2. Can trigger escalation to Full Deliberation tier for irreversible actions
3. Adds a reversibility_window_seconds field to governance tokens

Key concepts:
- Reversibility is a spectrum, not binary. A database DELETE with WAL backup
  is more reversible than a wire transfer.
- Context matters: DELETE in staging != DELETE in production.
- Time-bounded reversibility: some actions are reversible within a window
  (e.g., email recall, soft delete retention period).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Optional


__all__ = [
    "CommitPointDetector",
    "ReversibilityAssessment",
    "ReversibilityConfig",
    "ReversibilityLevel",
]


class ReversibilityLevel(Enum):
    """How reversible an action is."""

    FULLY_REVERSIBLE = "fully_reversible"  # Can undo with no consequences
    TIME_BOUNDED = "time_bounded"  # Reversible within a window
    PARTIALLY_REVERSIBLE = "partially_reversible"  # Can undo but with side effects
    DIFFICULT_TO_REVERSE = "difficult_to_reverse"  # Technically possible, high cost
    IRREVERSIBLE = "irreversible"  # Cannot be undone


@dataclass
class ReversibilityAssessment:
    """Assessment of how reversible an action is.

    Produced by the CommitPointDetector for each action. Consumed by
    the ReversibilityModifier to adjust governance scoring.
    """

    level: ReversibilityLevel
    score: float  # 0.0 (irreversible) to 1.0 (fully reversible)
    window_seconds: Optional[int]  # Time window for reversal (None if N/A)
    undo_mechanism: Optional[str]  # How to reverse ("soft_delete", "rollback", etc.)
    confidence: float  # How confident the assessment is (0-1)
    reasoning: str  # Why this level was assigned
    affected_scope: str  # What's affected ("single_record", "table", "system", "external")
    requires_escalation: bool  # Should this force Full Deliberation tier?

    @property
    def is_irreversible(self) -> bool:
        return self.level == ReversibilityLevel.IRREVERSIBLE

    @property
    def is_time_bounded(self) -> bool:
        return self.level == ReversibilityLevel.TIME_BOUNDED

    @property
    def cascading_impact_modifier(self) -> float:
        """Weight modifier for the cascading_impact dimension.

        Irreversible actions get a significant boost to cascading_impact weight,
        making the governance evaluation stricter. Fully reversible actions
        get a slight reduction (still positive -- all actions have some impact).

        Returns a value in [-0.10, +0.40] to add to cascading_impact weight.
        """
        modifiers = {
            ReversibilityLevel.FULLY_REVERSIBLE: -0.10,
            ReversibilityLevel.TIME_BOUNDED: 0.05,
            ReversibilityLevel.PARTIALLY_REVERSIBLE: 0.15,
            ReversibilityLevel.DIFFICULT_TO_REVERSE: 0.30,
            ReversibilityLevel.IRREVERSIBLE: 0.40,
        }
        return modifiers[self.level]

    def to_dict(self) -> dict[str, Any]:
        return {
            "level": self.level.value,
            "score": self.score,
            "window_seconds": self.window_seconds,
            "undo_mechanism": self.undo_mechanism,
            "confidence": self.confidence,
            "reasoning": self.reasoning,
            "affected_scope": self.affected_scope,
            "requires_escalation": self.requires_escalation,
        }


@dataclass
class ReversibilityConfig:
    """Configuration for reversibility-aware governance modifiers."""

    # UCS threshold increases (added to the runtime's allow_threshold)
    irreversible_ucs_increase: float = 0.15
    difficult_to_reverse_ucs_increase: float = 0.10
    partially_reversible_ucs_increase: float = 0.05
    time_bounded_ucs_increase: float = 0.03

    # How to treat UNKNOWN reversibility
    unknown_treated_as: str = "irreversible"  # "irreversible" or "difficult_to_reverse"

    # Force Tier 3 deliberation for these levels
    force_tier3_levels: list[str] = field(default_factory=lambda: [
        "irreversible", "difficult_to_reverse",
    ])

    # Seal TTL overrides (seconds) — shorter for dangerous actions
    irreversible_seal_ttl: int = 10
    difficult_to_reverse_seal_ttl: int = 15
    time_bounded_seal_ttl_cap: bool = True  # Cap seal TTL at the reversibility window

    # Human authorization requirement
    require_human_for_irreversible: bool = False


# ── Reversibility level ordering for escalation/de-escalation ────────

_LEVEL_ORDER = [
    ReversibilityLevel.FULLY_REVERSIBLE,
    ReversibilityLevel.TIME_BOUNDED,
    ReversibilityLevel.PARTIALLY_REVERSIBLE,
    ReversibilityLevel.DIFFICULT_TO_REVERSE,
    ReversibilityLevel.IRREVERSIBLE,
]

_LEVEL_SCORES = {
    ReversibilityLevel.FULLY_REVERSIBLE: 1.0,
    ReversibilityLevel.TIME_BOUNDED: 0.75,
    ReversibilityLevel.PARTIALLY_REVERSIBLE: 0.50,
    ReversibilityLevel.DIFFICULT_TO_REVERSE: 0.20,
    ReversibilityLevel.IRREVERSIBLE: 0.0,
}


class CommitPointDetector:
    """Detects whether an action represents a commit point (irreversible state change).

    Extracts and extends the logic scattered through workflow_governor.py:
    - _is_transaction() for method-level detection
    - is_reversible_to() for workflow-level rollback
    - irreversibility_chain for sequential non-reversible steps

    This class makes the same logic available for single-action evaluation
    (not just multi-step workflows).
    """

    # Action patterns by reversibility level
    IRREVERSIBLE_PATTERNS: dict[str, ReversibilityLevel] = {
        # Fully irreversible
        "delete": ReversibilityLevel.IRREVERSIBLE,
        "drop": ReversibilityLevel.IRREVERSIBLE,
        "truncate": ReversibilityLevel.IRREVERSIBLE,
        "purge": ReversibilityLevel.IRREVERSIBLE,
        "destroy": ReversibilityLevel.IRREVERSIBLE,
        "transfer_funds": ReversibilityLevel.IRREVERSIBLE,
        "wire_transfer": ReversibilityLevel.IRREVERSIBLE,
        "send_payment": ReversibilityLevel.IRREVERSIBLE,
        "revoke_access": ReversibilityLevel.DIFFICULT_TO_REVERSE,
        "terminate": ReversibilityLevel.DIFFICULT_TO_REVERSE,
        "publish": ReversibilityLevel.DIFFICULT_TO_REVERSE,
        "broadcast": ReversibilityLevel.DIFFICULT_TO_REVERSE,
        "deploy": ReversibilityLevel.DIFFICULT_TO_REVERSE,
        # Partially reversible
        "update": ReversibilityLevel.PARTIALLY_REVERSIBLE,
        "modify": ReversibilityLevel.PARTIALLY_REVERSIBLE,
        "overwrite": ReversibilityLevel.PARTIALLY_REVERSIBLE,
        "merge": ReversibilityLevel.PARTIALLY_REVERSIBLE,
        # Time-bounded
        "send_email": ReversibilityLevel.TIME_BOUNDED,
        "send_message": ReversibilityLevel.TIME_BOUNDED,
        "schedule": ReversibilityLevel.TIME_BOUNDED,
        "queue": ReversibilityLevel.TIME_BOUNDED,
        # Fully reversible
        "read": ReversibilityLevel.FULLY_REVERSIBLE,
        "query": ReversibilityLevel.FULLY_REVERSIBLE,
        "list": ReversibilityLevel.FULLY_REVERSIBLE,
        "describe": ReversibilityLevel.FULLY_REVERSIBLE,
        "create": ReversibilityLevel.PARTIALLY_REVERSIBLE,  # Can delete what was created
        "insert": ReversibilityLevel.PARTIALLY_REVERSIBLE,
    }

    # Target patterns that increase irreversibility
    SENSITIVE_TARGETS = {
        "production",
        "prod",
        "live",
        "master",
        "main",
        "credentials",
        "secrets",
        "keys",
        "passwords",
        "financial",
        "payments",
        "billing",
        "transactions",
        "customer_data",
        "pii",
        "health_records",
    }

    # Time windows for time-bounded reversibility
    DEFAULT_WINDOWS: dict[str, int] = {
        "send_email": 30,  # 30-second recall window
        "send_message": 15,  # 15-second edit/delete window
        "schedule": 3600,  # 1 hour before execution
        "queue": 300,  # 5 minutes in queue
    }

    def __init__(
        self,
        custom_patterns: Optional[dict[str, ReversibilityLevel]] = None,
    ) -> None:
        """Initialize with optional custom action->reversibility mappings."""
        self._patterns = dict(self.IRREVERSIBLE_PATTERNS)
        if custom_patterns:
            self._patterns.update(custom_patterns)

    def assess(
        self,
        action: str,
        target: str,
        *,
        context: Optional[dict[str, Any]] = None,
    ) -> ReversibilityAssessment:
        """Assess the reversibility of a single action.

        Args:
            action: The action type (e.g., "delete", "query", "send_email")
            target: The target resource (e.g., "customers", "production_db")
            context: Additional context (e.g., {"environment": "staging"})

        Returns:
            ReversibilityAssessment with level, score, and modifiers
        """
        context = context or {}

        # Step 1: Base level from action pattern
        base_action = self._normalize_action(action)
        level = self._patterns.get(
            base_action, ReversibilityLevel.PARTIALLY_REVERSIBLE
        )

        # Step 2: Target sensitivity adjustment
        target_lower = target.lower()
        target_is_sensitive = any(s in target_lower for s in self.SENSITIVE_TARGETS)

        if target_is_sensitive and level.value != "irreversible":
            # Bump up one level for sensitive targets
            level = self._escalate_level(level)

        # Step 3: Environment context
        env = context.get("environment", "production")
        if env in ("staging", "development", "test", "sandbox"):
            # Non-production environments are more reversible
            level = self._deescalate_level(level)

        # Step 4: Build assessment
        score = _LEVEL_SCORES[level]
        window = self.DEFAULT_WINDOWS.get(base_action)
        undo = self._determine_undo_mechanism(base_action, level)
        scope = self._determine_affected_scope(base_action, target)

        # Require escalation for irreversible + sensitive target
        requires_escalation = (
            level
            in (
                ReversibilityLevel.IRREVERSIBLE,
                ReversibilityLevel.DIFFICULT_TO_REVERSE,
            )
            and target_is_sensitive
        )

        confidence = 0.9 if base_action in self._patterns else 0.5

        reasoning_parts = [f"Action '{action}' on '{target}'"]
        reasoning_parts.append(f"base reversibility: {level.value}")
        if target_is_sensitive:
            reasoning_parts.append("sensitive target detected")
        if env != "production":
            reasoning_parts.append(f"non-production environment ({env})")

        return ReversibilityAssessment(
            level=level,
            score=score,
            window_seconds=window,
            undo_mechanism=undo,
            confidence=confidence,
            reasoning="; ".join(reasoning_parts),
            affected_scope=scope,
            requires_escalation=requires_escalation,
        )

    def _normalize_action(self, action: str) -> str:
        """Normalize action string to match patterns.

        Handles variations like 'query_db', 'db_delete', 'hard_delete'.
        """
        action_lower = action.lower().strip()
        # Direct match
        if action_lower in self._patterns:
            return action_lower
        # Check if any pattern is a substring
        for pattern in self._patterns:
            if pattern in action_lower:
                return pattern
        return action_lower

    @staticmethod
    def _escalate_level(level: ReversibilityLevel) -> ReversibilityLevel:
        """Move one step toward irreversible."""
        idx = _LEVEL_ORDER.index(level)
        return _LEVEL_ORDER[min(idx + 1, len(_LEVEL_ORDER) - 1)]

    @staticmethod
    def _deescalate_level(level: ReversibilityLevel) -> ReversibilityLevel:
        """Move one step toward reversible."""
        idx = _LEVEL_ORDER.index(level)
        return _LEVEL_ORDER[max(idx - 1, 0)]

    @staticmethod
    def _determine_undo_mechanism(
        action: str,
        level: ReversibilityLevel,
    ) -> Optional[str]:
        """Suggest the undo mechanism if available."""
        if level == ReversibilityLevel.IRREVERSIBLE:
            return None
        mechanisms = {
            "delete": "restore_from_backup",
            "update": "revert_to_previous",
            "overwrite": "restore_from_version",
            "create": "delete_created",
            "insert": "delete_inserted",
            "send_email": "recall_message",
            "send_message": "delete_message",
            "deploy": "rollback_deployment",
            "publish": "unpublish",
            "schedule": "cancel_scheduled",
            "queue": "dequeue",
        }
        return mechanisms.get(action)

    @staticmethod
    def _determine_affected_scope(action: str, target: str) -> str:
        """Estimate the blast radius of the action."""
        destructive = {"delete", "drop", "truncate", "purge", "destroy"}
        bulk = {"truncate", "drop", "purge", "broadcast"}
        external = {
            "send_email",
            "send_message",
            "transfer_funds",
            "wire_transfer",
            "publish",
            "broadcast",
        }

        if action in external:
            return "external"
        if action in bulk:
            return "table"
        if action in destructive:
            return (
                "table" if "all" in target.lower() or "*" in target else "single_record"
            )
        return "single_record"
