"""MCP Governance Proxy — governs MCP tool calls through Nomotic.

Sits between an MCP client (the agent) and an MCP server (tools).
Intercepts tool-call requests, evaluates governance, and forwards
approved calls. Denied calls return a governance denial response.

This is an *adapter* — thin, replaceable, and clearly separated from
core governance logic. MCP wire-format translation happens here;
all governance decisions are delegated to GovernedToolExecutor.

Architecture:
    Agent -> MCP Client -> [Nomotic Proxy] -> MCP Server -> Tools

The proxy appears as an MCP server to the client and as an MCP client
to the actual server. It's transparent — the agent doesn't know
governance is happening.

**Scope limitation**: Certificate-required mode only enforces identity for
traffic routed through this proxy. Nomotic cannot detect arbitrary code
executing on the network that bypasses governed tool endpoints. The
enforcement boundary is the proxy, not the network.

Usage:
    # Start the proxy (stdio mode)
    nomotic mcp-proxy \\
        --agent-id claims-bot \\
        --upstream "python my_mcp_server.py"

    # Start the proxy (HTTP mode)
    nomotic mcp-proxy \\
        --agent-id claims-bot \\
        --upstream-url http://localhost:3000 \\
        --port 8421

    # Programmatically:
    from nomotic.mcp_proxy import MCPGovernanceProxy

    proxy = MCPGovernanceProxy(
        agent_id="claims-bot",
        upstream_command="python my_mcp_server.py",
    )
    proxy.run()
"""

from __future__ import annotations

import json
import signal
import subprocess
import sys
import threading
import time
import urllib.request
import uuid
from http.server import HTTPServer, BaseHTTPRequestHandler
from pathlib import Path
from typing import Any
from urllib.request import Request, urlopen
from urllib.error import URLError

from nomotic.executor import GovernedToolExecutor
from nomotic.otel_exporter import PrometheusMetrics
from nomotic.proxy import verify_certificate_status

__all__ = [
    "MCPGovernanceProxy",
    "MCPHTTPGovernanceProxy",
]


# ── Stdio Proxy ──────────────────────────────────────────────────────────


class MCPGovernanceProxy:
    """Governance proxy for MCP tool calls (stdio transport).

    Intercepts JSON-RPC messages between client and server,
    applying governance evaluation on tools/call requests.
    All governance decisions are delegated to GovernedToolExecutor.
    """

    def __init__(
        self,
        agent_id: str,
        upstream_command: str | list[str],
        *,
        base_dir: Path | None = None,
        test_mode: bool = False,
        log_level: str = "info",
        require_certificate: bool = False,
    ):
        """
        Args:
            agent_id: Nomotic agent identity for governance.
            upstream_command: Command to start the upstream MCP server (stdio mode).
            base_dir: Nomotic config directory.
            test_mode: Use testlog and simulated trust.
            log_level: Logging verbosity ("debug", "info", "quiet").
            require_certificate: If True, verify that the agent has a valid
                birth certificate at startup. Only enforced for traffic
                routed through this proxy — Nomotic cannot detect traffic
                that bypasses governed endpoints.
        """
        self._agent_id = agent_id
        self._upstream_cmd = (
            upstream_command
            if isinstance(upstream_command, list)
            else upstream_command.split()
        )

        kw: dict[str, Any] = {"test_mode": test_mode}
        if base_dir:
            kw["base_dir"] = base_dir

        # Certificate verification at startup (stdio has a fixed agent_id)
        if require_certificate:
            from nomotic.store import FileCertificateStore

            store = FileCertificateStore(base_dir or Path.home() / ".nomotic")
            error = verify_certificate_status(store, agent_id)
            if error is not None:
                raise ValueError(
                    f"Certificate required but verification failed for agent "
                    f"'{agent_id}': {error}"
                )

        self._executor = GovernedToolExecutor.connect(agent_id, **kw)

        self._upstream_proc: subprocess.Popen | None = None
        self._log_level = log_level

    # ── Public API ────────────────────────────────────────────────────

    def run(self) -> None:
        """Run the proxy — reads from stdin, writes to stdout.

        The proxy itself acts as an MCP server (stdio transport).
        It launches the upstream MCP server as a subprocess and
        proxies messages between the client and server, intercepting
        tool calls for governance.
        """
        self._upstream_proc = subprocess.Popen(
            self._upstream_cmd,
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )

        upstream_reader = threading.Thread(
            target=self._read_upstream, daemon=True
        )
        upstream_reader.start()

        try:
            self._read_client()
        except KeyboardInterrupt:
            pass
        finally:
            if self._upstream_proc:
                self._upstream_proc.terminate()

    # ── Message routing ───────────────────────────────────────────────

    def _read_client(self) -> None:
        """Read JSON-RPC messages from the client (stdin)."""
        for line in sys.stdin:
            line = line.strip()
            if not line:
                continue

            try:
                message = json.loads(line)
            except json.JSONDecodeError:
                # Pass through non-JSON (headers, etc.)
                self._send_to_upstream(line)
                continue

            if self._is_tool_call(message):
                self._handle_tool_call(message)
            else:
                self._send_to_upstream(json.dumps(message))

    def _read_upstream(self) -> None:
        """Read responses from the upstream MCP server and forward to client."""
        if self._upstream_proc is None or self._upstream_proc.stdout is None:
            return
        for line in self._upstream_proc.stdout:
            decoded = line.decode("utf-8").strip()
            if decoded:
                self._send_to_client(decoded)

    # ── Governance interception ───────────────────────────────────────

    @staticmethod
    def _is_tool_call(message: dict) -> bool:
        """Check if a JSON-RPC message is an MCP tools/call request."""
        return message.get("method") == "tools/call" and "params" in message

    def _handle_tool_call(self, message: dict) -> None:
        """Evaluate governance on a tool call and decide whether to forward."""
        params = message.get("params", {})
        tool_name = params.get("name", "")
        tool_args = params.get("arguments", {})
        request_id = message.get("id")

        target = _extract_target(tool_name, tool_args)

        result = self._executor.check(
            action=tool_name,
            target=target,
            params=tool_args,
        )

        if self._log_level in ("info", "debug"):
            verdict_str = "ALLOW" if result.allowed else "DENY"
            sys.stderr.write(
                f"[nomotic] {tool_name} -> {target}: {verdict_str} "
                f"(trust: {result.trust_after:.3f})\n"
            )

        if result.allowed:
            forwarded = _attach_governance_token(message, result)
            self._send_to_upstream(json.dumps(forwarded))
        else:
            denial = _build_denial_response(request_id, tool_name, target, result.reason)
            self._send_to_client(json.dumps(denial))

    # ── Wire I/O ──────────────────────────────────────────────────────

    def _send_to_upstream(self, message: str) -> None:
        """Send a message to the upstream MCP server."""
        if self._upstream_proc and self._upstream_proc.stdin:
            self._upstream_proc.stdin.write((message + "\n").encode("utf-8"))
            self._upstream_proc.stdin.flush()

    def _send_to_client(self, message: str) -> None:
        """Send a message to the client (stdout)."""
        sys.stdout.write(message + "\n")
        sys.stdout.flush()


# ── HTTP/SSE Proxy ────────────────────────────────────────────────────────


class MCPHTTPGovernanceProxy:
    """HTTP-based MCP governance proxy.

    Runs as an HTTP server that proxies MCP JSON-RPC requests to an
    upstream MCP server over HTTP, applying governance on tool calls.

    Usage:
        nomotic mcp-proxy \\
            --agent-id claims-bot \\
            --upstream-url http://localhost:3000 \\
            --port 8421
    """

    def __init__(
        self,
        agent_id: str,
        upstream_url: str,
        *,
        port: int = 8421,
        host: str = "127.0.0.1",
        base_dir: Path | None = None,
        test_mode: bool = False,
        log_level: str = "info",
        require_certificate: bool = False,
        agent_id_map: dict[str, str] | None = None,
        tool_timeouts: dict[str, float] | None = None,
        default_timeout: float = 30.0,
    ):
        """
        Args:
            agent_id: Nomotic agent identity for governance.
            upstream_url: URL of the upstream MCP server.
            port: Port for this proxy to listen on.
            host: Host to bind to.
            base_dir: Nomotic config directory.
            test_mode: Use testlog and simulated trust.
            log_level: Logging verbosity.
            require_certificate: If True, require a valid birth certificate
                for every request. Only enforced for traffic routed through
                this proxy — Nomotic cannot detect traffic that bypasses
                governed endpoints.
            agent_id_map: Optional mapping of client IPs to agent IDs for
                environments where agents cannot set custom HTTP headers.
            tool_timeouts: Per-tool timeout overrides (tool_name -> seconds).
            default_timeout: Default upstream timeout in seconds.
        """
        self._agent_id = agent_id
        self._upstream_url = upstream_url.rstrip("/")
        self._port = port
        self._host = host
        self._log_level = log_level
        self._require_certificate = require_certificate
        self._agent_id_map = agent_id_map or {}
        self._tool_timeouts = tool_timeouts or {}
        self._default_timeout = default_timeout

        # Metrics and counters
        self._metrics = PrometheusMetrics()
        self._start_time = time.time()
        self._request_count = 0
        self._denial_count = 0
        self._shutting_down = False

        self._cert_store: Any = None
        if require_certificate:
            from nomotic.store import FileCertificateStore

            self._cert_store = FileCertificateStore(
                base_dir or Path.home() / ".nomotic"
            )

        kw: dict[str, Any] = {"test_mode": test_mode}
        if base_dir:
            kw["base_dir"] = base_dir
        self._executor = GovernedToolExecutor.connect(agent_id, **kw)

    def _verify_certificate(self, agent_id: str) -> str | None:
        """Verify agent has valid certificate. Returns error string or None."""
        return verify_certificate_status(self._cert_store, agent_id)

    def _log(self, level: str, message: str, **kwargs: Any) -> None:
        """Structured JSON log entry."""
        if self._log_level == "quiet" and level != "error":
            return
        if self._log_level == "info" and level == "debug":
            return

        entry = {
            "timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            "level": level,
            "message": message,
            "agent_id": self._agent_id,
            **kwargs,
        }
        print(json.dumps(entry), file=sys.stderr)

    def _health_check(self) -> dict[str, Any]:
        """Return health status."""
        health: dict[str, Any] = {
            "status": "ok",
            "agent_id": self._agent_id,
            "upstream_url": self._upstream_url,
            "require_certificate": getattr(self, "_require_certificate", False),
            "uptime_seconds": time.time() - self._start_time,
            "requests_total": self._request_count,
            "denials_total": self._denial_count,
        }

        # Check upstream connectivity
        try:
            req = urllib.request.Request(self._upstream_url, method="HEAD")
            urllib.request.urlopen(req, timeout=2)
            health["upstream_status"] = "reachable"
        except Exception:
            health["upstream_status"] = "unreachable"
            health["status"] = "degraded"

        return health

    def run(self) -> None:
        """Start the HTTP proxy server."""
        proxy = self
        self._shutting_down = False

        class Handler(BaseHTTPRequestHandler):
            def do_POST(self) -> None:
                request_id = uuid.uuid4().hex[:8]
                proxy._request_count += 1
                proxy._metrics.inc(
                    "nomotic_proxy_requests_total",
                    labels={"agent_id": proxy._agent_id},
                )

                # Certificate verification (if required) — fail fast
                if proxy._require_certificate:
                    agent_id = self._resolve_agent_identity()
                    if agent_id is None:
                        self._respond(403, {
                            "error": "certificate_required",
                            "reason": "No agent identification in request",
                        })
                        return
                    cert_error = proxy._verify_certificate(agent_id)
                    if cert_error:
                        self._respond(403, {
                            "error": "certificate_required",
                            "reason": cert_error,
                        })
                        return

                content_len = int(self.headers.get("Content-Length", 0))
                body = self.rfile.read(content_len)

                try:
                    message = json.loads(body)
                except json.JSONDecodeError:
                    self._respond(400, {"error": "invalid JSON"})
                    return

                if MCPGovernanceProxy._is_tool_call(message):
                    params = message.get("params", {})
                    tool_name = params.get("name", "")
                    tool_args = params.get("arguments", {})
                    target = _extract_target(tool_name, tool_args)

                    proxy._log(
                        "info", "request",
                        tool=tool_name, target=target, request_id=request_id,
                    )

                    response_body = proxy._handle_tool_call_http(message)
                    if response_body is not None:
                        # Governance denied — return denial directly
                        proxy._denial_count += 1
                        proxy._metrics.inc(
                            "nomotic_proxy_denials_total",
                            labels={"agent_id": proxy._agent_id},
                        )
                        self._respond(200, response_body)
                        return

                    # Governance approved — forward with token
                    result = proxy._executor.check(
                        action=tool_name,
                        target=target,
                        params=tool_args,
                    )

                    proxy._log(
                        "info", "verdict",
                        verdict=result.verdict, ucs=result.ucs,
                        request_id=request_id,
                    )

                    forwarded = _attach_governance_token(message, result)
                    upstream_resp = proxy._forward_to_upstream(
                        json.dumps(forwarded).encode(),
                        tool_name=tool_name,
                        request_id=request_id,
                    )
                    self._respond(200, upstream_resp)
                else:
                    proxy._log("debug", "passthrough", request_id=request_id)
                    upstream_resp = proxy._forward_to_upstream(
                        body, request_id=request_id,
                    )
                    self._respond(200, upstream_resp)

            def do_GET(self) -> None:
                if self.path == "/health":
                    health = proxy._health_check()
                    status = 200 if health["status"] == "ok" else 503
                    self._respond(status, health)
                elif self.path == "/metrics":
                    metrics_text = proxy._metrics.format_prometheus()
                    self.send_response(200)
                    self.send_header(
                        "Content-Type", "text/plain; version=0.0.4",
                    )
                    self.send_header(
                        "Content-Length", str(len(metrics_text)),
                    )
                    self.end_headers()
                    self.wfile.write(metrics_text.encode())
                else:
                    self._respond(404, {"error": "not found"})

            def _resolve_agent_identity(self) -> str | None:
                """Extract agent identity from the request."""
                agent_id = self.headers.get("X-Nomotic-Agent-Id")
                if agent_id:
                    return agent_id
                cert_id = self.headers.get("X-Nomotic-Certificate-Id")
                if cert_id:
                    return cert_id
                client_ip = self.client_address[0]
                return proxy._agent_id_map.get(client_ip)

            def _respond(self, status: int, body: Any) -> None:
                self.send_response(status)
                self.send_header("Content-Type", "application/json")
                self.end_headers()
                if isinstance(body, dict):
                    self.wfile.write(json.dumps(body).encode("utf-8"))
                elif isinstance(body, bytes):
                    self.wfile.write(body)
                else:
                    self.wfile.write(str(body).encode("utf-8"))

            def log_message(self, format: str, *log_args: Any) -> None:
                if proxy._log_level == "debug":
                    sys.stderr.write(
                        f"[nomotic-http] {self.address_string()} "
                        f"{format % log_args}\n"
                    )

        server = HTTPServer((self._host, self._port), Handler)

        def _shutdown_handler(signum: int, frame: Any) -> None:
            proxy._log("info", "shutdown_initiated", signal=signum)
            proxy._shutting_down = True
            # Allow 5 seconds for in-flight requests to complete
            threading.Timer(5.0, server.shutdown).start()

        signal.signal(signal.SIGTERM, _shutdown_handler)
        signal.signal(signal.SIGINT, _shutdown_handler)

        self._log(
            "info", "proxy_started",
            host=self._host, port=self._port,
            upstream=self._upstream_url,
            require_certificate=getattr(self, "_require_certificate", False),
        )

        try:
            server.serve_forever()
        finally:
            self._log(
                "info", "proxy_stopped",
                requests_served=self._request_count,
            )
            server.server_close()

    def _handle_tool_call_http(self, message: dict) -> dict | None:
        """Evaluate governance; return denial dict or None if allowed."""
        params = message.get("params", {})
        tool_name = params.get("name", "")
        tool_args = params.get("arguments", {})
        request_id = message.get("id")

        target = _extract_target(tool_name, tool_args)

        result = self._executor.check(
            action=tool_name,
            target=target,
            params=tool_args,
        )

        if self._log_level in ("info", "debug"):
            verdict_str = "ALLOW" if result.allowed else "DENY"
            self._log(
                "info", "governance_verdict",
                tool=tool_name, target=target,
                verdict=verdict_str, trust=result.trust_after,
            )

        if result.allowed:
            return None

        return _build_denial_response(request_id, tool_name, target, result.reason)

    def _forward_to_upstream(
        self,
        body: bytes,
        tool_name: str = "",
        request_id: str = "",
    ) -> Any:
        """Forward a request body to the upstream MCP server and return the response."""
        timeout = self._tool_timeouts.get(tool_name, self._default_timeout)
        req = Request(
            self._upstream_url,
            data=body,
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        t0 = time.time()
        try:
            with urlopen(req, timeout=timeout) as resp:
                latency_seconds = time.time() - t0
                self._metrics.observe(
                    "nomotic_proxy_latency_seconds", latency_seconds,
                )
                self._log(
                    "debug", "forwarded",
                    latency_ms=round(latency_seconds * 1000, 2),
                    request_id=request_id,
                )
                return json.loads(resp.read())
        except (URLError, json.JSONDecodeError) as exc:
            self._metrics.inc(
                "nomotic_proxy_upstream_errors_total",
                labels={"agent_id": self._agent_id},
            )
            self._log(
                "error", "upstream_error",
                error=str(exc), request_id=request_id,
            )
            return {"jsonrpc": "2.0", "error": {"code": -32603, "message": str(exc)}}


# ── Shared helpers (no MCP domain leakage) ────────────────────────────────


def _extract_target(tool_name: str, tool_args: dict) -> str:
    """Extract a governance target from tool call arguments.

    Looks for common resource-identifying keys, then falls back to
    the first string argument value, then the tool name itself.
    """
    for key in ("target", "path", "file", "table", "url", "resource", "database", "uri"):
        if key in tool_args:
            return str(tool_args[key])
    for val in tool_args.values():
        if isinstance(val, str):
            return val
    return tool_name


def _build_denial_response(
    request_id: Any,
    tool_name: str,
    target: str,
    reason: str,
) -> dict:
    """Build a JSON-RPC 2.0 denial response for a governed tool call."""
    return {
        "jsonrpc": "2.0",
        "id": request_id,
        "result": {
            "content": [
                {
                    "type": "text",
                    "text": (
                        f"[GOVERNANCE DENIED] Action '{tool_name}' on '{target}' "
                        f"was denied by Nomotic governance. Reason: {reason}"
                    ),
                }
            ],
            "isError": True,
        },
    }


def _attach_governance_token(message: dict, result: Any) -> dict:
    """Attach Nomotic governance metadata to a forwarded tool call.

    Adds a ``_nomotic`` key inside ``params`` so downstream services
    can verify that governance occurred. Returns a shallow copy of
    the message — the original is not mutated.
    """
    forwarded = dict(message)
    forwarded["params"] = dict(forwarded.get("params", {}))
    forwarded["params"]["_nomotic"] = {
        "governance_token": result.action_id,
        "trust_score": result.trust_after,
        "verdict": result.verdict,
        "timestamp": time.time(),
    }
    return forwarded
