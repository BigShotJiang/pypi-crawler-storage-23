"""Nomotic: Runtime AI Governance for agentic systems."""

__version__ = "0.4.2"

from nomotic.types import (
    Action,
    AgentContext,
    GovernanceOverrideRecord,
    GovernanceVerdict,
    TrustProfile,
    Verdict,
)
from nomotic.dimensions import DimensionRegistry, GovernanceDimension
from nomotic.ucs import UCSEngine
from nomotic.tiers import TierOneGate, TierTwoEvaluator, TierThreeDeliberator
from nomotic.interrupt import InterruptAuthority, InterruptScope
from nomotic.trust import TrustCalibrator
from nomotic.runtime import GovernanceRuntime
from nomotic.keys import SigningKey, VerifyKey
from nomotic.certificate import AgentCertificate, CertificateStatusError, CertStatus, CertVerifyResult, LiveVerifyResult
from nomotic.authority import CertificateAuthority
from nomotic.store import CertificateStore, MemoryCertificateStore, FileCertificateStore
from nomotic.registry import (
    ArchetypeDefinition,
    ArchetypeRegistry,
    FileOrgStore,
    MemoryOrgStore,
    OrganizationRegistry,
    OrgRegistration,
    OrgStatus,
    OrgStore,
    ValidationResult,
    ZoneValidator,
)
from nomotic.sdk import GovernedAgent, GovernedResponse, CertificateLoadError, GovernedRequestError
from nomotic.executor import GovernedToolExecutor, ExecutionResult
from nomotic.async_executor import AsyncGovernedToolExecutor
from nomotic.seal import GovernanceSeal, SealRegistry, SealVerificationResult, seal_action, verify_seal
from nomotic.middleware import NomoticGateway, GatewayConfig, GatewayResult
from nomotic.fingerprint import BehavioralFingerprint, TemporalPattern
from nomotic.priors import ArchetypePrior, TemporalProfile, PriorRegistry
from nomotic.observer import FingerprintObserver
from nomotic.drift import (
    AUDIT_ALARM_DETECTED,
    AmbiguityDriftConfig,
    AmbiguityDriftObserver,
    AmbiguityDriftProfile,
    DriftCalculator,
    DriftScore,
    FeedbackLoopManager,
    UnifiedAgentHealthScore,
    UnifiedHealthScoreCalculator,
    compute_ambiguity_health_score,
    persist_health_events,
)
from nomotic.ucs_tracker import AgentRegistration, UCSTracker
from nomotic.window import SlidingWindow
from nomotic.monitor import DriftMonitor, DriftConfig, DriftAlert
from nomotic.trajectory import TrustTrajectory, TrustEvent
from nomotic.context import ContextCode, CODES
from nomotic.audit import AuditRecord, AuditTrail, build_justification, verify_chain
from nomotic.id_registry import AgentIdRegistry
from nomotic.revocation import create_revocation_seal, load_revocation_seal
from nomotic.audit_store import AuditStore, GovernanceHealthRecord, GovernanceHealthStore, PersistentAuditRecord
from nomotic.doctor import DoctorCheck, DoctorReport, run_doctor
from nomotic.provenance import ProvenanceRecord, ProvenanceLog
from nomotic.accountability import (
    OwnerActivity,
    OwnerActivityLog,
    UserActivityTracker,
    UserStats,
)
from nomotic.types import UserContext
from nomotic.protocol import (
    METHODS,
    METHOD_CATEGORIES,
    PROTOCOL_VERSION,
    Assessment,
    AuthorityClaim,
    Condition,
    Denial,
    Escalation,
    GovernanceResponseData,
    Guidance,
    IntendedAction,
    ProtocolVerdict,
    ReasoningArtifact,
    ResponseMetadata,
    validate_artifact,
)
from nomotic.token import GovernanceToken, TokenClaims, TokenValidationResult, TokenValidator
from nomotic.evaluator import (
    EthicalReasoningAssessment,
    EthicalReasoningConfig,
    EvaluatorConfig,
    PostHocAssessment,
    ProtocolEvaluator,
)
from nomotic.equity import (
    AnonymizationPolicy,
    AnonymizationRule,
    DisparityFinding,
    EquityAnalyzer,
    EquityConfig,
    EquityReport,
    EquityThreshold,
    GroupOutcome,
    ProtectedAttribute,
    ProxyAlert,
)
from nomotic.bias import (
    BiasDetector,
    GovernanceBiasReport,
    RuleBiasAssessment,
    StructuralConcern,
)
from nomotic.cross_dimensional import (
    CROSS_DIMENSIONAL_PATTERNS,
    CrossDimensionalDetector,
    CrossDimensionalReport,
    CrossDimensionalSignal,
)
from nomotic.contextual_modifier import (
    ContextConstraint,
    ContextModification,
    ContextRiskSignal,
    ContextualModifier,
    ModifierConfig,
    WeightAdjustment,
)
from nomotic.workflow_governor import (
    CompoundAuthorityFlag,
    ConsequenceProjector,
    DependencyGraph,
    DriftAcrossSteps,
    OrderingConcern,
    ProjectedRisk,
    StepAssessment,
    WorkflowGovernor,
    WorkflowGovernorConfig,
    WorkflowRiskAssessment,
    WorkflowRiskFactor,
)
from nomotic.human_drift import (
    DriftThresholds,
    HumanAuditStore,
    HumanDriftCalculator,
    HumanDriftMonitor,
    HumanDriftResult,
    HumanInteractionEvent,
    HumanInteractionProfile,
    RoutingRecommendation,
    TeamOversightMetrics,
)
from nomotic.context_profile import (
    CompletedStep,
    CompoundMethod,
    ContextProfile,
    ContextProfileManager,
    DelegationLink,
    Dependency,
    ExternalContext,
    ExternalSignal,
    FeedbackContext,
    FeedbackRecord,
    HistoricalContext,
    InputContext,
    MetaContext,
    OutcomeRecord,
    OutputContext,
    OutputRecord,
    OverrideRecord,
    PlannedStep,
    RecentVerdict,
    RelationalContext,
    SituationalContext,
    TemporalContext,
    TemporalEvent,
    WorkflowContext,
)
from nomotic.reversibility import (
    CommitPointDetector,
    ReversibilityAssessment,
    ReversibilityLevel,
)
from nomotic.llm_deliberator import (
    LLMDeliberationConfig,
    LLMDeliberator,
    LLMProviderConfig,
    LLMResponse,
)
from nomotic.sanitize import (
    SanitizationPolicy,
    Sanitizer,
    sanitize_audit_record,
    sanitize_for_export,
    sanitize_reasoning_artifact,
)
from nomotic.otel_exporter import NomoticOtelExporter, PrometheusMetrics
from nomotic.siem import SIEMExporter
from nomotic.integrations.agicomply import AGICOMPLYClient, AGICOMPLYConfig, AGICOMPLYError
from nomotic.mcp_proxy import MCPGovernanceProxy, MCPHTTPGovernanceProxy
from nomotic.proxy import GovernanceProxyHandler, METHOD_ACTION_MAP, start_proxy
from nomotic.presets import (
    PRESET_DISCLAIMER,
    GovernancePreset,
    get_preset,
    get_preset_names,
    list_compliance_presets,
    list_presets,
    list_severity_presets,
    merge_presets,
)
from nomotic.config_loader import GovernanceConfig, load_governance_config
from nomotic.org_governance import (
    OrgGovernanceConfig,
    OrgViolation,
    enforce_org_policy,
    generate_org_config_from_preset,
    load_org_config,
    save_org_config,
)
from nomotic.loop_detector import LoopDetector, LoopDetectorConfig, LoopEvent
from nomotic.cost import CostProfile, CostTracker
from nomotic.evidence import (
    ControlMapping,
    EvidenceBundle,
    EvidenceBundleGenerator,
    HIPAA_MAPPINGS,
    ISO27001_MAPPINGS,
    PCI_DSS_MAPPINGS,
    SOC2_MAPPINGS,
)
from nomotic.delegation import DelegationRecord, DelegationTracker
from nomotic.policy import PolicyEngine, PolicyLoadError, PolicyResult, PolicyRule
from nomotic.webhooks import (
    WebhookConfig,
    WebhookDispatcher,
    WebhookEvent,
    WEBHOOK_EVENT_TYPES,
)
from nomotic.compliance_report import (
    ComplianceReport,
    ComplianceReportGenerator,
)

__all__ = [
    "Action",
    "AgentContext",
    "GovernanceOverrideRecord",
    "GovernanceVerdict",
    "TrustProfile",
    "Verdict",
    "DimensionRegistry",
    "GovernanceDimension",
    "UCSEngine",
    "TierOneGate",
    "TierTwoEvaluator",
    "TierThreeDeliberator",
    "InterruptAuthority",
    "InterruptScope",
    "TrustCalibrator",
    "GovernanceRuntime",
    "SigningKey",
    "VerifyKey",
    "AgentCertificate",
    "CertificateStatusError",
    "CertStatus",
    "CertVerifyResult",
    "LiveVerifyResult",
    "CertificateAuthority",
    "CertificateStore",
    "MemoryCertificateStore",
    "FileCertificateStore",
    "ArchetypeDefinition",
    "ArchetypeRegistry",
    "FileOrgStore",
    "MemoryOrgStore",
    "OrganizationRegistry",
    "OrgRegistration",
    "OrgStatus",
    "OrgStore",
    "ValidationResult",
    "ZoneValidator",
    "GovernedAgent",
    "GovernedResponse",
    "CertificateLoadError",
    "GovernedRequestError",
    "GovernedToolExecutor",
    "ExecutionResult",
    "AsyncGovernedToolExecutor",
    "NomoticGateway",
    "GatewayConfig",
    "GatewayResult",
    "BehavioralFingerprint",
    "TemporalPattern",
    "ArchetypePrior",
    "TemporalProfile",
    "PriorRegistry",
    "FingerprintObserver",
    "AUDIT_ALARM_DETECTED",
    "AmbiguityDriftConfig",
    "AmbiguityDriftObserver",
    "AmbiguityDriftProfile",
    "DriftCalculator",
    "DriftScore",
    "FeedbackLoopManager",
    "UnifiedAgentHealthScore",
    "UnifiedHealthScoreCalculator",
    "compute_ambiguity_health_score",
    "persist_health_events",
    "AgentRegistration",
    "UCSTracker",
    "SlidingWindow",
    "DriftMonitor",
    "DriftConfig",
    "DriftAlert",
    "TrustTrajectory",
    "TrustEvent",
    "ContextCode",
    "CODES",
    "AuditRecord",
    "AuditTrail",
    "build_justification",
    "verify_chain",
    "AgentIdRegistry",
    "create_revocation_seal",
    "load_revocation_seal",
    "AuditStore",
    "GovernanceHealthRecord",
    "GovernanceHealthStore",
    "PersistentAuditRecord",
    # Doctor (Governance Infrastructure Diagnostics)
    "DoctorCheck",
    "DoctorReport",
    "run_doctor",
    "ProvenanceRecord",
    "ProvenanceLog",
    "OwnerActivity",
    "OwnerActivityLog",
    "UserActivityTracker",
    "UserStats",
    "UserContext",
    # Nomotic Protocol (Phase 6)
    "METHODS",
    "METHOD_CATEGORIES",
    "PROTOCOL_VERSION",
    "Assessment",
    "AuthorityClaim",
    "Condition",
    "Denial",
    "Escalation",
    "GovernanceResponseData",
    "Guidance",
    "IntendedAction",
    "ProtocolVerdict",
    "ReasoningArtifact",
    "ResponseMetadata",
    "validate_artifact",
    "GovernanceToken",
    "TokenClaims",
    "TokenValidationResult",
    "TokenValidator",
    "EthicalReasoningAssessment",
    "EthicalReasoningConfig",
    "EvaluatorConfig",
    "PostHocAssessment",
    "ProtocolEvaluator",
    # Equity Analysis (Phase 8)
    "AnonymizationPolicy",
    "AnonymizationRule",
    "DisparityFinding",
    "EquityAnalyzer",
    "EquityConfig",
    "EquityReport",
    "EquityThreshold",
    "GroupOutcome",
    "ProtectedAttribute",
    "ProxyAlert",
    # Bias Detection (Phase 8)
    "BiasDetector",
    "GovernanceBiasReport",
    "RuleBiasAssessment",
    "StructuralConcern",
    # Cross-Dimensional Signals (Phase 8)
    "CROSS_DIMENSIONAL_PATTERNS",
    "CrossDimensionalDetector",
    "CrossDimensionalReport",
    "CrossDimensionalSignal",
    # Contextual Modifier (Phase 7B)
    "ContextConstraint",
    "ContextModification",
    "ContextRiskSignal",
    "ContextualModifier",
    "ModifierConfig",
    "WeightAdjustment",
    # Workflow Governor (Phase 7C)
    "CompoundAuthorityFlag",
    "ConsequenceProjector",
    "DependencyGraph",
    "DriftAcrossSteps",
    "OrderingConcern",
    "ProjectedRisk",
    "StepAssessment",
    "WorkflowGovernor",
    "WorkflowGovernorConfig",
    "WorkflowRiskAssessment",
    "WorkflowRiskFactor",
    # Human Drift Detection (Bidirectional Oversight)
    "DriftThresholds",
    "HumanAuditStore",
    "HumanDriftCalculator",
    "HumanDriftMonitor",
    "HumanDriftResult",
    "HumanInteractionEvent",
    "HumanInteractionProfile",
    "RoutingRecommendation",
    "TeamOversightMetrics",
    # OpenTelemetry / Prometheus (Observability)
    "NomoticOtelExporter",
    "PrometheusMetrics",
    # SIEM Exporter
    "SIEMExporter",
    # AGICOMPLY Integration
    "AGICOMPLYClient",
    "AGICOMPLYConfig",
    "AGICOMPLYError",
    # Context Profiles (Phase 7A)
    "CompletedStep",
    "CompoundMethod",
    "ContextProfile",
    "ContextProfileManager",
    "DelegationLink",
    "Dependency",
    "ExternalContext",
    "ExternalSignal",
    "FeedbackContext",
    "FeedbackRecord",
    "HistoricalContext",
    "InputContext",
    "MetaContext",
    "OutcomeRecord",
    "OutputContext",
    "OutputRecord",
    "OverrideRecord",
    "PlannedStep",
    "RecentVerdict",
    "RelationalContext",
    "SituationalContext",
    "TemporalContext",
    "TemporalEvent",
    "WorkflowContext",
    # Reversibility-Aware Governance
    "CommitPointDetector",
    "ReversibilityAssessment",
    "ReversibilityLevel",
    # Multi-Model LLM Deliberator
    "LLMDeliberationConfig",
    "LLMDeliberator",
    "LLMProviderConfig",
    "LLMResponse",
    # Data Sanitization
    "SanitizationPolicy",
    "Sanitizer",
    "sanitize_audit_record",
    "sanitize_for_export",
    "sanitize_reasoning_artifact",
    # MCP Governance Proxy
    "MCPGovernanceProxy",
    "MCPHTTPGovernanceProxy",
    # HTTP Governance Proxy
    "GovernanceProxyHandler",
    "METHOD_ACTION_MAP",
    "start_proxy",
    # Compliance Presets
    "PRESET_DISCLAIMER",
    "GovernancePreset",
    "get_preset",
    "get_preset_names",
    "list_compliance_presets",
    "list_presets",
    "list_severity_presets",
    "merge_presets",
    # YAML Config Loader
    "GovernanceConfig",
    "load_governance_config",
    # Organization Governance
    "OrgGovernanceConfig",
    "OrgViolation",
    "enforce_org_policy",
    "generate_org_config_from_preset",
    "load_org_config",
    "save_org_config",
    # Compliance Evidence Bundles
    "ControlMapping",
    "EvidenceBundle",
    "EvidenceBundleGenerator",
    "HIPAA_MAPPINGS",
    "ISO27001_MAPPINGS",
    "PCI_DSS_MAPPINGS",
    "SOC2_MAPPINGS",
    # Governance Seal (Commit-Time Authority Binding)
    "GovernanceSeal",
    "SealRegistry",
    "SealVerificationResult",
    "seal_action",
    "verify_seal",
    # Loop Detection Monitor
    "LoopDetector",
    "LoopDetectorConfig",
    "LoopEvent",
    # Cost Projection & Monitoring
    "CostProfile",
    "CostTracker",
    # Compliance Report Generator
    "ComplianceReport",
    "ComplianceReportGenerator",
    # Multi-Agent Handoff Reporting (Delegation)
    "DelegationRecord",
    "DelegationTracker",
    # Policy-as-Code
    "PolicyEngine",
    "PolicyLoadError",
    "PolicyResult",
    "PolicyRule",
    # Governance Event Webhooks
    "WebhookConfig",
    "WebhookDispatcher",
    "WebhookEvent",
    "WEBHOOK_EVENT_TYPES",
]
