"""Multi-Agent Handoff Reporting — delegation chain tracking.

When Agent A delegates work to Agent B, this module captures the
delegation chain: who delegated, under what authority, and whether
Agent B's certificate authorizes the delegated scope.

Delegations are session-scoped (in-memory) for v0.4.0. Each delegation
produces a DelegationRecord that can be written to the audit trail.
"""

from __future__ import annotations

import time
import uuid
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

__all__ = [
    "DelegationRecord",
    "DelegationTracker",
]


@dataclass
class DelegationRecord:
    """Record of an inter-agent delegation."""

    delegation_id: str  # Format: "nmd-<uuid4>"
    from_agent: str  # Delegating agent ID
    to_agent: str  # Receiving agent ID
    delegated_scope: set[str]  # Action types being delegated (e.g., {"read", "write"})
    delegated_targets: set[str]  # Targets being delegated (e.g., {"customers/*"})
    authority_basis: str  # Why from_agent can delegate ("certificate", "human_override")
    timestamp: float = field(default_factory=time.time)
    seal_id: str | None = None  # Governance seal for the delegation action itself
    expires_at: float | None = None  # When this delegation expires (None = session-scoped)
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "delegation_id": self.delegation_id,
            "from_agent": self.from_agent,
            "to_agent": self.to_agent,
            "delegated_scope": sorted(self.delegated_scope),
            "delegated_targets": sorted(self.delegated_targets),
            "authority_basis": self.authority_basis,
            "timestamp": self.timestamp,
            "seal_id": self.seal_id,
            "expires_at": self.expires_at,
            "metadata": self.metadata,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> DelegationRecord:
        data = dict(data)
        data["delegated_scope"] = set(data.get("delegated_scope", []))
        data["delegated_targets"] = set(data.get("delegated_targets", []))
        return cls(**{k: v for k, v in data.items() if k in cls.__dataclass_fields__})

    def is_expired(self) -> bool:
        if self.expires_at is None:
            return False
        return time.time() > self.expires_at


class DelegationTracker:
    """Tracks inter-agent delegations.

    Validates that delegating agents hold the scope they're delegating,
    and that receiving agents have valid certificates.
    """

    def __init__(self, cert_store: Any = None, base_dir: Path | None = None):
        self._cert_store = cert_store
        self._base_dir = base_dir or Path.home() / ".nomotic"
        # Active delegations: to_agent -> list of DelegationRecords
        self._active: dict[str, list[DelegationRecord]] = {}
        # History: all delegations ever created
        self._history: list[DelegationRecord] = []

    def delegate(
        self,
        from_agent: str,
        to_agent: str,
        scope: set[str],
        targets: set[str],
        *,
        authority_basis: str = "certificate",
        seal_id: str | None = None,
        expires_at: float | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> DelegationRecord:
        """Create a delegation from one agent to another.

        Validates:
        1. from_agent has a valid certificate
        2. to_agent has a valid certificate
        3. from_agent holds the scope being delegated (scope is subset of from_agent's allowed actions)

        Raises:
            ValueError: If validation fails
        """
        # Validate certificates
        self._validate_certificate(from_agent, "delegating")
        self._validate_certificate(to_agent, "receiving")

        # Validate scope (from_agent can only delegate what it holds)
        self._validate_scope(from_agent, scope)

        record = DelegationRecord(
            delegation_id=f"nmd-{uuid.uuid4()}",
            from_agent=from_agent,
            to_agent=to_agent,
            delegated_scope=scope,
            delegated_targets=targets,
            authority_basis=authority_basis,
            seal_id=seal_id,
            expires_at=expires_at,
            metadata=metadata or {},
        )

        if to_agent not in self._active:
            self._active[to_agent] = []
        self._active[to_agent].append(record)
        self._history.append(record)

        return record

    def get_active_delegations(self, agent_id: str) -> list[DelegationRecord]:
        """Get active (non-expired) delegations TO this agent."""
        self._evict_expired(agent_id)
        return list(self._active.get(agent_id, []))

    def get_delegations_from(self, agent_id: str) -> list[DelegationRecord]:
        """Get all delegations FROM this agent (active and historical)."""
        return [d for d in self._history if d.from_agent == agent_id]

    def get_delegation_chain(self, agent_id: str) -> list[DelegationRecord]:
        """Trace the full delegation chain for an agent.

        If A delegated to B and B delegated to C, calling this for C
        returns [A->B delegation, B->C delegation].
        """
        chain: list[DelegationRecord] = []
        visited: set[str] = set()
        current = agent_id
        while current not in visited:
            visited.add(current)
            delegations = self.get_active_delegations(current)
            if not delegations:
                break
            # Take most recent delegation
            latest = max(delegations, key=lambda d: d.timestamp)
            chain.insert(0, latest)
            current = latest.from_agent
        return chain

    def has_delegated_scope(self, agent_id: str, action_type: str, target: str) -> bool:
        """Check if an agent has been delegated scope for this action+target."""
        for delegation in self.get_active_delegations(agent_id):
            if action_type in delegation.delegated_scope:
                if self._target_matches(target, delegation.delegated_targets):
                    return True
        return False

    def _validate_certificate(self, agent_id: str, role: str) -> None:
        """Validate agent has an active certificate."""
        if self._cert_store is None:
            return  # No store = no validation
        from nomotic.certificate import CertStatus

        all_certs = self._cert_store.list(status=CertStatus.ACTIVE)
        active = [c for c in all_certs if c.agent_id == agent_id]
        if not active:
            raise ValueError(f"Cannot {role}: agent '{agent_id}' has no active certificate")

    def _validate_scope(self, agent_id: str, scope: set[str]) -> None:
        """Validate agent holds the scope being delegated.

        For now, this checks the agent's archetype-based scope if available.
        If no scope information is available, validation passes (permissive default).
        """
        # Scope validation is best-effort — if we can't determine the agent's scope,
        # we allow the delegation. The governance evaluation will catch unauthorized
        # actions when the receiving agent tries to execute.
        pass

    def _target_matches(self, target: str, delegated_targets: set[str]) -> bool:
        """Check if a target matches any of the delegated target patterns."""
        for pattern in delegated_targets:
            if pattern == "*":
                return True
            if pattern.endswith("/*"):
                prefix = pattern[:-2]
                if target.startswith(prefix):
                    return True
            if target == pattern:
                return True
        return False

    def _evict_expired(self, agent_id: str) -> None:
        """Remove expired delegations."""
        if agent_id in self._active:
            self._active[agent_id] = [
                d for d in self._active[agent_id] if not d.is_expired()
            ]
