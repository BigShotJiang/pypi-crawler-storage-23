"""Governance Seal — cryptographically signed authorization artifact.

A governance seal is an immutable proof that governance approved an action.
It is produced when a GovernanceVerdict is ALLOW and carries the full
authorization context: who, what, when, why, and under what conditions.

The seal travels with the action and proves to any third party that
governance occurred, who authorized it, and under what conditions.

Certificate Cross-Verification (v0.4.0):
The seal embeds the issuing agent's certificate fingerprint in the signed
payload. Validation verifies the certificate is still ACTIVE in the store,
creating a chained root of trust: Birth Certificate → Governance Seal.

Design constraints:
- Zero new dependencies (stdlib only: json, base64, uuid, time)
- Uses the existing SigningKey/VerifyKey HMAC-SHA256 backend from keys.py
- Importable independently — no circular imports
- Deterministic canonical form for signing and verification
"""

from __future__ import annotations

import base64
import json
import time
import uuid
from dataclasses import dataclass, field
from typing import Any, TYPE_CHECKING

if TYPE_CHECKING:
    from nomotic.certificate import AgentCertificate
    from nomotic.keys import SigningKey, VerifyKey
    from nomotic.store import CertificateStore
    from nomotic.audit import AuditTrail
    from nomotic.types import GovernanceVerdict

__all__ = [
    "GovernanceSeal",
    "SealRegistry",
    "SealVerificationResult",
    "seal_action",
    "verify_seal",
]


@dataclass
class GovernanceSeal:
    """Cryptographically signed, timestamped authorization artifact.

    Produced when governance approves an action. The seal is the proof
    artifact that regulators ask for — it proves governance occurred,
    who authorized it, and under what conditions.
    """

    # Identity
    seal_id: str  # Format: "nms-<uuid4>"
    action_id: str  # From the GovernanceVerdict
    agent_id: str  # Who was authorized
    verdict: str  # Always "ALLOW" — seals only produced for approvals

    # Governance scores
    ucs: float  # Unified confidence score at authorization time
    tier: int  # Which tier decided (1, 2, or 3)
    dimension_summary: dict[str, float]  # dimension_name → score
    vetoed_by: list[str]  # Should be empty for ALLOW

    # Authority chain
    agent_owner: str  # Human responsible (from birth certificate)
    organization: str  # Org from birth certificate
    preset: str  # Governance preset in effect (or "default")
    risk_tier: str  # "low", "moderate", "high", "critical"
    org_policy_hash: str  # SHA256 of org-governance.yaml (or "" if none)

    # Conditions
    trust_level: float  # Agent trust at authorization time
    reversibility: str  # From ReversibilityAssessment.level.value

    # Temporal
    issued_at: float  # time.time() epoch
    expires_at: float  # issued_at + ttl_seconds
    ttl_seconds: int  # How long this seal lives

    # Cryptographic
    signature: bytes  # Signed by issuer key
    issuer_fingerprint: str  # Which key signed this

    # Certificate binding (cross-verification, v0.4.0)
    cert_id: str = ""  # certificate_id from the agent's Birth Certificate
    cert_fingerprint: str = ""  # fingerprint from the Birth Certificate

    def canonical_bytes(self) -> bytes:
        """Produce the canonical JSON bytes for signing and verification.

        Deterministic: sorted keys, compact separators, UTF-8.
        Excludes 'signature' and 'issuer_fingerprint' from the canonical dict.
        Converts bytes fields to base64 strings in the canonical form.
        """
        d = self._canonical_dict()
        return json.dumps(d, sort_keys=True, separators=(",", ":")).encode("utf-8")

    def _canonical_dict(self) -> dict[str, Any]:
        """Build the dict used for canonical serialization (excludes crypto fields).

        Certificate binding fields (cert_id, cert_fingerprint) are included
        in the signed payload when present, so they cannot be tampered with.
        """
        d: dict[str, Any] = {
            "seal_id": self.seal_id,
            "action_id": self.action_id,
            "agent_id": self.agent_id,
            "verdict": self.verdict,
            "ucs": self.ucs,
            "tier": self.tier,
            "dimension_summary": self.dimension_summary,
            "vetoed_by": self.vetoed_by,
            "agent_owner": self.agent_owner,
            "organization": self.organization,
            "preset": self.preset,
            "risk_tier": self.risk_tier,
            "org_policy_hash": self.org_policy_hash,
            "trust_level": self.trust_level,
            "reversibility": self.reversibility,
            "issued_at": self.issued_at,
            "expires_at": self.expires_at,
            "ttl_seconds": self.ttl_seconds,
        }
        # Include certificate binding in signed payload when present
        if self.cert_id:
            d["cert_id"] = self.cert_id
        if self.cert_fingerprint:
            d["cert_fingerprint"] = self.cert_fingerprint
        return d

    def verify(self, verify_key: VerifyKey) -> bool:
        """Verify the seal's signature and check expiration.

        Returns True only if the signature is valid AND the seal
        has not expired.
        """
        if self.is_expired():
            return False
        canonical = self.canonical_bytes()
        return verify_key.verify(self.signature, canonical)

    def is_expired(self) -> bool:
        """Check whether this seal has expired."""
        return time.time() >= self.expires_at

    def to_dict(self) -> dict[str, Any]:
        """Convert to a JSON-serializable dict. Signature as base64."""
        d = self._canonical_dict()
        d["signature"] = base64.b64encode(self.signature).decode("ascii")
        d["issuer_fingerprint"] = self.issuer_fingerprint
        # Always include cert binding fields in serialized form
        if "cert_id" not in d:
            d["cert_id"] = self.cert_id
        if "cert_fingerprint" not in d:
            d["cert_fingerprint"] = self.cert_fingerprint
        return d

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> GovernanceSeal:
        """Reconstruct a GovernanceSeal from a dict (inverse of to_dict)."""
        sig = data["signature"]
        if isinstance(sig, str):
            sig = base64.b64decode(sig)
        return cls(
            seal_id=data["seal_id"],
            action_id=data["action_id"],
            agent_id=data["agent_id"],
            verdict=data["verdict"],
            ucs=data["ucs"],
            tier=data["tier"],
            dimension_summary=data["dimension_summary"],
            vetoed_by=data["vetoed_by"],
            agent_owner=data["agent_owner"],
            organization=data["organization"],
            preset=data["preset"],
            risk_tier=data["risk_tier"],
            org_policy_hash=data["org_policy_hash"],
            trust_level=data["trust_level"],
            reversibility=data["reversibility"],
            issued_at=data["issued_at"],
            expires_at=data["expires_at"],
            ttl_seconds=data["ttl_seconds"],
            signature=sig,
            issuer_fingerprint=data["issuer_fingerprint"],
            cert_id=data.get("cert_id", ""),
            cert_fingerprint=data.get("cert_fingerprint", ""),
        )

    def to_compact(self) -> str:
        """Base64url-encode the JSON dict for HTTP header transport."""
        json_bytes = json.dumps(self.to_dict(), sort_keys=True, separators=(",", ":")).encode("utf-8")
        return base64.urlsafe_b64encode(json_bytes).decode("ascii").rstrip("=")

    @classmethod
    def from_compact(cls, compact_str: str) -> GovernanceSeal:
        """Reconstruct from a compact base64url string (inverse of to_compact)."""
        # Restore padding
        padding = 4 - (len(compact_str) % 4)
        if padding != 4:
            compact_str += "=" * padding
        json_bytes = base64.urlsafe_b64decode(compact_str)
        data = json.loads(json_bytes)
        return cls.from_dict(data)


@dataclass
class SealVerificationResult:
    """Result of seal verification including certificate cross-verification.

    All new fields have sensible defaults so existing code using only
    the basic fields (valid, expired, error) continues to work.
    """

    valid: bool
    expired: bool = False
    error: str = ""

    # Certificate cross-verification fields
    cert_verified: bool = False
    cert_id: str | None = None
    cert_fingerprint: str | None = None
    cert_status: str | None = None
    cross_verify_error: str | None = None


class SealRegistry:
    """Tracks consumed seals to prevent reuse."""

    def __init__(self, max_entries: int = 10000):
        self._consumed: dict[str, float] = {}  # seal_id -> consumed_at timestamp
        self._max = max_entries

    def consume(self, seal_id: str) -> bool:
        """Mark seal as consumed. Returns False if already consumed."""
        if seal_id in self._consumed:
            return False
        self._consumed[seal_id] = time.time()
        self._evict_expired()
        return True

    def is_consumed(self, seal_id: str) -> bool:
        """Check whether a seal has been consumed."""
        return seal_id in self._consumed

    def _evict_expired(self) -> None:
        """Remove entries older than 1 hour (well past any TTL)."""
        cutoff = time.time() - 3600
        self._consumed = {k: v for k, v in self._consumed.items() if v > cutoff}


def seal_action(
    verdict: GovernanceVerdict,
    context: Any,
    signing_key: SigningKey,
    certificate: AgentCertificate | None = None,
    *,
    ttl_seconds: int = 30,
    preset: str = "default",
    risk_tier: str = "moderate",
    org_policy_hash: str = "",
    cert_store: CertificateStore | None = None,
    require_cert: bool = False,
) -> GovernanceSeal | None:
    """Produce a signed governance seal for an ALLOW verdict.

    Module-level function — keeps seal.py self-contained (not on runtime).

    Returns None if verdict.verdict != Verdict.ALLOW.

    When a certificate is provided (or looked up via cert_store), the seal
    embeds cert_id and cert_fingerprint in the signed payload, creating a
    cryptographic binding between the seal and the agent's identity.

    Args:
        verdict: The GovernanceVerdict to seal.
        context: AgentContext for the agent.
        signing_key: The issuer's SigningKey (from CertificateAuthority).
        certificate: Optional AgentCertificate for authority chain fields.
        ttl_seconds: How long the seal is valid (default 30s).
        preset: Governance preset name in effect.
        risk_tier: Risk tier classification.
        org_policy_hash: SHA256 of org-governance.yaml (or "").
        cert_store: Optional CertificateStore for auto-lookup by agent_id.
        require_cert: If True, raise CertificateStatusError when no active
            certificate is available. Default False for backward compatibility.

    Returns:
        GovernanceSeal if verdict is ALLOW, None otherwise.

    Raises:
        CertificateStatusError: If the certificate is SUSPENDED or REVOKED.
        ValueError: If the certificate's agent_id doesn't match context.agent_id.
    """
    from nomotic.certificate import CertificateStatusError, CertStatus
    from nomotic.types import Verdict

    if verdict.verdict != Verdict.ALLOW:
        return None

    # Auto-lookup certificate from store if not provided
    if certificate is None and cert_store is not None:
        certs = cert_store.list()
        for c in certs:
            if c.agent_id == context.agent_id:
                certificate = c
                break

    # Validate certificate if present
    cert_id = ""
    cert_fingerprint = ""
    if certificate is not None:
        # Check certificate status
        if certificate.status != CertStatus.ACTIVE:
            raise CertificateStatusError(certificate.agent_id, certificate.status)

        # Check agent_id match
        if certificate.agent_id != context.agent_id:
            raise ValueError(
                f"Certificate agent_id '{certificate.agent_id}' does not match "
                f"context agent_id '{context.agent_id}'"
            )

        cert_id = certificate.certificate_id
        cert_fingerprint = certificate.fingerprint

    now = time.time()

    # Extract dimension scores into flat dict
    dimension_summary: dict[str, float] = {}
    if verdict.dimension_scores:
        for ds in verdict.dimension_scores:
            dimension_summary[ds.dimension_name] = ds.score

    # Extract authority chain from certificate
    agent_owner = ""
    organization = ""
    if certificate is not None:
        agent_owner = certificate.owner
        organization = certificate.organization

    # Extract reversibility level
    reversibility = "unknown"
    if verdict.reversibility and isinstance(verdict.reversibility, dict):
        level = verdict.reversibility.get("level", "unknown")
        if isinstance(level, str):
            reversibility = level
        else:
            # It might be an enum value string
            reversibility = str(level)

    # Extract trust level from context
    trust_level = 0.5
    if hasattr(context, "trust_profile") and context.trust_profile is not None:
        trust_level = context.trust_profile.overall_trust

    seal = GovernanceSeal(
        seal_id=f"nms-{uuid.uuid4()}",
        action_id=verdict.action_id,
        agent_id=context.agent_id,
        verdict="ALLOW",
        ucs=verdict.ucs,
        tier=verdict.tier,
        dimension_summary=dimension_summary,
        vetoed_by=list(verdict.vetoed_by) if verdict.vetoed_by else [],
        agent_owner=agent_owner,
        organization=organization,
        preset=preset,
        risk_tier=risk_tier,
        org_policy_hash=org_policy_hash,
        trust_level=trust_level,
        reversibility=reversibility,
        issued_at=now,
        expires_at=now + ttl_seconds,
        ttl_seconds=ttl_seconds,
        signature=b"",  # placeholder — signed below
        issuer_fingerprint="",  # placeholder — set below
        cert_id=cert_id,
        cert_fingerprint=cert_fingerprint,
    )

    # Sign the canonical form (cert_id and cert_fingerprint are included)
    canonical = seal.canonical_bytes()
    seal.signature = signing_key.sign(canonical)
    seal.issuer_fingerprint = signing_key.verify_key().fingerprint()

    return seal


def verify_seal(
    seal: GovernanceSeal,
    verify_key: VerifyKey,
    cert_store: CertificateStore | None = None,
    audit_trail: AuditTrail | None = None,
) -> SealVerificationResult:
    """Verify a governance seal with optional certificate cross-verification.

    Performs:
    1. Expiration check
    2. Signature verification
    3. Certificate cross-verification (if cert binding fields present and store available)

    Cross-verification error codes:
    - CERT_NOT_FOUND: certificate not in store
    - CERT_FINGERPRINT_MISMATCH: fingerprint doesn't match (potential forgery)
    - CERT_NOT_ACTIVE: certificate suspended or revoked since seal issuance
    - CERT_BINDING_INCOMPLETE: only one of cert_id/cert_fingerprint present

    Args:
        seal: The GovernanceSeal to verify.
        verify_key: The issuer's VerifyKey for signature verification.
        cert_store: Optional CertificateStore for cross-verification lookup.
        audit_trail: Optional AuditTrail for recording verification results.

    Returns:
        SealVerificationResult with full verification details.
    """
    from nomotic.certificate import CertStatus

    # Step 1: Expiration check
    if seal.is_expired():
        result = SealVerificationResult(valid=False, expired=True, error="EXPIRED_SEAL")
        _audit_verification(audit_trail, seal, result)
        return result

    # Step 2: Signature verification
    canonical = seal.canonical_bytes()
    if not verify_key.verify(seal.signature, canonical):
        result = SealVerificationResult(valid=False, error="INVALID_SIGNATURE")
        _audit_verification(audit_trail, seal, result)
        return result

    # Step 3: Certificate cross-verification
    has_cert_id = bool(seal.cert_id)
    has_cert_fp = bool(seal.cert_fingerprint)

    if not has_cert_id and not has_cert_fp:
        # Legacy seal without certificate binding — valid but not cert-verified
        result = SealVerificationResult(valid=True, cert_verified=False)
        _audit_verification(audit_trail, seal, result)
        return result

    if has_cert_id != has_cert_fp:
        # Incomplete binding — one field present but not the other
        result = SealVerificationResult(
            valid=False,
            error="CERT_BINDING_INCOMPLETE",
            cert_id=seal.cert_id or None,
            cert_fingerprint=seal.cert_fingerprint or None,
            cross_verify_error="CERT_BINDING_INCOMPLETE",
        )
        _audit_verification(audit_trail, seal, result)
        return result

    # Both cert_id and cert_fingerprint are present — perform cross-verification
    result = SealVerificationResult(
        valid=True,  # signature is valid; may be overridden below
        cert_id=seal.cert_id,
        cert_fingerprint=seal.cert_fingerprint,
    )

    if cert_store is None:
        # No store available — cannot cross-verify, but signature is valid
        result.cert_verified = False
        _audit_verification(audit_trail, seal, result)
        return result

    # Look up the certificate
    cert = cert_store.get(seal.cert_id)
    if cert is None:
        result.valid = False
        result.cert_verified = False
        result.cross_verify_error = "CERT_NOT_FOUND"
        result.error = "CERT_NOT_FOUND"
        _audit_verification(audit_trail, seal, result)
        return result

    result.cert_status = cert.status.name

    # Verify fingerprint match
    if cert.fingerprint != seal.cert_fingerprint:
        result.valid = False
        result.cert_verified = False
        result.cross_verify_error = "CERT_FINGERPRINT_MISMATCH"
        result.error = "CERT_FINGERPRINT_MISMATCH"
        _audit_verification(audit_trail, seal, result)
        return result

    # Verify certificate is still ACTIVE
    if cert.status != CertStatus.ACTIVE:
        result.valid = False
        result.cert_verified = False
        result.cross_verify_error = "CERT_NOT_ACTIVE"
        result.error = "CERT_NOT_ACTIVE"
        _audit_verification(audit_trail, seal, result)
        return result

    # All checks passed
    result.cert_verified = True
    _audit_verification(audit_trail, seal, result)
    return result


def _audit_verification(
    audit_trail: AuditTrail | None,
    seal: GovernanceSeal,
    result: SealVerificationResult,
) -> None:
    """Record seal verification result in the audit trail."""
    if audit_trail is None:
        return

    from nomotic.audit import AuditRecord

    context_code = (
        "SEAL.VERIFY_OK" if result.valid else "SEAL.VERIFY_FAIL"
    )
    severity = "info" if result.valid else "warning"

    metadata: dict[str, Any] = {
        "seal_id": seal.seal_id,
        "cert_verified": result.cert_verified,
    }
    if result.cross_verify_error:
        metadata["cross_verify_error"] = result.cross_verify_error
    if result.cert_id:
        metadata["cert_id"] = result.cert_id
    if result.cert_fingerprint:
        metadata["cert_fingerprint"] = result.cert_fingerprint
    if result.cert_status:
        metadata["cert_status"] = result.cert_status

    record = AuditRecord(
        record_id=f"seal-verify-{uuid.uuid4()}",
        timestamp=time.time(),
        context_code=context_code,
        severity=severity,
        agent_id=seal.agent_id,
        owner_id=seal.agent_owner,
        user_id="",
        action_id=seal.action_id,
        action_type="seal_verification",
        action_target=seal.seal_id,
        verdict=seal.verdict,
        ucs=seal.ucs,
        tier=seal.tier,
        justification=(
            f"Seal verification {'passed' if result.valid else 'failed'}"
            + (f": {result.cross_verify_error}" if result.cross_verify_error else "")
        ),
        metadata=metadata,
    )
    audit_trail.append(record)
