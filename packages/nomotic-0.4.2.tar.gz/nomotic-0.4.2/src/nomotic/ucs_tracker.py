"""UCS score tracker — feeds governance evaluation outputs to AmbiguityDriftObserver.

Connects to GovernanceRuntime.evaluate() results without modifying
the evaluator itself. Called after each evaluation in the audit
recording path.

Also manages delegation chain band inheritance: when a sub-agent is
registered with a principal_agent_id, its ambiguity band is constrained
to be no wider than the principal's current band, with per-hop narrowing.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from nomotic.drift import (
    AUDIT_AMBIGUITY_PROFILE_UPDATE,
    AmbiguityDriftConfig,
    AmbiguityDriftObserver,
    AmbiguityDriftProfile,
)

__all__ = ["AgentRegistration", "UCSTracker"]


@dataclass
class AgentRegistration:
    """Registration record for a governed agent in the UCSTracker."""

    agent_id: str
    config: AmbiguityDriftConfig
    delegation_depth: int = 0  # 0 = root agent, 1 = first-level delegate, etc.
    principal_agent_id: str | None = None  # ID of the delegating principal, if any
    floor_low: float = 0.20  # Archetype floor — band cannot narrow below this
    floor_high: float = 0.80  # Archetype floor — band cannot widen above this


class UCSTracker:
    """Thin wrapper around AmbiguityDriftObserver with per-agent config and
    delegation chain band inheritance.

    Delegation band inheritance:
    - When registering a sub-agent with a principal_agent_id, the sub-agent's
      initial band is constrained to be no wider than the principal's current band.
    - Each delegation hop applies a per-hop narrowing of HOP_NARROWING (0.02)
      to both band_low (raised) and band_high (lowered).
    - This enforces transitive authority constraints without central recomputation:
      register agents in delegation order (principal before sub-agent) and the
      bands propagate automatically.

    Usage::

        tracker = UCSTracker()
        tracker.register_agent(AgentRegistration(agent_id="root", config=cfg))
        tracker.register_agent(AgentRegistration(
            agent_id="sub-1", config=cfg,
            delegation_depth=1, principal_agent_id="root",
        ))
        tracker.record("sub-1", ucs=0.45, verdict="ALLOW")
        profile = tracker.get_profile("sub-1")
        alerts = tracker.get_all_alerts()
    """

    HOP_NARROWING: float = 0.02  # Band narrowing applied per delegation depth level

    def __init__(
        self, default_config: AmbiguityDriftConfig | None = None
    ) -> None:
        self._observer = AmbiguityDriftObserver()
        self._default_config = default_config or AmbiguityDriftConfig()
        self._agent_configs: dict[str, AmbiguityDriftConfig] = {}
        self._registrations: dict[str, AgentRegistration] = {}

    def set_agent_config(
        self, agent_id: str, config: AmbiguityDriftConfig
    ) -> None:
        """Set per-agent configuration."""
        self._agent_configs[agent_id] = config

    def register_agent(self, registration: AgentRegistration) -> AmbiguityDriftConfig:
        """Register an agent, applying delegation band inheritance if principal is set.

        Returns the effective AmbiguityDriftConfig after inheritance adjustments.
        If principal_agent_id is set, the sub-agent's band is constrained to:
            band_low  >= principal_band_low  + (delegation_depth * HOP_NARROWING)
            band_high <= principal_band_high - (delegation_depth * HOP_NARROWING)
        Both constraints are further bounded by the agent's archetype floor.
        """
        effective_low = registration.config.band_low
        effective_high = registration.config.band_high

        if registration.principal_agent_id is not None:
            principal_id = registration.principal_agent_id
            # Try to get principal's current profile (live band values)
            principal_profile = self._observer.get_profile(principal_id)
            if principal_profile is not None:
                principal_low = principal_profile.band_low
                principal_high = principal_profile.band_high
            elif principal_id in self._registrations:
                # Principal registered but not yet observed — use registered config
                principal_reg = self._registrations[principal_id]
                principal_cfg = self._agent_configs.get(
                    principal_id, principal_reg.config
                )
                principal_low = principal_cfg.band_low
                principal_high = principal_cfg.band_high
            else:
                # Principal not registered — fall back to sub-agent's own config
                principal_low = registration.config.band_low
                principal_high = registration.config.band_high

            hop_adj = registration.delegation_depth * self.HOP_NARROWING
            inherited_low = principal_low + hop_adj
            inherited_high = principal_high - hop_adj

            effective_low = max(registration.config.band_low, inherited_low)
            effective_high = min(registration.config.band_high, inherited_high)

            # Apply archetype floor constraint
            effective_low = min(effective_low, registration.floor_low + 0.10)

        # Build effective config
        effective_config = AmbiguityDriftConfig(
            window_size=registration.config.window_size,
            band_low=effective_low,
            band_high=effective_high,
            rise_threshold=registration.config.rise_threshold,
            fall_threshold=registration.config.fall_threshold,
            accept_drift_threshold=registration.config.accept_drift_threshold,
            deny_drift_threshold=registration.config.deny_drift_threshold,
            baseline_ema_alpha=registration.config.baseline_ema_alpha,
        )

        # Store registration and effective config
        self._registrations[registration.agent_id] = registration
        self._agent_configs[registration.agent_id] = effective_config

        return effective_config

    def record(
        self,
        agent_id: str,
        ucs: float,
        verdict: str,
        action_class: str = "substantive",
        was_human_override: bool = False,
    ) -> AmbiguityDriftProfile:
        """Record a single governance evaluation for the agent."""
        cfg = self._agent_configs.get(agent_id, self._default_config)
        return self._observer.observe(
            agent_id=agent_id,
            ucs=ucs,
            verdict=verdict,
            action_class=action_class,
            was_human_override=was_human_override,
            config=cfg,
        )

    def get_profile(self, agent_id: str) -> AmbiguityDriftProfile | None:
        """Get the current ambiguity drift profile for an agent."""
        return self._observer.get_profile(agent_id)

    def get_all_alerts(self) -> list[AmbiguityDriftProfile]:
        """Get all agents with active compound alarms."""
        return self._observer.get_alerts()

    def get_registration(self, agent_id: str) -> AgentRegistration | None:
        """Get the registration record for an agent."""
        return self._registrations.get(agent_id)

    def get_observer(self) -> AmbiguityDriftObserver:
        """Expose underlying observer for direct access."""
        return self._observer

    @property
    def observer(self) -> AmbiguityDriftObserver:
        """Access the underlying observer (for integration with FeedbackLoopManager)."""
        return self._observer

    def get_delegation_chain_bands(
        self, agent_id: str
    ) -> dict[str, tuple[float, float]]:
        """Returns a dict of {agent_id: (band_low, band_high)} for all agents
        in the delegation chain from the given agent up to the root.

        Useful for debugging and compliance reporting.
        """
        chain: dict[str, tuple[float, float]] = {}
        current_id: str | None = agent_id

        while current_id is not None:
            # Get band from live profile if available, else from registered config
            profile = self._observer.get_profile(current_id)
            if profile is not None:
                chain[current_id] = (profile.band_low, profile.band_high)
            elif current_id in self._agent_configs:
                cfg = self._agent_configs[current_id]
                chain[current_id] = (cfg.band_low, cfg.band_high)
            elif current_id in self._registrations:
                reg = self._registrations[current_id]
                chain[current_id] = (reg.config.band_low, reg.config.band_high)
            else:
                break

            # Walk up to principal
            reg = self._registrations.get(current_id)
            if reg is not None and reg.principal_agent_id is not None:
                current_id = reg.principal_agent_id
                # Avoid cycles
                if current_id in chain:
                    break
            else:
                break

        return chain
