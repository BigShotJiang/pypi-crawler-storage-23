"""Multi-Model LLM Deliberator for Tier 3 evaluation.

When governance decisions land in the ambiguous zone (Tier 2 can't decide),
this deliberator optionally consults multiple LLMs and aggregates their
recommendations using weighted consensus.

Design constraints:
- Zero runtime dependencies: LLM callables are injected, not imported.
- No raw parameter values in prompts (PII risk).
- Thread-safe: uses ThreadPoolExecutor for parallel LLM calls.
- Timeout-safe: slow models are excluded from consensus.
- Returns None when disabled or all models fail, letting Tier 3's
  built-in logic handle the case.
"""

from __future__ import annotations

import json
import logging
import re
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field
from typing import Any, Callable

from nomotic.types import (
    Action,
    AgentContext,
    DimensionScore,
    Verdict,
)

__all__ = [
    "LLMDeliberationConfig",
    "LLMDeliberator",
    "LLMProviderConfig",
    "LLMResponse",
]

logger = logging.getLogger(__name__)


@dataclass
class LLMProviderConfig:
    """Configuration for a single LLM provider.

    The ``call`` callable takes a prompt string and returns a response string.
    It is injected by the user — no SDK imports required.
    """

    provider: str
    model: str
    call: Callable[[str], str]
    weight: float = 1.0


@dataclass
class LLMDeliberationConfig:
    """Configuration for multi-model LLM deliberation."""

    enabled: bool = False
    providers: list[LLMProviderConfig] = field(default_factory=list)
    consensus_threshold: float = 0.67
    veto_weight: float = 0.5
    timeout_seconds: float = 30.0
    fallback_verdict: Verdict = field(default=Verdict.ESCALATE)


@dataclass
class LLMResponse:
    """Parsed response from a single LLM provider."""

    provider: str
    model: str
    verdict: Verdict | None = None
    reasoning: str = ""
    raw: str = ""
    error: str | None = None
    weight: float = 1.0


_VERDICT_MAP: dict[str, Verdict] = {
    "ALLOW": Verdict.ALLOW,
    "DENY": Verdict.DENY,
    "MODIFY": Verdict.MODIFY,
    "ESCALATE": Verdict.ESCALATE,
}


class LLMDeliberator:
    """Consults multiple LLMs for Tier 3 governance decisions.

    Implements the Callable signature expected by
    ``TierThreeDeliberator.add_deliberator()``:
        (Action, AgentContext, list[DimensionScore], float) -> Verdict | None

    Usage::

        config = LLMDeliberationConfig(
            enabled=True,
            providers=[
                LLMProviderConfig(
                    provider="openai",
                    model="gpt-4",
                    call=my_openai_call,
                    weight=1.0,
                ),
                LLMProviderConfig(
                    provider="anthropic",
                    model="claude-3",
                    call=my_anthropic_call,
                    weight=1.5,
                ),
            ],
            consensus_threshold=0.67,
            veto_weight=0.5,
            timeout_seconds=30,
        )
        deliberator = LLMDeliberator(config)
        runtime.tier_three.add_deliberator(deliberator)
    """

    PROMPT_TEMPLATE: str = """\
You are a governance evaluator for an AI agent system. An action has landed \
in the ambiguous zone and requires your judgment.

## Action
- Type: {action_type}
- Target: {action_target}
- Parameter keys: {param_keys}

## Dimension Scores
{dimension_scores}

## Unified Confidence Score
- UCS: {ucs:.4f}
- Allow threshold: typically 0.7
- Deny threshold: typically 0.3
- This action fell between thresholds (ambiguous zone).

## Agent Trust
- Overall trust: {trust:.4f}
- Successful actions: {successful_actions}
- Violation count: {violation_count}
- Violation rate: {violation_rate:.4f}

## Behavioral Drift
{drift_status}

## Instructions
Based on the above governance context, provide your verdict.

You MUST respond with EXACTLY this JSON format (no other text):
{{"verdict": "<ALLOW|DENY|MODIFY|ESCALATE>", "reasoning": "<your reasoning>"}}
"""

    def __init__(self, config: LLMDeliberationConfig) -> None:
        self._config = config
        self._lock = threading.Lock()
        self._last_audit: dict[str, Any] | None = None

    @property
    def config(self) -> LLMDeliberationConfig:
        return self._config

    @property
    def last_audit(self) -> dict[str, Any] | None:
        """Most recent audit record from the last deliberation call."""
        with self._lock:
            return self._last_audit

    def __call__(
        self,
        action: Action,
        context: AgentContext,
        scores: list[DimensionScore],
        ucs: float,
    ) -> Verdict | None:
        """Deliberate using configured LLMs.

        Returns the consensus verdict, or None if disabled / all models fail.
        """
        if not self._config.enabled or not self._config.providers:
            return None

        prompt = self._build_prompt(action, context, scores, ucs)
        responses = self._query_all(prompt)

        # Filter out failures
        valid = [r for r in responses if r.verdict is not None]

        if not valid:
            audit = self._build_audit(responses, None, {})
            with self._lock:
                self._last_audit = audit
            return self._config.fallback_verdict if responses else None

        verdict, details = self._aggregate(valid)
        audit = self._build_audit(responses, verdict, details)
        with self._lock:
            self._last_audit = audit

        return verdict

    # ── Prompt construction ──────────────────────────────────────────

    def _build_prompt(
        self,
        action: Action,
        context: AgentContext,
        scores: list[DimensionScore],
        ucs: float,
    ) -> str:
        """Build the governance prompt. No raw parameter values — only keys."""
        # Dimension scores table
        dim_lines = []
        for s in scores:
            dim_lines.append(
                f"- {s.dimension_name}: score={s.score:.4f}, "
                f"weight={s.weight:.2f}, confidence={s.confidence:.2f}"
            )
        dimension_scores = "\n".join(dim_lines) if dim_lines else "- (none)"

        # Trust info
        tp = context.trust_profile

        # Drift status
        drift_status = "- No drift data available"
        drift = context.metadata.get("drift") if context.metadata else None
        if drift is not None:
            if hasattr(drift, "overall"):
                drift_status = (
                    f"- Overall drift: {drift.overall:.4f}\n"
                    f"- Severity: {getattr(drift, 'severity', 'unknown')}"
                )
            elif isinstance(drift, dict):
                drift_status = (
                    f"- Overall drift: {drift.get('overall', 'N/A')}\n"
                    f"- Severity: {drift.get('severity', 'unknown')}"
                )

        # Parameter keys only — never values
        param_keys = list(action.parameters.keys()) if action.parameters else []

        return self.PROMPT_TEMPLATE.format(
            action_type=action.action_type,
            action_target=action.target,
            param_keys=param_keys,
            dimension_scores=dimension_scores,
            ucs=ucs,
            trust=tp.overall_trust,
            successful_actions=tp.successful_actions,
            violation_count=tp.violation_count,
            violation_rate=tp.violation_rate,
            drift_status=drift_status,
        )

    # ── LLM querying ────────────────────────────────────────────────

    def _query_all(self, prompt: str) -> list[LLMResponse]:
        """Send the prompt to all configured LLMs in parallel."""
        responses: list[LLMResponse] = []

        with ThreadPoolExecutor(
            max_workers=len(self._config.providers)
        ) as executor:
            future_to_provider = {
                executor.submit(self._query_one, provider, prompt): provider
                for provider in self._config.providers
            }
            try:
                for future in as_completed(
                    future_to_provider, timeout=self._config.timeout_seconds
                ):
                    provider = future_to_provider[future]
                    try:
                        response = future.result(timeout=0)
                        responses.append(response)
                    except Exception as exc:
                        responses.append(
                            LLMResponse(
                                provider=provider.provider,
                                model=provider.model,
                                error=str(exc),
                                weight=provider.weight,
                            )
                        )
            except TimeoutError:
                # Some futures didn't complete in time — record them as errors
                for future, provider in future_to_provider.items():
                    if not future.done():
                        future.cancel()
                        responses.append(
                            LLMResponse(
                                provider=provider.provider,
                                model=provider.model,
                                error="timeout",
                                weight=provider.weight,
                            )
                        )

        return responses

    def _query_one(
        self, provider: LLMProviderConfig, prompt: str
    ) -> LLMResponse:
        """Query a single LLM and parse the response."""
        try:
            raw = provider.call(prompt)
        except Exception as exc:
            return LLMResponse(
                provider=provider.provider,
                model=provider.model,
                error=str(exc),
                weight=provider.weight,
            )

        return self._parse_response(raw, provider)

    # ── Response parsing ────────────────────────────────────────────

    def _parse_response(
        self, raw: str, provider: LLMProviderConfig
    ) -> LLMResponse:
        """Parse an LLM response string into a structured LLMResponse."""
        verdict = None
        reasoning = ""

        # Try to extract JSON from the response
        cleaned = raw.strip()
        json_match = re.search(r"\{[^{}]*\}", cleaned, re.DOTALL)
        if json_match:
            try:
                parsed = json.loads(json_match.group())
                verdict_str = parsed.get("verdict", "").upper()
                verdict = _VERDICT_MAP.get(verdict_str)
                reasoning = parsed.get("reasoning", "")
            except (json.JSONDecodeError, AttributeError):
                pass

        # If JSON parsing didn't produce a verdict, try text extraction
        if verdict is None:
            upper = raw.upper()
            for name, v in _VERDICT_MAP.items():
                if name in upper:
                    verdict = v
                    reasoning = raw.strip()
                    break

        return LLMResponse(
            provider=provider.provider,
            model=provider.model,
            verdict=verdict,
            reasoning=reasoning,
            raw=raw,
            weight=provider.weight,
        )

    # ── Consensus aggregation ───────────────────────────────────────

    def _aggregate(
        self, responses: list[LLMResponse]
    ) -> tuple[Verdict, dict[str, Any]]:
        """Aggregate LLM responses using weighted consensus.

        Rules:
        1. Veto: If any model recommends DENY and its weight >= veto_weight,
           return DENY immediately.
        2. Consensus: If weighted agreement >= consensus_threshold, return
           the consensus verdict.
        3. No consensus: return ESCALATE.
        """
        total_weight = sum(r.weight for r in responses)
        details: dict[str, Any] = {
            "total_weight": total_weight,
            "response_count": len(responses),
        }

        if total_weight == 0:
            details["reason"] = "zero total weight"
            return Verdict.ESCALATE, details

        # Check for veto: any DENY with weight >= veto_weight
        for r in responses:
            if r.verdict == Verdict.DENY and r.weight >= self._config.veto_weight:
                details["veto_by"] = f"{r.provider}/{r.model}"
                details["veto_weight"] = r.weight
                details["reason"] = "veto"
                return Verdict.DENY, details

        # Count weighted votes per verdict
        votes: dict[Verdict, float] = {}
        for r in responses:
            if r.verdict is not None:
                votes[r.verdict] = votes.get(r.verdict, 0.0) + r.weight

        # Find the verdict with the highest weighted vote
        best_verdict = max(votes, key=lambda v: votes[v])
        best_weight = votes[best_verdict]
        agreement = best_weight / total_weight

        details["votes"] = {v.name: w for v, w in votes.items()}
        details["agreement"] = agreement
        details["threshold"] = self._config.consensus_threshold

        if agreement >= self._config.consensus_threshold:
            details["reason"] = "consensus"
            return best_verdict, details

        details["reason"] = "no_consensus"
        return Verdict.ESCALATE, details

    # ── Audit ───────────────────────────────────────────────────────

    def _build_audit(
        self,
        responses: list[LLMResponse],
        verdict: Verdict | None,
        details: dict[str, Any],
    ) -> dict[str, Any]:
        """Build an audit record of the deliberation."""
        return {
            "verdict": verdict.name if verdict is not None else None,
            "consensus_details": details,
            "responses": [
                {
                    "provider": r.provider,
                    "model": r.model,
                    "verdict": r.verdict.name if r.verdict else None,
                    "reasoning": r.reasoning,
                    "error": r.error,
                    "weight": r.weight,
                }
                for r in responses
            ],
            "dissenting": [
                {
                    "provider": r.provider,
                    "model": r.model,
                    "verdict": r.verdict.name if r.verdict else None,
                    "reasoning": r.reasoning,
                }
                for r in responses
                if r.verdict is not None
                and verdict is not None
                and r.verdict != verdict
            ],
        }
