"""Governance Event Webhooks — push governance events to external systems.

Nomotic (L5 runtime governance) feeds events to operating governance (L2)
and outcome monitoring (L6) systems via HTTP webhooks.  Enables integration
with Slack, PagerDuty, SIEM systems, and custom monitoring.

Fire-and-forget delivery with optional retry.  Webhook failures are logged
but never block governance operations.

Configuration example (JSON or YAML)::

    {
      "webhooks": [
        {"url": "https://hooks.slack.com/...", "events": ["DENY", "SUSPEND"]},
        {"url": "https://pagerduty.com/...", "events": ["SUSPEND", "TRUST_DROP"]}
      ]
    }
"""

from __future__ import annotations

import json
import time
import urllib.request
from dataclasses import dataclass, field
from typing import Any


# ── Valid event types ────────────────────────────────────────────────

WEBHOOK_EVENT_TYPES = {
    "DENY",              # Action denied by governance
    "SUSPEND",           # Agent certificate suspended
    "DRIFT_ALERT",       # Behavioral drift detected
    "TRUST_DROP",        # Trust score dropped below threshold
    "SEAL_EXPIRED",      # A seal expired (should not happen with enforcement)
    "OVERRIDE_APPROVE",  # Human overrode a denial
    "OVERRIDE_REVOKE",   # Human revoked an approval
    "CHAIN_BREAK",       # Audit hash chain integrity failure
    "LOOP_DETECTED",     # Loop/doom loop detected
}


# ── Data classes ─────────────────────────────────────────────────────

@dataclass
class WebhookConfig:
    """Configuration for a single webhook endpoint."""

    url: str
    events: list[str]            # Event types to subscribe to
    format: str = "json"         # "json" only for now
    timeout_seconds: float = 5.0
    max_retries: int = 1
    enabled: bool = True


@dataclass
class WebhookEvent:
    """A governance event to be delivered via webhook."""

    event_type: str              # DENY, SUSPEND, DRIFT_ALERT, TRUST_DROP, etc.
    event_id: str                # Unique ID for this event
    timestamp: float
    agent_id: str
    payload: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "event_type": self.event_type,
            "event_id": self.event_id,
            "timestamp": self.timestamp,
            "agent_id": self.agent_id,
            "payload": self.payload,
            "source": "nomotic",
            "version": "0.4.0",
        }


# ── Rate limiter ─────────────────────────────────────────────────────

class _RateLimiter:
    """Simple token bucket rate limiter — max N events/second."""

    def __init__(self, max_per_second: int = 10) -> None:
        self._max = max_per_second
        self._tokens: list[float] = []

    def allow(self) -> bool:
        now = time.time()
        self._tokens = [t for t in self._tokens if now - t < 1.0]
        if len(self._tokens) >= self._max:
            return False
        self._tokens.append(now)
        return True


# ── Webhook dispatcher ───────────────────────────────────────────────

class WebhookDispatcher:
    """Dispatches governance events to configured webhook endpoints.

    Fire-and-forget delivery with optional retry.  Webhook failures
    are logged but do not block governance operations.
    """

    def __init__(self, webhooks: list[WebhookConfig] | None = None) -> None:
        self._webhooks = webhooks or []
        self._rate_limiters: dict[str, _RateLimiter] = {}
        # Delivery stats
        self._delivered: int = 0
        self._failed: int = 0
        self._last_errors: list[dict[str, Any]] = []  # Last 10 errors

    @classmethod
    def from_config(cls, config: dict[str, Any]) -> WebhookDispatcher:
        """Create from configuration dict (e.g., from YAML config).

        Expected format::

            {
                "webhooks": [
                    {"url": "https://...", "events": ["DENY", "SUSPEND"]},
                    {"url": "https://...", "events": ["TRUST_DROP"]}
                ]
            }
        """
        hooks: list[WebhookConfig] = []
        for hook_data in config.get("webhooks", []):
            if not isinstance(hook_data, dict):
                continue
            url = hook_data.get("url")
            if not url:
                continue
            hooks.append(WebhookConfig(
                url=url,
                events=hook_data.get("events", []),
                format=hook_data.get("format", "json"),
                timeout_seconds=hook_data.get("timeout_seconds", 5.0),
                max_retries=hook_data.get("max_retries", 1),
                enabled=hook_data.get("enabled", True),
            ))
        return cls(hooks)

    def dispatch(self, event: WebhookEvent) -> None:
        """Dispatch an event to all subscribed webhooks.

        Fire-and-forget.  Failures are logged but do not raise.
        Rate limited to 10 events/second per endpoint.
        """
        for webhook in self._webhooks:
            if not webhook.enabled:
                continue
            if event.event_type not in webhook.events:
                continue
            if not self._check_rate_limit(webhook.url):
                continue

            self._send(webhook, event)

    def _send(self, webhook: WebhookConfig, event: WebhookEvent) -> None:
        """Send event to a single webhook endpoint."""
        payload = json.dumps(event.to_dict()).encode("utf-8")

        for attempt in range(1 + webhook.max_retries):
            try:
                req = urllib.request.Request(
                    webhook.url,
                    data=payload,
                    method="POST",
                    headers={
                        "Content-Type": "application/json",
                        "User-Agent": "nomotic-webhook/0.4.0",
                        "X-Nomotic-Event": event.event_type,
                        "X-Nomotic-Event-Id": event.event_id,
                    },
                )
                with urllib.request.urlopen(req, timeout=webhook.timeout_seconds) as resp:
                    if resp.status < 300:
                        self._delivered += 1
                        return
            except Exception as e:
                if attempt == webhook.max_retries:
                    self._failed += 1
                    error = {
                        "url": webhook.url,
                        "event_type": event.event_type,
                        "error": str(e),
                        "timestamp": time.time(),
                    }
                    self._last_errors.append(error)
                    if len(self._last_errors) > 10:
                        self._last_errors = self._last_errors[-10:]

    def _check_rate_limit(self, url: str) -> bool:
        """Rate limit: max 10 events/second per endpoint."""
        if url not in self._rate_limiters:
            self._rate_limiters[url] = _RateLimiter(max_per_second=10)
        return self._rate_limiters[url].allow()

    def stats(self) -> dict[str, Any]:
        """Return delivery statistics."""
        return {
            "delivered": self._delivered,
            "failed": self._failed,
            "webhooks_configured": len(self._webhooks),
            "last_errors": list(self._last_errors),
        }
