"""Nomotic CLI — manage agent birth certificates from the command line.

Usage::

    nomotic setup
    nomotic new
    nomotic birth --name my-agent
    nomotic birth --name my-agent --archetype customer-experience --org acme
    nomotic verify <cert-id>
    nomotic inspect <agent-id>
    nomotic inspect <agent-id> --brief
    nomotic inspect <agent-id> --raw
    nomotic status
    nomotic status --presets
    nomotic config set --retention 5y
    nomotic suspend <cert-id> --reason "policy violation"
    nomotic revoke <cert-id> --reason "decommissioned"
    nomotic reactivate <cert-id>
    nomotic renew <cert-id>
    nomotic list [--status ACTIVE] [--archetype ...] [--org ...]
    nomotic reputation <cert-id>
    nomotic export <cert-id>

    nomotic archetype list [--category ...]
    nomotic archetype set <agent>
    nomotic archetype register --name <name> --description <desc> --category <cat>
    nomotic archetype validate <name>

    nomotic org register --name <name> [--email <email>]
    nomotic org list [--status ACTIVE]
    nomotic org validate <name>

    nomotic zone validate <path>

    nomotic serve [--host 0.0.0.0] [--port 8420]

Configuration is stored in ``~/.nomotic/config.json``.
Certificates are stored in ``~/.nomotic/certs/``.
The issuer key is stored in ``~/.nomotic/issuer/``.
"""

from __future__ import annotations

import argparse
import json
import os
import platform
import sys
from datetime import datetime, timezone
from pathlib import Path

from nomotic.authority import CertificateAuthority
from nomotic.certificate import CertStatus
from nomotic.id_registry import AgentIdRegistry
from nomotic.keys import SigningKey, VerifyKey
from nomotic.org_governance import (
    OrgGovernanceConfig,
    generate_org_config_from_preset,
    save_org_config,
)
from nomotic.presets import (
    PRESET_DISCLAIMER,
    get_preset,
    list_compliance_presets,
    list_severity_presets,
    merge_presets,
)
from nomotic.registry import (
    ArchetypeRegistry,
    FileOrgStore,
    OrganizationRegistry,
    OrgStatus,
    ZoneValidator,
    _normalize_org_name,
)
from nomotic.store import FileCertificateStore

__all__ = ["main"]

_DEFAULT_BASE = Path.home() / ".nomotic"


# ── ANSI color support ───────────────────────────────────────────────────


def _init_colors() -> bool:
    """Initialize ANSI color support. Returns True if colors are available."""
    if not sys.stdout.isatty():
        return False
    if os.environ.get("NO_COLOR"):
        return False
    if platform.system() == "Windows":
        try:
            import ctypes
            kernel32 = ctypes.windll.kernel32  # type: ignore[attr-defined]
            # Enable ANSI escape sequences on Windows 10+
            kernel32.SetConsoleMode(kernel32.GetStdHandle(-11), 7)
            return True
        except Exception:
            return False
    return True


_COLORS_ENABLED = _init_colors()


def _c(code: str, text: str) -> str:
    return text if not _COLORS_ENABLED else f"\033[{code}m{text}\033[0m"


def _bold(t: str) -> str:
    return _c("1", t)


def _green(t: str) -> str:
    return _c("32", t)


def _red(t: str) -> str:
    return _c("31", t)


def _yellow(t: str) -> str:
    return _c("33", t)


def _cyan(t: str) -> str:
    return _c("36", t)


def _dim(t: str) -> str:
    return _c("2", t)


# ── Issuer key management ────────────────────────────────────────────────


def _issuer_dir(base: Path) -> Path:
    d = base / "issuer"
    d.mkdir(parents=True, exist_ok=True)
    return d


def _load_or_create_issuer(base: Path) -> tuple[SigningKey, VerifyKey, str]:
    """Load the issuer key pair, or generate one on first run."""
    issuer = _issuer_dir(base)
    key_path = issuer / "issuer.key"
    pub_path = issuer / "issuer.pub"
    meta_path = issuer / "issuer.json"

    if key_path.exists():
        sk = SigningKey.from_bytes(key_path.read_bytes())
        vk = sk.verify_key()
        meta = json.loads(meta_path.read_text(encoding="utf-8"))
        return sk, vk, meta["issuer_id"]

    # First run — generate
    sk, vk = SigningKey.generate()
    key_path.write_bytes(sk.to_bytes())
    os.chmod(key_path, 0o600)
    pub_path.write_bytes(vk.to_bytes())
    issuer_id = f"nomotic-cli-{vk.fingerprint()[-12:]}"
    meta = {
        "issuer_id": issuer_id,
        "created_at": datetime.now(timezone.utc).isoformat(),
        "fingerprint": vk.fingerprint(),
    }
    meta_path.write_text(json.dumps(meta, indent=2), encoding="utf-8")
    return sk, vk, issuer_id


def _build_ca(base: Path) -> tuple[CertificateAuthority, FileCertificateStore]:
    """Build a CertificateAuthority backed by the file store."""
    sk, _vk, issuer_id = _load_or_create_issuer(base)
    store = FileCertificateStore(base)
    ca = CertificateAuthority(issuer_id=issuer_id, signing_key=sk, store=store)
    return ca, store


def _build_registries(base: Path) -> tuple[ArchetypeRegistry, ZoneValidator, OrganizationRegistry]:
    """Build the validation registries for CLI use."""
    archetype_reg = ArchetypeRegistry.with_defaults()
    zone_val = ZoneValidator()
    org_store = FileOrgStore(base)
    org_reg = OrganizationRegistry(store=org_store)
    return archetype_reg, zone_val, org_reg


# ── Nomotic config (setup defaults) ─────────────────────────────────────


def _load_nomotic_config(base: Path) -> dict:
    """Load the nomotic config, or return empty dict if not set up."""
    config_path = base / "config.json"
    if config_path.exists():
        return json.loads(config_path.read_text(encoding="utf-8"))
    return {}


# ── Agent ID registry helpers ────────────────────────────────────────────


def _load_registry(base: Path) -> AgentIdRegistry:
    """Load the AgentIdRegistry, running migration on first use."""
    registry = AgentIdRegistry(base)
    if not registry._path.exists():
        # First use — migrate existing certs
        certs_dir = base / "certs"
        registry.migrate_from_certs(certs_dir)
        registry._save()
    return registry


# ── Identifier resolution ────────────────────────────────────────────────


def _resolve_agent(base: Path, identifier: str) -> tuple[int, str, str]:
    """Resolve an identifier to (agent_numeric_id, name, cert_id).

    Uses the AgentIdRegistry for resolution.
    Falls back to scanning cert files for old-format agents without
    registry entries.
    """
    registry = _load_registry(base)

    try:
        match = registry.resolve_single(identifier)
        return match["agent_id"], match["name"], match["certificate_id"]
    except ValueError:
        pass

    # Fall back: try registry.resolve for multiple matches
    matches = registry.resolve(identifier)
    if len(matches) > 1:
        print(f"Ambiguous identifier '{identifier}' matches multiple agents:", file=sys.stderr)
        for m in matches:
            print(f"  ID {m['agent_id']}: {m['name']} ({m['certificate_id']})", file=sys.stderr)
        print("  Use numeric ID or name+ID combo to disambiguate.", file=sys.stderr)
        sys.exit(1)

    if len(matches) == 1:
        m = matches[0]
        return m["agent_id"], m["name"], m["certificate_id"]

    # Fall back to scanning cert files for old-format agents
    if identifier.startswith("nmc-"):
        # Direct cert-id — check file exists
        certs_dir = base / "certs"
        cert_path = certs_dir / f"{identifier}.json"
        if cert_path.exists():
            data = json.loads(cert_path.read_text(encoding="utf-8"))
            return data.get("agent_numeric_id", 0), data.get("agent_id", ""), identifier
        revoked_path = base / "revoked" / f"{identifier}.json"
        if revoked_path.exists():
            data = json.loads(revoked_path.read_text(encoding="utf-8"))
            return data.get("agent_numeric_id", 0), data.get("agent_id", ""), identifier

    # Try scanning certs for agent name match (old-format without registry)
    # Case-insensitive comparison
    certs_dir = base / "certs"
    lookup = identifier.lower()
    if certs_dir.exists():
        for cert_file in certs_dir.glob("nmc-*.json"):
            try:
                data = json.loads(cert_file.read_text(encoding="utf-8"))
                if data.get("agent_id", "").lower() == lookup:
                    return (
                        data.get("agent_numeric_id", 0),
                        data.get("agent_id", ""),
                        data["certificate_id"],
                    )
            except (json.JSONDecodeError, KeyError):
                continue

    print(f"No agent found for identifier '{identifier}'.", file=sys.stderr)
    print("  Use 'nomotic list' to see available agents.", file=sys.stderr)
    sys.exit(1)


def _resolve_cert_id(base: Path, identifier: str) -> str:
    """Backward-compatible wrapper: resolve identifier to cert_id only."""
    _numeric_id, _name, cert_id = _resolve_agent(base, identifier)
    return cert_id


# ── CLI commands ─────────────────────────────────────────────────────────


def _cmd_setup(args: argparse.Namespace) -> None:
    """Interactive first-run configuration."""
    config_path = args.base_dir / "config.json"

    # Load existing config if present (for re-running setup)
    existing: dict = {}
    if config_path.exists():
        existing = json.loads(config_path.read_text(encoding="utf-8"))

    print()
    print(f"  {_bold('Nomotic Setup')}")
    print(f"  {'─' * 35}")
    print()

    # ── Step 1: Organization ─────────────────────────────────────────────
    default_org = existing.get("organization", "")
    prompt = "  Organization name"
    if default_org:
        prompt += f" [{default_org}]"
    prompt += ": "
    org_input = input(prompt).strip() or default_org
    org = _normalize_org_name(org_input)
    if org_input != org:
        print(f"    \u2192 Normalized to: {org}")
    print()

    # ── Step 2: Owner ────────────────────────────────────────────────────
    default_owner = existing.get("owner", "")
    prompt = "  Your name or email (agent owner)"
    if default_owner:
        prompt += f" [{default_owner}]"
    prompt += ": "
    owner = input(prompt).strip() or default_owner
    print()

    # ── Step 3: Zone ─────────────────────────────────────────────────────
    default_zone = existing.get("default_zone", "global")
    print("  Zones define where agents operate (e.g., global, us/production, eu/staging).")
    prompt = f"  Default governance zone [{default_zone}]: "
    zone_input = input(prompt).strip() or default_zone
    zone = zone_input.lower()
    if zone_input != zone:
        print(f"    \u2192 Normalized to: {zone}")
    print()

    # ── Step 4: Compliance Profile ───────────────────────────────────────
    # Mapping from menu selection to (preset_name, framework_label)
    _COMPLIANCE_MAP: dict[str, tuple[str, str]] = {
        "2": ("soc2_aligned", "SOC2"),
        "3": ("hipaa_aligned", "HIPAA"),
        "4": ("pci_dss_aligned", "PCI-DSS"),
        "5": ("iso27001_aligned", "ISO27001"),
    }
    _MULTI_OPTIONS: list[tuple[str, str, str]] = [
        ("1", "soc2_aligned", "SOC2"),
        ("2", "hipaa_aligned", "HIPAA"),
        ("3", "pci_dss_aligned", "PCI-DSS"),
        ("4", "iso27001_aligned", "ISO27001"),
    ]

    # Show existing compliance as context
    existing_frameworks = existing.get("compliance_frameworks", [])
    existing_presets = existing.get("compliance_presets", [])

    # Determine default selection for re-runs
    compliance_default = "1"
    if existing_frameworks:
        if len(existing_frameworks) > 1:
            compliance_default = "6"
        else:
            for sel, (_, label) in _COMPLIANCE_MAP.items():
                if label == existing_frameworks[0]:
                    compliance_default = sel
                    break

    print("  Does your organization have compliance requirements?")
    print()
    print("    [1] No specific requirements (standard defaults)")
    print("    [2] SOC2 \u2014 Service organization controls")
    print("    [3] HIPAA \u2014 Healthcare data protection")
    print("    [4] PCI-DSS \u2014 Payment card security")
    print("    [5] ISO27001 \u2014 Information security management")
    print("    [6] Multiple frameworks")
    print()
    compliance_input = input(f"  Selection [{compliance_default}]: ").strip() or compliance_default

    selected_frameworks: list[str] = []
    selected_presets: list[str] = []

    if compliance_input == "6":
        # Multiple frameworks — follow-up selection
        print()
        print("  Select frameworks (comma-separated numbers):")
        print()
        for num, _, label in _MULTI_OPTIONS:
            print(f"    [{num}] {label}")
        print()
        # Determine default for multi-select from existing config
        multi_default = ""
        if existing_frameworks and len(existing_frameworks) > 1:
            defaults = []
            for num, _, label in _MULTI_OPTIONS:
                if label in existing_frameworks:
                    defaults.append(num)
            multi_default = ",".join(defaults)
        multi_prompt = "  Selections"
        if multi_default:
            multi_prompt += f" [{multi_default}]"
        multi_prompt += ": "
        multi_input = input(multi_prompt).strip() or multi_default
        for part in multi_input.split(","):
            part = part.strip()
            for num, preset, label in _MULTI_OPTIONS:
                if part == num:
                    selected_frameworks.append(label)
                    selected_presets.append(preset)
                    break
    elif compliance_input in _COMPLIANCE_MAP:
        preset_name, framework_label = _COMPLIANCE_MAP[compliance_input]
        selected_frameworks = [framework_label]
        selected_presets = [preset_name]
    # else: selection "1" or anything else → no compliance (empty lists)
    print()

    # ── Step 5: Default Severity ─────────────────────────────────────────
    _SEVERITY_MAP: dict[str, str] = {
        "1": "standard",
        "2": "strict",
        "3": "ultra_strict",
    }
    _SEVERITY_LABELS: dict[str, str] = {
        "standard": "standard",
        "strict": "strict",
        "ultra_strict": "ultra-strict",
    }

    existing_preset = existing.get("default_preset", "standard")
    severity_default = "1"
    for sel, name in _SEVERITY_MAP.items():
        if name == existing_preset:
            severity_default = sel
            break

    print("  Default governance strictness for new agents:")
    print()
    print("    [1] Standard \u2014 reasonable defaults")
    print("    [2] Strict \u2014 elevated security, recommended for production")
    print("    [3] Ultra-strict \u2014 maximum governance for regulated industries")
    print()
    severity_input = input(f"  Selection [{severity_default}]: ").strip() or severity_default
    default_preset = _SEVERITY_MAP.get(severity_input, "standard")
    print()

    # ── Step 6: Org Governance (optional) ────────────────────────────────
    org_gov_path = args.base_dir / "org-governance.yaml"
    org_gov_default = "2"
    if org_gov_path.exists():
        org_gov_default = "1"

    org_gov_generated = False
    if selected_frameworks or selected_presets:
        print("  Create organization-level governance minimums?")
        print("  These set the floor that no agent can go below.")
        print()
        print("    [1] Yes \u2014 generate from your compliance and strictness selections")
        print("    [2] No \u2014 skip for now")
        print()
        org_gov_input = input(f"  Selection [{org_gov_default}]: ").strip() or org_gov_default

        if org_gov_input == "1":
            # Determine the preset to use for generation
            if len(selected_presets) == 1:
                gen_preset_name = selected_presets[0]
                org_config = generate_org_config_from_preset(org, gen_preset_name)
            else:
                # Multiple frameworks — merge presets first
                preset_objects = [get_preset(p) for p in selected_presets]
                merged = merge_presets(*preset_objects)
                gen_preset_name = merged.name
                # Build org config from merged values
                org_config = OrgGovernanceConfig(
                    org_name=org,
                    minimum_weights=dict(merged.dimension_weights),
                    required_vetoes=list(merged.veto_dimensions),
                    minimum_allow_threshold=merged.allow_threshold,
                    minimum_deny_threshold=merged.deny_threshold,
                    minimum_violation_decrement=merged.trust_settings["violation_decrement"],
                    maximum_success_increment=merged.trust_settings["success_increment"],
                    allowed_presets=None,
                    required_frameworks=list(selected_frameworks),
                    source_path="",
                )

            save_org_config(org_config, org_gov_path)
            org_gov_generated = True

            print()
            print(f"  \u2139 Org governance generated using {gen_preset_name} preset.")
            # Build framework reference for disclaimer
            fw_refs = ", ".join(selected_frameworks)
            print(f"    This is Nomotic's interpretation aligned to {fw_refs} concerns.")
            print(f"    It does not constitute {fw_refs} compliance.")
            print(f"    Review {org_gov_path} and adjust for your needs.")
        print()

    # ── Save config ──────────────────────────────────────────────────────
    config = {
        "organization": org,
        "owner": owner,
        "default_zone": zone,
        "retention": existing.get("retention", "5y"),
        "enforce_unique_names": existing.get("enforce_unique_names", False),
        "compliance_frameworks": selected_frameworks,
        "compliance_presets": selected_presets,
        "default_preset": default_preset,
    }
    args.base_dir.mkdir(parents=True, exist_ok=True)
    config_path.write_text(json.dumps(config, indent=2), encoding="utf-8")

    # ── Completion output ────────────────────────────────────────────────
    print(f"  {_green('Setup complete.')} Configuration saved to {config_path}")
    print()
    print("  Your defaults:")
    print(f"    Organization:   {org}")
    print(f"    Owner:          {owner}")
    print(f"    Zone:           {zone}")
    if selected_frameworks:
        fw_display = ", ".join(selected_frameworks)
        preset_display = ", ".join(selected_presets)
        print(f"    Compliance:     {fw_display} (using {preset_display} preset)")
    else:
        print("    Compliance:     none")
    print(f"    Strictness:     {_SEVERITY_LABELS.get(default_preset, default_preset)}")
    if org_gov_generated:
        print(f"    Org governance: {org_gov_path} \u2713")
    elif org_gov_path.exists():
        print(f"    Org governance: {org_gov_path}")
    else:
        print("    Org governance: not configured")
    print()
    print("  Next steps:")
    print("    1. Create your first agent:    nomotic birth --name my-agent")
    print("    2. Validate a governance config: nomotic validate nomotic.yaml")
    print("    3. View current settings:       nomotic status")
    print()


def _cmd_birth(args: argparse.Namespace) -> None:
    # Load config defaults
    config = _load_nomotic_config(args.base_dir)

    # Resolve name from --name or --agent-id (backward compat)
    agent_name = args.name or getattr(args, "agent_id_compat", None)
    if not agent_name:
        print("Error: --name is required.", file=sys.stderr)
        sys.exit(1)
    args.name = agent_name

    # Merge config defaults with CLI args
    org_raw = args.org or config.get("organization", "")
    owner = args.owner or config.get("owner", "")
    zone_raw = args.zone or config.get("default_zone", "global")
    archetype_raw = (args.archetype or "general-purpose")

    # First-run guard: need at least an org
    if not org_raw:
        print("Nomotic is not configured yet.", file=sys.stderr)
        print("  Run 'nomotic setup' first, or provide --org.", file=sys.stderr)
        sys.exit(1)

    # Normalize zone, org, archetype
    org = _normalize_org_name(org_raw)
    zone_path = zone_raw.lower()
    archetype = archetype_raw.lower()

    ca, store = _build_ca(args.base_dir)
    arch_reg, zone_val, _org_reg = _build_registries(args.base_dir)

    # Load or create the AgentIdRegistry
    registry = _load_registry(args.base_dir)

    # Check for duplicate active name within the same org via registry
    # Case-insensitive name comparison
    existing = registry.list_all(status="ACTIVE")
    for entry in existing:
        if entry["name"].lower() == args.name.lower() and entry["organization"] == org:
            print(f"Error: An active agent named '{args.name}' already exists in org '{org}'.", file=sys.stderr)
            print(f"  ID: {entry['agent_id']}, Certificate: {entry['certificate_id']}", file=sys.stderr)
            print("  Use a different --name, or revoke the existing agent first.", file=sys.stderr)
            sys.exit(1)

    # Validate archetype
    arch_result = arch_reg.validate(archetype)
    if not arch_result.valid:
        msg = f"Invalid archetype '{archetype}': {'; '.join(arch_result.errors)}"
        if arch_result.suggestion:
            msg += f"\n  Did you mean '{arch_result.suggestion}'?"
        print(msg, file=sys.stderr)
        sys.exit(1)
    if arch_result.warnings:
        for w in arch_result.warnings:
            print(f"  Warning: {w}", file=sys.stderr)
        if arch_result.suggestion:
            print(f"  Did you mean '{arch_result.suggestion}'?", file=sys.stderr)

    # Validate zone (after normalization)
    zone_result = zone_val.validate(zone_path)
    if not zone_result.valid:
        error = zone_result.errors[0] if zone_result.errors else "Invalid zone format"
        print(f"Invalid zone '{zone_path}': {error}", file=sys.stderr)
        print("  Zones use lowercase with slashes: global, us/production, eu/staging", file=sys.stderr)
        sys.exit(1)

    # Allocate sequential numeric ID
    numeric_id = registry.next_id()

    cert, agent_sk = ca.issue(
        agent_id=args.name,
        archetype=archetype,
        organization=org,
        zone_path=zone_path,
        owner=owner,
    )

    # Set numeric ID on certificate and re-save
    cert.agent_numeric_id = numeric_id
    store.update(cert)

    # Register in the ID registry
    registry.register(numeric_id, args.name, cert.certificate_id, org)

    # Save agent keys alongside certificate
    store.save_agent_key(cert.certificate_id, agent_sk.to_bytes())
    store.save_agent_pub(cert.certificate_id, cert.public_key)

    print()
    print(f"Agent created: {_bold(args.name)}")
    if cert.agent_numeric_id:
        print(f"  ID:          {cert.agent_numeric_id}")
    print(f"  Name:        {cert.agent_id}")
    print(f"  Certificate: {cert.certificate_id}")
    print(f"  Archetype:   {archetype}")
    print(f"  Org:         {org}")
    print(f"  Zone:        {zone_path}")
    print(f"  Owner:       {owner}")
    print(f"  Trust:       {cert.trust_score:.2f}")
    print(f"  Status:      {cert.status.name}")

    # Prompt to set archetype if they didn't specify one
    if not args.archetype:
        print()
        print("  Archetype defaulted to 'general-purpose'.")
        print(f"  Set a specific archetype with: nomotic archetype set {args.name}")

    # Next steps
    print()
    print("  Next steps:")
    print(f"    nomotic scope {args.name} set --actions read,write --boundaries my_db")
    print(f"    nomotic test {args.name} --action read --target my_db")


def _cmd_verify(args: argparse.Namespace) -> None:
    ca, _store = _build_ca(args.base_dir)
    cert_id = _resolve_cert_id(args.base_dir, args.cert_id)
    cert = ca.get(cert_id)
    if cert is None:
        print(f"Certificate not found: {args.cert_id}", file=sys.stderr)
        sys.exit(1)
    result = ca.verify_certificate(cert)
    if result.valid:
        print(f"VALID — {cert.certificate_id}")
        print(f"  Status: {cert.status.name}")
        print(f"  Trust:  {cert.trust_score:.3f}")
        print(f"  Age:    {cert.behavioral_age}")
    else:
        print(f"INVALID — {cert.certificate_id}")
        for issue in result.issues:
            print(f"  - {issue}")
        sys.exit(1)


def _cmd_inspect_agent(args: argparse.Namespace) -> None:
    """Inspect an agent's governance configuration and state."""
    if getattr(args, "raw", False):
        # Raw JSON cert dump (formerly _cmd_inspect)
        ca, _store = _build_ca(args.base_dir)
        cert_id = _resolve_cert_id(args.base_dir, args.agent_id)
        cert = ca.get(cert_id)
        if cert is None:
            print(f"Certificate not found: {args.agent_id}", file=sys.stderr)
            sys.exit(1)
        print(json.dumps(cert.to_dict(), indent=2, sort_keys=True))
        return

    if getattr(args, "brief", False):
        # Quick status view (formerly _cmd_status)
        ca, _store = _build_ca(args.base_dir)
        cert_id = _resolve_cert_id(args.base_dir, args.agent_id)
        cert = ca.get(cert_id)
        if cert is None:
            print(f"Certificate not found: {cert_id}", file=sys.stderr)
            sys.exit(1)

        # Status color
        if cert.status.name == "ACTIVE":
            status_display = _green(cert.status.name)
        elif cert.status.name == "SUSPENDED":
            status_display = _yellow(cert.status.name)
        else:
            status_display = _red(cert.status.name)

        # Trust color
        trust = cert.trust_score
        if trust >= 0.5:
            trust_display = _green(f"{trust:.3f}")
        elif trust >= 0.3:
            trust_display = _yellow(f"{trust:.3f}")
        else:
            trust_display = _red(f"{trust:.3f}")

        print()
        print(f"  {_bold(cert.agent_id)}")
        print(f"  {'─' * 40}")
        print(f"  Status:    {status_display}")
        print(f"  Trust:     {trust_display}")
        print(f"  Archetype: {cert.archetype}")
        print(f"  Org:       {cert.organization}")
        print(f"  Zone:      {cert.zone_path}")
        print(f"  Owner:     {cert.owner}")
        print(f"  Issued:    {cert.issued_at.strftime('%Y-%m-%d %H:%M')}")
        print(f"  Cert:      {cert.certificate_id}")
        print()
        return

    # Default: comprehensive view (formerly _cmd_config display logic)
    from nomotic.sandbox import load_agent_config

    agent_id = args.agent_id

    # Resolve agent identifier
    try:
        _numeric_id, resolved_name, cert_id = _resolve_agent(args.base_dir, agent_id)
        agent_id = resolved_name
    except SystemExit:
        cert_id = None

    # Try to load certificate info
    ca, _store = _build_ca(args.base_dir)
    if cert_id is None:
        from nomotic.sandbox import find_agent_cert_id
        cert_id = find_agent_cert_id(args.base_dir, agent_id)
    cert = ca.get(cert_id) if cert_id else None

    # Load governance config
    config = load_agent_config(args.base_dir, agent_id)

    print()
    print(_bold(f"  Governance Configuration: {agent_id}"))
    print(f"  {'=' * 50}")
    print()

    # Certificate info
    if cert:
        print(_bold("  Identity:"))
        print(f"    Certificate: {cert.certificate_id}")
        print(f"    Archetype:   {cert.archetype}")
        print(f"    Org:         {cert.organization}")
        print(f"    Zone:        {cert.zone_path}")
        print(f"    Owner:       {cert.owner}")
        print(f"    Trust:       {cert.trust_score}")
        print(f"    Status:      {cert.status.name}")
        print()
    else:
        print(_bold("  Identity:"))
        print(f"    No certificate found for '{agent_id}'")
        print()

    if config is None:
        print(_bold("  Authority:"))
        print("    No governance configuration found.")
        print(f"    Use 'nomotic scope set {agent_id} --actions ...' to configure.")
        print()
        return

    # Scope
    print(_bold("  Authority:"))
    if config.actions:
        print(f"    Allowed actions: {', '.join(config.actions)}")
    else:
        print("    Allowed actions: (not configured)")
    print()

    # Boundaries
    print(_bold("  Boundaries:"))
    if config.boundaries:
        for b in config.boundaries:
            print(f"    {_green(chr(10003))} {b}")
    else:
        print("    (not configured)")
    print()

    # Ethical rules
    print(_bold("  Ethical Rules:"))
    if config.ethical_rules:
        for i, rule in enumerate(config.ethical_rules, 1):
            print(f"    [{i}] {_yellow('VETO')} if: {rule.condition}")
            print(f"        Message: \"{rule.message}\"")
    else:
        print("    (none)")
    print()

    # Human override rules
    print(_bold("  Human Override Rules:"))
    if config.human_overrides:
        for i, ho in enumerate(config.human_overrides, 1):
            print(f"    [{i}] Action '{_red(ho.action)}' requires human approval")
            print(f"        Message: \"{ho.message}\"")
    else:
        print("    (none)")
    print()


def _cmd_suspend(args: argparse.Namespace) -> None:
    ca, _store = _build_ca(args.base_dir)
    numeric_id, _name, cert_id = _resolve_agent(args.base_dir, args.cert_id)
    try:
        cert = ca.suspend(cert_id, args.reason)
    except (KeyError, ValueError) as exc:
        print(str(exc), file=sys.stderr)
        sys.exit(1)
    # Update registry status
    if numeric_id > 0:
        registry = _load_registry(args.base_dir)
        try:
            registry.update_status(numeric_id, "SUSPENDED")
        except KeyError:
            pass
    print(f"Suspended: {cert.certificate_id}")


def _cmd_reactivate(args: argparse.Namespace) -> None:
    ca, _store = _build_ca(args.base_dir)
    numeric_id, _name, cert_id = _resolve_agent(args.base_dir, args.cert_id)
    try:
        cert = ca.reactivate(cert_id)
    except (KeyError, ValueError) as exc:
        print(str(exc), file=sys.stderr)
        sys.exit(1)
    # Update registry status
    if numeric_id > 0:
        registry = _load_registry(args.base_dir)
        try:
            registry.update_status(numeric_id, "ACTIVE")
        except KeyError:
            pass
    print(f"Reactivated: {cert.certificate_id}")


def _cmd_revoke(args: argparse.Namespace) -> None:
    ca, _store = _build_ca(args.base_dir)
    numeric_id, name, cert_id = _resolve_agent(args.base_dir, args.cert_id)
    try:
        cert = ca.revoke(cert_id, args.reason)
    except (KeyError, ValueError) as exc:
        print(str(exc), file=sys.stderr)
        sys.exit(1)

    # Update registry status
    registry = _load_registry(args.base_dir)
    now_iso = datetime.now(timezone.utc).isoformat()
    if numeric_id > 0:
        try:
            registry.update_status(numeric_id, "REVOKED", revoked_at=now_iso)
        except KeyError:
            pass

    # Seal the persistent audit trail
    from nomotic.audit_store import AuditStore
    audit_store = AuditStore(args.base_dir)
    seal_hash = audit_store.seal(name)
    audit_summary = audit_store.summary(name)

    # Build audit_records list for the revocation seal
    audit_records = None
    all_records = audit_store.query_all(name)
    if all_records:
        audit_records = [r.to_dict() for r in all_records]

    # Create revocation seal
    from nomotic.revocation import create_revocation_seal
    create_revocation_seal(
        args.base_dir,
        agent_id=numeric_id,
        agent_name=name,
        certificate_id=cert_id,
        reason=args.reason,
        cert=cert,
        audit_records=audit_records,
    )

    total_evals = audit_summary.get("total", 0)
    print()
    print(f"Revoked: {cert.certificate_id}")
    print()
    print(f"Agent revoked: {_bold(name)}")
    print(f"  Certificate: {cert.certificate_id}")
    print(f"  Status:      {_red('REVOKED')}")
    print(f"  Reason:      {args.reason}")
    print(f"  Audit sealed: {seal_hash} ({total_evals} records)")
    print()
    print("  This agent's complete history is preserved and cannot be modified.")
    print(f"  View with: nomotic history {name}")
    print()


def _cmd_renew(args: argparse.Namespace) -> None:
    ca, store = _build_ca(args.base_dir)
    cert_id = _resolve_cert_id(args.base_dir, args.cert_id)
    try:
        cert, agent_sk = ca.renew(cert_id)
    except KeyError as exc:
        print(str(exc), file=sys.stderr)
        sys.exit(1)
    store.save_agent_key(cert.certificate_id, agent_sk.to_bytes())
    store.save_agent_pub(cert.certificate_id, cert.public_key)
    print(f"Renewed: {cert.certificate_id}")
    print(f"  Lineage: {cert.lineage}")


def _cmd_list(args: argparse.Namespace) -> None:
    ca, _store = _build_ca(args.base_dir)
    status_filter = CertStatus[args.status.upper()] if args.status else None

    # Special handling for REVOKED status — show from revocation records
    if status_filter == CertStatus.REVOKED:
        registry = _load_registry(args.base_dir)
        revoked_agents = registry.list_all(status="REVOKED", org=args.org)
        if not revoked_agents:
            print("No revoked agents found.")
            return

        print()
        print("Revoked Agents:")
        print()
        print(f"  {'ID':<6}{'Name':<14}{'Org':<17}{'Revoked':<13}{'Reason'}")
        print(f"  {'─' * 4}  {'─' * 12}  {'─' * 15}  {'─' * 11}  {'─' * 23}")
        for agent in revoked_agents:
            revoked_at = agent.get("revoked_at", "")
            if revoked_at:
                revoked_date = revoked_at[:10]
            else:
                revoked_date = "unknown"
            # Load reason from revocation seal if available
            reason = ""
            seal_path = args.base_dir / "revocations" / f"{agent['agent_id']}.json"
            if seal_path.exists():
                try:
                    seal = json.loads(seal_path.read_text(encoding="utf-8"))
                    reason = seal.get("reason", "")
                except (json.JSONDecodeError, KeyError):
                    pass
            print(f"  {agent['agent_id']:<6}{agent['name']:<14}{agent['organization']:<17}{revoked_date:<13}{reason}")
        print()
        return

    certs = ca.list(org=args.org, status=status_filter, archetype=args.archetype)
    if not certs:
        print("No certificates found.")
        return

    # Load registry for numeric IDs
    registry = _load_registry(args.base_dir)

    for cert in certs:
        nid = cert.agent_numeric_id
        if nid == 0:
            # Try to find in registry
            matches = registry.resolve(cert.agent_id)
            if matches:
                nid = matches[0]["agent_id"]
        id_str = str(nid) if nid > 0 else "?"
        print(f"  {id_str:<6}{cert.agent_id:20s}  {cert.status.name:10s}  trust={cert.trust_score:.2f}  age={cert.behavioral_age}  cert={cert.certificate_id}")


def _cmd_reputation(args: argparse.Namespace) -> None:
    ca, _store = _build_ca(args.base_dir)
    cert_id = _resolve_cert_id(args.base_dir, args.cert_id)
    cert = ca.get(cert_id)
    if cert is None:
        print(f"Certificate not found: {cert_id}", file=sys.stderr)
        sys.exit(1)

    trust = cert.trust_score
    age = cert.behavioral_age

    # Estimate violation/success counts from behavioral age and trust
    # Trust starts at 0.500 and moves asymmetrically (violations cost 5x).
    # We estimate based on age and current trust trajectory.
    if age > 0:
        # Rough heuristic: each success adds ~0.002, each violation costs ~0.010
        # Solve: successful * 0.002 - violations * 0.010 = trust - 0.500
        #        successful + violations = age
        delta = trust - 0.500
        # violations ≈ (age * 0.002 - delta) / 0.012
        est_violations = max(0, int((age * 0.002 - delta) / 0.012))
        est_successful = max(0, age - est_violations)
    else:
        est_violations = 0
        est_successful = 0

    total = est_successful + est_violations
    violation_rate = (est_violations / total * 100) if total > 0 else 0.0

    # Trust color
    if trust >= 0.5:
        trust_display = _green(f"{trust:.3f}")
    elif trust >= 0.3:
        trust_display = _yellow(f"{trust:.3f}")
    else:
        trust_display = _red(f"{trust:.3f}")

    # Status color
    if cert.status.name == "ACTIVE":
        status_display = _green(cert.status.name)
    elif cert.status.name == "SUSPENDED":
        status_display = _yellow(cert.status.name)
    else:
        status_display = _red(cert.status.name)

    print()
    print(f"  Reputation: {_bold(cert.agent_id)}")
    print()
    print(f"    Trust Score:        {trust_display}")
    print(f"    Behavioral Age:     {age}")
    print(f"    Violation Count:    {est_violations}")
    print(f"    Successful Actions: {est_successful}")
    print(f"    Violation Rate:     {violation_rate:.1f}%")
    print(f"    Status:             {status_display}")
    print()

    # Trust trajectory
    start_trust = 0.500
    trend = "stable"
    if trust > start_trust + 0.02:
        trend = "rising"
    elif trust < start_trust - 0.02:
        trend = "falling"

    print("    Trust Trajectory:")
    print(f"      Started at {start_trust:.3f} on {cert.issued_at.strftime('%Y-%m-%d')}")
    print(f"      Current:   {trust:.3f}")
    print(f"      Trend:     {trend}")
    print()


def _cmd_export(args: argparse.Namespace) -> None:
    ca, _store = _build_ca(args.base_dir)
    cert_id = _resolve_cert_id(args.base_dir, args.cert_id)
    cert = ca.get(cert_id)
    if cert is None:
        print(f"Certificate not found: {args.cert_id}", file=sys.stderr)
        sys.exit(1)
    # Export public certificate (no private key)
    filename = f"{cert.certificate_id}.cert.json"
    Path(filename).write_text(
        json.dumps(cert.to_dict(), indent=2, sort_keys=True),
        encoding="utf-8",
    )
    print(f"Exported to {filename}")


# ── Archetype commands ───────────────────────────────────────────────────


def _cmd_archetype(args: argparse.Namespace) -> None:
    arch_reg = ArchetypeRegistry.with_defaults()
    sub = args.archetype_command

    if sub == "list":
        archetypes = arch_reg.list(category=args.category)
        if not archetypes:
            print("No archetypes found.")
            return

        # Group by category
        from collections import defaultdict
        by_category: dict[str, list] = defaultdict(list)
        for a in archetypes:
            by_category[a.category].append(a)

        # Find max name length for alignment
        max_name = max(len(a.name) for a in archetypes)

        print()
        print("Archetypes:")
        for cat in sorted(by_category.keys()):
            print()
            print(f"  {_bold(cat)}")
            for a in sorted(by_category[cat], key=lambda x: x.name):
                print(f"    {a.name:<{max_name + 2}}{a.description}")

    elif sub == "register":
        try:
            defn = arch_reg.register(args.name, args.description, args.category)
        except ValueError as exc:
            print(str(exc), file=sys.stderr)
            sys.exit(1)
        print(f"Registered archetype: {defn.name}")

    elif sub == "validate":
        result = arch_reg.validate(args.name)
        if result.valid:
            print(f"VALID: {result.name}")
            for w in result.warnings:
                print(f"  Warning: {w}")
            if result.suggestion:
                print(f"  Suggestion: {result.suggestion}")
        else:
            print(f"INVALID: {result.name}")
            for e in result.errors:
                print(f"  Error: {e}")
            if result.suggestion:
                print(f"  Did you mean '{result.suggestion}'?")
            sys.exit(1)

    elif sub == "set":
        _cmd_archetype_set(args)

    else:
        print("Unknown archetype subcommand", file=sys.stderr)
        sys.exit(1)


def _cmd_archetype_set(args: argparse.Namespace) -> None:
    """Interactive archetype selection for an agent."""
    agent_identifier = args.agent_identifier

    # Resolve agent
    _numeric_id, _name, cert_id = _resolve_agent(args.base_dir, agent_identifier)

    arch_reg = ArchetypeRegistry.with_defaults()
    archetypes = arch_reg.list()

    # Group by category
    by_category: dict[str, list] = {}
    for a in archetypes:
        cat = a.category or "uncategorized"
        by_category.setdefault(cat, []).append(a)

    # Display numbered list
    print()
    print(f"  Select an archetype for {_bold(agent_identifier)}:")
    print()

    numbered = []
    idx = 1
    for cat in sorted(by_category.keys()):
        print(f"  {_bold(cat)}")
        for a in sorted(by_category[cat], key=lambda x: x.name):
            print(f"    {idx:2d}. {a.name:28s} {a.description}")
            numbered.append(a)
            idx += 1
        print()

    # Get selection
    while True:
        choice = input("  Enter number (or 'skip' to keep current): ").strip()
        if choice.lower() == "skip":
            print("  Archetype unchanged.")
            return
        try:
            num = int(choice)
            if 1 <= num <= len(numbered):
                selected = numbered[num - 1]
                break
            print(f"  Please enter a number between 1 and {len(numbered)}.")
        except ValueError:
            print("  Please enter a number or 'skip'.")

    # Update the certificate's archetype
    ca, store = _build_ca(args.base_dir)
    cert = ca.get(cert_id)
    if cert is None:
        print("Certificate not found.", file=sys.stderr)
        sys.exit(1)

    cert.archetype = selected.name
    store.update(cert)

    print(f"  Archetype set to '{_green(selected.name)}' for {agent_identifier}.")
    print()


# ── Organization commands ────────────────────────────────────────────────


def _cmd_org(args: argparse.Namespace) -> None:
    _arch_reg, _zone_val, org_reg = _build_registries(args.base_dir)
    sub = args.org_command

    if sub == "register":
        sk, vk, _issuer_id = _load_or_create_issuer(args.base_dir)
        try:
            org = org_reg.register(
                args.name,
                vk.fingerprint(),
                contact_email=getattr(args, "email", None),
            )
        except ValueError as exc:
            print(str(exc), file=sys.stderr)
            sys.exit(1)
        print(f"Registered organization: {org.name}")
        print(f"  Display name: {org.display_name}")
        print(f"  Issuer:       {org.issuer_fingerprint}")

    elif sub == "list":
        status_str = getattr(args, "status", None)
        status = OrgStatus[status_str.upper()] if status_str else None
        orgs = org_reg.list(status=status)
        if not orgs:
            print("No organizations found.")
            return
        for org in orgs:
            print(f"  {org.name:30s}  {org.status.name:10s}  {org.display_name}")

    elif sub == "validate":
        result = org_reg.validate(args.name)
        if result.valid:
            print(f"VALID: {result.name} (available)")
        else:
            print(f"INVALID: {result.name}")
            for e in result.errors:
                print(f"  Error: {e}")
            sys.exit(1)

    else:
        print("Unknown org subcommand", file=sys.stderr)
        sys.exit(1)


# ── Zone commands ────────────────────────────────────────────────────────


def _cmd_zone(args: argparse.Namespace) -> None:
    zone_val = ZoneValidator()
    sub = args.zone_command

    if sub == "validate":
        result = zone_val.validate(args.path)
        if result.valid:
            print(f"VALID: {result.name}")
        else:
            print(f"INVALID: {result.name}")
            for e in result.errors:
                print(f"  Error: {e}")
            sys.exit(1)

    else:
        print("Unknown zone subcommand", file=sys.stderr)
        sys.exit(1)


# ── Serve command ────────────────────────────────────────────────────────


def _cmd_hello(args: argparse.Namespace) -> None:
    """Redirect to the tutorial."""
    print("Starting the Nomotic tutorial...")
    print("  (Tip: You can also run 'nomotic tutorial' directly.)")
    print()
    _cmd_tutorial(args)


def _cmd_drift(args: argparse.Namespace) -> None:
    """Show the current behavioral drift for an agent (via API)."""
    import urllib.request
    import urllib.error

    base_url = f"http://{args.host}:{args.port}"
    url = f"{base_url}/v1/drift/{args.agent_id}"

    try:
        req = urllib.request.Request(url)
        with urllib.request.urlopen(req) as resp:
            data = json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        if exc.code == 404:
            print(f"No drift data for agent: {args.agent_id}", file=sys.stderr)
            sys.exit(1)
        print(f"API error: {exc.code} {exc.reason}", file=sys.stderr)
        sys.exit(1)
    except urllib.error.URLError as exc:
        print(f"Cannot connect to {base_url}: {exc.reason}", file=sys.stderr)
        print("Is the Nomotic API server running? (nomotic serve)", file=sys.stderr)
        sys.exit(1)

    drift = data["drift"]
    print(f"Behavioral Drift: {data['agent_id']}")
    print(f"  Overall:    {drift['overall']:.4f} ({drift['severity']})")
    print(f"  Confidence: {drift['confidence']:.2f}")
    print()
    print("  Per-distribution:")
    for name in ["action_drift", "target_drift", "temporal_drift", "outcome_drift"]:
        val = drift[name]
        bar_full = int(val * 10)
        bar = "#" * bar_full + "." * (10 - bar_full)
        label = name.replace("_drift", "").title()
        print(f"    {label:10s} {val:.2f}  {bar}")
    print()
    if drift.get("detail"):
        print(f"  Detail: {drift['detail']}")
        print()

    alerts = data.get("alerts", [])
    unacked = sum(1 for a in alerts if not a.get("acknowledged"))
    if alerts:
        print(f"  Alerts: {unacked} unacknowledged")
        for i, alert in enumerate(alerts):
            ack = " (ack)" if alert.get("acknowledged") else ""
            print(f"    [{i}] {alert['severity']}{ack} - {alert['drift_score'].get('detail', '')}")
    print()


def _cmd_alerts(args: argparse.Namespace) -> None:
    """List drift alerts (via API)."""
    import urllib.request
    import urllib.error

    base_url = f"http://{args.host}:{args.port}"
    url = f"{base_url}/v1/alerts"
    if args.agent_id:
        url += f"?agent_id={args.agent_id}"

    try:
        req = urllib.request.Request(url)
        with urllib.request.urlopen(req) as resp:
            data = json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        print(f"API error: {exc.code} {exc.reason}", file=sys.stderr)
        sys.exit(1)
    except urllib.error.URLError as exc:
        print(f"Cannot connect to {base_url}: {exc.reason}", file=sys.stderr)
        print("Is the Nomotic API server running? (nomotic serve)", file=sys.stderr)
        sys.exit(1)

    alerts = data.get("alerts", [])
    if args.unacknowledged:
        alerts = [a for a in alerts if not a.get("acknowledged")]

    if not alerts:
        print("No drift alerts.")
        return

    print(f"Drift Alerts ({len(alerts)} total, {data.get('unacknowledged', 0)} unacknowledged):")
    for i, alert in enumerate(alerts):
        ack = " [ack]" if alert.get("acknowledged") else ""
        agent = alert.get("agent_id", "?")
        sev = alert.get("severity", "?")
        detail = alert.get("drift_score", {}).get("detail", "")
        print(f"  [{i}] {agent:20s} {sev:10s}{ack}  {detail}")


def _cmd_fingerprint(args: argparse.Namespace) -> None:
    """Show the behavioral fingerprint for an agent (via API)."""
    import urllib.request
    import urllib.error

    base_url = f"http://{args.host}:{args.port}"
    url = f"{base_url}/v1/fingerprint/{args.agent_id}"

    try:
        req = urllib.request.Request(url)
        with urllib.request.urlopen(req) as resp:
            data = json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        if exc.code == 404:
            print(f"No fingerprint found for agent: {args.agent_id}", file=sys.stderr)
            sys.exit(1)
        print(f"API error: {exc.code} {exc.reason}", file=sys.stderr)
        sys.exit(1)
    except urllib.error.URLError as exc:
        print(f"Cannot connect to {base_url}: {exc.reason}", file=sys.stderr)
        print("Is the Nomotic API server running? (nomotic serve)", file=sys.stderr)
        sys.exit(1)

    print(f"Behavioral Fingerprint for {data['agent_id']}")
    print(f"  Observations: {data['total_observations']}")
    print(f"  Confidence:   {data['confidence']:.3f}")
    print()

    if data.get("action_distribution"):
        print("  Action Distribution:")
        for action_type, freq in sorted(data["action_distribution"].items(), key=lambda x: -x[1]):
            bar = "#" * int(freq * 40)
            print(f"    {action_type:20s} {freq:6.1%} {bar}")
        print()

    if data.get("target_distribution"):
        print("  Target Distribution:")
        for target, freq in sorted(data["target_distribution"].items(), key=lambda x: -x[1]):
            bar = "#" * int(freq * 40)
            print(f"    {target:20s} {freq:6.1%} {bar}")
        print()

    tp = data.get("temporal_pattern", {})
    if tp.get("active_hours"):
        print("  Temporal Pattern:")
        print(f"    Active hours: {tp['active_hours']}")
        print(f"    Rate: {tp.get('actions_per_hour_mean', 0):.1f} +/- {tp.get('actions_per_hour_std', 0):.1f} actions/hr")
        print()

    if data.get("outcome_distribution"):
        print("  Outcome Distribution:")
        for outcome, freq in sorted(data["outcome_distribution"].items(), key=lambda x: -x[1]):
            bar = "#" * int(freq * 40)
            print(f"    {outcome:20s} {freq:6.1%} {bar}")
        print()


def _cmd_trust(args: argparse.Namespace) -> None:
    """Show the trust report for an agent (via API)."""
    import urllib.request
    import urllib.error

    base_url = f"http://{args.host}:{args.port}"
    url = f"{base_url}/v1/trust/{args.agent_id}"

    try:
        req = urllib.request.Request(url)
        with urllib.request.urlopen(req) as resp:
            data = json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        if exc.code == 404:
            print(f"No trust data for agent: {args.agent_id}", file=sys.stderr)
            sys.exit(1)
        print(f"API error: {exc.code} {exc.reason}", file=sys.stderr)
        sys.exit(1)
    except urllib.error.URLError as exc:
        print(f"Cannot connect to {base_url}: {exc.reason}", file=sys.stderr)
        print("Is the Nomotic API server running? (nomotic serve)", file=sys.stderr)
        sys.exit(1)

    print(f"Trust Report: {data['agent_id']}")
    print(f"  Current Trust: {data['current_trust']:.2f}")

    traj = data.get("trajectory", {})
    trend = traj.get("trend", "unknown")
    print(f"  Trend: {trend}")
    print()

    total = data.get("successful_actions", 0) + data.get("violation_count", 0)
    print(f"  Actions: {total} total ({data.get('successful_actions', 0)} successful, {data.get('violation_count', 0)} denied)")
    vr = data.get("violation_rate", 0)
    print(f"  Violation Rate: {vr:.1%}")
    print()

    fp = data.get("fingerprint")
    if fp:
        print(f"  Fingerprint: {fp['total_observations']} observations (confidence: {fp['confidence']:.3f})")

    drift = data.get("drift")
    if drift:
        print(f"  Drift: {drift['overall']:.2f} ({drift['severity']})")

    active_alerts = data.get("active_alerts")
    if active_alerts is not None:
        print(f"  Active Alerts: {active_alerts}")
    print()

    # Show recent events
    recent = traj.get("recent_events", [])
    if recent:
        total_events = traj.get("total_events", 0)
        print(f"  Trust History (last {len(recent)} of {total_events} changes):")
        for i, event in enumerate(recent):
            idx = total_events - len(recent) + i
            tb = event.get("trust_before", 0)
            ta = event.get("trust_after", 0)
            delta = event.get("delta", 0)
            src = event.get("source", "")
            reason = event.get("reason", "")
            sign = "+" if delta >= 0 else ""
            print(f"    [{idx}] {tb:.2f} -> {ta:.2f}  {sign}{delta:.3f}  {src:25s} {reason}")
        print()

    # Show trust by source
    sources = traj.get("sources", {})
    if sources:
        print("  Trust by Source:")
        for src, info in sorted(sources.items()):
            nd = info.get("net_delta", 0)
            cnt = info.get("count", 0)
            sign = "+" if nd >= 0 else ""
            print(f"    {src:25s} {sign}{nd:.3f} ({cnt} events)")
        print()


def _cmd_audit(args: argparse.Namespace) -> None:
    """View audit trail records, summary, or verify hash chain integrity."""

    identifier = args.identifier

    if not identifier and not args.show_all:
        print("Specify an agent name/ID, or use --all for all agents.", file=sys.stderr)
        print("  nomotic audit TestBot", file=sys.stderr)
        print("  nomotic audit TestBot --summary", file=sys.stderr)
        print("  nomotic audit TestBot --verify", file=sys.stderr)
        print("  nomotic audit --all", file=sys.stderr)
        print("  nomotic audit --all --push-agicomply", file=sys.stderr)
        sys.exit(1)

    # Resolve agent if provided
    agent_id = None
    agent_name = None
    if identifier:
        try:
            _numeric_id, resolved_name, _cert_id = _resolve_agent(args.base_dir, identifier)
            agent_id = resolved_name
            agent_name = resolved_name
        except SystemExit:
            # If resolve fails, use the identifier directly (might be a name
            # for an agent with audit records but no cert)
            agent_id = identifier
            agent_name = identifier

    if args.verify:
        _audit_verify(args.base_dir, agent_id)
    elif args.summary:
        _audit_summary(args.base_dir, agent_id)
    elif args.delegations:
        _audit_delegations(args.base_dir, agent_id, limit=args.limit)
    else:
        _audit_records(args.base_dir, agent_id, limit=args.limit, severity=args.severity)

    if getattr(args, "push_agicomply", False):
        _audit_push_agicomply(args)


def _audit_push_agicomply(args: argparse.Namespace) -> None:
    """Push audit records to AGICOMPLY's ingestion API."""
    from nomotic.audit_store import AuditStore
    from nomotic.integrations.agicomply import (
        AGICOMPLYClient,
        AGICOMPLYConfig,
        AGICOMPLYError,
    )

    identifier = args.identifier
    agent_id = None
    if identifier:
        try:
            _numeric_id, resolved_name, _cert_id = _resolve_agent(
                args.base_dir, identifier
            )
            agent_id = resolved_name
        except SystemExit:
            agent_id = identifier

    try:
        config = AGICOMPLYConfig.from_env()
    except ValueError as e:
        print(_red(f"AGICOMPLY config error: {e}"), file=sys.stderr)
        return

    if getattr(args, "agicomply_endpoint", None):
        config.endpoint = args.agicomply_endpoint

    audit_store = AuditStore(args.base_dir)
    records = []
    if agent_id:
        records = audit_store.query(
            agent_id, limit=args.limit, severity=args.severity
        )
    elif args.show_all:
        for name in audit_store.list_agents():
            records.extend(audit_store.query(name, limit=args.limit, severity=args.severity))

    if not records:
        print(_red("AGICOMPLY: no records to push"), file=sys.stderr)
        return

    try:
        client = AGICOMPLYClient(config)
        result = client.push_records(records)
        print(
            f"\nAGICOMPLY: {result['delivered']} delivered, "
            f"{result['failed']} failed"
        )
        if result["errors"]:
            for err in result["errors"]:
                print(f"  {_red('✗')} {err}")
    except AGICOMPLYError as e:
        print(_red(f"AGICOMPLY push failed: {e}"), file=sys.stderr)


def _audit_records(
    base_dir: Path,
    agent_id: str | None,
    limit: int = 20,
    severity: str | None = None,
) -> None:
    """Show recent audit records for an agent."""
    from nomotic.audit_store import AuditStore

    audit_store = AuditStore(base_dir)

    if agent_id is None:
        # --all mode: show records across all agents
        all_agents = audit_store.list_agents()
        if not all_agents:
            print()
            print(f"  {_bold('Audit Trail')}")
            print("  No records found.")
            print()
            print("  Audit records are created automatically when actions are")
            print("  evaluated through the Nomotic gateway or SDK.")
            print()
            return
        print()
        print(f"  {_bold('Audit Trail: All Agents')}")
        print()
        for name in sorted(all_agents):
            records = audit_store.query(name, limit=limit, severity=severity)
            if records:
                print(f"  {_bold(name)} ({len(records)} records)")
                for r in records[:5]:  # Show top 5 per agent
                    _print_audit_record(r)
                if len(records) > 5:
                    print(f"    ... and {len(records) - 5} more")
                print()
        return

    records = audit_store.query(agent_id, limit=limit, severity=severity)

    if not records:
        print()
        print(f"  {_bold(f'Audit Trail: {agent_id}')}")
        print("  No records found.")
        print()
        print("  Audit records are created automatically when actions are")
        print("  evaluated through the Nomotic gateway or SDK.")
        print()
        print(f"  To run test evaluations: nomotic test {agent_id} --action read --target my_db")
        print(f"  To view test history:    nomotic testlog {agent_id}")
        print()
        return

    print()
    print(f"  {_bold(f'Audit Trail: {agent_id}')} (last {len(records)} records)")
    print()

    for r in records:
        _print_audit_record(r)


def _audit_delegations(
    base_dir: Path,
    agent_id: str | None,
    limit: int = 20,
) -> None:
    """Show delegation records from the audit trail."""
    from nomotic.audit_store import AuditStore

    audit_store = AuditStore(base_dir)

    if agent_id is None:
        all_agents = audit_store.list_agents()
        if not all_agents:
            print()
            print(f"  {_bold('Delegation History')}")
            print("  No records found.")
            print()
            return
        print()
        print(f"  {_bold('Delegation History: All Agents')}")
        print()
        for name in sorted(all_agents):
            records = audit_store.query(name, limit=limit)
            delegations = [r for r in records if r.action_type == "delegate"]
            if delegations:
                print(f"  {_bold(name)} ({len(delegations)} delegations)")
                for r in delegations[:5]:
                    _print_audit_record(r)
                if len(delegations) > 5:
                    print(f"    ... and {len(delegations) - 5} more")
                print()
        return

    records = audit_store.query(agent_id, limit=limit)
    delegations = [r for r in records if r.action_type == "delegate"]

    if not delegations:
        print()
        print(f"  {_bold(f'Delegation History: {agent_id}')}")
        print("  No delegation records found.")
        print()
        return

    print()
    print(f"  {_bold(f'Delegation History: {agent_id}')} ({len(delegations)} records)")
    print()

    for r in delegations:
        _print_audit_record(r)


def _print_audit_record(r: "PersistentLogRecord", show_source: bool = False) -> None:
    """Print a single audit/log record."""
    from datetime import datetime as _dt
    from datetime import timezone as _tz

    ts = _dt.fromtimestamp(r.timestamp, tz=_tz.utc).strftime("%Y-%m-%d %H:%M:%S")
    verdict_color = _green if r.verdict == "ALLOW" else (_red if r.verdict == "DENY" else _yellow)
    source_tag = f" [{r.source}]" if show_source and hasattr(r, "source") and r.source else ""

    print(f"  {r.record_id}  {ts}  {verdict_color(r.verdict)}{source_tag}")
    print(f"    Action: {r.action_type} \u2192 {r.action_target}")
    print(f"    UCS: {r.ucs:.2f}  Tier: {r.tier}  Trust: {r.trust_score:.3f} ({r.trust_trend})")
    if r.vetoed_by:
        print(f"    Vetoed by: {', '.join(r.vetoed_by)}")
    if r.justification:
        just = r.justification[:120]
        if len(r.justification) > 120:
            just += "..."
        print(f"    Why: {just}")
    print()


def _audit_summary(base_dir: Path, agent_id: str | None) -> None:
    """Show audit summary for an agent."""
    from nomotic.audit_store import AuditStore

    audit_store = AuditStore(base_dir)

    if agent_id is None:
        # --all mode
        all_agents = audit_store.list_agents()
        if not all_agents:
            print("  No audit records found.")
            return
        print()
        print(f"  {_bold('Audit Summary: All Agents')}")
        print()
        for name in sorted(all_agents):
            s = audit_store.summary(name)
            if s["total"] > 0:
                print(f"  {_bold(name)}: {s['total']} evaluations, trust {s.get('trust_start', 0.5):.3f} \u2192 {s.get('trust_end', 0.5):.3f}")
        print()
        return

    summary = audit_store.summary(agent_id)

    if summary["total"] == 0:
        print(f"  No audit records found for '{agent_id}'.")
        return

    total = summary["total"]
    print()
    print(f"  {_bold(f'Audit Summary: {agent_id}')}")
    print()
    print(f"  Total evaluations: {total}")
    print()

    print("  By verdict:")
    for v, count in sorted(summary["by_verdict"].items()):
        pct = count / total * 100
        color = _green if v == "ALLOW" else (_red if v == "DENY" else _yellow)
        bar_len = int(count / total * 40)
        bar = "\u2588" * bar_len
        print(f"    {color(f'{v:10s}')} {count:5d}  {bar}  {pct:.1f}%")
    print()

    print(f"  Trust: {summary.get('trust_start', 0.5):.3f} \u2192 {summary.get('trust_end', 0.5):.3f}")
    print()


def _audit_verify(base_dir: Path, agent_id: str | None) -> None:
    """Verify hash chain integrity for an agent's audit trail."""
    from nomotic.audit_store import AuditStore

    audit_store = AuditStore(base_dir)

    if agent_id is None:
        # --all mode
        all_agents = audit_store.list_agents()
        if not all_agents:
            print("  No audit records to verify.")
            return
        print()
        print(f"  {_bold('Audit Chain Verification: All Agents')}")
        print()
        _check = "\u2713"
        _cross = "\u2717"
        for name in sorted(all_agents):
            is_valid, count, message = audit_store.verify_chain(name)
            if count == 0:
                continue
            if is_valid:
                print(f"  {_green(_check)} {name}: {count} records verified")
            else:
                print(f"  {_red(_cross)} {name}: {message}")
        print()
        return

    is_valid, count, message = audit_store.verify_chain(agent_id)

    print()
    print(f"  {_bold(f'Audit Chain: {agent_id}')}")
    print()
    print(f"  Records: {count}")

    if count == 0:
        print("  No records to verify.")
        return

    records = audit_store.query_all(agent_id)
    from datetime import datetime as _dt
    from datetime import timezone as _tz

    first_ts = _dt.fromtimestamp(records[0].timestamp, tz=_tz.utc).strftime("%Y-%m-%d %H:%M:%S")
    last_ts = _dt.fromtimestamp(records[-1].timestamp, tz=_tz.utc).strftime("%Y-%m-%d %H:%M:%S")
    print(f"  First:   {first_ts}  ({records[0].action_type} \u2192 {records[0].action_target}, {records[0].verdict})")
    print(f"  Last:    {last_ts}  ({records[-1].action_type} \u2192 {records[-1].action_target}, {records[-1].verdict})")

    if is_valid:
        chain_ok = f"\u2713 All {count} records verified \u2014 no tampering detected"
        print(f"  Chain:   {_green(chain_ok)}")
        print(f"  Hash:    {records[-1].record_hash}")
    else:
        chain_fail = f"\u2717 {message}"
        print(f"  Chain:   {_red(chain_fail)}")
    print()


def _cmd_testlog(args: argparse.Namespace) -> None:
    """View test evaluation history."""
    identifier = getattr(args, "identifier", None)

    if not identifier:
        print("Specify an agent: nomotic testlog TestBot", file=sys.stderr)
        sys.exit(1)

    # Resolve agent name
    try:
        _numeric_id, resolved_name, _cert_id = _resolve_agent(args.base_dir, identifier)
        agent_id = resolved_name
    except SystemExit:
        agent_id = identifier

    if getattr(args, "clear", False):
        _testlog_clear(args.base_dir, agent_id)
        return

    from nomotic.audit_store import LogStore

    store = LogStore(args.base_dir, "testlog")

    if getattr(args, "verify", False):
        _testlog_verify(store, agent_id)
    elif getattr(args, "summary", False):
        _testlog_summary(store, agent_id)
    else:
        _testlog_records(store, agent_id, limit=getattr(args, "limit", 20))


def _testlog_records(
    store: "LogStore",
    agent_id: str,
    limit: int = 20,
) -> None:
    """Show recent test log records for an agent."""
    records = store.query(agent_id, limit=limit)

    if not records:
        print()
        print(f"  {_bold(f'Test Log: {agent_id}')}")
        print("  No records found.")
        print()
        print("  Run test evaluations with:")
        print(f"    nomotic test {agent_id} --action read --target my_db")
        print()
        return

    print()
    print(f"  {_bold(f'Test Log: {agent_id}')} (last {len(records)} records)")
    print()

    for r in records:
        _print_audit_record(r, show_source=True)


def _testlog_summary(store: "LogStore", agent_id: str) -> None:
    """Show test log summary for an agent."""
    summary = store.summary(agent_id)

    if summary.get("total", 0) == 0:
        print(f"  No test log records found for '{agent_id}'.")
        return

    total = summary["total"]
    print()
    print(f"  {_bold(f'Test Log Summary: {agent_id}')}")
    print()
    print(f"  Total evaluations: {total}")
    print()

    print("  By verdict:")
    for v, count in sorted(summary["by_verdict"].items()):
        pct = count / total * 100
        color = _green if v == "ALLOW" else (_red if v == "DENY" else _yellow)
        bar_len = int(count / total * 40)
        bar = "\u2588" * bar_len
        print(f"    {color(f'{v:10s}')} {count:5d}  {bar}  {pct:.1f}%")
    print()

    print(f"  Trust: {summary.get('trust_start', 0.5):.3f} \u2192 {summary.get('trust_end', 0.5):.3f}")
    print()


def _testlog_verify(store: "LogStore", agent_id: str) -> None:
    """Verify hash chain integrity for an agent's test log."""
    is_valid, count, message = store.verify_chain(agent_id)

    print()
    print(f"  {_bold(f'Test Log Chain: {agent_id}')}")
    print()
    print(f"  Records: {count}")

    if count == 0:
        print("  No records to verify.")
        return

    records = store.query_all(agent_id)
    from datetime import datetime as _dt
    from datetime import timezone as _tz

    first_ts = _dt.fromtimestamp(records[0].timestamp, tz=_tz.utc).strftime("%Y-%m-%d %H:%M:%S")
    last_ts = _dt.fromtimestamp(records[-1].timestamp, tz=_tz.utc).strftime("%Y-%m-%d %H:%M:%S")
    print(f"  First:   {first_ts}  ({records[0].action_type} \u2192 {records[0].action_target}, {records[0].verdict})")
    print(f"  Last:    {last_ts}  ({records[-1].action_type} \u2192 {records[-1].action_target}, {records[-1].verdict})")

    if is_valid:
        chain_ok = f"\u2713 All {count} records verified \u2014 no tampering detected"
        print(f"  Chain:   {_green(chain_ok)}")
        print(f"  Hash:    {records[-1].record_hash}")
    else:
        chain_fail = f"\u2717 {message}"
        print(f"  Chain:   {_red(chain_fail)}")
    print()


def _testlog_clear(base_dir: Path, agent_id: str) -> None:
    """Clear test history and reset simulated trust for an agent."""
    testlog_dir = base_dir / "testlog"
    safe_name = agent_id.lower()

    log_file = testlog_dir / f"{safe_name}.jsonl"
    trust_file = testlog_dir / f"{safe_name}.trust.json"

    cleared = False
    if log_file.exists():
        log_file.unlink()
        cleared = True
    if trust_file.exists():
        trust_file.unlink()
        cleared = True

    if cleared:
        print(f"  Test history cleared for {agent_id}.")
        print("  Simulated trust reset to production value.")
    else:
        print(f"  No test history found for {agent_id}.")


def _cmd_provenance(args: argparse.Namespace) -> None:
    """Show configuration provenance records (via API)."""
    import urllib.request
    import urllib.error

    base_url = f"http://{args.host}:{args.port}"
    url = f"{base_url}/v1/provenance?"
    params = []
    if args.target_type:
        params.append(f"target_type={args.target_type}")
    if args.target_id:
        params.append(f"target_id={args.target_id}")
    url += "&".join(params)

    try:
        req = urllib.request.Request(url)
        with urllib.request.urlopen(req) as resp:
            data = json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        print(f"API error: {exc.code} {exc.reason}", file=sys.stderr)
        sys.exit(1)
    except urllib.error.URLError as exc:
        print(f"Cannot connect to {base_url}: {exc.reason}", file=sys.stderr)
        sys.exit(1)

    records = data.get("records", [])
    if not records:
        print("No provenance records found.")
        return

    print(f"Provenance Records ({len(records)} shown):")
    for r in records:
        print(f"  [{r.get('change_type', '?'):6s}] {r.get('target_type', '?'):10s}/{r.get('target_id', '?'):15s} by {r.get('actor', '?')}")
        if r.get("reason"):
            print(f"          reason: {r['reason']}")


def _cmd_owner(args: argparse.Namespace) -> None:
    """Show owner activity and engagement (via API)."""
    import urllib.request
    import urllib.error

    base_url = f"http://{args.host}:{args.port}"
    owner_id = args.owner_id

    if args.engagement:
        url = f"{base_url}/v1/owner/{owner_id}/engagement"
        try:
            req = urllib.request.Request(url)
            with urllib.request.urlopen(req) as resp:
                data = json.loads(resp.read().decode("utf-8"))
        except urllib.error.HTTPError as exc:
            print(f"API error: {exc.code} {exc.reason}", file=sys.stderr)
            sys.exit(1)
        except urllib.error.URLError as exc:
            print(f"Cannot connect to {base_url}: {exc.reason}", file=sys.stderr)
            sys.exit(1)

        print(f"Owner Engagement: {owner_id}")
        print(f"  Total activities:     {data.get('total_activities', 0)}")
        print(f"  Activities in window: {data.get('activities_in_window', 0)}")
        print(f"  Alert response rate:  {data.get('alert_response_rate', 0):.1%}")
        print(f"  Engagement level:     {data.get('engagement_level', 'unknown')}")
        return

    url = f"{base_url}/v1/owner/{owner_id}/activity"
    try:
        req = urllib.request.Request(url)
        with urllib.request.urlopen(req) as resp:
            data = json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        print(f"API error: {exc.code} {exc.reason}", file=sys.stderr)
        sys.exit(1)
    except urllib.error.URLError as exc:
        print(f"Cannot connect to {base_url}: {exc.reason}", file=sys.stderr)
        sys.exit(1)

    activities = data.get("activities", [])
    if not activities:
        print(f"No activity for owner: {owner_id}")
        return

    print(f"Owner Activity: {owner_id} ({len(activities)} shown)")
    for a in activities:
        print(f"  {a.get('activity_type', '?'):25s} agent={a.get('target_agent_id', '-')}")
        if a.get("detail"):
            print(f"    {a['detail']}")


def _cmd_oversight(args: argparse.Namespace) -> None:
    """Show human oversight engagement profiles and drift analysis."""
    from nomotic.human_drift import (
        HumanAuditStore,
        HumanDriftCalculator,
        HumanDriftMonitor,
        HumanInteractionProfile,
        RoutingRecommendation,
        TeamOversightMetrics,
    )

    store = HumanAuditStore(args.base_dir)

    # --team: show team-level oversight health
    if args.team:
        reviewers = store.list_reviewers()
        if not reviewers:
            print("No human interaction data found.")
            return

        monitor = HumanDriftMonitor()
        for reviewer_id in reviewers:
            events = store.query_all(reviewer_id)
            for event in events:
                monitor.record_event(event)

        metrics = TeamOversightMetrics(monitor).compute()
        print(_bold("Team Oversight Health"))
        print(f"  Reviewers:             {metrics.get('total_reviewers', 0)}")
        print(f"  Profiled:              {metrics.get('profiled_reviewers', 0)}")
        print(f"  Total reviews:         {metrics.get('total_reviews', 0)}")
        print(f"  Team approval rate:    {metrics.get('team_approval_rate', 0):.1%}")
        print(f"  Team rationale rate:   {metrics.get('team_rationale_rate', 0):.1%}")
        spof = metrics.get("single_point_of_failure", False)
        conc = metrics.get("highest_concentration", 0)
        if spof:
            print(f"  {_red('!')} Single point of failure: {conc:.0%} concentration")
        else:
            print(f"  Highest concentration: {conc:.0%}")
        alert_count = metrics.get("active_alerts", 0)
        if alert_count > 0:
            print(f"  {_yellow('!')} Active drift alerts: {alert_count}")
        else:
            print("  Active drift alerts:   0")
        concentration = metrics.get("review_concentration", {})
        if concentration:
            print()
            print(_bold("  Review Distribution:"))
            for rid, share in sorted(concentration.items(), key=lambda x: -x[1]):
                print(f"    {rid:25s} {share:.1%}")
        return

    # --alerts: show all human drift alerts across all reviewers
    if args.alerts:
        reviewers = store.list_reviewers()
        if not reviewers:
            print("No human interaction data found.")
            return

        found_alerts = False
        for reviewer_id in reviewers:
            events = store.query_all(reviewer_id)
            if len(events) < 250:  # baseline_window(200) + recent_window(50)
                continue
            baseline = HumanInteractionProfile.from_events(reviewer_id, events[:200])
            recent = HumanInteractionProfile.from_events(reviewer_id, events[-50:])
            calculator = HumanDriftCalculator()
            result = calculator.calculate(baseline, recent)
            if result.alerts:
                found_alerts = True
                rec = RoutingRecommendation.from_drift_result(result)
                print(_bold(f"Reviewer: {reviewer_id}") + f"  [{_yellow(result.drift_category)}]")
                print(f"  Overall drift: {result.overall_drift:.3f}")
                print(f"  Routing:       {rec.recommendation} ({rec.urgency})")
                for alert in result.alerts:
                    print(f"  {_red('!')} {alert}")
                print()

        if not found_alerts:
            print("No human drift alerts detected.")
        return

    # Require reviewer_id for profile/drift views
    if args.reviewer_id is None:
        print("Usage: nomotic oversight <reviewer_id> [--drift] [--alerts] [--team]", file=sys.stderr)
        sys.exit(1)

    reviewer_id = args.reviewer_id
    events = store.query_all(reviewer_id)
    if not events:
        print(f"No events found for reviewer: {reviewer_id}")
        return

    # --drift: show drift analysis
    if args.drift:
        if len(events) < 250:
            print(f"Insufficient data for drift analysis. Have {len(events)} events, need 250+.")
            return
        baseline = HumanInteractionProfile.from_events(reviewer_id, events[:200])
        recent = HumanInteractionProfile.from_events(reviewer_id, events[-50:])
        calculator = HumanDriftCalculator()
        result = calculator.calculate(baseline, recent)
        rec = RoutingRecommendation.from_drift_result(result)

        print(_bold(f"Human Drift Analysis: {reviewer_id}"))
        print(f"  Category:          {result.drift_category}")
        print(f"  Overall drift:     {result.overall_drift:.3f}")
        print(f"  Risk timing drift: {result.risk_timing_drift:.3f}")
        print(f"  Timing drift:      {result.timing_drift:.3f}")
        print(f"  Decision drift:    {result.decision_drift:.3f}")
        print(f"  Engagement drift:  {result.engagement_drift:.3f}")
        print(f"  Throughput drift:  {result.throughput_drift:.3f}")
        print(f"  Fatigue score:     {result.fatigue_score:.3f}")
        print()
        print(_bold("Routing Recommendation:"))
        print(f"  Action:  {rec.recommendation}")
        print(f"  Urgency: {rec.urgency}")
        print(f"  Reason:  {rec.reason}")
        if result.alerts:
            print()
            print(_bold("Alerts:"))
            for alert in result.alerts:
                print(f"  {_red('!')} {alert}")
        else:
            print(f"\n  {_green('OK')} No drift alerts.")
        return

    # Default: show engagement profile
    profile = HumanInteractionProfile.from_events(reviewer_id, events)
    print(_bold(f"Human Oversight Profile: {reviewer_id}"))
    print(f"  Total interactions:    {profile.total_interactions}")
    print(f"  Mean review duration:  {profile.mean_review_duration:.1f}s")
    print(f"  Median review duration:{profile.median_review_duration:.1f}s")
    print(f"  Approval rate:         {profile.approval_rate:.1%}")
    print(f"  Denial rate:           {profile.denial_rate:.1%}")
    print(f"  Modification rate:     {profile.modification_rate:.1%}")
    print(f"  Override rate:         {profile.override_rate:.1%}")
    print(f"  Rationale provided:    {profile.rationale_provided_rate:.1%}")
    print(f"  Context viewed:        {profile.context_view_rate:.1%}")
    print(f"  Mean rationale depth:  {profile.mean_rationale_depth:.1f} words")
    print(f"  Throughput:            {profile.interactions_per_hour:.1f}/hr")
    if profile.high_risk_interactions > 0:
        print(f"  High-risk reviews:     {profile.high_risk_interactions}")
        print(f"  High-risk avg duration:{profile.high_risk_mean_duration:.1f}s")
        print(f"  High-risk rationale:   {profile.high_risk_rationale_rate:.1%}")
    print(f"  Consecutive approvals: {profile.consecutive_approvals}")
    print(f"  Reviews last hour:     {profile.reviews_last_hour}")


def _cmd_scope(args: argparse.Namespace) -> None:
    """Configure or view an agent's authorized scope."""
    from nomotic.sandbox import (
        AgentConfig,
        load_agent_config,
        save_agent_config,
    )

    agent_id = args.agent_id
    sub = args.scope_command

    if sub == "set":
        config = load_agent_config(args.base_dir, agent_id) or AgentConfig(agent_id=agent_id)
        if args.actions:
            config.actions = [a.strip() for a in args.actions.split(",")]
        if args.boundaries:
            config.boundaries = [b.strip() for b in args.boundaries.split(",")]
        save_agent_config(args.base_dir, config)

        print(f"Scope configured for {agent_id}:")
        print(f"  Allowed actions:  {', '.join(config.actions)}")
        print(f"  Boundaries:       {', '.join(config.boundaries)}")
        print()
        _print_authority_envelope(agent_id, config)

    elif sub == "show":
        config = load_agent_config(args.base_dir, agent_id)
        if config is None:
            print(f"No configuration found for agent: {agent_id}", file=sys.stderr)
            sys.exit(1)
        _print_authority_envelope(agent_id, config)

    else:
        print("Unknown scope subcommand. Use 'set' or 'show'.", file=sys.stderr)
        sys.exit(1)


def _print_authority_envelope(agent_id: str, config: "AgentConfig") -> None:
    """Print the formatted authority envelope box."""
    actions_str = "  ".join(config.actions) if config.actions else "(none)"
    boundaries = config.boundaries or []

    width = 45
    print(f"  {'':>{0}}{_bold(chr(9484))}{chr(9472) * width}{_bold(chr(9488))}")
    print(f"  {_bold(chr(9474))}  {agent_id} Authority Envelope{' ' * (width - len(agent_id) - 22)}{_bold(chr(9474))}")
    print(f"  {_bold(chr(9474))}{' ' * width}{_bold(chr(9474))}")
    print(f"  {_bold(chr(9474))}  Actions: {actions_str}{' ' * max(0, width - len(actions_str) - 12)}{_bold(chr(9474))}")
    print(f"  {_bold(chr(9474))}{' ' * width}{_bold(chr(9474))}")
    if boundaries:
        print(f"  {_bold(chr(9474))}  Can touch:{' ' * (width - 13)}{_bold(chr(9474))}")
        for b in boundaries:
            line = f"    {_green(chr(10003))} {b}"
            # Count visible chars (without ANSI)
            visible_len = len(f"    {chr(10003)} {b}")
            pad = width - visible_len - 2
            print(f"  {_bold(chr(9474))}  {line}{' ' * max(0, pad)}{_bold(chr(9474))}")
    else:
        print(f"  {_bold(chr(9474))}  Boundaries: (none){' ' * (width - 22)}{_bold(chr(9474))}")
    print(f"  {_bold(chr(9474))}{' ' * width}{_bold(chr(9474))}")
    print(f"  {_bold(chr(9474))}  Cannot touch: everything else{' ' * (width - 33)}{_bold(chr(9474))}")
    print(f"  {_bold(chr(9492))}{chr(9472) * width}{_bold(chr(9496))}")


def _cmd_rule(args: argparse.Namespace) -> None:
    """Add governance rules to an agent."""
    from nomotic.sandbox import (
        AgentConfig,
        EthicalRuleSpec,
        HumanOverrideSpec,
        load_agent_config,
        save_agent_config,
    )

    agent_id = args.agent_id
    config = load_agent_config(args.base_dir, agent_id) or AgentConfig(agent_id=agent_id)

    if args.rule_command != "add":
        print("Unknown rule subcommand. Use 'add'.", file=sys.stderr)
        sys.exit(1)

    rule_type = args.type

    if rule_type == "ethical":
        if not args.condition:
            print("--condition is required for ethical rules", file=sys.stderr)
            sys.exit(1)
        if not args.message:
            print("--message is required for ethical rules", file=sys.stderr)
            sys.exit(1)
        rule = EthicalRuleSpec(
            condition=args.condition,
            message=args.message,
            name=getattr(args, "name", "") or "",
        )
        config.ethical_rules.append(rule)
        save_agent_config(args.base_dir, config)

        print("Ethical rule added:")
        print(f"  Agent: {agent_id}")
        print(f"  Rule:  {rule.condition}")
        print(f"  If violated: \"{rule.message}\"")
        print("  Effect: VETO (cannot be overridden by score)")

    elif rule_type == "human-override":
        if not args.action:
            print("--action is required for human-override rules", file=sys.stderr)
            sys.exit(1)
        override = HumanOverrideSpec(
            action=args.action,
            message=args.message or f"Human approval required for '{args.action}'",
        )
        config.human_overrides.append(override)
        save_agent_config(args.base_dir, config)

        print("Human override rule added:")
        print(f"  Agent:  {agent_id}")
        print(f"  Action: {override.action}")
        print(f"  Effect: \"{override.message}\"")

    else:
        print(f"Unknown rule type: {rule_type}. Use 'ethical' or 'human-override'.", file=sys.stderr)
        sys.exit(1)


def _cmd_config(args: argparse.Namespace) -> None:
    """Manage Nomotic configuration values."""
    config_cmd = getattr(args, "config_command", None)
    if config_cmd == "set":
        _cmd_config_set(args)
        return
    # No subcommand — show help
    print("Usage: nomotic config set --retention <period>", file=sys.stderr)
    print("  Set global configuration values.", file=sys.stderr)
    print()
    print("  Options:", file=sys.stderr)
    print("    --retention  Audit retention period (2y, 3y, 5y, forever)", file=sys.stderr)
    sys.exit(1)


def _load_simulated_trust(base_dir: Path, agent_id: str, production_trust: float) -> float:
    """Load simulated trust, resetting if stale (>1 hour old)."""
    import time as _time

    trust_file = base_dir / "testlog" / f"{agent_id.lower()}.trust.json"
    if trust_file.exists():
        try:
            data = json.loads(trust_file.read_text(encoding="utf-8"))
            age = _time.time() - data.get("last_updated", 0)
            if age < 3600:  # 1 hour
                return data.get("simulated_trust", production_trust)
        except (json.JSONDecodeError, KeyError):
            pass
    return production_trust


def _save_simulated_trust(
    base_dir: Path, agent_id: str, simulated: float, production: float,
) -> None:
    """Save simulated trust state."""
    import time as _time

    testlog_dir = base_dir / "testlog"
    testlog_dir.mkdir(parents=True, exist_ok=True)
    trust_file = testlog_dir / f"{agent_id.lower()}.trust.json"
    trust_file.write_text(json.dumps({
        "simulated_trust": simulated,
        "production_trust_at_start": production,
        "last_updated": _time.time(),
    }, indent=2), encoding="utf-8")


def _cmd_test(args: argparse.Namespace) -> None:
    """Run a simulated governance evaluation. Does not affect production trust."""

    # ── adversarial mode ──────────────────────────────────────────
    if getattr(args, "adversarial", False):
        _run_adversarial(args)
        return

    # ── single-action mode (original behaviour) ──────────────────
    if not args.action:
        print("error: --action is required (or use --adversarial)", file=sys.stderr)
        sys.exit(1)

    from nomotic.sandbox import (
        AgentConfig,
        build_sandbox_runtime,
        load_agent_config,
    )

    from nomotic.sandbox import format_bar
    from nomotic.types import Action as GovAction, AgentContext as GovCtx, Verdict

    agent_id = args.agent_id
    action_type = args.action
    target = args.target or ""
    params = {}
    if args.params:
        try:
            params = json.loads(args.params)
        except json.JSONDecodeError:
            print(f"Invalid JSON for --params: {args.params}", file=sys.stderr)
            sys.exit(1)

    # Load agent config
    config = load_agent_config(args.base_dir, agent_id)
    if config is None:
        config = AgentConfig(agent_id=agent_id)

    # Load certificate for production trust
    ca, _store = _build_ca(args.base_dir)
    from nomotic.sandbox import find_agent_cert_id
    cert_id = find_agent_cert_id(args.base_dir, agent_id)
    cert = ca.get(cert_id) if cert_id else None
    production_trust = cert.trust_score if cert else 0.5

    # Load simulated trust (or reset from production)
    simulated_trust = _load_simulated_trust(args.base_dir, agent_id, production_trust)

    # Build runtime and evaluate using simulated trust
    runtime = build_sandbox_runtime(agent_config=config, agent_id=agent_id)
    trust_profile = runtime.get_trust_profile(agent_id)
    trust_profile.overall_trust = simulated_trust

    action = GovAction(
        agent_id=agent_id,
        action_type=action_type,
        target=target,
        parameters=params,
    )
    ctx = GovCtx(agent_id=agent_id, trust_profile=trust_profile)

    verdict = runtime.evaluate(action, ctx)

    # Calculate simulated trust delta
    new_simulated = runtime.get_trust_profile(agent_id).overall_trust
    sim_delta = new_simulated - simulated_trust
    new_simulated = round(max(0.0, min(1.0, new_simulated)), 3)

    # Save simulated trust (do NOT touch production)
    _save_simulated_trust(args.base_dir, agent_id, new_simulated, production_trust)

    # Display results
    print()
    print(_bold(_cyan("=" * 55)))
    print(_bold(_cyan("  TEST EVALUATION (simulated \u2014 does not affect production trust)")))
    print(_bold(_cyan("=" * 55)))
    print()
    print(f"  Agent:   {agent_id}")
    target_str = f" {chr(8594)} {target}" if target else ""
    print(f"  Action:  {action_type}{target_str}")
    if params:
        print(f"  Params:  {json.dumps(params)}")
    print()

    # Dimension scores
    print(f"  {_bold(chr(9472) * 2 + ' Dimension Scores ' + chr(9472) * 30)}")
    print()

    for ds in verdict.dimension_scores:
        bar = format_bar(ds.score, 20)
        name_padded = f"{ds.dimension_name:26s}"
        score_str = f"{ds.score:.2f}"

        if ds.veto and ds.score < 0.5:
            check = _red(f"{chr(10007)} VETO: {ds.reasoning}")
            color_score = _red(score_str)
        elif ds.score >= 0.7:
            check = _green(ds.reasoning)
            color_score = _green(score_str)
        elif ds.score >= 0.4:
            check = _yellow(ds.reasoning)
            color_score = _yellow(score_str)
        else:
            check = _red(ds.reasoning)
            color_score = _red(score_str)

        print(f"  {name_padded} {color_score}  {bar}  {check}")

    # Decision
    print()
    print(f"  {_bold(chr(9472) * 2 + ' Decision ' + chr(9472) * 38)}")
    print()

    ucs_str = f"{verdict.ucs:.3f}"
    tier_labels = {1: "veto gate", 2: "threshold evaluation", 3: "deliberative review"}
    tier_label = tier_labels.get(verdict.tier, "unknown")

    if verdict.verdict == Verdict.ALLOW:
        verdict_display = _green(f"{chr(9989)} ALLOW")
    elif verdict.verdict == Verdict.DENY:
        verdict_display = _red(f"{chr(10060)} DENY")
    elif verdict.verdict == Verdict.ESCALATE:
        verdict_display = _yellow(f"{chr(9888)} ESCALATE")
    else:
        verdict_display = _yellow(f"{chr(9888)} {verdict.verdict.name}")

    print(f"  UCS:      {ucs_str}")
    print(f"  Tier:     {verdict.tier} ({tier_label})")
    print(f"  Verdict:  {verdict_display}")
    if verdict.vetoed_by:
        print(f"  Vetoed by: {', '.join(verdict.vetoed_by)}")
    if verdict.reasoning:
        print(f"  Reason:   {verdict.reasoning}")
    print(f"  Time:     {verdict.evaluation_time_ms:.1f}ms")

    # Trust (Simulated)
    sign = "+" if sim_delta >= 0 else ""
    delta_color = _green if sim_delta > 0 else (_red if sim_delta < 0 else _yellow)

    trend = "stable"
    if sim_delta > 0.001:
        trend = f"{chr(8599)} rising"
    elif sim_delta < -0.001:
        trend = f"{chr(8600)} falling"

    print()
    print(f"  {_bold(chr(9472) * 2 + ' Trust (Simulated) ' + chr(9472) * 29)}")
    print()
    print(f"  Production trust:  {production_trust:.3f} (unchanged)")
    print(f"  Simulated:         {simulated_trust:.3f} {chr(8594)} {new_simulated:.3f}  ({delta_color(f'{sign}{sim_delta:.3f}')})")
    print(f"  Trend:             {trend}")

    if sim_delta < -0.01:
        ratio = abs(sim_delta) / 0.01
        print()
        print(f"  {_yellow(chr(9888))} Note: violations cost 5x more trust than successes earn.")
        if ratio > 1:
            print(f"  This one denial erased ~{int(ratio)} successful actions.")
    print()
    print(f"  {_yellow(chr(9888))} This is a test. Production trust is not affected.")
    print(f"  Test history: nomotic testlog {agent_id}")
    print()

    # Persist to testlog (NOT audit)
    import time as _time
    from nomotic.audit_store import LogStore, PersistentLogRecord

    test_store = LogStore(args.base_dir, "testlog")
    previous_hash = test_store.get_last_hash(agent_id)

    dim_scores = {ds.dimension_name: ds.score for ds in verdict.dimension_scores}
    vetoed = list(verdict.vetoed_by) if verdict.vetoed_by else []

    record_data = {
        "record_id": verdict.action_id[:12],
        "timestamp": _time.time(),
        "agent_id": agent_id,
        "action_type": action_type,
        "action_target": target,
        "verdict": verdict.verdict.name,
        "ucs": verdict.ucs,
        "tier": verdict.tier,
        "trust_score": new_simulated,
        "trust_delta": sim_delta,
        "trust_trend": trend.replace("\u2197 ", "").replace("\u2198 ", ""),
        "severity": "alert" if verdict.verdict.name == "DENY" else "info",
        "justification": verdict.reasoning or "",
        "vetoed_by": vetoed,
        "dimension_scores": dim_scores,
        "parameters": params,
        "source": "cli-test",
        "previous_hash": previous_hash,
        "record_hash": "",
    }
    record_data["record_hash"] = test_store.compute_hash(record_data, previous_hash)

    test_record = PersistentLogRecord(**record_data)
    test_store.append(test_record)


def _run_adversarial(args: argparse.Namespace) -> None:
    """Run adversarial red team scenarios against an agent."""
    from nomotic.adversarial import (
        AdversarialRunner,
        CATEGORIES,
        format_report,
        format_summary,
    )

    agent_id = args.agent_id
    category = getattr(args, "category", None)
    detailed = getattr(args, "report", False)

    # Validate category if provided
    if category and category not in CATEGORIES:
        valid = ", ".join(sorted(CATEGORIES))
        print(f"Unknown category: {category}", file=sys.stderr)
        print(f"Valid categories: {valid}", file=sys.stderr)
        sys.exit(1)

    runner = AdversarialRunner(base_dir=args.base_dir, agent_id=agent_id)

    if category:
        results = runner.run_category(category)
    else:
        results = runner.run_all()

    if detailed:
        print(format_report(results, agent_id))
    else:
        print(format_summary(results, agent_id))


def _cmd_simulate(args: argparse.Namespace) -> None:
    """Run a batch simulation of governance evaluations."""
    from nomotic.sandbox import (
        AgentConfig,
        build_sandbox_runtime,
        format_pct_bar,
        load_agent_config,
    )
    from nomotic.scenarios import BUILTIN_SCENARIOS, generate_actions
    from nomotic.types import AgentContext as GovCtx

    agent_id = args.agent_id
    scenario_name = args.scenario
    count = args.count

    if scenario_name not in BUILTIN_SCENARIOS:
        print(f"Unknown scenario: {scenario_name}", file=sys.stderr)
        print(f"Available: {', '.join(BUILTIN_SCENARIOS.keys())}", file=sys.stderr)
        sys.exit(1)

    scenario = BUILTIN_SCENARIOS[scenario_name]

    # Load agent config
    config = load_agent_config(args.base_dir, agent_id)
    if config is None:
        config = AgentConfig(agent_id=agent_id)

    # Load initial trust from cert
    ca, _store = _build_ca(args.base_dir)
    from nomotic.sandbox import find_agent_cert_id
    cert_id = find_agent_cert_id(args.base_dir, agent_id)
    cert = ca.get(cert_id) if cert_id else None
    initial_trust = cert.trust_score if cert else 0.5

    # Build runtime
    runtime = build_sandbox_runtime(agent_config=config, agent_id=agent_id)
    trust_profile = runtime.get_trust_profile(agent_id)
    trust_profile.overall_trust = initial_trust

    # Generate actions
    actions = generate_actions(agent_id, scenario, total_count=count if count else None)

    # Prepare audit store for persistent records
    import time as _time
    from nomotic.audit_store import AuditStore, PersistentAuditRecord

    audit_store = AuditStore(args.base_dir)

    # Run simulation
    print()
    print(f"  {_bold(f'Simulating: {scenario.description}')}")
    print()

    trust_history: list[float] = [initial_trust]
    results = {"ALLOW": 0, "DENY": 0, "ESCALATE": 0, "MODIFY": 0}
    current_phase = ""
    previous_hash = audit_store.get_last_hash(agent_id)

    for i, (action, phase_desc) in enumerate(actions):
        if phase_desc != current_phase:
            current_phase = phase_desc
            print(f"  {_cyan(f'Phase: {phase_desc}')}")

        prev_trust = runtime.get_trust_profile(agent_id).overall_trust
        ctx = GovCtx(agent_id=agent_id, trust_profile=runtime.get_trust_profile(agent_id))
        verdict = runtime.evaluate(action, ctx)
        results[verdict.verdict.name] = results.get(verdict.verdict.name, 0) + 1
        new_trust = runtime.get_trust_profile(agent_id).overall_trust
        trust_history.append(new_trust)

        # Persist audit record
        delta = new_trust - prev_trust
        trend = "stable"
        if delta > 0.001:
            trend = "rising"
        elif delta < -0.001:
            trend = "falling"

        dim_scores = {ds.dimension_name: ds.score for ds in verdict.dimension_scores}
        vetoed = list(verdict.vetoed_by) if verdict.vetoed_by else []

        record_data = {
            "record_id": verdict.action_id[:12],
            "timestamp": _time.time(),
            "agent_id": agent_id,
            "action_type": action.action_type,
            "action_target": action.target,
            "verdict": verdict.verdict.name,
            "ucs": verdict.ucs,
            "tier": verdict.tier,
            "trust_score": new_trust,
            "trust_delta": delta,
            "trust_trend": trend,
            "severity": "alert" if verdict.verdict.name == "DENY" else "info",
            "justification": verdict.reasoning or "",
            "vetoed_by": vetoed,
            "dimension_scores": dim_scores,
            "parameters": dict(action.parameters) if action.parameters else {},
            "source": "cli-simulate",
            "previous_hash": previous_hash,
            "record_hash": "",
        }
        record_data["record_hash"] = audit_store.compute_hash(record_data, previous_hash)
        audit_record = PersistentAuditRecord(**record_data)
        audit_store.append(audit_record)
        previous_hash = record_data["record_hash"]

        # Progress indicator
        total = len(actions)
        bar_width = 40
        filled = int((i + 1) / total * bar_width)
        bar = chr(9608) * filled + chr(9617) * (bar_width - filled)
        print(f"\r  [{bar}] {i + 1}/{total}", end="", flush=True)

    print()  # newline after progress bar
    print()

    # Behavioral Fingerprint
    fp = runtime.get_fingerprint(agent_id)
    if fp is not None:
        print(f"  {_bold(chr(9472) * 2 + ' Behavioral Fingerprint ' + chr(9472) * 24)}")
        print()
        print(f"  Observations: {fp.total_observations}")
        print(f"  Confidence:   {fp.confidence:.2f}")
        print()

        if fp.action_distribution:
            print("  Action Distribution:")
            for act, freq in sorted(fp.action_distribution.items(), key=lambda x: -x[1]):
                bar = format_pct_bar(freq)
                print(f"    {act:20s} {bar}  {freq:.0%}")
            print()

        if fp.target_distribution:
            print("  Target Distribution:")
            for tgt, freq in sorted(fp.target_distribution.items(), key=lambda x: -x[1]):
                bar = format_pct_bar(freq)
                print(f"    {tgt:20s} {bar}  {freq:.0%}")
            print()

    # Drift detection
    drift = runtime.get_drift(agent_id)
    if drift is not None and drift.overall > 0.05:
        print(f"  {_bold(chr(9472) * 2 + ' Drift Detection Report ' + chr(9472) * 24)}")
        print()
        sev = drift.severity
        color = _red if sev in ("high", "critical") else (_yellow if sev == "moderate" else _green)
        print(f"  Drift Score:    {color(f'{drift.overall:.2f}')} ({sev.upper()})")
        print(f"  JSD Divergence: {drift.action_drift:.2f}")
        if drift.detail:
            print(f"  Detail:         {drift.detail}")
        print()

        # Show alerts
        alerts = runtime.get_drift_alerts(agent_id)
        if alerts:
            for alert in alerts:
                sev_color = _red if alert.severity in ("critical", "high") else _yellow
                print(f"  {sev_color(chr(9888))} DRIFT ALERT:")
                print(f"    Severity: {alert.severity.upper()}")
                if alert.drift_score.detail:
                    print(f"    Message:  {alert.drift_score.detail}")
            print()

    # Trust trajectory
    print(f"  {_bold(chr(9472) * 2 + ' Trust Trajectory ' + chr(9472) * 30)}")
    print()
    end_trust = trust_history[-1]
    trend = "stable"
    if end_trust > initial_trust + 0.02:
        trend = "rising"
    elif end_trust < initial_trust - 0.02:
        trend = "falling"

    print(f"  Start: {initial_trust:.3f} {chr(8594)} End: {end_trust:.3f}")
    print(f"  Trend: {trend}")
    print()

    # Visual trust trajectory
    n_rows = 6
    min_t = min(trust_history)
    max_t = max(trust_history)
    t_range = max_t - min_t if max_t > min_t else 0.1
    chart_width = min(40, len(trust_history))
    step = max(1, len(trust_history) // chart_width)
    sampled = [trust_history[i] for i in range(0, len(trust_history), step)]

    for row in range(n_rows, -1, -1):
        level = min_t + (row / n_rows) * t_range
        label = f"  {level:.2f} |"
        chars = []
        for val in sampled:
            val_row = int((val - min_t) / t_range * n_rows) if t_range > 0 else n_rows // 2
            if val_row == row:
                chars.append(".")
            elif val_row > row:
                chars.append(" ")
            else:
                chars.append(" ")
        print(f"{label}{''.join(chars)}|")
    total_actions = len(actions)
    print(f"         {chr(9492)}{chr(9472) * len(sampled)}{chr(9496)}")
    label_str = f"         0{' ' * (len(sampled) - len(str(total_actions)) - 1)}{total_actions}"
    print(label_str)
    print()

    # Summary
    allowed = results.get("ALLOW", 0)
    denied = results.get("DENY", 0)
    escalated = results.get("ESCALATE", 0)

    print(f"  {_green(chr(10003))} {total_actions} actions evaluated")
    print(f"  {_green(chr(10003))} {_green(str(allowed))} allowed, {_red(str(denied))} denied", end="")
    if escalated:
        print(f", {_yellow(str(escalated))} escalated", end="")
    print()
    if fp:
        print(f"  {_green(chr(10003))} Fingerprint established")
    print(f"  {_green(chr(10003))} Trust trajectory: {trend}")
    print()

    # Update certificate trust
    if cert is not None:
        ca.update_trust(cert.certificate_id, end_trust)


def _cmd_config_set(args: argparse.Namespace) -> None:
    """Handle 'nomotic config set --retention <period>'."""
    if args.retention is not None:
        valid_periods = {"2y", "3y", "5y", "forever"}
        if args.retention not in valid_periods:
            print(f"Invalid retention period: {args.retention}", file=sys.stderr)
            print(f"  Valid values: {', '.join(sorted(valid_periods))}", file=sys.stderr)
            sys.exit(1)
        config_path = args.base_dir / "config.json"
        config_data: dict = {}
        if config_path.exists():
            config_data = json.loads(config_path.read_text(encoding="utf-8"))
        config_data["retention"] = args.retention
        args.base_dir.mkdir(parents=True, exist_ok=True)
        config_path.write_text(json.dumps(config_data, indent=2), encoding="utf-8")
        print(f"Retention set to: {args.retention}")
        print("  Note: Retention is recorded but not yet enforced (all records are kept).")
    else:
        print("No configuration value specified.", file=sys.stderr)
        print("  Use --retention to set audit retention period.", file=sys.stderr)
        sys.exit(1)


def _cmd_history(args: argparse.Namespace) -> None:
    """Show the complete historical record for any agent (including revoked)."""
    numeric_id, name, cert_id = _resolve_agent(args.base_dir, args.identifier)

    ca, _store = _build_ca(args.base_dir)
    cert = ca.get(cert_id)

    registry = _load_registry(args.base_dir)
    entry = registry.get(numeric_id) if numeric_id > 0 else None

    status = "UNKNOWN"
    revoked_at = ""
    reason = ""
    seal_data: dict = {}

    if entry:
        status = entry.get("status", "UNKNOWN")
    elif cert:
        status = cert.status.name

    # Check for revocation seal
    seal_path = args.base_dir / "revocations" / f"{numeric_id}.json"
    if seal_path.exists():
        try:
            seal_data = json.loads(seal_path.read_text(encoding="utf-8"))
            revoked_at = seal_data.get("revoked_at", "")
            reason = seal_data.get("reason", "")
        except (json.JSONDecodeError, KeyError):
            pass

    # Load audit store data
    from nomotic.audit_store import AuditStore
    audit_store = AuditStore(args.base_dir)
    audit_summary = audit_store.summary(name)
    is_valid, chain_count, chain_msg = audit_store.verify_chain(name)

    print()
    print(f"History: {name} (ID: {numeric_id})")

    if status == "REVOKED" and revoked_at:
        print(f"  Status: {_red('REVOKED')} ({revoked_at[:10]})")
    else:
        status_color = _green if status == "ACTIVE" else (_yellow if status == "SUSPENDED" else _dim)
        print(f"  Status: {status_color(status)}")
    print(f"  {'─' * 37}")
    print()

    # Lifecycle
    print("  Lifecycle:")
    if cert:
        print(f"    Born:     {cert.issued_at.strftime('%Y-%m-%d %H:%M')}  (trust: 0.500)")
    elif entry:
        created = entry.get("created_at", "unknown")
        print(f"    Born:     {created[:16] if len(created) >= 16 else created}  (trust: 0.500)")

    if seal_data:
        peak_trust = seal_data.get("peak_trust", 0.5)
        final_trust = seal_data.get("final_trust", 0.05)
        total_evals = seal_data.get("total_evaluations", 0)
        total_violations = seal_data.get("total_violations", 0)
        print(f"    Peak:     (trust: {peak_trust:.3f})")
        if revoked_at:
            print(f"    Revoked:  {revoked_at[:16]}  (trust: {final_trust:.3f})")
        if reason:
            print(f"    Reason:   {reason}")

        print()
        print("  Summary:")
        allowed = total_evals - total_violations
        violation_rate = (total_violations / total_evals * 100) if total_evals > 0 else 0.0
        print(f"    Total evaluations:  {total_evals}")
        print(f"    Allowed:            {allowed}")
        print(f"    Denied:             {total_violations}")
        print(f"    Violation rate:     {violation_rate:.1f}%")

        audit_seal = seal_data.get("audit_seal", "")
        if audit_seal:
            print()
            print(f"  Audit seal: {audit_seal}")

        chain_verified = seal_data.get("chain_records", 0)
        if chain_verified > 0:
            print(f"  Chain integrity: verified ({chain_verified} records)")
    elif cert:
        trust = cert.trust_score
        age = cert.behavioral_age
        print(f"    Current:  (trust: {trust:.3f})")
        print()
        print("  Summary:")
        print(f"    Behavioral age:     {age}")
        print(f"    Current trust:      {trust:.3f}")

    # Persistent audit trail info
    if audit_summary.get("total", 0) > 0:
        total = audit_summary["total"]
        print()
        print("  Persistent Audit Trail:")
        print(f"    Records:   {total}")
        if audit_summary.get("by_verdict"):
            verdicts = []
            for v, c in sorted(audit_summary["by_verdict"].items()):
                verdicts.append(f"{c} {v}")
            print(f"    Verdicts:  {', '.join(verdicts)}")
        trust_start = audit_summary.get("trust_start", 0.5)
        trust_end = audit_summary.get("trust_end", 0.5)
        print(f"    Trust:     {trust_start:.3f} \u2192 {trust_end:.3f}")

        if chain_count > 0:
            if is_valid:
                _ok = "\u2713 verified"
                print(f"    Chain:     {_green(_ok)} ({chain_count} records)")
            else:
                _fail = f"\u2717 {chain_msg}"
                print(f"    Chain:     {_red(_fail)}")

    print()


def _cmd_tutorial(args: argparse.Namespace) -> None:
    """Run the interactive governance tutorial — the full developer journey."""
    import time as _time

    from nomotic.monitor import DriftConfig as _DriftConfig
    from nomotic.runtime import GovernanceRuntime, RuntimeConfig
    from nomotic.sandbox import (
        AgentConfig,
        EthicalRuleSpec,
        HumanOverrideSpec,
        apply_config_to_runtime,
        format_pct_bar,
    )
    from nomotic.store import MemoryCertificateStore
    from nomotic.types import Action as GovAction, AgentContext as GovCtx, Verdict

    interactive = sys.stdin.isatty() and _COLORS_ENABLED

    def _pause(msg: str = "Press Enter to continue...") -> None:
        if interactive:
            input(f"\n  {_dim(msg)}")
        print()

    def _header(chapter: str, title: str) -> None:
        print()
        print(_bold(_cyan("=" * 60)))
        print(_bold(_cyan(f"  {chapter}: {title}")))
        print(_bold(_cyan("=" * 60)))
        print()

    def _section(title: str) -> None:
        print(f"  {_bold(chr(9472) * 2 + ' ' + title + ' ' + chr(9472) * max(0, 45 - len(title)))}")
        print()

    # ── Chapter 1: Identity ─────────────────────────────────────────

    _header("Chapter 1", "Identity \u2014 \"Who is this agent?\"")
    print("  Every AI agent starts with a birth certificate \u2014 a cryptographically")
    print("  signed identity. Let's create one.")
    print()

    issuer_sk, issuer_vk = SigningKey.generate()
    store = MemoryCertificateStore()
    ca = CertificateAuthority(
        issuer_id="playground-issuer",
        signing_key=issuer_sk,
        store=store,
    )

    cert, agent_sk = ca.issue(
        agent_id="claims-bot",
        archetype="customer-experience",
        organization="acme-insurance",
        zone_path="us/production",
        owner="chris@acme.com",
    )

    print(f"  {_green('Certificate issued')}: {cert.certificate_id}")
    print(f"    Agent:     {cert.agent_id}")
    print(f"    Owner:     {cert.owner}")
    print(f"    Archetype: {cert.archetype}")
    print(f"    Org:       {cert.organization}")
    print(f"    Zone:      {cert.zone_path}")
    print(f"    Trust:     {cert.trust_score}")
    print(f"    Age:       {cert.behavioral_age}")
    print(f"    Status:    {cert.status.name}")
    print(f"    Issued:    {cert.issued_at.isoformat()}")
    print(f"    Fingerprint: {cert.fingerprint[:16]}...")
    print()
    print(f"  {_dim('What you learned: Every agent has an identity.')}")
    print(f"  {_dim('It is cryptographically signed, has a human owner,')}")
    print(f"  {_dim('lives in a governance zone, and starts with 0.50 trust.')}")

    _pause()

    # ── Chapter 2: Authority ────────────────────────────────────────

    _header("Chapter 2", 'Authority \u2014 "What can this agent do?"')
    print("  Now we define what this agent is allowed to do. Scope controls which")
    print("  actions. Boundaries control which resources. Rules add hard limits.")
    print()

    agent_config = AgentConfig(
        agent_id="claims-bot",
        actions=["read", "write", "query", "assess"],
        boundaries=["claims_db", "customer_records", "policy_db"],
        ethical_rules=[
            EthicalRuleSpec(
                condition="amount <= 10000",
                message="Claims over $10,000 require manual processing",
                name="max-claim-amount",
            ),
        ],
        human_overrides=[
            HumanOverrideSpec(
                action="approve",
                message="All claim approvals require human sign-off",
            ),
        ],
    )

    drift_cfg = _DriftConfig(window_size=50, check_interval=10, min_observations=10)
    runtime = GovernanceRuntime(config=RuntimeConfig(
        enable_fingerprints=True,
        drift_config=drift_cfg,
    ))
    runtime.set_certificate_authority(ca)
    runtime._cert_map["claims-bot"] = cert.certificate_id

    apply_config_to_runtime(runtime, agent_config)

    # Sync initial trust
    tp = runtime.get_trust_profile("claims-bot")
    tp.overall_trust = cert.trust_score

    print("  Scope configured:")
    print(f"    Allowed actions:  {', '.join(agent_config.actions)}")
    print(f"    Boundaries:       {', '.join(agent_config.boundaries)}")
    print()
    _print_authority_envelope("claims-bot", agent_config)
    print()

    print("  Ethical rule added:")
    print("    Rule:  amount <= 10000")
    print("    If violated: \"Claims over $10,000 require manual processing\"")
    print(f"    Effect: {_red('VETO')} (cannot be overridden by score)")
    print()

    print("  Human override rule added:")
    print(f"    Action '{_yellow('approve')}' requires human sign-off")
    print()

    print(f"  {_dim('What you learned: Authority is defined before the agent acts.')}")
    print(f"  {_dim('Scope controls actions. Boundaries control resources.')}")
    print(f"  {_dim('Rules add ethical constraints and human checkpoints.')}")

    _pause()

    # ── Chapter 3: Evaluation ───────────────────────────────────────

    _header("Chapter 3", 'Evaluation \u2014 "What happens when the agent acts?"')
    print("  When the agent tries to act, every action passes through 13 governance")
    print("  dimensions simultaneously. Watch what happens when we try allowed")
    print("  actions, then forbidden ones.")
    print()

    # Eval 1: authorized action
    _section("Evaluating: read \u2192 claims_db")

    action1 = GovAction(
        agent_id="claims-bot",
        action_type="read",
        target="claims_db",
        parameters={"claim_id": "CLM-5678"},
    )
    ctx1 = GovCtx(agent_id="claims-bot", trust_profile=runtime.get_trust_profile("claims-bot"))
    trust_before1 = ctx1.trust_profile.overall_trust
    v1 = runtime.evaluate(action1, ctx1)
    trust_after1 = runtime.get_trust_profile("claims-bot").overall_trust

    _print_evaluation(v1, trust_before1, trust_after1)

    _pause()

    # Eval 2: unauthorized action (out of scope)
    _section("Evaluating: delete \u2192 claims_db")

    action2 = GovAction(agent_id="claims-bot", action_type="delete", target="claims_db")
    ctx2 = GovCtx(agent_id="claims-bot", trust_profile=runtime.get_trust_profile("claims-bot"))
    trust_before2 = ctx2.trust_profile.overall_trust
    v2 = runtime.evaluate(action2, ctx2)
    trust_after2 = runtime.get_trust_profile("claims-bot").overall_trust

    _print_evaluation(v2, trust_before2, trust_after2)
    if v2.verdict == Verdict.DENY:
        print(f"  {_yellow(chr(9888))} Note: violations cost 5x more trust than successes earn.")
    print()

    _pause()

    # Eval 3: ethical violation
    _section("Evaluating: write \u2192 claims_db (amount=25000)")

    action3 = GovAction(
        agent_id="claims-bot",
        action_type="write",
        target="claims_db",
        parameters={"claim_id": "CLM-9999", "amount": 25000},
    )
    ctx3 = GovCtx(agent_id="claims-bot", trust_profile=runtime.get_trust_profile("claims-bot"))
    trust_before3 = ctx3.trust_profile.overall_trust
    v3 = runtime.evaluate(action3, ctx3)
    trust_after3 = runtime.get_trust_profile("claims-bot").overall_trust

    _print_evaluation(v3, trust_before3, trust_after3)

    _pause()

    # Eval 4: boundary breach
    _section("Evaluating: read \u2192 payroll_db (boundary breach)")

    action4 = GovAction(agent_id="claims-bot", action_type="read", target="payroll_db")
    ctx4 = GovCtx(agent_id="claims-bot", trust_profile=runtime.get_trust_profile("claims-bot"))
    trust_before4 = ctx4.trust_profile.overall_trust
    v4 = runtime.evaluate(action4, ctx4)
    trust_after4 = runtime.get_trust_profile("claims-bot").overall_trust

    _print_evaluation(v4, trust_before4, trust_after4)

    print(f"  {_dim('What you learned: Every action goes through 13 dimensions.')}")
    print(f"  {_dim('Some dimensions can veto (instant denial).')}")
    print(f"  {_dim('The UCS aggregates all scores into a single confidence number.')}")
    emdash = "\u2014"
    print(f"  {_dim('Trust updates asymmetrically ' + emdash + ' violations hurt 5x more.')}")

    _pause()

    # ── Chapter 4: Behavior ─────────────────────────────────────────

    _header("Chapter 4", 'Behavior \u2014 "What patterns does the agent develop?"')
    print("  After enough actions, the system learns what 'normal' looks like for")
    print("  this agent. Then we'll change the agent's behavior and watch the")
    print("  system detect the shift.")
    print()

    _section("Simulating 100 normal operations")

    import random
    normal_actions = [
        ("read", "claims_db"),
        ("read", "customer_records"),
        ("query", "claims_db"),
        ("query", "policy_db"),
        ("write", "claims_db"),
        ("read", "policy_db"),
        ("assess", "claims_db"),
    ]
    normal_weights = [25, 15, 15, 10, 10, 15, 10]

    trust_traj: list[float] = [runtime.get_trust_profile("claims-bot").overall_trust]

    for i in range(100):
        act_type, act_target = random.choices(normal_actions, weights=normal_weights, k=1)[0]
        params = {}
        if act_type == "write":
            params = {"claim_id": f"CLM-{random.randint(1000, 9999)}", "amount": random.randint(500, 9000)}
        elif act_type == "assess":
            params = {"claim_id": f"CLM-{random.randint(1000, 9999)}", "amount": random.randint(1000, 8000)}
        action = GovAction(agent_id="claims-bot", action_type=act_type, target=act_target, parameters=params)
        ctx = GovCtx(agent_id="claims-bot", trust_profile=runtime.get_trust_profile("claims-bot"))
        runtime.evaluate(action, ctx)
        trust_traj.append(runtime.get_trust_profile("claims-bot").overall_trust)

        bar_width = 40
        filled = int((i + 1) / 100 * bar_width)
        bar = chr(9608) * filled + chr(9617) * (bar_width - filled)
        print(f"\r  Simulating 100 normal operations... [{bar}] {i + 1}/100", end="", flush=True)

    print()
    print()

    # Show fingerprint
    fp = runtime.get_fingerprint("claims-bot")
    if fp is not None:
        print(f"  {_bold('Behavioral Fingerprint:')}")
        print(f"    Observations: {fp.total_observations}")
        print(f"    Confidence:   {fp.confidence:.2f}")
        print()

        if fp.action_distribution:
            print("    Action Distribution:")
            for act, freq in sorted(fp.action_distribution.items(), key=lambda x: -x[1]):
                bar = format_pct_bar(freq, 36)
                print(f"      {act:8s} {bar}  {freq:.0%}")
            print()

        if fp.target_distribution:
            print("    Target Distribution:")
            for tgt, freq in sorted(fp.target_distribution.items(), key=lambda x: -x[1]):
                bar = format_pct_bar(freq, 28)
                print(f"      {tgt:20s} {bar}  {freq:.0%}")
            print()

    # Show trust trajectory
    start_trust = trust_traj[0]
    end_trust = trust_traj[-1]
    print(f"  {_bold('Trust Trajectory:')}")
    print(f"    Start: {start_trust:.3f} {chr(8594)} End: {end_trust:.3f}")
    trend = "rising" if end_trust > start_trust + 0.02 else ("falling" if end_trust < start_trust - 0.02 else "stable")
    print(f"    Trend: {trend}")
    print()

    # Mini trajectory chart
    n_rows = 5
    min_t = min(trust_traj)
    max_t = max(trust_traj)
    t_range = max_t - min_t if max_t > min_t else 0.1
    chart_width = 40
    step = max(1, len(trust_traj) // chart_width)
    sampled = [trust_traj[i] for i in range(0, len(trust_traj), step)]

    for row in range(n_rows, -1, -1):
        level = min_t + (row / n_rows) * t_range
        label = f"  {level:.2f} |"
        chars = []
        for val in sampled:
            val_row = int((val - min_t) / t_range * n_rows) if t_range > 0 else n_rows // 2
            chars.append("." if val_row == row else " ")
        print(f"{label}{''.join(chars)}|")
    print(f"         {chr(9492)}{chr(9472) * len(sampled)}{chr(9496)}")
    print()

    allowed_count = sum(1 for t1, t2 in zip(trust_traj, trust_traj[1:]) if t2 >= t1)
    denied_count = 100 - allowed_count
    print(f"  {_green(chr(10003))} 100 actions evaluated")
    print(f"  {_green(chr(10003))} Fingerprint established")
    print(f"  {_green(chr(10003))} Trust trajectory: {trend}")

    _pause()

    # ── Chapter 4b: Drift ───────────────────────────────────────────

    _section("Introducing behavioral drift")

    trust_before_drift = runtime.get_trust_profile("claims-bot").overall_trust
    print("  Agent starts doing mostly deletes instead of reads...")
    print(f"  Trust before drift: {_green(f'{trust_before_drift:.3f}')}")
    print()

    drift_traj: list[float] = [trust_before_drift]

    for i in range(50):
        # 80% deletes, 10% reads on sensitive targets, 10% normal reads
        r = random.random()
        if r < 0.80:
            action = GovAction(agent_id="claims-bot", action_type="delete", target=random.choice(["claims_db", "customer_records", "policy_db"]))
        elif r < 0.90:
            action = GovAction(agent_id="claims-bot", action_type="read", target="payroll_db")
        else:
            action = GovAction(agent_id="claims-bot", action_type="read", target="claims_db")
        ctx = GovCtx(agent_id="claims-bot", trust_profile=runtime.get_trust_profile("claims-bot"))
        runtime.evaluate(action, ctx)
        drift_traj.append(runtime.get_trust_profile("claims-bot").overall_trust)

        bar_width = 40
        filled = int((i + 1) / 50 * bar_width)
        bar = chr(9608) * filled + chr(9617) * (bar_width - filled)
        print(f"\r  Simulating drift... [{bar}] {i + 1}/50", end="", flush=True)

    print()
    print()

    # Show drift
    drift = runtime.get_drift("claims-bot")
    if drift is not None:
        sev = drift.severity
        color = _red if sev in ("high", "critical") else (_yellow if sev == "moderate" else _green)
        print(f"  {_bold('Drift Detection Report:')}")
        print(f"    Drift Score:    {color(f'{drift.overall:.2f}')} ({sev.upper()})")
        print(f"    JSD Divergence: {drift.action_drift:.2f}")
        if drift.detail:
            print(f"    Detail:         {drift.detail}")
        print()

    # Trust erosion
    trust_after_drift = runtime.get_trust_profile("claims-bot").overall_trust
    erosion = trust_after_drift - trust_before_drift
    print(f"  {_bold('Trust Impact:')}")
    print(f"    Trust eroded by drift: {trust_before_drift:.3f} {chr(8594)} {trust_after_drift:.3f}")
    print(f"    Erosion amount: {_red(f'{erosion:+.3f}')}")
    print()

    alerts = runtime.get_drift_alerts("claims-bot")
    if alerts:
        for alert in alerts[-1:]:
            sev_color = _red if alert.severity in ("critical", "high") else _yellow
            print(f"  {sev_color(chr(9888))} DRIFT ALERT generated:")
            print(f"    Severity: {alert.severity.upper()}")
            if alert.drift_score.detail:
                print(f"    Message:  \"{alert.drift_score.detail}\"")
        print()

    print(f"  {_dim('What you learned: The system learns normal patterns,')}")
    print(f"  {_dim('then detects when behavior changes. Drift erodes trust')}")
    print(f"  {_dim('and changes governance outcomes automatically.')}")

    _pause()

    # ── Chapter 5: Interruption ─────────────────────────────────────

    _header("Chapter 5", 'Interruption \u2014 "Can we stop an agent mid-action?"')
    print("  Governance doesn't just decide before execution \u2014 it can stop an agent")
    print("  mid-action and roll back. Watch an interrupt happen.")
    print()

    print("  Agent claims-bot is processing a batch write...")
    print()

    rollback_log: list[str] = []

    def _rollback() -> None:
        for item in reversed(rollback_log):
            print(f"    Reverting {item}... done")
        rollback_log.clear()

    batch_action = GovAction(agent_id="claims-bot", action_type="write", target="claims_db")
    handle = runtime.begin_execution(batch_action, ctx1, rollback=_rollback)

    for record_num in range(1, 11):
        if handle.check_interrupt():
            print(f"\n  {_red(chr(9940))} EXECUTION HALTED after record {record_num - 1}")
            break

        rollback_log.append(f"record {record_num}")
        print(f"  {chr(9203)} Processing record {record_num} of 10... {_green(chr(10003))}")
        _time.sleep(0.15)

        if record_num == 3:
            print()
            print(f"  {_yellow(chr(9889))} INTERRUPT SIGNAL: Anomaly detected in write pattern")
            print()
            print("  Agent checks interrupt flag at next safe point...")
            print()

            runtime.interrupt_action(
                batch_action.id,
                reason="Anomaly detected in write pattern",
                source="drift_monitor",
            )

    if handle.is_interrupted:
        print()
        print(f"  {_bold(chr(8617))} ROLLBACK executing...")

        handle_rollback = handle.rollback
        if handle_rollback:
            handle_rollback()

        print()
        print(f"  {_green(chr(10003))} Rollback complete. System state restored.")
    else:
        runtime.complete_execution(batch_action.id, ctx1)
        print("\n  All records processed successfully.")

    print()
    print(f"  {_dim('What you learned: Governance has teeth.')}")
    print(f"  {_dim('The agent cooperated with the interrupt ' + emdash + ' it checked')}")
    print(f"  {_dim('for interrupts at each safe point and rolled back cleanly.')}")

    _pause()

    # ── Chapter 6: Audit Trail ──────────────────────────────────────

    _header("Chapter 6", 'Audit Trail \u2014 "What happened and why?"')
    print("  Every governance decision is recorded with full justification \u2014 not")
    print("  just what happened, but why.")
    print()

    if runtime.audit_trail is not None:
        _section("Recent audit records")

        records = runtime.audit_trail.query(agent_id="claims-bot", limit=5)
        if records:
            for i, r in enumerate(records):
                verdict_color = _green if r.verdict == "ALLOW" else (_red if r.verdict == "DENY" else _yellow)
                ts_str = datetime.fromtimestamp(r.timestamp, tz=timezone.utc).strftime("%H:%M:%S")
                print(f"  #{r.record_id}  {ts_str}  {verdict_color(f'GOVERNANCE.{r.verdict}')}")
                print(f"       Action: {r.action_type} {chr(8594)} {r.action_target}")
                print(f"       UCS: {r.ucs:.2f}  Tier: {r.tier}")
                print(f"       Trust: {r.trust_score:.3f} ({r.trust_trend})")
                if r.justification:
                    just = r.justification[:100]
                    if len(r.justification) > 100:
                        just += "..."
                    print(f"       Why: {just}")
                print()

        _section("Audit summary")

        summary = runtime.audit_trail.summary()
        total = summary.get("total_records", 0)
        print(f"  Total evaluations:  {total}")
        print()

        by_verdict = summary.get("by_verdict", {})
        if by_verdict:
            print("  By verdict:")
            for v, cnt in sorted(by_verdict.items()):
                pct = cnt / total * 100 if total else 0
                bar = format_pct_bar(cnt / total if total else 0, 40)
                vcolor = _green if v == "ALLOW" else (_red if v == "DENY" else _yellow)
                print(f"    {vcolor(f'{v:10s}')} {cnt:5d}  {bar}  {pct:.1f}%")
            print()

        by_severity = summary.get("by_severity", {})
        if by_severity:
            print("  By severity:")
            for s, cnt in sorted(by_severity.items()):
                pct = cnt / total * 100 if total else 0
                bar = format_pct_bar(cnt / total if total else 0, 40)
                print(f"    {s:10s} {cnt:5d}  {bar}  {pct:.1f}%")
            print()

        recent_alerts = summary.get("recent_alerts", [])
        if recent_alerts:
            print("  Recent alerts:")
            for a in recent_alerts[-3:]:
                sev = a.get("severity", "?")
                code = a.get("context_code", "?")
                sev_color = _red if sev in ("critical", "alert") else _yellow
                print(f"    [{sev_color(sev.upper())}] {code}")
            print()

    print(f"  {_dim('What you learned: Every decision is recorded with full')}")
    print(f"  {_dim('justification. The audit trail explains the why, not just the what.')}")

    _pause()

    # ── Chapter 7: Full picture ─────────────────────────────────────

    _header("Chapter 7", 'The Full Picture')

    final_trust = runtime.get_trust_profile("claims-bot").overall_trust
    report = runtime.get_trust_report("claims-bot")

    print(f"  {_bold('Governance Report for claims-bot')}")
    print()
    print(f"    Current Trust:     {final_trust:.3f}")
    print(f"    Total Actions:     {report.get('successful_actions', 0) + report.get('violation_count', 0)}")
    print(f"    Successful:        {report.get('successful_actions', 0)}")
    print(f"    Violations:        {report.get('violation_count', 0)}")
    print(f"    Violation Rate:    {report.get('violation_rate', 0):.1%}")
    print()

    fp_info = report.get("fingerprint")
    if fp_info:
        print(f"    Fingerprint:       {fp_info.get('total_observations', 0)} observations (confidence: {fp_info.get('confidence', 0):.2f})")

    drift_info = report.get("drift")
    if drift_info:
        sev = drift_info.get("severity", "none")
        color = _red if sev in ("high", "critical") else (_yellow if sev == "moderate" else _green)
        drift_val = drift_info.get("overall", 0)
        print(f"    Drift:             {color(f'{drift_val:.2f}')} ({sev})")

    alert_count = report.get("active_alerts", 0)
    if alert_count:
        print(f"    Active Alerts:     {_red(str(alert_count))}")
    print()

    traj = report.get("trajectory", {})
    sources = traj.get("sources", {})
    if sources:
        print(f"  {_bold('Trust by source:')}")
        for src, info in sorted(sources.items()):
            nd = info.get("net_delta", 0)
            cnt = info.get("count", 0)
            sign = "+" if nd >= 0 else ""
            color = _green if nd > 0 else (_red if nd < 0 else _yellow)
            print(f"    {src:25s} {color(f'{sign}{nd:.3f}')} ({cnt} events)")
        print()

    print(_bold(_cyan("=" * 60)))
    print(_bold(_cyan("  Tutorial complete.")))
    print(_bold(_cyan("=" * 60)))
    print()
    print("  You just saw the entire Nomotic governance lifecycle:")
    print("    1. Identity     \u2014 Cryptographic birth certificate")
    print("    2. Authority    \u2014 Scope, boundaries, and rules")
    print("    3. Evaluation   \u2014 13-dimension scoring with UCS")
    print("    4. Behavior     \u2014 Fingerprinting and drift detection")
    print("    5. Interruption \u2014 Mechanical halt with rollback")
    print("    6. Audit Trail  \u2014 Full accountability record")
    print("    7. Trust        \u2014 Continuous calibration from all sources")
    print()
    print("  Next steps:")
    print("    nomotic birth --agent-id my-agent --archetype customer-experience --org my-org")
    print("    nomotic scope set my-agent --actions read,write --boundaries my_db")
    print("    nomotic test my-agent --action read --target my_db")
    print("    nomotic simulate my-agent --scenario normal")
    print()


def _print_evaluation(
    verdict: "GovernanceVerdict",
    trust_before: float,
    trust_after: float,
) -> None:
    """Print a formatted governance evaluation result."""
    from nomotic.sandbox import format_bar
    from nomotic.types import Verdict

    print(f"  Trust:   {trust_before:.3f}")
    print()

    for ds in verdict.dimension_scores:
        bar = format_bar(ds.score, 20)
        name_padded = f"{ds.dimension_name:26s}"
        score_str = f"{ds.score:.2f}"

        if ds.veto and ds.score < 0.5:
            check = _red(f"{chr(10007)} VETO: {ds.reasoning}")
            color_score = _red(score_str)
        elif ds.score >= 0.7:
            check = _green(ds.reasoning)
            color_score = _green(score_str)
        elif ds.score >= 0.4:
            check = _yellow(ds.reasoning)
            color_score = _yellow(score_str)
        else:
            check = _red(ds.reasoning)
            color_score = _red(score_str)

        print(f"  {name_padded} {color_score}  {bar}  {check}")

    print()

    ucs_str = f"{verdict.ucs:.3f}"
    tier_labels = {1: "veto gate", 2: "threshold evaluation", 3: "deliberative review"}
    tier_label = tier_labels.get(verdict.tier, "unknown")

    if verdict.verdict == Verdict.ALLOW:
        verdict_display = _green(f"{chr(9989)} ALLOW")
    elif verdict.verdict == Verdict.DENY:
        verdict_display = _red(f"{chr(10060)} DENY")
    elif verdict.verdict == Verdict.ESCALATE:
        verdict_display = _yellow(f"{chr(9888)} ESCALATE")
    else:
        verdict_display = _yellow(f"{chr(9888)} {verdict.verdict.name}")

    print(f"  UCS:      {ucs_str}")
    print(f"  Tier:     {verdict.tier} ({tier_label})")
    print(f"  Verdict:  {verdict_display}")
    if verdict.vetoed_by:
        print(f"  Vetoed by: {', '.join(verdict.vetoed_by)}")
    if verdict.reasoning:
        print(f"  Reason:   {verdict.reasoning}")
    print(f"  Time:     {verdict.evaluation_time_ms:.1f}ms")

    # Trust update
    delta = trust_after - trust_before
    sign = "+" if delta >= 0 else ""
    delta_color = _green if delta > 0 else (_red if delta < 0 else _yellow)
    trend = "stable"
    if delta > 0.001:
        trend = f"{chr(8599)} rising"
    elif delta < -0.001:
        trend = f"{chr(8600)} falling"

    print()
    print(f"  Before:   {trust_before:.3f}")
    print(f"  After:    {trust_after:.3f}  ({delta_color(f'{sign}{delta:.3f}')})")
    print(f"  Trend:    {trend}")
    print()


def _cmd_audit_show(args: argparse.Namespace) -> None:
    """Show audit records from an in-memory simulation or local test sessions."""
    # This is a convenience alias that displays a help message
    # pointing users to the tutorial or test commands.
    print("The 'audit show' command works in two modes:")
    print()
    print("  1. After 'nomotic tutorial' — audit records are shown as part")
    print("     of the interactive walkthrough (Chapter 6).")
    print()
    print("  2. Against a running API server:")
    print("     nomotic audit query --agent-id <agent> --host 127.0.0.1 --port 8420")
    print("     nomotic audit summary --agent-id <agent> --host 127.0.0.1 --port 8420")
    print()
    print("  Run 'nomotic tutorial' for the full interactive experience.")


def _cmd_serve(args: argparse.Namespace) -> None:
    from nomotic.api import NomoticAPIServer

    ca, _store = _build_ca(args.base_dir)
    arch_reg, zone_val, org_reg = _build_registries(args.base_dir)

    prometheus = None
    if getattr(args, "metrics", False):
        from nomotic.otel_exporter import PrometheusMetrics

        prometheus = PrometheusMetrics()

    server = NomoticAPIServer(
        ca,
        archetype_registry=arch_reg,
        zone_validator=zone_val,
        org_registry=org_reg,
        base_dir=args.base_dir,
        prometheus=prometheus,
        host=args.host,
        port=args.port,
    )
    sk, vk, issuer_id = _load_or_create_issuer(args.base_dir)
    print(f"Nomotic API server starting on http://{args.host}:{args.port}")
    print(f"  Issuer: {issuer_id}")
    print(f"  Fingerprint: {vk.fingerprint()}")
    if prometheus is not None:
        print("  Metrics: http://{}:{}/metrics".format(args.host, args.port))
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nShutting down...")
        server.shutdown()


# ── MCP Proxy command ────────────────────────────────────────────────────


def _cmd_mcp_proxy(args: argparse.Namespace) -> None:
    from nomotic.mcp_proxy import MCPGovernanceProxy, MCPHTTPGovernanceProxy

    agent_id = args.agent_id
    upstream = args.upstream
    upstream_url = args.upstream_url

    if not upstream and not upstream_url:
        print("Error: Either --upstream (stdio) or --upstream-url (HTTP) is required.", file=sys.stderr)
        sys.exit(1)
    if upstream and upstream_url:
        print("Error: Specify either --upstream or --upstream-url, not both.", file=sys.stderr)
        sys.exit(1)

    require_certificate = getattr(args, "require_certificate", False)
    agent_id_map: dict[str, str] = {}
    if getattr(args, "agent_map", None):
        agent_id_map = json.loads(Path(args.agent_map).read_text())

    kw = {
        "test_mode": args.test_mode,
        "log_level": args.log_level,
        "base_dir": args.base_dir,
    }

    if upstream:
        proxy = MCPGovernanceProxy(
            agent_id=agent_id,
            upstream_command=upstream,
            require_certificate=require_certificate,
            **kw,
        )
        sys.stderr.write(
            f"[nomotic] MCP stdio proxy starting\n"
            f"[nomotic] Agent: {agent_id}\n"
            f"[nomotic] Upstream: {upstream}\n"
        )
        proxy.run()
    else:
        proxy = MCPHTTPGovernanceProxy(
            agent_id=agent_id,
            upstream_url=upstream_url,
            port=args.port,
            host=args.host,
            require_certificate=require_certificate,
            agent_id_map=agent_id_map,
            default_timeout=args.timeout,
            **kw,
        )
        proxy.run()


# ── HTTP Governance Proxy command ────────────────────────────────────────


def _cmd_proxy(args: argparse.Namespace) -> None:
    from nomotic.proxy import start_proxy

    require_certificate = getattr(args, "require_certificate", False)
    agent_id_map: dict[str, str] = {}
    if getattr(args, "agent_map", None):
        agent_id_map = json.loads(Path(args.agent_map).read_text())

    start_proxy(
        agent_id=args.agent_id,
        listen=args.listen,
        upstream=args.upstream,
        test_mode=args.test_mode,
        base_dir=str(args.base_dir),
        require_certificate=require_certificate,
        agent_id_map=agent_id_map,
        default_timeout=args.timeout,
    )


# ── SIEM export ─────────────────────────────────────────────────────────


def _cmd_siem_export(args: argparse.Namespace) -> None:
    """Export audit trail records in SIEM-ingestible formats."""
    from nomotic.audit_store import AuditStore
    from nomotic.siem import SIEMExporter

    identifier = getattr(args, "identifier", None)
    siem_all = getattr(args, "siem_all", False)

    if not identifier and not siem_all:
        print(
            "Specify an agent name/ID, or use --all for all agents.",
            file=sys.stderr,
        )
        print("  nomotic siem-export agent-1 --format jsonl", file=sys.stderr)
        print("  nomotic siem-export agent-1 --format cef --severity alert", file=sys.stderr)
        print("  nomotic siem-export --all --format syslog", file=sys.stderr)
        sys.exit(1)

    # Parse date filters
    since_ts: float | None = None
    until_ts: float | None = None
    if args.since:
        since_ts = datetime.fromisoformat(args.since).replace(
            tzinfo=timezone.utc
        ).timestamp()
    if args.until:
        until_ts = datetime.fromisoformat(args.until).replace(
            tzinfo=timezone.utc
        ).timestamp()

    exporter = SIEMExporter(
        format=args.siem_format,
        include_dimension_scores=getattr(args, "include_dimensions", False),
    )

    audit_store = AuditStore(args.base_dir)

    # Gather agent names to export
    agent_names: list[str] = []
    if siem_all:
        agent_names = audit_store.list_agents()
        if not agent_names:
            print("  No audit records found.", file=sys.stderr)
            return
    else:
        # Try to resolve identifier
        try:
            _numeric_id, resolved_name, _cert_id = _resolve_agent(
                args.base_dir, identifier  # type: ignore[arg-type]
            )
            agent_names = [resolved_name]
        except SystemExit:
            agent_names = [identifier]  # type: ignore[list-item]

    # Collect and format records
    output_file = None
    if args.output:
        output_file = open(args.output, "w")  # noqa: SIM115

    try:
        for name in agent_names:
            records = audit_store.query(
                name,
                severity=args.severity,
            )
            if not records:
                continue

            # Build a lightweight in-memory AuditTrail for the exporter
            from nomotic.audit import AuditRecord, AuditTrail

            trail = AuditTrail()
            for r in records:
                # Convert PersistentAuditRecord -> AuditRecord
                rec = AuditRecord(
                    record_id=r.record_id,
                    timestamp=r.timestamp,
                    context_code=r.context_code,
                    severity=r.severity,
                    agent_id=r.agent_id,
                    owner_id=getattr(r, "owner_id", ""),
                    user_id=getattr(r, "user_id", ""),
                    action_id=getattr(r, "action_id", ""),
                    action_type=getattr(r, "action_type", ""),
                    action_target=getattr(r, "action_target", ""),
                    verdict=r.verdict,
                    ucs=r.ucs,
                    tier=r.tier,
                    trust_score=getattr(r, "trust_score", 0.5),
                    trust_trend=getattr(r, "trust_trend", "stable"),
                    drift_overall=getattr(r, "drift_overall", None),
                    drift_severity=getattr(r, "drift_severity", None),
                    justification=getattr(r, "justification", ""),
                    previous_hash=getattr(r, "previous_hash", ""),
                    record_hash=getattr(r, "record_hash", ""),
                )
                # Apply date filtering
                if since_ts is not None and rec.timestamp < since_ts:
                    continue
                if until_ts is not None and rec.timestamp > until_ts:
                    continue

                trail.append(rec)

            # Apply verdict filter via query
            query_kwargs: dict[str, Any] = {"limit": 100000}
            if args.verdict:
                query_kwargs["verdict"] = args.verdict

            output = exporter.export_trail(trail, **query_kwargs)
            if output:
                dest = output_file or sys.stdout
                print(output, file=dest)

    finally:
        if output_file is not None:
            output_file.close()


# ── Evidence bundle commands ─────────────────────────────────────────────


def _cmd_evidence(args: argparse.Namespace) -> None:
    """Generate, verify, or summarize compliance evidence bundles."""
    subcmd = getattr(args, "evidence_command", None)
    if subcmd is None:
        print("Usage: nomotic evidence {generate,verify,summary}")
        print()
        print("  generate  Generate a compliance evidence bundle")
        print("  verify    Verify a bundle file's integrity")
        print("  summary   Show a summary of a bundle file")
        return

    if subcmd == "generate":
        _cmd_evidence_generate(args)
    elif subcmd == "verify":
        _cmd_evidence_verify(args)
    elif subcmd == "summary":
        _cmd_evidence_summary(args)


def _cmd_evidence_generate(args: argparse.Namespace) -> None:
    """Generate a compliance evidence bundle from persisted audit records."""
    from nomotic.audit import AuditRecord, AuditTrail
    from nomotic.audit_store import AuditStore
    from nomotic.evidence import EvidenceBundleGenerator

    identifier = getattr(args, "identifier", None)

    # Parse frameworks
    frameworks: list[str] | None = None
    if args.frameworks:
        frameworks = [f.strip() for f in args.frameworks.split(",")]

    # Parse date filters
    since_ts: float | None = None
    until_ts: float | None = None
    if args.since:
        since_ts = datetime.fromisoformat(args.since).replace(
            tzinfo=timezone.utc
        ).timestamp()
    if getattr(args, "until", None):
        until_ts = datetime.fromisoformat(args.until).replace(
            tzinfo=timezone.utc
        ).timestamp()

    # Resolve agent name
    agent_name: str | None = None
    if identifier:
        try:
            _numeric_id, resolved_name, _cert_id = _resolve_agent(
                args.base_dir, identifier
            )
            agent_name = resolved_name
        except SystemExit:
            agent_name = identifier

    # Load audit records from the persistent store
    audit_store = AuditStore(args.base_dir)
    trail = AuditTrail()

    agent_names: list[str] = []
    if agent_name:
        agent_names = [agent_name]
    else:
        agent_names = audit_store.list_agents()

    for name in agent_names:
        records = audit_store.query(name)
        for r in records:
            rec = AuditRecord(
                record_id=r.record_id,
                timestamp=r.timestamp,
                context_code=r.context_code,
                severity=r.severity,
                agent_id=r.agent_id,
                owner_id=getattr(r, "owner_id", ""),
                user_id=getattr(r, "user_id", ""),
                action_id=getattr(r, "action_id", ""),
                action_type=getattr(r, "action_type", ""),
                action_target=getattr(r, "action_target", ""),
                verdict=r.verdict,
                ucs=r.ucs,
                tier=r.tier,
                trust_score=getattr(r, "trust_score", 0.5),
                trust_trend=getattr(r, "trust_trend", "stable"),
                drift_overall=getattr(r, "drift_overall", None),
                drift_severity=getattr(r, "drift_severity", None),
                justification=getattr(r, "justification", ""),
                previous_hash=getattr(r, "previous_hash", ""),
                record_hash=getattr(r, "record_hash", ""),
            )
            trail.append(rec)

    generator = EvidenceBundleGenerator(audit_trail=trail)
    bundle = generator.generate(
        agent_id=agent_name,
        since=since_ts,
        until=until_ts,
        frameworks=frameworks,
        created_by=getattr(args, "created_by", "nomotic-cli"),
    )

    output_json = generator.to_json(bundle)

    if args.output:
        with open(args.output, "w") as f:
            f.write(output_json)
        print(f"Evidence bundle written to {args.output}")
        print(f"  Bundle ID:  {bundle.bundle_id}")
        print(f"  Records:    {bundle.record_count}")
        print(f"  Frameworks: {', '.join(bundle.frameworks)}")
        print(f"  Chain OK:   {bundle.chain_verification.get('valid', False)}")
    else:
        print(output_json)


def _cmd_evidence_verify(args: argparse.Namespace) -> None:
    """Verify a bundle file's integrity."""
    from nomotic.evidence import EvidenceBundleGenerator

    bundle_path = args.bundle_file
    try:
        with open(bundle_path) as f:
            bundle_data = json.load(f)
    except (FileNotFoundError, json.JSONDecodeError) as exc:
        print(f"Error reading bundle: {exc}", file=sys.stderr)
        sys.exit(1)

    generator = EvidenceBundleGenerator()
    valid, message = generator.verify_bundle(bundle_data)

    if valid:
        print(_green("PASS") + f"  {message}")
    else:
        print(_red("FAIL") + f"  {message}")
        sys.exit(1)


def _cmd_evidence_summary(args: argparse.Namespace) -> None:
    """Show a summary of a bundle file."""
    bundle_path = args.bundle_file
    try:
        with open(bundle_path) as f:
            bundle_data = json.load(f)
    except (FileNotFoundError, json.JSONDecodeError) as exc:
        print(f"Error reading bundle: {exc}", file=sys.stderr)
        sys.exit(1)

    bid = bundle_data.get("bundle_id", "?")
    created = bundle_data.get("created_at", "?")
    created_by = bundle_data.get("created_by", "?")
    agent = bundle_data.get("agent_id") or "(all agents)"
    frameworks = bundle_data.get("frameworks", [])
    record_count = bundle_data.get("record_count", 0)
    chain = bundle_data.get("chain_verification", {})
    chain_ok = chain.get("valid", False)
    time_range = bundle_data.get("time_range", [0.0, 0.0])

    # Format time range
    if time_range[0] > 0:
        start_str = datetime.fromtimestamp(
            time_range[0], tz=timezone.utc
        ).strftime("%Y-%m-%d %H:%M UTC")
    else:
        start_str = "(beginning)"
    end_str = datetime.fromtimestamp(
        time_range[1], tz=timezone.utc
    ).strftime("%Y-%m-%d %H:%M UTC")

    print(f"  {_bold('Evidence Bundle Summary')}")
    print(f"  {'─' * 40}")
    print(f"  Bundle ID:   {bid}")
    print(f"  Created:     {created}")
    print(f"  Created by:  {created_by}")
    print(f"  Agent:       {agent}")
    print(f"  Time range:  {start_str} → {end_str}")
    print(f"  Frameworks:  {', '.join(frameworks)}")
    print(f"  Records:     {record_count}")
    chain_label = _green("valid") if chain_ok else _red("INVALID")
    print(f"  Chain:       {chain_label}")
    print(f"  Controls:    {len(bundle_data.get('compliance_evidence', []))}")

    # Verdict breakdown
    verdicts: dict[str, int] = {}
    for rec in bundle_data.get("audit_records", []):
        v = rec.get("verdict", "?")
        verdicts[v] = verdicts.get(v, 0) + 1
    if verdicts:
        print(f"  Verdicts:    {', '.join(f'{k}: {v}' for k, v in sorted(verdicts.items()))}")


# ── Compliance Report command ────────────────────────────────────────────


def _cmd_compliance_report(args: argparse.Namespace) -> None:
    """Generate a compliance mapping report."""
    from nomotic.compliance_report import (
        ComplianceReportGenerator,
        format_json,
        format_markdown,
    )

    framework = args.framework
    agent_name: str | None = None
    if args.agent:
        try:
            _numeric_id, resolved_name, _cert_id = _resolve_agent(
                args.base_dir, args.agent
            )
            agent_name = resolved_name
        except SystemExit:
            agent_name = args.agent

    generator = ComplianceReportGenerator(base_dir=args.base_dir)
    try:
        report = generator.generate(
            framework=framework,
            agent_id=agent_name,
            include_layer_map=getattr(args, "include_layer_map", False),
        )
    except ValueError as exc:
        print(_red(f"Error: {exc}"), file=sys.stderr)
        sys.exit(1)

    output_path: str | None = args.output
    if output_path is not None:
        if output_path.endswith(".json"):
            content = json.dumps(format_json(report), indent=2)
        else:
            content = format_markdown(report)
        with open(output_path, "w", encoding="utf-8") as f:
            f.write(content)
        print(f"Compliance report written to {output_path}")
        print(f"  Framework:  {report.framework_name}")
        print(f"  Controls:   {report.summary.total_controls}")
        print(f"  Coverage:   {report.summary.coverage_percentage:.0f}%")
    else:
        # Print markdown to stdout
        print(format_markdown(report))


# ── Validate command ─────────────────────────────────────────────────────


def _cmd_validate(args: argparse.Namespace) -> None:
    """Validate a nomotic.yaml governance config file."""
    from nomotic.config_loader import (
        load_governance_config_from_string,
        validate_governance_config,
    )
    from nomotic.org_governance import enforce_org_policy, load_org_config
    from nomotic.presets import DIMENSION_NAMES, TRUST_SETTING_KEYS, get_preset, get_preset_names

    target_path = Path(args.path)
    use_json = getattr(args, "json", False)
    quiet = getattr(args, "quiet", False)
    strict = getattr(args, "strict", False)
    preset_override = getattr(args, "preset", None)
    org_path = getattr(args, "org", None)

    errors: list[dict[str, str]] = []
    warnings: list[dict[str, str]] = []
    info: list[dict[str, str]] = []
    presets_applied: list[str] = []
    org_compliant: bool | None = None
    simulation_passed: bool | None = None
    config_file = ""

    # When --json is used, suppress all text output; collect data only.
    text_output = not use_json

    def _add_error(check: str, message: str, location: str = "") -> None:
        errors.append({"check": check, "message": message, "location": location})

    def _add_warning(check: str, message: str, location: str = "") -> None:
        warnings.append({"check": check, "message": message, "location": location})

    def _add_info(check: str, message: str) -> None:
        info.append({"check": check, "message": message})

    def _print_ok(msg: str) -> None:
        if text_output and not quiet:
            print(f"  {_green('✓')} {msg}")

    def _print_warn(msg: str) -> None:
        if text_output:
            print(f"  {_yellow('⚠')} {msg}")

    def _print_err(msg: str) -> None:
        if text_output:
            print(f"  {_red('✗')} {msg}")

    def _print_info(msg: str) -> None:
        if text_output and not quiet:
            print(f"  {_cyan('ℹ')} {msg}")

    # ── 1. File discovery ────────────────────────────────────────
    try:
        from nomotic.config_loader import _find_config_file

        resolved = _find_config_file(target_path)
        config_file = str(resolved)
    except FileNotFoundError as exc:
        if use_json:
            result = {
                "status": "error",
                "file": str(target_path),
                "errors": [{"check": "file_discovery", "message": str(exc)}],
                "warnings": [],
                "info": [],
                "presets_applied": [],
                "org_compliant": None,
                "simulation_passed": None,
            }
            print(json.dumps(result, indent=2))
        else:
            print(f"\n  {_bold('Nomotic Validate')}: {target_path}")
            print(f"  {'━' * 31}\n")
            _print_err(f"File not found: {exc}")
            print(f"\n  Result: {_red('ERROR')}\n")
        sys.exit(2)

    if text_output and not quiet:
        print(f"\n  {_bold('Nomotic Validate')}: {Path(config_file).name}")
        print(f"  {'━' * 31}\n")

    # ── 2. YAML parse ────────────────────────────────────────────
    try:
        yaml_string = Path(config_file).read_text(encoding="utf-8")
    except OSError as exc:
        _add_error("yaml_parse", f"Cannot read file: {exc}")
        if use_json:
            result = {
                "status": "error",
                "file": config_file,
                "errors": errors,
                "warnings": warnings,
                "info": info,
                "presets_applied": [],
                "org_compliant": None,
                "simulation_passed": None,
            }
            print(json.dumps(result, indent=2))
        else:
            _print_err(f"Cannot read file: {exc}")
            print(f"\n  Result: {_red('ERROR')}\n")
        sys.exit(2)

    try:
        config = load_governance_config_from_string(yaml_string, source_path=config_file)
    except ValueError as exc:
        msg = str(exc)
        _add_error("yaml_parse", msg)
        if use_json:
            result = {
                "status": "error",
                "file": config_file,
                "errors": errors,
                "warnings": warnings,
                "info": info,
                "presets_applied": [],
                "org_compliant": None,
                "simulation_passed": None,
            }
            print(json.dumps(result, indent=2))
        else:
            _print_err(f"YAML parse error: {msg}")
            print(f"\n  Result: {_red('ERROR')}\n")
        sys.exit(2)

    _print_ok("YAML syntax valid")

    # ── Apply --preset override if given ─────────────────────────
    if preset_override:
        canonical_names = get_preset_names()
        lower_map = {n.lower(): n for n in canonical_names}
        key = preset_override.lower()
        if key not in lower_map:
            from difflib import get_close_matches

            close = get_close_matches(key, [n.lower() for n in canonical_names], n=1, cutoff=0.4)
            if close:
                suggestion = lower_map[close[0]]
                _add_error(
                    "preset_override",
                    f"Unknown preset '{preset_override}'. Did you mean '{suggestion}'? "
                    f"Available presets: {', '.join(canonical_names)}",
                )
            else:
                _add_error(
                    "preset_override",
                    f"Unknown preset '{preset_override}'. "
                    f"Available presets: {', '.join(canonical_names)}",
                )
        else:
            # Apply the preset as if extends included it
            if lower_map[key] not in config.extends:
                config.extends.insert(0, lower_map[key])
            # Re-parse with the new extends
            yaml_with_preset = config.raw.copy()
            yaml_with_preset["extends"] = list(config.extends)
            try:
                import yaml as _yaml

                new_yaml = _yaml.dump(yaml_with_preset, default_flow_style=False)
                config = load_governance_config_from_string(new_yaml, source_path=config_file)
            except Exception:
                # Fallback: just keep the modified config
                pass

    # ── 3. Schema validation ─────────────────────────────────────
    schema_errors = validate_governance_config(config)
    if schema_errors:
        for err in schema_errors:
            _add_error("schema", err)
    else:
        agent_count = len(config.agents)
        _print_ok(f"Schema validated (version {config.version}, {agent_count} agent{'s' if agent_count != 1 else ''})")

    # ── 4. Preset resolution ─────────────────────────────────────
    presets_applied = list(config.extends)
    if config.extends:
        all_valid = True
        for name in config.extends:
            try:
                get_preset(name)
            except KeyError:
                all_valid = False
        if all_valid:
            _print_ok(f"Preset resolved: {', '.join(config.extends)}")
    else:
        _print_ok("No presets (using defaults)")

    # ── Compliance preset disclaimer ─────────────────────────────
    for name in config.extends:
        try:
            preset = get_preset(name)
            if preset.framework_reference:
                framework = preset.framework_reference
                disclaimer_msg = (
                    f"{name} is Nomotic's interpretation aligned to "
                    f"{framework} concerns. It does not constitute "
                    f"{framework} compliance."
                )
                _add_info("preset_disclaimer", disclaimer_msg)
                _print_info(disclaimer_msg)
        except KeyError:
            pass

    # ── 5. Dimension validation ──────────────────────────────────
    valid_dims = set(DIMENSION_NAMES)
    configured_dims = set(config.dimension_weights.keys()) & valid_dims
    _print_ok(f"All {len(configured_dims)} dimensions configured")

    # ── 6. Threshold logic ───────────────────────────────────────
    if config.allow_threshold > config.deny_threshold:
        _print_ok(
            f"Thresholds consistent (allow: {config.allow_threshold:.2f}, "
            f"deny: {config.deny_threshold:.2f})"
        )

    # ── 7. Trust settings ────────────────────────────────────────
    missing_trust = TRUST_SETTING_KEYS - set(config.trust_settings)
    if not missing_trust:
        _print_ok("Trust settings valid")

    # ── 8. Agent scope validation ────────────────────────────────
    all_scopes_valid = True
    for agent in config.agents:
        if not agent.actions:
            all_scopes_valid = False
    if all_scopes_valid and config.agents:
        _print_ok("Agent scopes valid")

    # ── 9. Logical checks ───────────────────────────────────────
    if text_output and not quiet:
        print()

    # 9a. Veto-weight contradictions
    veto_set = set(config.veto_dimensions)
    for dim_name in veto_set:
        weight = config.dimension_weights.get(dim_name, 1.0)
        if weight == 0.0:
            _add_warning(
                "veto_weight_contradiction",
                f"Dimension '{dim_name}' has veto authority but weight 0.0",
                f"dimensions.vetoes.{dim_name}",
            )

    # 9b. Missing vetoes on high-weight critical dimensions
    critical_dims = {"scope_compliance", "authority_verification"}
    for dim_name in critical_dims:
        weight = config.dimension_weights.get(dim_name, 1.0)
        if weight > 1.5 and dim_name not in veto_set:
            _add_warning(
                "missing_veto",
                f"Dimension '{dim_name}' has weight {weight} but no veto authority",
                f"dimensions.weights.{dim_name}",
            )

    # 9c. Overprivileged agents
    for agent in config.agents:
        if len(agent.actions) > 5:
            _add_warning(
                "agent_scope",
                f"Agent '{agent.agent_id}' has {len(agent.actions)} action types — consider narrowing scope",
                f"agents.{agent.agent_id}.scope.actions",
            )
        if len(agent.targets) > 10:
            _add_warning(
                "agent_scope",
                f"Agent '{agent.agent_id}' has {len(agent.targets)} targets — consider narrowing scope",
                f"agents.{agent.agent_id}.scope.targets",
            )

    # 9d. Trust floor above agent minimums
    trust_floor = config.trust_settings.get("floor", 0.0)
    for agent in config.agents:
        if trust_floor > agent.min_trust_for_action:
            _add_warning(
                "trust_floor",
                f"Trust floor ({trust_floor}) is above agent '{agent.agent_id}' "
                f"min_trust_for_action ({agent.min_trust_for_action})",
                f"agents.{agent.agent_id}.trust.min_trust_for_action",
            )

    # Print warnings
    for w in warnings:
        _print_warn(w["message"])

    if text_output and not quiet and warnings:
        print()

    # ── 10. Org policy enforcement ───────────────────────────────
    org_config = None
    try:
        org_config = load_org_config(path=org_path)
    except FileNotFoundError as exc:
        _add_error("org_policy", f"Org config not found: {exc}")
    except (ValueError, ImportError) as exc:
        _add_error("org_policy", str(exc))

    if org_config is not None:
        violations = enforce_org_policy(config, org_config)
        if violations:
            org_compliant = False
            for v in violations:
                _add_error(
                    "org_policy",
                    f"{v.field}: {v.requirement} — {v.actual}",
                    v.field,
                )
            _print_err(f"Org policy: {len(violations)} violation(s) ({org_config.org_name})")
        else:
            org_compliant = True
            _print_ok(f"Org policy: compliant ({org_config.org_name})")
    elif org_path:
        # User explicitly asked for org check but it failed
        pass
    else:
        # No org config found — that's fine, it's optional
        _print_info("No org policy found (skipped)")

    # ── 11. Simulation check ─────────────────────────────────────
    if not errors and config.agents:
        try:
            from nomotic.runtime import GovernanceRuntime
            from nomotic.types import Action, AgentContext, TrustProfile, Verdict

            runtime_config = config.to_runtime_config()
            runtime = GovernanceRuntime(runtime_config)

            # Use the first agent for simulation
            first_agent = config.agents[0]
            agent_id = first_agent.agent_id

            # Configure scope for the agent via the runtime
            runtime.configure_scope(
                agent_id, set(first_agent.actions),
                actor="validate", reason="Validation simulation",
            )

            # Configure boundaries if agent has targets
            if first_agent.targets:
                runtime.configure_boundaries(
                    agent_id, set(first_agent.targets),
                    actor="validate", reason="Validation simulation",
                )

            trust = TrustProfile(agent_id=agent_id, overall_trust=first_agent.initial_trust)
            ctx = AgentContext(agent_id=agent_id, trust_profile=trust)

            # Test 1: in-scope action
            in_scope_action = Action(
                agent_id=agent_id,
                action_type=first_agent.actions[0],
                target=first_agent.targets[0] if first_agent.targets else "test-target",
            )
            runtime.evaluate(in_scope_action, ctx)

            # Test 2: out-of-scope action should be denied
            out_scope_action = Action(
                agent_id=agent_id,
                action_type="__nomotic_validate_out_of_scope__",
                target="__nomotic_validate_forbidden__",
            )
            # Refresh trust profile for second evaluation
            trust2 = TrustProfile(agent_id=agent_id, overall_trust=first_agent.initial_trust)
            ctx2 = AgentContext(agent_id=agent_id, trust_profile=trust2)
            out_verdict = runtime.evaluate(out_scope_action, ctx2)

            if out_verdict.verdict == Verdict.DENY:
                simulation_passed = True
                _print_ok("Simulation: out-of-scope actions correctly denied")
            else:
                simulation_passed = False
                _add_error(
                    "simulation",
                    "Out-of-scope action was not denied — governance may be too permissive",
                )

        except Exception as exc:
            simulation_passed = False
            _add_error("simulation", f"Simulation failed: {exc}")

    # ── Final result ─────────────────────────────────────────────
    if errors:
        status = "fail"
        exit_code = 1
    elif strict and warnings:
        status = "fail"
        exit_code = 1
    else:
        status = "pass"
        exit_code = 0

    if use_json:
        result = {
            "status": status,
            "file": config_file,
            "errors": errors,
            "warnings": warnings,
            "info": info,
            "presets_applied": presets_applied,
            "org_compliant": org_compliant,
            "simulation_passed": simulation_passed,
        }
        print(json.dumps(result, indent=2))
    else:
        # Print errors not already shown inline
        for e in errors:
            _print_err(e["message"])

        # Summary
        parts = []
        if warnings:
            parts.append(f"{len(warnings)} warning{'s' if len(warnings) != 1 else ''}")
        if errors:
            parts.append(f"{len(errors)} error{'s' if len(errors) != 1 else ''}")
        detail = f" ({', '.join(parts)})" if parts else ""

        print()
        if status == "pass":
            print(f"  Result: {_green('PASS')}{detail}\n")
        else:
            print(f"  Result: {_red('FAIL')}{detail}\n")

    sys.exit(exit_code)


# ── New command ──────────────────────────────────────────────────────────


def _cmd_new(args: argparse.Namespace) -> None:
    """Generate a new nomotic.yaml governance config for this project."""
    from nomotic.presets import (
        get_preset,
        get_preset_names,
    )

    target_dir = Path(args.path).resolve()
    if not target_dir.is_dir():
        print(f"Directory not found: {args.path}", file=sys.stderr)
        sys.exit(1)

    yaml_path = target_dir / "nomotic.yaml"

    # Check if file exists (unless --force)
    if yaml_path.exists() and not args.force:
        print()
        print(f"  {_yellow('⚠')} nomotic.yaml already exists in this directory.")
        try:
            answer = input("  Overwrite? [y/N]: ").strip().lower()
        except (EOFError, KeyboardInterrupt):
            print()
            sys.exit(1)
        if answer != "y":
            print("  Aborted.")
            sys.exit(0)

    # Load defaults from setup config
    setup_config = _load_nomotic_config(args.base_dir)
    default_owner = setup_config.get("owner", "")
    default_preset_name = setup_config.get("default_preset", "standard")
    # If compliance_presets exist, use first as default
    compliance_presets_cfg = setup_config.get("compliance_presets", [])
    if compliance_presets_cfg:
        default_preset_name = compliance_presets_cfg[0]

    default_name = target_dir.name

    # Resolve all values (interactive or from flags)
    all_preset_names = get_preset_names()

    # Agent name
    agent_name = args.name
    if agent_name is None:
        print()
        print(f"  {_bold('Nomotic New Project')}")
        print(f"  {'━' * 19}")
        print()
        try:
            agent_name = input(f"  Agent name [{default_name}]: ").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            sys.exit(1)
        if not agent_name:
            agent_name = default_name
    else:
        print()
        print(f"  {_bold('Nomotic New Project')}")
        print(f"  {'━' * 19}")
        print()

    # Actions
    actions_str = args.actions
    if actions_str is None:
        try:
            actions_str = input("  What can this agent do?\n  Actions (comma-separated) [read, query]: ").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            sys.exit(1)
        if not actions_str:
            actions_str = "read, query"
    actions = [a.strip() for a in actions_str.split(",") if a.strip()]

    # Targets
    targets_str = args.targets
    if targets_str is None:
        try:
            targets_str = input("\n  What resources does it access?\n  Targets (comma-separated): ").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            sys.exit(1)
    targets = [t.strip() for t in targets_str.split(",") if t.strip()] if targets_str else []

    # Preset selection
    preset_name = args.preset
    if preset_name is None:
        severity = list_severity_presets()
        compliance = list_compliance_presets()

        print()
        print("  Governance preset:")
        idx = 1
        preset_menu: list[str] = []
        for p in severity:
            desc = p.description.split(".")[0].strip().lower() if p.description else ""
            print(f"    [{idx}] {p.name} — {desc}")
            preset_menu.append(p.name)
            idx += 1
        for p in compliance:
            desc = p.description.split(".")[0].strip().lower() if p.description else ""
            print(f"    [{idx}] {p.name} — {desc}")
            preset_menu.append(p.name)
            idx += 1

        # Determine default selection number
        default_num = 1
        for i, name in enumerate(preset_menu):
            if name == default_preset_name:
                default_num = i + 1
                break

        print()
        try:
            sel_str = input(f"  Selection [{default_num}]: ").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            sys.exit(1)
        if not sel_str:
            sel_num = default_num
        else:
            try:
                sel_num = int(sel_str)
            except ValueError:
                print(f"  Invalid selection: {sel_str}", file=sys.stderr)
                sys.exit(1)
        if sel_num < 1 or sel_num > len(preset_menu):
            print(f"  Invalid selection: {sel_num}", file=sys.stderr)
            sys.exit(1)
        preset_name = preset_menu[sel_num - 1]
    else:
        # Validate the preset name
        lower_name = preset_name.lower()
        if lower_name not in [n.lower() for n in all_preset_names]:
            # Try to suggest
            suggestion = None
            for n in all_preset_names:
                if lower_name in n or n in lower_name:
                    suggestion = n
                    break
            msg = f"Unknown preset '{preset_name}'."
            if suggestion:
                msg += f" Did you mean '{suggestion}'?"
            available = ", ".join(all_preset_names)
            print(f"\n  {_red(msg)}", file=sys.stderr)
            print(f"  Available presets: {available}\n", file=sys.stderr)
            sys.exit(1)
        # Normalize to canonical name
        for n in all_preset_names:
            if n.lower() == lower_name:
                preset_name = n
                break

    # Owner
    owner = args.owner
    if owner is None:
        default_display = default_owner if default_owner else ""
        prompt_suffix = f" [{default_display}]" if default_display else ""
        print()
        try:
            owner = input(f"  Owner{prompt_suffix}: ").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            sys.exit(1)
        if not owner:
            owner = default_owner

    # Reason
    reason = args.reason
    if reason is None:
        print()
        try:
            reason = input("  Why does this agent exist?\n  Reason: ").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            sys.exit(1)

    # Show compliance disclaimer if applicable
    try:
        preset_obj = get_preset(preset_name)
        if preset_obj.disclaimer:
            fw = preset_obj.framework_reference or preset_obj.display_name
            print()
            print(f"  {_yellow('ℹ')} Using {preset_name} preset. This is Nomotic's interpretation aligned to")
            print(f"    {fw} concerns. It does not constitute {fw} compliance.")
    except KeyError:
        pass

    # Generate YAML content
    boundaries = targets  # boundaries = targets by default

    # Build actions YAML list
    actions_yaml = "[" + ", ".join(actions) + "]"
    targets_yaml = "[" + ", ".join(targets) + "]" if targets else "[]"
    boundaries_yaml = "[" + ", ".join(boundaries) + "]" if boundaries else "[]"

    lines = []
    lines.append('version: "1.0"')
    lines.append("")
    lines.append(f'extends: "{preset_name}"')
    lines.append("")
    lines.append("agents:")
    lines.append(f"  {agent_name}:")
    lines.append("    scope:")
    lines.append(f"      actions: {actions_yaml}")
    lines.append(f"      targets: {targets_yaml}")
    lines.append(f"      boundaries: {boundaries_yaml}")
    lines.append("    trust:")
    lines.append("      initial: 0.5")
    lines.append("      minimum_for_action: 0.3")
    if owner:
        lines.append(f'    owner: "{owner}"')
    if reason:
        lines.append(f'    reason: "{reason}"')

    if args.full:
        lines.append("")
        lines.append("# ─── Optional overrides ───────────────────────────────────────")
        lines.append("# Uncomment and modify to override preset values.")
        lines.append("#")
        lines.append("# dimensions:")
        lines.append("#   weights:")
        lines.append("#     scope_compliance: 2.0")
        lines.append("#     authority_verification: 1.5")
        lines.append("#   vetoes:")
        lines.append("#     - scope_compliance")
        lines.append("#     - authority_verification")
        lines.append("#")
        lines.append("# thresholds:")
        lines.append("#   allow: 0.80")
        lines.append("#   deny: 0.30")
        lines.append("#")
        lines.append("# trust:")
        lines.append("#   success_increment: 0.01")
        lines.append("#   violation_decrement: 0.05")
        lines.append("#   interrupt_cost: 0.03")
        lines.append("#   decay_rate: 0.001")
        lines.append("#   floor: 0.05")
        lines.append("#   ceiling: 0.95")
        lines.append("#")
        lines.append("# compliance:")
        lines.append("#   frameworks: []")

    lines.append("")  # trailing newline

    yaml_content = "\n".join(lines)

    # Write the file
    yaml_path.write_text(yaml_content, encoding="utf-8")
    print()
    print(f"  {_green('✓')} Created nomotic.yaml")

    # Auto-validate unless --no-validate
    if not args.no_validate:
        try:
            from nomotic.config_loader import (
                load_governance_config_from_string,
                validate_governance_config,
            )

            config = load_governance_config_from_string(yaml_content, source_path=str(yaml_path))
            errors = validate_governance_config(config)
            if errors:
                print(f"  {_red('✗')} Validation failed:")
                for err in errors:
                    print(f"    - {err}")
            else:
                print(f"  {_green('✓')} Validation passed")
        except Exception as exc:
            print(f"  {_yellow('⚠')} Validation error: {exc}")

    print()
    print("  Next: nomotic validate nomotic.yaml")
    print()


# ── Settings command ─────────────────────────────────────────────────────


def _cmd_status_global(args: argparse.Namespace) -> None:
    """Show the current effective governance configuration."""
    from nomotic.presets import (
        get_preset,
        get_preset_names,
    )

    show_org = getattr(args, "org_only", False)
    show_presets_list = getattr(args, "presets_list", False)
    preset_name = getattr(args, "preset_detail", None)
    show_policies = getattr(args, "policies_list", False)

    # ── Active policies ─────────────────────────────────────────────
    if show_policies:
        from nomotic.policy import PolicyEngine

        engine = PolicyEngine()
        policies = engine.list_policies()
        print()
        print(f"  {_bold('Active Policies')}")
        print(f"  {'━' * 15}")
        print()
        if not policies:
            print("  No policies loaded.")
            print()
            print("  Policy directories searched:")
            print("    ./nomotic-policies/")
            print(f"    {Path.home() / '.nomotic' / 'policies'}/")
            print()
            print("  Install PyYAML for policy-as-code support: pip install pyyaml")
        else:
            for p in policies:
                status_icon = _green("\u2713") if p.enabled else _yellow("\u25cb")
                verdict = p.then.get("verdict", "?")
                print(f"    {status_icon} {_bold(p.name)} \u2192 {verdict} (priority={p.priority})")
                if p.description:
                    print(f"      {p.description}")
            print()
            issues = engine.validate_all()
            if issues:
                warn_icon = _yellow("\u26a0")
                print(f"  {warn_icon} {len(issues)} validation issue(s) found. Run 'nomotic policy-validate' for details.")
            else:
                ok_icon = _green("\u2713")
                print(f"  {ok_icon} All policies valid.")
        print()
        return

    # ── Single preset detail ────────────────────────────────────────
    if preset_name is not None:
        _settings_show_preset(preset_name, get_preset, get_preset_names)
        return

    # ── List all presets ────────────────────────────────────────────
    if show_presets_list:
        _settings_list_presets(list_compliance_presets, list_severity_presets, PRESET_DISCLAIMER)
        return

    # ── Org-only view ───────────────────────────────────────────────
    if show_org:
        print()
        _settings_show_org(args.base_dir)
        print()
        return

    # ── Full settings view ──────────────────────────────────────────
    _settings_show_full(
        args.base_dir,
        list_compliance_presets,
        list_severity_presets,
    )


def _settings_show_preset(
    preset_name: str,
    get_preset_fn,
    get_preset_names_fn,
) -> None:
    """Display full details of a single preset."""
    all_names = get_preset_names_fn()
    try:
        preset = get_preset_fn(preset_name)
    except KeyError:
        # Try to find a close match
        lower = preset_name.lower()
        suggestion = None
        for n in all_names:
            if lower in n or n in lower:
                suggestion = n
                break
        msg = f"Unknown preset '{preset_name}'."
        if suggestion:
            msg += f" Did you mean '{suggestion}'?"
        available = ", ".join(all_names)
        print(f"\n  {_red(msg)}")
        print(f"  Available presets: {available}\n")
        sys.exit(1)

    title = f"Preset: {preset.name}"
    print()
    print(f"  {_bold(title)}")
    print(f"  {'━' * len(title)}")

    if preset.display_name and preset.display_name != preset.name:
        print(f"  Display Name: {preset.display_name}")
    if preset.framework_reference:
        certified_note = "aligned, not certified"
        print(f"  Framework:    {preset.framework_reference} ({certified_note})")
    print(f"  Category:     {preset.category}")
    print(f"  Description:  {preset.description}")

    # Disclaimer for compliance presets only
    if preset.disclaimer:
        fw = preset.framework_reference or preset.display_name
        print()
        print(f"  {_yellow('⚠')} This preset is Nomotic's interpretation of governance weights aligned")
        print(f"    to {fw} concerns. It does not constitute {fw} compliance. Consult")
        print("    your compliance team before deploying in regulated environments.")

    # Dimension weights
    print()
    print("  Dimension Weights:")
    for dim, weight in preset.dimension_weights.items():
        print(f"    {dim + ':':<28s} {weight}")

    # Veto dimensions
    print()
    print("  Veto Dimensions:")
    # Wrap veto list
    vetoes = preset.veto_dimensions
    if vetoes:
        lines: list[str] = []
        line = "    "
        for i, v in enumerate(vetoes):
            sep = ", " if i < len(vetoes) - 1 else ""
            if len(line) + len(v) + len(sep) > 72 and line.strip():
                lines.append(line.rstrip(", "))
                line = "    " + v + sep
            else:
                line += v + sep
        if line.strip():
            lines.append(line)
        for l in lines:
            print(l)
    else:
        print("    (none)")

    # Thresholds
    print()
    print("  Thresholds:")
    print(f"    Allow: {preset.allow_threshold}")
    print(f"    Deny:  {preset.deny_threshold}")

    # Trust settings
    print()
    print("  Trust:")
    ts = preset.trust_settings
    print(f"    Success increment:    {ts.get('success_increment', 'N/A')}")
    print(f"    Violation decrement:  {ts.get('violation_decrement', 'N/A')}")
    print(f"    Interrupt cost:       {ts.get('interrupt_cost', 'N/A')}")
    print(f"    Decay rate:           {ts.get('decay_rate', 'N/A')}")
    print(f"    Floor:                {ts.get('floor', 'N/A')}")
    print(f"    Ceiling:              {ts.get('ceiling', 'N/A')}")
    print()


def _settings_list_presets(
    list_compliance_fn,
    list_severity_fn,
    disclaimer: str,
) -> None:
    """List all available presets grouped by category."""
    compliance = list_compliance_fn()
    severity = list_severity_fn()

    print()
    print(f"  {_bold('Available Presets')}")
    print(f"  {'━' * 17}")
    print()

    # Compliance-aligned
    print(f"  {_bold('Compliance-Aligned:')}")
    for p in compliance:
        desc_short = p.description.split(".")[0] if p.description else ""
        print(f"    {p.name:<18s} {p.display_name} — {desc_short.strip().lower()}")
    print()
    print(f"    {_yellow('⚠')} Compliance-aligned presets are Nomotic's interpretation of governance")
    print("      weights. They do not constitute compliance with the referenced frameworks.")
    print()

    # Severity tiers
    print(f"  {_bold('Severity Tiers:')}")
    _severity_descriptions = {
        "standard": "Reasonable defaults for general use",
        "strict": "Elevated security, recommended for production",
        "ultra_strict": "Maximum governance for regulated industries",
    }
    for p in severity:
        desc = _severity_descriptions.get(p.name, p.description)
        print(f"    {p.name:<18s} {desc}")
    print()


def _settings_show_org(base_dir) -> None:
    """Show org governance section."""
    from nomotic.org_governance import load_org_config

    org_config = None
    try:
        org_config = load_org_config()
    except Exception:
        pass

    # Also check base_dir fallback
    if org_config is None:
        org_path = Path(base_dir) / "org-governance.yaml"
        if org_path.is_file():
            try:
                org_config = load_org_config(path=str(org_path))
            except Exception:
                pass

    print(f"  {_bold('Org Governance:')}")
    if org_config is None:
        print("    Not configured. Create ~/.nomotic/org-governance.yaml or run 'nomotic setup'.")
        return

    print(f"    Source:     {org_config.source_path}")
    if org_config.org_name:
        print(f"    Org Name:   {org_config.org_name}")
    print()

    if org_config.minimum_weights:
        print("    Minimum Weights:")
        for dim, weight in org_config.minimum_weights.items():
            print(f"      {dim + ':':<28s} {weight}")
        print()

    if org_config.required_vetoes:
        vetoes_str = ", ".join(org_config.required_vetoes)
        print(f"    Required Vetoes:    {vetoes_str}")

    print(f"    Min Allow Threshold: {org_config.minimum_allow_threshold}")
    print(f"    Min Deny Threshold:  {org_config.minimum_deny_threshold}")
    print(f"    Min Violation Cost:  {org_config.minimum_violation_decrement}")
    print(f"    Max Success Incr:    {org_config.maximum_success_increment}")


def _settings_show_full(
    base_dir,
    list_compliance_fn,
    list_severity_fn,
) -> None:
    """Show the complete settings view."""
    from nomotic import __version__

    config = _load_nomotic_config(Path(base_dir))
    config_path = Path(base_dir) / "config.json"

    print()
    print(f"  {_bold('Nomotic Settings')}")
    print(f"  {'━' * 16}")
    print()

    # Installation section
    print(f"  {_bold('Installation:')}")
    print(f"    Config:     {config_path}")
    print(f"    Version:    {__version__}")
    print(f"    Org:        {config.get('organization', '(not set)')}")
    print(f"    Owner:      {config.get('owner', '(not set)')}")
    print(f"    Zone:       {config.get('default_zone', '(not set)')}")
    print()

    # Org Governance section
    _settings_show_org(base_dir)
    print()

    # Available presets summary
    compliance = list_compliance_fn()
    severity = list_severity_fn()

    print(f"  {_bold('Available Presets:')}")
    compliance_names = ", ".join(p.name for p in compliance)
    severity_names = ", ".join(p.name for p in severity)
    print(f"    Compliance-Aligned: {compliance_names}")
    print(f"    Severity Tiers:     {severity_names}")
    print()
    print("    Use 'nomotic status --preset <name>' for details.")
    print()


# ── Cost projection ──────────────────────────────────────────────────────


def _cmd_cost(args: argparse.Namespace) -> None:
    """Show or configure cost projection for an agent."""
    from nomotic.cost import CostTracker

    base_dir = getattr(args, "base_dir", _DEFAULT_BASE)
    tracker = CostTracker(base_dir)
    profile = tracker.get_profile(args.agent_id)

    if args.configure:
        # Interactive configuration
        print(f"Configure cost settings for: {_bold(args.agent_id)}")
        print()

        raw = input(
            f"  Estimated cost per run [{profile.estimated_cost_per_run or 'auto'}]: "
        ).strip()
        if raw:
            if raw.lower() in ("none", "auto", ""):
                tracker.configure(args.agent_id, estimated_cost_per_run=None)
            else:
                try:
                    tracker.configure(
                        args.agent_id, estimated_cost_per_run=float(raw)
                    )
                except ValueError:
                    print("  Invalid number, skipping.", file=sys.stderr)

        raw = input(
            f"  Daily budget advisory [{profile.daily_budget_advisory or 'none'}]: "
        ).strip()
        if raw:
            if raw.lower() in ("none", ""):
                tracker.configure(args.agent_id, daily_budget_advisory=None)
            else:
                try:
                    tracker.configure(
                        args.agent_id, daily_budget_advisory=float(raw)
                    )
                except ValueError:
                    print("  Invalid number, skipping.", file=sys.stderr)

        raw = input(
            f"  Monthly budget advisory [{profile.monthly_budget_advisory or 'none'}]: "
        ).strip()
        if raw:
            if raw.lower() in ("none", ""):
                tracker.configure(args.agent_id, monthly_budget_advisory=None)
            else:
                try:
                    tracker.configure(
                        args.agent_id, monthly_budget_advisory=float(raw)
                    )
                except ValueError:
                    print("  Invalid number, skipping.", file=sys.stderr)

        print()
        print("Cost settings updated.")
        return

    summary = profile.summary()

    if args.cost_json:
        print(json.dumps(summary, indent=2))
        return

    # Human-readable display
    currency = summary["currency"]
    print(f"Cost Profile: {_bold(args.agent_id)}")
    print("\u2501" * 30)
    print(f"  Total runs:              {summary['total_runs']}")
    print(f"  Average cost/run:        ${summary['average_cost_per_run']:.4f}")
    print(f"  Average execution:       {summary['average_execution_ms']:.1f}ms")
    print(
        f"  Total estimated cost:    ${summary['total_estimated_cost']:,.2f}"
    )
    print(f"  Daily projection:        ${summary['daily_projection']:,.2f}")
    print(f"  Monthly projection:      ${summary['monthly_projection']:,.2f}")

    daily_adv = summary["daily_budget_advisory"]
    if daily_adv is not None:
        status = (
            _green("\u2713 (under budget)")
            if summary["daily_projection"] <= daily_adv
            else _red("\u2717 (OVER BUDGET)")
        )
        print(f"  Daily budget advisory:   ${daily_adv:,.2f}  {status}")
    else:
        print("  Daily budget advisory:   not set")

    monthly_adv = summary["monthly_budget_advisory"]
    if monthly_adv is not None:
        status = (
            _green("\u2713 (under budget)")
            if summary["monthly_projection"] <= monthly_adv
            else _red("\u2717 (OVER BUDGET)")
        )
        print(f"  Monthly budget advisory: ${monthly_adv:,.2f}  {status}")
    else:
        print("  Monthly budget advisory: not set")
    print()


# ── Argument parser ──────────────────────────────────────────────────────


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="nomotic",
        description="Nomotic — runtime governance for agentic AI",
    )
    parser.add_argument(
        "--base-dir",
        type=Path,
        default=_DEFAULT_BASE,
        help="Base directory for nomotic data (default: ~/.nomotic)",
    )

    sub = parser.add_subparsers(dest="command")

    # setup
    sub.add_parser("setup", help="Configure Nomotic defaults (organization, owner, zone)")

    # new (project config generator)
    new = sub.add_parser("new", help="Generate a nomotic.yaml governance config for this project")
    new.add_argument("path", nargs="?", default=".", help="Directory to create nomotic.yaml in (default: current directory)")
    new.add_argument("--name", default=None, help="Agent name (default: directory name)")
    new.add_argument("--preset", default=None, help="Governance preset (e.g., strict, hipaa_aligned)")
    new.add_argument("--actions", default=None, help="Comma-separated allowed actions")
    new.add_argument("--targets", default=None, help="Comma-separated target resources")
    new.add_argument("--owner", default=None, help="Agent owner (default: from setup config)")
    new.add_argument("--reason", default=None, help="Why this agent exists")
    new.add_argument("--force", action="store_true", help="Overwrite existing nomotic.yaml")
    new.add_argument("--full", action="store_true", help="Include commented-out override sections")
    new.add_argument("--no-validate", action="store_true", help="Skip auto-validation after creation")

    # birth
    birth = sub.add_parser("birth", help="Create a new agent")
    birth.add_argument("--name", default=None, help="Agent name")
    birth.add_argument("--agent-id", dest="agent_id_compat", default=None, help=argparse.SUPPRESS)
    birth.add_argument("--archetype", default=None, help="Behavioral archetype (optional, can be set later)")
    birth.add_argument("--org", default=None, help="Organization (default: from setup config)")
    birth.add_argument("--zone", default=None, help="Governance zone (default: from setup config)")
    birth.add_argument("--owner", default=None, help="Agent owner (default: from setup config)")

    # verify
    verify = sub.add_parser("verify", help="Verify a certificate")
    verify.add_argument("cert_id", help="Agent ID, name, or certificate ID")

    # inspect (consolidated agent inspection)
    inspect_ = sub.add_parser("inspect", help="Inspect an agent's governance configuration and state")
    inspect_.add_argument("agent_id", help="Agent ID, name, or certificate ID")
    inspect_.add_argument("--brief", action="store_true", help="Quick operational summary")
    inspect_.add_argument("--raw", action="store_true", help="Raw certificate JSON")

    # suspend
    suspend = sub.add_parser("suspend", help="Suspend a certificate")
    suspend.add_argument("cert_id", help="Agent ID, name, or certificate ID")
    suspend.add_argument("--reason", required=True, help="Reason for suspension")

    # reactivate
    reactivate = sub.add_parser("reactivate", help="Reactivate a suspended certificate")
    reactivate.add_argument("cert_id", help="Agent ID, name, or certificate ID")

    # revoke
    revoke = sub.add_parser("revoke", help="Permanently revoke a certificate")
    revoke.add_argument("cert_id", help="Agent ID, name, or certificate ID")
    revoke.add_argument("--reason", required=True, help="Reason for revocation")

    # renew
    renew = sub.add_parser("renew", help="Renew a certificate with lineage link")
    renew.add_argument("cert_id", help="Agent ID, name, or certificate ID")

    # list
    list_ = sub.add_parser("list", help="List certificates")
    list_.add_argument("--status", default=None, help="Filter by status")
    list_.add_argument("--archetype", default=None, help="Filter by archetype")
    list_.add_argument("--org", default=None, help="Filter by organization")

    # reputation
    rep = sub.add_parser("reputation", help="Show trust trajectory")
    rep.add_argument("cert_id", help="Agent ID, name, or certificate ID")

    # export
    export = sub.add_parser("export", help="Export public certificate to file")
    export.add_argument("cert_id", help="Agent ID, name, or certificate ID")

    # ── archetype subcommands ────────────────────────────────────────
    archetype = sub.add_parser("archetype", help="Manage archetypes")
    arch_sub = archetype.add_subparsers(dest="archetype_command")

    arch_list = arch_sub.add_parser("list", help="List archetypes")
    arch_list.add_argument("--category", default=None, help="Filter by category")

    arch_reg = arch_sub.add_parser("register", help="Register a custom archetype")
    arch_reg.add_argument("--name", required=True, help="Archetype name")
    arch_reg.add_argument("--description", required=True, help="Description")
    arch_reg.add_argument("--category", required=True, help="Category")

    arch_val = arch_sub.add_parser("validate", help="Validate an archetype name")
    arch_val.add_argument("name", help="Archetype name to validate")

    arch_set = arch_sub.add_parser("set", help="Set archetype for an agent (interactive)")
    arch_set.add_argument("agent_identifier", help="Agent name, ID, or certificate ID")

    # ── org subcommands ──────────────────────────────────────────────
    org = sub.add_parser("org", help="Manage organizations")
    org_sub = org.add_subparsers(dest="org_command")

    org_register = org_sub.add_parser("register", help="Register an organization")
    org_register.add_argument("--name", required=True, help="Organization name")
    org_register.add_argument("--email", default=None, help="Contact email")

    org_list = org_sub.add_parser("list", help="List organizations")
    org_list.add_argument("--status", default=None, help="Filter by status")

    org_val = org_sub.add_parser("validate", help="Validate an org name")
    org_val.add_argument("name", help="Organization name to validate")

    # ── zone subcommands ─────────────────────────────────────────────
    zone = sub.add_parser("zone", help="Manage governance zones")
    zone_sub = zone.add_subparsers(dest="zone_command")

    zone_val = zone_sub.add_parser("validate", help="Validate a zone path")
    zone_val.add_argument("path", help="Zone path to validate")

    # ── scope ───────────────────────────────────────────────────────
    scope = sub.add_parser("scope", help="Configure agent authority scope")
    scope.add_argument("agent_id", help="Agent ID, name, or certificate ID")
    scope_sub = scope.add_subparsers(dest="scope_command")
    scope_set = scope_sub.add_parser("set", help="Set scope and boundaries")
    scope_set.add_argument("--actions", default=None, help="Comma-separated allowed actions")
    scope_set.add_argument("--boundaries", default=None, help="Comma-separated allowed targets")
    scope_show = scope_sub.add_parser("show", help="Show current scope")

    # ── rule ────────────────────────────────────────────────────────
    rule = sub.add_parser("rule", help="Manage governance rules")
    rule.add_argument("agent_id", help="Agent ID, name, or certificate ID")
    rule_sub = rule.add_subparsers(dest="rule_command")
    rule_add = rule_sub.add_parser("add", help="Add a governance rule")
    rule_add.add_argument("--type", required=True, choices=["ethical", "human-override"], help="Rule type")
    rule_add.add_argument("--condition", default=None, help="Condition expression (ethical rules)")
    rule_add.add_argument("--action", default=None, help="Action type (human-override rules)")
    rule_add.add_argument("--message", default=None, help="Message when rule triggers")
    rule_add.add_argument("--name", default=None, help="Optional rule name")

    # ── config (global configuration) ─────────────────────────────
    config = sub.add_parser("config", help="Manage Nomotic configuration")
    config_sub = config.add_subparsers(dest="config_command")
    config_set = config_sub.add_parser("set", help="Set a configuration value")
    config_set.add_argument("--retention", default=None, help="Audit retention period (2y, 3y, 5y, forever)")

    # ── test (formerly eval) ──────────────────────────────────────────
    test_parser = sub.add_parser("test", help="Test a governance decision (simulated \u2014 does not affect production trust)")
    test_parser.add_argument("agent_id", help="Agent ID, name, or certificate ID")
    test_parser.add_argument("--action", default=None, help="Action type to evaluate (required unless --adversarial)")
    test_parser.add_argument("--target", default=None, help="Target resource")
    test_parser.add_argument("--params", default=None, help="JSON parameters")
    test_parser.add_argument("--adversarial", action="store_true",
                             help="Run adversarial red team scenarios")
    test_parser.add_argument("--category", default=None,
                             help="Adversarial category (injection, escalation, drift, trust, deputy, recon)")
    test_parser.add_argument("--report", action="store_true",
                             help="Generate detailed adversarial report")

    # Hidden alias for backward compatibility
    eval_parser = sub.add_parser("eval", help=argparse.SUPPRESS)
    eval_parser.add_argument("agent_id", help="Agent ID, name, or certificate ID")
    eval_parser.add_argument("--action", required=True, help="Action type to evaluate")
    eval_parser.add_argument("--target", default=None, help="Target resource")
    eval_parser.add_argument("--params", default=None, help="JSON parameters")

    # ── simulate ────────────────────────────────────────────────────
    sim_parser = sub.add_parser("simulate", help="Run a batch governance simulation")
    sim_parser.add_argument("agent_id", help="Agent ID, name, or certificate ID")
    sim_parser.add_argument("--scenario", required=True, help="Scenario name (normal, drift, violations, mixed)")
    sim_parser.add_argument("--count", type=int, default=None, help="Override action count")
    sim_parser.add_argument("--description", default=None, help="Custom scenario description")

    # ── testlog ─────────────────────────────────────────────────────
    testlog_parser = sub.add_parser("testlog", help="View test evaluation history")
    testlog_parser.add_argument("identifier", nargs="?", default=None,
                                help="Agent name, ID, or certificate ID")
    testlog_parser.add_argument("--summary", action="store_true", help="Show summary")
    testlog_parser.add_argument("--verify", action="store_true", help="Verify hash chain")
    testlog_parser.add_argument("--limit", type=int, default=20, help="Max records")
    testlog_parser.add_argument("--clear", action="store_true",
                                help="Clear test history and reset simulated trust")

    # ── tutorial ───────────────────────────────────────────────────
    sub.add_parser("tutorial", help="Interactive walkthrough of the complete governance lifecycle")

    # ── serve ────────────────────────────────────────────────────────
    serve = sub.add_parser("serve", help="Start the Nomotic API server")
    serve.add_argument("--host", default="0.0.0.0", help="Bind host (default: 0.0.0.0)")
    serve.add_argument("--port", type=int, default=8420, help="Bind port (default: 8420)")
    serve.add_argument(
        "--metrics",
        action="store_true",
        default=False,
        help="Enable Prometheus /metrics endpoint",
    )

    # ── mcp-proxy ──────────────────────────────────────────────────────
    mcp_parser = sub.add_parser("mcp-proxy", help="Run MCP governance proxy")
    mcp_parser.add_argument("--agent-id", required=True, help="Nomotic agent identity")
    mcp_parser.add_argument("--upstream", default=None, help="Upstream MCP server command (stdio mode)")
    mcp_parser.add_argument("--upstream-url", default=None, help="Upstream MCP server URL (HTTP mode)")
    mcp_parser.add_argument("--port", type=int, default=8421, help="Proxy listen port (HTTP mode)")
    mcp_parser.add_argument("--host", default="127.0.0.1", help="Proxy listen host (HTTP mode)")
    mcp_parser.add_argument("--test-mode", action="store_true", help="Use testlog and simulated trust")
    mcp_parser.add_argument("--log-level", default="info", choices=["debug", "info", "quiet"],
                            help="Logging verbosity (default: info)")
    mcp_parser.add_argument(
        "--require-certificate", action="store_true",
        help="Require valid birth certificate for all requests. "
             "Only enforced for traffic routed through this proxy.",
    )
    mcp_parser.add_argument(
        "--agent-map",
        help="Path to agent ID mapping JSON file (IP/key → agent_id)",
    )
    mcp_parser.add_argument(
        "--timeout", type=float, default=30.0,
        help="Default upstream timeout in seconds",
    )
    mcp_parser.add_argument(
        "--log-format", choices=["json", "text"], default="json",
        help="Log format",
    )

    # ── proxy ────────────────────────────────────────────────────────
    proxy_parser = sub.add_parser("proxy", help="Run governance proxy for HTTP traffic")
    proxy_parser.add_argument("--agent-id", required=True, help="Agent identity for governance")
    proxy_parser.add_argument("--listen", default="0.0.0.0:8421", help="Proxy listen address (default: 0.0.0.0:8421)")
    proxy_parser.add_argument("--upstream", required=True, help="Upstream service URL")
    proxy_parser.add_argument("--test-mode", action="store_true", help="Use testlog and simulated trust")
    proxy_parser.add_argument(
        "--require-certificate", action="store_true",
        help="Require valid birth certificate for all requests. "
             "Only enforced for traffic routed through this proxy.",
    )
    proxy_parser.add_argument(
        "--agent-map",
        help="Path to agent ID mapping JSON file (IP/key → agent_id)",
    )
    proxy_parser.add_argument(
        "--timeout", type=float, default=30.0,
        help="Default upstream timeout in seconds",
    )
    proxy_parser.add_argument(
        "--log-format", choices=["json", "text"], default="json",
        help="Log format",
    )

    # ── hello ────────────────────────────────────────────────────────
    sub.add_parser("hello", help="Start the Nomotic tutorial (same as 'nomotic tutorial')")

    # ── history ─────────────────────────────────────────────────────
    history = sub.add_parser("history", help="Full historical record for an agent (including revoked)")
    history.add_argument("identifier", help="Agent ID, name, or certificate ID")

    # ── fingerprint ─────────────────────────────────────────────────
    fp_parser = sub.add_parser("fingerprint", help="Show behavioral fingerprint for an agent")
    fp_parser.add_argument("agent_id", help="Agent identifier")
    fp_parser.add_argument("--host", default="127.0.0.1", help="API server host (default: 127.0.0.1)")
    fp_parser.add_argument("--port", type=int, default=8420, help="API server port (default: 8420)")

    # ── drift ────────────────────────────────────────────────────
    drift_parser = sub.add_parser("drift", help="Show behavioral drift for an agent")
    drift_parser.add_argument("agent_id", help="Agent identifier")
    drift_parser.add_argument("--host", default="127.0.0.1", help="API server host (default: 127.0.0.1)")
    drift_parser.add_argument("--port", type=int, default=8420, help="API server port (default: 8420)")

    # ── trust ────────────────────────────────────────────────────
    trust_parser = sub.add_parser("trust", help="Show trust report for an agent")
    trust_parser.add_argument("agent_id", help="Agent identifier")
    trust_parser.add_argument("--host", default="127.0.0.1", help="API server host (default: 127.0.0.1)")
    trust_parser.add_argument("--port", type=int, default=8420, help="API server port (default: 8420)")

    # ── alerts ───────────────────────────────────────────────────
    alerts_parser = sub.add_parser("alerts", help="List drift alerts")
    alerts_parser.add_argument("--agent-id", default=None, help="Filter by agent ID")
    alerts_parser.add_argument("--unacknowledged", action="store_true", help="Show only unacknowledged alerts")
    alerts_parser.add_argument("--host", default="127.0.0.1", help="API server host (default: 127.0.0.1)")
    alerts_parser.add_argument("--port", type=int, default=8420, help="API server port (default: 8420)")

    # ── audit ────────────────────────────────────────────────────
    audit_parser = sub.add_parser("audit", help="View audit trail and verify integrity")
    audit_parser.add_argument("identifier", nargs="?", default=None,
                              help="Agent name, ID, or certificate ID")
    audit_parser.add_argument("--summary", action="store_true", help="Show summary instead of records")
    audit_parser.add_argument("--verify", action="store_true", help="Verify hash chain integrity")
    audit_parser.add_argument("--all", action="store_true", dest="show_all", help="Show all agents (no filter)")
    audit_parser.add_argument("--limit", type=int, default=20, help="Max records to show")
    audit_parser.add_argument("--severity", default=None, help="Filter by severity")
    audit_parser.add_argument("--delegations", action="store_true", help="Show delegation history")
    audit_parser.add_argument(
        "--push-agicomply",
        action="store_true",
        help="Push audit records to AGICOMPLY (requires AGICOMPLY_API_URL, "
             "AGICOMPLY_API_TOKEN, AGICOMPLY_SYSTEM_ID env vars)"
    )
    audit_parser.add_argument(
        "--agicomply-endpoint",
        default="/api/runtime-governance/ingest",
        help="AGICOMPLY ingestion endpoint (default: /api/runtime-governance/ingest)"
    )

    # ── provenance ──────────────────────────────────────────────
    prov_parser = sub.add_parser("provenance", help="Show configuration provenance")
    prov_parser.add_argument("--target-type", default=None, help="Filter by target type")
    prov_parser.add_argument("--target-id", default=None, help="Filter by target ID")
    prov_parser.add_argument("--host", default="127.0.0.1", help="API server host")
    prov_parser.add_argument("--port", type=int, default=8420, help="API server port")

    # ── owner ───────────────────────────────────────────────────
    owner_parser = sub.add_parser("owner", help="Show owner activity")
    owner_parser.add_argument("owner_id", help="Owner identifier")
    owner_parser.add_argument("--engagement", action="store_true", help="Show engagement score")
    owner_parser.add_argument("--host", default="127.0.0.1", help="API server host")
    owner_parser.add_argument("--port", type=int, default=8420, help="API server port")

    # ── oversight (human drift) ─────────────────────────────────
    oversight_parser = sub.add_parser("oversight", help="Human oversight engagement analysis")
    oversight_parser.add_argument("reviewer_id", nargs="?", default=None, help="Reviewer identifier")
    oversight_parser.add_argument("--drift", action="store_true", help="Show drift analysis")
    oversight_parser.add_argument("--alerts", action="store_true", help="Show all human drift alerts")
    oversight_parser.add_argument("--team", action="store_true", help="Show team-level oversight health")

    # ── siem-export ──────────────────────────────────────────────
    siem_parser = sub.add_parser("siem-export", help="Export audit trail in SIEM formats (CEF, syslog, JSONL)")
    siem_parser.add_argument("identifier", nargs="?", default=None,
                             help="Agent name, ID, or certificate ID")
    siem_parser.add_argument("--format", dest="siem_format", default="jsonl",
                             choices=["cef", "syslog", "jsonl"],
                             help="Output format (default: jsonl)")
    siem_parser.add_argument("--since", default=None,
                             help="Start date (ISO 8601, e.g. 2026-02-01)")
    siem_parser.add_argument("--until", default=None,
                             help="End date (ISO 8601, e.g. 2026-02-28)")
    siem_parser.add_argument("--severity", default=None,
                             help="Filter by severity (info, warning, alert, critical)")
    siem_parser.add_argument("--verdict", default=None,
                             help="Filter by verdict (ALLOW, DENY, etc.)")
    siem_parser.add_argument("--all", action="store_true", dest="siem_all",
                             help="Export all agents")
    siem_parser.add_argument("--output", default=None,
                             help="Output file path (default: stdout)")
    siem_parser.add_argument("--include-dimensions", action="store_true",
                             help="Include per-dimension scores")

    # ── evidence ──────────────────────────────────────────────────
    evidence_parser = sub.add_parser(
        "evidence",
        help="Generate, verify, and summarize compliance evidence bundles",
    )
    evidence_sub = evidence_parser.add_subparsers(dest="evidence_command")

    ev_gen = evidence_sub.add_parser("generate", help="Generate a compliance evidence bundle")
    ev_gen.add_argument("identifier", nargs="?", default=None,
                        help="Agent name, ID, or certificate ID (omit for all agents)")
    ev_gen.add_argument("--frameworks", default=None,
                        help="Comma-separated frameworks: SOC2,HIPAA,PCI-DSS,ISO27001")
    ev_gen.add_argument("--since", default=None,
                        help="Start date (ISO 8601, e.g. 2026-01-01)")
    ev_gen.add_argument("--until", default=None,
                        help="End date (ISO 8601, e.g. 2026-02-28)")
    ev_gen.add_argument("--output", default=None,
                        help="Output file path (default: stdout)")
    ev_gen.add_argument("--created-by", default="nomotic-cli",
                        help="Identity of who is generating this bundle")

    ev_verify = evidence_sub.add_parser("verify", help="Verify a bundle file's integrity")
    ev_verify.add_argument("bundle_file", help="Path to evidence bundle JSON file")

    ev_summary = evidence_sub.add_parser("summary", help="Show a summary of a bundle file")
    ev_summary.add_argument("bundle_file", help="Path to evidence bundle JSON file")

    # ── validate ──────────────────────────────────────────────────
    validate = sub.add_parser(
        "validate",
        help="Validate a nomotic.yaml governance config file",
    )
    validate.add_argument(
        "path", nargs="?", default=".",
        help="Path to nomotic.yaml or directory (default: .)",
    )
    validate.add_argument(
        "--strict", action="store_true", default=False,
        help="Treat warnings as errors (exit 1 on any warning)",
    )
    validate.add_argument(
        "--preset", default=None,
        help="Apply a preset for validation (canonical name, e.g. hipaa_aligned)",
    )
    validate.add_argument(
        "--org", default=None,
        help="Path to org config (otherwise auto-discovers via load_org_config)",
    )
    validate.add_argument(
        "--json", action="store_true", default=False,
        help="Output results as JSON instead of formatted text",
    )
    validate.add_argument(
        "--quiet", action="store_true", default=False,
        help="Only output errors",
    )

    # ── cost ──────────────────────────────────────────────────────
    cost_parser = sub.add_parser("cost", help="Show cost projection for an agent")
    cost_parser.add_argument("agent_id", help="Agent to show costs for")
    cost_parser.add_argument("--configure", action="store_true",
                             help="Configure cost settings")
    cost_parser.add_argument("--json", action="store_true", dest="cost_json",
                             help="JSON output")

    # ── status (global settings/status) ──────────────────────────
    status = sub.add_parser("status", help="Show global governance settings and presets")
    status.add_argument(
        "--org", action="store_true", default=False, dest="org_only",
        help="Show only org-level governance settings",
    )
    status.add_argument(
        "--presets", action="store_true", default=False, dest="presets_list",
        help="List all available presets",
    )
    status.add_argument(
        "--preset", default=None, dest="preset_detail",
        help="Show full details of a specific preset (canonical name)",
    )
    status.add_argument(
        "--policies", action="store_true", default=False, dest="policies_list",
        help="List active governance policies (policy-as-code)",
    )

    # ── compliance-report ─────────────────────────────────────────
    compliance_parser = sub.add_parser(
        "compliance-report", help="Generate compliance mapping report",
    )
    compliance_parser.add_argument(
        "--framework", required=True,
        choices=[
            "soc2", "hipaa", "eu-ai-act", "iso27001",
            "nist-ai-rmf", "nist-csf-ai", "imda-agentic",
        ],
        help="Compliance framework to map against",
    )
    compliance_parser.add_argument(
        "--agent", default=None,
        help="Include agent-specific evidence",
    )
    compliance_parser.add_argument(
        "--include-layer-map", action="store_true", default=False,
        help="Include governance stack coverage",
    )
    compliance_parser.add_argument(
        "--output", default=None,
        help="Output file (extension determines format: .json or .md)",
    )

    # ── doctor ─────────────────────────────────────────────────────
    p_doctor = sub.add_parser("doctor", help="Check governance infrastructure health")
    p_doctor.add_argument("--quiet", action="store_true", help="Only show errors and warnings")
    p_doctor.add_argument("--json", action="store_true", dest="doctor_json", help="Machine-readable JSON output")
    p_doctor.add_argument(
        "--fix",
        action="store_true",
        help="Attempt to auto-fix simple issues (interactive)",
    )

    # ── policy-validate ──────────────────────────────────────────
    policy_validate = sub.add_parser(
        "policy-validate", help="Validate policy files and configuration",
    )
    policy_validate.add_argument(
        "--dir", default=None, dest="policy_dir",
        help="Directory to load policies from (default: ./nomotic-policies/ and ~/.nomotic/policies/)",
    )
    policy_validate.add_argument(
        "--json", action="store_true", dest="policy_json",
        help="Output results as JSON",
    )

    # ── override ──────────────────────────────────────────────────
    override = sub.add_parser("override", help="Override a governance decision")
    override.add_argument("action_id", help="Action ID to override")
    override.add_argument("--approve", action="store_true", help="Approve a previously denied action")
    override.add_argument("--revoke", action="store_true", help="Revoke a previously allowed action")
    override.add_argument("--authority", required=True, help="Identity of the person overriding (email or ID)")
    override.add_argument("--reason", required=True, help="Reason for the override")
    override.add_argument("--agent", default=None, help="Agent ID (required if action_id is ambiguous)")
    override.add_argument("--trust-penalty", type=float, default=0.10, help="Trust penalty for REVOKE (default: 0.10)")

    return parser


def _cmd_policy_validate(args: argparse.Namespace) -> None:
    """Validate policy files and configuration."""
    from nomotic.policy import PolicyEngine

    dirs = None
    if args.policy_dir:
        dirs = [Path(args.policy_dir)]

    engine = PolicyEngine(policy_dirs=dirs)
    policies = engine.list_policies()
    issues = engine.validate_all()

    if getattr(args, "policy_json", False):
        result = {
            "policies_loaded": len(policies),
            "policies": [p.to_dict() for p in policies],
            "issues": issues,
            "valid": len(issues) == 0,
        }
        print(json.dumps(result, indent=2))
        sys.exit(1 if issues else 0)

    print()
    print(_bold("Policy Validation"))
    print("\u2501" * 17)
    print()

    if not policies and not issues:
        print("  No policies loaded.")
        print()
        print("  Policy directories searched:")
        if dirs:
            for d in dirs:
                print(f"    {d}")
        else:
            print("    ./nomotic-policies/")
            print(f"    {Path.home() / '.nomotic' / 'policies'}/")
        print()
        print("  To create a policy, add a JSON or YAML file to one of these directories.")
        print()
        sys.exit(0)

    print(f"  Policies loaded: {len(policies)}")
    print()
    for p in policies:
        status_icon = _green("\u2713") if p.enabled else _yellow("\u25cb")
        print(f"    {status_icon} {_bold(p.name)} (priority={p.priority})")
        if p.description:
            print(f"      {p.description}")
        verdict = p.then.get("verdict", "?")
        print(f"      When: {p.when}")
        print(f"      Then: {verdict}")
    print()

    if issues:
        print(f"  {_red('Issues found:')}")
        for issue in issues:
            x_icon = _red("\u2717")
            pol = issue['policy']
            desc = issue['issue']
            print(f"    {x_icon} [{pol}] {desc}")
        print()
        sys.exit(1)
    else:
        ok_icon = _green("\u2713")
        print(f"  {ok_icon} All policies valid.")
        print()


def _cmd_override(args: argparse.Namespace) -> None:
    """Override a governance decision after the fact."""
    if args.approve == args.revoke:  # both True or both False
        print(_red("Specify exactly one of --approve or --revoke"))
        sys.exit(1)

    override_type = "APPROVE" if args.approve else "REVOKE"

    base = args.base_dir
    from nomotic.audit_store import AuditStore
    from nomotic.runtime import GovernanceRuntime, RuntimeConfig

    # Build a runtime with the persistent audit store
    audit_store = AuditStore(base)
    runtime = GovernanceRuntime(RuntimeConfig(enable_audit=False))
    runtime.set_audit_store(audit_store)

    # If --agent is given, seed the trust profile from the audit store
    agent_id = args.agent if args.agent else None
    if agent_id:
        # Pre-load trust from the audit store summary
        summary = audit_store.summary(agent_id)
        if summary.get("total", 0) > 0:
            trust = summary.get("trust_end", 0.5)
            profile = runtime.trust_calibrator.get_profile(agent_id)
            profile.overall_trust = trust

    # Attempt to seed trust from last audit record for the agent
    if agent_id is None:
        # Search all agents for the action_id
        for aid in audit_store.list_agents():
            record = audit_store.find_by_action_id(aid, args.action_id)
            if record is not None:
                agent_id = record.agent_id
                profile = runtime.trust_calibrator.get_profile(agent_id)
                profile.overall_trust = record.trust_score
                break

    try:
        result = runtime.override(
            action_id=args.action_id,
            override_type=override_type,
            authority=args.authority,
            reason=args.reason,
            trust_penalty=args.trust_penalty,
        )
    except ValueError as e:
        print(_red(str(e)))
        sys.exit(1)

    # Display result
    print()
    print(_bold("Override Recorded"))
    print(f"  Override ID: {result.override_id}")
    if override_type == "APPROVE":
        print(f"  Type: {_green(override_type)}")
    else:
        print(f"  Type: {_red(override_type)}")
    print(f"  Action: {result.action_id}")
    print(f"  Agent: {result.agent_id}")
    print(f"  Authority: {result.authority}")
    print(f"  Reason: {result.reason}")
    if result.trust_before != result.trust_after:
        print(f"  Trust: {result.trust_before:.2f} \u2192 {result.trust_after:.2f}")
    print()


def _cmd_doctor(args: argparse.Namespace) -> None:
    """Run governance infrastructure health checks."""
    from nomotic.doctor import run_doctor

    base_dir = Path(args.base_dir) if hasattr(args, "base_dir") and args.base_dir else _DEFAULT_BASE
    report = run_doctor(base_dir)

    if args.doctor_json:
        print(json.dumps(report.to_dict(), indent=2))
        sys.exit(1 if report.has_errors else 0)

    # ── Header ────────────────────────────────────────────────────────────
    print()
    print(_bold("Nomotic Doctor"))
    print("\u2501" * 44)
    print()

    # ── Print checks ──────────────────────────────────────────────────────
    current_category = None
    for check in report.checks:
        if check.category != current_category:
            current_category = check.category
            print(f"  {_bold(check.category)}:")

        if check.status == "ok":
            if args.quiet:
                continue
            icon = _green("\u2713")
        elif check.status == "warning":
            icon = _yellow("\u26a0")
        else:  # error
            icon = _red("\u2717")

        print(f"    {icon} {check.message}")
        if check.fix_hint and args.fix and check.category != "Audit Trail":
            print(f"      \u2192 Fix: {check.fix_hint}")

    # ── Audit trail safety guard ──────────────────────────────────────────
    if args.fix:
        audit_errors = [
            c for c in report.checks
            if c.category == "Audit Trail" and c.status == "error"
        ]
        if audit_errors:
            print(
                "  \u26a0 Audit trail integrity issues require manual investigation"
                " \u2014 cannot be auto-fixed."
            )
            print(
                "  Chain breaks and tampering detections are forensic evidence"
                " and must be preserved."
            )
            print()

    # ── Summary ───────────────────────────────────────────────────────────
    print()
    n_errors = len(report.errors)
    n_warnings = len(report.warnings)

    if n_errors == 0 and n_warnings == 0:
        print(f"  {_green(chr(0x2713))} All checks passed.")
    else:
        parts = []
        if n_errors:
            parts.append(_red(f"{n_errors} error{'s' if n_errors != 1 else ''}"))
        if n_warnings:
            parts.append(_yellow(f"{n_warnings} warning{'s' if n_warnings != 1 else ''}"))
        print(f"  Summary: {', '.join(parts)}")
    print()

    if report.has_errors:
        sys.exit(1)


def main(argv: list[str] | None = None) -> None:
    parser = build_parser()
    args = parser.parse_args(argv)

    if args.command is None:
        parser.print_help()
        sys.exit(0)

    commands = {
        "setup": _cmd_setup,
        "new": _cmd_new,
        "birth": _cmd_birth,
        "verify": _cmd_verify,
        "inspect": _cmd_inspect_agent,
        "suspend": _cmd_suspend,
        "reactivate": _cmd_reactivate,
        "revoke": _cmd_revoke,
        "renew": _cmd_renew,
        "list": _cmd_list,
        "reputation": _cmd_reputation,
        "export": _cmd_export,
        "status": _cmd_status_global,
        "history": _cmd_history,
        "archetype": _cmd_archetype,
        "org": _cmd_org,
        "zone": _cmd_zone,
        "scope": _cmd_scope,
        "rule": _cmd_rule,
        "config": _cmd_config,
        "test": _cmd_test,
        "eval": _cmd_test,
        "simulate": _cmd_simulate,
        "tutorial": _cmd_tutorial,
        "serve": _cmd_serve,
        "hello": _cmd_hello,
        "fingerprint": _cmd_fingerprint,
        "drift": _cmd_drift,
        "alerts": _cmd_alerts,
        "trust": _cmd_trust,
        "audit": _cmd_audit,
        "testlog": _cmd_testlog,
        "provenance": _cmd_provenance,
        "owner": _cmd_owner,
        "oversight": _cmd_oversight,
        "siem-export": _cmd_siem_export,
        "mcp-proxy": _cmd_mcp_proxy,
        "proxy": _cmd_proxy,
        "evidence": _cmd_evidence,
        "compliance-report": _cmd_compliance_report,
        "validate": _cmd_validate,
        "cost": _cmd_cost,
        "doctor": _cmd_doctor,
        "override": _cmd_override,
        "policy-validate": _cmd_policy_validate,
    }

    handler = commands.get(args.command)
    if handler is None:
        parser.print_help()
        sys.exit(1)
    handler(args)


if __name__ == "__main__":
    main()
