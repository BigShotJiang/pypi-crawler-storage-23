"""Tests for the ``nomotic validate`` CLI command."""

from __future__ import annotations

import json
import textwrap
from pathlib import Path

import pytest

from nomotic.cli import main


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _valid_yaml() -> str:
    """A fully valid nomotic.yaml config."""
    return textwrap.dedent("""\
        version: "1.0"

        agents:
          test-agent:
            scope:
              actions: [read, write]
              targets: [data]
              boundaries: [data]
            trust:
              initial: 0.6
              minimum_for_action: 0.25

        dimensions:
          weights:
            scope_compliance: 2.0
            authority_verification: 1.8
            resource_boundaries: 1.5
            behavioral_consistency: 1.2
            cascading_impact: 1.3
            stakeholder_impact: 1.2
            incident_detection: 2.0
            isolation_integrity: 1.8
            temporal_compliance: 1.0
            precedent_alignment: 0.8
            transparency: 1.5
            human_override: 2.0
            ethical_alignment: 1.5
          vetoes:
            - scope_compliance
            - human_override

        thresholds:
          allow: 0.75
          deny: 0.35

        trust:
          success_increment: 0.008
          violation_decrement: 0.06
          interrupt_cost: 0.04
          decay_rate: 0.001
          floor: 0.05
          ceiling: 0.93
    """)


def _threshold_inverted_yaml() -> str:
    """Config with allow_threshold <= deny_threshold."""
    return textwrap.dedent("""\
        version: "1.0"

        agents:
          test-agent:
            scope:
              actions: [read]
              targets: [data]
              boundaries: [data]

        dimensions:
          weights:
            scope_compliance: 1.0
            authority_verification: 1.0
            resource_boundaries: 1.0
            behavioral_consistency: 1.0
            cascading_impact: 1.0
            stakeholder_impact: 1.0
            incident_detection: 1.0
            isolation_integrity: 1.0
            temporal_compliance: 1.0
            precedent_alignment: 1.0
            transparency: 1.0
            human_override: 1.0
            ethical_alignment: 1.0
          vetoes:
            - scope_compliance

        thresholds:
          allow: 0.30
          deny: 0.80

        trust:
          success_increment: 0.01
          violation_decrement: 0.05
          interrupt_cost: 0.04
          decay_rate: 0.001
          floor: 0.05
          ceiling: 0.95
    """)


def _warning_yaml() -> str:
    """Config that is valid but produces warnings (high-weight critical dim without veto)."""
    return textwrap.dedent("""\
        version: "1.0"

        agents:
          test-agent:
            scope:
              actions: [read, write]
              targets: [data]
              boundaries: [data]

        dimensions:
          weights:
            scope_compliance: 2.0
            authority_verification: 2.0
            resource_boundaries: 1.0
            behavioral_consistency: 1.0
            cascading_impact: 1.0
            stakeholder_impact: 1.0
            incident_detection: 1.0
            isolation_integrity: 1.0
            temporal_compliance: 1.0
            precedent_alignment: 1.0
            transparency: 1.0
            human_override: 1.0
            ethical_alignment: 1.0
          vetoes: []

        thresholds:
          allow: 0.75
          deny: 0.35

        trust:
          success_increment: 0.008
          violation_decrement: 0.06
          interrupt_cost: 0.04
          decay_rate: 0.001
          floor: 0.05
          ceiling: 0.93
    """)


def _hipaa_extends_yaml() -> str:
    """Config extending hipaa_aligned preset."""
    return textwrap.dedent("""\
        version: "1.0"
        extends: "hipaa_aligned"

        agents:
          my-agent:
            scope:
              actions: [read, write]
              targets: [patient_records]
              boundaries: [patient_records]
    """)


def _bad_extends_yaml() -> str:
    """Config extending invalid preset name 'HIPAA'."""
    return textwrap.dedent("""\
        version: "1.0"
        extends: "HIPAA"

        agents:
          my-agent:
            scope:
              actions: [read]
              targets: [data]
              boundaries: [data]
    """)


def _strict_extends_yaml() -> str:
    """Config extending a severity preset (strict) — no disclaimer."""
    return textwrap.dedent("""\
        version: "1.0"
        extends: "strict"

        agents:
          my-agent:
            scope:
              actions: [read, write]
              targets: [data]
              boundaries: [data]
    """)


def _all_zero_weights_yaml() -> str:
    """Config with all weights 0.0 and no vetoes — simulation should fail."""
    return textwrap.dedent("""\
        version: "1.0"

        agents:
          test-agent:
            scope:
              actions: [read]
              targets: [data]
              boundaries: [data]

        dimensions:
          weights:
            scope_compliance: 0.0
            authority_verification: 0.0
            resource_boundaries: 0.0
            behavioral_consistency: 0.0
            cascading_impact: 0.0
            stakeholder_impact: 0.0
            incident_detection: 0.0
            isolation_integrity: 0.0
            temporal_compliance: 0.0
            precedent_alignment: 0.0
            transparency: 0.0
            human_override: 0.0
            ethical_alignment: 0.0
          vetoes: []

        thresholds:
          allow: 0.75
          deny: 0.35

        trust:
          success_increment: 0.01
          violation_decrement: 0.05
          interrupt_cost: 0.04
          decay_rate: 0.001
          floor: 0.05
          ceiling: 0.95
    """)


def _org_yaml() -> str:
    """A valid org config YAML string."""
    return textwrap.dedent("""\
        org_name: "Acme Corp"

        minimum_weights:
          scope_compliance: 1.5
          authority_verification: 1.5
          human_override: 2.0

        required_vetoes:
          - scope_compliance
          - human_override

        minimum_allow_threshold: 0.70
        minimum_deny_threshold: 0.25

        trust:
          minimum_violation_decrement: 0.05
          maximum_success_increment: 0.02
    """)


def _org_violating_yaml() -> str:
    """An agent config that violates org policy (weights too low)."""
    return textwrap.dedent("""\
        version: "1.0"

        agents:
          weak-agent:
            scope:
              actions: [read]
              targets: [data]
              boundaries: [data]

        dimensions:
          weights:
            scope_compliance: 0.5
            authority_verification: 0.5
            resource_boundaries: 1.0
            behavioral_consistency: 1.0
            cascading_impact: 1.0
            stakeholder_impact: 1.0
            incident_detection: 1.0
            isolation_integrity: 1.0
            temporal_compliance: 1.0
            precedent_alignment: 1.0
            transparency: 1.0
            human_override: 0.5
            ethical_alignment: 1.0
          vetoes:
            - scope_compliance
            - human_override

        thresholds:
          allow: 0.75
          deny: 0.30

        trust:
          success_increment: 0.008
          violation_decrement: 0.06
          interrupt_cost: 0.04
          decay_rate: 0.001
          floor: 0.05
          ceiling: 0.93
    """)


def _write_file(tmp_path: Path, filename: str, content: str) -> Path:
    """Write content to a file in tmp_path, return path."""
    p = tmp_path / filename
    p.write_text(content, encoding="utf-8")
    return p


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


class TestValidateCommand:
    """Test ``nomotic validate`` CLI command."""

    def test_valid_config_passes(self, tmp_path, capsys):
        """Valid config → exit code 0, output contains 'PASS'."""
        _write_file(tmp_path, "nomotic.yaml", _valid_yaml())

        with pytest.raises(SystemExit) as exc_info:
            main(["validate", str(tmp_path)])

        assert exc_info.value.code == 0
        captured = capsys.readouterr()
        assert "PASS" in captured.out

    def test_threshold_inversion_fails(self, tmp_path, capsys):
        """Config with threshold inversion → exit code 1, output contains 'FAIL'."""
        _write_file(tmp_path, "nomotic.yaml", _threshold_inverted_yaml())

        with pytest.raises(SystemExit) as exc_info:
            main(["validate", str(tmp_path)])

        assert exc_info.value.code == 1
        captured = capsys.readouterr()
        assert "FAIL" in captured.out

    def test_warnings_no_errors_pass(self, tmp_path, capsys):
        """Config with warnings but no errors → exit code 0."""
        _write_file(tmp_path, "nomotic.yaml", _warning_yaml())

        with pytest.raises(SystemExit) as exc_info:
            main(["validate", str(tmp_path)])

        assert exc_info.value.code == 0
        captured = capsys.readouterr()
        assert "PASS" in captured.out
        assert "warning" in captured.out.lower()

    def test_warnings_strict_fails(self, tmp_path, capsys):
        """Config with warnings and --strict → exit code 1."""
        _write_file(tmp_path, "nomotic.yaml", _warning_yaml())

        with pytest.raises(SystemExit) as exc_info:
            main(["validate", "--strict", str(tmp_path)])

        assert exc_info.value.code == 1
        captured = capsys.readouterr()
        assert "FAIL" in captured.out

    def test_json_output(self, tmp_path, capsys):
        """--json produces valid JSON output."""
        _write_file(tmp_path, "nomotic.yaml", _valid_yaml())

        with pytest.raises(SystemExit) as exc_info:
            main(["validate", "--json", str(tmp_path)])

        assert exc_info.value.code == 0
        captured = capsys.readouterr()
        data = json.loads(captured.out)
        assert data["status"] == "pass"
        assert isinstance(data["errors"], list)
        assert isinstance(data["warnings"], list)
        assert isinstance(data["info"], list)
        assert isinstance(data["presets_applied"], list)

    def test_preset_hipaa_aligned_applies(self, tmp_path, capsys):
        """--preset hipaa_aligned applies preset before validation."""
        # Use a minimal config without extends
        _write_file(tmp_path, "nomotic.yaml", _valid_yaml())

        with pytest.raises(SystemExit) as exc_info:
            main(["validate", "--preset", "hipaa_aligned", "--json", str(tmp_path)])

        assert exc_info.value.code == 0
        captured = capsys.readouterr()
        data = json.loads(captured.out)
        assert "hipaa_aligned" in data["presets_applied"]

    def test_preset_invalid_name_fails(self, tmp_path, capsys):
        """--preset HIPAA fails with helpful error suggesting hipaa_aligned."""
        _write_file(tmp_path, "nomotic.yaml", _valid_yaml())

        with pytest.raises(SystemExit) as exc_info:
            main(["validate", "--preset", "HIPAA", "--json", str(tmp_path)])

        assert exc_info.value.code == 1
        captured = capsys.readouterr()
        data = json.loads(captured.out)
        assert data["status"] == "fail"
        # Check that there's a suggestion for hipaa_aligned
        error_messages = " ".join(e["message"] for e in data["errors"])
        assert "hipaa_aligned" in error_messages

    def test_org_config_compliance(self, tmp_path, capsys):
        """--org loads specific org config and checks compliance."""
        _write_file(tmp_path, "nomotic.yaml", _valid_yaml())
        org_file = _write_file(tmp_path, "nomotic-org.yaml", _org_yaml())

        with pytest.raises(SystemExit) as exc_info:
            main(["validate", "--org", str(org_file), "--json", str(tmp_path)])

        assert exc_info.value.code == 0
        captured = capsys.readouterr()
        data = json.loads(captured.out)
        assert data["org_compliant"] is True

    def test_missing_file_exit_2(self, tmp_path, capsys):
        """Missing file → exit code 2."""
        nonexistent = str(tmp_path / "nonexistent")

        with pytest.raises(SystemExit) as exc_info:
            main(["validate", nonexistent])

        assert exc_info.value.code == 2

    def test_invalid_yaml_syntax_exit_2(self, tmp_path, capsys):
        """Invalid YAML syntax → exit code 2."""
        _write_file(tmp_path, "nomotic.yaml", "{ invalid: yaml: content: [}")

        with pytest.raises(SystemExit) as exc_info:
            main(["validate", str(tmp_path)])

        assert exc_info.value.code == 2

    def test_extends_invalid_name_fails_with_suggestion(self, tmp_path, capsys):
        """Config with extends: 'HIPAA' fails with suggestion to use hipaa_aligned."""
        _write_file(tmp_path, "nomotic.yaml", _bad_extends_yaml())

        with pytest.raises(SystemExit) as exc_info:
            main(["validate", "--json", str(tmp_path)])

        assert exc_info.value.code == 1
        captured = capsys.readouterr()
        data = json.loads(captured.out)
        assert data["status"] == "fail"
        error_messages = " ".join(e["message"] for e in data["errors"])
        assert "hipaa_aligned" in error_messages

    def test_org_policy_violation(self, tmp_path, capsys):
        """Org policy violation → error."""
        _write_file(tmp_path, "nomotic.yaml", _org_violating_yaml())
        org_file = _write_file(tmp_path, "nomotic-org.yaml", _org_yaml())

        with pytest.raises(SystemExit) as exc_info:
            main(["validate", "--org", str(org_file), "--json", str(tmp_path)])

        assert exc_info.value.code == 1
        captured = capsys.readouterr()
        data = json.loads(captured.out)
        assert data["org_compliant"] is False
        assert len(data["errors"]) > 0

    def test_compliance_preset_disclaimer(self, tmp_path, capsys):
        """Config extending a compliance preset → output includes disclaimer info line."""
        _write_file(tmp_path, "nomotic.yaml", _hipaa_extends_yaml())

        with pytest.raises(SystemExit) as exc_info:
            main(["validate", "--json", str(tmp_path)])

        assert exc_info.value.code == 0
        captured = capsys.readouterr()
        data = json.loads(captured.out)
        info_messages = [i["message"] for i in data["info"]]
        found_disclaimer = any("does not constitute" in m for m in info_messages)
        assert found_disclaimer, f"No disclaimer found in info: {info_messages}"

    def test_severity_preset_no_disclaimer(self, tmp_path, capsys):
        """Config extending a severity preset (strict) → no disclaimer."""
        _write_file(tmp_path, "nomotic.yaml", _strict_extends_yaml())

        with pytest.raises(SystemExit) as exc_info:
            main(["validate", "--json", str(tmp_path)])

        assert exc_info.value.code == 0
        captured = capsys.readouterr()
        data = json.loads(captured.out)
        info_messages = [i["message"] for i in data["info"]]
        found_disclaimer = any("does not constitute" in m for m in info_messages)
        assert not found_disclaimer, f"Unexpected disclaimer in info: {info_messages}"

    def test_simulation_failure_all_zero_weights(self, tmp_path, capsys):
        """Simulation failure (all weights 0.0 and no vetoes) → error."""
        _write_file(tmp_path, "nomotic.yaml", _all_zero_weights_yaml())

        with pytest.raises(SystemExit) as exc_info:
            main(["validate", "--json", str(tmp_path)])

        captured = capsys.readouterr()
        data = json.loads(captured.out)
        # With all zero weights and no vetoes, the out-of-scope action
        # may not be denied — that's a simulation failure
        if data["simulation_passed"] is False:
            assert data["status"] == "fail"
            assert exc_info.value.code == 1
        else:
            # If governance still denies due to scope_compliance dimension
            # internal logic (scope check is deterministic), that's also valid
            assert exc_info.value.code in (0, 1)

    def test_direct_file_path(self, tmp_path, capsys):
        """Can pass direct path to nomotic.yaml file."""
        config_file = _write_file(tmp_path, "nomotic.yaml", _valid_yaml())

        with pytest.raises(SystemExit) as exc_info:
            main(["validate", str(config_file)])

        assert exc_info.value.code == 0
        captured = capsys.readouterr()
        assert "PASS" in captured.out

    def test_quiet_mode(self, tmp_path, capsys):
        """--quiet only outputs errors."""
        _write_file(tmp_path, "nomotic.yaml", _valid_yaml())

        with pytest.raises(SystemExit) as exc_info:
            main(["validate", "--quiet", str(tmp_path)])

        assert exc_info.value.code == 0
        captured = capsys.readouterr()
        # In quiet mode, success messages (✓) should not appear
        # Only PASS/FAIL result line should show
        assert "PASS" in captured.out

    def test_json_missing_file(self, tmp_path, capsys):
        """--json with missing file still outputs valid JSON."""
        nonexistent = str(tmp_path / "nonexistent")

        with pytest.raises(SystemExit) as exc_info:
            main(["validate", "--json", nonexistent])

        assert exc_info.value.code == 2
        captured = capsys.readouterr()
        data = json.loads(captured.out)
        assert data["status"] == "error"
        assert len(data["errors"]) > 0
