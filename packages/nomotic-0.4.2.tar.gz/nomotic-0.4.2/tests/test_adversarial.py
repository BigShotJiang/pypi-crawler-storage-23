"""Tests for the adversarial scenario library."""

import tempfile
from pathlib import Path

from nomotic.adversarial import (
    ADVERSARIAL_SCENARIOS,
    CATEGORIES,
    ActionTestResult,
    AdversarialAction,
    AdversarialRunner,
    AdversarialScenario,
    ExpectedOutcome,
    ScenarioTestResult,
    format_report,
    format_summary,
    get_all_scenarios,
    get_scenarios_by_category,
)
from nomotic.scenarios import ScenarioAction


class TestAdversarialScenarios:
    """Tests for scenario definitions and structure."""

    def test_all_scenarios_valid(self):
        """Every scenario has actions with expected outcomes."""
        scenarios = get_all_scenarios()
        assert len(scenarios) >= 6
        for scenario in scenarios:
            assert len(scenario.phases) > 0
            assert scenario.name
            assert scenario.category
            assert scenario.description
            assert scenario.required_scope
            for phase in scenario.phases:
                assert phase.name
                assert len(phase.actions) > 0
                for action in phase.actions:
                    assert action.expected.verdict in ("ALLOW", "DENY", "ESCALATE")
                    assert action.attack_technique
                    assert action.description

    def test_injection_scenario_structure(self):
        s = ADVERSARIAL_SCENARIOS["prompt_injection_resistance"]()
        assert s.category == "injection"
        assert len(s.phases) == 2
        # Normal phase should expect ALLOW
        assert all(a.expected.verdict == "ALLOW" for a in s.phases[0].actions)
        # Attack phase should expect DENY
        assert all(a.expected.verdict == "DENY" for a in s.phases[1].actions)

    def test_privilege_escalation_structure(self):
        s = ADVERSARIAL_SCENARIOS["privilege_escalation"]()
        assert s.category == "escalation"
        assert len(s.phases) == 2
        # First phase: legitimate
        assert all(a.expected.verdict == "ALLOW" for a in s.phases[0].actions)
        # Second phase: escalation attempts should be denied
        assert all(a.expected.verdict == "DENY" for a in s.phases[1].actions)

    def test_drift_inducement_structure(self):
        s = ADVERSARIAL_SCENARIOS["drift_inducement"]()
        assert s.category == "drift"
        assert len(s.phases) == 4
        # First phase: all normal reads -> ALLOW
        assert all(a.expected.verdict == "ALLOW" for a in s.phases[0].actions)
        # Subsequent phases: boundary pushing -> DENY
        for phase in s.phases[1:]:
            assert all(a.expected.verdict == "DENY" for a in phase.actions)

    def test_trust_manipulation_structure(self):
        s = ADVERSARIAL_SCENARIOS["trust_manipulation"]()
        assert s.category == "trust"
        assert len(s.phases) == 2
        # Trust building phase: all ALLOW
        assert all(a.expected.verdict == "ALLOW" for a in s.phases[0].actions)
        assert len(s.phases[0].actions) == 15
        # Exploitation phase: DENY
        assert all(a.expected.verdict == "DENY" for a in s.phases[1].actions)

    def test_confused_deputy_structure(self):
        s = ADVERSARIAL_SCENARIOS["confused_deputy"]()
        assert s.category == "deputy"
        assert len(s.phases) == 2

    def test_boundary_probing_structure(self):
        s = ADVERSARIAL_SCENARIOS["boundary_probing"]()
        assert s.category == "recon"
        # Should have 4 action_types x 4 targets = 16 probes
        total = sum(len(p.actions) for p in s.phases)
        assert total == 16
        # Exactly 1 should be ALLOW (read x customer_db)
        allowed = [
            a for p in s.phases for a in p.actions
            if a.expected.verdict == "ALLOW"
        ]
        assert len(allowed) == 1
        assert allowed[0].action_type == "read"
        assert allowed[0].target == "customer_db"


class TestCategoryRegistry:
    """Tests for the scenario registry and category lookup."""

    def test_all_scenarios_registered(self):
        assert len(ADVERSARIAL_SCENARIOS) >= 6

    def test_all_categories_have_scenarios(self):
        for cat, names in CATEGORIES.items():
            assert len(names) > 0
            for name in names:
                assert name in ADVERSARIAL_SCENARIOS

    def test_category_filter(self):
        injection = get_scenarios_by_category("injection")
        assert len(injection) >= 1
        assert all(s.category == "injection" for s in injection)

    def test_unknown_category_returns_empty(self):
        result = get_scenarios_by_category("nonexistent")
        assert result == []

    def test_get_all_scenarios(self):
        all_scenarios = get_all_scenarios()
        assert len(all_scenarios) == len(ADVERSARIAL_SCENARIOS)


class TestAdversarialAction:
    """Tests for AdversarialAction methods."""

    def test_to_scenario_action(self):
        action = AdversarialAction(
            action_type="read",
            target="customer_db",
            parameters={"table": "customers"},
            description="test",
            attack_technique="none",
            expected=ExpectedOutcome("ALLOW", [], 0.01, "test"),
        )
        sa = action.to_scenario_action()
        assert isinstance(sa, ScenarioAction)
        assert sa.action_type == "read"
        assert sa.target == "customer_db"
        assert sa.parameters == {"table": "customers"}


class TestAdversarialRunner:
    """Tests for running adversarial scenarios against the governance engine."""

    def test_runner_injection_scenario(self):
        """Runner correctly evaluates injection scenario."""
        with tempfile.TemporaryDirectory() as tmp:
            runner = AdversarialRunner(base_dir=Path(tmp), agent_id="test-agent")
            scenario = ADVERSARIAL_SCENARIOS["prompt_injection_resistance"]()
            result = runner.run_scenario(scenario)

            assert result.scenario_name == "prompt_injection_resistance"
            assert result.category == "injection"
            assert result.total_actions == 5
            assert len(result.action_results) == 5

            # Normal actions should be allowed
            for ar in result.action_results[:2]:
                assert ar.actual_verdict == "ALLOW"
            # Attack actions should be denied
            for ar in result.action_results[2:]:
                assert ar.actual_verdict == "DENY"

    def test_runner_privilege_escalation(self):
        """Runner correctly evaluates privilege escalation scenario."""
        with tempfile.TemporaryDirectory() as tmp:
            runner = AdversarialRunner(base_dir=Path(tmp), agent_id="test-agent")
            scenario = ADVERSARIAL_SCENARIOS["privilege_escalation"]()
            result = runner.run_scenario(scenario)

            assert result.scenario_name == "privilege_escalation"
            assert result.total_actions == 4
            # Legitimate read should be allowed
            assert result.action_results[0].actual_verdict == "ALLOW"
            # Escalation attempts should be denied
            for ar in result.action_results[1:]:
                assert ar.actual_verdict == "DENY"

    def test_runner_boundary_probing(self):
        """Runner correctly evaluates boundary probing scenario."""
        with tempfile.TemporaryDirectory() as tmp:
            runner = AdversarialRunner(base_dir=Path(tmp), agent_id="test-agent")
            scenario = ADVERSARIAL_SCENARIOS["boundary_probing"]()
            result = runner.run_scenario(scenario)

            assert result.total_actions == 16
            # Exactly 1 ALLOW (read x customer_db)
            allowed = [ar for ar in result.action_results if ar.actual_verdict == "ALLOW"]
            assert len(allowed) == 1

    def test_runner_trust_manipulation(self):
        """Runner correctly handles trust building then exploitation."""
        with tempfile.TemporaryDirectory() as tmp:
            runner = AdversarialRunner(base_dir=Path(tmp), agent_id="test-agent")
            scenario = ADVERSARIAL_SCENARIOS["trust_manipulation"]()
            result = runner.run_scenario(scenario)

            assert result.total_actions == 16
            # Last action (exploitation) should be denied regardless of trust
            assert result.action_results[-1].actual_verdict == "DENY"

    def test_run_all(self):
        """Runner can execute all scenarios without error."""
        with tempfile.TemporaryDirectory() as tmp:
            runner = AdversarialRunner(base_dir=Path(tmp), agent_id="test-agent")
            results = runner.run_all()
            assert len(results) == len(ADVERSARIAL_SCENARIOS)
            for r in results:
                assert r.total_actions > 0
                assert len(r.action_results) == r.total_actions

    def test_run_category(self):
        """Runner can filter by category."""
        with tempfile.TemporaryDirectory() as tmp:
            runner = AdversarialRunner(base_dir=Path(tmp), agent_id="test-agent")
            results = runner.run_category("injection")
            assert len(results) == 1
            assert results[0].category == "injection"

    def test_run_empty_category(self):
        """Running an unknown category returns empty results."""
        with tempfile.TemporaryDirectory() as tmp:
            runner = AdversarialRunner(base_dir=Path(tmp), agent_id="test-agent")
            results = runner.run_category("nonexistent")
            assert results == []

    def test_result_trust_tracking(self):
        """Trust values are tracked for each action."""
        with tempfile.TemporaryDirectory() as tmp:
            runner = AdversarialRunner(base_dir=Path(tmp), agent_id="test-agent")
            scenario = ADVERSARIAL_SCENARIOS["privilege_escalation"]()
            result = runner.run_scenario(scenario)

            for ar in result.action_results:
                assert 0.0 <= ar.trust_before <= 1.0
                assert 0.0 <= ar.trust_after <= 1.0
                assert 0.0 <= ar.ucs <= 1.0

    def test_result_correctness_counts(self):
        """Correct/incorrect counts match action_results."""
        with tempfile.TemporaryDirectory() as tmp:
            runner = AdversarialRunner(base_dir=Path(tmp), agent_id="test-agent")
            scenario = ADVERSARIAL_SCENARIOS["privilege_escalation"]()
            result = runner.run_scenario(scenario)

            passed = sum(1 for ar in result.action_results if ar.passed)
            failed = sum(1 for ar in result.action_results if not ar.passed)
            assert result.correct_verdicts == passed
            assert result.incorrect_verdicts == failed
            assert result.correct_verdicts + result.incorrect_verdicts == result.total_actions


class TestReportFormatting:
    """Tests for report output formatting."""

    def test_format_report(self):
        """format_report produces readable output."""
        with tempfile.TemporaryDirectory() as tmp:
            runner = AdversarialRunner(base_dir=Path(tmp), agent_id="TestBot")
            results = runner.run_all()
            report = format_report(results, "TestBot")

            assert "ADVERSARIAL TEST REPORT" in report
            assert "TestBot" in report
            assert "Scenarios:" in report
            assert "Passed:" in report

    def test_format_summary(self):
        """format_summary produces compact output."""
        with tempfile.TemporaryDirectory() as tmp:
            runner = AdversarialRunner(base_dir=Path(tmp), agent_id="TestBot")
            results = runner.run_all()
            summary = format_summary(results, "TestBot")

            assert "Adversarial:" in summary
            assert "scenarios passed" in summary

    def test_format_report_with_failures(self):
        """Report includes failure details when scenarios fail."""
        # Create a result with a failure
        result = ScenarioTestResult(
            scenario_name="test_scenario",
            category="test",
            passed=False,
            total_actions=2,
            correct_verdicts=1,
            incorrect_verdicts=1,
            action_results=[
                ActionTestResult(
                    action_description="Good action",
                    attack_technique="none",
                    expected_verdict="ALLOW",
                    actual_verdict="ALLOW",
                    expected_caught_by=[],
                    actual_caught_by=[],
                    passed=True,
                    trust_before=0.5,
                    trust_after=0.51,
                    ucs=0.8,
                    failure_reason="",
                ),
                ActionTestResult(
                    action_description="Bad action",
                    attack_technique="boundary_probe",
                    expected_verdict="DENY",
                    actual_verdict="ALLOW",
                    expected_caught_by=["isolation_integrity"],
                    actual_caught_by=[],
                    passed=False,
                    trust_before=0.51,
                    trust_after=0.52,
                    ucs=0.72,
                    failure_reason="Expected DENY but got ALLOW (UCS 0.720)",
                ),
            ],
        )
        report = format_report([result], "TestBot")
        assert "Failures" in report
        assert "Bad action" in report
        assert "Expected DENY but got ALLOW" in report
