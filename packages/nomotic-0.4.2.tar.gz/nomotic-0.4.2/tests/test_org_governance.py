"""Tests for nomotic.org_governance — org-level governance with override protection."""

from __future__ import annotations

import textwrap
from pathlib import Path

import pytest

from nomotic.config_loader import (
    GovernanceConfig,
    load_governance_config_from_string,
)
from nomotic.org_governance import (
    OrgGovernanceConfig,
    OrgViolation,
    enforce_org_policy,
    generate_org_config_from_preset,
    load_org_config,
    save_org_config,
)
from nomotic.presets import get_preset


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _org_yaml() -> str:
    """A valid org config YAML string."""
    return textwrap.dedent("""\
        org_name: "Acme Corp"

        minimum_weights:
          scope_compliance: 1.5
          authority_verification: 1.5
          human_override: 2.0
          ethical_alignment: 2.0

        required_vetoes:
          - scope_compliance
          - authority_verification
          - human_override

        minimum_allow_threshold: 0.70
        minimum_deny_threshold: 0.30

        trust:
          minimum_violation_decrement: 0.05
          maximum_success_increment: 0.02

        required_frameworks: []
    """)


def _compliant_agent_yaml() -> str:
    """An agent config that meets all org requirements."""
    return textwrap.dedent("""\
        version: "1.0"
        extends: "hipaa_aligned"

        agents:
          compliant-agent:
            scope:
              actions: [read, write]
              targets: [patient_records]
              boundaries: [patient_records]

        dimensions:
          weights:
            scope_compliance: 2.0
            authority_verification: 1.5
            human_override: 2.0
            ethical_alignment: 2.0
          vetoes:
            - scope_compliance
            - authority_verification
            - human_override
            - ethical_alignment
            - isolation_integrity
            - stakeholder_impact

        thresholds:
          allow: 0.80
          deny: 0.30

        trust:
          success_increment: 0.005
          violation_decrement: 0.08
          interrupt_cost: 0.04
          decay_rate: 0.001
          floor: 0.05
          ceiling: 0.92

        compliance:
          frameworks: [HIPAA]
    """)


def _org_config() -> OrgGovernanceConfig:
    """Build a standard org config for tests."""
    return OrgGovernanceConfig(
        org_name="Acme Corp",
        minimum_weights={
            "scope_compliance": 1.5,
            "authority_verification": 1.5,
            "human_override": 2.0,
            "ethical_alignment": 2.0,
        },
        required_vetoes=["scope_compliance", "authority_verification", "human_override"],
        minimum_allow_threshold=0.70,
        minimum_deny_threshold=0.30,
        minimum_violation_decrement=0.05,
        maximum_success_increment=0.02,
        allowed_presets=None,
        required_frameworks=[],
        source_path="",
    )


def _compliant_agent_config() -> GovernanceConfig:
    """Build a compliant agent config."""
    return load_governance_config_from_string(_compliant_agent_yaml())


# ---------------------------------------------------------------------------
# Test: Load a valid org config YAML
# ---------------------------------------------------------------------------

class TestLoadOrgConfig:
    """Tests for load_org_config."""

    def test_load_valid_org_config_from_explicit_path(self, tmp_path: Path) -> None:
        """Load a valid org config YAML from an explicit path."""
        config_path = tmp_path / "nomotic-org.yaml"
        config_path.write_text(_org_yaml(), encoding="utf-8")

        config = load_org_config(config_path)
        assert config is not None
        assert config.org_name == "Acme Corp"
        assert config.minimum_weights["scope_compliance"] == 1.5
        assert config.minimum_weights["authority_verification"] == 1.5
        assert config.minimum_weights["human_override"] == 2.0
        assert config.minimum_weights["ethical_alignment"] == 2.0
        assert "scope_compliance" in config.required_vetoes
        assert "authority_verification" in config.required_vetoes
        assert "human_override" in config.required_vetoes
        assert config.minimum_allow_threshold == 0.70
        assert config.minimum_deny_threshold == 0.30
        assert config.minimum_violation_decrement == 0.05
        assert config.maximum_success_increment == 0.02
        assert config.allowed_presets is None
        assert config.required_frameworks == []
        assert str(config_path) in config.source_path

    def test_load_org_config_returns_none_when_not_found(self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
        """load_org_config() returns None when no org config exists."""
        # Point cwd to a temp dir with no org config
        monkeypatch.chdir(tmp_path)
        # Also ensure no ~/.nomotic/org-governance.yaml
        monkeypatch.setattr(Path, "home", lambda: tmp_path / "fake_home")
        config = load_org_config()
        assert config is None

    def test_load_org_config_explicit_path_not_found(self, tmp_path: Path) -> None:
        """load_org_config raises FileNotFoundError for missing explicit path."""
        with pytest.raises(FileNotFoundError):
            load_org_config(tmp_path / "nonexistent.yaml")

    def test_load_org_config_walks_up_directory(self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
        """load_org_config finds config by walking up from cwd."""
        # Place config in parent dir
        config_path = tmp_path / "nomotic-org.yaml"
        config_path.write_text(_org_yaml(), encoding="utf-8")

        # Set cwd to a subdirectory
        subdir = tmp_path / "sub" / "deep"
        subdir.mkdir(parents=True)
        monkeypatch.chdir(subdir)
        # Ensure no home config interferes
        monkeypatch.setattr(Path, "home", lambda: tmp_path / "fake_home")

        config = load_org_config()
        assert config is not None
        assert config.org_name == "Acme Corp"

    def test_load_org_config_with_allowed_presets(self, tmp_path: Path) -> None:
        """Load org config that includes allowed_presets."""
        yaml_content = textwrap.dedent("""\
            org_name: "Restricted Corp"
            minimum_weights: {}
            required_vetoes: []
            minimum_allow_threshold: 0.70
            minimum_deny_threshold: 0.30
            trust:
              minimum_violation_decrement: 0.05
              maximum_success_increment: 0.02
            allowed_presets: [hipaa_aligned, soc2_aligned, strict, ultra_strict]
            required_frameworks: [HIPAA, SOC2]
        """)
        config_path = tmp_path / "nomotic-org.yaml"
        config_path.write_text(yaml_content, encoding="utf-8")

        config = load_org_config(config_path)
        assert config is not None
        assert config.allowed_presets == ["hipaa_aligned", "soc2_aligned", "strict", "ultra_strict"]
        assert config.required_frameworks == ["HIPAA", "SOC2"]


# ---------------------------------------------------------------------------
# Test: enforce_org_policy — compliant agent
# ---------------------------------------------------------------------------

class TestEnforceOrgPolicyCompliant:
    """Agent config that meets all org requirements → 0 violations."""

    def test_compliant_agent_no_violations(self) -> None:
        """A fully compliant agent should produce zero violations."""
        org = _org_config()
        agent = _compliant_agent_config()
        violations = enforce_org_policy(agent, org)
        assert violations == []

    def test_stricter_agent_still_compliant(self) -> None:
        """An agent that is stricter than org minimums is still compliant."""
        org = _org_config()
        # Use ultra_strict which exceeds all typical org minimums
        agent = load_governance_config_from_string(textwrap.dedent("""\
            version: "1.0"
            extends: "ultra_strict"

            agents:
              strict-agent:
                scope:
                  actions: [read]
                  targets: [data]
                  boundaries: [data]

            trust:
              success_increment: 0.003
              violation_decrement: 0.10
              interrupt_cost: 0.05
              decay_rate: 0.002
              floor: 0.05
              ceiling: 0.88
        """))
        violations = enforce_org_policy(agent, org)
        assert violations == []


# ---------------------------------------------------------------------------
# Test: Individual violation types
# ---------------------------------------------------------------------------

class TestEnforceOrgPolicyViolations:
    """Tests for each type of violation detected by enforce_org_policy."""

    def test_weight_below_org_minimum(self) -> None:
        """Agent with weight below org minimum → violation."""
        org = _org_config()
        agent = load_governance_config_from_string(textwrap.dedent("""\
            version: "1.0"
            extends: "hipaa_aligned"

            agents:
              under-weight-agent:
                scope:
                  actions: [read]
                  targets: [data]
                  boundaries: [data]

            dimensions:
              weights:
                scope_compliance: 1.0
              vetoes:
                - scope_compliance
                - authority_verification
                - human_override
                - ethical_alignment

            thresholds:
              allow: 0.80
              deny: 0.30

            trust:
              success_increment: 0.005
              violation_decrement: 0.08
              interrupt_cost: 0.04
              decay_rate: 0.001
              floor: 0.05
              ceiling: 0.92
        """))
        violations = enforce_org_policy(agent, org)
        weight_violations = [v for v in violations if "scope_compliance" in v.field and "weight" in v.field]
        assert len(weight_violations) == 1
        assert weight_violations[0].severity == "critical"
        assert "1.5" in weight_violations[0].requirement
        assert "1.0" in weight_violations[0].actual

    def test_missing_required_veto(self) -> None:
        """Agent missing a required veto → violation."""
        org = _org_config()
        agent = load_governance_config_from_string(textwrap.dedent("""\
            version: "1.0"
            extends: "hipaa_aligned"

            agents:
              missing-veto-agent:
                scope:
                  actions: [read]
                  targets: [data]
                  boundaries: [data]

            dimensions:
              vetoes:
                - scope_compliance
                - human_override

            thresholds:
              allow: 0.80
              deny: 0.30

            trust:
              success_increment: 0.005
              violation_decrement: 0.08
              interrupt_cost: 0.04
              decay_rate: 0.001
              floor: 0.05
              ceiling: 0.92
        """))
        violations = enforce_org_policy(agent, org)
        veto_violations = [v for v in violations if "vetoes" in v.field]
        assert len(veto_violations) == 1
        assert "authority_verification" in veto_violations[0].field

    def test_allow_threshold_below_org_minimum(self) -> None:
        """Agent with allow_threshold below org minimum → violation."""
        org = _org_config()
        agent = load_governance_config_from_string(textwrap.dedent("""\
            version: "1.0"

            agents:
              low-threshold-agent:
                scope:
                  actions: [read]
                  targets: [data]
                  boundaries: [data]

            dimensions:
              weights:
                scope_compliance: 2.0
                authority_verification: 2.0
                human_override: 2.0
                ethical_alignment: 2.0
              vetoes:
                - scope_compliance
                - authority_verification
                - human_override

            thresholds:
              allow: 0.60
              deny: 0.30

            trust:
              success_increment: 0.01
              violation_decrement: 0.05
              interrupt_cost: 0.03
              decay_rate: 0.001
              floor: 0.05
              ceiling: 0.95
        """))
        violations = enforce_org_policy(agent, org)
        threshold_violations = [v for v in violations if "thresholds.allow" in v.field]
        assert len(threshold_violations) == 1
        assert "0.7" in threshold_violations[0].requirement
        assert "0.6" in threshold_violations[0].actual

    def test_deny_threshold_below_org_minimum(self) -> None:
        """Agent with deny_threshold below org minimum → violation."""
        org = OrgGovernanceConfig(
            org_name="Test",
            minimum_weights={},
            required_vetoes=[],
            minimum_allow_threshold=0.70,
            minimum_deny_threshold=0.35,
            minimum_violation_decrement=0.0,
            maximum_success_increment=1.0,
        )
        agent = load_governance_config_from_string(textwrap.dedent("""\
            version: "1.0"

            agents:
              low-deny-agent:
                scope:
                  actions: [read]
                  targets: [data]
                  boundaries: [data]

            thresholds:
              allow: 0.80
              deny: 0.30

            trust:
              success_increment: 0.01
              violation_decrement: 0.05
              interrupt_cost: 0.03
              decay_rate: 0.001
              floor: 0.05
              ceiling: 0.95
        """))
        violations = enforce_org_policy(agent, org)
        deny_violations = [v for v in violations if "thresholds.deny" in v.field]
        assert len(deny_violations) == 1
        assert "0.35" in deny_violations[0].requirement

    def test_violation_decrement_below_org_minimum(self) -> None:
        """Agent with violation_decrement below org minimum → violation."""
        org = _org_config()
        agent = load_governance_config_from_string(textwrap.dedent("""\
            version: "1.0"

            agents:
              low-decrement-agent:
                scope:
                  actions: [read]
                  targets: [data]
                  boundaries: [data]

            dimensions:
              weights:
                scope_compliance: 2.0
                authority_verification: 2.0
                human_override: 2.0
                ethical_alignment: 2.0
              vetoes:
                - scope_compliance
                - authority_verification
                - human_override

            thresholds:
              allow: 0.80
              deny: 0.30

            trust:
              success_increment: 0.01
              violation_decrement: 0.03
              interrupt_cost: 0.03
              decay_rate: 0.001
              floor: 0.05
              ceiling: 0.95
        """))
        violations = enforce_org_policy(agent, org)
        trust_violations = [v for v in violations if "violation_decrement" in v.field]
        assert len(trust_violations) == 1
        assert "0.05" in trust_violations[0].requirement
        assert "0.03" in trust_violations[0].actual

    def test_success_increment_above_org_maximum(self) -> None:
        """Agent with success_increment above org maximum → violation."""
        org = _org_config()
        agent = load_governance_config_from_string(textwrap.dedent("""\
            version: "1.0"

            agents:
              fast-trust-agent:
                scope:
                  actions: [read]
                  targets: [data]
                  boundaries: [data]

            dimensions:
              weights:
                scope_compliance: 2.0
                authority_verification: 2.0
                human_override: 2.0
                ethical_alignment: 2.0
              vetoes:
                - scope_compliance
                - authority_verification
                - human_override

            thresholds:
              allow: 0.80
              deny: 0.30

            trust:
              success_increment: 0.05
              violation_decrement: 0.08
              interrupt_cost: 0.03
              decay_rate: 0.001
              floor: 0.05
              ceiling: 0.95
        """))
        violations = enforce_org_policy(agent, org)
        trust_violations = [v for v in violations if "success_increment" in v.field]
        assert len(trust_violations) == 1
        assert "0.02" in trust_violations[0].requirement
        assert "0.05" in trust_violations[0].actual

    def test_preset_not_in_allowed_list(self) -> None:
        """Agent using a preset not in allowed_presets → violation."""
        org = OrgGovernanceConfig(
            org_name="Restricted Corp",
            minimum_weights={},
            required_vetoes=[],
            minimum_allow_threshold=0.0,
            minimum_deny_threshold=0.0,
            minimum_violation_decrement=0.0,
            maximum_success_increment=1.0,
            allowed_presets=["hipaa_aligned", "soc2_aligned"],
        )
        agent = load_governance_config_from_string(textwrap.dedent("""\
            version: "1.0"
            extends: "standard"

            agents:
              wrong-preset-agent:
                scope:
                  actions: [read]
                  targets: [data]
                  boundaries: [data]
        """))
        violations = enforce_org_policy(agent, org)
        preset_violations = [v for v in violations if "extends" in v.field]
        assert len(preset_violations) == 1
        assert "standard" in preset_violations[0].actual

    def test_missing_required_compliance_framework(self) -> None:
        """Agent missing required compliance framework → violation."""
        org = OrgGovernanceConfig(
            org_name="Compliant Corp",
            minimum_weights={},
            required_vetoes=[],
            minimum_allow_threshold=0.0,
            minimum_deny_threshold=0.0,
            minimum_violation_decrement=0.0,
            maximum_success_increment=1.0,
            required_frameworks=["HIPAA", "SOC2"],
        )
        # Agent only declares HIPAA, missing SOC2
        agent = load_governance_config_from_string(textwrap.dedent("""\
            version: "1.0"

            agents:
              partial-compliance-agent:
                scope:
                  actions: [read]
                  targets: [data]
                  boundaries: [data]

            thresholds:
              allow: 0.75
              deny: 0.35

            trust:
              success_increment: 0.01
              violation_decrement: 0.05
              interrupt_cost: 0.03
              decay_rate: 0.001
              floor: 0.05
              ceiling: 0.95

            compliance:
              frameworks: [HIPAA]
        """))
        violations = enforce_org_policy(agent, org)
        framework_violations = [v for v in violations if "frameworks" in v.field]
        assert len(framework_violations) == 1
        assert "SOC2" in framework_violations[0].field


# ---------------------------------------------------------------------------
# Test: Multiple violations detected simultaneously
# ---------------------------------------------------------------------------

class TestMultipleViolations:
    """Multiple violations detected simultaneously."""

    def test_multiple_violations_at_once(self) -> None:
        """An agent that violates multiple org policies should report all violations."""
        org = OrgGovernanceConfig(
            org_name="Strict Corp",
            minimum_weights={
                "scope_compliance": 1.5,
                "human_override": 2.0,
            },
            required_vetoes=["scope_compliance", "human_override"],
            minimum_allow_threshold=0.80,
            minimum_deny_threshold=0.35,
            minimum_violation_decrement=0.08,
            maximum_success_increment=0.005,
            allowed_presets=["hipaa_aligned"],
            required_frameworks=["HIPAA"],
        )
        # Agent violates everything
        agent = load_governance_config_from_string(textwrap.dedent("""\
            version: "1.0"
            extends: "standard"

            agents:
              bad-agent:
                scope:
                  actions: [read]
                  targets: [data]
                  boundaries: [data]

            dimensions:
              weights:
                scope_compliance: 1.0
                human_override: 1.0
              vetoes:
                - scope_compliance

            thresholds:
              allow: 0.70
              deny: 0.30

            trust:
              success_increment: 0.01
              violation_decrement: 0.05
              interrupt_cost: 0.03
              decay_rate: 0.001
              floor: 0.05
              ceiling: 0.95
        """))
        violations = enforce_org_policy(agent, org)

        # Should have violations for:
        # 1. scope_compliance weight below 1.5
        # 2. human_override weight below 2.0
        # 3. missing veto: human_override
        # 4. allow_threshold below 0.80
        # 5. deny_threshold below 0.35
        # 6. violation_decrement below 0.08
        # 7. success_increment above 0.005
        # 8. preset "standard" not in allowed_presets
        # 9. missing framework "HIPAA"
        assert len(violations) >= 9

        # All should be critical
        assert all(v.severity == "critical" for v in violations)

        # Verify specific violation types exist
        fields = [v.field for v in violations]
        assert any("dimensions.weights.scope_compliance" in f for f in fields)
        assert any("dimensions.weights.human_override" in f for f in fields)
        assert any("vetoes.human_override" in f for f in fields)
        assert any("thresholds.allow" in f for f in fields)
        assert any("thresholds.deny" in f for f in fields)
        assert any("violation_decrement" in f for f in fields)
        assert any("success_increment" in f for f in fields)
        assert any("extends" in f for f in fields)
        assert any("frameworks" in f for f in fields)


# ---------------------------------------------------------------------------
# Test: save_org_config round-trip
# ---------------------------------------------------------------------------

class TestSaveOrgConfig:
    """save_org_config writes valid YAML that can be loaded back."""

    def test_save_and_reload(self, tmp_path: Path) -> None:
        """Save an org config and load it back — values should match."""
        original = OrgGovernanceConfig(
            org_name="Round Trip Corp",
            minimum_weights={
                "scope_compliance": 1.5,
                "authority_verification": 1.8,
                "human_override": 2.0,
                "ethical_alignment": 2.0,
            },
            required_vetoes=["scope_compliance", "authority_verification", "human_override"],
            minimum_allow_threshold=0.75,
            minimum_deny_threshold=0.35,
            minimum_violation_decrement=0.07,
            maximum_success_increment=0.01,
            allowed_presets=["hipaa_aligned", "strict"],
            required_frameworks=["HIPAA"],
            source_path="",
        )
        save_path = tmp_path / "nomotic-org.yaml"
        save_org_config(original, save_path)

        # Verify file was written
        assert save_path.exists()

        # Load it back
        loaded = load_org_config(save_path)
        assert loaded is not None
        assert loaded.org_name == original.org_name
        assert loaded.minimum_weights == original.minimum_weights
        assert loaded.required_vetoes == original.required_vetoes
        assert loaded.minimum_allow_threshold == original.minimum_allow_threshold
        assert loaded.minimum_deny_threshold == original.minimum_deny_threshold
        assert loaded.minimum_violation_decrement == original.minimum_violation_decrement
        assert loaded.maximum_success_increment == original.maximum_success_increment
        assert loaded.allowed_presets == original.allowed_presets
        assert loaded.required_frameworks == original.required_frameworks

    def test_save_minimal_config(self, tmp_path: Path) -> None:
        """Save a minimal org config with no optional fields."""
        minimal = OrgGovernanceConfig(
            org_name="Minimal Corp",
            minimum_weights={},
            required_vetoes=[],
            minimum_allow_threshold=0.70,
            minimum_deny_threshold=0.30,
            minimum_violation_decrement=0.05,
            maximum_success_increment=0.02,
        )
        save_path = tmp_path / "org.yaml"
        save_org_config(minimal, save_path)

        loaded = load_org_config(save_path)
        assert loaded is not None
        assert loaded.org_name == "Minimal Corp"
        assert loaded.minimum_weights == {}
        assert loaded.required_vetoes == []
        assert loaded.allowed_presets is None
        assert loaded.required_frameworks == []


# ---------------------------------------------------------------------------
# Test: generate_org_config_from_preset
# ---------------------------------------------------------------------------

class TestGenerateOrgConfigFromPreset:
    """generate_org_config_from_preset creates sensible minimums."""

    def test_generate_from_hipaa_aligned(self) -> None:
        """Generate org config from hipaa_aligned preset."""
        config = generate_org_config_from_preset("Acme", "hipaa_aligned")
        preset = get_preset("hipaa_aligned")

        assert config.org_name == "Acme"
        assert config.minimum_weights == dict(preset.dimension_weights)
        assert config.required_vetoes == list(preset.veto_dimensions)
        assert config.minimum_allow_threshold == preset.allow_threshold
        assert config.minimum_deny_threshold == preset.deny_threshold
        assert config.minimum_violation_decrement == preset.trust_settings["violation_decrement"]
        assert config.maximum_success_increment == preset.trust_settings["success_increment"]
        assert config.allowed_presets is None
        assert config.required_frameworks == []

    def test_generate_from_strict(self) -> None:
        """Generate org config from strict preset."""
        config = generate_org_config_from_preset("Acme", "strict")
        preset = get_preset("strict")

        assert config.minimum_allow_threshold == preset.allow_threshold
        assert config.minimum_deny_threshold == preset.deny_threshold
        assert config.minimum_weights == dict(preset.dimension_weights)

    def test_generate_from_soc2_aligned(self) -> None:
        """Generate org config from soc2_aligned preset."""
        config = generate_org_config_from_preset("Acme", "soc2_aligned")
        preset = get_preset("soc2_aligned")

        assert config.org_name == "Acme"
        assert config.minimum_weights["scope_compliance"] == preset.dimension_weights["scope_compliance"]
        assert config.minimum_violation_decrement == preset.trust_settings["violation_decrement"]

    def test_generate_from_unknown_preset_raises(self) -> None:
        """Unknown preset name raises KeyError."""
        with pytest.raises(KeyError, match="Unknown preset"):
            generate_org_config_from_preset("Acme", "nonexistent")

    def test_generated_config_is_self_consistent(self) -> None:
        """An agent extending the same preset passes enforcement against
        the org config generated from that preset."""
        config = generate_org_config_from_preset("Acme", "hipaa_aligned")

        # Agent that extends hipaa_aligned should be compliant since the
        # org config was generated from exactly that preset
        agent = load_governance_config_from_string(textwrap.dedent("""\
            version: "1.0"
            extends: "hipaa_aligned"

            agents:
              hipaa-agent:
                scope:
                  actions: [read]
                  targets: [data]
                  boundaries: [data]
        """))
        violations = enforce_org_policy(agent, config)
        assert violations == []


# ---------------------------------------------------------------------------
# Test: OrgViolation dataclass
# ---------------------------------------------------------------------------

class TestOrgViolation:
    """Tests for the OrgViolation dataclass."""

    def test_default_severity(self) -> None:
        """OrgViolation defaults to 'critical' severity."""
        v = OrgViolation(
            field="test.field",
            requirement="Required: X",
            actual="Got: Y",
        )
        assert v.severity == "critical"

    def test_explicit_severity(self) -> None:
        """OrgViolation accepts explicit severity."""
        v = OrgViolation(
            field="test.field",
            requirement="Required: X",
            actual="Got: Y",
            severity="critical",
        )
        assert v.severity == "critical"


# ---------------------------------------------------------------------------
# Test: Edge cases
# ---------------------------------------------------------------------------

class TestEdgeCases:
    """Edge cases for org governance enforcement."""

    def test_no_extends_no_allowed_presets_violation(self) -> None:
        """Agent with no extends doesn't trigger allowed_presets violation."""
        org = OrgGovernanceConfig(
            org_name="Test",
            minimum_weights={},
            required_vetoes=[],
            minimum_allow_threshold=0.0,
            minimum_deny_threshold=0.0,
            minimum_violation_decrement=0.0,
            maximum_success_increment=1.0,
            allowed_presets=["hipaa_aligned"],
        )
        agent = load_governance_config_from_string(textwrap.dedent("""\
            version: "1.0"

            agents:
              no-extends-agent:
                scope:
                  actions: [read]
                  targets: [data]
                  boundaries: [data]

            thresholds:
              allow: 0.75
              deny: 0.35

            trust:
              success_increment: 0.01
              violation_decrement: 0.05
              interrupt_cost: 0.03
              decay_rate: 0.001
              floor: 0.05
              ceiling: 0.95
        """))
        violations = enforce_org_policy(agent, org)
        preset_violations = [v for v in violations if "extends" in v.field]
        assert len(preset_violations) == 0

    def test_empty_org_config_no_violations(self) -> None:
        """An org config with no restrictions produces no violations."""
        org = OrgGovernanceConfig(
            org_name="Permissive Corp",
            minimum_weights={},
            required_vetoes=[],
            minimum_allow_threshold=0.0,
            minimum_deny_threshold=0.0,
            minimum_violation_decrement=0.0,
            maximum_success_increment=1.0,
        )
        agent = load_governance_config_from_string(textwrap.dedent("""\
            version: "1.0"

            agents:
              any-agent:
                scope:
                  actions: [read]
                  targets: [data]
                  boundaries: [data]

            thresholds:
              allow: 0.75
              deny: 0.35

            trust:
              success_increment: 0.01
              violation_decrement: 0.05
              interrupt_cost: 0.03
              decay_rate: 0.001
              floor: 0.05
              ceiling: 0.95
        """))
        violations = enforce_org_policy(agent, org)
        assert violations == []

    def test_case_insensitive_preset_matching(self) -> None:
        """Allowed presets comparison is case-insensitive."""
        org = OrgGovernanceConfig(
            org_name="Test",
            minimum_weights={},
            required_vetoes=[],
            minimum_allow_threshold=0.0,
            minimum_deny_threshold=0.0,
            minimum_violation_decrement=0.0,
            maximum_success_increment=1.0,
            allowed_presets=["HIPAA_ALIGNED"],  # uppercase
        )
        agent = load_governance_config_from_string(textwrap.dedent("""\
            version: "1.0"
            extends: "hipaa_aligned"

            agents:
              case-agent:
                scope:
                  actions: [read]
                  targets: [data]
                  boundaries: [data]
        """))
        violations = enforce_org_policy(agent, org)
        preset_violations = [v for v in violations if "extends" in v.field]
        assert len(preset_violations) == 0

    def test_case_insensitive_framework_matching(self) -> None:
        """Required frameworks comparison is case-insensitive."""
        org = OrgGovernanceConfig(
            org_name="Test",
            minimum_weights={},
            required_vetoes=[],
            minimum_allow_threshold=0.0,
            minimum_deny_threshold=0.0,
            minimum_violation_decrement=0.0,
            maximum_success_increment=1.0,
            required_frameworks=["hipaa"],  # lowercase
        )
        agent = load_governance_config_from_string(textwrap.dedent("""\
            version: "1.0"

            agents:
              case-agent:
                scope:
                  actions: [read]
                  targets: [data]
                  boundaries: [data]

            thresholds:
              allow: 0.75
              deny: 0.35

            trust:
              success_increment: 0.01
              violation_decrement: 0.05
              interrupt_cost: 0.03
              decay_rate: 0.001
              floor: 0.05
              ceiling: 0.95

            compliance:
              frameworks: [HIPAA]
        """))
        violations = enforce_org_policy(agent, org)
        framework_violations = [v for v in violations if "frameworks" in v.field]
        assert len(framework_violations) == 0

    def test_weight_at_exact_minimum_is_compliant(self) -> None:
        """Agent weight exactly at org minimum is compliant (>= not >)."""
        org = OrgGovernanceConfig(
            org_name="Test",
            minimum_weights={"scope_compliance": 1.5},
            required_vetoes=[],
            minimum_allow_threshold=0.0,
            minimum_deny_threshold=0.0,
            minimum_violation_decrement=0.0,
            maximum_success_increment=1.0,
        )
        agent = load_governance_config_from_string(textwrap.dedent("""\
            version: "1.0"

            agents:
              exact-agent:
                scope:
                  actions: [read]
                  targets: [data]
                  boundaries: [data]

            dimensions:
              weights:
                scope_compliance: 1.5

            thresholds:
              allow: 0.75
              deny: 0.35

            trust:
              success_increment: 0.01
              violation_decrement: 0.05
              interrupt_cost: 0.03
              decay_rate: 0.001
              floor: 0.05
              ceiling: 0.95
        """))
        violations = enforce_org_policy(agent, org)
        weight_violations = [v for v in violations if "weights" in v.field]
        assert len(weight_violations) == 0
