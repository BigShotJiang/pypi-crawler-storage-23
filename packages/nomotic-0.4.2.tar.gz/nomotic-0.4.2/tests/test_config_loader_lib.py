"""Tests for nomotic.config_loader — YAML governance config loading.

Named ``_lib`` to distinguish from nomotic-ci's ``test_config_loader.py``.
"""

from __future__ import annotations

import os
import textwrap
from pathlib import Path

import pytest

from nomotic.config_loader import (
    AgentDefinition,
    GovernanceConfig,
    load_governance_config,
    load_governance_config_from_string,
    validate_governance_config,
)
from nomotic.presets import DIMENSION_NAMES, get_preset
from nomotic.runtime import GovernanceRuntime, RuntimeConfig
from nomotic.types import Action, AgentContext, TrustProfile, Verdict


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _full_explicit_yaml() -> str:
    """A complete YAML with no extends — all fields explicit."""
    return textwrap.dedent("""\
        version: "1.0"

        agents:
          test-agent:
            scope:
              actions: [read, write, query]
              targets: [customer_records, orders]
              boundaries: [customer_records, orders]
            trust:
              initial: 0.6
              minimum_for_action: 0.25
            owner: "team@company.com"
            reason: "Customer service agent"

        dimensions:
          weights:
            scope_compliance: 2.0
            authority_verification: 1.8
            resource_boundaries: 1.5
            behavioral_consistency: 1.2
            cascading_impact: 1.3
            stakeholder_impact: 1.2
            incident_detection: 2.0
            isolation_integrity: 1.8
            temporal_compliance: 1.0
            precedent_alignment: 0.8
            transparency: 1.5
            human_override: 2.0
            ethical_alignment: 1.5
          vetoes:
            - scope_compliance
            - human_override

        thresholds:
          allow: 0.75
          deny: 0.35

        trust:
          success_increment: 0.008
          violation_decrement: 0.06
          interrupt_cost: 0.04
          decay_rate: 0.001
          floor: 0.05
          ceiling: 0.93

        compliance:
          frameworks: [SOC2, HIPAA]
    """)


def _minimal_extends_yaml(extends: str | list[str] = "hipaa_aligned") -> str:
    """A minimal YAML using extends for everything except agents."""
    if isinstance(extends, list):
        extends_str = "[" + ", ".join(extends) + "]"
    else:
        extends_str = f'"{extends}"'

    return textwrap.dedent(f"""\
        version: "1.0"
        extends: {extends_str}

        agents:
          my-agent:
            scope:
              actions: [read, write]
              targets: [data]
              boundaries: [data]
    """)


# ---------------------------------------------------------------------------
# Test: basic YAML with no extends — all fields explicit
# ---------------------------------------------------------------------------

class TestLoadExplicit:
    def test_load_basic_no_extends(self):
        config = load_governance_config_from_string(_full_explicit_yaml())

        assert config.version == "1.0"
        assert config.extends == []
        assert len(config.agents) == 1

        agent = config.agents[0]
        assert agent.agent_id == "test-agent"
        assert agent.actions == ["read", "write", "query"]
        assert agent.targets == ["customer_records", "orders"]
        assert agent.boundaries == ["customer_records", "orders"]
        assert agent.initial_trust == 0.6
        assert agent.min_trust_for_action == 0.25
        assert agent.owner == "team@company.com"
        assert agent.reason == "Customer service agent"

        assert config.dimension_weights["scope_compliance"] == 2.0
        assert config.dimension_weights["authority_verification"] == 1.8
        assert config.veto_dimensions == ["scope_compliance", "human_override"]
        assert config.allow_threshold == 0.75
        assert config.deny_threshold == 0.35
        assert config.trust_settings["success_increment"] == 0.008
        assert config.trust_settings["violation_decrement"] == 0.06
        assert config.trust_settings["interrupt_cost"] == 0.04
        assert config.compliance_frameworks == ["SOC2", "HIPAA"]

    def test_validation_passes(self):
        config = load_governance_config_from_string(_full_explicit_yaml())
        errors = validate_governance_config(config)
        assert errors == []


# ---------------------------------------------------------------------------
# Test: extends with hipaa_aligned
# ---------------------------------------------------------------------------

class TestExtendsHipaa:
    def test_inherits_from_hipaa(self):
        config = load_governance_config_from_string(
            _minimal_extends_yaml("hipaa_aligned")
        )

        hipaa = get_preset("hipaa_aligned")
        assert config.extends == ["hipaa_aligned"]
        assert config.dimension_weights == dict(hipaa.dimension_weights)
        assert config.veto_dimensions == list(hipaa.veto_dimensions)
        assert config.allow_threshold == hipaa.allow_threshold
        assert config.deny_threshold == hipaa.deny_threshold
        assert config.trust_settings == dict(hipaa.trust_settings)

    def test_validation_passes(self):
        config = load_governance_config_from_string(
            _minimal_extends_yaml("hipaa_aligned")
        )
        errors = validate_governance_config(config)
        assert errors == []


# ---------------------------------------------------------------------------
# Test: extends with case-insensitive name
# ---------------------------------------------------------------------------

class TestExtendsCaseInsensitive:
    def test_uppercase_hipaa_aligned(self):
        config = load_governance_config_from_string(
            _minimal_extends_yaml("HIPAA_ALIGNED")
        )

        hipaa = get_preset("hipaa_aligned")
        # Should produce the same result as lowercase
        assert config.dimension_weights == dict(hipaa.dimension_weights)
        assert config.veto_dimensions == list(hipaa.veto_dimensions)
        assert config.allow_threshold == hipaa.allow_threshold

    def test_mixed_case(self):
        config = load_governance_config_from_string(
            _minimal_extends_yaml("Hipaa_Aligned")
        )
        hipaa = get_preset("hipaa_aligned")
        assert config.dimension_weights == dict(hipaa.dimension_weights)

    def test_validation_passes(self):
        config = load_governance_config_from_string(
            _minimal_extends_yaml("HIPAA_ALIGNED")
        )
        errors = validate_governance_config(config)
        assert errors == []


# ---------------------------------------------------------------------------
# Test: extends list — strict then hipaa_aligned (hipaa overrides strict)
# ---------------------------------------------------------------------------

class TestExtendsMultiple:
    def test_later_preset_overrides_earlier(self):
        config = load_governance_config_from_string(
            _minimal_extends_yaml(["strict", "hipaa_aligned"])
        )

        hipaa = get_preset("hipaa_aligned")
        # hipaa_aligned is last, so it should override strict
        assert config.dimension_weights == dict(hipaa.dimension_weights)
        assert config.veto_dimensions == list(hipaa.veto_dimensions)
        assert config.allow_threshold == hipaa.allow_threshold
        assert config.deny_threshold == hipaa.deny_threshold

    def test_extends_list_preserved(self):
        config = load_governance_config_from_string(
            _minimal_extends_yaml(["strict", "hipaa_aligned"])
        )
        assert config.extends == ["strict", "hipaa_aligned"]


# ---------------------------------------------------------------------------
# Test: extends AND explicit weight overrides — explicit wins
# ---------------------------------------------------------------------------

class TestExtendsWithWeightOverrides:
    def test_explicit_weight_overrides_preset(self):
        yaml_str = textwrap.dedent("""\
            version: "1.0"
            extends: "hipaa_aligned"

            agents:
              my-agent:
                scope:
                  actions: [read]
                  targets: [data]
                  boundaries: [data]

            dimensions:
              weights:
                scope_compliance: 3.0
        """)
        config = load_governance_config_from_string(yaml_str)

        # scope_compliance should be overridden
        assert config.dimension_weights["scope_compliance"] == 3.0

        # Other weights should come from hipaa_aligned
        hipaa = get_preset("hipaa_aligned")
        assert config.dimension_weights["stakeholder_impact"] == hipaa.dimension_weights["stakeholder_impact"]
        assert config.dimension_weights["ethical_alignment"] == hipaa.dimension_weights["ethical_alignment"]

    def test_unspecified_weights_preserved(self):
        yaml_str = textwrap.dedent("""\
            version: "1.0"
            extends: "hipaa_aligned"

            agents:
              my-agent:
                scope:
                  actions: [read]
                  targets: [data]
                  boundaries: [data]

            dimensions:
              weights:
                transparency: 2.5
        """)
        config = load_governance_config_from_string(yaml_str)

        hipaa = get_preset("hipaa_aligned")
        # transparency overridden
        assert config.dimension_weights["transparency"] == 2.5
        # All other 12 dimensions from hipaa
        for dim in DIMENSION_NAMES:
            if dim != "transparency":
                assert config.dimension_weights[dim] == hipaa.dimension_weights[dim]


# ---------------------------------------------------------------------------
# Test: extends AND explicit vetoes — YAML vetoes REPLACE preset vetoes
# ---------------------------------------------------------------------------

class TestExtendsWithVetoOverrides:
    def test_explicit_vetoes_replace_preset(self):
        yaml_str = textwrap.dedent("""\
            version: "1.0"
            extends: "hipaa_aligned"

            agents:
              my-agent:
                scope:
                  actions: [read]
                  targets: [data]
                  boundaries: [data]

            dimensions:
              vetoes:
                - scope_compliance
        """)
        config = load_governance_config_from_string(yaml_str)

        # Vetoes should be ONLY what's in the YAML, not from hipaa
        assert config.veto_dimensions == ["scope_compliance"]

        hipaa = get_preset("hipaa_aligned")
        assert len(hipaa.veto_dimensions) > 1  # hipaa has many vetoes
        # But our config only has the one we specified


# ---------------------------------------------------------------------------
# Test: only agents and extends — everything from preset
# ---------------------------------------------------------------------------

class TestOnlyAgentsAndExtends:
    def test_everything_from_preset(self):
        yaml_str = textwrap.dedent("""\
            version: "1.0"
            extends: "strict"

            agents:
              my-agent:
                scope:
                  actions: [read, write]
                  targets: [data]
                  boundaries: [data]
        """)
        config = load_governance_config_from_string(yaml_str)

        strict = get_preset("strict")
        assert config.dimension_weights == dict(strict.dimension_weights)
        assert config.veto_dimensions == list(strict.veto_dimensions)
        assert config.allow_threshold == strict.allow_threshold
        assert config.deny_threshold == strict.deny_threshold
        assert config.trust_settings == dict(strict.trust_settings)
        assert config.compliance_frameworks == []

    def test_threshold_override_only(self):
        yaml_str = textwrap.dedent("""\
            version: "1.0"
            extends: "strict"

            agents:
              my-agent:
                scope:
                  actions: [read]
                  targets: [data]
                  boundaries: [data]

            thresholds:
              allow: 0.85
        """)
        config = load_governance_config_from_string(yaml_str)

        strict = get_preset("strict")
        # allow overridden
        assert config.allow_threshold == 0.85
        # deny from preset
        assert config.deny_threshold == strict.deny_threshold


# ---------------------------------------------------------------------------
# Test: extends "HIPAA" fails validation with helpful error
# ---------------------------------------------------------------------------

class TestInvalidPresetHIPAA:
    def test_hipaa_fails_with_suggestion(self):
        yaml_str = textwrap.dedent("""\
            version: "1.0"
            extends: "HIPAA"

            agents:
              my-agent:
                scope:
                  actions: [read]
                  targets: [data]
                  boundaries: [data]
        """)
        config = load_governance_config_from_string(yaml_str)
        errors = validate_governance_config(config)

        assert len(errors) >= 1
        # Should mention hipaa_aligned as suggestion
        preset_error = [e for e in errors if "HIPAA" in e][0]
        assert "hipaa_aligned" in preset_error
        assert "Did you mean" in preset_error


# ---------------------------------------------------------------------------
# Test: extends "soc2" fails validation with helpful error
# ---------------------------------------------------------------------------

class TestInvalidPresetSOC2:
    def test_soc2_fails_with_suggestion(self):
        yaml_str = textwrap.dedent("""\
            version: "1.0"
            extends: "soc2"

            agents:
              my-agent:
                scope:
                  actions: [read]
                  targets: [data]
                  boundaries: [data]
        """)
        config = load_governance_config_from_string(yaml_str)
        errors = validate_governance_config(config)

        assert len(errors) >= 1
        preset_error = [e for e in errors if "soc2" in e.lower()][0]
        assert "soc2_aligned" in preset_error


# ---------------------------------------------------------------------------
# Test: validation catches common errors
# ---------------------------------------------------------------------------

class TestValidationErrors:
    def test_missing_version(self):
        yaml_str = textwrap.dedent("""\
            agents:
              my-agent:
                scope:
                  actions: [read]
                  targets: [data]
                  boundaries: [data]
        """)
        config = load_governance_config_from_string(yaml_str)
        errors = validate_governance_config(config)
        assert any("version" in e.lower() for e in errors)

    def test_no_agents(self):
        yaml_str = textwrap.dedent("""\
            version: "1.0"
            extends: "standard"
        """)
        config = load_governance_config_from_string(yaml_str)
        errors = validate_governance_config(config)
        assert any("agent" in e.lower() for e in errors)

    def test_invalid_dimension_name(self):
        yaml_str = textwrap.dedent("""\
            version: "1.0"
            agents:
              my-agent:
                scope:
                  actions: [read]
                  targets: [data]
                  boundaries: [data]
            dimensions:
              weights:
                made_up_dimension: 1.5
        """)
        config = load_governance_config_from_string(yaml_str)
        errors = validate_governance_config(config)
        assert any("made_up_dimension" in e for e in errors)

    def test_invalid_veto_dimension(self):
        yaml_str = textwrap.dedent("""\
            version: "1.0"
            agents:
              my-agent:
                scope:
                  actions: [read]
                  targets: [data]
                  boundaries: [data]
            dimensions:
              vetoes:
                - not_a_real_dimension
        """)
        config = load_governance_config_from_string(yaml_str)
        errors = validate_governance_config(config)
        assert any("not_a_real_dimension" in e for e in errors)

    def test_threshold_inversion(self):
        yaml_str = textwrap.dedent("""\
            version: "1.0"
            agents:
              my-agent:
                scope:
                  actions: [read]
                  targets: [data]
                  boundaries: [data]
            thresholds:
              allow: 0.3
              deny: 0.8
        """)
        config = load_governance_config_from_string(yaml_str)
        errors = validate_governance_config(config)
        assert any("allow_threshold" in e and "deny_threshold" in e for e in errors)

    def test_agent_with_empty_actions(self):
        yaml_str = textwrap.dedent("""\
            version: "1.0"
            agents:
              my-agent:
                scope:
                  actions: []
                  targets: [data]
                  boundaries: [data]
        """)
        config = load_governance_config_from_string(yaml_str)
        errors = validate_governance_config(config)
        assert any("action" in e.lower() and "my-agent" in e for e in errors)


# ---------------------------------------------------------------------------
# Test: load_governance_config finds nomotic.yaml in a directory
# ---------------------------------------------------------------------------

class TestLoadFromDirectory:
    def test_finds_yaml_in_directory(self, tmp_path: Path):
        config_file = tmp_path / "nomotic.yaml"
        config_file.write_text(_full_explicit_yaml())

        config = load_governance_config(tmp_path)
        assert config.version == "1.0"
        assert config.source_path == str(config_file)

    def test_finds_yaml_in_subdirectory(self, tmp_path: Path):
        subdir = tmp_path / "config"
        subdir.mkdir()
        config_file = subdir / "nomotic.yaml"
        config_file.write_text(_full_explicit_yaml())

        config = load_governance_config(tmp_path)
        assert config.source_path == str(config_file)

    def test_finds_yml_extension(self, tmp_path: Path):
        config_file = tmp_path / "nomotic.yml"
        config_file.write_text(_full_explicit_yaml())

        config = load_governance_config(tmp_path)
        assert config.source_path == str(config_file)

    def test_loads_direct_file_path(self, tmp_path: Path):
        config_file = tmp_path / "my-config.yaml"
        config_file.write_text(_full_explicit_yaml())

        config = load_governance_config(config_file)
        assert config.source_path == str(config_file)

    def test_file_not_found(self, tmp_path: Path):
        with pytest.raises(FileNotFoundError):
            load_governance_config(tmp_path)

    def test_nonexistent_path(self):
        with pytest.raises(FileNotFoundError):
            load_governance_config("/nonexistent/path/to/config")

    def test_invalid_config_raises_value_error(self, tmp_path: Path):
        config_file = tmp_path / "nomotic.yaml"
        config_file.write_text(textwrap.dedent("""\
            version: "2.0"
        """))

        with pytest.raises(ValueError, match="Invalid governance config"):
            load_governance_config(tmp_path)


# ---------------------------------------------------------------------------
# Test: load_governance_config_from_string
# ---------------------------------------------------------------------------

class TestLoadFromString:
    def test_works_for_testing(self):
        config = load_governance_config_from_string(_full_explicit_yaml())
        assert config.source_path == "<string>"
        assert config.version == "1.0"

    def test_custom_source_path(self):
        config = load_governance_config_from_string(
            _full_explicit_yaml(), source_path="/test/path.yaml"
        )
        assert config.source_path == "/test/path.yaml"

    def test_raw_dict_preserved(self):
        config = load_governance_config_from_string(_full_explicit_yaml())
        assert isinstance(config.raw, dict)
        assert config.raw["version"] == "1.0"
        assert "agents" in config.raw

    def test_invalid_yaml_raises(self):
        with pytest.raises(ValueError):
            load_governance_config_from_string("not: [valid: yaml: content")


# ---------------------------------------------------------------------------
# Test: to_runtime_config() produces a valid RuntimeConfig
# ---------------------------------------------------------------------------

class TestToRuntimeConfig:
    def test_produces_runtime_config(self):
        config = load_governance_config_from_string(_full_explicit_yaml())
        rc = config.to_runtime_config()

        assert isinstance(rc, RuntimeConfig)
        assert rc.allow_threshold == 0.75
        assert rc.deny_threshold == 0.35
        assert rc.dimension_weights["scope_compliance"] == 2.0
        assert rc.veto_dimensions == ["scope_compliance", "human_override"]

    def test_trust_config_mapped_correctly(self):
        config = load_governance_config_from_string(_full_explicit_yaml())
        rc = config.to_runtime_config()

        assert rc.trust_config.success_increment == 0.008
        assert rc.trust_config.violation_decrement == 0.06
        assert rc.trust_config.interrupt_decrement == 0.04
        assert rc.trust_config.decay_rate == 0.001
        assert rc.trust_config.min_trust == 0.05
        assert rc.trust_config.max_trust == 0.93

    def test_from_preset_round_trip(self):
        yaml_str = _minimal_extends_yaml("hipaa_aligned")
        config = load_governance_config_from_string(yaml_str)
        rc = config.to_runtime_config()

        hipaa = get_preset("hipaa_aligned")
        assert rc.allow_threshold == hipaa.allow_threshold
        assert rc.deny_threshold == hipaa.deny_threshold
        assert rc.dimension_weights == dict(hipaa.dimension_weights)


# ---------------------------------------------------------------------------
# Test: Round-trip — load → to_runtime_config → GovernanceRuntime → evaluate
# ---------------------------------------------------------------------------

class TestRoundTrip:
    def test_full_round_trip_no_errors(self):
        config = load_governance_config_from_string(
            _minimal_extends_yaml("hipaa_aligned")
        )
        errors = validate_governance_config(config)
        assert errors == []

        rc = config.to_runtime_config()
        runtime = GovernanceRuntime(rc)

        # Configure agent scope
        scope_dim = runtime.registry.get("scope_compliance")
        scope_dim.configure_agent_scope("my-agent", {"read", "write"})

        # Create action and context
        action = Action(
            id="action-1",
            agent_id="my-agent",
            action_type="read",
            target="data",
        )
        trust = TrustProfile(agent_id="my-agent", overall_trust=0.5)
        context = AgentContext(agent_id="my-agent", trust_profile=trust)

        # Evaluate — should not raise
        verdict = runtime.evaluate(action, context)
        assert verdict.verdict in (
            Verdict.ALLOW,
            Verdict.DENY,
            Verdict.MODIFY,
            Verdict.ESCALATE,
            Verdict.SUSPEND,
        )

    def test_round_trip_with_explicit_overrides(self):
        yaml_str = textwrap.dedent("""\
            version: "1.0"
            extends: "strict"

            agents:
              bot-1:
                scope:
                  actions: [read, query]
                  targets: [logs]
                  boundaries: [logs]
                owner: "ops@corp.com"
                reason: "Log analysis bot"

            dimensions:
              weights:
                scope_compliance: 2.5
              vetoes:
                - scope_compliance
                - human_override

            thresholds:
              allow: 0.85
              deny: 0.25

            trust:
              success_increment: 0.02
              violation_decrement: 0.1
              interrupt_cost: 0.05
              decay_rate: 0.002
              floor: 0.1
              ceiling: 0.9

            compliance:
              frameworks: [SOC2]
        """)
        config = load_governance_config_from_string(yaml_str)
        errors = validate_governance_config(config)
        assert errors == []

        rc = config.to_runtime_config()
        runtime = GovernanceRuntime(rc)

        # Verify override applied
        assert rc.allow_threshold == 0.85
        assert rc.deny_threshold == 0.25
        assert rc.dimension_weights["scope_compliance"] == 2.5

        # Verify agent parsed
        assert config.agents[0].agent_id == "bot-1"
        assert config.agents[0].owner == "ops@corp.com"

        # Evaluate
        scope_dim = runtime.registry.get("scope_compliance")
        scope_dim.configure_agent_scope("bot-1", {"read", "query"})

        action = Action(
            id="action-2",
            agent_id="bot-1",
            action_type="read",
            target="logs",
        )
        trust = TrustProfile(agent_id="bot-1", overall_trust=0.5)
        context = AgentContext(agent_id="bot-1", trust_profile=trust)

        verdict = runtime.evaluate(action, context)
        assert verdict is not None


# ---------------------------------------------------------------------------
# Test: trust settings override from YAML
# ---------------------------------------------------------------------------

class TestTrustOverrides:
    def test_partial_trust_override(self):
        yaml_str = textwrap.dedent("""\
            version: "1.0"
            extends: "standard"

            agents:
              my-agent:
                scope:
                  actions: [read]
                  targets: [data]
                  boundaries: [data]

            trust:
              floor: 0.1
              ceiling: 0.9
        """)
        config = load_governance_config_from_string(yaml_str)

        standard = get_preset("standard")
        # Overridden values
        assert config.trust_settings["floor"] == 0.1
        assert config.trust_settings["ceiling"] == 0.9
        # Inherited values
        assert config.trust_settings["success_increment"] == standard.trust_settings["success_increment"]
        assert config.trust_settings["violation_decrement"] == standard.trust_settings["violation_decrement"]


# ---------------------------------------------------------------------------
# Test: default agent values
# ---------------------------------------------------------------------------

class TestAgentDefaults:
    def test_defaults_applied(self):
        yaml_str = textwrap.dedent("""\
            version: "1.0"
            extends: "standard"

            agents:
              minimal-agent:
                scope:
                  actions: [read]
                  targets: [data]
                  boundaries: [data]
        """)
        config = load_governance_config_from_string(yaml_str)
        agent = config.agents[0]

        assert agent.agent_id == "minimal-agent"
        assert agent.initial_trust == 0.5
        assert agent.min_trust_for_action == 0.3
        assert agent.owner == ""
        assert agent.reason == ""


# ---------------------------------------------------------------------------
# Test: multiple agents
# ---------------------------------------------------------------------------

class TestMultipleAgents:
    def test_multiple_agents_parsed(self):
        yaml_str = textwrap.dedent("""\
            version: "1.0"
            extends: "standard"

            agents:
              agent-a:
                scope:
                  actions: [read]
                  targets: [logs]
                  boundaries: [logs]
              agent-b:
                scope:
                  actions: [write, delete]
                  targets: [records]
                  boundaries: [records]
                owner: "admin@corp.com"
        """)
        config = load_governance_config_from_string(yaml_str)
        assert len(config.agents) == 2
        ids = {a.agent_id for a in config.agents}
        assert ids == {"agent-a", "agent-b"}


# ---------------------------------------------------------------------------
# Test: no extends defaults to standard preset
# ---------------------------------------------------------------------------

class TestNoExtendsDefaults:
    def test_defaults_to_standard(self):
        yaml_str = textwrap.dedent("""\
            version: "1.0"

            agents:
              my-agent:
                scope:
                  actions: [read]
                  targets: [data]
                  boundaries: [data]
        """)
        config = load_governance_config_from_string(yaml_str)

        standard = get_preset("standard")
        # With no extends and no explicit dimensions, should get standard defaults
        assert config.dimension_weights == dict(standard.dimension_weights)
        assert config.allow_threshold == standard.allow_threshold
        assert config.deny_threshold == standard.deny_threshold
