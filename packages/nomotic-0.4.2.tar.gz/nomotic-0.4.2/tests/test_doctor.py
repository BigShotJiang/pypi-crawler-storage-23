"""Tests for the ``nomotic doctor`` diagnostic command."""

from __future__ import annotations

import json
import os
import time
from datetime import datetime, timezone
from pathlib import Path

import pytest

from nomotic.certificate import AgentCertificate, CertStatus
from nomotic.doctor import DoctorCheck, DoctorReport, run_doctor
from nomotic.keys import SigningKey


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_cert(**overrides) -> AgentCertificate:
    """Create a certificate with sensible defaults for testing."""
    _sk, vk = SigningKey.generate()
    defaults = {
        "certificate_id": "nmc-test-1234",
        "agent_id": "agent-1",
        "owner": "alice@acme.com",
        "archetype": "customer-experience",
        "organization": "acme-corp",
        "zone_path": "global/us/acme-corp/retail",
        "issued_at": datetime(2024, 1, 1, tzinfo=timezone.utc),
        "trust_score": 0.50,
        "behavioral_age": 0,
        "status": CertStatus.ACTIVE,
        "public_key": vk.to_bytes(),
        "fingerprint": vk.fingerprint(),
        "governance_hash": "abc123",
        "lineage": None,
        "issuer_signature": b"\x00" * 32,
        "expires_at": None,
    }
    defaults.update(overrides)
    return AgentCertificate(**defaults)


def _save_cert(base_dir: Path, cert: AgentCertificate) -> None:
    """Save a certificate to the file store directory."""
    certs_dir = base_dir / "certs"
    certs_dir.mkdir(parents=True, exist_ok=True)
    path = certs_dir / f"{cert.certificate_id}.json"
    path.write_text(
        json.dumps(cert.to_dict(), sort_keys=True, indent=2),
        encoding="utf-8",
    )


def _setup_issuer(base_dir: Path) -> SigningKey:
    """Set up a valid issuer key in base_dir/issuer/."""
    issuer_dir = base_dir / "issuer"
    issuer_dir.mkdir(parents=True, exist_ok=True)
    sk, vk = SigningKey.generate()
    (issuer_dir / "issuer.key").write_bytes(sk.to_bytes())
    (issuer_dir / "issuer.pub").write_bytes(vk.to_bytes())
    meta = {
        "issuer_id": f"nomotic-cli-test",
        "created_at": datetime.now(timezone.utc).isoformat(),
        "fingerprint": vk.fingerprint(),
    }
    (issuer_dir / "issuer.json").write_text(json.dumps(meta, indent=2), encoding="utf-8")
    return sk


def _write_config(base_dir: Path, config: dict) -> None:
    """Write a config.json file."""
    path = base_dir / "config.json"
    path.write_text(json.dumps(config, indent=2), encoding="utf-8")


def _make_audit_record(
    agent_id: str = "TestBot",
    action_type: str = "read",
    target: str = "test_db",
    verdict: str = "ALLOW",
    trust: float = 0.510,
    delta: float = 0.010,
    **kwargs,
) -> dict:
    """Build a record data dict (without hashes)."""
    return {
        "record_id": kwargs.get("record_id", "abc123"),
        "timestamp": kwargs.get("timestamp", time.time()),
        "agent_id": agent_id,
        "action_type": action_type,
        "action_target": target,
        "verdict": verdict,
        "ucs": kwargs.get("ucs", 0.908),
        "tier": kwargs.get("tier", 2),
        "trust_score": trust,
        "trust_delta": delta,
        "trust_trend": kwargs.get("trust_trend", "rising"),
        "severity": kwargs.get("severity", "info"),
        "justification": kwargs.get("justification", "Action allowed"),
        "vetoed_by": kwargs.get("vetoed_by", []),
        "dimension_scores": kwargs.get("dimension_scores", {}),
        "parameters": kwargs.get("parameters", {}),
        "source": kwargs.get("source", ""),
        "previous_hash": "",
        "record_hash": "",
    }


def _append_chained(store, agent_id: str, records_data: list[dict]):
    """Append records with proper hash chaining."""
    from nomotic.audit_store import PersistentLogRecord

    result = []
    previous_hash = store.get_last_hash(agent_id)
    for data in records_data:
        data["previous_hash"] = previous_hash
        data["record_hash"] = store.compute_hash(data, previous_hash)
        record = PersistentLogRecord(**data)
        store.append(record)
        previous_hash = data["record_hash"]
        result.append(record)
    return result


# ===========================================================================
# 1. Report structure tests
# ===========================================================================


class TestReportStructure:
    """DoctorReport / DoctorCheck data-model tests."""

    def test_run_doctor_returns_report(self, tmp_path):
        report = run_doctor(tmp_path)
        assert isinstance(report, DoctorReport)

    def test_filters(self):
        report = DoctorReport(
            checks=[
                DoctorCheck("A", "a1", "ok", "fine"),
                DoctorCheck("A", "a2", "warning", "hmm"),
                DoctorCheck("B", "b1", "error", "bad"),
            ]
        )
        assert len(report.errors) == 1
        assert len(report.warnings) == 1
        assert len(report.ok) == 1

    def test_has_errors_false_when_clean(self):
        report = DoctorReport(
            checks=[
                DoctorCheck("A", "a1", "ok", "all good"),
                DoctorCheck("A", "a2", "warning", "just a warn"),
            ]
        )
        assert report.has_errors is False

    def test_has_errors_true(self):
        report = DoctorReport(
            checks=[DoctorCheck("A", "a1", "error", "bad")]
        )
        assert report.has_errors is True

    def test_to_dict_keys(self):
        report = DoctorReport(
            checks=[DoctorCheck("A", "a1", "ok", "fine")]
        )
        d = report.to_dict()
        assert "generated_at" in d
        assert "summary" in d
        assert "checks" in d
        assert d["summary"]["errors"] == 0
        assert d["summary"]["warnings"] == 0
        assert d["summary"]["ok"] == 1
        assert len(d["checks"]) == 1

    def test_check_to_dict(self):
        c = DoctorCheck("Cat", "name", "ok", "msg")
        d = c.to_dict()
        assert d == {
            "category": "Cat",
            "name": "name",
            "status": "ok",
            "message": "msg",
        }

    def test_check_status_helpers(self):
        assert DoctorCheck("A", "a", "ok", "m").is_ok()
        assert not DoctorCheck("A", "a", "ok", "m").is_warning()
        assert DoctorCheck("A", "a", "warning", "m").is_warning()
        assert DoctorCheck("A", "a", "error", "m").is_error()


# ===========================================================================
# 2. Installation checks
# ===========================================================================


class TestInstallationChecks:
    """Test the installation health checks."""

    def test_nomotic_version_passes(self, tmp_path):
        """Nomotic is installed in the test env, so version check passes."""
        report = run_doctor(tmp_path)
        version_checks = [
            c for c in report.checks if c.name == "Nomotic version"
        ]
        assert len(version_checks) == 1
        assert version_checks[0].status == "ok"

    def test_python_version_passes(self, tmp_path):
        """Test env is 3.10+, so Python version check passes."""
        report = run_doctor(tmp_path)
        py_checks = [c for c in report.checks if c.name == "Python version"]
        assert len(py_checks) == 1
        assert py_checks[0].status == "ok"


# ===========================================================================
# 3. Configuration checks
# ===========================================================================


class TestConfigurationChecks:
    """Test config.json health checks."""

    def test_missing_config_warning(self, tmp_path):
        """Missing config.json produces warning, not error."""
        report = run_doctor(tmp_path)
        config_checks = [
            c for c in report.checks if c.name == "config.json"
        ]
        assert len(config_checks) == 1
        assert config_checks[0].status == "warning"
        assert "nomotic setup" in config_checks[0].message

    def test_valid_config_ok(self, tmp_path):
        _write_config(tmp_path, {"organization": "acme", "default_preset": "strict"})
        report = run_doctor(tmp_path)
        config_checks = [
            c for c in report.checks if c.name == "config.json"
        ]
        assert len(config_checks) == 1
        assert config_checks[0].status == "ok"

    def test_malformed_config_error(self, tmp_path):
        """Invalid JSON in config.json produces error."""
        config_path = tmp_path / "config.json"
        config_path.write_text("{bad json!!!", encoding="utf-8")
        report = run_doctor(tmp_path)
        config_checks = [
            c for c in report.checks if c.name == "config.json"
        ]
        assert len(config_checks) == 1
        assert config_checks[0].status == "error"

    def test_config_with_organization_ok(self, tmp_path):
        """Config with organization field produces ok."""
        _write_config(tmp_path, {"organization": "acme-corp"})
        report = run_doctor(tmp_path)
        org_checks = [c for c in report.checks if c.name == "Organization"]
        assert len(org_checks) == 1
        assert org_checks[0].status == "ok"
        assert "acme-corp" in org_checks[0].message

    def test_config_without_organization_warning(self, tmp_path):
        """Config without organization field produces warning."""
        _write_config(tmp_path, {"some_other_key": "value"})
        report = run_doctor(tmp_path)
        org_checks = [c for c in report.checks if c.name == "Organization"]
        assert len(org_checks) == 1
        assert org_checks[0].status == "warning"

    def test_valid_preset_ok(self, tmp_path):
        _write_config(tmp_path, {"organization": "x", "default_preset": "strict"})
        report = run_doctor(tmp_path)
        preset_checks = [c for c in report.checks if c.name == "Default preset"]
        assert len(preset_checks) == 1
        assert preset_checks[0].status == "ok"

    def test_unknown_preset_warning(self, tmp_path):
        _write_config(tmp_path, {"organization": "x", "default_preset": "nonexistent"})
        report = run_doctor(tmp_path)
        preset_checks = [c for c in report.checks if c.name == "Default preset"]
        assert len(preset_checks) == 1
        assert preset_checks[0].status == "warning"
        assert "nonexistent" in preset_checks[0].message


# ===========================================================================
# 4. Certificate store checks
# ===========================================================================


class TestCertificateStoreChecks:
    """Test certificate store health checks."""

    def test_no_certs_dir_warning(self, tmp_path):
        """No certs directory produces warning, not error."""
        report = run_doctor(tmp_path)
        cert_checks = [
            c for c in report.checks
            if c.category == "Certificate Store"
        ]
        # Should have at least one check
        assert len(cert_checks) >= 1
        assert cert_checks[0].status == "warning"
        assert "does not exist" in cert_checks[0].message

    def test_empty_certs_dir_warning(self, tmp_path):
        """Empty certs directory produces warning about no agents."""
        (tmp_path / "certs").mkdir()
        report = run_doctor(tmp_path)
        active_checks = [
            c for c in report.checks if c.name == "Active agents"
        ]
        assert len(active_checks) == 1
        assert active_checks[0].status == "warning"

    def test_populated_store_ok(self, tmp_path):
        """Store with active certs reports correct counts."""
        cert1 = _make_cert(certificate_id="nmc-001", agent_id="agent-1")
        cert2 = _make_cert(certificate_id="nmc-002", agent_id="agent-2")
        _save_cert(tmp_path, cert1)
        _save_cert(tmp_path, cert2)
        # Also need revoked dir for FileCertificateStore
        (tmp_path / "revoked").mkdir(parents=True, exist_ok=True)

        report = run_doctor(tmp_path)
        count_checks = [
            c for c in report.checks if c.name == "Certificate counts"
        ]
        assert len(count_checks) == 1
        assert count_checks[0].status == "ok"
        assert "active:2" in count_checks[0].message

    def test_expired_active_cert_warning(self, tmp_path):
        """Active cert with expired timestamp produces warning."""
        cert = _make_cert(
            certificate_id="nmc-expired-001",
            expires_at=datetime(2020, 1, 1, tzinfo=timezone.utc),
        )
        _save_cert(tmp_path, cert)
        (tmp_path / "revoked").mkdir(parents=True, exist_ok=True)

        report = run_doctor(tmp_path)
        expired_checks = [
            c for c in report.checks if c.name == "Expired active certificates"
        ]
        assert len(expired_checks) == 1
        assert expired_checks[0].status == "warning"
        assert "nmc-expired-001" in expired_checks[0].message


# ===========================================================================
# 5. Audit trail checks
# ===========================================================================


class TestAuditTrailChecks:
    """Test audit trail health checks."""

    def test_no_audit_dir_warning(self, tmp_path):
        """No audit directory produces warning."""
        report = run_doctor(tmp_path)
        audit_checks = [
            c for c in report.checks if c.category == "Audit Trail"
        ]
        assert len(audit_checks) >= 1
        assert audit_checks[0].status == "warning"
        assert "No audit records" in audit_checks[0].message

    def test_valid_chain_ok(self, tmp_path):
        """Audit records with valid chain produce ok."""
        from nomotic.audit_store import AuditStore

        store = AuditStore(tmp_path)
        records = [
            _make_audit_record(record_id=f"r{i}", agent_id="agent-1")
            for i in range(3)
        ]
        _append_chained(store, "agent-1", records)

        report = run_doctor(tmp_path)
        chain_checks = [
            c for c in report.checks if c.name == "Hash chain integrity"
        ]
        assert len(chain_checks) == 1
        assert chain_checks[0].status == "ok"

    def test_tampered_chain_error(self, tmp_path):
        """Tampered audit record produces chain break error."""
        from nomotic.audit_store import AuditStore

        store = AuditStore(tmp_path)
        records = [
            _make_audit_record(record_id=f"r{i}", agent_id="agent-1")
            for i in range(3)
        ]
        _append_chained(store, "agent-1", records)

        # Tamper with the audit file
        audit_file = tmp_path / "audit" / "agent-1.jsonl"
        lines = audit_file.read_text().strip().split("\n")
        record = json.loads(lines[1])
        record["verdict"] = "DENY"  # tamper
        lines[1] = json.dumps(record)
        audit_file.write_text("\n".join(lines) + "\n")

        report = run_doctor(tmp_path)
        chain_checks = [
            c for c in report.checks if c.name == "Hash chain integrity"
        ]
        assert len(chain_checks) == 1
        assert chain_checks[0].status == "error"
        assert "CHAIN BREAK" in chain_checks[0].message

    def test_silent_agents_warning(self, tmp_path):
        """Agent with empty audit file produces warning."""
        audit_dir = tmp_path / "audit"
        audit_dir.mkdir(parents=True)
        # Create empty audit file for an agent
        (audit_dir / "silent-bot.jsonl").write_text("", encoding="utf-8")

        report = run_doctor(tmp_path)
        silent_checks = [
            c for c in report.checks if c.name == "Silent agents"
        ]
        assert len(silent_checks) == 1
        assert silent_checks[0].status == "warning"
        assert "silent-bot" in silent_checks[0].message


# ===========================================================================
# 5b. Audit trail --fix safety guard
# ===========================================================================


class TestAuditFixExclusion:
    """Audit trail errors must NEVER be auto-fixed — they are forensic evidence."""

    def _tamper_chain(self, tmp_path):
        """Set up a tampered audit chain and return the audit file path."""
        from nomotic.audit_store import AuditStore

        store = AuditStore(tmp_path)
        records = [
            _make_audit_record(record_id=f"r{i}", agent_id="agent-1")
            for i in range(3)
        ]
        _append_chained(store, "agent-1", records)

        audit_file = tmp_path / "audit" / "agent-1.jsonl"
        lines = audit_file.read_text().strip().split("\n")
        record = json.loads(lines[1])
        record["verdict"] = "DENY"  # tamper
        lines[1] = json.dumps(record)
        audit_file.write_text("\n".join(lines) + "\n")
        return audit_file

    def test_fix_does_not_modify_audit_data(self, tmp_path):
        """--fix must NOT modify audit trail files when chain error is detected."""
        from nomotic.cli import main

        import io
        import contextlib

        audit_file = self._tamper_chain(tmp_path)
        content_before = audit_file.read_text()

        buf = io.StringIO()
        with contextlib.redirect_stdout(buf):
            with pytest.raises(SystemExit):
                main(["--base-dir", str(tmp_path), "doctor", "--fix"])

        content_after = audit_file.read_text()
        assert content_before == content_after, "Audit file was modified by --fix"

    def test_fix_prints_manual_investigation_message(self, tmp_path, capsys):
        """--fix prints forensic preservation warning for audit errors."""
        from nomotic.cli import main

        self._tamper_chain(tmp_path)

        with pytest.raises(SystemExit):
            main(["--base-dir", str(tmp_path), "doctor", "--fix"])

        captured = capsys.readouterr()
        assert "manual investigation" in captured.out
        assert "cannot be auto-fixed" in captured.out
        assert "forensic evidence" in captured.out

    def test_fix_still_processes_other_fixable_items(self, tmp_path, capsys):
        """--fix shows fix hints for non-audit items even when audit errors exist."""
        from nomotic.cli import main

        # Create tampered audit chain (audit error)
        self._tamper_chain(tmp_path)

        # Also create an expired-cert scenario to have a non-audit fix hint
        # The missing config gives a fix_hint="nomotic setup"
        # (no config.json → warning with fix_hint)

        with pytest.raises(SystemExit):
            main(["--base-dir", str(tmp_path), "doctor", "--fix"])

        captured = capsys.readouterr()
        # Non-audit fix hints should still appear
        assert "Fix:" in captured.out
        # Audit warning should also appear
        assert "manual investigation" in captured.out

    def test_verify_chain_unchanged_after_fix(self, tmp_path):
        """verify_chain() result is identical before and after --fix runs."""
        from nomotic.audit_store import AuditStore
        from nomotic.cli import main

        import io
        import contextlib

        self._tamper_chain(tmp_path)
        store = AuditStore(tmp_path)

        result_before = store.verify_chain("agent-1")

        buf = io.StringIO()
        with contextlib.redirect_stdout(buf):
            with pytest.raises(SystemExit):
                main(["--base-dir", str(tmp_path), "doctor", "--fix"])

        result_after = store.verify_chain("agent-1")
        assert result_before == result_after, (
            "verify_chain() result changed after --fix"
        )


# ===========================================================================
# 6. Signing key checks
# ===========================================================================


class TestSigningKeyChecks:
    """Test issuer signing key health checks."""

    def test_no_issuer_dir_warning(self, tmp_path):
        """No issuer directory produces warning."""
        report = run_doctor(tmp_path)
        key_checks = [
            c for c in report.checks if c.category == "Signing Keys"
        ]
        assert len(key_checks) >= 1
        assert key_checks[0].status == "warning"
        assert "nomotic setup" in key_checks[0].message

    def test_no_key_file_error(self, tmp_path):
        """Issuer dir exists but no key file produces error."""
        issuer_dir = tmp_path / "issuer"
        issuer_dir.mkdir()
        # Create a non-key file so the dir exists but has no keys
        (issuer_dir / "readme.txt").write_text("nothing here")

        report = run_doctor(tmp_path)
        key_checks = [
            c for c in report.checks if c.name == "Issuer key"
        ]
        assert len(key_checks) == 1
        assert key_checks[0].status == "error"

    def test_valid_key_ok(self, tmp_path):
        """Valid issuer key produces ok with fingerprint."""
        _setup_issuer(tmp_path)

        report = run_doctor(tmp_path)
        key_checks = [
            c for c in report.checks if c.name == "Issuer key"
        ]
        assert len(key_checks) == 1
        assert key_checks[0].status == "ok"
        assert "fingerprint:" in key_checks[0].message


# ===========================================================================
# 7. CLI integration tests
# ===========================================================================


class TestCLIIntegration:
    """Test the ``nomotic doctor`` CLI integration."""

    def test_json_output_valid(self, tmp_path):
        """``nomotic doctor --json`` outputs valid JSON."""
        from nomotic.cli import main

        import io
        import contextlib

        buf = io.StringIO()
        with contextlib.redirect_stdout(buf):
            # No errors expected on empty dir (only warnings)
            with pytest.raises(SystemExit) as exc_info:
                main(["--base-dir", str(tmp_path), "doctor", "--json"])
            assert exc_info.value.code == 0

        output = buf.getvalue()
        data = json.loads(output)
        assert "summary" in data
        assert "errors" in data["summary"]
        assert "checks" in data
        assert "generated_at" in data

    def test_exit_code_0_on_pass(self, tmp_path):
        """Exit code 0 when no errors (warnings are ok)."""
        from nomotic.cli import main

        import io
        import contextlib

        buf = io.StringIO()
        with contextlib.redirect_stdout(buf):
            with pytest.raises(SystemExit) as exc_info:
                main(["--base-dir", str(tmp_path), "doctor", "--json"])
            assert exc_info.value.code == 0

    def test_exit_code_1_on_errors(self, tmp_path):
        """Exit code 1 when errors found."""
        from nomotic.cli import main

        import io
        import contextlib

        # Create a malformed config to trigger an error
        (tmp_path / "config.json").write_text("{bad", encoding="utf-8")

        buf = io.StringIO()
        with contextlib.redirect_stdout(buf):
            with pytest.raises(SystemExit) as exc_info:
                main(["--base-dir", str(tmp_path), "doctor", "--json"])
            assert exc_info.value.code == 1

    def test_quiet_suppresses_ok(self, tmp_path, capsys):
        """``--quiet`` suppresses ok-status checks from output."""
        from nomotic.cli import main

        _write_config(tmp_path, {"organization": "acme"})

        # No errors → function returns normally (no SystemExit)
        main(["--base-dir", str(tmp_path), "doctor", "--quiet"])

        captured = capsys.readouterr()
        # In quiet mode, ok checks should not appear.
        # The "Nomotic version" and "Python version" lines are ok status
        # and should NOT appear in the output.
        assert "Nomotic Doctor" in captured.out
        # Ok checks like version info should be suppressed
        assert "Python" not in captured.out
        # Warnings should still appear
        assert "nomotic setup" in captured.out or "warning" in captured.out.lower()

    def test_json_has_required_keys(self, tmp_path):
        """JSON output has required top-level keys."""
        from nomotic.cli import main

        import io
        import contextlib

        buf = io.StringIO()
        with contextlib.redirect_stdout(buf):
            with pytest.raises(SystemExit):
                main(["--base-dir", str(tmp_path), "doctor", "--json"])

        data = json.loads(buf.getvalue())
        assert set(data.keys()) == {"generated_at", "summary", "checks"}


# ===========================================================================
# 8. Robustness — run_doctor never raises
# ===========================================================================


class TestRobustness:
    """Ensure run_doctor does not raise regardless of filesystem state."""

    def test_empty_dir(self, tmp_path):
        """Empty base directory does not raise."""
        report = run_doctor(tmp_path)
        assert isinstance(report, DoctorReport)
        assert not report.has_errors

    def test_nonexistent_base_dir(self, tmp_path):
        """Non-existent base directory does not raise."""
        report = run_doctor(tmp_path / "does-not-exist")
        assert isinstance(report, DoctorReport)

    def test_corrupted_issuer_key(self, tmp_path):
        """Corrupted issuer key file does not crash, produces error check."""
        issuer_dir = tmp_path / "issuer"
        issuer_dir.mkdir()
        (issuer_dir / "issuer.key").write_bytes(b"corrupted-key-data")

        report = run_doctor(tmp_path)
        key_checks = [
            c for c in report.checks if c.name == "Issuer key"
        ]
        assert len(key_checks) == 1
        assert key_checks[0].status == "error"
