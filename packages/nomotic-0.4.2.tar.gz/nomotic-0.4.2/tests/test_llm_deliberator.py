"""Tests for the multi-model LLM deliberator."""

import json
import time
import threading
from concurrent.futures import TimeoutError

from nomotic.types import Action, AgentContext, DimensionScore, TrustProfile, Verdict
from nomotic.tiers import TierThreeDeliberator
from nomotic.runtime import GovernanceRuntime, RuntimeConfig
from nomotic.llm_deliberator import (
    LLMDeliberationConfig,
    LLMDeliberator,
    LLMProviderConfig,
    LLMResponse,
)


# ── Helpers ──────────────────────────────────────────────────────────


def _ctx(trust: float = 0.5) -> AgentContext:
    return AgentContext(
        agent_id="a",
        trust_profile=TrustProfile(agent_id="a", overall_trust=trust),
    )


def _action(**params) -> Action:
    return Action(
        agent_id="a",
        action_type="transfer",
        target="account",
        parameters=params or {"amount": 500, "recipient": "user@example.com"},
    )


def _scores() -> list[DimensionScore]:
    return [
        DimensionScore(dimension_name="scope_compliance", score=0.6, weight=1.0),
        DimensionScore(dimension_name="authority_level", score=0.5, weight=1.2),
        DimensionScore(dimension_name="ethical_alignment", score=0.7, weight=1.0),
    ]


def _make_llm_callable(verdict: str, reasoning: str = "test reasoning"):
    """Create a mock LLM callable that returns a fixed JSON response."""
    def call(prompt: str) -> str:
        return json.dumps({"verdict": verdict, "reasoning": reasoning})
    return call


def _make_config(
    providers: list[LLMProviderConfig] | None = None,
    enabled: bool = True,
    **kwargs,
) -> LLMDeliberationConfig:
    if providers is None:
        providers = [
            LLMProviderConfig(
                provider="mock-a",
                model="model-a",
                call=_make_llm_callable("ALLOW"),
                weight=1.0,
            ),
            LLMProviderConfig(
                provider="mock-b",
                model="model-b",
                call=_make_llm_callable("ALLOW"),
                weight=1.0,
            ),
        ]
    return LLMDeliberationConfig(enabled=enabled, providers=providers, **kwargs)


# ── Test Classes ─────────────────────────────────────────────────────


class TestBasicConsensus:
    """Basic consensus with mock LLM callables."""

    def test_unanimous_allow(self):
        config = _make_config()
        delib = LLMDeliberator(config)
        result = delib(_action(), _ctx(), _scores(), 0.5)
        assert result == Verdict.ALLOW

    def test_unanimous_deny(self):
        providers = [
            LLMProviderConfig("a", "m-a", _make_llm_callable("DENY"), weight=1.0),
            LLMProviderConfig("b", "m-b", _make_llm_callable("DENY"), weight=1.0),
        ]
        config = _make_config(providers=providers)
        delib = LLMDeliberator(config)
        result = delib(_action(), _ctx(), _scores(), 0.5)
        assert result == Verdict.DENY

    def test_unanimous_escalate(self):
        providers = [
            LLMProviderConfig("a", "m-a", _make_llm_callable("ESCALATE"), weight=1.0),
            LLMProviderConfig("b", "m-b", _make_llm_callable("ESCALATE"), weight=1.0),
        ]
        config = _make_config(providers=providers)
        delib = LLMDeliberator(config)
        result = delib(_action(), _ctx(), _scores(), 0.5)
        assert result == Verdict.ESCALATE

    def test_unanimous_modify(self):
        providers = [
            LLMProviderConfig("a", "m-a", _make_llm_callable("MODIFY"), weight=1.0),
            LLMProviderConfig("b", "m-b", _make_llm_callable("MODIFY"), weight=1.0),
        ]
        config = _make_config(providers=providers)
        delib = LLMDeliberator(config)
        result = delib(_action(), _ctx(), _scores(), 0.5)
        assert result == Verdict.MODIFY

    def test_majority_consensus(self):
        """Two out of three agree on ALLOW (67% >= threshold)."""
        providers = [
            LLMProviderConfig("a", "m-a", _make_llm_callable("ALLOW"), weight=1.0),
            LLMProviderConfig("b", "m-b", _make_llm_callable("ALLOW"), weight=1.0),
            LLMProviderConfig("c", "m-c", _make_llm_callable("MODIFY"), weight=1.0),
        ]
        # 2/3 = 0.6667, so threshold must be <= that value
        config = _make_config(providers=providers, consensus_threshold=0.66)
        delib = LLMDeliberator(config)
        result = delib(_action(), _ctx(), _scores(), 0.5)
        assert result == Verdict.ALLOW

    def test_no_consensus_escalates(self):
        """No verdict has enough weight for consensus."""
        providers = [
            LLMProviderConfig("a", "m-a", _make_llm_callable("ALLOW"), weight=1.0),
            LLMProviderConfig("b", "m-b", _make_llm_callable("MODIFY"), weight=1.0),
            LLMProviderConfig("c", "m-c", _make_llm_callable("ESCALATE"), weight=1.0),
        ]
        config = _make_config(providers=providers, consensus_threshold=0.67)
        delib = LLMDeliberator(config)
        result = delib(_action(), _ctx(), _scores(), 0.5)
        assert result == Verdict.ESCALATE


class TestWeightedConsensus:
    """Weighted consensus calculation."""

    def test_weight_tips_consensus(self):
        """A heavily weighted model tips the balance."""
        providers = [
            LLMProviderConfig("a", "m-a", _make_llm_callable("ALLOW"), weight=3.0),
            LLMProviderConfig("b", "m-b", _make_llm_callable("MODIFY"), weight=1.0),
        ]
        config = _make_config(providers=providers, consensus_threshold=0.67)
        delib = LLMDeliberator(config)
        result = delib(_action(), _ctx(), _scores(), 0.5)
        # ALLOW has weight 3.0 / 4.0 = 0.75 >= 0.67
        assert result == Verdict.ALLOW

    def test_low_weight_insufficient_for_consensus(self):
        """Low-weight model can't achieve consensus alone."""
        providers = [
            LLMProviderConfig("a", "m-a", _make_llm_callable("ALLOW"), weight=1.0),
            LLMProviderConfig("b", "m-b", _make_llm_callable("MODIFY"), weight=2.0),
            LLMProviderConfig("c", "m-c", _make_llm_callable("ESCALATE"), weight=2.0),
        ]
        config = _make_config(providers=providers, consensus_threshold=0.67)
        delib = LLMDeliberator(config)
        result = delib(_action(), _ctx(), _scores(), 0.5)
        # No verdict reaches 0.67. MODIFY=2/5=0.4, ESCALATE=2/5=0.4, ALLOW=1/5=0.2
        assert result == Verdict.ESCALATE

    def test_equal_weights_split(self):
        """Equal split results in ESCALATE (when no veto applies)."""
        providers = [
            LLMProviderConfig("a", "m-a", _make_llm_callable("ALLOW"), weight=1.0),
            LLMProviderConfig("b", "m-b", _make_llm_callable("MODIFY"), weight=1.0),
        ]
        # Use veto_weight higher than any provider weight so veto doesn't trigger
        config = _make_config(providers=providers, consensus_threshold=0.67, veto_weight=2.0)
        delib = LLMDeliberator(config)
        result = delib(_action(), _ctx(), _scores(), 0.5)
        assert result == Verdict.ESCALATE


class TestVetoBehavior:
    """Veto behavior: DENY with sufficient weight overrides consensus."""

    def test_veto_overrides_majority(self):
        """A single DENY with weight >= veto_weight vetoes."""
        providers = [
            LLMProviderConfig("a", "m-a", _make_llm_callable("ALLOW"), weight=1.0),
            LLMProviderConfig("b", "m-b", _make_llm_callable("ALLOW"), weight=1.0),
            LLMProviderConfig("c", "m-c", _make_llm_callable("DENY"), weight=0.5),
        ]
        config = _make_config(
            providers=providers,
            consensus_threshold=0.67,
            veto_weight=0.5,
        )
        delib = LLMDeliberator(config)
        result = delib(_action(), _ctx(), _scores(), 0.5)
        assert result == Verdict.DENY

    def test_deny_below_veto_weight_no_veto(self):
        """DENY with weight < veto_weight doesn't trigger veto."""
        providers = [
            LLMProviderConfig("a", "m-a", _make_llm_callable("ALLOW"), weight=1.0),
            LLMProviderConfig("b", "m-b", _make_llm_callable("ALLOW"), weight=1.0),
            LLMProviderConfig("c", "m-c", _make_llm_callable("DENY"), weight=0.3),
        ]
        config = _make_config(
            providers=providers,
            consensus_threshold=0.67,
            veto_weight=0.5,
        )
        delib = LLMDeliberator(config)
        result = delib(_action(), _ctx(), _scores(), 0.5)
        # ALLOW: 2.0/2.3 ~= 0.87 >= 0.67, no veto
        assert result == Verdict.ALLOW

    def test_veto_audit_records_vetoer(self):
        """Veto audit metadata records which model vetoed."""
        providers = [
            LLMProviderConfig("safety", "safety-model", _make_llm_callable("DENY"), weight=1.0),
            LLMProviderConfig("general", "general-model", _make_llm_callable("ALLOW"), weight=1.0),
        ]
        config = _make_config(providers=providers, veto_weight=0.5)
        delib = LLMDeliberator(config)
        delib(_action(), _ctx(), _scores(), 0.5)
        audit = delib.last_audit
        assert audit is not None
        assert audit["consensus_details"]["reason"] == "veto"
        assert "safety/safety-model" in audit["consensus_details"]["veto_by"]


class TestTimeoutHandling:
    """Timeout handling: slow models are excluded."""

    def test_slow_model_excluded(self):
        """A model that sleeps past the timeout is excluded from consensus."""
        def slow_call(prompt: str) -> str:
            time.sleep(5)
            return json.dumps({"verdict": "DENY", "reasoning": "slow"})

        providers = [
            LLMProviderConfig("fast-a", "m-a", _make_llm_callable("ALLOW"), weight=1.0),
            LLMProviderConfig("fast-b", "m-b", _make_llm_callable("ALLOW"), weight=1.0),
            LLMProviderConfig("slow", "m-slow", slow_call, weight=1.0),
        ]
        config = _make_config(providers=providers, timeout_seconds=0.5)
        delib = LLMDeliberator(config)
        result = delib(_action(), _ctx(), _scores(), 0.5)
        # The slow model should be excluded or error out; fast models agree on ALLOW
        assert result == Verdict.ALLOW

    def test_all_timeout_returns_fallback(self):
        """If all models time out, return the fallback verdict."""
        def slow_call(prompt: str) -> str:
            time.sleep(5)
            return json.dumps({"verdict": "ALLOW", "reasoning": "slow"})

        providers = [
            LLMProviderConfig("slow-a", "m-a", slow_call, weight=1.0),
            LLMProviderConfig("slow-b", "m-b", slow_call, weight=1.0),
        ]
        config = _make_config(
            providers=providers,
            timeout_seconds=0.2,
            fallback_verdict=Verdict.ESCALATE,
        )
        delib = LLMDeliberator(config)
        result = delib(_action(), _ctx(), _scores(), 0.5)
        assert result == Verdict.ESCALATE


class TestAllFailFallback:
    """All-fail fallback behavior."""

    def test_all_errors_return_fallback(self):
        """If all LLMs raise exceptions, return fallback verdict."""
        def failing_call(prompt: str) -> str:
            raise ConnectionError("network error")

        providers = [
            LLMProviderConfig("a", "m-a", failing_call, weight=1.0),
            LLMProviderConfig("b", "m-b", failing_call, weight=1.0),
        ]
        config = _make_config(
            providers=providers,
            fallback_verdict=Verdict.ESCALATE,
        )
        delib = LLMDeliberator(config)
        result = delib(_action(), _ctx(), _scores(), 0.5)
        assert result == Verdict.ESCALATE

    def test_custom_fallback_verdict(self):
        """Fallback can be configured to any verdict."""
        def failing_call(prompt: str) -> str:
            raise RuntimeError("fail")

        providers = [
            LLMProviderConfig("a", "m-a", failing_call, weight=1.0),
        ]
        config = _make_config(
            providers=providers,
            fallback_verdict=Verdict.DENY,
        )
        delib = LLMDeliberator(config)
        result = delib(_action(), _ctx(), _scores(), 0.5)
        assert result == Verdict.DENY

    def test_unparseable_responses_return_fallback(self):
        """If all LLMs return unparseable responses, use fallback."""
        def garbled_call(prompt: str) -> str:
            return "This is not a valid response at all."

        providers = [
            LLMProviderConfig("a", "m-a", garbled_call, weight=1.0),
            LLMProviderConfig("b", "m-b", garbled_call, weight=1.0),
        ]
        config = _make_config(providers=providers)
        delib = LLMDeliberator(config)
        result = delib(_action(), _ctx(), _scores(), 0.5)
        assert result == Verdict.ESCALATE  # default fallback


class TestThreadSafety:
    """Thread safety: concurrent invocations."""

    def test_concurrent_invocations(self):
        """Multiple threads can invoke the deliberator simultaneously."""
        config = _make_config()
        delib = LLMDeliberator(config)
        results = []
        errors = []

        def invoke():
            try:
                result = delib(_action(), _ctx(), _scores(), 0.5)
                results.append(result)
            except Exception as exc:
                errors.append(exc)

        threads = [threading.Thread(target=invoke) for _ in range(10)]
        for t in threads:
            t.start()
        for t in threads:
            t.join(timeout=10)

        assert not errors
        assert len(results) == 10
        assert all(r == Verdict.ALLOW for r in results)

    def test_audit_survives_concurrent_access(self):
        """last_audit is safely readable across threads."""
        config = _make_config()
        delib = LLMDeliberator(config)
        audits = []

        def invoke_and_read():
            delib(_action(), _ctx(), _scores(), 0.5)
            audit = delib.last_audit
            if audit is not None:
                audits.append(audit)

        threads = [threading.Thread(target=invoke_and_read) for _ in range(10)]
        for t in threads:
            t.start()
        for t in threads:
            t.join(timeout=10)

        assert len(audits) == 10
        for audit in audits:
            assert "responses" in audit
            assert "verdict" in audit


class TestPromptGeneration:
    """Prompt generation: verify no raw parameters leak."""

    def test_no_raw_parameter_values_in_prompt(self):
        """The prompt must NOT contain raw parameter values."""
        captured_prompts = []

        def capturing_call(prompt: str) -> str:
            captured_prompts.append(prompt)
            return json.dumps({"verdict": "ALLOW", "reasoning": "ok"})

        providers = [
            LLMProviderConfig("a", "m-a", capturing_call, weight=1.0),
        ]
        config = _make_config(providers=providers)
        delib = LLMDeliberator(config)

        action = _action(
            amount=9999,
            recipient="secret@email.com",
            ssn="123-45-6789",
        )
        delib(action, _ctx(), _scores(), 0.5)

        assert len(captured_prompts) == 1
        prompt = captured_prompts[0]

        # Raw values should NOT appear
        assert "9999" not in prompt
        assert "secret@email.com" not in prompt
        assert "123-45-6789" not in prompt

        # Parameter keys SHOULD appear
        assert "amount" in prompt
        assert "recipient" in prompt
        assert "ssn" in prompt

    def test_prompt_contains_dimension_scores(self):
        """Prompt includes dimension score information."""
        captured = []

        def capturing_call(prompt: str) -> str:
            captured.append(prompt)
            return json.dumps({"verdict": "ALLOW", "reasoning": "ok"})

        providers = [
            LLMProviderConfig("a", "m-a", capturing_call, weight=1.0),
        ]
        config = _make_config(providers=providers)
        delib = LLMDeliberator(config)
        delib(_action(), _ctx(trust=0.65), _scores(), 0.45)

        prompt = captured[0]
        assert "scope_compliance" in prompt
        assert "authority_level" in prompt
        assert "ethical_alignment" in prompt
        assert "0.45" in prompt  # UCS
        assert "0.65" in prompt  # trust

    def test_prompt_contains_action_type_and_target(self):
        """Prompt includes action type and target."""
        captured = []

        def capturing_call(prompt: str) -> str:
            captured.append(prompt)
            return json.dumps({"verdict": "ALLOW", "reasoning": "ok"})

        providers = [
            LLMProviderConfig("a", "m-a", capturing_call, weight=1.0),
        ]
        config = _make_config(providers=providers)
        delib = LLMDeliberator(config)
        delib(_action(), _ctx(), _scores(), 0.5)

        prompt = captured[0]
        assert "transfer" in prompt
        assert "account" in prompt

    def test_custom_prompt_template(self):
        """PROMPT_TEMPLATE can be overridden."""
        class CustomDeliberator(LLMDeliberator):
            PROMPT_TEMPLATE = "Custom: {action_type} {ucs:.4f}"

        captured = []

        def capturing_call(prompt: str) -> str:
            captured.append(prompt)
            return json.dumps({"verdict": "ALLOW", "reasoning": "ok"})

        providers = [
            LLMProviderConfig("a", "m-a", capturing_call, weight=1.0),
        ]
        config = _make_config(providers=providers)
        delib = CustomDeliberator(config)
        delib(_action(), _ctx(), _scores(), 0.5)

        assert captured[0] == "Custom: transfer 0.5000"


class TestDisabledNoOp:
    """No-op when disabled."""

    def test_disabled_returns_none(self):
        config = _make_config(enabled=False)
        delib = LLMDeliberator(config)
        result = delib(_action(), _ctx(), _scores(), 0.5)
        assert result is None

    def test_no_providers_returns_none(self):
        config = _make_config(providers=[], enabled=True)
        delib = LLMDeliberator(config)
        result = delib(_action(), _ctx(), _scores(), 0.5)
        assert result is None

    def test_disabled_doesnt_call_providers(self):
        """When disabled, no LLM calls are made."""
        call_count = 0

        def counting_call(prompt: str) -> str:
            nonlocal call_count
            call_count += 1
            return json.dumps({"verdict": "ALLOW", "reasoning": "ok"})

        providers = [
            LLMProviderConfig("a", "m-a", counting_call, weight=1.0),
        ]
        config = _make_config(providers=providers, enabled=False)
        delib = LLMDeliberator(config)
        delib(_action(), _ctx(), _scores(), 0.5)
        assert call_count == 0


class TestTierThreeIntegration:
    """Integration with TierThreeDeliberator.add_deliberator()."""

    def test_registers_and_executes_via_tier_three(self):
        """LLMDeliberator can be registered via add_deliberator()."""
        tier3 = TierThreeDeliberator()
        config = _make_config()
        delib = LLMDeliberator(config)
        tier3.add_deliberator(delib)

        result = tier3.evaluate(_action(), _ctx(trust=0.5), _scores(), 0.5)
        assert result.decided
        assert result.verdict.verdict == Verdict.ALLOW
        assert result.verdict.tier == 3

    def test_disabled_deliberator_falls_through(self):
        """Disabled LLMDeliberator returns None, letting Tier 3 continue."""
        tier3 = TierThreeDeliberator()
        config = _make_config(enabled=False)
        delib = LLMDeliberator(config)
        tier3.add_deliberator(delib)

        # With trust=0.8 and ucs=0.55, built-in logic allows
        result = tier3.evaluate(_action(), _ctx(trust=0.8), _scores(), 0.55)
        assert result.decided
        assert result.verdict.verdict == Verdict.ALLOW
        assert "High trust" in result.verdict.reasoning

    def test_multiple_deliberators_first_wins(self):
        """If LLMDeliberator returns a verdict, subsequent deliberators are skipped."""
        tier3 = TierThreeDeliberator()

        config = _make_config()
        delib = LLMDeliberator(config)
        tier3.add_deliberator(delib)

        # Add another deliberator that would DENY — should never be reached
        tier3.add_deliberator(lambda a, c, s, u: Verdict.DENY)

        result = tier3.evaluate(_action(), _ctx(), _scores(), 0.5)
        assert result.verdict.verdict == Verdict.ALLOW


class TestDissentTracking:
    """Dissent tracking in audit metadata."""

    def test_dissent_recorded(self):
        """Dissenting opinions are recorded in audit metadata."""
        providers = [
            LLMProviderConfig("a", "m-a", _make_llm_callable("ALLOW", "Looks safe"), weight=1.0),
            LLMProviderConfig("b", "m-b", _make_llm_callable("ALLOW", "Agree"), weight=1.0),
            LLMProviderConfig("c", "m-c", _make_llm_callable("DENY", "Too risky"), weight=0.3),
        ]
        config = _make_config(providers=providers, veto_weight=0.5)
        delib = LLMDeliberator(config)
        result = delib(_action(), _ctx(), _scores(), 0.5)

        assert result == Verdict.ALLOW
        audit = delib.last_audit
        assert audit is not None
        assert len(audit["dissenting"]) == 1
        assert audit["dissenting"][0]["provider"] == "c"
        assert audit["dissenting"][0]["verdict"] == "DENY"
        assert audit["dissenting"][0]["reasoning"] == "Too risky"

    def test_no_dissent_when_unanimous(self):
        config = _make_config()
        delib = LLMDeliberator(config)
        delib(_action(), _ctx(), _scores(), 0.5)
        audit = delib.last_audit
        assert audit is not None
        assert len(audit["dissenting"]) == 0

    def test_audit_records_all_model_responses(self):
        """All model responses are recorded in audit regardless of verdict."""
        providers = [
            LLMProviderConfig("a", "m-a", _make_llm_callable("ALLOW"), weight=1.0),
            LLMProviderConfig("b", "m-b", _make_llm_callable("MODIFY"), weight=1.0),
        ]
        config = _make_config(providers=providers)
        delib = LLMDeliberator(config)
        delib(_action(), _ctx(), _scores(), 0.5)

        audit = delib.last_audit
        assert audit is not None
        assert len(audit["responses"]) == 2
        verdicts_in_audit = {r["verdict"] for r in audit["responses"]}
        assert "ALLOW" in verdicts_in_audit
        assert "MODIFY" in verdicts_in_audit

    def test_audit_records_errors(self):
        """Error responses are recorded in audit."""
        def failing_call(prompt: str) -> str:
            raise RuntimeError("LLM failed")

        providers = [
            LLMProviderConfig("good", "m-g", _make_llm_callable("ALLOW"), weight=1.0),
            LLMProviderConfig("bad", "m-b", failing_call, weight=1.0),
        ]
        config = _make_config(providers=providers)
        delib = LLMDeliberator(config)
        delib(_action(), _ctx(), _scores(), 0.5)

        audit = delib.last_audit
        assert audit is not None
        error_responses = [r for r in audit["responses"] if r["error"] is not None]
        assert len(error_responses) >= 1


class TestResponseParsing:
    """Response parsing edge cases."""

    def test_parses_json_in_markdown_code_block(self):
        """LLM response wrapped in code blocks is parsed correctly."""
        def markdown_call(prompt: str) -> str:
            return '```json\n{"verdict": "MODIFY", "reasoning": "needs changes"}\n```'

        providers = [
            LLMProviderConfig("a", "m-a", markdown_call, weight=1.0),
            LLMProviderConfig("b", "m-b", markdown_call, weight=1.0),
        ]
        config = _make_config(providers=providers)
        delib = LLMDeliberator(config)
        result = delib(_action(), _ctx(), _scores(), 0.5)
        assert result == Verdict.MODIFY

    def test_parses_plain_text_verdict(self):
        """Falls back to extracting verdict from plain text."""
        def text_call(prompt: str) -> str:
            return "I think we should ALLOW this action because it is safe."

        providers = [
            LLMProviderConfig("a", "m-a", text_call, weight=1.0),
            LLMProviderConfig("b", "m-b", text_call, weight=1.0),
        ]
        config = _make_config(providers=providers)
        delib = LLMDeliberator(config)
        result = delib(_action(), _ctx(), _scores(), 0.5)
        assert result == Verdict.ALLOW

    def test_invalid_verdict_string_ignored(self):
        """Invalid verdict strings result in None for that response."""
        def bad_verdict(prompt: str) -> str:
            return json.dumps({"verdict": "MAYBE", "reasoning": "unsure"})

        providers = [
            LLMProviderConfig("a", "m-a", bad_verdict, weight=1.0),
            LLMProviderConfig("b", "m-b", _make_llm_callable("ALLOW"), weight=1.0),
        ]
        config = _make_config(providers=providers)
        delib = LLMDeliberator(config)
        result = delib(_action(), _ctx(), _scores(), 0.5)
        # Only model b has a valid verdict; with 1 valid model at weight 1.0,
        # agreement is 1.0 >= 0.67
        assert result == Verdict.ALLOW


class TestRuntimeIntegration:
    """Integration with GovernanceRuntime config."""

    def test_runtime_auto_registers_when_enabled(self):
        """When llm_deliberation is enabled, the runtime auto-registers it."""
        providers = [
            LLMProviderConfig("a", "m-a", _make_llm_callable("ALLOW"), weight=1.0),
            LLMProviderConfig("b", "m-b", _make_llm_callable("ALLOW"), weight=1.0),
        ]
        llm_config = LLMDeliberationConfig(
            enabled=True,
            providers=providers,
        )
        runtime_config = RuntimeConfig(llm_deliberation=llm_config)
        runtime = GovernanceRuntime(config=runtime_config)

        assert runtime._llm_deliberator is not None
        assert len(runtime.tier_three._deliberators) == 1

    def test_runtime_disabled_no_registration(self):
        """When disabled, no deliberator is registered."""
        llm_config = LLMDeliberationConfig(enabled=False)
        runtime_config = RuntimeConfig(llm_deliberation=llm_config)
        runtime = GovernanceRuntime(config=runtime_config)

        assert runtime._llm_deliberator is None
        assert len(runtime.tier_three._deliberators) == 0

    def test_runtime_none_config_no_registration(self):
        """When llm_deliberation is None, no deliberator is registered."""
        runtime = GovernanceRuntime()
        assert runtime._llm_deliberator is None
        assert len(runtime.tier_three._deliberators) == 0


class TestDriftInPrompt:
    """Test that drift data is included in prompts when available."""

    def test_drift_dict_in_context(self):
        """Drift data from context.metadata is included in prompt."""
        captured = []

        def capturing_call(prompt: str) -> str:
            captured.append(prompt)
            return json.dumps({"verdict": "ALLOW", "reasoning": "ok"})

        providers = [
            LLMProviderConfig("a", "m-a", capturing_call, weight=1.0),
        ]
        config = _make_config(providers=providers)
        delib = LLMDeliberator(config)

        ctx = _ctx()
        ctx.metadata["drift"] = {"overall": 0.42, "severity": "moderate"}
        delib(_action(), ctx, _scores(), 0.5)

        prompt = captured[0]
        assert "0.42" in prompt
        assert "moderate" in prompt

    def test_no_drift_shows_not_available(self):
        """Without drift data, prompt says 'No drift data available'."""
        captured = []

        def capturing_call(prompt: str) -> str:
            captured.append(prompt)
            return json.dumps({"verdict": "ALLOW", "reasoning": "ok"})

        providers = [
            LLMProviderConfig("a", "m-a", capturing_call, weight=1.0),
        ]
        config = _make_config(providers=providers)
        delib = LLMDeliberator(config)
        delib(_action(), _ctx(), _scores(), 0.5)

        prompt = captured[0]
        assert "No drift data available" in prompt
