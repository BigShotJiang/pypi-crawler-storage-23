"""Tests for framework integrations — CrewAI, LangGraph/LangChain, and AutoGen adapters."""

import pytest

from nomotic.authority import CertificateAuthority
from nomotic.executor import GovernedToolExecutor
from nomotic.keys import SigningKey
from nomotic.sandbox import AgentConfig, save_agent_config
from nomotic.store import FileCertificateStore


def _setup_agent(
    tmp_path,
    agent_id: str = "TestBot",
    actions: list[str] | None = None,
    boundaries: list[str] | None = None,
) -> str:
    """Create a certificate and config for an agent in tmp_path.

    Returns the certificate ID.
    """
    sk, _vk = SigningKey.generate()
    store = FileCertificateStore(tmp_path)
    ca = CertificateAuthority(issuer_id="test-issuer", signing_key=sk, store=store)

    cert, _agent_sk = ca.issue(
        agent_id=agent_id,
        archetype="general",
        organization="test-org",
        zone_path="global",
        owner="test-owner",
    )

    if actions is None:
        actions = ["read", "write", "query"]
    config = AgentConfig(
        agent_id=agent_id,
        actions=actions,
        boundaries=boundaries or [],
    )
    save_agent_config(tmp_path, config)

    return cert.certificate_id


# ── Mock tool classes ────────────────────────────────────────────────


class MockCrewAITool:
    """Minimal mock of a CrewAI Tool with _run method."""

    def __init__(self, name: str, return_value: str = "ok"):
        self.name = name
        self._return_value = return_value

    def _run(self, *args, **kwargs):
        return self._return_value


class MockCrewAIToolWithRun:
    """Mock CrewAI tool that uses .run instead of ._run."""

    def __init__(self, name: str, return_value: str = "ok"):
        self.name = name
        self._return_value = return_value

    def run(self, *args, **kwargs):
        return self._return_value


class MockLangChainTool:
    """Minimal mock of a LangChain BaseTool."""

    def __init__(self, name: str, return_value: str = "ok"):
        self.name = name
        self._return_value = return_value

    def _run(self, query: str, **kwargs) -> str:
        return self._return_value


# ── CrewAI Adapter Tests ─────────────────────────────────────────────


class TestCrewAIAdapter:
    def test_govern_tools_returns_same_count(self, tmp_path):
        """Wrapping tools preserves the number of tools."""
        _setup_agent(tmp_path, "TestBot", actions=["web_search", "read_file"])
        from nomotic.integrations.crewai_adapter import govern_crewai_tools

        tools = [MockCrewAITool("web_search"), MockCrewAITool("read_file")]
        governed = govern_crewai_tools("TestBot", tools, base_dir=str(tmp_path))
        assert len(governed) == 2

    def test_allowed_tool_executes(self, tmp_path):
        """Tool function runs when governance approves."""
        _setup_agent(tmp_path, "TestBot", actions=["web_search"])
        from nomotic.integrations.crewai_adapter import govern_crewai_tools

        tools = [MockCrewAITool("web_search", return_value="search results")]
        governed = govern_crewai_tools("TestBot", tools, base_dir=str(tmp_path))

        result = governed[0]._run("test query")
        assert result == "search results"

    def test_denied_tool_returns_message(self, tmp_path):
        """Denied tool returns a governance denial message."""
        _setup_agent(tmp_path, "TestBot", actions=["read"])
        from nomotic.integrations.crewai_adapter import govern_crewai_tools

        tools = [MockCrewAITool("delete_everything", return_value="destroyed")]
        governed = govern_crewai_tools("TestBot", tools, base_dir=str(tmp_path))

        result = governed[0]._run("all-data")
        assert "[GOVERNANCE DENIED]" in result

    def test_wraps_run_method_fallback(self, tmp_path):
        """Falls back to .run when ._run is not available."""
        _setup_agent(tmp_path, "TestBot", actions=["web_search"])
        from nomotic.integrations.crewai_adapter import govern_crewai_tools

        tools = [MockCrewAIToolWithRun("web_search", return_value="results")]
        governed = govern_crewai_tools("TestBot", tools, base_dir=str(tmp_path))

        result = governed[0].run("query")
        assert result == "results"

    def test_target_from_kwargs(self, tmp_path):
        """Target is extracted from keyword arguments."""
        _setup_agent(tmp_path, "TestBot", actions=["web_search"])
        from nomotic.integrations.crewai_adapter import govern_crewai_tools

        tools = [MockCrewAITool("web_search", return_value="found it")]
        governed = govern_crewai_tools("TestBot", tools, base_dir=str(tmp_path))

        # The "query" kwarg should be picked up as the governance target
        result = governed[0]._run(query="nomotic governance")
        assert result == "found it"

    def test_preserves_tool_name(self, tmp_path):
        """Tool name attribute is preserved after wrapping."""
        _setup_agent(tmp_path, "TestBot", actions=["my_tool"])
        from nomotic.integrations.crewai_adapter import govern_crewai_tools

        tools = [MockCrewAITool("my_tool")]
        governed = govern_crewai_tools("TestBot", tools, base_dir=str(tmp_path))

        assert governed[0].name == "my_tool"

    def test_test_mode(self, tmp_path):
        """test_mode parameter is passed through to executor."""
        _setup_agent(tmp_path, "TestBot", actions=["web_search"])
        from nomotic.integrations.crewai_adapter import govern_crewai_tools

        tools = [MockCrewAITool("web_search", return_value="ok")]
        # Should not raise — test_mode uses simulated trust
        governed = govern_crewai_tools(
            "TestBot", tools, base_dir=str(tmp_path), test_mode=True
        )
        result = governed[0]._run("test")
        assert isinstance(result, str)


# ── LangGraph Adapter Tests ──────────────────────────────────────────


class TestLangGraphAdapter:
    def test_governance_node_returns_state(self, tmp_path):
        """Governance node returns state with governance_result key."""
        _setup_agent(tmp_path, "TestBot", actions=["read"])
        from nomotic.integrations.langgraph_adapter import governance_node

        node_fn = governance_node("TestBot", base_dir=str(tmp_path))
        state = {"pending_action": "read", "pending_target": "test_db"}
        result = node_fn(state)

        assert "governance_result" in result
        gov = result["governance_result"]
        assert "allowed" in gov
        assert "verdict" in gov
        assert "reason" in gov
        assert "ucs" in gov
        assert "trust" in gov

    def test_governance_node_allowed(self, tmp_path):
        """Governance node allows actions within scope."""
        _setup_agent(tmp_path, "TestBot", actions=["read_file"])
        from nomotic.integrations.langgraph_adapter import governance_node

        node_fn = governance_node("TestBot", base_dir=str(tmp_path))
        state = {"pending_action": "read_file", "pending_target": "report.csv"}
        result = node_fn(state)

        assert result["governance_result"]["allowed"] is True
        assert result["governance_result"]["verdict"] == "ALLOW"

    def test_governance_node_denied(self, tmp_path):
        """Governance node denies actions outside scope."""
        _setup_agent(tmp_path, "TestBot", actions=["read"])
        from nomotic.integrations.langgraph_adapter import governance_node

        node_fn = governance_node("TestBot", base_dir=str(tmp_path))
        state = {"pending_action": "delete_database", "pending_target": "production"}
        result = node_fn(state)

        assert result["governance_result"]["allowed"] is False

    def test_governance_node_custom_keys(self, tmp_path):
        """Custom state keys are used when specified."""
        _setup_agent(tmp_path, "TestBot", actions=["query"])
        from nomotic.integrations.langgraph_adapter import governance_node

        node_fn = governance_node(
            "TestBot",
            base_dir=str(tmp_path),
            action_key="my_action",
            target_key="my_target",
            result_key="my_result",
        )
        state = {"my_action": "query", "my_target": "customers"}
        result = node_fn(state)

        assert "my_result" in result

    def test_route_on_governance_allow(self):
        """route_on_governance returns 'execute' when allowed."""
        from nomotic.integrations.langgraph_adapter import route_on_governance

        state = {"governance_result": {"allowed": True}}
        assert route_on_governance(state) == "execute"

    def test_route_on_governance_deny(self):
        """route_on_governance returns 'denied' when not allowed."""
        from nomotic.integrations.langgraph_adapter import route_on_governance

        state = {"governance_result": {"allowed": False}}
        assert route_on_governance(state) == "denied"

    def test_route_on_governance_missing_result(self):
        """route_on_governance defaults to 'denied' when result is missing."""
        from nomotic.integrations.langgraph_adapter import route_on_governance

        state = {}
        assert route_on_governance(state) == "denied"

    def test_route_on_governance_custom_key(self):
        """route_on_governance uses custom result key."""
        from nomotic.integrations.langgraph_adapter import route_on_governance

        state = {"my_gov": {"allowed": True}}
        assert route_on_governance(state, result_key="my_gov") == "execute"


# ── LangChain Tool Wrapping Tests ────────────────────────────────────


class TestLangChainAdapter:
    def test_govern_tools_returns_same_count(self, tmp_path):
        """Wrapping tools preserves the number of tools."""
        _setup_agent(tmp_path, "TestBot", actions=["search", "lookup"])
        from nomotic.integrations.langgraph_adapter import govern_langchain_tools

        tools = [MockLangChainTool("search"), MockLangChainTool("lookup")]
        governed = govern_langchain_tools("TestBot", tools, base_dir=str(tmp_path))
        assert len(governed) == 2

    def test_allowed_tool_executes(self, tmp_path):
        """LangChain tool runs when governance approves."""
        _setup_agent(tmp_path, "TestBot", actions=["search"])
        from nomotic.integrations.langgraph_adapter import govern_langchain_tools

        tools = [MockLangChainTool("search", return_value="found results")]
        governed = govern_langchain_tools("TestBot", tools, base_dir=str(tmp_path))

        result = governed[0]._run("test query")
        assert result == "found results"

    def test_denied_tool_returns_message(self, tmp_path):
        """Denied LangChain tool returns governance message."""
        _setup_agent(tmp_path, "TestBot", actions=["read"])
        from nomotic.integrations.langgraph_adapter import govern_langchain_tools

        tools = [MockLangChainTool("nuke_server", return_value="boom")]
        governed = govern_langchain_tools("TestBot", tools, base_dir=str(tmp_path))

        result = governed[0]._run("production")
        assert "[GOVERNANCE DENIED]" in result

    def test_preserves_tool_name(self, tmp_path):
        """Tool name is preserved after wrapping."""
        _setup_agent(tmp_path, "TestBot", actions=["search"])
        from nomotic.integrations.langgraph_adapter import govern_langchain_tools

        tools = [MockLangChainTool("search")]
        governed = govern_langchain_tools("TestBot", tools, base_dir=str(tmp_path))

        assert governed[0].name == "search"


# ── AutoGen Adapter Tests ────────────────────────────────────────────


class TestAutoGenAdapter:
    def test_import_without_autogen(self):
        """Module imports successfully even without AutoGen installed."""
        from nomotic.integrations.autogen_adapter import GovernedAutoGenAgent

        assert GovernedAutoGenAgent is not None

    def test_init_raises_without_autogen(self, tmp_path):
        """GovernedAutoGenAgent raises ImportError if autogen not installed."""
        from nomotic.integrations.autogen_adapter import GovernedAutoGenAgent

        _setup_agent(tmp_path, "TestBot")

        # AutoGen is not installed in this test environment,
        # so initialization should raise ImportError
        with pytest.raises(ImportError, match="AutoGen is required"):
            GovernedAutoGenAgent(
                name="test",
                nomotic_agent_id="TestBot",
                base_dir=str(tmp_path),
            )


# ── Integration Import Tests ─────────────────────────────────────────


class TestIntegrationImports:
    def test_import_crewai_adapter(self):
        """CrewAI adapter public functions are importable."""
        from nomotic.integrations.crewai_adapter import govern_crewai_tools

        assert govern_crewai_tools is not None

    def test_import_langgraph_adapter(self):
        """LangGraph adapter public functions are importable."""
        from nomotic.integrations.langgraph_adapter import (
            governance_node,
            govern_langchain_tools,
            route_on_governance,
        )

        assert governance_node is not None
        assert route_on_governance is not None
        assert govern_langchain_tools is not None

    def test_import_autogen_adapter(self):
        """AutoGen adapter public class is importable."""
        from nomotic.integrations.autogen_adapter import GovernedAutoGenAgent

        assert GovernedAutoGenAgent is not None

    def test_integrations_init_imports(self):
        """Integrations package __init__ is importable."""
        import nomotic.integrations

        assert nomotic.integrations is not None
