"""Tests for compliance-aligned presets and severity tiers."""

from __future__ import annotations

import pytest

from nomotic.presets import (
    DIMENSION_NAMES,
    PRESET_DISCLAIMER,
    TRUST_SETTING_KEYS,
    GovernancePreset,
    get_preset,
    get_preset_names,
    list_compliance_presets,
    list_presets,
    list_severity_presets,
    merge_presets,
)
from nomotic.runtime import GovernanceRuntime, RuntimeConfig
from nomotic.types import Action, AgentContext, TrustProfile, Verdict


# ---------------------------------------------------------------------------
# Canonical preset names (new _aligned convention for compliance)
# ---------------------------------------------------------------------------

ALL_PRESET_NAMES = [
    "soc2_aligned", "hipaa_aligned", "pci_dss_aligned", "iso27001_aligned",
    "standard", "strict", "ultra_strict",
]

COMPLIANCE_NAMES = ["soc2_aligned", "hipaa_aligned", "pci_dss_aligned", "iso27001_aligned"]
SEVERITY_NAMES = ["standard", "strict", "ultra_strict"]


# ---------------------------------------------------------------------------
# All 7 preset names are retrievable
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("name", ALL_PRESET_NAMES)
def test_preset_retrievable(name: str) -> None:
    preset = get_preset(name)
    assert isinstance(preset, GovernancePreset)
    assert preset.name == name


# ---------------------------------------------------------------------------
# Each preset has all 13 dimensions defined in weights
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("name", ALL_PRESET_NAMES)
def test_preset_has_all_13_dimensions(name: str) -> None:
    preset = get_preset(name)
    assert set(preset.dimension_weights.keys()) == set(DIMENSION_NAMES)
    assert len(preset.dimension_weights) == 13


# ---------------------------------------------------------------------------
# Each preset's veto dimensions are a subset of the 13 dimensions
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("name", ALL_PRESET_NAMES)
def test_preset_veto_dimensions_valid(name: str) -> None:
    preset = get_preset(name)
    assert set(preset.veto_dimensions).issubset(set(DIMENSION_NAMES))


# ---------------------------------------------------------------------------
# Each preset's allow_threshold > deny_threshold
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("name", ALL_PRESET_NAMES)
def test_preset_thresholds(name: str) -> None:
    preset = get_preset(name)
    assert preset.allow_threshold > preset.deny_threshold


# ---------------------------------------------------------------------------
# Each preset's trust settings have all required keys
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("name", ALL_PRESET_NAMES)
def test_preset_trust_settings_keys(name: str) -> None:
    preset = get_preset(name)
    assert set(preset.trust_settings.keys()) >= TRUST_SETTING_KEYS


# ---------------------------------------------------------------------------
# get_preset is case-insensitive (canonical names)
# ---------------------------------------------------------------------------

def test_get_preset_case_insensitive() -> None:
    p1 = get_preset("hipaa_aligned")
    p2 = get_preset("HIPAA_ALIGNED")
    p3 = get_preset("Hipaa_Aligned")
    assert p1 is p2
    assert p2 is p3
    assert p1.name == "hipaa_aligned"


# ---------------------------------------------------------------------------
# get_preset raises KeyError for unknown presets
# ---------------------------------------------------------------------------

def test_get_preset_unknown_raises_key_error() -> None:
    with pytest.raises(KeyError, match="Unknown preset"):
        get_preset("nonexistent_preset")


# ---------------------------------------------------------------------------
# list_compliance_presets returns 4 presets with _aligned names
# ---------------------------------------------------------------------------

def test_list_compliance_presets() -> None:
    presets = list_compliance_presets()
    assert len(presets) == 4
    names = {p.name for p in presets}
    assert names == {"soc2_aligned", "hipaa_aligned", "pci_dss_aligned", "iso27001_aligned"}


# ---------------------------------------------------------------------------
# list_severity_presets returns 3 presets
# ---------------------------------------------------------------------------

def test_list_severity_presets() -> None:
    presets = list_severity_presets()
    assert len(presets) == 3
    names = {p.name for p in presets}
    assert names == {"standard", "strict", "ultra_strict"}


# ---------------------------------------------------------------------------
# list_presets returns all 7
# ---------------------------------------------------------------------------

def test_list_presets() -> None:
    presets = list_presets()
    assert len(presets) == 7


# ---------------------------------------------------------------------------
# get_preset_names returns all names
# ---------------------------------------------------------------------------

def test_get_preset_names() -> None:
    names = get_preset_names()
    assert len(names) == 7
    for n in ALL_PRESET_NAMES:
        assert n in names


# ---------------------------------------------------------------------------
# merge_presets correctly unions vetoes
# ---------------------------------------------------------------------------

def test_merge_presets_unions_vetoes() -> None:
    soc2 = get_preset("soc2_aligned")
    hipaa = get_preset("hipaa_aligned")
    merged = merge_presets(soc2, hipaa)
    expected_vetoes = set(soc2.veto_dimensions) | set(hipaa.veto_dimensions)
    assert set(merged.veto_dimensions) == expected_vetoes


# ---------------------------------------------------------------------------
# merge_presets takes max weights from all presets
# ---------------------------------------------------------------------------

def test_merge_presets_max_weights() -> None:
    soc2 = get_preset("soc2_aligned")
    standard = get_preset("standard")
    merged = merge_presets(standard, soc2)
    for dim in DIMENSION_NAMES:
        assert merged.dimension_weights[dim] == max(
            soc2.dimension_weights[dim],
            standard.dimension_weights[dim],
        )


# ---------------------------------------------------------------------------
# merge_presets takes strictest thresholds
# ---------------------------------------------------------------------------

def test_merge_presets_strictest_thresholds() -> None:
    strict = get_preset("strict")
    hipaa = get_preset("hipaa_aligned")
    merged = merge_presets(strict, hipaa)
    assert merged.allow_threshold == max(strict.allow_threshold, hipaa.allow_threshold)
    assert merged.deny_threshold == max(strict.deny_threshold, hipaa.deny_threshold)


# ---------------------------------------------------------------------------
# merge_presets most conservative trust settings
# ---------------------------------------------------------------------------

def test_merge_presets_conservative_trust() -> None:
    strict = get_preset("strict")
    hipaa = get_preset("hipaa_aligned")
    merged = merge_presets(strict, hipaa)
    assert merged.trust_settings["violation_decrement"] == max(
        strict.trust_settings["violation_decrement"],
        hipaa.trust_settings["violation_decrement"],
    )
    assert merged.trust_settings["success_increment"] == min(
        strict.trust_settings["success_increment"],
        hipaa.trust_settings["success_increment"],
    )
    assert merged.trust_settings["interrupt_cost"] == max(
        strict.trust_settings["interrupt_cost"],
        hipaa.trust_settings["interrupt_cost"],
    )


# ---------------------------------------------------------------------------
# RuntimeConfig.from_preset("soc2_aligned") creates a valid config
# ---------------------------------------------------------------------------

def test_runtime_config_from_preset_soc2() -> None:
    config = RuntimeConfig.from_preset("soc2_aligned")
    assert isinstance(config, RuntimeConfig)
    assert config.allow_threshold == 0.75
    assert config.deny_threshold == 0.35
    assert config.dimension_weights is not None
    assert len(config.dimension_weights) == 13
    assert config.veto_dimensions is not None


# ---------------------------------------------------------------------------
# RuntimeConfig.from_preset with overrides
# ---------------------------------------------------------------------------

def test_runtime_config_from_preset_with_overrides() -> None:
    config = RuntimeConfig.from_preset("hipaa_aligned", allow_threshold=0.9)
    assert config.allow_threshold == 0.9
    # deny_threshold should still come from the preset
    assert config.deny_threshold == 0.30


# ---------------------------------------------------------------------------
# GovernanceRuntime from preset constructs without error
# ---------------------------------------------------------------------------

def test_governance_runtime_from_preset() -> None:
    config = RuntimeConfig.from_preset("soc2_aligned")
    runtime = GovernanceRuntime(config)
    assert runtime is not None
    # Verify weights were applied to the registry
    scope = runtime.registry.get("scope_compliance")
    assert scope is not None
    assert scope.weight == 2.0


# ---------------------------------------------------------------------------
# Verify the runtime uses preset weights during evaluation
# ---------------------------------------------------------------------------

def test_runtime_uses_preset_weights_for_evaluation() -> None:
    """Create runtime from a preset with high scope_compliance weight,
    evaluate an out-of-scope action, verify it gets denied."""
    config = RuntimeConfig.from_preset("soc2_aligned")
    runtime = GovernanceRuntime(config)

    # Configure scope: agent-1 can only "read"
    scope_dim = runtime.registry.get("scope_compliance")
    scope_dim.configure_agent_scope("agent-1", {"read"})

    # Attempt an out-of-scope action: "delete"
    action = Action(
        agent_id="agent-1",
        action_type="delete",
        target="critical-data",
    )
    context = AgentContext(
        agent_id="agent-1",
        trust_profile=TrustProfile(agent_id="agent-1", overall_trust=0.5),
    )

    verdict = runtime.evaluate(action, context)
    assert verdict.verdict == Verdict.DENY

    # Verify the scope_compliance dimension vetoed it
    scope_scores = [
        s for s in verdict.dimension_scores if s.dimension_name == "scope_compliance"
    ]
    assert len(scope_scores) == 1
    assert scope_scores[0].veto is True
    assert scope_scores[0].score == 0.0


# ---------------------------------------------------------------------------
# Verify preset veto dimensions are applied to the runtime
# ---------------------------------------------------------------------------

def test_runtime_applies_preset_veto_dimensions() -> None:
    config = RuntimeConfig.from_preset("soc2_aligned")
    runtime = GovernanceRuntime(config)

    soc2 = get_preset("soc2_aligned")
    for dim in runtime.registry.dimensions:
        if dim.name in soc2.veto_dimensions:
            assert dim.can_veto is True, f"{dim.name} should have veto authority"
        else:
            assert dim.can_veto is False, f"{dim.name} should NOT have veto authority"


# ---------------------------------------------------------------------------
# Verify preset trust settings flow to TrustConfig
# ---------------------------------------------------------------------------

def test_preset_trust_settings_flow_to_trust_config() -> None:
    config = RuntimeConfig.from_preset("hipaa_aligned")
    assert config.trust_config.violation_decrement == 0.08
    assert config.trust_config.success_increment == 0.005
    assert config.trust_config.interrupt_decrement == 0.04
    assert config.trust_config.decay_rate == 0.001
    assert config.trust_config.min_trust == 0.05
    assert config.trust_config.max_trust == 0.92


# ---------------------------------------------------------------------------
# merge_presets with a single preset returns that preset
# ---------------------------------------------------------------------------

def test_merge_single_preset_returns_same() -> None:
    soc2 = get_preset("soc2_aligned")
    merged = merge_presets(soc2)
    assert merged is soc2


# ---------------------------------------------------------------------------
# merge_presets with no presets raises ValueError
# ---------------------------------------------------------------------------

def test_merge_no_presets_raises() -> None:
    with pytest.raises(ValueError, match="at least one preset"):
        merge_presets()


# ---------------------------------------------------------------------------
# ultra_strict has all 13 dimensions as vetoes
# ---------------------------------------------------------------------------

def test_ultra_strict_all_vetoes() -> None:
    preset = get_preset("ultra_strict")
    assert set(preset.veto_dimensions) == set(DIMENSION_NAMES)


# ---------------------------------------------------------------------------
# GovernancePreset is frozen (immutable)
# ---------------------------------------------------------------------------

def test_preset_is_frozen() -> None:
    preset = get_preset("soc2_aligned")
    with pytest.raises(AttributeError):
        preset.name = "modified"  # type: ignore[misc]


# ---------------------------------------------------------------------------
# Merged preset category is "merged"
# ---------------------------------------------------------------------------

def test_merged_preset_category() -> None:
    merged = merge_presets(get_preset("strict"), get_preset("hipaa_aligned"))
    assert merged.category == "merged"


# ---------------------------------------------------------------------------
# All presets construct valid runtimes
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("name", ALL_PRESET_NAMES)
def test_all_presets_construct_runtimes(name: str) -> None:
    config = RuntimeConfig.from_preset(name)
    runtime = GovernanceRuntime(config)
    assert runtime is not None


# ===========================================================================
# Tests for _aligned naming and disclaimer
# ===========================================================================


# ---------------------------------------------------------------------------
# All compliance presets have _aligned suffix in their name field
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("name", COMPLIANCE_NAMES)
def test_compliance_preset_aligned_suffix(name: str) -> None:
    preset = get_preset(name)
    assert preset.name.endswith("_aligned"), f"{preset.name} should end with _aligned"


# ---------------------------------------------------------------------------
# All compliance presets have certified=False
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("name", COMPLIANCE_NAMES)
def test_compliance_preset_certified_false(name: str) -> None:
    preset = get_preset(name)
    assert preset.certified is False


# ---------------------------------------------------------------------------
# All compliance presets have non-empty disclaimer
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("name", COMPLIANCE_NAMES)
def test_compliance_preset_has_disclaimer(name: str) -> None:
    preset = get_preset(name)
    assert preset.disclaimer != ""
    assert preset.disclaimer == PRESET_DISCLAIMER


# ---------------------------------------------------------------------------
# All compliance presets have non-empty framework_reference
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("name", COMPLIANCE_NAMES)
def test_compliance_preset_has_framework_reference(name: str) -> None:
    preset = get_preset(name)
    assert preset.framework_reference != ""


# ---------------------------------------------------------------------------
# Severity presets have empty disclaimer and framework_reference
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("name", SEVERITY_NAMES)
def test_severity_preset_empty_disclaimer_and_reference(name: str) -> None:
    preset = get_preset(name)
    assert preset.disclaimer == ""
    assert preset.framework_reference == ""


# ---------------------------------------------------------------------------
# Severity presets also have certified=False
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("name", SEVERITY_NAMES)
def test_severity_preset_certified_false(name: str) -> None:
    preset = get_preset(name)
    assert preset.certified is False


# ---------------------------------------------------------------------------
# Old framework names (without _aligned) raise KeyError
# ---------------------------------------------------------------------------

def test_old_name_hipaa_raises_key_error() -> None:
    with pytest.raises(KeyError, match="Unknown preset"):
        get_preset("HIPAA")


def test_old_name_soc2_raises_key_error() -> None:
    with pytest.raises(KeyError, match="Unknown preset"):
        get_preset("soc2")


def test_old_name_pci_dss_raises_key_error() -> None:
    with pytest.raises(KeyError, match="Unknown preset"):
        get_preset("PCI_DSS")


def test_old_name_pci_dss_hyphen_raises_key_error() -> None:
    with pytest.raises(KeyError, match="Unknown preset"):
        get_preset("pci-dss")


def test_old_name_iso27001_raises_key_error() -> None:
    with pytest.raises(KeyError, match="Unknown preset"):
        get_preset("ISO27001")


# ---------------------------------------------------------------------------
# list_compliance_presets returns presets with _aligned names
# ---------------------------------------------------------------------------

def test_list_compliance_presets_aligned_names() -> None:
    presets = list_compliance_presets()
    for p in presets:
        assert p.name.endswith("_aligned"), f"{p.name} should end with _aligned"


# ---------------------------------------------------------------------------
# RuntimeConfig.from_preset with canonical names works
# ---------------------------------------------------------------------------

def test_runtime_config_from_preset_canonical_hipaa() -> None:
    config = RuntimeConfig.from_preset("hipaa_aligned")
    assert isinstance(config, RuntimeConfig)
    assert config.allow_threshold == 0.80


# ---------------------------------------------------------------------------
# RuntimeConfig.from_preset with old names raises KeyError
# ---------------------------------------------------------------------------

def test_runtime_config_from_preset_old_hipaa_raises() -> None:
    with pytest.raises(KeyError, match="Unknown preset"):
        RuntimeConfig.from_preset("HIPAA")


def test_runtime_config_from_preset_old_soc2_raises() -> None:
    with pytest.raises(KeyError, match="Unknown preset"):
        RuntimeConfig.from_preset("SOC2")


# ---------------------------------------------------------------------------
# All compliance presets have display_name set
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("name", COMPLIANCE_NAMES)
def test_compliance_preset_has_display_name(name: str) -> None:
    preset = get_preset(name)
    assert preset.display_name != ""
    assert preset.display_name != preset.name  # display_name should differ from canonical name


# ---------------------------------------------------------------------------
# PRESET_DISCLAIMER is a non-empty string
# ---------------------------------------------------------------------------

def test_preset_disclaimer_constant() -> None:
    assert isinstance(PRESET_DISCLAIMER, str)
    assert len(PRESET_DISCLAIMER) > 0
    assert "not certified" in PRESET_DISCLAIMER.lower() or "not" in PRESET_DISCLAIMER.lower()
