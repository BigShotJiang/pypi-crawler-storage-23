# Contributor Covenant Code of Conduct

This project has adopted the [Contributor Covenant](https://www.contributor-covenant.org/), version 2.1, as its Code of Conduct.

The full text is available at: https://www.contributor-covenant.org/version/2/1/code_of_conduct/

## Reporting

Instances of unacceptable behavior may be reported to the project team at conduct@nomotic.ai. All complaints will be reviewed and investigated and will result in a response that is deemed necessary and appropriate to the circumstances.

## Enforcement

Project maintainers who do not follow or enforce the Code of Conduct in good faith may face temporary or permanent repercussions as determined by other members of the project's leadership.
