Trust Calibration
=================

.. automodule:: nomotic.trust
   :members:
   :show-inheritance:
