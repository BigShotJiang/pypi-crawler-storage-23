#!/usr/bin/env python3
"""AutoGen + Nomotic Governance Example.

Shows how to wrap an AutoGen AssistantAgent with Nomotic governance.
Every function call the agent makes is evaluated through the governance
pipeline before execution.

Prerequisites:
    pip install nomotic pyautogen

Usage:
    python examples/autogen_governed.py

Note:
    This example requires the `pyautogen` package. Since AutoGen
    may not be installed in all environments, this script demonstrates
    the integration pattern and the GovernedAutoGenAgent API.
"""

from __future__ import annotations

# ── Without governance (standard AutoGen) ────────────────────────────
#
#   from autogen import AssistantAgent
#
#   agent = AssistantAgent(
#       name="researcher",
#       llm_config=llm_config,
#       system_message="You are a research assistant.",
#   )
#
# ── With governance (3-line change) ──────────────────────────────────
#
#   from nomotic.integrations.autogen_adapter import GovernedAutoGenAgent
#
#   wrapper = GovernedAutoGenAgent(
#       name="researcher",
#       nomotic_agent_id="claims-bot",   # <-- add this
#       llm_config=llm_config,
#       system_message="You are a research assistant.",
#   )
#   agent = wrapper.agent  # use this in your AutoGen workflow
#
# Every function call the agent makes is now governed by Nomotic.

if __name__ == "__main__":
    print("AutoGen + Nomotic Governance Example")
    print("=" * 50)
    print()
    print("This example shows the integration pattern.")
    print("To run with a real AutoGen agent, install pyautogen")
    print("and provide an LLM config with your API key.")
    print()
    print("Integration code (3 lines):")
    print()
    print("  from nomotic.integrations.autogen_adapter import GovernedAutoGenAgent")
    print()
    print('  wrapper = GovernedAutoGenAgent(')
    print('      name="researcher",')
    print('      nomotic_agent_id="claims-bot",')
    print('      llm_config=llm_config,')
    print('  )')
    print('  agent = wrapper.agent')
    print()
    print("Every function call made by the agent is evaluated through")
    print("Nomotic's 13-dimension governance pipeline before execution.")
    print("Denied calls return an error message instead of executing.")
