# Contributing to Nomotic

Thank you for your interest in contributing to Nomotic. This document covers the process for contributing to this project.

## Quick Start for Contributors

1. Clone: `git clone https://git.nomotic.ai/nomotic/core.git`
2. Install dev deps: `pip install -e ".[dev]"`
3. Run tests: `pytest`
4. Check types: `mypy src/nomotic/`

## Project Structure

```
src/nomotic/
├── runtime.py              # Core governance pipeline
├── evaluator.py            # Protocol reasoning evaluator
├── executor.py             # GovernedToolExecutor (agent integration)
├── cli.py                  # CLI commands (nomotic birth, verify, serve...)
├── api.py                  # HTTP API server
├── sdk.py                  # GovernedAgent HTTP client
├── audit_store.py          # Persistent hash-chained audit logs
├── audit.py                # In-memory audit trail
├── workflow_governor.py    # Multi-step workflow governance
├── dimensions.py           # 13 governance dimension definitions
├── drift.py                # Behavioral drift detection
├── fingerprint.py          # Agent behavioral fingerprinting
├── trust.py                # Trust score management
├── bias.py                 # Governance rule bias detection
├── equity.py               # Outcome equity analysis
├── certificate.py          # Agent identity certificates
├── token.py                # JWT governance tokens
├── interrupt.py            # Mid-execution interruption
├── monitor.py              # Drift monitoring and alerts
├── cross_dimensional.py    # Cross-dimension signal detection
├── context_profile.py      # 10 types of situational context
├── contextual_modifier.py  # Per-evaluation weight adjustment
├── protocol.py             # Nomotic Protocol (reasoning artifacts)
├── types.py                # Core data structures
├── tiers.py                # Three-tier evaluation cascade
├── ucs.py                  # Unified Confidence Score engine
├── middleware.py            # Gateway middleware
├── proxy.py                # HTTP governance proxy
├── mcp_proxy.py            # Model Context Protocol proxy
├── integrations/           # Framework adapters (CrewAI, LangGraph, AutoGen)
└── adapters/               # Web framework adapters (FastAPI, Flask)
```

## How to Contribute

### Bug Reports

- Use the Bug Report issue template
- Include: Python version, OS, minimal reproduction, full traceback
- If governance-related: include the action, agent config, and verdict

### Feature Requests

- Use the Feature Request issue template
- Explain the governance problem it solves, not just the code change
- Reference relevant dimensions or existing modules if applicable

### Pull Requests

- One feature or fix per PR
- All tests must pass: `pytest` (1,800+ tests)
- Add tests for new code — aim for the patterns in existing test files
- Follow existing code style (PEP 8, type hints on all public APIs)
- Docstrings on all public classes and functions (Google style)
- No new dependencies unless absolutely necessary (zero-dep core is a feature)

### Code Style

- Type hints required on all public APIs
- Google-style docstrings
- `snake_case` for functions/variables, `PascalCase` for classes
- Tests in `test_<module>.py` files in the `tests/` directory
- Use `@dataclass` for data structures

### Areas Welcoming Contributions

- **Custom dimensions**: Pluggable governance dimensions (GDPR-specific, domain-specific)
- **Framework adapters**: New integrations beyond CrewAI/LangGraph/AutoGen
- **Bias metrics**: Advanced fairness analysis (AIF360 integration)
- **Structured logging**: structlog integration for enterprise deployability
- **Performance**: Benchmarking, caching, async variants
- **Documentation**: Examples, tutorials, translations

## AI-Assisted Development

Nomotic welcomes AI-assisted contributions. If you used AI tools (Claude, Copilot, etc.) in writing your PR:

- Add `assisted-by: <tool>` to your commit message trailer
- You are still responsible for reviewing, testing, and understanding all code
- AI-generated code must meet the same quality bar as human-written code

## Running Tests

```bash
# All tests
pytest

# Specific module
pytest tests/test_runtime.py

# With coverage
pytest --cov=nomotic --cov-report=html

# Adversarial scenarios
nomotic test --adversarial
```

## Architecture Decisions

Major design decisions are documented in the project knowledge base. Key principles:

- Zero mandatory dependencies (optional extras for integrations)
- Governance evaluation must be synchronous and deterministic
- All audit records are hash-chained and tamper-detectable
- Case-insensitive agent name resolution everywhere
- Test logs separated from production audit trails

## Code of Conduct

This project follows the [Contributor Covenant Code of Conduct](CODE_OF_CONDUCT.md). By participating, you are expected to uphold this code.

## License

By contributing, you agree that your contributions will be licensed under the [Apache License 2.0](LICENSE).

## Security

If you discover a security vulnerability, please follow the process described in [SECURITY.md](SECURITY.md). Do not open a public issue for security vulnerabilities.
