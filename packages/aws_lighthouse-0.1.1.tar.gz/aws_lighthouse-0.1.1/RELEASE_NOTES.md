## [0.1.2] - 2026-03-03

### ⚙️ Miscellaneous Tasks

- *(release)* Update uv publish command to verify PyPI URL
