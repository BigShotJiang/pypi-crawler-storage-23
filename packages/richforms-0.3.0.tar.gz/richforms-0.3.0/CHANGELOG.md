# Changelog

## [0.3.0](https://github.com/shinybrar/richforms/compare/v0.2.1...v0.3.0) (2026-02-20)


### Features

* **release:** added automation for releasing richforms ([594b5d7](https://github.com/shinybrar/richforms/commit/594b5d7db2cea59df513e78d286b73fbe5bd1c21))
* **richforms:** initial implementation ([833258f](https://github.com/shinybrar/richforms/commit/833258fa5134ec6dad58bed6749bf01c92eb5088))


### Bug Fixes

* **actions:** removed release please action ([7a5bba7](https://github.com/shinybrar/richforms/commit/7a5bba76198c1bc4ac409979adfb542a3f574779))
* **ci:** actions ([573c432](https://github.com/shinybrar/richforms/commit/573c43243dfd44418e1688576d12be1d6b6b7da5))
* **ci:** files ([3948703](https://github.com/shinybrar/richforms/commit/394870370abc37813a8d1e546e049a2c48604ced))
* **ci:** fixed release-please action ([f85b696](https://github.com/shinybrar/richforms/commit/f85b696e51155fc607b77882a428a18d2be09bb6))
* **ci:** release action ([f9ad040](https://github.com/shinybrar/richforms/commit/f9ad040edab39d030c798de1813b199813e8e895))
* **deps:** removed click as a dep since it comes from typer ([c5b7fce](https://github.com/shinybrar/richforms/commit/c5b7fce9fb534eb5e8dd4e782f4900571df76864))
* **deps:** removed library from deps ([dacf997](https://github.com/shinybrar/richforms/commit/dacf997d6b8479307aec0bcc77f059e860f6d382))
* **package:** deps ([60f15ed](https://github.com/shinybrar/richforms/commit/60f15edb3175783f813218e2a505691ec5bf8289))
* **pypi:** release ([a8d2dc8](https://github.com/shinybrar/richforms/commit/a8d2dc83f84fe4410cd118c520478bdf9846809e))
* **release-please:** action ([a6c3e01](https://github.com/shinybrar/richforms/commit/a6c3e01f75db4d021d8b854b09498040cac5d4db))
* **release:** automations ([488de1b](https://github.com/shinybrar/richforms/commit/488de1b2835e86d26e9a0895ae348506bc5bda6b))
* **render:** styling ([cc50f1b](https://github.com/shinybrar/richforms/commit/cc50f1b0029854e1a5b64ed0008f12def670a947))


### Documentation

* **zensical:** overhaul ([1d0f30c](https://github.com/shinybrar/richforms/commit/1d0f30c8630457b105630fd31d9293a6b5aed42f))

## [0.2.1](https://github.com/shinybrar/richforms/compare/richforms-v0.2.0...richforms-v0.2.1) (2026-02-20)


### Documentation

* **zensical:** overhaul ([1d0f30c](https://github.com/shinybrar/richforms/commit/1d0f30c8630457b105630fd31d9293a6b5aed42f))

## [0.2.0](https://github.com/shinybrar/richforms/compare/richforms-v0.1.0...richforms-v0.2.0) (2026-02-19)


### Features

* **richforms:** initial implementation ([833258f](https://github.com/shinybrar/richforms/commit/833258fa5134ec6dad58bed6749bf01c92eb5088))


### Bug Fixes

* **ci:** fixed release-please action ([f85b696](https://github.com/shinybrar/richforms/commit/f85b696e51155fc607b77882a428a18d2be09bb6))
* **deps:** removed library from deps ([dacf997](https://github.com/shinybrar/richforms/commit/dacf997d6b8479307aec0bcc77f059e860f6d382))
* **render:** styling ([cc50f1b](https://github.com/shinybrar/richforms/commit/cc50f1b0029854e1a5b64ed0008f12def670a947))

## Changelog

All notable changes to this project will be documented in this file.
