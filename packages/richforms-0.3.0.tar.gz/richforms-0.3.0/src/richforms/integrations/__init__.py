from richforms.integrations.click import form_callback as click_form_callback
from richforms.integrations.typer import form_callback as typer_form_callback

__all__ = ["click_form_callback", "typer_form_callback"]
