## [0.12.9](https://github.com/l4rm4nd/PyADRecon/compare/v0.12.8...v0.12.9) (2026-02-21)


### Bug Fixes

* refactor ESC9 detection ([9a58455](https://github.com/l4rm4nd/PyADRecon/commit/9a584559bbf4fac26e71264b2c4126af6fee6670))

## [0.12.8](https://github.com/l4rm4nd/PyADRecon/compare/v0.12.7...v0.12.8) (2026-02-21)


### Bug Fixes

* add manager approval to dashboard ([1716844](https://github.com/l4rm4nd/PyADRecon/commit/17168444a95083828ddcf8e605f398f345562f9a))

## [0.12.7](https://github.com/l4rm4nd/PyADRecon/compare/v0.12.6...v0.12.7) (2026-02-21)


### Bug Fixes

* add laps readers to table and adjust maq text ([2586914](https://github.com/l4rm4nd/PyADRecon/commit/25869149ce6a8c16923b3cace2bcb0e1e5db5025))

## [0.12.6](https://github.com/l4rm4nd/PyADRecon/compare/v0.12.5...v0.12.6) (2026-02-21)


### Bug Fixes

* hide non-issue tiles and add maq finding ([9929546](https://github.com/l4rm4nd/PyADRecon/commit/9929546c58bfe7d29d70e0ecf7be045bf244b2be))

## [0.12.5](https://github.com/l4rm4nd/PyADRecon/compare/v0.12.4...v0.12.5) (2026-02-21)


### Bug Fixes

* counter for security findings in navigation ([b856c3d](https://github.com/l4rm4nd/PyADRecon/commit/b856c3d4395b093cb0545c8ed716aaed3f868223))

