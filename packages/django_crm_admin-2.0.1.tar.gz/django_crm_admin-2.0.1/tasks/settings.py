
# List of fields, the value of which will be saved
# to the excel file when exporting tasks.
TASK_COLUMNS = [
    'creation_date', 'name', 'closing_date', 'lead_time', 'id'
]
