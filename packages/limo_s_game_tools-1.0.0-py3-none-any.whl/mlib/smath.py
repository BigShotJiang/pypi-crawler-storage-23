# 常数
pi = 3.141592653589793
e = 2.718281828459045
i = 1j

# ========== 基础函数 ==========

def _exp(z, terms=20):
    """e^z 泰勒展开，支持复数"""
    result = 1.0
    term = 1.0
    for n in range(1, terms):
        term *= z / n
        result += term
    return result

def _ln(x):
    
    if x <= 0:
        return float('-inf')
    y = x - 1
    if abs(y) < 0.1:
        return y - y**2/2 + y**3/3 - y**4/4 + y**5/5 - y**6/6 + y**7/7 - y**8/8 + y**9/9 - y**10/10 + y**11/11 - y**12/12 + y**13/13 - y**14/14 + y**15/15 - y**16/16 + y**17/17 - y**18/18 + y**19/19
    exponent = 0
    while x > 2:
        x /= 2
        exponent += 1
    while x < 1:
        x *= 2
        exponent -= 1
    y = x - 1
    log_x = y - y**2/2 + y**3/3 - y**4/4 + y**5/5 - y**6/6 + y**7/7 - y**8/8 + y**9/9 - y**10/10 + y**11/11 - y**12/12 + y**13/13 - y**14/14 + y**15/15 - y**16/16 + y**17/17 - y**18/18 + y**19/19
    return log_x + exponent * 0.6931471805599453  # ln(2)

def _log(z):
    """复数自然对数 ln(z)"""
    if not isinstance(z, complex):
        z = complex(z, 0)
    
    # 模长
    r = (z.real**2 + z.imag**2) ** 0.5
    if r == 0:
        return float("-inf")
    
    # 辐角 atan2(y, x)
    theta = _atan2(z.imag, z.real)
    result = complex(_ln(r), theta)
    if abs(result.imag) < 1e-15:  # 浮点数精度阈值
        return result.real
    return result

def _atan2(y, x):
    """手写辐角函数"""
    if x > 0:
        return _atan(y / x)
    if x < 0:
        if y >= 0:
            return _atan(y / x) + pi
        else:
            return _atan(y / x) - pi
    if x == 0:
        if y > 0:
            return pi / 2
        if y < 0:
            return -pi / 2
        return 0  # (0,0) 未定义，这里返回 0

def _atan(x, terms=20):
    """反正切泰勒展开 arctan(x)"""
    if abs(x) > 1:
        return pi/2 - _atan(1/x) if x > 0 else -pi/2 - _atan(1/x)
    
    result = 0
    for n in range(terms):
        result += ((-1)**n) * (x**(2*n+1)) / (2*n + 1)
    return result

# ========== 对数系列 ==========

def log(z, base=10):
    """任意底数的对数，支持复数"""
    ln_z = _log(z)
    if base is None:
        return ln_z
    return ln_z / _log(base)

def log10(z):
    return log(z, 10)

def log2(z):
    return log(z, 2)

def ln(z):

    if not isinstance(z, complex):
        # 提取 e 的幂次
        n = 0
        x = z
        while x > e:  # 分解出 e 的因子
            x /= e
            n += 1
        while 0 < x < 1/e:
            x *= e
            n -= 1
        
        if n != 0:
            # ln(z) = n * ln(e) + ln(x)
            # ln(e) 可以预定义为精确值 1.0
            return n * 1.0 + _ln(x)
        
    # 复数走原来的逻辑
    return _log(z)
# ========== 三角函数 ==========

def cos(z):
    """余弦，支持复数"""
    if not isinstance(z, complex):
        z = z % (2*pi)
        z = complex(z, 0)
    iz = complex(-(z.imag % (2*pi)), z.real % (2*pi))  # i * z
    return (_exp(iz) + _exp(-iz)) / 2

def sin(z):
    """正弦，支持复数"""
    if not isinstance(z, complex):
        z = complex(z, 0)
    iz = complex(-z.imag, z.real)  # i * z
    result = (_exp(iz) - _exp(-iz)) / (2j)
    if abs(result.imag) < 1e-15:  # 浮点数精度阈值
        return result.real
    return result

def tan(z):
    return sin(z) / cos(z)

def cot(z):
    return cos(z) / sin(z)

def sec(z):
    return 1 / cos(z)

def csc(z):
    return 1 / sin(z)

# ========== 反三角函数 ==========

def asin(z):
    """反正弦 arcsin(z) = -i * ln(i*z + sqrt(1-z²))"""
    if not isinstance(z, complex):
        z = complex(z, 0)
    return -1j * _log(1j * z + (1 - z*z) ** 0.5)

def acos(z):
    """反余弦 arccos(z) = -i * ln(z + i*sqrt(1-z²))"""
    if not isinstance(z, complex):
        z = complex(z, 0)
    return -1j * _log(z + 1j * (1 - z*z) ** 0.5)

def atan(z):
    """反正切 arctan(z) = i/2 * ln((i+z)/(i-z))"""
    if not isinstance(z, complex):
        z = complex(z, 0)
    return (1j/2) * _log((1j + z) / (1j - z))

# ========== 双曲函数 ==========

def cosh(z):
    """双曲余弦 cosh(z) = (e^z + e^-z)/2"""
    return (_exp(z) + _exp(-z)) / 2

def sinh(z):
    """双曲正弦 sinh(z) = (e^z - e^-z)/2"""
    return (_exp(z) - _exp(-z)) / 2

def tanh(z):
    return sinh(z) / cosh(z)

# ========== 取整函数 ==========
def round(x):
    if x >= 0:
        return int(x + 0.5)
    else:
        return int(x - 0.5)
    
def floor(x):
    return round(x - 0.5)

def ceil(x):
    return (floor(x) + 1) if x != int(x) else x

# ========== 代数函数 ==========

def root(x, n=2):
    """n 次方根"""
    return x ** (1/n)

sqrt = root  # 平方根别名
cbrt = lambda x: root(x, 3)  # 立方根

# ========== 转换函数 ==========
sign = lambda x: (x > 0) - (x < 0)
deg = lambda x: x * pi / 180
rad = lambda x: x * 180 / pi
fract = lambda x: x - floor(x) if x >= 0 else x - ceil(x)
wrap = lambda x, a, b: a + (x - a) % (b - a)
def map(x, in_min, in_max, out_min, out_max, clamp=False):
    value = (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min
    if clamp:
        if out_min <= out_max:
            return max(min(value, out_max), out_min)
        else:
            return max(min(value, out_min), out_max)
    return value


# ========== 统计函数 ==========

def mean(arr):
    return sum(arr) / len(arr)

def variance(arr):
    m = mean(arr)
    return sum((x - m) ** 2 for x in arr) / len(arr)

def mad(arr):
    m = mean(arr)
    return sum(abs(x - m) for x in arr) / len(arr)

