# scolor.py - 游戏颜色工具

def rgb(r, g, b):
    """RGB 颜色 (0-255)"""
    return (r, g, b)
    

def rgba(r, g, b, a=255):
    """RGBA 颜色"""
    return (r, g, b, a)
    
    
def hex_to_rgb(hex_str):
    """16进制转RGB，如 #FF0000 转 (255,0,0)"""
    hex_str = hex_str.lstrip('#')
    r = int(hex_str[0:2], 16)
    g = int(hex_str[2:4], 16)
    b = int(hex_str[4:6], 16)
    return (r, g, b)

def rgb_to_hex(r,g,b):
    return "#{:02x}{:02x}{:02x}".format(r, g, b)

    
    
def lerp(c1, c2, t):
    """颜色插值"""
    return tuple(int(a + (b-a)*t) for a,b in zip(c1, c2))

def rgb_to_hsv(r, g, b):
    r, g, b = r / 255.0, g / 255.0, b / 255.0
    cmax = max(r, g, b)
    cmin = min(r, g, b)
    delta = cmax - cmin
    if delta == 0:
        h = 0
    elif cmax == r:
        h = 60 * (((g - b) / delta) % 6)
    elif cmax == g:
        h = 60 * (((b - r) / delta) + 2)
    else:  # cmax == b
        h = 60 * (((r - g) / delta) + 4)
    if h < 0:
        h += 360
    if cmax == 0:
        s = 0
    else:
        s = delta / cmax
    v = cmax
    
    return h, s, v

def hsv_to_rgb(h, s, v):
    """HSV转RGB，返回(0-255)的RGB值"""
    h = h % 360
    s = max(0, min(s, 1))
    v = max(0, min(v, 1))
    
    c = v * s
    x = c * (1 - abs((h / 60) % 2 - 1))
    m = v - c
    
    if h < 60:
        r, g, b = c, x, 0
    elif h < 120:
        r, g, b = x, c, 0
    elif h < 180:
        r, g, b = 0, c, x
    elif h < 240:
        r, g, b = 0, x, c
    elif h < 300:
        r, g, b = x, 0, c
    else:
        r, g, b = c, 0, x
    
    return int((r + m) * 255), int((g + m) * 255), int((b + m) * 255)
    

# 常用颜色
RED = (255, 0, 0)
GREEN = (0, 255, 0)
BLUE = (0, 0, 255)
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
