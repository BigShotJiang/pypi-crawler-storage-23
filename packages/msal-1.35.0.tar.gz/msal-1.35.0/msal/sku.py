"""This module is from where we recieve the client sku name and version.
"""

# The __init__.py will import this. Not the other way around.
__version__ = "1.35.0"
SKU = "MSAL.Python"
