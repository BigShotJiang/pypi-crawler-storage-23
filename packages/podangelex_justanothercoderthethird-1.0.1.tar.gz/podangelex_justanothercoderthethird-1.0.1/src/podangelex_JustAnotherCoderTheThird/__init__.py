"""PodangelEX - Audio profanity removal using Whisper and Detoxify."""

__version__ = "1.0.1"

from .functions import (
    read_config,
    write_config,
    config_menu,
    run_program,
    get_config_dir,
    initialize_workspace,
)
from .cli import main

__all__ = [
    "read_config",
    "write_config",
    "config_menu",
    "run_program",
    "get_config_dir",
    "initialize_workspace",
    "main",
]
