![MIT License](https://upload.wikimedia.org/wikipedia/commons/6/6b/License_icon-mit-88x31.svg)  
*MIT License*

![Python 3.6](https://upload.wikimedia.org/wikipedia/commons/c/c3/Python-logo-notext.svg)  
*Python 3.6+*

![Author](https://upload.wikimedia.org/wikipedia/commons/8/87/Light_Bulb_or_Idea_Flat_Icon_Vector.svg)  
*Author: TheLostIdea1*

## Chronos Sync

Hello, time travelers! We all know that time... is money, but what if... you want to check the time with no clock? A python script or browsing the web helps. **ChronosSync** provides a live-ticking terminal experience with high-precision tools, mimicking the namespace style of the standard `datetime` library.

---

### 1. Installation & Setup

Install the library using `pip` from PyPI or TestPyPI:

**Standard PyPI:**
```shell
pip install chronossync
```

**TestPyPI:**
```shell
python -m pip install --index-url [https://test.pypi.org/simple/](https://test.pypi.org/simple/) chronossync
```

---

### 2. Usage & Syntax

**ChronosSync** allows you to use the library via the full namespace or by importing the class directly.

#### Live Clock
Evaluating the `present()` method triggers a live-updating clock in your terminal.
```python
import chronossync
chronossync.chronossync.present()
```

OR

```python
import chronossync
print(chronossync.chronossync.present()

#### Timer & Stopwatch
High-precision tools using `hh:mm:ss.ms` formatting.
```python
from chronossync import chronossync

# 10-second countdown timer
chronossync.timer(10)

# Endless stopwatch
chronossync.stopwatch()
```

#### Data Extraction
Extract specific strings without starting a loop.
```python
clock = chronossync.present()
print(clock.date())   # Tuesday, 24th of February, 2026
print(clock.time())   # 06:45:12 PM
print(clock.tzone())  # GMT+06:00
```

---

### 3. Logic and Mechanics

* **Anti-Flicker (`\r`)**: Unlike scripts that clear the whole screen, **ChronosSync** uses carriage returns to overwrite the current line, preserving your terminal history.
* **Precision Timing**: The Timer and Stopwatch use `time.perf_counter()` to remain accurate down to the millisecond, independent of system clock shifts.
* **The "Ordinal" Logic**: Intentionally follows a custom convention inspired by internet culture:
    * `1st`, `2nd`, `3th` (e.g., "3th of March").
    * Applies to the tens place: `21st`, `22nd`, `23th`.
* **Graceful Termination**: Press `Ctrl+C` at any time to stop the live loop and return to the prompt cleanly.

---

### 4. Development & Testing

This project uses the modern `src` layout. To verify the logic, run the test suite from the root directory:

```shell
python -m unittest discover tests
```



---

