import time
import os
import sys
from datetime import datetime

class chronossync:
    def __init__(self):
        self._now = datetime.now()
        
    def _get_tz_string(self):
        offset_seconds = -time.timezone if (time.daylight == 0) else -time.altzone
        sign = "+" if offset_seconds >= 0 else "-"
        offset_abs = abs(offset_seconds)
        hours = offset_abs // 3600
        minutes = (offset_abs % 3600) // 60
        return f"GMT{sign}{hours:02}:{minutes:02}"

    def _get_ordinal(self, day):
        if 11 <= day <= 13: return f"{day}th"
        last_digit = day % 10
        if last_digit == 1: return f"{day}st"
        if last_digit == 2: return f"{day}nd"
        return f"{day}th"

    def date(self):
        self._now = datetime.now()
        day_str = self._get_ordinal(self._now.day)
        return self._now.strftime(f"%A, {day_str} of %B, %Y")

    def time(self):
        self._now = datetime.now()
        return self._now.strftime("%I:%M:%S %p")

    def tzone(self):
        return self._get_tz_string()

    def _format_duration(self, seconds):
        """Helper to format seconds into hh:mm:ss.ms"""
        h = int(seconds // 3600)
        m = int((seconds % 3600) // 60)
        s = int(seconds % 60)
        ms = int((seconds % 1) * 1000)
        return f"{h:02}:{m:02}:{s:02}.{ms:03}"

    @classmethod
    def timer(cls, seconds):
        """Countdown timer from a given number of seconds."""
        end_time = time.perf_counter() + seconds
        try:
            while True:
                remaining = end_time - time.perf_counter()
                if remaining <= 0:
                    sys.stdout.write(f"\r00:00:00.000\n[Timer Finished]\n")
                    break
                sys.stdout.write(f"\r{cls()._format_duration(remaining)}")
                sys.stdout.flush()
                time.sleep(0.01) # Faster refresh for ms
        except KeyboardInterrupt:
            print("\n[Timer Stopped]")

    @classmethod
    def stopwatch(cls):
        """Endless stopwatch starting from zero."""
        start_time = time.perf_counter()
        try:
            while True:
                elapsed = time.perf_counter() - start_time
                sys.stdout.write(f"\r{cls()._format_duration(elapsed)}")
                sys.stdout.flush()
                time.sleep(0.01)
        except KeyboardInterrupt:
            print("\n[Stopwatch Stopped]")

    @classmethod
    def present(cls):
        return cls()

    def __repr__(self):
        try:
            while True:
                output = f"{self.date()}, {self.time()}, {self.tzone()}"
                sys.stdout.write(f"\r{output}")
                sys.stdout.flush()
                time.sleep(1)
        except KeyboardInterrupt:
            return "\n[Clock Stopped]"

