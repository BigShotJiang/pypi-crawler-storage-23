from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="chronossync",
    version="0.1.0post3",
    author="TheLostIdea1",
    description="A live ticking clock with custom formatting.",
    long_description=long_description,
    long_description_content_type="text/markdown",
    include_package_data=True,
    packages=find_packages(where="src"),
    package_dir={"": "src"},
    python_requires=">=3.6",
)

