import unittest
from chronossync.chronossync import chronossync

class TestChronosSync(unittest.TestCase):
    def setUp(self):
        self.clock = chronossync()

    def test_ordinals(self):
        # Custom rules: 1st, 2nd, 3th... 21st, 22nd, 23th
        self.assertEqual(self.clock._get_ordinal(1), "1st")
        self.assertEqual(self.clock._get_ordinal(2), "2nd")
        self.assertEqual(self.clock._get_ordinal(3), "3th")
        self.assertEqual(self.clock._get_ordinal(11), "11th")
        self.assertEqual(self.clock._get_ordinal(21), "21st")
        self.assertEqual(self.clock._get_ordinal(22), "22nd")
        self.assertEqual(self.clock._get_ordinal(23), "23th")

    def test_timezone_structure(self):
        tz = self.clock.tzone()
        self.assertTrue(tz.startswith("GMT"))
        self.assertIn("+", tz) if "+" in tz else self.assertIn("-", tz)

