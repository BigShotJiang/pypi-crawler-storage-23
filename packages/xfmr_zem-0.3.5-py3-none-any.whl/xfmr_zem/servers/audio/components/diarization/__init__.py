from .diarizer import DiariZenDiarizer

__all__ = ["DiariZenDiarizer"]
