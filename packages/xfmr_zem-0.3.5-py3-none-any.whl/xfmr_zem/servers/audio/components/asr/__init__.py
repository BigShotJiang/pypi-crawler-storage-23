# ASR module
from .transcriber import VieASRTranscriber

__all__ = ["VieASRTranscriber"]
