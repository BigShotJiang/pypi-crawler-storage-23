---
license: apache-2.0
---

Please refer to [this](https://github.com/infiniflow/ragflow/blob/main/deepdoc/README.md).