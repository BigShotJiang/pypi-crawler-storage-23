#!/usr/bin/env python3
"""Google Drive Deduplication Manager — backward-compatible entry point."""

from dedrive.cli import main

if __name__ == "__main__":
    main()
