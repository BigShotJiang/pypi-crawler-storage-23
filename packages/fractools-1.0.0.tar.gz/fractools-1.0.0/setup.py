from setuptools import setup, find_packages

setup(
    name="fractools",
    version="1.0.0",
    packages=find_packages(),
    description="A standalone fraction and mixed number toolkit.",
    long_description="A toolkit that makes fractions and mixed numbers easier to work with in python.\nThis python module requires version 3.6 or higher.",
    long_description_content_type="text/markdown",
    author="KingTheCoder",
    python_requires=">=3.6",
)