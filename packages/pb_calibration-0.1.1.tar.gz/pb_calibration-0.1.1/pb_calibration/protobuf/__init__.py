# -*- coding: utf-8 -*-
"""Proto 定义及生成代码（基于 vehicle_config.proto）。"""

from .vehicle_config_pb2 import (  # noqa: F401
    VehicleConfig,
    VehicleInfo,
    VehicleParam,
    LatencyParam,
    Extrinsics,
    Transform,
    Point3D,
    Quaternion,
    Intrinsics,
    CameraParam,
    PinholeCamera,
    FisheyeCamera,
    CameraModelType,
)

__all__ = [
    "VehicleConfig",
    "VehicleInfo",
    "VehicleParam",
    "LatencyParam",
    "Extrinsics",
    "Transform",
    "Point3D",
    "Quaternion",
    "Intrinsics",
    "CameraParam",
    "PinholeCamera",
    "FisheyeCamera",
    "CameraModelType",
]
