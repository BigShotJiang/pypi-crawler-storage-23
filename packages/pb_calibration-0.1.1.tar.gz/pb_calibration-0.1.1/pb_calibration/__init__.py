# -*- coding: utf-8 -*-
"""
pb_calibration：基于 vehicle_config.proto 的 PB 车辆配置/标定文件校验、解析为 YAML、从 YAML 组装为 .pb.txt

提供：
1. check(pb_path) - 反序列化检查 pb.txt 是否存在格式问题
2. parse(pb_path, yaml_dir) - 解析 pb.txt 为每个单独的 yaml 文件，输出到指定目录（与组合位置一致）
3. build(yaml_dir, output_pb_path) - 按顺序将 yaml 目录中的文件组装成 pb.txt
4. YamlConfigManager(default_yaml_dir) - 默认路径 + 无缓存 YAML 读写、rescan/get_cached/get
5. read_yaml / update_yaml / read_order_manifest / update_order_manifest - 函数式 API
"""

from .api import (
    check,
    parse,
    build,
    YamlConfigManager,
    read_yaml,
    update_yaml,
    read_order_manifest,
    update_order_manifest,
)

__version__ = "0.1.1"
__all__ = [
    "check",
    "parse",
    "build",
    "YamlConfigManager",
    "read_yaml",
    "update_yaml",
    "read_order_manifest",
    "update_order_manifest",
    "__version__",
]
