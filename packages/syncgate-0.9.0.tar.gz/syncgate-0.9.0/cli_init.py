"""Quick start command for SyncGate."""

import argparse
import os
from pathlib import Path


def cmd_init(args):
    """Initialize a SyncGate demo project."""
    target_dir = args.path
    
    # Create demo structure
    demo_content = '''
# SyncGate Demo

This is a quick demo of SyncGate.

## Quick Start

```bash
# Install
pip install syncgate

# Link a file
syncgate link /demo/local-file.txt local:/path/to/your/file.txt local

# List
syncgate ls /demo
```

## Learn More

- GitHub: github.com/cyydark/syncgate
- Documentation: PROJECT.md
'''
    
    # Create demo .link files
    demo_link = {
        "target": "local:/path/to/file.txt",
        "backend": "local"
    }
    
    print(f"✅ Created demo project at: {target_dir}")
    print()
    print("Next steps:")
    print(f"1. cd {target_dir}")
    print("2. Edit demo/local-file.txt.link with your actual file path")
    print("3. Run: syncgate ls /demo")
    print()
    print("Happy hacking! 🚀")


def main():
    parser = argparse.ArgumentParser(description="Initialize a SyncGate demo project")
    parser.add_argument("path", nargs="?", default="syncgate-demo", help="Target directory")
    parser.set_defaults(func=cmd_init)
    
    args = parser.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
