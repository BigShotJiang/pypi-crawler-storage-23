#!/usr/bin/env python3
"""
SyncGate v2 演示 - 完整功能展示

运行方式:
    python3 demo_v2.py
"""

from syncgate.vfs.fs import VirtualFS
from syncgate.backend.local import LocalBackend
from syncgate.backend.http import HTTPBackend
from syncgate.gateway.gateway import Gateway
from pathlib import Path
import shutil
import os


def setup():
    """设置演示环境"""
    vfs_root = Path("demo_v2")
    vfs_root.mkdir(exist_ok=True)
    
    # 创建测试文件
    os.makedirs("/tmp/syncgate_demo", exist_ok=True)
    Path("/tmp/syncgate_demo/test.txt").write_text("Hello SyncGate!")
    Path("/tmp/syncgate_demo/video.mp4").write_text("Video placeholder")
    
    return vfs_root


def cleanup(vfs_root):
    """清理演示环境"""
    shutil.rmtree(vfs_root, ignore_errors=True)
    shutil.rmtree("/tmp/syncgate_demo", ignore_errors=True)


def demo():
    """演示主函数"""
    print("🎯 SyncGate v2 演示")
    print("=" * 60)
    
    vfs_root = setup()
    
    try:
        # 初始化
        vfs = VirtualFS(str(vfs_root))
        local_backend = LocalBackend(
            vfs_root=str(vfs_root),
            local_root="/tmp/syncgate_demo",
            db_path=str(vfs_root / "local_status.db")
        )
        http_backend = HTTPBackend(
            vfs_root=str(vfs_root),
            db_path=str(vfs_root / "http_status.db")
        )
        gateway = Gateway(vfs, local_backend)
        
        # 1. 创建链接
        print("\n📝 Step 1: 创建链接")
        vfs.link("/docs/notes.txt", "local:/tmp/syncgate_demo/test.txt", "local")
        vfs.link("/media/video.mp4", "local:/tmp/syncgate_demo/video.mp4", "local")
        vfs.link("/online/article.md", "https://httpbin.org/json", "http")
        print("  ✅ Created 3 links")
        
        # 2. 列出目录
        print("\n📂 Step 2: 虚拟文件系统")
        print(gateway.tree("/", max_depth=3))
        
        # 3. 验证链接
        print("\n🔍 Step 3: 验证链接")
        for path in ["/docs/notes.txt", "/online/article.md"]:
            status = gateway.get_link_status(path)
            icon = "✅" if status.get("valid") else "❌"
            print(f"  {icon} {path}")
        
        print("\n" + "=" * 60)
        print("✅ 演示完成!")
        print("\n📦 安装使用:")
        print("   pip install syncgate")
        print("   syncgate --help")
        print("\n🔗 了解更多:")
        print("   GitHub: github.com/cyydark/syncgate")
        
    finally:
        cleanup(vfs_root)


if __name__ == "__main__":
    demo()
