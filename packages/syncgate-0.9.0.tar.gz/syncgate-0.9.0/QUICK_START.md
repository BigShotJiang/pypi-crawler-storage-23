# SyncGate 快速开始

> 5 分钟学会使用 SyncGate

## 安装 (1 分钟)

```bash
pip install syncgate
```

或者从源码：

```bash
git clone https://github.com/cyydark/syncgate.git
cd syncgate
pip install -e .
```

## 基本使用 (3 分钟)

### 步骤 1: 创建第一个链接

```bash
# 创建本地文件链接
syncgate link /hello.txt local:/tmp/hello.txt local
```

### 步骤 2: 查看目录

```bash
syncgate ls /
```

输出：
```
virtual/
└── hello.txt
```

### 步骤 3: 验证链接

```bash
syncgate validate /hello.txt
```

### 步骤 4: 删除链接

```bash
syncgate unlink /hello.txt
```

## 添加更多存储

### HTTP 链接

```bash
syncgate link /api.json https://httpbin.org/json http
syncgate ls /api.json
```

### S3 链接

```bash
syncgate link /backup s3://my-bucket/backups/ s3
syncgate ls /backup
```

## 一句话记住

```
syncgate link <虚拟路径> <目标地址> <后端类型>
```

| 后端类型 | 示例 |
|----------|------|
| local | `local:/path/to/file` |
| http | `https://example.com/file` |
| s3 | `s3://bucket/path` |

## 下一步

- 查看完整文档: [USAGE.md](USAGE.md)
- 运行演示: `python3 demo_complete.py`
- GitHub: https://github.com/cyydark/syncgate
