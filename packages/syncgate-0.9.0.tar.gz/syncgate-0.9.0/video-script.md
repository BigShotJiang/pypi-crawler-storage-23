# SyncGate 30 秒产品视频脚本

## 场景 1: 问题 (5秒)

**[画面]** 文件散落在不同位置
**[旁白]** "文件散落在 S3、NAS、本地...找文件太麻烦？"

## 场景 2: 解决方案 (10秒)

**[画面]** SyncGate CLI 操作
**[旁白]** "SyncGate，统一管理所有存储"
**[操作]** syncgate link /docs/a.txt local:/path/file local
**[旁白]** "一条命令，链接所有存储"

## 场景 3: 统一访问 (10秒)

**[画面]** syncgate ls /docs
**[旁白]** "本地、HTTPS、S3，一个命令访问"
**[画面]** 多个后端结果
**[旁白]** "虚拟文件系统，不移动源文件"

## 场景 4: 收尾 (5秒)

**[画面]** Logo + GitHub
**[旁白]** "SyncGate - 多存储路由"
**[字幕]** github.com/cyydark/syncgate

---

## 发布文案

### Twitter/X

🎯 SyncGate - 多存储路由工具

文件散落在各处？
🔗 一条命令链接所有存储

📁 local://
🌐 https://
☁️ s3://

github.com/cyydark/syncgate

#工具 #开发者

---

## 联系

- GitHub: github.com/cyydark/syncgate
- Issues: github.com/cyydark/syncgate/issues
