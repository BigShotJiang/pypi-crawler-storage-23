# SyncGate 使用指南

> 多存储路由与同步抽象层

## 快速开始

### 安装

```bash
pip install syncgate
```

或者从源码安装：

```bash
git clone https://github.com/cyydark/syncgate.git
cd syncgate
pip install -e .
```

### 基本使用

```bash
# 创建链接
syncgate link /docs/a.txt local:/path/to/file local
syncgate link /online/api.json https://api.example.com/data.json http
syncgate link /backup/data.csv s3://my-bucket/data/2024.csv s3

# 列出目录
syncgate ls /docs

# 树形结构
syncgate tree /

# 验证链接
syncgate validate /docs/a.txt

# 查看状态
syncgate status /docs/a.txt
```

---

## 核心概念

### 1. 链接 (.link 文件)

SyncGate 通过 `.link` 文件管理存储链接，不移动源文件。

```bash
# 创建链接
syncgate link /virtual/path target-url backend-type

# 示例
syncgate link /docs/a.txt local:/home/user/docs/a.txt local
syncgate link /online/video https://example.com/video.mp4 http
syncgate link /cloud/backup s3://my-bucket/backup s3
```

### 2. 支持的存储后端

| 后端 | 协议 | 示例 |
|------|------|------|
| 本地 | local:/ | `local:/home/user/docs` |
| HTTP | https:// | `https://api.example.com/data.json` |
| S3 | s3:// | `s3://bucket-name/path/to/file` |
| WebDAV | webdav:// | `webdav://server.com/path` |
| FTP | ftp:// | `ftp://server.com/path` |
| SFTP | sftp:// | `sftp://user@server.com/path` |

### 3. 虚拟文件系统

SyncGate 创建虚拟文件系统，所有操作都是虚拟的：

```
virtual/
├── docs/
│   └── a.txt.link  → local:/home/user/docs/a.txt
├── online/
│   └── api.json.link  → https://api.example.com/api.json
└── cloud/
    └── backup.csv.link  → s3://my-bucket/backup/backup.csv
```

---

## 命令详解

### link - 创建链接

```bash
syncgate link <virtual_path> <target> <backend>

# 示例
syncgate link /docs/notes.txt local:/home/user/notes.txt local
syncgate link /media/video.mp4 https://example.com/video.mp4 http
syncgate link /backup/data.csv s3://my-bucket/data/backup.csv s3
```

### ls - 列出目录

```bash
syncgate ls /path

# 示例
syncgate ls /docs
syncgate ls /
```

### tree - 树形结构

```bash
syncgate tree /path [--max-depth 3]

# 示例
syncgate tree /docs --max-depth 2
```

### unlink - 删除链接

```bash
syncgate unlink /path

# 示例
syncgate unlink /docs/a.txt
```

### validate - 验证链接

```bash
# 验证单个链接
syncgate validate /docs/a.txt

# 验证目录下的所有链接
syncgate validate /docs --all
```

### status - 查看状态

```bash
syncgate status /path
```

### config - 管理配置

```bash
# 列出配置
syncgate config list

# 获取配置
syncgate config get key

# 设置配置
syncgate config set key value
```

---

## 高级功能

### 1. REST API

启动 API 服务器：

```bash
python -m syncgate.api --port 8080
```

API 端点：

```bash
# 获取统计
GET /api/stats

# 获取链接信息
GET /api/links/<path>

# 创建链接
POST /api/links
Content-Type: application/json
{
  "virtual_path": "/docs/a.txt",
  "target": "local:/path/to/file",
  "backend": "local"
}

# 删除链接
DELETE /api/links/<path>
```

### 2. 批量操作

```python
from syncgate.batch import BatchOperations

batch = BatchOperations(vfs_root="virtual")

# 批量创建
batch.batch_create([
    {"virtual_path": "/a.txt", "target": "local:/tmp/a.txt", "backend": "local"},
    {"virtual_path": "/b.txt", "target": "local:/tmp/b.txt", "backend": "local"},
])

# 批量验证
batch.batch_validate(["/a.txt", "/b.txt"])

# 导出配置
batch.export_links("backup.json")

# 导入配置
batch.import_links("backup.json", prefix="/backup")
```

### 3. 监控和统计

```python
from syncgate.monitor import StatsCollector, PerformanceMonitor

# 统计收集
stats = StatsCollector(vfs_root="virtual")
stats.record_create("local")
stats.record_validate(success=True)

# 获取统计
summary = stats.get_summary()
print(f"Total links: {summary['total_links']}")
print(f"Health score: {stats.get_health_score()}")

# 性能监控
monitor = PerformanceMonitor()
monitor.start_operation("operation_name")
# ... do something ...
monitor.end_operation(success=True)

# 获取性能数据
perf_stats = monitor.get_stats()
```

### 4. Webhook 通知

```python
from syncgate.webhook import WebhookManager

wm = WebhookManager()

# 添加 webhook
wm.add("https://your-server.com/webhook", events=["link.created", "link.deleted"])

# 发送通知
wm.notify("link.created", {"path": "/docs/a.txt"})
```

### 5. 错误处理

```python
from syncgate.error_handler import retry, CircuitBreaker, ErrorHandler

# 重试装饰器
@retry(max_retries=3, delay=1.0)
def fragile_operation():
    ...

# 熔断器
breaker = CircuitBreaker("my-service", failure_threshold=5)
if breaker.state == "open":
    raise Exception("Service unavailable")

# 错误日志
handler = ErrorHandler()
handler.log_error("operation", "error message", path="/docs/a.txt")
```

### 6. AI 搜索

```python
from syncgate.ai import AIModule

ai = AIModule(vfs_root="virtual")

# 索引内容
ai.index_content("/docs/python.txt", b"Python is great")

# 语义搜索
results = ai.search("Python programming", limit=5)

# 获取元数据
meta = ai.get_metadata("/docs/python.txt")
```

---

## 配置文件

SyncGate 使用以下配置文件：

| 文件 | 用途 |
|------|------|
| `virtual/` | 虚拟文件系统根目录 |
| `virtual/*.link` | 链接文件 |
| `virtual/status.db` | 链接状态数据库 |
| `virtual/ai_metadata.db` | AI 元数据数据库 |
| `webhooks.json` | Webhook 配置 |

---

## 开发

### 运行测试

```bash
pytest tests/ -v
```

### 运行演示

```bash
# 完整演示
python3 demo_complete.py

# AI 模块演示
python3 ai_demo.py
```

### 代码结构

```
syncgate/
├── api.py          # REST API 服务器
├── batch.py        # 批量操作
├── cli.py          # 命令行工具
├── monitor.py      # 监控统计
├── webhook.py      # Webhook 通知
├── error_handler.py # 错误处理
├── utils.py        # 工具函数
├── vfs/
│   └── fs.py      # 虚拟文件系统
├── gateway/
│   └── gateway.py # 网关层
├── backend/
│   ├── base.py    # 基础后端类
│   ├── local.py   # 本地存储
│   ├── http.py    # HTTP 存储
│   ├── s3.py     # AWS S3
│   ├── webdav.py # WebDAV
│   ├── ftp.py     # FTP
│   └── sftp.py    # SFTP
└── ai/
    └── __init__.py # AI 模块
```

---

## 性能优化

SyncGate 针对大目录进行了性能优化：

### 1. 内存索引

首次使用时，SyncGate 会扫描所有 `.link` 文件建立内存索引，后续操作直接操作内存，避免重复文件 I/O。

### 2. LRU 缓存

重复查询的链接数据会被缓存，第二次查询速度提升 100+ 倍。

```python
# 第一次查询 (文件 I/O)
vfs.resolve("/file")  # ~0.1ms

# 第二次查询 (缓存命中)
vfs.resolve("/file")  # ~0.001ms
```

### 3. 分页查询

大目录支持分页查询，避免一次性加载所有数据。

```python
# 获取前 50 个文件
result = vfs.list_paged("/", page=0, page_size=50)

# 获取下 50 个文件
result = vfs.list_paged("/", page=1, page_size=50)
```

### 性能数据

| 操作 | 1000 文件 | 5000 文件 |
|------|----------|----------|
| 索引构建 | 0.01s | 0.05s |
| 首次查询 | 0.1ms/文件 | 0.1ms/文件 |
| 缓存查询 | 0.001ms/文件 | 0.001ms/文件 |
| 统计收集 | 0.1s | 0.5s |

---

## 常见问题

### Q: 链接验证失败？

```bash
# 检查链接是否有效
syncgate validate /docs/a.txt --all

# 查看错误信息
syncgate status /docs/a.txt
```

### Q: 如何迁移到其他机器？

```bash
# 导出链接
batch.export_links("backup.json")

# 复制到新机器后导入
batch.import_links("backup.json")
```

### Q: 支持实时同步吗？

SyncGate 是链接管理工具，不做实时同步。链接的目标存储由各自的后端管理。

---

## 相关链接

- GitHub: https://github.com/cyydark/syncgate
- PyPI: https://pypi.org/project/syncgate/

---

## 许可证

MIT License
