# Reddit r/python 帖子

## 标题

SyncGate - 统一管理多存储的CLI工具

## 正文

Hi! 我做了一个 CLI 工具 SyncGate，用于统一管理本地文件、HTTP 链接和 S3 对象。

**为什么做这个:**
- 我的文件散落在 S3、NAS、本地磁盘...
- 每次要找文件都要切换不同的工具
- 做了这个统一的虚拟文件系统

**特点:**
- 🔗 轻量级: 纯 Python，无外部依赖
- 🧩 可扩展: 支持任意存储后端
- 📁 虚拟管理: 不移动源文件，只管理链接
- ⚡ 无延迟: 实时透传，不做缓存

**使用示例:**
```bash
# 创建链接
syncgate link /docs/a.txt local:/path/to/file.txt local
syncgate link /online/api.json https://api.example.com/data.json http
syncgate link /cloud/data.csv s3://my-bucket/data/2024.csv s3

# 列出目录
syncgate ls /docs
✅ a.txt

# 验证链接
syncgate validate /docs/a.txt
```

**快速开始:**
```bash
pip install syncgate
python3 demo_complete.py
```

🔗 GitHub: https://github.com/cyydark/syncgate

欢迎反馈和建议！

---

## 提交链接

https://www.reddit.com/r/python/submit
