# SyncGate 演示输出

## 终端演示

```bash
$ python3 demo_complete.py

🎯 SyncGate Complete Demo
============================================================

📝 Step 1: 创建链接
  ✅ Local:  /docs/notes.txt
  ✅ Local:  /media/video.mp4
  ✅ HTTP:   /online/api.json
  ✅ S3:     /cloud/data.csv

📂 Step 2: 虚拟文件系统结构

virtual/
├── 📁 docs/
│   └── ✅ notes.txt
├── 📁 media/
│   └── ✅ video.mp4
├── 📁 online/
│   └── ✅ api.json
└── 📁 cloud/
    └── ✅ data.csv

🔍 Step 3: 链接验证
  ✅ /docs/notes.txt
  ✅ /online/api.json
  ✅ /cloud/data.csv

✅ 演示完成!

🔗 GitHub: github.com/cyydark/syncgate
```

---

## CLI 使用

```bash
$ syncgate --help
SyncGate - Lightweight multi-storage routing

Commands:
  ls        列出目录
  tree      树形结构
  link      创建链接
  unlink    删除链接
  validate  验证链接
  status    查看状态

$ syncgate link /docs/a.txt local:/path/to/file.txt local
Linked: /docs/a.txt -> local:/path/to/file.txt

$ syncgate ls /docs
✅ a.txt
✅ b.txt
```

---

## 一句话介绍

**SyncGate** - 统一管理散落在各处的文件

- 📁 本地文件
- 🌐 HTTP/HTTPS
- ☁️ AWS S3

统一路径访问，虚拟文件系统管理。
