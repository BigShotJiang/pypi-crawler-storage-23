# SyncGate 推广文案

## Twitter 30秒介绍

```
🎯 我做了一个工具，统一管理散落在各处的文件

本地文件 + HTTP + S3，一个命令访问

🔗 github.com/cyydark/syncgate

#Python #DevTools #OpenSource
```

---

## Hacker News 提交

```
标题: SyncGate - 统一管理本地文件/HTTP/S3的工具

正文:

我做了一个轻量级工具 SyncGate，用于统一管理散落在不同存储位置的文件。

核心功能:
- 📁 本地文件系统
- 🌐 HTTP/HTTPS 链接
- ☁️ AWS S3 对象存储

统一访问方式:
$ syncgate link /docs/a.txt local:/path/to/file.txt
$ syncgate ls /docs
✅ a.txt

虚拟文件系统，不移动源文件，只管理链接。

🔗 演示: python3 demo_complete.py
🔗 GitHub: github.com/cyydark/syncgate
```

---

## Reddit r/python

```
标题: SyncGate - 统一管理多存储的CLI工具

正文:

Hi! 我做了一个 CLI 工具 SyncGate，用于统一管理本地文件、HTTP 链接和 S3 对象。

为什么做这个:
- 我的文件散落在 S3、NAS、本地...
- 每次要找文件都要切换工具
- 做了一个统一的虚拟文件系统

特点:
- 轻量级: 纯 Python，无依赖
- 可扩展: 支持任意存储后端
- 虚拟管理: 不移动源文件，只管理链接

🔗 GitHub: github.com/cyydark/syncgate
```

---

## 一句话卖点

| 痛点 | 解决方案 |
|------|----------|
| 文件散落各地 | 统一虚拟路径访问 |
| 切换工具麻烦 | 一个 CLI 管所有 |
| 不想移动文件 | 链接管理，不动源文件 |

---

## 快速上手

```bash
pip install syncgate

# 创建链接
syncgate link /docs/a.txt local:/path/to/file local

# 列出目录
syncgate ls /docs

# 验证链接
syncgate validate /docs/a.txt
```
