#!/usr/bin/env python3
"""
SyncGate 一键推广脚本

执行推广任务：
1. 生成推广文案
2. 准备提交链接
"""

import webbrowser

PROMO_TEXT = """🎯 SyncGate v0.6.0 - 多存储统一管理工具

✅ 支持 6 种存储：
- 本地文件 (Local)
- HTTP/HTTPS
- AWS S3
- WebDAV (NAS/云存储)
- FTP
- SFTP

✅ 功能特性：
- 虚拟文件系统 .link 管理
- REST API 支持
- AI 元数据管理
- 语义搜索
- 完整测试覆盖

🔗 github.com/cyydark/syncgate

#Python #DevTools #OpenSource
"""

TWEET_URL = "https://twitter.com/intent/tweet?text=" + PROMO_TEXT.replace("\n", "%0A").replace("#", "%23")

HN_URL = "https://news.ycombinator.com/submit"

REDDIT_URL = "https://www.reddit.com/r/python/submit"

def main():
    print("🚀 SyncGate 推广执行")
    print("=" * 50)
    print()
    print("📱 Twitter 推广:")
    print(f"   {TWEET_URL[:60]}...")
    print()
    print("📰 Hacker News 提交:")
    print(f"   {HN_URL}")
    print()
    print("💬 Reddit r/python:")
    print(f"   {REDDIT_URL}")
    print()
    print("-" * 50)
    print("选择推广渠道:")
    print("  1. 🐦 Twitter")
    print("  2. 📰 Hacker News")
    print("  3. 💬 Reddit")
    print("  4. 📋 复制文案")
    print("  5. 🚀 全部打开")
    print()
    
    choice = input("选择 (1-5): ").strip()
    
    if choice == "1":
        webbrowser.open(TWEET_URL)
    elif choice == "2":
        webbrowser.open(HN_URL)
    elif choice == "3":
        webbrowser.open(REDDIT_URL)
    elif choice == "4":
        import subprocess
        subprocess.run("pbcopy", input=PROMO_TEXT.encode())
        print("✅ 已复制到剪贴板!")
    elif choice == "5":
        webbrowser.open(TWEET_URL)
        webbrowser.open(HN_URL)
        webbrowser.open(REDDIT_URL)
    else:
        print("❌ 无效选择")

if __name__ == "__main__":
    main()
