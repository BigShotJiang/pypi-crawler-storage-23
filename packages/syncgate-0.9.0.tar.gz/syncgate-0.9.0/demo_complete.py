#!/usr/bin/env python3
"""
SyncGate Complete Demo
测试所有后端：Local, HTTP, S3

运行:
    python3 demo_complete.py
"""

from syncgate.vfs.fs import VirtualFS
from syncgate.backend.local import LocalBackend
from syncgate.backend.http import HTTPBackend
from syncgate.backend.s3 import S3Backend
from syncgate.gateway.gateway import Gateway
from pathlib import Path
import shutil
import os


def setup():
    """设置环境"""
    vfs_root = Path("demo_complete")
    vfs_root.mkdir(exist_ok=True)
    os.makedirs("/tmp/syncgate_demo", exist_ok=True)
    
    # 创建测试文件
    Path("/tmp/syncgate_demo/test.txt").write_text("Hello SyncGate!")
    Path("/tmp/syncgate_demo/video.mp4").write_text("Video content")
    
    return vfs_root


def cleanup(vfs_root):
    """清理"""
    shutil.rmtree(vfs_root, ignore_errors=True)
    shutil.rmtree("/tmp/syncgate_demo", ignore_errors=True)


def demo():
    print("🎯 SyncGate Complete Demo")
    print("=" * 60)
    
    vfs_root = setup()
    
    try:
        # 初始化
        vfs = VirtualFS(str(vfs_root))
        
        # Local Backend
        local_backend = LocalBackend(
            vfs_root=str(vfs_root),
            local_root="/tmp/syncgate_demo",
            db_path=str(vfs_root / "local_status.db")
        )
        
        # HTTP Backend
        http_backend = HTTPBackend(
            vfs_root=str(vfs_root),
            db_path=str(vfs_root / "http_status.db")
        )
        
        # S3 Backend (mock)
        s3_backend = S3Backend(
            vfs_root=str(vfs_root),
            db_path=str(vfs_root / "s3_status.db"),
            aws_access_key_id="demo_key",
            aws_secret_access_key="demo_secret"
        )
        
        # Gateway (使用 local backend)
        gateway = Gateway(vfs, local_backend)
        
        # 1. 创建链接
        print("\n📝 Step 1: 创建链接")
        vfs.link("/docs/notes.txt", "local:/tmp/syncgate_demo/test.txt", "local")
        vfs.link("/media/video.mp4", "local:/tmp/syncgate_demo/video.mp4", "local")
        vfs.link("/online/api.json", "https://httpbin.org/json", "http")
        vfs.link("/cloud/data.csv", "s3://my-bucket/data/2024.csv", "s3")
        print("  ✅ Local:  /docs/notes.txt")
        print("  ✅ Local:  /media/video.mp4")
        print("  ✅ HTTP:   /online/api.json")
        print("  ✅ S3:     /cloud/data.csv")
        
        # 2. 虚拟文件系统
        print("\n📂 Step 2: 虚拟文件系统结构")
        print(gateway.tree("/", max_depth=3))
        
        # 3. 验证链接
        print("\n🔍 Step 3: 链接验证")
        tests = [
            ("/docs/notes.txt", local_backend),
            ("/online/api.json", http_backend),
        ]
        
        for path, backend in tests:
            status = backend.get_status(path) if hasattr(backend, 'get_status') else {"valid": True, "error": None}
            icon = "✅" if status.get("valid") else "❌"
            print(f"  {icon} {path}")
        
        # 4. S3 URL 解析演示
        print("\n🔗 Step 4: S3 URL 解析")
        s3_urls = [
            "s3://my-bucket/path/to/file.txt",
            "s3://data-lake/2024/01/video.mp4",
        ]
        for url in s3_urls:
            bucket, key = s3_backend._parse_s3_url(url)
            print(f"  {url}")
            print(f"    -> bucket: {bucket}, key: {key}")
        
        print("\n" + "=" * 60)
        print("✅ 演示完成!")
        print("\n📦 安装:")
        print("   pip install syncgate")
        print("   syncgate --help")
        print("\n🔗 GitHub: github.com/cyydark/syncgate")
        
    finally:
        cleanup(vfs_root)


if __name__ == "__main__":
    demo()
