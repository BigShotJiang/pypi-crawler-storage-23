#!/usr/bin/env python3
"""
SyncGate AI Module Demo
演示元数据提取和语义搜索

运行:
    python3 ai_demo.py
"""

from syncgate.ai import AIModule, SimpleEmbedding
from pathlib import Path
import shutil


def demo():
    print("🎯 SyncGate AI Module Demo")
    print("=" * 60)
    
    # 设置
    vfs_root = Path("ai_demo_vfs")
    vfs_root.mkdir(exist_ok=True)
    
    try:
        # 初始化 AI 模块
        ai = AIModule(str(vfs_root))
        
        # 1. 索引一些示例内容
        print("\n📝 Step 1: 索引示例内容")
        contents = [
            ("/docs/python_guide.txt", b"""
            Python is a powerful programming language.
            Its syntax is simple and easy to learn.
            Python is used for web development, data science, and AI.
            """),
            ("/docs/js_guide.txt", b"""
            JavaScript is the core language of web development.
            It can run in browsers and on servers.
            Node.js allows JavaScript to run on the server side.
            """),
            ("/docs/ai_intro.txt", b"""
            Artificial Intelligence (AI) is a branch of computer science.
            Machine learning is an important subfield of AI.
            Deep learning uses neural networks for pattern recognition.
            """),
        ]
        
        # 先收集所有文本构建词汇表
        all_texts = [c[1].decode('utf-8') for c in contents]
        ai.embedding._build_vocab(all_texts)
        print(f"  📚 词汇表大小: {ai.embedding.vocab_size} words")
        
        for path, content in contents:
            ai.index_content(path, content)
            print(f"  ✅ Indexed: {path}")
        
        # 2. 显示索引列表
        print("\n📚 Step 2: 已索引文件")
        indexed = ai.list_indexed()
        for path in indexed:
            print(f"  - {path}")
        
        # 3. 获取元数据
        print("\n📊 Step 3: 文件元数据")
        for path, _ in contents:
            meta = ai.get_metadata(path)
            if meta:
                print(f"  {path}")
                print(f"    Size: {meta['size']} bytes")
                print(f"    Words: {meta['word_count']}")
        
        # 4. 语义搜索
        print("\n🔍 Step 4: 语义搜索")
        queries = [
            "Python 编程",
            "Web 开发",
            "机器学习 AI",
        ]
        
        for query in queries:
            print(f"\n  查询: \"{query}\"")
            results = ai.search(query, limit=2)
            for r in results:
                print(f"    ✅ {r['path']} (相似度: {r['similarity']:.3f})")
        
        print("\n" + "=" * 60)
        print("✅ AI 模块演示完成!")
        print("\n📖 了解更多:")
        print("   GitHub: github.com/cyydark/syncgate")
        
    finally:
        # 清理
        shutil.rmtree(vfs_root, ignore_errors=True)
        print("\n🧹 清理完成")


if __name__ == "__main__":
    demo()
