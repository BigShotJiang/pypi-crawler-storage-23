# Hacker News 提交

## 标题

SyncGate - 统一管理本地文件/HTTP/S3的工具

## 正文

我做了一个轻量级工具 SyncGate，用于统一管理散落在不同存储位置的文件。

**为什么做这个:**
- 我的文件散落在 S3、NAS、本地磁盘...
- 每次要找文件都要切换工具
- 做了一个统一的虚拟文件系统

**核心功能:**
- 📁 本地文件系统
- 🌐 HTTP/HTTPS 链接  
- ☁️ AWS S3 对象存储

**统一访问方式:**
```
$ syncgate link /docs/a.txt local:/path/to/file.txt
$ syncgate ls /docs
✅ a.txt
```

虚拟文件系统，不移动源文件，只管理链接。

**快速开始:**
```bash
pip install syncgate
python3 demo_complete.py
```

🔗 GitHub: https://github.com/cyydark/syncgate
🔗 演示: https://github.com/cyydark/syncgate#demo

---

## 提交链接

https://news.ycombinator.com/submit
