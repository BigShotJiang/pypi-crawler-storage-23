#!/usr/bin/env python3
"""
SyncList Demo Launcher

Usage:
    python demo.py           # Open in browser
    python demo.py --share  # Create shareable link (需要 ngrok)
"""

import os
import sys
import webbrowser
from pathlib import Path
import http.server
import socketserver
import threading


def open_demo():
    """Open demo.html in browser"""
    demo_path = Path(__file__).parent / "demo.html"
    webbrowser.open(f"file://{demo_path.absolute()}")
    print(f"🎯 已打开 SyncList 演示")
    print(f"   文件: {demo_path}")
    print(f"\n📤 分享方式:")
    print(f"   1. 发送 demo.html 文件")
    print(f"   2. 部署到 GitHub Pages: {demo_path}")
    print(f"   3. 使用 ngrok 分享本地服务")


def start_server(port=8080):
    """Start local HTTP server"""
    os.chdir(Path(__file__).parent)
    
    handler = http.server.SimpleHTTPRequestHandler
    
    with socketserver.TCPServer(("", port), handler) as httpd:
        print(f"\n🌐 SyncList 演示服务器已启动")
        print(f"   地址: http://localhost:{port}")
        print(f"   按 Ctrl+C 停止\n")
        httpd.serve_forever()


def main():
    if len(sys.argv) > 1 and sys.argv[1] == "--serve":
        start_server()
    else:
        open_demo()


if __name__ == "__main__":
    main()
