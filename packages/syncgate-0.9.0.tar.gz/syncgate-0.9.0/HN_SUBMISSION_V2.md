# SyncGate - 多存储统一管理工具

**GitHub**: https://github.com/cyydark/syncgate

## 简介

SyncGate 是一个轻量级工具，用于统一管理散落在不同存储位置的文件。

## 核心功能

- **6 种存储后端**: Local, HTTP, S3, WebDAV, FTP, SFTP
- **虚拟文件系统**: 通过 .link 文件管理，不移动源文件
- **REST API**: 支持程序化访问
- **AI 搜索**: 元数据管理和语义搜索
- **完整测试**: 39 个测试，覆盖核心功能

## 支持的存储

| 存储类型 | 协议 | 用途 |
|----------|------|------|
| 本地文件 | local:/ | 个人电脑文件 |
| HTTP | https:// | 在线文档、API |
| AWS S3 | s3:// | 云存储 |
| WebDAV | webdav:// | NAS/私有云 |
| FTP | ftp:// | 传统服务器 |
| SFTP | s3ftp:// | 安全文件传输 |

## 使用示例

```bash
# 创建链接
syncgate link /docs/a.txt local:/path/to/file local
syncgate link /backup/video.mp4 s3://my-bucket/videos/ video

# 列出目录
syncgate ls /docs

# 验证链接
syncgate validate /docs/a.txt
```

## 技术栈

- Python 3.10+
- 无外部依赖 (除存储 SDK)
- 完整 CI/CD
- MIT 许可

## 开源地址

https://github.com/cyydark/syncgate
