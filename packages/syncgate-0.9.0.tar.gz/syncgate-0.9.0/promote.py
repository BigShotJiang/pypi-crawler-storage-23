#!/usr/bin/env python3
"""
SyncGate 一键推广脚本

执行以下操作:
1. 打开 Hacker News 提交页面
2. 打开 Twitter 发推页面
3. 打开 Reddit 发布页面

运行:
    python3 promote.py
"""

import webbrowser
import time


def main():
    print("=" * 60)
    print("SyncGate 推广")
    print("=" * 60)
    
    # 1. Hacker News
    print("\n1. 打开 Hacker News 提交页面...")
    hn_url = "https://news.ycombinator.com/submit"
    webbrowser.open(hn_url)
    time.sleep(1)
    
    # 2. Twitter
    print("\n2. 打开 Twitter 发推页面...")
    twitter_url = "https://twitter.com/intent/tweet?text=SyncGate%20-%20%E7%BB%9F%E4%B8%80%E7%AE%A1%E7%90%86%E6%9C%AC%E5%9C%B0%E3%80%81HTTP%E3%80%81S3%20%E7%9A%84%E5%B7%A5%E5%85%B7%0A%0A%F0%9F%93%81%20local://%0A%F0%9F%8C%90%20https://%0A%E2%98%81%20s3://%0A%0Agithub.com/cyydark/syn..."
    webbrowser.open(twitter_url)
    time.sleep(1)
    
    # 3. Reddit
    print("\n3. 打开 Reddit 发布页面...")
    reddit_url = "https://www.reddit.com/r/programming/submit"
    webbrowser.open(reddit_url)
    time.sleep(1)
    
    print("\n" + "=" * 60)
    print("已打开推广页面！")
    print("=" * 60)
    
    print("""
Hacker News 提交内容:

标题:
SyncGate - 统一管理本地文件/HTTP/S3的工具

正文:
我做了一个轻量级工具 SyncGate，用于统一管理散落在不同存储位置的文件。

核心功能:
- 📁 本地文件系统
- 🌐 HTTP/HTTPS 链接  
- ☁️ AWS S3 对象存储

快速开始:
pip install syncgate

🔗 GitHub: https://github.com/cyydark/syncgate
""")
    
    print("""
Twitter/X 发推内容:

🎯 SyncGate - 多存储路由工具

文件散落在各处？
🔗 一条命令链接所有存储

📁 local://
🌐 https://
☁️ s3://

github.com/cyydark/syncgate

#工具 #开发者 #Python
""")


if __name__ == "__main__":
    main()
