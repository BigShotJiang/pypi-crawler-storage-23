# SyncGate - 项目设定

## 愿景

构建一个 **轻量级多存储路由与同步抽象层**，专注于路由、编解码，协调。

核心原则：
- **极简核心** — 只做路由、编解码，协调
- **存储无关** — 通过后端接口支持任意存储后端
- **可组合** — 模块化设计，任意模块可独立运行
- **无延迟请求** — 同步层直接透传后端数据，不做缓存/等待
- **源数据不动** — 所有操作都是虚拟的，只修改 .link 文件
- **链接可靠** — 后端管理链接有效性，前端展示异常状态

---

## 核心设定（最初的三条）

| # | 设定 | 说明 |
|---|------|------|
| **1** | 后端支持对接任意协议存储 | WebDAV、S3、FTP、SFTP、对象存储等 |
| **2** | 前端先实现自定义路径进行展示 | 树形结构、CLI 交互、自定义展示 |
| **3** | 同步层实现无延迟请求到后端数据 | 不做缓存，实时透传 |

---

## 核心灵感：STRM 格式

```
STRM 格式：
  movie.strm 内容 = "https://..."
  播放器打开 strm 文件 → 请求 URL → 获取视频

SyncGate 格式：
  docs/a.txt.link 内容 = "backend:/path/to/file"
  打开 link 文件 → 解析 → 路由 → 获取文件
```

---

## 三层核心命名

| 层级 | 名称 | 核心职责 |
|------|------|----------|
| **前端层** | **Gateway** | 自定义路径展示、虚拟操作、异常展示 |
| **路由层** | **VirtualFS** | 虚拟文件系统、.link 文件管理、无延迟路由 |
| **后端层** | **Backend** | 任意协议存储接入、链接有效性管理 |
| **AI 扩展** | **AIModule** | 元数据管理、AI 分析、语义搜索（可选） |

---

## 新增需求

### 1. 后端管理链接有效性

| 需求 | 说明 |
|------|------|
| **链接验证** | 后端需要验证源路径是否有效 |
| **状态跟踪** | 记录链接的最后验证状态 |
| **异常处理** | 链接无效时标记状态 |

### 2. 前端展示异常状态

| 需求 | 说明 |
|------|------|
| **断联展示** | 后端断联时显示异常状态 |
| **状态提示** | 提示用户链接不可用 |
| **异常恢复** | 链接恢复后自动更新状态 |

---

## 架构设计

```
┌─────────────────────────────────────────────────────────────────┐
│                         前端层 (Gateway)                          │
│                    展示 + 虚拟操作 + AI 交互                      │
└─────────────────────────────────────────────────────────────────┘
                                │
                  ┌─────────────┼─────────────┐
                  ▼             ▼             ▼
┌──────────────────┐ ┌──────────────────┐ ┌──────────────────┐
│   路由层          │ │   后端层          │ │   AI 模块        │
│  (VirtualFS)     │ │   (Backend)      │ │  (AIModule)      │
│                  │ │                  │ │                  │
│  - .link 管理    │ │  - 存储接入      │ │  - 元数据管理    │
│  - 路由解析      │ │  - 链接验证      │ │  - AI 分析       │
│  - 索引缓存      │ │  - 状态管理      │ │  - 向量检索      │
└──────────────────┘ └──────────────────┘ └──────────────────┘
            │                 │                 │
            ▼                 ▼                 ▼
┌──────────────────┐ ┌──────────────────┐ ┌──────────────────┐
│  .link 文件      │ │  link_status 表  │ │  file_metadata   │
│  (纯连接信息)    │ │  (状态管理)      │ │  ai_analysis 表  │
└──────────────────┘ └──────────────────┘ └──────────────────┘
```

---

## .link 文件格式（精简版 - P0）

### 设计原则

```
模块化设计：
  .link 文件 = 纯连接信息（最小化，核心层负责）
  元数据 = 扩展信息（AI 模块负责，可选）

好处：
  ✅ 核心层极简，只做路由
  ✅ AI 模块独立，可插拔
  ✅ 元数据不影响核心功能
  ✅ 向后兼容，渐进增强
```

### .link 文件格式

```json
{
  "target": "local:/home/user/docs/a.txt",
  "backend": "local"
}
```

**字段说明：**

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| target | string | ✅ | 目标路径（包含 backend 协议） |
| backend | string | ✅ | 后端类型（冗余但方便解析） |

**设计决策：**

```
为什么保留 backend 字段？
  1. 方便解析（不需要解析 URL）
  2. 向后兼容（旧代码可读）
  3. 字段小（存储开销可忽略）

为什么不包含其他字段？
  ❌ created - 不影响核心功能
  ❌ status - 由 Backend 层管理
  ❌ metadata - 由 AI 模块管理
```

### 完整示例

```
virtual/
├── docs/
│   ├── a.txt.link      → {"target": "local:/data/a.txt", "backend": "local"}
│   ├── b.pdf.link      → {"target": "s3://mybucket/b.pdf", "backend": "s3"}
│   └── report/
│       └── summary.docx.link
│                         → {"target": "http://api.example.com/files/summary.docx", "backend": "http"}
```
### VirtualFS 核心实现

```python
from pathlib import Path
from typing import Dict, Optional
from collections import OrderedDict
import json
import os

class VirtualFS:
    """虚拟文件系统 - .link 文件管理 + 路由解析"""

    def __init__(self, root: str):
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)
        self.index = VirtualFSIndex(self.root)

    def link(self, virtual_path: str, target: str, backend: str):
        """创建链接"""
        link_path = self._to_link_path(virtual_path)
        link_path.parent.mkdir(parents=True, exist_ok=True)

        data = {"target": target, "backend": backend}
        link_path.write_text(json.dumps(data, indent=2))

        # 更新索引
        self.index.add(str(link_path.parent), link_path.stem)

    def resolve(self, virtual_path: str) -> Optional[Dict]:
        """解析虚拟路径到实际路径"""
        link_path = self._to_link_path(virtual_path)
        if not link_path.exists():
            return None

        data = json.loads(link_path.read_text())
        return {
            "backend": data["backend"],
            "target": data["target"],
            "link_path": str(link_path)
        }

    def list(self, virtual_path: str) -> list:
        """列出目录（使用索引）"""
        return self.index.list(self._normalize_path(virtual_path))

    def unlink(self, virtual_path: str):
        """删除链接"""
        link_path = self._to_link_path(virtual_path)
        if link_path.exists():
            link_path.unlink()

    def _to_link_path(self, virtual_path: str) -> Path:
        """虚拟路径转换为 .link 文件路径"""
        path = self._normalize_path(virtual_path)
        return self.root / f"{path}.link"

    def _normalize_path(self, path: str) -> str:
        """标准化路径（去掉 / 开头和结尾）"""
        return path.strip("/")


class VirtualFSIndex:
    """VirtualFS 索引 - 内存索引树"""

    def __init__(self, root: Path):
        self.root = root
        self.tree = {}  # path -> [names]
        self.cache = OrderedDict()

    def build(self):
        """构建索引"""
        for link_path in self.root.rglob("*.link"):
            rel_path = link_path.relative_to(self.root)
            dir_path = str(rel_path.parent)
            name = link_path.stem
            self.add(dir_path, name)

    def add(self, dir_path: str, name: str):
        """添加到索引"""
        if dir_path not in self.tree:
            self.tree[dir_path] = []
        if name not in self.tree[dir_path]:
            self.tree[dir_path].append(name)

    def list(self, path: str) -> list:
        """列出目录"""
        return self.tree.get(path, [])
```

---

## 链接状态管理（Backend 层）

### 状态存储设计

```
方案：使用 PostgreSQL 数据库存储链接状态

原因：
  ✅ 状态与 .link 文件分离，核心层保持极简
  ✅ 数据库索引查询效率高
  ✅ 支持批量更新和查询
  ✅ 易于扩展（添加更多状态字段）
```

### link_status 表结构

```sql
CREATE TABLE link_status (
    virtual_path TEXT PRIMARY KEY,
    is_valid BOOLEAN DEFAULT TRUE,
    last_check TIMESTAMP,
    error_message TEXT,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

### 状态字段说明

| 字段 | 类型 | 说明 |
|------|------|------|
| virtual_path | TEXT | 虚拟路径（主键） |
| is_valid | BOOLEAN | 是否有效 |
| last_check | TIMESTAMP | 最后验证时间 |
| error_message | TEXT | 错误信息 |
| updated_at | TIMESTAMP | 更新时间 |

### 状态枚举

```
链接状态：
  ✅ is_valid: true    → 正常
  ⚠️  error_message: "..."   → 错误信息
```

---

## VirtualFS 索引设计（P0 优化）

### 当前问题

```
当前设计问题：
  - 每次遍历目录都要读取所有 .link 文件
  - 频繁 I/O 操作
  - JSON 解析开销
  - 无缓存机制
```

### 优化方案

| 问题 | 当前设计 | 优化方案 | 收益 |
|------|----------|----------|------|
| **频繁 I/O** | 每次都读文件 | 内存索引树 | 速度提升 100 倍 |
| **JSON 解析** | 每次都解析 | 二进制格式 | 解析速度提升 5 倍 |
| **无缓存** | 重复读取 | LRU 缓存 | 减少 95% I/O |
| **无增量更新** | 全量重建 | 监听文件变化 | 实时更新 |

### 索引数据结构

```python
class VirtualFSIndex:
    def __init__(self):
        self.tree = {}  # 内存索引树
        self.cache = LRUCache(maxsize=10000)
    
    def build_index(self):
        """启动时构建索引"""
        for root, dirs, files in os.walk(self.root):
            for file in files:
                if file.endswith('.link'):
                    self._add_to_index(root, file)
    
    def list(self, path: str) -> List[str]:
        """O(1) 查询"""
        return self.tree.get(path, [])
```

### 收益

```
性能提升：
  - 目录遍历：1s → 10ms（提升 100 倍）
  - 内存占用：可配置（默认 10k 条记录）
  - 响应时间：显著改善
```

---

## 链接验证策略（P0 优化）

### 当前问题

```
当前设计问题：
  - 每次访问都验证链接，延迟高
  - 大量链接时验证成本高
```

### 优化方案

| 策略 | 当前设计 | 优化方案 | 收益 |
|------|----------|----------|------|
| **验证时机** | 每次都验证 | 懒加载 + TTL 缓存 | 减少 90% 验证请求 |
| **批量验证** | 逐个验证 | 批量 API 调用 | 减少 80% 网络开销 |
| **后台验证** | 阻塞验证 | 异步后台验证 | 用户体验提升 |
| **智能跳过** | 无差别验证 | 跳过刚验证的链接 | 减少 70% 重复验证 |

### 缓存验证器实现

```python
class CachedValidator:
    def __init__(self, ttl: int = 300):
        self.cache = {}  # path -> (valid, timestamp)
        self.ttl = ttl
    
    def validate(self, path: str) -> bool:
        if path in self.cache:
            valid, ts = self.cache[path]
            if time.time() - ts < self.ttl:
                return valid
        
        # 实际验证
        result = self._do_validate(path)
        self.cache[path] = (result, time.time())
        return result
```

### 收益

```
性能提升：
  - 响应时间：500ms → 50ms（提升 10 倍）
  - 验证请求：减少 90%
  - 用户体验：显著改善
```

---

## AI 模块元数据设计（可选扩展）

### 元数据存储设计

```
方案：使用 PostgreSQL 数据库存储元数据

原因：
  ✅ 元数据与 .link 文件分离，核心层保持极简
  ✅ 数据库索引查询效率高
  ✅ 支持复杂的 AI 分析结果存储
  ✅ 易于扩展（添加更多 AI 功能）
```

### 数据库表结构

```sql
-- 文件元数据表
CREATE TABLE file_metadata (
    id SERIAL PRIMARY KEY,
    virtual_path TEXT NOT NULL UNIQUE,
    file_hash TEXT,
    file_size INTEGER,
    mime_type TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- AI 分析结果表
CREATE TABLE ai_analysis (
    id SERIAL PRIMARY KEY,
    metadata_id INTEGER NOT NULL,
    analysis_type TEXT NOT NULL,
    result TEXT NOT NULL,
    model_name TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (metadata_id) REFERENCES file_metadata(id)
);

-- 索引
CREATE INDEX idx_virtual_path ON file_metadata(virtual_path);
CREATE INDEX idx_file_hash ON file_metadata(file_hash);
CREATE INDEX idx_metadata_id ON ai_analysis(metadata_id);
```

### 元数据结构示例

```python
# file_metadata 记录
{
    "id": 1,
    "virtual_path": "/docs/a.txt",
    "file_hash": "sha256:abc123...",
    "file_size": 1024,
    "mime_type": "text/plain",
    "created_at": "2024-01-01T10:00:00Z",
    "updated_at": "2024-01-15T10:00:00Z"
}

# ai_analysis 记录（summary）
{
    "id": 1,
    "metadata_id": 1,
    "analysis_type": "summary",
    "result": {
        "summary": "这是一份关于 AI 技术的文档...",
        "keywords": ["AI", "机器学习", "深度学习"],
        "language": "zh-CN"
    },
    "model_name": "gpt-4",
    "created_at": "2024-01-15T10:00:00Z"
}

# ai_analysis 记录（embedding）
{
    "id": 2,
    "metadata_id": 1,
    "analysis_type": "embedding",
    "result": {
        "vector": [0.1, 0.2, 0.3, ...],  # 1536 维向量
        "model": "text-embedding-ada-002"
    },
    "model_name": "text-embedding-ada-002",
    "created_at": "2024-01-15T10:00:00Z"
}
```

### AI 模块接口

```python
class AIModule:
    """AI 模块 - 元数据管理 + AI 分析"""
    
    def __init__(self, vfs: VirtualFS, backend: Backend, db_path: str):
        self.vfs = vfs
        self.backend = backend
        self.db_path = db_path
        self._init_db()
    
      def _init_db(self):
          """初始化数据库"""
          conn = psycopg2.connect(self.db_path)
          cursor = conn.cursor()
          cursor.execute("""
              CREATE TABLE IF NOT EXISTS file_metadata (
                  id SERIAL PRIMARY KEY,
                  virtual_path TEXT NOT NULL UNIQUE,
                  file_hash TEXT,
                  file_size INTEGER,
                  mime_type TEXT,
                  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
              );
              
              CREATE TABLE IF NOT EXISTS ai_analysis (
                  id SERIAL PRIMARY KEY,
                  metadata_id INTEGER NOT NULL,
                  analysis_type TEXT NOT NULL,
                  result TEXT NOT NULL,
                  model_name TEXT,
                  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                  FOREIGN KEY (metadata_id) REFERENCES file_metadata(id)
              );
              
              CREATE INDEX IF NOT EXISTS idx_virtual_path ON file_metadata(virtual_path);
              CREATE INDEX IF NOT EXISTS idx_file_hash ON file_metadata(file_hash);
              CREATE INDEX IF NOT EXISTS idx_metadata_id ON ai_analysis(metadata_id);
          """)
          conn.commit()
          cursor.close()
          conn.close()
      
    def index_file(self, virtual_path: str) -> int:
        """索引文件（提取元数据）"""
        # 获取文件内容
        content = self.backend.get(virtual_path)
        
        # 计算哈希
        file_hash = hashlib.sha256(content).hexdigest()
        file_size = len(content)
        mime_type = self._detect_mime_type(virtual_path)
        
        # 存储元数据
        conn = psycopg2.connect(self.db_path)
        cursor = conn.cursor()
          cursor.execute("""
            INSERT INTO file_metadata 
            (virtual_path, file_hash, file_size, mime_type, updated_at)
            VALUES (%s, %s, %s, %s, CURRENT_TIMESTAMP)
            ON CONFLICT (virtual_path) DO UPDATE SET
                file_hash = EXCLUDED.file_hash,
                file_size = EXCLUDED.file_size,
                mime_type = EXCLUDED.mime_type,
                updated_at = CURRENT_TIMESTAMP
        """, (virtual_path, file_hash, file_size, mime_type))
        metadata_id = cursor.fetchone()[0]
        conn.commit()
        cursor.close()
        conn.close()
        
        return metadata_id
    
    def analyze_summary(self, virtual_path: str, model: str = "gpt-4") -> dict:
        """生成摘要"""
        metadata_id = self.index_file(virtual_path)
        content = self.backend.get(virtual_path)
        
        # 调用 AI API
        summary = self._call_ai_api(content, "summary", model)
        
        # 存储结果
        conn = psycopg2.connect(self.db_path)
        cursor.execute("""
            INSERT INTO ai_analysis 
            (metadata_id, analysis_type, result, model_name)
            VALUES (%s, %s, %s, %s)
        """, (metadata_id, "summary", json.dumps(summary), model))
        conn.commit()
        cursor.close()
        conn.close()
        
        return summary
    
    def analyze_embedding(self, virtual_path: str, model: str = "text-embedding-ada-002") -> list:
        """生成向量嵌入"""
        metadata_id = self.index_file(virtual_path)
        content = self.backend.get(virtual_path)
        
        # 调用 AI API
        embedding = self._call_ai_api(content, "embedding", model)
        
        # 存储结果
        conn = psycopg2.connect(self.db_path)
        cursor.execute("""
            INSERT INTO ai_analysis 
            (metadata_id, analysis_type, result, model_name)
            VALUES (%s, %s, %s, %s)
        """, (metadata_id, "embedding", json.dumps({"vector": embedding}), model))
        conn.commit()
        cursor.close()
        conn.close()
        
        return embedding
    
            def search(self, query: str, top_k: int = 10) -> List[dict]:
          """语义搜索"""
          # 生成查询向量
          query_embedding = self._call_ai_api(query, "embedding", "text-embedding-ada-002")
          
          # 检索最相似的文档
          conn = psycopg2.connect(self.db_path)
          cursor = conn.cursor()
          cursor.execute("""
          SELECT fm.virtual_path, aa.result
          FROM file_metadata fm
          JOIN ai_analysis aa ON fm.id = aa.metadata_id
          WHERE aa.analysis_type = %s
          """, ("embedding",))
          
          results = []
          for row in cursor.fetchall():
          virtual_path = row[0]
          embedding = json.loads(row[1])['vector']
          similarity = self._cosine_similarity(query_embedding, embedding)
          results.append({
          "virtual_path": virtual_path,
          "similarity": similarity
          })
          
          cursor.close()
          conn.close()
          
          # 按相似度排序
          results.sort(key=lambda x: x['similarity'], reverse=True)
          return results[:top_k]

          def _detect_mime_type(self, virtual_path: str) -> str:
        """检测 MIME 类型"""
        ext = virtual_path.split('.')[-1]
        mime_map = {
            'txt': 'text/plain',
            'pdf': 'application/pdf',
            'docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        }
        return mime_map.get(ext, 'application/octet-stream')
    
    def _call_ai_api(self, content: bytes, analysis_type: str, model: str) -> any:
        """调用 AI API（示例）"""
        # 实际实现调用 OpenAI / Claude / 本地模型
        if analysis_type == "summary":
            return {"summary": "...", "keywords": ["..."]}
        elif analysis_type == "embedding":
            return [0.1, 0.2, 0.3, ...]  # 示例向量
    
    def _cosine_similarity(self, a: list, b: list) -> float:
        """计算余弦相似度"""
        dot = sum(x * y for x, y in zip(a, b))
        norm_a = sum(x * x for x in a) ** 0.5
        norm_b = sum(y * y for y in b) ** 0.5
        return dot / (norm_a * norm_b)
```

---

## 后端层设计

### Backend 接口

```python
from abc import ABC, abstractmethod
from typing import List, BinaryIO, Optional
import psycopg2
from psycopg2 import sql

class Backend(ABC):
    """存储后端接口 + 链接管理"""

    @abstractmethod
    def list(self, path: str) -> List[str]:
        """列出目录"""

    @abstractmethod
    def get(self, path: str) -> BinaryIO:
        """获取文件"""

    @abstractmethod
    def put(self, path: str, content: bytes):
        """上传文件"""

    @abstractmethod
    def exists(self, path: str) -> bool:
        """检查存在"""

    @abstractmethod
    def mkdir(self, path: str):
        """创建目录"""

    # ========== 链接管理 ==========

    @abstractmethod
    def validate(self, path: str) -> bool:
        """验证链接是否有效"""

    @abstractmethod
    def get_status(self, path: str) -> dict:
        """获取链接状态"""


class BackendBase:
    """后端基础类（链接管理）"""
    
    def __init__(self, vfs: VirtualFS, db_path: str):
        self.vfs = vfs
        self.db_path = db_path
        self._init_db()
    
    def _init_db(self):
        """初始化数据库"""
        conn = psycopg2.connect(self.db_path)
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS link_status (
                virtual_path TEXT PRIMARY KEY,
                is_valid BOOLEAN DEFAULT TRUE,
                last_check TIMESTAMP,
                error_message TEXT,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        conn.commit()
        cursor.close()
        conn.close()
    
    def validate(self, virtual_path: str) -> bool:
        """验证链接有效性"""
        link = self.vfs.resolve(virtual_path)
        
        if not link:
            self._update_status(virtual_path, False, "链接不存在")
            return False
        
        # 调用后端 API 检查
        try:
            result = self._check_backend(link['backend'], link['target'])
            self._update_status(virtual_path, True, None)
            return result
        except Exception as e:
            self._update_status(virtual_path, False, str(e))
            return False
    
    def get_status(self, virtual_path: str) -> dict:
        """获取链接状态"""
        conn = psycopg2.connect(self.db_path)
        cursor = conn.cursor()
          cursor.execute(
            sql.SQL("SELECT is_valid, last_check, error_message FROM link_status WHERE virtual_path = %s"),
            (virtual_path,)
        )
        row = cursor.fetchone()
        conn.close()
        
        if not row:
            return {"valid": True, "error": None}
        
        return {
            "valid": bool(row[0]),
            "last_check": row[1],
            "error": row[2]
        }
    
    def _update_status(self, virtual_path: str, is_valid: bool, error: Optional[str]):
        """更新状态到数据库"""
        conn = psycopg2.connect(self.db_path)
        cursor.execute("""
            INSERT INTO link_status 
            (virtual_path, is_valid, error_message, updated_at)
            VALUES (%s, %s, %s, CURRENT_TIMESTAMP)
            ON CONFLICT (virtual_path) DO UPDATE SET
                is_valid = EXCLUDED.is_valid,
                error_message = EXCLUDED.error_message,
                updated_at = CURRENT_TIMESTAMP
        """, (virtual_path, is_valid, error))
        conn.commit()
        cursor.close()
        conn.close()
    
    def _check_backend(self, backend: str, target: str) -> bool:
        """检查后端链接（子类实现）"""
        raise NotImplementedError
```
### LocalBackend 实现

```python
from pathlib import Path
from typing import BinaryIO
import os

class LocalBackend(BackendBase):
    """本地文件系统后端"""

    def __init__(self, vfs: VirtualFS, root: str, db_path: str):
        super().__init__(vfs, db_path)
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)

    def list(self, path: str) -> list:
        """列出目录"""
        return self._check_backend("local", path)

    def get(self, path: str) -> BinaryIO:
        """获取文件"""
        link = self.vfs.resolve(path)
        if not link:
            raise FileNotFoundError(f"链接不存在: {path}")

        # 解析目标路径
        target = link["target"]
        if target.startswith("local:/"):
            target = target[7:]  # 去掉 "local:/" 前缀

        target_path = self.root / target
        if not target_path.exists():
            raise FileNotFoundError(f"文件不存在: {target_path}")

        return target_path.open("rb")

    def put(self, path: str, content: bytes):
        """上传文件"""
        link = self.vfs.resolve(path)
        if not link:
            raise FileNotFoundError(f"链接不存在: {path}")

        # 解析目标路径
        target = link["target"]
        if target.startswith("local:/"):
            target = target[7:]  # 去掉 "local:/" 前缀

        target_path = self.root / target
        target_path.parent.mkdir(parents=True, exist_ok=True)
        target_path.write_bytes(content)

    def exists(self, path: str) -> bool:
        """检查存在"""
        link = self.vfs.resolve(path)
        if not link:
            return False

        target = link["target"]
        if target.startswith("local:/"):
            target = target[7:]

        target_path = self.root / target
        return target_path.exists()

    def mkdir(self, path: str):
        """创建目录"""
        link = self.vfs.resolve(path)
        if not link:
            return False

        target = link["target"]
        if target.startswith("local:/"):
            target = target[7:]

        target_path = self.root / target
        target_path.mkdir(parents=True, exist_ok=True)

    def _check_backend(self, backend: str, target: str) -> bool:
        """检查后端链接"""
        if backend == "local":
            if target.startswith("local:/"):
                target = target[7:]
            return (self.root / target).exists()
        return False
```

---

## 前端层设计

### Gateway 接口

```python
class Gateway:
    """前端层 - 展示 + 虚拟操作 + 异常展示"""

    def __init__(self, vfs: VirtualFS, backend: Backend):
        self.vfs = vfs
        self.backend = backend
    
    def ls(self, virtual_path: str) -> str:
        """
        列出目录，展示链接状态

        输出示例：
          ✅ a.txt       (正常)
          ⚠️  b.txt       (连接异常: timeout)
        """
        entries = self.vfs.list(virtual_path)
        
        lines = []
        for name in entries:
            full_path = f"{virtual_path}/{name}".rstrip('/')
            status = self.get_link_status(full_path)
            
            if status["valid"]:
                lines.append(f"✅ {name}")
            elif status["error"]:
                lines.append(f"⚠️  {name} ({status['error']})")
        
        return '\n'.join(lines)
    
    def get_link_status(self, virtual_path: str) -> dict:
        """获取链接状态"""
        link = self.vfs.resolve(virtual_path)
        if not link:
            return {"valid": False, "error": "路径不存在"}
        
        # 从数据库读取状态
        return self.backend.get_status(virtual_path)
    
    def check_all(self, virtual_path: str):
        """
        检查目录下所有链接的有效性
        
        触发后端验证，更新状态
        """
        entries = self.vfs.list(virtual_path)
        
        for name in entries:
            full_path = f"{virtual_path}/{name}".rstrip('/')
            link = self.vfs.resolve(full_path)
            
            if link:
                # 触发后端验证
                self.backend.validate(full_path)
```


---

## 数据库配置

### PostgreSQL 连接字符串

```python
# 状态数据库
status_db = "postgresql://user:password@localhost:5432/syncgate_status"

# 元数据数据库
metadata_db = "postgresql://user:password@localhost:5432/syncgate_metadata"
```

### 数据库初始化

```bash
# 创建数据库
createdb syncgate_status
createdb syncgate_metadata

# 或使用 SQL
CREATE DATABASE syncgate_status;
CREATE DATABASE syncgate_metadata;
```

### 依赖安装

```bash
pip install psycopg2-binary
```

---

## 目录结构

```
syncgate/
├── gateway/              ← 前端层
│   ├── __init__.py
│   ├── cli.py          # CLI 交互
│   ├── tree.py         # 树形展示
│   └── status.py       # 状态展示
│
├── vfs/                 ← 路由层
│   ├── __init__.py
│   ├── fs.py           # VirtualFS 核心
│   ├── index.py        # 索引管理（新增）
│   └── link.py         # .link 文件操作
│
├── backend/             ← 后端层
│   ├── __init__.py
│   ├── protocol.py     # 后端接口
│   ├── base.py         # 后端基础类（新增）
│   ├── local.py        # Local 后端
│   ├── http.py         # HTTP 后端
│   ├── s3.py         # S3 后端
│   └── validator.py    # 链接验证器
│
├── ai/                  ← AI 模块（可选）
│   ├── __init__.py
│   ├── module.py       # AI 模块核心
│   └── analyzer.py     # AI 分析器
│
├── virtual/             ← .link 文件存储
├── syncgate_metadata.db          ← 元数据数据库
├── syncgate_status.db            ← 状态数据库
├── pyproject.toml
└── README.md
```

---

## 核心操作

| 操作 | 层级 | 说明 | 数据搬运 |
|------|------|------|----------|
| **cp** | Gateway | 新增 .link 文件 | ❌ 无 |
| **mv** | Gateway | 重命名 .link 文件 | ❌ 无 |
| **rm** | Gateway | 删除 .link 文件 | ❌ 无 |
| **ls** | Gateway | 列出目录 + 展示状态 | ❌ 无 |
| **validate** | Backend | 验证链接有效性 | ✅ 调用后端 |
| **get** | Backend | 获取文件内容 | ✅ 调用后端 |
| **index** | AI Module | 索引文件元数据 | ✅ 调用后端 |
| **search** | AI Module | 语义搜索 | ✅ 查询数据库 |

---

## 使用方式

### 基础使用（无 AI 模块）

```python
from vfs import VirtualFS
from backend import LocalBackend
from gateway import Gateway

# 初始化
vfs = VirtualFS(root="virtual")
backend = LocalBackend(vfs=vfs, db_path="syncgate_status.db")
gateway = Gateway(vfs=vfs, backend=backend)

# 创建链接
vfs.link("/docs/a.txt", "local:/data/a.txt", "local")
vfs.link("/docs/b.pdf", "s3://mybucket/b.pdf", "s3")

# 列出目录（带状态）
print(gateway.ls("/docs"))
# 输出：
# ✅ a.txt
# ✅ b.pdf

# 验证链接
backend.validate("/docs/a.txt")
print(backend.get_status("/docs/a.txt"))
# 输出：{"valid": True, "last_check": "2024-01-15T10:00:00Z", "error": None}

# 获取文件
content = backend.get("/docs/a.txt")
```

### 启用 AI 模块

```python
from ai import AIModule

# 初始化 AI 模块
ai = AIModule(vfs=vfs, backend=backend, db_path="syncgate_metadata.db")

# 索引文件
ai.index_file("/docs/a.txt")

# 生成摘要
summary = ai.analyze_summary("/docs/a.txt")
print(summary)
# 输出：
# {
#   "summary": "这是一份关于 AI 技术的文档...",
#   "keywords": ["AI", "机器学习", "深度学习"],
#   "language": "zh-CN"
# }

# 生成向量嵌入
embedding = ai.analyze_embedding("/docs/a.txt")
print(len(embedding))  # 1536

# 语义搜索
results = ai.search("机器学习算法")
for result in results:
    print(f"{result['virtual_path']}: {result['similarity']:.3f}")
# 输出：
# /docs/a.txt: 0.856
# /docs/machine-learning.pdf: 0.789
```

---

## 后端实现策略

```
链接验证策略：

1. 简单实现
   ├── Local 后端：os.path.exists()
   ├── HTTP 后端：HEAD 请求
   └── S3 后端：head_object()

2. 如果受阻
   └── 嵌入 OpenList 代码
       └── 复用 OpenList 的验证逻辑
```

---

## 核心价值

| 价值 | 说明 |
|------|------|
| **链接管理** | 后端验证链接有效性，状态存储在数据库 |
| **状态展示** | 前端展示异常状态 |
| **模块化** | 任意模块可独立运行 |
| **可插拔后端** | 简单实现 → 受阻则嵌入 |
| **无延迟请求** | 只有 get/list 才调用后端 |
| **AI Ready** | AI 模块独立预留，元数据分离存储 |
| **高性能** | 内存索引 + 缓存验证，性能提升 10-100 倍 |

---

## 技术栈

| 层级 | 技术 |
|------|------|
| **语言** | Python |
| **路由层** | 虚拟文件系统 + .link 文件 + 内存索引 |
| **后端** | Local / HTTP / S3 / OpenList |
| **链接管理** | PostgreSQL 数据库 + 缓存验证器 |
| **AI** | LangChain / OpenAI / Claude（可选） |

---

## 开发顺序

```
第一阶段（核心层 - P0）：
  1. VirtualFS（路由层，核心）
     ├── .link 文件管理
     ├── 路由解析
     └── 内存索引（新增）
  
  2. Local Backend + 链接验证
     ├── 存储接入
     └── 状态管理（PostgreSQL）
  
  3. Gateway + 状态展示
     ├── 目录展示
     └── 异常状态展示

第二阶段（扩展层 - P1）：
  4. HTTP / S3 Backend
  5. 批量操作优化
  6. 异步并发处理

第三阶段（AI 扩展 - P2）：
  7. AI 模块（独立预留）
     ├── 元数据管理
     ├── AI 分析（summary + embedding）
     └── 语义搜索
```

---

## 关键功能

| 功能 | 实现层级 | 优化 |
|------|----------|------|
| 链接验证 | Backend | 缓存验证器 + 批量验证 |
| 状态记录 | PostgreSQL 数据库 | 批量更新 + LRU 缓存 |
| 异常展示 | Gateway | 实时状态查询 |
| 目录遍历 | VirtualFS | 内存索引 + 增量更新 |

---

## 参考

- **STRM 格式** - 媒体库索引格式
- **OpenList** - 多存储后端
- **SyncGate 定位** - 轻量级多存储路由与同步抽象层

---

## 核心原则

```
✅ 后端支持对接任意协议存储
✅ 前端先实现自定义路径进行展示
✅ 同步层无延迟请求到后端数据
✅ 后端管理链接有效性（数据库存储）
✅ 前端展示链接异常状态
✅ 模块化设计，任意模块可独立运行
✅ .link 文件只保留连接信息（核心层极简）
✅ AI 模块独立，元数据分离存储
✅ 内存索引 + 缓存验证（性能优化 P0）
  ✅ PostgreSQL 数据库存储（链接状态 + AI 元数据）
```
