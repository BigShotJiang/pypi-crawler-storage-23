"""Monitoring and statistics for SyncGate."""

import json
import os
import time
from pathlib import Path
from typing import Dict, List, Optional
from datetime import datetime, timedelta


class StatsCollector:
    """Collect and analyze SyncGate statistics."""

    def __init__(self, vfs_root: str = "virtual"):
        self.vfs_root = Path(vfs_root)
        self.stats_file = self.vfs_root / "stats.json"
        self._load()

    def _load(self):
        """Load stats from file."""
        if self.stats_file.exists():
            try:
                with open(self.stats_file) as f:
                    self.stats = json.load(f)
            except:
                self.stats = self._default_stats()
        else:
            self.stats = self._default_stats()

    def _default_stats(self) -> Dict:
        """Get default stats structure."""
        return {
            "created": 0,
            "deleted": 0,
            "validated": 0,
            "errors": 0,
            "last_used": None,
            "total_links": 0,
            "by_backend": {},
            "by_day": {},
        }

    def _save(self):
        """Save stats to file."""
        self.stats["last_used"] = datetime.now().isoformat()
        with open(self.stats_file, 'w') as f:
            json.dump(self.stats, f, indent=2)

    def _get_today_key(self) -> str:
        """Get today's date key."""
        return datetime.now().strftime("%Y-%m-%d")

    def record_create(self, backend: str = "local"):
        """Record link creation."""
        self.stats["created"] += 1
        self.stats["by_backend"][backend] = self.stats["by_backend"].get(backend, 0) + 1

        today = self._get_today_key()
        self.stats["by_day"][today] = self.stats["by_day"].get(today, 0) + 1

        self._save()

    def record_delete(self, backend: str = "local"):
        """Record link deletion."""
        self.stats["deleted"] += 1
        self._save()

    def record_validate(self, success: bool = True):
        """Record validation."""
        self.stats["validated"] += 1
        if not success:
            self.stats["errors"] += 1
        self._save()

    def get_total_links(self, vfs) -> int:
        """Get total number of links."""
        count = 0
        for root, dirs, files in vfs._index.walk():
            for link in root.iterdir():
                if link.suffix == ".link":
                    count += 1
        self.stats["total_links"] = count
        self._save()
        return count

    def get_summary(self) -> Dict:
        """Get stats summary."""
        return {
            "total_links": self.stats["total_links"],
            "created": self.stats["created"],
            "deleted": self.stats["deleted"],
            "validated": self.stats["validated"],
            "errors": self.stats["errors"],
            "last_used": self.stats["last_used"],
        }

    def get_backend_stats(self) -> Dict:
        """Get stats by backend."""
        return self.stats.get("by_backend", {})

    def get_activity_by_day(self, days: int = 7) -> List[Dict]:
        """Get activity for last N days."""
        today = datetime.now()
        result = []

        for i in range(days):
            date = (today - timedelta(days=i)).strftime("%Y-%m-%d")
            count = self.stats.get("by_day", {}).get(date, 0)
            result.append({
                "date": date,
                "created": count,
            })

        return result

    def get_health_score(self) -> float:
        """Calculate health score (0-100)."""
        total = self.stats["created"]
        if total == 0:
            return 0

        errors = self.stats["errors"]
        validations = self.stats["validated"]

        # Score based on error rate and validation rate
        error_rate = errors / total if total > 0 else 0
        validation_rate = validations / total if total > 0 else 0

        # Higher score for more validations, lower for errors
        score = (validation_rate * 50) + (50 - error_rate * 50)
        return max(0, min(100, score))

    def reset(self):
        """Reset all stats."""
        self.stats = self._default_stats()
        self._save()


class PerformanceMonitor:
    """Monitor performance metrics."""

    def __init__(self):
        self.operations = []
        self.slow_threshold = 1.0  # seconds

    def start_operation(self, name: str):
        """Start tracking an operation."""
        self.current_operation = {
            "name": name,
            "start_time": time.time(),
            "end_time": None,
            "duration": None,
        }

    def end_operation(self, success: bool = True, error: str = None):
        """End tracking an operation."""
        self.current_operation["end_time"] = time.time()
        self.current_operation["duration"] = time.time() - self.current_operation["start_time"]
        self.current_operation["success"] = success
        self.current_operation["error"] = error

        self.operations.append(self.current_operation)

        # Keep only last 100 operations
        if len(self.operations) > 100:
            self.operations = self.operations[-100:]

    def get_stats(self) -> Dict:
        """Get performance stats."""
        if not self.operations:
            return {"count": 0}

        durations = [op["duration"] for op in self.operations if op["duration"]]
        success_count = sum(1 for op in self.operations if op.get("success", True))

        return {
            "count": len(self.operations),
            "success_rate": success_count / len(self.operations) if self.operations else 0,
            "avg_duration": sum(durations) / len(durations) if durations else 0,
            "max_duration": max(durations) if durations else 0,
            "slow_operations": [op for op in self.operations if op["duration"] and op["duration"] > self.slow_threshold],
        }

    def get_slow_operations(self, threshold: float = None) -> List[Dict]:
        """Get operations slower than threshold."""
        if threshold is None:
            threshold = self.slow_threshold

        return [op for op in self.operations if op.get("duration", 0) > threshold]

    def reset(self):
        """Reset all tracked operations."""
        self.operations = []
