#!/usr/bin/env python3
"""SyncGate CLI entry point."""

import argparse
import sys
from pathlib import Path

from syncgate import __version__
from syncgate.vfs.fs import VirtualFS
from syncgate.backend.local import LocalBackend
from syncgate.backend.http import HTTPBackend
from syncgate.backend.s3 import S3Backend
from syncgate.backend.webdav import WebDAVBackend
from syncgate.backend.ftp import FTPBackend
from syncgate.backend.sftp import SFTPBackend
from syncgate.gateway.gateway import Gateway
from syncgate.utils import Config, Logger


logger = Logger("syncgate")


def get_backend(vfs_root: str, args) -> LocalBackend:
    """Get appropriate backend."""
    db_path = str(Path(vfs_root) / "status.db")
    return LocalBackend(vfs_root=vfs_root, local_root=vfs_root, db_path=db_path)


def cmd_ls(args):
    """List directory contents."""
    vfs = VirtualFS(args.vfs_root)
    backend = get_backend(args.vfs_root, args)
    gateway = Gateway(vfs, backend)
    print(gateway.ls(args.path))


def cmd_tree(args):
    """Display tree structure."""
    vfs = VirtualFS(args.vfs_root)
    backend = get_backend(args.vfs_root, args)
    gateway = Gateway(vfs, backend)
    print(gateway.tree(args.path, max_depth=args.max_depth))


def cmd_link(args):
    """Create a link."""
    vfs = VirtualFS(args.vfs_root)
    vfs.link(args.virtual_path, args.target, args.backend)
    logger.success(f"Linked: {args.virtual_path} -> {args.target}")


def cmd_unlink(args):
    """Remove a link."""
    vfs = VirtualFS(args.vfs_root)
    if vfs.unlink(args.virtual_path):
        logger.success(f"Unlinked: {args.virtual_path}")
    else:
        logger.error(f"Not found: {args.virtual_path}")


def cmd_validate(args):
    """Validate links."""
    vfs = VirtualFS(args.vfs_root)
    backend = get_backend(args.vfs_root, args)
    gateway = Gateway(vfs, backend)

    if args.all:
        results = gateway.validate_dir(args.path)
        for name, valid in results.items():
            status = "✅" if valid else "❌"
            print(f"{status} {name}")
    else:
        valid = gateway.validate(args.path)
        status = "✅" if valid else "❌"
        print(f"{status} {args.path}")


def cmd_status(args):
    """Show link status."""
    vfs = VirtualFS(args.vfs_root)
    backend = get_backend(args.vfs_root, args)
    gateway = Gateway(vfs, backend)
    status = gateway.get_link_status(args.path)
    print(f"Status: {status}")


def cmd_config(args):
    """Manage configuration."""
    config = Config()
    
    if args.action == "get":
        value = config.get(args.key)
        print(f"{args.key}: {value}")
    elif args.action == "set":
        config.set(args.key, args.value)
        logger.success(f"Set {args.key} = {args.value}")
    elif args.action == "list":
        all_config = config.get_all()
        for key, value in all_config.items():
            print(f"{key}: {value}")
    elif args.action == "path":
        print(config.path)


def cmd_version(args):
    """Show version."""
    print(f"SyncGate {__version__}")


def main():
    parser = argparse.ArgumentParser(
        description="SyncGate - Multi-storage routing and sync abstraction layer",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument("--version", action="version", version=f"SyncGate {__version__}")
    parser.set_defaults(func=lambda x: parser.print_help())

    subparsers = parser.add_subparsers(title="commands", dest="command")

    # ls command
    ls_parser = subparsers.add_parser("ls", help="List directory contents")
    ls_parser.add_argument("path", help="Virtual path")
    ls_parser.add_argument("--vfs-root", default="virtual", help="VFS root directory")
    ls_parser.set_defaults(func=cmd_ls)

    # tree command
    tree_parser = subparsers.add_parser("tree", help="Display tree structure")
    tree_parser.add_argument("path", help="Virtual path")
    tree_parser.add_argument("--vfs-root", default="virtual", help="VFS root directory")
    tree_parser.add_argument("--max-depth", type=int, default=3, help="Maximum depth")
    tree_parser.set_defaults(func=cmd_tree)

    # link command
    link_parser = subparsers.add_parser("link", help="Create a link")
    link_parser.add_argument("virtual_path", help="Virtual path")
    link_parser.add_argument("target", help="Target URL")
    link_parser.add_argument("backend", help="Backend type")
    link_parser.add_argument("--vfs-root", default="virtual", help="VFS root directory")
    link_parser.set_defaults(func=cmd_link)

    # unlink command
    unlink_parser = subparsers.add_parser("unlink", help="Remove a link")
    unlink_parser.add_argument("virtual_path", help="Virtual path")
    unlink_parser.add_argument("--vfs-root", default="virtual", help="VFS root directory")
    unlink_parser.set_defaults(func=cmd_unlink)

    # validate command
    validate_parser = subparsers.add_parser("validate", help="Validate links")
    validate_parser.add_argument("path", help="Virtual path")
    validate_parser.add_argument("--vfs-root", default="virtual", help="VFS root directory")
    validate_parser.add_argument("--all", action="store_true", help="Validate all links in directory")
    validate_parser.set_defaults(func=cmd_validate)

    # status command
    status_parser = subparsers.add_parser("status", help="Show link status")
    status_parser.add_argument("path", help="Virtual path")
    status_parser.add_argument("--vfs-root", default="virtual", help="VFS root directory")
    status_parser.set_defaults(func=cmd_status)

    # config command
    config_parser = subparsers.add_parser("config", help="Manage configuration")
    config_subparsers = config_parser.add_subparsers(title="actions", dest="config_action")
    
    config_get = config_subparsers.add_parser("get", help="Get config value")
    config_get.add_argument("key", help="Config key")
    
    config_set = config_subparsers.add_parser("set", help="Set config value")
    config_set.add_argument("key", help="Config key")
    config_set.add_argument("value", help="Config value")
    
    config_list = config_subparsers.add_parser("list", help="List all config")
    
    config_path = config_subparsers.add_parser("path", help="Show config file path")
    
    config_parser.set_defaults(func=cmd_config)

    # version command
    version_parser = subparsers.add_parser("version", help="Show version")
    version_parser.set_defaults(func=cmd_version)

    args = parser.parse_args()

    try:
        args.func(args)
    except Exception as e:
        logger.error(str(e))
        sys.exit(1)


if __name__ == "__main__":
    main()
