"""
错误处理模块

提供详细的错误信息和恢复建议。
"""

from enum import Enum
from dataclasses import dataclass, field
from typing import Optional, Dict, Any, List
import functools
import time


class ErrorType(Enum):
    """错误类型"""
    # 通用错误
    UNKNOWN = "unknown"
    VALIDATION_ERROR = "validation_error"
    
    # 连接错误
    CONNECTION_FAILED = "connection_failed"
    TIMEOUT = "timeout"
    NETWORK_UNREACHABLE = "network_unreachable"
    
    # 认证错误
    AUTH_FAILED = "auth_failed"
    PERMISSION_DENIED = "permission_denied"
    INVALID_CREDENTIALS = "invalid_credentials"
    
    # 文件错误
    FILE_NOT_FOUND = "file_not_found"
    FILE_EXISTS = "file_exists"
    IS_DIRECTORY = "is_directory"
    NOT_A_DIRECTORY = "not_a_directory"
    
    # 后端错误
    BACKEND_ERROR = "backend_error"
    BACKEND_UNAVAILABLE = "backend_unavailable"
    
    # 配置错误
    CONFIG_ERROR = "config_error"
    MISSING_CONFIG = "missing_config"


class RecoverySuggestion(Enum):
    """恢复建议"""
    # 通用建议
    CHECK_CONNECTION = "check_connection"
    CHECK_CREDENTIALS = "check_credentials"
    CHECK_PERMISSIONS = "check_permissions"
    RETRY_LATER = "retry_later"
    CHECK_DOCUMENTATION = "check_documentation"
    REPORT_ISSUE = "report_issue"
    
    # 具体建议
    VERIFY_URL = "verify_url"
    CHECK_API_KEY = "check_api_key"
    CHECK_FIREWALL = "check_firewall"
    CHECK_DISK_SPACE = "check_disk_space"
    UPDATE_CONFIG = "update_config"


@dataclass
class ErrorContext:
    """错误上下文"""
    operation: str
    path: str = ""
    backend: str = ""
    details: Dict[str, Any] = field(default_factory=dict)
    timestamp: float = field(default_factory=time.time)


@dataclass
class SyncGateError(Exception):
    """SyncGate 错误基类"""
    error_type: ErrorType
    message: str
    suggestion: RecoverySuggestion = RecoverySuggestion.REPORT_ISSUE
    context: Optional[ErrorContext] = None
    original_error: Optional[Exception] = None
    
    def __str__(self):
        return self.message


class BackendError(SyncGateError):
    """后端错误"""
    def __init__(
        self,
        message: str,
        backend: str,
        suggestion: RecoverySuggestion = RecoverySuggestion.CHECK_CONNECTION,
        original_error: Optional[Exception] = None,
    ):
        super().__init__(
            error_type=ErrorType.BACKEND_ERROR,
            message=message,
            suggestion=suggestion,
            original_error=original_error,
        )
        self.backend = backend


class ConnectionError(SyncGateError):
    """连接错误"""
    def __init__(
        self,
        message: str,
        url: str,
        suggestion: RecoverySuggestion = RecoverySuggestion.CHECK_CONNECTION,
        original_error: Optional[Exception] = None,
    ):
        super().__init__(
            error_type=ErrorType.CONNECTION_FAILED,
            message=message,
            suggestion=suggestion,
            original_error=original_error,
        )
        self.url = url


class AuthenticationError(SyncGateError):
    """认证错误"""
    def __init__(
        self,
        message: str,
        backend: str,
        suggestion: RecoverySuggestion = RecoverySuggestion.CHECK_CREDENTIALS,
        original_error: Optional[Exception] = None,
    ):
        super().__init__(
            error_type=ErrorType.AUTH_FAILED,
            message=message,
            suggestion=suggestion,
            original_error=original_error,
        )
        self.backend = backend


class FileNotFoundError_(SyncGateError):
    """文件不存在错误"""
    def __init__(
        self,
        path: str,
        suggestion: RecoverySuggestion = RecoverySuggestion.VERIFY_URL,
        original_error: Optional[Exception] = None,
    ):
        super().__init__(
            error_type=ErrorType.FILE_NOT_FOUND,
            message=f"File not found: {path}",
            suggestion=suggestion,
            original_error=original_error,
        )
        self.path = path


def get_suggestion_message(suggestion: RecoverySuggestion) -> str:
    """获取建议消息"""
    messages = {
        RecoverySuggestion.CHECK_CONNECTION: "请检查网络连接是否正常",
        RecoverySuggestion.CHECK_CREDENTIALS: "请检查凭证配置是否正确",
        RecoverySuggestion.CHECK_PERMISSIONS: "请检查文件/目录权限",
        RecoverySuggestion.RETRY_LATER: "请稍后重试",
        RecoverySuggestion.CHECK_DOCUMENTATION: "请查阅文档了解更多信息",
        RecoverySuggestion.REPORT_ISSUE: "如果问题持续，请提交 Issue 报告",
        RecoverySuggestion.VERIFY_URL: "请验证 URL 是否正确",
        RecoverySuggestion.CHECK_API_KEY: "请检查 API Key 是否有效",
        RecoverySuggestion.CHECK_FIREWALL: "请检查防火墙设置",
        RecoverySuggestion.CHECK_DISK_SPACE: "请检查磁盘空间",
        RecoverySuggestion.UPDATE_CONFIG: "请更新配置文件",
    }
    return messages.get(suggestion, "请检查相关配置")


def format_error(error: SyncGateError) -> str:
    """格式化错误消息"""
    lines = [
        f"❌ 错误: {error.message}",
        f"💡 建议: {get_suggestion_message(error.suggestion)}",
    ]
    
    if error.context:
        if error.context.backend:
            lines.append(f"📦 后端: {error.context.backend}")
        if error.context.path:
            lines.append(f"📁 路径: {error.context.path}")
    
    if error.original_error:
        lines.append(f"🔍 原始错误: {type(error.original_error).__name__}")
    
    return "\n".join(lines)


def error_boundary(
    fallback: Any = None,
    reraise: bool = False,
    context: Optional[Dict] = None,
):
    """
    错误边界装饰器
    
    捕获错误，提供恢复建议
    """
    def decorator(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            try:
                return func(*args, **kwargs)
            except SyncGateError as e:
                if reraise:
                    raise
                print(format_error(e))
                return fallback
            except Exception as e:
                # 转换为 SyncGateError
                error = SyncGateError(
                    error_type=ErrorType.UNKNOWN,
                    message=f"未知错误: {str(e)}",
                    suggestion=RecoverySuggestion.REPORT_ISSUE,
                    original_error=e,
                )
                
                if context:
                    error.context = ErrorContext(
                        operation=context.get("operation", func.__name__),
                        **context,
                    )
                
                if reraise:
                    raise error
                
                print(format_error(error))
                return fallback
        
        return wrapper
    return decorator


class RetryManager:
    """重试管理器"""
    
    def __init__(
        self,
        max_attempts: int = 3,
        delay: float = 1.0,
        backoff: float = 2.0,
        max_delay: float = 60.0,
    ):
        self.max_attempts = max_attempts
        self.delay = delay
        self.backoff = backoff
        self.max_delay = max_delay
        self._attempts = 0
        self._last_error: Optional[Exception] = None
        self._succeeded = False
    
    def __enter__(self):
        self._attempts = 0
        self._last_error = None
        self._succeeded = False
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        if exc_type is not None:
            self._last_error = exc_val
            return False
        return True
    
    def execute(self, func, *args, **kwargs):
        """执行带重试的函数"""
        self._attempts = 0
        delay = self.delay
        
        while self._attempts < self.max_attempts:
            self._attempts += 1
            
            try:
                result = func(*args, **kwargs)
                self._succeeded = True
                return result
            except Exception as e:
                self._last_error = e
                
                if self._attempts >= self.max_attempts:
                    raise
                
                # 打印重试信息
                print(f"⚠️  第 {self._attempts} 次尝试失败: {str(e)}")
                print(f"⏳  {delay:.1f} 秒后重试...")
                
                time.sleep(delay)
                delay = min(delay * self.backoff, self.max_delay)
        
        self._succeeded = False
        raise self._last_error
    
    @property
    def attempts(self) -> int:
        return self._attempts
    
    @property
    def succeeded(self) -> bool:
        return self._succeeded


# 便捷函数
def with_retry(
    max_attempts: int = 3,
    delay: float = 1.0,
):
    """带重试的装饰器"""
    def decorator(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            manager = RetryManager(max_attempts, delay)
            return manager.execute(func, *args, **kwargs)
        return wrapper
    return decorator
