"""AI Module - 元数据管理和语义搜索"""

from pathlib import Path
from typing import Dict, List, Optional
import json
import sqlite3
from datetime import datetime
from abc import ABC, abstractmethod


class EmbeddingProvider(ABC):
    """嵌入提供者接口"""
    
    @abstractmethod
    def embed(self, text: str) -> List[float]:
        """将文本转换为向量"""
        pass


class SimpleEmbedding(EmbeddingProvider):
    """简单嵌入实现 (基于 TF-IDF 思想)"""
    
    def __init__(self):
        self.vocab: Dict[str, int] = {}
        self.vocab_size = 0
    
    def _tokenize(self, text: str) -> List[str]:
        """简单分词"""
        return [word.lower() for word in text.split() if len(word) > 2]
    
    def _build_vocab(self, texts: List[str]):
        """构建词汇表"""
        for text in texts:
            for word in self._tokenize(text):
                if word not in self.vocab:
                    self.vocab[word] = len(self.vocab)
        self.vocab_size = len(self.vocab)
    
    def embed(self, text: str) -> List[float]:
        """将文本转换为向量 (词袋模型)"""
        tokens = set(self._tokenize(text))
        vector = [0.0] * self.vocab_size
        
        for word in tokens:
            if word in self.vocab:
                vector[self.vocab[word]] = 1.0
        
        return vector


class AIModule:
    """AI 模块 - 元数据管理和语义搜索"""
    
    def __init__(self, vfs_root: str, embedding_provider: Optional[EmbeddingProvider] = None):
        self.vfs_root = Path(vfs_root)
        self.db_path = self.vfs_root / "ai_metadata.db"
        self.embedding = embedding_provider or SimpleEmbedding()
        self._init_db()
    
    def _init_db(self):
        """初始化数据库"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # 元数据表
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS metadata (
                virtual_path TEXT PRIMARY KEY,
                content_hash TEXT,
                size INTEGER,
                created_at TEXT,
                updated_at TEXT,
                metadata_json TEXT
            )
        """)
        
        # 向量索引表
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS embeddings (
                virtual_path TEXT PRIMARY KEY,
                embedding_blob TEXT
            )
        """)
        
        conn.commit()
        cursor.close()
        conn.close()
    
    def extract_metadata(self, virtual_path: str, content: bytes) -> Dict:
        """提取文件元数据"""
        content_hash = hash(content)
        size = len(content)
        now = datetime.now().isoformat()
        
        # 尝试解码文本
        text = None
        encoding = None
        for enc in ['utf-8', 'latin-1', 'gbk']:
            try:
                text = content.decode(enc)
                encoding = enc
                break
            except:
                continue
        
        metadata = {
            "size": size,
            "content_hash": str(content_hash),
            "encoding": encoding,
            "word_count": len(text.split()) if text else 0,
            "lines": len(text.split('\n')) if text else 0,
        }
        
        # 保存到数据库
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("""
            INSERT OR REPLACE INTO metadata 
            (virtual_path, content_hash, size, created_at, updated_at, metadata_json)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (
            virtual_path, str(content_hash), size, now, now, json.dumps(metadata)
        ))
        conn.commit()
        cursor.close()
        conn.close()
        
        return metadata
    
    def index_content(self, virtual_path: str, content: bytes):
        """索引文件内容"""
        # 提取元数据
        metadata = self.extract_metadata(virtual_path, content)
        
        # 转换为向量
        text = content.decode('utf-8', errors='ignore')[:10000]  # 限制长度
        vector = self.embedding.embed(text)
        
        # 保存向量
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("""
            INSERT OR REPLACE INTO embeddings (virtual_path, embedding_blob)
            VALUES (?, ?)
        """, (virtual_path, json.dumps(vector)))
        conn.commit()
        cursor.close()
        conn.close()
    
    def search(self, query: str, limit: int = 5) -> List[Dict]:
        """语义搜索"""
        # 查询向量
        query_vector = self.embedding.embed(query)
        
        # 获取所有向量
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT virtual_path, embedding_blob FROM embeddings")
        rows = cursor.fetchall()
        conn.close()
        
        # 计算相似度
        results = []
        for virtual_path, blob in rows:
            doc_vector = json.loads(blob)
            similarity = self._cosine_similarity(query_vector, doc_vector)
            results.append({
                "path": virtual_path,
                "similarity": similarity
            })
        
        # 排序并返回 top k
        results.sort(key=lambda x: x["similarity"], reverse=True)
        return results[:limit]
    
    def _cosine_similarity(self, v1: List[float], v2: List[float]) -> float:
        """计算余弦相似度"""
        if len(v1) != len(v2):
            return 0.0
        
        dot = sum(a * b for a, b in zip(v1, v2))
        norm1 = sum(a * a for a in v1) ** 0.5
        norm2 = sum(b * b for b in v2) ** 0.5
        
        if norm1 * norm2 == 0:
            return 0.0
        
        return dot / (norm1 * norm2)
    
    def get_metadata(self, virtual_path: str) -> Optional[Dict]:
        """获取文件元数据"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute(
            "SELECT metadata_json FROM metadata WHERE virtual_path = ?",
            (virtual_path,)
        )
        row = cursor.fetchone()
        conn.close()
        
        if row:
            return json.loads(row[0])
        return None
    
    def list_indexed(self) -> List[str]:
        """列出已索引的文件"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT virtual_path FROM embeddings")
        rows = cursor.fetchall()
        conn.close()
        
        return [r[0] for r in rows]
