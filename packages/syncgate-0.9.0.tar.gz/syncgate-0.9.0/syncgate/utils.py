"""Configuration management for SyncGate."""

import json
import os
from pathlib import Path
from typing import Any, Dict, Optional


class Config:
    """SyncGate configuration management."""

    def __init__(self, config_path: Optional[str] = None):
        if config_path is None:
            # Default to ~/.config/syncgate/config.json
            config_dir = Path.home() / ".config" / "syncgate"
            config_dir.mkdir(parents=True, exist_ok=True)
            self.config_path = config_dir / "config.json"
        else:
            self.config_path = Path(config_path)
        
        self._config = self._load()
    
    def _load(self) -> Dict[str, Any]:
        """Load configuration from file."""
        if self.config_path.exists():
            try:
                with open(self.config_path) as f:
                    return json.load(f)
            except json.JSONDecodeError:
                return {}
        return {}
    
    def _save(self):
        """Save configuration to file."""
        with open(self.config_path, 'w') as f:
            json.dump(self._config, f, indent=2)
    
    def get(self, key: str, default: Any = None) -> Any:
        """Get configuration value."""
        return self._config.get(key, default)
    
    def set(self, key: str, value: Any):
        """Set configuration value."""
        self._config[key] = self._save()
    
    def delete(self, key: str):
        """Delete configuration key."""
        if key in self._config:
            del self._config[key]
            self._save()
    
    def get_all(self) -> Dict[str, Any]:
        """Get all configuration."""
        return self._config.copy()
    
    def clear(self):
        """Clear all configuration."""
        self._config = {}
        self._save()
    
    @property
    def path(self) -> str:
        """Get config file path."""
        return str(self.config_path)


class ProgressBar:
    """Simple progress bar for CLI."""

    def __init__(self, total: int, width: int = 40, desc: str = ""):
        self.total = total
        self.width = width
        self.desc = desc
        self.current = 0
        self._last_percent = -1
    
    def update(self, n: int = 1):
        """Update progress."""
        self.current += n
        self.draw()
    
    def draw(self):
        """Draw progress bar."""
        if self.total == 0:
            return
        
        percent = min(100, int(self.current / self.total * 100))
        
        # Only redraw if percent changed (avoid flicker)
        if percent == self._last_percent:
            return
        self._last_percent = percent
        
        filled = int(self.width * self.current / self.total)
        bar = "█" * filled + "░" * (self.width - filled)
        
        print(f"\r{self.desc}: |{bar}| {percent}% ({self.current}/{self.total})", end="", flush=True)
    
    def finish(self):
        """Finish progress bar."""
        print()  # New line
    
    def __enter__(self):
        return self
    
    def __exit__(self, *args):
        self.finish()


class Logger:
    """Simple logger for SyncGate."""

    def __init__(self, name: str = "syncgate"):
        self.name = name
        self.levels = {
            "DEBUG": "🔧",
            "INFO": "ℹ️",
            "WARNING": "⚠️",
            "ERROR": "❌",
            "SUCCESS": "✅",
        }

    def log(self, level: str, message: str):
        """Log a message."""
        icon = self.levels.get(level, "📝")
        print(f"{icon} [{level}] {message}")

    def debug(self, message: str):
        self.log("DEBUG", message)

    def info(self, message: str):
        self.log("INFO", message)

    def warning(self, message: str):
        self.log("WARNING", message)

    def error(self, message: str):
        self.log("ERROR", message)

    def success(self, message: str):
        self.log("SUCCESS", message)
