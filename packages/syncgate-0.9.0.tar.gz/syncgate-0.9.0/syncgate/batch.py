"""Batch operations for SyncGate."""

import json
from typing import Dict, List, Optional
from pathlib import Path

from syncgate.vfs import VirtualFS
from syncgate.gateway import Gateway


class BatchOperations:
    """Batch operations for SyncGate."""

    def __init__(self, vfs_root: str = "virtual"):
        self.vfs_root = Path(vfs_root)
        self.vfs = VirtualFS(str(self.vfs_root))

    def batch_create(
        self,
        links: List[Dict],
        dry_run: bool = False
    ) -> Dict:
        """Batch create links.

        Args:
            links: List of {"virtual_path": "...", "target": "...", "backend": "..."}
            dry_run: If True, only show what would be done

        Returns:
            Dict with created, failed counts
        """
        results = {"created": 0, "failed": 0, "errors": []}

        for link in links:
            virtual_path = link.get("virtual_path")
            target = link.get("target")
            backend = link.get("backend", "local")

            if not virtual_path or not target:
                results["failed"] += 1
                results["errors"].append(f"Missing path or target: {link}")
                continue

            if dry_run:
                print(f"[DRY-RUN] Would create: {virtual_path} -> {target}")
                results["created"] += 1
                continue

            try:
                self.vfs.link(virtual_path, target, backend)
                results["created"] += 1
            except Exception as e:
                results["failed"] += 1
                results["errors"].append(f"{virtual_path}: {e}")

        return results

    def batch_delete(
        self,
        paths: List[str],
        dry_run: bool = False
    ) -> Dict:
        """Batch delete links.

        Args:
            paths: List of virtual paths to delete
            dry_run: If True, only show what would be done

        Returns:
            Dict with deleted, failed counts
        """
        results = {"deleted": 0, "failed": 0, "errors": []}

        for path in paths:
            if dry_run:
                print(f"[DRY-RUN] Would delete: {path}")
                results["deleted"] += 1
                continue

            try:
                if self.vfs.unlink(path):
                    results["deleted"] += 1
                else:
                    results["failed"] += 1
                    results["errors"].append(f"{path}: Not found")
            except Exception as e:
                results["failed"] += 1
                results["errors"].append(f"{path}: {e}")

        return results

    def batch_validate(
        self,
        paths: Optional[List[str]] = None,
        gateway: Optional[Gateway] = None
    ) -> Dict:
        """Batch validate links.

        Args:
            paths: List of paths to validate (None = all)
            gateway: Gateway instance

        Returns:
            Dict with valid, invalid counts
        """
        if paths is None:
            paths = self.vfs.list("/")

        results = {"valid": 0, "invalid": 0, "errors": []}

        for path in paths:
            try:
                if gateway:
                    is_valid = gateway.validate(path)
                else:
                    is_valid = True  # Assume valid if no gateway

                if is_valid:
                    results["valid"] += 1
                else:
                    results["invalid"] += 1
            except Exception as e:
                results["invalid"] += 1
                results["errors"].append(f"{path}: {e}")

        return results

    def export_links(self, output_file: str = "links.json"):
        """Export all links to JSON file."""
        links = []

        # Use VirtualFS index.tree to iterate
        for dir_path, names in self.vfs.index.tree.items():
            for name in names:
                link_path = str(self.vfs_root / dir_path / f"{name}.link")
                link_file = Path(link_path)
                if link_file.exists():
                    data = json.loads(link_file.read_text())
                    virtual_path = f"{dir_path}/{name}".lstrip("/")
                    links.append({
                        "virtual_path": virtual_path,
                        "target": data.get("target"),
                        "backend": data.get("backend")
                    })

        with open(output_file, 'w') as f:
            json.dump(links, f, indent=2)

        return {"exported": len(links), "file": output_file}

    def import_links(
        self,
        input_file: str,
        dry_run: bool = False,
        prefix: str = ""
    ) -> Dict:
        """Import links from JSON file.

        Args:
            input_file: JSON file to import
            dry_run: If True, only show what would be done
            prefix: Add prefix to virtual paths

        Returns:
            Dict with imported, skipped counts
        """
        with open(input_file) as f:
            links = json.load(f)

        results = {"imported": 0, "skipped": 0, "errors": []}

        for link in links:
            virtual_path = prefix + link.get("virtual_path", "")
            target = link.get("target")
            backend = link.get("backend", "local")

            if not target:
                results["skipped"] += 1
                continue

            if dry_run:
                print(f"[DRY-RUN] Would import: {virtual_path}")
                results["imported"] += 1
                continue

            try:
                self.vfs.link(virtual_path, target, backend)
                results["imported"] += 1
            except Exception as e:
                results["skipped"] += 1
                results["errors"].append(f"{virtual_path}: {e}")

        return results
