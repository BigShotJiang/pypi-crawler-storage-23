"""Webhook notification support for SyncGate."""

import json
import requests
from typing import Dict, List, Optional
from datetime import datetime


class Webhook:
    """Webhook notification handler."""

    def __init__(self, url: str, events: List[str] = None):
        self.url = url
        self.events = events or ["all"]
        self.headers = {
            "Content-Type": "application/json",
            "User-Agent": "SyncGate-Webhook/1.0",
        }

    def send(self, event: str, data: Dict) -> bool:
        """Send webhook notification."""
        if "all" not in self.events and event not in self.events:
            return False

        payload = {
            "event": event,
            "timestamp": datetime.now().isoformat(),
            "data": data,
        }

        try:
            response = requests.post(
                self.url,
                json=payload,
                headers=self.headers,
                timeout=10,
            )
            return response.status_code in (200, 201)
        except Exception:
            return False


class WebhookManager:
    """Manage multiple webhooks."""

    def __init__(self):
        self.webhooks: List[Webhook] = []
        self.config_path = "webhooks.json"

    def add(self, url: str, events: List[str] = None) -> bool:
        """Add a webhook."""
        if not self._validate_url(url):
            return False

        webhook = Webhook(url, events)
        self.webhooks.append(webhook)
        self._save()
        return True

    def remove(self, url: str) -> bool:
        """Remove a webhook."""
        for i, wh in enumerate(self.webhooks):
            if wh.url == url:
                self.webhooks.pop(i)
                self._save()
                return True
        return False

    def list(self) -> List[Dict]:
        """List all webhooks."""
        return [{"url": wh.url, "events": wh.events} for wh in self.webhooks]

    def notify(self, event: str, data: Dict) -> Dict:
        """Send notification to all webhooks."""
        results = {}
        for wh in self.webhooks:
            success = wh.send(event, data)
            results[wh.url] = success
        return results

    def _validate_url(self, url: str) -> bool:
        """Validate webhook URL."""
        return url.startswith("http://") or url.startswith("https://")

    def _save(self):
        """Save webhooks to config."""
        data = [{"url": wh.url, "events": wh.events} for wh in self.webhooks]
        with open(self.config_path, 'w') as f:
            json.dump(data, f, indent=2)

    def load(self):
        """Load webhooks from config."""
        try:
            with open(self.config_path) as f:
                data = json.load(f)
                for item in data:
                    self.webhooks.append(Webhook(item["url"], item.get("events")))
        except FileNotFoundError:
            pass
