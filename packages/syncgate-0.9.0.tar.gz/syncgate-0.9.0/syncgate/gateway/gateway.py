"""Gateway - Frontend layer for SyncGate."""

from typing import Dict, List, Optional


class Gateway:
    """Frontend layer providing CLI and status display."""

    def __init__(self, vfs, backend):
        self.vfs = vfs
        self.backend = backend

    def ls(self, virtual_path: str) -> str:
        """List directory with link status."""
        entries = self.vfs.list(virtual_path)

        if not entries:
            return f"(empty directory: {virtual_path})"

        lines = []
        for name in sorted(entries):
            full_path = f"{virtual_path}/{name}".replace("//", "/")
            status = self.get_link_status(full_path)

            if status["valid"]:
                lines.append(f"  ✅ {name}")
            else:
                error = status.get("error", "unknown error")
                lines.append(f"  ⚠️  {name} ({error})")

        return "\n".join(lines)

    def get_link_status(self, virtual_path: str) -> Dict:
        """Get link status for a virtual path."""
        link = self.vfs.resolve(virtual_path)
        if not link:
            return {"valid": False, "error": "path not found"}

        return self.backend.get_status(virtual_path)

    def validate(self, virtual_path: str) -> bool:
        """Validate a single link."""
        link = self.vfs.resolve(virtual_path)
        if not link:
            return False

        return self.backend.validate(virtual_path, link)

    def validate_dir(self, virtual_path: str) -> Dict[str, bool]:
        """Validate all links in a directory."""
        entries = self.vfs.list(virtual_path)
        results = {}

        for name in entries:
            full_path = f"{virtual_path}/{name}".replace("//", "/")
            results[name] = self.validate(full_path)

        return results

    def tree(self, virtual_path: str, prefix: str = "", max_depth: int = 3, current_depth: int = 0) -> str:
        """Display tree structure with status."""
        if current_depth >= max_depth:
            return ""

        entries = self.vfs.list(virtual_path)
        if not entries:
            return ""

        lines = []
        for i, name in enumerate(sorted(entries)):
            is_last = i == len(entries) - 1
            connector = "└── " if is_last else "├── "
            full_path = f"{virtual_path}/{name}".replace("//", "/")
            status = self.get_link_status(full_path)

            status_icon = "✅" if status["valid"] else "⚠️"
            lines.append(f"{prefix}{connector}{status_icon} {name}")

            # Recurse into subdirectories
            if self.vfs.exists(full_path):
                new_prefix = prefix + ("    " if is_last else "│   ")
                lines.append(self.tree(full_path, new_prefix, max_depth, current_depth + 1))

        return "\n".join(lines)
