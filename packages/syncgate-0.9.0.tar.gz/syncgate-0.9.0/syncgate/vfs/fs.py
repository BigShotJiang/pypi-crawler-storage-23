"""修复版 VirtualFS - 路径格式统一"""

from pathlib import Path
from typing import Dict, List, Optional
import json


class VirtualFSIndex:
    """In-memory index for VirtualFS."""

    def __init__(self, root: Path):
        self.root = root
        self.tree: Dict[str, List[str]] = {}  # path -> [names]

    def build(self) -> None:
        """Build index from existing .link files."""
        self.tree.clear()
        for link_path in self.root.rglob("*.link"):
            rel_path = link_path.relative_to(self.root)
            parent = rel_path.parent
            
            # 统一路径格式：空字符串代表根目录
            if str(parent) == ".":
                dir_path = ""
            else:
                dir_path = str(parent)
            
            name = link_path.stem
            self.add(dir_path, name)

    def add(self, dir_path: str, name: str) -> None:
        """Add entry to index."""
        if dir_path not in self.tree:
            self.tree[dir_path] = []
        if name not in self.tree[dir_path]:
            self.tree[dir_path].append(name)

    def remove(self, dir_path: str, name: str) -> None:
        """Remove entry from index."""
        if dir_path in self.tree and name in self.tree[dir_path]:
            self.tree[dir_path].remove(name)
            if not self.tree[dir_path]:
                del self.tree[dir_path]

    def list(self, path: str) -> List[str]:
        """List directory contents."""
        return self.tree.get(path, [])

    def exists(self, path: str) -> bool:
        """Check if path exists in index."""
        return path in self.tree


class VirtualFS:
    """Virtual filesystem managing .link files."""

    def __init__(self, root: str):
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)
        self.index = VirtualFSIndex(self.root)
        self.index.build()

    def link(self, virtual_path: str, target: str, backend: str) -> None:
        """Create a link file."""
        link_path = self._to_link_path(virtual_path)
        link_path.parent.mkdir(parents=True, exist_ok=True)

        data = {"target": target, "backend": backend}
        link_path.write_text(json.dumps(data, indent=2))

        # Update index
        dir_path = str(link_path.parent.relative_to(self.root))
        # 统一为空字符串
        if dir_path == ".":
            dir_path = ""
        self.index.add(dir_path, link_path.stem)

    def resolve(self, virtual_path: str) -> Optional[Dict]:
        """Resolve virtual path to link data."""
        link_path = self._to_link_path(virtual_path)
        if not link_path.exists():
            return None

        data = json.loads(link_path.read_text())
        return {
            "backend": data["backend"],
            "target": data["target"],
            "link_path": str(link_path),
        }

    def unlink(self, virtual_path: str) -> bool:
        """Remove a link file."""
        link_path = self._to_link_path(virtual_path)
        if not link_path.exists():
            return False

        # Update index first
        dir_path = str(link_path.parent.relative_to(self.root))
        if dir_path == ".":
            dir_path = ""
        self.index.remove(dir_path, link_path.stem)

        # Remove file
        link_path.unlink()
        return True

    def list(self, virtual_path: str) -> List[str]:
        """List directory contents (files and subdirectories)."""
        path = self._normalize_path(virtual_path)
        entries = set(self.index.list(path))

        # Check for subdirectories
        prefix = path + "/" if path else ""
        for idx_path in self.index.tree.keys():
            if idx_path.startswith(prefix):
                subdir = idx_path[len(prefix):].split("/")[0]
                entries.add(subdir)

        return sorted(entries)

    def exists(self, virtual_path: str) -> bool:
        """Check if virtual path exists (file or directory)."""
        path = self._normalize_path(virtual_path)

        # Check if it's a link file
        link_path = self.root / f"{path}.link"
        if link_path.exists():
            return True

        # Check if it's a directory
        if path in self.index.tree and self.index.tree[path]:
            return True

        # Check for subdirectories
        prefix = path + "/" if path else ""
        for idx_path in self.index.tree.keys():
            if idx_path.startswith(prefix):
                return True

        return False

    def _to_link_path(self, virtual_path: str) -> Path:
        """Convert virtual path to .link file path."""
        path = self._normalize_path(virtual_path)
        return self.root / f"{path}.link"

    def _normalize_path(self, path: str) -> str:
        """Normalize path (remove leading/trailing slashes)."""
        return path.strip("/")

    def rebuild_index(self) -> None:
        """Rebuild the entire index."""
        self.index.build()
