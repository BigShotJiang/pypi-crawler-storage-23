"""VFS - Virtual filesystem layer."""

from .fs import VirtualFS, VirtualFSIndex

__all__ = ["VirtualFS", "VirtualFSIndex"]
