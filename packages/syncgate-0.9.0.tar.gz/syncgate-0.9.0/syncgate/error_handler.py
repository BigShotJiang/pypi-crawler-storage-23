"""Error handling and retry utilities."""

import time
import logging
from functools import wraps
from typing import Callable, TypeVar, Optional
from pathlib import Path
from datetime import datetime

T = TypeVar('T')


class RetryConfig:
    """Retry configuration."""

    def __init__(
        self,
        max_retries: int = 3,
        delay: float = 1.0,
        backoff: float = 2.0,
        max_delay: float = 60.0,
        retry_exceptions: tuple = (Exception,),
    ):
        self.max_retries = max_retries
        self.delay = delay
        self.backoff = backoff
        self.max_delay = max_delay
        self.retry_exceptions = retry_exceptions


class CircuitBreaker:
    """Circuit breaker for preventing cascading failures."""

    def __init__(
        self,
        name: str,
        failure_threshold: int = 5,
        recovery_timeout: int = 60,
    ):
        self.name = name
        self.failure_threshold = failure_threshold
        self.recovery_timeout = recovery_timeout

        self._failures = 0
        self._last_failure = None
        self._state = "closed"  # closed, open, half-open

    @property
    def state(self) -> str:
        """Get current state."""
        if self._state == "open":
            if self._last_failure and (time.time() - self._last_failure) > self.recovery_timeout:
                self._state = "half-open"
        return self._state

    def record_success(self):
        """Record a successful operation."""
        self._failures = 0
        self._state = "closed"

    def record_failure(self):
        """Record a failed operation."""
        self._failures += 1
        self._last_failure = time.time()

        if self._failures >= self.failure_threshold:
            self._state = "open"

    def record_error(self):
        """Record an error."""
        self.record_failure()


def retry(config: Optional[RetryConfig] = None):
    """Decorator for retrying failed operations.

    Args:
        config: Retry configuration (default: 3 retries, exponential backoff)

    Example:
        @retry()
        def fragile_operation():
            ...
    """
    if config is None:
        config = RetryConfig()

    def decorator(func: Callable[..., T]) -> Callable[..., T]:
        @wraps(func)
        def wrapper(*args, **kwargs) -> T:
            last_exception = None

            for attempt in range(config.max_retries + 1):
                try:
                    return func(*args, **kwargs)
                except config.retry_exceptions as e:
                    last_exception = e

                    if attempt < config.max_retries:
                        delay = min(
                            config.delay * (config.backoff ** attempt),
                            config.max_delay
                        )
                        logging.warning(
                            f"Retry {attempt + 1}/{config.max_retries} after {delay:.1f}s: {e}"
                        )
                        time.sleep(delay)
                    else:
                        logging.error(f"All retries failed: {e}")
                        raise

            raise last_exception

        return wrapper

    return decorator


class ErrorHandler:
    """Centralized error handling for SyncGate."""

    def __init__(self, log_file: str = "errors.log"):
        self.log_file = Path(log_file)
        self.errors = []
        self.max_errors = 100

    def log_error(
        self,
        operation: str,
        error: str,
        path: str = None,
        recoverable: bool = True,
    ):
        """Log an error."""
        error_entry = {
            "timestamp": datetime.now().isoformat(),
            "operation": operation,
            "error": str(error),
            "path": path,
            "recoverable": recoverable,
        }

        self.errors.append(error_entry)

        # Keep only last N errors
        if len(self.errors) > self.max_errors:
            self.errors = self.errors[-self.max_errors:]

        # Also log to file
        with open(self.log_file, 'a') as f:
            f.write(json.dumps(error_entry) + "\n")

    def get_recent_errors(self, count: int = 10) -> List[Dict]:
        """Get recent errors."""
        return self.errors[-count:]

    def get_error_count(self, since: datetime = None) -> int:
        """Get error count since given time."""
        if since is None:
            return len(self.errors)

        count = 0
        for error in self.errors:
            error_time = datetime.fromisoformat(error["timestamp"])
            if error_time > since:
                count += 1

        return count

    def get_error_rate(self, total_operations: int) -> float:
        """Calculate error rate (0-1)."""
        if total_operations == 0:
            return 0.0
        return len(self.errors) / total_operations

    def clear_errors(self):
        """Clear all logged errors."""
        self.errors = []
        if self.log_file.exists():
            self.log_file.unlink()


class FallbackHandler:
    """Fallback handlers for graceful degradation."""

    def __init__(self):
        self._fallbacks = {}

    def register(self, primary: str, fallback: Callable, condition: Callable = None):
        """Register a fallback for a primary function.

        Args:
            primary: Name of primary function
            fallback: Fallback function to call
            condition: When to use fallback (default: always)
        """
        self._fallbacks[primary] = {
            "fallback": fallback,
            "condition": condition or (lambda *args, **kwargs: True),
        }

    def call(self, primary: str, primary_func: Callable, *args, **kwargs):
        """Call primary function with fallback support."""
        if primary not in self._fallbacks:
            return primary_func(*args, **kwargs)

        fb = self._fallbacks[primary]
        fallback_func = fb["fallback"]

        try:
            return primary_func(*args, **kwargs)
        except Exception as e:
            if fb["condition"](e, *args, **kwargs):
                logging.warning(f"Using fallback for {primary}: {e}")
                return fallback_func(*args, **kwargs)
            raise
