"""SyncGate - Lightweight multi-storage routing and sync abstraction layer."""

__version__ = "0.1.0"
