"""
配置管理模块

支持从 YAML/JSON 配置文件加载后端凭证。
"""

from pathlib import Path
from typing import Dict, Any, Optional
from dataclasses import dataclass, field
import json
import os

# 尝试导入 yaml，如果不存在则使用纯 Python 实现
try:
    import yaml
    HAS_YAML = True
except ImportError:
    HAS_YAML = False
    # 简单的 YAML 解析器（仅支持基本语法）
    def safe_load(stream):
        """简单的 YAML 解析"""
        import re
        result = {}
        for line in stream:
            line = line.strip()
            if not line or line.startswith('#'):
                continue
            if ':' in line:
                key, value = line.split(':', 1)
                key = key.strip()
                value = value.strip()
                if value:
                    # 尝试转换为数字
                    if value.isdigit():
                        value = int(value)
                    elif value in ('true', 'True', 'yes'):
                        value = True
                    elif value in ('false', 'False', 'no'):
                        value = False
                    elif value.startswith('"') and value.endswith('"'):
                        value = value[1:-1]
                result[key] = value
        return result
    
    yaml = type('YAML', (), {'safe_load': safe_load})()


@dataclass
class BackendConfig:
    """后端配置基类"""
    enabled: bool = True


@dataclass
class LocalConfig(BackendConfig):
    """本地后端配置"""
    pass


@dataclass
class HTTPConfig(BackendConfig):
    """HTTP 后端配置"""
    timeout: int = 30
    verify_ssl: bool = True
    headers: Dict[str, str] = field(default_factory=dict)


@dataclass
class S3Config(BackendConfig):
    """S3 后端配置"""
    aws_access_key_id: str = ""
    aws_secret_access_key: str = ""
    region: str = "us-east-1"
    endpoint_url: str = ""
    bucket: str = ""


@dataclass
class WebDAVConfig(BackendConfig):
    """WebDAV 后端配置"""
    url: str = ""
    username: str = ""
    password: str = ""
    verify_ssl: bool = True


@dataclass
class FTPConfig(BackendConfig):
    """FTP 后端配置"""
    host: str = ""
    port: int = 21
    username: str = ""
    password: str = ""
    use_tls: bool = False


@dataclass
class SFTPConfig(BackendConfig):
    """SFTP 后端配置"""
    host: str = ""
    port: int = 22
    username: str = ""
    password: str = ""
    key_filename: str = ""


@dataclass
class SyncGateConfig:
    """SyncGate 主配置"""
    vfs_root: str = "virtual"
    
    # 后端配置
    local: LocalConfig = field(default_factory=LocalConfig)
    http: HTTPConfig = field(default_factory=HTTPConfig)
    s3: S3Config = field(default_factory=S3Config)
    webdav: WebDAVConfig = field(default_factory=WebDAVConfig)
    ftp: FTPConfig = field(default_factory=FTPConfig)
    sftp: SFTPConfig = field(default_factory=SFTPConfig)
    
    # 全局配置
    cache_ttl: int = 300  # 缓存过期时间（秒）
    log_level: str = "INFO"
    retry_attempts: int = 3
    retry_delay: float = 1.0


class ConfigManager:
    """配置管理器"""
    
    def __init__(self, config_path: str = None):
        self.config_path = config_path or self._find_config_file()
        self.config = SyncGateConfig()
        
        if self.config_path and Path(self.config_path).exists():
            self.load(self.config_path)
    
    def _find_config_file(self) -> str:
        """查找配置文件"""
        possible_paths = [
            "config.yaml",
            "config.yml",
            "syncgate.yaml",
            "syncgate.yml",
            "syncgate.json",
        ]
        
        for path in possible_paths:
            if Path(path).exists():
                return path
        
        return ""
    
    def load(self, path: str = None) -> SyncGateConfig:
        """从文件加载配置"""
        path = path or self.config_path
        if not path:
            return self.config
        
        config_file = Path(path)
        
        if config_file.suffix in [".yaml", ".yml"]:
            self._load_yaml(config_file)
        elif config_file.suffix == ".json":
            self._load_json(config_file)
        else:
            # 尝试自动检测
            try:
                self._load_yaml(config_file)
            except Exception:
                try:
                    self._load_json(config_file)
                except Exception:
                    pass
        
        return self.config
    
    def _load_yaml(self, path: Path):
        """加载 YAML 配置"""
        with open(path) as f:
            data = yaml.safe_load(f) or {}
        self._apply_config(data)
    
    def _load_json(self, path: Path):
        """加载 JSON 配置"""
        with open(path) as f:
            data = json.load(f)
        self._apply_config(data)
    
    def _apply_config(self, data: Dict[str, Any]):
        """应用配置到 config 对象"""
        # 主配置
        if "vfs_root" in data:
            self.config.vfs_root = data["vfs_root"]
        if "cache_ttl" in data:
            self.config.cache_ttl = data["cache_ttl"]
        if "log_level" in data:
            self.config.log_level = data["log_level"]
        if "retry_attempts" in data:
            self.config.retry_attempts = data["retry_attempts"]
        if "retry_delay" in data:
            self.config.retry_delay = data["retry_delay"]
        
        # 后端配置
        backend_map = {
            "local": self.config.local,
            "http": self.config.http,
            "s3": self.config.s3,
            "webdav": self.config.webdav,
            "ftp": self.config.ftp,
            "sftp": self.config.sftp,
        }
        
        if "backend" in data:
            for name, backend_data in data["backend"].items():
                if name in backend_map:
                    self._apply_backend_config(backend_map[name], backend_data)
    
    def _apply_backend_config(self, config: BackendConfig, data: Dict[str, Any]):
        """应用后端配置"""
        if "enabled" in data:
            config.enabled = data["enabled"]
        
        # S3 配置
        if isinstance(config, S3Config):
            if "aws_access_key_id" in data:
                config.aws_access_key_id = data["aws_access_key_id"]
            if "aws_secret_access_key" in data:
                config.aws_secret_access_key = data["aws_secret_access_key"]
            if "region" in data:
                config.region = data["region"]
            if "endpoint_url" in data:
                config.endpoint_url = data["endpoint_url"]
            if "bucket" in data:
                config.bucket = data["bucket"]
        
        # WebDAV 配置
        if isinstance(config, WebDAVConfig):
            if "url" in data:
                config.url = data["url"]
            if "username" in data:
                config.username = data["username"]
            if "password" in data:
                config.password = data["password"]
            if "verify_ssl" in data:
                config.verify_ssl = data["verify_ssl"]
        
        # FTP 配置
        if isinstance(config, FTPConfig):
            if "host" in data:
                config.host = data["host"]
            if "port" in data:
                config.port = data["port"]
            if "username" in data:
                config.username = data["username"]
            if "password" in data:
                config.password = data["password"]
            if "use_tls" in data:
                config.use_tls = data["use_tls"]
        
        # SFTP 配置
        if isinstance(config, SFTPConfig):
            if "host" in data:
                config.host = data["host"]
            if "port" in data:
                config.port = data["port"]
            if "username" in data:
                config.username = data["username"]
            if "password" in data:
                config.password = data["password"]
            if "key_filename" in data:
                config.key_filename = data["key_filename"]
        
        # HTTP 配置
        if isinstance(config, HTTPConfig):
            if "timeout" in data:
                config.timeout = data["timeout"]
            if "verify_ssl" in data:
                config.verify_ssl = data["verify_ssl"]
            if "headers" in data:
                config.headers = data["headers"]
    
    def save(self, path: str = None) -> str:
        """保存配置到文件"""
        path = path or self.config_path or "config.yaml"
        data = self._to_dict()
        
        if path.endswith(".json"):
            with open(path, "w") as f:
                json.dump(data, f, indent=2)
        else:
            with open(path, "w") as f:
                yaml.dump(data, f, default_flow_style=False)
        
        return path
    
    def _to_dict(self) -> Dict[str, Any]:
        """转换为字典"""
        return {
            "vfs_root": self.config.vfs_root,
            "cache_ttl": self.config.cache_ttl,
            "log_level": self.config.log_level,
            "retry_attempts": self.config.retry_attempts,
            "retry_delay": self.config.retry_delay,
            "backend": {
                "local": {"enabled": self.config.local.enabled},
                "http": {
                    "enabled": self.config.http.enabled,
                    "timeout": self.config.http.timeout,
                    "verify_ssl": self.config.http.verify_ssl,
                    "headers": self.config.http.headers,
                },
                "s3": {
                    "enabled": self.config.s3.enabled,
                    "aws_access_key_id": self.config.s3.aws_access_key_id,
                    "aws_secret_access_key": self.config.s3.aws_secret_access_key,
                    "region": self.config.s3.region,
                    "endpoint_url": self.config.s3.endpoint_url,
                    "bucket": self.config.s3.bucket,
                },
                "webdav": {
                    "enabled": self.config.webdav.enabled,
                    "url": self.config.webdav.url,
                    "username": self.config.webdav.username,
                    "password": self.config.webdav.password,
                    "verify_ssl": self.config.webdav.verify_ssl,
                },
                "ftp": {
                    "enabled": self.config.ftp.enabled,
                    "host": self.config.ftp.host,
                    "port": self.config.ftp.port,
                    "username": self.config.ftp.username,
                    "password": self.config.ftp.password,
                    "use_tls": self.config.ftp.use_tls,
                },
                "sftp": {
                    "enabled": self.config.sftp.enabled,
                    "host": self.config.sftp.host,
                    "port": self.config.sftp.port,
                    "username": self.config.sftp.username,
                    "password": self.config.sftp.password,
                    "key_filename": self.config.sftp.key_filename,
                },
            }
        }
    
    def get_backend_config(self, backend_name: str) -> BackendConfig:
        """获取后端配置"""
        config_map = {
            "local": self.config.local,
            "http": self.config.http,
            "s3": self.config.s3,
            "webdav": self.config.webdav,
            "ftp": self.config.ftp,
            "sftp": self.config.sftp,
        }
        
        return config_map.get(backend_name, BackendConfig())
    
    def is_backend_enabled(self, backend_name: str) -> bool:
        """检查后端是否启用"""
        config = self.get_backend_config(backend_name)
        return config.enabled


def load_config(path: str = None) -> SyncGateConfig:
    """加载配置"""
    manager = ConfigManager(path)
    return manager.config


def save_config(config: SyncGateConfig, path: str = None) -> str:
    """保存配置"""
    manager = ConfigManager()
    manager.config = config
    return manager.save(path)
