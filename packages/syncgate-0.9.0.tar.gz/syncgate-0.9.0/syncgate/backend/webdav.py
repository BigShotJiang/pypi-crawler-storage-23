"""WebDAV backend implementation."""

from typing import Dict, List, Optional
import requests
from urllib.parse import urlparse
import xml.etree.ElementTree as ET

from .protocol import Backend
from .base import BaseBackend


class WebDAVBackend(BaseBackend, Backend):
    """WebDAV backend implementation."""

    def __init__(
        self,
        vfs_root: str,
        db_path: str,
        timeout: int = 30,
        verify_ssl: bool = True,
    ):
        self.vfs_root = vfs_root
        self.timeout = timeout
        self.verify_ssl = verify_ssl
        super().__init__(db_path)

    def _parse_url(self, url: str) -> tuple:
        """Parse webdav://server/path into (server, path)."""
        parsed = urlparse(url)
        # webdav://server/path -> (server, path)
        server = parsed.netloc
        path = parsed.path or "/"
        return server, path

    def _make_request(
        self,
        method: str,
        url: str,
        auth: Optional[tuple] = None,
        **kwargs,
    ) -> requests.Response:
        """Make HTTP request with WebDAV headers."""
        headers = kwargs.pop("headers", {})
        headers["Depth"] = headers.get("Depth", "0")
        
        response = requests.request(
            method,
            url,
            auth=auth,
            timeout=self.timeout,
            verify=self.verify_ssl,
            headers=headers,
            **kwargs,
        )
        return response

    def list(self, path: str) -> List[str]:
        """List directory contents (PROPFIND)."""
        server, dav_path = self._parse_url(path)
        url = f"https://{server}{dav_path}"
        
        # WebDAV PROPFIND request
        propfind_body = """<?xml version="1.0" encoding="UTF-8"?>
        <D:propfind xmlns:D="DAV:">
            <D:prop>
                <D:displayname/>
            </D:prop>
        </D:propfind>"""
        
        try:
            response = self._make_request(
                "PROPFIND",
                url,
                headers={"Depth": "1"},
                data=propfind_body,
            )
            
            if response.status_code not in (207, 200):
                return []
            
            # Parse response
            entries = []
            try:
                root = ET.fromstring(response.content)
                for response_elem in root.findall(".//{DAV:}response"):
                    href = response_elem.findtext("{DAV:}href")
                    if href and href != dav_path:
                        name = href.split("/")[-1]
                        if name:
                            entries.append(name)
            except ET.ParseError:
                pass
            
            return entries
            
        except requests.RequestException:
            return []

    def get(self, path: str) -> bytes:
        """Get file content."""
        server, dav_path = self._parse_url(path)
        url = f"https://{server}{dav_path}"
        
        try:
            response = requests.get(url, timeout=self.timeout, verify=self.verify_ssl)
            response.raise_for_status()
            return response.content
        except requests.RequestException as e:
            raise FileNotFoundError(f"Failed to fetch {path}: {e}")

    def put(self, path: str, content: bytes) -> None:
        """Put file content (PUT)."""
        server, dav_path = self._parse_url(path)
        url = f"https://{server}{dav_path}"
        
        try:
            response = requests.put(
                url,
                data=content,
                timeout=self.timeout,
                verify=self.verify_ssl,
            )
            response.raise_for_status()
        except requests.RequestException as e:
            raise IOError(f"Failed to put {path}: {e}")

    def exists(self, path: str) -> bool:
        """Check if URL exists (HEAD request)."""
        server, dav_path = self._parse_url(path)
        url = f"https://{server}{dav_path}"
        
        try:
            response = requests.head(url, timeout=self.timeout, verify=self.verify_ssl)
            return response.status_code == 200
        except requests.RequestException:
            return False

    def mkdir(self, path: str) -> None:
        """Create directory (MKCOL)."""
        server, dav_path = self._parse_url(path)
        url = f"https://{server}{dav_path}"
        
        try:
            response = requests.request(
                "MKCOL",
                url,
                timeout=self.timeout,
                verify=self.verify_ssl,
            )
            response.raise_for_status()
        except requests.RequestException as e:
            raise IOError(f"Failed to create directory {path}: {e}")

    def validate(self, virtual_path: str, link_data: Dict) -> bool:
        """Validate if WebDAV URL is accessible."""
        target = link_data.get("target", "")
        
        if not target.startswith("webdav://"):
            self._update_status(virtual_path, False, "Invalid WebDAV URL")
            return False

        try:
            server, dav_path = self._parse_url(target)
            url = f"https://{server}{dav_path}"
            
            response = requests.head(url, timeout=self.timeout, verify=self.verify_ssl)
            is_valid = response.status_code == 200
            
            error = None if is_valid else f"HTTP {response.status_code}"
            self._update_status(virtual_path, is_valid, error)
            return is_valid
            
        except requests.Timeout:
            self._update_status(virtual_path, False, "Connection timeout")
            return False
        except requests.RequestException as e:
            self._update_status(virtual_path, False, str(e))
            return False
