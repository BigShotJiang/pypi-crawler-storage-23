"""Local filesystem backend."""

from pathlib import Path
from typing import BinaryIO, Dict, List, Optional
import os

from .protocol import Backend
from .base import BaseBackend


class LocalBackend(BaseBackend, Backend):
    """Local filesystem backend implementation."""

    def __init__(self, vfs_root: str, local_root: str, db_path: str):
        self.vfs_root = Path(vfs_root)
        self.local_root = Path(local_root)
        self.local_root.mkdir(parents=True, exist_ok=True)
        super().__init__(db_path)

    def _get_target_path(self, target: str) -> Path:
        """Convert target URL to local path."""
        if target.startswith("local:/"):
            target = target[7:]
        return self.local_root / target

    def list(self, path: str) -> List[str]:
        """List directory contents."""
        target_path = self._get_target_path(path)
        if not target_path.exists():
            return []
        if target_path.is_file():
            return [target_path.name]
        return os.listdir(target_path)

    def get(self, path: str) -> bytes:
        """Get file content."""
        target_path = self._get_target_path(path)
        if not target_path.exists():
            raise FileNotFoundError(f"File not found: {path}")
        return target_path.read_bytes()

    def put(self, path: str, content: bytes) -> None:
        """Put file content."""
        target_path = self._get_target_path(path)
        target_path.parent.mkdir(parents=True, exist_ok=True)
        target_path.write_bytes(content)

    def exists(self, path: str) -> bool:
        """Check if path exists."""
        target_path = self._get_target_path(path)
        return target_path.exists()

    def mkdir(self, path: str) -> None:
        """Create directory."""
        target_path = self._get_target_path(path)
        target_path.mkdir(parents=True, exist_ok=True)

    def validate(self, virtual_path: str, link_data: Dict) -> bool:
        """Validate if link target is accessible."""
        target = link_data.get("target", "")
        backend = link_data.get("backend", "")

        if backend != "local":
            return False

        target_path = self._get_target_path(target)
        is_valid = target_path.exists()

        self._update_status(virtual_path, is_valid, None if is_valid else "File not found")
        return is_valid
