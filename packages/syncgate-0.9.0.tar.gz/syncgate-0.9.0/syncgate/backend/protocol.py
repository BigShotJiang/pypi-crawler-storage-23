"""Backend protocol definition."""

from abc import ABC, abstractmethod
from typing import BinaryIO, Dict, List, Optional


class Backend(ABC):
    """Abstract base class for storage backends."""

    @abstractmethod
    def list(self, path: str) -> List[str]:
        """List directory contents."""
        ...

    @abstractmethod
    def get(self, path: str) -> bytes:
        """Get file content."""
        ...

    @abstractmethod
    def put(self, path: str, content: bytes) -> None:
        """Put file content."""
        ...

    @abstractmethod
    def exists(self, path: str) -> bool:
        """Check if path exists."""
        ...

    @abstractmethod
    def mkdir(self, path: str) -> None:
        """Create directory."""
        ...

    @abstractmethod
    def validate(self, virtual_path: str, link_data: Dict) -> bool:
        """Validate if link target is accessible."""
        ...

    @abstractmethod
    def get_status(self, virtual_path: str) -> Dict:
        """Get link status from database."""
        ...
