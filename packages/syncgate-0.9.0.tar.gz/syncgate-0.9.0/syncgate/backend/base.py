"""Base backend class with common functionality."""

from abc import ABC
from pathlib import Path
from typing import Dict, Optional
import sqlite3
from datetime import datetime


class BaseBackend(ABC):
    """Base class with common database and status functionality."""
    
    def __init__(self, db_path: str):
        self.db_path = db_path
        self._init_db()
    
    def _init_db(self) -> None:
        """Initialize SQLite database for link status."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS link_status (
                virtual_path TEXT PRIMARY KEY,
                is_valid INTEGER DEFAULT 1,
                last_check TEXT,
                error_message TEXT,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
        """)
        conn.commit()
        cursor.close()
        conn.close()
    
    def get_status(self, virtual_path: str) -> Dict:
        """Get link status from database."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute(
            "SELECT is_valid, last_check, error_message FROM link_status WHERE virtual_path = ?",
            (virtual_path,),
        )
        row = cursor.fetchone()
        conn.close()
        
        if not row:
            return {"valid": True, "error": None}
        
        return {
            "valid": bool(row[0]),
            "last_check": row[1],
            "error": row[2],
        }
    
    def _update_status(
        self, virtual_path: str, is_valid: bool, error: Optional[str]
    ) -> None:
        """Update link status in database."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        now = datetime.now().isoformat()
        cursor.execute(
            """
            INSERT OR REPLACE INTO link_status
            (virtual_path, is_valid, last_check, error_message, updated_at)
            VALUES (?, ?, ?, ?, ?)
            """,
            (virtual_path, 1 if is_valid else 0, now, error, now),
        )
        conn.commit()
        cursor.close()
        conn.close()
