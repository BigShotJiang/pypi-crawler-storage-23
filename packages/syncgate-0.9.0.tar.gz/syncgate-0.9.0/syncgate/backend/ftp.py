"""FTP backend implementation."""

from typing import Dict, List, Optional
import ftplib
from urllib.parse import urlparse
import io

from .protocol import Backend
from .base import BaseBackend


class FTPBackend(BaseBackend, Backend):
    """FTP backend implementation."""

    def __init__(
        self,
        vfs_root: str,
        db_path: str,
        timeout: int = 30,
    ):
        self.vfs_root = vfs_root
        self.timeout = timeout
        super().__init__(db_path)

    def _parse_url(self, url: str) -> tuple:
        """Parse ftp://server/path into (server, path)."""
        parsed = urlparse(url)
        # ftp://server/path -> (server, path)
        server = parsed.netloc
        path = parsed.path or "/"
        return server, path

    def _connect(self, server: str) -> ftplib.FTP:
        """Create FTP connection."""
        ftp = ftplib.FTP()
        ftp.connect(server, timeout=self.timeout)
        ftp.login()  # Anonymous login
        return ftp

    def list(self, path: str) -> List[str]:
        """List directory contents."""
        server, ftp_path = self._parse_url(path)
        
        try:
            ftp = self._connect(server)
            ftp.cwd(ftp_path)
            entries = ftp.nlst()
            ftp.quit()
            return entries
        except ftplib.error_perm as e:
            return []
        except Exception as e:
            return []

    def get(self, path: str) -> bytes:
        """Get file content."""
        server, ftp_path = self._parse_url(path)
        
        try:
            ftp = self._connect(server)
            ftp.voidcmd('TYPE I')  # Binary mode
            data = []
            ftp.retrbinary(f"RETR {ftp_path}", data.append)
            ftp.quit()
            return b''.join(data)
        except ftplib.error_perm as e:
            raise FileNotFoundError(f"Failed to fetch {path}: {e}")

    def put(self, path: str, content: bytes) -> None:
        """Put file content."""
        server, ftp_path = self._parse_url(path)
        
        try:
            ftp = self._connect(server)
            ftp.storbinary(f"STOR {ftp_path}", io.BytesIO(content))
            ftp.quit()
        except ftplib.error_perm as e:
            raise IOError(f"Failed to put {path}: {e}")

    def exists(self, path: str) -> bool:
        """Check if path exists."""
        server, ftp_path = self._parse_url(path)
        
        try:
            ftp = self._connect(server)
            try:
                ftp.cwd(ftp_path)
                ftp.quit()
                return True
            except ftplib.error_perm:
                # Try as file
                ftp.voidcmd('TYPE I')
                ftp.size(ftp_path)
                ftp.quit()
                return True
        except Exception:
            return False

    def mkdir(self, path: str) -> None:
        """Create directory."""
        server, ftp_path = self._parse_url(path)
        
        try:
            ftp = self._connect(server)
            ftp.mkd(ftp_path)
            ftp.quit()
        except ftplib.error_perm as e:
            raise IOError(f"Failed to create directory {path}: {e}")

    def validate(self, virtual_path: str, link_data: Dict) -> bool:
        """Validate if FTP URL is accessible."""
        target = link_data.get("target", "")
        
        if not target.startswith("ftp://"):
            self._update_status(virtual_path, False, "Invalid FTP URL")
            return False

        try:
            server, ftp_path = self._parse_url(target)
            ftp = self._connect(server)
            
            # Try to access
            try:
                ftp.cwd(ftp_path)
                is_valid = True
            except ftplib.error_perm:
                # Try as file
                ftp.voidcmd('TYPE I')
                ftp.size(ftp_path)
                is_valid = True
            
            ftp.quit()
            self._update_status(virtual_path, is_valid, None if is_valid else "Access denied")
            return is_valid
            
        except Exception as e:
            self._update_status(virtual_path, False, str(e))
            return False
