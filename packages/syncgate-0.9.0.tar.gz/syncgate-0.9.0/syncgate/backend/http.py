"""HTTP/HTTPS backend implementation."""

from typing import Dict, List, Optional
import requests
from urllib.parse import urlparse

from .protocol import Backend
from .base import BaseBackend


class HTTPBackend(BaseBackend, Backend):
    """HTTP/HTTPS backend implementation."""

    def __init__(self, vfs_root: str, db_path: str, timeout: int = 10):
        self.vfs_root = vfs_root
        self.timeout = timeout
        super().__init__(db_path)

    def list(self, path: str) -> List[str]:
        """List directory contents (not supported for HTTP)."""
        raise NotImplementedError("Directory listing not supported for HTTP backend")

    def get(self, path: str) -> bytes:
        """Get file content from URL."""
        try:
            response = requests.get(path, timeout=self.timeout, stream=True)
            response.raise_for_status()
            return response.content
        except requests.RequestException as e:
            raise FileNotFoundError(f"Failed to fetch {path}: {e}")

    def put(self, path: str, content: bytes) -> None:
        """Put file content (not supported for HTTP read-only)."""
        raise NotImplementedError("Write not supported for HTTP backend")

    def exists(self, path: str) -> bool:
        """Check if URL exists."""
        try:
            response = requests.head(path, timeout=self.timeout)
            return response.status_code == 200
        except requests.RequestException:
            return False

    def mkdir(self, path: str) -> None:
        """Create directory (not supported for HTTP)."""
        raise NotImplementedError("Directory creation not supported for HTTP backend")

    def validate(self, virtual_path: str, link_data: Dict) -> bool:
        """Validate if HTTP URL is accessible."""
        target = link_data.get("target", "")

        if not target.startswith(("http://", "https://")):
            self._update_status(virtual_path, False, "Invalid HTTP URL")
            return False

        try:
            response = requests.head(target, timeout=self.timeout, allow_redirects=True)
            is_valid = response.status_code == 200
            error = None if is_valid else f"HTTP {response.status_code}"
            self._update_status(virtual_path, is_valid, error)
            return is_valid
        except requests.Timeout:
            self._update_status(virtual_path, False, "Connection timeout")
            return False
        except requests.RequestException as e:
            self._update_status(virtual_path, False, str(e))
            return False
