"""S3 backend implementation."""

from typing import BinaryIO, Dict, List, Optional
import boto3
from botocore.exceptions import ClientError
from urllib.parse import urlparse

from .protocol import Backend
from .base import BaseBackend


class S3Backend(BaseBackend, Backend):
    """AWS S3 backend implementation."""

    def __init__(
        self,
        vfs_root: str,
        db_path: str,
        aws_access_key_id: Optional[str] = None,
        aws_secret_access_key: Optional[str] = None,
        region_name: str = "us-east-1",
    ):
        self.vfs_root = vfs_root
        self.region_name = region_name

        # Initialize S3 client
        self.s3 = boto3.client(
            "s3",
            region_name=region_name,
            aws_access_key_id=aws_access_key_id,
            aws_secret_access_key=aws_secret_access_key,
        )

        super().__init__(db_path)

    def _parse_s3_url(self, url: str) -> tuple:
        """Parse s3://bucket/key into (bucket, key)."""
        parsed = urlparse(url)
        return parsed.netloc, parsed.path.lstrip("/")

    def list(self, path: str) -> List[str]:
        """List objects in S3 bucket/prefix."""
        bucket, prefix = self._parse_s3_url(path)
        if not prefix.endswith("/"):
            prefix += "/"

        try:
            response = self.s3.list_objects_v2(Bucket=bucket, Prefix=prefix, Delimiter="/")
            entries = []

            # Add subdirectories
            if "CommonPrefixes" in response:
                for obj in response["CommonPrefixes"]:
                    subdir = obj["Prefix"].rstrip("/").split("/")[-1]
                    entries.append(subdir + "/")

            # Add files
            if "Contents" in response:
                for obj in response["Contents"]:
                    key = obj["Key"]
                    if key != prefix:
                        filename = key.split("/")[-1]
                        entries.append(filename)

            return entries
        except ClientError as e:
            raise FileNotFoundError(f"Failed to list {path}: {e}")

    def get(self, path: str) -> bytes:
        """Get file content from S3."""
        bucket, key = self._parse_s3_url(path)

        try:
            response = self.s3.get_object(Bucket=bucket, Key=key)
            return response["Body"].read()
        except ClientError as e:
            raise FileNotFoundError(f"Failed to get {path}: {e}")

    def put(self, path: str, content: bytes) -> None:
        """Put file content to S3."""
        bucket, key = self._parse_s3_url(path)

        try:
            self.s3.put_object(Bucket=bucket, Key=key, Body=content)
        except ClientError as e:
            raise IOError(f"Failed to put {path}: {e}")

    def exists(self, path: str) -> bool:
        """Check if S3 object exists."""
        bucket, key = self._parse_s3_url(path)

        try:
            self.s3.head_object(Bucket=bucket, Key=key)
            return True
        except ClientError:
            return False

    def mkdir(self, path: str) -> None:
        """Create directory (S3 doesn't have directories)."""
        pass

    def validate(self, virtual_path: str, link_data: Dict) -> bool:
        """Validate if S3 object is accessible."""
        target = link_data.get("target", "")

        if not target.startswith("s3://"):
            self._update_status(virtual_path, False, "Invalid S3 URL")
            return False

        try:
            bucket, key = self._parse_s3_url(target)
            self.s3.head_object(Bucket=bucket, Key=key)
            self._update_status(virtual_path, True, None)
            return True
        except ClientError as e:
            error_code = e.response.get("Error", {}).get("Code", "Unknown")
            error_msg = f"S3 Error: {error_code}"
            self._update_status(virtual_path, False, error_msg)
            return False
