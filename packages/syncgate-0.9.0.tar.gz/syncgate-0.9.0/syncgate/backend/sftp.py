"""SFTP backend implementation."""

from typing import Dict, List, Optional
import paramiko
from urllib.parse import urlparse

from .protocol import Backend
from .base import BaseBackend


class SFTPBackend(BaseBackend, Backend):
    """SFTP backend implementation."""

    def __init__(
        self,
        vfs_root: str,
        db_path: str,
        timeout: int = 30,
        username: Optional[str] = None,
        password: Optional[str] = None,
        key_filename: Optional[str] = None,
    ):
        self.vfs_root = vfs_root
        self.timeout = timeout
        self.username = username
        self.password = password
        self.key_filename = key_filename
        super().__init__(db_path)

    def _parse_url(self, url: str) -> tuple:
        """Parse sftp://server/path into (server, path)."""
        parsed = urlparse(url)
        # sftp://server/path -> (server, path)
        server = parsed.netloc
        path = parsed.path or "/"
        return server, path

    def _connect(self, server: str):
        """Create SFTP connection."""
        transport = paramiko.Transport(server)
        transport.connect(
            username=self.username,
            password=self.password,
            key_filename=self.key_filename,
        )
        sftp = paramiko.SFTPClient.from_transport(transport)
        sftp.sock.settimeout(self.timeout)
        return sftp

    def list(self, path: str) -> List[str]:
        """List directory contents."""
        server, sftp_path = self._parse_url(path)
        
        try:
            sftp = self._connect(server)
            entries = sftp.listdir(sftp_path)
            sftp.close()
            return entries
        except Exception:
            return []

    def get(self, path: str) -> bytes:
        """Get file content."""
        server, sftp_path = self._parse_url(path)
        
        try:
            sftp = self._connect(server)
            data = sftp.file(sftp_path, 'rb').read()
            sftp.close()
            return data
        except Exception as e:
            raise FileNotFoundError(f"Failed to fetch {path}: {e}")

    def put(self, path: str, content: bytes) -> None:
        """Put file content."""
        server, sftp_path = self._parse_url(path)
        
        try:
            sftp = self._connect(server)
            with sftp.file(sftp_path, 'wb') as f:
                f.write(content)
            sftp.close()
        except Exception as e:
            raise IOError(f"Failed to put {path}: {e}")

    def exists(self, path: str) -> bool:
        """Check if path exists."""
        server, sftp_path = self._parse_url(path)
        
        try:
            sftp = self._connect(server)
            try:
                sftp.stat(sftp_path)
                sftp.close()
                return True
            except FileNotFoundError:
                sftp.close()
                return False
        except Exception:
            return False

    def mkdir(self, path: str) -> None:
        """Create directory."""
        server, sftp_path = self._parse_url(path)
        
        try:
            sftp = self._connect(server)
            sftp.mkdir(sftp_path)
            sftp.close()
        except Exception as e:
            raise IOError(f"Failed to create directory {path}: {e}")

    def validate(self, virtual_path: str, link_data: Dict) -> bool:
        """Validate if SFTP URL is accessible."""
        target = link_data.get("target", "")
        
        if not target.startswith("sftp://"):
            self._update_status(virtual_path, False, "Invalid SFTP URL")
            return False

        try:
            server, sftp_path = self._parse_url(target)
            sftp = self._connect(server)
            
            try:
                sftp.stat(sftp_path)
                is_valid = True
            except FileNotFoundError:
                is_valid = False
            
            sftp.close()
            self._update_status(virtual_path, is_valid, None if is_valid else "File not found")
            return is_valid
            
        except Exception as e:
            self._update_status(virtual_path, False, str(e))
            return False
