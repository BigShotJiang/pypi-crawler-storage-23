"""SyncGate REST API Server."""

import json
from http.server import HTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs
import sys
from pathlib import Path

from syncgate.vfs import VirtualFS
from syncgate.backend.local import LocalBackend
from syncgate.gateway import Gateway


class SyncGateAPI:
    """SyncGate REST API."""

    def __init__(self, vfs_root: str = "virtual"):
        self.vfs_root = Path(vfs_root)
        self.vfs = VirtualFS(str(self.vfs_root))
        db_path = str(self.vfs_root / "status.db")
        self.backend = LocalBackend(
            vfs_root=str(self.vfs_root),
            local_root=str(self.vfs_root),
            db_path=db_path
        )
        self.gateway = Gateway(self.vfs, self.backend)

    def list_links(self, path: str = "/") -> dict:
        """List links in a directory."""
        try:
            entries = self.vfs.list(path)
            return {"success": True, "data": entries}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def get_link(self, virtual_path: str) -> dict:
        """Get link info."""
        try:
            target = self.vfs.resolve(virtual_path)
            status = self.gateway.get_link_status(virtual_path)
            return {
                "success": True,
                "data": {
                    "path": virtual_path,
                    "target": target,
                    "status": status
                }
            }
        except Exception as e:
            return {"success": False, "error": str(e)}

    def create_link(self, virtual_path: str, target: str, backend: str) -> dict:
        """Create a link."""
        try:
            self.vfs.link(virtual_path, target, backend)
            return {"success": True, "message": f"Linked: {virtual_path} -> {target}"}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def delete_link(self, virtual_path: str) -> dict:
        """Delete a link."""
        try:
            if self.vfs.unlink(virtual_path):
                return {"success": True, "message": f"Unlinked: {virtual_path}"}
            return {"success": False, "error": "Link not found"}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def validate_link(self, virtual_path: str) -> dict:
        """Validate a link."""
        try:
            valid = self.gateway.validate(virtual_path)
            return {"success": True, "valid": valid}
        except Exception as e:
            return {"success": False, "error": str(e)}

    def get_stats(self) -> dict:
        """Get statistics."""
        try:
            links = []
            for root, dirs, files in self.vfs._index.walk():
                for link in root.iterdir():
                    if link.suffix == ".link":
                        path = str(link.relative_to(self.vfs_root)).replace(".link", "")
                        links.append(path)
            
            return {
                "success": True,
                "data": {
                    "total_links": len(links),
                    "vfs_root": str(self.vfs_root)
                }
            }
        except Exception as e:
            return {"success": False, "error": str(e)}


class SyncGateHandler(BaseHTTPRequestHandler):
    """HTTP request handler."""

    api: SyncGateAPI = None

    def _send_json(self, data: dict, status: int = 200):
        """Send JSON response."""
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.end_headers()
        self.wfile.write(json.dumps(data, indent=2).encode())

    def do_GET(self):
        """Handle GET requests."""
        parsed = urlparse(self.path)
        path = parsed.path

        if path == "/":
            self._send_json({
                "name": "SyncGate API",
                "version": "1.0.0",
                "endpoints": ["/api/links", "/api/links/<path>", "/api/stats"]
            })
        elif path == "/api/stats":
            result = self.api.get_stats()
            self._send_json(result)
        elif path.startswith("/api/links/"):
            virtual_path = path.replace("/api/links/", "")
            result = self.api.get_link(virtual_path)
            self._send_json(result)
        else:
            self._send_json({"error": "Not found"}, 404)

    def do_POST(self):
        """Handle POST requests."""
        parsed = urlparse(self.path)
        path = parsed.path

        if path == "/api/links":
            length = int(self.headers.get("Content-Length", 0))
            body = self.rfile.read(length).decode()
            data = json.loads(body)

            result = self.api.create_link(
                data.get("virtual_path"),
                data.get("target"),
                data.get("backend", "local")
            )
            self._send_json(result, 201 if result["success"] else 400)
        else:
            self._send_json({"error": "Not found"}, 404)

    def do_DELETE(self):
        """Handle DELETE requests."""
        parsed = urlparse(self.path)
        path = parsed.path

        if path.startswith("/api/links/"):
            virtual_path = path.replace("/api/links/", "")
            result = self.api.delete_link(virtual_path)
            self._send_json(result, 200 if result["success"] else 404)
        else:
            self._send_json({"error": "Not found"}, 404)

    def log_message(self, format: str, *args):
        """Log HTTP requests."""
        print(f"[HTTP] {args[0]}")


def run_server(host: str = "localhost", port: int = 8080, vfs_root: str = "virtual"):
    """Run the API server."""
    api = SyncGateAPI(vfs_root)
    SyncGateHandler.api = api

    server = HTTPServer((host, port), SyncGateHandler)
    print(f"🚀 SyncGate API Server running at http://{host}:{port}")
    print("Press Ctrl+C to stop")

    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n👋 Server stopped")
        server.shutdown()


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="SyncGate API Server")
    parser.add_argument("--host", default="localhost", help="Host to bind")
    parser.add_argument("--port", type=int, default=8080, help="Port to listen")
    parser.add_argument("--vfs-root", default="virtual", help="VFS root directory")

    args = parser.parse_args()

    run_server(args.host, args.port, args.vfs_root)
