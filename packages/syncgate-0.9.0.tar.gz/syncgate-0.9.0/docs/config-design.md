# SyncGate 配置系统

## 设计目标
简化 CLI 使用，自动发现配置

## 配置位置
1. `~/.config/syncgate/config.toml` (用户级)
2. `syncgate.toml` (项目级)
3. 环境变量 (最高优先级)

## 配置格式
```toml
[backend.local]
root = "/home/user/files"

[backend.s3]
region = "us-east-1"
bucket = "my-bucket"

[defaults]
default_backend = "local"
```

## 使用方式
```bash
# 自动读取配置
syncgate link /docs/file.txt file.txt  # 使用默认 backend
syncgate set-default s3  # 设置默认后端

# 列出配置的 backend
syncgate backend list
```

## 实现优先级
- [ ] 配置加载器
- [ ] `backend list` 命令
- [ ] `set-default` 命令
- [ ] 环境变量覆盖
