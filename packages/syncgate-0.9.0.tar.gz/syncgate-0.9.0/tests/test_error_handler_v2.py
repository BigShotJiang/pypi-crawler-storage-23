"""Tests for error handling v2."""

import pytest
from syncgate.error_handler_v2 import (
    ErrorType,
    RecoverySuggestion,
    ErrorContext,
    SyncGateError,
    BackendError,
    ConnectionError,
    AuthenticationError,
    FileNotFoundError_,
    get_suggestion_message,
    format_error,
    error_boundary,
    RetryManager,
    with_retry,
)


def test_error_type_enum():
    """Test error type enum values."""
    assert ErrorType.CONNECTION_FAILED.value == "connection_failed"
    assert ErrorType.AUTH_FAILED.value == "auth_failed"
    assert ErrorType.FILE_NOT_FOUND.value == "file_not_found"


def test_recovery_suggestion_enum():
    """Test recovery suggestion enum values."""
    assert RecoverySuggestion.CHECK_CREDENTIALS.value == "check_credentials"
    assert RecoverySuggestion.RETRY_LATER.value == "retry_later"


def test_error_context():
    """Test error context."""
    ctx = ErrorContext(
        operation="read",
        path="/docs/a.txt",
        backend="s3",
        details={"size": 1024},
    )
    
    assert ctx.operation == "read"
    assert ctx.path == "/docs/a.txt"
    assert ctx.backend == "s3"
    assert ctx.details["size"] == 1024


def test_syncgate_error():
    """Test SyncGate error."""
    error = SyncGateError(
        error_type=ErrorType.UNKNOWN,
        message="Something went wrong",
        suggestion=RecoverySuggestion.REPORT_ISSUE,
    )
    
    assert str(error) == "Something went wrong"
    assert error.error_type == ErrorType.UNKNOWN
    assert error.suggestion == RecoverySuggestion.REPORT_ISSUE


def test_backend_error():
    """Test backend error."""
    error = BackendError(
        message="S3 connection failed",
        backend="s3",
        suggestion=RecoverySuggestion.CHECK_CONNECTION,
    )
    
    assert error.backend == "s3"
    assert error.error_type == ErrorType.BACKEND_ERROR


def test_connection_error():
    """Test connection error."""
    error = ConnectionError(
        message="Connection timeout",
        url="https://example.com",
        suggestion=RecoverySuggestion.RETRY_LATER,
    )
    
    assert error.url == "https://example.com"
    assert error.error_type == ErrorType.CONNECTION_FAILED


def test_authentication_error():
    """Test authentication error."""
    error = AuthenticationError(
        message="Invalid credentials",
        backend="s3",
    )
    
    assert error.backend == "s3"
    assert error.error_type == ErrorType.AUTH_FAILED
    assert error.suggestion == RecoverySuggestion.CHECK_CREDENTIALS


def test_file_not_found_error():
    """Test file not found error."""
    error = FileNotFoundError_(
        path="/docs/missing.txt",
    )
    
    assert error.path == "/docs/missing.txt"
    assert error.error_type == ErrorType.FILE_NOT_FOUND
    assert "missing.txt" in error.message


def test_get_suggestion_message():
    """Test getting suggestion message."""
    msg = get_suggestion_message(RecoverySuggestion.CHECK_CREDENTIALS)
    assert "凭证" in msg
    
    msg = get_suggestion_message(RecoverySuggestion.RETRY_LATER)
    assert "重试" in msg


def test_format_error():
    """Test formatting error message."""
    error = BackendError(
        message="S3 error",
        backend="s3",
    )
    
    formatted = format_error(error)
    
    assert "❌" in formatted
    assert "S3 error" in formatted
    assert "💡" in formatted


def test_error_boundary_success():
    """Test error boundary with successful function."""
    
    @error_boundary(fallback="fallback")
    def success_func():
        return "success"
    
    result = success_func()
    assert result == "success"


def test_error_boundary_syncgate_error():
    """Test error boundary with SyncGateError."""
    
    @error_boundary(fallback="fallback", reraise=False)
    def error_func():
        raise BackendError("test", "backend")
    
    result = error_func()
    assert result == "fallback"


def test_error_boundary_reraise():
    """Test error boundary with reraise."""
    
    @error_boundary(reraise=True)
    def error_func():
        raise BackendError("test", "backend")
    
    with pytest.raises(BackendError):
        error_func()


def test_error_boundary_generic_exception():
    """Test error boundary with generic exception."""
    
    @error_boundary(fallback="fallback")
    def error_func():
        raise ValueError("test")
    
    result = error_func()
    assert result == "fallback"


def test_retry_manager_success():
    """Test RetryManager successful execution."""
    
    with RetryManager(max_attempts=3, delay=0.01) as manager:
        result = manager.execute(lambda: "success")
    
    assert result == "success"
    assert manager.succeeded is True
    assert manager.attempts == 1


def test_retry_manager_failure():
    """Test RetryManager with eventual failure."""
    
    with pytest.raises(ValueError):
        with RetryManager(max_attempts=3, delay=0.01) as manager:
            manager.execute(lambda: (_ for _ in ()).throw(ValueError("fail")))
    
    assert manager.succeeded is False
    assert manager.attempts == 3


def test_retry_manager_retry_success():
    """Test RetryManager with retry then success."""
    call_count = [0]
    
    def flaky_func():
        call_count[0] += 1
        if call_count[0] < 3:
            raise ValueError("try again")
        return "success"
    
    with RetryManager(max_attempts=5, delay=0.01) as manager:
        result = manager.execute(flaky_func)
    
    assert result == "success"
    assert manager.succeeded is True
    assert manager.attempts == 3


def test_with_retry_decorator():
    """Test with_retry decorator."""
    call_count = [0]
    
    @with_retry(max_attempts=3, delay=0.01)
    def flaky_func():
        call_count[0] += 1
        if call_count[0] < 2:
            raise ValueError("try again")
        return "done"
    
    result = flaky_func()
    assert result == "done"
    assert call_count[0] == 2


def test_error_with_original_exception():
    """Test error with original exception."""
    original = ValueError("original error")
    
    error = BackendError(
        message="wrapped",
        backend="test",
        original_error=original,
    )
    
    assert error.original_error is original
    assert "ValueError" in format_error(error)


def test_error_context_in_format():
    """Test error formatting with context."""
    error = FileNotFoundError_(
        path="/docs/a.txt",
    )
    error.context = ErrorContext(
        operation="read",
        path="/docs/a.txt",
        backend="local",
    )
    
    formatted = format_error(error)
    
    assert "/docs/a.txt" in formatted


def test_custom_fallback():
    """Test error boundary with custom fallback."""
    
    @error_boundary(fallback={"status": "error"})
    def error_func():
        raise BackendError("test", "backend")
    
    result = error_func()
    assert result == {"status": "error"}


def test_retry_manager_backoff():
    """Test RetryManager backoff behavior."""
    
    def always_fail():
        raise ValueError("fail")
    
    with pytest.raises(ValueError):
        with RetryManager(max_attempts=3, delay=0.01, backoff=2.0, max_delay=10.0) as manager:
            manager.execute(always_fail)
    
    # Should have attempted 3 times
    assert manager.attempts == 3


def test_authentication_error_default_suggestion():
    """Test authentication error has default suggestion."""
    error = AuthenticationError(
        message="Auth failed",
        backend="test",
    )
    
    assert error.suggestion == RecoverySuggestion.CHECK_CREDENTIALS


def test_file_not_found_default_suggestion():
    """Test file not found error has default suggestion."""
    error = FileNotFoundError_(
        path="/docs/a.txt",
    )
    
    assert error.suggestion == RecoverySuggestion.VERIFY_URL
