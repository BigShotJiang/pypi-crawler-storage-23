"""Tests for WebDAV backend."""

import tempfile
from pathlib import Path
from syncgate.backend.webdav import WebDAVBackend


def test_webdav_init():
    """Test WebDAV backend initialization."""
    with tempfile.TemporaryDirectory() as tmpdir:
        backend = WebDAVBackend(
            vfs_root=tmpdir,
            db_path=f"{tmpdir}/test.db",
        )
        
        assert backend.vfs_root == tmpdir
        assert backend.timeout == 30
        assert backend.verify_ssl is True


def test_webdav_url_parsing():
    """Test WebDAV URL parsing."""
    with tempfile.TemporaryDirectory() as tmpdir:
        backend = WebDAVBackend(
            vfs_root=tmpdir,
            db_path=f"{tmpdir}/test.db",
        )
        
        # Test URL parsing
        server, path = backend._parse_url("webdav://server.com/path/to/file")
        assert server == "server.com"
        assert path == "/path/to/file"
        
        server, path = backend._parse_url("webdav://nas.local/data")
        assert server == "nas.local"
        assert path == "/data"


def test_webdav_exists():
    """Test exists check (mock server)."""
    with tempfile.TemporaryDirectory() as tmpdir:
        backend = WebDAVBackend(
            vfs_root=tmpdir,
            db_path=f"{tmpdir}/test.db",
        )
        
        # Non-existent URL should return False
        # (connection will fail, handled gracefully)
        try:
            result = backend.exists("webdav://nonexistent-server.local/file.txt")
            # Should be False due to connection failure
            assert result is False
        except:
            # Exceptions are also acceptable for non-existent servers
            pass


def test_webdav_validate():
    """Test link validation."""
    with tempfile.TemporaryDirectory() as tmpdir:
        backend = WebDAVBackend(
            vfs_root=tmpdir,
            db_path=f"{tmpdir}/test.db",
        )
        
        link_data = {"target": "webdav://server.com/file.txt", "backend": "webdav"}
        
        # Should return False for non-existent server
        result = backend.validate("/test/link", link_data)
        assert result is False
        
        # Check status was recorded
        status = backend.get_status("/test/link")
        assert status["valid"] is False


def test_webdav_status():
    """Test status tracking."""
    with tempfile.TemporaryDirectory() as tmpdir:
        backend = WebDAVBackend(
            vfs_root=tmpdir,
            db_path=f"{tmpdir}/test.db",
        )
        
        # Initial status should be valid
        status = backend.get_status("/test/file")
        assert status["valid"] is True
        assert status["error"] is None


def test_webdav_invalid_url():
    """Test validation with invalid URL."""
    with tempfile.TemporaryDirectory() as tmpdir:
        backend = WebDAVBackend(
            vfs_root=tmpdir,
            db_path=f"{tmpdir}/test.db",
        )
        
        link_data = {"target": "http://example.com/file.txt", "backend": "webdav"}
        
        # Should reject non-webdav URLs
        result = backend.validate("/test/link", link_data)
        assert result is False
        
        status = backend.get_status("/test/link")
        assert status["valid"] is False
        assert "Invalid WebDAV URL" in status["error"]
