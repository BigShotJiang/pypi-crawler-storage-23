"""Tests for Gateway."""

import tempfile
from pathlib import Path
from syncgate.vfs import VirtualFS
from syncgate.backend import LocalBackend
from syncgate.gateway import Gateway


def test_ls():
    """Test listing directory."""
    with tempfile.TemporaryDirectory() as tmpdir:
        vfs_root = Path(tmpdir) / "vfs"
        local_root = Path(tmpdir) / "local"
        db_path = Path(tmpdir) / "status.db"

        vfs_root.mkdir()
        local_root.mkdir()

        # Create local file
        (local_root / "data").mkdir()
        (local_root / "data" / "a.txt").write_text("hello")

        vfs = VirtualFS(str(vfs_root))
        backend = LocalBackend(str(vfs_root), str(local_root), str(db_path))
        gateway = Gateway(vfs, backend)

        vfs.link("/docs/a.txt", "local:/data/a.txt", "local")

        output = gateway.ls("/docs")
        assert "✅ a.txt" in output


def test_ls_empty():
    """Test listing empty directory."""
    with tempfile.TemporaryDirectory() as tmpdir:
        vfs_root = Path(tmpdir) / "vfs"
        local_root = Path(tmpdir) / "local"
        db_path = Path(tmpdir) / "status.db"

        vfs_root.mkdir()
        local_root.mkdir()

        vfs = VirtualFS(str(vfs_root))
        backend = LocalBackend(str(vfs_root), str(local_root), str(db_path))
        gateway = Gateway(vfs, backend)

        output = gateway.ls("/empty")
        assert "empty directory" in output.lower()


def test_get_link_status():
    """Test getting link status."""
    with tempfile.TemporaryDirectory() as tmpdir:
        vfs_root = Path(tmpdir) / "vfs"
        local_root = Path(tmpdir) / "local"
        db_path = Path(tmpdir) / "status.db"

        vfs_root.mkdir()
        local_root.mkdir()

        vfs = VirtualFS(str(vfs_root))
        backend = LocalBackend(str(vfs_root), str(local_root), str(db_path))
        gateway = Gateway(vfs, backend)

        vfs.link("/docs/a.txt", "local:/data/a.txt", "local")

        status = gateway.get_link_status("/docs/a.txt")
        assert "valid" in status


def test_tree():
    """Test tree display."""
    with tempfile.TemporaryDirectory() as tmpdir:
        vfs_root = Path(tmpdir) / "vfs"
        local_root = Path(tmpdir) / "local"
        db_path = Path(tmpdir) / "status.db"

        vfs_root.mkdir()
        local_root.mkdir()

        # Create local files
        (local_root / "data").mkdir()
        (local_root / "data" / "a.txt").write_text("hello")
        (local_root / "data" / "b.txt").write_text("world")

        vfs = VirtualFS(str(vfs_root))
        backend = LocalBackend(str(vfs_root), str(local_root), str(db_path))
        gateway = Gateway(vfs, backend)

        vfs.link("/docs/a.txt", "local:/data/a.txt", "local")
        vfs.link("/docs/sub/b.txt", "local:/data/b.txt", "local")

        output = gateway.tree("/docs")
        assert "✅ a.txt" in output
        assert "✅ b.txt" in output
        assert "sub" in output
