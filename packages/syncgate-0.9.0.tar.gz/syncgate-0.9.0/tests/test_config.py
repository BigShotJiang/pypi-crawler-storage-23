"""Tests for config management."""

import tempfile
import json
from pathlib import Path
from syncgate.config import (
    ConfigManager,
    SyncGateConfig,
    S3Config,
    WebDAVConfig,
    FTPConfig,
    load_config,
)


def test_default_config():
    """Test default configuration."""
    config = SyncGateConfig()
    
    assert config.vfs_root == "virtual"
    assert config.cache_ttl == 300
    assert config.log_level == "INFO"
    assert config.retry_attempts == 3
    assert config.retry_delay == 1.0
    assert config.local.enabled is True
    assert config.http.enabled is True


def test_s3_config():
    """Test S3 configuration."""
    config = S3Config(
        aws_access_key_id="AKIAxxx",
        aws_secret_access_key="secret",
        region="us-west-2",
    )
    
    assert config.aws_access_key_id == "AKIAxxx"
    assert config.aws_secret_access_key == "secret"
    assert config.region == "us-west-2"


def test_webdav_config():
    """Test WebDAV configuration."""
    config = WebDAVConfig(
        url="https://dav.example.com",
        username="user",
        password="pass",
    )
    
    assert config.url == "https://dav.example.com"
    assert config.username == "user"
    assert config.password == "pass"


def test_ftp_config():
    """Test FTP configuration."""
    config = FTPConfig(
        host="ftp.example.com",
        port=21,
        username="user",
        password="pass",
        use_tls=True,
    )
    
    assert config.host == "ftp.example.com"
    assert config.port == 21
    assert config.use_tls is True


def test_load_json_config():
    """Test loading JSON configuration."""
    with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
        json.dump({
            "vfs_root": "json_virtual",
            "cache_ttl": 500,
            "backend": {
                "ftp": {
                    "host": "ftp.example.com",
                    "port": 2121,
                    "use_tls": True,
                },
            },
        }, f)
        config_path = f.name
    
    try:
        config = load_config(config_path)
        
        assert config.vfs_root == "json_virtual"
        assert config.cache_ttl == 500
        assert config.ftp.host == "ftp.example.com"
        assert config.ftp.port == 2121
        assert config.ftp.use_tls is True
    finally:
        Path(config_path).unlink()


def test_save_and_load_config():
    """Test saving and loading configuration."""
    config = SyncGateConfig(
        vfs_root="test_root",
        cache_ttl=1000,
    )
    config.s3.aws_access_key_id = "SAVED_KEY"
    config.s3.aws_secret_access_key = "SAVED_SECRET"
    
    with tempfile.NamedTemporaryFile(suffix='.json', delete=False) as f:
        config_path = f.name
    
    try:
        # Save config
        from syncgate.config import save_config
        save_config(config, config_path)
        
        # Load and verify
        loaded = load_config(config_path)
        
        assert loaded.vfs_root == "test_root"
        assert loaded.cache_ttl == 1000
        assert loaded.s3.aws_access_key_id == "SAVED_KEY"
    finally:
        Path(config_path).unlink()


def test_is_backend_enabled():
    """Test checking if backend is enabled."""
    config = SyncGateConfig()
    
    assert config.local.enabled is True
    assert config.http.enabled is True
    
    # Disable a backend
    config.s3.enabled = False
    
    manager = ConfigManager()
    manager.config = config
    
    assert manager.is_backend_enabled("local") is True
    assert manager.is_backend_enabled("s3") is False


def test_config_manager_auto_detect():
    """Test ConfigManager auto-detects config file."""
    with tempfile.TemporaryDirectory() as tmpdir:
        config_path = Path(tmpdir) / "syncgate.json"
        config_path.write_text('{"vfs_root": "auto_test"}\n')
        
        manager = ConfigManager()
        manager.load(str(config_path))
        
        assert manager.config.vfs_root == "auto_test"


def test_partial_config_update():
    """Test partial configuration update."""
    with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
        json.dump({
            "vfs_root": "original",
            "backend": {
                "s3": {
                    "region": "us-east-1",
                },
            },
        }, f)
        config_path = f.name
    
    try:
        config = load_config(config_path)
        
        # Original values
        assert config.vfs_root == "original"
        assert config.s3.region == "us-east-1"
        
        # Update only s3 region
        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
            json.dump({
                "backend": {
                    "s3": {
                        "region": "us-west-2",
                    },
                },
            }, f)
            update_path = f.name
        
        try:
            config = load_config(update_path)
            assert config.s3.region == "us-west-2"
        finally:
            Path(update_path).unlink()
    finally:
        Path(config_path).unlink()


def test_http_config():
    """Test HTTP configuration."""
    config = SyncGateConfig()
    
    assert config.http.timeout == 30
    assert config.http.verify_ssl is True
    assert config.http.headers == {}
    
    # Update HTTP config
    config.http.timeout = 60
    config.http.verify_ssl = False
    config.http.headers = {"User-Agent": "SyncGate"}
    
    assert config.http.timeout == 60
    assert config.http.verify_ssl is False
    assert config.http.headers["User-Agent"] == "SyncGate"


def test_sftp_config():
    """Test SFTP configuration."""
    config = SyncGateConfig()
    
    config.sftp.host = "sftp.example.com"
    config.sftp.port = 2222
    config.sftp.username = "sftp_user"
    config.sftp.password = "sftp_pass"
    config.sftp.key_filename = "/path/to/key"
    
    assert config.sftp.host == "sftp.example.com"
    assert config.sftp.port == 2222
    assert config.sftp.username == "sftp_user"
    assert config.sftp.key_filename == "/path/to/key"
