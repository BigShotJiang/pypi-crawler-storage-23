"""Test configuration."""

import pathlib

# Discover tests in tests directory
pytest_plugins = ["tests"]
