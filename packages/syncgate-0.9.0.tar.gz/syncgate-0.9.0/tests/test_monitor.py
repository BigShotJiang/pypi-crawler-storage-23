"""Tests for monitoring and statistics."""

import tempfile
import time
from pathlib import Path
from syncgate.monitor import StatsCollector, PerformanceMonitor


def test_stats_collector_init():
    """Test stats collector initialization."""
    with tempfile.TemporaryDirectory() as tmpdir:
        stats = StatsCollector(vfs_root=tmpdir)
        assert stats.stats["created"] == 0
        assert stats.stats["deleted"] == 0


def test_record_create():
    """Test recording link creation."""
    with tempfile.TemporaryDirectory() as tmpdir:
        stats = StatsCollector(vfs_root=tmpdir)

        stats.record_create("local")
        stats.record_create("http")
        stats.record_create("local")

        assert stats.stats["created"] == 3
        assert stats.stats["by_backend"]["local"] == 2
        assert stats.stats["by_backend"]["http"] == 1


def test_record_delete():
    """Test recording link deletion."""
    with tempfile.TemporaryDirectory() as tmpdir:
        stats = StatsCollector(vfs_root=tmpdir)

        stats.record_create()
        stats.record_delete()

        assert stats.stats["created"] == 1
        assert stats.stats["deleted"] == 1


def test_record_validate():
    """Test recording validation."""
    with tempfile.TemporaryDirectory() as tmpdir:
        stats = StatsCollector(vfs_root=tmpdir)

        stats.record_validate(success=True)
        stats.record_validate(success=True)
        stats.record_validate(success=False)

        assert stats.stats["validated"] == 3
        assert stats.stats["errors"] == 1


def test_get_summary():
    """Test getting stats summary."""
    with tempfile.TemporaryDirectory() as tmpdir:
        stats = StatsCollector(vfs_root=tmpdir)

        stats.record_create()
        stats.record_create()
        stats.record_validate(success=True)

        summary = stats.get_summary()

        assert summary["created"] == 2
        assert summary["validated"] == 1


def test_get_backend_stats():
    """Test getting backend stats."""
    with tempfile.TemporaryDirectory() as tmpdir:
        stats = StatsCollector(vfs_root=tmpdir)

        stats.record_create("local")
        stats.record_create("local")
        stats.record_create("http")
        stats.record_create("s3")

        backend_stats = stats.get_backend_stats()

        assert backend_stats["local"] == 2
        assert backend_stats["http"] == 1
        assert backend_stats["s3"] == 1


def test_get_activity_by_day():
    """Test getting daily activity."""
    with tempfile.TemporaryDirectory() as tmpdir:
        stats = StatsCollector(vfs_root=tmpdir)

        # Record some activity
        stats.record_create()
        stats.record_create()
        stats.record_create()

        activity = stats.get_activity_by_day(days=7)

        assert len(activity) == 7
        # Today should have 3
        today_activity = activity[0]
        assert today_activity["created"] == 3


def test_get_health_score():
    """Test health score calculation."""
    with tempfile.TemporaryDirectory() as tmpdir:
        stats = StatsCollector(vfs_root=tmpdir)

        # No operations = 0 score
        assert stats.get_health_score() == 0

        # With operations
        stats.record_create()
        stats.record_validate(success=True)
        stats.record_validate(success=True)

        score = stats.get_health_score()
        assert 0 <= score <= 100


def test_reset():
    """Test resetting stats."""
    with tempfile.TemporaryDirectory() as tmpdir:
        stats = StatsCollector(vfs_root=tmpdir)

        stats.record_create()
        stats.record_create()

        assert stats.stats["created"] == 2

        stats.reset()

        assert stats.stats["created"] == 0


def test_performance_monitor():
    """Test performance monitor."""
    monitor = PerformanceMonitor()

    # Record some operations
    monitor.start_operation("op1")
    time.sleep(0.01)
    monitor.end_operation(success=True)

    monitor.start_operation("op2")
    time.sleep(0.02)
    monitor.end_operation(success=True)

    stats = monitor.get_stats()

    assert stats["count"] == 2
    assert stats["success_rate"] == 1.0
    assert stats["avg_duration"] > 0


def test_get_slow_operations():
    """Test getting slow operations."""
    monitor = PerformanceMonitor()

    # Record fast operation
    monitor.start_operation("fast")
    time.sleep(0.001)
    monitor.end_operation(success=True)

    # Record slow operation
    monitor.start_operation("slow")
    time.sleep(0.1)  # 100ms is slow
    monitor.end_operation(success=True)

    slow = monitor.get_slow_operations(threshold=0.05)

    assert len(slow) == 1
    assert slow[0]["name"] == "slow"


def test_reset_performance():
    """Test resetting performance monitor."""
    monitor = PerformanceMonitor()

    monitor.start_operation("op1")
    monitor.end_operation(success=True)

    assert monitor.get_stats()["count"] == 1

    monitor.reset()

    assert monitor.get_stats()["count"] == 0
