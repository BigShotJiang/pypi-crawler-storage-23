"""调试 Original list"""

import tempfile
from pathlib import Path

with tempfile.TemporaryDirectory() as tmpdir:
    root = Path(tmpdir) / "vfs"
    root.mkdir()
    
    # 根目录文件
    for i in range(100):
        link_path = root / f"file{i}.link"
        link_path.write_text(f'{{"target": "test{i}", "backend": "local"}}')
    
    # 检查
    files = list(root.glob("*.link"))
    print(f"根目录 .link 文件: {len(files)}")
    
    from syncgate.vfs.fs import VirtualFS
    
    vfs = VirtualFS(str(root))
    r = vfs.list("/")
    print(f"list('/') 条目: {len(r)}")
    print(f"r 类型: {type(r)}")
    print(f"r 内容[:3]: {r[:3] if len(r) > 3 else r}")
