"""Tests for AI module."""

import tempfile
from pathlib import Path
from syncgate.ai import AIModule, SimpleEmbedding


def test_simple_embedding():
    """Test simple embedding tokenization."""
    emb = SimpleEmbedding()
    
    texts = [
        "Python is a programming language",
        "JavaScript is for web development",
        "AI and machine learning are popular",
    ]
    
    # Build vocabulary
    emb._build_vocab(texts)
    
    assert emb.vocab_size > 0
    assert "python" in emb.vocab
    assert "language" in emb.vocab


def test_embedding_vector():
    """Test embedding vector generation."""
    emb = SimpleEmbedding()
    
    texts = [
        "Python programming language",
        "JavaScript web development",
    ]
    emb._build_vocab(texts)
    
    # Get vector
    vector = emb.embed("Python programming")
    
    assert len(vector) == emb.vocab_size
    assert any(v > 0 for v in vector)  # Has some non-zero values


def test_ai_module_init():
    """Test AI module initialization."""
    with tempfile.TemporaryDirectory() as tmpdir:
        vfs_root = Path(tmpdir)
        ai = AIModule(str(vfs_root))
        
        assert ai.vfs_root == vfs_root
        assert ai.db_path.exists()
        
        # Check database initialized
        import sqlite3
        conn = sqlite3.connect(str(ai.db_path))
        cursor = conn.cursor()
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
        tables = cursor.fetchall()
        conn.close()
        
        assert ("metadata",) in tables
        assert ("embeddings",) in tables


def test_extract_metadata():
    """Test metadata extraction."""
    with tempfile.TemporaryDirectory() as tmpdir:
        vfs_root = Path(tmpdir)
        ai = AIModule(str(vfs_root))
        
        content = b"Hello World! This is a test document."
        meta = ai.extract_metadata("/test/doc.txt", content)
        
        assert meta["size"] == len(content)
        assert meta["word_count"] > 0
        assert "encoding" in meta


def test_index_content():
    """Test content indexing."""
    with tempfile.TemporaryDirectory() as tmpdir:
        vfs_root = Path(tmpdir)
        ai = AIModule(str(vfs_root))
        
        content = b"Python is a powerful programming language."
        ai.index_content("/test/python.txt", content)
        
        # Check indexed
        indexed = ai.list_indexed()
        assert "/test/python.txt" in indexed


def test_search():
    """Test semantic search."""
    with tempfile.TemporaryDirectory() as tmpdir:
        vfs_root = Path(tmpdir)
        ai = AIModule(str(vfs_root))
        
        # Index some documents
        docs = [
            ("/docs/python.txt", b"Python programming language learning"),
            ("/docs/js.txt", b"JavaScript web development coding"),
            ("/docs/ai.txt", b"Artificial intelligence machine learning"),
        ]
        
        all_texts = [d[1].decode('utf-8') for d in docs]
        ai.embedding._build_vocab(all_texts)
        
        for path, content in docs:
            ai.index_content(path, content)
        
        # Search for Python
        results = ai.search("Python programming", limit=2)
        
        assert len(results) > 0
        # First result should be python.txt
        assert results[0]["path"] == "/docs/python.txt"
        assert results[0]["similarity"] > 0


def test_cosine_similarity():
    """Test cosine similarity calculation."""
    with tempfile.TemporaryDirectory() as tmpdir:
        vfs_root = Path(tmpdir)
        ai = AIModule(str(vfs_root))
        
        # Build vocab
        texts = ["Python programming language", "Programming is fun"]
        ai.embedding._build_vocab(texts)
        
        # Same text
        v1 = ai.embedding.embed("Python programming")
        v2 = ai.embedding.embed("Python programming")
        sim = ai._cosine_similarity(v1, v2)
        assert sim > 0.99  # Should be essentially 1.0
        
        # Different text
        v3 = ai.embedding.embed("JavaScript web")
        sim = ai._cosine_similarity(v1, v3)
        assert sim < 1.0


def test_get_metadata():
    """Test getting metadata."""
    with tempfile.TemporaryDirectory() as tmpdir:
        vfs_root = Path(tmpdir)
        ai = AIModule(str(vfs_root))
        
        content = b"Test document content here."
        ai.extract_metadata("/test/doc.txt", content)
        
        meta = ai.get_metadata("/test/doc.txt")
        
        assert meta is not None
        assert meta["size"] == len(content)


def test_list_indexed():
    """Test listing indexed files."""
    with tempfile.TemporaryDirectory() as tmpdir:
        vfs_root = Path(tmpdir)
        ai = AIModule(str(vfs_root))
        
        # Initially empty
        indexed = ai.list_indexed()
        assert len(indexed) == 0
        
        # Add some content
        all_texts = ["doc1 content", "doc2 content", "doc3 content"]
        ai.embedding._build_vocab(all_texts)
        
        ai.index_content("/docs/a.txt", b"doc1 content")
        ai.index_content("/docs/b.txt", b"doc2 content")
        
        indexed = ai.list_indexed()
        assert len(indexed) == 2
        assert "/docs/a.txt" in indexed
        assert "/docs/b.txt" in indexed
