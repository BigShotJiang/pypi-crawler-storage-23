"""Performance tests for optimized VirtualFS."""

import tempfile
import time
from pathlib import Path


def test_index_build_performance():
    """Test index building performance."""
    with tempfile.TemporaryDirectory() as tmpdir:
        root = Path(tmpdir) / "vfs"
        root.mkdir()
        
        # Create many link files
        num_links = 1000
        for i in range(num_links):
            link_path = root / f"dir{i % 10}" / f"file{i}.link"
            link_path.parent.mkdir(parents=True, exist_ok=True)
            link_path.write_text('{"target": "test", "backend": "local"}')
        
        # Import and build
        import sys
        sys.path.insert(0, str(Path(__file__).parent.parent))
        
        from syncgate.vfs.optimized import OptimizedVirtualFSIndex
        
        start = time.time()
        index = OptimizedVirtualFSIndex(root)
        index.build()
        elapsed = time.time() - start
        
        print(f"Index build time: {elapsed:.3f}s for {num_links} links")
        assert elapsed < 1.0
        stats = index.get_stats()
        assert stats["total_entries"] == num_links


def test_cached_lookup():
    """Test cached lookup is faster."""
    with tempfile.TemporaryDirectory() as tmpdir:
        root = Path(tmpdir) / "vfs"
        root.mkdir()
        
        # Create links
        for i in range(100):
            link_path = root / f"file{i}.link"
            link_path.write_text(f'{{"target": "test{i}", "backend": "local"}}')
        
        import sys
        sys.path.insert(0, str(Path(__file__).parent.parent))
        
        from syncgate.vfs.optimized import CachedVirtualFS
        
        vfs = CachedVirtualFS(str(root))
        
        # First lookup
        start = time.time()
        for i in range(100):
            vfs.resolve(f"/file{i}")
        first_pass = time.time() - start
        
        # Second lookup (cached)
        start = time.time()
        for i in range(100):
            vfs.resolve(f"/file{i}")
        second_pass = time.time() - start
        
        print(f"First pass: {first_pass:.4f}s")
        print(f"Second pass (cached): {second_pass:.4f}s")
        assert second_pass < first_pass


def test_large_directory():
    """Test performance with large directory."""
    with tempfile.TemporaryDirectory() as tmpdir:
        root = Path(tmpdir) / "vfs"
        root.mkdir()
        
        # Create 5000 files
        num_files = 5000
        for i in range(num_files):
            link_path = root / f"file{i}.link"
            link_path.write_text('{"target": "test", "backend": "local"}')
        
        import sys
        sys.path.insert(0, str(Path(__file__).parent.parent))
        
        from syncgate.vfs.optimized import CachedVirtualFS
        
        vfs = CachedVirtualFS(str(root))
        
        start = time.time()
        stats = vfs.get_stats()
        elapsed = time.time() - start
        
        print(f"Stats collection for {num_files} files: {elapsed:.3f}s")
        assert elapsed < 1.0
        assert stats["total_links"] == num_files


if __name__ == "__main__":
    print("Running performance tests...")
    print()
    
    print("1. Index build (1000 links):")
    test_index_build_performance()
    print("   ✅ Pass\n")
    
    print("2. Cached lookup:")
    test_cached_lookup()
    print("   ✅ Pass\n")
    
    print("3. Large directory (5000 files):")
    test_large_directory()
    print("   ✅ Pass\n")
    
    print("All performance tests passed!")
