"""Tests for VirtualFS."""

import os
import tempfile
from pathlib import Path
from syncgate.vfs import VirtualFS


def test_link_and_resolve():
    """Test creating and resolving links."""
    with tempfile.TemporaryDirectory() as tmpdir:
        vfs = VirtualFS(tmpdir)

        # Create a link
        vfs.link("/docs/a.txt", "local:/data/a.txt", "local")

        # Resolve it
        result = vfs.resolve("/docs/a.txt")
        assert result is not None
        assert result["backend"] == "local"
        assert result["target"] == "local:/data/a.txt"
        assert result["link_path"].endswith("a.txt.link")


def test_list():
    """Test listing directory contents."""
    with tempfile.TemporaryDirectory() as tmpdir:
        vfs = VirtualFS(tmpdir)

        # Create links
        vfs.link("/docs/a.txt", "local:/data/a.txt", "local")
        vfs.link("/docs/b.txt", "local:/data/b.txt", "local")
        vfs.link("/docs/sub/c.txt", "local:/data/c.txt", "local")

        # List root
        entries = vfs.list("/docs")
        assert set(entries) == {"a.txt", "b.txt", "sub"}

        # List subdirectory
        sub_entries = vfs.list("/docs/sub")
        assert sub_entries == ["c.txt"]


def test_unlink():
    """Test removing links."""
    with tempfile.TemporaryDirectory() as tmpdir:
        vfs = VirtualFS(tmpdir)

        # Create and remove
        vfs.link("/docs/a.txt", "local:/data/a.txt", "local")
        assert vfs.resolve("/docs/a.txt") is not None

        result = vfs.unlink("/docs/a.txt")
        assert result is True
        assert vfs.resolve("/docs/a.txt") is None


def test_exists():
    """Test checking if path exists."""
    with tempfile.TemporaryDirectory() as tmpdir:
        vfs = VirtualFS(tmpdir)

        vfs.link("/docs/a.txt", "local:/data/a.txt", "local")

        assert vfs.exists("/docs/a.txt") is True
        assert vfs.exists("/docs/nonexistent") is False


def test_index_rebuild():
    """Test index rebuilding."""
    with tempfile.TemporaryDirectory() as tmpdir:
        vfs = VirtualFS(tmpdir)

        # Create links
        vfs.link("/docs/a.txt", "local:/data/a.txt", "local")
        vfs.link("/docs/b.txt", "local:/data/b.txt", "local")

        # Rebuild index
        vfs.rebuild_index()

        entries = vfs.list("/docs")
        assert set(entries) == {"a.txt", "b.txt"}
