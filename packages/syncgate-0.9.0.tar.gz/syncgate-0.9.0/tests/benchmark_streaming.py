"""流式加载性能测试"""

import tempfile
import time
from pathlib import Path


def create_test_data(root: Path, num_dirs: int = 10, num_files: int = 500):
    """创建测试数据"""
    # 在根目录放一些文件
    for i in range(100):
        link_path = root / f"file{i}.link"
        link_path.write_text(f'{{"target": "test{i}", "backend": "local"}}')
    
    # 子目录
    for d in range(num_dirs):
        subdir = root / f"dir{d}"
        subdir.mkdir()
        for i in range(num_files):
            link_path = subdir / f"file{i}.link"
            link_path.write_text(f'{{"target": "test{i}", "backend": "local"}}')
    
    return len(list(root.rglob("*.link")))


def benchmark():
    """性能测试"""
    print("=" * 60)
    print("SyncGate 流式加载性能测试")
    print("=" * 60)
    
    with tempfile.TemporaryDirectory() as tmpdir:
        root = Path(tmpdir) / "vfs"
        root.mkdir()
        
        # 创建测试数据
        total = create_test_data(root, 10, 500)
        print(f"\n测试数据: {total} 文件, 10 子目录")
        
        # 1. Original VirtualFS
        from syncgate.vfs.fs import VirtualFS
        
        start = time.time()
        vfs1 = VirtualFS(str(root))
        t1_init = (time.time() - start) * 1000
        
        start = time.time()
        r1 = vfs1.list("/")
        t1_list = (time.time() - start) * 1000
        
        print(f"\nOriginal VirtualFS:")
        print(f"  初始化: {t1_init:.2f}ms")
        print(f"  list('/'): {t1_list:.2f}ms, 条目: {len(r1)}")
        
        # 2. Optimized VirtualFS
        from syncgate.vfs.optimized import CachedVirtualFS
        
        start = time.time()
        vfs2 = CachedVirtualFS(str(root))
        t2_init = (time.time() - start) * 1000
        
        start = time.time()
        r2 = vfs2.list("/")
        t2_list = (time.time() - start) * 1000
        
        print(f"\nOptimized VirtualFS:")
        print(f"  初始化: {t2_init:.2f}ms")
        print(f"  list('/'): {t2_list:.2f}ms, 条目: {len(r2)}")
        
        # 3. Streaming VirtualFS
        from syncgate.vfs.streaming import StreamingVirtualFS
        
        start = time.time()
        vfs3 = StreamingVirtualFS(str(root))
        t3_init = (time.time() - start) * 1000
        
        start = time.time()
        r3 = vfs3.list("/")
        t3_list = (time.time() - start) * 1000
        
        # 滚动加载
        start = time.time()
        total_entries = 0
        for page in range(10):
            r = vfs3.list("/", page=page)
            total_entries += len(r.entries)
            if not r.has_more:
                break
        t3_scroll = (time.time() - start) * 1000
        
        print(f"\nStreaming VirtualFS:")
        print(f"  初始化: {t3_init:.2f}ms ⚡")
        print(f"  list('/'): {t3_list:.2f}ms, 条目: {len(r3.entries)}")
        print(f"  滚动 10 页: {t3_scroll:.2f}ms, 获取 {total_entries} 条")
        
        # 4. 本地文件系统
        start = time.time()
        entries = list(root.iterdir())
        t_local = (time.time() - start) * 1000
        
        print(f"\n本地文件系统:")
        print(f"  list(): {t_local:.2f}ms, 条目: {len(entries)}")
        
        # 总结
        print("\n" + "=" * 60)
        print("性能对比")
        print("=" * 60)
        print(f"{'实现':<20} {'初始化':<12} {'首屏加载':<12} {'相对本地FS'}")
        print("-" * 60)
        print(f"{'Original':<20} {t1_init:<12.2f}ms {t1_list:<12.2f}ms {t1_list/t_local:.2f}x")
        print(f"{'Optimized':<20} {t2_init:<12.2f}ms {t2_list:<12.2f}ms {t2_list/t_local:.2f}x")
        print(f"{'Streaming':<20} {t3_init:<12.2f}ms {t3_list:<12.2f}ms {t3_list/t_local:.2f}x")
        print(f"{'本地FS':<20} {'N/A':<12} {t_local:<12.2f}ms 1.00x")
        
        print("\n" + "=" * 60)
        print("结论")
        print("=" * 60)
        print(f"✓ Streaming 初始化最快: {t3_init:.2f}ms")
        print(f"✓ 首屏加载 {len(r3.entries)} 条，即点即开")
        print(f"✓ 滚动加载流畅，内存占用可控")


if __name__ == "__main__":
    benchmark()
