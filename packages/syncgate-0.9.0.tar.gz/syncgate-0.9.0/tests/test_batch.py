"""Tests for batch operations."""

import tempfile
import json
from pathlib import Path
from syncgate.batch import BatchOperations


def test_batch_create():
    """Test batch creating links."""
    with tempfile.TemporaryDirectory() as tmpdir:
        batch = BatchOperations(vfs_root=tmpdir)

        links = [
            {"virtual_path": "/a.txt", "target": "local:/tmp/a.txt", "backend": "local"},
            {"virtual_path": "/b.txt", "target": "local:/tmp/b.txt", "backend": "local"},
            {"virtual_path": "/c.txt", "target": "local:/tmp/c.txt", "backend": "local"},
        ]

        # Dry run
        result = batch.batch_create(links, dry_run=True)
        assert result["created"] == 3
        assert result["failed"] == 0

        # Actual create
        result = batch.batch_create(links)
        assert result["created"] == 3
        assert result["failed"] == 0


def test_batch_create_missing_data():
    """Test batch create with missing data."""
    with tempfile.TemporaryDirectory() as tmpdir:
        batch = BatchOperations(vfs_root=tmpdir)

        links = [
            {"virtual_path": "/a.txt", "target": "local:/tmp/a.txt"},
            {"virtual_path": "", "target": "local:/tmp/b.txt"},  # Missing path
            {"target": "local:/tmp/c.txt"},  # Missing both
        ]

        result = batch.batch_create(links)
        assert result["created"] == 1
        assert result["failed"] == 2


def test_batch_delete():
    """Test batch deleting links."""
    with tempfile.TemporaryDirectory() as tmpdir:
        batch = BatchOperations(vfs_root=tmpdir)

        # Create links first
        links = [
            {"virtual_path": "/a.txt", "target": "local:/tmp/a.txt"},
            {"virtual_path": "/b.txt", "target": "local:/tmp/b.txt"},
        ]
        batch.batch_create(links)

        # Dry run delete
        result = batch.batch_delete(["/a.txt", "/b.txt"], dry_run=True)
        assert result["deleted"] == 2

        # Actual delete
        result = batch.batch_delete(["/a.txt"])
        assert result["deleted"] == 1


def test_batch_validate():
    """Test batch validating links."""
    with tempfile.TemporaryDirectory() as tmpdir:
        batch = BatchOperations(vfs_root=tmpdir)

        # Create links
        links = [
            {"virtual_path": "/a.txt", "target": "local:/tmp/a.txt"},
        ]
        batch.batch_create(links)

        result = batch.batch_validate(["/a.txt"])
        assert result["valid"] == 1
        assert result["invalid"] == 0


def test_export_links():
    """Test exporting links to JSON."""
    with tempfile.TemporaryDirectory() as tmpdir:
        batch = BatchOperations(vfs_root=tmpdir)

        # Create links
        links = [
            {"virtual_path": "/a.txt", "target": "local:/tmp/a.txt", "backend": "local"},
            {"virtual_path": "/b.txt", "target": "local:/tmp/b.txt", "backend": "local"},
        ]
        batch.batch_create(links)

        # Export
        result = batch.export_links(output_file=f"{tmpdir}/links.json")
        assert result["exported"] == 2
        assert Path(f"{tmpdir}/links.json").exists()

        # Verify content
        with open(f"{tmpdir}/links.json") as f:
            data = json.load(f)
            assert len(data) == 2


def test_import_links():
    """Test importing links from JSON."""
    import json

    with tempfile.TemporaryDirectory() as tmpdir:
        batch = BatchOperations(vfs_root=tmpdir)

        # Create export file
        links = [
            {"virtual_path": "/a.txt", "target": "local:/tmp/a.txt", "backend": "local"},
        ]
        with open(f"{tmpdir}/export.json", 'w') as f:
            json.dump(links, f)

        # Import
        result = batch.import_links(f"{tmpdir}/export.json")
        assert result["imported"] == 1


def test_import_with_prefix():
    """Test importing links with path prefix."""
    import json

    with tempfile.TemporaryDirectory() as tmpdir:
        batch = BatchOperations(vfs_root=tmpdir)

        links = [
            {"virtual_path": "/a.txt", "target": "local:/tmp/a.txt", "backend": "local"},
        ]
        with open(f"{tmpdir}/export.json", 'w') as f:
            json.dump(links, f)

        # Import with prefix
        result = batch.import_links(f"{tmpdir}/export.json", prefix="/imported")
        assert result["imported"] == 1
