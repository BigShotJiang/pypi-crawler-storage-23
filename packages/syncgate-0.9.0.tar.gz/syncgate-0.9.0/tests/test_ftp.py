"""Tests for FTP backend."""

import tempfile
from pathlib import Path
from syncgate.backend.ftp import FTPBackend


def test_ftp_init():
    """Test FTP backend initialization."""
    with tempfile.TemporaryDirectory() as tmpdir:
        backend = FTPBackend(
            vfs_root=tmpdir,
            db_path=f"{tmpdir}/test.db",
        )
        
        assert backend.vfs_root == tmpdir
        assert backend.timeout == 30


def test_ftp_url_parsing():
    """Test FTP URL parsing."""
    with tempfile.TemporaryDirectory() as tmpdir:
        backend = FTPBackend(
            vfs_root=tmpdir,
            db_path=f"{tmpdir}/test.db",
        )
        
        # Test URL parsing
        server, path = backend._parse_url("ftp://server.com/path/to/file")
        assert server == "server.com"
        assert path == "/path/to/file"
        
        server, path = backend._parse_url("ftp://nas.local/data")
        assert server == "nas.local"
        assert path == "/data"


def test_ftp_validate():
    """Test link validation."""
    with tempfile.TemporaryDirectory() as tmpdir:
        backend = FTPBackend(
            vfs_root=tmpdir,
            db_path=f"{tmpdir}/test.db",
        )
        
        # Invalid URL should fail
        link_data = {"target": "http://example.com/file.txt", "backend": "ftp"}
        result = backend.validate("/test/link", link_data)
        assert result is False
        
        status = backend.get_status("/test/link")
        assert status["valid"] is False
        assert "Invalid FTP URL" in status["error"]


def test_ftp_status():
    """Test status tracking."""
    with tempfile.TemporaryDirectory() as tmpdir:
        backend = FTPBackend(
            vfs_root=tmpdir,
            db_path=f"{tmpdir}/test.db",
        )
        
        # Initial status should be valid
        status = backend.get_status("/test/file")
        assert status["valid"] is True


def test_ftp_exists():
    """Test exists check (should fail for non-existent server)."""
    with tempfile.TemporaryDirectory() as tmpdir:
        backend = FTPBackend(
            vfs_root=tmpdir,
            db_path=f"{tmpdir}/test.db",
        )
        
        # Should return False for non-existent server
        try:
            result = backend.exists("ftp://nonexistent-server.local/file.txt")
            # Should be False due to connection failure
            assert result is False
        except:
            # Exceptions are acceptable
            pass
