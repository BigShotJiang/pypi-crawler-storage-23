"""Tests for LocalBackend."""

import tempfile
from pathlib import Path
from syncgate.vfs import VirtualFS
from syncgate.backend import LocalBackend


def test_backend_list():
    """Test listing directory contents."""
    with tempfile.TemporaryDirectory() as tmpdir:
        vfs_root = Path(tmpdir) / "vfs"
        local_root = Path(tmpdir) / "local"
        db_path = Path(tmpdir) / "status.db"

        vfs_root.mkdir()
        local_root.mkdir()

        # Create local file
        (local_root / "data").mkdir()
        (local_root / "data" / "a.txt").write_text("hello")

        vfs = VirtualFS(str(vfs_root))
        backend = LocalBackend(str(vfs_root), str(local_root), str(db_path))

        vfs.link("/docs/a.txt", "local:/data/a.txt", "local")

        # List should work
        entries = backend.list("local:/data")
        assert "a.txt" in entries


def test_backend_get():
    """Test getting file content."""
    with tempfile.TemporaryDirectory() as tmpdir:
        vfs_root = Path(tmpdir) / "vfs"
        local_root = Path(tmpdir) / "local"
        db_path = Path(tmpdir) / "status.db"

        vfs_root.mkdir()
        local_root.mkdir()

        # Create local file
        (local_root / "data").mkdir()
        (local_root / "data" / "a.txt").write_text("hello world")

        vfs = VirtualFS(str(vfs_root))
        backend = LocalBackend(str(vfs_root), str(local_root), str(db_path))

        vfs.link("/docs/a.txt", "local:/data/a.txt", "local")

        # Get should return content
        content = backend.get("local:/data/a.txt")
        assert content == b"hello world"


def test_backend_validate():
    """Test link validation."""
    with tempfile.TemporaryDirectory() as tmpdir:
        vfs_root = Path(tmpdir) / "vfs"
        local_root = Path(tmpdir) / "local"
        db_path = Path(tmpdir) / "status.db"

        vfs_root.mkdir()
        local_root.mkdir()

        # Create local file
        (local_root / "data").mkdir()
        (local_root / "data" / "a.txt").write_text("hello")

        vfs = VirtualFS(str(vfs_root))
        backend = LocalBackend(str(vfs_root), str(local_root), str(db_path))

        vfs.link("/docs/a.txt", "local:/data/a.txt", "local")
        vfs.link("/docs/b.txt", "local:/data/nonexistent.txt", "local")

        # Validate valid link
        result = backend.validate("/docs/a.txt", vfs.resolve("/docs/a.txt"))
        assert result is True

        # Validate invalid link
        result = backend.validate("/docs/b.txt", vfs.resolve("/docs/b.txt"))
        assert result is False


def test_backend_status():
    """Test getting link status."""
    with tempfile.TemporaryDirectory() as tmpdir:
        vfs_root = Path(tmpdir) / "vfs"
        local_root = Path(tmpdir) / "local"
        db_path = Path(tmpdir) / "status.db"

        vfs_root.mkdir()
        local_root.mkdir()

        # Create local file
        (local_root / "data").mkdir()
        (local_root / "data" / "a.txt").write_text("hello")

        vfs = VirtualFS(str(vfs_root))
        backend = LocalBackend(str(vfs_root), str(local_root), str(db_path))

        vfs.link("/docs/a.txt", "local:/data/a.txt", "local")

        # Initially should be valid (no status recorded = assume valid)
        status = backend.get_status("/docs/a.txt")
        assert status["valid"] is True

        # After successful validation
        backend.validate("/docs/a.txt", vfs.resolve("/docs/a.txt"))
        status = backend.get_status("/docs/a.txt")
        assert status["valid"] is True  # File exists
