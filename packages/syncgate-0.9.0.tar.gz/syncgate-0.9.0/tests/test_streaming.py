"""Benchmark: Streaming vs Local vs Original SyncGate"""

import tempfile
import time
from pathlib import Path


def create_test_files(root: Path, count: int = 1000):
    """创建测试文件"""
    for i in range(count):
        link_path = root / f"file{i}.link"
        link_path.parent.mkdir(parents=True, exist_ok=True)
        link_path.write_text(f'{{"target": "test{i}", "backend": "local"}}')


def benchmark_original_vfs(root: Path):
    """测试原始 VirtualFS"""
    from syncgate.vfs.fs import VirtualFS
    
    vfs = VirtualFS(str(root))
    
    # 测试 1: 初始化时间
    start = time.time()
    vfs = VirtualFS(str(root))
    init_time = time.time() - start
    
    # 测试 2: 首次 list
    start = time.time()
    result = vfs.list("/")
    list_time = time.time() - start
    
    # 测试 3: 多次 list (内存中)
    start = time.time()
    for _ in range(10):
        result = vfs.list("/")
    list_10x = time.time() - start
    
    return {
        "init": init_time,
        "list_first": list_time,
        "list_10x": list_10x,
    }


def benchmark_optimized_vfs(root: Path):
    """测试优化版 VirtualFS"""
    from syncgate.vfs.optimized import CachedVirtualFS
    
    # 测试 1: 初始化时间
    start = time.time()
    vfs = CachedVirtualFS(str(root))
    init_time = time.time() - start
    
    # 测试 2: 首次 list
    start = time.time()
    result = vfs.list("/")
    list_time = time.time() - start
    
    # 测试 3: 多次 list (缓存中)
    start = time.time()
    for _ in range(10):
        result = vfs.list("/")
    list_10x = time.time() - start
    
    return {
        "init": init_time,
        "list_first": list_time,
        "list_10x": list_10x,
    }


def benchmark_streaming_vfs(root: Path):
    """测试流式 VirtualFS"""
    from syncgate.vfs.streaming import StreamingVirtualFS
    
    # 测试 1: 初始化时间
    start = time.time()
    vfs = StreamingVirtualFS(str(root))
    init_time = time.time() - start
    
    # 测试 2: 首次 list
    start = time.time()
    result = vfs.list("/")
    list_time = time.time() - start
    
    # 测试 3: 多次 list (缓存中)
    start = time.time()
    for _ in range(10):
        result = vfs.list("/")
    list_10x = time.time() - start
    
    vfs.stop()
    
    return {
        "init": init_time,
        "list_first": list_time,
        "list_10x": list_10x,
    }


def benchmark_local_fs(root: Path):
    """测试本地文件系统"""
    # 测试 1: 初始化时间 (目录扫描)
    start = time.time()
    entries = list(root.iterdir())
    init_time = time.time() - start
    
    # 测试 2: 首次 list
    start = time.time()
    entries = list(root.iterdir())
    list_time = time.time() - start
    
    # 测试 3: 多次 list
    start = time.time()
    for _ in range(10):
        entries = list(root.iterdir())
    list_10x = time.time() - start
    
    return {
        "init": init_time,
        "list_first": list_time,
        "list_10x": list_10x,
    }


def benchmark_scrolling(root: Path):
    """模拟滚动浏览（分页加载）"""
    from syncgate.vfs.streaming import StreamingVirtualFS
    
    vfs = StreamingVirtualFS(str(root))
    
    # 模拟滚动：加载多个页面
    start = time.time()
    
    page = 0
    while True:
        result = vfs.list("/", page=page)
        if not result.entries:
            break
        page += 1
        if page > 20:  # 最多加载 20 页
            break
    
    scroll_time = time.time() - start
    vfs.stop()
    
    return scroll_time


if __name__ == "__main__":
    print("=" * 60)
    print("SyncGate 性能对比测试")
    print("=" * 60)
    
    # 创建测试环境
    with tempfile.TemporaryDirectory() as tmpdir:
        root = Path(tmpdir) / "test"
        root.mkdir()
        
        # 测试不同规模
        for count in [100, 1000, 5000]:
            print(f"\n{'='*60}")
            print(f"测试规模: {count} 文件")
            print(f"{'='*60}")
            
            # 清理并重新创建
            import shutil
            if root.exists():
                shutil.rmtree(root)
            root.mkdir()
            
            create_test_files(root, count)
            
            # 运行测试
            local = benchmark_local_fs(root)
            original = benchmark_original_vfs(root)
            optimized = benchmark_optimized_vfs(root)
            streaming = benchmark_streaming_vfs(root)
            
            # 滚动测试
            scroll_time = benchmark_scrolling(root)
            
            print(f"\n{'指标':<20} {'本地FS':<12} {'Original':<12} {'Optimized':<12} {'Streaming':<12}")
            print("-" * 70)
            print(f"{'初始化时间':<20} {local['init']*1000:<10.1f}ms {original['init']*1000:<10.1f}ms {optimized['init']*1000:<10.1f}ms {streaming['init']*1000:<10.1f}ms")
            print(f"{'首次 List':<20} {local['list_first']*1000:<10.1f}ms {original['list_first']*1000:<10.1f}ms {optimized['list_first']*1000:<10.1f}ms {streaming['list_first']*1000:<10.1f}ms")
            print(f"{'10x List (缓存)':<20} {local['list_10x']*1000:<10.1f}ms {original['list_10x']*1000:<10.1f}ms {optimized['list_10x']*1000:<10.1f}ms {streaming['list_10x']*1000:<10.1f}ms")
            print(f"{'滚动加载':<20} {'N/A':<12} {'N/A':<12} {'N/A':<12} {scroll_time*1000:<10.1f}ms")
            
            # 计算相对性能
            base = local['list_first']
            print(f"\n相对本地 FS (首次 List):")
            print(f"  Original: {original['list_first']/base:.1f}x")
            print(f"  Optimized: {optimized['list_first']/base:.1f}x")
            print(f"  Streaming: {streaming['list_first']/base:.1f}x")
    
    print("\n" + "=" * 60)
    print("结论:")
    print("=" * 60)
    print("""
1. StreamingVirtualFS 特点:
   - 初始化极快 (不扫描全量)
   - 首屏快速加载
   - 支持无限大目录
   - 内存占用可控

2. 与本地 FS 的差距:
   - 需要解析 .link JSON 文件
   - 后端访问有网络延迟
   - 但 .link 管理体验接近原生

3. 建议场景:
   - 小目录 (100-1000): 使用 Optimized 或 Streaming
   - 大目录 (1000+): 强烈推荐 Streaming
   - 需要极致性能: 使用 Optimized (全量缓存)
""")
