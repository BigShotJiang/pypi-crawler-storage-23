# SyncGate 发布清单

## 发布状态

| 平台 | 状态 | 说明 |
|------|------|------|
| GitHub | ⏳ 待手动 | 需要 gh auth login |
| PyPI | ⏳ 待手动 | 需要 API token |
| TestPyPI | ✅ 已构建 | dist/ 目录 |

---

## 手动发布步骤

### 1. GitHub 发布

```bash
cd /Users/chenyanyu/.openclaw/workspace/syncgate

# 登录 GitHub
gh auth login

# 创建并推送仓库
gh repo create syncgate --public \
  --description "Lightweight multi-storage routing and sync abstraction layer" \
  --source=. --push
```

### 2. PyPI 发布

#### 方式 A: 使用 API Token (推荐)

1. 在 https://pypi.org/manage/account/ 创建 API token
2. 创建 `~/.pypirc` 文件:

```
[pypi]
username = __token__
password = pypi-xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
```

3. 发布:

```bash
twine upload dist/*
```

#### 方式 B: 使用 GitHub Actions (自动化)

1. 在 GitHub Settings > Secrets 添加 `PYPI_API_TOKEN`
2. GitHub Actions 会自动发布到 PyPI

---

## 发布后营销

### 2.1 技术社区

- [ ] Hacker News: https://news.ycombinator.com/submit
- [ ] Reddit: r/programming, r/python, r/devtools
- [ ] Lobsters: https://lobste.rs/submit

### 2.2 社交媒体

- [ ] Twitter/X: @ ReleaseYourEye
- [ ] LinkedIn

### 2.3 技术博客

- [ ] 撰写博客: "SyncGate: 轻量级多存储路由抽象层"
- [ ] Dev.to: https://dev.to/new
- [ ] Medium

### 2.4 开发者社区

- [ ] Product Hunt: https://www.producthunt.com/post
- [ ] Indie Hackers: https://www.indiehackers.com/post
- [ ] Hacker News Launch: https://launch.news

---

## 验证指标 (发布后 24h)

- [ ] GitHub ⭐ ≥ 10
- [ ] PyPI 下载 ≥ 50
- [ ] GitHub Issues ≥ 2

---

## 发布版本历史

| 版本 | 日期 | 说明 |
|------|------|------|
| 0.1.0 | 2025-01-20 | MVP 发布 |

---

*清单创建时间: 2025-01-20*
