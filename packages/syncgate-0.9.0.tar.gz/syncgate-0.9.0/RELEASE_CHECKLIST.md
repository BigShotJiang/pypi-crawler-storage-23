# SyncGate 发布清单

## 发布前检查

- [ ] 所有测试通过
- [ ] 代码已格式化 (black)
- [ ] 类型检查通过 (mypy)
- [ ] CHANGELOG.md 已更新
- [ ] 版本号正确 (pyproject.toml)

## GitHub 发布

### 选项 1: 使用 GitHub CLI

```bash
# 安装
brew install gh

# 登录
gh auth login

# 创建仓库并推送
cd syncgate
gh repo create syncgate --public --description "Lightweight multi-storage routing and sync abstraction layer" --source=. --push
```

### 选项 2: 手动创建

1. 打开 https://github.com/new
2. Repository name: `syncgate`
3. Description: "Lightweight multi-storage routing and sync abstraction layer"
4. Public: ✅
5. Add a README: ❌ (我们已经有了)
6. 点击 "Create repository"
7. 推送代码:

```bash
cd syncgate
git remote add origin https://github.com/YOUR_USERNAME/syncgate.git
git branch -M main
git push -u origin main
```

## PyPI 发布

### 准备

```bash
# 安装 build
pip install build

# 构建包
python -m build
```

### 发布

#### 选项 1: 使用 Twine

```bash
# 安装 twine
pip install twine

# 上传到 Test PyPI (测试)
twine upload --repository testpypi dist/*

# 上传到正式 PyPI
twine upload dist/*
```

#### 选项 2: 使用 GitHub Actions (推荐)

1. 在 GitHub 仓库 Settings > Secrets 中添加 `PYPI_API_TOKEN`
2. CI/CD 会自动发布到 PyPI (main 分支推送时)

## 发布后

- [ ] 创建 GitHub Release
- [ ] 验证 pip install syncgate 正常
- [ ] 监控 GitHub Issues
- [ ] 回复用户反馈

## 营销

- [ ] 提交到 Product Hunt
- [ ] 发布到 Reddit (r/python, r/devtools)
- [ ] Tweet/X 推广
- [ ] 联系技术博主
- [ ] 发布到 Hacker News

---

## 快速命令

```bash
# 发布到 GitHub
gh repo create syncgate --public --description "Lightweight multi-storage routing and sync abstraction layer" --source=. --push

# 发布到 PyPI (需要 TOKEN)
twine upload dist/*
```
