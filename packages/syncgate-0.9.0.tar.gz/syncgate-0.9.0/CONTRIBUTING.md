# Contributing to SyncGate

Thank you for your interest in contributing to SyncGate! This document outlines the process for contributing.

## Getting Started

### Prerequisites

- Python 3.10+
- pip or poetry

### Setting Up Development Environment

```bash
# Clone the repository
git clone https://github.com/yourusername/syncgate.git
cd syncgate

# Install in development mode
pip install -e ".[dev]"

# Run tests
pytest tests/
```

### Code Style

We use:
- **Black** for code formatting
- **mypy** for type checking
- **pytest** for testing

```bash
# Format code
black syncgate/ tests/

# Type check
mypy syncgate/

# Run tests with coverage
pytest --cov=syncgate tests/
```

## Submitting Changes

### 1. Fork the Repository

Fork the repository on GitHub and clone your fork.

### 2. Create a Feature Branch

```bash
git checkout -b feature/your-feature-name
```

### 3. Make Changes

- Write clean, documented code
- Add tests for new functionality
- Run the full test suite

### 4. Submit a Pull Request

- Describe your changes
- Link any related issues
- Ensure CI passes

## Issue Reporting

### Bug Reports

When reporting bugs, include:
- Steps to reproduce
- Expected behavior
- Actual behavior
- Python version
- Operating system

### Feature Requests

When requesting features, include:
- Use case description
- Proposed solution
- Any relevant examples

## Code of Conduct

This project follows the [Contributor Covenant](https://www.contributor-covenant.org/).

## Questions?

Open an issue for discussion.
