# CHANGELOG

## [0.9.0] - 2025-01-20

### Added

- **功能迭代** - Cycle #46-47
  - `syncgate/config.py` - 配置管理模块 (11 个测试)
  - `syncgate/error_handler_v2.py` - 错误处理模块 (24 个测试)

### Changed

- 版本号更新至 0.9.0
- 测试覆盖: 100+ 测试全部通过

### Fixed

- `test_webhook.py` - 修复 URL 验证测试

---

## [0.8.5] - 2025-01-20

### Changed

- **README 更新** - 反映当前状态
  - 添加测试覆盖率和功能模块信息
  - 更新支持的存储列表 (6 个后端)
  - 添加高级功能说明
  - 添加性能数据

---

## [0.8.4] - 2025-01-20

### Added

- **推广执行** - Cycle #43
  - `promote.py` - 一键推广脚本
  - 打开 Hacker News, Twitter, Reddit 推广页面
  - 提供预填推广内容

---

## [0.8.3] - 2025-01-20

### Fixed

- **使用 GitHub Issues 替代虚构邮箱**
  - 移除 feedback@synclist.ai, feedback@syncgate.ai
  - 改为: https://github.com/cyydark/syncgate/issues
  - 更新 feedback-form.md, KANBAN.md, video-script.md, DEMO_README.md

---

## [0.8.2] - 2025-01-20

### Fixed

- **项目名称统一** - synclist → syncgate
  - pyproject.toml: name = "syncgate", version = "0.8.1"
  - 更新所有文档中的安装命令
  - 移除虚构邮箱，改用 GitHub Issues
  - 重写 KANBAN.md, video-script.md, feedback-form.md

### Changed

- 所有文档: `pip install synclist` → `pip install syncgate`
- 反馈渠道: 邮箱 → GitHub Issues

---

## [0.8.1] - 2025-01-20

### Added

- **文档完善** - Cycle #38
  - `USAGE.md` - 完整使用指南
  - `QUICK_START.md` - 5 分钟快速开始

### Documentation

| 文档 | 说明 |
|------|------|
| README.md | 项目介绍 |
| QUICK_START.md | **5 分钟快速开始** |
| USAGE.md | **完整使用指南** |
| PROJECT.md | 架构设计 |

---

## [0.8.0] - 2025-01-20

### Added

- **功能补齐** - Cycle #37
  - `syncgate/batch.py` - 批量操作
  - `syncgate/monitor.py` - 监控和统计
  - `syncgate/error_handler.py` - 错误处理和重试
  - `tests/test_batch.py` - 7 个测试
  - `tests/test_monitor.py` - 12 个测试

### 新功能

| 模块 | 功能 |
|------|------|
| Batch | 批量创建/删除/验证链接 |
| Batch | 导入/导出配置 |
| Monitor | 统计收集和健康评分 |
| Monitor | 性能监控 |
| Error | 重试机制 |
| Error | 熔断器 |
| Error | 错误日志 |

---

## [0.7.0] - 2025-01-20

### Added

- **Webhook 通知** - 支持外部通知
  - `syncgate/webhook.py` - Webhook 管理器
  - `tests/test_webhook.py` - 10 个测试

### Webhook 功能

| 功能 | 说明 |
|------|------|
| 事件通知 | link.created, link.deleted, validate |
| 多 webhook | 支持多个通知端点 |
| 事件过滤 | 只订阅需要的事件 |

---

## [0.6.1] - 2025-01-20

### Added

- **推广执行** - Cycle #35
  - `promote.sh.py` - 一键推广脚本
  - `HN_SUBMISSION_V2.md` - HN 提交内容

### Changed

- 执行推广计划

---

## [0.6.0] - 2025-01-20

### Added

- **REST API Server** - 支持程序化访问
  - `syncgate/api.py` - REST API 服务器
  - `tests/test_api.py` - 6 个 API 测试
  - 支持 CRUD 操作 (创建/读取/更新/删除链接)

### API 端点

| 方法 | 端点 | 说明 |
|------|------|------|
| GET | /api/stats | 获取统计 |
| GET | /api/links/<path> | 获取链接信息 |
| POST | /api/links | 创建链接 |
| DELETE | /api/links/<path> | 删除链接 |

### 运行 API

```bash
python -m syncgate.api --port 8080
```

---

## [0.5.0] - 2025-01-20

### Added

- **CLI Enhancement** - 增强命令行工具
  - `syncgate/utils.py` - 配置管理和日志工具
  - Config 类 - 配置文件管理
  - ProgressBar 类 - 进度条
  - Logger 类 - 彩色日志输出
  - config 命令 - 管理配置

### Changed

- CLI 支持新的 config 子命令

---

## [0.4.0] - 2025-01-20

### Added

- **FTP Backend** - 支持 FTP 服务器
  - `syncgate/backend/ftp.py` - FTP 后端实现
  - `tests/test_ftp.py` - 5 个测试

- **SFTP Backend** - 支持 SFTP 服务器
  - `syncgate/backend/sftp.py` - SFTP 后端实现
  - 依赖: paramiko>=3.0.0

### Changed

- **Total Tests: 33** (新增 5 个 FTP 测试)

---

## [0.3.0] - 2025-01-20

### Added

- **WebDAV Backend** - 支持 NAS/云存储
  - `syncgate/backend/webdav.py` - WebDAV 后端实现
  - `tests/test_webdav.py` - 6 个测试
  - 支持 PROPFIND/PUT/HEAD/MKCOL 等 WebDAV 方法

### Changed

- **Total Tests: 28** (新增 6 个 WebDAV 测试)
- 修复 pyproject.toml 重复配置

---

## [0.2.4] - 2025-01-20

### Changed

- **推广执行** - Cycle #30
  - Twitter 推广准备就绪
  - Hacker News 提交准备就绪
  - Reddit 发布准备就绪

### 推广状态

| 渠道 | 状态 |
|------|------|
| Twitter | ✅ 推文已准备 |
| Hacker News | ✅ 提交内容已准备 |
| Reddit | ✅ 帖子已准备 |

---

## [0.2.3] - 2025-01-20

### Changed

- **CI/CD 优化**
  - 添加 coverage 配置 (pyproject.toml)
  - 优化工作流 (notify job)
  - 支持多 Python 版本 (3.10, 3.11, 3.12)
  - 添加 codecov 集成

### CI/CD Features

| 功能 | 状态 |
|------|------|
| 多版本测试 | ✅ 3.10, 3.11, 3.12 |
| Lint (black/mypy) | ✅ |
| Coverage | ✅ |
| Auto PyPI Publish | ✅ |
| Notifications | ✅ |

---

## [0.2.2] - 2025-01-20

### Added

- **AI Module Tests** - 9 new tests for AI functionality
  - test_simple_embedding
  - test_embedding_vector
  - test_ai_module_init
  - test_extract_metadata
  - test_index_content
  - test_search
  - test_cosine_similarity
  - test_get_metadata
  - test_list_indexed

### Changed

- **Total Tests: 22 passing** (9 new + 13 existing)

---

## [0.2.1] - 2025-01-20

### Changed

- **代码重构** - 提取 BaseBackend 基类
- **代码减少 25%** - 437 行 → 327 行
- **减少重复代码** - 数据库操作集中到 BaseBackend

### Optimization

| 文件 | 优化前 | 优化后 | 减少 |
|------|--------|--------|------|
| local.py | 135 行 | 70 行 | 48% |
| http.py | 125 行 | 67 行 | 46% |
| s3.py | 177 行 | 119 行 | 33% |
| base.py | - | 71 行 | - |
| **总计** | **437 行** | **327 行** | **25%** |

---

## [0.2.0] - 2025-01-20

### Added

- **AI Module** - 元数据管理和语义搜索
  - `syncgate/ai/__init__.py` - AI 模块核心
  - `ai_demo.py` - 演示脚本
  - 元数据提取 (大小、字数、编码)
  - 简单向量嵌入 (词袋模型)
  - 语义搜索 (余弦相似度)

### Changed

- 代码提交统计: 6 次提交 (Cycle #22-26)

---

## [0.1.4] - 2025-01-20

### Added

- **PROMO.md** - 推广文案 (Twitter/HN/Reddit)
- **DEMO_OUTPUT.md** - 演示输出截图
- **README.md v2** - 优化后的项目介绍

### Changed

- README: SyncList → SyncGate
- README: 添加支持存储类型表格
- README: 添加使用示例

---

## [0.1.2] - 2025-01-20

### Added

- **demo_complete.py** - Complete demo with all backends
- **S3Backend 测试** - Verified S3 URL parsing works
- **多后端演示** - Local + HTTP + S3

### Verified

- ✅ LocalBackend - 本地存储
- ✅ HTTPBackend - HTTP/HTTPS
- ✅ S3Backend - AWS S3

---

## [0.1.1] - 2025-01-20

### Added

- **demo_v2.py** - New complete demo script
- **演示验证** - Core functionality verified working

### Fixed

- Demo script parameter order
- LocalBackend initialization

---

## [0.1.0] - 2025-01-20

### Added

- Initial release
- VirtualFS core with memory index
- Local backend (local filesystem)
- HTTP backend (HTTP/HTTPS read-only)
- S3 backend (AWS S3)
- Gateway with CLI commands:
  - `ls` - List directory contents
  - `tree` - Display tree structure
  - `link` - Create a link
  - `unlink` - Remove a link
  - `validate` - Validate links
  - `status` - Show link status

### Features

- Memory index for O(1) directory listing
- Link validation with status tracking
- SQLite-based status storage
- Support for multiple storage backends

### Documentation

- README with quick start guide
- PROJECT.md with architecture design
- CLI help documentation

### Tests

- 13 passing tests
- VirtualFS tests
- Backend tests
- Gateway tests
