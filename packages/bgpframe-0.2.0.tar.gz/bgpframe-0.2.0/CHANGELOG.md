# Changelog

## [0.2.0](https://github.com/taeyun16/bgpframe/compare/v0.1.0...v0.2.0) (2026-02-28)


### Features

* add CI/CD workflows for testing and PyPI publishing ([6479382](https://github.com/taeyun16/bgpframe/commit/6479382eac4b07719a80219bc737f41e54ac6b97))
* enhance BGP filtering capabilities and update documentation ([57207ea](https://github.com/taeyun16/bgpframe/commit/57207eafad21abbe35bfb9302a55a6b2628baf6e))
