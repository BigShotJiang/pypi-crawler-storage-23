import unittest

from tibase.core.rootcontext import EnvConfig


class TestEnvConfig(unittest.TestCase):

    def test_basic_getters(self):
        data = {
            'A': '1',
            'B': 'true',
            'C': '3.14',
            'D': 'x,y, z ',
            'E': '10|20|30',
            'F': 'no',
            'G': 'oops',
            'H': '1,,2',
        }
        env = EnvConfig(data)
        self.assertEqual(env.get('A'), '1')
        self.assertEqual(env.get('MISSING', 'x'), 'x')
        self.assertTrue(env.get_bool('B'))
        self.assertFalse(env.get_bool('F'))
        self.assertEqual(env.get_bool('G', default=True), True)
        self.assertFalse(env.get_bool('MISSING', default=False))
        self.assertEqual(env.get_int('A'), 1)
        self.assertEqual(env.get_int('G', default=7, strict=False), 7)
        self.assertEqual(env.get_float('C'), 3.14)
        self.assertEqual(env.get_float('G', default=1.5, strict=False), 1.5)
        self.assertEqual(env.get_list('D'), ['x', 'y', 'z'])
        self.assertEqual(env.get_list('E', item_type=int, sep='|'), [10, 20, 30])
        self.assertEqual(env.get_list('H'), ['1', '2'])

    def test_mapping_protocols(self):
        data = {'K': 'v'}
        env = EnvConfig(data)
        self.assertEqual(env['K'], 'v')
        self.assertTrue('K' in env)
        self.assertEqual(list(env.items()), [('K', 'v')])


if __name__ == '__main__':
    unittest.main()
