from setuptools import setup, find_packages, find_namespace_packages

setup(
    name = 'cpbox',
    version = '1.6.813',
    keywords = ('cpbox'),
    description = 'cp tool box',
    license = '',
    install_requires = [
        'psutil',
        'ruamel.yaml==0.18.5',
        'Jinja2',
        'requests',
        'redis',
        'oss2',
        'python-dotenv',
        ],

    scripts = [],

    author = 'https://www.liaohuqiu.com',
    author_email = 'liaohuqiu@gmail.com',
    url = '',

    packages = find_packages() + find_namespace_packages(include=['tibase*']),
    platforms = 'any',
)
