from datetime import datetime

def local_now():
    return datetime.now().astimezone()

def local_now_ios8061_str():
    return local_now().strftime('%Y-%m-%dT%H:%M:%S%z')
