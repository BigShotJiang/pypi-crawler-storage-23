"""Reporting commands (e.g. CFO report) built on top of exported/indexed data."""
