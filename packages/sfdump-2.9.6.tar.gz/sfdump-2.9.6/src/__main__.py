"""Convenience wrapper for domfin to run directly from source tree"""

from sfdump.cli import cli

if __name__ == "__main__":
    cli()
