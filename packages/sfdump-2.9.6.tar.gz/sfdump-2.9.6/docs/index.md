# sfdump Documentation

Welcome to the sfdump documentation.

```{toctree}
:maxdepth: 2

user-guide/index
admin-guide/index
developer-guide/index
admin-finance/index
reference/index
```
