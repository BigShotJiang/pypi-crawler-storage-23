# CFO Detailed Audit Report

This chapter is automatically generated from the latest sfdump CFO extraction run.

To regenerate this report:

```
sfdump cfo-generate-docs --export-dir <dir> --redact
```

---

## Generated Report

```{include} ../_generated/cfo/cfo_report_body.md
```
