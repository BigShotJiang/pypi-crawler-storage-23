#from .common import global_tight_sip3d
import numpy as np
import awkward as ak

def tag_tau_quality(tau, is_UL=False):  # use on raw Electron collection (Awkward array)
    
    """
    Add 'isGold', 'isSilver', 'isBronze' boolean field to events.Electron based on cuts.
    """

    # define variables
    abs_eta   = np.abs(tau.eta)
    abs_dxy   = np.abs(tau.dxy)
    abs_dz    = np.abs(tau.dz)
    pt        = tau.pt
    iso03pt   = tau.pfRelIso03_all * pt
    miniIsoPt = tau.miniPFRelIso_all * pt

    # --- Baseline selection ---
    baseline_mask = (
        (pt >= 7)
        & ( ((pt >= 10) & (abs_eta < 2.5)) | ((pt < 10) & (abs_eta < 1.442)) )
        & (tau.sip3d < 6)
        & (abs_dxy < 0.05)
        & (abs_dz  < 0.1)
    )

    # --- Quality tags ---

    gold_silver_mask = None
    
    gold_mask = None

    silver_mask = None

    bronze_mask = None
    
    # Add quality masks
    #tau = ak.with_field(tau, ~baseline_mask, 'isFail')
    #tau = ak.with_field(tau, baseline_mask, 'isBaseline')
    #tau = ak.with_field(tau, gold_mask, 'isGold')
    #tau = ak.with_field(tau, silver_mask, 'isSilver')
    #tau = ak.with_field(tau, bronze_mask, 'isBronze')

    
    #if is_UL:
        #ID_mask = ak.where(pt >= 20, tau.mvaFall17V2Iso_WP90, tight_minus_iso_hoe(tau))
    #else:
        #ID_mask = ak.where(pt >= 20, tau.mvaIso_WP90, tight_minus_iso_hoe(tau))
    
    #tight_ID = baseline_mask & ID_mask
    
    #tight_SIP3D = baseline_mask & (tau.sip3d < global_tight_sip3d)
    
    #tight_ISO = baseline_mask & (miniIsoPt <= 4) & (iso03pt <= 4)
    
    #tau = ak.with_field(tau, tight_ID, 'tight_ID')
    #tau = ak.with_field(tau, tight_SIP3D, 'tight_SIP3D')
    #tau = ak.with_field(tau, tight_ISO, 'tight_ISO')

    return tau