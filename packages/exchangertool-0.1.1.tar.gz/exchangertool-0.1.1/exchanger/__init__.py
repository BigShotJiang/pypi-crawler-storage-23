"""exchanger - minimal file send/receive over HTTP or SMB."""

__version__ = "0.1.0"
