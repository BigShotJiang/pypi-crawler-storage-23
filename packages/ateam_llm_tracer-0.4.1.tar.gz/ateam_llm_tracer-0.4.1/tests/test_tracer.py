"""Tests for tracer module."""

from unittest.mock import MagicMock, patch

from ateam_llm_tracer.span_kinds import SpanKind
from ateam_llm_tracer.tracer import Tracer


@patch("ateam_llm_tracer.tracer.trace")
def test_tracer_initialization(mock_trace):
    """Test tracer initialization."""
    tracer = Tracer(task="test-task", workspace_id="test-workspace")
    assert tracer._task == "test-task"
    assert tracer._workspace_id == "test-workspace"
    mock_trace.get_tracer.assert_called_once()


@patch("ateam_llm_tracer.tracer.trace")
def test_start_llm_span(mock_trace):
    """Test starting an LLM span."""
    mock_span = MagicMock()
    mock_tracer = MagicMock()
    mock_tracer.start_span.return_value = mock_span
    mock_trace.get_tracer.return_value = mock_tracer

    tracer = Tracer(task="test-task")
    with tracer.start_llm_span("test-llm-op") as enhanced_span:
        assert enhanced_span._span_kind == SpanKind.LLM
        mock_tracer.start_span.assert_called_once_with("test-llm-op")


@patch("ateam_llm_tracer.tracer.trace")
def test_start_agent_span(mock_trace):
    """Test starting an agent span."""
    mock_span = MagicMock()
    mock_tracer = MagicMock()
    mock_tracer.start_span.return_value = mock_span
    mock_trace.get_tracer.return_value = mock_tracer

    tracer = Tracer(task="test-task")
    with tracer.start_agent_span("test-agent-op") as enhanced_span:
        assert enhanced_span._span_kind == SpanKind.AGENT


@patch("ateam_llm_tracer.tracer.trace")
def test_start_tool_span(mock_trace):
    """Test starting a tool span."""
    mock_span = MagicMock()
    mock_span.set_attribute = MagicMock()
    mock_tracer = MagicMock()
    mock_tracer.start_span.return_value = mock_span
    mock_trace.get_tracer.return_value = mock_tracer

    tracer = Tracer(task="test-task")
    with tracer.start_tool_span("test-tool-op", tool_name="test-tool") as enhanced_span:
        assert enhanced_span._span_kind == SpanKind.TOOL


@patch("ateam_llm_tracer.tracer.trace")
def test_start_chain_span(mock_trace):
    """Test starting a chain span."""
    mock_span = MagicMock()
    mock_tracer = MagicMock()
    mock_tracer.start_span.return_value = mock_span
    mock_trace.get_tracer.return_value = mock_tracer

    tracer = Tracer(task="test-task")
    with tracer.start_chain_span("test-chain-op") as enhanced_span:
        assert enhanced_span._span_kind == SpanKind.CHAIN


@patch("ateam_llm_tracer.tracer.trace")
def test_start_retriever_span(mock_trace):
    """Test starting a retriever span."""
    mock_span = MagicMock()
    mock_tracer = MagicMock()
    mock_tracer.start_span.return_value = mock_span
    mock_trace.get_tracer.return_value = mock_tracer

    tracer = Tracer(task="test-task")
    with tracer.start_retriever_span("test-retriever-op") as enhanced_span:
        assert enhanced_span._span_kind == SpanKind.RETRIEVER


@patch("ateam_llm_tracer.tracer.trace")
def test_task_attribute_set(mock_trace):
    """Test that task attribute is set on spans."""
    mock_span = MagicMock()
    mock_span.set_attribute = MagicMock()
    mock_tracer = MagicMock()
    mock_tracer.start_span.return_value = mock_span
    mock_trace.get_tracer.return_value = mock_tracer

    tracer = Tracer(task="test-task", workspace_id="test-workspace")
    with tracer.start_llm_span("test-op"):
        # Check that task and workspace_id were set
        calls = mock_span.set_attribute.call_args_list
        assert any(call[0][0] == "task" and call[0][1] == "test-task" for call in calls)
        assert any(
            call[0][0] == "workspace_id" and call[0][1] == "test-workspace" for call in calls
        )
