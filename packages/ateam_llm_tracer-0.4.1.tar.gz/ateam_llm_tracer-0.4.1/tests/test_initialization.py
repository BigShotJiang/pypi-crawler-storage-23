"""Tests for initialization module."""

from unittest.mock import MagicMock, patch

import pytest

from ateam_llm_tracer.initialization import force_flush, init_tracing


@pytest.fixture(autouse=True)
def reset_tracing_state():
    """Reset global tracing state before each test."""
    import ateam_llm_tracer.initialization as init_module
    init_module._initialized = False
    init_module._tracer_provider = None
    init_module._project_name = None
    yield
    # Cleanup after test
    init_module._initialized = False
    init_module._tracer_provider = None
    init_module._project_name = None


@patch("ateam_llm_tracer.initialization.TracerProvider")
@patch("ateam_llm_tracer.initialization.OTLPSpanExporter")
@patch("ateam_llm_tracer.initialization.BatchSpanProcessor")
@patch("ateam_llm_tracer.initialization.trace")
@patch("ateam_llm_tracer.initialization.OpenAIInstrumentor")
def test_force_flush_success(
    _mock_openai_instrumentor, _mock_trace, _mock_processor, _mock_exporter, mock_provider_class
):
    """Test force_flush successfully flushes traces."""
    # Setup mocks
    mock_provider = MagicMock()
    mock_provider.force_flush.return_value = True
    mock_provider_class.return_value = mock_provider

    # Initialize tracing
    init_tracing(
        project_name="test-project",
        service_name="test-service",
        phoenix_endpoint="http://localhost:6006"
    )

    # Test force_flush
    result = force_flush(timeout_millis=5000)

    assert result is True
    mock_provider.force_flush.assert_called_once_with(timeout_millis=5000)


@patch("ateam_llm_tracer.initialization.TracerProvider")
@patch("ateam_llm_tracer.initialization.OTLPSpanExporter")
@patch("ateam_llm_tracer.initialization.BatchSpanProcessor")
@patch("ateam_llm_tracer.initialization.trace")
@patch("ateam_llm_tracer.initialization.OpenAIInstrumentor")
def test_force_flush_timeout(
    _mock_openai_instrumentor, _mock_trace, _mock_processor, _mock_exporter, mock_provider_class
):
    """Test force_flush when flush times out."""
    # Setup mocks
    mock_provider = MagicMock()
    mock_provider.force_flush.return_value = False
    mock_provider_class.return_value = mock_provider

    # Initialize tracing
    init_tracing(
        project_name="test-project",
        service_name="test-service",
        phoenix_endpoint="http://localhost:6006"
    )

    # Test force_flush
    result = force_flush(timeout_millis=1000)

    assert result is False
    mock_provider.force_flush.assert_called_once_with(timeout_millis=1000)


def test_force_flush_not_initialized():
    """Test force_flush when tracing is not initialized."""
    result = force_flush()

    assert result is False


@patch("ateam_llm_tracer.initialization.TracerProvider")
@patch("ateam_llm_tracer.initialization.OTLPSpanExporter")
@patch("ateam_llm_tracer.initialization.BatchSpanProcessor")
@patch("ateam_llm_tracer.initialization.trace")
@patch("ateam_llm_tracer.initialization.OpenAIInstrumentor")
def test_force_flush_exception(
    _mock_openai_instrumentor, _mock_trace, _mock_processor, _mock_exporter, mock_provider_class
):
    """Test force_flush handles exceptions gracefully."""
    # Setup mocks
    mock_provider = MagicMock()
    mock_provider.force_flush.side_effect = Exception("Flush failed")
    mock_provider_class.return_value = mock_provider

    # Initialize tracing
    init_tracing(
        project_name="test-project",
        service_name="test-service",
        phoenix_endpoint="http://localhost:6006"
    )

    # Test force_flush
    result = force_flush()

    assert result is False


@patch("ateam_llm_tracer.initialization.TracerProvider")
@patch("ateam_llm_tracer.initialization.OTLPSpanExporter")
@patch("ateam_llm_tracer.initialization.BatchSpanProcessor")
@patch("ateam_llm_tracer.initialization.trace")
@patch("ateam_llm_tracer.initialization.OpenAIInstrumentor")
def test_force_flush_custom_timeout(
    _mock_openai_instrumentor, _mock_trace, _mock_processor, _mock_exporter, mock_provider_class
):
    """Test force_flush with custom timeout."""
    # Setup mocks
    mock_provider = MagicMock()
    mock_provider.force_flush.return_value = True
    mock_provider_class.return_value = mock_provider

    # Initialize tracing
    init_tracing(
        project_name="test-project",
        service_name="test-service",
        phoenix_endpoint="http://localhost:6006"
    )

    # Test force_flush with custom timeout
    result = force_flush(timeout_millis=10000)

    assert result is True
    mock_provider.force_flush.assert_called_once_with(timeout_millis=10000)
