"""Configuration management for tracing."""

import os

from pydantic import BaseModel, Field, field_validator, model_validator


class TracingConfig(BaseModel):
    """Configuration for tracing initialization.

    Uses Pydantic for validation and type safety.
    """

    enabled: bool = Field(default=True, description="Master on/off switch for tracing")
    phoenix_endpoint: str | None = Field(default=None, description="Phoenix collector URL")
    service_name: str | None = Field(default=None, description="Service name for tracing")
    phoenix_api_key: str | None = Field(
        default=None,
        description="Optional API key for Phoenix authentication",
    )
    sample_rate: float = Field(
        default=1.0,
        description="Sampling rate between 0.0 and 1.0",
    )

    @field_validator("sample_rate")
    @classmethod
    def clamp_sample_rate(cls, v: float) -> float:
        """Clamp sample rate to valid range."""
        return max(0.0, min(1.0, v))

    @model_validator(mode="after")
    def validate_enabled_requirements(self) -> "TracingConfig":
        """Validate that required fields are present when tracing is enabled."""
        if self.enabled:
            if not self.phoenix_endpoint:
                raise ValueError(
                    "phoenix_endpoint is required when tracing is enabled. "
                    "Set CONTROL_ROOM_TRACING_ENDPOINT environment variable or "
                    "provide phoenix_endpoint parameter."
                )

            if not self.service_name:
                raise ValueError(
                    "service_name is required when tracing is enabled. "
                    "Set CONTROL_ROOM_TRACING_SERVICE environment variable or "
                    "provide service_name parameter."
                )
        return self

    @classmethod
    def from_env(cls) -> "TracingConfig":
        """Create configuration from environment variables.

        Environment variables:
            CONTROL_ROOM_TRACING_ENABLED: Master on/off switch (default: true)
            CONTROL_ROOM_TRACING_ENDPOINT: Phoenix collector URL
            CONTROL_ROOM_TRACING_SERVICE: Service name
            CONTROL_ROOM_TRACING_API_KEY: Phoenix API key for authentication
            CONTROL_ROOM_TRACING_SAMPLE_RATE: Sampling rate 0.0-1.0 (default: 1.0)

        Returns:
            TracingConfig instance populated from environment
        """
        enabled_str = os.getenv("CONTROL_ROOM_TRACING_ENABLED", "true").lower()
        enabled = enabled_str in ("true", "1", "yes", "on")

        sample_rate_str = os.getenv("CONTROL_ROOM_TRACING_SAMPLE_RATE", "1.0")
        try:
            sample_rate = float(sample_rate_str)
        except ValueError:
            sample_rate = 1.0

        phoenix_endpoint = os.getenv("CONTROL_ROOM_TRACING_ENDPOINT")
        service_name = os.getenv("CONTROL_ROOM_TRACING_SERVICE")
        phoenix_api_key = os.getenv("CONTROL_ROOM_TRACING_API_KEY")

        return cls.model_construct(
            enabled=enabled,
            phoenix_endpoint=phoenix_endpoint,
            service_name=service_name,
            phoenix_api_key=phoenix_api_key,
            sample_rate=sample_rate,
        )
