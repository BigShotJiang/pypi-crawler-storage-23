"""Tracer module for creating and managing spans."""

from typing import Any

from opentelemetry import trace

from .span import EnhancedSpan
from .span_kinds import SpanKind


class Tracer:
    """Factory for creating spans, scoped to a task."""

    def __init__(
        self,
        task: str | None = None,
        workspace_id: str | None = None,
        **kwargs: Any,
    ) -> None:
        """Initialize the tracer.

        Args:
            task: Task name (e.g., "nl-to-sql")
            workspace_id: Workspace identifier
            **kwargs: Additional attributes to apply to all spans
        """
        self._task = task
        self._workspace_id = workspace_id
        self._default_attributes = kwargs
        self._tracer = trace.get_tracer(__name__)

    def _apply_defaults(self, span: EnhancedSpan) -> None:
        """Apply default attributes to a span."""
        if self._task:
            span._span.set_attribute("task", self._task)
        if self._workspace_id:
            span._span.set_attribute("workspace_id", self._workspace_id)

        for key, value in self._default_attributes.items():
            span._span.set_attribute(key, str(value))

    def start_span(
        self,
        kind: SpanKind,
        operation_name: str,
        **kwargs: Any,
    ) -> EnhancedSpan:
        """Start a generic span.

        Args:
            kind: The kind of span to create
            operation_name: Name of the operation
            **kwargs: Additional attributes to set on the span

        Returns:
            EnhancedSpan: The created span
        """
        otel_span = self._tracer.start_span(operation_name)
        enhanced_span = EnhancedSpan(otel_span, kind, operation_name)
        self._apply_defaults(enhanced_span)

        for key, value in kwargs.items():
            enhanced_span._span.set_attribute(key, str(value))

        return enhanced_span

    def start_agent_span(
        self,
        operation_name: str,
        agent_id: str | None = None,
        workflow_id: str | None = None,
        workflow_instance_id: str | None = None,
        report_id: str | None = None,
        **kwargs: Any,
    ) -> EnhancedSpan:
        """Create a parent span for agentic task execution.

        Args:
            operation_name: Name of the agent operation
            agent_id: Identifier for the agent
            workflow_id: Identifier for the workflow template
            workflow_instance_id: Identifier for this specific workflow instance
            report_id: Identifier for the report/artifact being generated
            **kwargs: Additional attributes to set on the span

        Returns:
            EnhancedSpan: The parent span for this agent execution
        """
        span = self.start_span(SpanKind.AGENT, operation_name, **kwargs)
        if agent_id:
            span._span.set_attribute("agent.id", agent_id)
        if workflow_id:
            span._span.set_attribute("workflow.id", workflow_id)
        if workflow_instance_id:
            span._span.set_attribute("workflow.instance_id", workflow_instance_id)
        if report_id:
            span._span.set_attribute("report.id", report_id)
        return span

    def start_llm_span(
        self,
        operation_name: str,
        agent_id: str | None = None,
        **kwargs: Any,
    ) -> EnhancedSpan:
        """Start an LLM call span.

        Args:
            operation_name: Name of the LLM operation
            agent_id: Optional agent identifier
            **kwargs: Additional attributes to set on the span

        Returns:
            EnhancedSpan: The LLM span
        """
        span = self.start_span(SpanKind.LLM, operation_name, **kwargs)
        if agent_id:
            span._span.set_attribute("agent.id", agent_id)
        return span

    def start_tool_span(
        self,
        operation_name: str,
        tool_name: str | None = None,
        agent_id: str | None = None,
        **kwargs: Any,
    ) -> EnhancedSpan:
        """Start a tool call span.

        Args:
            operation_name: Name of the tool operation
            tool_name: Name of the tool being called
            agent_id: Optional agent identifier
            **kwargs: Additional attributes to set on the span

        Returns:
            EnhancedSpan: The tool span
        """
        span = self.start_span(SpanKind.TOOL, operation_name, **kwargs)
        if tool_name:
            span.set_tool_name(tool_name)
        if agent_id:
            span._span.set_attribute("agent.id", agent_id)
        return span

    def start_retriever_span(
        self,
        operation_name: str,
        agent_id: str | None = None,
        **kwargs: Any,
    ) -> EnhancedSpan:
        """Start a retrieval span.

        Args:
            operation_name: Name of the retrieval operation
            agent_id: Optional agent identifier
            **kwargs: Additional attributes to set on the span

        Returns:
            EnhancedSpan: The retrieval span
        """
        span = self.start_span(SpanKind.RETRIEVER, operation_name, **kwargs)
        if agent_id:
            span._span.set_attribute("agent.id", agent_id)
        return span

    def start_embedding_span(
        self,
        operation_name: str,
        agent_id: str | None = None,
        **kwargs: Any,
    ) -> EnhancedSpan:
        """Start an embedding span.

        Args:
            operation_name: Name of the embedding operation
            agent_id: Optional agent identifier
            **kwargs: Additional attributes to set on the span

        Returns:
            EnhancedSpan: The embedding span
        """
        span = self.start_span(SpanKind.EMBEDDING, operation_name, **kwargs)
        if agent_id:
            span._span.set_attribute("agent.id", agent_id)
        return span

    def start_chain_span(
        self,
        operation_name: str,
        agent_id: str | None = None,
        **kwargs: Any,
    ) -> EnhancedSpan:
        """Start a chain/workflow span.

        Args:
            operation_name: Name of the chain operation
            agent_id: Optional agent identifier
            **kwargs: Additional attributes to set on the span

        Returns:
            EnhancedSpan: The chain span
        """
        span = self.start_span(SpanKind.CHAIN, operation_name, **kwargs)
        if agent_id:
            span._span.set_attribute("agent.id", agent_id)
        return span
