"""Initialization module for setting up Phoenix tracing."""

import logging
from typing import Any

from openinference.semconv.resource import ResourceAttributes
from opentelemetry import trace
from opentelemetry.exporter.otlp.proto.http.trace_exporter import OTLPSpanExporter
from opentelemetry.sdk.resources import Resource
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import BatchSpanProcessor
from openinference.instrumentation.openai import OpenAIInstrumentor

from .config import TracingConfig
from .signals import SignalMapping, set_signal_mapping

logger = logging.getLogger(__name__)

_initialized = False
_project_name: str | None = None
_tracer_provider: TracerProvider | None = None


def init_tracing(
    project_name: str,
    service_name: str | None = None,
    phoenix_endpoint: str | None = None,
    phoenix_api_key: str | None = None,
    sample_rate: float | None = None,
    enabled: bool | None = None,
    config: TracingConfig | None = None,
    signal_mapping: SignalMapping | None = None,
) -> None:
    """Initialize tracing with Phoenix backend.

    Args:
        project_name: Phoenix project name for organizing traces
        service_name: Service name for tracing (overrides config/env)
        phoenix_endpoint: Phoenix collector URL (overrides config/env)
        phoenix_api_key: Phoenix API key for authentication (overrides config/env)
        sample_rate: Sampling rate 0.0-1.0 (overrides config/env)
        enabled: Enable/disable tracing (overrides config/env)
        config: TracingConfig object (if not provided, will use env vars)
        signal_mapping: Custom mapping of SignalType -> (label, score) tuples (optional)

    Raises:
        ValueError: If required configuration is missing or invalid

    Example:
        >>> init_tracing(
        ...     project_name="my-agent-project",
        ...     service_name="my-agent",
        ...     phoenix_endpoint="https://phoenix.internal.a.team",
        ...     phoenix_api_key="your-api-key-here"
        ... )

        >>> # With custom signal mapping
        >>> from ateam_llm_tracer import SignalType
        >>> custom_mapping = {
        ...     SignalType.EXECUTE: ("executed", 1.0),
        ...     SignalType.EDIT: ("edited", 0.6),
        ...     SignalType.REGENERATE: ("regenerated", 0.2),
        ... }
        >>> init_tracing(
        ...     project_name="my-agent-project",
        ...     service_name="my-agent",
        ...     phoenix_endpoint="https://phoenix.internal.a.team",
        ...     phoenix_api_key="your-api-key-here",
        ...     signal_mapping=custom_mapping
        ... )
    """
    global _initialized, _project_name, _tracer_provider

    if _initialized:
        logger.warning("Tracing already initialized, skipping re-initialization")
        return

    _project_name = project_name

    # Set custom signal mapping if provided
    if signal_mapping is not None:
        set_signal_mapping(signal_mapping)

    # Start with config or environment
    if config is None:
        config = TracingConfig.from_env()

    # Collect all parameter overrides
    updates: dict[str, Any] = {}
    if service_name is not None:
        updates["service_name"] = service_name
    if phoenix_endpoint is not None:
        updates["phoenix_endpoint"] = phoenix_endpoint
    if phoenix_api_key is not None:
        updates["phoenix_api_key"] = phoenix_api_key
    if sample_rate is not None:
        updates["sample_rate"] = sample_rate
    if enabled is not None:
        updates["enabled"] = enabled

    # If user provides phoenix_endpoint or service_name but enabled was auto-disabled,
    # re-enable tracing since they're providing the required params
    if not config.enabled and enabled is None:
        if phoenix_endpoint is not None or service_name is not None:
            updates["enabled"] = True

    # Apply all overrides at once (Pydantic validates automatically during model creation)
    if updates:
        config = config.model_copy(update=updates)

    if not config.enabled:
        logger.info("Tracing is disabled")
        return

    try:
        # Create resource with service name and project name
        attributes = {
            ResourceAttributes.PROJECT_NAME: project_name,
        }

        resource = Resource(attributes=attributes)

        # Create tracer provider
        provider = TracerProvider(resource=resource)

        # Create OTLP exporter for Phoenix
        exporter_kwargs: dict[str, Any] = {
            "endpoint": f"{config.phoenix_endpoint}/v1/traces",
        }

        # Add authorization header if API key is provided
        if config.phoenix_api_key:
            exporter_kwargs["headers"] = {
                "Authorization": f"Bearer {config.phoenix_api_key}"
            }

        otlp_exporter = OTLPSpanExporter(**exporter_kwargs)

        # Add batch span processor
        span_processor = BatchSpanProcessor(otlp_exporter)
        provider.add_span_processor(span_processor)

        # Set as global tracer provider
        trace.set_tracer_provider(provider)
        OpenAIInstrumentor().instrument()

        _tracer_provider = provider
        _initialized = True
        logger.info(
            f"Tracing initialized: service={config.service_name}, "
            f"endpoint={config.phoenix_endpoint}"
        )

    except Exception as e:
        logger.error(f"Failed to initialize tracing: {e}", exc_info=True)
        raise


def is_tracing_initialized() -> bool:
    """Check if tracing has been initialized.

    Returns:
        True if tracing is initialized, False otherwise
    """
    return _initialized


def force_flush(timeout_millis: int = 5000) -> bool:
    """Force flush all pending traces to the backend.

    This is useful for ensuring all traces are sent before the application exits,
    particularly in serverless environments or CLI tools.

    Args:
        timeout_millis: Maximum time to wait for flush in milliseconds (default: 5000)

    Returns:
        True if flush completed successfully, False otherwise

    Example:
        >>> from ateam_llm_tracer import init_tracing, force_flush
        >>> init_tracing(project_name="my-project", service_name="my-service")
        >>> # ... perform traced operations ...
        >>> force_flush()  # Ensure all traces are sent before exit
    """
    if not _initialized or _tracer_provider is None:
        logger.warning("Cannot flush: tracing not initialized")
        return False

    try:
        result = _tracer_provider.force_flush(timeout_millis=timeout_millis)
        if result:
            logger.debug(f"Successfully flushed traces (timeout: {timeout_millis}ms)")
        else:
            logger.warning(f"Flush timed out after {timeout_millis}ms")
        return result
    except Exception as e:
        logger.error(f"Failed to flush traces: {e}", exc_info=True)
        return False
