"""Signal recording for user feedback and interaction tracking."""

import logging
from typing import Any

from phoenix.client import Client

from .signal_types import SignalType

logger = logging.getLogger(__name__)

# Type alias for signal mapping
SignalMapping = dict[SignalType, tuple[str, float | None]]

# Default mapping: records signals without quality interpretation
# All scores are None, allowing downstream systems to interpret meaning
DEFAULT_SIGNAL_MAPPING: SignalMapping = {
    # Explicit positive
    SignalType.THUMBS_UP: ("thumbs-up", None),
    SignalType.RATING_HIGH: ("rating-high", None),
    # Explicit negative
    SignalType.THUMBS_DOWN: ("thumbs-down", None),
    SignalType.FLAG: ("flag", None),
    SignalType.RATING_LOW: ("rating-low", None),
    # Implicit positive
    SignalType.COPY: ("copy", None),
    SignalType.SAVE: ("save", None),
    SignalType.SHARE: ("share", None),
    SignalType.EXECUTE: ("execute", None),
    SignalType.ACCEPT: ("accept", None),
    # Implicit negative
    SignalType.EDIT: ("edit", None),
    SignalType.REGENERATE: ("regenerate", None),
    SignalType.DISMISS: ("dismiss", None),
    SignalType.REJECT: ("reject", None),
    SignalType.ABANDON: ("abandon", None),
    SignalType.DELETE: ("delete", None),
    # Contextual
    SignalType.FOLLOW_UP: ("follow-up", None),
    SignalType.CORRECTION: ("correction", None),
}

# Global signal mapping singleton
_signal_mapping: SignalMapping = DEFAULT_SIGNAL_MAPPING.copy()


def set_signal_mapping(mapping: SignalMapping) -> None:
    """Set the global signal mapping.

    Args:
        mapping: Dictionary mapping SignalType to (label, score) tuples
    """
    global _signal_mapping
    _signal_mapping = mapping


def get_signal_mapping() -> SignalMapping:
    """Get the current global signal mapping.

    Returns:
        Current signal mapping dictionary
    """
    return _signal_mapping


def record_signal(
    span_id: str,
    signal: SignalType,
    metadata: dict[str, Any] | None = None,
) -> None:
    """Record a user signal/feedback event linked to a span.

    Signals connect user interactions back to the traces that produced artifacts,
    enabling evaluation of model outputs based on real user feedback.

    Args:
        span_id: Span ID from EnhancedSpan.get_span_id()
        signal: Type of signal (thumbs up/down, edit, copy, etc.)
        metadata: Optional metadata (user_id, artifact_id, etc.)

    Example:
        >>> # After generating an artifact
        >>> span_id = span.get_span_id()
        >>>
        >>> # Later, when user provides feedback
        >>> record_signal(
        ...     span_id=span_id,
        ...     signal=SignalType.THUMBS_UP,
        ...     metadata={"user_id": "user123", "artifact_id": "art456"}
        ... )

    Note:
        This is synchronous only. Async signal recording will be added in a future version.
    """
    if metadata is None:
        metadata = {}

    try:
        client = Client()

        # Look up signal in mapping, fallback to signal value with no score
        label, score = _signal_mapping.get(signal, (signal.value.replace("_", "-"), None))

        client.spans.add_span_annotation(
            annotation_name="user feedback",
            annotator_kind="HUMAN",
            span_id=span_id,
            label=label,
            score=score,
            metadata=metadata if metadata else None,
        )

        logger.debug(f"Recorded signal {signal.value} for span {span_id}")

    except Exception as e:
        logger.error(f"Failed to record signal: {e}", exc_info=True)
        # Don't raise - signal recording should not break user flows
