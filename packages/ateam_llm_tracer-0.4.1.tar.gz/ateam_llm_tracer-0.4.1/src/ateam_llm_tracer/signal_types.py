"""Signal types for user feedback and interaction tracking."""

from enum import Enum


class SignalType(Enum):
    """Types of user signals for feedback tracking."""

    # Explicit positive
    THUMBS_UP = "thumbs_up"
    RATING_HIGH = "rating_high"

    # Explicit negative
    THUMBS_DOWN = "thumbs_down"
    FLAG = "flag"
    RATING_LOW = "rating_low"

    # Implicit positive
    COPY = "copy"
    SAVE = "save"
    SHARE = "share"
    EXECUTE = "execute"
    ACCEPT = "accept"

    # Implicit negative
    EDIT = "edit"
    REGENERATE = "regenerate"
    DISMISS = "dismiss"
    REJECT = "reject"
    ABANDON = "abandon"
    DELETE = "delete"

    # Contextual
    FOLLOW_UP = "follow_up"
    CORRECTION = "correction"
