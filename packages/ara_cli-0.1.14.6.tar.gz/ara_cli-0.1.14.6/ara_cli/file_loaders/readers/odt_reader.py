from ara_cli.file_loaders.document_reader import DocumentReader

class OdtReader(DocumentReader):
    """Reader for ODT files"""

    def read(self, extract_images: bool = False) -> str:
        import pymupdf4llm

        if not extract_images:
            return pymupdf4llm.to_markdown(self.file_path, write_images=False)

        import zipfile
        from PIL import Image
        import io

        # Create data directory for images
        images_dir = self.create_image_data_dir("odt")

        # Get text content
        text_content = pymupdf4llm.to_markdown(
            self.file_path, write_images=False)

        # Extract and process images from ODT
        image_descriptions = []
        image_counter = 1

        try:
            with zipfile.ZipFile(self.file_path, 'r') as odt_zip:
                # List all files in the Pictures directory
                picture_files = [
                    f for f in odt_zip.namelist() if f.startswith('Pictures/')]

                for picture_file in picture_files:
                    # Extract image data
                    image_data = odt_zip.read(picture_file)

                    # Determine image format
                    image = Image.open(io.BytesIO(image_data))
                    image_format = image.format.lower()

                    # Save and describe image
                    relative_path, description = self.save_and_describe_image(
                        image_data, image_format, images_dir, image_counter
                    )

                    # Add formatted description to list
                    image_description = f"\nImage: {relative_path}\n[{description}]\n"
                    image_descriptions.append(image_description)

                    image_counter += 1
        except Exception as e:
            print(f"Warning: Could not extract images from ODT: {e}")

        # Combine text content with image descriptions
        if image_descriptions:
            text_content += "\n\n### Extracted Images\n" + \
                "\n".join(image_descriptions)

        return text_content
