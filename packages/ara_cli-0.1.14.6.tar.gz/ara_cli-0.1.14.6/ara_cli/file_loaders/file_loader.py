from abc import ABC, abstractmethod
from typing import Optional


class FileLoader(ABC):
    """Abstract base class for file loaders"""

    def __init__(self, chat_instance):
        self.chat = chat_instance

    @abstractmethod
    def load(self, file_path: str, **kwargs) -> bool:
        """Load file with specific implementation"""
        pass

    def add_prompt_tag_if_needed(self):
        """Add prompt tag to chat if needed"""
        self.chat.add_prompt_tag_if_needed(self.chat.chat_name)



