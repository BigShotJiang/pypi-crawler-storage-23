from typing import Optional
from ara_cli import BINARY_TYPE_MAPPING, DOCUMENT_TYPE_EXTENSIONS
from ara_cli.file_loaders.file_loader import FileLoader

class FileLoaderFactory:
    """Factory for creating appropriate file loaders"""

    @staticmethod
    def create_loader(file_name: str, chat_instance) -> Optional[FileLoader]:
        """Create appropriate loader based on file type"""
        from ara_cli.file_loaders.loaders.binary_file_loader import BinaryFileLoader
        from ara_cli.file_loaders.loaders.text_file_loader import TextFileLoader
        from ara_cli.file_loaders.loaders.document_file_loader import DocumentFileLoader

        file_name_lower = file_name.lower()

        # Check if it's a binary file
        for extension, mime_type in BINARY_TYPE_MAPPING.items():
            if file_name_lower.endswith(extension):
                return BinaryFileLoader(chat_instance)

        # Check if it's a document
        if any(file_name_lower.endswith(ext) for ext in DOCUMENT_TYPE_EXTENSIONS):
            return DocumentFileLoader(chat_instance)

        # Default to text file loader
        return TextFileLoader(chat_instance)
