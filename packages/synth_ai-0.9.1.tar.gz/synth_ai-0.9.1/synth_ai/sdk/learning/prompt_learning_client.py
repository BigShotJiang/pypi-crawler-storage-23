"""Backward-compatible prompt learning client export."""

from __future__ import annotations

from synth_ai.sdk.optimization.clients.prompt_learning import PromptLearningClient

__all__ = ["PromptLearningClient"]
