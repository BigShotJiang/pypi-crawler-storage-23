"""Default adapter stubs for GEPA compatibility."""
# See: specs/sdk_logic.md

from .default_adapter import DefaultAdapter

__all__ = ["DefaultAdapter"]
