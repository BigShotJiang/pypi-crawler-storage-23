"""Example datasets for GEPA compatibility."""
# See: specs/sdk_logic.md

from . import aime, banking77

__all__ = ["aime", "banking77"]
