"""Utility helpers for GEPA compatibility."""
# See: specs/sdk_logic.md
