"""Canonical pools namespace.

# See: specs/sdk_logic.md
"""

from synth_ai.client import AsyncPoolsClient, PoolsClient, PoolTarget

__all__ = [
    "AsyncPoolsClient",
    "PoolTarget",
    "PoolsClient",
]
