"""Canonical graphs namespace.

# See: specs/sdk_logic.md
"""

from synth_ai.client import AsyncGraphsClient, GraphsClient

__all__ = [
    "AsyncGraphsClient",
    "GraphsClient",
]
