"""The pytest-ansible initialization."""
# ruff: noqa: RUF067

from __future__ import annotations


__version__ = "2.3.0"
__author__ = "James Laska"
__author_email__ = "<jlaska@ansible.com>"
