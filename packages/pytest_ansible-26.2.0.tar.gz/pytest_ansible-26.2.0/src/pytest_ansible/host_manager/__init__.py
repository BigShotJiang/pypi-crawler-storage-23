"""Host manager module."""
