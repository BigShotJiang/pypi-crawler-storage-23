import os

base = os.path.join("src", "pypong")

files = {
"__init__.py": '''from .ball import Ball
from .paddle import Paddle
from .court import Court
from .cpu import CPU
from .game import Game


def demo():
    game = Game()
    game.add(Paddle("left"), Paddle("right"), Ball(), Court())
    game.set_win_score(5)
    game.run()
''',

"__main__.py": '''from pypong import demo

demo()
''',

"input.py": '''import sys
import os

WINDOWS = os.name == 'nt'

if WINDOWS:
    import msvcrt
else:
    import tty
    import termios
    import select


class InputHandler:
    def __init__(self):
        self._original_settings = None
        if not WINDOWS:
            self._original_settings = termios.tcgetattr(sys.stdin)
            tty.setcbreak(sys.stdin.fileno())

    def get_key(self):
        if WINDOWS:
            if msvcrt.kbhit():
                ch = msvcrt.getch()
                if ch in (b"\\x00", b"\\xe0"):
                    msvcrt.getch()
                    return None
                try:
                    return ch.decode("utf-8").lower()
                except:
                    return None
            return None
        else:
            if select.select([sys.stdin], [], [], 0)[0]:
                ch = sys.stdin.read(1)
                return ch.lower()
            return None

    def read_keys(self, max_keys=15):
        keys = []
        for _ in range(max_keys):
            key = self.get_key()
            if key is None:
                break
            keys.append(key)
        return keys

    def cleanup(self):
        if not WINDOWS and self._original_settings:
            termios.tcsetattr(sys.stdin, termios.TCSADRAIN, self._original_settings)
''',

"ball.py": '''import random


class Ball:
    def __init__(self, speed=1.0, max_speed=2.5, speed_increment=0.08,
                 char="O", trail=False, trail_length=4, trail_chars=None):
        self.x = 0.0
        self.y = 0.0
        self.dx = 0.0
        self.dy = 0.0
        self.speed = speed
        self.default_speed = speed
        self.max_speed = max_speed
        self.speed_increment = speed_increment
        self.char = char
        self.court_width = 0
        self.court_height = 0
        self.trail_enabled = trail
        self.trail_length = trail_length
        self.trail = []
        self.trail_chars = trail_chars or [".", ".", "o", "o"]
        self._move_accum = 0.0
        self.frozen = True
        self._freeze_time = 0.0

    def setup(self, court_width, court_height):
        self.court_width = court_width
        self.court_height = court_height
        self.reset()

    def reset(self, direction=None):
        self.x = float(self.court_width // 2)
        self.y = float(self.court_height // 2)
        self.speed = self.default_speed
        self._move_accum = 0.0
        self.trail = []
        if direction is None:
            direction = random.choice([-1, 1])
        self.dx = float(direction)
        self.dy = random.uniform(-0.5, 0.5)
        self.frozen = True
        self._freeze_time = 3.0

    def update(self, dt):
        if self.frozen:
            self._freeze_time -= dt
            if self._freeze_time <= 0:
                self.frozen = False
            return []
        self._move_accum += self.speed
        positions = []
        while self._move_accum >= 1.0:
            self._move_accum -= 1.0
            if self.trail_enabled:
                self.trail.append((self.x, self.y))
                if len(self.trail) > self.trail_length:
                    self.trail.pop(0)
            self.x += self.dx
            self.y += self.dy
            positions.append((self.x, self.y))
        return positions

    def get_display_pos(self):
        bx = int(round(self.x))
        by = int(round(self.y))
        by = max(1, min(self.court_height - 2, by))
        return bx, by

    def get_trail_positions(self):
        positions = []
        for i, (tx, ty) in enumerate(self.trail):
            txi = int(round(tx))
            tyi = int(round(ty))
            tyi = max(1, min(self.court_height - 2, tyi))
            idx = min(i, len(self.trail_chars) - 1)
            positions.append((txi, tyi, self.trail_chars[idx]))
        return positions
''',

"paddle.py": '''class Paddle:
    def __init__(self, side="left", height=5, speed=2,
                 up_key=None, down_key=None, char="#", end_char=None):
        self.side = side
        self.height = height
        self.speed = speed
        self.char = char
        self.end_char = end_char or ("[" if side == "left" else "]")
        self.y = 0.0
        self.x = 0
        if up_key and down_key:
            self.up_key = up_key
            self.down_key = down_key
        elif side == "left":
            self.up_key = "w"
            self.down_key = "s"
        else:
            self.up_key = "i"
            self.down_key = "k"
        self.court_width = 0
        self.court_height = 0
        self.hits = 0
        self.combo = 0

    def setup(self, court_width, court_height):
        self.court_width = court_width
        self.court_height = court_height
        if self.side == "left":
            self.x = 1
        else:
            self.x = court_width - 2
        self.y = float(court_height // 2 - self.height // 2)

    def reset(self):
        self.y = float(self.court_height // 2 - self.height // 2)
        self.combo = 0

    def handle_input(self, keys):
        for key in keys:
            if key == self.up_key:
                self.y = max(0, self.y - self.speed)
            elif key == self.down_key:
                self.y = min(self.court_height - self.height, self.y + self.speed)

    def register_hit(self):
        self.hits += 1
        self.combo += 1

    def reset_combo(self):
        self.combo = 0

    def get_cells(self):
        cells = []
        top = int(self.y)
        for y in range(top, top + self.height):
            if y == top or y == top + self.height - 1:
                cells.append((self.x, y, self.end_char))
            else:
                cells.append((self.x, y, self.char))
        return cells
''',

"cpu.py": '''import random
from .paddle import Paddle


class CPU(Paddle):
    def __init__(self, side="right", height=5, difficulty="medium",
                 char="#", end_char=None):
        if end_char is None:
            end_char = "[" if side == "left" else "]"
        self.side = side
        self.height = height
        self.speed = 2
        self.char = char
        self.end_char = end_char
        self.y = 0.0
        self.x = 0
        self.up_key = None
        self.down_key = None
        self.court_width = 0
        self.court_height = 0
        self.hits = 0
        self.combo = 0
        self.difficulty = difficulty
        self._reaction_timer = 0
        self._configs = {
            "easy": {"react_every": 6, "wobble": 4.0, "chase_always": False, "speed": 1},
            "medium": {"react_every": 3, "wobble": 1.5, "chase_always": False, "speed": 2},
            "hard": {"react_every": 1, "wobble": 0.0, "chase_always": True, "speed": 2},
        }

    def setup(self, court_width, court_height):
        self.court_width = court_width
        self.court_height = court_height
        if self.side == "left":
            self.x = 1
        else:
            self.x = court_width - 2
        self.y = float(court_height // 2 - self.height // 2)

    def handle_input(self, keys):
        pass

    def update(self, ball):
        self._reaction_timer += 1
        config = self._configs.get(self.difficulty, self._configs["medium"])
        if self._reaction_timer % config["react_every"] != 0:
            return
        target_y = ball.y
        paddle_center = self.y + self.height / 2.0
        target_y += random.uniform(-config["wobble"], config["wobble"])
        should_chase = config["chase_always"]
        if self.side == "right" and ball.dx > 0:
            should_chase = True
        elif self.side == "left" and ball.dx < 0:
            should_chase = True
        if should_chase:
            diff = target_y - paddle_center
            if abs(diff) > 1:
                if diff > 0:
                    self.y = min(self.court_height - self.height, self.y + config["speed"])
                else:
                    self.y = max(0, self.y - config["speed"])
''',

"court.py": '''class Court:
    def __init__(self, width=60, height=22, border_h="=", border_v="|",
                 corner_tl="+", corner_tr="+", corner_bl="+", corner_br="+",
                 net_char="|", net_enabled=True):
        self.width = width
        self.height = height
        self.border_h = border_h
        self.border_v = border_v
        self.corner_tl = corner_tl
        self.corner_tr = corner_tr
        self.corner_bl = corner_bl
        self.corner_br = corner_br
        self.net_char = net_char
        self.net_enabled = net_enabled

    def top_border(self):
        return self.corner_tl + self.border_h * self.width + self.corner_tr

    def bottom_border(self):
        return self.corner_bl + self.border_h * self.width + self.corner_br

    def row_start(self):
        return self.border_v

    def row_end(self):
        return self.border_v

    def get_net_char(self, y):
        if not self.net_enabled:
            return " "
        if y % 2 == 0:
            return self.net_char
        return " "

    def net_x(self):
        return self.width // 2
''',

"collision.py": '''class CollisionHandler:
    def __init__(self, court_top=1.0, court_bottom=None, min_dy=0.3, max_dy=0.9):
        self.court_top = court_top
        self.court_bottom = court_bottom
        self.min_dy = min_dy
        self.max_dy = max_dy

    def set_bounds(self, height):
        self.court_bottom = float(height - 2)

    def bounce_walls(self, ball):
        bounced = False
        bounce_count = 0
        while (ball.y < self.court_top or ball.y > self.court_bottom) and bounce_count < 10:
            bounce_count += 1
            bounced = True
            if ball.y < self.court_top:
                ball.y = 2 * self.court_top - ball.y
                ball.dy = abs(ball.dy)
                if abs(ball.dy) < self.min_dy:
                    ball.dy = self.min_dy
            if ball.y > self.court_bottom:
                ball.y = 2 * self.court_bottom - ball.y
                ball.dy = -abs(ball.dy)
                if abs(ball.dy) < self.min_dy:
                    ball.dy = -self.min_dy
        if ball.y <= self.court_top:
            ball.y = self.court_top + 0.5
            ball.dy = abs(ball.dy)
            if abs(ball.dy) < self.min_dy:
                ball.dy = self.min_dy
        if ball.y >= self.court_bottom:
            ball.y = self.court_bottom - 0.5
            ball.dy = -abs(ball.dy)
            if abs(ball.dy) < self.min_dy:
                ball.dy = -self.min_dy
        return bounced

    def check_paddle(self, ball, paddle):
        by = int(round(ball.y))
        by = max(1, by)
        paddle_top = int(paddle.y)
        paddle_bottom = paddle_top + paddle.height
        if paddle.side == "left":
            if ball.x <= paddle.x + 1 and ball.dx < 0:
                if paddle_top <= by < paddle_bottom:
                    ball.x = float(paddle.x + 2)
                    ball.dx = abs(ball.dx)
                    self._apply_spin(ball, paddle)
                    return True
                elif ball.x < 0:
                    return "scored"
        elif paddle.side == "right":
            if ball.x >= paddle.x - 1 and ball.dx > 0:
                if paddle_top <= by < paddle_bottom:
                    ball.x = float(paddle.x - 2)
                    ball.dx = -abs(ball.dx)
                    self._apply_spin(ball, paddle)
                    return True
                elif ball.x >= paddle.court_width:
                    return "scored"
        return False

    def _apply_spin(self, ball, paddle):
        by = int(round(ball.y))
        center = paddle.y + paddle.height / 2.0
        offset = (by - center) / (paddle.height / 2.0)
        ball.dy = offset * 1.0
        if abs(ball.dy) < self.min_dy:
            ball.dy = self.min_dy if ball.dy >= 0 else -self.min_dy
        if ball.dy > self.max_dy:
            ball.dy = self.max_dy
        elif ball.dy < -self.max_dy:
            ball.dy = -self.max_dy
        ball.speed = min(ball.speed + ball.speed_increment, ball.max_speed)
''',

"game.py": '''import sys
import os
import time

from .ball import Ball
from .paddle import Paddle
from .court import Court
from .cpu import CPU
from .collision import CollisionHandler
from .input import InputHandler


class Game:
    def __init__(self, title="PyPong"):
        self.title = title
        self.paddles = []
        self.ball = None
        self.court = None
        self.cpus = []
        self.collision = CollisionHandler()
        self.input_handler = None
        self.scores = {}
        self.win_score = 7
        self.running = True
        self.paused = False
        self.game_over = False
        self.winner = None
        self.tick_rate = 0.045
        self.countdown = 0
        self.countdown_timer = 0.0
        self.sound_enabled = True
        self.on_hit = None
        self.on_score = None
        self.on_wall_bounce = None
        self.on_game_over = None

    def add(self, *objects):
        for obj in objects:
            if isinstance(obj, CPU):
                self.paddles.append(obj)
                self.cpus.append(obj)
                self.scores[obj.side] = 0
            elif isinstance(obj, Paddle):
                self.paddles.append(obj)
                self.scores[obj.side] = 0
            elif isinstance(obj, Ball):
                self.ball = obj
            elif isinstance(obj, Court):
                self.court = obj
        return self

    def set_win_score(self, score):
        self.win_score = score
        return self

    def set_tick_rate(self, rate):
        self.tick_rate = rate
        return self

    def set_sound(self, enabled):
        self.sound_enabled = enabled
        return self

    def _beep(self):
        if self.sound_enabled:
            sys.stdout.write("\\a")
            sys.stdout.flush()

    def _setup(self):
        if self.court is None:
            self.court = Court()
        if self.ball is None:
            self.ball = Ball()
        w = self.court.width
        h = self.court.height
        self.ball.setup(w, h)
        self.collision.set_bounds(h)
        for paddle in self.paddles:
            paddle.setup(w, h)
        self.input_handler = InputHandler()
        self.countdown = 3
        self.countdown_timer = time.time()
        sys.stdout.write("\\033[?25l")
        sys.stdout.flush()

    def _restart(self):
        for side in self.scores:
            self.scores[side] = 0
        for paddle in self.paddles:
            paddle.reset()
        self.ball.reset()
        self.game_over = False
        self.winner = None
        self.paused = False
        self.countdown = 3
        self.countdown_timer = time.time()

    def _handle_input(self, keys):
        for key in keys:
            if key == "q":
                self.running = False
            elif key == "p" and not self.game_over:
                self.paused = not self.paused
            elif key == "r":
                self._restart()
        if not self.paused and not self.game_over:
            for paddle in self.paddles:
                paddle.handle_input(keys)

    def _update(self):
        if self.paused or self.game_over:
            return
        if self.countdown > 0:
            if time.time() - self.countdown_timer >= 1.0:
                self.countdown -= 1
                self.countdown_timer = time.time()
            return
        positions = self.ball.update(self.tick_rate)
        for _ in positions:
            if self.collision.bounce_walls(self.ball):
                self._beep()
                if self.on_wall_bounce:
                    self.on_wall_bounce(self.ball)
            for paddle in self.paddles:
                result = self.collision.check_paddle(self.ball, paddle)
                if result == True:
                    paddle.register_hit()
                    for other in self.paddles:
                        if other is not paddle:
                            other.reset_combo()
                    self._beep()
                    if self.on_hit:
                        self.on_hit(paddle, self.ball)
                elif result == "scored":
                    scoring_side = "right" if paddle.side == "left" else "left"
                    self.scores[scoring_side] = self.scores.get(scoring_side, 0) + 1
                    self._beep()
                    if self.on_score:
                        self.on_score(scoring_side, self.scores)
                    if self.scores[scoring_side] >= self.win_score:
                        self.game_over = True
                        self.winner = scoring_side
                        if self.on_game_over:
                            self.on_game_over(self.winner, self.scores)
                    else:
                        direction = 1 if scoring_side == "left" else -1
                        self.ball.reset(direction)
                        self.countdown = 3
                        self.countdown_timer = time.time()
                    return
        for cpu in self.cpus:
            cpu.update(self.ball)

    def _build_frame(self):
        lines = []
        w = self.court.width
        h = self.court.height
        left_name = "P1"
        right_name = "P2"
        for paddle in self.paddles:
            if isinstance(paddle, CPU):
                if paddle.side == "left":
                    left_name = "CPU"
                else:
                    right_name = "CPU"
        left_score = self.scores.get("left", 0)
        right_score = self.scores.get("right", 0)
        header = f"  {left_name} [{left_score}]"
        header2 = f"[{right_score}] {right_name}"
        gap = w + 2 - len(header) - len(header2)
        lines.append(header + " " * max(gap, 1) + header2)
        lines.append("")
        lines.append(self.court.top_border())
        bx, by = self.ball.get_display_pos()
        show_ball = not self.ball.frozen or int(time.time() * 4) % 2 == 0
        trail_map = {}
        if self.ball.trail_enabled and not self.ball.frozen:
            for tx, ty, tc in self.ball.get_trail_positions():
                trail_map[(tx, ty)] = tc
        paddle_map = {}
        for paddle in self.paddles:
            for px, py, pc in paddle.get_cells():
                paddle_map[(px, py)] = pc
        net_x = self.court.net_x()
        for y in range(h):
            row = [self.court.row_start()]
            for x in range(w):
                drawn = False
                if not drawn and x == bx and y == by and show_ball:
                    row.append(self.ball.char)
                    drawn = True
                if not drawn and (x, y) in trail_map:
                    row.append(trail_map[(x, y)])
                    drawn = True
                if not drawn and (x, y) in paddle_map:
                    row.append(paddle_map[(x, y)])
                    drawn = True
                if not drawn and x == net_x:
                    row.append(self.court.get_net_char(y))
                    drawn = True
                if not drawn:
                    row.append(" ")
            row.append(self.court.row_end())
            lines.append("".join(row))
        lines.append(self.court.bottom_border())
        control_parts = []
        for paddle in self.paddles:
            if not isinstance(paddle, CPU) and paddle.up_key and paddle.down_key:
                name = "P1" if paddle.side == "left" else "P2"
                control_parts.append(f"{paddle.up_key.upper()}/{paddle.down_key.upper()}:{name}")
        control_parts.extend(["P:Pause", "Q:Quit", "R:Restart"])
        lines.append("  " + "  ".join(control_parts))
        if self.countdown > 0:
            lines.append(f"\\n          >>> Get ready... {self.countdown} <<<")
        elif self.paused:
            lines.append(f"\\n          >>> PAUSED - Press P to resume <<<")
        elif self.game_over:
            winner_name = left_name if self.winner == "left" else right_name
            lines.append(f"\\n          >>> {winner_name} WINS! R:Restart Q:Quit <<<")
        else:
            lines.append("")
        for _ in range(3):
            lines.append(" " * (w + 2))
        return "\\n".join(lines)

    def run(self):
        try:
            self._setup()
            os.system("cls" if os.name == "nt" else "clear")
            while self.running:
                start = time.time()
                keys = self.input_handler.read_keys()
                self._handle_input(keys)
                self._update()
                frame = self._build_frame()
                sys.stdout.write("\\033[H")
                sys.stdout.write(frame)
                sys.stdout.flush()
                elapsed = time.time() - start
                sleep = self.tick_rate - elapsed
                if sleep > 0:
                    time.sleep(sleep)
        except KeyboardInterrupt:
            pass
        finally:
            self.input_handler.cleanup()
            sys.stdout.write("\\033[?25h")
            sys.stdout.flush()
            os.system("cls" if os.name == "nt" else "clear")
            print(f"\\n  Thanks for playing {self.title}!\\n")
''',
}

os.makedirs(base, exist_ok=True)

for filename, content in files.items():
    filepath = os.path.join(base, filename)
    with open(filepath, 'w', encoding='utf-8') as f:
        f.write(content)
    print(f"Fixed: {filepath}")

print("\nAll files fixed!")