from ...discrete.phase_set import PhaseSet

LIFE_PHASE_SET = PhaseSet(["alive", "dead"])
