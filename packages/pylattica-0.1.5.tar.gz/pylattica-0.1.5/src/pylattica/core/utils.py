def printif(cond, statement):  # pragma: no cover
    if cond:
        print(statement)
