LOCATION = "_location"
SITE_ID = "_site_id"
SITE_CLASS = "_site_class"
STATE_VALUE = "_state_value"
GENERAL = "GENERAL"
SITES = "SITES"
OFFSET_PRECISION = 3
