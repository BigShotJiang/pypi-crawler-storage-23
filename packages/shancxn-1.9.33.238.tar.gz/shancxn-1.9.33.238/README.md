# Welecome to shancxn

A simple Python package that provides a timer decorator to measure the execution time of functions.

## Installation
 
pip install shancxn
 
pip install shancxn -i https://mirrors.cloud.tencent.com/pypi/simple