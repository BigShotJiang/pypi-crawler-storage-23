import traceback
def getSimple(df=None,n=1000):
    try:
       df = df.sample(n=n, replace=True, random_state=42)
    except Exception as e :
        print(traceback.format_exc())
        return None
    return df
