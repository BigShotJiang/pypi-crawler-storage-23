# QuikArit, not so quick as you think
Math functions are cool, but do you know what's cooler? Miscellaneous ones, with a little bit of sorting algorithms and logic gates!