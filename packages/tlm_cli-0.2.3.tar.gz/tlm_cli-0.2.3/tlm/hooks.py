"""
TLM Hook Handlers — Context injection and enforcement for Claude Code.

Server-backed intelligence. Same 6 hooks as V1, all intelligence from server.

Hook handlers:
    hook_session_start      — SessionStart: loads project context + gaps
    hook_prompt_submit      — UserPromptSubmit: phase-specific context + gap warnings
    hook_guard              — PreToolUse (Write/Edit): blocks during interview, enforces TDD
    hook_compliance_gate    — PreToolUse (Bash): review gate on git commit
    hook_deployment_gate    — PreToolUse (Bash): always blocks deploys
    hook_stop               — Stop: session cleanup
"""

import json
import re
import subprocess
import datetime
from pathlib import Path

from tlm.state import read_state
from tlm.config import load_project_config
from tlm.gaps import load_gaps, get_active_gaps

# ANSI colors
_C = "\033[36m"   # cyan
_G = "\033[32m"   # green
_Y = "\033[33m"   # amber
_R = "\033[31m"   # red
_B = "\033[1m"    # bold
_D = "\033[2m"    # dim
_X = "\033[0m"    # reset


def hook_session_start(project_root: str) -> str:
    """SessionStart hook: inject project context into Claude's session."""
    root = Path(project_root)
    tlm_dir = root / ".tlm"

    if not tlm_dir.exists():
        return "TLM is not initialized in this project. Run `tlm install` to set up."

    parts = [
        f"{_C}{_B}[TLM]{_X} You are operating under TLM rules. Read CLAUDE.md for full details.",
        f"{_D}When using knowledge facts, attribute: 'Based on TLM's analysis of your project, [fact].'{_X}\n",
    ]

    # Current state
    state = read_state(project_root)
    phase = state.get("phase", "idle")
    activity = state.get("activity_type")

    parts.append(f"{_B}Current phase:{_X} {phase}")
    if activity:
        parts.append(f"{_B}Activity type:{_X} {activity}")

    # Quality control level
    config = load_project_config(project_root)
    quality = config.get("quality_control", "standard")
    parts.append(f"\n{_B}Quality control:{_X} {quality}")

    # Active gaps
    active = get_active_gaps(project_root)
    if active:
        parts.append(f"\n{_Y}Known project gaps ({len(active)}):{_X}")
        for g in active[:5]:
            sev = g.get("severity", "medium")
            parts.append(f"  {_Y}[{sev}]{_X} {g['description']}")
        if len(active) > 5:
            parts.append(f"  {_D}... and {len(active) - 5} more{_X}")

    # Knowledge file
    knowledge_file = tlm_dir / "knowledge.md"
    if knowledge_file.exists():
        try:
            knowledge = knowledge_file.read_text()
            facts = [l.strip() for l in knowledge.split("\n")
                     if l.strip() and not l.startswith(("#", "_", "---"))]
            if facts:
                parts.append(f"\n{_G}Project knowledge ({len(facts)} facts):{_X}")
                for fact in facts[:10]:
                    parts.append(f"  {_D}{fact}{_X}")
        except OSError:
            pass

    return "\n".join(parts)


def hook_prompt_submit(project_root: str, prompt_text: str = "") -> dict:
    """UserPromptSubmit hook: phase-specific context + gap warnings."""
    state = read_state(project_root)
    phase = state.get("phase", "idle")
    activity = state.get("activity_type")

    context_parts = []

    # Phase-specific context
    if phase == "idle":
        context_parts.append(
            "[TLM] Before responding, classify this request: "
            "Is it a significant engineering activity? "
            "Check Tier 1 (always activate) and Tier 2 (self-classify) "
            "in CLAUDE.md. If significant, enter interview mode first. "
            "If activating TLM, start your response with "
            "'TLM > [reason]. Let me refine your requirements first.'"
        )
    elif phase == "tlm_active":
        context_parts.append(
            f"[TLM] You are in interview mode (activity: {activity or 'unknown'}). "
            "Continue asking questions one at a time. "
            "Do not write code until the interview is complete and spec is generated."
        )
    elif phase == "implementation":
        active_spec = state.get("active_spec")
        spec_note = f" Active spec: {active_spec}." if active_spec else ""
        context_parts.append(
            f"[TLM] Implementation phase.{spec_note} "
            "TDD is mandatory: write tests first, verify they fail, "
            "then implement, then verify they pass."
        )
    elif phase == "deployment":
        context_parts.append(
            "[TLM] Deployment phase. Follow the deployment pipeline. Never skip environments."
        )

    # Gap warnings: check if prompt mentions a known gap
    if prompt_text:
        active = get_active_gaps(project_root)
        for gap in active:
            gap_keywords = _gap_keywords(gap)
            prompt_lower = prompt_text.lower()
            if any(kw in prompt_lower for kw in gap_keywords):
                context_parts.append(
                    f"\n[TLM Warning] '{gap['category']}' is flagged as a gap in this project. "
                    f"Description: {gap['description']}. "
                    f"Status: {gap['status']}. "
                    "Consider fixing this gap properly with `tlm gaps` before proceeding."
                )
                break  # Only show one gap warning per prompt

    return {"additionalContext": "\n".join(context_parts)}


def hook_guard(project_root: str, tool_input: dict) -> dict:
    """PreToolUse hook for Write/Edit: blocks during interview, enforces TDD."""
    tool_name = tool_input.get("tool_name", "")
    file_input = tool_input.get("tool_input", {})
    file_path = file_input.get("file_path", "")

    if tool_name not in ("Write", "Edit"):
        return {}

    state = read_state(project_root)
    phase = state.get("phase", "idle")

    is_tlm_file = "/.tlm/" in file_path or file_path.startswith(".tlm/")
    is_test_file = _is_test_file(file_path)

    # During interview: block source writes
    if phase == "tlm_active" and not is_test_file and not is_tlm_file:
        return {
            "decision": "block",
            "reason": (
                f"{_Y}TLM >{_X} Complete the discovery interview and get spec approval "
                f"before writing code."
            ),
        }

    # During implementation: TDD enforcement
    if phase == "implementation" and not is_test_file and not is_tlm_file:
        # Check spec approval
        spec_status = state.get("spec_review_status", "none")
        if spec_status != "approved":
            return {
                "decision": "block",
                "reason": (
                    f"{_Y}TLM > Spec has not been reviewed/approved yet.{_X} "
                    "Save the spec to .tlm/specs/ to trigger review."
                ),
            }

        # TDD: check if tests written this session
        tdd_result = _check_tdd_compliance(project_root, file_path)
        if tdd_result:
            return tdd_result

    # Track test file writes
    if is_test_file and phase in ("tlm_active", "implementation"):
        _track_test_write(project_root, file_path)

    # Gap warning on related files (non-blocking)
    if phase == "idle" and not is_tlm_file:
        gap_ctx = _check_gap_file_warning(project_root, file_path)
        if gap_ctx:
            return gap_ctx

    return {}


def hook_compliance_gate(project_root: str, tool_input: dict) -> dict:
    """PreToolUse hook for Bash: compliance gate on git commit."""
    command = tool_input.get("command", "")

    if not _is_git_commit(command):
        return {}

    root = Path(project_root)
    tlm_dir = root / ".tlm"
    if not tlm_dir.exists():
        return {}

    config = load_project_config(project_root)
    quality = config.get("quality_control", "standard")
    state = read_state(project_root)
    active_spec = state.get("active_spec")

    parts = [
        "[TLM] COMPLIANCE CHECK before commit:",
        "Tell the user: 'TLM > Running compliance check before commit.'",
    ]

    if active_spec:
        parts.append(f"\n1. Verify changes against spec: {active_spec}")
        parts.append("   - Are ALL spec items implemented?")
        parts.append("   - Are ALL specified test cases written and passing?")

    parts.append("\nEnsure all tests pass before committing.")

    return {"additionalContext": "\n".join(parts)}


def hook_deployment_gate(project_root: str, tool_input: dict) -> dict:
    """PreToolUse hook for Bash: ALWAYS blocks deploy commands."""
    command = tool_input.get("command", "")

    if not _is_deploy_command(command):
        return {}

    root = Path(project_root)
    if not (root / ".tlm").exists():
        return {}

    return {
        "decision": "block",
        "reason": (
            f"{_Y}TLM > DEPLOYMENT GATE{_X} — Run {_B}tlm check{_X} before deploying.\n"
            "All quality gates must pass before deployment to any environment."
        ),
    }


def hook_stop(project_root: str) -> dict:
    """Stop hook: session cleanup."""
    root = Path(project_root)
    tlm_dir = root / ".tlm"

    if not tlm_dir.exists():
        return {}

    # Clean session caches
    cache_dir = tlm_dir / "cache"
    if cache_dir.exists():
        for cache_file in ("session_tests.json",):
            (cache_dir / cache_file).unlink(missing_ok=True)

    return {}


# ─── Internal helpers ─────────────────────────────────────────

def _gap_keywords(gap: dict) -> list[str]:
    """Extract keywords from a gap for prompt matching."""
    keywords = []
    gap_id = gap.get("id", "").lower()
    gap_type = gap.get("type", "").lower()
    category = gap.get("category", "").lower()
    description = gap.get("description", "").lower()

    keywords.append(gap_id)
    if gap_type and gap_type != gap_id:
        keywords.append(gap_type)
    if category:
        keywords.extend(category.lower().split("/"))

    # Extract significant words from description
    for word in description.split():
        if len(word) > 4 and word not in ("detected", "pipeline", "implemented", "project"):
            keywords.append(word)

    return [k for k in keywords if k]


def _is_test_file(file_path: str) -> bool:
    """Check if a file path is a test file."""
    parts = Path(file_path).parts
    if not parts:
        return False
    filename = parts[-1].lower()

    if (filename.startswith("test_") or filename.startswith("test.")
            or "_test." in filename or ".test." in filename
            or "_spec." in filename or ".spec." in filename):
        return True

    test_dirs = {"tests", "test", "spec", "specs", "__tests__"}
    return any(part.lower() in test_dirs for part in parts[:-1])


def _track_test_write(project_root: str, file_path: str):
    """Track test file writes for TDD enforcement."""
    tlm_dir = Path(project_root) / ".tlm"
    cache_dir = tlm_dir / "cache"
    cache_dir.mkdir(parents=True, exist_ok=True)
    tracking_file = cache_dir / "session_tests.json"

    tracking = {"test_files_written": []}
    if tracking_file.exists():
        try:
            tracking = json.loads(tracking_file.read_text())
        except (json.JSONDecodeError, OSError):
            pass

    files = tracking.get("test_files_written", [])
    if file_path not in files:
        files.append(file_path)
        tracking["test_files_written"] = files
        tracking_file.write_text(json.dumps(tracking))


def _check_tdd_compliance(project_root: str, source_file_path: str) -> dict | None:
    """Check if TDD is being followed. Returns block dict or None."""
    tlm_dir = Path(project_root) / ".tlm"
    tracking_file = tlm_dir / "cache" / "session_tests.json"

    test_files = []
    if tracking_file.exists():
        try:
            tracking = json.loads(tracking_file.read_text())
            test_files = tracking.get("test_files_written", [])
        except (json.JSONDecodeError, OSError):
            pass

    if not test_files:
        return {
            "decision": "block",
            "reason": (
                f"{_Y}TLM > Write the test first. TDD is non-negotiable.{_X}\n"
                "Write your test file first, then you can write the source code."
            ),
        }

    return None


def _check_gap_file_warning(project_root: str, file_path: str) -> dict | None:
    """Warn if writing to a file related to a known gap."""
    active = get_active_gaps(project_root)
    if not active:
        return None

    filename = Path(file_path).stem.lower()
    for gap in active:
        gap_id = gap.get("id", "").lower()
        gap_type = gap.get("type", "").lower()
        if gap_id in filename or gap_type in filename:
            return {
                "additionalContext": (
                    f"[TLM] You're modifying '{Path(file_path).name}', but "
                    f"'{gap['category']}' is flagged as a gap ({gap['status']}). "
                    "Consider fixing this gap properly first."
                ),
            }

    return None


def _is_git_commit(command: str) -> bool:
    """Check if a shell command is a git commit."""
    return bool(re.search(r'\bgit\s+commit\b', command))


def _is_deploy_command(command: str) -> bool:
    """Check if a shell command is a deployment command."""
    deploy_patterns = [
        r'\bgit\s+push\s+.*\b(prod|production|main|master)\b',
        r'\b(eb|firebase|fly|sam|serverless)\s+deploy\b',
        r'\bkubectl\s+apply\b.*\b(prod|production)\b',
        r'\bdocker\s+push\b',
        r'\bhelm\s+(install|upgrade)\b',
    ]
    for pattern in deploy_patterns:
        if re.search(pattern, command, re.IGNORECASE):
            return True
    return False
