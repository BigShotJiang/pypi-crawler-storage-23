"""Tests for scanner — file tree collection and sample extraction."""

import pytest
from tlm.scanner import scan_project


class TestScanner:
    def test_scan_returns_file_tree(self, temp_project):
        """Scan should return a file tree string."""
        result = scan_project(str(temp_project))
        assert "file_tree" in result
        assert isinstance(result["file_tree"], str)
        assert len(result["file_tree"]) > 0

    def test_scan_returns_samples(self, temp_project):
        """Scan should return sample file contents."""
        result = scan_project(str(temp_project))
        assert "samples" in result
        assert isinstance(result["samples"], str)

    def test_file_tree_contains_files(self, temp_project):
        """File tree should list actual files."""
        result = scan_project(str(temp_project))
        assert "app.py" in result["file_tree"]
        assert "requirements.txt" in result["file_tree"]
        assert "README.md" in result["file_tree"]

    def test_samples_contain_key_file_contents(self, temp_project):
        """Samples should include content of important files."""
        result = scan_project(str(temp_project))
        # Should sample at least one file
        assert "===" in result["samples"] or len(result["samples"]) > 10

    def test_scan_excludes_hidden_dirs(self, temp_project):
        """Scan should exclude .git and other hidden directories."""
        (temp_project / ".git").mkdir()
        (temp_project / ".git" / "config").write_text("gitconfig")
        result = scan_project(str(temp_project))
        assert ".git/config" not in result["file_tree"]

    def test_scan_excludes_node_modules(self, temp_project):
        """Scan should exclude node_modules."""
        (temp_project / "node_modules").mkdir()
        (temp_project / "node_modules" / "pkg").mkdir()
        (temp_project / "node_modules" / "pkg" / "index.js").write_text("module.exports = {}")
        result = scan_project(str(temp_project))
        assert "node_modules" not in result["file_tree"]

    def test_scan_handles_empty_dir(self, tmp_path):
        """Scan should work on empty directory."""
        result = scan_project(str(tmp_path))
        assert "file_tree" in result
        assert "samples" in result

    def test_scan_limits_file_tree_depth(self, temp_project):
        """Scan should not go infinitely deep."""
        # Create deeply nested dirs
        d = temp_project
        for i in range(20):
            d = d / f"level{i}"
            d.mkdir()
            (d / "file.py").write_text(f"# level {i}")
        result = scan_project(str(temp_project))
        # Should still return a result (not hang)
        assert isinstance(result["file_tree"], str)

    def test_scan_samples_important_files(self, temp_project):
        """Should sample config/manifest files preferentially."""
        (temp_project / "pyproject.toml").write_text('[project]\nname = "test"\n')
        (temp_project / "Dockerfile").write_text("FROM python:3.12\n")
        result = scan_project(str(temp_project))
        # At least one key file should be sampled
        assert len(result["samples"]) > 0
