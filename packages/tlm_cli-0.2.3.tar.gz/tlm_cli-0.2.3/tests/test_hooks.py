"""Tests for hooks — 6 hook handlers with server-backed intelligence."""

import json
import pytest
from pathlib import Path
from unittest.mock import patch, AsyncMock

from tlm.hooks import (
    hook_session_start,
    hook_prompt_submit,
    hook_guard,
    hook_compliance_gate,
    hook_deployment_gate,
    hook_stop,
)
from tlm.state import write_state
from tlm.config import save_project_config
from tlm.gaps import add_gap, GapStatus


@pytest.fixture
def tlm_project(tmp_path):
    """Create a project with TLM initialized."""
    tlm_dir = tmp_path / ".tlm"
    tlm_dir.mkdir()
    (tlm_dir / "specs").mkdir()
    (tlm_dir / "cache").mkdir()
    write_state(str(tmp_path), {"phase": "idle"})
    save_project_config(str(tmp_path), {
        "quality_control": "standard",
        "project_id": "proj_1",
    })
    return tmp_path


class TestHookSessionStart:
    def test_returns_context_when_tlm_exists(self, tlm_project):
        """Session start should return context when .tlm/ exists."""
        result = hook_session_start(str(tlm_project))
        assert isinstance(result, str)
        assert "TLM" in result

    def test_returns_install_message_when_no_tlm(self, tmp_path):
        """Should tell user to run tlm install when .tlm/ missing."""
        result = hook_session_start(str(tmp_path))
        assert "install" in result.lower()

    def test_includes_phase_info(self, tlm_project):
        """Session start should show current phase."""
        result = hook_session_start(str(tlm_project))
        assert "idle" in result.lower()

    def test_includes_quality_level(self, tlm_project):
        """Session start should show quality level."""
        result = hook_session_start(str(tlm_project))
        assert "standard" in result.lower()

    def test_includes_active_gaps(self, tlm_project):
        """Session start should show active gaps."""
        add_gap(str(tlm_project), {
            "id": "cicd", "type": "cicd", "category": "CI/CD",
            "severity": "critical", "description": "No CI/CD pipeline",
        })

        result = hook_session_start(str(tlm_project))
        assert "gap" in result.lower() or "CI/CD" in result


class TestHookPromptSubmit:
    def test_idle_phase_returns_classify_context(self, tlm_project):
        """In idle phase, should tell Claude to classify the request."""
        result = hook_prompt_submit(str(tlm_project), "Add auth")
        assert "additionalContext" in result
        assert "classify" in result["additionalContext"].lower()

    def test_tlm_active_returns_interview_context(self, tlm_project):
        """In tlm_active phase, should remind Claude of interview mode."""
        write_state(str(tlm_project), {"phase": "tlm_active", "activity_type": "feature"})

        result = hook_prompt_submit(str(tlm_project), "What about OAuth?")
        assert "additionalContext" in result
        assert "interview" in result["additionalContext"].lower()

    def test_implementation_returns_tdd_context(self, tlm_project):
        """In implementation phase, should remind Claude of TDD."""
        write_state(str(tlm_project), {"phase": "implementation"})

        result = hook_prompt_submit(str(tlm_project), "Let me code this")
        assert "additionalContext" in result
        assert "TDD" in result["additionalContext"] or "test" in result["additionalContext"].lower()

    def test_gap_warning_when_prompt_matches_gap(self, tlm_project):
        """Should warn when user mentions something related to an active gap."""
        add_gap(str(tlm_project), {
            "id": "auth", "type": "auth", "category": "Security",
            "severity": "critical", "description": "No authentication implemented",
        })

        result = hook_prompt_submit(str(tlm_project), "auth isn't working")
        assert "additionalContext" in result
        # Should mention the gap
        ctx = result["additionalContext"]
        assert "auth" in ctx.lower() or "gap" in ctx.lower()


class TestHookGuard:
    def test_idle_allows_writes(self, tlm_project):
        """In idle phase, writes should be allowed."""
        result = hook_guard(str(tlm_project), {
            "tool_name": "Write",
            "tool_input": {"file_path": "/project/app.py"},
        })
        assert result.get("decision") != "block"

    def test_tlm_active_blocks_source_writes(self, tlm_project):
        """In tlm_active phase, source code writes should be blocked."""
        write_state(str(tlm_project), {"phase": "tlm_active", "activity_type": "feature"})

        result = hook_guard(str(tlm_project), {
            "tool_name": "Write",
            "tool_input": {"file_path": "/project/app.py"},
        })
        assert result.get("decision") == "block"

    def test_tlm_active_allows_test_writes(self, tlm_project):
        """In tlm_active phase, test file writes should be allowed."""
        write_state(str(tlm_project), {"phase": "tlm_active", "activity_type": "feature"})

        result = hook_guard(str(tlm_project), {
            "tool_name": "Write",
            "tool_input": {"file_path": "/project/tests/test_app.py"},
        })
        assert result.get("decision") != "block"

    def test_tlm_active_allows_tlm_file_writes(self, tlm_project):
        """In tlm_active phase, .tlm/ file writes should be allowed."""
        write_state(str(tlm_project), {"phase": "tlm_active", "activity_type": "feature"})

        result = hook_guard(str(tlm_project), {
            "tool_name": "Write",
            "tool_input": {"file_path": str(tlm_project / ".tlm" / "specs" / "auth.md")},
        })
        assert result.get("decision") != "block"

    def test_implementation_blocks_without_tests(self, tlm_project):
        """In implementation phase, source writes should block if no tests written."""
        write_state(str(tlm_project), {
            "phase": "implementation",
            "spec_review_status": "approved",
        })

        result = hook_guard(str(tlm_project), {
            "tool_name": "Write",
            "tool_input": {"file_path": "/project/app.py"},
        })
        assert result.get("decision") == "block"
        assert "test" in result.get("reason", "").lower()

    def test_implementation_allows_after_test_write(self, tlm_project):
        """In implementation phase, source writes allowed after writing tests."""
        write_state(str(tlm_project), {
            "phase": "implementation",
            "spec_review_status": "approved",
        })

        # First write a test file
        hook_guard(str(tlm_project), {
            "tool_name": "Write",
            "tool_input": {"file_path": "/project/tests/test_app.py"},
        })

        # Now source write should be allowed
        result = hook_guard(str(tlm_project), {
            "tool_name": "Write",
            "tool_input": {"file_path": "/project/app.py"},
        })
        assert result.get("decision") != "block"

    def test_non_write_tools_pass_through(self, tlm_project):
        """Non-Write/Edit tools should pass through."""
        result = hook_guard(str(tlm_project), {
            "tool_name": "Read",
            "tool_input": {"file_path": "/project/app.py"},
        })
        assert result == {}

    def test_gap_warning_on_related_file(self, tlm_project):
        """Writing to a file related to a known gap should warn."""
        add_gap(str(tlm_project), {
            "id": "auth", "type": "auth", "category": "Security",
            "severity": "critical", "description": "No authentication",
        })

        result = hook_guard(str(tlm_project), {
            "tool_name": "Write",
            "tool_input": {"file_path": "/project/auth.py"},
        })
        # Should contain a warning about the gap (not a block in idle)
        ctx = result.get("additionalContext", "")
        assert "auth" in ctx.lower() or "gap" in ctx.lower() or result == {}


class TestHookComplianceGate:
    def test_non_commit_passes_through(self, tlm_project):
        """Non-git-commit commands should pass through."""
        result = hook_compliance_gate(str(tlm_project), {
            "command": "python -m pytest tests/",
        })
        assert result.get("decision") != "block"

    def test_git_commit_gets_context(self, tlm_project):
        """git commit should get compliance context."""
        result = hook_compliance_gate(str(tlm_project), {
            "command": "git commit -m 'test'",
        })
        # Should return context or block (depending on quality level)
        assert "additionalContext" in result or "decision" in result


class TestHookDeploymentGate:
    def test_non_deploy_passes_through(self, tlm_project):
        """Non-deployment commands should pass through."""
        result = hook_deployment_gate(str(tlm_project), {
            "command": "python app.py",
        })
        assert result == {}

    def test_firebase_deploy_blocked(self, tlm_project):
        """firebase deploy should be blocked."""
        result = hook_deployment_gate(str(tlm_project), {
            "command": "firebase deploy",
        })
        assert result.get("decision") == "block"

    def test_docker_push_blocked(self, tlm_project):
        """docker push should be blocked."""
        result = hook_deployment_gate(str(tlm_project), {
            "command": "docker push myapp:latest",
        })
        assert result.get("decision") == "block"

    def test_git_push_prod_blocked(self, tlm_project):
        """git push to production should be blocked."""
        result = hook_deployment_gate(str(tlm_project), {
            "command": "git push origin production",
        })
        assert result.get("decision") == "block"


class TestHookStop:
    def test_returns_empty_when_no_tlm(self, tmp_path):
        """Should return empty when .tlm/ doesn't exist."""
        result = hook_stop(str(tmp_path))
        assert result == {}

    def test_returns_dict(self, tlm_project):
        """Should return a dict."""
        result = hook_stop(str(tlm_project))
        assert isinstance(result, dict)
