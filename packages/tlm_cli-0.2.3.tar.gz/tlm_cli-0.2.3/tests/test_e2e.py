"""E2E tests — full flow: auth → install → scan → gaps → hooks intercept."""

import json
import pytest
from unittest.mock import patch, MagicMock, AsyncMock
from click.testing import CliRunner
from pathlib import Path

from tlm.cli import main
from tlm.gaps import load_gaps, get_active_gaps, add_gap, update_gap_status, GapStatus
from tlm.state import read_state, write_state
from tlm.config import save_project_config, load_project_config
from tlm.hooks import (
    hook_session_start,
    hook_prompt_submit,
    hook_guard,
    hook_compliance_gate,
    hook_deployment_gate,
)


MOCK_ASSESS = {
    "recommendations": [
        {"id": "cicd", "type": "cicd", "category": "CI/CD",
         "severity": "critical", "description": "No CI/CD pipeline detected", "fixable": True},
        {"id": "testing", "type": "testing", "category": "Testing",
         "severity": "critical", "description": "No tests found", "fixable": True},
        {"id": "staging", "type": "staging", "category": "Infrastructure",
         "severity": "high", "description": "No staging environment", "fixable": True},
        {"id": "monitoring", "type": "monitoring", "category": "Ops",
         "severity": "medium", "description": "No monitoring setup", "fixable": True},
    ],
    "profile": {"stack": "Python Flask", "has_ci": False},
}


class TestFullInstallFlow:
    @patch("tlm.cli.Installer")
    def test_install_creates_full_project_structure(self, mock_installer_cls, tmp_path):
        """Full install flow should create .tlm/ with all artifacts."""
        mock_installer = MagicMock()
        mock_installer.scan_project.return_value = {"file_tree": "app.py", "samples": "code"}
        mock_installer.assess.return_value = MOCK_ASSESS
        mock_installer_cls.return_value = mock_installer

        runner = CliRunner()
        # Accept high quality, decline to fix gaps
        result = runner.invoke(main, ["install", "--path", str(tmp_path)], input="\nn\n")

        assert result.exit_code == 0
        mock_installer.init_project_dir.assert_called_once()
        mock_installer.scan_project.assert_called_once()
        mock_installer.assess.assert_called_once()
        mock_installer.save_quality_tier.assert_called_once_with("high")
        mock_installer.populate_gaps.assert_called_once()
        mock_installer.install_hooks.assert_called_once()
        mock_installer.finalize.assert_called_once()


class TestGapLifecycleE2E:
    def test_gap_detect_defer_resolve(self, tmp_path):
        """Gaps should flow: detected → deferred → re-detected next session."""
        # Install creates gaps
        (tmp_path / ".tlm").mkdir(parents=True)
        add_gap(str(tmp_path), {
            "id": "cicd", "type": "cicd", "category": "CI/CD",
            "severity": "critical", "description": "No CI/CD",
        })
        add_gap(str(tmp_path), {
            "id": "testing", "type": "testing", "category": "Testing",
            "severity": "critical", "description": "No tests",
        })

        # User defers one
        update_gap_status(str(tmp_path), "cicd", GapStatus.DEFERRED)

        active = get_active_gaps(str(tmp_path))
        assert len(active) == 2  # Deferred is still active (warns next session)
        assert any(g["id"] == "cicd" and g["status"] == "deferred" for g in active)

        # User resolves one
        update_gap_status(str(tmp_path), "testing", GapStatus.RESOLVED)

        active = get_active_gaps(str(tmp_path))
        assert len(active) == 1
        assert active[0]["id"] == "cicd"

    def test_gap_dismiss_suppresses_permanently(self, tmp_path):
        """Dismissed gaps should be permanently suppressed."""
        (tmp_path / ".tlm").mkdir(parents=True)
        add_gap(str(tmp_path), {
            "id": "monitoring", "type": "monitoring", "category": "Ops",
            "severity": "medium", "description": "No monitoring",
        })

        update_gap_status(str(tmp_path), "monitoring", GapStatus.DISMISSED,
                         reason="Not needed for MVP")

        active = get_active_gaps(str(tmp_path))
        assert len(active) == 0


class TestHookInterceptionE2E:
    def test_session_start_shows_gaps_after_install(self, tmp_path):
        """Session start after install should show detected gaps."""
        (tmp_path / ".tlm").mkdir(parents=True)
        (tmp_path / ".tlm" / "specs").mkdir()
        (tmp_path / ".tlm" / "cache").mkdir()
        write_state(str(tmp_path), {"phase": "idle"})
        save_project_config(str(tmp_path), {"quality_control": "high"})
        add_gap(str(tmp_path), {
            "id": "cicd", "type": "cicd", "category": "CI/CD",
            "severity": "critical", "description": "No CI/CD pipeline",
        })

        result = hook_session_start(str(tmp_path))
        assert "TLM" in result
        assert "gap" in result.lower() or "CI/CD" in result

    def test_interview_blocks_source_writes(self, tmp_path):
        """During interview phase, source code writes should be blocked."""
        (tmp_path / ".tlm").mkdir(parents=True)
        write_state(str(tmp_path), {"phase": "tlm_active", "activity_type": "feature"})

        result = hook_guard(str(tmp_path), {
            "tool_name": "Write",
            "tool_input": {"file_path": "/project/app.py"},
        })
        assert result["decision"] == "block"

        # But test files pass
        result = hook_guard(str(tmp_path), {
            "tool_name": "Write",
            "tool_input": {"file_path": "/project/tests/test_app.py"},
        })
        assert result.get("decision") != "block"

    def test_tdd_enforcement_during_implementation(self, tmp_path):
        """Implementation phase should enforce TDD: tests before source."""
        (tmp_path / ".tlm").mkdir(parents=True)
        (tmp_path / ".tlm" / "cache").mkdir()
        write_state(str(tmp_path), {
            "phase": "implementation",
            "spec_review_status": "approved",
        })

        # Try writing source first → blocked
        result = hook_guard(str(tmp_path), {
            "tool_name": "Write",
            "tool_input": {"file_path": "/project/app.py"},
        })
        assert result["decision"] == "block"
        assert "test" in result["reason"].lower()

        # Write test first
        hook_guard(str(tmp_path), {
            "tool_name": "Write",
            "tool_input": {"file_path": "/project/tests/test_app.py"},
        })

        # Now source write should pass
        result = hook_guard(str(tmp_path), {
            "tool_name": "Write",
            "tool_input": {"file_path": "/project/app.py"},
        })
        assert result.get("decision") != "block"

    def test_deployment_always_blocked(self, tmp_path):
        """Deploy commands should always be blocked."""
        (tmp_path / ".tlm").mkdir(parents=True)
        write_state(str(tmp_path), {"phase": "idle"})

        for cmd in ["firebase deploy", "docker push myapp", "git push origin production"]:
            result = hook_deployment_gate(str(tmp_path), {"command": cmd})
            assert result.get("decision") == "block", f"Expected block for: {cmd}"

    def test_prompt_warns_about_matching_gap(self, tmp_path):
        """Prompt mentioning a gap keyword should get a warning."""
        (tmp_path / ".tlm").mkdir(parents=True)
        write_state(str(tmp_path), {"phase": "idle"})
        add_gap(str(tmp_path), {
            "id": "auth", "type": "auth", "category": "Security",
            "severity": "critical", "description": "No authentication system",
        })

        result = hook_prompt_submit(str(tmp_path), "the auth is broken")
        ctx = result.get("additionalContext", "")
        assert "auth" in ctx.lower() or "gap" in ctx.lower()


class TestQualityTierEffects:
    def test_high_quality_shows_in_session_start(self, tmp_path):
        """High quality should be visible in session context."""
        (tmp_path / ".tlm").mkdir(parents=True)
        write_state(str(tmp_path), {"phase": "idle"})
        save_project_config(str(tmp_path), {"quality_control": "high"})

        result = hook_session_start(str(tmp_path))
        assert "high" in result.lower()

    def test_quality_persists_across_reads(self, tmp_path):
        """Quality tier should persist across config reads."""
        (tmp_path / ".tlm").mkdir(parents=True)
        save_project_config(str(tmp_path), {"quality_control": "relaxed"})

        config = load_project_config(str(tmp_path))
        assert config["quality_control"] == "relaxed"


class TestScanWithoutProjectId:
    @patch("tlm.cli.Installer")
    def test_scan_no_project_id_needed(self, mock_installer_cls, tmp_path):
        """Scan should work without --project-id (V2 doesn't need it from user)."""
        mock_installer = MagicMock()
        mock_installer.scan_project.return_value = {"file_tree": "app.py", "samples": "code"}
        mock_installer.assess.return_value = {
            "recommendations": [
                {"id": "cicd", "type": "cicd", "category": "CI/CD",
                 "severity": "critical", "description": "No CI/CD", "fixable": True},
            ],
            "profile": {"stack": "Python"},
        }
        mock_installer_cls.return_value = mock_installer

        runner = CliRunner()
        result = runner.invoke(main, ["scan", "--path", str(tmp_path)])

        assert result.exit_code == 0
        assert "CI/CD" in result.output or "cicd" in result.output
