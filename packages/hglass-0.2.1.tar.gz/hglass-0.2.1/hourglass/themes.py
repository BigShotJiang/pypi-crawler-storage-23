"""Color themes for the hourglass timer."""

from dataclasses import dataclass


@dataclass(frozen=True)
class Theme:
    """Color scheme for hourglass rendering."""
    cap: str        # top/bottom caps (═══)
    frame: str      # bulb borders (║)
    taper: str      # taper lines (╲╱)
    sand: str       # sand blocks (░)
    grain: str      # falling neck grain
    timer: str      # big digit timer
    label: str      # label text above hourglass
    paused: str     # "PAUSED" indicator
    round_info: str # round info text below timer


DARK = Theme(
    cap="color(39)",
    frame="color(248)",
    taper="color(245)",
    sand="bold color(214)",
    grain="bold color(214)",
    timer="bold color(39)",
    label="bold color(255)",
    paused="bold color(214)",
    round_info="color(245)",
)

LIGHT = Theme(
    cap="bold color(25)",
    frame="color(238)",
    taper="color(241)",
    sand="bold color(166)",
    grain="bold color(166)",
    timer="bold color(25)",
    label="bold color(232)",
    paused="bold color(166)",
    round_info="color(241)",
)

RETRO = Theme(
    cap="bold color(46)",
    frame="color(34)",
    taper="color(28)",
    sand="bold color(46)",
    grain="bold color(46)",
    timer="bold color(46)",
    label="bold color(46)",
    paused="bold color(196)",
    round_info="color(34)",
)

THEMES: dict[str, Theme] = {
    "dark": DARK,
    "light": LIGHT,
    "retro": RETRO,
}


def get_theme(name: str) -> Theme:
    """Return a theme by name, defaulting to dark."""
    return THEMES.get(name, DARK)
