"""Desktop notifications and bell sounds."""

import subprocess
import sys

from rich.console import Console


def send_notification(title: str, message: str) -> None:
    """Send a desktop notification. Silently degrades if unavailable."""
    try:
        if sys.platform == "darwin":
            subprocess.run(
                ["osascript", "-e",
                 f'display notification "{message}" with title "{title}"'],
                capture_output=True, timeout=5,
            )
        elif sys.platform.startswith("linux"):
            subprocess.run(
                ["notify-send", title, message],
                capture_output=True, timeout=5,
            )
    except (FileNotFoundError, subprocess.TimeoutExpired, OSError):
        pass


def play_bell(console: Console) -> None:
    """Ring the terminal bell."""
    console.bell()
