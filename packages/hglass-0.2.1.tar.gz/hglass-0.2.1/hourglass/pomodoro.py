"""Pomodoro work/break cycle orchestration."""

from rich.console import Console

from .themes import Theme, get_theme
from .timer import run_timer


def run_pomodoro(work_mins: float = 25, break_mins: float = 5,
                 rounds: int = 4, label: str | None = None,
                 theme: Theme | None = None, silent: bool = False,
                 notify: bool = True) -> None:
    """Run a pomodoro cycle: work → break → ... → work."""
    if theme is None:
        theme = get_theme("dark")

    console = Console()
    completed_rounds = 0
    total_work = 0.0
    total_break = 0.0

    for r in range(1, rounds + 1):
        # Work session
        work_label = label or "Work"
        round_info = f"Round {r}/{rounds} — Work"
        status = run_timer(
            work_mins * 60,
            label=work_label, theme=theme,
            silent=silent, notify=notify,
            round_info=round_info,
        )
        if status == "interrupted":
            total_work += work_mins  # approximate
            break

        completed_rounds += 1
        total_work += work_mins

        # Break (skip after last round)
        if r < rounds:
            round_info = f"Round {r}/{rounds} — Break"
            status = run_timer(
                break_mins * 60,
                label="Break", theme=theme,
                silent=silent, notify=notify,
                round_info=round_info,
            )
            if status == "interrupted":
                break
            total_break += break_mins

    # Summary
    console.print()
    console.print("  [bold]Pomodoro Summary[/bold]")
    console.print(f"  Completed rounds: {completed_rounds}/{rounds}")
    console.print(f"  Total focus time: {total_work:.1f} min")
    console.print(f"  Total break time: {total_break:.1f} min")
    console.print()
