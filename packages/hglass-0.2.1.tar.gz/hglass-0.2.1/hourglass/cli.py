"""CLI entry point for hglass."""

import argparse
import sys

from .pomodoro import run_pomodoro
from .themes import THEMES, get_theme
from .timer import run_timer


def _add_common_args(parser: argparse.ArgumentParser) -> None:
    """Add flags shared between timer and pomodoro subcommand."""
    parser.add_argument(
        "--label", "-l", type=str, default=None,
        help="label text displayed above the hourglass",
    )
    parser.add_argument(
        "--theme", "-t", type=str, default="dark",
        choices=list(THEMES.keys()),
        help="color theme (default: dark)",
    )
    parser.add_argument(
        "--silent", "-s", action="store_true",
        help="suppress terminal bell on completion",
    )
    parser.add_argument(
        "--no-notify", action="store_true",
        help="suppress desktop notification on completion",
    )


def _build_timer_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="hglass",
        description="Terminal hourglass timer with animated ASCII art.",
    )
    parser.add_argument(
        "minutes", type=float,
        help="timer duration in minutes (e.g. 25, 0.1)",
    )
    _add_common_args(parser)
    return parser


def _build_pomo_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="hglass pomo",
        description="Pomodoro work/break cycle timer.",
    )
    parser.add_argument(
        "--work", "-w", type=float, default=25,
        help="work duration in minutes (default: 25)",
    )
    parser.add_argument(
        "--break", "-b", type=float, default=5, dest="break_mins",
        help="break duration in minutes (default: 5)",
    )
    parser.add_argument(
        "--rounds", "-r", type=int, default=4,
        help="number of work rounds (default: 4)",
    )
    _add_common_args(parser)
    return parser


def main(argv: list[str] | None = None) -> None:
    args = argv if argv is not None else sys.argv[1:]

    # Route to pomodoro if first arg is pomo/pomodoro
    if args and args[0] in ("pomo", "pomodoro"):
        parser = _build_pomo_parser()
        parsed = parser.parse_args(args[1:])
        theme = get_theme(parsed.theme)
        run_pomodoro(
            work_mins=parsed.work,
            break_mins=parsed.break_mins,
            rounds=parsed.rounds,
            label=parsed.label,
            theme=theme,
            silent=parsed.silent,
            notify=not parsed.no_notify,
        )
    else:
        parser = _build_timer_parser()
        if not args or args[0] in ("-h", "--help"):
            parser.print_help()
            print("\nSubcommands:")
            print("  pomo (pomodoro)   run a pomodoro work/break cycle")
            print("                    use 'hglass pomo --help' for details")
            if not args:
                sys.exit(1)
            sys.exit(0)

        parsed = parser.parse_args(args)
        if parsed.minutes <= 0:
            print("Error: duration must be positive.")
            sys.exit(1)

        theme = get_theme(parsed.theme)
        run_timer(
            parsed.minutes * 60,
            label=parsed.label,
            theme=theme,
            silent=parsed.silent,
            notify=not parsed.no_notify,
        )


if __name__ == "__main__":
    main()
