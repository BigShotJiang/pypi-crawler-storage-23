from .client import (
    Foil,
    SpanKind,
    MediaCategory,
    ContentBlock,
    TextBlock,
    MediaBlock,
    content,
)
from .tracer import (
    FoilTracer,
    TraceContext,
    Span,
    create_foil_tracer,
)

__version__ = "0.6.0"
__all__ = [
    # Core client
    "Foil",
    # Enums
    "SpanKind",
    "MediaCategory",
    # Content blocks
    "ContentBlock",
    "TextBlock",
    "MediaBlock",
    "content",
    # Tracer
    "FoilTracer",
    "TraceContext",
    "Span",
    "create_foil_tracer",
]

# OTEL support (optional - requires opentelemetry-sdk)
# Access via: from foil.otel import Foil, FoilSpanProcessor
try:
    from .otel import (
        Foil as OtelFoil,
        FoilSpanProcessor,
        add_attachment,
        attach_image,
        attach_code,
        attach_text,
    )
    __all__.extend([
        "OtelFoil",
        "FoilSpanProcessor",
        "add_attachment",
        "attach_image",
        "attach_code",
        "attach_text",
    ])
except ImportError:
    # OTEL dependencies not installed
    pass
