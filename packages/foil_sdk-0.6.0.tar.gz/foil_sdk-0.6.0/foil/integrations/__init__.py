"""
Foil Integrations - Framework integrations for automatic tracing.
"""

__all__ = []
