# IDE configuration
Due to the use of Maturin, some IDEs may need specific configuration

## RustRover
For the following sections, denote the env var "PYO3_PYTHON" as the full path to the python executable of your given venv with maturin installed
- Settings / Rust / Environment Variables (you may need to double click to access this)
- Settings / Rust External Linters / Environment Variables
- Build Configuration