__version__ = "0.7.0"
__version_message__ = "%(prog)s, malcolm3utils version %(version)s"
