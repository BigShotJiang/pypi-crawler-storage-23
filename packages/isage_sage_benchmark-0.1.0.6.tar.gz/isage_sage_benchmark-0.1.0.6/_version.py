"""Version information for sage-benchmark."""

__version__ = "0.1.0.6"
__author__ = "IntelliStream Team"
__email__ = "shuhao_zhang@hust.edu.cn"
