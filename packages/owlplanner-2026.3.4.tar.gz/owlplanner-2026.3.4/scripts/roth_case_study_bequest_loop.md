# Roth conversion case study (Kim + Sam) - Bequest focus

Kim and Sam are a recently retired couple with roughly $3M of assets split across taxable, tax-deferred, and Roth accounts, looking to spend their savings over retirement with a steady 60/40 allocation. In this study, net spending is fixed at $145,000 per year (today's dollars), and the focus is on how Roth conversions affect the after-tax value of the total bequest from all savings accounts under comparable market conditions.

All runs use the Medicare/IRMAA self-consistent loop option, so each market case appears once. Net benefit is computed relative to the zero-conversion baseline for each heirs' tax rate. Two additional columns report total Roth conversions in today's dollars and the ratio of bequest benefit to total Roth conversions (both in today's dollars). Each scenario includes one table per heirs' tax rate plus a summary table that highlights the best net benefit for each heirs rate.

Generated: 2026-01-20 20:55:19

## Case 1: Fixed conservative rates (loop) - heirs 33%

|   max Roth X (nominal k$) | net spending (today's $)   | net bequest (today's $)   | net benefit (today's $)   | net benefit (%)   | total Roth X (nominal $)   | total Roth converted (today's $)   | benefit / total Roth (today's $)   |
|--------------------------:|:---------------------------|:--------------------------|:--------------------------|:------------------|:---------------------------|:-----------------------------------|:-----------------------------------|
|                       200 | $145,000                   | $1,081,031                | $151,275                  | 13.99%            | $1,032,771                 | $978,767                           | 15.46%                             |
|                       150 | $145,000                   | $1,081,031                | $151,275                  | 13.99%            | $1,032,771                 | $978,767                           | 15.46%                             |
|                       100 | $145,000                   | $1,083,996                | $154,240                  | 14.23%            | $1,044,079                 | $984,447                           | 15.67%                             |
|                        50 | $145,000                   | $1,055,956                | $126,200                  | 11.95%            | $973,012                   | $863,660                           | 14.61%                             |
|                        10 | $145,000                   | $998,878                  | $69,122                   | 6.92%             | $570,000                   | $399,247                           | 17.31%                             |
|                         0 | $145,000                   | $929,756                  | $0                        | 0.00%             | $0                         | $0                                 | 0.00%                              |

## Case 1: Fixed conservative rates (loop) - heirs 22%

|   max Roth X (nominal k$) | net spending (today's $)   | net bequest (today's $)   | net benefit (today's $)   | net benefit (%)   | total Roth X (nominal $)   | total Roth converted (today's $)   | benefit / total Roth (today's $)   |
|--------------------------:|:---------------------------|:--------------------------|:--------------------------|:------------------|:---------------------------|:-----------------------------------|:-----------------------------------|
|                       200 | $145,000                   | $1,081,031                | $107,242                  | 9.92%             | $1,032,771                 | $978,767                           | 10.96%                             |
|                       150 | $145,000                   | $1,081,031                | $107,242                  | 9.92%             | $1,032,771                 | $978,767                           | 10.96%                             |
|                       100 | $145,000                   | $1,083,996                | $110,207                  | 10.17%            | $1,044,079                 | $984,447                           | 11.19%                             |
|                        50 | $145,000                   | $1,069,217                | $95,428                   | 8.93%             | $831,782                   | $753,234                           | 12.67%                             |
|                        10 | $145,000                   | $1,028,183                | $54,394                   | 5.29%             | $417,050                   | $321,058                           | 16.94%                             |
|                         0 | $145,000                   | $973,789                  | $0                        | 0.00%             | $0                         | $0                                 | 0.00%                              |

## Case 1: Fixed conservative rates (loop) - heirs 0%

|   max Roth X (nominal k$) | net spending (today's $)   | net bequest (today's $)   | net benefit (today's $)   | net benefit (%)   | total Roth X (nominal $)   | total Roth converted (today's $)   | benefit / total Roth (today's $)   |
|--------------------------:|:---------------------------|:--------------------------|:--------------------------|:------------------|:---------------------------|:-----------------------------------|:-----------------------------------|
|                       200 | $145,000                   | $1,177,657                | $83,594                   | 7.10%             | $827,017                   | $769,466                           | 10.86%                             |
|                       150 | $145,000                   | $1,177,657                | $83,594                   | 7.10%             | $827,017                   | $769,466                           | 10.86%                             |
|                       100 | $145,000                   | $1,177,657                | $83,594                   | 7.10%             | $827,017                   | $769,466                           | 10.86%                             |
|                        50 | $145,000                   | $1,174,429                | $80,367                   | 6.84%             | $719,213                   | $661,165                           | 12.16%                             |
|                        10 | $145,000                   | $1,139,034                | $44,972                   | 3.95%             | $282,402                   | $237,054                           | 18.97%                             |
|                         0 | $145,000                   | $1,094,062                | $0                        | 0.00%             | $0                         | $0                                 | 0.00%                              |

## Case 1: Fixed conservative rates summary (best by heirs rate)

|   heirs tax rate (%) |   max Roth X (nominal k$) | net benefit (today's $)   | total Roth converted (today's $)   | benefit / total Roth (today's $)   |
|---------------------:|--------------------------:|:--------------------------|:-----------------------------------|:-----------------------------------|
|                    0 |                       200 | $83,594                   | $769,466                           | 10.86%                             |
|                   22 |                       100 | $110,207                  | $984,447                           | 11.19%                             |
|                   33 |                       100 | $154,240                  | $984,447                           | 15.67%                             |

## Case 2: Fixed optimistic rates (loop) - heirs 33%

|   max Roth X (nominal k$) | net spending (today's $)   | net bequest (today's $)   | net benefit (today's $)   | net benefit (%)   | total Roth X (nominal $)   | total Roth converted (today's $)   | benefit / total Roth (today's $)   |
|--------------------------:|:---------------------------|:--------------------------|:--------------------------|:------------------|:---------------------------|:-----------------------------------|:-----------------------------------|
|                       200 | $145,000                   | $2,547,251                | $343,227                  | 13.47%            | $1,248,498                 | $1,178,764                         | 29.12%                             |
|                       150 | $145,000                   | $2,547,251                | $343,227                  | 13.47%            | $1,248,498                 | $1,178,764                         | 29.12%                             |
|                       100 | $145,000                   | $2,545,457                | $341,433                  | 13.41%            | $1,252,308                 | $1,165,045                         | 29.31%                             |
|                        50 | $145,000                   | $2,496,614                | $292,590                  | 11.72%            | $1,200,000                 | $1,035,597                         | 28.25%                             |
|                        10 | $145,000                   | $2,308,776                | $104,752                  | 4.54%             | $570,000                   | $399,247                           | 26.24%                             |
|                         0 | $145,000                   | $2,204,024                | $0                        | 0.00%             | $0                         | $0                                 | 0.00%                              |

## Case 2: Fixed optimistic rates (loop) - heirs 22%

|   max Roth X (nominal k$) | net spending (today's $)   | net bequest (today's $)   | net benefit (today's $)   | net benefit (%)   | total Roth X (nominal $)   | total Roth converted (today's $)   | benefit / total Roth (today's $)   |
|--------------------------:|:---------------------------|:--------------------------|:--------------------------|:------------------|:---------------------------|:-----------------------------------|:-----------------------------------|
|                       200 | $145,000                   | $2,547,251                | $279,188                  | 10.96%            | $1,248,498                 | $1,178,764                         | 23.68%                             |
|                       150 | $145,000                   | $2,547,251                | $279,188                  | 10.96%            | $1,248,498                 | $1,178,764                         | 23.68%                             |
|                       100 | $145,000                   | $2,553,154                | $285,091                  | 11.17%            | $1,197,437                 | $1,118,552                         | 25.49%                             |
|                        50 | $145,000                   | $2,511,875                | $243,812                  | 9.71%             | $1,033,329                 | $910,107                           | 26.79%                             |
|                        10 | $145,000                   | $2,365,929                | $97,866                   | 4.14%             | $570,000                   | $399,247                           | 24.51%                             |
|                         0 | $145,000                   | $2,268,063                | $0                        | 0.00%             | $0                         | $0                                 | 0.00%                              |

## Case 2: Fixed optimistic rates (loop) - heirs 0%

|   max Roth X (nominal k$) | net spending (today's $)   | net bequest (today's $)   | net benefit (today's $)   | net benefit (%)   | total Roth X (nominal $)   | total Roth converted (today's $)   | benefit / total Roth (today's $)   |
|--------------------------:|:---------------------------|:--------------------------|:--------------------------|:------------------|:---------------------------|:-----------------------------------|:-----------------------------------|
|                       200 | $145,000                   | $2,671,504                | $213,155                  | 7.98%             | $1,003,134                 | $945,522                           | 22.54%                             |
|                       150 | $145,000                   | $2,668,466                | $210,117                  | 7.87%             | $1,004,342                 | $946,909                           | 22.19%                             |
|                       100 | $145,000                   | $2,672,786                | $214,437                  | 8.02%             | $1,016,998                 | $956,906                           | 22.41%                             |
|                        50 | $145,000                   | $2,653,361                | $195,012                  | 7.35%             | $800,000                   | $727,751                           | 26.80%                             |
|                        10 | $145,000                   | $2,531,346                | $72,998                   | 2.88%             | $380,000                   | $299,780                           | 24.35%                             |
|                         0 | $145,000                   | $2,458,349                | $0                        | 0.00%             | $0                         | $0                                 | 0.00%                              |

## Case 2: Fixed optimistic rates summary (best by heirs rate)

|   heirs tax rate (%) |   max Roth X (nominal k$) | net benefit (today's $)   | total Roth converted (today's $)   | benefit / total Roth (today's $)   |
|---------------------:|--------------------------:|:--------------------------|:-----------------------------------|:-----------------------------------|
|                    0 |                       100 | $214,437                  | $956,906                           | 22.41%                             |
|                   22 |                       100 | $285,091                  | $1,118,552                         | 25.49%                             |
|                   33 |                       200 | $343,227                  | $1,178,764                         | 29.12%                             |

## Case 3: Historical rates from 1966 (loop) - heirs 33%

|   max Roth X (nominal k$) | net spending (today's $)   | net bequest (today's $)   | net benefit (today's $)   | net benefit (%)   | total Roth X (nominal $)   | total Roth converted (today's $)   | benefit / total Roth (today's $)   |
|--------------------------:|:---------------------------|:--------------------------|:--------------------------|:------------------|:---------------------------|:-----------------------------------|:-----------------------------------|
|                       200 | $145,000                   | $1,222,025                | $357,717                  | 29.27%            | $784,260                   | $718,555                           | 49.78%                             |
|                       150 | $145,000                   | $1,222,025                | $357,717                  | 29.27%            | $784,260                   | $718,555                           | 49.78%                             |
|                       100 | $145,000                   | $1,222,025                | $357,717                  | 29.27%            | $784,260                   | $718,555                           | 49.78%                             |
|                        50 | $145,000                   | $1,205,671                | $341,362                  | 28.31%            | $700,000                   | $621,645                           | 54.91%                             |
|                        10 | $145,000                   | $1,056,556                | $192,247                  | 18.20%            | $339,796                   | $229,680                           | 83.70%                             |
|                         0 | $145,000                   | $864,309                  | $0                        | 0.00%             | $0                         | $0                                 | 0.00%                              |

## Case 3: Historical rates from 1966 (loop) - heirs 22%

|   max Roth X (nominal k$) | net spending (today's $)   | net bequest (today's $)   | net benefit (today's $)   | net benefit (%)   | total Roth X (nominal $)   | total Roth converted (today's $)   | benefit / total Roth (today's $)   |
|--------------------------:|:---------------------------|:--------------------------|:--------------------------|:------------------|:---------------------------|:-----------------------------------|:-----------------------------------|
|                       200 | $145,000                   | $1,222,025                | $313,771                  | 25.68%            | $784,260                   | $718,555                           | 43.67%                             |
|                       150 | $145,000                   | $1,222,025                | $313,771                  | 25.68%            | $784,260                   | $718,555                           | 43.67%                             |
|                       100 | $145,000                   | $1,222,025                | $313,771                  | 25.68%            | $784,260                   | $718,555                           | 43.67%                             |
|                        50 | $145,000                   | $1,205,671                | $297,417                  | 24.67%            | $700,000                   | $621,645                           | 47.84%                             |
|                        10 | $145,000                   | $1,067,412                | $159,157                  | 14.91%            | $339,796                   | $229,680                           | 69.30%                             |
|                         0 | $145,000                   | $908,254                  | $0                        | 0.00%             | $0                         | $0                                 | 0.00%                              |

## Case 3: Historical rates from 1966 (loop) - heirs 0%

|   max Roth X (nominal k$) | net spending (today's $)   | net bequest (today's $)   | net benefit (today's $)   | net benefit (%)   | total Roth X (nominal $)   | total Roth converted (today's $)   | benefit / total Roth (today's $)   |
|--------------------------:|:---------------------------|:--------------------------|:--------------------------|:------------------|:---------------------------|:-----------------------------------|:-----------------------------------|
|                       200 | $145,000                   | $1,290,383                | $203,470                  | 15.77%            | $784,260                   | $718,555                           | 28.32%                             |
|                       150 | $145,000                   | $1,290,383                | $203,470                  | 15.77%            | $784,260                   | $718,555                           | 28.32%                             |
|                       100 | $145,000                   | $1,288,421                | $201,508                  | 15.64%            | $784,260                   | $718,555                           | 28.04%                             |
|                        50 | $145,000                   | $1,274,406                | $187,493                  | 14.71%            | $700,000                   | $621,645                           | 30.16%                             |
|                        10 | $145,000                   | $1,184,405                | $97,492                   | 8.23%             | $300,000                   | $213,591                           | 45.64%                             |
|                         0 | $145,000                   | $1,086,913                | $0                        | 0.00%             | $0                         | $0                                 | 0.00%                              |

## Case 3: Historical rates from 1966 summary (best by heirs rate)

|   heirs tax rate (%) |   max Roth X (nominal k$) | net benefit (today's $)   | total Roth converted (today's $)   | benefit / total Roth (today's $)   |
|---------------------:|--------------------------:|:--------------------------|:-----------------------------------|:-----------------------------------|
|                    0 |                       200 | $203,470                  | $718,555                           | 28.32%                             |
|                   22 |                       200 | $313,771                  | $718,555                           | 43.67%                             |
|                   33 |                       200 | $357,717                  | $718,555                           | 49.78%                             |

## Case 4: Historical rates from 1991 (loop) - heirs 33%

|   max Roth X (nominal k$) | net spending (today's $)   | net bequest (today's $)   | net benefit (today's $)   | net benefit (%)   | total Roth X (nominal $)   | total Roth converted (today's $)   | benefit / total Roth (today's $)   |
|--------------------------:|:---------------------------|:--------------------------|:--------------------------|:------------------|:---------------------------|:-----------------------------------|:-----------------------------------|
|                       200 | $145,000                   | $12,132,620               | $2,510,157                | 20.69%            | $1,945,125                 | $1,818,378                         | 138.04%                            |
|                       150 | $145,000                   | $12,101,570               | $2,479,107                | 20.49%            | $2,160,292                 | $1,878,466                         | 131.98%                            |
|                       100 | $145,000                   | $12,051,895               | $2,429,432                | 20.16%            | $2,867,394                 | $2,276,074                         | 106.74%                            |
|                        50 | $145,000                   | $11,438,850               | $1,816,387                | 15.88%            | $2,850,000                 | $2,064,108                         | 88.00%                             |
|                        10 | $145,000                   | $9,998,798                | $376,335                  | 3.76%             | $570,000                   | $412,822                           | 91.16%                             |
|                         0 | $145,000                   | $9,622,463                | $0                        | 0.00%             | $0                         | $0                                 | 0.00%                              |

## Case 4: Historical rates from 1991 (loop) - heirs 22%

|   max Roth X (nominal k$) | net spending (today's $)   | net bequest (today's $)   | net benefit (today's $)   | net benefit (%)   | total Roth X (nominal $)   | total Roth converted (today's $)   | benefit / total Roth (today's $)   |
|--------------------------:|:---------------------------|:--------------------------|:--------------------------|:------------------|:---------------------------|:-----------------------------------|:-----------------------------------|
|                       200 | $145,000                   | $12,159,777               | $2,138,534                | 17.59%            | $1,881,853                 | $1,766,454                         | 121.06%                            |
|                       150 | $145,000                   | $12,123,874               | $2,102,630                | 17.34%            | $2,168,913                 | $1,878,459                         | 111.93%                            |
|                       100 | $145,000                   | $12,077,826               | $2,056,582                | 17.03%            | $2,668,822                 | $2,160,001                         | 95.21%                             |
|                        50 | $145,000                   | $11,535,956               | $1,514,712                | 13.13%            | $2,850,000                 | $2,064,108                         | 73.38%                             |
|                        10 | $145,000                   | $10,328,415               | $307,172                  | 2.97%             | $570,000                   | $412,822                           | 74.41%                             |
|                         0 | $145,000                   | $10,021,244               | $0                        | 0.00%             | $0                         | $0                                 | 0.00%                              |

## Case 4: Historical rates from 1991 (loop) - heirs 0%

|   max Roth X (nominal k$) | net spending (today's $)   | net bequest (today's $)   | net benefit (today's $)   | net benefit (%)   | total Roth X (nominal $)   | total Roth converted (today's $)   | benefit / total Roth (today's $)   |
|--------------------------:|:---------------------------|:--------------------------|:--------------------------|:------------------|:---------------------------|:-----------------------------------|:-----------------------------------|
|                       200 | $145,000                   | $12,336,429               | $1,504,322                | 12.19%            | $1,738,817                 | $1,635,113                         | 92.00%                             |
|                       150 | $145,000                   | $12,313,598               | $1,481,491                | 12.03%            | $1,641,487                 | $1,532,839                         | 96.65%                             |
|                       100 | $145,000                   | $12,296,150               | $1,464,043                | 11.91%            | $1,901,198                 | $1,633,989                         | 89.60%                             |
|                        50 | $145,000                   | $12,015,084               | $1,182,977                | 9.85%             | $2,011,528                 | $1,588,280                         | 74.48%                             |
|                        10 | $145,000                   | $11,100,496               | $268,389                  | 2.42%             | $420,000                   | $327,917                           | 81.85%                             |
|                         0 | $145,000                   | $10,832,107               | $0                        | 0.00%             | $0                         | $0                                 | 0.00%                              |

## Case 4: Historical rates from 1991 summary (best by heirs rate)

|   heirs tax rate (%) |   max Roth X (nominal k$) | net benefit (today's $)   | total Roth converted (today's $)   | benefit / total Roth (today's $)   |
|---------------------:|--------------------------:|:--------------------------|:-----------------------------------|:-----------------------------------|
|                    0 |                       200 | $1,504,322                | $1,635,113                         | 92.00%                             |
|                   22 |                       200 | $2,138,534                | $1,766,454                         | 121.06%                            |
|                   33 |                       200 | $2,510,157                | $1,818,378                         | 138.04%                            |

## Observations

- Case 1 (Fixed conservative rates): best net benefit at 100k (heirs 33%) is $154,240, ratio 15.67%.
- Case 2 (Fixed optimistic rates): best net benefit at 200k (heirs 33%) is $343,227, ratio 29.12%.
- Case 3 (Historical rates from 1966): best net benefit at 200k (heirs 33%) is $357,717, ratio 49.78%.
- Case 4 (Historical rates from 1991): best net benefit at 200k (heirs 33%) is $2,510,157, ratio 138.04%.
- Net bequest benefits (in dollars) remain positive across scenarios and heirs tax rates, but they are still smaller than the total after-tax bequest size.
- Fixed-rate scenarios show similar net benefit percentages despite different absolute bequest sizes, suggesting conversions are driven more by tax mechanics than return levels.
- The benefit-to-conversion ratio is a separate metric; historical-rate sequences tend to show higher ratios, indicating conversions can be more efficient per dollar converted when returns vary over time.
- Medicare and IRMAA premiums are accounted for via the self-consistent loop, so both the net benefit and the benefit-to-conversion ratio reflect the premium impacts of higher MAGI.
- The conversion cap that maximizes net benefit often sits in the mid range of tested values, though the highest cap can be best in some scenarios.

## Conclusions

- Across scenarios and heirs tax rates, best net bequest benefits occur with maximum Roth caps between 100k and 200k (mode 200k).
- The best-case bequest uplift ranges from $154,240 to $2,510,157 in today's dollars, which is smaller than (but still meaningful relative to) the total after-tax bequest.
- The benefit-to-conversion ratio for those best cases ranges from 15.67% to 138.04%, so each conversion dollar yields anywhere from a few cents to more than a dollar of added after-tax bequest in the best cases.

## Case details

Kim has $650k invested in taxable accounts, $1.5M in a 401k, and $60k in Roth IRAs. Sam has $250k in taxable accounts, $500k in a 403b, and $40k in Roth IRAs. Kim expects to live to age 89 while Sam to age 93. Kim will collect Social Security at age 70 with a $3,500 primary insurance amount (PIA). Sam will claim SS at full retirement age of 68 yo with a PIA of $2,000. They own a house that is fully paid that they expect to keep and leave as a bequest. They would like to spend all their savings during their retirement while leaving a bequest from remaining savings assets. They have just stopped working and have no anticipated wages for the next few years, creating what is believed to be a tax valley for converting funds to Roth accounts. They anticipate keeping their portfolio with a traditional split of 60/40 stocks/bonds. This constant allocation between all accounts is voluntary in order to avoid biases towards any type of savings account. The current (OBBBA) tax brackets are assumed to expire in 2032 and be replaced by (inflation-adjusted) brackets in effect before the Tax Cut and Job Act (TCJA). Four cases were considered where we assume 4 different scenarios for return rates: **Case 1)** fixed conservative return rates at 6.0% S&P 500, 4.0% for Baa Corporate bonds, 3.3% for 10-year T-Notes, and 2.8% inflation **Case 2)** fixed optimistic return rates at 8.0% S&P 500, 4.5% for Baa Corporate bonds, 3.3% for 10-year T-Notes, and 2.8% inflation **Case 3)** historical rates starting in 1966 **Case 4)** historical rates starting in 1991. Medicare/IRMAA premiums were solved iteratively using a self-consistent loop wrapping an optimization step.

