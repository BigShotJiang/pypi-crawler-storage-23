# Roth conversion case study (Kim + Sam)

Kim and Sam are a recently retired couple with roughly $3M of assets split across taxable, tax-deferred, and Roth accounts, looking to spend their savings over retirement with a steady 60/40 allocation. The goal here is to quantify how the maximum allowed Roth conversions change available net spending under comparable market conditions, while keeping the rest of the plan assumptions fixed.

All runs use the Medicare/IRMAA self-consistent loop option, so each market case appears once. Net spending is an annual value (today's dollars), totals are over the full plan, and net benefit is computed relative to the zero-conversion baseline. Two additional columns report total Roth conversions in today's dollars and the ratio of net spending benefit to total Roth conversions (both in today's dollars).

Generated: 2026-01-20 19:24:17

## Case 1: Fixed conservative rates (loop)

|   max Roth X (nominal k$) | net spending (today's $)   | total net spending (today's $)   | net benefit (today's $)   | net benefit (%)   | total Roth X (nominal $)   | total Roth converted (today's $)   | benefit / total Roth (today's $)   |
|--------------------------:|:---------------------------|:---------------------------------|:--------------------------|:------------------|:---------------------------|:-----------------------------------|:-----------------------------------|
|                       200 | $167,617                   | $5,196,122                       | $44,398                   | 0.85%             | $925,487                   | $884,591                           | 5.02%                              |
|                       150 | $167,617                   | $5,196,122                       | $44,398                   | 0.85%             | $925,487                   | $884,591                           | 5.02%                              |
|                       100 | $167,680                   | $5,198,076                       | $46,352                   | 0.89%             | $928,774                   | $883,212                           | 5.25%                              |
|                        50 | $167,301                   | $5,186,334                       | $34,609                   | 0.67%             | $800,000                   | $727,751                           | 4.76%                              |
|                        10 | $166,520                   | $5,162,128                       | $10,404                   | 0.20%             | $300,000                   | $249,033                           | 4.18%                              |
|                         0 | $166,185                   | $5,151,724                       | $0                        | 0.00%             | $0                         | $0                                 | 0.00%                              |

## Case 2: Fixed optimistic rates (loop)

|   max Roth X (nominal k$) | net spending (today's $)   | total net spending (today's $)   | net benefit (today's $)   | net benefit (%)   | total Roth X (nominal $)   | total Roth converted (today's $)   | benefit / total Roth (today's $)   |
|--------------------------:|:---------------------------|:---------------------------------|:--------------------------|:------------------|:---------------------------|:-----------------------------------|:-----------------------------------|
|                       200 | $185,758                   | $5,758,490                       | $45,306                   | 0.79%             | $990,283                   | $949,071                           | 4.77%                              |
|                       150 | $185,758                   | $5,758,490                       | $45,306                   | 0.79%             | $990,283                   | $949,071                           | 4.77%                              |
|                       100 | $185,878                   | $5,762,214                       | $49,030                   | 0.85%             | $994,907                   | $941,865                           | 5.21%                              |
|                        50 | $185,114                   | $5,738,536                       | $25,353                   | 0.44%             | $867,849                   | $782,151                           | 3.24%                              |
|                        10 | $184,395                   | $5,716,253                       | $3,069                    | 0.05%             | $275,613                   | $232,382                           | 1.32%                              |
|                         0 | $184,296                   | $5,713,184                       | $0                        | 0.00%             | $0                         | $0                                 | 0.00%                              |

## Case 3: Historical rates from 1966 (loop)

|   max Roth X (nominal k$) | net spending (today's $)   | total net spending (today's $)   | net benefit (today's $)   | net benefit (%)   | total Roth X (nominal $)   | total Roth converted (today's $)   | benefit / total Roth (today's $)   |
|--------------------------:|:---------------------------|:---------------------------------|:--------------------------|:------------------|:---------------------------|:-----------------------------------|:-----------------------------------|
|                       200 | $152,424                   | $4,725,147                       | $46,473                   | 0.98%             | $725,527                   | $671,699                           | 6.92%                              |
|                       150 | $152,424                   | $4,725,147                       | $46,473                   | 0.98%             | $725,527                   | $671,699                           | 6.92%                              |
|                       100 | $152,426                   | $4,725,205                       | $46,531                   | 0.98%             | $732,451                   | $677,231                           | 6.87%                              |
|                        50 | $152,330                   | $4,722,242                       | $43,568                   | 0.92%             | $600,000                   | $544,279                           | 8.00%                              |
|                        10 | $151,540                   | $4,697,755                       | $19,081                   | 0.41%             | $295,819                   | $211,858                           | 9.01%                              |
|                         0 | $150,925                   | $4,678,674                       | $0                        | 0.00%             | $0                         | $0                                 | 0.00%                              |

## Case 4: Historical rates from 1991 (loop)

|   max Roth X (nominal k$) | net spending (today's $)   | total net spending (today's $)   | net benefit (today's $)   | net benefit (%)   | total Roth X (nominal $)   | total Roth converted (today's $)   | benefit / total Roth (today's $)   |
|--------------------------:|:---------------------------|:---------------------------------|:--------------------------|:------------------|:---------------------------|:-----------------------------------|:-----------------------------------|
|                       200 | $265,058                   | $8,216,782                       | $136,561                  | 1.66%             | $1,191,551                 | $1,157,325                         | 11.80%                             |
|                       150 | $264,515                   | $8,199,961                       | $119,739                  | 1.46%             | $1,180,143                 | $1,124,390                         | 10.65%                             |
|                       100 | $264,137                   | $8,188,262                       | $108,041                  | 1.32%             | $1,088,542                 | $1,022,155                         | 10.57%                             |
|                        50 | $263,560                   | $8,170,359                       | $90,138                   | 1.10%             | $620,628                   | $577,061                           | 15.62%                             |
|                        10 | $261,406                   | $8,103,599                       | $23,378                   | 0.29%             | $220,000                   | $193,011                           | 12.11%                             |
|                         0 | $260,652                   | $8,080,221                       | $0                        | 0.00%             | $0                         | $0                                 | 0.00%                              |

## Observations

- Case 1 (Fixed conservative rates): best net benefit at 100k is $46,352, ratio 5.25%.
- Case 2 (Fixed optimistic rates): best net benefit at 100k is $49,030, ratio 5.21%.
- Case 3 (Historical rates from 1966): best net benefit at 100k is $46,531, ratio 6.87%.
- Case 4 (Historical rates from 1991): best net benefit at 200k is $136,561, ratio 11.80%.
- Net spending benefits (in dollars) remain positive across all scenarios, but the magnitude is modest relative to total lifetime spending.
- Fixed-rate scenarios show similar net benefit percentages despite different absolute spending levels, suggesting conversions are driven more by tax mechanics than return levels.
- The benefit-to-conversion ratio is a separate metric; historical-rate sequences show slightly higher ratios, indicating that conversions during weaker return periods can be incrementally more efficient per dollar converted.
- Medicare and IRMAA premiums are accounted for via the self-consistent loop, so both the net benefit and the benefit-to-conversion ratio already reflect the premium impacts of higher MAGI.
- The conversion cap that maximizes net benefit often sits in the mid range of tested values, though the highest cap can be best in some scenarios.

## Conclusions

- Across scenarios, best net benefits occur with maximum Roth caps between 100k and 200k (mode 100k).
- The best-case net spending uplift ranges from $46,352 to $136,561 in today's dollars, while benefits remain on the order of ~1% of total spending.
- The benefit-to-conversion ratio for those best cases ranges from 5.21% to 11.80%, so each conversion dollar yields only a few cents of added spending.

