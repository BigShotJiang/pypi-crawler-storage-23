# Configuration Refactoring Strategy

## Executive Summary

This document proposes a strategy to refactor Owl's configuration system to achieve:

1. **Simpler maintenance and expansion** — Single schema, single conversion logic
2. **User-defined keys** — Passthrough and round-trip of unknown keys in TOML files
3. **Homogenized storage** — Same canonical structure across UI, API, and TOML

---

## Current State Analysis

### Three Parallel Paths

| Source | Format | Keys | Conversion |
|--------|--------|------|-------------|
| **TOML** | Nested sections (`basic_info`, `savings_assets`, etc.) | snake_case | `readConfig()` → Plan (imperative calls) |
| **API** | Plan object with setters | N/A | Direct: `plan.setAccountBalances(...)` |
| **UI** | Flat session-state dict | Mixed (`iname0`, `txbl0`, `ssAmt0`, `benf0`, etc.) | `genDic(plan)` + `prepareRun()` + `getSolveParameters()` |

### Pain Points

1. **Triple maintenance**: Adding a parameter requires touching `config.py` (read + save), `owlbridge.genDic()`, `owlbridge.prepareRun()` (or equivalent), `sskeys.getSolveParameters()`, and potentially multiple UI pages.

2. **No schema**: Parameter definitions are scattered. `PARAMETERS.md` documents TOML structure, but there is no programmatic schema enforcing types or structure.

3. **Unknown keys dropped**: User-added keys in a TOML file (e.g., `[custom] notes = "..."`) are ignored on load and not preserved on save.

4. **Key proliferation**: UI uses ~80+ distinct flat keys that must be manually mapped to/from the nested TOML structure and Plan attributes.

5. **Translation overhead**: `_KEY_TRANSLATION` exists for backward compatibility, but the system has no single place where "canonical key" is defined.

---

## Proposed Architecture

### 1. Canonical Configuration Schema (Single Source of Truth)

Introduce a **programmatic schema** that defines the canonical structure. This schema is the single source of truth for:

- Which keys exist
- Their types and validation
- Default values
- Which sections they belong to

**Implementation options:**

- **Option A — Declarative schema (recommended)**: Use `dataclasses` or `pydantic` to define a `CaseConfig` model. Each field maps to a TOML path (e.g., `basic_info.names`).

- **Option B — Dictionary schema**: A Python dict describing sections and keys, with optional `jsonschema` or similar for validation.

**Recommended: Pydantic v2** — Provides validation, serialization, and `model_extra` for unknown keys.

```python
# Conceptual example (not literal implementation)
from pydantic import BaseModel, Field
from typing import Optional, List

class BasicInfo(BaseModel):
    status: str = "single"
    names: List[str] = Field(min_length=1, max_length=2)
    date_of_birth: List[str] = ...
    life_expectancy: List[int] = ...
    start_date: str = "today"

class CaseConfig(BaseModel):
    model_config = {"extra": "allow"}  # Preserve unknown keys!
    
    case_name: str = ""
    description: str = ""
    basic_info: BasicInfo = ...
    savings_assets: SavingsAssets = ...
    # ... other sections
```

`extra = "allow"` ensures user-defined keys at any level are preserved and round-tripped.

---

### 2. Canonical Dictionary as Interchange Format

Define a **canonical dict** structure that matches the TOML layout 1:1. All conversions go through this structure:

```
TOML file  ←→  canonical dict  ←→  Plan
                      ↑
                      │
                UI flat dict
```

- **TOML ↔ canonical dict**: Direct mapping. TOML sections become top-level keys. Unknown TOML keys go into reserved sections (e.g., `[extra]` or `[user_defined]`) or are merged at their original path with a namespace prefix (e.g., `_user.notes`).

- **canonical dict ↔ Plan**: One module (`config_plan_bridge.py`) with `config_to_plan(diconf) -> Plan` and `plan_to_config(plan) -> dict`. This replaces the scattered logic in `readConfig`/`saveConfig`.

- **canonical dict ↔ UI flat dict**: One mapping module (`config_ui_bridge.py`) with `config_to_ui(diconf) -> dict` and `ui_to_config(uidic) -> dict`. The UI continues to use flat keys for widget binding, but the mapping is centralized.

---

### 3. User-Defined Keys (Passthrough)

**Strategy: Preserve by path**

- When loading TOML:
  - Known keys are parsed into the schema.
  - Unknown top-level keys and unknown keys within known sections are stored in a structure such as `config["_extra"]` (or `config["user_defined"]`), keyed by full path, e.g. `{"custom.notes": "..."}`.

- When saving TOML:
  - Emit known keys from the schema.
  - Emit `_extra` contents as TOML sections/keys at their original paths. Use a convention (e.g., `[custom]` or `[user]`) so user keys don't collide with future schema keys.

**Alternative: No reserved section**

- Store unknown keys directly in the canonical dict at their TOML path. The schema only validates known keys; unknown keys are passed through. On save, iterate the full dict and dump everything.

---

### 4. Homogenized Storage

| Component | Current | Target |
|-----------|---------|--------|
| **UI session state** | Flat keys (`iname0`, `txbl0`, ...) | Option 1: Keep flat, add `config` key holding canonical dict; widgets sync from it. Option 2: Store canonical dict as primary; derive flat keys via accessors for widgets. |
| **TOML file** | Direct `readConfig`/`saveConfig` | `load_config(file) -> CaseConfig`; `save_config(config, file)` |
| **API** | `Plan` + imperative setters | `Plan.from_config(config)`; `plan.to_config()` (or keep setters as sugar over `apply_config`) |

**Recommendation for UI**: Store the **canonical dict** (or `CaseConfig` instance) as the primary case representation. The Plan is derived when needed (e.g., before solve). Widgets read/write via a thin layer that maps canonical paths to widget keys, e.g. `get_case_value("basic_info.names.0")` instead of `getCaseKey("iname0")`. Migration can be gradual: start by building the canonical dict from current flat keys and vice versa.

---

## Implementation Phases

### Phase 1: Canonical schema and TOML round-trip (low risk)

1. Define the canonical schema (Pydantic or dataclasses) mirroring current TOML structure.
2. Implement `toml_to_config(file) -> dict` and `config_to_toml(config, file)` that:
   - Preserve unknown keys (merge into output, or use `_extra`).
   - Use the schema only for known keys.
3. Refactor `readConfig` to: `diconf = toml_to_config(file)` then `plan = config_to_plan(diconf)`.
4. Refactor `saveConfig` to: `diconf = plan_to_config(plan)` then `config_to_toml(diconf, file)`.
5. Add tests for round-trip (save → load → save) and unknown key preservation.

**Deliverable**: Same behavior as today, with unknown keys preserved. Clear separation between TOML I/O and Plan construction.

---

### Phase 2: Centralize Plan conversion

1. Create `config_plan_bridge.py` with:
   - `config_to_plan(diconf, logstreams, loadHFP) -> Plan`
   - `plan_to_config(plan) -> dict`
2. Move all logic from `readConfig` / `saveConfig` into these functions.
3. `readConfig` becomes: load TOML → `config_to_plan`.
4. `saveConfig` becomes: `plan_to_config` → save TOML.
5. Ensure `plan_to_config` includes any values only present in Plan (e.g., derived state) so round-trip is complete.

**Deliverable**: Single place for Plan ↔ config conversion. `config.py` is slim (TOML I/O + bridge calls).

---

### Phase 3: UI integration

1. Create `config_ui_bridge.py` with:
   - `config_to_ui(diconf) -> dict` (canonical → flat session-state style)
   - `ui_to_config(uidic) -> dict` (flat → canonical)
2. When loading a case from TOML in the UI:
   - `diconf = toml_to_config(strio)` then `uidic = config_to_ui(diconf)` then populate `ss.cases[name]`.
3. When creating a Plan from the UI:
   - `uidic = get_all_case_keys()` (collect flat keys)
   - `diconf = ui_to_config(uidic)` then `plan = config_to_plan(diconf)`.
4. Optionally, add a `config` key to each case holding the canonical dict; widgets sync to it, and `ui_to_config` can be simplified to just reading that dict.
5. Migrate UI pages incrementally to use the bridge instead of ad-hoc `getCaseKey` / `setCaseKey` for config values.

**Deliverable**: UI uses the same canonical structure. Adding a new parameter requires:
- One schema entry
- One line in `config_to_plan` and `plan_to_config`
- One line in `config_to_ui` and `ui_to_config` (or auto-generation from schema)
- UI widget binding

---

### Phase 4: Schema-driven UI (optional, high impact)

1. Define a **UI manifest** (e.g., YAML or dict) that maps schema paths to:
   - Widget type (number_input, text_input, selectbox, etc.)
   - Label, help, min/max, choices
   - Section/page
2. Generate or drive UI widgets from this manifest. Adding a parameter becomes: add to schema + add to manifest.
3. Auto-generate `config_to_ui` / `ui_to_config` from the schema + manifest where possible.

---

## File Layout (Proposed)

```
src/owlplanner/
  config/
    __init__.py           # Public API: readConfig, saveConfig, load_config, save_config
    schema.py             # Pydantic/dataclass schema
    toml_io.py            # TOML load/save with unknown key preservation
    plan_bridge.py        # config ↔ Plan
    validation.py         # Optional: extra validation, migration helpers
ui/
  config_ui_bridge.py     # config ↔ UI flat dict
  sskeys.py              # Keep; optionally add config-centric helpers
```

---

## Migration and Backward Compatibility

1. **Existing TOML files**: Must load identically. `translate_old_keys` stays until deprecated keys are removed; it runs before schema parsing.
2. **API**: `owl.readConfig()` and `plan.saveConfig()` keep current signatures; internally they use the new pipeline.
3. **UI**: No user-visible change initially; refactor is internal. Session state structure can stay the same until Phase 3 is complete.
4. **Unknown keys**: Document that keys under `[user]` or `[custom]` (or similar) are preserved. Existing files without such sections are unchanged.

---

## Risks and Mitigations

| Risk | Mitigation |
|------|-------------|
| Large refactor breaks behavior | Incremental phases; extensive round-trip tests; keep old code paths until new ones are validated. |
| Pydantic adds dependency | Use `dataclasses` + manual validation if minimal deps required; or `pydantic` is already common in data tooling. |
| UI migration is tedious | Phase 3 can be done gradually; start with `createCaseFromFile` and `prepareRun`; leave most widgets as-is initially. |
| User keys conflict with future schema | Reserve `[user]` or `_` prefix for user-defined keys; document clearly. |

---

## Success Criteria

1. Adding a new configuration parameter requires changes in **at most 3–4 places** (schema, plan bridge, UI bridge, optional manifest), instead of 6+.
2. User-added keys in TOML are preserved across load/save.
3. TOML, API, and UI all operate on the same canonical structure conceptually; no divergent representations for the same logical parameter.
4. All existing tests pass; new tests cover round-trip and unknown-key preservation.
5. `PARAMETERS.md` can be generated or synchronized from the schema (optional stretch goal).

---

## Implementation Status (Feb 2026)

**Phases 1, 2 & 3 completed** using Pydantic:

- `src/owlplanner/config/` package with:
  - `schema.py` — Pydantic models for all TOML sections
  - `toml_io.py` — Load/save with unknown key preservation
  - `plan_bridge.py` — `config_to_plan()`, `plan_to_config()`, `apply_config_to_plan()`
  - `legacy.py` — Backward-compatible key translation
- `owlplanner.config.ui_bridge` — `config_to_ui()`, `ui_to_config()` (ui/config_ui_bridge.py removed as redundant)
- Public API unchanged: `readConfig()`, `saveConfig()` behave as before
- User-defined sections round-trip correctly
- UI integration:
  - `createCaseFromFile` uses `load_toml` → `config_to_plan` → `config_to_ui`; stores `config` key for user keys
  - `prepareRun` uses `ui_to_config` → `apply_config_to_plan` (replaces manual setters)
  - `genDic` retained for compatibility but no longer used in createCaseFromFile path
- Tests: `tests/test_config_pydantic.py`, `tests/test_config_ui_bridge.py`

## Next Steps

1. Phase 4 (optional): Schema-driven UI from manifest
