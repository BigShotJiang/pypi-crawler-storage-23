"""
A test package used to ensure that downstream packages can do basic things with openff-units.
"""

from setuptools import setup

setup(
    version="0.0.0",
    name="openff-units-downstream-dummy",
)
