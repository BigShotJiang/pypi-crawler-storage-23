__version__ = "0.1.33"
__app_name__ = "devmemory"
