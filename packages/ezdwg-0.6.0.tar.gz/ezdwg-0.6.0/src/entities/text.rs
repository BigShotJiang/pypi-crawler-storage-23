use crate::bit::{BitReader, Endian};
use crate::core::error::ErrorKind;
use crate::core::result::Result;
use crate::entities::common::{
    parse_common_entity_handles, parse_common_entity_header, parse_common_entity_header_r14,
    parse_common_entity_header_r2007, parse_common_entity_header_r2010,
    parse_common_entity_header_r2013, parse_common_entity_layer_handle, read_handle_reference,
    CommonEntityHeader,
};

#[derive(Debug, Clone)]
pub struct TextEntity {
    pub handle: u64,
    pub color_index: Option<u16>,
    pub true_color: Option<u32>,
    pub layer_handle: u64,
    pub text: String,
    pub insertion: (f64, f64, f64),
    pub alignment: Option<(f64, f64, f64)>,
    pub extrusion: (f64, f64, f64),
    pub thickness: f64,
    pub oblique_angle: f64,
    pub height: f64,
    pub rotation: f64,
    pub width_factor: f64,
    pub generation: u16,
    pub horizontal_alignment: u16,
    pub vertical_alignment: u16,
    pub style_handle: Option<u64>,
}

pub fn decode_text(reader: &mut BitReader<'_>) -> Result<TextEntity> {
    let header = parse_common_entity_header(reader)?;
    decode_text_with_header(reader, header, false)
}

pub fn decode_text_r14(reader: &mut BitReader<'_>, object_handle: u64) -> Result<TextEntity> {
    let mut header = parse_common_entity_header_r14(reader)?;
    if header.handle == 0 {
        header.handle = object_handle;
    }
    decode_text_with_header_r14(reader, header, true)
}

pub fn decode_text_r2007(reader: &mut BitReader<'_>) -> Result<TextEntity> {
    let header = parse_common_entity_header_r2007(reader)?;
    decode_text_with_header(reader, header, true)
}

pub fn decode_text_r2010(
    reader: &mut BitReader<'_>,
    object_data_end_bit: u32,
    object_handle: u64,
) -> Result<TextEntity> {
    let mut header = parse_common_entity_header_r2010(reader, object_data_end_bit)?;
    header.handle = object_handle;
    decode_text_with_header(reader, header, true)
}

pub fn decode_text_r2013(
    reader: &mut BitReader<'_>,
    object_data_end_bit: u32,
    object_handle: u64,
) -> Result<TextEntity> {
    let mut header = parse_common_entity_header_r2013(reader, object_data_end_bit)?;
    header.handle = object_handle;
    decode_text_with_header(reader, header, true)
}

fn decode_text_with_header(
    reader: &mut BitReader<'_>,
    header: CommonEntityHeader,
    allow_handle_decode_failure: bool,
) -> Result<TextEntity> {
    let data_flags = reader.read_rc()?;

    let elevation = if (data_flags & 0x01) == 0 {
        reader.read_rd(Endian::Little)?
    } else {
        0.0
    };

    let insertion_x = reader.read_rd(Endian::Little)?;
    let insertion_y = reader.read_rd(Endian::Little)?;

    let alignment = if (data_flags & 0x02) == 0 {
        let align_x = reader.read_dd(insertion_x)?;
        let align_y = reader.read_dd(insertion_y)?;
        Some((align_x, align_y, elevation))
    } else {
        None
    };

    let extrusion = reader.read_be()?;
    let thickness = reader.read_bt()?;

    let oblique_angle = if (data_flags & 0x04) == 0 {
        reader.read_rd(Endian::Little)?
    } else {
        0.0
    };

    let rotation = if (data_flags & 0x08) == 0 {
        reader.read_rd(Endian::Little)?
    } else {
        0.0
    };

    let height = reader.read_rd(Endian::Little)?;

    let width_factor = if (data_flags & 0x10) == 0 {
        reader.read_rd(Endian::Little)?
    } else {
        1.0
    };

    let text = reader.read_tv()?;

    let generation = if (data_flags & 0x20) == 0 {
        reader.read_bs()?
    } else {
        0
    };

    let horizontal_alignment = if (data_flags & 0x40) == 0 {
        reader.read_bs()?
    } else {
        0
    };

    let vertical_alignment = if (data_flags & 0x80) == 0 {
        reader.read_bs()?
    } else {
        0
    };

    let (layer_handle, style_handle) =
        decode_text_handles(reader, &header, allow_handle_decode_failure)?;

    Ok(TextEntity {
        handle: header.handle,
        color_index: header.color.index,
        true_color: header.color.true_color,
        layer_handle,
        text,
        insertion: (insertion_x, insertion_y, elevation),
        alignment,
        extrusion,
        thickness,
        oblique_angle,
        height,
        rotation,
        width_factor,
        generation,
        horizontal_alignment,
        vertical_alignment,
        style_handle,
    })
}

fn decode_text_with_header_r14(
    reader: &mut BitReader<'_>,
    header: CommonEntityHeader,
    allow_handle_decode_failure: bool,
) -> Result<TextEntity> {
    let elevation = reader.read_bd()?;
    let insertion_x = reader.read_rd(Endian::Little)?;
    let insertion_y = reader.read_rd(Endian::Little)?;
    let align_x = reader.read_rd(Endian::Little)?;
    let align_y = reader.read_rd(Endian::Little)?;
    let extrusion = reader.read_3bd()?;
    let thickness = reader.read_bd()?;
    let oblique_angle = reader.read_bd()?;
    let rotation = reader.read_bd()?;
    let height = reader.read_bd()?;
    let width_factor = reader.read_bd()?;
    let text = reader.read_tv()?;
    let generation = reader.read_bs()?;
    let horizontal_alignment = reader.read_bs()?;
    let vertical_alignment = reader.read_bs()?;

    let (layer_handle, style_handle) =
        decode_text_handles(reader, &header, allow_handle_decode_failure)?;

    Ok(TextEntity {
        handle: header.handle,
        color_index: header.color.index,
        true_color: header.color.true_color,
        layer_handle,
        text,
        insertion: (insertion_x, insertion_y, elevation),
        alignment: Some((align_x, align_y, elevation)),
        extrusion,
        thickness,
        oblique_angle,
        height,
        rotation,
        width_factor,
        generation,
        horizontal_alignment,
        vertical_alignment,
        style_handle,
    })
}

fn decode_text_handles(
    reader: &mut BitReader<'_>,
    header: &CommonEntityHeader,
    allow_handle_decode_failure: bool,
) -> Result<(u64, Option<u64>)> {
    // Handles are stored in the handle stream at obj_size bit offset.
    reader.set_bit_pos(header.obj_size);
    let handles_pos = reader.get_pos();
    match parse_common_entity_handles(reader, header) {
        Ok(common_handles) => Ok((
            common_handles.layer,
            read_handle_reference(reader, header.handle).ok(),
        )),
        Err(err)
            if allow_handle_decode_failure
                && matches!(
                    err.kind,
                    ErrorKind::Format | ErrorKind::Decode | ErrorKind::Io
                ) =>
        {
            reader.set_pos(handles_pos.0, handles_pos.1);
            let layer = parse_common_entity_layer_handle(reader, header).unwrap_or(0);
            Ok((layer, None))
        }
        Err(err) => Err(err),
    }
}
