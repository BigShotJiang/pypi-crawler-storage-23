# ACadSharp Sample Fixtures

These DWG fixtures were copied from the public ACadSharp repository:

- `sample_AC1032.dwg`
- `BLOCKPOINTPARAMETER.dwg`
- `sample_AC1027.dwg`

Source repository:

- https://github.com/DomCR/ACadSharp

Original paths:

- `samples/sample_AC1032.dwg`
- `samples/dynamic-blocks/BLOCKPOINTPARAMETER.dwg`
- `samples/sample_AC1027.dwg`

License:

- MIT License (ACadSharp `LICENSE`)
