# CLI Reference

ezdwg provides a command-line interface for inspecting, converting, and writing DWG files.

## Version

```bash
ezdwg --version
```

## Inspect

Show information about a DWG file:

```bash
ezdwg inspect path/to/file.dwg
```

Output includes:

- File path
- DWG version (e.g. `AC1015`)
- Decode version
- Total entity count
- Per-type entity counts

### Verbose Mode

Show expanded diagnostics:

```bash
ezdwg inspect path/to/file.dwg --verbose
```

Verbose mode shows additional details for diagnostic entity types and expands the number of unknown handle/type-code entries reported.

### Example Output

```
file: examples/data/line_2000.dwg
version: AC1015
decode_version: AC1015
total_entities: 3
LINE: 3
```

## Convert

Convert a DWG file to DXF:

```bash
ezdwg convert input.dwg output.dxf
```

### Options

| Option | Description |
|--------|-------------|
| `--types` | Entity filter (e.g. `"LINE ARC LWPOLYLINE"`) |
| `--dxf-version` | Output DXF version (default: `R2010`) |
| `--strict` | Fail if any entity cannot be converted |
| `--include-unsupported` | Also query unsupported entity types |

### Examples

```bash
# Convert with type filter
ezdwg convert input.dwg output.dxf --types "ARC LINE"

# Specify DXF version
ezdwg convert input.dwg output.dxf --dxf-version R2018

# Strict mode
ezdwg convert input.dwg output.dxf --strict
```

### Example Output

```
input: input.dwg
output: output.dxf
total_entities: 15
written_entities: 12
skipped_entities: 3
skipped[VIEWPORT]: 3
```

## Write

Write a DWG file using the native AC1015 writer:

```bash
ezdwg write input.dwg output.dwg
```

### Options

| Option | Description |
|--------|-------------|
| `--types` | Entity filter (e.g. `"LINE ARC LWPOLYLINE"`) |
| `--dwg-version` | Output DWG version (default: `AC1015`, currently only supported value) |
| `--strict` | Fail if any entity cannot be written |

### Examples

```bash
# Write only selected entity types
ezdwg write input.dwg output.dwg --types "LINE MTEXT"

# Explicit target version
ezdwg write input.dwg output.dwg --dwg-version AC1015

# Strict mode
ezdwg write input.dwg output.dwg --strict
```

### Example Output

```
input: input.dwg
output: output.dwg
target_version: AC1015
total_entities: 8
written_entities: 7
skipped_entities: 1
skipped[POINT]: 1
```
