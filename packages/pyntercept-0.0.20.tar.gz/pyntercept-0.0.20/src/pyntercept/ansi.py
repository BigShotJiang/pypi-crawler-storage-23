ESC = '\x1B'

# ANSI_CSI = '\x9B'

ASCII_BEL = '\x07'
ASCII_BS  = '\x08'
ASCII_HT  = '\x09'
ASCII_LF  = '\x0A'
ASCII_VT  = '\x0B'
ASCII_FF  = '\x0C'
ASCII_CR  = '\x0D'
ASCII_DEL = '\x7F'

# region cursor controls 
CUR_CTRL_HOME = ESC + '[H'

def CUR_SET_POS(line: int, col: int) -> str:
    return f'{ESC}[{line};{col}H'


def CUR_MOVE_UP(line: int) -> str:
    return f'{ESC}[#{line}A'


def CUR_MOVE_DOWN(line: int) -> str:
    return f'{ESC}[#{line}B'


def CUR_MOVE_RIGHT(cols: int) -> str:
    return f'{ESC}[#{cols}C'


def CUR_MOVE_LEFT(cols: int) -> str:
    return f'{ESC}[#{cols}D'


def CUR_MOVE_BEG_DOWN(lines: int) -> str:
    return f'{ESC}[#{lines}E'


def CUR_MOVE_BEG_UP(lines: int) -> str:
    return f'{ESC}[#{lines}F'


def CUR_SET_COL(col: int) -> str:
    return f'{ESC}[#{col}G'

CUR_REQ_POS = f'{ESC}[6n'

CUR_UP_ONE_L = f'{ESC}M'

CUR_POS_SAVE_DEC = f'{ESC}7'

CUR_POS_RESTORE_DEC = f'{ESC}8'

CUR_POS_SAVE_SCO = f'{ESC}[s'

CUR_POS_RESTORE_SCO = f'{ESC}[u'

# endregion

# region erase functions

ERASE_IN_DISPLAY = f'{ESC}[J'
ERASE_CUR_TO_SCR_END = f'{ESC}[0J'
ERASE_CUR_TO_SCR_BEG = f'{ESC}[1J'
ERASE_ENTIRE_SCR = f'{ESC}[2J'
ERASE_SAVED_LINES = f'{ESC}[3J'
ERASE_IN_LINE = f'{ESC}[K'
ERASE_CUR_TO_LINE_END = f'{ESC}[0K'
ERASE_CUR_TO_LINE_BEG = f'{ESC}[1K'
ERASE_LINE = f'{ESC}[2K'

# endregion

# region colors & graphics modes
RESET_ALL_STYLES = f'{ESC}[0m'

SET_BOLD         = f'{ESC}[1m'
SET_DIM          = f'{ESC}[2m'; RESET_BOLD_DIM      = f'{ESC}[22m'
SET_ITALIC       = f'{ESC}[3m'; RESET_ITALIC        = f'{ESC}[23m'
SET_UNDER        = f'{ESC}[4m'; RESET_UNDER         = f'{ESC}[24m'
SET_SLOW_BLINK   = f'{ESC}[5m'; RESET_SLOW_BLINK    = f'{ESC}[25m'
SET_INVERS       = f'{ESC}[7m'; RESET_INVERS        = f'{ESC}[27m'
SET_HIDDEN       = f'{ESC}[8m'; RESET_HIDDEN        = f'{ESC}[28m'
SET_STRIKE       = f'{ESC}[9m'; RESET_HIDDEN        = f'{ESC}[29m'
# endregion

if __name__ == "__main__":
    print(f'regular {SET_BOLD}bold')