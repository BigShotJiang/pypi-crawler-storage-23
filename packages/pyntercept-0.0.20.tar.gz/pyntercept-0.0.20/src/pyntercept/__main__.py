if __name__ == "__main__":
    from pyntercept.main import main
    main()