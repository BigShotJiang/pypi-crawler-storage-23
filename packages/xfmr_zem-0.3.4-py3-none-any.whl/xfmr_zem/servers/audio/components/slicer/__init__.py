# Slicer module
from .slicer import AudioSlicer

__all__ = ["AudioSlicer"]
