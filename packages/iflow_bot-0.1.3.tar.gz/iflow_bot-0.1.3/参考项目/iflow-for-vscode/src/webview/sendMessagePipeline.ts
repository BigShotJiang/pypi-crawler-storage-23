import { AcpClient } from '../acpClient';
import { normalizeErrorMessage } from '../errorUtils';
import { ConversationStore } from '../store';
import { AttachedFile, Conversation, ExtensionMessage, IDEContext, StreamStatusPhase } from '../protocol';
import { PlanApprovalCoordinator } from './planApprovalCoordinator';

const PLAN_EXECUTION_REMINDER = '<system-reminder>\nPlan mode has been deactivated. The user approved the plan. You are now in execution mode. You may now freely use all tools including write_file, edit_file, run_shell_command, and other modification tools. Please proceed with the implementation.\n</system-reminder>';
const WAITING_FIRST_CHUNK_STATUS_DELAY_MS = 300;
const CLI_RECHECK_HINT = '未连接到 iFlow CLI，请 Re-check CLI。';
const DEFAULT_STREAM_RENDER_INTERVAL_MS = 50;
const MIN_STREAM_RENDER_INTERVAL_MS = 30;

interface QueuedMessage {
  content: string;
  attachedFiles: AttachedFile[];
  silent: boolean;
  ideContext?: IDEContext;
}

interface SendMessagePipelineDependencies {
  store: ConversationStore;
  client: AcpClient;
  postMessage: (message: ExtensionMessage) => void;
  markCliUnavailable: (diagnostics: string) => void;
  resolveWorkspaceFolder: (conversation: Conversation) => string | undefined;
  getAllWorkspaceFolderPaths: () => string[];
  getWorkspaceFileList: (cwd?: string, limit?: number) => Promise<string[]>;
  shouldIncludeWorkspaceFiles: () => boolean;
  getWorkspaceFilesLimit: () => number;
  getStreamRenderIntervalMs: () => number;
  planApprovalCoordinator: PlanApprovalCoordinator;
  debug: (message: string) => void;
  setSessionId: (sessionId: string) => void;
  now?: () => number;
}

export class SendMessagePipeline {
  private readonly now: () => number;

  constructor(private readonly deps: SendMessagePipelineDependencies) {
    this.now = deps.now ?? (() => Date.now());
  }

  async execute(input: QueuedMessage): Promise<void> {
    const queue: QueuedMessage[] = [input];

    while (queue.length > 0) {
      const current = queue.shift();
      if (!current) {
        continue;
      }

      const followups = await this.executeSingle(current);
      queue.push(...followups);
    }
  }

  private async executeSingle(input: QueuedMessage): Promise<QueuedMessage[]> {
    const sendStartedAt = this.now();
    let runStartedAt = sendStartedAt;
    let firstChunkAt: number | null = null;
    let workspaceScanMs: number | null = null;

    this.deps.debug(
      `Send pipeline start: silent=${input.silent}, contentLength=${input.content.length}, attachedFiles=${input.attachedFiles.length}, hasIdeContext=${Boolean(input.ideContext)}`
    );
    this.emitStreamStatus(sendStartedAt, 'preparing');

    this.deps.store.batchUpdate(() => {
      if (!input.silent) {
        this.deps.store.addUserMessage(input.content, input.attachedFiles);
      }
      this.deps.store.startAssistantMessage();
      this.deps.store.setStreaming(true);
    });

    const conversation = this.deps.store.getCurrentConversation();
    if (!conversation) {
      this.deps.debug('No active conversation found; dropping send request');
      return [];
    }

    const cwd = this.deps.resolveWorkspaceFolder(conversation);
    if (cwd && !conversation.workspaceFolderUri) {
      this.deps.store.setConversationWorkspaceFolder(cwd);
    }

    const fileAllowedDirs = this.deps.getAllWorkspaceFolderPaths();
    const autoIncludeWorkspaceFiles = this.deps.shouldIncludeWorkspaceFiles();
    const workspaceFilesLimit = Math.max(1, this.deps.getWorkspaceFilesLimit());
    let workspaceFiles: string[] = [];

    if (autoIncludeWorkspaceFiles) {
      const workspaceScanStartedAt = this.now();
      workspaceFiles = await this.deps.getWorkspaceFileList(cwd, workspaceFilesLimit);
      workspaceScanMs = this.now() - workspaceScanStartedAt;
    }

    this.deps.debug(
      `Prepared run context: mode=${conversation.mode}, model=${conversation.model}, cwd=${cwd ?? 'n/a'}, workspaceFiles=${workspaceFiles.length}, autoIncludeWorkspaceFiles=${autoIncludeWorkspaceFiles}, workspaceFilesLimit=${workspaceFilesLimit}, allowedDirs=${fileAllowedDirs.length}`
    );

    let runSucceeded = false;
    let runCompleted = false;
    let firstChunkSeen = false;
    const streamRenderIntervalMs = this.resolveStreamRenderIntervalMs();
    let statePublishTimer: ReturnType<typeof setTimeout> | null = null;
    let hasPendingStatePublish = false;

    const clearStatePublishTimer = (): void => {
      if (!statePublishTimer) {
        return;
      }
      clearTimeout(statePublishTimer);
      statePublishTimer = null;
    };

    const flushPendingStatePublish = (): void => {
      clearStatePublishTimer();
      if (!hasPendingStatePublish) {
        return;
      }
      hasPendingStatePublish = false;
      this.deps.store.publishState();
    };

    const scheduleStatePublish = (): void => {
      hasPendingStatePublish = true;
      if (statePublishTimer) {
        return;
      }
      statePublishTimer = setTimeout(() => {
        statePublishTimer = null;
        if (!hasPendingStatePublish) {
          return;
        }
        hasPendingStatePublish = false;
        this.deps.store.publishState();
      }, streamRenderIntervalMs);
    };

    this.deps.planApprovalCoordinator.startRun();
    runStartedAt = this.now();
    this.emitStreamStatus(sendStartedAt, 'connecting');

    const waitingStatusTimer = setTimeout(() => {
      if (!firstChunkSeen && !runCompleted) {
        this.emitStreamStatus(sendStartedAt, 'waiting_first_chunk');
      }
    }, WAITING_FIRST_CHUNK_STATUS_DELAY_MS);

    try {
      await this.deps.client.run(
        {
          prompt: input.content,
          attachedFiles: input.attachedFiles,
          mode: conversation.mode,
          think: conversation.think,
          model: conversation.model,
          workspaceFiles,
          sessionId: conversation.sessionId,
          ideContext: input.ideContext,
          cwd,
          fileAllowedDirs,
        },
        (chunk) => {
          if (!firstChunkSeen) {
            firstChunkSeen = true;
            firstChunkAt = this.now();
          }
          this.deps.planApprovalCoordinator.onChunk(chunk);
          this.deps.store.appendToAssistantMessage(chunk, { notify: false });
          this.deps.postMessage({ type: 'streamChunk', chunk });
          scheduleStatePublish();
        },
        () => {
          runCompleted = true;
          runSucceeded = true;
          flushPendingStatePublish();
          this.logPerf(sendStartedAt, runStartedAt, firstChunkAt, workspaceScanMs);
          this.deps.debug('Run completed successfully');
          this.deps.store.batchUpdate(() => {
            this.deps.store.endAssistantMessage();
            this.deps.store.setStreaming(false);
          });
          this.deps.postMessage({ type: 'streamEnd' });
        },
        (error) => {
          runCompleted = true;
          flushPendingStatePublish();
          let normalizedError = normalizeErrorMessage(error);
          this.deps.debug(`Run failed: ${normalizedError}`);
          if (this.shouldResetCli(normalizedError)) {
            this.deps.markCliUnavailable(normalizedError);
            normalizedError = this.appendCliReconnectHint(normalizedError);
          }
          this.logPerf(sendStartedAt, runStartedAt, firstChunkAt, workspaceScanMs);

          this.deps.store.batchUpdate(() => {
            this.deps.store.appendToAssistantMessage({ chunkType: 'error', message: normalizedError }, { notify: false });
            this.deps.store.endAssistantMessage();
            this.deps.store.setStreaming(false);
          });
          this.deps.postMessage({ type: 'streamError', error: normalizedError });
        },
      ).then((returnedSessionId) => {
        if (returnedSessionId) {
          this.deps.debug(`Persisting ACP sessionId on conversation: ${returnedSessionId}`);
          this.deps.setSessionId(returnedSessionId);
        }
      });
    } finally {
      clearTimeout(waitingStatusTimer);
      clearStatePublishTimer();
    }

    if (!runSucceeded) {
      this.deps.planApprovalCoordinator.cancelWait();
      return [];
    }

    const followup = await this.deps.planApprovalCoordinator.resolveAfterRun(
      conversation.mode,
      () => {
        this.deps.postMessage({
          type: 'streamChunk',
          chunk: {
            chunkType: 'plan_approval',
            requestId: -1,
            plan: '',
          },
        });
      },
    );

    switch (followup.kind) {
      case 'execute':
        this.deps.debug(`Plan approved by user; switching to execution mode=${followup.mode}`);
        this.deps.store.setMode(followup.mode);
        this.deps.planApprovalCoordinator.markReplaying();
        return [{
          content: PLAN_EXECUTION_REMINDER,
          attachedFiles: [],
          silent: true,
        }];

      case 'feedback':
        this.deps.debug('Plan feedback provided by user; re-running in plan mode');
        return [{
          content: followup.feedback,
          attachedFiles: [],
          silent: false,
        }];

      case 'none':
      default:
        return [];
    }
  }

  private emitStreamStatus(startedAt: number, phase: StreamStatusPhase): void {
    this.deps.postMessage({
      type: 'streamStatus',
      phase,
      elapsedMs: Math.max(0, this.now() - startedAt),
    });
  }

  private appendCliReconnectHint(error: string): string {
    if (error.includes('Re-check CLI') || error.includes('未连接到 iFlow CLI')) {
      return error;
    }
    return `${error}\n${CLI_RECHECK_HINT}`;
  }

  private logPerf(
    sendStartedAt: number,
    runStartedAt: number,
    firstChunkAt: number | null,
    workspaceScanMs: number | null,
  ): void {
    const preflightMs = Math.max(0, runStartedAt - sendStartedAt);
    const totalMs = Math.max(0, this.now() - sendStartedAt);
    const ttft = firstChunkAt === null ? 'n/a' : `${Math.max(0, firstChunkAt - sendStartedAt)}ms`;
    const workspaceScan = workspaceScanMs === null ? 'n/a' : `${Math.max(0, workspaceScanMs)}ms`;
    this.deps.debug(`[perf] ttft=${ttft} preflight=${preflightMs}ms total=${totalMs}ms workspaceScan=${workspaceScan}`);
  }

  private shouldResetCli(error: string): boolean {
    return error.includes('connect')
      || error.includes('ECONNREFUSED')
      || error.includes('not found')
      || error.includes('not available');
  }

  private resolveStreamRenderIntervalMs(): number {
    const configured = this.deps.getStreamRenderIntervalMs();
    if (!Number.isFinite(configured)) {
      return DEFAULT_STREAM_RENDER_INTERVAL_MS;
    }
    return Math.max(MIN_STREAM_RENDER_INTERVAL_MS, Math.round(configured));
  }
}
