"""REST API module for nautobot_device_lifecycle_mgmt app."""
