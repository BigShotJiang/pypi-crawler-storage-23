"""Kindex — Knowledge graph that learns from your conversations."""

__version__ = "0.8.0"
