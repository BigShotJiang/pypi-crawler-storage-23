---
skill: python
title: "Python Development"
level: expert
domains: [engineering, systems]
connects_to:
  - target: alpha
    weight: 0.8
    reason: "Alpha uses Python extensively"
evidence:
  - "Built Conv knowledge graph tool"
  - "Pact contract system"
---
# Python Development

Expert-level Python including async, metaclasses, Pydantic, CLI tools.
