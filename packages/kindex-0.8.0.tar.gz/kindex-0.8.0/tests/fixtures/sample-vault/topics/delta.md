# Delta Topic — No Frontmatter

This topic has no YAML frontmatter at all, simulating the popular-science.md edge case.

It should still parse without errors but will have empty metadata.
