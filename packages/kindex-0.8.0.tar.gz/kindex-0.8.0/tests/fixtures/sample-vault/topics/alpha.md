---
topic: alpha
title: "Alpha Topic"
weight: 1.0
domains: [research, systems]
status: active
connects_to:
  - target: beta
    reason: "Alpha depends on Beta's framework"
    weight: 0.9
  - target: gamma
    reason: "Gamma provides theoretical basis"
    weight: 0.7
  - target: delta
    reason: "Weak connection to Delta"
    weight: 0.3
---
# Alpha Topic

This is the primary test topic. It has three outgoing edges with different weights.
