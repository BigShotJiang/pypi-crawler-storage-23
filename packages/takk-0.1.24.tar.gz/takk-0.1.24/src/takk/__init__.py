from takk.models import Project, Worker, PubSub, NetworkApp, StreamlitApp, MlflowServer, Job, Compute, FastAPIApp, UvicornApp, GuvicornApp, ResourceTags, value_for, current_env, ResourceRef, ServiceUrl, DockerBuild

try:
    from importlib.metadata import version
    __version__ = version("takk")
except Exception:
    __version__ = "0.0.0+unknown"


__all__ = [
    "Project", 
    "Worker", 
    "PubSub", 
    "NetworkApp", 
    "StreamlitApp", 
    "MlflowServer", 
    "Job", 
    "Compute", 
    "FastAPIApp",
    "UvicornApp",
    "GuvicornApp",
    "ResourceTags",
    "value_for", 
    "current_env",
    "ResourceRef",
    "ServiceUrl",
    "DockerBuild",
]
