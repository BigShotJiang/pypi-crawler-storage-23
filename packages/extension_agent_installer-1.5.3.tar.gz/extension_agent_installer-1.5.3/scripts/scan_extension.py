#!/usr/bin/env python3
"""
Scan opencode extensions for security vulnerabilities using mcp-scan.
Returns JSON with scan results and recommendation.
"""

import subprocess
import sys
import json
import tempfile
import shutil
from pathlib import Path

def check_uv_installed():
    """Check if uv is installed."""
    result = shutil.which("uv")
    return result is not None

def check_mcp_scan_installed():
    """Check if mcp-scan is available via uvx."""
    try:
        result = subprocess.run(
            ["uvx", "mcp-scan@latest", "--help"],
            capture_output=True,
            text=True,
            timeout=30
        )
        return result.returncode == 0
    except Exception:
        return False

def scan_file(file_path: str) -> dict:
    """
    Scan a single file or directory for security issues.
    Returns dict with scan results.
    """
    path = Path(file_path)
    if not path.exists():
        return {
            "success": False,
            "error": f"Path does not exist: {file_path}",
            "can_install": False
        }
    
    # Determine scan type based on content
    is_skill = path.is_file() and path.suffix == ".md" and path.name == "SKILL.md"
    is_skill_dir = path.is_dir() and (path / "SKILL.md").exists()
    is_config = path.suffix == ".json"
    
    cmd = ["uvx", "mcp-scan@latest", "--json"]
    
    if is_skill or is_skill_dir:
        cmd.extend(["--skills", str(path)])
    else:
        cmd.append(str(path))
    
    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=60
        )
        
        output = result.stdout + result.stderr
        
        # Try to parse JSON output
        try:
            scan_data = json.loads(output)
        except json.JSONDecodeError:
            scan_data = {"raw_output": output}
        
        # Analyze severity
        has_critical = "CRITICAL" in output.upper() or "PROMPT INJECTION" in output.upper()
        has_high = "HIGH" in output.upper() or "TOOL POISONING" in output.upper()
        has_medium = "MEDIUM" in output.upper() or "TOXIC FLOW" in output.upper()
        has_low = "LOW" in output.upper() or "SECRET" in output.upper() or "SENSITIVE" in output.upper()
        
        if has_critical:
            recommendation = "BLOCK"
            severity = "CRITICAL"
        elif has_high:
            recommendation = "BLOCK"
            severity = "HIGH"
        elif has_medium:
            recommendation = "WARN"
            severity = "MEDIUM"
        elif has_low:
            recommendation = "WARN"
            severity = "LOW"
        else:
            recommendation = "ALLOW"
            severity = "NONE"
        
        return {
            "success": True,
            "severity": severity,
            "recommendation": recommendation,
            "can_install": recommendation != "BLOCK",
            "scan_data": scan_data,
            "raw_output": output[:2000] if len(output) > 2000 else output
        }
        
    except subprocess.TimeoutExpired:
        return {
            "success": False,
            "error": "Scan timed out",
            "can_install": False
        }
    except Exception as e:
        return {
            "success": False,
            "error": str(e),
            "can_install": False
        }

def main():
    if len(sys.argv) < 2:
        print(json.dumps({
            "success": False,
            "error": "Usage: scan_extension.py <path>",
            "can_install": False
        }))
        sys.exit(1)
    
    file_path = sys.argv[1]
    result = scan_file(file_path)
    print(json.dumps(result, indent=2))
    
    sys.exit(0 if result.get("can_install", False) else 1)

if __name__ == "__main__":
    main()
