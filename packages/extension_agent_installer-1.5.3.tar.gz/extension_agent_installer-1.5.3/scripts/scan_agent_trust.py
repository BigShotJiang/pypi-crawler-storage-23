#!/usr/bin/env python3
"""
Scan extensions using Gen Digital's Agent Trust Hub API.
Cloud-based verification backed by Gen Threat Labs.
"""

import subprocess
import sys
import json
import urllib.request
import urllib.error

AGENT_TRUST_API = "https://ai.gendigital.com/api/scan/lookup"

def scan_skill_url(skill_url: str) -> dict:
    """
    Scan a skill URL using Agent Trust Hub API.
    
    Args:
        skill_url: URL to the skill (e.g., https://skills.sh/author/skill-name)
    
    Returns:
        dict with scan results including severity and recommendation
    """
    payload = json.dumps({"skillUrl": skill_url}).encode("utf-8")
    headers = {"Content-Type": "application/json"}
    
    try:
        req = urllib.request.Request(
            AGENT_TRUST_API,
            data=payload,
            headers=headers,
            method="POST"
        )
        
        with urllib.request.urlopen(req, timeout=30) as response:
            data = json.loads(response.read().decode("utf-8"))
        
        severity = data.get("severity", "UNKNOWN").upper()
        notes = data.get("notes", "")
        trusted = data.get("trusted", False)
        
        # Map severity to recommendation
        if severity == "SAFE":
            recommendation = "ALLOW"
            can_install = True
        elif severity == "LOW":
            recommendation = "WARN"
            can_install = True
        elif severity == "HIGH":
            recommendation = "BLOCK"
            can_install = False
        elif severity == "CRITICAL":
            recommendation = "BLOCK"
            can_install = False
        else:
            recommendation = "WARN"
            can_install = True
        
        return {
            "success": True,
            "scanner": "agent-trust-hub",
            "severity": severity,
            "recommendation": recommendation,
            "can_install": can_install,
            "trusted": trusted,
            "notes": notes,
            "raw_response": data
        }
        
    except urllib.error.HTTPError as e:
        return {
            "success": False,
            "scanner": "agent-trust-hub",
            "error": f"HTTP {e.code}: {e.reason}",
            "can_install": None
        }
    except urllib.error.URLError as e:
        return {
            "success": False,
            "scanner": "agent-trust-hub",
            "error": f"Connection error: {e.reason}",
            "can_install": None
        }
    except Exception as e:
        return {
            "success": False,
            "scanner": "agent-trust-hub",
            "error": str(e),
            "can_install": None
        }

def main():
    if len(sys.argv) < 2:
        print(json.dumps({
            "success": False,
            "error": "Usage: scan_agent_trust.py <skill_url>",
            "example": "scan_agent_trust.py https://skills.sh/author/skill-name"
        }))
        sys.exit(1)
    
    skill_url = sys.argv[1]
    result = scan_skill_url(skill_url)
    print(json.dumps(result, indent=2))
    
    # Exit 0 if can install, 1 if blocked, 2 if error
    if result.get("can_install") is None:
        sys.exit(2)
    elif result.get("can_install"):
        sys.exit(0)
    else:
        sys.exit(1)

if __name__ == "__main__":
    main()
