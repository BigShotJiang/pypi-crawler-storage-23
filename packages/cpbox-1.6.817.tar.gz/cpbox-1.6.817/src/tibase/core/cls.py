from typing import Dict, Type, Any

class Singleton:
    _instances: Dict[Type, Any] = {}
    
    def __new__(cls, *args, **kwargs):
        if cls not in cls._instances:
            cls._instances[cls] = super().__new__(cls)
        return cls._instances[cls]
    
    def __init__(self):
        # 确保初始化代码只执行一次
        if not hasattr(self, '_initialized'):
            self._initialized = True
            self._init_once()
    
    def _init_once(self):
        """子类可以重写此方法来进行一次性初始化"""
        pass