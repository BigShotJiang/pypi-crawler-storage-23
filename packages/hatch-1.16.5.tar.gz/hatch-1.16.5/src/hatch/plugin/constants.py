DEFAULT_CUSTOM_SCRIPT = "hatch_plugins.py"
