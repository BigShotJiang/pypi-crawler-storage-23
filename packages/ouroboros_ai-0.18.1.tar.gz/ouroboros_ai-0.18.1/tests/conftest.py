"""Pytest configuration for Ouroboros."""
