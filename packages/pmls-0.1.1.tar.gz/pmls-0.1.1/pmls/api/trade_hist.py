from dataclasses import fields

from py_clob_client import ClobClient, TradeParams

from pmls.models import TradeHistory

TRADE_HISTORY_KEYS = {f.name for f in fields(TradeHistory)}


def list_trade_history(
    cli: ClobClient,
    token_id: str = None,
    before: int = None,
    after: int = None,
    market: str = None,
) -> list[TradeHistory]:
    
    
    res = cli.get_trades(
        TradeParams(
            asset_id=token_id,
            before=before,
            after=after,
            market=market,
        )
    )

    trades: list[TradeHistory] = []
    for o in res:
        trade_kwargs = {k: o.get(k) for k in TRADE_HISTORY_KEYS}
        trades.append(TradeHistory(**trade_kwargs))

    return trades
