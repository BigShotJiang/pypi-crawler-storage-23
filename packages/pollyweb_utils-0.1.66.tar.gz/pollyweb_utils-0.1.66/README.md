# pollyweb-utils

Description...

## Installation

```bash
pip install pollyweb-utils
```

## Git Push Protection

Enable the repository pre-push hook (blocks pushes when tests fail):

```bash
./scripts/install-git-hooks.sh
```

What it does:
- Runs `.venv/bin/python -m pytest -q` (or `python3 -m pytest -q` if no venv) on every `git push`.
- Rejects the push if tests fail.
