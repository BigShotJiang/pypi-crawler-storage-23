from __future__ import annotations

import subprocess
import sys
from pathlib import Path


def test_nl_utils_legacy_suite() -> None:
    """Run the existing PW_UTILS suite through the legacy module entrypoint."""
    repo_root = Path(__file__).resolve().parents[1]
    result = subprocess.run(
        [sys.executable, "-m", "src.PW_UTILS.test"],
        cwd=repo_root,
        capture_output=True,
        text=True,
    )
    if result.returncode != 0:
        tail = "\n".join(result.stdout.splitlines()[-80:])
        error_tail = "\n".join(result.stderr.splitlines()[-80:])
        raise AssertionError(
            "Legacy PW_UTILS suite failed.\n"
            f"stdout tail:\n{tail}\n\nstderr tail:\n{error_tail}"
        )
