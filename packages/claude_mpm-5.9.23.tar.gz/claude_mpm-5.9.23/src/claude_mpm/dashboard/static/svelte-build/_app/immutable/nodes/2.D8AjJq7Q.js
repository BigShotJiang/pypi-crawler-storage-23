import{bC as m}from"../chunks/BnimKDg3.js";export{m as component};
