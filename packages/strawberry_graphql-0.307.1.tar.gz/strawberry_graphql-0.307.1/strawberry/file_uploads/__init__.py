from .scalars import Upload, UploadDefinition

__all__ = ["Upload", "UploadDefinition"]
