"""OpOp -- The Optimizer Optimizer.

Three modes:
  1. OptBrain: wraps any existing optimizer (Adam, SGD, etc.) with a learned brain
  2. TwinCrack: gradient-free optimization via twin learned perturbation agents
  3. Telemetry: crowdsourced brain intelligence — every run makes OpOp smarter

OptBrain watches your training and learns what helps. Drop-in, can't make things worse.
TwinCrack replaces gradients entirely. No .backward(). No autograd. Just two forward passes.
Telemetry collects anonymized optimizer experience across all users.

All brains train online via REINFORCE. All get better with every step.
All are ~6KB. All transfer across models.
"""

__version__ = "0.3.0"

from opop.brain import OptBrain, Brain, TrainingObserver
from opop.twin_crack import TwinCrack, PerturbBrain, PerturbObserver
from opop.telemetry import Telemetry

__all__ = [
    "OptBrain", "Brain", "TrainingObserver",
    "TwinCrack", "PerturbBrain", "PerturbObserver",
    "Telemetry",
]
