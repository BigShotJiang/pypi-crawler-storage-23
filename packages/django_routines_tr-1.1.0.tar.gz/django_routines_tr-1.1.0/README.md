# django-routines-tr

Django projeleri için tekrar kullanılabilir middleware, authentication backend ve yardımcı altyapı rutinleri.

Dil yönlendirmesi, admin erişim kontrolü, çok dilli slug yönetimi, e-posta ile giriş, görsel sıkıştırma ve rate limit aşımı loglama gibi tekrar eden altyapı kodlarını azaltmak için tasarlanmış, hafif ve production odaklı yardımcı araçlar içerir.

---

## Özellikler

- Dil duyarlı yönlendirme middleware’i  
- Admin erişim güvenlik middleware’i  
- Çok dilli slug üretimi (LANGUAGES’a göre otomatik slug set etme)  
- Çok dilli slug yönlendirme yardımcı fonksiyonu  
- Türkçe karakter uyumlu slugify fonksiyonu  
- E-posta ile giriş (authentication backend)  
- Model ImageField görsellerini otomatik WEBP’e çevirme ve sıkıştırma yardımcı fonksiyonu  
- django-ratelimit entegrasyonu ile detaylı rate limit aşımı loglama  

---

## Kurulum

```bash
pip install django-routines-tr
```

Not:  
Görsel sıkıştırma yardımcıları için `Pillow` gereklidir. Paket bağımlılıkları içinde otomatik kurulur.

---

## Middleware Kullanımı

`settings.py` dosyanıza middleware’leri ekleyin:

```python
MIDDLEWARE = [
    ...
    "django_routines.middleware.language_redirect.LanguageRedirectMiddleware",
    "django_routines.middleware.admin_redirect.AdminRedirectMiddleware",
]
```

### LanguageRedirectMiddleware

- URL’leri aktif dile göre otomatik olarak prefixler  
- Static ve media yollarını hariç tutar  
- `settings.LANGUAGES` ayarını dikkate alır  
- Çift dil prefix oluşumunu engeller  

### AdminRedirectMiddleware

- `/admin/` paneline sadece superuser erişimine izin verir  
- Yetkisiz erişimlerde HTTP 404 döner  
- Admin panelinin ifşa edilmesini azaltmaya yardımcı olur  

---

## Authentication

### EmailBackend

Kullanıcıların e-posta adresi ile giriş yapmasını sağlar.

`settings.py`:

```python
AUTHENTICATION_BACKENDS = [
    "django_routines.backends.email_backend.EmailBackend",
]
```

Örnek:

```python
from django.contrib.auth import authenticate

user = authenticate(request, username="user@example.com", password="secret")
if user is not None:
    pass
```

Not: Kullanıcı modelinizde `email` alanının unique olması önerilir.

---

## Yardımcı Fonksiyonlar

### turkce_slugify

Türkçe karakterleri ASCII uyumlu karşılıklarına çevirir ve ardından Django’nun `slugify` fonksiyonunu uygular.

```python
from django_routines.i18n.slugify import turkce_slugify

slug = turkce_slugify("İstanbul Şehir Rehberi")
# Çıktı: istanbul-sehir-rehberi
```

---

### coklu_dil_slug_uygula

Modelinizde `settings.LANGUAGES` içinde tanımlı dillere göre otomatik slug üretir ve ilgili slug alanlarına set eder.

- Ana alan: `isim` → `slug`  
- Diğer diller: `isim_en` → `slug_en`, `isim_de` → `slug_de`, `isim_ar` → `slug_ar` vb.  
- Model üzerinde ilgili alan yoksa güvenli şekilde atlanır  
- Slug üretimi için dışarıdan bir `slugify_fonksiyonu` alır  
- `settings.LANGUAGES` değiştiğinde otomatik uyum sağlar  

Örnek kullanım:

```python
from django.db import models
from django_routines.i18n.coklu_dil_slug_save import coklu_dil_slug_uygula
from django_routines.i18n.slugify_tr import turkce_slugify

class Blog(models.Model):
    isim = models.CharField(max_length=255)
    slug = models.SlugField(max_length=255, unique=True, blank=True, null=True)

    def save(self, *args, **kwargs):
        coklu_dil_slug_uygula(
            nesne=self,
            baslik_alani="isim",
            slug_alani="slug",
            slugify_fonksiyonu=turkce_slugify,
        )
        super().save(*args, **kwargs)
```

---

### redirect_to_correct_i18n_slug

Aktif dile göre doğru slug alanını kontrol eder ve gerekirse doğru slug’a yönlendirme yapar.

```python
from django_routines.i18n.slug_redirect import redirect_to_correct_i18n_slug
```

---

## Rate Limit Aşımı Loglama

### ratelimit_sinir

`django-ratelimit` ile birlikte çalışır.  
Rate limit aşıldığında (HTTP 429) detaylı güvenlik log’u üretir.

Loglanan bilgiler:

- Client IP (X-Forwarded-For destekli)
- Kullanıcı ID ve username (authenticated ise)
- Path ve HTTP method
- Query string
- Referer
- User-Agent
- Accept-Language
- Host
- Session key
- POST key listesi
- Truncate edilmiş body preview

### Kurulum

`settings.py` içine handler ekleyin:

```python
RATELIMIT_VIEW = "django_routines.ratelimit_sinir.ratelimit_exceeded"
```

### Cache Ayarı (Production Önerisi)

```python
CACHES = {
    "default": {
        "BACKEND": "django.core.cache.backends.redis.RedisCache",
        "LOCATION": "redis://127.0.0.1:6379/1",
    }
}
```

Multi-worker production ortamda `LocMemCache` önerilmez.

### View Üzerinde Kullanım

```python
from django_ratelimit.decorators import ratelimit

@ratelimit(key="ip", rate="3/m", method="POST", block=True)
def login_view(request):
    ...
```

Limit aşımı gerçekleştiğinde otomatik 429 döner ve güvenlik log'u üretilir.

### Logging Yapılandırma Önerisi

```python
LOGGING = {
    "version": 1,
    "disable_existing_loggers": False,
    "handlers": {
        "console": {"class": "logging.StreamHandler"},
    },
    "loggers": {
        "security.ratelimit": {
            "handlers": ["console"],
            "level": "WARNING",
            "propagate": False,
        },
    },
}
```

### Güvenlik Notu

`body_preview` request body içeriğini kısaltılmış şekilde loglayabilir.  
Şifre, token veya hassas veri içeren endpoint’lerde bu özelliğin kapatılması önerilir.

---

## Görsel Sıkıştırma

### resim_sikistir

Model üzerindeki bir `ImageField` alanını:

- Eski görsel değiştiyse `eski_<upload_to>/` klasörüne taşır  
- WEBP formatına çevirir  
- `max_kenar` ile en büyük boyutu sınırlar  
- `max_kb` altına düşene kadar kaliteyi optimize eder  

Örnek kullanım:

```python
from django.db import models
from django_routines.images.compress import resim_sikistir

class Urun(models.Model):
    resim = models.ImageField(upload_to="urun_resimleri/", blank=True, null=True)

    def save(self, *args, **kwargs):
        resim_sikistir(self, "resim", dosya_adi="urun", max_kb=200, max_kenar=1200)
        super().save(*args, **kwargs)
```

---

## Gereksinimler

- Python 3.10+
---

## Lisans

Apache Lisansı