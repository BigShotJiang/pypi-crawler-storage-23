"""Tests for the Legacy service client."""

import pytest
from pytest_httpx import HTTPXMock

from augur_api import AugurAPI
from augur_api.services.legacy.schemas import (
    AlsoBoughtItem,
    AlsoBoughtListParams,
    HealthCheckData,
    InvMastTag,
    InvMastTagCreateParams,
    InvMastTagsListParams,
    InvMastTagUpdateParams,
    InvMastWebDesc,
    InvMastWebDescCreateParams,
    InvMastWebDescListParams,
    InvMastWebDescUpdateParams,
    ItemCategory,
    OrderResetResponse,
    State,
    StateCreateParams,
    StateGetParams,
    StateListParams,
    StateUpdateParams,
)


class TestLegacySchemas:
    """Tests for Legacy schemas."""

    def test_health_check_data(self) -> None:
        """Should parse health check data."""
        data = {"siteHash": "abc123", "siteId": "test-site"}
        result = HealthCheckData.model_validate(data)
        assert result.site_id == "test-site"

    def test_state_list_params(self) -> None:
        """Should create state list params."""
        params = StateListParams(limit=10, offset=5, two_letter_code="CA")
        assert params.limit == 10
        assert params.offset == 5
        assert params.two_letter_code == "CA"

    def test_state_get_params(self) -> None:
        """Should create state get params."""
        params = StateGetParams(two_letter_code="CA")
        assert params.two_letter_code == "CA"
        assert params.edge_cache is None

    def test_state_model(self) -> None:
        """Should parse state data."""
        data = {
            "stateUid": 1,
            "stateCd": "CA",
            "stateName": "California",
            "countryCd": "US",
        }
        result = State.model_validate(data)
        assert result.state_uid == 1
        assert result.state_cd == "CA"
        assert result.state_name == "California"

    def test_state_create_params(self) -> None:
        """Should create state create params."""
        params = StateCreateParams()
        assert params is not None

    def test_state_update_params(self) -> None:
        """Should create state update params."""
        params = StateUpdateParams()
        assert params is not None

    def test_also_bought_list_params(self) -> None:
        """Should create also bought list params."""
        params = AlsoBoughtListParams(limit=10, offset=5)
        assert params.limit == 10
        assert params.offset == 5

    def test_also_bought_item_model(self) -> None:
        """Should parse also bought item data."""
        data = {"invMastUid": 1, "itemId": "ABC123", "itemDesc": "Test Item"}
        result = AlsoBoughtItem.model_validate(data)
        assert result.inv_mast_uid == 1
        assert result.item_id == "ABC123"

    def test_inv_mast_tags_list_params(self) -> None:
        """Should create inv mast tags list params."""
        params = InvMastTagsListParams(limit=10, offset=5)
        assert params.limit == 10

    def test_inv_mast_tag_model(self) -> None:
        """Should parse inv mast tag data."""
        data = {"invMastTagsUid": 1, "invMastUid": 100, "tag": "Featured"}
        result = InvMastTag.model_validate(data)
        assert result.inv_mast_tags_uid == 1
        assert result.tag == "Featured"

    def test_inv_mast_tag_create_params(self) -> None:
        """Should create inv mast tag create params."""
        params = InvMastTagCreateParams()
        assert params is not None

    def test_inv_mast_tag_update_params(self) -> None:
        """Should create inv mast tag update params."""
        params = InvMastTagUpdateParams()
        assert params is not None

    def test_inv_mast_web_desc_list_params(self) -> None:
        """Should create inv mast web desc list params."""
        params = InvMastWebDescListParams(limit=10, offset=5)
        assert params.limit == 10

    def test_inv_mast_web_desc_model(self) -> None:
        """Should parse inv mast web desc data."""
        data = {"invMastWebDescUid": 1, "invMastUid": 100, "description": "Test desc"}
        result = InvMastWebDesc.model_validate(data)
        assert result.inv_mast_web_desc_uid == 1
        assert result.description == "Test desc"

    def test_inv_mast_web_desc_create_params(self) -> None:
        """Should create inv mast web desc create params."""
        params = InvMastWebDescCreateParams()
        assert params is not None

    def test_inv_mast_web_desc_update_params(self) -> None:
        """Should create inv mast web desc update params."""
        params = InvMastWebDescUpdateParams()
        assert params is not None

    def test_item_category_model(self) -> None:
        """Should parse item category data."""
        data = {"itemCategoryUid": 1, "categoryName": "Electronics"}
        result = ItemCategory.model_validate(data)
        assert result.item_category_uid == 1
        assert result.category_name == "Electronics"

    def test_order_reset_response_model(self) -> None:
        """Should parse order reset response data."""
        data = {"status": "success"}
        result = OrderResetResponse.model_validate(data)
        assert result is not None


class TestLegacyClient:
    """Tests for LegacyClient."""

    @pytest.fixture
    def api(self) -> AugurAPI:
        """Create API client for testing."""
        return AugurAPI(token="test-token", site_id="test-site")

    def test_health_check(
        self, httpx_mock: HTTPXMock, api: AugurAPI, mock_health_check_response: dict
    ) -> None:
        """Should call health check endpoint."""
        httpx_mock.add_response(
            url="https://legacy.augur-api.com/health-check",
            json=mock_health_check_response,
        )
        response = api.legacy.health_check()
        assert response.data.site_id == "test-site"

    # State tests
    def test_state_list(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should list states."""
        mock_response = {
            "count": 1,
            "data": [{"stateUid": 1, "stateCd": "CA", "stateName": "California"}],
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://legacy.augur-api.com/legacy/state",
            json=mock_response,
        )
        response = api.legacy.state.list()
        assert len(response.data) == 1

    def test_state_get(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should get state by UID."""
        mock_response = {
            "count": 1,
            "data": {"stateUid": 1, "stateCd": "CA", "stateName": "California"},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://legacy.augur-api.com/legacy/state/1",
            json=mock_response,
        )
        response = api.legacy.state.get(1)
        assert response.data.state_uid == 1

    def test_state_create(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should create a state."""
        mock_response = {
            "count": 1,
            "data": {"stateUid": 1, "stateCd": "CA"},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://legacy.augur-api.com/legacy/state",
            json=mock_response,
        )
        response = api.legacy.state.create(StateCreateParams())
        assert response.data.state_uid == 1

    def test_state_update(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should update a state."""
        mock_response = {
            "count": 1,
            "data": {"stateUid": 1, "stateCd": "CA"},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://legacy.augur-api.com/legacy/state/1",
            json=mock_response,
        )
        response = api.legacy.state.update(1, StateUpdateParams())
        assert response.data.state_uid == 1

    def test_state_delete(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should delete a state."""
        mock_response = {
            "count": 1,
            "data": True,
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://legacy.augur-api.com/legacy/state/1",
            json=mock_response,
        )
        response = api.legacy.state.delete(1)
        assert response.data is True

    # Also bought tests
    def test_also_bought_list(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should list also bought items."""
        mock_response = {
            "count": 1,
            "data": [{"invMastUid": 2, "itemId": "DEF456"}],
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://legacy.augur-api.com/inv-mast/1/also-bought",
            json=mock_response,
        )
        response = api.legacy.also_bought.list(1)
        assert len(response.data) == 1

    # Inv mast tags tests
    def test_inv_mast_tags_list(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should list inv mast tags."""
        mock_response = {
            "count": 1,
            "data": [{"invMastTagsUid": 1, "tag": "Featured"}],
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://legacy.augur-api.com/inv-mast/1/tags",
            json=mock_response,
        )
        response = api.legacy.inv_mast_tags.list(1)
        assert len(response.data) == 1

    def test_inv_mast_tags_get(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should get inv mast tag by UID."""
        mock_response = {
            "count": 1,
            "data": {"invMastTagsUid": 1, "tag": "Featured"},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://legacy.augur-api.com/inv-mast/1/tags/1",
            json=mock_response,
        )
        response = api.legacy.inv_mast_tags.get(1, 1)
        assert response.data.inv_mast_tags_uid == 1

    def test_inv_mast_tags_create(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should create an inv mast tag."""
        mock_response = {
            "count": 1,
            "data": {"invMastTagsUid": 1, "tag": "Featured"},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://legacy.augur-api.com/inv-mast/1/tags",
            json=mock_response,
        )
        response = api.legacy.inv_mast_tags.create(1, InvMastTagCreateParams())
        assert response.data.inv_mast_tags_uid == 1

    def test_inv_mast_tags_update(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should update an inv mast tag."""
        mock_response = {
            "count": 1,
            "data": {"invMastTagsUid": 1, "tag": "Updated"},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://legacy.augur-api.com/inv-mast/1/tags/1",
            json=mock_response,
        )
        response = api.legacy.inv_mast_tags.update(1, 1, InvMastTagUpdateParams())
        assert response.data.inv_mast_tags_uid == 1

    def test_inv_mast_tags_delete(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should delete an inv mast tag."""
        mock_response = {
            "count": 1,
            "data": True,
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://legacy.augur-api.com/inv-mast/1/tags/1",
            json=mock_response,
        )
        response = api.legacy.inv_mast_tags.delete(1, 1)
        assert response.data is True

    # Inv mast web desc tests
    def test_inv_mast_web_desc_list(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should list inv mast web descriptions."""
        mock_response = {
            "count": 1,
            "data": [{"invMastWebDescUid": 1, "description": "Test"}],
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://legacy.augur-api.com/inv-mast/1/web-desc",
            json=mock_response,
        )
        response = api.legacy.inv_mast_web_desc.list(1)
        assert len(response.data) == 1

    def test_inv_mast_web_desc_get(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should get inv mast web description by UID."""
        mock_response = {
            "count": 1,
            "data": {"invMastWebDescUid": 1, "description": "Test"},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://legacy.augur-api.com/inv-mast/1/web-desc/1",
            json=mock_response,
        )
        response = api.legacy.inv_mast_web_desc.get(1, 1)
        assert response.data.inv_mast_web_desc_uid == 1

    def test_inv_mast_web_desc_create(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should create an inv mast web description."""
        mock_response = {
            "count": 1,
            "data": {"invMastWebDescUid": 1, "description": "Test"},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://legacy.augur-api.com/inv-mast/1/web-desc",
            json=mock_response,
        )
        response = api.legacy.inv_mast_web_desc.create(1, InvMastWebDescCreateParams())
        assert response.data.inv_mast_web_desc_uid == 1

    def test_inv_mast_web_desc_update(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should update an inv mast web description."""
        mock_response = {
            "count": 1,
            "data": {"invMastWebDescUid": 1, "description": "Updated"},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://legacy.augur-api.com/inv-mast/1/web-desc/1",
            json=mock_response,
        )
        response = api.legacy.inv_mast_web_desc.update(1, 1, InvMastWebDescUpdateParams())
        assert response.data.inv_mast_web_desc_uid == 1

    def test_inv_mast_web_desc_delete(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should delete an inv mast web description."""
        mock_response = {
            "count": 1,
            "data": True,
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://legacy.augur-api.com/inv-mast/1/web-desc/1",
            json=mock_response,
        )
        response = api.legacy.inv_mast_web_desc.delete(1, 1)
        assert response.data is True

    # Item category tests
    def test_item_category_get(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should get item category by UID."""
        mock_response = {
            "count": 1,
            "data": {"itemCategoryUid": 1, "categoryName": "Electronics"},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://legacy.augur-api.com/item-category/1",
            json=mock_response,
        )
        response = api.legacy.item_category.get(1)
        assert response.data.item_category_uid == 1

    # Orders tests
    def test_orders_reset(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should reset an order."""
        mock_response = {
            "count": 1,
            "data": {"status": "success"},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://legacy.augur-api.com/orders/1/reset",
            json=mock_response,
        )
        response = api.legacy.orders.reset(1)
        assert response is not None

    def test_resource_properties_return_same_instance(self, api: AugurAPI) -> None:
        """Should return same resource instance on multiple accesses."""
        client = api.legacy
        assert client.state is client.state
        assert client.also_bought is client.also_bought
        assert client.inv_mast_tags is client.inv_mast_tags
        assert client.inv_mast_web_desc is client.inv_mast_web_desc
        assert client.item_category is client.item_category
        assert client.orders is client.orders
