"""Tests for the P21 PIM service client."""

import pytest
from pytest_httpx import HTTPXMock

from augur_api import AugurAPI
from augur_api.services.p21_pim.schemas import (
    AISuggestionParams,
    HealthCheckData,
    InvMastExt,
    InvMastExtCreateParams,
    InvMastExtListParams,
    InvMastExtUpdateParams,
    Item,
    ItemListParams,
    ItemUpdateParams,
    Podcast,
    PodcastCreateParams,
    PodcastListParams,
    PodcastUpdateParams,
    SuggestDisplayDescResponse,
    SuggestWebDescResponse,
)


class TestP21PimSchemas:
    """Tests for P21 PIM schemas."""

    def test_health_check_data(self) -> None:
        """Should parse health check data."""
        data = {"siteHash": "abc123", "siteId": "test-site"}
        result = HealthCheckData.model_validate(data)
        assert result.site_id == "test-site"

    def test_item_list_params(self) -> None:
        """Should create item list params."""
        params = ItemListParams(limit=10, offset=5, item_id="ABC123")
        assert params.limit == 10
        assert params.item_id == "ABC123"

    def test_item_model(self) -> None:
        """Should parse item data."""
        data = {
            "invMastUid": 1,
            "itemId": "ABC123",
            "itemDesc": "Test Item",
            "extendedDesc": "Extended description",
            "seoTitle": "SEO Title",
        }
        result = Item.model_validate(data)
        assert result.inv_mast_uid == 1
        assert result.item_id == "ABC123"
        assert result.seo_title == "SEO Title"

    def test_item_update_params(self) -> None:
        """Should create item update params."""
        params = ItemUpdateParams(extended_desc="Updated description", seo_title="Updated SEO")
        assert params.extended_desc == "Updated description"
        assert params.seo_title == "Updated SEO"

    def test_podcast_list_params(self) -> None:
        """Should create podcast list params."""
        params = PodcastListParams(limit=10, offset=5)
        assert params.limit == 10

    def test_podcast_model(self) -> None:
        """Should parse podcast data."""
        data = {
            "podcastUid": 1,
            "title": "Test Podcast",
            "description": "Description",
            "audioUrl": "https://example.com/audio.mp3",
            "duration": 3600,
        }
        result = Podcast.model_validate(data)
        assert result.podcast_uid == 1
        assert result.title == "Test Podcast"
        assert result.duration == 3600

    def test_podcast_create_params(self) -> None:
        """Should create podcast create params."""
        params = PodcastCreateParams(title="New Podcast", description="Description", duration=1800)
        assert params.title == "New Podcast"
        assert params.duration == 1800

    def test_podcast_update_params(self) -> None:
        """Should create podcast update params."""
        params = PodcastUpdateParams(title="Updated Podcast", duration=2400)
        assert params.title == "Updated Podcast"
        assert params.duration == 2400

    def test_inv_mast_ext_list_params(self) -> None:
        """Should create inv mast ext list params."""
        params = InvMastExtListParams(limit=10, offset=5)
        assert params.limit == 10
        assert params.offset == 5

    def test_inv_mast_ext_model(self) -> None:
        """Should parse inv mast ext data."""
        data = {"invMastExtUid": 1, "invMastUid": 100}
        result = InvMastExt.model_validate(data)
        assert result.inv_mast_ext_uid == 1
        assert result.inv_mast_uid == 100

    def test_inv_mast_ext_create_params(self) -> None:
        """Should create inv mast ext create params."""
        params = InvMastExtCreateParams(inv_mast_uid=100)
        assert params.inv_mast_uid == 100

    def test_inv_mast_ext_update_params(self) -> None:
        """Should create inv mast ext update params."""
        params = InvMastExtUpdateParams()
        # Passthrough model - any fields allowed
        assert params is not None

    def test_ai_suggestion_params(self) -> None:
        """Should create AI suggestion params."""
        params = AISuggestionParams(limit=5, model="gpt-4")
        assert params.limit == 5
        assert params.model == "gpt-4"

    def test_suggest_display_desc_response(self) -> None:
        """Should parse suggest display desc response."""
        data = {"suggestions": ["suggestion1", "suggestion2"]}
        result = SuggestDisplayDescResponse.model_validate(data)
        # Passthrough allows any fields
        assert result is not None

    def test_suggest_web_desc_response(self) -> None:
        """Should parse suggest web desc response."""
        data = {"suggestions": ["suggestion1", "suggestion2"]}
        result = SuggestWebDescResponse.model_validate(data)
        # Passthrough allows any fields
        assert result is not None


class TestP21PimClient:
    """Tests for P21PimClient."""

    @pytest.fixture
    def api(self) -> AugurAPI:
        """Create API client for testing."""
        return AugurAPI(token="test-token", site_id="test-site")

    def test_health_check(
        self, httpx_mock: HTTPXMock, api: AugurAPI, mock_health_check_response: dict
    ) -> None:
        """Should call health check endpoint."""
        httpx_mock.add_response(
            url="https://p21-pim.augur-api.com/health-check",
            json=mock_health_check_response,
        )
        response = api.p21_pim.health_check()
        assert response.data.site_id == "test-site"

    def test_items_list(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should list items."""
        mock_response = {
            "count": 1,
            "data": [{"invMastUid": 1, "itemId": "ABC123"}],
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://p21-pim.augur-api.com/items",
            json=mock_response,
        )
        response = api.p21_pim.items.list()
        assert len(response.data) == 1

    def test_items_get(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should get item by UID."""
        mock_response = {
            "count": 1,
            "data": {"invMastUid": 1, "itemId": "ABC123"},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://p21-pim.augur-api.com/items/1",
            json=mock_response,
        )
        response = api.p21_pim.items.get(1)
        assert response.data.inv_mast_uid == 1

    def test_items_update(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should update item."""
        mock_response = {
            "count": 1,
            "data": {"invMastUid": 1, "itemId": "ABC123", "extendedDesc": "Updated"},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://p21-pim.augur-api.com/items/1",
            json=mock_response,
            method="PUT",
        )
        response = api.p21_pim.items.update(1, ItemUpdateParams(extended_desc="Updated"))
        assert response.data.inv_mast_uid == 1

    def test_podcasts_list(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should list podcasts."""
        mock_response = {
            "count": 1,
            "data": [{"podcastUid": 1, "title": "Test Podcast"}],
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://p21-pim.augur-api.com/podcasts",
            json=mock_response,
        )
        response = api.p21_pim.podcasts.list()
        assert len(response.data) == 1

    def test_podcasts_get(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should get podcast by UID."""
        mock_response = {
            "count": 1,
            "data": {"podcastUid": 1, "title": "Test Podcast"},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://p21-pim.augur-api.com/podcasts/1",
            json=mock_response,
        )
        response = api.p21_pim.podcasts.get(1)
        assert response.data.podcast_uid == 1

    def test_podcasts_create(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should create podcast."""
        mock_response = {
            "count": 1,
            "data": {"podcastUid": 1, "title": "New Podcast"},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://p21-pim.augur-api.com/podcasts",
            json=mock_response,
            method="POST",
        )
        response = api.p21_pim.podcasts.create(PodcastCreateParams(title="New Podcast"))
        assert response.data.podcast_uid == 1

    def test_podcasts_update(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should update podcast."""
        mock_response = {
            "count": 1,
            "data": {"podcastUid": 1, "title": "Updated Podcast"},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://p21-pim.augur-api.com/podcasts/1",
            json=mock_response,
            method="PUT",
        )
        response = api.p21_pim.podcasts.update(1, PodcastUpdateParams(title="Updated Podcast"))
        assert response.data.podcast_uid == 1

    def test_podcasts_delete(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should delete podcast."""
        mock_response = {
            "count": 1,
            "data": {"podcastUid": 1, "title": "Deleted Podcast"},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://p21-pim.augur-api.com/podcasts/1",
            json=mock_response,
            method="DELETE",
        )
        response = api.p21_pim.podcasts.delete(1)
        assert response.data.podcast_uid == 1

    def test_inv_mast_ext_list(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should list inventory master extensions."""
        mock_response = {
            "count": 1,
            "data": [{"invMastExtUid": 1, "invMastUid": 100}],
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://p21-pim.augur-api.com/inv-mast-ext",
            json=mock_response,
        )
        response = api.p21_pim.inv_mast_ext.list()
        assert len(response.data) == 1
        assert response.data[0].inv_mast_ext_uid == 1

    def test_inv_mast_ext_get(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should get inventory master extension by UID."""
        mock_response = {
            "count": 1,
            "data": {"invMastExtUid": 1, "invMastUid": 100},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://p21-pim.augur-api.com/inv-mast-ext/1",
            json=mock_response,
        )
        response = api.p21_pim.inv_mast_ext.get(1)
        assert response.data.inv_mast_ext_uid == 1

    def test_inv_mast_ext_create(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should create inventory master extension."""
        mock_response = {
            "count": 1,
            "data": {"invMastExtUid": 1, "invMastUid": 100},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://p21-pim.augur-api.com/inv-mast-ext",
            json=mock_response,
            method="POST",
        )
        response = api.p21_pim.inv_mast_ext.create(InvMastExtCreateParams(inv_mast_uid=100))
        assert response.data.inv_mast_ext_uid == 1

    def test_inv_mast_ext_update(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should update inventory master extension."""
        mock_response = {
            "count": 1,
            "data": {"invMastExtUid": 1, "invMastUid": 100},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://p21-pim.augur-api.com/inv-mast-ext/1",
            json=mock_response,
            method="PUT",
        )
        response = api.p21_pim.inv_mast_ext.update(1, InvMastExtUpdateParams())
        assert response.data.inv_mast_ext_uid == 1

    def test_inv_mast_ext_delete(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should delete inventory master extension."""
        mock_response = {
            "count": 1,
            "data": {"invMastExtUid": 1, "invMastUid": 100},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://p21-pim.augur-api.com/inv-mast-ext/1",
            json=mock_response,
            method="DELETE",
        )
        response = api.p21_pim.inv_mast_ext.delete(1)
        assert response.data.inv_mast_ext_uid == 1

    def test_items_suggest_display_desc(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should get AI display description suggestions."""
        mock_response = {
            "count": 1,
            "data": {"suggestions": ["suggestion1", "suggestion2"]},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://p21-pim.augur-api.com/items/1/suggest-display-desc",
            json=mock_response,
        )
        response = api.p21_pim.items.suggest_display_desc(1).get()
        assert response.data is not None

    def test_items_suggest_web_desc(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should get AI web description suggestions."""
        mock_response = {
            "count": 1,
            "data": {"suggestions": ["suggestion1", "suggestion2"]},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://p21-pim.augur-api.com/items/1/suggest-web-desc",
            json=mock_response,
        )
        response = api.p21_pim.items.suggest_web_desc(1).get()
        assert response.data is not None

    def test_resource_properties_return_same_instance(self, api: AugurAPI) -> None:
        """Should return same resource instance on multiple accesses."""
        client = api.p21_pim
        assert client.items is client.items
        assert client.podcasts is client.podcasts
        assert client.inv_mast_ext is client.inv_mast_ext
