"""Tests for the UPS service client."""

import pytest
from pytest_httpx import HTTPXMock

from augur_api import AugurAPI
from augur_api.services.ups.schemas import (
    HealthCheckData,
    RatesShopItem,
    RatesShopParams,
)


class TestUpsSchemas:
    """Tests for UPS schemas."""

    def test_health_check_data(self) -> None:
        """Should parse health check data."""
        data = {"siteHash": "abc123", "siteId": "test-site"}
        result = HealthCheckData.model_validate(data)
        assert result.site_id == "test-site"

    def test_rates_shop_params(self) -> None:
        """Should create rates shop params."""
        params = RatesShopParams(
            from_postal_code="90210",
            from_city="Los Angeles",
            to_postal_code="10001",
            to_city="New York",
            weight=5,
        )
        assert params.from_postal_code == "90210"
        assert params.to_postal_code == "10001"
        assert params.weight == 5

    def test_rates_shop_item(self) -> None:
        """Should parse rates shop item."""
        data = {"serviceCode": "03", "serviceName": "UPS Ground", "totalCharges": 12.99}
        result = RatesShopItem.model_validate(data)
        # Passthrough allows any fields via model_extra
        assert result.model_extra is not None or result.model_dump()


class TestUpsClient:
    """Tests for UpsClient."""

    @pytest.fixture
    def api(self) -> AugurAPI:
        """Create API client for testing."""
        return AugurAPI(token="test-token", site_id="test-site")

    def test_health_check(
        self, httpx_mock: HTTPXMock, api: AugurAPI, mock_health_check_response: dict
    ) -> None:
        """Should call health check endpoint."""
        httpx_mock.add_response(
            url="https://ups.augur-api.com/health-check",
            json=mock_health_check_response,
        )
        response = api.ups.health_check()
        assert response.data.site_id == "test-site"

    def test_ping(self, httpx_mock: HTTPXMock, api: AugurAPI, mock_ping_response: dict) -> None:
        """Should call ping endpoint."""
        httpx_mock.add_response(
            url="https://ups.augur-api.com/ping",
            json=mock_ping_response,
        )
        response = api.ups.ping()
        assert response.data == "pong"

    def test_rates_shop_get(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should get UPS rates."""
        # API returns array of rate objects directly in data field
        mock_response = {
            "count": 1,
            "data": [{"serviceCode": "03", "serviceName": "UPS Ground", "totalCharges": 12.99}],
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://ups.augur-api.com/rates-shop?fromPostalCode=90210&toPostalCode=10001&weight=5",
            json=mock_response,
        )
        response = api.ups.rates_shop.get(
            RatesShopParams(from_postal_code="90210", to_postal_code="10001", weight=5)
        )
        assert response.data is not None
        assert len(response.data) == 1
        # Extra fields are in model_extra (passthrough model)
        assert response.data[0].model_extra.get("serviceCode") == "03"

    def test_resource_properties_return_same_instance(self, api: AugurAPI) -> None:
        """Should return same resource instance on multiple accesses."""
        client = api.ups
        assert client.rates_shop is client.rates_shop
