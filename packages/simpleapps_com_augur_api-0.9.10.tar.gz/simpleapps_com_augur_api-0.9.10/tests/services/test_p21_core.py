"""Tests for the P21 Core service client."""

import pytest
from pytest_httpx import HTTPXMock

from augur_api import AugurAPI
from augur_api.services.p21_core import (
    Address,
    AddressListParams,
    Branch,
    BranchListParams,
    CashDrawer,
    CashDrawerListParams,
    Company,
    CompanyListParams,
    Location,
    LocationListParams,
)


class TestP21CoreSchemas:
    """Tests for P21 Core schemas."""

    def test_address_list_params(self) -> None:
        """Should create address list params."""
        params = AddressListParams(
            limit=10,
            offset=20,
            carrier_flag="Y",
            status_cd=1,
        )
        assert params.limit == 10
        assert params.carrier_flag == "Y"
        assert params.status_cd == 1

    def test_address_model(self) -> None:
        """Should parse address data."""
        data = {
            "address_id": 1,
            "name": "Main Office",
            "address_1": "123 Main St",
            "city": "Test City",
            "state": "CA",
            "postal_code": "12345",
        }
        address = Address.model_validate(data)
        assert address.address_id == 1
        assert address.name == "Main Office"
        assert address.city == "Test City"

    def test_branch_list_params(self) -> None:
        """Should create branch list params."""
        params = BranchListParams(limit=10, branch_id="BR001")
        assert params.limit == 10
        assert params.branch_id == "BR001"

    def test_branch_model(self) -> None:
        """Should parse branch data."""
        data = {
            "branch_id": "BR001",
            "branch_name": "Main Branch",
            "company_id": "CO001",
            "is_active": "Y",
        }
        branch = Branch.model_validate(data)
        assert branch.branch_id == "BR001"
        assert branch.branch_name == "Main Branch"

    def test_cash_drawer_list_params(self) -> None:
        """Should create cash drawer list params."""
        params = CashDrawerListParams(drawer_open="Y", q="search")
        assert params.drawer_open == "Y"
        assert params.q == "search"

    def test_cash_drawer_model(self) -> None:
        """Should parse cash drawer data."""
        data = {
            "cash_drawer_id": 1,
            "location_id": 100,
            "drawer_open": "Y",
            "opening_amount": 500.0,
        }
        drawer = CashDrawer.model_validate(data)
        assert drawer.cash_drawer_id == 1
        assert drawer.drawer_open == "Y"
        assert drawer.opening_amount == 500.0

    def test_company_list_params(self) -> None:
        """Should create company list params."""
        params = CompanyListParams(limit=10, q="test")
        assert params.limit == 10
        assert params.q == "test"

    def test_company_model(self) -> None:
        """Should parse company data."""
        data = {
            "company_id": "CO001",
            "company_name": "Test Company",
            "is_active": "Y",
        }
        company = Company.model_validate(data)
        assert company.company_id == "CO001"
        assert company.company_name == "Test Company"

    def test_location_list_params(self) -> None:
        """Should create location list params."""
        params = LocationListParams(limit=10, delete_flag="N")
        assert params.limit == 10
        assert params.delete_flag == "N"

    def test_location_model(self) -> None:
        """Should parse location data."""
        data = {
            "location_id": 100,
            "location_name": "Main Warehouse",
            "branch_id": "BR001",
            "is_active": "Y",
        }
        location = Location.model_validate(data)
        assert location.location_id == 100
        assert location.location_name == "Main Warehouse"


class TestP21CoreClient:
    """Tests for P21CoreClient."""

    @pytest.fixture
    def api(self) -> AugurAPI:
        """Create API client for testing."""
        return AugurAPI(token="test-token", site_id="test-site")

    def test_health_check(
        self, httpx_mock: HTTPXMock, api: AugurAPI, mock_health_check_response: dict
    ) -> None:
        """Should call health check endpoint."""
        httpx_mock.add_response(
            url="https://p21-core.augur-api.com/health-check",
            json=mock_health_check_response,
        )
        response = api.p21_core.health_check()
        assert response.data.site_id == "test-site"

    def test_address_list(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should list addresses."""
        mock_response = {
            "count": 1,
            "data": [{"address_id": 1, "name": "Main Office", "city": "Test City"}],
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "total_results": 1,
        }
        httpx_mock.add_response(
            url="https://p21-core.augur-api.com/address",
            json=mock_response,
        )
        response = api.p21_core.address.list()
        assert len(response.data) == 1
        assert response.data[0].name == "Main Office"

    def test_address_list_with_params(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should list addresses with params."""
        mock_response = {
            "count": 1,
            "data": [{"address_id": 1, "name": "Office", "city": "Test City"}],
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "total_results": 1,
        }
        httpx_mock.add_response(
            url="https://p21-core.augur-api.com/address?carrierFlag=Y",
            json=mock_response,
        )
        params = AddressListParams(carrier_flag="Y")
        response = api.p21_core.address.list(params)
        assert len(response.data) == 1

    def test_address_get(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should get address by ID."""
        mock_response = {
            "count": 1,
            "data": {"address_id": 1, "name": "Main Office"},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "total_results": 1,
        }
        httpx_mock.add_response(
            url="https://p21-core.augur-api.com/address/1",
            json=mock_response,
        )
        response = api.p21_core.address.get(1)
        assert response.data.address_id == 1

    def test_branch_list(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should list branches."""
        mock_response = {
            "count": 1,
            "data": [{"branch_id": "BR001", "branch_name": "Main Branch"}],
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "total_results": 1,
        }
        httpx_mock.add_response(
            url="https://p21-core.augur-api.com/branch",
            json=mock_response,
        )
        response = api.p21_core.branch.list()
        assert len(response.data) == 1
        assert response.data[0].branch_id == "BR001"

    def test_branch_get(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should get branch by ID."""
        mock_response = {
            "count": 1,
            "data": {"branch_id": "BR001", "branch_name": "Main Branch"},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "total_results": 1,
        }
        httpx_mock.add_response(
            url="https://p21-core.augur-api.com/branch/BR001",
            json=mock_response,
        )
        response = api.p21_core.branch.get("BR001")
        assert response.data.branch_id == "BR001"

    def test_cash_drawer_list(
        self, httpx_mock: HTTPXMock, api: AugurAPI, mock_cash_drawer_list_response: dict
    ) -> None:
        """Should list cash drawers."""
        httpx_mock.add_response(
            url="https://p21-core.augur-api.com/cash-drawer",
            json=mock_cash_drawer_list_response,
        )
        response = api.p21_core.cash_drawer.list()
        assert len(response.data) == 1
        assert response.data[0].drawer_open == "Y"

    def test_cash_drawer_list_with_params(
        self, httpx_mock: HTTPXMock, api: AugurAPI, mock_cash_drawer_list_response: dict
    ) -> None:
        """Should list cash drawers with params."""
        httpx_mock.add_response(
            url="https://p21-core.augur-api.com/cash-drawer?drawerOpen=Y",
            json=mock_cash_drawer_list_response,
        )
        params = CashDrawerListParams(drawer_open="Y")
        response = api.p21_core.cash_drawer.list(params)
        assert len(response.data) == 1

    def test_cash_drawer_get(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should get cash drawer by ID."""
        mock_response = {
            "count": 1,
            "data": {"cash_drawer_id": 1, "drawer_open": "Y"},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "total_results": 1,
        }
        httpx_mock.add_response(
            url="https://p21-core.augur-api.com/cash-drawer/1",
            json=mock_response,
        )
        response = api.p21_core.cash_drawer.get(1)
        assert response.data.cash_drawer_id == 1

    def test_company_list(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should list companies."""
        mock_response = {
            "count": 1,
            "data": [{"company_id": "CO001", "company_name": "Test Company"}],
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "total_results": 1,
        }
        httpx_mock.add_response(
            url="https://p21-core.augur-api.com/company",
            json=mock_response,
        )
        response = api.p21_core.company.list()
        assert len(response.data) == 1
        assert response.data[0].company_id == "CO001"

    def test_company_get(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should get company by ID."""
        mock_response = {
            "count": 1,
            "data": {"company_id": "CO001", "company_name": "Test Company"},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "total_results": 1,
        }
        httpx_mock.add_response(
            url="https://p21-core.augur-api.com/company/CO001",
            json=mock_response,
        )
        response = api.p21_core.company.get("CO001")
        assert response.data.company_id == "CO001"

    def test_location_list(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should list locations."""
        mock_response = {
            "count": 1,
            "data": [{"location_id": 100, "location_name": "Main Warehouse"}],
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "total_results": 1,
        }
        httpx_mock.add_response(
            url="https://p21-core.augur-api.com/location",
            json=mock_response,
        )
        response = api.p21_core.location.list()
        assert len(response.data) == 1
        assert response.data[0].location_id == 100

    def test_location_get(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should get location by ID."""
        mock_response = {
            "count": 1,
            "data": {"location_id": 100, "location_name": "Main Warehouse"},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "total_results": 1,
        }
        httpx_mock.add_response(
            url="https://p21-core.augur-api.com/location/100",
            json=mock_response,
        )
        response = api.p21_core.location.get(100)
        assert response.data.location_id == 100

    def test_address_refresh(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should trigger address data refresh."""
        mock_response = {
            "count": 1,
            "data": True,
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "total_results": 1,
        }
        httpx_mock.add_response(
            url="https://p21-core.augur-api.com/address/refresh",
            json=mock_response,
        )
        response = api.p21_core.address.refresh()
        assert response.data is True

    def test_address_corp_address(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should get corporate address."""
        mock_response = {
            "count": 1,
            "data": {"address_id": 2, "name": "Corp Office"},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "total_results": 1,
        }
        httpx_mock.add_response(
            url="https://p21-core.augur-api.com/address/1/corp-address",
            json=mock_response,
        )
        response = api.p21_core.address.corp_address(1)
        assert response.data.address_id == 2

    def test_address_default(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should get default address."""
        mock_response = {
            "count": 1,
            "data": {"address_id": 3, "name": "Default Office"},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "total_results": 1,
        }
        httpx_mock.add_response(
            url="https://p21-core.augur-api.com/address/1/default",
            json=mock_response,
        )
        response = api.p21_core.address.default(1)
        assert response.data.address_id == 3

    def test_address_enable(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should get address enable status."""
        mock_response = {
            "count": 1,
            "data": {"address_id": 1, "name": "Main Office"},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "total_results": 1,
        }
        httpx_mock.add_response(
            url="https://p21-core.augur-api.com/address/1/enable",
            json=mock_response,
        )
        response = api.p21_core.address.enable(1)
        assert response.data.address_id == 1

    def test_cash_drawer_underscore_list(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should list cash drawers via underscore endpoint."""
        mock_response = {
            "count": 1,
            "data": [{"cash_drawer_id": 1, "drawer_open": "Y"}],
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "total_results": 1,
        }
        httpx_mock.add_response(
            url="https://p21-core.augur-api.com/cash_drawer",
            json=mock_response,
        )
        response = api.p21_core.cash_drawer_underscore.list()
        assert len(response.data) == 1

    def test_cash_drawer_underscore_get(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should get cash drawer via underscore endpoint."""
        mock_response = {
            "count": 1,
            "data": {"cash_drawer_id": 1, "drawer_open": "Y"},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "total_results": 1,
        }
        httpx_mock.add_response(
            url="https://p21-core.augur-api.com/cash_drawer/1",
            json=mock_response,
        )
        response = api.p21_core.cash_drawer_underscore.get(1)
        assert response.data.cash_drawer_id == 1

    def test_code_p21_list(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should list code P21 records."""
        mock_response = {
            "count": 1,
            "data": [{"code_p21_uid": 1}],
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "total_results": 1,
        }
        httpx_mock.add_response(
            url="https://p21-core.augur-api.com/code-p21",
            json=mock_response,
        )
        response = api.p21_core.code_p21.list()
        assert len(response.data) == 1

    def test_payment_types_list(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should list payment types."""
        mock_response = {
            "count": 1,
            "data": [{"payment_type_uid": 1}],
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "total_results": 1,
        }
        httpx_mock.add_response(
            url="https://p21-core.augur-api.com/payment-types",
            json=mock_response,
        )
        response = api.p21_core.payment_types.list()
        assert len(response.data) == 1

    def test_resource_properties_return_same_instance(self, api: AugurAPI) -> None:
        """Resource properties should return same instance."""
        assert api.p21_core.address is api.p21_core.address
        assert api.p21_core.branch is api.p21_core.branch
        assert api.p21_core.cash_drawer is api.p21_core.cash_drawer
        assert api.p21_core.company is api.p21_core.company
        assert api.p21_core.location is api.p21_core.location
        assert api.p21_core.cash_drawer_underscore is api.p21_core.cash_drawer_underscore
        assert api.p21_core.code_p21 is api.p21_core.code_p21
        assert api.p21_core.payment_types is api.p21_core.payment_types
