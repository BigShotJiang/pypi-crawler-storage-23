"""Tests for the Pricing service client."""

import pytest
from pytest_httpx import HTTPXMock

from augur_api import AugurAPI
from augur_api.services.pricing.schemas import (
    HealthCheckData,
    JobPriceHdr,
    JobPriceHdrListParams,
    JobPriceLine,
    JobPriceLinesParams,
    PriceEngineParams,
    PriceEngineResult,
    TaxEngineAddress,
    TaxEngineItem,
    TaxEngineRequest,
    TaxEngineResult,
    TaxJurisdiction,
)


class TestPricingSchemas:
    """Tests for Pricing schemas."""

    def test_health_check_data(self) -> None:
        """Should parse health check data."""
        data = {"siteHash": "abc123", "siteId": "test-site"}
        result = HealthCheckData.model_validate(data)
        assert result.site_id == "test-site"

    def test_price_engine_params(self) -> None:
        """Should create price engine params."""
        params = PriceEngineParams(customer_id=100, item_id="ABC123", quantity=10.0, ship_to_id=5)
        assert params.customer_id == 100
        assert params.item_id == "ABC123"
        assert params.quantity == 10.0

    def test_price_engine_result_model(self) -> None:
        """Should parse price engine result data."""
        data = {
            "customerId": 100,
            "itemId": "ABC123",
            "quantity": 10.0,
            "unitPrice": 29.99,
            "basePrice": 35.00,
            "extendedPrice": 299.90,
            "discountPercent": 14.31,
        }
        result = PriceEngineResult.model_validate(data)
        assert result.customer_id == 100
        assert result.unit_price == 29.99
        assert result.extended_price == 299.90

    def test_tax_engine_item(self) -> None:
        """Should create tax engine item."""
        item = TaxEngineItem(
            item_id="ABC123", quantity=10.0, unit_price=29.99, extended_amount=299.90
        )
        assert item.item_id == "ABC123"
        assert item.extended_amount == 299.90

    def test_tax_engine_address(self) -> None:
        """Should create tax engine address."""
        address = TaxEngineAddress(
            street="123 Main St", city="Anytown", state="CA", postal_code="90210"
        )
        assert address.postal_code == "90210"

    def test_tax_engine_request(self) -> None:
        """Should create tax engine request."""
        request = TaxEngineRequest(
            customer_id=100,
            postal_code="90210",
            items=[
                TaxEngineItem(
                    item_id="ABC123",
                    quantity=10.0,
                    unit_price=29.99,
                    extended_amount=299.90,
                )
            ],
        )
        assert request.customer_id == 100
        assert len(request.items) == 1

    def test_tax_jurisdiction_model(self) -> None:
        """Should parse tax jurisdiction data."""
        data = {
            "jurisdictionName": "California",
            "jurisdictionType": "state",
            "taxRate": 0.0725,
            "taxAmount": 21.74,
        }
        result = TaxJurisdiction.model_validate(data)
        assert result.jurisdiction_name == "California"
        assert result.tax_rate == 0.0725

    def test_tax_engine_result_model(self) -> None:
        """Should parse tax engine result data."""
        data = {
            "totalTax": 21.74,
            "totalRate": 0.0725,
            "taxableAmount": 299.90,
            "jurisdictions": [{"jurisdictionName": "California", "taxRate": 0.0725}],
        }
        result = TaxEngineResult.model_validate(data)
        assert result.total_tax == 21.74
        assert len(result.jurisdictions) == 1

    def test_job_price_hdr_list_params(self) -> None:
        """Should create job price header list params."""
        params = JobPriceHdrListParams(limit=10, q="test")
        assert params.limit == 10
        assert params.q == "test"

    def test_job_price_hdr_model(self) -> None:
        """Should parse job price header data."""
        data = {
            "jobPriceHdrUid": 1,
            "customerId": 100,
            "jobName": "Test Job",
            "statusCd": 1,
        }
        result = JobPriceHdr.model_validate(data)
        assert result.job_price_hdr_uid == 1
        assert result.job_name == "Test Job"

    def test_job_price_lines_params(self) -> None:
        """Should create job price lines params."""
        params = JobPriceLinesParams(limit=10, inv_mast_uid=5)
        assert params.inv_mast_uid == 5

    def test_job_price_line_model(self) -> None:
        """Should parse job price line data."""
        data = {
            "jobPriceLineUid": 1,
            "jobPriceHdrUid": 1,
            "invMastUid": 5,
            "itemId": "ABC123",
            "unitPrice": 29.99,
            "quantity": 10.0,
        }
        result = JobPriceLine.model_validate(data)
        assert result.job_price_line_uid == 1
        assert result.unit_price == 29.99


class TestPricingClient:
    """Tests for PricingClient."""

    @pytest.fixture
    def api(self) -> AugurAPI:
        """Create API client for testing."""
        return AugurAPI(token="test-token", site_id="test-site")

    def test_health_check(
        self, httpx_mock: HTTPXMock, api: AugurAPI, mock_health_check_response: dict
    ) -> None:
        """Should call health check endpoint."""
        httpx_mock.add_response(
            url="https://pricing.augur-api.com/health-check",
            json=mock_health_check_response,
        )
        response = api.pricing.health_check()
        assert response.data.site_id == "test-site"

    def test_price_engine_get(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should get item price."""
        mock_response = {
            "count": 1,
            "data": {"customerId": 100, "itemId": "ABC123", "unitPrice": 29.99},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://pricing.augur-api.com/price-engine?customerId=100&itemId=ABC123",
            json=mock_response,
        )
        response = api.pricing.price_engine.get(
            PriceEngineParams(customer_id=100, item_id="ABC123")
        )
        assert response.data.unit_price == 29.99

    def test_tax_engine_calculate(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should calculate tax."""
        mock_response = {
            "count": 1,
            "data": {"totalTax": 21.74, "totalRate": 0.0725},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://pricing.augur-api.com/tax-engine",
            json=mock_response,
            method="POST",
        )
        response = api.pricing.tax_engine.calculate(
            TaxEngineRequest(
                customer_id=100,
                postal_code="90210",
                items=[
                    TaxEngineItem(
                        item_id="ABC123",
                        quantity=10.0,
                        unit_price=29.99,
                        extended_amount=299.90,
                    )
                ],
            )
        )
        assert response.data.total_tax == 21.74

    def test_job_price_hdr_list(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should list job price headers."""
        mock_response = {
            "count": 1,
            "data": [{"jobPriceHdrUid": 1, "jobName": "Test Job"}],
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://pricing.augur-api.com/job-price-hdr",
            json=mock_response,
        )
        response = api.pricing.job_price_hdr.list()
        assert len(response.data) == 1

    def test_job_price_hdr_get(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should get job price header by UID."""
        mock_response = {
            "count": 1,
            "data": {"jobPriceHdrUid": 1, "jobName": "Test Job"},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://pricing.augur-api.com/job-price-hdr/1",
            json=mock_response,
        )
        response = api.pricing.job_price_hdr.get(1)
        assert response.data.job_price_hdr_uid == 1

    def test_job_price_hdr_list_lines(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should list job price lines."""
        mock_response = {
            "count": 1,
            "data": [{"jobPriceLineUid": 1, "jobPriceHdrUid": 1}],
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://pricing.augur-api.com/job-price-hdr/1/lines",
            json=mock_response,
        )
        response = api.pricing.job_price_hdr.list_lines(1)
        assert len(response.data) == 1

    def test_job_price_hdr_get_line(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should get specific job price line."""
        mock_response = {
            "count": 1,
            "data": {"jobPriceLineUid": 1, "jobPriceHdrUid": 1},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://pricing.augur-api.com/job-price-hdr/1/lines/1",
            json=mock_response,
        )
        response = api.pricing.job_price_hdr.get_line(1, 1)
        assert response.data.job_price_line_uid == 1

    def test_resource_properties_return_same_instance(self, api: AugurAPI) -> None:
        """Should return same resource instance on multiple accesses."""
        client = api.pricing
        assert client.price_engine is client.price_engine
        assert client.tax_engine is client.tax_engine
        assert client.job_price_hdr is client.job_price_hdr
