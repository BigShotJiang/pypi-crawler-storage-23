"""Tests for the Basecamp2 service client."""

import pytest
from pytest_httpx import HTTPXMock

from augur_api import AugurAPI
from augur_api.services.basecamp2 import (
    Comment,
    CommentCreateParams,
    CommentListParams,
    Event,
    EventListParams,
    Metric,
    MetricsListParams,
    Person,
    PersonListParams,
    Project,
    ProjectListParams,
    Todo,
    TodoCreateParams,
    Todolist,
    TodolistListParams,
    TodoListParams,
    TodosSummary,
    TodosSummaryListParams,
    TodoUpdateParams,
)
from augur_api.services.basecamp2.schemas import (
    HealthCheckData,
    SessionCreateParams,
    SessionUpdateParams,
)


class TestBasecamp2Schemas:
    """Tests for Basecamp2 schemas."""

    def test_health_check_data(self) -> None:
        """Should parse health check data."""
        data = {"siteHash": "abc123", "siteId": "test-site"}
        result = HealthCheckData.model_validate(data)
        assert result.site_id == "test-site"
        assert result.site_hash == "abc123"

    def test_project_list_params(self) -> None:
        """Should create project list params."""
        params = ProjectListParams(limit=10, offset=5)
        assert params.limit == 10
        assert params.offset == 5

    def test_project_list_params_defaults(self) -> None:
        """Should have None defaults."""
        params = ProjectListParams()
        assert params.limit is None
        assert params.offset is None

    def test_project_model(self) -> None:
        """Should parse project data."""
        data = {
            "projectsUid": 1,
            "bcProjectId": 12345,
            "name": "Test Project",
            "description": "A test project",
            "status": "active",
        }
        result = Project.model_validate(data)
        assert result.projects_uid == 1
        assert result.bc_project_id == 12345
        assert result.name == "Test Project"

    def test_todo_list_params(self) -> None:
        """Should create todo list params."""
        params = TodoListParams(limit=10, projects_id=1, completed_flag="N")
        assert params.limit == 10
        assert params.projects_id == 1
        assert params.completed_flag == "N"

    def test_todo_model(self) -> None:
        """Should parse todo data."""
        data = {
            "todosUid": 1,
            "bcTodoId": 12345,
            "content": "Test Todo",
            "completed": False,
            "dueAt": "2024-01-15T00:00:00Z",
        }
        result = Todo.model_validate(data)
        assert result.todos_uid == 1
        assert result.content == "Test Todo"
        assert result.completed is False

    def test_todo_create_params(self) -> None:
        """Should create todo create params."""
        params = TodoCreateParams(content="New Todo", todolist_id=1)
        assert params.content == "New Todo"
        assert params.todolist_id == 1

    def test_todo_update_params(self) -> None:
        """Should create todo update params."""
        params = TodoUpdateParams(content="Updated Todo", completed=True)
        assert params.content == "Updated Todo"
        assert params.completed is True

    def test_person_list_params(self) -> None:
        """Should create person list params."""
        params = PersonListParams(limit=10, offset=5)
        assert params.limit == 10
        assert params.offset == 5

    def test_person_model(self) -> None:
        """Should parse person data."""
        data = {
            "peopleUid": 1,
            "bcPersonId": 12345,
            "name": "John Doe",
            "emailAddress": "john@example.com",
            "admin": True,
        }
        result = Person.model_validate(data)
        assert result.people_uid == 1
        assert result.name == "John Doe"
        assert result.email_address == "john@example.com"
        assert result.admin is True

    def test_comment_list_params(self) -> None:
        """Should create comment list params."""
        params = CommentListParams(limit=10, todos_id=1)
        assert params.limit == 10
        assert params.todos_id == 1

    def test_comment_model(self) -> None:
        """Should parse comment data."""
        data = {
            "commentsUid": 1,
            "bcCommentId": 12345,
            "content": "Test Comment",
            "creatorId": 1,
            "todoId": 1,
        }
        result = Comment.model_validate(data)
        assert result.comments_uid == 1
        assert result.content == "Test Comment"

    def test_comment_create_params(self) -> None:
        """Should create comment create params."""
        params = CommentCreateParams(content="New Comment", todo_id=1)
        assert params.content == "New Comment"
        assert params.todo_id == 1

    def test_event_list_params(self) -> None:
        """Should create event list params."""
        params = EventListParams(limit=10, offset=5)
        assert params.limit == 10
        assert params.offset == 5

    def test_event_model(self) -> None:
        """Should parse event data."""
        data = {"eventsUid": 1, "type": "todo_created"}
        result = Event.model_validate(data)
        assert result.events_uid == 1

    def test_metrics_list_params(self) -> None:
        """Should create metrics list params."""
        params = MetricsListParams(limit=10, offset=5)
        assert params.limit == 10
        assert params.offset == 5

    def test_metric_model(self) -> None:
        """Should parse metric data."""
        data = {"name": "completed_todos", "value": 42}
        result = Metric.model_validate(data)
        # Passthrough allows any fields
        assert hasattr(result, "model_extra") or "name" in result.model_dump()

    def test_todolist_list_params(self) -> None:
        """Should create todolist list params."""
        params = TodolistListParams(limit=10, offset=5)
        assert params.limit == 10
        assert params.offset == 5

    def test_todolist_model(self) -> None:
        """Should parse todolist data."""
        data = {"todolistsUid": 1, "name": "Sprint Tasks"}
        result = Todolist.model_validate(data)
        assert result.todolists_uid == 1
        assert result.name == "Sprint Tasks"

    def test_todos_summary_list_params(self) -> None:
        """Should create todos summary list params."""
        params = TodosSummaryListParams(limit=10, offset=5)
        assert params.limit == 10
        assert params.offset == 5

    def test_todos_summary_model(self) -> None:
        """Should parse todos summary data."""
        data = {"todosSummaryUid": 1, "total": 100, "completed": 75}
        result = TodosSummary.model_validate(data)
        assert result.todos_summary_uid == 1


class TestBasecamp2Client:
    """Tests for Basecamp2Client."""

    @pytest.fixture
    def api(self) -> AugurAPI:
        """Create API client for testing."""
        return AugurAPI(token="test-token", site_id="test-site")

    def test_health_check(
        self, httpx_mock: HTTPXMock, api: AugurAPI, mock_health_check_response: dict
    ) -> None:
        """Should call health check endpoint."""
        httpx_mock.add_response(
            url="https://basecamp2.augur-api.com/health-check",
            json=mock_health_check_response,
        )
        response = api.basecamp2.health_check()
        assert response.data.site_id == "test-site"

    def test_ping(self, httpx_mock: HTTPXMock, api: AugurAPI, mock_ping_response: dict) -> None:
        """Should call ping endpoint."""
        httpx_mock.add_response(
            url="https://basecamp2.augur-api.com/ping",
            json=mock_ping_response,
        )
        response = api.basecamp2.ping()
        assert response.data == "pong"

    def test_whoami(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should call whoami endpoint."""
        mock_response = {
            "count": 1,
            "data": {"user_id": "test-user", "email": "test@example.com"},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://basecamp2.augur-api.com/whoami",
            json=mock_response,
        )
        response = api.basecamp2.whoami()
        assert response.data["user_id"] == "test-user"

    def test_projects_list(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should list projects."""
        mock_response = {
            "count": 1,
            "data": [{"projectsUid": 1, "name": "Test Project"}],
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://basecamp2.augur-api.com/projects",
            json=mock_response,
        )
        response = api.basecamp2.projects.list()
        assert len(response.data) == 1
        assert response.data[0].name == "Test Project"

    def test_projects_get(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should get project by UID."""
        mock_response = {
            "count": 1,
            "data": {"projectsUid": 1, "name": "Test Project"},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://basecamp2.augur-api.com/projects/1",
            json=mock_response,
        )
        response = api.basecamp2.projects.get(1)
        assert response.data.projects_uid == 1

    def test_todos_list(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should list todos."""
        mock_response = {
            "count": 1,
            "data": [{"todosUid": 1, "content": "Test Todo"}],
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://basecamp2.augur-api.com/todos",
            json=mock_response,
        )
        response = api.basecamp2.todos.list()
        assert len(response.data) == 1
        assert response.data[0].content == "Test Todo"

    def test_todos_get(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should get todo by UID."""
        mock_response = {
            "count": 1,
            "data": {"todosUid": 1, "content": "Test Todo"},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://basecamp2.augur-api.com/todos/1",
            json=mock_response,
        )
        response = api.basecamp2.todos.get(1)
        assert response.data.todos_uid == 1

    def test_todos_create(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should create todo."""
        mock_response = {
            "count": 1,
            "data": {"todosUid": 1, "content": "New Todo"},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://basecamp2.augur-api.com/todos",
            json=mock_response,
            method="POST",
        )
        data = TodoCreateParams(content="New Todo", todolist_id=1)
        response = api.basecamp2.todos.create(data)
        assert response.data.content == "New Todo"

    def test_todos_update(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should update todo."""
        mock_response = {
            "count": 1,
            "data": {"todosUid": 1, "content": "Updated Todo", "completed": True},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://basecamp2.augur-api.com/todos/1",
            json=mock_response,
            method="PUT",
        )
        data = TodoUpdateParams(content="Updated Todo", completed=True)
        response = api.basecamp2.todos.update(1, data)
        assert response.data.completed is True

    def test_todos_delete(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should delete todo."""
        mock_response = {
            "count": 1,
            "data": True,
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://basecamp2.augur-api.com/todos/1",
            json=mock_response,
            method="DELETE",
        )
        response = api.basecamp2.todos.delete(1)
        assert response.data is True

    def test_people_list(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should list people."""
        mock_response = {
            "count": 1,
            "data": [{"peopleUid": 1, "name": "John Doe"}],
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://basecamp2.augur-api.com/people",
            json=mock_response,
        )
        response = api.basecamp2.people.list()
        assert len(response.data) == 1
        assert response.data[0].name == "John Doe"

    def test_people_get(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should get person by UID."""
        mock_response = {
            "count": 1,
            "data": {"peopleUid": 1, "name": "John Doe"},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://basecamp2.augur-api.com/people/1",
            json=mock_response,
        )
        response = api.basecamp2.people.get(1)
        assert response.data.people_uid == 1

    def test_comments_list(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should list comments."""
        mock_response = {
            "count": 1,
            "data": [{"commentsUid": 1, "content": "Test Comment"}],
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://basecamp2.augur-api.com/comments",
            json=mock_response,
        )
        response = api.basecamp2.comments.list()
        assert len(response.data) == 1
        assert response.data[0].content == "Test Comment"

    def test_comments_get(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should get comment by UID."""
        mock_response = {
            "count": 1,
            "data": {"commentsUid": 1, "content": "Test Comment"},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://basecamp2.augur-api.com/comments/1",
            json=mock_response,
        )
        response = api.basecamp2.comments.get(1)
        assert response.data.comments_uid == 1

    def test_comments_create(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should create comment."""
        mock_response = {
            "count": 1,
            "data": {"commentsUid": 1, "content": "New Comment"},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://basecamp2.augur-api.com/comments",
            json=mock_response,
            method="POST",
        )
        data = CommentCreateParams(content="New Comment", todo_id=1)
        response = api.basecamp2.comments.create(data)
        assert response.data.content == "New Comment"

    def test_events_list(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should list events."""
        mock_response = {
            "count": 1,
            "data": [{"eventsUid": 1, "type": "todo_created"}],
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://basecamp2.augur-api.com/events",
            json=mock_response,
        )
        response = api.basecamp2.events.list()
        assert len(response.data) == 1
        assert response.data[0].events_uid == 1

    def test_metrics_list(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should list metrics."""
        mock_response = {
            "count": 1,
            "data": [{"name": "completed_todos", "value": 42}],
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://basecamp2.augur-api.com/metrics",
            json=mock_response,
        )
        response = api.basecamp2.metrics.list()
        assert len(response.data) == 1

    def test_todolists_list(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should list todolists."""
        mock_response = {
            "count": 1,
            "data": [{"todolistsUid": 1, "name": "Sprint Tasks"}],
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://basecamp2.augur-api.com/todolists",
            json=mock_response,
        )
        response = api.basecamp2.todolists.list()
        assert len(response.data) == 1
        assert response.data[0].name == "Sprint Tasks"

    def test_todolists_get(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should get todolist by UID."""
        mock_response = {
            "count": 1,
            "data": {"todolistsUid": 1, "name": "Sprint Tasks"},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://basecamp2.augur-api.com/todolists/1",
            json=mock_response,
        )
        response = api.basecamp2.todolists.get(1)
        assert response.data.todolists_uid == 1

    def test_todos_summary_list(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should list todos summary."""
        mock_response = {
            "count": 1,
            "data": [{"todosSummaryUid": 1, "total": 100, "completed": 75}],
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://basecamp2.augur-api.com/todos-summary",
            json=mock_response,
        )
        response = api.basecamp2.todos_summary.list()
        assert len(response.data) == 1
        assert response.data[0].todos_summary_uid == 1

    def test_todos_summary_get(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should get todos summary by UID."""
        mock_response = {
            "count": 1,
            "data": {"todosSummaryUid": 1, "total": 100, "completed": 75},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://basecamp2.augur-api.com/todos-summary/1",
            json=mock_response,
        )
        response = api.basecamp2.todos_summary.get(1)
        assert response.data.todos_summary_uid == 1

    def test_projects_metrics(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should get project metrics."""
        mock_response = {
            "count": 1,
            "data": {"name": "completed_todos", "value": 42},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://basecamp2.augur-api.com/projects/1/metrics",
            json=mock_response,
        )
        response = api.basecamp2.projects.metrics(1)
        assert response.status == 200

    def test_projects_todolists(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should get project todolists."""
        mock_response = {
            "count": 1,
            "data": [{"todolistsUid": 1, "name": "Sprint Tasks"}],
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://basecamp2.augur-api.com/projects/1/todolists",
            json=mock_response,
        )
        response = api.basecamp2.projects.todolists(1)
        assert len(response.data) == 1

    def test_projects_todolist_todos(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should get todos for a project todolist."""
        mock_response = {
            "count": 1,
            "data": [{"todosUid": 1, "content": "Task"}],
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://basecamp2.augur-api.com/projects/1/todolists/2/todos",
            json=mock_response,
        )
        response = api.basecamp2.projects.todolist_todos(1, 2)
        assert len(response.data) == 1

    def test_todos_event(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should get a specific event for a todo."""
        mock_response = {
            "count": 1,
            "data": {"eventsUid": 1, "type": "todo_created"},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://basecamp2.augur-api.com/todos/1/events/2",
            json=mock_response,
        )
        response = api.basecamp2.todos.event(1, 2)
        assert response.data.events_uid == 1

    def test_todos_metrics(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should get metrics for a todo."""
        mock_response = {
            "count": 1,
            "data": {"name": "sessions", "value": 5},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://basecamp2.augur-api.com/todos/1/metrics",
            json=mock_response,
        )
        response = api.basecamp2.todos.metrics(1)
        assert response.status == 200

    def test_todos_list_sessions(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should list sessions for a todo."""
        mock_response = {
            "count": 1,
            "data": [{"session_id": 1}],
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://basecamp2.augur-api.com/todos/1/sessions",
            json=mock_response,
        )
        response = api.basecamp2.todos.list_sessions(1)
        assert len(response.data) == 1

    def test_todos_create_session(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should create a session for a todo."""
        mock_response = {
            "count": 1,
            "data": {"session_id": 1},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://basecamp2.augur-api.com/todos/1/sessions",
            json=mock_response,
            method="POST",
        )
        response = api.basecamp2.todos.create_session(1, SessionCreateParams())
        assert response.data.session_id == 1

    def test_todos_get_session(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should get a specific session for a todo."""
        mock_response = {
            "count": 1,
            "data": {"session_id": 5},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://basecamp2.augur-api.com/todos/1/sessions/5",
            json=mock_response,
        )
        response = api.basecamp2.todos.get_session(1, 5)
        assert response.data.session_id == 5

    def test_todos_update_session(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should update a session for a todo."""
        mock_response = {
            "count": 1,
            "data": {"session_id": 5},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://basecamp2.augur-api.com/todos/1/sessions/5",
            json=mock_response,
            method="PUT",
        )
        response = api.basecamp2.todos.update_session(1, 5, SessionUpdateParams())
        assert response.data.session_id == 5

    def test_todos_delete_session(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should delete a session for a todo."""
        mock_response = {
            "count": 1,
            "data": True,
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://basecamp2.augur-api.com/todos/1/sessions/5",
            json=mock_response,
            method="DELETE",
        )
        response = api.basecamp2.todos.delete_session(1, 5)
        assert response.data is True

    def test_people_metrics(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should get metrics for a person."""
        mock_response = {
            "count": 1,
            "data": {"name": "todos_completed", "value": 10},
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://basecamp2.augur-api.com/people/1/metrics",
            json=mock_response,
        )
        response = api.basecamp2.people.metrics(1)
        assert response.status == 200

    def test_people_project_todos(self, httpx_mock: HTTPXMock, api: AugurAPI) -> None:
        """Should get todos for a person in a project."""
        mock_response = {
            "count": 1,
            "data": [{"todosUid": 1, "content": "Task"}],
            "message": "Success",
            "options": [],
            "params": [],
            "status": 200,
            "total": 1,
            "totalResults": 1,
        }
        httpx_mock.add_response(
            url="https://basecamp2.augur-api.com/people/1/projects/2/todos",
            json=mock_response,
        )
        response = api.basecamp2.people.project_todos(1, 2)
        assert len(response.data) == 1

    def test_resource_properties_return_same_instance(self, api: AugurAPI) -> None:
        """Should return same resource instance on multiple accesses."""
        client = api.basecamp2
        assert client.projects is client.projects
        assert client.todos is client.todos
        assert client.people is client.people
        assert client.comments is client.comments
        assert client.events is client.events
        assert client.metrics is client.metrics
        assert client.todolists is client.todolists
        assert client.todos_summary is client.todos_summary
