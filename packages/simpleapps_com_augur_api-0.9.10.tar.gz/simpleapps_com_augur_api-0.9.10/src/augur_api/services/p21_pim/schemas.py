"""Schemas for the P21 PIM service."""

from pydantic import BaseModel

from augur_api.core.schemas import CamelCaseModel, EdgeCacheParams


# Health Check
class HealthCheckData(CamelCaseModel):
    """Health check response data."""

    site_hash: str | None = None
    site_id: str | None = None


# Items
class ItemListParams(EdgeCacheParams):
    """Parameters for listing items."""

    limit: int | None = None
    offset: int | None = None
    item_id: str | None = None


class Item(CamelCaseModel):
    """PIM item entity."""

    inv_mast_uid: int | None = None
    item_id: str | None = None
    item_desc: str | None = None
    extended_desc: str | None = None
    marketing_desc: str | None = None
    features: str | None = None
    specifications: str | None = None
    seo_title: str | None = None
    seo_description: str | None = None
    created_at: str | None = None
    updated_at: str | None = None


class ItemUpdateParams(BaseModel):
    """Parameters for updating an item."""

    extended_desc: str | None = None
    marketing_desc: str | None = None
    features: str | None = None
    specifications: str | None = None
    seo_title: str | None = None
    seo_description: str | None = None


# Podcasts
class PodcastListParams(EdgeCacheParams):
    """Parameters for listing podcasts."""

    limit: int | None = None
    offset: int | None = None


class Podcast(CamelCaseModel):
    """Podcast entity."""

    podcast_uid: int | None = None
    title: str | None = None
    description: str | None = None
    audio_url: str | None = None
    duration: int | None = None
    published_at: str | None = None
    created_at: str | None = None


class PodcastCreateParams(BaseModel):
    """Parameters for creating a podcast."""

    title: str
    description: str | None = None
    audio_url: str | None = None
    duration: int | None = None


class PodcastUpdateParams(BaseModel):
    """Parameters for updating a podcast."""

    title: str | None = None
    description: str | None = None
    audio_url: str | None = None
    duration: int | None = None


# Inventory Master Extension
class InvMastExtListParams(EdgeCacheParams):
    """Parameters for listing inventory master extensions."""

    limit: int | None = None
    offset: int | None = None


class InvMastExt(CamelCaseModel, extra="allow"):
    """Inventory master extension entity (passthrough for API flexibility)."""

    inv_mast_ext_uid: int | None = None
    inv_mast_uid: int | None = None


class InvMastExtCreateParams(BaseModel, extra="allow"):
    """Parameters for creating an inventory master extension (passthrough)."""

    inv_mast_uid: int


class InvMastExtUpdateParams(BaseModel, extra="allow"):
    """Parameters for updating an inventory master extension (passthrough)."""


# AI Suggestions
class AISuggestionParams(EdgeCacheParams):
    """Parameters for AI suggestion endpoints."""

    limit: int | None = None
    model: str | None = None


class SuggestDisplayDescResponse(CamelCaseModel, extra="allow"):
    """Response for suggest display description endpoint (passthrough)."""


class SuggestWebDescResponse(CamelCaseModel, extra="allow"):
    """Response for suggest web description endpoint (passthrough)."""
