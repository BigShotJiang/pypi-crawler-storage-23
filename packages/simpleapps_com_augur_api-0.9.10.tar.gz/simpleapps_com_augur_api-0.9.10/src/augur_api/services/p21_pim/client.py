"""P21 PIM service client for product information management."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from augur_api.core.http_client import HTTPClient
from augur_api.core.schemas import BaseResponse, EdgeCacheParams
from augur_api.services.base import BaseServiceClient
from augur_api.services.p21_pim.schemas import (
    AISuggestionParams,
    InvMastExt,
    InvMastExtListParams,
    Item,
    ItemListParams,
    Podcast,
    PodcastListParams,
    SuggestDisplayDescResponse,
    SuggestWebDescResponse,
)
from augur_api.services.resource import BaseResource


class SuggestDisplayDescResource(BaseResource):
    """Resource for /items/{invMastUid}/suggest-display-desc endpoints."""

    def __init__(self, http: HTTPClient, inv_mast_uid: int) -> None:
        """Initialize the resource."""
        super().__init__(http, f"/items/{inv_mast_uid}/suggest-display-desc")

    def get(
        self, params: AISuggestionParams | None = None
    ) -> BaseResponse[SuggestDisplayDescResponse]:
        """Generate AI display description suggestions.

        Args:
            params: Optional parameters including limit and model selection.

        Returns:
            BaseResponse containing display description suggestions.
        """
        response = self._get(params=params)
        return BaseResponse[SuggestDisplayDescResponse].model_validate(response)


class SuggestWebDescResource(BaseResource):
    """Resource for /items/{invMastUid}/suggest-web-desc endpoints."""

    def __init__(self, http: HTTPClient, inv_mast_uid: int) -> None:
        """Initialize the resource."""
        super().__init__(http, f"/items/{inv_mast_uid}/suggest-web-desc")

    def get(self, params: AISuggestionParams | None = None) -> BaseResponse[SuggestWebDescResponse]:
        """Generate AI web description suggestions.

        Args:
            params: Optional parameters including limit and model selection.

        Returns:
            BaseResponse containing web description suggestions.
        """
        response = self._get(params=params)
        return BaseResponse[SuggestWebDescResponse].model_validate(response)


class ItemsResource(BaseResource):
    """Resource for /items endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/items")

    def list(self, params: ItemListParams | None = None) -> BaseResponse[list[Item]]:
        """List items.

        Args:
            params: Optional query parameters for filtering and pagination.

        Returns:
            BaseResponse containing a list of Item items.
        """
        response = self._get(params=params)
        return BaseResponse[list[Item]].model_validate(response)

    def get(self, inv_mast_uid: int, options: EdgeCacheParams | None = None) -> BaseResponse[Item]:
        """Get item by UID.

        Args:
            inv_mast_uid: The inventory master UID.
            options: Optional edge cache parameters.

        Returns:
            BaseResponse containing the Item.
        """
        response = self._get(f"/{inv_mast_uid}", params=options)
        return BaseResponse[Item].model_validate(response)

    def update(self, inv_mast_uid: int, data: Any) -> BaseResponse[Item]:
        """Update an item.

        Args:
            inv_mast_uid: The inventory master UID.
            data: The item data to update.

        Returns:
            BaseResponse containing the updated Item.
        """
        response = self._put(f"/{inv_mast_uid}", data=data)
        return BaseResponse[Item].model_validate(response)

    def suggest_display_desc(self, inv_mast_uid: int) -> SuggestDisplayDescResource:
        """Access suggest display description endpoint for an item.

        Args:
            inv_mast_uid: The inventory master UID.

        Returns:
            SuggestDisplayDescResource for the item.
        """
        return SuggestDisplayDescResource(self._http, inv_mast_uid)

    def suggest_web_desc(self, inv_mast_uid: int) -> SuggestWebDescResource:
        """Access suggest web description endpoint for an item.

        Args:
            inv_mast_uid: The inventory master UID.

        Returns:
            SuggestWebDescResource for the item.
        """
        return SuggestWebDescResource(self._http, inv_mast_uid)


class PodcastsResource(BaseResource):
    """Resource for /podcasts endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/podcasts")

    def list(self, params: PodcastListParams | None = None) -> BaseResponse[list[Podcast]]:
        """List podcasts.

        Args:
            params: Optional query parameters for filtering and pagination.

        Returns:
            BaseResponse containing a list of Podcast items.
        """
        response = self._get(params=params)
        return BaseResponse[list[Podcast]].model_validate(response)

    def get(self, podcast_uid: int, options: EdgeCacheParams | None = None) -> BaseResponse[Podcast]:
        """Get podcast by UID.

        Args:
            podcast_uid: The podcast UID.
            options: Optional edge cache parameters.

        Returns:
            BaseResponse containing the Podcast.
        """
        response = self._get(f"/{podcast_uid}", params=options)
        return BaseResponse[Podcast].model_validate(response)

    def create(self, data: Any) -> BaseResponse[Podcast]:
        """Create a new podcast.

        Args:
            data: The podcast data to create.

        Returns:
            BaseResponse containing the created Podcast.
        """
        response = self._post(data=data)
        return BaseResponse[Podcast].model_validate(response)

    def update(self, podcast_uid: int, data: Any) -> BaseResponse[Podcast]:
        """Update a podcast.

        Args:
            podcast_uid: The podcast UID.
            data: The podcast data to update.

        Returns:
            BaseResponse containing the updated Podcast.
        """
        response = self._put(f"/{podcast_uid}", data=data)
        return BaseResponse[Podcast].model_validate(response)

    def delete(self, podcast_uid: int) -> BaseResponse[Podcast]:
        """Delete a podcast.

        Args:
            podcast_uid: The podcast UID.

        Returns:
            BaseResponse containing the deleted Podcast confirmation.
        """
        response = self._delete(f"/{podcast_uid}")
        return BaseResponse[Podcast].model_validate(response)


class InvMastExtResource(BaseResource):
    """Resource for /inv-mast-ext endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/inv-mast-ext")

    def list(self, params: InvMastExtListParams | None = None) -> BaseResponse[list[InvMastExt]]:
        """List inventory master extensions.

        Args:
            params: Optional query parameters for filtering and pagination.

        Returns:
            BaseResponse containing a list of InvMastExt items.
        """
        response = self._get(params=params)
        return BaseResponse[list[InvMastExt]].model_validate(response)

    def get(self, inv_mast_ext_uid: int, options: EdgeCacheParams | None = None) -> BaseResponse[InvMastExt]:
        """Get inventory master extension by UID.

        Args:
            inv_mast_ext_uid: The inventory master extension UID.
            options: Optional edge cache parameters.

        Returns:
            BaseResponse containing the InvMastExt.
        """
        response = self._get(f"/{inv_mast_ext_uid}", params=options)
        return BaseResponse[InvMastExt].model_validate(response)

    def create(self, data: Any) -> BaseResponse[InvMastExt]:
        """Create a new inventory master extension.

        Args:
            data: The inventory master extension data to create.

        Returns:
            BaseResponse containing the created InvMastExt.
        """
        response = self._post(data=data)
        return BaseResponse[InvMastExt].model_validate(response)

    def update(self, inv_mast_ext_uid: int, data: Any) -> BaseResponse[InvMastExt]:
        """Update an inventory master extension.

        Args:
            inv_mast_ext_uid: The inventory master extension UID.
            data: The inventory master extension data to update.

        Returns:
            BaseResponse containing the updated InvMastExt.
        """
        response = self._put(f"/{inv_mast_ext_uid}", data=data)
        return BaseResponse[InvMastExt].model_validate(response)

    def delete(self, inv_mast_ext_uid: int) -> BaseResponse[InvMastExt]:
        """Delete an inventory master extension.

        Args:
            inv_mast_ext_uid: The inventory master extension UID.

        Returns:
            BaseResponse containing the deleted InvMastExt confirmation.
        """
        response = self._delete(f"/{inv_mast_ext_uid}")
        return BaseResponse[InvMastExt].model_validate(response)


class P21PimClient(BaseServiceClient):
    """Client for the P21 PIM service.

    Provides access to product information management endpoints including:
    - Health check (health_check)
    - Items (items) with AI suggestions
    - Podcasts (podcasts)
    - Inventory Master Extensions (inv_mast_ext)

    Example:
        >>> from augur_api import AugurAPI
        >>> api = AugurAPI(token="...", site_id="...")
        >>> items = api.p21_pim.items.list()
        >>> for item in items.data:
        ...     print(item.item_desc)
    """

    def __init__(self, http_client: HTTPClient) -> None:
        """Initialize the P21 PIM client.

        Args:
            http_client: HTTP client for making requests.
        """
        super().__init__(http_client)
        self._items: ItemsResource | None = None
        self._podcasts: PodcastsResource | None = None
        self._inv_mast_ext: InvMastExtResource | None = None

    @property
    def items(self) -> ItemsResource:
        """Access items endpoints."""
        if self._items is None:
            self._items = ItemsResource(self._http)
        return self._items

    @property
    def podcasts(self) -> PodcastsResource:
        """Access podcasts endpoints."""
        if self._podcasts is None:
            self._podcasts = PodcastsResource(self._http)
        return self._podcasts

    @property
    def inv_mast_ext(self) -> InvMastExtResource:
        """Access inventory master extension endpoints."""
        if self._inv_mast_ext is None:
            self._inv_mast_ext = InvMastExtResource(self._http)
        return self._inv_mast_ext
