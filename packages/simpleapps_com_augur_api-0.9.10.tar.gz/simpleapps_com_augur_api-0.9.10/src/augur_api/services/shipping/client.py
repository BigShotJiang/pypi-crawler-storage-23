"""Shipping service client for shipping rate calculations."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from augur_api.core.http_client import HTTPClient
from augur_api.core.schemas import BaseResponse
from augur_api.services.base import BaseServiceClient
from augur_api.services.resource import BaseResource
from augur_api.services.shipping.schemas import (
    RateQuote,
)


class RatesResource(BaseResource):
    """Resource for /rates endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/rates")

    def create(self, data: Any) -> BaseResponse[list[RateQuote]]:
        """Calculate shipping rates.

        Args:
            data: Rate calculation parameters.

        Returns:
            BaseResponse containing a list of RateQuote items.
        """
        response = self._post(data=data)
        return BaseResponse[list[RateQuote]].model_validate(response)


class ShippingClient(BaseServiceClient):
    """Client for the Shipping service.

    Provides access to shipping rate calculation endpoints including:
    - Health check (health_check)
    - Rate quotes (rates)

    Example:
        >>> from augur_api import AugurAPI
        >>> api = AugurAPI(token="...", site_id="...")
        >>> rates = api.shipping.rates.create(
        ...     RatesParams(origin_zip="90210", destination_zip="10001", weight=5.0)
        ... )
        >>> for rate in rates.data:
        ...     print(f"{rate.carrier}: ${rate.rate}")
    """

    def __init__(self, http_client: HTTPClient) -> None:
        """Initialize the Shipping client.

        Args:
            http_client: HTTP client for making requests.
        """
        super().__init__(http_client)
        self._rates: RatesResource | None = None

    @property
    def rates(self) -> RatesResource:
        """Access rates endpoints."""
        if self._rates is None:
            self._rates = RatesResource(self._http)
        return self._rates
