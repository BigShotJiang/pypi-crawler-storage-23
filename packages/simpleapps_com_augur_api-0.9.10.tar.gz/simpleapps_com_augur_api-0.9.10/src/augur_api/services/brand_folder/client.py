"""Brand Folder service client for digital asset management."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from augur_api.core.http_client import HTTPClient
from augur_api.core.schemas import BaseResponse, EdgeCacheParams
from augur_api.services.base import BaseServiceClient
from augur_api.services.brand_folder.schemas import (
    Asset,
    AssetListParams,
    Category,
    CategoryFocusResult,
    CategoryListParams,
    Collection,
    CollectionListParams,
)
from augur_api.services.resource import BaseResource


class AssetsResource(BaseResource):
    """Resource for /assets endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/assets")

    def list(self, params: AssetListParams | None = None) -> BaseResponse[list[Asset]]:
        """List assets.

        Args:
            params: Optional query parameters for filtering and pagination.

        Returns:
            BaseResponse containing a list of Asset items.
        """
        response = self._get(params=params)
        return BaseResponse[list[Asset]].model_validate(response)

    def get(self, assets_uid: int, options: EdgeCacheParams | None = None) -> BaseResponse[Asset]:
        """Get asset by UID.

        Args:
            assets_uid: The asset UID.
            options: Optional edge cache parameters.

        Returns:
            BaseResponse containing the Asset.
        """
        response = self._get(f"/{assets_uid}", params=options)
        return BaseResponse[Asset].model_validate(response)

    def create(self, data: Any) -> BaseResponse[Asset]:
        """Create a new asset.

        Args:
            data: The asset data to create.

        Returns:
            BaseResponse containing the created Asset.
        """
        response = self._post(data=data)
        return BaseResponse[Asset].model_validate(response)


class CategoriesFocusResource(BaseResource):
    """Resource for /categories/focus endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/categories/focus")

    def create(self, data: Any) -> BaseResponse[CategoryFocusResult]:
        """Set category focus configuration.

        Args:
            data: Category focus configuration parameters.

        Returns:
            BaseResponse containing the CategoryFocusResult.
        """
        response = self._post(data=data)
        return BaseResponse[CategoryFocusResult].model_validate(response)


class CategoriesResource(BaseResource):
    """Resource for /categories endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/categories")
        self._focus: CategoriesFocusResource | None = None

    @property
    def focus(self) -> CategoriesFocusResource:
        """Access category focus endpoints."""
        if self._focus is None:
            self._focus = CategoriesFocusResource(self._http)
        return self._focus

    def list(self, params: CategoryListParams | None = None) -> BaseResponse[list[Category]]:
        """List categories.

        Args:
            params: Optional query parameters for filtering and pagination.

        Returns:
            BaseResponse containing a list of Category items.
        """
        response = self._get(params=params)
        return BaseResponse[list[Category]].model_validate(response)

    def get(self, categories_uid: int, options: EdgeCacheParams | None = None) -> BaseResponse[Category]:
        """Get category by UID.

        Args:
            categories_uid: The category UID.
            options: Optional edge cache parameters.

        Returns:
            BaseResponse containing the Category.
        """
        response = self._get(f"/{categories_uid}", params=options)
        return BaseResponse[Category].model_validate(response)


class CollectionsResource(BaseResource):
    """Resource for /collections endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/collections")

    def list(self, params: CollectionListParams | None = None) -> BaseResponse[list[Collection]]:
        """List collections.

        Args:
            params: Optional query parameters for filtering and pagination.

        Returns:
            BaseResponse containing a list of Collection items.
        """
        response = self._get(params=params)
        return BaseResponse[list[Collection]].model_validate(response)

    def get(self, collections_uid: int, options: EdgeCacheParams | None = None) -> BaseResponse[Collection]:
        """Get collection by UID.

        Args:
            collections_uid: The collection UID.
            options: Optional edge cache parameters.

        Returns:
            BaseResponse containing the Collection.
        """
        response = self._get(f"/{collections_uid}", params=options)
        return BaseResponse[Collection].model_validate(response)


class BrandFolderClient(BaseServiceClient):
    """Client for the Brand Folder service.

    Provides access to digital asset management endpoints including:
    - Health check (health_check)
    - Assets (assets)
    - Categories (categories)
    - Collections (collections)

    Example:
        >>> from augur_api import AugurAPI
        >>> api = AugurAPI(token="...", site_id="...")
        >>> assets = api.brand_folder.assets.list()
        >>> for asset in assets.data:
        ...     print(asset.name)
    """

    def __init__(self, http_client: HTTPClient) -> None:
        """Initialize the Brand Folder client.

        Args:
            http_client: HTTP client for making requests.
        """
        super().__init__(http_client)
        self._assets: AssetsResource | None = None
        self._categories: CategoriesResource | None = None
        self._collections: CollectionsResource | None = None

    @property
    def assets(self) -> AssetsResource:
        """Access assets endpoints."""
        if self._assets is None:
            self._assets = AssetsResource(self._http)
        return self._assets

    @property
    def categories(self) -> CategoriesResource:
        """Access categories endpoints."""
        if self._categories is None:
            self._categories = CategoriesResource(self._http)
        return self._categories

    @property
    def collections(self) -> CollectionsResource:
        """Access collections endpoints."""
        if self._collections is None:
            self._collections = CollectionsResource(self._http)
        return self._collections
