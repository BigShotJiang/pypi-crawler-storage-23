"""Schemas for the Brand Folder service."""

from pydantic import BaseModel

from augur_api.core.schemas import CamelCaseModel, EdgeCacheParams


# Health Check
class HealthCheckData(CamelCaseModel):
    """Health check response data."""

    site_hash: str | None = None
    site_id: str | None = None


# Assets
class AssetListParams(EdgeCacheParams):
    """Parameters for listing assets."""

    limit: int | None = None
    offset: int | None = None
    section_id: str | None = None
    collection_id: str | None = None


class Asset(CamelCaseModel):
    """Brand folder asset entity."""

    assets_uid: int | None = None
    bf_asset_id: str | None = None
    name: str | None = None
    description: str | None = None
    file_type: str | None = None
    file_size: int | None = None
    cdn_url: str | None = None
    thumbnail_url: str | None = None
    section_id: str | None = None
    created_at: str | None = None
    updated_at: str | None = None


class AssetCreateParams(BaseModel):
    """Parameters for creating an asset."""

    name: str
    section_id: str
    description: str | None = None


# Categories
class CategoryListParams(EdgeCacheParams):
    """Parameters for listing categories."""

    limit: int | None = None
    offset: int | None = None


class Category(CamelCaseModel):
    """Brand folder category entity."""

    categories_uid: int | None = None
    bf_category_id: str | None = None
    name: str | None = None
    slug: str | None = None
    parent_id: str | None = None
    created_at: str | None = None
    updated_at: str | None = None


class CategoryFocusParams(BaseModel):
    """Parameters for setting category focus configuration."""

    # Category identification
    category_id: str | None = None
    category_name: str | None = None
    category_slug: str | None = None
    # Focus configuration
    focus_level: str | None = None  # 'primary', 'secondary', 'tertiary'
    priority: int | None = None  # 1-100
    is_active: bool | None = None
    # Brand association
    brand_id: str | None = None
    brand_name: str | None = None
    # Metadata
    description: str | None = None
    tags: list[str] | None = None
    start_date: str | None = None
    end_date: str | None = None
    # Configuration options
    display_order: int | None = None
    visibility: str | None = None  # 'public', 'private', 'draft'
    featured: bool | None = None


class CategoryFocusResult(CamelCaseModel):
    """Result of category focus configuration."""

    category_id: str | None = None
    category_name: str | None = None
    category_slug: str | None = None
    focus_level: str | None = None
    priority: int | None = None
    is_active: bool | None = None
    brand_id: str | None = None
    brand_name: str | None = None
    display_order: int | None = None
    visibility: str | None = None
    featured: bool | None = None
    created_at: str | None = None
    updated_at: str | None = None
    effective_date: str | None = None
    expiration_date: str | None = None


# Collections
class CollectionListParams(EdgeCacheParams):
    """Parameters for listing collections."""

    limit: int | None = None
    offset: int | None = None


class Collection(CamelCaseModel):
    """Brand folder collection entity."""

    collections_uid: int | None = None
    bf_collection_id: str | None = None
    name: str | None = None
    description: str | None = None
    slug: str | None = None
    public: bool | None = None
    created_at: str | None = None
    updated_at: str | None = None
