"""Open Search service client for search operations."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    import builtins

    from augur_api.core.http_client import HTTPClient

from augur_api.core.schemas import BaseResponse, EdgeCacheParams
from augur_api.services.base import BaseServiceClient
from augur_api.services.open_search.schemas import (
    ItemDocument,
    ItemRefreshResponse,
    ItemSearchAttributesData,
    ItemSearchAttributesParams,
    ItemSearchData,
    ItemSearchParams,
    ItemsListParams,
    QueryString,
    QueryStringListParams,
    Suggestion,
    SuggestionListParams,
    SuggestionParams,
)
from augur_api.services.resource import BaseResource


class ItemSearchAttributesResource(BaseResource):
    """Resource for /item-search/attributes endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/item-search/attributes")

    def list(
        self, params: ItemSearchAttributesParams | None = None
    ) -> BaseResponse[ItemSearchAttributesData]:
        """List attributes from item search.

        Args:
            params: Optional parameters for filtering attributes.

        Returns:
            BaseResponse containing ItemSearchAttributesData with attributes list.
        """
        response = self._get(params=params)
        return BaseResponse[ItemSearchAttributesData].model_validate(response)


class ItemSearchResource(BaseResource):
    """Resource for /item-search endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/item-search")
        self._attributes: ItemSearchAttributesResource | None = None

    @property
    def attributes(self) -> ItemSearchAttributesResource:
        """Access item search attributes endpoints."""
        if self._attributes is None:
            self._attributes = ItemSearchAttributesResource(self._http)
        return self._attributes

    def list(self, params: ItemSearchParams) -> BaseResponse[ItemSearchData]:
        """List items matching search criteria.

        Args:
            params: Search parameters including query string.

        Returns:
            BaseResponse containing ItemSearchData with items and metadata.
        """
        response = self._get(params=params)
        return BaseResponse[ItemSearchData].model_validate(response)


class ItemsResource(BaseResource):
    """Resource for /items endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/items")

    def list(self, params: ItemsListParams | None = None) -> BaseResponse[list[ItemDocument]]:
        """List items.

        Args:
            params: Optional parameters for pagination.

        Returns:
            BaseResponse containing a list of ItemDocument items.
        """
        response = self._get(params=params)
        return BaseResponse[list[ItemDocument]].model_validate(response)

    def get(self, inv_mast_uid: int, options: EdgeCacheParams | None = None) -> BaseResponse[ItemDocument]:
        """Get item document by inventory master UID.

        Args:
            inv_mast_uid: The inventory master UID.
            options: Optional edge cache parameters.

        Returns:
            BaseResponse containing the item document.
        """
        response = self._get(f"/{inv_mast_uid}", params=options)
        return BaseResponse[ItemDocument].model_validate(response)

    def update(self, inv_mast_uid: int, data: Any) -> BaseResponse[ItemDocument]:
        """Update item document.

        Args:
            inv_mast_uid: The inventory master UID.
            data: Item data to update.

        Returns:
            BaseResponse containing the updated item document.
        """
        response = self._put(f"/{inv_mast_uid}", data=data)
        return BaseResponse[ItemDocument].model_validate(response)

    def refresh_all(self) -> BaseResponse[ItemRefreshResponse]:
        """Refresh all items.

        Returns:
            BaseResponse containing the refresh result.
        """
        response = self._put("/refresh")
        return BaseResponse[ItemRefreshResponse].model_validate(response)

    def refresh(self, inv_mast_uid: int, options: EdgeCacheParams | None = None) -> BaseResponse[ItemRefreshResponse]:
        """Refresh a specific item document.

        Args:
            inv_mast_uid: The inventory master UID.
            options: Optional edge cache parameters.

        Returns:
            BaseResponse containing the refresh result.
        """
        response = self._get(f"/{inv_mast_uid}/refresh", params=options)
        return BaseResponse[ItemRefreshResponse].model_validate(response)


class SuggestionsResource(BaseResource):
    """Resource for /suggestions endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/suggestions")

    def list(self, params: SuggestionListParams | None = None) -> BaseResponse[list[Suggestion]]:
        """List suggestions.

        Args:
            params: Optional parameters for pagination.

        Returns:
            BaseResponse containing a list of Suggestion items.
        """
        response = self._get(params=params)
        return BaseResponse[list[Suggestion]].model_validate(response)

    def get(self, suggestions_uid: int, options: EdgeCacheParams | None = None) -> BaseResponse[Suggestion]:
        """Get suggestion details by UID.

        Args:
            suggestions_uid: The suggestions UID.
            options: Optional edge cache parameters.

        Returns:
            BaseResponse containing the Suggestion.
        """
        response = self._get(f"/{suggestions_uid}", params=options)
        return BaseResponse[Suggestion].model_validate(response)

    def suggest(self, params: SuggestionParams) -> BaseResponse[builtins.list[Suggestion]]:
        """Get search suggestions for autocomplete.

        Args:
            params: Suggestion parameters including query string.

        Returns:
            BaseResponse containing a list of Suggestion items.
        """
        response = self._get("/suggest", params=params)
        return BaseResponse[list[Suggestion]].model_validate(response)


class QueryStringResource(BaseResource):
    """Resource for /query-string endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/query-string")

    def list(self, params: QueryStringListParams | None = None) -> BaseResponse[list[QueryString]]:
        """List query strings (search analytics).

        Args:
            params: Optional query parameters for filtering and pagination.

        Returns:
            BaseResponse containing a list of QueryString items.
        """
        response = self._get(params=params)
        return BaseResponse[list[QueryString]].model_validate(response)

    def get(self, query_string_uid: int, options: EdgeCacheParams | None = None) -> BaseResponse[QueryString]:
        """Get query string analytics by UID.

        Args:
            query_string_uid: The query string UID.
            options: Optional edge cache parameters.

        Returns:
            BaseResponse containing the QueryString.
        """
        response = self._get(f"/{query_string_uid}", params=options)
        return BaseResponse[QueryString].model_validate(response)


class OpenSearchClient(BaseServiceClient):
    """Client for the Open Search service.

    Provides access to search operation endpoints including:
    - Health check (health_check) - inherited from BaseServiceClient
    - Item search (item_search)
    - Items (items)
    - Search suggestions (suggestions)
    - Query string analytics (query_string)

    Example:
        >>> from augur_api import AugurAPI
        >>> api = AugurAPI(token="...", site_id="...")
        >>> results = api.open_search.item_search.list(
        ...     ItemSearchParams(q="widget")
        ... )
        >>> for item in results.data:
        ...     print(item.item_desc)
        >>> # Get search attributes
        >>> attrs = api.open_search.item_search.attributes.list(
        ...     ItemSearchAttributesParams(q="widget")
        ... )
    """

    def __init__(self, http_client: HTTPClient) -> None:
        """Initialize the Open Search client.

        Args:
            http_client: HTTP client for making requests.
        """
        super().__init__(http_client)
        self._item_search: ItemSearchResource | None = None
        self._items: ItemsResource | None = None
        self._suggestions: SuggestionsResource | None = None
        self._query_string: QueryStringResource | None = None

    @property
    def item_search(self) -> ItemSearchResource:
        """Access item search endpoints."""
        if self._item_search is None:
            self._item_search = ItemSearchResource(self._http)
        return self._item_search

    @property
    def items(self) -> ItemsResource:
        """Access items endpoints."""
        if self._items is None:
            self._items = ItemsResource(self._http)
        return self._items

    @property
    def suggestions(self) -> SuggestionsResource:
        """Access suggestions endpoints."""
        if self._suggestions is None:
            self._suggestions = SuggestionsResource(self._http)
        return self._suggestions

    @property
    def query_string(self) -> QueryStringResource:
        """Access query string analytics endpoints."""
        if self._query_string is None:
            self._query_string = QueryStringResource(self._http)
        return self._query_string
