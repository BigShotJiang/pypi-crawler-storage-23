"""Gregorovich service exports."""

from augur_api.services.gregorovich.client import (
    ChatGptAskResource,
    ChatGptResource,
    DocumentsResource,
    GregorovichClient,
    OllamaGenerateResource,
    OllamaResource,
)
from augur_api.services.gregorovich.schemas import (
    ChatGptAskParams,
    ChatGptAskResult,
    DocumentsResult,
    OllamaGenerateParams,
    OllamaGenerateResult,
)

__all__ = [
    "ChatGptAskParams",
    "ChatGptAskResource",
    "ChatGptAskResult",
    "ChatGptResource",
    "DocumentsResource",
    "DocumentsResult",
    "GregorovichClient",
    "OllamaGenerateParams",
    "OllamaGenerateResource",
    "OllamaGenerateResult",
    "OllamaResource",
]
