"""UPS service exports."""

from augur_api.services.ups.client import (
    RatesShopResource,
    UpsClient,
)
from augur_api.services.ups.schemas import (
    RatesShopData,
    RatesShopParams,
)

__all__ = [
    "RatesShopData",
    "RatesShopParams",
    "RatesShopResource",
    "UpsClient",
]
