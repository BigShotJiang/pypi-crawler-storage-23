"""UPS service client for UPS integration."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from augur_api.core.http_client import HTTPClient
from augur_api.core.schemas import BaseResponse
from augur_api.services.base import BaseServiceClient
from augur_api.services.resource import BaseResource
from augur_api.services.ups.schemas import (
    RatesShopItem,
    RatesShopParams,
)


class RatesShopResource(BaseResource):
    """Resource for /rates-shop endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/rates-shop")

    def get(self, params: RatesShopParams | None = None) -> BaseResponse[list[RatesShopItem]]:
        """Shop UPS shipping rates.

        Args:
            params: Rate shopping parameters.

        Returns:
            BaseResponse containing list of UPS rate items.
        """
        response = self._get(params=params)
        return BaseResponse[list[RatesShopItem]].model_validate(response)


class UpsClient(BaseServiceClient):
    """Client for the UPS service.

    Provides access to UPS shipping rate shopping endpoints including:
    - Health check (health_check)
    - Rate shopping (rates_shop)

    Example:
        >>> from augur_api import AugurAPI
        >>> api = AugurAPI(token="...", site_id="...")
        >>> rates = api.ups.rates_shop.get(
        ...     RatesShopParams(
        ...         from_postal_code="90210",
        ...         to_postal_code="10001",
        ...         weight=5
        ...     )
        ... )
        >>> print(rates.data)
    """

    def __init__(self, http_client: HTTPClient) -> None:
        """Initialize the UPS client.

        Args:
            http_client: HTTP client for making requests.
        """
        super().__init__(http_client)
        self._rates_shop: RatesShopResource | None = None

    @property
    def rates_shop(self) -> RatesShopResource:
        """Access rates shop endpoints."""
        if self._rates_shop is None:
            self._rates_shop = RatesShopResource(self._http)
        return self._rates_shop
