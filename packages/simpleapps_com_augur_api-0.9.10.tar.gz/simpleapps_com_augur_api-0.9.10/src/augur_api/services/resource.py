"""Base resource class for API endpoints.

Provides helper methods to eliminate boilerplate when implementing service resources.
"""

from typing import Any

from pydantic import BaseModel

from augur_api.core.http_client import HTTPClient


class BaseResource:
    """Base class for all API resources.

    Provides common functionality for making HTTP requests and
    converting parameters to query strings.

    Subclasses define their specific endpoints with proper typing.

    Attributes:
        _http: HTTP client for making requests.
        _path: Base path for this resource (e.g., "/inv-mast").

    Example:
        >>> class InvMastResource(BaseResource):
        ...     def __init__(self, http: HTTPClient) -> None:
        ...         super().__init__(http, "/inv-mast")
        ...
        ...     def list(self, params=None) -> BaseResponse[list[InvMast]]:
        ...         response = self._get(params=params)
        ...         return BaseResponse[list[InvMast]].model_validate(response)
        ...
        ...     def get(self, uid: int) -> BaseResponse[InvMast]:
        ...         response = self._get(f"/{uid}")
        ...         return BaseResponse[InvMast].model_validate(response)
    """

    def __init__(self, http: HTTPClient, path: str) -> None:
        """Initialize the resource.

        Args:
            http: HTTP client for making requests.
            path: Base path for this resource (e.g., "/inv-mast").
        """
        self._http = http
        self._path = path

    def _to_params(self, params: BaseModel | dict[str, Any] | None) -> dict[str, Any] | None:
        """Convert params to query dict.

        Excludes None values for cleaner query strings.

        Args:
            params: Optional Pydantic model or dict with query parameters.

        Returns:
            Dictionary of non-None parameters, or None if no params.
        """
        if params is None:
            return None
        if isinstance(params, dict):
            # Filter out None values from dict
            result = {k: v for k, v in params.items() if v is not None}
            return result if result else None
        result = params.model_dump(exclude_none=True, by_alias=True)
        return result if result else None

    def _get(
        self,
        path: str | None = None,
        params: BaseModel | dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Make a GET request.

        Args:
            path: Path suffix (appended to base path), or None for base path.
            params: Optional query parameters (Pydantic model or dict).

        Returns:
            Raw response dictionary.
        """
        full_path = f"{self._path}{path}" if path else self._path
        return self._http.get(full_path, params=self._to_params(params))

    def _post(
        self,
        path: str | None = None,
        data: BaseModel | dict[str, Any] | list[Any] | None = None,
        params: BaseModel | None = None,
    ) -> dict[str, Any]:
        """Make a POST request.

        Args:
            path: Path suffix (appended to base path), or None for base path.
            data: Request body data (object, list, or None).
            params: Optional query parameters.

        Returns:
            Raw response dictionary.
        """
        full_path = f"{self._path}{path}" if path else self._path
        body: dict[str, Any] | list[Any] | None
        if isinstance(data, list):
            body = data
        elif isinstance(data, BaseModel):
            body = data.model_dump(exclude_none=True, by_alias=True)
        else:
            body = data
        return self._http.post(full_path, data=body, params=self._to_params(params))

    def _put(
        self,
        path: str,
        data: BaseModel | dict[str, Any] | None = None,
        params: BaseModel | None = None,
    ) -> dict[str, Any]:
        """Make a PUT request.

        Args:
            path: Path suffix (appended to base path).
            data: Request body data.
            params: Optional query parameters.

        Returns:
            Raw response dictionary.
        """
        full_path = f"{self._path}{path}"
        body = data.model_dump(exclude_none=True, by_alias=True) if isinstance(data, BaseModel) else data
        return self._http.put(full_path, data=body, params=self._to_params(params))

    def _delete(
        self,
        path: str,
        params: BaseModel | None = None,
    ) -> dict[str, Any]:
        """Make a DELETE request.

        Args:
            path: Path suffix (appended to base path).
            params: Optional query parameters.

        Returns:
            Raw response dictionary.
        """
        full_path = f"{self._path}{path}"
        return self._http.delete(full_path, params=self._to_params(params))
