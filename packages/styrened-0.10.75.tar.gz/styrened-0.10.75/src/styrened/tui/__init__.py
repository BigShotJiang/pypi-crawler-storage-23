"""Styrene TUI - Terminal UI for Reticulum mesh network management."""
