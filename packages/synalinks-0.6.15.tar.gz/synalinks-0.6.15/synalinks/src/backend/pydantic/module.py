# License Apache 2.0: (c) 2025 Yoan Sallami (Synalinks Team)


class PydanticModule:
    pass
