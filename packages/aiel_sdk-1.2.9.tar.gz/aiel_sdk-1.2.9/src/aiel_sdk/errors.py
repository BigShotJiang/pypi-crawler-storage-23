from __future__ import annotations

class AielError(Exception):
    """Base class for AIEL SDK errors."""

class ContractViolation(AielError):
    """User export does not follow required contract/signature."""

class RuntimeDependencyError(AielError):
    """Raised when an optional integration is not installed."""
    def __init__(self, dep: str, hint: str | None = None):
        msg = f"Optional dependency '{dep}' is not installed."
        if hint:
            msg += f" {hint}"
        super().__init__(msg)
