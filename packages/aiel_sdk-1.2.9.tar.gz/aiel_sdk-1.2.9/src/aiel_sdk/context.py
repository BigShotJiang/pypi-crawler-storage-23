from __future__ import annotations
from dataclasses import dataclass
from typing import Any, Mapping

@dataclass
class Context:
    tenant_id: str | None = None
    workspace_id: str | None = None
    project_id: str | None = None
    request_id: str | None = None
    _secrets: Mapping[str, str] | None = None

    def log(self, event: str, **fields: Any) -> None:
        # structured log placeholder; keep stable API
        print({"event": event, **fields})

    @property
    def secrets(self) -> Mapping[str, str]:
        return self._secrets or {}
