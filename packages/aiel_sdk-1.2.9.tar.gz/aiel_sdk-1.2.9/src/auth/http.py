import httpx
from src.auth.providers import ProviderChain, default_chain

class HttpClient:
    def __init__(self, base_url: str, chain: ProviderChain | None = None):
        self.base_url = base_url.rstrip("/")
        self.chain = chain or default_chain()
        self.client = httpx.Client(timeout=30.0)

    def _auth_headers(self) -> dict[str, str]:
        tok = self.chain.resolve().token
        return {"Authorization": f"Bearer {tok}"}

    def get(self, path: str):
        return self.client.get(f"{self.base_url}{path}", headers=self._auth_headers())

    def post(self, path: str, json: dict):
        return self.client.post(f"{self.base_url}{path}", headers=self._auth_headers(), json=json)
