from __future__ import annotations
from aiel_sdk.errors import RuntimeDependencyError

try:
    from pydantic import BaseModel, Field, EmailStr
except Exception as e:  # pragma: no cover
    raise RuntimeDependencyError("pydantic", "Install aiel-sdk (includes pydantic) or add pydantic to runtime.") from e

__all__ = ["BaseModel", "Field","EmailStr"]
