"""AIEL CLI context facade namespace."""

__all__ = ["user_context"]
