"""AIEL CLI facade namespace."""

__all__ = ["user_context"]
