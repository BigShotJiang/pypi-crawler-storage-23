import argparse
import importlib
import json
import os
import sys
import time
from pathlib import Path
from typing import Annotated

import numpy as np
import pandas as pd
from pydantic import BaseModel, ConfigDict, Field, ValidationError

import sensor_routing.benefit_calculation as benefit_calculation_module
import sensor_routing.econ_benefit as econ_benefit_module
import sensor_routing.econ_mapping as econ_mapping_module
import sensor_routing.econ_paths as econ_paths_module
import sensor_routing.econ_route as econ_route_module
import sensor_routing.hull_points_extraction as hull_points_extraction_module
import sensor_routing.path_finding as path_finding_module
import sensor_routing.point_mapping as point_mapping_module
import sensor_routing.route_finding as route_finding_module
from sensor_routing.benefit_calculation import benefit_calculation
from sensor_routing.econ_benefit import benefit_calculation as econ_benefit_calculation
from sensor_routing.econ_mapping import point_mapping as econ_point_mapping
from sensor_routing.econ_paths import path_finding as econ_path_finding
from sensor_routing.econ_route import route_finding as econ_route_finding
from sensor_routing.hull_points_extraction import hpe_optimization
from sensor_routing.path_finding import path_finding
from sensor_routing.point_mapping import point_mapping
from sensor_routing.route_finding import route_finding

# =============================================================================
# GLOBAL DEBUG CONFIGURATION
# =============================================================================
# Set ENABLE_MODULE_DEBUG = True to enable debug prints in all modules
# You can still control individual modules by setting their DEBUG flags in their files
ENABLE_MODULE_DEBUG = False  # <-- MASTER DEBUG SWITCH FOR ALL MODULES

# Import modules first (as modules, not functions)

# Apply global debug setting to all modules
if ENABLE_MODULE_DEBUG:
    point_mapping_module.DEBUG = True
    benefit_calculation_module.DEBUG = True
    path_finding_module.DEBUG = True
    route_finding_module.DEBUG = True
    hull_points_extraction_module.DEBUG = True
    econ_mapping_module.DEBUG = True
    econ_benefit_module.DEBUG = True
    econ_paths_module.DEBUG = True
    econ_route_module.DEBUG = True

# Now import the functions from the modules

# Import modules with numeric prefixes using importlib

# Add current directory to path for relative imports
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))


# =============================================================================
# INPUT FILE CONSTANTS AND DESCRIPTIONS
# =============================================================================

# Expected filenames
from sensor_routing.constants import (  # noqa: E402
    MEMBERSHIP_FILENAME,
    OSM_FILENAME,
    PARAMETERS_FILENAME,
    PREDICTOR_FILENAME,
)

# File format descriptions
DESCRIPTION_PREDICTOR = """
The predictor file should be a CSV file with comma-separated values.
Each row represents a spatial point with the following columns:

Column 1: X coordinate (Easting)
Column 2: Y coordinate (Northing)  
Column 3: Urban mask (0=rural, 1=urban)
Columns 4+: Predictor values (environmental variables like DEM, Slope, SOC, Clay, etc.)

The file can have headers (optional) or just data rows.
Headers will be auto-detected. Common header names: Easting, Northing, X, Y, etc.

Example format WITH headers:
Easting,Northing,Mask,DEM,Slope,SOC,Clay
619500.0,5786500.0,0.0,132.95,5.2,1.8,0.25
619550.0,5786500.0,0.0,131.88,5.1,1.9,0.26

Example format WITHOUT headers:
619500.0,5786500.0,0.0,132.95,5.2,1.8,0.25
619550.0,5786500.0,0.0,131.88,5.1,1.9,0.26

NaN values are allowed in predictor columns (rows with NaN will be excluded from membership comparison).
"""

DESCRIPTION_MEMBERSHIP = """
The membership file should be a CSV file with fuzzy cluster membership values.
Each row represents a spatial point with the following columns:

Column 1: Easting (X coordinate) - must match predictor file coordinates
Column 2: Northing (Y coordinate) - must match predictor file coordinates
Columns 3+: Cluster membership values (probabilities for each cluster)

Requirements:
- First row should be a header with column names
- Membership values for each row should sum to approximately 1.0
- All membership values should be between 0.0 and 1.0
- Coordinates should match the predictor file (same points, same order)

Example format:
Easting,Northing,Cluster1,Cluster2,Cluster3
423150.5,5418230.2,0.7,0.2,0.1
423155.5,5418230.2,0.1,0.8,0.1
"""

DESCRIPTION_OSM = """
The OSM (OpenStreetMap) file should be a GeoJSON file containing the road network.
This file represents the actual roads that the mobile sensor will travel on.

Requirements:
- Valid GeoJSON format
- LineString or MultiLineString geometries representing road segments
- Must be in the same CRS (Coordinate Reference System) as the predictor/membership files
- Typically obtained from OpenStreetMap using tools like OSMnx or QGIS

The road network should cover the area represented by your predictor points.

Example filename: osm_data_transformed.geojson
"""


# =============================================================================
# INPUT FILE VALIDATION FUNCTIONS
# =============================================================================


def parse_predictor_file(filepath, allow_nan=True):
    """
    Validates predictor CSV file format and structure.

    Accepts CSV files with or without headers. If the first row contains
    non-numeric values (headers), it will be automatically detected and skipped.

    Note: NaN values are allowed in predictor files. Rows with any NaN values
    will be excluded from coordinate comparison with membership files.

    Args:
        filepath: Path to the predictor CSV file
        allow_nan: If True, allows NaN values in the data (default: True)

    Returns:
        numpy.ndarray: Validated predictor data

    Raises:
        ValueError: If file format is invalid with specific reason
        FileNotFoundError: If file doesn't exist
    """
    if not os.path.exists(filepath):
        raise FileNotFoundError(f"Predictor file not found: {filepath}")

    try:
        # First, detect the delimiter by reading a sample line
        with open(filepath, "r") as f:
            first_line = f.readline().strip()

        # Determine delimiter (comma, tab, or whitespace)
        if "," in first_line:
            delimiter = ","
        elif "\t" in first_line:
            delimiter = "\t"
        else:
            # Use whitespace delimiter (one or more spaces)
            delimiter = r"\s+"

        if ENABLE_MODULE_DEBUG and delimiter != ",":
            print(f"   ℹ️  Detected non-comma delimiter in CSV file")

        # First, try to detect if file has headers
        # Read first row to check if it contains text (headers) or numbers
        first_row = pd.read_csv(
            filepath,
            nrows=1,
            header=None,
            sep=delimiter,
            engine="python" if delimiter == r"\s+" else "c",
        )

        # Check if first row contains non-numeric data (likely headers)
        has_header = False
        try:
            # Try to convert first row to float - if it fails, it's likely headers
            pd.to_numeric(first_row.iloc[0, 0])
            # If first column is numeric, check if it looks like coordinates
            # Coordinates are typically large numbers (> 1000 for projected systems)
            first_val = float(first_row.iloc[0, 0])
            if (
                first_val < 10 and first_row.iloc[0, 0] != first_val
            ):  # String that converts to small number
                has_header = True
        except (ValueError, TypeError):
            # First value is not numeric - this is a header row
            has_header = True

        # Also check if first row contains typical header keywords
        if not has_header:
            first_row_str = str(first_row.iloc[0, 0]).lower()
            header_keywords = ["easting", "northing", "x", "y", "mask", "predictor"]
            if any(keyword in first_row_str for keyword in header_keywords):
                has_header = True

        # Load the predictor file with or without header
        if has_header:
            # Read CSV and ensure all data is treated as numeric from the start
            data_df = pd.read_csv(
                filepath,
                dtype=float,
                sep=delimiter,
                engine="python" if delimiter == r"\s+" else "c",
            )
            if ENABLE_MODULE_DEBUG:
                print(f"   📋 Detected header row in predictor file")
        else:
            # Read CSV without headers, treating all as numeric
            data_df = pd.read_csv(
                filepath,
                header=None,
                dtype=float,
                sep=delimiter,
                engine="python" if delimiter == r"\s+" else "c",
            )
            # Assign default column names: Easting, Northing, Mask, Predictor1, Predictor2, ...
            n_cols = data_df.shape[1]
            column_names = ["Easting", "Northing", "Mask"] + [
                f"Predictor{i}" for i in range(1, n_cols - 2)
            ]
            data_df.columns = column_names
            if ENABLE_MODULE_DEBUG:
                print(
                    f"   📋 No header detected - assigned default column names: {', '.join(column_names)}"
                )

        # Convert to numpy array
        data = data_df.values

        # Check if data is 2D
        if data.ndim != 2:
            raise ValueError(
                f"Predictor file must be a 2D array. Got {data.ndim}D array instead."
            )

        # Check minimum columns (X, Y, Mask)
        if data.shape[1] < 3:
            raise ValueError(
                f"Predictor file must have at least 3 columns (X, Y, Mask). "
                f"Got {data.shape[1]} columns."
            )

        # Check for NaN values
        has_nan = np.any(np.isnan(data))
        if has_nan:
            if not allow_nan:
                raise ValueError(
                    "Predictor file contains NaN (Not a Number) values. "
                    "All values must be valid numbers."
                )
            # Count rows with NaN
            nan_rows = np.any(np.isnan(data), axis=1)
            n_nan_rows = np.sum(nan_rows)
            if ENABLE_MODULE_DEBUG:
                print(
                    f"ℹ️  Predictor file contains {n_nan_rows} rows with NaN values (will be excluded from comparison)"
                )

        # Check for Inf values
        if np.any(np.isinf(data)):
            raise ValueError(
                "Predictor file contains Inf (Infinity) values. "
                "All values must be finite numbers."
            )

        # Check urban mask values (column 3) are binary (excluding NaN rows)
        valid_rows = ~np.any(np.isnan(data), axis=1)
        if np.any(valid_rows):
            mask_column = data[valid_rows, 2]
            unique_mask_values = np.unique(mask_column)
            if not np.all(np.isin(unique_mask_values, [0.0, 1.0])):
                raise ValueError(
                    f"Urban mask (column 3) must contain only 0 or 1. "
                    f"Found values: {unique_mask_values}"
                )

        if ENABLE_MODULE_DEBUG:
            print(
                f"✓ Predictor file validated: {data.shape[0]} points, {data.shape[1]} columns"
            )

        return data

    except pd.errors.EmptyDataError:
        raise ValueError(f"Predictor file is empty or corrupted: {filepath}")
    except pd.errors.ParserError as e:
        raise ValueError(
            f"Invalid CSV format in predictor file: {filepath}\nReason: {e}"
        )
    except Exception as e:
        if isinstance(e, (ValueError, FileNotFoundError)):
            raise
        raise ValueError(f"Error parsing predictor file: {filepath}\nReason: {e}")


def parse_membership_file(filepath):
    """
    Validates membership file format and structure.

    Accepts CSV files with or without headers. If the first row contains
    non-numeric values (headers), it will be automatically detected and skipped.

    Args:
        filepath: Path to the membership CSV file

    Returns:
        pandas.DataFrame: Validated membership data

    Raises:
        ValueError: If file format is invalid with specific reason
        FileNotFoundError: If file doesn't exist
    """
    import pandas as pd

    if not os.path.exists(filepath):
        raise FileNotFoundError(f"Membership file not found: {filepath}")

    try:
        # First, try to detect if file has headers
        # Read first row to check if it contains text (headers) or numbers
        first_row = pd.read_csv(filepath, nrows=1, header=None)

        # Check if first row contains non-numeric data (likely headers)
        has_header = False
        try:
            # Try to convert first row to float - if it fails, it's likely headers
            pd.to_numeric(first_row.iloc[0, 0])
            # If first column is numeric, check if it looks like coordinates
            # Coordinates are typically large numbers (> 1000 for projected systems)
            first_val = float(first_row.iloc[0, 0])
            if (
                first_val < 10 and first_row.iloc[0, 0] != first_val
            ):  # String that converts to small number
                has_header = True
        except (ValueError, TypeError):
            # First value is not numeric - this is a header row
            has_header = True

        # Also check if first row contains typical header keywords
        if not has_header:
            first_row_str = str(first_row.iloc[0, 0]).lower()
            header_keywords = [
                "easting",
                "northing",
                "x",
                "y",
                "cluster",
                "class",
                "membership",
            ]
            if any(keyword in first_row_str for keyword in header_keywords):
                has_header = True

        # Load the membership file with or without header
        if has_header:
            data = pd.read_csv(filepath)
            if ENABLE_MODULE_DEBUG:
                print(f"   📋 Detected header row in membership file")
        else:
            data = pd.read_csv(filepath, header=None)
            # Assign default column names: Easting, Northing, Cluster1, Cluster2, ...
            n_cols = data.shape[1]
            column_names = ["Easting", "Northing"] + [
                f"Cluster{i}" for i in range(1, n_cols - 1)
            ]
            data.columns = column_names
            if ENABLE_MODULE_DEBUG:
                print(
                    f"   📋 No header detected - assigned default column names: {', '.join(column_names)}"
                )

        # Check if file is empty
        if len(data) == 0:
            raise ValueError("Membership file is empty (no data rows).")

        # Check minimum columns (Easting, Northing, at least 1 cluster)
        if data.shape[1] < 3:
            raise ValueError(
                f"Membership file must have at least 3 columns "
                f"(Easting, Northing, Cluster1). Got {data.shape[1]} columns."
            )

        # Normalize column names to ensure first two are Easting/Northing
        # (in case headers use different names)
        if has_header:
            # Check for coordinate columns (case-insensitive)
            columns_lower = [col.lower() for col in data.columns]

            # Be more flexible - accept various coordinate names
            x_names = ["easting", "x", "lon", "longitude", "east"]
            y_names = ["northing", "y", "lat", "latitude", "north"]

            first_col_is_x = any(name in columns_lower[0] for name in x_names)
            second_col_is_y = any(name in columns_lower[1] for name in y_names)

            if not first_col_is_x:
                raise ValueError(
                    f"First column must be X coordinate (Easting/X/Lon). "
                    f"Got: '{data.columns[0]}'"
                )

            if not second_col_is_y:
                raise ValueError(
                    f"Second column must be Y coordinate (Northing/Y/Lat). "
                    f"Got: '{data.columns[1]}'"
                )

        # Check for NaN values in coordinates
        coord_cols = data.iloc[:, :2]
        if coord_cols.isna().any().any():
            raise ValueError(
                "Coordinate columns (first two columns) contain missing values (NaN)."
            )

        # Check cluster membership columns (all columns after coordinates)
        membership_cols = data.iloc[:, 2:]

        if membership_cols.shape[1] == 0:
            raise ValueError(
                "No cluster membership columns found (need at least 1 cluster)."
            )

        # Check for NaN values in membership columns
        if membership_cols.isna().any().any():
            raise ValueError(
                "Cluster membership columns contain missing values (NaN). "
                "All membership values must be numeric."
            )

        # Check membership values are in valid range [0, 1]
        if (membership_cols < 0).any().any() or (membership_cols > 1).any().any():
            raise ValueError(
                "Cluster membership values must be between 0.0 and 1.0. "
                "Found values outside this range."
            )

        # Check that membership values sum to approximately 1.0 per row
        row_sums = membership_cols.sum(axis=1)
        tolerance = 0.01  # Allow 1% deviation

        invalid_rows = np.where(np.abs(row_sums - 1.0) > tolerance)[0]
        if len(invalid_rows) > 0:
            # Show first few problematic rows
            sample_rows = invalid_rows[:5]
            sample_sums = row_sums.iloc[sample_rows].values
            raise ValueError(
                f"Cluster membership values must sum to 1.0 per row (±{tolerance}).\n"
                f"Found {len(invalid_rows)} rows with invalid sums.\n"
                f"Example rows: {sample_rows.tolist()} with sums: {sample_sums.tolist()}"
            )

        if ENABLE_MODULE_DEBUG:
            print(
                f"✓ Membership file validated: {len(data)} points, {membership_cols.shape[1]} clusters"
            )

        return data

    except pd.errors.EmptyDataError:
        raise ValueError(f"Membership file is empty or corrupted: {filepath}")
    except pd.errors.ParserError as e:
        raise ValueError(
            f"Invalid CSV format in membership file: {filepath}\nReason: {e}"
        )
    except Exception as e:
        if isinstance(e, (ValueError, FileNotFoundError)):
            raise
        raise ValueError(f"Error parsing membership file: {filepath}\nReason: {e}")


def validate_predictor_membership_consistency(predictor_path, membership_path):
    """
    Cross-validates that predictor and membership files are compatible.
    Ensures they represent the same spatial points in the same order.

    Note: Rows with NaN values in the predictor file are automatically excluded
    from the comparison. Only valid (non-NaN) rows are compared with membership data.

    Args:
        predictor_path: Path to predictor file
        membership_path: Path to membership CSV file

    Raises:
        ValueError: If files are inconsistent with specific reason
    """
    # Parse both files (this also validates their individual formats)
    predictor_data = parse_predictor_file(predictor_path, allow_nan=True)
    membership_data = parse_membership_file(membership_path)

    # Identify rows without NaN in predictor data
    valid_rows_mask = ~np.any(np.isnan(predictor_data), axis=1)
    n_valid_predictor = np.sum(valid_rows_mask)
    n_total_predictor = len(predictor_data)
    n_nan_rows = n_total_predictor - n_valid_predictor

    if ENABLE_MODULE_DEBUG and n_nan_rows > 0:
        print(
            f"ℹ️  Excluding {n_nan_rows} predictor rows with NaN values from comparison"
        )
        print(f"   Valid predictor rows: {n_valid_predictor}")

    # Filter predictor data to only valid rows
    valid_predictor_data = predictor_data[valid_rows_mask]

    # Get coordinates from both files
    n_membership = len(membership_data)
    pred_coords = valid_predictor_data[:, :2]  # X, Y from valid predictor rows
    memb_coords = membership_data.iloc[
        :, :2
    ].values  # Easting, Northing from membership

    # Round coordinates to avoid floating-point precision issues
    decimals = 6  # 6 decimal places = micrometer precision
    pred_coords_rounded = np.round(pred_coords, decimals)
    memb_coords_rounded = np.round(memb_coords, decimals)

    # Create set of predictor coordinates for fast lookup
    pred_coord_set = set(map(tuple, pred_coords_rounded))
    memb_coord_set = set(map(tuple, memb_coords_rounded))

    # Check if all membership coordinates exist in predictor set
    missing_coords = []
    for i, coord in enumerate(memb_coords_rounded):
        coord_tuple = tuple(coord)
        if coord_tuple not in pred_coord_set:
            missing_coords.append(
                (i, memb_coords[i])
            )  # Store original (unrounded) coordinate

    # Check row counts first
    if n_valid_predictor != n_membership:
        # Row counts don't match - check if it's actually a problem
        if missing_coords:
            # There are missing coordinates AND count mismatch - this is an error
            sample_size = min(5, len(missing_coords))
            sample_missing = missing_coords[:sample_size]

            error_msg = (
                f"Validation failed: Row count mismatch AND missing coordinates.\n\n"
                f"Point counts:\n"
                f"  Predictor file: {n_total_predictor} total points ({n_valid_predictor} valid, {n_nan_rows} with NaN)\n"
                f"  Membership file: {n_membership} points\n\n"
                f"{len(missing_coords)} membership coordinates NOT found in predictor file.\n"
                f"First {sample_size} missing coordinates:\n"
            )
            for idx, coord in sample_missing:
                error_msg += f"  Row {idx}: ({coord[0]:.6f}, {coord[1]:.6f})\n"

            error_msg += (
                f"\nAll membership coordinates must exist in the predictor file."
            )

            raise ValueError(error_msg)
        else:
            # Row counts don't match BUT all coordinates exist - just a warning, no error
            if ENABLE_MODULE_DEBUG:
                extra_in_predictor = len(pred_coord_set - memb_coord_set)
                print(
                    f"ℹ️  Row count mismatch but all membership coordinates exist in predictor:"
                )
                print(f"   Predictor: {n_valid_predictor} valid points")
                print(f"   Membership: {n_membership} points")
                print(f"   Extra in predictor: {extra_in_predictor}")
                print(f"   ✓ Validation passed - all membership coordinates found")
    else:
        # Row counts match - just verify no missing coordinates
        if missing_coords:
            sample_size = min(5, len(missing_coords))
            sample_missing = missing_coords[:sample_size]

            error_msg = (
                f"Coordinate validation failed: {len(missing_coords)} membership coordinates "
                f"NOT found in predictor file.\n\n"
                f"First {sample_size} missing coordinates:\n"
            )
            for idx, coord in sample_missing:
                error_msg += f"  Row {idx}: ({coord[0]:.6f}, {coord[1]:.6f})\n"

            error_msg += (
                f"\nAll membership coordinates must exist in the predictor file."
            )

            raise ValueError(error_msg)

    if ENABLE_MODULE_DEBUG:
        if n_nan_rows > 0:
            print(
                f"✓ Predictor-Membership consistency validated: {n_valid_predictor} matching points ({n_nan_rows} NaN rows excluded)"
            )
        else:
            print(
                f"✓ Predictor-Membership consistency validated: {n_valid_predictor} matching points"
            )


# =============================================================================
# PYDANTIC CONFIGURATION MODEL
# =============================================================================


class FullPipelineConfig(BaseModel):
    model_config = ConfigDict(populate_by_name=True)

    segment_number: Annotated[
        int,
        Field(
            default=1,
            alias="sn",
            ge=1,
            le=10,
            description="Must be between 1 and 10",
            title="Segments per class",
            json_schema_extra={"type": "integer"},
        ),
    ]
    lower_benefit_limit: Annotated[
        float,
        Field(
            default=0.1,
            alias="lbf",
            ge=0.0,
            le=1.0,
            description="Must be between 0.0 and 1.0",
            title="Lower benefit limit",
            json_schema_extra={"type": "float"},
        ),
    ]
    time_limit: Annotated[
        int,
        Field(
            default=80,
            alias="tl",
            gt=0,
            description="Must be a positive number",
            title="Time limit [h]",
            json_schema_extra={"type": "integer"},
        ),
    ]
    optimization_objective: Annotated[
        str,
        Field(
            default="d",
            alias="oo",
            pattern="^(d|t|i)$",
            description="Must be 'd' (distance) or 't' (time)",
            title="Objective",
            json_schema_extra={"type": "text"},
        ),
    ]
    max_aco_iteration: Annotated[
        int,
        Field(
            default=50,
            alias="mai",
            gt=0,
            description="Must be a positive integer",
            title="Max ACO iteration",
            json_schema_extra={"type": "integer"},
        ),
    ]
    ant_no: Annotated[
        int,
        Field(
            default=500,
            alias="an",
            gt=0,
            description="Must be a positive integer",
            title="Ant number",
            json_schema_extra={"type": "integer"},
        ),
    ]
    is_reversed: Annotated[
        bool,
        Field(
            default=False,
            alias="ir",
            description="Must be true or false",
            title="Reversed network",
            json_schema_extra={"type": "checkbox"},
        ),
    ]
    working_directory: Annotated[
        str,
        Field(
            default="work_dir",
            alias="wd",
            description="Working directory path",
            title="Working directory",
            json_schema_extra={"type": "text"},
        ),
    ]
    max_distance: Annotated[
        int,
        Field(
            default=50,
            alias="md",
            gt=0,
            description="Must be a positive integer",
            title="Max distance",
            json_schema_extra={"type": "integer"},
        ),
    ]
    benefit_type: Annotated[
        str,
        Field(
            default="t",
            alias="bt",
            pattern="^(t|m)$",
            description="Must be 't' (total) or 'm' (max)",
            title="Benefit type",
            json_schema_extra={"type": "text"},
        ),
    ]
    route_type: Annotated[
        str,
        Field(
            default="g",
            alias="rt",
            pattern="^(g|b)$",
            description="Must be 'g' (good) or 'b' (bad)",
            title="Route type",
            json_schema_extra={"type": "text"},
        ),
    ]

    # HPE-specific parameters
    num_points: Annotated[
        int,
        Field(
            default=50,
            alias="np",
            gt=0,
            description="Number of points for HPE optimization",
            title="Number of points",
            json_schema_extra={"type": "integer"},
        ),
    ]
    goal_ratio: Annotated[
        float,
        Field(
            default=100.0,
            alias="gr",
            gt=0,
            description="Goal ratio for HPE optimization",
            title="Goal ratio",
            json_schema_extra={"type": "float"},
        ),
    ]
    use_fixed_seeds: Annotated[
        bool,
        Field(
            default=False,
            alias="ufs",
            description="Use fixed seeds for reproducible results",
            title="Use fixed seeds",
            json_schema_extra={"type": "checkbox"},
        ),
    ]
    debug_seed: Annotated[
        int,
        Field(
            default=42,
            alias="ds",
            gt=0,
            description="Debug seed value",
            title="Debug seed",
            json_schema_extra={"type": "integer"},
        ),
    ]
    allow_fewer_points: Annotated[
        bool,
        Field(
            default=True,
            alias="afp",
            description="Allow fewer points than requested",
            title="Allow fewer points",
            json_schema_extra={"type": "checkbox"},
        ),
    ]


def load_or_create_parameters(
    working_dir="work_dir/test_pipeline", filename="parameters.json"
):
    """Loads parameters from a JSON file in the specified working directory or creates it with default values."""
    # Ensure the working directory exists
    os.makedirs(working_dir, exist_ok=True)

    parameters_path = os.path.join(working_dir, filename)

    # Check if file exists, if not create it with defaults
    if not os.path.exists(parameters_path):
        if ENABLE_MODULE_DEBUG:
            print(f"File not found, creating {parameters_path} with default values...")

        default_config = FullPipelineConfig(working_directory=working_dir)
        default_config_dict = default_config.model_dump(mode="json")

        if ENABLE_MODULE_DEBUG:
            print("Default config:", default_config_dict)

        # Write to the file
        try:
            with open(parameters_path, "w") as file:
                json.dump(default_config_dict, file, indent=4)
            if ENABLE_MODULE_DEBUG:
                print(f"Created default {parameters_path} with values")
        except Exception as e:
            print(f"Error writing to file: {e}")

        # Confirm file creation with a check
        if os.path.exists(parameters_path):
            if ENABLE_MODULE_DEBUG:
                print(f"File {parameters_path} successfully created!")
        else:
            print(f"Failed to create file at {parameters_path}")
    else:
        if ENABLE_MODULE_DEBUG:
            print(f"Loading existing parameters from {parameters_path}")

    # Load the parameters from the file
    with open(parameters_path, "r") as file:
        params = json.load(file)
    if ENABLE_MODULE_DEBUG:
        print(f"Loaded parameters from {parameters_path}: {params}")

    return FullPipelineConfig(**params)


def parse_args():
    """Parses command-line arguments using argparse."""
    parser = argparse.ArgumentParser(description="Full sensor routing pipeline program")

    # Original parameters
    parser.add_argument(
        "--sn",
        "-segment_number",
        type=int,
        help="how many segments will be visited per cluster",
    )
    parser.add_argument(
        "--lbf",
        "-lower_benefit_limit",
        type=float,
        help="lower benefit limit for the benefit calculation",
    )
    parser.add_argument(
        "--tl", "-time_limit", type=int, help="time limit for the agent"
    )
    parser.add_argument(
        "--oo",
        "-optimization_objective",
        type=str,
        help="optimization objective for the agent (d for distance, t for time)",
    )
    parser.add_argument(
        "--mai", "-max_aco_iteration", type=int, help="max ACO iteration for the agent"
    )
    parser.add_argument("--an", "-ant_no", type=int, help="ant number for the agent")
    parser.add_argument(
        "--ir", "-is_reversed", type=bool, help="is the road network reversed"
    )
    parser.add_argument(
        "--wd", "-working_directory", type=str, help="working directory"
    )
    parser.add_argument(
        "--bt", "-benefit_type", type=str, help="benefit type, t(total) or m(max)"
    )
    parser.add_argument(
        "--rt", "-route_type", type=str, help="route type, g(good) or b(bad)"
    )

    # HPE-specific parameters
    parser.add_argument(
        "--np", "-num_points", type=int, help="number of points for HPE optimization"
    )
    parser.add_argument(
        "--gr", "-goal_ratio", type=float, help="goal ratio for HPE optimization"
    )
    parser.add_argument(
        "--ufs",
        "-use_fixed_seeds",
        type=bool,
        help="use fixed seeds for reproducible results",
    )
    parser.add_argument("--ds", "-debug_seed", type=int, help="debug seed value")
    parser.add_argument(
        "--afp",
        "-allow_fewer_points",
        type=bool,
        help="allow fewer points than requested",
    )

    args = parser.parse_args()

    # Remove None values
    return {k: v for k, v in vars(args).items() if v is not None}


def get_final_config(manual_working_dir=None):
    """Combines JSON config and command-line arguments, with CLI taking priority."""
    cli_args = parse_args()

    # Priority: CLI args > manual override > default
    if "wd" in cli_args:
        # Command-line argument takes highest priority
        working_dir = cli_args["wd"]
    elif manual_working_dir:
        working_dir = manual_working_dir  # Manual setting second
    else:
        working_dir = "work_dir/test_pipeline"  # Default fallback

    # Load parameters from JSON or create them
    json_config = load_or_create_parameters(working_dir=working_dir)
    # Use model_dump() to get the parameters as a dictionary
    merged_params = json_config.model_dump(by_alias=True)
    merged_params.update(cli_args)  # Update with command-line args

    try:
        return FullPipelineConfig(**merged_params)  # Validate final config
    except ValidationError as e:
        print("Configuration Validation Error:", e)
        exit(1)


def sensor_routing_pipeline(work_dir):
    """
    Main entry point for sensor routing computation.

    This is the simplified interface that only requires a working directory.
    All configuration and input files are read from standardized locations:

    Required files in work_dir:
        - parameters.json: Pipeline configuration (auto-created with defaults if missing)
        - predictors.csv: Predictor data in CSV format (with or without headers)
        - memberships.csv: Fuzzy cluster membership values in CSV format
        - osm_data_transformed.geojson: OpenStreetMap road network in GeoJSON format

    Args:
        work_dir (str): Working directory path containing input files and parameters.json

    Returns:
        dict: Pipeline results with output file paths

    Raises:
        FileNotFoundError: If required input files are missing
        ValueError: If input files are invalid or inconsistent

    Example:
        >>> from sensor_routing import sensor_routing_pipeline
        >>> results = sensor_routing_pipeline("/path/to/work_dir")
        >>> print(f"Routing completed: {results['econ_solution_path']}")
    """
    # Validate work_dir exists
    if not os.path.exists(work_dir):
        raise FileNotFoundError(f"Working directory not found: {work_dir}")

    if not os.path.isdir(work_dir):
        raise ValueError(f"Working directory path is not a directory: {work_dir}")

    # Define expected file paths
    predictor_path = os.path.join(work_dir, PREDICTOR_FILENAME)
    membership_path = os.path.join(work_dir, MEMBERSHIP_FILENAME)
    osm_path = os.path.join(work_dir, OSM_FILENAME)
    parameters_path = os.path.join(work_dir, PARAMETERS_FILENAME)

    # Load or create parameters.json
    if ENABLE_MODULE_DEBUG:
        print(f"📂 Working directory: {work_dir}")
        print(f"📄 Loading configuration from: {parameters_path}")

    config = load_or_create_parameters(work_dir)
    config.working_directory = work_dir

    # Validate predictor file
    if not os.path.exists(predictor_path):
        raise FileNotFoundError(
            f"Predictor file not found: {predictor_path}\n\n"
            f"Expected file format:\n{DESCRIPTION_PREDICTOR}"
        )

    # Validate membership file exists
    if not os.path.exists(membership_path):
        raise FileNotFoundError(
            f"Membership file not found: {membership_path}\n\n"
            f"Expected file format:\n{DESCRIPTION_MEMBERSHIP}"
        )

    # Validate OSM file exists
    if not os.path.exists(osm_path):
        raise FileNotFoundError(
            f"OSM road network file not found: {osm_path}\n\n"
            f"Expected file format:\n{DESCRIPTION_OSM}"
        )

    if ENABLE_MODULE_DEBUG:
        print(f"✓ Found {PREDICTOR_FILENAME}")
        print(f"✓ Found {MEMBERSHIP_FILENAME}")
        print(f"✓ Found {OSM_FILENAME}")

    # Cross-validate predictor and membership files
    if ENABLE_MODULE_DEBUG:
        print("🔄 Cross-validating predictor and membership files...")

    try:
        validate_predictor_membership_consistency(predictor_path, membership_path)
    except ValueError as e:
        raise ValueError(
            f"Predictor and membership files are inconsistent:\n{e}\n\n"
            f"Both files must:\n"
            f"  - Contain the same number of data points\n"
            f"  - Have matching coordinates in the same order\n"
            f"  - Represent the same spatial locations"
        )

    if ENABLE_MODULE_DEBUG:
        print("=" * 80)
        print("✅ All input files validated successfully")
        print("=" * 80)

    # Run the full pipeline
    return full_sensor_routing_pipeline(config)


def full_sensor_routing_pipeline(config):
    """
    Execute the full sensor routing pipeline with all 9 steps:
    1. Point Mapping (Initial) - creates pm_output.json + point_hull_collection.json
    2. Benefit Calculation (Initial) - creates bc_benefits_output.json, bc_top_benefits_output.json
    3. Path Finding (Initial) - creates pf_output.json
    4. Route Finding (Initial) - creates solution.json
    5. Hull Points Extraction - creates optimal_grid_cells_N_filtered.json
    6. Econ Point Mapping - creates econ_pm_output.json (uses optimal grid cells)
    7. Econ Benefit Calculation - creates econ_bc_benefits_output.json, econ_bc_top_benefits_output.json
    8. Econ Path Finding - creates econ_pf_output.json
    9. Econ Route Finding - creates econ_solution.json (FINAL OUTPUT)

    Note: Steps 6-9 use the "econ" (economical) versions that work with optimized points from hull extraction
    """
    if ENABLE_MODULE_DEBUG:
        print("🚀 Starting Full Sensor Routing Pipeline")
        print("=" * 80)

    pipeline_start_time = time.time()

    # Step 1: Point Mapping (Initial)
    if ENABLE_MODULE_DEBUG:
        print("\n📍 Step 1: Point Mapping (Initial)")
        print("-" * 40)
    step_start = time.time()

    total_number_of_classes = point_mapping(
        config.working_directory,
        config.max_distance,
        config.is_reversed,
        config.segment_number,
    )
    if total_number_of_classes == 0:
        raise ValueError("Point Mapping failed: Insufficient nodes per class.")

    step_time = time.time() - step_start
    if ENABLE_MODULE_DEBUG:
        print(f"✅ Step 1 completed in {step_time:.2f} seconds")
        print(f"   Classes found: {total_number_of_classes}")
        print(f"   Outputs: transient/pm_output.json, point_hull_collection.json")

    # Step 2: Benefit Calculation (Initial)
    if ENABLE_MODULE_DEBUG:
        print("\n💰 Step 2: Benefit Calculation (Initial)")
        print("-" * 40)
    step_start = time.time()

    benefit_calculation(
        config.working_directory,
        config.lower_benefit_limit,
        total_number_of_classes,
        config.benefit_type,
        config.route_type,
    )

    step_time = time.time() - step_start
    if ENABLE_MODULE_DEBUG:
        print(f"✅ Step 2 completed in {step_time:.2f} seconds")
        print(
            f"   Outputs: transient/bc_benefits_output.json, bc_top_benefits_output.json"
        )

    # Step 3: Path Finding (Initial)
    if ENABLE_MODULE_DEBUG:
        print("\n🛤️  Step 3: Path Finding (Initial)")
        print("-" * 40)
    step_start = time.time()

    path_finding(
        config.working_directory,
        config.segment_number,
        total_number_of_classes,
        config.route_type,
        "i",
    )

    step_time = time.time() - step_start
    if ENABLE_MODULE_DEBUG:
        print(f"✅ Step 3 completed in {step_time:.2f} seconds")
        print(f"   Output: transient/pf_output.json")

    # Step 4: Route Finding (Initial)
    if ENABLE_MODULE_DEBUG:
        print("\n🗺️  Step 4: Route Finding (Initial)")
        print("-" * 40)
    step_start = time.time()

    route_finding(
        config.working_directory,
        total_number_of_classes,
        config.time_limit,
        config.optimization_objective,
        config.max_aco_iteration,
        config.ant_no,
        config.segment_number,
        config.benefit_type,
        config.route_type,
    )

    step_time = time.time() - step_start
    if ENABLE_MODULE_DEBUG:
        print(f"✅ Step 4 completed in {step_time:.2f} seconds")
        print(f"   Output: transient/solution.json")

    # Step 5: Hull Points Extraction (HPE Optimization)
    if ENABLE_MODULE_DEBUG:
        print("\n🔷 Step 5: Hull Points Extraction")
        print("-" * 40)
        print(f"   Extracting optimal {config.num_points} points using PSO")
    step_start = time.time()

    hpe_result = hpe_optimization(
        working_directory=config.working_directory,
        num_points=config.num_points,
        goal_ratio=config.goal_ratio,
        use_fixed_seeds=config.use_fixed_seeds,
        debug_seed=config.debug_seed,
        predictor_filename="predictors.csv",
        route_filename="initial_route.json",
        pm_output_filename="pm_output.json",
        return_ratio=True,
        allow_fewer_points=config.allow_fewer_points,
        include_summary=True,
        mode="single",
        start_time=step_start,
    )

    step_time = time.time() - step_start
    if hpe_result is not None:
        if isinstance(hpe_result, tuple):
            grid_cells, ratio = hpe_result
            if ENABLE_MODULE_DEBUG:
                print(f"✅ Step 5 completed in {step_time:.2f} seconds")
                print(f"   Achieved ratio: {ratio:.1f}%")
                print(
                    f"   Optimal points: {len(grid_cells) if grid_cells is not None else 0}"
                )
                print(
                    f"   Output: transient/optimal_grid_cells_{config.num_points}_filtered.json"
                )
        else:
            if ENABLE_MODULE_DEBUG:
                print(f"✅ Step 5 completed in {step_time:.2f} seconds")
    else:
        if ENABLE_MODULE_DEBUG:
            print(f"⚠️  Step 5 completed in {step_time:.2f} seconds (no result)")

    # Step 6: Econ Point Mapping
    if ENABLE_MODULE_DEBUG:
        print("\n📍 Step 6: Econ Point Mapping")
        print("-" * 40)
        print("   Using optimized points from hull extraction")
    step_start = time.time()

    total_number_of_classes_econ = econ_point_mapping(
        config.working_directory,
        config.max_distance,
        config.is_reversed,
        use_optimal_grid_cells=True,
        num_clusters=total_number_of_classes,
    )

    step_time = time.time() - step_start
    if ENABLE_MODULE_DEBUG:
        print(f"✅ Step 6 completed in {step_time:.2f} seconds")
        print(f"   Classes found: {total_number_of_classes_econ}")
        print(f"   Output: transient/econ_pm_output.json")

    # Step 7: Econ Benefit Calculation
    if ENABLE_MODULE_DEBUG:
        print("\n💰 Step 7: Econ Benefit Calculation")
        print("-" * 40)
    step_start = time.time()

    econ_benefit_calculation(
        config.working_directory,
        config.lower_benefit_limit,
        total_number_of_classes_econ,
        config.benefit_type,
        config.route_type,
    )

    step_time = time.time() - step_start
    if ENABLE_MODULE_DEBUG:
        print(f"✅ Step 7 completed in {step_time:.2f} seconds")
        print(
            f"   Outputs: transient/econ_bc_benefits_output.json, econ_bc_top_benefits_output.json"
        )

    # Step 8: Econ Path Finding
    if ENABLE_MODULE_DEBUG:
        print("\n🛤️  Step 8: Econ Path Finding")
        print("-" * 40)
    step_start = time.time()

    econ_path_finding(
        config.working_directory,
        config.segment_number,
        total_number_of_classes_econ,
        config.route_type,
        config.optimization_objective,
    )

    step_time = time.time() - step_start
    if ENABLE_MODULE_DEBUG:
        print(f"✅ Step 8 completed in {step_time:.2f} seconds")
        print(f"   Output: transient/econ_pf_output.json")

    # Step 9: Econ Route Finding (FINAL STEP)
    if ENABLE_MODULE_DEBUG:
        print("\n🗺️  Step 9: Econ Route Finding (FINAL)")
        print("-" * 40)
    step_start = time.time()

    econ_route_finding(
        config.working_directory,
        total_number_of_classes_econ,
        config.time_limit,
        config.optimization_objective,
        config.max_aco_iteration,
        config.ant_no,
        config.segment_number,
        config.benefit_type,
        config.route_type,
    )

    step_time = time.time() - step_start
    if ENABLE_MODULE_DEBUG:
        print(f"✅ Step 9 completed in {step_time:.2f} seconds")
        print(f"   Output: transient/econ_solution.json ⭐ FINAL RESULT")

    # Final summary
    total_time = time.time() - pipeline_start_time
    if ENABLE_MODULE_DEBUG:
        print("\n" + "=" * 80)
        print("🏁 FULL PIPELINE COMPLETED SUCCESSFULLY!")
        print("=" * 80)
        print(
            f"⏱️  Total Execution Time: {total_time:.2f} seconds ({total_time / 60:.2f} minutes)"
        )

        if total_time >= 3600:  # 1 hour
            hours = total_time // 3600
            minutes = (total_time % 3600) // 60
            seconds = total_time % 60
            print(f"⏱️  Detailed Time: {int(hours)}h {int(minutes)}m {seconds:.1f}s")
        elif total_time >= 60:
            minutes = total_time // 60
            seconds = total_time % 60
            print(f"⏱️  Detailed Time: {int(minutes)}m {seconds:.1f}s")

        print(f"📁 Working Directory: {config.working_directory}")
    if ENABLE_MODULE_DEBUG:
        print("✨ All 9 pipeline steps completed successfully!")
        print("\n📊 Pipeline Summary:")
        print(f"   0. Predictor Check → predictors.txt verified/generated")
        print(
            f"   1. Point Mapping → pm_output.json, point_hull_collection.json ({total_number_of_classes} classes)"
        )
        print(
            f"   2. Benefit Calculation → bc_benefits_output.json, bc_top_benefits_output.json"
        )
        print(f"   3. Path Finding → pf_output.json")
        print(f"   4. Route Finding → solution.json")
        print(
            f"   5. Hull Points Extraction → optimal_grid_cells_{config.num_points}_filtered.json"
        )
        print(
            f"   6. Econ Point Mapping → econ_pm_output.json ({total_number_of_classes_econ} classes)"
        )
        print(
            f"   7. Econ Benefit Calculation → econ_bc_benefits_output.json, econ_bc_top_benefits_output.json"
        )
        print(f"   8. Econ Path Finding → econ_pf_output.json")
        print(f"   9. Econ Route Finding → econ_solution.json ⭐")

    return True


def main():
    """
    Main entry point for the sensor-routing command-line interface.
    This function is called when running 'sensor-routing' from the command line.
    """
    from datetime import datetime

    # Ensure we're running from the correct directory (repository root)
    script_dir = os.path.dirname(os.path.abspath(__file__))
    # Go up one level from sensor_routing/
    repo_root = os.path.dirname(script_dir)
    os.chdir(repo_root)

    # Start timestamp
    main_start_time = time.time()
    start_timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    print(f"SENSOR ROUTING PIPELINE STARTED")
    print(f"Start Time: {start_timestamp}")

    if ENABLE_MODULE_DEBUG:
        print(f"📁 Working from: {os.getcwd()}")
        print("🔧 FULL SENSOR ROUTING PIPELINE")
        print("📊 Running all 9 steps in sequence")
        print("=" * 80)
        print("Pipeline Order:")
        print("1. Point Mapping (Initial)")
        print("2. Benefit Calculation (Initial)")
        print("3. Path Finding (Initial)")
        print("4. Route Finding (Initial)")
        print("5. Hull Points Extraction")
        print("6. Econ Point Mapping")
        print("7. Econ Benefit Calculation")
        print("8. Econ Path Finding")
        print("9. Econ Route Finding (FINAL)")
        print("=" * 80)

    config = get_final_config(manual_working_dir=None)

    # Now, `config` contains validated parameters and can be used in your program
    if ENABLE_MODULE_DEBUG:
        print("\n✅ Final Configuration Loaded:")
        print(config)
        print()

    # Run the full pipeline
    success = full_sensor_routing_pipeline(config)

    # End timestamp
    end_timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    total_runtime = time.time() - main_start_time

    if success:
        print(f"\nPIPELINE COMPLETED SUCCESSFULLY")
        print(f"End Time: {end_timestamp}")
        print(
            f"Total Runtime: {total_runtime:.2f} seconds ({total_runtime / 60:.2f} minutes)"
        )
    else:
        print(f"\nPIPELINE FAILED")
        print(f"End Time: {end_timestamp}")
        print(f"Runtime before failure: {total_runtime:.2f} seconds")
        exit(1)


if __name__ == "__main__":
    from datetime import datetime

    # ============================================================================
    # MANUAL WORKING DIRECTORY SETUP (for "Run without debugging" in VS Code)
    # ============================================================================
    # Set this to override the default working directory when running directly
    # Example: MANUAL_WORKING_DIR = "work_dir/test_pipeline"
    # Set to None to use command-line arguments or default
    # MANUAL_WORKING_DIR = "work_dir/test_john"  # <-- CHANGE THIS
    MANUAL_WORKING_DIR = "sensor_routing/test_data"  # <-- CHANGE THIS
    # ============================================================================

    # Ensure we're running from the correct directory (repository root)
    script_dir = os.path.dirname(os.path.abspath(__file__))
    # Go up one level from sensor_routing/
    repo_root = os.path.dirname(script_dir)
    os.chdir(repo_root)

    # Start timestamp
    main_start_time = time.time()
    start_timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    print(f"SENSOR ROUTING PIPELINE STARTED")
    print(f"Start Time: {start_timestamp}")

    if ENABLE_MODULE_DEBUG:
        print(f"📁 Working from: {os.getcwd()}")
        if MANUAL_WORKING_DIR:
            print(f"📂 Manual working directory set to: {MANUAL_WORKING_DIR}")

        print("🔧 FULL SENSOR ROUTING PIPELINE")
        print("📊 Running all 9 steps in sequence")
        print("=" * 80)
        print("Pipeline Order:")
        print("1. Point Mapping (Initial)")
        print("2. Benefit Calculation (Initial)")
        print("3. Path Finding (Initial)")
        print("4. Route Finding (Initial)")
        print("5. Hull Points Extraction")
        print("6. Econ Point Mapping")
        print("7. Econ Benefit Calculation")
        print("8. Econ Path Finding")
        print("9. Econ Route Finding (FINAL)")
        print("=" * 80)

    # Use the new simplified API - just pass working directory
    # All configuration is read from parameters.json
    # All input validation happens automatically
    if ENABLE_MODULE_DEBUG:
        print(f"\n🚀 Using simplified API with work_dir: {MANUAL_WORKING_DIR}")
        print()

    # Run the full pipeline with new simplified entry point
    success = sensor_routing_pipeline(MANUAL_WORKING_DIR)

    # End timestamp
    end_timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    total_runtime = time.time() - main_start_time

    if success:
        print(f"\nPIPELINE COMPLETED SUCCESSFULLY")
        print(f"End Time: {end_timestamp}")
        print(
            f"Total Runtime: {total_runtime:.2f} seconds ({total_runtime / 60:.2f} minutes)"
        )
    else:
        print(f"\nPIPELINE FAILED")
        print(f"End Time: {end_timestamp}")
        print(f"Runtime before failure: {total_runtime:.2f} seconds")
        exit(1)
