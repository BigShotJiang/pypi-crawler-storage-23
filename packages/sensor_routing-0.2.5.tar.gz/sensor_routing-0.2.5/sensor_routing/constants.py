"""Canonical filenames for sensor-routing pipeline input/output files."""

PREDICTOR_FILENAME = "predictors.csv"
MEMBERSHIP_FILENAME = "memberships.csv"
OSM_FILENAME = "osm_data_transformed.geojson"
PARAMETERS_FILENAME = "parameters.json"

# Final pipeline output
ROUTE_FILENAME = "solution.json"
