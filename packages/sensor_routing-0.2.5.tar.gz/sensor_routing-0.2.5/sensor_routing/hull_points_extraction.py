"""
HPE Single Mode - Filtered to Segment-Covered Cells AND Bounding Box
This file filters grid cells to those covered by segments AND within membership CSV bbox.
"""
#TODO continuous to discrete optimization with uniqueness enforcement
# =============================================================================
# DEBUG CONFIGURATION - Set to True to enable debug prints for this module
# =============================================================================
DEBUG = False

from gc import enable
import numpy as np
import pandas as pd
import json
import time
import os
import csv
import glob
from scipy.spatial import ConvexHull
from scipy.optimize import minimize
from tqdm import tqdm
from datetime import datetime


def get_bbox_from_data(data):
    """
    Calculate bounding box from data array.
    
    Args:
        data (ndarray): Data with coordinates in first 2 columns
        
    Returns:
        tuple: (min_east, max_east, min_north, max_north)
    """
    eastings = data[:, 0]
    northings = data[:, 1]
    
    return (np.min(eastings), np.max(eastings), np.min(northings), np.max(northings))


def bboxes_match(bbox1, bbox2, tolerance=1.0):
    """
    Check if two bounding boxes match within tolerance.
    
    Args:
        bbox1 (tuple): (min_east, max_east, min_north, max_north)
        bbox2 (tuple): (min_east, max_east, min_north, max_north)
        tolerance (float): Tolerance in meters for coordinate comparison
        
    Returns:
        bool: True if bounding boxes match within tolerance
    """
    if bbox1 is None or bbox2 is None:
        return False
    
    for i in range(4):
        if abs(bbox1[i] - bbox2[i]) > tolerance:
            return False
    
    return True


def load_membership_bbox(membership_csv_path):
    """
    Load bounding box from membership CSV file.
    
    Args:
        membership_csv_path (str): Path to membership CSV file
        
    Returns:
        tuple: (min_east, max_east, min_north, max_north) or None if file doesn't exist
    """
    if not os.path.exists(membership_csv_path):
        return None
    
    eastings = []
    northings = []
    
    with open(membership_csv_path, 'r') as f:
        reader = csv.reader(f)
        for row in reader:
            if not row or len(row) < 2:
                continue
            
            # Try to parse as float, skip if it's a header
            try:
                eastings.append(float(row[0]))
                northings.append(float(row[1]))
            except (ValueError, IndexError):
                # Skip header rows or invalid data
                continue
    
    if not eastings:
        return None
    
    min_east = min(eastings)
    max_east = max(eastings)
    min_north = min(northings)
    max_north = max(northings)
    
    if DEBUG:
        print(f"\n📦 Membership CSV Bounding Box:")
        print(f"   Easting:  {min_east:.1f} to {max_east:.1f} (width: {max_east-min_east:.1f}m)")
        print(f"   Northing: {min_north:.1f} to {max_north:.1f} (height: {max_north-min_north:.1f}m)")
    
    return (min_east, max_east, min_north, max_north)


def filter_predictors_by_bbox(predictor_data, bbox):
    """
    Filter predictor data to only include points within bounding box.
    
    Args:
        predictor_data (ndarray): Full predictor data with coordinates in first 2 columns
        bbox (tuple): (min_east, max_east, min_north, max_north)
        
    Returns:
        ndarray: Filtered predictor data
    """
    if bbox is None:
        return predictor_data
    
    min_east, max_east, min_north, max_north = bbox
    
    eastings = predictor_data[:, 0]
    northings = predictor_data[:, 1]
    
    mask = (eastings >= min_east) & (eastings <= max_east) & \
           (northings >= min_north) & (northings <= max_north)
    
    filtered = predictor_data[mask]
    
    if DEBUG:
        print(f"   🔍 Bbox filter: {len(predictor_data)} → {len(filtered)} points " +
              f"({100*len(filtered)/len(predictor_data):.1f}%)")
    
    return filtered


def create_summary_data(mode, start_time, end_time, **kwargs):
    """
    Create a dictionary with execution summary data for JSON output.
    
    Args:
        mode: Execution mode ('single', 'golden', etc.)
        start_time: Execution start time
        end_time: Execution end time
        **kwargs: Additional parameters to include
    
    Returns:
        dict: Summary data structure
    """
    runtime = end_time - start_time
    start_readable = datetime.fromtimestamp(start_time).strftime('%Y-%m-%d %H:%M:%S')
    end_readable = datetime.fromtimestamp(end_time).strftime('%Y-%m-%d %H:%M:%S')
    
    summary = {
        "execution_summary": {
            "mode": mode.upper() + "_FILTERED_BBOX",
            "timing": {
                "start_time": start_readable,
                "end_time": end_readable,
                "runtime_seconds": round(runtime, 2),
                "runtime_minutes": round(runtime/60, 2)
            },
            "parameters": {}
        }
    }
    
    # Add detailed time breakdown for longer runs
    if runtime >= 60:
        hours = runtime // 3600
        minutes = (runtime % 3600) // 60
        seconds = runtime % 60
        if hours > 0:
            summary["execution_summary"]["timing"]["detailed_time"] = f"{int(hours)}h {int(minutes)}m {seconds:.1f}s"
        else:
            summary["execution_summary"]["timing"]["detailed_time"] = f"{int(minutes)}m {seconds:.1f}s"
    
    # Mode-specific parameters
    if mode == 'single':
        summary["execution_summary"]["parameters"] = {
            "num_points": kwargs.get('num_points'),
            "goal_ratio": kwargs.get('goal_ratio'),
            "achieved_ratio": kwargs.get('achieved_ratio'),
            "use_fixed_seeds": kwargs.get('use_fixed_seeds'),
            "debug_seed": kwargs.get('debug_seed') if kwargs.get('use_fixed_seeds') else None,
            "allow_fewer_points": kwargs.get('allow_fewer_points'),
            "predictor_filename": kwargs.get('predictor_filename'),
            "route_filename": kwargs.get('route_filename'),
            "pm_output_filename": kwargs.get('pm_output_filename', 'pm_output.json'),
            "membership_csv_filename": kwargs.get('membership_csv_filename'),
            "working_directory": kwargs.get('working_directory'),
            "filtering_enabled": True,
            "bbox_filtering_enabled": kwargs.get('bbox_filtering_enabled', False)
        }
    
    return summary


def print_execution_summary(mode, start_time, end_time, **kwargs):
    """
    Print a comprehensive summary of the execution at the beginning of output.
    
    Args:
        mode: Execution mode ('single', 'golden', etc.)
        start_time: Execution start time
        end_time: Execution end time
        **kwargs: Additional parameters to display
    """
    if not DEBUG:
        return
        
    runtime = end_time - start_time
    
    print("=" * 80)
    print("🚀 SENSOR ROUTING OPTIMIZATION SUMMARY (FILTERED + BBOX)")
    print("=" * 80)
    
    # Convert timestamps to readable format
    start_readable = datetime.fromtimestamp(start_time).strftime('%Y-%m-%d %H:%M:%S')
    end_readable = datetime.fromtimestamp(end_time).strftime('%Y-%m-%d %H:%M:%S')
    
    print(f"🔧 Mode: {mode.upper()} + SEGMENT FILTERING + BBOX FILTERING")
    
    if runtime > 0.1:  # Only show timing details if meaningful
        print(f"🕐 Start Time: {start_readable}")
        print(f"🕐 End Time: {end_readable}")
        print(f"⏱️  Total Runtime: {runtime:.2f} seconds ({runtime/60:.2f} minutes)")
        if runtime >= 60:
            hours = runtime // 3600
            minutes = (runtime % 3600) // 60
            seconds = runtime % 60
            if hours > 0:
                print(f"⏱️  Detailed Time: {int(hours)}h {int(minutes)}m {seconds:.1f}s")
            else:
                print(f"⏱️  Detailed Time: {int(minutes)}m {seconds:.1f}s")
    else:
        print(f"🕐 Started: {start_readable}")
        print(f"⏱️  Status: Starting optimization...")
    
    # Mode-specific parameters
    if mode == 'single':
        print(f"📊 Points Tested: {kwargs.get('num_points', 'N/A')}")
        print(f"🎯 Target Ratio: {kwargs.get('goal_ratio', 'N/A'):.1f}%")
        if kwargs.get('achieved_ratio') is not None:
            print(f"📈 Achieved Ratio: {kwargs.get('achieved_ratio'):.1f}%")
        print(f"🌱 Fixed Seeds: {kwargs.get('use_fixed_seeds', 'N/A')}")
        if kwargs.get('use_fixed_seeds'):
            print(f"🔢 Debug Seed: {kwargs.get('debug_seed', 'N/A')}")
    
    # Working directory and file information
    print(f"📁 Working Directory: {kwargs.get('working_directory', 'N/A')}")
    print(f"📄 Predictor File: {kwargs.get('predictor_filename', 'N/A')}")
    print(f"🗺️  Route File: {kwargs.get('route_filename', 'N/A')}")
    print(f"🔍 PM Output File: {kwargs.get('pm_output_filename', 'pm_output.json')}")
    print(f"📋 Membership CSV: {kwargs.get('membership_csv_filename', 'N/A')}")
    print(f"✨ Filtering: ENABLED (segments + bbox)")
    print("=" * 80)
    print()


def evaluateVolume(x, predictor_data):
    """Evaluate convex hull volume for given indices."""
    # Round to get integer indices
    indices = np.round(x).astype(int)
    
    # Check bounds
    if np.any(indices < 0) or np.any(indices >= len(predictor_data)):
        return 1e6  # Large positive value for invalid indices
    
    # Check for duplicate indices
    if len(np.unique(indices)) < len(indices):
        return 1e6  # Penalize duplicate indices
    
    # Get selected points
    selected_points = predictor_data[indices]
    
    # Check dimensions
    if len(selected_points.shape) < 2:
        return 1e6
    
    # Check if we have at least n+1 points for n-dimensional hull
    min_points_needed = selected_points.shape[1] + 1
    if len(selected_points) < min_points_needed:
        return 1e6
    
    try:
        # Create convex hull and return negative volume for minimization
        hull = ConvexHull(selected_points)
        return -hull.volume  # Negative for minimization
    except Exception as e:
        # Return large positive value for degenerate cases
        return 1e6


def particle_swarm_optimization(fitness_func, num_variables, lb, ub, 
                              swarm_size=500, max_iterations=150, 
                              w=0.5, c1=1.5, c2=1.5,
                              use_fixed_seeds=False, debug_seed=42, use_adaptive_params=False,
                              matlab_style=False, adaptive_coefficients=False):
    """
    Particle Swarm Optimization implementation.
    
    Args:
        matlab_style: If True, use MATLAB-inspired enhancements (20% velocity, adaptive c1/c2)
        adaptive_coefficients: If True, adapt c1/c2 during optimization (like MATLAB)
    """
    
    if use_fixed_seeds:
        np.random.seed(debug_seed)
    
    # Initialize particles with optional stratified sampling (MATLAB-style)
    if matlab_style:
        # MATLAB-style initialization: mix of strategies
        positions = np.zeros((swarm_size, num_variables))
        quarter = swarm_size // 4
        
        # 1. Random uniform (50%)
        positions[:2*quarter] = np.random.uniform(lb, ub, (2*quarter, num_variables))
        
        # 2. Stratified sampling (25%)
        for i in range(2*quarter, min(3*quarter, swarm_size)):
            for j in range(num_variables):
                segment = j / num_variables
                # Handle both scalar and array bounds
                lb_val = lb[j] if isinstance(lb, np.ndarray) else lb
                ub_val = ub[j] if isinstance(ub, np.ndarray) else ub
                positions[i, j] = lb_val + segment * (ub_val - lb_val) + np.random.uniform(-0.1, 0.1) * (ub_val - lb_val)
                positions[i, j] = np.clip(positions[i, j], lb_val, ub_val)
        
        # 3. Spread initialization (25%)
        for i in range(3*quarter, swarm_size):
            # Handle both scalar and array bounds
            lb_val = lb if np.isscalar(lb) else lb
            ub_val = ub if np.isscalar(ub) else ub
            spread_indices = np.linspace(lb_val, ub_val, num_variables) if np.isscalar(lb_val) else np.array([np.linspace(lb_val[j], ub_val[j], num_variables)[j] for j in range(num_variables)])
            noise_scale = (ub_val - lb_val) * 0.05 if np.isscalar(lb_val) else np.array([(ub_val[j] - lb_val[j]) * 0.05 for j in range(num_variables)])
            positions[i] = spread_indices + np.random.normal(0, noise_scale if np.isscalar(noise_scale) else 1, num_variables)
            # Handle array clipping properly
            if np.isscalar(lb):
                positions[i] = np.clip(positions[i], lb, ub)
            else:
                for j in range(num_variables):
                    positions[i, j] = np.clip(positions[i, j], lb[j], ub[j])
    else:
        # Standard random uniform initialization
        positions = np.random.uniform(lb, ub, (swarm_size, num_variables))
    
    # Velocity initialization (MATLAB uses 10-20% of search space, not 50%)
    if matlab_style:
        max_velocity = (ub - lb) * 0.2  # MATLAB-style: 20% of search space
    else:
        max_velocity = (ub - lb) * 0.5  # Original: 50% of search space
    
    velocities = np.random.uniform(-max_velocity, max_velocity, (swarm_size, num_variables))
    
    # Personal best positions and fitness
    personal_best_positions = positions.copy()
    personal_best_fitness = np.full(swarm_size, np.inf)
    
    # Global best
    global_best_position = None
    global_best_fitness = np.inf
    
    # Evaluate initial fitness
    for i in range(swarm_size):
        fitness = fitness_func(positions[i])
        personal_best_fitness[i] = fitness
        
        if fitness < global_best_fitness:
            global_best_fitness = fitness
            global_best_position = positions[i].copy()
    
    # PSO iterations
    original_w = w
    original_c1 = c1
    original_c2 = c2
    
    for iteration in range(max_iterations):
        # Adaptive parameters
        if use_adaptive_params:
            # Adaptive inertia weight - decreases over time
            w = original_w * (1 - iteration / max_iterations)
        
        if adaptive_coefficients and matlab_style:
            # MATLAB-style adaptive coefficients (c1 decreases, c2 increases)
            progress = iteration / max_iterations
            c1 = original_c1 - (original_c1 - 0.5) * progress  # c1: 2.0 → 0.5
            c2 = original_c2 + (2.5 - original_c2) * progress  # c2: 2.0 → 2.5
        
        for i in range(swarm_size):
            # Update velocity
            r1, r2 = np.random.random(2)
            cognitive = c1 * r1 * (personal_best_positions[i] - positions[i])
            social = c2 * r2 * (global_best_position - positions[i])
            velocities[i] = w * velocities[i] + cognitive + social
            
            # ✅ FIX: Clamp velocity to prevent excessive movement
            velocities[i] = np.clip(velocities[i], -max_velocity, max_velocity)
            
            # Update position
            positions[i] += velocities[i]
            
            # Apply bounds
            positions[i] = np.clip(positions[i], lb, ub)
            
            # Evaluate fitness
            fitness = fitness_func(positions[i])
            
            # Update personal best
            if fitness < personal_best_fitness[i]:
                personal_best_fitness[i] = fitness
                personal_best_positions[i] = positions[i].copy()
                
                # Update global best
                if fitness < global_best_fitness:
                    global_best_fitness = fitness
                    global_best_position = positions[i].copy()
        
        # Print progress every 50 iterations
        if iteration % 50 == 0 or iteration == max_iterations - 1:
            if DEBUG:
                print(f"Iteration {iteration}, Best fitness: {global_best_fitness:.6f}, w: {w:.3f}")
    
    if DEBUG:
        print(f"PSO completed after {max_iterations} iterations")
    
    return global_best_position, global_best_fitness


def particle_swarm_optimization_simple(fitness_func, num_variables, lb, ub, N,
                                      swarm_size=300, max_iterations=200,
                                      w=0.7, c1=2.0, c2=2.0,
                                      use_fixed_seeds=False, debug_seed=42):
    """
    Simplified PSO that enforces unique integer indices throughout optimization.
    Better for discrete selection problems.
    
    Args:
        fitness_func: Function to minimize (takes array of indices)
        num_variables: Number of points to select
        lb: Lower bound (should be 0)
        ub: Upper bound (should be N-1, where N is total points available)
        N: Total number of points available for selection
        swarm_size: Number of particles
        max_iterations: Maximum iterations
        w: Inertia weight
        c1: Cognitive parameter
        c2: Social parameter
        use_fixed_seeds: Whether to use fixed random seed
        debug_seed: Seed value if using fixed seeds
    """
    if use_fixed_seeds:
        np.random.seed(debug_seed)
    
    if DEBUG:
        print(f"\n🔬 Using SIMPLE PSO (enforces unique indices)")
        print(f"   Selecting {num_variables} from {int(ub)+1} available points")
    
    # Initialize particles with unique indices
    positions = np.zeros((swarm_size, num_variables))
    for i in range(swarm_size):
        positions[i] = np.random.choice(N, num_variables, replace=False)
    
    velocities = np.random.uniform(-2, 2, (swarm_size, num_variables))
    
    # Personal best
    personal_best_positions = positions.copy()
    personal_best_fitness = np.full(swarm_size, np.inf)
    
    # Global best
    global_best_position = None
    global_best_fitness = np.inf
    
    # Evaluate initial fitness
    for i in range(swarm_size):
        fitness = fitness_func(positions[i])
        personal_best_fitness[i] = fitness
        
        if fitness < global_best_fitness:
            global_best_fitness = fitness
            global_best_position = positions[i].copy()
    
    # PSO iterations
    for iteration in range(max_iterations):
        # Adaptive inertia weight
        w_adaptive = w * (1 - iteration / max_iterations)
        
        for i in range(swarm_size):
            # Update velocity
            r1, r2 = np.random.random(2)
            cognitive = c1 * r1 * (personal_best_positions[i] - positions[i])
            social = c2 * r2 * (global_best_position - positions[i])
            velocities[i] = w_adaptive * velocities[i] + cognitive + social
            
            # Update position
            new_position = positions[i] + velocities[i]
            
            # Round to integers and clip to bounds
            new_position = np.clip(np.round(new_position), lb, ub).astype(int)
            
            # Enforce uniqueness: if duplicates, replace with random unselected indices
            unique_indices = np.unique(new_position)
            if len(unique_indices) < num_variables:
                # Get unselected indices
                all_indices = set(range(N))
                selected = set(unique_indices)
                unselected = list(all_indices - selected)
                
                # How many more do we need?
                needed = num_variables - len(unique_indices)
                if len(unselected) >= needed:
                    additional = np.random.choice(unselected, needed, replace=False)
                    new_position = np.concatenate([unique_indices, additional])
                else:
                    # Not enough unselected, use what we have
                    new_position = unique_indices
            
            positions[i] = new_position
            
            # Evaluate fitness
            fitness = fitness_func(positions[i])
            
            # Update personal best
            if fitness < personal_best_fitness[i]:
                personal_best_fitness[i] = fitness
                personal_best_positions[i] = positions[i].copy()
                
                # Update global best
                if fitness < global_best_fitness:
                    global_best_fitness = fitness
                    global_best_position = positions[i].copy()
        
        # Print progress
        if iteration % 50 == 0 or iteration == max_iterations - 1:
            if DEBUG:
                n_unique = len(np.unique(global_best_position))
                print(f"Iteration {iteration}, Best fitness: {global_best_fitness:.6f}, " +
                      f"Unique indices: {n_unique}/{num_variables}, w: {w_adaptive:.3f}")
    
    if DEBUG:
        print(f"Simple PSO completed after {max_iterations} iterations")
        print(f"Final solution has {len(np.unique(global_best_position))} unique indices")
    
    return global_best_position, global_best_fitness


def hpe_optimization(
    working_directory='work_dir/test_john',
    num_points=50,
    goal_ratio=100.0,
    use_fixed_seeds=False,
    debug_seed=42,
    predictor_filename='predictors.csv',
    route_filename='initial_route.json',
    pm_output_filename='pm_output.json',
    membership_csv_filename=None,  # New parameter for membership CSV
    enable_bbox_filter=True,  # New parameter to enable/disable bbox filtering
    return_ratio=False,
    fast_search_mode=False,
    allow_fewer_points=False,
    use_simple_pso=False,  # New parameter to use simple PSO with uniqueness enforcement
    include_summary=False,
    mode=None,
    start_time=None,
    custom_swarm_size=None,
    custom_max_iterations=None,
    custom_inertia_weight=None,
    custom_cognitive_coef=None,
    custom_social_coef=None,
    num_pso_runs=None,
    use_adaptive_inertia=True,
    use_discrete_pso=False,
    enable_local_search=True,
    matlab_style_pso=False,
    adaptive_coefficients=False,
    **kwargs
):
    """
    High-performance route optimization with SEGMENT + BBOX FILTERING.
    Only selects grid cells that are covered by segments AND within membership CSV bbox.
    
    Args:
        membership_csv_filename: Optional. If provided, filters predictors to bbox of this CSV.
                                If None, only segment filtering is applied.
        enable_bbox_filter: If False, skips bbox filtering even if membership_csv_filename is provided.
        use_simple_pso: If True, uses Simple PSO (discrete selection with uniqueness enforcement).
                        This is useful when num_points is close to or exceeds hull points,
                        where standard PSO's continuous optimization creates duplicate indices.
    """
    # Configuration from parameters
    USE_FIXED_SEEDS = use_fixed_seeds
    DEBUG_SEED = debug_seed
    
    # Construct file paths
    transient_dir = os.path.join(working_directory, 'transient')
    predictor_path = os.path.join(working_directory, predictor_filename)
    route_path = os.path.join(transient_dir, route_filename)
    pm_output_path = os.path.join(transient_dir, pm_output_filename)

    # Membership CSV path - auto-detect if not provided (same logic as point_mapping)
    membership_csv_path = None
    if membership_csv_filename:
        membership_csv_path = os.path.join(working_directory, membership_csv_filename)
    else:
        # Auto-detect membership CSV using same logic as point_mapping
        import glob
        csv_files = glob.glob(os.path.join(working_directory, '*.csv'))
        # Filter out points.csv and prefer membership files
        csv_files = [f for f in csv_files if 'points.csv' not in os.path.basename(f)]
        if csv_files:
            # Prefer files with 'membership' in the name, otherwise take the first
            membership_files = [f for f in csv_files if 'membership' in os.path.basename(f).lower()]
            detected_csv = membership_files[0] if membership_files else csv_files[0]
            membership_csv_path = detected_csv
            if DEBUG:
                print(f"🔍 Auto-detected membership CSV: {os.path.basename(membership_csv_path)}")
    
    # Ensure transient directory exists
    os.makedirs(transient_dir, exist_ok=True)
    
    # Load predictors and route data
    try:
        # Detect delimiter by reading first line (same logic as full_pipeline_cli.py)
        with open(predictor_path, 'r') as f:
            first_line = f.readline().strip()
        
        # Determine delimiter (comma, tab, or whitespace)
        if ',' in first_line:
            delimiter = ','
        elif '\t' in first_line:
            delimiter = '\t'
        else:
            # Use whitespace delimiter (one or more spaces)
            delimiter = r'\s+'
        
        # Use pandas for consistent CSV/TXT loading with automatic delimiter detection
        dat = pd.read_csv(
            predictor_path, 
            sep=delimiter,
            engine='python' if delimiter == r'\s+' else 'c',
            dtype=float, 
            header=None
        ).values
        
        if DEBUG:
            print(f"Loaded predictor data from {predictor_path} with shape: {dat.shape}")
        
        # Compare bounding boxes and decide if filtering is needed
        bbox_filtering_enabled = False
        
        if enable_bbox_filter and membership_csv_path and os.path.exists(membership_csv_path):
            # Get both bounding boxes
            membership_bbox = load_membership_bbox(membership_csv_path)
            predictor_bbox = get_bbox_from_data(dat)
            
            if DEBUG:
                print(f"\n📦 Predictor File Bounding Box:")
                print(f"   Easting:  {predictor_bbox[0]:.1f} to {predictor_bbox[1]:.1f} (width: {predictor_bbox[1]-predictor_bbox[0]:.1f}m)")
                print(f"   Northing: {predictor_bbox[2]:.1f} to {predictor_bbox[3]:.1f} (height: {predictor_bbox[3]-predictor_bbox[2]:.1f}m)")
            
            if membership_bbox is not None:
                # Check if bounding boxes match
                if bboxes_match(predictor_bbox, membership_bbox, tolerance=1.0):
                    if DEBUG:
                        print(f"\n✅ Bounding boxes match! Using predictor file as-is (no filtering needed)")
                        print(f"   Predictor and membership data cover the same geographic area.")
                else:
                    if DEBUG:
                        print(f"\n🔍 Bounding boxes differ! Filtering predictors to membership bbox...")
                        print(f"   Predictor bbox: E[{predictor_bbox[0]:.1f}, {predictor_bbox[1]:.1f}] N[{predictor_bbox[2]:.1f}, {predictor_bbox[3]:.1f}]")
                        print(f"   Membership bbox: E[{membership_bbox[0]:.1f}, {membership_bbox[1]:.1f}] N[{membership_bbox[2]:.1f}, {membership_bbox[3]:.1f}]")
                    dat = filter_predictors_by_bbox(dat, membership_bbox)
                    bbox_filtering_enabled = True
                    if DEBUG:
                        print(f"   ✅ Bbox filtering applied: {dat.shape[0]} points remaining")
                        print(f"   🎯 All subsequent operations (normalization, hull calculation) use filtered data")
            else:
                if DEBUG:
                    print(f"   ⚠️ Could not load bbox from {membership_csv_path}, skipping bbox filter")
        else:
            if DEBUG:
                if not enable_bbox_filter:
                    print(f"   ℹ️ Bbox filtering disabled (enable_bbox_filter=False)")
                elif membership_csv_path:
                    print(f"   ℹ️ Membership CSV not found: {membership_csv_path}, skipping bbox filter")
                else:
                    print(f"   ℹ️ No membership CSV specified, skipping bbox filter")
        
        # Check for NaN values in predictor columns only (not X, Y, mask)
        if DEBUG:
            print("Checking for NaN values in predictor columns...")
        predictor_cols = dat[:, 3:]  # Columns 3 and beyond are predictors
        nan_rows = np.isnan(predictor_cols).any(axis=1)
        if DEBUG:
            print(f"Found {np.sum(nan_rows)} rows with NaN values out of {len(dat)} total rows")
        
        if np.sum(nan_rows) > 0:
            # Remove rows with NaN values in predictor columns
            dat = dat[~nan_rows]
            if DEBUG:
                print(f"After removing NaN rows: {dat.shape}")
        
        with open(route_path, 'r') as f:
            so = json.load(f)
        if DEBUG:
            print(f"Loaded solution from {route_path} with {len(so['Path'])} path points")
        
        # Load pm_output to get segment-covered points
        if DEBUG:
            print(f"\n🔍 Loading pm_output from {pm_output_path}...")
        with open(pm_output_path, 'r') as f:
            pm = json.load(f)
        
        # Extract all points covered by segments
        pm_coords = set()
        for road in pm.values():
            for seg in road['segments'].values():
                if seg.get('number_of_points', 0) > 0:
                    for pt in seg['points'].values():
                        pm_coords.add(tuple(pt['point_coordinates']))
        
        if DEBUG:
            print(f"✅ Found {len(pm_coords)} grid cells covered by segments")
        
    except FileNotFoundError as e:
        if DEBUG:
            print(f"Error: File not found - {e}")
        return None
    
    # Set up random seeding strategy
    if USE_FIXED_SEEDS:
        base_seed = DEBUG_SEED
        if DEBUG:
            print(f"Using FIXED random seeds for reproducible results (base seed: {base_seed})")
        random_seed_mode = "FIXED"
    else:
        base_seed = int(time.time()) % 10000  # Keep it reasonable
        if DEBUG:
            print(f"Using TIME-BASED random seeds for varied results (base seed: {base_seed})")
        random_seed_mode = "VARIABLE"
    
    if DEBUG:
        print(f"Random seed mode: {random_seed_mode}")
    
    # Create spatial grid
    unique_x = np.unique(dat[:, 0])
    unique_y = np.unique(dat[:, 1])
    dx = unique_x[1] - unique_x[0] if len(unique_x) > 1 else 1.0
    dy = unique_y[1] - unique_y[0] if len(unique_y) > 1 else 1.0
    
    if DEBUG:
        print(f"Grid dimensions: {len(unique_x)} x {len(unique_y)}")
        print(f"Available data points: {len(dat)}")
        print(f"Expected grid size: {len(unique_x) * len(unique_y)}")
        print(f"Grid spacing: dx={dx:.3f}, dy={dy:.3f}")
    
    # Create coordinate mappings for grid indexing
    x_to_idx = {x: i for i, x in enumerate(unique_x)}
    y_to_idx = {y: i for i, y in enumerate(unique_y)}
    
    # Create full grid structure for route matching
    X_full = np.zeros((len(unique_y), len(unique_x)))
    Y_full = np.zeros((len(unique_y), len(unique_x)))
    for i, y in enumerate(unique_y):
        for j, x in enumerate(unique_x):
            X_full[i, j] = x
            Y_full[i, j] = y
    
    # Match route and map - find grid cells crossed by route
    if DEBUG:
        print("Matching route with map...")
    route_mask = np.zeros(X_full.shape, dtype=bool)
    
    # Use tqdm only if DEBUG is enabled
    path_range = tqdm(range(len(so['Path']) - 1)) if DEBUG else range(len(so['Path']) - 1)
    for ii in path_range:
        # Line interpolation for two neighboring points on the route
        p1 = so['Path'][ii]
        p2 = so['Path'][ii + 1]
        
        dist = np.sqrt((p1[0] - p2[0])**2 + (p1[1] - p2[1])**2)
        no_pieces = max(int(round(dist)), 2)
        
        x_line = np.linspace(p1[0], p2[0], no_pieces)
        y_line = np.linspace(p1[1], p2[1], no_pieces)
        
        # Map grid index calculation (Python uses 0-based indexing)
        ix = np.round((x_line - X_full[0, 0]) / dx).astype(int)
        iy = np.round((y_line - Y_full[0, 0]) / dy).astype(int)
        
        # Limit to valid indices
        ix = np.clip(ix, 0, X_full.shape[1] - 1)
        iy = np.clip(iy, 0, X_full.shape[0] - 1)
        
        # Flag map grid nodes crossed by route
        route_mask[iy, ix] = True
    
    # Keep only predictor data for grid cells crossed by route
    # We need to match the route_mask with our actual data points
    
    # Create a mapping from grid coordinates to data indices
    coord_to_data_idx = {}
    for i, row in enumerate(dat):
        x, y = row[0], row[1]
        coord_to_data_idx[(x, y)] = i
    
    # Find which data points correspond to route-crossed grid cells
    route_data_indices = []
    for i in range(len(unique_y)):
        for j in range(len(unique_x)):
            if route_mask[i, j]:
                x, y = X_full[i, j], Y_full[i, j]
                if (x, y) in coord_to_data_idx:
                    route_data_indices.append(coord_to_data_idx[(x, y)])
    
    if len(route_data_indices) == 0:
        if DEBUG:
            print("Error: No data points found along the route")
        return None
    
    dat_red = dat[route_data_indices]
    if DEBUG:
        print(f"Reduced data shape (route-crossed): {dat_red.shape}")
    
    # *** Filter to only segment-covered cells ***
    if DEBUG:
        print(f"\n🔍 FILTERING: Keeping only cells covered by segments...")
    segment_covered_mask = np.array([tuple(row[:2]) in pm_coords for row in dat_red])
    dat_red_before = len(dat_red)
    dat_red = dat_red[segment_covered_mask]
    if DEBUG:
        print(f"✅ Filtered from {dat_red_before} to {len(dat_red)} cells ({100*len(dat_red)/dat_red_before:.1f}%)")
    
    if len(dat_red) == 0:
        if DEBUG:
            print("❌ Error: No segment-covered data points found")
        return None
    
    # Check data before filtering
    if DEBUG:
        print(f"Urban areas (mask==1): {np.sum(dat_red[:, 2] == 1)} points")
        print(f"Non-urban areas (mask!=1): {np.sum(dat_red[:, 2] != 1)} points")
    
    # Double-check for any remaining NaN values (should be none after initial cleaning)
    remaining_nan = np.isnan(dat_red[:, 3:]).any(axis=1)
    if np.sum(remaining_nan) > 0:
        if DEBUG:
            print(f"Warning: Found {np.sum(remaining_nan)} additional rows with NaN values, removing them")
        dat_red = dat_red[~remaining_nan]
        if DEBUG:
            print(f"After removing remaining NaN values: {dat_red.shape}")
    
    # Eliminate grid cells in urban areas (mask == 1)
    dat_red = dat_red[dat_red[:, 2] != 1]
    if DEBUG:
        print(f"After removing urban areas: {dat_red.shape}")
    
    if len(dat_red) == 0:
        if DEBUG:
            print("Error: No valid data points remaining after cleaning")
        return None
    
    # Check if we have enough points for the analysis
    num_predictors = dat_red.shape[1] - 3  # subtract X, Y, mask columns
    min_points_for_hull = num_predictors + 1
    
    if len(dat_red) < min_points_for_hull:
        if DEBUG:
            print(f"Warning: Only {len(dat_red)} points available, but need at least {min_points_for_hull} for {num_predictors}D convex hull")
            print("Consider:")
            print("1. Including urban areas in analysis")
            print("2. Using a different route or expanding the route coverage")
            print("3. Reducing the number of predictor dimensions")
        
        # Option to include urban areas if not enough points
        if len(dat_red) < min_points_for_hull:
            if DEBUG:
                print("Attempting to include urban areas to get more data points...")
            # Reapply segment filter but keep urban areas
            dat_red_all = dat[route_data_indices]
            segment_covered_mask_all = np.array([tuple(row[:2]) in pm_coords for row in dat_red_all])
            dat_red_with_urban = dat_red_all[segment_covered_mask_all]
            
            if len(dat_red_with_urban) >= min_points_for_hull:
                if DEBUG:
                    print(f"Including urban areas: {len(dat_red_with_urban)} points available")
                dat_red = dat_red_with_urban
            else:
                if DEBUG:
                    print(f"Even with urban areas, only {len(dat_red_with_urban)} points available")
                return None
    
    # Normalize data relative to the filtered dataset (dat_red, not full dat)
    # This ensures that when we select all hull points, we get 100% volume
    minval = np.min(dat_red[:, 3:], axis=0)  # Use dat_red for consistent normalization
    maxval = np.max(dat_red[:, 3:], axis=0)
    
    if DEBUG:
        print(f"\n📐 Normalization based on filtered data (dat_red):")
        print(f"   Min values: {minval[:3]}..." if len(minval) > 3 else f"   Min values: {minval}")
        print(f"   Max values: {maxval[:3]}..." if len(maxval) > 3 else f"   Max values: {maxval}")
    
    # Avoid division by zero
    range_vals = maxval - minval
    range_vals[range_vals == 0] = 1
    
    ndat_red = dat_red.copy()
    ndat_red[:, 3:] = (dat_red[:, 3:] - minval) / range_vals
    
    # Compute convex hull for normalized predictor data
    if DEBUG:
        print("Computing convex hull...")
    
    # Check for remaining NaN or infinite values
    predictor_data = ndat_red[:, 3:]
    if np.any(np.isnan(predictor_data)) or np.any(np.isinf(predictor_data)):
        if DEBUG:
            print(f"Error: NaN or infinite values found in normalized predictor data")
            print(f"NaN count: {np.sum(np.isnan(predictor_data))}")
            print(f"Inf count: {np.sum(np.isinf(predictor_data))}")
        return None
    
    # Check if we have enough points for convex hull
    min_points_needed = predictor_data.shape[1] + 1  # n+1 points for n-dimensional space
    if len(predictor_data) < min_points_needed:
        if DEBUG:
            print(f"Error: Need at least {min_points_needed} points for {predictor_data.shape[1]}-dimensional convex hull, but only have {len(predictor_data)}")
            print("\nPossible solutions:")
            print("1. Check if the route covers enough grid cells")
            print("2. Include urban areas in the analysis")
            print("3. Use a different route with broader coverage")
            print("4. Reduce the number of predictor variables")
            print(f"5. Current predictor dimensions: {predictor_data.shape[1]}")
            
            # Print some sample data for debugging
            print(f"\nSample of available data:")
            print(f"Coordinates (X,Y): {dat_red[:min(5, len(dat_red)), :2]}")
            print(f"Predictor stats: min={np.min(predictor_data, axis=0)}, max={np.max(predictor_data, axis=0)}")
        return None
    
    try:
        hull = ConvexHull(predictor_data)
        hull_point_indices = np.unique(hull.simplices.flatten())
        P_hull = ndat_red[hull_point_indices]
        
        if DEBUG:
            print(f"Convex hull uses {len(hull_point_indices)} points")
    except Exception as e:
        if DEBUG:
            print(f"Error computing convex hull: {e}")
            print(f"Data shape: {predictor_data.shape}")
            print(f"Data stats - min: {np.min(predictor_data):.3f}, max: {np.max(predictor_data):.3f}")
        return None
    
    # Save hull points for verification (only in debug mode)
    if DEBUG:
        points_2d = P_hull[:, :2].tolist()  # Get only X and Y coordinates
        hull_points_path = os.path.join(transient_dir, 'hull_points_check_filtered_bbox.json')
        with open(hull_points_path, 'w') as f:
            json.dump(points_2d, f, indent=2)
        print(f"Saved hull points to {hull_points_path}")

    # Calculate full volume
    try:
        full_hull = ConvexHull(P_hull[:, 3:])
        V_full = full_hull.volume
        if DEBUG:
            print(f"Full convex hull volume: {V_full}")
    except Exception as e:
        if DEBUG:
            print(f"Error calculating full volume: {e}")
        return None
    
    if V_full <= 0:
        if DEBUG:
            print("Error: Full volume is zero or negative")
        return None
    
    # Enhanced optimization with different random seeds and parameter sets
    N = len(P_hull)
    if DEBUG:
        print("Starting enhanced optimization with different random seeds and parameter sets...")
        print(f"Target: Select {num_points} points from {N} hull points")
        if use_simple_pso:
            print("🔧 USE_SIMPLE_PSO enabled: Will use Simple PSO (discrete selection)")
        else:
            print("📊 Using Standard PSO (continuous optimization with rounding)")
    
    # Different parameter configurations to try
    # Custom PSO parameters are now passed directly as function arguments
    
    # If custom parameters are provided, use them
    if any([custom_swarm_size, custom_max_iterations, custom_inertia_weight, 
            custom_cognitive_coef, custom_social_coef]):
        # Use custom parameters (with defaults if not specified)
        param_configs = [{
            "swarm_size": custom_swarm_size or 300,
            "max_iterations": custom_max_iterations or 100,
            "w": custom_inertia_weight or 0.9,
            "c1": custom_cognitive_coef or 2.0,
            "c2": custom_social_coef or 2.0
        }]
        # Use custom number of runs if specified, otherwise default to 3 for thorough search
        max_random_states = num_pso_runs if num_pso_runs is not None else 3
        if DEBUG:
            print("🔧 CUSTOM PSO PARAMETERS:")
            print(f"   Swarm size: {param_configs[0]['swarm_size']}")
            print(f"   Max iterations: {param_configs[0]['max_iterations']}")
            print(f"   Inertia weight: {param_configs[0]['w']}")
            print(f"   Cognitive coef (c1): {param_configs[0]['c1']}")
            print(f"   Social coef (c2): {param_configs[0]['c2']}")
            print(f"   Number of PSO runs: {max_random_states}")
            print(f"   Adaptive inertia: {'Enabled' if use_adaptive_inertia else 'Disabled (constant weight)'}")
            print(f"   MATLAB-style enhancements: {'Enabled' if matlab_style_pso else 'Disabled'}")
            if matlab_style_pso:
                print(f"      - 20% velocity limit (vs 50%)")
                print(f"      - Stratified initialization")
                if adaptive_coefficients:
                    print(f"      - Adaptive c1/c2 coefficients")
            print(f"   PSO variant: {'DISCRETE (no gap)' if use_discrete_pso else 'CONTINUOUS (with rounding)'}")
    elif fast_search_mode:
        # Adaptive parameters based on target ratio for speed optimization
        target_ratio = goal_ratio - 10  # Infer actual target from goal
        if target_ratio <= 30:
            # Ultra-fast for very low targets  
            param_configs = [
                {"swarm_size": 50, "max_iterations": 20, "w": 0.9, "c1": 2.0, "c2": 2.0},
            ]
            max_random_states = 1
            print("⚡ ULTRA-FAST MODE: Minimal parameters for very low target ratios")
        elif target_ratio <= 50:
            # Balanced-fast for low targets (still needs to find solutions!)
            param_configs = [
                {"swarm_size": 100, "max_iterations": 50, "w": 0.9, "c1": 2.0, "c2": 2.0},
            ]
            max_random_states = 1
            print("⚡ BALANCED-FAST MODE: Optimized parameters for low target ratios")
        elif target_ratio <= 70:
            # Fast for medium targets
            param_configs = [
                {"swarm_size": 150, "max_iterations": 60, "w": 0.9, "c1": 2.0, "c2": 2.0},
            ]
            max_random_states = 1
            print("🚀 SPEED MODE: Reduced parameters for medium target ratios")
        else:
            # Balanced for high targets (need more precision)
            param_configs = [
                {"swarm_size": 200, "max_iterations": 75, "w": 0.9, "c1": 2.0, "c2": 2.0},
            ]
            max_random_states = 2
            print("🚀 FAST SEARCH MODE: Balanced parameters for high target ratios")
        
        # Override with custom num_pso_runs if specified
        if num_pso_runs is not None:
            max_random_states = num_pso_runs
            if DEBUG:
                print(f"   🔧 Overriding to {num_pso_runs} PSO runs (custom)")
    else:
        # Full parameters for final optimization (more accurate)
        param_configs = [
            {"swarm_size": 300, "max_iterations": 100, "w": 0.9, "c1": 2.0, "c2": 2.0},  # Balanced
            {"swarm_size": 200, "max_iterations": 120, "w": 0.8, "c1": 2.5, "c2": 1.5},  # Exploitation focused
        ]
        max_random_states = 3  # 3 random states for thoroughness
        
        # Override with custom num_pso_runs if specified
        if num_pso_runs is not None:
            max_random_states = num_pso_runs
            if DEBUG:
                print(f"   🔧 Using {num_pso_runs} PSO runs (custom override)")
    
    # Initialize optimization variables
    opt_ratio = 0
    opt_best_idx = None
    run_count = 0
    for ii in range(max_random_states):  # ✅ FIX: Start at 0, not 1
        for config_idx, config in enumerate(param_configs):
            run_count += 1
            if DEBUG:
                print(f"\n================Run {run_count}: Random state: {ii}, Config: {config_idx+1}================")
                print(f"Config: {config}")
            
            # Use configurable seeding strategy (now correct with ii starting at 0)
            if USE_FIXED_SEEDS:
                current_seed = base_seed + ii * 10 + config_idx  # Predictable but different seeds
            else:
                current_seed = base_seed + ii * 100 + config_idx * 10  # More spread for time-based
            
            if DEBUG:
                print(f"Current seed: {current_seed} ({'FIXED' if USE_FIXED_SEEDS else 'TIME-BASED'})")
            
            try:
                # Create fitness function closure with predictor data
                def fitness_func(x):
                    return evaluateVolume(x, P_hull[:, 3:])
                
                # Start PSO with current configuration - choose PSO method
                if use_simple_pso:
                    # Use simple PSO with uniqueness enforcement
                    x_best, fval = particle_swarm_optimization_simple(
                        fitness_func, num_points,
                        lb=0,
                        ub=N-1,
                        N=N,
                        swarm_size=config.get('swarm_size', 300),
                        max_iterations=config.get('max_iterations', 200),
                        w=config.get('w', 0.7),
                        c1=config.get('c1', 2.0),
                        c2=config.get('c2', 2.0),
                        use_fixed_seeds=USE_FIXED_SEEDS,
                        debug_seed=current_seed
                    )
                else:
                    # Use standard PSO (original method)
                    x_best, fval = particle_swarm_optimization(
                        fitness_func, num_points, 
                        lb=np.zeros(num_points), 
                        ub=np.full(num_points, N-1),
                        **config,
                        use_adaptive_params=True,
                        use_fixed_seeds=USE_FIXED_SEEDS,
                        debug_seed=current_seed
                    )
                
                # Get results with better handling
                if x_best is None:
                    if DEBUG:
                        print("PSO returned None result, skipping...")
                    continue
                
                # For simple PSO, indices are already integers and should be unique
                if use_simple_pso:
                    best_idx = x_best.astype(int)
                else:
                    best_idx = np.unique(np.round(x_best).astype(int))
                
                # Apply local search improvement (hill climbing) - optional
                if enable_local_search:
                    if DEBUG:
                        print("Applying local search refinement...")
                    current_fitness = fval
                    improved = True
                    local_iterations = 0
                    max_local_iterations = 300
                    
                    while improved and local_iterations < max_local_iterations:
                        improved = False
                        local_iterations += 1
                        
                        # Try swapping each selected point with unselected points
                        if len(best_idx) > 0:
                            unselected = list(set(range(N)) - set(best_idx))
                            
                            if len(unselected) > 0:
                                for i, selected_point in enumerate(best_idx):
                                    # Try fewer random unselected points
                                    n_candidates = min(4, len(unselected))  # Reduced from 3
                                    if n_candidates > 0:
                                        candidates = np.random.choice(unselected, n_candidates, replace=False)
                                        
                                        for candidate in candidates:
                                            # Create new solution by swapping
                                            test_idx = best_idx.copy()
                                            test_idx[i] = candidate
                                            
                                            # Create position array for fitness evaluation
                                            test_pos = np.zeros(num_points)
                                            test_pos[:len(test_idx)] = test_idx
                                            
                                            test_fitness = fitness_func(test_pos)
                                            
                                            if test_fitness < current_fitness:
                                                best_idx[i] = candidate
                                                current_fitness = test_fitness
                                                improved = True
                                                
                                                # Update unselected list
                                                unselected.remove(candidate)
                                                unselected.append(selected_point)
                                                break
                        
                        if local_iterations % 5 == 0 and improved:  # Reduced frequency
                            if DEBUG:
                                print(f"Local search iteration {local_iterations}, fitness improved to {current_fitness:.6f}")
                    
                    if DEBUG:
                        print(f"Local search completed after {local_iterations} iterations")
                    
                    # Update final fitness value
                    fval = current_fitness
                else:
                    if DEBUG:
                        print("Local search disabled, using PSO solution directly")
                
                # Handle point count based on allow_fewer_points setting
                if DEBUG:
                    print(f"PSO found {len(best_idx)} unique indices (target: {num_points})")
                
                if len(best_idx) < num_points:
                    if allow_fewer_points:
                        if DEBUG:
                            print(f"✅ Accepting {len(best_idx)} points (allow_fewer_points=True)")
                        # Check if we have enough points for convex hull
                        min_points_needed = P_hull.shape[1] - 3 + 1  # predictor dimensions + 1
                        if len(best_idx) < min_points_needed:
                            if DEBUG:
                                print(f"❌ Error: {len(best_idx)} points insufficient for {P_hull.shape[1]-3}D convex hull (need {min_points_needed})")
                            continue  # Skip this attempt
                    else:
                        if DEBUG:
                            print(f"⚠️  Warning: Only {len(best_idx)} unique indices found, need {num_points}")
                            print(f"🔧 Padding with random additional indices (allow_fewer_points=False)")
                        # Pad with random additional indices if needed
                        remaining_indices = list(set(range(N)) - set(best_idx))
                        additional_needed = min(num_points - len(best_idx), len(remaining_indices))
                        if len(remaining_indices) > 0:
                            if USE_FIXED_SEEDS:
                                np.random.seed(current_seed + 1000)  # Reproducible padding
                            additional_indices = np.random.choice(remaining_indices, additional_needed, replace=False)
                            best_idx = np.concatenate([best_idx, additional_indices])
                            if DEBUG:
                                print(f"📊 Padded to {len(best_idx)} points")
                
                # Truncate if we have too many (only when padding was used)
                if len(best_idx) > num_points and not allow_fewer_points:
                    best_idx = best_idx[:num_points]
                    if DEBUG:
                        print(f"✂️  Truncated to {num_points} points")
                
                if DEBUG:
                    print(f"📊 Final selection: {len(best_idx)} indices")
                
                final_points = P_hull[best_idx]
                
                # Calculate volume and ratio
                final_hull = ConvexHull(final_points[:, 3:])
                V_final = final_hull.volume
                ratio = 100 * V_final / V_full
                if DEBUG:
                    print(f'Final Volume: {V_final:.6f} ({ratio:.3f}% of original Volume)')
                    print(f'Selected {len(best_idx)} points, PSO fitness: {fval:.6f}, Ratio: {ratio:.3f}%')
                
                if opt_ratio < ratio:
                    opt_best_idx = best_idx
                    opt_ratio = ratio
                    if DEBUG:
                        print(f'*** New best ratio: {ratio:.3f}% ***')
                    
                    # Aggressive early termination for speed based on goal ratio
                    inferred_target = goal_ratio - 10  # Since goal_ratio is typically target + 10
                    if fast_search_mode:
                        if inferred_target <= 50 and ratio >= inferred_target + 5:  # Low target: stop if exceeded by 5%
                            print(f"⚡ SPEED: Early termination for low target ({ratio:.1f}% >> {inferred_target}%)")
                            break
                        elif inferred_target <= 70 and ratio >= inferred_target + 10:  # Medium target: stop if exceeded by 10%
                            print(f"⚡ SPEED: Early termination for medium target ({ratio:.1f}% >> {inferred_target}%)")
                            break
                        elif ratio >= goal_ratio:  # High target: traditional early termination
                            print(f"Excellent result achieved ({ratio:.3f}%), terminating early")
                            break
                    else:
                        # Traditional early termination for full mode
                        if ratio >= goal_ratio:
                            print(f"Excellent result achieved ({ratio:.3f}%), terminating early")
                            break
                    
            except Exception as e:
                print(f"Error in run {run_count}: {e}")
                continue
        
        # Break outer loop too if excellent result found
        if opt_ratio >= goal_ratio:
            break
    
    if opt_best_idx is not None:
        opt_grid_cells = P_hull[opt_best_idx, :2]
        if DEBUG:
            print(f"\nOptimal solution found with {opt_ratio:.2f}% volume preservation")
            print(f"Selected {len(opt_best_idx)} grid cells")
        
        # Verify all selected cells are segment-covered
        selected_coords = set(tuple(cell) for cell in opt_grid_cells)
        verified_count = len(selected_coords & pm_coords)
        if DEBUG:
            print(f"✅ Verification: {verified_count}/{len(opt_best_idx)} selected cells are segment-covered")
        
        # Save optimal grid cells
        optimal_cells_path = os.path.join(transient_dir, f'optimal_grid_cells_{num_points}_filtered_bbox.json')
        
        # Prepare data for JSON output
        output_data = {}
        
        # Add execution summary if requested
        if include_summary and mode and start_time is not None:
            end_time = time.time()
            summary_data = create_summary_data(
                mode=mode,
                start_time=start_time,
                end_time=end_time,
                num_points=num_points,
                goal_ratio=goal_ratio,
                achieved_ratio=opt_ratio,
                use_fixed_seeds=use_fixed_seeds,
                debug_seed=debug_seed,
                allow_fewer_points=allow_fewer_points,
                predictor_filename=predictor_filename,
                route_filename=route_filename,
                pm_output_filename=pm_output_filename,
                membership_csv_filename=membership_csv_filename,
                working_directory=working_directory,
                bbox_filtering_enabled=bbox_filtering_enabled
            )
            output_data.update(summary_data)
        
        # Add the optimal grid cells data
        output_data["optimal_grid_cells"] = opt_grid_cells.tolist()
        output_data["verification"] = {
            "total_selected": len(opt_best_idx),
            "segment_covered": verified_count,
            "all_covered": verified_count == len(opt_best_idx)
        }
        
        with open(optimal_cells_path, 'w') as f:
            json.dump(output_data, f, indent=2)
        if DEBUG:
            print(f"Saved optimal grid cells to {optimal_cells_path}")
            print(f"JSON includes: {'Summary + ' if include_summary else ''}Grid cells data + Verification")

        if return_ratio:
            return opt_grid_cells, opt_ratio
        else:
            return opt_grid_cells
    else:
        if DEBUG:
            print("No valid solution found")
        if return_ratio:
            return None, None
        else:
            return None


if __name__ == "__main__":
    # Default parameters - can be overridden when calling the function directly
    working_directory = 'work_dir/test_john'
    
    print("🔧 RUNNING MODE: single + FILTERING + BBOX")
    print("📍 Executing: Single optimization mode with segment + bbox filtering")
    
    # Auto-detect membership CSV file in working directory
    membership_csv_filename = None

    if os.path.exists(working_directory):
        # Look for .csv or .txt files that might be membership files
        for filename in os.listdir(working_directory):
            # Skip known non-membership files
            if filename in ['predictors.txt', 'points.csv']:
                continue
            # Look for CSV or TXT files with "membership" or "FCM" in name, or exactly "converted.csv"
            if (filename.endswith('.csv') or filename.endswith('.txt')) and \
               ('membership' in filename.lower() or 'fcm' in filename.lower() or 
                'cl_' in filename.lower() or filename.lower() == 'converted.csv'):
                membership_csv_filename = filename
                print(f"📋 Auto-detected membership file: {filename}")
                break
        
        if membership_csv_filename is None:
            print("⚠️  No membership CSV file auto-detected, bbox filtering disabled")
    
    # Original single optimization
    num_points = 10 # default 50
    goal_ratio = 100.0
    use_fixed_seeds = False  # Set to True for reproducible results, False for variation
    debug_seed = 42
    predictor_filename = 'predictors.csv'
    route_filename = 'initial_route.json'
    pm_output_filename = 'pm_output.json'
    # membership_csv_filename is auto-detected above - Set to None to disable bbox filtering
    allow_fewer_points = True  # Set to True to accept fewer points if PSO finds that optimal
    use_simple_pso = False  # Set to True to use simplified PSO with uniqueness enforcement
    enable_bbox_filter = True  # Enable bbox filtering based on membership CSV
    print(f"📝 Point handling: {'Allow fewer points' if allow_fewer_points else 'Pad to exact count'}")
    print(f"📋 Membership CSV: {membership_csv_filename if membership_csv_filename else 'None (bbox filter disabled)'}")
    print(f"🔬 PSO Method: {'Simple (unique indices)' if use_simple_pso else 'Standard (may have duplicates)'}")
    
    # Print initial summary (before execution)
    start_time = time.time()
    print_execution_summary(
        mode='single',
        start_time=start_time,
        end_time=start_time,  # Will be updated later
        num_points=num_points,
        goal_ratio=goal_ratio,
        achieved_ratio=None,  # Will be updated later
        use_fixed_seeds=use_fixed_seeds,
        debug_seed=debug_seed,
        working_directory=working_directory,
        predictor_filename=predictor_filename,
        route_filename=route_filename,
        pm_output_filename=pm_output_filename,
        membership_csv_filename=membership_csv_filename
    )
    
    # Start actual optimization
    result = hpe_optimization(
        working_directory=working_directory,
        num_points=num_points,
        goal_ratio=goal_ratio,
        use_fixed_seeds=use_fixed_seeds,
        debug_seed=debug_seed,
        predictor_filename=predictor_filename,
        route_filename=route_filename,
        pm_output_filename=pm_output_filename,
        membership_csv_filename=membership_csv_filename,
        enable_bbox_filter=enable_bbox_filter,  # Can be changed to False to disable bbox filtering
        return_ratio=True,  # Get both grid cells and achieved ratio
        allow_fewer_points=allow_fewer_points,
        use_simple_pso=use_simple_pso,  # Choose PSO method
        include_summary=True,  # Include summary in JSON output
        mode='single',
        start_time=start_time,
        # Pass custom PSO parameters if specified
        custom_swarm_size=custom_swarm_size,
        custom_max_iterations=custom_max_iterations,
        custom_inertia_weight=custom_inertia_weight,
        custom_cognitive_coef=custom_cognitive_coef,
        custom_social_coef=custom_social_coef,
        num_pso_runs=num_pso_runs,
        use_adaptive_inertia=use_adaptive_inertia,
        use_discrete_pso=use_discrete_pso,
        enable_local_search=enable_local_search,
        matlab_style_pso=matlab_style_pso,
        adaptive_coefficients=adaptive_coefficients
    )
    
    # End timing and print final summary
    end_time = time.time()
    
    # Extract achieved ratio from result
    achieved_ratio = None
    if result is not None:
        if isinstance(result, tuple) and len(result) == 2:
            grid_cells, achieved_ratio = result
        else:
            achieved_ratio = None  # Fallback if format unexpected
    
    print("\n" + "="*80)
    print("🏁 FINAL RESULTS SUMMARY")
    print("="*80)
    
    # Show detailed timing
    runtime = end_time - start_time
    start_readable = datetime.fromtimestamp(start_time).strftime('%Y-%m-%d %H:%M:%S')
    end_readable = datetime.fromtimestamp(end_time).strftime('%Y-%m-%d %H:%M:%S')
    
    print(f"🕐 Started: {start_readable}")
    print(f"🕐 Finished: {end_readable}")
    print(f"⏱️  Total Runtime: {runtime:.2f} seconds ({runtime/60:.2f} minutes)")
    if runtime >= 60:
        hours = runtime // 3600
        minutes = (runtime % 3600) // 60
        seconds = runtime % 60
        if hours > 0:
            print(f"⏱️  Detailed Time: {int(hours)}h {int(minutes)}m {seconds:.1f}s")
        else:
            print(f"⏱️  Detailed Time: {int(minutes)}m {seconds:.1f}s")
    
    print(f"📊 Points Tested: {num_points}")
    print(f"🎯 Target Ratio: {goal_ratio:.1f}%")
    if achieved_ratio is not None:
        print(f"📈 Achieved Ratio: {achieved_ratio:.1f}%")
        if achieved_ratio >= goal_ratio * 0.9:  # Within 90% of target
            print("✅ SUCCESS: Target achieved!")
        else:
            print("⚠️  PARTIAL: Below target ratio")
    else:
        print("❌ FAILED: No valid solution found")
    print("="*80)
    
    print("\n✨ Done!")
