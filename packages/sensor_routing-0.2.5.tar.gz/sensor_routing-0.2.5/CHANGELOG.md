# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.2.5] - 2026-02-18

### Added
- **Constants module**: New `sensor_routing/constants.py` for centralized filename management
- **Standardized filenames**: `ROUTE_FILENAME = "solution.json"` added to constants

### Changed
- **Simplified directory structure**: Input files (`predictors.csv`, `memberships.csv`, `osm_data_transformed.geojson`) now in working directory root instead of `input/` subdirectory
- **Harmonized with cosmonaut**: Project structure aligned with external standards
- **File path handling**: All modules now expect absolute `working_directory` paths
- **Output locations**: `initial_route.json` and `solution.json` now saved to appropriate directories
- **Test data organization**: Moved from `test_data/input/` to `test_data/` directly
- **Import organization**: Improved import statements in `full_pipeline_cli.py`

### Fixed
- **Debug output**: Abort time in `path_finding.py` now only prints when DEBUG=True
- **Error handling**: Removed unnecessary try-except wrapper in `full_sensor_routing_pipeline()`

### Removed
- **Metadata cleanup**: Deleted auto-generated `sensor_routing.egg-info/` files from version control

## [0.2.4] - 2025-02-13

### Added
- **Input file constants exported**: `PREDICTOR_FILENAME`, `MEMBERSHIP_FILENAME`, `OSM_FILENAME`, `PARAMETERS_FILENAME` now available in public API
- **OSM filename constant**: Added `OSM_FILENAME = "osm_data_transformed.geojson"` to standardize road network file naming
- **OSM file description**: Added `DESCRIPTION_OSM` with format requirements and CRS compatibility notes
- **OSM validation**: Added validation check for OSM file existence in `sensor_routing_pipeline()`

### Changed
- **Updated documentation**: README now shows correct OSM filename (`osm_data_transformed.geojson`)
- **Working directory structure**: Updated to reflect standardized OSM filename
- **API examples**: Updated modular API example to use correct OSM filename
- **Exported constants**: All filename constants now accessible via `from sensor_routing import PREDICTOR_FILENAME, ...`

### Fixed
- **Consistent naming**: All references to OSM file now use standardized name across documentation

## [0.2.3] - 2025-02-12

### Added
- **Standardized input file names**: `predictors.csv` and `memberships.csv` constants
- **Comprehensive input validation**: Added parser functions for predictor and membership files
  - `parse_predictor_file()`: Validates CSV format, handles NaN values, detects headers/delimiters
  - `parse_membership_file()`: Validates membership probabilities, coordinate consistency
  - `validate_predictor_membership_consistency()`: Cross-validates coordinate matching
- **Automatic delimiter detection**: Supports comma, tab, and whitespace-separated CSV files
- **Flexible header detection**: Auto-detects presence of headers vs numeric data
- **Set-based coordinate validation**: O(n) performance for large datasets
- **Detailed error messages**: Clear explanations when validation fails with sample data
- **Simplified API entry point**: `sensor_routing_pipeline(work_dir)` function
  - Single parameter interface (work directory only)
  - Auto-loads parameters.json (creates with defaults if missing)
  - Validates all input files before processing
- **File format descriptions**: `DESCRIPTION_PREDICTOR` and `DESCRIPTION_MEMBERSHIP` constants
- **Exported main function**: Added `sensor_routing_pipeline` to package `__all__`

### Changed
- **Point mapping**: Now uses standardized `memberships.csv` filename
- **Input validation**: More flexible - allows predictor to have extra rows with NaN values
- **Coordinate validation**: Order-independent matching using set-based comparison
- **Error handling**: Improved error messages showing missing coordinates with row numbers
- **Debug output**: Enhanced with column name display for better clarity

### Fixed
- **NaN handling**: Correctly excludes predictor rows with NaN from validation
- **Delimiter detection**: Fixed parsing of space-separated scientific notation values
- **Duplicate parsing**: Removed redundant file parsing in validation workflow
- **Column naming**: Predictor columns now correctly labeled as "Predictor" not "Cluster"

## [0.2.0] - 2024-11-10

### Added
- Comprehensive debug control system with `DEBUG` flags in all modules
- Debug file output control (all debug files now respect DEBUG flag)
- Progress bar control (tqdm now respects DEBUG flag)
- Economic routing variants (econ_mapping, econ_benefit, econ_paths, econ_route)
- Pydantic V2 support with ConfigDict
- Complete PyPI packaging support
- Proper `__init__.py` with version and metadata
- Comprehensive README.md with usage examples
- LICENSE file (EUPL-1.2)
- MANIFEST.in for proper package distribution
- Development dependencies in pyproject.toml

### Changed
- Migrated from Poetry to modern setuptools with pyproject.toml
- Updated requirements.txt with all missing dependencies (scipy, scikit-learn, pydantic, tqdm)
- Organized requirements by category with comments
- Changed version constraints from `==` to `>=` for better compatibility
- Updated pyproject.toml with complete metadata and classifiers
- Improved setup.py with proper package metadata

### Fixed
- All debug terminal prints now respect DEBUG flag (10 modules)
- All debug file outputs now respect DEBUG flag (16+ files)
- tqdm progress bars now conditional on DEBUG flag
- Pydantic V2 deprecation warning (migrated to ConfigDict)
- Missing dependencies in requirements.txt

### Removed
- Removed unused debug_config.py file
- Cleaned up orphaned debug infrastructure

## [0.1.15] - 2024-09-18

### Added
- Initial release with basic routing functionality
- Point mapping to road networks
- Benefit calculation for route segments
- Path finding with Dijkstra algorithm
- Route optimization with ACO (Ant Colony Optimization)
- Hull points extraction for optimal sensor placement
- OpenStreetMap integration via OSMnx
- Geospatial data processing with GeoPandas

### Features
- Support for EPSG:25832 and EPSG:31468 coordinate systems
- Network-based routing with real road data
- Information value maximization
- Convex hull analysis
- Command-line interface

## [Unreleased]

### Planned
- Unit tests with pytest
- Continuous integration setup
- Performance optimizations
- Additional routing algorithms
- Web-based visualization tools
- API documentation with Sphinx
- Example notebooks
- Docker containerization

---

## Version History

- **0.2.0** - PyPI-ready release with complete packaging
- **0.1.15** - Initial functional release
