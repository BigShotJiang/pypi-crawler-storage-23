import os
import glob
import shutil


from sensor_routing.full_pipeline_cli import (
    full_sensor_routing_pipeline,
    FullPipelineConfig,
)


def test_full_sensor_routing_pipeline():
    """Test that the full pipeline runs successfully with default config."""
    import traceback
    
    input_files = ["test_memberships.csv", "osm_data_transformed.geojson"]
    try:
        config = FullPipelineConfig(
            working_directory="./sensor_routing/test_data/",
            segment_number=1,
            lower_benefit_limit=0.1,
            time_limit=80,
            optimization_objective="d",
            max_aco_iteration=50,
            ant_no=500,
            is_reversed=False,
            max_distance=50,
            benefit_type="t",
            route_type="g",
            num_points=50,
            goal_ratio=100.0,
            use_fixed_seeds=False,
            debug_seed=42,
            allow_fewer_points=True,
        )
        result = full_sensor_routing_pipeline(config)
        if not result:
            print("\n⚠️ Pipeline returned False - check the error message above")
        assert result is True
        # TODO make better assertions based on expected output files
    finally:
        files = glob.glob("./sensor_routing/test_data/output/*")
        for f in files:
            for input_file in input_files:
                if input_file in f:
                    continue
            if os.path.isfile(f):
                os.remove(f)
            else:
                shutil.rmtree(f)
