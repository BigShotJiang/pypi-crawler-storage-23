# 会话摘要

**Session ID:** {session_id}
**时间:** {YYYY-MM-DD HH:MM}
**项目:** {project_name}
**模式:** {工作流 / 对话}

## 做了什么
- {主要活动描述}

## 关键决策
- {决策及理由}

## 未完成
- {待完成事项}
