import importlib.metadata

from virtualitics_cli.virtualitics_cli import APP_NAME

__version__ = importlib.metadata.version(APP_NAME)
