"""
PredictionResult and PredictionFeedback classes.

These classes represent prediction results and the feedback mechanism
for improving model accuracy.
"""

from dataclasses import dataclass, field
from datetime import datetime
from typing import Dict, Any, Optional, Union, TYPE_CHECKING

if TYPE_CHECKING:
    from .http_client import ClientContext


@dataclass
class PredictionResult:
    """
    Represents a prediction result with full metadata.

    Attributes:
        prediction_uuid: Unique identifier for this prediction (use for feedback)
        prediction: Raw prediction result (class probabilities or numeric value)
        predicted_class: Predicted class name (for classification)
        confidence: Confidence score (for classification)
        probabilities: Full probability distribution (for classification)
        threshold: Classification threshold (for binary classification)
        query_record: Original input record
        predictor_id: ID of predictor that made this prediction
        session_id: Session ID (internal)
        timestamp: When prediction was made
        target_column: Target column name
        guardrails: Per-column guardrail warnings (if any)
        ignored_query_columns: Columns in input that were not used (not in training data)
        available_query_columns: All columns the model knows about

    Usage:
        result = predictor.predict({"age": 35, "income": 50000})
        print(result.predicted_class)  # "churned"
        print(result.confidence)       # 0.87
        print(result.prediction_uuid)  # UUID for feedback

        # Check for guardrail warnings
        if result.guardrails:
            print(f"Warnings: {len(result.guardrails)} columns with issues")

        # Check for ignored columns
        if result.ignored_query_columns:
            print(f"Ignored: {result.ignored_query_columns}")

        # Send feedback if prediction was wrong
        if result.predicted_class != actual_label:
            feedback = result.send_feedback(ground_truth=actual_label)
            feedback.send()
    """

    prediction_uuid: Optional[str] = None
    prediction: Optional[Union[Dict[str, float], float]] = None
    predicted_class: Optional[str] = None
    probability: Optional[float] = None
    confidence: Optional[float] = None
    probabilities: Optional[Dict[str, float]] = None
    threshold: Optional[float] = None
    query_record: Optional[Dict[str, Any]] = None

    # Documentation fields - explain what prediction/probability/confidence mean
    readme_prediction: str = field(default="The predicted class label (for classification) or value (for regression).")
    readme_probability: str = field(default="Raw probability of the predicted class from the model's softmax output.")
    readme_confidence: str = field(default=(
        "For binary classification: normalized margin from threshold. "
        "confidence = (prob - threshold) / (1 - threshold) if predicting positive, "
        "or (threshold - prob) / threshold if predicting negative. "
        "Ranges from 0 (at decision boundary) to 1 (maximally certain). "
        "For multi-class: same as probability."
    ))
    readme_threshold: str = field(default=(
        "Decision boundary for binary classification. "
        "If P(positive_class) >= threshold, predict positive; otherwise predict negative. "
        "Calibrated to optimize F1 score on validation data."
    ))
    readme_probabilities: str = field(default=(
        "Full probability distribution across all classes from the model's softmax output. "
        "Dictionary mapping class labels to their probabilities (sum to 1.0)."
    ))
    readme_pos_label: str = field(default=(
        "The class label considered 'positive' for binary classification metrics. "
        "Threshold and confidence calculations are relative to this class."
    ))
    predictor_id: Optional[str] = None
    session_id: Optional[str] = None
    target_column: Optional[str] = None
    timestamp: Optional[datetime] = None
    model_version: Optional[str] = None

    # Checkpoint info from the model (epoch, metric_type, metric_value)
    checkpoint_info: Optional[Dict[str, Any]] = None

    # Guardrails and warnings
    guardrails: Optional[Dict[str, Any]] = None
    ignored_query_columns: Optional[list] = None
    available_query_columns: Optional[list] = None

    # Feature importance (from leave-one-out ablation)
    feature_importance: Optional[Dict[str, float]] = None

    # Internal: client context for sending feedback
    _ctx: Optional['ClientContext'] = field(default=None, repr=False)

    @classmethod
    def from_response(
        cls,
        response: Dict[str, Any],
        query_record: Dict[str, Any],
        ctx: Optional['ClientContext'] = None
    ) -> 'PredictionResult':
        """
        Create PredictionResult from API response.

        Args:
            response: API response dictionary
            query_record: Original query record
            ctx: Client context for feedback

        Returns:
            PredictionResult instance
        """
        # Extract prediction data - handle both formats
        # New format: prediction is the class label, probabilities is separate
        # Old format: prediction is the probabilities dict
        prediction = response.get('prediction')
        probabilities = response.get('probabilities')
        predicted_class = response.get('predicted_class')
        probability = response.get('probability')
        confidence = response.get('confidence')

        # For old format where prediction is the probabilities dict
        if isinstance(prediction, dict) and not probabilities:
            probabilities = prediction
            if prediction:
                predicted_class = max(prediction.keys(), key=lambda k: prediction[k])
                probability = prediction[predicted_class]
                confidence = probability  # Old format: confidence = probability
        elif isinstance(prediction, str) and not predicted_class:
            # New format: prediction is already the class label
            predicted_class = prediction

        return cls(
            prediction_uuid=response.get('prediction_uuid') or response.get('prediction_id'),
            prediction=prediction,
            predicted_class=predicted_class,
            probability=probability,
            confidence=confidence,
            probabilities=probabilities,
            threshold=response.get('threshold'),
            query_record=query_record,
            predictor_id=response.get('predictor_id'),
            session_id=response.get('session_id'),
            target_column=response.get('target_column'),
            timestamp=datetime.now(),
            model_version=response.get('model_version'),
            checkpoint_info=response.get('checkpoint_info'),
            guardrails=response.get('guardrails'),
            ignored_query_columns=response.get('ignored_query_columns'),
            available_query_columns=response.get('available_query_columns'),
            _ctx=ctx,
        )

    def send_feedback(self, ground_truth: Union[str, float]) -> 'PredictionFeedback':
        """
        Create a feedback object for this prediction.

        Args:
            ground_truth: The correct label/value

        Returns:
            PredictionFeedback object (call .send() to submit)

        Raises:
            ValueError: If prediction_uuid is not available
        """
        if not self.prediction_uuid:
            raise ValueError(
                "Cannot send feedback: prediction_uuid not available. "
                "The server may not have returned a prediction_uuid for this prediction."
            )

        return PredictionFeedback(
            prediction_uuid=self.prediction_uuid,
            ground_truth=ground_truth,
            _ctx=self._ctx,
        )

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary representation."""
        result = {
            'prediction_uuid': self.prediction_uuid,
            'prediction': self.prediction,
            'predicted_class': self.predicted_class,
            'probability': self.probability,
            'confidence': self.confidence,
            'probabilities': self.probabilities,
            'threshold': self.threshold,
            'query_record': self.query_record,
            'predictor_id': self.predictor_id,
            'session_id': self.session_id,
            'target_column': self.target_column,
            'timestamp': self.timestamp.isoformat() if self.timestamp else None,
            'model_version': self.model_version,
            # Documentation
            'readme_prediction': self.readme_prediction,
            'readme_probability': self.readme_probability,
            'readme_confidence': self.readme_confidence,
            'readme_threshold': self.readme_threshold,
            'readme_probabilities': self.readme_probabilities,
            'readme_pos_label': self.readme_pos_label,
        }
        # Include checkpoint_info if present
        if self.checkpoint_info:
            result['checkpoint_info'] = self.checkpoint_info
        # Include guardrails if present
        if self.guardrails:
            result['guardrails'] = self.guardrails
        if self.ignored_query_columns:
            result['ignored_query_columns'] = self.ignored_query_columns
        if self.available_query_columns:
            result['available_query_columns'] = self.available_query_columns
        if self.feature_importance:
            result['feature_importance'] = self.feature_importance
        return result


@dataclass
class PredictionFeedback:
    """
    Represents feedback (ground truth) for a prediction.

    Usage:
        # Method 1: From PredictionResult
        result = predictor.predict(record)
        feedback = result.send_feedback(ground_truth="correct_label")
        feedback.send()

        # Method 2: Create directly
        feedback = PredictionFeedback(
            prediction_uuid="123e4567-e89b-12d3-a456-426614174000",
            ground_truth="correct_label"
        )
        feedback.send()

        # Method 3: Create and send in one call
        PredictionFeedback.create_and_send(
            ctx=client_context,
            prediction_uuid="123e4567-...",
            ground_truth="correct_label"
        )
    """

    prediction_uuid: str
    ground_truth: Union[str, float]
    feedback_timestamp: Optional[datetime] = None

    # Internal: client context for sending
    _ctx: Optional['ClientContext'] = field(default=None, repr=False)

    def send(self) -> Dict[str, Any]:
        """
        Submit feedback to the server.

        Returns:
            Server response

        Raises:
            ValueError: If no client context available
        """
        if not self._ctx:
            raise ValueError(
                "Cannot send feedback: no client context. "
                "Create feedback from a PredictionResult or use create_and_send()."
            )

        self.feedback_timestamp = datetime.now()

        response = self._ctx.post_json(
            f"/compute/prediction/{self.prediction_uuid}/update_label",
            data={"user_label": str(self.ground_truth)}
        )
        return response

    @classmethod
    def create_and_send(
        cls,
        ctx: 'ClientContext',
        prediction_uuid: str,
        ground_truth: Union[str, float]
    ) -> Dict[str, Any]:
        """
        Create and send feedback in one call.

        Args:
            ctx: Client context
            prediction_uuid: UUID of the prediction
            ground_truth: Correct label/value

        Returns:
            Server response
        """
        feedback = cls(
            prediction_uuid=prediction_uuid,
            ground_truth=ground_truth,
            _ctx=ctx,
        )
        return feedback.send()

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary representation."""
        return {
            'prediction_uuid': self.prediction_uuid,
            'ground_truth': self.ground_truth,
            'feedback_timestamp': self.feedback_timestamp.isoformat() if self.feedback_timestamp else None,
        }
