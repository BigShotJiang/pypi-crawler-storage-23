::: marshmallow_generic.schema
