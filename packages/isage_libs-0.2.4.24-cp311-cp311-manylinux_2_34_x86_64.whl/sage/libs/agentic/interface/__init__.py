"""Interface definitions for agentic.

This module defines the abstract interfaces and registries for agentic components.
Concrete implementations are provided by the external package 'isage-agentic'.

Merged modules:
- Intent recognition (from sage.libs.intent)
- Reasoning strategies (from sage.libs.reasoning)
- SIAS (will be in isage-agentic[sias])

Architecture:
- Interface layer (here): Abstract base classes, factory pattern
- Implementation layer (isage-agentic): Concrete implementations

Usage:
    # Import interfaces
    from sage.libs.agentic.interface import BaseAgent, create_agent

    # In isage-agentic, register implementations
    from sage.libs.agentic.interface import register_agent
    register_agent("react", ReactAgent)
"""

from .base import *  # noqa: F401, F403
from .factory import *  # noqa: F401, F403

__all__ = [
    # Base classes
    "AgentAction",  # noqa: F405
    "AgentResult",  # noqa: F405
    "Intent",  # noqa: F405
    "BaseAgent",  # noqa: F405
    "BasePlanner",  # noqa: F405
    "BaseToolSelector",  # noqa: F405
    "BaseOrchestrator",  # noqa: F405
    "IntentRecognizer",  # noqa: F405
    "IntentClassifier",  # noqa: F405
    "BaseReasoningStrategy",  # noqa: F405
    # Factory functions
    "register_agent",  # noqa: F405
    "create_agent",  # noqa: F405
    "list_agents",  # noqa: F405
    "register_planner",  # noqa: F405
    "create_planner",  # noqa: F405
    "list_planners",  # noqa: F405
    "register_tool_selector",  # noqa: F405
    "create_tool_selector",  # noqa: F405
    "list_tool_selectors",  # noqa: F405
    "register_orchestrator",  # noqa: F405
    "create_orchestrator",  # noqa: F405
    "list_orchestrators",  # noqa: F405
    "register_intent_recognizer",  # noqa: F405
    "create_intent_recognizer",  # noqa: F405
    "list_intent_recognizers",  # noqa: F405
    "register_intent_classifier",  # noqa: F405
    "create_intent_classifier",  # noqa: F405
    "list_intent_classifiers",  # noqa: F405
    "register_reasoning_strategy",  # noqa: F405
    "create_reasoning_strategy",  # noqa: F405
    "list_reasoning_strategies",  # noqa: F405
]
