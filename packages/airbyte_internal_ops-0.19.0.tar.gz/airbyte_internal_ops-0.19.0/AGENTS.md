# Agents

See [CONTRIBUTING.md](./CONTRIBUTING.md) for full setup and contribution guidelines.

## Registry Operations

The `GCS_CREDENTIALS` environment variable is required for registry tools that interact with GCS buckets. In CI and agent environments, this credential may be aliased from `GCP_GSM_CREDENTIALS`. The service account should have read/write access to the dev bucket (`dev-airbyte-cloud-connector-metadata-service-2`) used in registry tests.
