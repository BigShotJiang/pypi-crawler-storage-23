# Copyright (c) 2025 Airbyte, Inc., all rights reserved.
"""CLI commands for DockerHub operations.

This module provides CLI wrappers for DockerHub image operations.

Commands:
    airbyte-ops dockerhub inspect-image - Inspect Docker image on DockerHub
"""

from __future__ import annotations

from typing import Annotated

from cyclopts import App, Parameter

from airbyte_ops_mcp.cli._base import app
from airbyte_ops_mcp.cli._shared import (
    print_error,
    print_json,
    print_success,
)
from airbyte_ops_mcp.mcp.github_actions import get_docker_image_info

# Create the dockerhub sub-app
dockerhub_app = App(name="dockerhub", help="DockerHub image operations.")
app.command(dockerhub_app)


@dockerhub_app.command(name="inspect-image")
def inspect_image(
    image: Annotated[
        str,
        Parameter(help="Docker image name (e.g., 'airbyte/source-github')."),
    ],
    tag: Annotated[
        str,
        Parameter(help="Image tag (e.g., '2.1.5-preview.abc1234')."),
    ],
) -> None:
    """Check if a Docker image exists on DockerHub.

    Returns information about the image if it exists, or indicates if it doesn't exist.
    Useful for confirming that a pre-release connector was successfully published.
    """
    result = get_docker_image_info(
        image=image,
        tag=tag,
    )
    if result.exists:
        print_success(f"Image {result.full_name} exists.")
    else:
        print_error(f"Image {result.full_name} not found.")
    print_json(result.model_dump())
