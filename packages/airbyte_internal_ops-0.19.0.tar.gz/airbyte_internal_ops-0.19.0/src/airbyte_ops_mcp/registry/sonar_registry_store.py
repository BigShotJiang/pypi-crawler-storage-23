# Copyright (c) 2025 Airbyte, Inc., all rights reserved.

from __future__ import annotations

from airbyte_ops_mcp.registry.registry_store_base import RegistryStoreBase
from airbyte_ops_mcp.registry.store import StoreTarget


class SonarRegistryStore(RegistryStoreBase):
    """Sonar (S3) implementation of :class:`RegistryStoreBase`.

    Stubbed initially. Methods should be implemented as sonar registry support
    is built out.
    """

    def __init__(self, target: StoreTarget) -> None:
        super().__init__(target)

    def list_connectors(self) -> list[str]:
        raise NotImplementedError(
            f"Operation 'list_connectors' is not implemented for store type '{self.store_type.value}'."
        )
