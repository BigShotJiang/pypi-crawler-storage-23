# Google Ads changelog

## [0.1.1] - 2026-02-25
- Updated connector definition (YAML version 1.0.2)
- Source commit: a55e0595
- SDK version: 0.1.0

## [0.1.0] - 2026-02-23
- Updated connector definition (YAML version 1.0.1)
- Source commit: 8c0db5b1
- SDK version: 0.1.0
