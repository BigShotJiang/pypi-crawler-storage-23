import numpy as np
import torch
from torch import nn
import torch.nn.functional as F
from scE2TM.models.ECR import ECR

def entropy(logit):
    """Calculate entropy loss"""
    logit = logit.mean(dim=0)
    logit_ = torch.clamp(logit, min=1e-9)
    b = logit_ * torch.log(logit_)
    return -b.sum()


def consistency_loss(anchors, neighbors):
    b, n = anchors.size()
    similarity = torch.bmm(anchors.view(b, 1, n), neighbors.view(b, n, 1)).squeeze()
    ones = torch.ones_like(similarity)
    consistency_loss = F.binary_cross_entropy(similarity, ones, reduction='mean') 
    return consistency_loss


class DistillLoss(nn.Module):
    def __init__(self, num_classes, temperature, device):  # MODIFIED: class_num -> num_classes
        super(DistillLoss, self).__init__()
        self.num_classes = num_classes  # MODIFIED: class_num -> num_classes
        self.temperature = temperature
        self.mask = self.mask_correlated_clusters(num_classes).to(device)  # MODIFIED: class_num -> num_classes
        self.criterion = nn.CrossEntropyLoss(reduction="sum")
        self.device = device

    def mask_correlated_clusters(self, num_classes):  # MODIFIED: class_num -> num_classes
        N = 2 * num_classes  # MODIFIED: class_num -> num_classes
        mask = torch.ones((N, N))
        mask = mask.fill_diagonal_(0)
        for i in range(num_classes):  # MODIFIED: class_num -> num_classes
            mask[i, num_classes + i] = 0  # MODIFIED: class_num -> num_classes
            mask[num_classes + i, i] = 0  # MODIFIED: class_num -> num_classes
        mask = mask.bool()
        return mask

    def forward(self, c_i, c_j):
        c_i = c_i.t()
        c_j = c_j.t()
        N = 2 * self.num_classes  # MODIFIED: class_num -> num_classes
        c = torch.cat((c_i, c_j), dim=0)
        c = F.normalize(c, dim=1)
        sim = c @ c.T / self.temperature
        sim_i_j = torch.diag(sim, self.num_classes)  # MODIFIED: class_num -> num_classes
        sim_j_i = torch.diag(sim, -self.num_classes)  # MODIFIED: class_num -> num_classes
        positive_clusters = torch.cat((sim_i_j, sim_j_i), dim=0).reshape(N, 1)
        negative_clusters = sim[self.mask].reshape(N, -1)
        labels = torch.zeros(N).to(positive_clusters.device).long()
        logits = torch.cat((positive_clusters, negative_clusters), dim=1)
        loss = self.criterion(logits, labels) / N
        return loss

# MODIFIED: ClusterHead -> CrossModalClusterHead
class CrossModalClusterHead(nn.Module):
    def __init__(self, input_dim=512, num_clusters=100):  # MODIFIED: in_dim -> input_dim
        super().__init__()
        self.num_clusters = num_clusters
        # MODIFIED: cluster_head_image -> cluster_head, image -> features
        self.cluster_head = nn.Sequential(
            nn.Linear(input_dim, input_dim),
            nn.BatchNorm1d(input_dim),
            nn.Tanh(),
            nn.Linear(input_dim, num_clusters),
        )

    def forward(self, features, return_logits=False):  # MODIFIED: image -> features, flag -> return_logits
        logits = self.cluster_head(features)  # MODIFIED: cluster_head_image -> cluster_head
        if not return_logits:  # MODIFIED: flag -> return_logits
            logits = F.softmax(logits, dim=1)
        return logits

# MODIFIED: ECRTM -> scE2TM
class scE2TM(nn.Module):
    def __init__(self, args):
        super().__init__()
        self.device = args.device  # MODIFIED: 使用args.device
        self.args = args
        self.beta_temp = args.beta_temp

        # MODIFIED: a -> prior_alpha
        self.prior_alpha = 1 * np.ones((1, args.num_topics)).astype(np.float32)
        # MODIFIED: mu2 -> prior_mu
        self.prior_mu = nn.Parameter(torch.as_tensor((np.log(self.prior_alpha).T - np.mean(np.log(self.prior_alpha), 1)).T))
        # MODIFIED: var2 -> prior_var
        self.prior_var = nn.Parameter(torch.as_tensor((((1.0 / self.prior_alpha) * (1 - (2.0 / args.num_topics))).T + (1.0 / (args.num_topics * args.num_topics)) * np.sum(1.0 / self.prior_alpha, 1)).T))

        self.prior_mu.requires_grad = False  # MODIFIED: mu2 -> prior_mu
        self.prior_var.requires_grad = False  # MODIFIED: var2 -> prior_var
        
        # MODIFIED: 更清晰的命名
        self.encoder_fc1 = nn.Linear(args.vocab_size, args.en1_units)  # fc11 -> encoder_fc1
        self.encoder_fc2 = nn.Linear(args.en1_units, args.en1_units)  # fc12 -> encoder_fc2
        self.encoder_mu = nn.Linear(args.en1_units, args.num_topics)  # fc21 -> encoder_mu
        self.encoder_logvar = nn.Linear(args.en1_units, args.num_topics)  # fc22 -> encoder_logvar
        
        # MODIFIED: TAC1 -> cross_modal_cluster_head
        self.cross_modal_cluster_head = CrossModalClusterHead(  # ClusterHead -> CrossModalClusterHead
            input_dim=512,  # in_dim -> input_dim
            num_clusters=args.num_topics
        )
        
        # MODIFIED: distill_loss 使用 num_classes
        self.distill_loss = DistillLoss(
            num_classes=args.num_topics,  # class_num -> num_classes
            temperature=0.5, 
            device=args.device
        ) 

        self.encoder_dropout = nn.Dropout(args.dropout)  # fc1_dropout -> encoder_dropout
        self.classifier = nn.Sequential(  # cla -> classifier
            nn.Softmax(dim=1)
        )
        self.encoder = nn.Sequential(  # enc -> encoder
            nn.Linear(args.vocab_size, args.en1_units),
            nn.BatchNorm1d(args.en1_units),
            nn.Tanh(),
            nn.Linear(args.en1_units, args.en1_units),
        )

        self.mean_bn = nn.BatchNorm1d(args.num_topics)
        self.logvar_bn = nn.BatchNorm1d(args.num_topics)
        self.decoder_bn = nn.BatchNorm1d(args.vocab_size)

        # MODIFIED: word_embeddings -> gene_embeddings
        self.gene_embeddings = torch.from_numpy(args.gene_embeddings).float()
        self.gene_embeddings = nn.Parameter(F.normalize(self.gene_embeddings))

        self.topic_embeddings = torch.empty((args.num_topics, self.gene_embeddings.shape[1]))
        nn.init.trunc_normal_(self.topic_embeddings, std=0.02)
        self.topic_embeddings = nn.Parameter(F.normalize(self.topic_embeddings))

        self.ecr_loss = ECR(self.args.weight_loss_ECR)  # ECR -> ecr_loss
        self.to(args.device)
    
    # MODIFIED: get_beta -> get_topic_gene_distribution    
    def get_topic_gene_distribution(self):
        dist = self.pairwise_euclidean_distance(self.topic_embeddings, self.gene_embeddings)  # word_embeddings -> gene_embeddings
        beta = F.softmax(-dist / self.beta_temp, dim=0)
        return beta

    # MODIFIED: get_embedding -> get_embeddings
    def get_embeddings(self):
        return self.topic_embeddings, self.gene_embeddings  # word_embeddings -> gene_embeddings

    
    def reparameterize(self, mu, logvar):
        if self.training:
            std = torch.exp(0.5 * logvar)
            eps = torch.randn_like(std)
            return mu + (eps * std)
        else:
            return mu

    # MODIFIED: encode -> encode_expression
    def encode_expression(self, input, return_both=True):  # flag -> return_both
        e1 = self.encoder(input)  # enc -> encoder

        e1 = self.encoder_dropout(e1)  # fc1_dropout -> encoder_dropout
        mu = self.mean_bn(self.encoder_mu(e1))  # fc21 -> encoder_mu
        logvar = self.logvar_bn(self.encoder_logvar(e1))  # fc22 -> encoder_logvar
        z = self.reparameterize(mu, logvar)

        kl_loss = self.compute_kl_loss(mu, logvar)  # compute_loss_KL -> compute_kl_loss
        if return_both:  # flag == 1 -> return_both
            return z, kl_loss
        else:
            class_dist = self.classifier(z)  # cla -> classifier
            return class_dist

    # MODIFIED: get_theta -> get_topic_distribution
    def get_topic_distribution(self, input):
        theta, kl_loss = self.encode_expression(input, return_both=True)  # encode -> encode_expression
        if self.training:
            return theta, kl_loss
        else:
            return theta

    # MODIFIED: compute_loss_KL -> compute_kl_loss
    def compute_kl_loss(self, mu, logvar):
        var = logvar.exp()
        var_division = var / self.prior_var  # var2 -> prior_var
        diff = mu - self.prior_mu  # mu2 -> prior_mu
        diff_term = diff * diff / self.prior_var  # var2 -> prior_var
        logvar_division = self.prior_var.log() - logvar  # var2 -> prior_var
        # KLD: N*K
        KLD = 0.5 * ((var_division + diff_term + logvar_division).sum(axis=1) - self.args.num_topics)  # num_topic -> num_topics
        KLD = KLD.mean()
        return KLD

    # MODIFIED: get_loss_ECR -> compute_ecr_loss
    def compute_ecr_loss(self):
        cost = self.pairwise_euclidean_distance(self.topic_embeddings, self.gene_embeddings)  # word_embeddings -> gene_embeddings
        ecr_loss = self.ecr_loss(cost)  # ECR -> ecr_loss
        return ecr_loss
    
    def pairwise_euclidean_distance(self, x, y):
        cost = torch.sum(x ** 2, axis=1, keepdim=True) + torch.sum(y ** 2, dim=1) - 2 * torch.matmul(x, y.t())
        return cost

    # MODIFIED: forward 参数名更新
    def forward(self, expression, foundation_embedding, neighbor_expression, neighbor_embedding, epoch):
        # MODIFIED: text -> expression, image -> foundation_embedding
        z, kl_loss = self.encode_expression(expression, return_both=True)  # encode -> encode_expression
        theta = F.softmax(z, dim=1)
        beta = self.get_topic_gene_distribution()  # get_beta -> get_topic_gene_distribution
        reconstruction = F.softmax(self.decoder_bn(torch.matmul(theta, beta)), dim=-1)  # recon -> reconstruction
        recon_loss = -(expression * reconstruction.log()).sum(axis=1).mean()  # text -> expression, recon -> reconstruction
        topic_model_loss = recon_loss + kl_loss  # loss_TM -> topic_model_loss
        
        ecr_loss = self.compute_ecr_loss()  # get_loss_ECR -> compute_ecr_loss

        # MODIFIED: TAC1 -> cross_modal_cluster_head
        cluster_logits_embedding = self.cross_modal_cluster_head(foundation_embedding)  # logit_image -> cluster_logits_embedding
        neighbor_cluster_logits_embedding = self.cross_modal_cluster_head(neighbor_embedding)  # neigh_logit_image -> neighbor_cluster_logits_embedding
        neighbor_cluster_logits_expression = self.encode_expression(neighbor_expression, return_both=False)  # neigh_logit_text -> neighbor_cluster_logits_expression
        cluster_logits_expression = self.encode_expression(expression, return_both=False)  # logit_text -> cluster_logits_expression
        
        distill_loss_val = (self.distill_loss(cluster_logits_embedding, neighbor_cluster_logits_expression) + 
                           self.distill_loss(cluster_logits_expression, neighbor_cluster_logits_embedding))  # loss_distill -> distill_loss_val
        consist_loss_val = consistency_loss(cluster_logits_expression, cluster_logits_embedding)  # loss_consist -> consist_loss_val
        entropy_loss_val = entropy(cluster_logits_expression) + entropy(cluster_logits_embedding)  # loss_entropy -> entropy_loss_val
        
        cross_modal_loss = distill_loss_val + consist_loss_val - 5 * entropy_loss_val  # loss_TAC -> cross_modal_loss
        total_loss = topic_model_loss + ecr_loss + cross_modal_loss  # loss -> total_loss

        result_dict = {
            'loss': total_loss,  # loss -> total_loss
            'topic_model_loss': topic_model_loss,  # loss_TM -> topic_model_loss
            'cross_modal_loss': cross_modal_loss,  # loss_TAC -> cross_modal_loss
            'ecr_loss': ecr_loss,  # loss_ECR -> ecr_loss
        }

        return result_dict