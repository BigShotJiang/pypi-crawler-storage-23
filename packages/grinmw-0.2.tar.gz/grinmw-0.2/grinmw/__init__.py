from grinmw.wallet import WalletV3Owner, WalletV2Foreign
from grinmw.node import NodeV2Foreign, NodeV2Owner
