"""Domain tool tests."""
