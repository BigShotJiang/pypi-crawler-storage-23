"""CLI module for smooai-logger."""
