# ModeKeeper

ModeKeeper is a verify-first operations agent for SRE, MLOps, and FinOps teams.

Free mode (PyPI) is customer-safe and read-only: inspect systems, evaluate plans, and export evidence.
Paid mode unlocks controlled apply flows plus governance/policy packs.

Key guarantees:
- verify-first: observe → verify → plan before any mutation is even considered
- licensed apply hard-gated by license_ok + verify_ok + kill-switch + approval/audit metadata
- `--out` artifacts preserve audit/incident evidence end-to-end

Public PyPI builds ship only the safe public runtime, never proprietary paid core.

## Install

```bash
python -m pip install -U modekeeper
```

Optional:

```bash
pipx install modekeeper
```

## Quickstart

```bash
mk --help
```

```bash
mk doctor
```

```bash
mk quickstart --out report/_quickstart
```

```bash
mk eval file --path report/_quickstart/plan/decision_trace_latest.jsonl --out report/_eval_quick
```

```bash
OBSERVE_ONLY=1 mk observe --duration 30s --source synthetic --out report/_observe_quick
```

Closed-loop dry run (no apply):

```bash
mk closed-loop run --scenario drift --dry-run --out report/_closed_loop_dry
```

Closed-loop apply (safe blocked example):

```bash
MODEKEEPER_KILL_SWITCH=1 MODEKEEPER_APPROVAL_ID=CHG-2026-004 MODEKEEPER_AUDIT_LOG=report/_closed_loop_apply_blocked/audit.json mk closed-loop run --scenario drift --apply --out report/_closed_loop_apply_blocked
```

Apply is gated by `license_ok` + `verify_ok` + kill-switch state + approval/audit metadata; with `MODEKEEPER_KILL_SWITCH=1`, apply remains blocked.

## How It Works

1. `observe`: collect read-only signals and write artifacts with `--out`.
2. `propose`: generate candidate actions/plans without mutating customer systems.
3. `verify`: check invariants/policies and produce a `verify_ok` decision artifact.
4. `apply` (licensed): execute only after gates pass (license + kill-switch + approval/audit + `verify_ok`).

## Packaging Policy (PyPI)

Public PyPI distribution is limited to customer-safe read-only capabilities.
Proprietary paid apply core and governance/policy packs are not shipped in public PyPI artifacts.

## Free vs Paid

- Free: customer-safe read-only workflows (`doctor`, `quickstart`, `observe`, `eval`, `roi`, `plan`, `verify`, `export`) with no mutations.
- Paid: apply actions plus governance/policy packs, gated by license, kill-switch, approval/audit controls, and `verify_ok`.

## Support / Commercial

Run `mk export --out report/_pilot_bundle` and send it to your ModeKeeper support/sales contact to request a pilot/license.
