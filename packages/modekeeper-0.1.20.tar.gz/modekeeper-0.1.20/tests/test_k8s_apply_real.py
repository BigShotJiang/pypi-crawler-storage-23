import importlib
import json
import subprocess
import sys
from pathlib import Path


def _run(mk: Path, args: list[str], env: dict | None = None) -> subprocess.CompletedProcess[str]:
    e = None
    if env is not None:
        import os

        e = os.environ.copy()
        e.update(env)
    return subprocess.run([str(mk), *args], text=True, capture_output=True, env=e)


def _write_plan(plan_path: Path) -> None:
    plan_path.write_text(
        json.dumps(
            [
                {"namespace": "ns1", "name": "dep1", "patch": {"spec": {"replicas": 2}}},
                {"namespace": "ns1", "name": "dep2", "patch": {"spec": {"replicas": 3}}},
            ]
        ),
        encoding="utf-8",
    )


def test_k8s_apply_public_is_pro_gated(tmp_path: Path, mk_path: Path) -> None:
    plan = tmp_path / "plan.json"
    _write_plan(plan)

    out_dir = tmp_path / "out"
    cp = _run(
        mk_path,
        ["k8s", "apply", "--plan", str(plan), "--out", str(out_dir)],
        env={"MODEKEEPER_PAID": "1", "MODEKEEPER_INTERNAL_OVERRIDE": "1"},
    )
    assert cp.returncode == 2
    assert cp.stderr.strip() == "PRO REQUIRED: k8s apply"

    report = json.loads((out_dir / "k8s_apply_latest.json").read_text(encoding="utf-8"))
    assert report.get("block_reason") == "pro_required"
    assert report.get("reason") == "pro_required"
    assert report.get("would_apply") is False


class _Explain:
    def __init__(self) -> None:
        self.events: list[dict] = []

    def emit(self, event: str, payload: dict) -> None:
        self.events.append({"event": event, "payload": payload})


def _import_pro_k8s_apply() -> object:
    repo_root = Path(__file__).resolve().parents[1]
    pro_src = repo_root / "packages" / "modekeeper_pro" / "src"
    pro_src_str = str(pro_src)
    if pro_src_str not in sys.path:
        sys.path.insert(0, pro_src_str)
    return importlib.import_module("modekeeper_pro.k8s_apply")


def _write_plan_and_verify_ok(tmp_path: Path) -> Path:
    plan_path = tmp_path / "k8s_plan.json"
    plan_path.write_text(
        json.dumps([{"namespace": "ns1", "name": "dep1", "patch": {"spec": {"replicas": 2}}}]) + "\n",
        encoding="utf-8",
    )
    (tmp_path / "k8s_verify_latest.json").write_text(
        json.dumps({"ok": True}) + "\n",
        encoding="utf-8",
    )
    return plan_path


def test_pro_k8s_apply_internal_override_bypasses_license_missing(
    monkeypatch, tmp_path: Path
) -> None:
    pro_k8s_apply = _import_pro_k8s_apply()
    plan_path = _write_plan_and_verify_ok(tmp_path)
    out_dir = tmp_path / "out_override"
    out_dir.mkdir(parents=True, exist_ok=True)
    explain = _Explain()

    monkeypatch.delenv("MODEKEEPER_PAID", raising=False)
    monkeypatch.delenv("MODEKEEPER_LICENSE_PATH", raising=False)
    monkeypatch.delenv("MODEKEEPER_KILL_SWITCH", raising=False)
    monkeypatch.setenv("MODEKEEPER_INTERNAL_OVERRIDE", "1")
    monkeypatch.setenv("KUBECTL", "/definitely/missing/kubectl")

    rc, _report_path, report = pro_k8s_apply.run_k8s_apply(
        plan_path=plan_path,
        out_dir=out_dir,
        explain=explain,
        force=False,
        license_path=None,
    )

    assert rc == 1
    assert report is not None
    assert report.get("block_reason") != "license_missing"
    assert report.get("internal_override") is True
    assert report.get("paid_enabled") is True
    assert report.get("items")[0].get("stderr") == "kubectl not found"


def test_pro_k8s_apply_without_override_blocks_license_missing(monkeypatch, tmp_path: Path) -> None:
    pro_k8s_apply = _import_pro_k8s_apply()
    plan_path = _write_plan_and_verify_ok(tmp_path)
    out_dir = tmp_path / "out_no_override"
    out_dir.mkdir(parents=True, exist_ok=True)
    explain = _Explain()

    monkeypatch.delenv("MODEKEEPER_PAID", raising=False)
    monkeypatch.delenv("MODEKEEPER_INTERNAL_OVERRIDE", raising=False)
    monkeypatch.delenv("MODEKEEPER_LICENSE_PATH", raising=False)
    monkeypatch.delenv("MODEKEEPER_KILL_SWITCH", raising=False)
    monkeypatch.setenv("KUBECTL", "/definitely/missing/kubectl")

    rc, _report_path, report = pro_k8s_apply.run_k8s_apply(
        plan_path=plan_path,
        out_dir=out_dir,
        explain=explain,
        force=False,
        license_path=None,
    )

    assert rc == 2
    assert report is not None
    assert report.get("block_reason") == "license_missing"
    assert report.get("internal_override") is False
    assert report.get("paid_enabled") is False
