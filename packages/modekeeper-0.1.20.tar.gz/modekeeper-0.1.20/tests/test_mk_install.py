import os
import subprocess
import urllib.request
import json
import importlib.util
import re
import sys
from pathlib import Path

import pytest


def _repo_root() -> Path:
    return Path(__file__).resolve().parents[1]


def _ensure_wheel(tmp_path: Path) -> Path:
    repo = _repo_root()
    dist_dir = repo / "dist"
    wheels = sorted(dist_dir.glob("modekeeper-*.whl"))
    if wheels:
        return wheels[-1]

    out_dir = tmp_path / "dist"
    out_dir.mkdir(parents=True, exist_ok=True)
    if importlib.util.find_spec("build") is None:
        pytest.skip("python build module is required when dist wheel is absent")
    cp = subprocess.run(
        [sys.executable, "-m", "build", "--wheel", "--outdir", str(out_dir)],
        cwd=repo,
        check=False,
        capture_output=True,
        text=True,
    )
    assert cp.returncode == 0, cp.stderr or cp.stdout

    built = sorted(out_dir.glob("modekeeper-*.whl"))
    assert built, "expected a modekeeper wheel"
    return built[-1]


def _run_mk_install_with_fake_python(
    tmp_path: Path,
    *,
    extra_env: dict[str, str],
    verify_license_rc: int,
    verify_requires_keys_env: bool = False,
    create_home_license_file: bool = False,
    create_home_keys_file: bool = False,
) -> tuple[subprocess.CompletedProcess[str], str]:
    repo = _repo_root()
    home_dir = tmp_path / "home"
    home_dir.mkdir(parents=True, exist_ok=True)
    fake_bin = tmp_path / "fake-bin"
    fake_bin.mkdir(parents=True, exist_ok=True)
    log_path = tmp_path / "calls.log"

    fake_python3 = fake_bin / "python3"
    fake_python3.write_text(
        f"""#!/usr/bin/env bash
set -Eeuo pipefail
if [[ "${{1:-}}" == "-m" && "${{2:-}}" == "venv" ]]; then
  venv_dir="${{3:?}}"
  mkdir -p "${{venv_dir}}/bin"
  cat > "${{venv_dir}}/bin/python" <<'EOF'
#!/usr/bin/env bash
set -Eeuo pipefail
LOG_PATH="${{MK_INSTALL_LOG:?}}"
printf 'VENV_PY %s\\n' "$*" >> "${{LOG_PATH}}"
if [[ "${{1:-}}" == "-m" && "${{2:-}}" == "pip" ]]; then
  if [[ "${{3:-}}" == "install" ]]; then
    cat > "$(dirname "$0")/mk" <<'MK'
#!/usr/bin/env bash
exit 0
MK
    chmod +x "$(dirname "$0")/mk"
  fi
  exit 0
fi
  if [[ "${{1:-}}" == "-c" ]]; then
  if [[ "${{2:-}}" == *'MK_INSTALL_REPO_JSON'* ]]; then
    url="${{3:-}}"
    sha="aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
    if [[ "${{url}}" == *'modekeeper/latest.json'* ]]; then
      printf '%s\x1f%s\x1f%s\n' "http://repo/modekeeper/wheels/modekeeper-0.1.9-py3-none-any.whl" "wheels/modekeeper-0.1.9-py3-none-any.whl" "${{sha}}"
      exit 0
    fi
    if [[ "${{url}}" == *'modekeeper-pro/latest.json'* ]]; then
      printf '%s\x1f%s\x1f%s\n' "http://repo/modekeeper-pro/wheels/modekeeper_pro-0.1.9-py3-none-any.whl" "wheels/modekeeper_pro-0.1.9-py3-none-any.whl" "${{sha}}"
      exit 0
    fi
    exit 1
  fi
  if [[ "${{2:-}}" == *'MK_INSTALL_LICENSE_GATE'* ]]; then
    if [[ "${{MK_TEST_LICENSE_GATE_HTTP403:-0}}" == "1" ]]; then
      echo "license gate HTTP 403: license_invalid" >&2
      exit 1
    fi
    if [[ "${{MK_TEST_LICENSE_GATE_FAIL:-0}}" == "1" ]]; then
      echo "license gate request failed" >&2
      exit 1
    fi
    sha="bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb"
    printf '%s\x1f%s\n' "http://repo/modekeeper-pro/wheels/modekeeper_pro-0.1.9-py3-none-any.whl?X-Amz-Signature=abc" "${{sha}}"
    exit 0
  fi
  if [[ "${{2:-}}" == *'MK_INSTALL_DOWNLOAD_VERIFY'* ]]; then
    out_path="${{5:?}}"
    mkdir -p "$(dirname "${{out_path}}")"
    printf 'wheel-bytes' > "${{out_path}}"
    exit 0
  fi
  if [[ "${{2:-}}" == *'verify_license'* ]]; then
    printf 'VERIFY_ENV %s\\n' "${{MODEKEEPER_LICENSE_PUBLIC_KEYS_PATH:-}}" >> "${{LOG_PATH}}"
    if [[ "${{VERIFY_REQUIRES_KEYS_ENV:-0}}" == "1" ]]; then
      expected="${{HOME}}/.config/modekeeper/license_public_keys.json"
      if [[ "${{MODEKEEPER_LICENSE_PUBLIC_KEYS_PATH:-}}" != "${{expected}}" ]]; then
        exit 1
      fi
    fi
    exit {verify_license_rc}
  fi
fi
exit 0
EOF
  chmod +x "${{venv_dir}}/bin/python"
  exit 0
fi
echo "unexpected python3 args: $*" >&2
exit 2
""",
        encoding="utf-8",
    )
    fake_python3.chmod(0o755)

    if create_home_license_file:
        cfg_dir = home_dir / ".config" / "modekeeper"
        cfg_dir.mkdir(parents=True, exist_ok=True)
        (cfg_dir / "license.json").write_text('{"schema_version":"license.v1"}', encoding="utf-8")
    if create_home_keys_file:
        cfg_dir = home_dir / ".config" / "modekeeper"
        cfg_dir.mkdir(parents=True, exist_ok=True)
        (cfg_dir / "license_public_keys.json").write_text(
            '{"mk-dev-2026-01":"A6EHv/POEL4dcN0Y50vAmWfk1jCbpQ1fHdyGZBJVMbg="}',
            encoding="utf-8",
        )

    env = {
        **os.environ,
        "HOME": str(home_dir),
        "PATH": f"{fake_bin}:{os.environ.get('PATH', '')}",
        "MK_INSTALL_LOG": str(log_path),
        "VERIFY_REQUIRES_KEYS_ENV": "1" if verify_requires_keys_env else "0",
        **extra_env,
    }
    install = subprocess.run(
        [str(repo / "bin" / "mk-install")],
        cwd=repo,
        check=False,
        capture_output=True,
        text=True,
        env=env,
    )
    return install, log_path.read_text(encoding="utf-8")


def test_mk_install_bootstraps_user_install(tmp_path: Path) -> None:
    repo = _repo_root()
    wheel = _ensure_wheel(tmp_path)

    home_dir = tmp_path
    env = {
        **os.environ,
        "HOME": str(home_dir),
        "MODEKEEPER_WHEEL": str(wheel),
    }

    install = subprocess.run(
        [str(repo / "bin" / "mk-install")],
        cwd=repo,
        check=False,
        capture_output=True,
        text=True,
        env=env,
    )
    assert install.returncode == 0, install.stderr or install.stdout

    mk_bin = home_dir / ".modekeeper" / "venv" / "bin" / "mk"
    mk_link = home_dir / ".local" / "bin" / "mk"
    assert mk_bin.exists()
    assert mk_link.exists()
    assert mk_link.is_symlink()

    kubectl = tmp_path / "kubectl"
    kubectl.write_text("#!/usr/bin/env bash\nexit 0\n", encoding="utf-8")
    kubectl.chmod(0o755)
    kubeconfig = tmp_path / "kubeconfig"
    kubeconfig.write_text("apiVersion: v1\n", encoding="utf-8")

    run_env = {
        **env,
        "KUBECTL": str(kubectl),
        "KUBECONFIG": str(kubeconfig),
    }

    doctor = subprocess.run(
        [str(mk_link), "doctor"],
        check=False,
        capture_output=True,
        text=True,
        env=run_env,
    )
    assert doctor.returncode == 0
    assert "Doctor result: PASS" in doctor.stdout

    help_cp = subprocess.run(
        [str(mk_link), "--help"],
        check=False,
        capture_output=True,
        text=True,
        env=run_env,
    )
    assert help_cp.returncode == 0


def test_mk_install_online_uses_latest_wheel_url_from_pypi_json(tmp_path: Path) -> None:
    repo = _repo_root()
    home_dir = tmp_path / "home"
    home_dir.mkdir(parents=True, exist_ok=True)
    fake_bin = tmp_path / "fake-bin"
    fake_bin.mkdir(parents=True, exist_ok=True)
    log_path = tmp_path / "calls.log"

    fake_python3 = fake_bin / "python3"
    fake_python3.write_text(
        """#!/usr/bin/env bash
set -Eeuo pipefail
if [[ "${1:-}" == "-m" && "${2:-}" == "venv" ]]; then
  venv_dir="${3:?}"
  mkdir -p "${venv_dir}/bin"
  cat > "${venv_dir}/bin/python" <<'EOF'
#!/usr/bin/env bash
set -Eeuo pipefail
LOG_PATH="${MK_INSTALL_LOG:?}"
printf 'VENV_PY %s\\n' "$*" >> "${LOG_PATH}"
if [[ "${1:-}" == "-m" && "${2:-}" == "pip" ]]; then
  if [[ "${3:-}" == "install" ]]; then
    cat > "$(dirname "$0")/mk" <<'MK'
#!/usr/bin/env bash
exit 0
MK
    chmod +x "$(dirname "$0")/mk"
  fi
  exit 0
fi
if [[ "${1:-}" == "-c" ]]; then
  if [[ "${2:-}" == *'["info"]["version"]'* ]]; then
    # stale metadata value that must not be used as "latest"
    echo "9.9.8"
    exit 0
  fi
  if [[ "${2:-}" == *'d.get("releases", {})'* ]]; then
    echo -e "9.9.9\thttps://files.pythonhosted.org/packages/test/modekeeper-9.9.9-py3-none-any.whl"
    exit 0
  fi
fi
exit 0
EOF
  chmod +x "${venv_dir}/bin/python"
  exit 0
fi
echo "unexpected python3 args: $*" >&2
exit 2
""",
        encoding="utf-8",
    )
    fake_python3.chmod(0o755)

    env = {
        **os.environ,
        "HOME": str(home_dir),
        "PATH": f"{fake_bin}:{os.environ.get('PATH', '')}",
        "MK_INSTALL_LOG": str(log_path),
    }
    install = subprocess.run(
        [str(repo / "bin" / "mk-install")],
        cwd=repo,
        check=False,
        capture_output=True,
        text=True,
        env=env,
    )
    assert install.returncode == 0, install.stderr or install.stdout

    logged = log_path.read_text(encoding="utf-8")
    assert "-m pip install -U --no-cache-dir https://files.pythonhosted.org/packages/test/modekeeper-9.9.9-py3-none-any.whl" in logged
    assert "--index-url https://pypi.org/simple modekeeper" not in logged


def test_mk_install_skips_pro_wheel_without_license(tmp_path: Path) -> None:
    pro_wheel_url = "https://example.com/modekeeper_pro-0.1.8-py3-none-any.whl"
    install, logged = _run_mk_install_with_fake_python(
        tmp_path,
        extra_env={
            "MODEKEEPER_WHEEL": "/tmp/modekeeper-0.1.8-py3-none-any.whl",
            "MODEKEEPER_PRO_WHEEL_URL": pro_wheel_url,
        },
        verify_license_rc=0,
    )
    assert install.returncode == 0, install.stderr or install.stdout
    assert f"-m pip install -U --no-cache-dir {pro_wheel_url}" not in logged


def test_mk_install_installs_pro_wheel_with_valid_license(tmp_path: Path) -> None:
    pro_wheel_url = "/tmp/modekeeper_pro-0.1.8-py3-none-any.whl"
    install, logged = _run_mk_install_with_fake_python(
        tmp_path,
        extra_env={
            "MODEKEEPER_WHEEL": "/tmp/modekeeper-0.1.8-py3-none-any.whl",
            "MODEKEEPER_PRO_WHEEL_URL": pro_wheel_url,
            "MODEKEEPER_LICENSE": '{"schema_version":"license.v1"}',
        },
        verify_license_rc=0,
    )
    assert install.returncode == 0, install.stderr or install.stdout
    assert f"-m pip install -U --no-cache-dir {pro_wheel_url}" in logged


def test_mk_install_skips_pro_wheel_with_invalid_license(tmp_path: Path) -> None:
    pro_wheel_url = "https://example.com/modekeeper_pro-0.1.8-py3-none-any.whl"
    install, logged = _run_mk_install_with_fake_python(
        tmp_path,
        extra_env={
            "MODEKEEPER_WHEEL": "/tmp/modekeeper-0.1.8-py3-none-any.whl",
            "MODEKEEPER_PRO_WHEEL_URL": pro_wheel_url,
            "MODEKEEPER_LICENSE": '{"schema_version":"license.v1"}',
        },
        verify_license_rc=1,
    )
    assert install.returncode == 0, install.stderr or install.stdout
    assert "WARNING: MODEKEEPER_PRO_WHEEL_URL set but license verification failed; skipping modekeeper-pro install" in install.stderr
    assert f"-m pip install -U --no-cache-dir {pro_wheel_url}" not in logged


def test_mk_install_installs_pro_wheel_with_home_license_and_keys_file(tmp_path: Path) -> None:
    pro_wheel_url = "/tmp/modekeeper_pro-0.1.8-py3-none-any.whl"
    install, logged = _run_mk_install_with_fake_python(
        tmp_path,
        extra_env={
            "MODEKEEPER_WHEEL": "/tmp/modekeeper-0.1.8-py3-none-any.whl",
            "MODEKEEPER_PRO_WHEEL_URL": pro_wheel_url,
        },
        verify_license_rc=0,
        verify_requires_keys_env=True,
        create_home_license_file=True,
        create_home_keys_file=True,
    )
    assert install.returncode == 0, install.stderr or install.stdout
    assert f"VERIFY_ENV {tmp_path / 'home' / '.config' / 'modekeeper' / 'license_public_keys.json'}" in logged
    assert f"-m pip install -U --no-cache-dir {pro_wheel_url}" in logged


def test_mk_install_repo_installs_public_and_pro_when_license_ok(tmp_path: Path) -> None:
    install, logged = _run_mk_install_with_fake_python(
        tmp_path,
        extra_env={"MODEKEEPER_REPO_BASE_URL": "http://repo"},
        verify_license_rc=0,
        verify_requires_keys_env=True,
        create_home_license_file=True,
        create_home_keys_file=True,
    )
    assert install.returncode == 0, install.stderr or install.stdout
    assert "modekeeper-0.1.9-py3-none-any.whl" in logged
    assert "modekeeper_pro-0.1.9-py3-none-any.whl" in logged


def test_mk_install_repo_skips_pro_when_license_bad(tmp_path: Path) -> None:
    install, logged = _run_mk_install_with_fake_python(
        tmp_path,
        extra_env={"MODEKEEPER_REPO_BASE_URL": "http://repo"},
        verify_license_rc=1,
        verify_requires_keys_env=True,
        create_home_license_file=True,
        create_home_keys_file=True,
    )
    assert install.returncode == 0, install.stderr or install.stdout
    assert "modekeeper-0.1.9-py3-none-any.whl" in logged
    assert "modekeeper_pro-0.1.9-py3-none-any.whl" not in logged


def test_mk_install_license_gate_installs_pro_when_license_ok(tmp_path: Path) -> None:
    install, logged = _run_mk_install_with_fake_python(
        tmp_path,
        extra_env={
            "MODEKEEPER_REPO_BASE_URL": "http://repo",
            "MODEKEEPER_LICENSE_GATE_URL": "http://gate/v1/pro/latest",
        },
        verify_license_rc=0,
        create_home_license_file=True,
        create_home_keys_file=True,
    )
    assert install.returncode == 0, install.stderr or install.stdout
    assert "modekeeper_pro-0.1.9-py3-none-any.whl" in logged
    match = re.search(
        r"modekeeper_pro-0\.1\.9-py3-none-any\.whl\?X-Amz-Signature=abc\s+[0-9a-f]{64}\s+(\S+)",
        logged,
    )
    assert match is not None
    out_path = match.group(1)
    assert "?" not in out_path
    assert out_path.endswith(".whl")


def test_mk_install_license_gate_skips_pro_when_license_bad(tmp_path: Path) -> None:
    install, logged = _run_mk_install_with_fake_python(
        tmp_path,
        extra_env={
            "MODEKEEPER_REPO_BASE_URL": "http://repo",
            "MODEKEEPER_LICENSE_GATE_URL": "http://gate/v1/pro/latest",
        },
        verify_license_rc=1,
        create_home_license_file=True,
        create_home_keys_file=True,
    )
    assert install.returncode == 0, install.stderr or install.stdout
    assert "modekeeper_pro-0.1.9-py3-none-any.whl" not in logged


def test_mk_install_license_gate_failure_does_not_fail_public_install(tmp_path: Path) -> None:
    install, logged = _run_mk_install_with_fake_python(
        tmp_path,
        extra_env={
            "MODEKEEPER_REPO_BASE_URL": "http://repo",
            "MODEKEEPER_LICENSE_GATE_URL": "http://gate/v1/pro/latest",
            "MK_TEST_LICENSE_GATE_FAIL": "1",
        },
        verify_license_rc=0,
        create_home_license_file=True,
        create_home_keys_file=True,
    )
    assert install.returncode == 0, install.stderr or install.stdout
    assert "modekeeper-0.1.9-py3-none-any.whl" in logged
    assert f"Installed: {tmp_path / 'home' / '.local' / 'bin' / 'mk'} -> {tmp_path / 'home' / '.modekeeper' / 'venv' / 'bin' / 'mk'}" in install.stdout


def test_mk_install_license_gate_failure_falls_back_to_repo_pro_when_available(tmp_path: Path) -> None:
    install, logged = _run_mk_install_with_fake_python(
        tmp_path,
        extra_env={
            "MODEKEEPER_REPO_BASE_URL": "http://repo",
            "MODEKEEPER_LICENSE_GATE_URL": "http://gate/v1/pro/latest",
            "MK_TEST_LICENSE_GATE_FAIL": "1",
        },
        verify_license_rc=0,
        create_home_license_file=True,
        create_home_keys_file=True,
    )
    assert install.returncode == 0, install.stderr or install.stdout
    assert "modekeeper_pro-0.1.9-py3-none-any.whl" in logged
    assert "?X-Amz-Signature=abc" not in logged


def test_mk_install_license_gate_http_403_warning_includes_root_cause_and_skips_pro(tmp_path: Path) -> None:
    install, logged = _run_mk_install_with_fake_python(
        tmp_path,
        extra_env={
            "MODEKEEPER_WHEEL": "/tmp/modekeeper-0.1.8-py3-none-any.whl",
            "MODEKEEPER_LICENSE_GATE_URL": "http://gate/v1/pro/latest",
            "MODEKEEPER_LICENSE": '{"schema_version":"license.v1"}',
            "MK_TEST_LICENSE_GATE_HTTP403": "1",
        },
        verify_license_rc=0,
    )
    assert install.returncode == 0, install.stderr or install.stdout
    assert "WARNING: modekeeper-pro license gate HTTP 403: license_invalid;" in install.stderr
    assert "modekeeper_pro-0.1.9-py3-none-any.whl" not in logged
    assert "-m pip install -U /tmp/modekeeper-0.1.8-py3-none-any.whl" in logged


def test_mk_install_online_matches_pypi_latest_and_module_version(tmp_path: Path) -> None:
    if os.environ.get("MK_INSTALL_E2E_ONLINE") != "1":
        return

    repo = _repo_root()
    home_dir = tmp_path
    env = {
        **os.environ,
        "HOME": str(home_dir),
    }

    install = subprocess.run(
        [str(repo / "bin" / "mk-install")],
        cwd=repo,
        check=False,
        capture_output=True,
        text=True,
        env=env,
    )
    assert install.returncode == 0, install.stderr or install.stdout

    venv_py = home_dir / ".modekeeper" / "venv" / "bin" / "python"
    assert venv_py.exists()

    latest_json = json.load(
        urllib.request.urlopen("https://pypi.org/pypi/modekeeper/json")
    )["info"]["version"]
    installed = subprocess.run(
        [str(venv_py), "-c", "import importlib.metadata; print(importlib.metadata.version('modekeeper'))"],
        check=False,
        capture_output=True,
        text=True,
        env=env,
    )
    assert installed.returncode == 0, installed.stderr or installed.stdout
    installed_version = installed.stdout.strip()

    module = subprocess.run(
        [str(venv_py), "-c", "import modekeeper; print(modekeeper.__version__)"],
        check=False,
        capture_output=True,
        text=True,
        env=env,
    )
    assert module.returncode == 0, module.stderr or module.stdout
    module_version = module.stdout.strip()

    assert installed_version == latest_json
    assert module_version == installed_version
