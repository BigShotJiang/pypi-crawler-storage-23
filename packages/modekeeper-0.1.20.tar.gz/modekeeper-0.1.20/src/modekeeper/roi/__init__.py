"""ROI artifacts."""

