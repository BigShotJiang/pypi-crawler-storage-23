"""Audit artifacts for closed-loop execution."""

