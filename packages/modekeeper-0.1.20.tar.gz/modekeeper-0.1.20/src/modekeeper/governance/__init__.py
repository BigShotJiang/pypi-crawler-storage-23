"""Governance helpers."""

