from albums.cli.entry_point import albums_group

if __name__ == "__main__":
    albums_group()
