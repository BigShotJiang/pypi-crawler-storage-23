from ...types import Album, CheckResult
from ..base_check import Check


class CheckAlbumUnderAlbum(Check):
    name = "album-under-album"
    default_config = {"enabled": True}

    def check(self, album: Album):
        if not self.ctx.db:
            raise ValueError("CheckAlbumUnderAlbum.check called without a db connection")

        path = album.path
        like_path = path.replace("|", "||").replace("%", "|%").replace("_", "|_") + "%"
        (matches,) = self.ctx.db.execute(
            "SELECT COUNT(*) FROM album WHERE path != ? AND path LIKE ? ESCAPE '|';",
            (
                path,
                like_path,
            ),
        ).fetchone()
        if matches > 0:
            return CheckResult(f"there are {matches} albums in directories under album {album.path}")
