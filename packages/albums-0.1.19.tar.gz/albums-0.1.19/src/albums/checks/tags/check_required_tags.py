from typing import Any

from ...tagger.folder import AlbumTagger, Cap
from ...types import Album, CheckResult
from ..base_check import Check


# TODO deprecate, replace with checks for individual important tags
class CheckRequiredTags(Check):
    name = "required-tags"
    default_config = {"enabled": False, "tags": ["artist", "title"]}

    def init(self, check_config: dict[str, Any]):
        required_tags: list[Any] = check_config.get("tags", CheckRequiredTags.default_config["tags"])
        if not isinstance(required_tags, list) or any(  # pyright: ignore[reportUnnecessaryIsInstance]
            not isinstance(tag, str) or tag == "" for tag in required_tags
        ):
            raise ValueError("required-tags.tags configuration must be a list of tags")
        self.required_tags = list(str(tag) for tag in required_tags)

    def check(self, album: Album):
        if not all(AlbumTagger.supports(track.filename, Cap.BASIC_TAGS) for track in album.tracks):
            return None  # this check only makes sense for files with common tags

        missing_required_tags: dict[str, int] = {}
        for track in sorted(album.tracks, key=lambda track: track.filename):
            for tag in filter(lambda tag: tag not in track.tags, self.required_tags):
                missing_required_tags[tag] = missing_required_tags.get(tag, 0) + 1

        if len(missing_required_tags) > 0:
            return CheckResult(f"tracks missing required tags {missing_required_tags}")
