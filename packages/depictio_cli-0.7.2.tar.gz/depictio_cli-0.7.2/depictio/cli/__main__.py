"""Enable running the CLI as `python -m depictio.cli`."""

from depictio.cli.depictio_cli import main

if __name__ == "__main__":
    main()
