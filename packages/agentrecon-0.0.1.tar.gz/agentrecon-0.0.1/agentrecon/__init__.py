"""AgentRecon — Code intelligence engine for AI coding assistants.

This is a placeholder package. The full release is coming soon.
Visit https://agentrecon.dev for more information.
"""

__version__ = "0.0.1"
