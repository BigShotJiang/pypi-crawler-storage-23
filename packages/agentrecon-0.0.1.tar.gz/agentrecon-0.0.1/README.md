# AgentRecon

Code intelligence engine for AI coding assistants.

This is a placeholder package to reserve the name. The full release is coming soon.

Visit [agentrecon.dev](https://agentrecon.dev) for more information.
