class Curve:
    """Base class for curves."""
    pass

class BezierCurve(Curve):
    pass
    
class NURBSCurve(Curve):
    pass
