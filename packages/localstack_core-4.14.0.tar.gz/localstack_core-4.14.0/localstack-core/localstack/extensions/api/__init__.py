"""Public facing API for users to build LocalStack extensions."""

from .extension import Extension

name = "api"

__all__ = ["Extension"]
