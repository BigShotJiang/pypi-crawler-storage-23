"""Easymode profile definitions for Homematic device links."""
