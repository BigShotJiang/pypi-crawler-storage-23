from setuptools import setup, find_packages

with open("README.md", "r") as f:
    description = f.read()
    

setup(
    name='sdk_risk',
    version='0.0.1.9',
    packages=find_packages(),
    include_package_data=True,
    install_requires=[
        "pandas>=2.2.3",
        "requests>=2.32.3",
        'numpy',
        'scipy',
        
    ],
    long_description=description,
    long_description_content_type="text/markdown",
            
)