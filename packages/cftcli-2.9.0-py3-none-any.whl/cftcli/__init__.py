"""CloudFormation CLI tools for managing AWS CloudFormation stacks."""

from cftcli.__version__ import __version__

__all__ = ['__version__']
