"""
QuarterBit - Memory-Efficient Training
======================================

Usage:
    from quarterbit import load_model, TrainingStats

    # Load model with 15-17x memory compression (streaming load)
    model = load_model("meta-llama/Llama-2-7b-hf")

    # Training loop with stats
    stats = TrainingStats()
    for step, batch in enumerate(dataloader):
        loss = model(**batch).loss
        loss.backward()  # Weights update automatically
        stats.log(step, loss.item())

    # Save/resume with standard PyTorch
    torch.save(model.state_dict(), "checkpoint.pt")

License: Free account required at https://quarterbit.dev
"""

__version__ = "20.5.4"
__author__ = "Clouthier Simulation Labs"

# License check on import
from .license import check_license, LicenseError

_LICENSE_VALID = False
try:
    check_license(silent=True)
    _LICENSE_VALID = True
except LicenseError:
    import sys
    print("\n" + "="*60)
    print("QuarterBit requires a free account.")
    print("")
    print("Sign up (free): https://quarterbit.dev")
    print("Then run:       quarterbit login")
    print("="*60 + "\n")

# Check PyTorch
try:
    import torch as _torch
    _HAS_TORCH = True
    if not _torch.cuda.is_available():
        import warnings
        warnings.warn(
            "QuarterBit: CUDA not available. GPU required for full performance.",
            RuntimeWarning
        )
except ImportError:
    _HAS_TORCH = False
    import warnings
    warnings.warn(
        "QuarterBit: PyTorch not found. Install from https://pytorch.org/get-started/locally/",
        ImportWarning
    )


def axiom(model, lr: float = 1e-3, verbose: bool = True):
    """
    Enable memory-efficient training on any PyTorch model.

    Achieves 15-17x memory compression, allowing large models to train
    on single GPUs. Works with all HuggingFace models (NLP, Vision, Audio, Multimodal).

    Args:
        model: Any PyTorch model (HuggingFace, custom, etc.)
        lr: Learning rate (default: 5e-5)
        verbose: Show training progress (default: True)

    Returns:
        Model with memory-efficient training enabled

    Example:
        from quarterbit import axiom
        from transformers import AutoModelForCausalLM

        model = AutoModelForCausalLM.from_pretrained("model-name", torch_dtype=torch.float16)
        model = axiom(model)
        model = model.cuda()

        for batch in dataloader:
            loss = model(**batch).loss
            loss.backward()
    """
    if not _LICENSE_VALID:
        raise LicenseError(
            "License required. Sign up free at quarterbit.dev then run: quarterbit login"
        )

    if not _HAS_TORCH:
        raise ImportError("PyTorch required. Install from https://pytorch.org/get-started/locally/")

    from .vla_trainable import make_vla_trainable, VLATrainableLinear, VLATrainableEmbedding, VLA_LR_SCALE

    # Convert model to memory-efficient training
    model = make_vla_trainable(model, error_bits=4, verbose=verbose)

    # Collect all VLA layers, enable streaming, and set lr
    vla_layers = []
    vla_params = 0
    for module in model.modules():
        if isinstance(module, (VLATrainableLinear, VLATrainableEmbedding)):
            module.enable_streaming_training()
            module._axiom_lr = lr  # Each layer knows its lr for auto-update
            vla_layers.append(module)
            if hasattr(module, 'out_features'):
                vla_params += module.out_features * module.in_features

    # Store for reference
    model._axiom_lr = lr
    model._axiom_vla_layers = vla_layers

    if verbose:
        pytorch_params = sum(p.numel() for p in model.parameters())
        total_params = vla_params + pytorch_params
        print(f"\n{'='*50}")
        print(f"AXIOM: Memory-efficient training enabled")
        print(f"Parameters: {total_params/1e9:.1f}B")
        print(f"Learning rate: {lr} (effective: {lr * VLA_LR_SCALE:.2e})")
        print(f"{'='*50}\n")

    return model


def load_model(
    model_name: str,
    lr: float = 1e-3,
    device: str = "cuda",
    verbose: bool = True,
    token: str = None,
    trust_remote_code: bool = False,
):
    """
    Load any HuggingFace model with 15-17x memory compression.

    Uses streaming load - never exceeds final compressed size.
    This is the RECOMMENDED way to load models with AXIOM.

    Args:
        model_name: HuggingFace model name (e.g., "meta-llama/Llama-2-7b-hf")
        lr: Learning rate (default: 5e-5)
        device: Target device (default: "cuda")
        verbose: Show progress (default: True)
        token: HuggingFace token for gated models
        trust_remote_code: Allow custom model code

    Returns:
        Model ready for training with automatic weight updates

    Memory comparison (7B model):
        Standard load:  14GB peak (FP16) -> then compress
        load_model():   5GB peak = final size (never higher!)

    Example:
        from quarterbit import load_model, TrainingStats

        model = load_model("meta-llama/Llama-2-7b-hf")

        for batch in dataloader:
            loss = model(**batch).loss
            loss.backward()  # Weights update automatically
    """
    if not _LICENSE_VALID:
        raise LicenseError(
            "License required. Sign up free at quarterbit.dev then run: quarterbit login"
        )

    if not _HAS_TORCH:
        raise ImportError("PyTorch required. Install from https://pytorch.org/get-started/locally/")

    from .vla_loader import load_vla_model
    from .vla_trainable import VLATrainableLinear, VLATrainableEmbedding, VLA_LR_SCALE

    # Load with streaming (never exceeds final VLA size)
    # Use error_bits=4 for compatibility with streaming training
    model = load_vla_model(
        model_name,
        error_bits=4,  # Must match axiom() for streaming compatibility
        device=device,
        verbose=verbose,
        token=token,
        trust_remote_code=trust_remote_code,
    )

    # Enable streaming training and set lr on all VLA layers
    vla_layers = []
    for module in model.modules():
        if isinstance(module, (VLATrainableLinear, VLATrainableEmbedding)):
            module.enable_streaming_training()
            module._axiom_lr = lr
            vla_layers.append(module)

    model._axiom_lr = lr
    model._axiom_vla_layers = vla_layers

    if verbose:
        print(f"\nLearning rate: {lr} (effective: {lr * VLA_LR_SCALE:.2e})")
        print(f"Ready for training - weights auto-update during backward()")

    return model


class TrainingStats:
    """
    Lightweight training progress tracker.

    Displays step, loss, perplexity, speed, GPU memory, and validation.

    Example:
        stats = TrainingStats(log_interval=100, eval_interval=500)
        for step, batch in enumerate(dataloader):
            loss = model(**batch).loss
            loss.backward()
            stats.log(step, loss.item())

            # Validation (optional)
            if step % 500 == 0:
                val_loss = evaluate(model, val_loader)
                stats.log_val(step, val_loss)
    """

    def __init__(self, log_interval: int = 100, eval_interval: int = 500, total_steps: int = None):
        """
        Args:
            log_interval: Print training stats every N steps (default: 100)
            eval_interval: Expected validation interval for display (default: 500)
            total_steps: Total training steps (for progress display)
        """
        self.log_interval = log_interval
        self.eval_interval = eval_interval
        self.total_steps = total_steps
        self._start_time = None
        self._step_time = None
        self._total_tokens = 0
        self._losses = []
        self._val_losses = []
        self._val_steps = []

    def log(self, step: int, loss: float, tokens: int = 0):
        """
        Log training step and display progress.

        Args:
            step: Current step number
            loss: Loss value for this step
            tokens: Number of tokens processed (for throughput)
        """
        import time
        import math

        if self._start_time is None:
            self._start_time = time.time()
            self._step_time = time.time()

        # Convert tensor to float if needed
        if hasattr(loss, 'item'):
            loss = loss.item()
        self._losses.append(loss)
        self._total_tokens += tokens

        if step > 0 and step % self.log_interval == 0:
            # Calculate stats
            elapsed = time.time() - self._step_time
            avg_loss = sum(self._losses[-self.log_interval:]) / min(len(self._losses), self.log_interval)
            ppl = math.exp(min(avg_loss, 20))  # Cap to avoid overflow

            # Throughput
            tps = tokens * self.log_interval / elapsed if elapsed > 0 and tokens > 0 else 0

            # Memory - show allocated (real usage) not reserved (nvidia-smi)
            mem_str = ""
            if _HAS_TORCH and _torch.cuda.is_available():
                _torch.cuda.synchronize()
                alloc_gb = _torch.cuda.memory_allocated() / 1e9
                mem_str = f" | VRAM: {alloc_gb:.1f}GB"

            # Progress
            if self.total_steps:
                progress = f"Step {step:5d}/{self.total_steps}"
            else:
                progress = f"Step {step:5d}"

            # Speed string
            speed_str = f" | {tps:.0f} tok/s" if tps > 0 else ""

            print(f"{progress} | Loss: {avg_loss:.4f} | PPL: {ppl:.2f}{speed_str}{mem_str}")

            self._step_time = time.time()

    def log_val(self, step: int, val_loss: float):
        """
        Log validation results.

        Args:
            step: Current step number
            val_loss: Validation loss
        """
        import math

        # Convert tensor to float if needed
        if hasattr(val_loss, 'item'):
            val_loss = val_loss.item()
        self._val_losses.append(val_loss)
        self._val_steps.append(step)

        val_ppl = math.exp(min(val_loss, 20))

        # Show improvement from initial
        if len(self._val_losses) > 1:
            init_ppl = math.exp(min(self._val_losses[0], 20))
            improvement = (init_ppl - val_ppl) / init_ppl * 100
            print(f"         >>> Val Loss: {val_loss:.4f} | Val PPL: {val_ppl:.2f} ({improvement:+.1f}%)")
        else:
            print(f"         >>> Val Loss: {val_loss:.4f} | Val PPL: {val_ppl:.2f}")

    def summary(self):
        """Print final training summary."""
        import time
        import math

        if not self._losses:
            return

        total_time = time.time() - self._start_time
        final_loss = self._losses[-1]
        best_loss = min(self._losses)

        print(f"\n{'='*50}")
        print(f"Training Complete")
        print(f"  Train Loss: {self._losses[0]:.4f} -> {final_loss:.4f}")
        print(f"  Best Loss:  {best_loss:.4f}")

        # Validation summary
        if self._val_losses:
            init_val = self._val_losses[0]
            final_val = self._val_losses[-1]
            best_val = min(self._val_losses)
            init_ppl = math.exp(min(init_val, 20))
            final_ppl = math.exp(min(final_val, 20))
            best_ppl = math.exp(min(best_val, 20))
            improvement = (init_ppl - final_ppl) / init_ppl * 100
            print(f"  Val PPL:    {init_ppl:.2f} -> {final_ppl:.2f} ({improvement:+.1f}%)")
            print(f"  Best Val:   {best_ppl:.2f}")

        print(f"  Steps:      {len(self._losses)}")
        print(f"  Time:       {total_time/60:.1f} min")
        if self._total_tokens > 0:
            print(f"  Throughput: {self._total_tokens/total_time:.0f} tok/s avg")

        # Memory summary
        if _HAS_TORCH and _torch.cuda.is_available():
            _torch.cuda.synchronize()
            peak_gb = _torch.cuda.max_memory_allocated() / 1e9
            current_gb = _torch.cuda.memory_allocated() / 1e9
            print(f"  Peak VRAM:  {peak_gb:.2f} GB")
            print(f"  Final VRAM: {current_gb:.2f} GB")

        print(f"{'='*50}\n")


# Main exports
__all__ = [
    "load_model",  # Primary: streaming load with compression
    "axiom",       # Legacy: convert already-loaded model
    "TrainingStats",
    "__version__",
]
