# Client-side copy of functions/src/orchestration/plan_integrity.py — keep in sync

"""Canonical plan integrity validation helpers.

This module is intentionally pure and framework-free so it can be reused by
server and client validation paths.
"""

from dataclasses import dataclass
from enum import Enum
from typing import Any


class ViolationCode(str, Enum):
    """Machine-readable plan integrity violation codes."""

    DEPTH_MISSING_OR_INVALID = "DEPTH_MISSING_OR_INVALID"
    STORY_NO_EXECUTABLE_DESCENDANTS = "STORY_NO_EXECUTABLE_DESCENDANTS"
    EPIC_NO_STORIES = "EPIC_NO_STORIES"
    DEPTH_PARENT_MISMATCH = "DEPTH_PARENT_MISMATCH"
    ORPHAN_PARENT_REF = "ORPHAN_PARENT_REF"
    DUPLICATE_ID = "DUPLICATE_ID"
    NONCONTIGUOUS_DESCENDANTS = "NONCONTIGUOUS_DESCENDANTS"
    DANGLING_DEPENDENCY = "DANGLING_DEPENDENCY"
    EXECUTABLE_DEPENDS_ON_CONTAINER = "EXECUTABLE_DEPENDS_ON_CONTAINER"


class ViolationSeverity(str, Enum):
    """Severity for plan integrity violations."""

    BLOCKING = "BLOCKING"
    WARNING = "WARNING"


@dataclass
class PlanViolation:
    """Plan integrity violation record."""

    code: ViolationCode
    item_ids: list[str]
    message: str
    severity: ViolationSeverity


def _normalize_item_type(item: dict[str, Any]) -> str:
    return str(item.get("item_type", "")).strip().lower()


def _normalize_item_id(item: dict[str, Any]) -> str:
    return str(item.get("id", "")).strip()


def _parse_depth(value: Any) -> int | None:
    if value is None:
        return None
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


def _walk_parent_chain(
    item_id: str,
    item_map: dict[str, dict[str, Any]],
    *,
    max_hops: int = 10,
) -> list[str]:
    chain: list[str] = []
    current_id = str(item_id).strip()
    visited: set[str] = set()
    for _ in range(max_hops):
        if not current_id or current_id in visited:
            break
        visited.add(current_id)
        chain.append(current_id)
        current_item = item_map.get(current_id)
        if not current_item:
            break
        raw_parent = current_item.get("parent_id")
        parent_id = str(raw_parent).strip() if raw_parent is not None else ""
        if not parent_id:
            break
        current_id = parent_id
    return chain


def _extract_dependency_ids(item: dict[str, Any]) -> list[str]:
    dependency_ids: list[str] = []
    for field in ("dependencies", "depends_on"):
        raw_dependencies = item.get(field)
        if not raw_dependencies:
            continue
        if not isinstance(raw_dependencies, list):
            raw_dependencies = [raw_dependencies]
        for dependency in raw_dependencies:
            if isinstance(dependency, dict):
                dep_id = str(
                    dependency.get("item_id")
                    or dependency.get("id")
                    or dependency.get("task_id")
                    or ""
                ).strip()
            else:
                dep_id = str(dependency).strip()
            if dep_id:
                dependency_ids.append(dep_id)
    return dependency_ids


def validate_plan_integrity(
    plan_items: list[dict[str, Any]],
    *,
    executable_types: set[str] | None = None,
) -> list[PlanViolation]:
    """Validate structural plan integrity constraints."""
    normalized_exec_types = {
        str(item_type).strip().lower()
        for item_type in (executable_types or {"task", "subtask"})
        if str(item_type).strip()
    }
    if not normalized_exec_types:
        normalized_exec_types = {"task", "subtask"}

    items = [item for item in plan_items if isinstance(item, dict)]
    item_counts: dict[str, int] = {}
    item_map: dict[str, dict[str, Any]] = {}
    for item in items:
        item_id = _normalize_item_id(item)
        if not item_id:
            continue
        item_counts[item_id] = item_counts.get(item_id, 0) + 1
        if item_id not in item_map:
            item_map[item_id] = item

    violations: list[PlanViolation] = []

    duplicate_ids = sorted(
        [item_id for item_id, count in item_counts.items() if count > 1]
    )
    for duplicate_id in duplicate_ids:
        violations.append(
            PlanViolation(
                code=ViolationCode.DUPLICATE_ID,
                item_ids=[duplicate_id],
                message=f"Duplicate plan item ID '{duplicate_id}'.",
                severity=ViolationSeverity.BLOCKING,
            )
        )

    for item_id, item in item_map.items():
        raw_parent = item.get("parent_id")
        parent_id = str(raw_parent).strip() if raw_parent is not None else ""
        if parent_id and parent_id not in item_map:
            violations.append(
                PlanViolation(
                    code=ViolationCode.ORPHAN_PARENT_REF,
                    item_ids=[item_id, parent_id],
                    message=(
                        f"Item '{item_id}' references missing parent_id '{parent_id}'."
                    ),
                    severity=ViolationSeverity.BLOCKING,
                )
            )

    for item_id, item in item_map.items():
        item_depth = _parse_depth(item.get("depth"))
        if item_depth is None:
            violations.append(
                PlanViolation(
                    code=ViolationCode.DEPTH_MISSING_OR_INVALID,
                    item_ids=[item_id],
                    message=f"Item '{item_id}' has missing or invalid depth.",
                    severity=ViolationSeverity.BLOCKING,
                )
            )

    for item_id, item in item_map.items():
        raw_parent = item.get("parent_id")
        parent_id = str(raw_parent).strip() if raw_parent is not None else ""
        if not parent_id or parent_id not in item_map:
            continue
        item_depth = _parse_depth(item.get("depth"))
        parent_depth = _parse_depth(item_map[parent_id].get("depth"))
        if item_depth is None or parent_depth is None:
            continue
        expected_depth = parent_depth + 1
        if item_depth != expected_depth:
            violations.append(
                PlanViolation(
                    code=ViolationCode.DEPTH_PARENT_MISMATCH,
                    item_ids=[item_id, parent_id],
                    message=(
                        f"Item '{item_id}' depth={item_depth} does not match parent "
                        f"'{parent_id}' depth+1={expected_depth}."
                    ),
                    severity=ViolationSeverity.BLOCKING,
                )
            )

    story_ids = [
        item_id
        for item_id, item in item_map.items()
        if _normalize_item_type(item) == "story"
    ]
    story_has_executable_descendant = {story_id: False for story_id in story_ids}

    story_exec_positions: dict[str, list[int]] = {}
    for index, item in enumerate(items):
        item_id = _normalize_item_id(item)
        if not item_id:
            continue
        item_type = _normalize_item_type(item)
        if item_type not in normalized_exec_types:
            continue
        chain = _walk_parent_chain(item_id, item_map)
        for ancestor_id in chain[1:]:
            if ancestor_id in story_has_executable_descendant:
                story_has_executable_descendant[ancestor_id] = True
                story_exec_positions.setdefault(ancestor_id, []).append(index)
                break

    for story_id, has_descendants in sorted(story_has_executable_descendant.items()):
        if has_descendants:
            continue
        violations.append(
            PlanViolation(
                code=ViolationCode.STORY_NO_EXECUTABLE_DESCENDANTS,
                item_ids=[story_id],
                message=f"Story '{story_id}' has no executable task/subtask descendants.",
                severity=ViolationSeverity.BLOCKING,
            )
        )

    epic_ids = [
        item_id
        for item_id, item in item_map.items()
        if _normalize_item_type(item) == "epic"
    ]
    epic_has_story_with_work = {epic_id: False for epic_id in epic_ids}
    for story_id, has_descendants in story_has_executable_descendant.items():
        if not has_descendants:
            continue
        chain = _walk_parent_chain(story_id, item_map)
        for ancestor_id in chain[1:]:
            ancestor_item = item_map.get(ancestor_id)
            if ancestor_item and _normalize_item_type(ancestor_item) == "epic":
                epic_has_story_with_work[ancestor_id] = True
                break

    for epic_id, has_story in sorted(epic_has_story_with_work.items()):
        if has_story:
            continue
        violations.append(
            PlanViolation(
                code=ViolationCode.EPIC_NO_STORIES,
                item_ids=[epic_id],
                message=(
                    f"Epic '{epic_id}' has no stories with executable descendants."
                ),
                severity=ViolationSeverity.WARNING,
            )
        )

    for story_id, positions in sorted(story_exec_positions.items()):
        if len(positions) <= 1:
            continue
        sorted_positions = sorted(positions)
        span = sorted_positions[-1] - sorted_positions[0] + 1
        if span == len(sorted_positions):
            continue
        violations.append(
            PlanViolation(
                code=ViolationCode.NONCONTIGUOUS_DESCENDANTS,
                item_ids=[story_id],
                message=(
                    f"Executable descendants of story '{story_id}' are not contiguous "
                    "in list order."
                ),
                severity=ViolationSeverity.WARNING,
            )
        )

    plan_id_set = set(item_map.keys())
    for item_id, item in sorted(item_map.items()):
        item_type = _normalize_item_type(item)
        dependency_ids = _extract_dependency_ids(item)

        if item_type in normalized_exec_types:
            container_dependencies = sorted(
                {
                    dependency_id
                    for dependency_id in dependency_ids
                    if dependency_id in plan_id_set
                    and _normalize_item_type(item_map.get(dependency_id, {}))
                    not in normalized_exec_types
                }
            )
            if container_dependencies:
                violations.append(
                    PlanViolation(
                        code=ViolationCode.EXECUTABLE_DEPENDS_ON_CONTAINER,
                        item_ids=[item_id, *container_dependencies],
                        message=(
                            f"Executable item '{item_id}' depends on container item(s): "
                            f"{container_dependencies}. Tasks/subtasks may only depend on "
                            "other executable items."
                        ),
                        severity=ViolationSeverity.BLOCKING,
                    )
                )

        missing_dependencies = sorted(
            {
                dependency_id
                for dependency_id in dependency_ids
                if dependency_id not in plan_id_set
            }
        )
        if not missing_dependencies:
            continue
        violations.append(
            PlanViolation(
                code=ViolationCode.DANGLING_DEPENDENCY,
                item_ids=[item_id, *missing_dependencies],
                message=(
                    f"Item '{item_id}' has dependencies not present in plan: "
                    f"{missing_dependencies}."
                ),
                severity=ViolationSeverity.WARNING,
            )
        )

    return violations
