"""Save Preview Modal for diff-on-save.

Shows a preview of all pending changes before saving configuration.
"""

from dataclasses import dataclass
from typing import Any

from textual.app import ComposeResult
from textual.binding import Binding
from textual.containers import Container, Horizontal
from textual.screen import ModalScreen
from textual.widgets import Button, DataTable, Label, Static


@dataclass
class PendingChange:
    """Represents a single pending configuration change."""

    path: str
    old_value: Any
    new_value: Any

    @property
    def change_type(self) -> str:
        """Return the type of change: added, modified, or removed."""
        if self.old_value is None:
            return "added"
        if self.new_value is None:
            return "removed"
        return "modified"

    @property
    def display_old(self) -> str:
        """Format old value for display."""
        if self.old_value is None:
            return "-"
        return str(self.old_value)

    @property
    def display_new(self) -> str:
        """Format new value for display."""
        if self.new_value is None:
            return "-"
        return str(self.new_value)


class SavePreviewModal(ModalScreen[bool]):
    """Modal dialog showing preview of pending changes before save.

    Returns True if user confirms save, False/None if cancelled.
    """

    BINDINGS = [
        Binding("escape", "cancel", "Cancel"),
        Binding("enter", "save", "Save", priority=True),
    ]

    DEFAULT_CSS = """
    SavePreviewModal {
        align: center middle;
    }

    SavePreviewModal > Container {
        width: 90;
        height: auto;
        max-height: 30;
        background: $surface;
        border: thick $accent;
        padding: 1 2;
    }

    SavePreviewModal #title {
        text-style: bold;
        width: 100%;
        text-align: center;
        margin-bottom: 1;
    }

    SavePreviewModal #description {
        color: $text-muted;
        margin-bottom: 1;
    }

    SavePreviewModal #changes-table {
        height: auto;
        max-height: 18;
        margin-bottom: 1;
    }

    SavePreviewModal .buttons {
        height: 3;
        align: center middle;
    }

    SavePreviewModal Button {
        margin: 0 1;
    }

    SavePreviewModal .added {
        color: $success;
    }

    SavePreviewModal .removed {
        color: $error;
    }

    SavePreviewModal .modified {
        color: $warning;
    }
    """

    def __init__(
        self,
        pending_changes: dict[str, tuple[Any, Any]],
    ) -> None:
        """Initialize the save preview modal.

        Args:
            pending_changes: Dict mapping path to (old_value, new_value) tuples
        """
        super().__init__()
        self._changes = [
            PendingChange(path=path, old_value=old, new_value=new)
            for path, (old, new) in pending_changes.items()
        ]

    def compose(self) -> ComposeResult:
        """Create the modal content."""
        with Container():
            yield Label("Changes to Save", id="title")
            yield Static(
                f"Review {len(self._changes)} pending change(s) before saving.",
                id="description",
            )

            # Changes table
            yield DataTable(id="changes-table")

            with Horizontal(classes="buttons"):
                yield Button("Cancel", variant="default", id="cancel")
                yield Button("Save Changes", variant="primary", id="save")

    def on_mount(self) -> None:
        """Initialize the changes table."""
        table = self.query_one("#changes-table", DataTable)

        # Add columns
        table.add_column("Path", width=40)
        table.add_column("Old Value", width=20)
        table.add_column("", width=3)  # Arrow column
        table.add_column("New Value", width=20)

        # Add rows for each change
        for change in self._changes:
            # Format path - truncate if too long
            path = change.path
            if len(path) > 38:
                path = "..." + path[-35:]

            # Format values
            old_val = change.display_old
            if len(old_val) > 18:
                old_val = old_val[:15] + "..."

            new_val = change.display_new
            if len(new_val) > 18:
                new_val = new_val[:15] + "..."

            # Determine styling based on change type
            if change.change_type == "added":
                arrow = "[green]+[/green]"
                old_val = "[dim]-[/dim]"
            elif change.change_type == "removed":
                arrow = "[red]-[/red]"
                new_val = "[dim]-[/dim]"
            else:
                arrow = "[yellow]->[/yellow]"

            table.add_row(path, old_val, arrow, new_val)

        # Focus save button
        save_button = self.query_one("#save", Button)
        save_button.focus()

    def action_cancel(self) -> None:
        """Cancel and close modal."""
        self.dismiss(False)

    def action_save(self) -> None:
        """Confirm save and close modal."""
        self.dismiss(True)

    def on_button_pressed(self, event: Button.Pressed) -> None:
        """Handle button clicks."""
        if event.button.id == "cancel":
            self.action_cancel()
        elif event.button.id == "save":
            self.action_save()
