"""LLM provider definitions and health checking for Obra.

Handles provider configuration, CLI availability checks, and installation guidance.

Example:
    from obra.config.providers import check_provider_status, validate_provider_ready

    status = check_provider_status("anthropic")
    if not status.installed:
        print(f"Install with: {status.install_hint}")
"""

import logging
import shutil
import subprocess
from dataclasses import dataclass
from pathlib import Path

from obra.model_registry import get_provider_models

logger = logging.getLogger(__name__)

# =============================================================================
# LLM Provider Definitions
# =============================================================================

# Supported LLM providers
# Provider model lists are derived from obra.model_registry to avoid drift.
# Keep "default" for provider-auto behavior and retain "auto" for Gemini CLI compatibility.
LLM_PROVIDERS = {
    "anthropic": {
        "name": "Anthropic",
        "description": "Claude models",
        "cli": "claude",  # Claude Code CLI
        "models": ["default", *[m.id for m in get_provider_models("anthropic")]],
        "default_model": "default",
        "oauth_env_var": None,  # OAuth uses browser-based login
        "api_key_env_var": "ANTHROPIC_API_KEY",  # pragma: allowlist secret
    },
    "google": {
        "name": "Google",
        "description": "Gemini models",
        "cli": "gemini",  # Gemini CLI
        "models": ["default", "auto", *[m.id for m in get_provider_models("google")]],
        "default_model": "default",
        "oauth_env_var": None,  # OAuth uses browser-based login (gemini auth login)
        "api_key_env_var": "GEMINI_API_KEY",  # pragma: allowlist secret
    },
    "openai": {
        "name": "OpenAI",
        "description": "Codex / GPT models",
        "cli": "codex",  # OpenAI Codex CLI
        "models": ["default", *[m.id for m in get_provider_models("openai")]],
        "default_model": "default",
        "oauth_env_var": None,  # OAuth uses browser-based login (codex --login)
        "api_key_env_var": "OPENAI_API_KEY",  # pragma: allowlist secret
    },
}

# Auth methods
LLM_AUTH_METHODS = {
    "oauth": {
        "name": "OAuth (Flat Rate)",
        "description": "Subscription-based, fixed monthly cost",
        "recommended_model": "default",
        "note": "Recommended - inherits provider's optimal model",
    },
    "api_key": {
        "name": "API Key (Token Billing)",
        "description": "Pay per token usage",
        "recommended_model": None,  # User should choose
        "note": "Warning: API Key method is currently untested",
    },
}

# Default provider settings
DEFAULT_PROVIDER = "anthropic"
DEFAULT_AUTH_METHOD = "oauth"
DEFAULT_MODEL = "default"

# =============================================================================
# Provider Health Check
# =============================================================================


@dataclass
class ProviderStatus:
    """Status of an LLM provider's CLI availability.

    Attributes:
        provider: Provider name (anthropic, openai, google)
        installed: Whether the CLI is installed and accessible
        cli_command: The CLI command name
        cli_path: Full path to CLI executable (if installed)
        install_hint: Installation instructions
        docs_url: Documentation URL
    """

    provider: str
    installed: bool
    cli_command: str
    cli_path: str | None = None
    install_hint: str = ""
    docs_url: str = ""


# Provider CLI information for health checking
PROVIDER_CLI_INFO: dict[str, dict[str, str]] = {
    "anthropic": {
        "cli": "claude",
        "install_hint": "npm install -g @anthropic-ai/claude-code",
        "docs_url": "https://docs.anthropic.com/en/docs/claude-code",
        "auth_hint": "claude login",
        "version_arg": "--version",
    },
    "openai": {
        "cli": "codex",
        "install_hint": "npm install -g @openai/codex",
        "docs_url": "https://platform.openai.com/docs/codex-cli",
        "auth_hint": "codex --login",
        "version_arg": "--version",
    },
    "google": {
        "cli": "gemini",
        "install_hint": "npm install -g @google/gemini-cli",
        "docs_url": "https://ai.google.dev/gemini-api/docs/gemini-cli",
        "auth_hint": "gemini auth login",
        "version_arg": "--version",
    },
}

# Timeout for functional health check subprocess (seconds)
_CLI_HEALTH_CHECK_TIMEOUT_S = 10


def check_provider_status(provider: str) -> ProviderStatus:
    """Check if an LLM provider's CLI is installed and accessible.

    Uses shutil.which() to locate the CLI executable in PATH.

    Args:
        provider: Provider name (anthropic, openai, google)

    Returns:
        ProviderStatus with installation details

    Examples:
        >>> status = check_provider_status("anthropic")
        >>> if status.installed:
        ...     print(f"Claude CLI at: {status.cli_path}")
        ... else:
        ...     print(f"Install with: {status.install_hint}")
    """
    cli_info = PROVIDER_CLI_INFO.get(provider, {})
    cli_command_raw = cli_info.get("cli", LLM_PROVIDERS.get(provider, {}).get("cli", ""))
    cli_command = str(cli_command_raw)

    if not cli_command:
        return ProviderStatus(
            provider=provider,
            installed=False,
            cli_command="unknown",
            install_hint=f"Unknown provider: {provider}",
        )

    # Check if CLI is in PATH
    cli_path = shutil.which(cli_command)

    return ProviderStatus(
        provider=provider,
        installed=cli_path is not None,
        cli_command=cli_command,
        cli_path=cli_path,
        install_hint=cli_info.get("install_hint", ""),
        docs_url=cli_info.get("docs_url", ""),
    )


def _run_cli_health_check(cli_path: str, version_arg: str) -> tuple[bool, str]:
    """Run a functional health check on a CLI binary.

    Executes ``<cli> <version_arg>`` and verifies it exits cleanly (rc 0).

    Args:
        cli_path: Full path to the CLI executable.
        version_arg: Argument to invoke a lightweight probe (e.g. ``--version``).

    Returns:
        (success, detail) – *detail* contains version output on success
        or the error description on failure.
    """
    try:
        result = subprocess.run(
            [cli_path, version_arg],
            capture_output=True,
            text=True,
            timeout=_CLI_HEALTH_CHECK_TIMEOUT_S,
        )
        if result.returncode == 0:
            version_output = (result.stdout or result.stderr or "").strip()
            return True, version_output
        # Non-zero exit — CLI is broken
        error_detail = (result.stderr or result.stdout or "").strip()
        return False, f"exited with code {result.returncode}: {error_detail}"
    except subprocess.TimeoutExpired:
        return False, f"timed out after {_CLI_HEALTH_CHECK_TIMEOUT_S}s"
    except OSError as exc:
        return False, str(exc)


def validate_provider_ready(provider: str) -> None:
    """Validate that a provider's CLI is installed and functional.

    Performs two checks:
    1. Binary exists on PATH (shutil.which)
    2. Functional probe (``<cli> --version``) exits cleanly

    Raises ConfigurationError with installation hints on failure.

    Args:
        provider: Provider name to validate (anthropic, openai, google)

    Raises:
        ConfigurationError: If provider CLI is not installed or non-functional

    Example:
        >>> try:
        ...     validate_provider_ready("openai")
        ... except ConfigurationError as e:
        ...     print(f"Setup required: {e}")
    """
    from obra.exceptions import ConfigurationError

    status = check_provider_status(provider)

    if not status.installed:
        provider_name = LLM_PROVIDERS.get(provider, {}).get("name", provider)
        cli_info = PROVIDER_CLI_INFO.get(provider, {})

        error_msg = f"{provider_name} CLI ({status.cli_command}) not found in PATH."
        details = []

        if status.install_hint:
            details.append(f"Install with: {status.install_hint}")

        auth_hint = cli_info.get("auth_hint")
        if auth_hint:
            details.append(f"Then authenticate: {auth_hint}")

        if status.docs_url:
            details.append(f"See: {status.docs_url}")

        if details:
            error_msg = f"{error_msg}\n\n" + "\n".join(details)

        raise ConfigurationError(error_msg)

    # Functional health check — verify the CLI actually runs
    cli_info = PROVIDER_CLI_INFO.get(provider, {})
    version_arg = cli_info.get("version_arg", "--version")
    ok, detail = _run_cli_health_check(status.cli_path, version_arg)  # type: ignore[arg-type]

    if ok:
        logger.debug(
            "Provider %s CLI health check passed: %s", provider, detail
        )
    else:
        provider_name = LLM_PROVIDERS.get(provider, {}).get("name", provider)
        error_msg = (
            f"{provider_name} CLI ({status.cli_command}) found at "
            f"{status.cli_path} but failed health check: {detail}"
        )
        details = []
        if status.install_hint:
            details.append(f"Try reinstalling: {status.install_hint}")
        if status.docs_url:
            details.append(f"See: {status.docs_url}")
        if details:
            error_msg = f"{error_msg}\n\n" + "\n".join(details)

        raise ConfigurationError(error_msg)


def _is_model_not_found_error(message: str) -> bool:
    """Detect provider/model lookup failures from CLI/API error text."""
    text = message.lower()
    return (
        "model_not_found" in text
        or ("requested model" in text and "does not exist" in text)
        or "unknown model" in text
    )


def validate_provider_model_ready(
    provider: str,
    model: str,
    *,
    auth_method: str = "oauth",
    cwd: Path | None = None,
    timeout_s: int = 30,
) -> None:
    """Validate that a provider+model pair is invokable end-to-end.

    This performs a lightweight live probe via provider CLI/API, catching model
    availability drift that static config/registry checks cannot detect.
    """
    from obra.exceptions import ConfigurationError
    from obra.llm.cli_runner import invoke_llm_via_cli

    validate_provider_ready(provider)

    model_text = str(model or "").strip()
    if not model_text or model_text in {"default", "auto"}:
        return

    probe_cwd = cwd or Path.cwd()
    try:
        invoke_llm_via_cli(
            prompt="Reply with exactly: OK",
            cwd=probe_cwd,
            provider=provider,
            model=model_text,
            thinking_level="low",
            auth_method=auth_method,
            timeout_s=timeout_s,
            retry_enabled=False,
            mode="text",
            response_format="text",
        )
    except Exception as exc:
        detail = str(exc)
        if _is_model_not_found_error(detail):
            raise ConfigurationError(
                f"Model '{model_text}' is not available for provider '{provider}'. "
                "Update model config to an available model and retry. "
                f"(detail: {detail})"
            ) from exc
        raise ConfigurationError(
            f"Model preflight failed for provider '{provider}', model '{model_text}'. "
            f"(detail: {detail})"
        ) from exc


# Public exports
__all__ = [
    "DEFAULT_AUTH_METHOD",
    "DEFAULT_MODEL",
    "DEFAULT_PROVIDER",
    "LLM_AUTH_METHODS",
    # Provider definitions
    "LLM_PROVIDERS",
    "PROVIDER_CLI_INFO",
    # Provider health check
    "ProviderStatus",
    "check_provider_status",
    "validate_provider_model_ready",
    "validate_provider_ready",
]
