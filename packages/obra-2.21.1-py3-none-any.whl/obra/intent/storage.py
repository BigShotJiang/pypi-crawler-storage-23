"""Intent storage layer for persistence to ~/.obra/intents/.

This module provides the IntentStorage class for saving and loading
intents to the global ~/.obra/intents/{project}/ directory structure.

Storage Layout:
    ~/.obra/intents/
        index.json              # Global index with active_intent per project
        {project}/
            {timestamp}-{slug}.json   # Intent files (JSON)

Related:
    - docs/design/briefs/AUTO_INTENT_GENERATION_BRIEF.md
    - obra/intent/models.py
"""

import hashlib
import json
import logging
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from obra.intent.models import IntentModel, IntentStatus

logger = logging.getLogger(__name__)

# Default storage root
DEFAULT_INTENTS_ROOT = Path.home() / ".obra" / "intents"

INTENT_FILE_EXTENSION = ".json"
INDEX_FILENAME = "index.json"
PROJECT_POINTER_FILENAME = "active_intent.json"


class IntentStorage:
    """Storage layer for intent persistence.

    Manages saving and loading intents to ~/.obra/intents/{project}/
    with an index.json file tracking active intents per project.

    Attributes:
        root: Root directory for intent storage (default: ~/.obra/intents/)

    Example:
        >>> storage = IntentStorage()
        >>> storage.save(intent)
        >>> loaded = storage.load(intent.id, project="my-app")
    """

    def __init__(self, root: Path | None = None) -> None:
        """Initialize IntentStorage.

        Args:
            root: Optional custom root directory (default: ~/.obra/intents/)
        """
        self._root = root or DEFAULT_INTENTS_ROOT

    @property
    def root(self) -> Path:
        """Get the storage root directory."""
        return self._root

    def _iter_intent_ids(self, project_dir: Path) -> list[str]:
        ids: set[str] = set()
        for intent_file in project_dir.glob(f"*{INTENT_FILE_EXTENSION}"):
            ids.add(intent_file.stem)
        return sorted(ids)

    def _ensure_dirs(self, project: str) -> Path:
        """Ensure project directory exists.

        Args:
            project: Project identifier

        Returns:
            Path to project intent directory
        """
        project_dir = self._root / project
        project_dir.mkdir(parents=True, exist_ok=True)
        return project_dir

    def save(self, intent: IntentModel) -> Path:
        """Save an intent to storage.

        Creates a JSON intent file.
        Updates the index.json to track this as the active intent
        for the project.

        Args:
            intent: IntentModel to save

        Returns:
            Path to the saved intent file

        Example:
            >>> storage = IntentStorage()
            >>> path = storage.save(intent)
            >>> print(path)
            ~/.obra/intents/my-app/20260110T1200-add-auth.json
        """
        project_dir = self._ensure_dirs(intent.project)
        file_path = project_dir / f"{intent.id}{INTENT_FILE_EXTENSION}"

        payload: dict[str, Any] = {
            "_meta": {
                "version": 1,
                "saved_at": datetime.now(UTC).isoformat(),
            },
            "intent": intent.model_dump(mode="json"),
        }
        file_path.write_text(
            json.dumps(payload, indent=2, sort_keys=False) + "\n",
            encoding="utf-8",
        )

        # Update index with active intent
        self._update_index(intent.project, intent.id, intent.status)

        logger.info("Saved intent %s to %s", intent.id, file_path)
        return file_path

    def load(self, intent_id: str, project: str) -> IntentModel | None:
        """Load an intent from storage.

        Args:
            intent_id: Intent ID to load
            project: Project identifier

        Returns:
            IntentModel if found, None otherwise

        Example:
            >>> storage = IntentStorage()
            >>> intent = storage.load("20260110T1200-add-auth", "my-app")
        """
        project_dir = self._root / project
        json_path = project_dir / f"{intent_id}{INTENT_FILE_EXTENSION}"
        if json_path.exists():
            try:
                content = json_path.read_text(encoding="utf-8")
                data = json.loads(content)
                intent_data = data.get("intent", data)
                if isinstance(intent_data, dict):
                    return IntentModel(**intent_data)
                return None
            except Exception:
                logger.exception("Failed to load intent %s", intent_id)
                return None
        logger.debug("Intent file not found: %s", json_path)
        return None

    def load_active(self, project: str) -> IntentModel | None:
        """Load the active intent for a project.

        Args:
            project: Project identifier

        Returns:
            Active IntentModel if exists, None otherwise
        """
        index = self._load_index()
        project_data = index.get("projects", {}).get(project, {})
        active_id = project_data.get("active_intent")

        if not active_id:
            logger.debug("No active intent for project: %s", project)
            return None

        return self.load(active_id, project)

    def list_intents(self, project: str | None = None) -> list[dict[str, Any]]:
        """List all intents, optionally filtered by project.

        Args:
            project: Optional project filter

        Returns:
            List of intent summaries with id, project, slug, created, status
        """
        intents: list[dict[str, Any]] = []
        index = self._load_index()

        if project:
            projects = {project: index.get("projects", {}).get(project, {})}
        else:
            projects = index.get("projects", {})

        for proj_name, proj_data in projects.items():
            proj_dir = self._root / proj_name
            if not proj_dir.exists():
                continue

            active_id = proj_data.get("active_intent")

            for intent_id in self._iter_intent_ids(proj_dir):
                # Parse minimal info from filename
                parts = intent_id.split("-", 1)
                timestamp = parts[0] if parts else ""
                slug = parts[1] if len(parts) > 1 else intent_id

                intents.append(
                    {
                        "id": intent_id,
                        "project": proj_name,
                        "slug": slug,
                        "created": timestamp,
                        "is_active": intent_id == active_id,
                    }
                )

        # Sort by created timestamp descending
        intents.sort(key=lambda x: x.get("created", ""), reverse=True)
        return intents

    def find_by_userplan(
        self,
        userplan_id: str,
        project: str,
        version: int | None = None,
    ) -> list[IntentModel]:
        """Find intents linked to a specific UserPlan.

        Searches for intents that reference the given UserPlan ID
        and optionally a specific version.

        Args:
            userplan_id: UserPlan ID to search for
            project: Project identifier
            version: Optional version filter

        Returns:
            List of IntentModel instances matching the criteria

        Example:
            >>> storage = IntentStorage()
            >>> intents = storage.find_by_userplan("UP-20260115-auth", "my-app")
            >>> intents = storage.find_by_userplan("UP-20260115-auth", "my-app", version=2)
        """
        matching: list[IntentModel] = []
        project_dir = self._root / project

        if not project_dir.exists():
            return matching

        for intent_id in self._iter_intent_ids(project_dir):
            intent = self.load(intent_id, project)

            if intent is None:
                continue

            if intent.userplan_id == userplan_id:
                if version is None or intent.userplan_version == version:
                    matching.append(intent)

        # Sort by version descending (most recent first)
        matching.sort(
            key=lambda x: (x.userplan_version or 0, x.created),
            reverse=True,
        )
        return matching

    def delete(self, intent_id: str, project: str) -> bool:
        """Delete an intent from storage.

        Args:
            intent_id: Intent ID to delete
            project: Project identifier

        Returns:
            True if deleted, False if not found
        """
        project_dir = self._root / project
        json_path = project_dir / f"{intent_id}{INTENT_FILE_EXTENSION}"
        if not json_path.exists():
            logger.debug("Intent file not found for deletion: %s", json_path)
            return False

        if json_path.exists():
            json_path.unlink()

        # Update index if this was the active intent
        index = self._load_index()
        proj_data = index.get("projects", {}).get(project, {})
        if proj_data.get("active_intent") == intent_id:
            proj_data["active_intent"] = None
            self._save_index(index)

        logger.info("Deleted intent %s from %s", intent_id, project)
        return True

    def set_active(self, intent_id: str, project: str) -> bool:
        """Set an intent as the active intent for a project.

        Args:
            intent_id: Intent ID to set as active
            project: Project identifier

        Returns:
            True if set, False if intent not found
        """
        project_dir = self._root / project
        json_path = project_dir / f"{intent_id}{INTENT_FILE_EXTENSION}"
        if not json_path.exists():
            logger.debug("Intent file not found: %s", json_path)
            return False

        self._update_index(project, intent_id, IntentStatus.ACTIVE)
        logger.info("Set active intent for %s: %s", project, intent_id)
        return True

    def resolve_id(self, partial_id: str, project: str) -> str | None:
        """Resolve a partial ID to a full intent ID.

        Supports:
        - Full ID: 20260110T1200-add-auth
        - Timestamp only: 20260110T1200
        - Slug only: add-auth

        Args:
            partial_id: Partial or full intent ID
            project: Project identifier

        Returns:
            Full intent ID if unique match found, None otherwise
        """
        project_dir = self._root / project
        if not project_dir.exists():
            return None

        matches: list[str] = []
        for intent_id in self._iter_intent_ids(project_dir):
            # Exact match
            if intent_id == partial_id:
                return intent_id

            # Timestamp prefix match
            if intent_id.startswith(partial_id):
                matches.append(intent_id)
                continue

            # Slug suffix match
            if intent_id.endswith(f"-{partial_id}"):
                matches.append(intent_id)
                continue

        if len(matches) == 1:
            return matches[0]

        if len(matches) > 1:
            logger.warning(
                "Ambiguous intent ID '%s' matches multiple: %s",
                partial_id,
                matches,
            )

        return None

    def get_project_id(self, working_dir: Path) -> str:
        """Get project identifier from working directory.

        Uses the directory name for readability, falling back to
        a hash if the name contains problematic characters.

        Args:
            working_dir: Project working directory

        Returns:
            Project identifier string
        """
        name = working_dir.name

        # If name is simple alphanumeric with hyphens/underscores, use it
        if all(c.isalnum() or c in "-_" for c in name):
            return name.lower()

        # Otherwise hash the full path
        return hashlib.sha256(str(working_dir).encode()).hexdigest()[:12]

    def _update_index(
        self,
        project: str,
        intent_id: str,
        status: IntentStatus,
    ) -> None:
        """Update the index.json with intent information.

        Args:
            project: Project identifier
            intent_id: Intent ID
            status: Intent status
        """
        index = self._load_index()

        if "projects" not in index:
            index["projects"] = {}

        if project not in index["projects"]:
            index["projects"][project] = {}

        proj_data = index["projects"][project]

        # Set as active if status is ACTIVE
        if status == IntentStatus.ACTIVE:
            proj_data["active_intent"] = intent_id

        proj_data["last_updated"] = datetime.now(UTC).isoformat()

        self._save_index(index)

    def _load_index(self) -> dict[str, Any]:
        """Load the index.json file.

        Returns:
            Index data dictionary
        """
        index_path = self._root / INDEX_FILENAME
        if index_path.exists():
            try:
                content = index_path.read_text(encoding="utf-8")
                data = json.loads(content)
                if isinstance(data, dict):
                    return data
            except Exception:
                logger.exception("Failed to load index.json")
                return {"version": 1, "projects": {}}

        return {"version": 1, "projects": {}}

    def _save_index(self, index: dict[str, Any]) -> None:
        """Save the index.json file.

        Args:
            index: Index data dictionary
        """
        self._root.mkdir(parents=True, exist_ok=True)
        index_path = self._root / INDEX_FILENAME

        index["version"] = 1
        index["updated"] = datetime.now(UTC).isoformat()

        content = json.dumps(index, indent=2, sort_keys=False)
        index_path.write_text(content + "\n", encoding="utf-8")

    def write_project_pointer(
        self,
        working_dir: Path,
        intent: IntentModel,
    ) -> Path:
        """Write a project-local pointer file for LLM discoverability.

        Creates .obra/active_intent.json in the project directory,
        enabling LLM agents to discover the active intent without
        knowing the global storage location.

        Args:
            working_dir: Project working directory
            intent: Active IntentModel to reference

        Returns:
            Path to the created pointer file
        """
        obra_dir = working_dir / ".obra"
        obra_dir.mkdir(parents=True, exist_ok=True)
        pointer_path = obra_dir / PROJECT_POINTER_FILENAME

        # Get the full path to the intent file
        project_dir = self._root / intent.project
        intent_file_path = project_dir / f"{intent.id}{INTENT_FILE_EXTENSION}"

        # Build pointer content
        pointer_content = {
            "_meta": {
                "purpose": "LLM discoverability pointer for Obra intent system",
                "generated": datetime.now(UTC).isoformat(),
                "view_command": "obra intent show",
            },
            "intent": {
                "id": intent.id,
                "project": intent.project,
                "status": intent.status.value,
                "summary": (intent.problem_statement[:200] if intent.problem_statement else ""),
                "full_path": str(intent_file_path),
            },
        }

        pointer_path.write_text(
            json.dumps(pointer_content, indent=2, sort_keys=False) + "\n",
            encoding="utf-8",
        )
        logger.info("Wrote project pointer to %s", pointer_path)
        return pointer_path

    def remove_project_pointer(self, working_dir: Path) -> bool:
        """Remove the project-local pointer file.

        Called when an intent is deactivated or deleted.

        Args:
            working_dir: Project working directory

        Returns:
            True if removed, False if not found
        """
        pointer_path = working_dir / ".obra" / PROJECT_POINTER_FILENAME
        removed = False
        if pointer_path.exists():
            pointer_path.unlink()
            removed = True
        if removed:
            logger.info("Removed project pointer: %s", pointer_path)
            return True
        return False


# Convenience exports
__all__ = ["IntentStorage"]
