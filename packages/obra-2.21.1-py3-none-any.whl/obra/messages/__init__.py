"""
User-facing message library for Obra CLI.

This package provides a centralized registry of user-facing messages
organized by domain (recovery, status, progress, error, warning, guidance, prompt).

Usage:
    from obra.messages import get_message, list_messages, MessageDomain

    # Get a formatted message
    msg = get_message("recovery.auth.login")

    # Get with placeholders
    msg = get_message("recovery.session.resume", short_id="abc123")

    # Get verbose variant
    msg = get_message("recovery.session.resume", short_id="abc123", verbose=True)

    # List all recovery messages
    keys = list_messages(MessageDomain.RECOVERY)

    # Export for auditing
    index = export_message_index()

Thread Safety:
    All functions are thread-safe. Templates are lazily loaded on first
    access using double-checked locking.

ASCII Mode:
    Set OBRA_ASCII_MODE=1 or config display.emoji_enabled=false to use
    ASCII-safe variants of messages that contain emoji.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from obra.messages.registry import MessageDomain

__all__ = [
    "ErrorCategory",
    "GuidanceCategory",
    "Keys",
    "MessageDomain",
    # MessageTemplate for type hints
    "MessageTemplate",
    "ProgressCategory",
    "PromptCategory",
    # Category enums
    "RecoveryCategory",
    "StatusCategory",
    "WarningCategory",
    "export_message_index",
    "get_message",
    "list_messages",
]


# =============================================================================
# PEP 562 Lazy Loading
# =============================================================================


def __getattr__(name: str) -> Any:
    """
    Lazily load attributes on first access.

    This prevents loading heavy modules during package import,
    enabling fast CLI startup.
    """
    if name == "get_message":
        from obra.messages.registry import get_message

        return get_message

    if name == "list_messages":
        from obra.messages.registry import list_messages

        return list_messages

    if name == "export_message_index":
        from obra.messages.registry import export_message_index

        return export_message_index

    if name == "MessageDomain":
        from obra.messages.registry import MessageDomain

        return MessageDomain

    if name == "Keys":
        from obra.messages.keys import Keys

        return Keys

    if name == "MessageTemplate":
        from obra.messages.registry import MessageTemplate

        return MessageTemplate

    # Category enums
    if name == "RecoveryCategory":
        from obra.messages.registry import RecoveryCategory

        return RecoveryCategory

    if name == "StatusCategory":
        from obra.messages.registry import StatusCategory

        return StatusCategory

    if name == "ProgressCategory":
        from obra.messages.registry import ProgressCategory

        return ProgressCategory

    if name == "ErrorCategory":
        from obra.messages.registry import ErrorCategory

        return ErrorCategory

    if name == "WarningCategory":
        from obra.messages.registry import WarningCategory

        return WarningCategory

    if name == "GuidanceCategory":
        from obra.messages.registry import GuidanceCategory

        return GuidanceCategory

    if name == "PromptCategory":
        from obra.messages.registry import PromptCategory

        return PromptCategory

    msg = f"module {__name__!r} has no attribute {name!r}"
    raise AttributeError(msg)
