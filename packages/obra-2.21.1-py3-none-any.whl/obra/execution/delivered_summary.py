"""Delivered work summary helpers for post-execution gap checks."""

# pylint: disable=too-many-arguments

from __future__ import annotations

import json
from typing import Any

DEFAULT_MAX_FILES = 50
DEFAULT_MAX_TESTS = 20
DEFAULT_MAX_DOCS = 20


def _cap_list(items: list[str], max_items: int) -> list[str]:
    return items[:max_items]


def build_delivered_summary(
    *,
    changed_files: list[str],
    diffstat: dict[str, int],
    tests_run: list[str],
    docs_updated: list[str],
    changelog_updated: bool,
    max_files: int = DEFAULT_MAX_FILES,
    max_tests: int = DEFAULT_MAX_TESTS,
    max_docs: int = DEFAULT_MAX_DOCS,
) -> dict[str, Any]:
    """Build a compact delivered work summary.

    Args:
        changed_files: List of changed file paths
        diffstat: Dict with added/modified/deleted counts
        tests_run: List of tests executed
        docs_updated: List of docs updated
        changelog_updated: Whether CHANGELOG.md was updated
        max_files: Max files to keep
        max_tests: Max tests to keep
        max_docs: Max docs to keep

    Returns:
        Summary dict with capped lists and summary_text
    """
    files_capped = _cap_list(sorted(set(changed_files)), max_files)
    tests_capped = _cap_list(sorted(set(tests_run)), max_tests)
    docs_capped = _cap_list(sorted(set(docs_updated)), max_docs)

    summary: dict[str, Any] = {
        "changed_files": files_capped,
        "diffstat": {
            "added": int(diffstat.get("added", 0)),
            "modified": int(diffstat.get("modified", 0)),
            "deleted": int(diffstat.get("deleted", 0)),
            "total": int(diffstat.get("total", 0)),
        },
        "tests_run": tests_capped,
        "docs_updated": docs_capped,
        "changelog_updated": bool(changelog_updated),
    }

    diff_line = (
        f"Diffstat: +{summary['diffstat']['added']} "
        f"~{summary['diffstat']['modified']} "
        f"-{summary['diffstat']['deleted']}"
    )
    summary_lines = [
        f"Files changed: {len(files_capped)}",
        diff_line,
        f"Tests run: {', '.join(tests_capped) if tests_capped else 'none'}",
        f"Docs updated: {', '.join(docs_capped) if docs_capped else 'none'}",
        f"Changelog updated: {'yes' if changelog_updated else 'no'}",
    ]
    summary["summary_text"] = "\n".join(summary_lines)
    return summary


def format_summary_json(summary: dict[str, Any]) -> str:
    """Format summary as compact JSON for prompt injection."""
    return json.dumps(summary, indent=2)


__all__ = ["build_delivered_summary", "format_summary_json"]
