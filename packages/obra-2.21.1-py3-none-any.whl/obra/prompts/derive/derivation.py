"""Derivation prompts extracted from obra/execution/derivation.py.

This module contains prompt templates and builder functions for the
derivation engine, enabling plan generation from high-level objectives.

Related:
    - obra/execution/derivation.py (DerivationEngine)
    - REFACTOR-PROMPT-LIBRARY-001

Prompts:
    - SIZING_GUIDANCE: Quality criteria for plan items
    - PATTERN_GUIDANCE: Work-type specific decomposition guidance
    - build_derivation_prompt: Main derivation prompt builder
    - build_step1_prompt: Step 1 (structure planning) prompt builder
    - build_step1_epics_only_prompt: Step 1 (epic-only) prompt builder
    - build_step2_prompt: Step 2 (task derivation) prompt builder
    - build_step2_per_epic_prompt: Step 2 (per-epic) prompt builder
    - build_step3_prompt: Step 3 (JSON serialization) prompt builder
"""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from obra.hybrid.derivation.mission_complexity import SizingGuidance

__all__ = [
    "FOUR_PHASE_GUIDANCE",
    "PATTERN_GUIDANCE",
    "SIZING_GUIDANCE",
    "build_derivation_prompt",
    "build_four_phase_guidance",
    "build_refinement_prompt",
    "build_sizing_guidance_block",
    "build_step1_epics_only_prompt",
    "build_step1_epics_template",
    "build_step1_prompt",
    "build_step2_per_epic_prompt",
    "build_step2_repair_prompt",
    "build_step2_repair_template",
    "build_step2_per_epic_template",
    "build_step2_prompt",
    "build_step3_per_epic_prompt",
    "build_step3_prompt",
    "get_pattern_guidance",
]

SIZING_GUIDANCE = """
## Plan Quality Criteria

### What Makes a Good Plan

**Good items:**
- ONE primary action per item (create, modify, test, document)
- Achievable in a single focused LLM session
- Self-contained description (executor sees ONLY this item)
- Concrete, verifiable acceptance criteria
- Explicit dependencies between items
- Target: 1-3 files modified, ~50-300 lines changed

**Avoid:**
- Compound titles with "and", "then", "after" (split these)
- Items touching >5 files (add explore item first)
- Vague criteria ("works correctly", "code is clean")
- Hidden dependencies between items
- Descriptions over ~150 words (too big)

### Acceptance Criteria Quality

Each criterion must be objectively verifiable:
- GOOD: "pytest tests/auth/ passes with 0 failures"
- GOOD: "Returns 401 JSON error on invalid credentials"
- GOOD: "ruff check exits 0 with no lint errors"
- BAD: "Code is clean and readable"
- BAD: "Tests look good"

Cover both success and failure paths. State where artifacts live.

### Context-Aware Descriptions

The executing LLM sees ONLY this item's description—not the original objective or other items.
- Include specific file paths, function names, API contracts
- Don't assume knowledge of previous decisions—repeat key context
- Call out inputs/outputs, feature flags, config values explicitly

### Phase-Specific Guidance

For each phase, consider what's appropriate:
- **EXPLORE**: What context do you need? What patterns exist? (Read-only)
- **PLAN**: What's the approach? What are the interfaces? (Design-focused)
- **IMPLEMENT**: What's the smallest shippable unit? (1-3 files, single feature)
- **COMMIT**: What verification ensures quality? (Tests, lint, docs)

### Complexity Signals (Split If Present)

If any of these apply, the item is likely too big:
- Description exceeds ~150 words
- Item touches >5 files
- Item lists >5 acceptance criteria
- Title contains "and", "then", or "after"
- Work spans multiple phases
- Requires understanding multiple subsystems
"""


def build_sizing_guidance_block(guidance: SizingGuidance) -> str:
    """Build sizing context block for derivation prompts."""
    return (
        "\n## Sizing Context\n"
        f"This is a {guidance.size_class.value.upper()} objective:\n"
        f"{guidance.description}\n\n"
        f"Scope: {guidance.scope}\n\n"
        "Apply your judgment to create an appropriately-sized plan."
    )


PATTERN_GUIDANCE: dict[str, str] = {
    "feature_implementation": """
For new features, consider:
- What data models and interfaces need to exist?
- What's the core functionality that delivers user value?
- How will you verify it works (tests, manual checks)?
- What documentation helps users understand it?""",
    "bug_fix": """
For bug fixes, consider:
- Can you reproduce the bug reliably? (Write a failing test first)
- What's the root cause, not just the symptom?
- What regression test prevents this from recurring?
- How do you verify the fix works in realistic conditions?""",
    "refactoring": """
For refactoring, consider:
- What's wrong with the current structure? (Document before changing)
- What's the target state and migration path?
- How do you maintain test coverage throughout?
- How do you verify behavior is unchanged?""",
    "integration": """
For integrations, consider:
- What's the contract between systems? (Define interfaces first)
- How do you handle errors and edge cases?
- How do you test without depending on external systems?
- What documentation helps others use this integration?""",
    "database": """
For database changes, consider:
- What's the schema change and migration strategy?
- How do you handle rollback if something goes wrong?
- What ORM/query changes follow from the schema change?
- How do you test migrations safely before production?""",
    "documentation": """
For documentation, consider:
- Who is the audience? (Users, developers, operators)
- What do they need to accomplish?
- What existing docs need to be updated?
- How do you verify completeness and accuracy?""",
    "general": """
Consider for any work:
- What context do you need before starting? (explore)
- What's the approach and key decisions? (plan)
- What's the smallest shippable implementation? (implement)
- How do you verify quality and completeness? (commit)""",
}

FOUR_PHASE_GUIDANCE = """
## Recommended Phase Structure (4-Phase Workflow)

For best results, structure derived items to follow the 4-phase workflow:

1. **Explore** (work_phase: "explore")
   - Research existing code, patterns, dependencies
   - Do NOT write implementation code in this phase

2. **Plan** (work_phase: "plan")
   - Design the approach based on exploration
   - Create implementation plan

3. **Implement** (work_phase: "implement")
   - Execute the plan step by step
   - Reference the plan to stay on track

4. **Commit** (work_phase: "commit")
   - Run tests, verify, commit
   - Update documentation

Not all work requires all phases. Bug fixes may skip exploration.
Simple tasks may skip planning. Use judgment based on complexity.
"""


def get_pattern_guidance(work_type: str) -> str:
    """Get decomposition guidance for work type.

    Args:
        work_type: Detected work type (e.g., 'feature_implementation', 'bug_fix')

    Returns:
        Pattern guidance string for the work type
    """
    return PATTERN_GUIDANCE.get(work_type, PATTERN_GUIDANCE["general"])


def build_four_phase_guidance() -> str:
    """Return the 4-phase workflow guidance block."""
    return FOUR_PHASE_GUIDANCE


def build_refinement_prompt(prose_step2: str, violations: list[str]) -> str:
    """Build the prompt to refine a plan after validation errors.

    Args:
        prose_step2: Step 2 prompt content to include as context
        violations: List of validation error messages

    Returns:
        Refinement prompt string
    """
    return f"""{prose_step2}

## Validation Errors
{chr(10).join(violations)}

Fix these issues in the JSON. Ensure all items have required fields (id, item_type, title, parent_id, depth).
Ensure parent_id references exist in the plan (or null for epics). Ensure depth matches item_type (epic=0, story=1, task=2).
Output raw JSON only. First character must be {{
"""


def build_derivation_prompt(
    objective: str,
    context_section: str,
    work_type: str,
    pattern_guidance: str,
    constraints_section: str,
    four_phase_guidance: str,
) -> str:
    """Build the main derivation prompt.

    Args:
        objective: The task objective to derive a plan for
        context_section: Formatted project context (languages, frameworks, files)
        work_type: Detected work type (e.g., 'feature_implementation')
        pattern_guidance: Work-type specific decomposition guidance
        constraints_section: Constraints and non-goals
        four_phase_guidance: Guidance about the 4-phase workflow

    Returns:
        Formatted derivation prompt string
    """
    return f"""You are an expert software architect. Derive an implementation plan for the following objective.

## Objective
{objective}

## Project Context
{context_section}

## Work Type Detected: {work_type}
{pattern_guidance}

## Constraints
{constraints_section}
{four_phase_guidance}{SIZING_GUIDANCE}
## Instructions
Create a structured implementation plan with the following requirements:
1. Break the objective into logical tasks/stories
2. Each item should be independently testable
3. Order items by dependencies (items that must be done first come first)
4. Be specific about what each item accomplishes
5. Include acceptance criteria for each item
6. Classify each item's work_phase if applicable (explore, plan, implement, commit)
7. Do NOT ask questions or request clarification
8. NEVER run interactive shell commands; if a command would prompt, stop and return an error

## Output Format
Return a JSON object with a "plan_items" array. Each item should have:
- id: Unique identifier (e.g., "T1", "T2")
- item_type: "task" or "story"
- title: Brief title
- description: Detailed description
- acceptance_criteria: Array of criteria strings
- dependencies: Array of item IDs this depends on
- work_phase: "explore" | "plan" | "implement" | "commit" (required - classify each item's phase)
- suggested_agent: "Explore" | null (optional - hint for which Claude Code subagent to use; "Explore" for exploration tasks, null for others)

Example:
```json
{{
  "plan_items": [
    {{
      "id": "T1",
      "item_type": "task",
      "title": "Research existing authentication patterns",
      "description": "Explore the codebase to understand existing auth patterns",
      "acceptance_criteria": [
        "Exploration notes saved to docs/auth/README.md with file paths for existing flows",
        "pytest tests/auth/ passes with 0 failures"
      ],
      "dependencies": [],
      "work_phase": "explore",
      "suggested_agent": "Explore"
    }},
    {{
      "id": "T2",
      "item_type": "task",
      "title": "Implement login endpoint",
      "description": "Create POST /login endpoint that validates credentials",
      "acceptance_criteria": ["Endpoint returns JWT on valid credentials", "Returns 401 on invalid"],
      "dependencies": ["T1"],
      "work_phase": "implement",
      "suggested_agent": null
    }}
  ]
}}
```

Return ONLY the JSON object, no additional text.
"""


def build_step1_prompt(
    objective: str,
    constraints: str,
    context: str,
    intent_markdown: str | None = None,
    exploration_context: str | None = None,
) -> str:
    """Build Step 1 prompt for structure planning (epics and stories).

    Step 1 asks the LLM to decompose the objective into epics and stories.
    Output is prose format, not JSON.

    Args:
        objective: The task objective to plan for
        constraints: Constraints and non-goals
        context: Project context (languages, frameworks, etc.)
        intent_markdown: Optional strategic intent from intent generation
        exploration_context: Optional codebase exploration context

    Returns:
        Prompt string for Step 1 (structure planning)
    """
    intent_section = ""
    if intent_markdown:
        intent_section = f"\n## Strategic Intent\n{intent_markdown}\n"

    exploration_section = ""
    if exploration_context:
        exploration_section = f"\n## Codebase Exploration\n{exploration_context}\n"

    return f"""You are a software architect. Decompose this objective into an implementation plan.

## Objective
{objective}

{intent_section}
{exploration_section}
## Constraints / Non-Goals
{constraints}

## Project Context
{context}

## Instructions

Break down the objective into:
- One or more Epics (major independent workstreams, mutually exclusive and collectively exhaustive)
- Multiple Stories per epic (typically 2-5, each completable in a single focused session; use fewer or more if needed)
- Ensure story acceptance criteria define done, including integration/testing where relevant

For simple objectives, one epic is fine. For complex objectives, identify distinct workstreams.
Prefer valuable, user-facing functionality. Avoid scope bloat, over-engineering, or unnecessary infrastructure unless explicitly required.

## Output Format

Use these exact IDs (E for epic, E#.S# for stories). Do not add tasks or subtasks.

E1: <title>
<description - what this workstream delivers>

  E1.S1: <title>
  <description - what this story delivers>
  Acceptance:
  - <criterion>
  - <criterion>

  E1.S2: <title>
  ...

E2: <title>
...

Output the plan directly. No preamble, no tasks.

Before finalizing, quickly self-check that the epics and stories cover the objective and constraints. Revise once if needed.
"""


def build_step1_epics_template(story_range: str) -> dict[str, Any]:
    """Build JSON template skeleton for Step 1 epic identification.

    Generates a structured template that the LLM populates via file editing,
    eliminating preamble contamination from text responses.

    Args:
        story_range: Story count range string (e.g., "3-6")

    Returns:
        Template dict with epics array and _instructions

    Example:
        >>> template = build_step1_epics_template("3-6")
        >>> template["epics"]
        [{"id": "E1", "title": "<FILL: epic title>", ...}, ...]
    """
    min_epics = int(story_range.split("-")[0])

    epics = []
    for i in range(1, min_epics + 1):
        epics.append({
            "id": f"E{i}",
            "title": "<FILL: epic title>",
            "description": "<FILL: epic description>",
            "acceptance_criteria": ["<FILL: criterion>"]
        })

    return {
        "epics": epics,
        "_instructions": (
            "Decompose the objective into epics (coherent functional areas). "
            "Each epic should deliver a distinct capability. "
            "Epic = 3-15 sessions of work. Story = 1 session of work. "
            "Replace all <FILL:...> placeholders with actual content. "
            "Add more epic entries if needed following the same structure."
        )
    }


def build_step1_epics_only_prompt(
    objective: str,
    constraints: str,
    context: str,
    intent_markdown: str | None = None,
    exploration_context: str | None = None,
    strategic_prompt: str | None = None,
) -> str:
    """Build Step 1 prompt for epic-only structure planning.

    Step 1 asks the LLM to decompose the objective into epics only.
    Output is prose format, not JSON.

    Args:
        objective: The task objective to plan for
        constraints: Constraints and non-goals
        context: Project context (languages, frameworks, etc.)
        intent_markdown: Optional strategic intent from intent generation
        exploration_context: Optional codebase exploration context
        strategic_prompt: Optional sizing guidance (from sizing gate)

    Returns:
        Prompt string for Step 1 (epic-only structure planning)
    """
    intent_section = ""
    if intent_markdown:
        intent_section = f"\n## Strategic Intent\n{intent_markdown}\n"

    exploration_section = ""
    if exploration_context:
        exploration_section = f"\n## Codebase Exploration\n{exploration_context}\n"

    # Include sizing guidance if provided
    sizing_section = ""
    if strategic_prompt:
        sizing_section = f"\n{strategic_prompt}\n"

    return f"""You are a software architect. Decompose this objective into epics only.

## Objective
{objective}

{intent_section}
{exploration_section}
{sizing_section}
## Constraints / Non-Goals
{constraints}

## Project Context
{context}

## Automation Constraints
This plan will be executed autonomously without human interaction:
- Design for automated testing (unit tests, not manual verification)
- Separate core logic from UI/interactive components so logic is testable
- All build/test commands must be non-interactive (no prompts, no GUI required)
- For GUI apps: include headless/testable architecture (logic layer separate from presentation)

## Requirements
- Decompose into coherent functional areas (epics)
- Each epic should deliver a distinct capability
- Prefer fewer well-scoped epics over many thin ones
- Simple objectives may need only 1-2 epics; complex ones may need more
- Do NOT include stories or tasks yet (those come in Step 2)
- Infrastructure/setup should be Epic 1 if needed
- Edit the provided template file following its structural format
"""


def build_step2_prompt(
    objective: str,
    prose_from_step_1: str,
    intent_markdown: str | None = None,
    exploration_context: str | None = None,
) -> str:
    """Build Step 2 prompt for deriving stories and tasks (prose).

    Step 2 asks the LLM to derive stories and implementation tasks for each epic,
    with full epic structure visible. Output is still prose, not JSON.

    Args:
        objective: The original task objective
        prose_from_step_1: The prose output from Step 1 (epics only)
        intent_markdown: Optional strategic intent from intent generation
        exploration_context: Optional codebase exploration context

    Returns:
        Prompt string for Step 2 (task derivation)
    """
    intent_section = ""
    if intent_markdown:
        intent_section = f"\n## Strategic Intent\n{intent_markdown}\n"

    exploration_section = ""
    if exploration_context:
        exploration_section = f"\n## Codebase Exploration\n{exploration_context}\n"

    return f"""You are a software architect. Expand this epic structure into stories and tasks.

## Original Objective
{objective}

{intent_section}
{exploration_section}
## Current Epic Structure
{prose_from_step_1}

## Instructions

### Why Task Decomposition Matters

The execution model works as follows: each task is implemented by a separate LLM session that receives ONLY the task description and acceptance criteria. The executor cannot see the parent story, epic, other tasks, or the original objective. This isolation means:

- If a task combines multiple concerns (e.g., "create component AND add tests AND integrate"), the executor typically completes the first action and produces incomplete work
- Implicit sub-steps get skipped because the executor has no context about what else the story needs
- Broad tasks result in partial implementations that require rework

Break compound work into separate tasks so each can be fully implemented in isolation.

### Automation Constraints

Tasks will be executed autonomously without human interaction:
- Testing must be automated (pytest, unittest) - never "run and manually verify"
- For GUI/game apps: separate logic from presentation so core behavior is unit-testable
- All commands must be non-interactive (no input prompts, no GUI-dependent tests)
- Verification should use assertions and exit codes, not visual inspection

### Task Requirements

For each epic, derive stories and tasks. Each task should:
- Be a focused unit of work (aim for as few files as reasonable, completable in one sitting)
- Have one primary action (create, modify, test, document)
- Include specific file paths and function names only when confident (do not invent)
- Avoid inventing requirements beyond the objective and provided context
- Note cross-story blockers or prerequisites in the task description when relevant
- Do NOT add new epics beyond the provided structure
Favor valuable functionality over optional polish or extra scaffolding unless the objective/constraints call for it.

Important: Avoid duplicating setup or infrastructure tasks across epics. If multiple stories need the same foundation (e.g., test framework setup, shared utilities), place it in the earliest epic/story only.

## Output Format

Preserve the epic structure from the input. For each epic, add stories and tasks using full IDs (E#.S# and E#.S#.T#):

E1: <title>
<description>

  E1.S1: <title>
  <description>
  Acceptance:
  - <criteria>

  Tasks:
    E1.S1.T1: <title>
    <implementation details - files, functions, specifics>
    Acceptance:
    - <criterion>

    E1.S1.T2: <title>
    ...

  E1.S2: <title>
  ...

Output the complete plan with tasks. No preamble, no JSON, no code fences.

Before finalizing, quickly self-check for missing tasks, duplicated infrastructure, or over-scoped tasks. Revise once if needed.
"""


def build_step2_per_epic_prompt(
    objective: str,
    all_epics_prose: str,
    completed_epic_details: list[str],
    target_epic: str,
    target_epic_id: str,
    story_range: str,
    task_range: str,
    intent_markdown: str | None = None,
    exploration_context: str | None = None,
    strict: bool = False,
) -> str:
    """Build Step 2 prompt for deriving stories + tasks for ONE epic.

    The LLM sees full epic structure + all previously completed epic details,
    but only outputs stories/tasks for the target epic.
    """
    intent_section = ""
    if intent_markdown:
        intent_section = f"\n## Strategic Intent\n{intent_markdown}\n"

    exploration_section = ""
    if exploration_context:
        exploration_section = f"\n## Codebase Exploration\n{exploration_context}\n"

    completed_context = ""
    if completed_epic_details:
        completed_context = f"""
## Previously Completed Epics (DO NOT DUPLICATE)
The following epics have already been fully detailed:

{"\n\n".join(completed_epic_details)}

Do not create stories or tasks that duplicate this work.
Infrastructure and setup have already been handled.
"""

    sizing_note = ""
    if strict:
        sizing_note = "- Focus on critical path only\n- Keep output concise to stay under ~3K tokens"

    sizing_block = f"\n{sizing_note}" if sizing_note else ""

    return f"""You are a software architect. Derive stories and tasks for ONE epic.

## Original Objective
{objective}

{intent_section}
{exploration_section}
## Full Epic Structure (READ ONLY)
{all_epics_prose}

{completed_context}
## Your Mission

Derive stories and implementation tasks for THIS EPIC ONLY:
{target_epic}

### Automation Constraints
Tasks will be executed autonomously without human interaction:
- Testing must be automated (unit tests, not manual verification)
- Separate testable logic from interactive/UI components
- All commands must be non-interactive (no prompts or GUI-dependent tests)

### Requirements
- Output {story_range} stories for epic {target_epic_id}
- Each story should have {task_range} focused implementation tasks
- Each task should be a focused unit of work (1-3 files)
- Do NOT derive stories/tasks for other epics
- Do NOT duplicate work from previously completed epics
- Infrastructure/setup belongs in E1.S1 only{sizing_block}
- Prefer a lean task set while still covering all acceptance criteria and explicit constraints.
- Edit the provided template file following its structural format.

### Output Format Contract (Machine-Required)
- Story IDs must use: `{target_epic_id}.S#:`
- Task IDs must use: `{target_epic_id}.S#.T#:`
- Every story must include one or more task IDs under `Tasks:`
- Do not emit IDs from other epics.

### User Story Context
- User stories in strategic intent are requirement-trace context only.
- Use them to inform task content and linked traceability, not as an output format to copy.
"""


def build_step2_per_epic_template(
    target_epic_id: str,
    story_range: str,
    task_range: str,
) -> str:
    """Build a prose template skeleton with <FILL:> placeholders for per-epic derivation.

    Generates a structured template that the LLM populates via file editing,
    eliminating preamble contamination from text responses.

    Args:
        target_epic_id: Epic identifier (e.g., "E2")
        story_range: Story count range string (e.g., "3-6")
        task_range: Task count range string (e.g., "2-5")

    Returns:
        Prose template string with <FILL:> placeholders
    """
    min_stories = int(story_range.split("-")[0])

    lines: list[str] = [
        f"# Derive {story_range} stories for {target_epic_id}, "
        f"each with {task_range} tasks. "
        f"Add more story/task blocks as needed following this pattern.",
        "",
    ]

    for s in range(1, min_stories + 1):
        story_id = f"{target_epic_id}.S{s}"
        lines.extend([
            f"{story_id}: <FILL: story title>",
            "<FILL: story description>",
            "Acceptance:",
            "- <FILL: criterion>",
            f"Linked Stories: <FILL: US-N or none>",
            "",
            "Tasks:",
        ])

        for t in range(1, 3):  # 2 task slots per story
            task_id = f"{story_id}.T{t}"
            lines.extend([
                f"{task_id}: <FILL: task title>",
                "<FILL: implementation details>",
                "Acceptance:",
                "- <FILL: criterion>",
                "",
            ])

    return "\n".join(lines)


def build_step2_repair_prompt(
    objective: str,
    target_epic_id: str,
    incomplete_output: str,
    missing_stories: list[str],
) -> str:
    """Build completion-style repair prompt for missing task decomposition."""
    missing_story_block = "\n".join(f"- {story_id}" for story_id in missing_stories) or "- none listed"
    return f"""You are repairing an incomplete per-epic derivation output.

## Original Objective
{objective}

## Target Epic
{target_epic_id}

## Current Incomplete Output
{incomplete_output}

## Repair Required
The following stories are missing task decomposition:
{missing_story_block}

Add 2-3 focused implementation tasks per listed story using IDs in this format:
- {target_epic_id}.S#.T#:

Rules:
- Keep existing story IDs and story titles.
- Add tasks only; do not rename or remove stories.
- Do not emit IDs from other epics.
- No preamble, no JSON, no code fences.
"""


def build_step2_repair_template(
    target_epic_id: str,
    existing_stories: list[dict[str, str]],
) -> str:
    """Build repair template with existing stories pre-filled and task slots open."""
    lines: list[str] = [
        f"# Repair missing tasks for {target_epic_id}. Keep stories unchanged and add tasks only.",
        "",
    ]

    for story in existing_stories:
        story_id = story.get("id", "").strip()
        story_title = story.get("title", "").strip() or "<FILL: story title>"
        if not story_id:
            continue
        lines.extend([
            f"{story_id}: {story_title}",
            "Tasks:",
            f"{story_id}.T1: <FILL: task title>",
            "<FILL: implementation details>",
            "Acceptance:",
            "- <FILL: criterion>",
            "",
            f"{story_id}.T2: <FILL: task title>",
            "<FILL: implementation details>",
            "Acceptance:",
            "- <FILL: criterion>",
            "",
        ])

    return "\n".join(lines)


def build_step3_prompt(prose_from_step_2: str) -> str:
    """Build Step 3 prompt for JSON serialization.

    Step 3 asks the LLM to convert the complete prose plan (from Step 2)
    into structured JSON matching the plan_items schema.

    Args:
        prose_from_step_2: The prose output from Step 2 (with tasks added)

    Returns:
        Prompt string for Step 3 (JSON serialization)
    """
    return f"""Convert this implementation plan to JSON.

## Plan
{prose_from_step_2}

## Instructions

Create a JSON object with a "plan_items" array containing every epic, story, and task.

Each item must have these fields:
- id: Use IDs from the plan (E1, E1.S1, E1.S1.T1, etc.)
- item_type: "epic" | "story" | "task"
- title: The item title
- description: The item description
- acceptance_criteria: Array of criteria strings (empty array if none specified)
- dependencies: Array of item IDs this depends on (empty array if none)
- parent_id: null for epics, epic ID for stories, story ID for tasks
- depth: 0 for epics, 1 for stories, 2 for tasks
- work_phase: "implement"
- suggested_agent: null
- user_story_ids: Array of user story IDs this item traces to (e.g., ["US-1", "US-3"]). Empty array if no user stories referenced.

## Example Output

{{{{
  "plan_items": [
    {{{{
      "id": "E1",
      "item_type": "epic",
      "title": "User Authentication System",
      "description": "Implement secure user authentication",
      "acceptance_criteria": ["Users can log in", "Sessions persist"],
      "dependencies": [],
      "parent_id": null,
      "depth": 0,
      "work_phase": "implement",
      "suggested_agent": null,
      "user_story_ids": []
    }}}},
    {{{{
      "id": "E1.S1",
      "item_type": "story",
      "title": "Login endpoint",
      "description": "Create POST /login endpoint",
      "acceptance_criteria": ["Returns JWT on success"],
      "dependencies": [],
      "parent_id": "E1",
      "depth": 1,
      "work_phase": "implement",
      "suggested_agent": null,
      "user_story_ids": ["US-1"]
    }}}},
    {{{{
      "id": "E1.S1.T1",
      "item_type": "task",
      "title": "Implement login handler",
      "description": "Add login route in auth.py",
      "acceptance_criteria": ["Validates credentials", "Returns 401 on failure"],
      "dependencies": [],
      "parent_id": "E1.S1",
      "depth": 2,
      "work_phase": "implement",
      "suggested_agent": null,
      "user_story_ids": ["US-1"]
    }}}}
  ]
}}}}

Do not copy example titles or descriptions. Preserve item ordering: epics, then stories, then tasks under each story.
Output raw JSON only. No markdown, no code blocks, no explanation.
First character must be {{ and last character must be }}.
Do NOT wrap the JSON in any other object (no "result", "response", or metadata).
If you output anything other than raw JSON, discard it and output ONLY the JSON object.
JSON ONLY.
"""


def build_step3_per_epic_prompt(epic_prose: str, epic_id: str) -> str:
    """Build Step 3 prompt for serializing a single epic's stories and tasks.

    This is used for per-epic serialization, which improves performance and
    progress visibility compared to serializing all epics in one call.

    Epic items are constructed directly from parsed_epics (no LLM needed).
    Only stories and tasks require LLM serialization.

    Args:
        epic_prose: The prose output for this epic (stories and tasks)
        epic_id: The epic ID (e.g., "E1", "E2")

    Returns:
        Prompt string for per-epic JSON serialization
    """
    return f"""Convert this epic's stories and tasks to JSON.

## Epic {epic_id} Content
{epic_prose}

## Instructions

Create a JSON object with a "plan_items" array containing every story and task for this epic.
Do NOT include the epic itself (only stories and tasks).

Each item must have these fields:
- id: Use IDs from the plan (e.g., {epic_id}.S1, {epic_id}.S1.T1)
- item_type: "story" | "task"
- title: The item title
- description: The item description
- acceptance_criteria: Array of criteria strings (empty array if none specified)
- dependencies: Array of task/subtask IDs that must complete before this item can start (empty array if none). IMPORTANT: Only reference other task or subtask IDs here (e.g., {epic_id}.S1.T1). Do NOT include story or epic IDs — use parent_id for containment relationships.
- parent_id: "{epic_id}" for stories, story ID for tasks
- depth: 1 for stories, 2 for tasks
- work_phase: "implement"
- suggested_agent: null

## Example Output

{{{{
  "plan_items": [
    {{{{
      "id": "{epic_id}.S1",
      "item_type": "story",
      "title": "First story title",
      "description": "Story description",
      "acceptance_criteria": ["Criterion 1"],
      "dependencies": [],
      "parent_id": "{epic_id}",
      "depth": 1,
      "work_phase": "implement",
      "suggested_agent": null
    }}}},
    {{{{
      "id": "{epic_id}.S1.T1",
      "item_type": "task",
      "title": "First task title",
      "description": "Task description",
      "acceptance_criteria": ["Task criterion"],
      "dependencies": [],
      "parent_id": "{epic_id}.S1",
      "depth": 2,
      "work_phase": "implement",
      "suggested_agent": null
    }}}}
  ]
}}}}

Do not copy example titles or descriptions. Use actual content from the epic.
Output raw JSON only. No markdown, no code blocks, no explanation.
First character must be {{ and last character must be }}.
JSON ONLY.
"""


def build_step3_per_epic_prompt_strict(
    epic_prose: str,
    epic_id: str,
    expected_story_count: int,
    expected_task_count: int,
) -> str:
    """Build strict Step 3 prompt for retrying per-epic serialization.

    Used when the initial Step 3 serialization fails. Adds explicit item count
    expectations and stronger JSON constraints to improve parse success rate.

    Args:
        epic_prose: The prose output for this epic (stories and tasks)
        epic_id: The epic ID (e.g., "E1", "E2")
        expected_story_count: Number of stories found in Step 2 prose
        expected_task_count: Number of tasks found in Step 2 prose

    Returns:
        Prompt string for strict per-epic JSON serialization
    """
    total = expected_story_count + expected_task_count
    return f"""STRICT RETRY: Convert this epic's stories and tasks to JSON.
A previous attempt failed to produce valid JSON. Follow these rules exactly.

## Epic {epic_id} Content
{epic_prose}

## Validation Requirements

This epic contains {expected_story_count} stories and {expected_task_count} tasks.
Your output MUST contain exactly {total} items in the "plan_items" array.

## Required Fields (every item MUST have ALL of these)

- "id": string — Use IDs from the plan (e.g., {epic_id}.S1, {epic_id}.S1.T1)
- "item_type": "story" or "task"
- "title": string — The item title from the plan
- "description": string — The item description from the plan
- "acceptance_criteria": array of strings (use [] if none specified)
- "dependencies": array of task/subtask ID strings that must complete before this item starts (use [] if none). Only reference task or subtask IDs (e.g., {epic_id}.S1.T1). Never include story or epic IDs in dependencies.
- "parent_id": "{epic_id}" for stories, story ID (e.g., {epic_id}.S1) for tasks
- "depth": 1 for stories, 2 for tasks
- "work_phase": "implement"
- "suggested_agent": null

## Output Rules

1. Output ONLY a JSON object. No text before or after.
2. First character must be {{{{ and last character must be }}}}.
3. The object has exactly one key: "plan_items".
4. "plan_items" is an array of exactly {total} objects.
5. Every object has ALL 10 fields listed above.
6. Do not omit any field. Do not add extra fields.

JSON ONLY. No markdown. No code blocks. No explanation.
"""
