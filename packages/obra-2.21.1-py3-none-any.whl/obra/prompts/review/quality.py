"""LLM prompt template for UserPlan quality assessment.

This module provides the prompt template that instructs an LLM to assess
the quality of a UserPlan based on various criteria and return a structured
score with improvement hints.

The assessment evaluates:
    1. Task clarity and specificity
    2. Proper dependency sequencing
    3. Completeness of acceptance criteria
    4. Technical feasibility indicators
    5. Missing context or ambiguities

Output Format:
    JSON object with the following structure:
    {
        "score": float (0.0-1.0),
        "hints": [str]  # Improvement suggestions
    }

Related:
    - obra/schemas/userplan_schema.py (UserPlan, QualityStatus)
    - obra/execution/prompts/intent_to_plan.py (similar prompt patterns)
"""

from typing import Any

# Quality assessment criteria descriptions
QUALITY_CRITERIA = """
Quality Assessment Criteria:

1. **Task Clarity and Specificity** (Weight: 25%)
   - Each task should have a clear, action-oriented title
   - Descriptions should explain WHAT needs to be done, not just repeat the title
   - Tasks should be specific enough to estimate and verify completion
   - Avoid vague language ("improve", "enhance", "optimize" without specifics)

2. **Dependency Sequencing** (Weight: 20%)
   - Tasks should be ordered by logical dependencies
   - Prerequisites should appear before dependent tasks
   - No circular dependencies implied by ordering
   - Related tasks should be grouped appropriately

3. **Acceptance Criteria Completeness** (Weight: 25%)
   - Each task should have verifiable success criteria
   - Criteria should be measurable and testable
   - Deliverables should be concrete and identifiable
   - Avoid subjective criteria ("works well", "looks good")

4. **Technical Feasibility** (Weight: 15%)
   - Tasks should be technically achievable
   - No impossible or contradictory requirements
   - Appropriate scope for individual tasks (not too large, not too small)
   - Technical requirements should be realistic

5. **Context and Completeness** (Weight: 15%)
   - Sufficient context for implementation
   - No critical gaps or missing information
   - Assumptions are stated where relevant
   - Constraints are identified
"""

# Main quality assessment prompt template
QUALITY_ASSESSMENT_PROMPT = """You are an expert software architect and project planner. Your task is to assess the quality of a UserPlan and provide a score with improvement hints.

## UserPlan to Assess

**Plan ID**: {plan_id}
**Work Type**: {work_type}
**Total Steps**: {step_count}

### Plan Context
{context_section}

### Steps
{steps_section}

## Assessment Criteria
{criteria}

## Your Task

Evaluate the UserPlan against each criterion and provide:

1. **Overall Score** (0.0 to 1.0):
   - 0.0-0.3: Poor quality, significant issues that block derivation
   - 0.3-0.5: Below average, multiple areas need improvement
   - 0.5-0.7: Acceptable, some improvements recommended
   - 0.7-0.9: Good quality, minor improvements possible
   - 0.9-1.0: Excellent quality, ready for derivation

2. **Improvement Hints**: Specific, actionable suggestions to improve the plan.
   - Focus on the most impactful improvements
   - Be specific about which tasks or aspects need work
   - Provide concrete suggestions, not vague advice
   - Limit to 3-7 hints (prioritize the most important)

## Scoring Guidelines

For each criterion, assess:
- Task Clarity (25%): Are tasks specific and actionable?
- Dependency Sequencing (20%): Is the order logical?
- Acceptance Criteria (25%): Can completion be verified?
- Technical Feasibility (15%): Are tasks achievable?
- Context Completeness (15%): Is there enough information?

## Common Issues to Flag

- Tasks that are too vague ("Set up infrastructure" without specifics)
- Missing acceptance criteria or deliverables
- Tasks that are too large (should be split)
- Tasks that are too small (should be combined)
- Unclear dependencies or sequencing issues
- Missing technical context or constraints
- Ambiguous requirements that need clarification
- Potential technical blockers or risks not addressed

## Output Format

Return ONLY a valid JSON object with this exact structure:

```json
{{
  "score": 0.75,
  "hints": [
    "Specific improvement suggestion 1",
    "Specific improvement suggestion 2",
    "Specific improvement suggestion 3"
  ]
}}
```

**Important**:
- Return ONLY the JSON object, no additional text before or after
- Ensure the JSON is valid and parseable
- Score must be a float between 0.0 and 1.0
- Hints must be an array of strings (3-7 items recommended)
- Each hint should be actionable and specific
- Do not include comments in the JSON
"""


def _format_step(step: dict[str, Any], index: int) -> str:
    """Format a single step for the prompt.

    Args:
        step: Step dictionary with title, description, etc.
        index: 1-based step index

    Returns:
        Formatted step string
    """
    lines = [f"**Step {index}: {step.get('title', 'Untitled')}**"]

    description = step.get("description", "")
    if description:
        lines.append(f"Description: {description}")

    # Format context if present
    context = step.get("context", {})
    if context:
        if context.get("deliverables"):
            deliverables = ", ".join(context["deliverables"])
            lines.append(f"Deliverables: {deliverables}")

        if context.get("success_criteria"):
            lines.append(f"Success Criteria: {context['success_criteria']}")

        if context.get("requirements"):
            requirements = ", ".join(context["requirements"])
            lines.append(f"Requirements: {requirements}")

    lines.append("")  # Empty line between steps
    return "\n".join(lines)


def _format_steps_section(steps: list[dict[str, Any]]) -> str:
    """Format all steps for the prompt.

    Args:
        steps: List of step dictionaries

    Returns:
        Formatted steps section string
    """
    if not steps:
        return "No steps defined."

    formatted_steps = []
    for i, step in enumerate(steps, start=1):
        formatted_steps.append(_format_step(step, i))

    return "\n".join(formatted_steps)


def _format_context_section(context: dict[str, Any] | None) -> str:
    """Format the plan context section.

    Args:
        context: Plan-level context dictionary

    Returns:
        Formatted context section string
    """
    if not context:
        return "No plan-level context provided."

    lines = []

    if context.get("deliverables"):
        deliverables = ", ".join(context["deliverables"])
        lines.append(f"- Overall Deliverables: {deliverables}")

    if context.get("success_criteria"):
        lines.append(f"- Success Criteria: {context['success_criteria']}")

    if context.get("requirements"):
        requirements = ", ".join(context["requirements"])
        lines.append(f"- Requirements: {requirements}")

    if context.get("tech_stack"):
        tech_stack = ", ".join(context["tech_stack"])
        lines.append(f"- Tech Stack: {tech_stack}")

    if context.get("constraints"):
        constraints = ", ".join(context["constraints"])
        lines.append(f"- Constraints: {constraints}")

    if context.get("assumptions"):
        assumptions = ", ".join(context["assumptions"])
        lines.append(f"- Assumptions: {assumptions}")

    return "\n".join(lines) if lines else "No plan-level context provided."


def build_quality_assessment_prompt(
    plan_id: str,
    work_type: str | None,
    steps: list[dict[str, Any]],
    context: dict[str, Any] | None = None,
) -> str:
    """Build the LLM prompt for UserPlan quality assessment.

    Args:
        plan_id: UserPlan identifier
        work_type: Type of work (feature_implementation, bug_fix, etc.)
        steps: List of step dictionaries with title, description, context
        context: Optional plan-level context dictionary

    Returns:
        Formatted prompt string ready for LLM invocation

    Example:
        >>> steps = [
        ...     {
        ...         "title": "Create user model",
        ...         "description": "Define SQLAlchemy model for User",
        ...         "context": {"deliverables": ["user.py model file"]}
        ...     }
        ... ]
        >>> prompt = build_quality_assessment_prompt(
        ...     plan_id="UP-20260115-add-auth",
        ...     work_type="feature_implementation",
        ...     steps=steps
        ... )
    """
    steps_section = _format_steps_section(steps)
    context_section = _format_context_section(context)

    return QUALITY_ASSESSMENT_PROMPT.format(
        plan_id=plan_id,
        work_type=work_type or "not specified",
        step_count=len(steps),
        context_section=context_section,
        steps_section=steps_section,
        criteria=QUALITY_CRITERIA,
    )


# Export convenience for testing and usage
__all__ = [
    "QUALITY_ASSESSMENT_PROMPT",
    "QUALITY_CRITERIA",
    "build_quality_assessment_prompt",
]
