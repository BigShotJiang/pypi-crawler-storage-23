"""Prompt builders for template edit instructions."""

from __future__ import annotations

from pathlib import Path

__all__ = ["build_template_edit_prompt", "build_template_edit_prompt_text"]


def build_template_edit_prompt(
    base_prompt: str,
    template_path: Path | str,
    task_verb: str = "findings",
) -> str:
    """Build the prompt to instruct an LLM to edit a template file.

    Args:
        base_prompt: Original task prompt
        template_path: Path to the template file to edit (relative or absolute)

    Returns:
        Augmented prompt with file editing instructions
    """
    return (
        f"{base_prompt}\n\n"
        f"IMPORTANT: Edit the file {template_path} to apply your {task_verb}. "
        f"Populate the structure with your analysis. "
        f"Do not remove keys; keep all fields and use empty lists when needed. "
        f"Use strict JSON syntax only: double-quoted keys/strings, no trailing commas, "
        f"no comments, and no code fences or extra prose. "
        f"DO NOT respond with prose - only edit the file."
    )


def build_template_edit_prompt_text(base_prompt: str, template_path: Path | str) -> str:
    """Build the prompt to instruct an LLM to edit a prose template file.

    Used for natural language (prose) template editing where the template
    contains <FILL:...> placeholders to be replaced with actual content.

    Args:
        base_prompt: Original task prompt
        template_path: Path to the template file to edit (relative or absolute)

    Returns:
        Augmented prompt with text editing instructions
    """
    return (
        f"{base_prompt}\n\n"
        f"IMPORTANT: Edit the file {template_path} to populate it with your output. "
        f"Replace all <FILL: ...> placeholders with actual content. "
        f"Preserve the structural format (ID prefixes, section headings, acceptance criteria bullets). "
        f"Do not add text before or after the structured content. "
        f"DO NOT respond with prose — only edit the file."
    )
