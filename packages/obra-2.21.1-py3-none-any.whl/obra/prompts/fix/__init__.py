"""Fix and issue context prompts.

This package contains prompts for building fix contexts:
- context: Batch and issue-specific fix context builders
"""

from __future__ import annotations

# Define lazy-loaded exports
_SUBMODULE_EXPORTS = {
    # context.py exports
    "build_batch_fix_context": ".context",
    "build_issue_specific_context": ".context",
    "build_test_gap_issue_context": ".context",
    "build_test_gap_batch_context": ".context",
    "build_test_gap_inference_prompt": ".context",
}

__all__ = list(_SUBMODULE_EXPORTS.keys())


def __getattr__(name: str):
    """PEP 562 lazy loading for submodule exports."""
    if name in _SUBMODULE_EXPORTS:
        from importlib import import_module

        module_name = _SUBMODULE_EXPORTS[name]
        module = import_module(module_name, package=__name__)
        return getattr(module, name)
    msg = f"module {__name__!r} has no attribute {name!r}"
    raise AttributeError(msg)


def __dir__():
    """List available exports."""
    return __all__
