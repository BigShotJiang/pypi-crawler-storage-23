__version__ = "0.8.9"
__author__ = "Verlex Team"

import copyreg as _copyreg
import _thread as _thread_mod
import threading as _threading


def _reduce_lock(lock):
    return (_rebuild_lock, (lock.locked(),))


def _rebuild_lock(locked):
    lk = _threading.Lock()
    if locked:
        lk.acquire(blocking=False)
    return lk


_copyreg.pickle(_thread_mod.LockType, _reduce_lock)


def _reduce_rlock(rlock):
    try:
        count = int(repr(rlock).split("count=")[1].split()[0].rstrip(">"))
    except (IndexError, ValueError):
        count = 0
    return (_rebuild_rlock, (count,))


def _rebuild_rlock(count):
    rl = _threading.RLock()
    for _ in range(count):
        rl.acquire()
    return rl


_copyreg.pickle(_thread_mod.RLock, _reduce_rlock)


def _reduce_event(event):
    return (_rebuild_event, (event.is_set(),))


def _rebuild_event(is_set):
    e = _threading.Event()
    if is_set:
        e.set()
    return e


_copyreg.pickle(_threading.Event, _reduce_event)


def _reduce_condition(cond):
    is_rlock = isinstance(cond._lock, _thread_mod.RLock)
    return (_rebuild_condition, (is_rlock,))


def _rebuild_condition(is_rlock):
    lock = _threading.RLock() if is_rlock else _threading.Lock()
    return _threading.Condition(lock)


_copyreg.pickle(_threading.Condition, _reduce_condition)


def _reduce_semaphore(sem):
    return (_rebuild_semaphore, (sem._value,))


def _rebuild_semaphore(value):
    return _threading.Semaphore(value)


_copyreg.pickle(_threading.Semaphore, _reduce_semaphore)


def _reduce_bounded_semaphore(sem):
    return (_rebuild_bounded_semaphore, (sem._initial_value, sem._value))


def _rebuild_bounded_semaphore(initial, current):
    bs = _threading.BoundedSemaphore(initial)
    for _ in range(initial - current):
        bs.acquire(blocking=False)
    return bs


_copyreg.pickle(_threading.BoundedSemaphore, _reduce_bounded_semaphore)


def _reduce_barrier(barrier):
    return (_rebuild_barrier, (barrier._parties, barrier._action, barrier._timeout))


def _rebuild_barrier(parties, action, timeout):
    return _threading.Barrier(parties, action=action, timeout=timeout)


_copyreg.pickle(_threading.Barrier, _reduce_barrier)

from verlex.client import (
    AsyncJob,
    AuthSession,
    GateWay,
    JobResult,
    auth,
    cloud,
    get_session,
    logout,
    whoami,
)
from verlex.overflow import overflow
from verlex.agent import AgentDaemon, ProcessScanner, submit_code
from verlex.errors import (
    AuthenticationError,
    ConfigurationError,
    ExecutionError,
    GPUUnavailableError,
    InsufficientCreditsError,
    InvalidAPIKeyError,
    JobFailedError,
    JobTimeoutError,
    NetworkError,
    NotAuthenticatedError,
    QuotaExceededError,
    RateLimitError,
    SerializationError,
    VerlexError,
)

__all__ = [
    "__version__",
    "__author__",
    "GateWay",
    "AsyncJob",
    "JobResult",
    "AuthSession",
    "auth",
    "logout",
    "whoami",
    "get_session",
    "cloud",
    "overflow",
    "AgentDaemon",
    "ProcessScanner",
    "submit_code",
    "VerlexError",
    "ExecutionError",
    "AuthenticationError",
    "NotAuthenticatedError",
    "InvalidAPIKeyError",
    "InsufficientCreditsError",
    "QuotaExceededError",
    "GPUUnavailableError",
    "JobFailedError",
    "JobTimeoutError",
    "SerializationError",
    "NetworkError",
    "RateLimitError",
    "ConfigurationError",
]
