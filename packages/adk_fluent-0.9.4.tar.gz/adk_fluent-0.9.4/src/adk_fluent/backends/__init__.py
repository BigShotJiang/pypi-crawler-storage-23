"""Backend protocol and implementations for adk-fluent IR compilation."""

from adk_fluent.backends._protocol import Backend, final_text

__all__ = ["Backend", "final_text"]
