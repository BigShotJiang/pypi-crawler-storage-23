"""Single source of truth for adk-fluent version."""

__version__ = "0.9.4"
