# Match-V5
get_list_of_match_ids_by_puuid = "https://{server_addr}/lol/match/v5/matches/by-puuid/{puuid}/ids"
get_match_by_id = "https://{server_addr}/lol/match/v5/matches/{match_id}"
get_match_timeline_by_id = "https://{server_addr}/lol/match/v5/matches/{match_id}/timeline"
