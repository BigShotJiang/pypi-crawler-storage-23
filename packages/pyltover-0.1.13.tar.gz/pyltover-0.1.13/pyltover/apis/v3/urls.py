# Champion-V3
get_champion_rotaions = "https://{server_addr}/lol/platform/v3/champion-rotations"
