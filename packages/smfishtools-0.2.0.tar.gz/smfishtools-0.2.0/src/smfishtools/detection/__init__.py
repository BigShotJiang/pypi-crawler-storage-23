# -*- coding: utf-8 -*-
# Author: Floric Slimani <floric.slimani@live.fr>


"""
This smfishtools subpackage wrapers around bigfish.detection subpackage.
"""

from .wrapper import full_detection
from .bigfish_wrapper import spot_decomposition_nobckgrndrmv, cluster_deconvolution
from .bigfish_wrapper import detect_spots, iter_detect_spots, compute_auto_threshold
from .clusters import cluster_detection, get_centroids_list, get_centroids_array, remove_artifact, add_cell_tag
from .centrosome import detect_centrosome
from .multithread import multi_thread_cell_quantification, multi_thread_full_detection

try :
    from .ufish import init_ufish_model, infer_spots
except ModuleNotFoundError :
    pass