import numpy as np
import pandas as pd
from skimage.measure import regionprops_table, regionprops


def detect_centrosome(cell, max_number_candidates = 5) :
    min_y,min_x,max_y,max_x = cell['bbox']
    cell_mask = cell["cell_mask"]
    
    #Brightest spot
    coords = []
    candidate_coords = cell.setdefault("centrosome_spots",np.empty(shape=(0,0), dtype=int))

    if len(candidate_coords) == 0 or len(candidate_coords) > max_number_candidates : # if no spot detected or too many (likely to be noise) cell is skiped
        return np.empty(shape=(0,0), dtype=int)
    signal = cell["centrosome_mip"]
    Z,Y,X = zip(*candidate_coords)
    intensity_array = signal[Y,X]

    #1st centrosome
    max_index_1 = np.argmax(intensity_array)
    intensity_1 = intensity_array[max_index_1]
    coords.append([Z[max_index_1], Y[max_index_1], X[max_index_1]])

    #opt 2nd centrosome : if spot in a 10% range of intensity
    intensity_array[max_index_1] = 0
    max_index_2 = np.argmax(intensity_array)
    intensity_2 = intensity_array[max_index_2]
    if intensity_2 > intensity_1*0.9 :
        coords.append([Z[max_index_2], Y[max_index_2], X[max_index_2]])
    return np.array(coords, dtype= int)
