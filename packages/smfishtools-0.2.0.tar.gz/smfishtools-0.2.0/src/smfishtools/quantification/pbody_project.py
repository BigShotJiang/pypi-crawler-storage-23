import warnings
import pandas as pd

def from_spike_value_compute_CellullarCycleGroup(Cell: pd.DataFrame, spikeg1: float= 2.2e7)-> pd.DataFrame :
    """
    Add a new column to Cell DataFrame : "Cellular Cycle Group" which sorts cells between the g1 phase and g2 phase.
    """
    measurement = "nucleus_mean_mean_signal"
    new_Cell = Cell.copy()
    measure = Cell.loc[:, measurement]/spikeg1
    new_Cell["Mean signal / spike"] = measure
    new_Cell.loc[:,new_Cell["Mean signal / spike"] >= 1.5] = 'g2'
    new_Cell.loc[:,new_Cell["Mean signal / spike"] < 1.5] = 'g1'

    return new_Cell



def from_nucleus_malat_proportion_compute_CellullarCycleGroup(Cell: pd.DataFrame, threshold = 0.5)-> pd.DataFrame :

    """
    creates column : 'Cellular_cycle (malat proportion)' ; 'malat proportion in nucleus'
    """
    proportion = Cell.loc[:, "malat1 spots in nucleus"] / (Cell.loc[:, "malat1 spots in nucleus"] + Cell.loc[:, "malat1 spots in cytoplasm"])
    new_Cell = Cell.copy()
    new_Cell["malat proportion in nucleus"] = proportion
    new_Cell["Cellular_cycle (malat proportion)"] = 'g1'
    index = new_Cell.query("`malat proportion in nucleus` > {0}".format(threshold)).index
    new_Cell.loc[index,["Cellular_cycle (malat proportion)"]] = 'g2'

    return new_Cell

def from_IntegratedSignal_ranking_compute_CellularCycleGroup(Cell_raw: pd.DataFrame, g1 = 0.502, s = 0.225, g2 = 0.165, column_name= 'cellular_cycle') :
    """
    Default value are for Hek Cells : g1 = 0.53, s = 0.22, g2 = 0.25
    New key : column_name (default = 'cellular_cycle')
    """
    if column_name in Cell_raw.index : 
        warnings.warn("{0} column already in dataframe, returning dataframe unchanged.".format(column_name))
        return Cell_raw
    
    if g1 >1 or g2>1 or s > 1 : raise ValueError("g1, g2 and s must be defined between 0 and 1")
    if g1 <0 or g2<0 or s < 0 : raise ValueError("g1, g2 and s must be defined between 0 and 1")
    if g1 + g2 + s > 1 : raise ValueError("g1+g2+s should equal 1 or be inferior to 1.")

    Cell = Cell_raw.copy()
    if 'rna name' in Cell.index.names :
        level = Cell.index.names.index("rna name")
        rna_list = Cell.index.get_level_values(level).unique()
    elif 'rna name' in Cell.columns : 
        rna_list = Cell.value_counts(subset= 'rna name').index
    else :    
        raise Exception("rna name column wasn't found in Cell DataFrame consider using update.AddRnaName")
    
    if "IntegratedSignal" not in Cell.columns :
        Cell = compute_IntegratedSignal(Cell)
    
    for rna in rna_list :
        
        rna_idx = Cell.query("`rna name` == '{0}'".format(rna)).index

        if g1 + g2 + s == 1 :
            Cell.loc[rna_idx,column_name] = "s"
        else : 
            Cell.loc[rna_idx,column_name] = np.nan
            if s != 0 :
                limit_inf = g1 + (1 - g1 - g2 - s)/2
                limit_sup = 1 - g2 - (1 - g1 - g2 - s)/2
                assert limit_inf < 1 and limit_sup < 1
                assert limit_inf >= 0 and limit_sup >= 0
                quantile_inf = float(Cell.loc[rna_idx,["IntegratedSignal"]].quantile(limit_inf))
                quantile_sup = float(Cell.loc[rna_idx,["IntegratedSignal"]].quantile(limit_sup))
                s_idx = Cell.loc[rna_idx,:].query("IntegratedSignal >= {0} and IntegratedSignal < {1}".format(quantile_inf,quantile_sup)).index
                Cell.loc[s_idx, column_name] = "s"

        g1_quantile = float(Cell.loc[rna_idx,["IntegratedSignal"]].quantile(g1))
        g1_idx = Cell.loc[rna_idx,:].query("IntegratedSignal < {0}".format(g1_quantile)).index
        g2_quantile = float(Cell.loc[rna_idx,["IntegratedSignal"]].quantile(1-g2))
        g2_idx = Cell.loc[rna_idx,:].query("IntegratedSignal >= {0}".format(g2_quantile)).index
        Cell.loc[g1_idx, [column_name]] = "g1"
        Cell.loc[g2_idx, [column_name]] = "g2"

    return Cell


def from_IntegratedSignal_spike_compute_CellularCycleGroup(Cell : pd.DataFrame, column_name= 'cellular_cycle', shift = -0.12e12, auto_shift= True, multiplicator = 2, bins= 100,) :

    """
    Add new column to Cell DF : column_name (default = 'cellular_cycle')
        Values can be either one of ['g1', 'g2' or np.nan]
    """
    if column_name in Cell.index : 
        warnings.warn("{0} column already in dataframe, returning dataframe unchanged.".format(column_name))
        return Cell

    Cell[column_name] = np.nan
    if "IntegratedSignal" not in Cell.columns :
        Cell.loc[:,["IntegratedSignal"]] = Cell['nucleus_mean_mean_signal'] * Cell["nucleus area (nm^2)"]
    distribution = Cell["IntegratedSignal"]
    median_value = np.median(Cell['IntegratedSignal'])
    maximum_value = hist_maximum(np.histogram(distribution, bins=bins))
    box_size = abs(median_value - maximum_value)

    if auto_shift : shift = (-np.percentile(distribution, 0.5)/2)

    g2_spike = (maximum_value + shift)*multiplicator


    indexg1 = Cell[Cell["IntegratedSignal"] < maximum_value + box_size].index
    indexg2 = Cell[Cell["IntegratedSignal"] > g2_spike].index

    Cell.loc[indexg1,column_name] = 'g1'
    Cell.loc[indexg2,column_name] = 'g2'


    return Cell

def from_IntegratedSignal_distribution_compute_Cellular_CycleGroup(Cell: pd.DataFrame, g1_interval = [7e7,9.5e7], g2_interval= [1.5e8,2e8], drop_IntegratedSignal = False):

    check_parameter(Cell = (pd.DataFrame), g1_interval = (list, tuple), g2_interval = (list, tuple))
    if len(g1_interval) != 2 : raise ValueError("g1_interval : expected length 2 : g1min, g1max")
    if len(g2_interval) != 2 : raise ValueError("g2_interval : expected length 2 : g2min, g2max")

    if "IntegratedSignal" not in Cell.columns : Cell["IntegratedSignal"] = Cell["nucleus_mean_mean_signal"] * Cell["nucleus area (nm^2)"]

    g1min, g1max = g1_interval
    g2min, g2max = g2_interval

    Cell["cellular_cycle"] = np.nan
    Cell[np.logical_and(Cell["IntegratedSignal"] >= g1min, Cell["IntegratedSignal"] <= g1max)]["cellular_cycle"] = "g1"
    Cell[np.logical_and(Cell["IntegratedSignal"] >= g2min, Cell["IntegratedSignal"] <= g2max)]["cellular_cycle"] = "g2"
    Cell[np.logical_and(Cell["IntegratedSignal"] > g1max, Cell["IntegratedSignal"] < g2min)]["cellular_cycle"] = "?"

    if drop_IntegratedSignal : Cell = Cell.drop(columns= "IntegratedSignal", axis= 1)
    return Cell