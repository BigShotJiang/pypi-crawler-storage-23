class QuantificationError(Exception) :
    pass