"""
This submodule contains functions to compute features related to fov wide measurement.
"""
import numpy as np
import pandas as pd
from bigfish.stack import mean_projection
from .measures import compute_signalmetrics


def newframe_Acquisitions(pk= None, rootfilename= None, rna_name=None, cell_number=None, RNA_spot_threshold= None, malat1_spot_threshold= None, background_dapi_signal_mean=None, background_dapi_signal_std= None, **kwargs) :
    """Returns an empty pandas DataFrame with expected Acquisition data shape
        id (int, primary key) : Unique identifier to each acquisition
        filenameroot (str) : root of the file name meaning the part shared by all chanels filenames. 
    """

    if type(pk) == type(None) : pk= []
    if type(rootfilename) == type(None) : rootfilename= np.nan
    if type(rna_name) == type(None) : rna_name= np.nan
    if type(cell_number) == type(None) : cell_number= np.nan
    if type(RNA_spot_threshold) == type(None) : RNA_spot_threshold= np.nan
    if type(malat1_spot_threshold) == type(None) : malat1_spot_threshold= np.nan
    if type(background_dapi_signal_mean) == type(None) : background_dapi_signal_mean= np.nan
    if type(background_dapi_signal_std) == type(None) : background_dapi_signal_std = np.nan


    dic = {
        "id" : pk, 
        "rootfilename" : rootfilename,
        "rna name" : rna_name,
        "cell number" : cell_number,
        "RNA spot threshold" : RNA_spot_threshold,
        "malat1 spot threshold" : malat1_spot_threshold,
        "background dapi signal mean" : background_dapi_signal_mean,
        "background dapi signal std" : background_dapi_signal_std
        }

    dic_Acquisition = dict(dic, **kwargs)
    res = pd.DataFrame(dic_Acquisition)    
    return(res)

def compute_fov(acquisition_id, rootfilename:str, rna_name:str, cell_number: int, rna_threshold:float, malat_threshold:float, dapi: np.ndarray, nucleus_mask: np.ndarray) :
    """Returns DataFrame with expected Acquisition datashape containing all acquisition (fov) level features."""

    if dapi.ndim == 3 : 
        dapi = mean_projection(dapi)
    elif dapi.ndim == 2 :
        pass
    else: raise ValueError("dapi signal should either be a 2D or 3D np.ndarray.")
    if nucleus_mask.dtype != bool : raise TypeError("nucleus mask should be of dtype bool.")
    
    
    dapi_backgrnd_metrics = compute_signalmetrics(dapi, ~nucleus_mask)

    new_Acquisition = newframe_Acquisitions()
    new_Acquisition["id"] = [acquisition_id]
    new_Acquisition["rootfilename"] = [rootfilename]
    new_Acquisition["rna name"] = [rna_name]
    new_Acquisition["cell number"] = [cell_number]
    new_Acquisition["RNA spot threshold"] = [rna_threshold]
    new_Acquisition["malat1 spot threshold"] = [malat_threshold]
    new_Acquisition["background dapi signal mean"] = dapi_backgrnd_metrics['mean']
    new_Acquisition["background dapi signal std"] = dapi_backgrnd_metrics['std']
    
    
    return new_Acquisition