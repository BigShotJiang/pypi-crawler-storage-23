"""Phase 5: Post-docking analysis.

CNNscore filter -> ProLIF interaction profiling -> min_interactions filter
              -> rank by CNNaffinity -> write CSV.
"""

from __future__ import annotations

import logging
import warnings
from dataclasses import dataclass
from pathlib import Path

import pandas as pd

log = logging.getLogger("wtfdtb.post_dock")


@dataclass
class InteractionProfile:
    """Interaction counts for one docked pose."""

    hbond_donor: int = 0
    hbond_acceptor: int = 0
    hydrophobic: int = 0
    pi_stacking: int = 0
    salt_bridge: int = 0

    @property
    def total(self) -> int:
        return (
            self.hbond_donor
            + self.hbond_acceptor
            + self.hydrophobic
            + self.pi_stacking
            + self.salt_bridge
        )


def analyze_and_rank(
    docking_results: list,
    receptor_paths: dict[str, Path],
    cnn_score_threshold: float = 0.5,
    min_interactions: int = 1,
    output_csv: Path = Path("results.csv"),
) -> pd.DataFrame:
    """Filter, profile, rank, and write the final results CSV."""
    if not docking_results:
        log.warning("Nothing to analyze")
        return pd.DataFrame()

    rows = [
        {
            "pdb_id": r.pdb_id,
            "pocket": r.pocket_name,
            "pose_rank": r.pose_rank,
            "cnn_score": r.cnn_score,
            "cnn_affinity": r.cnn_affinity,
            "vina_affinity": r.vina_affinity,
            "pose_sdf": r.pose_sdf,
        }
        for r in docking_results
    ]
    df = pd.DataFrame(rows)
    log.info("Total poses: %d", len(df))

    # CNN score hard filter
    df = df[df["cnn_score"] >= cnn_score_threshold].copy()
    log.info("After CNNscore >= %.2f: %d", cnn_score_threshold, len(df))

    if df.empty:
        _write_empty_csv(output_csv)
        return df

    # interaction profiling — precompute protein Universe per PDB once
    profiles = []
    prot_cache: dict = {}  # pdb_id -> (mda.Universe, prolif.Fingerprint)
    for _, row in df.iterrows():
        rec = receptor_paths.get(row["pdb_id"])
        if rec and min_interactions > 0:
            if row["pdb_id"] not in prot_cache:
                prot_cache[row["pdb_id"]] = _build_protein_universe(rec)
            prot_u, fp = prot_cache[row["pdb_id"]]
            profiles.append(_profile_interactions(row["pose_sdf"], prot_u, fp))
        else:
            profiles.append(InteractionProfile())

    df["hbond"] = [p.hbond_donor + p.hbond_acceptor for p in profiles]
    df["hydrophobic"] = [p.hydrophobic for p in profiles]
    df["pi_stacking"] = [p.pi_stacking for p in profiles]
    df["salt_bridge"] = [p.salt_bridge for p in profiles]
    df["total_interactions"] = [p.total for p in profiles]

    if min_interactions > 0:
        df = df[df["total_interactions"] >= min_interactions].copy()
        log.info("After min_interactions >= %d: %d", min_interactions, len(df))

    # **Critical Ranking Logic Change**
    # CNN affinity (pKd) produces false positives with terrible steric clashes
    # (e.g. +7.8 kcal/mol Vina score). We MUST prioritize empirical Vina affinity
    # (kcal/mol, lower is better) over CNN affinity to ensure physical plausibility.
    df = df.sort_values(by=["vina_affinity", "cnn_affinity"], ascending=[True, False]).reset_index(
        drop=True
    )
    df.index = df.index + 1
    df.index.name = "rank"

    out_df = df.drop(columns=["pose_sdf"])
    output_csv.parent.mkdir(parents=True, exist_ok=True)
    out_df.to_csv(output_csv)
    log.info("Wrote %s (%d rows)", output_csv, len(out_df))

    return df


def _fix_gnina_mol_block(block: str) -> str:
    """Ensure the mol block has the 3-line header that RDKit expects.

    GNINA/OpenBabel writes only 2 header lines (title + blank) instead
    of the standard 3 (title + program-timestamp + comment).  RDKit's
    MolFromMolBlock reads line 0 as title, line 1 as program info,
    line 2 as comment, and line 3 as the counts line.  With only 2
    header lines the counts line is swallowed as the comment and the
    first atom line is mis-parsed as counts → parsing fails.
    """
    lines = block.split("\n")
    for i, line in enumerate(lines[:10]):
        if "V2000" in line or "V3000" in line:
            if i < 3:
                return "\n" * (3 - i) + block
            return block
    return block


def _build_protein_universe(receptor_pdb: Path):
    """Load protein PDB once, guess elements, build ProLIF fingerprint.

    Returns (mda.Universe, prolif.Fingerprint) — reuse across all poses
    of the same receptor to avoid the expensive protein conversion overhead.
    """
    import MDAnalysis as mda
    import prolif

    prot = mda.Universe(str(receptor_pdb))
    if not hasattr(prot.atoms, "elements") or len(prot.atoms.elements) == 0:
        prot.guess_TopologyAttrs(to_guess=["elements"])

    fp = prolif.Fingerprint(
        interactions=[
            "HBDonor",
            "HBAcceptor",
            "Hydrophobic",
            "PiStacking",
            "CationPi",
            "Anionic",
            "Cationic",
        ]
    )
    return prot, fp


def _profile_interactions(pose_sdf: str, prot_u, fp) -> InteractionProfile:
    """Count protein-ligand interactions with ProLIF.

    The protein MDAnalysis Universe and ProLIF Fingerprint are prebuilt and
    shared across all poses of the same receptor (see _build_protein_universe).
    """
    try:
        import MDAnalysis as mda
        from rdkit import Chem

        fixed_sdf = _fix_gnina_mol_block(pose_sdf)
        # GNINA SDFs are 3D; ensure RDKit knows this
        mol = Chem.MolFromMolBlock(fixed_sdf, removeHs=False, sanitize=False)
        if mol is None:
            log.warning("RDKit could not parse pose SDF block")
            return InteractionProfile()

        # Basic sanitization to fix valences if possible, but don't crash
        import contextlib

        mol.UpdatePropertyCache(strict=False)
        with contextlib.suppress(Exception):
            Chem.SanitizeMol(mol, Chem.SANITIZE_ALL ^ Chem.SANITIZE_KEKULIZE)

        # Add hydrogens with 3D coordinates based on heavy atom positions
        mol = Chem.AddHs(mol, addCoords=True)
        pos = mol.GetConformer().GetPositions()
        center = pos.mean(axis=0)

        # Select pocket: protein residues within 12.0A of ligand center
        # "byres" ensures we don't cut residues in half, which causes RDKit kekulization errors
        selection = prot_u.select_atoms(f"byres point {center[0]} {center[1]} {center[2]} 12.0")
        if len(selection) == 0:
            return InteractionProfile()

        # Use MDAnalysis for the ligand to facilitate ProLIF
        lig_u = mda.Universe(mol)

        # Run ProLIF profiling on the pocket subset
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            fp.run(lig_u.trajectory, lig_u, selection, converter_kwargs=[{}, {"force": True}])

        ifp = fp.to_dataframe()
        if ifp.empty:
            return InteractionProfile()

        p = InteractionProfile()
        for col in ifp.columns:
            c = str(col).lower()
            v = int(ifp[col].sum())
            if "hbdonor" in c:
                p.hbond_donor += v
            elif "hbacceptor" in c:
                p.hbond_acceptor += v
            elif "hydrophobic" in c:
                p.hydrophobic += v
            elif "pistacking" in c or "cationpi" in c:
                p.pi_stacking += v
            elif "anionic" in c or "cationic" in c:
                p.salt_bridge += v
        return p
    except Exception as exc:
        log.warning("ProLIF failed for pose: %s", exc)
        return InteractionProfile()


def _write_empty_csv(path: Path) -> None:
    cols = [
        "pdb_id",
        "pocket",
        "pose_rank",
        "cnn_score",
        "cnn_affinity",
        "vina_affinity",
        "hbond",
        "hydrophobic",
        "pi_stacking",
        "salt_bridge",
        "total_interactions",
    ]
    pd.DataFrame(columns=cols).to_csv(path, index_label="rank")
