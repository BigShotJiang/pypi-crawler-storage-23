"""WTFDTB — High-Throughput Inverse Virtual Screening (Target Fishing)."""

__version__ = "0.1.0"
