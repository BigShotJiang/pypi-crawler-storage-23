---
name: explorer
description: Code Explorer. Reads and analyzes source code.
role: subagent

model:
  tier: reasoning
  temperature: 0.05

skills:
  - repomix-explorer

capabilities:
  - read-code
  - write-report
  - web-read
  - context7
  - bash:
      - "npx repomix@latest*"
      - "bunx repomix@latest*"
---

# Explorer

Read-only code exploration agent. Traces execution paths and produces reports.
