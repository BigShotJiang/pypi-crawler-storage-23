"""refit.toml configuration parser."""

from __future__ import annotations

import tomllib
from pathlib import Path

from agent_caster.log import logger
from agent_caster.models import ProjectConfig, TargetConfig


class ConfigError(Exception):
    """Raised when refit.toml is invalid or missing."""


def find_config(start: Path | None = None) -> Path:
    """Find refit.toml by searching upward from start (default: cwd)."""
    current = (start or Path.cwd()).resolve()
    while True:
        candidate = current / "refit.toml"
        if candidate.is_file():
            logger.debug(f"Found config at {candidate}")
            return candidate
        parent = current.parent
        if parent == current:
            raise ConfigError(f"refit.toml not found (searched upward from {start or Path.cwd()})")
        current = parent


def load_config(config_path: Path) -> ProjectConfig:
    """Parse refit.toml and return ProjectConfig."""
    logger.debug(f"Loading config from {config_path}")
    with open(config_path, "rb") as f:
        data = tomllib.load(f)

    project = data.get("project", {})
    agents_dir = project.get("agents_dir", ".agents/roles")

    raw_targets = data.get("targets", {})
    targets = {}
    for name, raw in raw_targets.items():
        targets[name] = _parse_target(name, raw)

    return ProjectConfig(agents_dir=agents_dir, targets=targets)


def _parse_target(name: str, raw: dict) -> TargetConfig:
    """Parse a single [targets.<name>] section."""
    return TargetConfig(
        name=name,
        enabled=raw.get("enabled", True),
        output_dir=raw.get("output_dir", "."),
        model_map=raw.get("model_map", {}),
        capability_map=raw.get("capability_map", {}),
    )
