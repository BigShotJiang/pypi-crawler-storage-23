"""LMNgly N-linked glycosylation prediction tool for the Amina CLI."""

import typer
from pathlib import Path
from typing import Optional
from rich.console import Console

METADATA = {
    "name": "lmngly",
    "display_name": "LMNgly",
    "category": "interactions",
    "description": "N-linked glycosylation site prediction using ProtT5 embeddings + neural networks",
    "modal_function_name": "lmngly_pred_worker",
    "modal_app_name": "lmngly-pred-api",
    "status": "available",
    "outputs": {
        "csv_filepath": "CSV file with all prediction results",
    },
}

console = Console()


def register(app: typer.Typer):
    """Register this tool's command with the app."""
    from amina_cli.commands.tools import run_tool_with_progress

    @app.command("lmngly")
    def run_lmngly(
        pdb: Path = typer.Option(
            ...,
            "--pdb",
            "-p",
            help="Path to PDB structure file",
            exists=True,
        ),
        threshold: float = typer.Option(
            0.5,
            "--threshold",
            "-t",
            help="Prediction threshold (0.0-1.0, higher = more stringent)",
            min=0.0,
            max=1.0,
        ),
        ensemble_method: str = typer.Option(
            "average",
            "--ensemble-method",
            "-e",
            help="Ensemble method: 'average', 'max', or 'weighted'",
        ),
        output: Optional[Path] = typer.Option(
            None,
            "--output",
            "-o",
            help="Output directory for results (required unless --background)",
        ),
        background: bool = typer.Option(
            False,
            "--background",
            "-b",
            help="Submit job and return immediately without waiting for completion",
        ),
        job_name: Optional[str] = typer.Option(
            None,
            "--job-name",
            "-j",
            help="Custom job name for output files (default: random 4-letter code)",
        ),
    ):
        """
        Predict N-linked glycosylation sites from protein structures using LMNglyPred.

        Uses ProtT5 protein language model embeddings and an ensemble of neural networks
        to identify asparagine residues with N-X-S/T motifs likely to be glycosylated.

        The ensemble uses 3 models trained on different datasets:
        - Undersampled NGlyDE
        - 90/10 Split NGlyDE
        - NGlycositeAtlas with cell localization

        Examples:
            amina run lmngly --pdb ./1A2J.pdb -o ./output/
            amina run lmngly --pdb ./structure.pdb --threshold 0.7 -o ./output/
            amina run lmngly --pdb ./1A2J.pdb --ensemble-method max -o ./output/
            amina run lmngly --pdb ./1A2J.pdb -j myjob -o ./output/
        """
        # Validate required options
        if output is None and not background:
            console.print("[red]Error:[/red] --output / -o is required (unless using --background)")
            raise typer.Exit(1)

        # Validate ensemble method
        valid_methods = {"average", "max", "weighted"}
        if ensemble_method not in valid_methods:
            console.print(
                f"[red]Error:[/red] Invalid ensemble method '{ensemble_method}'. "
                f"Valid options: {', '.join(sorted(valid_methods))}"
            )
            raise typer.Exit(1)

        # Read PDB file content
        pdb_content = pdb.read_text()

        params = {
            "pdb_content": pdb_content,
            "pdb_filename": pdb.name,  # e.g., "1A2J.pdb"
            "threshold": threshold,
            "ensemble_method": ensemble_method,
        }

        if job_name:
            params["job_name"] = job_name

        run_tool_with_progress("lmngly", params, output, background=background)
