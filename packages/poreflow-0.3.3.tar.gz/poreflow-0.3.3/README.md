# PoreFlow
> *Nanopore data analysis tools*

[![pipeline status](https://gitlab.tudelft.nl/xiuqichen/poreFlow/badges/main/pipeline.svg)](https://gitlab.tudelft.nl/xiuqichen/poreFlow/-/commits/main)
[![Latest Release](https://gitlab.tudelft.nl/xiuqichen/poreFlow/-/badges/release.svg)](https://gitlab.tudelft.nl/xiuqichen/poreFlow/-/releases)

PoreFlow is a fast, simple, and flexible set of tools for analysing raw nanopore sequencing data, 
intended for use for research in the Cees Dekker lab (and beyond?). 

Please see the [Documentation][PoreFlow] for an introductory tutorial and full user guide.

## Features

- Python API for storing measurement, event, and step data.
- Event detection algorithm
- Fast step detection algorithm written in C++
- Support for reasarch .fast5 files, along with .dat files from the UTube device
- Filter events with basic metrics and store metadata
- Find DNA-peptide boundary with expected DNA sequence

## If you need help with PoreFlow, do not hesitate to get in contact:
- For questions, contact the authors in-person or via email
- To report a bug or make a feature request, open an **[Issue]** on GitLab.

## Links
- [Official Documentation][PoreFlow]

## Contributing to PoreFlow
Please see the [Contributing Guide] for information on how you can help develop PoreFlow.


## Authors
Thijn Hoekstra, Xiuqi Chen

## License
[MIT license](https://gitlab.tudelft.nl/xiuqichen/poreFlow/LICENSE)

<!-- Links -->
[PoreFlow]: https://twhoekstra.github.io/poreFlow-docs/
[Issue]: https://https://gitlab.tudelft.nl/xiuqichen/poreFlow/issues
[Contributing Guide]: https://twhoekstra.github.io/poreFlow-docs/contributing/
[PyPA Code of Conduct]: https://www.pypa.io/en/latest/code-of-conduct/