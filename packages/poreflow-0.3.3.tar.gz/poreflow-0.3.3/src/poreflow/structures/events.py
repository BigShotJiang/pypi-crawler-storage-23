#
#      Copyright (C) 2024 Thijn Hoekstra
#
#      This program is free software: you can redistribute it and/or modify
#      it under the terms of the GNU General Public License as published by
#      the Free Software Foundation, either version 3 of the License, or
#      (at your option) any later version.
#
#      This program is distributed in the hope that it will be useful,
#      but WITHOUT ANY WARRANTY; without even the implied warranty of
#      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#      GNU General Public License for more details.
#
#      You should have received a copy of the GNU General Public License
#      along with this program.  If not, see <https://www.gnu.org/licenses/>.
#

import numpy as np
import pandas as pd
from matplotlib import pyplot as plt

import poreflow as pf
from poreflow import utils


class EventsDataFrame(pd.DataFrame):
    """Data frame storing events in a nanopore read

    Data frame must contain the following columns:
    - start_idx (integers): The start index of the event in the measurement
    - end_idx (integers): The end index of the event
    - n_pts (int): The number of samples in the event
    - quality (float): The quality of the event
    - label (int): The label of the event

    Other optional columns are:
    - start_time (float): The start time of the event in seconds.
    - end_time (float): The end time of the event
    - duration (float): The duration time of the event
    - ios (float): The local open state current during the event
    - channel (int): The channel number of the event. Useful when
        concatenating multiple event DataFrames.

    Attributes:
        sfreq (float): The sampling frequency.
        handle (pf.File): TODO remove

    """

    _metadata = [
        "sfreq",
        "handle",
    ]

    def __init__(self, data=None, *args, sfreq=None, handle=None, **kwargs):
        super().__init__(data, *args, **kwargs)
        self.sfreq = sfreq

    def validate(self):
        assert pf.START_IDX_COL in self
        assert pf.END_IDX_COL in self
        assert pf.N_PTS_COL in self
        assert pf.QUALITY_COL in self
        assert pf.LABEL_COL in self

    @property
    def _constructor(self):
        return EventsDataFrame

    def as_dataframe(self):
        return pd.DataFrame(self)

    @property
    def _has_times(self):
        return pf.DURATION_COL in self.columns

    def ensure_times(self):
        if not self._has_times:
            self.calculate_times()

    def calculate_times(self):
        utils.calculate_times(self, self.sfreq)

    def _calculate_indices(self):
        """Inverse of EventsDataFrame._calculate_times"""
        if self.sfreq is None:
            raise ValueError("sfreq cannot be None")

        self[pf.START_IDX_COL] = (self[pf.START_TIME_COL] * self.sfreq).astype(
            np.uint32
        )
        self[pf.END_IDX_COL] = (self[pf.END_IDX_COL] * self.sfreq).astype(np.uint32)
        self[pf.N_PTS_COL] = self[pf.END_IDX_COL] - self[pf.START_IDX_COL]

    def trim_events(
        self, size: int = 5, time: float = None, recalculate_times: bool = True
    ):
        if time is not None:
            size = time * self.sfreq

        self[pf.START_IDX_COL] += size
        self[pf.END_IDX_COL] -= size

        if recalculate_times:
            self.calculate_times()

    def clip_events(self, *args, recalculate_times: bool = True, **kwargs):
        self[pf.START_IDX_COL] = self[pf.START_IDX_COL].clip(*args, **kwargs)
        self[pf.END_IDX_COL] = self[pf.END_IDX_COL].clip(*args, **kwargs)

        if recalculate_times:
            self.calculate_times()

    def filter_by_mask(self, mask: pd.Series | np.ndarray, ignore_index: bool = True):
        mask = pd.Series(mask, dtype=bool)
        new_df = self.loc[mask]

        if ignore_index:
            new_df.reset_index(drop=True, inplace=True)

        return new_df

    def get_label_stats(self, label_df: pd.DataFrame = None) -> pd.DataFrame:
        if "labels" not in self.columns:
            # Try label?
            if "label" in self.columns:
                labels = self.label
            else:
                raise KeyError("No labels column found")
        else:
            labels = self.labels

        if label_df is not None:
            u_labels = label_df.label.to_numpy()
        else:
            u_labels = np.unique(labels).astype(int)

        nums = np.array([np.sum(labels == i) for i in u_labels])
        perc = nums / len(self) * 100
        df = pd.DataFrame(
            [
                u_labels,
                nums,
                perc,
            ],
            index=["Labels", "No.", "%"],
            columns=label_df.description if label_df is not None else None,
        ).astype(int)
        return df

    def filter_by_labels(self, include=None, exclude=None, **kwargs):
        if "labels" in self.columns:
            labels = np.array(self.labels)
        else:
            labels = np.array(self.label)  # fallback

        if include is None and exclude is None:
            raise ValueError("Please specify which labels to include or exclude.")
        elif include is not None and exclude is not None:
            raise ValueError("Please specify either include or exclude.")
        elif isinstance(include, (int, np.integer)):
            include = [include]
        elif isinstance(exclude, (int, np.integer)):
            exclude = [exclude]

        if exclude is not None:
            include = np.unique(labels)
            include = np.setdiff1d(include, exclude)

        mask = np.isin(labels, include)
        return self.filter_by_mask(mask, **kwargs)

    def filter_by_step_rate(self, r: float = 10, **kwargs):
        if pf.STEP_RATE_COL not in self:
            raise KeyError(
                f"No column '{pf.STEP_RATE_COL}' containing step rate found in "
                f"event dataframe. Check out poreflow."
            )

        return self.filter_by_mask(self[pf.STEP_RATE_COL] > r, **kwargs)

    def filter_by_duration(self, min_duration: float = 0.1, verbose=False, **kwargs):
        if min_duration is None:
            return self

        self.ensure_times()
        good_idxs = self[pf.DURATION_COL] >= min_duration

        if verbose:
            print(
                f"Found {sum(good_idxs)} events from {len(good_idxs)} with "
                f"a duration of {min_duration} seconds or longer."
            )

        return self.filter_by_mask(good_idxs, **kwargs)

    def filter_by_current_range(
        self,
        current_range: tuple = (0.15, 0.75),
        threshold: float = 0.9,
        verbose=False,
        strict: bool = True,
        **kwargs,
    ):
        good_idxs = np.ones(len(self), dtype=bool)
        for i, event in enumerate(self.iter_events()):
            ios = getattr(event, "ios", None)
            if ios is None:
                # Try getting from self?
                # self.ios might be global?
                # But EventsDataFrame usually has ios per event if variable?
                # Or global ios?
                # Accessor code: if event.ios is None.
                if strict:
                    raise ValueError(
                        f"Event {i} has not been assigned an open pore current."
                    )
                else:
                    continue

            upper_bound = ios * max(current_range)
            lower_bound = ios * min(current_range)

            in_range = (event.i > lower_bound) & (event.i < upper_bound)

            if np.sum(in_range) / len(event) < threshold:
                good_idxs[i] = False

        if verbose:
            print(
                f"Found {sum(good_idxs)} events from {len(good_idxs)} with "
                f"at least {threshold:.0%} of samples within a range of "
                f"{min(current_range):.0%}-{max(current_range):.0%} of the "
                f"open pore current."
            )

        return self.filter_by_mask(good_idxs, **kwargs)


def plot_steps(
    self,
    steps,
    fig: plt.Figure = None,
    ax: plt.Axes = None,
    **kwargs,
):
    if self.is_varv():
        # dimreduction? not imported.
        # raise NotImplementedError
        pass
    else:
        raise NotImplementedError()


def add_event_time(properties, sfreq):
    properties["start_s"] = properties["start_idx"] / sfreq
    properties["stop_s"] = properties["stop_idx"] / sfreq
    properties["dur_s"] = properties["n_samples"] / sfreq


# find_events is redundant with EventsDataFrame.from_raw/eventdetection.find_events
# but keeping it as a wrapper if needed for compatibility
def find_events(*args, **kwargs):
    from poreflow.events import detection

    return detection.find_events(**kwargs)
