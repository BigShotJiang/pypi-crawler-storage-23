ONT = "ont"
UTUBE = "utube"
