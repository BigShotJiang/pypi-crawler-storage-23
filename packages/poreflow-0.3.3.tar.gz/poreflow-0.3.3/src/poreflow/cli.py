"""CLI for poreflow."""

import argparse
from poreflow.dashboards.app import run_app


def main():
    """Main entry point for the poreflow CLI."""
    parser = argparse.ArgumentParser(description="Poreflow CLI")
    subparsers = parser.add_subparsers(dest="command")

    dash_parser = subparsers.add_parser("dash", help="Start the Plotly Dash dashboard")
    dash_parser.add_argument(
        "--port", type=int, default=8050, help="Port to run on (default: 8050)"
    )
    dash_parser.add_argument("--debug", action="store_true", help="Run in debug mode")
    dash_parser.add_argument(
        "-f", "--file", type=str, help="Pre-set a file path for the dashboard"
    )

    args = parser.parse_args()

    if args.command == "dash":
        run_app(port=args.port, debug=args.debug, initial_path=args.file)
    else:
        # Default to starting dash if no command is provided
        run_app()


if __name__ == "__main__":
    main()
