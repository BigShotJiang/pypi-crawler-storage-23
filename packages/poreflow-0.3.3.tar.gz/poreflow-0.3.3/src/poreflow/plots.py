import multiprocessing
import os
import pathlib


import poreflow as pf


def plot_raw_with_events_worker(
    fname: str | os.PathLike,
    channel: int,
    out: str | os.PathLike = None,
    lock: multiprocessing.Lock = None,
    ylim: tuple[float, float] = None,
    **kwargs,
):

    if out is None:
        out = "./Images/Channels"
    out = pathlib.Path(out)
    out.mkdir(parents=True, exist_ok=True)
    with pf.File(fname, mode="r") as f:
        raw = f.get_raw(channel)
        events = f.get_events(channel)

    ax = raw.plot_with_events(events, **kwargs)
    raw.plot_ios(ax)

    ax.set_ylim(ylim)

    fig = ax.get_figure()

    fig.tight_layout()
    fig.savefig(out / f"Channel_{channel:03d}.png")
