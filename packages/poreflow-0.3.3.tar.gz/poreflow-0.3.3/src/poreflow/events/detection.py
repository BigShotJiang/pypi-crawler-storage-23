# Created by Ruben Marchau
# Refactored and documented by Thijn Hoekstra
import multiprocessing
import os

import scipy
import numpy as np
import pandas as pd

import poreflow as pf
from poreflow.events import open_state, voltage_state

DEFAULT_DEGREE = 1


class EventDetectionFailure(Exception):
    pass


def find_events(
    raw: pd.DataFrame,
    open_state_range: tuple[float, float] = (200, 300),
    voltage_range: tuple[float, float] = (175, 185),
    closing_iterations: int | bool = 10,
    boundary_trim: int = 5,
    n_components: int = 3,
    degree: int = DEFAULT_DEGREE,
    min_frac_os: float = 0.01,
) -> pf.EventsDataFrame | None:
    component = open_state.find_open_state(raw, open_state_range, n_components)

    # "Bad state" still only open state
    bad_state = open_state.get_open_state_mask(raw, component)

    if bad_state.sum() / len(raw) < min_frac_os:
        return None

    poly = open_state.get_open_state_fit(raw, bad_state, degree)
    raw.ios = poly

    # Boolean AND: want to include all samples either in bad voltage or
    # in an open state
    bad_state = bad_state | voltage_state.get_voltage_state_mask(raw, voltage_range)
    bad_state = bad_state.to_numpy(dtype=bool)

    # Do binary closing to clean up mask
    if closing_iterations is not False:
        bad_state = scipy.ndimage.binary_closing(
            bad_state, iterations=closing_iterations
        )

    start_indices, end_indices = get_event_indices(bad_state)

    df = pf.EventsDataFrame(
        {
            pf.START_IDX_COL: start_indices,
            pf.END_IDX_COL: end_indices,
        },
        sfreq=raw.sfreq,
    )

    df.trim_events(size=boundary_trim, recalculate_times=False)
    df.clip_events(lower=0, upper=len(raw))  # Times are recalculated here

    add_local_open_state(df, poly)

    df[pf.CHANNEL_COL] = raw.channel
    df[pf.QUALITY_COL] = 0.0
    df[pf.LABEL_COL] = 0

    return df


def get_event_indices(bad_state: np.ndarray[np.bool]):
    diff = np.diff(bad_state.astype(np.int8))

    if not np.any(diff):
        raise RuntimeError(
            "Did not find any states. Please run "
            "find_open_state() and find_bad_voltages() first."
        )

    start_indices = np.where(diff == -1)[0] + 1
    end_indices = np.where(diff == 1)[0] + 1
    # If starting/ending at a good state, also add events here
    if not bad_state[0]:
        start_indices = np.insert(start_indices, 0, 0)
    if not bad_state[-1]:
        end_indices = np.append(end_indices, len(bad_state))
    return start_indices, end_indices


def add_local_open_state(df: pd.DataFrame, poly: np.polynomial.Polynomial) -> None:
    start_ios = poly(df[pf.START_TIME_COL])
    end_ios = poly(df[pf.END_TIME_COL])

    df[pf.IOS_COL] = (start_ios + end_ios) / 2


def event_detection_worker(
    fname: str | os.PathLike,
    channel: int,
    lock: multiprocessing.Lock = None,
    **kwargs,
):
    index = kwargs.pop("index", None)
    times = kwargs.pop("times", None)
    downsample = kwargs.pop("downsample", None)

    error = None
    lock.acquire()
    try:
        with pf.File(fname, mode="r") as f:
            raw = f.get_raw(channel, index=index, times=times, downsample=downsample)
    except IOError as e:
        error = e
    lock.release()

    events = []
    if error is None:
        try:
            events = raw.find_events(**kwargs)

            min_duration = kwargs.get("min_duration", None)
            filter_kwargs = (
                {} if min_duration is None else dict(min_duration=min_duration)
            )
            events = events.filter_by_duration(**filter_kwargs)

        except Exception as e:
            events = []
            error = e

    if error is None:
        return {
            "channel": channel,
            "result": f"Worker {os.getpid()} processed channel {channel}",
            "success": True,
            "n_events": len(events),
            "events": events,
            "coef": raw.ios,
        }
    else:
        return {
            "channel": channel,
            "result": str(f"Error when processing channel {channel}: {error}"),
            "success": False,
            "n_events": 0,
            "events": None,
            "coef": raw.ios,
        }


def summarize_events(results):
    n_channels = len(results)
    n_events = sum(r.get("n_events", 0) for r in results)

    print("------- SUMMARY -------")
    failed_channels = sorted([r["channel"] for r in results if not r["success"]])
    error_str = ""
    if failed_channels:
        failed_str = ", ".join(map(str, failed_channels[:10]))
        if len(failed_channels) > 10:
            failed_str += ", ..."
        error_str = (
            f"Error finding events in {len(failed_channels)} channels "
            f"({len(failed_channels) / n_channels:.0%}), channels {failed_str}. \n"
        )
    n_good = len(results) - len(failed_channels)
    avg_events = n_events / n_good if n_good > 0 else 0.0
    print(
        f"Searched {n_channels} channels and found {n_events} events. \n{error_str}"
        f"Good channels had {avg_events:.2f} events on average."
    )


def save_events_to_file(
    result,
    fname,
    lock: multiprocessing.Lock = None,
    verbose: int = 0,
):
    if verbose > 2:
        print(result["result"])

    channel = result["channel"]

    events = None
    if result["success"] and result["n_events"] > 0:
        events = result.get("events")

    coef = result.get("coef")

    lock.acquire()
    try:
        with pf.File(fname, mode="r+") as f:
            if events is not None:
                f.set_events(events, mode="a")
                result["events"] = None

            f.set_ios(coef, channel=channel)
    except Exception as e:
        raise IOError(f"Error in saving data from channel {channel}") from e
    finally:
        lock.release()
