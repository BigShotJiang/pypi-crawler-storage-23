# Created by Henry Brinkerhoff
# Written for Python by Thijn Hoekstra

"""Change point detection"""

import multiprocessing
import os
from collections.abc import Iterator

import numpy as np

import poreflow as pf

try:
    from ._changepoint import BasisFunctionStepFinder
except ImportError:
    # Fallback or error if extension not built
    raise ImportError(
        "Could not import C++ extension _changepoint. Ensure the package is installed properly."
    )


def iter_transitions(transitions: np.ndarray[int]) -> Iterator[int, int, int]:
    for j, (start, stop) in enumerate(zip(transitions[:-1], transitions[1:])):
        yield j, start, stop


def find_transitions(
    i_data: np.ndarray, min_level_length: int, sensitivity: float = 1
) -> np.ndarray:
    """Uses the variable voltage step finder with a flat basis function to find transitions.

    Args:
        i_data:
        min_level_length:
        sensitivity:

    Returns:

    """
    bf = np.atleast_2d(np.ones(min_level_length))
    # Note: C++ class takes (bf, cpic_multiplier)
    step_finder = BasisFunctionStepFinder(bf, sensitivity)

    return step_finder.fit(i_data)


def get_step_features(
    data: np.ndarray,
    sensitivity: float = 1,
    min_level_length: int = 2,
) -> tuple[np.ndarray, np.ndarray]:
    transitions = find_transitions(data, min_level_length, sensitivity)

    features = np.zeros((2, len(transitions) - 1))

    for j, start, stop in iter_transitions(transitions):
        features[0, j] = np.mean(data[start:stop])
        features[1, j] = np.std(data[start:stop])

    return transitions, features


def format_steps_df(transitions, features, sfreq) -> pf.StepsDataFrame:
    """
    Formats a DataFrame containing information about steps and their properties.

    This function creates a DataFrame where each row represents a step, with columns
    for the start and end indices of each step, the number of points in each step,
    the dwell time in seconds, and the mean and standard deviation values of the features
    for each step. The function assumes that the `features` array contains mean values
    in the first row and standard deviation values in the second row.

    Parameters:
        transitions (array-like): The indices of the transitions marking the start and end of each step.
        features (array-like): A 2D array where the first row contains mean feature values,
                               and the second row contains standard deviation values for each step.
        sfreq (float): The sampling frequency (samples per second), used to calculate dwell time.

    Returns:
        pd.DataFrame: A DataFrame with columns for the start and end indices, the number of points,
                      the dwell time in seconds, and the mean and standard deviation of each step.

    """
    steps_df = pf.StepsDataFrame(
        {
            pf.START_IDX_COL: transitions[:-1],
            pf.END_IDX_COL: transitions[1:],
            pf.STD_COL: features[1, :],
            pf.MEAN_COL: features[0, :],
        },
        sfreq=sfreq,
    )
    steps_df.calculate_times()
    return steps_df


def get_steps(i: np.ndarray, sfreq: float, **kwargs) -> pf.StepsDataFrame:
    results = get_step_features(i, **kwargs)
    return format_steps_df(*results, sfreq=sfreq)


def step_finding_worker(
    fname: str | os.PathLike,
    event: int,
    lock: multiprocessing.Lock = None,
    **kwargs,
):
    downsample = kwargs.pop("downsample", None)

    lock.acquire()
    try:
        with pf.File(fname, mode="r") as f:
            df_event = f.get_event(event, downsample=downsample)
    except Exception as e:
        raise e
    finally:
        lock.release()

    try:
        steps = df_event.find_steps(**kwargs)
        steps.add_event(event)
        steps.add_step_idx()
    except Exception:
        steps = None

    if steps is None:
        return [event, False, None, 0]
    else:
        return [event, True, steps, len(steps)]


def summarize_steps(results):
    n_events = len(results)
    n_steps = sum(r[3] for r in results)

    print("------- SUMMARY -------")
    n_good = sum(r[1] for r in results)
    avg_events = n_steps / n_good if n_good > 0 else 0.0
    print(
        f"Found steps in {n_events} events. \n"
        f"Unable to find steps in {n_events - n_good} "
        f"({(n_events - n_good) / n_events:.0%}) events. \n"
        f"Found a total of {n_steps} steps. \n"
        f"Good channels had {avg_events:.2f} steps on average."
    )


def save_steps_to_file(
    result,
    fname,
    lock: multiprocessing.Lock = None,
):

    if not result[1]:
        return

    steps = result[2]

    lock.acquire()
    try:
        with pf.File(fname, mode="r+") as f:
            f.set_steps(steps, mode="a")
            result[2] = None

    except Exception as e:
        raise IOError(f"Error in saving data from channel {result[0]}") from e
    finally:
        lock.release()


def add_step_idx(df_steps: pf.StepsDataFrame):
    df_steps["step_idx"] = 0
    for event, group in df_steps.groupby("event"):
        df_steps.loc[group.index, "step_idx"] = np.arange(len(group), dtype=int)
