import importlib as _importlib

# First the dataframe types

from poreflow.structures.base import BaseDataFrame
from poreflow.structures.steps import StepsDataFrame
from poreflow.structures.event import EventDataFrame
from poreflow.structures.events import EventsDataFrame
from poreflow.structures.raw import RawDataFrame

# Then I/O
from poreflow.io.ont import File

from poreflow.io.devices import ONT, UTUBE
from poreflow import constants
from poreflow.constants import *

from poreflow import _version

__version__ = _version.__version__

submodules = [
    "dashboards"
    "events",
    "io",
    "steps",
    "structures",
    "dataset",
    "parallel",
    "plots",
    "utils",
]

__all__ = (
    submodules
    + [
        "__version__",
        "File",
        "RawDataFrame",
        "EventsDataFrame",
        "EventDataFrame",
        "StepsDataFrame",
        "ONT",
        "UTUBE",
    ]
    + constants.__all__
)

def __dir__():
    return __all__


def __getattr__(name):
    if name in submodules:
        return _importlib.import_module(f"poreflow.{name}")
    else:
        try:
            return globals()[name]
        except KeyError:
            raise AttributeError(f"Module 'poreflow' has no attribute '{name}'")
