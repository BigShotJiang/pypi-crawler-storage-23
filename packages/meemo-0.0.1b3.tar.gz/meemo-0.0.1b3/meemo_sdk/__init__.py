"""Meemo Python client library for interacting with the Meemo External API."""

from meemo_sdk.client import MeemoClient
from meemo_sdk.async_client import AsyncMeemoClient
from meemo_sdk.meetings import Meetings
from meemo_sdk.async_meetings import AsyncMeetings
from meemo_sdk.webhooks import Webhooks
from meemo_sdk.async_webhooks import AsyncWebhooks
from meemo_sdk.models import (
    CalendarAttendee,
    CalendarEvent,
    MeetingDetail,
    MeetingHost,
    MeetingListItem,
    MeetingListParams,
    MeetingListResponse,
    MeetingStatus,
    Participant,
    ParticipantsResponse,
    RecordingFormat,
    RecordingResponse,
    SummaryResponse,
    TokenResponse,
    TranscriptResponse,
    TranscriptSegment,
    AvailableOrganization,
    CreateWebhookBody,
    Webhook,
    WebhookListResponse,
    WebhookEvent,
    WebhookEventListResponse,
)

__all__ = [
    # Client
    "MeemoClient",
    "AsyncMeemoClient",
    # API Classes
    "Meetings",
    "AsyncMeetings",
    "Webhooks",
    "AsyncWebhooks",
    # Enums
    "MeetingStatus",
    "RecordingFormat",
    # Auth Models
    "TokenResponse",
    # Calendar Models
    "CalendarAttendee",
    "CalendarEvent",
    # Meeting Models
    "MeetingListItem",
    "MeetingListResponse",
    "MeetingListParams",
    "MeetingDetail",
    "MeetingHost",
    # Transcript Models
    "TranscriptSegment",
    "TranscriptResponse",
    # Summary Models
    "SummaryResponse",
    # Participant Models
    "Participant",
    "ParticipantsResponse",
    # Recording Models
    "RecordingResponse",
    # Webhook Models
    "AvailableOrganization",
    "CreateWebhookBody",
    "Webhook",
    "WebhookListResponse",
    "WebhookEvent",
    "WebhookEventListResponse",
]
