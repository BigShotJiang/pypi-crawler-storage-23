"""Meetings handling for the Meemo Python client.

This module provides the Meetings class for accessing meeting data
from the Meemo External API, including meeting details, transcripts,
summaries, participants, and recordings.

Authors:
    GDP Labs

References:
    https://gdplabs.gitbook.io/meemo/resources/external-api-documentation
"""

import logging
from typing import Any

from meemo_sdk.models import (
    MeetingDetail,
    MeetingListParams,
    MeetingListResponse,
    ParticipantsResponse,
    RecordingResponse,
    SummaryResponse,
    TranscriptResponse,
)

logger = logging.getLogger(__name__)

_ERR_EXPECTED_DICT = "Expected dict response from API"
_ERR_MEETING_ID_POSITIVE = "meeting_id must be a positive integer"


class Meetings:
    """Handles Meeting API operations for the Meemo External API."""

    def __init__(self, client):
        """Initialize Meetings API.

        Args:
            client: MeemoClient instance.
        """
        self._client = client

    def _prepare_headers(self, extra_headers: dict[str, str] | None = None) -> dict[str, str]:
        """Prepare headers for the API request (delegates to client)."""
        return self._client._prepare_headers(extra_headers)

    def _make_request(
        self,
        method: str,
        url: str,
        headers: dict[str, str],
        json_data: dict[str, Any] | None = None,
        params: dict[str, Any] | None = None,
    ) -> dict[str, Any] | list[dict[str, Any]]:
        """Make an HTTP request (delegates to client)."""
        return self._client._make_request(
            method=method,
            url=url,
            headers=headers,
            json_data=json_data,
            params=params,
        )

    def list_meetings(
        self,
        organization_id: int | None = None,
        title: str | None = None,
        participants: str | None = None,
        created_after: str | None = None,
        created_before: str | None = None,
        summary_complete: bool | None = None,
        from_calendar: bool | None = None,
        page: int | None = None,
        size: int | None = None,
        extra_headers: dict[str, str] | None = None,
    ) -> MeetingListResponse:
        """List meetings for your accessible organization(s).

        Returns a paginated list of meetings ordered by start time descending
        (newest first).

        Args:
            organization_id (int | None): Filter to a specific organization.
                If not provided, returns meetings from all accessible organizations.
            title (str | None): Filter by title (case-insensitive, contains match).
            participants (str | None): Filter by participant user IDs (comma-separated).
            created_after (str | None): Filter meetings created on or after this date
                (YYYY-MM-DD).
            created_before (str | None): Filter meetings created on or before this date
                (YYYY-MM-DD).
            summary_complete (bool | None): Filter by summary completion status.
            from_calendar (bool | None): Filter by meeting source.
                True=calendar integration, False=manually created.
            page (int | None): Page number for pagination.
            size (int | None): Number of results per page (default: 10).
            extra_headers (dict[str, str] | None): Additional headers.

        Returns:
            MeetingListResponse: Paginated list of meetings.

        Raises:
            httpx.HTTPStatusError: If the API request fails.
        """
        logger.debug("Listing meetings")

        url = f"{self._client.base_url}/api/v1/external/meeting/"
        headers = self._prepare_headers(extra_headers)

        list_params = MeetingListParams(
            organization_id=organization_id,
            title=title,
            participants=participants,
            created_after=created_after,
            created_before=created_before,
            summary_complete=summary_complete,
            from_calendar=from_calendar,
            page=page,
            size=size,
        )
        params = list_params.to_query_params()

        response_data = self._make_request("GET", url, headers, params=params or None)
        if not isinstance(response_data, dict):
            raise TypeError(_ERR_EXPECTED_DICT)
        return MeetingListResponse(**response_data)

    def get_meeting(
        self,
        meeting_id: int,
        extra_headers: dict[str, str] | None = None,
    ) -> MeetingDetail:
        """Get detailed information about a specific meeting.

        The meeting must belong to one of your accessible organizations.

        Args:
            meeting_id (int): Meeting ID.
            extra_headers (dict[str, str] | None): Additional headers.

        Returns:
            MeetingDetail: Detailed meeting information.

        Raises:
            ValueError: If meeting_id is not a positive integer.
            httpx.HTTPStatusError: If the API request fails.
        """
        if not meeting_id or meeting_id <= 0:
            raise ValueError(_ERR_MEETING_ID_POSITIVE)

        logger.debug("Retrieving meeting: %d", meeting_id)

        url = f"{self._client.base_url}/api/v1/external/meeting/{meeting_id}/"
        headers = self._prepare_headers(extra_headers)

        response_data = self._make_request("GET", url, headers)
        if not isinstance(response_data, dict):
            raise TypeError(_ERR_EXPECTED_DICT)
        return MeetingDetail(**response_data)

    def get_transcript(
        self,
        meeting_id: int,
        extra_headers: dict[str, str] | None = None,
    ) -> TranscriptResponse:
        """Get the transcript of a specific meeting.

        Returns the meeting transcript as a JSON array of segments, ordered by
        start time. Confidential segments are excluded.

        Args:
            meeting_id (int): Meeting ID.
            extra_headers (dict[str, str] | None): Additional headers.

        Returns:
            TranscriptResponse: Meeting transcript with segments.

        Raises:
            ValueError: If meeting_id is not a positive integer.
            httpx.HTTPStatusError: If the API request fails.
        """
        if not meeting_id or meeting_id <= 0:
            raise ValueError(_ERR_MEETING_ID_POSITIVE)

        logger.debug("Retrieving transcript for meeting: %d", meeting_id)

        url = f"{self._client.base_url}/api/v1/external/meeting/{meeting_id}/transcript/"
        headers = self._prepare_headers(extra_headers)

        response_data = self._make_request("GET", url, headers)
        if not isinstance(response_data, dict):
            raise TypeError(_ERR_EXPECTED_DICT)
        return TranscriptResponse(**response_data)

    def get_summary(
        self,
        meeting_id: int,
        extra_headers: dict[str, str] | None = None,
    ) -> SummaryResponse:
        """Get the summary of a specific meeting.

        Returns the meeting summary, notes, and keywords. The summary field
        may be a Markdown string (new format) or a structured JSON object
        (legacy format).

        Args:
            meeting_id (int): Meeting ID.
            extra_headers (dict[str, str] | None): Additional headers.

        Returns:
            SummaryResponse: Meeting summary with notes and keywords.

        Raises:
            ValueError: If meeting_id is not a positive integer.
            httpx.HTTPStatusError: If the API request fails.
        """
        if not meeting_id or meeting_id <= 0:
            raise ValueError(_ERR_MEETING_ID_POSITIVE)

        logger.debug("Retrieving summary for meeting: %d", meeting_id)

        url = f"{self._client.base_url}/api/v1/external/meeting/{meeting_id}/summary/"
        headers = self._prepare_headers(extra_headers)

        response_data = self._make_request("GET", url, headers)
        if not isinstance(response_data, dict):
            raise TypeError(_ERR_EXPECTED_DICT)
        return SummaryResponse(**response_data)

    def get_participants(
        self,
        meeting_id: int,
        extra_headers: dict[str, str] | None = None,
    ) -> ParticipantsResponse:
        """Get the list of participants for a specific meeting.

        Args:
            meeting_id (int): Meeting ID.
            extra_headers (dict[str, str] | None): Additional headers.

        Returns:
            ParticipantsResponse: Meeting participants list.

        Raises:
            ValueError: If meeting_id is not a positive integer.
            httpx.HTTPStatusError: If the API request fails.
        """
        if not meeting_id or meeting_id <= 0:
            raise ValueError(_ERR_MEETING_ID_POSITIVE)

        logger.debug("Retrieving participants for meeting: %d", meeting_id)

        url = f"{self._client.base_url}/api/v1/external/meeting/{meeting_id}/participants/"
        headers = self._prepare_headers(extra_headers)

        response_data = self._make_request("GET", url, headers)
        if not isinstance(response_data, dict):
            raise TypeError(_ERR_EXPECTED_DICT)
        return ParticipantsResponse(**response_data)

    def get_recording(
        self,
        meeting_id: int,
        extra_headers: dict[str, str] | None = None,
    ) -> RecordingResponse:
        """Get the recording URL for a specific meeting.

        Args:
            meeting_id (int): Meeting ID.
            extra_headers (dict[str, str] | None): Additional headers.

        Returns:
            RecordingResponse: Meeting recording URL and metadata.

        Raises:
            ValueError: If meeting_id is not a positive integer.
            httpx.HTTPStatusError: If the API request fails.
        """
        if not meeting_id or meeting_id <= 0:
            raise ValueError(_ERR_MEETING_ID_POSITIVE)

        logger.debug("Retrieving recording for meeting: %d", meeting_id)

        url = f"{self._client.base_url}/api/v1/external/meeting/{meeting_id}/recording/"
        headers = self._prepare_headers(extra_headers)

        response_data = self._make_request("GET", url, headers)
        if not isinstance(response_data, dict):
            raise TypeError(_ERR_EXPECTED_DICT)
        return RecordingResponse(**response_data)
