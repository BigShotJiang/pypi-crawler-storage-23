"""Async webhooks handling for the Meemo Python client.

This module provides the AsyncWebhooks class for managing webhook registrations
and viewing delivery logs for the Meemo External API using async/await.

Authors:
    GDP Labs

References:
    https://gdplabs.gitbook.io/meemo/resources/external-api-documentation
"""

import logging
from typing import Any

from meemo_sdk.models import (
    AvailableOrganization,
    CreateWebhookBody,
    Webhook,
    WebhookEvent,
    WebhookEventListResponse,
    WebhookListResponse,
)

logger = logging.getLogger(__name__)

_ERR_EXPECTED_DICT = "Expected dict response from API"
_ERR_EXPECTED_LIST = "Expected list response from API"


class AsyncWebhooks:
    """Handles async Webhooks API operations for the Meemo External API."""

    def __init__(self, client):
        """Initialize AsyncWebhooks API.

        Args:
            client: AsyncMeemoClient instance.
        """
        self._client = client

    async def _prepare_headers(self, extra_headers: dict[str, str] | None = None) -> dict[str, str]:
        """Prepare headers for the API request (delegates to client)."""
        return await self._client._prepare_headers(extra_headers)

    async def _make_request(
        self,
        method: str,
        url: str,
        headers: dict[str, str],
        json_data: dict[str, Any] | None = None,
        params: dict[str, Any] | None = None,
    ) -> dict[str, Any] | list[dict[str, Any]]:
        """Make an async HTTP request (delegates to client)."""
        return await self._client._make_request(
            method=method,
            url=url,
            headers=headers,
            json_data=json_data,
            params=params,
        )

    async def list_available_organizations(
        self,
        extra_headers: dict[str, str] | None = None,
    ) -> list[AvailableOrganization]:
        """List organizations accessible to your external application.

        Use these IDs when creating webhooks.

        Args:
            extra_headers: Additional headers.

        Returns:
            List of available organizations.

        Raises:
            httpx.HTTPStatusError: If the API request fails.
        """
        logger.debug("Listing available organizations for webhooks")
        url = f"{self._client.base_url}/api/v1/external/webhooks/available-organizations/"
        headers = await self._prepare_headers(extra_headers)
        data = await self._make_request("GET", url, headers)
        if not isinstance(data, list):
            raise TypeError(_ERR_EXPECTED_LIST)
        return [AvailableOrganization(**item) for item in data]

    async def create_webhook(
        self,
        target_url: str,
        events: list[str],
        organization_ids: list[int],
        description: str | None = None,
        extra_headers: dict[str, str] | None = None,
    ) -> list[Webhook]:
        """Register a new webhook for one or more organizations.

        The API returns one webhook object per organization.

        Args:
            target_url: HTTPS URL where events will be sent.
            events: List of event types (e.g. meeting.created, meeting.transcription_completed).
            organization_ids: List of organization IDs to monitor.
            description: Optional description of the webhook.
            extra_headers: Additional headers.

        Returns:
            List of created webhook objects (one per organization).

        Raises:
            httpx.HTTPStatusError: If the API request fails.
        """
        logger.debug("Creating webhook for organizations: %s", organization_ids)
        url = f"{self._client.base_url}/api/v1/external/webhooks/"
        headers = await self._prepare_headers(extra_headers)
        headers["Content-Type"] = "application/json"
        body = CreateWebhookBody(
            target_url=target_url,
            events=events,
            organization_ids=organization_ids,
            description=description,
        )
        data = await self._make_request(
            "POST",
            url,
            headers,
            json_data=body.model_dump(exclude_none=True),
        )
        if not isinstance(data, list):
            raise TypeError(_ERR_EXPECTED_LIST)
        return [Webhook(**item) for item in data]

    async def list_webhooks(
        self,
        extra_headers: dict[str, str] | None = None,
    ) -> WebhookListResponse:
        """List all webhooks registered for your accessible organizations.

        Args:
            extra_headers: Additional headers.

        Returns:
            Paginated list of webhooks.

        Raises:
            httpx.HTTPStatusError: If the API request fails.
        """
        logger.debug("Listing webhooks")
        url = f"{self._client.base_url}/api/v1/external/webhooks/"
        headers = await self._prepare_headers(extra_headers)
        data = await self._make_request("GET", url, headers)
        if not isinstance(data, dict):
            raise TypeError(_ERR_EXPECTED_DICT)
        return WebhookListResponse(**data)

    async def get_webhook(
        self,
        webhook_id: int,
        extra_headers: dict[str, str] | None = None,
    ) -> Webhook:
        """Get details of a specific webhook.

        Args:
            webhook_id: Webhook ID.
            extra_headers: Additional headers.

        Returns:
            Webhook details including failure_count and last_failure_reason.

        Raises:
            ValueError: If webhook_id is not a positive integer.
            httpx.HTTPStatusError: If the API request fails.
        """
        if not webhook_id or webhook_id <= 0:
            raise ValueError("webhook_id must be a positive integer")
        logger.debug("Retrieving webhook: %d", webhook_id)
        url = f"{self._client.base_url}/api/v1/external/webhooks/{webhook_id}/"
        headers = await self._prepare_headers(extra_headers)
        data = await self._make_request("GET", url, headers)
        if not isinstance(data, dict):
            raise TypeError(_ERR_EXPECTED_DICT)
        return Webhook(**data)

    async def delete_webhook(
        self,
        webhook_id: int,
        extra_headers: dict[str, str] | None = None,
    ) -> None:
        """Delete a webhook.

        Args:
            webhook_id: Webhook ID.
            extra_headers: Additional headers.

        Raises:
            ValueError: If webhook_id is not a positive integer.
            httpx.HTTPStatusError: If the API request fails.
        """
        if not webhook_id or webhook_id <= 0:
            raise ValueError("webhook_id must be a positive integer")
        logger.debug("Deleting webhook: %d", webhook_id)
        url = f"{self._client.base_url}/api/v1/external/webhooks/{webhook_id}/"
        headers = await self._prepare_headers(extra_headers)
        await self._make_request("DELETE", url, headers)

    async def list_webhook_events(
        self,
        webhook_id: int | None = None,
        extra_headers: dict[str, str] | None = None,
    ) -> WebhookEventListResponse:
        """List webhook delivery logs.

        Args:
            webhook_id: Optional. Filter by specific webhook ID.
            extra_headers: Additional headers.

        Returns:
            Paginated list of webhook event logs.

        Raises:
            httpx.HTTPStatusError: If the API request fails.
        """
        logger.debug("Listing webhook events (webhook_id=%s)", webhook_id)
        url = f"{self._client.base_url}/api/v1/external/webhook-events/"
        headers = await self._prepare_headers(extra_headers)
        params = {"webhook_id": webhook_id} if webhook_id is not None else None
        data = await self._make_request("GET", url, headers, params=params)
        if not isinstance(data, dict):
            raise TypeError(_ERR_EXPECTED_DICT)
        return WebhookEventListResponse(**data)

    async def get_webhook_event(
        self,
        event_id: int,
        extra_headers: dict[str, str] | None = None,
    ) -> WebhookEvent:
        """Get details of a specific webhook event log.

        Args:
            event_id: Webhook event log ID.
            extra_headers: Additional headers.

        Returns:
            Webhook event log details.

        Raises:
            ValueError: If event_id is not a positive integer.
            httpx.HTTPStatusError: If the API request fails.
        """
        if not event_id or event_id <= 0:
            raise ValueError("event_id must be a positive integer")
        logger.debug("Retrieving webhook event: %d", event_id)
        url = f"{self._client.base_url}/api/v1/external/webhook-events/{event_id}/"
        headers = await self._prepare_headers(extra_headers)
        data = await self._make_request("GET", url, headers)
        if not isinstance(data, dict):
            raise TypeError(_ERR_EXPECTED_DICT)
        return WebhookEvent(**data)
