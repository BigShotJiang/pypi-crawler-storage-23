"""Multi-language parsing via Tree-sitter with regex fallback.

Tree-sitter provides accurate AST parsing for 8+ languages. When tree-sitter
grammars are not installed, falls back to regex-based extraction that still
captures function/class signatures for most languages.

Supported languages: Python, TypeScript/JavaScript, Go, Rust, Java, Ruby, C/C++
"""

import ast
import re
import threading
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Optional, List, Dict, Any

from know.exceptions import ParseError
from know.models import FunctionInfo, ClassInfo, ModuleInfo
from know.logger import get_logger

logger = get_logger()

# ---------------------------------------------------------------------------
# Language detection
# ---------------------------------------------------------------------------
EXTENSION_TO_LANGUAGE: Dict[str, str] = {
    ".py": "python",
    ".ts": "typescript",
    ".tsx": "tsx",
    ".js": "javascript",
    ".jsx": "jsx",
    ".go": "go",
    ".rs": "rust",
    ".java": "java",
    ".rb": "ruby",
    ".c": "c",
    ".h": "c",
    ".cpp": "cpp",
    ".cc": "cpp",
    ".cxx": "cpp",
    ".hpp": "cpp",
    ".swift": "swift",
}

# Tree-sitter grammar packages for each language
_TS_GRAMMAR_PACKAGES: Dict[str, str] = {
    "python": "tree_sitter_python",
    "typescript": "tree_sitter_typescript",
    "tsx": "tree_sitter_typescript",
    "javascript": "tree_sitter_javascript",
    "jsx": "tree_sitter_javascript",
    "go": "tree_sitter_go",
    "rust": "tree_sitter_rust",
    "java": "tree_sitter_java",
    "ruby": "tree_sitter_ruby",
    "c": "tree_sitter_c",
    "cpp": "tree_sitter_c",  # C parser handles basic C++ too
}

# Node types per language for function/class extraction
_FUNCTION_NODE_TYPES: Dict[str, set] = {
    "python": {"function_definition"},
    "typescript": {"function_declaration", "method_definition", "arrow_function", "function_expression"},
    "tsx": {"function_declaration", "method_definition", "arrow_function", "function_expression"},
    "javascript": {"function_declaration", "method_definition", "arrow_function", "function_expression"},
    "jsx": {"function_declaration", "method_definition", "arrow_function", "function_expression"},
    "go": {"function_declaration", "method_declaration"},
    "rust": {"function_item"},
    "java": {"method_declaration", "constructor_declaration"},
    "ruby": {"method", "singleton_method"},
    "c": {"function_definition"},
    "cpp": {"function_definition"},
}

_CLASS_NODE_TYPES: Dict[str, set] = {
    "python": {"class_definition"},
    "typescript": {"class_declaration"},
    "tsx": {"class_declaration"},
    "javascript": {"class_declaration"},
    "jsx": {"class_declaration"},
    "go": set(),  # Go uses type_declaration + struct
    "rust": {"struct_item", "enum_item"},
    "java": {"class_declaration", "interface_declaration"},
    "ruby": {"class", "module"},
    "c": {"struct_specifier"},
    "cpp": {"struct_specifier", "class_specifier"},
}

_IMPORT_NODE_TYPES: Dict[str, set] = {
    "python": {"import_statement", "import_from_statement"},
    "typescript": {"import_statement"},
    "tsx": {"import_statement"},
    "javascript": {"import_statement"},
    "jsx": {"import_statement"},
    "go": {"import_declaration"},
    "rust": {"use_declaration"},
    "java": {"import_declaration"},
    "ruby": {"call"},  # require/require_relative
    "c": {"preproc_include"},
    "cpp": {"preproc_include"},
}

# Node types for call expression extraction (used by TreeSitterParser._walk_calls)
_CALL_EXPRESSION_TYPES: Dict[str, set] = {
    "python": {"call"},
    "typescript": {"call_expression", "new_expression"},
    "tsx": {"call_expression", "new_expression"},
    "javascript": {"call_expression", "new_expression"},
    "jsx": {"call_expression", "new_expression"},
    "go": {"call_expression"},
    "rust": {"call_expression", "macro_invocation"},
    "java": {"method_invocation", "object_creation_expression"},
    "ruby": {"call", "method_call"},
    "c": {"call_expression"},
    "cpp": {"call_expression"},
    "swift": {"call_expression"},
}


# ---------------------------------------------------------------------------
# Tree-sitter parser cache
# ---------------------------------------------------------------------------
_parser_cache: Dict[str, Any] = {}
_parser_cache_lock = threading.Lock()


def _get_ts_parser(language: str):
    """Get or create a tree-sitter parser for the given language.

    Returns (parser, Language) or (None, None) if unavailable.
    Thread-safe: uses a lock to protect the shared cache.
    """
    if language in _parser_cache:
        return _parser_cache[language]

    with _parser_cache_lock:
        # Double-check after acquiring lock
        if language in _parser_cache:
            return _parser_cache[language]

        try:
            from tree_sitter import Language, Parser
            import importlib

            pkg_name = _TS_GRAMMAR_PACKAGES.get(language)
            if not pkg_name:
                _parser_cache[language] = (None, None)
                return None, None

            mod = importlib.import_module(pkg_name)

            # Handle TypeScript which has separate language functions
            if language == "typescript":
                lang = Language(mod.language_typescript())
            elif language == "tsx":
                lang = Language(mod.language_tsx())
            else:
                lang = Language(mod.language())

            parser = Parser(lang)
            _parser_cache[language] = (parser, lang)
            return parser, lang

        except (ImportError, AttributeError, Exception) as e:
            logger.debug(f"Tree-sitter not available for {language}: {e}")
            _parser_cache[language] = (None, None)
            return None, None


# ---------------------------------------------------------------------------
# Abstract base
# ---------------------------------------------------------------------------
class BaseParser(ABC):
    """Abstract base class for language parsers."""

    language: str = ""
    extensions: set = set()

    @abstractmethod
    def parse(self, path: Path, root: Path) -> ModuleInfo:
        """Parse a file and return module info."""
        pass

    def _read_file(self, path: Path, strict: bool = False) -> str:
        try:
            return path.read_text(encoding="utf-8", errors="strict" if strict else "replace")
        except UnicodeDecodeError as e:
            raise ParseError(f"Invalid encoding: {e}", str(path))
        except Exception as e:
            raise ParseError(f"Cannot read file: {e}", str(path))


# ---------------------------------------------------------------------------
# Tree-sitter unified parser
# ---------------------------------------------------------------------------
class TreeSitterParser(BaseParser):
    """Multi-language parser using Tree-sitter."""

    def __init__(self, language: str):
        self.language = language
        self.extensions = {ext for ext, lang in EXTENSION_TO_LANGUAGE.items() if lang == language}

    def parse(self, path: Path, root: Path) -> ModuleInfo:
        content = self._read_file(path)
        content_bytes = content.encode("utf-8")

        parser, lang = _get_ts_parser(self.language)
        if parser is None:
            raise ParseError(f"Tree-sitter not available for {self.language}", str(path))

        tree = parser.parse(content_bytes)
        relative_path = path.relative_to(root)
        module_name = str(relative_path.with_suffix("")).replace("/", ".")

        module = ModuleInfo(
            path=relative_path,
            name=module_name,
            docstring=None,
            functions=[],
            classes=[],
            imports=[],
        )

        func_types = _FUNCTION_NODE_TYPES.get(self.language, set())
        class_types = _CLASS_NODE_TYPES.get(self.language, set())
        import_types = _IMPORT_NODE_TYPES.get(self.language, set())

        self._walk(tree.root_node, content_bytes, module, func_types, class_types, import_types)
        return module

    def _walk(self, node, content: bytes, module: ModuleInfo,
              func_types: set, class_types: set, import_types: set,
              is_method: bool = False):
        """Walk tree-sitter AST and extract functions, classes, imports."""
        ntype = node.type

        if ntype in func_types:
            func = self._extract_function(node, content, is_method)
            if func:
                module.functions.append(func)

        elif ntype in class_types:
            cls = self._extract_class(node, content)
            if cls:
                module.classes.append(cls)
            # Walk class body for methods
            for child in node.children:
                if child.type in ("block", "class_body", "body_statement",
                                  "declaration_list", "field_declaration_list"):
                    for grandchild in child.children:
                        self._walk(grandchild, content, module,
                                   func_types, class_types, import_types,
                                   is_method=True)
            return  # Don't recurse further into this node

        elif ntype in import_types:
            import_text = content[node.start_byte:node.end_byte].decode("utf-8", errors="replace")
            # For Ruby, only capture require/require_relative calls
            if self.language == "ruby":
                if "require" in import_text:
                    module.imports.append(import_text.strip())
            else:
                module.imports.append(import_text.strip())

        # Rust impl block — extract methods from its body
        elif ntype == "impl_item" and self.language == "rust":
            for child in node.children:
                if child.type == "declaration_list":
                    for grandchild in child.children:
                        if grandchild.type in func_types:
                            func = self._extract_function(grandchild, content, is_method=True)
                            if func:
                                module.functions.append(func)
            return  # Don't recurse further

        # Go struct detection via type_declaration
        elif ntype == "type_declaration" and self.language == "go":
            cls = self._extract_go_type(node, content)
            if cls:
                module.classes.append(cls)

        # Module-level UPPER_CASE constant assignments
        elif ntype in ("expression_statement", "assignment") and not is_method:
            self._try_extract_constant(node, content, module)

        for child in node.children:
            self._walk(child, content, module, func_types, class_types, import_types, is_method)

    def _extract_function(self, node, content: bytes, is_method: bool = False) -> Optional[FunctionInfo]:
        """Extract function info from tree-sitter node."""
        name = None
        for child in node.children:
            if child.type in ("identifier", "property_identifier", "name", "field_identifier"):
                name = content[child.start_byte:child.end_byte].decode("utf-8")
                break

        # Arrow/function expressions often store name on parent variable declarator.
        if not name and node.type in ("arrow_function", "function_expression"):
            parent = getattr(node, "parent", None)
            while parent is not None:
                if parent.type in ("variable_declarator", "pair", "property_assignment", "public_field_definition"):
                    for child in parent.children:
                        if child.type in ("identifier", "property_identifier", "name", "field_identifier"):
                            name = content[child.start_byte:child.end_byte].decode("utf-8")
                            break
                    if name:
                        break
                parent = getattr(parent, "parent", None)

        if not name:
            return None

        # Get the full signature line
        sig_line = content[node.start_byte:node.end_byte].decode("utf-8", errors="replace")
        # Take first line as signature
        sig = sig_line.split("\n")[0].rstrip("{").rstrip(":").strip()
        if len(sig) > 200:
            sig = sig[:200] + "..."

        # Extract docstring (next sibling or first child string)
        docstring = self._extract_docstring(node, content)

        return FunctionInfo(
            name=name,
            line_number=node.start_point[0] + 1,
            end_line=node.end_point[0] + 1,
            docstring=docstring,
            signature=sig,
            is_async="async" in content[node.start_byte:node.start_byte + 20].decode("utf-8", errors="replace"),
            is_method=is_method,
        )

    def _extract_class(self, node, content: bytes) -> Optional[ClassInfo]:
        """Extract class info from tree-sitter node."""
        name = None
        for child in node.children:
            if child.type in ("identifier", "type_identifier", "name", "constant"):
                name = content[child.start_byte:child.end_byte].decode("utf-8")
                break

        if not name:
            return None

        return ClassInfo(
            name=name,
            line_number=node.start_point[0] + 1,
            end_line=node.end_point[0] + 1,
            docstring=self._extract_docstring(node, content),
            methods=[],
            bases=[],
        )

    def _extract_go_type(self, node, content: bytes) -> Optional[ClassInfo]:
        """Extract Go type (struct/interface) from type_declaration."""
        for child in node.children:
            if child.type == "type_spec":
                name_node = None
                for grandchild in child.children:
                    if grandchild.type == "type_identifier":
                        name_node = grandchild
                        break
                if name_node:
                    name = content[name_node.start_byte:name_node.end_byte].decode("utf-8")
                    return ClassInfo(
                        name=name,
                        line_number=node.start_point[0] + 1,
                        end_line=node.end_point[0] + 1,
                        docstring=None,
                        methods=[],
                        bases=[],
                    )
        return None

    def _try_extract_constant(self, node, content: bytes, module: ModuleInfo):
        """Extract UPPER_CASE constant assignments at module level."""
        # Find the assignment node (may be the node itself or a child)
        assign = node if node.type == "assignment" else None
        if assign is None:
            for child in node.children:
                if child.type == "assignment":
                    assign = child
                    break
        if assign is None:
            return

        # Get the left-hand side identifier
        for child in assign.children:
            if child.type in ("identifier", "name"):
                name = content[child.start_byte:child.end_byte].decode("utf-8")
                if name.isupper() and len(name) >= 2:
                    module.functions.append(FunctionInfo(
                        name=name,
                        line_number=node.start_point[0] + 1,
                        end_line=node.end_point[0] + 1,
                        docstring=None,
                        signature=name,
                        is_async=False,
                        is_method=False,
                        decorators=["constant"],
                    ))
                break  # Only check first identifier (LHS)

    def extract_call_refs(self, content: str, module: ModuleInfo) -> List[Dict[str, Any]]:
        """Extract function call references from parsed tree-sitter AST.

        Returns list of dicts with: ref_name, ref_type, line_number, containing_chunk.
        """
        content_bytes = content.encode("utf-8")
        parser, _ = _get_ts_parser(self.language)
        if not parser:
            return []
        tree = parser.parse(content_bytes)
        # Build a map of line ranges to chunk names
        chunk_ranges = []
        for func in module.functions:
            chunk_ranges.append((func.line_number, func.end_line, func.name))
        for cls in module.classes:
            chunk_ranges.append((cls.line_number, cls.end_line, cls.name))

        refs = []
        self._walk_calls(tree.root_node, content_bytes, chunk_ranges, refs)
        return refs

    def _walk_calls(self, node, content: bytes, chunk_ranges, refs):
        """Recursively walk AST to find call expressions."""
        call_types = _CALL_EXPRESSION_TYPES.get(self.language, {"call", "call_expression", "method_invocation"})

        if node.type in call_types:
            # Extract the function name being called
            func_node = node.children[0] if node.children else None
            if func_node:
                name = self._extract_call_name(func_node, content)
                if name and len(name) >= 2 and not name.startswith("__"):
                    line = node.start_point[0] + 1
                    chunk = self._find_containing_chunk(line, chunk_ranges)
                    refs.append({
                        "ref_name": name,
                        "ref_type": "call",
                        "line_number": line,
                        "containing_chunk": chunk or "<module>",
                    })

        # Rust method calls: obj.method(args) — tree-sitter node is "method_call_expression"
        elif self.language == "rust" and node.type == "method_call_expression":
            for child in node.children:
                if child.type == "field_identifier":
                    name = content[child.start_byte:child.end_byte].decode("utf-8", errors="replace")
                    if name and len(name) >= 2 and not name.startswith("__"):
                        line = node.start_point[0] + 1
                        chunk = self._find_containing_chunk(line, chunk_ranges)
                        refs.append({
                            "ref_name": name,
                            "ref_type": "call",
                            "line_number": line,
                            "containing_chunk": chunk or "<module>",
                        })
                    break

        elif self.language in ("tsx", "jsx") and node.type in ("jsx_opening_element", "jsx_self_closing_element"):
            comp_name = self._extract_jsx_component_name(node, content)
            if comp_name:
                line = node.start_point[0] + 1
                chunk = self._find_containing_chunk(line, chunk_ranges)
                refs.append({
                    "ref_name": comp_name,
                    "ref_type": "jsx_component",
                    "line_number": line,
                    "containing_chunk": chunk or "<module>",
                })

        for child in node.children:
            self._walk_calls(child, content, chunk_ranges, refs)

    def _extract_call_name(self, node, content: bytes) -> Optional[str]:
        """Extract the function name from a call target node."""
        if node.type in ("identifier", "name", "field_identifier"):
            return content[node.start_byte:node.end_byte].decode("utf-8", errors="replace")
        elif node.type in ("attribute", "member_expression", "selector_expression", "field_expression"):
            # e.g. obj.method, pkg.Func, items.iter — extract just the method/function name
            for child in reversed(node.children):
                if child.type in ("identifier", "property_identifier", "name", "field_identifier"):
                    return content[child.start_byte:child.end_byte].decode("utf-8", errors="replace")
        elif node.type == "scoped_identifier":
            # Rust: module::function — extract just the function name
            for child in reversed(node.children):
                if child.type in ("identifier", "type_identifier"):
                    return content[child.start_byte:child.end_byte].decode("utf-8", errors="replace")
        return None

    def _extract_jsx_component_name(self, node, content: bytes) -> Optional[str]:
        """Extract referenced JSX component names from opening/self-closing elements."""
        raw = content[node.start_byte:node.end_byte].decode("utf-8", errors="replace").strip()
        if raw.startswith("</"):
            return None

        # Covers tags like <AppSidebar>, <UI.Sidebar>, <Foo.Bar.Baz />
        m = re.match(r"<\s*([A-Z][A-Za-z0-9_]*(?:\.[A-Z][A-Za-z0-9_]*)*)\b", raw)
        if not m:
            return None
        name = m.group(1)
        # Use final segment so it can match chunk_name for local declarations.
        return name.split(".")[-1]

    @staticmethod
    def _find_containing_chunk(line: int, chunk_ranges) -> Optional[str]:
        """Find which chunk contains the given line number."""
        best = None
        best_size = float("inf")
        for start, end, name in chunk_ranges:
            if start <= line <= max(end, start):
                size = max(end, start) - start
                if size < best_size:
                    best = name
                    best_size = size
        return best

    def _extract_docstring(self, node, content: bytes) -> Optional[str]:
        """Try to extract a docstring from a node."""
        # Python: first child of body is expression_statement > string
        for child in node.children:
            if child.type in ("block", "body"):
                for grandchild in child.children:
                    if grandchild.type == "expression_statement":
                        for ggchild in grandchild.children:
                            if ggchild.type == "string":
                                doc = content[ggchild.start_byte:ggchild.end_byte].decode("utf-8")
                                return doc.strip("\"'").strip()
                break
        return None


# ---------------------------------------------------------------------------
# Python AST parser (built-in, no tree-sitter needed)
# ---------------------------------------------------------------------------
class PythonParser(BaseParser):
    """Parser for Python files using built-in ast module."""

    language = "python"
    extensions = {".py"}

    def parse(self, path: Path, root: Path) -> ModuleInfo:
        content = self._read_file(path, strict=True)

        try:
            tree = ast.parse(content)
        except SyntaxError as e:
            raise ParseError(f"Syntax error: {e}", str(path), e.lineno or 0)

        relative_path = path.relative_to(root)
        module_name = str(relative_path.with_suffix("")).replace("/", ".")

        module = ModuleInfo(
            path=relative_path,
            name=module_name,
            docstring=ast.get_docstring(tree),
            functions=[],
            classes=[],
            imports=[],
        )

        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    module.imports.append(alias.name)
            elif isinstance(node, ast.ImportFrom):
                level = getattr(node, "level", 0) or 0
                dotted = "." * level + (node.module or "")
                module.imports.append(dotted)

        for node in tree.body:
            if isinstance(node, ast.FunctionDef):
                module.functions.append(self._parse_function(node))
            elif isinstance(node, ast.AsyncFunctionDef):
                module.functions.append(self._parse_function(node, is_async=True))
            elif isinstance(node, ast.ClassDef):
                module.classes.append(self._parse_class(node))
            elif isinstance(node, ast.Assign):
                for target in node.targets:
                    if isinstance(target, ast.Name) and target.id.isupper():
                        end = getattr(node, 'end_lineno', node.lineno)
                        module.functions.append(FunctionInfo(
                            name=target.id,
                            line_number=node.lineno,
                            end_line=end,
                            docstring=None,
                            signature=target.id,
                            is_async=False,
                            is_method=False,
                            decorators=["constant"],
                        ))

        return module

    def _parse_function(self, node, is_async=False, is_method=False) -> FunctionInfo:
        args = []
        for arg in node.args.args:
            arg_str = arg.arg
            if arg.annotation:
                arg_str += f": {ast.unparse(arg.annotation)}"
            args.append(arg_str)

        signature = f"{node.name}({', '.join(args)})"

        decorators = []
        for decorator in node.decorator_list:
            if isinstance(decorator, ast.Name):
                decorators.append(decorator.id)
            elif isinstance(decorator, ast.Attribute):
                decorators.append(decorator.attr)
            elif isinstance(decorator, ast.Call):
                if isinstance(decorator.func, ast.Name):
                    decorators.append(f"{decorator.func.id}()")

        return FunctionInfo(
            name=node.name,
            line_number=node.lineno,
            end_line=getattr(node, 'end_lineno', node.lineno),
            docstring=ast.get_docstring(node),
            signature=signature,
            is_async=is_async or isinstance(node, ast.AsyncFunctionDef),
            is_method=is_method,
            decorators=decorators,
        )

    def extract_call_refs(self, content: str, module: ModuleInfo) -> List[Dict[str, Any]]:
        """Extract function call references using Python AST.

        Returns list of dicts with: ref_name, ref_type, line_number, containing_chunk.
        """
        try:
            tree = ast.parse(content)
        except SyntaxError:
            return []

        # Build chunk ranges
        chunk_ranges = []
        for func in module.functions:
            chunk_ranges.append((func.line_number, func.end_line, func.name))
        for cls in module.classes:
            chunk_ranges.append((cls.line_number, cls.end_line, cls.name))

        # Resolve import aliases so call-graph links map back to declaration names.
        alias_map: Dict[str, str] = {}
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    if alias.asname:
                        alias_map[alias.asname] = alias.name.split(".")[-1]
            elif isinstance(node, ast.ImportFrom):
                for alias in node.names:
                    local_name = alias.asname or alias.name
                    alias_map[local_name] = alias.name.split(".")[-1]
            elif isinstance(node, ast.Assign) and isinstance(node.value, ast.Name):
                resolved = alias_map.get(node.value.id, node.value.id)
                for target in node.targets:
                    if isinstance(target, ast.Name):
                        alias_map[target.id] = resolved

        refs = []
        seen = set()
        for node in ast.walk(tree):
            if isinstance(node, ast.Call):
                name = None
                if isinstance(node.func, ast.Name):
                    name = alias_map.get(node.func.id, node.func.id)
                elif isinstance(node.func, ast.Attribute):
                    name = node.func.attr

                if name and len(name) >= 2 and not name.startswith("__"):
                    line = getattr(node, "lineno", 0)
                    chunk = TreeSitterParser._find_containing_chunk(line, chunk_ranges)
                    key = (name, line, chunk or "<module>")
                    if key in seen:
                        continue
                    seen.add(key)
                    refs.append({
                        "ref_name": name,
                        "ref_type": "call",
                        "line_number": line,
                        "containing_chunk": chunk or "<module>",
                    })
        return refs

    def _parse_class(self, node) -> ClassInfo:
        methods = []
        for item in node.body:
            if isinstance(item, ast.FunctionDef):
                methods.append(self._parse_function(item, is_method=True))
            elif isinstance(item, ast.AsyncFunctionDef):
                methods.append(self._parse_function(item, is_async=True, is_method=True))

        bases = []
        for base in node.bases:
            if isinstance(base, ast.Name):
                bases.append(base.id)
            elif isinstance(base, ast.Attribute):
                bases.append(ast.unparse(base))

        return ClassInfo(
            name=node.name,
            line_number=node.lineno,
            end_line=getattr(node, 'end_lineno', node.lineno),
            docstring=ast.get_docstring(node),
            methods=methods,
            bases=bases,
        )


# ---------------------------------------------------------------------------
# Regex fallback parsers
# ---------------------------------------------------------------------------
class RegexParser(BaseParser):
    """Regex-based parser for when tree-sitter is unavailable."""

    # Override these in subclasses
    _func_pattern: str = ""
    _class_pattern: str = ""
    _import_pattern: str = ""

    # Generic call extraction — subclasses can override _CALL_PATTERN and _CALL_SKIP
    _CALL_PATTERN = re.compile(r"\b([A-Za-z_]\w*)\s*\(")
    _CALL_SKIP: set = {
        "if", "for", "while", "switch", "return", "catch",
    }

    def extract_call_refs(self, content: str, module: ModuleInfo) -> List[Dict[str, Any]]:
        """Extract call refs via regex pattern matching."""
        refs: List[Dict[str, Any]] = []
        seen: set = set()
        chunk_ranges = []
        for func in module.functions:
            end = func.end_line if func.end_line >= func.line_number else func.line_number
            chunk_ranges.append((func.line_number, end, func.name))
        for cls in module.classes:
            end = cls.end_line if cls.end_line >= cls.line_number else cls.line_number
            chunk_ranges.append((cls.line_number, end, cls.name))

        for line_no, line in enumerate(content.split("\n"), 1):
            for match in self._CALL_PATTERN.finditer(line):
                ref_name = match.group(1)
                if ref_name in self._CALL_SKIP or len(ref_name) < 2:
                    continue
                containing = TreeSitterParser._find_containing_chunk(line_no, chunk_ranges)
                key = (ref_name, line_no, containing or "<module>")
                if key in seen:
                    continue
                seen.add(key)
                refs.append({
                    "ref_name": ref_name,
                    "ref_type": "call",
                    "line_number": line_no,
                    "containing_chunk": containing or "<module>",
                })
        return refs

    def parse(self, path: Path, root: Path) -> ModuleInfo:
        content = self._read_file(path)
        relative_path = path.relative_to(root)
        module_name = str(relative_path.with_suffix("")).replace("/", ".")

        module = ModuleInfo(
            path=relative_path,
            name=module_name,
            docstring=None,
            functions=[],
            classes=[],
            imports=[],
        )

        lines = content.split("\n")
        for i, line in enumerate(lines, 1):
            stripped = line.strip()

            if self._func_pattern:
                match = re.match(self._func_pattern, stripped)
                if match:
                    name = match.group(1)
                    module.functions.append(FunctionInfo(
                        name=name, line_number=i, end_line=0,
                        docstring=None,
                        signature=stripped.rstrip("{:").strip(),
                        is_async="async" in stripped,
                        is_method=False,
                    ))

            if self._class_pattern:
                match = re.match(self._class_pattern, stripped)
                if match:
                    name = match.group(1)
                    module.classes.append(ClassInfo(
                        name=name, line_number=i, end_line=0,
                        docstring=None,
                        methods=[], bases=[],
                    ))

            if self._import_pattern:
                match = re.match(self._import_pattern, stripped)
                if match:
                    module.imports.append(stripped)

        return module


class TypeScriptRegexParser(RegexParser):
    language = "typescript"
    extensions = {".ts", ".tsx", ".js", ".jsx"}
    _func_pattern = r"(?:export\s+)?(?:async\s+)?function\s+(\w+)"
    _class_pattern = r"(?:export\s+)?class\s+(\w+)"
    _import_pattern = r"import\s+"

    _FUNC_PATTERNS = (
        re.compile(r"(?:export\s+)?(?:default\s+)?(?:async\s+)?function\s+([A-Za-z_]\w*)"),
        re.compile(
            r"(?:export\s+)?(?:const|let|var)\s+([A-Za-z_]\w*)\s*="
            r"\s*(?:async\s*)?(?:\([^)]*\)|[A-Za-z_]\w*)\s*=>"
        ),
        re.compile(
            r"(?:export\s+)?(?:const|let|var)\s+([A-Za-z_]\w*)\s*"
            r"(?::[^=]+)?=\s*(?:async\s*)?(?:\([^)]*\)|[A-Za-z_]\w*)\s*=>"
        ),
        re.compile(r"(?:export\s+)?(?:const|let|var)\s+([A-Za-z_]\w*)\s*=\s*(?:async\s*)?function\b"),
    )

    _CALL_PATTERN = re.compile(r"\b([A-Za-z_]\w*)\s*\(")
    _JSX_COMPONENT_PATTERN = re.compile(r"<\s*([A-Z][A-Za-z0-9_]*(?:\.[A-Z][A-Za-z0-9_]*)*)\b")
    _IMPORT_TARGET_PATTERN = re.compile(
        r"""(?:import\s+.*?\s+from\s+|export\s+.*?\s+from\s+|import\s+)\s*["']([^"']+)["']""",
        re.DOTALL,
    )
    _CALL_SKIP = {
        "if", "for", "while", "switch", "catch", "return", "typeof", "new",
        "function", "await", "import", "console",
    }

    @staticmethod
    def _find_block_end(lines: List[str], start_idx: int) -> int:
        """Best-effort brace matching to estimate function body end line."""
        depth = 0
        saw_open = False
        for i in range(start_idx, len(lines)):
            for ch in lines[i]:
                if ch == "{":
                    depth += 1
                    saw_open = True
                elif ch == "}":
                    depth -= 1
            if saw_open and depth <= 0:
                return i + 1
        return start_idx + 1

    def parse(self, path: Path, root: Path) -> ModuleInfo:
        """Parse TS/JS files with improved function/component extraction."""
        content = self._read_file(path)
        relative_path = path.relative_to(root)
        module_name = str(relative_path.with_suffix("")).replace("/", ".")

        module = ModuleInfo(
            path=relative_path,
            name=module_name,
            docstring=None,
            functions=[],
            classes=[],
            imports=[],
        )

        lines = content.split("\n")
        for i, line in enumerate(lines, 1):
            stripped = line.strip()
            if not stripped:
                continue

            is_import_stmt = stripped.startswith("import ") or stripped.startswith("export ")
            if is_import_stmt:
                stmt = stripped
                if (" from " not in stmt and not re.search(r'import\s+["\']', stmt)) and i < len(lines):
                    # Multi-line imports/exports: keep appending until module literal appears.
                    for j in range(i, min(len(lines), i + 12)):
                        stmt += " " + lines[j].strip()
                        if " from " in stmt or re.search(r'import\s+["\']', stmt):
                            break
                m = self._IMPORT_TARGET_PATTERN.search(stmt)
                if m:
                    module.imports.append(f'import "{m.group(1)}"')

            if self._class_pattern:
                match = re.match(self._class_pattern, stripped)
                if match:
                    module.classes.append(ClassInfo(
                        name=match.group(1), line_number=i, end_line=0,
                        docstring=None, methods=[], bases=[],
                    ))

            for pattern in self._FUNC_PATTERNS:
                match = pattern.match(stripped)
                if not match:
                    continue
                name = match.group(1)
                end_line = self._find_block_end(lines, i - 1)
                module.functions.append(FunctionInfo(
                    name=name,
                    line_number=i,
                    end_line=end_line,
                    docstring=None,
                    signature=stripped.rstrip("{:").strip(),
                    is_async="async" in stripped,
                    is_method=False,
                ))
                break

        return module

    def extract_call_refs(self, content: str, module: ModuleInfo) -> List[Dict[str, Any]]:
        """Extract call refs via regex when tree-sitter is unavailable."""
        refs: List[Dict[str, Any]] = []
        seen = set()
        chunk_ranges = []
        for func in module.functions:
            end = func.end_line if func.end_line >= func.line_number else func.line_number
            chunk_ranges.append((func.line_number, end, func.name))
        for cls in module.classes:
            end = cls.end_line if cls.end_line >= cls.line_number else cls.line_number
            chunk_ranges.append((cls.line_number, end, cls.name))

        for line_no, line in enumerate(content.split("\n"), 1):
            for match in self._CALL_PATTERN.finditer(line):
                ref_name = match.group(1)
                if ref_name in self._CALL_SKIP or len(ref_name) < 2:
                    continue
                containing = TreeSitterParser._find_containing_chunk(line_no, chunk_ranges)
                key = (ref_name, line_no, containing or "<module>")
                if key in seen:
                    continue
                seen.add(key)
                refs.append({
                    "ref_name": ref_name,
                    "ref_type": "call",
                    "line_number": line_no,
                    "containing_chunk": containing or "<module>",
                })
            # JSX component references behave like calls for dependency tracing.
            for match in self._JSX_COMPONENT_PATTERN.finditer(line):
                ref_name = match.group(1).split(".")[-1]
                containing = TreeSitterParser._find_containing_chunk(line_no, chunk_ranges)
                key = (ref_name, line_no, containing or "<module>")
                if key in seen:
                    continue
                seen.add(key)
                refs.append({
                    "ref_name": ref_name,
                    "ref_type": "jsx_component",
                    "line_number": line_no,
                    "containing_chunk": containing or "<module>",
                })
        return refs


class GoRegexParser(RegexParser):
    language = "go"
    extensions = {".go"}
    _func_pattern = r"func\s+(?:\([^)]+\)\s+)?(\w+)\s*\("
    _class_pattern = r"type\s+(\w+)\s+struct"
    _import_pattern = r"import\s+"
    _CALL_SKIP = {
        "if", "for", "range", "switch", "select", "go", "defer", "return",
        "make", "len", "cap", "append", "copy", "delete", "close",
        "panic", "recover", "print", "println", "new", "func",
    }


class RustRegexParser(RegexParser):
    language = "rust"
    extensions = {".rs"}
    _func_pattern = r"(?:pub\s+)?(?:async\s+)?fn\s+(\w+)"
    _class_pattern = r"(?:pub\s+)?(?:struct|enum|trait)\s+(\w+)"
    _import_pattern = r"use\s+"
    _CALL_SKIP = {
        "if", "for", "while", "match", "loop", "return", "unsafe", "async",
        "move", "fn", "let", "mut", "impl", "use", "mod", "pub", "self",
        "Some", "None", "Ok", "Err",
    }


class JavaRegexParser(RegexParser):
    language = "java"
    extensions = {".java"}
    _func_pattern = r"(?:public|private|protected)?\s*(?:static\s+)?(?:\w+\s+)+(\w+)\s*\("
    _class_pattern = r"(?:public\s+)?(?:abstract\s+)?class\s+(\w+)"
    _import_pattern = r"import\s+"
    _CALL_SKIP = {
        "if", "for", "while", "switch", "catch", "return", "new", "throw",
        "instanceof", "class", "interface", "extends", "implements",
    }


class RubyRegexParser(RegexParser):
    language = "ruby"
    extensions = {".rb"}
    _func_pattern = r"def\s+(?:self\.)?(\w+)"
    _class_pattern = r"(?:class|module)\s+(\w+)"
    _import_pattern = r"require"
    _CALL_SKIP = {
        "if", "unless", "while", "until", "for", "case", "when", "return",
        "require", "require_relative", "puts", "print", "raise", "def",
        "end", "do", "class", "module", "attr_reader", "attr_writer", "attr_accessor",
    }


class CRegexParser(RegexParser):
    language = "c"
    extensions = {".c", ".h", ".cpp", ".cc", ".cxx", ".hpp"}
    _func_pattern = r"(?:\w+[\s*]+)+(\w+)\s*\([^)]*\)\s*\{"
    _class_pattern = r"(?:struct|class)\s+(\w+)"
    _import_pattern = r"#include"
    _CALL_SKIP = {
        "if", "for", "while", "switch", "return", "sizeof", "typeof",
        "define", "ifdef", "ifndef", "endif", "include", "struct", "enum",
        "void", "int", "char", "float", "double", "long", "unsigned",
    }


class SwiftRegexParser(RegexParser):
    language = "swift"
    extensions = {".swift"}
    _func_pattern = r"(?:public|private|fileprivate|internal|open)?\s*(?:static\s+)?func\s+([A-Za-z_]\w*)"
    _class_pattern = r"(?:public|private|fileprivate|internal|open)?\s*(?:final\s+)?(?:class|struct|enum|protocol)\s+([A-Za-z_]\w*)"
    _import_pattern = r"import\s+"
    _CALL_SKIP = {
        "if", "for", "while", "switch", "guard", "return", "throw", "catch",
        "func", "class", "struct", "enum", "protocol", "import", "let", "var",
    }


# ---------------------------------------------------------------------------
# Backwards-compatible aliases (used by tests and external code)
# ---------------------------------------------------------------------------
class TypeScriptParser(TypeScriptRegexParser):
    """TypeScript parser — delegates to tree-sitter or regex."""

    def __init__(self, use_treesitter: bool = True, language: str = "typescript"):
        self._delegate = None
        self.language = language if language in {"typescript", "tsx", "javascript", "jsx"} else "typescript"
        if use_treesitter:
            parser, _ = _get_ts_parser(self.language)
            if parser is not None:
                self._delegate = TreeSitterParser(self.language)

    def parse(self, path: Path, root: Path) -> ModuleInfo:
        if self._delegate:
            return self._delegate.parse(path, root)
        return TypeScriptRegexParser.parse(self, path, root)

    def extract_call_refs(self, content: str, module: ModuleInfo) -> List[Dict[str, Any]]:
        if self._delegate:
            return self._delegate.extract_call_refs(content, module)
        return TypeScriptRegexParser.extract_call_refs(self, content, module)


class GoParser(GoRegexParser):
    """Go parser — delegates to tree-sitter or regex."""

    def __init__(self, use_treesitter: bool = True):
        self._delegate = None
        if use_treesitter:
            parser, _ = _get_ts_parser("go")
            if parser is not None:
                self._delegate = TreeSitterParser("go")

    def parse(self, path: Path, root: Path) -> ModuleInfo:
        if self._delegate:
            return self._delegate.parse(path, root)
        return GoRegexParser.parse(self, path, root)

    def extract_call_refs(self, content: str, module: ModuleInfo) -> List[Dict[str, Any]]:
        if self._delegate:
            return self._delegate.extract_call_refs(content, module)
        return GoRegexParser.extract_call_refs(self, content, module)


# ---------------------------------------------------------------------------
# Parser factory
# ---------------------------------------------------------------------------
_REGEX_PARSERS: Dict[str, type] = {
    "typescript": TypeScriptRegexParser,
    "tsx": TypeScriptRegexParser,
    "javascript": TypeScriptRegexParser,
    "jsx": TypeScriptRegexParser,
    "go": GoRegexParser,
    "rust": RustRegexParser,
    "java": JavaRegexParser,
    "ruby": RubyRegexParser,
    "c": CRegexParser,
    "cpp": CRegexParser,
    "swift": SwiftRegexParser,
}


class ParserFactory:
    """Factory for creating language-specific parsers.

    Prefers tree-sitter when available, falls back to regex.
    Python always uses the built-in ast module.
    """

    _parsers: Dict[str, BaseParser] = {}

    @classmethod
    def get_parser(cls, language: str, use_treesitter: bool = True) -> Optional[BaseParser]:
        """Get a parser for the specified language."""
        cache_key = f"{language}:{use_treesitter}"

        if cache_key not in cls._parsers:
            # Python always uses built-in ast
            if language == "python":
                cls._parsers[cache_key] = PythonParser()
            elif language in ("typescript", "tsx", "javascript", "jsx"):
                cls._parsers[cache_key] = TypeScriptParser(use_treesitter=use_treesitter, language=language)
            elif language == "go":
                cls._parsers[cache_key] = GoParser(use_treesitter)
            elif use_treesitter:
                # Try tree-sitter first for other languages
                parser, _ = _get_ts_parser(language)
                if parser is not None:
                    cls._parsers[cache_key] = TreeSitterParser(language)
                elif language in _REGEX_PARSERS:
                    cls._parsers[cache_key] = _REGEX_PARSERS[language]()
                else:
                    return None
            elif language in _REGEX_PARSERS:
                cls._parsers[cache_key] = _REGEX_PARSERS[language]()
            else:
                return None

        return cls._parsers[cache_key]

    @classmethod
    def get_parser_for_file(cls, path: Path, use_treesitter: bool = True) -> Optional[BaseParser]:
        """Get a parser based on file extension."""
        suffix = path.suffix.lower()
        language = EXTENSION_TO_LANGUAGE.get(suffix)
        if language:
            return cls.get_parser(language, use_treesitter)
        return None

    @classmethod
    def supported_extensions(cls) -> set:
        """Return all supported file extensions."""
        return set(EXTENSION_TO_LANGUAGE.keys())

    @classmethod
    def clear_cache(cls) -> None:
        """Clear the parser cache."""
        cls._parsers.clear()
        _parser_cache.clear()
