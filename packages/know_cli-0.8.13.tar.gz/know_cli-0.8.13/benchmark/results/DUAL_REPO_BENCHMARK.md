# Dual-Repo Parallel Benchmark

- Generated at: 2026-03-03T13:19:48.420716+00:00
- Strategies: `grep+read` baseline vs `know workflow` (single daemon RPC)
- Language globs: `py, ts, tsx, js, jsx, go, rs, swift`

## /Users/sushil/Code/Github/know-cli

- know version: `0.8.12`
- Token reduction: `93.3%` | Latency ratio (know/grep): `2.14x` | Tool-call reduction: `93.8%`
- Warm p50/p95: `0.124s / 0.128s` | Cold start: `0.479s` | Fallback rate: `0.0%`
- Deep call-graph available: `100.0%` | non-empty edges: `90.0%`

| Query | Grep Tokens | know Tokens | Token Savings | Grep Time (s) | know Time (s) | know Payload (bytes) | Fallback |
|---|---:|---:|---:|---:|---:|---:|---:|
| configuration loading and environment variable handling | 39,819 | 5,727 | 85.6% | 0.116 | 0.128 | 39,466 | no |
| database schema and persistence layer | 46,792 | 3,433 | 92.7% | 0.049 | 0.119 | 25,226 | no |
| module dependency graph and call graph tracking | 102,108 | 3,901 | 96.2% | 0.06 | 0.124 | 28,855 | no |
| error handling and retry logic | 93,687 | 5,002 | 94.7% | 0.055 | 0.127 | 34,694 | no |
| workflow command availability and command registration | 49,745 | 5,155 | 89.6% | 0.045 | 0.128 | 36,338 | no |
| memory recall and decision capture flow | 60,803 | 4,092 | 93.3% | 0.046 | 0.123 | 29,687 | no |
| background daemon indexing and cache refresh behavior | 79,100 | 3,735 | 95.3% | 0.054 | 0.126 | 27,044 | no |
| api route validation and schema handling | 58,459 | 4,708 | 91.9% | 0.049 | 0.124 | 34,726 | no |
| session deduplication and token budget reuse | 89,114 | 4,340 | 95.1% | 0.057 | 0.124 | 31,354 | no |
| retry/backoff behavior in external service integrations | 65,634 | 5,908 | 91.0% | 0.05 | 0.123 | 34,092 | no |

## /Users/sushil/Code/Github/farfield

- know version: `0.8.12`
- Token reduction: `95.4%` | Latency ratio (know/grep): `1.51x` | Tool-call reduction: `93.8%`
- Warm p50/p95: `0.177s / 0.184s` | Cold start: `3.022s` | Fallback rate: `10.0%`
- Deep call-graph available: `90.0%` | non-empty edges: `70.0%`

| Query | Grep Tokens | know Tokens | Token Savings | Grep Time (s) | know Time (s) | know Payload (bytes) | Fallback |
|---|---:|---:|---:|---:|---:|---:|---:|
| configuration loading and environment variable handling | 63,549 | 3,038 | 95.2% | 0.111 | 0.177 | 26,097 | no |
| database schema and persistence layer | 57,214 | 3,543 | 93.8% | 0.108 | 0.18 | 29,501 | no |
| module dependency graph and call graph tracking | 89,078 | 3,555 | 96.0% | 0.116 | 0.177 | 34,367 | no |
| error handling and retry logic | 117,364 | 3,951 | 96.6% | 0.127 | 0.181 | 36,231 | no |
| workflow command availability and command registration | 78,457 | 3,246 | 95.9% | 0.115 | 0.169 | 24,727 | no |
| memory recall and decision capture flow | 53,798 | 4,216 | 92.2% | 0.11 | 0.176 | 36,413 | no |
| background daemon indexing and cache refresh behavior | 79,769 | 2,935 | 96.3% | 0.115 | 0.174 | 21,574 | yes |
| api route validation and schema handling | 100,455 | 4,050 | 96.0% | 0.128 | 0.175 | 34,342 | no |
| session deduplication and token budget reuse | 132,355 | 5,167 | 96.1% | 0.134 | 0.186 | 40,634 | no |
| retry/backoff behavior in external service integrations | 77,457 | 4,991 | 93.6% | 0.109 | 0.18 | 33,786 | no |
