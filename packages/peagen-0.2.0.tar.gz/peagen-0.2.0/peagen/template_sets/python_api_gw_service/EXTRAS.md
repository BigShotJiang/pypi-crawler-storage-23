# Extras Keys for python_api_gw_service

This template set recognizes the following EXTRAS keys:

- RESOURCE_KIND
- PURPOSE
- DESCRIPTION
- REQUIREMENTS
- DEPENDENCIES
