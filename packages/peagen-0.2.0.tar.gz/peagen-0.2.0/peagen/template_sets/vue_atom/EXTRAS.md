# Extras Keys for vue_atom

This template set recognizes the following EXTRAS keys:

- RESOURCE_KIND
- PURPOSE
- DESCRIPTION
- REQUIREMENTS
- STATES
- DEPENDENCIES
