class WebhookPublisher:
    def __init__(self, **kwargs):
        self.kwargs = kwargs
