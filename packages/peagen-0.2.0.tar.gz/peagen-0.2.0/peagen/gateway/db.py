from tigrbl.engine import engine as build_engine
from .runtime_cfg import settings

if settings.pg_dsn_env or (settings.pg_host and settings.pg_db and settings.pg_user):
    dsn = settings.apg_dsn
else:
    dsn = "sqlite+aiosqlite:///./gateway.db"

ENGINE = build_engine(dsn)
get_db = ENGINE.get_db

__all__ = ["ENGINE", "get_db", "dsn"]
