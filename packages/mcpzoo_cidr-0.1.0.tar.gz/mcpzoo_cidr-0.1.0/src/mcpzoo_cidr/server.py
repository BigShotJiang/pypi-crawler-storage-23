import ipaddress
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("cidr")

@mcp.tool()
def calc_cidr(cidr: str) -> str:
    """计算 CIDR 网段的 IP 范围和主机数。"""
    try:
        network = ipaddress.ip_network(cidr, strict=False)
        return (
            f"网络地址: {network.network_address}\n"
            f"广播地址: {network.broadcast_address}\n"
            f"掩码: {network.netmask}\n"
            f"可用主机数: {network.num_addresses - 2 if network.num_addresses > 2 else network.num_addresses}\n"
            f"IP 范围: {network[0]} - {network[-1]}"
        )
    except ValueError as e:
        return f"CIDR 解析错误: {e}"

def main():
    mcp.run()

if __name__ == "__main__":
    main()
