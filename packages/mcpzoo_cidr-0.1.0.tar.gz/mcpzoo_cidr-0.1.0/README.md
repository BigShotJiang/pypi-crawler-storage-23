# mcpzoo-cidr

> CIDR 计算 — 计算 CIDR 网段的 IP 范围和主机数

## Installation

```bash
uvx mcpzoo-cidr
```

## uvx JSON

```json
{
  "mcpServers": {
    "cidr": {
      "args": ["mcpzoo-cidr"],
      "command": "uvx"
    }
  }
}
```
