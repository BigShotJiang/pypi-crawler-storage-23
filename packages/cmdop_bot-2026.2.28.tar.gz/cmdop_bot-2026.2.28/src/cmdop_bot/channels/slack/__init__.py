"""Slack app integration."""

from cmdop_bot.channels.slack.app import SlackApp

__all__ = ["SlackApp"]
