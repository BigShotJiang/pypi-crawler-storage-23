###############################################################################
# General settings
###############################################################################

# The amount of indentation to use for each level in DOT files. You could also
# use a \t character here, if you're the sort of person who prefers tabs ._.
INDENT = "  "

# The conversion factor between inches (Graphviz) and pixels (Cytoscape.js).
# There is a lot of history to this, and I think Cytoscape.js has changed its
# system from points to pixels??? Or maybe it was always in pixels and graphviz
# has just been kind of inconsistent with its units being in points or inches
# depending on bounding boxes or coordinates??? let's just see how things go
PIXELS_PER_INCH = 54

########
# Node scaling
########

# The base we use when logarithmically scaling contig dimensions from length
NODE_SCALING_LOG_BASE = 10

NOLENGTH_NODE_WIDTH = 0.4
NOLENGTH_NODE_HEIGHT = 0.4

########
# Graph style
########
# General graph style. Feel free to insert newlines/tabs for readability.
# Any text here must end without a semicolon.
PROG2GRAPHSTYLE = {"dot": "rankdir=LR", "sfdp": "overlap=prism"}

########
# Node style
########
# Note that this style impacts node groups in the "backfilled" layouts
# generated using -pg or -px, since node groups are temporarily represented as
# nodes.
#
# "fixedsize=true" is needed in order to prevent node labels from causing nodes
# to be resized. Might trigger some warnings from Graphviz but oh well, better
# that than nodes getting assigned the wrong sizes.
#
# "orientation=90" is needed in order to get nodes to be correctly
# rotated (to point in the left --> right direction), which makes the graph
# look as intended when rankdir=LR. Shoutouts to
# https://stackoverflow.com/a/45431027 for the wisdom that the node
# "orientation" attr existed.
GLOBALNODE_STYLE = "fixedsize=true,orientation=90"

# Colors in nodes in the drawings produced by dot (without having an effect on
# the interactive visualization in Cy.js, which doesn't care what colors dot
# says things are)
GLOBALNODE_STYLE += ',style=filled,fillcolor="#888888"'

########
# Edge style
########

# Style applied to every edge in the graph.
GLOBALEDGE_STYLE = ""

# fake edges
FAKEEDGE_STYLE = 'style="dashed"'

# back edges (from an end node to a start node of a single pattern)
# this prevents these edges from impacting node ranking, which makes
# cyclic chains look much nicer - see
# https://github.com/marbl/MetagenomeScope/issues/368
# and https://stackoverflow.com/a/6826107
BACKEDGE_STYLE = 'constraint="false"'

# If all of the control points of an edge are close enough to the straight
# line from source to target, then we won't bother drawing the edge using its
# control points -- we'll just mark it a basic bezier or something. This value
# controls how close "close enough" is.
CTRL_PT_DIST_EPSILON = 10

########
# Cluster (pattern) style
########

# used for the "padding" style in Cy.js and subgraph "margin". Cytoscape.js is
# not clear on what the default padding is but this seems to match it -- based
# on going through its codebase and noticing
# https://github.com/cytoscape/cytoscape.js/blob/57e681a052d79c02f6e9fa802ff0c9ce9a77ff3e/snippets/animated-bfs.js#L56
# NOTE: this is not currently used in recursive layout. Maybe the way to
# handle that would be adjusting the "pad" setting for the entire graph when
# laying out subregions...?
CLUSTER_PADDING = 10

###############################################################################
# Client-side (i.e. done like within Cytoscape.js I guess?) layout settings
###############################################################################

# Dagre and fCoSE support animating the layout. I guess we might as well
# support this since it looks nice -- plus these layouts put all of the nodes
# in the same position at the start, so if we don't turn on animation then
# the user still sees this "flash of unstyled content" i guess
#
# Anyway, they have slightly different default duration settings, so let's
# standardize things here so that the user gets the same kinda experience
#
# (Actually controlling "animate" - whether or not we do animation at all -
# is controlled by a checkbox, which is controlled by
# ui_config.DEFAULT_DRAW_SETTINGS)
ANIMATION_SETTINGS = {
    "animationDuration": 500,
}
