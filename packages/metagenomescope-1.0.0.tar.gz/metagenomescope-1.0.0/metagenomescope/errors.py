class GraphParsingError(Exception):
    pass


class PathParsingError(Exception):
    pass


class GraphError(Exception):
    pass


class WeirdError(Exception):
    pass


class UIError(Exception):
    pass
