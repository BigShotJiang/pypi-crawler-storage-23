#!/usr/bin/env python3
# coding: utf-8

from .core import distance_matrix

__all__ = ["distance_matrix"]
