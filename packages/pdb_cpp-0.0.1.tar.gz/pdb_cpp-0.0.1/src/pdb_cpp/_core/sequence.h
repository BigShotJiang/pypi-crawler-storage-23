#include <array>
#include <cstring>
#include <stdexcept>

char convert_to_one_letter_resname(const std::array<char, 5> &resname_array);
char convert_to_one_letter_resname_dl(const std::array<char, 5> &resname_array);
char convert_to_one_letter_resname_na(const std::array<char, 5> &resname_array);
char convert_to_one_letter_resname_any(const std::array<char, 5> &resname_array);