# Guardrail Workflows 🔄

Visual guide to common usage patterns and workflows.

---

## 1. Initial Setup Workflow

```
┌─────────────────────────────────────────────────────────┐
│                    INITIAL SETUP                        │
└─────────────────────────────────────────────────────────┘

1. Clone Repository
   ↓
   git clone <repo-url>
   cd IntentAnalyser-AIGuardrail

2. Install Dependencies
   ↓
   pip install -r requirements.txt

3. Configure Environment
   ↓
   export HUGGINGFACE_API_TOKEN=hf_xxxxx
   export PORT=8002

4. Initialize Policy
   ↓
   ./guardrail init
   
   Prompts:
   ┌──────────────────────────┐
   │ Select policy template:  │
   │ 1. strict                │
   │ 2. balanced   ← default  │
   │ 3. permissive            │
   └──────────────────────────┘

5. Validate Setup
   ↓
   ./guardrail policy validate
   
   Output:
   [OK] YAML schema valid
   [OK] Cedar compilation successful
   [OK] No conflicting rules detected

6. Start Server
   ↓
   python main.py
   
   Server running on http://localhost:8002
```

---

## 2. Policy Development Workflow

```
┌─────────────────────────────────────────────────────────┐
│              POLICY DEVELOPMENT CYCLE                   │
└─────────────────────────────────────────────────────────┘

START
  ↓
┌─────────────────────┐
│ Launch TUI Editor   │
│ ./guardrail policy  │
│         edit        │
└─────────────────────┘
  ↓
┌─────────────────────────────────────────────────────────┐
│                    TUI INTERFACE                        │
│                                                         │
│  Blocked Tiers:  [x] P0  [x] P1  [ ] P2  [ ] P3  [ ] P4│
│                                                         │
│  Role Overrides:                                        │
│    admin    : ALL                                       │
│    analyst  : P3_Low                                    │
│                                                         │
│  Low Confidence:                                        │
│    threshold: 0.4                                       │
│    clamp_tier: P3_Low                                   │
│                                                         │
│  Commands: template blocked override remove lowconf     │
│            simulate save quit help                      │
└─────────────────────────────────────────────────────────┘
  ↓
Make Changes (toggle tiers, add overrides, etc.)
  ↓
Test with 'simulate' or 'm'
  ↓
┌─────────────────────┐
│  Simulation Result  │
│  Decision: BLOCK    │
│  Tier: P0_Critical  │
│  Matched: blocked_  │
│           tiers     │
└─────────────────────┘
  ↓
Satisfied? ──No──→ Continue editing
  ↓ Yes
Save with 'save' or 's'
  ↓
┌─────────────────────┐
│ Files Updated:      │
│ ✓ main.yaml         │
│ ✓ main.cedar        │
└─────────────────────┘
  ↓
Exit with 'quit' or 'q'
  ↓
Validate
  ↓
./guardrail policy validate
  ↓
Deploy/Restart Server
```

---

## 3. API Integration Workflow

```
┌─────────────────────────────────────────────────────────┐
│                  API INTEGRATION                        │
└─────────────────────────────────────────────────────────┘

Application Request
  ↓
┌──────────────────────────────────────┐
│  POST /intent                        │
│  {                                   │
│    "text": "user input",             │
│    "role": "general"                 │
│  }                                   │
└──────────────────────────────────────┘
  ↓
┌─────────────────────────────────────────────────────────┐
│              GUARDRAIL PROCESSING                       │
│                                                         │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐            │
│  │  Regex   │  │ Semantic │  │ Zero-Shot│            │
│  │ Detector │  │ Detector │  │ Detector │            │
│  └────┬─────┘  └────┬─────┘  └────┬─────┘            │
│       │             │             │                    │
│       └─────────────┴─────────────┘                    │
│                     ↓                                   │
│            ┌─────────────────┐                         │
│            │  Risk Engine    │                         │
│            │  + Policy Check │                         │
│            └─────────────────┘                         │
└─────────────────────────────────────────────────────────┘
  ↓
┌──────────────────────────────────────┐
│  Response                            │
│  {                                   │
│    "decision": "block",              │
│    "intent": "code.exploit",         │
│    "risk_score": 0.95,               │
│    "tier": "P0_Critical",            │
│    "confidence": 0.98,               │
│    "reason": "Prompt injection"      │
│  }                                   │
└──────────────────────────────────────┘
  ↓
Application Decision
  ↓
┌─────────────┬─────────────┐
│   ALLOW     │    BLOCK    │
│  Continue   │   Reject    │
│  Processing │   Request   │
└─────────────┴─────────────┘
```

---

## 4. Testing Workflow

```
┌─────────────────────────────────────────────────────────┐
│                  TESTING WORKFLOW                       │
└─────────────────────────────────────────────────────────┘

1. Unit Testing
   ↓
   python -m pytest tests/test_policy_simulator.py
   
   Output:
   ✓ test_simulate_critical_threat
   ✓ test_simulate_role_override
   ✓ test_low_confidence_clamp

2. CLI Simulation
   ↓
   ./guardrail policy simulate \
     --tier P0_Critical \
     --confidence 0.9
   
   Decision: BLOCK
   Matched: blocked_tiers
   Final Tier: P0_Critical

3. API Testing
   ↓
   curl -X POST http://localhost:8002/intent \
     -H "Content-Type: application/json" \
     -d '{"text": "test input", "role": "general"}'
   
   {
     "decision": "allow",
     "risk_score": 0.12,
     ...
   }

4. Stress Testing
   ↓
   python tests/stress_test_proxy.py
   
   Requests: 1000
   Success: 998 (99.8%)
   Avg Latency: 145ms
   p95: 210ms

5. Integration Testing
   ↓
   from app.client.client import IntentClient
   
   async def test():
       client = IntentClient(...)
       response = await client.analyze_text(...)
       assert response.decision == "block"
```

---

## 5. Deployment Workflow

```
┌─────────────────────────────────────────────────────────┐
│                 DEPLOYMENT WORKFLOW                     │
└─────────────────────────────────────────────────────────┘

Development
  ↓
┌─────────────────────┐
│ 1. Test Locally     │
│    python main.py   │
└─────────────────────┘
  ↓
┌─────────────────────┐
│ 2. Validate Policy  │
│    ./guardrail      │
│    policy validate  │
└─────────────────────┘
  ↓
┌─────────────────────┐
│ 3. Run Tests        │
│    pytest tests/    │
└─────────────────────┘
  ↓
Staging
  ↓
┌─────────────────────────────────┐
│ 4. Build Docker Image           │
│    docker build -t intent-      │
│    analyzer:v4.0 .              │
└─────────────────────────────────┘
  ↓
┌─────────────────────────────────┐
│ 5. Test Container               │
│    docker run -p 8002:8002      │
│    intent-analyzer:v4.0         │
└─────────────────────────────────┘
  ↓
┌─────────────────────────────────┐
│ 6. Smoke Test                   │
│    curl http://localhost:8002/  │
│    health                        │
└─────────────────────────────────┘
  ↓
Production
  ↓
┌─────────────────────────────────┐
│ 7. Deploy to Cloud              │
│    • Render                     │
│    • AWS ECS                    │
│    • Kubernetes                 │
└─────────────────────────────────┘
  ↓
┌─────────────────────────────────┐
│ 8. Configure Environment        │
│    HUGGINGFACE_API_TOKEN=xxx    │
│    PORT=8002                    │
└─────────────────────────────────┘
  ↓
┌─────────────────────────────────┐
│ 9. Health Check                 │
│    curl https://your-domain/    │
│    health                        │
└─────────────────────────────────┘
  ↓
┌─────────────────────────────────┐
│ 10. Monitor                     │
│     • Logs                      │
│     • Metrics                   │
│     • Alerts                    │
└─────────────────────────────────┘
```

---

## 6. Policy Update Workflow (Production)

```
┌─────────────────────────────────────────────────────────┐
│            PRODUCTION POLICY UPDATE                     │
└─────────────────────────────────────────────────────────┘

Requirement: Block P2_Medium tier
  ↓
┌─────────────────────────────────┐
│ 1. Clone Current Policy         │
│    cp main.yaml main.yaml.bak   │
└─────────────────────────────────┘
  ↓
┌─────────────────────────────────┐
│ 2. Edit Policy                  │
│    ./guardrail policy edit      │
│    • Add P2_Medium to blocked   │
│    • Ctrl+S to save             │
└─────────────────────────────────┘
  ↓
┌─────────────────────────────────┐
│ 3. Validate                     │
│    ./guardrail policy validate  │
└─────────────────────────────────┘
  ↓
┌─────────────────────────────────┐
│ 4. Test Locally                 │
│    ./guardrail policy simulate  │
│    --tier P2_Medium             │
│                                 │
│    Expected: BLOCK              │
└─────────────────────────────────┘
  ↓
┌─────────────────────────────────┐
│ 5. Commit Changes               │
│    git add app/policies/        │
│    git commit -m "Block P2"     │
└─────────────────────────────────┘
  ↓
┌─────────────────────────────────┐
│ 6. Deploy                       │
│    git push origin main         │
│    • Auto-deploy triggers       │
│    • Or manual restart          │
└─────────────────────────────────┘
  ↓
┌─────────────────────────────────┐
│ 7. Verify in Production         │
│    curl -X POST /intent \       │
│      -d '{"text": "toxic",      │
│           "role": "general"}'   │
│                                 │
│    Expected: decision="block"   │
└─────────────────────────────────┘
  ↓
┌─────────────────────────────────┐
│ 8. Monitor                      │
│    • Check logs                 │
│    • Watch metrics              │
│    • Validate behavior          │
└─────────────────────────────────┘
  ↓
Success ──Yes──→ Done
  ↓ No
Rollback
  ↓
┌─────────────────────────────────┐
│ 9. Restore Backup               │
│    cp main.yaml.bak main.yaml   │
│    git revert HEAD              │
│    git push origin main         │
└─────────────────────────────────┘
```

---

## 7. Troubleshooting Workflow

```
┌─────────────────────────────────────────────────────────┐
│              TROUBLESHOOTING GUIDE                      │
└─────────────────────────────────────────────────────────┘

Issue: Server won't start
  ↓
Check port availability
  ↓
  lsof -i :8002
  ↓
  Port in use? ──Yes──→ PORT=8003 python main.py
  ↓ No
Check dependencies
  ↓
  pip install -r requirements.txt
  ↓
Check environment
  ↓
  echo $HUGGINGFACE_API_TOKEN
  ↓
  Missing? ──Yes──→ export HUGGINGFACE_API_TOKEN=xxx
  ↓ No
Check logs
  ↓
  tail -f server.log

─────────────────────────────────────────────────────────

Issue: Policy validation fails
  ↓
Check YAML syntax
  ↓
  ./guardrail policy validate
  ↓
  [ERR] Invalid tier: P5_Invalid
  ↓
Fix in editor
  ↓
  ./guardrail policy edit
  ↓
Validate again
  ↓
  ./guardrail policy validate
  ↓
  [OK] YAML schema valid

─────────────────────────────────────────────────────────

Issue: Unexpected decisions
  ↓
Check current policy
  ↓
  ./guardrail policy show
  ↓
Simulate specific case
  ↓
  ./guardrail policy simulate \
    --tier P0_Critical \
    --role general
  ↓
Review signal contract
  ↓
Check role overrides
  ↓
  Policy: balanced v1
  Overrides:
    admin -> ALL  ← This might be the issue
  ↓
Adjust policy
  ↓
  ./guardrail policy edit
  ↓
Test again

─────────────────────────────────────────────────────────

Issue: High latency
  ↓
Check HF API status
  ↓
  curl https://status.huggingface.co
  ↓
Increase timeout
  ↓
  export HF_TIMEOUT_SECONDS=30
  ↓
Add retries
  ↓
  export HF_MAX_RETRIES=3
  ↓
Consider caching
  ↓
Enable Redis cache (if configured)
  ↓
Monitor performance
  ↓
  python tests/stress_test_proxy.py
```

---

## 8. Role Override Workflow

```
┌─────────────────────────────────────────────────────────┐
│              ROLE OVERRIDE MANAGEMENT                   │
└─────────────────────────────────────────────────────────┘

Requirement: Give admin full access
  ↓
┌─────────────────────────────────┐
│ 1. Open Editor                  │
│    ./guardrail policy edit      │
└─────────────────────────────────┘
  ↓
┌─────────────────────────────────┐
│ 2. Add Override                 │
│    • Press 'o'                  │
│    • Enter role: admin          │
│    • Enter allowance: ALL       │
└─────────────────────────────────┘
  ↓
┌─────────────────────────────────┐
│ 3. Verify                       │
│    Role Overrides:              │
│      admin : ALL                │
└─────────────────────────────────┘
  ↓
┌─────────────────────────────────┐
│ 4. Test                         │
│    Press 'm' (Simulate)        │
│    • Input: "delete files"      │
│    • Role: admin                │
│    • Expected: ALLOW            │
└─────────────────────────────────┘
  ↓
┌─────────────────────────────────┐
│ 5. Save                         │
│    Press 's'                    │
└─────────────────────────────────┘
  ↓
┌─────────────────────────────────┐
│ 6. Verify in API                │
│    curl -X POST /intent \       │
│      -d '{"text": "delete",     │
│           "role": "admin"}'     │
│                                 │
│    Response: decision="allow"   │
└─────────────────────────────────┘

Multiple Roles Example:
┌─────────────────────────────────┐
│ admin     : ALL                 │
│ moderator : P2_Medium           │
│ analyst   : P3_Low              │
│ readonly  : P4_Info             │
└─────────────────────────────────┘

Meaning:
• admin: Bypass all blocks
• moderator: Allow up to P2_Medium
• analyst: Allow up to P3_Low
• readonly: Only P4_Info allowed
```

---

## Quick Command Reference

```bash
# Setup
./guardrail init

# Edit
./guardrail policy edit

# Validate
./guardrail policy validate

# Simulate
./guardrail policy simulate --tier P0_Critical --confidence 0.9

# Show
./guardrail policy show

# Server
python main.py

# Test
curl -X POST http://localhost:8002/intent \
  -H "Content-Type: application/json" \
  -d '{"text": "test", "role": "general"}'
```

---

**For detailed command reference, see:** [CLI_GUIDE.md](CLI_GUIDE.md)  
**For quick reference, see:** [CHEATSHEET.md](CHEATSHEET.md)
