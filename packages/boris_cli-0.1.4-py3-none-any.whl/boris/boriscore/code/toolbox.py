from boris.boriscore.toolbox_mngmnt.toolbox import RETRIEVE_NODE

TOOLBOX = {"retrieve_node": RETRIEVE_NODE}
