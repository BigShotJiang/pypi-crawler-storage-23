from setuptools import setup, find_packages

setup(
    name="FF-Tokens",
    version="2.1.4",  # Match your folder version
    author="NR CODEX",
    author_email="nilaysingh.official@gmail.com",
    description="Generate JWT tokens from Free Fire access tokens",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    packages=find_packages(),
    install_requires=[
        "pycryptodome",   # for Crypto
        "requests",
        "httpx",
        "protobuf",
        "PyJWT",
        "urllib3"
    ],
    keywords=["free fire", "jwt", "access token"],
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.6",
)