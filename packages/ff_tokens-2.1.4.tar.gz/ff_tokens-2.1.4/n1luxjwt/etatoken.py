import requests
from urllib.parse import urlparse, parse_qs, unquote
import re

def N1LUXETAACCESS(token):
    try:
        r=requests.get(f"https://api-otrss.garena.com/support/callback/?access_token={token}", headers={"User-Agent":"Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36"}, allow_redirects=False, timeout=10)
        if r.status_code in (301,302,303,307,308):
            return r.headers.get('Location','')
        return r.url if r.status_code==200 and r.url!=r.request.url else f"Error: {r.status_code}"
    except Exception as e: return f"Error: {e}"

def N1LUXACCESSGEN(raw_url):
    try:
        if not raw_url or raw_url.startswith('Error'): return
        u=unquote(raw_url)
        m=re.search(r'(?:eat|token)[=%3D]+([\w-]+)',u,re.I)
        if m: return m.group(1)
        q=parse_qs(urlparse(u).query)
        if 'eat' in q: return q['eat'][0]
        if 'site' in q:
            m2=re.search(r'(?:eat|token)[=%3D]+([\w-]+)',unquote(q['site'][0]),re.I)
            return m2.group(1) if m2 else None
    except: return