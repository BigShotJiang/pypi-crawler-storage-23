from Crypto.Cipher import AES
from Crypto.Util.Padding import pad
import binascii
import requests
import jwt
import json
import time
import urllib3

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

try:
    from .my_pb2 import GameData
except ImportError:
    try:
        import my_pb2
        GameData = my_pb2.GameData
    except ImportError:
        pass

Garena_420 = None
try:
    from .jwt_generator_pb2 import Garena_420
except ImportError:
    try:
        from .output_pb2 import Garena_420
    except ImportError:
        try:
            from jwt_generator_pb2 import Garena_420
        except ImportError:
            try:
                from output_pb2 import Garena_420
            except ImportError:
                pass
# -----------------------------------------------------

AES_KEY = b'Yg&tc%DEuh6%Zc^8'
AES_IV = b'6oyZDr22E3ychjM%'

def encrypt_message(plaintext):
    cipher = AES.new(AES_KEY, AES.MODE_CBC, AES_IV)
    padded_message = pad(plaintext, AES.block_size)
    return cipher.encrypt(padded_message)

def x7aMa_oiD(access_token):
    url = f"https://100067.connect.garena.com/oauth/token/inspect?token={access_token}"
    headers = {
        "Accept": "*/*",
        "Accept-Encoding": "gzip, deflate, br",
        "Accept-Language": "en-GB,en-US;q=0.9,en;q=0.8",
        "Connection": "keep-alive",
        "Host": "100067.connect.garena.com",
        "User-Agent": "GarenaMSDK/4.0.26.04212025 (iPhone14,3;ios - 18.4.1;en-MA;MA)"
    }
    response = requests.get(url, headers=headers, verify=False)
    if response.status_code == 200:
        return response.json().get("open_id")
    return response.content

def get_ob_config():
    url = "https://bdversion.ggbluefox.com/live/ver.php"
    params = {
        "version": "1.120.1",
        "lang": "ar",
        "device": "android",
        "channel": "android",
        "appstore": "googleplay",
        "region": "ME",
        "whitelist_version": "1.3.0",
        "whitelist_sp_version": "1.0.0",
        "device_name": "google G011A",
        "device_CPU": "ARMv7 VFPv3 NEON VMH",
        "device_GPU": "Adreno (TM) 640",
        "device_mem": "1993"
    }
    try:
        resp = requests.get(url, params=params, timeout=10, verify=False)
        resp.raise_for_status()
        return resp.json()
    except Exception as e:
        return {"error": str(e)}

def N1LUXAccessGenerator(access_token):
    open_id = x7aMa_oiD(access_token)
    if isinstance(open_id, bytes):
        try:
            error_json = json.loads(open_id.decode('utf-8', errors='ignore'))
            return error_json
        except:
            return {"error": "Invalid access token"}
    
    config = get_ob_config()
    if "error" in config:
        return {"error": f"Failed to fetch OB config: {config['error']}"}

    latest_release_version = config.get("latest_release_version", "OB1")
    server_url = config.get("server_url", "https://loginbp.ggpolarbear.com")
    
    version_code = "1.120.1"
    game_version = 1
    platforms = [8, 3, 4, 6]

    for platform_type in platforms:
        try:
            game_data = GameData()
            game_data.timestamp = "2024-12-05 18:15:32"
            game_data.game_name = "free fire"
            game_data.game_version = game_version
            game_data.version_code = version_code
            game_data.os_info = "Android OS 9 / API-28 (PI/rel.cjw.20220518.114133)"
            game_data.device_type = "Handheld"
            game_data.network_provider = "Verizon Wireless"
            game_data.connection_type = "WIFI"
            game_data.screen_width = 1280
            game_data.screen_height = 960
            game_data.dpi = "240"
            game_data.cpu_info = "ARMv7 VFPv3 NEON VMH | 2400 | 4"
            game_data.total_ram = 5951
            game_data.gpu_name = "Adreno (TM) 640"
            game_data.gpu_version = "OpenGL ES 3.0"
            game_data.user_id = "Google|74b585a9-0268-4ad3-8f36-ef41d2e53610"
            game_data.ip_address = "172.190.111.97"
            game_data.language = "en"
            game_data.open_id = open_id
            game_data.access_token = access_token
            game_data.platform_type = platform_type
            game_data.field_99 = str(platform_type)
            game_data.field_100 = str(platform_type)

            serialized_data = game_data.SerializeToString()
            encrypted_data = encrypt_message(serialized_data)
            hex_encrypted_data = binascii.hexlify(encrypted_data).decode('utf-8')

            url = server_url.rstrip('/') + "/MajorLogin"
            headers = {
                "User-Agent": "Dalvik/2.1.0 (Linux; U; Android 9; ASUS_Z01QD Build/PI)",
                "Connection": "Keep-Alive",
                "Accept-Encoding": "gzip",
                "Content-Type": "application/octet-stream",
                "Expect": "100-continue",
                "X-Unity-Version": "2018.4.11f1",
                "X-GA": "v1 1",
                "ReleaseVersion": latest_release_version
            }
            edata = bytes.fromhex(hex_encrypted_data)

            response = requests.post(url, data=edata, headers=headers, verify=False, timeout=5)
            
            if response.status_code == 200:
                if Garena_420 is not None:
                    try:
                        msg = Garena_420()
                        msg.ParseFromString(response.content)
                        
                        token = msg.token if hasattr(msg, 'token') else None
                        
                        if token:
                            try:
                                decoded = jwt.decode(token, options={"verify_signature": False})
                            except Exception:
                                decoded = {}
                            return {
                                "access_token": access_token,
                                "account_id": decoded.get("account_id"),
                                "account_name": decoded.get("nickname"),
                                "open_id": open_id,
                                "platform": decoded.get("external_type"),
                                "region": decoded.get("lock_region"),
                                "token": token,
                                "server_url": msg.api if hasattr(msg, 'api') else None,
                                "agora_environment": msg.status if hasattr(msg, 'status') else None,
                                "ip_region": decoded.get("country_code"),
                                "noti_region": decoded.get("noti_region"),
                                "ttl": max(0, decoded.get("exp", 0) - int(time.time())) if decoded.get("exp") else None
                            }
                    except Exception:
                        pass
                
                try:
                    json_data = response.json()
                    if json_data.get('token'):
                        decoded = jwt.decode(json_data['token'], options={"verify_signature": False})
                        
                        return {
                            "access_token": access_token,
                            "account_id": decoded.get("account_id"),
                            "account_name": decoded.get("nickname"),
                            "open_id": open_id,
                            "platform": decoded.get("external_type"),
                            "region": decoded.get("lock_region"),
                            "token": json_data.get('token'),
                            "server_url": json_data.get('api'),
                            "agora_environment": json_data.get('status'),
                            "ip_region": decoded.get("country_code"),
                            "noti_region": decoded.get("noti_region"),
                            "ttl": max(0, decoded.get("exp", 0) - int(time.time())) if decoded.get("exp") else None
                        }
                except:
                    continue
        except Exception:
            continue
            
    return {"error": "Failed to generate token", "status": "error"}

def N1LUXACCESS(uid, password):
    oauth_url = "https://100067.connect.garena.com/oauth/guest/token/grant"
    payload = {
        'uid': uid,
        'password': password,
        'response_type': "token",
        'client_type': "2",
        'client_secret': "2ee44819e9b4598845141067b281621874d0d5d7af9d8f7e00c1e54715b7d1e3",
        'client_id': "100067"
    }
    headers = {
        'User-Agent': "GarenaMSDK/4.0.19P9(SM-M526B ;Android 13;pt;BR;)",
        'Connection': "Keep-Alive",
        'Accept-Encoding': "gzip"
    }

    try:
        oauth_response = requests.post(oauth_url, data=payload, headers=headers, timeout=5, verify=False)
    except requests.RequestException as e:
        return {"error": str(e), "status": "error"}

    if oauth_response.status_code != 200:
        try:
            return oauth_response.json()
        except ValueError:
            return {"error": oauth_response.text, "status": "error"}

    try:
        oauth_data = oauth_response.json()
    except ValueError:
        return {"error": "Invalid JSON from OAuth", "status": "error"}

    if 'access_token' not in oauth_data:
        return {"error": "OAuth response missing access_token", "status": "error"}

    return N1LUXAccessGenerator(oauth_data['access_token'])