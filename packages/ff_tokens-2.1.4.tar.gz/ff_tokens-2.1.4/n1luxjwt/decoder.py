import jwt

def N1LUXJwtdecode(token):
    try:
        if not token: return {"status":"error","message":"Token is empty"}
        return {"status":"success","payload":jwt.decode(token,options={"verify_signature":False})}
    except Exception as e: return {"status":"error","message":f"Failed to decode: {e}"}