import requests, logging
logger=logging.getLogger(__name__)

def get_ob_raw():
    try:
        r=requests.get("https://bdversion.ggbluefox.com/live/ver.php?version=1.120.1&lang=ar&device=android&channel=android&appstore=googleplay&region=ME&whitelist_version=1.3.0&whitelist_sp_version=1.0.0&device_name=google%20G011A&device_CPU=ARMv7%20VFPv3%20NEON%20VMH&device_GPU=Adreno%20(TM)%20640&device_mem=1993", timeout=10)
        return r.json() if r.status_code==200 else logger.error(f"Invalid status: {r.status_code}") or None
    except Exception as e: logger.error(f"Error: {e}"); return None

def fetch_ob_version():
    d=get_ob_raw() or get_ob_raw()
    if d and d.get("code")==0:
        v=d.get("latest_release_version")
        print(f"OB VERSION FETCHED => {v}"); return v
    print("Failed. Using fallback.")