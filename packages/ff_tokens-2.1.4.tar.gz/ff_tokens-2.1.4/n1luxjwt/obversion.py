import httpx
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class OBVersionManager:
    def __init__(self):
        self.raw_data = None
        self.ob_version = None
        self.server_url = None
        self.gop_urls = []
        self.is_loaded = False

    async def fetch(self):
        url="https://bdversion.ggbluefox.com/live/ver.php"
        params={"version":"1.120.1","lang":"ar","device":"android","channel":"android","appstore":"googleplay","region":"ME","whitelist_version":"1.3.0","whitelist_sp_version":"1.0.0","device_name":"google G011A","device_CPU":"ARMv7 VFPv3 NEON VMH","device_GPU":"Adreno (TM) 640","device_mem":"1993"}
        try:
            async with httpx.AsyncClient(timeout=15,verify=False) as c:
                r=await c.get(url,params=params,headers={"User-Agent":"Dalvik/2.1.0 (Linux; U; Android 10; SM-G965F Build/QP1A.190711.020)","Accept-Encoding":"gzip","Connection":"Keep-Alive"})
            r.raise_for_status();d=r.json()
            if d.get("code")!=0: logger.error(f"Error code: {d.get('code')}");return False
            self.raw_data,self.ob_version,self.server_url=d,d.get("latest_release_version"),d.get("server_url")
            self.gop_urls=(d.get("gop_url","") or "").split(";")if d.get("gop_url")else[]
            if not self.ob_version or not self.server_url: logger.error("Missing version/server");return False
            self.is_loaded=True;logger.info(f"OB: {self.ob_version} | Server: {self.server_url}");return True
        except Exception as e: logger.error(f"Fetch Failed: {e}");return False

    def get_ob(self): return self.ob_version
    def get_login_server(self): return self.server_url
    def get_gop_server(self): return self.gop_urls[0] if self.gop_urls else None
    def get_raw_data(self): return self.raw_data
    async def show_full(self):
        if await self.fetch(): print("FULL RESPONSE:",self.raw_data)
        else: print("Failed to fetch")