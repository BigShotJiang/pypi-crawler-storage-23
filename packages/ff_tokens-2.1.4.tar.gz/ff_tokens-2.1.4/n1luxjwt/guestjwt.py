import json
import base64
import logging
import httpx
import urllib3

from Crypto.Cipher import AES
from Crypto.Util.Padding import pad as pkcs7_pad
from google.protobuf import json_format

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

try:
    from .Token_pb2 import LoginReq, LoginRes
except ImportError:
    LoginReq = LoginRes = None
    print("Error: Token_pb2.py not found.")

from .utils import fetch_ob_version

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class N1LUXGenerator:

    MAIN_KEY = base64.b64decode("WWcmdGMlREV1aDYlWmNeOA==")
    MAIN_IV = base64.b64decode("Nm95WkRyMjJFM3ljaGpNJQ==")
    
    USER_AGENT = (
        "Dalvik/2.1.0 (Linux; U; Android 13; CPH2095 Build/RKQ1.211119.001)"
    )
    
    CLIENT_CONFIG = {
        "client_type": "2",
        "client_secret": "2ee44819e9b4598845141067b281621874d0d5d7af9d8f7e00c1e54715b7d1e3",
        "client_id": "100067"
    }

    def __init__(self):
        self.release_version = fetch_ob_version()
        logger.info(f"Initialized N1LUXGenerator with OB version: {self.release_version}")

    def _aes_encrypt(self, plaintext: bytes) -> bytes:
        try:
            padded = pkcs7_pad(plaintext, AES.block_size)
            cipher = AES.new(self.MAIN_KEY, AES.MODE_CBC, self.MAIN_IV)
            return cipher.encrypt(padded)
        except Exception as e:
            logger.error(f"Encryption failed: {e}")
            raise

    def _json_to_proto(self, json_data: dict) -> bytes:
        try:
            message = LoginReq()
            json_format.ParseDict(json_data, message)
            return message.SerializeToString()
        except Exception as e:
            logger.error(f"JSON to proto conversion failed: {e}")
            raise

    async def _get_access_token(self, uid: str, password: str) -> tuple:
        url = "https://ffmconnect.live.gop.garenanow.com/oauth/guest/token/grant"
        
        payload = {
            "uid": uid,
            "password": password,
            "response_type": "token",
            **self.CLIENT_CONFIG
        }
        
        headers = {
            "User-Agent": self.USER_AGENT,
            "Content-Type": "application/x-www-form-urlencoded"
        }

        try:
            async with httpx.AsyncClient(timeout=15) as client:
                response = await client.post(url, data=payload, headers=headers)
                response.raise_for_status()
                
            data = response.json()
            access_token = data.get("access_token")
            open_id = data.get("open_id")
            
            if not access_token or not open_id:
                raise ValueError(f"Invalid server response: missing tokens in {data}")
                
            return access_token, open_id
            
        except Exception as e:
            logger.error(f"Access token fetch failed: {e}")
            raise

    async def create_token(self, uid: str, password: str) -> dict:
    
        if LoginReq is None or LoginRes is None:
            return {"error": "Token_pb2.py missing or not imported properly."}

        try:
            logger.info(f"Generating token for UID: {uid}")
            
            access_token, open_id = await self._get_access_token(uid, password)
            
            login_payload = {
                "open_id": open_id,
                "open_id_type": "4",
                "login_token": access_token,
                "orign_platform_type": "4"
            }

            proto_bytes = self._json_to_proto(login_payload)
            encrypted_data = self._aes_encrypt(proto_bytes)

            login_url = "https://loginbp.ggblueshark.com/MajorLogin"
            headers = {
                "User-Agent": self.USER_AGENT,
                "Content-Type": "application/octet-stream",
                "X-Unity-Version": "2022.3.47f1",
                "X-GA": "v1 1",
                "ReleaseVersion": self.release_version
            }

            async with httpx.AsyncClient(timeout=15) as client:
                response = await client.post(
                    login_url,
                    content=encrypted_data,
                    headers=headers
                )
                response.raise_for_status()

            response_proto = LoginRes.FromString(response.content)
            response_dict = json_format.MessageToDict(
                response_proto,
                preserving_proto_field_name=True,
                use_integers_for_enums=False
            )
            
            logger.info(f"Token generated successfully for UID: {uid}")
            return response_dict

        except httpx.HTTPStatusError as e:
            error_msg = f"HTTP error: {e.response.status_code}"
            logger.error(f"{error_msg} for UID: {uid}")
            return {"error": error_msg}
            
        except httpx.RequestError as e:
            error_msg = f"Network error: {str(e)}"
            logger.error(f"{error_msg} for UID: {uid}")
            return {"error": error_msg}
            
        except Exception as e:
            error_msg = f"Token generation failed: {str(e)}"
            logger.error(f"{error_msg} for UID: {uid}")
            return {"error": error_msg}

generator = N1LUXGenerator()
create_token = generator.create_token