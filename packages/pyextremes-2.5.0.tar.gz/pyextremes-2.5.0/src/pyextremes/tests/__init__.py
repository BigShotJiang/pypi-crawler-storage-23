__all__ = ["KolmogorovSmirnov"]

from pyextremes.tests.ks_test import KolmogorovSmirnov
