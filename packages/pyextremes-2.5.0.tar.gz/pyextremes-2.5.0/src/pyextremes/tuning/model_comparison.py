# TODO
# compare models using AIC, likelihood ratio, KS, etc.
# return a DataFrame with comparison of 'n' models
# n_rows=n and n_columns=n_metrics
