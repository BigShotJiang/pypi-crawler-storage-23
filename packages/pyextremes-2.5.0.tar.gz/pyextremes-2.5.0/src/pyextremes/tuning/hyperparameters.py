# TODO
# for a grid of block_size/thresholds, distributions, and distribution_kwargs
# using given scoring metric (AIC, R^2, or whatever)
# get a dataframe with results:
#   return value and its confidence interval
#   AIC
#   Pearson correlation coefficient
