"""
Finetunehub CLI scripts and utilities.
"""
