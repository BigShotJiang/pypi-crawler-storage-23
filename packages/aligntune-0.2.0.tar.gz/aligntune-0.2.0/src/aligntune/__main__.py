"""
AlignTune CLI Entry Point

This module provides the main entry point for the AlignTune CLI.

"""

from .cli import main

if __name__ == "__main__":
    main()