"""
NLP extraction modules for Spellcaster.

* :mod:`.action_frames` — Verb-centred action frame extraction.
* :mod:`.noun_dependencies` — Schema–valence noun dependency triples.
* :mod:`.sentence_parser` — Sentence segmentation with POS tags.
"""

from spell_exploder.extractors.action_frames import (
    ActionFrame,
    extract_action_frames,
    make_hashable_frame,
)
from spell_exploder.extractors.noun_dependencies import (
    NounDependency,
    extract_noun_dependencies,
)
from spell_exploder.extractors.sentence_parser import (
    DEFAULT_ABBREVIATIONS,
    ParsedSentence,
    parse_sentences,
    split_sentences_simple,
)

__all__ = [
    "ActionFrame",
    "extract_action_frames",
    "make_hashable_frame",
    "NounDependency",
    "extract_noun_dependencies",
    "ParsedSentence",
    "parse_sentences",
    "split_sentences_simple",
    "DEFAULT_ABBREVIATIONS",
]