class Colors:
    Reset = "\033[0m"

    Black = "\033[30m"
    Red = "\033[31m"
    Green = "\033[32m"
    Yellow = "\033[33m"
    Blue = "\033[34m"
    Purple = "\033[35m"
    Pink = "\033[95m"
    Cyan = "\033[36m"
    White = "\033[37m"
    Gray = "\033[90m"

    @staticmethod
    def Add(text: str, color: str, reset=True):
        if reset:
            return f"{color}{text}{Colors.Reset}"
        return f"{color}{text}"
    

    @staticmethod
    def UseRGB(r, g, b):
        return f"\033[38;2;{r};{g};{b}m"