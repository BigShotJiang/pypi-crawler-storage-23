from enum import Enum
from itertools import cycle
from .utils import ColorUtils

class Gradient(Enum):
    Rainbow = [(255, 0, 0), (255, 165, 0), (255, 255, 0), (0, 255, 0), (0, 0, 255), (75, 0, 130), (148, 0, 211)]
    Sunset = [(255, 94, 98), (255, 195, 113), (255, 247, 174)]
    Mint = [(152, 255, 152), (0, 255, 127), (46, 139, 87)]
    Fire = [(255, 0, 0), (255, 140, 0), (255, 255, 0)]
    Ocean = [(0, 128, 255), (0, 255, 255), (0, 128, 128)]
    Midnight = [(25, 25, 112), (0, 0, 128), (75, 0, 130)]
    PinkPurple = [(255, 105, 180), (147, 112, 219)]
    PurpleBlue = [(147, 112, 219), (0, 0, 255)]
    GreyOrange = [(128, 128, 128), (255, 165, 0)]
    LimeGreen = [(50, 205, 50), (0, 255, 127)]
    BlueCyan = [(0, 0, 255), (0, 255, 255)]
    GreenToOrange = [(0, 255, 0), (255, 165, 0)]
    BlackToWhite = [(0, 0, 0), (255, 255, 255)]
    RedBlue = [(255, 0, 0), (0, 0, 255)]
    YellowGreen = [(255, 255, 0), (0, 128, 0)]
    PinkCyan = [(255, 105, 180), (0, 255, 255)]
    OrangeBlue = [(255, 165, 0), (0, 0, 255)]
    WhitePurple = [(255, 255, 255), (128, 0, 128)]
    PurpleWhite = [(128, 0, 128), (255, 255, 255)]
    RedWhite = [(255, 0, 0), (255, 255, 255)]

    def Cycle(self):
        return cycle(self.value)

    def Shift(self):
        colors = self.value
        while True:
            yield colors
            colors = colors[1:] + colors[:1]


class Gradients:
    @staticmethod
    def Apply(text: str, gradient: Gradient | list, center: bool = False) -> str:
        colors = gradient.value if isinstance(gradient, Gradient) else gradient
        output = ""
        steps = len(text)

        for i, char in enumerate(text):
            r, g, b = ColorUtils.InterpolateRgb(colors, i / max(steps - 1, 1))
            output += f"{ColorUtils.RgbToAnsi(r, g, b)}{char}"

        output += "\033[0m"
        return ColorUtils.CenterText(output) if center else output

    @staticmethod
    def List():
        return [g.name for g in Gradient]
