import time
from .loggers import Logs
import sys

class Animate:
    @staticmethod
    def Write(text: str, speed: float = 0.05, logger: Logs | None = None):
        output = ""
        for char in text:
            print(char, end="", flush=True)
            output += char
            if logger:
                logger.Info(text)
            time.sleep(speed)
        print()
        return output
    
    @staticmethod
    def NewWrite(text: str, speed: float = 0.01):
        for char in text:
            sys.stdout.write(char)
            sys.stdout.flush()
            time.sleep(speed)

        return input() 


    @staticmethod
    def Wave(text: str, delay: float = 0.1, logger: Logs | None = None) -> str:
        output = ""
        lines = text.splitlines()
        for line in lines:
            print(line)
            output += line + "\n"
            if logger:
                logger.Info(line)
            time.sleep(delay)
        return output

