import os
import hashlib
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("file-hash")

@mcp.tool()
def hash_file(path: str, algorithm: str = "sha256") -> str:
    """计算文件的哈希值 (md5, sha1, sha256)。"""
    algo = algorithm.lower().strip()
    if algo not in ("md5", "sha1", "sha256", "sha512"):
        return f"不支持的算法: {algo}。可选: md5, sha1, sha256, sha512"
        
    if not os.path.isfile(path):
        return f"文件不存在或非普通文件: {path}"
        
    try:
        h = hashlib.new(algo)
        with open(path, "rb") as f:
            for chunk in iter(lambda: f.read(4096), b""):
                h.update(chunk)
                
        return f"{algo.upper()}: {h.hexdigest()}"
    except Exception as e:
        return f"计算失败: {e}"

def main():
    mcp.run()

if __name__ == "__main__":
    main()
