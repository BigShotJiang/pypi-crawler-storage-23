# mcpzoo-file-hash

> 文件哈希 — 计算文件的 MD5 或 SHA256 哈希值

## Installation

```bash
uvx mcpzoo-file-hash
```

## uvx JSON

```json
{
  "mcpServers": {
    "file-hash": {
      "args": ["mcpzoo-file-hash"],
      "command": "uvx"
    }
  }
}
```
