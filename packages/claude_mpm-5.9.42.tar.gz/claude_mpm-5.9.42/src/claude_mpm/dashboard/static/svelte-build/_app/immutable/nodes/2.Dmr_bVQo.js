import{bC as m}from"../chunks/DjZgGVRL.js";export{m as component};
