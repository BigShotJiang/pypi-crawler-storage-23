import{b as r}from"./B4A5zAgx.js";var e=4;function a(o){return r(o,e)}export{a as c};
