"""Telegram bot specific utilities."""

import re

class Telegram:
    @staticmethod
    def escape_markdown(text: str) -> str:
        """Escape MarkdownV2 characters."""
        special = ['_', '*', '[', ']', '(', ')', '~', '`', '>', '#', '+', '-', '=', '|', '{', '}', '.', '!']
        for char in special:
            text = text.replace(char, f'\\{char}')
        return text
    
    @staticmethod
    def extract_user_id(text: str) -> int:
        """Extract user ID from mention or text."""
        match = re.search(r'(\d+)', text)
        return int(match.group(1)) if match else 0
    
    @staticmethod
    def split_message(text: str, limit: int = 4096) -> list:
        """Split long message into chunks."""
        if len(text) <= limit:
            return [text]
        
        chunks = []
        while text:
            if len(text) <= limit:
                chunks.append(text)
                break
            
            split_at = text[:limit].rfind('\n')
            if split_at == -1:
                split_at = limit
            
            chunks.append(text[:split_at])
            text = text[split_at:].lstrip()
        
        return chunks
    
    @staticmethod
    def progress_bar(current: int, total: int, length: int = 10) -> str:
        """Create progress bar."""
        percent = current / total
        filled = int(length * percent)
        bar = '█' * filled + '░' * (length - filled)
        return f"{bar} {int(percent * 100)}%"

# Алиасы
escape = Telegram.escape_markdown
extract_user = Telegram.extract_user_id
split_message = Telegram.split_message
progress_bar = Telegram.progress_bar