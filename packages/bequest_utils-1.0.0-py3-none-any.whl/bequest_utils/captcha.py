"""Math captcha for Telegram bots."""

import random
import operator

class Captcha:
    OPERATIONS = {
        '+': operator.add,
        '-': operator.sub,
        '*': operator.mul,
    }
    
    @classmethod
    def generate(cls, operation: str = '+', max_num: int = 10) -> dict:
        if operation not in cls.OPERATIONS:
            operation = '+'
        
        a = random.randint(1, max_num)
        b = random.randint(1, max_num)
        
        if operation == '-':
            a, b = max(a, b), min(a, b)
        
        question = f"{a} {operation} {b} = ?"
        answer = cls.OPERATIONS[operation](a, b)
        
        return {'question': question, 'answer': answer}
    
    @classmethod
    def verify(cls, user_answer: int, correct_answer: int) -> bool:
        return user_answer == correct_answer
    
    @classmethod
    def with_options(cls, operation: str = '+', max_num: int = 10, num_options: int = 4) -> dict:
        cap = cls.generate(operation, max_num)
        options = [cap['answer']]
        
        while len(options) < num_options:
            wrong = cap['answer'] + random.randint(-5, 5)
            if wrong not in options and wrong > 0:
                options.append(wrong)
        
        random.shuffle(options)
        
        return {
            'question': cap['question'],
            'answer': cap['answer'],
            'options': options
        }

# Короткий алиас
math_captcha = Captcha.generate