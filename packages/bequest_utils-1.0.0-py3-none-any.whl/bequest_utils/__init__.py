"""bequest-utils - Complete toolkit for Telegram bots."""

from .captcha import Captcha, math_captcha
from .strings import Strings, slugify, truncate, clean, random_string, mentions, hashtags
from .numbers import Numbers, format_number, human_readable, random_int, random_choice, percent
from .dates import Dates, now, today, format_date, time_ago, date_diff
from .telegram import Telegram, escape, extract_user, split_message, progress_bar

__version__ = '1.0.0'
__author__ = 'Bequest'
__email__ = 'bequestpython@email.com'

__all__ = [
    # Captcha
    'Captcha', 'math_captcha',
    
    # Strings
    'Strings', 'slugify', 'truncate', 'clean', 'random_string', 'mentions', 'hashtags',
    
    # Numbers
    'Numbers', 'format_number', 'human_readable', 'random_int', 'random_choice', 'percent',
    
    # Dates
    'Dates', 'now', 'today', 'format_date', 'time_ago', 'date_diff',
    
    # Telegram
    'Telegram', 'escape', 'extract_user', 'split_message', 'progress_bar',
]