"""Number utilities for Telegram bots."""

import random

class Numbers:
    @staticmethod
    def format(number: float, decimals: int = 0) -> str:
        """Format number with spaces."""
        if decimals > 0:
            return f"{number:,.{decimals}f}".replace(',', ' ')
        return f"{int(number):,}".replace(',', ' ')
    
    @staticmethod
    def human_readable(number: float) -> str:
        """Convert to K/M/B format."""
        if number < 1000:
            return str(int(number))
        if number < 1_000_000:
            return f"{number/1000:.1f}K"
        if number < 1_000_000_000:
            return f"{number/1_000_000:.1f}M"
        return f"{number/1_000_000_000:.1f}B"
    
    @staticmethod
    def random_int(min_val: int = 1, max_val: int = 100) -> int:
        """Generate random integer."""
        return random.randint(min_val, max_val)
    
    @staticmethod
    def random_choice(items: list):
        """Random item from list."""
        return random.choice(items) if items else None
    
    @staticmethod
    def percent(part: float, total: float) -> float:
        """Calculate percentage."""
        if total == 0:
            return 0
        return (part / total) * 100

# Алиасы
format_number = Numbers.format
human_readable = Numbers.human_readable
random_int = Numbers.random_int
random_choice = Numbers.random_choice
percent = Numbers.percent