"""Date utilities for Telegram bots."""

from datetime import datetime, timedelta
import time

class Dates:
    @staticmethod
    def now() -> str:
        """Current time as string."""
        return datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    @staticmethod
    def today() -> str:
        """Current date."""
        return datetime.now().strftime("%Y-%m-%d")
    
    @staticmethod
    def format(date, format: str = "%d.%m.%Y") -> str:
        """Format date."""
        if isinstance(date, str):
            date = datetime.fromisoformat(date)
        return date.strftime(format)
    
    @staticmethod
    def ago(date, accuracy: str = "auto") -> str:
        """Human readable time ago."""
        if isinstance(date, str):
            date = datetime.fromisoformat(date)
        
        diff = datetime.now() - date
        
        seconds = diff.total_seconds()
        minutes = seconds // 60
        hours = minutes // 60
        days = diff.days
        weeks = days // 7
        months = days // 30
        years = days // 365
        
        if seconds < 60:
            return f"{int(seconds)} сек назад"
        if minutes < 60:
            return f"{int(minutes)} мин назад"
        if hours < 24:
            return f"{int(hours)} ч назад"
        if days == 1:
            return "вчера"
        if days < 7:
            return f"{days} дн назад"
        if weeks < 5:
            return f"{weeks} нед назад"
        if months < 12:
            return f"{months} мес назад"
        return f"{years} г назад"
    
    @staticmethod
    def diff(date1, date2) -> str:
        """Difference between two dates."""
        if isinstance(date1, str):
            date1 = datetime.fromisoformat(date1)
        if isinstance(date2, str):
            date2 = datetime.fromisoformat(date2)
        
        diff = abs(date2 - date1)
        days = diff.days
        hours = diff.seconds // 3600
        minutes = (diff.seconds % 3600) // 60
        
        parts = []
        if days > 0:
            parts.append(f"{days} дн")
        if hours > 0:
            parts.append(f"{hours} ч")
        if minutes > 0:
            parts.append(f"{minutes} мин")
        
        return ' '.join(parts) if parts else "0 мин"

# Алиасы
now = Dates.now
today = Dates.today
format_date = Dates.format
time_ago = Dates.ago
date_diff = Dates.diff