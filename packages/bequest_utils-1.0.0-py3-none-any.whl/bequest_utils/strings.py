"""String utilities for Telegram bots."""

import re
import random
import string

class Strings:
    @staticmethod
    def slugify(text: str) -> str:
        """Convert to URL-friendly slug."""
        text = text.lower()
        text = re.sub(r'[^\w\s-]', '', text)
        text = re.sub(r'[-\s]+', '-', text)
        return text.strip('-')
    
    @staticmethod
    def truncate(text: str, limit: int = 100, suffix: str = '...') -> str:
        """Truncate text to limit."""
        if len(text) <= limit:
            return text
        return text[:limit].rsplit(' ', 1)[0] + suffix
    
    @staticmethod
    def clean(text: str) -> str:
        """Remove extra spaces."""
        return ' '.join(text.split())
    
    @staticmethod
    def random_string(length: int = 8) -> str:
        """Generate random string."""
        chars = string.ascii_letters + string.digits
        return ''.join(random.choice(chars) for _ in range(length))
    
    @staticmethod
    def mentions(text: str) -> list:
        """Extract @mentions from text."""
        return re.findall(r'@(\w+)', text)
    
    @staticmethod
    def hashtags(text: str) -> list:
        """Extract #hashtags from text."""
        return re.findall(r'#(\w+)', text)

# Алиасы
slugify = Strings.slugify
truncate = Strings.truncate
clean = Strings.clean
random_string = Strings.random_string
mentions = Strings.mentions
hashtags = Strings.hashtags