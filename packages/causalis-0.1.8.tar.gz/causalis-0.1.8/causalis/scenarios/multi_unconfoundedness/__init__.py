from .model import MultiTreatmentIRM

__all__ = ["MultiTreatmentIRM"]