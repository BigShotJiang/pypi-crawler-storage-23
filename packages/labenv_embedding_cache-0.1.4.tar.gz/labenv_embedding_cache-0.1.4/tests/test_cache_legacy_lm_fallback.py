from __future__ import annotations

import json
from pathlib import Path

import numpy as np

from labenv_embedding_cache.fingerprints import build_ids_sha256
from labenv_embedding_cache.indexing import build_legacy_index
from labenv_embedding_cache.resolver import read_cache_header, resolve_cache_with_index


def _write_new_format_cache(
    path: Path,
    *,
    registry_key: str = "bert",
    dataset_shuffle_seed: int = 7,
    variant_tag: str | None = None,
) -> dict[str, object]:
    ids = np.asarray(["id-1", "id-2"])
    embeddings = np.asarray([[0.1, 0.2], [0.3, 0.4]], dtype=np.float32)
    metadata = {
        "registry_key": registry_key,
        "rulebook_id": "shared_lm_embedding_cache:v1",
        "dataset_shuffle_seed": dataset_shuffle_seed,
        "ids_sha256": build_ids_sha256(ids.tolist()),
    }
    if variant_tag is not None:
        metadata["variant_tag"] = variant_tag
    path.parent.mkdir(parents=True, exist_ok=True)
    np.savez(
        path,
        ids=ids,
        embeddings=embeddings,
        shuffle_seed=dataset_shuffle_seed,
        registry_key=registry_key,
        rulebook_id="shared_lm_embedding_cache:v1",
        metadata_json=json.dumps(metadata, sort_keys=True),
    )
    return metadata


def test_resolve_cache_with_index_returns_canonical_path_when_present(tmp_path: Path) -> None:
    cache_root = tmp_path / "cache"
    expected_path = cache_root / "lm" / "bert-base-uncased" / "ag_news__bert-base-uncased.npz"
    metadata = _write_new_format_cache(expected_path)

    resolved = resolve_cache_with_index(
        expected_path,
        expected_metadata=metadata,
        dataset_name="ag_news",
        cache_dir=cache_root,
        index_path=cache_root / ".labenv" / "index_v1.jsonl",
    )
    assert resolved is not None
    assert resolved.path == expected_path.resolve()
    assert resolved.source == "canonical"


def test_resolve_cache_with_index_fallbacks_to_legacy_index(tmp_path: Path) -> None:
    cache_root = tmp_path / "cache"
    index_path = cache_root / ".labenv" / "index_v1.jsonl"
    candidate = cache_root / "lm" / "bert-base-uncased" / "ag_news__bert-base-uncased.npz"
    metadata = _write_new_format_cache(candidate, variant_tag="compat")
    build_legacy_index(cache_dir=cache_root, index_path=index_path)

    resolved = resolve_cache_with_index(
        cache_root / "lm" / "bert-base-uncased" / "ag_news__missing.npz",
        expected_metadata=metadata,
        dataset_name="ag_news",
        cache_dir=cache_root,
        index_path=index_path,
    )
    assert resolved is not None
    assert resolved.path == candidate.resolve()
    assert resolved.source == "legacy_index"


def test_read_cache_header_returns_none_for_legacy_tuple_npz(tmp_path: Path) -> None:
    cache_path = tmp_path / "legacy_tuple.npz"
    ids = np.asarray(["id-1", "id-2"])
    embeddings = np.asarray([[0.1, 0.2], [0.3, 0.4]], dtype=np.float32)
    legacy_tuple = np.empty((), dtype=object)
    legacy_tuple[()] = (ids, embeddings, 7)
    np.savez(cache_path, arr_0=legacy_tuple)

    metadata = read_cache_header(cache_path)
    assert metadata is None
