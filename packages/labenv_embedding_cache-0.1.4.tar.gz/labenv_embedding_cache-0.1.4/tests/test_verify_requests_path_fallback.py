from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pytest

from labenv_embedding_cache.fingerprints import build_ids_sha256
from labenv_embedding_cache.indexing import build_legacy_index
from labenv_embedding_cache.resolver import verify_cache_requests


def _write_cache(path: Path) -> dict[str, object]:
    ids = np.asarray(["id-1", "id-2"])
    embeddings = np.asarray([[0.1, 0.2], [0.3, 0.4]], dtype=np.float32)
    metadata = {
        "registry_key": "bert",
        "rulebook_id": "shared_lm_embedding_cache:v1",
        "dataset_shuffle_seed": 7,
        "ids_sha256": build_ids_sha256(ids.tolist()),
    }

    path.parent.mkdir(parents=True, exist_ok=True)
    np.savez(
        path,
        ids=ids,
        embeddings=embeddings,
        shuffle_seed=7,
        registry_key="bert",
        rulebook_id="shared_lm_embedding_cache:v1",
        metadata_json=json.dumps(metadata, sort_keys=True),
    )
    return metadata


def test_verify_requests_falls_back_to_index_when_expected_path_is_inaccessible(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    cache_root = tmp_path / "cache"
    index_path = cache_root / ".labenv" / "index_v1.jsonl"
    candidate = cache_root / "lm" / "bert-base-uncased" / "ag_news__bert-base-uncased.npz"
    metadata = _write_cache(candidate)
    build_legacy_index(cache_dir=cache_root, index_path=index_path)

    blocked_expected = Path(
        "/root/data/embedding_cache/lm/bert-base-uncased/ag_news__bert-base-uncased.npz"
    )
    original_exists = Path.exists

    def _patched_exists(self: Path) -> bool:  # type: ignore[override]
        if str(self).startswith("/root/data/embedding_cache"):
            raise PermissionError("blocked")
        return original_exists(self)

    monkeypatch.setattr(Path, "exists", _patched_exists)

    report = verify_cache_requests(
        [
            {
                "request_id": "ag_news:bert",
                "dataset_name": "ag_news",
                "model_id": "bert",
                "model_name": "bert-base-uncased",
                "expected_cache_path": str(blocked_expected),
                "registry_key": "bert",
                "rulebook_id": "shared_lm_embedding_cache:v1",
                "dataset_shuffle_seed": 7,
                "ids_sha256": metadata["ids_sha256"],
            }
        ],
        cache_dir=cache_root,
        index_path=index_path,
    )

    assert report["available"]["ag_news"]["bert"] is True
    assert report["selected_models"] == ["bert"]
    assert report["results"][0]["source"] == "legacy_index"
    assert report["results"][0]["resolved_cache_path"] == str(candidate.resolve())


def test_verify_requests_remaps_index_cache_path_root_to_cache_dir(tmp_path: Path) -> None:
    cache_root = tmp_path / "cache"
    index_path = cache_root / ".labenv" / "index_v1.jsonl"
    candidate = cache_root / "lm" / "bert-base-uncased" / "ag_news__bert-base-uncased.npz"
    metadata = _write_cache(candidate)
    build_legacy_index(cache_dir=cache_root, index_path=index_path)

    rows = [
        json.loads(line)
        for line in index_path.read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]
    assert len(rows) == 1
    rows[0]["cache_path"] = (
        "/workspace/text_embedding_cache/lm/bert-base-uncased/ag_news__bert-base-uncased.npz"
    )
    index_path.write_text(
        "".join(json.dumps(row, ensure_ascii=True) + "\n" for row in rows),
        encoding="utf-8",
    )

    report = verify_cache_requests(
        [
            {
                "request_id": "ag_news:bert",
                "dataset_name": "ag_news",
                "model_id": "bert",
                "model_name": "bert-base-uncased",
                "expected_cache_path": (
                    "/workspace/text_embedding_cache/lm/bert-base-uncased/ag_news__bert-base-uncased.npz"
                ),
                "registry_key": "bert",
                "rulebook_id": "shared_lm_embedding_cache:v1",
                "dataset_shuffle_seed": 7,
                "ids_sha256": metadata["ids_sha256"],
            }
        ],
        cache_dir=cache_root,
        index_path=index_path,
    )

    assert report["available"]["ag_news"]["bert"] is True
    assert report["selected_models"] == ["bert"]
    assert report["results"][0]["source"] == "legacy_index"
    assert report["results"][0]["resolved_cache_path"] == str(candidate.resolve())
