from __future__ import annotations

import json
from pathlib import Path

import numpy as np

from labenv_embedding_cache.cli import tool_main
from labenv_embedding_cache.identity import augment_metadata_with_identity
from labenv_embedding_cache.indexing import build_legacy_index
from labenv_embedding_cache.resolver import resolve_cache_with_index


def _canonical_metadata(*, dataset_key: str = "dk", variant_tag: str = "vt") -> dict[str, object]:
    return {
        "dataset_key": dataset_key,
        "dataset_config_hash": "dch",
        "text_manifest_hash": "tmh",
        "label_manifest_hash": "lmh",
        "ids_sha256": "idsh",
        "dataset_shuffle": False,
        "dataset_shuffle_seed": 7,
        "embedding_seed": 5,
        "variant_tag": variant_tag,
        "rulebook_id": "shared_lm_embedding_cache:v1",
        "registry_key": "bert",
        "embedding_type": "hf_transformer",
        "pooling": "mean",
        "hidden_state_layer": -1,
        "cache_all_layers": False,
        "torch_dtype": None,
        "tokenizer_id": None,
    }


def _write_cache(path: Path, *, metadata: dict[str, object], include_header_fields: bool = True) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    kwargs: dict[str, object] = {
        "ids": np.asarray(["a", "b"]),
        "embeddings": np.asarray([[0.1, 0.2], [0.3, 0.4]], dtype=np.float32),
        "shuffle_seed": np.asarray(7, dtype=int),
        "metadata_json": json.dumps(metadata, sort_keys=True),
    }
    if include_header_fields:
        kwargs["registry_key"] = np.asarray(metadata.get("registry_key"))
        kwargs["rulebook_id"] = np.asarray(metadata.get("rulebook_id"))
    np.savez(path, **kwargs)


def test_identity_hash_is_deterministic_and_soft_field_tolerant() -> None:
    base = augment_metadata_with_identity(_canonical_metadata())
    rerun = augment_metadata_with_identity(_canonical_metadata())
    assert base["identity_hash"] == rerun["identity_hash"]

    with_soft = dict(_canonical_metadata())
    with_soft["library_versions"] = {"numpy": "2.0"}
    enriched_with_soft = augment_metadata_with_identity(with_soft)
    assert base["identity_hash"] == enriched_with_soft["identity_hash"]

    hard_changed = augment_metadata_with_identity(_canonical_metadata(variant_tag="vt2"))
    assert base["identity_hash"] != hard_changed["identity_hash"]


def test_resolver_fallbacks_via_legacy_index_when_match_exists(tmp_path: Path) -> None:
    cache_root = tmp_path / "cache"
    index_path = cache_root / ".labenv" / "index_v1.jsonl"
    expected = augment_metadata_with_identity(_canonical_metadata(dataset_key="dk-expected"))

    mismatch_meta = augment_metadata_with_identity(_canonical_metadata(dataset_key="dk-other"))
    match_meta = dict(expected)

    early = cache_root / "lm" / "bert-base-uncased" / "ag_news__alpha.npz"
    late = cache_root / "lm" / "bert-base-uncased" / "ag_news__zeta.npz"
    _write_cache(early, metadata=mismatch_meta)
    _write_cache(late, metadata=match_meta)
    build_legacy_index(cache_dir=cache_root, index_path=index_path)

    resolved = resolve_cache_with_index(
        cache_root / "lm" / "bert-base-uncased" / "ag_news__missing.npz",
        expected_metadata=expected,
        dataset_name="ag_news",
        cache_dir=cache_root,
        index_path=index_path,
    )
    assert resolved is not None
    assert resolved.path == late.resolve()
    assert resolved.source == "legacy_index"


def test_resolver_does_not_fallback_when_identity_hash_is_missing(tmp_path: Path) -> None:
    cache_root = tmp_path / "cache"
    index_path = cache_root / ".labenv" / "index_v1.jsonl"
    expected = augment_metadata_with_identity(_canonical_metadata())

    candidate_meta = {
        "registry_key": "bert",
        "rulebook_id": "shared_lm_embedding_cache:v1",
        "dataset_shuffle_seed": 7,
        "ids_sha256": "idsh",
    }
    candidate = cache_root / "lm" / "bert-base-uncased" / "ag_news__legacy.npz"
    _write_cache(candidate, metadata=candidate_meta, include_header_fields=True)
    build_legacy_index(cache_dir=cache_root, index_path=index_path)

    resolved = resolve_cache_with_index(
        cache_root / "lm" / "bert-base-uncased" / "ag_news__missing.npz",
        expected_metadata=expected,
        dataset_name="ag_news",
        cache_dir=cache_root,
        index_path=index_path,
    )
    assert resolved is None


def test_resolver_accepts_dataset_key_mismatch_when_manifests_match(tmp_path: Path) -> None:
    cache_root = tmp_path / "cache"
    index_path = cache_root / ".labenv" / "index_v1.jsonl"

    expected = augment_metadata_with_identity(_canonical_metadata(dataset_key="dk-expected"))
    candidate_meta = augment_metadata_with_identity(_canonical_metadata(dataset_key="dk-legacy"))

    # dataset_name_hint becomes hash-like, but metadata match should still resolve.
    candidate = cache_root / "lm" / "bert-base-uncased" / "6de179abcd1234ef__legacy.npz"
    _write_cache(candidate, metadata=candidate_meta)
    build_legacy_index(cache_dir=cache_root, index_path=index_path)

    resolved = resolve_cache_with_index(
        cache_root / "lm" / "bert-base-uncased" / "ag_news__missing.npz",
        expected_metadata=expected,
        dataset_name="ag_news",
        cache_dir=cache_root,
        index_path=index_path,
    )
    assert resolved is not None
    assert resolved.path == candidate.resolve()
    assert resolved.source == "legacy_index"


def test_lock_export_writes_policy_index_and_verify(tmp_path: Path) -> None:
    cache_root = tmp_path / "cache"
    candidate = cache_root / "lm" / "bert-base-uncased" / "ag_news__bert-base-uncased.npz"
    metadata = augment_metadata_with_identity(_canonical_metadata())
    _write_cache(candidate, metadata=metadata)

    requests_path = tmp_path / "requests.jsonl"
    requests_path.write_text(
        json.dumps(
            {
                "request_id": "ag_news:bert",
                "dataset_name": "ag_news",
                "model_id": "bert",
                "model_name": "bert-base-uncased",
                "embedding_type": "hf_transformer",
                "registry_key": "bert",
                "rulebook_id": "shared_lm_embedding_cache:v1",
                "pooling": "mean",
                "hidden_state_layer": -1,
                "dataset_shuffle_seed": 7,
                "ids_sha256": metadata["ids_sha256"],
                "expected_cache_path": str(candidate),
                "identity_hash": metadata["identity_hash"],
            },
            ensure_ascii=True,
        )
        + "\n",
        encoding="utf-8",
    )

    output_path = tmp_path / "lock.json"
    status = tool_main(
        [
            "lock-export",
            "--cache-dir",
            str(cache_root),
            "--requests",
            str(requests_path),
            "--output",
            str(output_path),
            "--min-selected-models",
            "1",
        ]
    )
    assert status == 0
    payload = json.loads(output_path.read_text(encoding="utf-8"))
    assert "policy_digest" in payload
    assert "index" in payload
    assert "verify" in payload
    assert payload["verify"]["selected_models"] == ["bert"]
