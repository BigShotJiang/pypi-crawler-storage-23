from __future__ import annotations

from pathlib import Path

import pytest

from labenv_embedding_cache.resolver import build_request_manifest_entry


def _metadata() -> dict[str, object]:
    return {
        "embedding_type": "hf_transformer",
        "registry_key": "bert",
        "rulebook_id": "shared_lm_embedding_cache:v1",
        "pooling": "mean",
        "hidden_state_layer": -1,
        "dataset_shuffle": False,
        "dataset_shuffle_seed": 7,
        "dataset_key": "dataset-key",
        "dataset_config_hash": "dataset-config-hash",
        "text_manifest_hash": "text-manifest-hash",
        "label_manifest_hash": "label-manifest-hash",
        "variant_tag": "variant-tag",
        "ids_sha256": "ids-from-metadata",
        "embedding_seed": 7,
        "cache_all_layers": False,
        "torch_dtype": "bfloat16",
        "tokenizer_id": "google-bert/bert-base-cased",
        "text_preprocess_id": "none",
        "identity_profile_id": "default",
        "identity_version": 1,
        "identity_hash": "identity-hash",
        "config_extensions_hash": "cfgext-hash",
    }


def test_build_request_manifest_entry_populates_lcm_fields(tmp_path: Path) -> None:
    expected_cache_path = tmp_path / "cache.npz"
    record = build_request_manifest_entry(
        dataset_name="ag_news",
        model_id="bert",
        model_name="bert-base-uncased",
        expected_cache_path=expected_cache_path,
        metadata=_metadata(),
    )

    assert record["request_id"] == "ag_news:bert"
    assert record["dataset_name"] == "ag_news"
    assert record["model_id"] == "bert"
    assert record["model_name"] == "bert-base-uncased"
    assert record["expected_cache_path"] == str(expected_cache_path.resolve())
    assert record["embedding_type"] == "hf_transformer"
    assert record["registry_key"] == "bert"
    assert record["rulebook_id"] == "shared_lm_embedding_cache:v1"
    assert record["pooling"] == "mean"
    assert record["hidden_state_layer"] == -1
    assert record["dataset_shuffle"] is False
    assert record["dataset_shuffle_seed"] == 7
    assert record["dataset_key"] == "dataset-key"
    assert record["dataset_config_hash"] == "dataset-config-hash"
    assert record["text_manifest_hash"] == "text-manifest-hash"
    assert record["label_manifest_hash"] == "label-manifest-hash"
    assert record["variant_tag"] == "variant-tag"
    assert record["ids_sha256"] == "ids-from-metadata"
    assert record["embedding_seed"] == 7
    assert record["cache_all_layers"] is False
    assert record["torch_dtype"] == "bfloat16"
    assert record["tokenizer_id"] == "google-bert/bert-base-cased"
    assert record["text_preprocess_id"] == "none"
    assert record["identity_profile_id"] == "default"
    assert record["identity_version"] == 1
    assert record["identity_hash"] == "identity-hash"
    assert record["config_extensions_hash"] == "cfgext-hash"


def test_build_request_manifest_entry_supports_overrides(tmp_path: Path) -> None:
    record = build_request_manifest_entry(
        dataset_name="ag_news",
        model_id="bert",
        model_name="bert-base-uncased",
        expected_cache_path=tmp_path / "cache.npz",
        metadata=_metadata(),
        request_id="custom-id",
        ids_sha256="ids-override",
        extra_fields={"custom_field": "ok"},
    )

    assert record["request_id"] == "custom-id"
    assert record["ids_sha256"] == "ids-override"
    assert record["custom_field"] == "ok"


def test_build_request_manifest_entry_handles_resolve_permission_error(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    original_resolve = Path.resolve

    def _raise_permission(self: Path, *, strict: bool = False) -> Path:  # type: ignore[override]
        raise PermissionError("blocked")

    monkeypatch.setattr(Path, "resolve", _raise_permission)
    expected = Path("/root/data/embedding_cache/example.npz")

    record = build_request_manifest_entry(
        dataset_name="ag_news",
        model_id="bert",
        model_name="bert-base-uncased",
        expected_cache_path=expected,
        metadata=_metadata(),
    )

    # Fallback keeps an absolute path string when canonical resolution fails.
    assert record["expected_cache_path"] == str(expected)

    # Keep monkeypatch usage explicit to satisfy linters/type-checkers.
    monkeypatch.setattr(Path, "resolve", original_resolve)


@pytest.mark.parametrize(
    ("dataset_name", "model_id", "model_name"),
    [
        ("", "bert", "bert-base-uncased"),
        ("ag_news", "", "bert-base-uncased"),
        ("ag_news", "bert", ""),
    ],
)
def test_build_request_manifest_entry_rejects_empty_required_values(
    dataset_name: str,
    model_id: str,
    model_name: str,
    tmp_path: Path,
) -> None:
    with pytest.raises(ValueError):
        build_request_manifest_entry(
            dataset_name=dataset_name,
            model_id=model_id,
            model_name=model_name,
            expected_cache_path=tmp_path / "cache.npz",
            metadata=_metadata(),
        )
