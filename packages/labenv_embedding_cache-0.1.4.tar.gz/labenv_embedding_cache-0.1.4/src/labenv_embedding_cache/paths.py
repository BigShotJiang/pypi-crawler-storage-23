import os
from pathlib import Path
from typing import Any, Mapping, Optional

from .standards import (
    include_shuffle_seed_in_filename,
    resolve_shared_cache_layout,
    resolve_shared_cache_tag,
    resolve_shared_embedding_cache_dir,
)


def _cfg_get(source: Any, path: str, default: Any = None) -> Any:
    current = source
    for part in path.split("."):
        if isinstance(current, Mapping):
            if part not in current:
                return default
            current = current[part]
        else:
            if not hasattr(current, part):
                return default
            current = getattr(current, part)
    return current


def resolve_embedding_cache_dir(
    cfg: Any,
    *,
    env_var: str = "TEXT_EMBEDDING_CACHE_DIR",
) -> Path:
    del cfg, env_var
    return resolve_shared_embedding_cache_dir()


def _sanitize_component(raw: str) -> str:
    safe = str(raw).strip()
    for sep in {os.sep, os.altsep} - {None}:
        safe = safe.replace(sep, "__")
    safe = safe.replace("/", "__").replace(" ", "_")
    return safe


def _embedding_family(embedding_type: str | None) -> str:
    if embedding_type in {"hf_transformer", "sentence_transformer"}:
        return "lm"
    if embedding_type:
        return str(embedding_type)
    return "unknown"


def _to_bool_token(value: Any) -> str:
    return "true" if bool(value) else "false"


def _resolve_tokenizer_id(embedding_cfg: Any) -> str | None:
    candidates = [
        _cfg_get(embedding_cfg, "tokenizer_name", None),
        _cfg_get(embedding_cfg, "tokenizer_model_name", None),
        _cfg_get(embedding_cfg, "tokenizer.model_name", None),
        _cfg_get(embedding_cfg, "tokenizer.name", None),
        _cfg_get(embedding_cfg, "tokenizer.id", None),
        _cfg_get(embedding_cfg, "tokenizer", None),
    ]
    for candidate in candidates:
        if candidate is None or isinstance(candidate, Mapping):
            continue
        text = str(candidate).strip()
        if text:
            return text
    return None


def _is_embedding_l2_normalized(embedding_cfg: Any) -> bool:
    for key in ("normalize_embeddings", "normalize", "l2_normalize"):
        raw = _cfg_get(embedding_cfg, key, None)
        if raw is None:
            continue
        if isinstance(raw, bool):
            return raw
        text = str(raw).strip().lower()
        if text in {"1", "true", "yes", "y", "t", "on"}:
            return True
        if text in {"0", "false", "no", "n", "f", "off", ""}:
            return False
        return bool(raw)
    return False


def build_embedding_variant_tag(
    embedding_cfg: Any,
    *,
    embedding_seed: int | None = None,
) -> str:
    hidden_state_layer = _cfg_get(embedding_cfg, "hidden_state_layer", None)
    layer_token = "final" if hidden_state_layer is None else str(int(hidden_state_layer))
    cache_all_layers = _to_bool_token(_cfg_get(embedding_cfg, "cache_all_layers", False))
    pooling = str(_cfg_get(embedding_cfg, "pooling", "mean") or "mean").strip().lower()
    torch_dtype = _cfg_get(embedding_cfg, "torch_dtype", None)
    dtype_token = "none" if torch_dtype is None else _sanitize_component(str(torch_dtype))
    seed_token = "none" if embedding_seed is None else str(int(embedding_seed))

    components = [
        f"layer={layer_token}",
        f"all_layers={cache_all_layers}",
        f"pool={pooling}",
        f"dtype={dtype_token}",
        f"embseed={seed_token}",
    ]
    tokenizer_id = _resolve_tokenizer_id(embedding_cfg)
    if tokenizer_id:
        components.append(f"tok={tokenizer_id}")
    if _is_embedding_l2_normalized(embedding_cfg):
        components.append("norm=l2")
    return "__".join(_sanitize_component(part) for part in components)


def build_embedding_cache_filename(
    cfg: Any,
    *,
    dataset_key: str | None = None,
    variant_tag: str | None = None,
    include_shuffle_seed: bool | None = None,
) -> str:
    dataset_name = dataset_key or str(_cfg_get(cfg, "dataset.name", "unknown_dataset"))
    model_name = _cfg_get(cfg, "embedding.model_name", None) or _cfg_get(
        cfg,
        "embedding.name",
        "unknown_model",
    )
    safe_model_name = _sanitize_component(str(model_name))

    filename = f"{_sanitize_component(str(dataset_name))}__{safe_model_name}"

    if include_shuffle_seed is None:
        include_shuffle_seed = include_shuffle_seed_in_filename()
    if include_shuffle_seed and bool(_cfg_get(cfg, "dataset.shuffle", False)):
        seed = _cfg_get(cfg, "dataset.shuffle_seed", None)
        if seed is not None:
            filename += f"__seed{int(seed)}"
        else:
            filename += "__shuffle"

    resolved_tag = variant_tag if variant_tag is not None else resolve_shared_cache_tag(cfg)
    if resolved_tag:
        safe_tag = _sanitize_component(resolved_tag)
        if safe_tag:
            filename += f"__tag{safe_tag}"

    return f"{filename}.npz"


def get_embedding_cache_path(
    cfg: Any,
    *,
    dataset_key: str | None = None,
    variant_tag: str | None = None,
    include_shuffle_seed: bool | None = None,
) -> Path:
    base_dir = resolve_embedding_cache_dir(cfg)
    filename = build_embedding_cache_filename(
        cfg,
        dataset_key=dataset_key,
        variant_tag=variant_tag,
        include_shuffle_seed=include_shuffle_seed,
    )
    if resolve_shared_cache_layout() == "hierarchical":
        emb_family = _embedding_family(_cfg_get(cfg, "embedding.type", None))
        model_name = _cfg_get(cfg, "embedding.model_name", None) or _cfg_get(
            cfg,
            "embedding.name",
            "unknown_model",
        )
        return base_dir / emb_family / str(model_name) / filename
    return base_dir / filename
