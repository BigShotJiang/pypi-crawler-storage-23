from __future__ import annotations

import json
import string
from dataclasses import dataclass
from datetime import date
from pathlib import Path
from typing import Any, Mapping, Optional, Sequence

import numpy as np

from .fingerprints import build_ids_sha256
from .identity import augment_metadata_with_identity
from .indexing import load_legacy_index
from .paths import get_embedding_cache_path
from .standards import enforce_registry_key_on_cache, enforce_rulebook_id_on_cache, load_rulebook


@dataclass(frozen=True)
class ResolvedCachePath:
    path: Path
    source: str
    metadata: dict[str, Any]


def _coerce_scalar(value: Any) -> Any:
    if isinstance(value, np.ndarray):
        if value.shape == ():
            return value.item()
        return value
    return value


def _to_optional_int(value: Any) -> Optional[int]:
    value = _coerce_scalar(value)
    if value is None:
        return None
    return int(value)


def _to_optional_str(value: Any) -> Optional[str]:
    value = _coerce_scalar(value)
    if value is None:
        return None
    text = str(value).strip()
    return text or None


def _safe_normalize_path(path: str | Path) -> Path:
    """Return an absolute path without failing on inaccessible prefixes."""
    raw = Path(path).expanduser()
    try:
        return raw.resolve(strict=False)
    except Exception:
        if raw.is_absolute():
            return raw
        return Path.cwd() / raw


def _safe_path_exists(path: Path) -> bool:
    try:
        return path.exists()
    except OSError:
        return False


def _load_metadata_json(data: Any) -> dict[str, Any]:
    raw = _coerce_scalar(data)
    if raw is None:
        return {}
    try:
        parsed = json.loads(str(raw))
    except Exception:
        return {}
    return parsed if isinstance(parsed, dict) else {}


def _compatibility_policy() -> dict[str, Any]:
    rulebook = load_rulebook()
    compat = rulebook.get("compatibility", {}) if isinstance(rulebook, Mapping) else {}
    legacy_index = compat.get("legacy_index", {}) if isinstance(compat, Mapping) else {}

    enabled = bool(legacy_index.get("enabled", True))

    sunset_raw = legacy_index.get("sunset_date")
    sunset_date = None
    if sunset_raw is not None:
        try:
            sunset_date = date.fromisoformat(str(sunset_raw))
        except ValueError:
            sunset_date = None
    if sunset_date is not None and date.today() > sunset_date:
        enabled = False

    require_ids_sha256_match = bool(legacy_index.get("require_ids_sha256_match", True))
    require_variant_tag_match = bool(legacy_index.get("require_variant_tag_match", True))
    return {
        "enabled": enabled,
        "sunset_date": sunset_date,
        "require_ids_sha256_match": require_ids_sha256_match,
        "require_variant_tag_match": require_variant_tag_match,
    }


def _looks_like_hash(value: str) -> bool:
    text = value.strip().lower()
    if len(text) < 16:
        return False
    return all(ch in string.hexdigits for ch in text)


def _load_npz_with_compat(path: Path) -> Optional[tuple[np.ndarray, Optional[int], dict[str, Any]]]:
    if not _safe_path_exists(path):
        return None

    with np.load(path, allow_pickle=True) as data:
        files = set(data.files)
        if "ids" in files and "embeddings" in files:
            ids = np.asarray(data["ids"]).reshape(-1)
            metadata = _load_metadata_json(data["metadata_json"]) if "metadata_json" in files else {}
            for key in (
                "rulebook_id",
                "registry_key",
                "embedding_type",
                "pooling",
                "hidden_state_layer",
                "variant_tag",
                "dataset_key",
                "dataset_config_hash",
                "text_manifest_hash",
                "label_manifest_hash",
                "dataset_shuffle",
                "dataset_shuffle_seed",
                "ids_sha256",
                "identity_hash",
                "config_extensions_hash",
                "shuffle_seed",
            ):
                if key in metadata:
                    continue
                if key in files:
                    metadata[key] = _coerce_scalar(data[key])

            shuffle_seed = _to_optional_int(data["shuffle_seed"]) if "shuffle_seed" in files else None
            if metadata.get("dataset_shuffle_seed") is None and shuffle_seed is not None:
                metadata["dataset_shuffle_seed"] = shuffle_seed
            if metadata.get("ids_sha256") is None:
                metadata["ids_sha256"] = build_ids_sha256(ids.tolist())
            metadata = augment_metadata_with_identity(metadata)
            return ids, shuffle_seed, metadata
    return None


def read_cache_header(path: str | Path) -> Optional[dict[str, Any]]:
    resolved_path = _safe_normalize_path(path)
    loaded = _load_npz_with_compat(resolved_path)
    if loaded is None:
        return None
    ids, shuffle_seed, metadata = loaded
    out = dict(metadata)
    out.setdefault("ids_sha256", build_ids_sha256(ids.tolist()))
    if out.get("dataset_shuffle_seed") is None and shuffle_seed is not None:
        out["dataset_shuffle_seed"] = shuffle_seed
    return out


def validate_cache_header(
    path: str | Path,
    *,
    required_fields: Sequence[str] = (),
    allow_empty: bool = True,
) -> dict[str, Any]:
    metadata = read_cache_header(path)
    resolved_path = _safe_normalize_path(path)
    if metadata is None:
        raise ValueError(f"Failed to read cache header metadata from '{resolved_path}'.")
    if not allow_empty and not metadata:
        raise ValueError(f"Cache header metadata is empty at '{resolved_path}'.")
    missing = [field for field in required_fields if field not in metadata]
    if missing:
        raise ValueError(
            f"Cache header metadata missing required fields at '{resolved_path}': {missing}"
        )
    return dict(metadata)


def _has_dataset_signature_match(
    expected_metadata: Mapping[str, Any],
    candidate_metadata: Mapping[str, Any],
    *,
    require_ids_sha256_match: bool,
) -> bool:
    expected_text_hash = _to_optional_str(expected_metadata.get("text_manifest_hash"))
    candidate_text_hash = _to_optional_str(candidate_metadata.get("text_manifest_hash"))
    expected_label_hash = _to_optional_str(expected_metadata.get("label_manifest_hash"))
    candidate_label_hash = _to_optional_str(candidate_metadata.get("label_manifest_hash"))

    if expected_text_hash is None or candidate_text_hash is None:
        return False
    if expected_label_hash is None or candidate_label_hash is None:
        return False
    if expected_text_hash != candidate_text_hash or expected_label_hash != candidate_label_hash:
        return False

    expected_ids_sha256 = _to_optional_str(expected_metadata.get("ids_sha256"))
    candidate_ids_sha256 = _to_optional_str(candidate_metadata.get("ids_sha256"))
    if require_ids_sha256_match and expected_ids_sha256 is not None:
        return candidate_ids_sha256 is not None and candidate_ids_sha256 == expected_ids_sha256
    if expected_ids_sha256 is not None and candidate_ids_sha256 is not None:
        return expected_ids_sha256 == candidate_ids_sha256
    return True


def _validate_expected_metadata(
    path: Path,
    candidate_metadata: Mapping[str, Any],
    expected_metadata: Mapping[str, Any],
    shuffle_seed: Optional[int],
    *,
    require_ids_sha256_match: bool,
    require_variant_tag_match: bool,
) -> None:
    dataset_signature_match = _has_dataset_signature_match(
        expected_metadata,
        candidate_metadata,
        require_ids_sha256_match=require_ids_sha256_match,
    )

    expected_registry = _to_optional_str(expected_metadata.get("registry_key"))
    candidate_registry = _to_optional_str(candidate_metadata.get("registry_key"))
    if expected_registry is not None:
        if candidate_registry is None:
            if enforce_registry_key_on_cache():
                raise ValueError(f"registry_key missing at {path}")
        elif candidate_registry != expected_registry:
            raise ValueError(
                f"registry_key mismatch: expected={expected_registry!r}, actual={candidate_registry!r}, path={path}"
            )

    expected_rulebook = _to_optional_str(expected_metadata.get("rulebook_id"))
    candidate_rulebook = _to_optional_str(candidate_metadata.get("rulebook_id"))
    if expected_rulebook is not None:
        if candidate_rulebook is None:
            if enforce_rulebook_id_on_cache():
                raise ValueError(f"rulebook_id missing at {path}")
        elif candidate_rulebook != expected_rulebook and enforce_rulebook_id_on_cache():
            raise ValueError(
                f"rulebook_id mismatch: expected={expected_rulebook!r}, actual={candidate_rulebook!r}, path={path}"
            )

    expected_seed = _to_optional_int(expected_metadata.get("dataset_shuffle_seed"))
    if expected_seed is not None:
        actual_seed = _to_optional_int(candidate_metadata.get("dataset_shuffle_seed"))
        if actual_seed is None:
            actual_seed = shuffle_seed
        if actual_seed is not None and actual_seed != expected_seed:
            raise ValueError(
                f"dataset_shuffle_seed mismatch: expected={expected_seed}, actual={actual_seed}, path={path}"
            )

    expected_variant = _to_optional_str(expected_metadata.get("variant_tag"))
    actual_variant = _to_optional_str(candidate_metadata.get("variant_tag"))
    if expected_variant is not None:
        if actual_variant is None:
            if require_variant_tag_match:
                raise ValueError(f"variant_tag missing at {path}")
        elif actual_variant != expected_variant:
            raise ValueError(
                f"variant_tag mismatch: expected={expected_variant!r}, actual={actual_variant!r}, path={path}"
            )

    expected_embedding_type = _to_optional_str(expected_metadata.get("embedding_type"))
    actual_embedding_type = _to_optional_str(candidate_metadata.get("embedding_type"))
    if (
        expected_embedding_type is not None
        and actual_embedding_type is not None
        and actual_embedding_type != expected_embedding_type
    ):
        raise ValueError(
            f"embedding_type mismatch: expected={expected_embedding_type!r}, actual={actual_embedding_type!r}, path={path}"
        )

    expected_pooling = _to_optional_str(expected_metadata.get("pooling"))
    actual_pooling = _to_optional_str(candidate_metadata.get("pooling"))
    if expected_pooling is not None and actual_pooling is not None and actual_pooling != expected_pooling:
        raise ValueError(f"pooling mismatch: expected={expected_pooling!r}, actual={actual_pooling!r}, path={path}")

    expected_layer = _to_optional_int(expected_metadata.get("hidden_state_layer"))
    actual_layer = _to_optional_int(candidate_metadata.get("hidden_state_layer"))
    if expected_layer is not None and actual_layer is not None and actual_layer != expected_layer:
        raise ValueError(
            f"hidden_state_layer mismatch: expected={expected_layer!r}, actual={actual_layer!r}, path={path}"
        )

    expected_ids_sha256 = _to_optional_str(expected_metadata.get("ids_sha256"))
    actual_ids_sha256 = _to_optional_str(candidate_metadata.get("ids_sha256"))
    if require_ids_sha256_match and expected_ids_sha256 is not None:
        if actual_ids_sha256 is None:
            raise ValueError(f"ids_sha256 missing at {path}")
        if actual_ids_sha256 != expected_ids_sha256:
            raise ValueError(
                f"ids_sha256 mismatch: expected={expected_ids_sha256!r}, actual={actual_ids_sha256!r}, path={path}"
            )

    expected_text_hash = _to_optional_str(expected_metadata.get("text_manifest_hash"))
    actual_text_hash = _to_optional_str(candidate_metadata.get("text_manifest_hash"))
    if expected_text_hash is not None and actual_text_hash is not None and actual_text_hash != expected_text_hash:
        raise ValueError(
            f"text_manifest_hash mismatch: expected={expected_text_hash!r}, actual={actual_text_hash!r}, path={path}"
        )

    expected_label_hash = _to_optional_str(expected_metadata.get("label_manifest_hash"))
    actual_label_hash = _to_optional_str(candidate_metadata.get("label_manifest_hash"))
    if expected_label_hash is not None and actual_label_hash is not None and actual_label_hash != expected_label_hash:
        raise ValueError(
            f"label_manifest_hash mismatch: expected={expected_label_hash!r}, actual={actual_label_hash!r}, path={path}"
        )

    expected_dataset_key = _to_optional_str(expected_metadata.get("dataset_key"))
    actual_dataset_key = _to_optional_str(candidate_metadata.get("dataset_key"))
    if expected_dataset_key is not None and actual_dataset_key is not None and actual_dataset_key != expected_dataset_key:
        if not dataset_signature_match:
            raise ValueError(
                f"dataset_key mismatch: expected={expected_dataset_key!r}, actual={actual_dataset_key!r}, path={path}"
            )

    expected_dataset_config_hash = _to_optional_str(expected_metadata.get("dataset_config_hash"))
    actual_dataset_config_hash = _to_optional_str(candidate_metadata.get("dataset_config_hash"))
    if (
        expected_dataset_config_hash is not None
        and actual_dataset_config_hash is not None
        and actual_dataset_config_hash != expected_dataset_config_hash
    ):
        if not dataset_signature_match:
            raise ValueError(
                "dataset_config_hash mismatch: "
                f"expected={expected_dataset_config_hash!r}, actual={actual_dataset_config_hash!r}, path={path}"
            )

    expected_identity_hash = _to_optional_str(expected_metadata.get("identity_hash"))
    candidate_identity_hash = _to_optional_str(candidate_metadata.get("identity_hash"))
    if expected_identity_hash is not None and candidate_identity_hash is not None:
        if candidate_identity_hash != expected_identity_hash and not dataset_signature_match:
            raise ValueError(
                f"identity_hash mismatch: expected={expected_identity_hash!r}, actual={candidate_identity_hash!r}, path={path}"
            )


def _dataset_rank(entry: Mapping[str, Any], dataset_name: str) -> int:
    if not dataset_name:
        return 0
    expected = dataset_name.strip().lower()
    if not expected:
        return 0

    hinted = _to_optional_str(entry.get("dataset_name_hint"))
    if hinted is not None and hinted.lower() == expected:
        return 0

    path_text = str(entry.get("cache_path", ""))
    stem = Path(path_text).stem.lower()
    if stem.startswith(f"{expected}__"):
        return 1

    if hinted is None:
        return 2
    if _looks_like_hash(hinted):
        return 3
    return 4


def _candidate_rank(
    entry: Mapping[str, Any],
    expected_metadata: Mapping[str, Any],
    *,
    dataset_name: str,
) -> tuple[int, int, int, int, int, int, int, str]:
    expected_identity = _to_optional_str(expected_metadata.get("identity_hash"))
    expected_registry = _to_optional_str(expected_metadata.get("registry_key"))
    expected_ids_sha256 = _to_optional_str(expected_metadata.get("ids_sha256"))
    expected_seed = _to_optional_int(expected_metadata.get("dataset_shuffle_seed"))
    expected_variant = _to_optional_str(expected_metadata.get("variant_tag"))

    entry_identity = _to_optional_str(entry.get("identity_hash"))
    entry_registry = _to_optional_str(entry.get("registry_key"))
    entry_ids_sha256 = _to_optional_str(entry.get("ids_sha256"))
    entry_seed = _to_optional_int(entry.get("shuffle_seed"))
    entry_variant = _to_optional_str(entry.get("variant_tag"))
    entry_path = str(entry.get("cache_path", ""))

    if expected_identity is None:
        identity_rank = 0
    elif entry_identity == expected_identity:
        identity_rank = 0
    elif entry_identity is None:
        identity_rank = 1
    else:
        identity_rank = 2

    registry_rank = 0 if expected_registry is not None and entry_registry == expected_registry else 1
    ids_rank = 0 if expected_ids_sha256 is not None and entry_ids_sha256 == expected_ids_sha256 else 1
    seed_rank = 0 if expected_seed is not None and entry_seed == expected_seed else 1

    if expected_variant is None:
        variant_rank = 0 if not entry_variant else 1
    elif entry_variant == expected_variant:
        variant_rank = 0
    elif entry_variant in {None, ""}:
        variant_rank = 1
    else:
        variant_rank = 2

    dataset_rank = _dataset_rank(entry, dataset_name)
    tagdebug_rank = 1 if "__tagdebug" in Path(entry_path).name else 0
    return (dataset_rank, identity_rank, registry_rank, ids_rank, seed_rank, variant_rank, tagdebug_rank, entry_path)


def _embedding_family_hint(entry: Mapping[str, Any], expected_metadata: Mapping[str, Any]) -> Optional[str]:
    raw = _to_optional_str(entry.get("embedding_type")) or _to_optional_str(expected_metadata.get("embedding_type"))
    if raw is None:
        return None
    lowered = raw.lower()
    if lowered in {"hf_transformer", "sentence_transformer"}:
        return "lm"
    return lowered or None


def _remap_suffix_candidates(path: Path, *, family_hint: Optional[str]) -> list[Path]:
    """Build relative suffix candidates that can be re-anchored under cache_dir."""
    parts = path.parts
    candidates: list[Path] = []
    seen: set[str] = set()

    def _push(raw_parts: Sequence[str]) -> None:
        if not raw_parts:
            return
        candidate = Path(*raw_parts)
        key = str(candidate)
        if key in seen:
            return
        seen.add(key)
        candidates.append(candidate)

    anchors: list[str] = []
    if family_hint:
        anchors.append(family_hint)
    anchors.extend(["lm", "hf_transformer", "sentence_transformer"])
    for anchor in anchors:
        for index, part in enumerate(parts):
            if part == anchor and index < len(parts) - 1:
                _push(parts[index:])

    if path.suffix.lower() == ".npz":
        if len(parts) >= 3:
            _push(parts[-3:])
        if len(parts) >= 2:
            _push(parts[-2:])
        _push(parts[-1:])

    return candidates


def _record_path_candidates(
    record: Mapping[str, Any],
    *,
    cache_dir: str | Path | None,
    expected_metadata: Mapping[str, Any],
) -> list[Path]:
    raw_cache_path = _to_optional_str(record.get("cache_path"))
    if not raw_cache_path:
        return []

    raw_path = Path(raw_cache_path).expanduser()
    candidates: list[Path] = []
    seen: set[str] = set()

    def _append(path: Path) -> None:
        normalized = _safe_normalize_path(path)
        key = str(normalized)
        if key in seen:
            return
        seen.add(key)
        candidates.append(normalized)

    _append(raw_path)

    if cache_dir is None:
        return candidates

    cache_root = _safe_normalize_path(cache_dir)
    if not raw_path.is_absolute():
        _append(cache_root / raw_path)

    family_hint = _embedding_family_hint(record, expected_metadata)
    for suffix in _remap_suffix_candidates(raw_path, family_hint=family_hint):
        _append(cache_root / suffix)

    return candidates


def resolve_cache_with_index(
    expected_path: str | Path,
    *,
    expected_metadata: Mapping[str, Any] | None = None,
    dataset_name: str | None = None,
    cache_dir: str | Path | None = None,
    index_path: str | Path | None = None,
) -> Optional[ResolvedCachePath]:
    resolved_expected_path = _safe_normalize_path(expected_path)
    base_metadata = dict(expected_metadata or {})

    if _safe_path_exists(resolved_expected_path):
        return ResolvedCachePath(
            path=resolved_expected_path,
            source="canonical",
            metadata=base_metadata,
        )

    policy = _compatibility_policy()
    if not policy["enabled"]:
        return None

    normalized_dataset_name = (dataset_name or "").strip()
    if not normalized_dataset_name:
        fallback_name = _to_optional_str(base_metadata.get("dataset_name"))
        normalized_dataset_name = fallback_name or ""

    records = load_legacy_index(cache_dir=cache_dir, index_path=index_path)
    if not records:
        return None

    expected_registry = _to_optional_str(base_metadata.get("registry_key"))
    candidates: list[tuple[tuple[int, int, int, int, int, int, int, str], Mapping[str, Any], list[Path]]] = []
    for record in records:
        candidate_paths = _record_path_candidates(
            record,
            cache_dir=cache_dir,
            expected_metadata=base_metadata,
        )
        if not any(_safe_path_exists(path) for path in candidate_paths):
            continue

        entry_registry = _to_optional_str(record.get("registry_key"))
        if expected_registry is not None and entry_registry is not None and entry_registry != expected_registry:
            continue

        rank = _candidate_rank(record, base_metadata, dataset_name=normalized_dataset_name)
        candidates.append((rank, record, candidate_paths))

    for _rank, _record, candidate_paths in sorted(candidates, key=lambda item: item[0]):
        for candidate_path in candidate_paths:
            loaded = _load_npz_with_compat(candidate_path)
            if loaded is None:
                continue
            ids, shuffle_seed, candidate_metadata = loaded
            if candidate_metadata.get("ids_sha256") is None:
                candidate_metadata["ids_sha256"] = build_ids_sha256(ids.tolist())
            try:
                _validate_expected_metadata(
                    candidate_path,
                    candidate_metadata,
                    base_metadata,
                    shuffle_seed,
                    require_ids_sha256_match=bool(policy["require_ids_sha256_match"]),
                    require_variant_tag_match=bool(policy["require_variant_tag_match"]),
                )
            except Exception:
                continue

            merged_metadata = dict(base_metadata)
            merged_metadata.update(candidate_metadata)
            if merged_metadata.get("dataset_shuffle_seed") is None and shuffle_seed is not None:
                merged_metadata["dataset_shuffle_seed"] = shuffle_seed
            return ResolvedCachePath(
                path=candidate_path,
                source="legacy_index",
                metadata=merged_metadata,
            )

    return None


_REQUEST_METADATA_FIELDS: tuple[str, ...] = (
    "embedding_type",
    "registry_key",
    "rulebook_id",
    "pooling",
    "hidden_state_layer",
    "dataset_shuffle",
    "dataset_shuffle_seed",
    "dataset_key",
    "dataset_config_hash",
    "text_manifest_hash",
    "label_manifest_hash",
    "variant_tag",
    "ids_sha256",
    "embedding_seed",
    "cache_all_layers",
    "torch_dtype",
    "tokenizer_id",
    "text_preprocess_id",
    "identity_profile_id",
    "identity_version",
    "identity_hash",
    "config_extensions_hash",
)


def build_request_manifest_entry(
    *,
    dataset_name: str,
    model_id: str,
    model_name: str,
    expected_cache_path: str | Path,
    metadata: Mapping[str, Any] | None = None,
    request_id: str | None = None,
    ids_sha256: str | None = None,
    extra_fields: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    dataset_text = str(dataset_name).strip()
    if not dataset_text:
        raise ValueError("dataset_name must not be empty")
    model_id_text = str(model_id).strip()
    if not model_id_text:
        raise ValueError("model_id must not be empty")
    model_name_text = str(model_name).strip()
    if not model_name_text:
        raise ValueError("model_name must not be empty")

    expected_path = _safe_normalize_path(expected_cache_path)
    merged_metadata = dict(metadata or {})
    record: dict[str, Any] = {
        "request_id": str(request_id or f"{dataset_text}:{model_id_text}"),
        "dataset_name": dataset_text,
        "model_id": model_id_text,
        "model_name": model_name_text,
        "expected_cache_path": str(expected_path),
    }
    for key in _REQUEST_METADATA_FIELDS:
        if key == "ids_sha256":
            record[key] = ids_sha256 or merged_metadata.get(key)
            continue
        record[key] = merged_metadata.get(key)

    if extra_fields:
        record.update(dict(extra_fields))
    return record


def _request_model_id(request: Mapping[str, Any]) -> str:
    for key in ("model_id", "model_name", "registry_key"):
        raw = request.get(key)
        if raw is None:
            continue
        text = str(raw).strip()
        if text:
            return text
    return "unknown_model"


def _request_dataset_name(request: Mapping[str, Any]) -> str:
    raw = request.get("dataset_name")
    if raw is None:
        raise ValueError("request.dataset_name is required")
    text = str(raw).strip()
    if not text:
        raise ValueError("request.dataset_name must not be empty")
    return text


def _request_expected_path(request: Mapping[str, Any]) -> Path:
    explicit = request.get("expected_cache_path")
    if explicit is not None and str(explicit).strip():
        return _safe_normalize_path(str(explicit))

    dataset_name = _request_dataset_name(request)
    model_name = request.get("model_name")
    if model_name is None:
        raise ValueError("request.model_name is required when expected_cache_path is not provided")
    cfg = {
        "dataset": {
            "name": dataset_name,
            "shuffle": bool(request.get("dataset_shuffle", request.get("dataset_shuffle_seed") is not None)),
            "shuffle_seed": request.get("dataset_shuffle_seed"),
        },
        "embedding": {
            "type": request.get("embedding_type"),
            "model_name": model_name,
            "name": request.get("model_name"),
            "pooling": request.get("pooling"),
            "hidden_state_layer": request.get("hidden_state_layer"),
            "cache_all_layers": bool(request.get("cache_all_layers", False)),
            "torch_dtype": request.get("torch_dtype"),
            "embedding_seed": request.get("embedding_seed"),
            "normalize_embeddings": bool(request.get("normalize_embeddings", False)),
        },
    }
    return _safe_normalize_path(
        get_embedding_cache_path(
            cfg,
            dataset_key=_to_optional_str(request.get("dataset_key")),
            variant_tag=_to_optional_str(request.get("variant_tag")),
        )
    )


def _request_expected_metadata(request: Mapping[str, Any]) -> dict[str, Any]:
    return {
        "dataset_key": request.get("dataset_key"),
        "dataset_config_hash": request.get("dataset_config_hash"),
        "text_manifest_hash": request.get("text_manifest_hash"),
        "label_manifest_hash": request.get("label_manifest_hash"),
        "dataset_shuffle": request.get("dataset_shuffle"),
        "registry_key": request.get("registry_key"),
        "rulebook_id": request.get("rulebook_id"),
        "embedding_type": request.get("embedding_type"),
        "pooling": request.get("pooling"),
        "hidden_state_layer": request.get("hidden_state_layer"),
        "dataset_shuffle_seed": request.get("dataset_shuffle_seed"),
        "ids_sha256": request.get("ids_sha256"),
        "variant_tag": request.get("variant_tag"),
        "embedding_seed": request.get("embedding_seed"),
        "cache_all_layers": request.get("cache_all_layers"),
        "torch_dtype": request.get("torch_dtype"),
        "tokenizer_id": request.get("tokenizer_id"),
        "text_preprocess_id": request.get("text_preprocess_id"),
        "identity_profile_id": request.get("identity_profile_id"),
        "identity_version": request.get("identity_version"),
        "identity_hash": request.get("identity_hash"),
        "config_extensions_hash": request.get("config_extensions_hash"),
    }


def verify_cache_requests(
    requests: Sequence[Mapping[str, Any]],
    *,
    cache_dir: str | Path | None = None,
    index_path: str | Path | None = None,
) -> dict[str, Any]:
    datasets: list[str] = []
    models: list[str] = []
    available: dict[str, dict[str, bool]] = {}
    errors: dict[str, dict[str, str]] = {}
    results: list[dict[str, Any]] = []

    for request in requests:
        dataset_name = _request_dataset_name(request)
        model_id = _request_model_id(request)

        if dataset_name not in datasets:
            datasets.append(dataset_name)
        if model_id not in models:
            models.append(model_id)
        available.setdefault(dataset_name, {})
        errors.setdefault(dataset_name, {})

        request_id = str(request.get("request_id") or f"{dataset_name}:{model_id}")
        expected_metadata = _request_expected_metadata(request)
        try:
            expected_path = _request_expected_path(request)
            resolved = resolve_cache_with_index(
                expected_path,
                expected_metadata=expected_metadata,
                dataset_name=dataset_name,
                cache_dir=cache_dir,
                index_path=index_path,
            )
            if resolved is None:
                available[dataset_name][model_id] = False
                errors[dataset_name][model_id] = "cache_not_found"
                results.append(
                    {
                        "request_id": request_id,
                        "dataset_name": dataset_name,
                        "model_id": model_id,
                        "available": False,
                        "expected_cache_path": str(expected_path),
                        "resolved_cache_path": None,
                        "source": None,
                        "error": "cache_not_found",
                    }
                )
            else:
                available[dataset_name][model_id] = True
                results.append(
                    {
                        "request_id": request_id,
                        "dataset_name": dataset_name,
                        "model_id": model_id,
                        "available": True,
                        "expected_cache_path": str(expected_path),
                        "resolved_cache_path": str(resolved.path),
                        "source": resolved.source,
                        "error": None,
                    }
                )
        except Exception as exc:
            message = f"{type(exc).__name__}: {exc}"
            available[dataset_name][model_id] = False
            errors[dataset_name][model_id] = message
            results.append(
                {
                    "request_id": request_id,
                    "dataset_name": dataset_name,
                    "model_id": model_id,
                    "available": False,
                    "expected_cache_path": None,
                    "resolved_cache_path": None,
                    "source": None,
                    "error": message,
                }
            )

    sorted_datasets = sorted(datasets)
    sorted_models = sorted(models)
    selected_models = [
        model
        for model in sorted_models
        if all(available.get(dataset, {}).get(model, False) for dataset in sorted_datasets)
    ]
    pruned_models = [model for model in sorted_models if model not in selected_models]

    missing: dict[str, list[str]] = {}
    for dataset in sorted_datasets:
        missing[dataset] = [
            model for model in sorted_models if not available.get(dataset, {}).get(model, False)
        ]
        if not errors.get(dataset):
            errors.pop(dataset, None)

    selected_count = len(selected_models)
    ready_pairs = 0
    if selected_count >= 2:
        ready_pairs = len(sorted_datasets) * selected_count * (selected_count - 1)

    return {
        "datasets": sorted_datasets,
        "models": sorted_models,
        "available": {
            dataset: {
                model: bool(available.get(dataset, {}).get(model, False))
                for model in sorted_models
            }
            for dataset in sorted_datasets
        },
        "missing": missing,
        "errors": errors,
        "selected_models": selected_models,
        "pruned_models": pruned_models,
        "ready_pairs": ready_pairs,
        "results": results,
        "index_path": str(index_path) if index_path is not None else None,
    }


def load_request_manifest(path: str | Path) -> list[dict[str, Any]]:
    manifest_path = Path(path).expanduser().resolve()
    if not manifest_path.exists():
        raise FileNotFoundError(f"Request manifest not found: {manifest_path}")

    if manifest_path.suffix.lower() == ".json":
        loaded = json.loads(manifest_path.read_text(encoding="utf-8"))
        if isinstance(loaded, dict):
            items = loaded.get("requests")
            if not isinstance(items, list):
                raise ValueError("JSON request manifest must contain a 'requests' list.")
            return [dict(item) for item in items if isinstance(item, Mapping)]
        if isinstance(loaded, list):
            return [dict(item) for item in loaded if isinstance(item, Mapping)]
        raise ValueError("Unsupported JSON manifest format.")

    requests: list[dict[str, Any]] = []
    with manifest_path.open("r", encoding="utf-8") as handle:
        for line_no, line in enumerate(handle, start=1):
            text = line.strip()
            if not text:
                continue
            try:
                payload = json.loads(text)
            except json.JSONDecodeError as exc:
                raise ValueError(f"Invalid JSON at {manifest_path}:{line_no}: {exc}") from exc
            if not isinstance(payload, Mapping):
                raise ValueError(f"Request line must be a JSON object at {manifest_path}:{line_no}")
            requests.append(dict(payload))
    return requests
