import hashlib
import json
from pathlib import Path
from typing import Any, Mapping, Sequence

try:
    from omegaconf import DictConfig, ListConfig, OmegaConf
except Exception:  # pragma: no cover
    DictConfig = ()  # type: ignore[assignment]
    ListConfig = ()  # type: ignore[assignment]
    OmegaConf = None  # type: ignore[assignment]


_DEFAULT_DATASET_FIELDS: tuple[str, ...] = (
    "dataset.source",
    "dataset.name",
    "dataset.hf_path",
    "dataset.sklearn_dataset",
    "dataset.kaggle_handle",
    "dataset.data_files",
    "dataset.splits",
    "dataset.text_column",
    "dataset.label_column",
    "dataset.label_columns",
    "dataset.label_delimiter",
    "dataset.label_map",
    "dataset.label_remap",
    "dataset.drop_multi_label_samples",
    "dataset.multi_label",
    "dataset.trust_remote_code",
    "cebra.conditional",
    "dataset.text_preprocess_id",
)


def _maybe_to_container(value: Any) -> Any:
    if OmegaConf is not None and isinstance(value, (DictConfig, ListConfig)):
        return OmegaConf.to_container(value, resolve=True)
    return value


def _normalize_json_value(value: Any) -> Any:
    value = _maybe_to_container(value)
    if isinstance(value, Mapping):
        items = sorted(((str(k), _normalize_json_value(v)) for k, v in value.items()), key=lambda item: item[0])
        return {k: v for k, v in items}
    if isinstance(value, (list, tuple)):
        return [_normalize_json_value(v) for v in value]
    if isinstance(value, set):
        return [_normalize_json_value(v) for v in sorted(value, key=lambda x: str(x))]
    if isinstance(value, Path):
        return str(value)
    if hasattr(value, "tolist"):
        try:
            return _normalize_json_value(value.tolist())
        except Exception:
            pass
    if isinstance(value, bytes):
        return value.decode("utf-8", errors="replace")
    if isinstance(value, (str, int, float, bool)) or value is None:
        return value
    return str(value)


def canonical_json_dumps(value: Any) -> str:
    return json.dumps(
        _normalize_json_value(value),
        ensure_ascii=True,
        sort_keys=True,
        separators=(",", ":"),
    )


def sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def sha256_json(value: Any) -> str:
    return sha256_text(canonical_json_dumps(value))


def _get_by_path(source: Any, path: str, default: Any = None) -> Any:
    parts = path.split(".")
    current = source
    for part in parts:
        current = _maybe_to_container(current)
        if isinstance(current, Mapping):
            if part not in current:
                return default
            current = current[part]
        else:
            if not hasattr(current, part):
                return default
            current = getattr(current, part)
    return _maybe_to_container(current)


def build_dataset_signature(
    cfg: Any,
    *,
    fields: Sequence[str] = _DEFAULT_DATASET_FIELDS,
    text_preprocess_id: str | None = None,
) -> dict[str, Any]:
    signature: dict[str, Any] = {}
    for path in fields:
        value = _get_by_path(cfg, path, default=None)
        if value is None:
            continue
        signature[path] = value
    if text_preprocess_id is not None:
        signature["dataset.text_preprocess_id"] = str(text_preprocess_id)
    return signature


def build_dataset_config_hash(
    cfg: Any,
    *,
    fields: Sequence[str] = _DEFAULT_DATASET_FIELDS,
    text_preprocess_id: str | None = None,
) -> str:
    signature = build_dataset_signature(
        cfg,
        fields=fields,
        text_preprocess_id=text_preprocess_id,
    )
    return sha256_json(signature)


def _digest_label_value(label: Any) -> str:
    label = _maybe_to_container(label)
    if isinstance(label, (list, tuple, set)):
        normalized = sorted(str(v) for v in label)
    elif isinstance(label, Mapping):
        normalized = _normalize_json_value(label)
    else:
        normalized = label
    return sha256_json(normalized)


def _build_manifest(ids: Sequence[Any], digest_values: Sequence[str]) -> list[dict[str, str]]:
    if len(ids) != len(digest_values):
        raise ValueError("ids and values must have the same length.")
    rows = [
        {
            "id": str(sample_id),
            "digest": digest,
        }
        for sample_id, digest in zip(ids, digest_values)
    ]
    rows.sort(key=lambda item: item["id"])
    return rows


def build_ids_sha256(ids: Sequence[Any]) -> str:
    hasher = hashlib.sha256()
    hasher.update(str(len(ids)).encode("utf-8"))
    for sample_id in ids:
        payload = str(sample_id).encode("utf-8", errors="replace")
        hasher.update(len(payload).to_bytes(8, "little", signed=False))
        hasher.update(payload)
    return hasher.hexdigest()


def build_text_manifest_hash(ids: Sequence[Any], texts: Sequence[str]) -> str:
    text_digests = [sha256_text(str(text)) for text in texts]
    return sha256_json(_build_manifest(ids, text_digests))


def build_label_manifest_hash(ids: Sequence[Any], labels: Sequence[Any] | None) -> str:
    if labels is None:
        return sha256_json([])
    label_digests = [_digest_label_value(label) for label in labels]
    return sha256_json(_build_manifest(ids, label_digests))


def build_dataset_key(
    *,
    dataset_config_hash: str,
    text_manifest_hash: str,
    label_manifest_hash: str,
) -> str:
    payload = {
        "dataset_config_hash": str(dataset_config_hash),
        "text_manifest_hash": str(text_manifest_hash),
        "label_manifest_hash": str(label_manifest_hash),
    }
    return sha256_json(payload)
