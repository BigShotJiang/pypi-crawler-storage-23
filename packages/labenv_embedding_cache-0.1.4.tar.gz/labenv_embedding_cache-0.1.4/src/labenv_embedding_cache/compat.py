"""Runtime compatibility helpers for third-party ML libraries."""

from __future__ import annotations


def ensure_transformers_onnx_config() -> bool:
    """
    Ensure `from transformers.onnx import OnnxConfig` succeeds.

    Some Hugging Face models loaded with `trust_remote_code=True` import OnnxConfig
    even when ONNX export is not used (e.g. `jinaai/jina-bert-implementation`).
    Certain environments ship a Transformers build without the `transformers.onnx`
    package, which breaks model loading. For embedding generation, a minimal stub
    base class is sufficient.

    Returns
    -------
    bool
        True if a shim module was installed, else False.
    """
    import sys
    import types

    try:
        from transformers.onnx import OnnxConfig as _OnnxConfig  # noqa: F401

        return False
    except Exception:
        try:
            import transformers  # noqa: F401
        except Exception:
            # If transformers is not installed, callers will fail later anyway.
            return False

    shim = types.ModuleType("transformers.onnx")
    shim.__path__ = []  # type: ignore[attr-defined]

    class OnnxConfig:  # noqa: D401
        """Compatibility stub for environments missing `transformers.onnx`."""

        pass

    shim.OnnxConfig = OnnxConfig
    shim.OnnxConfigWithPast = OnnxConfig
    shim.OnnxSeq2SeqConfigWithPast = OnnxConfig

    config_shim = types.ModuleType("transformers.onnx.config")
    config_shim.OnnxConfig = OnnxConfig
    config_shim.OnnxConfigWithPast = OnnxConfig
    config_shim.OnnxSeq2SeqConfigWithPast = OnnxConfig
    shim.config = config_shim

    sys.modules["transformers.onnx"] = shim
    sys.modules["transformers.onnx.config"] = config_shim
    try:
        import transformers

        setattr(transformers, "onnx", shim)
    except Exception:
        pass

    return True
