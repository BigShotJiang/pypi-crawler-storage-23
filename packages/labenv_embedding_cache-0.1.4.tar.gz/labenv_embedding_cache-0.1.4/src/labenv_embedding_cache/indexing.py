from __future__ import annotations

import json
import hashlib
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable, Mapping, Optional

import numpy as np

from .fingerprints import build_ids_sha256
from .identity import augment_metadata_with_identity
from .standards import resolve_shared_embedding_cache_dir

INDEX_RELATIVE_PATH = Path(".labenv") / "index_v1.jsonl"


@dataclass(frozen=True)
class LegacyIndexEntry:
    cache_path: str
    registry_key: str
    rulebook_id: Optional[str]
    embedding_type: Optional[str]
    pooling: Optional[str]
    hidden_state_layer: Optional[int]
    dataset_name_hint: str
    shuffle_seed: Optional[int]
    ids_sha256: Optional[str]
    variant_tag: Optional[str]
    identity_hash: Optional[str]
    config_extensions_hash: Optional[str]
    file_sha256: Optional[str]
    source_format: str
    mtime_ns: int
    size_bytes: int

    def as_dict(self) -> dict[str, Any]:
        return {
            "cache_path": self.cache_path,
            "registry_key": self.registry_key,
            "rulebook_id": self.rulebook_id,
            "embedding_type": self.embedding_type,
            "pooling": self.pooling,
            "hidden_state_layer": self.hidden_state_layer,
            "dataset_name_hint": self.dataset_name_hint,
            "shuffle_seed": self.shuffle_seed,
            "ids_sha256": self.ids_sha256,
            "variant_tag": self.variant_tag,
            "identity_hash": self.identity_hash,
            "config_extensions_hash": self.config_extensions_hash,
            "file_sha256": self.file_sha256,
            "source_format": self.source_format,
            "mtime_ns": self.mtime_ns,
            "size_bytes": self.size_bytes,
        }


def _coerce_scalar(value: Any) -> Any:
    if isinstance(value, np.ndarray):
        if value.shape == ():
            return value.item()
        return value
    return value


def _to_optional_int(value: Any) -> Optional[int]:
    value = _coerce_scalar(value)
    if value is None:
        return None
    return int(value)


def _to_optional_str(value: Any) -> Optional[str]:
    value = _coerce_scalar(value)
    if value is None:
        return None
    text = str(value).strip()
    return text or None


def _load_metadata_json(raw: Any) -> dict[str, Any]:
    value = _coerce_scalar(raw)
    if value is None:
        return {}
    try:
        parsed = json.loads(str(value))
    except Exception:
        return {}
    return parsed if isinstance(parsed, dict) else {}


def _dataset_name_from_raw(raw: Any) -> Optional[str]:
    value = _coerce_scalar(raw)
    if value is None:
        return None
    if isinstance(value, Mapping):
        for key in ("name", "dataset_name", "dataset", "dataset_token"):
            nested = value.get(key)
            if nested is None:
                continue
            nested_text = str(_coerce_scalar(nested)).strip()
            if nested_text:
                return nested_text
        return None
    text = str(value).strip()
    if not text:
        return None
    if text.startswith("{") and text.endswith("}"):
        # Legacy metadata may stringify a dataset dict; avoid using it as a hint.
        return None
    return text


def _dataset_name_hint(path: Path, metadata: Mapping[str, Any]) -> str:
    for key in ("dataset_name", "dataset", "dataset_token"):
        parsed = _dataset_name_from_raw(metadata.get(key))
        if parsed:
            return parsed
    stem = path.stem
    if "__" in stem:
        return stem.split("__", 1)[0]
    return stem


def resolve_index_path(
    *,
    cache_dir: str | Path | None = None,
    index_path: str | Path | None = None,
) -> Path:
    if index_path is not None:
        return Path(index_path).expanduser().resolve()
    root = resolve_shared_embedding_cache_dir() if cache_dir is None else Path(cache_dir).expanduser().resolve()
    return (root / INDEX_RELATIVE_PATH).resolve()


def _iter_npz(cache_root: Path) -> Iterable[Path]:
    lm_root = cache_root / "lm"
    if not lm_root.exists():
        return []
    return sorted(path for path in lm_root.rglob("*.npz") if path.is_file())


def _sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while True:
            chunk = handle.read(1024 * 1024)
            if not chunk:
                break
            digest.update(chunk)
    return digest.hexdigest()


def _build_entry(path: Path, *, include_file_sha256: bool = False) -> Optional[LegacyIndexEntry]:
    with np.load(path, allow_pickle=True) as payload:
        files = set(payload.files)
        if "ids" not in files or "embeddings" not in files:
            return None

        metadata: dict[str, Any] = {}
        if "metadata_json" in files:
            metadata.update(_load_metadata_json(payload["metadata_json"]))

        for key in (
            "registry_key",
            "rulebook_id",
            "embedding_type",
            "pooling",
            "hidden_state_layer",
            "dataset_shuffle_seed",
            "variant_tag",
            "ids_sha256",
            "shuffle_seed",
        ):
            if key in metadata:
                continue
            if key in files:
                metadata[key] = _coerce_scalar(payload[key])

        registry_key = _to_optional_str(metadata.get("registry_key"))
        if registry_key is None:
            return None

        ids = payload["ids"]
        ids_sha256 = _to_optional_str(metadata.get("ids_sha256"))
        if ids_sha256 is None:
            try:
                ids_sha256 = build_ids_sha256(np.asarray(ids).reshape(-1).tolist())
            except Exception:
                ids_sha256 = None
        if ids_sha256 is not None:
            metadata["ids_sha256"] = ids_sha256

        shuffle_seed = _to_optional_int(metadata.get("dataset_shuffle_seed"))
        if shuffle_seed is None:
            shuffle_seed = _to_optional_int(metadata.get("shuffle_seed"))

        metadata = augment_metadata_with_identity(metadata)
        source_format = "npz_metadata_json" if "metadata_json" in files else "npz_header_only"
        stat = path.stat()
        return LegacyIndexEntry(
            cache_path=str(path.resolve()),
            registry_key=registry_key,
            rulebook_id=_to_optional_str(metadata.get("rulebook_id")),
            embedding_type=_to_optional_str(metadata.get("embedding_type")),
            pooling=_to_optional_str(metadata.get("pooling")),
            hidden_state_layer=_to_optional_int(metadata.get("hidden_state_layer")),
            dataset_name_hint=_dataset_name_hint(path, metadata),
            shuffle_seed=shuffle_seed,
            ids_sha256=ids_sha256,
            variant_tag=_to_optional_str(metadata.get("variant_tag")),
            identity_hash=_to_optional_str(metadata.get("identity_hash")),
            config_extensions_hash=_to_optional_str(metadata.get("config_extensions_hash")),
            file_sha256=_sha256_file(path) if include_file_sha256 else None,
            source_format=source_format,
            mtime_ns=int(stat.st_mtime_ns),
            size_bytes=int(stat.st_size),
        )


def build_legacy_index(
    *,
    cache_dir: str | Path | None = None,
    index_path: str | Path | None = None,
    strict: bool = False,
    include_file_sha256: bool = False,
) -> dict[str, Any]:
    root = resolve_shared_embedding_cache_dir() if cache_dir is None else Path(cache_dir).expanduser().resolve()
    resolved_index_path = resolve_index_path(cache_dir=root, index_path=index_path)

    scanned = 0
    skipped_missing_registry = 0
    skipped_incompatible = 0
    errors: list[dict[str, Any]] = []
    entries: list[LegacyIndexEntry] = []

    for path in _iter_npz(root):
        scanned += 1
        try:
            entry = _build_entry(path, include_file_sha256=include_file_sha256)
        except Exception as exc:
            errors.append({"cache_path": str(path), "error": f"{type(exc).__name__}: {exc}"})
            continue
        if entry is None:
            with np.load(path, allow_pickle=True) as payload:
                if "ids" in payload.files and "embeddings" in payload.files:
                    skipped_missing_registry += 1
                else:
                    skipped_incompatible += 1
            continue
        entries.append(entry)

    entries.sort(key=lambda item: item.cache_path)
    resolved_index_path.parent.mkdir(parents=True, exist_ok=True)
    with resolved_index_path.open("w", encoding="utf-8") as handle:
        for entry in entries:
            handle.write(json.dumps(entry.as_dict(), ensure_ascii=True, sort_keys=True))
            handle.write("\n")

    if strict and errors:
        details = "\n".join(f"{item['cache_path']}: {item['error']}" for item in errors[:10])
        raise RuntimeError(f"Failed to build legacy index for {len(errors)} files.\n{details}")

    return {
        "cache_dir": str(root),
        "index_path": str(resolved_index_path),
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "scanned": scanned,
        "entries": len(entries),
        "skipped_missing_registry_key": skipped_missing_registry,
        "skipped_incompatible_format": skipped_incompatible,
        "errors": errors,
    }


def load_legacy_index(
    *,
    cache_dir: str | Path | None = None,
    index_path: str | Path | None = None,
) -> list[dict[str, Any]]:
    resolved_index_path = resolve_index_path(cache_dir=cache_dir, index_path=index_path)
    if not resolved_index_path.exists():
        return []

    records: list[dict[str, Any]] = []
    with resolved_index_path.open("r", encoding="utf-8") as handle:
        for line_no, line in enumerate(handle, start=1):
            text = line.strip()
            if not text:
                continue
            try:
                payload = json.loads(text)
            except json.JSONDecodeError as exc:
                raise ValueError(
                    f"Invalid JSON line in legacy index at {resolved_index_path}:{line_no}: {exc}"
                ) from exc
            if not isinstance(payload, dict):
                continue
            cache_path = payload.get("cache_path")
            if cache_path is None:
                continue
            payload["cache_path"] = str(cache_path)
            records.append(payload)
    records.sort(key=lambda item: str(item.get("cache_path", "")))
    return records


def index_stats(
    *,
    cache_dir: str | Path | None = None,
    index_path: str | Path | None = None,
) -> dict[str, Any]:
    records = load_legacy_index(cache_dir=cache_dir, index_path=index_path)
    by_registry: dict[str, int] = {}
    by_dataset: dict[str, int] = {}
    for record in records:
        registry_key = str(record.get("registry_key", ""))
        dataset_name = str(record.get("dataset_name_hint", ""))
        by_registry[registry_key] = by_registry.get(registry_key, 0) + 1
        by_dataset[dataset_name] = by_dataset.get(dataset_name, 0) + 1
    return {
        "index_path": str(resolve_index_path(cache_dir=cache_dir, index_path=index_path)),
        "entries": len(records),
        "registry_keys": dict(sorted(by_registry.items(), key=lambda item: item[0])),
        "datasets": dict(sorted(by_dataset.items(), key=lambda item: item[0])),
    }
