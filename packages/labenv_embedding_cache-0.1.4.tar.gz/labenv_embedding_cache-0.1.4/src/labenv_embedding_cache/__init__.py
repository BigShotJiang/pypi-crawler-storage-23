"""Shared embedding cache core for cross-project reuse."""

from importlib.metadata import PackageNotFoundError, version as _package_version

from .api import build_cache_metadata, get_or_compute_embeddings
from .compat import ensure_transformers_onnx_config
from .fingerprints import (
    build_dataset_config_hash,
    build_dataset_key,
    build_ids_sha256,
    build_label_manifest_hash,
    build_text_manifest_hash,
)
from .identity import (
    augment_metadata_with_identity,
    apply_identity_defaults,
    build_config_extensions_hash,
    build_identity_hash,
    build_identity_payload,
    has_required_identity_fields,
    load_cache_spec,
    resolve_identity_profile,
)
from .indexing import (
    INDEX_RELATIVE_PATH,
    build_legacy_index,
    index_stats,
    load_legacy_index,
    resolve_index_path,
)
from .paths import (
    build_embedding_cache_filename,
    build_embedding_variant_tag,
    get_embedding_cache_path,
    resolve_embedding_cache_dir,
)
from .resolver import (
    ResolvedCachePath,
    build_request_manifest_entry,
    load_request_manifest,
    read_cache_header,
    resolve_cache_with_index,
    validate_cache_header,
    verify_cache_requests,
)
from .standards import (
    enforce_registry_key_on_cache,
    enforce_rulebook_id_on_cache,
    get_rulebook_id,
    load_embedding_registry,
    load_rulebook,
    resolve_embedding_registry_key,
    resolve_policy_dir,
    resolve_registry_path,
    resolve_rulebook_path,
    resolve_spec_path,
    resolve_shared_cache_layout,
    resolve_shared_cache_tag,
    resolve_shared_embedding_cache_dir,
    validate_embedding_registry,
)
from .store import (
    CACHE_VERSION,
    CacheFile,
    load_embedding_cache,
    load_text_embedding,
    save_embedding_cache,
    save_text_embedding,
)

try:
    __version__ = _package_version("labenv-embedding-cache")
except PackageNotFoundError:
    __version__ = "0+unknown"

__all__ = [
    "CACHE_VERSION",
    "CacheFile",
    "INDEX_RELATIVE_PATH",
    "ResolvedCachePath",
    "__version__",
    "build_cache_metadata",
    "build_config_extensions_hash",
    "build_dataset_config_hash",
    "build_dataset_key",
    "build_ids_sha256",
    "build_identity_hash",
    "build_identity_payload",
    "build_legacy_index",
    "build_embedding_cache_filename",
    "build_embedding_variant_tag",
    "build_label_manifest_hash",
    "build_text_manifest_hash",
    "build_request_manifest_entry",
    "augment_metadata_with_identity",
    "apply_identity_defaults",
    "enforce_registry_key_on_cache",
    "enforce_rulebook_id_on_cache",
    "ensure_transformers_onnx_config",
    "get_embedding_cache_path",
    "get_or_compute_embeddings",
    "get_rulebook_id",
    "load_embedding_cache",
    "load_embedding_registry",
    "load_cache_spec",
    "index_stats",
    "load_legacy_index",
    "load_request_manifest",
    "load_rulebook",
    "load_text_embedding",
    "read_cache_header",
    "validate_cache_header",
    "resolve_cache_with_index",
    "resolve_embedding_cache_dir",
    "resolve_embedding_registry_key",
    "resolve_identity_profile",
    "resolve_index_path",
    "resolve_policy_dir",
    "resolve_registry_path",
    "resolve_rulebook_path",
    "resolve_spec_path",
    "resolve_shared_cache_layout",
    "resolve_shared_cache_tag",
    "resolve_shared_embedding_cache_dir",
    "save_embedding_cache",
    "save_text_embedding",
    "validate_embedding_registry",
    "verify_cache_requests",
    "has_required_identity_fields",
]
