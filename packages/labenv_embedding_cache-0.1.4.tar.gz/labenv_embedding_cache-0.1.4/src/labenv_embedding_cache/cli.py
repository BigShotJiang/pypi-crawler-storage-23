from __future__ import annotations

import argparse
import hashlib
import json
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .indexing import build_legacy_index, index_stats
from .resolver import load_request_manifest, verify_cache_requests
from .standards import (
    resolve_policy_dir,
    resolve_registry_path,
    resolve_rulebook_path,
    resolve_spec_path,
)


def _resolve(target: str) -> str:
    if target == "rulebook":
        return str(resolve_rulebook_path())
    if target == "registry":
        return str(resolve_registry_path())
    if target == "spec":
        return str(resolve_spec_path())
    if target == "policy-dir":
        return str(resolve_policy_dir())
    raise ValueError(f"Unsupported target: {target}")


def path_main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="labenv-embedding-cache-path",
        description="Print resolved policy paths for labenv embedding cache.",
    )
    parser.add_argument(
        "target",
        choices=["rulebook", "registry", "spec", "policy-dir"],
        help="Path target to resolve.",
    )
    parser.add_argument(
        "--shell-export",
        action="store_true",
        help="Print an export statement for EMBEDDING_RULEBOOK_PATH (rulebook only).",
    )
    args = parser.parse_args(argv)

    resolved = _resolve(args.target)
    if args.shell_export:
        if args.target != "rulebook":
            parser.error("--shell-export is only supported for target='rulebook'.")
        print(f"export EMBEDDING_RULEBOOK_PATH={resolved}")
        return 0

    print(resolved)
    return 0


def _write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, ensure_ascii=True, indent=2, sort_keys=True), encoding="utf-8")


def _sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while True:
            chunk = handle.read(1024 * 1024)
            if not chunk:
                break
            digest.update(chunk)
    return digest.hexdigest()


def _policy_digest_payload() -> dict[str, Any]:
    rulebook_path = Path(resolve_rulebook_path()).expanduser().resolve()
    registry_path = Path(resolve_registry_path()).expanduser().resolve()
    spec_path = Path(resolve_spec_path()).expanduser().resolve()
    file_hashes = {
        "rulebook_sha256": _sha256_file(rulebook_path),
        "registry_sha256": _sha256_file(registry_path),
        "spec_sha256": _sha256_file(spec_path),
    }
    bundle_sha256 = hashlib.sha256(
        json.dumps(file_hashes, ensure_ascii=True, sort_keys=True, separators=(",", ":")).encode("utf-8")
    ).hexdigest()
    return {
        "policy_dir": str(resolve_policy_dir()),
        "rulebook_path": str(rulebook_path),
        "registry_path": str(registry_path),
        "spec_path": str(spec_path),
        **file_hashes,
        "bundle_sha256": bundle_sha256,
    }


def _tool_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="labenv-embedding-cache",
        description="CLI for labenv embedding cache indexing and verification.",
    )
    sub = parser.add_subparsers(dest="command", required=True)

    path_parser = sub.add_parser("path", help="Resolve a policy path.")
    path_parser.add_argument(
        "target",
        choices=["rulebook", "registry", "spec", "policy-dir"],
    )
    path_parser.add_argument("--shell-export", action="store_true")

    build_parser = sub.add_parser("index-build", help="Build legacy cache index.")
    build_parser.add_argument("--cache-dir", default=None, help="Embedding cache root directory.")
    build_parser.add_argument("--index-path", default=None, help="Output index JSONL path.")
    build_parser.add_argument("--strict", action="store_true", help="Fail when indexing errors occur.")
    build_parser.add_argument(
        "--file-sha256",
        action="store_true",
        help="Also compute sha256 digest for each cache file (slower).",
    )
    build_parser.add_argument("--output", default=None, help="Optional JSON summary output path.")

    stats_parser = sub.add_parser("index-stats", help="Show legacy index statistics.")
    stats_parser.add_argument("--cache-dir", default=None, help="Embedding cache root directory.")
    stats_parser.add_argument("--index-path", default=None, help="Index JSONL path.")
    stats_parser.add_argument("--output", default=None, help="Optional JSON output path.")

    verify_parser = sub.add_parser("verify-requests", help="Verify cache reuse for request manifest.")
    verify_parser.add_argument("--requests", required=True, help="Request manifest path (.json/.jsonl).")
    verify_parser.add_argument("--cache-dir", default=None, help="Embedding cache root directory.")
    verify_parser.add_argument("--index-path", default=None, help="Index JSONL path.")
    verify_parser.add_argument("--output", default=None, help="Optional JSON report output path.")
    verify_parser.add_argument(
        "--min-selected-models",
        type=int,
        default=0,
        help="Exit code 3 if selected_models count is below this threshold.",
    )

    lock_parser = sub.add_parser(
        "lock-export",
        help="Export lock payload (policy digest + legacy index + optional verify report).",
    )
    lock_parser.add_argument("--requests", default=None, help="Optional request manifest path (.json/.jsonl).")
    lock_parser.add_argument("--cache-dir", default=None, help="Embedding cache root directory.")
    lock_parser.add_argument("--index-path", default=None, help="Index JSONL path.")
    lock_parser.add_argument(
        "--file-sha256",
        action="store_true",
        help="Also compute sha256 digest for each cache file (slower).",
    )
    lock_parser.add_argument("--output", default=None, help="Optional JSON output path.")
    lock_parser.add_argument(
        "--min-selected-models",
        type=int,
        default=0,
        help="Exit code 3 if verify.selected_models count is below this threshold.",
    )

    return parser


def tool_main(argv: list[str] | None = None) -> int:
    parser = _tool_parser()
    args = parser.parse_args(argv)

    if args.command == "path":
        return path_main([args.target] + (["--shell-export"] if args.shell_export else []))

    if args.command == "index-build":
        payload = build_legacy_index(
            cache_dir=args.cache_dir,
            index_path=args.index_path,
            strict=bool(args.strict),
            include_file_sha256=bool(args.file_sha256),
        )
        if args.output:
            _write_json(Path(args.output).expanduser().resolve(), payload)
        print(json.dumps(payload, ensure_ascii=True, indent=2, sort_keys=True))
        return 0

    if args.command == "index-stats":
        payload = index_stats(
            cache_dir=args.cache_dir,
            index_path=args.index_path,
        )
        if args.output:
            _write_json(Path(args.output).expanduser().resolve(), payload)
        print(json.dumps(payload, ensure_ascii=True, indent=2, sort_keys=True))
        return 0

    if args.command == "verify-requests":
        requests = load_request_manifest(args.requests)
        payload = verify_cache_requests(
            requests,
            cache_dir=args.cache_dir,
            index_path=args.index_path,
        )
        if args.output:
            _write_json(Path(args.output).expanduser().resolve(), payload)
        print(json.dumps(payload, ensure_ascii=True, indent=2, sort_keys=True))
        selected_count = len(payload.get("selected_models", []))
        if selected_count < int(args.min_selected_models):
            return 3
        return 0

    if args.command == "lock-export":
        index_payload = build_legacy_index(
            cache_dir=args.cache_dir,
            index_path=args.index_path,
            strict=False,
            include_file_sha256=bool(args.file_sha256),
        )
        verify_payload = None
        if args.requests:
            requests = load_request_manifest(args.requests)
            verify_payload = verify_cache_requests(
                requests,
                cache_dir=args.cache_dir,
                index_path=args.index_path,
            )

        payload: dict[str, Any] = {
            "generated_at_utc": datetime.now(timezone.utc).isoformat(),
            "policy_digest": _policy_digest_payload(),
            "index": index_payload,
            "verify": verify_payload,
        }
        if args.output:
            _write_json(Path(args.output).expanduser().resolve(), payload)
        print(json.dumps(payload, ensure_ascii=True, indent=2, sort_keys=True))

        if verify_payload is not None:
            selected_count = len(verify_payload.get("selected_models", []))
            if selected_count < int(args.min_selected_models):
                return 3
        return 0

    raise AssertionError(f"Unhandled command: {args.command}")


def main(argv: list[str] | None = None) -> int:
    return path_main(argv)


if __name__ == "__main__":  # pragma: no cover
    sys.exit(tool_main())
