from __future__ import annotations

from functools import lru_cache
from typing import Any, Mapping

from omegaconf import OmegaConf

from .fingerprints import sha256_json
from .standards import resolve_spec_path


_DEFAULT_IDENTITY_SPEC: dict[str, Any] = {
    "identity": {
        "default_profile": "default",
        "profiles": {
            "default": {
                "version": 1,
                "hard_fields": [
                    "dataset_key",
                    "dataset_config_hash",
                    "text_manifest_hash",
                    "label_manifest_hash",
                    "ids_sha256",
                    "dataset_shuffle",
                    "dataset_shuffle_seed",
                    "embedding_seed",
                    "variant_tag",
                    "rulebook_id",
                    "registry_key",
                    "embedding_type",
                    "pooling",
                    "hidden_state_layer",
                    "cache_all_layers",
                    "torch_dtype",
                    "tokenizer_id",
                ],
                "soft_fields": [
                    "text_preprocess_id",
                    "library_versions",
                    "embedding_l2_normalized",
                ],
                "defaults": {
                    "dataset_shuffle": False,
                    "dataset_shuffle_seed": None,
                    "embedding_seed": None,
                    "pooling": None,
                    "hidden_state_layer": None,
                    "cache_all_layers": False,
                    "torch_dtype": None,
                    "tokenizer_id": None,
                },
                "legacy_match_policy": {
                    "allow_missing_identity_hash": True,
                    "allow_missing_soft_fields": True,
                    "prefer_identity_hash": True,
                },
            }
        },
    }
}

_INTERNAL_IDENTITY_FIELDS = frozenset(
    {
        "identity_profile_id",
        "identity_version",
        "identity_hash",
        "config_extensions_hash",
    }
)


def _normalize_string_list(values: Any) -> list[str]:
    if not isinstance(values, list):
        return []
    out: list[str] = []
    for value in values:
        text = str(value).strip()
        if not text:
            continue
        if text in out:
            continue
        out.append(text)
    return out


def _to_mapping(value: Any) -> dict[str, Any]:
    if isinstance(value, Mapping):
        return dict(value)
    return {}


@lru_cache(maxsize=1)
def load_cache_spec() -> dict[str, Any]:
    merged = OmegaConf.create(_DEFAULT_IDENTITY_SPEC)
    path = resolve_spec_path()
    if path.exists():
        loaded = OmegaConf.load(path)
        merged = OmegaConf.merge(merged, loaded)
    resolved = OmegaConf.to_container(merged, resolve=True)
    return dict(resolved) if isinstance(resolved, Mapping) else dict(_DEFAULT_IDENTITY_SPEC)


def resolve_identity_profile(
    profile_id: str | None = None,
    *,
    spec: Mapping[str, Any] | None = None,
) -> tuple[str, dict[str, Any]]:
    resolved_spec = dict(spec) if isinstance(spec, Mapping) else load_cache_spec()
    identity_cfg = _to_mapping(resolved_spec.get("identity"))
    profiles = _to_mapping(identity_cfg.get("profiles"))
    default_profile_id = str(identity_cfg.get("default_profile", "default")).strip() or "default"

    selected_profile_id = str(profile_id or default_profile_id).strip() or default_profile_id
    profile = _to_mapping(profiles.get(selected_profile_id))
    if not profile:
        selected_profile_id = "default"
        profile = _to_mapping(_to_mapping(_DEFAULT_IDENTITY_SPEC["identity"]).get("profiles", {}).get("default"))

    hard_fields = _normalize_string_list(profile.get("hard_fields"))
    if not hard_fields:
        hard_fields = list(
            _to_mapping(_to_mapping(_DEFAULT_IDENTITY_SPEC["identity"]).get("profiles", {}).get("default")).get(
                "hard_fields",
                [],
            )
        )

    soft_fields = _normalize_string_list(profile.get("soft_fields"))
    defaults = _to_mapping(profile.get("defaults"))
    legacy_match_policy = _to_mapping(profile.get("legacy_match_policy"))
    version = int(profile.get("version", 1))

    normalized_profile = {
        "version": version,
        "hard_fields": hard_fields,
        "soft_fields": soft_fields,
        "defaults": defaults,
        "legacy_match_policy": legacy_match_policy,
    }
    return selected_profile_id, normalized_profile


def apply_identity_defaults(
    metadata: Mapping[str, Any],
    *,
    profile: Mapping[str, Any],
) -> dict[str, Any]:
    out = dict(metadata)
    defaults = _to_mapping(profile.get("defaults"))
    for key, value in defaults.items():
        if key not in out or out.get(key) is None:
            out[key] = value
    return out


def build_identity_payload(
    metadata: Mapping[str, Any],
    *,
    profile: Mapping[str, Any],
) -> dict[str, Any]:
    enriched = apply_identity_defaults(metadata, profile=profile)
    payload: dict[str, Any] = {}
    for field in _normalize_string_list(profile.get("hard_fields")):
        payload[field] = enriched.get(field)
    return payload


def build_identity_hash(
    metadata: Mapping[str, Any],
    *,
    profile: Mapping[str, Any],
) -> str:
    payload = build_identity_payload(metadata, profile=profile)
    return sha256_json(payload)


def build_config_extensions_hash(
    metadata: Mapping[str, Any],
    *,
    profile: Mapping[str, Any],
) -> str:
    enriched = apply_identity_defaults(metadata, profile=profile)
    hard_fields = set(_normalize_string_list(profile.get("hard_fields")))
    soft_fields = set(_normalize_string_list(profile.get("soft_fields")))
    known_fields = hard_fields | soft_fields | set(_INTERNAL_IDENTITY_FIELDS)
    extension_payload = {
        str(key): value
        for key, value in sorted(enriched.items(), key=lambda item: str(item[0]))
        if str(key) not in known_fields
    }
    return sha256_json(extension_payload)


def has_required_identity_fields(
    metadata: Mapping[str, Any],
    *,
    profile: Mapping[str, Any],
) -> bool:
    enriched = apply_identity_defaults(metadata, profile=profile)
    for field in _normalize_string_list(profile.get("hard_fields")):
        if field not in enriched:
            return False
    return True


def augment_metadata_with_identity(
    metadata: Mapping[str, Any],
    *,
    profile_id: str | None = None,
    spec: Mapping[str, Any] | None = None,
    allow_partial: bool = False,
) -> dict[str, Any]:
    selected_profile_id, profile = resolve_identity_profile(profile_id, spec=spec)
    enriched = apply_identity_defaults(metadata, profile=profile)
    enriched["identity_profile_id"] = selected_profile_id
    enriched["identity_version"] = int(profile.get("version", 1))
    if allow_partial or has_required_identity_fields(enriched, profile=profile):
        enriched["identity_hash"] = build_identity_hash(enriched, profile=profile)
        enriched["config_extensions_hash"] = build_config_extensions_hash(enriched, profile=profile)
    else:
        enriched.pop("identity_hash", None)
        enriched.pop("config_extensions_hash", None)
    return enriched
