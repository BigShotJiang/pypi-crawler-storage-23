from dataclasses import dataclass
from typing import Any, Callable, Mapping, Optional, Sequence

import numpy as np

from .fingerprints import (
    build_dataset_config_hash,
    build_dataset_key,
    build_ids_sha256,
    build_label_manifest_hash,
    build_text_manifest_hash,
)
from .identity import augment_metadata_with_identity
from .paths import build_embedding_variant_tag, get_embedding_cache_path
from .resolver import resolve_cache_with_index
from .standards import (
    enforce_registry_key_on_cache,
    enforce_rulebook_id_on_cache,
    get_rulebook_id,
    resolve_embedding_registry_key,
    resolve_shared_cache_tag,
)
from .store import CacheFile, load_embedding_cache, save_text_embedding


@dataclass
class CacheResolution:
    cache_path: str
    was_cache_hit: bool
    metadata: dict[str, Any]


def _cfg_get(source: Any, path: str, default: Any = None) -> Any:
    current = source
    for part in path.split("."):
        if isinstance(current, Mapping):
            if part not in current:
                return default
            current = current[part]
        else:
            if not hasattr(current, part):
                return default
            current = getattr(current, part)
    return current


def _normalize_pooling(value: Optional[str]) -> str:
    if value is None:
        return "mean"
    normalized = str(value).strip().lower()
    if normalized in {"mean", "masked_mean", "avg", "average"}:
        return "mean"
    if normalized in {"cls", "cls_token"}:
        return "cls"
    return normalized


def _is_embedding_l2_normalized(embedding_cfg: Any) -> bool:
    for key in ("normalize_embeddings", "normalize", "l2_normalize"):
        raw = _cfg_get(embedding_cfg, key, None)
        if raw is None:
            continue
        if isinstance(raw, bool):
            return raw
        text = str(raw).strip().lower()
        if text in {"1", "true", "yes", "y", "t", "on"}:
            return True
        if text in {"0", "false", "no", "n", "f", "off", ""}:
            return False
        return bool(raw)
    return False


def _resolve_dataset_shuffle_seed(cfg: Any) -> Optional[int]:
    seed = _cfg_get(cfg, "dataset.shuffle_seed", None)
    if seed is None:
        seed = _cfg_get(cfg, "evaluation.random_state", None)
    return None if seed is None else int(seed)


def _resolve_tokenizer_id(embedding_cfg: Any) -> str | None:
    candidates = [
        _cfg_get(embedding_cfg, "tokenizer_name", None),
        _cfg_get(embedding_cfg, "tokenizer_model_name", None),
        _cfg_get(embedding_cfg, "tokenizer.model_name", None),
        _cfg_get(embedding_cfg, "tokenizer.name", None),
        _cfg_get(embedding_cfg, "tokenizer.id", None),
        _cfg_get(embedding_cfg, "tokenizer", None),
    ]
    for candidate in candidates:
        if candidate is None or isinstance(candidate, Mapping):
            continue
        text = str(candidate).strip()
        if text:
            return text
    return None


def _select_cached_embeddings(cache: CacheFile, ids: Sequence[Any], hidden_state_layer: Any) -> np.ndarray:
    id_to_index = {str(i): idx for idx, i in enumerate(cache.ids)}
    selection_indices = np.asarray([id_to_index[str(i)] for i in ids], dtype=int)

    if cache.layer_embeddings is not None:
        requested_layer = -1 if hidden_state_layer is None else int(hidden_state_layer)
        layer_count = cache.layer_embeddings.shape[1]
        if requested_layer < 0:
            target_layer = layer_count + requested_layer
        else:
            target_layer = requested_layer
        if target_layer < 0 or target_layer >= layer_count:
            raise ValueError(
                f"Requested hidden_state_layer={requested_layer} is out of range for cached layer count={layer_count}."
            )
        return cache.layer_embeddings[selection_indices, target_layer, :]

    return np.asarray(cache.embeddings)[selection_indices]


def _validate_cache(cache: CacheFile, *, metadata: Mapping[str, Any], cfg: Any) -> str | None:
    requested_type = _cfg_get(cfg, "embedding.type", None)
    if cache.embedding_type is not None and requested_type != cache.embedding_type:
        return (
            "Cached embeddings type mismatch "
            f"(cached={cache.embedding_type}, requested={requested_type})."
        )

    if requested_type == "hf_transformer":
        requested_pooling = _normalize_pooling(_cfg_get(cfg, "embedding.pooling", None))
        cached_pooling = _normalize_pooling(cache.pooling)
        if requested_pooling != cached_pooling:
            return (
                "Cached embeddings pooling mismatch "
                f"(cached={cached_pooling}, requested={requested_pooling})."
            )

    requested_tokenizer_id = metadata.get("tokenizer_id")
    if requested_tokenizer_id is not None:
        cached_tokenizer_id = cache.metadata.get("tokenizer_id")
        if cached_tokenizer_id != requested_tokenizer_id:
            return (
                "Cached embeddings tokenizer mismatch "
                f"(cached={cached_tokenizer_id}, requested={requested_tokenizer_id})."
            )

    if enforce_rulebook_id_on_cache():
        current_rulebook_id = get_rulebook_id()
        if cache.rulebook_id != current_rulebook_id:
            return (
                "Cached embeddings rulebook_id mismatch "
                f"(cached={cache.rulebook_id}, current={current_rulebook_id})."
            )

    if enforce_registry_key_on_cache():
        current_registry_key = resolve_embedding_registry_key(
            _cfg_get(cfg, "embedding", {}),
            strict=False,
        )
        if current_registry_key is not None and cache.registry_key != current_registry_key:
            return (
                "Cached embeddings registry_key mismatch "
                f"(cached={cache.registry_key}, current={current_registry_key})."
            )

    cached_dataset_key = cache.metadata.get("dataset_key")
    expected_dataset_key = metadata.get("dataset_key")
    if cached_dataset_key and expected_dataset_key and cached_dataset_key != expected_dataset_key:
        return (
            "Cached embeddings dataset_key mismatch "
            f"(cached={cached_dataset_key}, expected={expected_dataset_key})."
        )

    return None


def build_cache_metadata(
    cfg: Any,
    ids: Sequence[Any],
    texts: Sequence[str],
    *,
    labels: Sequence[Any] | None = None,
    embedding_seed: int | None = None,
    text_preprocess_id: str | None = None,
    extra_metadata: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    embedding_cfg = _cfg_get(cfg, "embedding", {})
    dataset_config_hash = build_dataset_config_hash(
        cfg,
        text_preprocess_id=text_preprocess_id,
    )
    text_manifest_hash = build_text_manifest_hash(ids, texts)
    label_manifest_hash = build_label_manifest_hash(ids, labels)
    dataset_key = build_dataset_key(
        dataset_config_hash=dataset_config_hash,
        text_manifest_hash=text_manifest_hash,
        label_manifest_hash=label_manifest_hash,
    )

    if embedding_seed is None:
        seed_candidate = _cfg_get(cfg, "embedding.embedding_seed", None)
        if seed_candidate is None:
            seed_candidate = _cfg_get(cfg, "reproducibility.seed", None)
        embedding_seed = None if seed_candidate is None else int(seed_candidate)

    variant_tag = resolve_shared_cache_tag(cfg)
    if variant_tag is None:
        variant_tag = build_embedding_variant_tag(
            embedding_cfg,
            embedding_seed=embedding_seed,
        )

    metadata: dict[str, Any] = {
        "dataset_key": dataset_key,
        "dataset_config_hash": dataset_config_hash,
        "text_manifest_hash": text_manifest_hash,
        "label_manifest_hash": label_manifest_hash,
        "ids_sha256": build_ids_sha256(ids),
        "dataset_shuffle": bool(_cfg_get(cfg, "dataset.shuffle", False)),
        "dataset_shuffle_seed": _resolve_dataset_shuffle_seed(cfg),
        "embedding_seed": embedding_seed,
        "variant_tag": variant_tag,
        "embedding_type": _cfg_get(cfg, "embedding.type", None),
        "pooling": _cfg_get(cfg, "embedding.pooling", None),
        "hidden_state_layer": _cfg_get(cfg, "embedding.hidden_state_layer", None),
        "cache_all_layers": bool(_cfg_get(cfg, "embedding.cache_all_layers", False)),
        "torch_dtype": _cfg_get(cfg, "embedding.torch_dtype", None),
        "tokenizer_id": _resolve_tokenizer_id(embedding_cfg),
        "embedding_l2_normalized": _is_embedding_l2_normalized(
            embedding_cfg
        ),
        "rulebook_id": get_rulebook_id(),
        "registry_key": resolve_embedding_registry_key(
            _cfg_get(cfg, "embedding", {}),
            strict=False,
        ),
    }

    if text_preprocess_id is not None:
        metadata["text_preprocess_id"] = str(text_preprocess_id)
    if extra_metadata:
        metadata.update(dict(extra_metadata))

    return augment_metadata_with_identity(metadata)


def get_or_compute_embeddings(
    cfg: Any,
    texts: Sequence[str],
    ids: Sequence[Any],
    *,
    compute_embeddings: Callable[[Sequence[str], Any], np.ndarray],
    labels: Sequence[Any] | None = None,
    require_cache: bool = False,
    embedding_seed: int | None = None,
    text_preprocess_id: str | None = None,
    extra_metadata: Mapping[str, Any] | None = None,
    load_layer_embeddings: bool = True,
) -> tuple[np.ndarray, CacheResolution]:
    metadata = build_cache_metadata(
        cfg,
        ids,
        texts,
        labels=labels,
        embedding_seed=embedding_seed,
        text_preprocess_id=text_preprocess_id,
        extra_metadata=extra_metadata,
    )

    cache_path = get_embedding_cache_path(
        cfg,
        dataset_key=str(metadata["dataset_key"]),
        variant_tag=str(metadata["variant_tag"]),
    )

    cache = load_embedding_cache(cache_path, load_layer_embeddings=load_layer_embeddings)
    if cache is not None:
        error = _validate_cache(cache, metadata=metadata, cfg=cfg)
        if error is None:
            try:
                selected = _select_cached_embeddings(
                    cache,
                    ids,
                    hidden_state_layer=_cfg_get(cfg, "embedding.hidden_state_layer", None),
                )
                return selected, CacheResolution(
                    cache_path=str(cache_path),
                    was_cache_hit=True,
                    metadata=dict(metadata),
                )
            except KeyError:
                if require_cache:
                    raise KeyError("Cached embeddings are missing required ids.")
            except ValueError as exc:
                if require_cache:
                    raise ValueError(str(exc))
        elif require_cache:
            raise ValueError(error)
    else:
        resolved = resolve_cache_with_index(
            cache_path,
            expected_metadata=metadata,
            dataset_name=str(_cfg_get(cfg, "dataset.name", "") or ""),
        )
        if resolved is not None and resolved.path != cache_path:
            cache = load_embedding_cache(
                resolved.path,
                load_layer_embeddings=load_layer_embeddings,
            )
            if cache is not None:
                error = _validate_cache(cache, metadata=metadata, cfg=cfg)
                if error is None:
                    try:
                        selected = _select_cached_embeddings(
                            cache,
                            ids,
                            hidden_state_layer=_cfg_get(cfg, "embedding.hidden_state_layer", None),
                        )
                        merged_metadata = dict(metadata)
                        merged_metadata.update(resolved.metadata)
                        return selected, CacheResolution(
                            cache_path=str(resolved.path),
                            was_cache_hit=True,
                            metadata=merged_metadata,
                        )
                    except KeyError:
                        if require_cache:
                            raise KeyError("Cached embeddings are missing required ids.")
                    except ValueError as exc:
                        if require_cache:
                            raise ValueError(str(exc))
                elif require_cache:
                    raise ValueError(error)

    if require_cache:
        raise FileNotFoundError(f"Required cache not available at {cache_path}.")

    vectors = np.asarray(compute_embeddings(texts, cfg))
    save_text_embedding(
        ids,
        vectors,
        metadata.get("dataset_shuffle_seed"),
        cache_path,
        hidden_state_layer=_cfg_get(cfg, "embedding.hidden_state_layer", None),
        embedding_type=_cfg_get(cfg, "embedding.type", None),
        pooling=_cfg_get(cfg, "embedding.pooling", None),
        rulebook_id=metadata.get("rulebook_id"),
        registry_key=metadata.get("registry_key"),
        metadata=metadata,
    )

    return vectors, CacheResolution(
        cache_path=str(cache_path),
        was_cache_hit=False,
        metadata=dict(metadata),
    )
