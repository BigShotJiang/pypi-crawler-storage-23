import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Mapping, Optional

import numpy as np

from .fingerprints import canonical_json_dumps

CACHE_VERSION = 3


@dataclass
class CacheFile:
    ids: np.ndarray
    embeddings: np.ndarray
    shuffle_seed: Optional[int]
    layer_embeddings: Optional[np.ndarray]
    hidden_state_layer: Optional[int]
    embedding_type: Optional[str]
    pooling: Optional[str]
    rulebook_id: Optional[str]
    registry_key: Optional[str]
    metadata: dict[str, Any] = field(default_factory=dict)


def _to_optional_int(value: Any) -> Optional[int]:
    if value is None:
        return None
    if isinstance(value, np.ndarray):
        if value.shape == ():
            item = value.item()
            if item is None:
                return None
            return int(item)
        raise ValueError("Expected scalar ndarray for integer metadata.")
    return int(value)


def _to_optional_str(value: Any) -> Optional[str]:
    if value is None:
        return None
    if isinstance(value, np.ndarray):
        if value.shape == ():
            item = value.item()
            if item is None:
                return None
            return str(item)
        raise ValueError("Expected scalar ndarray for string metadata.")
    text = str(value)
    return text


def _load_metadata_json(data: Any) -> dict[str, Any]:
    if data is None:
        return {}
    try:
        if isinstance(data, np.ndarray):
            raw = data.item()
        else:
            raw = data
        if raw is None:
            return {}
        text = str(raw)
        loaded = json.loads(text)
        if isinstance(loaded, dict):
            return loaded
    except Exception:
        return {}
    return {}


def save_embedding_cache(
    cache: CacheFile,
    path: Path,
    *,
    extra_metadata: Mapping[str, Any] | None = None,
) -> None:
    metadata = dict(cache.metadata)
    if extra_metadata:
        metadata.update(extra_metadata)

    save_kwargs: dict[str, Any] = {
        "ids": cache.ids,
        "embeddings": cache.embeddings,
        "shuffle_seed": cache.shuffle_seed,
        "cache_version": CACHE_VERSION,
    }
    if cache.embedding_type is not None:
        save_kwargs["embedding_type"] = str(cache.embedding_type)
    if cache.pooling is not None:
        save_kwargs["pooling"] = str(cache.pooling)
    if cache.rulebook_id is not None:
        save_kwargs["rulebook_id"] = str(cache.rulebook_id)
    if cache.registry_key is not None:
        save_kwargs["registry_key"] = str(cache.registry_key)
    if cache.hidden_state_layer is not None:
        save_kwargs["hidden_state_layer"] = int(cache.hidden_state_layer)
    if cache.layer_embeddings is not None:
        save_kwargs["layer_embeddings"] = cache.layer_embeddings
    if metadata:
        save_kwargs["metadata_json"] = canonical_json_dumps(metadata)

    path.parent.mkdir(parents=True, exist_ok=True)
    np.savez(path, **save_kwargs)


def load_embedding_cache(path: Path, *, load_layer_embeddings: bool = True) -> Optional[CacheFile]:
    if not path.exists():
        return None

    data = np.load(path, allow_pickle=True)
    layer_embeddings = None
    if load_layer_embeddings and "layer_embeddings" in data.files:
        layer_embeddings = data["layer_embeddings"]

    metadata = _load_metadata_json(data["metadata_json"]) if "metadata_json" in data.files else {}
    if "shuffle_seed" not in metadata and "shuffle_seed" in data.files:
        metadata["shuffle_seed"] = _to_optional_int(data["shuffle_seed"])

    return CacheFile(
        ids=data["ids"],
        embeddings=data["embeddings"],
        shuffle_seed=_to_optional_int(data["shuffle_seed"]) if "shuffle_seed" in data.files else None,
        layer_embeddings=layer_embeddings,
        hidden_state_layer=_to_optional_int(data["hidden_state_layer"]) if "hidden_state_layer" in data.files else None,
        embedding_type=_to_optional_str(data["embedding_type"]) if "embedding_type" in data.files else None,
        pooling=_to_optional_str(data["pooling"]) if "pooling" in data.files else None,
        rulebook_id=_to_optional_str(data["rulebook_id"]) if "rulebook_id" in data.files else None,
        registry_key=_to_optional_str(data["registry_key"]) if "registry_key" in data.files else None,
        metadata=metadata,
    )


def save_text_embedding(
    ids,
    embeddings,
    shuffle_seed,
    path: Path,
    layer_embeddings=None,
    *,
    hidden_state_layer: int | None = None,
    embedding_type: str | None = None,
    pooling: str | None = None,
    rulebook_id: str | None = None,
    registry_key: str | None = None,
    metadata: Mapping[str, Any] | None = None,
):
    cache = CacheFile(
        ids=np.asarray(ids),
        embeddings=np.asarray(embeddings),
        shuffle_seed=shuffle_seed,
        layer_embeddings=np.asarray(layer_embeddings) if layer_embeddings is not None else None,
        hidden_state_layer=hidden_state_layer,
        embedding_type=embedding_type,
        pooling=pooling,
        rulebook_id=rulebook_id,
        registry_key=registry_key,
        metadata=dict(metadata or {}),
    )
    save_embedding_cache(cache, path)


def load_text_embedding(path: Path, *, load_layer_embeddings: bool = True):
    cache = load_embedding_cache(path, load_layer_embeddings=load_layer_embeddings)
    if cache is None:
        return None
    return (
        cache.ids,
        cache.embeddings,
        cache.shuffle_seed,
        cache.layer_embeddings,
        cache.hidden_state_layer,
        cache.embedding_type,
        cache.pooling,
        cache.rulebook_id,
        cache.registry_key,
    )
