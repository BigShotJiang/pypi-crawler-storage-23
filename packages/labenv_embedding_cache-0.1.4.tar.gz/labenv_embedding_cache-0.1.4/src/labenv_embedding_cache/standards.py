import os
from functools import lru_cache
from pathlib import Path
from typing import Any, Dict, Mapping, Optional

from omegaconf import OmegaConf


_DEFAULT_RULEBOOK: Dict[str, Any] = {
    "schema_version": 1,
    "identity": {
        "name": "shared_lm_embedding_cache",
        "version": 1,
    },
    "cache": {
        "base_dir": "/home/ryua/data/embedding_cache",
        "must_be_outside_project": True,
        "layout": "hierarchical",
        "include_shuffle_seed_in_filename": True,
        "env": {
            "base_dir": [
                "EMBEDDING_CACHE_DIR",
                "TEXT_EMBEDDING_CACHE_DIR",
            ],
            "layout": [
                "EMBEDDING_CACHE_LAYOUT",
                "TEXT_EMBEDDING_CACHE_LAYOUT",
            ],
            "tag": [
                "EMBEDDING_CACHE_TAG",
                "TEXT_EMBEDDING_CACHE_TAG",
            ],
        },
    },
    "registry": {
        "path": "embedding_registry.yaml",
        "enforce_match": True,
    },
    "consistency": {
        "enforce_rulebook_id": True,
        "enforce_registry_key": True,
    },
    "compatibility": {
        "legacy_index": {
            "enabled": True,
            "sunset_date": None,
            "require_ids_sha256_match": True,
            "require_variant_tag_match": True,
        }
    },
}


def _cfg_get(source: Any, path: str, default: Any = None) -> Any:
    current = source
    for part in path.split("."):
        if isinstance(current, Mapping):
            if part not in current:
                return default
            current = current[part]
        else:
            if not hasattr(current, part):
                return default
            current = getattr(current, part)
    return current


def _first_env(names: list[str]) -> Optional[str]:
    for name in names:
        raw = os.getenv(name)
        if raw is None:
            continue
        value = raw.strip()
        if value:
            return value
    return None


def _to_string_list(raw: Any) -> list[str]:
    if raw is None:
        return []
    if isinstance(raw, str):
        value = raw.strip()
        return [value] if value else []
    if isinstance(raw, (list, tuple)):
        result: list[str] = []
        for item in raw:
            text = str(item).strip()
            if text:
                result.append(text)
        return result
    text = str(raw).strip()
    return [text] if text else []


def _to_bool(value: Any, *, default: bool = False) -> bool:
    if value is None:
        return default
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        return bool(value)
    text = str(value).strip().lower()
    if text in {"1", "true", "yes", "y", "t", "on"}:
        return True
    if text in {"0", "false", "no", "n", "f", "off", ""}:
        return False
    return bool(value)


def _is_l2_normalized_embedding_cfg(embedding_cfg: Any) -> bool:
    for key in ("normalize_embeddings", "normalize", "l2_normalize"):
        raw = _cfg_get(embedding_cfg, key, None)
        if raw is not None:
            return _to_bool(raw)
    return False


def _is_l2_normalized_registry_entry(entry: Mapping[str, Any]) -> bool:
    for key in ("normalize_embeddings", "normalize", "l2_normalize"):
        raw = entry.get(key, None)
        if raw is not None:
            return _to_bool(raw)
    return False


def _repo_root() -> Path:
    return Path(__file__).resolve().parents[2]


def _package_root() -> Path:
    return Path(__file__).resolve().parent


def resolve_policy_dir() -> Path:
    env_dir = os.getenv("EMBEDDING_CACHE_POLICY_DIR")
    if env_dir is not None and env_dir.strip():
        return Path(env_dir.strip()).expanduser().resolve()

    packaged = (_package_root() / "policy").resolve()
    if packaged.exists():
        return packaged

    return _repo_root().resolve()


def resolve_rulebook_path() -> Path:
    env_path = os.getenv("EMBEDDING_RULEBOOK_PATH")
    if env_path is not None and env_path.strip():
        return Path(env_path.strip()).expanduser().resolve()

    policy_rulebook = resolve_policy_dir() / "embedding_rulebook.yaml"
    if policy_rulebook.exists():
        return policy_rulebook.resolve()

    return (_repo_root() / "embedding_rulebook.yaml").resolve()


@lru_cache(maxsize=1)
def load_rulebook() -> Dict[str, Any]:
    rulebook_path = resolve_rulebook_path()
    merged = OmegaConf.create(_DEFAULT_RULEBOOK)
    if rulebook_path.exists():
        loaded = OmegaConf.load(rulebook_path)
        merged = OmegaConf.merge(merged, loaded)
    return OmegaConf.to_container(merged, resolve=True)


def get_rulebook_id() -> str:
    rulebook = load_rulebook()
    identity = rulebook.get("identity", {})
    name = str(identity.get("name", "shared_lm_embedding_cache"))
    version = str(identity.get("version", "1"))
    return f"{name}:v{version}"


def resolve_registry_path() -> Path:
    rulebook = load_rulebook()
    registry_cfg = rulebook.get("registry", {})
    configured = str(registry_cfg.get("path", "embedding_registry.yaml"))
    candidate = Path(configured).expanduser()
    if candidate.is_absolute():
        return candidate.resolve()

    from_rulebook_parent = (resolve_rulebook_path().parent / candidate).resolve()
    if from_rulebook_parent.exists():
        return from_rulebook_parent

    return (resolve_policy_dir() / candidate).resolve()


def resolve_spec_path() -> Path:
    candidate = (resolve_policy_dir() / "embedding_cache_spec.yaml").resolve()
    if candidate.exists():
        return candidate
    return (_repo_root() / "embedding_cache_spec.yaml").resolve()


@lru_cache(maxsize=1)
def load_embedding_registry() -> Dict[str, Any]:
    registry_path = resolve_registry_path()
    if not registry_path.exists():
        raise FileNotFoundError(
            f"Embedding registry file not found at '{registry_path}'. "
            "Update the rulebook registry.path or create the registry file."
        )
    loaded = OmegaConf.load(registry_path)
    registry = OmegaConf.to_container(loaded, resolve=True)
    models = registry.get("models", {})
    if not isinstance(models, dict):
        raise ValueError(
            f"Embedding registry at '{registry_path}' must contain a 'models' mapping."
        )
    return registry


def resolve_embedding_registry_key(embedding_cfg: Any, *, strict: bool = True) -> Optional[str]:
    embedding_type = str(_cfg_get(embedding_cfg, "type", "") or "")
    model_name = _cfg_get(embedding_cfg, "model_name", None)
    model_name_text = None if model_name is None else str(model_name)
    name_text = str(_cfg_get(embedding_cfg, "name", "") or "")
    requested_l2 = _is_l2_normalized_embedding_cfg(embedding_cfg)

    registry = load_embedding_registry()
    models = registry.get("models", {})
    exact_candidates: list[str] = []
    base_candidates: list[tuple[str, bool]] = []
    for key, entry in models.items():
        if not isinstance(entry, dict):
            continue
        if str(entry.get("type", "")) != embedding_type:
            continue
        entry_model_name = entry.get("model_name", None)
        entry_model_name_text = None if entry_model_name is None else str(entry_model_name)
        if entry_model_name_text == model_name_text:
            entry_l2 = _is_l2_normalized_registry_entry(entry)
            key_text = str(key)
            base_candidates.append((key_text, entry_l2))
            if entry_l2 == requested_l2:
                exact_candidates.append(key_text)

    if len(exact_candidates) == 1:
        return exact_candidates[0]
    if len(exact_candidates) > 1:
        raise ValueError(
            "Embedding registry has multiple matches for "
            f"type='{embedding_type}', model_name='{model_name_text}', normalize_embeddings={requested_l2}: "
            f"{exact_candidates}."
        )

    if requested_l2 and len(base_candidates) == 1:
        base_key, _base_l2 = base_candidates[0]
        if base_key.endswith("__l2"):
            return base_key
        return f"{base_key}__l2"

    if not strict:
        return None

    if base_candidates:
        available = ", ".join(
            f"{key}(normalize_embeddings={entry_l2})" for key, entry_l2 in base_candidates
        )
        raise ValueError(
            "Embedding config normalization mismatch: "
            f"type='{embedding_type}', model_name='{model_name_text}', "
            f"normalize_embeddings={requested_l2}, available=[{available}]."
        )

    raise ValueError(
        "Embedding config not registered: "
        f"type='{embedding_type}', model_name='{model_name_text}', "
        f"normalize_embeddings={requested_l2}, name='{name_text}'. "
        f"Add an entry to '{resolve_registry_path()}'."
    )


def validate_embedding_registry(embedding_cfg: Any) -> Optional[str]:
    rulebook = load_rulebook()
    enforce_match = bool(rulebook.get("registry", {}).get("enforce_match", True))
    return resolve_embedding_registry_key(embedding_cfg, strict=enforce_match)


def enforce_rulebook_id_on_cache() -> bool:
    return bool(load_rulebook().get("consistency", {}).get("enforce_rulebook_id", True))


def enforce_registry_key_on_cache() -> bool:
    return bool(load_rulebook().get("consistency", {}).get("enforce_registry_key", True))


def resolve_shared_embedding_cache_dir(cfg: Any | None = None) -> Path:
    del cfg
    rulebook = load_rulebook()
    cache_cfg = rulebook.get("cache", {})
    env_names = _to_string_list(cache_cfg.get("env", {}).get("base_dir"))
    env_value = _first_env(env_names)
    configured = (
        env_value
        if env_value is not None
        else str(cache_cfg.get("base_dir", "/home/ryua/data/embedding_cache"))
    )
    base_dir = Path(configured).expanduser()
    if not base_dir.is_absolute():
        base_dir = (Path.home() / base_dir).resolve()

    if bool(cache_cfg.get("must_be_outside_project", True)):
        project_root = _repo_root().resolve()
        try:
            base_dir.resolve().relative_to(project_root)
            raise ValueError(
                f"Embedding cache directory '{base_dir}' must be outside project root '{project_root}'."
            )
        except ValueError as exc:
            if str(exc).startswith("Embedding cache directory"):
                raise
    return base_dir.resolve()


def resolve_shared_cache_layout() -> str:
    rulebook = load_rulebook()
    cache_cfg = rulebook.get("cache", {})
    env_names = _to_string_list(cache_cfg.get("env", {}).get("layout"))
    env_value = _first_env(env_names)
    raw = (env_value or str(cache_cfg.get("layout", "hierarchical"))).strip().lower()
    return raw if raw in {"flat", "hierarchical"} else "hierarchical"


def resolve_shared_cache_tag(cfg: Any | None = None) -> Optional[str]:
    rulebook = load_rulebook()
    cache_cfg = rulebook.get("cache", {})
    env_names = _to_string_list(cache_cfg.get("env", {}).get("tag"))
    env_value = _first_env(env_names)
    if env_value is not None:
        return env_value
    if cfg is None:
        return None

    tag = _cfg_get(cfg, "paths.embedding_cache_tag", None)
    if tag is None:
        tag = _cfg_get(cfg, "embedding.cache_tag", None)
    if tag is None:
        return None

    text = str(tag).strip()
    return text or None


def include_shuffle_seed_in_filename() -> bool:
    rulebook = load_rulebook()
    return bool(rulebook.get("cache", {}).get("include_shuffle_seed_in_filename", True))
