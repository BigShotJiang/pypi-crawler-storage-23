# cubio
A fully typed and pydantic-compatible framework for reading and writing geospatial data cubes.
