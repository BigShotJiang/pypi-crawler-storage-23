### **Demos**
[simple](https://monitorat.brege.org)
· [advanced](https://monitorat.brege.org/advanced)
· [layout](https://monitorat.brege.org/layout)
· [federation](https://monitorat.brege.org/federation)

### **Repositories**
[github.com/brege/monitorat](https://github.com/brege/monitorat)
· [pypi.org/project/monitorat](https://pypi.org/project/monitorat)

### **About**
[brege.org](https://brege.org)
· [monitorat.brege.org](https://monitorat.brege.org)
· [github.com/brege](https://github.com/brege)
· [mastodon.social/@brege](https://mastodon.social/@brege)
