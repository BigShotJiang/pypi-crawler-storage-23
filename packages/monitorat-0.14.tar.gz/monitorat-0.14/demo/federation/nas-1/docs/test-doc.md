# Test Wiki Document

This is a test document for federation wiki proxy testing.

## Features

- No external includes
- Simple markdown
- Works from any config directory
