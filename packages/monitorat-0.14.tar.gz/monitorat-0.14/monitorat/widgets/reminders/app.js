// Reminders Widget
/* global alert */
class RemindersWidget {
  constructor(config = {}) {
    this.container = null;
    this.remindersConfig = null;
    this.config = config;
    this.selectedSource = 'all';
    this.filteredReminders = null;
    this.features = {
      controls: null,
      alerts: null,
    };
  }

  initializeFeatureHeaders() {
    const features = this.config.features || {};
    for (const [featureId, featureConfig] of Object.entries(features)) {
      const headerEl = this.container.querySelector(
        `[data-reminders-section-header="${featureId}"]`,
      );
      if (headerEl && featureConfig.header) {
        headerEl.textContent = featureConfig.header;
      }
    }
  }

  getApiBase() {
    return this.config._apiPrefix
      ? `api/${this.config._apiPrefix}`
      : 'api/reminders';
  }

  getImgBase() {
    return this.config.remote ? `api/proxy/${this.config.remote}/img` : 'img';
  }

  canEditReminders() {
    if (this.config._apiPrefix || this.config.remote) {
      return false;
    }
    if (this.config.federation?.nodes) {
      return false;
    }
    return window.monitorShared?.isEditModeEnabled?.() === true;
  }

  async openReminderEditor(reminder = null) {
    if (!this.canEditReminders()) {
      return;
    }

    const reminderId = reminder?.id || null;
    const requestUrl = new URL(`${this.getApiBase()}/source`, window.location);
    if (reminderId) {
      requestUrl.searchParams.set('reminder', reminderId);
    }

    try {
      const response = await fetch(requestUrl, { cache: 'no-store' });
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || `HTTP ${response.status}`);
      }
      const data = await response.json();

      const editorKey = reminderId
        ? `reminders:${reminderId}`
        : 'reminders:new';

      const saveReminderContent = async (payload) => {
        const saveUrl = new URL(`${this.getApiBase()}/source`, window.location);
        if (reminderId) {
          saveUrl.searchParams.set('reminder', reminderId);
        }
        const saveResponse = await fetch(saveUrl, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload),
        });
        if (!saveResponse.ok) {
          const error = await saveResponse.json();
          throw new Error(error.error || `HTTP ${saveResponse.status}`);
        }
        await this.loadData();
      };

      const deleteReminder = reminderId
        ? async () => {
            const deleteUrl = new URL(
              `${this.getApiBase()}/source`,
              window.location,
            );
            deleteUrl.searchParams.set('reminder', reminderId);
            const deleteResponse = await fetch(deleteUrl, {
              method: 'DELETE',
            });
            if (!deleteResponse.ok) {
              const error = await deleteResponse.json();
              throw new Error(error.error || `HTTP ${deleteResponse.status}`);
            }
            await this.loadData();
          }
        : null;

      if (!window.RemindersEditor) {
        throw new Error('Reminders editor unavailable');
      }

      await window.RemindersEditor.open({
        editorKey,
        reminderId,
        item: data.item,
        path: data.path,
        imgRoot: data.img_root,
        previewRenderer: (item, previewElement) =>
          this.renderReminderPreview(item, previewElement),
        onSave: saveReminderContent,
        onDelete: deleteReminder,
      });
    } catch (error) {
      alert(`Failed to load reminder editor: ${error.message}`);
    }
  }

  async openReminderModal(reminder) {
    if (!reminder || !window.RemindersModal) {
      return;
    }

    const imgBase = reminder._source
      ? `api/proxy/${reminder._source}/img`
      : this.getImgBase();
    const touchBase = reminder._source
      ? `api/reminders-${reminder._source}`
      : this.getApiBase();

    window.RemindersModal.open({
      reminder,
      imgBase,
      onConfirm: async () => {
        const touchUrl = new URL(
          `${touchBase}/${reminder.id}/touch`,
          window.location,
        );
        await fetch(touchUrl, {
          method: 'POST',
        });
        setTimeout(() => this.loadData(), 500);
        if (reminder.url) {
          window.open(reminder.url, '_blank');
        }
      },
      onReset: async () => {
        const resetUrl = new URL(
          `${touchBase}/${reminder.id}/reset`,
          window.location,
        );
        await fetch(resetUrl, { method: 'POST' });
        setTimeout(() => this.loadData(), 500);
      },
    });
  }

  async renderReminderPreview(payload, previewElement) {
    if (!previewElement) return;
    previewElement.innerHTML = '';
    previewElement.classList.add('reminder-editor-preview');

    if (!payload || !payload.item) {
      previewElement.textContent = 'Reminder preview unavailable.';
      return;
    }

    const requestUrl = new URL(`${this.getApiBase()}/preview`, window.location);
    const response = await fetch(requestUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });

    if (!response.ok) {
      const error = await response.json();
      previewElement.textContent = error.error || `HTTP ${response.status}`;
      return;
    }

    const responsePayload = await response.json();
    const reminderData = responsePayload.reminder;
    if (!reminderData) {
      previewElement.textContent = 'Preview unavailable.';
      return;
    }

    const previewCard = this.features.alerts.createReminderCard(
      reminderData,
      false,
      { disableActions: true },
    );
    previewElement.appendChild(previewCard);
  }

  sortReminders(reminders) {
    const sortBy = this.config.sort_by || 'due.asc';
    const [field, direction] = sortBy.split('.');
    const ascending = direction !== 'desc';

    return [...reminders].sort((a, b) => {
      let valueA, valueB;

      switch (field) {
        case 'name':
          valueA = (a.name || '').toLowerCase();
          valueB = (b.name || '').toLowerCase();
          break;
        case 'due':
          valueA = a.days_remaining ?? Infinity;
          valueB = b.days_remaining ?? Infinity;
          break;
        case 'touched':
          valueA = a.days_since ?? Infinity;
          valueB = b.days_since ?? Infinity;
          break;
        default:
          return 0;
      }

      if (valueA < valueB) return ascending ? -1 : 1;
      if (valueA > valueB) return ascending ? 1 : -1;
      return 0;
    });
  }

  async init(container, config = {}) {
    this.container = container;
    this.config = { ...this.config, ...config };

    const response = await fetch('widgets/reminders/index.html');
    const html = await response.text();
    await window.monitorShared.renderWidgetTemplate(container, html);

    this.initializeFeatureHeaders();
    await this.loadFeatureScripts();
    this.initializeFeatures();
    this.features.controls.initialize();
    await this.loadData();
  }

  async loadData() {
    try {
      const mergeSources = this.config.federation?.nodes;
      if (mergeSources && Array.isArray(mergeSources)) {
        await this.loadMergedData(mergeSources);
      } else {
        const response = await fetch(this.getApiBase());
        if (!response.ok) {
          throw new Error(`HTTP ${response.status}`);
        }
        const reminders = await response.json();
        this.remindersConfig = reminders;
      }
      this.updateSourceFilter();
      this.render();
    } catch (error) {
      console.error('Unable to load reminders:', error.message);
    }
  }

  async loadMergedData(sources) {
    const results = await Promise.all(
      sources.map(async (source) => {
        try {
          const response = await fetch(`api/reminders-${source}`);
          if (!response.ok) {
            console.warn(
              `Failed to fetch reminders from ${source}: HTTP ${response.status}`,
            );
            return [];
          }
          const reminders = await response.json();
          return reminders.map((r) => ({ ...r, _source: source }));
        } catch (error) {
          console.warn(
            `Failed to fetch reminders from ${source}:`,
            error.message,
          );
          return [];
        }
      }),
    );

    this.remindersConfig = results.flat();
    this.updateSourceFilter();
  }

  render() {
    this.filteredReminders = this.getFilteredReminders();
    this.features.alerts.render();
  }

  async loadFeatureScripts() {
    const featureScripts = [
      {
        globalName: 'IconHandler',
        source: 'ui/icons.js',
      },
      {
        globalName: 'RemindersModal',
        source: 'widgets/reminders/features/confirm.js',
      },
      {
        globalName: 'RemindersControls',
        source: 'widgets/reminders/features/controls.js',
      },
      {
        globalName: 'RemindersAlerts',
        source: 'widgets/reminders/features/alerts.js',
      },
    ];

    const editingAvailable =
      window.monitorShared?.isEditingAvailable?.() === true;
    const localEditableWidget =
      !this.config._apiPrefix &&
      !this.config.remote &&
      !this.config.federation?.nodes;
    if (editingAvailable && localEditableWidget) {
      featureScripts.push(
        {
          globalName: 'FormFields',
          source: 'editor/fields.js',
        },
        {
          globalName: 'RemindersEditor',
          source: 'widgets/reminders/features/editor.js',
        },
      );
    }

    await window.monitorShared.loadFeatureScripts(featureScripts);
  }

  initializeFeatures() {
    const ControlsFeature = window.RemindersControls;
    const AlertsFeature = window.RemindersAlerts;

    if (!ControlsFeature || !AlertsFeature) {
      throw new Error('Reminders feature scripts not loaded');
    }

    this.features.controls = new ControlsFeature(this);
    this.features.alerts = new AlertsFeature(this);
  }

  getFilteredReminders() {
    const reminders = this.remindersConfig || [];
    if (this.selectedSource === 'all') {
      return reminders;
    }
    return reminders.filter(
      (reminder) => reminder._source === this.selectedSource,
    );
  }

  resolveSources() {
    const configSources = this.config.federation?.nodes;
    if (configSources && Array.isArray(configSources)) {
      return configSources;
    }
    const sources = new Set(
      (this.remindersConfig || [])
        .map((reminder) => reminder._source)
        .filter(Boolean),
    );
    return Array.from(sources);
  }

  updateSourceFilter() {
    if (!this.features.controls?.updateSources) return;
    const sources = this.resolveSources();
    this.features.controls.updateSources(sources, this.selectedSource);
  }
}

// Register widget
window.widgets = window.widgets || {};
window.widgets.reminders = RemindersWidget;
