## Changelog

### 2026-02-21 -- [a394f5f..d17ab69](https://github.com/brege/monitorat/compare/a394f5f..d17ab69)

- Add [ty](https://github.com/astral-sh/ty) to pre-commit linting and fix all errors
- Updated README masthead to link to demo
- Bump version to v0.14

### 2026-02-16 -- [cde1281..e313094](https://github.com/brege/monitorat/compare/3d2cd7b..e313094)

- Applied modern CSS design after reading https://modern-css.com

### 2026-02-14 -- [0acceac..b80e139](https://github.com/brege/monitorat/compare/0acceac..b80e139)

- Fixed 'month' selection in Speedtest dropdown be a rolling 31 day window
- Add support for GitHub admonitions in the Wiki widget
- Supply a pre-build Docker container via GitHub Container Registry
- Fix overlapping editor buttons with wiki content text
- Bump version to v0.13.2

### 2026-02-09 -- [11a7f1e..28d8d9f](https://github.com/brege/monitorat/compare/11a7f1e..28d8d9f)

- Significantly improve network widget loading by pre-warming log state
- Make observer multi-cadence for use by multiple widgets
- Add Markdown features (like math) to simple demo README
- Make network uptime pill meter by event segments

### 2026-05-08 -- [1e9007c..30ac3f8](https://github.com/brege/monitorat/compare/1e9007c..30ac3f8)

- Improve all documentation of and backlinks to layout demo
- Use 'assets', not 'vendors', since these are not proprietary moneyware
- Improved spacing between feature-headers and features in metrics and network widgets
- Add KaTeX math support for the Wiki widget
- Bump version to v0.12.3
- Make network uptime pips meter-like, not a color gradient, to show fractional network health

### 2026-02-07 -- [9c843fe..337cd00](https://github.com/brege/monitorat/compare/9c843fe..337cd00)

- Support tile/snapshot configuration for metrics widget
- Bump version to v0.12.2
- Add a new "suite" mode for demos, so advanced, simple, and layout demos run from same server
- Production server (monitorat.brege.org) updated to show the layout demo

### 2026-02-06 -- [14792dd..8d49baa](https://github.com/brege/monitorat/compare/14792dd..8d49baa)

- Fix test harness API endpoints following Metrics refactor
- BREAKING: rename `/metrics/` API base path to `/system/`
- Pre-warm/cache network logs (backend) for MUCH faster restarts
- Make tile renormalization AFTER remeasure 
- Add a metrics event method (similar to network events/alerts/outages)
- Bump version to v0.12.1

### 2026-01-23 -- [4d29a30..1483e24](https://github.com/brege/monitorat/compare/4d29a30..1483e24)

- Generalized network events handling to static/alerts/
- Allow for zero-day expiration in reminders widget
- Generalize url-picker-status* from service.info to modal-status*
- Move notification testing to menu modal
- Add notification queue and add notify support for network events
- Update network statuses/colors for accuracy
- Switch alerts+notifications handlers to observers system
- Bump version to v0.12

### 2026-01-22 -- [7cabfe2..3c24d16](https://github.com/brege/monitorat/compare/7cabfe2..3c24d16)

- Add docstring explaining new observable adds to metrics
- Remove legacy H2 headers (widget headers)

### 2026-01-21 -- [67ca836..0d3f1e2](https://github.com/brege/monitorat/compare/67ca836..0d3f1e2)

- Refactored metrics tiles/snapshots into a registry driven design (continued and finished)

### 2026-01-20 -- [2456c53..371fc99](https://github.com/brege/monitorat/compare/2456c53..371fc99)

- Refactored metrics tiles/snapshots into a registry driven design [ refactor(1..8) ]
- Refactor network tiles, pips for new Observer-based system
- Make editor demo use destructable config snippets/document fragments
- Prevent wrapping/truncation of widget header on mobile through clamping and scalling
- Privacy icon switched from eyeOpen to incognitoGuy
- Services info can now hide URL bars if url set to '' or null
- Bump version to v0.11.1

### 2026-01-19 -- [f8c188a..2059111](https://github.com/brege/monitorat/compare/f8c188a..2059111)

- Bump version to v0.11
- Refactored README and update all non-install docs (sans screenshots)
- Made editing a single-key and single-menu-item toggle
- Make editing global only through the Main Menu modal
- Write directly on main config file
- De-duplicate chart CSS CSS styles and chart.js logic
- Make the chart easier MUCH easier to read on mobile

### 2026-01-18 -- [b05081d..cb23046](https://github.com/brege/monitorat/compare/b05081d..cb23046)

- Fixed regressed Privacy Mask and changed icon to Incognito Man
- Make editing global only through the Main Menu modal
- Added "Add Service"/"Add Reminder" buttons
- Various centralizations into main OR component FROM per-widget features
- Added support for uploading icons to reminders and services
- Add to wiki editing the relative path of the document the user is editing
- Change reminders editor from textarea to well-structured and bounded form
- Create central card editor for both services and reminders
- Edits now happen directly on the config file (or snippet) for reminders/services
- Added support for editing services (copying reminders method)

### 2026-01-17 -- [66cb41d..b4778d0](https://github.com/brege/monitorat/compare/66cb41d..b4778d0)

- Bump version to v0.10.5
- Restructured main JS directory
- Major improvements to editing Wiki's, ability to restore via dropdown
- Various CSS and UI tweaks for polish and consistency
- Introduce reminders editing (experimental)

### 2026-01-16 -- [338fc1d..66fe520](https://github.com/brege/monitorat/compare/338fc1d..66fe520)

- Added support for monochromatic icon handling via config flag

### 2026-01-13 -- [f155e23..73800ec](https://github.com/brege/monitorat/compare/f155e23..73800ec)

- Readying project to share with the public: many documentation edits
- NB. This stretches to 2026-01-16

### 2026-01-12 -- [7f8d8c7..e2251c7](https://github.com/brege/monitorat/compare/7f8d8c7..e2251c7)

- Introduced tile-packing algorithm "Tyler" (see: `static/tiles/tyler.tex`)
- Desktop/mobile can click/tap the status indicator Dot in in compact Service view
- Fixed Docker installs from attempting to install vendors/ in the wheel
- BREAKING: Deprecated widget-headers for section-headers (see: e083da4)
- Add node-source filters for other widgets
- CSS Refactor Procedure:
  1. extract all common patterns from `widgets/*/index.html` into `common.css`
  2. extract all `<style>` tags from `widgets/*/index.html` into `widgets/*/style.css`
  3. remove widget-specific CSS from `default.css` in `widgets/*/style.css`
  4. marry `common.css` into `default.css`
- Switched from StandardJS to Biome linting and formatting (for CSS)
- Updated all code to Biome's standard rules (js, css)
- Made default color palette sharper, less pastel
- Repaired broken href's, leading to client bugs when behind Nginx reverse proxy
- Bumped version to v0.10.4

### 2026-01-11 --  [3143083..cae4a55](https://github.com/brege/monitorat/compare/3143083..cae4a55)

- Orthogonalize Federation demos from Layout specification
- Deprecate federation "stacked" and "columnated" mergers in favor of full integrations
- Added true columnation: group by widgets as tables when needed
- Added node-source filtering to the network.outages
- Created Layout demo for testing new columnation+positioning scheme

### 2026-01-10 -- [7643259..6d5ee72](https://github.com/brege/monitorat/compare/7643259..6d5ee72)

- Introduced modal Markdown editing (esperimental) via textarea
- Standardize Action buttons into new icon-label group (save, cancel, restore, run speedtest)
- Made chart legends much easier to read
- Trimmed the full-fat widgets from advanced demo, so it focuses only on: 
  - features
  - styling
  - components  
  of each widget
- Made app icons more expressive on hover
- Divided the main demo/docs.yml into demo-specifc index.yml's
- No longer differentiate widgets by stacking or columnated

### 2026-01-09 -- [2ee8b57..d400921](https://github.com/brege/monitorat/compare/2ee8b57..d400921)

- Add Roadmap
- Hover on reminder alerts shows the URL target
- Run button uses an speedometer icon
- Federation demo wiki samples shorter or summary/detail for side-by-side readability
- Chart.js hover tooltip legend squares should be solid fill
- CSV button hover tooltip should read "Download CSV"
- Change "show less" to "show fewer"
- Unit time labels use "hour"/"day" when unity; keep numerals for non-unity
- Added link-icon expansion for informational links/modals
- Added docs.py to pre-commit as insurance before pushing to prod demos
- Refactored header and menu code into central monitorat/static/header/
- Added TOC button to left of site header for easier navigation

### 2026-01-08 -- [15d51fe..7de663f](https://github.com/brege/monitorat/compare/15d51fe..7de663f)

- Overhauled chart legends and created two-legend scheme for federation
- Made ollama icon look better on both light and dark backgrounds
- Overhauled headers inside and outside Markdown containers
- Added Wikipedia chevrons to first-rate headers for easier collapsing
- Made all demo section headers collapsible
- Fixed ~50 typos and grammar errors in Markdown
- Make server shutdowns more graceful
- Bumped version to v0.10

### 2026-01-07 -- [d17e19c..ebd479f](https://github.com/brege/monitorat/compare/d17e19c..ebd479f)

- Made service status resolving more robust for Docker and Systemd
- Expanded schema for services widget to cover more status cases
- Added toggle for local vs. CDN external JS/CSS (needed for demo on production)
- Caught up scattered ghost colors and theme leakage in JS
- Added a formal.css theme for a LaTeX/Journal look
- Gave users a theming key in config.yaml so they can change or layer on top of the factory themes
- Added a new about modal with live theme switching
- Added a modal for long press on services cards/icons for more details
- Added an info icon for services cards/icons (desktop benefits too)
- Made markdown tables and TableManager tables gracefully overflow through scrolling in-body
- Made demo bind to 0.0.0.0 for easier mobile debugging on Fedora


### 2026-01-06 -- [c2d5013..78af0e6](https://github.com/brege/monitorat/compare/c2d5013..78af0e6)

- Added an installation guide for Docker
- Improved all installation-related documentation
- Modernized screenshots in README to reflect new capabilities like federation
- Bumped version to v0.9.3

### 2026-01-05 -- [b29068a..769b1b9](https://github.com/brege/monitorat/compare/b29068a..769b1b9)

- Added quick-link footers to demos for easier navigation
- Made test network data non-degenerate and non-trivial
- Improved error handling in test harness when documents can't resolve
- Condensed 40+ \*.md snippets into demo/docs.{yml,py}
- Fixed non-snippetted config loading being overridden by default values
- Renamed widgets/\*/config_default.yaml to widgets/\*/default.yaml and load them dynamically
- Bumped version to v0.9.2

### -- [b8bdb34..a95ab80](https://github.com/brege/monitorat/compare/b8bdb34..a95ab80)

- Added test harness to GitHub Actions to prevent publishing some mistakes to PyPI
- Added smoke test for demos to check for 200/404/503 etc responses
- Added a compact view for services, so it feels like an app drawer
- Added mermaid diagrams to vendors so users can make flowcharts
- Unified the old test/dev and demo runner under one demo/launcher.py
- Many small adjustments to demo snippets to make examples more interesting
- Debut a full demo stack showcasing:
  - simple: the standard one-node demo
  - advanced: a multi-node demo with federation
  - federation: a multi-node demo with federation

### 2026-01-01 -- [b402afa..406035e](https://github.com/brege/monitorat/compare/b402afa..406035e)

- Extracted three shared utilities to reduce federation bloat in widget code:
  - `FeatureVisibility.js` - centralizes show/hide logic for widget features
  - `FederationRenderer.js` - provides columnate/stack rendering patterns
  - `TileRenderer.js` - creates stats tiles with consistent structure
- Refactored network, metrics, and speedtest widgets to use new shared utilities
- Fixed config resolution for includes snippets
- Added bootstrap command so install -> demo is two commands
- Extended demo infrastructure for living documentation:
  - Created `demo/launcher.py` to start simple/advanced/federation demos
  - Created partitioned config structure: `demo/federation/central/`, `demo/federation/nas-1/`, `demo/federation/nas-2/`
  - Introduced snippet-based config assembly for pedagogical widget ordering
  - Created `docs/demo-architecture.md` with implementation checklist

### 2025-12-31 -- [c0ccc97..63f8097](https://github.com/brege/monitorat/compare/c0ccc97..63f8097)

- Completed federation support for all widgets with per-feature merge strategies
- Network widget now supports columnate, stack, and merge for tiles, uptime, and outages separately
- Fixed network tiles in columnation showing all 6 metrics in 2-wide layout
- Fixed uptime column headers showing both source badge and period label
- Fixed badge positioning issue (badges were floating to page corners)
- Added `show.controls` and `show.history` visibility toggles to speedtest widget
- Reorganized metrics and speedtest directory structure: chart.js + table.js grouped into history/ folder
- Metrics widget fully federalized with per-feature display strategies
- Added new test configurations for speedtest: controls-only and history-only variants

### 2025-12-30 -- [5b0f6d2..e9aaba9](https://github.com/brege/monitorat/compare/5b0f6d2..e9aaba9)

- Complete test apparatus implemented:
  - test/harness.py introduced 26 smoke tests to check basic asserts/API response
  - test/dev.py allowed launching multiple local instances of monitorat (since removed)
  - --widget [metrics|network|...] allows for launching only a simplified, one-widget page
  - Launches a head node and two "remote" nodes in one harness
- Fixed discovered DOM collisions from federation
- Added API-prefixes so clients, nodes can distinguish data on same widgets
- Bumped version to v0.8.1
- Renamed "gaps" CSS naming to "alerts"
- Added style switches to Wiki widget: seamless|featured|rail
- Serve service and reminder icons through API
- All widgets now have Schema
- All widget-specific configuration atomized into an includes' config snippets
- All widget client app.js chunked into features: {chart|table|snapshot|...}.js
- All widgets have decided-upon merging behaviors in federation; network widget still WIP
- Centralize data-downloaders (CSV, etc), table/chart/node filters in one standard container
- All widget federation tested with test/dev.py: merging, stacking, side-by-side, interleaving (since removed)

### 2025-12-29 -- [d8da266..af3b061](https://github.com/brege/monitorat/compare/d8da266..af3b061)

- Created new branch: federation
- Added experimental federation and auth support in the federation branch
- Created test fixtures and a test harness to launch multiple instances at once
- Extended demo/init.py to demo/setup.py that bootstraps -t tests and -d demos
- Packages added: httpx, Flask-HTTPAuth
- Began backfilling this changelog
- Bumped version to v0.8
- Removed documentation scripts--these are not appropriate for this project
- Added LTTB sampling to clamp data points at 1500 for faster rendering, data transfer

### 2025-12-28 -- [3a1c4eb..3d9a566](https://github.com/brege/monitorat/compare/3a1c4eb..3d9a566)

- Added an interactive demo mode and pushed to https://monitorat.brege.org
- Fixed incorrect colors in the network widget's stats
- Added support for nested markdown inclusions and shortcodes for {{file}} inclusion
- Reduced onboarding friction by adding 'monitorat server' instead of gunicorn command
- Condensed the README in favor of linking the interactive Demo

### 2025-12-27 -- [feccd25..47e3521](https://github.com/brege/monitorat/compare/feccd25..47e3521)

- Favor uv-installs over pip installs by default
- Systemd and GitHub-Actions workflows updated for uv tool installs

### 2025-11-23-- [19902ad..7b64821](https://github.com/brege/monitorat/compare/19902ad..7b64821)

- Standardized widget structure with common names: app.js, index.html, api.py, schema.json
- Fixed multiple issues with the Speedtest widget: 
  - Added a TimeSeries.js helper so temporal axes are consistent between widgets
  - Splitting responsibilities of charting and table formatting
  - Broken dropdowns and time-mismatches causing unstable UX on refresh
  - Made speedtest metadata declarative, removing duplicate code
- Refactored Metrics widget to use new time-series methods from Speedtest effort


### 2025-11-22 -- [8a39f1c..21aa74b](https://github.com/brege/monitorat/compare/8a39f1c..21aa74b)

- Added JSON schema for all chart-based widgets and refactored TS widgets to use their schema
- Made recording and measuring of metric quantities declarative, configurable by user
- Added a CSV handler so all widgets have predictable data handling

### 2025-11-20 -- [6d3c8c9..7b3609f](https://github.com/brege/monitorat/compare/6d3c8c9..7b3609f)

- Moved all www/ code to monitorat/ so application code has less hairy pip-installs to Wheel
- Added an Alerts module for use by Metrics widget and Reminders widget
- Made central monitor.py less monolithic and more orchestrative:
  - Created monitorat/cli.py to provide 'monitorat config|ls-widgets' commands
  - Extract config management (confuse+adapters) to central monitorat/config.py
- Centralized client-side code in monitorat/static/

### 2025-11-19 -- [feaafb5..2e11323](https://github.com/brege/monitorat/compare/feaafb5..2e11323)

- Fixed regression of multiple Wiki-widget support
- Added to Network widget a chirper to record activity, so users don't need ddclient+syslogs

### 2025-11-17

- Applied YAML formatting via opinionated linter package 'yamlfix' to config\_default.yaml
- Greatly improved new widget discovery to dynamically load user-defined widgets

---

### 2025-11-17 -- [908ff25..88f9474](https://github.com/brege/monitorat/compare/908ff25..88f9474)

- Changed custom widget path from var to list (confuse)
- Added support widget discovery

### 2025-11-16 -- [4ac4eb7..7e8f7e2](https://github.com/brege/monitorat/compare/4ac4eb7..7e8f7e2)

- Fix regression that allowed widget initialization in parallel
- Made factory widgets/* dynamically loadable
- Remove legacy sub-widget enabled key
- Remove duplicate listeners from reminders widget
- Introduce `wiki/api.py` and register services identical to others (multiple wikis)

### 2025-11-14 -- [25802e9..25802e9](https://github.com/brege/monitorat/compare/25802e9..25802e9)

- Added support molecular config snippets (e.g. one YAML per-widget)

### 2025-11-13 -- [0be2624..8fc9b31](https://github.com/brege/monitorat/compare/0be2624..8fc9b31)

- Bump version to v0.2
- Improve installation instructions for pip-source installs
- Added speedtest widget as a first-run default

### 2025-11-11 -- [01fd796..c5d4aca](https://github.com/brege/monitorat/compare/01fd796..c5d4aca)

- Release v0.1 and publish to PyPI
- Added a publish workflow for PyPI
- Added masthead

### 2025-11-10 -- [7448817..12a2488](https://github.com/brege/monitorat/compare/7448817..12a2488)

- Removed alpha code and outdated documentation
- De-duplicated Time Series methods from System Metrics and Speedtest widgets
- Improved Reminders widget's confuse implementation
- Added confuse's config dumping method
- Download-CSV consistency between System Metrics and Speedtest
- Restrict table's 'show X more' to table display only

### 2025-11-08 -- [42b353b..42b353b](https://github.com/brege/monitorat/compare/42b353b..42b353b)

- Updated network widget to use ddclient-style logs

### 2025-11-07 -- [703d197..a7423ad](https://github.com/brege/monitorat/compare/703d197..a7423ad)

- Restored cadence and threshold settings in Network widget
- Service detection for Docker, Systemd better scoped
- Improved configuration language (natural language times)
- Added backend logging
- Removed hardcoded fall backs: embrace confuse
- Debut System Metrics alerts

---

### 2025-11-06 -- [e4ce686..8a8a753](https://github.com/brege/monitorat/compare/e4ce686..8a8a753)

- Universalized logging for all widgets
- Extracted notification handler from reminders into top-level handler
- Applied new code-quality standards/linting
- Added duration defaults to chart view options
- Make spiky plots smoother
- Refactored to centralize widget headers and de-dupe timestamp helpers

### 2025-11-05 -- [9e7759d..776ea43](https://github.com/brege/monitorat/compare/9e7759d..776ea43)

- Add charts for System Metrics widget
- Extracted data handling from Speedtest widget
- Enhanced metrics widget to provide an historical CSV download

### 2025-11-03 -- [c90cfcd..c90cfcd](https://github.com/brege/monitorat/compare/c90cfcd..c90cfcd)

- Added a deeper app reload toggle for refreshing off changes to config.yaml

### 2025-11-02 -- [61fba0a..61fba0a](https://github.com/brege/monitorat/compare/61fba0a..61fba0a)

- Added Daylight Savings Time change handling

### 2025-11-01 -- [b852022..0eb8c8f](https://github.com/brege/monitorat/compare/b852022..0eb8c8f)

- Added pipeline for new favicon
- Fixed dupe chart fetch and improve speedtest graph loading
- Cache network pills so refresh doesn't repaint each one
- Network widget now provides an API for the DDNS log (no longer assumes it's in data/)
- Replace direct Pushover notification with general Apprise URLs

### 2025-10-31 -- [5aeeff0..5aeeff0](https://github.com/brege/monitorat/compare/5aeeff0..5aeeff0)

- Load widgets in parallel to improve performance

### 2025-10-30 -- [5d47fb1..880c46c](https://github.com/brege/monitorat/compare/5d47fb1..880c46c)

- Removed hardcoded dark mode stranded in Network widget
- Improved light mode and SVG icon usage
- Fixed spotty click behavior and hover text on service widget boxes
- Extended Metrics widget to measure quantities on old hardware

### 2025-10-29 -- [8467262..2021ca7](https://github.com/brege/monitorat/compare/8467262..2021ca7)

- Added speedtest plotting via Chart.js
- Extracted the speedtest API code from main into its own widget
- Improve pushover notifications

### 2025-10-28 -- [747e82a..4b6c5eb](https://github.com/brege/monitorat/compare/747e82a..4b6c5eb)

- Added ability to collapse widgets to anchored headers
- Now supporting multiple of same widget via `type` key

### 2025-10-27

- Initial Commit
