"""fastfold-agent-cli: An autonomous agent for drug discovery research."""

__version__ = "0.1.0"
