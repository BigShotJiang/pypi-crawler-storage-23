"""Shared fixtures for ievo CLI tests."""

from __future__ import annotations

from pathlib import Path

import pytest
import yaml


@pytest.fixture
def tmp_project(tmp_path: Path) -> Path:
    """Create a minimal ievo project structure."""
    manifest = {
        "project": "test-project",
        "version": "0.1.0",
        "created": "2026-01-01",
        "agents": {},
    }
    (tmp_path / "ievo.yaml").write_text(yaml.dump(manifest, sort_keys=False))
    (tmp_path / "agents").mkdir()
    (tmp_path / "spec").mkdir()
    (tmp_path / "plans").mkdir()
    return tmp_path


@pytest.fixture
def tmp_project_with_agent(tmp_project: Path) -> Path:
    """Create a project with one agent installed."""
    # Update manifest
    manifest = yaml.safe_load((tmp_project / "ievo.yaml").read_text())
    manifest["agents"] = {"spec-writer": "0.1.0"}
    (tmp_project / "ievo.yaml").write_text(yaml.dump(manifest, sort_keys=False))

    # Create agent dir
    agent_dir = tmp_project / "agents" / "spec-writer"
    agent_dir.mkdir(parents=True)
    (agent_dir / "memory").mkdir()
    (agent_dir / "skills" / "evo").mkdir(parents=True)

    agent_yaml = {
        "name": "spec-writer",
        "version": "0.1.0",
        "description": "Converts features into atomic requirements",
        "author": "ievo-ai",
        "model": {"primary": "sonnet", "fallback": "haiku"},
        "dependencies": [],
        "mcp": [{"name": "filesystem", "type": "builtin"}],
        "plugins": [],
        "skills": ["evo"],
        "hooks": {
            "on_session_start": "load_memory",
            "on_session_end": "save_memory",
            "on_error": "evo_analyze",
        },
        "disclosure": {"metadata": 100, "instructions": 400, "resources": 600},
    }
    (agent_dir / "agent.yaml").write_text(yaml.dump(agent_yaml, sort_keys=False))
    (agent_dir / "ROLE.md").write_text("# Spec Writer\n\nYou are the Spec Writer agent.\n")
    (agent_dir / "EVOLUTION_LOG.md").write_text("# Evolution Log\n\n")

    for mf in ["CONTEXT.md", "DECISIONS.md", "VOCABULARY.md", "HISTORY.md"]:
        (agent_dir / "memory" / mf).write_text(f"# {mf.replace('.md', '')}\n\n")

    return tmp_project


SAMPLE_REGISTRY_YAML = """\
agents:
  - name: spec-writer
    version: "0.1.0"
    description: "Converts features into atomic requirements"
    model: sonnet
    dependencies: []
    category: core
  - name: architect
    version: "0.1.0"
    description: "Creates implementation plans"
    model: opus
    dependencies:
      - spec-writer
    category: core
  - name: coder
    version: "0.1.0"
    description: "Implements plans via TDD"
    model: sonnet
    dependencies:
      - spec-writer
      - architect
    category: core
"""
