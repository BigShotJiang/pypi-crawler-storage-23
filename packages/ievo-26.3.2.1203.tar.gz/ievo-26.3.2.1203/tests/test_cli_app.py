"""Tests for ievo CLI entry point (cli.py)."""

from __future__ import annotations

import sys
from unittest.mock import MagicMock, patch

import pytest
import typer

from ievo.cli import app, version_callback


def test_version_callback_true() -> None:
    with pytest.raises(typer.Exit):
        version_callback(value=True)


def test_version_callback_false() -> None:
    # Should do nothing when value is False
    version_callback(value=False)


def test_main_with_subcommand() -> None:
    """When a subcommand is invoked, main should not launch TUI."""
    # Import the actual underlying function
    from ievo.cli import main

    ctx = MagicMock(spec=typer.Context)
    ctx.invoked_subcommand = "init"
    # Should not raise or call run_tui
    main(ctx=ctx, version=False)


def test_main_no_subcommand_launches_tui() -> None:
    """When no subcommand, main should launch the TUI."""
    from ievo.cli import main

    ctx = MagicMock(spec=typer.Context)
    ctx.invoked_subcommand = None

    # Mock the module-level import that happens inside main()
    mock_tui_module = MagicMock()
    with patch.dict(sys.modules, {"ievo.tui.app": mock_tui_module}):
        main(ctx=ctx, version=False)
        mock_tui_module.run_tui.assert_called_once()


def test_app_has_commands() -> None:
    # Verify all expected commands are registered
    command_names = {cmd.name for cmd in app.registered_commands}
    expected = {"init", "add", "remove", "update", "list", "run", "team", "orchestrate"}
    assert expected.issubset(command_names)
