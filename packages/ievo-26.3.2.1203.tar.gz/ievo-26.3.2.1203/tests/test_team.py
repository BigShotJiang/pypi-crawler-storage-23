"""Tests for ievo team command."""

from __future__ import annotations

from ievo.commands.team import team


def test_team_warns_not_implemented() -> None:
    # Should not raise, just print warnings
    team(agents=["spec-writer", "coder"])


def test_team_single_agent() -> None:
    team(agents=["spec-writer"])
