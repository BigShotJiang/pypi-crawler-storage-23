"""Tests for ievo dev subcommands."""

from __future__ import annotations

from pathlib import Path
from unittest.mock import patch

from ievo.commands.dev import new, publish, test


def test_dev_new_creates_agent(tmp_path: Path) -> None:
    with (
        patch("pathlib.Path.cwd", return_value=tmp_path),
        patch("ievo.commands.add._create_local_agent") as mock_create,
    ):
        new(name="my-agent")
        mock_create.assert_called_once_with(tmp_path / "my-agent", "my-agent", "0.1.0")


def test_dev_test_stub() -> None:
    # Phase 2 stub — should not raise
    test(agent="spec-writer")


def test_dev_publish_stub() -> None:
    # Phase 2 stub — should not raise
    publish(agent="spec-writer")
