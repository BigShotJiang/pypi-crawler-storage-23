"""Tests for ievo list command."""

from __future__ import annotations

from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

from ievo.commands.list_cmd import list_agents


def test_list_empty_project(tmp_project: Path) -> None:
    with patch("ievo.commands.list_cmd.require_project", return_value=tmp_project):
        list_agents(marketplace=False)  # should not raise


def test_list_with_agents(tmp_project_with_agent: Path) -> None:
    with patch("ievo.commands.list_cmd.require_project", return_value=tmp_project_with_agent):
        list_agents(marketplace=False)  # should not raise


def test_list_with_agent_missing_dir(tmp_project_with_agent: Path) -> None:
    """Agent in manifest but dir was deleted — should not crash."""
    import shutil

    root = tmp_project_with_agent
    shutil.rmtree(root / "agents" / "spec-writer")

    with patch("ievo.commands.list_cmd.require_project", return_value=root):
        list_agents(marketplace=False)


def test_list_marketplace_with_entries() -> None:
    """Marketplace listing with registry entries."""
    mock_entry = MagicMock()
    mock_entry.name = "spec-writer"
    mock_entry.version = "0.1.0"
    mock_entry.model = "sonnet"
    mock_entry.category = "core"
    mock_entry.description = "Converts features into atomic requirements"

    mock_registry = MagicMock()
    mock_registry.fetch = AsyncMock()
    mock_registry.list_all.return_value = [mock_entry]

    with patch("ievo.core.registry.Registry.load_cached", return_value=mock_registry):
        list_agents(marketplace=True)


def test_list_marketplace_empty() -> None:
    """Marketplace listing with empty registry."""
    mock_registry = MagicMock()
    mock_registry.fetch = AsyncMock()
    mock_registry.list_all.return_value = []

    with patch("ievo.core.registry.Registry.load_cached", return_value=mock_registry):
        list_agents(marketplace=True)
