"""Tests for init_templates — verify template content integrity."""

from __future__ import annotations

from ievo.commands.init_templates import (
    ARCHITECT_WORKFLOW,
    CLAUDE_MD,
    CODER_AGENT_WORKFLOW,
    GITIGNORE,
    ISSUE_TEMPLATE_CHANGE,
    ISSUE_TEMPLATE_FEATURE,
    PRIORITY_MD,
    SPEC_CR_TEMPLATE,
    SPEC_INDEX_MD,
    SPEC_REQ_TEMPLATE,
    SPEC_WRITER_WORKFLOW,
)


def test_priority_md_has_formula() -> None:
    assert "score =" in PRIORITY_MD
    assert "priority_weight" in PRIORITY_MD
    assert "dependency_satisfaction" in PRIORITY_MD
    assert "blocking_count" in PRIORITY_MD
    assert "open_questions" in PRIORITY_MD


def test_priority_md_has_example() -> None:
    assert "REQ-001" in PRIORITY_MD
    assert "REQ-002" in PRIORITY_MD


def test_spec_index_has_status_legend() -> None:
    assert "Status Legend" in SPEC_INDEX_MD
    assert "draft" in SPEC_INDEX_MD
    assert "ready" in SPEC_INDEX_MD
    assert "implemented" in SPEC_INDEX_MD
    assert "blocked" in SPEC_INDEX_MD


def test_spec_index_has_dependency_rules() -> None:
    assert "Dependency Rules" in SPEC_INDEX_MD


def test_spec_writer_workflow_valid() -> None:
    assert "name: Spec Writer" in SPEC_WRITER_WORKFLOW
    assert "ANTHROPIC_API_KEY" in SPEC_WRITER_WORKFLOW
    assert "claude -p" in SPEC_WRITER_WORKFLOW


def test_coder_agent_workflow_valid() -> None:
    assert "name: Coder Agent" in CODER_AGENT_WORKFLOW
    assert "ANTHROPIC_API_KEY" in CODER_AGENT_WORKFLOW
    assert "ready" in CODER_AGENT_WORKFLOW


def test_issue_template_feature() -> None:
    assert "Feature" in ISSUE_TEMPLATE_FEATURE
    assert "labels: feature" in ISSUE_TEMPLATE_FEATURE


def test_issue_template_change() -> None:
    assert "Change" in ISSUE_TEMPLATE_CHANGE
    assert "labels: change" in ISSUE_TEMPLATE_CHANGE


# ── New template tests ────────────────────────────────────────


def test_architect_workflow_valid() -> None:
    assert "name: Architect Agent" in ARCHITECT_WORKFLOW
    assert "ANTHROPIC_API_KEY" in ARCHITECT_WORKFLOW
    assert "plans/" in ARCHITECT_WORKFLOW


def test_gitignore_non_empty() -> None:
    assert ".env" in GITIGNORE
    assert "__pycache__" in GITIGNORE
    assert len(GITIGNORE.strip()) > 50


def test_claude_md_has_sections() -> None:
    assert "Tech stack" in CLAUDE_MD
    assert "Conventions" in CLAUDE_MD
    assert "{project_name}" in CLAUDE_MD
    assert "What this project is" in CLAUDE_MD
    assert "What NOT to do" in CLAUDE_MD


def test_spec_req_template_has_sections() -> None:
    assert "Acceptance Criteria" in SPEC_REQ_TEMPLATE
    assert "Metadata" in SPEC_REQ_TEMPLATE
    assert "Negative Acceptance Criteria" in SPEC_REQ_TEMPLATE
    assert "Context" in SPEC_REQ_TEMPLATE


def test_spec_cr_template_has_sections() -> None:
    assert "What Changes" in SPEC_CR_TEMPLATE
    assert "Impact Estimate" in SPEC_CR_TEMPLATE
    assert "What Stays the Same" in SPEC_CR_TEMPLATE


def test_all_templates_non_empty() -> None:
    for name, template in [
        ("PRIORITY_MD", PRIORITY_MD),
        ("SPEC_INDEX_MD", SPEC_INDEX_MD),
        ("SPEC_WRITER_WORKFLOW", SPEC_WRITER_WORKFLOW),
        ("CODER_AGENT_WORKFLOW", CODER_AGENT_WORKFLOW),
        ("ISSUE_TEMPLATE_FEATURE", ISSUE_TEMPLATE_FEATURE),
        ("ISSUE_TEMPLATE_CHANGE", ISSUE_TEMPLATE_CHANGE),
        ("ARCHITECT_WORKFLOW", ARCHITECT_WORKFLOW),
        ("CLAUDE_MD", CLAUDE_MD),
        ("GITIGNORE", GITIGNORE),
        ("SPEC_REQ_TEMPLATE", SPEC_REQ_TEMPLATE),
        ("SPEC_CR_TEMPLATE", SPEC_CR_TEMPLATE),
    ]:
        assert len(template.strip()) > 50, f"{name} is too short"
