"""ievo dev — agent development commands."""

from __future__ import annotations

import typer

from ievo.utils.console import info, warn

app = typer.Typer(no_args_is_help=True)


@app.command(name="new")
def new(
    name: str = typer.Argument(help="Name for the new agent."),
) -> None:
    """Scaffold a new agent from the SDK template."""
    warn("Dev SDK not yet available. Creating local agent structure...")

    from pathlib import Path

    from ievo.commands.add import _create_local_agent

    dest = Path.cwd() / name
    _create_local_agent(dest, name, "0.1.0")
    info(f"Created agent scaffold at [bold]{dest}[/bold]")
    info("Edit ROLE.md to define agent behavior.")


@app.command(name="test")
def test(
    agent: str = typer.Argument(help="Agent name to test."),
) -> None:
    """Run evaluation tests for an agent (Phase 2+)."""
    warn("Agent eval suite not yet implemented (Phase 2).")
    info(f"Will run evals for [bold]{agent}[/bold] when ready.")


@app.command(name="publish")
def publish(
    agent: str = typer.Argument(help="Agent name to publish."),
) -> None:
    """Publish agent to the marketplace (Phase 2+)."""
    warn("Publishing not yet implemented (Phase 2).")
    info(f"Will publish [bold]{agent}[/bold] to ievo-marketplace when ready.")
