"""ievo team — run Agent Teams with multiple agents."""

from __future__ import annotations

import typer

from ievo.utils.console import info, warn


def team(
    agents: list[str] = typer.Argument(help="Agent names to run as a team."),
) -> None:
    """Run multiple agents as an Agent Team (Phase 2+)."""
    warn("Agent Teams are not yet implemented (Phase 2).")
    info(f"Planned team: {', '.join(agents)}")
    info("For now, run agents individually: [bold]ievo run <agent>[/bold]")
