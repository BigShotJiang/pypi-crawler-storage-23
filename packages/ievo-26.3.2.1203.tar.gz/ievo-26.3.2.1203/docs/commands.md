# CLI Command Reference

## Project Management

### `ievo init [name]`

Create a new SDD project. Generates:

- `ievo.yaml` — project configuration
- `spec/` — specification documents
- `plans/` — architecture plans
- `agents/` — installed agents
- `.github/` — workflow templates
- `.claude/` — Claude Code configuration

### `ievo config set/get/delete <key> [value]`

Manage project and global settings.

```bash
ievo config set default_model sonnet
ievo config get default_model
ievo config delete custom_key
```

## Agent Management

### `ievo add <agents...>`

Install agents from the marketplace. Resolves dependencies and downloads via GitHub Contents API.

```bash
ievo add spec-writer architect coder
```

### `ievo remove <agent> [--force]`

Remove an installed agent. Checks for dependents before removal. Use `--force` to skip dependency checks.

### `ievo update [agent]`

Update agent(s) to the latest marketplace version. Without an argument, updates all installed agents.

### `ievo list [--marketplace]`

Show installed agents. With `--marketplace`, show all available agents from the registry.

## Execution

### `ievo run <agent> [-m msg] [-p file] [--model] [--local]`

Launch a Claude session with agent context loaded. By default, agents run in a Docker sandbox with tool-level permissions defined in `agent.yaml`. Use `--local` to run directly via Claude CLI.

```bash
ievo run spec-writer -m "Build auth module"
ievo run coder -p spec/REQ-001.md --model opus
ievo run spec-writer --local -m "Quick test"    # skip Docker
```

**Docker sandbox behavior:**
- Requires Docker installed and running
- Auto-builds `ievoai/sandbox:latest` image if not found (from `sandbox/Dockerfile`)
- Falls back to local mode if Docker is unavailable
- Mounts project root as `/workspace` volume
- Passes `CLAUDE_CODE_OAUTH_TOKEN` for API access
- Tool isolation via `--allowedTools` (from agent.yaml `sandbox.allowed_tools`)

**Build the sandbox image manually:**

```bash
docker build -t ievoai/sandbox:latest sandbox/
```

### `ievo orchestrate [--max N] [--agent name]`

Automated coder loop. Runs agent sessions in sequence, processing the highest-priority task. `--max N` limits iterations. `--agent` restricts to a specific agent.

## Dependencies

### `ievo deps install/check/list`

Manage MCP and plugin dependencies declared in agent packages.

```bash
ievo deps install    # Install all declared dependencies
ievo deps check      # Verify all dependencies are met
ievo deps list       # Show dependency tree
```

## Evolution

### `ievo learn log/push/status`

Manage evolution history.

```bash
ievo learn log       # Show local evolution entries
ievo learn push      # Push evolution entries upstream
ievo learn status    # Check sync status
```

## Phase 2 (Planned)

### `ievo dev new/test/publish`

Agent development workflow — create, test, and publish agents to the marketplace.

### `ievo team <agents...>`

Multi-agent teams — run multiple agents in coordinated sessions.
