# Configuration

## Project Config: `ievo.yaml`

Created by `ievo init`. Lives in the project root.

```yaml
project:
  name: my-project
  version: "0.1.0"

agents:
  - spec-writer
  - architect
  - coder

overrides:
  spec-writer:
    model: opus
  coder:
    model: sonnet
```

### Fields

| Field | Type | Description |
|-------|------|-------------|
| `project.name` | string | Project name |
| `project.version` | string | Project version |
| `agents` | list | Installed agent names |
| `overrides` | map | Per-agent config overrides (model, hooks, etc.) |

Agent overrides allow per-project model changes without modifying the agent package itself.

## Global Config: `~/.ievo/config.json`

User-level settings, shared across all projects.

```json
{
  "default_model": "sonnet",
  "marketplace_url": "https://github.com/ievo-ai/marketplace",
  "github_auth": "ghp_..."
}
```

| Field | Description |
|-------|-------------|
| `default_model` | Default Claude model for `ievo run` |
| `marketplace_url` | Agent registry URL |
| `github_auth` | GitHub token for marketplace access |

## Credentials

Credentials are encrypted via RSA keypair stored in `~/.ievo/`. The keypair is generated on first use. Tokens and API keys are encrypted at rest and decrypted only when needed by CLI commands.

## Environment Variables

| Variable | Purpose |
|----------|---------|
| `ANTHROPIC_API_KEY` | Required for Claude sessions (`ievo run`, `ievo orchestrate`) |

## Sandbox Configuration

Each agent declares sandbox settings in `agent.yaml`:

```yaml
sandbox:
  allowed_tools:
    - Read
    - Write
    - Edit
    - Glob
    - Grep
  network: false
  memory_mb: 2048
  cpu_limit: 2.0
  timeout_seconds: 3600
```

| Field | Type | Default | Description |
|-------|------|---------|-------------|
| `allowed_tools` | list | `[Read, Write, Edit, Glob, Grep]` | Claude tools available inside the sandbox |
| `network` | bool | `false` | If true, adds WebFetch/WebSearch to allowed tools |
| `memory_mb` | int | `2048` | Container memory limit |
| `cpu_limit` | float | `2.0` | CPU cores limit |
| `timeout_seconds` | int | `3600` | Maximum session duration |

When `network: true`, WebFetch and WebSearch are automatically added to the tools list. Network isolation is tool-level, not Docker network — Claude CLI always needs Anthropic API access.

Missing `sandbox:` section defaults to read/write-only tools with no network.

## Docker Sandbox Image

The sandbox Dockerfile is at `sandbox/Dockerfile`. Build manually:

```bash
docker build -t ievoai/sandbox:latest sandbox/
```

`ievo run` auto-builds the image if Docker is available but the image is missing.

The image includes: Python 3.13, Node.js, Claude Code CLI, git.

## MCP Dependencies

Agents declare MCP server dependencies in `agent.yaml`. When agents are installed via `ievo add`, the CLI auto-generates `.mcp.json` in the project root, configuring all required MCP servers for Claude Code.
