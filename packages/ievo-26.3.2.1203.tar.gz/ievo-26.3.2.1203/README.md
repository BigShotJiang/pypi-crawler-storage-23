```
 ██╗ ███████╗██╗   ██╗ ██████╗
 ╚═╝ ██╔════╝██║   ██║██╔═══██╗
 ██╗ █████╗  ██║   ██║██║   ██║
 ██║ ██╔══╝  ╚██╗ ██╔╝██║   ██║
 ██║ ███████╗ ╚████╔╝ ╚██████╔╝
 ╚═╝ ╚══════╝  ╚═══╝   ╚═════╝
```

# iEvo CLI

Self-evolving AI agent framework. Install agents like packages — they learn from every mistake.

## Install

```bash
# Recommended — run without install
uvx ievo --help

# Or install globally
uv tool install ievo

# Or with pip
pip install ievo
```

## Quick start

```bash
ievo init my-project
cd my-project
ievo add spec-writer architect coder
ievo run spec-writer
```

## Development

```bash
git clone https://github.com/ievo-ai/cli.git
cd cli
uv sync
uv run ievo --help
```

## Docker sandbox

Agents run in isolated Docker containers by default — each with its own set of allowed tools.

```bash
# Build the sandbox image (first time)
docker build -t ievoai/sandbox:latest sandbox/

# Agents use Docker automatically
ievo run spec-writer -m "Build auth module"

# Skip Docker, run locally
ievo run spec-writer --local -m "Quick test"
```

Auto-fallback: if Docker is not available, agents run locally via Claude CLI.

## Commands

| Command | Description |
|---------|-------------|
| `ievo init` | Create a new project |
| `ievo add <agent>` | Install agent from marketplace |
| `ievo remove <agent>` | Remove an agent |
| `ievo update` | Update agents to latest |
| `ievo list` | Show installed agents |
| `ievo run <agent>` | Start agent session (Docker sandbox) |
| `ievo team <agents>` | Run Agent Teams (Phase 2) |
| `ievo learn log` | Show evolution history |
| `ievo learn push` | Share anonymized logs |
| `ievo dev new` | Scaffold new agent |

## Links

- [ievo.ai](https://ievo.ai)
- [Marketplace](https://github.com/ievo-ai/marketplace)
- [GitHub](https://github.com/ievo-ai)
