
Changelog
=========

0.0.1 (2024-10-18)
------------------

* First release on PyPI.
