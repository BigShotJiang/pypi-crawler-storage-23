from . import synthetic

__all__ = ["synthetic"]
