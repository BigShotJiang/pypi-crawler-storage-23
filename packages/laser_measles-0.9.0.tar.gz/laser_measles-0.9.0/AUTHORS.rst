
Authors
=======

* Christopher Lorton - https://www.idmod.org - `@clorton <https://github.com/clorton>`_
* Jonathan Bloedow - https://www.idmod.org - `@jonathanhhb <https://github.com/jonathanhhb>`_
* Katherine Rosenfeld - https://www.idmod.org - `@krosenfeld-IDM <https://github.com/krosenfeld-IDM>`_
* Kevin McCarthy - https://www.idmod.org - `KevinMcCarthyAtIDM <https://github.com/KevinMcCarthyAtIDM>`_
