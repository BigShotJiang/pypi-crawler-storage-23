"""Lazy file opener for map mode."""

from __future__ import annotations

import sys

from .lazy_proxy import LazyProxy


class LazyFile(LazyProxy):
    """Context manager that opens the file on first access."""

    __slots__ = ("_path", "_mode", "_kwargs", "_fd", "_closed", "_owns_fd")

    def __init__(self, path, mode="r", **kwargs):
        self._path = path
        self._mode = mode
        self._kwargs = kwargs
        self._fd = None
        self._closed = False
        self._owns_fd = False

    def _ensure_open(self):
        if self._closed:
            raise ValueError("I/O operation on closed file.")
        if self._fd is None:
            if self._path == "-":
                if "b" in self._mode and hasattr(sys.stdin, "buffer"):
                    self._fd = sys.stdin.buffer
                else:
                    self._fd = sys.stdin
                self._owns_fd = False
            else:
                self._fd = open(self._path, self._mode, **self._kwargs)
                self._owns_fd = True
        return self._fd

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        self._closed = True
        if self._fd is not None and self._owns_fd:
            self._fd.close()
        return False

    def _proxy_target(self):
        return self._ensure_open()

    def __next__(self):
        return next(self._proxy_target())
