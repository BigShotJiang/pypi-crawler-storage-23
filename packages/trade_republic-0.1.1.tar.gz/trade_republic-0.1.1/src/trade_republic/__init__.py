"""Trade Republic Python SDK."""

from trade_republic.tr_client import TRClient

__version__ = "0.1.1"

__all__ = ["TRClient"]
