"""
FeatrixSphere New API

A clean, object-oriented API for interacting with FeatrixSphere.

Usage:
    from featrixsphere.api import FeatrixSphere

    featrix = FeatrixSphere("https://sphere-api.featrix.com")

    # Create foundational model
    fm = featrix.create_foundational_model(
        name="my_model",
        data_file="data.csv"
    )
    fm.wait_for_training()

    # Create a binary classifier
    predictor = fm.create_binary_classifier(
        target_column="target",
        name="my_classifier"
    )
    predictor.wait_for_training()

    # Or a multiclass classifier
    predictor = fm.create_multi_classifier(
        target_column="category",
        name="my_multiclass"
    )
    predictor.wait_for_training()

    # Make predictions
    result = predictor.predict({"feature1": "value1"})
    print(result.predicted_class)
    print(result.confidence)
"""

from .exceptions import FeatrixAuthenticationError
from .client import FeatrixSphere
from .foundational_model import FoundationalModel
from .predictor import Predictor
from .published_predictor import PublishedPredictor
from .prediction_result import PredictionResult, PredictionFeedback
from .prediction_grid import PredictionGrid
from .vector_database import VectorDatabase
from .reference_record import ReferenceRecord
from .api_endpoint import APIEndpoint
from .notebook_helper import FeatrixNotebookHelper

__all__ = [
    'FeatrixAuthenticationError',
    'FeatrixSphere',
    'FoundationalModel',
    'Predictor',
    'PublishedPredictor',
    'PredictionResult',
    'PredictionFeedback',
    'PredictionGrid',
    'VectorDatabase',
    'ReferenceRecord',
    'APIEndpoint',
    'FeatrixNotebookHelper',
]
