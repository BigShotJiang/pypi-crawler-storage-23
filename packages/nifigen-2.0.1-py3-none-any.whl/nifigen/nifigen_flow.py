"""
NiFi Automation Library
=======================
This module provides a comprehensive set of functions for automating Apache NiFi
operations through the REST API. It includes functions for managing process groups,
processors, controller services, connections, and flow deployment.

Version: 1.0.0
Author: [Your Name/Organization]
"""

import requests

from nifigen.nifigen_comp import (
    add_handle_http_response,
    connect_components,
    create_execute_sql_processor,
    create_execute_stream_command,
    create_input_port,
    create_output_port,
    create_process_group_inside_pg,
    create_put_websocket,
    create_update_attribute_processor,
    create_update_record_processor,
    delete_all_connections_to_pg,
    delete_connection_by_id,
    delete_process_group,
    delete_processor_to_child_pg_connection,
    enable_controller_service,
    get_ports_in_process_group,
    get_processor_by_id,
    remove_route_on_attribute_rule,
    setup_avro_to_json_services,
    start_port_by_id,
    start_processor,
    stop_port_by_id,
    stop_process_group,
    stop_processor,
    create_process_orch_group,
    create_controller_service,
    import_controller_services,
    create_processor_in_pg,
    get_processor_by_type,
    bind_websocket_controller_service,
    create_connection
)

import time
import json
import uuid
import os
import logging
from typing import Dict, List, Optional, Any, Union, Tuple

# ---------------------------------------------------------------------------
# Logger setup - writes to file only, never touches stdout.
# Callers can override by reconfiguring the "nifigen" logger before use.
# ---------------------------------------------------------------------------
logger = logging.getLogger("nifigen")
if not logger.handlers:
    logger.setLevel(logging.DEBUG)
    _fh = logging.FileHandler("nifigen.log", encoding="utf-8")
    _fh.setLevel(logging.DEBUG)
    _fh.setFormatter(logging.Formatter(
        "%(asctime)s | %(levelname)-8s | %(funcName)s | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    ))
    logger.addHandler(_fh)
    logger.propagate = False          # don't bubble up to root logger




def recreate_process_group_flow(
    parent_pg_id: str,
    name: str,
    pg_json: Dict[str, Any],
    NIFI_URL: str,
    position: Tuple[int, int] = (0, 0),
    id_map: Optional[Dict[str, str]] = None,
    orch_dir: Optional[str] = None,
    ws_port:int = 7777,
    http_port=7778,
    verify_ssl: bool = False
) -> Dict[str, Any]:
    """
    Recreates a process group from exported JSON data.
    
    Args:
        parent_pg_id: Parent Process Group ID
        name: Process group name
        pg_json: Exported process group JSON data
        NIFI_URL: Base URL of the NiFi instance
        position: Canvas position (x, y)
        id_map: Dictionary for old_id -> new_id mapping
        orch_dir: Orchestration directory path
        
    Returns:
        Created process group details
    """
    try:
        if id_map is None:
            id_map = {}

        # Create the Process Group
       
        new_pg_result = create_process_orch_group(parent_pg_id, name, NIFI_URL, position, verify_ssl=verify_ssl)
        if not new_pg_result["status"]:
            return new_pg_result
            
        new_pg_id = new_pg_result["data"]["id"]
        
        # Define HTTP controller service for the new PG
        cs_def = {
            "name": "http_cs",
            "type": "org.apache.nifi.http.StandardHttpContextMap",
            "bundle": {
                'group': 'org.apache.nifi',
                'artifact': 'nifi-http-context-map-nar',
                'version': '2.7.2'
            },
            "properties": {"Request Expiration": "5 min"}
        }
        # create websc=ocket
        sc_cs={
                "type": "org.apache.nifi.websocket.jetty.JettyWebSocketServer",
                "bundle": {
                "group": "org.apache.nifi",
                "artifact": "nifi-websocket-services-jetty-nar",
                "version": "2.7.2"
                },
                "name": "JettyWebSocketServer",
                "properties": {
                "Input Buffer Size": "4 kb",
                "Max Text Message Size": "64 kb",
                "Max Binary Message Size": "64 kb",
                "Idle Timeout": "0 sec",
                "Port": ws_port,
                "SSL Context Service": None,
                "Client Authentication": "no",
                "Basic Authentication Enabled": "false",
                "Basic Authentication Path Spec": "/*",
                "Basic Authentication Roles": "**",
                "Login Service": "hash",
                "Users Properties File": None
                }
        }
        # Define JsonTreeReader controller service
        jt = {
            "type": "org.apache.nifi.json.JsonTreeReader",
            "bundle": {
                "group": "org.apache.nifi",
                "artifact": "nifi-record-serialization-services-nar",
                "version": "2.7.2"
            },
            "name": "JsonTreeReader_out",
            "properties": {
                "Schema Access Strategy": "infer-schema",
                "Schema Registry": None,
                "Schema Name": "${schema.name}",
                "Schema Version": None,
                "Schema Branch": None,
                "Schema Text": "${avro.schema}",
                "Schema Reference Reader": None,
                "Schema Inference Cache": None,
                "Starting Field Strategy": "ROOT_NODE",
                "Starting Field Name": None,
                "Schema Application Strategy": "SELECTED_PART",
                "Max String Length": "20 MB",
                "Allow Comments": "false",
                "Date Format": None,
                "Time Format": None,
                "Timestamp Format": None
            }
        }
        
        # Define JsonWriter controller service
        jwr = {
            "type": "org.apache.nifi.json.JsonRecordSetWriter",
            "bundle": {
                "group": "org.apache.nifi",
                "artifact": "nifi-record-serialization-services-nar",
                "version": "2.7.2"
            },
            "name": "JsonWriter_out",
            "properties": {
                "Schema Write Strategy": "no-schema",
                "Schema Cache": None,
                "Schema Reference Writer": None,
                "Schema Access Strategy": "inherit-record-schema",
                "Schema Registry": None,
                "Schema Name": "${schema.name}",
                "Schema Version": None,
                "Schema Branch": None,
                "Schema Text": "${avro.schema}",
                "Schema Reference Reader": None,
                "Date Format": None,
                "Time Format": None,
                "Timestamp Format": None,
                "Pretty Print JSON": "false",
                "Suppress Null Values": "never-suppress",
                "Allow Scientific Notation": "false",
                "Output Grouping": "output-array",
                "Compression Format": "none",
                "Compression Level": "1"
            }
        }
        
        # Map old PG ID to new PG ID
        id_map[pg_json["id"]] = new_pg_id
        logger.info(f"Created new PG: {name}, id={new_pg_id}")

        # Create HTTP controller service
        http_cs_result = create_controller_service(pg_id=new_pg_id, cs_def=cs_def, NIFI_URL=NIFI_URL, verify_ssl=verify_ssl)
        ws_cs_result = create_controller_service(pg_id=new_pg_id, cs_def=sc_cs, NIFI_URL=NIFI_URL, verify_ssl=verify_ssl)
        json_tree_reader_out = create_controller_service(pg_id=new_pg_id, cs_def=jt, NIFI_URL=NIFI_URL, verify_ssl=verify_ssl)
        json_wr_out = create_controller_service(pg_id=new_pg_id, cs_def=jwr, NIFI_URL=NIFI_URL, verify_ssl=verify_ssl)
        
        logger.info(f"Finishing cs ==> {http_cs_result['data']['id']}  ,{json_tree_reader_out['data']['id']},  {json_wr_out['data']['id']}")
        
        if not http_cs_result["status"]:
            return http_cs_result
        logger.info(f""" ws_cs_result

        {ws_cs_result}


        """)
        http_cs = http_cs_result["data"]
        ws_cs=ws_cs_result['data']
        json_tree_reader_out = json_tree_reader_out['data']
        json_wr_out = json_wr_out['data']
        
        # Enable all controller services
        enable_cs_result = enable_controller_service(cs_id=http_cs["id"], NIFI_URL=NIFI_URL, verify_ssl=verify_ssl)
        enable_ws_cs_result = enable_controller_service(cs_id=ws_cs["id"], NIFI_URL=NIFI_URL, verify_ssl=verify_ssl)
        enable_json_tree_reader_out_result = enable_controller_service(cs_id=json_tree_reader_out["id"], NIFI_URL=NIFI_URL, verify_ssl=verify_ssl)
        enable_json_wr_out_result = enable_controller_service(cs_id=json_wr_out["id"], NIFI_URL=NIFI_URL, verify_ssl=verify_ssl)
        
        logger.info(f"Finishing cs =enable=> {enable_cs_result['status']}  ,{enable_json_tree_reader_out_result['status']},  {enable_json_wr_out_result['status']}")
        
        if not enable_cs_result["status"]:
            logger.error(f"Warning: Failed to enable HTTP controller service")
        if not enable_json_tree_reader_out_result["status"]:
            logger.error(f"Warning: Failed to enable enable_json_tree_reader_out_result controller service")
        if not enable_json_wr_out_result["status"]:
            logger.error(f"Warning: Failed to enable enable_json_wr_out_result controller service")
            
        # Import additional controller services from file
        import_result = import_controller_services(
            pg_id=new_pg_id,
            file_path="/work/progs/nifi_aut/nifi_srv/nifi_aut/service_controller.json",
            NIFI_URL=NIFI_URL,
            verify_ssl=verify_ssl
        )
        
        if not import_result["status"]:
            logger.error(f"Warning: Failed to import some controller services")
            
        #cs_id = import_result.get("last_service_id")
        cs_id = ws_cs["id"]

        # Create orchestration directory if needed
        if orch_dir and not os.path.exists(f"{orch_dir}/{new_pg_id}"):
            os.makedirs(f"{orch_dir}/{new_pg_id}")

        # Recreate processors from JSON
        logger.info("################### Creating processors")
        for proc in pg_json["flow"]["processors"]:
            time.sleep(2)
            logger.info(f"-- Processing: {proc['component']['name']}")
            
            comp = proc["component"]
            
            # Apply modifications based on processor type
            if comp['type'] == 'org.apache.nifi.processors.websocket.ListenWebSocket':
                comp['config']['properties']['WebSocket Server Controller Service'] = cs_id
                
            if comp['type'] == 'org.apache.nifi.processors.standard.HandleHttpRequest':
                comp['config']['properties']['HTTP Context Map'] = http_cs["id"]
                comp['config']['properties']['Allowed Paths'] = "/" + name + "_hr"
                comp['config']['properties']['Listening Port']=http_port
                
            if comp['type'] == 'org.apache.nifi.processors.standard.ExecuteStreamCommand':
                comp["config"]["properties"]['Working Directory'] = f"{orch_dir}/{new_pg_id}"
                comp["config"]["properties"]['Command Arguments'] = f"main_orch.py"
                
            if comp['type'] == 'org.apache.nifi.processors.standard.EvaluateJsonPath':
                comp["config"]["properties"]['question'] = "$.question"
                comp["config"]["descriptors"]['question'] = {
                    "name": "question",
                    "displayName": "question",
                    "description": "",
                    "required": False,
                    "sensitive": False,
                    "dynamic": False,
                    "supportsEl": False,
                    "expressionLanguageScope": "Not Supported",
                    "dependencies": []
                }
                
            if comp['type'] == 'org.apache.nifi.processors.jolt.JoltTransformJSON':
                comp["config"]["properties"]['Jolt Specification'] = """[\n  {\n    \"operation\": \"shift\",\n    \"spec\": {\"question\": \"question\",\n      \"session_id\": \"session_id\",\n      \"timestamp\": \"timestamp\",\n      \"status\": \"status\",\n      \"sources\": \"sources\",\n      \"selected_agents\": \"selected_agents\",\"plan\": {\n        \"agents\": \"agent_plan\"\n      }\n    }\n  },\n  {\n    \"operation\": \"modify-overwrite-beta\",\n    \"spec\": {\n      \"agent_tmp\": \"=join('--,--', @(1,selected_agents))\"\n    }\n  },\n  {\n    \"operation\": \"modify-overwrite-beta\",\n    \"spec\": {\n      \"agent\": \"=concat('--', @(1,agent_tmp), '--')\"\n    }\n  },\n  {\n    \"operation\": \"remove\",\n    \"spec\": {\n      \"agent_tmp\": \"\"\n    }\n  }\n]"""

            # Create processor
            new_proc_result = create_processor_in_pg(new_pg_id, comp, NIFI_URL, verify_ssl=verify_ssl)
            if new_proc_result["status"]:
                id_map[comp["id"]] = new_proc_result["data"]["id"]

        # Recreate sub-groups recursively
        for sub_pg in pg_json["flow"]["processGroups"]:
            recreate_result = recreate_process_group_flow(
                new_pg_id,
                sub_pg["component"]["name"],
                sub_pg,
                position=(position[0] + 300, position[1] + 300),
                id_map=id_map,
                NIFI_URL=NIFI_URL,
                verify_ssl=verify_ssl
            )
            
            if not recreate_result["status"]:
                logger.error(f"Warning: Failed to recreate sub-group {sub_pg['component']['name']}")

        # Bind WebSocket controller service
        ws_cs_result = get_processor_by_type(
            pg_id=new_pg_id,
            processor_type="org.apache.nifi.processors.websocket.ListenWebSocket",
            NIFI_URL=NIFI_URL,
            verify_ssl=verify_ssl
        )
        
        if ws_cs_result["status"]:
            ws_cs = ws_cs_result["data"]
            bind_result = bind_websocket_controller_service(ws_cs["id"], cs_id, NIFI_URL, verify_ssl=verify_ssl)
            if not bind_result["status"]:
                logger.error(f"Warning: Failed to bind WebSocket controller service")

        # Recreate connections
        logger.info("START connections ###################")
        for conn in pg_json["flow"]["connections"]:
            # Map old source/destination IDs to new IDs
            src_old = conn["component"]["source"]["id"]
            dst_old = conn["component"]["destination"]["id"]

            # Skip connection if source or destination not in id_map yet
            if src_old not in id_map or dst_old not in id_map:
                logger.warning(f"Skipping connection {conn['component'].get('name', '')} because IDs not mapped yet")
                continue

            conn_copy = conn.copy()
            conn_copy["component"]["source"]["id"] = id_map[src_old]
            conn_copy["component"]["destination"]["id"] = id_map[dst_old]
            print(f"""create_conn_result""")
            create_conn_result = create_connection(new_pg_id, conn_copy, NIFI_URL, verify_ssl=verify_ssl)
            print(f"""create_conn_result 
            
            {create_conn_result}
            
            """)
            if not create_conn_result["status"]:
                logger.error(f"Warning: Failed to create connection")
                

        logger.info(f"json_tree_reader_out id: {json_tree_reader_out['id']}")
        logger.info(f"json_wr_out id: {json_wr_out['id']}")
        logger.info(f"http_cs id: {http_cs['id']}")

        return {
            "status": True, 
            "pg_id": new_pg_id, 
            "id_map": id_map,
            'http_cs': http_cs['id'],
            'json_tree_r_out': json_tree_reader_out['id'],
            'json_wr_out': json_wr_out['id']
        }
        
    except requests.exceptions.RequestException as e:
        logger.error(f"Network error recreating process group: {str(e)}")
        return {"status": False, "error": f"Network error: {str(e)}"}
    except KeyError as e:
        logger.error(f"Invalid JSON data recreating process group: {str(e)}")
        return {"status": False, "error": f"Invalid data: {str(e)}"}
    except Exception as e:
        logger.error(f"Unexpected error recreating process group: {str(e)}")
        return {"status": False, "error": f"Unexpected error: {str(e)}"}


def create_nifi_connection_ports_flow(
        source_id: str,
        source_group_id: str,
        source_name: str,
        source_type: str,
        destination_id: str,
        destination_group_id: str,
        destination_name: str,
        destination_type: str,
        parent_group_id: str,
        NIFI_URL: str,
        verify_ssl: bool = False
) -> Dict[str, Any]:
    """
    Creates a NiFi connection between source and destination components
    and starts Input/Output ports if applicable.

    Args:
        source_id: Source component ID
        source_group_id: Source process group ID
        source_name: Source component name
        source_type: Source type (INPUT_PORT, OUTPUT_PORT, PROCESSOR)
        destination_id: Destination component ID
        destination_group_id: Destination process group ID
        destination_name: Destination component name
        destination_type: Destination type (INPUT_PORT, OUTPUT_PORT, PROCESSOR)
        parent_group_id: Process group ID where connection is created
        NIFI_URL: Base NiFi API URL

    Returns:
        Dict with operation status and connection details
    """
    try:
        # Build connection payload
        connection_body = {
            "revision": {"version": 0},
            "component": {
                "parentGroupId": parent_group_id,
                "source": {
                    "id": source_id,
                    "type": source_type,
                    "groupId": source_group_id,
                    "name": source_name
                },
                "destination": {
                    "id": destination_id,
                    "type": destination_type,
                    "groupId": destination_group_id,
                    "name": destination_name
                },
                "backPressureObjectThreshold": 10000,
                "backPressureDataSizeThreshold": "1 GB",
                "flowFileExpiration": "0 sec",
                "loadBalanceStrategy": "DO_NOT_LOAD_BALANCE"
            }
        }

        # Create the connection
        url = f"{NIFI_URL}/process-groups/{parent_group_id}/connections"
        response = requests.post(url, json=connection_body, verify=verify_ssl)
        response.raise_for_status()

        connection = response.json()
        connection_id = connection["id"]

        logger.info(f"✔ Connection created: {connection_id}")

        # Start source port if needed
        if source_type in ("INPUT_PORT", "OUTPUT_PORT"):
            start_port_by_id(
                port_id=source_id,
                port_type="input-port" if source_type == "INPUT_PORT" else "output-port",
                NIFI_URL=NIFI_URL,
                verify_ssl=verify_ssl
            )
            start_port_by_id(
                port_id=destination_id,
                port_type="input-port" if source_type == "INPUT_PORT" else "output-port",
                NIFI_URL=NIFI_URL,
                verify_ssl=verify_ssl
            )

        # Start destination port if needed
        if destination_type in ("INPUT_PORT", "OUTPUT_PORT"):
            start_port_by_id(
                port_id=destination_id,
                port_type="input-port" if destination_type == "INPUT_PORT" else "output-port",
                NIFI_URL=NIFI_URL,
                verify_ssl=verify_ssl
            )

        return {
            "status": True,
            "connection_id": connection_id,
            "connection": connection
        }

    except requests.exceptions.RequestException as e:
        logger.error(f"❌ Network error creating NiFi connection: {str(e)}")
        return {
            "status": False,
            "error": f"Network error: {str(e)}"
        }
    except KeyError as e:
        logger.info(f"❌ Invalid configuration creating connection: {str(e)}")
        return {
            "status": False,
            "error": f"Invalid config: {str(e)}"
        }
    except Exception as e:
        logger.error(f"❌ Unexpected error creating NiFi connection: {str(e)}")
        return {
            "status": False,
            "error": f"Unexpected error: {str(e)}"
        }


def create_and_start_stream_flow_no_agent_flow(
    parent_pg_id: str,
    child_pg_name: str,
    NIFI_URL: str,
    ur_json_r: str,
    ur_json_wr: str,
    additional_attributes_update: Optional[Dict[str, str]] = {"agents_ops": """${agents_ops:isEmpty():ifElse("${RouteOnAttribute.Route}","${agents_ops}--${RouteOnAttribute.Route}")}"""},
    additional_ru_update: Optional[Dict[str, str]] = {"/agents_ops": """${agents_ops}"""},
    verify_ssl: bool = False
) -> Dict[str, Any]:
    """
    Creates a simple process group with input and output ports only (no agent processors).
    This is used for basic passthrough or routing flows.
    
    Args:
        parent_pg_id: Parent Process Group ID
        child_pg_name: Child process group name
        NIFI_URL: Base URL of the NiFi instance
        ur_json_r: JSON Reader controller service ID
        ur_json_wr: JSON Writer controller service ID
        additional_attributes_update: Additional attributes for UpdateAttribute processor
        additional_ru_update: Additional RecordPath updates for UpdateRecord processor
        
    Returns:
        Dictionary containing status and created component details
    """
    try:
        # Create child Process Group
        pg_result = create_process_group_inside_pg(
            parent_pg_id=parent_pg_id,
            name=child_pg_name,
            NIFI_URL=NIFI_URL,
            position=(200, 200),
            fail_if_exists=False,
            verify_ssl=verify_ssl
        )
        
        if not pg_result["status"]:
            return pg_result
            
        child_pg_id = pg_result["id"]

        # Create Input Port
        in_port_result = create_input_port(
            pg_id=child_pg_id,
            name="IN",
            NIFI_URL=NIFI_URL,
            position_id=0,
            verify_ssl=verify_ssl
        )

        if not in_port_result["status"]:
            return in_port_result
            
        in_port = in_port_result

        # Create UpdateAttribute processor
        update_attr_result = create_update_attribute_processor(
            pg_id=child_pg_id,
            name=f"{child_pg_name}_UpdateAttributes",
            NIFI_URL=NIFI_URL,
            position_id=1,
            additional_attributes=additional_attributes_update,
            verify_ssl=verify_ssl
        )
        
        if not update_attr_result["status"]:
            return update_attr_result
            
        update_attr = update_attr_result

        # Create UpdateRecord processor
        records_update_result = create_update_record_processor(
            pg_id=child_pg_id,
            name=f"{child_pg_name}_UpdateRecord",
            NIFI_URL=NIFI_URL,
            record_reader=ur_json_r,
            record_writer=ur_json_wr,
            record_properties=additional_ru_update,
            verify_ssl=verify_ssl
        )
        
        if not records_update_result["status"]:
            return records_update_result
            
        records_update = records_update_result

        # Create Output Port
        out_port_result = create_output_port(
            pg_id=child_pg_id,
            name="OUT",
            NIFI_URL=NIFI_URL,
            position_id=2,
            verify_ssl=verify_ssl
        )
        
        if not out_port_result["status"]:
            return out_port_result
            
        time.sleep(4)
        out_port = out_port_result
        
        logger.info("##start out connection ==")
        
        # Create connections between components
        connections = [
            connect_components(
                pg_id=child_pg_id,
                source_id=in_port["id"],
                source_type="INPUT_PORT",
                destination_id=update_attr['id'],
                destination_type="PROCESSOR",
                NIFI_URL=NIFI_URL,
                verify_ssl=verify_ssl
            ),
            connect_components(
                pg_id=child_pg_id,
                source_id=update_attr['id'],
                source_type="PROCESSOR",
                destination_id=records_update['id'],
                destination_type="PROCESSOR",
                relationships=["success"],
                NIFI_URL=NIFI_URL,
                verify_ssl=verify_ssl
            ),
            connect_components(
                 pg_id=child_pg_id,
                 source_id=records_update['id'],
                 source_type="PROCESSOR",
                 destination_id=out_port['id'],
                 destination_type="OUTPUT_PORT",
                 relationships=["success"],
                 NIFI_URL=NIFI_URL,
                 verify_ssl=verify_ssl
             )
        ]
        
        # Check connection results
        for conn_result in connections:
            time.sleep(2)
            if not conn_result["status"]:
                logger.error("Warning: Failed to create some connections")

        # Start input port
        try:
            logger.info(f"## Start input-port ++> {in_port['id']}")
            start_input_result = start_port_by_id(
                port_id=in_port["id"],
                port_type="input-port",
                NIFI_URL=NIFI_URL,
                verify_ssl=verify_ssl
            )
            if not start_input_result["status"]:
                logger.error(f"Warning: Failed to start input port: {start_input_result.get('error', 'Unknown error')}")
        except Exception as start_error:
            logger.error(f"Warning: Error starting input port: {str(start_error)}")

        # Start output port
        try:
            logger.info(f"## Start output-port ++> {out_port['id']}")
            start_output_result = start_port_by_id(
                port_id=out_port["id"],
                port_type="output-port",
                NIFI_URL=NIFI_URL,
                verify_ssl=verify_ssl
            )
            if not start_output_result["status"]:
                logger.error(f"Warning: Failed to start output port: {start_output_result.get('error', 'Unknown error')}")
        except Exception as start_error:
            logger.error(f"Warning: Error starting output port: {str(start_error)}")

        logger.info(f"✅ Created process group '{child_pg_name}' with input and output ports")

        return {
            "status": True,
            "process_group_id": child_pg_id,
            "process_group_name": child_pg_name,
            "input_port": {
                "id": in_port.get("id"),
                "name": in_port.get("name")
            },
            "output_port": {
                "id": out_port.get("id"),
                "name": out_port.get("name")
            },
            "message": f"Process group '{child_pg_name}' created successfully with input/output ports"
        }
        
    except requests.exceptions.RequestException as e:
        logger.error(f"Network error creating stream flow without agent: {str(e)}")
        return {"status": False, "error": f"Network error: {str(e)}"}
    except Exception as e:
        logger.error(f"Unexpected error creating stream flow without agent: {str(e)}")
        return {"status": False, "error": f"Unexpected error: {str(e)}"}


def create_and_enable_dbcp_service(
    pg_id: str,
    name: str,
    jdbc_url: str,
    driver_class: str,
    driver_location: str,
    username: str,
    password: str,
    NIFI_URL: str,
    max_total_connections: str = "10",
    verify_ssl: bool = False
) -> Dict[str, Any]:
    """
    Creates and enables a DBCPConnectionPool controller service.
    
    Args:
        pg_id: Process Group ID
        name: Service name
        jdbc_url: JDBC connection URL
        driver_class: Database driver class name
        driver_location: Database driver location path
        username: Database username
        password: Database password
        NIFI_URL: Base URL of the NiFi instance
        max_total_connections: Maximum connection pool size
        
    Returns:
        Controller service ID
    """
    try:
        # Check if service already exists
        r = requests.get(f"{NIFI_URL}/flow/process-groups/{pg_id}/controller-services", verify=verify_ssl)
        r.raise_for_status()

        # Search for existing service
        for cs in r.json().get("controllerServices", []):
            if cs["component"]["name"] == name:
                cs_id = cs["id"]
                logger.info(f"✔ Controller service '{name}' already exists")
                
                # Enable if not already enabled
                enable_result = enable_controller_service(cs_id, NIFI_URL, verify_ssl=verify_ssl)
                if not enable_result["status"]:
                    logger.error(f"Warning: Failed to enable existing service {cs_id}")
                    
                return {"status": True, "cs_id": cs_id}

        # Create new controller service
        payload = {
            "revision": {"version": 0},
            "component": {
                "type": "org.apache.nifi.dbcp.DBCPConnectionPool",
                "name": name,
                "properties": {
                    "Database Connection URL": jdbc_url,
                    "Database Driver Class Name": driver_class,
                    "Database Driver Locations": driver_location,
                    "Database User": username,
                    "Password": password,
                    "Max Total Connections": max_total_connections
                }
            }
        }

        r = requests.post(
            f"{NIFI_URL}/process-groups/{pg_id}/controller-services",
            json=payload,
            verify=verify_ssl
        )
        r.raise_for_status()

        cs_id = r.json()["id"]
        logger.info(f"✔ Created controller service '{name}'")

        # Enable the new controller service
        enable_result = enable_controller_service(cs_id, NIFI_URL, verify_ssl=verify_ssl)
        if not enable_result["status"]:
            logger.error(f"Warning: Failed to enable new service {cs_id}")

        return {"status": True, "cs_id": cs_id}
    except requests.exceptions.RequestException as e:
        logger.error(f"Network error creating and enabling DBCP service: {str(e)}")
        return {"status": False, "error": f"Network error: {str(e)}"}
    except KeyError as e:
        logger.info(f"Invalid configuration creating DBCP service: {str(e)}")
        return {"status": False, "error": f"Invalid config: {str(e)}"}
    except Exception as e:
        logger.error(f"Unexpected error creating and enabling DBCP service: {str(e)}")
        return {"status": False, "error": f"Unexpected error: {str(e)}"}


def create_sql_to_json_jsonfile_flow(
    pg_id: str,
    sql_name: str,
    sql_query: str,
    dbcp_id: str,
    output_dir: str,
    output_filename: str,
    NIFI_URL: str,
    position_x: float = 0,
    position_y: float = 0,
    run_every_minutes: int = 10,
    start: bool = True,
    verify_ssl: bool = False
) -> Dict[str, Any]:
    """
    Creates a complete SQL to JSON file flow in NiFi.
    
    Args:
        pg_id: Process Group ID
        sql_name: SQL processor name
        sql_query: SQL query to execute
        dbcp_id: DBCP connection pool service ID
        output_dir: Output directory path
        output_filename: Output filename
        NIFI_URL: Base URL of the NiFi instance
        position_x: Starting X position
        position_y: Starting Y position
        run_every_minutes: Scheduling interval in minutes
        start: Whether to start processors immediately
        
    Returns:
        Flow creation status and component IDs
    """
    try:

        # Setup Avro to JSON controller services
        services_result = setup_avro_to_json_services(pg_id, NIFI_URL, verify_ssl=verify_ssl)
        if not services_result["status"]:
            return services_result
            

        avro_reader_id = services_result["avro_reader_id"]

        json_writer_id = services_result["json_writer_id"]

        
        # Create ExecuteSQL processor
        exec_sql_result = create_execute_sql_processor(
            pg_id=pg_id,
            name=sql_name,
            position_x=position_x,
            position_y=position_y,
            dbcp_id=dbcp_id,
            sql_query=sql_query,
            run_every_minutes=run_every_minutes,
            start=False,
            NIFI_URL=NIFI_URL,
            verify_ssl=verify_ssl
        )
        
        if not exec_sql_result["status"]:
            return exec_sql_result
            
        exec_sql_proc_id = exec_sql_result["processor_id"]
        
        # Create ConvertRecord processor (Avro → JSON)
        convert_payload = {
            "revision": {"version": 0},
            "component": {
                "type": "org.apache.nifi.processors.standard.ConvertRecord",
                "name": f"{sql_name}_AvroToJson",
                "position": {"x": position_x + 300, "y": position_y},
                "config": {
                    "properties": {
                        "Record Reader": avro_reader_id,
                        "Record Writer": json_writer_id
                    },
                    "autoTerminatedRelationships": ["failure"]
                }
            }
        }
        
        r = requests.post(
            f"{NIFI_URL}/process-groups/{pg_id}/processors",
            json=convert_payload,
            verify=verify_ssl
        )
        r.raise_for_status()
        convert_proc_id = r.json()["id"]
        
        # Create UpdateAttribute processor (set filename)
        update_attr_payload = {
            "revision": {"version": 0},
            "component": {
                "type": "org.apache.nifi.processors.attributes.UpdateAttribute",
                "name": f"{sql_name}_SetFilename",
                "position": {"x": position_x + 450, "y": position_y},
                "config": {
                    "properties": {
                        "filename": output_filename
                    },
                    "autoTerminatedRelationships": ["failure"]
                }
            }
        }
        
        r = requests.post(
            f"{NIFI_URL}/process-groups/{pg_id}/processors",
            json=update_attr_payload,
            verify=verify_ssl
        )
        r.raise_for_status()
        update_attr_id = r.json()["id"]
        
        # Create PutFile processor
        putfile_payload = {
            "revision": {"version": 0},
            "component": {
                "type": "org.apache.nifi.processors.standard.PutFile",
                "name": f"{sql_name}_PutFile",
                "position": {"x": position_x + 650, "y": position_y},
                "config": {
                    "properties": {
                        "Directory": output_dir + "/" + pg_id,
                        "Conflict Resolution Strategy": "replace",
                        "Create Missing Directories": "true"
                    },
                    "autoTerminatedRelationships": ["failure", "success"]
                }
            }
        }
        
        r = requests.post(
            f"{NIFI_URL}/process-groups/{pg_id}/processors",
            json=putfile_payload,
            verify=verify_ssl
        )
        r.raise_for_status()
        putfile_id = r.json()["id"]

        # Create connections between processors
        connections = [
            # ExecuteSQL → ConvertRecord
            connect_components(
                pg_id=pg_id,
                source_id=exec_sql_proc_id,
                source_type="PROCESSOR",
                destination_id=convert_proc_id,
                destination_type="PROCESSOR",
                relationships=["success"],
                NIFI_URL=NIFI_URL,
                verify_ssl=verify_ssl
            ),
            # ConvertRecord → UpdateAttribute
            connect_components(
                pg_id=pg_id,
                source_id=convert_proc_id,
                source_type="PROCESSOR",
                destination_id=update_attr_id,
                destination_type="PROCESSOR",
                relationships=["success"],
                NIFI_URL=NIFI_URL,
                verify_ssl=verify_ssl
            ),
            # UpdateAttribute → PutFile
            connect_components(
                pg_id=pg_id,
                source_id=update_attr_id,
                source_type="PROCESSOR",
                destination_id=putfile_id,
                destination_type="PROCESSOR",
                relationships=["success"],
                NIFI_URL=NIFI_URL,
                verify_ssl=verify_ssl
            )
        ]
        
        # Check if any connection failed
        for conn_result in connections:
            if not conn_result["status"]:
                logger.error("Warning: Failed to create some connections")

        # Start processors if requested
        if start:
            processor_ids = [exec_sql_proc_id, convert_proc_id, update_attr_id, putfile_id]
            for pid in processor_ids:
                proc_result = get_processor_by_id(pid, NIFI_URL, verify_ssl=verify_ssl)
                if proc_result["status"]:
                    start_result = start_processor(pid, NIFI_URL, verify_ssl=verify_ssl)
                    if not start_result["status"]:
                        logger.error(f"Warning: Failed to start processor {pid}")

        return {
            "status": True,
            "pg_id": pg_id,
            "processors": {
                "execute_sql": exec_sql_proc_id,
                "convert_record": convert_proc_id,
                "update_attribute": update_attr_id,
                "putfile": putfile_id
            },
            "output": {
                "directory": output_dir,
                "filename": output_filename
            }
        }
    except requests.exceptions.RequestException as e:
        logger.error(f"Network error creating SQL to JSON file flow: {str(e)}")
        return {"status": False, "error": f"Network error: {str(e)}"}
    except KeyError as e:
        logger.info(f"Invalid configuration creating SQL to JSON flow: {str(e)}")
        return {"status": False, "error": f"Invalid config: {str(e)}"}
    except Exception as e:
        logger.error(f"Unexpected error creating SQL to JSON file flow: {str(e)}")
        return {"status": False, "error": f"Unexpected error: {str(e)}"}


def create_and_start_stream_flow(
    parent_pg_id: str,
    child_pg_name: str,
    command: str,
    http_cs_id: str,
    NIFI_URL: str,
    additional_attributes: Optional[Dict[str, str]],
    command_arguments: str = "",
    working_dir: str = "",
    verify_ssl: bool = False
) -> Dict[str, Any]:
    """
    Creates and starts a complete stream processing flow.
    
    Args:
        parent_pg_id: Parent Process Group ID
        child_pg_name: Child process group name
        command: Command to execute
        http_cs_id: HTTP context map controller service ID
        NIFI_URL: Base URL of the NiFi instance
        additional_attributes: Additional attributes for UpdateAttribute processor
        command_arguments: Command arguments
        working_dir: Working directory
        
    Returns:
        Flow creation status and component IDs
    """
    try:
        # Create child Process Group
        pg_result = create_process_group_inside_pg(
            parent_pg_id=parent_pg_id,
            name=child_pg_name,
            NIFI_URL=NIFI_URL,
            position=(200, 200),
            fail_if_exists=False,
            verify_ssl=verify_ssl
        )
        
        if not pg_result["status"]:
            return pg_result
            
        child_pg_id = pg_result["id"]

        # Create Input Port
        in_port_result = create_input_port(
            pg_id=child_pg_id,
            name="IN",
            NIFI_URL=NIFI_URL,
            position_id=0,
            verify_ssl=verify_ssl
        )
        
        if not in_port_result["status"]:
            return in_port_result
            
        in_port = in_port_result
        
        # Create UpdateAttribute processor
        update_attr_result = create_update_attribute_processor(
            pg_id=child_pg_id,
            name=f"{child_pg_name}_UpdateAttributes",
            NIFI_URL=NIFI_URL,
            position_id=1,
            additional_attributes=additional_attributes,
            verify_ssl=verify_ssl
        )
        
        if not update_attr_result["status"]:
            return update_attr_result
            
        update_attr = update_attr_result
        
        # Create ExecuteStreamCommand processor
        exec_proc_result = create_execute_stream_command(
            pg_id=child_pg_id,
            NIFI_URL=NIFI_URL,
            name="Execute_Command",
            command=command,
            command_arguments=command_arguments,
            working_dir=working_dir,
            position_id=1,
            verify_ssl=verify_ssl
        )
        
        if not exec_proc_result["status"]:
            return exec_proc_result
            
        exec_proc = exec_proc_result

        # Create Output Port
        out_port_result = create_output_port(
            pg_id=child_pg_id,
            name="OUT",
            NIFI_URL=NIFI_URL,
            position_id=2,
            verify_ssl=verify_ssl
        )
        
        if not out_port_result["status"]:
            return out_port_result
            
        out_port = out_port_result

        # Create PutWebSocket processor
        ws_out_result = create_put_websocket(
            pg_id=child_pg_id,
            name=child_pg_name + "_WS_out",
            NIFI_URL=NIFI_URL,
            comp={
                "WebSocket Session Id": "${websocket.session.id}",
                "WebSocket Controller Service Id": "${websocket.controller.service.id}",
                "WebSocket Endpoint Id": "${websocket.endpoint.id}",
                "WebSocket Message Type": "TEXT"
            },
            verify_ssl=verify_ssl
        )
        
        if not ws_out_result["status"]:
            return ws_out_result
            
        ws_out = ws_out_result["data"]

        # Create HandleHttpResponse processor
        http_res_result = add_handle_http_response(
            pg_id=child_pg_id,
            processor_name=child_pg_name,
            NIFI_URL=NIFI_URL,
            http_cs_id=http_cs_id,
            verify_ssl=verify_ssl
        )
        
        if not http_res_result["status"]:
            return http_res_result
            
        http_res = http_res_result["data"]

        # Create connections between components
        connections = [
            # Input Port → UpdateAttribute
            connect_components(
                pg_id=child_pg_id,
                source_id=in_port["id"],
                source_type="INPUT_PORT",
                destination_id=update_attr["id"],
                destination_type="PROCESSOR",
                NIFI_URL=NIFI_URL,
                verify_ssl=verify_ssl
            ),
            # UpdateAttribute → ExecuteStreamCommand
            connect_components(
                pg_id=child_pg_id,
                source_id=update_attr["id"],
                source_type="PROCESSOR",
                destination_id=exec_proc["id"],
                destination_type="PROCESSOR",
                relationships=["success"],
                NIFI_URL=NIFI_URL,
                verify_ssl=verify_ssl
            ),
            # ExecuteStreamCommand → Output Port
            connect_components(
                pg_id=child_pg_id,
                source_id=exec_proc["id"],
                source_type="PROCESSOR",
                destination_id=out_port["id"],
                destination_type="OUTPUT_PORT",
                relationships=["output stream"],
                NIFI_URL=NIFI_URL,
                verify_ssl=verify_ssl
            ),
            # ExecuteStreamCommand → PutWebSocket
            connect_components(
                pg_id=child_pg_id,
                source_id=exec_proc["id"],
                source_type="PROCESSOR",
                destination_id=ws_out["id"],
                destination_type="PROCESSOR",
                relationships=["output stream"],
                NIFI_URL=NIFI_URL,
                verify_ssl=verify_ssl
            ),
            # ExecuteStreamCommand → HandleHttpResponse
            connect_components(
                pg_id=child_pg_id,
                source_id=exec_proc["id"],
                source_type="PROCESSOR",
                destination_id=http_res["id"],
                destination_type="PROCESSOR",
                relationships=["output stream"],
                NIFI_URL=NIFI_URL,
                verify_ssl=verify_ssl
            )
        ]
        
        # Check connection results
        for conn_result in connections:
            if not conn_result["status"]:
                logger.error("Warning: Failed to create some connections")

        # Start processors
        time.sleep(4)
        start_results = [
            start_processor(exec_proc['id'], NIFI_URL, verify_ssl=verify_ssl),
            start_processor(ws_out['id'], NIFI_URL, verify_ssl=verify_ssl),
            start_processor(http_res['id'], NIFI_URL, verify_ssl=verify_ssl),
            start_processor(update_attr['id'], NIFI_URL, verify_ssl=verify_ssl),
        ]
        
        for start_result in start_results:
            if not start_result["status"]:
                logger.error("Warning: Failed to start some processors")

        logger.info("✅ Flow created, connected, and started successfully")

        return {
            "status": True,
            "process_group_id": child_pg_id,
            "input_port": in_port,
            "processor": exec_proc,
            "output_port": out_port,
            "websocket_out": ws_out,
            "http_response": http_res,
            "update_attribute": update_attr,
        }
    except requests.exceptions.RequestException as e:
        logger.error(f"Network error creating and starting stream flow: {str(e)}")
        return {"status": False, "error": f"Network error: {str(e)}"}
    except KeyError as e:
        logger.info(f"Invalid configuration creating stream flow: {str(e)}")
        return {"status": False, "error": f"Invalid config: {str(e)}"}
    except Exception as e:
        logger.error(f"Unexpected error creating and starting stream flow: {str(e)}")
        return {"status": False, "error": f"Unexpected error: {str(e)}"}


def remove_agent(
    parent_pg_id: str,
    agent_pg_id: str,
    router_id: str,
    rule_name: str,
    out_input_port: str,
    out_con_id: str,
    NIFI_URL: str,
    verify_ssl: bool = False
) -> Dict[str, Any]:
    """
    Removes an agent from the flow by stopping components and deleting connections.
    
    Args:
        parent_pg_id: Parent Process Group ID
        agent_pg_id: Agent Process Group ID to remove
        router_id: Router processor ID
        rule_name: RouteOnAttribute rule name to remove
        out_input_port: Output input port ID
        out_con_id: Output connection ID
        NIFI_URL: Base URL of the NiFi instance
        
    Returns:
        Operation status
    """
    try:
        # Stop the agent process group
        stop_pg_result = stop_process_group(agent_pg_id, NIFI_URL, verify_ssl=verify_ssl)
        if not stop_pg_result["status"]:
            logger.error(f"Warning: Failed to stop process group {agent_pg_id}")

        # Stop the router processor
        stop_router_result = stop_processor(router_id, NIFI_URL, verify_ssl=verify_ssl)
        if not stop_router_result["status"]:
            logger.error(f"Warning: Failed to stop router processor {router_id}")
            
        # Get and stop all ports in the agent PG
        ports = get_ports_in_process_group(process_group_id=agent_pg_id, NIFI_URL=NIFI_URL, verify_ssl=verify_ssl)
        logger.info(f"Ports found: {len(ports) if isinstance(ports, list) else ports}")
        for i in ports:
            stop_port_by_id(port_id=i['port_id'], port_type=str(i['port_type']).lower().strip(), NIFI_URL=NIFI_URL, verify_ssl=verify_ssl)
            
        # Stop output input port
        stop_port_by_id(port_id=out_input_port, port_type='input_port', NIFI_URL=NIFI_URL, verify_ssl=verify_ssl)
        
        # Remove output connection
        logger.info(f"Removing out connection: {out_con_id}")
        delete_connection_by_id(connection_id=out_con_id, NIFI_URL=NIFI_URL, verify_ssl=verify_ssl)
        
        # Remove the route rule
        remove_rule_result = remove_route_on_attribute_rule(
            route_proc_id=router_id,
            rule_name=rule_name,
            NIFI_URL=NIFI_URL,
            verify_ssl=verify_ssl
        )
        if not remove_rule_result["status"]:
            logger.error(f"Warning: Failed to remove rule {rule_name}")
            
        # Delete all connections to the agent PG
        delete_conns_result = delete_all_connections_to_pg(agent_pg_id, NIFI_URL, verify_ssl=verify_ssl)
        if not delete_conns_result["status"]:
            logger.error(f"Warning: Failed to delete some connections to PG {agent_pg_id}")

        # Delete specific processor to child PG connection
        delete_proc_conn_result = delete_processor_to_child_pg_connection(
            parent_pg_id=parent_pg_id,
            processor_id=router_id,
            child_pg_id=agent_pg_id,
            NIFI_URL=NIFI_URL,
            verify_ssl=verify_ssl
        )
        if not delete_proc_conn_result["status"]:
            logger.error(f"Warning: Failed to delete processor to child PG connection")

        # Delete the agent process group
        delete_pg_result = delete_process_group(agent_pg_id, NIFI_URL, verify_ssl=verify_ssl)
        if not delete_pg_result["status"]:
            return delete_pg_result

        # Restart the router processor
        start_router_result = start_processor(router_id, NIFI_URL, verify_ssl=verify_ssl)
        for i in ports:
            #stop_port_by_id(port_id=i['port_id'], port_type=str(i['port_type']).lower().strip(), NIFI_URL=NIFI_URL, verify_ssl=verify_ssl)
            start_port_by_id(port_id=i['port_id'], port_type=str(i['port_type']).lower().strip(), NIFI_URL=NIFI_URL, verify_ssl=verify_ssl)
        # Stop output input port
        start_port_by_id(port_id=out_input_port, port_type='input_port', NIFI_URL=NIFI_URL, verify_ssl=verify_ssl)
        if not start_router_result["status"]:
            logger.error(f"Warning: Failed to restart router processor {router_id}")

        return {"status": True, "message": f"Agent {agent_pg_id} removed successfully"}
    except requests.exceptions.RequestException as e:
        logger.error(f"Network error removing agent: {str(e)}")
        return {"status": False, "error": f"Network error: {str(e)}"}
    except KeyError as e:
        logger.error(f"Invalid response removing agent: {str(e)}")
        return {"status": False, "error": f"Invalid response: {str(e)}"}
    except Exception as e:
        logger.error(f"Unexpected error removing agent: {str(e)}")
        return {"status": False, "error": f"Unexpected error: {str(e)}"}




