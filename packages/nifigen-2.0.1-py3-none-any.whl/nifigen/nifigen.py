"""
NiFi Automation Library
=======================
This module provides a comprehensive set of functions for automating Apache NiFi
operations through the REST API. It includes functions for managing process groups,
processors, controller services, connections, and flow deployment.

Version: 1.0.0
Author: [Your Name/Organization]
"""

import requests
import time
import json
import uuid
import os
import logging
from typing import Dict, List, Optional, Any, Union, Tuple

# ---------------------------------------------------------------------------
# Logger setup - writes to file only, never touches stdout.
# Callers can override by reconfiguring the "nifigen" logger before use.
# ---------------------------------------------------------------------------
logger = logging.getLogger("nifigen")
if not logger.handlers:
    logger.setLevel(logging.DEBUG)
    _fh = logging.FileHandler("nifigen.log", encoding="utf-8")
    _fh.setLevel(logging.DEBUG)
    _fh.setFormatter(logging.Formatter(
        "%(asctime)s | %(levelname)-8s | %(funcName)s | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    ))
    logger.addHandler(_fh)
    logger.propagate = False          # don't bubble up to root logger



def get_processor_stats(pg_id: str, NIFI_URL: str) -> Dict[str, Any]:
    """
    Retrieves processor statistics for a given process group.
    
    Args:
        pg_id: Process Group ID
        NIFI_URL: Base URL of the NiFi instance
        
    Returns:
        Dictionary containing counts of running, stopped, and total processors
        or error status if exception occurs
        
    Raises:
        requests.exceptions.RequestException: If API call fails
    """
    try:
        # Fetch process group details from NiFi API
        r = requests.get(f"{NIFI_URL}/flow/process-groups/{pg_id}")
        r.raise_for_status()

        # Extract processors from the response
        processors = r.json()["processGroupFlow"]["flow"].get("processors", [])

        running = 0
        stopped = 0

        # Count running and stopped processors
        for p in processors:
            state = p["component"].get("state")
            if state == "RUNNING":
                running += 1
            else:
                stopped += 1

        return {
            "status": True,
            "running": running,
            "stopped": stopped,
            "total": len(processors)
        }
    except requests.exceptions.RequestException as e:
        logger.error(f"Network error getting processor stats for PG {pg_id}: {str(e)}")
        return {"status": False, "error": f"Network error: {str(e)}"}
    except KeyError as e:
        logger.error(f"Invalid response format for processor stats: {str(e)}")
        return {"status": False, "error": f"Invalid response format: {str(e)}"}
    except Exception as e:
        logger.error(f"Unexpected error getting processor stats for PG {pg_id}: {str(e)}")
        return {"status": False, "error": f"Unexpected error: {str(e)}"}


def get_root_flows(NIFI_URL: str) -> Dict[str, Any]:
    """
    Retrieves all flows under the ROOT process group with processor statistics.
    
    Args:
        NIFI_URL: Base URL of the NiFi instance
        
    Returns:
        Dictionary containing flow details including process groups, processors,
        input ports, and output ports with their states
    """
    try:
        url = f"{NIFI_URL}/flow/process-groups/root"
        r = requests.get(url)
        r.raise_for_status()

        data = r.json()["processGroupFlow"]
        flow = data["flow"]

        results = []

        # Process Groups with processor stats
        for pg in flow.get("processGroups", []):
            comp = pg["component"]

            stats = get_processor_stats(comp["id"], NIFI_URL)
            s_status = comp.get("state")
            if stats["running"] == stats["total"]:
                s_status = "RUNNING"

            results.append({
                "id": comp["id"],
                "name": comp["name"],
                "type": "PROCESS_GROUP",
                "state": s_status or comp.get("statelessGroupScheduledState"),
                "processors": {
                    "running": stats["running"],
                    "stopped": stats["stopped"],
                    "total": stats["total"]
                }
            })

        # Processors directly under ROOT
        for p in flow.get("processors", []):
            comp = p["component"]
            results.append({
                "id": comp["id"],
                "name": comp["name"],
                "type": "PROCESSOR",
                "state": comp.get("state")
            })

        # Input Ports
        for ip in flow.get("inputPorts", []):
            comp = ip["component"]
            results.append({
                "id": comp["id"],
                "name": comp["name"],
                "type": "INPUT_PORT",
                "state": comp.get("state")
            })

        # Output Ports
        for op in flow.get("outputPorts", []):
            comp = op["component"]
            results.append({
                "id": comp["id"],
                "name": comp["name"],
                "type": "OUTPUT_PORT",
                "state": comp.get("state")
            })

        return {
            "status": True,
            "root_id": data["id"],
            "flows": results
        }
    except requests.exceptions.RequestException as e:
        logger.error(f"Network error getting root flows: {str(e)}")
        return {"status": False, "error": f"Network error: {str(e)}"}
    except KeyError as e:
        logger.error(f"Invalid response format for root flows: {str(e)}")
        return {"status": False, "error": f"Invalid response format: {str(e)}"}
    except Exception as e:
        logger.error(f"Unexpected error getting root flows: {str(e)}")
        return {"status": False, "error": f"Unexpected error: {str(e)}"}


def controller_service_exists(pg_id: str, name: str, NIFI_URL: str) -> Optional[Dict[str, Any]]:
    """
    Checks if a controller service exists by name in a process group.
    
    Args:
        pg_id: Process Group ID
        name: Controller service name
        NIFI_URL: Base URL of the NiFi instance
        
    Returns:
        Controller service entity if found, None otherwise
    """
    try:
        # Fetch controller services from the process group
        r = requests.get(f"{NIFI_URL}/flow/process-groups/{pg_id}/controller-services")
        r.raise_for_status()
        
        # Search for service by name
        for cs in r.json()["controllerServices"]:
            if cs["component"]["name"] == name:
                return cs
        return None
    except requests.exceptions.RequestException as e:
        logger.error(f"Network error checking controller service existence: {str(e)}")
        return None
    except KeyError as e:
        logger.error(f"Invalid response format checking controller service: {str(e)}")
        return None
    except Exception as e:
        logger.error(f"Unexpected error checking controller service existence: {str(e)}")
        return None


def create_controller_service(pg_id: str, cs_def: Dict[str, Any], NIFI_URL: str) -> Dict[str, Any]:
    """
    Creates a new controller service in a process group.
    
    Args:
        pg_id: Process Group ID
        cs_def: Controller service definition dictionary
        NIFI_URL: Base URL of the NiFi instance
        
    Returns:
        Created controller service entity or existing one if already present
    """
    logger.info(f"""
    Created controller 

    {cs_def}
    
    """)
    try:
        # Check if service already exists
        existing = controller_service_exists(pg_id, cs_def["name"], NIFI_URL)
        if existing:
            logger.info(f"Controller service '{cs_def['name']}' already exists")
            return {"status": True, "data": existing, "message": "Service already exists"}

        # Prepare payload for new controller service
        payload = {
            "revision": {"version": 0},
            "component": {
                "type": cs_def["type"],
                "bundle": cs_def["bundle"],
                "name": cs_def["name"],
                "properties": cs_def["properties"],
                "comments": cs_def.get("comments", "")
            }
        }

        # Create controller service via API
        r = requests.post(
            f"{NIFI_URL}/process-groups/{pg_id}/controller-services",
            json=payload
        )

        # Handle conflict (service already exists)
        if r.status_code == 409:
            #logger.info("NiFi error:", r.text)
            return {"status": False, "error": r.text}

        r.raise_for_status()
        return {"status": True, "data": r.json()}
    except requests.exceptions.RequestException as e:
        logger.error(f"Network error creating controller service: {str(e)}")
        return {"status": False, "error": f"Network error: {str(e)}"}
    except KeyError as e:
        logger.info(f"Invalid controller service definition: {str(e)}")
        return {"status": False, "error": f"Invalid definition: {str(e)}"}
    except Exception as e:
        logger.error(f"Unexpected error creating controller service: {str(e)}")
        return {"status": False, "error": f"Unexpected error: {str(e)}"}


def create_process_orch_group(parent_pg_id: str, name: str, NIFI_URL: str, 
                             position: Tuple[int, int] = (200, 200)) -> Dict[str, Any]:
    """
    Creates a new process group with orchestration naming convention.
    
    Args:
        parent_pg_id: Parent Process Group ID
        name: Base name for the process group
        NIFI_URL: Base URL of the NiFi instance
        position: Canvas position (x, y)
        
    Returns:
        Created process group entity
    """
    try:
        url = f"{NIFI_URL}/process-groups/{parent_pg_id}/process-groups"
        payload = {
            "revision": {"version": 0},
            "component": {
                "name": f"{name}_orch",
                "position": {"x": position[0], "y": position[1]}
            }
        }
        r = requests.post(url, json=payload)
        r.raise_for_status()
        return {"status": True, "data": r.json()}
    except requests.exceptions.RequestException as e:
        logger.error(f"Network error creating process group: {str(e)}")
        return {"status": False, "error": f"Network error: {str(e)}"}
    except Exception as e:
        logger.error(f"Unexpected error creating process group: {str(e)}")
        return {"status": False, "error": f"Unexpected error: {str(e)}"}


def enable_controller_service(cs_id: str, NIFI_URL: str) -> Dict[str, Any]:
    """
    Enables a controller service by ID.
    
    Args:
        cs_id: Controller Service ID
        NIFI_URL: Base URL of the NiFi instance
        
    Returns:
        Updated controller service entity
    """
    try:
        # Get fresh revision to avoid version conflicts
        r = requests.get(f"{NIFI_URL}/controller-services/{cs_id}")
        r.raise_for_status()
        
        rev = r.json()["revision"]["version"]

        # Prepare payload to enable service
        payload = {
            "revision": {"version": rev},
            "component": {"id": cs_id, "state": "ENABLED"}
        }
        
        r2 = requests.put(
            f"{NIFI_URL}/controller-services/{cs_id}",
            json=payload
        )
        
        #logger.info("Enable response:", r2.text)
        return {"status": True, "data": r2.json()}
    except requests.exceptions.RequestException as e:
        logger.error(f"Network error enabling controller service: {str(e)}")
        return {"status": False, "error": f"Network error: {str(e)}"}
    except KeyError as e:
        logger.info(f"Invalid controller service response: {str(e)}")
        return {"status": False, "error": f"Invalid response: {str(e)}"}
    except Exception as e:
        logger.error(f"Unexpected error enabling controller service: {str(e)}")
        return {"status": False, "error": f"Unexpected error: {str(e)}"}


def import_controller_services(pg_id: str, file_path: str, NIFI_URL: str) -> Dict[str, Any]:
    """
    Imports controller services from a JSON file.
    
    Args:
        pg_id: Process Group ID
        file_path: Path to JSON file containing service definitions
        NIFI_URL: Base URL of the NiFi instance
        
    Returns:
        Dictionary with status and created/enabled services
    """
    try:
        # Load service definitions from JSON file
        with open(file_path) as f:
            services = json.load(f)

        created = []
        # Create each controller service
        for cs in services:
            cs_entity = create_controller_service(pg_id, cs, NIFI_URL)
            if cs_entity["status"]:
                created.append(cs_entity["data"])
            else:
                logger.error(f"Failed to create service: {cs['name']}")

        # Enable all created services
        for cs in created:
            enable_result = enable_controller_service(cs["id"], NIFI_URL)
            if not enable_result["status"]:
                logger.error(f"Failed to enable service: {cs['id']}")

        return {"status": True, "created_services": created, "last_service_id": cs["id"] if created else None}
    except FileNotFoundError as e:
        logger.error(f"Controller services file not found: {str(e)}")
        return {"status": False, "error": f"File not found: {str(e)}"}
    except json.JSONDecodeError as e:
        logger.error(f"Invalid JSON in controller services file: {str(e)}")
        return {"status": False, "error": f"Invalid JSON: {str(e)}"}
    except requests.exceptions.RequestException as e:
        logger.error(f"Network error importing controller services: {str(e)}")
        return {"status": False, "error": f"Network error: {str(e)}"}
    except Exception as e:
        logger.error(f"Unexpected error importing controller services: {str(e)}")
        return {"status": False, "error": f"Unexpected error: {str(e)}"}


def create_processor_in_pg(pg_id: str, comp: Dict[str, Any], NIFI_URL: str) -> Dict[str, Any]:
    """
    Creates a processor in a process group using component definition.
    
    Args:
        pg_id: Process Group ID
        comp: Processor component definition
        NIFI_URL: Base URL of the NiFi instance
        
    Returns:
        Created processor entity
    """
    try:
        # Wait to avoid rate limiting
        time.sleep(4)
        url = f"{NIFI_URL}/process-groups/{pg_id}/processors"
        payload = {
            "revision": {"version": 0},
            "component": {
                "type": comp["type"],
                "name": comp["name"],
                "position": {"x": comp["position"]["x"], "y": comp["position"]["y"]},
                "config": comp.get("config", {})
            }
        }
        r = requests.post(url, json=payload)
        r.raise_for_status()
        logger.info(f"Created processor: {comp['name']} - {r.json()['id']}")
        return {"status": True, "data": r.json()}
    except requests.exceptions.RequestException as e:
        logger.error(f"Network error creating processor: {str(e)}")
        return {"status": False, "error": f"Network error: {str(e)}"}
    except KeyError as e:
        logger.error(f"Invalid processor component definition: {str(e)}")
        return {"status": False, "error": f"Invalid definition: {str(e)}"}
    except Exception as e:
        logger.error(f"Unexpected error creating processor: {str(e)}")
        return {"status": False, "error": f"Unexpected error: {str(e)}"}


def get_processor_by_type(pg_id: str, processor_type: str, NIFI_URL: str) -> Dict[str, Any]:
    """
    Finds a processor by type within a process group.
    
    Args:
        pg_id: Process Group ID
        processor_type: Fully qualified processor type name
        NIFI_URL: Base URL of the NiFi instance
        
    Returns:
        Processor entity if found
        
    Raises:
        Exception: If processor not found
    """
    try:
        # Wait to avoid rate limiting
        time.sleep(5)
        r = requests.get(f"{NIFI_URL}/flow/process-groups/{pg_id}")
        r.raise_for_status()
        
        # Search for processor by type
        for p in r.json()["processGroupFlow"]["flow"]["processors"]:
            if p["component"]["type"] == processor_type:
                return {"status": True, "data": p}
        
        raise Exception(f"Processor of type '{processor_type}' not found in PG {pg_id}")
    except requests.exceptions.RequestException as e:
        logger.error(f"Network error getting processor by type: {str(e)}")
        return {"status": False, "error": f"Network error: {str(e)}"}
    except KeyError as e:
        logger.error(f"Invalid response format getting processor by type: {str(e)}")
        return {"status": False, "error": f"Invalid response: {str(e)}"}
    except Exception as e:
        logger.error(f"Unexpected error getting processor by type: {str(e)}")
        return {"status": False, "error": f"Unexpected error: {str(e)}"}


def bind_websocket_controller_service(processor_id: str, cs_id: str, NIFI_URL: str) -> Dict[str, Any]:
    """
    Binds a WebSocket controller service to a processor.
    
    Args:
        processor_id: Processor ID
        cs_id: Controller Service ID
        NIFI_URL: Base URL of the NiFi instance
        
    Returns:
        Operation status
    """
    try:
        # Get fresh processor data to avoid version conflicts
        r = requests.get(f"{NIFI_URL}/processors/{processor_id}")
        r.raise_for_status()

        proc = r.json()
        rev = proc["revision"]["version"]
        properties = proc["component"]["config"]["properties"]
        properties["WebSocket Server Controller Service"] = cs_id

        # Update processor properties with WebSocket service
        payload = {
            "revision": {"version": rev},
            "component": {
                "id": processor_id,
                "config": {"properties": properties}
            }
        }

        r2 = requests.put(
            f"{NIFI_URL}/processors/{processor_id}",
            json=payload
        )
        r2.raise_for_status()
        
        return {"status": True, "message": "WebSocket controller service bound successfully"}
    except requests.exceptions.RequestException as e:
        logger.error(f"Network error binding WebSocket controller service: {str(e)}")
        return {"status": False, "error": f"Network error: {str(e)}"}
    except KeyError as e:
        logger.error(f"Invalid processor response binding WebSocket: {str(e)}")
        return {"status": False, "error": f"Invalid response: {str(e)}"}
    except Exception as e:
        logger.error(f"Unexpected error binding WebSocket controller service: {str(e)}")
        return {"status": False, "error": f"Unexpected error: {str(e)}"}


def create_connection(pg_id: str, conn: Dict[str, Any], NIFI_URL: str) -> Dict[str, Any]:
    """
    Creates a connection between components in a process group.
    
    Args:
        pg_id: Process Group ID
        conn: Connection definition
        NIFI_URL: Base URL of the NiFi instance
        
    Returns:
        Created connection entity
    """
    try:
        logger.info("####### Creating connection")
        # Wait to avoid rate limiting
        time.sleep(5)
        url = f"{NIFI_URL}/process-groups/{pg_id}/connections"

        src_old = conn["component"]["source"]["id"]
        dst_old = conn["component"]["destination"]["id"]

        logger.info(f"Source ID: {src_old}")
        logger.info(f"Destination ID: {dst_old}")

        # Prepare connection payload
        payload = {
            "revision": {"version": 0},
            "component": {
                "name": conn["component"].get("selectedRelationships", ["success"])[0],
                "parentGroupId": pg_id,
                "source": {
                    "id": src_old,
                    "type": conn["component"]["source"]["type"],
                    "groupId": pg_id,
                    "name": conn["component"]["source"]["name"]
                },
                "destination": {
                    "id": dst_old,
                    "type": conn["component"]["destination"]["type"],
                    "groupId": pg_id,
                    "name": conn["component"]["source"]["name"]
                },
                "selectedRelationships": conn["component"].get("selectedRelationships", ["success"]),
                "flowFileExpiration": conn["component"].get("flowFileExpiration", "0 sec"),
                "backPressureObjectThreshold": conn["component"].get("backPressureObjectThreshold", 10000),
                "backPressureDataSizeThreshold": conn["component"].get("backPressureDataSizeThreshold", "1 GB"),
                "availableRelationships": conn["component"].get("availableRelationships", [])
            }
        }

        r = requests.post(url, json=payload, headers={'Content-Type': 'application/json'})
        r.raise_for_status()

        logger.info("Created connection successfully")
        return {"status": True, "data": r.json()}
    except requests.exceptions.RequestException as e:
        logger.error(f"Network error creating connection: {str(e)}")
        return {"status": False, "error": f"Network error: {str(e)}"}
    except KeyError as e:
        logger.info(f"Invalid connection definition: {str(e)}")
        return {"status": False, "error": f"Invalid definition: {str(e)}"}
    except Exception as e:
        logger.error(f"Unexpected error creating connection: {str(e)}")
        return {"status": False, "error": f"Unexpected error: {str(e)}"}


def get_process_group_full(pg_id: str, NIFI_URL: str) -> Dict[str, Any]:
    """
    Retrieves complete process group data including all components.
    
    Args:
        pg_id: Process Group ID
        NIFI_URL: Base URL of the NiFi instance
        
    Returns:
        Complete process group data
    """
    try:
        # Wait to avoid rate limiting
        time.sleep(5)
        url = f"{NIFI_URL}/flow/process-groups/{pg_id}"
        r = requests.get(url)
        r.raise_for_status()
        return {"status": True, "data": r.json()}
    except requests.exceptions.RequestException as e:
        logger.error(f"Network error getting process group full data: {str(e)}")
        return {"status": False, "error": f"Network error: {str(e)}"}
    except Exception as e:
        logger.error(f"Unexpected error getting process group full data: {str(e)}")
        return {"status": False, "error": f"Unexpected error: {str(e)}"}


def create_controller_service_by_type(pg_id: str, cs_type: str, name: str, 
                                     NIFI_URL: str, properties: Optional[Dict] = None) -> Dict[str, Any]:
    """
    Creates a controller service by type in a process group.
    
    Args:
        pg_id: Process Group ID
        cs_type: Controller service type
        name: Service name
        NIFI_URL: Base URL of the NiFi instance
        properties: Service properties dictionary
        
    Returns:
        Created controller service ID
    """
    try:
        logger.info(f"==== > {NIFI_URL}")
        payload = {
            "revision": {"version": 0},
            "component": {
                "type": cs_type,
                "name": name,
                "properties": properties or {}
            }
        }
        r = requests.post(f"{NIFI_URL}/process-groups/{pg_id}/controller-services", json=payload)
        r.raise_for_status()
        cs_id = r.json()["id"]
        logger.info(f"Created Controller Service: {name}")
        return {"status": True, "cs_id": cs_id}
    except requests.exceptions.RequestException as e:
        logger.error(f"Network error creating controller service by type: {str(e)}")
        return {"status": False, "error": f"Network error: {str(e)}"}
    except KeyError as e:
        logger.error(f"Invalid response creating controller service: {str(e)}")
        return {"status": False, "error": f"Invalid response: {str(e)}"}
    except Exception as e:
        logger.error(f"Unexpected error creating controller service by type: {str(e)}")
        return {"status": False, "error": f"Unexpected error: {str(e)}"}


def start_processor(processor_id: str, NIFI_URL: str) -> Dict[str, Any]:
    """
    Starts a processor by ID.
    
    Args:
        processor_id: Processor ID
        NIFI_URL: Base URL of the NiFi instance
        
    Returns:
        Operation status
    """
    try:
        # Get current revision to avoid version conflicts
        url_get = f"{NIFI_URL}/processors/{processor_id}"
        resp = requests.get(url_get)
        resp.raise_for_status()
        processor = resp.json()
        revision = processor['revision']['version']

        # Start processor with RUNNING state
        url_put = f"{NIFI_URL}/processors/{processor_id}/run-status"
        payload = {
            "revision": {"version": revision},
            "state": "RUNNING"
        }
        r = requests.put(url_put, json=payload)
        r.raise_for_status()
        
        return {"status": True, "message": f"Processor {processor_id} started successfully"}
    except requests.exceptions.RequestException as e:
        logger.error(f"Network error starting processor: {str(e)}")
        return {"status": False, "error": f"Network error: {str(e)}"}
    except KeyError as e:
        logger.error(f"Invalid processor response starting: {str(e)}")
        return {"status": False, "error": f"Invalid response: {str(e)}"}
    except Exception as e:
        logger.error(f"Unexpected error starting processor: {str(e)}")
        return {"status": False, "error": f"Unexpected error: {str(e)}"}


def connect_components(
    pg_id: str,
    source_id: str,
    source_type: str,
    destination_id: str,
    destination_type: str,
    NIFI_URL: str,
    relationships: Optional[List[str]] = None,
    name: Optional[str] = None,
    flowfile_expiration: str = "0 sec",
    backpressure_count: int = 10000,
    backpressure_size: str = "1 GB"
) -> Dict[str, Any]:
    """
    Creates a connection between any two NiFi components.
    
    Args:
        pg_id: Process Group ID
        source_id: Source component ID
        source_type: Source component type
        destination_id: Destination component ID
        destination_type: Destination component type
        NIFI_URL: Base URL of the NiFi instance
        relationships: Selected relationships for the connection
        name: Connection name
        flowfile_expiration: FlowFile expiration time
        backpressure_count: Backpressure object threshold
        backpressure_size: Backpressure data size threshold
        
    Returns:
        Created connection entity
    """
    try:
        logger.info(f"\nSource connection: {source_id}\nDestination connection: {destination_id}\n")

        # Normalize processor types from fully qualified names
        if source_type.startswith("org.apache.nifi.processors"):
            source_type = "PROCESSOR"
        if destination_type.startswith("org.apache.nifi.processors"):
            destination_type = "PROCESSOR"
        
        # Set default relationships
        if relationships is None:
            relationships = ["success"]
        if source_type == "INPUT_PORT":
            relationships = None

        url = f"{NIFI_URL}/process-groups/{pg_id}/connections"

        # Prepare connection payload
        payload = {
            "revision": {"version": 0},
            "component": {
                "parentGroupId": pg_id,
                "name": name or f"{source_id[:6]}_to_{destination_id[:6]}",
                "source": {
                    "id": source_id,
                    "type": source_type,
                    "groupId": pg_id
                },
                "destination": {
                    "id": destination_id,
                    "type": destination_type,
                    "groupId": pg_id
                },
                "selectedRelationships": relationships,
                "flowFileExpiration": flowfile_expiration,
                "backPressureObjectThreshold": backpressure_count,
                "backPressureDataSizeThreshold": backpressure_size
            }
        }

        r = requests.post(url, json=payload)
        r.raise_for_status()

        logger.info(
            f"Connected {source_type} ({source_id}) "
            f"→ {destination_type} ({destination_id}) "
            f"relationships={relationships}"
        )

        return {"status": True, "data": r.json()}
    except requests.exceptions.RequestException as e:
        logger.error(f"Network error connecting components: {str(e)}")
        return {"status": False, "error": f"Network error: {str(e)}"}
    except KeyError as e:
        logger.error(f"Invalid component IDs connecting: {str(e)}")
        return {"status": False, "error": f"Invalid IDs: {str(e)}"}
    except Exception as e:
        logger.error(f"Unexpected error connecting components: {str(e)}")
        return {"status": False, "error": f"Unexpected error: {str(e)}"}


def get_processor_by_id(processor_id: str, NIFI_URL: str) -> Dict[str, Any]:
    """
    Retrieves processor details by ID.
    
    Args:
        processor_id: Processor ID
        NIFI_URL: Base URL of the NiFi instance
        
    Returns:
        Processor entity
    """
    try:
        url = f"{NIFI_URL}/processors/{processor_id}"
        r = requests.get(url)
        r.raise_for_status()
        return {"status": True, "data": r.json()}
    except requests.exceptions.RequestException as e:
        logger.error(f"Network error getting processor by ID: {str(e)}")
        return {"status": False, "error": f"Network error: {str(e)}"}
    except Exception as e:
        logger.error(f"Unexpected error getting processor by ID: {str(e)}")
        return {"status": False, "error": f"Unexpected error: {str(e)}"}


def get_processors_in_pg(pg_id: str, NIFI_URL: str) -> Dict[str, Any]:
    """
    Retrieves all processors in a process group.
    
    Args:
        pg_id: Process Group ID
        NIFI_URL: Base URL of the NiFi instance
        
    Returns:
        List of processors
    """
    try:
        url = f"{NIFI_URL}/flow/process-groups/{pg_id}"
        r = requests.get(url)
        r.raise_for_status()
        return {"status": True, "data": r.json()["processGroupFlow"]["flow"]["processors"]}
    except requests.exceptions.RequestException as e:
        logger.error(f"Network error getting processors in PG: {str(e)}")
        return {"status": False, "error": f"Network error: {str(e)}"}
    except KeyError as e:
        logger.error(f"Invalid response getting processors: {str(e)}")
        return {"status": False, "error": f"Invalid response: {str(e)}"}
    except Exception as e:
        logger.error(f"Unexpected error getting processors in PG: {str(e)}")
        return {"status": False, "error": f"Unexpected error: {str(e)}"}


def export_process_group(pg_id: str, NIFI_URL: str) -> Dict[str, Any]:
    """
    Exports a process group as JSON file.
    
    Args:
        pg_id: Process Group ID
        NIFI_URL: Base URL of the NiFi instance
        
    Returns:
        Process group JSON data
    """
    try:
        url = f"{NIFI_URL}/flow/process-groups/{pg_id}"
        r = requests.get(url)
        r.raise_for_status()
        pg_json = r.json()["processGroupFlow"] 
        return {"status": True, "data": pg_json}
    except requests.exceptions.RequestException as e:
        logger.error(f"Network error exporting process group: {str(e)}")
        return {"status": False, "error": f"Network error: {str(e)}"}
    except KeyError as e:
        logger.error(f"Invalid response exporting process group: {str(e)}")
        return {"status": False, "error": f"Invalid response: {str(e)}"}
    except Exception as e:
        logger.error(f"Unexpected error exporting process group: {str(e)}")
        return {"status": False, "error": f"Unexpected error: {str(e)}"}


def get_all_child_process_group_ids(parent_pg_id: str, NIFI_URL: str) -> Dict[str, Any]:
    """
    Recursively retrieves all child process group IDs under a parent PG.
    
    Args:
        parent_pg_id: Parent Process Group ID
        NIFI_URL: Base URL of the NiFi instance
        
    Returns:
        List of child process group IDs
    """
    try:
        all_pg_ids = []

        def _walk(pg_id: str):
            # Get child process groups of current PG
            url = f"{NIFI_URL}/process-groups/{pg_id}/process-groups"
            r = requests.get(url)
            r.raise_for_status()

            data = r.json()
            child_pgs = data["processGroups"]

            # Add child IDs and recursively walk through them
            for pg in child_pgs:
                child_id = pg["id"]
                all_pg_ids.append(child_id)
                _walk(child_id)

        # Start recursive walk from parent PG
        _walk(parent_pg_id)
        return {"status": True, "data": all_pg_ids}
    except requests.exceptions.RequestException as e:
        logger.error(f"Network error getting child PG IDs: {str(e)}")
        return {"status": False, "error": f"Network error: {str(e)}"}
    except Exception as e:
        logger.error(f"Unexpected error getting child PG IDs: {str(e)}")
        return {"status": False, "error": f"Unexpected error: {str(e)}"}


def stop_all_processors(pg_id: str, NIFI_URL: str) -> Dict[str, Any]:
    """
    Stops all processors in a process group.
    
    Args:
        pg_id: Process Group ID
        NIFI_URL: Base URL of the NiFi instance
        
    Returns:
        Operation status
    """
    try:
        # Get all processors in the process group
        r = requests.get(f"{NIFI_URL}/flow/process-groups/{pg_id}")
        r.raise_for_status()

        processors = r.json()["processGroupFlow"]["flow"].get("processors", [])

        # Stop each processor that is not already stopped
        for p in processors:
            if p["component"]["state"] != "STOPPED":
                proc_id = p["id"]

                # Fetch fresh revision to avoid conflicts
                pr = requests.get(f"{NIFI_URL}/processors/{proc_id}")
                pr.raise_for_status()

                rev = pr.json()["revision"]["version"]

                payload = {
                    "revision": {"version": rev},
                    "state": "STOPPED"
                }

                requests.put(
                    f"{NIFI_URL}/processors/{proc_id}/run-status",
                    json=payload
                ).raise_for_status()

        logger.info(f"✔ Processors stopped in PG {pg_id}")
        return {"status": True, "message": f"All processors stopped in PG {pg_id}"}
    except requests.exceptions.RequestException as e:
        logger.error(f"Network error stopping all processors: {str(e)}")
        return {"status": False, "error": f"Network error: {str(e)}"}
    except KeyError as e:
        logger.error(f"Invalid response stopping processors: {str(e)}")
        return {"status": False, "error": f"Invalid response: {str(e)}"}
    except Exception as e:
        logger.error(f"Unexpected error stopping all processors: {str(e)}")
        return {"status": False, "error": f"Unexpected error: {str(e)}"}


def stop_all_ports(pg_id: str, NIFI_URL: str) -> Dict[str, Any]:
    """
    Stops all input and output ports in a process group.
    
    Args:
        pg_id: Process Group ID
        NIFI_URL: Base URL of the NiFi instance
        
    Returns:
        Operation status
    """
    try:
        r = requests.get(f"{NIFI_URL}/flow/process-groups/{pg_id}")
        r.raise_for_status()

        flow = r.json()["processGroupFlow"]["flow"]

        # Process both input and output ports
        for port_type in ["inputPorts", "outputPorts"]:
            for p in flow.get(port_type, []):
                if p["component"]["state"] != "STOPPED":
                    port_id = p["id"]
                    
                    # Determine API endpoint based on port type
                    if port_type == "inputPorts":
                        port_type_api = "input-ports"
                    else:
                        port_type_api = "output-ports"

                    # Get fresh revision
                    pr = requests.get(f"{NIFI_URL}/{port_type_api}/{port_id}")
                    pr.raise_for_status()
                    
                    rev = pr.json()["revision"]["version"]

                    payload = {
                        "revision": {"version": rev},
                        "state": "STOPPED"
                    }

                    requests.put(
                        f"{NIFI_URL}/{port_type_api}/{port_id}/run-status",
                        json=payload
                    ).raise_for_status()

        logger.info(f"✔ Ports stopped in PG {pg_id}")
        return {"status": True, "message": f"All ports stopped in PG {pg_id}"}
    except requests.exceptions.RequestException as e:
        logger.error(f"Network error stopping all ports: {str(e)}")
        return {"status": False, "error": f"Network error: {str(e)}"}
    except KeyError as e:
        logger.error(f"Invalid response stopping ports: {str(e)}")
        return {"status": False, "error": f"Invalid response: {str(e)}"}
    except Exception as e:
        logger.error(f"Unexpected error stopping all ports: {str(e)}")
        return {"status": False, "error": f"Unexpected error: {str(e)}"}


def empty_all_queues(pg_id: str, NIFI_URL: str) -> Dict[str, Any]:
    """
    Empties all flowfile queues in a process group.
    
    Args:
        pg_id: Process Group ID
        NIFI_URL: Base URL of the NiFi instance
        
    Returns:
        Operation status
    """
    try:
        r = requests.get(f"{NIFI_URL}/flow/process-groups/{pg_id}")
        r.raise_for_status()

        connections = r.json()["processGroupFlow"]["flow"].get("connections", [])

        # Drop all flowfiles from each connection queue
        for c in connections:
            conn_id = c["id"]
            requests.post(
                f"{NIFI_URL}/flowfile-queues/{conn_id}/drop-requests"
            ).raise_for_status()

        logger.info(f"✔ Queues emptied in PG {pg_id}")
        return {"status": True, "message": f"All queues emptied in PG {pg_id}"}
    except requests.exceptions.RequestException as e:
        logger.error(f"Network error emptying all queues: {str(e)}")
        return {"status": False, "error": f"Network error: {str(e)}"}
    except Exception as e:
        logger.error(f"Unexpected error emptying all queues: {str(e)}")
        return {"status": False, "error": f"Unexpected error: {str(e)}"}


def disable_all_controller_services(pg_id: str, NIFI_URL: str) -> Dict[str, Any]:
    """
    Disables all controller services in a process group.
    
    Args:
        pg_id: Process Group ID
        NIFI_URL: Base URL of the NiFi instance
        
    Returns:
        Operation status
    """
    try:
        r = requests.get(f"{NIFI_URL}/flow/process-groups/{pg_id}/controller-services")
        r.raise_for_status()

        # Disable each controller service
        for cs in r.json().get("controllerServices", []):
            cs_id = cs["id"]

            cr = requests.get(f"{NIFI_URL}/controller-services/{cs_id}")
            cr.raise_for_status()

            rev = cr.json()["revision"]["version"]

            payload = {
                "revision": {"version": rev},
                "component": {
                    "id": cs_id,
                    "state": "DISABLED"
                }
            }

            requests.put(
                f"{NIFI_URL}/controller-services/{cs_id}",
                json=payload
            ).raise_for_status()

        logger.info(f"✔ Controller services disabled in PG {pg_id}")
        return {"status": True, "message": f"All controller services disabled in PG {pg_id}"}
    except requests.exceptions.RequestException as e:
        logger.error(f"Network error disabling all controller services: {str(e)}")
        return {"status": False, "error": f"Network error: {str(e)}"}
    except KeyError as e:
        logger.error(f"Invalid response disabling services: {str(e)}")
        return {"status": False, "error": f"Invalid response: {str(e)}"}
    except Exception as e:
        logger.error(f"Unexpected error disabling all controller services: {str(e)}")
        return {"status": False, "error": f"Unexpected error: {str(e)}"}


def delete_process_group(pg_id: str, NIFI_URL: str) -> Dict[str, Any]:
    """
    Deletes a process group.
    
    Args:
        pg_id: Process Group ID
        NIFI_URL: Base URL of the NiFi instance
        
    Returns:
        Operation status
    """
    try:
        # Get current revision before deletion
        r = requests.get(f"{NIFI_URL}/process-groups/{pg_id}")
        r.raise_for_status()

        rev = r.json()["revision"]["version"]

        # Delete process group with version parameter
        requests.delete(
            f"{NIFI_URL}/process-groups/{pg_id}",
            params={"version": rev}
        ).raise_for_status()

        logger.info(f"🗑 Process Group {pg_id} deleted")
        return {"status": True, "message": f"Process Group {pg_id} deleted"}
    except requests.exceptions.RequestException as e:
        logger.error(f"Network error deleting process group: {str(e)}")
        return {"status": False, "error": f"Network error: {str(e)}"}
    except KeyError as e:
        logger.error(f"Invalid response deleting process group: {str(e)}")
        return {"status": False, "error": f"Invalid response: {str(e)}"}
    except Exception as e:
        logger.error(f"Unexpected error deleting process group: {str(e)}")
        return {"status": False, "error": f"Unexpected error: {str(e)}"}


def get_controller_service_by_name(pg_id: str, service_name: str, NIFI_URL: str) -> Dict[str, Any]:
    """
    Retrieves a controller service by name within a process group.
    
    Args:
        pg_id: Process Group ID
        service_name: Controller service name
        NIFI_URL: Base URL of the NiFi instance
        
    Returns:
        Controller service entity if found
    """
    try:
        url = f"{NIFI_URL}/flow/process-groups/{pg_id}/controller-services"
        r = requests.get(url)
        r.raise_for_status()

        services = r.json().get("controllerServices", [])

        # Search for service by name
        for cs in services:
            if cs["component"]["name"] == service_name:
                return {"status": True, "data": cs}

        return {"status": False, "error": f"Controller service '{service_name}' not found"}
    except requests.exceptions.RequestException as e:
        logger.error(f"Network error getting controller service by name: {str(e)}")
        return {"status": False, "error": f"Network error: {str(e)}"}
    except KeyError as e:
        logger.error(f"Invalid response getting controller service: {str(e)}")
        return {"status": False, "error": f"Invalid response: {str(e)}"}
    except Exception as e:
        logger.error(f"Unexpected error getting controller service by name: {str(e)}")
        return {"status": False, "error": f"Unexpected error: {str(e)}"}


def create_process_group_inside_pg(
    parent_pg_id: str,
    name: str,
    NIFI_URL: str,
    position: Tuple[float, float] = (200.0, 200.0),
    fail_if_exists: bool = True
) -> Dict[str, Any]:
    """
    Creates a process group inside an existing process group.
    
    Args:
        parent_pg_id: Parent Process Group ID
        name: New process group name
        NIFI_URL: Base URL of the NiFi instance
        position: Canvas position (x, y)
        fail_if_exists: Raise error if PG with same name exists
        
    Returns:
        Creation status and PG details
    """
    try:
        # Check if PG already exists under parent
        r = requests.get(f"{NIFI_URL}/flow/process-groups/{parent_pg_id}")
        r.raise_for_status()

        existing_pgs = r.json()["processGroupFlow"]["flow"]["processGroups"]

        # Check for existing process group with same name
        for pg in existing_pgs:
            if pg["component"]["name"] == name:
                if fail_if_exists:
                    return {
                        "status": False,
                        "id": pg["component"]["id"],
                        "name": name,
                        "message": "Process Group already exists"
                    }
                else:
                    return {
                        "status": True,
                        "id": pg["component"]["id"],
                        "name": name,
                        "message": "Process Group already exists"
                    }

        # Create Process Group
        payload = {
            "revision": {"version": 0},
            "component": {
                "name": name,
                "position": {
                    "x": float(position[0]),
                    "y": float(position[1])
                }
            }
        }

        r = requests.post(
            f"{NIFI_URL}/process-groups/{parent_pg_id}/process-groups",
            json=payload
        )
        r.raise_for_status()

        pg_id = r.json()["id"]

        logger.info(f"Created Process Group '{name}' inside PG '{parent_pg_id}'")

        return {
            "status": True,
            "id": pg_id,
            "name": name
        }
    except requests.exceptions.RequestException as e:
        logger.error(f"Network error creating process group inside PG: {str(e)}")
        return {"status": False, "error": f"Network error: {str(e)}"}
    except KeyError as e:
        logger.error(f"Invalid response creating process group: {str(e)}")
        return {"status": False, "error": f"Invalid response: {str(e)}"}
    except Exception as e:
        logger.error(f"Unexpected error creating process group inside PG: {str(e)}")
        return {"status": False, "error": f"Unexpected error: {str(e)}"}


def create_input_port(
    pg_id: str,
    name: str,
    NIFI_URL: str,
    position_id: int = 0,
    allow_remote_access: bool = False
) -> Dict[str, Any]:
    """
    Creates an input port inside a process group.
    
    Args:
        pg_id: Process Group ID
        name: Input port name
        NIFI_URL: Base URL of the NiFi instance
        position_id: Position multiplier for canvas layout
        allow_remote_access: Allow access from remote PGs
        
    Returns:
        Created input port details
    """
    try:
        position = (400 * position_id, 0.0)
        url = f"{NIFI_URL}/process-groups/{pg_id}/input-ports"

        payload = {
            "revision": {"version": 0},
            "component": {
                "name": name,
                "position": {
                    "x": float(position[0]),
                    "y": float(position[1])
                },
                "allowRemoteAccess": allow_remote_access
            }
        }

        r = requests.post(url, json=payload)
        r.raise_for_status()

        port_id = r.json()["id"]

        logger.info(f"Created Input Port '{name}' in PG '{pg_id}'")

        return {
            "status": True,
            "id": port_id,
            "name": name,
            "data": r.json()
        }
    except requests.exceptions.RequestException as e:
        logger.error(f"Network error creating input port: {str(e)}")
        return {"status": False, "error": f"Network error: {str(e)}"}
    except Exception as e:
        logger.error(f"Unexpected error creating input port: {str(e)}")
        return {"status": False, "error": f"Unexpected error: {str(e)}"}


def create_execute_stream_command(
    pg_id: str,
    NIFI_URL: str,
    name: str = "ExecuteStreamCommand",
    command: str = "",
    command_arguments: str = "",
    working_dir: str = "",
    position_id: int = 1,
    scheduling_period: str = "0 sec",
    environment: Optional[Dict[str, str]] = None
) -> Dict[str, Any]:
    """
    Creates an ExecuteStreamCommand processor in a process group.
    
    Args:
        pg_id: Target Process Group ID
        NIFI_URL: Base URL of the NiFi instance
        name: Processor name
        command: Command to execute
        command_arguments: Command arguments
        working_dir: Working directory
        position_id: Position multiplier for canvas layout
        scheduling_period: Scheduling period
        environment: Environment variables dictionary
        
    Returns:
        Created processor details
    """
    try:
        position = (500 * position_id, 0.0)
        url = f"{NIFI_URL}/process-groups/{pg_id}/processors"

        properties = {
            "Command Path": command,
            "Command Arguments": command_arguments,
            "Working Directory": working_dir,
            "Ignore STDIN": "false",
            "Redirect STDERR": "true",
            "Argument Delimiter": ";",
            "Max Attribute Length": "5000",
            "Output MIME Type": "application/json"
        }

        # Add environment variables if provided
        if environment:
            properties["Environment Variables"] = "\n".join(
                f"{k}={v}" for k, v in environment.items()
            )

        payload = {
            "revision": {"version": 0},
            "component": {
                "type": "org.apache.nifi.processors.standard.ExecuteStreamCommand",
                "name": name,
                "position": {
                    "x": float(position[0]),
                    "y": float(position[1])
                },
                "config": {
                    "properties": properties,
                    "schedulingPeriod": scheduling_period,
                    "executionNode": "ALL",
                    "autoTerminatedRelationships": [
                        "original",
                        "nonzero status"
                    ]
                }
            }
        }

        r = requests.post(url, json=payload)
        r.raise_for_status()

        proc_id = r.json()["id"]

        logger.info(f"Created ExecuteStreamCommand '{name}' in PG '{pg_id}'")

        return {
            "status": True,
            "id": proc_id,
            "name": name,
            "data": r.json()
        }
    except requests.exceptions.RequestException as e:
        logger.error(f"Network error creating ExecuteStreamCommand: {str(e)}")
        return {"status": False, "error": f"Network error: {str(e)}"}
    except KeyError as e:
        logger.info(f"Invalid configuration creating ExecuteStreamCommand: {str(e)}")
        return {"status": False, "error": f"Invalid config: {str(e)}"}
    except Exception as e:
        logger.error(f"Unexpected error creating ExecuteStreamCommand: {str(e)}")
        return {"status": False, "error": f"Unexpected error: {str(e)}"}


def create_output_port(
    pg_id: str,
    name: str,
    NIFI_URL: str,
    position_id: int = 2,
    allow_remote_access: bool = False
) -> Dict[str, Any]:
    """
    Creates an output port inside a process group.
    
    Args:
        pg_id: Process Group ID
        name: Output port name
        NIFI_URL: Base URL of the NiFi instance
        position_id: Position multiplier for canvas layout
        allow_remote_access: Allow remote process groups to connect
        
    Returns:
        Created output port details
    """
    try:
        position = (500 * position_id, 0.0)
        url = f"{NIFI_URL}/process-groups/{pg_id}/output-ports"

        payload = {
            "revision": {"version": 0},
            "component": {
                "name": name,
                "position": {
                    "x": float(position[0]),
                    "y": float(position[1])
                },
                "allowRemoteAccess": allow_remote_access
            }
        }

        r = requests.post(url, json=payload)
        r.raise_for_status()

        port_id = r.json()["id"]

        logger.info(f"Created Output Port '{name}' in PG '{pg_id}'")

        return {
            "status": True,
            "id": port_id,
            "name": name,
            "data": r.json()
        }
    except requests.exceptions.RequestException as e:
        logger.error(f"Network error creating output port: {str(e)}")
        return {"status": False, "error": f"Network error: {str(e)}"}
    except Exception as e:
        logger.error(f"Unexpected error creating output port: {str(e)}")
        return {"status": False, "error": f"Unexpected error: {str(e)}"}


def create_put_websocket(
    pg_id: str,
    name: str,
    comp: Dict[str, Any],
    NIFI_URL: str,
    position_id: int = 0
) -> Dict[str, Any]:
    """
    Creates a PutWebSocket processor.
    
    Args:
        pg_id: Process Group ID
        name: Processor name
        comp: Processor component configuration
        NIFI_URL: Base URL of the NiFi instance
        position_id: Position multiplier for canvas layout
        
    Returns:
        Created processor details
    """
    try:
        url = f"{NIFI_URL}/process-groups/{pg_id}/processors"

        payload = {
            "revision": {"version": 0},
            "component": {
                "type": "org.apache.nifi.processors.websocket.PutWebSocket",
                "name": name,
                "position": {
                    "x": 400 + (position_id * 150),
                    "y": 300
                },
                "config": {
                    "properties": {
                        "WebSocket Session Id": comp["WebSocket Session Id"],
                        "WebSocket Controller Service Id": comp["WebSocket Controller Service Id"],
                        "WebSocket Endpoint Id": comp["WebSocket Endpoint Id"],
                        "WebSocket Message Type": comp["WebSocket Message Type"]
                    },
                    "autoTerminatedRelationships": ["failure", "success"],
                    "schedulingPeriod": "0 sec",
                    "executionNode": "ALL"
                }
            }
        }

        response = requests.post(url, json=payload)
        response.raise_for_status()
        
        return {"status": True, "data": response.json()}
    except requests.exceptions.RequestException as e:
        logger.error(f"Network error creating PutWebSocket processor: {str(e)}")
        return {"status": False, "error": f"Network error: {str(e)}"}
    except KeyError as e:
        logger.info(f"Invalid configuration creating PutWebSocket: {str(e)}")
        return {"status": False, "error": f"Invalid config: {str(e)}"}
    except Exception as e:
        logger.error(f"Unexpected error creating PutWebSocket processor: {str(e)}")
        return {"status": False, "error": f"Unexpected error: {str(e)}"}


def add_handle_http_response(
    pg_id: str,
    http_cs_id: str,
    NIFI_URL: str,
    processor_name: str = "HandleHttpResponse"
) -> Dict[str, Any]:
    """
    Creates a HandleHttpResponse processor in a process group.
    
    Args:
        pg_id: Process Group ID
        http_cs_id: HTTP Context Map controller service ID
        NIFI_URL: Base URL of the NiFi instance
        processor_name: Processor name prefix
        
    Returns:
        Created processor details
    """
    try:
        url = f"{NIFI_URL}/process-groups/{pg_id}/processors"

        payload = {
            "revision": {"version": 0},
            "component": {
                "name": f"{processor_name}_HTTP_rep",
                "type": "org.apache.nifi.processors.standard.HandleHttpResponse",
                "config": {
                    "properties": {
                        "HTTP Status Code": "${http.status.code}",
                        "HTTP Context Map": http_cs_id,
                        "Attributes for HTTP Response": "Content-Type:application/json"
                    },
                    "autoTerminatedRelationships": ["failure", "success"]
                }
            }
        }

        headers = {"Content-Type": "application/json"}
        r = requests.post(url, headers=headers, data=json.dumps(payload))
        r.raise_for_status()

        return {"status": True, "data": r.json()}
    except requests.exceptions.RequestException as e:
        logger.error(f"Network error adding HandleHttpResponse: {str(e)}")
        return {"status": False, "error": f"Network error: {str(e)}"}
    except KeyError as e:
        logger.info(f"Invalid configuration adding HandleHttpResponse: {str(e)}")
        return {"status": False, "error": f"Invalid config: {str(e)}"}
    except Exception as e:
        logger.error(f"Unexpected error adding HandleHttpResponse: {str(e)}")
        return {"status": False, "error": f"Unexpected error: {str(e)}"}


def add_route_on_attribute_rule(
    route_proc_id: str,
    rule_name: str,
    expression: str,
    NIFI_URL: str
) -> Dict[str, Any]:
    """
    Adds a new rule (dynamic property) to a RouteOnAttribute processor.
    
    Args:
        route_proc_id: RouteOnAttribute processor ID
        rule_name: Rule name (dynamic property name)
        expression: Expression for the rule
        NIFI_URL: Base URL of the NiFi instance
        
    Returns:
        Operation status
    """
    try:
        # Get current processor state
        proc = requests.get(f"{NIFI_URL}/processors/{route_proc_id}").json()
        rev = proc["revision"]["version"]

        properties = proc["component"]["config"]["properties"] or {}

        # Add dynamic rule to properties
        properties[rule_name] = expression

        payload = {
            "revision": {"version": rev},
            "component": {
                "id": route_proc_id,
                "config": {
                    "properties": properties
                }
            }
        }

        r = requests.put(f"{NIFI_URL}/processors/{route_proc_id}", json=payload)
        r.raise_for_status()
        # Wait for changes to propagate
        time.sleep(5)
        
        logger.info(f"Added RouteOnAttribute rule: {rule_name}")
        return {"status": True, "message": f"Rule '{rule_name}' added successfully"}
    except requests.exceptions.RequestException as e:
        logger.error(f"Network error adding RouteOnAttribute rule: {str(e)}")
        return {"status": False, "error": f"Network error: {str(e)}"}
    except KeyError as e:
        logger.error(f"Invalid processor response adding route rule: {str(e)}")
        return {"status": False, "error": f"Invalid response: {str(e)}"}
    except Exception as e:
        logger.error(f"Unexpected error adding RouteOnAttribute rule: {str(e)}")
        return {"status": False, "error": f"Unexpected error: {str(e)}"}


def connect_processor_to_child_pg(
    parent_pg_id: str,
    processor_id: str,
    child_pg_id: str,
    NIFI_URL: str,
    relationships: List[str]
) -> Dict[str, Any]:
    """
    Connects a processor in a parent PG to a child PG's input port.
    
    Args:
        parent_pg_id: Parent Process Group ID
        processor_id: Processor ID in the parent PG
        child_pg_id: Child Process Group ID
        NIFI_URL: Base URL of the NiFi instance
        relationships: Relationships to use for connection
        
    Returns:
        Operation status
    """
    try:
        # Get the child PG's input ports
        r = requests.get(f"{NIFI_URL}/process-groups/{child_pg_id}/input-ports")
        r.raise_for_status()
        input_ports = r.json()["inputPorts"]
        
        if not input_ports:
            raise Exception(f"Child PG {child_pg_id} has no input ports")
        
        # Use the first input port
        input_port = input_ports[0]

        # Get the processor info
        r = requests.get(f"{NIFI_URL}/processors/{processor_id}")
        r.raise_for_status()
        processor = r.json()

        # Prepare the connection payload
        connection_payload = {
            "revision": {"version": 0},
            "component": {
                "name": f"Connection_to_{input_port['component']['name']}",
                "source": {
                    "id": processor_id,
                    "type": "PROCESSOR",
                    "groupId": parent_pg_id
                },
                "destination": {
                    "id": input_port['id'],
                    "type": "INPUT_PORT",
                    "groupId": child_pg_id
                },
                "selectedRelationships": relationships,
                "flowFileExpiration": "0 sec",
                "backPressureDataSizeThreshold": "1 GB",
                "backPressureObjectThreshold": 10000
            }
        }
        
        # Create the connection in the parent PG
        url = f"{NIFI_URL}/process-groups/{parent_pg_id}/connections"
        r = requests.post(url, json=connection_payload)
        r.raise_for_status()
        
        logger.info(f"Connected processor '{processor['component']['name']}' to input port '{input_port['component']['name']}' of child PG.")
        return {"status": True, "data": r.json()}
    except requests.exceptions.RequestException as e:
        logger.error(f"Network error connecting processor to child PG: {str(e)}")
        return {"status": False, "error": f"Network error: {str(e)}"}
    except KeyError as e:
        logger.error(f"Invalid response connecting processor to child PG: {str(e)}")
        return {"status": False, "error": f"Invalid response: {str(e)}"}
    except Exception as e:
        logger.error(f"Unexpected error connecting processor to child PG: {str(e)}")
        return {"status": False, "error": f"Unexpected error: {str(e)}"}


def get_ports_in_process_group(
    process_group_id: str,
    NIFI_URL: str,
    headers: Dict[str, str] = None
) -> List[Dict[str, Any]]:
    """
    Get all Input Ports and Output Ports inside a NiFi Process Group.

    Args:
        process_group_id: NiFi Process Group ID
        NIFI_URL: Base NiFi URL (e.g. https://localhost:8443/nifi-api)
        headers: Optional auth headers

    Returns:
        List of ports with id, name, type, state, and version
    """
    try:
        url = f"{NIFI_URL}/process-groups/{process_group_id}/connections"
        response = requests.get(url, headers=headers, verify=False)
        response.raise_for_status()
        logger.info(url)
        
        data = response.json()['connections']
        
        # Debug output for connection details
        for i in data:
            logger.info(i['sourceType'])
            logger.info(i['sourceId'])
            logger.info("####################")
            
        ports = []

        # Extract INPUT_PORT information from connections
        for port in data:
            if (port['sourceType'] == "INPUT_PORT"):
                ports.append({
                    "port_id": port["sourceId"],
                    "port_type": "INPUT_PORT",
                    "version": port["revision"]["version"]
                })
            if port['destinationType'] == "INPUT_PORT":
                ports.append({
                    "port_id": port["destinationId"],
                    "port_type": "INPUT_PORT",
                    "version": port["revision"]["version"]
                })
        
        # Extract OUTPUT_PORT information from connections
        for port in data:
            if (port['sourceType'] == "OUTPUT_PORT"):
                ports.append({
                    "port_id": port["sourceId"],
                    "port_type": "OUTPUT_PORT",
                    "version": port["revision"]["version"]
                })
            if (port['destinationType'] == "OUTPUT_PORT"):
                ports.append({
                    "port_id": port["destinationId"],
                    "port_type": "OUTPUT_PORT",
                    "version": port["revision"]["version"]
                })
        return ports
    except requests.exceptions.RequestException as e:
        logger.error(f"Network error getting ports in process group: {str(e)}")
        return []
    except KeyError as e:
        logger.error(f"Invalid response getting ports: {str(e)}")
        return []
    except Exception as e:
        logger.error(f"Unexpected error getting ports in process group: {str(e)}")
        return []


def stop_port_by_id(port_id: str, port_type: str, NIFI_URL: str) -> Dict[str, Any]:
    """
    Stops an InputPort or OutputPort by ID.
    
    Args:
        port_id: Port ID
        port_type: Port type ("input-ports" or "output-ports")
        NIFI_URL: Base URL of the NiFi instance
        
    Returns:
        Operation status
    """
    # Convert port type to API format (e.g., INPUT_PORT -> input-ports)
    port_type = port_type.replace("_","-") + "s"
    try:
        # Get current port state
        r = requests.get(f"{NIFI_URL}/{port_type}/{port_id}")
        r.raise_for_status()

        revision = r.json()["revision"]["version"]
        name = r.json()["component"]["name"]

        # Stop port
        payload = {
            "revision": {"version": revision},
            "state": "STOPPED"
        }

        sr = requests.put(
            f"{NIFI_URL}/{port_type}/{port_id}/run-status",
            json=payload
        )
        sr.raise_for_status()

        logger.info(f"✔ Stopped {port_type[:-1]}: {name} ({port_id})")
        return {"status": True, "message": f"Port {port_id} stopped successfully"}
    except requests.exceptions.RequestException as e:
        logger.error(f"Network error stopping port by ID: {str(e)}")
        return {"status": False, "error": f"Network error: {str(e)}"}
    except KeyError as e:
        logger.error(f"Invalid response stopping port: {str(e)}")
        return {"status": False, "error": f"Invalid response: {str(e)}"}
    except Exception as e:
        logger.error(f"Unexpected error stopping port by ID: {str(e)}")
        return {"status": False, "error": f"Unexpected error: {str(e)}"}


def start_port_by_id(port_id: str, port_type: str, NIFI_URL: str, retries: int = 5) -> Dict[str, Any]:
    """
    Starts an InputPort or OutputPort by ID with retry logic.
    
    Args:
        port_id: Port ID
        port_type: Port type ("input-ports" or "output-ports")
        NIFI_URL: Base URL of the NiFi instance
        retries: Number of retry attempts on conflict
        
    Returns:
        Operation status
    """
    # Normalize port type for API calls
    port_type = str(port_type).lower().replace("_", "-") + "s"

    for attempt in range(1, retries + 1):
        try:
            # Get current port state
            r = requests.get(f"{NIFI_URL}/{port_type}/{port_id}")
            r.raise_for_status()

            data = r.json()
            revision = data["revision"]["version"]
            name = data["component"]["name"]
            state = data["component"]["state"]

            # Check if already running
            if state == "RUNNING":
                return {
                    "status": True,
                    "message": f"Port already running: {name}"
                }

            # Prepare start payload
            payload = {
                "revision": {"version": revision},
                "state": "RUNNING"
            }

            # Start port
            sr = requests.put(
                f"{NIFI_URL}/{port_type}/{port_id}/run-status",
                json=payload
            )

            # Handle conflict with retry
            if sr.status_code == 409:
                logger.info(f"⚠ Conflict on attempt {attempt}, retrying...")
                time.sleep(1)
                continue

            sr.raise_for_status()

            logger.info(f"✔ Started {port_type[:-1]}: {name} ({port_id})")
            return {
                "status": True,
                "message": f"Port {name} started successfully"
            }

        except requests.exceptions.RequestException as e:
            if attempt == retries:
                return {"status": False, "error": f"Network error: {str(e)}"}
            time.sleep(1)
        except KeyError as e:
            if attempt == retries:
                return {"status": False, "error": f"Invalid response: {str(e)}"}
            time.sleep(1)
        except Exception as e:
            if attempt == retries:
                return {"status": False, "error": f"Unexpected error: {str(e)}"}
            time.sleep(1)

    return {"status": False, "error": "Max retries exceeded"}


def stop_processor(processor_id: str, NIFI_URL: str) -> Dict[str, Any]:
    """
    Stops a processor by ID.
    
    Args:
        processor_id: Processor ID
        NIFI_URL: Base URL of the NiFi instance
        
    Returns:
        Operation status
    """
    try:
        # Get processor details first
        proc_data = get_processor_by_id(processor_id, NIFI_URL)
        if not proc_data["status"]:
            return proc_data
            
        processor = proc_data["data"]
        url = f"{NIFI_URL}/processors/{processor_id}/run-status"
        
        # Prepare stop payload
        payload = {
            "revision": processor["revision"],
            "state": "STOPPED"
        }
        
        r = requests.put(url, json=payload)
        r.raise_for_status()
        
        logger.info(f"Stopped processor: {processor['component']['name']}")
        return {"status": True, "message": f"Processor {processor_id} stopped"}
    except requests.exceptions.RequestException as e:
        logger.error(f"Network error stopping processor: {str(e)}")
        return {"status": False, "error": f"Network error: {str(e)}"}
    except KeyError as e:
        logger.error(f"Invalid response stopping processor: {str(e)}")
        return {"status": False, "error": f"Invalid response: {str(e)}"}
    except Exception as e:
        logger.error(f"Unexpected error stopping processor: {str(e)}")
        return {"status": False, "error": f"Unexpected error: {str(e)}"}


def stop_process_group(pg_id: str, NIFI_URL: str) -> Dict[str, Any]:
    """
    Stops all processors in a process group.
    
    Args:
        pg_id: Process Group ID
        NIFI_URL: Base URL of the NiFi instance
        
    Returns:
        Operation status
    """
    try:
        logger.info(f"Stopping process group: {pg_id}")
        
        # Get all processors in the group
        processors_data = get_processors_in_pg(pg_id, NIFI_URL)
        if not processors_data["status"]:
            return processors_data
            
        processors = processors_data["data"]
        
        if not processors:
            logger.info("No processors in process group")
            return {"status": True, "message": "No processors to stop"}
            
        # Stop each processor
        for p in processors:
            if p["component"]["state"] != "STOPPED":
                stop_result = stop_processor(p["id"], NIFI_URL)
                if not stop_result["status"]:
                    logger.error(f"Failed to stop processor {p['id']}")
                    
        return {"status": True, "message": f"All processors in PG {pg_id} stopped"}
    except requests.exceptions.RequestException as e:
        logger.error(f"Network error stopping process group: {str(e)}")
        return {"status": False, "error": f"Network error: {str(e)}"}
    except Exception as e:
        logger.error(f"Unexpected error stopping process group: {str(e)}")
        return {"status": False, "error": f"Unexpected error: {str(e)}"}


def remove_route_on_attribute_rule(
    route_proc_id: str,
    rule_name: str,
    NIFI_URL: str
) -> Dict[str, Any]:
    """
    Removes a rule (dynamic property) from a RouteOnAttribute processor.
    
    Args:
        route_proc_id: RouteOnAttribute processor ID
        rule_name: Rule name to remove
        NIFI_URL: Base URL of the NiFi instance
        
    Returns:
        Operation status
    """
    try:
        # Get current processor state
        proc = requests.get(f"{NIFI_URL}/processors/{route_proc_id}").json()
        rev = proc["revision"]["version"]

        properties = proc["component"]["config"]["properties"] or {}

        # Remove dynamic rule by setting to None
        properties[rule_name] = None

        payload = {
            "revision": {"version": rev},
            "component": {
                "id": route_proc_id,
                "config": {
                    "properties": properties
                }
            }
        }

        r = requests.put(f"{NIFI_URL}/processors/{route_proc_id}", json=payload)
        r.raise_for_status()
        # Wait for changes to propagate
        time.sleep(5)
        
        logger.info(f"Deleted RouteOnAttribute rule: {rule_name}")
        return {"status": True, "message": f"Rule '{rule_name}' removed successfully"}
    except requests.exceptions.RequestException as e:
        logger.error(f"Network error removing RouteOnAttribute rule: {str(e)}")
        return {"status": False, "error": f"Network error: {str(e)}"}
    except KeyError as e:
        logger.error(f"Invalid response removing route rule: {str(e)}")
        return {"status": False, "error": f"Invalid response: {str(e)}"}
    except Exception as e:
        logger.error(f"Unexpected error removing RouteOnAttribute rule: {str(e)}")
        return {"status": False, "error": f"Unexpected error: {str(e)}"}


def delete_all_connections_to_pg(pg_id: str, NIFI_URL: str) -> Dict[str, Any]:
    """
    Deletes all connections where source OR destination belongs to a process group.
    
    Args:
        pg_id: Process Group ID
        NIFI_URL: Base URL of the NiFi instance
        
    Returns:
        Operation status
    """
    try:
        # Get ALL connections from the process group
        r = requests.get(f"{NIFI_URL}/process-groups/{pg_id}/connections")
        r.raise_for_status()
        
        all_connections = []
        data = r.json()
        
        # Extract connections from response
        if isinstance(data, dict) and "connections" in data:
            all_connections = data["connections"]
        elif isinstance(data, list):
            all_connections = data
            
        logger.info(all_connections)
        
        # Delete connections that involve this process group
        for c in all_connections:
            if isinstance(c, dict):
                src = c.get("component", {}).get("source", {})
                dest = c.get("component", {}).get("destination", {})
                
                # Check if connection involves this PG
                if src.get("groupId") == pg_id or dest.get("groupId") == pg_id:
                    cid = c.get("id")
                    ver = c.get("revision", {}).get("version", 0)
                    
                    if cid:
                        requests.delete(
                            f"{NIFI_URL}/connections/{cid}",
                            params={"version": ver}
                        ).raise_for_status()
                        
                        logger.info(f"🧹 Deleted connection {cid}")

        logger.info(f"All connections to/from PG {pg_id} deleted")
        return {"status": True, "message": f"All connections to/from PG {pg_id} deleted"}
    except requests.exceptions.RequestException as e:
        logger.error(f"Network error deleting all connections to PG: {str(e)}")
        return {"status": False, "error": f"Network error: {str(e)}"}
    except KeyError as e:
        logger.error(f"Invalid response deleting connections: {str(e)}")
        return {"status": False, "error": f"Invalid response: {str(e)}"}
    except Exception as e:
        logger.error(f"Unexpected error deleting all connections to PG: {str(e)}")
        return {"status": False, "error": f"Unexpected error: {str(e)}"}


def delete_processor_to_child_pg_connection(
    parent_pg_id: str,
    processor_id: str,
    child_pg_id: str,
    NIFI_URL: str
) -> Dict[str, Any]:
    """
    Deletes the connection from a processor in a parent PG to a child PG input port.
    
    Args:
        parent_pg_id: Parent Process Group ID
        processor_id: Processor ID in parent PG
        child_pg_id: Child Process Group ID
        NIFI_URL: Base URL of the NiFi instance
        
    Returns:
        Operation status
    """
    try:
        # Get all connections in the parent PG
        r = requests.get(f"{NIFI_URL}/flow/process-groups/{parent_pg_id}")
        r.raise_for_status()
        
        connections = r.json()["processGroupFlow"]["flow"].get("connections", [])

        # Find matching connection
        target = None
        for c in connections:
            src = c["component"]["source"]
            dst = c["component"]["destination"]

            # Look for processor-to-input-port connection
            if (
                src["type"] == "PROCESSOR"
                and src["id"] == processor_id
                and src["groupId"] == parent_pg_id
                and dst["type"] == "INPUT_PORT"
                and dst["groupId"] == child_pg_id
            ):
                target = c
                break

        if not target:
            logger.error("⚠️ Connection not found — nothing to delete")
            return {"status": True, "message": "Connection not found"}

        conn_id = target["id"]
        version = target["revision"]["version"]

        # Delete connection
        r = requests.delete(
            f"{NIFI_URL}/connections/{conn_id}",
            params={"version": version}
        )
        r.raise_for_status()

        logger.info(f"✅ Deleted connection {conn_id}")
        return {"status": True, "message": f"Connection {conn_id} deleted"}
    except requests.exceptions.RequestException as e:
        logger.error(f"Network error deleting processor to child PG connection: {str(e)}")
        return {"status": False, "error": f"Network error: {str(e)}"}
    except KeyError as e:
        logger.error(f"Invalid response deleting connection: {str(e)}")
        return {"status": False, "error": f"Invalid response: {str(e)}"}
    except Exception as e:
        logger.error(f"Unexpected error deleting processor to child PG connection: {str(e)}")
        return {"status": False, "error": f"Unexpected error: {str(e)}"}


def safe_delete_process_group(pg_id: str, NIFI_URL: str) -> Dict[str, Any]:
    """
    Safely deletes a process group by stopping all components and emptying queues first.
    
    Args:
        pg_id: Process Group ID
        NIFI_URL: Base URL of the NiFi instance
        
    Returns:
        Operation status
    """
    try:
        logger.info(f"⚠ Deleting Process Group {pg_id}")

        # Stop all components safely
        stop_result = stop_all_processors(pg_id, NIFI_URL)
        if not stop_result["status"]:
            logger.error("Warning: Failed to stop some processors")
            
        stop_ports_result = stop_all_ports(pg_id, NIFI_URL)
        if not stop_ports_result["status"]:
            logger.error("Warning: Failed to stop some ports")
            
        empty_queues_result = empty_all_queues(pg_id, NIFI_URL)
        if not empty_queues_result["status"]:
            logger.error("Warning: Failed to empty some queues")
            
        disable_services_result = disable_all_controller_services(pg_id, NIFI_URL)
        if not disable_services_result["status"]:
            logger.error("Warning: Failed to disable some controller services")

        # Allow NiFi to settle
        time.sleep(2)
        logger.info(f"Deleting PG: {pg_id}")
        
        # Delete the process group
        delete_result = delete_process_group(pg_id, NIFI_URL)
        
        if delete_result["status"]:
            return {"status": True, "message": "Process Group deleted safely"}
        else:
            return delete_result
            
    except requests.exceptions.RequestException as e:
        logger.error(f"Network error in safe delete process group: {str(e)}")
        return {"status": False, "error": f"Network error: {str(e)}"}
    except Exception as e:
        logger.error(f"Unexpected error in safe delete process group: {str(e)}")
        return {"status": False, "error": f"Unexpected error: {str(e)}"}


def start_process_group(pg_id: str, NIFI_URL: str) -> Dict[str, Any]:
    """
    Starts all processors in a process group.
    
    Args:
        pg_id: Process Group ID
        NIFI_URL: Base URL of the NiFi instance
        
    Returns:
        Operation status
    """
    try:
        processors_data = get_processors_in_pg(pg_id, NIFI_URL)
        if not processors_data["status"]:
            return processors_data
            
        processors = processors_data["data"]
        
        if not processors:
            logger.info("No processors in process group")
            return {"status": True, "message": "No processors to start"}
            
        # Start each processor that is not already running
        for p in processors:
            if p["component"]["state"] != "RUNNING":
                start_result = start_processor(p['id'], NIFI_URL)
                if not start_result["status"]:
                    logger.error(f"Failed to start processor {p['id']}")
                    
        return {"status": True, "message": f"All processors in PG {pg_id} started"}
    except requests.exceptions.RequestException as e:
        logger.error(f"Network error starting process group: {str(e)}")
        return {"status": False, "error": f"Network error: {str(e)}"}
    except Exception as e:
        logger.error(f"Unexpected error starting process group: {str(e)}")
        return {"status": False, "error": f"Unexpected error: {str(e)}"}


def create_execute_sql_processor(
    pg_id: str,
    name: str,
    position_x: float,
    position_y: float,
    dbcp_id: str,
    sql_query: str,
    NIFI_URL: str,
    run_every_minutes: int = 10,
    concurrent_tasks: int = 1,
    start: bool = True
) -> Dict[str, Any]:
    """
    Creates an ExecuteSQL processor using a DBCPConnectionPool service.
    
    Args:
        pg_id: Process Group ID
        name: Processor name
        position_x: X position on canvas
        position_y: Y position on canvas
        dbcp_id: DBCP Connection Pool controller service ID
        sql_query: SQL query to execute
        NIFI_URL: Base URL of the NiFi instance
        run_every_minutes: Scheduling interval in minutes
        concurrent_tasks: Number of concurrent tasks
        start: Whether to start the processor immediately
        
    Returns:
        Created processor ID
    """
    try:
        # Prepare payload for ExecuteSQL processor
        payload = {
            "revision": {"version": 0},
            "component": {
                "type": "org.apache.nifi.processors.standard.ExecuteSQL",
                "name": name,
                "position": {"x": position_x, "y": position_y},
                "config": {
                    "schedulingStrategy": "TIMER_DRIVEN",
                    "schedulingPeriod": f"{run_every_minutes} min",
                    "concurrentlySchedulableTaskCount": concurrent_tasks,
                    "properties": {
                        "Database Connection Pooling Service": dbcp_id,
                        "SQL Query": sql_query,
                        "Max Rows Per Flow File": "0",
                        "Output Format": "JSON"
                    },
                    "autoTerminatedRelationships": ["failure"]
                }
            }
        }

        r = requests.post(
            f"{NIFI_URL}/process-groups/{pg_id}/processors",
            json=payload
        )
        r.raise_for_status()

        processor_id = r.json()["id"]
        logger.info(f"✔ ExecuteSQL processor created: {processor_id}")

        # Start processor if requested
        if start:
            start_result = start_processor(processor_id, NIFI_URL)
            if not start_result["status"]:
                logger.error(f"Warning: Failed to start processor {processor_id}")

        return {"status": True, "processor_id": processor_id}
    except requests.exceptions.RequestException as e:
        logger.error(f"Network error creating ExecuteSQL processor: {str(e)}")
        return {"status": False, "error": f"Network error: {str(e)}"}
    except KeyError as e:
        logger.info(f"Invalid configuration creating ExecuteSQL: {str(e)}")
        return {"status": False, "error": f"Invalid config: {str(e)}"}
    except Exception as e:
        logger.error(f"Unexpected error creating ExecuteSQL processor: {str(e)}")
        return {"status": False, "error": f"Unexpected error: {str(e)}"}


def setup_avro_to_json_services(pg_id: str, NIFI_URL: str) -> Dict[str, Any]:
    """
    Sets up AvroReader and JsonWriter controller services for data conversion.
    
    Args:
        pg_id: Process Group ID
        NIFI_URL: Base URL of the NiFi instance
        
    Returns:
        Tuple of (avro_reader_id, json_writer_id)
    """
    try:
        # Create AvroReader controller service
        avro_reader_result = create_controller_service_by_type(
            pg_id=pg_id,
            cs_type="org.apache.nifi.avro.AvroReader",
            name="AvroReader",
            NIFI_URL=NIFI_URL,
            properties={}
        )
        
        if not avro_reader_result["status"]:
            return avro_reader_result
            
        avro_reader_id = avro_reader_result["cs_id"]
        
        # Enable AvroReader
        enable_avro_result = enable_controller_service(avro_reader_id, NIFI_URL)
        if not enable_avro_result["status"]:
            logger.error(f"Warning: Failed to enable AvroReader {avro_reader_id}")

        # Create JsonWriter controller service
        json_writer_result = create_controller_service_by_type(
            pg_id=pg_id,
            cs_type="org.apache.nifi.json.JsonRecordSetWriter",
            name="JsonWriter",
            NIFI_URL=NIFI_URL,
            properties={}
        )
        
        if not json_writer_result["status"]:
            return json_writer_result
            
        json_writer_id = json_writer_result["cs_id"]
        
        # Enable JsonWriter
        enable_json_result = enable_controller_service(json_writer_id, NIFI_URL)
        if not enable_json_result["status"]:
            logger.error(f"Warning: Failed to enable JsonWriter {json_writer_id}")

        return {
            "status": True,
            "avro_reader_id": avro_reader_id,
            "json_writer_id": json_writer_id
        }
    except requests.exceptions.RequestException as e:
        logger.error(f"Network error setting up Avro to JSON services: {str(e)}")
        return {"status": False, "error": f"Network error: {str(e)}"}
    except Exception as e:
        logger.error(f"Unexpected error setting up Avro to JSON services: {str(e)}")
        return {"status": False, "error": f"Unexpected error: {str(e)}"}


def recreate_process_group(
    parent_pg_id: str,
    name: str,
    pg_json: Dict[str, Any],
    NIFI_URL: str,
    position: Tuple[int, int] = (0, 0),
    id_map: Optional[Dict[str, str]] = None,
    orch_dir: Optional[str] = None,
    ws_port:int = 7777,
    http_port=7778
) -> Dict[str, Any]:
    """
    Recreates a process group from exported JSON data.
    
    Args:
        parent_pg_id: Parent Process Group ID
        name: Process group name
        pg_json: Exported process group JSON data
        NIFI_URL: Base URL of the NiFi instance
        position: Canvas position (x, y)
        id_map: Dictionary for old_id -> new_id mapping
        orch_dir: Orchestration directory path
        
    Returns:
        Created process group details
    """
    try:
        if id_map is None:
            id_map = {}

        # Create the Process Group
       
        new_pg_result = create_process_orch_group(parent_pg_id, name, NIFI_URL, position)
        if not new_pg_result["status"]:
            return new_pg_result
            
        new_pg_id = new_pg_result["data"]["id"]
        
        # Define HTTP controller service for the new PG
        cs_def = {
            "name": "http_cs",
            "type": "org.apache.nifi.http.StandardHttpContextMap",
            "bundle": {
                'group': 'org.apache.nifi',
                'artifact': 'nifi-http-context-map-nar',
                'version': '2.7.2'
            },
            "properties": {"Request Expiration": "5 min"}
        }
        # create websc=ocket
        sc_cs={
                "type": "org.apache.nifi.websocket.jetty.JettyWebSocketServer",
                "bundle": {
                "group": "org.apache.nifi",
                "artifact": "nifi-websocket-services-jetty-nar",
                "version": "2.7.2"
                },
                "name": "JettyWebSocketServer",
                "properties": {
                "Input Buffer Size": "4 kb",
                "Max Text Message Size": "64 kb",
                "Max Binary Message Size": "64 kb",
                "Idle Timeout": "0 sec",
                "Port": ws_port,
                "SSL Context Service": None,
                "Client Authentication": "no",
                "Basic Authentication Enabled": "false",
                "Basic Authentication Path Spec": "/*",
                "Basic Authentication Roles": "**",
                "Login Service": "hash",
                "Users Properties File": None
                }
        }
        # Define JsonTreeReader controller service
        jt = {
            "type": "org.apache.nifi.json.JsonTreeReader",
            "bundle": {
                "group": "org.apache.nifi",
                "artifact": "nifi-record-serialization-services-nar",
                "version": "2.7.2"
            },
            "name": "JsonTreeReader_out",
            "properties": {
                "Schema Access Strategy": "infer-schema",
                "Schema Registry": None,
                "Schema Name": "${schema.name}",
                "Schema Version": None,
                "Schema Branch": None,
                "Schema Text": "${avro.schema}",
                "Schema Reference Reader": None,
                "Schema Inference Cache": None,
                "Starting Field Strategy": "ROOT_NODE",
                "Starting Field Name": None,
                "Schema Application Strategy": "SELECTED_PART",
                "Max String Length": "20 MB",
                "Allow Comments": "false",
                "Date Format": None,
                "Time Format": None,
                "Timestamp Format": None
            }
        }
        
        # Define JsonWriter controller service
        jwr = {
            "type": "org.apache.nifi.json.JsonRecordSetWriter",
            "bundle": {
                "group": "org.apache.nifi",
                "artifact": "nifi-record-serialization-services-nar",
                "version": "2.7.2"
            },
            "name": "JsonWriter_out",
            "properties": {
                "Schema Write Strategy": "no-schema",
                "Schema Cache": None,
                "Schema Reference Writer": None,
                "Schema Access Strategy": "inherit-record-schema",
                "Schema Registry": None,
                "Schema Name": "${schema.name}",
                "Schema Version": None,
                "Schema Branch": None,
                "Schema Text": "${avro.schema}",
                "Schema Reference Reader": None,
                "Date Format": None,
                "Time Format": None,
                "Timestamp Format": None,
                "Pretty Print JSON": "false",
                "Suppress Null Values": "never-suppress",
                "Allow Scientific Notation": "false",
                "Output Grouping": "output-array",
                "Compression Format": "none",
                "Compression Level": "1"
            }
        }
        
        # Map old PG ID to new PG ID
        id_map[pg_json["id"]] = new_pg_id
        logger.info(f"Created new PG: {name}, id={new_pg_id}")

        # Create HTTP controller service
        http_cs_result = create_controller_service(pg_id=new_pg_id, cs_def=cs_def, NIFI_URL=NIFI_URL)
        ws_cs_result = create_controller_service(pg_id=new_pg_id, cs_def=sc_cs, NIFI_URL=NIFI_URL)
        json_tree_reader_out = create_controller_service(pg_id=new_pg_id, cs_def=jt, NIFI_URL=NIFI_URL)
        json_wr_out = create_controller_service(pg_id=new_pg_id, cs_def=jwr, NIFI_URL=NIFI_URL)
        
        logger.info(f"Finishing cs ==> {http_cs_result['data']['id']}  ,{json_tree_reader_out['data']['id']},  {json_wr_out['data']['id']}")
        
        if not http_cs_result["status"]:
            return http_cs_result
        logger.info(f""" ws_cs_result

        {ws_cs_result}


        """)
        http_cs = http_cs_result["data"]
        ws_cs=ws_cs_result['data']
        json_tree_reader_out = json_tree_reader_out['data']
        json_wr_out = json_wr_out['data']
        
        # Enable all controller services
        enable_cs_result = enable_controller_service(cs_id=http_cs["id"], NIFI_URL=NIFI_URL)
        enable_ws_cs_result = enable_controller_service(cs_id=ws_cs["id"], NIFI_URL=NIFI_URL)
        enable_json_tree_reader_out_result = enable_controller_service(cs_id=json_tree_reader_out["id"], NIFI_URL=NIFI_URL)
        enable_json_wr_out_result = enable_controller_service(cs_id=json_wr_out["id"], NIFI_URL=NIFI_URL)
        
        logger.info(f"Finishing cs =enable=> {enable_cs_result['status']}  ,{enable_json_tree_reader_out_result['status']},  {enable_json_wr_out_result['status']}")
        
        if not enable_cs_result["status"]:
            logger.error(f"Warning: Failed to enable HTTP controller service")
        if not enable_json_tree_reader_out_result["status"]:
            logger.error(f"Warning: Failed to enable enable_json_tree_reader_out_result controller service")
        if not enable_json_wr_out_result["status"]:
            logger.error(f"Warning: Failed to enable enable_json_wr_out_result controller service")
            
        # Import additional controller services from file
        import_result = import_controller_services(
            pg_id=new_pg_id,
            file_path="/work/progs/nifi_aut/nifi_srv/nifi_aut/service_controller.json",
            NIFI_URL=NIFI_URL
        )
        
        if not import_result["status"]:
            logger.error(f"Warning: Failed to import some controller services")
            
        #cs_id = import_result.get("last_service_id")
        cs_id = ws_cs["id"]

        # Create orchestration directory if needed
        if orch_dir and not os.path.exists(f"{orch_dir}/{new_pg_id}"):
            os.makedirs(f"{orch_dir}/{new_pg_id}")

        # Recreate processors from JSON
        logger.info("################### Creating processors")
        for proc in pg_json["flow"]["processors"]:
            time.sleep(2)
            logger.info(f"-- Processing: {proc['component']['name']}")
            
            comp = proc["component"]
            
            # Apply modifications based on processor type
            if comp['type'] == 'org.apache.nifi.processors.websocket.ListenWebSocket':
                comp['config']['properties']['WebSocket Server Controller Service'] = cs_id
                
            if comp['type'] == 'org.apache.nifi.processors.standard.HandleHttpRequest':
                comp['config']['properties']['HTTP Context Map'] = http_cs["id"]
                comp['config']['properties']['Allowed Paths'] = "/" + name + "_hr"
                comp['config']['properties']['Listening Port']=http_port
                
            if comp['type'] == 'org.apache.nifi.processors.standard.ExecuteStreamCommand':
                comp["config"]["properties"]['Working Directory'] = f"{orch_dir}/{new_pg_id}"
                comp["config"]["properties"]['Command Arguments'] = f"main_orch.py"
                
            if comp['type'] == 'org.apache.nifi.processors.standard.EvaluateJsonPath':
                comp["config"]["properties"]['question'] = "$.question"
                comp["config"]["descriptors"]['question'] = {
                    "name": "question",
                    "displayName": "question",
                    "description": "",
                    "required": False,
                    "sensitive": False,
                    "dynamic": False,
                    "supportsEl": False,
                    "expressionLanguageScope": "Not Supported",
                    "dependencies": []
                }
                
            if comp['type'] == 'org.apache.nifi.processors.jolt.JoltTransformJSON':
                comp["config"]["properties"]['Jolt Specification'] = """[\n  {\n    \"operation\": \"shift\",\n    \"spec\": {\"question\": \"question\",\n      \"session_id\": \"session_id\",\n      \"timestamp\": \"timestamp\",\n      \"status\": \"status\",\n      \"sources\": \"sources\",\n      \"selected_agents\": \"selected_agents\",\"plan\": {\n        \"agents\": \"agent_plan\"\n      }\n    }\n  },\n  {\n    \"operation\": \"modify-overwrite-beta\",\n    \"spec\": {\n      \"agent_tmp\": \"=join('--,--', @(1,selected_agents))\"\n    }\n  },\n  {\n    \"operation\": \"modify-overwrite-beta\",\n    \"spec\": {\n      \"agent\": \"=concat('--', @(1,agent_tmp), '--')\"\n    }\n  },\n  {\n    \"operation\": \"remove\",\n    \"spec\": {\n      \"agent_tmp\": \"\"\n    }\n  }\n]"""

            # Create processor
            new_proc_result = create_processor_in_pg(new_pg_id, comp, NIFI_URL)
            if new_proc_result["status"]:
                id_map[comp["id"]] = new_proc_result["data"]["id"]

        # Recreate sub-groups recursively
        for sub_pg in pg_json["flow"]["processGroups"]:
            recreate_result = recreate_process_group(
                new_pg_id,
                sub_pg["component"]["name"],
                sub_pg,
                position=(position[0] + 300, position[1] + 300),
                id_map=id_map,
                NIFI_URL=NIFI_URL
            )
            
            if not recreate_result["status"]:
                logger.error(f"Warning: Failed to recreate sub-group {sub_pg['component']['name']}")

        # Bind WebSocket controller service
        ws_cs_result = get_processor_by_type(
            pg_id=new_pg_id,
            processor_type="org.apache.nifi.processors.websocket.ListenWebSocket",
            NIFI_URL=NIFI_URL
        )
        
        if ws_cs_result["status"]:
            ws_cs = ws_cs_result["data"]
            bind_result = bind_websocket_controller_service(ws_cs["id"], cs_id, NIFI_URL)
            if not bind_result["status"]:
                logger.error(f"Warning: Failed to bind WebSocket controller service")

        # Recreate connections
        logger.info("START connections ###################")
        for conn in pg_json["flow"]["connections"]:
            # Map old source/destination IDs to new IDs
            src_old = conn["component"]["source"]["id"]
            dst_old = conn["component"]["destination"]["id"]

            # Skip connection if source or destination not in id_map yet
            if src_old not in id_map or dst_old not in id_map:
                logger.warning(f"Skipping connection {conn['component'].get('name', '')} because IDs not mapped yet")
                continue

            conn_copy = conn.copy()
            conn_copy["component"]["source"]["id"] = id_map[src_old]
            conn_copy["component"]["destination"]["id"] = id_map[dst_old]
            print(f"""create_conn_result""")
            create_conn_result = create_connection(new_pg_id, conn_copy, NIFI_URL)
            print(f"""create_conn_result 
            
            {create_conn_result}
            
            """)
            if not create_conn_result["status"]:
                logger.error(f"Warning: Failed to create connection")
                

        logger.info(f"json_tree_reader_out id: {json_tree_reader_out['id']}")
        logger.info(f"json_wr_out id: {json_wr_out['id']}")
        logger.info(f"http_cs id: {http_cs['id']}")

        return {
            "status": True, 
            "pg_id": new_pg_id, 
            "id_map": id_map,
            'http_cs': http_cs['id'],
            'json_tree_r_out': json_tree_reader_out['id'],
            'json_wr_out': json_wr_out['id']
        }
        
    except requests.exceptions.RequestException as e:
        logger.error(f"Network error recreating process group: {str(e)}")
        return {"status": False, "error": f"Network error: {str(e)}"}
    except KeyError as e:
        logger.error(f"Invalid JSON data recreating process group: {str(e)}")
        return {"status": False, "error": f"Invalid data: {str(e)}"}
    except Exception as e:
        logger.error(f"Unexpected error recreating process group: {str(e)}")
        return {"status": False, "error": f"Unexpected error: {str(e)}"}


def create_update_attribute_processor(
    pg_id: str,
    name: str,
    NIFI_URL: str,
    position_id: int = 0,
    additional_attributes: Optional[Dict[str, str]] = None
) -> Dict[str, Any]:
    """
    Creates an UpdateAttribute processor to add/modify flowfile attributes.
    
    Args:
        pg_id: Process Group ID
        name: Processor name
        NIFI_URL: Base URL of the NiFi instance
        position_id: Position multiplier for canvas layout
        additional_attributes: Dictionary of attributes to add/modify
        
    Returns:
        Created processor details
    """
    try:
        position = (400 * position_id, 100.0)  # Adjusted y position for better layout
        url = f"{NIFI_URL}/process-groups/{pg_id}/processors"
        
        # Default attributes - start with empty dict
        properties = {}
        
        # Add additional attributes if provided
        if additional_attributes:
            properties.update(additional_attributes)
        
        payload = {
            "revision": {"version": 0},
            "component": {
                "type": "org.apache.nifi.processors.attributes.UpdateAttribute",
                "name": name,
                "position": {
                    "x": float(position[0]),
                    "y": float(position[1])
                },
                "config": {
                    "properties": properties,
                    "autoTerminatedRelationships": ["failure"]
                }
            }
        }
        
        r = requests.post(url, json=payload)
        r.raise_for_status()
        
        proc_id = r.json()["id"]
        
        logger.info(f"Created UpdateAttribute processor '{name}' in PG '{pg_id}'")
        
        return {
            "status": True,
            "id": proc_id,
            "name": name,
            "data": r.json()
        }
    except requests.exceptions.RequestException as e:
        logger.error(f"Network error creating UpdateAttribute processor: {str(e)}")
        return {"status": False, "error": f"Network error: {str(e)}"}
    except Exception as e:
        logger.error(f"Unexpected error creating UpdateAttribute processor: {str(e)}")
        return {"status": False, "error": f"Unexpected error: {str(e)}"}


def delete_connection_by_id(
    connection_id: str,
    NIFI_URL: str,
) -> Dict[str, Any]:
    """
    Deletes a NiFi connection by its ID.

    Args:
        connection_id: NiFi connection ID
        NIFI_URL: Base NiFi URL (e.g. https://localhost:8443/nifi-api)

    Returns:
        Deletion status response
    """
    try:
        # Get connection details to fetch revision.version
        get_url = f"{NIFI_URL}/connections/{connection_id}"
        get_resp = requests.get(get_url)
        get_resp.raise_for_status()

        revision = get_resp.json()["revision"]
        version = revision["version"]
        client_id = revision.get("clientId", "python-client")

        # Delete the connection using revision.version
        delete_url = f"{NIFI_URL}/connections/{connection_id}"
        params = {
            "version": version,
            "clientId": client_id
        }

        delete_resp = requests.delete(
            delete_url,
            params=params
        )
        delete_resp.raise_for_status()

        return {
            "status": "deleted",
            "connection_id": connection_id
        }
    except requests.exceptions.RequestException as e:
        logger.error(f"Network error deleting connection by ID: {str(e)}")
        return {"status": False, "error": f"Network error: {str(e)}"}
    except KeyError as e:
        logger.error(f"Invalid response deleting connection: {str(e)}")
        return {"status": False, "error": f"Invalid response: {str(e)}"}
    except Exception as e:
        logger.error(f"Unexpected error deleting connection by ID: {str(e)}")
        return {"status": False, "error": f"Unexpected error: {str(e)}"}


def create_update_record_processor(
    pg_id: str,
    name: str,
    NIFI_URL: str,
    record_reader: str,
    record_writer: str,
    position_id: int = 0,
    record_properties: Optional[Dict[str, str]] = None
) -> Dict[str, Any]:
    """
    Creates an UpdateRecord processor to update record fields using RecordPath.

    Args:
        pg_id: Process Group ID
        name: Processor name
        NIFI_URL: Base URL of the NiFi instance
        record_reader: Record Reader Controller Service ID
        record_writer: Record Writer Controller Service ID
        position_id: Position multiplier for canvas layout
        record_properties: RecordPath -> value mappings

    Returns:
        Created processor details
    """
    try:
        position = (400 * position_id, 200.0)
        url = f"{NIFI_URL}/process-groups/{pg_id}/processors"

        # Default UpdateRecord properties
        properties = {
            "Record Reader": record_reader,
            "Record Writer": record_writer
        }

        # Add RecordPath update rules
        if record_properties:
            properties.update(record_properties)

        payload = {
            "revision": {"version": 0},
            "component": {
                "type": "org.apache.nifi.processors.standard.UpdateRecord",
                "name": name,
                "position": {
                    "x": float(position[0]),
                    "y": float(position[1])
                },
                "config": {
                    "properties": properties,
                    "autoTerminatedRelationships": ["failure"]
                }
            }
        }

        r = requests.post(url, json=payload)
        r.raise_for_status()

        proc_id = r.json()["id"]

        logger.info(f"Created UpdateRecord processor '{name}' in PG '{pg_id}'")

        return {
            "status": True,
            "id": proc_id,
            "name": name,
            "data": r.json()
        }

    except requests.exceptions.RequestException as e:
        logger.error(f"Network error creating UpdateRecord processor: {str(e)}")
        return {"status": False, "error": f"Network error: {str(e)}"}
    except KeyError as e:
        logger.info(f"Invalid configuration creating UpdateRecord: {str(e)}")
        return {"status": False, "error": f"Invalid config: {str(e)}"}
    except Exception as e:
        logger.error(f"Unexpected error creating UpdateRecord processor: {str(e)}")
        return {"status": False, "error": f"Unexpected error: {str(e)}"}


#######
#   flow
########
def create_nifi_connection_ports_flow(
        source_id: str,
        source_group_id: str,
        source_name: str,
        source_type: str,
        destination_id: str,
        destination_group_id: str,
        destination_name: str,
        destination_type: str,
        parent_group_id: str,
        NIFI_URL: str
) -> Dict[str, Any]:
    """
    Creates a NiFi connection between source and destination components
    and starts Input/Output ports if applicable.

    Args:
        source_id: Source component ID
        source_group_id: Source process group ID
        source_name: Source component name
        source_type: Source type (INPUT_PORT, OUTPUT_PORT, PROCESSOR)
        destination_id: Destination component ID
        destination_group_id: Destination process group ID
        destination_name: Destination component name
        destination_type: Destination type (INPUT_PORT, OUTPUT_PORT, PROCESSOR)
        parent_group_id: Process group ID where connection is created
        NIFI_URL: Base NiFi API URL

    Returns:
        Dict with operation status and connection details
    """
    try:
        # Build connection payload
        connection_body = {
            "revision": {"version": 0},
            "component": {
                "parentGroupId": parent_group_id,
                "source": {
                    "id": source_id,
                    "type": source_type,
                    "groupId": source_group_id,
                    "name": source_name
                },
                "destination": {
                    "id": destination_id,
                    "type": destination_type,
                    "groupId": destination_group_id,
                    "name": destination_name
                },
                "backPressureObjectThreshold": 10000,
                "backPressureDataSizeThreshold": "1 GB",
                "flowFileExpiration": "0 sec",
                "loadBalanceStrategy": "DO_NOT_LOAD_BALANCE"
            }
        }

        # Create the connection
        url = f"{NIFI_URL}/process-groups/{parent_group_id}/connections"
        response = requests.post(url, json=connection_body)
        response.raise_for_status()

        connection = response.json()
        connection_id = connection["id"]

        logger.info(f"✔ Connection created: {connection_id}")

        # Start source port if needed
        if source_type in ("INPUT_PORT", "OUTPUT_PORT"):
            start_port_by_id(
                port_id=source_id,
                port_type="input-port" if source_type == "INPUT_PORT" else "output-port",
                NIFI_URL=NIFI_URL
            )
            start_port_by_id(
                port_id=destination_id,
                port_type="input-port" if source_type == "INPUT_PORT" else "output-port",
                NIFI_URL=NIFI_URL
            )

        # Start destination port if needed
        if destination_type in ("INPUT_PORT", "OUTPUT_PORT"):
            start_port_by_id(
                port_id=destination_id,
                port_type="input-port" if destination_type == "INPUT_PORT" else "output-port",
                NIFI_URL=NIFI_URL
            )

        return {
            "status": True,
            "connection_id": connection_id,
            "connection": connection
        }

    except requests.exceptions.RequestException as e:
        logger.error(f"❌ Network error creating NiFi connection: {str(e)}")
        return {
            "status": False,
            "error": f"Network error: {str(e)}"
        }
    except KeyError as e:
        logger.info(f"❌ Invalid configuration creating connection: {str(e)}")
        return {
            "status": False,
            "error": f"Invalid config: {str(e)}"
        }
    except Exception as e:
        logger.error(f"❌ Unexpected error creating NiFi connection: {str(e)}")
        return {
            "status": False,
            "error": f"Unexpected error: {str(e)}"
        }


def create_and_start_stream_flow_no_agent_flow(
    parent_pg_id: str,
    child_pg_name: str,
    NIFI_URL: str,
    ur_json_r: str,
    ur_json_wr: str,
    additional_attributes_update: Optional[Dict[str, str]] = {"agents_ops": """${agents_ops:isEmpty():ifElse("${RouteOnAttribute.Route}","${agents_ops}--${RouteOnAttribute.Route}")}"""},
    additional_ru_update: Optional[Dict[str, str]] = {"/agents_ops": """${agents_ops}"""}
) -> Dict[str, Any]:
    """
    Creates a simple process group with input and output ports only (no agent processors).
    This is used for basic passthrough or routing flows.
    
    Args:
        parent_pg_id: Parent Process Group ID
        child_pg_name: Child process group name
        NIFI_URL: Base URL of the NiFi instance
        ur_json_r: JSON Reader controller service ID
        ur_json_wr: JSON Writer controller service ID
        additional_attributes_update: Additional attributes for UpdateAttribute processor
        additional_ru_update: Additional RecordPath updates for UpdateRecord processor
        
    Returns:
        Dictionary containing status and created component details
    """
    try:
        # Create child Process Group
        pg_result = create_process_group_inside_pg(
            parent_pg_id=parent_pg_id,
            name=child_pg_name,
            NIFI_URL=NIFI_URL,
            position=(200, 200),
            fail_if_exists=False
        )
        
        if not pg_result["status"]:
            return pg_result
            
        child_pg_id = pg_result["id"]

        # Create Input Port
        in_port_result = create_input_port(
            pg_id=child_pg_id,
            name="IN",
            NIFI_URL=NIFI_URL,
            position_id=0
        )

        if not in_port_result["status"]:
            return in_port_result
            
        in_port = in_port_result

        # Create UpdateAttribute processor
        update_attr_result = create_update_attribute_processor(
            pg_id=child_pg_id,
            name=f"{child_pg_name}_UpdateAttributes",
            NIFI_URL=NIFI_URL,
            position_id=1,
            additional_attributes=additional_attributes_update
        )
        
        if not update_attr_result["status"]:
            return update_attr_result
            
        update_attr = update_attr_result

        # Create UpdateRecord processor
        records_update_result = create_update_record_processor(
            pg_id=child_pg_id,
            name=f"{child_pg_name}_UpdateRecord",
            NIFI_URL=NIFI_URL,
            record_reader=ur_json_r,
            record_writer=ur_json_wr,
            record_properties=additional_ru_update
        )
        
        if not records_update_result["status"]:
            return records_update_result
            
        records_update = records_update_result

        # Create Output Port
        out_port_result = create_output_port(
            pg_id=child_pg_id,
            name="OUT",
            NIFI_URL=NIFI_URL,
            position_id=2
        )
        
        if not out_port_result["status"]:
            return out_port_result
            
        time.sleep(4)
        out_port = out_port_result
        
        logger.info("##start out connection ==")
        
        # Create connections between components
        connections = [
            connect_components(
                pg_id=child_pg_id,
                source_id=in_port["id"],
                source_type="INPUT_PORT",
                destination_id=update_attr['id'],
                destination_type="PROCESSOR",
                NIFI_URL=NIFI_URL
            ),
            connect_components(
                pg_id=child_pg_id,
                source_id=update_attr['id'],
                source_type="PROCESSOR",
                destination_id=records_update['id'],
                destination_type="PROCESSOR",
                relationships=["success"],
                NIFI_URL=NIFI_URL
            ),
            connect_components(
                 pg_id=child_pg_id,
                 source_id=records_update['id'],
                 source_type="PROCESSOR",
                 destination_id=out_port['id'],
                 destination_type="OUTPUT_PORT",
                 relationships=["success"],
                 NIFI_URL=NIFI_URL
             )
        ]
        
        # Check connection results
        for conn_result in connections:
            time.sleep(2)
            if not conn_result["status"]:
                logger.error("Warning: Failed to create some connections")

        # Start input port
        try:
            logger.info(f"## Start input-port ++> {in_port['id']}")
            start_input_result = start_port_by_id(
                port_id=in_port["id"],
                port_type="input-port",
                NIFI_URL=NIFI_URL
            )
            if not start_input_result["status"]:
                logger.error(f"Warning: Failed to start input port: {start_input_result.get('error', 'Unknown error')}")
        except Exception as start_error:
            logger.error(f"Warning: Error starting input port: {str(start_error)}")

        # Start output port
        try:
            logger.info(f"## Start output-port ++> {out_port['id']}")
            start_output_result = start_port_by_id(
                port_id=out_port["id"],
                port_type="output-port",
                NIFI_URL=NIFI_URL
            )
            if not start_output_result["status"]:
                logger.error(f"Warning: Failed to start output port: {start_output_result.get('error', 'Unknown error')}")
        except Exception as start_error:
            logger.error(f"Warning: Error starting output port: {str(start_error)}")

        logger.info(f"✅ Created process group '{child_pg_name}' with input and output ports")

        return {
            "status": True,
            "process_group_id": child_pg_id,
            "process_group_name": child_pg_name,
            "input_port": {
                "id": in_port.get("id"),
                "name": in_port.get("name")
            },
            "output_port": {
                "id": out_port.get("id"),
                "name": out_port.get("name")
            },
            "message": f"Process group '{child_pg_name}' created successfully with input/output ports"
        }
        
    except requests.exceptions.RequestException as e:
        logger.error(f"Network error creating stream flow without agent: {str(e)}")
        return {"status": False, "error": f"Network error: {str(e)}"}
    except Exception as e:
        logger.error(f"Unexpected error creating stream flow without agent: {str(e)}")
        return {"status": False, "error": f"Unexpected error: {str(e)}"}


def create_and_enable_dbcp_service(
    pg_id: str,
    name: str,
    jdbc_url: str,
    driver_class: str,
    driver_location: str,
    username: str,
    password: str,
    NIFI_URL: str,
    max_total_connections: str = "10"
) -> Dict[str, Any]:
    """
    Creates and enables a DBCPConnectionPool controller service.
    
    Args:
        pg_id: Process Group ID
        name: Service name
        jdbc_url: JDBC connection URL
        driver_class: Database driver class name
        driver_location: Database driver location path
        username: Database username
        password: Database password
        NIFI_URL: Base URL of the NiFi instance
        max_total_connections: Maximum connection pool size
        
    Returns:
        Controller service ID
    """
    try:
        # Check if service already exists
        r = requests.get(f"{NIFI_URL}/flow/process-groups/{pg_id}/controller-services")
        r.raise_for_status()

        # Search for existing service
        for cs in r.json().get("controllerServices", []):
            if cs["component"]["name"] == name:
                cs_id = cs["id"]
                logger.info(f"✔ Controller service '{name}' already exists")
                
                # Enable if not already enabled
                enable_result = enable_controller_service(cs_id, NIFI_URL)
                if not enable_result["status"]:
                    logger.error(f"Warning: Failed to enable existing service {cs_id}")
                    
                return {"status": True, "cs_id": cs_id}

        # Create new controller service
        payload = {
            "revision": {"version": 0},
            "component": {
                "type": "org.apache.nifi.dbcp.DBCPConnectionPool",
                "name": name,
                "properties": {
                    "Database Connection URL": jdbc_url,
                    "Database Driver Class Name": driver_class,
                    "Database Driver Locations": driver_location,
                    "Database User": username,
                    "Password": password,
                    "Max Total Connections": max_total_connections
                }
            }
        }

        r = requests.post(
            f"{NIFI_URL}/process-groups/{pg_id}/controller-services",
            json=payload
        )
        r.raise_for_status()

        cs_id = r.json()["id"]
        logger.info(f"✔ Created controller service '{name}'")

        # Enable the new controller service
        enable_result = enable_controller_service(cs_id, NIFI_URL)
        if not enable_result["status"]:
            logger.error(f"Warning: Failed to enable new service {cs_id}")

        return {"status": True, "cs_id": cs_id}
    except requests.exceptions.RequestException as e:
        logger.error(f"Network error creating and enabling DBCP service: {str(e)}")
        return {"status": False, "error": f"Network error: {str(e)}"}
    except KeyError as e:
        logger.info(f"Invalid configuration creating DBCP service: {str(e)}")
        return {"status": False, "error": f"Invalid config: {str(e)}"}
    except Exception as e:
        logger.error(f"Unexpected error creating and enabling DBCP service: {str(e)}")
        return {"status": False, "error": f"Unexpected error: {str(e)}"}


def create_sql_to_json_jsonfile_flow(
    pg_id: str,
    sql_name: str,
    sql_query: str,
    dbcp_id: str,
    output_dir: str,
    output_filename: str,
    NIFI_URL: str,
    position_x: float = 0,
    position_y: float = 0,
    run_every_minutes: int = 10,
    start: bool = True
) -> Dict[str, Any]:
    """
    Creates a complete SQL to JSON file flow in NiFi.
    
    Args:
        pg_id: Process Group ID
        sql_name: SQL processor name
        sql_query: SQL query to execute
        dbcp_id: DBCP connection pool service ID
        output_dir: Output directory path
        output_filename: Output filename
        NIFI_URL: Base URL of the NiFi instance
        position_x: Starting X position
        position_y: Starting Y position
        run_every_minutes: Scheduling interval in minutes
        start: Whether to start processors immediately
        
    Returns:
        Flow creation status and component IDs
    """
    try:

        # Setup Avro to JSON controller services
        services_result = setup_avro_to_json_services(pg_id, NIFI_URL)
        if not services_result["status"]:
            return services_result
            

        avro_reader_id = services_result["avro_reader_id"]

        json_writer_id = services_result["json_writer_id"]

        
        # Create ExecuteSQL processor
        exec_sql_result = create_execute_sql_processor(
            pg_id=pg_id,
            name=sql_name,
            position_x=position_x,
            position_y=position_y,
            dbcp_id=dbcp_id,
            sql_query=sql_query,
            run_every_minutes=run_every_minutes,
            start=False,
            NIFI_URL=NIFI_URL
        )
        
        if not exec_sql_result["status"]:
            return exec_sql_result
            
        exec_sql_proc_id = exec_sql_result["processor_id"]
        
        # Create ConvertRecord processor (Avro → JSON)
        convert_payload = {
            "revision": {"version": 0},
            "component": {
                "type": "org.apache.nifi.processors.standard.ConvertRecord",
                "name": f"{sql_name}_AvroToJson",
                "position": {"x": position_x + 300, "y": position_y},
                "config": {
                    "properties": {
                        "Record Reader": avro_reader_id,
                        "Record Writer": json_writer_id
                    },
                    "autoTerminatedRelationships": ["failure"]
                }
            }
        }
        
        r = requests.post(
            f"{NIFI_URL}/process-groups/{pg_id}/processors",
            json=convert_payload
        )
        r.raise_for_status()
        convert_proc_id = r.json()["id"]
        
        # Create UpdateAttribute processor (set filename)
        update_attr_payload = {
            "revision": {"version": 0},
            "component": {
                "type": "org.apache.nifi.processors.attributes.UpdateAttribute",
                "name": f"{sql_name}_SetFilename",
                "position": {"x": position_x + 450, "y": position_y},
                "config": {
                    "properties": {
                        "filename": output_filename
                    },
                    "autoTerminatedRelationships": ["failure"]
                }
            }
        }
        
        r = requests.post(
            f"{NIFI_URL}/process-groups/{pg_id}/processors",
            json=update_attr_payload
        )
        r.raise_for_status()
        update_attr_id = r.json()["id"]
        
        # Create PutFile processor
        putfile_payload = {
            "revision": {"version": 0},
            "component": {
                "type": "org.apache.nifi.processors.standard.PutFile",
                "name": f"{sql_name}_PutFile",
                "position": {"x": position_x + 650, "y": position_y},
                "config": {
                    "properties": {
                        "Directory": output_dir + "/" + pg_id,
                        "Conflict Resolution Strategy": "replace",
                        "Create Missing Directories": "true"
                    },
                    "autoTerminatedRelationships": ["failure", "success"]
                }
            }
        }
        
        r = requests.post(
            f"{NIFI_URL}/process-groups/{pg_id}/processors",
            json=putfile_payload
        )
        r.raise_for_status()
        putfile_id = r.json()["id"]

        # Create connections between processors
        connections = [
            # ExecuteSQL → ConvertRecord
            connect_components(
                pg_id=pg_id,
                source_id=exec_sql_proc_id,
                source_type="PROCESSOR",
                destination_id=convert_proc_id,
                destination_type="PROCESSOR",
                relationships=["success"],
                NIFI_URL=NIFI_URL
            ),
            # ConvertRecord → UpdateAttribute
            connect_components(
                pg_id=pg_id,
                source_id=convert_proc_id,
                source_type="PROCESSOR",
                destination_id=update_attr_id,
                destination_type="PROCESSOR",
                relationships=["success"],
                NIFI_URL=NIFI_URL
            ),
            # UpdateAttribute → PutFile
            connect_components(
                pg_id=pg_id,
                source_id=update_attr_id,
                source_type="PROCESSOR",
                destination_id=putfile_id,
                destination_type="PROCESSOR",
                relationships=["success"],
                NIFI_URL=NIFI_URL
            )
        ]
        
        # Check if any connection failed
        for conn_result in connections:
            if not conn_result["status"]:
                logger.error("Warning: Failed to create some connections")

        # Start processors if requested
        if start:
            processor_ids = [exec_sql_proc_id, convert_proc_id, update_attr_id, putfile_id]
            for pid in processor_ids:
                proc_result = get_processor_by_id(pid, NIFI_URL)
                if proc_result["status"]:
                    start_result = start_processor(pid, NIFI_URL)
                    if not start_result["status"]:
                        logger.error(f"Warning: Failed to start processor {pid}")

        return {
            "status": True,
            "pg_id": pg_id,
            "processors": {
                "execute_sql": exec_sql_proc_id,
                "convert_record": convert_proc_id,
                "update_attribute": update_attr_id,
                "putfile": putfile_id
            },
            "output": {
                "directory": output_dir,
                "filename": output_filename
            }
        }
    except requests.exceptions.RequestException as e:
        logger.error(f"Network error creating SQL to JSON file flow: {str(e)}")
        return {"status": False, "error": f"Network error: {str(e)}"}
    except KeyError as e:
        logger.info(f"Invalid configuration creating SQL to JSON flow: {str(e)}")
        return {"status": False, "error": f"Invalid config: {str(e)}"}
    except Exception as e:
        logger.error(f"Unexpected error creating SQL to JSON file flow: {str(e)}")
        return {"status": False, "error": f"Unexpected error: {str(e)}"}


def create_and_start_stream_flow(
    parent_pg_id: str,
    child_pg_name: str,
    command: str,
    http_cs_id: str,
    NIFI_URL: str,
    additional_attributes: Optional[Dict[str, str]],
    command_arguments: str = "",
    working_dir: str = ""
) -> Dict[str, Any]:
    """
    Creates and starts a complete stream processing flow.
    
    Args:
        parent_pg_id: Parent Process Group ID
        child_pg_name: Child process group name
        command: Command to execute
        http_cs_id: HTTP context map controller service ID
        NIFI_URL: Base URL of the NiFi instance
        additional_attributes: Additional attributes for UpdateAttribute processor
        command_arguments: Command arguments
        working_dir: Working directory
        
    Returns:
        Flow creation status and component IDs
    """
    try:
        # Create child Process Group
        pg_result = create_process_group_inside_pg(
            parent_pg_id=parent_pg_id,
            name=child_pg_name,
            NIFI_URL=NIFI_URL,
            position=(200, 200),
            fail_if_exists=False
        )
        
        if not pg_result["status"]:
            return pg_result
            
        child_pg_id = pg_result["id"]

        # Create Input Port
        in_port_result = create_input_port(
            pg_id=child_pg_id,
            name="IN",
            NIFI_URL=NIFI_URL,
            position_id=0
        )
        
        if not in_port_result["status"]:
            return in_port_result
            
        in_port = in_port_result
        
        # Create UpdateAttribute processor
        update_attr_result = create_update_attribute_processor(
            pg_id=child_pg_id,
            name=f"{child_pg_name}_UpdateAttributes",
            NIFI_URL=NIFI_URL,
            position_id=1,
            additional_attributes=additional_attributes
        )
        
        if not update_attr_result["status"]:
            return update_attr_result
            
        update_attr = update_attr_result
        
        # Create ExecuteStreamCommand processor
        exec_proc_result = create_execute_stream_command(
            pg_id=child_pg_id,
            NIFI_URL=NIFI_URL,
            name="Execute_Command",
            command=command,
            command_arguments=command_arguments,
            working_dir=working_dir,
            position_id=1
        )
        
        if not exec_proc_result["status"]:
            return exec_proc_result
            
        exec_proc = exec_proc_result

        # Create Output Port
        out_port_result = create_output_port(
            pg_id=child_pg_id,
            name="OUT",
            NIFI_URL=NIFI_URL,
            position_id=2
        )
        
        if not out_port_result["status"]:
            return out_port_result
            
        out_port = out_port_result

        # Create PutWebSocket processor
        ws_out_result = create_put_websocket(
            pg_id=child_pg_id,
            name=child_pg_name + "_WS_out",
            NIFI_URL=NIFI_URL,
            comp={
                "WebSocket Session Id": "${websocket.session.id}",
                "WebSocket Controller Service Id": "${websocket.controller.service.id}",
                "WebSocket Endpoint Id": "${websocket.endpoint.id}",
                "WebSocket Message Type": "TEXT"
            }
        )
        
        if not ws_out_result["status"]:
            return ws_out_result
            
        ws_out = ws_out_result["data"]

        # Create HandleHttpResponse processor
        http_res_result = add_handle_http_response(
            pg_id=child_pg_id,
            processor_name=child_pg_name,
            NIFI_URL=NIFI_URL,
            http_cs_id=http_cs_id
        )
        
        if not http_res_result["status"]:
            return http_res_result
            
        http_res = http_res_result["data"]

        # Create connections between components
        connections = [
            # Input Port → UpdateAttribute
            connect_components(
                pg_id=child_pg_id,
                source_id=in_port["id"],
                source_type="INPUT_PORT",
                destination_id=update_attr["id"],
                destination_type="PROCESSOR",
                NIFI_URL=NIFI_URL
            ),
            # UpdateAttribute → ExecuteStreamCommand
            connect_components(
                pg_id=child_pg_id,
                source_id=update_attr["id"],
                source_type="PROCESSOR",
                destination_id=exec_proc["id"],
                destination_type="PROCESSOR",
                relationships=["success"],
                NIFI_URL=NIFI_URL
            ),
            # ExecuteStreamCommand → Output Port
            connect_components(
                pg_id=child_pg_id,
                source_id=exec_proc["id"],
                source_type="PROCESSOR",
                destination_id=out_port["id"],
                destination_type="OUTPUT_PORT",
                relationships=["output stream"],
                NIFI_URL=NIFI_URL
            ),
            # ExecuteStreamCommand → PutWebSocket
            connect_components(
                pg_id=child_pg_id,
                source_id=exec_proc["id"],
                source_type="PROCESSOR",
                destination_id=ws_out["id"],
                destination_type="PROCESSOR",
                relationships=["output stream"],
                NIFI_URL=NIFI_URL
            ),
            # ExecuteStreamCommand → HandleHttpResponse
            connect_components(
                pg_id=child_pg_id,
                source_id=exec_proc["id"],
                source_type="PROCESSOR",
                destination_id=http_res["id"],
                destination_type="PROCESSOR",
                relationships=["output stream"],
                NIFI_URL=NIFI_URL
            )
        ]
        
        # Check connection results
        for conn_result in connections:
            if not conn_result["status"]:
                logger.error("Warning: Failed to create some connections")

        # Start processors
        time.sleep(4)
        start_results = [
            start_processor(exec_proc['id'], NIFI_URL),
            start_processor(ws_out['id'], NIFI_URL),
            start_processor(http_res['id'], NIFI_URL),
            start_processor(update_attr['id'], NIFI_URL),
        ]
        
        for start_result in start_results:
            if not start_result["status"]:
                logger.error("Warning: Failed to start some processors")

        logger.info("✅ Flow created, connected, and started successfully")

        return {
            "status": True,
            "process_group_id": child_pg_id,
            "input_port": in_port,
            "processor": exec_proc,
            "output_port": out_port,
            "websocket_out": ws_out,
            "http_response": http_res,
            "update_attribute": update_attr,
        }
    except requests.exceptions.RequestException as e:
        logger.error(f"Network error creating and starting stream flow: {str(e)}")
        return {"status": False, "error": f"Network error: {str(e)}"}
    except KeyError as e:
        logger.info(f"Invalid configuration creating stream flow: {str(e)}")
        return {"status": False, "error": f"Invalid config: {str(e)}"}
    except Exception as e:
        logger.error(f"Unexpected error creating and starting stream flow: {str(e)}")
        return {"status": False, "error": f"Unexpected error: {str(e)}"}


def remove_agent(
    parent_pg_id: str,
    agent_pg_id: str,
    router_id: str,
    rule_name: str,
    out_input_port: str,
    out_con_id: str,
    NIFI_URL: str
) -> Dict[str, Any]:
    """
    Removes an agent from the flow by stopping components and deleting connections.
    
    Args:
        parent_pg_id: Parent Process Group ID
        agent_pg_id: Agent Process Group ID to remove
        router_id: Router processor ID
        rule_name: RouteOnAttribute rule name to remove
        out_input_port: Output input port ID
        out_con_id: Output connection ID
        NIFI_URL: Base URL of the NiFi instance
        
    Returns:
        Operation status
    """
    try:
        # Stop the agent process group
        stop_pg_result = stop_process_group(agent_pg_id, NIFI_URL)
        if not stop_pg_result["status"]:
            logger.error(f"Warning: Failed to stop process group {agent_pg_id}")

        # Stop the router processor
        stop_router_result = stop_processor(router_id, NIFI_URL)
        if not stop_router_result["status"]:
            logger.error(f"Warning: Failed to stop router processor {router_id}")
            
        # Get and stop all ports in the agent PG
        ports = get_ports_in_process_group(process_group_id=agent_pg_id, NIFI_URL=NIFI_URL)
        logger.info(f"Ports found: {len(ports) if isinstance(ports, list) else ports}")
        for i in ports:
            stop_port_by_id(port_id=i['port_id'], port_type=str(i['port_type']).lower().strip(), NIFI_URL=NIFI_URL)
            
        # Stop output input port
        stop_port_by_id(port_id=out_input_port, port_type='input_port', NIFI_URL=NIFI_URL)
        
        # Remove output connection
        logger.info(f"Removing out connection: {out_con_id}")
        delete_connection_by_id(connection_id=out_con_id, NIFI_URL=NIFI_URL)
        
        # Remove the route rule
        remove_rule_result = remove_route_on_attribute_rule(
            route_proc_id=router_id,
            rule_name=rule_name,
            NIFI_URL=NIFI_URL
        )
        if not remove_rule_result["status"]:
            logger.error(f"Warning: Failed to remove rule {rule_name}")
            
        # Delete all connections to the agent PG
        delete_conns_result = delete_all_connections_to_pg(agent_pg_id, NIFI_URL)
        if not delete_conns_result["status"]:
            logger.error(f"Warning: Failed to delete some connections to PG {agent_pg_id}")

        # Delete specific processor to child PG connection
        delete_proc_conn_result = delete_processor_to_child_pg_connection(
            parent_pg_id=parent_pg_id,
            processor_id=router_id,
            child_pg_id=agent_pg_id,
            NIFI_URL=NIFI_URL
        )
        if not delete_proc_conn_result["status"]:
            logger.error(f"Warning: Failed to delete processor to child PG connection")

        # Delete the agent process group
        delete_pg_result = delete_process_group(agent_pg_id, NIFI_URL)
        if not delete_pg_result["status"]:
            return delete_pg_result

        # Restart the router processor
        start_router_result = start_processor(router_id, NIFI_URL)
        for i in ports:
            #stop_port_by_id(port_id=i['port_id'], port_type=str(i['port_type']).lower().strip(), NIFI_URL=NIFI_URL)
            start_port_by_id(port_id=i['port_id'], port_type=str(i['port_type']).lower().strip(), NIFI_URL=NIFI_URL)
        # Stop output input port
        start_port_by_id(port_id=out_input_port, port_type='input_port', NIFI_URL=NIFI_URL)
        if not start_router_result["status"]:
            logger.error(f"Warning: Failed to restart router processor {router_id}")

        return {"status": True, "message": f"Agent {agent_pg_id} removed successfully"}
    except requests.exceptions.RequestException as e:
        logger.error(f"Network error removing agent: {str(e)}")
        return {"status": False, "error": f"Network error: {str(e)}"}
    except KeyError as e:
        logger.error(f"Invalid response removing agent: {str(e)}")
        return {"status": False, "error": f"Invalid response: {str(e)}"}
    except Exception as e:
        logger.error(f"Unexpected error removing agent: {str(e)}")
        return {"status": False, "error": f"Unexpected error: {str(e)}"}



# #########################################
# #########################################
# multi direction 
# ##########################################################
# #############################################
def create_evaluate_json_path(
    pg_id: str,
    name: str,
    NIFI_URL: str,
    attributes: Dict[str, str],
    destination: str = "flowfile-attribute",
    return_type: str = "auto-detect",
    path_not_found: str = "ignore",
    null_value_representation: str = "empty string",
    position_id: int = 0,
    auto_terminate_failure: bool = True,
    auto_terminate_unmatched: bool = True,
    auto_terminate_matched: bool = False,
) -> Dict[str, Any]:
    """
    Creates an EvaluateJsonPath processor with multiple dynamic attributes.

    Each entry in the `attributes` dict becomes a dynamic property on the
    processor where the key is the resulting flowfile attribute name and the
    value is the JSONPath expression (e.g. ``$.question``).

    Args:
        pg_id: Target Process Group ID
        name: Processor display name
        NIFI_URL: Base URL of the NiFi instance (e.g. https://host:8443/nifi-api)
        attributes: Mapping of attribute-name -> JSONPath expression.
                    Example: {"question": "$.question", "session_id": "$.session_id"}
        destination: Where to put evaluated results.
                     "flowfile-attribute" (default) or "flowfile-content"
        return_type: "auto-detect" (default), "json", or "scalar"
        path_not_found: Behaviour when path is not found - "warn" (default) or "skip"
        null_value_representation: How to represent null - "empty string" (default) or "the string 'null'"
        position_id: Position multiplier for canvas layout
        auto_terminate_failure: Auto-terminate the 'failure' relationship
        auto_terminate_unmatched: Auto-terminate the 'unmatched' relationship
        auto_terminate_matched: Auto-terminate the 'matched' relationship

    Returns:
        dict with keys: status (bool), id, name, data  –  or status=False and error on failure
    """
    try:
        position = (400 * position_id, 100.0)
        url = f"{NIFI_URL}/process-groups/{pg_id}/processors"

        # --- static (built-in) properties ---
        properties: Dict[str, Any] = {
            "Destination": destination,
            "Return Type": return_type,
            "Path Not Found Behavior": path_not_found,
            "Null Value Representation": null_value_representation,
        }

        # --- dynamic properties (user-defined JSONPath attributes) ---
        descriptors: Dict[str, Any] = {}
        for attr_name, json_path in attributes.items():
            properties[attr_name] = json_path
            descriptors[attr_name] = {
                "name": attr_name,
                "displayName": attr_name,
                "description": "",
                "required": False,
                "sensitive": False,
                "dynamic": True,
                "supportsEl": False,
                "expressionLanguageScope": "Not Supported",
                "dependencies": [],
            }

        # --- auto-terminated relationships ---
        auto_terminated: List[str] = []
        if auto_terminate_failure:
            auto_terminated.append("failure")
        if auto_terminate_unmatched:
            auto_terminated.append("unmatched")
        if auto_terminate_matched:
            auto_terminated.append("matched")

        payload = {
            "revision": {"version": 0},
            "component": {
                "type": "org.apache.nifi.processors.standard.EvaluateJsonPath",
                "name": name,
                "position": {
                    "x": float(position[0]),
                    "y": float(position[1]),
                },
                "config": {
                    "properties": properties,
                    "descriptors": descriptors,
                    "autoTerminatedRelationships": auto_terminated,
                },
            },
        }

        r = requests.post(url, json=payload)
        r.raise_for_status()

        proc_id = r.json()["id"]
        logger.info(
            f"Created EvaluateJsonPath '{name}' with {len(attributes)} attribute(s) "
            f"in PG '{pg_id}'"
        )

        return {
            "status": True,
            "id": proc_id,
            "name": name,
            "data": r.json(),
        }
    except requests.exceptions.RequestException as e:
        logger.error(f"Network error creating EvaluateJsonPath: {str(e)}")
        return {"status": False, "error": f"Network error: {str(e)}"}
    except KeyError as e:
        logger.info(f"Invalid configuration for EvaluateJsonPath: {str(e)}")
        return {"status": False, "error": f"Invalid config: {str(e)}"}
    except Exception as e:
        logger.error(f"Unexpected error creating EvaluateJsonPath: {str(e)}")
        return {"status": False, "error": f"Unexpected error: {str(e)}"}


def create_route_on_attribute(
    pg_id: str,
    name: str,
    NIFI_URL: str,
    rules: Dict[str, str],
    routing_strategy: str = "Route to Property name",
    position_id: int = 0,
    auto_terminate_unmatched: bool = True,
) -> Dict[str, Any]:
    """
    Creates a RouteOnAttribute processor with multiple routing rules already
    configured.

    Each entry in ``rules`` becomes a dynamic property (relationship) on the
    processor.  The key is the relationship / rule name and the value is a
    NiFi Expression Language expression that must evaluate to ``true`` for a
    FlowFile to be routed to that relationship.

    Example::

        create_route_on_attribute(
            pg_id=pg_id,
            name="Route_By_Agent",
            NIFI_URL=NIFI_URL,
            rules={
                "is_agent_a": "${selected_agents:contains('agent_a')}",
                "is_agent_b": "${selected_agents:contains('agent_b')}",
                "has_plan":   "${plan:isEmpty():not()}",
            },
        )

    Args:
        pg_id: Target Process Group ID
        name: Processor display name
        NIFI_URL: Base URL of the NiFi instance
        rules: Mapping of rule-name -> NiFi Expression Language expression.
        routing_strategy: "Route to Property name" (default) or
                          "Route to 'matched' if all match" /
                          "Route to 'matched' if any matches"
        position_id: Position multiplier for canvas layout
        auto_terminate_unmatched: Auto-terminate the 'unmatched' relationship

    Returns:
        dict with keys: status (bool), id, name, data — or status=False
        and error on failure.
    """
    try:
        position = (400 * position_id, 100.0)
        url = f"{NIFI_URL}/process-groups/{pg_id}/processors"

        # --- built-in property ---
        properties: Dict[str, Any] = {
            "Routing Strategy": routing_strategy,
        }

        # --- dynamic properties (routing rules) ---
        for rule_name, expression in rules.items():
            properties[rule_name] = expression

        # --- auto-terminated relationships ---
        auto_terminated: List[str] = []
        if auto_terminate_unmatched:
            auto_terminated.append("unmatched")

        payload = {
            "revision": {"version": 0},
            "component": {
                "type": "org.apache.nifi.processors.standard.RouteOnAttribute",
                "name": name,
                "position": {
                    "x": float(position[0]),
                    "y": float(position[1]),
                },
                "config": {
                    "properties": properties,
                    "autoTerminatedRelationships": auto_terminated,
                },
            },
        }

        r = requests.post(url, json=payload)
        r.raise_for_status()

        proc_id = r.json()["id"]
        rule_names = list(rules.keys())
        logger.info(
            f"Created RouteOnAttribute '{name}' with {len(rules)} rule(s) "
            f"{rule_names} in PG '{pg_id}'"
        )

        return {
            "status": True,
            "id": proc_id,
            "name": name,
            "data": r.json(),
        }
    except requests.exceptions.RequestException as e:
        logger.error(f"Network error creating RouteOnAttribute: {str(e)}")
        return {"status": False, "error": f"Network error: {str(e)}"}
    except KeyError as e:
        logger.info(f"Invalid configuration for RouteOnAttribute: {str(e)}")
        return {"status": False, "error": f"Invalid config: {str(e)}"}
    except Exception as e:
        logger.error(f"Unexpected error creating RouteOnAttribute: {str(e)}")
        return {"status": False, "error": f"Unexpected error: {str(e)}"}

def create_and_start_stream_flow_no_agent_flow_mult(
    parent_pg_id: str,
    child_pg_name: str,
    NIFI_URL: str,
    working_dir:str,
    command:str,
    command_arguments:str,
    ur_json_r: str,
    ur_json_wr: str,
    additional_attributes_update: Optional[Dict[str, str]] = {"agents_ops": """${agents_ops:isEmpty():ifElse("${RouteOnAttribute.Route}","${agents_ops}--${RouteOnAttribute.Route}")}"""},
    additional_ru_update: Optional[Dict[str, str]] = {"/agents_ops": """${agents_ops}"""},
    attribute_evjson:Dict={"next_agent": "$.next_agent", "next_agent_case": "$.next_agent_case","remaining_parallel_slots":"$.remaining_parallel_slots","res":"$.res"}
) -> Dict[str, Any]:
    """
    Creates a simple process group with input and output ports only (no agent processors).
    This is used for basic passthrough or routing flows.
    
    Args:
        parent_pg_id: Parent Process Group ID
        child_pg_name: Child process group name
        NIFI_URL: Base URL of the NiFi instance
        ur_json_r: JSON Reader controller service ID
        ur_json_wr: JSON Writer controller service ID
        additional_attributes_update: Additional attributes for UpdateAttribute processor
        additional_ru_update: Additional RecordPath updates for UpdateRecord processor
        
    Returns:
        Dictionary containing status and created component details
    """
    try:
        # Create child Process Group
        pg_result = create_process_group_inside_pg(
            parent_pg_id=parent_pg_id,
            name=child_pg_name,
            NIFI_URL=NIFI_URL,
            position=(200, 200),
            fail_if_exists=False
        )
        
        if not pg_result["status"]:
            return pg_result
            
        child_pg_id = pg_result["id"]

        # Create Input Port
        in_port_result = create_input_port(
            pg_id=child_pg_id,
            name="IN",
            NIFI_URL=NIFI_URL,
            position_id=0
        )

        if not in_port_result["status"]:
            return in_port_result
            
        in_port = in_port_result

        # Create UpdateAttribute processor
        update_attr_result = create_update_attribute_processor(
            pg_id=child_pg_id,
            name=f"{child_pg_name}_UpdateAttributes",
            NIFI_URL=NIFI_URL,
            position_id=1,
            additional_attributes=additional_attributes_update
        )
        
        if not update_attr_result["status"]:
            return update_attr_result
            
        update_attr = update_attr_result

        # Create UpdateRecord processor
        records_update_result = create_update_record_processor(
            pg_id=child_pg_id,
            name=f"{child_pg_name}_UpdateRecord",
            NIFI_URL=NIFI_URL,
            record_reader=ur_json_r,
            record_writer=ur_json_wr,
            record_properties=additional_ru_update
        )
        
        if not records_update_result["status"]:
            return records_update_result
            
        records_update = records_update_result

        ### excute stream
        exec_proc_result = create_execute_stream_command(
            pg_id=child_pg_id,
            NIFI_URL=NIFI_URL,
            name=f"{child_pg_name}_Execute_Command",
            command=command,
            command_arguments=command_arguments,
            working_dir=working_dir,
            position_id=1
        )
        
        if not exec_proc_result["status"]:
            return exec_proc_result
            
        exec_proc = exec_proc_result

        ###### evaluate
        evjson_proc_result = create_evaluate_json_path(pg_id=child_pg_id,name=f"{child_pg_name}_EvaluateJsonPath",NIFI_URL=NIFI_URL,attributes=attribute_evjson)
        if not evjson_proc_result["status"]:
            return evjson_proc_result
            
        evjson_proc = evjson_proc_result

        ##########add router
        router_proc_result= create_route_on_attribute(pg_id=child_pg_id,
            NIFI_URL=NIFI_URL,
            name=f"{child_pg_name}_RouteOnAttribute",rules={"next_agent": "${res:equals('1')}"})
        if not router_proc_result["status"]:
            return router_proc_result
            
        router_proc = router_proc_result

        ###################################### HTTPhandler
        http_cs_result = get_controller_service_by_name(
            pg_id=parent_pg_id, 
            service_name="http_cs", 
            NIFI_URL=NIFI_URL
            )
        logger.info(f"http_cs_result id: {http_cs_result['data']['id']}")
        http_sc_id =http_cs_result['data']['id']
        http_res_result = add_handle_http_response(
            pg_id=child_pg_id,
            processor_name=child_pg_name,
            NIFI_URL=NIFI_URL,
            http_cs_id=http_sc_id
        )           
        if not http_res_result["status"]:
            return http_res_result
            
        http_res = http_res_result["data"]
        # Create Output Port
        out_port_result = create_output_port(
            pg_id=child_pg_id,
            name="OUT",
            NIFI_URL=NIFI_URL,
            position_id=2
        )
        
        if not out_port_result["status"]:
            return out_port_result
            
        time.sleep(4)
        out_port = out_port_result
        
        logger.info("##start out connection ==")
        
        #Create connections between components
        connections = [
            connect_components(
                pg_id=child_pg_id,
                source_id=in_port["id"],
                source_type="INPUT_PORT",
                destination_id=update_attr['id'],
                destination_type="PROCESSOR",
                NIFI_URL=NIFI_URL
            ),
            connect_components(
                pg_id=child_pg_id,
                source_id=update_attr['id'],
                source_type="PROCESSOR",
                destination_id=records_update['id'],
                destination_type="PROCESSOR",
                relationships=["success"],
                NIFI_URL=NIFI_URL
            ),
            connect_components(
                pg_id=child_pg_id,
                source_id=records_update['id'],
                source_type="PROCESSOR",
                destination_id=exec_proc['id'],
                destination_type="PROCESSOR",
                relationships=["success"],
                NIFI_URL=NIFI_URL
            ),
            connect_components(
                pg_id=child_pg_id,
                source_id=exec_proc['id'],
                source_type="PROCESSOR",
                destination_id=evjson_proc['id'],
                destination_type="PROCESSOR",
                relationships=["output stream"],
                NIFI_URL=NIFI_URL
            ),
            connect_components(
                pg_id=child_pg_id,
                source_id=evjson_proc['id'],
                source_type="PROCESSOR",
                destination_id=router_proc['id'],
                destination_type="PROCESSOR",
                relationships=["matched"],
                NIFI_URL=NIFI_URL
            ),
            connect_components(
                pg_id=child_pg_id,
                source_id=router_proc['id'],
                source_type="PROCESSOR",
                destination_id=out_port['id'],
                destination_type="PROCESSOR",
                relationships=["next_agent"],
                NIFI_URL=NIFI_URL
            ),
            connect_components(
                 pg_id=child_pg_id,
                 source_id=router_proc['id'],
                 source_type="PROCESSOR",
                 destination_id=http_res['id'],
                 destination_type="OUTPUT_PORT",
                 relationships=["unmatched"],
                 NIFI_URL=NIFI_URL
             )
        ]
        
        #Check connection results
        for conn_result in connections:
            time.sleep(2)
            if not conn_result["status"]:
                logger.error("Warning: Failed to create some connections")

        #Start input port
        try:
            logger.info(f"## Start input-port ++> {in_port['id']}")
            start_input_result = start_port_by_id(
                port_id=in_port["id"],
                port_type="input-port",
                NIFI_URL=NIFI_URL
            )
            if not start_input_result["status"]:
                logger.error(f"Warning: Failed to start input port: {start_input_result.get('error', 'Unknown error')}")
        except Exception as start_error:
            logger.error(f"Warning: Error starting input port: {str(start_error)}")

        # Start output port
        try:
            logger.info(f"## Start output-port ++> {out_port['id']}")
            start_output_result = start_port_by_id(
                port_id=out_port["id"],
                port_type="output-port",
                NIFI_URL=NIFI_URL
            )
            if not start_output_result["status"]:
                logger.error(f"Warning: Failed to start output port: {start_output_result.get('error', 'Unknown error')}")
        except Exception as start_error:
            logger.error(f"Warning: Error starting output port: {str(start_error)}")

        logger.info(f"✅ Created process group '{child_pg_name}' with input and output ports")

        return {
            "status": True,
            "process_group_id": child_pg_id,
            "process_group_name": child_pg_name,
            "input_port": {
                "id": in_port.get("id"),
                "name": in_port.get("name")
            },
            "update_attr": {
                "id": update_attr.get("id"),
                "name": update_attr.get("name")
            },
            "records_update": {
                "id": records_update.get("id"),
                "name": records_update.get("name")
            },
             "exec_proc": {
                "id": exec_proc.get("id"),
                "name": exec_proc.get("name")
            },
             "evjson_proc": {
                "id": evjson_proc.get("id"),
                "name": evjson_proc.get("name")
            },
             "router_proc": {
                "id": router_proc.get("id"),
                "name": router_proc.get("name")
            },
            "http_res": {
                "id": http_res.get("id"),
                "name": http_res.get("name")
            },
            "output_port": {
                "id": out_port.get("id"),
                "name": out_port.get("name")
            },
            "message": f"Process group '{child_pg_name}' created successfully with input/output ports"
        }
        
    except requests.exceptions.RequestException as e:
        logger.error(f"Network error creating stream flow without agent: {str(e)}")
        return {"status": False, "error": f"Network error: {str(e)}"}
    except Exception as e:
        logger.error(f"Unexpected error creating stream flow without agent: {str(e)}")
        return {"status": False, "error": f"Unexpected error: {str(e)}"}


def connect_child_pg_to_processor_flow(
    parent_pg_id: str,
    child_pg_id: str,
    processor_id: str,
    NIFI_URL: str,
    output_port_name: Optional[str] = None,
    relationships: Optional[List[str]] = None,
    name: Optional[str] = None,
    flowfile_expiration: str = "0 sec",
    backpressure_count: int = 10000,
    backpressure_size: str = "1 GB"
) -> Dict[str, Any]:
    """
    Connects a child Process Group's output port to a processor in the parent Process Group.

    This is the reverse of connect_processor_to_child_pg: data flows OUT of the child PG
    through its output port and INTO a processor that lives in the parent PG.

    Args:
        parent_pg_id: Parent Process Group ID (where the processor lives)
        child_pg_id: Child Process Group ID (where the output port lives)
        processor_id: Destination Processor ID in the parent PG
        NIFI_URL: Base URL of the NiFi instance
        output_port_name: Optional name of the output port to use.
                          If None, the first output port found is used.
        relationships: Not typically needed (output ports don't have relationships),
                       kept for API compatibility. Defaults to None.
        name: Optional connection name
        flowfile_expiration: FlowFile expiration time (default "0 sec")
        backpressure_count: Backpressure object threshold (default 10000)
        backpressure_size: Backpressure data size threshold (default "1 GB")

    Returns:
        Operation status with created connection data
    """
    try:
        # Get the child PG's output ports
        r = requests.get(f"{NIFI_URL}/process-groups/{child_pg_id}/output-ports")
        r.raise_for_status()
        output_ports = r.json()["outputPorts"]

        if not output_ports:
            raise Exception(f"Child PG {child_pg_id} has no output ports")

        # Select the output port: by name or use the first one
        output_port = None
        if output_port_name:
            for port in output_ports:
                if port["component"]["name"] == output_port_name:
                    output_port = port
                    break
            if output_port is None:
                available = [p["component"]["name"] for p in output_ports]
                raise Exception(
                    f"Output port '{output_port_name}' not found in child PG {child_pg_id}. "
                    f"Available output ports: {available}"
                )
        else:
            output_port = output_ports[0]

        # Get the destination processor info (for logging)
        r = requests.get(f"{NIFI_URL}/processors/{processor_id}")
        r.raise_for_status()
        processor = r.json()

        # Prepare the connection payload
        connection_payload = {
            "revision": {"version": 0},
            "component": {
                "name": name or f"Connection_from_{output_port['component']['name']}",
                "source": {
                    "id": output_port["id"],
                    "type": "OUTPUT_PORT",
                    "groupId": child_pg_id
                },
                "destination": {
                    "id": processor_id,
                    "type": "PROCESSOR",
                    "groupId": parent_pg_id
                },
                "flowFileExpiration": flowfile_expiration,
                "backPressureDataSizeThreshold": backpressure_size,
                "backPressureObjectThreshold": backpressure_count
            }
        }


        # Create the connection in the parent PG
        url = f"{NIFI_URL}/process-groups/{parent_pg_id}/connections"
        r = requests.post(url, json=connection_payload)
        r.raise_for_status()

        logger.info(
            f"Connected output port '{output_port['component']['name']}' of child PG "
            f"to processor '{processor['component']['name']}' in parent PG."
        )
        return {"status": True, "data": r.json()}
    except requests.exceptions.RequestException as e:
        logger.error(f"Network error connecting child PG output port to processor: {str(e)}")
        return {"status": False, "error": f"Network error: {str(e)}"}
    except KeyError as e:
        logger.error(f"Invalid response connecting child PG output port to processor: {str(e)}")
        return {"status": False, "error": f"Invalid response: {str(e)}"}
    except Exception as e:
        logger.error(f"Unexpected error connecting child PG output port to processor: {str(e)}")
        return {"status": False, "error": f"Unexpected error: {str(e)}"}

def create_and_start_stream_flow_mult(
    parent_pg_id: str,
    child_pg_name: str,
    command: str,
    http_cs_id: str,
    NIFI_URL: str,
    additional_attributes: Optional[Dict[str, str]],
    command_arguments: str = "",
    working_dir: str = ""
) -> Dict[str, Any]:
    """
    Creates and starts a complete stream processing flow.
    
    Args:
        parent_pg_id: Parent Process Group ID
        child_pg_name: Child process group name
        command: Command to execute
        http_cs_id: HTTP context map controller service ID
        NIFI_URL: Base URL of the NiFi instance
        additional_attributes: Additional attributes for UpdateAttribute processor
        command_arguments: Command arguments
        working_dir: Working directory
        
    Returns:
        Flow creation status and component IDs
    """
    try:
        # Create child Process Group
        pg_result = create_process_group_inside_pg(
            parent_pg_id=parent_pg_id,
            name=child_pg_name,
            NIFI_URL=NIFI_URL,
            position=(200, 200),
            fail_if_exists=False
        )
        
        if not pg_result["status"]:
            return pg_result
            
        child_pg_id = pg_result["id"]

        # Create Input Port
        in_port_result = create_input_port(
            pg_id=child_pg_id,
            name="IN",
            NIFI_URL=NIFI_URL,
            position_id=0
        )
        
        if not in_port_result["status"]:
            return in_port_result
            
        in_port = in_port_result
        
        # Create UpdateAttribute processor
        # update_attr_result = create_update_attribute_processor(
        #     pg_id=child_pg_id,
        #     name=f"{child_pg_name}_UpdateAttributes",
        #     NIFI_URL=NIFI_URL,
        #     position_id=1,
        #     additional_attributes=additional_attributes
        # )
        
        # if not update_attr_result["status"]:
        #     return update_attr_result
            
        # update_attr = update_attr_result
        
        # Create ExecuteStreamCommand processor
        exec_proc_result = create_execute_stream_command(
            pg_id=child_pg_id,
            NIFI_URL=NIFI_URL,
            name="Execute_Command",
            command=command,
            command_arguments=command_arguments,
            working_dir=working_dir,
            position_id=1
        )
        
        if not exec_proc_result["status"]:
            return exec_proc_result
            
        exec_proc = exec_proc_result

        # Create Output Port
        out_port_result = create_output_port(
            pg_id=child_pg_id,
            name="OUT",
            NIFI_URL=NIFI_URL,
            position_id=2
        )
        
        if not out_port_result["status"]:
            return out_port_result
            
        out_port = out_port_result

        # Create PutWebSocket processor
        # ws_out_result = create_put_websocket(
        #     pg_id=child_pg_id,
        #     name=child_pg_name + "_WS_out",
        #     NIFI_URL=NIFI_URL,
        #     comp={
        #         "WebSocket Session Id": "${websocket.session.id}",
        #         "WebSocket Controller Service Id": "${websocket.controller.service.id}",
        #         "WebSocket Endpoint Id": "${websocket.endpoint.id}",
        #         "WebSocket Message Type": "TEXT"
        #     }
        # )
        
        # if not ws_out_result["status"]:
        #     return ws_out_result
            
        # ws_out = ws_out_result["data"]

        # Create HandleHttpResponse processor
        # http_res_result = add_handle_http_response(
        #     pg_id=child_pg_id,
        #     processor_name=child_pg_name,
        #     NIFI_URL=NIFI_URL,
        #     http_cs_id=http_cs_id
        # )
        
        # if not http_res_result["status"]:
        #     return http_res_result
            
        # http_res = http_res_result["data"]

        # Create connections between components
        connections = [
            # Input Port → UpdateAttribute
            connect_components(
                pg_id=child_pg_id,
                source_id=in_port["id"],
                source_type="INPUT_PORT",
                destination_id=exec_proc["id"],
                destination_type="PROCESSOR",
                NIFI_URL=NIFI_URL
            ),
            # UpdateAttribute → ExecuteStreamCommand
            # connect_components(
            #     pg_id=child_pg_id,
            #     source_id=update_attr["id"],
            #     source_type="PROCESSOR",
            #     destination_id=exec_proc["id"],
            #     destination_type="PROCESSOR",
            #     relationships=["success"],
            #     NIFI_URL=NIFI_URL
            # ),
            # ExecuteStreamCommand → Output Port
            connect_components(
                pg_id=child_pg_id,
                source_id=exec_proc["id"],
                source_type="PROCESSOR",
                destination_id=out_port["id"],
                destination_type="OUTPUT_PORT",
                relationships=["output stream"],
                NIFI_URL=NIFI_URL
            ),
            # ExecuteStreamCommand → PutWebSocket
            # connect_components(
            #     pg_id=child_pg_id,
            #     source_id=exec_proc["id"],
            #     source_type="PROCESSOR",
            #     destination_id=ws_out["id"],
            #     destination_type="PROCESSOR",
            #     relationships=["output stream"],
            #     NIFI_URL=NIFI_URL
            # ),
            # # ExecuteStreamCommand → HandleHttpResponse
            # connect_components(
            #     pg_id=child_pg_id,
            #     source_id=exec_proc["id"],
            #     source_type="PROCESSOR",
            #     destination_id=http_res["id"],
            #     destination_type="PROCESSOR",
            #     relationships=["output stream"],
            #     NIFI_URL=NIFI_URL
            # )
        ]
        
        # Check connection results
        for conn_result in connections:
            if not conn_result["status"]:
                logger.error("Warning: Failed to create some connections")

        # Start processors
        time.sleep(4)
        start_results = [
            start_processor(exec_proc['id'], NIFI_URL),
            #start_processor(ws_out['id'], NIFI_URL),
            #start_processor(http_res['id'], NIFI_URL),
            #start_processor(update_attr['id'], NIFI_URL),
        ]
        
        for start_result in start_results:
            if not start_result["status"]:
                logger.error("Warning: Failed to start some processors")

        logger.info("✅ Flow created, connected, and started successfully")

        return {
            "status": True,
            "process_group_id": child_pg_id,
            "input_port": in_port,
            "processor": exec_proc,
            "output_port": out_port,
            # "websocket_out": ws_out,
            # "http_response": http_res,
            #"update_attribute": update_attr,
        }
    except requests.exceptions.RequestException as e:
        logger.error(f"Network error creating and starting stream flow: {str(e)}")
        return {"status": False, "error": f"Network error: {str(e)}"}
    except KeyError as e:
        logger.info(f"Invalid configuration creating stream flow: {str(e)}")
        return {"status": False, "error": f"Invalid config: {str(e)}"}
    except Exception as e:
        logger.error(f"Unexpected error creating and starting stream flow: {str(e)}")
        return {"status": False, "error": f"Unexpected error: {str(e)}"}


