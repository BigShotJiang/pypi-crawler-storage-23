def hello() -> str:
    return "Hello from pypline!"
