# Architecture version for this model implementation.
# This must match the on-chain model_architecture_version in ProtocolConfig
# for the current protocol version.
ARCHITECTURE_VERSION = 1
