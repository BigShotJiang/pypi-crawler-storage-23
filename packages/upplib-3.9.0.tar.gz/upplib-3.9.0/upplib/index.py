from upplib import *
from datetime import datetime, timezone, timedelta
from typing import Any, Optional, Union
from upplib.common_package import *
from collections import defaultdict

# 1. 创建全局线程本地变量对象
# 这个对象在不同线程中访问时，属性是完全隔离的
__THREAD_LOCAL_INDEX_DATA = threading.local()


def get_thread_local_index_data() -> dict[str, Any]:
    """
    获取当前线程专属的字典对象。
    用于存储如：数据库连接、用户信息、或者是你代码中用到的 to_print 节流时间戳。
    """
    # 2. 惰性初始化：检查当前线程是否已经绑定了 'data' 属性
    if not hasattr(__THREAD_LOCAL_INDEX_DATA, 'data'):
        # 3. 如果没有，则为当前线程创建一个全新的字典
        __THREAD_LOCAL_INDEX_DATA.data = {}

    # 4. 返回当前线程专属的字典
    return __THREAD_LOCAL_INDEX_DATA.data


def is_all_chinese(text: str) -> bool:
    return bool(re.compile(r'^[\u4e00-\u9fff]+$').match(text))


def remove_chinese(text: str) -> str:
    return re.compile(r'[\u4e00-\u9fff]+').sub('', text)


def rreplace(s: str,
             old: str,
             new: str,
             count: int = 1) -> str:
    return new.join(s.rsplit(old, count))


def to_java_one(s: str) -> str:
    """
    将下划线命名转成驼峰命名
    例如 : user_id -> userId
    例如 : USER_ID -> userId
    例如 : gpsMaxMove_new -> gpsMaxMoveNew
    """
    if s is None or s == '':
        return ''
    r = ''.join(list(map(lambda x: (x[0].upper() + x[1:]) if len(x) > 1 else x[0].upper(), str(s).split('_'))))
    return r[0].lower() + r[1:]


def to_java(s: None | str | list[str] | tuple[str] | set[str]) -> None | str | list[str]:
    if s is None or s == '':
        return s
    if isinstance(s, list) or isinstance(s, tuple) or isinstance(s, set):
        return list(map(lambda x: to_java_one(x), s))
    return to_java_one(s)


def to_java_more(*args: Any) -> None | tuple:
    # 使用列表推导式进行过滤和映射
    r = [to_java(x) for x in args if x is not None]
    if not r:
        return None
    return tuple(r)


def to_underline_one(s: str) -> None | str:
    """
    将驼峰命名转成下划线命名
    例如: userId -> user_id
    """
    if not s:
        return s
    return ''.join(['_' + c.lower() if c.isupper() else c for c in s])


def to_underline(s: None | str | list[str] | tuple[str] | set[str]) -> None | str | list[str]:
    if s == '' or s is None:
        return s
    if isinstance(s, list) or isinstance(s, tuple) or isinstance(s, set):
        return list(map(lambda x: to_underline_one(x), s))
    return to_underline_one(s)


def to_underline_more(*args: Any) -> None | tuple:
    # 使用列表推导式进行过滤和映射
    r = [to_underline(x) for x in args if x is not None]
    if not r:
        return None
    return tuple(r)


# 是否能用 json
def is_json_serializable(param: Any) -> bool:
    # 排除不能被 json 序列化的类型
    if isinstance(param, (bytes, complex, str, int, bool, float)):
        return False
    try:
        json.dumps(param)
        return True
    except (TypeError, OverflowError):
        return False


def is_json(myjson: Any) -> bool:
    """
    判断字符串是否是有效的JSON格式

    参数:
        myjson (str): 要检查的字符串

    返回:
        bool: 如果是有效JSON返回True，否则返回False
    """
    try:
        json.loads(myjson)
    except (ValueError, TypeError):
        return False
    return True


# 文件是否存在
def file_is_empty(file_name: str) -> bool:
    return file_name is None or file_name == '' or not os.path.exists(file_name)


# md5 算法
def do_md5(s: str) -> str:
    return hashlib.md5(s.encode(encoding='UTF-8')).hexdigest()


# sha256 算法
def do_sha256(s: str) -> str:
    h = hashlib.sha256()
    h.update(s.encode('utf-8'))
    return h.hexdigest()


# uuid 类型的随机数, 默认 32 位长度
def random_uuid(length: int = 32) -> str:
    r = uuid.uuid4().hex
    while len(r) < length:
        r += uuid.uuid4().hex
    return r[0:length]


def random_str(length: int = 64,
               start_str: int = 1,
               end_str: int = 32) -> str:
    """
    获得随机数
    length    ：随机数长度
    start_str ：随机数开始的字符的位置,从 1 开始, 包含start_str
    end_str   : 随机数结束的字符的位置, 不包含end_str
    默认的随机数是 : 数字+字母大小写
    """
    c_s = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_'
    r = ''
    start_str = max(1, start_str)
    end_str = min(len(c_s), end_str)
    while len(r) < length:
        r += c_s[random.Random().randint(start_str, end_str) - 1]
    return r


# 字母的随机数, 默认小写
def random_letter(length: int = 10,
                  is_upper: bool = False) -> str:
    r = random_str(length=length, end_str=26)
    return r.upper() if is_upper else r


def random_int(length_or_start: int = 10,
               end: int = None) -> int:
    """
    数字的随机数, 返回 int
    也可以返回指定范围的随机数据
    """
    if end is None:
        return int(random_int_str(length=length_or_start))
    return random.Random().randint(int(length_or_start), int(end) - 1)


# 数字的随机数, 返回 str
def random_int_str(length: int = 10) -> str:
    return random_str(length=length, start_str=53, end_str=62)


def format_fixed_length_string(value: Any, target_length: int) -> str:
    """
    格式化字符串到指定长度，不足左补0，超出则保留右边字符。
    """
    value = str(value)
    if len(value) >= target_length:
        return value[-target_length:]
    return value.zfill(target_length)


# 去掉 str 中的 非数字字符, 然后, 再转化为 int
def to_int(s: Any = None) -> int:
    """
    去掉字符串中的非数字字符（保留小数点），并转为 int 类型。
    如果是 float 类型则转为 int（直接截断小数部分）。
    如果无法解析为数字，返回 0。
    """
    if s is None:
        return 0
    if isinstance(s, int):
        return s
    if isinstance(s, float):
        return int(s)
    s = str(s).strip()
    if not s:
        return 0
    negative = s.startswith('-')
    s_clean = re.sub(r'[^\d.]', '', s)
    if not s_clean or s_clean.count('.') > 1:
        return 0  # 防止非法格式如 "12.3.4"
    cleaned = f"-{s_clean}" if negative else s_clean
    try:
        # 支持带小数点的转 int（自动舍弃小数部分）
        return int(float(cleaned))
    except ValueError:
        return 0


def to_float(s: Any = None,
             precision: int = None) -> float:
    """
    将字符串中的非数字字符（除了小数点）去掉后转为 float。

    :param s: 输入值（可以是字符串或其他类型）
    :param precision: 小数部分保留的位数（多余部分直接截断）
    :return: 转换后的 float 值
    """
    if not s:
        return 0.0
    s = str(s).strip()
    if not s:
        return 0.0
    negative = s.startswith('-')
    # 提取所有数字和小数点
    s_clean = re.sub(r'[^\d.]', '', s)
    if not s_clean or s_clean.count('.') > 1:
        return 0.0  # 避免多个小数点造成 float 转换失败
    cleaned = f"-{s_clean}" if negative else s_clean
    try:
        value = float(cleaned)
    except ValueError:
        return 0.0
    if precision is not None:
        int_part, _, dec_part = cleaned.partition('.')
        dec_part = dec_part[:precision]
        cleaned = f"{int_part}.{dec_part}" if dec_part else int_part
        try:
            value = float(cleaned)
        except ValueError:
            return 0.0
    return value


# 转化成字符串
def to_str(param: Any = None) -> str:
    return json.dumps(param, ensure_ascii=False) if is_json_serializable(param) else str(param)


def match_str(pattern: str,
              str_a: str = '') -> str | None:
    """
    匹配字符串
    可以参考 正则表达式的操作, 可以使用 chatgpt 帮忙写出这段代码
    @see https://www.runoob.com/python3/python3-reg-expressions.html
    # 示例用法
    # 输出：t_admin
    print(match_str(r'create TABLE (\\w+)', 'CREATE TABLE t_admin (id bigint(20) NOT NULL'))
    这里的 斜杠w 去掉一个斜杠
    """
    match = re.search(pattern, str_a, re.I)
    if match:
        return match.group(1)
    else:
        return None


def format_sorted_kv_string(data_obj: Any,
                            sep: str = '&',
                            join: str = '=',
                            join_list: str = ',') -> str:
    """
    将 dict/json-like 对象按 key 排序后格式化为字符串。
    格式为 key1=value1&key2=value2，支持嵌套结构和列表拼接。

    :param data_obj: 任意结构的数据，如 dict、list、基础类型
    :param sep: 键值对之间的分隔符，默认 '&'
    :param join: key 与 value 的连接符，默认 '='
    :param join_list: 列表等多值类型的连接符，默认 ','
    :return: 格式化后的字符串
    """
    if isinstance(data_obj, (list, tuple, set)):
        return join_list.join(map(str, data_obj))

    if not isinstance(data_obj, dict):
        return str(data_obj)

    # 对 dict 按 key 排序
    sorted_items = sorted(data_obj.items(), key=lambda x: x[0])
    result = []

    for key, value in sorted_items:
        if is_json_serializable(value):
            value_str = format_sorted_kv_string(value, sep=sep, join=join, join_list=join_list)
        else:
            value_str = str(value)
        result.append(f"{key}{join}{value_str}")

    return sep.join(result)


# 执行命令
def exec_command(command: str = None) -> None:
    if command is None:
        return
    try:
        subprocess.run(command, shell=True, check=True)
    except subprocess.CalledProcessError as e:
        print(f"command executed error: {e}")


# 是否是 windows 系统
def is_win() -> bool:
    return platform.system().lower() == 'windows'


# 是否是 linux 系统, 不是 windows , 就是 linux 系统
def is_linux() -> bool:
    return not is_win()
