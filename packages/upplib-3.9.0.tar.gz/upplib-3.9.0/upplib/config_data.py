from upplib import *
from upplib.file_function import *

# 建议将这些库中需要的函数显式导入，或者保持原样
# from upplib.file_function import to_json_from_file, to_str

__CONFIG_DIR = '.upp.config'
__CONFIG_DIR_BAK = '_upp.config'


def __get_full_path(root_path: Optional[str], dir_name: str, file_name: str) -> str:
    """内部辅助函数：构建完整的 JSON 文件路径"""
    base = root_path if root_path else ""
    return os.path.join(base, dir_name, f"{file_name}.json")


# --- 核心接口 ---

def set_config_data(file_name: str = 'config', param: dict = None) -> None:
    """默认在用户家目录下保存配置"""
    set_data_in_user_home(file_name, param)


def get_config_data(file_name: str = 'config') -> dict[str, Any]:
    """
    获取配置：优先从用户家目录读取，如果不存在则从当前工作目录读取
    """
    data = get_data_from_user_home(file_name)
    if not data:
        data = get_data_from_path(file_name)
    return data or {}


# --- 指定位置的操作 ---

def get_data_from_user_home(file_name: str = 'config') -> dict[str, Any]:
    """从当前用户的主目录中获取数据"""
    return get_data_from_path(file_name, os.path.expanduser("~"))


def set_data_in_user_home(file_name: str = 'config', param: dict = None) -> None:
    """在当前用户的主目录中存储数据"""
    set_data_in_path(file_name, param, os.path.expanduser("~"))


def get_data_from_path(file_name: str = 'config', file_dir: str = None) -> dict[str, Any]:
    """在指定目录中尝试从主路径或备用路径读取配置"""
    # 尝试主目录 .upp.config
    data = _read_json_detail(file_name, file_dir, __CONFIG_DIR)
    if not data:
        # 尝试备份目录 _upp.config
        data = _read_json_detail(file_name, file_dir, __CONFIG_DIR_BAK)
    return data or {}


def _read_json_detail(file_name: str, root_path: Optional[str], dir_name: str) -> dict:
    """底层的读取逻辑"""
    full_path = __get_full_path(root_path, dir_name, file_name)

    if not os.path.exists(full_path):
        return {}

    try:
        # 假设 to_json_from_file 是你 upplib 里的函数
        return to_json_from_file(full_path)
    except Exception as e:
        print(f"Error reading config at {full_path}: {e}")
        return {}


def set_data_in_path(file_name: str = 'config', param: dict = None, file_dir: str = '') -> None:
    """在指定路径下持久化数据"""
    target_dir = os.path.join(file_dir, __CONFIG_DIR)

    # 确保目录存在 (exist_ok=True 防止目录已存在时报错)
    os.makedirs(target_dir, exist_ok=True)

    full_path = os.path.join(target_dir, f"{file_name}.json")
    data = param if param is not None else {}

    try:
        # 使用 with 语句更安全地处理文件
        with open(full_path, 'w', encoding='utf-8') as f:
            # 如果 to_str 是将字典转 JSON 字符串，可以直接写
            # f.write(to_str(data))
            # 推荐直接使用 json 标准库以增强可维护性
            json.dump(data, f, ensure_ascii=False, indent=4)
    except Exception as e:
        print(f"Error saving config to {full_path}: {e}")
