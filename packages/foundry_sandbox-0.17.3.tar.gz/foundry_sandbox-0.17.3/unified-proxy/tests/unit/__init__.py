"""Unit tests for unified proxy addons."""
