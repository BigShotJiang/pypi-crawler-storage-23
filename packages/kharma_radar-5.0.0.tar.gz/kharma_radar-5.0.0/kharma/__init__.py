"""
Kharma - The Over-Watch Network Monitor
"""
__version__ = "5.0.0"
