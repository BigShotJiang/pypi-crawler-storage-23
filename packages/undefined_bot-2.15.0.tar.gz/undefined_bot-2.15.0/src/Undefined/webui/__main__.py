"""Allow running WebUI via `python -m Undefined.webui`."""

from __future__ import annotations

from Undefined.webui import run


if __name__ == "__main__":
    run()
