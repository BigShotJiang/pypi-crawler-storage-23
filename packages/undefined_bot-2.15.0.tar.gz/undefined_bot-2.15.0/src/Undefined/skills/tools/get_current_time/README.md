# get_current_time 工具

用于获取当前系统时间。

参数：无

目录结构：
- `config.json`：工具定义
- `handler.py`：执行逻辑
