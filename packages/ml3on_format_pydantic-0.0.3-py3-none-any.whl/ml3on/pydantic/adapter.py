"""ML3Seq Type Adapter for Pydantic models."""

from typing import Any, Generic, Optional, Type, TypeVar

from ml3on.core import (
    ML3Seq,
    ML3SeqFormatConfig,
    ML3SeqItem,
    ML3SeqMultilineString,
)

from pydantic import BaseModel  # type: ignore[attr-defined]
from pydantic import TypeAdapter as PydanticTypeAdapter  # type: ignore[attr-defined]

T = TypeVar("T", bound=BaseModel)


class ML3SeqTypeAdapter(Generic[T]):
    """Type adapter for serializing/deserializing Pydantic models to/from ML3Seq format.

    This adapter handles the conversion between Pydantic models and ML3Seq format,
    with special handling for ML3SeqMultilineString fields.
    """

    model_type: Type[T]
    pydantic_adapter: PydanticTypeAdapter[T]

    def __init__(
        self, model_type: Type[T], config: Optional[ML3SeqFormatConfig] = None
    ) -> None:
        """Initialize adapter for a Pydantic model type.

        Args:
            model_type: Pydantic model class to adapt
            config: Optional ML3Seq format configuration
        """
        self.model_type = model_type
        self.config = config or ML3SeqFormatConfig()
        self.pydantic_adapter = PydanticTypeAdapter(model_type)

    def to_ml3seq(self, data: T) -> str:
        """Convert Pydantic model to ML3Seq format string.

        Args:
            data: Pydantic model instance to serialize

        Returns:
            ML3Seq format string representation
        """
        # Convert to dict
        model_dict = self.pydantic_adapter.dump_python(data)

        # Convert to ML3SeqItem - the model's validators should have already
        # handled ML3SeqMultilineString coercion
        item = self._convert_to_ml3seq_item(model_dict)

        # Create sequence and serialize (ML3Sequence takes *items as positional args)
        sequence = ML3Seq(item, config=self.config)
        return sequence.as_ml3seq  # type: ignore[no-any-return]

    def from_ml3seq(self, ml3seq_str: str) -> T:
        """Parse ML3Seq format string to Pydantic model.

        Args:
            ml3seq_str: ML3Seq format string to parse

        Returns:
            Pydantic model instance

        Raises:
            ValueError: If ML3Seq format is invalid or type doesn't match
        """
        # Parse ML3Seq
        sequence = ML3Seq.from_ml3seq(ml3seq_str)

        if not sequence.items:
            raise ValueError("No items found in ML3Seq")

        item = sequence.items[0]

        # Verify type matches
        expected_kind = self.model_type.__name__
        if item.kind != expected_kind:
            raise ValueError(
                f"ML3Seq item kind '{item.kind}' doesn't match expected '{expected_kind}'"
            )

        # Convert ML3SeqItem to model
        model_dict = self._convert_from_ml3seq_item(item)

        # Validate and create model
        return self.model_type.model_validate(model_dict)  # type: ignore[no-any-return]

    def _convert_to_ml3seq_item(self, model_dict: dict[str, Any]) -> ML3SeqItem:
        """Convert model dict to ML3SeqItem with proper field handling.

        Note: This method assumes that the Pydantic model's validators have already
        handled any ML3SeqMultilineString coercion. We just pass through the values.
        """
        return ML3SeqItem(self.model_type.__name__, **model_dict)

    def _convert_from_ml3seq_item(self, item: ML3SeqItem) -> dict[str, Any]:
        """Convert ML3SeqItem back to model dict."""
        result: dict[str, Any] = {}
        for key, value in item.kv_pairs:
            if isinstance(value, ML3SeqMultilineString):
                # Convert back to regular string for Pydantic
                result[key] = str(value)
            else:
                result[key] = value
        return result
