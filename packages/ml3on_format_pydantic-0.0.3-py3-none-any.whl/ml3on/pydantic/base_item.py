"""ML3Seq BaseModel integration for Pydantic."""

from abc import ABC, abstractmethod
from enum import StrEnum
from functools import cached_property
from typing import TYPE_CHECKING, Any, Generic, Optional, TypeVar

from ml3macro.pydantic.base_model import ML3MacroBaseModel
from ml3macro.utils.optional import obj_get_or_else
from ml3macro.utils.reference import fully_qualified_name
from ml3on.core import (
    ML3Seq,
    ML3SeqFormatConfig,
    ML3SeqFormatConfigProtocol,
    ML3SeqItem,
    ML3SeqMultilineString,
)

if TYPE_CHECKING:
    pass

KindType = TypeVar("KindType", bound=StrEnum)


class ML3SeqItemBaseModel(ML3MacroBaseModel, Generic[KindType], ABC):
    """BaseModel with ML3Seq serialization/deserialization support.

    This class provides automatic handling of ML3SeqMultilineString fields by
    checking type annotations during serialization to ensure proper format.
    """

    @property
    @abstractmethod
    def _ml3seq_kind(self) -> str:
        """kind used by ML3Seq format to deserialize in items in sequence"""

    def to_ml3seq(
        self,
        # todo: add unit-tests with non-None value provided
        config: Optional[ML3SeqFormatConfigProtocol] = None,
    ) -> str:
        """Convert model instance to ML3Seq format string.

        Returns:
            ML3Seq format string representation
        """
        # Get model dict
        model_dict = self.model_dump()

        # Convert to ML3SeqItem with proper field type handling
        item = self._convert_to_ml3seq_item(model_dict)

        # Create sequence and serialize
        sequence = ML3Seq(item, config=config)
        return sequence.as_ml3seq  # type: ignore[no-any-return]

    @cached_property
    # private method to prevent cached property value from being mutated
    def __as_ml3seq_item(self) -> ML3SeqItem:
        return self._convert_to_ml3seq_item(self.model_dump())

    @property
    def as_ml3seq_item(self) -> ML3SeqItem:
        return self.__as_ml3seq_item

    def _convert_to_ml3seq_item(self, model_dict: dict[str, Any]) -> ML3SeqItem:
        """Convert model dict to ML3SeqItem with proper field handling.

        This method checks field type annotations to determine which fields
        should be serialized as ML3SeqMultilineString, regardless of their
        actual runtime type.
        """
        from ml3on.pydantic.base_sequence import ML3SeqBaseModel

        # Use Pydantic's model_fields to get proper field information
        # This includes annotations from the actual model class
        model_fields = self.__class__.model_fields

        # Create a processed dictionary that respects ML3SeqMultilineString annotations
        processed_dict: dict[str, Any] = {}

        for field_name, value in model_dict.items():
            # Get field info from Pydantic's field registry
            if field_name in model_fields:
                field_info = model_fields[field_name]
                field_annotation = field_info.annotation

                print(f"field_name: {field_name}")
                print(f"- value [{fully_qualified_name(type(value))}]: {value}")
                print(
                    f"- field_info [{fully_qualified_name(type(field_info))}]: {field_info}"
                )
                print(
                    f"- field_annotation [{fully_qualified_name(type(field_annotation))}]: {field_annotation}"
                )

                # Handle Optional[ML3SeqMultilineString] and Union types
                if hasattr(field_annotation, "__origin__"):
                    args = getattr(field_annotation, "__args__", ())
                    if args and args[0] is ML3SeqMultilineString:
                        # This field should be treated as ML3SeqMultilineString
                        if value is not None:
                            processed_dict[field_name] = ML3SeqMultilineString(value)
                        else:
                            processed_dict[field_name] = None
                        continue

                # Direct ML3SeqMultilineString annotation
                if field_annotation is ML3SeqMultilineString:
                    if value is not None:
                        processed_dict[field_name] = ML3SeqMultilineString(value)
                    else:
                        processed_dict[field_name] = None
                    continue

                if isinstance(field_annotation, type) and issubclass(
                    field_annotation, ML3SeqBaseModel
                ):
                    processed_dict[field_name] = obj_get_or_else(
                        obj=value,
                        get_value=lambda val: ML3SeqMultilineString(
                            "\n".join(
                                [
                                    f"  {line}"
                                    for line in (
                                        val.to_ml3seq
                                        if isinstance(val, ML3SeqBaseModel)
                                        else field_annotation.model_validate(  # type: ignore[attr-defined]
                                            val
                                        ).to_ml3seq
                                        if isinstance(val, dict)
                                        else str(val)
                                    ).splitlines()
                                ]
                            )
                        ),
                        default=None,
                    )
                    continue

            # No special handling needed
            processed_dict[field_name] = value

        return ML3SeqItem(self._ml3seq_kind, **processed_dict)

    @classmethod
    def from_ml3seq_item(cls, item: ML3SeqItem, /) -> dict[str, Any]:
        """Convert ML3SeqItem back to model dict."""
        result: dict[str, Any] = {}
        for key, value in item.kv_pairs:
            if isinstance(value, ML3SeqMultilineString):
                # Preserve ML3SeqMultilineString type for Pydantic validation
                result[key] = value
            else:
                result[key] = value
        return result

    def _get_ml3seq_config(self) -> ML3SeqFormatConfig:
        """Get ML3Seq configuration for this model."""
        # For now, use default config
        # Could be extended to support per-class or per-instance config
        return ML3SeqFormatConfig()
