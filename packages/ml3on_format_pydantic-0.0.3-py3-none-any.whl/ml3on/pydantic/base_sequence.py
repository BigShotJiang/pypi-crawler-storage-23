from abc import ABC, abstractmethod
from functools import cache, cached_property
from typing import Generic, List, Mapping, Optional, Self, Type, TypeVar, final

from frozendict import frozendict
from ml3macro.pydantic.base_model import ML3MacroBaseModel
from ml3macro.utils.reference import fully_qualified_name
from ml3on.core import ML3Seq, ML3SeqFormatConfigProtocol, ML3SeqItem
from ml3on.pydantic.base_item import ML3SeqItemBaseModel

ItemType = TypeVar("ItemType", bound=ML3SeqItemBaseModel)


class ML3SeqBaseModel(ML3MacroBaseModel, Generic[ItemType], ABC):
    config: Optional[ML3SeqFormatConfigProtocol] = None
    items: tuple[ItemType, ...]

    @classmethod
    @abstractmethod
    def _kind_to_class_mapping(cls) -> Mapping[str, Type[ItemType]]:
        """a mapping of all possible kinds to concrete classes."""

    @classmethod
    @cache
    def kind_to_class_mapping(cls) -> frozendict[str, Type[ItemType]]:
        return frozendict(cls._kind_to_class_mapping())

    @classmethod
    @cache
    @final
    def kind_to_class(cls, kind: str, /) -> type[ItemType]:
        mapping = cls.kind_to_class_mapping()
        item_type = mapping.get(kind, None)
        if item_type is None:
            raise ValueError(
                f"Unexpected kind: {kind}. Allowed values: {', '.join(mapping.keys())}"
            )
        return item_type

    @cached_property
    def __as_ml3seq_sequence(self) -> ML3Seq:
        items: List[ML3SeqItem] = [item.as_ml3seq_item for item in self.items]
        mapping = self.kind_to_class_mapping()
        unexpected_items = {
            f"- {item._ml3seq_kind}: {fully_qualified_name(type(item))}"
            for item in self.items
            if item._ml3seq_kind not in mapping
            or not isinstance(item, self.kind_to_class(item._ml3seq_kind))
        }
        if len(unexpected_items) > 0:
            expected_kinds_to_types = {
                f"- {k}: {fully_qualified_name(v)}" for k, v in mapping.items()
            }
            msg = "\n".join(
                ["Items found with unexpected kind/class:"]
                + list(unexpected_items)
                + ["Allowed values of kind/class:"]
                + list(expected_kinds_to_types)
            )
            raise TypeError(msg)
        return ML3Seq(*items, config=self.config)

    @property
    def as_ml3seq_sequence(self) -> ML3Seq:
        return self.__as_ml3seq_sequence

    @cached_property
    def __as_ml3seq_string(self) -> str:
        return self.as_ml3seq_sequence.as_ml3seq  # type: ignore[no-any-return]

    @property
    def to_ml3seq(self) -> str:
        return self.__as_ml3seq_string

    @classmethod
    def from_ml3seq_sequence(cls, sequence: ML3Seq, /) -> Self:
        return cls(
            config=sequence.config,
            items=tuple(
                concrete_cls(**concrete_cls.from_ml3seq_item(item))
                for item in sequence.items
                for concrete_cls in (cls.kind_to_class(item.kind),)
            ),
        )

    @classmethod
    def from_ml3seq(cls, ml3seq_string: str) -> Self:
        return cls.from_ml3seq_sequence(ML3Seq.from_ml3seq(ml3seq_string))
