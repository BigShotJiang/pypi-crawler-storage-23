# CLASP Python tests
