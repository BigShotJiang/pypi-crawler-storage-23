# 🚀 Snapfold

**Snapfold** is a lightweight CLI tool that snapshots your entire project folder into a single structured `.txt` file — including folder tree and source code — making it easy to share, review, or debug projects.

---

## ✨ Features

- 📁 Automatically captures project folder structure
- 📄 Includes source code from common development file types
- 🚫 Ignores unnecessary folders like `venv`, `.git`, `node_modules`
- 🧠 Smart filtering for development-related files
- ⚡ One-command execution
- 🖥️ Works on Windows, macOS, and Linux

---

## 📦 Installation

```bash
pip install snapfold
```

## (If installing locally)

```bash
pip install .
```

## 🚀 Usage

- Navigate to your project folder:

```bash
cd path/to/your/project
```
- Run:

```bash
snapfold
```

- snapfold will generate:

```bash
your_project_name.txt
```
inside the same folder.

## 📁 Example

- If your folder is:

```bash
my_portfolio/
```

Running:

```bash
snapfold
```

Will create:

```bash
my_portfolio.txt
```

## Containing:

- Folder tree

- All relevant source files

- Clean separators

- Structured output

## 📂 Supported File Types

- Snapfold automatically includes:

- .py

- .html

- .css

- .js

- .jsx

- .tsx

- .json

- .md

- .java

- .cpp

- .c

- .xml

- .yaml

- .yml

- .dart

- .txt


## 🚫 Ignored Folders

- venv

- __pycache__

- .git

- node_modules

## 🛠️ Built With

- Python 3.8+

- Modern pyproject.toml packaging

- CLI entry points

## 🎯 Why Snapfold?

Snapfold is useful for:

- Sharing projects with mentors or recruiters

- Submitting internship assignments

- Asking debugging questions

- Creating project documentation

- Archiving development snapshots

## 📜 License

MIT License

## 👨‍💻 Author

Developed by Nandakrishnan O
Computer Science Engineer 

## ⭐ Future Improvements

- PDF export support

- Custom ignore configuration

- CLI options (--pdf, --include, --exclude)

- Syntax highlighting support

- Markdown export

## If you find this tool helpful, consider giving it a ⭐ on GitHub!