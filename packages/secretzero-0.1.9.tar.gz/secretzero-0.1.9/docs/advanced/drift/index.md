# Drift Detection

Drift detection identifies secrets that were changed outside of SecretZero.

## Related

- [Detection Strategies](strategies.md)
- [Remediation](remediation.md)
- [CLI Drift](../../user-guide/cli/drift.md)
