# Monitoring

Monitor SecretZero operations using drift checks, audit logs, and provider
metrics.

## Recommended Signals

- Drift detection results
- Rotation failures
- Provider authentication errors
