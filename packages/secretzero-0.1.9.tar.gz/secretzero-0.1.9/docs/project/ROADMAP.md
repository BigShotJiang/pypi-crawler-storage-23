# Roadmap

This is a high-level roadmap for SecretZero.

## Near Term

- Improve documentation coverage
- Expand provider test suites
- Add more examples for CI/CD platforms

## Longer Term

- Web UI for managing secret configurations
- Extended policy and compliance support
- Enhanced multi-environment workflows
