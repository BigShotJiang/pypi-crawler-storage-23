# Code Style

## Guidelines

- Use type hints for all functions
- Prefer small, focused functions
- Keep line length to 100 characters
- Avoid logging secret values

## Tools

- `ruff` for linting
- `black` for formatting
- `mypy` for type checking
