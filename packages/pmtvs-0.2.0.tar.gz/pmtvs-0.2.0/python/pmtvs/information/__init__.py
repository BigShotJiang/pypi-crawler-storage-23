"""Information-theoretic primitives."""
