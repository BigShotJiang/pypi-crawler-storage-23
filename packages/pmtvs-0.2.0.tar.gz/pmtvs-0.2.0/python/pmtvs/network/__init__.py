"""Network primitives."""
