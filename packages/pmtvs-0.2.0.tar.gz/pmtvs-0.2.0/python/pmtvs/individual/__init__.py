"""Individual signal primitives."""
