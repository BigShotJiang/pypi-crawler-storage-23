"""Statistical test primitives."""
