pub mod hurst;
pub mod entropy;
