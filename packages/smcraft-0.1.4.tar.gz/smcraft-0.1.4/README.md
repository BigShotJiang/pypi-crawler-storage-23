# smcraft Python Package

This package contains the Python implementation of the State Machine Craft framework.

## Installation

```bash
pip install smcraft
```

## Usage

Refer to the main project README for examples and documentation.
