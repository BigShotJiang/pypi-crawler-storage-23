# Groups tags

## How it works

Watch has a list() of tag UUID's, which relate to a config under application.settings.tags

The 'tag' is actually a watch, because they basically will eventually share 90% of the same config.

So a tag is like an abstract of a watch
