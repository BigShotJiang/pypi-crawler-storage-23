"""AWS Cost Optimizer - Automated cost reduction recommendations"""

__version__ = "0.1.3"
__author__ = "Jonathan Schimpf"
__email__ = "jon@theatrico.org"
