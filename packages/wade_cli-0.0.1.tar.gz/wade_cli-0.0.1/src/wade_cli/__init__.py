"""WADE — Workflow for AI-Driven Engineering."""

__version__ = "0.0.1"
