# wade-cli

This package reserves the `wade-cli` name on PyPI for the [WADE](https://github.com/ivanviragine/wade) project.

**WADE** (Workflow for AI-Driven Engineering) is a Python CLI toolkit for AI-agent-driven git workflow management.

For the actual tool, visit: https://github.com/ivanviragine/wade
