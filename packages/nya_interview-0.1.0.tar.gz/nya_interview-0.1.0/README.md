# nya-interview

Create cli-based interviews easily

See `__main__.py` (run `python -m nya_interview` to see it working) for a source code example.
