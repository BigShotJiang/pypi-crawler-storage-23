"""
pqc-py — Post-quantum cryptography for Python via Rust

FIPS 203/204/205 implementations (Kyber, Dilithium, SPHINCS+)
with classical crypto primitives (AES-GCM, HKDF, HMAC).

All secret key material is automatically zeroed on drop.

Quick start:
    import pqc_py

    # Post-quantum key exchange (Kyber / ML-KEM)
    pk, sk = pqc_py.kyber_keygen("level3")
    ciphertext, shared1 = pqc_py.kyber_encapsulate(pk)
    shared2 = pqc_py.kyber_decapsulate(ciphertext, sk)
    assert shared1 == shared2

    # Post-quantum signatures (Dilithium / ML-DSA)
    pk, sk = pqc_py.dilithium_keygen("level3")
    sig = pqc_py.dilithium_sign(sk, b"message")
    assert pqc_py.dilithium_verify(pk, b"message", sig)
"""

from .pqc_py import (
    # Version
    VERSION,

    # Key Derivation
    derive_key,

    # HMAC
    hmac_sha256,
    verify_hmac,

    # AES-GCM
    encrypt_aes_gcm,
    decrypt_aes_gcm,
    encrypt_aes_gcm_auto,
    decrypt_aes_gcm_auto,

    # Hashing
    py_sha256 as sha256,
    py_sha256_hex as sha256_hex,

    # Random
    random_bytes,
    random_key,
    random_nonce,

    # Kyber (ML-KEM) - FIPS 203
    kyber_keygen,
    kyber_encapsulate,
    kyber_decapsulate,

    # Dilithium (ML-DSA) - FIPS 204
    dilithium_keygen,
    dilithium_sign,
    dilithium_verify,

    # SPHINCS+ (SLH-DSA) - FIPS 205
    sphincs_keygen,
    sphincs_sign,
    sphincs_verify,
)

__all__ = [
    "VERSION",
    "derive_key",
    "hmac_sha256",
    "verify_hmac",
    "encrypt_aes_gcm",
    "decrypt_aes_gcm",
    "encrypt_aes_gcm_auto",
    "decrypt_aes_gcm_auto",
    "sha256",
    "sha256_hex",
    "random_bytes",
    "random_key",
    "random_nonce",
    "kyber_keygen",
    "kyber_encapsulate",
    "kyber_decapsulate",
    "dilithium_keygen",
    "dilithium_sign",
    "dilithium_verify",
    "sphincs_keygen",
    "sphincs_sign",
    "sphincs_verify",
]

__version__ = VERSION
