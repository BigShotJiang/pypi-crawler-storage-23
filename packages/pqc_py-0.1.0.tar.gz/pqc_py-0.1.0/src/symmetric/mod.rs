//! Symmetric encryption primitives
//!
//! This module provides authenticated encryption using AES-256-GCM.

pub mod aes_gcm;
