//! Key management and derivation primitives
//!
//! This module provides:
//! - HKDF-SHA256/SHA512 key derivation
//! - HMAC-SHA256 message authentication
//! - Key manager for cryptographic keys

pub mod hkdf;
pub mod hmac;
pub mod manager;
