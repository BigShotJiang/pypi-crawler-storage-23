//! Post-Quantum Cryptography (PQC) module
//!
//! Implements NIST FIPS 203/204/205 standards:
//! - ML-KEM (Kyber) - FIPS 203 Key Encapsulation
//! - ML-DSA (Dilithium) - FIPS 204 Digital Signatures
//! - SLH-DSA (SPHINCS+) - FIPS 205 Stateless Hash-Based Signatures
//!
//! All algorithms provide quantum-resistant security at 128/192/256-bit levels.

pub mod kyber;
pub mod dilithium;
pub mod sphincs;

/// Security level for PQC algorithms
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum SecurityLevel {
    /// 128-bit security (NIST Level 1)
    Level1,
    /// 192-bit security (NIST Level 3)
    Level3,
    /// 256-bit security (NIST Level 5)
    Level5,
}

impl SecurityLevel {
    /// Get the security bits for this level
    pub fn bits(&self) -> usize {
        match self {
            SecurityLevel::Level1 => 128,
            SecurityLevel::Level3 => 192,
            SecurityLevel::Level5 => 256,
        }
    }
}

impl Default for SecurityLevel {
    fn default() -> Self {
        SecurityLevel::Level3
    }
}
