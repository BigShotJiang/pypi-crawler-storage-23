//! Hash functions and hash chains
//!
//! This module provides SHA-256 hash chains for tamper-evident audit logging.

pub mod chain;
