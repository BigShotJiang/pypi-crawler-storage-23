//! FFI bindings for Python via PyO3
//!
//! This module provides Python bindings for all cryptographic operations.

#[cfg(feature = "python")]
pub mod python;
