"""
spotify_genius

Open Genius lyrics for the currently playing Spotify track.
"""

__version__ = "0.1.0"