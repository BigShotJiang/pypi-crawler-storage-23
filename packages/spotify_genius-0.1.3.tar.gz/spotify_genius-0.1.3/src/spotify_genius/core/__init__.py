from .genius import open_genius

__all__ = [
    "open_genius",
]