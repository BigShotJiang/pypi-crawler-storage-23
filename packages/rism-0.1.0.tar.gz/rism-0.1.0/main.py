def main():
    print("Hello from streamguard!")


if __name__ == "__main__":
    main()
