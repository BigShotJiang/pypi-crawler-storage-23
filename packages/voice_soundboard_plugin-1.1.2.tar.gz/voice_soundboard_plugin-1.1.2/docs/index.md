# Soundboard Plugin

Give Claude Code a voice — a plugin that speaks code walkthroughs, announces build results, and adds context-aware TTS to your dev workflow.

## Key Features

- **12 curated voices** with emotion-aware routing (joy, anger, sadness, fear, surprise, urgency, calm, neutral)
- **Multi-speaker dialogue** with auto-casting and stage directions
- **Smart chunking** splits long text at sentence boundaries with interrupt support
- **SSML-lite** for fine-grained control (pauses, emphasis, pitch, rate)
- **Playback hardening** single-thread worker, 30s watchdog, queue policies
- **Security-first** path sandboxing, concurrency gate, structured errors

## Install / Quick Start

```bash
pip install voice-soundboard-plugin
```

## Links

- [GitHub Repository](https://github.com/mcp-tool-shop-org/soundboard-plugin)
- [voice-soundboard-plugin on PyPI](https://pypi.org/project/voice-soundboard-plugin/)
- [MCP Tool Shop](https://github.com/mcp-tool-shop-org)
