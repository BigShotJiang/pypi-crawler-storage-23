"""Stdio bridge for voice-soundboard MCP integration."""
