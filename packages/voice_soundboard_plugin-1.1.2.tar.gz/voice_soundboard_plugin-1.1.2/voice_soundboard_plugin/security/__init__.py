"""Security subsystem — guardrails, filesystem sandbox, redaction, validation."""
