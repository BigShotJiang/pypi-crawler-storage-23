"""Audio utilities — SFX generation and playback helpers."""
