"""Ambient module — ephemeral inner monologue with rate limiting and redaction."""

from voice_soundboard_plugin.ambient.inner_monologue import (
    AmbientConfig,
    InnerMonologue,
    MonologueEntry,
)

__all__ = [
    "AmbientConfig",
    "InnerMonologue",
    "MonologueEntry",
]
