# soundboard-plugin

## What This Plugin Does

This plugin gives Claude Code a voice. It wraps the voice-soundboard TTS engine
and provides spoken output for code walkthroughs, workflow notifications, and
general text-to-speech.

## MCP Tools Available

When the voice engine is running, these MCP tools are available:

| Tool | Purpose |
|------|---------|
| `voice.speak` | Synthesise speech from text |
| `voice.stream` | Stream speech for low-latency playback |
| `voice.interrupt` | Stop active audio |
| `voice.list_voices` | List available voices and presets |
| `voice.status` | Check engine health and capabilities |
| `voice.narrate` | Code-aware narration with adaptive pacing |
| `voice.workflow_notify` | Speak workflow event notifications |

## Context-Aware Voice (Automatic)

When using voice.speak, select emotion based on context:

| Context | Emotion | Voice |
|---------|---------|-------|
| Explaining code | neutral | bm_george (narrator) |
| Warning about errors | anger or sadness | bm_george (narrator) |
| Celebrating success | joy | am_michael (announcer) |
| General conversation | neutral | af_bella (assistant) |

## Presets

| Preset | Voice | Speed | Use For |
|--------|-------|-------|---------|
| assistant | af_bella | 1.0x | General speech |
| narrator | bm_george | 0.95x | Code walkthroughs, explanations |
| announcer | am_michael | 1.1x | Notifications, announcements |
| storyteller | bf_emma | 0.9x | Long-form narration |
| whisper | af_nicole | 0.85x | Quiet, subtle speech |

## Graceful Degradation

If the voice engine is not available, all tools return descriptive error messages
instead of crashing. The plugin remains loaded but voice features are inactive.
Check status with `/soundboard:voice-status`.

## Dependencies

- voice-soundboard >= 2.5.0 (F:\AI\voice-soundboard)
- Python >= 3.10
- mcp >= 1.0.0
