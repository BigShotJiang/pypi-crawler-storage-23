"""
Canopy: Institutional-Grade Hierarchical Portfolio Optimization
Copyright © 2026 Anagatam Technologies. All rights reserved.

https://github.com/Anagatam/Canopy
"""

from setuptools import setup, find_packages

setup(
    name="canopy-optimizer",
    version="2.3.0",
    description="Institutional-grade hierarchical portfolio optimization (HRP, HERC, NCO)",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    author="Anagatam Technologies",
    author_email="canopy@anagatam.com",
    url="https://github.com/Anagatam/Canopy",
    project_urls={
        "Documentation": "https://canopy-institutional-portfolio-optimization.readthedocs.io/en/latest/",
        "Source": "https://github.com/Anagatam/Canopy",
        "Issues": "https://github.com/Anagatam/Canopy/issues",
    },
    packages=find_packages(),
    python_requires=">=3.10",
    install_requires=[
        "numpy>=1.24",
        "pandas>=2.0",
        "scipy>=1.10",
        "scikit-learn>=1.3",
        "plotly>=5.18",
        "networkx>=2.6",
    ],
    extras_require={
        "dev": [
            "pytest>=7.0",
            "pytest-cov>=4.0",
            "yfinance>=0.2",
            "sphinx>=7.0",
            "sphinx-rtd-theme>=2.0",
            "furo>=2024.1",
            "myst-parser>=2.0",
            "sphinx-copybutton>=0.5",
            "sphinx-design>=0.5",
        ],
    },
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Financial and Insurance Industry",
        "Intended Audience :: Science/Research",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Programming Language :: Python :: 3.13",
        "Topic :: Office/Business :: Financial :: Investment",
        "Topic :: Scientific/Engineering :: Mathematics",
    ],
    keywords=[
        "portfolio-optimization", "hierarchical-risk-parity", "hrp",
        "herc", "nco", "quantitative-finance", "risk-management",
    ],
    license="MIT",
)
