"""
Canopy Metrics — Institutional Portfolio Performance Analytics
══════════════════════════════════════════════════════════════
Copyright © 2026 Anagatam Technologies. All rights reserved.

Provides a comprehensive suite of portfolio performance metrics
used by institutional risk desks, compliance teams, and PMs.

Architecture
────────────
    Each metric is a standalone function AND available as a method
    on the PortfolioMetrics class for convenience.

    Math is separated from logic: pure mathematical functions at the
    top of the file, orchestration class at the bottom.

References
──────────
    [1] Sharpe, W. (1966). "Mutual Fund Performance."
    [2] Sortino, F. & Price, L. (1994). "Performance Measurement in a Downside Risk Framework."
    [3] Rockafellar, R. & Uryasev, S. (2000). "Optimization of Conditional Value-at-Risk."

Usage
─────
    >>> from canopy.metrics import PortfolioMetrics
    >>>
    >>> pm = PortfolioMetrics(returns, weights, benchmark=bench)
    >>> print(pm.sharpe())           # Annualized Sharpe Ratio
    >>> print(pm.sortino())          # Sortino Ratio
    >>> print(pm.maxdrawdown())      # Maximum Drawdown
    >>> print(pm.report())           # Full summary table
"""

import numpy as np
import pandas as pd
from typing import Optional


# ═══════════════════════════════════════════════════════════════════════════
# PURE MATHEMATICS — Stateless functions, no side effects
# ═══════════════════════════════════════════════════════════════════════════

def sharpe(returns: pd.Series, rf: float = 0.0, periods: int = 252) -> float:
    """
    Annualized Sharpe Ratio.

    SR = (μ - rf) / σ × √T

    Args:
        returns: Portfolio return series.
        rf: Daily risk-free rate (default: 0).
        periods: Trading days per year (default: 252).

    Returns:
        Annualized Sharpe Ratio (float).
    """
    excess = returns - rf
    if excess.std() == 0:
        return 0.0
    return float(excess.mean() / excess.std() * np.sqrt(periods))


def sortino(returns: pd.Series, rf: float = 0.0, periods: int = 252) -> float:
    """
    Annualized Sortino Ratio — penalizes only downside volatility.

    Sortino = (μ - rf) / σ_down × √T

    where σ_down = std(min(r - rf, 0))
    """
    excess = returns - rf
    downside = excess[excess < 0]
    if len(downside) == 0 or downside.std() == 0:
        return 0.0
    return float(excess.mean() / downside.std() * np.sqrt(periods))


def calmar(returns: pd.Series, periods: int = 252) -> float:
    """
    Calmar Ratio — annualized return / max drawdown.

    Calmar = μ_annual / |MaxDD|
    """
    mdd = maxdrawdown(returns)
    if mdd == 0:
        return 0.0
    annual = returns.mean() * periods
    return float(annual / abs(mdd))


def maxdrawdown(returns: pd.Series) -> float:
    """
    Maximum Drawdown — largest peak-to-trough decline.

    MaxDD = min_t [ NAV(t) / max_{s≤t} NAV(s) - 1 ]
    """
    cumulative = (1 + returns).cumprod()
    running_max = cumulative.cummax()
    drawdown = cumulative / running_max - 1
    return float(drawdown.min())


def cvar(returns: pd.Series, alpha: float = 0.05) -> float:
    """
    Conditional Value-at-Risk (Expected Shortfall) at confidence level α.

    CVaR_α = E[R | R ≤ VaR_α]

    Args:
        returns: Portfolio return series.
        alpha: Tail probability (default: 5%).

    Returns:
        CVaR as a negative number (loss).
    """
    threshold = np.percentile(returns, alpha * 100)
    tail = returns[returns <= threshold]
    if len(tail) == 0:
        return float(threshold)
    return float(tail.mean())


def volatility(returns: pd.Series, periods: int = 252) -> float:
    """Annualized volatility: σ × √T."""
    return float(returns.std() * np.sqrt(periods))


def annualreturn(returns: pd.Series, periods: int = 252) -> float:
    """Compound Annual Growth Rate (CAGR)."""
    total = (1 + returns).prod()
    n_years = len(returns) / periods
    if n_years == 0:
        return 0.0
    return float(total ** (1 / n_years) - 1)


def informationratio(
    returns: pd.Series,
    benchmark: pd.Series,
    periods: int = 252,
) -> float:
    """
    Information Ratio — excess return per unit of tracking error.

    IR = (μ_p - μ_b) / σ(r_p - r_b) × √T
    """
    aligned = pd.concat([returns, benchmark], axis=1).dropna()
    if aligned.shape[0] < 2:
        return 0.0
    active = aligned.iloc[:, 0] - aligned.iloc[:, 1]
    if active.std() == 0:
        return 0.0
    return float(active.mean() / active.std() * np.sqrt(periods))


# ═══════════════════════════════════════════════════════════════════════════
# ORCHESTRATION — PortfolioMetrics class
# ═══════════════════════════════════════════════════════════════════════════

class PortfolioMetrics:
    """
    Comprehensive portfolio performance analytics.

    Computes portfolio return series from asset returns + weights,
    then provides all standard institutional metrics.

    Args:
        returns: Asset returns DataFrame (T × N).
        weights: Portfolio weights (pd.Series or dict).
        benchmark: Optional benchmark return series.
        rf: Daily risk-free rate (default: 0).

    Example:
        >>> pm = PortfolioMetrics(returns, weights, benchmark=nifty)
        >>> print(pm.sharpe())
        >>> print(pm.report())
    """

    def __init__(
        self,
        returns: pd.DataFrame,
        weights: pd.Series,
        benchmark: Optional[pd.Series] = None,
        rf: float = 0.0,
    ):
        self.weights = weights
        self.rf = rf

        # Compute portfolio return series
        self.portfolio = (returns * weights).sum(axis=1)
        self.portfolio.name = 'Portfolio'

        # Align benchmark if provided
        self.benchmark = benchmark

    def sharpe(self) -> float:
        """Annualized Sharpe Ratio."""
        return sharpe(self.portfolio, rf=self.rf)

    def sortino(self) -> float:
        """Annualized Sortino Ratio."""
        return sortino(self.portfolio, rf=self.rf)

    def calmar(self) -> float:
        """Calmar Ratio."""
        return calmar(self.portfolio)

    def maxdrawdown(self) -> float:
        """Maximum Drawdown."""
        return maxdrawdown(self.portfolio)

    def cvar(self, alpha: float = 0.05) -> float:
        """CVaR at α confidence."""
        return cvar(self.portfolio, alpha=alpha)

    def volatility(self) -> float:
        """Annualized Volatility."""
        return volatility(self.portfolio)

    def annualreturn(self) -> float:
        """Compound Annual Growth Rate."""
        return annualreturn(self.portfolio)

    def informationratio(self) -> float:
        """Information Ratio vs benchmark."""
        if self.benchmark is None:
            raise ValueError("No benchmark provided. Pass benchmark= to constructor.")
        return informationratio(self.portfolio, self.benchmark)

    def report(self) -> str:
        """
        Generate a full performance report as a formatted string.

        Returns:
            Multi-line string with all key metrics.
        """
        lines = [
            "╔══════════════════════════════════════════════════╗",
            "║         Canopy — Portfolio Performance Report    ║",
            "╚══════════════════════════════════════════════════╝",
            "",
            f"  Annual Return     : {self.annualreturn():>10.2%}",
            f"  Volatility        : {self.volatility():>10.2%}",
            f"  Sharpe Ratio      : {self.sharpe():>10.3f}",
            f"  Sortino Ratio     : {self.sortino():>10.3f}",
            f"  Calmar Ratio      : {self.calmar():>10.3f}",
            f"  Max Drawdown      : {self.maxdrawdown():>10.2%}",
            f"  CVaR (5%)         : {self.cvar():>10.4f}",
        ]

        if self.benchmark is not None:
            lines.append(f"  Information Ratio : {self.informationratio():>10.3f}")

        lines.append("")
        lines.append(f"  Assets            : {len(self.weights)}")
        lines.append(f"  Observations      : {len(self.portfolio)}")
        lines.append("")

        return "\n".join(lines)
