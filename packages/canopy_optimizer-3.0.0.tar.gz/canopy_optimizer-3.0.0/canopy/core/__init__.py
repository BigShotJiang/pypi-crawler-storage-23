"""
Canopy Core — Mathematical Kernel
Copyright © 2026 Anagatam Technologies. All rights reserved.

This package contains the mathematical foundations:
    - CovarianceEngine: Ledoit-Wolf shrinkage, MP denoising, EWMA
    - ClusterEngine: Distance transforms, linkage, seriation, cluster variance
"""
from canopy.core.ClusterEngine import correl_dist, compute_linkage, get_quasi_diag, get_cluster_var
from canopy.core.CovarianceEngine import ledoit_wolf_shrinkage, denoise_covariance, ewma_covariance
