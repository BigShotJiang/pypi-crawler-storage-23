"""Minimal headless agent that executes skill.md files via Chat Completion API."""

__version__ = "0.1.3"
