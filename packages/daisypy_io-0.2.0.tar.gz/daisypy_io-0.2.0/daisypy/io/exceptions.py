'''Exceptions for daisypy.io'''

class DaiException(Exception):
    '''Exception class for Dai related errors'''
