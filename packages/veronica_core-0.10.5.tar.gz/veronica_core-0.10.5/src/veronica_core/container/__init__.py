"""VERONICA Container - Composite AI safety container."""

from veronica_core.container.aicontainer import AIcontainer

__all__ = ["AIcontainer"]
