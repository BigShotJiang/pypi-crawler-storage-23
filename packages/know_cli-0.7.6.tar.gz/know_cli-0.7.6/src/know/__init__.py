"""know - Living documentation generator for codebases."""

__version__ = "0.7.6"
__author__ = "Sushil Kumar"

from know.cli import main

__all__ = ["main", "__version__"]
