__version__ = "74.20260219.post1"
GIT_REF = "40b9e21"
URL = "https://github.com/micro-manager/mmCoreAndDevices/tree/40b9e21"