"""
Lamia LLM Adapters

This submodule contains specific adapters for various Language Model providers.
Each adapter implements a common interface while handling the specific
requirements and peculiarities of different LLM APIs.

Available adapters will include:
- OpenAI (GPT models)
- Anthropic (Claude models)
- And more...
"""

__version__ = "0.1.0"
