"""
Lamia Adapters Module

This module provides adapter implementations for various services and APIs,
with a focus on Language Model providers (OpenAI, Anthropic, etc.).
The adapter pattern ensures a consistent interface while allowing for
different backend implementations.
"""

__version__ = "0.1.0"
