"""
CLI module for Lamia.

This module provides command-line interface functionality including
interactive mode, file execution, project scaffolding, and styling.
"""

# Import main from the local cli.py
from .cli import main

__all__ = ['main']