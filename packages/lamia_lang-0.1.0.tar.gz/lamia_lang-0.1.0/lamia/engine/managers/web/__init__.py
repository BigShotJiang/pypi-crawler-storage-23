"""Web management components."""

from .web_manager import WebManager

__all__ = ['WebManager']