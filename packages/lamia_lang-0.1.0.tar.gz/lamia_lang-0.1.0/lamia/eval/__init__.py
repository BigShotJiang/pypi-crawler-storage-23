"""
Lamia Evaluation Module

This module provides model evaluation and optimization capabilities for finding
the most cost-effective model that can successfully complete a given task.
"""