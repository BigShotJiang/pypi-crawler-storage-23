"""
Facade layer for Lamia - simplified interface to complex subsystems.

This module provides the main Lamia class and supporting utilities that
implement the facade pattern to provide a clean, simple interface to
the underlying engine, adapters, and validation systems.
"""