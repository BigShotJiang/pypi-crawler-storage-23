"""
Lamia Interpreter Module

This module contains the core interpretation logic for processing and executing
commands or queries through various LLM providers.
"""

__version__ = "0.1.0"
