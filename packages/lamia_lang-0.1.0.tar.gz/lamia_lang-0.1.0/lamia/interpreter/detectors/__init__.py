"""Detectors for hybrid syntax parsing."""

from .llm_command_detector import LLMCommandDetector

__all__ = ['LLMCommandDetector']
