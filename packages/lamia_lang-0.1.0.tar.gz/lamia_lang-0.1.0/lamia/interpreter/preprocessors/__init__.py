"""Preprocessors for hybrid syntax parsing."""

from .return_type_preprocessor import WithReturnTypePreprocessor

__all__ = ['WithReturnTypePreprocessor']
