"""Shield facade — decorator-based guardrails for functions and coroutines.

Usage::

    from highflame.shield import Shield, ShieldClient, ShieldBlockedError

    client = ShieldClient(api_key="hf_sk_xxx")
    shield = Shield(client)

    @shield.prompt
    def chat(message: str) -> str:
        return llm.complete(message)

    @shield.tool
    async def run_shell(cmd: str) -> str:
        ...
"""

from __future__ import annotations

import functools
import inspect
from typing import Any, Callable

from .client import ShieldClient
from .exceptions import ShieldBlockedError
from .types import Mode, ShieldRequest, ShieldResponse, ToolContext

# ---------------------------------------------------------------------------
# Private helpers
# ---------------------------------------------------------------------------


def _first_str_param(fn: Callable[..., Any]) -> str:
    """Return the name of the first str-annotated (or unannotated) parameter.

    Handles both evaluated annotations (``str`` class) and stringified
    annotations (``"str"`` from ``from __future__ import annotations``).
    """
    sig = inspect.signature(fn)
    for name, param in sig.parameters.items():
        if param.annotation in (str, "str", inspect.Parameter.empty):
            return name
    raise TypeError(
        f"shield: {fn.__name__} has no str parameter to guard. "
        "Use content_arg= to specify one explicitly."
    )


def _extract_content(
    fn: Callable[..., Any], arg_name: str, args: tuple[Any, ...], kwargs: dict[str, Any]
) -> str:
    """Bind call args and return the named str argument."""
    bound = inspect.signature(fn).bind(*args, **kwargs)
    bound.apply_defaults()
    val = bound.arguments.get(arg_name)
    if not isinstance(val, str):
        raise TypeError(
            f"shield: '{arg_name}' must be str, got {type(val).__name__}"
        )
    return val


def _bind_all_args(
    fn: Callable[..., Any], args: tuple[Any, ...], kwargs: dict[str, Any]
) -> dict[str, Any]:
    """Return all bound arguments as a plain dict (for ToolContext.arguments)."""
    bound = inspect.signature(fn).bind(*args, **kwargs)
    bound.apply_defaults()
    return dict(bound.arguments)


def _raise_if_blocked(response: ShieldResponse) -> None:
    if response.denied:
        raise ShieldBlockedError(response)


# ---------------------------------------------------------------------------
# Shield facade
# ---------------------------------------------------------------------------


class Shield:
    """
    Decorator facade over :class:`ShieldClient`.

    Attach guard checks to functions with a single line::

        shield = Shield(client)

        @shield.prompt           # bare — no options needed
        def chat(msg: str) -> str: ...

        @shield.prompt(mode="monitor", content_arg="user_input")
        def chat(user_input: str, ctx: str) -> str: ...

        @shield.tool             # guard before the tool runs
        def shell(cmd: str) -> str: ...

        @shield.toolresponse     # guard the return value
        def fetch(url: str) -> str: ...

        @shield.modelresponse    # guard LLM output before returning
        def generate(prompt: str) -> str: ...

        @shield(content_type="file", action="write_file", content_arg="content")
        def write(path: str, content: str) -> None: ...

    Async functions are auto-detected and use the async client methods.
    """

    def __init__(self, client: ShieldClient) -> None:
        self._client = client

    # ------------------------------------------------------------------
    # @shield.prompt
    # ------------------------------------------------------------------

    def prompt(
        self,
        fn: Callable[..., Any] | None = None,
        *,
        mode: Mode = "enforce",
        content_arg: str | None = None,
        session_id: str | None = None,
    ) -> Any:
        """Guard a prompt input before the function runs.

        Content type: ``prompt``, action: ``process_prompt``.
        The guarded value is the first ``str`` parameter (or ``content_arg=``).
        """

        def decorator(f: Callable[..., Any]) -> Callable[..., Any]:
            arg_name = content_arg or _first_str_param(f)

            if inspect.iscoroutinefunction(f):
                @functools.wraps(f)
                async def async_wrapper(*args: Any, **kwargs: Any) -> Any:
                    content = _extract_content(f, arg_name, args, kwargs)
                    _raise_if_blocked(
                        await self._client.aguard_prompt(
                            content, mode=mode, session_id=session_id
                        )
                    )
                    return await f(*args, **kwargs)

                return async_wrapper

            @functools.wraps(f)
            def sync_wrapper(*args: Any, **kwargs: Any) -> Any:
                content = _extract_content(f, arg_name, args, kwargs)
                _raise_if_blocked(
                    self._client.guard_prompt(
                        content, mode=mode, session_id=session_id
                    )
                )
                return f(*args, **kwargs)

            return sync_wrapper

        if fn is not None:
            return decorator(fn)
        return decorator

    # ------------------------------------------------------------------
    # @shield.tool
    # ------------------------------------------------------------------

    def tool(
        self,
        fn: Callable[..., Any] | None = None,
        *,
        mode: Mode = "enforce",
        tool_name: str | None = None,
        session_id: str | None = None,
    ) -> Any:
        """Guard a tool call before the function runs.

        Content type: ``tool_call``, action: ``call_tool``.
        All bound arguments are forwarded as ``ToolContext.arguments``.
        """

        def decorator(f: Callable[..., Any]) -> Callable[..., Any]:
            name = tool_name or f.__name__

            if inspect.iscoroutinefunction(f):
                @functools.wraps(f)
                async def async_wrapper(*args: Any, **kwargs: Any) -> Any:
                    bound_args = _bind_all_args(f, args, kwargs)
                    _raise_if_blocked(
                        await self._client.aguard_tool_call(
                            name, arguments=bound_args, mode=mode, session_id=session_id
                        )
                    )
                    return await f(*args, **kwargs)

                return async_wrapper

            @functools.wraps(f)
            def sync_wrapper(*args: Any, **kwargs: Any) -> Any:
                bound_args = _bind_all_args(f, args, kwargs)
                _raise_if_blocked(
                    self._client.guard_tool_call(
                        name, arguments=bound_args, mode=mode, session_id=session_id
                    )
                )
                return f(*args, **kwargs)

            return sync_wrapper

        if fn is not None:
            return decorator(fn)
        return decorator

    # ------------------------------------------------------------------
    # @shield.toolresponse
    # ------------------------------------------------------------------

    def toolresponse(
        self,
        fn: Callable[..., Any] | None = None,
        *,
        mode: Mode = "enforce",
        tool_name: str | None = None,
        session_id: str | None = None,
    ) -> Any:
        """Guard a tool's return value after the function runs.

        Content type: ``response``, action: ``call_tool``.
        The function executes first; its ``str`` return value is guarded.
        """

        def decorator(f: Callable[..., Any]) -> Callable[..., Any]:
            name = tool_name or f.__name__

            if inspect.iscoroutinefunction(f):
                @functools.wraps(f)
                async def async_wrapper(*args: Any, **kwargs: Any) -> Any:
                    result = await f(*args, **kwargs)
                    _raise_if_blocked(
                        await self._client.aguard(
                            ShieldRequest(
                                content=result if isinstance(result, str) else str(result),
                                content_type="response",
                                action="call_tool",
                                mode=mode,
                                session_id=session_id,
                                tool=ToolContext(name=name),
                            )
                        )
                    )
                    return result

                return async_wrapper

            @functools.wraps(f)
            def sync_wrapper(*args: Any, **kwargs: Any) -> Any:
                result = f(*args, **kwargs)
                _raise_if_blocked(
                    self._client.guard(
                        ShieldRequest(
                            content=result if isinstance(result, str) else str(result),
                            content_type="response",
                            action="call_tool",
                            mode=mode,
                            session_id=session_id,
                            tool=ToolContext(name=name),
                        )
                    )
                )
                return result

            return sync_wrapper

        if fn is not None:
            return decorator(fn)
        return decorator

    # ------------------------------------------------------------------
    # @shield.modelresponse
    # ------------------------------------------------------------------

    def modelresponse(
        self,
        fn: Callable[..., Any] | None = None,
        *,
        mode: Mode = "enforce",
        session_id: str | None = None,
    ) -> Any:
        """Guard a model response before returning to the caller.

        Content type: ``response``, action: ``process_prompt``.
        The function executes first; its ``str`` return value is guarded.
        """

        def decorator(f: Callable[..., Any]) -> Callable[..., Any]:
            if inspect.iscoroutinefunction(f):
                @functools.wraps(f)
                async def async_wrapper(*args: Any, **kwargs: Any) -> Any:
                    result = await f(*args, **kwargs)
                    _raise_if_blocked(
                        await self._client.aguard(
                            ShieldRequest(
                                content=result if isinstance(result, str) else str(result),
                                content_type="response",
                                action="process_prompt",
                                mode=mode,
                                session_id=session_id,
                            )
                        )
                    )
                    return result

                return async_wrapper

            @functools.wraps(f)
            def sync_wrapper(*args: Any, **kwargs: Any) -> Any:
                result = f(*args, **kwargs)
                _raise_if_blocked(
                    self._client.guard(
                        ShieldRequest(
                            content=result if isinstance(result, str) else str(result),
                            content_type="response",
                            action="process_prompt",
                            mode=mode,
                            session_id=session_id,
                        )
                    )
                )
                return result

            return sync_wrapper

        if fn is not None:
            return decorator(fn)
        return decorator

    # ------------------------------------------------------------------
    # @shield(content_type=..., action=..., ...)  — generic
    # ------------------------------------------------------------------

    def __call__(
        self,
        fn: None = None,
        *,
        content_type: str,
        action: str,
        content_arg: str | None = None,
        mode: Mode = "enforce",
        session_id: str | None = None,
    ) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
        """Generic decorator: fully configurable content type and action.

        Always requires keyword arguments::

            @shield(content_type="file", action="write_file", content_arg="data")
            def write(path: str, data: str) -> None: ...
        """
        if fn is not None:
            raise TypeError(
                "shield() requires keyword arguments: "
                "@shield(content_type=..., action=...) not @shield"
            )

        def decorator(f: Callable[..., Any]) -> Callable[..., Any]:
            arg_name = content_arg or _first_str_param(f)

            if inspect.iscoroutinefunction(f):
                @functools.wraps(f)
                async def async_wrapper(*args: Any, **kwargs: Any) -> Any:
                    content = _extract_content(f, arg_name, args, kwargs)
                    _raise_if_blocked(
                        await self._client.aguard(
                            ShieldRequest(
                                content=content,
                                content_type=content_type,  # type: ignore[arg-type]
                                action=action,  # type: ignore[arg-type]
                                mode=mode,
                                session_id=session_id,
                            )
                        )
                    )
                    return await f(*args, **kwargs)

                return async_wrapper

            @functools.wraps(f)
            def sync_wrapper(*args: Any, **kwargs: Any) -> Any:
                content = _extract_content(f, arg_name, args, kwargs)
                _raise_if_blocked(
                    self._client.guard(
                        ShieldRequest(
                            content=content,
                            content_type=content_type,  # type: ignore[arg-type]
                            action=action,  # type: ignore[arg-type]
                            mode=mode,
                            session_id=session_id,
                        )
                    )
                )
                return f(*args, **kwargs)

            return sync_wrapper

        return decorator
