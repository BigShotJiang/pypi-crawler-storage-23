"""SSE event model for POST /v1/guard/stream."""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, ConfigDict


class ShieldStreamEvent(BaseModel):
    """A single server-sent event from the streaming guard endpoint."""

    type: str
    """Event type: detection | decision | error | done."""

    data: dict[str, Any] = {}
    """Event payload."""

    model_config = ConfigDict(populate_by_name=True)
