"""Pydantic v2 models mirroring highflame-shield API types."""

from __future__ import annotations

from datetime import datetime
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict


class _Base(BaseModel):
    """Shared config for all Shield models."""

    model_config = ConfigDict(populate_by_name=True)


# ---------------------------------------------------------------------------
# Typed string aliases — usable in annotations and IDE autocomplete
# ---------------------------------------------------------------------------

ContentType = Literal["prompt", "response", "tool_call", "file"]
Action = Literal["process_prompt", "call_tool", "read_file", "write_file", "connect_server"]
Mode = Literal["enforce", "monitor", "alert"]
Product = Literal["guardrails", "overwatch"]


# ---------------------------------------------------------------------------
# Request context models
# ---------------------------------------------------------------------------


class ToolContext(_Base):
    """Tool call context for agentic evaluation."""

    name: str
    arguments: dict[str, Any] | None = None
    server_id: str | None = None
    is_builtin: bool | None = None
    description: str | None = None


class ModelContext(_Base):
    """LLM model context (provider, temperature, token usage)."""

    provider: str | None = None
    model: str | None = None
    temperature: float | None = None
    tokens_used: int | None = None
    max_tokens: int | None = None


class FileContext(_Base):
    """File operation context (path, operation, size)."""

    path: str
    operation: str
    size: int | None = None
    mime_type: str | None = None


class MCPContext(_Base):
    """MCP server interaction context."""

    server_name: str | None = None
    server_url: str | None = None
    transport: str | None = None
    verified: bool | None = None
    capabilities: list[str] | None = None


# ---------------------------------------------------------------------------
# Shield request
# ---------------------------------------------------------------------------


class ShieldRequest(_Base):
    """Request body for POST /v1/guard."""

    content: str
    """Content to evaluate (prompt text, tool call arguments, file content, etc.)."""

    content_type: ContentType
    """Type of content: prompt | response | tool_call | file."""

    action: Action
    """Cedar action: process_prompt | call_tool | read_file | write_file | connect_server."""

    detectors: list[str] | None = None
    """Specific detectors to run. None (absent) runs all enabled detectors."""

    mode: Mode = "enforce"
    """enforce: block on deny. monitor: allow + log. alert: allow + signal pipeline."""

    early_exit: bool | None = None
    """Enable early exit on deny after each tier."""

    explain: bool | None = None
    """Include structured policy explanation."""

    metadata: dict[str, Any] | None = None
    """Caller-provided metadata passed through to detectors."""

    contexts: list[str] | None = None
    """Reference material for context-aware detection (hallucination, groundedness)."""

    product: Product = "guardrails"
    """Product namespace: guardrails | overwatch."""

    session_id: str | None = None
    """Session ID for cross-turn state tracking."""

    tool: ToolContext | None = None
    """Tool call context for agentic evaluation."""

    model: ModelContext | None = None
    """LLM model context."""

    file: FileContext | None = None
    """File operation context."""

    mcp: MCPContext | None = None
    """MCP server interaction context."""


# ---------------------------------------------------------------------------
# Shield response models
# ---------------------------------------------------------------------------


class DeterminingPolicy(_Base):
    """A Cedar policy that contributed to the shield decision."""

    rule_id: str = ""
    policy_id: str = ""
    policy_name: str = ""
    effect: str = ""
    mode: str = ""
    annotations: dict[str, str] = {}


class DetectorResult(_Base):
    """Output of a single detector run."""

    name: str
    tier: str
    latency_ms: int
    context: dict[str, Any] = {}
    status: str
    """healthy | degraded | error | timeout"""
    error: str = ""


class SessionDelta(_Base):
    """Session state changes after evaluation."""

    turn_count: int
    cumulative_risk: float
    tokens_used_delta: int = 0
    new_action: str = ""


class RootCause(_Base):
    """A detector identified as the root cause of a policy block."""

    summary: str
    detector: str
    labels: dict[str, str] = {}
    triggering_context: dict[str, Any] = {}
    evidence: dict[str, Any] = {}
    triggered_policies: list[str] = []


class ShieldResponse(_Base):
    """Response from POST /v1/guard."""

    decision: Literal["allow", "deny"]

    actual_decision: str = ""
    """Cedar decision before mode override (populated for monitor/alert modes)."""

    mode_overridden: bool = False
    """True if decision was changed by per-policy mode annotation."""

    effective_mode: str = ""
    """Strictest mode among determining policies."""

    alerted: bool = False
    """True when an alert-mode policy fired. Trigger alerting pipeline when set."""

    reason: str = ""
    audit_id: str = ""
    request_id: str = ""
    timestamp: datetime

    determining_policies: list[DeterminingPolicy] = []
    detectors: list[DetectorResult] = []
    context: dict[str, Any] = {}
    projected_context: dict[str, Any] = {}

    latency_ms: int = 0
    eval_latency_ms: int = 0
    tiers_evaluated: list[str] = []
    tiers_skipped: list[str] = []

    session_delta: SessionDelta | None = None
    root_causes: list[RootCause] = []

    @property
    def allowed(self) -> bool:
        """True when the shield decision is allow."""
        return self.decision == "allow"

    @property
    def denied(self) -> bool:
        """True when the shield decision is deny."""
        return self.decision == "deny"


# ---------------------------------------------------------------------------
# Token exchange (service key flow)
# ---------------------------------------------------------------------------


class TokenResponse(_Base):
    """Response from the token exchange endpoint (service key → JWT)."""

    access_token: str
    """Short-lived RS256 JWT to use as Bearer token for Shield calls."""

    token_type: str = "Bearer"
    expires_in: int
    """Lifetime in seconds (typically 900 = 15 minutes)."""

    account_id: str = ""
    gateway_id: str = ""
    project_id: str = ""


# ---------------------------------------------------------------------------
# Health + detectors response models
# ---------------------------------------------------------------------------


class HealthResponse(_Base):
    """Response from GET /v1/health."""

    status: str
    """healthy | degraded"""

    detectors: dict[str, str] = {}
    """Per-detector health status."""

    evaluator: str = ""
    """Cedar evaluator status: ready | no_policies."""


class DetectorInfo(_Base):
    """Metadata about a registered detector."""

    name: str
    version: str = ""
    tier: str = ""
    status: str = ""


class ListDetectorsResponse(_Base):
    """Response from GET /v1/detectors."""

    detectors: list[DetectorInfo] = []
    count: int = 0
