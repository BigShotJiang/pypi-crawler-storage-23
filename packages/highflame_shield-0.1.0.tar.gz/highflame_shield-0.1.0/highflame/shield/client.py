"""ShieldClient: sync and async HTTP client for highflame-shield."""

from __future__ import annotations

import asyncio
import json
import threading
import time
from collections.abc import AsyncIterator, Iterator
from dataclasses import dataclass
from typing import Any

import httpx

try:
    from httpx_sse import aconnect_sse, connect_sse
except ImportError as exc:  # pragma: no cover
    raise ImportError(
        "httpx-sse is required for streaming support. "
        "Install it with: pip install httpx-sse"
    ) from exc

from .exceptions import ShieldAPIError, ShieldConnectionError
from .stream import ShieldStreamEvent
from .types import (
    HealthResponse,
    ListDetectorsResponse,
    Mode,
    ShieldRequest,
    ShieldResponse,
    TokenResponse,
    ToolContext,
)

_DEFAULT_TIMEOUT = 30.0
_DEFAULT_MAX_RETRIES = 2
_RETRY_STATUS_CODES = {429, 500, 502, 503, 504}
# Refresh the token this many seconds before it actually expires.
_TOKEN_REFRESH_BUFFER = 60

# SaaS endpoints — used as defaults; override via constructor for self-hosted.
_SAAS_BASE_URL  = "https://shield.api.highflame.ai"
_SAAS_TOKEN_URL = "https://studio.api.highflame.ai/api/cli-auth/token"


@dataclass
class _CachedToken:
    access_token: str
    expires_at: float   # time.time() + expires_in - _TOKEN_REFRESH_BUFFER
    account_id: str
    project_id: str
    gateway_id: str


def _raise_for_problem(response: httpx.Response) -> None:
    """Parse RFC 9457 Problem Details and raise ShieldAPIError."""
    if response.is_success:
        return
    try:
        body = response.json()
        title = body.get("title", response.reason_phrase or "Error")
        detail = body.get("detail", "")
    except Exception:
        title = response.reason_phrase or "Error"
        detail = response.text
    raise ShieldAPIError(status=response.status_code, title=title, detail=detail)


def _retry_delay(attempt: int) -> float:
    """Exponential backoff: 1s, 2s, 4s, …"""
    return 2**attempt


class ShieldClient:
    """
    Synchronous and asynchronous client for highflame-shield.

    ``base_url`` and ``token_url`` default to the Highflame SaaS endpoints so
    only ``api_key`` is required for most callers::

        # SaaS — service key (most common):
        client = ShieldClient(api_key="hf_sk_...")

        # Self-hosted override:
        client = ShieldClient(
            api_key="hf_sk_...",
            base_url="https://shield.self-hosted.example.com",
            token_url="https://auth.self-hosted.example.com/v1/auth/token",
        )

    Convenience shorthands for the most common patterns::

        resp = client.guard_prompt("What is the capital of France?")
        resp = client.guard_tool_call("shell", {"cmd": "ls"})

    Service Key Flow
    ~~~~~~~~~~~~~~~~
    Keys that start with ``hf_sk`` are automatically exchanged for a
    short-lived RS256 JWT via ``POST token_url``.  The JWT is cached and
    auto-refreshed 60 s before expiry.

    Direct JWT Flow
    ~~~~~~~~~~~~~~~
    Any other ``api_key`` value is sent directly as
    ``Authorization: Bearer <api_key>`` — useful when you already hold a
    short-lived token.
    """

    def __init__(
        self,
        api_key: str,
        *,
        base_url: str = _SAAS_BASE_URL,
        token_url: str = _SAAS_TOKEN_URL,
        timeout: float = _DEFAULT_TIMEOUT,
        max_retries: int = _DEFAULT_MAX_RETRIES,
        account_id: str | None = None,
        project_id: str | None = None,
    ) -> None:
        self._base_url = base_url.rstrip("/")
        self._api_key = api_key
        self._admin_url: str | None = token_url if api_key.startswith("hf_sk") else None
        self._timeout = timeout
        self._max_retries = max_retries
        self._override_account_id = account_id
        self._override_project_id = project_id

        # Pre-built static headers for the direct-JWT path.
        self._static_headers: dict[str, str] = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
            "Accept": "application/json",
        }
        if account_id:
            self._static_headers["X-Account-ID"] = account_id
        if project_id:
            self._static_headers["X-Project-ID"] = project_id

        # Token cache (service key flow only).
        self._cached_token: _CachedToken | None = None
        self._token_lock = threading.Lock()
        self._async_token_lock: asyncio.Lock | None = None

        # HTTP clients — lazily initialised on first use so constructing a
        # sync-only or async-only client doesn't spin up unnecessary resources.
        self.__sync_client: httpx.Client | None = None
        self.__async_client: httpx.AsyncClient | None = None
        self.__admin_sync_client: httpx.Client | None = None
        self.__admin_async_client: httpx.AsyncClient | None = None

    # ------------------------------------------------------------------
    # Lazy HTTP client properties
    # ------------------------------------------------------------------

    @property
    def _sync_client(self) -> httpx.Client:
        if self.__sync_client is None:
            self.__sync_client = httpx.Client(base_url=self._base_url)
        return self.__sync_client

    @property
    def _async_client(self) -> httpx.AsyncClient:
        if self.__async_client is None:
            self.__async_client = httpx.AsyncClient(base_url=self._base_url)
        return self.__async_client

    @property
    def _admin_sync_client(self) -> httpx.Client:
        if self.__admin_sync_client is None:
            self.__admin_sync_client = httpx.Client()
        return self.__admin_sync_client

    @property
    def _admin_async_client(self) -> httpx.AsyncClient:
        if self.__admin_async_client is None:
            self.__admin_async_client = httpx.AsyncClient()
        return self.__admin_async_client

    # ------------------------------------------------------------------
    # Context manager support
    # ------------------------------------------------------------------

    def __enter__(self) -> ShieldClient:
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()

    async def __aenter__(self) -> ShieldClient:
        return self

    async def __aexit__(self, *args: Any) -> None:
        await self.aclose()

    def close(self) -> None:
        """Close the underlying sync HTTP clients."""
        if self.__sync_client:
            self.__sync_client.close()
        if self.__admin_sync_client:
            self.__admin_sync_client.close()

    async def aclose(self) -> None:
        """Close the underlying async HTTP clients."""
        if self.__async_client:
            await self.__async_client.aclose()
        if self.__admin_async_client:
            await self.__admin_async_client.aclose()

    # ------------------------------------------------------------------
    # Token exchange (service key flow)
    # ------------------------------------------------------------------

    def _build_token_headers(self, token: _CachedToken) -> dict[str, str]:
        headers: dict[str, str] = {
            "Authorization": f"Bearer {token.access_token}",
            "Content-Type": "application/json",
            "Accept": "application/json",
        }
        account_id = self._override_account_id or token.account_id
        project_id = self._override_project_id or token.project_id
        if account_id:
            headers["X-Account-ID"] = account_id
        if project_id:
            headers["X-Project-ID"] = project_id
        return headers

    def _exchange_token(self) -> _CachedToken:
        """Exchange the service key for a short-lived JWT (sync)."""
        assert self._admin_url is not None
        try:
            resp = self._admin_sync_client.post(
                self._admin_url,
                json={"grant_type": "api_key", "api_key": self._api_key},
                timeout=self._timeout,
            )
        except httpx.TimeoutException as exc:
            raise ShieldConnectionError(f"Token exchange timed out: {exc}") from exc
        except httpx.ConnectError as exc:
            raise ShieldConnectionError(f"Token exchange connection failed: {exc}") from exc
        _raise_for_problem(resp)
        tok = TokenResponse.model_validate(resp.json())
        return _CachedToken(
            access_token=tok.access_token,
            expires_at=time.time() + tok.expires_in - _TOKEN_REFRESH_BUFFER,
            account_id=tok.account_id,
            project_id=tok.project_id,
            gateway_id=tok.gateway_id,
        )

    async def _aexchange_token(self) -> _CachedToken:
        """Exchange the service key for a short-lived JWT (async)."""
        assert self._admin_url is not None
        try:
            resp = await self._admin_async_client.post(
                self._admin_url,
                json={"grant_type": "api_key", "api_key": self._api_key},
                timeout=self._timeout,
            )
        except httpx.TimeoutException as exc:
            raise ShieldConnectionError(f"Token exchange timed out: {exc}") from exc
        except httpx.ConnectError as exc:
            raise ShieldConnectionError(f"Token exchange connection failed: {exc}") from exc
        _raise_for_problem(resp)
        tok = TokenResponse.model_validate(resp.json())
        return _CachedToken(
            access_token=tok.access_token,
            expires_at=time.time() + tok.expires_in - _TOKEN_REFRESH_BUFFER,
            account_id=tok.account_id,
            project_id=tok.project_id,
            gateway_id=tok.gateway_id,
        )

    def _get_auth_headers(self) -> dict[str, str]:
        """Return auth headers, refreshing the JWT if needed (sync, thread-safe)."""
        if not self._admin_url:
            return self._static_headers
        with self._token_lock:
            if self._cached_token is None or time.time() >= self._cached_token.expires_at:
                self._cached_token = self._exchange_token()
            return self._build_token_headers(self._cached_token)

    async def _aget_auth_headers(self) -> dict[str, str]:
        """Return auth headers, refreshing the JWT if needed (async, coroutine-safe).

        Uses threading.Lock for every read/write of _cached_token so this path
        coordinates with _get_auth_headers() on any OS thread.  The lock is never
        held across an await (that would block the event loop), so asyncio.Lock
        is layered on top to deduplicate concurrent coroutines that all observe an
        expired token — without them all racing to exchange simultaneously.

        Flow:
          1. threading.Lock fast-path check (non-blocking memory read).
          2. asyncio.Lock to serialise concurrent async refreshes.
          3. threading.Lock re-check inside asyncio.Lock (a sync or preceding async
             caller may have already refreshed while we were waiting).
          4. Exchange outside both locks (awaitable I/O).
          5. threading.Lock write-back so sync callers see the new token atomically.
        """
        if not self._admin_url:
            return self._static_headers

        # Step 1 — fast path: read under threading lock (brief, non-blocking).
        with self._token_lock:
            if self._cached_token is not None and time.time() < self._cached_token.expires_at:
                return self._build_token_headers(self._cached_token)
            # Lazily create the async dedup lock while the threading lock is held.
            if self._async_token_lock is None:
                self._async_token_lock = asyncio.Lock()

        # Step 2 — serialise concurrent async refreshes without blocking the loop.
        async with self._async_token_lock:
            # Step 3 — re-check: sync caller or prior async caller may have refreshed.
            with self._token_lock:
                if self._cached_token is not None and time.time() < self._cached_token.expires_at:
                    return self._build_token_headers(self._cached_token)

            # Step 4 — exchange (awaitable, outside threading lock).
            new_token = await self._aexchange_token()

            # Step 5 — write back under threading lock so sync readers see it atomically.
            with self._token_lock:
                self._cached_token = new_token
                return self._build_token_headers(self._cached_token)

    # ------------------------------------------------------------------
    # Internal request helpers
    # ------------------------------------------------------------------

    def _request_with_retry(
        self,
        method: str,
        path: str,
        body: dict[str, Any] | None = None,
        timeout: float | None = None,
    ) -> httpx.Response:
        """Make an HTTP request with retries and per-attempt auth refresh."""
        effective_timeout = timeout if timeout is not None else self._timeout
        last_exc: Exception = ShieldConnectionError("Request failed after all retries.")
        for attempt in range(self._max_retries + 1):
            if attempt > 0:
                time.sleep(_retry_delay(attempt - 1))
            # Re-fetch auth headers each attempt — token may have been
            # refreshed by another thread while we were backing off.
            headers = self._get_auth_headers()
            try:
                response = self._sync_client.request(
                    method,
                    path,
                    content=json.dumps(body) if body is not None else None,
                    headers=headers,
                    timeout=effective_timeout,
                )
            except httpx.TimeoutException as exc:
                last_exc = ShieldConnectionError(f"Request timed out: {exc}")
                continue
            except httpx.ConnectError as exc:
                raise ShieldConnectionError(f"Connection failed: {exc}") from exc

            if response.status_code not in _RETRY_STATUS_CODES:
                _raise_for_problem(response)
                return response

            last_exc = ShieldAPIError(
                status=response.status_code,
                title=response.reason_phrase or "Server Error",
                detail=response.text,
            )

        raise last_exc  # type: ignore[misc]

    async def _arequest_with_retry(
        self,
        method: str,
        path: str,
        body: dict[str, Any] | None = None,
        timeout: float | None = None,
    ) -> httpx.Response:
        """Async: make an HTTP request with retries and per-attempt auth refresh."""
        effective_timeout = timeout if timeout is not None else self._timeout
        last_exc: Exception = ShieldConnectionError("Request failed after all retries.")
        for attempt in range(self._max_retries + 1):
            if attempt > 0:
                await asyncio.sleep(_retry_delay(attempt - 1))
            headers = await self._aget_auth_headers()
            try:
                response = await self._async_client.request(
                    method,
                    path,
                    content=json.dumps(body) if body is not None else None,
                    headers=headers,
                    timeout=effective_timeout,
                )
            except httpx.TimeoutException as exc:
                last_exc = ShieldConnectionError(f"Request timed out: {exc}")
                continue
            except httpx.ConnectError as exc:
                raise ShieldConnectionError(f"Connection failed: {exc}") from exc

            if response.status_code not in _RETRY_STATUS_CODES:
                _raise_for_problem(response)
                return response

            last_exc = ShieldAPIError(
                status=response.status_code,
                title=response.reason_phrase or "Server Error",
                detail=response.text,
            )

        raise last_exc  # type: ignore[misc]

    # ------------------------------------------------------------------
    # Sync API
    # ------------------------------------------------------------------

    def guard(self, request: ShieldRequest, *, timeout: float | None = None) -> ShieldResponse:
        """
        Evaluate content against guard policies.

        POST /v1/guard — full detect + Cedar evaluate.
        """
        body = request.model_dump(exclude_none=True, by_alias=True)
        response = self._request_with_retry("POST", "/v1/guard", body, timeout=timeout)
        return ShieldResponse.model_validate(response.json())

    def guard_prompt(
        self,
        content: str,
        *,
        mode: Mode = "enforce",
        session_id: str | None = None,
        timeout: float | None = None,
    ) -> ShieldResponse:
        """
        Shorthand: evaluate a user prompt.

        Equivalent to ``guard()`` with ``content_type="prompt"`` and
        ``action="process_prompt"``.
        """
        return self.guard(
            ShieldRequest(
                content=content,
                content_type="prompt",
                action="process_prompt",
                mode=mode,
                session_id=session_id,
            ),
            timeout=timeout,
        )

    def guard_tool_call(
        self,
        tool_name: str,
        arguments: dict[str, Any] | None = None,
        *,
        mode: Mode = "enforce",
        session_id: str | None = None,
        timeout: float | None = None,
    ) -> ShieldResponse:
        """
        Shorthand: evaluate a tool call.

        Equivalent to ``guard()`` with ``content_type="tool_call"`` and
        ``action="call_tool"``.
        """
        return self.guard(
            ShieldRequest(
                content=f"Tool call: {tool_name}",
                content_type="tool_call",
                action="call_tool",
                mode=mode,
                session_id=session_id,
                tool=ToolContext(name=tool_name, arguments=arguments),
            ),
            timeout=timeout,
        )

    def stream(
        self, request: ShieldRequest, *, timeout: float | None = None
    ) -> Iterator[ShieldStreamEvent]:
        """
        Evaluate content with SSE streaming.

        POST /v1/guard/stream — yields ShieldStreamEvent objects as they arrive.
        """
        headers = self._get_auth_headers()
        body = request.model_dump(exclude_none=True, by_alias=True)
        effective_timeout = timeout if timeout is not None else self._timeout
        try:
            with connect_sse(
                self._sync_client,
                "POST",
                "/v1/guard/stream",
                content=json.dumps(body),
                headers=headers,
                timeout=effective_timeout,
            ) as event_source:
                for sse in event_source.iter_sse():
                    if not sse.data:
                        continue
                    try:
                        payload = json.loads(sse.data)
                    except json.JSONDecodeError:
                        continue
                    yield ShieldStreamEvent(
                        type=sse.event or "detection",
                        data=payload,
                    )
        except httpx.TimeoutException as exc:
            raise ShieldConnectionError(f"Stream timed out: {exc}") from exc
        except httpx.ConnectError as exc:
            raise ShieldConnectionError(f"Connection failed: {exc}") from exc

    def health(self, *, timeout: float | None = None) -> HealthResponse:
        """
        Get detailed service health.

        GET /v1/health — returns detector statuses and evaluator state.
        """
        response = self._request_with_retry("GET", "/v1/health", timeout=timeout)
        return HealthResponse.model_validate(response.json())

    def list_detectors(self, *, timeout: float | None = None) -> ListDetectorsResponse:
        """
        List available detectors.

        GET /v1/detectors — returns detector names, tiers, and health.
        """
        response = self._request_with_retry("GET", "/v1/detectors", timeout=timeout)
        return ListDetectorsResponse.model_validate(response.json())

    # ------------------------------------------------------------------
    # Async API
    # ------------------------------------------------------------------

    async def aguard(
        self, request: ShieldRequest, *, timeout: float | None = None
    ) -> ShieldResponse:
        """
        Async: evaluate content against guard policies.

        POST /v1/guard — full detect + Cedar evaluate.
        """
        body = request.model_dump(exclude_none=True, by_alias=True)
        response = await self._arequest_with_retry("POST", "/v1/guard", body, timeout=timeout)
        return ShieldResponse.model_validate(response.json())

    async def aguard_prompt(
        self,
        content: str,
        *,
        mode: Mode = "enforce",
        session_id: str | None = None,
        timeout: float | None = None,
    ) -> ShieldResponse:
        """Async shorthand: evaluate a user prompt."""
        return await self.aguard(
            ShieldRequest(
                content=content,
                content_type="prompt",
                action="process_prompt",
                mode=mode,
                session_id=session_id,
            ),
            timeout=timeout,
        )

    async def aguard_tool_call(
        self,
        tool_name: str,
        arguments: dict[str, Any] | None = None,
        *,
        mode: Mode = "enforce",
        session_id: str | None = None,
        timeout: float | None = None,
    ) -> ShieldResponse:
        """Async shorthand: evaluate a tool call."""
        return await self.aguard(
            ShieldRequest(
                content=f"Tool call: {tool_name}",
                content_type="tool_call",
                action="call_tool",
                mode=mode,
                session_id=session_id,
                tool=ToolContext(name=tool_name, arguments=arguments),
            ),
            timeout=timeout,
        )

    async def astream(
        self, request: ShieldRequest, *, timeout: float | None = None
    ) -> AsyncIterator[ShieldStreamEvent]:
        """
        Async: evaluate content with SSE streaming.

        POST /v1/guard/stream — yields ShieldStreamEvent objects as they arrive.
        """
        headers = await self._aget_auth_headers()
        body = request.model_dump(exclude_none=True, by_alias=True)
        effective_timeout = timeout if timeout is not None else self._timeout
        try:
            async with aconnect_sse(
                self._async_client,
                "POST",
                "/v1/guard/stream",
                content=json.dumps(body),
                headers=headers,
                timeout=effective_timeout,
            ) as event_source:
                async for sse in event_source.aiter_sse():
                    if not sse.data:
                        continue
                    try:
                        payload = json.loads(sse.data)
                    except json.JSONDecodeError:
                        continue
                    yield ShieldStreamEvent(
                        type=sse.event or "detection",
                        data=payload,
                    )
        except httpx.TimeoutException as exc:
            raise ShieldConnectionError(f"Stream timed out: {exc}") from exc
        except httpx.ConnectError as exc:
            raise ShieldConnectionError(f"Connection failed: {exc}") from exc

    async def ahealth(self, *, timeout: float | None = None) -> HealthResponse:
        """Async: get detailed service health."""
        response = await self._arequest_with_retry("GET", "/v1/health", timeout=timeout)
        return HealthResponse.model_validate(response.json())

    async def alist_detectors(self, *, timeout: float | None = None) -> ListDetectorsResponse:
        """Async: list available detectors."""
        response = await self._arequest_with_retry("GET", "/v1/detectors", timeout=timeout)
        return ListDetectorsResponse.model_validate(response.json())
