"""
highflame-shield Python SDK.

Quick start::

    from highflame.shield import ShieldClient, ShieldRequest

    client = ShieldClient(base_url="http://localhost:8060", api_key="...")
    resp = client.guard(ShieldRequest(
        content="print secrets",
        content_type="prompt",
        action="process_prompt",
    ))
    print(resp.decision)  # "allow" or "deny"
"""

from .client import ShieldClient
from .decorators import Shield
from .exceptions import ShieldAPIError, ShieldBlockedError, ShieldConnectionError, ShieldError
from .stream import ShieldStreamEvent
from .types import (
    Action,
    ContentType,
    DetectorInfo,
    DetectorResult,
    DeterminingPolicy,
    FileContext,
    HealthResponse,
    ListDetectorsResponse,
    MCPContext,
    Mode,
    ModelContext,
    Product,
    RootCause,
    SessionDelta,
    ShieldRequest,
    ShieldResponse,
    TokenResponse,
    ToolContext,
)

__all__ = [
    # Client + decorator facade
    "ShieldClient",
    "Shield",
    # Request types
    "ShieldRequest",
    "ToolContext",
    "ModelContext",
    "FileContext",
    "MCPContext",
    # Typed string aliases
    "ContentType",
    "Action",
    "Mode",
    "Product",
    # Response types
    "ShieldResponse",
    "DeterminingPolicy",
    "DetectorResult",
    "SessionDelta",
    "RootCause",
    "HealthResponse",
    "ListDetectorsResponse",
    "DetectorInfo",
    "TokenResponse",
    # Stream
    "ShieldStreamEvent",
    # Exceptions
    "ShieldError",
    "ShieldAPIError",
    "ShieldConnectionError",
    "ShieldBlockedError",
]
