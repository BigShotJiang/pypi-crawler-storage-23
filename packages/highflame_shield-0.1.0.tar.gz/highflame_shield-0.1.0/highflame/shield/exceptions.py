"""Error hierarchy for the highflame-shield SDK."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .types import ShieldResponse


class ShieldError(Exception):
    """Base class for all SDK errors."""


class ShieldAPIError(ShieldError):
    """HTTP error from the guard service (RFC 9457 Problem Details)."""

    def __init__(self, status: int, title: str, detail: str) -> None:
        self.status = status
        self.title = title
        self.detail = detail
        super().__init__(f"[{status}] {title}: {detail}")


class ShieldConnectionError(ShieldError):
    """Connection or timeout failure communicating with the guard service."""


class ShieldBlockedError(ShieldError):
    """Raised by Shield decorators when the guard decision is 'deny'."""

    def __init__(self, response: ShieldResponse) -> None:
        self.response = response
        super().__init__(
            f"Blocked by Shield: {response.reason or response.decision}"
        )
