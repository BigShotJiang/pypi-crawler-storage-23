"""Unit tests for ShieldClient using respx mock transport."""

import json
import time

import httpx
import pytest
import respx

from highflame.shield import (
    HealthResponse,
    ListDetectorsResponse,
    ShieldAPIError,
    ShieldClient,
    ShieldRequest,
    ShieldResponse,
    ToolContext,
)

BASE_URL = "http://guard.test"
ADMIN_URL = "http://admin.test/v1/auth/token"
API_KEY = "test-key"
SERVICE_KEY = "hf_sk_test_key"

# Reused across tests — keeps individual tests focused on what makes them distinct.
_MINIMAL_REQ = ShieldRequest(content="x", content_type="prompt", action="process_prompt")


def _make_client(**kwargs) -> ShieldClient:
    return ShieldClient(base_url=BASE_URL, api_key=API_KEY, max_retries=0, **kwargs)


_ALLOW_BODY = {
    "decision": "allow",
    "timestamp": "2024-01-01T00:00:00Z",
    "latency_ms": 5,
    "tiers_evaluated": ["fast"],
    "tiers_skipped": [],
    "detectors": [],
    "context": {},
}

_DENY_BODY = {
    "decision": "deny",
    "reason": "secrets detected",
    "timestamp": "2024-01-01T00:00:00Z",
    "latency_ms": 5,
    "tiers_evaluated": ["fast"],
    "tiers_skipped": ["standard"],
    "detectors": [],
    "context": {"contains_secrets": True},
}

_PROBLEM_BODY = {
    "status": 400,
    "title": "Bad Request",
    "detail": "content is required",
}

_HEALTH_BODY = {
    "status": "healthy",
    "detectors": {"secrets": "healthy", "keyword": "healthy"},
    "evaluator": "ready",
}

_DETECTORS_BODY = {
    "detectors": [
        {"name": "secrets", "version": "1.0", "tier": "fast", "status": "healthy"},
        {"name": "keyword", "version": "1.0", "tier": "fast", "status": "healthy"},
    ],
    "count": 2,
}


# ---------------------------------------------------------------------------
# Sync guard()
# ---------------------------------------------------------------------------


@respx.mock
def test_guard_allow():
    respx.post(f"{BASE_URL}/v1/guard").mock(return_value=httpx.Response(200, json=_ALLOW_BODY))
    client = _make_client()
    resp = client.guard(ShieldRequest(content="hi", content_type="prompt", action="process_prompt"))
    assert isinstance(resp, ShieldResponse)
    assert resp.decision == "allow"
    assert resp.allowed is True


@respx.mock
def test_guard_deny():
    respx.post(f"{BASE_URL}/v1/guard").mock(return_value=httpx.Response(200, json=_DENY_BODY))
    client = _make_client()
    resp = client.guard(
        ShieldRequest(content="api_key=abc", content_type="prompt", action="process_prompt")
    )
    assert resp.decision == "deny"
    assert resp.denied is True
    assert resp.reason == "secrets detected"


@respx.mock
def test_guard_sends_auth_header():
    route = respx.post(f"{BASE_URL}/v1/guard").mock(
        return_value=httpx.Response(200, json=_ALLOW_BODY)
    )
    _make_client().guard(_MINIMAL_REQ)
    assert route.calls.last.request.headers["Authorization"] == f"Bearer {API_KEY}"


@respx.mock
def test_guard_sends_tenant_headers():
    route = respx.post(f"{BASE_URL}/v1/guard").mock(
        return_value=httpx.Response(200, json=_ALLOW_BODY)
    )
    _make_client(account_id="acc_1", project_id="proj_1").guard(_MINIMAL_REQ)
    req = route.calls.last.request
    assert req.headers["X-Account-ID"] == "acc_1"
    assert req.headers["X-Project-ID"] == "proj_1"


@respx.mock
def test_guard_400_raises_api_error():
    respx.post(f"{BASE_URL}/v1/guard").mock(return_value=httpx.Response(400, json=_PROBLEM_BODY))
    with pytest.raises(ShieldAPIError) as exc_info:
        _make_client().guard(_MINIMAL_REQ)
    err = exc_info.value
    assert err.status == 400
    assert err.title == "Bad Request"
    assert "content is required" in err.detail


@respx.mock
def test_guard_500_raises_api_error_no_retry():
    respx.post(f"{BASE_URL}/v1/guard").mock(
        return_value=httpx.Response(
            500, json={"status": 500, "title": "Internal Server Error", "detail": "oops"}
        )
    )
    with pytest.raises(ShieldAPIError) as exc_info:
        _make_client().guard(_MINIMAL_REQ)  # max_retries=0
    assert exc_info.value.status == 500


@respx.mock
def test_guard_retries_on_503():
    """Client retries on 503 and succeeds on second attempt."""
    call_count = 0

    def side_effect(request):
        nonlocal call_count
        call_count += 1
        if call_count == 1:
            return httpx.Response(
                503, json={"status": 503, "title": "Service Unavailable", "detail": ""}
            )
        return httpx.Response(200, json=_ALLOW_BODY)

    respx.post(f"{BASE_URL}/v1/guard").mock(side_effect=side_effect)
    client = ShieldClient(base_url=BASE_URL, api_key=API_KEY, max_retries=1, timeout=5.0)
    resp = client.guard(_MINIMAL_REQ)
    assert resp.decision == "allow"
    assert call_count == 2


# ---------------------------------------------------------------------------
# Sync health() and list_detectors()
# ---------------------------------------------------------------------------


@respx.mock
def test_health():
    respx.get(f"{BASE_URL}/v1/health").mock(return_value=httpx.Response(200, json=_HEALTH_BODY))
    health = _make_client().health()
    assert isinstance(health, HealthResponse)
    assert health.status == "healthy"
    assert health.evaluator == "ready"
    assert health.detectors["secrets"] == "healthy"


@respx.mock
def test_list_detectors():
    respx.get(f"{BASE_URL}/v1/detectors").mock(
        return_value=httpx.Response(200, json=_DETECTORS_BODY)
    )
    result = _make_client().list_detectors()
    assert isinstance(result, ListDetectorsResponse)
    assert result.count == 2
    assert result.detectors[0].name == "secrets"


# ---------------------------------------------------------------------------
# Async aguard()
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
@respx.mock
async def test_aguard_allow():
    respx.post(f"{BASE_URL}/v1/guard").mock(return_value=httpx.Response(200, json=_ALLOW_BODY))
    async with _make_client() as client:
        resp = await client.aguard(
            ShieldRequest(content="hello", content_type="prompt", action="process_prompt")
        )
    assert resp.decision == "allow"


@pytest.mark.asyncio
@respx.mock
async def test_aguard_api_error():
    respx.post(f"{BASE_URL}/v1/guard").mock(
        return_value=httpx.Response(
            422, json={"status": 422, "title": "Unprocessable Entity", "detail": "bad field"}
        )
    )
    async with _make_client() as client:
        with pytest.raises(ShieldAPIError) as exc_info:
            await client.aguard(_MINIMAL_REQ)
    assert exc_info.value.status == 422


@pytest.mark.asyncio
@respx.mock
async def test_ahealth():
    respx.get(f"{BASE_URL}/v1/health").mock(return_value=httpx.Response(200, json=_HEALTH_BODY))
    async with _make_client() as client:
        health = await client.ahealth()
    assert health.status == "healthy"


@pytest.mark.asyncio
@respx.mock
async def test_alist_detectors():
    respx.get(f"{BASE_URL}/v1/detectors").mock(
        return_value=httpx.Response(200, json=_DETECTORS_BODY)
    )
    async with _make_client() as client:
        result = await client.alist_detectors()
    assert result.count == 2


# ---------------------------------------------------------------------------
# Request body serialisation
# ---------------------------------------------------------------------------


@respx.mock
def test_request_body_excludes_none_fields():
    """Unset optional fields must not appear in request body."""
    route = respx.post(f"{BASE_URL}/v1/guard").mock(
        return_value=httpx.Response(200, json=_ALLOW_BODY)
    )
    _make_client().guard(_MINIMAL_REQ)
    body = json.loads(route.calls.last.request.content)
    # Typed context objects
    assert "tool" not in body
    assert "model" not in body
    assert "file" not in body
    assert "mcp" not in body
    assert "session_id" not in body
    # Empty collections — must be absent, not serialised as [] / {}
    assert "detectors" not in body
    assert "metadata" not in body
    assert "contexts" not in body


@respx.mock
def test_request_body_includes_tool_context():
    """ToolContext nested model serialises correctly."""
    route = respx.post(f"{BASE_URL}/v1/guard").mock(
        return_value=httpx.Response(200, json=_ALLOW_BODY)
    )
    _make_client().guard(
        ShieldRequest(
            content="shell ls",
            content_type="tool_call",
            action="call_tool",
            tool=ToolContext(name="shell", arguments={"cmd": "ls"}),
        )
    )
    body = json.loads(route.calls.last.request.content)
    assert body["tool"]["name"] == "shell"
    assert body["tool"]["arguments"]["cmd"] == "ls"


# ---------------------------------------------------------------------------
# Service key flow
# ---------------------------------------------------------------------------

_TOKEN_BODY = {
    "access_token": "eyJhbGciOiJSUzI1NiJ9.test.sig",
    "token_type": "Bearer",
    "expires_in": 900,
    "account_id": "acc_from_token",
    "gateway_id": "gw_123",
    "project_id": "proj_from_token",
}


def _make_sk_client(**kwargs) -> ShieldClient:
    return ShieldClient(
        base_url=BASE_URL,
        api_key=SERVICE_KEY,
        token_url=ADMIN_URL,
        max_retries=0,
        **kwargs,
    )


@respx.mock
def test_service_key_exchanges_token_on_first_call():
    """Token exchange fires before the first Shield request; JWT used as Bearer."""
    respx.post(ADMIN_URL).mock(return_value=httpx.Response(200, json=_TOKEN_BODY))
    guard_route = respx.post(f"{BASE_URL}/v1/guard").mock(
        return_value=httpx.Response(200, json=_ALLOW_BODY)
    )
    resp = _make_sk_client().guard(_MINIMAL_REQ)
    assert resp.decision == "allow"
    assert guard_route.calls.last.request.headers["authorization"] == (
        f"Bearer {_TOKEN_BODY['access_token']}"
    )


@respx.mock
def test_service_key_injects_tenant_headers_from_token():
    """account_id and project_id from token response are forwarded as X-* headers."""
    respx.post(ADMIN_URL).mock(return_value=httpx.Response(200, json=_TOKEN_BODY))
    guard_route = respx.post(f"{BASE_URL}/v1/guard").mock(
        return_value=httpx.Response(200, json=_ALLOW_BODY)
    )
    _make_sk_client().guard(_MINIMAL_REQ)
    req = guard_route.calls.last.request
    assert req.headers["x-account-id"] == _TOKEN_BODY["account_id"]
    assert req.headers["x-project-id"] == _TOKEN_BODY["project_id"]


@respx.mock
def test_service_key_caches_token_across_calls():
    """Token exchange happens only once for multiple consecutive guard calls."""
    exchange_route = respx.post(ADMIN_URL).mock(
        return_value=httpx.Response(200, json=_TOKEN_BODY)
    )
    respx.post(f"{BASE_URL}/v1/guard").mock(return_value=httpx.Response(200, json=_ALLOW_BODY))
    client = _make_sk_client()
    client.guard(_MINIMAL_REQ)
    client.guard(_MINIMAL_REQ)
    client.guard(_MINIMAL_REQ)
    assert len(exchange_route.calls) == 1


@respx.mock
def test_service_key_refreshes_expired_token():
    """When the cached token is expired, a new exchange is triggered."""
    exchange_route = respx.post(ADMIN_URL).mock(
        return_value=httpx.Response(200, json=_TOKEN_BODY)
    )
    respx.post(f"{BASE_URL}/v1/guard").mock(return_value=httpx.Response(200, json=_ALLOW_BODY))
    client = _make_sk_client()

    client.guard(_MINIMAL_REQ)
    assert len(exchange_route.calls) == 1

    # Force expiry.
    assert client._cached_token is not None
    client._cached_token.expires_at = time.time() - 1

    client.guard(_MINIMAL_REQ)
    assert len(exchange_route.calls) == 2


@respx.mock
def test_service_key_constructor_overrides_tenant_headers():
    """Explicit account_id/project_id in constructor take precedence over token."""
    respx.post(ADMIN_URL).mock(return_value=httpx.Response(200, json=_TOKEN_BODY))
    guard_route = respx.post(f"{BASE_URL}/v1/guard").mock(
        return_value=httpx.Response(200, json=_ALLOW_BODY)
    )
    _make_sk_client(account_id="override_acc", project_id="override_proj").guard(_MINIMAL_REQ)
    req = guard_route.calls.last.request
    assert req.headers["x-account-id"] == "override_acc"
    assert req.headers["x-project-id"] == "override_proj"


@respx.mock
def test_service_key_exchange_failure_raises_api_error():
    """401 from Admin on token exchange raises ShieldAPIError."""
    respx.post(ADMIN_URL).mock(
        return_value=httpx.Response(
            401, json={"status": 401, "title": "Unauthorized", "detail": "invalid key"}
        )
    )
    with pytest.raises(ShieldAPIError) as exc_info:
        _make_sk_client().guard(_MINIMAL_REQ)
    assert exc_info.value.status == 401
    assert "invalid key" in exc_info.value.detail


@pytest.mark.asyncio
@respx.mock
async def test_service_key_async_exchanges_token():
    """Async path exchanges the token and uses the JWT."""
    respx.post(ADMIN_URL).mock(return_value=httpx.Response(200, json=_TOKEN_BODY))
    guard_route = respx.post(f"{BASE_URL}/v1/guard").mock(
        return_value=httpx.Response(200, json=_ALLOW_BODY)
    )
    async with _make_sk_client() as client:
        resp = await client.aguard(_MINIMAL_REQ)
    assert resp.decision == "allow"
    assert guard_route.calls.last.request.headers["authorization"] == (
        f"Bearer {_TOKEN_BODY['access_token']}"
    )


@pytest.mark.asyncio
@respx.mock
async def test_service_key_async_caches_token():
    """Async path exchanges token only once across multiple calls."""
    exchange_route = respx.post(ADMIN_URL).mock(
        return_value=httpx.Response(200, json=_TOKEN_BODY)
    )
    respx.post(f"{BASE_URL}/v1/guard").mock(return_value=httpx.Response(200, json=_ALLOW_BODY))
    async with _make_sk_client() as client:
        await client.aguard(_MINIMAL_REQ)
        await client.aguard(_MINIMAL_REQ)
    assert len(exchange_route.calls) == 1


# ---------------------------------------------------------------------------
# Cross-path token sharing (sync ↔ async)
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
@respx.mock
async def test_service_key_sync_token_reused_by_async():
    """Token exchanged by sync guard() is reused by a subsequent aguard() call."""
    exchange_route = respx.post(ADMIN_URL).mock(
        return_value=httpx.Response(200, json=_TOKEN_BODY)
    )
    respx.post(f"{BASE_URL}/v1/guard").mock(return_value=httpx.Response(200, json=_ALLOW_BODY))
    client = _make_sk_client()

    client.guard(_MINIMAL_REQ)         # sync — exchanges token
    await client.aguard(_MINIMAL_REQ)  # async — must reuse the same token

    assert len(exchange_route.calls) == 1


@pytest.mark.asyncio
@respx.mock
async def test_service_key_async_token_reused_by_sync():
    """Token exchanged by async aguard() is reused by a subsequent sync guard() call."""
    exchange_route = respx.post(ADMIN_URL).mock(
        return_value=httpx.Response(200, json=_TOKEN_BODY)
    )
    respx.post(f"{BASE_URL}/v1/guard").mock(return_value=httpx.Response(200, json=_ALLOW_BODY))
    client = _make_sk_client()

    await client.aguard(_MINIMAL_REQ)  # async — exchanges token
    client.guard(_MINIMAL_REQ)         # sync — must reuse the same token

    assert len(exchange_route.calls) == 1
