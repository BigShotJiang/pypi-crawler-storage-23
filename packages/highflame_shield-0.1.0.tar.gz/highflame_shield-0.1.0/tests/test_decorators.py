"""Tests for Shield decorator facade (highflame/shield/decorators.py)."""

from __future__ import annotations

import json

import httpx
import pytest
import respx

from highflame.shield import (
    Shield,
    ShieldBlockedError,
    ShieldClient,
)

BASE_URL = "http://guard.test"
API_KEY = "test-key"

_ALLOW_BODY = {
    "decision": "allow",
    "timestamp": "2024-01-01T00:00:00Z",
    "latency_ms": 5,
    "tiers_evaluated": ["fast"],
    "tiers_skipped": [],
    "detectors": [],
    "context": {},
}

_DENY_BODY = {
    "decision": "deny",
    "reason": "secrets detected",
    "timestamp": "2024-01-01T00:00:00Z",
    "latency_ms": 5,
    "tiers_evaluated": ["fast"],
    "tiers_skipped": ["standard"],
    "detectors": [],
    "context": {"contains_secrets": True},
}


def _client() -> ShieldClient:
    return ShieldClient(base_url=BASE_URL, api_key=API_KEY, max_retries=0)


def _shield() -> Shield:
    return Shield(_client())


# ---------------------------------------------------------------------------
# Helpers — build respx mock
# ---------------------------------------------------------------------------


def _guard_route(router: respx.MockRouter, body: dict) -> respx.Route:
    return router.post(f"{BASE_URL}/v1/guard").mock(
        return_value=httpx.Response(200, json=body)
    )


# ---------------------------------------------------------------------------
# @shield.prompt — sync
# ---------------------------------------------------------------------------


@respx.mock
def test_prompt_allow():
    _guard_route(respx.mock, _ALLOW_BODY)
    s = _shield()

    @s.prompt
    def chat(message: str) -> str:
        return "ok"

    result = chat("hello")
    assert result == "ok"


@respx.mock
def test_prompt_deny_raises():
    _guard_route(respx.mock, _DENY_BODY)
    s = _shield()
    called = []

    @s.prompt
    def chat(message: str) -> str:
        called.append(True)
        return "ok"

    with pytest.raises(ShieldBlockedError):
        chat("bad content")

    assert called == [], "function body must not execute on deny"


@respx.mock
def test_prompt_no_parens():
    """@shield.prompt (bare decorator) works identically to @shield.prompt()."""
    _guard_route(respx.mock, _ALLOW_BODY)
    s = _shield()

    @s.prompt
    def fn1(msg: str) -> str:
        return "bare"

    @s.prompt()
    def fn2(msg: str) -> str:
        return "parens"

    assert fn1("hello") == "bare"
    assert fn2("hello") == "parens"


@respx.mock
def test_prompt_with_mode():
    route = _guard_route(respx.mock, _ALLOW_BODY)
    s = _shield()

    @s.prompt(mode="monitor")
    def chat(msg: str) -> str:
        return "ok"

    chat("hello")

    sent = json.loads(route.calls.last.request.content)
    assert sent["mode"] == "monitor"


@respx.mock
def test_prompt_content_arg():
    """content_arg= selects the correct parameter as guarded content."""
    route = _guard_route(respx.mock, _ALLOW_BODY)
    s = _shield()

    @s.prompt(content_arg="user_input")
    def chat(context: str, user_input: str) -> str:
        return "ok"

    chat(context="ctx", user_input="hello world")

    sent = json.loads(route.calls.last.request.content)
    assert sent["content"] == "hello world"


@respx.mock
def test_prompt_sends_correct_body():
    route = _guard_route(respx.mock, _ALLOW_BODY)
    s = _shield()

    @s.prompt
    def chat(message: str) -> str:
        return "ok"

    chat("test message")

    sent = json.loads(route.calls.last.request.content)
    assert sent["content"] == "test message"
    assert sent["content_type"] == "prompt"
    assert sent["action"] == "process_prompt"


# ---------------------------------------------------------------------------
# @shield.tool — sync
# ---------------------------------------------------------------------------


@respx.mock
def test_tool_allow():
    _guard_route(respx.mock, _ALLOW_BODY)
    s = _shield()

    @s.tool
    def shell(cmd: str) -> str:
        return "output"

    result = shell("ls")
    assert result == "output"


@respx.mock
def test_tool_deny_raises():
    _guard_route(respx.mock, _DENY_BODY)
    s = _shield()
    called = []

    @s.tool
    def shell(cmd: str) -> str:
        called.append(True)
        return "output"

    with pytest.raises(ShieldBlockedError):
        shell("rm -rf /")

    assert called == [], "function body must not execute on deny"


@respx.mock
def test_tool_sends_tool_context():
    route = _guard_route(respx.mock, _ALLOW_BODY)
    s = _shield()

    @s.tool
    def shell(cmd: str) -> str:
        return "ok"

    shell("ls -la")

    sent = json.loads(route.calls.last.request.content)
    assert sent["content_type"] == "tool_call"
    assert sent["action"] == "call_tool"
    assert sent["tool"]["name"] == "shell"
    assert sent["tool"]["arguments"]["cmd"] == "ls -la"


@respx.mock
def test_tool_name_override():
    route = _guard_route(respx.mock, _ALLOW_BODY)
    s = _shield()

    @s.tool(tool_name="custom_shell")
    def shell(cmd: str) -> str:
        return "ok"

    shell("ls")

    sent = json.loads(route.calls.last.request.content)
    assert sent["tool"]["name"] == "custom_shell"


# ---------------------------------------------------------------------------
# @shield.toolresponse — sync
# ---------------------------------------------------------------------------


@respx.mock
def test_toolresponse_allow():
    _guard_route(respx.mock, _ALLOW_BODY)
    s = _shield()

    @s.toolresponse
    def fetch_page(url: str) -> str:
        return "<html>safe content</html>"

    result = fetch_page("http://example.com")
    assert result == "<html>safe content</html>"


@respx.mock
def test_toolresponse_deny_raises():
    """Function runs but return value is blocked."""
    _guard_route(respx.mock, _DENY_BODY)
    s = _shield()
    called = []

    @s.toolresponse
    def fetch_page(url: str) -> str:
        called.append(True)
        return "secret: abc123"

    with pytest.raises(ShieldBlockedError):
        fetch_page("http://example.com")

    assert called == [True], "function MUST run before guarding the response"


@respx.mock
def test_toolresponse_sends_response_body():
    route = _guard_route(respx.mock, _ALLOW_BODY)
    s = _shield()

    @s.toolresponse
    def fetch_page(url: str) -> str:
        return "page content"

    fetch_page("http://example.com")

    sent = json.loads(route.calls.last.request.content)
    assert sent["content"] == "page content"
    assert sent["content_type"] == "response"
    assert sent["action"] == "call_tool"


# ---------------------------------------------------------------------------
# @shield.modelresponse — sync
# ---------------------------------------------------------------------------


@respx.mock
def test_modelresponse_allow():
    _guard_route(respx.mock, _ALLOW_BODY)
    s = _shield()

    @s.modelresponse
    def generate(prompt: str) -> str:
        return "France is the capital of Paris"

    result = generate("capital of France?")
    assert result == "France is the capital of Paris"


@respx.mock
def test_modelresponse_deny_raises():
    _guard_route(respx.mock, _DENY_BODY)
    s = _shield()

    @s.modelresponse
    def generate(prompt: str) -> str:
        return "toxic response"

    with pytest.raises(ShieldBlockedError):
        generate("something")


@respx.mock
def test_modelresponse_sends_correct_body():
    route = _guard_route(respx.mock, _ALLOW_BODY)
    s = _shield()

    @s.modelresponse
    def generate(prompt: str) -> str:
        return "the answer"

    generate("question")

    sent = json.loads(route.calls.last.request.content)
    assert sent["content"] == "the answer"
    assert sent["content_type"] == "response"
    assert sent["action"] == "process_prompt"


# ---------------------------------------------------------------------------
# @shield(content_type=..., action=...) — generic
# ---------------------------------------------------------------------------


@respx.mock
def test_generic_allow():
    _guard_route(respx.mock, _ALLOW_BODY)
    s = _shield()

    @s(content_type="file", action="write_file", content_arg="content")
    def write_config(path: str, content: str) -> None:
        pass

    write_config(path="/etc/cfg", content="key=value")


@respx.mock
def test_generic_deny_raises():
    _guard_route(respx.mock, _DENY_BODY)
    s = _shield()

    @s(content_type="file", action="write_file", content_arg="content")
    def write_config(path: str, content: str) -> None:
        pass

    with pytest.raises(ShieldBlockedError):
        write_config(path="/etc/cfg", content="secret: xyz")


@respx.mock
def test_generic_sends_correct_body():
    route = _guard_route(respx.mock, _ALLOW_BODY)
    s = _shield()

    @s(content_type="file", action="write_file", content_arg="content")
    def write_config(path: str, content: str) -> None:
        pass

    write_config(path="/etc/cfg", content="key=value")

    sent = json.loads(route.calls.last.request.content)
    assert sent["content"] == "key=value"
    assert sent["content_type"] == "file"
    assert sent["action"] == "write_file"


# ---------------------------------------------------------------------------
# Async variants
# ---------------------------------------------------------------------------


@respx.mock
@pytest.mark.asyncio
async def test_async_prompt_allow():
    _guard_route(respx.mock, _ALLOW_BODY)
    s = _shield()

    @s.prompt
    async def async_chat(message: str) -> str:
        return "async ok"

    result = await async_chat("hello")
    assert result == "async ok"


@respx.mock
@pytest.mark.asyncio
async def test_async_prompt_deny():
    _guard_route(respx.mock, _DENY_BODY)
    s = _shield()
    called = []

    @s.prompt
    async def async_chat(message: str) -> str:
        called.append(True)
        return "ok"

    with pytest.raises(ShieldBlockedError):
        await async_chat("bad content")

    assert called == []


@respx.mock
@pytest.mark.asyncio
async def test_async_tool_deny():
    _guard_route(respx.mock, _DENY_BODY)
    s = _shield()
    called = []

    @s.tool
    async def shell(cmd: str) -> str:
        called.append(True)
        return "output"

    with pytest.raises(ShieldBlockedError):
        await shell("rm -rf /")

    assert called == []


@respx.mock
@pytest.mark.asyncio
async def test_async_toolresponse_deny():
    _guard_route(respx.mock, _DENY_BODY)
    s = _shield()
    called = []

    @s.toolresponse
    async def fetch(url: str) -> str:
        called.append(True)
        return "secret: abc"

    with pytest.raises(ShieldBlockedError):
        await fetch("http://example.com")

    assert called == [True], "async fetch MUST run before guarding response"


@respx.mock
@pytest.mark.asyncio
async def test_async_modelresponse_deny():
    _guard_route(respx.mock, _DENY_BODY)
    s = _shield()

    @s.modelresponse
    async def generate(prompt: str) -> str:
        return "toxic output"

    with pytest.raises(ShieldBlockedError):
        await generate("question")


# ---------------------------------------------------------------------------
# ShieldBlockedError — response accessible on exception
# ---------------------------------------------------------------------------


@respx.mock
def test_blocked_error_has_response():
    _guard_route(respx.mock, _DENY_BODY)
    s = _shield()

    @s.prompt
    def chat(message: str) -> str:
        return "ok"

    with pytest.raises(ShieldBlockedError) as exc_info:
        chat("bad")

    err = exc_info.value
    assert err.response.decision == "deny"
    assert err.response.reason == "secrets detected"
    assert err.response.denied is True


# ---------------------------------------------------------------------------
# Function not called on pre-deny (side-effect counter)
# ---------------------------------------------------------------------------


@respx.mock
def test_function_not_called_on_deny():
    _guard_route(respx.mock, _DENY_BODY)
    s = _shield()
    call_count = 0

    @s.prompt
    def expensive(msg: str) -> str:
        nonlocal call_count
        call_count += 1
        return "result"

    with pytest.raises(ShieldBlockedError):
        expensive("trigger deny")

    assert call_count == 0


# ---------------------------------------------------------------------------
# functools.wraps — metadata preserved
# ---------------------------------------------------------------------------


def test_functools_wraps_preserved():
    s = Shield(ShieldClient(base_url=BASE_URL, api_key=API_KEY))

    @s.prompt
    def my_function(message: str) -> str:
        """My docstring."""
        return "ok"

    assert my_function.__name__ == "my_function"
    assert my_function.__doc__ == "My docstring."


def test_functools_wraps_preserved_tool():
    s = Shield(ShieldClient(base_url=BASE_URL, api_key=API_KEY))

    @s.tool
    def my_tool(cmd: str) -> str:
        """Tool docstring."""
        return "ok"

    assert my_tool.__name__ == "my_tool"
    assert my_tool.__doc__ == "Tool docstring."


# ---------------------------------------------------------------------------
# Generic __call__ guard — must require keyword args
# ---------------------------------------------------------------------------


def test_generic_requires_keyword_args():
    """Calling shield() without content_type/action raises TypeError.

    Python enforces this because content_type and action are required
    keyword-only arguments — no callable passes through without them.
    """
    s = Shield(ShieldClient(base_url=BASE_URL, api_key=API_KEY))
    with pytest.raises(TypeError):
        s(lambda: None)  # type: ignore[call-arg]
