"""AtlasBridge Operator Console — single-command process management TUI."""
