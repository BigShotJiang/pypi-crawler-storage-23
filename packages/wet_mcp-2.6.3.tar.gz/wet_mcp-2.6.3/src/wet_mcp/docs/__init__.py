"""Docs package for WET MCP Server."""
