"""vizpy - A state of the art prompt optimization library."""

__version__ = "0.1.1"

__all__ = ["__version__"]
