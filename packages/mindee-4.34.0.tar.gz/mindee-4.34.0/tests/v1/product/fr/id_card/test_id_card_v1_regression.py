import pytest

from mindee.client import Client
from mindee.product.fr.id_card.id_card_v1 import IdCardV1
from tests.utils import V1_PRODUCT_DATA_DIR
from tests.v1.product import get_id, get_version


@pytest.mark.regression
def test_default_sample():
    client = Client()
    with open(
        V1_PRODUCT_DATA_DIR / "idcard_fr" / "response_v1" / "default_sample.rst",
        encoding="utf-8",
    ) as rst_file:
        rst_ref = rst_file.read()

    sample = client.source_from_path(
        V1_PRODUCT_DATA_DIR / "idcard_fr" / "default_sample.jpg",
    )
    response = client.parse(IdCardV1, sample)
    doc_response = response.document
    doc_response.id = get_id(rst_ref)
    doc_response.inference.product.version = get_version(rst_ref)
    assert str(doc_response) == rst_ref
