from mindee.v2.parsing.inference.base_inference import BaseInference
from mindee.v2.parsing.inference.base_response import (
    BaseResponse,
)

__all__ = [
    "BaseInference",
    "BaseResponse",
]
