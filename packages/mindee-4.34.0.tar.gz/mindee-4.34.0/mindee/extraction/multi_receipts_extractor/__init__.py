from mindee.extraction.multi_receipts_extractor import multi_receipts_extractor

__all__ = ["multi_receipts_extractor"]
