from mindee.product.driver_license.driver_license_v1 import DriverLicenseV1
from mindee.product.driver_license.driver_license_v1_document import (
    DriverLicenseV1Document,
)

__all__ = [
    "DriverLicenseV1",
    "DriverLicenseV1Document",
]
