import warnings
from time import sleep
from typing import Optional, Union, Type, TypeVar

from mindee.client_mixin import ClientMixin
from mindee.error.mindee_error import MindeeError
from mindee.error.mindee_http_error_v2 import handle_error_v2
from mindee.input import UrlInputSource, BaseParameters
from mindee.input.inference_parameters import InferenceParameters
from mindee.input.polling_options import PollingOptions
from mindee.input.sources.local_input_source import LocalInputSource
from mindee.logger import logger
from mindee.mindee_http.mindee_api_v2 import MindeeApiV2
from mindee.mindee_http.response_validation_v2 import (
    is_valid_get_response,
    is_valid_post_response,
)
from mindee.parsing.v2.common_response import CommonStatus
from mindee.v2.parsing.inference.base_response import BaseResponse
from mindee.parsing.v2.inference_response import InferenceResponse
from mindee.parsing.v2.job_response import JobResponse

TypeBaseResponse = TypeVar("TypeBaseResponse", bound=BaseResponse)


class ClientV2(ClientMixin):
    """
    Mindee API Client.

    See: https://developers.mindee.com/docs/
    """

    api_key: Optional[str]
    mindee_api: MindeeApiV2

    def __init__(self, api_key: Optional[str] = None) -> None:
        """
        Mindee API Client.

        :param api_key: Your API key for all endpoints
        """
        self.api_key = api_key
        self.mindee_api = MindeeApiV2(api_key)

    def enqueue_inference(
        self,
        input_source: Union[LocalInputSource, UrlInputSource],
        params: BaseParameters,
        disable_redundant_warnings: bool = False,
    ) -> JobResponse:
        """[Deprecated] Use `enqueue` instead."""
        if not disable_redundant_warnings:
            warnings.warn(
                "enqueue_inference is deprecated; use enqueue instead",
                DeprecationWarning,
                stacklevel=2,
            )
        return self.enqueue(input_source, params)

    def enqueue(
        self,
        input_source: Union[LocalInputSource, UrlInputSource],
        params: BaseParameters,
    ) -> JobResponse:
        """
        Enqueues a document to a given model.

        :param input_source: The document/source file to use. Can be local or remote.
        :param params: Parameters to set when sending a file.

        :return: A valid inference response.
        """
        logger.debug("Enqueuing inference using model: %s", params.model_id)
        response = self.mindee_api.req_post_inference_enqueue(
            input_source=input_source, params=params, slug=params.get_enqueue_slug()
        )
        dict_response = response.json()

        if not is_valid_post_response(response):
            handle_error_v2(dict_response)
        return JobResponse(dict_response)

    def get_job(self, job_id: str) -> JobResponse:
        """
        Get the status of an inference that was previously enqueued.

        Can be used for polling.

        :param job_id: UUID of the job to retrieve.
        :return: A job response.
        """
        logger.debug("Fetching job: %s", job_id)

        response = self.mindee_api.req_get_job(job_id)
        if not is_valid_get_response(response):
            handle_error_v2(response.json())
        dict_response = response.json()
        return JobResponse(dict_response)

    def get_inference(
        self,
        inference_id: str,
    ) -> BaseResponse:
        """[Deprecated] Use `get_result` instead."""
        return self.get_result(InferenceResponse, inference_id)

    def get_result(
        self,
        response_type: Type[TypeBaseResponse],
        inference_id: str,
    ) -> TypeBaseResponse:
        """
        Get the result of an inference that was previously enqueued.

        The inference will only be available after it has finished processing.

        :param inference_id: UUID of the inference to retrieve.
        :param response_type: Class of the product to instantiate.
        :return: An inference response.
        """
        logger.debug("Fetching result: %s", inference_id)

        response = self.mindee_api.req_get_inference(
            inference_id, response_type.get_result_slug()
        )
        if not is_valid_get_response(response):
            handle_error_v2(response.json())
        dict_response = response.json()
        return response_type(dict_response)

    def enqueue_and_get_result(
        self,
        response_type: Type[TypeBaseResponse],
        input_source: Union[LocalInputSource, UrlInputSource],
        params: BaseParameters,
    ) -> TypeBaseResponse:
        """
        Enqueues to an asynchronous endpoint and automatically polls for a response.

        :param input_source: The document/source file to use. Can be local or remote.
        :param params: Parameters to set when sending a file.
        :param response_type: The product class to use for the response object.

        :return: A valid inference response.
        """
        if not params.polling_options:
            params.polling_options = PollingOptions()
        self._validate_async_params(
            params.polling_options.initial_delay_sec,
            params.polling_options.delay_sec,
            params.polling_options.max_retries,
        )
        enqueue_response = self.enqueue_inference(input_source, params, True)
        logger.debug(
            "Successfully enqueued document with job ID: %s", enqueue_response.job.id
        )
        sleep(params.polling_options.initial_delay_sec)
        try_counter = 0
        while try_counter < params.polling_options.max_retries:
            job_response = self.get_job(enqueue_response.job.id)
            assert isinstance(job_response, JobResponse)
            if job_response.job.status == CommonStatus.FAILED.value:
                if job_response.job.error:
                    detail = job_response.job.error.detail
                else:
                    detail = "No error detail available."
                raise MindeeError(
                    f"Parsing failed for job {job_response.job.id}: {detail}"
                )
            if job_response.job.status == CommonStatus.PROCESSED.value:
                logger.debug(
                    "Job ID %s completed processing at: %s",
                    job_response.job.id,
                    job_response.job.completed_at,
                )
                result = self.get_result(
                    response_type or InferenceResponse, job_response.job.id
                )
                assert isinstance(result, response_type), (
                    f'Invalid response type "{type(result)}"'
                )
                return result
            try_counter += 1
            sleep(params.polling_options.delay_sec)

        raise MindeeError(f"Couldn't retrieve document after {try_counter + 1} tries.")

    def enqueue_and_get_inference(
        self,
        input_source: Union[LocalInputSource, UrlInputSource],
        params: InferenceParameters,
    ) -> InferenceResponse:
        """[Deprecated] Use `enqueue_and_get_result` instead."""
        warnings.warn(
            "enqueue_and_get_inference is deprecated; use enqueue_and_get_result instead",
            DeprecationWarning,
            stacklevel=2,
        )
        response = self.enqueue_and_get_result(InferenceResponse, input_source, params)
        assert isinstance(response, InferenceResponse), (
            f'Invalid response type "{type(response)}"'
        )
        return response
