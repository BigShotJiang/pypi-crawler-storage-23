from typing import Any, Dict

StringDict = Dict[str, Any]
"""Basic JSON-compliant python dictionary."""
