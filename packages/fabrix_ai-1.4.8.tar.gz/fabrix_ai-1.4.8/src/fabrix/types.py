from __future__ import annotations

from typing import Any, Literal

type JSONDict = dict[str, Any]
type ReasoningEffort = Literal["low", "medium", "high"]
