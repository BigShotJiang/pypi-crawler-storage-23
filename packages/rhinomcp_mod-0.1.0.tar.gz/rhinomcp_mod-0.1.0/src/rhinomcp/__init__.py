"""Rhino integration through the Model Context Protocol."""

__version__ = "0.1.0"

# Expose key classes and functions for easier imports
from .static.rhinoscriptsyntax import rhinoscriptsyntax_json
from .server import RhinoConnection, get_rhino_connection, mcp, logger

from .prompts.assert_general_strategy import asset_general_strategy

from .tools.create_objects import create_objects
from .tools.copy_objects import copy_objects
from .tools.delete_objects import delete_objects
from .tools.get_document_info import get_document_info
from .tools.get_object_info import get_object_info
from .tools.get_objects_info import get_objects_info
from .tools.get_connectivity_graph import get_connectivity_graph
from .tools.modify_objects import modify_objects
from .tools.invert_rotation_matrix import invert_rotation_matrix
from .tools.rotate_objects import rotate_objects
from .tools.reset_objects_pose import reset_objects_pose
from .tools.rebase_objects_pose import rebase_objects_pose
# from .tools.get_rhinoscript_python_function_names import get_rhinoscript_python_function_names
# from .tools.get_rhinoscript_python_code_guide import get_rhinoscript_python_code_guide
# from .tools.execute_rhinoscript_python_code import execute_rhinoscript_python_code
from .tools.create_layer import create_layer
from .tools.get_or_set_current_layer import get_or_set_current_layer
from .tools.delete_layer import delete_layer
