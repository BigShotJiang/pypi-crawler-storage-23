"""MCP server extension for Metaxy."""

from metaxy.ext.mcp.server import create_server, mcp, run_server

__all__ = ["create_server", "mcp", "run_server"]
