"""
Empty setup.py for get_terminal_size
Target: HackerOne Bug Bounty - Meta (Facebook)
"""
from setuptools import setup

setup(
    name="get_terminal_size",
    version="0.0.0",
    description="Empty placeholder package - reserved for Meta (Facebook)",
    author="Package Protector",
    author_email="protector@example.com",
    py_modules=[],
)
