"""jsonld-ex MCP server package."""

from jsonld_ex.mcp.server import mcp

__all__ = ["mcp"]
