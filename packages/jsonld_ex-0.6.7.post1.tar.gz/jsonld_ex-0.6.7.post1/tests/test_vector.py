"""Tests for vector extensions — edge cases."""

import math
import pytest
from jsonld_ex.vector import (
    vector_term_definition, validate_vector, cosine_similarity,
    extract_vectors, strip_vectors_for_rdf,
)


class TestVectorTermDefinition:
    def test_basic(self):
        defn = vector_term_definition("embedding", "http://ex.org/embedding", 768)
        assert defn["embedding"]["@container"] == "@vector"
        assert defn["embedding"]["@dimensions"] == 768

    def test_no_dimensions(self):
        defn = vector_term_definition("emb", "http://ex.org/emb")
        assert "@dimensions" not in defn["emb"]

    def test_zero_dimensions(self):
        with pytest.raises(ValueError):
            vector_term_definition("emb", "http://ex.org/emb", 0)

    def test_negative_dimensions(self):
        with pytest.raises(ValueError):
            vector_term_definition("emb", "http://ex.org/emb", -5)

    def test_bool_dimensions_rejected(self):
        with pytest.raises(ValueError):
            vector_term_definition("emb", "http://ex.org/emb", True)

    def test_float_dimensions_rejected(self):
        with pytest.raises(ValueError):
            vector_term_definition("emb", "http://ex.org/emb", 3.5)


class TestValidateVector:
    def test_valid(self):
        ok, errors = validate_vector([1.0, 2.0, 3.0])
        assert ok
        assert errors == []

    def test_with_dimensions(self):
        ok, errors = validate_vector([1.0, 2.0], expected_dimensions=2)
        assert ok

    def test_dimension_mismatch(self):
        ok, errors = validate_vector([1.0, 2.0], expected_dimensions=3)
        assert not ok
        assert "mismatch" in errors[0]

    def test_empty_vector(self):
        ok, errors = validate_vector([])
        assert not ok
        assert "empty" in errors[0].lower()

    def test_not_a_list(self):
        ok, errors = validate_vector("not a vector")
        assert not ok

    def test_nan_element(self):
        ok, errors = validate_vector([1.0, float("nan"), 3.0])
        assert not ok
        assert "[1]" in errors[0]

    def test_inf_element(self):
        ok, errors = validate_vector([float("inf"), 2.0])
        assert not ok

    def test_bool_element_rejected(self):
        ok, errors = validate_vector([True, False, 1.0])
        assert not ok
        assert "[0]" in errors[0]

    def test_string_element(self):
        ok, errors = validate_vector([1.0, "bad", 3.0])
        assert not ok

    def test_tuple_input(self):
        ok, errors = validate_vector((1.0, 2.0, 3.0))
        assert ok

    def test_integers_valid(self):
        ok, errors = validate_vector([1, 2, 3])
        assert ok


class TestCosineSimilarity:
    def test_identical(self):
        assert cosine_similarity([1.0, 0.0], [1.0, 0.0]) == pytest.approx(1.0)

    def test_orthogonal(self):
        assert cosine_similarity([1.0, 0.0], [0.0, 1.0]) == pytest.approx(0.0)

    def test_opposite(self):
        assert cosine_similarity([1.0, 0.0], [-1.0, 0.0]) == pytest.approx(-1.0)

    def test_dimension_mismatch(self):
        with pytest.raises(ValueError, match="mismatch"):
            cosine_similarity([1.0, 2.0], [1.0])

    def test_empty_vectors(self):
        with pytest.raises(ValueError, match="empty"):
            cosine_similarity([], [])

    def test_zero_vector_raises(self):
        with pytest.raises(ValueError, match="zero-magnitude"):
            cosine_similarity([0.0, 0.0], [1.0, 2.0])

    def test_nan_raises(self):
        with pytest.raises(ValueError, match="finite"):
            cosine_similarity([float("nan"), 1.0], [1.0, 1.0])

    def test_inf_raises(self):
        with pytest.raises(ValueError, match="finite"):
            cosine_similarity([1.0, 1.0], [float("inf"), 1.0])

    def test_bool_raises(self):
        with pytest.raises(TypeError, match="number"):
            cosine_similarity([True, 1.0], [1.0, 1.0])


class TestExtractVectors:
    def test_basic(self):
        node = {"name": "test", "embedding": [1.0, 2.0, 3.0]}
        result = extract_vectors(node, ["embedding"])
        assert result == {"embedding": [1.0, 2.0, 3.0]}

    def test_missing_property(self):
        result = extract_vectors({"name": "test"}, ["embedding"])
        assert result == {}

    def test_non_dict(self):
        assert extract_vectors("not a dict", ["embedding"]) == {}

    def test_non_numeric_list(self):
        node = {"tags": ["a", "b", "c"]}
        result = extract_vectors(node, ["tags"])
        assert result == {}


class TestMultiEmbeddingDocuments:
    """GAP-MM2: Multiple embeddings per node."""

    def test_multiple_vector_term_definitions(self):
        ctx = {}
        ctx.update(vector_term_definition("text_embedding", "http://ex.org/textEmb", 3))
        ctx.update(vector_term_definition("image_embedding", "http://ex.org/imgEmb", 4))
        assert "text_embedding" in ctx
        assert "image_embedding" in ctx
        assert ctx["text_embedding"]["@dimensions"] == 3
        assert ctx["image_embedding"]["@dimensions"] == 4

    def test_extract_multiple_vectors(self):
        node = {
            "@id": "http://example.org/product/1",
            "text_embedding": [0.1, 0.2, 0.3],
            "image_embedding": [0.4, 0.5, 0.6, 0.7],
            "name": "Widget",
        }
        vectors = extract_vectors(node, ["text_embedding", "image_embedding"])
        assert len(vectors) == 2
        assert vectors["text_embedding"] == [0.1, 0.2, 0.3]
        assert vectors["image_embedding"] == [0.4, 0.5, 0.6, 0.7]

    def test_validate_multiple_vectors(self):
        node = {
            "text_embedding": [0.1, 0.2, 0.3],
            "image_embedding": [0.4, 0.5, 0.6, 0.7],
        }
        ok1, errs1 = validate_vector(node["text_embedding"], expected_dimensions=3)
        ok2, errs2 = validate_vector(node["image_embedding"], expected_dimensions=4)
        assert ok1 is True and errs1 == []
        assert ok2 is True and errs2 == []

    def test_strip_preserves_other_vectors(self):
        """Stripping one vector property leaves others intact."""
        node = {
            "@id": "http://example.org/x",
            "text_embedding": [0.1, 0.2],
            "image_embedding": [0.3, 0.4],
            "name": "test",
        }
        stripped = strip_vectors_for_rdf(node, ["text_embedding"])
        assert "text_embedding" not in stripped
        assert stripped["image_embedding"] == [0.3, 0.4]
        assert stripped["name"] == "test"

    def test_cosine_similarity_between_modalities(self):
        """Cross-modal similarity still works as plain vectors."""
        # Same-dimension vectors from different modalities
        text_vec = [1.0, 0.0, 0.0]
        img_vec = [0.0, 1.0, 0.0]
        sim = cosine_similarity(text_vec, img_vec)
        assert sim == pytest.approx(0.0, abs=1e-9)


class TestStripVectorsForRdf:
    def test_removes_vectors(self):
        doc = {"@type": "Product", "name": "Widget", "embedding": [1.0, 2.0]}
        result = strip_vectors_for_rdf(doc, ["embedding"])
        assert "embedding" not in result
        assert result["name"] == "Widget"

    def test_nested_graph(self):
        doc = {"@graph": [{"embedding": [1.0], "name": "A"}]}
        result = strip_vectors_for_rdf(doc, ["embedding"])
        assert "embedding" not in result["@graph"][0]

    def test_preserves_non_vector(self):
        doc = {"name": "test", "age": 30}
        result = strip_vectors_for_rdf(doc, ["embedding"])
        assert result == doc

    def test_list_input(self):
        docs = [{"embedding": [1.0]}, {"embedding": [2.0]}]
        result = strip_vectors_for_rdf(docs, ["embedding"])
        assert all("embedding" not in d for d in result)

    def test_scalar_passthrough(self):
        assert strip_vectors_for_rdf("hello", ["embedding"]) == "hello"


# ── @similarity in term definitions (Step 4) ────────────────────────────


class TestVectorTermDefinitionSimilarity:
    """The optional *similarity* parameter stores a ``@similarity`` key
    in the term definition.  It is purely declarative metadata —
    validation against the metric registry happens at use-time, not
    at definition-time.
    """

    def test_similarity_omitted_by_default(self):
        defn = vector_term_definition("emb", "http://ex.org/emb", 768)
        assert "@similarity" not in defn["emb"]

    def test_similarity_none_omits_key(self):
        defn = vector_term_definition("emb", "http://ex.org/emb", similarity=None)
        assert "@similarity" not in defn["emb"]

    def test_similarity_stored(self):
        defn = vector_term_definition(
            "emb", "http://ex.org/emb", 768, similarity="cosine"
        )
        assert defn["emb"]["@similarity"] == "cosine"

    def test_similarity_euclidean(self):
        defn = vector_term_definition(
            "emb", "http://ex.org/emb", similarity="euclidean"
        )
        assert defn["emb"]["@similarity"] == "euclidean"

    def test_similarity_custom_name(self):
        """Any non-empty string is accepted — not validated at
        definition time so users can register the metric later."""
        defn = vector_term_definition(
            "emb", "http://ex.org/emb", similarity="my_custom_metric"
        )
        assert defn["emb"]["@similarity"] == "my_custom_metric"

    def test_similarity_empty_string_raises(self):
        with pytest.raises(ValueError, match="similarity"):
            vector_term_definition(
                "emb", "http://ex.org/emb", similarity=""
            )

    def test_similarity_whitespace_raises(self):
        with pytest.raises(ValueError, match="similarity"):
            vector_term_definition(
                "emb", "http://ex.org/emb", similarity="   "
            )

    def test_similarity_non_string_raises(self):
        with pytest.raises(TypeError, match="similarity"):
            vector_term_definition(
                "emb", "http://ex.org/emb", similarity=42
            )

    def test_similarity_coexists_with_dimensions(self):
        defn = vector_term_definition(
            "emb", "http://ex.org/emb", 768, similarity="dot_product"
        )
        assert defn["emb"]["@dimensions"] == 768
        assert defn["emb"]["@similarity"] == "dot_product"
        assert defn["emb"]["@container"] == "@vector"

    def test_backwards_compat_positional_args(self):
        """Existing callers using positional args must not break."""
        defn = vector_term_definition("emb", "http://ex.org/emb", 768)
        assert defn["emb"]["@container"] == "@vector"
        assert defn["emb"]["@dimensions"] == 768
        assert "@similarity" not in defn["emb"]
