"""Configuration module for Amazon Ads API MCP server.

This module contains configuration management for the Amazon Ads MCP server,
including settings, environment variables, and configuration validation.
"""
