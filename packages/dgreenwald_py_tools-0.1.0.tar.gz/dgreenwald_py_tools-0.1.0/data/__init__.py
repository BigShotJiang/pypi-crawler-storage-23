"""Data handling utilities package."""

from . import collapser, core, match
from .core import *  # noqa: F401,F403

__all__ = ("core", "collapser", "match")
