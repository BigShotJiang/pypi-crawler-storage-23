"""Configuration package."""

__all__ = ("registry", "modspec")
