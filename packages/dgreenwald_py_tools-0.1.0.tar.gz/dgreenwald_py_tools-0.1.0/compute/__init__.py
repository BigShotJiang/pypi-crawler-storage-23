"""Parallel and high-performance computing helpers."""

__all__ = ("mpi_array",)
