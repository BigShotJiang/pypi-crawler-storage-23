"""Web data acquisition package."""

__all__ = ("scrape",)
