"""Statistical tools package."""

from . import core, inequality, walker
from .core import *  # noqa: F401,F403

__all__ = ("core", "inequality", "walker")
