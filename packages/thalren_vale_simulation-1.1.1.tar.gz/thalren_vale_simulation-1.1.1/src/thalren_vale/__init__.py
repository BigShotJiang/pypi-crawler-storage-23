# (c) 2026 (KriaetvAspie / AspieTheBard)
# Licensed under the Polyform Noncommercial License 1.0.0
"""thalren_vale — Emergent AI Civilization Simulator package."""

__version__ = "1.0.0"
__author__  = "(KriaetvAspie / AspieTheBard)"
