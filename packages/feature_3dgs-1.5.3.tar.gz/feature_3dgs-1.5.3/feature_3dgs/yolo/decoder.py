import torch
import torch.nn as nn

from feature_3dgs.decoder import NoopFeatureDecoder


class YOLODecoder(NoopFeatureDecoder):
    pass  # TODO
