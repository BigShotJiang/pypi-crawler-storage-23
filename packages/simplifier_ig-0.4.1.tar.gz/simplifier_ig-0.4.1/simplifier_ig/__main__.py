"""Allow running with ``python -m simplifier_ig``."""

import sys

from .cli import main

sys.exit(main())
