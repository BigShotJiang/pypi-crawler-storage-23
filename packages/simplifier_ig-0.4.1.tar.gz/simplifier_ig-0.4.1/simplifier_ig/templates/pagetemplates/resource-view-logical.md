---
topic: resource-view-logical
---

## Views of Logical Model Content

<tabs>
	<tab title="Tree view">
		{{tree}}
	</tab>
    <tab title="Detailed Descriptions">
        {{dict}}
    </tab>
    <tab title="XML">
        {{xml}}
    </tab>
    <tab title="JSON">
        {{json}}
    </tab>
    <tab title="Examples">
        {{page:FQL-get-examples}}
    </tab>
</tabs>