---
topic: fql-get-resource-copyright
---
<fql output="inline">
    for Resource
    where url=%canonical
    select copyright
</fql>