---
topic: fql-get-resource-name
---
<fql output="inline">
    for Resource
    where url=%canonical
    select name
</fql>