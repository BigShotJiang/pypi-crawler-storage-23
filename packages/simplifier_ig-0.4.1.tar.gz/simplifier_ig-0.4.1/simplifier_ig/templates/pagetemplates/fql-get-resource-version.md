---
topic: fql-get-resource-version
---
<fql output="inline">
    for Resource
    where url=%canonical
    select version
</fql>