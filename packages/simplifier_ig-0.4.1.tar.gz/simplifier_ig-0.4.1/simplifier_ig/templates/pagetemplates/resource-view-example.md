---
topic: resource-view-example
---

<tabs>
	<tab  title="JSON view">
       {{json}}
	</tab>
	<tab title="XML view">
      {{xml}}
	</tab>
	<tab title="Tree view">
      {{tree}}
	</tab>
	<tab title="Table view">
      {{table}}
	</tab>
</tabs>

