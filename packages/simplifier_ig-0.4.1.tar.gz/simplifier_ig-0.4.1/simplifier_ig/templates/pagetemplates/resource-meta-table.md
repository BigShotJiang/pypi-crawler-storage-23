---
topic: resource-meta-table
---
<table class="table meta-table">
  <tr>
    <td colspan="2">
      <i>Official URL:</i> <code>{{variable:canonical}}</code>
    </td>
    <td>
      <i>Version:</i> {{variable:guide-version}}
    </td>
  </tr>
  <tr>
    <td colspan="2">
      <i>Parent:</i> {{page:FQL-get-resource-base}}
    </td>
    <td>
      <i>Computable Name:</i> {{page:FQL-get-resource-name}}
    </td>
  </tr>
</table>