---
topic: fql-get-resource-date
---
<fql output="inline">
    for Resource
    where url=%canonical
    select date
</fql>