---
topic: messagedefinition-{{ig-var: file-name }}
canonical: {{ig-var: MessageDefinition.url }}
expand: 2
---

## {{page-title}}

  {{page:Resource-Meta-Table}}
  
  {{page:FQL-get-resource-description}}

  {{page:resource-view-render}}
