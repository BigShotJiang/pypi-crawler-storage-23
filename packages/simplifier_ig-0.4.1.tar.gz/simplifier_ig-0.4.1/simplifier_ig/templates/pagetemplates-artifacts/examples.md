---
topic: example-{{ig-var: file-name }}
subject: {{ig-var: ResourceType/Resource.id }}
expand: yes
---

## {{page-title}}

{{page:Resource-View-Example}}

