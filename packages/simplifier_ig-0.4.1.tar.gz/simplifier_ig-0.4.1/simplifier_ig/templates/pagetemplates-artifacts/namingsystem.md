---
topic: namingsystem-{{ig-var: file-name }}
expand: 2
---

## {{page-title}}

  {{page:Resource-Meta-Table}}
  
  {{page:FQL-get-resource-description}}

  {{page:resource-view-render}}
