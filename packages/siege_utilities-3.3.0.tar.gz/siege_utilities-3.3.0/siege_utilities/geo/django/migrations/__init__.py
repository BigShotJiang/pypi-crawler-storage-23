"""Django migrations for siege_utilities.geo.django models."""
