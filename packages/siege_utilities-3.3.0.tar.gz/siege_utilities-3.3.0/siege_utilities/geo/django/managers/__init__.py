"""
Custom managers for Census boundary models.
"""

from .boundary_manager import BoundaryManager, BoundaryQuerySet

__all__ = ["BoundaryManager", "BoundaryQuerySet"]
