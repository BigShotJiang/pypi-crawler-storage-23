"""CLI applications for appif connectors."""
