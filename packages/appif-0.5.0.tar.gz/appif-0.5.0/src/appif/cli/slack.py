"""Slack CLI — connect to a Slack workspace and view messages.

Uses the existing SlackConnector adapter with typer for CLI structure
and rich for terminal formatting. All Slack-specific logic lives in
the adapter; this module is a thin presentation shell.

Usage:
    appif-slack status
    appif-slack accounts
    appif-slack channels
    appif-slack messages --channel C0123ABC --since 2h
    appif-slack listen
"""

from __future__ import annotations

import re
import signal
import threading
from datetime import UTC, datetime, timedelta
from typing import Annotated

import typer
from rich.console import Console
from rich.live import Live
from rich.panel import Panel
from rich.table import Table

from appif.adapters.slack import SlackConnector
from appif.domain.messaging.errors import ConnectorError, NotAuthorized, TargetUnavailable
from appif.domain.messaging.models import (
    BackfillScope,
    MessageEvent,
)

app = typer.Typer(
    name="appif-slack",
    help="Connect to a Slack workspace and view messages meant for you.",
    no_args_is_help=True,
    rich_markup_mode="rich",
)

console = Console()
err_console = Console(stderr=True)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _build_connector() -> SlackConnector:
    """Construct and return a SlackConnector (does not connect yet)."""
    try:
        return SlackConnector()
    except NotAuthorized as exc:
        err_console.print(
            Panel(
                f"[bold red]Authentication failed[/bold red]\n\n{exc}\n\n"
                "Set APPIF_SLACK_BOT_OAUTH_TOKEN and APPIF_SLACK_BOT_APP_LEVEL_TOKEN\n"
                "in ~/.env or as environment variables.",
                title="Missing Credentials",
                border_style="red",
            )
        )
        raise typer.Exit(code=1) from exc


def _connect(connector: SlackConnector) -> None:
    """Connect and handle errors with rich output."""
    try:
        with console.status("[bold cyan]Connecting to Slack...[/bold cyan]"):
            connector.connect()
    except NotAuthorized as exc:
        err_console.print(Panel(f"[bold red]Not authorized:[/bold red] {exc}", border_style="red"))
        raise typer.Exit(code=1) from exc
    except ConnectorError as exc:
        err_console.print(Panel(f"[bold red]Connection failed:[/bold red] {exc}", border_style="red"))
        raise typer.Exit(code=1) from exc


def _connected_connector() -> SlackConnector:
    """Build, connect, and return a ready connector."""
    connector = _build_connector()
    _connect(connector)
    return connector


def _parse_since(value: str) -> datetime:
    """Parse a human-friendly duration string into a UTC datetime.

    Accepts patterns like '2h', '30m', '1d', '7d', or ISO timestamps.
    """
    match = re.fullmatch(r"(\d+)\s*([mhd])", value.strip().lower())
    if match:
        amount = int(match.group(1))
        unit = match.group(2)
        delta = {"m": timedelta(minutes=amount), "h": timedelta(hours=amount), "d": timedelta(days=amount)}[unit]
        return datetime.now(tz=UTC) - delta

    # Try ISO format
    try:
        return datetime.fromisoformat(value).astimezone(UTC)
    except ValueError as exc:
        err_console.print(f"[red]Cannot parse --since value:[/red] {value!r}")
        err_console.print("Use a duration like '2h', '30m', '1d' or an ISO timestamp.")
        raise typer.Exit(code=1) from exc


def _format_timestamp(ts: datetime) -> str:
    """Format a datetime for table display."""
    local_ts = ts.astimezone()
    return local_ts.strftime("%Y-%m-%d %H:%M:%S")


def _truncate(text: str, max_len: int = 80) -> str:
    """Truncate text for table display."""
    if len(text) <= max_len:
        return text
    return text[: max_len - 3] + "..."


# ---------------------------------------------------------------------------
# Commands
# ---------------------------------------------------------------------------


@app.command()
def status():
    """Show connector status and capabilities."""
    connector = _build_connector()
    caps = connector.get_capabilities()
    current_status = connector.get_status()

    table = Table(title="Slack Connector Status", show_header=False, border_style="cyan")
    table.add_column("Property", style="bold")
    table.add_column("Value")

    table.add_row("Status", current_status.value)
    table.add_row("Real-time", "[green]Yes[/green]" if caps.supports_realtime else "[red]No[/red]")
    table.add_row("Backfill", "[green]Yes[/green]" if caps.supports_backfill else "[red]No[/red]")
    table.add_row("Threads", "[green]Yes[/green]" if caps.supports_threads else "[red]No[/red]")
    table.add_row("Reply", "[green]Yes[/green]" if caps.supports_reply else "[red]No[/red]")
    table.add_row("Auto-send", "[green]Yes[/green]" if caps.supports_auto_send else "[red]No[/red]")
    table.add_row("Delivery Mode", caps.delivery_mode)

    console.print(table)


@app.command()
def connect():
    """Authenticate and connect to the Slack workspace."""
    connector = _connected_connector()

    accounts = connector.list_accounts()
    if accounts:
        acct = accounts[0]
        console.print(
            Panel(
                f"[bold green]Connected[/bold green] to workspace "
                f"[bold]{acct.display_name}[/bold] (id: {acct.account_id})",
                title="Slack Connection",
                border_style="green",
            )
        )
    else:
        console.print(Panel("[yellow]Connected but no workspace found[/yellow]", border_style="yellow"))

    connector.disconnect()


@app.command()
def accounts():
    """List workspace accounts visible to the bot."""
    connector = _connected_connector()

    acct_list = connector.list_accounts()
    if not acct_list:
        console.print("[yellow]No accounts found.[/yellow]")
        connector.disconnect()
        return

    table = Table(title="Slack Workspace Accounts", border_style="cyan")
    table.add_column("Account ID", style="dim")
    table.add_column("Display Name", style="bold")
    table.add_column("Connector")

    for acct in acct_list:
        table.add_row(acct.account_id, acct.display_name, acct.connector)

    console.print(table)
    connector.disconnect()


@app.command()
def channels(
    type_filter: Annotated[
        str | None,
        typer.Option("--type", "-t", help="Filter by type: channel, private_channel, dm, group"),
    ] = None,
    joined: Annotated[
        bool,
        typer.Option("--joined", "-j", help="Show only channels the bot has joined (can read messages from)"),
    ] = False,
):
    """List channels, DMs, and groups visible to the bot."""
    connector = _connected_connector()

    acct_list = connector.list_accounts()
    if not acct_list:
        console.print("[yellow]No accounts found.[/yellow]")
        connector.disconnect()
        return

    account_id = acct_list[0].account_id
    with console.status("[cyan]Fetching channels...[/cyan]"):
        targets = connector.list_targets(account_id, member_only=joined)

    if type_filter:
        targets = [t for t in targets if t.type == type_filter.lower()]

    if not targets:
        console.print("[yellow]No channels found matching criteria.[/yellow]")
        connector.disconnect()
        return

    table = Table(title=f"Channels in {acct_list[0].display_name}", border_style="cyan")
    table.add_column("Type", style="dim", width=16)
    table.add_column("Name", style="bold")
    table.add_column("ID", style="dim")

    # Sort: channels first, then DMs, then groups
    type_order = {"channel": 0, "private_channel": 1, "group": 2, "dm": 3}
    targets.sort(key=lambda t: (type_order.get(t.type, 99), t.display_name))

    for target in targets:
        type_style = {
            "channel": "[blue]channel[/blue]",
            "private_channel": "[magenta]private[/magenta]",
            "dm": "[green]dm[/green]",
            "group": "[yellow]group[/yellow]",
        }.get(target.type, target.type)
        table.add_row(type_style, target.display_name, target.target_id)

    console.print(table)
    console.print(f"\n[dim]{len(targets)} channel(s) found[/dim]")
    connector.disconnect()


@app.command()
def messages(
    channel: Annotated[
        list[str] | None,
        typer.Option("--channel", "-c", help="Channel ID(s) to fetch messages from. Omit for all."),
    ] = None,
    since: Annotated[
        str | None,
        typer.Option("--since", "-s", help="How far back to fetch: '2h', '30m', '1d', or ISO timestamp"),
    ] = None,
    limit: Annotated[
        int,
        typer.Option("--limit", "-n", help="Maximum number of messages to display"),
    ] = 50,
):
    """Backfill and display messages from channels."""
    connector = _connected_connector()

    acct_list = connector.list_accounts()
    if not acct_list:
        console.print("[yellow]No accounts found.[/yellow]")
        connector.disconnect()
        return

    account_id = acct_list[0].account_id

    # Parse time filter
    oldest = _parse_since(since) if since else None

    # Resolve channel list — if none specified, discover joined channels only
    channel_ids = list(channel) if channel else []
    if not channel_ids:
        with console.status("[cyan]Discovering joined channels...[/cyan]"):
            targets = connector.list_targets(account_id, member_only=True)
        channel_ids = [t.target_id for t in targets]
        if not channel_ids:
            console.print(
                "[yellow]The bot hasn't joined any channels yet.[/yellow]\n"
                "[dim]Invite the bot to channels in Slack, then try again.[/dim]"
            )
            connector.disconnect()
            return
        console.print(f"[dim]Found {len(channel_ids)} joined channel(s) to search[/dim]")

    # Collect messages via a listener
    collected: list[MessageEvent] = []
    lock = threading.Lock()

    class _Collector:
        """Temporary listener that collects messages into a list."""

        def on_message(self, event: MessageEvent) -> None:
            with lock:
                collected.append(event)

    collector = _Collector()
    connector.register_listener(collector)

    # Backfill each channel individually so one failure doesn't abort all
    skipped: list[str] = []
    with console.status("[cyan]Fetching messages...[/cyan]"):
        for ch_id in channel_ids:
            try:
                scope = BackfillScope(conversation_ids=(ch_id,), oldest=oldest)
                connector.backfill(account_id, scope)
            except TargetUnavailable:
                skipped.append(ch_id)
            except ConnectorError as exc:
                skipped.append(ch_id)
                console.log(f"[yellow]Skipped {ch_id}:[/yellow] {exc}")

    connector.unregister_listener(collector)

    if skipped:
        console.print(
            f"[dim]Skipped {len(skipped)} channel(s) the bot cannot read "
            f"(not a member): {', '.join(skipped[:5])}"
            f"{'...' if len(skipped) > 5 else ''}[/dim]\n"
        )

    if not collected:
        console.print("[yellow]No messages found.[/yellow]")
        connector.disconnect()
        return

    # Sort by timestamp, newest last
    collected.sort(key=lambda e: e.timestamp)

    # Trim to limit
    if len(collected) > limit:
        collected = collected[-limit:]

    table = Table(title="Messages", border_style="cyan", show_lines=True)
    table.add_column("Time", style="dim", width=20, no_wrap=True)
    table.add_column("Sender", style="bold", width=20)
    table.add_column("Channel", width=20)
    table.add_column("Message")

    for msg in collected:
        sender_name = msg.sender.display_name if msg.sender else "unknown"
        channel_id = msg.conversation.opaque_id.get("channel", "") if msg.conversation else ""
        text = msg.content.text if msg.content else ""

        # Indicate thread replies
        thread_ts = msg.conversation.opaque_id.get("thread_ts") if msg.conversation else None
        if thread_ts:
            sender_name = f"  [dim]reply[/dim] {sender_name}"

        table.add_row(
            _format_timestamp(msg.timestamp),
            sender_name,
            channel_id,
            _truncate(text, 100),
        )

    console.print(table)
    console.print(f"\n[dim]{len(collected)} message(s) displayed[/dim]")
    connector.disconnect()


@app.command()
def listen():
    """Start real-time listener and display incoming messages live.

    Press Ctrl+C to stop.
    """
    connector = _connected_connector()

    acct_list = connector.list_accounts()
    workspace_name = acct_list[0].display_name if acct_list else "unknown"

    # Track messages for live display
    message_buffer: list[MessageEvent] = []
    buffer_lock = threading.Lock()
    max_buffer = 100
    stop_event = threading.Event()

    class _LiveListener:
        """Listener that buffers messages for live rendering."""

        def on_message(self, event: MessageEvent) -> None:
            with buffer_lock:
                message_buffer.append(event)
                # Keep buffer bounded
                if len(message_buffer) > max_buffer:
                    del message_buffer[: len(message_buffer) - max_buffer]

    listener = _LiveListener()
    connector.register_listener(listener)

    def _signal_handler(sig, frame):
        stop_event.set()

    signal.signal(signal.SIGINT, _signal_handler)

    console.print(
        Panel(
            f"[bold green]Listening[/bold green] to workspace [bold]{workspace_name}[/bold]\n"
            "[dim]Press Ctrl+C to stop[/dim]",
            title="Real-time Slack Listener",
            border_style="green",
        )
    )

    def _build_table() -> Table:
        """Build a table from the current message buffer."""
        table = Table(
            title=f"Live Messages - {workspace_name}",
            border_style="cyan",
            show_lines=True,
            caption="[dim]Press Ctrl+C to stop[/dim]",
        )
        table.add_column("Time", style="dim", width=20, no_wrap=True)
        table.add_column("Sender", style="bold", width=20)
        table.add_column("Channel", width=16)
        table.add_column("Message")

        with buffer_lock:
            # Show newest messages (last N)
            display_msgs = list(message_buffer[-30:])

        for msg in display_msgs:
            sender_name = msg.sender.display_name if msg.sender else "unknown"
            channel_id = msg.conversation.opaque_id.get("channel", "") if msg.conversation else ""
            text = msg.content.text if msg.content else ""

            thread_ts = msg.conversation.opaque_id.get("thread_ts") if msg.conversation else None
            if thread_ts:
                sender_name = f"  [dim]reply[/dim] {sender_name}"

            table.add_row(
                _format_timestamp(msg.timestamp),
                sender_name,
                channel_id,
                _truncate(text, 80),
            )

        return table

    try:
        with Live(_build_table(), console=console, refresh_per_second=2, screen=False) as live:
            while not stop_event.is_set():
                stop_event.wait(timeout=0.5)
                live.update(_build_table())
    except KeyboardInterrupt:
        pass
    finally:
        console.print("\n[dim]Shutting down...[/dim]")
        connector.unregister_listener(listener)
        connector.disconnect()
        console.print("[green]Disconnected.[/green]")


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    app()
