"""Work tracking domain -- platform-agnostic types and protocols."""

from appif.domain.work_tracking.errors import (
    ConnectionFailure,
    InstanceAlreadyRegistered,
    InstanceNotFound,
    InvalidTransition,
    ItemNotFound,
    NoDefaultInstance,
    PermissionDenied,
    RateLimited,
    WorkTrackingError,
)
from appif.domain.work_tracking.models import (
    CreateItemRequest,
    InstanceInfo,
    IssueTypeInfo,
    ItemAuthor,
    ItemCategory,
    ItemComment,
    ItemIdentifier,
    ItemLink,
    LinkType,
    LinkTypeInfo,
    SearchCriteria,
    SearchResult,
    TransitionInfo,
    WorkItem,
)
from appif.domain.work_tracking.ports import InstanceRegistry, WorkTracker

__all__ = [
    # Models
    "CreateItemRequest",
    "InstanceInfo",
    "IssueTypeInfo",
    "ItemAuthor",
    "ItemCategory",
    "ItemComment",
    "ItemIdentifier",
    "ItemLink",
    "LinkType",
    "LinkTypeInfo",
    "SearchCriteria",
    "SearchResult",
    "TransitionInfo",
    "WorkItem",
    # Errors
    "ConnectionFailure",
    "InstanceAlreadyRegistered",
    "InstanceNotFound",
    "InvalidTransition",
    "ItemNotFound",
    "NoDefaultInstance",
    "PermissionDenied",
    "RateLimited",
    "WorkTrackingError",
    # Protocols
    "InstanceRegistry",
    "WorkTracker",
]
