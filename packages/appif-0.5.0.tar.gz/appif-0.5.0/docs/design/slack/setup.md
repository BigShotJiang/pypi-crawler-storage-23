# Slack Connector — Setup Guide

Step-by-step instructions to get tokens and configure the connector.

---

## 1. Create a Slack App

1. Go to [https://api.slack.com/apps](https://api.slack.com/apps)
2. Click **Create New App**
3. Choose **From scratch**
4. Name it (e.g., `appif-bot`) and select your workspace
5. Click **Create App**

## 2. Enable Socket Mode

Socket Mode means the bot connects outbound (no public URL needed).

1. In the left sidebar: **Settings → Socket Mode**
2. Toggle **Enable Socket Mode** to ON
3. You'll be prompted to create an **App-Level Token**:
   - Name: `socket-mode` (or anything)
   - Scope: `connections:write` (should be pre-selected)
   - Click **Generate**
4. **Copy the token** — it starts with `xapp-`. This is your `SLACK_APP_TOKEN`.

## 3. Add Bot Token Scopes

1. In the left sidebar: **Features → OAuth & Permissions**
2. Scroll to **Scopes → Bot Token Scopes**
3. Click **Add an OAuth Scope** and add each of these:

| Scope | Purpose |
|-------|---------|
| `channels:history` | Read messages in public channels |
| `channels:read` | List public channels |
| `groups:history` | Read messages in private channels |
| `groups:read` | List private channels |
| `im:history` | Read direct messages |
| `im:read` | List DM conversations |
| `mpim:history` | Read group DMs |
| `mpim:read` | List group DM conversations |
| `chat:write` | Send messages |
| `users:read` | Look up user display names |

## 4. Subscribe to Events

1. In the left sidebar: **Features → Event Subscriptions**
2. Toggle **Enable Events** to ON
3. Under **Subscribe to bot events**, click **Add Bot User Event** and add:
   - `message.channels` (messages in public channels)
   - `message.groups` (messages in private channels)
   - `message.im` (direct messages)
   - `message.mpim` (group DMs)
4. Click **Save Changes**

## 5. Install the App to Your Workspace

1. In the left sidebar: **Settings → Install App**
2. Click **Install to Workspace**
3. Review permissions and click **Allow**
4. **Copy the Bot User OAuth Token** — it starts with `xoxb-`. This is your `SLACK_BOT_TOKEN`.

## 6. Store the Tokens

Add both tokens to your `~/.env` file:

```bash
# If you haven't created it yet:
cp .env.example ~/.env
```

Edit `~/.env` and fill in:

```
APPIF_SLACK_BOT_TOKEN=xoxb-your-bot-token-here
APPIF_SLACK_APP_TOKEN=xapp-your-app-level-token-here
```

**Do not commit `~/.env` to version control.** It lives in your home directory, outside the repo.

## 7. Invite the Bot to Channels

The bot can only see channels it's been invited to:

1. In Slack, go to the channel you want the bot to monitor
2. Type `/invite @appif-bot` (or whatever you named it)
3. The bot will now receive messages from that channel

DMs to the bot work automatically — no invite needed.

## 8. Verify It Works

```python
from appif.adapters.slack import SlackConnector

connector = SlackConnector()   # Loads tokens from ~/.env
connector.connect()

print(connector.get_status())           # ConnectorStatus.CONNECTED
print(connector.list_accounts())        # [Account(account_id='T...', ...)]
print(connector.list_targets("T..."))   # [Target(target_id='C...', ...)]

connector.disconnect()
```

---

## Token Summary

| Token | Starts with | Where to find it | Env variable |
|-------|-------------|------------------|--------------|
| **Bot Token** | `xoxb-` | OAuth & Permissions → Bot User OAuth Token | `APPIF_SLACK_BOT_TOKEN` |
| **App Token** | `xapp-` | Settings → Socket Mode → App-Level Token | `APPIF_SLACK_APP_TOKEN` |

## Testing

⚠️ **Integration tests run against the live Slack API — they are NOT mocked.**

```bash
# Unit tests (no network, safe to run anytime)
pytest tests/unit/ -v

# Integration tests (hits real Slack)
pytest tests/integration/test_slack_integration.py -v
```

The only acceptable send target for automated tests is **Larry Dawson** (`U01NVSBQH40`).
Override via `APPIF_SLACK_TEST_USER_ID` env var if needed, but never target a coworker
or shared channel from automated test runs.

---

## Troubleshooting

| Problem | Fix |
|---------|-----|
| `NotAuthorized: APPIF_SLACK_BOT_TOKEN is required` | Token not in `~/.env` or empty |
| Bot doesn't receive messages | Bot not invited to channel (`/invite @botname`) |
| `not_in_channel` error on send | Bot needs to be a member of the target channel |
| `missing_scope` error | Add the missing scope in OAuth & Permissions, then reinstall the app |
| `invalid_auth` on connect | Token was revoked or copied incorrectly — regenerate it |