"""
Omni Daily Client - The Morning Stand-Up Intelligence
=====================================================

This client wraps the 4 core scanners that provide daily situational awareness:
- `git/git`: General repo status (dirty/clean)
- `git/velocity`: Developer productivity and momentum
- `fleet/fleet`: Cross-repo inventory
- `health/federation_health`: System integrity pulse

Output returns standard scanner data along with a synthesized "tldr" 
for immediate human-readable feedback.
"""

from typing import Dict, Any, Optional, List
from pathlib import Path
import logging

# Configure logger for the Daily Client
logger = logging.getLogger("Omni.Clients.OmniDaily")

class OmniDailyClient:
    """
    OmniDailyClient - Orchestrates Morning Stand-Up intelligence across the fleet.
    """
    
    def __init__(self, omni_root: Optional[Path] = None):
        """
        Initialize the client.
        
        Args:
            omni_root: Path to Omni root. If None, auto-detected.
        """
        self.omni_root = omni_root or self._find_omni_root()
        
    def _find_omni_root(self) -> Path:
        """Auto-detect Omni installation."""
        candidates = [
            Path(__file__).parent.parent.parent,
            Path.cwd() / "tools" / "omni",
            Path.cwd(),
        ]
        
        for candidate in candidates:
            if (candidate / "omni").exists():
                return candidate
        
        return Path(__file__).parent.parent.parent

    def run_daily_standup(self, target: Optional[Path] = None) -> Dict[str, Any]:
        """
        Runs the daily stand-up orchestration.
        
        Args:
            target: Directory to scan. Defaults to omni_root if None.
            
        Returns:
            Standardized result dictionary with synthesized TL;DR.
        """
        target = target or self.omni_root
        
        try:
            # Lazy Import Scanners
            from omni.scanners import SCANNERS
            
            logger.info(f"🚀 Starting Morning Stand-Up for {target}")
            
            results = {}
            
            def safe_dict(res: Any) -> Any:
                """Convert objects like ScanResult to dict for serialization."""
                if hasattr(res, "to_dict"):
                    return res.to_dict()
                elif hasattr(res, "__dict__"):
                    return vars(res)
                return res
            
            # 1. Repo Status
            if "git" in SCANNERS:
                logger.info("   Checking Git Status...")
                results["git"] = safe_dict(SCANNERS["git"](target))
                
            # 2. Velocity
            if "velocity" in SCANNERS:
                logger.info("   Checking Velocity...")
                results["velocity"] = safe_dict(SCANNERS["velocity"](target))
                
            # 3. Fleet
            if "fleet" in SCANNERS:
                logger.info("   Checking Fleet Inventory...")
                results["fleet"] = safe_dict(SCANNERS["fleet"](target))
                
            # 4. Federation Health
            if "federation_health" in SCANNERS:
                logger.info("   Checking Federation Pulse...")
                results["health"] = safe_dict(SCANNERS["federation_health"](target))
                
            # Draft Synthesized TLDR
            tldr = self._synthesize_tldr(results)
            
            return {
                "success": True,
                "operation": "morning_standup",
                "target": str(target),
                "tldr": tldr,
                "scanners_run": list(results.keys()),
                "results": results,
            }

        except Exception as e:
            logger.error(f"Morning Stand-Up failed: {e}")
            return {
                "success": False,
                "error": str(e),
                "operation": "morning_standup",
                "tldr": f"Critical error during standup: {str(e)}"
            }

    def _synthesize_tldr(self, results: Dict[str, Any]) -> str:
        """Synthesize a human-readable summary from scanner results formatting them dynamically."""
        
        # Robust parsing of disparate scanner outputs
        issues = []
        
        # Git dirty check
        git_res = results.get("git", {})
        dirty_count = 0
        if isinstance(git_res, dict):
            dirty_count = len(git_res.get("dirty_repos", [])) or (1 if git_res.get("is_dirty") else 0)
            
        if dirty_count > 0:
            issues.append(f"{dirty_count} repos have unstaged changes")
        else:
            issues.append("All repos clean")
            
        # Velocity check
        vel_res = results.get("velocity", {})
        if isinstance(vel_res, dict) and "delta" in vel_res:
            delta = vel_res.get("delta", 0)
            if delta > 0:
                issues.append(f"Velocity up {delta}%")
            elif delta < 0:
                issues.append(f"Velocity down {abs(delta)}%")
                
        # Health check
        health_res = results.get("health", {})
        if isinstance(health_res, dict):
            status = health_res.get("status", health_res.get("is_healthy", "Unknown"))
            if status == True or str(status).lower() == "healthy":
                issues.append("Federation Heart beating normally")
            elif status == False or str(status).lower() == "unhealthy" or str(status).lower() == "degraded":
                issues.append("Federation Heart degraded")
                
        if not issues:
            return "No standout insights derived from scanners."
            
        return " | ".join(issues)
