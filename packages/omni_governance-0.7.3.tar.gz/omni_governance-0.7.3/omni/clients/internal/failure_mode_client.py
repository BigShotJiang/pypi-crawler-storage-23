"""
Omni Failure-Mode Hook Client
================================

Orchestrates the git/velocity and other scanners to flag repositories
that violate defined architectural failure modes.
"""
import logging
from typing import Dict, Any, Optional
from datetime import datetime
from pathlib import Path

logger = logging.getLogger("Omni.Clients.FailureMode")

class FailureModeClient:
    """Flags projects violating defined modes (e.g., Grinding Gears, Ghost Towns)."""
    
    def __init__(self, omni_root: Optional[Path] = None):
        self.omni_root = omni_root or Path.cwd()
        
    def check_failure_modes(self, target: Optional[Path] = None) -> Dict[str, Any]:
        """Run velocity scanner and build failure mode report."""
        target = target or self.omni_root
        
        try:
            from omni.scanners import SCANNERS
            if "velocity" not in SCANNERS:
                return {"success": False, "error": "Velocity scanner not found in registry."}
            
            logger.info(f"🚦 Checking Failure Modes for {target}")
            
            # Use last 30 days for recent velocity
            vel_res = SCANNERS["velocity"](target, since="30.days.ago")
            
            # Serialize if needed
            if hasattr(vel_res, "to_dict"):
                vel_res = vel_res.to_dict()
            elif hasattr(vel_res, "__dict__"):
                vel_res = vars(vel_res)
                
            items = vel_res.get("items", []) if isinstance(vel_res, dict) else []
            successful = [i for i in items if not i.get("error")]
            
            if not successful:
                return {
                    "success": True,
                    "operation": "failure_modes",
                    "report_md": "## Failure Mode Hook\n\nNo valid repositories found.",
                    "flags": []
                }
            
            flags = []
            
            for repo in successful:
                name = repo.get("name", "Unknown")
                commits = repo.get("total_commits", 0)
                net = repo.get("net_lines", 0)
                lpd = repo.get("lines_per_day", 0.0)
                
                # 1. Grinding Gears: Extreme intensity (lots of commits) + Low velocity (few lines)
                if commits > 20 and lpd < 10.0 and net > 0:
                    flags.append({
                        "repo": name,
                        "mode": "Grinding Gears",
                        "severity": "Warning",
                        "reason": f"High intensity ({commits} commits) but very low velocity ({lpd:,.1f} lines/day). Spinning wheels?"
                    })
                
                # 2. Danger Zone: Huge negative velocity (massive deletions without structure)
                if lpd < -500.0 and commits > 10:
                    flags.append({
                        "repo": name,
                        "mode": "Danger Zone",
                        "severity": "Alert",
                        "reason": f"Massive code bleeding ({lpd:,.1f} lines/day) across {commits} commits. Architectural collapse or deep refactoring?"
                    })
                    
                # 3. Code Dump: One giant commit, huge lines
                if commits > 0 and commits <= 2 and lpd > 5000:
                    flags.append({
                        "repo": name,
                        "mode": "Code Dump",
                        "severity": "Warning",
                        "reason": f"Massive code dump ({lpd:,.1f} lines/day) in only {commits} commits. Difficult to review."
                    })

            md = ["# 🚦 Omni Failure-Mode Report", f"**Generated:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}", ""]
            
            if not flags:
                md.append("✅ **All Clear!** No failure modes detected in the last 30 days.")
            else:
                md.append(f"⚠️ **Detected {len(flags)} Pattern Violations:**\n")
                
                for flag in flags:
                    emoji = "🔴" if flag["severity"] == "Alert" else "🟡"
                    md.append(f"### {emoji} {flag['mode']}: `{flag['repo']}`")
                    md.append(f"> {flag['reason']}")
                    md.append("")
            
            return {
                "success": True,
                "operation": "failure_modes",
                "report_md": "\n".join(md),
                "flags": flags
            }
            
        except Exception as e:
            logger.error(f"Failure Mode check failed: {e}")
            return {
                "success": False,
                "error": str(e),
                "operation": "failure_modes",
                "report_md": f"## Failure Mode Hook\n\nFailed to execute: {e}",
                "flags": []
            }
