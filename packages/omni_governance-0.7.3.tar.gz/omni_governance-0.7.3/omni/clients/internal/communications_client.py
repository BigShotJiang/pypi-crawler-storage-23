"""
Omni Communications Client
===========================

Pushes Omni intelligence reports (Daily Stand-Up, Failure Modes, Velocity)
to external communication channels like Slack and Discord via webhooks.
"""
import os
import json
import logging
import urllib.request
import urllib.error
from typing import Dict, Any, Optional
from pathlib import Path

logger = logging.getLogger("Omni.Clients.Communications")

class CommunicationsClient:
    """Dispatches Omni reports to configured external channels."""
    
    def __init__(self, slack_webhook: Optional[str] = None, discord_webhook: Optional[str] = None):
        # Load from environment or override
        self.slack_webhook = slack_webhook or os.environ.get("OMNI_SLACK_WEBHOOK")
        self.discord_webhook = discord_webhook or os.environ.get("OMNI_DISCORD_WEBHOOK")
        
    def push_daily_standup(self, target: Optional[Path] = None) -> Dict[str, Any]:
        """Run the daily standup and push it to configured channels."""
        from omni.clients.omni_daily_client import OmniDailyClient
        
        logger.info("📡 Running Daily Stand-up for broadcast...")
        daily_client = OmniDailyClient()
        report = daily_client.run_daily_standup(target=target)
        
        if not report.get("success"):
            return {"success": False, "error": f"Failed to generate standup: {report.get('error')}"}
            
        tldr = report.get("tldr", "No TL;DR available.")
        target_str = report.get("target", "Unknown")
        
        message = f"🌅 **Omni Daily Stand-Up**\n📍 Target: `{target_str}`\n\n**TL;DR:** {tldr}"
        
        return self._broadcast(message, payload_type="Daily Stand-Up")
        
    def push_failure_modes(self, target: Optional[Path] = None) -> Dict[str, Any]:
        """Run failure mode checks and broadcast if violations exist."""
        from omni.clients.failure_mode_client import FailureModeClient
        
        logger.info("📡 Running Failure Mode checks for broadcast...")
        failure_client = FailureModeClient()
        report = failure_client.check_failure_modes(target=target)
        
        if not report.get("success"):
            return {"success": False, "error": f"Failed to generate failure modes: {report.get('error')}"}
            
        flags = report.get("flags", [])
        if not flags:
            logger.info("No failure modes to broadcast. All clear.")
            return {"success": True, "message": "No failures to report.", "channels_notified": []}
            
        message = f"🚨 **Omni Architecture Alert!** ({len(flags)} violations)\n\n"
        for flag in flags:
            emoji = "🔴" if flag["severity"] == "Alert" else "🟡"
            message += f"**{emoji} {flag['mode']}**: `{flag['repo']}`\n> {flag['reason']}\n\n"
            
        return self._broadcast(message, payload_type="Failure Alerts")
        
    def _broadcast(self, text: str, payload_type: str) -> Dict[str, Any]:
        """Send the text payload to all configured webhooks."""
        results = {"success": False, "channels_notified": [], "errors": []}
        
        if not self.slack_webhook and not self.discord_webhook:
            results["error"] = "No webhooks configured. Set OMNI_SLACK_WEBHOOK or OMNI_DISCORD_WEBHOOK."
            return results
            
        # Push to Discord
        if self.discord_webhook:
            try:
                msg_payload = {"content": text}
                req = urllib.request.Request(
                    self.discord_webhook, 
                    data=json.dumps(msg_payload).encode("utf-8"),
                    headers={"Content-Type": "application/json", "User-Agent": "Omni-Communications-Client/1.0"}
                )
                with urllib.request.urlopen(req) as response:
                    # Discord returns 204 No Content for successful webhook post
                    if response.status in (200, 204):
                        results["channels_notified"].append("discord")
                        logger.info("✅ Pushed to Discord webhook.")
            except Exception as e:
                logger.error(f"Failed to push to Discord: {e}")
                results["errors"].append(f"Discord error: {str(e)}")
                
        # Push to Slack
        if self.slack_webhook:
            try:
                # Slack text payload format
                msg_payload = {"text": text}
                req = urllib.request.Request(
                    self.slack_webhook, 
                    data=json.dumps(msg_payload).encode("utf-8"),
                    headers={"Content-Type": "application/json", "User-Agent": "Omni-Communications-Client/1.0"}
                )
                with urllib.request.urlopen(req) as response:
                    if response.status == 200:
                        results["channels_notified"].append("slack")
                        logger.info("✅ Pushed to Slack webhook.")
            except Exception as e:
                logger.error(f"Failed to push to Slack: {e}")
                results["errors"].append(f"Slack error: {str(e)}")
                
        if results["channels_notified"]:
            results["success"] = True
            
        return results
