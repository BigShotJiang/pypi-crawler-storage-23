"""
Omni Velocity Dashboard Client
================================

Orchestrates the git/velocity scanner to build a comprehensive markdown
dashboard of development momentum across the Federation.
"""
import logging
from typing import Dict, Any, Optional
from datetime import datetime
from pathlib import Path

logger = logging.getLogger("Omni.Clients.VelocityDashboard")

class VelocityDashboardClient:
    """Consumes git/velocity data and generates a visualized markdown dashboard."""
    
    def __init__(self, omni_root: Optional[Path] = None):
        self.omni_root = omni_root or Path.cwd()
        
    def generate_dashboard(self, target: Optional[Path] = None, since: Optional[str] = None) -> Dict[str, Any]:
        """Run velocity scanner and build dashboard markdown."""
        target = target or self.omni_root
        
        try:
            from omni.scanners import SCANNERS
            if "velocity" not in SCANNERS:
                return {"success": False, "error": "Velocity scanner not found in registry."}
            
            logger.info(f"🚀 Generating Velocity Dashboard for {target}")
            
            vel_res = SCANNERS["velocity"](target, since=since)
            
            # Serialize if needed
            if hasattr(vel_res, "to_dict"):
                vel_res = vel_res.to_dict()
            elif hasattr(vel_res, "__dict__"):
                vel_res = vars(vel_res)
                
            items = vel_res.get("items", []) if isinstance(vel_res, dict) else []
            successful = [i for i in items if not i.get("error")]
            failed = [i for i in items if i.get("error")]
            
            if not successful:
                return {
                    "success": True,
                    "operation": "velocity_dashboard",
                    "dashboard_md": "## Velocity Dashboard\n\nNo valid repositories found or no commits detected.",
                    "raw_data": vel_res
                }
            
            # Aggregate stats
            total_commits = sum(i.get("total_commits", 0) for i in successful)
            total_added = sum(i.get("lines_added", 0) for i in successful)
            total_deleted = sum(i.get("lines_deleted", 0) for i in successful)
            total_net = total_added - total_deleted
            
            # Find max values for pseudo-bar-charts
            max_lines_per_day = max((i.get("lines_per_day", 0) for i in successful), default=1)
            
            md = ["# 🌌 Omni Velocity Dashboard", f"**Generated:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}", ""]
            md.append("## 📊 Federation Momentum")
            md.append(f"- **Repositories Analyzed:** {len(successful)}")
            md.append(f"- **Total Commits:** {total_commits:,}")
            md.append(f"- **Net Lines Changed:** {total_net:+,}")
            md.append("")
            
            if failed:
                md.append(f"⚠️ **Failed to analyze {len(failed)} repositories.**")
                md.append("")
                
            md.append("## 🚀 Top Accelerating Repositories")
            md.append("*(Ranked by lines modified per day)*\n")
            
            # Sort by lines per day
            top_repos = sorted(successful, key=lambda r: r.get("lines_per_day", 0), reverse=True)
            
            for rank, repo in enumerate(top_repos[:15], 1):
                name = repo.get("name", "Unknown")
                lpd = repo.get("lines_per_day", 0)
                commits = repo.get("total_commits", 0)
                net = repo.get("net_lines", 0)
                
                # ASCII Bar Graph
                bar_len = int((lpd / max_lines_per_day) * 20) if max_lines_per_day > 0 else 0
                bar = "█" * bar_len + "░" * (20 - bar_len)
                
                md.append(f"### {rank}. {name}")
                md.append(f"`{bar}` **{lpd:,.1f} lines/day**")
                md.append(f"> Commits: {commits:,} | Net Lines: {net:+,}")
                if lpd > 1000:
                    md.append("> *🔥 EMERGENCE AT VELOCITY!*")
                md.append("")
            
            return {
                "success": True,
                "operation": "velocity_dashboard",
                "dashboard_md": "\n".join(md),
                "raw_data": vel_res
            }
            
        except Exception as e:
            logger.error(f"Velocity Dashboard failed: {e}")
            return {
                "success": False,
                "error": str(e),
                "operation": "velocity_dashboard",
                "dashboard_md": f"## Velocity Dashboard\n\nFailed to generate: {e}"
            }
