"""
Omni Clients
============

High-level orchestrators for Omni workflows.
Use `TemplateClient` as a base for creating your own integration.
"""

from .template_client import TemplateClient

# Internal Clients (Cathedral Sovereign Routines)
from .internal.omni_daily_client import OmniDailyClient
from .internal.velocity_dashboard_client import VelocityDashboardClient
from .internal.failure_mode_client import FailureModeClient
from .internal.communications_client import CommunicationsClient

# External Clients (Federation Handshake Layer)
try:
    from .external.genesis_client import GenesisClient
except ImportError:
    GenesisClient = None

try:
    from .external.librarian_client import LibrarianClient
except ImportError:
    LibrarianClient = None

try:
    from .external.github_ops_client import GitHubOpsClient
except ImportError:
    GitHubOpsClient = None

__all__ = [
    "TemplateClient",
    "OmniDailyClient",
    "VelocityDashboardClient",
    "FailureModeClient",
    "CommunicationsClient",
    "GenesisClient",
    "LibrarianClient",
    "GitHubOpsClient",
]
