import logging
from typing import Dict, Any, Optional
import os

# Import scanners directly
# Note: we use lazy imports inside methods if circular deps become an issue, 
# but here we want to declare dependencies clearly.
try:
    from omni.scanners.git import git
    from omni.scanners.git import velocity
    from omni.scanners.git import commit_history
    from omni.scanners.git import pr_telemetry
except ImportError:
    # Fallback for when running in environments where omni is not fully installed
    # This allows the client to be imported even if scanners are missing (e.g. during bootstrap)
    git = None
    velocity = None
    commit_history = None
    pr_telemetry = None

logger = logging.getLogger(__name__)

class GitHubOpsClient:
    """
    GitHub Ops Client - Orchestrator for Git Operations
    
    Refactored to be a pure orchestrator that delegates actual work to 
    specialized scanners in `omni.scanners.git`.
    
    This client does NOT do network IO directly. It manages the flow of 
    information between the Tool Guild and the Git/GitHub scanners.
    """

    def __init__(self, token: Optional[str] = None):
        self.token = token or os.environ.get("GITHUB_TOKEN")
        if not self.token:
            logger.debug("GITHUB_TOKEN not set; some operations may be limited.")
            
        if not git:
            logger.warning("omni.scanners.git modules not found. Client will be non-functional.")

    def scan_status(self, repo_path: str) -> Dict[str, Any]:
        """
        Get current git status of a repository.
        Delegates to omni.scanners.git.git.scan()
        """
        if not git:
            return {"error": "Git scanner not available"}
        return git.scan(repo_path)

    def scan_velocity(self, repo_path: str) -> Dict[str, Any]:
        """
        Analyze development velocity (commit frequency, etc).
        Delegates to omni.scanners.git.velocity.scan()
        """
        if not velocity:
            return {"error": "Velocity scanner not available"}
        return velocity.scan(repo_path)

    def scan_history(self, repo_path: str) -> Dict[str, Any]:
        """
        Get commit history analysis.
        Delegates to omni.scanners.git.commit_history.scan()
        """
        if not commit_history:
            return {"error": "Commit history scanner not available"}
        return commit_history.scan(repo_path)

    def scan_telemetry(self, target: str, **kwargs) -> Dict[str, Any]:
        """
        Scan PR telemetry and health (The Telepath).
        Delegates to omni.scanners.git.pr_telemetry.scan()
        
        Args:
            target: Local path or "owner/repo" string.
            **kwargs: Extra options like 'limit'.
        """
        if not pr_telemetry:
            return {"error": "PR Telemetry scanner not available"}
        return pr_telemetry.scan(target, **kwargs)

    def download_pr(self, pr_number: int, target_dir: str, repo_context: str) -> Dict[str, Any]:
        """
        Download PR artifacts (JSON metadata and Diff) to a local target directory.
        
        Args:
            pr_number: The PR number to download.
            target_dir: Local path to save artifacts.
            repo_context: "owner/repo" context for gh CLI.
            
        Returns:
            Dict with status and paths to saved artifacts.
        """
        import subprocess
        import json
        from pathlib import Path
        
        target_path = Path(target_dir)
        target_path.mkdir(parents=True, exist_ok=True)
        
        json_path = target_path / f"{pr_number}.pr.json"
        
        try:
            # 1. Fetch Metadata (gh pr view --json)
            cmd_meta = ["gh", "pr", "view", str(pr_number), "--repo", repo_context, 
                       "--json", "number,title,body,state,author,createdAt,files,headRefName,baseRefName,commits"]
            
            result_meta = subprocess.run(cmd_meta, capture_output=True, text=True, check=True)
            meta_data = json.loads(result_meta.stdout)
            
            # 2. Fetch Diff (gh pr diff)
            cmd_diff = ["gh", "pr", "diff", str(pr_number), "--repo", repo_context]
            result_diff = subprocess.run(cmd_diff, capture_output=True, text=True, check=True)
            diff_data = result_diff.stdout
            
            # 3. Combine and Save
            artifact = {
                "meta": meta_data,
                "diff": diff_data,
                "schema_version": "v1.0"
            }
            
            with open(json_path, 'w', encoding='utf-8') as f:
                json.dump(artifact, f, indent=2)
                
            return {
                "success": True,
                "pr_number": pr_number,
                "artifact_path": str(json_path),
                "size_bytes": json_path.stat().st_size
            }
            
        except subprocess.CalledProcessError as e:
            return {
                "success": False,
                "pr_number": pr_number,
                "error": f"GH CLI Error: {e.stderr}",
            }
        except Exception as e:
            return {
                "success": False,
                "pr_number": pr_number,
                "error": str(e),
            }

__all__ = ["GitHubOpsClient"]
