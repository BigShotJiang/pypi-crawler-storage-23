# Polyglot scanners
