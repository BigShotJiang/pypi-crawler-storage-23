# Static scanners
