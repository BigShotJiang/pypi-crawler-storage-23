# Architecture scanners - structural enforcement for the Federation
