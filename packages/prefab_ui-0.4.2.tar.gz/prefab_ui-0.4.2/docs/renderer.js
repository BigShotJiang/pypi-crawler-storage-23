(function(){var base=window.location.hostname==="localhost"?"/":"https://cdn.jsdelivr.net/npm/@prefecthq/prefab-ui@latest/dist/";window.__prefabReady=import(base+"_renderer/embed.mjs");})();
