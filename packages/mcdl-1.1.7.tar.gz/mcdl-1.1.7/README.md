# MCDL

a simple game downloader for [Minecraft](https://www.minecraft.net/)

## Install

```commandline
pip install mcdl
```

## How to use?

```python
# Example: download & launch Minecraft 1.21.11
from mcdl import get_version_meta, MinecraftVersionDownloader, Launcher

# create downloader
downloader = MinecraftVersionDownloader(get_version_meta("1.21.11"), "version-name")

# download
# Game path: ./game_folder/.minecraft/<version_name>/<version_name>.jar
Launcher(downloader.download("./game_folder")).launch("<username>")
```

```python
# Example: launch 1.21.11
from mcdl import Launcher, MinecraftVersion
v1_21_11 = MinecraftVersion("1.21.11", "<version_name>", "<version_folder>", "29")  # 29: asset version
Launcher(v1_21_11).launch("<username>")
```

## References
Minecraft Wiki
[编写启动器](https://zh.minecraft.wiki/w/Tutorial:%E7%BC%96%E5%86%99%E5%90%AF%E5%8A%A8%E5%99%A8?variant=zh-cn)
[Mojang API](https://zh.minecraft.wiki/w/Mojang_API?variant=zh-cn)