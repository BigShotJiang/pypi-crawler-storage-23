import os
import platform
import shutil
import subprocess
import zipfile
from zipfile import ZipFile

import requests
import json

from parfive import Downloader
from tqdm import tqdm
from datetime import datetime


def get_version_meta(version: str) -> MinecraftVersionMeta:
    url = "https://piston-meta.mojang.com/mc/game/version_manifest.json"
    data = requests.get(url).json()

    for version_meta in data["versions"]:
        if version_meta["id"] == version:
            return MinecraftVersionMeta(version_meta, version)

    raise MinecraftVersionNotFoundError


def get_sys() -> str:
    sys_name = platform.system().lower()
    if sys_name == "darwin":
        return "osx"
    return sys_name


def extract_dll(file: ZipFile, output_folder: str) -> None:
    for info in file.infolist():
        if info.filename.endswith(".dll"):
            file_name = os.path.basename(info.filename)
            output_path = os.path.join(output_folder, file_name)

            with file.open(info.filename, "r") as source, open(output_path, "wb") as target:
                shutil.copyfileobj(source, target)


def get_arch():
    if platform.architecture()[0] == "64bit":
        return "x64"
    else:
        return "x86"


def get_uuid(username: str) -> str:
    url = f"https://api.mojang.com/users/profiles/minecraft/{username}"
    response = requests.get(url).json()

    return response["id"]


class SimpleLogger:
    def __init__(self, name, proj_name: str):
        self.name = name
        self.proj_name = proj_name

    def gen_log(self, message, color: str) -> str:
        current_time = datetime.now().strftime("%H:%M:%S")
        return f"\033[0;34m[{current_time}] {color}[%s/{self.name}] \033[0;36m({self.proj_name}) \033[0m{message}"

    def debug(self, message) -> None:
        print(self.gen_log(message, "\033[0;37m") % "DEBUG")

    def info(self, message) -> None:
        print(self.gen_log(message, "\033[0;32m") % "INFO")

    def warning(self, message) -> None:
        print(self.gen_log(message, "\033[0;33m") % "WARNING")

    def error(self, message) -> None:
        print(self.gen_log(message, "\033[0;31m") % "ERROR")

    def critical(self, message) -> None:
        print(self.gen_log(message, "\033[1;31m") % "CRITICAL")


logger = SimpleLogger("main", "MinecraftDownloader")


class MinecraftVersionNotFoundError(Exception):
    pass


class MinecraftVersion:
    def __init__(self, version: str, version_name: str, folder: str, asset_ver: str) -> None:
        self.version = version
        self.version_name = version_name
        self.folder = folder
        self.asset_ver = asset_ver


class MinecraftVersionDownloader:
    def __init__(self, meta: MinecraftVersionMeta, version_name: str):
        self.response = requests.get(meta.url).json()
        self.version_name = version_name
        self.meta = meta
        self.index_version = self.response["assetIndex"]["id"]

    @staticmethod
    def should_download(lib_info: dict, os_type: str) -> bool:
        try:
            if lib_info["rules"][0]["os"]["name"] == os_type:
                return True
            return False
        except KeyError:
            return True

    def download_index(self, index_folder: str) -> None:
        url = self.response["assetIndex"]["url"]
        resp = requests.get(url).json()

        os.makedirs(index_folder, exist_ok=True)

        with open(f"{index_folder}/{self.response["assets"]}.json", "w") as f:
            f.write(json.dumps(resp))

    def download_libs(self, os_type: str, lib_folder: str) -> None:
        dl = Downloader(max_conn=16, max_splits=24, progress=False, overwrite=True)

        for lib in tqdm(self.response["libraries"], desc="Collecting Libraries"):
            try:  # 处理旧版本
                if self.should_download(lib, os_type):
                    url = lib["downloads"]["artifact"]["url"]

                    file_path = lib["downloads"]["artifact"]["path"]

                    path = lib_folder + "/" + "/".join(file_path.split("/")[:-1])
                    name = file_path.split("/")[-1]

                    dl.enqueue_file(url=url, path=path, filename=name)
            except KeyError:
                if get_sys() in lib["natives"].keys():
                    if get_sys() == "windows" and lib["natives"]["windows"][-1] == "}":
                        system = get_sys() + "-" + platform.architecture()[0][:2]
                    else:
                        system = get_sys()

                    url = lib["downloads"]["classifiers"]["natives-" + system]["url"]

                    file_path = lib["downloads"]["classifiers"]["natives-" + system]["path"]

                    path = lib_folder + "/" + "/".join(file_path.split("/")[:-1])
                    name = file_path.split("/")[-1]

                    dl.enqueue_file(url=url, path=path, filename=name)

        logger.info("Downloading Libraries")

        logger.info("Done!\nFailed: " + str(dl.download().errors))

    def download_assets(self, asset_folder: str) -> None:
        url = self.response["assetIndex"]["url"]
        resp = requests.get(url).json()

        dl = Downloader(max_conn=48, max_splits=8, progress=False, overwrite=True)

        for value in tqdm(resp["objects"].values(), desc="Collecting Assets"):
            file_url = f"https://resources.download.minecraft.net/{value["hash"][:2]}/{value["hash"]}"
            file_path = f"{asset_folder}/{value["hash"][:2]}/"

            dl.enqueue_file(url=file_url, path=file_path, filename=value["hash"])

        logger.info("Downloading Assets (It will take a few minutes)")

        logger.info("Done!\nFailed: " + str(dl.download().errors))

    def download_version_json(self, version_folder: str) -> None:
        with open(f"{version_folder}/{self.version_name}.json", "w") as f:
            f.write(json.dumps(self.response))

    def download_client(self, version_folder: str) -> None:
        url = self.response["downloads"]["client"]["url"]
        logger.info("Downloading Client")
        resp = requests.get(url).content

        with open(f"{version_folder}/{self.version_name}.jar", "wb") as f:
            f.write(resp)

        logger.info("Done!")

    def unzip_natives(self, version_folder: str) -> None:
        files = os.walk(f"{version_folder}/libraries")

        for file in files:
            if file[-1]:
                for f in file[-1]:
                    if "natives" in f.lower():
                        path = file[0].replace("\\", "/") + "/" + f
                        output_folder = f"{version_folder}/versions/{self.version_name}/{self.version_name}-natives"
                        os.makedirs(output_folder, exist_ok=True)

                        with zipfile.ZipFile(path, "r") as zip_ref:
                            extract_dll(zip_ref, output_folder)

                        logger.info("Extracted: " + path)

    def download(self, folder) -> MinecraftVersion:
        logger.info("Downloading Minecraft")

        os.makedirs(f"{folder}/.minecraft/versions/{self.version_name}", exist_ok=True)

        self.download_client(f"{folder}/.minecraft/versions/{self.version_name}")  # 下载版本
        self.download_version_json(f"{folder}/.minecraft/versions/{self.version_name}")  # 下载版本Json文件

        self.download_assets(f"{folder}/.minecraft/assets/objects")  # 下载 assets
        self.download_index(f"{folder}/.minecraft/assets/indexes")  # 下载 index

        self.download_libs(get_sys(), f"{folder}/.minecraft/libraries")  # 下载 libs
        self.unzip_natives(f"{folder}/.minecraft")

        return MinecraftVersion(self.meta.version, self.version_name, folder, self.index_version)


class MinecraftVersionMeta:
    def __init__(self, meta: dict, version: str) -> None:
        self.meta = meta
        self.url = meta["url"]
        self.version = version

    def print(self) -> None:
        print(f"Minecraft {self.meta["id"]} ({self.meta["type"]}) Url: {self.meta['url']}")


class Launcher:
    def __init__(self, ver_info: MinecraftVersion) -> None:
        self.ver_name = ver_info.version_name
        self.folder = ver_info.folder
        self.assets_ver = ver_info.asset_ver

    @staticmethod
    def should_add(rules: list) -> bool:
        for rule in rules:
            if "name" in rule["os"].keys():
                if get_sys() != rule["os"]["name"]:
                    return False
            elif "arch" in rule["os"].keys():
                if get_arch() != rule["os"]["arch"]:
                    return False
        return True

    def get_cp(self) -> str:
        result = "\""

        for f in os.walk(f"{self.folder}/.minecraft/libraries"):
            for file in f[-1]:
                file_path = f[0].replace("\\", "/") + "/" + file
                #if "natives" not in file_path.lower():
                result += os.path.abspath(file_path) + ";"
        result += os.path.abspath(f"{self.folder}/.minecraft/versions/{self.ver_name}/{self.ver_name}.jar")
        result += "\""
        return result

    def replace(self, command: str, player_name) -> str:
        result = command.replace("${natives_directory}", os.path.abspath(f"./.minecraft/versions/{self.ver_name}/"
                                                                         f"{self.ver_name}-natives"))
        result = result.replace("${launcher_name}", "MCDL")
        result = result.replace("${launcher_version}", "1.1.0")
        result = result.replace("${classpath}", self.get_cp())
        result = result.replace("${auth_player_name}", player_name)
        result = result.replace("${version_name}", self.ver_name)
        result = result.replace("${game_directory}",
                                os.path.abspath(f"{self.folder}/.minecraft/versions/{self.ver_name}/"))
        result = result.replace("${assets_root}", os.path.abspath(f"{self.folder}/.minecraft/assets"))
        result = result.replace("${assets_index_name}", self.assets_ver)
        result = result.replace("${auth_uuid}", get_uuid(player_name))
        result = result.replace("${auth_access_token}", "OFFLINE")
        result = result.replace("${version_type}", "MCDL")

        return result

    def get_command(self, player_name: str) -> str:
        command = "java "

        with open(f"{self.folder}/.minecraft/versions/{self.ver_name}/{self.ver_name}.json", "r") as f:
            data = json.load(f)
            jvm_args = data["arguments"]["jvm"]
            game_args = data["arguments"]["game"]

        for arg in jvm_args:
            if isinstance(arg, str):
                command += arg + " "
            else:
                try:
                    if self.should_add(arg["rules"]):
                        command += arg["value"] + " "
                except KeyError:
                    logger.critical("This version is not supported!")
        command += " " + data["mainClass"] + " "

        for arg in game_args:
            if isinstance(arg, str):
                command += arg + " "

        return self.replace(command, player_name)

    def launch(self, player_name: str) -> None:
        os.makedirs("./.mcdl/temp", exist_ok=True)
        with open("./.mcdl/temp/launch.bat", "w") as f:
            f.write(self.get_command(player_name))
        subprocess.run([os.path.abspath("./.mcdl/temp/launch.bat")], shell=True)
