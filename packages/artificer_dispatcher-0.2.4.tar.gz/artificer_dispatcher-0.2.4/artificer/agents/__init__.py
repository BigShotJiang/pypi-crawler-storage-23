# Agent adapters for different agent types
