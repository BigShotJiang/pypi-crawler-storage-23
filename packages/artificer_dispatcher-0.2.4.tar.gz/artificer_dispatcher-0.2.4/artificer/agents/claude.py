from __future__ import annotations

import json
import logging
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from artificer.adapters.base import Task, TaskAdapter
    from artificer.config import RouteConfig
    from artificer.router import AgentProcess

log = logging.getLogger(__name__)


class ClaudeAgentAdapter:
    """Agent adapter for Claude with stream-json output parsing.

    Extracts session IDs and assistant messages from Claude's stream-json output,
    posts session comments, and includes resume hints in exit comments.
    """

    def __init__(self) -> None:
        # Track last assistant message per task
        self._last_assistant_msg: dict[str, str] = {}

    def augment_command(self, cmd: list[str], route: RouteConfig) -> list[str]:
        """Add Claude-specific flags for non-interactive mode and stream-json output."""
        # Inject -p for non-interactive mode if not already present
        if "-p" not in cmd and "--print" not in cmd:
            cmd.append("-p")
        # Add stream-json output format to capture session ID and messages
        cmd.append("--output-format")
        cmd.append("stream-json")
        cmd.append("--verbose")
        return cmd

    def process_stdout_line(
        self, line: str, agent: AgentProcess, task: Task, adapter: TaskAdapter
    ) -> None:
        """Parse stream-json output to extract session_id and last assistant message."""
        if not line:
            return

        try:
            msg = json.loads(line)
            if not isinstance(msg, dict):
                return

            # Extract session_id if we haven't seen it yet
            if not agent.session_id and msg.get("session_id"):
                agent.session_id = msg["session_id"]
                log.info("Agent for task %s has session %s", task.id, agent.session_id)
                try:
                    adapter.add_comment(
                        task.id, f"Claude conversation: `{agent.session_id}`"
                    )
                except Exception:
                    log.warning(
                        "Failed to add session comment for task %s",
                        task.id,
                        exc_info=True,
                    )

            # Extract last assistant message
            if msg.get("type") == "assistant" and msg.get("message", {}).get("content"):
                parts = msg["message"]["content"]
                texts = [p.get("text", "") for p in parts if p.get("type") == "text"]
                if texts:
                    self._last_assistant_msg[task.id] = "\n".join(texts)

        except (json.JSONDecodeError, TypeError):
            # Not valid JSON, skip
            pass

    def format_spawn_comment(self, command_str: str) -> str:
        """Format generic spawn comment (same as default)."""
        return f"Spawning agent with command `{command_str}`"

    def format_exit_comment(
        self,
        agent: AgentProcess,
        timed_out: bool,
        timeout: int | None,
        error_snippet: str,
        last_message: str,
    ) -> str:
        """Format exit comment with last message and resume hint."""
        # Build base comment
        if timed_out:
            comment = f"Agent session ended: timed out after {timeout}s"
        elif agent.process.returncode is None:
            comment = "Agent session ended: cancelled"
        elif agent.process.returncode == 0:
            comment = "Agent session ended normally (exit 0)"
        else:
            comment = f"Agent session ended: exit code {agent.process.returncode}: {error_snippet}"

        # Get last assistant message (prefer from our tracking)
        last_msg = self._last_assistant_msg.get(agent.task_id, last_message)
        if last_msg:
            comment += f"\n\nLast agent message:\n{last_msg[:1000]}"

        # Add resume hint if we have a session ID
        if agent.session_id:
            comment += f"\n\nResume session: `claude resume {agent.session_id}`"

        # Clean up tracking
        self._last_assistant_msg.pop(agent.task_id, None)

        return comment

    def get_status_extras(self, agent: AgentProcess) -> dict[str, Any]:
        """Return session_id if available."""
        if agent.session_id:
            return {"session_id": agent.session_id}
        return {}
