from __future__ import annotations

from artificer.adapters.base import TaskAdapter


def _list_queues(adapter: TaskAdapter) -> list[dict]:
    queues = adapter.list_queues()
    return [{"name": q.name, "task_count": q.task_count} for q in queues]


def _get_queue(adapter: TaskAdapter, queue_name: str) -> dict:
    q = adapter.get_queue(queue_name)
    return {"name": q.name, "task_count": q.task_count}


def _create_queue(adapter: TaskAdapter, queue_name: str) -> dict:
    q = adapter.create_queue(queue_name)
    return {"name": q.name, "task_count": q.task_count}


def _update_queue(adapter: TaskAdapter, queue_name: str, *, new_name: str | None = None) -> dict:
    q = adapter.update_queue(queue_name, new_name=new_name)
    return {"name": q.name, "task_count": q.task_count}


def _delete_queue(adapter: TaskAdapter, queue_name: str) -> str:
    adapter.delete_queue(queue_name)
    return f"Queue {queue_name!r} deleted"
