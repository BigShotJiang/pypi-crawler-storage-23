# IDEAS

## Features

- **RAG MCP server for agent context** — pre-indexed codebase so fresh agents skip discovery phase. Biggest win for repeated spawns against same repo.
- **Resume on input** — when an agent needs user input, it exits and moves task to "Needs Input" queue. User answers in comments, moves to "Received Input". Dispatcher route picks it up and spawns with `--resume <session_id>`. No dispatcher changes needed if `prompt_fn` can read session_id from task metadata.
- **Shared input board** — single board across projects where blocked tasks collect. User has one inbox for all agent questions. Tasks route back to original board after input received.
- **Soften stale-slot reaper** — once root cause of slot leaks is identified, change from crash-on-detection to cleanup-and-continue.

## Patterns to test and document

- **Resume-on-input** — agent asks question via comment, moves to input queue, exits. Fresh agent resumes conversation when input received. Test: does `--resume` with full comment history produce good results vs fresh spawn?
- **Research-then-implement pipeline** — research agent produces findings, implementation agent picks up from there. Two queues, two routes, task flows between them.
- **Priority-based queue draining** — high-priority queue (bugs) drains before low-priority (features) using route priority. Already implemented, needs documentation.
- **Per-queue poll intervals** — hot queues poll frequently, cold queues poll rarely. Already implemented, needs documentation.
- **Retry with dead-letter queue** — failed tasks retry N times then move to DLQ for manual review. Already implemented, needs documentation.
- **Asset downloading via adapter** — adapter downloads task attachments/images from backend at spawn time, saves to temp folder, agent receives local paths. Keeps backend auth and API details out of agents.
