from __future__ import annotations

import pytest
from starlette.testclient import TestClient

from artificer.http_api import create_app


@pytest.fixture
def client(adapter) -> TestClient:
    """Client with queue management enabled."""
    return TestClient(create_app(adapter, enable_queue_management=True))


@pytest.fixture
def client_disabled(adapter) -> TestClient:
    """Client with queue management disabled (default)."""
    return TestClient(create_app(adapter))


class TestListQueues:
    def test_returns_list(self, client):
        resp = client.get("/queues")
        assert resp.status_code == 200
        data = resp.json()
        assert isinstance(data, list)
        names = {q["name"] for q in data}
        assert "Bugs" in names
        assert "In Progress" in names
        assert "Done" in names

    def test_correct_task_counts(self, client):
        resp = client.get("/queues")
        data = resp.json()
        by_name = {q["name"]: q for q in data}
        assert by_name["Bugs"]["task_count"] == 1
        assert by_name["In Progress"]["task_count"] == 0

    def test_always_available_when_disabled(self, client_disabled):
        resp = client_disabled.get("/queues")
        assert resp.status_code == 200


class TestGetQueue:
    def test_returns_queue(self, client):
        resp = client.get("/queues/Bugs")
        assert resp.status_code == 200
        data = resp.json()
        assert data["name"] == "Bugs"
        assert data["task_count"] == 1

    def test_not_found(self, client):
        resp = client.get("/queues/Nonexistent")
        assert resp.status_code == 404
        assert "error" in resp.json()

    def test_always_available_when_disabled(self, client_disabled):
        resp = client_disabled.get("/queues/Bugs")
        assert resp.status_code == 200

    def test_dotted_queue_name(self, client):
        """Test that dotted names (e.g., Planka-style) work as path params."""
        # This queue won't exist, but we should get 404 not a routing error
        resp = client.get("/queues/Project.Board.List")
        assert resp.status_code == 404


class TestCreateQueue:
    def test_creates_queue(self, client):
        resp = client.post("/queues", json={"name": "New Queue"})
        assert resp.status_code == 201
        data = resp.json()
        assert data["name"] == "New Queue"
        assert data["task_count"] == 0

        # Verify it exists
        resp = client.get("/queues/New Queue")
        assert resp.status_code == 200

    def test_missing_name(self, client):
        resp = client.post("/queues", json={})
        assert resp.status_code == 400
        assert "name" in resp.json()["error"]

    def test_duplicate_name(self, client):
        resp = client.post("/queues", json={"name": "Bugs"})
        assert resp.status_code == 400

    def test_forbidden_when_disabled(self, client_disabled):
        resp = client_disabled.post("/queues", json={"name": "New Queue"})
        assert resp.status_code == 403
        assert "disabled" in resp.json()["error"]


class TestUpdateQueue:
    def test_renames_queue(self, client):
        resp = client.patch("/queues/In Progress", json={"name": "Working"})
        assert resp.status_code == 200
        data = resp.json()
        assert data["name"] == "Working"

        # Verify old name is gone, new name exists
        resp = client.get("/queues/In Progress")
        assert resp.status_code == 404
        resp = client.get("/queues/Working")
        assert resp.status_code == 200

    def test_not_found(self, client):
        resp = client.patch("/queues/Nonexistent", json={"name": "New"})
        assert resp.status_code == 404

    def test_no_fields(self, client):
        resp = client.patch("/queues/Bugs", json={})
        assert resp.status_code == 400

    def test_name_conflict(self, client):
        resp = client.patch("/queues/In Progress", json={"name": "Bugs"})
        assert resp.status_code == 400

    def test_forbidden_when_disabled(self, client_disabled):
        resp = client_disabled.patch("/queues/In Progress", json={"name": "Working"})
        assert resp.status_code == 403
        assert "disabled" in resp.json()["error"]


class TestDeleteQueue:
    def test_deletes_empty_queue(self, client):
        resp = client.delete("/queues/Done")
        assert resp.status_code == 200
        assert "Done" in resp.json()["message"]

        # Verify it's gone
        resp = client.get("/queues/Done")
        assert resp.status_code == 404

    def test_not_found(self, client):
        resp = client.delete("/queues/Nonexistent")
        assert resp.status_code == 404

    def test_non_empty_returns_400(self, client):
        resp = client.delete("/queues/Bugs")
        assert resp.status_code == 400

    def test_forbidden_when_disabled(self, client_disabled):
        resp = client_disabled.delete("/queues/Done")
        assert resp.status_code == 403
        assert "disabled" in resp.json()["error"]


class TestQueueManagementDisabled:
    """Verify that all write endpoints return 403 while reads return 200."""

    def test_get_queues_allowed(self, client_disabled):
        resp = client_disabled.get("/queues")
        assert resp.status_code == 200

    def test_get_queue_allowed(self, client_disabled):
        resp = client_disabled.get("/queues/Bugs")
        assert resp.status_code == 200

    def test_post_forbidden(self, client_disabled):
        resp = client_disabled.post("/queues", json={"name": "New"})
        assert resp.status_code == 403

    def test_patch_forbidden(self, client_disabled):
        resp = client_disabled.patch("/queues/Bugs", json={"name": "New"})
        assert resp.status_code == 403

    def test_delete_forbidden(self, client_disabled):
        resp = client_disabled.delete("/queues/Done")
        assert resp.status_code == 403
