from __future__ import annotations

import asyncio
import json

import pytest
from starlette.testclient import TestClient

from artificer.adapters.json_file import JsonFileAdapter
from artificer.config import RouteConfig
from artificer.http_api import create_app
from artificer.router import Router


@pytest.fixture
def client(adapter) -> TestClient:
    return TestClient(create_app(adapter))


class TestGetTaskDetails:
    def test_returns_task(self, client):
        resp = client.get("/tasks/1")
        assert resp.status_code == 200
        data = resp.json()
        assert data["id"] == "1"
        assert data["name"] == "Fix crash"
        assert "App crashes" in data["description"]
        assert data["labels"] == ["urgent"]
        assert data["assignees"] == ["alice"]

    def test_not_found(self, client):
        resp = client.get("/tasks/999")
        assert resp.status_code == 404
        assert "error" in resp.json()


class TestCommentsInTaskDetails:
    def test_comments_included(self, client):
        resp = client.get("/tasks/1")
        data = resp.json()
        assert len(data["comments"]) == 1
        assert data["comments"][0]["author"] == "bob"
        assert data["comments"][0]["text"] == "Confirmed"


class TestAddComment:
    def test_adds_comment(self, client):
        resp = client.post("/tasks/1/comments", json={"comment": "Working on it"})
        assert resp.status_code == 200
        assert "message" in resp.json()

        # Verify comment was persisted via task details
        resp = client.get("/tasks/1")
        comments = resp.json()["comments"]
        assert any(c["text"] == "Working on it" for c in comments)

    def test_missing_comment_field(self, client):
        resp = client.post("/tasks/1/comments", json={})
        assert resp.status_code == 400
        assert "comment" in resp.json()["error"]

    def test_not_found(self, client):
        resp = client.post("/tasks/999/comments", json={"comment": "test"})
        assert resp.status_code == 404


class TestMoveTask:
    def test_moves_task(self, client):
        resp = client.post("/tasks/1/move", json={"target_queue": "In Progress"})
        assert resp.status_code == 200
        assert "In Progress" in resp.json()["message"]

        # Verify task moved
        resp = client.get("/tasks/1")
        assert resp.json()["source_queue"] == "In Progress"

    def test_missing_target_queue(self, client):
        resp = client.post("/tasks/1/move", json={})
        assert resp.status_code == 400
        assert "target_queue" in resp.json()["error"]

    def test_not_found_task(self, client):
        resp = client.post("/tasks/999/move", json={"target_queue": "Done"})
        assert resp.status_code == 404

    def test_not_found_queue(self, client):
        resp = client.post("/tasks/1/move", json={"target_queue": "Nonexistent"})
        assert resp.status_code == 404


class TestUpdateTask:
    def test_patch_updates_name(self, client):
        resp = client.patch("/tasks/1", json={"name": "New name"})
        assert resp.status_code == 200
        data = resp.json()
        assert data["name"] == "New name"

    def test_patch_updates_assignees(self, client):
        resp = client.patch("/tasks/1", json={"assignees": ["bob"]})
        assert resp.status_code == 200
        data = resp.json()
        assert data["assignees"] == ["bob"]

    def test_patch_updates_labels(self, client):
        resp = client.patch("/tasks/1", json={"labels": ["bug", "critical"]})
        assert resp.status_code == 200
        data = resp.json()
        assert data["labels"] == ["bug", "critical"]

    def test_patch_updates_description(self, client):
        resp = client.patch("/tasks/1", json={"description": "New desc"})
        assert resp.status_code == 200
        data = resp.json()
        assert "New desc" in data["description"]

    def test_patch_empty_body_returns_400(self, client):
        resp = client.patch("/tasks/1", json={})
        assert resp.status_code == 400
        assert "No updatable fields" in resp.json()["error"]

    def test_patch_not_found_returns_404(self, client):
        resp = client.patch("/tasks/999", json={"name": "Nope"})
        assert resp.status_code == 404

    def test_patch_returns_full_task(self, client):
        resp = client.patch("/tasks/1", json={"name": "Updated"})
        assert resp.status_code == 200
        data = resp.json()
        assert "id" in data
        assert "name" in data
        assert "description" in data
        assert "labels" in data
        assert "assignees" in data
        assert "comments" in data
        assert "url" in data
        assert "source_queue" in data


class TestCreateTask:
    def test_creates_task(self, client):
        resp = client.post(
            "/tasks",
            json={
                "queue_name": "Bugs",
                "name": "New bug",
                "description": "Something broke",
            },
        )
        assert resp.status_code == 201
        data = resp.json()
        assert data["name"] == "New bug"
        assert data["description"] == "Something broke"
        assert data["source_queue"] == "Bugs"
        assert data["id"]  # should have an id

    def test_missing_fields(self, client):
        resp = client.post("/tasks", json={"queue_name": "Bugs"})
        assert resp.status_code == 400
        assert "name" in resp.json()["error"]

    def test_not_found_queue(self, client):
        resp = client.post(
            "/tasks",
            json={
                "queue_name": "Nonexistent",
                "name": "task",
                "description": "desc",
            },
        )
        assert resp.status_code == 404


class TestStatus:
    def test_status_returns_503_when_no_router(self, client):
        resp = client.get("/status")
        assert resp.status_code == 503
        assert resp.json() == {"error": "Router not available"}

    def test_status_returns_200_with_router_no_agents(self, tmp_path):
        board_data = {
            "queues": {
                "Bugs": [],
                "In Progress": [],
            }
        }
        path = tmp_path / "board.json"
        path.write_text(json.dumps(board_data))
        adapter = JsonFileAdapter(path)
        router = Router(
            adapter,
            poll_interval=1,
            max_concurrent_agents=3,
            routes=[
                RouteConfig(
                    queue_name="Bugs",
                    command="true",
                    args=[],
                    in_progress_queue="In Progress",
                ),
            ],
        )
        client = TestClient(create_app(adapter, router=router))

        resp = client.get("/status")
        assert resp.status_code == 200
        data = resp.json()
        assert data["active_agents"] == []
        assert data["available_slots"] == 3
        assert data["max_concurrent_agents"] == 3

    @pytest.mark.asyncio
    async def test_status_returns_200_with_active_agent(self, tmp_path):
        board_data = {
            "queues": {
                "Bugs": [
                    {
                        "id": "status-1",
                        "name": "Bug for status",
                        "description": "d1",
                        "labels": [],
                        "assignees": [],
                        "comments": [],
                        "tasks": [],
                    },
                ],
                "In Progress": [],
            }
        }
        path = tmp_path / "board.json"
        path.write_text(json.dumps(board_data))
        adapter = JsonFileAdapter(path)
        router = Router(
            adapter,
            poll_interval=1,
            max_concurrent_agents=3,
            routes=[
                RouteConfig(
                    queue_name="Bugs",
                    command="sleep",
                    args=["10"],
                    in_progress_queue="In Progress",
                ),
            ],
        )

        await router._poll_once()
        assert "status-1" in router._active

        try:
            client = TestClient(create_app(adapter, router=router))
            resp = client.get("/status")
            assert resp.status_code == 200
            data = resp.json()

            assert len(data["active_agents"]) == 1
            agent = data["active_agents"][0]
            assert agent["task_id"] == "status-1"
            assert isinstance(agent["pid"], int)
            assert agent["command"] == "sleep"
            assert agent["running_for_seconds"] >= 0

            assert data["available_slots"] == 3 - len(data["active_agents"])
            assert data["max_concurrent_agents"] == 3
        finally:
            # Kill spawned processes to avoid leaked subprocesses
            for agent_proc in list(router._active.values()):
                agent_proc.process.kill()
            for agent_proc in list(router._active.values()):
                await agent_proc.process.wait()
            monitors = list(router._monitor_tasks.values())
            if monitors:
                await asyncio.gather(*monitors, return_exceptions=True)
