from __future__ import annotations

import asyncio
import json
import logging
import time

import pytest

from artificer.adapters.base import Task
from artificer.adapters.json_file import JsonFileAdapter
from artificer.config import RouteConfig
from artificer.router import Router

_DEFAULT_ROUTER_BOARD: dict = {
    "queues": {
        "Bugs": [
            {"id": "1", "name": "Bug one", "description": "d1", "labels": [], "assignees": [], "comments": [], "tasks": []},
            {"id": "2", "name": "Bug two", "description": "d2", "labels": [], "assignees": [], "comments": [], "tasks": []},
        ],
        "Features": [
            {"id": "3", "name": "Feat one", "description": "d3", "labels": [], "assignees": [], "comments": [], "tasks": []},
        ],
        "In Progress": [],
        "Done": [],
    }
}


def _make_router(adapter: JsonFileAdapter, max_concurrent: int = 2) -> Router:
    return Router(
        adapter,
        poll_interval=1,
        max_concurrent_agents=max_concurrent,
        routes=[
            RouteConfig(queue_name="Bugs", command="true", args=[], in_progress_queue="In Progress"),
            RouteConfig(queue_name="Features", command="echo", args=["{task_id}", "{task_name}"], in_progress_queue="In Progress"),
        ],
    )


async def _wait_and_cleanup(router: Router) -> None:
    """Wait for all active agent processes to finish and clean up."""
    agents = list(router._active.values())
    for agent in agents:
        await agent.process.wait()
    # Let monitor tasks run to clean up _active
    monitors = list(router._monitor_tasks.values())
    if monitors:
        await asyncio.gather(*monitors, return_exceptions=True)


async def _kill_and_cleanup(router: Router) -> None:
    """Terminate all active agent processes and clean up."""
    for agent in list(router._active.values()):
        agent.process.kill()
    for agent in list(router._active.values()):
        await agent.process.wait()
    monitors = list(router._monitor_tasks.values())
    if monitors:
        await asyncio.gather(*monitors, return_exceptions=True)


@pytest.mark.asyncio
class TestPollPicksUpTasks:
    async def test_picks_up_ready_tasks(self, make_adapter):
        json_path, adapter = make_adapter(_DEFAULT_ROUTER_BOARD)
        router = Router(
            adapter,
            poll_interval=1,
            max_concurrent_agents=3,
            routes=[
                RouteConfig(queue_name="Bugs", command="sleep", args=["10"], in_progress_queue="In Progress"),
                RouteConfig(queue_name="Features", command="sleep", args=["10"], in_progress_queue="In Progress"),
            ],
        )

        await router._poll_once()

        assert len(router._active) == 3
        assert set(router._active.keys()) == {"1", "2", "3"}

        await _kill_and_cleanup(router)

    async def test_skips_seen_tasks(self, make_adapter):
        json_path, adapter = make_adapter(_DEFAULT_ROUTER_BOARD)
        router = Router(
            adapter,
            poll_interval=1,
            max_concurrent_agents=3,
            routes=[
                RouteConfig(queue_name="Bugs", command="sleep", args=["10"], in_progress_queue="In Progress"),
                RouteConfig(queue_name="Features", command="sleep", args=["10"], in_progress_queue="In Progress"),
            ],
        )
        router._seen_ids.add("1")

        await router._poll_once()

        assert "1" not in router._active
        assert "2" in router._active
        assert "3" in router._active

        await _kill_and_cleanup(router)

    async def test_respects_concurrency_limit(self, make_adapter):
        json_path, adapter = make_adapter(_DEFAULT_ROUTER_BOARD)
        router = _make_router(adapter, max_concurrent=1)

        await router._poll_once()

        assert len(router._active) == 1

        await _wait_and_cleanup(router)

    async def test_skips_when_no_slots(self, make_adapter):
        json_path, adapter = make_adapter(_DEFAULT_ROUTER_BOARD)
        router = _make_router(adapter, max_concurrent=1)

        await router._poll_once()
        first_seen = set(router._seen_ids)

        await router._poll_once()
        # No new tasks picked up - same seen set (or one more if slot freed)
        assert len(router._active) <= 1

        await _wait_and_cleanup(router)


@pytest.mark.asyncio
class TestSpawnAgent:
    async def test_moves_to_in_progress_before_exec(self, make_adapter, tmp_path):
        json_path, adapter = make_adapter(_DEFAULT_ROUTER_BOARD)
        router = _make_router(adapter)

        await router._poll_once()

        data = json.loads((tmp_path / "board.json").read_text())
        bug_ids = [t["id"] for t in data["queues"]["Bugs"]]
        ip_ids = [t["id"] for t in data["queues"]["In Progress"]]
        assert "1" not in bug_ids
        assert "1" in ip_ids

        await _wait_and_cleanup(router)

    async def test_formats_command_correctly(self, make_adapter, tmp_path):
        board_data = {
            "queues": {
                "Features": [
                    {"id": "10", "name": "Dark mode", "description": "", "labels": [], "assignees": [], "comments": [], "tasks": []},
                ],
                "Bugs": [],
                "In Progress": [],
                "Done": [],
            }
        }
        json_path, adapter = make_adapter(board_data)
        router = _make_router(adapter)

        await router._poll_once()

        # Wait for the monitor task to complete
        monitor = router._monitor_tasks["10"]
        await monitor

        # Read the board to verify the spawn comment has the formatted command
        data = json.loads((tmp_path / "board.json").read_text())
        task = next((t for t in data["queues"]["In Progress"] if t["id"] == "10"), None)
        assert task is not None
        # Verify command was formatted with task_id and task_name
        spawn_comment = next((c["text"] for c in task["comments"] if "Spawning agent" in c["text"]), "")
        assert "10 Dark mode" in spawn_comment



@pytest.mark.asyncio
class TestMonitorAgent:
    async def test_cleans_up_on_completion(self, make_adapter):
        json_path, adapter = make_adapter(_DEFAULT_ROUTER_BOARD)
        router = _make_router(adapter, max_concurrent=1)

        await router._poll_once()
        assert len(router._active) == 1
        tid = next(iter(router._active))

        monitor = router._monitor_tasks[tid]
        await monitor

        assert tid not in router._active
        assert tid not in router._monitor_tasks
        assert tid not in router._seen_ids

    async def test_timeout_terminates_agent(self, make_adapter, tmp_path):
        """Test that agents exceeding route timeout are terminated."""
        board_data = {
            "queues": {
                "Bugs": [
                    {"id": "timeout-test", "name": "Long task", "description": "d1", "labels": [], "assignees": [], "comments": [], "tasks": []},
                ],
                "In Progress": [],
                "Done": [],
            }
        }
        json_path, adapter = make_adapter(board_data)
        router = Router(
            adapter,
            poll_interval=1,
            max_concurrent_agents=2,
            routes=[
                RouteConfig(queue_name="Bugs", command="sleep", args=["10"], in_progress_queue="In Progress", timeout=1),
            ],
        )

        await router._poll_once()
        assert "timeout-test" in router._active

        monitor = router._monitor_tasks["timeout-test"]
        await monitor

        # Agent should be cleaned up after timeout
        assert "timeout-test" not in router._active

        # Check that a timeout comment was added
        data = json.loads((tmp_path / "board.json").read_text())
        task = next((t for t in data["queues"]["In Progress"] if t["id"] == "timeout-test"), None)
        assert task is not None
        assert any("timed out" in c["text"].lower() for c in task["comments"])

    async def test_default_timeout_applies(self, make_adapter, tmp_path):
        """Test that default_agent_timeout applies when route timeout is not specified."""
        board_data = {
            "queues": {
                "Bugs": [
                    {"id": "default-timeout-test", "name": "Task", "description": "d1", "labels": [], "assignees": [], "comments": [], "tasks": []},
                ],
                "In Progress": [],
                "Done": [],
            }
        }
        json_path, adapter = make_adapter(board_data)
        router = Router(
            adapter,
            poll_interval=1,
            max_concurrent_agents=2,
            routes=[
                RouteConfig(queue_name="Bugs", command="sleep", args=["10"], in_progress_queue="In Progress"),
            ],
            default_agent_timeout=1,
        )

        await router._poll_once()
        assert "default-timeout-test" in router._active

        monitor = router._monitor_tasks["default-timeout-test"]
        await monitor

        # Agent should be cleaned up after default timeout
        assert "default-timeout-test" not in router._active

        # Check that a timeout comment was added
        data = json.loads((tmp_path / "board.json").read_text())
        task = next((t for t in data["queues"]["In Progress"] if t["id"] == "default-timeout-test"), None)
        assert task is not None
        assert any("timed out" in c["text"].lower() for c in task["comments"])

    async def test_route_timeout_overrides_default(self, make_adapter, tmp_path):
        """Test that route-specific timeout overrides default timeout."""
        board_data = {
            "queues": {
                "Bugs": [
                    {"id": "override-test", "name": "Task", "description": "d1", "labels": [], "assignees": [], "comments": [], "tasks": []},
                ],
                "In Progress": [],
                "Done": [],
            }
        }
        json_path, adapter = make_adapter(board_data)
        router = Router(
            adapter,
            poll_interval=1,
            max_concurrent_agents=2,
            routes=[
                # Route timeout of 1s should override default of 100s
                RouteConfig(queue_name="Bugs", command="sleep", args=["10"], in_progress_queue="In Progress", timeout=1),
            ],
            default_agent_timeout=100,
        )

        await router._poll_once()
        assert "override-test" in router._active

        monitor = router._monitor_tasks["override-test"]
        await monitor

        # Agent should be cleaned up after route timeout (1s), not default timeout (100s)
        assert "override-test" not in router._active

        # Check that a timeout comment was added
        data = json.loads((tmp_path / "board.json").read_text())
        task = next((t for t in data["queues"]["In Progress"] if t["id"] == "override-test"), None)
        assert task is not None
        assert any("timed out" in c["text"].lower() for c in task["comments"])

    async def test_no_timeout_when_not_configured(self, make_adapter, tmp_path):
        """Test that agents run without timeout when not configured."""
        board_data = {
            "queues": {
                "Bugs": [
                    {"id": "no-timeout-test", "name": "Task", "description": "d1", "labels": [], "assignees": [], "comments": [], "tasks": []},
                ],
                "In Progress": [],
                "Done": [],
            }
        }
        json_path, adapter = make_adapter(board_data)
        router = Router(
            adapter,
            poll_interval=1,
            max_concurrent_agents=2,
            routes=[
                # No timeout specified, and no default_agent_timeout
                RouteConfig(queue_name="Bugs", command="true", args=[], in_progress_queue="In Progress"),
            ],
        )

        await router._poll_once()
        assert "no-timeout-test" in router._active

        monitor = router._monitor_tasks["no-timeout-test"]
        await monitor

        # Agent should complete normally
        assert "no-timeout-test" not in router._active

        # Check that no timeout comment was added
        data = json.loads((tmp_path / "board.json").read_text())
        task = next((t for t in data["queues"]["In Progress"] if t["id"] == "no-timeout-test"), None)
        assert task is not None
        assert not any("timed out" in c["text"].lower() for c in task["comments"])


@pytest.mark.asyncio
class TestAgentAdapterSelection:
    """Tests for agent adapter selection and behavior."""

    async def test_claude_adapter_selected_for_claude_commands(self, make_adapter, tmp_path):
        """Verify ClaudeAgentAdapter is used for claude commands."""
        board_data = {
            "queues": {
                "Claude Tasks": [
                    {"id": "claude-1", "name": "Claude task", "description": "", "labels": [], "assignees": [], "comments": [], "tasks": []},
                ],
                "In Progress": [],
            }
        }
        json_path, adapter = make_adapter(board_data)
        router = Router(
            adapter,
            poll_interval=1,
            max_concurrent_agents=1,
            routes=[
                RouteConfig(queue_name="Claude Tasks", command="claude", args=["--agent", "test"], in_progress_queue="In Progress"),
            ],
        )

        await router._poll_once()

        # Verify the agent is running
        assert "claude-1" in router._active
        agent = router._active["claude-1"]

        # Verify ClaudeAgentAdapter was used (check for injected flags)
        # The command should have -p, --output-format, stream-json, --verbose
        assert agent.command == "claude"

        # Kill and cleanup
        await _kill_and_cleanup(router)

        # Verify spawn comment was added
        data = json.loads((tmp_path / "board.json").read_text())
        task = next((t for t in data["queues"]["In Progress"] if t["id"] == "claude-1"), None)
        assert task is not None
        assert any("Spawning agent with command" in c["text"] for c in task["comments"])
        # Verify stream-json flags were injected
        spawn_comment = next((c["text"] for c in task["comments"] if "Spawning agent" in c["text"]), "")
        assert "--output-format stream-json" in spawn_comment
        assert "-p" in spawn_comment or "--print" in spawn_comment

    async def test_default_adapter_for_other_commands(self, make_adapter, tmp_path):
        """Verify DefaultAgentAdapter is used for non-claude commands."""
        board_data = {
            "queues": {
                "Scripts": [
                    {"id": "script-1", "name": "Script task", "description": "", "labels": [], "assignees": [], "comments": [], "tasks": []},
                ],
                "In Progress": [],
            }
        }
        json_path, adapter = make_adapter(board_data)
        router = Router(
            adapter,
            poll_interval=1,
            max_concurrent_agents=1,
            routes=[
                RouteConfig(queue_name="Scripts", command="echo", args=["test"], in_progress_queue="In Progress"),
            ],
        )

        await router._poll_once()

        # Verify the agent is running
        assert "script-1" in router._active
        agent = router._active["script-1"]

        # Verify DefaultAgentAdapter was used (command not modified with Claude flags)
        assert agent.command == "echo"

        # Wait for completion
        await _wait_and_cleanup(router)

        # Verify spawn comment was added
        data = json.loads((tmp_path / "board.json").read_text())
        task = next((t for t in data["queues"]["In Progress"] if t["id"] == "script-1"), None)
        assert task is not None
        assert any("Spawning agent with command" in c["text"] for c in task["comments"])
        # Verify stream-json flags were NOT injected
        spawn_comment = next((c["text"] for c in task["comments"] if "Spawning agent" in c["text"]), "")
        assert "--output-format" not in spawn_comment
        assert "stream-json" not in spawn_comment

    async def test_status_includes_session_id_for_claude(self, make_adapter, tmp_path):
        """Verify status endpoint includes session_id for Claude agents."""
        board_data = {
            "queues": {
                "Claude Tasks": [
                    {"id": "claude-status", "name": "Claude task", "description": "", "labels": [], "assignees": [], "comments": [], "tasks": []},
                ],
                "In Progress": [],
            }
        }
        json_path, adapter = make_adapter(board_data)
        router = Router(
            adapter,
            poll_interval=1,
            max_concurrent_agents=1,
            routes=[
                RouteConfig(queue_name="Claude Tasks", command="claude", args=["test"], in_progress_queue="In Progress"),
            ],
        )

        await router._poll_once()

        # Manually set a session_id to test status
        agent = router._active["claude-status"]
        agent.session_id = "test-session-123"

        # Get status
        status = router.get_status()

        # Verify session_id is in status
        assert len(status["active_agents"]) == 1
        agent_status = status["active_agents"][0]
        assert agent_status["session_id"] == "test-session-123"
        assert agent_status["command"] == "claude"

        await _kill_and_cleanup(router)

    async def test_status_excludes_session_id_for_non_claude(self, make_adapter, tmp_path):
        """Verify status endpoint does not include session_id for non-Claude agents."""
        board_data = {
            "queues": {
                "Scripts": [
                    {"id": "script-status", "name": "Script task", "description": "", "labels": [], "assignees": [], "comments": [], "tasks": []},
                ],
                "In Progress": [],
            }
        }
        json_path, adapter = make_adapter(board_data)
        router = Router(
            adapter,
            poll_interval=1,
            max_concurrent_agents=1,
            routes=[
                RouteConfig(queue_name="Scripts", command="sleep", args=["10"], in_progress_queue="In Progress"),
            ],
        )

        await router._poll_once()

        # Get status
        status = router.get_status()

        # Verify session_id is NOT in status
        assert len(status["active_agents"]) == 1
        agent_status = status["active_agents"][0]
        assert "session_id" not in agent_status
        assert agent_status["command"] == "sleep"

        await _kill_and_cleanup(router)


@pytest.mark.asyncio
class TestPerQueuePollIntervals:
    async def test_queue_with_explicit_interval_respects_it(self, make_adapter, tmp_path):
        """Queue with poll_interval=100 should not be re-polled after 1 second."""
        board_data = {
            "queues": {
                "Fast": [
                    {"id": "f1", "name": "Fast task", "description": "", "labels": [], "assignees": [], "comments": [], "tasks": []},
                ],
                "Slow": [
                    {"id": "s1", "name": "Slow task", "description": "", "labels": [], "assignees": [], "comments": [], "tasks": []},
                ],
                "In Progress": [],
            }
        }
        json_path, adapter = make_adapter(board_data)
        router = Router(
            adapter,
            poll_interval=1,
            max_concurrent_agents=10,
            routes=[
                RouteConfig(queue_name="Fast", command="sleep", args=["10"], in_progress_queue="In Progress", poll_interval=1),
                RouteConfig(queue_name="Slow", command="sleep", args=["10"], in_progress_queue="In Progress", poll_interval=100),
            ],
        )

        # First poll: both queues are due (last_poll_times starts empty)
        await router._poll_once()
        assert "f1" in router._active
        assert "s1" in router._active

        # Add new tasks to both queues
        data = json.loads((tmp_path / "board.json").read_text())
        data["queues"]["Slow"].append(
            {"id": "s2", "name": "Slow task 2", "description": "", "labels": [], "assignees": [], "comments": [], "tasks": []}
        )
        data["queues"]["Fast"].append(
            {"id": "f2", "name": "Fast task 2", "description": "", "labels": [], "assignees": [], "comments": [], "tasks": []}
        )
        (tmp_path / "board.json").write_text(json.dumps(data))

        # Wait just over 1 second so Fast is due again but Slow is not
        await asyncio.sleep(1.1)

        await router._poll_once()

        # Fast queue task should be picked up
        assert "f2" in router._active
        # Slow queue task should NOT be picked up (100s hasn't elapsed)
        assert "s2" not in router._active

        await _kill_and_cleanup(router)

    async def test_queue_without_interval_uses_global_default(self, make_adapter, tmp_path):
        """Queue without explicit poll_interval uses the global default."""
        board_data = {
            "queues": {
                "Default": [
                    {"id": "d1", "name": "Default task", "description": "", "labels": [], "assignees": [], "comments": [], "tasks": []},
                ],
                "In Progress": [],
            }
        }
        json_path, adapter = make_adapter(board_data)
        router = Router(
            adapter,
            poll_interval=1,
            max_concurrent_agents=10,
            routes=[
                RouteConfig(queue_name="Default", command="sleep", args=["10"], in_progress_queue="In Progress"),
            ],
        )

        # First poll picks up d1
        await router._poll_once()
        assert "d1" in router._active

        # Add a new task
        data = json.loads((tmp_path / "board.json").read_text())
        data["queues"]["Default"].append(
            {"id": "d2", "name": "Default task 2", "description": "", "labels": [], "assignees": [], "comments": [], "tasks": []}
        )
        (tmp_path / "board.json").write_text(json.dumps(data))

        # Wait just over the global interval
        await asyncio.sleep(1.1)

        await router._poll_once()
        # Should be re-polled because global interval elapsed
        assert "d2" in router._active

        await _kill_and_cleanup(router)

    async def test_queues_with_different_intervals_independent_schedules(self, make_adapter, tmp_path):
        """Queues with different intervals are polled independently."""
        board_data = {
            "queues": {
                "QueueA": [
                    {"id": "a1", "name": "A task", "description": "", "labels": [], "assignees": [], "comments": [], "tasks": []},
                ],
                "QueueB": [
                    {"id": "b1", "name": "B task", "description": "", "labels": [], "assignees": [], "comments": [], "tasks": []},
                ],
                "In Progress": [],
            }
        }
        json_path, adapter = make_adapter(board_data)
        router = Router(
            adapter,
            poll_interval=30,
            max_concurrent_agents=10,
            routes=[
                RouteConfig(queue_name="QueueA", command="sleep", args=["10"], in_progress_queue="In Progress", poll_interval=1),
                RouteConfig(queue_name="QueueB", command="sleep", args=["10"], in_progress_queue="In Progress", poll_interval=100),
            ],
        )

        # First poll picks up both
        await router._poll_once()
        assert "a1" in router._active
        assert "b1" in router._active

        # Add new tasks to both queues
        data = json.loads((tmp_path / "board.json").read_text())
        data["queues"]["QueueA"].append(
            {"id": "a2", "name": "A task 2", "description": "", "labels": [], "assignees": [], "comments": [], "tasks": []}
        )
        data["queues"]["QueueB"].append(
            {"id": "b2", "name": "B task 2", "description": "", "labels": [], "assignees": [], "comments": [], "tasks": []}
        )
        (tmp_path / "board.json").write_text(json.dumps(data))

        # Wait >1s so QueueA is due but QueueB is not
        await asyncio.sleep(1.1)

        await router._poll_once()

        # QueueA should be re-polled
        assert "a2" in router._active
        # QueueB should NOT be re-polled (100s hasn't elapsed)
        assert "b2" not in router._active

        await _kill_and_cleanup(router)

    def test_effective_poll_interval_helper(self, tmp_path):
        """_effective_poll_interval returns route value when set, global when not."""
        (tmp_path / "board.json").write_text(json.dumps({"queues": {"Q": [], "In Progress": []}}))
        adapter = JsonFileAdapter(tmp_path / "board.json")

        route_with = RouteConfig(queue_name="Q", command="echo", poll_interval=10)
        route_without = RouteConfig(queue_name="Q", command="echo")

        router = Router(
            adapter,
            poll_interval=30,
            max_concurrent_agents=1,
            routes=[route_with],
        )

        assert router._effective_poll_interval(route_with) == 10
        assert router._effective_poll_interval(route_without) == 30

    async def test_tick_interval_is_minimum_of_all_intervals(self, tmp_path):
        """_tick_interval should be the minimum of all effective poll intervals."""
        (tmp_path / "board.json").write_text(json.dumps({"queues": {"Fast": [], "Slow": [], "In Progress": []}}))
        adapter = JsonFileAdapter(tmp_path / "board.json")

        router = Router(
            adapter,
            poll_interval=60,
            max_concurrent_agents=1,
            routes=[
                RouteConfig(queue_name="Fast", command="echo", poll_interval=5),
                RouteConfig(queue_name="Slow", command="echo", poll_interval=120),
            ],
        )

        assert router._tick_interval == 5

    async def test_tick_interval_uses_global_when_no_routes_override(self, tmp_path):
        """_tick_interval falls back to global poll_interval when no routes override."""
        (tmp_path / "board.json").write_text(json.dumps({"queues": {"Q1": [], "Q2": [], "In Progress": []}}))
        adapter = JsonFileAdapter(tmp_path / "board.json")

        router = Router(
            adapter,
            poll_interval=45,
            max_concurrent_agents=1,
            routes=[
                RouteConfig(queue_name="Q1", command="echo"),
                RouteConfig(queue_name="Q2", command="echo"),
            ],
        )

        # Both routes use global default (45), so tick_interval = 45
        assert router._tick_interval == 45

    async def test_startup_logs_per_queue_intervals(self, make_adapter, caplog):
        """Router.run() should log the effective poll interval for each queue."""
        board_data = {
            "queues": {
                "Fast": [],
                "Normal": [],
                "In Progress": [],
            }
        }
        json_path, adapter = make_adapter(board_data)
        router = Router(
            adapter,
            poll_interval=30,
            max_concurrent_agents=1,
            routes=[
                RouteConfig(queue_name="Fast", command="echo", poll_interval=5),
                RouteConfig(queue_name="Normal", command="echo"),
            ],
        )

        with caplog.at_level(logging.INFO, logger="artificer.router"):
            # Run the router for a very short time, then cancel
            task = asyncio.create_task(router.run())
            await asyncio.sleep(0.1)
            task.cancel()
            try:
                await task
            except asyncio.CancelledError:
                pass

        # Verify startup logs
        assert any("tick every 5s" in r.message for r in caplog.records)
        assert any("'Fast'" in r.message and "poll every 5s" in r.message for r in caplog.records)
        assert any("'Normal'" in r.message and "poll every 30s" in r.message and "(global default)" in r.message for r in caplog.records)

    async def test_no_queues_due_skips_adapter_call(self, make_adapter):
        """When no queues are due, _poll_once should return early without calling get_ready_tasks."""
        board_data = {
            "queues": {
                "Slow": [],
                "In Progress": [],
            }
        }
        json_path, adapter = make_adapter(board_data)
        router = Router(
            adapter,
            poll_interval=100,
            max_concurrent_agents=10,
            routes=[
                RouteConfig(queue_name="Slow", command="echo", poll_interval=100),
            ],
        )

        # First poll is always due (timestamps start at 0.0)
        await router._poll_once()

        # Immediately poll again — should skip because 100s hasn't elapsed
        # We verify indirectly: _last_poll_times should not be updated
        first_poll_time = router._last_poll_times["Slow"]
        await router._poll_once()
        # _last_poll_times should be unchanged (no queues were due)
        assert router._last_poll_times["Slow"] == first_poll_time


@pytest.mark.asyncio
class TestPriorityOrdering:
    async def test_higher_priority_route_dispatched_first(self, make_adapter):
        """Route B (priority=0) should be dispatched before Route A (priority=1) when only 1 slot."""
        board_data = {
            "queues": {
                "QueueA": [
                    {"id": "a1", "name": "A task", "description": "", "labels": [], "assignees": [], "comments": [], "tasks": []},
                ],
                "QueueB": [
                    {"id": "b1", "name": "B task", "description": "", "labels": [], "assignees": [], "comments": [], "tasks": []},
                ],
                "In Progress": [],
            }
        }
        json_path, adapter = make_adapter(board_data)
        router = Router(
            adapter,
            poll_interval=1,
            max_concurrent_agents=1,
            routes=[
                RouteConfig(queue_name="QueueA", command="sleep", args=["10"], in_progress_queue="In Progress", priority=1),
                RouteConfig(queue_name="QueueB", command="sleep", args=["10"], in_progress_queue="In Progress", priority=0),
            ],
        )

        await router._poll_once()

        # Only 1 slot, so only 1 task should be active — and it should be from QueueB (priority=0)
        assert len(router._active) == 1
        assert "b1" in router._active

        await _kill_and_cleanup(router)

    async def test_default_priority_uses_registration_order(self, make_adapter):
        """Without explicit priority, tasks dispatch in registration order."""
        board_data = {
            "queues": {
                "First": [
                    {"id": "f1", "name": "First task", "description": "", "labels": [], "assignees": [], "comments": [], "tasks": []},
                ],
                "Second": [
                    {"id": "s1", "name": "Second task", "description": "", "labels": [], "assignees": [], "comments": [], "tasks": []},
                ],
                "In Progress": [],
            }
        }
        json_path, adapter = make_adapter(board_data)
        router = Router(
            adapter,
            poll_interval=1,
            max_concurrent_agents=1,
            routes=[
                RouteConfig(queue_name="First", command="sleep", args=["10"], in_progress_queue="In Progress"),
                RouteConfig(queue_name="Second", command="sleep", args=["10"], in_progress_queue="In Progress"),
            ],
        )

        await router._poll_once()

        # First-registered route (index 0) should be dispatched first
        assert len(router._active) == 1
        assert "f1" in router._active

        await _kill_and_cleanup(router)

    async def test_explicit_priority_overrides_registration_order(self, make_adapter):
        """Route B registered second but with priority=0 should dispatch before Route A (priority=10)."""
        board_data = {
            "queues": {
                "QueueA": [
                    {"id": "a1", "name": "A task", "description": "", "labels": [], "assignees": [], "comments": [], "tasks": []},
                ],
                "QueueB": [
                    {"id": "b1", "name": "B task", "description": "", "labels": [], "assignees": [], "comments": [], "tasks": []},
                ],
                "In Progress": [],
            }
        }
        json_path, adapter = make_adapter(board_data)
        router = Router(
            adapter,
            poll_interval=1,
            max_concurrent_agents=1,
            routes=[
                RouteConfig(queue_name="QueueA", command="sleep", args=["10"], in_progress_queue="In Progress", priority=10),
                RouteConfig(queue_name="QueueB", command="sleep", args=["10"], in_progress_queue="In Progress", priority=0),
            ],
        )

        await router._poll_once()

        # QueueB should be dispatched first despite being registered second
        assert len(router._active) == 1
        assert "b1" in router._active

        await _kill_and_cleanup(router)

    async def test_equal_priority_preserves_registration_order(self, make_adapter):
        """Two routes with equal priority should dispatch in registration order (stable sort)."""
        board_data = {
            "queues": {
                "First": [
                    {"id": "f1", "name": "First task", "description": "", "labels": [], "assignees": [], "comments": [], "tasks": []},
                ],
                "Second": [
                    {"id": "s1", "name": "Second task", "description": "", "labels": [], "assignees": [], "comments": [], "tasks": []},
                ],
                "In Progress": [],
            }
        }
        json_path, adapter = make_adapter(board_data)
        router = Router(
            adapter,
            poll_interval=1,
            max_concurrent_agents=1,
            routes=[
                RouteConfig(queue_name="First", command="sleep", args=["10"], in_progress_queue="In Progress", priority=5),
                RouteConfig(queue_name="Second", command="sleep", args=["10"], in_progress_queue="In Progress", priority=5),
            ],
        )

        await router._poll_once()

        # Both have priority 5; first-registered route's task should dispatch first
        assert len(router._active) == 1
        assert "f1" in router._active

        await _kill_and_cleanup(router)

    async def test_mixed_explicit_and_implicit_priorities(self, make_adapter):
        """Route A (no priority, index 0 -> effective 0) and Route B (priority=0) both have effective 0.
        Registration order (Route A first) preserved by stable sort."""
        board_data = {
            "queues": {
                "QueueA": [
                    {"id": "a1", "name": "A task", "description": "", "labels": [], "assignees": [], "comments": [], "tasks": []},
                ],
                "QueueB": [
                    {"id": "b1", "name": "B task", "description": "", "labels": [], "assignees": [], "comments": [], "tasks": []},
                ],
                "In Progress": [],
            }
        }
        json_path, adapter = make_adapter(board_data)
        router = Router(
            adapter,
            poll_interval=1,
            max_concurrent_agents=1,
            routes=[
                RouteConfig(queue_name="QueueA", command="sleep", args=["10"], in_progress_queue="In Progress"),
                RouteConfig(queue_name="QueueB", command="sleep", args=["10"], in_progress_queue="In Progress", priority=0),
            ],
        )

        await router._poll_once()

        # Both have effective priority 0; Route A registered first, so its task dispatches first
        assert len(router._active) == 1
        assert "a1" in router._active

        await _kill_and_cleanup(router)

    def test_route_priority_lookup_built_correctly(self, tmp_path):
        """Verify _route_priority dict is built correctly from mixed explicit and implicit priorities."""
        (tmp_path / "board.json").write_text(json.dumps({"queues": {"Q1": [], "Q2": [], "Q3": [], "In Progress": []}}))
        adapter = JsonFileAdapter(tmp_path / "board.json")

        router = Router(
            adapter,
            poll_interval=1,
            max_concurrent_agents=1,
            routes=[
                RouteConfig(queue_name="Q1", command="echo"),          # index 0, no priority -> effective 0
                RouteConfig(queue_name="Q2", command="echo", priority=5),  # explicit priority 5
                RouteConfig(queue_name="Q3", command="echo"),          # index 2, no priority -> effective 2
            ],
        )

        assert router._route_priority == {"Q1": 0, "Q2": 5, "Q3": 2}


@pytest.mark.asyncio
class TestErrorAndEdgeCases:
    async def test_poll_failure_does_not_crash_router(self, tmp_path, caplog):
        """When get_ready_tasks() raises during polling, the router logs the
        error and continues running instead of crashing."""

        class FailingAdapter(JsonFileAdapter):
            """JsonFileAdapter subclass that raises RuntimeError from
            get_ready_tasks() for the first N calls, then delegates."""

            def __init__(self, path, fail_count: int = 2):
                super().__init__(path)
                self._remaining_failures = fail_count

            def get_ready_tasks(self, queue_names):
                if self._remaining_failures > 0:
                    self._remaining_failures -= 1
                    raise RuntimeError("simulated poll failure")
                return super().get_ready_tasks(queue_names)

        board_data = {
            "queues": {
                "Bugs": [
                    {"id": "poll-1", "name": "Bug", "description": "", "labels": [], "assignees": [], "comments": [], "tasks": []},
                ],
                "In Progress": [],
            }
        }
        json_path = tmp_path / "board.json"
        json_path.write_text(json.dumps(board_data))
        adapter = FailingAdapter(json_path, fail_count=2)

        router = Router(
            adapter,
            poll_interval=1,
            max_concurrent_agents=1,
            routes=[
                RouteConfig(queue_name="Bugs", command="true", args=[], in_progress_queue="In Progress"),
            ],
        )

        with caplog.at_level(logging.ERROR, logger="artificer.router"):
            run_task = asyncio.create_task(router.run())
            # Wait long enough for at least 3 poll cycles (first 2 fail, third succeeds)
            await asyncio.sleep(2.5)

            # The router should still be alive (not crashed by the RuntimeError).
            assert not run_task.done(), "router.run() should still be running after poll failures"

            run_task.cancel()
            try:
                await run_task
            except asyncio.CancelledError:
                pass

        # The "Poll failed" error was logged (proves the exception path was hit)
        assert any("Poll failed" in r.message for r in caplog.records)

    async def test_no_matching_route_skips_task(self, make_adapter, tmp_path, caplog):
        """A task whose source_queue has no registered route is silently
        skipped with a warning log — no agent is spawned."""
        board_data = {
            "queues": {
                "Routed": [],
                "Unrouted": [
                    {"id": "unrouted-1", "name": "Lost task", "description": "", "labels": [], "assignees": [], "comments": [], "tasks": []},
                ],
                "In Progress": [],
            }
        }
        json_path, adapter = make_adapter(board_data)
        router = Router(
            adapter,
            poll_interval=1,
            max_concurrent_agents=2,
            routes=[
                RouteConfig(queue_name="Routed", command="true", args=[], in_progress_queue="In Progress"),
            ],
        )

        # Build a Task whose source_queue is "Unrouted" — no route registered for it.
        task = Task(id="unrouted-1", name="Lost task", source_queue="Unrouted")

        # Snapshot the board file before _spawn_agent
        board_before = (tmp_path / "board.json").read_text()

        with caplog.at_level(logging.WARNING, logger="artificer.router"):
            await router._spawn_agent(task)

        # No agent was spawned
        assert len(router._active) == 0
        # Board file was not modified
        assert (tmp_path / "board.json").read_text() == board_before
        # Warning was logged
        assert any("No route for queue" in r.message for r in caplog.records)

    async def test_force_kill_after_failed_terminate(self, make_adapter, tmp_path, caplog):
        """When a timed-out agent ignores SIGTERM, the router escalates to
        SIGKILL after the 5-second grace period and cleans up all internal state.

        Expected duration: ~6 seconds (1s timeout + 5s grace period + kill).
        """
        board_data = {
            "queues": {
                "Bugs": [
                    {"id": "stubborn-1", "name": "Stubborn task", "description": "", "labels": [], "assignees": [], "comments": [], "tasks": []},
                ],
                "In Progress": [],
            }
        }
        json_path, adapter = make_adapter(board_data)
        router = Router(
            adapter,
            poll_interval=1,
            max_concurrent_agents=1,
            routes=[
                RouteConfig(
                    queue_name="Bugs",
                    command="bash",
                    args=["-c", "trap '' TERM; sleep 60"],
                    in_progress_queue="In Progress",
                    timeout=1,
                ),
            ],
        )

        with caplog.at_level(logging.WARNING, logger="artificer.router"):
            await router._poll_once()
            assert "stubborn-1" in router._active

            # Wait for the monitor to complete (timeout + grace + kill)
            monitor = router._monitor_tasks["stubborn-1"]
            await monitor

        # All internal state should be cleaned up
        assert "stubborn-1" not in router._active
        assert "stubborn-1" not in router._monitor_tasks
        assert "stubborn-1" not in router._seen_ids
        # The force-kill warning was logged
        assert any("did not terminate gracefully, killing" in r.message for r in caplog.records)


@pytest.mark.asyncio
class TestRetryMechanism:
    async def test_no_retry_when_max_retries_zero(self, make_adapter, tmp_path):
        """Agent fails, max_retries=0 (default). Task stays in in-progress queue. No retry comment. Backward compat."""
        board_data = {
            "queues": {
                "Bugs": [
                    {"id": "no-retry-1", "name": "Failing task", "description": "", "labels": [], "assignees": [], "comments": [], "tasks": []},
                ],
                "In Progress": [],
            }
        }
        json_path, adapter = make_adapter(board_data)
        router = Router(
            adapter,
            poll_interval=1,
            max_concurrent_agents=1,
            routes=[
                RouteConfig(queue_name="Bugs", command="false", args=[], in_progress_queue="In Progress"),
            ],
        )

        await router._poll_once()
        assert "no-retry-1" in router._active

        monitor = router._monitor_tasks["no-retry-1"]
        await monitor

        assert "no-retry-1" not in router._active

        # Task should stay in In Progress (no retry)
        data = json.loads((tmp_path / "board.json").read_text())
        ip_ids = [t["id"] for t in data["queues"]["In Progress"]]
        bugs_ids = [t["id"] for t in data["queues"]["Bugs"]]
        assert "no-retry-1" in ip_ids
        assert "no-retry-1" not in bugs_ids
        # No retry comment
        task = next(t for t in data["queues"]["In Progress"] if t["id"] == "no-retry-1")
        assert not any("Retry" in c["text"] for c in task["comments"])

    async def test_retry_on_nonzero_exit(self, make_adapter, tmp_path):
        """max_retries=2, agent exits code 1. Task moved back to source queue, retry_count incremented to 1."""
        board_data = {
            "queues": {
                "Bugs": [
                    {"id": "retry-exit-1", "name": "Failing task", "description": "", "labels": [], "assignees": [], "comments": [], "tasks": []},
                ],
                "In Progress": [],
            }
        }
        json_path, adapter = make_adapter(board_data)
        router = Router(
            adapter,
            poll_interval=1,
            max_concurrent_agents=1,
            routes=[
                RouteConfig(queue_name="Bugs", command="false", args=[], in_progress_queue="In Progress", max_retries=2),
            ],
        )

        await router._poll_once()
        assert "retry-exit-1" in router._active

        monitor = router._monitor_tasks["retry-exit-1"]
        await monitor

        # Task should be moved back to Bugs
        data = json.loads((tmp_path / "board.json").read_text())
        bugs_ids = [t["id"] for t in data["queues"]["Bugs"]]
        assert "retry-exit-1" in bugs_ids

        # retry_count should be 1
        task = next(t for t in data["queues"]["Bugs"] if t["id"] == "retry-exit-1")
        assert task.get("retry_count") == 1

        # Retry comment should be present
        assert any("Retry 1/2" in c["text"] for c in task["comments"])
        assert any("exited with code" in c["text"] for c in task["comments"])

    async def test_retry_on_timeout(self, make_adapter, tmp_path):
        """max_retries=1, agent times out. Task moved back to source queue, retry_count=1."""
        board_data = {
            "queues": {
                "Bugs": [
                    {"id": "retry-timeout-1", "name": "Slow task", "description": "", "labels": [], "assignees": [], "comments": [], "tasks": []},
                ],
                "In Progress": [],
            }
        }
        json_path, adapter = make_adapter(board_data)
        router = Router(
            adapter,
            poll_interval=1,
            max_concurrent_agents=1,
            routes=[
                RouteConfig(queue_name="Bugs", command="sleep", args=["10"], in_progress_queue="In Progress", timeout=1, max_retries=1),
            ],
        )

        await router._poll_once()
        assert "retry-timeout-1" in router._active

        monitor = router._monitor_tasks["retry-timeout-1"]
        await monitor

        # Task should be moved back to Bugs
        data = json.loads((tmp_path / "board.json").read_text())
        bugs_ids = [t["id"] for t in data["queues"]["Bugs"]]
        assert "retry-timeout-1" in bugs_ids

        task = next(t for t in data["queues"]["Bugs"] if t["id"] == "retry-timeout-1")
        assert task.get("retry_count") == 1
        assert any("timed out" in c["text"] for c in task["comments"])

    async def test_exhausted_retries_with_dlq(self, make_adapter, tmp_path):
        """max_retries=1, task has retry_count=1. Agent fails. Task moved to dead-letter queue."""
        board_data = {
            "queues": {
                "Bugs": [
                    {"id": "dlq-1", "name": "Exhausted task", "description": "", "labels": [], "assignees": [], "comments": [], "tasks": [], "retry_count": 1},
                ],
                "In Progress": [],
                "Dead Letter": [],
            }
        }
        json_path, adapter = make_adapter(board_data)
        router = Router(
            adapter,
            poll_interval=1,
            max_concurrent_agents=1,
            routes=[
                RouteConfig(queue_name="Bugs", command="false", args=[], in_progress_queue="In Progress", max_retries=1, dead_letter_queue="Dead Letter"),
            ],
        )

        await router._poll_once()
        assert "dlq-1" in router._active

        monitor = router._monitor_tasks["dlq-1"]
        await monitor

        # Task should be in Dead Letter queue
        data = json.loads((tmp_path / "board.json").read_text())
        dlq_ids = [t["id"] for t in data["queues"]["Dead Letter"]]
        assert "dlq-1" in dlq_ids

        # Should have exhaustion comment
        task = next(t for t in data["queues"]["Dead Letter"] if t["id"] == "dlq-1")
        assert any("Max retries (1) exhausted" in c["text"] for c in task["comments"])
        assert any("dead-letter queue" in c["text"] for c in task["comments"])

    async def test_exhausted_retries_without_dlq(self, make_adapter, tmp_path):
        """max_retries=1, task has retry_count=1, no DLQ. Task stays in place."""
        board_data = {
            "queues": {
                "Bugs": [
                    {"id": "no-dlq-1", "name": "Exhausted task", "description": "", "labels": [], "assignees": [], "comments": [], "tasks": [], "retry_count": 1},
                ],
                "In Progress": [],
            }
        }
        json_path, adapter = make_adapter(board_data)
        router = Router(
            adapter,
            poll_interval=1,
            max_concurrent_agents=1,
            routes=[
                RouteConfig(queue_name="Bugs", command="false", args=[], in_progress_queue="In Progress", max_retries=1),
            ],
        )

        await router._poll_once()
        assert "no-dlq-1" in router._active

        monitor = router._monitor_tasks["no-dlq-1"]
        await monitor

        # Task should stay in In Progress (not moved back to Bugs, not moved to DLQ)
        data = json.loads((tmp_path / "board.json").read_text())
        ip_ids = [t["id"] for t in data["queues"]["In Progress"]]
        assert "no-dlq-1" in ip_ids

        # Should have exhaustion comment
        task = next(t for t in data["queues"]["In Progress"] if t["id"] == "no-dlq-1")
        assert any("Max retries (1) exhausted" in c["text"] for c in task["comments"])
        assert any("No dead-letter queue configured" in c["text"] for c in task["comments"])

    async def test_retry_count_persisted_in_json_adapter(self, make_adapter, tmp_path):
        """After retry, verify JSON file has updated retry_count."""
        board_data = {
            "queues": {
                "Bugs": [
                    {"id": "persist-1", "name": "Retry task", "description": "", "labels": [], "assignees": [], "comments": [], "tasks": []},
                ],
                "In Progress": [],
            }
        }
        json_path, adapter = make_adapter(board_data)
        router = Router(
            adapter,
            poll_interval=1,
            max_concurrent_agents=1,
            routes=[
                RouteConfig(queue_name="Bugs", command="false", args=[], in_progress_queue="In Progress", max_retries=3),
            ],
        )

        await router._poll_once()
        monitor = router._monitor_tasks["persist-1"]
        await monitor

        data = json.loads((tmp_path / "board.json").read_text())
        task = next(t for t in data["queues"]["Bugs"] if t["id"] == "persist-1")
        assert task["retry_count"] == 1

    async def test_no_retry_on_successful_exit(self, make_adapter, tmp_path):
        """Agent exits 0 with retries configured. No retry."""
        board_data = {
            "queues": {
                "Bugs": [
                    {"id": "success-1", "name": "Good task", "description": "", "labels": [], "assignees": [], "comments": [], "tasks": []},
                ],
                "In Progress": [],
            }
        }
        json_path, adapter = make_adapter(board_data)
        router = Router(
            adapter,
            poll_interval=1,
            max_concurrent_agents=1,
            routes=[
                RouteConfig(queue_name="Bugs", command="true", args=[], in_progress_queue="In Progress", max_retries=3),
            ],
        )

        await router._poll_once()
        monitor = router._monitor_tasks["success-1"]
        await monitor

        # Task should stay in In Progress (success, no retry)
        data = json.loads((tmp_path / "board.json").read_text())
        ip_ids = [t["id"] for t in data["queues"]["In Progress"]]
        bugs_ids = [t["id"] for t in data["queues"]["Bugs"]]
        assert "success-1" in ip_ids
        assert "success-1" not in bugs_ids
        # No retry comment
        task = next(t for t in data["queues"]["In Progress"] if t["id"] == "success-1")
        assert not any("Retry" in c["text"] for c in task["comments"])

    async def test_no_retry_on_cancellation(self, make_adapter, tmp_path):
        """Router cancelled during agent run. No retry."""
        board_data = {
            "queues": {
                "Bugs": [
                    {"id": "cancel-1", "name": "Cancelled task", "description": "", "labels": [], "assignees": [], "comments": [], "tasks": []},
                ],
                "In Progress": [],
            }
        }
        json_path, adapter = make_adapter(board_data)
        router = Router(
            adapter,
            poll_interval=1,
            max_concurrent_agents=1,
            routes=[
                RouteConfig(queue_name="Bugs", command="sleep", args=["60"], in_progress_queue="In Progress", max_retries=3),
            ],
        )

        await router._poll_once()
        assert "cancel-1" in router._active

        # Cancel the monitor task (simulating router shutdown)
        monitor = router._monitor_tasks["cancel-1"]
        monitor.cancel()
        try:
            await monitor
        except asyncio.CancelledError:
            pass

        # Task should stay in In Progress (cancelled, no retry)
        data = json.loads((tmp_path / "board.json").read_text())
        ip_ids = [t["id"] for t in data["queues"]["In Progress"]]
        bugs_ids = [t["id"] for t in data["queues"]["Bugs"]]
        assert "cancel-1" in ip_ids
        assert "cancel-1" not in bugs_ids

    async def test_route_level_overrides_dispatcher_level(self, tmp_path):
        """Route max_retries=3 overrides dispatcher max_retries=1."""
        (tmp_path / "board.json").write_text(json.dumps({"queues": {"Q": [], "In Progress": []}}))
        adapter = JsonFileAdapter(tmp_path / "board.json")

        route_with = RouteConfig(queue_name="Q", command="echo", max_retries=3)
        route_without = RouteConfig(queue_name="Q", command="echo")

        router = Router(
            adapter,
            poll_interval=1,
            max_concurrent_agents=1,
            routes=[route_with],
            default_max_retries=1,
        )

        assert router._effective_max_retries(route_with) == 3
        assert router._effective_max_retries(route_without) == 1

    async def test_dispatcher_level_used_as_fallback(self, tmp_path):
        """Route doesn't set max_retries, dispatcher value used."""
        (tmp_path / "board.json").write_text(json.dumps({"queues": {"Q": [], "In Progress": []}}))
        adapter = JsonFileAdapter(tmp_path / "board.json")

        route = RouteConfig(queue_name="Q", command="echo")

        router = Router(
            adapter,
            poll_interval=1,
            max_concurrent_agents=1,
            routes=[route],
            default_max_retries=5,
            default_dead_letter_queue="DLQ",
        )

        assert router._effective_max_retries(route) == 5
        assert router._effective_dead_letter_queue(route) == "DLQ"
