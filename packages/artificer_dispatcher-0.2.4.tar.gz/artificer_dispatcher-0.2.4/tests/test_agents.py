from __future__ import annotations

import asyncio
from pathlib import Path
from unittest.mock import MagicMock, call

import pytest

from artificer.adapters.base import Task
from artificer.agents.claude import ClaudeAgentAdapter
from artificer.agents.default import DefaultAgentAdapter
from artificer.config import RouteConfig
from artificer.router import AgentProcess

PROJECT_ROOT = Path(__file__).resolve().parent.parent


def _make_agent_process(task_id: str = "1", command: str = "test") -> AgentProcess:
    """Helper to create a mock AgentProcess."""
    process = MagicMock(spec=asyncio.subprocess.Process)
    process.returncode = 0
    return AgentProcess(task_id=task_id, process=process, command=command)


def _make_task(task_id: str = "1", name: str = "Test task") -> Task:
    """Helper to create a Task."""
    return Task(id=task_id, name=name, description="Test description")


def _make_route(command: str = "test") -> RouteConfig:
    """Helper to create a RouteConfig."""
    return RouteConfig(queue_name="Test Queue", command=command, args=[])


class TestDefaultAgentAdapter:
    """Tests for DefaultAgentAdapter."""

    def test_augment_command_returns_unchanged(self):
        adapter = DefaultAgentAdapter()
        route = _make_route()
        cmd = ["test", "arg1", "arg2"]
        result = adapter.augment_command(cmd, route)
        assert result == ["test", "arg1", "arg2"]
        assert result is cmd  # Should return the same list

    def test_process_stdout_line_is_noop(self):
        adapter = DefaultAgentAdapter()
        agent = _make_agent_process()
        task = _make_task()
        task_adapter = MagicMock()

        # Should not raise or do anything
        adapter.process_stdout_line("test output", agent, task, task_adapter)
        task_adapter.add_comment.assert_not_called()

    def test_format_spawn_comment(self):
        adapter = DefaultAgentAdapter()
        comment = adapter.format_spawn_comment("test command")
        assert comment == "Spawning agent with command `test command`"

    def test_format_exit_comment_timeout(self):
        adapter = DefaultAgentAdapter()
        agent = _make_agent_process()
        comment = adapter.format_exit_comment(agent, timed_out=True, timeout=60, error_snippet="", last_message="")
        assert "timed out after 60s" in comment

    def test_format_exit_comment_cancelled(self):
        adapter = DefaultAgentAdapter()
        agent = _make_agent_process()
        agent.process.returncode = None
        comment = adapter.format_exit_comment(agent, timed_out=False, timeout=None, error_snippet="", last_message="")
        assert "cancelled" in comment

    def test_format_exit_comment_success(self):
        adapter = DefaultAgentAdapter()
        agent = _make_agent_process()
        agent.process.returncode = 0
        comment = adapter.format_exit_comment(agent, timed_out=False, timeout=None, error_snippet="", last_message="")
        assert "exit 0" in comment

    def test_format_exit_comment_error(self):
        adapter = DefaultAgentAdapter()
        agent = _make_agent_process()
        agent.process.returncode = 1
        comment = adapter.format_exit_comment(
            agent, timed_out=False, timeout=None, error_snippet="Error occurred", last_message=""
        )
        assert "exit code 1" in comment
        assert "Error occurred" in comment

    def test_get_status_extras_empty(self):
        adapter = DefaultAgentAdapter()
        agent = _make_agent_process()
        extras = adapter.get_status_extras(agent)
        assert extras == {}


class TestClaudeAgentAdapter:
    """Tests for ClaudeAgentAdapter."""

    def test_augment_command_adds_flags(self):
        adapter = ClaudeAgentAdapter()
        route = _make_route("claude")
        cmd = ["claude", "--agent", "test"]
        result = adapter.augment_command(cmd, route)

        assert "-p" in result
        assert "--output-format" in result
        assert "stream-json" in result
        assert "--verbose" in result

    def test_augment_command_skips_p_if_present(self):
        adapter = ClaudeAgentAdapter()
        route = _make_route("claude")
        cmd = ["claude", "-p", "--agent", "test"]
        result = adapter.augment_command(cmd, route)

        # Should not add another -p
        assert result.count("-p") == 1
        assert "--output-format" in result

    def test_augment_command_skips_p_if_print_present(self):
        adapter = ClaudeAgentAdapter()
        route = _make_route("claude")
        cmd = ["claude", "--print", "--agent", "test"]
        result = adapter.augment_command(cmd, route)

        # Should not add -p if --print is present
        assert "-p" not in result
        assert "--print" in result
        assert "--output-format" in result

    def test_process_stdout_line_extracts_session_id(self):
        adapter = ClaudeAgentAdapter()
        agent = _make_agent_process()
        task = _make_task()
        task_adapter = MagicMock()

        # Simulate stream-json output with session_id
        line = '{"session_id": "abc123", "type": "init"}'
        adapter.process_stdout_line(line, agent, task, task_adapter)

        assert agent.session_id == "abc123"
        task_adapter.add_comment.assert_called_once_with("1", "Claude conversation: `abc123`")

    def test_process_stdout_line_extracts_assistant_message(self):
        adapter = ClaudeAgentAdapter()
        agent = _make_agent_process()
        task = _make_task()
        task_adapter = MagicMock()

        # Simulate assistant message
        line = '{"type": "assistant", "message": {"content": [{"type": "text", "text": "Hello world"}]}}'
        adapter.process_stdout_line(line, agent, task, task_adapter)

        assert adapter._last_assistant_msg["1"] == "Hello world"

    def test_process_stdout_line_handles_multiple_text_blocks(self):
        adapter = ClaudeAgentAdapter()
        agent = _make_agent_process()
        task = _make_task()
        task_adapter = MagicMock()

        # Multiple text blocks
        line = '{"type": "assistant", "message": {"content": [{"type": "text", "text": "Part 1"}, {"type": "text", "text": "Part 2"}]}}'
        adapter.process_stdout_line(line, agent, task, task_adapter)

        assert adapter._last_assistant_msg["1"] == "Part 1\nPart 2"

    def test_process_stdout_line_ignores_non_text_blocks(self):
        adapter = ClaudeAgentAdapter()
        agent = _make_agent_process()
        task = _make_task()
        task_adapter = MagicMock()

        # Mixed content blocks
        line = '{"type": "assistant", "message": {"content": [{"type": "text", "text": "Text"}, {"type": "tool_use", "name": "foo"}]}}'
        adapter.process_stdout_line(line, agent, task, task_adapter)

        assert adapter._last_assistant_msg["1"] == "Text"

    def test_process_stdout_line_handles_malformed_json(self):
        adapter = ClaudeAgentAdapter()
        agent = _make_agent_process()
        task = _make_task()
        task_adapter = MagicMock()

        # Should not raise
        adapter.process_stdout_line("not json", agent, task, task_adapter)
        adapter.process_stdout_line("{invalid json", agent, task, task_adapter)
        task_adapter.add_comment.assert_not_called()

    def test_process_stdout_line_handles_empty_line(self):
        adapter = ClaudeAgentAdapter()
        agent = _make_agent_process()
        task = _make_task()
        task_adapter = MagicMock()

        # Should not raise
        adapter.process_stdout_line("", agent, task, task_adapter)
        task_adapter.add_comment.assert_not_called()

    def test_format_spawn_comment(self):
        adapter = ClaudeAgentAdapter()
        comment = adapter.format_spawn_comment("claude test")
        assert comment == "Spawning agent with command `claude test`"

    def test_format_exit_comment_includes_last_message(self):
        adapter = ClaudeAgentAdapter()
        agent = _make_agent_process()
        agent.process.returncode = 0
        adapter._last_assistant_msg["1"] = "Agent finished working"

        comment = adapter.format_exit_comment(agent, timed_out=False, timeout=None, error_snippet="", last_message="")

        assert "exit 0" in comment
        assert "Last agent message:" in comment
        assert "Agent finished working" in comment
        # Should clean up tracking
        assert "1" not in adapter._last_assistant_msg

    def test_format_exit_comment_includes_resume_hint(self):
        adapter = ClaudeAgentAdapter()
        agent = _make_agent_process()
        agent.process.returncode = 0
        agent.session_id = "abc123"

        comment = adapter.format_exit_comment(agent, timed_out=False, timeout=None, error_snippet="", last_message="")

        assert "Resume session: `claude resume abc123`" in comment

    def test_format_exit_comment_truncates_long_message(self):
        adapter = ClaudeAgentAdapter()
        agent = _make_agent_process()
        agent.process.returncode = 0
        adapter._last_assistant_msg["1"] = "x" * 2000

        comment = adapter.format_exit_comment(agent, timed_out=False, timeout=None, error_snippet="", last_message="")

        # Should truncate to 1000 chars
        assert len(comment.split("Last agent message:\n")[1].split("\n")[0]) == 1000

    def test_format_exit_comment_uses_fallback_last_message(self):
        adapter = ClaudeAgentAdapter()
        agent = _make_agent_process()
        agent.process.returncode = 0

        comment = adapter.format_exit_comment(
            agent, timed_out=False, timeout=None, error_snippet="", last_message="Fallback message"
        )

        # Should include fallback since there's no tracked message
        assert "Fallback message" in comment

    def test_format_exit_comment_timeout_with_session(self):
        adapter = ClaudeAgentAdapter()
        agent = _make_agent_process()
        agent.session_id = "xyz789"
        adapter._last_assistant_msg["1"] = "Working on it..."

        comment = adapter.format_exit_comment(agent, timed_out=True, timeout=60, error_snippet="", last_message="")

        assert "timed out after 60s" in comment
        assert "Working on it..." in comment
        assert "Resume session: `claude resume xyz789`" in comment

    def test_get_status_extras_with_session_id(self):
        adapter = ClaudeAgentAdapter()
        agent = _make_agent_process()
        agent.session_id = "session123"

        extras = adapter.get_status_extras(agent)

        assert extras == {"session_id": "session123"}

    def test_get_status_extras_without_session_id(self):
        adapter = ClaudeAgentAdapter()
        agent = _make_agent_process()

        extras = adapter.get_status_extras(agent)

        assert extras == {}

    def test_multiple_tasks_tracked_separately(self):
        """Test that last_assistant_msg is tracked per-task."""
        adapter = ClaudeAgentAdapter()
        agent1 = _make_agent_process(task_id="1")
        agent2 = _make_agent_process(task_id="2")
        task1 = _make_task(task_id="1")
        task2 = _make_task(task_id="2")
        task_adapter = MagicMock()

        # Process messages for different tasks
        line1 = '{"type": "assistant", "message": {"content": [{"type": "text", "text": "Task 1 message"}]}}'
        line2 = '{"type": "assistant", "message": {"content": [{"type": "text", "text": "Task 2 message"}]}}'

        adapter.process_stdout_line(line1, agent1, task1, task_adapter)
        adapter.process_stdout_line(line2, agent2, task2, task_adapter)

        assert adapter._last_assistant_msg["1"] == "Task 1 message"
        assert adapter._last_assistant_msg["2"] == "Task 2 message"

        # Format exit for task 1
        comment1 = adapter.format_exit_comment(agent1, False, None, "", "")
        assert "Task 1 message" in comment1
        assert "1" not in adapter._last_assistant_msg

        # Task 2's message should still be there
        assert adapter._last_assistant_msg["2"] == "Task 2 message"


class TestResearchAgentDefinition:
    """Tests for the research agent definition file."""

    def _parse_frontmatter(self, content: str) -> dict[str, str]:
        """Parse frontmatter from agent markdown file."""
        parts = content.split("---", 2)
        if len(parts) < 3:
            return {}

        frontmatter = {}
        frontmatter_text = parts[1].strip()
        for line in frontmatter_text.split("\n"):
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            if ":" in line:
                key, value = line.split(":", 1)
                frontmatter[key.strip()] = value.strip()
        return frontmatter

    def test_research_agent_definition_exists(self):
        """Test that the research agent definition file exists and is readable."""
        agent_file = PROJECT_ROOT / ".claude/agents/research.md"
        assert agent_file.exists(), "research.md agent definition file should exist"
        assert agent_file.is_file(), "research.md should be a file"
        content = agent_file.read_text()
        assert len(content) > 0, "research.md should not be empty"

    def test_research_agent_frontmatter_valid(self):
        """Test that the research agent frontmatter contains required fields."""
        agent_file = PROJECT_ROOT / ".claude/agents/research.md"
        content = agent_file.read_text()

        # Extract frontmatter between --- delimiters
        parts = content.split("---", 2)
        assert len(parts) >= 3, "Agent file should have frontmatter delimited by ---"

        frontmatter_text = parts[1].strip()

        # Check required fields are present in frontmatter
        assert "name: research" in frontmatter_text, "Agent name should be 'research'"
        assert "description:" in frontmatter_text, "Agent should have a description"
        assert "Conducts research and analysis" in frontmatter_text, \
            "Description should mention research and analysis"
        assert "model: sonnet" in frontmatter_text, "Research agent should use sonnet model"
        assert "maxTurns: 30" in frontmatter_text, "Research agent should have maxTurns set to 30"

    def test_research_agent_has_correct_tools(self):
        """Test that the research agent has the correct tools configured."""
        agent_file = PROJECT_ROOT / ".claude/agents/research.md"
        content = agent_file.read_text()
        parts = content.split("---", 2)
        frontmatter_text = parts[1].strip()

        # Check tools line exists
        assert "tools:" in frontmatter_text, "Agent should specify tools"

        # Research agent should have read-only exploration tools
        expected_tools = ["Read", "Grep", "Glob", "WebSearch", "WebFetch", "Bash"]
        for tool in expected_tools:
            assert tool in frontmatter_text, f"Research agent should have {tool} tool"

    def test_research_agent_disallows_write_and_edit(self):
        """Test that the research agent disallows Write and Edit tools."""
        agent_file = PROJECT_ROOT / ".claude/agents/research.md"
        content = agent_file.read_text()
        parts = content.split("---", 2)
        frontmatter_text = parts[1].strip()

        # Check disallowedTools
        assert "disallowedTools:" in frontmatter_text, "Agent should specify disallowedTools"
        assert "Write" in frontmatter_text, "Research agent should disallow Write"
        assert "Edit" in frontmatter_text, "Research agent should disallow Edit"

    def test_research_agent_has_task_router_skill(self):
        """Test that the research agent has the task-router skill."""
        agent_file = PROJECT_ROOT / ".claude/agents/research.md"
        content = agent_file.read_text()
        parts = content.split("---", 2)
        frontmatter_text = parts[1].strip()

        # Check skills
        assert "skills:" in frontmatter_text, "Agent should specify skills"
        assert "task-router" in frontmatter_text, "Research agent should have task-router skill"

    def test_research_agent_workflow_includes_critical_exit_requirement(self):
        """Test that the research agent workflow includes the critical exit requirement."""
        agent_file = PROJECT_ROOT / ".claude/agents/research.md"
        content = agent_file.read_text()

        # Check for critical section
        assert "CRITICAL: You MUST move the task before exiting" in content, \
            "Agent should have critical exit requirement section"

        # Check that it mentions moving to Done queue
        assert "Research.Done" in content, \
            "Agent should reference the Research.Done queue"

        # Check that it mentions the scenario where task must be moved
        assert "no scenario where you exit without moving the task" in content.lower(), \
            "Agent should emphasize always moving the task"
