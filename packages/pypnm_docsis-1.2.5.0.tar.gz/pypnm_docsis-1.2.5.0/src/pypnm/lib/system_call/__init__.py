# SPDX-License-Identifier: Apache-2.0
# Copyright (c) 2026 Maurice Garcia

from pypnm.lib.system_call.manager import SystemCall

__all__ = ["SystemCall"]
