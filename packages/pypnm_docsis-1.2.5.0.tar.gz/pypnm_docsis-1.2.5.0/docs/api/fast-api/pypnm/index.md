# PyPNM  Systems and Operations Guide

| Guide | Description  |
| ----- | ------------ |
| [DataBase](db/data-base.md)   | Repository layout, file ledgers, capture groups, and operation linking for traceability and exports. |
| [System](system/index.md)     | Platform overview, configuration, deployment notes, and service topology.                            |
