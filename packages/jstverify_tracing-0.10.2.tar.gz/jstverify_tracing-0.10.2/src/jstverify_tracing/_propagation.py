"""Helpers for propagating trace context into outgoing SQS / EventBridge messages."""

from ._context import get_current_context


def sqs_message_attributes():
    """Return SQS MessageAttributes dict for trace context propagation.

    Merge the returned dict into your ``MessageAttributes`` when calling
    ``sqs.send_message()`` or ``sqs.send_message_batch()``:

        attrs = {"MyAttr": {"DataType": "String", "StringValue": "value"}}
        attrs.update(propagation.sqs_message_attributes())
        sqs.send_message(QueueUrl=url, MessageBody=body, MessageAttributes=attrs)

    Returns an empty dict when no trace context is active.
    """
    ctx = get_current_context()
    if ctx is None:
        return {}

    attrs = {
        "JstVerifyTraceId": {
            "DataType": "String",
            "StringValue": ctx.trace_id,
        },
    }
    if ctx.span_id:
        attrs["JstVerifyParentSpanId"] = {
            "DataType": "String",
            "StringValue": ctx.span_id,
        }
    return attrs


def eventbridge_trace_context():
    """Return a dict to merge into EventBridge ``Detail`` for trace propagation.

    Merge the returned dict into your event detail before calling
    ``events.put_events()``:

        detail = {"orderId": "123", "status": "processed"}
        detail.update(propagation.eventbridge_trace_context())
        events.put_events(Entries=[{
            "Source": "myapp",
            "DetailType": "OrderProcessed",
            "Detail": json.dumps(detail),
        }])

    Returns an empty dict when no trace context is active.
    """
    ctx = get_current_context()
    if ctx is None:
        return {}

    trace_ctx = {"traceId": ctx.trace_id}
    if ctx.span_id:
        trace_ctx["parentSpanId"] = ctx.span_id

    return {"_traceContext": trace_ctx}
