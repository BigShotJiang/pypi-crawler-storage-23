"""Monkey-patch boto3.client() and boto3.resource() to auto-instrument AWS API calls."""

import threading
import time
import logging

from ._context import start_child_context, pop_context, get_current_context
from ._source_location import from_first_user_frame

logger = logging.getLogger("jstverify_tracing")

_original_client = None
_original_resource = None
_original_session_client = None
_original_session_resource = None
_patched = False
_services_filter = None  # True = all, or list of lowercase service names

_thread_local = threading.local()

# Map service → api_params key that identifies the resource being operated on
_RESOURCE_KEY = {
    "dynamodb": "TableName",
    "s3": "Bucket",
    "sqs": "QueueUrl",
    "sns": "TopicArn",
    "lambda": "FunctionName",
    "kinesis": "StreamName",
    "secretsmanager": "SecretId",
    "ssm": "Name",
}

# Human-friendly display names for AWS services
_SERVICE_DISPLAY_NAMES = {
    "dynamodb": "DynamoDB",
    "s3": "S3",
    "sqs": "SQS",
    "sns": "SNS",
    "sts": "STS",
    "ssm": "SSM",
    "lambda": "Lambda",
    "kinesis": "Kinesis",
    "secretsmanager": "SecretsManager",
    "cloudwatch": "CloudWatch",
    "events": "EventBridge",
    "stepfunctions": "StepFunctions",
    "ses": "SES",
    "cognito-idp": "CognitoIDP",
}


def set_manual_dynamodb_trace(active):
    """Set thread-local flag indicating we're inside a manual trace_dynamodb() call."""
    _thread_local.manual_dynamodb = active


def _in_manual_dynamodb_trace():
    return getattr(_thread_local, "manual_dynamodb", False)


def _extract_resource_name(service_name, operation_name, api_params):
    """Extract the resource name (table, bucket, queue, etc.) from api_params."""
    key = _RESOURCE_KEY.get(service_name)
    if key is None:
        return None

    value = api_params.get(key)
    if value is None:
        return None

    # SQS: extract queue name from URL (last path segment)
    if service_name == "sqs" and "/" in value:
        return value.rsplit("/", 1)[-1]

    # SNS: extract topic name from ARN (last colon segment)
    if service_name == "sns" and ":" in value:
        return value.rsplit(":", 1)[-1]

    return value


def _wrap_client(client):
    """Wrap client._make_api_call to emit a span for each AWS API call."""
    # Avoid double-wrapping
    if getattr(client, "_jstverify_patched", False):
        return client

    original_make_api_call = client._make_api_call
    service_name = client.meta.service_model.service_name  # e.g. "dynamodb", "s3"

    def patched_make_api_call(operation_name, api_params):
        from ._config import JstVerifyTracing

        instance = JstVerifyTracing.get_instance()

        # Skip if SDK not initialized
        if instance is None:
            return original_make_api_call(operation_name, api_params)

        # Skip if no active trace context
        current = get_current_context()
        if current is None:
            return original_make_api_call(operation_name, api_params)

        # Skip if service is filtered out
        if _services_filter is not True:
            if _services_filter is None or service_name not in _services_filter:
                return original_make_api_call(operation_name, api_params)

        # Skip DynamoDB if inside manual trace_dynamodb() to avoid double-tracing
        if service_name == "dynamodb" and _in_manual_dynamodb_trace():
            return original_make_api_call(operation_name, api_params)

        location = from_first_user_frame()
        ctx = start_child_context()
        start_time = int(time.time() * 1000)
        status_code = 200
        status_message = None
        http_status_code = None

        display_name = _SERVICE_DISPLAY_NAMES.get(service_name, service_name)
        resource_name = _extract_resource_name(service_name, operation_name, api_params)
        op_label = f"{display_name}.{operation_name}"
        if resource_name:
            op_label = f"{op_label} {resource_name}"

        service_type = service_name if service_name in _RESOURCE_KEY or service_name in _SERVICE_DISPLAY_NAMES else "aws"

        try:
            result = original_make_api_call(operation_name, api_params)
            metadata = result.get("ResponseMetadata")
            if metadata:
                http_status_code = metadata.get("HTTPStatusCode")
            return result
        except Exception as e:
            status_code = 500
            status_message = str(e)
            raise
        finally:
            end_time = int(time.time() * 1000)
            span = {
                "traceId": ctx.trace_id,
                "spanId": ctx.span_id,
                "parentSpanId": ctx.parent_span_id,
                "operationName": op_label,
                "serviceName": resource_name or service_name,
                "serviceType": service_type,
                "startTime": start_time,
                "endTime": end_time,
                "duration": end_time - start_time,
                "statusCode": status_code,
            }
            if status_message is not None:
                span["statusMessage"] = status_message
            if http_status_code is not None:
                span["httpStatusCode"] = http_status_code
            span.update(location)
            from ._span import _enqueue
            _enqueue(instance, span)
            pop_context()

    client._make_api_call = patched_make_api_call
    client._jstverify_patched = True
    return client


def _wrap_resource(resource):
    """Wrap the underlying client of a boto3 resource."""
    if hasattr(resource, "meta") and hasattr(resource.meta, "client"):
        _wrap_client(resource.meta.client)
    return resource


def patch_boto(services):
    """Monkey-patch boto3.client() and boto3.resource() to auto-instrument AWS calls.

    Also patches boto3.Session.client() and boto3.Session.resource() so that
    clients created via ``boto3.session.Session().client(...)`` are instrumented.

    Args:
        services: True to instrument all services, or a list of service names
                  (e.g. ["dynamodb", "s3"]) to instrument selectively.
    """
    global _original_client, _original_resource, _patched, _services_filter
    global _original_session_client, _original_session_resource

    if _patched:
        return

    import boto3

    _original_client = boto3.client
    _original_resource = boto3.resource
    _original_session_client = boto3.Session.client
    _original_session_resource = boto3.Session.resource

    if services is True:
        _services_filter = True
    elif isinstance(services, (list, tuple)):
        _services_filter = [s.lower() for s in services]
    else:
        _services_filter = True

    def patched_client(*args, **kwargs):
        client = _original_client(*args, **kwargs)
        _wrap_client(client)
        return client

    def patched_resource(*args, **kwargs):
        resource = _original_resource(*args, **kwargs)
        _wrap_resource(resource)
        return resource

    def patched_session_client(self, *args, **kwargs):
        client = _original_session_client(self, *args, **kwargs)
        _wrap_client(client)
        return client

    def patched_session_resource(self, *args, **kwargs):
        resource = _original_session_resource(self, *args, **kwargs)
        _wrap_resource(resource)
        return resource

    boto3.client = patched_client
    boto3.resource = patched_resource
    boto3.Session.client = patched_session_client
    boto3.Session.resource = patched_session_resource
    _patched = True


def unpatch_boto():
    """Restore the original boto3.client() and boto3.resource() (for testing)."""
    global _original_client, _original_resource, _patched, _services_filter
    global _original_session_client, _original_session_resource

    if not _patched:
        return

    import boto3

    if _original_client is not None:
        boto3.client = _original_client
    if _original_resource is not None:
        boto3.resource = _original_resource
    if _original_session_client is not None:
        boto3.Session.client = _original_session_client
    if _original_session_resource is not None:
        boto3.Session.resource = _original_session_resource

    _original_client = None
    _original_resource = None
    _original_session_client = None
    _original_session_resource = None
    _services_filter = None
    _patched = False
