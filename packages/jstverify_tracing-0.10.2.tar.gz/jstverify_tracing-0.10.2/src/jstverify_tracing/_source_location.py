"""Capture source code location for spans.

Three strategies:
1. from_code_object(code) - for @trace decorator, Lambda/AppSync middleware
2. from_caller(depth) - for trace_span() and trace_dynamodb()
3. from_first_user_frame() - for boto3/requests auto-patches
"""

import inspect
import os

_SDK_DIR = os.path.dirname(os.path.abspath(__file__))


def _module_from_file(filepath):
    """Convert a file path to a dotted module name.

    Strips /var/task/ prefix (Lambda environment) and converts
    path separators to dots.
    """
    if not filepath:
        return None
    path = filepath
    if path.startswith("/var/task/"):
        path = path[len("/var/task/"):]
    if path.endswith(".py"):
        path = path[:-3]
    return path.replace(os.sep, ".").replace("/", ".")


def from_code_object(code):
    """Extract location from a function's __code__ object."""
    if code is None:
        return {}
    return {
        "sourceFile": code.co_filename,
        "sourceFunction": code.co_name,
        "sourceLine": code.co_firstlineno,
        "sourceModule": _module_from_file(code.co_filename),
    }


def from_caller(depth=1):
    """Walk frame.f_back *depth* levels from the caller to find the call site."""
    frame = inspect.currentframe()
    if frame is None:
        return {}
    try:
        for _ in range(depth):
            frame = frame.f_back
            if frame is None:
                return {}
        return {
            "sourceFile": frame.f_code.co_filename,
            "sourceFunction": frame.f_code.co_name,
            "sourceLine": frame.f_lineno,
            "sourceModule": _module_from_file(frame.f_code.co_filename),
        }
    finally:
        del frame


def from_first_user_frame():
    """Walk the stack until we leave the SDK package directory."""
    frame = inspect.currentframe()
    if frame is None:
        return {}
    try:
        frame = frame.f_back  # skip this function
        while frame is not None:
            filename = os.path.abspath(frame.f_code.co_filename)
            if not filename.startswith(_SDK_DIR):
                return {
                    "sourceFile": frame.f_code.co_filename,
                    "sourceFunction": frame.f_code.co_name,
                    "sourceLine": frame.f_lineno,
                    "sourceModule": _module_from_file(frame.f_code.co_filename),
                }
            frame = frame.f_back
        return {}
    finally:
        del frame
