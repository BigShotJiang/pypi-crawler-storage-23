"""Per-request relay buffer for transporting spans via response headers."""

import base64
import json
import logging
from contextvars import ContextVar
from typing import List, Optional

from ._types import SpanData

logger = logging.getLogger("jstverify_tracing")

HEADER_NAME = "X-JstVerify-Spans"
MAX_HEADER_BYTES = 7500

# Mutable list reference shared across context copies (async-safe)
_relay_spans: ContextVar[Optional[List[SpanData]]] = ContextVar(
    "_relay_spans", default=None
)


def _get_or_create_buffer() -> List[SpanData]:
    """Get (or lazily create) the per-request span list."""
    buf = _relay_spans.get()
    if buf is None:
        buf = []
        _relay_spans.set(buf)
    return buf


def enqueue_relay_span(span: SpanData) -> None:
    """Append a span to the current request's relay buffer."""
    from ._config import JstVerifyTracing
    instance = JstVerifyTracing.get_instance()
    if instance is not None and instance.sanitize_pii:
        from ._sanitizer import sanitize_span
        sanitize_span(span)
    _get_or_create_buffer().append(span)


def drain_relay_spans() -> List[SpanData]:
    """Return all buffered spans and reset the buffer for this request."""
    buf = _relay_spans.get()
    _relay_spans.set(None)
    return buf or []


def encode_relay_header(spans: List[SpanData]) -> Optional[str]:
    """Encode spans as a base64url header value, truncating if needed.

    Truncation drops oldest child spans first, always keeping the root span
    (the span with parentSpanId matching the incoming trace parent, i.e. the
    first span whose parentSpanId differs from all other spans' spanId).

    Returns None if spans is empty or the root span alone exceeds the limit.
    """
    if not spans:
        return None

    encoded = _encode(spans)
    if len(encoded) <= MAX_HEADER_BYTES:
        return encoded

    # Find root span (first span without a parent that is another collected span)
    span_ids = {s["spanId"] for s in spans}
    root = None
    children = []
    for s in spans:
        parent = s.get("parentSpanId")
        if root is None and (parent is None or parent not in span_ids):
            root = s
        else:
            children.append(s)

    if root is None:
        # Fallback: treat first span as root
        root = spans[0]
        children = spans[1:]

    # Drop oldest children first until it fits
    while children:
        children.pop(0)
        encoded = _encode([root] + children)
        if len(encoded) <= MAX_HEADER_BYTES:
            return encoded

    # Root alone
    encoded = _encode([root])
    if len(encoded) <= MAX_HEADER_BYTES:
        return encoded

    # Root alone exceeds limit — omit header entirely
    return None


def _encode(spans: List[SpanData]) -> str:
    """JSON-encode spans and return base64url (no padding)."""
    raw = json.dumps(spans, separators=(",", ":")).encode("utf-8")
    return base64.urlsafe_b64encode(raw).rstrip(b"=").decode("ascii")
