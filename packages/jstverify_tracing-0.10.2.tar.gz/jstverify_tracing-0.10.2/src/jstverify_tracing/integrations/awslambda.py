"""AWS Lambda middleware for JstVerify distributed tracing."""

import logging
import os
import time
import uuid
from functools import wraps

from .._context import set_root_context, pop_context, clear_context, set_session_id
from .._config import JstVerifyTracing
from .._source_location import from_code_object

logger = logging.getLogger("jstverify_tracing")

_FLUSH_HEADROOM_MS = 2000


def _get_remaining_ms(context):
    """Return milliseconds left in the Lambda invocation, or *None*."""
    if context is None:
        return None
    fn = getattr(context, "get_remaining_time_in_millis", None)
    return fn() if fn else None


def _has_trace_context(event):
    """Check if the request carries a trace ID from the frontend SDK.

    The JS SDK only injects X-JstVerify-Trace-Id when TracingModule is
    running, which only happens when the property has tracing enabled.
    If the header is absent, the request was not instrumented and we
    skip tracing entirely (conservative default).
    """
    headers = event.get("headers") or {}
    normalized = {k.lower(): v for k, v in headers.items()}
    return bool(normalized.get("x-jstverify-trace-id"))


# ---------------------------------------------------------------------------
# Event classification
# ---------------------------------------------------------------------------

def _classify_event(event):
    """Classify the Lambda invocation source.

    Returns one of: 'api_gateway', 'sqs', 'sns', 'eventbridge', 'scheduled', 'direct'.
    """
    # API Gateway (REST or HTTP API)
    rc = event.get("requestContext") or {}
    if rc.get("apiId") or event.get("httpMethod"):
        return "api_gateway"

    # SQS
    records = event.get("Records")
    if isinstance(records, list) and records:
        first = records[0]
        if first.get("eventSource") == "aws:sqs":
            return "sqs"
        if first.get("EventSource") == "aws:sns":
            return "sns"

    # EventBridge / Scheduled
    source = event.get("source")
    detail_type = event.get("detail-type")
    if source and detail_type:
        if source == "aws.events" and detail_type == "Scheduled Event":
            return "scheduled"
        return "eventbridge"

    return "direct"


# ---------------------------------------------------------------------------
# Trace context extraction
# ---------------------------------------------------------------------------

def _extract_trace_context(event):
    """Extract trace ID, parent span ID, and session ID from Lambda event headers."""
    headers = event.get("headers") or {}
    normalized = {k.lower(): v for k, v in headers.items()}
    trace_id = normalized.get("x-jstverify-trace-id") or str(uuid.uuid4())
    parent_span_id = normalized.get("x-jstverify-parent-span-id")
    session_id = normalized.get("x-jstverify-session-id")
    return trace_id, parent_span_id, session_id


def _extract_backend_trace_context(event, event_type):
    """Extract propagated trace context from non-HTTP event sources.

    Returns (trace_id, parent_span_id).  Falls back to a fresh trace ID
    and None parent when no propagated context is found.
    """
    trace_id = None
    parent_span_id = None

    if event_type == "sqs":
        records = event.get("Records") or []
        if records:
            attrs = records[0].get("messageAttributes") or {}
            trace_attr = attrs.get("JstVerifyTraceId") or {}
            trace_id = trace_attr.get("stringValue")
            parent_attr = attrs.get("JstVerifyParentSpanId") or {}
            parent_span_id = parent_attr.get("stringValue")

    elif event_type == "sns":
        records = event.get("Records") or []
        if records:
            sns_msg = records[0].get("Sns") or {}
            attrs = sns_msg.get("MessageAttributes") or {}
            trace_attr = attrs.get("JstVerifyTraceId") or {}
            trace_id = trace_attr.get("Value")
            parent_attr = attrs.get("JstVerifyParentSpanId") or {}
            parent_span_id = parent_attr.get("Value")

    elif event_type in ("eventbridge", "scheduled"):
        detail = event.get("detail") or {}
        trace_ctx = detail.get("_traceContext") or {}
        trace_id = trace_ctx.get("traceId")
        parent_span_id = trace_ctx.get("parentSpanId")

    if not trace_id:
        trace_id = str(uuid.uuid4())
        parent_span_id = None

    return trace_id, parent_span_id


# ---------------------------------------------------------------------------
# Synthetic source spans
# ---------------------------------------------------------------------------

def _build_source_span(trace_id, source_span_id, parent_span_id, event, event_type, start_time):
    """Build a synthetic span representing the event source (SQS, SNS, etc.).

    This produces a node in the service map showing the trigger before Lambda.
    """
    if event_type == "sqs":
        records = event.get("Records") or [{}]
        arn = records[0].get("eventSourceARN", "")
        queue_name = arn.rsplit(":", 1)[-1] if arn else "SQS Queue"
        return {
            "traceId": trace_id,
            "spanId": source_span_id,
            "parentSpanId": parent_span_id,
            "operationName": f"SQS ReceiveMessage {queue_name}",
            "serviceName": queue_name,
            "serviceType": "sqs",
            "startTime": start_time,
            "endTime": start_time,
            "duration": 0,
            "statusCode": 200,
            "statusMessage": None,
        }

    if event_type == "sns":
        records = event.get("Records") or [{}]
        sns_msg = records[0].get("Sns") or {}
        arn = sns_msg.get("TopicArn", "")
        topic_name = arn.rsplit(":", 1)[-1] if arn else "SNS Topic"
        return {
            "traceId": trace_id,
            "spanId": source_span_id,
            "parentSpanId": parent_span_id,
            "operationName": f"SNS Notification {topic_name}",
            "serviceName": topic_name,
            "serviceType": "sns",
            "startTime": start_time,
            "endTime": start_time,
            "duration": 0,
            "statusCode": 200,
            "statusMessage": None,
        }

    if event_type == "eventbridge":
        source = event.get("source", "events")
        detail_type = event.get("detail-type", "Event")
        return {
            "traceId": trace_id,
            "spanId": source_span_id,
            "parentSpanId": parent_span_id,
            "operationName": f"{source} {detail_type}",
            "serviceName": source,
            "serviceType": "events",
            "startTime": start_time,
            "endTime": start_time,
            "duration": 0,
            "statusCode": 200,
            "statusMessage": None,
        }

    if event_type == "scheduled":
        return {
            "traceId": trace_id,
            "spanId": source_span_id,
            "parentSpanId": parent_span_id,
            "operationName": "aws.events Scheduled Event",
            "serviceName": "aws.events",
            "serviceType": "events",
            "startTime": start_time,
            "endTime": start_time,
            "duration": 0,
            "statusCode": 200,
            "statusMessage": None,
        }

    # direct invocation — no synthetic source
    return None


# ---------------------------------------------------------------------------
# API Gateway synthetic span
# ---------------------------------------------------------------------------

def _build_apigw_span(trace_id, apigw_span_id, parent_span_id, event, start_time, end_time, status_code, status_message):
    """Build a synthetic API Gateway span from the Lambda event."""
    rc = event.get("requestContext") or {}
    method = event.get("httpMethod", "")
    path = event.get("path", rc.get("resourcePath", ""))
    operation = f"{method} {path}" if method else path or "API Gateway"

    api_id = rc.get("apiId", "")
    domain = rc.get("domainName", "")
    if domain and api_id:
        service_name = f"{domain} ({api_id})"
    elif domain:
        service_name = domain
    elif api_id:
        service_name = f"API Gateway ({api_id})"
    else:
        service_name = "API Gateway"

    return {
        "traceId": trace_id,
        "spanId": apigw_span_id,
        "parentSpanId": parent_span_id,
        "operationName": operation,
        "serviceName": service_name,
        "serviceType": "apigateway",
        "startTime": start_time,
        "endTime": end_time,
        "duration": end_time - start_time,
        "statusCode": status_code,
        "statusMessage": status_message,
    }


# ---------------------------------------------------------------------------
# Trace execution paths
# ---------------------------------------------------------------------------

def _trace_api_gateway(func, event, context, instance):
    """Trace a Lambda invoked via API Gateway (existing behavior)."""
    trace_id, original_parent_span_id, session_id = _extract_trace_context(event)
    set_session_id(session_id)

    # Deterministic span ID so multiple Lambda invocations from the
    # same trace produce the same API Gateway span (DynamoDB dedup).
    apigw_span_id = str(uuid.uuid5(uuid.NAMESPACE_URL, trace_id + "-apigw"))
    lambda_parent_span_id = apigw_span_id

    ctx = set_root_context(trace_id, lambda_parent_span_id)
    start_time = int(time.time() * 1000)

    lambda_service_name = os.environ.get(
        "AWS_LAMBDA_FUNCTION_NAME", instance.service_name
    )

    status_code = 200
    status_message = None
    result = None
    try:
        result = func(event, context)
        if isinstance(result, dict) and "statusCode" in result:
            status_code = result["statusCode"]
        return result
    except Exception as e:
        status_code = 500
        status_message = str(e)
        raise
    finally:
        end_time = int(time.time() * 1000)
        operation = getattr(func, "__name__", "handler")

        lambda_span = {
            "traceId": ctx.trace_id,
            "spanId": ctx.span_id,
            "parentSpanId": lambda_parent_span_id,
            "operationName": operation,
            "serviceName": lambda_service_name,
            "serviceType": instance.service_type,
            "startTime": start_time,
            "endTime": end_time,
            "duration": end_time - start_time,
            "statusCode": status_code,
            "statusMessage": status_message,
        }
        if session_id:
            lambda_span["sessionId"] = session_id
        lambda_span.update(from_code_object(func.__code__))

        if instance.is_relay:
            from .._relay_buffer import (
                enqueue_relay_span, drain_relay_spans,
                encode_relay_header, HEADER_NAME,
            )
            apigw_span = _build_apigw_span(
                ctx.trace_id, apigw_span_id, original_parent_span_id,
                event, start_time, end_time, status_code, status_message,
            )
            if session_id:
                apigw_span["sessionId"] = session_id
            enqueue_relay_span(apigw_span)
            enqueue_relay_span(lambda_span)
            spans = drain_relay_spans()
            header_value = encode_relay_header(spans)
            if (
                header_value is not None
                and isinstance(result, dict)
            ):
                result.setdefault("headers", {})[HEADER_NAME] = header_value
        else:
            apigw_span = _build_apigw_span(
                ctx.trace_id, apigw_span_id, original_parent_span_id,
                event, start_time, end_time, status_code, status_message,
            )
            if session_id:
                apigw_span["sessionId"] = session_id
            # Stop daemon flush thread to prevent it from taking spans
            # between enqueue calls, then flush synchronously.
            instance._buffer.stop()
            instance._buffer.enqueue(apigw_span)
            instance._buffer.enqueue(lambda_span)
            remaining = _get_remaining_ms(context)
            if remaining is not None and remaining < _FLUSH_HEADROOM_MS:
                logger.debug(
                    "jstverify-tracing: skipping flush — %dms remaining",
                    remaining,
                )
            else:
                instance._buffer.flush_all()
            # Restart daemon for next warm Lambda invocation
            instance._buffer.start()

        pop_context()
        clear_context()


def _trace_backend(func, event, context, instance, event_type):
    """Trace a Lambda invoked by a non-HTTP source (SQS, SNS, EventBridge, etc.)."""
    if instance.is_relay:
        logger.warning(
            "jstverify-tracing: relay transport cannot be used for backend traces "
            "(no HTTP response to attach headers to) — skipping tracing"
        )
        return func(event, context)

    trace_id, propagated_parent = _extract_backend_trace_context(event, event_type)

    # Deterministic source span ID for DynamoDB dedup
    source_span_id = str(uuid.uuid5(uuid.NAMESPACE_URL, trace_id + f"-{event_type}"))
    lambda_parent_span_id = source_span_id

    ctx = set_root_context(trace_id, lambda_parent_span_id)
    start_time = int(time.time() * 1000)

    lambda_service_name = os.environ.get(
        "AWS_LAMBDA_FUNCTION_NAME", instance.service_name
    )

    status_code = 200
    status_message = None
    try:
        result = func(event, context)
        if isinstance(result, dict) and "statusCode" in result:
            status_code = result["statusCode"]
        return result
    except Exception as e:
        status_code = 500
        status_message = str(e)
        raise
    finally:
        end_time = int(time.time() * 1000)
        operation = getattr(func, "__name__", "handler")

        # Synthetic source span (SQS Queue → Lambda, etc.)
        source_span = _build_source_span(
            trace_id, source_span_id, propagated_parent,
            event, event_type, start_time,
        )
        if source_span is not None:
            instance._buffer.enqueue(source_span)

        # Lambda span
        lambda_span = {
            "traceId": ctx.trace_id,
            "spanId": ctx.span_id,
            "parentSpanId": lambda_parent_span_id,
            "operationName": operation,
            "serviceName": lambda_service_name,
            "serviceType": instance.service_type,
            "startTime": start_time,
            "endTime": end_time,
            "duration": end_time - start_time,
            "statusCode": status_code,
            "statusMessage": status_message,
        }
        lambda_span.update(from_code_object(func.__code__))
        instance._buffer.enqueue(lambda_span)

        remaining = _get_remaining_ms(context)
        if remaining is not None and remaining < _FLUSH_HEADROOM_MS:
            logger.debug(
                "jstverify-tracing: skipping flush — %dms remaining",
                remaining,
            )
        else:
            instance.flush()

        pop_context()
        clear_context()


# ---------------------------------------------------------------------------
# Middleware routing
# ---------------------------------------------------------------------------

def _run_middleware(func, event, context, backend_trace):
    """Route to the appropriate tracing path based on event type and config."""
    instance = JstVerifyTracing.get_instance()
    if instance is None:
        return func(event, context)

    event_type = _classify_event(event)

    if event_type == "api_gateway":
        if not _has_trace_context(event):
            return func(event, context)
        if instance.is_relay:
            logger.warning(
                "jstverify-tracing: relay transport is not recommended for Lambda — "
                "spans will be attached to response headers only if the result is a dict"
            )
        return _trace_api_gateway(func, event, context, instance)

    if not backend_trace:
        return func(event, context)

    return _trace_backend(func, event, context, instance, event_type)


# ---------------------------------------------------------------------------
# Public decorator
# ---------------------------------------------------------------------------

def JstVerifyTracingMiddleware(func=None, *, backend_trace=False):
    """Decorator for Lambda handler functions.

    Extracts trace context from incoming requests and creates root spans.
    Supports both bare and parameterized usage:

        @JstVerifyTracingMiddleware
        def api_handler(event, context):
            ...

        @JstVerifyTracingMiddleware(backend_trace=True)
        def sqs_handler(event, context):
            ...

    When ``backend_trace=False`` (default), only API Gateway invocations
    carrying the ``X-JstVerify-Trace-Id`` header are traced.

    When ``backend_trace=True``, non-HTTP invocations (SQS, SNS,
    EventBridge, scheduled, direct) produce traces with synthetic source
    spans. API Gateway events still require the frontend header.
    """
    def decorator(fn):
        @wraps(fn)
        def wrapper(event, context):
            return _run_middleware(fn, event, context, backend_trace)
        return wrapper

    if func is not None:
        # Bare usage: @JstVerifyTracingMiddleware
        return decorator(func)
    # Parameterized: @JstVerifyTracingMiddleware(backend_trace=True)
    return decorator
