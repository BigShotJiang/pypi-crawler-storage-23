"""Monkey-patch requests.Session.send to auto-instrument outgoing HTTP calls."""

import time
import logging

from ._context import start_child_context, pop_context, get_current_context
from ._source_location import from_first_user_frame

logger = logging.getLogger("jstverify_tracing")

_original_send = None
_patched = False


def patch_requests():
    """Monkey-patch requests.Session.send to inject trace headers and record spans."""
    global _original_send, _patched

    if _patched:
        return

    import requests

    _original_send = requests.Session.send

    def patched_send(self, request, **kwargs):
        from ._config import JstVerifyTracing

        instance = JstVerifyTracing.get_instance()

        # Skip if not initialized
        if instance is None:
            return _original_send(self, request, **kwargs)

        # Skip requests to our own tracing endpoint (prevents recursion)
        if instance.endpoint and request.url and instance.endpoint in request.url:
            return _original_send(self, request, **kwargs)

        # Skip if no active trace context
        current = get_current_context()
        if current is None:
            return _original_send(self, request, **kwargs)

        location = from_first_user_frame()
        ctx = start_child_context()
        start_time = int(time.time() * 1000)

        # Inject trace headers
        request.headers["X-JstVerify-Trace-Id"] = ctx.trace_id
        request.headers["X-JstVerify-Parent-Span-Id"] = ctx.span_id

        method = request.method or "GET"
        url = _truncate_url(request.url)
        status_code = 0
        http_status_code = None

        try:
            response = _original_send(self, request, **kwargs)
            status_code = 200 if response.ok else response.status_code
            http_status_code = response.status_code
            return response
        except Exception as e:
            status_code = 0
            raise
        finally:
            end_time = int(time.time() * 1000)
            span = {
                "traceId": ctx.trace_id,
                "spanId": ctx.span_id,
                "parentSpanId": ctx.parent_span_id,
                "operationName": f"{method} {url}",
                "serviceName": instance.service_name,
                "serviceType": "http",
                "startTime": start_time,
                "endTime": end_time,
                "duration": end_time - start_time,
                "statusCode": status_code,
                "httpMethod": method,
                "httpUrl": url,
            }
            if http_status_code is not None:
                span["httpStatusCode"] = http_status_code
            span.update(location)
            from ._span import _enqueue
            _enqueue(instance, span)
            pop_context()

    requests.Session.send = patched_send
    _patched = True


def unpatch_requests():
    """Restore the original requests.Session.send (for testing)."""
    global _original_send, _patched

    if not _patched or _original_send is None:
        return

    import requests
    requests.Session.send = _original_send
    _original_send = None
    _patched = False


def _truncate_url(url: str) -> str:
    """Extract path only from URL, stripping query params and fragments."""
    try:
        from urllib.parse import urlparse
        parsed = urlparse(url)
        return parsed.path or "/"
    except Exception:
        return url[:200]
