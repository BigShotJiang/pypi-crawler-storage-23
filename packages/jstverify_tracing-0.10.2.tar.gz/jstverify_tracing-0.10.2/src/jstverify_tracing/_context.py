"""Thread-local trace context stack for parent-child span linking."""

import threading
import uuid
from dataclasses import dataclass, field
from typing import Optional


@dataclass
class TraceContext:
    trace_id: str
    span_id: str
    parent_span_id: Optional[str]


_local = threading.local()


def _get_stack() -> list:
    if not hasattr(_local, "stack"):
        _local.stack = []
    return _local.stack


def set_root_context(trace_id: str, parent_span_id: Optional[str] = None) -> TraceContext:
    """Called by middleware when a request arrives. Resets the stack and pushes a root context."""
    stack = _get_stack()
    stack.clear()
    span_id = str(uuid.uuid4())
    ctx = TraceContext(trace_id=trace_id, span_id=span_id, parent_span_id=parent_span_id)
    stack.append(ctx)
    return ctx


def start_child_context() -> TraceContext:
    """Push a child context onto the stack. Parent = current top of stack."""
    stack = _get_stack()
    parent = stack[-1] if stack else None
    trace_id = parent.trace_id if parent else str(uuid.uuid4())
    parent_span_id = parent.span_id if parent else None
    span_id = str(uuid.uuid4())
    ctx = TraceContext(trace_id=trace_id, span_id=span_id, parent_span_id=parent_span_id)
    stack.append(ctx)
    return ctx


def pop_context() -> Optional[TraceContext]:
    """Pop the top context after a span completes."""
    stack = _get_stack()
    if stack:
        return stack.pop()
    return None


def get_current_context() -> Optional[TraceContext]:
    """Return the current (top) context without modifying the stack."""
    stack = _get_stack()
    return stack[-1] if stack else None


def set_session_id(session_id: Optional[str]) -> None:
    """Store the frontend session ID for the current request."""
    _local.session_id = session_id


def get_session_id() -> Optional[str]:
    """Return the frontend session ID set for the current request, if any."""
    return getattr(_local, "session_id", None)


def clear_context() -> None:
    """Clear the entire context stack. Called at end of request."""
    stack = _get_stack()
    stack.clear()
    _local.session_id = None
