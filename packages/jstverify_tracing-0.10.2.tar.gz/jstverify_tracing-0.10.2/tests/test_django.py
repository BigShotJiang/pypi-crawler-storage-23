import os
import responses
import jstverify_tracing
from jstverify_tracing._config import JstVerifyTracing

# Set Django settings before importing anything
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "tests.django_settings")

import django
from django.conf import settings

if not settings.configured:
    settings.configure(
        DEBUG=True,
        ROOT_URLCONF="tests.test_django",
        MIDDLEWARE=[
            "jstverify_tracing.integrations.django.JstVerifyTracingMiddleware",
        ],
        SECRET_KEY="test-secret-key",
    )
    django.setup()

from django.http import HttpResponse, JsonResponse
from django.test import RequestFactory
from django.urls import path

from jstverify_tracing.integrations.django import JstVerifyTracingMiddleware as DjangoMiddleware


def test_view(request):
    return HttpResponse("ok")


urlpatterns = [
    path("test/", test_view),
]


@responses.activate
def test_django_middleware_creates_span():
    responses.add(responses.POST, "https://example.com/spans", json={"status": "ok"})

    jstverify_tracing.init(
        api_key="key",
        endpoint="https://example.com/spans",
        service_name="django-svc",
        patch_requests=False,
    )
    instance = JstVerifyTracing.get_instance()

    factory = RequestFactory()
    request = factory.get("/test/")

    middleware = DjangoMiddleware(test_view)
    response = middleware(request)
    assert response.status_code == 200

    with instance._buffer._lock:
        assert len(instance._buffer._queue) == 1
        span = instance._buffer._queue[0]
        assert span["operationName"] == "GET /test/"
        assert span["serviceName"] == "django-svc"
        assert span["statusCode"] == 200


@responses.activate
def test_django_middleware_propagates_trace_id():
    responses.add(responses.POST, "https://example.com/spans", json={"status": "ok"})

    jstverify_tracing.init(
        api_key="key",
        endpoint="https://example.com/spans",
        service_name="django-svc",
        patch_requests=False,
    )
    instance = JstVerifyTracing.get_instance()

    factory = RequestFactory()
    request = factory.get(
        "/test/",
        HTTP_X_JSTVERIFY_TRACE_ID="trace-abc",
        HTTP_X_JSTVERIFY_PARENT_SPAN_ID="parent-xyz",
    )

    middleware = DjangoMiddleware(test_view)
    middleware(request)

    with instance._buffer._lock:
        span = instance._buffer._queue[0]
        assert span["traceId"] == "trace-abc"
        assert span["parentSpanId"] == "parent-xyz"


@responses.activate
def test_django_middleware_handles_exception():
    responses.add(responses.POST, "https://example.com/spans", json={"status": "ok"})

    jstverify_tracing.init(
        api_key="key",
        endpoint="https://example.com/spans",
        service_name="django-svc",
        patch_requests=False,
    )
    instance = JstVerifyTracing.get_instance()

    def error_view(request):
        raise RuntimeError("fail")

    factory = RequestFactory()
    request = factory.get("/test/")

    middleware = DjangoMiddleware(error_view)
    try:
        middleware(request)
    except RuntimeError:
        pass

    with instance._buffer._lock:
        assert len(instance._buffer._queue) == 1
        span = instance._buffer._queue[0]
        assert span["statusCode"] == 500
