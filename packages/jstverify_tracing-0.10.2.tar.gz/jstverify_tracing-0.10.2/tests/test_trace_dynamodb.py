import responses
import pytest
import jstverify_tracing
from jstverify_tracing import trace_dynamodb
from jstverify_tracing._config import JstVerifyTracing
from jstverify_tracing._context import set_root_context


class FakeTable:
    """Mimics a boto3 DynamoDB Table resource for testing."""

    def __init__(self, table_name="test-table"):
        self.table_name = table_name
        self._items = {}

    def get_item(self, **kwargs):
        key = kwargs.get("Key", {})
        return {"Item": self._items.get(str(key), None)}

    def put_item(self, **kwargs):
        item = kwargs.get("Item", {})
        self._items[str(item)] = item
        return {}

    def query(self, **kwargs):
        return {"Items": [], "Count": 0}

    def failing_op(self, **kwargs):
        raise RuntimeError("DynamoDB error")


@responses.activate
def test_trace_dynamodb_creates_span():
    responses.add(responses.POST, "https://example.com/spans", json={"status": "ok"})

    jstverify_tracing.init(
        api_key="key",
        endpoint="https://example.com/spans",
        service_name="my-svc",
        service_type="lambda",
        patch_requests=False,
    )
    instance = JstVerifyTracing.get_instance()
    set_root_context("t1")

    table = FakeTable("users-table")
    result = trace_dynamodb("GetItem", table, Key={"UserID": "123"})
    assert "Item" in result

    with instance._buffer._lock:
        assert len(instance._buffer._queue) == 1
        span = instance._buffer._queue[0]
        assert span["operationName"] == "GetItem users-table"
        assert span["serviceName"] == "users-table"
        assert span["serviceType"] == "dynamodb"
        assert span["traceId"] == "t1"
        assert span["statusCode"] == 200
        assert span["duration"] >= 0


@responses.activate
def test_trace_dynamodb_captures_exception():
    responses.add(responses.POST, "https://example.com/spans", json={"status": "ok"})

    jstverify_tracing.init(
        api_key="key",
        endpoint="https://example.com/spans",
        service_name="my-svc",
        service_type="lambda",
        patch_requests=False,
    )
    instance = JstVerifyTracing.get_instance()
    set_root_context("t1")

    table = FakeTable("orders-table")

    with pytest.raises(RuntimeError, match="DynamoDB error"):
        trace_dynamodb("FailingOp", table)

    with instance._buffer._lock:
        span = instance._buffer._queue[0]
        assert span["statusCode"] == 500
        assert span["statusMessage"] == "DynamoDB error"
        assert span["operationName"] == "FailingOp orders-table"


@responses.activate
def test_trace_dynamodb_parent_child_linking():
    responses.add(responses.POST, "https://example.com/spans", json={"status": "ok"})

    jstverify_tracing.init(
        api_key="key",
        endpoint="https://example.com/spans",
        service_name="my-svc",
        service_type="lambda",
        patch_requests=False,
    )
    instance = JstVerifyTracing.get_instance()
    root = set_root_context("t1")

    table = FakeTable("users-table")
    trace_dynamodb("Query", table, KeyConditionExpression="pk = :pk")

    with instance._buffer._lock:
        span = instance._buffer._queue[0]
        assert span["parentSpanId"] == root.span_id
        assert span["traceId"] == "t1"


@responses.activate
def test_trace_dynamodb_invalid_operation():
    responses.add(responses.POST, "https://example.com/spans", json={"status": "ok"})

    jstverify_tracing.init(
        api_key="key",
        endpoint="https://example.com/spans",
        service_name="my-svc",
        patch_requests=False,
    )
    set_root_context("t1")

    table = FakeTable("test-table")

    with pytest.raises(AttributeError, match="Table has no method"):
        trace_dynamodb("NonExistentOp", table)


def test_trace_dynamodb_noop_without_init():
    """When SDK is not initialized, trace_dynamodb should still execute the operation."""
    table = FakeTable("test-table")
    table._items[str({"UserID": "1"})] = {"UserID": "1", "Name": "Test"}

    result = trace_dynamodb("GetItem", table, Key={"UserID": "1"})
    assert result["Item"] is not None


@responses.activate
def test_method_name_conversion():
    """Verify DynamoDB operation names convert correctly to boto3 method names."""
    from jstverify_tracing._span import _to_method_name

    assert _to_method_name("GetItem") == "get_item"
    assert _to_method_name("PutItem") == "put_item"
    assert _to_method_name("Query") == "query"
    assert _to_method_name("BatchWriteItem") == "batch_write_item"
    assert _to_method_name("UpdateItem") == "update_item"
    assert _to_method_name("DeleteItem") == "delete_item"
    assert _to_method_name("Scan") == "scan"
