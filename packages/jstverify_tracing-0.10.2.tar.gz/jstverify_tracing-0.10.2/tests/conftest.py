import pytest

from jstverify_tracing._config import JstVerifyTracing
from jstverify_tracing._context import clear_context
from jstverify_tracing._relay_buffer import drain_relay_spans
from jstverify_tracing._requests_patch import unpatch_requests
from jstverify_tracing._boto_patch import unpatch_boto


@pytest.fixture(autouse=True)
def _reset_tracing():
    """Reset global state between tests."""
    yield
    JstVerifyTracing.reset()
    clear_context()
    unpatch_requests()
    unpatch_boto()
    drain_relay_spans()
