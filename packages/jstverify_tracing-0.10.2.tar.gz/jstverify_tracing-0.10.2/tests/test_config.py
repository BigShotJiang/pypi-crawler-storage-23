import jstverify_tracing
from jstverify_tracing._config import DEFAULT_ENDPOINT


def test_default_endpoint_used_when_omitted():
    """Omitting endpoint should default to the production ingestion URL."""
    instance = jstverify_tracing.init(
        api_key="key",
        service_name="test-service",
        patch_requests=False,
    )
    assert instance.endpoint == DEFAULT_ENDPOINT


def test_custom_endpoint_overrides_default():
    """Providing an explicit endpoint should override the default."""
    instance = jstverify_tracing.init(
        api_key="key",
        endpoint="https://custom.example.com/spans",
        service_name="test-service",
        patch_requests=False,
    )
    assert instance.endpoint == "https://custom.example.com/spans"


def test_relay_mode_does_not_need_endpoint():
    """Relay mode should initialize without errors even with no endpoint."""
    instance = jstverify_tracing.init(
        api_key="key",
        service_name="test-service",
        transport="relay",
        patch_requests=False,
    )
    assert instance.is_relay
    assert instance._buffer is None
