import json
import os
import uuid
from unittest.mock import MagicMock, patch
import responses
import jstverify_tracing
from jstverify_tracing._config import JstVerifyTracing
from jstverify_tracing.integrations.appsync import JstVerifyAppSyncMiddleware


def _appsync_event(headers=None, parent_type="Query", field_name="listUsers", stash=None):
    """Build a minimal AppSync Lambda resolver event."""
    event = {
        "request": {"headers": headers or {}},
        "info": {"parentTypeName": parent_type, "fieldName": field_name},
    }
    if stash is not None:
        event["stash"] = stash
    return event


def _find_spans_by_type(spans):
    """Return (appsync_span, lambda_span) from a list of 2 spans."""
    appsync = [s for s in spans if s["serviceType"] == "appsync"]
    lam = [s for s in spans if s["serviceType"] != "appsync"]
    return appsync[0], lam[0]


@responses.activate
def test_appsync_query_creates_span_and_flushes():
    responses.add(responses.POST, "https://example.com/spans", json={"status": "ok"})

    jstverify_tracing.init(
        api_key="key",
        endpoint="https://example.com/spans",
        service_name="my-appsync",
        service_type="lambda",
        patch_requests=False,
    )

    @JstVerifyAppSyncMiddleware
    def handler(event, context):
        return [{"id": "1", "name": "Alice"}]

    event = _appsync_event(parent_type="Query", field_name="listUsers")
    result = handler(event, None)
    assert result == [{"id": "1", "name": "Alice"}]

    assert len(responses.calls) == 1
    payload = json.loads(responses.calls[0].request.body)
    assert len(payload["spans"]) == 2

    appsync_span, lambda_span = _find_spans_by_type(payload["spans"])
    assert appsync_span["operationName"] == "Query.listUsers"
    assert appsync_span["serviceName"] == "my-appsync"
    assert appsync_span["serviceType"] == "appsync"
    assert lambda_span["operationName"] == "Query.listUsers"
    assert lambda_span["serviceName"] == "my-appsync"  # no env var set
    assert lambda_span["serviceType"] == "lambda"
    assert lambda_span["statusCode"] == 200


@responses.activate
def test_appsync_mutation_creates_span():
    responses.add(responses.POST, "https://example.com/spans", json={"status": "ok"})

    jstverify_tracing.init(
        api_key="key",
        endpoint="https://example.com/spans",
        service_name="my-appsync",
        service_type="lambda",
        patch_requests=False,
    )

    @JstVerifyAppSyncMiddleware
    def handler(event, context):
        return {"id": "42", "status": "created"}

    event = _appsync_event(parent_type="Mutation", field_name="upsertFormDefinition")
    handler(event, None)

    payload = json.loads(responses.calls[0].request.body)
    appsync_span, lambda_span = _find_spans_by_type(payload["spans"])
    assert appsync_span["operationName"] == "Mutation.upsertFormDefinition"
    assert lambda_span["operationName"] == "Mutation.upsertFormDefinition"


@responses.activate
def test_appsync_propagates_trace_context():
    responses.add(responses.POST, "https://example.com/spans", json={"status": "ok"})

    jstverify_tracing.init(
        api_key="key",
        endpoint="https://example.com/spans",
        service_name="my-appsync",
        service_type="lambda",
        patch_requests=False,
    )

    @JstVerifyAppSyncMiddleware
    def handler(event, context):
        return {"ok": True}

    event = _appsync_event(
        headers={
            "X-JstVerify-Trace-Id": "trace-abc",
            "X-JstVerify-Parent-Span-Id": "parent-xyz",
        }
    )
    handler(event, None)

    payload = json.loads(responses.calls[0].request.body)
    appsync_span, lambda_span = _find_spans_by_type(payload["spans"])
    assert appsync_span["traceId"] == "trace-abc"
    assert appsync_span["parentSpanId"] == "parent-xyz"
    assert lambda_span["traceId"] == "trace-abc"
    assert lambda_span["parentSpanId"] == appsync_span["spanId"]


@responses.activate
def test_appsync_case_insensitive_headers():
    responses.add(responses.POST, "https://example.com/spans", json={"status": "ok"})

    jstverify_tracing.init(
        api_key="key",
        endpoint="https://example.com/spans",
        service_name="my-appsync",
        service_type="lambda",
        patch_requests=False,
    )

    @JstVerifyAppSyncMiddleware
    def handler(event, context):
        return {"ok": True}

    event = _appsync_event(
        headers={
            "x-jstverify-trace-id": "trace-lower",
            "x-jstverify-parent-span-id": "parent-lower",
        }
    )
    handler(event, None)

    payload = json.loads(responses.calls[0].request.body)
    appsync_span, lambda_span = _find_spans_by_type(payload["spans"])
    assert appsync_span["traceId"] == "trace-lower"
    assert appsync_span["parentSpanId"] == "parent-lower"
    assert lambda_span["traceId"] == "trace-lower"
    assert lambda_span["parentSpanId"] == appsync_span["spanId"]


@responses.activate
def test_appsync_generates_trace_id_when_absent():
    responses.add(responses.POST, "https://example.com/spans", json={"status": "ok"})

    jstverify_tracing.init(
        api_key="key",
        endpoint="https://example.com/spans",
        service_name="my-appsync",
        service_type="lambda",
        patch_requests=False,
    )

    @JstVerifyAppSyncMiddleware
    def handler(event, context):
        return {"ok": True}

    handler(_appsync_event(), None)

    payload = json.loads(responses.calls[0].request.body)
    appsync_span, lambda_span = _find_spans_by_type(payload["spans"])
    assert appsync_span["traceId"]  # auto-generated UUID
    assert appsync_span["parentSpanId"] is None
    assert lambda_span["parentSpanId"] == appsync_span["spanId"]


@responses.activate
def test_appsync_captures_exception():
    responses.add(responses.POST, "https://example.com/spans", json={"status": "ok"})

    jstverify_tracing.init(
        api_key="key",
        endpoint="https://example.com/spans",
        service_name="my-appsync",
        service_type="lambda",
        patch_requests=False,
    )

    @JstVerifyAppSyncMiddleware
    def handler(event, context):
        raise ValueError("boom")

    try:
        handler(_appsync_event(), None)
    except ValueError:
        pass

    payload = json.loads(responses.calls[0].request.body)
    appsync_span, lambda_span = _find_spans_by_type(payload["spans"])
    assert lambda_span["statusCode"] == 500
    assert lambda_span["statusMessage"] == "boom"
    assert appsync_span["statusCode"] == 500
    assert appsync_span["statusMessage"] == "boom"


@responses.activate
def test_appsync_list_return_value():
    """AppSync resolvers often return lists (e.g. listUsers)."""
    responses.add(responses.POST, "https://example.com/spans", json={"status": "ok"})

    jstverify_tracing.init(
        api_key="key",
        endpoint="https://example.com/spans",
        service_name="my-appsync",
        service_type="lambda",
        patch_requests=False,
    )

    @JstVerifyAppSyncMiddleware
    def handler(event, context):
        return [{"id": "1"}, {"id": "2"}, {"id": "3"}]

    result = handler(_appsync_event(), None)
    assert len(result) == 3

    payload = json.loads(responses.calls[0].request.body)
    assert len(payload["spans"]) == 2
    _, lambda_span = _find_spans_by_type(payload["spans"])
    assert lambda_span["statusCode"] == 200


def test_appsync_noop_without_init():
    """When SDK is not initialized, decorator is transparent."""

    @JstVerifyAppSyncMiddleware
    def handler(event, context):
        return {"id": "1"}

    result = handler(_appsync_event(), None)
    assert result == {"id": "1"}


def test_appsync_relay_mode_warns_and_skips(caplog):
    """Relay mode logs a warning and passes through without tracing."""
    jstverify_tracing.init(
        api_key="key",
        service_name="my-appsync",
        transport="relay",
        patch_requests=False,
    )

    @JstVerifyAppSyncMiddleware
    def handler(event, context):
        return {"id": "1"}

    with caplog.at_level("WARNING", logger="jstverify_tracing"):
        result = handler(_appsync_event(), None)

    assert result == {"id": "1"}
    assert "relay transport is not supported for AppSync" in caplog.text


@responses.activate
def test_appsync_child_spans():
    """Verify nested trace_span calls inside an AppSync handler get correct parent-child links."""
    responses.add(responses.POST, "https://example.com/spans", json={"status": "ok"})

    jstverify_tracing.init(
        api_key="key",
        endpoint="https://example.com/spans",
        service_name="my-appsync",
        service_type="lambda",
        patch_requests=False,
    )

    @JstVerifyAppSyncMiddleware
    def handler(event, context):
        with jstverify_tracing.trace_span("fetch-data") as span:
            span.set_status(200)
        return {"ok": True}

    event = _appsync_event(
        headers={"X-JstVerify-Trace-Id": "t1"},
        parent_type="Query",
        field_name="getItem",
    )
    handler(event, None)

    payload = json.loads(responses.calls[0].request.body)
    spans = payload["spans"]
    # 3 spans: fetch-data child, appsync parent, lambda child
    assert len(spans) == 3

    by_op = {}
    for s in spans:
        key = f"{s['serviceType']}:{s['operationName']}"
        by_op[key] = s

    child = by_op["lambda:fetch-data"]
    appsync = by_op["appsync:Query.getItem"]
    root_lambda = by_op["lambda:Query.getItem"]

    assert child["traceId"] == "t1"
    assert appsync["traceId"] == "t1"
    assert root_lambda["traceId"] == "t1"
    assert root_lambda["parentSpanId"] == appsync["spanId"]
    assert child["parentSpanId"] == root_lambda["spanId"]


@responses.activate
def test_appsync_fallback_operation_name_no_info():
    """When event has no info field, fall back to function name."""
    responses.add(responses.POST, "https://example.com/spans", json={"status": "ok"})

    jstverify_tracing.init(
        api_key="key",
        endpoint="https://example.com/spans",
        service_name="my-appsync",
        service_type="lambda",
        patch_requests=False,
    )

    @JstVerifyAppSyncMiddleware
    def my_resolver(event, context):
        return {"ok": True}

    # Event without info field
    event = {"request": {"headers": {}}}
    my_resolver(event, None)

    payload = json.loads(responses.calls[0].request.body)
    appsync_span, lambda_span = _find_spans_by_type(payload["spans"])
    assert appsync_span["operationName"] == "my_resolver"
    assert lambda_span["operationName"] == "my_resolver"


@responses.activate
def test_appsync_missing_request_key():
    """Event with no request key should not crash."""
    responses.add(responses.POST, "https://example.com/spans", json={"status": "ok"})

    jstverify_tracing.init(
        api_key="key",
        endpoint="https://example.com/spans",
        service_name="my-appsync",
        service_type="lambda",
        patch_requests=False,
    )

    @JstVerifyAppSyncMiddleware
    def handler(event, context):
        return {"ok": True}

    # Completely bare event
    handler({}, None)

    payload = json.loads(responses.calls[0].request.body)
    appsync_span, lambda_span = _find_spans_by_type(payload["spans"])
    assert appsync_span["traceId"]  # auto-generated
    assert appsync_span["operationName"] == "handler"
    assert lambda_span["operationName"] == "handler"


@responses.activate
def test_appsync_skips_flush_when_low_remaining_time():
    """When Lambda has <2s remaining, spans are enqueued but flush is skipped."""
    responses.add(responses.POST, "https://example.com/spans", json={"status": "ok"})

    instance = jstverify_tracing.init(
        api_key="key",
        endpoint="https://example.com/spans",
        service_name="my-appsync",
        service_type="lambda",
        patch_requests=False,
    )

    @JstVerifyAppSyncMiddleware
    def handler(event, context):
        return {"ok": True}

    ctx = MagicMock()
    ctx.get_remaining_time_in_millis.return_value = 500  # 500ms left

    handler(_appsync_event(), ctx)

    # No HTTP call should have been made
    assert len(responses.calls) == 0
    # But both spans should be in the buffer
    assert len(instance._buffer._queue) == 2


# --- New tests for two-span emission and stash support ---


@responses.activate
def test_appsync_emits_two_spans():
    """Verify both AppSync parent and Lambda child spans are emitted with correct linkage."""
    responses.add(responses.POST, "https://example.com/spans", json={"status": "ok"})

    jstverify_tracing.init(
        api_key="key",
        endpoint="https://example.com/spans",
        service_name="my-appsync",
        service_type="lambda",
        patch_requests=False,
    )

    @JstVerifyAppSyncMiddleware
    def handler(event, context):
        return {"ok": True}

    handler(_appsync_event(), None)

    payload = json.loads(responses.calls[0].request.body)
    assert len(payload["spans"]) == 2

    appsync_span, lambda_span = _find_spans_by_type(payload["spans"])

    # AppSync span is the parent
    assert appsync_span["serviceType"] == "appsync"
    assert appsync_span["serviceName"] == "my-appsync"
    assert appsync_span["parentSpanId"] is None

    # Lambda span is the child of the AppSync span
    assert lambda_span["serviceType"] == "lambda"
    assert lambda_span["parentSpanId"] == appsync_span["spanId"]

    # Both share the same traceId
    assert appsync_span["traceId"] == lambda_span["traceId"]


@responses.activate
def test_appsync_lambda_service_name_from_env():
    """Lambda span uses AWS_LAMBDA_FUNCTION_NAME while AppSync span uses instance.service_name."""
    responses.add(responses.POST, "https://example.com/spans", json={"status": "ok"})

    jstverify_tracing.init(
        api_key="key",
        endpoint="https://example.com/spans",
        service_name="my-appsync",
        service_type="lambda",
        patch_requests=False,
    )

    @JstVerifyAppSyncMiddleware
    def handler(event, context):
        return {"ok": True}

    with patch.dict(os.environ, {"AWS_LAMBDA_FUNCTION_NAME": "dev-myapp-checkPermissions"}):
        handler(_appsync_event(), None)

    payload = json.loads(responses.calls[0].request.body)
    appsync_span, lambda_span = _find_spans_by_type(payload["spans"])

    assert appsync_span["serviceName"] == "my-appsync"
    assert lambda_span["serviceName"] == "dev-myapp-checkPermissions"


@responses.activate
def test_appsync_deterministic_appsync_span_id():
    """Same traceId always produces the same AppSync spanId (uuid5)."""
    responses.add(responses.POST, "https://example.com/spans", json={"status": "ok"})

    trace_id = "test-trace-deterministic-123"
    expected_span_id = str(uuid.uuid5(uuid.NAMESPACE_URL, trace_id))

    jstverify_tracing.init(
        api_key="key",
        endpoint="https://example.com/spans",
        service_name="my-appsync",
        service_type="lambda",
        patch_requests=False,
    )

    @JstVerifyAppSyncMiddleware
    def handler(event, context):
        return {"ok": True}

    # Call twice with the same traceId
    for _ in range(2):
        event = _appsync_event(headers={"X-JstVerify-Trace-Id": trace_id})
        handler(event, None)

    # Both calls should produce the same AppSync spanId
    for call in responses.calls:
        payload = json.loads(call.request.body)
        appsync_span, _ = _find_spans_by_type(payload["spans"])
        assert appsync_span["spanId"] == expected_span_id


@responses.activate
def test_appsync_stash_trace_context():
    """Pass traceId via event['stash']['jstverifyTraceId'], verify both spans use it."""
    responses.add(responses.POST, "https://example.com/spans", json={"status": "ok"})

    jstverify_tracing.init(
        api_key="key",
        endpoint="https://example.com/spans",
        service_name="my-appsync",
        service_type="lambda",
        patch_requests=False,
    )

    @JstVerifyAppSyncMiddleware
    def handler(event, context):
        return {"ok": True}

    stash_trace_id = "stash-trace-abc-123"
    event = _appsync_event(stash={"jstverifyTraceId": stash_trace_id})
    handler(event, None)

    payload = json.loads(responses.calls[0].request.body)
    appsync_span, lambda_span = _find_spans_by_type(payload["spans"])
    assert appsync_span["traceId"] == stash_trace_id
    assert lambda_span["traceId"] == stash_trace_id


@responses.activate
def test_appsync_stash_overrides_headers():
    """When event has both stash and headers trace IDs, stash wins."""
    responses.add(responses.POST, "https://example.com/spans", json={"status": "ok"})

    jstverify_tracing.init(
        api_key="key",
        endpoint="https://example.com/spans",
        service_name="my-appsync",
        service_type="lambda",
        patch_requests=False,
    )

    @JstVerifyAppSyncMiddleware
    def handler(event, context):
        return {"ok": True}

    event = _appsync_event(
        headers={"X-JstVerify-Trace-Id": "header-trace-id"},
        stash={"jstverifyTraceId": "stash-trace-id"},
    )
    handler(event, None)

    payload = json.loads(responses.calls[0].request.body)
    appsync_span, lambda_span = _find_spans_by_type(payload["spans"])
    assert appsync_span["traceId"] == "stash-trace-id"
    assert lambda_span["traceId"] == "stash-trace-id"
