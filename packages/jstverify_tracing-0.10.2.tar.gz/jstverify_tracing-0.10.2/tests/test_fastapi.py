import responses
import jstverify_tracing
from jstverify_tracing._config import JstVerifyTracing


@responses.activate
def test_fastapi_middleware_creates_span():
    responses.add(responses.POST, "https://example.com/spans", json={"status": "ok"})

    from fastapi import FastAPI
    from fastapi.testclient import TestClient
    from jstverify_tracing.integrations.fastapi import JstVerifyTracingMiddleware

    jstverify_tracing.init(
        api_key="key",
        endpoint="https://example.com/spans",
        service_name="fastapi-svc",
        patch_requests=False,
    )

    app = FastAPI()
    app.add_middleware(JstVerifyTracingMiddleware)

    @app.get("/test")
    def test_route():
        return {"msg": "ok"}

    instance = JstVerifyTracing.get_instance()
    client = TestClient(app)
    resp = client.get("/test")
    assert resp.status_code == 200

    with instance._buffer._lock:
        assert len(instance._buffer._queue) == 1
        span = instance._buffer._queue[0]
        assert span["operationName"] == "GET /test"
        assert span["serviceName"] == "fastapi-svc"
        assert span["statusCode"] == 200
        assert span["httpMethod"] == "GET"


@responses.activate
def test_fastapi_middleware_propagates_trace_id():
    responses.add(responses.POST, "https://example.com/spans", json={"status": "ok"})

    from fastapi import FastAPI
    from fastapi.testclient import TestClient
    from jstverify_tracing.integrations.fastapi import JstVerifyTracingMiddleware

    jstverify_tracing.init(
        api_key="key",
        endpoint="https://example.com/spans",
        service_name="fastapi-svc",
        patch_requests=False,
    )

    app = FastAPI()
    app.add_middleware(JstVerifyTracingMiddleware)

    @app.get("/traced")
    def traced_route():
        return {"msg": "ok"}

    instance = JstVerifyTracing.get_instance()
    client = TestClient(app)
    resp = client.get("/traced", headers={
        "X-JstVerify-Trace-Id": "trace-from-js",
        "X-JstVerify-Parent-Span-Id": "parent-from-js",
    })
    assert resp.status_code == 200

    with instance._buffer._lock:
        span = instance._buffer._queue[0]
        assert span["traceId"] == "trace-from-js"
        assert span["parentSpanId"] == "parent-from-js"


@responses.activate
def test_fastapi_middleware_generates_trace_id():
    responses.add(responses.POST, "https://example.com/spans", json={"status": "ok"})

    from fastapi import FastAPI
    from fastapi.testclient import TestClient
    from jstverify_tracing.integrations.fastapi import JstVerifyTracingMiddleware

    jstverify_tracing.init(
        api_key="key",
        endpoint="https://example.com/spans",
        service_name="fastapi-svc",
        patch_requests=False,
    )

    app = FastAPI()
    app.add_middleware(JstVerifyTracingMiddleware)

    @app.get("/no-trace")
    def route():
        return {"msg": "ok"}

    instance = JstVerifyTracing.get_instance()
    client = TestClient(app)
    client.get("/no-trace")

    with instance._buffer._lock:
        span = instance._buffer._queue[0]
        assert span["traceId"]  # auto-generated
        assert span["parentSpanId"] is None
