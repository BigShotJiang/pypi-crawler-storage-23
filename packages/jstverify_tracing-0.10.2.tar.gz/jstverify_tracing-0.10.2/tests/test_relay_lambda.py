"""Tests for Lambda middleware in relay transport mode."""

import base64
import json
import logging

import jstverify_tracing
from jstverify_tracing._config import JstVerifyTracing
from jstverify_tracing._relay_buffer import HEADER_NAME
from jstverify_tracing.integrations.awslambda import JstVerifyTracingMiddleware


def _init_relay():
    jstverify_tracing.init(
        api_key="key",
        service_name="lambda-relay",
        service_type="lambda",
        transport="relay",
        patch_requests=False,
    )


def test_relay_header_in_result_dict():
    _init_relay()

    @JstVerifyTracingMiddleware
    def handler(event, context):
        return {"statusCode": 200, "body": "ok"}

    result = handler({"headers": {}}, None)
    assert result["statusCode"] == 200
    assert HEADER_NAME in result.get("headers", {})
    raw = result["headers"][HEADER_NAME]
    padded = raw + "=" * ((4 - len(raw) % 4) % 4)
    spans = json.loads(base64.urlsafe_b64decode(padded))
    assert len(spans) == 1
    assert spans[0]["operationName"] == "handler"
    assert spans[0]["serviceName"] == "lambda-relay"


def test_relay_warning_logged(caplog):
    _init_relay()

    @JstVerifyTracingMiddleware
    def handler(event, context):
        return {"statusCode": 200}

    with caplog.at_level(logging.WARNING, logger="jstverify_tracing"):
        handler({"headers": {}}, None)

    assert "relay transport is not recommended for Lambda" in caplog.text


def test_relay_no_http_calls():
    _init_relay()
    instance = JstVerifyTracing.get_instance()
    assert instance._buffer is None
    assert instance._transport is None


def test_relay_child_spans_included():
    _init_relay()

    @JstVerifyTracingMiddleware
    def handler(event, context):
        with jstverify_tracing.trace_span("lambda-child") as span:
            span.set_status(200)
        return {"statusCode": 200}

    result = handler({"headers": {}}, None)
    raw = result["headers"][HEADER_NAME]
    padded = raw + "=" * ((4 - len(raw) % 4) % 4)
    spans = json.loads(base64.urlsafe_b64decode(padded))
    assert len(spans) == 2
    ops = [s["operationName"] for s in spans]
    assert "lambda-child" in ops
    assert "handler" in ops


def test_relay_exception_safety():
    """On exception, spans should not leak and handler should re-raise."""
    _init_relay()

    @JstVerifyTracingMiddleware
    def handler(event, context):
        raise ValueError("boom")

    try:
        handler({"headers": {}}, None)
    except ValueError:
        pass

    # Buffer should be empty
    from jstverify_tracing._relay_buffer import drain_relay_spans
    assert drain_relay_spans() == []


def test_relay_non_dict_result_silently_drops():
    """When result is not a dict, spans are silently dropped."""
    _init_relay()

    @JstVerifyTracingMiddleware
    def handler(event, context):
        return "plain string"

    result = handler({"headers": {}}, None)
    assert result == "plain string"


def test_relay_propagates_trace_id():
    _init_relay()

    @JstVerifyTracingMiddleware
    def handler(event, context):
        return {"statusCode": 200}

    event = {
        "headers": {
            "X-JstVerify-Trace-Id": "relay-trace-lambda",
            "X-JstVerify-Parent-Span-Id": "parent-lambda",
        }
    }
    result = handler(event, None)
    raw = result["headers"][HEADER_NAME]
    padded = raw + "=" * ((4 - len(raw) % 4) % 4)
    spans = json.loads(base64.urlsafe_b64decode(padded))
    assert spans[0]["traceId"] == "relay-trace-lambda"
    assert spans[0]["parentSpanId"] == "parent-lambda"
