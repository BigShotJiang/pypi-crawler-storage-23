# Bu araç @keyiflerolsun tarafından | @KekikAkademi için yazılmıştır.

from KekikStream.Core import BePlayerExtractor

class DonilasPlay(BePlayerExtractor):
    name     = "DonilasPlay"
    main_url = "https://donilasplay.com"
