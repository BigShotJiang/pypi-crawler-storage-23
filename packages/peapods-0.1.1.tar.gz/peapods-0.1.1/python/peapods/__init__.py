from peapods.spin_models import Ising

__all__ = ["Ising"]
