# Changelog

## 0.3.0 (2026-02-22)

Full Changelog: [v0.2.0...v0.3.0](https://github.com/Midbound/cloud-sdk-python/compare/v0.2.0...v0.3.0)

### Features

* **api:** api update ([f8c444e](https://github.com/Midbound/cloud-sdk-python/commit/f8c444e4b82dadec774ee7e71d8d1252d9ea716d))
* **api:** api update ([4ef5a0b](https://github.com/Midbound/cloud-sdk-python/commit/4ef5a0b8c0288672011d972445c2af0ed0f9b92d))


### Chores

* **internal:** remove mock server code ([712f0af](https://github.com/Midbound/cloud-sdk-python/commit/712f0af491e973c3d9558cd554e6358a61a05c93))
* update mock server docs ([a075a5e](https://github.com/Midbound/cloud-sdk-python/commit/a075a5ee2b638b084c2dabb5b528104779e95757))

## 0.2.0 (2026-02-15)

Full Changelog: [v0.1.0...v0.2.0](https://github.com/Midbound/cloud-sdk-python/compare/v0.1.0...v0.2.0)

### Features

* **api:** manual updates ([fe18784](https://github.com/Midbound/cloud-sdk-python/commit/fe18784386c780eeab5912a929c4bbe08a03708d))


### Chores

* update SDK settings ([2e3428c](https://github.com/Midbound/cloud-sdk-python/commit/2e3428c343febda12d97cca3801c377bb94cf20f))
* update SDK settings ([adc60a5](https://github.com/Midbound/cloud-sdk-python/commit/adc60a5a3504130eac1dffb9e475f1dc6be948e7))
* update SDK settings ([c41b5f1](https://github.com/Midbound/cloud-sdk-python/commit/c41b5f1b568c1dd943bc74048519bc089d127604))

## 0.1.0 (2026-02-15)

Full Changelog: [v0.0.4...v0.1.0](https://github.com/Midbound/cloud-sdk-python/compare/v0.0.4...v0.1.0)

### Features

* **api:** manual updates ([08c7382](https://github.com/Midbound/cloud-sdk-python/commit/08c7382932977f9c925946df45152ba55b6bfeea))
* **api:** manual updates ([cef8f12](https://github.com/Midbound/cloud-sdk-python/commit/cef8f121e0ad6103cb2cd4b7baf903aa3d2543fe))
* **api:** manual updates ([48df30a](https://github.com/Midbound/cloud-sdk-python/commit/48df30aff69b296f418c4e36b46e32d78e5ed0b6))
* **api:** manual updates ([74a14b7](https://github.com/Midbound/cloud-sdk-python/commit/74a14b7b43786bb140839a64a0f3916f81a5f8ce))


### Chores

* update SDK settings ([1967eea](https://github.com/Midbound/cloud-sdk-python/commit/1967eea356514c256c6aeb9569bc42a5836b1550))
* update SDK settings ([a7a6e45](https://github.com/Midbound/cloud-sdk-python/commit/a7a6e45451f7097aa2c1bc6698d4707dcf5db589))
* update SDK settings ([5bd28e4](https://github.com/Midbound/cloud-sdk-python/commit/5bd28e47a32eb8178ba14b1e2f4b5abf8fb8fd73))

## 0.0.4 (2026-02-14)

Full Changelog: [v0.0.3...v0.0.4](https://github.com/Midbound/cloud-sdk-python/compare/v0.0.3...v0.0.4)

### Chores

* update SDK settings ([4931289](https://github.com/Midbound/cloud-sdk-python/commit/4931289c071b508236c8ab6a54bfb1889b447048))
* update SDK settings ([fba3263](https://github.com/Midbound/cloud-sdk-python/commit/fba32638fb12acb1ac0daeae83702099c39b5f69))

## 0.0.3 (2026-02-14)

Full Changelog: [v0.0.2...v0.0.3](https://github.com/Midbound/cloud-sdk-python/compare/v0.0.2...v0.0.3)

### Chores

* update SDK settings ([3dd6fc8](https://github.com/Midbound/cloud-sdk-python/commit/3dd6fc81ff75d4f8a042187a63029317c8a926d5))
* update SDK settings ([5a4b563](https://github.com/Midbound/cloud-sdk-python/commit/5a4b563ddda41dc34f09791ff79a7b03ff74b2c9))

## 0.0.2 (2026-02-14)

Full Changelog: [v0.0.1...v0.0.2](https://github.com/Midbound/cloud-sdk-python/compare/v0.0.1...v0.0.2)

### Chores

* configure new SDK language ([803e543](https://github.com/Midbound/cloud-sdk-python/commit/803e543054b282d7d6fd89e14ea03ef34b707bf6))
* update SDK settings ([621e9f4](https://github.com/Midbound/cloud-sdk-python/commit/621e9f44c22f53a5645e77b7ff77ce5d5b33949d))
* update SDK settings ([9039d94](https://github.com/Midbound/cloud-sdk-python/commit/9039d941640eed78ac9e0ed93315d41fdb47bf04))
* update SDK settings ([4e5d545](https://github.com/Midbound/cloud-sdk-python/commit/4e5d54533d50ad0e955a97cff6dd86b22f33f899))
