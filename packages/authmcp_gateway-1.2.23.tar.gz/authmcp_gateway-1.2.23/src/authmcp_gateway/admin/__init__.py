"""Admin panel module."""
