# =====================================
# generator=datazen
# version=3.2.3
# hash=293bc5acb10c007c0fa167228977a266
# =====================================

"""
Useful defaults and other package metadata.
"""

DESCRIPTION = "Read the sign."
PKG_NAME = "experimental-lowqa"
VERSION = "0.2.1"
