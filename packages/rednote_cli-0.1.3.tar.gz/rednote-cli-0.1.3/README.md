# rednote-cli

Rednote 平台专用 CLI（独立安装、独立升级、独立发布）。

## 系统要求

- Python `3.12.x`
- `pipx`

## 安装

```bash
brew update
brew upgrade python@3.12 pipx
python3.12 --version
pipx --version
pipx ensurepath
exec zsh

pipx install --python python3.12 rednote-cli
```

## 升级

```bash
pipx upgrade --python python3.12 rednote-cli
```

如果历史环境用了其他 Python（例如 3.14），先重建：

```bash
pipx reinstall --python python3.12 rednote-cli
```

## 卸载

```bash
pipx uninstall rednote-cli
```

## 快速开始

```bash
rednote-cli init runtime
rednote-cli doctor run --format json
rednote-cli account login
rednote-cli account status --format json
rednote-cli search note --keyword 旅行 --size 10 --sort-by latest --note-type image_text --format json
```

## 常用命令

```bash
rednote-cli search note --keyword <kw> [--size N] [--sort-by <comprehensive|latest|most_liked|most_commented|most_favorited>] [--note-type <all|video|image_text>] [--publish-time <all|day|week|half_year>] [--search-scope <all|viewed|unviewed|following>] [--location <all|local|nearby>] [--account <user_id>] [--input <file|->]

rednote-cli note --note-id <id> [--xsec-token t] [--xsec-source src] [--comment-size N] [--sub-comment-size N] [--account <user_id>] [--input <file|->]

rednote-cli search user --keyword <kw> [--size N] [--account <user_id>] [--input <file|->]

rednote-cli user --user-id <id> [--xsec-token t] [--xsec-source src] [--account <user_id>] [--input <file|->]

rednote-cli user self --account <user_id>

rednote-cli publish --target image --account <account_uid> [--image-list csv] [--title t] [--content c] [--tags csv] [--schedule-at rfc3339] [--input <file|->]
rednote-cli publish --target video --account <account_uid> [--video <path-or-url>] [--title t] [--content c] [--tags csv] [--schedule-at rfc3339] [--input <file|->]
```

## JSON 输入模式（`--input`）

参数优先级固定：
- 显式 CLI 参数 > `--input` JSON > 默认值

支持 `--input` 的命令：
- `search note`
- `search user`
- `note`
- `user`
- `publish`

不支持 `--input` 的命令：
- `init runtime`
- `doctor run`
- `account login|status|list|activate|deactivate|delete`
- `user self`

推荐 Agent 调用模板：

```bash
rednote-cli --format json --trace-id req-001 search note --input payload.json
cat payload.json | rednote-cli --format json --trace-id req-002 publish --input - --account user_001
```

## 输出与退出码

- 建议自动化调用统一使用 `--format json` + `--trace-id`
- 退出码：`0` 成功，`2` 参数错误，`3` 认证错误，`4` 风控/限流，`5` 内部错误，`6` 超时，`7` 依赖缺失/未实现

## 工作区文档

- Workspace 总览：`../../README.md`
