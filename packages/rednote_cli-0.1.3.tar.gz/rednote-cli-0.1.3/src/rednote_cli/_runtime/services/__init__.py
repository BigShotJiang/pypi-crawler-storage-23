"""Service package for CLI runtime."""
