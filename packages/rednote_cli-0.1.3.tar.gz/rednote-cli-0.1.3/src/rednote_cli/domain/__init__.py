"""Domain layer."""
