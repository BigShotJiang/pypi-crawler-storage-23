from __future__ import annotations

from rednote_cli._runtime.services import scraper_service


class RednoteExtractorAdapter:
    async def search_notes(
        self,
        keyword: str,
        size: int,
        sort_by: str | None = None,
        note_type: str | None = None,
        publish_time: str | None = None,
        search_scope: str | None = None,
        location: str | None = None,
        account_uid: str | None = None,
    ) -> list[dict]:
        return await scraper_service.search_notes(
            keyword=keyword,
            size=size,
            sort_by=sort_by,
            note_type=note_type,
            publish_time=publish_time,
            search_scope=search_scope,
            location=location,
            account_uid=account_uid,
        )

    async def search_users(self, keyword: str, size: int, account_uid: str | None = None) -> list[dict]:
        return await scraper_service.search_users(keyword=keyword, size=size, account_uid=account_uid)

    async def get_user_info(
        self,
        user_id: str,
        xsec_token: str | None = None,
        xsec_source: str | None = "pc_feed",
        account_uid: str | None = None,
    ) -> dict:
        return await scraper_service.get_user_info(
            user_id=user_id,
            xsec_token=xsec_token,
            xsec_source=xsec_source,
            account_uid=account_uid,
        )

    async def get_note_info(
        self,
        note_id: str,
        xsec_token: str | None = None,
        xsec_source: str | None = "pc_feed",
        comment_size: int = 10,
        sub_comment_size: int = 5,
        account_uid: str | None = None,
    ) -> dict:
        return await scraper_service.get_note_info(
            note_id=note_id,
            xsec_token=xsec_token,
            xsec_source=xsec_source,
            comment_size=comment_size,
            sub_comment_size=sub_comment_size,
            account_uid=account_uid,
        )

    async def get_self_info(self, account_uid: str | None = None) -> dict:
        return await scraper_service.get_self_info(account_uid=account_uid)
