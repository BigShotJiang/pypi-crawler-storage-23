# Download CHMI weather forecast data

## Installation 

```shell
uv tool install chmix
```

## Running without installation

```shell
uvx chmix aladin Ostrava
```
