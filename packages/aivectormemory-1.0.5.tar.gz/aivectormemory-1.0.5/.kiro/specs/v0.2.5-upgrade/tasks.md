# v0.2.5 任务清单

> 对应需求文档：`.kiro/specs/v0.2.5-upgrade/requirements.md`
> 按批次 A → B → C 顺序执行

---

## 批次 A：track 问题追踪结构化 + 问题关联

### A1. schema 迁移（需求 1.3）

- [x] A1.1 `schema.py`：ISSUES_TABLE 定义新增 description/investigation/root_cause/solution/files_changed/test_result/notes/feature_id/parent_id 字段
- [x] A1.2 `schema.py`：ISSUES_ARCHIVE_TABLE 定义新增 description/investigation/root_cause/solution/files_changed/test_result/notes/feature_id/parent_id/status 字段
- [x] A1.3 `schema.py`：CURRENT_SCHEMA_VERSION 改为 4
- [x] A1.4 `schema.py`：新增 `if ver < 4` 迁移逻辑，ALTER TABLE issues ADD COLUMN 逐字段
- [x] A1.5 `schema.py`：v4 迁移逻辑中 ALTER TABLE issues_archive ADD COLUMN 逐字段（含 status）
- [x] A1.6 `schema.py`：v4 迁移逻辑中 CREATE TABLE IF NOT EXISTS tasks（批次 B 的表，合并在 v4）
- [x] A1.7 `schema.py`：新增 TASKS_TABLE 定义，ALL_TABLES 添加
- [x] A1.8 `schema.py`：新增 tasks 相关索引（idx_tasks_project/idx_tasks_feature/idx_tasks_status）
- [x] A1.9 自测：删除测试数据库，运行 init_db 验证迁移无报错

### A2. issue_repo 变更（需求 1.4）

- [x] A2.1 `issue_repo.py`：create() 新增 parent_id 参数（默认 0），INSERT 语句新增 parent_id 字段
- [x] A2.2 `issue_repo.py`：update() 的 allowed 集合扩展，新增 description/investigation/root_cause/solution/files_changed/test_result/notes/feature_id
- [x] A2.3 `issue_repo.py`：archive() 的 INSERT 语句扩展，写入所有结构化字段 + status 到 issues_archive
- [x] A2.4 自测：pytest 验证 create/update/archive 的新字段读写正确

### A3. track 工具变更（需求 1.4）

- [x] A3.1 `track.py`：create 分支读取 args.get("parent_id", 0) 传入 repo.create()
- [x] A3.2 `track.py`：新增 delete 分支，调用 repo.delete(issue_id)
- [x] A3.3 `track.py`：update 分支的 fields 提取扩展，支持所有结构化字段
- [x] A3.4 `__init__.py`：track 的 TOOL_DEFINITIONS inputSchema 新增 parent_id、delete action、结构化字段参数
- [x] A3.5 自测：MCP JSON-RPC 验证 create(parent_id)/delete/update(结构化字段)

### A4. Web API 变更（需求 1.5）

- [x] A4.1 `api.py`：get_issues 返回结果自动包含新字段（SELECT * 已覆盖，验证即可）
- [x] A4.2 `api.py`：put_issue 支持更新所有新字段
- [x] A4.3 `api.py`：post_issue 支持创建时传入 parent_id 和结构化字段
- [x] A4.4 `api.py`：delete_issue 确认兼容（已有实现）
- [x] A4.5 自测：启动 web server，API 请求验证新字段读写

### A5. 看板 UI 变更（需求 1.5）

- [x] A5.1 `app.js`：issues 列表中子问题（parent_id > 0）标题后标注"关联 #xxx"
- [x] A5.2 `app.js`：issues 列表新增结构化字段折叠展示区域
- [x] A5.3 `app.js`：issue 详情页展示所有结构化字段
- [x] A5.4 `app.js`：files_changed 以列表形式展示（路径 + 完成状态）
- [x] A5.5 `style.css`：结构化字段展示样式（折叠/展开、字段区域布局）
- [x] A5.6 自测：Playwright 验证列表页关联标注 + 折叠展开 + 详情页字段展示

---

## 批次 B：任务机制

### B1. task_repo 新增（需求 2.4）

- [x] B1.1 新建 `aivectormemory/db/task_repo.py`：TaskRepo 类
- [x] B1.2 TaskRepo.batch_create()：批量创建任务，同 feature_id + 同 title 去重
- [x] B1.3 TaskRepo.update()：更新单个任务的 status/title
- [x] B1.4 TaskRepo.list_by_feature()：按 feature_id 和 status 过滤查询
- [x] B1.5 自测：pytest 验证 batch_create 去重 + update + list 过滤

### B2. task 工具新增（需求 2.5）

- [x] B2.1 新建 `aivectormemory/tools/task.py`：handle_task 函数
- [x] B2.2 handle_task：batch_create action 实现
- [x] B2.3 handle_task：update action 实现
- [x] B2.4 handle_task：list action 实现
- [x] B2.5 `__init__.py`：TOOL_DEFINITIONS 新增 task 定义
- [x] B2.6 `__init__.py`：TOOL_HANDLERS 注册 handle_task
- [x] B2.7 自测：MCP JSON-RPC 验证 batch_create/update/list

### B3. task Web API + 看板（需求 2.6）

- [x] B3.1 `api.py`：新增 GET /tasks 接口（按 feature_id 查询）
- [x] B3.2 `api.py`：新增 POST /tasks 接口（批量创建）
- [x] B3.3 `api.py`：新增 PUT /tasks/:id 接口（更新状态）
- [x] B3.4 `app.js`：看板新增任务视图页面（按 feature 分组展示）
- [x] B3.5 `style.css`：任务视图样式
- [x] B3.6 自测：Playwright 验证任务视图展示 + 状态更新

### B4. steering 模板更新（需求 2.7）

- [x] B4.1 `install.py`：STEERING_CONTENT 工具速查表新增 task 行
- [x] B4.2 `install.py`：STEERING_CONTENT "何时调用"章节新增 task 相关说明
- [x] B4.3 自测：运行 install 验证 steering 输出包含 task 内容

---

## 批次 C：README 生成工具

### C1. readme 工具新增（需求 3.3）

- [x] C1.1 新建 `aivectormemory/tools/readme.py`：handle_readme 函数
- [x] C1.2 handle_readme：generate action（从 TOOL_DEFINITIONS/pyproject.toml/STEERING_CONTENT 提取内容）
- [x] C1.3 handle_readme：diff action（对比当前 README 与生成内容）
- [x] C1.4 handle_readme：多语言支持（en/zh-TW/ja/de/fr/es）
- [x] C1.5 `__init__.py`：TOOL_DEFINITIONS 新增 readme 定义
- [x] C1.6 `__init__.py`：TOOL_HANDLERS 注册 handle_readme
- [x] C1.7 自测：MCP JSON-RPC 验证 generate/diff 输出正确

---

## 收尾

- [x] Z1 ~~pyproject.toml 版本号改为 0.2.5~~（按规范：版本号在 PyPI 发布时升级）
- [x] Z2 全量 pytest 通过（82 passed）
- [ ] Z3 用户验证确认