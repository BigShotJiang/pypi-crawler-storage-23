# v0.2.5 需求文档

> 基于 OpenSpec 对比分析，针对问题追踪、任务机制、README 生成 3 项升级改进。
> 当前版本：0.2.4

---

## 1. track 问题追踪结构化 + 问题关联（高优先级）

### 1.1 背景

当前 issues 表只有一个 `content` 文本字段，所有排查信息混在一起，无法按阶段查看、看板无法分区渲染。同时修复过程中经常发现新问题，无法记录问题之间的关联关系。

### 1.2 需求

将 `content` 拆分为结构化字段，支持问题追踪的完整流程链：

```
问题描述 → 排查过程(逐步) → 根本原因 → 解决方案 → 修改文件清单 → 自测结果 → 注意事项
```

同时支持通过 `parent_id` 记录问题间的关联关系。

### 1.3 数据库变更

**issues 表新增字段**（保留原 `content` 字段做兼容）：

| 字段 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| description | TEXT | '' | 问题描述 |
| investigation | TEXT | '' | 排查过程（逐步记录） |
| root_cause | TEXT | '' | 根本原因 |
| solution | TEXT | '' | 解决方案 |
| files_changed | TEXT | '[]' | 修改文件清单（JSON 数组，每项含 path + done 状态） |
| test_result | TEXT | '' | 自测结果 |
| notes | TEXT | '' | 注意事项 |
| feature_id | TEXT | '' | 关联的功能标识（关联 spec 文档和 task） |
| parent_id | INTEGER | 0 | 父问题 ID（0 表示顶级问题，用于记录问题间关联关系） |

**issues_archive 表**同步新增以上所有字段，并补充 `status` 字段（当前缺失）：

| 字段 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| description | TEXT | '' | 问题描述 |
| investigation | TEXT | '' | 排查过程 |
| root_cause | TEXT | '' | 根本原因 |
| solution | TEXT | '' | 解决方案 |
| files_changed | TEXT | '[]' | 修改文件清单 |
| test_result | TEXT | '' | 自测结果 |
| notes | TEXT | '' | 注意事项 |
| feature_id | TEXT | '' | 关联功能标识 |
| parent_id | INTEGER | 0 | 父问题 ID |
| status | TEXT | '' | 归档时的状态（当前缺失，需补上） |

> **遗漏补充**：当前 `issues_archive` 表缺少 `status` 字段（`issues` 表有但归档表没有），迁移时需一并补上。

**schema 迁移**（CURRENT_SCHEMA_VERSION 升至 4）：
- ALTER TABLE issues ADD COLUMN ... 逐字段添加
- ALTER TABLE issues_archive ADD COLUMN ... 逐字段添加
- 已有数据的 `content` 保留不动，新字段默认空

### 1.4 track 工具变更

**create action 新增参数**：

| 参数 | 类型 | 说明 |
|------|------|------|
| parent_id | INTEGER | 父问题 ID（可选，默认 0，用于记录"修复 A 时发现 B"的关联关系） |

- `handle_track` 的 create 分支：将 `parent_id` 传入 `repo.create()`
- `IssueRepo.create()` 新增 `parent_id` 参数，写入数据库
- `IssueRepo.create()` 的 INSERT 语句新增 `parent_id` 字段

**新增 delete action**：

当前 track 工具只有 create/update/archive/list 四个 action，缺少 delete。

- 新增 `action="delete"`，调用 `IssueRepo.delete(issue_id)`（已有实现）
- 用途：删除误创建的问题（区别于 archive 归档）
- TOOL_DEFINITIONS 中 track 的 action enum 新增 `"delete"`

**update action 新增结构化字段**：

当前 update 的 allowed 字段只有 `{"title", "status", "content", "memory_id"}`，需扩展为：

```python
allowed = {"title", "status", "content", "memory_id",
           "description", "investigation", "root_cause", "solution",
           "files_changed", "test_result", "notes", "feature_id"}
```

**archive action 变更**：

当前 `IssueRepo.archive()` 的 INSERT 语句只写入 project_dir/issue_number/date/title/content/memory_id/archived_at/created_at，需扩展为同时写入所有结构化字段（description/investigation/root_cause/solution/files_changed/test_result/notes/feature_id/parent_id/status）到 issues_archive 表。

**list action 增强**：
- 返回结果中包含 `parent_id` 字段
- 子问题在列表中标注父问题编号，便于 AI 理解关联关系

### 1.5 看板变更

**issues 列表页**：
- 子问题（parent_id > 0）在标题后标注 `关联 #xxx`（xxx 为父问题编号）
- 不做树形渲染，保持扁平列表
- 新增结构化字段的展示区域（折叠式，点击展开查看排查过程、根因、方案等）

**issue 详情/编辑页**：
- 展示所有结构化字段（description、investigation、root_cause、solution、files_changed、test_result、notes）
- `files_changed` 以列表形式展示，每项含文件路径和完成状态
- `feature_id` 显示为关联标识
- `parent_id` 显示为关联的父问题链接

**API 变更**（`aivectormemory/web/api.py`）：
- `get_issues`：返回结果包含所有新字段
- `put_issue`：支持更新所有新字段
- `post_issue`：支持创建时传入 parent_id 和结构化字段

### 1.6 涉及文件

| 文件 | 变更内容 |
|------|----------|
| `aivectormemory/db/schema.py` | CURRENT_SCHEMA_VERSION 升至 4，新增 v4 迁移逻辑（ALTER TABLE 添加字段） |
| `aivectormemory/db/issue_repo.py` | create/update/archive 方法支持新字段，allowed 集合扩展 |
| `aivectormemory/tools/track.py` | create 支持 parent_id，新增 delete action，update 支持结构化字段 |
| `aivectormemory/tools/__init__.py` | track 的 TOOL_DEFINITIONS 新增 parent_id、delete、结构化字段参数 |
| `aivectormemory/web/api.py` | issues 相关 API 支持新字段 |
| `aivectormemory/web/static/app.js` | 看板 UI 展示结构化字段、关联标注 |
| `aivectormemory/web/static/style.css` | 结构化字段展示样式 |
| `aivectormemory/web/static/index.html` | 详情页模板（如需） |

---

## 2. 任务机制（中优先级）

### 2.1 背景

当前项目缺少任务管理工具。开发流程中的任务拆分、进度跟踪依赖 `.kiro/specs/*/tasks.md` 手动维护，AI 无法程序化地创建、更新、查询任务状态。

### 2.2 整体架构（混合方案 C）

采用文件 + 数据库混合方案：

- **需求文档 + 设计文档**：继续用 `.kiro/specs/*/` 下的 markdown 文件管理，进 git 版本控制
- **任务执行状态**：存数据库（tasks 表），通过 MCP task 工具程序化管理
- **关联方式**：通过 `feature_id` 关联（如 `feature_id="v0.2.5-track"` 同时出现在 spec 目录名和 tasks 表中）

这样需求/设计文档可以 diff 审查、跨会话持久化，任务状态可以被 AI 程序化查询和更新。

### 2.3 需求

新增 `task` 工具，提供任务的批量创建、状态更新、列表查询功能。任务与 track 问题通过 `feature_id` 关联。

### 2.4 数据库变更

**新增 tasks 表**：

| 字段 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| id | INTEGER | AUTO | 主键 |
| project_dir | TEXT | '' | 项目目录 |
| feature_id | TEXT | '' | 关联的功能标识（与 issues.feature_id 对应） |
| title | TEXT | - | 任务标题 |
| status | TEXT | 'pending' | 状态：pending / in_progress / completed / skipped |
| sort_order | INTEGER | 0 | 排序序号 |
| created_at | TEXT | - | 创建时间 |
| updated_at | TEXT | - | 更新时间 |

**schema 迁移**（与第 1 项合并在 v4 迁移中）：
- CREATE TABLE IF NOT EXISTS tasks ...
- 新增索引：idx_tasks_project、idx_tasks_feature、idx_tasks_status

### 2.5 task 工具设计

**actions**：

| action | 参数 | 说明 |
|--------|------|------|
| batch_create | feature_id, tasks: [{title, sort_order}] | 批量创建任务，返回创建数量 |
| update | task_id, status, title(可选) | 更新单个任务状态或标题 |
| list | feature_id(可选), status(可选) | 查询任务列表，支持按 feature 和状态过滤 |

- 不做 delete action（任务用 skipped 状态替代删除）
- batch_create 去重：同 feature_id + 同 title 不重复创建

### 2.6 涉及文件

| 文件 | 变更内容 |
|------|----------|
| `aivectormemory/db/schema.py` | 新增 TASKS_TABLE 定义，ALL_TABLES 添加，v4 迁移包含 |
| `aivectormemory/db/task_repo.py` | 新增文件，TaskRepo 类（batch_create / update / list_by_feature） |
| `aivectormemory/tools/task.py` | 新增文件，handle_task 函数 |
| `aivectormemory/tools/__init__.py` | TOOL_DEFINITIONS 新增 task，TOOL_HANDLERS 注册 |
| `aivectormemory/web/api.py` | 新增 tasks 相关 API（get_tasks / post_task / put_task） |
| `aivectormemory/web/static/app.js` | 看板新增任务视图（按 feature 分组展示） |
| `aivectormemory/install.py` | STEERING_CONTENT 工具速查表新增 task 行 |

### 2.7 steering 模板补充

`install.py` 的 `STEERING_CONTENT` 需同步更新：

**工具速查表新增 task 行**：

```
| task | 任务管理 | action(batch_create/update/list), feature_id, tasks |
```

**"何时调用"章节新增**：

```
- 拆分任务时：调用 `task`（action: batch_create）批量创建任务
- 完成子任务时：调用 `task`（action: update）更新状态为 completed
- 查看任务进度时：调用 `task`（action: list）按 feature 查询
```

---

## 3. README 生成工具（低优先级）

### 3.1 背景

当前 README 文档（含多语言版本）需要手动维护，版本更新时容易遗漏。需要一个工具从代码和配置中自动生成 README。

### 3.2 需求

新增 `readme` 工具，从 `TOOL_DEFINITIONS`、`STEERING_CONTENT`、`pyproject.toml` 等源自动生成 README 内容。

### 3.3 设计

**actions**：

| action | 参数 | 说明 |
|--------|------|------|
| generate | lang(默认 "en"), sections(可选) | 生成指定语言的 README 内容 |
| diff | lang(默认 "en") | 对比当前 README 与生成内容的差异 |

**生成逻辑**：
- 从 `TOOL_DEFINITIONS` 提取工具列表和参数说明
- 从 `pyproject.toml` 提取版本号、依赖、项目描述
- 从 `STEERING_CONTENT` 提取使用规则摘要
- 支持语言：en / zh-TW / ja / de / fr / es（对应 docs/ 目录下已有文件）

### 3.4 涉及文件

| 文件 | 变更内容 |
|------|----------|
| `aivectormemory/tools/readme.py` | 新增文件，handle_readme 函数 |
| `aivectormemory/tools/__init__.py` | TOOL_DEFINITIONS 新增 readme，TOOL_HANDLERS 注册 |

---

## 看板改动汇总

| 页面 | 来源需求 | 变更内容 |
|------|----------|----------|
| issues 列表 | 1.5 | 子问题标注"关联 #xxx"，结构化字段折叠展示 |
| issue 详情 | 1.5 | 展示所有结构化字段 |
| tasks 视图 | 2.6 | 新增任务列表页，按 feature 分组 |

---

## 实施分组建议

| 批次 | 内容 | 优先级 |
|------|------|--------|
| A | 第 1 项：track 结构化 + 问题关联 | 高 |
| B | 第 2 项：任务机制 | 中 |
| C | 第 3 项：README 生成 | 低 |

批次 A 和 B 共享 schema v4 迁移，建议合并开发、分开测试。

---

## 跨 IDE 兼容性总则

- 所有新增工具（task、readme）必须在 `TOOL_DEFINITIONS` 中定义，确保所有 IDE 通过 MCP 协议统一调用
- `install.py` 的 `STEERING_CONTENT` 同步更新工具速查表和调用时机
- 看板变更仅影响 `aivectormemory/web/` 目录，不影响 MCP 协议层
- schema 迁移通过 `init_db()` 自动执行，用户无需手动操作