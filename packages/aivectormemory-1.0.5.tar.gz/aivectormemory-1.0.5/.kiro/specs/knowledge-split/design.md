# 设计文档：知识库拆表重构

## 架构概览

```
改动前：
memories (混存) ──→ vec_memories
issues ──→ issues_archive (无向量)

改动后：
memories (项目知识) ──→ vec_memories
user_memories (用户偏好) ──→ vec_user_memories
issues ──→ issues_archive ──→ vec_issues_archive
```

核心变化：memories 按职责拆为 memories + user_memories，issues_archive 加向量索引，auto_save 精简为只存偏好，digest 工具删除，track 清理自动任务机制，agentStop hook 删除。

---

## 一、新增 UserMemoryRepo

### 文件：`db/user_memory_repo.py`（新建）

从 MemoryRepo 提取 user scope 逻辑，独立管理 user_memories 表。

```python
class UserMemoryRepo:
    def __init__(self, conn):
        # 不需要 project_dir，user_memories 是跨项目的
        self.conn = conn

    def insert(self, content, tags, session_id, embedding, dedup_threshold=0.95, source="manual") -> dict:
        # 去重逻辑：在 vec_user_memories 中查找相似向量
        # 写入 user_memories + vec_user_memories

    def search_by_vector(self, embedding, top_k=5) -> list[dict]:
        # 从 vec_user_memories 搜索

    def search_by_vector_with_tags(self, embedding, tags, top_k=5) -> list[dict]:
        # 带标签过滤的向量搜索

    def delete(self, mid) -> bool:
        # 同时删除 user_memories + vec_user_memories

    def list_by_tags(self, tags, limit=100, source=None) -> list[dict]:
        # 按标签查询

    def get_all(self, limit=100, offset=0) -> list[dict]
    def get_by_id(self, mid) -> dict | None
    def count(self) -> int
    def get_tag_counts(self) -> dict[str, int]
    def get_ids_with_tag(self, tag) -> list[dict]
```

### 与 MemoryRepo 的关系

- MemoryRepo 不再处理 scope="user"，移除 USER_SCOPE_DIR 相关逻辑
- MemoryRepo.insert 的 scope 参数保留但只接受 "project"
- MemoryRepo.search_by_vector 的 scope 参数移除 "user" 分支
- MemoryRepo.list_by_tags 的 scope 参数移除 "user" 分支

### MemoryRepo 具体改动

```python
# 移除的逻辑：
# insert() 中: pdir = USER_SCOPE_DIR if scope == "user" else self.project_dir
# 改为: pdir = self.project_dir（scope 参数可保留但忽略）

# search_by_vector() 中:
# if scope == "user" and mem["project_dir"] != USER_SCOPE_DIR: continue
# 移除此分支

# list_by_tags() 中:
# elif scope == "user": sql += " AND project_dir=?"; params.append(USER_SCOPE_DIR)
# 移除此分支
```

---

## 二、IssueRepo 加向量索引

### 文件：`db/issue_repo.py`

archive 方法新增 embedding 生成和写入。

```python
class IssueRepo:
    def __init__(self, conn, project_dir="", engine=None):
        # 新增 engine 参数，用于生成 embedding
        self.engine = engine

    def archive(self, issue_id) -> dict | None:
        # 现有归档逻辑不变
        # 新增：归档后生成 embedding 写入 vec_issues_archive
        if self.engine:
            text = f"{r['title']} {r.get('description','')} {r.get('root_cause','')} {r.get('solution','')}"
            embedding = self.engine.encode(text)
            self.conn.execute(
                "INSERT INTO vec_issues_archive (id, embedding) VALUES (?, ?)",
                (archive_id, json.dumps(embedding))
            )
            self.conn.commit()

    def search_archive_by_vector(self, embedding, top_k=5) -> list[dict]:
        # 新增方法：从 vec_issues_archive 语义搜索归档问题
        rows = self.conn.execute(
            "SELECT id, distance FROM vec_issues_archive WHERE embedding MATCH ? AND k = ?",
            (json.dumps(embedding), top_k * 2)
        ).fetchall()
        results = []
        for r in rows:
            archive = self.conn.execute(
                "SELECT * FROM issues_archive WHERE id=? AND project_dir=?",
                (r["id"], self.project_dir)
            ).fetchone()
            if archive:
                d = dict(archive)
                d["similarity"] = round(1 - (r["distance"] ** 2) / 2, 4)
                results.append(d)
            if len(results) >= top_k:
                break
        return results
```

### archive 方法改动点

当前 archive 流程：
1. 从 issues 读取记录
2. INSERT INTO issues_archive
3. DELETE FROM issues

新增步骤（在 INSERT 之后）：
4. 拼接 `title + description + root_cause + solution` 生成 embedding
5. INSERT INTO vec_issues_archive

需要获取 archive 后的 id（用 `cursor.lastrowid`），当前代码没有保存这个值，需要调整。

---

## 三、recall 多表路由

### 文件：`tools/recall.py`

当前 recall 只查 memories 表。改动后根据参数路由到不同表。

```python
def handle_recall(args, *, cm, engine, **_):
    source = args.get("source")

    # 路由 1：source="experience" → 搜 vec_issues_archive
    if source == "experience":
        return _recall_experience(args, cm=cm, engine=engine)

    # 路由 2：scope="user" → 搜 user_memories
    scope = args.get("scope", "all")
    if scope == "user":
        return _recall_user(args, cm=cm, engine=engine)

    # 路由 3：scope="project" → 搜 memories
    if scope == "project":
        return _recall_project(args, cm=cm, engine=engine)

    # 路由 4：scope="all" → 合并搜 memories + user_memories
    return _recall_all(args, cm=cm, engine=engine)
```

### _recall_experience 实现

```python
def _recall_experience(args, *, cm, engine):
    query = args.get("query")
    if not query:
        raise ValueError("query is required for source=experience")
    top_k = args.get("top_k", DEFAULT_TOP_K)
    brief = args.get("brief", False)

    embedding = engine.encode(query)
    issue_repo = IssueRepo(cm.conn, cm.project_dir, engine=engine)
    rows = issue_repo.search_archive_by_vector(embedding, top_k=top_k)

    # 统一返回格式：{id, content, tags, similarity}
    results = []
    for r in rows:
        content = f"{r['title']}\n根因：{r.get('root_cause','')}\n方案：{r.get('solution','')}"
        results.append({
            "id": r["id"],
            "content": content,
            "tags": ["经验"],
            "similarity": r["similarity"],
        })
    return json.dumps(success_response(memories=_to_brief(results) if brief else results))
```

### recall inputSchema 变更

```python
"source": {
    "type": "string",
    "enum": ["manual", "experience"],  # 移除 "auto_save"，新增 "experience"
    "description": "按来源过滤：manual=项目知识, experience=归档经验。不传则不过滤"
}
```

---

## 四、remember scope 路由

### 文件：`tools/remember.py`

```python
def handle_remember(args, *, cm, engine, session_id, **_):
    scope = args.get("scope", "project")

    if scope == "user":
        from aivectormemory.db.user_memory_repo import UserMemoryRepo
        repo = UserMemoryRepo(cm.conn)
        result = repo.insert(content, tags, session_id, embedding, DEDUP_THRESHOLD)
    else:
        repo = MemoryRepo(cm.conn, cm.project_dir)
        result = repo.insert(content, tags, scope, session_id, embedding, DEDUP_THRESHOLD)
```

---

## 五、forget scope 路由

### 文件：`tools/forget.py`

```python
def handle_forget(args, *, cm, **_):
    scope = args.get("scope", "all")

    if scope == "user":
        repo = UserMemoryRepo(cm.conn)
    elif scope == "project":
        repo = MemoryRepo(cm.conn, cm.project_dir)
    else:  # all
        # 两表都尝试删除
        mem_repo = MemoryRepo(cm.conn, cm.project_dir)
        user_repo = UserMemoryRepo(cm.conn)
        # 先尝试 memories，再尝试 user_memories
```

---

## 六、auto_save 精简

### 文件：`tools/auto_save.py`

改动前：5 个分类（decisions/modifications/pitfalls/todos/preferences），写入 memories 表。
改动后：只保留 preferences，写入 user_memories 表。

```python
def handle_auto_save(args, *, cm, engine, session_id, **_):
    items = args.get("preferences", [])
    if not items or not isinstance(items, list):
        return json.dumps(success_response(saved=[], count=0))

    from aivectormemory.db.user_memory_repo import UserMemoryRepo
    repo = UserMemoryRepo(cm.conn)
    saved = []
    for item in items:
        if not item or not isinstance(item, str):
            continue
        item = item[:5000] if len(item) > 5000 else item
        embedding = engine.encode(item)
        tags = ["preference"] + args.get("extra_tags", [])
        result = repo.insert(item, tags, session_id, embedding, DEDUP_THRESHOLD, source="auto_save")
        saved.append({"id": result["id"], "action": result["action"], "category": "preferences"})
    return json.dumps(success_response(saved=saved, count=len(saved)))
```

删除的内容：
- `CATEGORY_TAG_MAP`（5 个分类映射）
- `CATEGORY_SCOPE_OVERRIDE`
- `_check_digest_threshold` 函数
- `DIGEST_TASK_TITLE`、`DIGEST_HINT`、`DEFAULT_DIGEST_THRESHOLD` 常量
- `from aivectormemory.db.task_repo import TaskRepo` 导入

---

## 七、track.py 清理

### 文件：`tools/track.py`

删除自动任务创建机制。

删除的内容：
- `ISSUE_STEPS` 常量
- `from aivectormemory.db.task_repo import TaskRepo` 导入
- create 中 `task_repo.batch_create` 和 `repo.update(result["id"], feature_id=feature_id)` 逻辑
- archive 中 `task_repo.complete_by_feature` 逻辑

archive 新增 embedding 生成（通过 IssueRepo.engine）：
- handle_track 需要接收 engine 参数
- 创建 IssueRepo 时传入 engine：`IssueRepo(cm.conn, cm.project_dir, engine=engine)`

---

## 八、digest 工具删除

### 删除文件：`tools/digest.py`

### `tools/__init__.py` 改动
- TOOL_DEFINITIONS 移除 digest 定义
- 移除 `from aivectormemory.tools.digest import handle_digest`
- TOOL_HANDLERS 移除 `"digest": handle_digest`

### `server.py` 改动
- 无直接改动（server.py 通过 TOOL_HANDLERS 字典路由，删除 __init__.py 中的条目即可）

---

## 九、tools/__init__.py 工具定义更新

### auto_save inputSchema
```python
{
    "name": "auto_save",
    "description": "【每次对话结束前必须调用】自动保存用户偏好。",
    "inputSchema": {
        "type": "object",
        "properties": {
            "preferences": {"type": "array", "items": {"type": "string"}, "description": "用户表达的技术偏好（固定 scope=user，跨项目通用）"},
            "extra_tags": {"type": "array", "items": {"type": "string"}, "description": "额外标签"}
        }
    }
}
```

### recall inputSchema
- source enum 改为 `["manual", "experience"]`
- source description 改为 `"按来源过滤：manual=项目知识, experience=归档经验"`

### 移除 digest 工具定义

---

## 十、server.py 改动

### IssueRepo 初始化传入 engine

当前 server.py 中 handle_tools_call 传递 `cm=self.cm, engine=self.engine`，各 handler 自行创建 repo。

track handler 中创建 IssueRepo 时需要 engine，但当前 handle_track 签名是 `(args, *, cm, **_)`，engine 被 `**_` 吞掉了。

方案：handle_track 签名改为 `(args, *, cm, engine=None, **_)`，创建 IssueRepo 时传入 engine。

---

## 十一、web/api.py 改动

### user scope 路由改用 UserMemoryRepo

当前 api.py 中所有 user scope 查询都通过 MemoryRepo + USER_SCOPE_DIR 实现。改动后：

- `get_memories`：scope="user" 时用 UserMemoryRepo
- `get_stats`：user_count 从 UserMemoryRepo.count() 获取
- `get_tags`：user 标签从 UserMemoryRepo.get_tag_counts() 获取
- `search_memories`：scope="user" 时用 UserMemoryRepo
- `export_memories`：scope="user" 时从 user_memories 导出
- `import_memories`：根据 scope 路由到对应 repo
- `rename_tag`、`merge_tags`、`delete_tags`：同时操作 memories + user_memories
- `get_projects`：user_memories 的统计从 UserMemoryRepo 获取
- `delete_project`：不需要删除 user_memories（跨项目）

### 新增需要改动的函数

- `get_memory_detail`：先查 memories，找不到再查 user_memories
- `delete_memories_batch`：需要同时从 memories 和 user_memories 删除（根据 id 判断属于哪个表）

### 辅助函数改动

```python
# _merged_tag_counts 改为：
def _merged_tag_counts(mem_repo, user_repo, pdir):
    proj = mem_repo.get_tag_counts(project_dir=pdir)
    user = user_repo.get_tag_counts()
    # 合并逻辑不变

# _merged_ids_with_tag 改为：
def _merged_ids_with_tag(mem_repo, user_repo, tag, pdir):
    proj = mem_repo.get_ids_with_tag(tag, project_dir=pdir)
    user = user_repo.get_ids_with_tag(tag)
    # 合并逻辑不变
```

---

## 十二、数据库迁移 v7

### 文件：`db/schema.py`

### 新增表定义

```python
USER_MEMORIES_TABLE = """
CREATE TABLE IF NOT EXISTS user_memories (
    id TEXT PRIMARY KEY,
    content TEXT NOT NULL,
    tags TEXT NOT NULL DEFAULT '[]',
    source TEXT NOT NULL DEFAULT 'manual',
    session_id INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
)"""

VEC_USER_MEMORIES_TABLE = """
CREATE VIRTUAL TABLE IF NOT EXISTS vec_user_memories USING vec0(
    id TEXT PRIMARY KEY,
    embedding FLOAT[384]
)"""

VEC_ISSUES_ARCHIVE_TABLE = """
CREATE VIRTUAL TABLE IF NOT EXISTS vec_issues_archive USING vec0(
    id INTEGER PRIMARY KEY,
    embedding FLOAT[384]
)"""
```

### 新增索引

```python
"CREATE INDEX IF NOT EXISTS idx_user_memories_tags ON user_memories(tags)",
```

### v7 迁移逻辑

```python
if ver < 7:
    # 1. 创建新表
    conn.execute(USER_MEMORIES_TABLE)
    conn.execute(VEC_USER_MEMORIES_TABLE)
    conn.execute(VEC_ISSUES_ARCHIVE_TABLE)

    # 2. 迁移 scope=user 记录到 user_memories
    user_rows = conn.execute(
        "SELECT * FROM memories WHERE project_dir=?", (USER_SCOPE_DIR,)
    ).fetchall()
    for r in user_rows:
        conn.execute(
            "INSERT INTO user_memories (id, content, tags, source, session_id, created_at, updated_at) VALUES (?,?,?,?,?,?,?)",
            (r["id"], r["content"], r["tags"], r.get("source", "manual"), r["session_id"], r["created_at"], r["updated_at"])
        )
        # 迁移向量
        vec_row = conn.execute("SELECT embedding FROM vec_memories WHERE id=?", (r["id"],)).fetchone()
        if vec_row:
            conn.execute("INSERT INTO vec_user_memories (id, embedding) VALUES (?,?)", (r["id"], vec_row["embedding"]))
            conn.execute("DELETE FROM vec_memories WHERE id=?", (r["id"],))
        conn.execute("DELETE FROM memories WHERE id=?", (r["id"],))

    # 3. 删除 auto_save 碎片（decision/modification/pitfall/todo）
    conn.execute(
        "DELETE FROM vec_memories WHERE id IN ("
        "  SELECT id FROM memories WHERE source='auto_save' AND tags NOT LIKE '%\"preference\"%'"
        ")"
    )
    conn.execute(
        "DELETE FROM memories WHERE source='auto_save' AND tags NOT LIKE '%\"preference\"%'"
    )

    # 4. 踩坑记录迁移到 issues_archive
    pitfall_rows = conn.execute(
        "SELECT * FROM memories WHERE tags LIKE '%\"踩坑\"%'"
    ).fetchall()
    for r in pitfall_rows:
        content = r["content"]
        # title：取第一行，去掉 ## 前缀，截断 100 字符
        first_line = content.split("\n")[0].lstrip("# ").strip()[:100]
        created_date = r["created_at"][:10]  # YYYY-MM-DD
        now = _now()

        tags_list = json.loads(r["tags"]) if isinstance(r["tags"], str) else r["tags"]
        has_project_knowledge = "项目知识" in tags_list

        # 写入 issues_archive
        cur = conn.execute(
            """INSERT INTO issues_archive (project_dir, issue_number, date, title, content, description,
               root_cause, solution, status, archived_at, created_at)
               VALUES (?,0,?,?,?,?,?,?,?,?,?)""",
            (r["project_dir"], created_date, first_line, "", content, "", "", "completed", now, r["created_at"])
        )
        archive_id = cur.lastrowid

        # 生成 embedding 写入 vec_issues_archive（受超时防护控制）
        # 见下方超时防护逻辑

        if has_project_knowledge:
            # 双标签：保留在 memories，去掉"踩坑"标签
            new_tags = [t for t in tags_list if t != "踩坑"]
            conn.execute("UPDATE memories SET tags=? WHERE id=?",
                         (json.dumps(new_tags, ensure_ascii=False), r["id"]))
        else:
            # 只有踩坑标签：从 memories 删除
            conn.execute("DELETE FROM vec_memories WHERE id=?", (r["id"],))
            conn.execute("DELETE FROM memories WHERE id=?", (r["id"],))

    # 5. 删除 ISSUE_STEPS 产生的系统任务
    conn.execute(
        "DELETE FROM tasks WHERE task_type='system' AND feature_id LIKE 'issue/%'"
    )

    # 6. issues_archive 批量生成 embedding（超时防护）
    archive_count = conn.execute("SELECT COUNT(*) FROM issues_archive").fetchone()[0]
    if archive_count <= 50:
        archives = conn.execute(
            "SELECT id, title, description, root_cause, solution FROM issues_archive"
        ).fetchall()
        for a in archives:
            # 跳过已有 embedding 的记录
            existing = conn.execute(
                "SELECT id FROM vec_issues_archive WHERE id=?", (a["id"],)
            ).fetchone()
            if existing:
                continue
            text = f"{a['title']} {a.get('description','')} {a.get('root_cause','')} {a.get('solution','')}"
            embedding = engine.encode(text)
            conn.execute(
                "INSERT INTO vec_issues_archive (id, embedding) VALUES (?,?)",
                (a["id"], json.dumps(embedding))
            )
        print(f"[aivectormemory] v7 migration: generated embeddings for {archive_count} archived issues", file=sys.stderr)
    else:
        print(f"[aivectormemory] v7 migration: skipped embedding generation for {archive_count} archived issues (>50, will use lazy loading)", file=sys.stderr)
```

### init_db 签名变更

当前 `init_db(conn)` 不接收 engine 参数。v7 迁移需要 engine 生成 embedding。

方案：`init_db(conn, engine=None)`，v7 迁移中如果 engine 为 None 则跳过 embedding 生成。

server.py 中调用改为：`init_db(self.cm.conn, engine=self.engine)`

---

## 十三、agentStop hook 删除

### 删除文件
- `.kiro/hooks/auto-save-session.kiro.hook`

### install.py 改动
- `HOOKS_CONFIGS` 移除 `auto-save-session` 配置
- 各 IDE 的 stop hook 配置同步删除：
  - Claude Code: `CLAUDE_SETTINGS` 中移除 Stop hook
  - Cursor: `CURSOR_HOOKS` 中移除 stop hook
  - Windsurf: `WINDSURF_HOOKS` 中移除 post_cascade_response hook
  - OpenCode: plugin 模板中移除 auto_save 自动调用

---

## 十四、install.py steering 模板更新

### STEERING_CONTENT 改动
- 工具数量描述：从"提供以下 7 个工具"改为"提供以下 6 个工具"
- 工具速查表：移除 digest 行，更新 auto_save 描述
- 何时调用：移除 digest 相关说明，更新 auto_save 说明
- 知识库章节：移除 `remember(tags=["踩坑"])` 指引，改为 `track → archive` 流程
- 新增 recall source="experience" 使用说明

### dev-workflow-check hook prompt 改动
- 移除"Hook链式触发防护"段落（agentStop hook 删除后，不再有循环触发问题，该防护无意义）

### 各 IDE hook/plugin prompt 改动
- auto_save 参数从 5 个改为 1 个（只保留 preferences）
- 移除 digest_hint 相关提示

---

## 十五、实现顺序

1. db/schema.py — v7 迁移（新表 + 数据迁移）
2. db/user_memory_repo.py — 新建
3. db/memory_repo.py — 移除 USER_SCOPE_DIR 逻辑
4. db/issue_repo.py — archive 加 embedding + search_archive_by_vector
5. tools/recall.py — 多表路由
6. tools/remember.py — scope 路由
7. tools/forget.py — scope 路由
8. tools/auto_save.py — 精简为只存偏好
9. tools/track.py — 清理自动任务
10. tools/digest.py — 删除
11. tools/__init__.py — 更新工具定义
12. server.py — init_db 传 engine，IssueRepo 传 engine
13. web/api.py — user scope 路由改用 UserMemoryRepo
14. install.py — steering 模板 + hook 配置更新
15. .kiro/hooks/auto-save-session.kiro.hook — 删除
16. 测试更新
