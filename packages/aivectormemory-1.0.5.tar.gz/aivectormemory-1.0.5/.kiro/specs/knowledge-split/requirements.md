# 需求文档：知识库拆表重构

## 背景

现有 `memories` 表混存四类数据：
1. 项目知识（source=manual，标签含"项目知识"）— 启动时加载，高频使用
2. 踩坑记录（source=manual，标签含"踩坑"）— 低频检索，不需要启动加载，但混在 memories 中占用启动上下文
3. 用户偏好（source=auto_save，标签含"preference"，scope=user）— 启动时加载，跨项目通用
4. auto_save 碎片（source=auto_save，标签含 decision/modification/pitfall/todo）— 800+ 条堆积，价值低

同时 `issues_archive` 存有丰富的结构化经验数据（description/investigation/root_cause/solution），但没有向量索引，无法语义搜索。

**现状问题**：踩坑记录存在两条入口，导致使用时机混乱：
- 入口 A：`track create` → 修复 → `track archive` → 进入 issues_archive（结构化）
- 入口 B：`remember(tags=["踩坑"])` → 进入 memories（非结构化纯文本）

两条路记录的是同一类东西（开发经验），但分散在不同的表里，搜索时需要分别查。本次重构将取消入口 B，统一走入口 A。

## 核心目标

1. 按职责拆表，memories 只存项目知识，user_memories 存用户偏好
2. 砍掉低价值碎片存储，auto_save 只保留用户偏好
3. 给 issues_archive 加向量索引，作为踩坑经验的唯一存储
4. 统一踩坑入口：取消 `remember(tags=["踩坑"])`，所有踩坑统一走 `track → archive` 流程
5. 清理冗余的自动任务创建机制

---

## 现有表结构（v6）

| 表 | 用途 | 向量表 |
|---|---|---|
| memories | 混存所有记忆 | vec_memories |
| issues | 活跃问题追踪 | 无 |
| issues_archive | 归档问题 | 无 |
| tasks | 任务管理 | 无 |
| session_state | 会话状态 | 无 |

---

## 改动一：memories 表职责收窄

### 改动前
memories 存所有类型：项目知识、用户偏好、踩坑记录、auto_save 碎片

### 改动后
memories 只存项目知识（source=manual，scope=project）

- `remember` 工具写入 memories（仅项目知识）
- `recall` 工具从 memories 搜索（项目知识）
- 启动时 `recall(tags=["项目知识"])` 加载
- 踩坑记录不再存入 memories，统一走 `track → archive` 流程（见改动三）

### 不变
- memories 表结构不变
- vec_memories 表不变
- remember 接口不变（scope 路由见改动二）
- recall 接口新增 source 参数（路由逻辑见改动三）

### steering 规则变更
- 移除 `remember(tags=["踩坑"])` 的使用指引
- 遇到坑 → `track create`，修完 → `track archive`
- 查踩坑经验 → `recall(source="experience", query="关键词")`
- 记项目知识 → `remember(tags=["项目知识"])`

---

## 改动二：新增 user_memories + vec_user_memories

### 用途
存储用户偏好（scope=user），跨项目通用，启动时加载

### 表结构

```sql
CREATE TABLE IF NOT EXISTS user_memories (
    id TEXT PRIMARY KEY,
    content TEXT NOT NULL,
    tags TEXT NOT NULL DEFAULT '[]',
    source TEXT NOT NULL DEFAULT 'manual',
    session_id INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
)

CREATE VIRTUAL TABLE IF NOT EXISTS vec_user_memories USING vec0(
    id TEXT PRIMARY KEY,
    embedding FLOAT[384]
)
```

### 与 memories 的区别
- 没有 scope 字段（固定 user 级别）
- 没有 project_dir 字段（跨项目通用）
- 独立的向量表 vec_user_memories

### 数据来源
- auto_save 的 preferences 分类写入此表
- `remember(scope="user")` 写入此表
- `recall(scope="user")` 从此表搜索

### remember/recall 路由逻辑
- `handle_remember` 根据 scope 参数分发：scope="user" → UserMemoryRepo，scope="project" → MemoryRepo
- `handle_recall` 根据 scope 参数分发（完整路由见改动三）
- MemoryRepo 不再处理 scope="user" 的写入（移除 USER_SCOPE_DIR 逻辑）

---

## 改动三：issues_archive 加向量索引（踩坑经验唯一存储）

### 用途
归档问题作为踩坑经验的唯一存储，所有开发经验统一通过 `track → archive` 流程进入此表。遇到类似问题时可语义搜索历史经验。

### 统一入口
- 遇到坑 → `track create` 记录问题
- 修复后 → `track update` 填充 root_cause/solution
- 确认没问题 → `track archive` 归档（此时生成 embedding）
- 查经验 → `recall(source="experience", query="关键词")`
- 不再使用 `remember(tags=["踩坑"])` 存踩坑记录

### 新增表

```sql
CREATE VIRTUAL TABLE IF NOT EXISTS vec_issues_archive USING vec0(
    id INTEGER PRIMARY KEY,
    embedding FLOAT[384]
)
```

### embedding 生成时机
`track archive` 归档时，用问题的结构化内容生成 embedding 并写入 vec_issues_archive

### embedding 内容来源
拼接 issues 表的关键字段生成：`title + description + root_cause + solution`

### 搜索方式
`recall` 新增 `source` 参数选项 `"experience"`，搜索 issues_archive 表：
- `recall(query="xxx", source="experience")` → 从 vec_issues_archive 语义搜索
- 返回格式统一为 `{id, content, tags, similarity}`，其中 content 拼接 `title + root_cause + solution`
- 不新增独立工具，复用 recall 接口降低 AI 学习成本

### recall 完整路由逻辑（统一定义）
- `scope="project"` + 无 source → 搜 memories（项目知识）
- `scope="user"` → 搜 user_memories（用户偏好）
- `scope="all"` + 无 source → 合并搜 memories + user_memories
- `source="experience"` → 搜 vec_issues_archive（归档经验），忽略 scope 参数
- `source="auto_save"` → 废弃，不再支持

---

## 改动四：auto_save 精简

### 改动前
auto_save 存 5 个分类碎片：decisions/modifications/pitfalls/todos/preferences

### 改动后
auto_save 只保留 preferences（写入 user_memories 表）

### 砍掉的内容
- decisions 碎片 — 不再存储
- modifications 碎片 — 不再存储
- pitfalls 碎片 — 不再存储
- todos 碎片 — 不再存储

### 砍掉的机制
- `_check_digest_threshold` 函数 — 碎片不存了，阈值检测无意义
- `_sys/digest` 系统任务创建 — 没有碎片就不需要归纳任务
- `DIGEST_TASK_TITLE`、`DIGEST_HINT`、`DEFAULT_DIGEST_THRESHOLD` 常量 — 废弃

### auto_save 接口变更
- 参数只保留 `preferences` 和 `extra_tags`
- 移除 `decisions`、`modifications`、`pitfalls`、`todos` 参数
- MCP 工具定义（tools/__init__.py）同步更新 inputSchema

### 删除 agentStop hook（Kiro）

agentStop hook 的设计初衷是 agent 停止时自动调用 auto_save 防遗忘，但存在不可修复的循环触发问题：
- agent 回复任何内容 → agentStop → 触发 auto_save hook → agent 回复 → 又 agentStop → 循环约 7 次
- 循环产生的消息污染 context transfer 的 USER QUERIES，导致续接会话时 agent 无法识别真正的用户意图

精简后 auto_save 只保留 preferences，大多数对话不产生新偏好，hook 触发后几乎都是"无需保存" → 循环问题依然存在。steering 规则已覆盖 auto_save 调用时机（"对话结束前：调用 auto_save"），hook 的"防遗忘保险"价值不抵副作用。

具体清理：
- 删除本地 `.kiro/hooks/auto-save-session.kiro.hook` 文件
- `install.py` 的 `HOOKS_CONFIGS` 移除 `auto-save-session` 配置
- 各 IDE 的 agentStop/stop hook 同步删除：
  - Claude Code: `CLAUDE_SETTINGS` 中移除 Stop hook
  - Cursor: `CURSOR_HOOKS` 中移除 stop hook
  - Windsurf: `WINDSURF_HOOKS` 中移除 post_cascade_response hook
  - OpenCode: plugin 模板中移除 auto_save 自动调用

---

## 改动五：track create 自动任务清理

### 改动前
track create 创建问题时，自动在 tasks 表创建 5 步系统任务（ISSUE_STEPS）

### 改动后
砍掉这个自动创建逻辑

### 原因
issues 表字段本身已跟踪问题处理进度：
- description → investigation → root_cause → solution → files_changed → test_result
- CLAUDE.md 规则要求每步填充对应字段，不需要额外的 tasks 记录

### 具体清理
- track.py 中删除 `ISSUE_STEPS` 常量
- track create 中删除自动调用 `task_repo.batch_create` 的逻辑
- track create 中删除 `repo.update(result["id"], feature_id=feature_id)` 的逻辑
- track archive 中删除自动调用 `task_repo.complete_by_feature` 的逻辑
- track.py 中删除 `from aivectormemory.db.task_repo import TaskRepo` 导入（track 不再依赖 task_repo）
- issues 表的 `feature_id` 字段保留（手动关联仍可用），但不再自动填充

---

## 改动六：移除 digest 工具

### 原因
digest 的完整工作流是：auto_save 产生碎片 → digest 提取碎片列表 → AI 归纳合并 → remember 写回 → forget 删除碎片。碎片不存了（改动四），这条链路的输入没了，整个工具废弃。

### 具体清理
- 删除 `tools/digest.py`
- `tools/__init__.py` 移除 digest 工具定义
- `server.py` 移除 digest 路由注册（TOOL_HANDLERS 中删除 digest 条目）
- `install.py` steering 模板移除 digest 相关说明
- `install.py` 各 IDE 的 hook/plugin prompt 同步更新（auto_save 参数从 5 个改为 1 个）：
  - Kiro: `HOOKS_CONFIGS` 中 auto-save-session 的 prompt
  - Claude Code: `CLAUDE_SETTINGS` 中 Stop hook 的 prompt
  - Cursor: `CURSOR_HOOKS` 中 stop hook 的 command/script
  - Windsurf: `WINDSURF_HOOKS` 中 post_cascade_response hook
  - OpenCode: plugin 模板中的 auto_save 调用
- CLAUDE.md / AGENTS.md 移除 digest 相关工具描述，更新 auto_save 参数说明

---

## 改动七：数据库迁移 v7

### 新增表
- user_memories
- vec_user_memories
- vec_issues_archive

### 数据迁移
- memories 表中 scope=user 的记录迁移到 user_memories
- memories 表中 source=auto_save 且标签为 decision/modification/pitfall/todo 的记录删除
- memories 表中 tags 含"踩坑"的记录迁移到 issues_archive（见下方踩坑迁移规则），迁移后从 memories 删除
- issues_archive 中已有记录批量生成 embedding 写入 vec_issues_archive（见下方超时防护）
- tasks 表中 `task_type='system'` 且 `feature_id LIKE 'issue/%'` 的记录删除（ISSUE_STEPS 产生的冗余数据）

### 踩坑记录迁移规则
memories 中 tags 含"踩坑"的记录是非结构化纯文本，迁移到 issues_archive 时需要适配结构化字段：
- `title`：取 content 的第一行（去掉 `## ` 前缀），截断到 100 字符
- `description`：完整 content
- `root_cause`：空（非结构化记录无此字段）
- `solution`：空
- `date`：从 created_at 提取日期
- `status`：`completed`
- `archived_at`：迁移执行时间
- embedding 生成：用 `title + description` 拼接生成（因为 root_cause/solution 为空）

#### 双标签处理
部分记录同时含"踩坑"和"项目知识"标签（如"Kiro 上下文窗口调研结论"）：
- 同时含两个标签的记录：复制到 issues_archive，但保留在 memories 中（去掉"踩坑"标签，只留"项目知识"）
- 只含"踩坑"标签的记录：迁移到 issues_archive 后从 memories 删除

### v7 迁移超时防护
issues_archive 批量生成 embedding 在 MCP server 启动时同步执行（init_db），如果归档问题过多会导致 IDE 连接超时。

防护策略：
- 迁移时检查 issues_archive 数量，≤50 条直接批量生成
- >50 条时跳过批量 embedding，改为懒加载：`track archive` 归档时生成，`recall(source="experience")` 搜索时对无 embedding 的记录跳过
- 在 stderr 输出迁移进度日志：`[aivectormemory] v7 migration: generating embeddings for N archived issues`

### 索引
- idx_user_memories_tags

---

## 已确认决策

1. issues_archive 归档时 embedding 拼接：`title + description + root_cause + solution`，不含 investigation（排查过程噪音大，不适合语义匹配）
2. 旧 auto_save 碎片（800+ 条 decision/modification/pitfall/todo）：v7 迁移时直接删除，不做归纳
3. auto_save 的 MCP 工具定义：直接移除 decisions/modifications/pitfalls/todos 参数，不做向后兼容（自用 MCP server，无第三方兼容需求）
4. 踩坑记录统一入口：取消 `remember(tags=["踩坑"])` 路径，所有踩坑统一走 `track → archive` 流程，issues_archive 是踩坑经验的唯一存储
5. memories 表不需要 hot 字段：踩坑记录统一走 track 后，memories 里没有冷数据，全部是启动加载的项目知识
6. 职责划分：memories = 项目知识，user_memories = 用户偏好，issues_archive = 踩坑经验，三者不交叉
7. memories 中现有 tags 含"踩坑"的记录：v7 迁移时转入 issues_archive，适配结构化字段后删除原记录
8. 删除 agentStop hook：循环触发问题不可修复（平台限制），steering 规则已覆盖 auto_save 调用时机，hook 的防遗忘价值不抵副作用

---

## 涉及文件

| 文件 | 改动 |
|---|---|
| db/schema.py | v7 迁移：新增 3 张表 + 数据迁移 + 清理 issue/ 系统任务 + 超时防护 |
| db/memory_repo.py | 移除 USER_SCOPE_DIR 写入逻辑，scope=user 不再经过此 repo |
| db/user_memory_repo.py | 新增：UserMemoryRepo（insert/search/delete/list_by_tags） |
| db/issue_repo.py | archive 时生成 embedding 写入 vec_issues_archive；新增 search_archive_by_vector 方法 |
| tools/forget.py | scope 路由：user → UserMemoryRepo，project → MemoryRepo，all → 两表都尝试删除 |
| tools/auto_save.py | 精简为只处理 preferences，移除 5 分类和 digest 阈值检测 |
| tools/digest.py | 删除 |
| tools/track.py | 删除 ISSUE_STEPS、TaskRepo 导入和自动任务创建/完成逻辑 |
| tools/recall.py | 多表路由：scope 分发 + source="experience" 搜 issues_archive |
| tools/remember.py | scope 路由：user → UserMemoryRepo，project → MemoryRepo |
| tools/__init__.py | 更新 auto_save/recall 的 inputSchema，移除 digest 工具定义 |
| server.py | 注册 UserMemoryRepo，移除 digest 路由，engine 传递给 issue_repo |
| web/api.py | user scope 路由改用 UserMemoryRepo + 合并查询 user_memories 表（get_memories/get_stats/search_memories 等） |
| install.py | steering 模板更新（踩坑使用方式变更 + digest 移除）+ 各 IDE hook/plugin prompt 同步更新 auto_save 参数 + 移除各 IDE 的 agentStop/stop hook 配置 |
| .kiro/hooks/auto-save-session.kiro.hook | 删除 |
