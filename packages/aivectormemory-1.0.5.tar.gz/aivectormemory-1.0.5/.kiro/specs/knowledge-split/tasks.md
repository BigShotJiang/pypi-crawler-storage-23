# 任务文档：知识库拆表重构

## 阶段一：数据库层

- [x] 1.1 新建 `db/user_memory_repo.py`：UserMemoryRepo 类（insert/search_by_vector/search_by_vector_with_tags/delete/list_by_tags/get_all/get_by_id/count/get_tag_counts/get_ids_with_tag）
- [x] 1.2 `db/schema.py`：新增 USER_MEMORIES_TABLE、VEC_USER_MEMORIES_TABLE、VEC_ISSUES_ARCHIVE_TABLE 表定义，加入 ALL_TABLES
- [x] 1.3 `db/schema.py`：新增 idx_user_memories_tags 索引到 INDEXES
- [x] 1.4 `db/schema.py`：init_db 签名改为 `init_db(conn, engine=None)`，CURRENT_SCHEMA_VERSION 改为 7
- [x] 1.5 `db/schema.py`：v7 迁移 — 创建 3 张新表
- [x] 1.6 `db/schema.py`：v7 迁移 — scope=user 记录从 memories 迁移到 user_memories（含向量迁移）
- [x] 1.7 `db/schema.py`：v7 迁移 — 删除 auto_save 碎片（source=auto_save 且标签非 preference）
- [x] 1.8 `db/schema.py`：v7 迁移 — 踩坑记录迁移到 issues_archive（含双标签处理）
- [x] 1.9 `db/schema.py`：v7 迁移 — 删除 ISSUE_STEPS 系统任务（task_type=system AND feature_id LIKE issue/）
- [x] 1.10 `db/schema.py`：v7 迁移 — issues_archive 批量生成 embedding（含超时防护：≤50 直接生成，>50 跳过）
- [x] 1.11 `db/memory_repo.py`：移除 USER_SCOPE_DIR 相关逻辑（insert 中 pdir 判断、search_by_vector 中 user 分支、list_by_tags 中 user 分支）
- [x] 1.12 `db/issue_repo.py`：__init__ 新增 engine 参数
- [x] 1.13 `db/issue_repo.py`：archive 方法新增 embedding 生成和写入 vec_issues_archive（需获取 archive 后的 lastrowid）
- [x] 1.14 `db/issue_repo.py`：新增 search_archive_by_vector 方法
- [x] 1.15 `db/__init__.py`：导出 UserMemoryRepo（如需要）
- [x] 1.16 阶段一测试：运行现有测试确认不破坏，编写 v7 迁移测试

## 阶段二：工具层

- [x] 2.1 `tools/recall.py`：重构为多表路由（source=experience → issues_archive，scope=user → user_memories，scope=project → memories，scope=all → memories + user_memories 合并）
- [x] 2.2 `tools/remember.py`：scope 路由（user → UserMemoryRepo，project → MemoryRepo）
- [x] 2.3 `tools/forget.py`：scope 路由（user → UserMemoryRepo，project → MemoryRepo，all → 两表都尝试）
- [x] 2.4 `tools/auto_save.py`：精简为只处理 preferences，写入 UserMemoryRepo，删除 CATEGORY_TAG_MAP/CATEGORY_SCOPE_OVERRIDE/_check_digest_threshold/DIGEST_* 常量/TaskRepo 导入
- [x] 2.5 `tools/track.py`：删除 ISSUE_STEPS 常量、TaskRepo 导入、create 中自动任务创建逻辑、archive 中 complete_by_feature 逻辑；handle_track 签名新增 engine 参数，创建 IssueRepo 时传入 engine
- [x] 2.6 删除 `tools/digest.py`
- [x] 2.7 `tools/__init__.py`：更新 auto_save inputSchema（只保留 preferences + extra_tags）、recall inputSchema（source enum 改为 manual/experience）、移除 digest 工具定义和导入、移除 TOOL_HANDLERS 中 digest 条目
- [x] 2.8 阶段二测试：运行全量测试，修复因工具接口变更导致的测试失败

## 阶段三：服务层

- [x] 3.1 `server.py`：_init_db 调用改为 `init_db(self.cm.conn, engine=self.engine)`
- [x] 3.2 `server.py`：handle_tools_call 中 engine 已通过 kwargs 传递，确认 track handler 能接收到
- [x] 3.3 阶段三测试：运行全量测试

## 阶段四：看板 API

- [x] 4.1 `web/api.py`：get_memories — scope=user 时用 UserMemoryRepo 查询 user_memories 表
- [x] 4.2 `web/api.py`：get_stats — user_count 从 UserMemoryRepo.count() 获取
- [x] 4.3 `web/api.py`：get_tags — user 标签从 UserMemoryRepo.get_tag_counts() 获取
- [x] 4.4 `web/api.py`：search_memories — scope=user 时用 UserMemoryRepo 搜索
- [x] 4.5 `web/api.py`：export_memories — scope=user 时从 user_memories 导出（含 vec_user_memories 向量）
- [x] 4.6 `web/api.py`：import_memories — 根据 scope 路由到对应 repo
- [x] 4.7 `web/api.py`：rename_tag/merge_tags/delete_tags — 同时操作 memories + user_memories
- [x] 4.8 `web/api.py`：get_projects — user_memories 统计从 UserMemoryRepo 获取
- [x] 4.9 `web/api.py`：_merged_tag_counts/_merged_ids_with_tag 辅助函数改为接收 mem_repo + user_repo 两个参数
- [x] 4.10 `web/api.py`：put_memory/delete_memory — 需要判断记忆属于哪个表（memories 或 user_memories）
- [x] 4.11 `web/api.py`：get_memory_detail — 需要同时查 memories 和 user_memories
- [x] 4.12 `web/api.py`：delete_memories_batch — 需要同时从 memories 和 user_memories 删除
- [x] 4.13 阶段四测试：运行全量测试 + 看板功能验证

## 阶段五：安装脚本和 hook

- [x] 5.1 `install.py`：STEERING_CONTENT 模板更新 — 工具速查表移除 digest、更新 auto_save 描述、工具数量从 7 改为 6
- [x] 5.2 `install.py`：STEERING_CONTENT 模板更新 — 何时调用章节移除 digest 说明、更新 auto_save 说明
- [x] 5.3 `install.py`：STEERING_CONTENT 模板更新 — 知识库章节移除 remember(tags=["踩坑"]) 指引，新增 recall(source="experience") 说明
- [x] 5.4 `install.py`：HOOKS_CONFIGS 移除 auto-save-session 配置
- [x] 5.5 `install.py`：各 IDE stop hook 配置删除（Claude Code CLAUDE_SETTINGS / Cursor CURSOR_HOOKS / Windsurf WINDSURF_HOOKS / OpenCode plugin）
- [x] 5.6 `install.py`：各 IDE hook/plugin prompt 中 auto_save 参数从 5 个改为 1 个
- [x] 5.7 `install.py`：dev-workflow-check hook prompt 中移除"Hook链式触发防护"段落（agentStop hook 删除后该防护无意义）
- [x] 5.8 删除 `.kiro/hooks/auto-save-session.kiro.hook`
- [x] 5.9 阶段五测试：运行 test_hooks_install.py + test_steering_update.py + test_install.py + test_install_config.py

## 阶段六：自检

- [x] 6.1 运行全量测试（`pytest --ignore=tests/test_tree_render.py`），确认全部通过
- [x] 6.2 对照需求文档逐条验证：7 个改动 + 8 个已确认决策 + 涉及文件表
- [x] 6.3 对照设计文档逐节验证：15 个设计章节
