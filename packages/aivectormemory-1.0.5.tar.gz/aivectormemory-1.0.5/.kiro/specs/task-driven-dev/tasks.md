# 任务驱动开发模式 - 任务文档

## 阶段一：数据库层

- [x] 1.1 schema.py 新增 TASKS_ARCHIVE_TABLE 表定义
- [x] 1.2 schema.py TASKS_ARCHIVE_TABLE 加入 ALL_TABLES
- [x] 1.3 schema.py 新增 tasks_archive 索引（project、feature_id）
- [x] 1.4 schema.py v9 迁移：创建 tasks_archive 表
- [x] 1.5 CURRENT_SCHEMA_VERSION 改为 9
- [x] 1.6 阶段一测试

## 阶段二：仓库层

- [x] 2.1 task_repo.py 新增 archive_by_feature 方法
- [x] 2.2 task_repo.py 新增 list_archived 方法
- [x] 2.3 task_repo.py 新增 get_feature_status 方法
- [x] 2.4 issue_repo.py 新增 list_by_feature_id 方法
- [x] 2.5 issue_repo.py 新增 count_active_by_feature 方法
- [x] 2.6 阶段二测试

## 阶段三：工具层

- [x] 3.1 task.py 新增 archive action
- [x] 3.2 task.py update action 增加联动：同步关联问题状态
- [x] 3.3 track.py archive action 增加联动：最后一个活跃问题时归档任务
- [x] 3.4 tools/__init__.py 更新 task 工具的 inputSchema（action 枚举加 archive）
- [x] 3.5 阶段三测试

## 阶段四：看板 API

- [x] 4.1 api.py get_issues 返回 task_progress 字段
- [x] 4.2 api.py 新增 get_archived_tasks 函数
- [x] 4.3 api.py handle_api_request 注册归档任务路由
- [x] 4.4 阶段四测试

## 阶段五：前端

- [x] 5.1 app.js renderIssueCard 显示任务进度
- [x] 5.2 app.js 任务页面状态筛选新增「已归档」选项
- [x] 5.3 app.js loadTasks 处理归档筛选（调用归档 API、只读渲染）
- [x] 5.4 style.css 任务进度和归档相关样式
- [x] 5.5 阶段五 Playwright 验证

## 阶段六：自检

- [x] 6.1 全量 pytest 测试
- [x] 6.2 对照需求文档逐项验证
- [x] 6.3 对照设计文档逐项验证
