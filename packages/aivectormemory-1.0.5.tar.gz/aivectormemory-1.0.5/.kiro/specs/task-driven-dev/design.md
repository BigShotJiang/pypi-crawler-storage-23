# 任务驱动开发模式 - 设计文档

## 架构概览

通过 `feature_id` 字段将 issues 和 tasks 两个独立系统串联，在 `task update` 和 `track archive` 两个时机触发联动逻辑。

```
issues 表 ──── feature_id ────── tasks 表
    │                                │
    │  task update 时                │
    │  ← 自动同步状态 ←──────────────┘
    │
    │  track archive 时
    │  ──→ 检查是否最后一个活跃问题
    │       └─ 是 → 任务移入 tasks_archive
    │       └─ 否 → 不动
    ▼
issues_archive                tasks_archive（新表）
```

---

## 1. 数据库层

### 1.1 新增 tasks_archive 表

`schema.py` 新增表定义：

```python
TASKS_ARCHIVE_TABLE = """
CREATE TABLE IF NOT EXISTS tasks_archive (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    project_dir TEXT NOT NULL DEFAULT '',
    feature_id TEXT NOT NULL DEFAULT '',
    title TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'pending',
    sort_order INTEGER NOT NULL DEFAULT 0,
    parent_id INTEGER NOT NULL DEFAULT 0,
    task_type TEXT NOT NULL DEFAULT 'manual',
    metadata TEXT NOT NULL DEFAULT '{}',
    original_task_id INTEGER NOT NULL DEFAULT 0,
    archived_at TEXT NOT NULL,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
)"""
```

加入 `ALL_TABLES`，新增索引：
```python
"CREATE INDEX IF NOT EXISTS idx_tasks_archive_project ON tasks_archive(project_dir)",
"CREATE INDEX IF NOT EXISTS idx_tasks_archive_feature ON tasks_archive(feature_id)",
```

### 1.2 schema 迁移 v9

```python
if ver < 9:
    conn.execute(TASKS_ARCHIVE_TABLE)
```

不需要改现有表结构，`issues.feature_id` 和 `tasks.feature_id` 已存在。

---

## 2. 仓库层

### 2.1 task_repo.py 新增方法

```python
def archive_by_feature(self, feature_id: str) -> dict:
    """将指定 feature_id 的所有任务移入 tasks_archive"""
    now = self._now()
    rows = self.conn.execute(
        "SELECT * FROM tasks WHERE project_dir=? AND feature_id=?",
        (self.project_dir, feature_id)
    ).fetchall()
    count = 0
    for r in rows:
        self.conn.execute(
            """INSERT INTO tasks_archive
               (project_dir, feature_id, title, status, sort_order, parent_id,
                task_type, metadata, original_task_id, archived_at, created_at, updated_at)
               VALUES (?,?,?,?,?,?,?,?,?,?,?,?)""",
            (r["project_dir"], r["feature_id"], r["title"], r["status"],
             r["sort_order"], r["parent_id"], r["task_type"], r["metadata"],
             r["id"], now, r["created_at"], r["updated_at"])
        )
        count += 1
    self.conn.execute(
        "DELETE FROM tasks WHERE project_dir=? AND feature_id=?",
        (self.project_dir, feature_id)
    )
    self.conn.commit()
    return {"archived": count, "feature_id": feature_id}

def list_archived(self, feature_id: str | None = None) -> list[dict]:
    """查询归档任务"""
    sql, params = "SELECT * FROM tasks_archive WHERE project_dir=?", [self.project_dir]
    if feature_id:
        sql += " AND feature_id=?"
        params.append(feature_id)
    sql += " ORDER BY feature_id, sort_order, id"
    rows = [dict(r) for r in self.conn.execute(sql, params).fetchall()]
    # 重建树形结构（用 original_task_id 映射 parent_id）
    id_map = {r["original_task_id"]: r for r in rows}
    top_level = [r for r in rows if r["parent_id"] == 0]
    for node in top_level:
        node["children"] = [r for r in rows if r["parent_id"] == node["original_task_id"]]
    return top_level

def get_feature_status(self, feature_id: str) -> str:
    """计算功能组汇总状态"""
    rows = self.conn.execute(
        "SELECT status FROM tasks WHERE project_dir=? AND feature_id=? AND parent_id!=0",
        (self.project_dir, feature_id)
    ).fetchall()
    if not rows:
        # 没有子任务，查顶层任务
        rows = self.conn.execute(
            "SELECT status FROM tasks WHERE project_dir=? AND feature_id=?",
            (self.project_dir, feature_id)
        ).fetchall()
    if not rows:
        return "pending"
    statuses = {r["status"] for r in rows}
    if statuses == {"completed"}:
        return "completed"
    if statuses == {"pending"}:
        return "pending"
    return "in_progress"
```

### 2.2 issue_repo.py 新增方法

```python
def list_by_feature_id(self, feature_id: str) -> list[dict]:
    """查询指定 feature_id 的所有活跃问题"""
    rows = self.conn.execute(
        "SELECT * FROM issues WHERE project_dir=? AND feature_id=?",
        (self.project_dir, feature_id)
    ).fetchall()
    return [dict(r) for r in rows]

def count_active_by_feature(self, feature_id: str) -> int:
    """统计指定 feature_id 的活跃问题数量"""
    row = self.conn.execute(
        "SELECT COUNT(*) as c FROM issues WHERE project_dir=? AND feature_id=?",
        (self.project_dir, feature_id)
    ).fetchone()
    return row["c"]
```

---

## 3. 工具层

### 3.1 task.py 改动

**新增 `archive` action：**

```python
elif action == "archive":
    feature_id = args.get("feature_id", "").strip()
    if not feature_id:
        raise ValueError("feature_id is required for archive")
    result = repo.archive_by_feature(feature_id)
    return json.dumps(success_response(**result))
```

**`update` action 增加联动逻辑：**

在 `task update` 成功后，检查该任务的 `feature_id`，计算汇总状态，同步到关联问题。

```python
# update action 末尾追加：
feature_id = result.get("feature_id", "")
if feature_id:
    new_status = repo.get_feature_status(feature_id)
    issue_repo = IssueRepo(cm.conn, cm.project_dir)
    issues = issue_repo.list_by_feature_id(feature_id)
    for issue in issues:
        if issue["status"] != new_status:
            issue_repo.update(issue["id"], status=new_status)
```

### 3.2 track.py 改动

**`archive` action 增加联动逻辑：**

在 `track archive` 成功后，检查该问题的 `feature_id`，如果是最后一个活跃问题，归档关联任务。

```python
# archive action 末尾追加（在 repo.archive 之后）：
feature_id = row.get("feature_id", "")
if feature_id:
    remaining = repo.count_active_by_feature(feature_id)
    if remaining == 0:
        task_repo = TaskRepo(cm.conn, cm.project_dir)
        task_repo.archive_by_feature(feature_id)
```

注意：`repo.archive` 已经把当前问题从 issues 表删除了，所以 `count_active_by_feature` 查到的是剩余的活跃问题。

---

## 4. 看板 API 层

### 4.1 get_issues 返回任务进度

`api.py` 的 `get_issues` 函数，对每个有 `feature_id` 的问题，查询关联任务进度：

```python
# 在返回 issues 列表前，补充任务进度
task_repo = TaskRepo(cm.conn, pdir)
for issue in issues:
    fid = issue.get("feature_id", "")
    if fid:
        all_tasks = task_repo.list_by_feature(feature_id=fid)
        total, done = 0, 0
        for t in all_tasks:
            kids = t.get("children", [])
            if kids:
                total += len(kids)
                done += sum(1 for k in kids if k["status"] == "completed")
            else:
                total += 1
                if t["status"] == "completed":
                    done += 1
        issue["task_progress"] = {"total": total, "done": done}
```

### 4.2 任务归档 API

新增 API 端点：

- `GET /tasks/archived` → 返回归档任务列表
- `GET /tasks/archived?feature_id=xxx` → 按功能组筛选

```python
def get_archived_tasks(cm, params, pdir):
    repo = TaskRepo(cm.conn, pdir)
    feature_id = params.get("feature_id", [None])[0]
    tasks = repo.list_archived(feature_id=feature_id)
    return {"tasks": tasks}
```

### 4.3 路由注册

`handle_api_request` 中新增路由：
- `GET /api/tasks/archived` → `get_archived_tasks`

---

## 5. 前端层

### 5.1 问题跟踪卡片显示任务进度

`renderIssueCard` 函数中，如果 `issue.task_progress` 存在，显示进度：

```javascript
// 在卡片标题旁
if (i.task_progress) {
    const { done, total } = i.task_progress;
    html += `<span class="issue-task-progress">${done}/${total}</span>`;
}
```

### 5.2 任务页面归档筛选

状态筛选下拉框新增「已归档」选项。选中时：
- 调用 `GET /tasks/archived` 获取归档任务
- 渲染为只读卡片（不显示操作按钮）

---

## 6. MCP 工具定义更新

`tools/__init__.py` 中 task 工具的 `inputSchema` 需要更新：
- `action` 枚举新增 `"archive"`
- `archive` action 需要 `feature_id` 参数

---

## 7. 数据流总结

| 触发动作 | 联动逻辑 | 涉及表 |
|---------|---------|--------|
| `task update` | 计算 feature 汇总状态 → 同步 issues.status | tasks → issues |
| `track archive` | 检查剩余活跃问题 → 0 则归档任务 | issues → tasks → tasks_archive |
| `task archive` | 直接归档，不影响 issues | tasks → tasks_archive |
| `get_issues` API | 查询关联任务进度 | issues ← tasks |

## 8. 不改动的部分

- `track create/update` 行为不变
- `task batch_create/list/delete` 行为不变
- 没有 `feature_id` 的问题和任务完全不受影响
- `status` 工具的 `progress` 字段聚合逻辑不变（归档后自然消失）
