# 任务驱动开发模式 - 需求文档

## 背景

当前问题跟踪（track/issues）和任务管理（task/tasks）是两个独立模块，缺乏关联。实际开发中，一个问题往往对应一组任务，问题的状态应该随任务进度自动变化。同时，已完成的功能组任务长期堆积在看板中，需要归档机制。

## 目标

将问题跟踪和任务管理打通成一条完整链路：发现问题 → 创建任务 → 执行任务 → 自动同步状态 → 归档。

---

## 需求 1：问题与任务通过 feature_id 关联

### 现状
- `issues` 表已有 `feature_id` 字段（TEXT，默认空）
- `tasks` 表已有 `feature_id` 字段
- 两者之间没有任何联动逻辑

### 需求
- `track create` 时可选传入 `feature_id`
- `task batch_create` 时传入相同的 `feature_id`，自动建立关联
- 通过 `feature_id` 可以查询某个问题关联的所有任务

### 验收标准
- 问题和任务通过相同 `feature_id` 关联
- API 能返回问题关联的任务进度（完成数/总数）

---

## 需求 2：任务状态变化自动同步问题状态

### 规则
- 功能组内所有任务完成 → 关联问题自动标记为 `completed`
- 功能组内有任务进行中 → 关联问题自动标记为 `in_progress`
- 功能组内所有任务待处理 → 关联问题保持 `pending`

### 触发时机
- `task update` 更新任务状态时，检查该 `feature_id` 下所有任务状态
- 计算汇总状态后，更新关联问题的 `status`

### 验收标准
- 更新任务状态后，关联问题状态自动同步
- 无关联问题时不报错（静默跳过）

---

## 需求 3：任务归档机制

### 现状
- `tasks` 表只有活跃任务，没有归档表
- 已完成的功能组长期堆积在看板中

### 需求
- 新增 `tasks_archive` 表，结构与 `tasks` 表一致，额外加 `archived_at` 字段
- `task` 工具新增 `archive` action：将指定 `feature_id` 的所有任务移入 `tasks_archive`
- `track archive` 归档问题时，如果问题有 `feature_id`，自动归档关联任务

### tasks_archive 表结构
```sql
CREATE TABLE IF NOT EXISTS tasks_archive (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    project_dir TEXT NOT NULL DEFAULT '',
    feature_id TEXT NOT NULL DEFAULT '',
    title TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'pending',
    sort_order INTEGER NOT NULL DEFAULT 0,
    parent_id INTEGER NOT NULL DEFAULT 0,
    task_type TEXT NOT NULL DEFAULT 'manual',
    metadata TEXT NOT NULL DEFAULT '{}',
    original_task_id INTEGER NOT NULL DEFAULT 0,
    archived_at TEXT NOT NULL,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
)
```

### 验收标准
- `task archive` 能将功能组所有任务移入归档表
- `track archive` 自动联动归档关联任务
- 归档后 `tasks` 表中不再有该功能组的记录

---

## 需求 4：看板展示优化

### 4.1 问题跟踪卡片显示关联任务进度

- 问题卡片如果有 `feature_id`，显示任务进度条（如 `5/10`）
- API `get_issues` 返回每个问题的关联任务进度

### 4.2 任务页面归档筛选

- 任务页面默认只显示活跃任务（当前行为不变）
- 新增「已归档」筛选选项，可查看归档任务
- 归档任务只读，不可编辑

### 验收标准
- 有关联任务的问题卡片显示进度
- 任务页面可切换查看活跃/归档任务

---

## 需求 5：工作流串联

### 完整流程
1. `track create`（可选 `feature_id`）→ 记录问题
2. `task batch_create`（同 `feature_id`）→ 创建任务
3. `task update` → 更新任务状态 → 自动同步问题状态
4. 所有任务完成 → 问题自动标记 `completed`
5. `track archive` → 归档问题 + 自动归档关联任务

### 验收标准
- 上述流程端到端可用
- 每一步的状态同步正确

---

## 涉及模块

| 模块 | 文件 | 改动 |
|------|------|------|
| 数据库 | `schema.py` | 新增 `tasks_archive` 表 + 迁移 |
| 任务仓库 | `task_repo.py` | 新增 `archive_by_feature`、`list_archived` 方法 |
| 问题仓库 | `issue_repo.py` | 新增按 `feature_id` 查询方法 |
| 任务工具 | `task.py` | 新增 `archive` action，`update` 时联动问题状态 |
| 问题工具 | `track.py` | `archive` 时联动任务归档 |
| 看板 API | `api.py` | 任务归档接口、问题关联进度接口 |
| 前端 | `app.js` | 问题卡片进度、任务归档筛选 |

## 需求 6：边界场景与规则

### 6.1 启动时机

- `feature_id` 是否存在即为开关：有 `feature_id` = 任务驱动模式，没有 = 传统独立问题追踪
- 单点修复（改样式、修逻辑）→ `track create` 不带 `feature_id`，独立流程
- 多步骤改动（新功能、重构、升级）→ 走 spec，`track create` 带 `feature_id`
- 中途升级：独立问题后来需要拆任务，通过 `track update` 补上 `feature_id` 即可进入任务驱动模式

### 6.2 一个 feature_id 关联多个问题

- 同一个 `feature_id` 下可以有多个问题（主需求 + 过程中发现的子问题）
- `task update` 同步状态时，同步该 `feature_id` 下所有活跃问题

### 6.3 任务或问题不存在时

- `task update` 时查不到关联问题 → 静默跳过，不报错
- 问题有 `feature_id` 但还没创建任务 → 不影响问题正常流程

### 6.4 部分归档规则

- `track archive` 归档某个问题时，检查该 `feature_id` 下是否还有其他活跃问题
- 还有活跃问题 → 不归档任务
- 这是最后一个活跃问题 → 联动归档关联任务

### 6.5 手动任务归档

- `task archive` 直接归档任务，不影响关联问题状态
- 这是用户主动行为，问题状态由用户自己管理

### 6.6 向后兼容

- 没有 `feature_id` 的问题走原来的独立流程，零影响
- 现有的 `track create/update/archive` 行为不变，只在有 `feature_id` 时增加联动
- steering 规则中的问题追踪流程不需要修改

---

## 不做的事

- 不做任务和问题的双向编辑（任务页面不能编辑问题，问题页面不能编辑任务）
- 不做复杂的依赖关系（任务之间无依赖）
- 不考虑历史数据兼容（程序未上线）
