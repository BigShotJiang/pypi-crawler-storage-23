# 任务清单：碎片自动归纳 + 统一任务调度

## 需求一：任务树形结构（基础设施）

### 1.1 数据库迁移 v6
- [x] schema.py TASKS_TABLE 建表语句新增 parent_id/task_type/metadata 三个字段
- [x] schema.py CURRENT_SCHEMA_VERSION 改为 6
- [x] schema.py init_db 新增 `if ver < 6` 迁移分支（ALTER TABLE 加三个字段）
- [x] 运行 pytest tests/test_schema_v4.py 验证迁移逻辑

### 1.2 task_repo.py 树形支持
- [x] batch_create 去重条件加 parent_id（四字段去重）
- [x] batch_create 支持 task_type 参数（默认 manual）
- [x] batch_create 支持 metadata 参数（默认 {}）
- [x] batch_create 处理 children 字段（插入父任务后用 lastrowid 作为子任务的 parent_id）
- [x] batch_create INSERT 语句加 parent_id/task_type/metadata 字段
- [x] list_by_feature 查出扁平记录后按 parent_id 分组组装树形
- [x] list_by_feature 新增 _compute_status 方法动态计算节点状态
- [x] list_by_feature 有 status 过滤时，查询不过滤节点（parent_id=0），只过滤子任务，确保节点始终包含
- [x] list_by_feature 节点状态由过滤后的子任务列表重新计算
- [x] 新增 complete_by_feature 方法（批量将指定 feature_id 的任务标记为 completed）
- [x] 运行 pytest tests/test_task_repo.py 验证

### 1.3 task.py 工具层
- [x] batch_create 透传 task_type 参数给 repo
- [x] batch_create 的 tasks 数组直接透传（含 children）给 repo
- [x] 运行 pytest tests/test_task_tool.py 验证

### 1.4 tools/__init__.py inputSchema
- [x] task 工具 tasks 数组 items 新增 children 字段定义
- [x] 运行 pytest tests/test_tools_integration.py 验证

### 1.5 Web 看板 — 后端
- [x] api.py get_tasks 直接返回 repo.list_by_feature 的树形结果
- [x] api.py post_tasks 透传 children 给 repo

### 1.6 Web 看板 — 前端 i18n
- [x] i18n.js zh-CN 新增翻译键（sysDigest/issuePrefix/taskProgress/systemTask/manualTask/collapse/expand）
- [x] i18n.js zh-TW 新增对应翻译键
- [x] i18n.js en 新增对应翻译键
- [x] i18n.js es 新增对应翻译键
- [x] i18n.js de 新增对应翻译键
- [x] i18n.js fr 新增对应翻译键
- [x] i18n.js ja 新增对应翻译键

### 1.7 Web 看板 — 前端渲染
- [x] app.js 新增 formatFeatureId 函数（_sys/ → 系统名称，issue/ → 问题 #N）
- [x] app.js loadTasks 改为两级渲染（节点 + 子任务）
- [x] app.js renderTaskCard 区分节点卡片（显示进度、不可切换状态）和子任务卡片
- [x] app.js 节点折叠/展开交互逻辑
- [x] style.css 子任务缩进样式（.task-children padding-left）
- [x] style.css 节点折叠/展开样式
- [x] Playwright 验证看板树形渲染

---

## 需求二：问题追踪任务化（依赖需求一）

### 2.1 track.py 改造
- [x] track.py 顶部新增 ISSUE_STEPS 常量列表（5个步骤标题）
- [x] track.py 顶部 import TaskRepo
- [x] track.py create 分支末尾：用 issue_number 构造 feature_id，调用 task_repo.batch_create 创建 5 步任务（task_type="system"）
- [x] track.py create 分支末尾：更新 issue 的 feature_id 字段
- [x] track.py archive 分支：归档操作之前先获取 issue 的 feature_id（归档后 get_by_id 查不到），再调用 task_repo.complete_by_feature 批量完成
- [x] 运行 pytest tests/test_track_v4.py 验证

### 2.2 集成验证
- [x] 手动调用 track create 验证自动创建 5 步任务
- [x] 手动调用 track archive 验证批量完成关联任务
- [x] 看板验证 issue/ 前缀的任务显示为"问题 #N"

---

## 需求三：碎片自动归纳（依赖需求一）

### 3.1 memory_repo 扩展
- [x] memory_repo.py 新增 count_by_source 方法（统计指定 source 的记忆数量）

### 3.2 auto_save.py 改造
- [x] auto_save.py 顶部新增 DIGEST_TASK_TITLE 常量和 DEFAULT_DIGEST_THRESHOLD
- [x] auto_save.py 顶部 import TaskRepo 和 os
- [x] handle_auto_save 末尾：读取阈值环境变量，统计碎片数，超阈值时去重检查后创建归纳任务
- [x] 运行 pytest 验证碎片检测逻辑（超阈值创建、去重不重复创建）

---

## 需求四：统一任务调度（依赖需求二、三）

### 4.1 steering 模板更新
- [x] install.py STEERING_CONTENT 启动检查流程新增步骤 4（检查系统任务）和步骤 5（检查未完成问题修复任务）
- [x] install.py STEERING_CONTENT 工具速查表 task 行的关键参数加 children
- [x] 运行 pytest tests/test_install.py 验证

### 4.2 集成验证
- [x] 验证新会话启动流程：status → recall → task list _sys/* → task list issue/*

---

## 需求五：收尾

### 5.1 清理测试数据
- [x] 清理 feature_id="test/demo" 和 "test/tree-demo" 的测试任务数据

### 5.2 全量测试
- [x] 运行 pytest 全量测试（跳过 test_install.py 网络超时）
- [x] 看板 Playwright 全流程验证
