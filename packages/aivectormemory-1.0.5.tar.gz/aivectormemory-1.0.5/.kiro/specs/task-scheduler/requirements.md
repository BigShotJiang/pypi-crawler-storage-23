# 需求文档：碎片自动归纳 + 统一任务调度

## 背景

auto_save 每次会话结束时自动保存 decision/modification/pitfall/todo/preference 五类碎片记忆，累积到 800+ 条后永远停留在原始状态，不会自动升级为有价值的「项目知识」。

track 的问题修复流程（排查→出方案→改代码→自测）跨多步骤，会话中断后无法从断点继续，导致重复劳动。

## 核心目标

1. 碎片记忆自动升级为项目知识（不是简单减少条数，而是提炼价值）
2. 跨会话任务可从断点恢复（不依赖上下文转移的记忆）

## 术语

- **碎片记忆**：auto_save 产生的 source=auto_save 记忆，标签为 decision/modification/pitfall/todo/preference
- **项目知识**：经过归纳提炼的高价值记忆，标签为「项目知识」，source=manual
- **系统任务**：由系统自动创建的任务（如碎片归纳），区别于用户手动创建的开发任务
- **feature_id**：任务的分组标识，系统任务使用固定前缀 `_sys/` 区分

## 实现顺序

按依赖关系排序：需求一（树形结构）是需求二、三的基础设施，需求四依赖前三个都完成，需求五最后收尾。

---

## 需求一：任务树形结构（基础设施）

### 现状问题

tasks 表是扁平结构，所有任务同级，只能通过 feature_id 分组、sort_order 排序。无法表达「节点 → 子任务」的层级关系。

实际场景中，一个功能开发或问题修复往往有多个阶段（节点），每个阶段下有具体的执行步骤（子任务）。扁平结构只能靠 title 前缀或 sort_order 编码来模拟层级，不够精确，看板也无法正确渲染树形视图。

### 方案

tasks 表新增 `parent_id` 字段：

- `parent_id` INTEGER DEFAULT 0：父任务 ID，0 表示顶级任务（节点）
- 子任务的 parent_id 指向所属节点的 task id
- 最多支持两级（节点 → 子任务），不支持更深嵌套

### 数据结构示例

```
feature_id = "issue/503"

id=1  parent_id=0  title="排查问题"        ← 节点
id=2  parent_id=1  title="查看日志"        ← 子任务
id=3  parent_id=1  title="定位代码"        ← 子任务
id=4  parent_id=1  title="记录根因"        ← 子任务
id=5  parent_id=0  title="修复代码"        ← 节点
id=6  parent_id=5  title="修改文件"        ← 子任务
id=7  parent_id=5  title="运行测试"        ← 子任务
id=8  parent_id=5  title="提交代码"        ← 子任务
```

### batch_create 去重逻辑调整

现有去重逻辑按 `project_dir + feature_id + title` 判断，树形结构下不同节点的子任务可能有相同标题（如两个节点都有"运行测试"），会导致误判。去重条件需加上 `parent_id`：

```sql
SELECT id FROM tasks WHERE project_dir=? AND feature_id=? AND title=? AND parent_id=?
```

### batch_create 接口变更

tasks 数组中的每个任务新增可选字段 `children`：

```json
{
  "action": "batch_create",
  "feature_id": "issue/503",
  "tasks": [
    {
      "title": "排查问题",
      "sort_order": 1,
      "children": [
        { "title": "查看日志", "sort_order": 1 },
        { "title": "定位代码", "sort_order": 2 },
        { "title": "记录根因", "sort_order": 3 }
      ]
    },
    {
      "title": "修复代码",
      "sort_order": 2,
      "children": [
        { "title": "修改文件", "sort_order": 1 },
        { "title": "运行测试", "sort_order": 2 },
        { "title": "提交代码", "sort_order": 3 }
      ]
    }
  ]
}
```

### list 接口变更

返回结果按树形组织，节点下嵌套 children 数组：

```json
{
  "tasks": [
    {
      "id": 1, "title": "排查问题", "status": "completed", "parent_id": 0,
      "children": [
        { "id": 2, "title": "查看日志", "status": "completed", "parent_id": 1 },
        { "id": 3, "title": "定位代码", "status": "completed", "parent_id": 1 },
        { "id": 4, "title": "记录根因", "status": "completed", "parent_id": 1 }
      ]
    },
    {
      "id": 5, "title": "修复代码", "status": "in_progress", "parent_id": 0,
      "children": [
        { "id": 6, "title": "修改文件", "status": "in_progress", "parent_id": 5 },
        { "id": 7, "title": "运行测试", "status": "pending", "parent_id": 5 },
        { "id": 8, "title": "提交代码", "status": "pending", "parent_id": 5 }
      ]
    }
  ]
}
```

### 节点状态自动计算

节点本身不需要手动更新状态，由子任务状态自动推导：
- 所有子任务 pending → 节点 pending
- 任一子任务 in_progress → 节点 in_progress
- 所有子任务 completed → 节点 completed

### 节点状态计算位置

在 task_repo 的 list 查询时动态计算，不存数据库。list_by_feature 查出所有记录后，按 parent_id 分组，遍历每个节点的子任务列表推导节点状态。这样避免 update 子任务时还要联动更新父节点。

### MCP 工具定义变更（tools/__init__.py）

task 工具的 inputSchema 需要：
- batch_create 的 tasks 数组中每个元素新增可选字段 `children`（数组）
- list 返回结果中每个节点新增 `children` 数组
- update 不变（只操作单条记录，不支持更新 parent_id，子任务创建后不允许移动到其他节点）

### Web 看板变更

后端 `api.py`：
- `get_tasks`：调用 task_repo.list_by_feature 后组装树形结构返回
- `post_tasks`：透传 children 给 task_repo.batch_create

前端 `app.js`：
- `loadTasks`：渲染逻辑改为两级结构，节点显示为可折叠分组头（含进度如 2/3），子任务缩进展示
- `renderTaskCard`：区分节点卡片（不可直接切换状态，显示子任务进度）和子任务卡片（可切换状态）
- `feature_id` 显示优化：`_sys/` 和 `issue/` 前缀的 feature_id 需映射为可读名称（如 `_sys/digest` → "系统：碎片归纳"，`issue/503` → "问题 #503"），映射逻辑在 `loadTasks` 渲染时处理

前端 `style.css`：
- 子任务缩进样式（padding-left）
- 节点折叠/展开交互样式

前端 `i18n.js`：
- 新增翻译键：节点进度格式、系统任务类型标识、feature_id 可读名称前缀（"系统："/"问题 #"）、折叠/展开提示
- 所有 7 种语言同步更新

### 数据库迁移

合并到 v6 迁移中（与 task_type/metadata 字段一起）：
- `ALTER TABLE tasks ADD COLUMN parent_id INTEGER NOT NULL DEFAULT 0`

---

## 需求二：问题追踪任务化（依赖需求一）

### 现状问题

track 记录的是问题本身（是什么、根因、方案），但修复流程的执行步骤（排查→改代码→自测→验证）没有持久化。会话中断后，新会话只能看到 track 的字段填充情况来推断进度，不够精确。

### 方案

track create 创建问题时，自动创建关联的修复任务步骤：

```
feature_id = "issue/{issue_number}"
tasks = [
  { title: "排查问题原因", sort_order: 1 },
  { title: "确定解决方案", sort_order: 2 },
  { title: "修改代码", sort_order: 3 },
  { title: "自测验证", sort_order: 4 },
  { title: "等待用户验证", sort_order: 5 }
]
```

### 执行规则

- track create 时自动调用 task batch_create 创建步骤
- 每完成一步，track update 填充对应字段的同时，task update 更新步骤状态
- 会话中断恢复时，通过 `task list`（feature_id="issue/{issue_number}"）查看哪些步骤已完成，从未完成的步骤继续
- track archive 时，关联的 task 全部标记为 completed

### 不改变现有 track 字段

问题追踪的字段（description/investigation/root_cause/solution/files_changed/test_result）保持不变，task 只是补充执行步骤的状态追踪。

### 多语言处理

track create 自动创建的5个步骤标题不能硬编码中文。步骤标题定义为常量列表，通过用户的 steering 语言环境或系统语言决定使用哪种语言。默认中文，但标题常量需支持多语言扩展：

```python
ISSUE_STEPS = [
    "排查问题原因",
    "确定解决方案",
    "修改代码",
    "自测验证",
    "等待用户验证",
]
```

后续如需国际化，将常量改为字典映射即可，当前阶段先用中文。

### 实现细节

- track create 时在 track.py 内部直接调用 task_repo.batch_create 创建关联任务，不通过 MCP 工具层调用
- track archive 时在 track.py 内部调用 task_repo 将 feature_id="issue/{issue_number}" 的所有 task 标记为 completed

---

## 需求三：碎片自动归纳（依赖需求一）

### 触发条件

auto_save 执行完毕后，统计当前项目的碎片记忆总数（source=auto_save）。超过阈值（默认 50 条）时，自动创建一个归纳系统任务。

阈值可通过环境变量 `AVM_DIGEST_THRESHOLD` 配置，默认 50。

### 归纳任务创建规则

- feature_id 固定为 `_sys/digest`
- 同一时间只允许存在一个 pending 状态的归纳任务（避免重复创建）
- 去重检查在 auto_save.py 中执行：创建前先查 task_repo.list_by_feature(feature_id="_sys/digest", status="pending")，有结果则跳过
- 任务标题包含碎片数量，如「归纳 127 条碎片记忆」

### 多语言处理

归纳任务标题同样不能硬编码中文。标题模板定义为常量，当前阶段先用中文：

```python
DIGEST_TASK_TITLE = "归纳 {count} 条碎片记忆"
```

### 归纳执行时机

新会话启动时，在加载项目知识和用户偏好之后，检查是否有 pending 的系统任务（feature_id 以 `_sys/` 开头）。有则提示用户并在用户确认后执行。

**不在 agentStop 中执行归纳**，原因：
- agentStop 上下文是会话结束场景，执行归纳耗时且无用户反馈
- 归纳过程需要调用 remember/forget，在 agentStop 中执行会触发链式 hook
- 新会话启动时执行，用户可以看到归纳过程和结果

### 归纳执行流程

1. 调用 `task update` 将归纳任务状态改为 in_progress
2. 调用 `digest`（tags 按类别分批，compress=true）获取碎片列表
3. 按主题分组归纳，生成精炼的项目知识条目
4. 先调用 `remember` 写入归纳后的项目知识（标签：项目知识 + 原始类别标签）
5. 确认写入成功后，调用 `forget` 删除已归纳的碎片
6. 调用 `task update` 将归纳任务状态改为 completed

### 数据安全

- 先写后删：必须先 remember 成功，再 forget 删除碎片
- 分批处理：每批不超过 20 条碎片，避免单次操作过大
- preference 类碎片归纳后 scope 保持 user（跨项目通用）

---

## 需求四：统一任务调度（依赖需求二、三）

### 新会话启动流程（修改后）

```
1. 调用 status 检查阻塞状态
2. 加载项目知识（recall tags=项目知识）
3. 加载用户偏好（recall tags=preference）
4. 检查系统任务（task list feature_id 以 _sys/ 开头，status=pending）
   - 有系统任务 → 提示用户，确认后执行
   - 无系统任务 → 继续正常流程
5. 检查未完成的问题修复任务（task list feature_id 以 issue/ 开头，status!=completed）
   - 有未完成任务 → 提示用户上次中断的问题和进度
```

### task 表扩展

现有 tasks 表字段：id, project_dir, feature_id, title, status, sort_order, created_at, updated_at

新增字段：
- `task_type` TEXT DEFAULT 'manual'：任务类型，manual=手动创建，system=系统创建
- `metadata` TEXT DEFAULT '{}'：扩展数据，JSON 格式（如归纳任务存碎片数量、问题任务存 issue_id）

### feature_id 命名规范

| 前缀 | 用途 | 示例 |
|------|------|------|
| `_sys/digest` | 碎片归纳 | `_sys/digest` |
| `issue/{number}` | 问题修复步骤 | `issue/503` |
| 其他 | 用户自定义功能 | `login-page` |

---

## 需求五：steering 模板更新（收尾）

install.py 中的 STEERING_CONTENT 需要同步更新启动检查流程，增加系统任务检查步骤。

所有 IDE 的 steering 模板统一更新（通过 install.py 的 STEERING_CONTENT 变量控制）。

---

## 跨 IDE 兼容性

所有改动都在 MCP 工具层面（Python 代码），对所有 IDE 通用：
- schema.py：数据库迁移 v6（parent_id/task_type/metadata）
- task_repo.py：batch_create 支持 children、list 返回树形、节点状态动态计算
- task.py：MCP 工具层透传 children
- tools/__init__.py：task 工具 inputSchema 加 children/parent_id 参数
- track.py：create 时自动创建关联任务、archive 时批量完成关联任务
- auto_save.py：检测碎片阈值创建归纳系统任务
- web/api.py：get_tasks 返回树形、post_tasks 支持 children
- web/static/app.js：loadTasks/renderTaskCard 支持两级渲染、feature_id 可读名称映射
- web/static/style.css：子任务缩进样式
- web/static/i18n.js：新增树形任务、系统任务相关翻译键（7种语言）
- install.py：steering 模板更新启动流程

steering 模板的启动流程更新通过 install.py 统一管理，用户重新运行 install 即可同步到各 IDE。

---

## 不做的事

- 不在 agentStop hook 中执行归纳
- 不新增 MCP 工具（复用现有 task/digest/remember/forget）
- 不改变 track 的字段结构
- 不新增数据库表（只扩展 tasks 表字段）
