# 设计文档：碎片自动归纳 + 统一任务调度

## 架构概览

```
MCP 工具层（tools/）
  ├── task.py        ← 透传 children 给 task_repo
  ├── track.py       ← create 时调 task_repo 创建关联任务
  ├── auto_save.py   ← 保存后检测碎片阈值创建归纳任务
  └── __init__.py    ← inputSchema 更新

数据层（db/）
  ├── schema.py      ← v6 迁移（parent_id/task_type/metadata）
  └── task_repo.py   ← 树形 CRUD

Web 看板（web/）
  ├── api.py         ← 树形接口
  ├── app.js         ← 两级渲染
  ├── style.css      ← 子任务缩进
  └── i18n.js        ← 新增翻译键

配置层
  └── install.py     ← steering 模板更新
```

---

## 一、数据库迁移 v6（schema.py）

在 `init_db` 中新增 `if ver < 6` 分支：

```python
if ver < 6:
    task_cols = {row[1] for row in conn.execute("PRAGMA table_info(tasks)").fetchall()}
    for col, typ, default in [
        ("parent_id", "INTEGER", "0"),
        ("task_type", "TEXT", "'manual'"),
        ("metadata", "TEXT", "'{}'"),
    ]:
        if col not in task_cols:
            conn.execute(f"ALTER TABLE tasks ADD COLUMN {col} {typ} NOT NULL DEFAULT {default}")
```

`CURRENT_SCHEMA_VERSION` 改为 6。

`TASKS_TABLE` 建表语句同步加上三个新字段（新库直接建完整表）。

---

## 二、task_repo.py 改造

### batch_create 支持 children

```python
def batch_create(self, feature_id: str, tasks: list[dict], task_type: str = "manual") -> dict:
    created, skipped = 0, 0
    now = self._now()
    for t in tasks:
        title = t.get("title", "").strip()
        if not title:
            skipped += 1
            continue
        parent_id = t.get("parent_id", 0)
        # 去重：project_dir + feature_id + title + parent_id
        existing = self.conn.execute(
            "SELECT id FROM tasks WHERE project_dir=? AND feature_id=? AND title=? AND parent_id=?",
            (self.project_dir, feature_id, title, parent_id)
        ).fetchone()
        if existing:
            skipped += 1
            continue
        cur = self.conn.execute(
            "INSERT INTO tasks (project_dir,feature_id,title,status,sort_order,parent_id,task_type,metadata,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?,?)",
            (self.project_dir, feature_id, title, "pending", t.get("sort_order",0), parent_id, task_type, t.get("metadata","{}"), now, now)
        )
        node_id = cur.lastrowid
        created += 1
        # 处理 children
        for child in t.get("children", []):
            child_title = child.get("title", "").strip()
            if not child_title:
                skipped += 1
                continue
            child_existing = self.conn.execute(
                "SELECT id FROM tasks WHERE project_dir=? AND feature_id=? AND title=? AND parent_id=?",
                (self.project_dir, feature_id, child_title, node_id)
            ).fetchone()
            if child_existing:
                skipped += 1
                continue
            self.conn.execute(
                "INSERT INTO tasks (...) VALUES (...)",
                (..., node_id, task_type, child.get("metadata","{}"), now, now)
            )
            created += 1
    self.conn.commit()
    return {"created": created, "skipped": skipped, "feature_id": feature_id}
```

### list_by_feature 返回树形

```python
def list_by_feature(self, feature_id=None, status=None) -> list[dict]:
    # 查出所有记录（扁平）
    rows = self._query(feature_id, status)
    # 按 parent_id 分组
    top_level = [r for r in rows if r["parent_id"] == 0]
    children_map = {}
    for r in rows:
        if r["parent_id"] != 0:
            children_map.setdefault(r["parent_id"], []).append(r)
    # 组装树形 + 动态计算节点状态
    for node in top_level:
        kids = children_map.get(node["id"], [])
        node["children"] = kids
        if kids:
            node["status"] = self._compute_status(kids)
    return top_level
```

### 节点状态计算

```python
def _compute_status(self, children: list[dict]) -> str:
    statuses = {c["status"] for c in children}
    if statuses == {"completed"}:
        return "completed"
    if statuses == {"pending"}:
        return "pending"
    return "in_progress"
```

### 批量完成（供 track archive 调用）

```python
def complete_by_feature(self, feature_id: str):
    now = self._now()
    self.conn.execute(
        "UPDATE tasks SET status='completed', updated_at=? WHERE project_dir=? AND feature_id=? AND status!='completed'",
        (now, self.project_dir, feature_id)
    )
    self.conn.commit()
```

---

## 三、task.py 工具层

透传 `children` 和 `task_type`：

```python
if action == "batch_create":
    # tasks 数组直接透传给 repo，children 在 repo 层处理
    result = repo.batch_create(feature_id, tasks, task_type=args.get("task_type", "manual"))
```

---

## 四、tools/__init__.py inputSchema 更新

task 工具的 tasks 数组 items 新增：

```python
"children": {
    "type": "array",
    "items": {
        "type": "object",
        "properties": {
            "title": {"type": "string"},
            "sort_order": {"type": "integer", "default": 0}
        },
        "required": ["title"]
    },
    "description": "子任务列表（可选，最多一级嵌套）"
}
```

---

## 五、track.py 改造

### create 时自动创建关联任务

```python
ISSUE_STEPS = [
    "排查问题原因",
    "确定解决方案",
    "修改代码",
    "自测验证",
    "等待用户验证",
]

def handle_track(args, *, cm, **_):
    # ... 现有 create 逻辑 ...
    if action == "create":
        # 创建问题后，自动创建关联任务
        issue_number = result["issue_number"]
        feature_id = f"issue/{issue_number}"
        task_repo = TaskRepo(cm.conn, cm.project_dir)
        steps = [{"title": t, "sort_order": i+1} for i, t in enumerate(ISSUE_STEPS)]
        task_repo.batch_create(feature_id, steps, task_type="system")
        # 同时更新 issue 的 feature_id
        repo.update(result["id"], feature_id=feature_id)
```

### archive 时批量完成关联任务

```python
    elif action == "archive":
        # 现有归档逻辑...
        # 批量完成关联任务
        issue = repo.get_by_id(issue_id)
        if issue and issue.get("feature_id"):
            task_repo = TaskRepo(cm.conn, cm.project_dir)
            task_repo.complete_by_feature(issue["feature_id"])
```

---

## 六、auto_save.py 改造

在 `handle_auto_save` 末尾新增碎片检测逻辑：

```python
DIGEST_TASK_TITLE = "归纳 {count} 条碎片记忆"
DEFAULT_DIGEST_THRESHOLD = 50

def handle_auto_save(args, *, cm, engine, session_id, **_):
    # ... 现有保存逻辑 ...

    # 检测碎片阈值
    threshold = int(os.environ.get("AVM_DIGEST_THRESHOLD", DEFAULT_DIGEST_THRESHOLD))
    count = repo.count_by_source("auto_save")  # 需要在 memory_repo 新增此方法
    if count >= threshold:
        task_repo = TaskRepo(cm.conn, cm.project_dir)
        # 去重：检查是否已有 pending 的归纳任务
        existing = task_repo.list_by_feature(feature_id="_sys/digest", status="pending")
        if not existing:
            title = DIGEST_TASK_TITLE.format(count=count)
            task_repo.batch_create("_sys/digest", [{"title": title, "sort_order": 0}], task_type="system")
```

### memory_repo 新增 count_by_source

```python
def count_by_source(self, source: str) -> int:
    row = self.conn.execute(
        "SELECT COUNT(*) as cnt FROM memories WHERE project_dir=? AND source=?",
        (self.project_dir, source)
    ).fetchone()
    return row["cnt"] if row else 0
```

---

## 七、Web 看板改造

### api.py

`get_tasks` 直接返回 `repo.list_by_feature()` 的树形结果（repo 层已组装好）。

`post_tasks` 透传 children。

### app.js


`loadTasks` 改造要点：

```javascript
async function loadTasks() {
  // ... 获取数据 ...
  const grouped = {};
  tasks.forEach(t => {
    (grouped[t.feature_id] = grouped[t.feature_id] || []).push(t);
  });

  for (const [fid, items] of Object.entries(grouped)) {
    const displayName = formatFeatureId(fid);  // 可读名称映射
    // 节点有 children → 渲染为可折叠分组
    // 节点无 children → 渲染为普通任务卡片
    for (const node of items) {
      if (node.children && node.children.length) {
        // 渲染节点头（含进度 done/total）
        // 渲染子任务列表（缩进）
      } else {
        // 渲染普通任务卡片
      }
    }
  }
}

function formatFeatureId(fid) {
  if (fid.startsWith('_sys/digest')) return t('sysDigest');
  if (fid.startsWith('issue/')) return t('issuePrefix') + fid.split('/')[1];
  return fid;
}
```

`renderTaskCard` 区分节点和子任务：
- 节点：不可直接切换状态，显示子任务进度（如 2/3）
- 子任务：可切换状态（现有逻辑不变）

### i18n.js

7 种语言各新增以下翻译键：

```javascript
// zh-CN
sysDigest: '系统：碎片归纳',
issuePrefix: '问题 #',
taskProgress: '{done}/{total}',
systemTask: '系统任务',
manualTask: '手动任务',
collapse: '收起',
expand: '展开',

// zh-TW
sysDigest: '系統：碎片歸納',
issuePrefix: '問題 #',
// ...

// en
sysDigest: 'System: Memory Digest',
issuePrefix: 'Issue #',
taskProgress: '{done}/{total}',
systemTask: 'System Task',
manualTask: 'Manual Task',
collapse: 'Collapse',
expand: 'Expand',

// es / de / fr / ja 同理
```

### style.css

```css
.task-children { padding-left: 24px; }
.task-node-header { cursor: pointer; display: flex; align-items: center; gap: 8px; }
.task-node-header .task-node-toggle { transition: transform 0.2s; }
.task-node-header.collapsed .task-node-toggle { transform: rotate(-90deg); }
.task-node-header .task-node-progress { font-size: 12px; color: #888; }
```

---

## 八、install.py steering 模板更新

在 STEERING_CONTENT 的「启动检查」部分，步骤 3 后新增：

```
4. 检查系统任务（task list，feature_id 以 _sys/ 开头，status=pending）
   - 有系统任务 → 提示用户，确认后执行
5. 检查未完成的问题修复任务（task list，feature_id 以 issue/ 开头，status!=completed）
   - 有未完成任务 → 提示用户上次中断的问题和进度
```

---

## 九、测试策略

| 模块 | 测试方式 | 覆盖点 |
|------|----------|--------|
| schema.py v6 迁移 | pytest | 新库建表含新字段、旧库迁移加字段 |
| task_repo 树形 | pytest | batch_create 含 children、list 返回树形、节点状态计算、去重含 parent_id |
| track 关联任务 | pytest | create 自动创建 5 步任务、archive 批量完成 |
| auto_save 碎片检测 | pytest | 超阈值创建归纳任务、去重不重复创建 |
| Web 看板树形渲染 | Playwright | 节点折叠展开、子任务缩进、进度显示 |
| install.py steering | pytest | 模板内容包含系统任务检查步骤 |

---

## 十、数据流图

```
auto_save 执行
  → 保存碎片记忆
  → 统计碎片数 > 阈值？
    → 是：创建 _sys/digest 系统任务（去重）
    → 否：跳过

track create
  → 创建问题记录
  → 自动创建 issue/{number} 关联任务（5步）

新会话启动
  → status 检查阻塞
  → recall 加载项目知识/偏好
  → task list 检查 _sys/* pending 系统任务
    → 有：提示用户 → 确认后执行归纳
  → task list 检查 issue/* 未完成任务
    → 有：提示用户中断的问题和进度
```
