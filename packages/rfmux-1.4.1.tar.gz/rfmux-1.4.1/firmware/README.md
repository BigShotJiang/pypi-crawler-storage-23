Please refer to [CHANGES](CHANGES) and **[docs/guides/firmware.md](../docs/guides/firmware.md)**.
