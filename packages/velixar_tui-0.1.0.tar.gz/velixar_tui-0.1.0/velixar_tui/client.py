"""Velixar API client for TUI."""

import httpx
from typing import Optional, Dict, Any, List, AsyncIterator


API_BASE = "https://api.velixarai.com"


class VelixarClient:
    """Async client for the Velixar public API."""

    def __init__(self, api_key: str, base_url: str = API_BASE):
        self.api_key = api_key
        self.base_url = base_url
        self._headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        }

    async def health(self) -> Dict[str, Any]:
        async with httpx.AsyncClient() as c:
            r = await c.get(f"{self.base_url}/health", headers=self._headers)
            return r.json()

    # ── Memory ──

    async def store_memory(self, content: str, tags: Optional[List[str]] = None, tier: int = 2) -> Dict[str, Any]:
        async with httpx.AsyncClient() as c:
            r = await c.post(f"{self.base_url}/memory", headers=self._headers, json={
                "content": content, "tags": tags or [], "tier": tier,
            })
            return r.json()

    async def search_memories(self, query: str, limit: int = 10) -> Dict[str, Any]:
        async with httpx.AsyncClient() as c:
            r = await c.get(
                f"{self.base_url}/memory/search",
                headers=self._headers,
                params={"q": query, "limit": limit},
            )
            return r.json()

    async def list_memories(self, limit: int = 20, offset: int = 0) -> Dict[str, Any]:
        async with httpx.AsyncClient() as c:
            r = await c.get(
                f"{self.base_url}/memory/list",
                headers=self._headers,
                params={"limit": limit, "offset": offset},
            )
            return r.json()

    async def delete_memory(self, memory_id: str) -> Dict[str, Any]:
        async with httpx.AsyncClient() as c:
            r = await c.delete(f"{self.base_url}/memory/{memory_id}", headers=self._headers)
            return r.json()

    # ── Chat ──

    async def chat(self, message: str, conversation_id: Optional[str] = None) -> Dict[str, Any]:
        """Send a chat message through the frontend API."""
        chat_url = "https://p42munn3lg.execute-api.us-east-1.amazonaws.com/api/chat"
        async with httpx.AsyncClient(timeout=120) as c:
            r = await c.post(chat_url, headers=self._headers, json={
                "message": message,
                "conversation_id": conversation_id or "tui-session",
                "history": [],
            })
            return r.json()

    async def chat_stream(self, message: str, conversation_id: Optional[str] = None) -> AsyncIterator[str]:
        """Stream a chat response via SSE."""
        chat_url = "https://p42munn3lg.execute-api.us-east-1.amazonaws.com/api/chat"
        async with httpx.AsyncClient(timeout=120) as c:
            async with c.stream("POST", chat_url, headers=self._headers, json={
                "message": message,
                "conversation_id": conversation_id or "tui-session",
                "history": [],
                "stream": True,
            }) as r:
                async for line in r.aiter_lines():
                    if line.startswith("data: "):
                        data = line[6:]
                        if data == "[DONE]":
                            break
                        yield data
