"""Velixar TUI — Main application."""

from textual.app import App, ComposeResult
from textual.binding import Binding
from textual.containers import Container, Horizontal, Vertical, VerticalScroll
from textual.css.query import NoMatches
from textual.reactive import reactive
from textual.widgets import (
    Footer, Header, Input, Static, Label, Button,
    DataTable, TabbedContent, TabPane, TextArea,
    LoadingIndicator, RichLog,
)
from textual.screen import ModalScreen

from velixar_tui.client import VelixarClient
from velixar_tui.auth import get_api_key, set_api_key, clear_api_key


# ── Login Screen ──

class LoginScreen(ModalScreen[str]):
    """API key entry screen."""

    BINDINGS = [Binding("escape", "dismiss", "Cancel")]

    def compose(self) -> ComposeResult:
        with Container(id="login-dialog"):
            yield Label("🧠 Velixar", id="login-logo")
            yield Label("Enter your API key to connect", id="login-subtitle")
            yield Input(placeholder="vx_...", password=True, id="api-key-input")
            yield Label("Get your key at velixarai.com/settings", id="login-hint")

    def on_input_submitted(self, event: Input.Submitted) -> None:
        key = event.value.strip()
        if key:
            self.dismiss(key)


# ── Chat Tab ──

class ChatMessage(Static):
    """A single chat message."""

    def __init__(self, role: str, content: str, **kwargs):
        super().__init__(**kwargs)
        self.role = role
        self.content = content

    def compose(self) -> ComposeResult:
        prefix = "⟩ You" if self.role == "user" else "⟨ Velixar"
        color = "cyan" if self.role == "user" else "green"
        yield Static(f"[bold {color}]{prefix}[/]\n{self.content}")


# ── Memory Tab ──

class StoreMemoryScreen(ModalScreen[dict | None]):
    """Modal for storing a new memory."""

    BINDINGS = [Binding("escape", "dismiss", "Cancel")]

    def compose(self) -> ComposeResult:
        with Container(id="store-dialog"):
            yield Label("Store Memory", id="store-title")
            yield TextArea(id="memory-content")
            yield Input(placeholder="tags (comma-separated)", id="memory-tags")
            with Horizontal(id="store-buttons"):
                yield Button("Store", variant="primary", id="btn-store")
                yield Button("Cancel", id="btn-cancel")

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "btn-store":
            try:
                content = self.query_one("#memory-content", TextArea).text
            except NoMatches:
                content = ""
            try:
                tags_raw = self.query_one("#memory-tags", Input).value
            except NoMatches:
                tags_raw = ""
            tags = [t.strip() for t in tags_raw.split(",") if t.strip()]
            if content.strip():
                self.dismiss({"content": content.strip(), "tags": tags})
        else:
            self.dismiss(None)


# ── Main App ──

class VelixarTUI(App):
    """Velixar Terminal UI."""

    TITLE = "Velixar"
    SUB_TITLE = "AI Memory Platform"
    CSS = """
    #login-dialog {
        width: 60;
        height: auto;
        padding: 2 4;
        background: $surface;
        border: thick $primary;
        align: center middle;
    }
    #login-logo {
        text-align: center;
        text-style: bold;
        color: $primary;
        width: 100%;
        margin-bottom: 1;
    }
    #login-subtitle {
        text-align: center;
        color: $text-muted;
        width: 100%;
        margin-bottom: 1;
    }
    #login-hint {
        text-align: center;
        color: $text-disabled;
        width: 100%;
        margin-top: 1;
    }
    #store-dialog {
        width: 70;
        height: auto;
        padding: 2 4;
        background: $surface;
        border: thick $primary;
        align: center middle;
    }
    #store-title {
        text-style: bold;
        margin-bottom: 1;
    }
    #store-buttons {
        margin-top: 1;
        align: right middle;
        height: 3;
    }
    #store-buttons Button {
        margin-left: 1;
    }
    #chat-scroll {
        height: 1fr;
        padding: 1 2;
    }
    #chat-input {
        dock: bottom;
        margin: 0 2 1 2;
    }
    #status-bar {
        dock: bottom;
        height: 1;
        background: $primary-background;
        color: $text-muted;
        padding: 0 2;
    }
    #memory-content {
        height: 8;
    }
    .usage-card {
        padding: 1 2;
        margin: 1;
        border: round $primary;
        height: auto;
    }
    .usage-label {
        color: $text-muted;
    }
    .usage-value {
        text-style: bold;
        color: $primary;
    }
    """

    BINDINGS = [
        Binding("ctrl+q", "quit", "Quit"),
        Binding("ctrl+l", "logout", "Logout"),
    ]

    client: VelixarClient | None = None
    connected = reactive(False)

    def compose(self) -> ComposeResult:
        yield Header()
        with TabbedContent():
            with TabPane("Chat", id="tab-chat"):
                with Vertical():
                    yield VerticalScroll(id="chat-scroll")
                    yield Input(placeholder="Message Velixar...", id="chat-input")
            with TabPane("Memories", id="tab-memories"):
                with Vertical():
                    with Horizontal(id="memory-actions"):
                        yield Button("↻ Refresh", id="btn-refresh-mem")
                        yield Button("+ Store", variant="primary", id="btn-store-mem")
                        yield Input(placeholder="Search memories...", id="memory-search")
                    yield DataTable(id="memory-table")
            with TabPane("Usage", id="tab-usage"):
                yield VerticalScroll(id="usage-scroll")
        yield Static("", id="status-bar")
        yield Footer()

    async def on_mount(self) -> None:
        # Setup memory table columns
        table = self.query_one("#memory-table", DataTable)
        table.add_columns("ID", "Content", "Tags", "Tier")
        table.cursor_type = "row"

        # Check for stored key
        key = get_api_key()
        if key:
            await self._connect(key)
        else:
            self.push_screen(LoginScreen(), self._on_login)

    def _on_login(self, key: str | None) -> None:
        if key:
            self.run_worker(self._connect(key))
        else:
            self.exit()

    async def _connect(self, key: str) -> None:
        self.client = VelixarClient(key)
        try:
            health = await self.client.health()
            if health.get("status") == "healthy":
                set_api_key(key)
                self.connected = True
                self._set_status("Connected ✓")
                await self._load_memories()
                await self._load_usage()
            else:
                self._set_status("Connection failed")
                self.push_screen(LoginScreen(), self._on_login)
        except Exception as e:
            self._set_status(f"Error: {e}")
            self.push_screen(LoginScreen(), self._on_login)

    def _set_status(self, text: str) -> None:
        try:
            self.query_one("#status-bar", Static).update(f" {text}")
        except NoMatches:
            pass

    # ── Chat ──

    async def on_input_submitted(self, event: Input.Submitted) -> None:
        if event.input.id == "chat-input" and self.client:
            message = event.value.strip()
            if not message:
                return
            event.input.value = ""
            scroll = self.query_one("#chat-scroll", VerticalScroll)
            scroll.mount(ChatMessage("user", message))

            self._set_status("Thinking...")
            try:
                result = await self.client.chat(message)
                response = result.get("response") or result.get("message") or str(result)
                scroll.mount(ChatMessage("assistant", response))
                self._set_status("Connected ✓")
            except Exception as e:
                scroll.mount(ChatMessage("assistant", f"[red]Error: {e}[/]"))
                self._set_status(f"Error: {e}")
            scroll.scroll_end(animate=False)

        elif event.input.id == "memory-search" and self.client:
            query = event.value.strip()
            if query:
                await self._search_memories(query)

    # ── Memories ──

    async def _load_memories(self) -> None:
        if not self.client:
            return
        try:
            result = await self.client.list_memories(limit=50)
            memories = result.get("memories", result.get("results", []))
            table = self.query_one("#memory-table", DataTable)
            table.clear()
            for m in memories:
                content = str(m.get("content", ""))[:80]
                tags = ", ".join(m.get("tags", []))
                tier = str(m.get("tier", ""))
                table.add_row(str(m.get("id", ""))[:8], content, tags, tier)
        except Exception as e:
            self._set_status(f"Failed to load memories: {e}")

    async def _search_memories(self, query: str) -> None:
        if not self.client:
            return
        try:
            result = await self.client.search_memories(query)
            memories = result.get("memories", result.get("results", []))
            table = self.query_one("#memory-table", DataTable)
            table.clear()
            for m in memories:
                content = str(m.get("content", ""))[:80]
                tags = ", ".join(m.get("tags", []))
                score = str(m.get("score", ""))[:5]
                table.add_row(str(m.get("id", ""))[:8], content, tags, score)
            self._set_status(f"Found {len(memories)} memories")
        except Exception as e:
            self._set_status(f"Search failed: {e}")

    async def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "btn-refresh-mem":
            await self._load_memories()
        elif event.button.id == "btn-store-mem":
            self.push_screen(StoreMemoryScreen(), self._on_store_memory)

    def _on_store_memory(self, result: dict | None) -> None:
        if result:
            self.run_worker(self._do_store_memory(result))

    async def _do_store_memory(self, data: dict) -> None:
        if not self.client:
            return
        try:
            result = await self.client.store_memory(data["content"], data.get("tags", []))
            self._set_status(f"Stored: {result.get('id', 'ok')}")
            await self._load_memories()
        except Exception as e:
            self._set_status(f"Store failed: {e}")

    # ── Usage ──

    async def _load_usage(self) -> None:
        if not self.client:
            return
        try:
            health = await self.client.health()
            scroll = self.query_one("#usage-scroll", VerticalScroll)
            await scroll.remove_children()

            scroll.mount(Static(
                "[bold]Platform Status[/]\n"
                f"  API: [green]healthy[/]\n"
                f"  Qdrant: {'[green]✓[/]' if health.get('qdrant') else '[red]✗[/]'}\n"
                f"  Redis: {'[green]✓[/]' if health.get('redis') else '[red]✗[/]'}\n"
                f"  Version: {health.get('version', '?')}",
                classes="usage-card",
            ))
        except Exception as e:
            self._set_status(f"Failed to load usage: {e}")

    # ── Actions ──

    def action_logout(self) -> None:
        clear_api_key()
        self.client = None
        self.connected = False
        self._set_status("Logged out")
        self.push_screen(LoginScreen(), self._on_login)


def main():
    app = VelixarTUI()
    app.run()


if __name__ == "__main__":
    main()
