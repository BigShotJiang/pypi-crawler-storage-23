"""Velixar TUI — Terminal UI for the Velixar AI memory platform."""
