"""API key storage using system keyring with file fallback."""

import os
import json
from pathlib import Path

CONFIG_DIR = Path.home() / ".config" / "velixar"
CONFIG_FILE = CONFIG_DIR / "config.json"


def _load_config() -> dict:
    if CONFIG_FILE.exists():
        return json.loads(CONFIG_FILE.read_text())
    return {}


def _save_config(data: dict):
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    CONFIG_FILE.write_text(json.dumps(data, indent=2))
    os.chmod(CONFIG_FILE, 0o600)


def get_api_key() -> str | None:
    """Get stored API key. Tries keyring first, falls back to config file."""
    try:
        import keyring
        key = keyring.get_password("velixar", "api_key")
        if key:
            return key
    except Exception:
        pass
    return _load_config().get("api_key")


def set_api_key(key: str):
    """Store API key. Tries keyring first, falls back to config file."""
    try:
        import keyring
        keyring.set_password("velixar", "api_key", key)
        return
    except Exception:
        pass
    config = _load_config()
    config["api_key"] = key
    _save_config(config)


def clear_api_key():
    """Remove stored API key."""
    try:
        import keyring
        keyring.delete_password("velixar", "api_key")
    except Exception:
        pass
    config = _load_config()
    config.pop("api_key", None)
    _save_config(config)
