# Velixar TUI

Terminal UI for the [Velixar](https://velixarai.com) AI memory platform.

![Python 3.10+](https://img.shields.io/badge/python-3.10+-blue)
![License: MIT](https://img.shields.io/badge/license-MIT-green)

## Install

```bash
pip install velixar-tui
```

## Usage

```bash
velixar
```

On first launch, enter your API key (get one at [app.velixarai.com/settings/api-keys](https://app.velixarai.com/settings/api-keys)).

## Features

- **Chat** — Talk to Velixar with persistent memory
- **Memories** — Browse, search, store, and delete memories
- **Usage** — Platform health and usage stats

## Keybindings

| Key | Action |
|-----|--------|
| `Tab` | Switch tabs |
| `Ctrl+Q` | Quit |
| `Ctrl+L` | Logout / switch API key |
| `Enter` | Send message / search |

## License

MIT
