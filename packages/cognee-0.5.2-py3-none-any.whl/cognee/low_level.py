from cognee.infrastructure.engine import ExtendableDataPoint as DataPoint
from cognee.modules.engine.operations.setup import setup
