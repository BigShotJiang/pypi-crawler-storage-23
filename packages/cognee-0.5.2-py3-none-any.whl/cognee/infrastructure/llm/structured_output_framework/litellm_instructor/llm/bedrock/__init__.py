"""Bedrock LLM adapter module."""

from .adapter import BedrockAdapter

__all__ = ["BedrockAdapter"]
