from cognee.cli._cognee import main

if __name__ == "__main__":
    main()
