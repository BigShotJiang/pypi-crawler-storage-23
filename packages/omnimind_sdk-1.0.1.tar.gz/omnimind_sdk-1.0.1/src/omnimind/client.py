import websocket
import threading
import time
import json
from .tools import get_tool_definition, get_event_definition
from .generated import omnimind_pb2
from google.protobuf.message import DecodeError

class OmniMindClient:
    def __init__(self, server_url, sn, token="", input_audio_format=None, output_audio_format=None, enable_tts=False):
        self.server_url = server_url
        self.sn = sn
        self.token = token
        self.input_audio_format = input_audio_format
        self.output_audio_format = output_audio_format
        self.enable_tts = enable_tts
        self.ws = None
        self.voice_callback = None
        self.text_callback = None
        self.tool_call_callback = None
        self.tool_handlers = {} # Map function_name -> callable
        self.running = False
        self.thread = None
        self.on_open_callback = None
        self.heartbeat_timer = None
        self.auth_timeout_timer = None
        self.heartbeat_interval = 30.0

    def set_voice_callback(self, callback):
        """
        Callback for voice stream data.
        Args:
            callback (function): function(data: bytes)
        """
        self.voice_callback = callback

    def set_text_callback(self, callback):
        """
        Callback for text messages.
        Args:
            callback (function): function(content: str, role: str)
        """
        self.text_callback = callback

    def set_tool_call_callback(self, callback):
        """
        Callback for tool calls.
        Args:
            callback (function): function(call_id: str, name: str, arguments: str) -> str
            The callback should return the result string.
        """
        self.tool_call_callback = callback

    def set_on_open_callback(self, callback):
        """
        Callback when connection is opened.
        """
        self.on_open_callback = callback

    def _start_heartbeat(self):
        self._stop_heartbeat()
        if not self.running:
            return
        
        self.heartbeat_timer = threading.Timer(self.heartbeat_interval, self._send_ping)
        self.heartbeat_timer.daemon = True
        self.heartbeat_timer.start()

    def _stop_heartbeat(self):
        if self.heartbeat_timer:
            self.heartbeat_timer.cancel()
            self.heartbeat_timer = None

    def _start_auth_timeout(self):
        self._stop_auth_timeout()
        self.auth_timeout_timer = threading.Timer(5.0, self._handle_auth_timeout)
        self.auth_timeout_timer.daemon = True
        self.auth_timeout_timer.start()

    def _stop_auth_timeout(self):
        if self.auth_timeout_timer:
            self.auth_timeout_timer.cancel()
            self.auth_timeout_timer = None

    def _handle_auth_timeout(self):
        if self.running and self.ws:
            print("[Client] Authentication timed out after 5s")
            self.close()

    def _send_ping(self):
        if not self.running or not self.ws:
            return

        try:
            msg = omnimind_pb2.OmniMessage()
            msg.sn = self.sn
            msg.type = omnimind_pb2.PING
            msg.timestamp = int(time.time() * 1000)
            
            # Send PING
            self.ws.send(msg.SerializeToString(), opcode=websocket.ABNF.OPCODE_BINARY)
            
            # Schedule next heartbeat
            self._start_heartbeat()
        except Exception as e:
            print(f"Error sending PING: {e}")
            self._stop_heartbeat()

    def _on_message(self, ws, message):
        try:
            msg = omnimind_pb2.OmniMessage()
            msg.ParseFromString(message)
            
            if msg.type == omnimind_pb2.AUTH_RESP:
                self._stop_auth_timeout()
                ar = omnimind_pb2.AuthResponse()
                ar.ParseFromString(msg.payload)
                if ar.success:
                    print(f"[Client] Authenticated successfully")
                    if self.on_open_callback:
                        self.on_open_callback()
                else:
                    print(f"[Client] Authentication failed: {ar.error_message} (Code: {ar.code})")
                    self.close()
            elif msg.type == omnimind_pb2.VOICE_STREAM:
                if self.voice_callback:
                    self.voice_callback(msg.payload)
            elif msg.type == omnimind_pb2.TEXT_MSG:
                if self.text_callback:
                    txt = omnimind_pb2.TextMessage()
                    txt.ParseFromString(msg.payload)
                    self.text_callback(txt.content, txt.role)
            elif msg.type == omnimind_pb2.TOOL_CALL:
                tc = omnimind_pb2.ToolCall()
                tc.ParseFromString(msg.payload)
                print(f"[Client] Tool Call Received: {tc.function_name} {tc.args_json}")
                
                result = None
                handled = False
                
                # Check specific handlers first
                if tc.function_name in self.tool_handlers:
                    try:
                        args = json.loads(tc.args_json)
                        func = self.tool_handlers[tc.function_name]
                        res_obj = func(**args)
                        
                        if isinstance(res_obj, (dict, list)):
                            result = json.dumps(res_obj)
                        else:
                            result = str(res_obj)
                        handled = True
                    except Exception as e:
                        print(f"Error executing tool handler {tc.function_name}: {e}")
                        self.send_tool_response(tc.call_id, str(e), is_error=True)
                        return

                # Fallback to generic callback
                if not handled and self.tool_call_callback:
                    result = self.tool_call_callback(tc.call_id, tc.function_name, tc.args_json)
                    handled = True
                    
                if handled and result is not None:
                    self.send_tool_response(tc.call_id, result)
            elif msg.type == omnimind_pb2.PONG:
                # Received PONG, connection is alive
                pass
            elif msg.type == omnimind_pb2.PING:
                # Respond with PONG if server pings us (optional, but good practice)
                pong = omnimind_pb2.OmniMessage()
                pong.sn = self.sn
                pong.type = omnimind_pb2.PONG
                pong.timestamp = int(time.time() * 1000)
                ws.send(pong.SerializeToString(), opcode=websocket.ABNF.OPCODE_BINARY)
            # Handle other types if needed
        except DecodeError:
            print("Failed to decode message")
        except Exception as e:
            print(f"Error handling message: {e}")

    def _on_error(self, ws, error):
        print(f"Error: {error}")

    def _on_close(self, ws, close_status_code, close_msg):
        print(f"Connection closed (Code: {close_status_code}, Reason: {close_msg})")
        self.running = False
        self._stop_heartbeat()
        self._stop_auth_timeout()
        
        # 1008: Policy Violation (used for Auth Failure)
        if close_status_code == 1008:
            print("Auth Failure detected. Please check your token.")

    def _on_open(self, ws):
        print("Connected. Sending AUTH...")
        
        # Send AUTH
        auth = omnimind_pb2.AuthPayload()
        auth.firmware_version = "1.0.0"
        auth.token = self.token
        auth.protocol_version = 1
        
        if self.input_audio_format:
            auth.input_audio_format.CopyFrom(self.input_audio_format)
            
        if self.output_audio_format:
            auth.output_audio_format.CopyFrom(self.output_audio_format)

        auth.enable_tts = self.enable_tts
            
        msg = omnimind_pb2.OmniMessage()
        msg.sn = self.sn
        msg.type = omnimind_pb2.AUTH
        msg.payload = auth.SerializeToString()
        msg.timestamp = int(time.time() * 1000)
        
        ws.send(msg.SerializeToString(), opcode=websocket.ABNF.OPCODE_BINARY)
        
        # Start Heartbeat
        self._start_heartbeat()
        
        # Start Auth Timeout
        self._start_auth_timeout()
        
    def close(self):
        """
        Close the connection and stop heartbeats.
        """
        self.running = False
        self._stop_heartbeat()
        self._stop_auth_timeout()
        if self.ws:
            try:
                self.ws.close()
            except:
                pass
        self.ws = None

    def register_tools(self, tools_list):
        """
        Register MCP tools and events.
        Args:
            tools_list (list): List of tool/event definitions (dicts) or annotated functions
        """
        reg = omnimind_pb2.ToolManifest()
        for t in tools_list:
            if callable(t):
                if getattr(t, "_is_mcp_event", False):
                    # Handle annotated event
                    definition = get_event_definition(t)
                    event = reg.events.add()
                    event.name = definition.get("name")
                    event.description = definition.get("description")
                    event.payload_schema = json.dumps(definition.get("payload_schema", {}))
                else:
                    # Handle annotated tool (default)
                    definition = get_tool_definition(t)
                    self.tool_handlers[definition["name"]] = t
                    
                    tool = reg.tools.add()
                    tool.name = definition.get("name")
                    tool.description = definition.get("description")
                    tool.args_schema = json.dumps(definition.get("input_schema", {}))
            else:
                # Handle raw dict (legacy support)
                if "payload_schema" in t:
                     event = reg.events.add()
                     event.name = t.get("name")
                     event.description = t.get("description")
                     schema = t.get("payload_schema", {})
                     event.payload_schema = json.dumps(schema) if isinstance(schema, dict) else str(schema)
                else:
                    tool = reg.tools.add()
                    tool.name = t.get("name")
                    tool.description = t.get("description")
                    schema = t.get("input_schema") or t.get("args_schema", {})
                    tool.args_schema = json.dumps(schema) if isinstance(schema, dict) else str(schema)
            
        msg = omnimind_pb2.OmniMessage()
        msg.sn = self.sn
        msg.type = omnimind_pb2.MCP_REG
        msg.payload = reg.SerializeToString()
        msg.timestamp = int(time.time() * 1000)
        
        self.ws.send(msg.SerializeToString(), opcode=websocket.ABNF.OPCODE_BINARY)

    def send_tool_response(self, call_id, content, is_error=False):
        """
        Send tool execution result.
        """
        resp = omnimind_pb2.ToolResponse()
        resp.call_id = call_id
        if is_error:
            resp.error = content
        else:
            resp.result_json = content
        
        msg = omnimind_pb2.OmniMessage()
        msg.sn = self.sn
        msg.type = omnimind_pb2.TOOL_RESP
        msg.payload = resp.SerializeToString()
        msg.timestamp = int(time.time() * 1000)
        
        self.ws.send(msg.SerializeToString(), opcode=websocket.ABNF.OPCODE_BINARY)

    def send_vision_request(self, image_data, prompt="", require_json=False):
        """
        Send Vision Analysis Request
        Args:
            image_data (bytes): Image data (JPEG/PNG)
            prompt (str): Optional prompt for the vision model
            require_json (bool): Whether to request JSON output
        """
        if not self.ws or not self.ws.sock or not self.running:
            print("Cannot send message: Connection not open")
            return

        req = omnimind_pb2.VisionRequest()
        req.image_data = image_data
        req.prompt = prompt
        req.require_json = require_json

        msg = omnimind_pb2.OmniMessage()
        msg.sn = self.sn
        msg.type = omnimind_pb2.VISION_ANALYSIS
        msg.payload = req.SerializeToString()
        msg.timestamp = int(time.time() * 1000)

        self.ws.send(msg.SerializeToString(), opcode=websocket.ABNF.OPCODE_BINARY)

    def send_event_report(self, event_type, source_component, payload_json="{}"):
        """
        Send Event Report
        Args:
            event_type (str): Event type identifier
            source_component (str): Which component triggered it
            payload_json (str): Detailed event data in JSON format
        """
        if not self.ws or not self.ws.sock or not self.running:
            print("Cannot send message: Connection not open")
            return

        report = omnimind_pb2.EventReport()
        report.event_type = event_type
        report.source_component = source_component
        report.payload_json = payload_json

        msg = omnimind_pb2.OmniMessage()
        msg.sn = self.sn
        msg.type = omnimind_pb2.EVENT_REPORT
        msg.payload = report.SerializeToString()
        msg.timestamp = int(time.time() * 1000)

        self.ws.send(msg.SerializeToString(), opcode=websocket.ABNF.OPCODE_BINARY)

    def connect(self):
        """
        Connect to the server in a separate thread.
        """
        # Enable trace for debugging if needed
        # websocket.enableTrace(True)
        self.ws = websocket.WebSocketApp(self.server_url,
                                         on_open=self._on_open,
                                         on_message=self._on_message,
                                         on_error=self._on_error,
                                         on_close=self._on_close)
        self.running = True
        self.thread = threading.Thread(target=self.ws.run_forever)
        self.thread.daemon = True
        self.thread.start()

    def send_text(self, content):
        """
        Send a text message to the server.
        """
        if not self.ws or not self.ws.sock or not self.running:
            print("Cannot send message: Connection not open")
            return
            
        txt = omnimind_pb2.TextMessage()
        txt.content = content
        txt.role = "user" 
        
        msg = omnimind_pb2.OmniMessage()
        msg.sn = self.sn
        msg.type = omnimind_pb2.TEXT_MSG
        msg.payload = txt.SerializeToString()
        msg.timestamp = int(time.time() * 1000)
        
        self.ws.send(msg.SerializeToString(), opcode=websocket.ABNF.OPCODE_BINARY)

    def close(self):
        """
        Close the connection.
        """
        if self.ws:
            self.ws.close()
        self.running = False

    def send_image(self, image_data):
        """
        Send an image frame (JPEG/PNG bytes) to the server.
        """
        if not self.ws or not self.ws.sock or not self.running:
            print("Cannot send message: Connection not open")
            return
            
        msg = omnimind_pb2.OmniMessage()
        msg.sn = self.sn
        msg.type = omnimind_pb2.IMAGE_FRAME
        msg.payload = image_data
        msg.timestamp = int(time.time() * 1000)
        
        self.ws.send(msg.SerializeToString(), opcode=websocket.ABNF.OPCODE_BINARY)

    def send_voice_stream(self, audio_data):
        """
        Send a chunk of voice stream (Opus/PCM bytes) to the server.
        """
        if not self.ws or not self.ws.sock or not self.running:
            # Silent return for voice to avoid spamming logs
            return
            
        msg = omnimind_pb2.OmniMessage()
        msg.sn = self.sn
        msg.type = omnimind_pb2.VOICE_STREAM
        msg.payload = audio_data
        msg.timestamp = int(time.time() * 1000)
        
        self.ws.send(msg.SerializeToString(), opcode=websocket.ABNF.OPCODE_BINARY)
        
    def wait(self):
        """
        Wait for the connection thread to finish.
        """
        if self.thread:
            try:
                self.thread.join()
            except KeyboardInterrupt:
                self.close()

    def close(self):
        self.running = False
        if self.ws:
            self.ws.close()
