# OmniMind Python SDK

OmniMind SDK is a high-performance communication library for AIoT devices using the OmniMind Protocol. It supports real-time voice streaming, text messaging, and hardware tool registration (MCP).

## Installation

```bash
pip install omnimind-sdk
```

If you need audio support (optional):
```bash
pip install omnimind-sdk[audio]
```

## Quick Start

```python
from omnimind import OmniMindClient

def on_text(content, role):
    print(f"[{role}] {content}")

client = OmniMindClient(
    server_url="ws://127.0.0.1:8082/v1/ws",
    sn="YOUR_DEVICE_SN",
    token="YOUR_TOKEN"
)

client.set_text_callback(on_text)
client.connect()

client.send_text("Hello, who are you?")
```

## Features

- **Real-time Voice**: Stream audio chunks using Opus/PCM.
- **Tool Registration**: Register hardware capabilities as tools for AI to call.
- **Heartbeat**: Automatic PING/PONG mechanism to keep connection alive.
- **Protobuf**: Efficient binary serialization.

## License

MIT
