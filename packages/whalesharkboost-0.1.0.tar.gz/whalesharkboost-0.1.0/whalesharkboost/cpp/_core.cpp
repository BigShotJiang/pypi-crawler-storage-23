/**
 * WhaleSharkBoost C++ acceleration module (pybind11)
 *
 * Exports:
 *   build_histogram        – single-pass gradient/hessian histogram building
 *   find_best_split_basic  – fast split finding (no adaptive_reg/monotone)
 *   predict_trees          – batch prediction over all trees (flat arrays)
 *   set_num_threads        – set the number of OpenMP threads
 *   get_num_threads        – get the current effective thread count
 */

#include <pybind11/pybind11.h>
#include <pybind11/numpy.h>
#include <pybind11/stl.h>

#include <algorithm>
#include <cmath>
#include <cstdint>
#include <limits>
#include <tuple>
#include <vector>

#ifdef _OPENMP
#  include <omp.h>
#else
// Stubs so the rest of the file compiles without #ifdef guards everywhere.
inline int omp_get_thread_num()  { return 0; }
inline int omp_get_num_threads() { return 1; }
inline int omp_get_max_threads() { return 1; }
#endif

namespace py = pybind11;
using namespace pybind11::literals;

// ---- Global thread count (-1 means "use all available") ----
static int g_num_threads = -1;

static int resolve_num_threads() {
#ifdef _OPENMP
    return (g_num_threads > 0) ? g_num_threads : omp_get_max_threads();
#else
    return 1;
#endif
}

// ============================================================
// 1. build_histogram
//
// Single-pass over sample rows.  For each sample i we iterate
// over every feature j and accumulate into hist[j, bin].
// This avoids n_features separate np.bincount calls and gives
// better cache usage because X_binned is row-major.
//
// OpenMP: samples are split across threads; each thread owns a
// private flat histogram to avoid false sharing. After the
// parallel region the per-thread histograms are merged serially.
// ============================================================

std::tuple<py::array_t<double>, py::array_t<double>, py::array_t<int64_t>>
build_histogram(
    py::array_t<uint8_t,  py::array::c_style | py::array::forcecast> X_binned,
    py::array_t<double,   py::array::c_style | py::array::forcecast> gradients,
    py::array_t<double,   py::array::c_style | py::array::forcecast> hessians,
    py::object sample_indices_obj,
    int max_bins)
{
    auto X = X_binned.unchecked<2>();
    auto g = gradients.unchecked<1>();
    auto h = hessians.unchecked<1>();

    const int n_features = static_cast<int>(X.shape(1));
    const int n_bins     = max_bins + 1;   // +1 for NaN bin

    // ---- Allocate output arrays ----
    py::array_t<double>  grad_hist ({n_features, n_bins});
    py::array_t<double>  hess_hist ({n_features, n_bins});
    py::array_t<int64_t> count_hist({n_features, n_bins});

    auto gh = grad_hist .mutable_unchecked<2>();
    auto hh = hess_hist .mutable_unchecked<2>();
    auto ch = count_hist.mutable_unchecked<2>();

    // Zero-initialise output (numpy does not guarantee this)
    for (int j = 0; j < n_features; ++j)
        for (int b = 0; b < n_bins; ++b) { gh(j,b)=0.0; hh(j,b)=0.0; ch(j,b)=0; }

    // ---- Resolve sample indices ----
    std::vector<int64_t> idx_buf;
    const int64_t* idx_ptr;
    int64_t n_sub;

    if (sample_indices_obj.is_none()) {
        n_sub = X.shape(0);
        idx_buf.resize(n_sub);
        for (int64_t k = 0; k < n_sub; ++k) idx_buf[k] = k;
        idx_ptr = idx_buf.data();
    } else {
        auto si = py::cast<py::array_t<int64_t, py::array::c_style | py::array::forcecast>>(
                      sample_indices_obj);
        n_sub = si.shape(0);
        idx_buf.resize(n_sub);
        auto si_r = si.unchecked<1>();
        for (int64_t k = 0; k < n_sub; ++k) idx_buf[k] = si_r(k);
        idx_ptr = idx_buf.data();
    }

    // ---- Thread-local histogram accumulation ----
    const int nthreads_req = resolve_num_threads();
    const int stride       = n_features * n_bins;

    // One flat histogram per thread, zero-initialised
    std::vector<double>  tl_gh((std::size_t)nthreads_req * stride, 0.0);
    std::vector<double>  tl_hh((std::size_t)nthreads_req * stride, 0.0);
    std::vector<int64_t> tl_ch((std::size_t)nthreads_req * stride, 0);

    int nthreads_used = 1;

#pragma omp parallel num_threads(nthreads_req)
    {
        const int tid  = omp_get_thread_num();
        double*  my_gh = tl_gh.data() + (std::size_t)tid * stride;
        double*  my_hh = tl_hh.data() + (std::size_t)tid * stride;
        int64_t* my_ch = tl_ch.data() + (std::size_t)tid * stride;

#pragma omp for schedule(static)
        for (int64_t k = 0; k < n_sub; ++k) {
            const int64_t i  = idx_ptr[k];
            const double  gi = g(i);
            const double  hi = h(i);
            const uint8_t* row = &X(i, 0);
            for (int j = 0; j < n_features; ++j) {
                const int b = row[j];
                my_gh[j * n_bins + b] += gi;
                my_hh[j * n_bins + b] += hi;
                my_ch[j * n_bins + b] += 1;
            }
        }

#pragma omp single
        { nthreads_used = omp_get_num_threads(); }
    }  // implicit barrier – nthreads_used is visible here

    // ---- Serial merge into output ----
    for (int t = 0; t < nthreads_used; ++t) {
        const double*  src_gh = tl_gh.data() + (std::size_t)t * stride;
        const double*  src_hh = tl_hh.data() + (std::size_t)t * stride;
        const int64_t* src_ch = tl_ch.data() + (std::size_t)t * stride;
        for (int j = 0; j < n_features; ++j) {
            for (int b = 0; b < n_bins; ++b) {
                gh(j, b) += src_gh[j * n_bins + b];
                hh(j, b) += src_hh[j * n_bins + b];
                ch(j, b) += src_ch[j * n_bins + b];
            }
        }
    }

    return {grad_hist, hess_hist, count_hist};
}

// ============================================================
// 2. find_best_split_basic
//
// Covers the common case (no adaptive_reg, no monotone constraints).
// Sweeps through (feature, bin, nan_dir) in a tight C++ loop,
// avoiding the large temporary 3-D numpy arrays the Python version creates.
//
// NaN convention (matches Python):
//   nan_dir=0 → NaN samples go LEFT
//   nan_dir=1 → NaN samples go RIGHT
//
// For a split at bin b:
//   nd=0: gL = cumL + g_nan,  gR = g_total - cumL
//   nd=1: gL = cumL,          gR = g_total - cumL + g_nan
//
// OpenMP: features split across threads; each thread tracks its own
// best and updates the global best once via a critical section.
// ============================================================

std::tuple<int, int, double, int>
find_best_split_basic(
    py::array_t<double,  py::array::c_style | py::array::forcecast> grad_hist,
    py::array_t<double,  py::array::c_style | py::array::forcecast> hess_hist,
    py::array_t<int64_t, py::array::c_style | py::array::forcecast> count_hist,
    int    max_bins,
    double reg_lambda,
    double reg_alpha,
    double min_child_weight,
    int    min_child_samples)
{
    auto gh = grad_hist .unchecked<2>();
    auto hh = hess_hist .unchecked<2>();
    auto ch = count_hist.unchecked<2>();

    const int n_features = static_cast<int>(grad_hist.shape(0));
    const int mb         = max_bins;   // valid bins: 0 .. mb-1

    double best_gain    = 0.0;
    int    best_feature = -1;
    int    best_bin     = -1;
    int    best_nan_dir = 0;

    // Inline score function (L1+L2 regularisation).
    // reg_alpha and reg_lambda are captured by reference but are read-only
    // throughout the parallel region, so concurrent access is safe.
    auto score = [&](double g_s, double h_s, double lam) -> double {
        if (reg_alpha == 0.0) {
            return g_s * g_s / (h_s + lam);
        }
        const double abs_g = std::abs(g_s);
        if (abs_g <= reg_alpha) return 0.0;
        const double g_adj = g_s - std::copysign(reg_alpha, g_s);
        return g_adj * g_adj / (h_s + lam);
    };

#pragma omp parallel num_threads(resolve_num_threads())
    {
        // Thread-local best (stack variables – no false sharing)
        double tl_best_gain    = 0.0;
        int    tl_best_feature = -1;
        int    tl_best_bin     = -1;
        int    tl_best_nan_dir = 0;

#pragma omp for schedule(static)
        for (int j = 0; j < n_features; ++j) {
            // Compute totals for valid bins
            double  g_total = 0.0, h_total = 0.0;
            int64_t c_total = 0;
            for (int b = 0; b < mb; ++b) {
                g_total += gh(j, b);
                h_total += hh(j, b);
                c_total += ch(j, b);
            }
            const double  g_nan = gh(j, mb);
            const double  h_nan = hh(j, mb);
            const int64_t c_nan = ch(j, mb);

            const double g_sum = g_total + g_nan;
            const double h_sum = h_total + h_nan;
            const double s_total = score(g_sum, h_sum, reg_lambda);

            // Sweep over nan_dir in the outer loop so inner loop is just bins
            for (int nd = 0; nd < 2; ++nd) {
                double  cumL_g = 0.0, cumL_h = 0.0;
                int64_t cumL_c = 0;

                for (int b = 0; b < mb; ++b) {
                    cumL_g += gh(j, b);
                    cumL_h += hh(j, b);
                    cumL_c += ch(j, b);

                    double  gL, hL, gR, hR;
                    int64_t cL, cR;

                    if (nd == 0) {   // NaN → left
                        gL = cumL_g + g_nan;
                        hL = cumL_h + h_nan;
                        cL = cumL_c + c_nan;
                        gR = g_total - cumL_g;
                        hR = h_total - cumL_h;
                        cR = c_total - cumL_c;
                    } else {         // NaN → right
                        gL = cumL_g;
                        hL = cumL_h;
                        cL = cumL_c;
                        gR = g_total - cumL_g + g_nan;
                        hR = h_total - cumL_h + h_nan;
                        cR = c_total - cumL_c + c_nan;
                    }

                    // Validity checks
                    if (hL < min_child_weight || hR < min_child_weight)  continue;
                    if (cL < (int64_t)min_child_samples ||
                        cR < (int64_t)min_child_samples)                  continue;

                    const double gain = 0.5 * (score(gL, hL, reg_lambda) +
                                               score(gR, hR, reg_lambda) - s_total);

                    if (gain > tl_best_gain) {
                        tl_best_gain    = gain;
                        tl_best_feature = j;
                        tl_best_bin     = b;
                        tl_best_nan_dir = nd;
                    }
                }
            }
        }

        // Merge thread-local best into global best (entered at most nthreads times)
#pragma omp critical
        {
            if (tl_best_gain > best_gain) {
                best_gain    = tl_best_gain;
                best_feature = tl_best_feature;
                best_bin     = tl_best_bin;
                best_nan_dir = tl_best_nan_dir;
            }
        }
    }

    return {best_feature, best_bin, best_gain, best_nan_dir};
}

// ============================================================
// 3. predict_trees
//
// All trees are stored as concatenated flat arrays (pre-order DFS layout).
// Feature indices stored in the tree nodes are already absolute
// (col_indices remapping is done in Python's DecisionTree.to_arrays).
//
// Tree node layout:
//   feature[i]   = split feature (-1 means leaf)
//   threshold[i] = bin threshold
//   nan_dir[i]   = 0→NaN goes left, 1→NaN goes right
//   value[i]     = leaf prediction (only read when feature[i] < 0)
//   left[i]      = index of left child  (-1 for leaf)
//   right[i]     = index of right child (-1 for leaf)
//
// tree_offsets[t] = index of root node of tree t in the flat arrays.
//
// OpenMP: loop order swapped to samples-outer / trees-inner.
// Each sample accumulates into a scalar p, written to pred[i] once
// at the end to minimise false sharing. Tree arrays are read-only.
// ============================================================

py::array_t<double>
predict_trees(
    py::array_t<int32_t, py::array::c_style | py::array::forcecast> all_features,
    py::array_t<int32_t, py::array::c_style | py::array::forcecast> all_thresholds,
    py::array_t<int32_t, py::array::c_style | py::array::forcecast> all_nan_dirs,
    py::array_t<double,  py::array::c_style | py::array::forcecast> all_values,
    py::array_t<int32_t, py::array::c_style | py::array::forcecast> all_lefts,
    py::array_t<int32_t, py::array::c_style | py::array::forcecast> all_rights,
    py::array_t<int32_t, py::array::c_style | py::array::forcecast> tree_offsets,
    py::array_t<double,  py::array::c_style | py::array::forcecast> tree_lrs,
    py::array_t<uint8_t, py::array::c_style | py::array::forcecast> X_binned,
    double base_score,
    int    n_trees,
    int    max_bins)
{
    // Raw pointer access for maximum speed in the inner loop
    const int32_t* feat    = all_features  .data();
    const int32_t* thresh  = all_thresholds.data();
    const int32_t* nan_dir = all_nan_dirs  .data();
    const double*  val     = all_values    .data();
    const int32_t* lchild  = all_lefts     .data();
    const int32_t* rchild  = all_rights    .data();
    const int32_t* offsets = tree_offsets  .data();
    const double*  lrs     = tree_lrs      .data();

    const int n_samples  = static_cast<int>(X_binned.shape(0));
    const int n_features = static_cast<int>(X_binned.shape(1));
    const uint8_t* Xptr  = X_binned.data();
    const uint8_t nan_bin = static_cast<uint8_t>(max_bins);

    auto predictions = py::array_t<double>(n_samples);
    double* pred = predictions.mutable_data();

    // Samples-outer / trees-inner: each sample is fully independent.
    // pred[i] is written exactly once per sample → no false sharing.
#pragma omp parallel for schedule(static) num_threads(resolve_num_threads())
    for (int i = 0; i < n_samples; ++i) {
        const uint8_t* row = Xptr + (int64_t)i * n_features;
        double p = base_score;
        for (int t = 0; t < n_trees; ++t) {
            int node = offsets[t];
            while (feat[node] >= 0) {
                const uint8_t bin = row[feat[node]];
                bool go_left;
                if (bin == nan_bin) {
                    go_left = (nan_dir[node] == 0);
                } else {
                    go_left = (bin <= (uint8_t)thresh[node]);
                }
                node = go_left ? lchild[node] : rchild[node];
            }
            p += lrs[t] * val[node];
        }
        pred[i] = p;
    }

    return predictions;
}

// ============================================================
// 4b. build_histogram_transposed  (FAST PATH)
//
// Accepts X in TRANSPOSED layout: shape (n_features, n_samples), C-contiguous.
// Uses FEATURE-PARALLEL OpenMP instead of sample-parallel.
//
// Advantages over the sample-parallel build_histogram:
//   • Each thread works on a disjoint feature slice → writes go to a different
//     memory region → NO thread-local copies and NO merge step.
//   • Per-thread active histogram = n_bins_per_feature × 3 arrays ≈ 6 KB
//     → stays in L1 cache for the entire inner loop.
//   • Feature column (n_samples uint8 ≈ 50 KB for n=50 000)
//     fits in L2, so random sample-index access hits L2 rather than L3/RAM.
//   • Gradient/hessian values are pre-gathered into contiguous buffers so the
//     inner loop always does sequential (hardware-prefetchable) reads.
//
// Pre-gather step (single-threaded, O(n_sub)):
//   g_sub[k] = gradients[idx[k]]   → turns scattered g[] reads into
//   h_sub[k] = hessians[idx[k]]       sequential g_sub[] reads in inner loop
//
// Call this when X_T is available; fall back to build_histogram otherwise.
// ============================================================

std::tuple<py::array_t<double>, py::array_t<double>, py::array_t<int64_t>>
build_histogram_transposed(
    py::array_t<uint8_t,  py::array::c_style | py::array::forcecast> X_T,
    py::array_t<double,   py::array::c_style | py::array::forcecast> gradients,
    py::array_t<double,   py::array::c_style | py::array::forcecast> hessians,
    py::object sample_indices_obj,
    int max_bins)
{
    const int n_features = static_cast<int>(X_T.shape(0));
    const int n_samples  = static_cast<int>(X_T.shape(1));
    const int n_bins     = max_bins + 1;

    // ---- Resolve sample indices ----
    std::vector<int64_t> idx_buf;
    const int64_t* idx_ptr;
    int64_t n_sub;

    if (sample_indices_obj.is_none()) {
        n_sub = n_samples;
        idx_buf.resize(n_sub);
        for (int64_t k = 0; k < n_sub; ++k) idx_buf[k] = k;
        idx_ptr = idx_buf.data();
    } else {
        auto si = py::cast<py::array_t<int64_t,
                        py::array::c_style | py::array::forcecast>>(sample_indices_obj);
        n_sub = si.shape(0);
        idx_buf.resize(n_sub);
        auto si_r = si.unchecked<1>();
        for (int64_t k = 0; k < n_sub; ++k) idx_buf[k] = si_r(k);
        idx_ptr = idx_buf.data();
    }

    // ---- Pre-gather g and h into contiguous buffers ----
    // This turns n_sub scattered reads (g[idx[k]], h[idx[k]]) into sequential
    // reads in the inner loop, enabling hardware prefetch.
    const double* g_ptr = gradients.data();
    const double* h_ptr = hessians.data();
    std::vector<double> g_sub(n_sub), h_sub(n_sub);
    for (int64_t k = 0; k < n_sub; ++k) {
        g_sub[k] = g_ptr[idx_ptr[k]];
        h_sub[k] = h_ptr[idx_ptr[k]];
    }
    const double* gs = g_sub.data();
    const double* hs = h_sub.data();

    // ---- Allocate output (zero-initialised) ----
    py::array_t<double>  grad_hist ({n_features, n_bins});
    py::array_t<double>  hess_hist ({n_features, n_bins});
    py::array_t<int64_t> count_hist({n_features, n_bins});

    double*  gh = grad_hist .mutable_data();
    double*  hh = hess_hist .mutable_data();
    int64_t* ch = count_hist.mutable_data();
    std::fill(gh, gh + (size_t)n_features * n_bins, 0.0);
    std::fill(hh, hh + (size_t)n_features * n_bins, 0.0);
    std::fill(ch, ch + (size_t)n_features * n_bins, int64_t(0));

    const uint8_t* X_ptr = X_T.data();

    // ---- Feature-parallel accumulation ----
    // Each thread owns a disjoint set of features → no false sharing, no merge.
    // Active histogram per thread: n_bins * 3 arrays = ~6 KB → L1 cache.
    // Feature column: n_samples uint8 → fits in L2 cache.
#pragma omp parallel for schedule(static) num_threads(resolve_num_threads())
    for (int j = 0; j < n_features; ++j) {
        const uint8_t* col  = X_ptr + (size_t)j * n_samples;  // feature-j column
        double*  g_row = gh + j * n_bins;   // 256 doubles = 2 KB  → L1
        double*  h_row = hh + j * n_bins;
        int64_t* c_row = ch + j * n_bins;

        for (int64_t k = 0; k < n_sub; ++k) {
            const int b = col[idx_ptr[k]];   // L2-cached column access
            g_row[b] += gs[k];               // sequential read from g_sub
            h_row[b] += hs[k];               // sequential read from h_sub
            ++c_row[b];
        }
    }

    return {grad_hist, hess_hist, count_hist};
}

// ============================================================
// 4c. partition_samples_transposed
//
// Same as partition_samples but accepts X in transposed layout
// (n_features, n_samples).  Accessing a single feature's column
// is now sequential (contiguous 50 KB block) rather than scattered
// across a row-major 5 MB matrix, yielding L2 cache hits instead
// of L3 cache misses for large datasets.
// ============================================================

std::tuple<py::array_t<int64_t>, py::array_t<int64_t>,
           double, double, double, double>
partition_samples_transposed(
    py::array_t<uint8_t, py::array::c_style | py::array::forcecast> X_T,
    py::array_t<int64_t, py::array::c_style | py::array::forcecast> sample_indices,
    py::array_t<double,  py::array::c_style | py::array::forcecast> gradients,
    py::array_t<double,  py::array::c_style | py::array::forcecast> hessians,
    int feature, int threshold, int max_bins, int nan_dir)
{
    const int64_t  n_sub    = static_cast<int64_t>(sample_indices.shape(0));
    const int64_t  n_samples= static_cast<int64_t>(X_T.shape(1));
    const int64_t* idx_ptr  = sample_indices.data();
    // Pointer to the contiguous feature column (L2-cached for n_samples ≤ 65536)
    const uint8_t* col      = X_T.data() + (size_t)feature * n_samples;
    const double*  g_ptr    = gradients.data();
    const double*  h_ptr    = hessians.data();
    const uint8_t  nan_bin  = static_cast<uint8_t>(max_bins);
    const uint8_t  thresh   = static_cast<uint8_t>(threshold);

    // Pass 1: count left samples
    int64_t n_left = 0;
    for (int64_t k = 0; k < n_sub; ++k) {
        const int64_t i   = idx_ptr[k];
        const uint8_t bin = col[i];   // L2-cached
        bool go_left = (bin == nan_bin) ? (nan_dir == 0) : (bin <= thresh);
        if (go_left) ++n_left;
    }
    const int64_t n_right = n_sub - n_left;

    py::array_t<int64_t> left_arr(n_left);
    py::array_t<int64_t> right_arr(n_right);
    int64_t* left_ptr  = left_arr.mutable_data();
    int64_t* right_ptr = right_arr.mutable_data();

    // Pass 2: fill + accumulate gradient/hessian sums
    int64_t li = 0, ri = 0;
    double gL = 0.0, hL = 0.0, gR = 0.0, hR = 0.0;
    for (int64_t k = 0; k < n_sub; ++k) {
        const int64_t i   = idx_ptr[k];
        const uint8_t bin = col[i];
        bool go_left = (bin == nan_bin) ? (nan_dir == 0) : (bin <= thresh);
        if (go_left) {
            left_ptr[li++] = i;
            gL += g_ptr[i];  hL += h_ptr[i];
        } else {
            right_ptr[ri++] = i;
            gR += g_ptr[i];  hR += h_ptr[i];
        }
    }

    return {left_arr, right_arr, gL, hL, gR, hR};
}

// ============================================================
// 4. subtract_histograms / subtract_histograms_inplace
//
// child_hist = parent_hist - sibling_hist
//
// subtract_histograms      – allocates three new arrays (kept for fallback)
// subtract_histograms_inplace – modifies parent arrays in-place:
//   • Avoids 3 malloc/free calls per split (≈ 60 KB × 3 per call)
//   • Safe because the parent histogram is always discarded after the
//     diff trick: it is popped from the leaf priority queue, so no
//     other reference to it exists when this function is called.
// ============================================================

void subtract_histograms_inplace(
    py::array_t<double,  py::array::c_style> pg,   // parent grad  – modified IN-PLACE
    py::array_t<double,  py::array::c_style> ph,   // parent hess  – modified IN-PLACE
    py::array_t<int64_t, py::array::c_style> pc,   // parent count – modified IN-PLACE
    py::array_t<double,  py::array::c_style | py::array::forcecast> sg,
    py::array_t<double,  py::array::c_style | py::array::forcecast> sh,
    py::array_t<int64_t, py::array::c_style | py::array::forcecast> sc)
{
    const int total = static_cast<int>(pg.shape(0)) * static_cast<int>(pg.shape(1));
    double*  pg_ = pg.mutable_data();
    double*  ph_ = ph.mutable_data();
    int64_t* pc_ = pc.mutable_data();
    const double*  sg_ = sg.data();
    const double*  sh_ = sh.data();
    const int64_t* sc_ = sc.data();

    for (int i = 0; i < total; ++i) {
        pg_[i] -= sg_[i];
        ph_[i] -= sh_[i];
        pc_[i] -= sc_[i];
    }
}

std::tuple<py::array_t<double>, py::array_t<double>, py::array_t<int64_t>>
subtract_histograms(
    py::array_t<double,  py::array::c_style | py::array::forcecast> pg,
    py::array_t<double,  py::array::c_style | py::array::forcecast> ph,
    py::array_t<int64_t, py::array::c_style | py::array::forcecast> pc,
    py::array_t<double,  py::array::c_style | py::array::forcecast> sg,
    py::array_t<double,  py::array::c_style | py::array::forcecast> sh,
    py::array_t<int64_t, py::array::c_style | py::array::forcecast> sc)
{
    const int n_features = static_cast<int>(pg.shape(0));
    const int n_bins     = static_cast<int>(pg.shape(1));
    const int total      = n_features * n_bins;

    py::array_t<double>  out_g({n_features, n_bins});
    py::array_t<double>  out_h({n_features, n_bins});
    py::array_t<int64_t> out_c({n_features, n_bins});

    const double*  pg_ = pg.data();
    const double*  ph_ = ph.data();
    const int64_t* pc_ = pc.data();
    const double*  sg_ = sg.data();
    const double*  sh_ = sh.data();
    const int64_t* sc_ = sc.data();
    double*  og = out_g.mutable_data();
    double*  oh = out_h.mutable_data();
    int64_t* oc = out_c.mutable_data();

    for (int i = 0; i < total; ++i) {
        og[i] = pg_[i] - sg_[i];
        oh[i] = ph_[i] - sh_[i];
        oc[i] = pc_[i] - sc_[i];
    }

    return std::make_tuple(std::move(out_g), std::move(out_h), std::move(out_c));
}

// ============================================================
// 5. partition_samples
//
// Partitions sample_indices into left/right subsets according to
// (feature, threshold, nan_dir) and simultaneously accumulates
// the gradient and hessian sums for each child.
//
// Replaces the Python _apply_split inner loop (fancy-index masking,
// numpy sum calls) with a single 2-pass C++ loop.
//
// Returns (left_indices, right_indices, grad_left, hess_left,
//          grad_right, hess_right).
// ============================================================

std::tuple<py::array_t<int64_t>, py::array_t<int64_t>,
           double, double, double, double>
partition_samples(
    py::array_t<uint8_t, py::array::c_style | py::array::forcecast> X_binned,
    py::array_t<int64_t, py::array::c_style | py::array::forcecast> sample_indices,
    py::array_t<double,  py::array::c_style | py::array::forcecast> gradients,
    py::array_t<double,  py::array::c_style | py::array::forcecast> hessians,
    int feature, int threshold, int max_bins, int nan_dir)
{
    const int64_t  n_sub   = static_cast<int64_t>(sample_indices.shape(0));
    const int64_t  n_cols  = static_cast<int64_t>(X_binned.shape(1));
    const int64_t* idx_ptr = sample_indices.data();
    const uint8_t* X_ptr   = X_binned.data();
    const double*  g_ptr   = gradients.data();
    const double*  h_ptr   = hessians.data();
    const uint8_t  nan_bin = static_cast<uint8_t>(max_bins);
    const uint8_t  thresh  = static_cast<uint8_t>(threshold);

    // Pass 1: count left samples
    int64_t n_left = 0;
    for (int64_t k = 0; k < n_sub; ++k) {
        const int64_t i   = idx_ptr[k];
        const uint8_t bin = X_ptr[i * n_cols + feature];
        bool go_left;
        if (bin == nan_bin) {
            go_left = (nan_dir == 0);
        } else {
            go_left = (bin <= thresh);
        }
        if (go_left) ++n_left;
    }
    const int64_t n_right = n_sub - n_left;

    // Allocate output index arrays
    py::array_t<int64_t> left_arr(n_left);
    py::array_t<int64_t> right_arr(n_right);
    int64_t* left_ptr  = left_arr.mutable_data();
    int64_t* right_ptr = right_arr.mutable_data();

    // Pass 2: fill index arrays + accumulate gradient/hessian sums
    int64_t li = 0, ri = 0;
    double gL = 0.0, hL = 0.0, gR = 0.0, hR = 0.0;

    for (int64_t k = 0; k < n_sub; ++k) {
        const int64_t i   = idx_ptr[k];
        const uint8_t bin = X_ptr[i * n_cols + feature];
        bool go_left;
        if (bin == nan_bin) {
            go_left = (nan_dir == 0);
        } else {
            go_left = (bin <= thresh);
        }
        if (go_left) {
            left_ptr[li++] = i;
            gL += g_ptr[i];
            hL += h_ptr[i];
        } else {
            right_ptr[ri++] = i;
            gR += g_ptr[i];
            hR += h_ptr[i];
        }
    }

    return {left_arr, right_arr, gL, hL, gR, hR};
}

// ============================================================
// Thread control
// ============================================================

void set_num_threads(int n) {
    g_num_threads = (n > 0) ? n : -1;
}

int get_num_threads() {
    return resolve_num_threads();
}

// ============================================================
// Module registration
// ============================================================

PYBIND11_MODULE(_core, m) {
    m.doc() = "WhaleSharkBoost C++ acceleration (histogram, split finding, tree prediction, partition)";

    m.def("set_num_threads", &set_num_threads, "n"_a,
          "Set number of OpenMP threads used by WhaleSharkBoost kernels. "
          "Pass n <= 0 to restore automatic (all available cores).");

    m.def("get_num_threads", &get_num_threads,
          "Return the current effective number of threads "
          "(1 when built without OpenMP).");

    m.def("build_histogram", &build_histogram,
          "X_binned"_a, "gradients"_a, "hessians"_a,
          "sample_indices"_a, "max_bins"_a,
          R"doc(
Build gradient/hessian/count histograms in a single row-major pass.

Parameters
----------
X_binned        : uint8 array (n_samples, n_features)
gradients       : float64 array (n_samples,)
hessians        : float64 array (n_samples,)
sample_indices  : int64 array (n_sub,) or None
max_bins        : int

Returns
-------
(grad_hist, hess_hist, count_hist) each of shape (n_features, max_bins+1)
)doc");

    m.def("find_best_split_basic", &find_best_split_basic,
          "grad_hist"_a, "hess_hist"_a, "count_hist"_a,
          "max_bins"_a, "reg_lambda"_a, "reg_alpha"_a,
          "min_child_weight"_a, "min_child_samples"_a,
          R"doc(
Find best split (feature, bin, gain, nan_dir) without adaptive_reg or monotone constraints.

Returns
-------
(best_feature, best_bin, best_gain, best_nan_dir)
Returns (-1, -1, 0.0, 0) when no valid split is found.
)doc");

    m.def("build_histogram_transposed", &build_histogram_transposed,
          "X_T"_a, "gradients"_a, "hessians"_a, "sample_indices"_a, "max_bins"_a,
          R"doc(
Feature-parallel histogram build using transposed X layout (n_features, n_samples).

Advantages over build_histogram:
  - Each thread's histogram (~6 KB) fits in L1 cache (vs 200 KB for 100 features)
  - No per-thread histogram copies or merge step
  - Feature column (50 KB) fits in L2 cache for typical n_samples
  - Gradients/hessians pre-gathered for sequential inner-loop access

Parameters
----------
X_T            : uint8 (n_features, n_samples), C-contiguous transposed X_binned
gradients      : float64 (n_samples,)
hessians       : float64 (n_samples,)
sample_indices : int64 (n_sub,) or None
max_bins       : int

Returns
-------
(grad_hist, hess_hist, count_hist) each of shape (n_features, max_bins+1)
)doc");

    m.def("partition_samples_transposed", &partition_samples_transposed,
          "X_T"_a, "sample_indices"_a, "gradients"_a, "hessians"_a,
          "feature"_a, "threshold"_a, "max_bins"_a, "nan_dir"_a,
          R"doc(
Partition samples using transposed X layout (n_features, n_samples).

Accessing feature column col = X_T[feature, :] is L2-cache friendly
(contiguous 50 KB block) vs scattered 5 MB access with row-major layout.

Returns
-------
(left_indices, right_indices, grad_left, hess_left, grad_right, hess_right)
)doc");

    m.def("subtract_histograms_inplace", &subtract_histograms_inplace,
          "parent_grad"_a, "parent_hess"_a, "parent_count"_a,
          "sibling_grad"_a, "sibling_hess"_a, "sibling_count"_a,
          "Subtract sibling histogram from parent IN-PLACE (avoids allocation). "
          "Safe only when parent_hist will not be used again after this call.");

    m.def("subtract_histograms", &subtract_histograms,
          "parent_grad"_a, "parent_hess"_a, "parent_count"_a,
          "sibling_grad"_a, "sibling_hess"_a, "sibling_count"_a,
          R"doc(
Compute child histogram as parent_hist - sibling_hist.

Parameters
----------
parent_grad, parent_hess, parent_count   : float64/int64 (n_features, max_bins+1)
sibling_grad, sibling_hess, sibling_count: float64/int64 (n_features, max_bins+1)

Returns
-------
(grad_diff, hess_diff, count_diff) each of shape (n_features, max_bins+1)
)doc");

    m.def("partition_samples", &partition_samples,
          "X_binned"_a, "sample_indices"_a, "gradients"_a, "hessians"_a,
          "feature"_a, "threshold"_a, "max_bins"_a, "nan_dir"_a,
          R"doc(
Partition sample indices into left/right subsets and compute gradient/hessian sums.

Uses a 2-pass loop: first counts left samples to pre-allocate, then fills
index arrays and accumulates sums in a single pass.

Parameters
----------
X_binned       : uint8 (n_samples, n_features)
sample_indices : int64 (n_sub,)
gradients      : float64 (n_samples,)
hessians       : float64 (n_samples,)
feature        : int  — split feature index
threshold      : int  — bin threshold (samples with bin <= threshold go left)
max_bins       : int  — bin value used for NaN samples
nan_dir        : int  — 0 → NaN goes left, 1 → NaN goes right

Returns
-------
(left_indices, right_indices, grad_left, hess_left, grad_right, hess_right)
)doc");

    m.def("predict_trees", &predict_trees,
          "all_features"_a, "all_thresholds"_a, "all_nan_dirs"_a,
          "all_values"_a, "all_lefts"_a, "all_rights"_a,
          "tree_offsets"_a, "tree_lrs"_a,
          "X_binned"_a, "base_score"_a, "n_trees"_a, "max_bins"_a,
          R"doc(
Batch prediction across all trees using pre-order DFS flat arrays.

Feature indices in tree nodes must already be remapped to absolute column
indices (i.e., col_indices remapping is done in Python before calling this).

Parameters
----------
all_features   : int32 (total_nodes,)
all_thresholds : int32 (total_nodes,)
all_nan_dirs   : int32 (total_nodes,)
all_values     : float64 (total_nodes,)
all_lefts      : int32 (total_nodes,)
all_rights     : int32 (total_nodes,)
tree_offsets   : int32 (n_trees,)  root index of each tree
tree_lrs       : float64 (n_trees,)
X_binned       : uint8 (n_samples, n_features)
base_score     : float64
n_trees        : int
max_bins       : int

Returns
-------
predictions : float64 (n_samples,)
)doc");
}
