from whalesharkboost.objectives.regression import MSEObjective, MAEObjective, HuberObjective
from whalesharkboost.objectives.classification import BinaryLoglossObjective, SoftmaxObjective
from whalesharkboost.objectives.ranking import LambdaRankObjective
from whalesharkboost.objectives.survival import CoxObjective
from whalesharkboost.objectives.quantile import QuantileObjective, CVaRObjective

OBJECTIVE_REGISTRY = {
    "mse": MSEObjective,
    "mae": MAEObjective,
    "huber": HuberObjective,
    "binary_logloss": BinaryLoglossObjective,
    "softmax": SoftmaxObjective,
    "lambdarank": LambdaRankObjective,
    "cox": CoxObjective,
    "quantile": QuantileObjective,
    "cvar": CVaRObjective,
}
