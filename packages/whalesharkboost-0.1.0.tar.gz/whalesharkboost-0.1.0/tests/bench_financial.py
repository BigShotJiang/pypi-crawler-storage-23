"""金融向け設定ベンチマーク: WhaleSharkBoost vs LightGBM.

Numerai スタイルの合成株式リターン予測データで比較:
  - IC / ICIR（スピアマン相関 / そのシャープ比）
  - ワーストエラ IC（ロバスト性）
  - 累積 IC の最大ドローダウン
  - 特徴量露出（過学習指標）

テスト設定:
  1. Baseline  : MSE 目的関数（両者共通）
  2. Spearman  : PB SpearmanObjective vs LightGBM MSE
  3. EraBoost  : PB use_era_boosting vs LightGBM (GOSS の代用)
  4. MaxSharpe : PB MaxSharpeEraObjective vs LightGBM tweedie
  5. DART      : PB use_dart vs LightGBM dart
  6. Exposure  : FeatureExposurePenalizedObjective vs LightGBM L2 reg

Usage:
    python tests/bench_financial.py
"""

import sys, os
_repo_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _repo_root not in sys.path:
    sys.path.insert(0, _repo_root)

import warnings
import time
import numpy as np
import lightgbm as lgb
from sklearn.model_selection import TimeSeriesSplit

from whalesharkboost import WhaleSharkBoostRegressor
from whalesharkboost.core.era_boost import _spearman_corr
from whalesharkboost.objectives.corr import (
    SpearmanObjective, MaxSharpeEraObjective,
    FeatureExposurePenalizedObjective,
)
from whalesharkboost.core.boosting import BoostingEngine

warnings.filterwarnings("ignore")

RANDOM_STATE = 42
rng = np.random.RandomState(RANDOM_STATE)

# ─── 金融データ生成 ──────────────────────────────────────────────────────────

def make_financial_data(
    n_eras=80,
    samples_per_era=300,
    n_features=100,
    n_informative=8,
    signal_strength=0.04,
    feature_corr=0.4,
    fat_tail_df=5,
    random_state=42,
):
    """Numerai スタイルの合成株式リターン予測データ生成。

    特徴:
    - エラ構造（時間軸）
    - 低 S/N 比（金融データの典型）
    - スチューデント t 分布ノイズ（ファットテール）
    - 特徴量間の相関（コリニアリティ）
    - エラをまたぐ緩やかな信号変化（市場レジーム変動）

    Returns
    -------
    X, y, eras : np.ndarray
    """
    rng = np.random.RandomState(random_state)
    n = n_eras * samples_per_era

    # --- 特徴量生成（一部相関あり）---
    # n_informative 個の基底因子 + ノイズ
    factors = rng.randn(n, n_informative)
    loadings = rng.randn(n_informative, n_features) * 0.8
    noise = rng.randn(n, n_features) * np.sqrt(1 - feature_corr)
    X = factors @ loadings * np.sqrt(feature_corr) + noise
    X = (X - X.mean(0)) / (X.std(0) + 1e-8)

    # --- ターゲット生成（低 S/N 比）---
    # エラごとに信号の重みが緩やかに変化（市場レジーム変動）
    era_ids = np.repeat(np.arange(n_eras), samples_per_era)
    signal_weights = rng.randn(n_eras, n_informative) * 0.3  # era-varying weights
    signal_weights += rng.randn(1, n_informative)             # global component

    y_signal = np.zeros(n)
    for e in range(n_eras):
        mask = era_ids == e
        y_signal[mask] = factors[mask] @ signal_weights[e]

    # ファットテール ノイズ（スチューデント t）
    fat_noise = rng.standard_t(df=fat_tail_df, size=n) * np.sqrt((fat_tail_df - 2) / fat_tail_df)
    y = signal_strength * y_signal + fat_noise
    y = y.astype(np.float64)

    return X, y, era_ids


# ─── 金融評価指標 ─────────────────────────────────────────────────────────────

def spearman_ic(y_true, y_pred):
    """スピアマンランク相関（IC）。"""
    return _spearman_corr(y_pred, y_true)


def era_ic(y_true, y_pred, eras):
    """エラごとの IC を計算して返す。"""
    era_labels = np.unique(eras)
    return np.array([
        _spearman_corr(y_pred[eras == e], y_true[eras == e])
        for e in era_labels
    ])


def icir(ics):
    """IC 情報比（IC シャープ比）= mean(IC) / std(IC)。"""
    std = ics.std()
    return float(ics.mean() / (std + 1e-9))


def max_drawdown(ics):
    """累積 IC 系列の最大ドローダウン。"""
    cumsum = np.cumsum(ics)
    running_max = np.maximum.accumulate(cumsum)
    dd = running_max - cumsum
    return float(dd.max())


def feature_exposure(y_pred, X):
    """各特徴量との予測値のスピアマン相関の最大絶対値。"""
    std_P = y_pred.std() + 1e-9
    P_c = y_pred - y_pred.mean()
    exposures = []
    for j in range(X.shape[1]):
        x = X[:, j]
        x_c = x - x.mean()
        corr = float(P_c @ x_c) / (len(y_pred) * std_P * (x.std() + 1e-9))
        exposures.append(abs(corr))
    return float(np.max(exposures)), float(np.mean(exposures))


def rank_normalize(y):
    """ランクを [-1, 1] に正規化。"""
    n = len(y)
    ranks = np.empty(n)
    ranks[np.argsort(y, kind='stable')] = np.arange(n)
    return (ranks / (n - 1)) * 2 - 1


# ─── ベンチマーク設定 ─────────────────────────────────────────────────────────

# LightGBM 基本設定（金融向け）
LGB_BASE = dict(
    n_estimators=500,
    learning_rate=0.02,
    max_depth=5,
    num_leaves=31,
    subsample=0.7,
    colsample_bytree=0.5,
    reg_lambda=1.0,
    reg_alpha=0.0,
    min_child_samples=20,
    max_bin=255,
    random_state=RANDOM_STATE,
    verbose=-1,
)

# WhaleSharkBoost 基本設定（金融向け）
PB_BASE = dict(
    n_estimators=500,
    learning_rate=0.02,
    max_depth=5,
    max_leaves=31,
    subsample=0.7,
    colsample_bytree=0.5,
    reg_lambda=1.0,
    reg_alpha=0.0,
    min_child_samples=20,
    max_bins=255,
    random_state=RANDOM_STATE,
)


# ─── ヘルパー ─────────────────────────────────────────────────────────────────

def _section(title):
    print(f"\n{'═' * 70}")
    print(f"  {title}")
    print(f"{'═' * 70}")


def _metric_row(label, pb_val, lgb_val, higher_is_better=True):
    if higher_is_better:
        better = "PB" if pb_val > lgb_val else "LGB"
        diff = (pb_val - lgb_val) / (abs(lgb_val) + 1e-9) * 100
        sign = "+" if diff > 0 else ""
    else:
        better = "PB" if pb_val < lgb_val else "LGB"
        diff = (lgb_val - pb_val) / (abs(lgb_val) + 1e-9) * 100
        sign = "+" if diff > 0 else ""
    marker = f"  ← {better}  ({sign}{diff:.1f}%)" if abs(diff) > 0.05 else "  ← 同等"
    return f"  {label:<30} PB={pb_val:+.4f}  LGB={lgb_val:+.4f}{marker}"


def evaluate(y_pred, y_true, X_te, eras_te, label=""):
    """金融指標一式を計算して辞書で返す。"""
    ics = era_ic(y_true, y_pred, eras_te)
    fe_max, fe_mean = feature_exposure(y_pred, X_te)
    return {
        "mean_ic":     float(ics.mean()),
        "icir":        icir(ics),
        "worst_ic":    float(ics.min()),
        "max_dd":      max_drawdown(ics),
        "fe_max":      fe_max,
        "fe_mean":     fe_mean,
        "label":       label,
    }


def print_eval(pb_m, lgb_m):
    print(_metric_row("Mean IC (↑ better)",         pb_m["mean_ic"],  lgb_m["mean_ic"],  True))
    print(_metric_row("ICIR = IC Sharpe (↑ better)", pb_m["icir"],     lgb_m["icir"],     True))
    print(_metric_row("Worst-era IC (↑ better)",     pb_m["worst_ic"], lgb_m["worst_ic"], True))
    print(_metric_row("Max Drawdown (↓ better)",     pb_m["max_dd"],   lgb_m["max_dd"],   False))
    print(_metric_row("Feature Exposure max (↓ better)", pb_m["fe_max"], lgb_m["fe_max"], False))
    print(_metric_row("Feature Exposure mean (↓ better)", pb_m["fe_mean"], lgb_m["fe_mean"], False))


# ─── 各設定のベンチマーク ─────────────────────────────────────────────────────

def run_benchmark(name, pb_model, lgb_model, X_tr, y_tr, X_te, y_te,
                  eras_tr, eras_te, pb_fit_kwargs=None, lgb_fit_kwargs=None):
    """モデルを学習・評価し結果を返す。"""
    pb_fit_kwargs  = pb_fit_kwargs  or {}
    lgb_fit_kwargs = lgb_fit_kwargs or {}

    t0 = time.perf_counter()
    pb_model.fit(X_tr, y_tr, **pb_fit_kwargs)
    pb_time = time.perf_counter() - t0

    t0 = time.perf_counter()
    lgb_model.fit(X_tr, y_tr, **lgb_fit_kwargs)
    lgb_time = time.perf_counter() - t0

    pb_pred  = pb_model.predict(X_te)
    lgb_pred = lgb_model.predict(X_te)

    pb_m  = evaluate(pb_pred,  y_te, X_te, eras_te, "WhaleSharkBoost")
    lgb_m = evaluate(lgb_pred, y_te, X_te, eras_te, "LightGBM")

    _section(name)
    print_eval(pb_m, lgb_m)
    print(f"\n  訓練時間  PB={pb_time:.1f}s  LGB={lgb_time:.1f}s"
          f"  (PB/LGB 比: {pb_time/lgb_time:.2f}x)")

    return pb_m, lgb_m


# ─── メイン ──────────────────────────────────────────────────────────────────

def main():
    import whalesharkboost
    print("=" * 70)
    print("  WhaleSharkBoost vs LightGBM — 金融向け設定ベンチマーク")
    print(f"  WhaleSharkBoost : {whalesharkboost.__version__}")
    print(f"  LightGBM     : {lgb.__version__}")
    print("=" * 70)

    # ── データ生成 ─────────────────────────────────────────────────────────
    print("\nデータ生成中 (Numerai スタイル合成株式データ)...")
    X, y, eras = make_financial_data(
        n_eras=100,
        samples_per_era=300,
        n_features=100,
        n_informative=8,
        signal_strength=0.05,
        fat_tail_df=5,
        random_state=RANDOM_STATE,
    )
    n_total = len(y)

    # 時系列分割（末尾 20 エラをテスト）
    test_eras = 20
    train_mask = eras < (100 - test_eras)
    test_mask  = eras >= (100 - test_eras)

    X_tr, X_te = X[train_mask], X[test_mask]
    y_tr, y_te = y[train_mask], y[test_mask]
    eras_tr, eras_te = eras[train_mask], eras[test_mask]

    print(f"  訓練: {train_mask.sum():,} サンプル ({(~test_mask).sum()//300} エラ)")
    print(f"  テスト: {test_mask.sum():,} サンプル ({test_eras} エラ)")
    print(f"  特徴量: {X.shape[1]}, 全体 IC 上限: ~{0.05:.2f}")

    all_results = {}

    # ── 1. Baseline: MSE 目的関数 ──────────────────────────────────────────
    pb_base = WhaleSharkBoostRegressor(**PB_BASE)
    lgb_base = lgb.LGBMRegressor(**LGB_BASE)
    pb_m, lgb_m = run_benchmark(
        "1. Baseline — MSE 目的関数 (両者共通)",
        pb_base, lgb_base, X_tr, y_tr, X_te, y_te, eras_tr, eras_te,
    )
    all_results["Baseline MSE"] = (pb_m, lgb_m)

    # ── 2. Spearman 目的関数 ──────────────────────────────────────────────
    # WhaleSharkBoost: SpearmanObjective（ランク相関直接最適化）
    # LightGBM   : ランクターゲット MSE（手動変換）
    _section("2. Spearman 目的関数")
    print("  PB: SpearmanObjective  |  LGB: ランク正規化ターゲット MSE")

    # WhaleSharkBoost: カスタム目的関数を BoostingEngine 経由で使用
    from whalesharkboost.core.boosting import BoostingEngine
    spearman_engine = BoostingEngine(
        n_estimators=PB_BASE["n_estimators"],
        learning_rate=PB_BASE["learning_rate"],
        max_depth=PB_BASE["max_depth"],
        max_leaves=PB_BASE["max_leaves"],
        subsample=PB_BASE["subsample"],
        colsample_bytree=PB_BASE["colsample_bytree"],
        reg_lambda=PB_BASE["reg_lambda"],
        min_child_samples=PB_BASE["min_child_samples"],
        max_bins=PB_BASE["max_bins"],
        random_state=RANDOM_STATE,
    )
    spearman_obj = SpearmanObjective(corr_correction=0.5)

    t0 = time.perf_counter()
    spearman_engine.fit(X_tr, y_tr, spearman_obj)
    pb_spearman_time = time.perf_counter() - t0

    # LightGBM: ランクターゲット MSE（LightGBM に Spearman 目的なし）
    y_tr_rank = rank_normalize(y_tr)  # ランク正規化ターゲット
    lgb_spearman = lgb.LGBMRegressor(**LGB_BASE)
    t0 = time.perf_counter()
    lgb_spearman.fit(X_tr, y_tr_rank)
    lgb_spearman_time = time.perf_counter() - t0

    pb_pred_sp  = spearman_engine.predict(X_te)
    lgb_pred_sp = lgb_spearman.predict(X_te)
    pb_m_sp  = evaluate(pb_pred_sp,  y_te, X_te, eras_te)
    lgb_m_sp = evaluate(lgb_pred_sp, y_te, X_te, eras_te)
    print_eval(pb_m_sp, lgb_m_sp)
    print(f"\n  訓練時間  PB={pb_spearman_time:.1f}s  LGB={lgb_spearman_time:.1f}s")
    all_results["Spearman"] = (pb_m_sp, lgb_m_sp)

    # ── 3. エラブースティング ──────────────────────────────────────────────
    pb_era = WhaleSharkBoostRegressor(
        **PB_BASE,
        use_era_boosting=True,
        era_boosting_method="sharpe_reweight",
        era_boosting_temp=1.0,
    )
    # LightGBM: GOSS（勾配ベースサンプリング）を代替として使用
    lgb_goss = lgb.LGBMRegressor(**{**LGB_BASE, "boosting_type": "goss"})

    pb_m_era, lgb_m_era = run_benchmark(
        "3. エラブースティング (PB) vs GOSS (LGB)",
        pb_era, lgb_goss,
        X_tr, y_tr, X_te, y_te, eras_tr, eras_te,
        pb_fit_kwargs={"era_indices": eras_tr},
    )
    all_results["EraBoost"] = (pb_m_era, lgb_m_era)

    # ── 4. MaxSharpe エラ目的関数 ─────────────────────────────────────────
    _section("4. MaxSharpeEraObjective (PB) vs DART (LGB)")
    print("  PB: MaxSharpe エラ目的関数（エラ IC のシャープ比最大化）")
    print("  LGB: DART ブースティング（ドロップアウト正則化）")

    maxsharpe_engine = BoostingEngine(
        n_estimators=PB_BASE["n_estimators"],
        learning_rate=PB_BASE["learning_rate"],
        max_depth=PB_BASE["max_depth"],
        max_leaves=PB_BASE["max_leaves"],
        subsample=PB_BASE["subsample"],
        colsample_bytree=PB_BASE["colsample_bytree"],
        reg_lambda=PB_BASE["reg_lambda"],
        min_child_samples=PB_BASE["min_child_samples"],
        max_bins=PB_BASE["max_bins"],
        random_state=RANDOM_STATE,
    )
    ms_obj = MaxSharpeEraObjective()
    ms_obj.set_era_indices(eras_tr)

    t0 = time.perf_counter()
    maxsharpe_engine.fit(X_tr, y_tr, ms_obj)
    pb_ms_time = time.perf_counter() - t0

    lgb_dart = lgb.LGBMRegressor(**{**LGB_BASE, "boosting_type": "dart",
                                     "drop_rate": 0.1, "skip_drop": 0.5})
    t0 = time.perf_counter()
    lgb_dart.fit(X_tr, y_tr)
    lgb_dart_time = time.perf_counter() - t0

    pb_pred_ms  = maxsharpe_engine.predict(X_te)
    lgb_pred_dart = lgb_dart.predict(X_te)
    pb_m_ms  = evaluate(pb_pred_ms,  y_te, X_te, eras_te)
    lgb_m_ms = evaluate(lgb_pred_dart, y_te, X_te, eras_te)
    print_eval(pb_m_ms, lgb_m_ms)
    print(f"\n  訓練時間  PB={pb_ms_time:.1f}s  LGB={lgb_dart_time:.1f}s")
    all_results["MaxSharpe"] = (pb_m_ms, lgb_m_ms)

    # ── 5. DART ブースティング ─────────────────────────────────────────────
    pb_dart = WhaleSharkBoostRegressor(
        **PB_BASE,
        use_dart=True,
        dart_drop_rate=0.1,
        dart_skip_drop=0.5,
    )
    lgb_dart2 = lgb.LGBMRegressor(**{**LGB_BASE, "boosting_type": "dart",
                                      "drop_rate": 0.1, "skip_drop": 0.5})
    pb_m_dart, lgb_m_dart = run_benchmark(
        "5. DART ブースティング (両者)",
        pb_dart, lgb_dart2, X_tr, y_tr, X_te, y_te, eras_tr, eras_te,
    )
    all_results["DART"] = (pb_m_dart, lgb_m_dart)

    # ── 6. 特徴量露出ペナルティ ──────────────────────────────────────────────
    _section("6. 特徴量露出ペナルティ (PB) vs 強正則化 (LGB)")
    print("  PB: FeatureExposurePenalizedObjective（予測値-特徴量相関ペナルティ）")
    print("  LGB: 高強度 L2 正則化（reg_lambda=10）")

    fe_engine = BoostingEngine(
        n_estimators=PB_BASE["n_estimators"],
        learning_rate=PB_BASE["learning_rate"],
        max_depth=PB_BASE["max_depth"],
        max_leaves=PB_BASE["max_leaves"],
        subsample=PB_BASE["subsample"],
        colsample_bytree=PB_BASE["colsample_bytree"],
        reg_lambda=PB_BASE["reg_lambda"],
        min_child_samples=PB_BASE["min_child_samples"],
        max_bins=PB_BASE["max_bins"],
        random_state=RANDOM_STATE,
    )
    spearman_base = SpearmanObjective(corr_correction=0.3)
    fe_obj = FeatureExposurePenalizedObjective(
        base_objective=spearman_base,
        X_ref=X_tr,
        lambda_fe=0.3,
    )
    t0 = time.perf_counter()
    fe_engine.fit(X_tr, y_tr, fe_obj)
    pb_fe_time = time.perf_counter() - t0

    lgb_fe = lgb.LGBMRegressor(**{**LGB_BASE, "reg_lambda": 10.0})
    t0 = time.perf_counter()
    lgb_fe.fit(X_tr, y_tr_rank)
    lgb_fe_time = time.perf_counter() - t0

    pb_pred_fe  = fe_engine.predict(X_te)
    lgb_pred_fe = lgb_fe.predict(X_te)
    pb_m_fe  = evaluate(pb_pred_fe,  y_te, X_te, eras_te)
    lgb_m_fe = evaluate(lgb_pred_fe, y_te, X_te, eras_te)
    print_eval(pb_m_fe, lgb_m_fe)
    print(f"\n  訓練時間  PB={pb_fe_time:.1f}s  LGB={lgb_fe_time:.1f}s")
    all_results["FeatureExposure"] = (pb_m_fe, lgb_m_fe)

    # ── 総合サマリー ─────────────────────────────────────────────────────
    _section("総合サマリー — 金融向け設定別 IC・ICIR 比較")

    print(f"\n  {'設定':<28} {'PB IC':>8} {'LGB IC':>8}  {'PB ICIR':>8} {'LGB ICIR':>8}  "
          f"{'PB DD':>8} {'LGB DD':>8}  {'PB FE':>8} {'LGB FE':>8}  {'勝者':>8}")
    print(f"  {'─'*108}")

    pb_wins = 0; lgb_wins = 0
    for name_r, (pb_m, lgb_m) in all_results.items():
        pb_ic, lgb_ic   = pb_m["mean_ic"], lgb_m["mean_ic"]
        pb_ir, lgb_ir   = pb_m["icir"],    lgb_m["icir"]
        pb_dd, lgb_dd   = pb_m["max_dd"],  lgb_m["max_dd"]
        pb_fe, lgb_fe_v = pb_m["fe_max"],  lgb_m["fe_max"]

        # 勝者判定: IC + ICIR が主要指標
        pb_score  = (pb_ic > lgb_ic) + (pb_ir > lgb_ir)
        lgb_score = (lgb_ic > pb_ic) + (lgb_ir > pb_ir)
        if pb_score > lgb_score:
            winner = "PB"; pb_wins += 1
        elif lgb_score > pb_score:
            winner = "LGB"; lgb_wins += 1
        else:
            winner = "引き分け"

        print(f"  {name_r:<28} "
              f"{pb_ic:>+8.4f} {lgb_ic:>+8.4f}  "
              f"{pb_ir:>8.3f} {lgb_ir:>8.3f}  "
              f"{pb_dd:>8.3f} {lgb_dd:>8.3f}  "
              f"{pb_fe:>8.4f} {lgb_fe_v:>8.4f}  "
              f"{winner:>8}")

    print(f"\n{'═'*70}")
    print(f"  最終スコア   WhaleSharkBoost 勝利: {pb_wins}  LightGBM 勝利: {lgb_wins}")
    print(f"{'═'*70}")

    # ── 解説 ────────────────────────────────────────────────────────────
    _section("結果の解釈")
    print("""
  IC (Information Coefficient):
    スピアマンランク相関。金融では IC > 0.02 が実用レベルとされる。

  ICIR (IC Information Ratio):
    IC の平均 / 標準偏差。シャープ比の類似物。
    高い ICIR = 安定した予測 = 実運用で重要。

  Worst-era IC:
    最悪エラの IC。市場レジーム変動への耐性を測る。
    WhaleSharkBoost のエラブースティングはこの指標の改善を狙う。

  Max Drawdown:
    累積 IC の最大ドローダウン。連続損失期間の長さ。

  Feature Exposure (最大 |corr(予測値, 特徴量)|):
    予測値が特定の特徴量に説明される度合い。低いほど過学習リスクが小さい。
    WhaleSharkBoost の FeatureExposurePenalizedObjective はこれを直接制御する。
""")


if __name__ == "__main__":
    main()
