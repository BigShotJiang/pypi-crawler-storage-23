"""Accuracy benchmark: WhaleSharkBoost vs LightGBM.

Tests predictive accuracy across multiple task types and datasets:
  - Regression (MSE / MAE objectives)
  - Binary classification
  - Multiclass classification
  - Quantile regression

Usage:
    python tests/bench_accuracy_vs_lightgbm.py
    # or from repo root:
    PYTHONPATH=. python tests/bench_accuracy_vs_lightgbm.py
"""

import sys, os
# Ensure the repo root is on sys.path so whalesharkboost is importable
# whether this script is run directly or from the repo root.
_repo_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _repo_root not in sys.path:
    sys.path.insert(0, _repo_root)

import warnings
import numpy as np
import lightgbm as lgb
from sklearn.datasets import (
    make_regression, make_classification,
    fetch_california_housing, load_breast_cancer, load_wine, load_digits,
)
from sklearn.model_selection import KFold, StratifiedKFold
from sklearn.metrics import (
    mean_squared_error, mean_absolute_error, r2_score,
    accuracy_score, roc_auc_score, log_loss, f1_score,
)
from sklearn.preprocessing import StandardScaler

from whalesharkboost import WhaleSharkBoostRegressor, WhaleSharkBoostClassifier
from whalesharkboost.sklearn_api import WhaleSharkBoostQuantileRegressor

warnings.filterwarnings("ignore")

RANDOM_STATE = 42
N_FOLDS = 5

# ─── Common hyper-parameters (matched as closely as possible) ─────────────────
COMMON = dict(
    n_estimators=300,
    learning_rate=0.05,
    max_depth=6,
    max_leaves=31,
    reg_lambda=1.0,
    max_bins=255,
    random_state=RANDOM_STATE,
)

PB_COMMON  = dict(**COMMON)
LGB_COMMON = dict(
    n_estimators=COMMON["n_estimators"],
    learning_rate=COMMON["learning_rate"],
    max_depth=COMMON["max_depth"],
    num_leaves=COMMON["max_leaves"],
    reg_lambda=COMMON["reg_lambda"],
    max_bin=COMMON["max_bins"],
    random_state=RANDOM_STATE,
    verbose=-1,
)

# ─── Metric helpers ────────────────────────────────────────────────────────────

def rmse(y, p):
    return np.sqrt(mean_squared_error(y, p))

def mae(y, p):
    return mean_absolute_error(y, p)

def pinball(y, p, alpha):
    """Pinball (quantile) loss."""
    err = y - p
    return np.mean(np.where(err >= 0, alpha * err, (alpha - 1) * err))

def coverage(y, lo, hi):
    """Fraction of y inside [lo, hi] interval."""
    return np.mean((y >= lo) & (y <= hi))

# ─── Display helpers ───────────────────────────────────────────────────────────

SEP = "─" * 72

def _section(title):
    print(f"\n{'═' * 72}")
    print(f"  {title}")
    print(f"{'═' * 72}")

def _row(label, pb, lgb, unit="", lower_is_better=True):
    if lower_is_better:
        ratio = pb / lgb if lgb > 0 else float("inf")
        winner = "LightGBM" if pb > lgb else "WhaleSharkBoost"
        marker = f"  ← {winner} better  (PB/LGB ratio: {ratio:.3f})"
    else:
        ratio = lgb / pb if pb > 0 else float("inf")
        winner = "WhaleSharkBoost" if pb > lgb else "LightGBM"
        marker = f"  ← {winner} better  (LGB/PB ratio: {ratio:.3f})"
    return f"  {label:<28} PB={pb:8.4f}  LGB={lgb:8.4f}{unit}{marker}"

# ─── Cross-validated accuracy runner ─────────────────────────────────────────

def cv_regression(name, X, y, pb_extra=None, lgb_extra=None, n_folds=N_FOLDS):
    """Run K-fold CV for a regression task, return mean metrics."""
    pb_extra  = pb_extra  or {}
    lgb_extra = lgb_extra or {}

    pb_rmse_scores, pb_mae_scores, pb_r2_scores = [], [], []
    lgb_rmse_scores, lgb_mae_scores, lgb_r2_scores = [], [], []

    kf = KFold(n_splits=n_folds, shuffle=True, random_state=RANDOM_STATE)
    for fold, (tr, te) in enumerate(kf.split(X)):
        X_tr, X_te = X[tr], X[te]
        y_tr, y_te = y[tr], y[te]

        # WhaleSharkBoost
        pb = WhaleSharkBoostRegressor(**{**PB_COMMON, **pb_extra})
        pb.fit(X_tr, y_tr)
        pb_p = pb.predict(X_te)
        pb_rmse_scores.append(rmse(y_te, pb_p))
        pb_mae_scores.append(mae(y_te, pb_p))
        pb_r2_scores.append(r2_score(y_te, pb_p))

        # LightGBM
        lgbm = lgb.LGBMRegressor(**{**LGB_COMMON, **lgb_extra})
        lgbm.fit(X_tr, y_tr)
        lgb_p = lgbm.predict(X_te)
        lgb_rmse_scores.append(rmse(y_te, lgb_p))
        lgb_mae_scores.append(mae(y_te, lgb_p))
        lgb_r2_scores.append(r2_score(y_te, lgb_p))

    return {
        "name": name,
        "task": "regression",
        "pb_rmse":  np.mean(pb_rmse_scores),
        "pb_mae":   np.mean(pb_mae_scores),
        "pb_r2":    np.mean(pb_r2_scores),
        "lgb_rmse": np.mean(lgb_rmse_scores),
        "lgb_mae":  np.mean(lgb_mae_scores),
        "lgb_r2":   np.mean(lgb_r2_scores),
        "pb_rmse_std":  np.std(pb_rmse_scores),
        "lgb_rmse_std": np.std(lgb_rmse_scores),
    }


def cv_binary(name, X, y, n_folds=N_FOLDS):
    """Run K-fold stratified CV for binary classification."""
    pb_acc, pb_auc, pb_ll = [], [], []
    lgb_acc, lgb_auc, lgb_ll = [], [], []

    skf = StratifiedKFold(n_splits=n_folds, shuffle=True, random_state=RANDOM_STATE)
    for fold, (tr, te) in enumerate(skf.split(X, y)):
        X_tr, X_te = X[tr], X[te]
        y_tr, y_te = y[tr], y[te]

        # WhaleSharkBoost
        pb = WhaleSharkBoostClassifier(**PB_COMMON)
        pb.fit(X_tr, y_tr)
        pb_labels = pb.predict(X_te)
        pb_proba  = pb.predict_proba(X_te)[:, 1]
        pb_acc.append(accuracy_score(y_te, pb_labels))
        pb_auc.append(roc_auc_score(y_te, pb_proba))
        pb_ll.append(log_loss(y_te, pb_proba))

        # LightGBM
        lgbm = lgb.LGBMClassifier(**LGB_COMMON)
        lgbm.fit(X_tr, y_tr)
        lgb_labels = lgbm.predict(X_te)
        lgb_proba  = lgbm.predict_proba(X_te)[:, 1]
        lgb_acc.append(accuracy_score(y_te, lgb_labels))
        lgb_auc.append(roc_auc_score(y_te, lgb_proba))
        lgb_ll.append(log_loss(y_te, lgb_proba))

    return {
        "name": name,
        "task": "binary_clf",
        "pb_acc":  np.mean(pb_acc),  "pb_auc":  np.mean(pb_auc),  "pb_ll":  np.mean(pb_ll),
        "lgb_acc": np.mean(lgb_acc), "lgb_auc": np.mean(lgb_auc), "lgb_ll": np.mean(lgb_ll),
    }


def cv_multiclass(name, X, y, n_folds=N_FOLDS):
    """Run K-fold stratified CV for multiclass classification."""
    n_cls = len(np.unique(y))
    pb_acc, pb_f1, pb_ll = [], [], []
    lgb_acc, lgb_f1, lgb_ll = [], [], []

    skf = StratifiedKFold(n_splits=n_folds, shuffle=True, random_state=RANDOM_STATE)
    for fold, (tr, te) in enumerate(skf.split(X, y)):
        X_tr, X_te = X[tr], X[te]
        y_tr, y_te = y[tr], y[te]

        # WhaleSharkBoost
        pb = WhaleSharkBoostClassifier(**PB_COMMON)
        pb.fit(X_tr, y_tr)
        pb_labels = pb.predict(X_te)
        pb_proba  = pb.predict_proba(X_te)
        pb_acc.append(accuracy_score(y_te, pb_labels))
        pb_f1.append(f1_score(y_te, pb_labels, average="macro", zero_division=0))
        pb_ll.append(log_loss(y_te, pb_proba, labels=np.arange(n_cls)))

        # LightGBM
        lgbm = lgb.LGBMClassifier(**LGB_COMMON)
        lgbm.fit(X_tr, y_tr)
        lgb_labels = lgbm.predict(X_te)
        lgb_proba  = lgbm.predict_proba(X_te)
        lgb_acc.append(accuracy_score(y_te, lgb_labels))
        lgb_f1.append(f1_score(y_te, lgb_labels, average="macro", zero_division=0))
        lgb_ll.append(log_loss(y_te, lgb_proba, labels=np.arange(n_cls)))

    return {
        "name": name,
        "task": "multiclass_clf",
        "n_classes": n_cls,
        "pb_acc":  np.mean(pb_acc),  "pb_f1":  np.mean(pb_f1),  "pb_ll":  np.mean(pb_ll),
        "lgb_acc": np.mean(lgb_acc), "lgb_f1": np.mean(lgb_f1), "lgb_ll": np.mean(lgb_ll),
    }


def cv_quantile(name, X, y, alphas=(0.1, 0.5, 0.9), n_folds=N_FOLDS):
    """Run K-fold CV for quantile regression at multiple alpha levels."""
    results = {}
    for alpha in alphas:
        pb_pl, lgb_pl = [], []
        kf = KFold(n_splits=n_folds, shuffle=True, random_state=RANDOM_STATE)
        for fold, (tr, te) in enumerate(kf.split(X)):
            X_tr, X_te = X[tr], X[te]
            y_tr, y_te = y[tr], y[te]

            # WhaleSharkBoost
            pb = WhaleSharkBoostQuantileRegressor(
                alpha=alpha,
                **{k: v for k, v in PB_COMMON.items()
                   if k not in ("random_state",)},
                random_state=RANDOM_STATE,
            )
            pb.fit(X_tr, y_tr)
            pb_p = pb.predict(X_te)
            pb_pl.append(pinball(y_te, pb_p, alpha))

            # LightGBM quantile mode
            lgbm = lgb.LGBMRegressor(
                objective="quantile",
                alpha=alpha,
                **LGB_COMMON,
            )
            lgbm.fit(X_tr, y_tr)
            lgb_p = lgbm.predict(X_te)
            lgb_pl.append(pinball(y_te, lgb_p, alpha))

        results[alpha] = {
            "pb":  np.mean(pb_pl),
            "lgb": np.mean(lgb_pl),
        }

    # also compute 80% prediction interval coverage (alpha=0.1 lower, 0.9 upper)
    cov_pb, cov_lgb = [], []
    kf = KFold(n_splits=n_folds, shuffle=True, random_state=RANDOM_STATE)
    for fold, (tr, te) in enumerate(kf.split(X)):
        X_tr, X_te = X[tr], X[te]
        y_tr, y_te = y[tr], y[te]

        lo_pb = WhaleSharkBoostQuantileRegressor(
            alpha=0.1, **{k: v for k, v in PB_COMMON.items() if k != "random_state"},
            random_state=RANDOM_STATE).fit(X_tr, y_tr).predict(X_te)
        hi_pb = WhaleSharkBoostQuantileRegressor(
            alpha=0.9, **{k: v for k, v in PB_COMMON.items() if k != "random_state"},
            random_state=RANDOM_STATE).fit(X_tr, y_tr).predict(X_te)
        cov_pb.append(coverage(y_te, lo_pb, hi_pb))

        lo_lgb = lgb.LGBMRegressor(
            objective="quantile", alpha=0.1, **LGB_COMMON).fit(X_tr, y_tr).predict(X_te)
        hi_lgb = lgb.LGBMRegressor(
            objective="quantile", alpha=0.9, **LGB_COMMON).fit(X_tr, y_tr).predict(X_te)
        cov_lgb.append(coverage(y_te, lo_lgb, hi_lgb))

    return {
        "name": name,
        "task": "quantile",
        "alphas": results,
        "pb_coverage":  np.mean(cov_pb),
        "lgb_coverage": np.mean(cov_lgb),
    }


# ─── Print result helpers ─────────────────────────────────────────────────────

def print_regression(r):
    _section(f"REGRESSION — {r['name']}")
    print(_row("RMSE  (↓ better)", r["pb_rmse"],  r["lgb_rmse"],  lower_is_better=True))
    print(_row("MAE   (↓ better)", r["pb_mae"],   r["lgb_mae"],   lower_is_better=True))
    print(_row("R²    (↑ better)", r["pb_r2"],    r["lgb_r2"],    lower_is_better=False))
    print(f"  {'RMSE std (5-fold)':<28} PB=±{r['pb_rmse_std']:.4f}  LGB=±{r['lgb_rmse_std']:.4f}")


def print_binary(r):
    _section(f"BINARY CLASSIFICATION — {r['name']}")
    print(_row("Accuracy  (↑ better)", r["pb_acc"],  r["lgb_acc"],  lower_is_better=False))
    print(_row("ROC-AUC   (↑ better)", r["pb_auc"],  r["lgb_auc"],  lower_is_better=False))
    print(_row("Log-loss  (↓ better)", r["pb_ll"],   r["lgb_ll"],   lower_is_better=True))


def print_multiclass(r):
    _section(f"MULTICLASS CLASSIFICATION — {r['name']} ({r['n_classes']} classes)")
    print(_row("Accuracy    (↑ better)", r["pb_acc"],  r["lgb_acc"],  lower_is_better=False))
    print(_row("Macro-F1    (↑ better)", r["pb_f1"],   r["lgb_f1"],   lower_is_better=False))
    print(_row("Log-loss    (↓ better)", r["pb_ll"],   r["lgb_ll"],   lower_is_better=True))


def print_quantile(r):
    _section(f"QUANTILE REGRESSION — {r['name']}")
    for alpha, m in sorted(r["alphas"].items()):
        label = f"Pinball α={alpha:.1f} (↓ better)"
        print(_row(label, m["pb"], m["lgb"], lower_is_better=True))
    print(_row("80% PI Coverage (→0.80)", r["pb_coverage"], r["lgb_coverage"],
               lower_is_better=False))
    print(f"  {'(ideal = 0.80)'}")


# ─── Summary table ────────────────────────────────────────────────────────────

def print_summary(reg_results, bin_results, multi_results, quant_results):
    _section("FULL ACCURACY SUMMARY")

    print(f"\n{'─'*72}")
    print("  REGRESSION  (5-fold CV, mean ± std RMSE)")
    print(f"  {'Dataset':<30} {'PB RMSE':>10} {'LGB RMSE':>10}  {'R² PB':>7} {'R² LGB':>7}  {'Winner':>12}")
    print(f"  {'─'*68}")
    for r in reg_results:
        winner = "WhaleSharkBoost" if r["pb_rmse"] < r["lgb_rmse"] else "LightGBM"
        print(f"  {r['name']:<30} {r['pb_rmse']:>10.4f} {r['lgb_rmse']:>10.4f}  "
              f"{r['pb_r2']:>7.4f} {r['lgb_r2']:>7.4f}  {winner:>12}")

    print(f"\n{'─'*72}")
    print("  BINARY CLASSIFICATION  (5-fold CV)")
    print(f"  {'Dataset':<30} {'PB AUC':>9} {'LGB AUC':>9}  {'PB Acc':>7} {'LGB Acc':>7}  {'Winner':>12}")
    print(f"  {'─'*68}")
    for r in bin_results:
        winner = "WhaleSharkBoost" if r["pb_auc"] > r["lgb_auc"] else "LightGBM"
        print(f"  {r['name']:<30} {r['pb_auc']:>9.4f} {r['lgb_auc']:>9.4f}  "
              f"{r['pb_acc']:>7.4f} {r['lgb_acc']:>7.4f}  {winner:>12}")

    print(f"\n{'─'*72}")
    print("  MULTICLASS CLASSIFICATION  (5-fold CV)")
    print(f"  {'Dataset':<30} {'PB Acc':>8} {'LGB Acc':>8}  {'PB F1':>7} {'LGB F1':>7}  {'Winner':>12}")
    print(f"  {'─'*68}")
    for r in multi_results:
        winner = "WhaleSharkBoost" if r["pb_acc"] > r["lgb_acc"] else "LightGBM"
        print(f"  {r['name']:<30} {r['pb_acc']:>8.4f} {r['lgb_acc']:>8.4f}  "
              f"{r['pb_f1']:>7.4f} {r['lgb_f1']:>7.4f}  {winner:>12}")

    print(f"\n{'─'*72}")
    print("  QUANTILE REGRESSION  (5-fold CV, median α=0.5 pinball loss)")
    print(f"  {'Dataset':<30} {'PB p50':>9} {'LGB p50':>9}  {'PB cov':>8} {'LGB cov':>8}  {'Winner':>12}")
    print(f"  {'─'*68}")
    for r in quant_results:
        pb_p50  = r["alphas"][0.5]["pb"]
        lgb_p50 = r["alphas"][0.5]["lgb"]
        winner = "WhaleSharkBoost" if pb_p50 < lgb_p50 else "LightGBM"
        print(f"  {r['name']:<30} {pb_p50:>9.4f} {lgb_p50:>9.4f}  "
              f"{r['pb_coverage']:>8.4f} {r['lgb_coverage']:>8.4f}  {winner:>12}")

    # Overall tally
    all_results = reg_results + bin_results + multi_results + quant_results
    pb_wins = 0
    lgb_wins = 0
    for r in reg_results:
        if r["pb_rmse"] < r["lgb_rmse"]:
            pb_wins += 1
        else:
            lgb_wins += 1
    for r in bin_results:
        if r["pb_auc"] > r["lgb_auc"]:
            pb_wins += 1
        else:
            lgb_wins += 1
    for r in multi_results:
        if r["pb_acc"] > r["lgb_acc"]:
            pb_wins += 1
        else:
            lgb_wins += 1
    for r in quant_results:
        if r["alphas"][0.5]["pb"] < r["alphas"][0.5]["lgb"]:
            pb_wins += 1
        else:
            lgb_wins += 1

    total = pb_wins + lgb_wins
    print(f"\n{'═'*72}")
    print(f"  OVERALL SCORE  (primary metric per task)")
    print(f"  WhaleSharkBoost wins: {pb_wins}/{total}")
    print(f"  LightGBM wins:     {lgb_wins}/{total}")
    print(f"{'═'*72}")


# ─── Datasets ─────────────────────────────────────────────────────────────────

def load_datasets():
    datasets = {}

    # --- Regression ---
    rng = np.random.RandomState(RANDOM_STATE)

    # Synthetic regression (medium difficulty)
    X_syn, y_syn = make_regression(
        n_samples=20_000, n_features=30, n_informative=15,
        noise=15.0, random_state=RANDOM_STATE)
    datasets["reg_synthetic"] = (X_syn, y_syn)

    # California housing (real-world, heteroscedastic)
    cal = fetch_california_housing()
    datasets["reg_california"] = (cal.data, cal.target)

    # --- Binary classification ---
    # Synthetic (moderate overlap)
    X_bc, y_bc = make_classification(
        n_samples=15_000, n_features=20, n_informative=10,
        n_redundant=4, flip_y=0.05, random_state=RANDOM_STATE)
    datasets["bin_synthetic"] = (X_bc, y_bc)

    # Breast cancer (real, 30 features, 2 classes)
    bc = load_breast_cancer()
    datasets["bin_breast_cancer"] = (bc.data, bc.target)

    # --- Multiclass classification ---
    # Synthetic 5-class
    X_mc5, y_mc5 = make_classification(
        n_samples=10_000, n_features=20, n_informative=12,
        n_redundant=2, n_classes=5, n_clusters_per_class=1,
        random_state=RANDOM_STATE)
    datasets["multi_synthetic_5cls"] = (X_mc5, y_mc5)

    # Wine dataset (13 features, 3 classes)
    wine = load_wine()
    datasets["multi_wine"] = (wine.data, wine.target)

    # Digits (64 features, 10 classes)
    digits = load_digits()
    datasets["multi_digits"] = (digits.data, digits.target)

    # --- Quantile regression ---
    # Synthetic heteroscedastic (variance grows with X)
    n = 10_000
    X_q = rng.randn(n, 10)
    noise_scale = 1.0 + 2.0 * np.abs(X_q[:, 0])
    y_q = X_q[:, 0] * 3 + X_q[:, 1] * 2 + rng.randn(n) * noise_scale
    datasets["quant_heteroscedastic"] = (X_q, y_q)

    # California housing for quantile (real-world, skewed)
    datasets["quant_california"] = (cal.data, cal.target)

    return datasets


# ─── Main ─────────────────────────────────────────────────────────────────────

def main():
    import whalesharkboost
    print("=" * 72)
    print("  WhaleSharkBoost vs LightGBM — Accuracy Benchmark")
    print(f"  WhaleSharkBoost version : {whalesharkboost.__version__}")
    print(f"  LightGBM version     : {lgb.__version__}")
    print(f"  Cross-validation     : {N_FOLDS}-fold")
    print(f"  n_estimators         : {COMMON['n_estimators']}")
    print(f"  learning_rate        : {COMMON['learning_rate']}")
    print(f"  max_depth            : {COMMON['max_depth']}")
    print(f"  max_leaves           : {COMMON['max_leaves']}")
    print("=" * 72)

    print("\nLoading datasets...")
    datasets = load_datasets()

    reg_results   = []
    bin_results   = []
    multi_results = []
    quant_results = []

    # ── Regression ──────────────────────────────────────────────────────────
    print("\n[1/4] Running REGRESSION benchmarks...")
    r = cv_regression("Synthetic (n=20k, f=30)", *datasets["reg_synthetic"])
    print_regression(r);  reg_results.append(r)

    r = cv_regression("California Housing (n=20k, f=8)", *datasets["reg_california"])
    print_regression(r);  reg_results.append(r)

    # MAE objective
    r = cv_regression(
        "Synthetic — MAE objective",
        *datasets["reg_synthetic"],
        pb_extra={"objective": "mae"},
        lgb_extra={"objective": "mean_absolute_error"})
    print_regression(r);  reg_results.append(r)

    # ── Binary classification ────────────────────────────────────────────────
    print("\n[2/4] Running BINARY CLASSIFICATION benchmarks...")
    r = cv_binary("Synthetic (n=15k, f=20)", *datasets["bin_synthetic"])
    print_binary(r);  bin_results.append(r)

    r = cv_binary("Breast Cancer (n=569, f=30)", *datasets["bin_breast_cancer"])
    print_binary(r);  bin_results.append(r)

    # ── Multiclass classification ────────────────────────────────────────────
    print("\n[3/4] Running MULTICLASS CLASSIFICATION benchmarks...")
    r = cv_multiclass("Synthetic 5-class (n=10k, f=20)", *datasets["multi_synthetic_5cls"])
    print_multiclass(r);  multi_results.append(r)

    r = cv_multiclass("Wine (n=178, f=13, 3 cls)", *datasets["multi_wine"])
    print_multiclass(r);  multi_results.append(r)

    r = cv_multiclass("Digits (n=1797, f=64, 10 cls)", *datasets["multi_digits"])
    print_multiclass(r);  multi_results.append(r)

    # ── Quantile regression ──────────────────────────────────────────────────
    print("\n[4/4] Running QUANTILE REGRESSION benchmarks...")
    r = cv_quantile("Heteroscedastic (n=10k, f=10)", *datasets["quant_heteroscedastic"])
    print_quantile(r);  quant_results.append(r)

    r = cv_quantile("California Housing (n=20k, f=8)", *datasets["quant_california"])
    print_quantile(r);  quant_results.append(r)

    # ── Summary ──────────────────────────────────────────────────────────────
    print_summary(reg_results, bin_results, multi_results, quant_results)


if __name__ == "__main__":
    main()
