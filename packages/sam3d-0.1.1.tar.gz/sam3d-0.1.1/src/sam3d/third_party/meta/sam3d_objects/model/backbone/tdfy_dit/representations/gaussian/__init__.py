# Copyright (c) Meta Platforms, Inc. and affiliates.
from .gaussian_model import Gaussian
