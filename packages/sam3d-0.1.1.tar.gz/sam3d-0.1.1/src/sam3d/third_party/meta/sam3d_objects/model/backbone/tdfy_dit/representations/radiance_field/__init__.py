# Copyright (c) Meta Platforms, Inc. and affiliates.
from .strivec import Strivec
