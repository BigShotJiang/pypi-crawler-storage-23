# Copyright (c) Meta Platforms, Inc. and affiliates.

from .sam3d_body import SAM3DBody
