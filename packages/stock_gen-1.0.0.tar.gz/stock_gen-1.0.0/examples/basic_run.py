from __future__ import annotations

from stock_gen import StockGenerator, StockGeneratorConfig


def main() -> None:
    cfg = StockGeneratorConfig(
        tick_size=0.01,
        dt=1.0,
        end_time=30.0,
        depth_levels=10,
        seed=123,
    )
    sg = StockGenerator(cfg)

    print("t, mid, (best_bid, best_ask)")
    for _ in range(5):
        step_result = sg.step()
        fr = step_result.frame
        bid, ask = sg.get_best_bid_ask()
        print(f"{fr.t:7.2f}  {sg.get_price():10.4f}  ({bid[0]:.4f}, {ask[0]:.4f})")

    sim = sg.gen()
    hist = sim.history
    print(
        "done:",
        f"frames={len(hist.frames)}",
        f"events={len(hist.events)}",
        f"trades={len(hist.trades)}",
    )


if __name__ == "__main__":
    main()
