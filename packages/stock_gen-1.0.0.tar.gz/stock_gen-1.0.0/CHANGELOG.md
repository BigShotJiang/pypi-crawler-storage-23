# Changelog

All notable changes to this project are documented in this file.

## [1.0.0] - 2026-03-03

### Added

- New public config groups:
  - `JointFlowConfig`
  - `SpreadControlConfig`
  - `BookConstraintConfig`
- New order-flow documentation: `docs/joint-order-flow.md`.
- New migration guide: `docs/archive/migration-v1.0.md`.
- Event quantity-audit fields in public `Event` payloads:
  - `requested_qty`
  - `executed_qty`
  - `resting_qty`
  - `canceled_qty`

### Changed

- Default flow kernel is now `StockGeneratorConfig.flow_kernel="joint_v1"`.
- English README is the canonical main entry; Korean README is now a concise landing page with links.
- Core docs were refreshed for v1.0 config and contract semantics.

### Removed

- Obsolete consolidated migration note: `docs/archive/legacy-migrations.md`.

### Breaking Changes

- Pipelines that relied on prior factorized event-flow defaults must explicitly set `flow_kernel="legacy_factorized"` if needed.
- Strict event-schema consumers must allow the new nullable quantity-audit fields.
- References to `docs/archive/legacy-migrations.md` must be updated to `docs/archive/migration-v1.0.md` (or `CHANGELOG.md`).

## [0.8.0] - 2026-03-03

### Added

- Heatmap compaction controls in `viz.plot_l2_heatmap`:
  - `price_window_ticks: int | "auto"` (default `"auto"`)
  - `y_range: "auto" | "full" | "side" | "occupied"` (default `"auto"`)
- New migration note: `docs/archive/migration-v0.8.md`.
- New consolidated legacy migration note: `docs/archive/legacy-migrations.md`.
- New invariant and rollback tests:
  - `tests/test_orderbook_no_cross_invariant.py`
  - `tests/test_step_rollback_on_runtime_error.py`

### Changed

- Order-book resting state now enforces no-cross invariant (`best_bid <= best_ask`).
- `OrderBook.replace(...)` now behaves as cancel-then-limit-submit and can generate trades.
- Replace events can now emit `order_id=None` when replacement is fully executed.
- Step transaction rollback now restores checkpoint on any exception, not only cap exceptions.
- Heatmap defaults now prefer compact price-space rendering to avoid vertical empty space.
- Documentation refresh:
  - English README remains canonical and was updated for v0.8 behavior.
  - Korean README links to current migration paths.
  - Removed split legacy migration files (`migration-v0.3`, `migration-v0.5`, `migration-v0.6`) after consolidation.

### Breaking Changes

- Code relying on fixed price-space heatmap defaults must now pass explicit:
  - `price_window_ticks=<int>`
  - `y_range="full"`
- Consumers assuming replace events always provide `order_id` must handle `None`.
- Failed `step()` calls now guarantee rollback for all exception types.

## [0.7.0] - 2026-03-03

### Added

- Internal stochastic pattern engine (`engine/stochastic_pattern.py`) for seed-deterministic path diversity.
- Pattern jump synthetic events (`reason="pattern_jump"`) emitted as market-style shocks.
- Runtime modularization components: `HistoryStore` and `run_step_transaction`.
- Visualization upgrade: `plot_l2_heatmap(..., space="rank"|"price", price_window_ticks=...)`.
- New documentation pages:
  - `docs/viz.md`
  - `docs/archive/migration-v0.7.md`
- New tests:
  - `tests/test_tick_size_default_one.py`
  - `tests/test_depth_budget_allocation.py`
  - `tests/test_random_pattern_diversity.py`
  - `tests/test_heatmap_price_space.py`

### Changed

- Default `StockGeneratorConfig.tick_size` changed from `0.01` to `1.0`.
- Depth maintenance budget allocation now uses weighted deficit scoring across levels.
- Default model parameters were retuned (`PlacementConfig`, `SizeConfig`, `CancelConfig`, `DepthMaintenanceConfig`).
- Heatmap default space changed to relative price bins (`space="price"`).
- Seed reproducibility coverage now compares full event/trade tuples, not only counts.
- Documentation cleanup:
  - English README remains canonical.
  - Korean README is the single Korean landing page.
  - Removed redundant `docs/ko/index.md`.
  - Added clearer migration and release guidance.

### Breaking Changes

- Code assuming default cent-tick behavior must explicitly set `tick_size=0.01`.
- Code relying on old heatmap rank default should pass `space="rank"` explicitly.

### Behavior Notes

- Internal pattern transitions are intentionally not exposed as a public config API in v0.7.
- With fixed seed and config, simulations remain deterministic.

## [0.6.0] - 2026-03-03

### Added

- Depth maintenance controls for simulation stability: `DepthMaintenanceConfig` and `DepthMaintenancePolicy`.
- Heatmap visibility controls in `plot_l2_heatmap`: `mask_invalid`, `normalize`, and `vmax_quantile`.
- Legacy migration detail now consolidated in `docs/archive/legacy-migrations.md`.

### Changed

- Default runs now apply depth maintenance via `depth_maintenance.policy=SOFT_TARGET`, adding synthetic events tagged with `reason="depth_maintenance"` to keep visible depth populated.
- Heatmap rendering now defaults to invalid-level masking and `log1p` normalization with quantile-based color clipping.
- Documentation cleanup: release-process instructions stay in `docs/release.md`, and version migrations stay in `docs/archive/`.

### Behavior Changes

- Pipelines that aggregate event counts should decide whether to include synthetic depth-maintenance events.
- Heatmap visual scale/contrast differs from previous defaults unless `normalize="none"` and `vmax_quantile=None` are set explicitly.

## [0.5.0] - 2026-03-03

### Added

- `L2Snapshot` validity masks: `bid_px_valid`, `ask_px_valid`.
- `StepResult` event counters: `events_user`, `events_synthetic`, `events_total`.
- Intraday intensity regime configuration (`RegimeConfig`, `RegimeSegment`).
- Partial cancel controls in `CancelConfig` (`partial_cancel_prob`, `partial_min_ratio`).
- Runtime checkpoint module (`stock_gen.runtime.checkpoint`) for explicit atomic rollback.
- Legacy migration detail now consolidated in `docs/archive/legacy-migrations.md`.

### Changed

- `get_l2(as_ticks=False)` now returns `NaN` for missing prices.
- Event-cap rollback path now uses explicit checkpoint/restore objects instead of `deepcopy`.
- `StockGeneratorConfig` now enforces runtime type validation for policies and nested configs.
- Documentation was reorganized for v0.5 contracts and migration paths.

### Breaking Changes

- Missing prices in `get_l2(as_ticks=False)` changed from scaled negative sentinels to `NaN`.
- `StepResult` primary counters moved to `events_user/events_synthetic/events_total`; `events_processed` remains compatibility alias.
- Invalid runtime types for policy/nested config fields now raise `TypeError` at config construction.

## [0.4.0] - 2026-03-03

### Added

- `README.ko.md` Korean translation with reciprocal language switch and canonical-source note.
- Public API stability/docstring tests covering root `__all__` and exported methods/properties.

### Changed

- `StockGenerator.step()` now enforces atomic rollback for `EventCapPolicy.RAISE`; when cap is exceeded, state/history/time are restored before raising `EventCapExceededError`.
- Event-type sampling now recomputes event-loop features after time advance/flow decay at event time.
- Snapshot construction is now side-effect free; `last_mid_ticks` updates are handled in the simulation loop.
- `MarketHistory.to_numpy(as_ticks=False)` now exports `NaN` for missing prices instead of scaled `-1` sentinels.
- `MarketHistory.to_numpy()` now includes per-level validity masks: `bid_px_valid`, `ask_px_valid`.
- Docs were reorganized to English-first README + Korean README, deduplicated API usage docs, and archived migration notes under `docs/archive/`.

### Breaking Changes

- `to_numpy(as_ticks=False)` missing best quotes/levels are now `NaN` (previously negative scaled sentinels from tick `-1`).
- `EventCapPolicy.RAISE` now behaves transactionally at step level: no partial step mutation remains after cap-exceeded exceptions.
- Migration guide path changed from `docs/migration-v0.3.md` to archived legacy migration notes.

## [0.3.0] - 2026-03-03

### Added

- `docs/architecture.md` with system-level design, data flow, and extension points.
- Legacy migration detail now consolidated in `docs/archive/legacy-migrations.md`.

### Changed

- README package description now reflects policy-driven order-book event dynamics.
- `pyproject.toml` metadata updated to `version = "0.3.0"` and aligned package description.
- Version-specific hardcoding in docs titles/pins was generalized (for example, no `v0.2` headings; reproducibility pin uses `X.Y.Z`).
- README Quickstart was reduced to a minimal entry flow; full typed walkthrough is centralized in `docs/api.md`.
- `docs/release.md` now matches GitHub Actions OIDC Trusted Publishing workflow and removes mandatory `twine upload` from standard release flow.
- Core engine internals were modularized into `src/stock_gen/engine/` to separate feature extraction, snapshot building, and event dispatch responsibilities.
- `recent_flow` half-life decay now applies across the full frame interval (including no-event residual time).

### Breaking Changes

- `StockGenerator.get_events()`, `get_trades()`, and `get_step_results()` now return immutable tuples.
- `MarketHistory.frames/events/trades` and `SimulationResult.steps` are now immutable tuples.
- L2/frame arrays are exported as read-only snapshots; downstream code must copy arrays before mutation.
- `get_l2(levels<=0)` now raises `ValueError` with an explicit domain message.
- Maintainer release process is now documented as tag-driven GitHub Actions OIDC publishing (instead of direct `twine` uploads in the primary flow).
- Version-tagged documentation heading text changed, so deep links/bookmarks targeting old `v0.2` headings may require updates.

### Migration Summary

- Runtime API keeps the same entry points, but returned collection mutability changed; update code that mutates returned containers/arrays.
- Maintainers should use the `vX.Y.Z` tag flow documented in `docs/release.md` and ensure PyPI Trusted Publisher is configured.
- Documentation consumers should update links to version-agnostic docs and follow `docs/archive/legacy-migrations.md` for historical rollout steps.

## [0.2.0] - 2026-03-03

### Added

- Public result types `StepResult` and `SimulationResult` in top-level API.
- Public policy enums `LiquidityPolicy` and `EventCapPolicy` in top-level API.
- Step-level truncation metadata (`truncated`, `events_processed`, `t_last_event`).
- `SimulationResult` convenience properties: `frames`, `events`, `trades`.
- Data-contract validity masks for array export (`*_valid` fields in `to_numpy` output).
- Policy-level controls for empty-book handling and event-cap handling.

### Changed

- Documentation reorganized for v0.2:
  - install-first README flow
  - API/data-contract/config/reproducibility/release docs

### Notes

- This is the first changelog entry in this repository snapshot.
