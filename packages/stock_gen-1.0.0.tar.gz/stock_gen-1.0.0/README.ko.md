# stock-gen

언어: [English (canonical)](README.md) | 한국어

`stock-gen`은 이벤트 기반 단일자산 CLOB 시뮬레이터입니다.

> 한국어 문서는 빠른 진입용 안내입니다. 규범적 API/데이터 계약 기준은 영문 문서입니다.

## 빠른 시작

```bash
python -m pip install stock-gen
```

```python
from stock_gen import StockGenerator, StockGeneratorConfig

sim = StockGenerator(StockGeneratorConfig(seed=123, end_time=5.0)).gen()
print(len(sim.frames), len(sim.events), len(sim.trades))
```

## 핵심 문서 링크 (영문 기준)

- 문서 인덱스: [docs/index.md](docs/index.md)
- API: [docs/api.md](docs/api.md)
- 설정: [docs/config-reference.md](docs/config-reference.md)
- 데이터 계약: [docs/data-contract.md](docs/data-contract.md)
- Joint order-flow: [docs/joint-order-flow.md](docs/joint-order-flow.md)
- 아키텍처: [docs/architecture.md](docs/architecture.md)
- 릴리스 가이드: [docs/release.md](docs/release.md)
- v1.0 마이그레이션: [docs/archive/migration-v1.0.md](docs/archive/migration-v1.0.md)
- 변경 이력: [CHANGELOG.md](CHANGELOG.md)
