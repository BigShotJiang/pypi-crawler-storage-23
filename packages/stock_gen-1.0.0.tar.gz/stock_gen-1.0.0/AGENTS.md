# Agent Workflow Rules

## Subagent Lifecycle (Required)

To prevent thread-limit issues, every subagent task must follow this sequence:

1. `spawn` a subagent for a bounded task.
2. `wait` until the result is received.
3. `close` the subagent immediately after result collection.

No subagent should remain open after task completion.

## Hygiene

- Prefer parallel subagents only for independent tasks.
- Keep ownership boundaries explicit (files/modules per subagent).
- Verify merged results in the main agent before commit.
