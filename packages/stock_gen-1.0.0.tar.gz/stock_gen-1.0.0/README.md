# stock-gen

Language: English (canonical) | [한국어](README.ko.md)

`stock-gen` is an event-driven single-asset CLOB simulator for virtual stock experiments.
It models limit, market, cancel, replace, and synthetic maintenance events with deterministic replay under fixed config + seed.

## Requirements

- Python >= 3.11

## Install

```bash
python -m pip install stock-gen
```

For local development:

```bash
python -m pip install -e '.[dev]'
```

## Quickstart

```python
from stock_gen import StockGenerator, StockGeneratorConfig

cfg = StockGeneratorConfig(seed=123, end_time=5.0)
sim = StockGenerator(cfg).gen()
print(len(sim.frames), len(sim.events), len(sim.trades))
```

## v1.0 Highlights

- Default flow kernel is `flow_kernel="joint_v1"`.
- New public config groups:
  - `JointFlowConfig`
  - `SpreadControlConfig`
  - `BookConstraintConfig`
- Event records include quantity-audit fields:
  - `requested_qty`
  - `executed_qty`
  - `resting_qty`
  - `canceled_qty`

## Documentation

- Docs index: [docs/index.md](docs/index.md)
- API reference: [docs/api.md](docs/api.md)
- Config reference: [docs/config-reference.md](docs/config-reference.md)
- Data contract: [docs/data-contract.md](docs/data-contract.md)
- Joint order-flow model: [docs/joint-order-flow.md](docs/joint-order-flow.md)
- Architecture: [docs/architecture.md](docs/architecture.md)
- Release flow: [docs/release.md](docs/release.md)
- Migration guide (v1.0): [docs/archive/migration-v1.0.md](docs/archive/migration-v1.0.md)
- Changelog: [CHANGELOG.md](CHANGELOG.md)

## Examples

- [examples/basic_run.py](examples/basic_run.py)
- [examples/plot_demo.py](examples/plot_demo.py)
