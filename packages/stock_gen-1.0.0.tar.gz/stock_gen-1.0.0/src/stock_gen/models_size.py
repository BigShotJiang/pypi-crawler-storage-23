from __future__ import annotations

import math

from numpy.random import Generator

from .config import SizeConfig
from .types import PlacementMode


def _sample_lognormal_int(*, rng: Generator, mu: float, sigma: float, max_qty: int) -> int:
    x = float(rng.normal(mu, sigma))
    qty = int(round(math.exp(x)))
    if qty < 1:
        qty = 1
    if qty > max_qty:
        qty = max_qty
    return qty


def sample_market_qty(*, cfg: SizeConfig, rng: Generator) -> int:
    return _sample_lognormal_int(rng=rng, mu=cfg.market_mu, sigma=cfg.market_sigma, max_qty=cfg.max_order_qty)


def sample_limit_qty(*, cfg: SizeConfig, rng: Generator, mode: PlacementMode) -> int:
    if mode is PlacementMode.IMPROVE:
        return _sample_lognormal_int(
            rng=rng, mu=cfg.improve_mu, sigma=cfg.improve_sigma, max_qty=cfg.max_order_qty
        )
    if mode is PlacementMode.JOIN:
        return _sample_lognormal_int(
            rng=rng, mu=cfg.join_mu, sigma=cfg.join_sigma, max_qty=cfg.max_order_qty
        )
    if mode is PlacementMode.DEEP:
        return _sample_lognormal_int(
            rng=rng, mu=cfg.deep_mu, sigma=cfg.deep_sigma, max_qty=cfg.max_order_qty
        )
    raise ValueError(f"unknown placement mode: {mode}")
