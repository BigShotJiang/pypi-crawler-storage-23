from __future__ import annotations

import math
from dataclasses import dataclass
from enum import IntEnum

import numpy as np
from numpy.random import Generator
from numpy.typing import NDArray

from .config import JOINT_FLOW_ACTION_DIM, JOINT_FLOW_FEATURE_DIM, JointFlowConfig
from .sim_state import SimulationState
from .types import EventType, PlacementMode, Side


class ActionCategory(IntEnum):
    """Joint categories over event type, side, and execution style."""

    L_B_IMPROVE = 0
    L_B_JOIN = 1
    L_B_DEEP = 2
    L_A_IMPROVE = 3
    L_A_JOIN = 4
    L_A_DEEP = 5
    M_B = 6
    M_A = 7
    C_B_AGGR = 8
    C_B_PASSIVE = 9
    C_A_AGGR = 10
    C_A_PASSIVE = 11


@dataclass(frozen=True, slots=True)
class JointAction:
    """Concrete action sampled from the joint flow model."""

    category: ActionCategory
    event_type: EventType
    side: Side
    placement_mode: PlacementMode | None
    deep_distance_scale: float | None
    qty_scale: float
    cancel_xi_shift: float | None


def _softmax(logits: NDArray[np.float64]) -> NDArray[np.float64]:
    m = float(np.max(logits))
    x = np.exp(logits - m)
    s = float(np.sum(x))
    if s <= 0.0:
        return np.asarray([1.0 / float(len(logits))] * len(logits), dtype=np.float64)
    return x / s


def _compute_joint_features(
    *,
    spread_ticks: int | None,
    best_bid_qty: int | None,
    best_ask_qty: int | None,
    imbalance: float | None,
    recent_flow: float,
    no_trade_streak_frames: int,
    market_share: float,
    cancel_share: float,
) -> NDArray[np.float64]:
    spread = 0.0 if spread_ticks is None or spread_ticks < 0 else float(spread_ticks)
    bbq = 0.0 if best_bid_qty is None or best_bid_qty < 0 else float(best_bid_qty)
    baq = 0.0 if best_ask_qty is None or best_ask_qty < 0 else float(best_ask_qty)
    imb = 0.0 if imbalance is None else float(imbalance)
    flow = float(np.clip(float(recent_flow), -100.0, 100.0))
    stale = float(np.clip(float(no_trade_streak_frames) / 20.0, 0.0, 1.0))
    vec = np.asarray(
        [
            1.0,
            math.log1p(spread),
            math.log1p(bbq),
            math.log1p(baq),
            imb,
            flow,
            stale,
            float(np.clip(market_share, 0.0, 1.0)),
            float(np.clip(cancel_share, 0.0, 1.0)),
        ],
        dtype=np.float64,
    )
    if vec.shape != (JOINT_FLOW_FEATURE_DIM,):
        raise AssertionError(
            f"joint feature vector must be shape ({JOINT_FLOW_FEATURE_DIM},), got {vec.shape}"
        )
    return vec


def _compute_adaptation_shift(
    *,
    cfg: JointFlowConfig,
    state: SimulationState,
) -> tuple[float, float]:
    total = int(state.rolling_total_events)
    if (
        not cfg.adaptation_enabled
        or total < int(cfg.adaptation_warmup_events)
        or total <= 0
        or cfg.adaptation_strength <= 0.0
    ):
        return 0.0, 0.0

    market_share = float(state.rolling_market_events) / float(total)
    cancel_share = float(state.rolling_cancel_events) / float(total)

    market_shift = 0.0
    if market_share < cfg.market_share_floor:
        market_shift += cfg.adaptation_strength * (cfg.market_share_floor - market_share)
    elif market_share > cfg.market_share_ceiling:
        market_shift -= cfg.adaptation_strength * (market_share - cfg.market_share_ceiling)
    # stale-flow bonus to break no-trade streaks quickly.
    market_shift += 0.50 * float(np.clip(state.no_trade_streak_frames / 5.0, 0.0, 1.0))
    market_shift = float(np.clip(market_shift, -cfg.max_adaptation_shift, cfg.max_adaptation_shift))

    cancel_shift = 0.0
    if cancel_share > cfg.cancel_share_ceiling:
        cancel_shift -= cfg.adaptation_strength * (cancel_share - cfg.cancel_share_ceiling)
    elif cancel_share < cfg.cancel_share_floor:
        cancel_shift += cfg.adaptation_strength * (cfg.cancel_share_floor - cancel_share)
    cancel_shift = float(np.clip(cancel_shift, -cfg.max_adaptation_shift, cfg.max_adaptation_shift))
    return market_shift, cancel_shift


def _category_feasible(
    *,
    cat: ActionCategory,
    has_bid: bool,
    has_ask: bool,
    spread_ticks: int | None,
) -> bool:
    if cat in (ActionCategory.M_B,):
        return has_ask
    if cat in (ActionCategory.M_A,):
        return has_bid
    if cat in (ActionCategory.C_B_AGGR, ActionCategory.C_B_PASSIVE):
        return has_bid
    if cat in (ActionCategory.C_A_AGGR, ActionCategory.C_A_PASSIVE):
        return has_ask
    if cat in (ActionCategory.L_B_IMPROVE, ActionCategory.L_A_IMPROVE):
        return has_bid and has_ask and spread_ticks is not None and spread_ticks > 1
    return True


def _to_action(category: ActionCategory) -> JointAction:
    if category is ActionCategory.L_B_IMPROVE:
        return JointAction(
            category=category,
            event_type=EventType.L_B,
            side=Side.BID,
            placement_mode=PlacementMode.IMPROVE,
            deep_distance_scale=None,
            qty_scale=1.20,
            cancel_xi_shift=None,
        )
    if category is ActionCategory.L_B_JOIN:
        return JointAction(
            category=category,
            event_type=EventType.L_B,
            side=Side.BID,
            placement_mode=PlacementMode.JOIN,
            deep_distance_scale=None,
            qty_scale=1.00,
            cancel_xi_shift=None,
        )
    if category is ActionCategory.L_B_DEEP:
        return JointAction(
            category=category,
            event_type=EventType.L_B,
            side=Side.BID,
            placement_mode=PlacementMode.DEEP,
            deep_distance_scale=1.00,
            qty_scale=0.90,
            cancel_xi_shift=None,
        )
    if category is ActionCategory.L_A_IMPROVE:
        return JointAction(
            category=category,
            event_type=EventType.L_A,
            side=Side.ASK,
            placement_mode=PlacementMode.IMPROVE,
            deep_distance_scale=None,
            qty_scale=1.20,
            cancel_xi_shift=None,
        )
    if category is ActionCategory.L_A_JOIN:
        return JointAction(
            category=category,
            event_type=EventType.L_A,
            side=Side.ASK,
            placement_mode=PlacementMode.JOIN,
            deep_distance_scale=None,
            qty_scale=1.00,
            cancel_xi_shift=None,
        )
    if category is ActionCategory.L_A_DEEP:
        return JointAction(
            category=category,
            event_type=EventType.L_A,
            side=Side.ASK,
            placement_mode=PlacementMode.DEEP,
            deep_distance_scale=1.00,
            qty_scale=0.90,
            cancel_xi_shift=None,
        )
    if category is ActionCategory.M_B:
        return JointAction(
            category=category,
            event_type=EventType.M_B,
            side=Side.BID,
            placement_mode=None,
            deep_distance_scale=None,
            qty_scale=1.25,
            cancel_xi_shift=None,
        )
    if category is ActionCategory.M_A:
        return JointAction(
            category=category,
            event_type=EventType.M_A,
            side=Side.ASK,
            placement_mode=None,
            deep_distance_scale=None,
            qty_scale=1.25,
            cancel_xi_shift=None,
        )
    if category is ActionCategory.C_B_AGGR:
        return JointAction(
            category=category,
            event_type=EventType.C_B,
            side=Side.BID,
            placement_mode=None,
            deep_distance_scale=None,
            qty_scale=1.00,
            cancel_xi_shift=-0.20,
        )
    if category is ActionCategory.C_B_PASSIVE:
        return JointAction(
            category=category,
            event_type=EventType.C_B,
            side=Side.BID,
            placement_mode=None,
            deep_distance_scale=None,
            qty_scale=1.00,
            cancel_xi_shift=0.20,
        )
    if category is ActionCategory.C_A_AGGR:
        return JointAction(
            category=category,
            event_type=EventType.C_A,
            side=Side.ASK,
            placement_mode=None,
            deep_distance_scale=None,
            qty_scale=1.00,
            cancel_xi_shift=-0.20,
        )
    return JointAction(
        category=category,
        event_type=EventType.C_A,
        side=Side.ASK,
        placement_mode=None,
        deep_distance_scale=None,
        qty_scale=1.00,
        cancel_xi_shift=0.20,
    )


def sample_joint_action(
    *,
    cfg: JointFlowConfig,
    rng: Generator,
    state: SimulationState,
    spread_ticks: int | None,
    best_bid_qty: int | None,
    best_ask_qty: int | None,
    imbalance: float | None,
    recent_flow: float,
    has_bid: bool,
    has_ask: bool,
    lambdas: dict[EventType, float] | None = None,
) -> JointAction:
    """Sample one joint action with feasibility masking and adaptive logit shifts."""

    total = max(0, int(state.rolling_total_events))
    market_share = 0.0 if total <= 0 else float(state.rolling_market_events) / float(total)
    cancel_share = 0.0 if total <= 0 else float(state.rolling_cancel_events) / float(total)
    features = _compute_joint_features(
        spread_ticks=spread_ticks,
        best_bid_qty=best_bid_qty,
        best_ask_qty=best_ask_qty,
        imbalance=imbalance,
        recent_flow=recent_flow,
        no_trade_streak_frames=int(state.no_trade_streak_frames),
        market_share=market_share,
        cancel_share=cancel_share,
    )
    logits = np.asarray(cfg.action_logits, dtype=np.float64) @ features
    if logits.shape != (JOINT_FLOW_ACTION_DIM,):
        raise ValueError(f"joint logits must be shape ({JOINT_FLOW_ACTION_DIM},), got {logits.shape}")

    if lambdas is not None:
        w = 0.15
        eps = 1e-12
        lb = math.log(max(float(lambdas.get(EventType.L_B, 0.0)), eps))
        la = math.log(max(float(lambdas.get(EventType.L_A, 0.0)), eps))
        mb = math.log(max(float(lambdas.get(EventType.M_B, 0.0)), eps))
        ma = math.log(max(float(lambdas.get(EventType.M_A, 0.0)), eps))
        cb = math.log(max(float(lambdas.get(EventType.C_B, 0.0)), eps))
        ca = math.log(max(float(lambdas.get(EventType.C_A, 0.0)), eps))
        logits[[ActionCategory.L_B_IMPROVE, ActionCategory.L_B_JOIN, ActionCategory.L_B_DEEP]] += w * lb
        logits[[ActionCategory.L_A_IMPROVE, ActionCategory.L_A_JOIN, ActionCategory.L_A_DEEP]] += w * la
        logits[[ActionCategory.M_B]] += w * mb
        logits[[ActionCategory.M_A]] += w * ma
        logits[[ActionCategory.C_B_AGGR, ActionCategory.C_B_PASSIVE]] += w * cb
        logits[[ActionCategory.C_A_AGGR, ActionCategory.C_A_PASSIVE]] += w * ca

    market_shift, cancel_shift = _compute_adaptation_shift(cfg=cfg, state=state)
    logits = logits.copy()
    logits[[ActionCategory.M_B, ActionCategory.M_A]] += market_shift
    logits[
        [
            ActionCategory.C_B_AGGR,
            ActionCategory.C_B_PASSIVE,
            ActionCategory.C_A_AGGR,
            ActionCategory.C_A_PASSIVE,
        ]
    ] += cancel_shift

    for cat in ActionCategory:
        if not _category_feasible(cat=cat, has_bid=has_bid, has_ask=has_ask, spread_ticks=spread_ticks):
            logits[int(cat)] = -np.inf

    if not np.isfinite(logits).any():
        fallback = ActionCategory.L_B_JOIN if has_ask else ActionCategory.L_A_JOIN
        return _to_action(fallback)

    probs = _softmax(logits.astype(np.float64))
    idx = int(rng.choice(JOINT_FLOW_ACTION_DIM, p=probs))
    return _to_action(ActionCategory(idx))
