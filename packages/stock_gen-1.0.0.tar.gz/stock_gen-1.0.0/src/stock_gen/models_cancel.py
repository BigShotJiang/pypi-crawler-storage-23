from __future__ import annotations

import math

from numpy.random import Generator

from .config import CancelConfig
from .orderbook import OrderBook
from .types import Side


def select_order_by_priority_index(ob: OrderBook, *, side: Side, xi: float) -> int | None:
    """
    Select the first order whose priority_index >= xi, where:

        priority_index = (qty_ahead_in_priority_order) / (total_qty_same_side)

    Practically, this is equivalent to choosing target = xi * Q_side and taking
    the first order whose cumulative qty >= target when iterating in priority order.
    """
    q = ob.total_qty(side)
    if q <= 0:
        return None

    if xi <= 0.0:
        target = 0.0
    elif xi >= 1.0:
        target = float(q)
    else:
        target = float(xi) * float(q)

    cum = 0.0
    for order_id, _price_ticks, qty in ob.iter_orders_priority(side):
        cum += float(qty)
        if cum >= target:
            return order_id
    return None


def sample_xi(*, cfg: CancelConfig, rng: Generator, shift: float = 0.0) -> float:
    """Sample cancellation priority index with optional bounded shift."""

    xi = float(rng.beta(cfg.beta_a, cfg.beta_b))
    return min(1.0, max(0.0, xi + float(shift)))


def sample_cancel_qty(*, cfg: CancelConfig, rng: Generator, order_qty: int) -> int:
    """Sample cancel quantity for one resting order."""

    if order_qty <= 0:
        raise ValueError("order_qty must be positive")
    if order_qty == 1:
        return 1
    if float(rng.uniform()) >= cfg.partial_cancel_prob:
        return int(order_qty)

    min_partial = max(1, int(math.ceil(order_qty * cfg.partial_min_ratio)))
    if min_partial >= order_qty:
        min_partial = order_qty - 1
    return int(rng.integers(min_partial, order_qty))


def choose_cancel_order_id(
    ob: OrderBook,
    *,
    side: Side,
    cfg: CancelConfig,
    rng: Generator,
    xi_shift: float = 0.0,
) -> int | None:
    """Choose one resting order id to cancel using sampled queue-priority index."""

    xi = sample_xi(cfg=cfg, rng=rng, shift=xi_shift)
    return select_order_by_priority_index(ob, side=side, xi=xi)
