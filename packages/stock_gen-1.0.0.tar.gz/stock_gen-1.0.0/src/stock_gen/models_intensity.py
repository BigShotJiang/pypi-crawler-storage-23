from __future__ import annotations

import math

import numpy as np
from numpy.typing import NDArray

from .config import PHI_DIM, ExpLinearIntensityConfig
from .types import EventType


def compute_phi(
    *,
    spread_ticks: int | None,
    best_bid_qty: int | None,
    best_ask_qty: int | None,
    imbalance: float | None,
    recent_flow: float,
) -> NDArray[np.float64]:
    spread = 0.0 if spread_ticks is None or spread_ticks < 0 else float(spread_ticks)
    bbq = 0.0 if best_bid_qty is None or best_bid_qty < 0 else float(best_bid_qty)
    baq = 0.0 if best_ask_qty is None or best_ask_qty < 0 else float(best_ask_qty)
    imb = 0.0 if imbalance is None else float(imbalance)

    phi = np.asarray(
        [
            1.0,
            math.log1p(spread),
            math.log1p(bbq),
            math.log1p(baq),
            imb,
            float(recent_flow),
        ],
        dtype=np.float64,
    )
    if phi.shape != (PHI_DIM,):
        raise AssertionError(f"phi must be shape ({PHI_DIM},), got {phi.shape}")
    return phi


def compute_lambdas(
    cfg: ExpLinearIntensityConfig,
    phi: NDArray[np.float64],
    *,
    has_bid: bool,
    has_ask: bool,
    intensity_multiplier: float = 1.0,
) -> dict[EventType, float]:
    if phi.shape != (PHI_DIM,):
        raise ValueError(f"phi must be shape ({PHI_DIM},), got {phi.shape}")
    if intensity_multiplier <= 0.0:
        raise ValueError("intensity_multiplier must be > 0")

    out: dict[EventType, float] = {}
    for et in EventType:
        theta = cfg.theta.get(et)
        if theta is None:
            out[et] = 0.0
            continue

        feasible = True
        if et is EventType.M_B:
            feasible = has_ask
        elif et is EventType.M_A:
            feasible = has_bid
        elif et is EventType.C_B:
            feasible = has_bid
        elif et is EventType.C_A:
            feasible = has_ask
        elif et is EventType.R_B:
            feasible = has_bid
        elif et is EventType.R_A:
            feasible = has_ask

        if not feasible:
            out[et] = 0.0
            continue

        x = float(np.dot(theta, phi))
        x = max(-cfg.exp_clip, min(cfg.exp_clip, x))
        lam = math.exp(x) * float(intensity_multiplier)
        out[et] = float(lam if lam >= cfg.min_lambda else cfg.min_lambda)

    return out
