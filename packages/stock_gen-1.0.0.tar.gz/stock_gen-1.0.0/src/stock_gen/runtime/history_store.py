from __future__ import annotations

from collections.abc import MutableSequence

from ..types import Event, FrameSnapshot, MarketHistory, StepResult, Trade


class HistoryStore:
    """Mutable history buffers with immutable API-facing views."""

    def __init__(self) -> None:
        self._frames: list[FrameSnapshot] = []
        self._events: list[Event] = []
        self._trades: list[Trade] = []
        self._step_results: list[StepResult] = []

    @property
    def frame_len(self) -> int:
        return len(self._frames)

    @property
    def event_len(self) -> int:
        return len(self._events)

    @property
    def trade_len(self) -> int:
        return len(self._trades)

    @property
    def step_len(self) -> int:
        return len(self._step_results)

    @property
    def frames_buffer(self) -> MutableSequence[FrameSnapshot]:
        return self._frames

    @property
    def events_buffer(self) -> MutableSequence[Event]:
        return self._events

    @property
    def trades_buffer(self) -> MutableSequence[Trade]:
        return self._trades

    @property
    def step_results_buffer(self) -> MutableSequence[StepResult]:
        return self._step_results

    def clear(self) -> None:
        self._frames.clear()
        self._events.clear()
        self._trades.clear()
        self._step_results.clear()

    def append_frame(self, frame: FrameSnapshot) -> None:
        self._frames.append(frame)

    def append_event(self, event: Event) -> None:
        self._events.append(event)

    def extend_trades(self, trades: list[Trade]) -> None:
        self._trades.extend(trades)

    def append_step_result(self, step_result: StepResult) -> None:
        self._step_results.append(step_result)

    def events_from(self, start: int) -> list[Event]:
        return self._events[int(start) :]

    def events(self) -> tuple[Event, ...]:
        return tuple(self._events)

    def trades(self) -> tuple[Trade, ...]:
        return tuple(self._trades)

    def step_results(self) -> tuple[StepResult, ...]:
        return tuple(self._step_results)

    def history(self, *, tick_size: float) -> MarketHistory:
        return MarketHistory(
            tick_size=float(tick_size),
            frames=tuple(self._frames),
            events=tuple(self._events),
            trades=tuple(self._trades),
        )
