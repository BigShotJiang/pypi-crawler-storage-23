from __future__ import annotations

from collections.abc import Callable
from typing import TypeVar

from ..types import EventCapPolicy
from .checkpoint import StepCheckpoint

T = TypeVar("T")


def run_step_transaction(
    *,
    event_cap_policy: EventCapPolicy,
    capture_checkpoint: Callable[[], StepCheckpoint],
    restore_checkpoint: Callable[[StepCheckpoint], None],
    run_step: Callable[[], T],
) -> T:
    """Run one step with full rollback on any exception."""

    _ = event_cap_policy

    checkpoint = capture_checkpoint()
    try:
        return run_step()
    except Exception:
        restore_checkpoint(checkpoint)
        raise
