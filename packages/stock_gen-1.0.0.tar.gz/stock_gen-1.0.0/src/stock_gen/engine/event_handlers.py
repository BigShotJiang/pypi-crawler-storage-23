from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass
from typing import Protocol

from numpy.random import Generator

from ..config import StockGeneratorConfig
from ..models_cancel import choose_cancel_order_id, sample_cancel_qty, select_order_by_priority_index
from ..models_joint_flow import JointAction
from ..models_placement import sample_placement
from ..models_size import sample_limit_qty, sample_market_qty
from ..orderbook import OrderBook
from ..sim_state import SimulationState
from ..types import EventType, PlacementMode, Side, Trade


class EventAppender(Protocol):
    def __call__(
        self,
        *,
        event_type: EventType,
        side: Side,
        price_ticks: int | None,
        qty: int | None,
        order_id: int | None,
        synthetic: bool = False,
        reason: str | None = None,
        placement_mode: PlacementMode | None = None,
        deep_distance: int | None = None,
        replaced_order_id: int | None = None,
        requested_qty: int | None = None,
        executed_qty: int | None = None,
        resting_qty: int | None = None,
        canceled_qty: int | None = None,
    ) -> None: ...


@dataclass(slots=True)
class EventHandlerContext:
    """Runtime dependencies used by event handlers and dispatcher."""

    cfg: StockGeneratorConfig
    rng: Generator
    ob: OrderBook
    state: SimulationState
    anchor_bests: Callable[[], tuple[int, int]]
    append_event: EventAppender


EventHandler = Callable[[float, int, int, int], list[Trade]]


class EventDispatcher:
    """Route sampled event types to concrete order-book mutations."""

    def __init__(self, context: EventHandlerContext) -> None:
        self._ctx = context
        self._handlers: dict[EventType, EventHandler] = {
            EventType.L_B: self._handle_limit_bid,
            EventType.L_A: self._handle_limit_ask,
            EventType.M_B: self._handle_market_bid,
            EventType.M_A: self._handle_market_ask,
            EventType.C_B: self._handle_cancel_bid,
            EventType.C_A: self._handle_cancel_ask,
            EventType.R_B: self._handle_replace_bid,
            EventType.R_A: self._handle_replace_ask,
        }

    def process(self, *, event_type: EventType, imbalance: float) -> list[Trade]:
        """Process one sampled event type and return generated trades."""

        handler = self._handlers.get(event_type)
        if handler is None:
            raise ValueError(f"unknown event_type: {event_type}")

        best_bid_anchor, best_ask_anchor = self._ctx.anchor_bests()
        spread_ticks = int(best_ask_anchor - best_bid_anchor)
        return handler(float(imbalance), best_bid_anchor, best_ask_anchor, spread_ticks)

    def process_joint_action(self, *, action: JointAction, imbalance: float) -> list[Trade]:
        """Process one pre-sampled joint action and return generated trades."""

        best_bid_anchor, best_ask_anchor = self._ctx.anchor_bests()
        spread_ticks = int(best_ask_anchor - best_bid_anchor)
        if action.event_type is EventType.L_B:
            return self._handle_limit(
                event_type=EventType.L_B,
                side=Side.BID,
                imbalance=imbalance,
                best_bid_anchor=best_bid_anchor,
                best_ask_anchor=best_ask_anchor,
                spread_ticks=spread_ticks,
                forced_mode=action.placement_mode,
                deep_distance_scale_override=action.deep_distance_scale,
                qty_scale=action.qty_scale,
            )
        if action.event_type is EventType.L_A:
            return self._handle_limit(
                event_type=EventType.L_A,
                side=Side.ASK,
                imbalance=imbalance,
                best_bid_anchor=best_bid_anchor,
                best_ask_anchor=best_ask_anchor,
                spread_ticks=spread_ticks,
                forced_mode=action.placement_mode,
                deep_distance_scale_override=action.deep_distance_scale,
                qty_scale=action.qty_scale,
            )
        if action.event_type is EventType.M_B:
            return self._handle_market(event_type=EventType.M_B, side=Side.BID, qty_scale=action.qty_scale)
        if action.event_type is EventType.M_A:
            return self._handle_market(event_type=EventType.M_A, side=Side.ASK, qty_scale=action.qty_scale)
        if action.event_type is EventType.C_B:
            return self._handle_cancel(
                event_type=EventType.C_B,
                side=Side.BID,
                xi_shift_override=action.cancel_xi_shift,
            )
        if action.event_type is EventType.C_A:
            return self._handle_cancel(
                event_type=EventType.C_A,
                side=Side.ASK,
                xi_shift_override=action.cancel_xi_shift,
            )
        return self.process(event_type=action.event_type, imbalance=imbalance)

    def apply_pattern_jump(self, *, side: Side, qty_scale: float) -> list[Trade]:
        """Apply a synthetic jump shock as an aggressive market order."""

        base_qty = sample_market_qty(cfg=self._ctx.cfg.size, rng=self._ctx.rng)
        qty = self._scaled_qty(base_qty, qty_scale)
        trades = self._ctx.ob.process_market(side=side, qty=qty, t=self._ctx.state.t)
        executed_qty = int(sum(tr.qty for tr in trades))
        self._ctx.append_event(
            event_type=EventType.M_B if side is Side.BID else EventType.M_A,
            side=side,
            price_ticks=None,
            qty=int(qty),
            order_id=None,
            synthetic=True,
            reason="pattern_jump",
            requested_qty=int(qty),
            executed_qty=executed_qty,
            resting_qty=0,
        )
        return trades

    def _handle_limit_bid(
        self, imbalance: float, best_bid_anchor: int, best_ask_anchor: int, spread_ticks: int
    ) -> list[Trade]:
        return self._handle_limit(
            event_type=EventType.L_B,
            side=Side.BID,
            imbalance=imbalance,
            best_bid_anchor=best_bid_anchor,
            best_ask_anchor=best_ask_anchor,
            spread_ticks=spread_ticks,
        )

    def _handle_limit_ask(
        self, imbalance: float, best_bid_anchor: int, best_ask_anchor: int, spread_ticks: int
    ) -> list[Trade]:
        return self._handle_limit(
            event_type=EventType.L_A,
            side=Side.ASK,
            imbalance=imbalance,
            best_bid_anchor=best_bid_anchor,
            best_ask_anchor=best_ask_anchor,
            spread_ticks=spread_ticks,
        )

    def _handle_market_bid(
        self, _imbalance: float, _best_bid_anchor: int, _best_ask_anchor: int, _spread_ticks: int
    ) -> list[Trade]:
        return self._handle_market(event_type=EventType.M_B, side=Side.BID)

    def _handle_market_ask(
        self, _imbalance: float, _best_bid_anchor: int, _best_ask_anchor: int, _spread_ticks: int
    ) -> list[Trade]:
        return self._handle_market(event_type=EventType.M_A, side=Side.ASK)

    def _handle_cancel_bid(
        self, _imbalance: float, _best_bid_anchor: int, _best_ask_anchor: int, _spread_ticks: int
    ) -> list[Trade]:
        return self._handle_cancel(event_type=EventType.C_B, side=Side.BID)

    def _handle_cancel_ask(
        self, _imbalance: float, _best_bid_anchor: int, _best_ask_anchor: int, _spread_ticks: int
    ) -> list[Trade]:
        return self._handle_cancel(event_type=EventType.C_A, side=Side.ASK)

    def _handle_replace_bid(
        self, imbalance: float, best_bid_anchor: int, best_ask_anchor: int, spread_ticks: int
    ) -> list[Trade]:
        return self._handle_replace(
            event_type=EventType.R_B,
            side=Side.BID,
            imbalance=imbalance,
            best_bid_anchor=best_bid_anchor,
            best_ask_anchor=best_ask_anchor,
            spread_ticks=spread_ticks,
        )

    def _handle_replace_ask(
        self, imbalance: float, best_bid_anchor: int, best_ask_anchor: int, spread_ticks: int
    ) -> list[Trade]:
        return self._handle_replace(
            event_type=EventType.R_A,
            side=Side.ASK,
            imbalance=imbalance,
            best_bid_anchor=best_bid_anchor,
            best_ask_anchor=best_ask_anchor,
            spread_ticks=spread_ticks,
        )

    @staticmethod
    def _scaled_qty(base_qty: int, scale: float, *, min_qty: int = 1, max_qty: int = 1_000_000) -> int:
        scaled = float(base_qty) * max(0.25, float(scale))
        return max(int(min_qty), min(int(round(scaled)), int(max_qty)))

    def _resolve_forced_placement(
        self,
        *,
        side: Side,
        mode: PlacementMode,
        best_bid_anchor: int,
        best_ask_anchor: int,
        spread_ticks: int,
        deep_distance_scale_override: float | None,
    ) -> tuple[PlacementMode, int, int | None]:
        if mode is PlacementMode.IMPROVE:
            if spread_ticks <= 1:
                mode = PlacementMode.JOIN
            elif side is Side.BID:
                return mode, int(best_bid_anchor + 1), None
            else:
                return mode, int(best_ask_anchor - 1), None

        if mode is PlacementMode.JOIN:
            return mode, int(best_bid_anchor if side is Side.BID else best_ask_anchor), None

        raw_d = int(self._ctx.rng.geometric(self._ctx.cfg.placement.p_deep))
        scale = (
            float(deep_distance_scale_override)
            if deep_distance_scale_override is not None
            else float(self._ctx.state.pattern_deep_distance_scale)
        )
        d = max(1, int(round(float(raw_d) * max(0.25, scale))))
        d = int(min(d, self._ctx.cfg.placement.deep_max_ticks))
        if side is Side.BID:
            return mode, int(best_bid_anchor - d), d
        return mode, int(best_ask_anchor + d), d

    def _handle_limit(
        self,
        *,
        event_type: EventType,
        side: Side,
        imbalance: float,
        best_bid_anchor: int,
        best_ask_anchor: int,
        spread_ticks: int,
        forced_mode: PlacementMode | None = None,
        deep_distance_scale_override: float | None = None,
        qty_scale: float = 1.0,
    ) -> list[Trade]:
        if forced_mode is None:
            mode, price_ticks, deep_distance = sample_placement(
                cfg=self._ctx.cfg.placement,
                rng=self._ctx.rng,
                side=side,
                best_bid_ticks=best_bid_anchor,
                best_ask_ticks=best_ask_anchor,
                spread_ticks=spread_ticks,
                imbalance=float(imbalance),
                side_bias=float(self._ctx.state.pattern_placement_side_bias),
                deep_distance_scale=float(self._ctx.state.pattern_deep_distance_scale),
            )
        else:
            mode, price_ticks, deep_distance = self._resolve_forced_placement(
                side=side,
                mode=forced_mode,
                best_bid_anchor=best_bid_anchor,
                best_ask_anchor=best_ask_anchor,
                spread_ticks=spread_ticks,
                deep_distance_scale_override=deep_distance_scale_override,
            )

        base_qty = sample_limit_qty(cfg=self._ctx.cfg.size, rng=self._ctx.rng, mode=mode)
        qty = self._scaled_qty(base_qty, qty_scale, max_qty=int(self._ctx.cfg.size.max_order_qty))
        order_id, trades = self._ctx.ob.process_limit(
            side=side,
            price_ticks=price_ticks,
            qty=qty,
            t=self._ctx.state.t,
        )
        executed_qty = int(sum(tr.qty for tr in trades))
        resting_qty = int(max(0, qty - executed_qty))
        self._ctx.append_event(
            event_type=event_type,
            side=side,
            price_ticks=int(price_ticks),
            qty=int(qty),
            order_id=order_id,
            placement_mode=mode,
            deep_distance=deep_distance,
            requested_qty=int(qty),
            executed_qty=executed_qty,
            resting_qty=resting_qty,
        )
        return trades

    def _handle_market(self, *, event_type: EventType, side: Side, qty_scale: float = 1.0) -> list[Trade]:
        base_qty = sample_market_qty(cfg=self._ctx.cfg.size, rng=self._ctx.rng)
        qty = self._scaled_qty(base_qty, qty_scale, max_qty=int(self._ctx.cfg.size.max_order_qty))
        trades = self._ctx.ob.process_market(side=side, qty=qty, t=self._ctx.state.t)
        executed_qty = int(sum(tr.qty for tr in trades))
        self._ctx.append_event(
            event_type=event_type,
            side=side,
            price_ticks=None,
            qty=int(qty),
            order_id=None,
            requested_qty=int(qty),
            executed_qty=executed_qty,
            resting_qty=0,
        )
        return trades

    def _handle_cancel(
        self,
        *,
        event_type: EventType,
        side: Side,
        xi_shift_override: float | None = None,
    ) -> list[Trade]:
        extra_shift = 0.0 if xi_shift_override is None else float(xi_shift_override)
        order_id = choose_cancel_order_id(
            ob=self._ctx.ob,
            side=side,
            cfg=self._ctx.cfg.cancel,
            rng=self._ctx.rng,
            xi_shift=float(self._ctx.state.pattern_cancel_xi_shift) + extra_shift,
        )
        if order_id is None:
            return []

        order = self._ctx.ob.get_order(order_id)
        if order is None:
            return []
        _order_side, _order_price, order_qty = order

        cancel_qty = sample_cancel_qty(cfg=self._ctx.cfg.cancel, rng=self._ctx.rng, order_qty=order_qty)

        canceled = self._ctx.ob.cancel_partial(order_id, qty=cancel_qty)
        if canceled is None:
            return []

        _side, price_ticks, canceled_qty, remaining_qty = canceled
        self._ctx.append_event(
            event_type=event_type,
            side=side,
            price_ticks=int(price_ticks),
            qty=int(canceled_qty),
            order_id=int(order_id),
            requested_qty=int(cancel_qty),
            executed_qty=0,
            resting_qty=int(remaining_qty),
            canceled_qty=int(canceled_qty),
        )
        return []

    def _handle_replace(
        self,
        *,
        event_type: EventType,
        side: Side,
        imbalance: float,
        best_bid_anchor: int,
        best_ask_anchor: int,
        spread_ticks: int,
    ) -> list[Trade]:
        order_id = select_order_by_priority_index(
            self._ctx.ob,
            side=side,
            xi=float(self._ctx.rng.uniform()),
        )
        if order_id is None:
            return []

        original = self._ctx.ob.get_order(order_id)
        original_qty = None if original is None else int(original[2])

        mode, price_ticks, deep_distance = sample_placement(
            cfg=self._ctx.cfg.placement,
            rng=self._ctx.rng,
            side=side,
            best_bid_ticks=best_bid_anchor,
            best_ask_ticks=best_ask_anchor,
            spread_ticks=spread_ticks,
            imbalance=float(imbalance),
            side_bias=float(self._ctx.state.pattern_placement_side_bias),
            deep_distance_scale=float(self._ctx.state.pattern_deep_distance_scale),
        )
        qty = sample_limit_qty(cfg=self._ctx.cfg.size, rng=self._ctx.rng, mode=mode)
        new_order_id, trades = self._ctx.ob.replace(
            order_id,
            new_price_ticks=price_ticks,
            new_qty=qty,
            t=self._ctx.state.t,
        )
        executed_qty = int(sum(tr.qty for tr in trades))
        resting_qty = int(max(0, qty - executed_qty))
        self._ctx.append_event(
            event_type=event_type,
            side=side,
            price_ticks=int(price_ticks),
            qty=int(qty),
            order_id=None if new_order_id is None else int(new_order_id),
            placement_mode=mode,
            deep_distance=deep_distance,
            replaced_order_id=int(order_id),
            requested_qty=int(qty),
            executed_qty=executed_qty,
            resting_qty=resting_qty,
            canceled_qty=original_qty,
        )
        return trades
