from __future__ import annotations

from collections.abc import Callable
from typing import Protocol

from ..config import DepthMaintenanceConfig, StockGeneratorConfig
from ..orderbook import OrderBook
from ..sim_state import SimulationState
from ..types import DepthMaintenancePolicy, EventType, PlacementMode, Side


class EventAppender(Protocol):
    def __call__(
        self,
        *,
        event_type: EventType,
        side: Side,
        price_ticks: int | None,
        qty: int | None,
        order_id: int | None,
        synthetic: bool = False,
        reason: str | None = None,
        placement_mode: PlacementMode | None = None,
        deep_distance: int | None = None,
        replaced_order_id: int | None = None,
        requested_qty: int | None = None,
        executed_qty: int | None = None,
        resting_qty: int | None = None,
        canceled_qty: int | None = None,
    ) -> None: ...


def _target_qty_for_level(cfg: DepthMaintenanceConfig, *, level_index: int) -> int:
    base = cfg.target_level_qty if cfg.policy is DepthMaintenancePolicy.STRICT_TARGET else cfg.min_level_qty
    target = float(base) / (1.0 + float(cfg.level_decay) * float(level_index))
    return max(1, int(round(target)))


def apply_depth_maintenance(
    *,
    ob: OrderBook,
    state: SimulationState,
    cfg: StockGeneratorConfig,
    anchor_bests: Callable[[], tuple[int, int]],
    append_event: EventAppender,
) -> int:
    """Replenish top-of-book depth using synthetic limit orders.

    Returns the number of synthetic orders inserted in this invocation.
    """

    policy_cfg = cfg.depth_maintenance
    if policy_cfg.policy is DepthMaintenancePolicy.OFF:
        return 0
    if state.frame_index < policy_cfg.warmup_frames:
        return 0
    if policy_cfg.max_synthetic_orders_per_step <= 0:
        return 0

    best_bid = ob.best_price_ticks(Side.BID)
    best_ask = ob.best_price_ticks(Side.ASK)
    if best_bid is None or best_ask is None:
        # Let liquidity policy repair one-sided states first.
        return 0

    best_bid_anchor, best_ask_anchor = anchor_bests()
    levels = min(int(policy_cfg.target_levels), int(cfg.depth_levels))
    if levels <= 0:
        return 0

    bid_px, bid_qty, ask_px, ask_qty = ob.get_l2_ticks(levels)
    bid_by_px = {int(px): int(qty) for px, qty in zip(bid_px, bid_qty, strict=False)}
    ask_by_px = {int(px): int(qty) for px, qty in zip(ask_px, ask_qty, strict=False)}

    budget = int(policy_cfg.max_synthetic_orders_per_step)
    inserted = 0
    candidates: list[tuple[float, int, int, Side, int, int]] = []

    for side in (Side.BID, Side.ASK):
        level_qty_by_px = bid_by_px if side is Side.BID else ask_by_px
        anchor = int(best_bid_anchor if side is Side.BID else best_ask_anchor)
        side_rank = 0 if side is Side.BID else 1

        for level_index in range(levels):
            target_px = int(anchor - level_index if side is Side.BID else anchor + level_index)
            current_qty = int(level_qty_by_px.get(target_px, 0))
            target_qty = _target_qty_for_level(policy_cfg, level_index=level_index)
            deficit = target_qty - current_qty
            if deficit <= 0:
                continue

            add_qty = min(int(deficit), int(cfg.size.max_order_qty))
            if add_qty <= 0:
                continue

            # Favor deeper deficits enough to avoid permanent near-touch concentration.
            level_weight = 1.0 + (float(level_index) / max(1.0, float(levels - 1)))
            score = float(deficit) * level_weight
            candidates.append((score, level_index, side_rank, side, target_px, add_qty))

    if not candidates:
        return 0

    candidates.sort(
        key=lambda item: (
            0 if item[1] == 0 else 1 if item[1] == 1 else 2,  # level 0, then 1, then deeper
            -item[0],  # larger deficit-weighted score within each tier
            item[2],  # stable side ordering
        )
    )

    for _score, level_index, _side_rank, side, target_px, add_qty in candidates[:budget]:
        event_type = EventType.L_B if side is Side.BID else EventType.L_A
        order_id = ob.add_limit_resting(side=side, price_ticks=target_px, qty=add_qty)
        append_event(
            event_type=event_type,
            side=side,
            price_ticks=target_px,
            qty=add_qty,
            order_id=order_id,
            synthetic=True,
            reason="depth_maintenance",
            placement_mode=PlacementMode.JOIN if level_index == 0 else PlacementMode.DEEP,
            deep_distance=None if level_index == 0 else int(level_index),
            requested_qty=add_qty,
            executed_qty=0,
            resting_qty=add_qty,
        )
        inserted += 1

    return inserted
