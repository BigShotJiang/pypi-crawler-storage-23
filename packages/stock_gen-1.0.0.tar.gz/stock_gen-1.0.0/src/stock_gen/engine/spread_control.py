from __future__ import annotations

from typing import Protocol

from numpy.random import Generator

from ..config import StockGeneratorConfig
from ..models_size import sample_limit_qty
from ..orderbook import OrderBook
from ..sim_state import SimulationState
from ..types import EventType, PlacementMode, Side


class EventAppender(Protocol):
    def __call__(
        self,
        *,
        event_type: EventType,
        side: Side,
        price_ticks: int | None,
        qty: int | None,
        order_id: int | None,
        synthetic: bool = False,
        reason: str | None = None,
        placement_mode: PlacementMode | None = None,
        deep_distance: int | None = None,
        replaced_order_id: int | None = None,
        requested_qty: int | None = None,
        executed_qty: int | None = None,
        resting_qty: int | None = None,
        canceled_qty: int | None = None,
    ) -> None: ...


def apply_spread_control(
    *,
    ob: OrderBook,
    state: SimulationState,
    cfg: StockGeneratorConfig,
    rng: Generator,
    append_event: EventAppender,
) -> int:
    """Tighten the inside spread with synthetic limits before snapshot export."""

    sc = cfg.spread_control
    if not sc.enabled:
        return 0
    budget = int(sc.max_repair_orders_per_step)
    if budget <= 0:
        return 0

    best_bid = ob.best_price_ticks(Side.BID)
    best_ask = ob.best_price_ticks(Side.ASK)
    if best_bid is None or best_ask is None:
        return 0

    target = int(sc.target_spread_ticks)
    if target < 0:
        return 0
    if (not ob.allow_locked_book) and target <= 0:
        target = 1

    inserted = 0
    while inserted < budget:
        best_bid = ob.best_price_ticks(Side.BID)
        best_ask = ob.best_price_ticks(Side.ASK)
        if best_bid is None or best_ask is None:
            break
        spread = int(best_ask - best_bid)
        if spread <= target:
            break

        bid_qty = ob.best_qty(Side.BID)
        ask_qty = ob.best_qty(Side.ASK)
        prefer_bid = bid_qty <= ask_qty

        if prefer_bid:
            price_ticks = int(best_ask - target)
            if price_ticks <= best_bid:
                price_ticks = best_bid + 1
            if (not ob.allow_locked_book and price_ticks >= best_ask) or price_ticks < ob.min_price_ticks:
                break
            qty = sample_limit_qty(cfg=cfg.size, rng=rng, mode=PlacementMode.IMPROVE)
            order_id = ob.add_limit_resting(side=Side.BID, price_ticks=price_ticks, qty=qty)
            append_event(
                event_type=EventType.L_B,
                side=Side.BID,
                price_ticks=price_ticks,
                qty=qty,
                order_id=order_id,
                synthetic=True,
                reason="spread_control",
                placement_mode=PlacementMode.IMPROVE,
                requested_qty=qty,
                executed_qty=0,
                resting_qty=qty,
            )
            inserted += 1
            continue

        price_ticks = int(best_bid + target)
        if price_ticks >= best_ask:
            price_ticks = best_ask - 1
        if (not ob.allow_locked_book and price_ticks <= best_bid) or price_ticks < ob.min_price_ticks:
            break
        qty = sample_limit_qty(cfg=cfg.size, rng=rng, mode=PlacementMode.IMPROVE)
        order_id = ob.add_limit_resting(side=Side.ASK, price_ticks=price_ticks, qty=qty)
        append_event(
            event_type=EventType.L_A,
            side=Side.ASK,
            price_ticks=price_ticks,
            qty=qty,
            order_id=order_id,
            synthetic=True,
            reason="spread_control",
            placement_mode=PlacementMode.IMPROVE,
            requested_qty=qty,
            executed_qty=0,
            resting_qty=qty,
        )
        inserted += 1

    # Do not adjust streak here; frame_runner owns no-trade streak accounting.
    _ = state
    return inserted
