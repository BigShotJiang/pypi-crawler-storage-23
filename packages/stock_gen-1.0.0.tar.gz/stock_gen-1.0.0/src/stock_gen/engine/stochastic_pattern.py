from __future__ import annotations

import math
from dataclasses import dataclass

import numpy as np
from numpy.random import Generator

from ..sim_state import SimulationState
from ..types import Side


@dataclass(frozen=True, slots=True)
class PatternView:
    intensity_multiplier: float
    imbalance_shift: float
    placement_side_bias: float
    deep_distance_scale: float
    cancel_xi_shift: float


@dataclass(frozen=True, slots=True)
class PatternJumpShock:
    side: Side
    qty_scale: float


@dataclass(frozen=True, slots=True)
class _Regime:
    intensity_multiplier: float
    imbalance_shift: float
    placement_side_bias: float
    deep_distance_scale: float
    cancel_xi_shift: float
    jump_rate: float
    jump_scale: float
    mean_duration: float


_REGIMES: tuple[_Regime, ...] = (
    _Regime(
        intensity_multiplier=0.95,
        imbalance_shift=0.00,
        placement_side_bias=0.00,
        deep_distance_scale=1.00,
        cancel_xi_shift=0.00,
        jump_rate=0.0025,
        jump_scale=1.30,
        mean_duration=30.0,
    ),
    _Regime(
        intensity_multiplier=1.15,
        imbalance_shift=0.20,
        placement_side_bias=0.18,
        deep_distance_scale=0.90,
        cancel_xi_shift=0.07,
        jump_rate=0.0030,
        jump_scale=1.55,
        mean_duration=22.0,
    ),
    _Regime(
        intensity_multiplier=1.15,
        imbalance_shift=-0.20,
        placement_side_bias=-0.18,
        deep_distance_scale=0.90,
        cancel_xi_shift=-0.07,
        jump_rate=0.0030,
        jump_scale=1.55,
        mean_duration=22.0,
    ),
    _Regime(
        intensity_multiplier=0.78,
        imbalance_shift=0.00,
        placement_side_bias=0.00,
        deep_distance_scale=1.22,
        cancel_xi_shift=-0.10,
        jump_rate=0.0040,
        jump_scale=1.90,
        mean_duration=16.0,
    ),
)

_TRANSITION: tuple[tuple[float, ...], ...] = (
    (0.72, 0.12, 0.12, 0.04),
    (0.20, 0.62, 0.08, 0.10),
    (0.20, 0.08, 0.62, 0.10),
    (0.36, 0.18, 0.18, 0.28),
)


def ensure_pattern_state(*, state: SimulationState, rng: Generator) -> None:
    if state.pattern_regime >= 0 and state.pattern_time_remaining > 0.0:
        return
    if state.pattern_regime < 0:
        state.pattern_regime = int(rng.integers(0, len(_REGIMES)))
    regime = _REGIMES[state.pattern_regime]
    _apply_regime(state=state, regime=regime)
    state.pattern_time_remaining = _sample_duration(rng=rng, mean_duration=regime.mean_duration)
    state.pattern_jump_cooldown = max(0.0, float(state.pattern_jump_cooldown))


def advance_pattern_state(*, state: SimulationState, rng: Generator, elapsed: float) -> None:
    ensure_pattern_state(state=state, rng=rng)

    dt = max(0.0, float(elapsed))
    if dt > 0.0:
        state.pattern_jump_cooldown = max(0.0, float(state.pattern_jump_cooldown) - dt)

    remaining = float(state.pattern_time_remaining) - dt
    while remaining <= 0.0:
        state.pattern_regime = _sample_next_regime(rng=rng, current=state.pattern_regime)
        regime = _REGIMES[state.pattern_regime]
        _apply_regime(state=state, regime=regime)
        remaining += _sample_duration(rng=rng, mean_duration=regime.mean_duration)
    state.pattern_time_remaining = remaining


def current_pattern_view(*, state: SimulationState) -> PatternView:
    return PatternView(
        intensity_multiplier=float(state.pattern_intensity_multiplier),
        imbalance_shift=float(state.pattern_imbalance_shift),
        placement_side_bias=float(state.pattern_placement_side_bias),
        deep_distance_scale=float(state.pattern_deep_distance_scale),
        cancel_xi_shift=float(state.pattern_cancel_xi_shift),
    )


def maybe_sample_pattern_jump(
    *,
    state: SimulationState,
    rng: Generator,
    elapsed: float,
    has_bid: bool,
    has_ask: bool,
) -> PatternJumpShock | None:
    if float(elapsed) <= 0.0:
        return None
    if not has_bid or not has_ask:
        return None
    if float(state.pattern_jump_cooldown) > 0.0:
        return None

    regime = _REGIMES[state.pattern_regime] if state.pattern_regime >= 0 else _REGIMES[0]
    hazard = float(regime.jump_rate) * max(0.0, float(elapsed))
    p_jump = 1.0 - math.exp(-hazard)
    if float(rng.uniform()) >= p_jump:
        return None

    direction_score = float(state.pattern_imbalance_shift) + float(rng.normal(0.0, 0.35))
    side = Side.BID if direction_score >= 0.0 else Side.ASK
    qty_scale = float(regime.jump_scale) * float(rng.lognormal(mean=0.0, sigma=0.20))
    qty_scale = float(np.clip(qty_scale, 0.60, 4.00))
    state.pattern_jump_cooldown = float(rng.uniform(6.0, 14.0))
    return PatternJumpShock(side=side, qty_scale=qty_scale)


def _apply_regime(*, state: SimulationState, regime: _Regime) -> None:
    state.pattern_intensity_multiplier = float(regime.intensity_multiplier)
    state.pattern_imbalance_shift = float(regime.imbalance_shift)
    state.pattern_placement_side_bias = float(regime.placement_side_bias)
    state.pattern_deep_distance_scale = float(regime.deep_distance_scale)
    state.pattern_cancel_xi_shift = float(regime.cancel_xi_shift)


def _sample_next_regime(*, rng: Generator, current: int) -> int:
    probs = np.asarray(_TRANSITION[int(current)], dtype=np.float64)
    return int(rng.choice(len(_REGIMES), p=probs))


def _sample_duration(*, rng: Generator, mean_duration: float) -> float:
    # Gamma sampling keeps durations positive with moderate variance and stable tails.
    shape = 2.2
    scale = float(mean_duration) / shape
    return max(1e-6, float(rng.gamma(shape=shape, scale=scale)))
