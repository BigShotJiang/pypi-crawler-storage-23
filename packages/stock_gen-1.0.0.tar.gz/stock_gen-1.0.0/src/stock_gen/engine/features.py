from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from numpy.random import Generator
from numpy.typing import NDArray

from ..config import StockGeneratorConfig
from ..models_intensity import compute_lambdas, compute_phi
from ..orderbook import OrderBook
from ..sim_state import SimulationState
from ..types import EventType, Side


@dataclass(frozen=True, slots=True)
class EventLoopFeatures:
    """Derived order-book features and intensities for one event-loop instant."""

    has_bid: bool
    has_ask: bool
    spread_ticks: int | None
    best_bid_qty: int | None
    best_ask_qty: int | None
    imbalance: float | None
    phi: NDArray[np.float64]
    lambdas: dict[EventType, float]
    total_intensity: float


def compute_book_imbalance(*, ob: OrderBook) -> float | None:
    """Return total-quantity imbalance ``(bid-ask)/(bid+ask)``, or ``None`` when empty."""

    q_bid = ob.total_qty(Side.BID)
    q_ask = ob.total_qty(Side.ASK)
    denom = q_bid + q_ask
    if denom <= 0:
        return None
    return float((q_bid - q_ask) / denom)


def compute_event_loop_features(
    *,
    ob: OrderBook,
    state: SimulationState,
    cfg: StockGeneratorConfig,
    pattern_imbalance_shift: float = 0.0,
    pattern_intensity_multiplier: float = 1.0,
) -> EventLoopFeatures:
    """Build event-loop features and per-event intensities at current state."""

    best_bid = ob.best_price_ticks(Side.BID)
    best_ask = ob.best_price_ticks(Side.ASK)
    has_bid = best_bid is not None
    has_ask = best_ask is not None
    spread_ticks = int(best_ask - best_bid) if (best_bid is not None and best_ask is not None) else None

    best_bid_qty = ob.best_qty(Side.BID) if has_bid else None
    best_ask_qty = ob.best_qty(Side.ASK) if has_ask else None
    imbalance = compute_book_imbalance(ob=ob)
    if imbalance is not None:
        imbalance = float(np.clip(float(imbalance) + float(pattern_imbalance_shift), -0.999, 0.999))

    phi = compute_phi(
        spread_ticks=spread_ticks,
        best_bid_qty=best_bid_qty,
        best_ask_qty=best_ask_qty,
        imbalance=imbalance,
        recent_flow=state.recent_flow,
    )
    lambdas = compute_lambdas(
        cfg.intensity,
        phi,
        has_bid=has_bid,
        has_ask=has_ask,
        intensity_multiplier=float(cfg.regime.multiplier_at(state.t)) * float(pattern_intensity_multiplier),
    )
    total_intensity = float(sum(lambdas.values()))

    return EventLoopFeatures(
        has_bid=has_bid,
        has_ask=has_ask,
        spread_ticks=spread_ticks,
        best_bid_qty=best_bid_qty,
        best_ask_qty=best_ask_qty,
        imbalance=imbalance,
        phi=phi,
        lambdas=lambdas,
        total_intensity=total_intensity,
    )


def sample_event_type(
    *,
    rng: Generator,
    lambdas: dict[EventType, float],
    total_intensity: float,
) -> EventType:
    """Sample an event type from positive-rate events using normalized intensities."""

    if total_intensity <= 0.0:
        raise ValueError("total_intensity must be positive")

    events = [event for event in EventType if lambdas.get(event, 0.0) > 0.0]
    if not events:
        raise RuntimeError("no feasible events with positive intensity")

    weights = np.asarray([lambdas[event] for event in events], dtype=np.float64)
    probabilities = weights / float(total_intensity)
    index = int(rng.choice(len(events), p=probabilities))
    return events[index]
