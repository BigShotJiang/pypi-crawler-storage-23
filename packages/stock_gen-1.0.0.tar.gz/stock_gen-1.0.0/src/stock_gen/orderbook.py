from __future__ import annotations

from bisect import bisect_left
from collections import OrderedDict
from dataclasses import dataclass

from .types import Side, Trade


@dataclass(slots=True)
class PriceLevel:
    """One price level queue and aggregated quantity."""

    price_ticks: int
    orders: "OrderedDict[int, int]"
    total_qty: int

    @staticmethod
    def empty(price_ticks: int) -> "PriceLevel":
        return PriceLevel(price_ticks=price_ticks, orders=OrderedDict(), total_qty=0)


@dataclass(frozen=True, slots=True)
class OrderBookSnapshot:
    """Serializable in-memory snapshot for atomic step rollback."""

    bid_levels: dict[int, PriceLevel]
    ask_levels: dict[int, PriceLevel]
    bid_keys: list[int]
    ask_keys: list[int]
    order_index: dict[int, tuple[Side, int]]
    next_order_id: int
    total_bid_qty: int
    total_ask_qty: int


class OrderBook:
    """
    Order-level CLOB with price-time priority.

    Internal prices are integer ticks.
    """

    def __init__(self, *, min_price_ticks: int = 0, allow_locked_book: bool = False) -> None:
        if min_price_ticks < 0:
            raise ValueError("min_price_ticks must be >= 0")
        self._bid_levels: dict[int, PriceLevel] = {}
        self._ask_levels: dict[int, PriceLevel] = {}

        # Sorted keys (ascending). For bids: key = price_ticks. For asks: key = -price_ticks.
        self._bid_keys: list[int] = []
        self._ask_keys: list[int] = []

        self._order_index: dict[int, tuple[Side, int]] = {}
        self._next_order_id: int = 1

        self._total_bid_qty: int = 0
        self._total_ask_qty: int = 0
        self._min_price_ticks: int = int(min_price_ticks)
        self._allow_locked_book: bool = bool(allow_locked_book)

    @property
    def min_price_ticks(self) -> int:
        return int(self._min_price_ticks)

    @property
    def allow_locked_book(self) -> bool:
        return bool(self._allow_locked_book)

    def total_qty(self, side: Side) -> int:
        """Return total resting quantity on ``side``."""

        return self._total_bid_qty if side is Side.BID else self._total_ask_qty

    def best_price_ticks(self, side: Side) -> int | None:
        """Return best price in ticks for ``side`` or ``None`` when empty."""

        if side is Side.BID:
            return None if not self._bid_keys else int(self._bid_keys[-1])
        return None if not self._ask_keys else int(-self._ask_keys[-1])

    def best_qty(self, side: Side) -> int:
        """Return aggregated quantity resting at the best level for ``side``."""

        p = self.best_price_ticks(side)
        if p is None:
            return 0
        lvl = self._bid_levels[p] if side is Side.BID else self._ask_levels[p]
        return int(lvl.total_qty)

    def spread_ticks(self) -> int | None:
        """Return inside spread in ticks, or ``None`` when one side is missing."""

        bb = self.best_price_ticks(Side.BID)
        ba = self.best_price_ticks(Side.ASK)
        if bb is None or ba is None:
            return None
        return int(ba - bb)

    def _assert_not_crossed(self) -> None:
        """Validate resting-book invariant (strict when locked books are disallowed)."""

        best_bid = self.best_price_ticks(Side.BID)
        best_ask = self.best_price_ticks(Side.ASK)
        if best_bid is None or best_ask is None:
            return
        if self._allow_locked_book:
            if best_bid > best_ask:
                raise ValueError(f"crossed resting book: best_bid={best_bid} best_ask={best_ask}")
            return
        if best_bid >= best_ask:
            raise ValueError(f"locked/crossed resting book: best_bid={best_bid} best_ask={best_ask}")

    def _validate_resting_insert(self, *, side: Side, price_ticks: int) -> None:
        """Reject resting inserts that would leave the book crossed."""

        if price_ticks < self._min_price_ticks:
            raise ValueError(
                f"price_ticks {price_ticks} is below min_price_ticks {self._min_price_ticks}"
            )

        if side is Side.BID:
            best_ask = self.best_price_ticks(Side.ASK)
            if best_ask is not None:
                crossed = price_ticks > best_ask if self._allow_locked_book else price_ticks >= best_ask
            else:
                crossed = False
            if crossed:
                raise ValueError(
                    f"crossed resting book insert: bid price {price_ticks} {'>' if self._allow_locked_book else '>='} best ask {best_ask}"
                )
            return

        best_bid = self.best_price_ticks(Side.BID)
        if best_bid is not None:
            crossed = price_ticks < best_bid if self._allow_locked_book else price_ticks <= best_bid
        else:
            crossed = False
        if crossed:
            raise ValueError(
                f"crossed resting book insert: ask price {price_ticks} {'<' if self._allow_locked_book else '<='} best bid {best_bid}"
            )

    def add_limit_resting(self, side: Side, price_ticks: int, qty: int) -> int:
        """Insert a resting limit order and return its new order id."""

        if qty <= 0:
            raise ValueError("qty must be positive")
        order_id = self._next_order_id
        self._add_order_with_id(order_id=order_id, side=side, price_ticks=price_ticks, qty=qty)
        self._assert_not_crossed()
        return order_id

    def cancel(self, order_id: int) -> tuple[Side, int, int] | None:
        """Cancel an order fully and return ``(side, price_ticks, canceled_qty)``."""

        canceled = self.cancel_partial(order_id, qty=2**63 - 1)
        if canceled is None:
            return None
        side, price_ticks, canceled_qty, _remaining_qty = canceled
        return side, price_ticks, canceled_qty

    def cancel_partial(self, order_id: int, qty: int) -> tuple[Side, int, int, int] | None:
        """Cancel up to ``qty`` from a resting order and return cancellation details."""

        if qty <= 0:
            raise ValueError("qty must be positive")

        info = self._order_index.get(order_id)
        if info is None:
            return None
        side, price_ticks = info
        if side is Side.BID:
            lvl = self._bid_levels[price_ticks]
        else:
            lvl = self._ask_levels[price_ticks]

        order_qty = int(lvl.orders[order_id])
        canceled_qty = int(min(order_qty, qty))
        remaining_qty = int(order_qty - canceled_qty)

        if remaining_qty == 0:
            lvl.orders.pop(order_id)
            del self._order_index[order_id]
        else:
            lvl.orders[order_id] = remaining_qty

        lvl.total_qty -= canceled_qty

        if side is Side.BID:
            self._total_bid_qty -= canceled_qty
        else:
            self._total_ask_qty -= canceled_qty

        if not lvl.orders:
            self._remove_level(side=side, price_ticks=price_ticks)

        self._assert_not_crossed()
        return side, price_ticks, canceled_qty, remaining_qty

    def get_order(self, order_id: int) -> tuple[Side, int, int] | None:
        """Return ``(side, price_ticks, qty)`` for an order id if present."""

        info = self._order_index.get(order_id)
        if info is None:
            return None
        side, price_ticks = info
        lvl = self._bid_levels[price_ticks] if side is Side.BID else self._ask_levels[price_ticks]
        qty = int(lvl.orders[order_id])
        return side, int(price_ticks), qty

    def replace(
        self, order_id: int, *, new_price_ticks: int, new_qty: int, t: float = 0.0
    ) -> tuple[int | None, list[Trade]]:
        """Replace an order atomically as cancel-then-limit-submit."""

        if new_qty <= 0:
            raise ValueError("qty must be positive")

        checkpoint = self.snapshot()
        try:
            canceled = self.cancel(order_id)
            if canceled is None:
                raise KeyError(f"unknown order_id={order_id}")
            side, _old_price_ticks, _old_qty = canceled
            new_order_id, trades = self.process_limit(
                side=side,
                price_ticks=new_price_ticks,
                qty=new_qty,
                t=float(t),
            )
            self._assert_not_crossed()
            return new_order_id, trades
        except Exception:
            self.restore(checkpoint)
            raise

    def iter_orders_priority(self, side: Side):
        """Iterate resting orders in strict price-time priority for ``side``."""

        if side is Side.BID:
            for price in reversed(self._bid_keys):
                price_ticks = int(price)
                lvl = self._bid_levels[price_ticks]
                for order_id, qty in lvl.orders.items():
                    yield int(order_id), price_ticks, int(qty)
        else:
            for key in reversed(self._ask_keys):
                price_ticks = int(-key)
                lvl = self._ask_levels[price_ticks]
                for order_id, qty in lvl.orders.items():
                    yield int(order_id), price_ticks, int(qty)

    def get_l2_ticks(self, levels: int) -> tuple[list[int], list[int], list[int], list[int]]:
        """Return top-``levels`` L2 arrays in tick-space for both sides."""

        # Returns lists: bid_px_ticks, bid_qty, ask_px_ticks, ask_qty
        bid_px: list[int] = []
        bid_q: list[int] = []
        ask_px: list[int] = []
        ask_q: list[int] = []

        for key in reversed(self._bid_keys[-levels:]):
            price_ticks = int(key)
            bid_px.append(price_ticks)
            bid_q.append(int(self._bid_levels[price_ticks].total_qty))

        for key in reversed(self._ask_keys[-levels:]):
            price_ticks = int(-key)
            ask_px.append(price_ticks)
            ask_q.append(int(self._ask_levels[price_ticks].total_qty))

        return bid_px, bid_q, ask_px, ask_q

    def process_market(self, *, side: Side, qty: int, t: float) -> list[Trade]:
        """Execute an aggressive market order and return resulting trades."""

        if qty <= 0:
            raise ValueError("qty must be positive")
        trades, _remaining = self._consume_opposite(side=side, qty=qty, t=t, limit_price_ticks=None)
        self._assert_not_crossed()
        return trades

    def process_limit(
        self, *, side: Side, price_ticks: int, qty: int, t: float
    ) -> tuple[int | None, list[Trade]]:
        """Execute a limit order; return resting id (if any) and generated trades."""

        if qty <= 0:
            raise ValueError("qty must be positive")
        if price_ticks < self._min_price_ticks:
            raise ValueError(
                f"price_ticks {price_ticks} is below min_price_ticks {self._min_price_ticks}"
            )
        trades, remaining = self._consume_opposite(
            side=side, qty=qty, t=t, limit_price_ticks=price_ticks
        )
        if remaining <= 0:
            self._assert_not_crossed()
            return None, trades
        order_id = self.add_limit_resting(side=side, price_ticks=price_ticks, qty=remaining)
        self._assert_not_crossed()
        return order_id, trades

    def _consume_opposite(
        self, *, side: Side, qty: int, t: float, limit_price_ticks: int | None
    ) -> tuple[list[Trade], int]:
        trades: list[Trade] = []
        remaining = int(qty)

        if side is Side.BID:
            # consume asks
            while remaining > 0:
                best_ask = self.best_price_ticks(Side.ASK)
                if best_ask is None:
                    break
                if limit_price_ticks is not None and best_ask > limit_price_ticks:
                    break

                lvl = self._ask_levels[best_ask]
                while remaining > 0 and lvl.orders:
                    maker_id, maker_qty = next(iter(lvl.orders.items()))
                    fill = maker_qty if maker_qty < remaining else remaining
                    trades.append(Trade(t=t, price_ticks=best_ask, qty=fill, aggressor=Side.BID))

                    maker_qty -= fill
                    remaining -= fill
                    lvl.total_qty -= fill
                    self._total_ask_qty -= fill

                    if maker_qty == 0:
                        lvl.orders.popitem(last=False)
                        del self._order_index[maker_id]
                    else:
                        lvl.orders[maker_id] = maker_qty

                if not lvl.orders:
                    self._remove_level(side=Side.ASK, price_ticks=best_ask)
        else:
            # consume bids
            while remaining > 0:
                best_bid = self.best_price_ticks(Side.BID)
                if best_bid is None:
                    break
                if limit_price_ticks is not None and best_bid < limit_price_ticks:
                    break

                lvl = self._bid_levels[best_bid]
                while remaining > 0 and lvl.orders:
                    maker_id, maker_qty = next(iter(lvl.orders.items()))
                    fill = maker_qty if maker_qty < remaining else remaining
                    trades.append(Trade(t=t, price_ticks=best_bid, qty=fill, aggressor=Side.ASK))

                    maker_qty -= fill
                    remaining -= fill
                    lvl.total_qty -= fill
                    self._total_bid_qty -= fill

                    if maker_qty == 0:
                        lvl.orders.popitem(last=False)
                        del self._order_index[maker_id]
                    else:
                        lvl.orders[maker_id] = maker_qty

                if not lvl.orders:
                    self._remove_level(side=Side.BID, price_ticks=best_bid)

        return trades, remaining

    def snapshot(self) -> OrderBookSnapshot:
        """Capture a structural snapshot for rollback."""

        return OrderBookSnapshot(
            bid_levels=self._clone_levels(self._bid_levels),
            ask_levels=self._clone_levels(self._ask_levels),
            bid_keys=list(self._bid_keys),
            ask_keys=list(self._ask_keys),
            order_index=dict(self._order_index),
            next_order_id=int(self._next_order_id),
            total_bid_qty=int(self._total_bid_qty),
            total_ask_qty=int(self._total_ask_qty),
        )

    def restore(self, snapshot: OrderBookSnapshot) -> None:
        """Restore order-book state from ``snapshot``."""

        self._bid_levels = self._clone_levels(snapshot.bid_levels)
        self._ask_levels = self._clone_levels(snapshot.ask_levels)
        self._bid_keys = list(snapshot.bid_keys)
        self._ask_keys = list(snapshot.ask_keys)
        self._order_index = dict(snapshot.order_index)
        self._next_order_id = int(snapshot.next_order_id)
        self._total_bid_qty = int(snapshot.total_bid_qty)
        self._total_ask_qty = int(snapshot.total_ask_qty)
        self._assert_not_crossed()

    def _add_order_with_id(self, *, order_id: int, side: Side, price_ticks: int, qty: int) -> None:
        self._validate_resting_insert(side=side, price_ticks=price_ticks)
        if side is Side.BID:
            lvl = self._bid_levels.get(price_ticks)
            if lvl is None:
                lvl = PriceLevel.empty(price_ticks)
                self._bid_levels[price_ticks] = lvl
                self._insert_key(self._bid_keys, price_ticks)
            lvl.orders[order_id] = qty
            lvl.total_qty += qty
            self._total_bid_qty += qty
        else:
            lvl = self._ask_levels.get(price_ticks)
            if lvl is None:
                lvl = PriceLevel.empty(price_ticks)
                self._ask_levels[price_ticks] = lvl
                self._insert_key(self._ask_keys, -price_ticks)
            lvl.orders[order_id] = qty
            lvl.total_qty += qty
            self._total_ask_qty += qty

        self._order_index[order_id] = (side, price_ticks)
        if order_id >= self._next_order_id:
            self._next_order_id = order_id + 1

    def _remove_level(self, *, side: Side, price_ticks: int) -> None:
        if side is Side.BID:
            del self._bid_levels[price_ticks]
            self._remove_key(self._bid_keys, price_ticks)
        else:
            del self._ask_levels[price_ticks]
            self._remove_key(self._ask_keys, -price_ticks)

    @staticmethod
    def _insert_key(keys: list[int], key: int) -> None:
        i = bisect_left(keys, key)
        keys.insert(i, key)

    @staticmethod
    def _remove_key(keys: list[int], key: int) -> None:
        i = bisect_left(keys, key)
        if i >= len(keys) or keys[i] != key:
            raise KeyError(f"missing price key={key}")
        keys.pop(i)

    @staticmethod
    def _clone_levels(levels: dict[int, PriceLevel]) -> dict[int, PriceLevel]:
        return {
            int(price): PriceLevel(
                price_ticks=int(level.price_ticks),
                orders=OrderedDict((int(order_id), int(qty)) for order_id, qty in level.orders.items()),
                total_qty=int(level.total_qty),
            )
            for price, level in levels.items()
        }
