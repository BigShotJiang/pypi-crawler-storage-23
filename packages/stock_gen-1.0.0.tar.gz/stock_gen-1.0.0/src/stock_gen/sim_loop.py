from __future__ import annotations

from dataclasses import dataclass


@dataclass(slots=True)
class StepStats:
    events_processed: int = 0
    truncated: bool = False
    t_last_event: float | None = None

    def record_event(self, *, t: float) -> None:
        self.events_processed += 1
        self.t_last_event = float(t)
