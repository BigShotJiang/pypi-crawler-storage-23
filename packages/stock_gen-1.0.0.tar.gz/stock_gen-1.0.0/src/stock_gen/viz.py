"""Visualization helpers for MarketHistory and StockGenerator outputs."""

from __future__ import annotations

from typing import Literal

import numpy as np

from .types import MarketHistory


def _as_history(obj: MarketHistory | object) -> MarketHistory:
    if isinstance(obj, MarketHistory):
        return obj
    get_history = getattr(obj, "get_history", None)
    if callable(get_history):
        hist = get_history()
        if isinstance(hist, MarketHistory):
            return hist
    raise TypeError("expected MarketHistory or an object with get_history() -> MarketHistory")


def plot_mid(obj: MarketHistory | object, *, ax=None):
    """Plot mid-price time series."""

    import matplotlib.pyplot as plt

    hist = _as_history(obj)
    data = hist.to_numpy(as_ticks=False)
    if ax is None:
        _, ax = plt.subplots(1, 1, figsize=(9, 3))
    ax.plot(data["t"], data["mid"], lw=1.2)
    ax.set_title("Mid Price")
    ax.set_xlabel("t")
    ax.set_ylabel("price")
    ax.grid(True, alpha=0.2)
    return ax


def plot_spread(obj: MarketHistory | object, *, ax=None, in_ticks: bool = True):
    """Plot spread series in ticks or price units."""

    import matplotlib.pyplot as plt

    hist = _as_history(obj)
    data = hist.to_numpy(as_ticks=True)
    if ax is None:
        _, ax = plt.subplots(1, 1, figsize=(9, 3))
    y = data["spread_ticks"].astype(np.float64)
    if not in_ticks:
        y = y * float(hist.tick_size)
    ax.plot(data["t"], y, lw=1.2)
    ax.set_title("Spread" + (" (ticks)" if in_ticks else ""))
    ax.set_xlabel("t")
    ax.set_ylabel("spread")
    ax.grid(True, alpha=0.2)
    return ax


def plot_l2_heatmap(
    obj: MarketHistory | object,
    *,
    side: Literal["bid", "ask", "both"] = "both",
    space: Literal["rank", "price"] = "price",
    price_window_ticks: int | Literal["auto"] = "auto",
    y_range: Literal["auto", "full", "side", "occupied"] = "auto",
    cmap: str = "viridis",
    mask_invalid: bool = True,
    normalize: Literal["none", "log1p"] = "log1p",
    vmax_quantile: float | None = 0.99,
):
    """Plot top-K depth quantity heatmap.

    Args:
        obj: Market history or simulator-like object with ``get_history``.
        side: ``\"bid\"``, ``\"ask\"``, or ``\"both\"``.
        space: Heatmap y-axis space: level ``\"rank\"`` or relative ``\"price\"`` bins.
        price_window_ticks: Relative window for price bins, or ``\"auto\"`` from observed depth.
        y_range: Price-space range mode. ``\"auto\"`` picks compact defaults.
        cmap: Matplotlib colormap name.
        mask_invalid: When ``True``, invalid L2 levels are rendered as NaN.
        normalize: Quantity transform; ``\"log1p\"`` improves long-horizon contrast.
        vmax_quantile: Optional upper quantile cap for color scaling.
    """

    import matplotlib.pyplot as plt

    hist = _as_history(obj)
    data = hist.to_numpy(as_ticks=True)
    _ = data["t"]  # reserved for future time-axis formatting

    if space not in ("rank", "price"):
        raise ValueError("space must be one of: 'rank', 'price'")
    if y_range not in ("auto", "full", "side", "occupied"):
        raise ValueError("y_range must be one of: 'auto', 'full', 'side', 'occupied'")
    y_range_mode = _resolve_y_range_mode(y_range=y_range, side=side)

    mid_ticks = data["mid"].astype(np.float64) / float(hist.tick_size)
    mid_valid = data["mid_valid"].astype(bool)

    def _plot_one(
        ax,
        qty: np.ndarray,
        px_ticks: np.ndarray,
        valid: np.ndarray,
        title: str,
        *,
        side_name: Literal["bid", "ask"],
    ):
        # rank space: (N, K), price space: (N, 2*window+1)
        if space == "rank":
            qty_matrix = qty
            valid_matrix = valid
            ylabel = "level (0=best)"
        else:
            window_ticks = _resolve_price_window_ticks(
                price_window_ticks=price_window_ticks,
                px_ticks=px_ticks,
                valid=valid,
                mid_ticks=mid_ticks,
                mid_valid=mid_valid,
                side=side_name,
                y_range=y_range_mode,
            )
            qty_matrix, valid_matrix = _prepare_price_space_matrix(
                qty=qty,
                px_ticks=px_ticks,
                valid=valid,
                mid_ticks=mid_ticks,
                mid_valid=mid_valid,
                price_window_ticks=window_ticks,
            )
            qty_matrix, valid_matrix, rel_min, rel_max = _crop_price_space_matrix(
                qty=qty_matrix,
                valid=valid_matrix,
                price_window_ticks=window_ticks,
                side=side_name,
                y_range=y_range_mode,
            )
            if y_range_mode == "full":
                ylabel = f"ticks from mid (-{window_ticks}..+{window_ticks})"
            else:
                ylabel = f"ticks from mid ({rel_min:+d}..{rel_max:+d})"

        values, vmax = _prepare_heatmap_matrix(
            qty=qty_matrix,
            valid=valid_matrix,
            mask_invalid=mask_invalid,
            normalize=normalize,
            vmax_quantile=vmax_quantile,
        )
        cmap_obj = plt.get_cmap(cmap).copy()
        cmap_obj.set_bad(color="#f2f2f2")
        im = ax.imshow(values.T, aspect="auto", origin="upper", cmap=cmap_obj, vmin=0.0, vmax=vmax)
        ax.set_title(title)
        ax.set_xlabel("frame")
        ax.set_ylabel(ylabel)
        plt.colorbar(im, ax=ax, fraction=0.046, pad=0.04)

    if side == "both":
        fig, axes = plt.subplots(2, 1, figsize=(10, 6), sharex=True)
        _plot_one(
            axes[0],
            data["bid_qty"],
            data["bid_px_ticks"],
            data["bid_px_valid"],
            "Bid L2 Qty Heatmap",
            side_name="bid",
        )
        _plot_one(
            axes[1],
            data["ask_qty"],
            data["ask_px_ticks"],
            data["ask_px_valid"],
            "Ask L2 Qty Heatmap",
            side_name="ask",
        )
        if space == "rank":
            fig.suptitle("L2 Depth (Top-K)")
        else:
            fig.suptitle("L2 Depth (Relative Price)")
        return axes

    fig, ax = plt.subplots(1, 1, figsize=(10, 3))
    if side == "bid":
        _plot_one(
            ax,
            data["bid_qty"],
            data["bid_px_ticks"],
            data["bid_px_valid"],
            "Bid L2 Qty Heatmap",
            side_name="bid",
        )
    elif side == "ask":
        _plot_one(
            ax,
            data["ask_qty"],
            data["ask_px_ticks"],
            data["ask_px_valid"],
            "Ask L2 Qty Heatmap",
            side_name="ask",
        )
    else:
        raise ValueError("side must be one of: 'bid', 'ask', 'both'")
    return ax


def _resolve_y_range_mode(
    *,
    y_range: Literal["auto", "full", "side", "occupied"],
    side: Literal["bid", "ask", "both"],
) -> Literal["full", "side", "occupied"]:
    if y_range != "auto":
        return y_range
    if side == "both":
        return "occupied"
    return "side"


def _resolve_price_window_ticks(
    *,
    price_window_ticks: int | Literal["auto"],
    px_ticks: np.ndarray,
    valid: np.ndarray,
    mid_ticks: np.ndarray,
    mid_valid: np.ndarray,
    side: Literal["bid", "ask"],
    y_range: Literal["full", "side", "occupied"],
) -> int:
    if isinstance(price_window_ticks, (int, np.integer)) and not isinstance(price_window_ticks, (bool, np.bool_)):
        window_ticks = int(price_window_ticks)
        if window_ticks <= 0:
            raise ValueError("price_window_ticks must be a positive int or 'auto'")
        return window_ticks
    if price_window_ticks != "auto":
        raise ValueError("price_window_ticks must be a positive int or 'auto'")

    rel_ticks = _collect_relative_ticks(
        px_ticks=px_ticks,
        valid=valid,
        mid_ticks=mid_ticks,
        mid_valid=mid_valid,
    )
    if y_range == "side":
        if side == "bid":
            rel_ticks = rel_ticks[rel_ticks <= 0]
        else:
            rel_ticks = rel_ticks[rel_ticks >= 0]

    if rel_ticks.size == 0:
        return 1
    return max(1, int(np.max(np.abs(rel_ticks))))


def _collect_relative_ticks(
    *,
    px_ticks: np.ndarray,
    valid: np.ndarray,
    mid_ticks: np.ndarray,
    mid_valid: np.ndarray,
) -> np.ndarray:
    if px_ticks.shape != valid.shape:
        raise ValueError("px_ticks and valid must have the same shape")
    if px_ticks.ndim != 2:
        raise ValueError("px_ticks and valid must be 2D arrays")
    if mid_ticks.shape != (px_ticks.shape[0],) or mid_valid.shape != (px_ticks.shape[0],):
        raise ValueError("mid_ticks and mid_valid must match frame dimension")

    rel_rows: list[np.ndarray] = []
    for i in range(px_ticks.shape[0]):
        if not mid_valid[i] or not np.isfinite(mid_ticks[i]):
            continue
        row_valid = valid[i]
        if not np.any(row_valid):
            continue
        row_px = px_ticks[i, row_valid].astype(np.float64)
        rel_rows.append(np.floor(row_px - float(mid_ticks[i])).astype(np.int64))
    if not rel_rows:
        return np.asarray([], dtype=np.int64)
    return np.concatenate(rel_rows)


def _crop_price_space_matrix(
    *,
    qty: np.ndarray,
    valid: np.ndarray,
    price_window_ticks: int,
    side: Literal["bid", "ask"],
    y_range: Literal["full", "side", "occupied"],
) -> tuple[np.ndarray, np.ndarray, int, int]:
    if qty.shape != valid.shape:
        raise ValueError("qty and valid must have the same shape")
    if qty.ndim != 2:
        raise ValueError("qty and valid must be 2D arrays")

    n_bins = qty.shape[1]
    if n_bins != 2 * price_window_ticks + 1:
        raise ValueError("price_window_ticks does not match matrix width")
    center = price_window_ticks

    if y_range == "full":
        start = 0
        stop = n_bins
    elif y_range == "side":
        if side == "bid":
            start = 0
            stop = center + 1
        else:
            start = center
            stop = n_bins
    else:  # occupied
        occupied = np.any(valid, axis=0)
        if np.any(occupied):
            start = int(np.argmax(occupied))
            stop = n_bins - int(np.argmax(occupied[::-1]))
        elif side == "bid":
            start = 0
            stop = center + 1
        else:
            start = center
            stop = n_bins

    rel_min = start - center
    rel_max = (stop - 1) - center
    return qty[:, start:stop], valid[:, start:stop], rel_min, rel_max


def _prepare_price_space_matrix(
    *,
    qty: np.ndarray,
    px_ticks: np.ndarray,
    valid: np.ndarray,
    mid_ticks: np.ndarray,
    mid_valid: np.ndarray,
    price_window_ticks: int,
) -> tuple[np.ndarray, np.ndarray]:
    if price_window_ticks <= 0:
        raise ValueError("price_window_ticks must be positive")
    if qty.shape != px_ticks.shape or qty.shape != valid.shape:
        raise ValueError("qty, px_ticks, and valid must have the same shape")
    if qty.ndim != 2:
        raise ValueError("qty, px_ticks, and valid must be 2D arrays")
    if mid_ticks.shape != (qty.shape[0],) or mid_valid.shape != (qty.shape[0],):
        raise ValueError("mid_ticks and mid_valid must match frame dimension")

    n_frames = qty.shape[0]
    n_bins = 2 * price_window_ticks + 1
    agg_qty = np.zeros((n_frames, n_bins), dtype=np.float64)
    agg_valid = np.zeros((n_frames, n_bins), dtype=bool)

    for i in range(n_frames):
        if not mid_valid[i] or not np.isfinite(mid_ticks[i]):
            continue
        row_valid = valid[i]
        if not np.any(row_valid):
            continue

        row_px = px_ticks[i, row_valid].astype(np.float64)
        row_qty = qty[i, row_valid].astype(np.float64)
        rel_ticks = np.floor(row_px - float(mid_ticks[i])).astype(np.int64)
        in_window = (rel_ticks >= -price_window_ticks) & (rel_ticks <= price_window_ticks)
        if not np.any(in_window):
            continue

        bin_idx = rel_ticks[in_window] + price_window_ticks
        np.add.at(agg_qty[i], bin_idx, row_qty[in_window])
        agg_valid[i, bin_idx] = True

    return agg_qty, agg_valid


def _prepare_heatmap_matrix(
    *,
    qty: np.ndarray,
    valid: np.ndarray,
    mask_invalid: bool,
    normalize: Literal["none", "log1p"],
    vmax_quantile: float | None,
) -> tuple[np.ndarray, float | None]:
    values = qty.astype(np.float64, copy=True)
    if mask_invalid:
        values[~valid] = np.nan

    if normalize == "none":
        pass
    elif normalize == "log1p":
        values = np.log1p(values)
    else:
        raise ValueError("normalize must be one of: 'none', 'log1p'")

    vmax: float | None = None
    if vmax_quantile is not None:
        if vmax_quantile <= 0.0 or vmax_quantile > 1.0:
            raise ValueError("vmax_quantile must be in (0, 1] when provided")
        finite = values[np.isfinite(values)]
        if finite.size > 0:
            vmax = float(np.quantile(finite, vmax_quantile))
            if vmax <= 0.0:
                vmax = None

    return values, vmax
