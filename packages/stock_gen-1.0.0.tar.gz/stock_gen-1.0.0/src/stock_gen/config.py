"""Public configuration dataclasses for stock-gen."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Literal

import numpy as np
from numpy.typing import NDArray

from .types import DepthMaintenancePolicy, EventCapPolicy, EventType, LiquidityPolicy

PHI_DIM: int = 6
JOINT_FLOW_FEATURE_DIM: int = 9
JOINT_FLOW_ACTION_DIM: int = 12


@dataclass(frozen=True, slots=True)
class ExpLinearIntensityConfig:
    """Exponential-linear intensity model configuration."""

    theta: dict[EventType, NDArray[np.float64]] = field(default_factory=dict)
    min_lambda: float = 1e-12
    exp_clip: float = 50.0

    def __post_init__(self) -> None:
        if self.min_lambda <= 0.0:
            raise ValueError("min_lambda must be > 0")
        if self.exp_clip <= 0.0:
            raise ValueError("exp_clip must be > 0")
        for event_type, theta in self.theta.items():
            if not isinstance(event_type, EventType):
                raise TypeError(f"theta key must be EventType, got {type(event_type)!r}")
            if theta.shape != (PHI_DIM,):
                raise ValueError(
                    f"theta[{event_type.value}] must be shape ({PHI_DIM},), got {theta.shape}"
                )

    @staticmethod
    def default() -> "ExpLinearIntensityConfig":
        """Return the baseline intensity model used by default simulator runs."""

        # phi = [1, log1p(spread_ticks), log1p(best_bid_qty), log1p(best_ask_qty), imbalance, recent_flow]
        t: dict[EventType, NDArray[np.float64]] = {}

        def v(*xs: float) -> NDArray[np.float64]:
            arr = np.asarray(xs, dtype=np.float64)
            if arr.shape != (PHI_DIM,):
                raise ValueError(f"theta must be shape ({PHI_DIM},), got {arr.shape}")
            return arr

        t[EventType.L_B] = v(+0.1, +0.5, -0.15, +0.0, -0.25, +0.0)
        t[EventType.L_A] = v(+0.1, +0.5, +0.0, -0.15, +0.25, +0.0)

        t[EventType.M_B] = v(-1.4, -0.7, +0.0, +0.05, -0.20, -0.25)
        t[EventType.M_A] = v(-1.4, -0.7, +0.05, +0.0, +0.20, +0.25)

        t[EventType.C_B] = v(-0.7, +0.0, +0.25, +0.0, +0.08, +0.0)
        t[EventType.C_A] = v(-0.7, +0.0, +0.0, +0.25, -0.08, +0.0)

        # Replace is supported by the engine, but disabled in the default v1 generator
        # by omitting it from theta.

        return ExpLinearIntensityConfig(theta=t)


@dataclass(frozen=True, slots=True)
class PlacementConfig:
    """Limit-order placement sampler configuration."""

    # logits = W @ [1, log1p(spread_ticks), side_imbalance]
    # where side_imbalance = imbalance (bid) or -imbalance (ask)
    W: NDArray[np.float64] = field(
        default_factory=lambda: np.asarray(
            [
                [-0.55, +1.20, +0.85],  # improve
                [+0.55, -0.20, +0.10],  # join
                [-0.05, -0.15, -0.25],  # deep
            ],
            dtype=np.float64,
        )
    )
    p_deep: float = 0.40
    deep_max_ticks: int = 200

    def __post_init__(self) -> None:
        if self.W.shape != (3, 3):
            raise ValueError(f"W must be shape (3, 3), got {self.W.shape}")
        if self.p_deep <= 0.0 or self.p_deep > 1.0:
            raise ValueError("p_deep must be in (0, 1]")
        if self.deep_max_ticks <= 0:
            raise ValueError("deep_max_ticks must be positive")


@dataclass(frozen=True, slots=True)
class SizeConfig:
    """Order-size model configuration."""

    market_mu: float = 0.95
    market_sigma: float = 0.85

    improve_mu: float = 1.35
    improve_sigma: float = 0.8

    join_mu: float = 1.25
    join_sigma: float = 0.85

    deep_mu: float = 1.15
    deep_sigma: float = 0.9

    max_order_qty: int = 1_000

    def __post_init__(self) -> None:
        if self.market_sigma < 0.0 or self.improve_sigma < 0.0 or self.join_sigma < 0.0 or self.deep_sigma < 0.0:
            raise ValueError("all sigma values must be >= 0")
        if self.max_order_qty <= 0:
            raise ValueError("max_order_qty must be positive")


@dataclass(frozen=True, slots=True)
class CancelConfig:
    """Cancellation priority and partial-cancel behavior."""

    beta_a: float = 4.6
    beta_b: float = 2.3
    partial_cancel_prob: float = 0.30
    partial_min_ratio: float = 0.2

    def __post_init__(self) -> None:
        if self.beta_a <= 0.0 or self.beta_b <= 0.0:
            raise ValueError("beta_a and beta_b must be > 0")
        if self.partial_cancel_prob < 0.0 or self.partial_cancel_prob > 1.0:
            raise ValueError("partial_cancel_prob must be in [0, 1]")
        if self.partial_min_ratio <= 0.0 or self.partial_min_ratio > 1.0:
            raise ValueError("partial_min_ratio must be in (0, 1]")


@dataclass(frozen=True, slots=True)
class RegimeSegment:
    """Time interval and intensity multiplier for intraday regime control."""

    start_time: float
    end_time: float
    multiplier: float

    def __post_init__(self) -> None:
        if self.start_time < 0.0:
            raise ValueError("start_time must be >= 0")
        if self.end_time <= self.start_time:
            raise ValueError("end_time must be > start_time")
        if self.multiplier <= 0.0:
            raise ValueError("multiplier must be > 0")


@dataclass(frozen=True, slots=True)
class RegimeConfig:
    """Optional intraday intensity regime schedule."""

    segments: tuple[RegimeSegment, ...] = ()

    def __post_init__(self) -> None:
        prev_end = -1.0
        for seg in self.segments:
            if seg.start_time < prev_end:
                raise ValueError("regime segments must be non-overlapping and sorted by start_time")
            prev_end = float(seg.end_time)

    def multiplier_at(self, t: float) -> float:
        """Return active multiplier at simulation time ``t``."""

        x = float(t)
        for seg in self.segments:
            if seg.start_time <= x < seg.end_time:
                return float(seg.multiplier)
        return 1.0


@dataclass(frozen=True, slots=True)
class DepthMaintenanceConfig:
    """Synthetic depth replenishment policy and thresholds."""

    policy: DepthMaintenancePolicy = DepthMaintenancePolicy.SOFT_TARGET
    target_levels: int = 10
    min_level_qty: int = 2
    target_level_qty: int = 7
    level_decay: float = 0.30
    max_synthetic_orders_per_step: int = 8
    warmup_frames: int = 0

    def __post_init__(self) -> None:
        if not isinstance(self.policy, DepthMaintenancePolicy):
            raise TypeError("depth_maintenance.policy must be a DepthMaintenancePolicy")
        if self.target_levels <= 0:
            raise ValueError("target_levels must be positive")
        if self.min_level_qty <= 0:
            raise ValueError("min_level_qty must be positive")
        if self.target_level_qty <= 0:
            raise ValueError("target_level_qty must be positive")
        if self.min_level_qty > self.target_level_qty:
            raise ValueError("min_level_qty must be <= target_level_qty")
        if self.level_decay < 0.0:
            raise ValueError("level_decay must be >= 0")
        if self.max_synthetic_orders_per_step < 0:
            raise ValueError("max_synthetic_orders_per_step must be >= 0")
        if self.warmup_frames < 0:
            raise ValueError("warmup_frames must be >= 0")


def _default_joint_flow_logits() -> NDArray[np.float64]:
    """Baseline joint-action logits (rows = categories, cols = feature vector)."""

    return np.asarray(
        [
            [+0.05, +1.10, -0.08, +0.03, -0.25, -0.05, -0.30, -0.10, -0.15],  # L_B_IMPROVE
            [+0.20, +0.35, -0.05, +0.00, -0.10, -0.02, -0.10, -0.05, -0.10],  # L_B_JOIN
            [-0.70, -0.10, +0.08, +0.08, -0.05, +0.00, -0.10, +0.00, -0.05],  # L_B_DEEP
            [+0.05, +1.10, +0.03, -0.08, +0.25, +0.05, -0.30, -0.10, -0.15],  # L_A_IMPROVE
            [+0.20, +0.35, +0.00, -0.05, +0.10, +0.02, -0.10, -0.05, -0.10],  # L_A_JOIN
            [-0.70, -0.10, +0.08, +0.08, +0.05, +0.00, -0.10, +0.00, -0.05],  # L_A_DEEP
            [+0.60, -0.25, +0.00, +0.05, -0.15, -0.20, +1.20, -1.10, +0.20],  # M_B
            [+0.60, -0.25, +0.05, +0.00, +0.15, +0.20, +1.20, -1.10, +0.20],  # M_A
            [-1.20, +0.00, +0.22, +0.00, +0.08, +0.00, -0.30, -0.20, +1.20],  # C_B_AGGR
            [-1.55, +0.00, +0.28, +0.00, +0.04, +0.00, -0.35, -0.20, +1.20],  # C_B_PASSIVE
            [-1.20, +0.00, +0.00, +0.22, -0.08, +0.00, -0.30, -0.20, +1.20],  # C_A_AGGR
            [-1.55, +0.00, +0.00, +0.28, -0.04, +0.00, -0.35, -0.20, +1.20],  # C_A_PASSIVE
        ],
        dtype=np.float64,
    )


@dataclass(frozen=True, slots=True)
class JointFlowConfig:
    """Joint event/side/style flow model configuration."""

    action_logits: NDArray[np.float64] = field(default_factory=_default_joint_flow_logits)
    adaptation_enabled: bool = True
    adaptation_warmup_events: int = 0
    market_share_floor: float = 0.20
    market_share_ceiling: float = 0.55
    cancel_share_floor: float = 0.10
    cancel_share_ceiling: float = 0.48
    adaptation_strength: float = 18.0
    max_adaptation_shift: float = 6.0

    def __post_init__(self) -> None:
        if self.action_logits.shape != (JOINT_FLOW_ACTION_DIM, JOINT_FLOW_FEATURE_DIM):
            raise ValueError(
                "action_logits must be shape "
                f"({JOINT_FLOW_ACTION_DIM}, {JOINT_FLOW_FEATURE_DIM}), got {self.action_logits.shape}"
            )
        if self.adaptation_warmup_events < 0:
            raise ValueError("adaptation_warmup_events must be >= 0")
        if self.adaptation_strength < 0.0:
            raise ValueError("adaptation_strength must be >= 0")
        if self.max_adaptation_shift < 0.0:
            raise ValueError("max_adaptation_shift must be >= 0")
        if self.market_share_floor < 0.0 or self.market_share_floor > 1.0:
            raise ValueError("market_share_floor must be in [0, 1]")
        if self.market_share_ceiling < 0.0 or self.market_share_ceiling > 1.0:
            raise ValueError("market_share_ceiling must be in [0, 1]")
        if self.cancel_share_floor < 0.0 or self.cancel_share_floor > 1.0:
            raise ValueError("cancel_share_floor must be in [0, 1]")
        if self.cancel_share_ceiling < 0.0 or self.cancel_share_ceiling > 1.0:
            raise ValueError("cancel_share_ceiling must be in [0, 1]")
        if self.market_share_floor > self.market_share_ceiling:
            raise ValueError("market_share_floor must be <= market_share_ceiling")
        if self.cancel_share_floor > self.cancel_share_ceiling:
            raise ValueError("cancel_share_floor must be <= cancel_share_ceiling")


@dataclass(frozen=True, slots=True)
class SpreadControlConfig:
    """Synthetic spread-tightening controls applied near snapshot boundaries."""

    enabled: bool = True
    target_spread_ticks: int = 1
    enforce_at_snapshot: bool = True
    max_repair_orders_per_step: int = 2

    def __post_init__(self) -> None:
        if self.target_spread_ticks < 0:
            raise ValueError("target_spread_ticks must be >= 0")
        if self.max_repair_orders_per_step < 0:
            raise ValueError("max_repair_orders_per_step must be >= 0")


@dataclass(frozen=True, slots=True)
class BookConstraintConfig:
    """Core order-book structural constraints."""

    min_price_ticks: int = 0
    allow_locked_book: bool = False

    def __post_init__(self) -> None:
        if self.min_price_ticks < 0:
            raise ValueError("min_price_ticks must be >= 0")


@dataclass(frozen=True, slots=True)
class StockGeneratorConfig:
    """Top-level immutable configuration for StockGenerator."""

    tick_size: float = 1.0
    dt: float = 1.0
    end_time: float = 600.0
    depth_levels: int = 10
    flow_kernel: Literal["joint_v1", "legacy_factorized"] = "joint_v1"

    seed: int | None = 123

    initial_mid_price: float | None = None
    initial_spread_ticks: int = 1
    init_levels_per_side: int = 50
    init_orders_per_level: int = 3

    max_events_per_step: int = 50_000

    # EWMA half-life for recent aggressive flow (in simulation time units).
    flow_half_life: float = 10.0
    liquidity_policy: LiquidityPolicy = LiquidityPolicy.REPAIR
    event_cap_policy: EventCapPolicy = EventCapPolicy.RAISE

    intensity: ExpLinearIntensityConfig = field(default_factory=ExpLinearIntensityConfig.default)
    placement: PlacementConfig = field(default_factory=PlacementConfig)
    size: SizeConfig = field(default_factory=SizeConfig)
    cancel: CancelConfig = field(default_factory=CancelConfig)
    regime: RegimeConfig = field(default_factory=RegimeConfig)
    depth_maintenance: DepthMaintenanceConfig = field(default_factory=DepthMaintenanceConfig)
    joint_flow: JointFlowConfig = field(default_factory=JointFlowConfig)
    spread_control: SpreadControlConfig = field(default_factory=SpreadControlConfig)
    book_constraints: BookConstraintConfig = field(default_factory=BookConstraintConfig)

    def __post_init__(self) -> None:
        if self.tick_size <= 0.0:
            raise ValueError("tick_size must be positive")
        if self.dt <= 0.0:
            raise ValueError("dt must be positive")
        if self.end_time < 0.0:
            raise ValueError("end_time must be >= 0")
        if self.depth_levels <= 0:
            raise ValueError("depth_levels must be positive")
        if self.flow_kernel not in ("joint_v1", "legacy_factorized"):
            raise ValueError("flow_kernel must be one of {'joint_v1', 'legacy_factorized'}")
        if self.initial_mid_price is not None and self.initial_mid_price <= 0.0:
            raise ValueError("initial_mid_price must be positive when provided")
        if self.initial_spread_ticks <= 0:
            raise ValueError("initial_spread_ticks must be positive")
        if self.init_levels_per_side <= 0 or self.init_orders_per_level <= 0:
            raise ValueError("init_levels_per_side and init_orders_per_level must be positive")
        if self.max_events_per_step <= 0:
            raise ValueError("max_events_per_step must be positive")
        if self.flow_half_life < 0.0:
            raise ValueError("flow_half_life must be >= 0")
        if not isinstance(self.liquidity_policy, LiquidityPolicy):
            raise TypeError("liquidity_policy must be a LiquidityPolicy")
        if not isinstance(self.event_cap_policy, EventCapPolicy):
            raise TypeError("event_cap_policy must be an EventCapPolicy")
        if not isinstance(self.intensity, ExpLinearIntensityConfig):
            raise TypeError("intensity must be ExpLinearIntensityConfig")
        if not isinstance(self.placement, PlacementConfig):
            raise TypeError("placement must be PlacementConfig")
        if not isinstance(self.size, SizeConfig):
            raise TypeError("size must be SizeConfig")
        if not isinstance(self.cancel, CancelConfig):
            raise TypeError("cancel must be CancelConfig")
        if not isinstance(self.regime, RegimeConfig):
            raise TypeError("regime must be RegimeConfig")
        if not isinstance(self.depth_maintenance, DepthMaintenanceConfig):
            raise TypeError("depth_maintenance must be DepthMaintenanceConfig")
        if not isinstance(self.joint_flow, JointFlowConfig):
            raise TypeError("joint_flow must be JointFlowConfig")
        if not isinstance(self.spread_control, SpreadControlConfig):
            raise TypeError("spread_control must be SpreadControlConfig")
        if not isinstance(self.book_constraints, BookConstraintConfig):
            raise TypeError("book_constraints must be BookConstraintConfig")
