from __future__ import annotations

from .types import EventCapPolicy, LiquidityPolicy


class EventCapExceededError(RuntimeError):
    """Raised when a frame reaches the event cap under ``EventCapPolicy.RAISE``."""


def should_repair_liquidity(*, policy: LiquidityPolicy, has_bid: bool, has_ask: bool, reason: str) -> bool:
    """Return whether one-sided liquidity must be synthetically repaired."""

    if has_bid and has_ask:
        return False
    if policy is LiquidityPolicy.ALLOW_EMPTY:
        return False
    if policy is LiquidityPolicy.HALT_ON_EMPTY:
        raise RuntimeError(f"one-sided book detected at {reason}")
    return True


def resolve_event_cap(
    *,
    policy: EventCapPolicy,
    max_events_per_step: int,
    current_time: float,
    step_end_time: float,
) -> bool:
    """Resolve event-cap overflow according to policy and return truncation flag."""

    if policy is EventCapPolicy.TRUNCATE_AND_FLAG:
        return True
    raise EventCapExceededError(
        "max_events_per_step reached: "
        f"max={max_events_per_step}, t={current_time:.6f}, step_end={step_end_time:.6f}"
    )
