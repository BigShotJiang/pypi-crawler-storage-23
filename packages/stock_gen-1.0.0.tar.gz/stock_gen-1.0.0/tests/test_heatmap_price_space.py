from __future__ import annotations

import matplotlib
import numpy as np
import pytest

from stock_gen import StockGenerator, StockGeneratorConfig
from stock_gen import viz

matplotlib.use("Agg")


def _image_shape(ax) -> tuple[int, int]:
    return tuple(ax.images[0].get_array().shape)


def test_prepare_price_space_matrix_aggregates_relative_bins() -> None:
    qty = np.asarray([[4, 2, 9], [3, 1, 5]], dtype=np.int64)
    px_ticks = np.asarray([[99, 100, 103], [198, 201, 202]], dtype=np.int64)
    valid = np.asarray([[True, True, True], [True, False, True]], dtype=bool)
    mid_ticks = np.asarray([100.0, 200.0], dtype=np.float64)
    mid_valid = np.asarray([True, False], dtype=bool)

    agg_qty, agg_valid = viz._prepare_price_space_matrix(
        qty=qty,
        px_ticks=px_ticks,
        valid=valid,
        mid_ticks=mid_ticks,
        mid_valid=mid_valid,
        price_window_ticks=2,
    )

    np.testing.assert_array_equal(agg_qty[0], np.asarray([0.0, 4.0, 2.0, 0.0, 0.0]))
    np.testing.assert_array_equal(agg_valid[0], np.asarray([False, True, True, False, False]))
    np.testing.assert_array_equal(agg_qty[1], np.asarray([0.0, 0.0, 0.0, 0.0, 0.0]))
    np.testing.assert_array_equal(agg_valid[1], np.asarray([False, False, False, False, False]))

    values, _ = viz._prepare_heatmap_matrix(
        qty=agg_qty,
        valid=agg_valid,
        mask_invalid=True,
        normalize="none",
        vmax_quantile=None,
    )
    assert np.isnan(values[0, 0])
    assert values[0, 1] == pytest.approx(4.0)
    assert values[0, 2] == pytest.approx(2.0)
    assert np.isnan(values[0, 3])
    assert np.isnan(values[1]).all()


def test_plot_l2_heatmap_price_space_defaults_use_compact_ranges() -> None:
    cfg = StockGeneratorConfig(seed=7, end_time=12.0, depth_levels=6)
    hist = StockGenerator(cfg).gen().history
    n_frames = len(hist.frames)
    window = 7
    full_bins = 2 * window + 1
    side_bins = window + 1

    bid_ax = viz.plot_l2_heatmap(
        hist,
        side="bid",
        space="price",
        price_window_ticks=window,
        mask_invalid=True,
        normalize="none",
        vmax_quantile=0.9,
    )
    assert _image_shape(bid_ax) == (side_bins, n_frames)
    assert bid_ax.get_ylabel() == f"ticks from mid (-{window}..+0)"

    ask_ax = viz.plot_l2_heatmap(
        hist,
        side="ask",
        space="price",
        price_window_ticks=window,
        mask_invalid=False,
        normalize="log1p",
        vmax_quantile=0.95,
    )
    assert _image_shape(ask_ax) == (side_bins, n_frames)
    assert ask_ax.get_ylabel() == f"ticks from mid (+0..+{window})"

    axes = viz.plot_l2_heatmap(
        hist,
        side="both",
        space="price",
        price_window_ticks=window,
        mask_invalid=True,
        normalize="log1p",
        vmax_quantile=0.95,
    )
    assert hasattr(axes, "__getitem__")
    assert _image_shape(axes[0])[1] == n_frames
    assert _image_shape(axes[1])[1] == n_frames
    assert 1 <= _image_shape(axes[0])[0] <= full_bins
    assert 1 <= _image_shape(axes[1])[0] <= full_bins

    bid_values = np.ma.asarray(axes[0].images[0].get_array()).filled(np.nan)
    ask_values = np.ma.asarray(axes[1].images[0].get_array()).filled(np.nan)
    assert np.isfinite(bid_values[0]).any()
    assert np.isfinite(bid_values[-1]).any()
    assert np.isfinite(ask_values[0]).any()
    assert np.isfinite(ask_values[-1]).any()


def test_plot_l2_heatmap_price_space_supports_auto_window_for_compact_default() -> None:
    cfg = StockGeneratorConfig(seed=19, end_time=11.0, depth_levels=6)
    hist = StockGenerator(cfg).gen().history
    n_frames = len(hist.frames)
    data = hist.to_numpy(as_ticks=True)

    expected_window = viz._resolve_price_window_ticks(
        price_window_ticks="auto",
        px_ticks=data["bid_px_ticks"],
        valid=data["bid_px_valid"],
        mid_ticks=data["mid"].astype(np.float64) / float(hist.tick_size),
        mid_valid=data["mid_valid"],
        side="bid",
        y_range="side",
    )
    ax = viz.plot_l2_heatmap(
        hist,
        side="bid",
        space="price",
        mask_invalid=True,
        normalize="none",
        vmax_quantile=1.0,
    )
    assert _image_shape(ax) == (expected_window + 1, n_frames)


def test_plot_l2_heatmap_price_space_full_range_compatibility_path() -> None:
    cfg = StockGeneratorConfig(seed=13, end_time=12.0, depth_levels=6)
    hist = StockGenerator(cfg).gen().history
    n_frames = len(hist.frames)
    window = 7
    full_bins = 2 * window + 1

    bid_ax = viz.plot_l2_heatmap(
        hist,
        side="bid",
        space="price",
        price_window_ticks=window,
        y_range="full",
        mask_invalid=True,
        normalize="none",
        vmax_quantile=0.9,
    )
    assert _image_shape(bid_ax) == (full_bins, n_frames)
    assert bid_ax.get_ylabel() == f"ticks from mid (-{window}..+{window})"

    axes = viz.plot_l2_heatmap(
        hist,
        side="both",
        space="price",
        price_window_ticks=window,
        y_range="full",
        mask_invalid=True,
        normalize="log1p",
        vmax_quantile=0.95,
    )
    assert hasattr(axes, "__getitem__")
    assert _image_shape(axes[0]) == (full_bins, n_frames)
    assert _image_shape(axes[1]) == (full_bins, n_frames)


def test_plot_l2_heatmap_rank_space_keeps_depth_levels() -> None:
    cfg = StockGeneratorConfig(seed=11, end_time=10.0, depth_levels=5)
    hist = StockGenerator(cfg).gen().history
    n_frames = len(hist.frames)

    ax = viz.plot_l2_heatmap(
        hist,
        side="bid",
        space="rank",
        mask_invalid=True,
        normalize="none",
        vmax_quantile=1.0,
    )
    assert _image_shape(ax) == (cfg.depth_levels, n_frames)
    assert ax.get_ylabel() == "level (0=best)"
