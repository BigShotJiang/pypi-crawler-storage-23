import math

import numpy as np
import pytest

from stock_gen import EventCapPolicy, StockGenerator, StockGeneratorConfig
from stock_gen.config import ExpLinearIntensityConfig
from stock_gen.types import EventType


def test_recent_flow_decays_during_no_event_interval() -> None:
    theta = {
        EventType.M_B: np.asarray([-2.0, 0.0, 0.0, 0.0, 0.0, 0.0], dtype=np.float64),
    }
    cfg = StockGeneratorConfig(
        dt=0.1,
        seed=245,
        max_events_per_step=1,
        event_cap_policy=EventCapPolicy.TRUNCATE_AND_FLAG,
        flow_half_life=1.0,
        intensity=ExpLinearIntensityConfig(theta=theta),
    )
    sg = StockGenerator(cfg)

    first = sg.step()
    events_after_first = len(sg.get_events())
    trades_after_first = len(sg.get_trades())
    time_after_first = sg.get_time()
    second = sg.step()

    assert first.events_processed == 1
    assert second.events_processed == 0
    assert second.t_last_event is None
    assert len(sg.get_events()) == events_after_first
    assert len(sg.get_trades()) == trades_after_first
    assert trades_after_first > 0
    assert sg.get_time() == pytest.approx(time_after_first + cfg.dt)

    decay = math.exp(-math.log(2.0) * cfg.dt / cfg.flow_half_life)
    expected = first.frame.recent_flow * decay
    assert second.frame.recent_flow == pytest.approx(expected, rel=1e-12, abs=1e-12)
