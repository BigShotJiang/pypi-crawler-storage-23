from __future__ import annotations

import inspect

from stock_gen.config import ExpLinearIntensityConfig
from stock_gen.engine import (
    EventDispatcher,
    EventHandlerContext,
    EventLoopFeatures,
    FrameRunResult,
    FrameRunnerContext,
    build_frame_snapshot,
    build_l2_snapshot,
    compute_book_imbalance,
    compute_event_loop_features,
    sample_event_type,
)
from stock_gen.models_cancel import choose_cancel_order_id, sample_xi
from stock_gen.orderbook import OrderBook, PriceLevel
from stock_gen.sim_policies import resolve_event_cap, should_repair_liquidity
from stock_gen.types import MarketHistory


def _assert_has_docstring(obj: object, *, label: str) -> None:
    doc = inspect.getdoc(obj)
    assert doc is not None and doc.strip(), f"missing docstring: {label}"


def test_engine_and_related_public_symbols_have_docstrings() -> None:
    symbols = {
        "EventHandlerContext": EventHandlerContext,
        "EventDispatcher": EventDispatcher,
        "EventLoopFeatures": EventLoopFeatures,
        "FrameRunnerContext": FrameRunnerContext,
        "FrameRunResult": FrameRunResult,
        "build_l2_snapshot": build_l2_snapshot,
        "build_frame_snapshot": build_frame_snapshot,
        "compute_book_imbalance": compute_book_imbalance,
        "compute_event_loop_features": compute_event_loop_features,
        "sample_event_type": sample_event_type,
        "EventDispatcher.process": EventDispatcher.process,
        "should_repair_liquidity": should_repair_liquidity,
        "resolve_event_cap": resolve_event_cap,
        "ExpLinearIntensityConfig.default": ExpLinearIntensityConfig.default,
        "MarketHistory.to_numpy": MarketHistory.to_numpy,
        "sample_xi": sample_xi,
        "choose_cancel_order_id": choose_cancel_order_id,
        "PriceLevel": PriceLevel,
        "OrderBook.total_qty": OrderBook.total_qty,
        "OrderBook.best_price_ticks": OrderBook.best_price_ticks,
        "OrderBook.best_qty": OrderBook.best_qty,
        "OrderBook.spread_ticks": OrderBook.spread_ticks,
        "OrderBook.add_limit_resting": OrderBook.add_limit_resting,
        "OrderBook.cancel": OrderBook.cancel,
        "OrderBook.replace": OrderBook.replace,
        "OrderBook.iter_orders_priority": OrderBook.iter_orders_priority,
        "OrderBook.get_l2_ticks": OrderBook.get_l2_ticks,
        "OrderBook.process_market": OrderBook.process_market,
        "OrderBook.process_limit": OrderBook.process_limit,
    }
    for label, symbol in symbols.items():
        _assert_has_docstring(symbol, label=label)
