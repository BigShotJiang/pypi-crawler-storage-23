import numpy as np

from stock_gen import EventCapPolicy, StockGenerator, StockGeneratorConfig
from stock_gen.config import CancelConfig, ExpLinearIntensityConfig, RegimeConfig, RegimeSegment, SizeConfig
from stock_gen.types import EventType


def test_regime_multiplier_changes_event_arrival_rate() -> None:
    theta = {
        EventType.L_B: np.asarray([0.0, 0.0, 0.0, 0.0, 0.0, 0.0], dtype=np.float64),
    }
    base_events: list[int] = []
    boosted_events: list[int] = []
    for seed in range(41, 51):
        base_cfg = StockGeneratorConfig(
            dt=1.0,
            seed=seed,
            max_events_per_step=20_000,
            intensity=ExpLinearIntensityConfig(theta=theta),
        )
        boosted_cfg = StockGeneratorConfig(
            dt=1.0,
            seed=seed,
            max_events_per_step=20_000,
            intensity=ExpLinearIntensityConfig(theta=theta),
            regime=RegimeConfig(segments=(RegimeSegment(start_time=0.0, end_time=10.0, multiplier=3.0),)),
        )
        base_events.append(StockGenerator(base_cfg).step().events_user)
        boosted_events.append(StockGenerator(boosted_cfg).step().events_user)

    assert sum(boosted_events) >= sum(base_events)
    assert any(b2 > b1 for b1, b2 in zip(base_events, boosted_events, strict=False))


def test_partial_cancel_keeps_order_resting_when_enabled() -> None:
    theta = {
        EventType.C_B: np.asarray([10.0, 0.0, 0.0, 0.0, 0.0, 0.0], dtype=np.float64),
    }
    cfg = StockGeneratorConfig(
        dt=1.0,
        seed=55,
        init_levels_per_side=1,
        init_orders_per_level=1,
        intensity=ExpLinearIntensityConfig(theta=theta),
        size=SizeConfig(
            market_mu=1.0,
            market_sigma=0.0,
            improve_mu=1.0,
            improve_sigma=0.0,
            join_mu=1.0,
            join_sigma=0.0,
            deep_mu=3.0,
            deep_sigma=0.0,
            max_order_qty=10_000,
        ),
        cancel=CancelConfig(beta_a=1.0, beta_b=1.0, partial_cancel_prob=1.0, partial_min_ratio=0.2),
        max_events_per_step=1,
        event_cap_policy=EventCapPolicy.TRUNCATE_AND_FLAG,
    )
    sg = StockGenerator(cfg)

    before_bid_qty = sg.get_l2(as_ticks=True).bid_qty[0]
    step = sg.step()
    after_bid_qty = sg.get_l2(as_ticks=True).bid_qty[0]

    cancel_events = [ev for ev in sg.get_events() if ev.event_type is EventType.C_B]
    assert cancel_events
    assert step.events_user == 1
    assert cancel_events[0].qty is not None
    assert int(cancel_events[0].qty) < int(before_bid_qty)
    assert after_bid_qty > 0
