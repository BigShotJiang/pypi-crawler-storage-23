import numpy as np
import pytest

from stock_gen import EventCapPolicy, LiquidityPolicy, StockGenerator, StockGeneratorConfig
from stock_gen.config import ExpLinearIntensityConfig, SizeConfig
from stock_gen.types import EventType


def _m_b_only_intensity() -> ExpLinearIntensityConfig:
    theta = {
        EventType.M_B: np.asarray([10.0, 0.0, 0.0, 0.0, 0.0, 0.0], dtype=np.float64),
    }
    return ExpLinearIntensityConfig(theta=theta)


def _small_book_large_market_size() -> SizeConfig:
    return SizeConfig(
        market_mu=8.0,
        market_sigma=0.0,
        improve_mu=0.0,
        improve_sigma=0.0,
        join_mu=0.0,
        join_sigma=0.0,
        deep_mu=0.0,
        deep_sigma=0.0,
        max_order_qty=10_000,
    )


def test_step_rolls_back_on_non_cap_runtime_error() -> None:
    cfg = StockGeneratorConfig(
        dt=1.0,
        seed=17,
        init_levels_per_side=1,
        init_orders_per_level=1,
        intensity=_m_b_only_intensity(),
        size=_small_book_large_market_size(),
        max_events_per_step=1,
        event_cap_policy=EventCapPolicy.TRUNCATE_AND_FLAG,
        liquidity_policy=LiquidityPolicy.HALT_ON_EMPTY,
    )
    sg = StockGenerator(cfg)

    before_time = sg.get_time()
    before_events = sg.get_events()
    before_trades = sg.get_trades()
    before_steps = sg.get_step_results()
    before_history = sg.get_history()

    with pytest.raises(RuntimeError, match="one-sided book"):
        sg.step()

    after_history = sg.get_history()

    assert sg.get_time() == pytest.approx(before_time)
    assert sg.get_events() == before_events
    assert sg.get_trades() == before_trades
    assert sg.get_step_results() == before_steps
    assert after_history.frames == before_history.frames
    assert after_history.events == before_history.events
    assert after_history.trades == before_history.trades
