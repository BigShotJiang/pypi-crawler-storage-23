from __future__ import annotations

import pytest

from stock_gen.orderbook import OrderBook
from stock_gen.types import Side


def test_orderbook_rejects_prices_below_min_ticks() -> None:
    ob = OrderBook(min_price_ticks=10)
    with pytest.raises(ValueError, match="below min_price_ticks"):
        ob.add_limit_resting(side=Side.BID, price_ticks=9, qty=1)


def test_orderbook_disallows_locked_book_by_default() -> None:
    ob = OrderBook()
    _ = ob.add_limit_resting(side=Side.ASK, price_ticks=100, qty=5)
    with pytest.raises(ValueError, match="crossed resting book insert"):
        ob.add_limit_resting(side=Side.BID, price_ticks=100, qty=3)


def test_orderbook_can_allow_locked_book_when_enabled() -> None:
    ob = OrderBook(allow_locked_book=True)
    _ = ob.add_limit_resting(side=Side.ASK, price_ticks=100, qty=5)
    _ = ob.add_limit_resting(side=Side.BID, price_ticks=100, qty=3)
    assert ob.spread_ticks() == 0
