from stock_gen import StockGenerator, StockGeneratorConfig
from stock_gen.config import ExpLinearIntensityConfig


def test_tick_size_default_is_one() -> None:
    cfg = StockGeneratorConfig()
    assert cfg.tick_size == 1.0


def test_default_price_scaling_is_identity_on_best_quotes() -> None:
    cfg = StockGeneratorConfig(seed=17, intensity=ExpLinearIntensityConfig(theta={}))
    sg = StockGenerator(cfg)
    frame = sg.step().frame

    assert frame.best_bid_ticks is not None
    assert frame.best_ask_ticks is not None

    (best_bid, _best_bid_qty), (best_ask, _best_ask_qty) = sg.get_best_bid_ask()
    assert best_bid == float(frame.best_bid_ticks)
    assert best_ask == float(frame.best_ask_ticks)
