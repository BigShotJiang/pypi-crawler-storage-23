import numpy as np

from stock_gen import StockGenerator, StockGeneratorConfig
from stock_gen.config import ExpLinearIntensityConfig, SizeConfig
from stock_gen.types import EventCapPolicy, EventType


def test_default_config_keeps_two_sided_quotes_multiseed() -> None:
    for seed in (1, 2, 3, 4, 5):
        cfg = StockGeneratorConfig(
            dt=1.0,
            end_time=100.0,
            depth_levels=10,
            seed=seed,
        )
        result = StockGenerator(cfg).gen()
        hist = result.history

        for frame in hist.frames:
            assert frame.best_bid_ticks is not None, f"missing bid for seed={seed} at t={frame.t}"
            assert frame.best_ask_ticks is not None, f"missing ask for seed={seed} at t={frame.t}"
            assert frame.spread_ticks is not None, f"missing spread for seed={seed} at t={frame.t}"
            assert frame.spread_ticks >= 1, f"invalid spread for seed={seed} at t={frame.t}"


def test_liquidity_repair_recovers_after_market_side_depletion() -> None:
    theta = {
        EventType.M_B: np.asarray([10.0, 0.0, 0.0, 0.0, 0.0, 0.0], dtype=np.float64),
    }
    cfg = StockGeneratorConfig(
        dt=1.0,
        seed=7,
        init_levels_per_side=1,
        init_orders_per_level=1,
        intensity=ExpLinearIntensityConfig(theta=theta),
        size=SizeConfig(
            market_mu=8.0,
            market_sigma=0.0,
            improve_mu=0.0,
            improve_sigma=0.0,
            join_mu=0.0,
            join_sigma=0.0,
            deep_mu=0.0,
            deep_sigma=0.0,
            max_order_qty=10_000,
        ),
        max_events_per_step=1,
        event_cap_policy=EventCapPolicy.TRUNCATE_AND_FLAG,
    )
    sg = StockGenerator(cfg)

    step_result = sg.step()
    frame = step_result.frame
    assert frame.best_bid_ticks is not None
    assert frame.best_ask_ticks is not None
    assert len(sg.get_trades()) > 0

    repair_events = [event for event in sg.get_events() if event.synthetic]
    assert repair_events
    assert any(event.event_type is EventType.L_A for event in repair_events)
    assert any(event.reason in {"pre_event_loop", "pre_snapshot"} for event in repair_events)
