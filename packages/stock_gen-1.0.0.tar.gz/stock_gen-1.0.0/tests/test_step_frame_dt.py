from stock_gen import StockGenerator, StockGeneratorConfig
from stock_gen.config import ExpLinearIntensityConfig


def test_step_advances_time_with_zero_events() -> None:
    cfg = StockGeneratorConfig(
        dt=1.0,
        depth_levels=5,
        seed=1,
        intensity=ExpLinearIntensityConfig(theta={}),  # disable all event intensities
    )
    sg = StockGenerator(cfg)

    t0 = sg.get_time()
    step_result = sg.step()
    frame = step_result.frame

    assert sg.get_time() == t0 + 1.0
    assert frame.t == sg.get_time()
    assert step_result.events_processed == 0
    assert step_result.truncated is False
    assert len(sg.get_events()) == 0
    assert len(sg.get_trades()) == 0
    assert len(sg.get_history().frames) == 1


def test_gen_runs_until_time_even_with_zero_events() -> None:
    cfg = StockGeneratorConfig(
        dt=1.0,
        seed=1,
        intensity=ExpLinearIntensityConfig(theta={}),
    )
    sg = StockGenerator(cfg)

    sg.step()  # t=1.0
    result = sg.gen(until_time=2.5)
    hist = result.history

    assert abs(sg.get_time() - 2.5) < 1e-12
    assert len(hist.frames) == 3
    assert len(result.steps) == 3
