from __future__ import annotations

from collections import Counter

import numpy as np

from stock_gen import StockGenerator, StockGeneratorConfig


def test_default_quality_targets_trade_rate_and_spread() -> None:
    trade_active_steps: list[bool] = []
    traded_qty_per_step: list[int] = []
    spread_eq_one_ratios: list[float] = []
    event_counter: Counter[str] = Counter()

    for seed in range(1, 9):
        sim = StockGenerator(StockGeneratorConfig(seed=seed, dt=1.0, end_time=120.0)).gen()
        frame_times = np.asarray([frame.t for frame in sim.frames], dtype=np.float64)
        step_qty = np.zeros(len(sim.steps), dtype=np.int64)
        for trade in sim.trades:
            idx = int(np.searchsorted(frame_times, trade.t, side="left"))
            if idx < len(step_qty):
                step_qty[idx] += int(trade.qty)
        trade_active_steps.extend((step_qty > 0).tolist())
        traded_qty_per_step.extend(step_qty.tolist())

        spreads = np.asarray(
            [int(frame.spread_ticks) if frame.spread_ticks is not None else -1 for frame in sim.frames],
            dtype=np.int64,
        )
        spread_eq_one_ratios.append(float(np.mean(spreads == 1)))
        event_counter.update(event.event_type.value[0] for event in sim.events if not event.synthetic)

    total_events = max(1, sum(event_counter.values()))
    market_share = float(event_counter["M"]) / float(total_events)
    cancel_share = float(event_counter["C"]) / float(total_events)

    assert float(np.mean(trade_active_steps)) >= 0.50
    assert float(np.mean(traded_qty_per_step)) >= 3.0
    assert float(np.median(traded_qty_per_step)) >= 1.0
    assert float(np.mean(spread_eq_one_ratios)) >= 0.99
    assert market_share >= 0.18
    assert cancel_share <= 0.50
