import numpy as np

from stock_gen import EventCapPolicy, LiquidityPolicy, StockGenerator, StockGeneratorConfig
from stock_gen.config import ExpLinearIntensityConfig, SizeConfig
from stock_gen.types import EventType, PlacementMode, Side


def test_replace_event_populates_v2_fields() -> None:
    theta = {
        EventType.R_B: np.asarray([10.0, 0.0, 0.0, 0.0, 0.0, 0.0], dtype=np.float64),
    }
    cfg = StockGeneratorConfig(
        dt=0.1,
        seed=101,
        max_events_per_step=1,
        event_cap_policy=EventCapPolicy.TRUNCATE_AND_FLAG,
        intensity=ExpLinearIntensityConfig(theta=theta),
    )
    sg = StockGenerator(cfg)

    sg.step()
    replace_events = [event for event in sg.get_events() if event.event_type is EventType.R_B]

    assert replace_events
    ev = replace_events[0]
    assert ev.replaced_order_id is not None
    if ev.order_id is not None:
        assert ev.order_id != ev.replaced_order_id
    assert ev.placement_mode in (PlacementMode.IMPROVE, PlacementMode.JOIN, PlacementMode.DEEP)


def test_replace_event_allows_none_order_id_when_fully_filled(monkeypatch) -> None:
    import stock_gen.engine.event_handlers as event_handlers

    theta = {
        EventType.R_B: np.asarray([10.0, 0.0, 0.0, 0.0, 0.0, 0.0], dtype=np.float64),
    }
    cfg = StockGeneratorConfig(
        dt=0.1,
        seed=7,
        init_levels_per_side=1,
        init_orders_per_level=1,
        max_events_per_step=1,
        event_cap_policy=EventCapPolicy.TRUNCATE_AND_FLAG,
        liquidity_policy=LiquidityPolicy.ALLOW_EMPTY,
        intensity=ExpLinearIntensityConfig(theta=theta),
        size=SizeConfig(
            market_mu=0.0,
            market_sigma=0.0,
            improve_mu=0.0,
            improve_sigma=0.0,
            join_mu=0.0,
            join_sigma=0.0,
            deep_mu=0.0,
            deep_sigma=0.0,
            max_order_qty=10,
        ),
    )

    def pick_first_order(ob, side, xi):  # noqa: ARG001
        first = next(ob.iter_orders_priority(side), None)
        return None if first is None else first[0]

    def force_crossing_replace(**kwargs):
        best_ask_ticks = kwargs["best_ask_ticks"]
        if best_ask_ticks is None:
            raise AssertionError("expected non-empty ask side for replacement test")
        return PlacementMode.JOIN, int(best_ask_ticks), None

    monkeypatch.setattr(event_handlers, "select_order_by_priority_index", pick_first_order)
    monkeypatch.setattr(event_handlers, "sample_placement", force_crossing_replace)
    monkeypatch.setattr(event_handlers, "sample_limit_qty", lambda **kwargs: 1)

    sg = StockGenerator(cfg)
    sg.step()

    replace_events = [event for event in sg.get_events() if event.event_type is EventType.R_B]
    assert replace_events
    ev = replace_events[0]
    assert ev.replaced_order_id is not None
    assert ev.order_id is None
    assert ev.placement_mode is PlacementMode.JOIN
    assert ev.side is Side.BID

    trades = sg.get_trades()
    assert len(trades) == 1
    assert trades[0].aggressor is Side.BID
    assert trades[0].qty == 1
