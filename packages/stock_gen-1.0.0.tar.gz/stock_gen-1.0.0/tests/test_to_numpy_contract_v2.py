import numpy as np

from stock_gen import EventCapPolicy, LiquidityPolicy, StockGenerator, StockGeneratorConfig
from stock_gen.config import ExpLinearIntensityConfig, SizeConfig
from stock_gen.types import EventType


def _one_sided_book_cfg() -> StockGeneratorConfig:
    theta = {
        EventType.M_B: np.asarray([10.0, 0.0, 0.0, 0.0, 0.0, 0.0], dtype=np.float64),
    }
    return StockGeneratorConfig(
        dt=1.0,
        seed=9,
        depth_levels=4,
        init_levels_per_side=1,
        init_orders_per_level=1,
        intensity=ExpLinearIntensityConfig(theta=theta),
        size=SizeConfig(
            market_mu=8.0,
            market_sigma=0.0,
            improve_mu=0.0,
            improve_sigma=0.0,
            join_mu=0.0,
            join_sigma=0.0,
            deep_mu=0.0,
            deep_sigma=0.0,
            max_order_qty=10_000,
        ),
        max_events_per_step=1,
        event_cap_policy=EventCapPolicy.TRUNCATE_AND_FLAG,
        liquidity_policy=LiquidityPolicy.ALLOW_EMPTY,
    )


def test_to_numpy_includes_v2_validity_masks() -> None:
    cfg = _one_sided_book_cfg()
    sg = StockGenerator(cfg)

    sg.step()
    data = sg.get_history().to_numpy(as_ticks=True)

    expected_keys = {
        "t",
        "mid",
        "mid_valid",
        "spread_ticks",
        "spread_valid",
        "best_bid_ticks",
        "best_ask_ticks",
        "best_bid_valid",
        "best_ask_valid",
        "imbalance",
        "imbalance_valid",
        "recent_flow",
        "bid_px_ticks",
        "bid_qty",
        "bid_px_valid",
        "ask_px_ticks",
        "ask_qty",
        "ask_px_valid",
    }
    assert expected_keys.issubset(set(data.keys()))

    assert data["mid_valid"].shape == (1,)
    assert data["spread_valid"].shape == (1,)
    assert data["best_bid_valid"].shape == (1,)
    assert data["best_ask_valid"].shape == (1,)
    assert data["imbalance_valid"].shape == (1,)
    assert data["bid_px_valid"].shape == (1, 4)
    assert data["ask_px_valid"].shape == (1, 4)

    assert bool(data["best_ask_valid"][0]) is False
    assert int(data["best_ask_ticks"][0]) == -1
    assert bool(data["spread_valid"][0]) is False
    assert int(data["spread_ticks"][0]) == -1


def test_to_numpy_as_ticks_false_adds_price_scaled_arrays() -> None:
    cfg = _one_sided_book_cfg()
    sg = StockGenerator(cfg)

    sg.step()
    data = sg.get_history().to_numpy(as_ticks=False)

    bid_px_valid = data["bid_px_ticks"] >= 0
    ask_px_valid = data["ask_px_ticks"] >= 0

    assert {"best_bid", "best_ask", "bid_px", "ask_px"}.issubset(set(data.keys()))
    assert bid_px_valid.shape == data["bid_px"].shape
    assert ask_px_valid.shape == data["ask_px"].shape

    assert bool(data["best_bid_valid"][0]) is True
    assert bool(data["best_ask_valid"][0]) is False
    assert np.isnan(data["best_ask"][0])

    assert np.all(np.isnan(data["best_bid"][~data["best_bid_valid"]]))
    assert np.all(np.isnan(data["best_ask"][~data["best_ask_valid"]]))
    np.testing.assert_allclose(
        data["best_bid"][data["best_bid_valid"]],
        data["best_bid_ticks"][data["best_bid_valid"]].astype(np.float64) * cfg.tick_size,
    )
    np.testing.assert_allclose(
        data["best_ask"][data["best_ask_valid"]],
        data["best_ask_ticks"][data["best_ask_valid"]].astype(np.float64) * cfg.tick_size,
    )

    assert np.all(np.isnan(data["bid_px"][~bid_px_valid]))
    assert np.all(np.isnan(data["ask_px"][~ask_px_valid]))
    np.testing.assert_allclose(
        data["bid_px"][bid_px_valid],
        data["bid_px_ticks"][bid_px_valid].astype(np.float64) * cfg.tick_size,
    )
    np.testing.assert_allclose(
        data["ask_px"][ask_px_valid],
        data["ask_px_ticks"][ask_px_valid].astype(np.float64) * cfg.tick_size,
    )


def test_to_numpy_as_ticks_false_scales_when_all_prices_are_valid() -> None:
    cfg = StockGeneratorConfig(
        dt=1.0,
        seed=21,
        tick_size=0.5,
        depth_levels=3,
        intensity=ExpLinearIntensityConfig(theta={}),
    )
    sg = StockGenerator(cfg)

    sg.step()
    data = sg.get_history().to_numpy(as_ticks=False)

    assert {"best_bid", "best_ask", "bid_px", "ask_px"}.issubset(set(data.keys()))
    np.testing.assert_allclose(data["best_bid"], data["best_bid_ticks"].astype(np.float64) * cfg.tick_size)
    np.testing.assert_allclose(data["best_ask"], data["best_ask_ticks"].astype(np.float64) * cfg.tick_size)
    np.testing.assert_allclose(data["bid_px"], data["bid_px_ticks"].astype(np.float64) * cfg.tick_size)
    np.testing.assert_allclose(data["ask_px"], data["ask_px_ticks"].astype(np.float64) * cfg.tick_size)


def test_to_numpy_empty_history_branch_returns_empty_arrays() -> None:
    cfg = StockGeneratorConfig(seed=22, intensity=ExpLinearIntensityConfig(theta={}))
    sg = StockGenerator(cfg)

    data = sg.get_history().to_numpy(as_ticks=False)

    expected_empty_keys = {
        "t",
        "mid",
        "mid_valid",
        "spread_ticks",
        "spread_valid",
        "best_bid_ticks",
        "best_ask_ticks",
        "best_bid_valid",
        "best_ask_valid",
        "imbalance",
        "imbalance_valid",
        "recent_flow",
        "bid_px_ticks",
        "bid_qty",
        "bid_px_valid",
        "ask_px_ticks",
        "ask_qty",
        "ask_px_valid",
    }
    assert expected_empty_keys == set(data.keys())
    assert all(data[key].size == 0 for key in expected_empty_keys)
    assert "best_bid" not in data
    assert "best_ask" not in data
    assert "bid_px" not in data
    assert "ask_px" not in data
