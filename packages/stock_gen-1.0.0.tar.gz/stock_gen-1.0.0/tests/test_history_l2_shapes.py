import numpy as np
import pytest

from stock_gen import StockGenerator, StockGeneratorConfig
from stock_gen.config import ExpLinearIntensityConfig


def test_frame_l2_arrays_have_fixed_shape() -> None:
    k = 7
    cfg = StockGeneratorConfig(
        dt=1.0,
        depth_levels=k,
        seed=1,
        intensity=ExpLinearIntensityConfig(theta={}),
    )
    sg = StockGenerator(cfg)
    fr = sg.step().frame

    assert fr.bid_px_ticks.shape == (k,)
    assert fr.bid_qty.shape == (k,)
    assert fr.ask_px_ticks.shape == (k,)
    assert fr.ask_qty.shape == (k,)

    assert fr.bid_px_ticks.dtype == np.int64
    assert fr.bid_qty.dtype == np.int64
    assert fr.ask_px_ticks.dtype == np.int64
    assert fr.ask_qty.dtype == np.int64


def test_get_l2_shape_and_dtype() -> None:
    k = 5
    cfg = StockGeneratorConfig(depth_levels=k, seed=1, intensity=ExpLinearIntensityConfig(theta={}))
    sg = StockGenerator(cfg)
    l2 = sg.get_l2()

    assert l2.bid_qty.shape == (k,)
    assert l2.ask_qty.shape == (k,)


@pytest.mark.parametrize("levels", [0, -1])
def test_get_l2_non_positive_levels_raise_value_error(levels: int) -> None:
    cfg = StockGeneratorConfig(depth_levels=5, seed=1, intensity=ExpLinearIntensityConfig(theta={}))
    sg = StockGenerator(cfg)

    with pytest.raises(ValueError):
        sg.get_l2(levels=levels)
