import numpy as np
import pytest

from stock_gen import EventCapPolicy, StockGenerator, StockGeneratorConfig
from stock_gen.config import ExpLinearIntensityConfig
from stock_gen.sim_policies import EventCapExceededError
from stock_gen.types import EventType


def _high_rate_intensity() -> ExpLinearIntensityConfig:
    theta = {
        EventType.L_B: np.asarray([10.0, 0.0, 0.0, 0.0, 0.0, 0.0], dtype=np.float64),
        EventType.L_A: np.asarray([10.0, 0.0, 0.0, 0.0, 0.0, 0.0], dtype=np.float64),
    }
    return ExpLinearIntensityConfig(theta=theta)


def test_event_cap_raise_policy_raises() -> None:
    cfg = StockGeneratorConfig(
        dt=1.0,
        seed=5,
        max_events_per_step=1,
        event_cap_policy=EventCapPolicy.RAISE,
        intensity=_high_rate_intensity(),
    )
    sg = StockGenerator(cfg)

    with pytest.raises(EventCapExceededError, match="max_events_per_step"):
        sg.step()


def test_event_cap_truncate_and_flag_policy_marks_step_result() -> None:
    cfg = StockGeneratorConfig(
        dt=1.0,
        seed=5,
        max_events_per_step=1,
        event_cap_policy=EventCapPolicy.TRUNCATE_AND_FLAG,
        intensity=_high_rate_intensity(),
    )
    sg = StockGenerator(cfg)

    step_result = sg.step()

    assert step_result.events_processed == 1
    assert step_result.truncated is True
    assert step_result.t_last_event is not None


def test_event_cap_raise_step_is_atomic_on_cap_exceed() -> None:
    cfg = StockGeneratorConfig(
        dt=1.0,
        seed=19,
        max_events_per_step=1,
        event_cap_policy=EventCapPolicy.RAISE,
        intensity=_high_rate_intensity(),
    )
    sg = StockGenerator(cfg)

    before_time = sg.get_time()
    before_events = sg.get_events()
    before_trades = sg.get_trades()
    before_steps = sg.get_step_results()
    before_history = sg.get_history()

    with pytest.raises(EventCapExceededError):
        sg.step()

    after_history = sg.get_history()

    assert sg.get_time() == pytest.approx(before_time)
    assert sg.get_events() == before_events
    assert sg.get_trades() == before_trades
    assert sg.get_step_results() == before_steps

    assert after_history.frames == before_history.frames
    assert after_history.events == before_history.events
    assert after_history.trades == before_history.trades
