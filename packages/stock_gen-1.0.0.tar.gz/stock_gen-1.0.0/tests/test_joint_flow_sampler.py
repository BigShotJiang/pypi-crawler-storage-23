from __future__ import annotations

import numpy as np
from numpy.random import default_rng

from stock_gen.config import JointFlowConfig
from stock_gen.models_joint_flow import sample_joint_action
from stock_gen.sim_state import SimulationState
from stock_gen.types import EventType


def test_joint_action_masks_infeasible_market_buy_without_ask() -> None:
    logits = np.zeros((12, 9), dtype=np.float64)
    logits[6, 0] = 9.0  # strongly prefer M_B if not masked
    cfg = JointFlowConfig(action_logits=logits)
    state = SimulationState()
    rng = default_rng(123)

    sampled = [
        sample_joint_action(
            cfg=cfg,
            rng=rng,
            state=state,
            spread_ticks=None,
            best_bid_qty=10,
            best_ask_qty=None,
            imbalance=0.0,
            recent_flow=0.0,
            has_bid=True,
            has_ask=False,
        ).event_type
        for _ in range(100)
    ]
    assert all(event_type is not EventType.M_B for event_type in sampled)


def test_joint_action_adaptation_boosts_market_share_when_flow_is_stale() -> None:
    cfg = JointFlowConfig(action_logits=np.zeros((12, 9), dtype=np.float64))
    state = SimulationState()
    state.rolling_total_events = 100
    state.rolling_market_events = 0
    state.rolling_cancel_events = 70
    state.no_trade_streak_frames = 20
    rng = default_rng(7)

    n = 300
    market_count = 0
    for _ in range(n):
        action = sample_joint_action(
            cfg=cfg,
            rng=rng,
            state=state,
            spread_ticks=1,
            best_bid_qty=25,
            best_ask_qty=25,
            imbalance=0.0,
            recent_flow=0.0,
            has_bid=True,
            has_ask=True,
        )
        if action.event_type in (EventType.M_B, EventType.M_A):
            market_count += 1
    assert (market_count / n) >= 0.20
