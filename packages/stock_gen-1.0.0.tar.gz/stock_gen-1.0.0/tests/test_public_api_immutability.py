import inspect

import numpy as np
import stock_gen

from stock_gen import EventCapPolicy, StockGenerator, StockGeneratorConfig
from stock_gen.config import ExpLinearIntensityConfig, SizeConfig
from stock_gen.types import EventType

EXPECTED_ROOT_PUBLIC_API = [
    "DepthMaintenanceConfig",
    "JointFlowConfig",
    "SpreadControlConfig",
    "BookConstraintConfig",
    "DepthMaintenancePolicy",
    "EventCapExceededError",
    "EventCapPolicy",
    "LiquidityPolicy",
    "SimulationResult",
    "StepResult",
    "StockGenerator",
    "StockGeneratorConfig",
]

EXPORTED_METHOD_DOC_TARGETS = {
    stock_gen.StockGenerator: (
        "__init__",
        "reset",
        "get_time",
        "get_price",
        "get_best_bid_ask",
        "get_l2",
        "get_events",
        "get_trades",
        "get_step_results",
        "get_history",
        "step",
        "gen",
    ),
    stock_gen.SimulationResult: ("frames", "events", "trades"),
}


def _assert_has_docstring(obj: object, *, label: str) -> None:
    doc = inspect.getdoc(obj)
    assert doc is not None and doc.strip(), f"missing docstring: {label}"


def test_root_public_api_all_is_exact_and_stable() -> None:
    assert list(stock_gen.__all__) == EXPECTED_ROOT_PUBLIC_API


def test_root_exported_symbols_and_methods_have_docstrings() -> None:
    for name in EXPECTED_ROOT_PUBLIC_API:
        _assert_has_docstring(getattr(stock_gen, name), label=f"stock_gen.{name}")

    for cls, method_names in EXPORTED_METHOD_DOC_TARGETS.items():
        for method_name in method_names:
            attr = getattr(cls, method_name)
            if isinstance(attr, property):
                if attr.fget is None:
                    raise AssertionError(f"property getter missing for {cls.__name__}.{method_name}")
                _assert_has_docstring(attr.fget, label=f"{cls.__name__}.{method_name}")
            else:
                _assert_has_docstring(attr, label=f"{cls.__name__}.{method_name}")


def test_history_events_trades_and_steps_are_returned_as_copies() -> None:
    cfg = StockGeneratorConfig(
        dt=1.0,
        seed=31,
        init_levels_per_side=1,
        init_orders_per_level=1,
        intensity=ExpLinearIntensityConfig(
            theta={EventType.M_B: np.asarray([10.0, 0.0, 0.0, 0.0, 0.0, 0.0], dtype=np.float64)}
        ),
        size=SizeConfig(
            market_mu=8.0,
            market_sigma=0.0,
            improve_mu=0.0,
            improve_sigma=0.0,
            join_mu=0.0,
            join_sigma=0.0,
            deep_mu=0.0,
            deep_sigma=0.0,
            max_order_qty=10_000,
        ),
        max_events_per_step=1,
        event_cap_policy=EventCapPolicy.TRUNCATE_AND_FLAG,
    )
    sg = StockGenerator(cfg)
    sg.step()

    original_event_count = len(sg.get_events())
    original_trade_count = len(sg.get_trades())
    original_step_count = len(sg.get_step_results())
    original_frame_count = len(sg.get_history().frames)

    assert isinstance(sg.get_events(), tuple)
    assert isinstance(sg.get_trades(), tuple)
    assert isinstance(sg.get_step_results(), tuple)

    events_copy = list(sg.get_events())
    trades_copy = list(sg.get_trades())
    steps_copy = list(sg.get_step_results())
    history_view = sg.get_history()
    assert isinstance(history_view.frames, tuple)
    assert isinstance(history_view.events, tuple)
    assert isinstance(history_view.trades, tuple)
    history_frames_copy = list(history_view.frames)
    history_events_copy = list(history_view.events)
    history_trades_copy = list(history_view.trades)

    events_copy.clear()
    trades_copy.clear()
    steps_copy.clear()
    history_frames_copy.clear()
    history_events_copy.clear()
    history_trades_copy.clear()

    assert len(sg.get_events()) == original_event_count
    assert len(sg.get_trades()) == original_trade_count
    assert len(sg.get_step_results()) == original_step_count
    history_after = sg.get_history()
    assert len(history_after.frames) == original_frame_count
    assert len(history_after.events) == original_event_count
    assert len(history_after.trades) == original_trade_count


def test_frame_and_l2_arrays_are_read_only() -> None:
    cfg = StockGeneratorConfig(
        dt=1.0,
        seed=41,
        intensity=ExpLinearIntensityConfig(theta={}),
    )
    sg = StockGenerator(cfg)
    step = sg.step()

    with np.testing.assert_raises(ValueError):
        step.frame.bid_px_ticks[0] = 0
    with np.testing.assert_raises(ValueError):
        step.frame.ask_qty[0] = 0

    l2 = sg.get_l2(as_ticks=True)
    with np.testing.assert_raises(ValueError):
        l2.bid_px[0] = 0
    with np.testing.assert_raises(ValueError):
        l2.ask_qty[0] = 0


def test_get_price_and_get_best_bid_ask_follow_one_sided_book_contract() -> None:
    theta = {
        EventType.M_B: np.asarray([10.0, 0.0, 0.0, 0.0, 0.0, 0.0], dtype=np.float64),
    }
    cfg = StockGeneratorConfig(
        dt=1.0,
        seed=55,
        init_levels_per_side=1,
        init_orders_per_level=1,
        intensity=ExpLinearIntensityConfig(theta=theta),
        size=SizeConfig(
            market_mu=8.0,
            market_sigma=0.0,
            improve_mu=0.0,
            improve_sigma=0.0,
            join_mu=0.0,
            join_sigma=0.0,
            deep_mu=0.0,
            deep_sigma=0.0,
            max_order_qty=10_000,
        ),
        max_events_per_step=1,
        event_cap_policy=EventCapPolicy.TRUNCATE_AND_FLAG,
        liquidity_policy=stock_gen.LiquidityPolicy.ALLOW_EMPTY,
        depth_maintenance=stock_gen.DepthMaintenanceConfig(
            policy=stock_gen.DepthMaintenancePolicy.OFF
        ),
    )
    sg = StockGenerator(cfg)
    sg.step()

    assert np.isnan(sg.get_price())
    (bid_px, bid_qty), (ask_px, ask_qty) = sg.get_best_bid_ask()
    assert np.isfinite(bid_px)
    assert bid_qty > 0
    assert np.isnan(ask_px)
    assert ask_qty == 0
