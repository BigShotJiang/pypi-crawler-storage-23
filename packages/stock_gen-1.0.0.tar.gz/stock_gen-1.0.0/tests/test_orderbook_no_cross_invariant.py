import pytest

from stock_gen.orderbook import OrderBook
from stock_gen.types import Side


def test_add_limit_resting_rejects_crossed_insert() -> None:
    ob = OrderBook()
    _ = ob.add_limit_resting(side=Side.ASK, price_ticks=100, qty=3)

    with pytest.raises(ValueError, match="crossed resting book insert"):
        ob.add_limit_resting(side=Side.BID, price_ticks=101, qty=1)

    assert ob.best_price_ticks(Side.BID) is None
    assert ob.best_price_ticks(Side.ASK) == 100


def test_replace_path_keeps_resting_book_non_crossed() -> None:
    ob = OrderBook()
    bid_id = ob.add_limit_resting(side=Side.BID, price_ticks=100, qty=5)
    _ = ob.add_limit_resting(side=Side.ASK, price_ticks=101, qty=3)
    _ = ob.add_limit_resting(side=Side.ASK, price_ticks=105, qty=2)

    new_order_id, trades = ob.replace(bid_id, new_price_ticks=103, new_qty=4, t=2.0)

    assert [tr.price_ticks for tr in trades] == [101]
    assert [tr.qty for tr in trades] == [3]
    assert new_order_id is not None

    best_bid = ob.best_price_ticks(Side.BID)
    best_ask = ob.best_price_ticks(Side.ASK)
    assert best_bid == 103
    assert best_ask == 105
    assert best_bid < best_ask
