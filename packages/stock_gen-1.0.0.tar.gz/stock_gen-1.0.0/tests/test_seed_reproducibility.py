import numpy as np

from stock_gen import StockGenerator, StockGeneratorConfig


def _assert_history_equal(left: dict[str, np.ndarray], right: dict[str, np.ndarray]) -> None:
    for key in [
        "t",
        "spread_ticks",
        "best_bid_ticks",
        "best_ask_ticks",
        "best_bid_valid",
        "best_ask_valid",
        "spread_valid",
        "bid_px_ticks",
        "bid_qty",
        "ask_px_ticks",
        "ask_qty",
    ]:
        np.testing.assert_array_equal(left[key], right[key], err_msg=f"mismatch at key={key}")

    for key in ["mid", "imbalance", "recent_flow"]:
        np.testing.assert_allclose(left[key], right[key], equal_nan=True, err_msg=f"mismatch at key={key}")


def test_same_seed_produces_identical_simulation_paths() -> None:
    cfg = StockGeneratorConfig(seed=2026, dt=0.5, end_time=5.0)

    run1 = StockGenerator(cfg).gen(until_time=5.0)
    run2 = StockGenerator(cfg).gen(until_time=5.0)

    arr1 = run1.history.to_numpy(as_ticks=True)
    arr2 = run2.history.to_numpy(as_ticks=True)

    _assert_history_equal(arr1, arr2)
    assert run1.events == run2.events
    assert run1.trades == run2.trades
