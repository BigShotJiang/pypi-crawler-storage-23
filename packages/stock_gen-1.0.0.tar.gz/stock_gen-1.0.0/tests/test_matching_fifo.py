from stock_gen.orderbook import OrderBook
from stock_gen.types import Side


def test_fifo_matching_same_price_level() -> None:
    ob = OrderBook()
    p = 10_000

    oid1 = ob.add_limit_resting(side=Side.ASK, price_ticks=p, qty=5)
    oid2 = ob.add_limit_resting(side=Side.ASK, price_ticks=p, qty=7)

    trades = ob.process_market(side=Side.BID, qty=6, t=0.0)
    assert [(tr.price_ticks, tr.qty, tr.aggressor) for tr in trades] == [
        (p, 5, Side.BID),
        (p, 1, Side.BID),
    ]

    # FIFO: the first order should be fully filled first.
    remaining = list(ob.iter_orders_priority(Side.ASK))
    assert all(order_id != oid1 for order_id, _px, _qty in remaining)
    assert remaining[0][0] == oid2
    assert remaining[0][2] == 6

