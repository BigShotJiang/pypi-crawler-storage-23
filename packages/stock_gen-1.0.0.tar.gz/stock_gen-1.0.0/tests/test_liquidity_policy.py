import pytest

import numpy as np

from stock_gen import EventCapPolicy, LiquidityPolicy, StockGenerator, StockGeneratorConfig
from stock_gen.config import ExpLinearIntensityConfig, SizeConfig
from stock_gen.types import EventType


def _m_b_only_intensity() -> ExpLinearIntensityConfig:
    theta = {
        EventType.M_B: np.asarray([10.0, 0.0, 0.0, 0.0, 0.0, 0.0], dtype=np.float64),
    }
    return ExpLinearIntensityConfig(theta=theta)


def _small_book_large_market_size() -> SizeConfig:
    return SizeConfig(
        market_mu=8.0,
        market_sigma=0.0,
        improve_mu=0.0,
        improve_sigma=0.0,
        join_mu=0.0,
        join_sigma=0.0,
        deep_mu=0.0,
        deep_sigma=0.0,
        max_order_qty=10_000,
    )


def test_allow_empty_policy_keeps_empty_side_without_repair() -> None:
    cfg = StockGeneratorConfig(
        dt=1.0,
        seed=11,
        init_levels_per_side=1,
        init_orders_per_level=1,
        intensity=_m_b_only_intensity(),
        size=_small_book_large_market_size(),
        max_events_per_step=1,
        event_cap_policy=EventCapPolicy.TRUNCATE_AND_FLAG,
        liquidity_policy=LiquidityPolicy.ALLOW_EMPTY,
    )
    sg = StockGenerator(cfg)

    step_result = sg.step()
    frame = step_result.frame

    assert frame.best_ask_ticks is None
    assert frame.spread_ticks is None
    assert step_result.events_processed == 1
    assert not any(event.synthetic for event in sg.get_events())


def test_halt_on_empty_policy_raises() -> None:
    cfg = StockGeneratorConfig(
        dt=1.0,
        seed=17,
        init_levels_per_side=1,
        init_orders_per_level=1,
        intensity=_m_b_only_intensity(),
        size=_small_book_large_market_size(),
        max_events_per_step=1,
        event_cap_policy=EventCapPolicy.TRUNCATE_AND_FLAG,
        liquidity_policy=LiquidityPolicy.HALT_ON_EMPTY,
    )
    sg = StockGenerator(cfg)

    with pytest.raises(RuntimeError, match="one-sided book"):
        sg.step()
