import numpy as np

from stock_gen import StockGenerator, StockGeneratorConfig


def _to_compact_arrays(sg: StockGenerator, until_time: float) -> dict[str, np.ndarray]:
    result = sg.gen(until_time=until_time)
    return result.history.to_numpy(as_ticks=True)


def test_reset_with_same_seed_replays_same_path() -> None:
    cfg = StockGeneratorConfig(seed=77, dt=0.5)
    sg = StockGenerator(cfg)

    first = _to_compact_arrays(sg, until_time=4.0)
    sg.reset(seed=77)
    second = _to_compact_arrays(sg, until_time=4.0)

    for key in [
        "t",
        "mid",
        "mid_valid",
        "spread_ticks",
        "spread_valid",
        "best_bid_ticks",
        "best_ask_ticks",
        "bid_px_ticks",
        "ask_px_ticks",
        "bid_qty",
        "ask_qty",
        "recent_flow",
    ]:
        np.testing.assert_allclose(first[key], second[key], equal_nan=True, err_msg=f"mismatch at key={key}")
