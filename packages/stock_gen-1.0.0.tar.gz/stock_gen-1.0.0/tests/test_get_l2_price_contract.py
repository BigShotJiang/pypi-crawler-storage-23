import numpy as np

from stock_gen import EventCapPolicy, LiquidityPolicy, StockGenerator, StockGeneratorConfig
from stock_gen.config import ExpLinearIntensityConfig, SizeConfig
from stock_gen.types import EventType


def _one_sided_cfg() -> StockGeneratorConfig:
    theta = {
        EventType.M_B: np.asarray([10.0, 0.0, 0.0, 0.0, 0.0, 0.0], dtype=np.float64),
    }
    return StockGeneratorConfig(
        dt=1.0,
        seed=313,
        depth_levels=4,
        init_levels_per_side=1,
        init_orders_per_level=1,
        intensity=ExpLinearIntensityConfig(theta=theta),
        size=SizeConfig(
            market_mu=8.0,
            market_sigma=0.0,
            improve_mu=0.0,
            improve_sigma=0.0,
            join_mu=0.0,
            join_sigma=0.0,
            deep_mu=0.0,
            deep_sigma=0.0,
            max_order_qty=10_000,
        ),
        max_events_per_step=1,
        event_cap_policy=EventCapPolicy.TRUNCATE_AND_FLAG,
        liquidity_policy=LiquidityPolicy.ALLOW_EMPTY,
    )


def test_get_l2_as_ticks_false_uses_nan_for_missing_prices() -> None:
    sg = StockGenerator(_one_sided_cfg())
    sg.step()

    l2 = sg.get_l2(as_ticks=False)
    assert l2.ask_px_valid.shape == (4,)
    assert l2.bid_px_valid.shape == (4,)
    assert np.all(~l2.ask_px_valid)
    assert np.all(np.isnan(l2.ask_px))


def test_get_l2_as_ticks_true_keeps_negative_tick_sentinel() -> None:
    sg = StockGenerator(_one_sided_cfg())
    sg.step()

    l2 = sg.get_l2(as_ticks=True)
    assert np.all(~l2.ask_px_valid)
    assert np.all(l2.ask_px == -1)


def test_l2_validity_masks_are_read_only() -> None:
    sg = StockGenerator(StockGeneratorConfig(seed=11))
    sg.step()
    l2 = sg.get_l2(as_ticks=False)

    with np.testing.assert_raises(ValueError):
        l2.bid_px_valid[0] = False
    with np.testing.assert_raises(ValueError):
        l2.ask_px_valid[0] = False
