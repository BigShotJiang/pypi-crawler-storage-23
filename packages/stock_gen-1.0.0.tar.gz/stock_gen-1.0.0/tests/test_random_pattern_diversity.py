from __future__ import annotations

from stock_gen import StockGenerator, StockGeneratorConfig
from stock_gen.types import EventType


def _path_signature(seed: int) -> tuple[int, int, tuple[int, ...], float]:
    cfg = StockGeneratorConfig(seed=seed, dt=1.0, end_time=60.0)
    result = StockGenerator(cfg).gen()
    arr = result.history.to_numpy(as_ticks=True)
    head_spread = tuple(int(x) for x in arr["spread_ticks"][:12])
    terminal_flow = float(arr["recent_flow"][-1]) if arr["recent_flow"].size > 0 else 0.0
    return (len(result.events), len(result.trades), head_spread, terminal_flow)


def test_random_pattern_multiseed_paths_are_diverse() -> None:
    signatures = {_path_signature(seed) for seed in (11, 12, 13, 14)}
    assert len(signatures) >= 3


def test_pattern_jump_emits_synthetic_market_events() -> None:
    cfg = StockGeneratorConfig(seed=1, dt=1.0, end_time=600.0)
    events = StockGenerator(cfg).gen().events
    jumps = [ev for ev in events if ev.reason == "pattern_jump"]

    assert jumps
    assert all(ev.synthetic for ev in jumps)
    assert all(ev.event_type in {EventType.M_B, EventType.M_A} for ev in jumps)
    assert all(ev.qty is not None and int(ev.qty) > 0 for ev in jumps)
