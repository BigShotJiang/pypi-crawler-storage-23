from __future__ import annotations

from dataclasses import replace

import numpy as np

from stock_gen import StockGenerator, StockGeneratorConfig
from stock_gen.config import DepthMaintenanceConfig
from stock_gen.types import DepthMaintenancePolicy


def _tail_depth_stats(cfg: StockGeneratorConfig) -> tuple[float, float, float, float]:
    data = StockGenerator(cfg).gen().history.to_numpy(as_ticks=True)
    n = len(data["t"])
    start = int(n * 0.7)
    bid_levels = data["bid_px_valid"][start:].sum(axis=1).astype(np.float64)
    ask_levels = data["ask_px_valid"][start:].sum(axis=1).astype(np.float64)
    bid_qty = data["bid_qty"][start:].sum(axis=1).astype(np.float64)
    ask_qty = data["ask_qty"][start:].sum(axis=1).astype(np.float64)
    return (
        float(bid_levels.mean()),
        float(ask_levels.mean()),
        float(bid_qty.mean()),
        float(ask_qty.mean()),
    )


def test_default_depth_maintenance_improves_tail_depth_vs_off_policy() -> None:
    base_cfg = StockGeneratorConfig(seed=1299, end_time=800.0, depth_levels=10)
    off_cfg = replace(
        base_cfg,
        depth_maintenance=DepthMaintenanceConfig(policy=DepthMaintenancePolicy.OFF),
    )

    on_bid_lv, on_ask_lv, on_bid_qty, on_ask_qty = _tail_depth_stats(base_cfg)
    off_bid_lv, off_ask_lv, off_bid_qty, off_ask_qty = _tail_depth_stats(off_cfg)

    assert on_bid_lv >= off_bid_lv + 1.0
    assert on_ask_lv >= off_ask_lv + 1.0
    assert on_bid_qty >= off_bid_qty + 5.0
    assert on_ask_qty >= off_ask_qty + 5.0


def test_default_tail_depth_remains_visibly_populated() -> None:
    cfg = StockGeneratorConfig(seed=1299, end_time=800.0, depth_levels=10)
    bid_levels, ask_levels, _, _ = _tail_depth_stats(cfg)

    assert bid_levels >= 5.0
    assert ask_levels >= 5.0
