from __future__ import annotations

import matplotlib
import numpy as np
import pytest

from stock_gen import StockGenerator, StockGeneratorConfig
from stock_gen import viz

matplotlib.use("Agg")


def test_prepare_heatmap_matrix_masks_invalid_and_applies_log() -> None:
    qty = np.asarray([[1, 10, 100], [5, 0, 50]], dtype=np.int64)
    valid = np.asarray([[True, False, True], [True, True, False]], dtype=bool)

    values, vmax = viz._prepare_heatmap_matrix(
        qty=qty,
        valid=valid,
        mask_invalid=True,
        normalize="log1p",
        vmax_quantile=1.0,
    )

    assert np.isnan(values[0, 1])
    assert np.isnan(values[1, 2])
    assert values[0, 0] == pytest.approx(np.log1p(1.0))
    assert values[0, 2] == pytest.approx(np.log1p(100.0))
    assert vmax == pytest.approx(np.nanmax(values))


def test_prepare_heatmap_matrix_rejects_invalid_quantile() -> None:
    qty = np.asarray([[1]], dtype=np.int64)
    valid = np.asarray([[True]], dtype=bool)

    with pytest.raises(ValueError, match="vmax_quantile"):
        viz._prepare_heatmap_matrix(
            qty=qty,
            valid=valid,
            mask_invalid=True,
            normalize="none",
            vmax_quantile=0.0,
        )


def test_plot_l2_heatmap_accepts_visibility_controls() -> None:
    cfg = StockGeneratorConfig(seed=17, end_time=15.0, depth_levels=5)
    hist = StockGenerator(cfg).gen().history

    axes = viz.plot_l2_heatmap(
        hist,
        side="both",
        space="rank",
        mask_invalid=True,
        normalize="log1p",
        vmax_quantile=0.95,
    )
    assert hasattr(axes, "__getitem__")


def test_plot_l2_heatmap_rejects_invalid_compact_range_inputs() -> None:
    cfg = StockGeneratorConfig(seed=21, end_time=8.0, depth_levels=4)
    hist = StockGenerator(cfg).gen().history

    with pytest.raises(ValueError, match="y_range"):
        viz.plot_l2_heatmap(
            hist,
            side="bid",
            space="price",
            y_range="invalid",  # type: ignore[arg-type]
        )

    with pytest.raises(ValueError, match="price_window_ticks"):
        viz.plot_l2_heatmap(
            hist,
            side="bid",
            space="price",
            price_window_ticks="bad",  # type: ignore[arg-type]
        )
