import pytest

from stock_gen.orderbook import OrderBook
from stock_gen.types import Side


def test_replace_rolls_back_when_new_order_is_invalid() -> None:
    ob = OrderBook()
    order_id = ob.add_limit_resting(side=Side.BID, price_ticks=100, qty=5)
    before = list(ob.iter_orders_priority(Side.BID))

    with pytest.raises(ValueError, match="qty must be positive"):
        ob.replace(order_id, new_price_ticks=101, new_qty=0)

    assert list(ob.iter_orders_priority(Side.BID)) == before
    assert ob.best_price_ticks(Side.BID) == 100
    assert ob.total_qty(Side.BID) == 5


def test_replace_can_fully_execute_without_new_resting_order() -> None:
    ob = OrderBook()
    bid_id = ob.add_limit_resting(side=Side.BID, price_ticks=100, qty=5)
    ask_id = ob.add_limit_resting(side=Side.ASK, price_ticks=101, qty=4)

    new_order_id, trades = ob.replace(bid_id, new_price_ticks=101, new_qty=4, t=1.5)

    assert new_order_id is None
    assert len(trades) == 1
    assert trades[0].t == pytest.approx(1.5)
    assert trades[0].price_ticks == 101
    assert trades[0].qty == 4
    assert trades[0].aggressor is Side.BID
    assert ob.get_order(bid_id) is None
    assert ob.get_order(ask_id) is None
    assert ob.total_qty(Side.BID) == 0
    assert ob.total_qty(Side.ASK) == 0
