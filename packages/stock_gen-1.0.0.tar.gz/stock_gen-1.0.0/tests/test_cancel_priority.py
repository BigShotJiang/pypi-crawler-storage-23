from stock_gen.models_cancel import select_order_by_priority_index
from stock_gen.orderbook import OrderBook
from stock_gen.types import Side


def test_cancel_selection_by_priority_index() -> None:
    ob = OrderBook()

    # Priority order for bids: higher price first.
    oid1 = ob.add_limit_resting(side=Side.BID, price_ticks=100, qty=10)  # cum=10
    oid2 = ob.add_limit_resting(side=Side.BID, price_ticks=99, qty=10)  # cum=20
    oid3 = ob.add_limit_resting(side=Side.BID, price_ticks=98, qty=10)  # cum=30

    assert select_order_by_priority_index(ob, side=Side.BID, xi=0.0) == oid1
    assert select_order_by_priority_index(ob, side=Side.BID, xi=0.5) == oid2
    assert select_order_by_priority_index(ob, side=Side.BID, xi=0.9999) == oid3

