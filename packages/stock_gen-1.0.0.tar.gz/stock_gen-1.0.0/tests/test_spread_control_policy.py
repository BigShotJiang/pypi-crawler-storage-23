from __future__ import annotations

from numpy.random import default_rng

from stock_gen.config import SizeConfig, StockGeneratorConfig
from stock_gen.engine.spread_control import apply_spread_control
from stock_gen.orderbook import OrderBook
from stock_gen.sim_state import SimulationState
from stock_gen.types import EventType, PlacementMode, Side


def test_spread_control_tightens_wide_book_to_target_one_tick() -> None:
    cfg = StockGeneratorConfig(
        size=SizeConfig(
            market_mu=0.0,
            market_sigma=0.0,
            improve_mu=0.0,
            improve_sigma=0.0,
            join_mu=0.0,
            join_sigma=0.0,
            deep_mu=0.0,
            deep_sigma=0.0,
            max_order_qty=50,
        )
    )
    ob = OrderBook(min_price_ticks=0, allow_locked_book=False)
    _ = ob.add_limit_resting(side=Side.BID, price_ticks=100, qty=7)
    _ = ob.add_limit_resting(side=Side.ASK, price_ticks=105, qty=9)
    state = SimulationState()

    captured: list[dict[str, object]] = []
    inserted = apply_spread_control(
        ob=ob,
        state=state,
        cfg=cfg,
        rng=default_rng(11),
        append_event=lambda **kwargs: captured.append(kwargs),
    )

    assert inserted == 1
    assert ob.spread_ticks() == 1
    assert captured
    ev = captured[0]
    assert ev["synthetic"] is True
    assert ev["reason"] == "spread_control"
    assert ev["event_type"] in (EventType.L_B, EventType.L_A)
    assert ev["placement_mode"] is PlacementMode.IMPROVE
