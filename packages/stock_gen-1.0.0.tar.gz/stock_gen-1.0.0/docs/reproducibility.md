# Reproducibility Guide

This project is deterministic when seed, config, and runtime environment are fixed.

## Deterministic Recipe

1. Pin package version (`stock-gen==X.Y.Z`).
2. Fix `StockGeneratorConfig(seed=...)` to a concrete integer.
3. Keep full config identical, including nested config values (`cancel`, `regime`, policies).
4. Start from a fresh `StockGenerator(cfg)` or call `reset(seed=...)`.

## Recommended Equality Check

```python
import numpy as np
from stock_gen import StockGenerator, StockGeneratorConfig

cfg = StockGeneratorConfig(seed=2026, dt=0.5, end_time=5.0)
run1 = StockGenerator(cfg).gen(until_time=5.0).history.to_numpy(as_ticks=True)
run2 = StockGenerator(cfg).gen(until_time=5.0).history.to_numpy(as_ticks=True)

for key in ["t", "spread_ticks", "best_bid_ticks", "best_ask_ticks", "bid_px_ticks", "ask_px_ticks"]:
    np.testing.assert_array_equal(run1[key], run2[key])
```

## Common Pitfalls

- `seed=None` means non-deterministic behavior.
- `gen()` is stateful and continues from current time.
- `SimulationResult.steps` is cumulative per instance.
- Comparing `as_ticks=False` outputs can include floating-point representation noise.

## What To Log

- `stock-gen` version
- Python version
- NumPy version
- full `StockGeneratorConfig`
- random seed
- horizon (`until_time` or `end_time`)
