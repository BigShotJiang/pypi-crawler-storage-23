# Architecture Overview

`stock-gen` is an event-driven single-asset CLOB simulator with deterministic replay boundaries and policy-driven safety behavior.

## Design Goals

- deterministic replay for fixed config + seed
- explicit contracts for frames/events/trades exports
- robust handling of edge states (one-sided books, event caps)
- extensible microstructure internals without widening public API

## Module Layout

- `stock_gen/generator.py`
  - public orchestration API (`step`, `gen`, `reset`, snapshot getters)
- `stock_gen/orderbook.py`
  - price-time-priority matching engine, partial cancel, replace, and no-cross/lock constraints
- `stock_gen/engine/`
  - `frame_runner.py`: per-frame event loop kernel and policy checkpoints
  - `event_handlers.py`: concrete event application and event metadata emission
  - `features.py`: feature and intensity assembly
  - `depth_policy.py`: synthetic depth replenishment
  - `spread_control.py`: synthetic spread tightening near snapshot time
  - `snapshot.py`: immutable L2/frame snapshots
  - `stochastic_pattern.py`: internal random regime process
- `stock_gen/runtime/`
  - `history_store.py`: centralized history buffers and immutable views
  - `checkpoint.py`: rollback checkpoint capture/restore
  - `step_transaction.py`: policy-driven transactional step wrapper
- `stock_gen/models_*`
  - intensity, placement, size, cancel samplers
  - joint flow sampler (`models_joint_flow.py`)

## Step Execution Flow

1. Start frame interval `[t, t+dt]`.
2. Ensure two-sided liquidity according to `LiquidityPolicy`.
3. Build event-loop features and intensities.
4. Sample next event time.
5. Advance stochastic pattern state and optional jump shock.
6. Route event via kernel:
   - `flow_kernel="joint_v1"`: joint action sampling with feasibility masks/adaptation.
   - `flow_kernel="legacy_factorized"`: factorized event-type sampling.
7. Apply event through dispatcher and record events/trades.
8. Repeat until interval end or event-cap policy stop.
9. Apply snapshot-time liquidity checks.
10. Apply depth maintenance.
11. Optionally apply spread control at snapshot boundary.
12. Build immutable frame snapshot and append `StepResult`.

## Joint Flow and Spread Controls

- `JointFlowConfig` governs logits, adaptation bounds, and adaptation strength.
- `SpreadControlConfig` can tighten wide books before snapshot export using synthetic improve orders.
- `BookConstraintConfig` constrains minimum allowed tick and lock behavior.

See [joint-order-flow.md](joint-order-flow.md) for details.

## Event Metadata Contract

Events carry additional quantity audit fields:
- `requested_qty`
- `executed_qty`
- `resting_qty`
- `canceled_qty`

These fields are emitted directly by event handlers and synthetic policies to make per-event accounting explicit.

## Atomic Rollback Path

For every `step()` call:

- `run_step_transaction(...)` captures checkpoint.
- Frame execution runs.
- If any exception is raised (including `EventCapExceededError`), checkpoint is restored and the exception is re-raised.

No partial frame mutation escapes on failed steps.

## Determinism Boundaries

Deterministic when all are fixed:

- package version
- Python/NumPy environment
- full config
- seed

Potential drift sources:

- `seed=None`
- environment/version changes
- changed defaults or parameter values between releases
