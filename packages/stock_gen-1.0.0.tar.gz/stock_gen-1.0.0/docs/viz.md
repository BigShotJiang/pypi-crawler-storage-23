# Visualization Guide

`stock_gen.viz` provides quick plotting helpers from `MarketHistory` or simulator instances.

## Imports

```python
from stock_gen import StockGenerator, StockGeneratorConfig
from stock_gen import viz
```

## Time-Series Plots

- `viz.plot_mid(obj, *, ax=None)`
- `viz.plot_spread(obj, *, ax=None, in_ticks=True)`

## L2 Heatmap

```python
axes = viz.plot_l2_heatmap(
    history,
    side="both",
    space="price",          # "price" (default) or "rank"
    price_window_ticks="auto",  # int or "auto" (used when space="price")
    y_range="auto",         # "auto", "full", "side", or "occupied"
    mask_invalid=True,
    normalize="log1p",      # "none" or "log1p"
    vmax_quantile=0.99,
)
```

### `space="rank"`

- Y-axis is level index (`0` = best).
- Useful for queue-layer visibility and depth-shape over time.

### `space="price"` (default)

- Y-axis is relative tick distance from frame mid.
- Useful for observing depth migration around price, not just top-K rank occupancy.
- Compact defaults reduce vertical empty space:
  - `side in {"bid", "ask"}` + `space="price"` -> `y_range="side"` (default via `y_range="auto"`).
  - `side="both"` + `space="price"` -> `y_range="occupied"` (default via `y_range="auto"`).

### Price-Space Range Controls

- `price_window_ticks`: positive `int` or `"auto"` (default).
  - `"auto"` picks a window from observed relative depth placement.
- `y_range`:
  - `"auto"` (default): compact defaults based on `side`.
  - `"full"`: symmetric `[-window, +window]` range.
  - `"side"`: one-sided compact range (`[-window, 0]` for bids, `[0, +window]` for asks).
  - `"occupied"`: crop to bins that contain any valid depth over time.

## Visibility Controls

- `mask_invalid=True`: hide invalid/missing levels (shown as NaN).
- `normalize="log1p"`: improve long-horizon contrast for heavy-tailed quantities.
- `vmax_quantile`: robust color clipping; set `None` for full scale.

## Migration Notes

- Previous behavior used a fixed symmetric window in price-space heatmaps.
- To keep legacy full-range output explicitly, set:

```python
viz.plot_l2_heatmap(
    history,
    side="both",
    space="price",
    price_window_ticks=60,
    y_range="full",
)
```

## Notes

- Heatmaps consume `history.to_numpy(as_ticks=True)` internally.
- For deterministic plots across runs, fix `seed` and config.
