# Documentation Index

English documentation is the canonical source for this project.

## Getting Started

- Project overview and quickstart: [../README.md](../README.md)
- Reproducibility checklist: [reproducibility.md](reproducibility.md)
- Example scripts: [../examples/basic_run.py](../examples/basic_run.py), [../examples/plot_demo.py](../examples/plot_demo.py)

## Public API and Contracts

- API reference: [api.md](api.md)
- Config reference: [config-reference.md](config-reference.md)
- Data contract: [data-contract.md](data-contract.md)
- Joint order-flow model: [joint-order-flow.md](joint-order-flow.md)
- Visualization guide: [viz.md](viz.md)

## Maintainer Docs

- Architecture notes: [architecture.md](architecture.md)
- Release flow: [release.md](release.md)
- Current migration guide: [archive/migration-v1.0.md](archive/migration-v1.0.md)
- Older migrations: `docs/archive/`

## Language

- Korean landing page: [../README.ko.md](../README.ko.md)

## Version History

- Changelog: [../CHANGELOG.md](../CHANGELOG.md)
