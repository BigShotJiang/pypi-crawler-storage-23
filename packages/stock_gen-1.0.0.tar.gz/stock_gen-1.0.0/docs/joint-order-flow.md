# Joint Order-Flow Model

This page documents the v1.0 event-flow kernel and related controls.

## Kernel Modes

`StockGeneratorConfig.flow_kernel` supports:

- `"joint_v1"` (default)
- `"legacy_factorized"`

`joint_v1` samples a joint action over event type, side, and execution style.
`legacy_factorized` keeps the older factorized event-type sampling path.

## `joint_v1` Execution Path

Inside the frame loop:

1. Build event-loop features and per-event intensities (`lambdas`).
2. If one event type dominates intensity share (`>= 0.90`), dispatch that event directly.
3. Else, if replace intensity is active, sample replace with replace-proportional probability.
4. Else, sample a joint action category from `JointFlowConfig.action_logits` and dispatch it.

The joint action sampler:
- uses a 12-category action space
- masks infeasible actions (for example no market buy when no ask book)
- applies adaptive market/cancel shifts based on rolling event shares

## Joint Features

`JointFlowConfig.action_logits` multiplies a 9-element feature vector:

`[1, log1p(spread), log1p(best_bid_qty), log1p(best_ask_qty), imbalance, recent_flow, no_trade_streak_norm, market_share, cancel_share]`

Shape contract:
- `action_logits`: `(12, 9)`

## `JointFlowConfig` Defaults

- `adaptation_enabled=True`
- `adaptation_warmup_events=0`
- `market_share_floor=0.20`
- `market_share_ceiling=0.55`
- `cancel_share_floor=0.10`
- `cancel_share_ceiling=0.48`
- `adaptation_strength=18.0`
- `max_adaptation_shift=6.0`

Adaptation raises/lowers market and cancel category logits to keep rolling shares in-range.

## Spread and Book Constraints

`SpreadControlConfig` (default enabled) can add synthetic improve orders before snapshot export:
- `target_spread_ticks=1`
- `enforce_at_snapshot=True`
- `max_repair_orders_per_step=2`

`BookConstraintConfig` constrains order-book structure:
- `min_price_ticks=0`
- `allow_locked_book=False`

These constraints apply to normal and synthetic order insertion paths.

## Event Quantity Fields

For downstream accounting, event records expose:
- `requested_qty`
- `executed_qty`
- `resting_qty`
- `canceled_qty`

This allows per-event reconciliation without re-deriving from trade/book diffs.

## Reproducing Pre-v1.0 Behavior

If you need closer legacy flow behavior:

```python
from stock_gen import SpreadControlConfig, StockGeneratorConfig

cfg = StockGeneratorConfig(
    flow_kernel="legacy_factorized",
    spread_control=SpreadControlConfig(enabled=False),
)
```

Also pin any other defaults your pipeline previously assumed.
