# Migration Guide: pre-v1.0 -> v1.0

v1.0 makes the joint flow kernel and new configuration surfaces first-class.

## Breaking Changes

1. Default flow kernel is now `flow_kernel="joint_v1"`.
2. Event payloads now include quantity-audit fields:
   - `requested_qty`
   - `executed_qty`
   - `resting_qty`
   - `canceled_qty`
3. The obsolete consolidated legacy migration note was removed.

## Public Configuration Additions

`StockGeneratorConfig` now exposes:
- `joint_flow: JointFlowConfig`
- `spread_control: SpreadControlConfig`
- `book_constraints: BookConstraintConfig`

Related default behavior:
- `spread_control.enabled=True`
- `spread_control.target_spread_ticks=1`
- `book_constraints.allow_locked_book=False`

## Migration Steps

1. If you need legacy event-flow sampling, set:

```python
cfg = StockGeneratorConfig(flow_kernel="legacy_factorized")
```

2. If synthetic snapshot-time spread tightening should be disabled:

```python
from stock_gen import SpreadControlConfig, StockGeneratorConfig

cfg = StockGeneratorConfig(
    spread_control=SpreadControlConfig(enabled=False),
)
```

3. If your event schema is strict, add nullable fields for:
- `requested_qty`
- `executed_qty`
- `resting_qty`
- `canceled_qty`

4. Repoint old migration links to:
- this page (`migration-v1.0.md`)
- `CHANGELOG.md`

## Quick Verification Checklist

- Regenerate one reference run with fixed `seed`.
- Check event ingestion still succeeds with new quantity fields.
- Confirm expected spread behavior at snapshot boundaries.
- Confirm release/docs links no longer reference removed legacy migration notes.
