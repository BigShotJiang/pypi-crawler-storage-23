# Migration Guide: v0.6 -> v0.7

v0.7 focuses on simulator realism, visualization clarity, and internal modularization.

## Breaking Changes

1. `StockGeneratorConfig.tick_size` default changed from `0.01` to `1.0`.
2. `viz.plot_l2_heatmap(...)` default space changed from rank-style to `space="price"`.

## Behavior Changes

- Default depth maintenance and event dynamics are retuned for better long-horizon depth shape.
- Internal stochastic regime transitions are enabled by default to increase path diversity.
- Rare synthetic jump events are emitted with `synthetic=True` and `reason="pattern_jump"`.

## API Additions

- `viz.plot_l2_heatmap(..., space="rank"|"price", price_window_ticks=60, ...)`

## Migration Steps

1. If your code assumed cent-scale prices by default, set `tick_size=0.01` explicitly.
2. If your dashboards depended on rank heatmap semantics, call:

```python
viz.plot_l2_heatmap(history, space="rank")
```

3. If event analytics exclude synthetic events, filter by `event.synthetic is False` or `event.reason`.
4. Refresh reproducibility baselines after upgrading (defaults changed).

## Compatibility Notes

- No public pattern configuration object was added in v0.7.
- Pattern diversity remains deterministic under fixed `seed`.
