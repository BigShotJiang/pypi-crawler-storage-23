# Migration Guide: v0.7 -> v0.8

v0.8 focuses on order-book safety invariants, replacement-order realism, and compact heatmap defaults.

## Breaking Changes

1. `viz.plot_l2_heatmap(..., space="price")` defaults changed:
   - `price_window_ticks` default: `60` -> `"auto"`
   - new `y_range` parameter default: `"auto"` (compact behavior)
2. Replacement events may now set `order_id=None` when the replacement is fully executed.
3. `step()` now rolls back simulator state/history on any exception before re-raising.

## Behavior Changes

- Resting-book inserts that would leave the book crossed are rejected.
- `replace` now behaves as cancel-then-limit-submit; replacement may trade immediately.
- Price-space heatmaps avoid unnecessary vertical empty space by default.

## Migration Steps

1. If your charts depended on fixed symmetric y-range, pin explicit parameters:

```python
viz.plot_l2_heatmap(
    history,
    side="both",
    space="price",
    price_window_ticks=60,
    y_range="full",
)
```

2. If your event pipeline assumed replace events always have `order_id`, accept nullable values:
   - treat `order_id=None` as "fully filled replacement (no resting order)".
3. If you had custom failure-recovery wrappers around `step()`, review whether they duplicate built-in rollback.

## Compatibility Notes

- Existing `space="rank"` heatmap behavior is unchanged.
- `events_processed` compatibility alias in `StepResult` remains available.
