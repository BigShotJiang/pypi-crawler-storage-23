"""Compatibility endpoint package namespace."""

from databricks_api.endpoints.catalog import ENDPOINT_CATALOG

__all__ = ["ENDPOINT_CATALOG"]
