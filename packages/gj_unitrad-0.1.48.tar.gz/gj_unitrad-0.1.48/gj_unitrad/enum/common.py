"""
Unitrade Trading Platform Python Enums
Generated from C++ enum bindings
"""

from enum import Enum


class ErrorCode(Enum):
    """Error codes for QTap platform"""
    ErrorCode_Unknown = 0
    ErrorCode_Success = 1
    ErrorCode_Error = 2
    ErrorCode_InvalidArgument = 3
    ErrorCode_FileNotFound = 4
    ErrorCode_OutOfMemory = 5
    ErrorCode_RegistrationDenied = 6
    ErrorCode_IncompatibleVersion = 7
    ErrorCode_ServiceNotFound = 8
    ErrorCode_ServiceNotAvailable = 9
    ErrorCode_TopicNotFound = 10
    ErrorCode_AccessDenied = 11
    ErrorCode_InvalidAccessDomain = 12
    ErrorCode_NotApplicable = 13
    ErrorCode_Timeout = 14
    ErrorCode_NotSupported = 15
    ErrorCode_IsNotLast = 16


class SubscribeType(Enum):
    """Subscription types"""
    SubscribeType_Unknown = 0
    SubscribeType_Future_And_Option = 1
    SubscribeType_Future = 2
    SubscribeType_Option = 3
    SubscribeType_Dominant = 4
    SubscribeType_Instrument = 5


class CounterType(Enum):
    """Counter types"""
    CounterType_Unknown = 0
    CounterType_Market = 1
    CounterType_Trader = 2


class InstrumentType(Enum):
    """Types of financial instruments"""
    InstrumentType_Unknown = 0
    InstrumentType_Stock = 1
    InstrumentType_Future = 2
    InstrumentType_Options = 3
    InstrumentType_StockOption = 4
    InstrumentType_TechStock = 5
    InstrumentType_Index = 6
    InstrumentType_Bond = 7
    InstrumentType_Fund = 8
    InstrumentType_Repo = 9


class OptionsType(Enum):
    """Options types"""
    OptionsType_Unknown = 0
    OptionsType_Call = 1
    OptionsType_Put = 2


class ExecType(Enum):
    """Execution types"""
    ExecType_Unknown = 0
    ExecType_Cancel = 1
    ExecType_Trade = 2


class BsFlag(Enum):
    """Buy/Sell flags"""
    BsFlag_Unknown = 0
    BsFlag_Buy = 1
    BsFlag_Sell = 2


class SideType(Enum):
    """Order side types"""
    SideType_Unknown = 0
    SideType_Buy = 1
    SideType_Sell = 2
    SideType_Lock = 3
    SideType_Unlock = 4
    SideType_Exec = 5
    SideType_Drop = 6


class OffsetType(Enum):
    """Offset types for futures trading"""
    OffsetType_Unknown = 0
    OffsetType_Open = 1
    OffsetType_Close = 2
    OffsetType_CloseToday = 3
    OffsetType_CloseYesterday = 4


class HedgeFlag(Enum):
    """Hedge flags"""
    HedgeFlag_Unknown = 0
    HedgeFlag_Speculation = 1
    HedgeFlag_Arbitrage = 2
    HedgeFlag_Hedge = 3
    HedgeFlag_Covered = 4


class OrderActionFlag(Enum):
    """Order action flags"""
    OrderActionFlag_Unknown = 0
    OrderActionFlag_Cancel = 1


class PriceType(Enum):
    """Order price types"""
    PriceTypeUnknown = 0
    PriceTypeLimit = 1
    PriceTypeAny = 2
    PriceTypeFakBest5 = 3
    PriceTypeForwardBest = 4
    PriceTypeReverseBest = 5
    PriceTypeFak = 6
    PriceTypeFok = 7


class VolumeCondition(Enum):
    """Volume conditions"""
    VolumeCondition_Unknown = 0
    VolumeCondition_Any = 1
    VolumeCondition_Min = 2
    VolumeCondition_All = 3


class TimeCondition(Enum):
    """Time conditions"""
    TimeCondition_Unknown = 0
    TimeCondition_IOC = 1
    TimeCondition_GFD = 2
    TimeCondition_GTC = 3


class OrderStatus(Enum):
    """Order status values"""
    OrderStatus_Unknown = 0
    OrderStatus_Submitted = 1
    OrderStatus_Pending = 2
    OrderStatus_Cancelled = 3
    OrderStatus_Error = 4
    OrderStatus_Insert_Error = 5
    OrderStatus_Filled = 6
    OrderStatus_PartialFilledNotActive = 7
    OrderStatus_PartialFilledActive = 8
    OrderStatus_LocalSubmitted = 9
    OrderStatus_Finished = 10


class DirectionType(Enum):
    """Direction types"""
    DirectionType_Unknown = 0
    DirectionType_Net = 1
    DirectionType_Long = 2
    DirectionType_Short = 3


class PositionDateType(Enum):
    """Position date types"""
    PositionDateType_Unknown = 0
    PositionDateType_Today = 1
    PositionDateType_History = 2


class AccountType(Enum):
    """Account types"""
    AccountType_Unknown = 0
    AccountType_Stock = 1
    AccountType_Credit = 2
    AccountType_Future = 3


class CommissionRateMode(Enum):
    """Commission rate modes"""
    CommissionRateMode_Unknown = 0
    CommissionRateMode_ByMoney = 1
    CommissionRateMode_ByVolume = 2


class LedgerCategory(Enum):
    """Ledger categories"""
    LedgerCategory_Unknown = 0
    LedgerCategory_Account = 1
    LedgerCategory_Strategy = 2


class ClientTopicType(Enum):
    """Client topic types"""
    ClientTopicType_Null = 0
    ClientTopicType_Request = 1
    ClientTopicType_Response = 2
    ClientTopicType_Subscribe = 3
    ClientTopicType_Unsubscribe = 4
    ClientTopicType_Publish = 5


class PlaceOrderType(Enum):
    """Place order types"""
    PlaceOrderType_Null = 0
    PlaceOrderType_FAK = 1
    PlaceOrderType_FOK = 2


class StrategyCtrlOption(Enum):
    """Strategy control options"""
    StrategyCtrlOption_Null = 0
    StrategyCtrlOption_Start = 1
    StrategyCtrlOption_Stop = 2


class StrategyOperatingState(Enum):
    """Strategy operating states"""
    StrategyOperatingState_Null = 0
    StrategyOperatingState_Ready = 1
    StrategyOperatingState_Running = 2
    StrategyOperatingState_Stop = 3
    StrategyOperatingState_Finish = 4


class StrategyOperatingDirection(Enum):
    """Strategy operating directions"""
    StrategyOperatingDirection_Unknown = 0
    StrategyOperatingDirection_Buy = 1
    StrategyOperatingDirection_Sell = 2


class StrategtChaseOrdersType(Enum):
    """Strategy chase orders types"""
    StrategtChaseOrdersType_Unknown = 0
    StrategtChaseOrdersType_Need = 1
    StrategtChaseOrdersType_NoNeed = 2


class StrategyArbitrageDirection(Enum):
    """Strategy arbitrage directions"""
    StrategyArbitrageDirection_NUll = 0
    StrategyArbitrageDirection_Forward = 1
    StrategyArbitrageDirection_Reverse = 2


class CounterReturnCode(Enum):
    """Counter return codes"""
    CounterReturnCode_Unknown = 0
    CounterReturnCode_RegisterSuccess = 1
    CounterReturnCode_RegisterFailure = 2
    CounterReturnCode_AuthenticationSuccess = 3
    CounterReturnCode_AuthenticationFailure = 4
    CounterReturnCode_FundComfirmSuccess = 5
    CounterReturnCode_FundComfirmFailure = 6
    CounterReturnCode_LoginSuccess = 7
    CounterReturnCode_LoginFailure = 8
    CounterReturnCode_LogoutSuccess = 9
    CounterReturnCode_LogoutFailure = 10


class PriceModelType(Enum):
    """Price model types"""
    PriceModelType_Unknown = 0
    PriceModelType_BS = 1
    PriceModelType_Black76 = 2
    PriceModelType_Trinomial = 3
    PriceModelType_BinomialTree = 4
    PriceModelType_BAW = 5


class OperationType(Enum):
    """Operation types"""
    OperationType_Unknown = 0
    OperationType_Add = 1
    OperationType_Remove = 2
    OperationType_Modify = 3
    OperationType_Query = 4
    OperationType_Check = 5
    OperationType_Start = 6
    OperationType_Stop = 7


class SpreadTemplateType(Enum):
    """Spread template types"""
    SpreadTemplateType_Unknown = 0
    SpreadTemplateType_Fixed = 1
    SpreadTemplateType_Max = 2


class BaseDirectionType(Enum):
    """Base direction types"""
    BaseDirectionType_BaseBid = 0
    BaseDirectionType_BaseAsk = 1
    BaseDirectionType_BaseMid = 2


class QuotingStrategyOperatetype(Enum):
    """Quoting strategy operation types"""
    QuotingStrategyOperatetype_Unknown = 0
    QuotingStrategyOperatetype_Start = 1
    QuotingStrategyOperatetype_Stop = 2
    QuotingStrategyOperatetype_Modify = 3
    QuotingStrategyOperatetype_Delete = 4
    QuotingStrategyOperatetype_Qry = 5


class QuotingStrategyStatus(Enum):
    """Quoting strategy statuses"""
    QuotingStrategyStatus_Unknown = 0
    QuotingStrategyStatus_Running = 1
    QuotingStrategyStatus_Stopped = 2


class CounterStatus(Enum):
    """Counter statuses"""
    CounterStatus_Unknown = 0
    CounterStatus_Init = 1
    CounterStatus_Login = 2
    CounterStatus_InstrumentInfo_Data_Ready = 3
    CounterStatus_ProductInfo_Data_Ready = 4
    CounterStatus_PositionInfo_Data_Ready = 5
    CounterStatus_AllReady = 6


class OrderSource(Enum):
    """Order sources"""
    OrderSource_Unknown = 0
    OrderSource_Market = 1
    OrderSource_Market_Hedge = 2
    OrderSource_Manual = 3
    OrderSource_OutSide = 4
    OrderSource_Normal = 5
    OrderSource_HandBack = 6
    OrderSource_PCP = 7
    OrderSource_StopProfit = 8
    OrderSource_StopProfit2 = 9
    OrderSource_StopLoss = 10


class HedgePositionLimitType(Enum):
    """Hedge position limit types"""
    HedgePositionLimitType_Unknown = 0  # Note: original had "Unknow" typo
    HedgePositionLimitType_Today = 1
    HedgePositionLimitType_Yesterday = 2
    HedgePositionLimitType_Net = 3
    HedgePositionLimitType_Delta = 4


class HedgeStatus(Enum):
    """Hedge statuses"""
    HedgeStatus_Unknown = 0
    HedgeStatus_On = 1
    HedgeStatus_Off = 2


class HedgeConfigOperateType(Enum):
    """Hedge configuration operation types"""
    HedgeConfigOperateType_Unknown = 0
    HedgeConfigOperateType_Add = 1
    HedgeConfigOperateType_Del = 2
    HedgeConfigOperateType_Mod = 3
    HedgeConfigOperateType_Qry = 4


class OrderPurposeType(Enum):
    """Order purpose types"""
    OrderPurposeType_Null = 0
    OrderPurposeOpen = 1
    OrderPurposeOffset = 2
    OrderPurposeStopLoss = 3
    OrderPurposeStopProfit = 4
    OrderPurposeClear = 5


class OrderPriceType(Enum):
    """Order price types"""
    OrderPriceTypeNone = 0
    OrderPriceTypeLimited = 1
    OrderPriceTypeMid = 2
    OrderPriceTypeLast = 3
    OrderPriceTypeRival = 4
    OrderPriceTypeBest = 5
    OrderPriceTypeLimitedNoCheck = 6


class OrderVolumeType(Enum):
    """Order volume types"""
    OrderVolumeTypeNormal = 0
    OrderVolumeTypeOffsetNetPosi = 1
    OrderVolumeTypeOpenNetPosi = 2
    OrderVolumeTypeClearPosi = 3


class QuoteModeType(Enum):
    """Quote mode types"""
    QuoteModeType_Quote = 0
    QuoteModeType_Normal = 1


class TradeUserType(Enum):
    """Trade user types"""
    TradeUserType_UnKnow = 0
    TradeUserType_Trader = 1
    TradeUserType_RiskMamager = 2  # Note: original had "RiskMamager" typo
    TradeUserType_Sync = 3
    TradeUserType_SuperAdmin = 4


class WebPermission(Enum):
    """Web permissions"""
    WebPermission_Forbidden = 0
    WebPermission_ForUnLogin = 1
    WebPermission_ForAdmin = 2
    WebPermission_ForTrade = 3
    WebPermission_ForAnyLogin = 4
    WebPermission_ForOwner = 5
    WebPermission_ForPublic = 6
    WebPermission_ForSync = 7
    WebPermission_ForRiskMamager = 8  # Note: original had "RiskMamager" typo


class TradingSectionStatus(Enum):
    """Trading section statuses"""
    TradingSectionStatus_NoTraing = 0
    TradingSectionStatus_Trading = 1
    TradingSectionStatus_OpenAction = 2
    TradingSectionStatus_AfterTrading = 3
    TradingSectionStatus_BeforeTrading = 4


