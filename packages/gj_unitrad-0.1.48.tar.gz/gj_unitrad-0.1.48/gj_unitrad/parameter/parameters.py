"""
Unitrade Trading Platform Python Classes
Corresponding to C++ structures defined in ParameterBinding.cpp
"""

from typing import Dict, List, Optional, Union
from dataclasses import dataclass
from enum import Enum


# 假设这些枚举已经在其他地方定义
from ..enum import (
    InstrumentType, SideType, OffsetType, HedgeFlag,
    PriceType, VolumeCondition, TimeCondition, OrderStatus, 
    DirectionType, OrderActionFlag, OrderSource,
)


@dataclass
class Instrument:
    """Instrument information"""
    instrument_id: str = ""    
    exchange_id: str = ""      
    product_id: str = ""
    instrument_name: str = ""
    product_id: str = ""
    product_type: str = ""
    create_date: str = ""
    open_date: str = ""
    expire_date: str = ""
    basis_price: float = 0.0
    volume_multiple: float = 0.0
    underlying_instrument_id: str = ""
    underlying_multiple: float = 0.0
    option_type: str = ""
    strike_price: float = 0.0
    price_tick: float = 0.0


@dataclass
class Quote:
    """Market quote data"""
    sourceId: str = ""
    tradingDay: str = ""
    dataTime: int = 0
    updateTime: int = 0
    instrumentId: str = ""
    exchangeId: str = ""
    instrumentType: InstrumentType = InstrumentType.InstrumentType_Unknown
    preClosePrice: float = 0.0
    preSettlementPrice: float = 0.0
    lastPrice: float = 0.0
    volume: int = 0
    turnover: float = 0.0
    preOpenInterest: float = 0.0
    openInterest: float = 0.0
    openPrice: float = 0.0
    highPrice: float = 0.0
    lowPrice: float = 0.0
    upperLimitPrice: float = 0.0
    lowerLimitPrice: float = 0.0
    closePrice: float = 0.0
    settlementPrice: float = 0.0
    bidPrice1: float = 0.0
    bidPrice2: float = 0.0
    bidPrice3: float = 0.0
    bidPrice4: float = 0.0
    bidPrice5: float = 0.0
    bidVolume1: int = 0
    bidVolume2: int = 0
    bidVolume3: int = 0
    bidVolume4: int = 0
    bidVolume5: int = 0
    askPrice1: float = 0.0
    askPrice2: float = 0.0
    askPrice3: float = 0.0
    askPrice4: float = 0.0
    askPrice5: float = 0.0
    askVolume1: int = 0
    askVolume2: int = 0
    askVolume3: int = 0
    askVolume4: int = 0
    askVolume5: int = 0
    sessionId: int = 0
    frontId: int = 0


@dataclass
class Bar:
    """Bar data structure"""
    tradeTime: str = ""
    instrumentId: str = ""
    uniqueInstrumentId: str = ""
    exchangeId: str = ""
    tradingDay: str = ""
    upperLimitPrice: float = 0.0
    lowerLimitPrice: float = 0.0
    tradeTimeStamp: int = 0
    openPrice: float = 0.0
    highestPrice: float = 0.0
    lowestPrice: float = 0.0
    closePrice: float = 0.0
    volume: int = 0
    totalVolume: int = 0
    turnover: float = 0.0
    totalTurnover: float = 0.0
    openInterest: float = 0.0
    productKind: str = ""


@dataclass
class OrderInput:
    """Order input information"""
    insertTime: int = 0
    orderId: int = 0
    parentId: int = 0
    instrumentId: str = ""
    exchangeId: str = ""
    sourceId: str = ""
    accountId: str = ""
    instrumentType: InstrumentType = InstrumentType.InstrumentType_Unknown
    limitPrice: float = 0.0
    frozenPrice: float = 0.0
    volume: int = 0
    side: SideType = SideType.SideType_Unknown
    offset: OffsetType = OffsetType.OffsetType_Unknown
    hedgeFlag: HedgeFlag = HedgeFlag.HedgeFlag_Unknown
    priceType: PriceType = PriceType.PriceTypeUnknown
    volumeCondition: VolumeCondition = VolumeCondition.VolumeCondition_Unknown
    timeCondition: TimeCondition = TimeCondition.TimeCondition_Unknown
    orderSource: OrderSource = OrderSource.OrderSource_Unknown
    strategyId: int = 0


@dataclass
class OrderAction:
    """Order action information"""
    instrumentId: str = ""
    orderId: int = 0
    orderActionId: int = 0
    actionFlag: OrderActionFlag = OrderActionFlag.OrderActionFlag_Unknown
    price: float = 0.0
    volume: int = 0

@dataclass
class Order:
    """Order information"""
    orderId: int = 0
    orderSysId: str = ""
    parentId: int = 0
    insertTime: int = 0
    updateTime: int = 0
    tradingDay: str = ""
    instrumentId: str = ""
    exchangeId: str = ""
    sourceId: str = ""
    accountId: str = ""
    clientId: str = ""
    limitPrice: float = 0.0
    frozenPrice: float = 0.0
    volume: int = 0
    volumeTrade: int = 0
    volumeLeft: int = 0
    tax: float = 0.0
    commission: float = 0.0
    status: OrderStatus = OrderStatus.OrderStatus_Unknown
    errorId: int = 0
    errorMsg: str = ""
    side: SideType = SideType.SideType_Unknown
    offset: OffsetType = OffsetType.OffsetType_Unknown
    hedgeFlag: HedgeFlag = HedgeFlag.HedgeFlag_Unknown
    priceType: PriceType = PriceType.PriceTypeUnknown
    volumeCondition: VolumeCondition = VolumeCondition.VolumeCondition_Unknown
    timeCondition: TimeCondition = TimeCondition.TimeCondition_Unknown
    exInsertTime: str = ""
    isOutOrder: bool = False
    firstTradeSequenceId: int = 0
    tradeSequenceId: int = 0
    orderSource: OrderSource = OrderSource.OrderSource_Unknown
    strategyId: int = 0
    exUpdateTime: str = ""
    exCancelTime: str = ""
    quoteId: str = ""
    sessionId: int = 0
    frontId: int = 0
    orderRef: str = ""
    traderId: str = ""
    orderLocalId: str = ""


@dataclass
class Trade:
    """Trade information"""
    isOpponentTrade: bool = False
    tradeId: int = 0
    orderId: int = 0
    parentOrderId: int = 0
    insertTime: int = 0
    updateTime: int = 0
    exchangeTradeTime: int = 0
    tradingDay: str = ""
    tradingTime: str = ""
    instrumentId: str = ""
    exchangeId: str = ""
    sourceId: str = ""
    accountId: str = ""
    clientId: str = ""
    side: SideType = SideType.SideType_Unknown
    offset: OffsetType = OffsetType.OffsetType_Unknown
    hedgeFlag: HedgeFlag = HedgeFlag.HedgeFlag_Unknown
    price: float = 0.0
    volume: int = 0
    tax: float = 0.0
    commission: float = 0.0
    exInsertTime: str = ""
    isOutOrder: bool = False
    tradeSequenceId: int = 0
    orderSource: OrderSource = OrderSource.OrderSource_Unknown
    strategyId: int = 0
    orderSysId: str = ""
    tradeID: str = ""


@dataclass
class InstrumentPosition:
    """Instrument position information"""
    tradingDay: str = ""
    instrumentId: str = ""
    exchangeId: str = ""
    accountId: str = ""
    instrumentType: InstrumentType = InstrumentType.InstrumentType_Unknown
    hedgeFlag: HedgeFlag = HedgeFlag.HedgeFlag_Unknown
    direction: DirectionType = DirectionType.DirectionType_Unknown
    position: int = 0
    todayPosition: int = 0
    yesterdayPosition: int = 0
    yesterdayAvaPosition: int = 0
    frozenYdPosition: int = 0
    frozenTdPosition: int = 0
    longFrozen: int = 0
    shortFrozen: int = 0
    openCost: float = 0.0
    avgOpenPrice: float = 0.0
    positionCost: float = 0.0
    avgPositionPrice: float = 0.0

