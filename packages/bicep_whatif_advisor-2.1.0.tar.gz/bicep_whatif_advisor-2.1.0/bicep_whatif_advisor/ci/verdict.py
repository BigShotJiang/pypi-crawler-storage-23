"""Risk level constants for CI mode deployment gates."""

# Risk level ordering (higher index = higher risk)
RISK_LEVELS = ["low", "medium", "high"]
