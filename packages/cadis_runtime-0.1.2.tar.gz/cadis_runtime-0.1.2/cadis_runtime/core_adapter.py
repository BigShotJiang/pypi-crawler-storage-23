from __future__ import annotations

from cadis_core import AdminEngineCore

CORE_BACKEND = "cadis_core"

__all__ = ["AdminEngineCore", "CORE_BACKEND"]
