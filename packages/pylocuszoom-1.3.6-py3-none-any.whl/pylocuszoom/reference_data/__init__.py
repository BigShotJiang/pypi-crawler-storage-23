"""Reference data for pyLocusZoom.

Contains species-specific reference data downloaders and loaders.
"""
