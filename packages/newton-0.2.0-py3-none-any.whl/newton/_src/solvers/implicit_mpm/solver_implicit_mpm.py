# SPDX-FileCopyrightText: Copyright (c) 2025 The Newton Developers
# SPDX-License-Identifier: Apache-2.0
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Implicit MPM solver."""

from dataclasses import dataclass
from typing import Any

import numpy as np
import warp as wp
import warp.fem as fem
import warp.sparse as sp

import newton

from ...core.types import override
from ..solver import SolverBase
from .implicit_mpm_model import ImplicitMPMModel
from .rasterized_collisions import (
    allot_collider_mass,
    build_rigidity_operator,
    interpolate_collider_normals,
    project_outside_collider,
    rasterize_collider,
)
from .render_grains import sample_render_grains, update_render_grains
from .solve_rheology import YieldParamVec, solve_rheology

__all__ = ["SolverImplicitMPM"]


MIN_PRINCIPAL_STRAIN = wp.constant(0.01)
"""Minimum elastic strain for the elastic model (singular value of the elastic deformation gradient)"""

MAX_PRINCIPAL_STRAIN = wp.constant(4.0)
"""Maximum elastic strain for the elastic model (singular value of the elastic deformation gradient)"""

MIN_HARDENING_JP = wp.constant(0.01)
"""Minimum hardening for the elastic model (determinant of the plastic deformation gradient)"""

MAX_HARDENING_JP = wp.constant(4.0)
"""Maximum hardening for the elastic model (determinant of the plastic deformation gradient)"""

MIN_JP_DELTA = wp.constant(0.1)
"""Minimum delta for the plastic deformation gradient"""

MAX_JP_DELTA = wp.constant(10.0)
"""Maximum delta for the plastic deformation gradient"""

_INFINITY = wp.constant(1.0e12)
"""Value above which quantities are considered infinite"""

_EPSILON = wp.constant(1.0 / _INFINITY)
"""Value below which quantities are considered zero"""

vec6 = wp.types.vector(length=6, dtype=wp.float32)
mat66 = wp.types.matrix(shape=(6, 6), dtype=wp.float32)
mat63 = wp.types.matrix(shape=(6, 3), dtype=wp.float32)
mat36 = wp.types.matrix(shape=(3, 6), dtype=wp.float32)


@fem.integrand
def integrate_fraction(s: fem.Sample, phi: fem.Field, domain: fem.Domain, inv_cell_volume: float):
    return phi(s) * inv_cell_volume


@fem.integrand
def integrate_collider_fraction(
    s: fem.Sample,
    domain: fem.Domain,
    phi: fem.Field,
    sdf: fem.Field,
    inv_cell_volume: float,
):
    return phi(s) * wp.where(sdf(s) <= 0.0, inv_cell_volume, 0.0)


@fem.integrand
def integrate_collider_fraction_apic(
    s: fem.Sample,
    domain: fem.Domain,
    phi: fem.Field,
    sdf: fem.Field,
    sdf_gradient: fem.Field,
    inv_cell_volume: float,
):
    # APIC collider fraction prediction
    node_count = fem.node_count(sdf, s)
    pos = domain(s)
    min_sdf = float(_INFINITY)
    for k in range(node_count):
        s_node = fem.at_node(sdf, s, k)
        sdf_value = sdf(s_node, k)
        sdf_gradient_value = sdf_gradient(s_node, k)

        node_offset = pos - domain(s_node)
        min_sdf = wp.min(min_sdf, sdf_value + wp.dot(sdf_gradient_value, node_offset))

    return phi(s) * wp.where(min_sdf <= 0.0, inv_cell_volume, 0.0)


@fem.integrand
def integrate_mass(
    s: fem.Sample,
    phi: fem.Field,
    domain: fem.Domain,
    inv_cell_volume: float,
    particle_density: wp.array(dtype=float),
    particle_flags: wp.array(dtype=wp.int32),
):
    density = wp.where(
        particle_flags[s.qp_index] & newton.ParticleFlags.ACTIVE, particle_density[s.qp_index], _INFINITY
    )
    return phi(s) * density * inv_cell_volume


@fem.integrand
def integrate_velocity(
    s: fem.Sample,
    domain: fem.Domain,
    u: fem.Field,
    velocities: wp.array(dtype=wp.vec3),
    dt: float,
    gravity: wp.array(dtype=wp.vec3),
    particle_world: wp.array(dtype=wp.int32),
    inv_cell_volume: float,
    particle_density: wp.array(dtype=float),
    particle_flags: wp.array(dtype=wp.int32),
):
    vel_adv = velocities[s.qp_index]
    world_idx = particle_world[s.qp_index]
    world_g = gravity[wp.max(world_idx, 0)]

    vel_adv = wp.where(
        particle_flags[s.qp_index] & newton.ParticleFlags.ACTIVE,
        particle_density[s.qp_index] * (vel_adv + dt * world_g),
        _INFINITY * vel_adv,
    )
    return wp.dot(u(s), vel_adv) * inv_cell_volume


@fem.integrand
def integrate_velocity_apic(
    s: fem.Sample,
    domain: fem.Domain,
    u: fem.Field,
    velocity_gradients: wp.array(dtype=wp.mat33),
    inv_cell_volume: float,
    particle_density: wp.array(dtype=float),
    particle_flags: wp.array(dtype=wp.int32),
):
    # APIC velocity prediction
    node_offset = domain(fem.at_node(u, s)) - domain(s)
    vel_apic = velocity_gradients[s.qp_index] * node_offset

    vel_adv = (
        wp.where(particle_flags[s.qp_index] & newton.ParticleFlags.ACTIVE, particle_density[s.qp_index], _INFINITY)
        * vel_apic
    )
    return wp.dot(u(s), vel_adv) * inv_cell_volume


@wp.kernel
def free_velocity(
    velocity_int: wp.array(dtype=wp.vec3),
    node_particle_mass: wp.array(dtype=float),
    drag: float,
    inv_mass_matrix: wp.array(dtype=float),
    velocity_avg: wp.array(dtype=wp.vec3),
):
    i = wp.tid()

    pmass = node_particle_mass[i]
    inv_particle_mass = 1.0 / (pmass + drag)

    vel = velocity_int[i] * inv_particle_mass
    inv_mass_matrix[i] = inv_particle_mass

    velocity_avg[i] = vel


@wp.func
def hardening_law(Jp: float, hardening: float):
    return wp.exp(hardening * (1.0 - wp.clamp(Jp, MIN_HARDENING_JP, MAX_HARDENING_JP)))


@wp.func
def get_elastic_parameters(
    i: int,
    young_modulus: wp.array(dtype=float),
    poisson_ratio: wp.array(dtype=float),
    damping: wp.array(dtype=float),
    hardening: wp.array(dtype=float),
    particle_Jp: wp.array(dtype=float),
):
    E = young_modulus[i] * hardening_law(particle_Jp[i], hardening[i])
    nu = poisson_ratio[i]
    d = damping[i]

    return wp.vec3(E, nu, d)


@wp.func
def extract_elastic_parameters(
    params_vec: wp.vec3,
):
    compliance = 1.0 / params_vec[0]
    poisson = params_vec[1]
    damping = params_vec[2]
    return compliance, poisson, damping


@wp.func
def get_yield_parameters(
    i: int,
    hardening: wp.array(dtype=float),
    friction: wp.array(dtype=float),
    yield_pressure: wp.array(dtype=float),
    tensile_yield_ratio: wp.array(dtype=float),
    yield_stress: wp.array(dtype=float),
    particle_Jp: wp.array(dtype=float),
):
    h = hardening_law(particle_Jp[i], hardening[i])
    mu = friction[i]

    return YieldParamVec.from_values(
        mu,
        yield_pressure[i] * h,
        tensile_yield_ratio[i] / h,  # keep tensile yield stress constant
        yield_stress[i] * h,
    )


@fem.integrand
def integrate_elastic_parameters(
    s: fem.Sample,
    domain: fem.Domain,
    u: fem.Field,
    inv_cell_volume: float,
    young_modulus: wp.array(dtype=float),
    poisson_ratio: wp.array(dtype=float),
    damping: wp.array(dtype=float),
    hardening: wp.array(dtype=float),
    particle_Jp: wp.array(dtype=float),
):
    i = s.qp_index
    params_vec = get_elastic_parameters(i, young_modulus, poisson_ratio, damping, hardening, particle_Jp)
    return wp.dot(u(s), params_vec) * inv_cell_volume


@fem.integrand
def integrate_yield_parameters(
    s: fem.Sample,
    u: fem.Field,
    inv_cell_volume: float,
    hardening: wp.array(dtype=float),
    friction: wp.array(dtype=float),
    yield_pressure: wp.array(dtype=float),
    tensile_yield_ratio: wp.array(dtype=float),
    yield_stress: wp.array(dtype=float),
    particle_Jp: wp.array(dtype=float),
):
    i = s.qp_index
    params_vec = get_yield_parameters(
        i, hardening, friction, yield_pressure, tensile_yield_ratio, yield_stress, particle_Jp
    )
    return wp.dot(u(s), params_vec) * inv_cell_volume


@wp.kernel
def average_yield_parameters(
    yield_parameters_int: wp.array(dtype=YieldParamVec),
    particle_volume: wp.array(dtype=float),
    yield_parameters_avg: wp.array(dtype=YieldParamVec),
):
    i = wp.tid()
    pvol = particle_volume[i]
    yield_parameters_avg[i] = wp.max(YieldParamVec(0.0), yield_parameters_int[i] / wp.max(pvol, _EPSILON))


@wp.kernel
def average_elastic_parameters(
    elastic_parameters_int: wp.array(dtype=wp.vec3),
    particle_volume: wp.array(dtype=float),
    elastic_parameters_avg: wp.array(dtype=wp.vec3),
):
    i = wp.tid()
    pvol = particle_volume[i]
    elastic_parameters_avg[i] = elastic_parameters_int[i] / wp.max(pvol, _EPSILON)


@wp.kernel
def average_elastic_strain_delta(
    elastic_strain_delta_int: wp.array(dtype=vec6),
    particle_volume: wp.array(dtype=float),
    elastic_strain_delta_avg: wp.array(dtype=vec6),
):
    i = wp.tid()
    pvol = particle_volume[i]

    # The 2 factor is due to the SymTensorMapping being othonormal with (tau:sig)/2
    elastic_strain_delta_avg[i] = elastic_strain_delta_int[i] / wp.max(2.0 * pvol, _EPSILON)


@fem.integrand
def advect_particles(
    s: fem.Sample,
    grid_vel: fem.Field,
    dt: float,
    max_vel: float,
    particle_flags: wp.array(dtype=wp.int32),
    pos: wp.array(dtype=wp.vec3),
    pos_prev: wp.array(dtype=wp.vec3),
    vel: wp.array(dtype=wp.vec3),
    vel_grad: wp.array(dtype=wp.mat33),
):
    if ~particle_flags[s.qp_index] & newton.ParticleFlags.ACTIVE:
        pos[s.qp_index] = pos_prev[s.qp_index]
        return

    p_vel = grid_vel(s)
    vel_n_sq = wp.length_sq(p_vel)

    p_vel_cfl = wp.where(vel_n_sq > max_vel * max_vel, p_vel * max_vel / wp.sqrt(vel_n_sq), p_vel)

    p_vel_grad = fem.grad(grid_vel, s)

    pos_adv = pos_prev[s.qp_index] + dt * p_vel_cfl

    pos[s.qp_index] = pos_adv
    vel[s.qp_index] = p_vel_cfl
    vel_grad[s.qp_index] = p_vel_grad


@fem.integrand
def update_particle_strains(
    s: fem.Sample,
    grid_vel: fem.Field,
    plastic_strain_delta: fem.Field,
    elastic_strain_delta: fem.Field,
    dt: float,
    particle_flags: wp.array(dtype=wp.int32),
    young_modulus: wp.array(dtype=float),
    poisson_ratio: wp.array(dtype=float),
    damping: wp.array(dtype=float),
    hardening: wp.array(dtype=float),
    friction: wp.array(dtype=float),
    yield_pressure: wp.array(dtype=float),
    tensile_yield_ratio: wp.array(dtype=float),
    yield_stress: wp.array(dtype=float),
    elastic_strain_prev: wp.array(dtype=wp.mat33),
    particle_Jp_prev: wp.array(dtype=float),
    elastic_strain: wp.array(dtype=wp.mat33),
    particle_Jp: wp.array(dtype=float),
):
    if ~particle_flags[s.qp_index] & newton.ParticleFlags.ACTIVE:
        return

    # plastic strain
    p_strain_delta = plastic_strain_delta(s)
    delta_Jp = wp.determinant(p_strain_delta + wp.identity(n=3, dtype=float))
    particle_Jp[s.qp_index] = particle_Jp_prev[s.qp_index] * wp.clamp(delta_Jp, MIN_JP_DELTA, MAX_JP_DELTA)

    # elastic strain
    prev_strain = elastic_strain_prev[s.qp_index]
    strain_delta = elastic_strain_delta(s)  # + skew * dt
    strain_new = prev_strain + strain_delta @ prev_strain

    elastic_parameters_vec = get_elastic_parameters(
        s.qp_index, young_modulus, poisson_ratio, damping, hardening, particle_Jp
    )
    compliance, poisson, _damping = extract_elastic_parameters(elastic_parameters_vec)

    yield_parameters_vec = get_yield_parameters(
        s.qp_index, hardening, friction, yield_pressure, tensile_yield_ratio, yield_stress, particle_Jp
    )

    strain_proj = project_particle_strain(
        s.qp_index, strain_new, prev_strain, compliance, poisson, yield_parameters_vec
    )

    # rotation
    rot = fem.curl(grid_vel, s) * dt
    q = wp.quat_from_axis_angle(wp.normalize(rot), wp.length(rot))
    R = wp.quat_to_matrix(q)

    elastic_strain[s.qp_index] = R @ strain_proj


@wp.func
def project_particle_strain(
    i: int,
    F: wp.mat33,
    F_prev: wp.mat33,
    compliance: float,
    poisson: float,
    yield_parameters_vec: YieldParamVec,
):
    if compliance <= _EPSILON:
        return wp.identity(n=3, dtype=float)

    _U, xi, _V = wp.svd3(F)

    if wp.min(xi) < MIN_PRINCIPAL_STRAIN or wp.max(xi) > MAX_PRINCIPAL_STRAIN:
        return F_prev  # non-recoverable, discard update

    return F


@wp.kernel
def update_particle_frames(
    dt: float,
    min_stretch: float,
    max_stretch: float,
    vel_grad: wp.array(dtype=wp.mat33),
    transform_prev: wp.array(dtype=wp.mat33),
    transform: wp.array(dtype=wp.mat33),
):
    i = wp.tid()

    p_vel_grad = vel_grad[i]

    # transform, for grain-level rendering
    F_prev = transform_prev[i]
    # dX1/dx = dX1/dX0 dX0/dx
    F = F_prev + dt * p_vel_grad @ F_prev

    # clamp eigenvalues of F
    if min_stretch >= 0.0 and max_stretch >= 0.0:
        U = wp.mat33()
        S = wp.vec3()
        V = wp.mat33()
        wp.svd3(F, U, S, V)
        S = wp.max(wp.min(S, wp.vec3(max_stretch)), wp.vec3(min_stretch))
        F = U @ wp.diag(S) @ wp.transpose(V)

    transform[i] = F


@fem.integrand
def strain_delta_form(
    s: fem.Sample,
    u: fem.Field,
    tau: fem.Field,
    dt: float,
    domain: fem.Domain,
    inv_cell_volume: float,
):
    return wp.ddot(fem.grad(u, s), tau(s)) * (dt * inv_cell_volume)


@wp.kernel
def compute_unilateral_strain_offset(
    max_fraction: float,
    particle_volume: wp.array(dtype=float),
    collider_volume: wp.array(dtype=float),
    node_volume: wp.array(dtype=float),
    unilateral_strain_offset: wp.array(dtype=float),
):
    i = wp.tid()

    spherical_part = max_fraction * (node_volume[i] - collider_volume[i]) - particle_volume[i]
    spherical_part = wp.max(spherical_part, 0.0)

    strain_offset = spherical_part / 3.0 * wp.identity(n=3, dtype=float)

    offset_vec = fem.SymmetricTensorMapper.value_to_dof_3d(strain_offset)
    unilateral_strain_offset[i] = offset_vec[0]


@wp.func
def stress_strain_relationship(sig: wp.mat33, compliance: float, poisson: float):
    return (sig * (1.0 + poisson) - poisson * (wp.trace(sig) * wp.identity(n=3, dtype=float))) * compliance


@fem.integrand
def strain_rhs(
    s: fem.Sample,
    tau: fem.Field,
    elastic_parameters: fem.Field,
    elastic_strains: wp.array(dtype=wp.mat33),
    inv_cell_volume: float,
    dt: float,
):
    F_prev = elastic_strains[s.qp_index]

    U_prev, xi_prev, _V_prev = wp.svd3(F_prev)

    _compliance, _poisson, damping = extract_elastic_parameters(elastic_parameters(s))

    alpha = 1.0 / (1.0 + damping * dt)

    RSinvRt_prev = U_prev @ wp.diag(1.0 / xi_prev) @ wp.transpose(U_prev)
    Id = wp.identity(n=3, dtype=float)

    strain = -alpha * wp.ddot(tau(s), RSinvRt_prev - Id)

    return strain * inv_cell_volume


@fem.integrand
def compliance_form(
    s: fem.Sample,
    domain: fem.Domain,
    tau: fem.Field,
    sig: fem.Field,
    elastic_parameters: fem.Field,
    elastic_strains: wp.array(dtype=wp.mat33),
    inv_cell_volume: float,
    dt: float,
):
    F = elastic_strains[s.qp_index]

    compliance, poisson, damping = extract_elastic_parameters(elastic_parameters(s))

    U, xi, V = wp.svd3(F)

    Rt = V @ wp.transpose(U)
    FinvT = U @ wp.diag(1.0 / xi) @ wp.transpose(V)
    return (
        wp.ddot(
            Rt @ tau(s) @ FinvT,
            stress_strain_relationship(Rt @ sig(s) @ FinvT, compliance / (1.0 + damping * dt), poisson),
        )
        * inv_cell_volume
    )


@fem.integrand
def collision_weight_field(
    s: fem.Sample,
    normal: fem.Field,
    trial: fem.Field,
):
    n = normal(s)
    if wp.length_sq(n) == 0.0:
        # invalid normal, contact is disabled
        return 0.0

    return trial(s)


def _make_grid_basis_space(grid: fem.Geometry, basis_str: str, family: fem.Polynomial | None = None):
    assert len(basis_str) >= 2

    degree = int(basis_str[1])

    if basis_str[0] == "Q":
        element_basis = fem.ElementBasis.LAGRANGE
    elif basis_str[0] == "S":
        element_basis = fem.ElementBasis.SERENDIPITY
    elif basis_str[0] == "P" and (degree == 0 or basis_str[-1] == "d"):
        element_basis = fem.ElementBasis.NONCONFORMING_POLYNOMIAL
    else:
        raise ValueError(
            f"Unsupported basis: {basis_str}. Expected format: Q<degree>[d], S<degree>, or P<degree>[d] for tri-polynomial, serendipity, or non-conforming polynomial respectively."
        )

    return fem.make_polynomial_basis_space(grid, degree=degree, element_basis=element_basis, family=family)


def _make_pic_basis_space(pic: fem.PicQuadrature, basis_str: str):
    try:
        max_points_per_cell = int(basis_str[3:])
    except ValueError:
        max_points_per_cell = -1

    return fem.PointBasisSpace(pic, max_nodes_per_element=max_points_per_cell)


class ImplicitMPMScratchpad:
    """Per-step spaces, fields, and temporaries for the implicit MPM solver."""

    def __init__(self):
        self.grid = None

        self.velocity_test = None
        self.velocity_trial = None
        self.fraction_test = None

        self.sym_strain_test = None
        self.sym_strain_trial = None
        self.divergence_test = None
        self.fraction_field = None
        self.elastic_parameters_field = None

        self.plastic_strain_delta_field = None
        self.elastic_strain_delta_field = None
        self.strain_yield_parameters_field = None
        self.strain_yield_parameters_test = None

        self.strain_matrix = sp.bsr_zeros(0, 0, mat63)
        self.transposed_strain_matrix = sp.bsr_zeros(0, 0, mat36)

        self.compliance_matrix = sp.bsr_zeros(0, 0, mat66)

        self.color_offsets = None
        self.color_indices = None
        self.color_nodes_per_element = 1

        self.inv_mass_matrix = None

        self.collider_fraction_test = None

        self.collider_normal_field = None
        self.collider_distance_field = None

        self.collider_velocity = None
        self.collider_friction = None
        self.collider_adhesion = None
        self.collider_inv_mass_matrix = None

        self.collider_matrix = sp.bsr_zeros(0, 0, block_type=float)
        self.transposed_collider_matrix = sp.bsr_zeros(0, 0, block_type=float)

        self.strain_node_particle_volume = None
        self.strain_node_volume = None
        self.strain_node_collider_volume = None

        self.int_symmetric_strain = None

        self.collider_total_volumes = None
        self.collider_node_volume = None

    def rebuild_function_spaces(
        self,
        pic: fem.PicQuadrature,
        strain_basis_str: str,
        collider_basis_str: str,
        max_cell_count: int,
        temporary_store: fem.TemporaryStore,
    ):
        """Define velocity and strain function spaces over the given geometry."""

        self.domain = pic.domain

        use_pic_collider_basis = collider_basis_str[:3] == "pic"

        if self.domain.geometry is not self.grid:
            self.grid = self.domain.geometry

            # Define function spaces: linear (Q1) for velocity and volume fraction,
            # zero or first order for pressure
            self._velocity_basis = fem.make_polynomial_basis_space(self.grid, degree=1)

            self._strain_basis = _make_grid_basis_space(self.grid, strain_basis_str)

            if not use_pic_collider_basis:
                self._collision_basis = _make_grid_basis_space(
                    self.grid, collider_basis_str, family=fem.Polynomial.EQUISPACED_CLOSED
                )

        # Point-based basis space needs to be rebuilt even when the geo does not change
        if use_pic_collider_basis:
            self._collision_basis = _make_pic_basis_space(pic, collider_basis_str)

        self._create_velocity_function_space(temporary_store, max_cell_count)
        self._create_collider_function_space(temporary_store, max_cell_count)
        self._create_strain_function_space(temporary_store, max_cell_count)

    def _create_velocity_function_space(self, temporary_store: fem.TemporaryStore, max_cell_count: int = -1):
        """Create velocity and fraction spaces and their partition/restriction."""
        domain = self.domain

        velocity_space = fem.make_collocated_function_space(self._velocity_basis, dtype=wp.vec3)

        # overly conservative
        max_vel_node_count = (
            velocity_space.topology.MAX_NODES_PER_ELEMENT * max_cell_count if max_cell_count >= 0 else -1
        )

        vel_space_partition = fem.make_space_partition(
            space_topology=velocity_space.topology,
            geometry_partition=domain.geometry_partition,
            with_halo=False,
            max_node_count=max_vel_node_count,
            temporary_store=temporary_store,
        )
        vel_space_restriction = fem.make_space_restriction(
            space_partition=vel_space_partition, domain=domain, temporary_store=temporary_store
        )

        self._velocity_space = velocity_space
        self._vel_space_restriction = vel_space_restriction

    def _create_collider_function_space(self, temporary_store: fem.TemporaryStore, max_cell_count: int = -1):
        """Create velocity and fraction spaces and their partition/restriction."""

        if self._velocity_basis == self._collision_basis:
            self._collision_space = self._velocity_space
            self._collision_space_restriction = self._vel_space_restriction
            return

        domain = self.domain

        collision_space = fem.make_collocated_function_space(self._collision_basis, dtype=wp.vec3)

        if isinstance(collision_space.basis, fem.PointBasisSpace):
            max_collision_node_count = collision_space.node_count()
        else:
            # overly conservative
            max_collision_node_count = (
                collision_space.topology.MAX_NODES_PER_ELEMENT * domain.element_count() if max_cell_count >= 0 else -1
            )

        collision_space_partition = fem.make_space_partition(
            space_topology=collision_space.topology,
            geometry_partition=domain.geometry_partition,
            with_halo=False,
            max_node_count=max_collision_node_count,
            temporary_store=temporary_store,
        )
        collision_space_restriction = fem.make_space_restriction(
            space_partition=collision_space_partition, domain=domain, temporary_store=temporary_store
        )

        self._collision_space = collision_space
        self._collision_space_restriction = collision_space_restriction

    def _create_strain_function_space(self, temporary_store: fem.TemporaryStore, max_cell_count: int = -1):
        """Create symmetric strain space (P0 or Q1) and its partition/restriction."""
        domain = self.domain

        sym_strain_space = fem.make_collocated_function_space(
            self._strain_basis,
            dof_mapper=fem.SymmetricTensorMapper(dtype=wp.mat33, mapping=fem.SymmetricTensorMapper.Mapping.DB16),
        )

        max_strain_node_count = (
            sym_strain_space.topology.MAX_NODES_PER_ELEMENT * max_cell_count if max_cell_count >= 0 else -1
        )

        strain_space_partition = fem.make_space_partition(
            space_topology=sym_strain_space.topology,
            geometry_partition=domain.geometry_partition,
            with_halo=False,
            max_node_count=max_strain_node_count,
            temporary_store=temporary_store,
        )

        strain_space_restriction = fem.make_space_restriction(
            space_partition=strain_space_partition, domain=domain, temporary_store=temporary_store
        )

        self._sym_strain_space = sym_strain_space
        self._strain_space_restriction = strain_space_restriction

    def require_velocity_space_fields(self, has_compliant_particles: bool):
        velocity_basis = self._velocity_basis
        velocity_space = self._velocity_space
        vel_space_restriction = self._vel_space_restriction
        domain = vel_space_restriction.domain
        vel_space_partition = vel_space_restriction.space_partition

        if (
            self.velocity_test is not None
            and self.velocity_test.space_restriction.space_partition == vel_space_partition
        ):
            return

        fraction_space = fem.make_collocated_function_space(velocity_basis, dtype=float)

        # test, trial and discrete fields
        if self.velocity_test is None:
            self.velocity_test = fem.make_test(velocity_space, domain=domain, space_restriction=vel_space_restriction)
            self.fraction_test = fem.make_test(fraction_space, space_restriction=vel_space_restriction)

            self.velocity_trial = fem.make_trial(velocity_space, domain=domain, space_partition=vel_space_partition)
            self.fraction_trial = fem.make_trial(fraction_space, domain=domain, space_partition=vel_space_partition)

            self.fraction_field = fem.make_discrete_field(fraction_space, space_partition=vel_space_partition)

            if has_compliant_particles:
                elastic_parameters_space = fem.make_collocated_function_space(velocity_basis, dtype=wp.vec3)
                self.elastic_parameters_field = elastic_parameters_space.make_field(space_partition=vel_space_partition)

        else:
            self.velocity_test.rebind(velocity_space, vel_space_restriction)
            self.fraction_test.rebind(fraction_space, vel_space_restriction)

            self.velocity_trial.rebind(velocity_space, vel_space_partition, domain)
            self.fraction_trial.rebind(fraction_space, vel_space_partition, domain)
            self.fraction_field.rebind(fraction_space, vel_space_partition)

            if has_compliant_particles:
                elastic_parameters_space = fem.make_collocated_function_space(velocity_basis, dtype=wp.vec3)
                self.elastic_parameters_field.rebind(elastic_parameters_space, vel_space_partition)

        self.velocity_field = velocity_space.make_field(space_partition=vel_space_partition)

    def require_collision_space_fields(self):
        collision_basis = self._collision_basis
        collision_space = self._collision_space
        collision_space_restriction = self._collision_space_restriction
        domain = collision_space_restriction.domain
        collision_space_partition = collision_space_restriction.space_partition

        if (
            self.collider_fraction_test is not None
            and self.collider_fraction_test.space_restriction.space_partition == collision_space_partition
        ):
            return
        collider_fraction_space = fem.make_collocated_function_space(collision_basis, dtype=float)

        # test, trial and discrete fields
        if self.collider_fraction_test is None:
            self.collider_fraction_test = fem.make_test(
                collider_fraction_space, space_restriction=collision_space_restriction
            )
            self.collider_distance_field = collider_fraction_space.make_field(space_partition=collision_space_partition)

            self.collider_velocity_field = collision_space.make_field(space_partition=collision_space_partition)
            self.collider_normal_field = collision_space.make_field(space_partition=collision_space_partition)

            self.background_impulse_field = fem.UniformField(domain, wp.vec3(0.0))
        else:
            self.collider_fraction_test.rebind(collider_fraction_space, collision_space_restriction)
            self.collider_distance_field.rebind(collider_fraction_space, collision_space_partition)

            self.collider_velocity_field.rebind(collision_space, collision_space_partition)
            self.collider_normal_field.rebind(collision_space, collision_space_partition)

            self.background_impulse_field.domain = domain

        self.impulse_field = collision_space.make_field(space_partition=collision_space_partition)
        self.collider_position_field = collision_space.make_field(space_partition=collision_space_partition)
        self.collider_ids = wp.empty(collision_space_partition.node_count(), dtype=int)

    def require_strain_space_fields(self):
        """Ensure strain-space fields exist and match current spaces."""
        strain_basis = self._strain_basis
        sym_strain_space = self._sym_strain_space
        strain_space_restriction = self._strain_space_restriction
        domain = strain_space_restriction.domain
        strain_space_partition = strain_space_restriction.space_partition

        if (
            self.sym_strain_test is not None
            and self.sym_strain_test.space_restriction.space_partition == strain_space_partition
        ):
            return

        divergence_space = fem.make_collocated_function_space(strain_basis, dtype=float)
        strain_yield_parameters_space = fem.make_collocated_function_space(strain_basis, dtype=YieldParamVec)

        if self.sym_strain_test is None:
            self.sym_strain_test = fem.make_test(sym_strain_space, space_restriction=strain_space_restriction)
            self.divergence_test = fem.make_test(divergence_space, space_restriction=strain_space_restriction)
            self.strain_yield_parameters_test = fem.make_test(
                strain_yield_parameters_space, space_restriction=strain_space_restriction
            )
            self.sym_strain_trial = fem.make_trial(
                sym_strain_space, domain=domain, space_partition=strain_space_partition
            )

            self.elastic_strain_delta_field = sym_strain_space.make_field(space_partition=strain_space_partition)
            self.plastic_strain_delta_field = sym_strain_space.make_field(space_partition=strain_space_partition)
            self.strain_yield_parameters_field = strain_yield_parameters_space.make_field(
                space_partition=strain_space_partition
            )

            self.background_stress_field = fem.UniformField(domain, wp.mat33(0.0))
        else:
            self.sym_strain_test.rebind(sym_strain_space, strain_space_restriction)
            self.divergence_test.rebind(divergence_space, strain_space_restriction)
            self.strain_yield_parameters_test.rebind(strain_yield_parameters_space, strain_space_restriction)

            self.sym_strain_trial.rebind(sym_strain_space, strain_space_partition, domain)

            self.elastic_strain_delta_field.rebind(sym_strain_space, strain_space_partition)
            self.plastic_strain_delta_field.rebind(sym_strain_space, strain_space_partition)
            self.strain_yield_parameters_field.rebind(strain_yield_parameters_space, strain_space_partition)

            self.background_stress_field.domain = domain

        self.stress_field = sym_strain_space.make_field(space_partition=strain_space_partition)

    @property
    def collider_node_count(self) -> int:
        return self._collision_space_restriction.space_partition.node_count()

    @property
    def velocity_node_count(self) -> int:
        return self._vel_space_restriction.space_partition.node_count()

    @property
    def strain_node_count(self) -> int:
        return self._strain_space_restriction.space_partition.node_count()

    def allocate_temporaries(
        self,
        collider_count: int,
        has_compliant_bodies: bool,
        has_critical_fraction: bool,
        max_colors: int,
        temporary_store: fem.TemporaryStore,
    ):
        """Allocate transient arrays sized to current grid and options."""
        vel_node_count = self.velocity_node_count
        collider_node_count = self.collider_node_count
        strain_node_count = self.strain_node_count

        self.inv_mass_matrix = fem.borrow_temporary(temporary_store, shape=(vel_node_count,), dtype=float)

        self.collider_velocity = fem.borrow_temporary(temporary_store, shape=(collider_node_count,), dtype=wp.vec3)
        self.collider_friction = fem.borrow_temporary(temporary_store, shape=(collider_node_count,), dtype=float)
        self.collider_adhesion = fem.borrow_temporary(temporary_store, shape=(collider_node_count,), dtype=float)
        self.collider_inv_mass_matrix = fem.borrow_temporary(temporary_store, shape=(collider_node_count,), dtype=float)
        self.collider_node_volume = fem.borrow_temporary(temporary_store, shape=collider_node_count, dtype=float)

        self.strain_node_particle_volume = fem.borrow_temporary(temporary_store, shape=strain_node_count, dtype=float)
        self.int_symmetric_strain = fem.borrow_temporary(temporary_store, shape=strain_node_count, dtype=vec6)
        self.unilateral_strain_offset = fem.borrow_temporary(temporary_store, shape=strain_node_count, dtype=float)

        sp.bsr_set_zero(self.strain_matrix, rows_of_blocks=strain_node_count, cols_of_blocks=vel_node_count)
        sp.bsr_set_zero(self.compliance_matrix, rows_of_blocks=strain_node_count, cols_of_blocks=strain_node_count)

        if has_critical_fraction:
            self.strain_node_volume = fem.borrow_temporary(temporary_store, shape=strain_node_count, dtype=float)
            self.strain_node_collider_volume = fem.borrow_temporary(
                temporary_store, shape=strain_node_count, dtype=float
            )

        if has_compliant_bodies:
            self.collider_total_volumes = fem.borrow_temporary(temporary_store, shape=collider_count, dtype=float)

        if max_colors > 0:
            self.color_indices = fem.borrow_temporary(temporary_store, shape=strain_node_count * 2, dtype=int)
            self.color_offsets = fem.borrow_temporary(temporary_store, shape=max_colors + 1, dtype=int)

    def release_temporaries(self):
        """Release previously allocated temporaries to the store."""
        self.inv_mass_matrix.release()
        self.collider_velocity.release()
        self.collider_friction.release()
        self.collider_adhesion.release()
        self.collider_inv_mass_matrix.release()
        self.collider_node_volume.release()
        self.int_symmetric_strain.release()
        self.strain_node_particle_volume.release()
        self.unilateral_strain_offset.release()

        if self.strain_node_volume is not None:
            self.strain_node_volume.release()
            self.strain_node_collider_volume.release()

        if self.collider_total_volumes is not None:
            self.collider_total_volumes.release()

        if self.color_indices is not None:
            self.color_indices.release()
            self.color_offsets.release()


class LastStepData:
    """Persistent solver state preserved across time steps.

    Separate from _ImplicitMPMScratchpad which is rebuilt when the grid changes.
    Stores warmstart fields for the iterative solver and previous body transforms
    for finite-difference velocity computation.
    """

    def __init__(self):
        self.ws_impulse_field = None  # Warmstart for collision impulses
        self.ws_stress_field = None  # Warmstart for stress field
        self.body_q_prev = None  # Previous body transforms for finite-difference velocities


@wp.kernel
def compute_bounds(
    pos: wp.array(dtype=wp.vec3),
    particle_flags: wp.array(dtype=wp.int32),
    lower_bounds: wp.array(dtype=wp.vec3),
    upper_bounds: wp.array(dtype=wp.vec3),
):
    block_id, lane = wp.tid()
    i = block_id * wp.block_dim() + lane

    # pad with +- inf for min/max
    # tile_min scalar only, so separate components
    # no tile_atomic_min yet, extract first and use lane 0

    if i >= pos.shape[0]:
        valid = False
    elif ~particle_flags[i] & newton.ParticleFlags.ACTIVE:
        valid = False
    else:
        valid = True

    if valid:
        p = pos[i]
        min_x = p[0]
        min_y = p[1]
        min_z = p[2]
        max_x = p[0]
        max_y = p[1]
        max_z = p[2]
    else:
        min_x = _INFINITY
        min_y = _INFINITY
        min_z = _INFINITY
        max_x = -_INFINITY
        max_y = -_INFINITY
        max_z = -_INFINITY

    tile_min_x = wp.tile_min(wp.tile(min_x))[0]
    tile_max_x = wp.tile_max(wp.tile(max_x))[0]
    tile_min_y = wp.tile_min(wp.tile(min_y))[0]
    tile_max_y = wp.tile_max(wp.tile(max_y))[0]
    tile_min_z = wp.tile_min(wp.tile(min_z))[0]
    tile_max_z = wp.tile_max(wp.tile(max_z))[0]
    tile_min = wp.vec3(tile_min_x, tile_min_y, tile_min_z)
    tile_max = wp.vec3(tile_max_x, tile_max_y, tile_max_z)
    if lane == 0:
        wp.atomic_min(lower_bounds, 0, tile_min)
        wp.atomic_max(upper_bounds, 0, tile_max)


@wp.kernel
def clamp_coordinates(
    coords: wp.array(dtype=wp.vec3),
):
    i = wp.tid()
    coords[i] = wp.min(wp.max(coords[i], wp.vec3(0.0)), wp.vec3(1.0))


@wp.kernel
def pad_voxels(particle_q: wp.array(dtype=wp.vec3i), padded_q: wp.array4d(dtype=wp.vec3i)):
    pid = wp.tid()

    for i in range(3):
        for j in range(3):
            for k in range(3):
                padded_q[pid, i, j, k] = particle_q[pid] + wp.vec3i(i - 1, j - 1, k - 1)


@wp.func
def _positive_modn(x: int, n: int):
    return (x % n + n) % n


def _allocate_by_voxels(particle_q, voxel_size, padding_voxels: int = 0):
    volume = wp.Volume.allocate_by_voxels(
        voxel_points=particle_q.flatten(),
        voxel_size=voxel_size,
    )

    for _pad_i in range(padding_voxels):
        voxels = wp.empty((volume.get_voxel_count(),), dtype=wp.vec3i)
        volume.get_voxels(voxels)

        padded_voxels = wp.zeros((voxels.shape[0], 3, 3, 3), dtype=wp.vec3i)
        wp.launch(pad_voxels, voxels.shape[0], (voxels, padded_voxels))

        volume = wp.Volume.allocate_by_voxels(
            voxel_points=padded_voxels.flatten(),
            voxel_size=voxel_size,
        )

    return volume


@wp.kernel
def node_color(
    space_node_indices: wp.array(dtype=int),
    nodes_per_element: int,
    stencil_size: int,
    voxels: wp.array(dtype=wp.vec3i),
    res: wp.vec3i,
    colors: wp.array(dtype=int),
    color_indices: wp.array(dtype=int),
):
    nid = wp.tid()
    vid = space_node_indices[nid * nodes_per_element] // nodes_per_element

    if voxels:
        c = voxels[vid]
    else:
        c = fem.Grid3D.get_cell(res, vid)

    colors[nid] = (
        _positive_modn(c[0], stencil_size) * stencil_size * stencil_size
        + _positive_modn(c[1], stencil_size) * stencil_size
        + _positive_modn(c[2], stencil_size)
    )
    color_indices[nid] = nid * nodes_per_element


_NULL_COLOR = 1 << 31 - 1  # color for null nodes. make sure it is sorted last


@wp.kernel
def compute_color_offsets(
    max_color_count: int,
    unique_count: wp.array(dtype=int),
    unique_colors: wp.array(dtype=int),
    color_counts: wp.array(dtype=int),
    color_offsets: wp.array(dtype=int),
):
    current_sum = int(0)
    count = unique_count[0]

    for k in range(count):
        color_offsets[k] = current_sum
        color = unique_colors[k]
        local_count = wp.where(color == _NULL_COLOR, 0, color_counts[k])
        current_sum += local_count

    for k in range(count, max_color_count + 1):
        color_offsets[k] = current_sum


@fem.integrand
def mark_active_cells(
    s: fem.Sample,
    domain: fem.Domain,
    positions: wp.array(dtype=wp.vec3),
    particle_flags: wp.array(dtype=int),
    active_cells: wp.array(dtype=int),
):
    if ~particle_flags[s.qp_index] & newton.ParticleFlags.ACTIVE:
        return

    x = positions[s.qp_index]
    s_grid = fem.lookup(domain, x)

    if s_grid.element_index != fem.NULL_ELEMENT_INDEX:
        active_cells[s_grid.element_index] = 1


@wp.kernel
def scatter_field_dof_values(
    space_node_indices: wp.array(dtype=int),
    src: wp.array(dtype=Any),
    dest: wp.array(dtype=Any),
):
    nid = wp.tid()

    if nid != fem.NULL_NODE_INDEX:
        dest[space_node_indices[nid]] = src[nid]


wp.overload(scatter_field_dof_values, {"src": wp.array(dtype=wp.vec3), "dest": wp.array(dtype=wp.vec3)})
wp.overload(scatter_field_dof_values, {"src": wp.array(dtype=vec6), "dest": wp.array(dtype=vec6)})


class SolverImplicitMPM(SolverBase):
    """Implicit MPM solver.

    This solver implements an implicit MPM algorithm for granular materials,
    roughly following [1] but with a GPU-friendly rheology solver.

    This variant of MPM is mostly interesting for very stiff materials, especially
    in the fully inelastic limit, but is not as versatile as more traditional explicit approaches.

    [1] https://doi.org/10.1145/2897824.2925877

    Args:
        model: The model to solve.
        config: The solver configuration.

    Returns:
        The solver.
    """

    @dataclass
    class Config:
        """Implicit MPM solver configuration."""

        # numerics
        max_iterations: int = 250
        """Maximum number of iterations for the rheology solver."""
        tolerance: float = 1.0e-5
        """Tolerance for the rheology solver."""
        strain_basis: str = "P0"
        """Strain basis functions. May be one of P0, Q1"""
        solver: str = "gauss-seidel"
        """Solver to use for the rheology solver. May be one of gauss-seidel, jacobi."""
        warmstart_mode: str = "auto"
        """Warmstart mode to use for the rheology solver. May be one of none, auto, particles, grid."""
        collider_velocity_mode: str = "instantaneous"
        """Collider velocity computation mode. May be one of instantaneous, finite_difference."""

        # grid
        voxel_size: float = 0.1
        """Size of the grid voxels."""
        grid_type: str = "sparse"
        """Type of grid to use. May be one of sparse, dense, fixed."""
        grid_padding: int = 0
        """Number of empty cells to add around particles when allocating the grid."""
        max_active_cell_count: int = -1
        """Maximum number of active cells to use for active subsets of dense grids. -1 means unlimited."""
        transfer_scheme: str = "apic"
        """Transfer scheme to use for particle-grid transfers. May be one of apic, pic."""

        # material / background
        critical_fraction: float = 0.0
        """Fraction for particles under which the yield surface collapses."""
        air_drag: float = 1.0
        """Numerical drag for the background air."""

        # experimental
        collider_normal_from_sdf_gradient: bool = False
        """Compute collider normals from sdf gradient rather than closest point"""
        collider_basis: str = "Q1"
        """Collider basis function string. Examples: P0 (piecewise constant), Q1 (trilinear), S2 (quadratic serendipity), pic8 (particle-based with max 8 points per cell)"""

    @classmethod
    def register_custom_attributes(cls, builder: newton.ModelBuilder) -> None:
        """Register MPM-specific custom attributes in the 'mpm' namespace.

        This method registers per-particle material parameters and state variables
        for the implicit MPM solver.

        Attributes registered on Model (per-particle):
            - ``mpm:young_modulus``: Young's modulus in Pa
            - ``mpm:poisson_ratio``: Poisson's ratio for elasticity
            - ``mpm:damping``: Viscous damping coefficient
            - ``mpm:hardening``: Hardening factor for plasticity
            - ``mpm:friction``: Friction coefficient
            - ``mpm:yield_pressure``: Yield pressure in Pa
            - ``mpm:tensile_yield_ratio``: Tensile yield ratio
            - ``mpm:yield_stress``: Deviatoric yield stress in Pa

        Attributes registered on State (per-particle):
            - ``mpm:particle_qd_grad``: Velocity gradient for APIC transfer
            - ``mpm:particle_elastic_strain``: Elastic deformation gradient
            - ``mpm:particle_Jp``: Determinant of plastic deformation gradient
            - ``mpm:particle_transform``: Overall deformation gradient for rendering
        """
        # Per-particle material parameters
        builder.add_custom_attribute(
            newton.ModelBuilder.CustomAttribute(
                name="young_modulus",
                frequency=newton.Model.AttributeFrequency.PARTICLE,
                assignment=newton.Model.AttributeAssignment.MODEL,
                dtype=wp.float32,
                default=1.0e15,
                namespace="mpm",
            )
        )
        builder.add_custom_attribute(
            newton.ModelBuilder.CustomAttribute(
                name="poisson_ratio",
                frequency=newton.Model.AttributeFrequency.PARTICLE,
                assignment=newton.Model.AttributeAssignment.MODEL,
                dtype=wp.float32,
                default=0.3,
                namespace="mpm",
            )
        )
        builder.add_custom_attribute(
            newton.ModelBuilder.CustomAttribute(
                name="damping",
                frequency=newton.Model.AttributeFrequency.PARTICLE,
                assignment=newton.Model.AttributeAssignment.MODEL,
                dtype=wp.float32,
                default=0.0,
                namespace="mpm",
            )
        )
        builder.add_custom_attribute(
            newton.ModelBuilder.CustomAttribute(
                name="hardening",
                frequency=newton.Model.AttributeFrequency.PARTICLE,
                assignment=newton.Model.AttributeAssignment.MODEL,
                dtype=wp.float32,
                default=0.0,
                namespace="mpm",
            )
        )
        builder.add_custom_attribute(
            newton.ModelBuilder.CustomAttribute(
                name="friction",
                frequency=newton.Model.AttributeFrequency.PARTICLE,
                assignment=newton.Model.AttributeAssignment.MODEL,
                dtype=wp.float32,
                default=0.5,
                namespace="mpm",
            )
        )
        builder.add_custom_attribute(
            newton.ModelBuilder.CustomAttribute(
                name="yield_pressure",
                frequency=newton.Model.AttributeFrequency.PARTICLE,
                assignment=newton.Model.AttributeAssignment.MODEL,
                dtype=wp.float32,
                default=1.0e15,
                namespace="mpm",
            )
        )
        builder.add_custom_attribute(
            newton.ModelBuilder.CustomAttribute(
                name="tensile_yield_ratio",
                frequency=newton.Model.AttributeFrequency.PARTICLE,
                assignment=newton.Model.AttributeAssignment.MODEL,
                dtype=wp.float32,
                default=0.0,
                namespace="mpm",
            )
        )
        builder.add_custom_attribute(
            newton.ModelBuilder.CustomAttribute(
                name="yield_stress",
                frequency=newton.Model.AttributeFrequency.PARTICLE,
                assignment=newton.Model.AttributeAssignment.MODEL,
                dtype=wp.float32,
                default=0.0,
                namespace="mpm",
            )
        )

        # Per-particle state attributes (attached to State objects)
        identity = wp.mat33(np.eye(3))
        builder.add_custom_attribute(
            newton.ModelBuilder.CustomAttribute(
                name="particle_qd_grad",
                frequency=newton.Model.AttributeFrequency.PARTICLE,
                assignment=newton.Model.AttributeAssignment.STATE,
                dtype=wp.mat33,
                default=wp.mat33(0.0),
                namespace="mpm",
            )
        )
        builder.add_custom_attribute(
            newton.ModelBuilder.CustomAttribute(
                name="particle_elastic_strain",
                frequency=newton.Model.AttributeFrequency.PARTICLE,
                assignment=newton.Model.AttributeAssignment.STATE,
                dtype=wp.mat33,
                default=identity,
                namespace="mpm",
            )
        )
        builder.add_custom_attribute(
            newton.ModelBuilder.CustomAttribute(
                name="particle_Jp",
                frequency=newton.Model.AttributeFrequency.PARTICLE,
                assignment=newton.Model.AttributeAssignment.STATE,
                dtype=wp.float32,
                default=1.0,
                namespace="mpm",
            )
        )
        builder.add_custom_attribute(
            newton.ModelBuilder.CustomAttribute(
                name="particle_transform",
                frequency=newton.Model.AttributeFrequency.PARTICLE,
                assignment=newton.Model.AttributeAssignment.STATE,
                dtype=wp.mat33,
                default=identity,
                namespace="mpm",
            )
        )

    def __init__(
        self,
        model: newton.Model,
        config: Config,
    ):
        super().__init__(model)

        self._mpm_model = ImplicitMPMModel(model, config)

        self.max_iterations = config.max_iterations
        self.tolerance = float(config.tolerance)

        self.velocity_basis = "Q1"
        self.strain_basis = config.strain_basis

        self.grid_padding = config.grid_padding
        self.grid_type = config.grid_type
        self.coloring = config.solver == "gauss-seidel"
        self.apic = config.transfer_scheme == "apic"
        self.max_active_cell_count = config.max_active_cell_count

        self.collider_normal_from_sdf_gradient = config.collider_normal_from_sdf_gradient
        self.collider_basis = config.collider_basis
        self.collider_velocity_mode = self._mpm_model.collider_velocity_mode

        self.temporary_store = fem.TemporaryStore()

        self._use_cuda_graph = self.model.device.is_cuda and wp.is_conditional_graph_supported()

        self._enable_timers = False
        self._timers_use_nvtx = False

        # Pre-allocate scratchpad and last step data so that step() can be graph-captured
        self._scratchpad = None
        self._last_step_data = LastStepData()
        with wp.ScopedDevice(model.device):
            pic = self._particles_to_cells(model.particle_q)
            self._rebuild_scratchpad(pic)
            self._require_velocity_space_fields(self._scratchpad, self._mpm_model.has_compliant_particles)
            self._require_collision_space_fields(self._scratchpad, self._last_step_data)
            self._require_strain_space_fields(self._scratchpad, self._last_step_data)

    def setup_collider(
        self,
        collider_meshes: list[wp.Mesh] | None = None,
        collider_body_ids: list[int] | None = None,
        collider_thicknesses: list[float] | None = None,
        collider_friction: list[float] | None = None,
        collider_adhesion: list[float] | None = None,
        collider_projection_threshold: list[float] | None = None,
        model: newton.Model | None = None,
        body_com: wp.array | None = None,
        body_mass: wp.array | None = None,
        body_inv_inertia: wp.array | None = None,
        body_q: wp.array | None = None,
    ):
        """Configure collider geometry and material properties.

        By default, collisions are set up against all shapes in the model with
        ``newton.ShapeFlags.COLLIDE_PARTICLES``. Use this method to customize
        collider sources, materials, or to read colliders from a different model.

        Args:
            collider_meshes: Warp triangular meshes used as colliders.
            collider_body_ids: For dynamic colliders, per-mesh body ids.
            collider_thicknesses: Per-mesh signed distance offsets (m).
            collider_friction: Per-mesh Coulomb friction coefficients.
            collider_adhesion: Per-mesh adhesion (Pa).
            collider_projection_threshold: Per-mesh projection threshold (m).
            model: The model to read collider properties from. Default to solver's model.
            body_com: For dynamic colliders, per-body center of mass.
            body_mass: For dynamic colliders, per-body mass. Pass zeros for kinematic bodies.
            body_inv_inertia: For dynamic colliders, per-body inverse inertia.
            body_q: For dynamic colliders, per-body initial transform.
        """
        self._mpm_model.setup_collider(
            collider_meshes=collider_meshes,
            collider_body_ids=collider_body_ids,
            collider_thicknesses=collider_thicknesses,
            collider_friction=collider_friction,
            collider_adhesion=collider_adhesion,
            collider_projection_threshold=collider_projection_threshold,
            model=model,
            body_com=body_com,
            body_mass=body_mass,
            body_inv_inertia=body_inv_inertia,
            body_q=body_q,
        )

        if self._mpm_model.collider_body_q is not None:
            self._last_step_data.body_q_prev = wp.clone(self._mpm_model.collider_body_q)

    @property
    def voxel_size(self) -> float:
        """Grid voxel size used by the solver."""
        return self._mpm_model.voxel_size

    @override
    def step(
        self,
        state_in: newton.State,
        state_out: newton.State,
        control: newton.Control,
        contacts: newton.Contacts,
        dt: float,
    ):
        model = self.model

        with wp.ScopedDevice(model.device):
            pic = self._particles_to_cells(state_in.particle_q)
            scratch = self._rebuild_scratchpad(pic)
            self._step_impl(state_in, state_out, dt, pic, scratch)
            scratch.release_temporaries()

    @override
    def notify_model_changed(self, flags: int):
        if flags & newton.SolverNotifyFlags.PARTICLE_PROPERTIES:
            self._mpm_model.notify_particle_material_changed()

    def project_outside(
        self, state_in: newton.State, state_out: newton.State, dt: float, max_dist: float | None = None
    ):
        """Project particles outside of colliders, and adjust their velocity and velocity gradients

        Args:
            state_in: The input state.
            state_out: The output state. Only particle_q, particle_qd, and particle_qd_grad are written.
            dt: The time step, for extrapolating the collider end-of-step positions from its current position and velocity.
            max_dist: Maximum distance for closest-point queries. If None, the default is the voxel size times sqrt(3).
        """

        if max_dist is not None:
            # Update max query dist if provided
            prev_max_dist, self._mpm_model.collider.query_max_dist = self._mpm_model.collider.query_max_dist, max_dist

        if (
            self._last_step_data.body_q_prev is not None
            and state_in.body_q is not None
            and self._last_step_data.body_q_prev.shape != state_in.body_q.shape
        ):
            # In unlikely case that number of colliding bodies has changed
            self._last_step_data.body_q_prev = wp.clone(state_in.body_q)

        wp.launch(
            project_outside_collider,
            dim=state_in.particle_count,
            inputs=[
                state_in.particle_q,
                state_in.particle_qd,
                state_in.mpm.particle_qd_grad,
                self.model.particle_flags,
                self._mpm_model.collider,
                state_in.body_q,
                state_in.body_qd,
                self._last_step_data.body_q_prev,
                dt,
            ],
            outputs=[
                state_out.particle_q,
                state_out.particle_qd,
                state_out.mpm.particle_qd_grad,
            ],
            device=state_in.particle_q.device,
        )

        if max_dist is not None:
            # Restore previous max query dist
            self._mpm_model.collider.query_max_dist = prev_max_dist

    def collect_collider_impulses(self, state: newton.State) -> tuple[wp.array, wp.array, wp.array]:
        """Collect current collider impulses and their application positions.

        Returns a tuple of 3 arrays:
            - Impulse values in world units.
            - Collider positions in world units.
            - Collider id, that can be mapped back to the model's body ids using the ``collider_body_index`` property.
        """

        # Not stepped yet, read from preallocated scratchpad
        if not hasattr(state, "impulse_field"):
            state = self._scratchpad

        cell_volume = self._mpm_model.voxel_size**3
        return (
            -cell_volume * state.impulse_field.dof_values,
            state.collider_position_field.dof_values,
            state.collider_ids,
        )

    @property
    def collider_body_index(self) -> wp.array:
        """Array mapping collider indices to body indices.

        Returns:
            Per-collider body index array. Value is -1 for colliders that are not bodies.
        """
        return self._mpm_model.collider.collider_body_index

    def update_particle_frames(
        self,
        state_prev: newton.State,
        state: newton.State,
        dt: float,
        min_stretch: float = 0.25,
        max_stretch: float = 2.0,
    ):
        """Update per-particle deformation frames for rendering and projection.

        Integrates the particle deformation gradient using the velocity gradient
        and clamps its principal stretches to the provided bounds for
        robustness.
        """

        wp.launch(
            update_particle_frames,
            dim=state.particle_count,
            inputs=[
                dt,
                min_stretch,
                max_stretch,
                state.mpm.particle_qd_grad,
                state_prev.mpm.particle_transform,
                state.mpm.particle_transform,
            ],
            device=state.mpm.particle_qd_grad.device,
        )

    def sample_render_grains(self, state: newton.State, grains_per_particle: int):
        """Generate per-particle point samples used for high-resolution rendering.

        Args:
            state: Current Newton state providing particle positions.
            grains_per_particle: Number of grains to sample per particle.

        Returns:
            A ``wp.array`` with shape ``(num_particles, grains_per_particle)`` of
            type ``wp.vec3`` containing grain positions.
        """

        return sample_render_grains(state, self._mpm_model.particle_radius, grains_per_particle)

    def update_render_grains(
        self,
        state_prev: newton.State,
        state: newton.State,
        grains: wp.array,
        dt: float,
    ):
        """Advect grain samples with the grid velocity and keep them inside the deformed particle.

        Args:
            state_prev: Previous state (t_n).
            state: Current state (t_{n+1}).
            grains: 2D array of grain positions per particle to be updated in place. See ``sample_render_grains``.
            dt: Time step duration.
        """

        return update_render_grains(state_prev, state, grains, self._mpm_model.particle_radius, dt)

    def _allocate_grid(
        self,
        positions: wp.array,
        particle_flags: wp.array,
        voxel_size: float,
        temporary_store: fem.TemporaryStore,
        padding_voxels: int = 0,
    ):
        """Create a grid (sparse or dense) covering all particle positions.

        Uses a sparse ``Nanogrid`` when requested; otherwise computes an axis
        aligned bounding box and instantiates a dense ``Grid3D`` with optional
        padding in voxel units.

        Args:
            positions: Particle positions to bound.
            voxel_size: Grid voxel edge length.
            temporary_store: Temporary storage for intermediate buffers.
            padding_voxels: Additional empty voxels to add around the bounds.

        Returns:
            A geometry partition suitable for FEM field assembly.
        """
        with self._timer("Allocate grid"):
            if self.grid_type == "sparse":
                volume = _allocate_by_voxels(positions, voxel_size, padding_voxels=padding_voxels)
                grid = fem.Nanogrid(volume, temporary_store=temporary_store)
            else:
                # Compute bounds and transfer to host
                device = positions.device
                if device.is_cuda:
                    min_dev = fem.borrow_temporary(temporary_store, shape=1, dtype=wp.vec3, device=device)
                    max_dev = fem.borrow_temporary(temporary_store, shape=1, dtype=wp.vec3, device=device)

                    min_dev.fill_(wp.vec3(_INFINITY))
                    max_dev.fill_(wp.vec3(-_INFINITY))

                    tile_size = 256
                    wp.launch(
                        compute_bounds,
                        dim=((positions.shape[0] + tile_size - 1) // tile_size, tile_size),
                        block_dim=tile_size,
                        inputs=[positions, particle_flags, min_dev, max_dev],
                        device=device,
                    )

                    min_host = fem.borrow_temporary(
                        temporary_store, shape=1, dtype=wp.vec3, device="cpu", pinned=device.is_cuda
                    )
                    max_host = fem.borrow_temporary(
                        temporary_store, shape=1, dtype=wp.vec3, device="cpu", pinned=device.is_cuda
                    )
                    wp.copy(src=min_dev, dest=min_host)
                    wp.copy(src=max_dev, dest=max_host)
                    wp.synchronize_stream()
                    bbox_min, bbox_max = min_host.numpy(), max_host.numpy()
                else:
                    bbox_min, bbox_max = np.min(positions.numpy(), axis=0), np.max(positions.numpy(), axis=0)

                # Round to nearest voxel
                grid_min = np.floor(bbox_min / voxel_size) - padding_voxels
                grid_max = np.ceil(bbox_max / voxel_size) + padding_voxels

                grid = fem.Grid3D(
                    bounds_lo=wp.vec3(grid_min * voxel_size),
                    bounds_hi=wp.vec3(grid_max * voxel_size),
                    res=wp.vec3i((grid_max - grid_min).astype(int)),
                )

        return grid

    def _create_geometry_partition(
        self, grid: fem.Geometry, positions: wp.array, particle_flags: wp.array, max_cell_count: int
    ):
        """Create a geometry partition for the given positions."""

        active_cells = fem.borrow_temporary(self.temporary_store, shape=grid.cell_count(), dtype=int)
        active_cells.zero_()
        fem.interpolate(
            mark_active_cells,
            dim=positions.shape[0],
            at=fem.Cells(grid),
            values={
                "positions": positions,
                "particle_flags": particle_flags,
                "active_cells": active_cells,
            },
            temporary_store=self.temporary_store,
        )

        partition = fem.ExplicitGeometryPartition(
            grid,
            cell_mask=active_cells,
            max_cell_count=max_cell_count,
            max_side_count=0,
            temporary_store=self.temporary_store,
        )
        active_cells.release()

        return partition

    def _rebuild_scratchpad(self, pic: fem.PicQuadrature):
        """(Re)create function spaces and allocate per-step temporaries.

        Allocates the grid based on current particle positions, rebuilds
        velocity and strain spaces as needed, configures collision data, and
        optionally computes a Gauss-Seidel coloring for the strain nodes.
        """

        if self._scratchpad is None:
            self._scratchpad = ImplicitMPMScratchpad()

        scratch = self._scratchpad

        with self._timer("Scratchpad"):
            scratch.rebuild_function_spaces(
                pic,
                strain_basis_str=self.strain_basis,
                collider_basis_str=self.collider_basis,
                max_cell_count=self.max_active_cell_count,
                temporary_store=self.temporary_store,
            )

            scratch.allocate_temporaries(
                collider_count=self._mpm_model.collider.collider_mesh.shape[0],
                has_compliant_bodies=self._mpm_model.has_compliant_colliders,
                has_critical_fraction=self._mpm_model.critical_fraction > 0.0,
                max_colors=self._max_colors(),
                temporary_store=self.temporary_store,
            )

            if self.coloring:
                self._compute_coloring(scratch=scratch)

        return scratch

    def _particles_to_cells(self, positions: wp.array) -> fem.PicQuadrature:
        """
        Rebuild the grid and grid partition around particles if required,
        then assign particles to grid cells.
        """

        # Rebuild grid

        if self._scratchpad is not None and self.grid_type == "fixed":
            grid = self._scratchpad.grid
        else:
            grid = self._allocate_grid(
                positions,
                self.model.particle_flags,
                voxel_size=self._mpm_model.voxel_size,
                temporary_store=self.temporary_store,
                padding_voxels=self.grid_padding,
            )

        # Build active partition
        with self._timer("Build active partition"):
            if self.grid_type == "sparse":
                max_cell_count = -1
                geo_partition = grid
            else:
                max_cell_count = self.max_active_cell_count
                geo_partition = self._create_geometry_partition(
                    grid, positions, self.model.particle_flags, max_cell_count
                )

        # Bin particles to grid cells
        with self._timer("Bin particles"):
            domain = fem.Cells(geo_partition)
            pic = fem.PicQuadrature(
                domain=domain,
                positions=positions,
                measures=self._mpm_model.particle_volume,
                temporary_store=self.temporary_store,
            )

            if self.grid_type == "fixed":
                wp.launch(
                    clamp_coordinates,
                    dim=pic.particle_coords.shape,
                    inputs=[pic.particle_coords],
                )

        return pic

    def _step_impl(
        self,
        state_in: newton.State,
        state_out: newton.State,
        dt: float,
        pic: fem.PicQuadrature,
        scratch: ImplicitMPMScratchpad,
    ):
        """Single implicit MPM step: bin, rasterize, assemble, solve, advect.

        Executes the full pipeline for one time step, including particle
        binning, collider rasterization, RHS assembly, strain/compliance matrix
        computation, warm-starting, coupled rheology/contact solve, strain
        updates, and particle advection.

        Args:
            state_in: Input state at the beginning of the timestep.
            state_out: Output state to write to.
            dt: Timestep length.
            pic: Particle-in-cell quadrature data.
            scratch: Scratchpad for temporary storage.
        """

        cell_volume = self._mpm_model.voxel_size**3
        inv_cell_volume = 1.0 / cell_volume

        mpm_model = self._mpm_model
        last_step_data = self._last_step_data

        self._require_collision_space_fields(scratch, last_step_data)
        self._require_velocity_space_fields(scratch, mpm_model.has_compliant_particles)

        # Rasterize colliders to discrete space
        self._rasterize_colliders(state_in, dt, last_step_data, scratch, inv_cell_volume)

        # Velocity right-hand side and inverse mass matrix
        self._compute_unconstrained_velocity(state_in, dt, pic, scratch, inv_cell_volume)

        # Build collider rigidity matrix
        rigidity_operator = self._build_collider_rigidity_operator(state_in, scratch, cell_volume)

        self._require_strain_space_fields(scratch, last_step_data)

        # Build elasticity compliance matrix and right-hand-side
        self._build_elasticity_system(state_in, dt, pic, scratch, inv_cell_volume)

        # Build strain matrix and offset, setup yield surface parameters
        self._build_plasticity_system(state_in, dt, pic, scratch, inv_cell_volume)

        # Solve implicit system
        self._solve_rheology(scratch, rigidity_operator, last_step_data)

        # Update and advect particles
        self._update_particles(state_in, state_out, dt, pic, scratch)

        # Save data for next step or further processing
        self._save_data(state_in, scratch, last_step_data, state_out)

    def _compute_unconstrained_velocity(
        self,
        state_in: newton.State,
        dt: float,
        pic: fem.PicQuadrature,
        scratch: ImplicitMPMScratchpad,
        inv_cell_volume: float,
    ):
        """Compute the unconstrained (ballistic) velocity at grid nodes, as well as inverse mass matrix."""

        model = self.model
        mpm_model = self._mpm_model

        with self._timer("Unconstrained velocity"):
            velocity_int = fem.integrate(
                integrate_velocity,
                quadrature=pic,
                fields={"u": scratch.velocity_test},
                values={
                    "velocities": state_in.particle_qd,
                    "dt": dt,
                    "gravity": model.gravity,
                    "particle_world": model.particle_world,
                    "particle_density": mpm_model.particle_density,
                    "particle_flags": model.particle_flags,
                    "inv_cell_volume": inv_cell_volume,
                },
                output_dtype=wp.vec3,
                temporary_store=self.temporary_store,
            )

            if self.apic:
                fem.integrate(
                    integrate_velocity_apic,
                    quadrature=pic,
                    fields={"u": scratch.velocity_test},
                    values={
                        "velocity_gradients": state_in.mpm.particle_qd_grad,
                        "particle_density": mpm_model.particle_density,
                        "particle_flags": model.particle_flags,
                        "inv_cell_volume": inv_cell_volume,
                    },
                    output=velocity_int,
                    add=True,
                    temporary_store=self.temporary_store,
                )

            node_particle_mass = fem.integrate(
                integrate_mass,
                quadrature=pic,
                fields={"phi": scratch.fraction_test},
                values={
                    "inv_cell_volume": inv_cell_volume,
                    "particle_density": mpm_model.particle_density,
                    "particle_flags": model.particle_flags,
                },
                output_dtype=float,
                temporary_store=self.temporary_store,
            )

            drag = mpm_model.air_drag * dt

            wp.launch(
                free_velocity,
                dim=scratch.velocity_node_count,
                inputs=[
                    velocity_int,
                    node_particle_mass,
                    drag,
                ],
                outputs=[
                    scratch.inv_mass_matrix,
                    scratch.velocity_field.dof_values,
                ],
            )

    def _rasterize_colliders(
        self,
        state_in: newton.State,
        dt: float,
        last_step_data: LastStepData,
        scratch: ImplicitMPMScratchpad,
        inv_cell_volume: float,
    ):
        # Rasterize collider to grid
        collider_node_count = scratch.collider_node_count
        vel_node_count = scratch.velocity_node_count

        with self._timer("Rasterize collider"):
            # volume associated to each collider node
            fem.integrate(
                integrate_fraction,
                fields={"phi": scratch.collider_fraction_test},
                values={"inv_cell_volume": inv_cell_volume},
                assembly="nodal",
                output=scratch.collider_node_volume,
                temporary_store=self.temporary_store,
            )

            # rasterize sdf and properties to grid
            rasterize_collider(
                self._mpm_model.collider,
                state_in.body_q,
                state_in.body_qd,
                last_step_data.body_q_prev,
                self._mpm_model.voxel_size,
                dt,
                scratch.collider_fraction_test.space_restriction,
                scratch.collider_node_volume,
                scratch.collider_position_field,
                scratch.collider_distance_field,
                scratch.collider_normal_field,
                scratch.collider_velocity,
                scratch.collider_friction,
                scratch.collider_adhesion,
                scratch.collider_ids,
                temporary_store=self.temporary_store,
            )

            # normal interpolation
            if self.collider_normal_from_sdf_gradient:
                interpolate_collider_normals(
                    scratch.collider_fraction_test.space_restriction,
                    scratch.collider_distance_field,
                    scratch.collider_normal_field,
                    temporary_store=self.temporary_store,
                )

            # Subgrid collisions
            if self.collider_basis != self.velocity_basis:
                #  Map from collider nodes to velocity nodes
                sp.bsr_set_zero(
                    scratch.collider_matrix, rows_of_blocks=collider_node_count, cols_of_blocks=vel_node_count
                )
                fem.interpolate(
                    collision_weight_field,
                    dest=scratch.collider_matrix,
                    dest_space=scratch.collider_fraction_test.space,
                    at=scratch.collider_fraction_test.space_restriction,
                    reduction="first",
                    fields={"trial": scratch.fraction_trial, "normal": scratch.collider_normal_field},
                    temporary_store=self.temporary_store,
                )

    def _build_collider_rigidity_operator(
        self,
        state_in: newton.State,
        scratch: ImplicitMPMScratchpad,
        cell_volume: float,
    ):
        has_compliant_colliders = self._mpm_model.min_collider_mass < _INFINITY

        if not has_compliant_colliders:
            scratch.collider_inv_mass_matrix.zero_()
            return None

        with self._timer("Collider compliance"):
            allot_collider_mass(
                cell_volume=cell_volume,
                node_volumes=scratch.collider_node_volume,
                collider=self._mpm_model.collider,
                body_mass=self._mpm_model.collider_body_mass,
                collider_ids=scratch.collider_ids,
                collider_total_volumes=scratch.collider_total_volumes,
                collider_inv_mass_matrix=scratch.collider_inv_mass_matrix,
            )

            rigidity_operator = build_rigidity_operator(
                cell_volume=cell_volume,
                node_volumes=scratch.collider_node_volume,
                node_positions=scratch.collider_position_field.dof_values,
                collider=self._mpm_model.collider,
                body_q=state_in.body_q,
                body_mass=self._mpm_model.collider_body_mass,
                body_inv_inertia=self._mpm_model.collider_body_inv_inertia,
                collider_ids=scratch.collider_ids,
                collider_total_volumes=scratch.collider_total_volumes,
            )

        return rigidity_operator

    def _build_elasticity_system(
        self,
        state_in: newton.State,
        dt: float,
        pic: fem.PicQuadrature,
        scratch: ImplicitMPMScratchpad,
        inv_cell_volume: float,
    ):
        """Build the elasticity and compliance system."""

        model = self.model
        mpm_model = self._mpm_model

        has_compliant_particles = mpm_model.min_young_modulus < _INFINITY

        if not has_compliant_particles:
            scratch.int_symmetric_strain.zero_()
            return

        with self._timer("Elasticity"):
            node_particle_volume = fem.integrate(
                integrate_fraction,
                quadrature=pic,
                fields={"phi": scratch.fraction_test},
                values={"inv_cell_volume": inv_cell_volume},
                output_dtype=float,
                temporary_store=self.temporary_store,
            )

            elastic_parameters_int = fem.integrate(
                integrate_elastic_parameters,
                quadrature=pic,
                fields={"u": scratch.velocity_test},
                values={
                    "particle_Jp": state_in.mpm.particle_Jp,
                    "young_modulus": model.mpm.young_modulus,
                    "poisson_ratio": model.mpm.poisson_ratio,
                    "damping": model.mpm.damping,
                    "hardening": model.mpm.hardening,
                    "inv_cell_volume": inv_cell_volume,
                },
                output_dtype=wp.vec3,
                temporary_store=self.temporary_store,
            )

            wp.launch(
                average_elastic_parameters,
                dim=scratch.elastic_parameters_field.space_partition.node_count(),
                inputs=[
                    elastic_parameters_int,
                    node_particle_volume,
                    scratch.elastic_parameters_field.dof_values,
                ],
            )

            fem.integrate(
                strain_rhs,
                quadrature=pic,
                fields={
                    "tau": scratch.sym_strain_test,
                    "elastic_parameters": scratch.elastic_parameters_field,
                },
                values={
                    "elastic_strains": state_in.mpm.particle_elastic_strain,
                    "inv_cell_volume": inv_cell_volume,
                    "dt": dt,
                },
                output=scratch.int_symmetric_strain,
                temporary_store=self.temporary_store,
            )

            fem.integrate(
                compliance_form,
                quadrature=pic,
                fields={
                    "tau": scratch.sym_strain_test,
                    "sig": scratch.sym_strain_trial,
                    "elastic_parameters": scratch.elastic_parameters_field,
                },
                values={
                    "elastic_strains": state_in.mpm.particle_elastic_strain,
                    "inv_cell_volume": inv_cell_volume,
                    "dt": dt,
                },
                output=scratch.compliance_matrix,
                temporary_store=self.temporary_store,
            )

    def _build_plasticity_system(
        self,
        state_in: newton.State,
        dt: float,
        pic: fem.PicQuadrature,
        scratch: ImplicitMPMScratchpad,
        inv_cell_volume: float,
    ):
        model = self.model
        mpm_model = self._mpm_model

        with self._timer("Compute strain-node volumes"):
            fem.integrate(
                integrate_fraction,
                quadrature=pic,
                fields={"phi": scratch.divergence_test},
                values={"inv_cell_volume": inv_cell_volume},
                output=scratch.strain_node_particle_volume,
                temporary_store=self.temporary_store,
            )

        with self._timer("Interpolated yield parameters"):
            yield_parameters_int = fem.integrate(
                integrate_yield_parameters,
                quadrature=pic,
                fields={
                    "u": scratch.strain_yield_parameters_test,
                },
                values={
                    "particle_Jp": state_in.mpm.particle_Jp,
                    "hardening": model.mpm.hardening,
                    "friction": model.mpm.friction,
                    "yield_pressure": model.mpm.yield_pressure,
                    "tensile_yield_ratio": model.mpm.tensile_yield_ratio,
                    "yield_stress": model.mpm.yield_stress,
                    "inv_cell_volume": inv_cell_volume,
                },
                output_dtype=YieldParamVec,
                temporary_store=self.temporary_store,
            )

            wp.launch(
                average_yield_parameters,
                dim=scratch.strain_node_particle_volume.shape[0],
                inputs=[
                    yield_parameters_int,
                    scratch.strain_node_particle_volume,
                    scratch.strain_yield_parameters_field.dof_values,
                ],
            )

        # Void fraction (unilateral incompressibility offset)
        if mpm_model.critical_fraction > 0.0:
            with self._timer("Unilateral offset"):
                fem.integrate(
                    integrate_fraction,
                    fields={"phi": scratch.divergence_test},
                    values={"inv_cell_volume": inv_cell_volume},
                    output=scratch.strain_node_volume,
                    temporary_store=self.temporary_store,
                )

                if isinstance(scratch.collider_distance_field.space.basis, fem.PointBasisSpace):
                    fem.integrate(
                        integrate_collider_fraction_apic,
                        fields={
                            "phi": scratch.divergence_test,
                            "sdf": scratch.collider_distance_field,
                            "sdf_gradient": scratch.collider_normal_field,
                        },
                        values={
                            "inv_cell_volume": inv_cell_volume,
                        },
                        output=scratch.strain_node_collider_volume,
                        temporary_store=self.temporary_store,
                    )
                else:
                    fem.integrate(
                        integrate_collider_fraction,
                        fields={
                            "phi": scratch.divergence_test,
                            "sdf": scratch.collider_distance_field,
                        },
                        values={
                            "inv_cell_volume": inv_cell_volume,
                        },
                        output=scratch.strain_node_collider_volume,
                        temporary_store=self.temporary_store,
                    )

                wp.launch(
                    compute_unilateral_strain_offset,
                    dim=scratch.strain_node_count,
                    inputs=[
                        mpm_model.critical_fraction,
                        scratch.strain_node_particle_volume,
                        scratch.strain_node_collider_volume,
                        scratch.strain_node_volume,
                        scratch.unilateral_strain_offset,
                    ],
                )
        else:
            scratch.unilateral_strain_offset.zero_()

        # Strain jacobian
        with self._timer("Strain matrix"):
            fem.integrate(
                strain_delta_form,
                quadrature=pic,
                fields={
                    "u": scratch.velocity_trial,
                    "tau": scratch.sym_strain_test,
                },
                values={
                    "dt": dt,
                    "inv_cell_volume": inv_cell_volume,
                },
                output_dtype=float,
                output=scratch.strain_matrix,
                temporary_store=self.temporary_store,
            )

    def _solve_rheology(
        self,
        scratch: ImplicitMPMScratchpad,
        rigidity_operator: tuple[sp.BsrMatrix, sp.BsrMatrix, sp.BsrMatrix] | None,
        last_step_data: LastStepData,
    ):
        strain_node_count = scratch.strain_node_count
        has_compliant_particles = self._mpm_model.has_compliant_particles

        with self._timer("Warmstart fields"):
            self._warmstart_fields(scratch, last_step_data)

        with self._timer("Strain solve"):
            # Retain graph to avoid immediate CPU synch
            solve_graph = solve_rheology(
                self.max_iterations,
                self.tolerance,
                scratch.strain_matrix,
                scratch.transposed_strain_matrix,
                scratch.compliance_matrix,
                scratch.inv_mass_matrix,
                scratch.strain_node_particle_volume,
                scratch.strain_yield_parameters_field.dof_values,
                scratch.unilateral_strain_offset,
                scratch.int_symmetric_strain,
                scratch.plastic_strain_delta_field.dof_values,
                scratch.stress_field.dof_values,
                scratch.velocity_field.dof_values,
                scratch.collider_matrix,
                scratch.transposed_collider_matrix,
                scratch.collider_friction,
                scratch.collider_adhesion,
                scratch.collider_normal_field.dof_values,
                scratch.collider_velocity,
                scratch.collider_inv_mass_matrix,
                scratch.impulse_field.dof_values,
                color_offsets=scratch.color_offsets,
                color_indices=scratch.color_indices,
                color_nodes_per_element=scratch.color_nodes_per_element,
                rigidity_operator=rigidity_operator,
                temporary_store=self.temporary_store,
                use_graph=self._use_cuda_graph,
            )

        if has_compliant_particles:
            wp.launch(
                average_elastic_strain_delta,
                dim=strain_node_count,
                inputs=[
                    scratch.int_symmetric_strain,
                    scratch.strain_node_particle_volume,
                    scratch.elastic_strain_delta_field.dof_values,
                ],
            )

        with self._timer("Save warmstart"):
            self._save_for_next_warmstart(scratch, last_step_data)

        return solve_graph

    def _update_particles(
        self,
        state_in: newton.State,
        state_out: newton.State,
        dt: float,
        pic: fem.PicQuadrature,
        scratch: ImplicitMPMScratchpad,
    ):
        """Update particle quantities (strains, velocities, ...) from grid fields an advect them."""

        model = self.model
        mpm_model = self._mpm_model

        has_compliant_particles = mpm_model.min_young_modulus < _INFINITY
        has_hardening = mpm_model.max_hardening > 0.0

        if has_compliant_particles or has_hardening:
            with self._timer("Particle strain update"):
                # Update particle elastic strain from grid strain delta
                fem.interpolate(
                    update_particle_strains,
                    at=pic,
                    values={
                        "dt": dt,
                        "particle_flags": model.particle_flags,
                        "young_modulus": model.mpm.young_modulus,
                        "poisson_ratio": model.mpm.poisson_ratio,
                        "damping": model.mpm.damping,
                        "hardening": model.mpm.hardening,
                        "friction": model.mpm.friction,
                        "yield_pressure": model.mpm.yield_pressure,
                        "tensile_yield_ratio": model.mpm.tensile_yield_ratio,
                        "yield_stress": model.mpm.yield_stress,
                        "elastic_strain_prev": state_in.mpm.particle_elastic_strain,
                        "elastic_strain": state_out.mpm.particle_elastic_strain,
                        "particle_Jp_prev": state_in.mpm.particle_Jp,
                        "particle_Jp": state_out.mpm.particle_Jp,
                    },
                    fields={
                        "grid_vel": scratch.velocity_field,
                        "plastic_strain_delta": scratch.plastic_strain_delta_field,
                        "elastic_strain_delta": scratch.elastic_strain_delta_field,
                    },
                    temporary_store=self.temporary_store,
                )

        # (A)PIC advection
        with self._timer("Advection"):
            fem.interpolate(
                advect_particles,
                at=pic,
                values={
                    "particle_flags": model.particle_flags,
                    "pos": state_out.particle_q,
                    "pos_prev": state_in.particle_q,
                    "vel": state_out.particle_qd,
                    "vel_grad": state_out.mpm.particle_qd_grad,
                    "dt": dt,
                    "max_vel": model.particle_max_velocity,
                },
                fields={
                    "grid_vel": scratch.velocity_field,
                },
                temporary_store=self.temporary_store,
            )

    def _save_data(
        self,
        state_in: newton.State,
        scratch: ImplicitMPMScratchpad,
        last_step_data: LastStepData,
        state_out: newton.State,
    ):
        """Save data for next step or further processing."""

        # Copy current body_q to last_step_data.body_q_prev for next step's velocity computation
        if state_in.body_q is not None and last_step_data.body_q_prev is not None:
            last_step_data.body_q_prev.assign(state_in.body_q)

        # Necessary fields for two-way coupling
        state_out.impulse_field = scratch.impulse_field
        state_out.collider_ids = scratch.collider_ids
        state_out.collider_position_field = scratch.collider_position_field
        state_out.collider_distance_field = scratch.collider_distance_field
        state_out.collider_normal_field = scratch.collider_normal_field

        # Necessary fields for grains rendering
        # Re-generated at each step, defined on space partition
        state_out.velocity_field = scratch.velocity_field

    def _require_velocity_space_fields(self, scratch: ImplicitMPMScratchpad, has_compliant_particles: bool):
        """Ensure velocity-space fields exist and match current spaces."""

        scratch.require_velocity_space_fields(has_compliant_particles)

    def _require_collision_space_fields(self, scratch: ImplicitMPMScratchpad, last_step_data: LastStepData):
        """Ensure collision-space fields exist and match current spaces."""
        scratch.require_collision_space_fields()

        # Impulse warmstarting, defined at space level
        if last_step_data.ws_impulse_field is None:
            last_step_data.ws_impulse_field = scratch.impulse_field.space.make_field()

        # Initialize body_q_prev on first step if needed (only if there are dynamic colliders)
        if self._mpm_model.collider_body_q is not None and (
            last_step_data.body_q_prev is None
            or last_step_data.body_q_prev.shape != self._mpm_model.collider_body_q.shape
        ):
            last_step_data.body_q_prev = wp.clone(self._mpm_model.collider_body_q)

    def _require_strain_space_fields(self, scratch: ImplicitMPMScratchpad, last_step_data: LastStepData):
        """Ensure strain-space fields exist and match current spaces."""
        scratch.require_strain_space_fields()

        # Stress warmstarting, define at space level
        if last_step_data.ws_stress_field is None:
            last_step_data.ws_stress_field = scratch.stress_field.space.make_field()

    def _warmstart_fields(self, scratch: ImplicitMPMScratchpad, last_step_data: LastStepData):
        """Interpolate previous grid fields into the current grid layout.

        Transfers impulse and stress fields from the previous grid to the new
        grid (handling nonconforming cases), and initializes the output state's
        grid fields to the current scratchpad fields.
        """

        prev_impulse_field = last_step_data.ws_impulse_field
        prev_stress_field = last_step_data.ws_stress_field

        domain = scratch.velocity_test.domain

        if isinstance(prev_impulse_field.space.basis, fem.PointBasisSpace):
            # point-based collisions, simply copy the previous impulses
            scratch.impulse_field.dof_values.assign(prev_impulse_field.dof_values)
        else:
            # Interpolate previous impulse
            prev_impulse_field = fem.NonconformingField(
                domain, prev_impulse_field, background=scratch.background_impulse_field
            )
            fem.interpolate(
                prev_impulse_field,
                dest=scratch.impulse_field,
                at=scratch.collider_fraction_test.space_restriction,
                reduction="first",
                temporary_store=self.temporary_store,
            )

        # Interpolate previous stress
        prev_stress_field = fem.NonconformingField(
            domain, prev_stress_field, background=scratch.background_stress_field
        )
        fem.interpolate(
            prev_stress_field,
            dest=scratch.stress_field,
            at=scratch.sym_strain_test.space_restriction,
            reduction="first",
            temporary_store=self.temporary_store,
        )

    @staticmethod
    def _save_for_next_warmstart(scratch: ImplicitMPMScratchpad, last_step_data: LastStepData):
        if last_step_data.ws_impulse_field.geometry != scratch.impulse_field.geometry:
            last_step_data.ws_impulse_field = scratch.impulse_field.space.make_field()

        if isinstance(last_step_data.ws_impulse_field.space.basis, fem.PointBasisSpace):
            # point-based collisions, simply copy the previous impulses
            last_step_data.ws_impulse_field.dof_values.assign(scratch.impulse_field.dof_values)
        else:
            last_step_data.ws_impulse_field.dof_values.zero_()
            wp.launch(
                scatter_field_dof_values,
                dim=scratch.impulse_field.space_partition.node_count(),
                inputs=[
                    scratch.impulse_field.space_partition.space_node_indices(),
                    scratch.impulse_field.dof_values,
                    last_step_data.ws_impulse_field.dof_values,
                ],
            )

        if last_step_data.ws_stress_field.geometry != scratch.stress_field.geometry:
            last_step_data.ws_stress_field = scratch.stress_field.space.make_field()

        last_step_data.ws_stress_field.dof_values.zero_()
        wp.launch(
            scatter_field_dof_values,
            dim=scratch.stress_field.space_partition.node_count(),
            inputs=[
                scratch.stress_field.space_partition.space_node_indices(),
                scratch.stress_field.dof_values,
                last_step_data.ws_stress_field.dof_values,
            ],
        )

    def _max_colors(self):
        if not self.coloring:
            return 0
        return 27 if self.strain_basis == "Q1" else 8

    def _compute_coloring(
        self,
        scratch: ImplicitMPMScratchpad,
    ):
        """Compute Gauss-Seidel coloring of strain nodes to avoid write conflicts.

        Writes scratch.color_offsets, scratch.color_indices and scratch.color_nodes_per_element.
        """

        space_partition = scratch._strain_space_restriction.space_partition
        grid = space_partition.geo_partition.geometry

        nodes_per_element = space_partition.space_topology.MAX_NODES_PER_ELEMENT
        is_dg = space_partition.space_topology.node_count() == nodes_per_element * grid.cell_count()

        if is_dg:
            # nodes in each element solved sequentially
            stencil_size = 2
            if isinstance(grid, fem.Nanogrid):
                voxels = grid._cell_ijk
                res = wp.vec3i(0)
            else:
                voxels = None
                res = grid.res
        elif self.strain_basis == "Q1":
            nodes_per_element = 1
            stencil_size = 3
            if isinstance(grid, fem.Nanogrid):
                voxels = grid._node_ijk
                res = wp.vec3i(0)
            else:
                voxels = None
                res = grid.res + wp.vec3i(1)
        else:
            raise RuntimeError("Unsupported strain basis for coloring")

        strain_node_count = space_partition.node_count()
        colored_element_count = strain_node_count // nodes_per_element
        colors = fem.borrow_temporary(self.temporary_store, shape=colored_element_count * 2 + 1, dtype=int)
        color_indices = scratch.color_indices
        space_node_indices = space_partition.space_node_indices()

        wp.launch(
            node_color,
            dim=colored_element_count,
            inputs=[
                space_node_indices,
                nodes_per_element,
                stencil_size,
                voxels,
                res,
                colors,
                color_indices,
            ],
        )

        wp.utils.radix_sort_pairs(
            keys=colors,
            values=color_indices,
            count=colored_element_count,
        )

        unique_colors = colors[colored_element_count:]
        color_count = unique_colors[colored_element_count:]
        color_node_counts = color_indices[colored_element_count:]

        wp.utils.runlength_encode(
            colors,
            value_count=colored_element_count,
            run_values=unique_colors,
            run_lengths=color_node_counts,
            run_count=color_count,
        )
        wp.launch(
            compute_color_offsets,
            dim=1,
            inputs=[self._max_colors(), color_count, unique_colors, color_node_counts, scratch.color_offsets],
        )

        scratch.color_nodes_per_element = nodes_per_element

        colors.release()

    def _timer(self, name: str):
        return wp.ScopedTimer(
            name,
            active=self._enable_timers,
            use_nvtx=self._timers_use_nvtx,
            synchronize=not self._timers_use_nvtx,
        )
