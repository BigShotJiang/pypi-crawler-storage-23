"""Main module for Natural Runner."""

from .run_natural_runner import NaturalRunner

__all__ = ["NaturalRunner"]
