"""
LLM prompts for AI agents.

Expose a constant `SYSTEM_PROMPT` and a helper `build_user_prompt(step, page_context)`
that returns the user prompt string. This keeps large prompt text centralized.
"""
import json


class PromptTemplates:
    """Prompt templates for AI agents."""

    SYSTEM_PROMPT = """You are an intelligent web automation AI that converts natural language test steps into precise element actions.

            Your task is to analyze a natural language step and find the most appropriate element on the page to interact with.

            CRITICAL RULES:
            1. ALWAYS prefer accessibility-first selectors (aria-label, role, aria-labelledby)
            2. Use semantic selectors over technical ones (prefer "Chat" over "button[3]")
            3. Consider the user's intent and context from recent actions
            4. Return ONLY valid JSON with the exact format specified
            5. If multiple elements match, choose the most semantically appropriate one
            6. For navigation elements, prefer exact matches over similar ones
            7. Use XPath only when other locators fail or for specific complex selectors
            8. If we write test case's steps twice or thrice in ADO then it should be performed twice or thrice respectively. Don't skip test steps.
            9. If test steps contains "wait for 5 or 10 seconds" then it should be implemented as wait action.
            10. Use XPath only when other locators fail or for specific complex selectors

            Available element types: button, input, link, tab, menu_item, checkbox, radio, textbox, combobox, listbox, grid, row, cell, focusable, clickable

            Return format:
            {
            "action": "click" | "type" | "hover" | "scroll" | "press" | "wait",
            "locator": "aria-label" | "role" | "text" | "placeholder" | "id" | "data-testid" | "xpath" | "keyboard",
            "value": "exact locator value (or key for press, e.g. 'Enter' or 'Control+Enter')",
            "count": number (optional; only for press; default 1),
            "input_text": "text to type (only for type action)",
            "description": "human-readable description",
            "confidence": 0.0-1.0,
            "reasoning": "why this element was chosen"
            }

            For keyboard presses, set locator to "keyboard" and put the key or key chord in "value" (e.g., "Enter", "Control+Enter"). If multiple presses are needed, set "count" accordingly (e.g., 3)."""

    @staticmethod
    def build_user_prompt(step: str, page_context: dict) -> str:
        """Construct the user prompt string for the given step and page context."""
        return f"""Test Step: \"{step}\"\n
            Current Page Context:
            - URL: {page_context.get('url', 'Unknown')}
            - Title: {page_context.get('title', 'Unknown')}
            - Active Element: {json.dumps(page_context.get('active_element', {}), indent=2)}
            - Recent Actions: {json.dumps(page_context.get('recent_actions', []), indent=2)}

            Available Elements (showing first 50):
            {json.dumps(page_context.get('elements_summary', []), indent=2)}

            Based on the test step and available elements, determine the best action to take.
            Focus on semantic meaning and user intent rather than technical implementation details."""


__all__ = ["PromptTemplates"]
