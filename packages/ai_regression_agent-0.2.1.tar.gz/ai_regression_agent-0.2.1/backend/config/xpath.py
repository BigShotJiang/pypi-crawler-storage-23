"""
XPath and Locator Constants for Family Safety Agent

This module centralizes all XPath selectors and element locators used across the application.
Consolidating selectors in one location improves maintainability and reduces duplication.
"""

# ============================================================================
# CLASS-BASED CONSTANTS
# ============================================================================

class XPathSelectors:
	"""XPath and related element IDs used by the agent."""

	# ========================================================================
	# LOGIN FLOW XPATHS
	# ========================================================================

	# Login verification - MS Child account card
	XPATH_MS_CHILD = "//span[contains(text(),'MS Child')]"

	# Sign-in button on landing page
	XPATH_SIGNIN_BUTTON = "//span[contains(text(),'Sign in to get started')]"

	# Alternate authentication flow - "Sign in another way" option
	XPATH_SIGNIN_ANOTHER_WAY = "//*[contains(text(),'Sign in another way')]"

	# Password authentication option
	XPATH_USE_PASSWORD = "//span[contains(text(),'Use your password')]"

	# "Stay signed in?" prompt - No button
	XPATH_NO_BUTTON = "//*[contains(text(),'No')]"

	# ========================================================================
	# FORM INPUT ID LOCATORS
	# ========================================================================

	# Username/email input field ID
	ID_USERNAME_ENTRY = "usernameEntry"

	# Password input field ID
	ID_PASSWORD_ENTRY = "passwordEntry"

	# ========================================================================
	# NAVIGATION XPATHS
	# ========================================================================

	# Apps navigation button in left sidebar
	XPATH_APPS_NAV = "//span[contains(text(), 'Apps')]"

	# ========================================================================
	# ACTION XPATHS
	# ========================================================================

	# Dynamic remove button with aria-label pattern "Remove <site> from this list"
	XPATH_REMOVE_BUTTON_DYNAMIC = "//button[starts-with(@aria-label, 'Remove ') and contains(@aria-label, ' from this list')]"
