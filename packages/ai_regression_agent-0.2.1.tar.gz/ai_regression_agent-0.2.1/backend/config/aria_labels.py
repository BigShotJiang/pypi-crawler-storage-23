"""
ARIA Label Constants for Family Safety Agent

This module centralizes all ARIA label values used for element identification.
ARIA labels provide accessible names for UI components and are often more stable
than text content or other selectors.
"""

# ============================================================================
# CLASS-BASED CONSTANTS
# ============================================================================

class AriaLabels:
	"""ARIA labels and related element IDs used by the agent."""

	# ========================================================================
	# BUTTON ARIA LABELS
	# ========================================================================

	# Chat button in sidebar with keyboard shortcut
	ARIA_CHAT_BUTTON = "Chat (Ctrl+Shift+2)"

	# Send button with keyboard shortcut (used in messaging/chat interfaces)
	ARIA_SEND_BUTTON = "Send (Ctrl+Enter)"

	# Generic Add button (used in various dialogs for adding items/apps)
	ARIA_ADD_BUTTON = "Add"

	# Close button (used for closing dialogs and modals)
	ARIA_CLOSE_BUTTON = "Close"

	# ========================================================================
	# WEBSITE MANAGEMENT ARIA LABELS
	# ========================================================================

	# Button to add a website to the block list
	ARIA_ADD_BLOCKED_WEBSITE = "Add a website you want to block"

	# Button to add a website to the allow list
	ARIA_ADD_ALLOWED_WEBSITE = "Add a website you want to allow"

	# ========================================================================
	# HTML ID CONSTANTS
	# ========================================================================

	# Email/username input field on login form
	ID_USERNAME_ENTRY = "usernameEntry"

	# Password input field on login form
	ID_PASSWORD_ENTRY = "passwordEntry"

	# Input field for adding allowed/always allowed websites
	ID_WEB_SEARCH_ALWAYS_ALLOWED_INPUT = "web-search-always-allowed-input"

	# Input field for adding blocked/never allowed websites
	ID_WEB_SEARCH_NEVER_ALLOWED_INPUT = "web-search-never-allowed-input"

