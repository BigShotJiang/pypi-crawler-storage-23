"""
IDC Family Safety backend package.

This package contains reusable components such as:
- agents (e.g. `ai_agents_web`, `web_agent`)
- services (e.g. `detailed_service`, `skip_service`, `tag_service`)
- integrations (e.g. `ado_integration`, `azure_blob`, email utilities)
- core utilities (e.g. logging, token_utils)
- utils (e.g. action builders, element extractors, page objects)
- reporting utilities

These modules are meant to be installed as a library and imported from other projects.
"""

