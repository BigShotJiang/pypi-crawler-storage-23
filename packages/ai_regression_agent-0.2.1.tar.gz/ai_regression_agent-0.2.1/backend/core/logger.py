"""
Logging utilities - re-exports from backend utils.
"""

import sys
from pathlib import Path

# Ensure backend utils is on path when running from various entry points
_backend_dir = Path(__file__).resolve().parent.parent.parent
if str(_backend_dir) not in sys.path:
    sys.path.insert(0, str(_backend_dir))

from .logging_config import (
    get_logger,
    log_info,
    log_error,
    log_warning,
    log_step,
    log_debug,
    setup_realtime_logging,
    LoggerUtils,
)

__all__ = [
    "get_logger",
    "log_info",
    "log_error",
    "log_warning",
    "log_step",
    "log_debug",
    "setup_realtime_logging",
    "LoggerUtils",
]
