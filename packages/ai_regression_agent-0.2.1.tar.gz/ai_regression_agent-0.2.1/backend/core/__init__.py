"""
AI Agent core utilities.
"""
