from transformers import GPT2Tokenizer

_TOKENIZER = GPT2Tokenizer.from_pretrained("gpt2")


def truncate_text_to_token_limit(text: str, max_tokens: int) -> str:
    """Truncate text to fit within the specified token limit."""
    tokens = _TOKENIZER.encode(text)
    if len(tokens) <= max_tokens:
        return text
    truncated_tokens = tokens[:max_tokens]
    return _TOKENIZER.decode(truncated_tokens)
