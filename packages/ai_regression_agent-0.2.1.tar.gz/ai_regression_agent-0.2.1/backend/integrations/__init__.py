"""
AI Agent Integrations - External service communication handlers.
Manages all third-party integrations (ADO, Azure Blob, Email, etc.)
"""

from .ado_integration import ADOIntegration, fetch_and_parse_test_cases
from .azure_blob import AzureBlobService, BlobStorageManager
from .email_service import (
    EmailService,
    send_client_email,
    send_internal_email,
)

__all__ = [
    "ADOIntegration",
    "AzureBlobService",
    "BlobStorageManager",
    "EmailService",
    "fetch_and_parse_test_cases",
    "send_client_email",
    "send_internal_email",
]
