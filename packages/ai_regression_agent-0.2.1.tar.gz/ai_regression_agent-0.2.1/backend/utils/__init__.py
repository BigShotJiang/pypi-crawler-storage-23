"""
Utils package for Family Safety Agent.

This package provides utilities for browser automation, page object models,
element finders, and action builders.
"""

from .page_objects import (
    BasePage,
    PageManager,
    ElementFinder,
    ClickableElementPage,
    FormPage,
    TogglePage,
    NavigationPage,
    DialogPage,
    ScrollPage,
    LinkPage,
)

from .element_extractor import ElementExtractor
from .reggex import RegexPatterns
from .action_builders import ActionBuilders
from .frames_handler import FramesHandler
from .click_type_actions import ClickTypeActions
from .helper import HelperUtils

__all__ = [
    # Page Objects
    "BasePage",
    "PageManager",
    # Backward Compatibility
    "ElementFinder",
    "ClickableElementPage",
    "FormPage",
    "TogglePage",
    "NavigationPage",
    "DialogPage",
    "ScrollPage",
    "LinkPage",
    # Element Extractor
    "ElementExtractor",
    # Regex Patterns
    "RegexPatterns",
    # Action Builders
    "ActionBuilders",
    "FramesHandler",
    "ClickTypeActions",
    "HelperUtils",
]
