"""
AI Agent implementations.
"""
