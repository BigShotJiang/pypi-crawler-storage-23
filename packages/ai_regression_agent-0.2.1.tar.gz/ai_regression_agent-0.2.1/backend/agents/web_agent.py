"""
Web AI agent - thin wrapper around the main AIAdhocWebAgent implementation.

This module allows imports like:
    from backend.agents.web_agent import AIAdhocWebAgent
    from aiagents.agents.web_agent import AIAdhocWebAgent
"""

from .ai_agents_web import AIAdhocWebAgent

__all__ = ["AIAdhocWebAgent"]
