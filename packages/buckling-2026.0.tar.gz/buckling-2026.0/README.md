Buckling handbook
=================

Documentation
-------------

The documentation is available on: https://saullocastro.github.io/buckling.

License
-------
Distrubuted under the 3-Clause BSD license
(https://raw.github.com/saullocastro/buckling/master/LICENSE).

Contact: S.G.P.Castro@tudelft.nl.

