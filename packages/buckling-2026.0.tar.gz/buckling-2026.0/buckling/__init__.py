r"""
==================================
buckling API (:mod:`buckling`)
==================================

.. currentmodule::buckling

The ``buckling`` module includes some useful functions shared amongst the different Python notebooks used in this Jupyter book.

"""
pass


