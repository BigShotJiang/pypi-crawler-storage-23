# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.1.1] - 2026-02-20

### Fixed

- Fixed CI wheel build failure on x86_64 targets.
- Fixed `maturin develop` in CI requiring a virtual environment.
- Fixed `cargo fmt` formatting issues.
- Fixed Python 3.9 compatibility (`str | None` syntax) — dropped 3.9, minimum is now Python 3.10.

## [0.1.0] - 2026-02-20

### Added

- **Marshall**: Convert regular JSON to DynamoDB JSON format (`S`, `N`, `BOOL`, `NULL`, `L`, `M`).
- **Unmarshall**: Convert DynamoDB JSON back to regular JSON. Supports all 10 DynamoDB type descriptors: `S`, `N`, `B`, `BOOL`, `NULL`, `L`, `M`, `SS`, `NS`, `BS`.
- **Property extraction**: Dot-path property access with wildcard (`*`) support for arrays.
- **Python bindings** via PyO3 — `marshall()`, `unmarshall()`, `get_property()`.
- **CLI** (`dynojson`) with `marshall`/`m` and `unmarshall`/`u` commands, `-g` property path option, stdin/file/string input.
- **Parallel processing** with Rayon for top-level arrays and objects.
- Multi-platform wheels: Linux (x86_64, aarch64), macOS (Apple Silicon), Windows (x86_64).
- Published to both [PyPI](https://pypi.org/project/dynojson/) and [crates.io](https://crates.io/crates/dynojson).

[Unreleased]: https://github.com/cykruss/dynojson/compare/v0.1.1...HEAD
[0.1.1]: https://github.com/cykruss/dynojson/compare/v0.1.0...v0.1.1
[0.1.0]: https://github.com/cykruss/dynojson/releases/tag/v0.1.0
