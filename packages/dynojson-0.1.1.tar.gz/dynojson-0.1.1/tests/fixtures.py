"""Test fixtures for dynojson tests — JSON strings for marshall/unmarshall."""

# ── Single object ───────────────────────────────────────────────────────────

UNMARSHALLED_OBJECT = (
    '{"object":{"array":["a","b","c"],"subobject":{"key1":"value1","key2":"value2"}},'
    '"number":1,"string":"string","boolean":true,"null":null}'
)

MARSHALLED_OBJECT = (
    '{"object":{"M":{"array":{"L":[{"S":"a"},{"S":"b"},{"S":"c"}]},'
    '"subobject":{"M":{"key1":{"S":"value1"},"key2":{"S":"value2"}}}}},'
    '"number":{"N":"1"},"string":{"S":"string"},"boolean":{"BOOL":true},"null":{"NULL":true}}'
)

# ── Array of DynamoDB Items (e.g. scan result) ─────────────────────────────

UNMARSHALLED_SCAN = (
    '[{"type":"fruit","foodItems":["apple","kiwi"]},'
    '{"type":"meat","foodItems":["beef","bacon"]}]'
)

MARSHALLED_SCAN = (
    '[{"type":{"S":"fruit"},"foodItems":{"L":[{"S":"apple"},{"S":"kiwi"}]}},'
    '{"type":{"S":"meat"},"foodItems":{"L":[{"S":"beef"},{"S":"bacon"}]}}]'
)

# ── Array of DynamoDB M-typed values ────────────────────────────────────────

UNMARSHALLED_ARRAY = (
    '[{"object":{"key1":"value1","key2":"value2"}},'
    '{"object":{"key3":"value3","key4":"value4"}}]'
)

MARSHALLED_ARRAY = (
    '[{"M":{"object":{"M":{"key1":{"S":"value1"},"key2":{"S":"value2"}}}}},'
    '{"M":{"object":{"M":{"key3":{"S":"value3"},"key4":{"S":"value4"}}}}}]'
)

# ── Array of DynamoDB L-typed values (array of arrays) ──────────────────────

UNMARSHALLED_ARRAY_ARRAYS = (
    '[[{"foo":"bar"},{"baz":"qux"}],[{"foo":"bar"},{"baz":"qux"}]]'
)

MARSHALLED_ARRAY_ARRAYS = (
    '[{"L":[{"M":{"foo":{"S":"bar"}}},{"M":{"baz":{"S":"qux"}}}]},'
    '{"L":[{"M":{"foo":{"S":"bar"}}},{"M":{"baz":{"S":"qux"}}}]}]'
)

# ── All DynamoDB types in a single Item ─────────────────────────────────────

MARSHALLED_ALL_TYPES = (
    '{"str":{"S":"hello"},"num":{"N":"42"},"bin":{"B":"AQID"},'
    '"bool":{"BOOL":false},"nul":{"NULL":true},'
    '"list":{"L":[{"S":"a"}]},"map":{"M":{"k":{"N":"1"}}},'
    '"ss":{"SS":["x","y"]},"ns":{"NS":["10","20"]},'
    '"bs":{"BS":["AQID","BAUG"]}'
    '}'
)

UNMARSHALLED_ALL_TYPES = (
    '{"str":"hello","num":42,"bin":"AQID",'
    '"bool":false,"nul":null,'
    '"list":["a"],"map":{"k":1},'
    '"ss":["x","y"],"ns":[10,20],'
    '"bs":["AQID","BAUG"]}'
)

# ── AWS CLI GetItem response (after -g "Item") ────────────────────────────

MARSHALLED_GET_ITEM = (
    '{"id":{"S":"user-123"},"name":{"S":"Alice"},"age":{"N":"30"},'
    '"active":{"BOOL":true},"tags":{"SS":["admin","dev"]},'
    '"scores":{"NS":["100","95.5"]},'
    '"profile":{"M":{"avatar":{"B":"aW1hZ2U="},"bio":{"S":"Engineer"}}}}'
)

UNMARSHALLED_GET_ITEM = (
    '{"id":"user-123","name":"Alice","age":30,'
    '"active":true,"tags":["admin","dev"],'
    '"scores":[100,95.5],'
    '"profile":{"avatar":"aW1hZ2U=","bio":"Engineer"}}'
)
