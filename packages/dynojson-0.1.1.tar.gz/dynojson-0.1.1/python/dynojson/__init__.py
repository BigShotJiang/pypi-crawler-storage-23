"""
dynojson — Marshall/unmarshall JSON to/from DynamoDB JSON format.

Powered by a Rust core via PyO3 for maximum performance.

Functions
---------
marshall(json_str) -> str
    Convert a regular JSON string to DynamoDB JSON format.

unmarshall(json_str) -> str
    Convert a DynamoDB JSON string to regular JSON format.

get_property(json_str, path) -> str
    Extract a nested property from a JSON string by dot-separated path.
    Supports ``*`` wildcard to expand array items.
"""

from ._dynojson import __version__, get_property, marshall, unmarshall

__all__ = ["marshall", "unmarshall", "get_property", "__version__"]
