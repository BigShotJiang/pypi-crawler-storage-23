#!/usr/bin/python

"""
gitaura produces a simple commit visualisation for a git repository.

gitaura is a Python utility that uses 'git log'
to produce a simple bar graph visualisation for
commit activity in a git repository.

Licensed under the MIT License.
"""

import os
import sys
import argparse
import datetime
from subprocess import check_output, DEVNULL
from collections import OrderedDict, namedtuple, Counter, defaultdict

try:
    import pkg_resources
    __version__ = pkg_resources.require("gitaura")[0].version
except Exception:
    __version__ = "0.0.0"


Item = namedtuple(
    "Item", ["timestamp", "is_weekend", "author", "commits", "score"])
Item.__new__.__defaults__ = (None, False, "none", 0, 0)


def print_bars(items, block=u"\u2580", width=50):
    """Print unicode bar representations of dates and scores."""
    for i in items:
        num = str(items[i].commits)

        sys.stdout.write(i)
        sys.stdout.write("  ")
        sys.stdout.write(num)
        sys.stdout.write((5 - len(num)) * " ")

        # Colour the weekend bars.
        if items[i].is_weekend:
            sys.stdout.write("\033[94m")

        sys.stdout.write(block * int(items[i].score * width))

        if items[i].is_weekend:
            sys.stdout.write("\x1b[0m")

        sys.stdout.write("\n")


def filter(items, periodicity="day", author=""):
    """Filter entries by periodicity and author."""
    bars = OrderedDict()

    for i in items:
        # Extract the day/month/year part of the date.
        d = i.timestamp
        if periodicity == "week":
            label = d.strftime("%Y/%V")
        elif periodicity == "month":
            label = d.strftime("%Y-%m")
        elif periodicity == "year":
            label = d.strftime("%Y")
        else:
            label = d.strftime("%Y-%m-%d %a")

        # Filter by author.
        if author != "":
            if author not in i.author:
                continue

        if label not in bars:
            bars[label] = Item(*i)
        else:
            bars[label] = bars[label]._replace(
                commits=bars[label].commits + i.commits)

    return bars


def get_scores(items):
    """Compute normalized scores (0-1) for commit numbers."""
    vals = [items[i].commits for i in items]
    vals.append(0)

    xmin = min(vals)
    xmax = max(vals)

    # Normalize.
    out = OrderedDict()
    for i in items:
        out[i] = Item(
            *(items[i]))._replace(score=normalize(items[i].commits, xmin, xmax))

    return out


def get_log(after, before, reverse=False, fill=False):
    """Return the list of git log from the git log command."""
    # 2018-01-01 00:00:00|author@author.com
    args = ["git", "log", "--pretty=format:%ai|%ae", "--reverse"]

    if after:
        args.append("--after=%s" % (after,))
    if before:
        args.append("--before=%s" % (before,))

    items = []
    for o in check_output(args, universal_newlines=True, shell=False).split("\n"):
        c = o.split("|")
        t = datetime.datetime.strptime(c[0], "%Y-%m-%d %H:%M:%S %z")
        items.append(
            Item(timestamp=t, author=c[1], is_weekend=t.weekday() > 4, commits=1))

    if fill:
        fill_dates(items)

    if not reverse:
        items.reverse()

    return items


def normalize(x, xmin, xmax):
    """Normalize a number to a 0-1 range given a min and max of its set."""
    return float(x - xmin) / float(xmax - xmin)


def fill_dates(data):
    """Fill missing dates where there were no commits."""
    n = len(data)
    i = 0
    while i < n - 1:
        cur = data[i].timestamp
        if (data[i+1].timestamp - cur).days > 1:
            data.insert(i+1, Item(
                timestamp=cur + datetime.timedelta(days=1),
                is_weekend=cur.weekday() > 4
            ))
            n += 1
        i += 1


def get_file_breakdown(after="", before="", author=""):
    """Get file type breakdown from git log (counts each file change per commit)."""
    args = ["git", "log", "--format=", "--name-only"]

    if after:
        args.append("--after=%s" % (after,))
    if before:
        args.append("--before=%s" % (before,))
    if author:
        args.append("--author=%s" % (author,))

    output = check_output(args, universal_newlines=True, shell=False)
    counts = Counter()

    for line in output.split("\n"):
        line = line.strip()
        if not line:
            continue
        ext = os.path.splitext(line)[1]
        if ext:
            counts[ext.lstrip(".").upper()] += 1
        else:
            counts["(none)"] += 1

    return dict(counts)


def print_file_breakdown(counts, block=u"\u2580", width=40):
    """Print file type breakdown as percentages with bar visualization."""
    total = sum(counts.values())
    if total == 0:
        print("No files to breakdown")
        return

    # Sort by count descending
    sorted_items = sorted(counts.items(), key=lambda x: -x[1])

    print("%d file changes by type:\n" % total)
    for ext, count in sorted_items:
        pct = 100.0 * count / total
        bar_len = int(pct / 100.0 * width)
        num = str(count)
        pct_str = "%5.1f%%" % pct
        sys.stdout.write("%-8s %6s %4s " % (ext, num, pct_str))
        sys.stdout.write(block * bar_len)
        sys.stdout.write("\n")


def get_file_stats(after="", before="", author=""):
    """
    Get per-file stats from git log --numstat.
    Returns: (file_churn, file_contributors, file_refactor_lines, total_refactor, total_churn)
    - file_churn: dict path -> (additions, deletions, commits)
    - file_contributors: dict path -> set of author emails
    - file_refactor_lines: dict path -> (refactor_lines, total_lines) for density
    - total_refactor, total_churn: repo-level refactor density
    """
    args = ["git", "log", "--numstat", "--format=%H|%ae"]
    if after:
        args.append("--after=%s" % after)
    if before:
        args.append("--before=%s" % before)
    if author:
        args.append("--author=%s" % author)

    out = check_output(args, universal_newlines=True, shell=False)
    file_churn = defaultdict(lambda: [0, 0, 0])  # adds, dels, commits
    file_contributors = defaultdict(set)
    file_refactor = defaultdict(lambda: [0, 0])  # refactor_lines, total_lines
    total_refactor = 0
    total_churn = 0

    current_author = ""
    for line in out.split("\n"):
        line = line.rstrip()
        if "|" in line and not line[0].isdigit() and "-" not in line[:3]:
            parts = line.split("|", 1)
            if len(parts) == 2:
                current_author = parts[1].strip()
            continue
        if not line.strip():
            continue
        parts = line.split("\t", 2)
        if len(parts) < 3:
            continue
        add_s, del_s, path = parts[0], parts[1], parts[2].strip()
        if not path:
            continue
        try:
            adds = int(add_s) if add_s != "-" else 0
            dels = int(del_s) if del_s != "-" else 0
        except ValueError:
            continue
        churn = adds + dels
        if churn == 0:
            continue

        file_churn[path][0] += adds
        file_churn[path][1] += dels
        file_churn[path][2] += 1
        file_contributors[path].add(current_author)
        refactor_lines = 2 * min(adds, dels)
        file_refactor[path][0] += refactor_lines
        file_refactor[path][1] += churn
        total_refactor += refactor_lines
        total_churn += churn

    return (dict(file_churn), dict(file_contributors), dict(file_refactor),
            total_refactor, total_churn)


def get_file_churn_ranking(after="", before="", author=""):
    """Return list of (path, adds, dels, commits) sorted by churn (adds+dels) desc."""
    file_churn, _, _, _, _ = get_file_stats(after, before, author)
    result = []
    for path, (adds, dels, commits) in file_churn.items():
        result.append((path, adds, dels, commits))
    return sorted(result, key=lambda x: -(x[1] + x[2]))


def print_file_churn(churn_list, limit=25, block=u"\u2580", width=40):
    """Print file churn ranking."""
    if not churn_list:
        print("No file changes to rank")
        return
    total_churn = sum(adds + dels for _, adds, dels, _ in churn_list)
    print("File churn ranking (most modified, %d total lines changed):\n" % total_churn)
    vals = [adds + dels for _, adds, dels, _ in churn_list]
    xmin, xmax = min(vals), max(vals)
    for path, adds, dels, commits in churn_list[:limit]:
        churn = adds + dels
        score = normalize(churn, xmin, xmax) if xmax > xmin else 1.0
        bar_len = int(score * width)
        sys.stdout.write("%-45s %6d (+%d -%d) " % (path[:45], churn, adds, dels))
        sys.stdout.write(block * bar_len)
        sys.stdout.write("\n")
    if len(churn_list) > limit:
        print("\n... and %d more files" % (len(churn_list) - limit))


def get_hotspots(after="", before="", author="", min_churn=50):
    """Return list of (path, churn, contributors, score) for hotspot files."""
    file_churn, file_contributors, _, _, _ = get_file_stats(after, before, author)
    result = []
    churns = [sum(c[0:2]) for c in file_churn.values()]
    max_churn = max(churns) if churns else 1
    max_contrib = max(len(s) for s in file_contributors.values()) if file_contributors else 1

    for path in file_churn:
        adds, dels, _ = file_churn[path]
        churn = adds + dels
        contribs = len(file_contributors.get(path, set()))
        if churn < min_churn:
            continue
        churn_norm = churn / max_churn if max_churn else 0
        contrib_norm = contribs / max_contrib if max_contrib else 0
        score = churn_norm * (0.5 + 0.5 * contrib_norm)
        result.append((path, churn, contribs, score))
    return sorted(result, key=lambda x: -x[3])


def print_hotspots(hotspots, limit=20, block=u"\u2580", width=30):
    """Print hotspot files (high churn + high contributor count)."""
    print("Hotspot detection (high churn + many contributors):\n")
    if not hotspots:
        print("No hotspots found")
        return
    scores = [h[3] for h in hotspots]
    xmin, xmax = min(scores), max(scores)
    for path, churn, contribs, score in hotspots[:limit]:
        bar_len = int(normalize(score, xmin, xmax) * width) if xmax > xmin else width
        sys.stdout.write("%-45s churn:%5d  authors:%2d " % (path[:45], churn, contribs))
        sys.stdout.write(block * bar_len)
        sys.stdout.write("\n")
    if len(hotspots) > limit:
        print("\n... and %d more" % (len(hotspots) - limit))


def get_refactor_density(after="", before="", author=""):
    """Return (overall_density, per_file_list) for refactor density estimation."""
    _, _, file_refactor, total_refactor, total_churn = get_file_stats(after, before, author)
    overall = total_refactor / total_churn if total_churn else 0.0
    per_file = []
    for path, (refactor, churn) in file_refactor.items():
        if churn > 0:
            density = refactor / churn
            per_file.append((path, refactor, churn, density))
    per_file.sort(key=lambda x: -x[3])
    return overall, per_file


def print_refactor_density(overall, per_file, limit=15, block=u"\u2580", width=40):
    """Print refactor density estimation."""
    print("Refactor density (balanced add/del ≈ refactoring):\n")
    print("Overall: %.1f%% of changes are refactor-like (add ≈ del)\n" % (overall * 100))
    if not per_file:
        print("No file-level data")
        return
    print("Top files by refactor density:\n")
    for path, refactor, churn, density in per_file[:limit]:
        pct = 100 * density
        bar_len = int(density * width)
        sys.stdout.write("%-45s %5.0f%% " % (path[:45], pct))
        sys.stdout.write(block * bar_len)
        sys.stdout.write("  (%d / %d lines)\n" % (refactor, churn))
    if len(per_file) > limit:
        print("\n... and %d more" % (len(per_file) - limit))


def get_main_branch():
    """Detect main branch (main or master)."""
    for candidate in ["main", "master"]:
        try:
            check_output(
                ["git", "rev-parse", "--verify", candidate],
                universal_newlines=True, shell=False, stderr=DEVNULL
            )
            return candidate
        except Exception:
            continue
    return None


# --- Branch features ---

def get_active_branches():
    """Return branches ranked by most recent commit (name, date)."""
    fmt = "%(refname:short)\t%(committerdate:iso8601)"
    out = check_output(
        ["git", "for-each-ref", "--sort=-committerdate",
         "--format=" + fmt, "refs/heads/"],
        universal_newlines=True, shell=False
    )
    result = []
    for line in out.strip().split("\n"):
        if not line:
            continue
        parts = line.split("\t", 1)
        if len(parts) == 2:
            name, date_str = parts
            try:
                dt = datetime.datetime.fromisoformat(
                    date_str.replace("Z", "+00:00")[:19])
                result.append((name, dt))
            except ValueError:
                result.append((name, None))
    return result


def print_active_branches(branches, limit=20):
    """Print active branches ranked by recency."""
    print("Active branches (most recent first):\n")
    now = datetime.datetime.now()
    for i, (name, dt) in enumerate(branches[:limit]):
        if dt:
            d = dt.replace(tzinfo=None) if dt.tzinfo else dt
            age = now - d
            days = age.days
            if days == 0:
                rel = "today"
            elif days == 1:
                rel = "1 day ago"
            else:
                rel = "%d days ago" % days
            sys.stdout.write("%-40s %s\n" % (name, rel))
        else:
            sys.stdout.write("%s\n" % name)
    if len(branches) > limit:
        print("\n... and %d more" % (len(branches) - limit))


def get_stale_branches(stale_days=30):
    """Return branches with no commits in the last stale_days days."""
    branches = get_active_branches()
    cutoff = datetime.datetime.now() - datetime.timedelta(days=stale_days)
    cutoff_naive = cutoff.replace(tzinfo=None) if cutoff.tzinfo else cutoff
    stale = []
    for name, dt in branches:
        if dt:
            d = dt.replace(tzinfo=None) if dt.tzinfo else dt
            if d < cutoff_naive:
                stale.append((name, dt))
        else:
            stale.append((name, None))
    return stale


def print_stale_branches(branches, stale_days):
    """Print stale branches."""
    print("Stale branches (no commits in %d+ days):\n" % stale_days)
    if not branches:
        print("None")
        return
    for name, dt in branches:
        if dt:
            age = datetime.datetime.now() - (dt.replace(tzinfo=None) if dt.tzinfo else dt)
            sys.stdout.write("%-40s %d days\n" % (name, age.days))
        else:
            sys.stdout.write("%s\n" % name)


def get_branch_divergence(base_branch):
    """Return list of (branch, ahead, behind) for each branch."""
    branches = check_output(
        ["git", "for-each-ref", "--format=%(refname:short)", "refs/heads/"],
        universal_newlines=True, shell=False
    ).strip().split("\n")
    branches = [b.strip() for b in branches if b.strip() and b.strip() != base_branch]

    result = []
    for branch in branches:
        try:
            out = check_output(
                ["git", "rev-list", "--left-right", "--count",
                 "%s...%s" % (base_branch, branch)],
                universal_newlines=True, shell=False
            ).strip()
            ahead, behind = map(int, out.split())
            result.append((branch, ahead, behind))
        except Exception:
            result.append((branch, None, None))
    return result


def print_branch_divergence(divergence, base_branch):
    """Print ahead/behind summary."""
    print("Branch divergence vs '%s' (ahead / behind):\n" % base_branch)
    for branch, ahead, behind in sorted(divergence, key=lambda x: (-(x[1] or 0), x[0])):
        if ahead is not None and behind is not None:
            sys.stdout.write("%-40s +%d / -%d\n" % (branch, ahead, behind))
        else:
            sys.stdout.write("%-40s (unable to compare)\n" % branch)


def get_branch_lifetimes(base_branch):
    """Return (branch, created_at, merged_at, days) for merged branches."""
    try:
        out = check_output(
            ["git", "log", "--merges", "--first-parent", base_branch,
             "--format=%H %ai %P"],
            universal_newlines=True, shell=False
        )
    except Exception:
        return []

    result = []
    for line in out.strip().split("\n"):
        if not line.strip():
            continue
        parts = line.split(None, 3)
        if len(parts) < 4:
            continue
        merge_hash, merge_date_str, p1, p2 = parts[0], parts[1], parts[2], parts[3]
        try:
            merged_at = datetime.datetime.strptime(
                merge_date_str[:19], "%Y-%m-%d %H:%M:%S")
        except ValueError:
            continue
        merge_base = check_output(
            ["git", "merge-base", p1, p2],
            universal_newlines=True, shell=False
        ).strip()
        branch_name = check_output(
            ["git", "name-rev", "--name-only", p2],
            universal_newlines=True, shell=False
        ).strip().split("~")[0].split("^")[0].strip()
        if "/" in branch_name:
            branch_name = branch_name.split("/")[-1]
        try:
            first_commit = check_output(
                ["git", "log", "--reverse", "--format=%ai", "%s..%s" % (merge_base, p2)],
                universal_newlines=True, shell=False
            ).strip().split("\n")[0]
            if not first_commit:
                continue
            created_at = datetime.datetime.strptime(
                first_commit[:19], "%Y-%m-%d %H:%M:%S")
            days = (merged_at - created_at).days
            result.append((branch_name, created_at, merged_at, days))
        except Exception:
            continue
    return result


def print_branch_lifetimes(lifetimes):
    """Print branch creation to merge duration."""
    print("Branch lifetime (creation → merge):\n")
    if not lifetimes:
        print("No merged branches found")
        return
    for name, created, merged, days in sorted(lifetimes, key=lambda x: -x[3]):
        sys.stdout.write("%-35s %3d days  (%s → %s)\n" % (
            name, days,
            created.strftime("%Y-%m-%d"),
            merged.strftime("%Y-%m-%d")))


def get_merge_timeline(after="", before="", periodicity="month"):
    """Return merge counts per period."""
    args = ["git", "log", "--merges", "--pretty=format:%ai"]
    if after:
        args.append("--after=%s" % after)
    if before:
        args.append("--before=%s" % before)

    out = check_output(args, universal_newlines=True, shell=False)
    counts = OrderedDict()
    for line in out.strip().split("\n"):
        if not line:
            continue
        try:
            t = datetime.datetime.strptime(line[:19], "%Y-%m-%d %H:%M:%S")
            if periodicity == "week":
                label = t.strftime("%Y/%V")
            elif periodicity == "day":
                label = t.strftime("%Y-%m-%d %a")
            elif periodicity == "year":
                label = t.strftime("%Y")
            else:
                label = t.strftime("%Y-%m")
            counts[label] = counts.get(label, 0) + 1
        except ValueError:
            continue
    return counts


def print_merge_timeline(counts, block=u"\u2580", width=40):
    """Print merge frequency timeline."""
    total = sum(counts.values())
    if total == 0:
        print("No merges to plot")
        return
    print("%d merges by period:\n" % total)
    vals = list(counts.values()) + [0]
    xmin, xmax = min(vals), max(vals)
    for label in sorted(counts.keys()):
        n = counts[label]
        score = normalize(n, xmin, xmax) if xmax > xmin else 1.0
        bar_len = int(score * width)
        sys.stdout.write("%-20s %3d " % (label, n))
        sys.stdout.write(block * bar_len)
        sys.stdout.write("\n")


def get_merge_timeline_events(base_branch=None, after="", before=""):
    """Return list of (date, branch_name, merge_hash) for each merge event."""
    args = ["git", "log", "--merges", "--format=%H %ai %P"]
    if base_branch:
        args.extend(["--first-parent", base_branch])  # merges into base_branch
    if after:
        args.append("--after=%s" % after)
    if before:
        args.append("--before=%s" % before)

    try:
        out = check_output(args, universal_newlines=True, shell=False)
    except Exception:
        return []

    result = []
    for line in out.strip().split("\n"):
        if not line.strip():
            continue
        parts = line.split(None, 3)
        if len(parts) < 4:
            continue
        merge_hash, date_str, p1, p2 = parts[0], parts[1], parts[2], parts[3]
        try:
            merged_at = datetime.datetime.strptime(date_str[:19], "%Y-%m-%d %H:%M:%S")
        except ValueError:
            continue
        branch_name = check_output(
            ["git", "name-rev", "--name-only", p2],
            universal_newlines=True, shell=False
        ).strip().split("~")[0].split("^")[0].strip()
        if "/" in branch_name:
            branch_name = branch_name.split("/")[-1]
        result.append((merged_at, branch_name, merge_hash))
    return result


def print_merge_timeline_view(events, base_branch, limit=50, block=u"\u2580", width=30):
    """Print timeline view of branch merges (date + branch name)."""
    base = base_branch or "HEAD"
    into = "into %s" % base if base else "all merges"
    print("Merge timeline (%s):\n" % into)
    if not events:
        print("No merges found")
        return
    total = len(events)
    max_w = max(len(e[1]) for e in events) if events else 20
    for merged_at, branch_name, _ in events[:limit]:
        date_str = merged_at.strftime("%Y-%m-%d %H:%M")
        sys.stdout.write("%s  %-*s  " % (date_str, max(min(max_w, 35), 15), branch_name))
        sys.stdout.write(block)
        sys.stdout.write("\n")
    if total > limit:
        print("\n... and %d more merges" % (total - limit))


def compare_branches(branch_a, branch_b):
    """
    Compare two branches statistically.
    Returns: dict with commits_a, commits_b, ahead, behind, files_changed, adds, dels, authors
    """
    result = {"branch_a": branch_a, "branch_b": branch_b}
    try:
        out = check_output(
            ["git", "rev-list", "--left-right", "--count", "%s...%s" % (branch_a, branch_b)],
            universal_newlines=True, shell=False
        ).strip().split()
        result["commits_only_a"] = int(out[0])
        result["commits_only_b"] = int(out[1])
    except Exception:
        result["commits_only_a"] = result["commits_only_b"] = None

    merge_base = ""
    try:
        merge_base = check_output(
            ["git", "merge-base", branch_a, branch_b],
            universal_newlines=True, shell=False
        ).strip()
    except Exception:
        pass

    if merge_base:
        try:
            diff_out = check_output(
                ["git", "diff", "--numstat", "%s..%s" % (merge_base, branch_b)],
                universal_newlines=True, shell=False
            )
            adds = dels = 0
            files = 0
            for line in diff_out.strip().split("\n"):
                if not line:
                    continue
                parts = line.split("\t", 2)
                if len(parts) >= 2:
                    try:
                        a = int(parts[0]) if parts[0] != "-" else 0
                        d = int(parts[1]) if parts[1] != "-" else 0
                        adds += a
                        dels += d
                        files += 1
                    except ValueError:
                        pass
            result["files_changed"] = files
            result["additions"] = adds
            result["deletions"] = dels
        except Exception:
            result["files_changed"] = result["additions"] = result["deletions"] = None

        try:
            auth_out = check_output(
                ["git", "shortlog", "-sne", "%s..%s" % (merge_base, branch_b)],
                universal_newlines=True, shell=False
            )
            authors = set()
            for line in auth_out.strip().split("\n"):
                if "\t" in line:
                    authors.add(line.split("\t", 1)[1].strip())
            result["authors"] = len(authors)
        except Exception:
            result["authors"] = None
    else:
        result["files_changed"] = result["additions"] = result["deletions"] = result["authors"] = None

    return result


def print_branch_compare(stats):
    """Print two-branch comparison."""
    a, b = stats["branch_a"], stats["branch_b"]
    print("Branch comparison: %s vs %s\n" % (a, b))
    print("%-25s %10s %10s" % ("", a, b))
    print("-" * 50)
    ca, cb = stats["commits_only_a"], stats["commits_only_b"]
    if ca is not None and cb is not None:
        print("%-25s %10d %10d" % ("Commits (unique)", ca, cb))
    if stats.get("files_changed") is not None:
        print("%-25s %10s %10d" % ("Files changed (in %s)" % b, "", stats["files_changed"]))
    if stats.get("additions") is not None:
        print("%-25s %10s %10d" % ("Lines added (in %s)" % b, "", stats["additions"]))
    if stats.get("deletions") is not None:
        print("%-25s %10s %10d" % ("Lines deleted (in %s)" % b, "", stats["deletions"]))
    if stats.get("authors") is not None:
        print("%-25s %10s %10d" % ("Authors (in %s)" % b, "", stats["authors"]))
    if ca is not None and cb is not None:
        print("\nSummary: %s has %d commits not in %s; %s has %d commits not in %s" %
              (a, ca, b, b, cb, a))


def get_work_map(after="", before="", author=""):
    """
    'Where do I work most?' - directory/path breakdown by commit activity.
    Returns: dict of dir_path -> (commits, churn) for top-level dirs and nested.
    """
    args = ["git", "log", "--numstat", "--format=%H|%ae"]
    if after:
        args.append("--after=%s" % after)
    if before:
        args.append("--before=%s" % before)
    if author:
        args.append("--author=%s" % author)

    out = check_output(args, universal_newlines=True, shell=False)
    dir_edits = defaultdict(int)
    dir_churn = defaultdict(lambda: [0, 0])

    current_author = ""
    for line in out.split("\n"):
        line = line.rstrip()
        if "|" in line and not line[0].isdigit() and "-" not in line[:3]:
            parts = line.split("|", 1)
            if len(parts) == 2:
                current_author = parts[1].strip()
            continue
        if not line.strip():
            continue
        parts = line.split("\t", 2)
        if len(parts) < 3:
            continue
        add_s, del_s, path = parts[0], parts[1], parts[2].strip()
        if not path:
            continue
        try:
            adds = int(add_s) if add_s != "-" else 0
            dels = int(del_s) if del_s != "-" else 0
        except ValueError:
            continue

        dirs = []
        head = ""
        for part in path.split("/"):
            head = head + part + "/" if head else part + "/"
            dirs.append(head.rstrip("/"))
        for d in dirs:
            dir_edits[d] += 1
        for d in dirs:
            dir_churn[d][0] += adds
            dir_churn[d][1] += dels

    combined = []
    for d in set(dir_edits.keys()) | set(dir_churn.keys()):
        edits = dir_edits.get(d, 0)
        churn = dir_churn.get(d, [0, 0])
        total_churn = churn[0] + churn[1]
        combined.append((d, edits, total_churn))

    combined.sort(key=lambda x: -(x[1] + x[2]))
    return combined


def print_work_map(work_data, limit=20, block=u"\u2580", width=40):
    """Print 'Where do I work most?' directory map."""
    print("Where do I work most? (by directory)\n")
    if not work_data:
        print("No activity")
        return
    total_commits = sum(x[1] for x in work_data)
    total_churn = sum(x[2] for x in work_data)
    max_val = max(x[1] + x[2] for x in work_data) if work_data else 1
    for path, commits, churn in work_data[:limit]:
        score = (commits + churn) / max_val if max_val else 0
        bar_len = int(score * width)
        depth = path.count("/") + 1
        indent = "  " * (depth - 1)
        disp = path if len(path) <= 45 else "..." + path[-42:]
        sys.stdout.write("%s%-45s %4d edits  %5d lines  " % (indent, disp[:45], commits, churn))
        sys.stdout.write(block * bar_len)
        sys.stdout.write("\n")
    print("\n(edits = file touches, lines = adds+dels)")


def main():
    """Commandline entry point."""
    p = argparse.ArgumentParser(description="Shows git commit count bars. "
                                "Weekends are coloured. (version " + __version__ + ")")
    p.add_argument("-p", "--periodicity", action="store", dest="periodicity",
                   type=str, required=False, default="month",
                   choices=["day", "week", "month", "year"])

    p.add_argument("-u", "--author", action="store", dest="author",
                   type=str, required=False, default="",
                   help="filter by author's e-mail (substring)")

    p.add_argument("-a", "--after", action="store", dest="after",
                   type=str, required=False, default="",
                   help="after date (yyyy-mm-dd hh:mm)")

    p.add_argument("-b", "--before", action="store", dest="before",
                   type=str, required=False, default="",
                   help="before date (yyyy-mm-dd hh:mm)")

    p.add_argument("-r", "--reverse", action="store", dest="reverse",
                   type=bool, required=False, default=False,
                   help="reverse date order")

    p.add_argument("-f", "--fill", action="store", dest="fill",
                   type=bool, required=False, default=False,
                   help="fill dates (with no commits) on the graph")

    p.add_argument("--files", action="store_true", dest="files",
                   help="show file type breakdown (%% JS, TS, MD, etc.)")
    p.add_argument("--churn", action="store_true", dest="churn",
                   help="file churn ranking (most modified files)")
    p.add_argument("--hotspots", action="store_true", dest="hotspots",
                   help="hotspot detection (high churn + high contributor count)")
    p.add_argument("--refactor", action="store_true", dest="refactor",
                   help="refactor density estimation")
    p.add_argument("--min-churn", action="store", type=int, default=50,
                   dest="min_churn", help="minimum churn for hotspots (default: 50)")

    p.add_argument("--branches", action="store_true", dest="branches",
                   help="active branches ranked by recency")
    p.add_argument("--stale", action="store_true", dest="stale",
                   help="detect stale branches (no commits in N days)")
    p.add_argument("--stale-days", action="store", type=int, default=30,
                   dest="stale_days", help="days threshold for stale (default: 30)")
    p.add_argument("--divergence", action="store_true", dest="divergence",
                   help="branch divergence summary (ahead/behind vs main)")
    p.add_argument("--branch-lifetime", action="store_true", dest="branch_lifetime",
                   help="branch lifetime (creation → merge duration)")
    p.add_argument("--merges", action="store_true", dest="merges",
                   help="merge frequency timeline")
    p.add_argument("--merge-timeline", action="store_true", dest="merge_timeline",
                   help="timeline view of branch merges (date + branch name)")
    p.add_argument("--compare", action="store", dest="compare", nargs=2, metavar=("A", "B"),
                   help="compare two branches statistically")
    p.add_argument("--work-map", action="store_true", dest="work_map",
                   help="'where do I work most?' directory map")
    p.add_argument("--main", action="store", dest="main_branch",
                   type=str, default="", help="main branch for divergence/lifetime/merge-timeline (default: main or master)")

    args = p.parse_args()

    """Invoke the utility."""
    if args.files:
        try:
            counts = get_file_breakdown(args.after, args.before, args.author)
            print_file_breakdown(counts)
        except Exception as e:
            print("error running 'git log': %s" % (e,))
        return

    if args.churn:
        try:
            churn_list = get_file_churn_ranking(args.after, args.before, args.author)
            print_file_churn(churn_list)
        except Exception as e:
            print("error: %s" % (e,))
        return

    if args.hotspots:
        try:
            hotspots = get_hotspots(args.after, args.before, args.author, args.min_churn)
            print_hotspots(hotspots)
        except Exception as e:
            print("error: %s" % (e,))
        return

    if args.refactor:
        try:
            overall, per_file = get_refactor_density(args.after, args.before, args.author)
            print_refactor_density(overall, per_file)
        except Exception as e:
            print("error: %s" % (e,))
        return

    if args.branches:
        try:
            branches = get_active_branches()
            print_active_branches(branches)
        except Exception as e:
            print("error: %s" % (e,))
        return

    if args.stale:
        try:
            branches = get_stale_branches(args.stale_days)
            print_stale_branches(branches, args.stale_days)
        except Exception as e:
            print("error: %s" % (e,))
        return

    if args.divergence:
        try:
            base = args.main_branch or get_main_branch()
            if not base:
                print("error: no main branch (use --main to specify)")
                return
            divergence = get_branch_divergence(base)
            print_branch_divergence(divergence, base)
        except Exception as e:
            print("error: %s" % (e,))
        return

    if args.branch_lifetime:
        try:
            base = args.main_branch or get_main_branch()
            if not base:
                print("error: no main branch (use --main to specify)")
                return
            lifetimes = get_branch_lifetimes(base)
            print_branch_lifetimes(lifetimes)
        except Exception as e:
            print("error: %s" % (e,))
        return

    if args.merges:
        try:
            counts = get_merge_timeline(args.after, args.before, args.periodicity)
            print_merge_timeline(counts)
        except Exception as e:
            print("error: %s" % (e,))
        return

    if args.merge_timeline:
        try:
            base = args.main_branch or get_main_branch() or ""
            events = get_merge_timeline_events(base, args.after, args.before)
            print_merge_timeline_view(events, base or "HEAD")
        except Exception as e:
            print("error: %s" % (e,))
        return

    if args.compare:
        try:
            a, b = args.compare
            stats = compare_branches(a, b)
            print_branch_compare(stats)
        except Exception as e:
            print("error: %s" % (e,))
        return

    if args.work_map:
        try:
            work_data = get_work_map(args.after, args.before, args.author)
            print_work_map(work_data)
        except Exception as e:
            print("error: %s" % (e,))
        return

    items = []
    try:
        items = get_log(args.after, args.before, args.reverse, args.fill)
    except Exception as e:
        print("error running 'git log': %s" % (e,))
        return

    filtered = filter(items, args.periodicity, args.author)

    scores = get_scores(filtered)
    if scores:
        print("%d commits over %d %s(s)" %
              (sum([filtered[f].commits for f in filtered]),
               len(scores),
               args.periodicity))
        print_bars(scores)
    else:
        print("No commits to plot")


if __name__ == "__main__":
    main()