# gitaura

A Python CLI for git repository analytics. Visualize commit activity, analyze file churn, explore branch history, and discover where you work most—all from the terminal.

## Installation

```bash
pip install gitaura
```

```
248 commits over 12 month(s)
2024-01     12 ▀▀▀▀▀
2024-02     28 ▀▀▀▀▀▀▀▀▀▀▀▀▀
2024-03     45 ▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀
...
```

---

## Commands

### Commit Activity

| Command    | Description                                          |
| ---------- | ---------------------------------------------------- |
| (default)  | Bar chart of commits by period (day/week/month/year) |
| `-p day`   | Daily granularity                                    |
| `-p week`  | Weekly (ISO week)                                    |
| `-p month` | Monthly (default)                                    |
| `-p year`  | Yearly                                               |
| `-f`       | Fill missing dates with zero-commit bars             |

### File Analysis

| Command         | Description                                        |
| --------------- | -------------------------------------------------- |
| `--files`       | File type breakdown (% JS, TS, MD, etc.)           |
| `--churn`       | File churn ranking (most modified files)           |
| `--hotspots`    | Hotspot detection (high churn + many contributors) |
| `--refactor`    | Refactor density (balanced add/del ≈ refactoring)  |
| `--min-churn N` | Minimum churn for hotspots (default: 50)           |

### Branch Analysis

| Command             | Description                                                          |
| ------------------- | -------------------------------------------------------------------- |
| `--branches`        | Active branches ranked by recency                                    |
| `--stale`           | Stale branches (no commits in N days)                                |
| `--stale-days N`    | Staleness threshold (default: 30)                                    |
| `--divergence`      | Ahead/behind counts vs main                                          |
| `--branch-lifetime` | Creation → merge duration for merged branches                        |
| `--merges`          | Merge frequency timeline (aggregated)                                |
| `--merge-timeline`  | Timeline of branch merges (date + branch name)                       |
| `--compare A B`     | Compare two branches statistically                                   |
| `--main BRANCH`     | Main branch for divergence/lifetime/merges (default: main or master) |

### Activity Map

| Command      | Description                                      |
| ------------ | ------------------------------------------------ |
| `--work-map` | “Where do I work most?” — directory activity map |

---

## Global Options

Apply to most commands:

| Option               | Description                        |
| -------------------- | ---------------------------------- |
| `-a, --after DATE`   | After date (e.g. `2024-01-01`)     |
| `-b, --before DATE`  | Before date                        |
| `-u, --author EMAIL` | Filter by author (substring match) |

---

## Examples

**Commit bars by week, filtered by author**

```bash
gitaura -p week -u "alice@company.com"
```

**File type breakdown for 2024**

```bash
gitaura --files -a 2024-01-01 -b 2024-12-31
```

**Most modified files**

```bash
gitaura --churn
```

**Hotspots — high churn and many contributors**

```bash
gitaura --hotspots --min-churn 100
```

**Refactor vs feature density**

```bash
gitaura --refactor
```

**Stale branches (no activity in 60 days)**

```bash
gitaura --stale --stale-days 60
```

**Branch divergence from main**

```bash
gitaura --divergence
```

**Compare main and feature branch**

```bash
gitaura --compare main feature-branch
gitaura --compare main origin/feature-branch
```

**Where do I work most?**

```bash
gitaura --work-map
gitaura --work-map -u "me@email.com"
```

**Merge timeline**

```bash
gitaura --merge-timeline
```

---

## Output Notes

- **Weekend bars** are colored blue in commit activity view.
- **Churn** = lines added + lines deleted per file.
- **Refactor density** uses “balanced” edits (adds ≈ dels) as a proxy for refactoring.
- **Hotspots** combine churn and contributor count; files with both rank higher.
- **Work map** shows directories by edit count and lines changed; hierarchy is indented.

---

## License

MIT
