class SDocMarkup:
    RST = "RST"
    HTML = "HTML"
    TEXT = "Text"

    ALL = {RST, HTML, TEXT}
