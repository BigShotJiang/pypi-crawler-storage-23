"""cPanel adapter — filesystem-based inspection of cPanel user environments.

URI scheme: cpanel://USERNAME[/element]

Elements:
    (none)          Overview: domains, SSL status summary, nginx config presence
    domains         List addon domains with docroots and home directory
    ssl             S2 disk-cert health per domain from /var/cpanel/ssl/apache_tls/
    acl-check       N1 nobody ACL health per domain docroot

All operations are filesystem-based; no WHM API or authentication required.
Must be run as root (or with read access to /var/cpanel/userdata/).

Examples:
    reveal cpanel://USERNAME                  # Overview
    reveal cpanel://USERNAME/domains          # All domains + docroots
    reveal cpanel://USERNAME/ssl              # Disk cert health per domain
    reveal cpanel://USERNAME/acl-check        # nobody ACL on all docroots
"""

import os
import re
import socket
from typing import Dict, Any, Optional, List

from ..base import ResourceAdapter, register_adapter, register_renderer
from .renderer import CpanelRenderer


# cPanel filesystem paths
CPANEL_USERDATA_DIR = "/var/cpanel/userdata"
CPANEL_SSL_DIR = "/var/cpanel/ssl/apache_tls"
NGINX_USER_CONF_DIR = "/etc/nginx/conf.d/users"


def _parse_cpanel_userdata(path: str) -> Dict[str, str]:
    """Parse a cPanel userdata file (YAML-ish key: value format).

    cPanel userdata files are a simple key: value format (not full YAML).
    Each line is either blank, a comment, or `key: value`.

    Returns:
        Dict of directive name → value.
    """
    result: Dict[str, str] = {}
    try:
        with open(path, 'r', encoding='utf-8', errors='replace') as fh:
            for line in fh:
                line = line.rstrip()
                if not line or line.startswith('#') or line.startswith('-'):
                    continue
                m = re.match(r'^(\w+):\s*(.*)', line)
                if m:
                    result[m.group(1)] = m.group(2).strip()
    except OSError:
        pass
    return result


def _list_user_domains(username: str) -> List[Dict[str, str]]:
    """Read /var/cpanel/userdata/USERNAME/ and return domain entries.

    Each file in this directory represents one domain (or subdomain).
    Files ending in `_SSL` are the SSL vhost duplicates — we skip them.
    The `main` file describes the account itself (not a domain); skipped.

    Returns:
        List of dicts with keys: domain, docroot, serveralias, type
        type is one of: main_domain | addon | subdomain | parked
    """
    userdata_dir = os.path.join(CPANEL_USERDATA_DIR, username)
    if not os.path.isdir(userdata_dir):
        return []

    entries = []
    for fname in sorted(os.listdir(userdata_dir)):
        # Skip non-domain files
        if fname in ('main', 'nobody') or fname.endswith('_SSL'):
            continue
        fpath = os.path.join(userdata_dir, fname)
        if not os.path.isfile(fpath):
            continue

        data = _parse_cpanel_userdata(fpath)
        domain = data.get('domain', fname)
        docroot = data.get('documentroot', '')
        serveralias = data.get('serveralias', '')
        # heuristic type detection
        dom_type = data.get('type', '')
        if not dom_type:
            if fname == username or '.' not in fname:
                dom_type = 'main_domain'
            elif fname.count('.') >= 2 and not fname.startswith('www.'):
                dom_type = 'subdomain'
            else:
                dom_type = 'addon'

        entries.append({
            'domain': domain,
            'docroot': docroot,
            'serveralias': serveralias,
            'type': dom_type,
        })
    return entries


def _get_disk_cert_status(domain: str) -> Dict[str, Any]:
    """Load cPanel disk cert for domain and return status dict.

    Returns dict with: status ('ok'|'missing'|'expired'|'expiring'|'error'),
    days_until_expiry, not_after (str), serial_number.
    """
    cert_path = os.path.join(CPANEL_SSL_DIR, domain, 'combined')
    if not os.path.exists(cert_path):
        return {'status': 'missing', 'cert_path': cert_path}

    try:
        from ..ssl.certificate import load_certificate_from_file
        leaf, _ = load_certificate_from_file(cert_path)
        days = leaf.days_until_expiry
        if days < 0:
            status = 'expired'
        elif days < 7:
            status = 'critical'
        elif days < 30:
            status = 'expiring'
        else:
            status = 'ok'
        return {
            'status': status,
            'cert_path': cert_path,
            'days_until_expiry': days,
            'not_after': leaf.not_after.strftime('%Y-%m-%d'),
            'serial_number': leaf.serial_number,
            'common_name': leaf.common_name,
        }
    except Exception as exc:
        return {'status': 'error', 'cert_path': cert_path, 'error': str(exc)[:80]}


def _check_docroot_acl(docroot: str) -> Dict[str, Any]:
    """Check that nobody user has read+execute access to docroot path components.

    Delegates to the nginx analyzer's _check_nobody_access utility.
    """
    from ...analyzers.nginx import _check_nobody_access
    return _check_nobody_access(docroot)


def _dns_resolves(domain: str) -> bool:
    """Return True if domain resolves in DNS, False if NXDOMAIN or lookup error."""
    try:
        socket.getaddrinfo(domain, None)
        return True
    except socket.gaierror:
        return False


@register_adapter('cpanel')
@register_renderer(CpanelRenderer)
class CpanelAdapter(ResourceAdapter):
    """Adapter for inspecting cPanel user environments via cpanel:// URIs.

    Usage:
        reveal cpanel://USERNAME              # Overview
        reveal cpanel://USERNAME/domains      # List domains + docroots
        reveal cpanel://USERNAME/ssl          # Disk cert health per domain
        reveal cpanel://USERNAME/acl-check    # nobody ACL on all docroots
    """

    def __init__(self, connection_string: str = ""):
        if not connection_string:
            raise TypeError("CpanelAdapter requires a connection string: cpanel://USERNAME")

        self.connection_string = connection_string
        self.username: str = ''
        self.element: Optional[str] = None

        self._parse_connection_string(connection_string)

    def _parse_connection_string(self, uri: str) -> None:
        """Parse cpanel://USERNAME[/element] URI."""
        if not uri.startswith('cpanel://'):
            raise ValueError(f"Invalid cpanel:// URI: {uri}")

        rest = uri[len('cpanel://'):]
        parts = rest.split('/', 1)
        self.username = parts[0]
        self.element = parts[1].rstrip('/') if len(parts) > 1 else None

        if not self.username:
            raise ValueError("cpanel:// URI requires a username: cpanel://USERNAME")

    def _get_domains(self) -> List[Dict[str, str]]:
        return _list_user_domains(self.username)

    def get_structure(self, dns_verified: bool = False, **kwargs) -> Dict[str, Any]:
        """Get cPanel user overview or element data."""
        if self.element:
            if self.element == 'domains':
                return self._get_domains_structure()
            elif self.element == 'ssl':
                return self._get_ssl_structure(dns_verified=dns_verified)
            elif self.element == 'acl-check':
                return self._get_acl_structure()
            else:
                raise ValueError(
                    f"Unknown cpanel:// element '{self.element}'. "
                    f"Valid: domains, ssl, acl-check"
                )
        return self._get_overview_structure()

    def _userdata_dir_exists(self) -> bool:
        return os.path.isdir(os.path.join(CPANEL_USERDATA_DIR, self.username))

    def _get_overview_structure(self) -> Dict[str, Any]:
        """Overview: domain count, SSL summary, nginx config presence."""
        domains = self._get_domains()
        ssl_summary = {'ok': 0, 'expiring': 0, 'critical': 0, 'expired': 0,
                       'missing': 0, 'error': 0}

        for d in domains:
            status = _get_disk_cert_status(d['domain'])['status']
            ssl_summary[status] = ssl_summary.get(status, 0) + 1

        nginx_conf = os.path.join(NGINX_USER_CONF_DIR, f'{self.username}.conf')
        nginx_present = os.path.exists(nginx_conf)

        userdata_dir = os.path.join(CPANEL_USERDATA_DIR, self.username)
        userdata_ok = os.path.isdir(userdata_dir)

        next_steps = [
            f"reveal cpanel://{self.username}/domains    # All domains + docroots",
            f"reveal cpanel://{self.username}/ssl        # Cert health per domain",
            f"reveal cpanel://{self.username}/acl-check  # nobody ACL on docroots",
        ]
        if nginx_present:
            next_steps.append(
                f"reveal {nginx_conf} --validate-nginx-acme"
                f"  # Full ACME audit"
            )

        return {
            'contract_version': '1.0',
            'type': 'cpanel_user',
            'username': self.username,
            'userdata_dir': userdata_dir,
            'userdata_accessible': userdata_ok,
            'domain_count': len(domains),
            'nginx_config': nginx_conf if nginx_present else None,
            'ssl_summary': ssl_summary,
            'next_steps': next_steps,
        }

    def _get_domains_structure(self) -> Dict[str, Any]:
        """List all domains with docroots and type."""
        domains = self._get_domains()
        return {
            'contract_version': '1.0',
            'type': 'cpanel_domains',
            'username': self.username,
            'domain_count': len(domains),
            'domains': domains,
        }

    def _get_ssl_structure(self, dns_verified: bool = False) -> Dict[str, Any]:
        """Disk cert health per domain."""
        domains = self._get_domains()
        certs = []
        for d in domains:
            status = _get_disk_cert_status(d['domain'])
            entry: Dict[str, Any] = {
                'domain': d['domain'],
                **status,
            }
            if dns_verified:
                entry['dns_resolves'] = _dns_resolves(d['domain'])
            certs.append(entry)

        # Sort: failures first, then expiring, then ok
        _ORDER = {'expired': 0, 'critical': 1, 'error': 2, 'expiring': 3,
                  'missing': 4, 'ok': 5}
        certs.sort(key=lambda r: (_ORDER.get(r['status'], 9), r['domain']))

        # Build summary: with --dns-verified, exclude NXDOMAIN domains from counts
        summary: Dict[str, int] = {}
        dns_excluded: Dict[str, int] = {}
        for c in certs:
            s = c['status']
            if dns_verified and not c.get('dns_resolves', True):
                dns_excluded[s] = dns_excluded.get(s, 0) + 1
            else:
                summary[s] = summary.get(s, 0) + 1

        return {
            'contract_version': '1.0',
            'type': 'cpanel_ssl',
            'username': self.username,
            'cpanel_ssl_dir': CPANEL_SSL_DIR,
            'cert_count': len(certs),
            'dns_verified': dns_verified,
            'summary': summary,
            'dns_excluded': dns_excluded,
            'certs': certs,
            'next_steps': [
                f"reveal cpanel://{self.username}/acl-check  # Check docroot ACL",
                f"reveal {os.path.join(NGINX_USER_CONF_DIR, self.username + '.conf')}"
                f" --cpanel-certs  # Compare disk vs live",
            ],
        }

    def _get_acl_structure(self) -> Dict[str, Any]:
        """nobody ACL health per domain docroot."""
        domains = self._get_domains()
        acl_results = []
        for d in domains:
            docroot = d['docroot']
            if docroot:
                acl = _check_docroot_acl(docroot)
                acl_results.append({
                    'domain': d['domain'],
                    'docroot': docroot,
                    'acl_status': acl.get('status', 'unknown'),
                    'acl_detail': acl,
                })
            else:
                acl_results.append({
                    'domain': d['domain'],
                    'docroot': '',
                    'acl_status': 'no_docroot',
                    'acl_detail': {},
                })

        summary: dict[str, int] = {}
        for r in acl_results:
            s = r['acl_status']
            summary[s] = summary.get(s, 0) + 1

        has_failures = any(r['acl_status'] == 'denied' for r in acl_results)

        return {
            'contract_version': '1.0',
            'type': 'cpanel_acl',
            'username': self.username,
            'domain_count': len(acl_results),
            'summary': summary,
            'has_failures': has_failures,
            'domains': acl_results,
            'next_steps': [
                f"reveal cpanel://{self.username}/ssl  # Check cert status",
                f"reveal {os.path.join(NGINX_USER_CONF_DIR, self.username + '.conf')}"
                f" --check-acl  # Full nginx ACL check",
            ],
        }

    def get_element(self, element_name: str, **kwargs: Any) -> Optional[Dict[str, Any]]:
        """Not used — element routing handled in get_structure."""
        return None

    @staticmethod
    def get_schema() -> Dict[str, Any]:
        """Machine-readable schema for AI agent integration."""
        return {
            'adapter': 'cpanel',
            'description': 'Inspect cPanel user environments — domains, SSL certs, ACL health',
            'uri_syntax': 'cpanel://USERNAME[/element]',
            'query_params': {
                '--dns-verified': 'Exclude NXDOMAIN domains from SSL summary counts',
            },
            'elements': {
                '(none)': 'Overview: domain count, SSL summary, nginx config path',
                'domains': 'All addon/subdomain domains with docroots and type',
                'ssl': 'Disk cert health per domain from /var/cpanel/ssl/apache_tls/',
                'acl-check': 'nobody ACL status on every domain docroot',
            },
            'cli_flags': ['--format=json', '--dns-verified'],
            'supports_batch': False,
            'output_types': [
                {
                    'type': 'cpanel_user',
                    'description': 'Overview of a cPanel user — domain count, SSL summary, nginx config presence',
                    'triggered_by': 'cpanel://USERNAME (no element)',
                    'schema': {
                        'type': 'object',
                        'properties': {
                            'type': {'type': 'string', 'const': 'cpanel_user'},
                            'username': {'type': 'string'},
                            'userdata_dir': {'type': 'string'},
                            'userdata_accessible': {'type': 'boolean'},
                            'domain_count': {'type': 'integer'},
                            'nginx_config': {'type': ['string', 'null']},
                            'ssl_summary': {
                                'type': 'object',
                                'description': 'Counts keyed by status: ok/expiring/critical/expired/missing/error',
                            },
                            'next_steps': {'type': 'array', 'items': {'type': 'string'}},
                        },
                    },
                },
                {
                    'type': 'cpanel_domains',
                    'description': 'All domains for a cPanel user with docroots and type',
                    'triggered_by': 'cpanel://USERNAME/domains',
                    'schema': {
                        'type': 'object',
                        'properties': {
                            'type': {'type': 'string', 'const': 'cpanel_domains'},
                            'username': {'type': 'string'},
                            'domain_count': {'type': 'integer'},
                            'domains': {
                                'type': 'array',
                                'items': {
                                    'type': 'object',
                                    'properties': {
                                        'domain': {'type': 'string'},
                                        'docroot': {'type': 'string'},
                                        'type': {'type': 'string', 'enum': ['main', 'addon', 'subdomain']},
                                    },
                                },
                            },
                        },
                    },
                },
                {
                    'type': 'cpanel_ssl',
                    'description': 'Disk cert health per domain — sorted by severity (failures first)',
                    'triggered_by': 'cpanel://USERNAME/ssl',
                    'schema': {
                        'type': 'object',
                        'properties': {
                            'type': {'type': 'string', 'const': 'cpanel_ssl'},
                            'username': {'type': 'string'},
                            'cpanel_ssl_dir': {'type': 'string'},
                            'cert_count': {'type': 'integer'},
                            'dns_verified': {'type': 'boolean'},
                            'summary': {
                                'type': 'object',
                                'description': 'Counts keyed by status: ok/expiring/critical/expired/missing/error',
                            },
                            'dns_excluded': {
                                'type': 'object',
                                'description': 'Counts of NXDOMAIN-excluded domains by status (only when dns_verified=true)',
                            },
                            'certs': {
                                'type': 'array',
                                'items': {
                                    'type': 'object',
                                    'properties': {
                                        'domain': {'type': 'string'},
                                        'status': {
                                            'type': 'string',
                                            'enum': ['ok', 'expiring', 'critical', 'expired', 'missing', 'error'],
                                        },
                                        'expiry_days': {'type': ['number', 'null']},
                                        'dns_resolves': {'type': 'boolean', 'description': 'Only present when dns_verified=true'},
                                    },
                                },
                            },
                            'next_steps': {'type': 'array', 'items': {'type': 'string'}},
                        },
                    },
                },
                {
                    'type': 'cpanel_acl',
                    'description': 'nobody ACL status on every domain docroot — required for ACME renewal',
                    'triggered_by': 'cpanel://USERNAME/acl-check',
                    'schema': {
                        'type': 'object',
                        'properties': {
                            'type': {'type': 'string', 'const': 'cpanel_acl'},
                            'username': {'type': 'string'},
                            'domain_count': {'type': 'integer'},
                            'has_failures': {'type': 'boolean'},
                            'summary': {
                                'type': 'object',
                                'description': 'Counts keyed by acl_status: ok/denied/no_docroot/unknown',
                            },
                            'domains': {
                                'type': 'array',
                                'items': {
                                    'type': 'object',
                                    'properties': {
                                        'domain': {'type': 'string'},
                                        'docroot': {'type': 'string'},
                                        'acl_status': {
                                            'type': 'string',
                                            'enum': ['ok', 'denied', 'no_docroot', 'unknown'],
                                        },
                                        'acl_detail': {'type': 'object'},
                                    },
                                },
                            },
                            'next_steps': {'type': 'array', 'items': {'type': 'string'}},
                        },
                    },
                },
            ],
        }

    @staticmethod
    def get_help() -> Dict[str, Any]:
        """Help documentation for the cpanel:// adapter."""
        return {
            'name': 'cpanel',
            'description': 'Inspect cPanel user environments — domains, SSL certs, ACL health',
            'stability': 'beta',
            'syntax': 'cpanel://USERNAME[/element]',
            'features': [
                'Filesystem-based — no WHM API or credentials required',
                'Overview: domain count, SSL summary, nginx config path',
                'Domain listing with docroots and type (addon/subdomain/main)',
                'Disk cert health from /var/cpanel/ssl/apache_tls/ (S2)',
                'nobody ACL check on every domain docroot (N1)',
                'JSON output for scripting',
                'Composable with nginx:// commands for full operator audits',
            ],
            'examples': [
                {
                    'uri': 'reveal cpanel://USERNAME',
                    'description': 'Overview: domain count, SSL summary, nginx config path',
                },
                {
                    'uri': 'reveal cpanel://USERNAME/domains',
                    'description': 'All domains with docroots and type (addon/subdomain/main)',
                },
                {
                    'uri': 'reveal cpanel://USERNAME/ssl',
                    'description': 'Disk cert health per SSL domain',
                },
                {
                    'uri': 'reveal cpanel://USERNAME/acl-check',
                    'description': 'nobody ACL check on every domain docroot (required for ACME renewal)',
                },
                {
                    'uri': 'reveal cpanel://USERNAME/ssl --format=json',
                    'description': 'JSON output for scripting',
                },
            ],
            'elements': {
                '(none)': 'Overview: domain count, SSL summary, nginx config path',
                'domains': 'All addon/subdomain domains with docroots and type',
                'ssl': 'Disk cert health per domain from /var/cpanel/ssl/apache_tls/',
                'acl-check': 'nobody ACL status on every domain docroot',
            },
            'workflows': [
                {
                    'name': 'Full cPanel User SSL Audit',
                    'description': 'Complete SSL and ACL health check for a user',
                    'steps': [
                        'reveal cpanel://USERNAME                    # Overview',
                        'reveal cpanel://USERNAME/acl-check          # ACL health',
                        'reveal cpanel://USERNAME/ssl                # Disk cert health',
                        'reveal /etc/nginx/conf.d/users/USERNAME.conf --validate-nginx-acme  # Composed audit',
                        'reveal /etc/nginx/conf.d/users/USERNAME.conf --cpanel-certs         # Disk vs live',
                        'reveal /etc/nginx/conf.d/users/USERNAME.conf --diagnose             # Error log audit',
                    ],
                },
            ],
            'notes': [
                'Must run as root or with read access to /var/cpanel/userdata/',
                'All operations are filesystem-based — no WHM API or network access',
                'nginx commands use plain file paths (e.g. reveal /etc/nginx/conf.d/users/USERNAME.conf)',
                'Use --validate-nginx-acme for the single-command "would have caught this" audit',
                'cpanel ACL check is filesystem-based (authoritative); nginx ACME audit also verifies config routing — use both',
            ],
            'see_also': [
                'reveal help://ssl - SSL certificate inspection',
                'reveal /etc/nginx/conf.d/users/USERNAME.conf --check-acl - N1 ACL check',
                'reveal /etc/nginx/conf.d/users/USERNAME.conf --validate-nginx-acme - Full ACME+ACL+SSL audit',
                'reveal /etc/nginx/conf.d/users/USERNAME.conf --cpanel-certs - Disk vs live cert compare',
                'reveal /etc/nginx/conf.d/users/USERNAME.conf --diagnose - Error log ACME/SSL audit',
            ],
        }
