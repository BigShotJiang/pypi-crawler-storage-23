from openalerts.dashboard.server import DashboardServer

__all__ = ["DashboardServer"]
