from openalerts.cli import main

main()
