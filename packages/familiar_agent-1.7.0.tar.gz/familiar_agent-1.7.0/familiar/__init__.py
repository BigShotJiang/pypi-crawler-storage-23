"""Familiar - Self-Hosted AI Companion Platform"""

__version__ = "1.7.0"
