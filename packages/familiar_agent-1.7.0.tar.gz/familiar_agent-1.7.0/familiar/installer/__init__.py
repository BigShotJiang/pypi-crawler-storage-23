# Familiar - Self-Hosted AI Companion Platform
# Copyright (c) 2026 George Scott Foley
# ORCID: 0009-0006-4957-0540
# Email: Georgescottfoley@proton.me
# Licensed under the MIT License - see LICENSE file for details

"""
Familiar Installer Package

Cross-platform GUI installer for Familiar.

Components:
    wizard.py          - Setup wizard GUI (Tkinter)
    build_installer.py - Build script for executables

Usage:
    # Run wizard directly
    python -m familiar.installer.wizard

    # Build distributable executable
    python -m familiar.installer.build_installer
"""

__version__ = "2.0.0"
