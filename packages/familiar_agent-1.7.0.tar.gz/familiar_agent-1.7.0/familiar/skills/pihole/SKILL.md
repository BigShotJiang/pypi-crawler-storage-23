# Pi-hole / AdGuard Home

Monitor and control your DNS-level ad blocker.

## Setup
Set `PIHOLE_URL` and `PIHOLE_TOKEN` environment variables. Optionally set `PIHOLE_TYPE` to `adguard` for AdGuard Home (defaults to `pihole`).

## Tools
- `pihole_get_stats` -- Get blocking statistics summary
- `pihole_top_queries` -- Show top queries and blocked domains
- `pihole_toggle_blocking` -- Enable or disable blocking (requires confirmation)
- `pihole_get_status` -- Check if blocking is enabled
- `pihole_query_log` -- View recent DNS queries
