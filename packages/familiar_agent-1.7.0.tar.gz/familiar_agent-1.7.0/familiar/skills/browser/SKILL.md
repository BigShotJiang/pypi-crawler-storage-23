# Browser Automation Skill

Control a web browser to navigate sites, fill forms, download files, and scrape content.

## Usage

Use this skill when the user wants to:
- Log into a website or portal
- Download documents (grant reports, donor exports, etc.)
- Fill out online forms
- Check information on websites
- Scrape/extract data from web pages
- Take screenshots of pages

## Important

- Browser runs headless by default (no visible window)
- Can handle JavaScript-heavy sites
- Stores cookies/sessions between runs for staying logged in
- Screenshots saved to ~/.pi_agent/data/screenshots/

## Security Notes

- Login credentials should be stored securely (environment variables or keyring)
- The agent will ask for confirmation before submitting forms with sensitive data
- Sessions are isolated per site

## Examples

"Log into the foundation portal and download our grant report"
"Check the donor database for recent gifts"
"Fill out the volunteer signup form for Jane Smith"
"Take a screenshot of our analytics dashboard"
"What's on our organization's calendar for next week?"
