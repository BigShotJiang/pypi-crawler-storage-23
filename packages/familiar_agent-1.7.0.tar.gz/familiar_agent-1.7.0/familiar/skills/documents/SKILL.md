# Documents Skill

Generate professional documents from natural language. Thank-you letters,
board reports, grant narratives, receipts, newsletters, memos.

## Usage

Use this skill when the user wants to:
- Draft a letter, report, receipt, memo, or newsletter
- Create a document from a template with provided data (mail merge)
- Export or convert between DOCX, PDF, and Markdown formats
- List or manage available document templates

## Template System

Templates are stored in ~/.familiar/templates/ as JSON schema files defining
layout, fields, and defaults. Pre-built templates ship for:
- Donor thank-you letter
- Donation receipt (IRS-compliant)
- Board report
- Grant narrative
- Meeting agenda
- Newsletter
- Memo

## Letterhead

Place organization logo at ~/.familiar/templates/letterhead.png.
The document skill auto-inserts it in headers. Organization name,
address, and EIN are pulled from config.yaml.

## Output

Files are saved to ~/.familiar/documents/ with date-based naming.
The agent provides the file path for download via dashboard or email attachment.

## Cross-Skill Integration

- **nonprofit**: donors_needing_thanks triggers create_letter. Grants link to docs.
- **bookkeeping**: generate_receipt creates formatted PDF via this skill.
- **reports**: All reports output as formatted DOCX/PDF.
- **meetings**: Agendas and minutes generated as DOCX/PDF.
