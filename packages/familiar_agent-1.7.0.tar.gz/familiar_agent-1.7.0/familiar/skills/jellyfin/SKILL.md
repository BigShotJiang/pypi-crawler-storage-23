# Jellyfin

Manage and browse your Jellyfin media server.

## Setup
Set `JELLYFIN_URL`, `JELLYFIN_TOKEN`, and `JELLYFIN_USER_ID` environment variables.

## Tools
- `jf_search_media` -- Search for media items
- `jf_now_playing` -- Show currently playing sessions
- `jf_play_media` -- Start playing media on a session (requires confirmation)
- `jf_get_library` -- Browse a library's contents
- `jf_list_users` -- List Jellyfin users
