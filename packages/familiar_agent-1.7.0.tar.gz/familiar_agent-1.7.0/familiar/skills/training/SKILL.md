# Training Data Skill

Self-curating pipeline for proprietary model training data with full provenance tracking.

## Features

- **Conversation Curation**: Extracts instruction/response pairs from chat history, scores quality with heuristics (no LLM needed), and saves to JSONL
- **Tool Call Curation**: Converts analytics tool call events into synthetic training examples
- **Content Generation**: Two-step original content authoring (how-to, FAQ, tutorials, etc.)
- **Dataset Export**: Exports in Alpaca, ShareGPT, and OpenAI fine-tuning formats
- **Provenance Tracking**: Every curated example carries author, license, consent, and timestamp metadata
- **Incremental Processing**: Watermark-based — only processes new data since last run

## Usage

- "Curate my training data" — extract and score conversation pairs
- "Curate tool call data" — build examples from analytics events
- "Generate training content about task management" — author original Q&A pairs
- "Show training stats" — view curated example counts and quality distribution
- "List training data" — browse individual curated examples
- "Export training dataset in alpaca format" — produce a fine-tuning-ready JSONL file

## Quality Scoring

All heuristic-based, runs fast on CPU:
- Response length (longer = more informative)
- Instruction substance (rejects trivial single-word messages)
- Error response penalty
- PII detection penalty (email, phone, SSN patterns)
- Tool call presence bonus
- Keyword coherence between instruction and response

## Data Layout

```
~/.familiar/data/training/
  curated/
    conversations.jsonl
    tool_calls.jsonl
    generated.jsonl
  exports/
    dataset_v{N}.jsonl
    dataset_v{N}_meta.json
  provenance.json
  state.json
```

## Export Formats

- **Alpaca**: `{"instruction": "...", "input": "", "output": "..."}`
- **ShareGPT**: `{"conversations": [{"from": "human", ...}, {"from": "gpt", ...}]}`
- **OpenAI**: `{"messages": [{"role": "user", ...}, {"role": "assistant", ...}]}`
