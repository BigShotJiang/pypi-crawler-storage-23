# Proton Services Skill

Monitor Proton Mail Bridge health and control Proton VPN.

## Proton Mail Bridge

Proton Mail Bridge exposes IMAP/SMTP on localhost for use with standard
email clients. Default ports:

- IMAP: `127.0.0.1:1143` (STARTTLS)
- SMTP: `127.0.0.1:1025` (STARTTLS)

### Setup

1. Install Proton Mail Bridge from https://proton.me/mail/bridge
2. Log in and leave Bridge running
3. Configure Familiar email with the Bridge password (not your Proton password):
   ```
   /connect email user@proton.me <bridge-password>
   ```
   Ports are auto-detected for proton.me / protonmail.com / pm.me domains.

## Proton VPN

VPN control uses `protonvpn-cli` (official Linux CLI).

### Setup

1. Install: https://protonvpn.com/support/linux-vpn-setup/
2. Log in: `protonvpn-cli login <username>`
3. Use the `proton_vpn_connect` / `proton_vpn_disconnect` tools

## Tools

- `proton_status` — Health check for Bridge ports, email config, and VPN
- `proton_vpn_connect` — Connect to VPN (fastest or by country code)
- `proton_vpn_disconnect` — Disconnect from VPN
- `proton_vpn_status` — Detailed VPN connection info

## Environment Overrides

If your Bridge uses non-default ports:

```
PROTON_BRIDGE_HOST=127.0.0.1
PROTON_BRIDGE_IMAP_PORT=1143
PROTON_BRIDGE_SMTP_PORT=1025
```
