# Gitea / Forgejo

Manage repositories and issues on your Gitea or Forgejo instance.

## Setup
Set `GITEA_URL` and `GITEA_TOKEN` environment variables.

## Tools
- `gitea_list_repos` -- List your repositories
- `gitea_search_issues` -- Search issues in a repository
- `gitea_create_issue` -- Create a new issue (requires confirmation)
- `gitea_list_prs` -- List pull requests
- `gitea_repo_stats` -- Get repository statistics
