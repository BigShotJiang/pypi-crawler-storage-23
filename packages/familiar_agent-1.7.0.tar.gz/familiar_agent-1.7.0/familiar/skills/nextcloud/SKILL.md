# Nextcloud Skill

Connect to any CalDAV/CardDAV/WebDAV server (Nextcloud, Radicale, ownCloud, Synology).

## Setup

1. Generate an **app password** in Nextcloud → Settings → Security → Devices & sessions
2. Set environment variables:

```
NEXTCLOUD_URL=https://cloud.example.org
NEXTCLOUD_USER=alice
NEXTCLOUD_TOKEN=xxxx-xxxx-xxxx-xxxx
```

3. Install dependencies:
```
pip install familiar-agent[nextcloud]
```

## Calendar (CalDAV)

- `nextcloud_calendar_today` — List events for today or a date range
- `nextcloud_calendar_create` — Create a calendar event (requires confirmation)
- `nextcloud_calendar_check` — Check if a time slot is available
- `nextcloud_calendar_free` — Find free time slots on a given day
- `nextcloud_calendar_delete` — Delete a calendar event (requires confirmation)

## Contacts (CardDAV)

- `nextcloud_contacts_list` — List contacts from the server
- `nextcloud_contacts_sync_in` — Pull contacts from server into local store
- `nextcloud_contacts_sync_out` — Push local contacts to server (requires confirmation)

## Files (WebDAV)

- `nextcloud_files_list` — List files in a directory
- `nextcloud_files_search` — Search files by name
- `nextcloud_files_read` — Read a text file (truncated at 5000 chars)
- `nextcloud_files_upload` — Upload a file (requires confirmation)
- `nextcloud_files_mkdir` — Create a directory
- `nextcloud_files_delete` — Delete a file or directory (requires confirmation)

## Timezone

Uses `CALENDAR_TIMEZONE` environment variable (shared with the Google Calendar skill).
