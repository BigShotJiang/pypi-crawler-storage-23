# Email Triage Skill - Themis, Titan of Order

*Themis was the Titan of divine law, order, and custom. She weighs each matter with her scales and assigns it to its proper place.*

Automatically sort and categorize incoming emails for nonprofit operations.

## Categories

- **Campaign** - Advocacy campaigns, action alerts, political organizing
- **Trans Pride** - Trans Pride events, planning, volunteers
- **GJL Operations** - Internal operations, admin, facilities, general org
- **Staff** - Staff communications, HR, team coordination
- **Board** - Board members, governance, board meetings
- **Coalitions** - Partner organizations, coalition work, allied groups
- **Donors** - Donations, fundraising, grant funders
- **Media** - Press inquiries, media requests, communications
- **Other** - Uncategorized

## Usage

The agent will:
1. Check inbox for new emails
2. Automatically categorize based on sender and content
3. Learn sender categories over time (remember who belongs where)
4. Present sorted summary with priority flags

## Priority Flags

- 🔴 Urgent: Time-sensitive, deadlines, "urgent" in subject
- 🟡 Action needed: Requests, questions requiring response
- 🟢 FYI: Informational, newsletters, updates
