# File Reader Skill

Extract text from PDF, DOCX, XLSX, CSV, TXT, and images (OCR).
Makes the agent able to read what's on the user's desk.

## Usage

Use this skill when the user wants to:
- Read or extract text from a PDF, Word doc, spreadsheet, or text file
- Extract tables from a PDF or DOCX into structured data
- Summarize a document's contents
- OCR a scanned document, receipt, or business card image
- Auto-detect a file's format and extract content

## File Discovery

The agent can reference files by path or by search. Integrates with
gdrive skill for cloud files and local filesystem for uploaded documents.

## Supported Formats

- **PDF**: Text and table extraction via PyMuPDF/fitz
- **DOCX**: Text extraction via python-docx
- **XLSX/CSV**: Sheet and range extraction via openpyxl/csv
- **TXT/MD**: Direct text reading
- **Images**: OCR via pytesseract (optional, requires Tesseract system package)

## HIPAA Consideration

File contents are processed locally. OCR runs on-device. No data
leaves the system. Audit log records which files were read and by whom.

## Cross-Skill Integration

- **knowledge**: Read documents can be ingested into knowledge base
- **documents**: Extracted content can be used to generate new documents
- **reports**: Tabular data from files feeds into report generation
