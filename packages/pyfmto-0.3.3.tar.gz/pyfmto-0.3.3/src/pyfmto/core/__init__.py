from .component import ComponentData

__all__ = [
    'ComponentData',
]
