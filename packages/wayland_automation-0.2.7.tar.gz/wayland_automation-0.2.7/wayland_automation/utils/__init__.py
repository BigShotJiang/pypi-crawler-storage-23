from .screen_resolution import get_resolution
