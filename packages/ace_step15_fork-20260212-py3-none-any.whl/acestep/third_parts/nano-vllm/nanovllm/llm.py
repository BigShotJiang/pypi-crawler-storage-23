from nanovllm.engine.llm_engine import LLMEngine


class LLM(LLMEngine):
    pass
