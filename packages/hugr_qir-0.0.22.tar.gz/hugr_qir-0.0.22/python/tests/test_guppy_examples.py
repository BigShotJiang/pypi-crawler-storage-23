from pathlib import Path

import pytest
from hugr_qir._hugr_qir import compile_target_choices, opt_level_choices
from hugr_qir.output import OutputFormat, expected_file_extension
from pytest_snapshot.plugin import Snapshot  # type: ignore

from .conftest import (
    SNAPSHOT_DIR,
    cli_on_hugr,
    guppy_example_dict,
    guppy_examples,
    skip_snapshot_checks,
)
from .hugr_generation import GuppyExample


@pytest.mark.parametrize(
    "guppy_example",
    guppy_examples,
    ids=[str(guppy_example.guppy_filepath.stem) for guppy_example in guppy_examples],
)
def test_guppy_files(tmp_path: Path, guppy_example: GuppyExample) -> None:
    out_file = tmp_path / "out.ll"
    options = ["-o", str(out_file)]
    guppy_path = guppy_example.guppy_filepath
    if "wasm" in guppy_path.stem:
        wasm_binary_filepath = str(guppy_path.parent / f"{guppy_path.stem}.wasm")
        options.extend(["--wasm-file", wasm_binary_filepath])
    cli_on_hugr(guppy_example.hugr_filepath, *options)


@pytest.mark.parametrize(
    "guppy_example",
    guppy_examples,
    ids=[str(guppy_example.guppy_filepath.stem) for guppy_example in guppy_examples],
)
def test_guppy_file_snapshots(
    tmp_path: Path, guppy_example: GuppyExample, snapshot: Snapshot
) -> None:
    snapshot.snapshot_dir = SNAPSHOT_DIR
    out_file = tmp_path / "out.ll"
    options = ["-o", str(out_file), "--no-validate-qir", "--validate-hugr"]
    guppy_file = guppy_example.guppy_filepath
    if "wasm" in guppy_file.stem:
        wasm_binary_filepath = str(guppy_file.parent / f"{guppy_file.stem}.wasm")
        options.extend(["--wasm-file", wasm_binary_filepath])

    cli_on_hugr(
        guppy_example.hugr_filepath,
        *options,
    )
    with Path.open(out_file) as f:
        qir = f.read()
    if not skip_snapshot_checks:
        snapshot.assert_match(qir, str(Path(guppy_file.stem).with_suffix(".ll")))


@pytest.mark.parametrize(
    ("target", "opt_level", "out_format"),
    [
        (t, opt, form)
        for t in compile_target_choices()
        for opt in opt_level_choices()
        for form in [c.value for c in OutputFormat]
    ],
)
def test_guppy_files_options(
    tmp_path: Path,
    snapshot: Snapshot,
    target: str,
    opt_level: str,
    out_format: str,
) -> None:
    snapshot.snapshot_dir = SNAPSHOT_DIR
    guppy_example = guppy_example_dict["quantum-conditional-2"]
    guppy_file = guppy_example.guppy_filepath
    out_file = tmp_path / "out.ll"
    extra_args = ["-t", target, "-l", opt_level, "-f", out_format]
    if opt_level == "none":
        extra_args.append("--no-validate-qir")
    cli_on_hugr(guppy_example.hugr_filepath, "-o", str(out_file), *extra_args)
    file_read_mode = "rb" if out_format == "bitcode" else "r"
    file_suffix = expected_file_extension(out_format)
    with Path.open(out_file, mode=file_read_mode) as f:
        qir = f.read()
    # don't test snapshots for 'native' since output is machine-dependent
    if target != "native" and not skip_snapshot_checks:
        snapshot_filename = guppy_file.stem + "_" + target + "_" + opt_level
        snapshot.assert_match(
            qir, str(Path(snapshot_filename).with_suffix(file_suffix))
        )


@pytest.mark.parametrize(
    "target",
    list(compile_target_choices()),
)
def test_qircheck_is_happy_with_discard_for_all_compilation_targets(
    tmp_path: Path,
    target: str,
) -> None:
    guppy_example = guppy_example_dict["uses-discard"]
    out_file = tmp_path / "out.ll"
    extra_args = ["-t", target]
    cli_on_hugr(guppy_example.hugr_filepath, "-o", str(out_file), *extra_args)
