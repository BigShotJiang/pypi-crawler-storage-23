raise ImportError(
    "gmft.table_function_algorithm has been moved to gmft.algorithm.structure."
)
