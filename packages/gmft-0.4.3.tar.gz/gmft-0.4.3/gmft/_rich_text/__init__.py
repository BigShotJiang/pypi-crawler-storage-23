"""
Note: this module is experimental and may be subject to refactors and changes.
"""

raise ImportError(
    "gmft._rich_text was experimental. Functionality has been moved to gmft.formatters.page.auto.AutoPageFormatter."
)
