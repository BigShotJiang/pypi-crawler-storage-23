from typing import Optional, Literal
from pydantic import BaseModel


MemoryCategory = Literal["preference", "context", "pattern", "fact"]


class MemoryItem(BaseModel):
    id: str
    content: str
    category: MemoryCategory = "fact"
    is_pinned: bool = False
    created_at: str
    updated_at: str


class CreateMemoryRequest(BaseModel):
    content: str
    category: MemoryCategory = "fact"


class UpdateMemoryRequest(BaseModel):
    content: Optional[str] = None
    category: Optional[MemoryCategory] = None
    is_pinned: Optional[bool] = None


class MemorySettings(BaseModel):
    enabled: bool = True
    max_memories: int = 50
    max_injection_tokens: int = 2000
    compression_threshold: float = 0.8  # 80% 도달 시 압축 트리거
