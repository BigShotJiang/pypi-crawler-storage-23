---
title: Architecture Decision Records
description: ADRs documenting significant architectural decisions for cosalette
---

# Architecture Decision Records

This directory contains the Architecture Decision Records (ADRs) for the cosalette
framework. ADRs document significant architectural decisions with their context,
rationale, and consequences.

## ADR Index

| ADR | Title | Status | Date |
| --- | ----- | ------ | ---- |
| [ADR-001](ADR-001-framework-architecture-style.md) | Framework Architecture Style | Accepted | 2026-02-14 |
| [ADR-002](ADR-002-mqtt-topic-conventions.md) | MQTT Topic Conventions | Accepted | 2026-02-14 |
| [ADR-003](ADR-003-configuration-system.md) | Configuration System | Accepted | 2026-02-14 |
| [ADR-004](ADR-004-logging-strategy.md) | Logging Strategy | Accepted | 2026-02-14 |
| [ADR-005](ADR-005-cli-framework.md) | CLI Framework | Accepted | 2026-02-14 |
| [ADR-006](ADR-006-hexagonal-architecture.md) | Hexagonal Architecture (Ports & Adapters) | Accepted | 2026-02-14 |
| [ADR-007](ADR-007-testing-strategy.md) | Testing Strategy | Accepted | 2026-02-14 |
| [ADR-008](ADR-008-packaging-and-distribution.md) | Packaging and Distribution | Accepted | 2026-02-14 |
| [ADR-009](ADR-009-python-version-and-dependencies.md) | Python Version and Dependencies | Accepted | 2026-02-14 |
| [ADR-010](ADR-010-device-archetypes.md) | Device Archetypes | Accepted | 2026-02-14 |
| [ADR-011](ADR-011-error-handling-and-publishing.md) | Error Handling and Publishing | Accepted | 2026-02-14 |
| [ADR-012](ADR-012-health-and-availability-reporting.md) | Health and Availability Reporting | Accepted | 2026-02-14 |
| [ADR-013](ADR-013-telemetry-publish-strategies.md) | Telemetry Publish Strategies | Accepted | 2026-02-22 |
| [ADR-014](ADR-014-signal-filters.md) | Signal Filters | Accepted | 2026-02-22 |
| [ADR-015](ADR-015-persistence.md) | Persistence | Accepted | 2026-02-25 |
| [ADR-016](ADR-016-adapter-lifecycle-protocol.md) | Adapter Lifecycle Protocol | Accepted | 2026-02-26 |
| [ADR-017](ADR-017-sbom-generation.md) | SBOM Generation | Accepted | 2026-02-27 |
| [ADR-018](ADR-018-coalescing-groups.md) | Telemetry Coalescing Groups | Accepted | 2026-03-03 |
| [ADR-019](ADR-019-scoped-name-uniqueness.md) | Scoped Name Uniqueness | Accepted | 2026-03-04 |
