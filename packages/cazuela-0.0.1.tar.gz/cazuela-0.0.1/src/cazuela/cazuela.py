#!/usr/bin/env python3

import os
import argparse

from ztl.core.server import TaskServer
from ztl.core.protocol import State, Task
from ztl.core.task import ExecutableTask, TaskExecutor, TaskController

from ollama import Client


class OLLamaTask(ExecutableTask):

  def __init__(self, client, request):
    self.client = client
    self.request = request

  def execute(self):
    response = self.client.chat(
      model=self.request["component"],
      messages=[
        {
          'role': 'user',
          'content': self.request["goal"],
          'stream': False
        },
      ]
    )
    return response

  def abort(self):
    return False


class Controller(TaskController):

  def __init__(self, remote):
    self.current_id = 0
    self.running = {}
    self.client = Client(host=remote)

  def init(self, request):
    self.current_id += 1
    request = Task.decode(request)
    if request["handler"] == "ollama":
      self.running[self.current_id] = TaskExecutor(OLLamaTask, self.client, request)
    else:
      raise RuntimeError("No such handler '%s'" % request["handler"])
    return self.current_id, "Initiated task '%s' with request: %s" % (self.current_id, request)

  def status(self, mid, request):
    if mid in self.running:
      state = self.running[mid].state()
      return state, self.running[mid].result()
    else:
      return State.REJECTED, "Invalid ID '%s'" % mid

  def abort(self, mid, request):
    if mid in self.running:
      success = self.running[mid].stop()
      state = self.running[mid].state()
      return state, success
    else:
      return State.REJECTED, "Invalid ID '%s'" % mid

def main_cli():

  parser = argparse.ArgumentParser(formatter_class=argparse.ArgumentDefaultsHelpFormatter)
  parser.add_argument("-p", "--port", type=int,
                      help="The port to listen listen on.", default=5570)
  parser.add_argument("-s", "--scope", type=str,
                      help="The scope that to respond to.", default="/prompt")
  parser.add_argument("-l", "--ollama", type=str,
                      help="The OLLama instance address.", default=os.environ.get('OLLAMA_HOST', 'http://localhost:11434'))

  args, unknown = parser.parse_known_args()

  server = TaskServer(args.port)
  server.register(args.scope, Controller(args.ollama))
  server.listen()

if __name__ == "__main__":

  main_cli()
