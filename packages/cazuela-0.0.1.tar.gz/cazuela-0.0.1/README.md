# Cazuela

Simple `ztl` Task Interface for AI. Currently supports `ollama` only.
