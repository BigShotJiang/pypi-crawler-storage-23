"""Allow running as python -m roam."""

from roam.cli import cli

cli()
