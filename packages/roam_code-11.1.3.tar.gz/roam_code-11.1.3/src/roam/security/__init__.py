"""Security analysis: vulnerability mapping and reachability."""
