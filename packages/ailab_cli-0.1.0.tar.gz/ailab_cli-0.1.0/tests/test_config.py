"""
Tests for config module — load, save, delete, is_authenticated.
"""

import json
import stat
from datetime import datetime, timedelta, timezone
from pathlib import Path

import pytest

from ailab_cli.config import Config, load_config, save_config, delete_config, is_authenticated


@pytest.fixture()
def config_dir(tmp_path, monkeypatch):
    """Redirect config to a temporary directory."""
    config_file = tmp_path / "config.json"
    monkeypatch.setattr("ailab_cli.config.CONFIG_DIR", tmp_path)
    monkeypatch.setattr("ailab_cli.config.CONFIG_FILE", config_file)
    # Clear any env var
    monkeypatch.delenv("AILAB_API_URL", raising=False)
    return tmp_path, config_file


class TestLoadConfig:
    """Tests for load_config()."""

    def test_returns_defaults_when_no_file(self, config_dir):
        config = load_config()
        assert config.api_url == "http://localhost:3000"
        assert config.token is None
        assert config.email is None
        assert config.expires_at is None

    def test_loads_saved_config(self, config_dir):
        _, config_file = config_dir
        data = {
            "apiUrl": "https://example.com",
            "token": "tok_abc",
            "email": "user@example.com",
            "expiresAt": "2026-06-01T00:00:00Z",
        }
        config_file.write_text(json.dumps(data))

        config = load_config()
        assert config.api_url == "https://example.com"
        assert config.token == "tok_abc"
        assert config.email == "user@example.com"
        assert config.expires_at == "2026-06-01T00:00:00Z"

    def test_env_var_overrides_api_url(self, config_dir, monkeypatch):
        monkeypatch.setenv("AILAB_API_URL", "https://prelive.example.com")
        config = load_config()
        assert config.api_url == "https://prelive.example.com"

    def test_env_var_overrides_saved_url(self, config_dir, monkeypatch):
        _, config_file = config_dir
        data = {"apiUrl": "https://production.example.com", "token": "tok"}
        config_file.write_text(json.dumps(data))
        monkeypatch.setenv("AILAB_API_URL", "https://prelive.example.com")

        config = load_config()
        assert config.api_url == "https://prelive.example.com"
        assert config.token == "tok"

    def test_handles_corrupt_json(self, config_dir):
        _, config_file = config_dir
        config_file.write_text("not valid json {{{")

        config = load_config()
        assert config.api_url == "http://localhost:3000"
        assert config.token is None


class TestSaveConfig:
    """Tests for save_config()."""

    def test_saves_and_sets_permissions(self, config_dir):
        tmp_path, config_file = config_dir
        config = Config(
            api_url="https://example.com",
            token="secret_token",
            email="test@example.com",
            expires_at="2026-12-31T00:00:00Z",
        )
        save_config(config)

        assert config_file.exists()
        data = json.loads(config_file.read_text())
        assert data["apiUrl"] == "https://example.com"
        assert data["token"] == "secret_token"
        assert data["email"] == "test@example.com"
        assert data["expiresAt"] == "2026-12-31T00:00:00Z"

        # Check 0600 permissions
        mode = config_file.stat().st_mode
        assert mode & 0o777 == stat.S_IRUSR | stat.S_IWUSR

    def test_creates_directory_if_missing(self, config_dir):
        tmp_path, _ = config_dir
        nested = tmp_path / "sub" / "dir"
        config_file = nested / "config.json"

        import ailab_cli.config as cfg_module
        original_dir = cfg_module.CONFIG_DIR
        original_file = cfg_module.CONFIG_FILE
        cfg_module.CONFIG_DIR = nested
        cfg_module.CONFIG_FILE = config_file

        try:
            save_config(Config(token="tok"))
            assert config_file.exists()
        finally:
            cfg_module.CONFIG_DIR = original_dir
            cfg_module.CONFIG_FILE = original_file


class TestDeleteConfig:
    """Tests for delete_config()."""

    def test_deletes_existing_file(self, config_dir):
        _, config_file = config_dir
        config_file.write_text("{}")
        assert config_file.exists()

        delete_config()
        assert not config_file.exists()

    def test_no_error_when_file_missing(self, config_dir):
        delete_config()  # Should not raise


class TestIsAuthenticated:
    """Tests for is_authenticated()."""

    def test_false_when_no_token(self):
        config = Config()
        assert is_authenticated(config) is False

    def test_true_with_valid_token(self):
        future = (datetime.now(timezone.utc) + timedelta(days=30)).isoformat()
        config = Config(token="tok", expires_at=future)
        assert is_authenticated(config) is True

    def test_false_when_token_expired(self):
        past = (datetime.now(timezone.utc) - timedelta(days=1)).isoformat()
        config = Config(token="tok", expires_at=past)
        assert is_authenticated(config) is False

    def test_true_when_no_expiry_set(self):
        config = Config(token="tok")
        assert is_authenticated(config) is True
