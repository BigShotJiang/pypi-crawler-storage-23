"""
Runs command — list annotation runs for a project.
"""

import typer
from rich.console import Console
from rich.table import Table

from ailab_cli.config import load_config, is_authenticated
from ailab_cli.api_client import ApiClient, ApiError, ApiConnectionError

console = Console()


def runs_command(project_id: str, url_override: str | None = None) -> None:
    """List annotation runs for a project."""
    config = load_config()
    if url_override:
        config.api_url = url_override
    if not is_authenticated(config):
        console.print("[red]Not logged in.[/red] Run [bold]ailab auth login[/bold] first.")
        raise typer.Exit(1)

    client = ApiClient(config)

    with console.status("Loading annotation runs..."):
        try:
            runs = client.list_runs(project_id)
        except ApiConnectionError as e:
            console.print(f"[red]Connection error:[/red] Could not reach server at {e.url}")
            console.print("Check the URL or run [bold]ailab auth login --api-url <url>[/bold] to reconfigure.")
            raise typer.Exit(1)
        except ApiError as e:
            console.print(f"[red]Error:[/red] {e.message}")
            raise typer.Exit(1)

    if not runs:
        console.print("[dim]No annotation runs found for this project.[/dim]")
        return

    table = Table(title="Annotation Runs")
    table.add_column("ID", style="dim", no_wrap=True)
    table.add_column("Name", style="bold")
    table.add_column("Dataset", style="cyan")
    table.add_column("Annotations", justify="right")
    table.add_column("Updated", style="dim")

    for r in runs:
        dataset_name = ""
        if isinstance(r.get("dataset"), dict):
            dataset_name = r["dataset"].get("name", "")

        annotation_count = str(len(r.get("annotations", []))) if "annotations" in r else "—"

        updated = r.get("updatedAt", r.get("createdAt", ""))
        if updated:
            updated = updated[:10]

        table.add_row(r["id"], r["name"], dataset_name, annotation_count, updated)

    console.print(table)
