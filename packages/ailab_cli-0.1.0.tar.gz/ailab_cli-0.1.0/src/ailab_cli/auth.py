"""
Authentication commands: login, logout, status.

Login uses the device authorization flow:
1. POST /api/apps/auth → get deviceCode + userCode + verificationUrl
2. Open browser to verificationUrl
3. Poll /api/apps/token until approved
4. Save token to config
"""

import time
import webbrowser

import typer
from rich.console import Console

from ailab_cli.config import (
    load_config,
    save_config,
    delete_config,
    is_authenticated,
)
from ailab_cli.api_client import ApiClient, ApiError, ApiConnectionError

auth_app = typer.Typer(help="Authentication commands")
console = Console()


@auth_app.command()
def login(
    api_url: str = typer.Option(
        None,
        "--api-url",
        help="API base URL (default: from config or AILAB_API_URL)",
    ),
) -> None:
    """Authenticate via browser (OAuth device flow)."""
    config = load_config()
    if api_url:
        config.api_url = api_url

    client = ApiClient(config)

    # Step 1: Initiate auth
    with console.status("Requesting authorization..."):
        try:
            auth_data = client.initiate_auth("CLI")
        except ApiConnectionError as e:
            console.print(f"[red]Connection error:[/red] Could not reach {e.url}")
            console.print("Check the URL or your network connection.")
            raise typer.Exit(1)
        except ApiError as e:
            console.print(f"[red]Error:[/red] {e.message}")
            raise typer.Exit(1)

    device_code = auth_data["deviceCode"]
    user_code = auth_data["userCode"]
    verification_url = auth_data["verificationUrl"]
    expires_in = auth_data.get("expiresIn", 600)

    # Step 2: Open browser
    console.print()
    console.print(f"Opening browser for authentication...")
    console.print(f"If the browser doesn't open, visit: [bold cyan]{verification_url}[/bold cyan]")
    console.print(f"Your code: [bold yellow]{user_code}[/bold yellow]")
    console.print()

    webbrowser.open(verification_url)

    # Step 3: Poll for token
    poll_interval = 3  # seconds
    deadline = time.time() + expires_in

    with console.status("Waiting for authorization...") as status:
        while time.time() < deadline:
            time.sleep(poll_interval)
            try:
                result = client.poll_token(device_code)
            except ApiError:
                continue

            if result.get("status") == "approved":
                config.token = result["accessToken"]
                config.email = result["email"]
                config.expires_at = result["expiresAt"]
                save_config(config)

                status.stop()
                console.print(f"[green]✓[/green] Logged in as [bold]{config.email}[/bold]")
                console.print(f"  Token expires: {config.expires_at}")
                return

            if result.get("status") == "expired":
                status.stop()
                console.print("[red]Authorization expired.[/red] Please try again.")
                raise typer.Exit(1)

            # status == "pending" → keep polling

    console.print("[red]Authorization timed out.[/red] Please try again.")
    raise typer.Exit(1)


@auth_app.command()
def logout() -> None:
    """Remove local credentials."""
    config = load_config()
    if not config.token:
        console.print("Not logged in.")
        return

    email = config.email or "unknown"
    delete_config()
    console.print(f"[green]✓[/green] Logged out ({email}). Local credentials removed.")


@auth_app.command()
def status() -> None:
    """Show current authentication status."""
    config = load_config()

    if is_authenticated(config):
        console.print(f"[green]✓[/green] Logged in as [bold]{config.email}[/bold]")
        console.print(f"  API:     {config.api_url}")
        console.print(f"  Expires: {config.expires_at or 'unknown'}")
    else:
        if config.token:
            console.print("[yellow]⚠[/yellow] Token expired. Run [bold]ailab auth login[/bold] to re-authenticate.")
        else:
            console.print("[dim]Not logged in.[/dim] Run [bold]ailab auth login[/bold] to authenticate.")
