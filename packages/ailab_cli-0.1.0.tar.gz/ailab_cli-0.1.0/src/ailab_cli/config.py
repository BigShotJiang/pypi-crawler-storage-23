"""
Configuration file management for ailab-cli.

Stores and reads the auth token and API URL from ~/.config/ailab/config.json.
File permissions are set to 0600 (owner read/write only) for security.
"""

import json
import os
import stat
from pathlib import Path
from dataclasses import dataclass
from typing import Optional

CONFIG_DIR = Path.home() / ".config" / "ailab"
CONFIG_FILE = CONFIG_DIR / "config.json"

# Default API URL — override with --api-url or AILAB_API_URL env var
DEFAULT_API_URL = "http://localhost:3000"


@dataclass
class Config:
    """CLI configuration data."""

    api_url: str = DEFAULT_API_URL
    token: Optional[str] = None
    email: Optional[str] = None
    expires_at: Optional[str] = None


def load_config() -> Config:
    """Load config from disk. Returns defaults if file doesn't exist."""
    # Allow env var override for API URL
    env_url = os.environ.get("AILAB_API_URL")

    if not CONFIG_FILE.exists():
        config = Config()
        if env_url:
            config.api_url = env_url
        return config

    try:
        data = json.loads(CONFIG_FILE.read_text(encoding="utf-8"))
        config = Config(
            api_url=data.get("apiUrl", DEFAULT_API_URL),
            token=data.get("token"),
            email=data.get("email"),
            expires_at=data.get("expiresAt"),
        )
        if env_url:
            config.api_url = env_url
        return config
    except (json.JSONDecodeError, OSError):
        config = Config()
        if env_url:
            config.api_url = env_url
        return config


def save_config(config: Config) -> None:
    """Save config to disk with secure file permissions (0600)."""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)

    data = {
        "apiUrl": config.api_url,
        "token": config.token,
        "email": config.email,
        "expiresAt": config.expires_at,
    }

    CONFIG_FILE.write_text(
        json.dumps(data, indent=2) + "\n", encoding="utf-8"
    )

    # Set file permissions to 0600 (owner read/write only)
    CONFIG_FILE.chmod(stat.S_IRUSR | stat.S_IWUSR)


def delete_config() -> None:
    """Delete the config file (logout)."""
    if CONFIG_FILE.exists():
        CONFIG_FILE.unlink()


def is_authenticated(config: Config) -> bool:
    """Check if the config has a valid (non-expired) token."""
    if not config.token:
        return False

    if config.expires_at:
        from datetime import datetime, timezone

        try:
            expires = datetime.fromisoformat(config.expires_at)
            if expires < datetime.now(timezone.utc):
                return False
        except ValueError:
            pass

    return True
