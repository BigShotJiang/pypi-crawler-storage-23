"""
Interactive TUI mode — launched when running `ailab` with no arguments.

Navigation:
  1. Auth check → login prompt if needed
  2. Project list (arrow keys, Enter to select, Esc to logout/exit)
  3. Run list (arrow keys, Enter to export, Esc to go back)
  4. Export → save to ./export.json, return to run list
"""

import sys

from rich.console import Console
from InquirerPy import inquirer
from InquirerPy.base.control import Choice

from ailab_cli.config import load_config, save_config, delete_config, is_authenticated
from ailab_cli.api_client import ApiClient, ApiError, ApiConnectionError

console = Console()


def run_interactive(url_override: str | None = None) -> None:
    """Main interactive mode entry point."""
    config = load_config()
    if url_override:
        config.api_url = url_override
    client = ApiClient(config)

    # ── Step 1: Auth check ──────────────────────────────────────────
    if not is_authenticated(config):
        console.print("[yellow]Not authenticated.[/yellow]")
        try:
            login_now = inquirer.confirm(
                message="Log in now?",
                default=True,
            ).execute()
        except KeyboardInterrupt:
            return

        if not login_now:
            return

        # Inline login flow
        from ailab_cli.auth import login
        login(api_url=url_override)
        # Reload config after login
        config = load_config()
        if url_override:
            config.api_url = url_override
        if not is_authenticated(config):
            return
        client = ApiClient(config)

    console.print(f"[green]✓[/green] Logged in as [bold]{config.email}[/bold]")
    console.print()

    # ── Step 2: Project list loop ───────────────────────────────────
    while True:
        with console.status("Loading projects..."):
            try:
                projects = client.list_projects()
            except ApiConnectionError as e:
                console.print(f"[red]Connection error:[/red] Could not reach server at {e.url}")
                console.print("Check the URL or run [bold]ailab auth login --api-url <url>[/bold] to reconfigure.")
                return
            except ApiError as e:
                console.print(f"[red]Error:[/red] {e.message}")
                return

        if not projects:
            console.print("[dim]No projects found.[/dim]")
            return

        # Build choices
        project_choices = []
        email = config.email or ""
        for p in projects:
            owners = [o.get("email", o) if isinstance(o, dict) else o for o in p.get("owners", [])]
            editors = [e.get("email", e) if isinstance(e, dict) else e for e in p.get("editors", [])]
            role = "Owner" if email in owners else ("Editor" if email in editors else "Reader")
            updated = (p.get("updatedAt") or p.get("createdAt", ""))[:10]
            label = f"{p['name']:<30} {role:<8} {updated}"
            project_choices.append(Choice(value=p["id"], name=label))

        try:
            selected_project = inquirer.select(
                message="Select a project:",
                choices=project_choices,
                pointer="▸",
                show_cursor=False,
            ).execute()
        except KeyboardInterrupt:
            # Esc / Ctrl+C on project list → offer logout
            _handle_exit(config)
            return

        if selected_project is None:
            _handle_exit(config)
            return

        # ── Step 3: Run list loop ───────────────────────────────────
        _run_list_loop(client, config, selected_project, projects)


def _run_list_loop(
    client: ApiClient,
    config: object,
    project_id: str,
    projects: list[dict],
) -> None:
    """Show runs for a project, allow export or go back."""
    project_name = next((p["name"] for p in projects if p["id"] == project_id), project_id)

    while True:
        with console.status("Loading annotation runs..."):
            try:
                runs = client.list_runs(project_id)
            except ApiConnectionError as e:
                console.print(f"[red]Connection error:[/red] Could not reach server at {e.url}")
                console.print("Check the URL or run [bold]ailab auth login --api-url <url>[/bold] to reconfigure.")
                return
            except ApiError as e:
                console.print(f"[red]Error:[/red] {e.message}")
                return

        if not runs:
            console.print(f"[dim]No annotation runs in \"{project_name}\".[/dim]")
            return

        run_choices = []
        for r in runs:
            dataset_name = ""
            if isinstance(r.get("dataset"), dict):
                dataset_name = r["dataset"].get("name", "")
            ann_count = len(r.get("annotations", [])) if "annotations" in r else "?"
            label = f"{r['name']:<30} {dataset_name:<20} {ann_count:>6} annotations"
            run_choices.append(Choice(value=r["id"], name=label))

        try:
            selected_run = inquirer.select(
                message=f"{project_name} — Select an annotation run:",
                choices=run_choices,
                pointer="▸",
                show_cursor=False,
            ).execute()
        except KeyboardInterrupt:
            # Esc → back to project list
            return

        if selected_run is None:
            return

        # ── Step 4: Export ──────────────────────────────────────────
        run_name = next((r["name"] for r in runs if r["id"] == selected_run), selected_run)

        with console.status(f'Exporting "{run_name}"...'):
            try:
                data = client.export_run(project_id, selected_run)
            except ApiConnectionError as e:
                console.print(f"[red]Connection error:[/red] Could not reach server at {e.url}")
                continue
            except ApiError as e:
                console.print(f"[red]Error:[/red] {e.message}")
                continue

        import json
        from pathlib import Path

        out_path = Path("./export.json")
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
            f.write("\n")

        total = data.get("totalEntries", len(data.get("entries", [])))
        console.print(
            f'[green]✓[/green] Saved to [bold]{out_path}[/bold] ({total} entries)'
        )
        console.print()
        # Loop back to run list


def _handle_exit(config) -> None:
    """Handle Esc on project list — offer logout."""
    try:
        do_logout = inquirer.confirm(
            message="Log out?",
            default=False,
        ).execute()
    except KeyboardInterrupt:
        return

    if do_logout:
        delete_config()
        console.print("[green]✓[/green] Logged out.")
