import pydantic


class ServiceEntity(pydantic.BaseModel):
    """
    Base entity model for services. Represents a generic entity in a service,
    such as a file, folder, or table. This model can be extended by specific
    service models to include additional fields relevant to that service.
    """

    name: str = pydantic.Field(description="Name of the entity.")
