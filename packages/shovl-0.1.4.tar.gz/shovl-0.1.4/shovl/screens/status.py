from typing import Optional

from textual.app import ComposeResult
from textual.containers import Vertical
from textual.screen import ModalScreen
from textual.widgets import Label, LoadingIndicator


class StatusScreen(ModalScreen):
    """
    Screen to display a status.
    """

    CSS_PATH = "../styles/status.tcss"

    label: Label

    initial_label: str | None

    ### Lifecycle methods ###

    def __init__(self, label: Optional[str] = None) -> None:
        """
        Initialize the status screen.
        """
        super().__init__()

        self.initial_label = label

    def compose(self) -> ComposeResult:
        """
        Compose the status screen.
        """
        with Vertical(classes="status-container"):
            label = self.initial_label if self.initial_label else "Loading..."
            self.label = Label(label, classes="label")
            yield self.label
            yield LoadingIndicator(classes="indicator")

    ### Class methods ###

    def update_label(self, label: str) -> None:
        """
        Update label.
        """
        self.label.update(content=label)
