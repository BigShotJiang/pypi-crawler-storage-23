"""Diagrid CLI utilities."""
