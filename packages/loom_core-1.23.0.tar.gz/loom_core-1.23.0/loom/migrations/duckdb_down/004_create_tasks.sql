-- Drop tasks table
DROP TABLE IF EXISTS tasks;
