-- Drop indexes
DROP INDEX IF EXISTS idx_events_workflow_id;
DROP INDEX IF EXISTS idx_tasks_pending;
DROP INDEX IF EXISTS idx_workflows_status;
