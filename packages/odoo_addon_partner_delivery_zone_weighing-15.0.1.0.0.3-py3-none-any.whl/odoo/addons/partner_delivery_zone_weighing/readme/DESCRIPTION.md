Shows delivery zone info in weighing cards.
