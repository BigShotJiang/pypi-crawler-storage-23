class UserCancelledError(Exception):
    """Exception raised when the user explicitly cancels an action."""

    pass
