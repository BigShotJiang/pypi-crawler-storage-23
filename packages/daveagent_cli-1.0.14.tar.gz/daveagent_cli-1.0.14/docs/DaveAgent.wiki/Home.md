# CodeAgent (DaveAgent) - Wiki

Welcome to the official documentation for **CodeAgent** (also known as DaveAgent)!

CodeAgent is an AI-powered coding assistant that works in your current directory. It uses AutoGen 0.4 to orchestrate specialized agents that help you with development tasks.

## Documentation Index

### For Users

- **[Installation](Installation)** - Complete installation and setup guide
- **[Quick Start](Quick-Start)** - Get started with CodeAgent in 5 minutes
- **[Usage Guide](Usage-Guide)** - Commands, features, and workflows
- **[Available Tools](Tools-and-Features)** - Complete catalog of 40+ tools
- **[Skills System](Skills)** - Agent Skills with semantic discovery
- **[State Management](State-Management)** - Auto-save sessions and conversation history
- **[Configuration](Configuration)** - Customization and environment variables
- **[Troubleshooting](Troubleshooting)** - Common issues and solutions

### For Developers

- **[Architecture](Architecture)** - Project structure and components
- **[Development](Development)** - Contributing guide
- **[SWE-bench Evaluation](SWE-Bench-Evaluation)** - Evaluation with standard benchmarks
- **[API Reference](API-Reference)** - API and tools documentation

### Special Features

- **[Agent Skills](Skills)** - Claude-compatible skill system with RAG discovery
- **[File Mentions](File-Mentions)** - Mention files with @ for maximum priority
- **[Session Management](State-Management)** - Auto-save, load, and manage conversation sessions
- **[Interactive CLI](CLI-Interface)** - Rich interface with colors and autocomplete

---

## Key Features

| Feature | Description |
|---------|-------------|
| **Global Command** | Use `daveagent` from any directory |
| **Contextual Work** | Operates in your current directory automatically |
| **Smart Routing** | SelectorGroupChat with automatic agent selection (Planner + Coder) |
| **Agent Skills** | Claude-compatible skills with semantic RAG discovery |
| **State Management** | Auto-save sessions with LLM-generated titles |
| **File Mentions** | Mention specific files with `@` for maximum priority |
| **40+ Tools** | Full integration: Filesystem, Git, JSON, CSV, Web, Analysis, Terminal |
| **Dual Clients** | Base (fast) and Strong (reasoning) model support |
| **Complete Logging** | Detailed logging system for debugging |
| **Rich Interface** | CLI with colors and formatting using Rich |
| **Real-time Visualization** | See agent thoughts and actions while it works |

---

## Quick Start

### Installation

```bash
# Clone the repository
git clone https://github.com/davidmonterocrespo24/DaveAgent.git
cd DaveAgent

# Install in development mode
pip install -e .

# Use from any directory
daveagent
```

### First Use

```bash
# Navigate to your project
cd my-project

# Start CodeAgent
daveagent

# Mention specific files with @
You: @main.py fix the authentication bug in this file

# Or simply ask what you need
You: create a REST API with FastAPI for user management

# Sessions are auto-saved with smart titles
# Load previous session
You: /load-state

# List available skills
You: /skills
```

---

## Use Cases

### Software Development
```bash
cd my-project
daveagent

# Mention specific files
You: @main.py fix the authentication bug
You: @config.py @.env update the API configuration

# Modify with context
You: create an authentication module with JWT
You: refactor the code in services/ to use async/await

# Save session for later
You: /save-state
```

### Data Analysis
```bash
cd data-project
daveagent

You: read the sales.csv file and show a summary
You: combine all CSVs in the data/ folder
You: convert the configuration JSON to CSV
```

### Git Operations
```bash
cd my-repo
daveagent

You: commit the changes with a descriptive message
You: show the diff of the last 3 commits
You: create a branch feature/new-functionality
```

---

## Internal Commands

Within CodeAgent, you can use these commands:

| Command | Description |
|---------|-------------|
| `/help` | Show command help |
| `/skills` | List available agent skills |
| `/skill-info <name>` | Show detailed skill information |
| `/init` | Create DAVEAGENT.md configuration template |
| `/save-state` | Save current session |
| `/load-state [id]` | Load previous session |
| `/sessions` | List all saved sessions |
| `/history` | Show current session history |
| `@<file>` | Mention specific file with high priority |
| `/debug` | Enable/disable debug mode |
| `/logs` | Show logs location |
| `/clear` | Clear screen |
| `/new` | New conversation |
| `/exit` | Exit CodeAgent |

### Skills System

Agent skills are automatically discovered and loaded from:
- Personal: `~/.daveagent/skills/`
- Project: `.daveagent/skills/`

Skills are compatible with Claude Code format and use RAG for semantic discovery:

```bash
You: /skills
# Lists all available skills with descriptions

You: /skill-info xlsx
# Shows detailed information about the xlsx skill
```

See **[Skills Guide](Skills)** for more details.

### State Management

Sessions are automatically saved with LLM-generated titles:

```bash
You: /save-state
# Saves current session with auto-generated title

You: /sessions
# Lists all saved sessions

You: /load-state 20240315_143022
# Loads a specific session

You: /history --all
# Shows complete conversation history
```

See **[State Management Guide](State-Management)** for more details.

---

## Tool Categories

CodeAgent includes **40+ tools** organized in categories:

- **Filesystem** (7 tools) - File operations
- **Git** (8 tools) - Complete version control
- **JSON** (8 tools) - JSON processing and validation
- **CSV** (7 tools) - CSV analysis and manipulation
- **Web** (7 tools) - Wikipedia and web search
- **Analysis** (5 tools) - Code analysis and search
- **Terminal** (1 tool) - Command execution

For more details, see **[Tools and Features](Tools-and-Features)**.

---

## Simplified Architecture

```
CodeAgent/
 src/
    config/          # Configuration and prompts
    interfaces/      # CLI interface
    managers/        # State, Context, RAG, and Error management
    skills/          # Agent Skills system
    tools/           # 40+ tools (Filesystem, Git, JSON, CSV, Web, Analysis)
    utils/           # Logging and utilities
    main.py          # Main application with SelectorGroupChat
    cli.py           # CLI entry point
 .daveagent/         # Working directory configuration
    skills/          # Project-specific skills
    state/           # Session state files
    logs/            # Application logs
    rag_data/        # RAG vector database
 eval/               # SWE-bench evaluation
 docs/               # Documentation
```

**Key Components:**
- **SelectorGroupChat**: Smart routing between Planner and Coder agents
- **Planner Agent**: Complex multi-step task planning (base model)
- **Coder Agent**: Code operations and modifications (strong model)
- **Skills Manager**: Discovers and loads Claude-compatible skills with RAG
- **State Manager**: Auto-save sessions with AutoGen's save_state/load_state
- **RAG Manager**: Vector memory for skills and context retrieval

For more details, see **[Architecture](Architecture)**.

---

## Contact and Community

- **Discord**: [Join our server](https://discord.gg/pufRfBeQ)
- **GitHub**: https://github.com/davidmonterocrespo24/DaveAgent
- **Issues**: https://github.com/davidmonterocrespo24/DaveAgent/issues
- **Email**: davidmonterocrespo24@gmail.com

### Join our Discord Community

We invite you to join our Discord server to:
- Get help and support
- Report bugs and issues  
- Suggest new features
- Collaborate with other users
- Stay updated on news

**[Click here to join: https://discord.gg/pufRfBeQ](https://discord.gg/pufRfBeQ)**

---

## License

This project is under the MIT License. See [LICENSE](https://github.com/davidmonterocrespo24/DaveAgent/blob/main/LICENSE) for more details.

---

## Acknowledgments

- [AutoGen](https://microsoft.github.io/autogen/) - Agent framework
- [Rich](https://rich.readthedocs.io/) - Terminal formatting
- [Prompt Toolkit](https://python-prompt-toolkit.readthedocs.io/) - Interactive CLI
- [ChromaDB](https://www.trychroma.com/) - Vector database

---

Made with love using [AutoGen 0.4](https://microsoft.github.io/autogen/)
