# Agent Skills - CodeAgent

Agent Skills are reusable, shareable capabilities that extend CodeAgent's functionality. They are compatible with Claude Code's skill format and use RAG (Retrieval-Augmented Generation) for intelligent, context-aware discovery.

---

## What are Agent Skills?

Agent Skills are:
- **Modular capabilities** that can be added to the agent
- **Claude-compatible** using the SKILL.md format
- **Semantically discovered** using RAG vector search
- **Context-rich** with instructions, scripts, references, and assets
- **Shareable** between projects and users

### Key Features

| Feature | Description |
|---------|-------------|
| **Automatic Discovery** | Skills are automatically loaded at startup |
| **Semantic Search** | RAG finds relevant skills based on user queries |
| **Claude Compatibility** | Uses Claude Code's SKILL.md format |
| **Multi-source** | Personal and project-specific skills |
| **Resource Support** | Includes scripts, references, and assets |
| **No Manual Activation** | Relevant skills activate automatically |

---

## Skill Locations

Skills are discovered from two directories:

### 1. Personal Skills
**Location**: `~/.daveagent/skills/`

Personal skills are available across all projects for the current user.

**Use for**:
- General-purpose utilities (xlsx, pdf, pptx)
- Frequently used workflows
- Personal preferences and templates

### 2. Project Skills
**Location**: `.daveagent/skills/` (in project root)

Project-specific skills for the current workspace.

**Use for**:
- Project-specific testing frameworks
- Custom deployment scripts
- Domain-specific utilities

---

## Skill Structure

Each skill is a directory containing a `SKILL.md` file and optional resources:

```
.daveagent/skills/
└── my-skill/
    ├── SKILL.md           # Required: Skill metadata and instructions
    ├── scripts/           # Optional: Python/shell scripts
    │   ├── script1.py
    │   └── script2.sh
    ├── references/        # Optional: Documentation, examples
    │   ├── examples.md
    │   └── api_docs.pdf
    └── assets/            # Optional: Data files, templates
        ├── template.json
        └── data.csv
```

---

## SKILL.md Format

The `SKILL.md` file uses YAML frontmatter + Markdown:

```markdown
---
name: my-skill
description: Brief description of what this skill does
allowed_tools:
  - read_file
  - write_file
  - run_terminal_cmd
license: MIT
---

# Detailed Instructions

This section contains detailed instructions for the agent on how to use this skill.

## When to Use

Use this skill when the user asks to...

## How to Use

1. First, check if...
2. Then, run...
3. Finally, verify...

## Examples

Example 1: ...
Example 2: ...

## Important Notes

- Note 1
- Note 2
```

### Frontmatter Fields

| Field | Required | Description |
|-------|----------|-------------|
| `name` | Yes | Unique skill identifier (lowercase, hyphens) |
| `description` | Yes | Short description (1-2 sentences) |
| `allowed_tools` | No | List of tools this skill can use |
| `license` | No | License identifier (MIT, Apache-2.0, etc.) |

### Instructions Section

The Markdown body contains:
- **Detailed instructions** for the agent
- **When to use** this skill
- **How to use** it step-by-step
- **Examples** of usage
- **Important notes** and caveats

---

## Creating a Skill

### Step 1: Create Skill Directory

```bash
# For personal skill
mkdir -p ~/.daveagent/skills/my-skill

# For project skill
mkdir -p .daveagent/skills/my-skill
```

### Step 2: Create SKILL.md

Create `.daveagent/skills/my-skill/SKILL.md`:

```markdown
---
name: my-skill
description: Processes data files and generates reports
allowed_tools:
  - read_file
  - write_file
  - read_csv
  - write_json
---

# Data Processing Skill

This skill processes CSV data files and generates JSON summary reports.

## When to Use

Use this skill when the user asks to:
- Process CSV data files
- Generate summary reports
- Convert CSV to JSON with aggregations

## How to Use

1. Read the CSV file using `read_csv`
2. Analyze the data structure
3. Calculate aggregations (sum, average, count)
4. Generate JSON report with `write_json`

## Example

Input: sales_data.csv
Output: sales_summary.json

```json
{
  "total_sales": 150000,
  "average_sale": 1500,
  "num_transactions": 100
}
```

## Important Notes

- Handle missing values gracefully
- Validate data types before aggregation
- Always include metadata in output
```

### Step 3: Add Resources (Optional)

Add scripts, references, or assets:

```bash
# Add a processing script
cat > .daveagent/skills/my-skill/scripts/process.py << 'EOF'
import pandas as pd
import json

def process_csv(input_file, output_file):
    df = pd.read_csv(input_file)
    summary = {
        "total_sales": df['amount'].sum(),
        "average_sale": df['amount'].mean(),
        "num_transactions": len(df)
    }
    with open(output_file, 'w') as f:
        json.dump(summary, f, indent=2)
EOF

# Add documentation
cat > .daveagent/skills/my-skill/references/examples.md << 'EOF'
# Examples

## Example 1: Monthly Sales Report
Input: monthly_sales.csv
Output: monthly_summary.json
EOF
```

### Step 4: Test the Skill

```bash
daveagent

You: /skills
# Verify your skill is listed

You: /skill-info my-skill
# Check detailed information

You: process sales_data.csv and create a summary report
# The skill should be automatically activated
```

---

## Using Skills

### Automatic Discovery

Skills are automatically loaded when CodeAgent starts:

```
[Startup] SkillManager initialized in 0.0234s
✓ Loaded 5 agent skills
```

### Listing Skills

```bash
You: /skills

# Output:
🎯 Available Agent Skills (5 loaded)

📁 Personal Skills:
  • xlsx: Work with Excel spreadsheets
  • pdf: PDF manipulation and form filling
  • pptx: PowerPoint presentation editing

📂 Project Skills:
  • api-testing: Test REST APIs with automated scenarios
  • db-migration: Database migration utilities
```

### Viewing Skill Details

```bash
You: /skill-info xlsx

# Output:
🎯 Skill: xlsx

📝 Description: Work with Excel spreadsheets
📁 Source: personal
📂 Path: ~/.daveagent/skills/xlsx
🔧 Allowed Tools: read_file, write_file, run_terminal_cmd

📦 Resources:
  • Scripts: read_excel.py, write_excel.py, format_excel.py
  • References: examples.md, api_reference.md
  • Assets: template.xlsx

📋 Instructions Preview:
This skill enables working with Excel (.xlsx) files including reading,
writing, formatting, and data manipulation...
```

### Semantic Activation

Skills are automatically activated based on semantic relevance:

```bash
You: create a summary report from sales_data.xlsx

# The agent:
# 1. Analyzes the query
# 2. Searches for relevant skills using RAG
# 3. Finds "xlsx" skill (score: 0.85)
# 4. Loads skill instructions into context
# 5. Executes the task using skill guidance
```

---

## Skill Discovery Algorithm

CodeAgent uses RAG for intelligent skill discovery:

### 1. Indexing (At Startup)

```python
# For each skill:
search_content = f"""
Skill: {skill.name}
Description: {skill.description}

{skill.instructions}
"""

# Index in RAG with metadata
rag_manager.add_document(
    collection="agent_skills",
    text=search_content,
    metadata={"skill_name": skill.name, "source": skill.source}
)
```

### 2. Semantic Search (At Query Time)

```python
# When user makes a request:
relevant_skills = skill_manager.find_relevant_skills(
    user_query,
    max_results=3,      # Maximum skills to activate
    min_score=0.6       # Minimum relevance threshold (0.0-1.0)
)

# Only skills with score >= 0.6 are activated
# This prevents false positives
```

### 3. Context Injection

```python
# Relevant skills are injected into the agent's context:
for skill in relevant_skills:
    context += f"""
<skill name="{skill.name}">
{skill.description}

{skill.instructions}

Available resources:
{skill.list_resources()}
</skill>
"""
```

---

## Advanced Features

### Resource Access

Skills can reference their own resources:

```markdown
## Instructions

1. Use the template from `assets/template.json`
2. Run the processing script: `scripts/process.py`
3. Refer to `references/api_docs.md` for API details
```

The agent can then:
```python
# Read script
script_content = read_file("~/.daveagent/skills/my-skill/scripts/process.py")

# Use template
template = read_json("~/.daveagent/skills/my-skill/assets/template.json")

# Reference documentation
docs = read_file("~/.daveagent/skills/my-skill/references/api_docs.md")
```

### Tool Restrictions

Limit which tools a skill can use:

```yaml
---
name: safe-analyzer
description: Analyzes code without making changes
allowed_tools:
  - read_file
  - list_dir
  - analyze_python_file
  - grep_search
# Note: No write_file, edit_file, or delete_file
---
```

This ensures the skill only performs read-only operations.

### Conditional Activation

Use descriptive language to control when skills activate:

```markdown
## When to Use

Use this skill ONLY when:
- The user explicitly mentions "Excel" or ".xlsx" files
- The task involves spreadsheet operations
- Data needs to be formatted in tabular form

Do NOT use this skill for:
- CSV files (use CSV tools instead)
- JSON data (use JSON tools instead)
- Plain text tables
```

---

## Example Skills

### Example 1: Excel Processing

```markdown
---
name: xlsx
description: Work with Excel spreadsheets including reading, writing, and formatting
allowed_tools:
  - read_file
  - write_file
  - run_terminal_cmd
license: MIT
---

# Excel Processing Skill

Process Excel (.xlsx) files for data analysis and reporting.

## When to Use

Use when the user asks to:
- Read data from .xlsx files
- Create new Excel spreadsheets
- Format Excel data
- Convert between Excel and other formats

## How to Use

1. Use `openpyxl` library (run `pip install openpyxl` if needed)
2. Read Excel file: `scripts/read_excel.py <file>`
3. Process data as needed
4. Write output: `scripts/write_excel.py <data> <output>`

## Resources

- `scripts/read_excel.py` - Read Excel files
- `scripts/write_excel.py` - Write Excel files
- `scripts/format_excel.py` - Apply formatting
- `references/examples.md` - Usage examples
- `assets/template.xlsx` - Template file
```

### Example 2: API Testing

```markdown
---
name: api-testing
description: Test REST APIs with automated scenarios and validation
allowed_tools:
  - run_terminal_cmd
  - read_file
  - write_file
  - read_json
  - write_json
---

# API Testing Skill

Automated REST API testing with request/response validation.

## When to Use

Use when the user asks to:
- Test REST API endpoints
- Validate API responses
- Create test scenarios
- Generate API test reports

## How to Use

1. Define test scenario in JSON
2. Run `scripts/run_tests.py <scenario_file>`
3. Validate responses against expected output
4. Generate test report

## Example Scenario

```json
{
  "name": "User API Tests",
  "base_url": "https://api.example.com",
  "tests": [
    {
      "name": "Get user",
      "method": "GET",
      "endpoint": "/users/1",
      "expected_status": 200,
      "expected_fields": ["id", "name", "email"]
    }
  ]
}
```

## Resources

- `scripts/run_tests.py` - Test runner
- `scripts/validate.py` - Response validator
- `references/scenario_format.md` - Scenario format docs
- `assets/example_scenario.json` - Example test
```

---

## Best Practices

### 1. Clear Names and Descriptions

```yaml
# Good
name: pdf-form-filler
description: Fill PDF forms programmatically with data validation

# Bad
name: pdf
description: PDF stuff
```

### 2. Specific Instructions

```markdown
# Good
## How to Use

1. Validate input file is a fillable PDF using `pdftk`
2. Read field mapping from JSON file
3. Fill each field with data validation
4. Save output PDF with timestamp suffix

# Bad
## How to Use

Fill the PDF with data.
```

### 3. Include Examples

```markdown
## Examples

### Example 1: Fill W-9 Form

Input:
- `w9_form.pdf` (blank form)
- `taxpayer_data.json` (data)

Output:
- `w9_form_filled_20240315.pdf`

### Example 2: Bulk Fill

Process multiple forms from `forms/` directory using
data from `data.csv`.
```

### 4. Document Resources

```markdown
## Available Resources

- `scripts/fill_pdf.py` - Main PDF filling script
  Usage: `python fill_pdf.py <input> <data> <output>`

- `scripts/validate_fields.py` - Field validator
  Checks field types and formats

- `references/field_types.md` - Supported field types
  Lists all PDF field types and validation rules

- `assets/template.pdf` - Blank template form
  Use this as a starting point for new forms
```

### 5. Semantic Keywords

Include relevant keywords for better RAG discovery:

```markdown
---
description: Excel spreadsheet processor for data analysis, pivot tables, charts, and financial reports
---

Keywords: Excel, XLSX, spreadsheet, workbook, cells, rows, columns, formulas, pivot, chart, graph
```

---

## Troubleshooting

### Skill Not Found

```bash
You: /skills
# Skill is not listed

# Check:
1. Verify SKILL.md exists in correct location
2. Check YAML frontmatter is valid
3. Ensure `name` and `description` fields are present
4. Restart CodeAgent to reload skills
```

### Skill Not Activating

```bash
# Skill exists but doesn't activate automatically

# Solutions:
1. Check semantic relevance (score < 0.6)
2. Add more descriptive keywords
3. Improve description field
4. Add explicit "When to Use" section
5. Use skill name in query: "use xlsx skill to..."
```

### Skill Errors

```bash
# View skill load errors
You: /debug

# Check logs
cat .daveagent/logs/daveagent_*.log | grep "skill"
```

---

## Configuration

### Changing Discovery Threshold

The default minimum relevance score is 0.6 (60% semantic match).

To change it, modify `src/main.py`:

```python
relevant_skills = self.skill_manager.find_relevant_skills(
    user_input,
    max_results=3,
    min_score=0.5,  # Lower = more permissive, higher = stricter
)
```

### Disabling Skills

To temporarily disable skills, rename the directory:

```bash
mv ~/.daveagent/skills/my-skill ~/.daveagent/skills/my-skill.disabled
```

---

## See Also

- **[State Management](State-Management)** - Session persistence
- **[Tools and Features](Tools-and-Features)** - Available tools
- **[Configuration](Configuration)** - Agent configuration
- **[Quick Start](Quick-Start)** - Getting started guide

---

[← Back to Home](Home) | [Tools and Features →](Tools-and-Features)
