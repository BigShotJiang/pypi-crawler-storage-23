#  Quick Start - CodeAgent

Learn to use CodeAgent in 5 minutes with this quick guide.

##  Express Installation

```bash
# Clone and install
git clone https://github.com/davidmonterocrespo24/DaveAgent.git
cd DaveAgent
pip install -e .

# Verify
daveagent --version
```

**Problems?** Go to the [Complete Installation Guide](Installation).

---

##  First Use

### 1. Start CodeAgent

```bash
# Navigate to your project
cd ~/my-project

# Start the agent
daveagent
```

You'll see a banner like this:

```

             D A V E A G E N T  v1.1.0             
         AI-Powered Coding Assistant                  


Working in: /home/user/my-project
Type '/help' for commands, '/exit' to quit

You: 
```

### 2. Basic Commands

```bash
# View help
You: /help

# Read a file
You: read the README.md file

# Search in code
You: /search authentication function

# View Git status
You: git status
```

### 3. Exit

```bash
You: /exit
# or Ctrl+C
```

---

##  Essential Commands

| Command | Description | Example |
|---------|-------------|---------|
| `/help` | Show help | `You: /help` |
| `/skills` | List available skills | `You: /skills` |
| `/skill-info <name>` | Show skill details | `You: /skill-info xlsx` |
| `/init` | Create DAVEAGENT.md | `You: /init` |
| `/save-state` | Save session | `You: /save-state` |
| `/load-state [id]` | Load session | `You: /load-state` |
| `/sessions` | List all sessions | `You: /sessions` |
| `/history` | Show history | `You: /history` |
| `@<file>` | Mention file with priority | `You: @main.py explain this` |
| `/new` | New conversation | `You: /new` |
| `/exit` | Exit | `You: /exit` |

---

##  5-Minute Tutorial

### Example 1: Read and Explain Code

```bash
You: read the main.py file and explain what it does

# The agent will read the file and provide an explanation
```

### Example 2: Use Skills

```bash
You: /skills

# Lists all available skills
# Personal Skills:
#   - xlsx: Work with Excel files
#   - pdf: PDF manipulation and form filling
#
# Project Skills:
#   - api-testing: Test REST APIs

You: /skill-info xlsx
# Shows detailed information about the xlsx skill
```

### Example 3: Create a New File

```bash
You: create a new file utils.py with a function to validate email addresses

# The agent will create utils.py with:
# - validate_email() function
# - Regex for validation
# - Docstrings
# - Error handling
```

### Example 4: Modify Existing Code

```bash
You: @auth.py add error handling to the login function

# The agent:
# 1. Reads auth.py
# 2. Identifies the login function
# 3. Adds try-except
# 4. Shows changes made
```

### Example 5: Session Management

```bash
You: /save-state

# Auto-saves current session with LLM-generated title
# Session saved: "Python API Development"

# Later, in a new session
You: /sessions

# Lists all saved sessions:
# 20240315_143022 - "Python API Development" - 25 messages
# 20240314_101530 - "Database Migration Setup" - 15 messages

You: /load-state 20240315_143022

# Loads the session and shows conversation history
# The agent continues from where you left off
```

---

##  Common Use Cases

### Web Development

```bash
cd my-web-app
daveagent

You: create a FastAPI endpoint for user registration with:
     - Email validation
     - Password hashing
     - Database storage
     - JSON response

# The agent will create:
# - routes/auth.py with /register endpoint
# - models/user.py with user model
# - utils/security.py with password hashing
# - Update main.py
```

### Data Analysis

```bash
cd data-analysis
daveagent

You: read sales_2024.csv and create a summary report in JSON format

# The agent:
# 1. Reads sales_2024.csv
# 2. Calculates statistics (total, average, etc.)
# 3. Creates sales_summary.json with report
```

### Refactoring

```bash
cd legacy-code
daveagent

You: /search where is the database connection used

# CodeSearcher shows all files

You: refactor all database connections to use a connection pool

# The agent:
# 1. Creates db_pool.py with pool
# 2. Updates all files using the connection
# 3. Shows summary of changes
```

### Project Setup

```bash
cd new-project
daveagent

You: /init

# Creates DAVEAGENT.md template with project-specific:
# - Commands
# - Guidelines
# - Custom instructions

You: @DAVEAGENT.md add project rules about using TypeScript and async/await

# The agent updates the file with your guidelines
# These instructions are automatically loaded on every session
```

---

##  Advanced Features (First Steps)

### 1. File Mentions with @

Mention specific files for maximum priority:

```bash
You: @auth.py @middleware.py update the authentication system to use JWT

# The agent:
# - auth.py has maximum priority
# - middleware.py also prioritized
# - Modifies both files in a coordinated way
```

**Navigation**:
- Type `@` and a file selector will appear
- Use ↑↓ to navigate
- Type to filter
- Enter to select

### 2. Skills System

```bash
# List available skills
You: /skills

# Personal Skills:
#   - xlsx: Work with Excel spreadsheets
#   - pdf: PDF manipulation and form filling
#
# Project Skills:
#   - api-testing: Test REST APIs
#   - db-migration: Database migration utilities

# Get detailed information
You: /skill-info xlsx

# Skill: xlsx
# Description: Work with Excel spreadsheets
# Source: personal
# Path: ~/.daveagent/skills/xlsx
# Resources:
#   - Scripts: read_excel.py, write_excel.py
#   - References: examples.md

# Skills are automatically activated when relevant
You: create a summary report from sales_data.xlsx

# The xlsx skill is automatically discovered and used
```

### 3. Session Persistence

```bash
# First session
You: create a REST API with user authentication

# Do some work...

You: /save-state

# Session saved with auto-generated title:
# "REST API with User Authentication"

# Next day - resume work
You: /load-state

# Loads the most recent session
# Shows conversation history
# Agent continues from where you left off

# View full history
You: /history --all

# Shows all messages with context
```

---

##  Quick Configuration

### Change AI Model

Edit `.env` in the project directory:

```env
DAVEAGENT_API_KEY=your-api-key
DAVEAGENT_MODEL=gpt-4
DAVEAGENT_BASE_URL=https://api.openai.com/v1
```

### Disable SSL (Corporate Networks)

```bash
# Option 1: Argument
daveagent --no-ssl-verify

# Option 2: Environment variable
export DAVEAGENT_SSL_VERIFY=false
daveagent
```

---

##  Common Problems

### "Command not found: daveagent"

```bash
# Solution: Reinstall
cd DaveAgent
pip install -e .
```

### "SSL Certificate Error"

```bash
# Solution: Disable SSL verification
daveagent --no-ssl-verify
```

### "Connection Refused"

```bash
# Verify API key and base URL
cat .env

# Test connectivity
curl https://api.deepseek.com/v1
```

---

##  Startup Checklist

- [ ] CodeAgent installed (`daveagent --version` works)
- [ ] API key configured (`.env` file or `.daveagent/.env`)
- [ ] Tested basic command (`read README.md`)
- [ ] Tested file mention (`@README.md explain`)
- [ ] Explored skills (`/skills` executed)
- [ ] Tested session save (`/save-state` executed)

---

##  Next Steps

Now that you know the basics:

1. **[Complete Usage Guide](Usage-Guide)** - Learn all commands and workflows
2. **[Tools](Tools-and-Features)** - Explore the 40+ available tools
3. **[Skills System](Skills)** - Create and use agent skills
4. **[State Management](State-Management)** - Master session management
5. **[File Mentions](File-Mentions)** - Interactive file selector

---

##  Need Help?

- **Discord**: [Join our server](https://discord.gg/pufRfBeQ) - Fastest way to get help
- **GitHub Issues**: [Report problems](https://github.com/davidmonterocrespo24/DaveAgent/issues)
- **Email**: davidmonterocrespo24@gmail.com

---

##  Final Tips

1. **Mention files with @** - Maximum priority for context
2. **Save your sessions** - `/save-state` to preserve progress
3. **Explore skills** - `/skills` to see what's available
4. **Use project context** - `/init` to add project-specific guidelines
5. **Be specific** - Clear instructions = better results
6. **Use `/help`** - When you forget a command

---

Congratulations!  You now know how to use CodeAgent. Start coding with AI!

[← Back to Home](Home) | [Complete Guide →](Usage-Guide)
