# State Management - CodeAgent

CodeAgent features a comprehensive state management system that automatically saves and restores conversation sessions, allowing you to pause work and resume later exactly where you left off.

---

## Overview

The State Management system provides:

- **Auto-save**: Sessions are automatically saved after each interaction
- **Smart Titles**: LLM-generated descriptive titles for each session
- **Complete History**: Full conversation and agent state persistence
- **Easy Recovery**: Load any previous session with one command
- **Rich Metadata**: Tags, descriptions, timestamps, and message counts

### Key Features

| Feature | Description |
|---------|-------------|
| **AutoGen Integration** | Uses official AutoGen `save_state`/`load_state` |
| **Auto-save** | Saves automatically every 5 minutes and after each response |
| **LLM Titles** | Automatically generates descriptive session titles |
| **Full State** | Preserves agents, teams, and conversation history |
| **Session Browser** | List, search, and filter saved sessions |
| **History Viewer** | View complete conversation history with Rich formatting |
| **Multi-agent** | Saves state of all agents (Planner, Coder) |

---

## Core Concepts

### Sessions

A **session** is a complete snapshot of your interaction with CodeAgent, including:

- All conversation messages (user and agent)
- Agent state (context, memory, reasoning)
- Team state (group chat coordination)
- Metadata (title, tags, description, timestamps)

Sessions are stored in `.daveagent/state/` as JSON files.

### Auto-save

Auto-save runs:
1. **After every response** from the agent
2. **Every 5 minutes** (configurable) in the background
3. **On exit** when you close CodeAgent

### Smart Titles

When a session is first saved, CodeAgent analyzes the conversation and generates a descriptive title using an LLM:

```
User: create a REST API for user management
Agent: [creates API code...]

Auto-generated title: "REST API for User Management"
```

---

## Commands

### `/save-state` or `/save-session`

Save the current session manually.

**Usage**:
```bash
# Save current session (auto-generates title)
You: /save-state

# Save with custom title (creates new session)
You: /save-state "My Custom Title"

# Alias
You: /save-session
```

**Output**:
```
✅ State saved successfully!
  • Title: REST API Development
  • Session ID: 20240315_143022
  • Location: .daveagent/state/session_20240315_143022.json
  • Agents saved: 2
  • Messages saved: 25
```

### `/load-state` or `/load-session`

Load a previous session.

**Usage**:
```bash
# Load most recent session
You: /load-state

# Load specific session by ID
You: /load-state 20240315_143022

# Alias
You: /load-session 20240314_101530
```

**Output**:
```
📂 Loading session: REST API Development...

✅ Session loaded: REST API Development
  • Messages restored: 25
  • Agents restored: 2

📜 Displaying conversation history:

[Shows last 20 messages...]

✅ The agent will continue from where the conversation left off
```

### `/sessions` or `/list-sessions`

List all saved sessions.

**Usage**:
```bash
You: /sessions

# Alias
You: /list-sessions
```

**Output** (Rich table):
```
📊 Saved Sessions (5 total)

┏━━━━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━━━━━━━━━━━━┳━━━━━━━━━━┳━━━━━━━━━━━━━━━━━━┓
┃ Session ID      ┃ Title                   ┃ Messages ┃ Last Interaction ┃
┡━━━━━━━━━━━━━━━━━╇━━━━━━━━━━━━━━━━━━━━━━━━━╇━━━━━━━━━━╇━━━━━━━━━━━━━━━━━━┩
│ 20240315_143022 │ REST API Development    │ 25       │ 2024-03-15 14:45 │
│ 20240314_101530 │ Database Migration      │ 15       │ 2024-03-14 11:20 │
│ 20240313_165443 │ Bug Fix in Auth Module  │ 10       │ 2024-03-13 17:30 │
│ 20240312_093215 │ Refactoring Services    │ 20       │ 2024-03-12 10:45 │
│ 20240311_141056 │ Adding Unit Tests       │ 12       │ 2024-03-11 15:00 │
└─────────────────┴─────────────────────────┴──────────┴──────────────────┘

💡 Use /load-session <session_id> to load a session
💡 Use /history to view current session history
```

### `/history`

Display conversation history for the current or specified session.

**Usage**:
```bash
# Show last 20 messages
You: /history

# Show all messages
You: /history --all

# Include agent thoughts/reasoning
You: /history --thoughts

# Show history of specific session
You: /history 20240315_143022

# Combine options
You: /history --all --thoughts
```

**Output**:
```
📜 Session History: REST API Development

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

👤 User (14:30:22)
create a REST API for user management

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

🤖 Planner (14:30:25)
I'll break this down into steps:
1. Create FastAPI application structure
2. Define User model with Pydantic
3. Implement CRUD endpoints
4. Add authentication

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

🤖 Coder (14:30:30)
Creating main.py with FastAPI app...
[Created file: main.py]

[... more messages ...]

💡 Showing last 20 of 25 messages
💡 Use /history --all to see all messages
```

### `/new-session`

Create a new session with metadata.

**Usage**:
```bash
# Basic
You: /new-session "My Project Title"

# With tags
You: /new-session "Web Development" --tags python,fastapi,postgresql

# With description
You: /new-session "API Project" --desc "Building a REST API with authentication"

# Complete
You: /new-session "Full Stack App" --tags react,node,mongo --desc "E-commerce platform"
```

**Output**:
```
✅ New session created: Full Stack App
  • Session ID: 20240315_150000
  • Tags: react, node, mongo
  • Description: E-commerce platform
```

---

## Workflow Examples

### Example 1: Basic Save and Load

```bash
# Day 1: Start working on a project
You: create a Python web scraper for news articles

[... work on the project ...]

You: /save-state
# Session saved: "Python Web Scraper for News Articles"

You: /exit
```

```bash
# Day 2: Resume work
You: /load-state
# Loads most recent session

You: now add error handling for network failures
# Agent continues from where you left off
```

### Example 2: Multiple Projects

```bash
# Create separate sessions for different projects
You: /new-session "Project A - API Development" --tags backend,api
You: create a FastAPI endpoint for user registration

[... work on Project A ...]

You: /save-state

# Start new session for different project
You: /new-session "Project B - Data Analysis" --tags data,pandas
You: analyze the sales data from Q1

[... work on Project B ...]

You: /save-state

# Later, switch between projects
You: /sessions
# See both sessions

You: /load-state 20240315_143022
# Load Project A
```

### Example 3: Reviewing History

```bash
# Load a session and review what was done
You: /load-state 20240314_101530

You: /history --all
# See complete conversation

# Continue work with full context
You: apply the same pattern to the other services
```

---

## Session Metadata

Each session stores rich metadata:

```json
{
  "session_id": "20240315_143022",
  "title": "REST API Development",
  "description": "Building a REST API with FastAPI and PostgreSQL",
  "tags": ["python", "fastapi", "postgresql", "backend"],
  "created_at": "2024-03-15T14:30:22",
  "last_interaction": "2024-03-15T14:45:30",
  "saved_at": "2024-03-15T14:45:32",
  "num_agents": 2,
  "num_teams": 1,
  "total_messages": 25
}
```

### Metadata Fields

| Field | Description |
|-------|-------------|
| `session_id` | Unique identifier (timestamp format) |
| `title` | Descriptive title (LLM-generated or user-provided) |
| `description` | Optional detailed description |
| `tags` | List of tags for categorization |
| `created_at` | When the session was created |
| `last_interaction` | When the last message was sent |
| `saved_at` | When the session was last saved |
| `num_agents` | Number of agents in the session |
| `num_teams` | Number of teams in the session |
| `total_messages` | Total number of messages |

---

## Auto-save Behavior

### When Auto-save Happens

1. **After each agent response**
   ```python
   # After process_user_request() completes:
   await self._auto_save_agent_states()
   ```

2. **Every 5 minutes (background)**
   ```python
   # Background loop in StateManager
   while auto_save_enabled:
       await asyncio.sleep(300)  # 5 minutes
       await save_to_disk()
   ```

3. **On exit**
   ```python
   # In app shutdown:
   await state_manager.close()  # Final save
   ```

### Auto-save Output

Auto-save runs silently in the background. You'll see debug messages in logs:

```
2024-03-15 14:45:32 | DEBUG | 💾 Auto-save: State saved automatically
```

### Disabling Auto-save

Auto-save is enabled by default. To disable:

```python
# In src/main.py DaveAgentCLI.__init__:
self.state_manager = StateManager(
    auto_save_enabled=False,  # Disable auto-save
)
```

---

## Title Generation

### Automatic Titles

When you save a session for the first time, CodeAgent generates a descriptive title using an LLM:

**Process**:
1. Extracts first 5 messages from conversation
2. Creates a prompt: "Generate a short title (max 50 chars) for this conversation"
3. Calls LLM to generate title
4. Cleans and validates title
5. Uses title for session

**Example**:
```
User: create a FastAPI app with user authentication
Agent: [creates code...]
User: add password reset functionality
Agent: [adds feature...]

Generated title: "FastAPI User Authentication System"
```

### Manual Titles

Provide your own title when saving:

```bash
You: /save-state "My Custom Project Title"
```

Or when creating a new session:

```bash
You: /new-session "My Project" --desc "Building something cool"
```

### Title Format

Titles are:
- **Maximum 50 characters** (truncated if longer)
- **Descriptive** of the main task or topic
- **Clean** (no quotes, special characters removed)
- **Concise** (1-5 words typically)

---

## Session Storage

### File Structure

Sessions are stored as JSON in `.daveagent/state/`:

```
.daveagent/
└── state/
    ├── session_20240315_143022.json
    ├── session_20240314_101530.json
    ├── session_20240313_165443.json
    └── ...
```

### File Format

Each session file contains:

```json
{
  "session_id": "20240315_143022",
  "saved_at": "2024-03-15T14:45:32",
  "session_metadata": {
    "title": "REST API Development",
    "tags": ["python", "fastapi"],
    "description": "Building a REST API",
    "created_at": "2024-03-15T14:30:22",
    "last_interaction": "2024-03-15T14:45:30"
  },
  "agent_states": {
    "coder": {
      "state": { "llm_context": {...}, ... },
      "metadata": {"description": "Main coder agent with tools"},
      "saved_at": "2024-03-15T14:45:32"
    },
    "planning": {
      "state": { "llm_context": {...}, ... },
      "metadata": {"description": "Planning and task management agent"},
      "saved_at": "2024-03-15T14:45:32"
    }
  },
  "team_states": {},
  "metadata": {
    "auto_save_enabled": true,
    "auto_save_interval": 300
  }
}
```

### Storage Location

- **Workspace-relative**: `.daveagent/state/` in current working directory
- **Project-specific**: Each project has its own sessions
- **Portable**: Can be copied/moved with the project

---

## Advanced Usage

### Session Resume at Startup

CodeAgent automatically offers to resume the most recent session:

```bash
$ daveagent

Previous session found: Messages: 25

Do you want to continue with this session? (Y/n): y

📂 Loading session: REST API Development...
✅ Session loaded: REST API Development
  • Messages restored: 25
  • Agents restored: 2

📜 Recent messages:
[Shows last 5 messages...]

✅ You can continue the conversation

You:
```

### Viewing Session Statistics

```bash
You: /sessions

# Shows for each session:
# - Session ID
# - Title
# - Number of messages
# - Last interaction time
# - Number of agents
# - Tags (if any)
```

### Searching Sessions

Currently, sessions are sorted by last interaction (newest first).

To search manually:

```bash
# List sessions and grep for keyword
You: /sessions
# Manually look for sessions about "API"

# Or use bash:
ls .daveagent/state/ | grep 20240315
```

### Deleting Sessions

Sessions can be deleted manually:

```bash
# Delete a specific session file
rm .daveagent/state/session_20240315_143022.json

# Or from CodeAgent (in future version):
# You: /delete-session 20240315_143022
```

---

## Integration with AutoGen

CodeAgent uses AutoGen's official state management:

### Agent State

Each agent (Planner, Coder) supports:

```python
# Save
agent_state = await agent.save_state()

# Load
await agent.load_state(agent_state)
```

This preserves:
- **Conversation history** (all messages)
- **LLM context** (current context window)
- **Agent configuration** (tools, system messages)

### Team State

Teams (SelectorGroupChat) also support state:

```python
# Save
team_state = await team.save_state()

# Load
await team.load_state(team_state)
```

This preserves:
- **Participant state** (all agents in the team)
- **Conversation flow** (who spoke when)
- **Team configuration** (routing logic, termination conditions)

---

## Troubleshooting

### Session Not Saving

**Symptoms**: `/save-state` completes but no file created

**Solutions**:
1. Check `.daveagent/state/` directory exists and is writable
2. Check disk space
3. Look for errors in logs: `/logs`
4. Try manual save: `/save-state "test"`

### Session Load Fails

**Symptoms**: `/load-state` fails with error

**Solutions**:
1. Verify session file exists:
   ```bash
   ls .daveagent/state/session_*.json
   ```

2. Check file is valid JSON:
   ```bash
   cat .daveagent/state/session_20240315_143022.json | python -m json.tool
   ```

3. Try loading a different session

### Auto-save Not Working

**Symptoms**: Sessions not auto-saving

**Solutions**:
1. Check if auto-save is enabled (default: yes)
2. Look for auto-save messages in debug logs:
   ```bash
   You: /debug  # Enable debug mode
   # Look for "Auto-save: State saved automatically"
   ```

3. Try manual save to verify system works

### Missing Messages

**Symptoms**: Loaded session missing some messages

**Possible causes**:
1. Session was saved before those messages
2. Auto-save interval not reached yet
3. Messages were in a different session

**Solutions**:
1. Check `/history --all` to see all messages in current session
2. Load the correct session
3. Manual `/save-state` more frequently

---

## Best Practices

### 1. Save Important Milestones

```bash
# After completing a major task
You: /save-state "Completed user authentication module"
```

### 2. Use Descriptive Titles

```bash
# Good
You: /new-session "REST API with JWT Auth"

# Bad
You: /new-session "Project"
```

### 3. Add Tags for Organization

```bash
You: /new-session "E-commerce Backend" --tags python,fastapi,postgres,stripe
```

### 4. Review Before Resuming

```bash
You: /load-state
You: /history
# Review what was done before continuing
```

### 5. Clean Up Old Sessions

```bash
# Periodically delete old/unnecessary sessions
ls .daveagent/state/
rm .daveagent/state/session_old*.json
```

---

## Configuration

### Auto-save Interval

Change the auto-save interval in `src/main.py`:

```python
self.state_manager = StateManager(
    auto_save_enabled=True,
    auto_save_interval=600,  # 10 minutes (in seconds)
)
```

### State Directory

Change the state storage location:

```python
self.state_manager = StateManager(
    state_dir=Path("/custom/path/to/state"),
    auto_save_enabled=True,
)
```

---

## See Also

- **[Skills System](Skills)** - Agent skills documentation
- **[Tools and Features](Tools-and-Features)** - Available tools
- **[Quick Start](Quick-Start)** - Getting started guide
- **[Configuration](Configuration)** - Agent configuration

---

[← Back to Home](Home) | [Skills →](Skills)
