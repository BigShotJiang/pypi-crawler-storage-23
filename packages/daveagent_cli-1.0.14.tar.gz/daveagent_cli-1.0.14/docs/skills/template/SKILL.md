---
name: template-skill
description: Replace with description of the skill and when Claude should use it.
---

# Insert instructions below
