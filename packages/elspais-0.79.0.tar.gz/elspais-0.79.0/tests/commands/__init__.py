# Tests for elspais CLI commands
