def get_version():
    return '0.6.2'
