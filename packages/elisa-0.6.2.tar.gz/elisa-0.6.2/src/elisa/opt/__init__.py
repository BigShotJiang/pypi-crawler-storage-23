from elisa.opt import newton
