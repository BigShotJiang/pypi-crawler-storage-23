from .. logger import getLogger

logger = getLogger(__name__)


# noinspection PyUnusedLocal
def compute_general_lightcurve(self, **kwargs):
    pass
