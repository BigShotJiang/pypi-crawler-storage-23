from elisa.single_system.graphic import plot
from elisa.single_system.graphic import animation
