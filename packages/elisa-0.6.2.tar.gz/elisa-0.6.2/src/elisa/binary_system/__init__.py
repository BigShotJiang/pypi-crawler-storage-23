from elisa.binary_system.system import BinarySystem
