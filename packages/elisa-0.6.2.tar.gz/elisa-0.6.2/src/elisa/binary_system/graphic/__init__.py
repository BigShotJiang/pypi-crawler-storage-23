from elisa.binary_system.graphic import plot
from elisa.binary_system.graphic import animation
