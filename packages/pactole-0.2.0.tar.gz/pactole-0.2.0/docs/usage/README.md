[Pactole](../../README.md) / [Documentation](../README.md) / [Usage](./README.md)

# Usage

This section contains practical guides for using Pactole public classes.

## Pages

- [Combinations](./combinations.md): Create, compare, and rank lottery combinations.
- [Lottery classes](./lotteries.md): Handle draw days and generate combinations by lottery.
