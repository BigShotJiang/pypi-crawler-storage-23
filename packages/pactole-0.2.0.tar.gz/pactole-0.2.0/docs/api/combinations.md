<!-- markdownlint-disable -->

<a href="../../src/pactole/combinations/__init__.py#L0"><img align="right" style="float:right;" src="https://img.shields.io/badge/-source-cccccc?style=flat-square"></a>

# <kbd>module</kbd> `combinations`
Combinations package. 

**Global Variables**
---------------
- **combination**
- **lottery_combination**
- **eurodreams_combination**
- **euromillions_combination**




---

_This file was automatically generated via [lazydocs](https://github.com/ml-tooling/lazydocs)._
