"""Entry points for the scripts package."""
