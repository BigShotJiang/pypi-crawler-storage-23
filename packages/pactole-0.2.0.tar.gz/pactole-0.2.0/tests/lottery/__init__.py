"""Unit tests for lottery package."""
