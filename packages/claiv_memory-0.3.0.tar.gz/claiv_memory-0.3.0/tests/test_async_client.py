"""Tests for the async AsyncClaivClient."""

import httpx
import pytest
import respx

from claiv import AsyncClaivClient, ClaivApiError, ClaivTimeoutError, ClaivNetworkError

BASE = "https://api.test.com"


def make_client(**kwargs) -> AsyncClaivClient:
    return AsyncClaivClient(api_key="test-key-123", base_url=BASE, **kwargs)


# ---------------------------------------------------------------------------
# Constructor
# ---------------------------------------------------------------------------


class TestAsyncConstructor:
    def test_raises_on_empty_api_key(self):
        with pytest.raises(ValueError, match="api_key is required"):
            AsyncClaivClient(api_key="", base_url=BASE)

    def test_raises_on_invalid_timeout(self):
        with pytest.raises(ValueError, match="timeout must be a positive number"):
            AsyncClaivClient(api_key="k", base_url=BASE, timeout=0)

    def test_raises_on_invalid_max_retries(self):
        with pytest.raises(ValueError, match="max_retries must be a non-negative integer"):
            AsyncClaivClient(api_key="k", base_url=BASE, max_retries=-1)


# ---------------------------------------------------------------------------
# Core endpoints
# ---------------------------------------------------------------------------


class TestAsyncIngest:
    @respx.mock
    async def test_ingest(self):
        respx.post(f"{BASE}/v1/ingest").mock(
            return_value=httpx.Response(200, json={"event_id": "e1", "deduped": False})
        )
        async with AsyncClaivClient(api_key="key", base_url=BASE) as client:
            result = await client.ingest({"user_id": "u1", "type": "message", "content": "hi"})
        assert result == {"event_id": "e1", "deduped": False}


class TestAsyncRecall:
    @respx.mock
    async def test_recall(self):
        response_body = {
            "system_context": "ctx",
            "memory_blocks": [
                {"type": "claim", "content": "fact", "source_ids": ["e1"], "score": 1.0},
            ],
            "citations": ["e1"],
            "token_estimate": 10,
        }
        respx.post(f"{BASE}/v1/recall").mock(
            return_value=httpx.Response(200, json=response_body)
        )
        async with AsyncClaivClient(api_key="key", base_url=BASE) as client:
            result = await client.recall({"user_id": "u1", "task": "test", "token_budget": 500})
        assert result == response_body


class TestAsyncForget:
    @respx.mock
    async def test_forget(self):
        response_body = {
            "receipt_id": "r1",
            "deleted_counts": {
                "events": 0, "chunks": 1, "episodes": 0,
                "facts": 0, "claims": 0, "open_loops": 0,
            },
        }
        respx.post(f"{BASE}/v1/forget").mock(
            return_value=httpx.Response(200, json=response_body)
        )
        async with AsyncClaivClient(api_key="key", base_url=BASE) as client:
            result = await client.forget({"user_id": "u1"})
        assert result == response_body


# ---------------------------------------------------------------------------
# Usage endpoints
# ---------------------------------------------------------------------------


class TestAsyncUsage:
    @respx.mock
    async def test_usage_summary(self):
        respx.get(f"{BASE}/v1/usage/summary").mock(
            return_value=httpx.Response(200, json={
                "range": "7d", "start_date": "d", "end_date": "d", "totals": {}, "daily": [],
            })
        )
        client = make_client()
        result = await client.get_usage_summary()
        assert result["range"] == "7d"
        await client.close()

    @respx.mock
    async def test_usage_breakdown(self):
        respx.get(f"{BASE}/v1/usage/breakdown").mock(
            return_value=httpx.Response(200, json={
                "range": "today", "start_date": "d", "end_date": "d", "endpoints": [],
            })
        )
        client = make_client()
        result = await client.get_usage_breakdown("today")
        assert result["range"] == "today"
        await client.close()

    @respx.mock
    async def test_usage_limits(self):
        respx.get(f"{BASE}/v1/usage/limits").mock(
            return_value=httpx.Response(200, json={
                "plan": "pro", "billing_cycle_day": 1, "reset_date": "x",
                "is_within_quota": True, "limits": {},
            })
        )
        client = make_client()
        result = await client.get_usage_limits()
        assert result["plan"] == "pro"
        await client.close()


# ---------------------------------------------------------------------------
# Health
# ---------------------------------------------------------------------------


class TestAsyncHealth:
    @respx.mock
    async def test_health_check_no_auth(self):
        route = respx.get(f"{BASE}/healthz").mock(
            return_value=httpx.Response(200, json={"ok": True})
        )
        client = make_client()
        result = await client.health_check()
        assert result == {"ok": True}
        assert "authorization" not in route.calls[0].request.headers
        await client.close()


# ---------------------------------------------------------------------------
# Error handling
# ---------------------------------------------------------------------------


class TestAsyncErrors:
    @respx.mock
    async def test_api_error(self):
        respx.post(f"{BASE}/v1/ingest").mock(
            return_value=httpx.Response(400, json={
                "error": {"code": "invalid_request", "message": "bad", "request_id": "r1"},
            })
        )
        client = make_client()
        with pytest.raises(ClaivApiError) as exc_info:
            await client.ingest({"user_id": "u1", "type": "message", "content": ""})
        assert exc_info.value.status == 400
        await client.close()

    @respx.mock
    async def test_timeout(self):
        respx.post(f"{BASE}/v1/ingest").mock(side_effect=httpx.ReadTimeout("timeout"))
        client = make_client()
        with pytest.raises(ClaivTimeoutError):
            await client.ingest({"user_id": "u1", "type": "message", "content": "x"})
        await client.close()

    @respx.mock
    async def test_network_error(self):
        respx.post(f"{BASE}/v1/ingest").mock(
            side_effect=httpx.ConnectError("refused")
        )
        client = make_client()
        with pytest.raises(ClaivNetworkError):
            await client.ingest({"user_id": "u1", "type": "message", "content": "x"})
        await client.close()


# ---------------------------------------------------------------------------
# Deletion receipts
# ---------------------------------------------------------------------------


class TestAsyncDeletionReceipts:
    @respx.mock
    async def test_list_deletion_receipts(self):
        respx.get(f"{BASE}/v1/deletion-receipts").mock(
            return_value=httpx.Response(200, json={
                "receipts": [{"receipt_id": "r1", "scope": {"user_id": "u1"}, "requested_at": "t", "completed_at": "t", "deleted_counts": {"events": 0, "chunks": 1, "episodes": 0, "facts": 0, "claims": 0, "open_loops": 0}}],
                "total": 1, "limit": 20, "offset": 0,
            })
        )
        client = make_client()
        result = await client.list_deletion_receipts()
        assert result["total"] == 1
        assert result["receipts"][0]["receipt_id"] == "r1"
        await client.close()

    @respx.mock
    async def test_get_deletion_receipt(self):
        respx.get(f"{BASE}/v1/deletion-receipts/r1").mock(
            return_value=httpx.Response(200, json={
                "receipt_id": "r1", "scope": {"user_id": "u1"}, "requested_at": "t", "completed_at": "t",
                "deleted_counts": {"events": 0, "chunks": 3, "episodes": 0, "facts": 0, "claims": 0, "open_loops": 0},
            })
        )
        client = make_client()
        result = await client.get_deletion_receipt("r1")
        assert result["receipt_id"] == "r1"
        assert result["deleted_counts"]["chunks"] == 3
        await client.close()
