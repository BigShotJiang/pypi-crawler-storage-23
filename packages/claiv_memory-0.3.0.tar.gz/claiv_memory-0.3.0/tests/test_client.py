"""Tests for the synchronous ClaivClient."""

import httpx
import pytest
import respx

from claiv import ClaivClient, ClaivApiError, ClaivTimeoutError, ClaivNetworkError

BASE = "https://api.test.com"


def make_client(**kwargs) -> ClaivClient:
    return ClaivClient(api_key="test-key-123", base_url=BASE, **kwargs)


# ---------------------------------------------------------------------------
# Constructor
# ---------------------------------------------------------------------------


class TestConstructor:
    def test_raises_on_empty_api_key(self):
        with pytest.raises(ValueError, match="api_key is required"):
            ClaivClient(api_key="", base_url=BASE)

    def test_raises_on_invalid_timeout(self):
        with pytest.raises(ValueError, match="timeout must be a positive number"):
            ClaivClient(api_key="k", base_url=BASE, timeout=0)

    def test_raises_on_invalid_max_retries(self):
        with pytest.raises(ValueError, match="max_retries must be a non-negative integer"):
            ClaivClient(api_key="k", base_url=BASE, max_retries=-1)

    def test_strips_trailing_slashes(self):
        with respx.mock:
            respx.get(f"{BASE}/healthz").mock(
                return_value=httpx.Response(200, json={"ok": True})
            )
            client = ClaivClient(api_key="k", base_url=BASE + "///")
            result = client.health_check()
            assert result == {"ok": True}


# ---------------------------------------------------------------------------
# Authentication
# ---------------------------------------------------------------------------


class TestAuth:
    @respx.mock
    def test_sends_bearer_token(self):
        route = respx.post(f"{BASE}/v1/ingest").mock(
            return_value=httpx.Response(200, json={"event_id": "e1", "deduped": False})
        )
        client = make_client()
        client.ingest({"user_id": "u1", "type": "message", "content": "hi"})

        assert route.called
        req = route.calls[0].request
        assert req.headers["authorization"] == "Bearer test-key-123"

    @respx.mock
    def test_no_auth_on_health_check(self):
        route = respx.get(f"{BASE}/healthz").mock(
            return_value=httpx.Response(200, json={"ok": True})
        )
        client = make_client()
        client.health_check()

        req = route.calls[0].request
        assert "authorization" not in req.headers


# ---------------------------------------------------------------------------
# Ingest
# ---------------------------------------------------------------------------


class TestIngest:
    @respx.mock
    def test_full_ingest_request(self):
        route = respx.post(f"{BASE}/v1/ingest").mock(
            return_value=httpx.Response(200, json={"event_id": "evt-abc", "deduped": False})
        )
        client = make_client()
        result = client.ingest({
            "user_id": "user-1",
            "thread_id": "thread-1",
            "type": "message",
            "content": "Hello world",
            "metadata": {"source": "test"},
            "event_time": "2025-01-01T00:00:00Z",
            "idempotency_key": "idem-1",
        })

        assert result == {"event_id": "evt-abc", "deduped": False}
        body = route.calls[0].request.content
        import json
        parsed = json.loads(body)
        assert parsed["user_id"] == "user-1"
        assert parsed["idempotency_key"] == "idem-1"

    @respx.mock
    def test_minimal_ingest(self):
        respx.post(f"{BASE}/v1/ingest").mock(
            return_value=httpx.Response(200, json={"event_id": "e2", "deduped": False})
        )
        client = make_client()
        result = client.ingest({"user_id": "u1", "type": "app_event", "content": "test"})
        assert result["event_id"] == "e2"

    @respx.mock
    def test_deduped_response(self):
        respx.post(f"{BASE}/v1/ingest").mock(
            return_value=httpx.Response(200, json={"event_id": "evt-existing", "deduped": True})
        )
        client = make_client()
        result = client.ingest({
            "user_id": "u1",
            "type": "message",
            "content": "test",
            "idempotency_key": "dup-key",
        })
        assert result["deduped"] is True


# ---------------------------------------------------------------------------
# Recall
# ---------------------------------------------------------------------------


class TestRecall:
    @respx.mock
    def test_full_recall(self):
        response_body = {
            "system_context": "You are an assistant.",
            "memory_blocks": [
                {"type": "claim", "content": "User prefers dark mode", "source_ids": ["e1"], "score": 3.5},
                {"type": "episode", "content": "Discussed project", "source_ids": ["e2", "e3"], "score": 2.1},
            ],
            "citations": ["e1", "e2", "e3"],
            "token_estimate": 45,
        }
        respx.post(f"{BASE}/v1/recall").mock(
            return_value=httpx.Response(200, json=response_body)
        )
        client = make_client()
        result = client.recall({
            "user_id": "user-1",
            "thread_id": "thread-1",
            "task": "Help configure editor",
            "token_budget": 2000,
            "scope": {"project": "claiv"},
        })
        assert result == response_body
        assert len(result["memory_blocks"]) == 2

    @respx.mock
    def test_empty_recall(self):
        respx.post(f"{BASE}/v1/recall").mock(
            return_value=httpx.Response(200, json={
                "system_context": "No memories.",
                "memory_blocks": [],
                "citations": [],
                "token_estimate": 5,
            })
        )
        client = make_client()
        result = client.recall({"user_id": "u1", "task": "obscure", "token_budget": 200})
        assert result["memory_blocks"] == []
        assert result["citations"] == []


# ---------------------------------------------------------------------------
# Forget
# ---------------------------------------------------------------------------


class TestForget:
    @respx.mock
    def test_full_forget(self):
        response_body = {
            "receipt_id": "rcpt-123",
            "deleted_counts": {
                "events": 0, "chunks": 5, "episodes": 2,
                "facts": 1, "claims": 3, "open_loops": 0,
            },
        }
        respx.post(f"{BASE}/v1/forget").mock(
            return_value=httpx.Response(200, json=response_body)
        )
        client = make_client()
        result = client.forget({
            "user_id": "user-1",
            "thread_id": "thread-1",
            "from_time": "2025-01-01T00:00:00Z",
            "to_time": "2025-06-01T00:00:00Z",
        })
        assert result == response_body

    @respx.mock
    def test_minimal_forget(self):
        respx.post(f"{BASE}/v1/forget").mock(
            return_value=httpx.Response(200, json={
                "receipt_id": "r2",
                "deleted_counts": {
                    "events": 0, "chunks": 0, "episodes": 0,
                    "facts": 0, "claims": 0, "open_loops": 0,
                },
            })
        )
        client = make_client()
        result = client.forget({"user_id": "u1"})
        assert result["receipt_id"] == "r2"


# ---------------------------------------------------------------------------
# Usage
# ---------------------------------------------------------------------------


class TestUsage:
    @respx.mock
    def test_get_usage_summary(self):
        response_body = {
            "range": "30d",
            "start_date": "2025-05-01",
            "end_date": "2025-05-30",
            "totals": {
                "requests": 100, "ingest_requests": 60, "recall_requests": 30,
                "forget_requests": 10, "ingest_events": 60, "tokens": 50000,
                "work_units": 200, "errors": 2, "request_bytes": 10000, "response_bytes": 50000,
            },
            "daily": [
                {"date": "2025-05-30", "requests": 10, "ingest_events": 5,
                 "tokens": 5000, "work_units": 20, "errors": 0},
            ],
        }
        route = respx.get(f"{BASE}/v1/usage/summary").mock(
            return_value=httpx.Response(200, json=response_body)
        )
        client = make_client()
        result = client.get_usage_summary("30d")
        assert result == response_body
        assert "range=30d" in str(route.calls[0].request.url)

    @respx.mock
    def test_get_usage_summary_default_range(self):
        route = respx.get(f"{BASE}/v1/usage/summary").mock(
            return_value=httpx.Response(200, json={
                "range": "7d", "start_date": "", "end_date": "", "totals": {}, "daily": [],
            })
        )
        client = make_client()
        client.get_usage_summary()
        assert "range=7d" in str(route.calls[0].request.url)

    @respx.mock
    def test_get_usage_breakdown(self):
        response_body = {
            "range": "today",
            "start_date": "2025-05-30",
            "end_date": "2025-05-30",
            "endpoints": [
                {"endpoint": "/v1/ingest", "requests": 50, "errors": 1,
                 "error_rate": 2.0, "avg_latency_ms": 15},
            ],
        }
        route = respx.get(f"{BASE}/v1/usage/breakdown").mock(
            return_value=httpx.Response(200, json=response_body)
        )
        client = make_client()
        result = client.get_usage_breakdown("today")
        assert result == response_body
        assert "range=today" in str(route.calls[0].request.url)

    @respx.mock
    def test_get_usage_limits(self):
        response_body = {
            "plan": "pro",
            "billing_cycle_day": 1,
            "reset_date": "2025-06-01T00:00:00Z",
            "is_within_quota": True,
            "limits": {
                "requests": {"used": 100, "limit": 10000, "remaining": 9900, "percentage_used": 1},
                "tokens": {"used": 50000, "limit": 1000000, "remaining": 950000, "percentage_used": 5},
                "work_units": {"used": 200, "limit": None, "remaining": None, "percentage_used": 0},
                "ingest_events": {"used": 60, "limit": 5000, "remaining": 4940, "percentage_used": 1.2},
            },
        }
        respx.get(f"{BASE}/v1/usage/limits").mock(
            return_value=httpx.Response(200, json=response_body)
        )
        client = make_client()
        result = client.get_usage_limits()
        assert result == response_body


# ---------------------------------------------------------------------------
# Health Check
# ---------------------------------------------------------------------------


class TestHealthCheck:
    @respx.mock
    def test_health_check(self):
        respx.get(f"{BASE}/healthz").mock(
            return_value=httpx.Response(200, json={"ok": True})
        )
        client = make_client()
        result = client.health_check()
        assert result == {"ok": True}


# ---------------------------------------------------------------------------
# Error handling
# ---------------------------------------------------------------------------


class TestErrors:
    @respx.mock
    def test_400_validation_error(self):
        error_body = {
            "error": {
                "code": "invalid_request",
                "message": "Validation failed",
                "request_id": "aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee",
                "details": [{"path": ["content"], "message": "Required"}],
            }
        }
        respx.post(f"{BASE}/v1/ingest").mock(
            return_value=httpx.Response(400, json=error_body)
        )
        client = make_client()
        with pytest.raises(ClaivApiError) as exc_info:
            client.ingest({"user_id": "u1", "type": "message", "content": ""})

        err = exc_info.value
        assert err.status == 400
        assert err.code == "invalid_request"
        assert err.request_id == "aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee"
        assert err.details == [{"path": ["content"], "message": "Required"}]
        assert str(err) == "Validation failed"

    @respx.mock
    def test_401_unauthorized(self):
        respx.post(f"{BASE}/v1/recall").mock(
            return_value=httpx.Response(401, json={
                "error": {
                    "code": "unauthorized",
                    "message": "Invalid API key",
                    "request_id": "11111111-2222-3333-4444-555555555555",
                }
            })
        )
        client = make_client()
        with pytest.raises(ClaivApiError) as exc_info:
            client.recall({"user_id": "u1", "task": "test", "token_budget": 500})
        assert exc_info.value.status == 401
        assert exc_info.value.code == "unauthorized"

    @respx.mock
    def test_429_quota_exceeded(self):
        respx.post(f"{BASE}/v1/ingest").mock(
            return_value=httpx.Response(429, json={
                "error": {
                    "code": "quota_exceeded",
                    "message": "Monthly quota exceeded",
                    "request_id": "66666666-7777-8888-9999-aaaaaaaaaaaa",
                    "details": {"plan": "free"},
                }
            })
        )
        client = make_client(max_retries=0)
        with pytest.raises(ClaivApiError) as exc_info:
            client.ingest({"user_id": "u1", "type": "message", "content": "x"})
        assert exc_info.value.status == 429
        assert exc_info.value.code == "quota_exceeded"
        assert exc_info.value.details is not None

    @respx.mock
    def test_500_internal_error(self):
        respx.post(f"{BASE}/v1/forget").mock(
            return_value=httpx.Response(500, json={
                "error": {
                    "code": "internal_error",
                    "message": "Something went wrong",
                    "request_id": "bbbbbbbb-cccc-dddd-eeee-ffffffffffff",
                }
            })
        )
        client = make_client(max_retries=0)
        with pytest.raises(ClaivApiError) as exc_info:
            client.forget({"user_id": "u1"})
        assert exc_info.value.status == 500
        assert exc_info.value.code == "internal_error"

    @respx.mock
    def test_non_json_error_response(self):
        respx.post(f"{BASE}/v1/ingest").mock(
            return_value=httpx.Response(502, text="Bad Gateway")
        )
        client = make_client(max_retries=0)
        with pytest.raises(ClaivApiError) as exc_info:
            client.ingest({"user_id": "u1", "type": "message", "content": "x"})
        assert exc_info.value.status == 502
        assert exc_info.value.code == "unknown"

    @respx.mock
    def test_timeout_error(self):
        respx.post(f"{BASE}/v1/ingest").mock(side_effect=httpx.ReadTimeout("timed out"))
        client = make_client(timeout=1.0)
        with pytest.raises(ClaivTimeoutError):
            client.ingest({"user_id": "u1", "type": "message", "content": "x"})

    @respx.mock
    def test_network_error(self):
        respx.post(f"{BASE}/v1/ingest").mock(
            side_effect=httpx.ConnectError("connection refused")
        )
        client = make_client()
        with pytest.raises(ClaivNetworkError) as exc_info:
            client.ingest({"user_id": "u1", "type": "message", "content": "x"})
        assert "connection refused" in str(exc_info.value)


# ---------------------------------------------------------------------------
# Context manager
# ---------------------------------------------------------------------------


class TestContextManager:
    @respx.mock
    def test_with_statement(self):
        respx.get(f"{BASE}/healthz").mock(
            return_value=httpx.Response(200, json={"ok": True})
        )
        with ClaivClient(api_key="key", base_url=BASE) as client:
            result = client.health_check()
            assert result == {"ok": True}


# ---------------------------------------------------------------------------
# Retry behavior
# ---------------------------------------------------------------------------

ERR_500 = {"error": {"code": "internal_error", "message": "fail", "request_id": "r1"}}
OK_INGEST = {"event_id": "e1", "deduped": False}


class TestRetries:
    @respx.mock
    def test_retries_on_500_then_succeeds(self, monkeypatch):
        monkeypatch.setattr("claiv.client.time.sleep", lambda _: None)
        route = respx.post(f"{BASE}/v1/ingest").mock(
            side_effect=[
                httpx.Response(500, json=ERR_500),
                httpx.Response(200, json=OK_INGEST),
            ]
        )
        client = make_client(max_retries=2)
        result = client.ingest({"user_id": "u1", "type": "message", "content": "hi"})
        assert result == OK_INGEST
        assert route.call_count == 2

    @respx.mock
    def test_retries_on_429_then_succeeds(self, monkeypatch):
        monkeypatch.setattr("claiv.client.time.sleep", lambda _: None)
        route = respx.post(f"{BASE}/v1/ingest").mock(
            side_effect=[
                httpx.Response(429, json={"error": {"code": "rate_limited", "message": "slow down", "request_id": "r1"}}),
                httpx.Response(200, json=OK_INGEST),
            ]
        )
        client = make_client(max_retries=2)
        result = client.ingest({"user_id": "u1", "type": "message", "content": "hi"})
        assert result == OK_INGEST
        assert route.call_count == 2

    @respx.mock
    def test_retries_on_502_503_504(self, monkeypatch):
        monkeypatch.setattr("claiv.client.time.sleep", lambda _: None)
        route = respx.post(f"{BASE}/v1/ingest").mock(
            side_effect=[
                httpx.Response(502, json=ERR_500),
                httpx.Response(503, json=ERR_500),
                httpx.Response(200, json=OK_INGEST),
            ]
        )
        client = make_client(max_retries=2)
        result = client.ingest({"user_id": "u1", "type": "message", "content": "hi"})
        assert result == OK_INGEST
        assert route.call_count == 3

    @respx.mock
    def test_no_retry_on_400(self):
        route = respx.post(f"{BASE}/v1/ingest").mock(
            return_value=httpx.Response(400, json={"error": {"code": "invalid_request", "message": "bad", "request_id": "r1"}})
        )
        client = make_client(max_retries=2)
        with pytest.raises(ClaivApiError) as exc_info:
            client.ingest({"user_id": "u1", "type": "message", "content": "hi"})
        assert exc_info.value.status == 400
        assert route.call_count == 1

    @respx.mock
    def test_no_retry_on_401(self):
        route = respx.post(f"{BASE}/v1/recall").mock(
            return_value=httpx.Response(401, json={"error": {"code": "unauthorized", "message": "bad key", "request_id": "r1"}})
        )
        client = make_client(max_retries=2)
        with pytest.raises(ClaivApiError) as exc_info:
            client.recall({"user_id": "u1", "task": "t", "token_budget": 500})
        assert exc_info.value.status == 401
        assert route.call_count == 1

    @respx.mock
    def test_exhausts_retries(self, monkeypatch):
        monkeypatch.setattr("claiv.client.time.sleep", lambda _: None)
        route = respx.post(f"{BASE}/v1/ingest").mock(
            return_value=httpx.Response(500, json=ERR_500)
        )
        client = make_client(max_retries=2)
        with pytest.raises(ClaivApiError) as exc_info:
            client.ingest({"user_id": "u1", "type": "message", "content": "hi"})
        assert exc_info.value.status == 500
        # 1 initial + 2 retries = 3 total
        assert route.call_count == 3

    @respx.mock
    def test_max_retries_zero_disables(self):
        route = respx.post(f"{BASE}/v1/ingest").mock(
            return_value=httpx.Response(500, json=ERR_500)
        )
        client = make_client(max_retries=0)
        with pytest.raises(ClaivApiError):
            client.ingest({"user_id": "u1", "type": "message", "content": "hi"})
        assert route.call_count == 1

    @respx.mock
    def test_invalid_retry_after_details_does_not_crash(self, monkeypatch):
        monkeypatch.setattr("claiv.client.time.sleep", lambda _: None)
        route = respx.post(f"{BASE}/v1/ingest").mock(
            side_effect=[
                httpx.Response(429, json={
                    "error": {
                        "code": "rate_limited",
                        "message": "slow down",
                        "request_id": "r1",
                        "details": {"retry_after": "not-a-number"},
                    }
                }),
                httpx.Response(200, json=OK_INGEST),
            ]
        )
        client = make_client(max_retries=1)
        result = client.ingest({"user_id": "u1", "type": "message", "content": "hi"})
        assert result == OK_INGEST
        assert route.call_count == 2


# ---------------------------------------------------------------------------
# Deletion receipts
# ---------------------------------------------------------------------------

RECEIPT_LIST = {
    "receipts": [
        {
            "receipt_id": "r1",
            "scope": {"user_id": "u1", "thread_id": None, "from_time": None, "to_time": None},
            "requested_at": "2026-02-05T20:00:00Z",
            "completed_at": "2026-02-05T20:00:00Z",
            "deleted_counts": {"events": 0, "chunks": 3, "episodes": 1, "facts": 2, "claims": 0, "open_loops": 0},
        },
    ],
    "total": 1,
    "limit": 20,
    "offset": 0,
}

SINGLE_RECEIPT = {
    "receipt_id": "r1",
    "scope": {"user_id": "u1"},
    "requested_at": "2026-02-05T20:00:00Z",
    "completed_at": "2026-02-05T20:00:00Z",
    "deleted_counts": {"events": 0, "chunks": 5, "episodes": 0, "facts": 0, "claims": 3, "open_loops": 0},
}


class TestDeletionReceipts:
    @respx.mock
    def test_list_deletion_receipts(self):
        route = respx.get(f"{BASE}/v1/deletion-receipts").mock(
            return_value=httpx.Response(200, json=RECEIPT_LIST)
        )
        client = make_client()
        result = client.list_deletion_receipts()
        assert result["total"] == 1
        assert result["receipts"][0]["receipt_id"] == "r1"
        assert "limit=20" in str(route.calls[0].request.url)

    @respx.mock
    def test_list_deletion_receipts_with_user_id(self):
        route = respx.get(f"{BASE}/v1/deletion-receipts").mock(
            return_value=httpx.Response(200, json=RECEIPT_LIST)
        )
        client = make_client()
        client.list_deletion_receipts(user_id="u1", limit=10, offset=5)
        url = str(route.calls[0].request.url)
        assert "user_id=u1" in url
        assert "limit=10" in url
        assert "offset=5" in url

    @respx.mock
    def test_get_deletion_receipt(self):
        respx.get(f"{BASE}/v1/deletion-receipts/r1").mock(
            return_value=httpx.Response(200, json=SINGLE_RECEIPT)
        )
        client = make_client()
        result = client.get_deletion_receipt("r1")
        assert result["receipt_id"] == "r1"
        assert result["deleted_counts"]["chunks"] == 5

    @respx.mock
    def test_get_deletion_receipt_not_found(self):
        respx.get(f"{BASE}/v1/deletion-receipts/missing").mock(
            return_value=httpx.Response(404, json={
                "error": {"code": "not_found", "message": "Not found", "request_id": "r1"},
            })
        )
        client = make_client(max_retries=0)
        with pytest.raises(ClaivApiError) as exc_info:
            client.get_deletion_receipt("missing")
        assert exc_info.value.status == 404
