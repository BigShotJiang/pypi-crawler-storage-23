"""Error classes for the Claiv Memory SDK."""

from __future__ import annotations

from typing import Any


class ClaivError(Exception):
    """Base error for all Claiv SDK errors."""


class ClaivApiError(ClaivError):
    """Raised when the API returns an error response (4xx / 5xx)."""

    def __init__(self, status: int, body: dict[str, Any]) -> None:
        error = body.get("error", {})
        self.status: int = status
        self.code: str = error.get("code", "unknown")
        self.request_id: str = error.get("request_id", "")
        self.details: Any = error.get("details")
        super().__init__(error.get("message", f"HTTP {status}"))


class ClaivTimeoutError(ClaivError):
    """Raised when a request times out."""

    def __init__(self, timeout_seconds: float) -> None:
        self.timeout_seconds = timeout_seconds
        super().__init__(f"Request timed out after {timeout_seconds}s")


class ClaivNetworkError(ClaivError):
    """Raised on network-level errors (DNS failure, connection refused, etc.)."""

    def __init__(self, cause: Exception) -> None:
        self.cause = cause
        super().__init__(f"Network error: {cause}")
