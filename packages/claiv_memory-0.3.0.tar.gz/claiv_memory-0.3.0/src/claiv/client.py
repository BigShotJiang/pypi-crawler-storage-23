"""Claiv Memory API client."""

from __future__ import annotations

import asyncio
import random
import time
from typing import Any

import httpx

from claiv.errors import ClaivApiError, ClaivNetworkError, ClaivTimeoutError
from claiv.types import (
    DeletionReceipt,
    ForgetRequest,
    ForgetResponse,
    IngestRequest,
    IngestResponse,
    ListDeletionReceiptsResponse,
    RecallRequest,
    RecallResponse,
    V2RecallRequest,
    V2RecallResponse,
    V2ForgetRequest,
    V2ForgetResponse,
    V3IngestRequest,
    V3RecallRequest,
    V3RecallResponse,
    V3ForgetRequest,
    V3ForgetResponse,
    V3FeedbackRequest,
    V3FeedbackResponse,
    UsageBreakdownResponse,
    UsageLimitsResponse,
    UsageRange,
    UsageSummaryResponse,
)

_DEFAULT_BASE_URL = "https://api.claiv.io"
_DEFAULT_TIMEOUT = 30.0
_DEFAULT_MAX_RETRIES = 2
_INITIAL_BACKOFF_S = 0.5
_MAX_BACKOFF_S = 30.0
_RETRYABLE_STATUS_CODES = frozenset({429, 500, 502, 503, 504})


def _get_backoff_s(attempt: int, error: ClaivApiError) -> float:
    """Compute backoff delay for a retry attempt."""
    # Respect retry_after from API details if present
    if error.details and isinstance(error.details, dict):
        retry_after = error.details.get("retry_after")
        if retry_after is not None:
            try:
                val = float(retry_after)
            except (TypeError, ValueError):
                val = 0.0
            if val > 0:
                return min(val, _MAX_BACKOFF_S)

    # Exponential backoff with jitter
    base = _INITIAL_BACKOFF_S * (2 ** (attempt - 1))
    jitter = base * 0.5 * random.random()
    return min(base + jitter, _MAX_BACKOFF_S)


class ClaivClient:
    """Synchronous client for the Claiv Memory API.

    Parameters
    ----------
    api_key:
        API key for authentication (sent as Bearer token).
    base_url:
        Base URL of the Claiv Memory API. Defaults to ``https://api.claiv.io``.
    timeout:
        Request timeout in seconds. Defaults to 30.
    max_retries:
        Maximum number of retries on 429 and 5xx errors. Set to 0 to disable.
        Defaults to 2.
    http_client:
        Optional pre-configured ``httpx.Client``. When provided, *base_url*
        and *timeout* are ignored and the caller owns the client lifecycle.
    """

    def __init__(
        self,
        *,
        api_key: str,
        base_url: str = _DEFAULT_BASE_URL,
        timeout: float = _DEFAULT_TIMEOUT,
        max_retries: int = _DEFAULT_MAX_RETRIES,
        http_client: httpx.Client | None = None,
    ) -> None:
        if not api_key:
            raise ValueError("api_key is required")
        if timeout <= 0:
            raise ValueError("timeout must be a positive number")
        if not isinstance(max_retries, int) or max_retries < 0:
            raise ValueError("max_retries must be a non-negative integer")
        self._api_key = api_key
        self._max_retries = max_retries
        self._timeout = timeout
        self._owns_client = http_client is None
        self._client = http_client or httpx.Client(
            base_url=base_url.rstrip("/"),
            timeout=timeout,
        )

    # -- lifecycle -----------------------------------------------------------

    def close(self) -> None:
        """Close the underlying HTTP transport (only if we created it)."""
        if self._owns_client:
            self._client.close()

    def __enter__(self) -> "ClaivClient":
        return self

    def __exit__(self, *_: Any) -> None:
        self.close()

    # -- core endpoints ------------------------------------------------------

    def ingest(self, request: IngestRequest) -> IngestResponse:
        """Ingest a memory event.

        Stores context your AI should remember. Returns immediately;
        enrichment happens asynchronously on the server.
        """
        return self._post("/v1/ingest", request)

    def recall(self, request: RecallRequest) -> RecallResponse:
        """Recall relevant memory for a task.

        Returns ranked memory blocks within the specified token budget,
        along with citations linking each block to its source event.
        """
        return self._post("/v1/recall", request)

    def forget(self, request: ForgetRequest) -> ForgetResponse:
        """Delete memory matching the given scope.

        Returns a receipt with deletion counts.
        """
        return self._post("/v1/forget", request)

    # -- V2 endpoints (assertion-based memory) --------------------------------

    def recall_v2(self, request: V2RecallRequest) -> V2RecallResponse:
        """V2 Recall: retrieve assertion-based memory with evidence."""
        return self._post("/v2/recall", request)

    def forget_v2(self, request: V2ForgetRequest) -> V2ForgetResponse:
        """V2 Forget: delete assertion-based memory."""
        return self._post("/v2/forget", request)

    # -- V3 endpoints (priority memory + retention + feedback loop) -----------

    def ingest_v3(self, request: V3IngestRequest) -> IngestResponse:
        """V3 Ingest: store a memory event with an optional retention policy.

        retention_policy values:
          - 'standard'   — normal 30-day grace-period deletion (default)
          - 'ephemeral'  — excluded from long-term memory
          - 'legal_hold' — protected from deletion until hold is released
        """
        return self._post("/v3/ingest", request)

    def recall_v3(self, request: V3RecallRequest) -> V3RecallResponse:
        """V3 Recall: retrieve priority-scored memory with freshness metadata.

        Response includes recall_id (use with feedback_v3), as_of timestamp,
        ingestion_lag_seconds, and per-block score breakdowns.
        """
        return self._post("/v3/recall", request)

    def forget_v3(self, request: V3ForgetRequest) -> V3ForgetResponse:
        """V3 Forget: tombstone memory matching the given scope.

        By default, events are soft-deleted with a 30-day grace period.
        Pass immediate=True to skip the grace period.
        Raises ClaivApiError(409) if a legal hold blocks deletion.
        """
        return self._post("/v3/forget", request)

    def feedback_v3(self, recall_id: str, request: V3FeedbackRequest) -> V3FeedbackResponse:
        """V3 Feedback: record which memory blocks were actually used.

        Call this after using recalled memory in a response. Pass the
        source_ids from the V3RecallResponse blocks you referenced.
        This improves future recall scoring via the verified_boost dimension.
        """
        return self._post(f"/v3/recall/{recall_id}/feedback", request)

    # -- deletion receipts ---------------------------------------------------

    def list_deletion_receipts(
        self,
        *,
        user_id: str | None = None,
        limit: int = 20,
        offset: int = 0,
    ) -> ListDeletionReceiptsResponse:
        """List deletion receipts, newest first."""
        params: dict[str, str] = {"limit": str(limit), "offset": str(offset)}
        if user_id is not None:
            params["user_id"] = user_id
        return self._get("/v1/deletion-receipts", params=params)

    def get_deletion_receipt(self, receipt_id: str) -> DeletionReceipt:
        """Get a single deletion receipt by ID."""
        return self._get(f"/v1/deletion-receipts/{receipt_id}")

    # -- usage endpoints -----------------------------------------------------

    def get_usage_summary(self, range: UsageRange = "7d") -> UsageSummaryResponse:
        """Get aggregated usage summary with daily breakdown."""
        return self._get("/v1/usage/summary", params={"range": range})

    def get_usage_breakdown(self, range: UsageRange = "7d") -> UsageBreakdownResponse:
        """Get usage breakdown by endpoint."""
        return self._get("/v1/usage/breakdown", params={"range": range})

    def get_usage_limits(self) -> UsageLimitsResponse:
        """Get current plan limits and quota status."""
        return self._get("/v1/usage/limits")

    # -- health --------------------------------------------------------------

    def health_check(self) -> dict[str, bool]:
        """Check if the API is reachable. Does not require authentication."""
        return self._request("GET", "/healthz", auth=False)

    # -- internals -----------------------------------------------------------

    def _post(self, path: str, body: dict[str, Any]) -> Any:
        return self._request("POST", path, json=body, auth=True)

    def _get(self, path: str, params: dict[str, str] | None = None) -> Any:
        return self._request("GET", path, params=params, auth=True)

    def _request(
        self,
        method: str,
        path: str,
        *,
        json: dict[str, Any] | None = None,
        params: dict[str, str] | None = None,
        auth: bool = True,
    ) -> Any:
        headers: dict[str, str] = {"Accept": "application/json"}
        if auth:
            headers["Authorization"] = f"Bearer {self._api_key}"

        last_error: ClaivApiError | None = None

        for attempt in range(self._max_retries + 1):
            if attempt > 0 and last_error is not None:
                time.sleep(_get_backoff_s(attempt, last_error))

            try:
                resp = self._client.request(
                    method,
                    path,
                    json=json,
                    params=params,
                    headers=headers,
                )
            except httpx.TimeoutException as exc:
                raise ClaivTimeoutError(self._timeout) from exc
            except httpx.HTTPError as exc:
                raise ClaivNetworkError(exc) from exc

            if resp.status_code < 400:
                return resp.json()

            try:
                body = resp.json()
            except Exception:
                body = {
                    "error": {
                        "code": "unknown",
                        "message": resp.reason_phrase or f"HTTP {resp.status_code}",
                        "request_id": "00000000-0000-0000-0000-000000000000",
                    }
                }

            last_error = ClaivApiError(resp.status_code, body)

            if resp.status_code not in _RETRYABLE_STATUS_CODES or attempt == self._max_retries:
                raise last_error

        # Unreachable, but satisfies type checkers
        raise last_error  # type: ignore[misc]


class AsyncClaivClient:
    """Async client for the Claiv Memory API.

    Same interface as :class:`ClaivClient` but all methods are ``async``.

    Parameters
    ----------
    api_key:
        API key for authentication (sent as Bearer token).
    base_url:
        Base URL of the Claiv Memory API.
    timeout:
        Request timeout in seconds. Defaults to 30.
    max_retries:
        Maximum number of retries on 429 and 5xx errors. Set to 0 to disable.
        Defaults to 2.
    http_client:
        Optional pre-configured ``httpx.AsyncClient``.
    """

    def __init__(
        self,
        *,
        api_key: str,
        base_url: str = _DEFAULT_BASE_URL,
        timeout: float = _DEFAULT_TIMEOUT,
        max_retries: int = _DEFAULT_MAX_RETRIES,
        http_client: httpx.AsyncClient | None = None,
    ) -> None:
        if not api_key:
            raise ValueError("api_key is required")
        if timeout <= 0:
            raise ValueError("timeout must be a positive number")
        if not isinstance(max_retries, int) or max_retries < 0:
            raise ValueError("max_retries must be a non-negative integer")
        self._api_key = api_key
        self._max_retries = max_retries
        self._timeout = timeout
        self._owns_client = http_client is None
        self._client = http_client or httpx.AsyncClient(
            base_url=base_url.rstrip("/"),
            timeout=timeout,
        )

    # -- lifecycle -----------------------------------------------------------

    async def close(self) -> None:
        if self._owns_client:
            await self._client.aclose()

    async def __aenter__(self) -> "AsyncClaivClient":
        return self

    async def __aexit__(self, *_: Any) -> None:
        await self.close()

    # -- core endpoints ------------------------------------------------------

    async def ingest(self, request: IngestRequest) -> IngestResponse:
        """Ingest a memory event."""
        return await self._post("/v1/ingest", request)

    async def recall(self, request: RecallRequest) -> RecallResponse:
        """Recall relevant memory for a task."""
        return await self._post("/v1/recall", request)

    async def forget(self, request: ForgetRequest) -> ForgetResponse:
        """Delete memory matching the given scope."""
        return await self._post("/v1/forget", request)

    # -- V2 endpoints (assertion-based memory) --------------------------------

    async def recall_v2(self, request: V2RecallRequest) -> V2RecallResponse:
        """V2 Recall: retrieve assertion-based memory with evidence."""
        return await self._post("/v2/recall", request)

    async def forget_v2(self, request: V2ForgetRequest) -> V2ForgetResponse:
        """V2 Forget: delete assertion-based memory."""
        return await self._post("/v2/forget", request)

    # -- V3 endpoints (priority memory + retention + feedback loop) -----------

    async def ingest_v3(self, request: V3IngestRequest) -> IngestResponse:
        """V3 Ingest: store a memory event with an optional retention policy."""
        return await self._post("/v3/ingest", request)

    async def recall_v3(self, request: V3RecallRequest) -> V3RecallResponse:
        """V3 Recall: retrieve priority-scored memory with freshness metadata."""
        return await self._post("/v3/recall", request)

    async def forget_v3(self, request: V3ForgetRequest) -> V3ForgetResponse:
        """V3 Forget: tombstone memory matching the given scope."""
        return await self._post("/v3/forget", request)

    async def feedback_v3(self, recall_id: str, request: V3FeedbackRequest) -> V3FeedbackResponse:
        """V3 Feedback: record which memory blocks were actually used."""
        return await self._post(f"/v3/recall/{recall_id}/feedback", request)

    # -- deletion receipts ---------------------------------------------------

    async def list_deletion_receipts(
        self,
        *,
        user_id: str | None = None,
        limit: int = 20,
        offset: int = 0,
    ) -> ListDeletionReceiptsResponse:
        """List deletion receipts, newest first."""
        params: dict[str, str] = {"limit": str(limit), "offset": str(offset)}
        if user_id is not None:
            params["user_id"] = user_id
        return await self._get("/v1/deletion-receipts", params=params)

    async def get_deletion_receipt(self, receipt_id: str) -> DeletionReceipt:
        """Get a single deletion receipt by ID."""
        return await self._get(f"/v1/deletion-receipts/{receipt_id}")

    # -- usage endpoints -----------------------------------------------------

    async def get_usage_summary(self, range: UsageRange = "7d") -> UsageSummaryResponse:
        """Get aggregated usage summary with daily breakdown."""
        return await self._get("/v1/usage/summary", params={"range": range})

    async def get_usage_breakdown(self, range: UsageRange = "7d") -> UsageBreakdownResponse:
        """Get usage breakdown by endpoint."""
        return await self._get("/v1/usage/breakdown", params={"range": range})

    async def get_usage_limits(self) -> UsageLimitsResponse:
        """Get current plan limits and quota status."""
        return await self._get("/v1/usage/limits")

    # -- health --------------------------------------------------------------

    async def health_check(self) -> dict[str, bool]:
        """Check if the API is reachable. Does not require authentication."""
        return await self._request("GET", "/healthz", auth=False)

    # -- internals -----------------------------------------------------------

    async def _post(self, path: str, body: dict[str, Any]) -> Any:
        return await self._request("POST", path, json=body, auth=True)

    async def _get(self, path: str, params: dict[str, str] | None = None) -> Any:
        return await self._request("GET", path, params=params, auth=True)

    async def _request(
        self,
        method: str,
        path: str,
        *,
        json: dict[str, Any] | None = None,
        params: dict[str, str] | None = None,
        auth: bool = True,
    ) -> Any:
        headers: dict[str, str] = {"Accept": "application/json"}
        if auth:
            headers["Authorization"] = f"Bearer {self._api_key}"

        last_error: ClaivApiError | None = None

        for attempt in range(self._max_retries + 1):
            if attempt > 0 and last_error is not None:
                await asyncio.sleep(_get_backoff_s(attempt, last_error))

            try:
                resp = await self._client.request(
                    method,
                    path,
                    json=json,
                    params=params,
                    headers=headers,
                )
            except httpx.TimeoutException as exc:
                raise ClaivTimeoutError(self._timeout) from exc
            except httpx.HTTPError as exc:
                raise ClaivNetworkError(exc) from exc

            if resp.status_code < 400:
                return resp.json()

            try:
                body = resp.json()
            except Exception:
                body = {
                    "error": {
                        "code": "unknown",
                        "message": resp.reason_phrase or f"HTTP {resp.status_code}",
                        "request_id": "00000000-0000-0000-0000-000000000000",
                    }
                }

            last_error = ClaivApiError(resp.status_code, body)

            if resp.status_code not in _RETRYABLE_STATUS_CODES or attempt == self._max_retries:
                raise last_error

        raise last_error  # type: ignore[misc]
