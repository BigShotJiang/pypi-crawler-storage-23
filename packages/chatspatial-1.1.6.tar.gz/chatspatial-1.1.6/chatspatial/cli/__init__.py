"""
ChatSpatial Command Line Interface module.

Provides the main CLI entry point for the ChatSpatial server.
"""

__all__: list[str] = []
