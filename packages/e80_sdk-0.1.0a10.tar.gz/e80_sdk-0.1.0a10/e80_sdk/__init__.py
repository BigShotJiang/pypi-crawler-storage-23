from .endpoint import eighty80_app as eighty80_app
from .eighty80 import Eighty80 as Eighty80
