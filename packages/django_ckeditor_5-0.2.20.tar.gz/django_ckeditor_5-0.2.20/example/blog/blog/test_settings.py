from .settings import *

# set to a small number for easier testing
CKEDITOR_5_MAX_FILE_SIZE = 0.06
