# Pylon changelog

## [0.1.2] - 2026-02-20
- Updated connector definition (YAML version 0.1.3)
- Source commit: e9e5b384
- SDK version: 0.1.0

## [0.1.1] - 2026-02-20
- Updated connector definition (YAML version 0.1.2)
- Source commit: 8177d883
- SDK version: 0.1.0

## [0.1.0] - 2026-02-20
- Updated connector definition (YAML version 0.1.1)
- Source commit: dd1a513d
- SDK version: 0.1.0
