"""python -m admin_gen_mcp  →  启动 MCP Server"""
from admin_gen_mcp._cli import run_server

run_server()
