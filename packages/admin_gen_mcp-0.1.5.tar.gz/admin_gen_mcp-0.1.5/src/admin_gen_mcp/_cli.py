"""CLI entry points (sync wrappers for async functions)."""
import asyncio

from .server import main


def run_server():
    """Sync entry point for `admin-gen-mcp` command."""
    asyncio.run(main())
