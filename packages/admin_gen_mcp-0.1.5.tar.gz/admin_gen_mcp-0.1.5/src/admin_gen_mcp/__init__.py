﻿"""
Admin Page Generator MCP Server
Vue 3 + Element Plus 鍚庡彴绠＄悊椤甸潰浠ｇ爜鐢熸垚鍣?
"""

__version__ = "0.1.5"

