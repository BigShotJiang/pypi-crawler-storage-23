/**
 * 字段属性配置
 * show - 是否显示在表格中（当alwaysHide为true一直不显示，为false再配合show动态控制）
 * smart - 是否支持智能搜索 | label - 显示名称 | width - 列宽
 */
export const dataMasterEntity = {
  billCode: { show: true, alwaysHide: false, smart: true, label: '单据编号', width: '180' },
  billState: { show: false, alwaysHide: true, smart: false, label: '单据状态', width: '0' },
  billStateId: { show: true, alwaysHide: false, smart: false, label: '单据状态ID', width: '80' },
  billDate: { show: true, alwaysHide: false, smart: false, label: '单据日期', width: '100' },
  projectCode: { show: true, alwaysHide: true, smart: true, label: '项目编号', width: '200' },
  projectId: { show: false, alwaysHide: true, smart: false, label: '项目ID', width: '0' },
  projectName: { show: true, alwaysHide: false, smart: true, label: '项目名称', width: '100' },
  ownerId: { show: false, alwaysHide: true, smart: false, label: '业主ID', width: '0' },
  ownerCreditCode: { show: true, alwaysHide: true, smart: true, label: '业主社会统一代码', width: '200' },
  owner: { show: true, alwaysHide: false, smart: true, label: '业主名称', width: '100' },
  debtProtocolType: { show: true, alwaysHide: false, smart: false, label: '抵债协议类型', width: '150' },
  contractDebtTermsFlag: { show: false, alwaysHide: false, smart: false, label: '合同是否约定抵债条款', width: '200' },
  determinationBasisOffsetValue: { show: false, alwaysHide: false, smart: false, label: '抵入价值确定依据', width: '200' },
  debtAmount: { show: true, alwaysHide: false, smart: false, label: '抵债金额', width: '130' },
  contractDebtContent: { show: false, alwaysHide: false, smart: true, label: '合同约定抵债条款内容', width: '200' },
  debtBusinessReason: { show: true, alwaysHide: false, smart: true, label: '抵债业务事由', width: '200' },
  // 附件字段（始终隐藏，仅在表单页使用）
  attachmentDebtsAssetsBusinessApply: { show: false, alwaysHide: true, smart: false, label: '附件-抵债资产业务申请表', width: '0' },
  attachmentOwnerSubcontractDistributionSettlement: { show: false, alwaysHide: true, smart: false, label: '附件-业主结算书', width: '0' },
  attachmentAssetsValuationStatement: { show: false, alwaysHide: true, smart: false, label: '附件-资产评估报告', width: '0' },
  attachmentMarketValueCertificate: { show: false, alwaysHide: true, smart: false, label: '附件-市场价值证明资料', width: '0' },
  attachmentProposedContract: { show: false, alwaysHide: true, smart: false, label: '附件-抵债协议', width: '0' },
  // 系统审计字段
  createUserId: { show: false, alwaysHide: true, smart: false, label: '填报人id', width: '0' },
  createUser: { show: true, alwaysHide: false, smart: true, label: '填报人', width: '100' },
  createPosId: { show: false, alwaysHide: true, smart: false, label: '填报岗位id', width: '0' },
  createPos: { show: false, alwaysHide: true, smart: false, label: '填报岗位', width: '0' },
  createDptId: { show: false, alwaysHide: true, smart: false, label: '填报部门id', width: '0' },
  createDpt: { show: false, alwaysHide: true, smart: false, label: '填报部门', width: '0' },
  createOgnId: { show: false, alwaysHide: true, smart: false, label: '填报单位id', width: '0' },
  createOgn: { show: false, alwaysHide: true, smart: false, label: '填报单位', width: '0' },
  createPsmFullId: { show: false, alwaysHide: true, smart: false, label: '填报人全id', width: '0' },
  createPsmFullName: { show: false, alwaysHide: true, smart: false, label: '填报人全名称', width: '0' },
  updatePsmFullId: { show: false, alwaysHide: true, smart: false, label: '修改人全id', width: '0' },
  updatePsmFullName: { show: false, alwaysHide: true, smart: false, label: '修改人全名称', width: '0' },
  createTime: { show: true, alwaysHide: false, smart: false, label: '创建时间', width: '180' },
  updateTime: { show: false, alwaysHide: true, smart: false, label: '更新时间', width: '0' },
  tenantId: { show: false, alwaysHide: true, smart: false, label: '租户ID', width: '0' },
  id: { show: false, alwaysHide: true, smart: false, label: 'ID', width: '0' },
  version: { show: false, alwaysHide: true, smart: false, label: '版本号', width: '0' },
  remark: { show: true, alwaysHide: true, smart: false, label: '备注', width: '200' },
  finishedTime: { show: false, alwaysHide: true, smart: false, label: '完成时间', width: '0' }
}

// 子表字段配置（结构同主表，子表特有系统字段：id、mainId、version）
export const dataDetailEntity = {
  id: { show: false, alwaysHide: true, smart: false, label: 'ID', width: '0' },
  mainId: { show: false, alwaysHide: true, smart: false, label: '主表ID', width: '0' },
  version: { show: false, alwaysHide: true, smart: false, label: '版本号', width: '0' },
  assetName: { show: true, alwaysHide: false, smart: true, label: '资产名称', width: '200' },
  assetClass: { show: true, alwaysHide: false, smart: false, label: '资产类别', width: '150' },
  detailInfo: { show: true, alwaysHide: false, smart: true, label: '房产坐落地址、车牌号、规格型号', width: '200' },
  transferFlag: { show: true, alwaysHide: false, smart: false, label: '是否办理权属过户', width: '250' },
  measureUnit: { show: true, alwaysHide: false, smart: true, label: '计量单位', width: '200' },
  number: { show: true, alwaysHide: false, smart: false, label: '数量', width: '130' },
  unitPrice: { show: true, alwaysHide: false, smart: false, label: '单价（含税）', width: '150' },
  valuationValue: { show: true, alwaysHide: false, smart: false, label: '评估价值（含税）', width: '200' },
  proposedOffsetValue: { show: true, alwaysHide: false, smart: false, label: '拟抵入价值（含税）', width: '200' },
  remark: { show: true, alwaysHide: false, smart: true, label: '备注', width: '200' },
  offsetAssetStatus: { show: true, alwaysHide: false, smart: true, label: '抵入资产状态', width: '150' },
  latestAssessedValue: { show: true, alwaysHide: false, smart: false, label: '最新评估价值', width: '150' },
  // 系统审计字段（配置同主表审计字段）
  createUserId: { show: false, alwaysHide: true, smart: false, label: '填报人id', width: '0' },
  createUser: { show: false, alwaysHide: true, smart: false, label: '填报人', width: '0' },
  createPosId: { show: false, alwaysHide: true, smart: false, label: '填报岗位id', width: '0' },
  createPos: { show: false, alwaysHide: true, smart: false, label: '填报岗位', width: '0' },
  createDptId: { show: false, alwaysHide: true, smart: false, label: '填报部门id', width: '0' },
  createDpt: { show: false, alwaysHide: true, smart: false, label: '填报部门', width: '0' },
  createOgnId: { show: false, alwaysHide: true, smart: false, label: '填报单位id', width: '0' },
  createOgn: { show: false, alwaysHide: true, smart: false, label: '填报单位', width: '0' },
  createPsmFullId: { show: false, alwaysHide: true, smart: false, label: '填报人全id', width: '0' },
  createPsmFullName: { show: false, alwaysHide: true, smart: false, label: '填报人全名称', width: '0' },
  updatePsmFullId: { show: false, alwaysHide: true, smart: false, label: '修改人全id', width: '0' },
  updatePsmFullName: { show: false, alwaysHide: true, smart: false, label: '修改人全名称', width: '0' },
  createTime: { show: false, alwaysHide: true, smart: false, label: '创建时间', width: '0' },
  updateTime: { show: false, alwaysHide: true, smart: false, label: '更新时间', width: '0' },
  tenantId: { show: false, alwaysHide: true, smart: false, label: '租户ID', width: '0' },
  detailProject: { show: false, alwaysHide: true, smart: false, label: '从表', width: '0' },
  assetId: { show: true, alwaysHide: false, smart: true, label: '资产ID', width: '150' },
  ownerName: { show: true, alwaysHide: false, smart: true, label: '抵入单位名称', width: '150' },
  debtDate: { show: true, alwaysHide: false, smart: false, label: '抵入时间', width: '150' },
  debtAmount: { show: true, alwaysHide: false, smart: false, label: '抵入价值', width: '130' },
  disposalProfitLoss: { show: true, alwaysHide: false, smart: false, label: '处置损益', width: '130' },
  debtProtocolType: { show: true, alwaysHide: false, smart: false, label: '抵债协议类型', width: '200' }
}

// 过滤类型配置，用于定义字典类字段的过滤行为
export const filterTypes = {
  billStateId: 30,
  debtProtocolType: 30,
  contractDebtTermsFlag: 30,
  determinationBasisOffsetValue: 30,
  debtAssetsType: 30
}
