package com.worsoft.worsoft.hr.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.worsoft.worsoft.common.core.annotation.Dict;
import com.worsoft.worsoft.common.core.base.BaseEntity;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Data
@TableName("contract_sign_batch")
@EqualsAndHashCode(callSuper = true)
@Schema(description = "合同批量签订")
public class ContractSignBatchEntity extends BaseEntity<ContractSignBatchEntity> {

	@TableId(type = IdType.ASSIGN_ID)
	@Schema(description = "id")
	private Long id;

	@Schema(description = "单据编号")
	private String billCode;

	@Schema(description = "单据状态ID")
	@Dict(value = "bill_state")
	private String billStateId;

	@Schema(description = "单据状态")
	private String billState;

	@Schema(description = "单据日期")
	private LocalDate billDate;

	// --- 业务字段示例：各种类型 ---

	@Schema(description = "人员属性")
	@Dict(value = "hr_person_attributes")
	private String attribute;

	@Schema(description = "合同类型")
	@Dict(value = "hr_contract_type")
	private String contractType;

	@Schema(description = "合同起始时间")
	private LocalDate contractStartDate;

	@Schema(description = "合同终止时间")
	private LocalDate contractEndDate;

	@Schema(description = "薪酬")
	private BigDecimal compensation;

	@Schema(description = "备注")
	private String remark;

	@Schema(description = "附件")
	private String attachment;

	@Schema(description = "租户ID")
	private Long tenantId;

	@Schema(description = "完成时间")
	private LocalDateTime finishedTime;

	// --- 子表字段（有子表时生成） ---
	@Schema(description = "从表")
	@TableField(exist = false)
	private List<ContractSignBatchDetailEntity> detailList;

	@TableField(exist = false)
	@Schema(description = "行状态.取值范围0:正常; -1:删除;")
	private Integer rowStatus = 0;
}
