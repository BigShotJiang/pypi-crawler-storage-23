## ADDED Requirements
### Requirement: Python 3.14 Compatibility
The project SHALL support Python 3.14 as a runtime environment.

#### Scenario: Install on Python 3.14
- **WHEN** a user installs namingpaper on Python 3.14
- **THEN** installation succeeds and all CLI commands are functional
