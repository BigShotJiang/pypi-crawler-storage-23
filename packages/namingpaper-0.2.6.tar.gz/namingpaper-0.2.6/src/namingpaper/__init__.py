"""namingpaper - CLI tool to rename academic papers using AI-extracted metadata."""

__version__ = "0.2.6"
