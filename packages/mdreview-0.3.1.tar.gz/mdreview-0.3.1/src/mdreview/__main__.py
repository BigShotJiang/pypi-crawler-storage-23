"""Allow running as `python -m mdreview`."""

from mdreview.cli import main

main()
