"""mdreview - Terminal UI for reviewing markdown documents."""

__version__ = "0.1.0"
