---
name: Feature Request
about: Suggest a new feature or improvement
title: ''
labels: enhancement
assignees: ''
---

## Description

<!-- What feature would you like? -->

## Use Case

<!-- Why is this useful? What problem does it solve? -->
