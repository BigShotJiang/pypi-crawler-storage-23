## Summary

<!-- Brief description of what this PR does -->

## Test Plan

- [ ] Tests pass (`pytest`)
- [ ] Linting passes (`ruff check src/`)
- [ ] Manually tested the change
