## Images

- Icon of the module is based on the Oxygen Team work and is under LGPL
  licence:
  <http://www.iconarchive.com/show/oxygen-icons-by-oxygen-icons.org.html>


The migration of this module from 17.0 to 18.0 was financially supported by:

- Camptocamp
