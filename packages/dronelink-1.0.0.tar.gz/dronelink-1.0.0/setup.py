from setuptools import setup, find_packages

setup(
    name="dronelink",
    version="1.0.0",
    author="ByIbos",
    author_email="",
    description="Serial/MAVLink drone communication library with gimbal servo control and packet framing.",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    url="https://github.com/ByIbos/dronelink",
    packages=find_packages(),
    install_requires=["pyserial"],
    python_requires=">=3.7",
    license="MIT",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Topic :: Scientific/Engineering",
        "Intended Audience :: Developers",
    ],
    keywords="drone serial mavlink gimbal servo autopilot uav communication",
)
