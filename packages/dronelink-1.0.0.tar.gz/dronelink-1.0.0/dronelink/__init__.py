"""
dronelink — Drone Communication & Gimbal Control
===================================================
Serial/MAVLink interface for sending gimbal angles,
flight commands, and heartbeats to drones and autopilots.

Quick Start:
    from dronelink import DroneLink, GimbalController
    drone = DroneLink("COM3", baudrate=115200)
    gimbal = GimbalController(drone)
    gimbal.set_angles(pan=0.5, tilt=-0.3)
"""

from dronelink.serial_link import DroneLink
from dronelink.gimbal import GimbalController

__version__ = "1.0.0"
__author__ = "ByIbos"
__all__ = ["DroneLink", "GimbalController"]
