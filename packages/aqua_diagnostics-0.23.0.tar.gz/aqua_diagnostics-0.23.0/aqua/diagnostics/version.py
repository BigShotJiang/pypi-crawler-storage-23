"""Module where to define the version of the package."""

__version__ = '0.23.0'
