from __future__ import annotations

import inspect
import json
import logging
import urllib.error
import urllib.request
from pathlib import Path
from typing import TYPE_CHECKING

from otto.config import (
    OTTO_HOME,
    BotAuthConfig,
    BotConfig,
    BotSkillsConfig,
    ChannelConfig,
    UserConfig,
    WorkspaceConfig,
    save_config,
)

if TYPE_CHECKING:
    from otto.chat import Chat, Renderer

_log = logging.getLogger(__name__)

_SETUP_STATE_KEY = "__setup_state"
_ENV_FILE = OTTO_HOME / ".env"


# ---------------------------------------------------------------------------
# State helpers
# ---------------------------------------------------------------------------


def _state_key(chat_id: str) -> str:
    return f"{_SETUP_STATE_KEY}:{chat_id}"


def _get_setup_state(chat: Chat, chat_id: str) -> dict | None:
    raw = chat._memory.get(_state_key(chat_id))
    if raw:
        return json.loads(raw)
    return None


def _set_setup_state(chat: Chat, chat_id: str, state: dict) -> None:
    chat._memory.store(_state_key(chat_id), json.dumps(state))


def _clear_setup_state(chat: Chat, chat_id: str) -> None:
    chat._memory.delete(_state_key(chat_id))


# ---------------------------------------------------------------------------
# Telegram token validation (reused from setup_flow.py pattern)
# ---------------------------------------------------------------------------


def _validate_telegram_token(token: str) -> bool:
    try:
        url = f"https://api.telegram.org/bot{token}/getMe"
        with urllib.request.urlopen(url, timeout=10) as resp:
            data = json.loads(resp.read())
            return data.get("ok", False)
    except Exception:
        return False


# ---------------------------------------------------------------------------
# .env file helpers
# ---------------------------------------------------------------------------


def _read_env_lines() -> list[str]:
    if _ENV_FILE.exists():
        return _ENV_FILE.read_text(encoding="utf-8").splitlines()
    return []


def _write_env_var(var_name: str, value: str) -> None:
    """Add or update a variable in the .env file."""
    _ENV_FILE.parent.mkdir(parents=True, exist_ok=True)
    lines = _read_env_lines()
    found = False
    new_lines = []
    for line in lines:
        stripped = line.strip()
        if stripped.startswith(f"{var_name}=") or stripped.startswith(f"export {var_name}="):
            new_lines.append(f"{var_name}={value}")
            found = True
        else:
            new_lines.append(line)
    if not found:
        new_lines.append(f"{var_name}={value}")
    _ENV_FILE.write_text("\n".join(new_lines) + "\n", encoding="utf-8")
    _ENV_FILE.chmod(0o600)


# ---------------------------------------------------------------------------
# Renderer helper
# ---------------------------------------------------------------------------


async def _send(
    renderer: Renderer, text: str, buttons: list[list[tuple[str, str]]] | None = None
) -> None:
    """Send text with optional buttons, falling back to plain text for CLI."""
    if buttons:
        try:
            result = renderer.send_with_buttons(text, buttons)
        except AttributeError:
            await renderer.send_text(text)
            return
        if inspect.isawaitable(result):
            await result
            return
        # send_with_buttons returned non-awaitable (e.g. CLI renderer) — fall through
        await renderer.send_text(text)
    else:
        await renderer.send_text(text)


# ---------------------------------------------------------------------------
# Main command entry point
# ---------------------------------------------------------------------------


async def cmd_setup(
    chat: Chat, chat_id: str, args: str, bot_id: str | None, renderer: Renderer
) -> None:
    """Handle /setup command with subcommands."""
    subcmd = args.strip().split(None, 1)[0] if args.strip() else ""

    if subcmd == "model":
        await _setup_model(chat, chat_id, bot_id, renderer)
    elif subcmd == "add" and "bot" in args:
        await _setup_add_bot(chat, chat_id, renderer)
    elif subcmd == "telegram":
        await _setup_telegram(chat, chat_id, bot_id, renderer)
    elif subcmd == "users":
        await _setup_users(chat, chat_id, renderer)
    else:
        await _setup_menu(chat, chat_id, bot_id, renderer)


# ---------------------------------------------------------------------------
# /setup (menu)
# ---------------------------------------------------------------------------


async def _setup_menu(chat: Chat, chat_id: str, bot_id: str | None, renderer: Renderer) -> None:
    text = "What do you want to configure?"
    buttons = [
        [
            ("Change model", "setup:model"),
            ("Add bot", "setup:add_bot"),
        ],
        [
            ("Telegram", "setup:telegram"),
            ("Users", "setup:users"),
        ],
    ]
    # Also build numbered list for CLI
    numbered = "What do you want to configure?\n1. Change model\n2. Add bot\n3. Telegram\n4. Users"
    try:
        result = renderer.send_with_buttons(text, buttons)
    except AttributeError:
        await renderer.send_text(numbered)
        return
    if inspect.isawaitable(result):
        await result
        return
    await renderer.send_text(numbered)


# ---------------------------------------------------------------------------
# /setup model
# ---------------------------------------------------------------------------


async def _setup_model(chat: Chat, chat_id: str, bot_id: str | None, renderer: Renderer) -> None:
    current = chat._model_overrides.get(chat_id, chat._config.agent.model)
    await renderer.send_text(f"Current model: {current}\nEnter new model name:")
    _set_setup_state(chat, chat_id, {"flow": "model", "step": "awaiting_input"})


# ---------------------------------------------------------------------------
# /setup add bot
# ---------------------------------------------------------------------------


async def _setup_add_bot(chat: Chat, chat_id: str, renderer: Renderer) -> None:
    await renderer.send_text("Enter a name for the new bot:")
    _set_setup_state(chat, chat_id, {"flow": "add_bot", "step": "awaiting_name"})


# ---------------------------------------------------------------------------
# /setup telegram
# ---------------------------------------------------------------------------


async def _setup_telegram(chat: Chat, chat_id: str, bot_id: str | None, renderer: Renderer) -> None:
    await renderer.send_text("Enter Telegram bot token (from @BotFather):")
    _set_setup_state(chat, chat_id, {"flow": "telegram", "step": "awaiting_token"})


# ---------------------------------------------------------------------------
# /setup users
# ---------------------------------------------------------------------------


async def _setup_users(chat: Chat, chat_id: str, renderer: Renderer) -> None:
    config = chat._config
    if config.users:
        lines = ["Current users:"]
        for u in config.users:
            tid = f" (telegram: {u.telegram_id})" if u.telegram_id else ""
            lines.append(f"  - {u.name}{tid}")
        lines.append("\nWant to add a user? (yes/no)")
        await renderer.send_text("\n".join(lines))
    else:
        await renderer.send_text("No users configured.\nWant to add a user? (yes/no)")
    _set_setup_state(chat, chat_id, {"flow": "users", "step": "awaiting_add_confirm"})


# ---------------------------------------------------------------------------
# Continuation handler — called from chat.handle_message
# ---------------------------------------------------------------------------


async def handle_setup_continuation(
    chat: Chat,
    chat_id: str,
    text: str,
    bot_id: str | None,
    renderer: Renderer,
    state: dict,
) -> None:
    """Process user reply within an active setup flow."""
    # /cancel exits any flow
    if text.strip().lower() in ("/cancel", "cancel"):
        _clear_setup_state(chat, chat_id)
        await renderer.send_text("Setup cancelled.")
        return

    flow = state.get("flow", "")
    if flow == "model":
        await _continue_model(chat, chat_id, text, bot_id, renderer, state)
    elif flow == "add_bot":
        await _continue_add_bot(chat, chat_id, text, renderer, state)
    elif flow == "telegram":
        await _continue_telegram(chat, chat_id, text, bot_id, renderer, state)
    elif flow == "users":
        await _continue_users(chat, chat_id, text, renderer, state)
    else:
        _clear_setup_state(chat, chat_id)
        await renderer.send_text("Unknown setup flow. Returning to normal chat.")


# ---------------------------------------------------------------------------
# Model flow continuation
# ---------------------------------------------------------------------------


async def _continue_model(
    chat: Chat,
    chat_id: str,
    text: str,
    bot_id: str | None,
    renderer: Renderer,
    state: dict,
) -> None:
    step = state.get("step", "")

    if step == "awaiting_input":
        model_name = text.strip()
        if not model_name:
            await renderer.send_text("Model name cannot be empty. Try again:")
            return
        state["model"] = model_name
        state["step"] = "awaiting_confirm"
        _set_setup_state(chat, chat_id, state)
        await renderer.send_text(f"Change model to '{model_name}'? Save these changes? (yes/no)")

    elif step == "awaiting_confirm":
        if _is_yes(text):
            model_name = state["model"]
            chat._model_overrides[chat_id] = model_name
            # Persist to config
            config = chat._config
            new_agent = type(config.agent)(
                model=model_name,
                model_list=config.agent.model_list,
                history_tool_results_keep=config.agent.history_tool_results_keep,
            )
            object.__setattr__(config, "agent", new_agent)
            try:
                save_config(config)
            except Exception:
                _log.exception("Failed to save config")
            _clear_setup_state(chat, chat_id)
            await renderer.send_text(f"Model updated to {model_name}")
        elif _is_no(text):
            _clear_setup_state(chat, chat_id)
            await renderer.send_text("Model change cancelled.")
        else:
            await renderer.send_text("Please answer yes or no.")


# ---------------------------------------------------------------------------
# Add bot flow continuation
# ---------------------------------------------------------------------------


async def _continue_add_bot(
    chat: Chat,
    chat_id: str,
    text: str,
    renderer: Renderer,
    state: dict,
) -> None:
    step = state.get("step", "")

    if step == "awaiting_name":
        name = text.strip()
        if not name:
            await renderer.send_text("Bot name cannot be empty. Try again:")
            return
        state["name"] = name
        state["step"] = "awaiting_model"
        _set_setup_state(chat, chat_id, state)
        current_model = chat._config.agent.model
        await renderer.send_text(f"Model for '{name}'? (default: {current_model})")

    elif step == "awaiting_model":
        model = text.strip() or chat._config.agent.model
        state["model"] = model
        state["step"] = "awaiting_workspace"
        _set_setup_state(chat, chat_id, state)
        default_ws = f"~/.otto/workspace/{state['name']}"
        await renderer.send_text(f"Workspace root? (default: {default_ws})")

    elif step == "awaiting_workspace":
        name = state["name"]
        default_ws = f"~/.otto/workspace/{name}"
        workspace = text.strip() or default_ws
        state["workspace"] = workspace
        state["step"] = "awaiting_confirm"
        _set_setup_state(chat, chat_id, state)
        await renderer.send_text(
            f"Create bot '{name}' with model '{state['model']}' "
            f"and workspace '{workspace}'?\n"
            f"Save these changes? (yes/no)"
        )

    elif step == "awaiting_confirm":
        if _is_yes(text):
            name = state["name"]
            model = state["model"]
            workspace = state["workspace"]
            config = chat._config

            # Determine owner — use first user if available
            owner = config.users[0].name if config.users else "user"
            allowed = [owner]

            new_bot = BotConfig(
                name=name,
                model=model,
                auth=BotAuthConfig(
                    owner=owner,
                    allowed_users=allowed,
                    bootstrap="disabled",
                ),
                workspace=WorkspaceConfig(
                    root=Path(workspace).expanduser(),
                    mode="default",
                    sandbox="none",
                ),
                skills=BotSkillsConfig(include_shared=True),
                channels=[],
            )

            new_bots = list(config.bots) + [new_bot]
            object.__setattr__(config, "bots", new_bots)
            try:
                save_config(config)
            except Exception:
                _log.exception("Failed to save config")
            _clear_setup_state(chat, chat_id)
            await renderer.send_text(f"Bot '{name}' created!")
        elif _is_no(text):
            _clear_setup_state(chat, chat_id)
            await renderer.send_text("Bot creation cancelled.")
        else:
            await renderer.send_text("Please answer yes or no.")


# ---------------------------------------------------------------------------
# Telegram flow continuation
# ---------------------------------------------------------------------------


async def _continue_telegram(
    chat: Chat,
    chat_id: str,
    text: str,
    bot_id: str | None,
    renderer: Renderer,
    state: dict,
) -> None:
    step = state.get("step", "")

    if step == "awaiting_token":
        token = text.strip()
        if not token:
            await renderer.send_text("Token cannot be empty. Try again:")
            return
        state["token"] = token
        state["step"] = "awaiting_confirm"
        _set_setup_state(chat, chat_id, state)
        await renderer.send_text(
            "Save these changes? (yes/no)\n"
            "Note: token will be written to .env and config will reference it via ${VAR}. "
            "Changes take effect after restart."
        )

    elif step == "awaiting_confirm":
        if _is_yes(text):
            token = state["token"]
            config = chat._config

            # Determine bot name for env var
            bot_name = "OTTO"
            if config.bots:
                bot_name = config.bots[0].name.upper().replace("-", "_").replace(" ", "_")

            env_var = f"TELEGRAM_{bot_name}_BOT_TOKEN"
            _write_env_var(env_var, token)

            # Add channel to first bot (or the one matching bot_id)
            target_idx = 0
            if bot_id and config.bots:
                for idx, b in enumerate(config.bots):
                    if b.name == bot_id:
                        target_idx = idx
                        break

            if config.bots:
                bot = config.bots[target_idx]
                new_channel = ChannelConfig(type="telegram", token=f"${{{env_var}}}")
                # Check if telegram channel already exists and replace, else append
                new_channels = []
                replaced = False
                for ch in bot.channels:
                    if ch.type == "telegram":
                        new_channels.append(new_channel)
                        replaced = True
                    else:
                        new_channels.append(ch)
                if not replaced:
                    new_channels.append(new_channel)

                new_bot = BotConfig(
                    name=bot.name,
                    model=bot.model,
                    auth=bot.auth,
                    workspace=bot.workspace,
                    skills=bot.skills,
                    channels=new_channels,
                )
                new_bots = list(config.bots)
                new_bots[target_idx] = new_bot
                object.__setattr__(config, "bots", new_bots)

            try:
                save_config(config)
            except Exception:
                _log.exception("Failed to save config")
            _clear_setup_state(chat, chat_id)
            await renderer.send_text(
                f"Telegram channel configured. Token saved to .env as {env_var}. "
                "Changes take effect after restart."
            )
        elif _is_no(text):
            _clear_setup_state(chat, chat_id)
            await renderer.send_text("Telegram setup cancelled.")
        else:
            await renderer.send_text("Please answer yes or no.")


# ---------------------------------------------------------------------------
# Users flow continuation
# ---------------------------------------------------------------------------


async def _continue_users(
    chat: Chat,
    chat_id: str,
    text: str,
    renderer: Renderer,
    state: dict,
) -> None:
    step = state.get("step", "")

    if step == "awaiting_add_confirm":
        if _is_yes(text):
            state["step"] = "awaiting_name"
            _set_setup_state(chat, chat_id, state)
            await renderer.send_text("Enter user name:")
        elif _is_no(text):
            _clear_setup_state(chat, chat_id)
            await renderer.send_text("User setup done.")
        else:
            await renderer.send_text("Please answer yes or no.")

    elif step == "awaiting_name":
        name = text.strip()
        if not name:
            await renderer.send_text("Name cannot be empty. Try again:")
            return
        state["user_name"] = name
        state["step"] = "awaiting_telegram_id"
        _set_setup_state(chat, chat_id, state)
        await renderer.send_text("Enter Telegram user ID (or press enter to skip):")

    elif step == "awaiting_telegram_id":
        tid_text = text.strip()
        telegram_id = None
        if tid_text:
            try:
                telegram_id = int(tid_text)
            except ValueError:
                await renderer.send_text("That doesn't look like a number. Try again:")
                return
        state["telegram_id"] = telegram_id
        state["step"] = "awaiting_user_confirm"
        _set_setup_state(chat, chat_id, state)
        tid_display = f" (telegram: {telegram_id})" if telegram_id else ""
        await renderer.send_text(
            f"Add user '{state['user_name']}'{tid_display}?\nSave these changes? (yes/no)"
        )

    elif step == "awaiting_user_confirm":
        if _is_yes(text):
            config = chat._config
            new_user = UserConfig(
                name=state["user_name"],
                telegram_id=state.get("telegram_id"),
            )
            new_users = list(config.users) + [new_user]
            object.__setattr__(config, "users", new_users)
            try:
                save_config(config)
            except Exception:
                _log.exception("Failed to save config")
            _clear_setup_state(chat, chat_id)
            await renderer.send_text(f"User '{state['user_name']}' added!")
        elif _is_no(text):
            _clear_setup_state(chat, chat_id)
            await renderer.send_text("User addition cancelled.")
        else:
            await renderer.send_text("Please answer yes or no.")


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _is_yes(text: str) -> bool:
    return text.strip().lower() in ("yes", "y", "yeah", "yep", "sure", "ok")


def _is_no(text: str) -> bool:
    return text.strip().lower() in ("no", "n", "nah", "nope")
