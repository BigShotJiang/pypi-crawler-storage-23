from enum import Enum


class Includes(Enum):
    LISTING = "listing"
