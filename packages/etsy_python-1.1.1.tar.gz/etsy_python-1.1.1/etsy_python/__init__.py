from etsy_python._version import __version__

__all__ = ["__version__"]
