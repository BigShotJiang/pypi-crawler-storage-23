"""Version information for etsy-python package."""

__version__ = "1.1.1"