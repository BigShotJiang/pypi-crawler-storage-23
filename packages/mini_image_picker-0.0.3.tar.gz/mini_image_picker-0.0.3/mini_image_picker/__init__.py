# -*- coding: utf-8 -*-
"""
mini_image_picker: 图像选点与可缩放平移视图组件（PySide6）
提供 ZoomPanLabel（主窗口选点/弹窗选点双通道）、ImagePickerWindow、PickerSession、PointPair、
get_default_config、图像标记样式 get_default_img_marker_style、ImgMarkerShowcaseWindow、ImgMarkerStyleEditorDialog、
ImgMarkerStyleEditor
"""

from .zoom_pan_label import ZoomPanLabel
from .image_picker_window import ImagePickerWindow
from .session import PickerSession
from ._data_structures import PointPair
from .config import get_default_config
from .img_marker_style import get_default_img_marker_style
from .cursor_ui import ImgMarkerShowcaseWindow, ImgMarkerStyleEditorDialog
from .img_marker_editor import ImgMarkerStyleEditor
from ._ui_mapping import map_label_pos_to_image_coord

__all__ = [
    "ZoomPanLabel",
    "ImagePickerWindow",
    "PickerSession",
    "PointPair",
    "get_default_config",
    "get_default_img_marker_style",
    "ImgMarkerShowcaseWindow",
    "ImgMarkerStyleEditorDialog",
    "ImgMarkerStyleEditor",
    "map_label_pos_to_image_coord",
]
