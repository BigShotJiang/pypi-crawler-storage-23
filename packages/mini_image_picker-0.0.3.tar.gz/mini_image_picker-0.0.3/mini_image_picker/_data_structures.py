# -*- coding: utf-8 -*-
"""
选点数据结构：点对等（供 ImagePickerWindow.draw_markers 与 PickerSession 使用）
"""

from dataclasses import dataclass
from typing import Tuple
import numpy as np


@dataclass
class PointPair:
    """点对数据"""
    index: int
    image_coord: Tuple[int, int]  # 2D 图像点 (u, v)
    xyz: np.ndarray               # 3D 点云点 (X, Y, Z)
    image_index: int = 0          # 图像索引（支持多图匹配）
    is_valid: bool = True         # RANSAC 内点标记
