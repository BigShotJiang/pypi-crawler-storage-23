# -*- coding: utf-8 -*-
"""
ZoomPanLabel：主窗口用可缩放平移图像视图。
支持 set_pixmap(pixmap, keep_view_state=True)、map_to_image_coord(pos)；
可选主窗口选点模式：左键点击发射 point_picked、可 get_picked_points() 与 clear_picked_points()。
"""

from typing import List, Optional, Tuple, Any, Dict
from PySide6 import QtWidgets, QtCore, QtGui

from ._ui_mapping import map_label_pos_to_image_coord
from .config import get_merged_config
from .img_marker_style import paint_img_marker


class ZoomPanLabel(QtWidgets.QLabel):
    """可缩放平移的 QLabel（主窗口）。

    统一术语：本控件不提供“随鼠标联动的光标”；仅提供点击后停留的 **img_marker**（图像标记）。

    - 主窗口选点默认开启（可关闭）
    - 支持“活动点 active_img_marker”状态：有活动点时，点击/方向键只移动活动点；按 Enter 确认后变为已确认点
    - 已确认点与弹窗选点点列表互相独立，可分别获取
    - **多次选择只保留最后一次**：仅维护一个活动点，每次点击/设置即覆盖。配置 `draw_confirmed_while_active=False` 时，有活动点只绘制活动点（只显示当前一个）；可编程调用 `set_active_point(coord)` / `set_active_point(None)` 设置或清除活动点（如主窗口 3D 选点待确认十字）。
    """

    zoomChanged = QtCore.Signal(float)
    point_picked = QtCore.Signal(tuple)  # (x, y) 活动点位置更新（创建/移动）时发射
    point_confirmed = QtCore.Signal(tuple)  # (x, y) 活动点被 Enter 确认时发射
    points_finalized = QtCore.Signal(list)  # [(x, y), ...] 所有点被 Ctrl+Enter 最终确认时发射

    def __init__(self, parent=None, config: Optional[Dict[str, Any]] = None):
        super().__init__(parent)
        self._cfg = get_merged_config(config)
        zp = self._cfg.get("zoom_pan_label", {})
        self._zoom_factor_in = float(zp.get("zoom_factor_in", 1.1))
        self._zoom_factor_out = float(zp.get("zoom_factor_out", 1.1))
        self._zoom_min = float(zp.get("zoom_min", 0.2))

        self._pixmap: Optional[QtGui.QPixmap] = None
        self._zoom_factor = 1.0
        self.setAlignment(QtCore.Qt.AlignCenter)
        self.setMouseTracking(True)
        self.setFocusPolicy(QtCore.Qt.StrongFocus)
        self.setSizePolicy(
            QtWidgets.QSizePolicy.Policy.Expanding,
            QtWidgets.QSizePolicy.Policy.Expanding,
        )
        self.setMinimumSize(0, 0)

        self._is_panning = False
        self._last_pan_point = QtCore.QPoint()
        self._pan_offset = QtCore.QPoint(0, 0)

        picking_cfg = self._cfg.get("picking", {})
        self._max_points = int(picking_cfg.get("max_points", 30))

        # 默认选点开启（可关闭）
        self._pick_mode = bool(zp.get("pick_enabled_default", True))
        # img_marker 叠加绘制开关（默认开启，可关闭）
        self._img_marker_enabled = bool(zp.get("img_marker_enabled_default", True))
        # 有活动点时是否同时绘制已确认点；False 时只绘制活动点（只显示当前一个）
        self._draw_confirmed_while_active = bool(zp.get("draw_confirmed_while_active", True))

        # 已确认点列表与活动点（活动点未确认，不计入 get_picked_points）
        self._picked_points: List[Tuple[int, int]] = []
        self._active_point: Optional[Tuple[int, int]] = None

        # 最终确认状态（Ctrl+Enter 后锁定所有操作）
        self._is_finalized = False
        self._last_confirmed_pos: Optional[Tuple[int, int]] = None

    def sizeHint(self):
        return QtCore.QSize(0, 0)

    def minimumSizeHint(self):
        return QtCore.QSize(0, 0)

    def set_pixmap(self, pixmap: QtGui.QPixmap, keep_view_state: bool = False):
        """设置 pixmap。keep_view_state=True 时保留当前缩放与平移（与 D05 图像更新配合）。"""
        self._pixmap = pixmap
        if not keep_view_state:
            self._pan_offset = QtCore.QPoint(0, 0)
        self.update_display()

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self.update_display()

    def wheelEvent(self, event: QtGui.QWheelEvent):
        if self._pixmap is None:
            return
        mouse_pos = event.position().toPoint()
        old_zoom = self._zoom_factor
        scaled_width = self._pixmap.width() * old_zoom
        scaled_height = self._pixmap.height() * old_zoom
        old_offset_x = (self.width() - scaled_width) / 2.0 + self._pan_offset.x()
        old_offset_y = (self.height() - scaled_height) / 2.0 + self._pan_offset.y()
        if scaled_width > 0 and scaled_height > 0:
            rel_x = (mouse_pos.x() - old_offset_x) / scaled_width
            rel_y = (mouse_pos.y() - old_offset_y) / scaled_height
        else:
            rel_x = rel_y = 0.5

        if event.angleDelta().y() > 0:
            self._zoom_factor = self._zoom_factor * self._zoom_factor_in
        else:
            self._zoom_factor = max(self._zoom_factor / self._zoom_factor_out, self._zoom_min)

        new_scaled_width = self._pixmap.width() * self._zoom_factor
        new_scaled_height = self._pixmap.height() * self._zoom_factor
        new_offset_x = (self.width() - new_scaled_width) / 2.0
        new_offset_y = (self.height() - new_scaled_height) / 2.0
        target_x = mouse_pos.x() - rel_x * new_scaled_width
        target_y = mouse_pos.y() - rel_y * new_scaled_height
        self._pan_offset.setX(int(target_x - new_offset_x))
        self._pan_offset.setY(int(target_y - new_offset_y))
        self.zoomChanged.emit(self._zoom_factor)
        self.update_display()
        event.accept()

    def mousePressEvent(self, event: QtGui.QMouseEvent):
        if event.button() == QtCore.Qt.RightButton:
            self._is_panning = True
            self._last_pan_point = event.pos()
            self.setCursor(QtCore.Qt.ClosedHandCursor)
        elif event.button() == QtCore.Qt.LeftButton and self._pick_mode and self._pixmap is not None:
            # 如果已最终确认，阻止所有选点操作
            if self._is_finalized:
                return
            # 点击后保持焦点，以便方向键作用于当前激活窗口/控件
            self.setFocus(QtCore.Qt.MouseFocusReason)
            coord = self.map_to_image_coord(event.pos())
            if coord is not None:
                # 有活动点则移动活动点；无活动点则创建活动点
                self._active_point = coord
                self.point_picked.emit(coord)
                self.update_display()
                return
        super().mousePressEvent(event)

    def mouseMoveEvent(self, event: QtGui.QMouseEvent):
        if self._is_panning:
            delta = event.pos() - self._last_pan_point
            self._last_pan_point = event.pos()
            self._pan_offset += delta
            self.update_display()
        super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event: QtGui.QMouseEvent):
        if event.button() == QtCore.Qt.RightButton:
            self._is_panning = False
            self.setCursor(QtCore.Qt.ArrowCursor)
        super().mouseReleaseEvent(event)

    def update_display(self):
        if self._pixmap is None:
            return
        original_size = self._pixmap.size()
        scaled_width = int(original_size.width() * self._zoom_factor)
        scaled_height = int(original_size.height() * self._zoom_factor)
        scaled = self._pixmap.scaled(
            scaled_width, scaled_height,
            QtCore.Qt.KeepAspectRatio,
            QtCore.Qt.SmoothTransformation,
        )
        canvas = QtGui.QPixmap(self.size())
        canvas.fill(QtCore.Qt.black)
        painter = QtGui.QPainter(canvas)
        x = (self.width() - scaled.width()) // 2 + self._pan_offset.x()
        y = (self.height() - scaled.height()) // 2 + self._pan_offset.y()
        painter.drawPixmap(x, y, scaled)

        # 叠加绘制 img_marker（点击后停留）
        if getattr(self, "_img_marker_enabled", False):
            style = self._cfg.get("img_marker_style") or self._cfg.get("cursor_style") or {}
            confirmed_style = self._cfg.get("img_marker_style_confirmed") or {}
            if style:
                draw_confirmed = getattr(self, "_draw_confirmed_while_active", True)
                active = getattr(self, "_active_point", None)
                # 有活动点且 draw_confirmed_while_active 为 False 时，只画活动点（只显示当前一个）
                if active is not None and not draw_confirmed:
                    ix, iy = active
                    sx = x + int(ix * self._zoom_factor)
                    sy = y + int(iy * self._zoom_factor)
                    paint_img_marker(painter, QtCore.QPoint(sx, sy), style, coord_text=f"{ix},{iy}")
                else:
                    # 已确认点（使用灰色样式）
                    for i, (ix, iy) in enumerate(self._picked_points):
                        sx = x + int(ix * self._zoom_factor)
                        sy = y + int(iy * self._zoom_factor)
                        if confirmed_style:
                            paint_img_marker(painter, QtCore.QPoint(sx, sy), confirmed_style, coord_text=str(i + 1))
                        else:
                            paint_img_marker(painter, QtCore.QPoint(sx, sy), style, coord_text=str(i + 1), force_gray=True)
                    # 活动点（若有，用坐标更直观，使用原始颜色）
                    if active is not None:
                        ix, iy = active
                        sx = x + int(ix * self._zoom_factor)
                        sy = y + int(iy * self._zoom_factor)
                        paint_img_marker(painter, QtCore.QPoint(sx, sy), style, coord_text=f"{ix},{iy}")
        painter.end()
        self.setPixmap(canvas)

    def keyPressEvent(self, event: QtGui.QKeyEvent):
        """方向键逐像素移动活动点；Enter 确认活动点为已确认点；Ctrl+Enter 最终确认所有点。"""
        if not getattr(self, "_pick_mode", False) or self._pixmap is None:
            return super().keyPressEvent(event)

        # 如果已最终确认，阻止所有键盘操作
        if self._is_finalized:
            return super().keyPressEvent(event)

        key = event.key()
        modifiers = event.modifiers()

        # Ctrl+Enter：最终确认所有点
        if (key in (QtCore.Qt.Key_Return, QtCore.Qt.Key_Enter)) and (modifiers & QtCore.Qt.ControlModifier):
            # 如果有活动点，先自动确认
            if getattr(self, "_active_point", None) is not None:
                x, y = self._active_point
                max_n = int(getattr(self, "_max_points", 30))
                if max_n > 0 and len(self._picked_points) >= max_n:
                    self._picked_points.pop(0)
                self._picked_points.append((x, y))
                self._last_confirmed_pos = (x, y)
                self.point_confirmed.emit((x, y))
                self._active_point = None
            # 最终确认
            self._is_finalized = True
            self.points_finalized.emit(list(self._picked_points))
            self.update_display()
            event.accept()
            return

        # Enter：确认活动点或重新进入活动状态
        if key in (QtCore.Qt.Key_Return, QtCore.Qt.Key_Enter):
            if getattr(self, "_active_point", None) is not None:
                # 有活动点：确认活动点，加入已确认列表
                x, y = self._active_point
                max_n = int(getattr(self, "_max_points", 30))
                if max_n > 0 and len(self._picked_points) >= max_n:
                    self._picked_points.pop(0)
                self._picked_points.append((x, y))
                self._last_confirmed_pos = (x, y)
                self.point_confirmed.emit((x, y))
                self._active_point = None
                self.update_display()
                event.accept()
                return
            else:
                # 无活动点：如果有上次确认位置，重新进入活动状态
                if self._last_confirmed_pos is not None:
                    self._active_point = self._last_confirmed_pos
                    self.point_picked.emit(self._last_confirmed_pos)
                    self.update_display()
                    event.accept()
                    return
                else:
                    return super().keyPressEvent(event)

        # 方向键：移动活动点
        if getattr(self, "_active_point", None) is None:
            return super().keyPressEvent(event)

        x, y = self._active_point
        w = self._pixmap.width()
        h = self._pixmap.height()

        if key == QtCore.Qt.Key_Left:
            x -= 1
        elif key == QtCore.Qt.Key_Right:
            x += 1
        elif key == QtCore.Qt.Key_Up:
            y -= 1
        elif key == QtCore.Qt.Key_Down:
            y += 1
        else:
            return super().keyPressEvent(event)

        # clamp to image bounds
        x = max(0, min(w - 1, x))
        y = max(0, min(h - 1, y))
        self._active_point = (x, y)
        self.point_picked.emit((x, y))
        self.update_display()
        event.accept()

    def zoom_in(self):
        self._zoom_factor = self._zoom_factor * self._zoom_factor_in
        self.zoomChanged.emit(self._zoom_factor)
        self.update_display()

    def zoom_out(self):
        self._zoom_factor = max(self._zoom_factor / self._zoom_factor_out, self._zoom_min)
        self.zoomChanged.emit(self._zoom_factor)
        self.update_display()

    def reset_zoom(self):
        self._zoom_factor = 1.0
        self._pan_offset = QtCore.QPoint(0, 0)
        self.update_display()
        self.zoomChanged.emit(self._zoom_factor)

    def map_to_image_coord(self, pos: QtCore.QPoint) -> Optional[Tuple[int, int]]:
        """将 label 上的坐标映射到当前 pixmap 对应的图像像素坐标（供选 3D 点、颜色过滤取像素等）。"""
        return map_label_pos_to_image_coord(
            pos=pos,
            pixmap=self._pixmap,
            zoom=self._zoom_factor,
            pan_offset=self._pan_offset,
            label_size=(self.width(), self.height()),
        )

    def map_to_image_coords(self, label_pos: QtCore.QPoint) -> Optional[Tuple[int, int]]:
        """兼容别名：同 map_to_image_coord(label_pos)。"""
        return self.map_to_image_coord(label_pos)

    def set_pick_mode(self, enabled: bool) -> None:
        """开启/关闭主窗口选点模式：开启时左键点击会发射 point_picked 并写入 get_picked_points()。"""
        self._pick_mode = bool(enabled)

    def is_pick_mode(self) -> bool:
        return self._pick_mode

    def get_picked_points(self) -> List[Tuple[int, int]]:
        """返回主窗口已确认的 img_marker 点列表（与弹窗选点结果分开）。"""
        return list(self._picked_points)

    def get_active_point(self) -> Optional[Tuple[int, int]]:
        """返回当前活动点（未确认）。"""
        return getattr(self, "_active_point", None)

    def set_active_point(self, coord: Optional[Tuple[int, int]]) -> None:
        """设置或清除活动点并刷新绘制。供主窗口 3D 选点等场景：待确认时设 (px, py)，确认/取消时传 None。"""
        self._active_point = coord
        self.update_display()

    def clear_active_point(self) -> None:
        """清除活动点并刷新绘制（等价于 set_active_point(None)）。"""
        self.set_active_point(None)

    def get_view_state(self) -> dict:
        """返回当前视图状态（缩放、平移），便于保存/恢复而不依赖私有属性。"""
        return {
            "zoom_factor": self._zoom_factor,
            "pan_offset_x": self._pan_offset.x(),
            "pan_offset_y": self._pan_offset.y(),
        }

    def set_view_state(
        self,
        zoom_factor: Optional[float] = None,
        pan_offset_x: Optional[int] = None,
        pan_offset_y: Optional[int] = None,
    ) -> None:
        """恢复视图状态；参数为 None 的项不修改。会调用 update_display()，若 zoom 变化则发射 zoomChanged。"""
        if zoom_factor is not None:
            self._zoom_factor = float(zoom_factor)
        if pan_offset_x is not None or pan_offset_y is not None:
            x = self._pan_offset.x() if pan_offset_x is None else pan_offset_x
            y = self._pan_offset.y() if pan_offset_y is None else pan_offset_y
            self._pan_offset = QtCore.QPoint(int(x), int(y))
        self.update_display()
        if zoom_factor is not None:
            self.zoomChanged.emit(self._zoom_factor)

    def clear_debug_markers(self) -> None:
        """兼容接口：清除调试标记。本控件不绘制调试标记，为空实现。"""
        pass

    def add_debug_marker(self, x: int, y: int, marker_type: str = "click", info: Any = None) -> None:
        """兼容接口：添加调试标记。本控件不绘制调试标记，为空实现。"""
        pass

    def clear_picked_points(self) -> None:
        """清空主窗口选点列表。"""
        self._picked_points.clear()
        self._active_point = None
        self._is_finalized = False
        self._last_confirmed_pos = None
        self.update_display()

    def set_img_marker_enabled(self, enabled: bool) -> None:
        """开启/关闭 img_marker 叠加绘制（默认开启）。"""
        self._img_marker_enabled = bool(enabled)
        self.update_display()

    def is_img_marker_enabled(self) -> bool:
        return bool(getattr(self, "_img_marker_enabled", False))

    def finalize_points(self) -> List[Tuple[int, int]]:
        """程序化触发 Ctrl+Enter 最终确认（供 UI 按钮调用）。"""
        if self._is_finalized:
            return list(self._picked_points)
        # 如果有活动点，先自动确认
        if self._active_point is not None:
            x, y = self._active_point
            max_n = int(getattr(self, "_max_points", 30))
            if max_n > 0 and len(self._picked_points) >= max_n:
                self._picked_points.pop(0)
            self._picked_points.append((x, y))
            self._last_confirmed_pos = (x, y)
            self.point_confirmed.emit((x, y))
            self._active_point = None
        # 最终确认
        self._is_finalized = True
        self.points_finalized.emit(list(self._picked_points))
        self.update_display()
        return list(self._picked_points)

    def is_finalized(self) -> bool:
        """检查是否已最终确认。"""
        return self._is_finalized    
    def reset_finalization(self) -> None:
        """重置最终确认状态（用于新会话）。"""
        self._is_finalized = False
        self.update_display()
