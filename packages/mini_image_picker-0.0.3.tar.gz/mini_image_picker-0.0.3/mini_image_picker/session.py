# -*- coding: utf-8 -*-
"""
PickerSession：持有 ImagePickerWindow、点列表与状态，对外提供 get_state()、get_result()、get_summary() 及信号。
"""

from typing import Any, Dict, List, Optional, Tuple
import numpy as np
from PySide6 import QtCore

from .config import get_merged_config
from .image_picker_window import ImagePickerWindow


class PickerSession(QtCore.QObject):
    """选点会话：创建并持有 ImagePickerWindow，维护已选点列表与状态，避免与主程序状态冲突。"""

    points_changed = QtCore.Signal()
    session_finished = QtCore.Signal()
    points_finalized = QtCore.Signal(list)  # [(x, y), ...] 所有点被 Ctrl+Enter 最终确认时发射

    STATE_IDLE = "idle"
    STATE_PICKING = "picking"
    STATE_FINE_TUNE = "fine_tune"
    STATE_CLOSED = "closed"
    STATE_FINALIZED = "finalized"

    def __init__(
        self,
        image: np.ndarray,
        config: Optional[Dict[str, Any]] = None,
        parent=None,
        distortion_mode: str = "image_undistort",
        projection_mgr=None,
    ):
        super().__init__(parent)
        self._cfg = get_merged_config(config)
        self._points: List[Tuple[int, int]] = []
        self._pending_point: Optional[Tuple[int, int]] = None
        self._state = self.STATE_IDLE
        self._window: Optional[ImagePickerWindow] = None

        self._window = ImagePickerWindow(
            image,
            config=self._cfg,
            parent=parent,
            distortion_mode=distortion_mode,
            projection_mgr=projection_mgr,
        )
        self._window.point_confirmed.connect(self._on_point_confirmed)
        self._window.points_finalized.connect(self._on_points_finalized)
        self._window.stop_requested.connect(self._on_stop_requested)
        self._state = self.STATE_PICKING

    def _on_point_confirmed(self, coord: Tuple[int, int]):
        self._points.append(coord)
        self._pending_point = None
        self.points_changed.emit()

    def _on_points_finalized(self, points: List[Tuple[int, int]]):
        """处理 Ctrl+Enter 最终确认。"""
        self._points = list(points)
        self._state = self.STATE_FINALIZED
        self.points_finalized.emit(points)

    def _on_stop_requested(self):
        self._state = self.STATE_CLOSED
        if self._window is not None:
            self._window.close()
            self._window = None
        self.session_finished.emit()

    def get_state(self) -> str:
        """当前状态：idle / picking / fine_tune / finalized / closed。"""
        # 检查是否已最终确认
        if self._window is not None and getattr(self._window, "_is_finalized", False):
            return self.STATE_FINALIZED
        if self._state == self.STATE_FINALIZED:
            return self.STATE_FINALIZED
        if self._window is not None and getattr(self._window, "fine_tune_mode", False):
            return self.STATE_FINE_TUNE
        return self._state

    def get_result(self) -> List[Tuple[int, int]]:
        """当前已确认的 2D 点列表（最终结果）。"""
        return list(self._points)

    def get_pending_point(self) -> Optional[Tuple[int, int]]:
        """待确认点（若有）。"""
        if self._window is not None and getattr(self._window, "pending_point", None) is not None:
            return self._window.pending_point
        return self._pending_point

    def get_summary(self) -> Dict[str, Any]:
        """一次取齐：state、points、count。"""
        return {
            "state": self.get_state(),
            "points": self.get_result(),
            "count": len(self._points),
        }

    def show(self):
        """显示选点窗口。"""
        if self._window is not None:
            self._window.show()

    def close(self):
        """关闭选点窗口并置为 closed。"""
        self._on_stop_requested()

    @property
    def image_window(self) -> Optional[ImagePickerWindow]:
        """内部 ImagePickerWindow（主程序如需直接调用 update_image、draw_markers 等可用）。"""
        return self._window

    def finalize_points(self) -> List[Tuple[int, int]]:
        """程序化触发 Ctrl+Enter 最终确认（供 UI 按钮调用）。"""
        if self._window:
            return self._window.finalize_points()
        return list(self._points)
