# -*- coding: utf-8 -*-
"""
ImgMarker 样式编辑器：可视化编辑和预览 img_marker 样式。
"""

import os
import copy
from typing import Dict, Any, Optional
from PySide6 import QtCore, QtGui, QtWidgets

from .img_marker_style import paint_img_marker, get_default_img_marker_style


class ImgMarkerStyleEditor(QtWidgets.QWidget):
    """ImgMarker 样式编辑器窗口。"""

    style_changed = QtCore.Signal(dict)  # 样式改变时发射

    def __init__(self, parent=None, initial_style: Optional[Dict[str, Any]] = None):
        super().__init__(parent)
        self.setWindowTitle("ImgMarker 样式编辑器")
        self.setWindowFlags(QtCore.Qt.Window)

        # 当前编辑的样式
        self.current_style = initial_style or get_default_img_marker_style()
        self.current_component = "crosshair"  # 当前选中的组件

        # 生成预设样式
        self.presets = self._generate_presets()

        self.init_ui()
        self.update_preview()

    def _generate_presets(self):
        """生成预设样式（不再使用，保留接口兼容性）。"""
        return []

    def init_ui(self):
        main_layout = QtWidgets.QHBoxLayout(self)

        # 左侧：预设样式选择
        left_panel = self._create_preset_panel()
        main_layout.addWidget(left_panel, 1)

        # 中间：详细编辑区
        middle_panel = self._create_editor_panel()
        main_layout.addWidget(middle_panel, 1)

        # 右侧：预览区
        right_panel = self._create_preview_panel()
        main_layout.addWidget(right_panel, 1)

        self.resize(1200, 600)

    def _create_preset_panel(self):
        """创建样式选择面板（使用下拉菜单）。"""
        panel = QtWidgets.QGroupBox("样式选择")
        layout = QtWidgets.QVBoxLayout(panel)

        # Crosshair 样式选择
        crosshair_layout = QtWidgets.QHBoxLayout()
        crosshair_layout.addWidget(QtWidgets.QLabel("Crosshair 样式:"))
        self.crosshair_style_combo = QtWidgets.QComboBox()
        self.crosshair_style_combo.addItems(["十字", "X型"])
        self.crosshair_style_combo.currentTextChanged.connect(self._on_crosshair_style_changed)
        crosshair_layout.addWidget(self.crosshair_style_combo)
        layout.addLayout(crosshair_layout)

        # Outer Contour 形状选择
        contour_layout = QtWidgets.QHBoxLayout()
        contour_layout.addWidget(QtWidgets.QLabel("Outer Contour 形状:"))
        self.contour_shape_combo = QtWidgets.QComboBox()
        self.contour_shape_combo.addItems(["圆形", "正方形", "菱形", "五角星"])
        self.contour_shape_combo.currentTextChanged.connect(self._on_contour_shape_changed)
        contour_layout.addWidget(self.contour_shape_combo)
        layout.addLayout(contour_layout)

        # Text 位置选择
        text_layout = QtWidgets.QHBoxLayout()
        text_layout.addWidget(QtWidgets.QLabel("Text 位置:"))
        self.text_position_combo = QtWidgets.QComboBox()
        self.text_position_combo.addItems(["左上角", "右上角", "左下角", "右下角"])
        self.text_position_combo.currentTextChanged.connect(self._on_text_position_changed)
        text_layout.addWidget(self.text_position_combo)
        layout.addLayout(text_layout)

        layout.addStretch()

        return panel

    def _create_editor_panel(self):
        """创建详细编辑面板。"""
        panel = QtWidgets.QGroupBox("详细编辑")
        layout = QtWidgets.QVBoxLayout(panel)

        # 组件选择下拉菜单
        component_layout = QtWidgets.QHBoxLayout()
        component_layout.addWidget(QtWidgets.QLabel("组件:"))
        self.component_combo = QtWidgets.QComboBox()
        self.component_combo.addItems(["crosshair", "outer_contour", "text"])
        self.component_combo.currentTextChanged.connect(self._on_component_changed)
        component_layout.addWidget(self.component_combo)
        layout.addLayout(component_layout)

        # 启用/禁用
        self.enabled_cb = QtWidgets.QCheckBox("启用")
        self.enabled_cb.stateChanged.connect(self._on_param_changed)
        layout.addWidget(self.enabled_cb)

        # 大小
        size_layout = QtWidgets.QHBoxLayout()
        size_layout.addWidget(QtWidgets.QLabel("大小:"))
        self.size_spin = QtWidgets.QSpinBox()
        self.size_spin.setRange(1, 100)
        self.size_spin.valueChanged.connect(self._on_param_changed)
        size_layout.addWidget(self.size_spin)
        layout.addLayout(size_layout)

        # 粗细
        thickness_layout = QtWidgets.QHBoxLayout()
        thickness_layout.addWidget(QtWidgets.QLabel("粗细:"))
        self.thickness_spin = QtWidgets.QSpinBox()
        self.thickness_spin.setRange(1, 10)
        self.thickness_spin.valueChanged.connect(self._on_param_changed)
        thickness_layout.addWidget(self.thickness_spin)
        layout.addLayout(thickness_layout)

        # 颜色
        color_layout = QtWidgets.QHBoxLayout()
        color_layout.addWidget(QtWidgets.QLabel("颜色:"))

        # 颜色选择器按钮
        self.color_button = QtWidgets.QPushButton("选择颜色")
        self.color_button.clicked.connect(self._on_color_picker)
        color_layout.addWidget(self.color_button)

        # 颜色预览
        self.color_preview = QtWidgets.QLabel()
        self.color_preview.setFixedSize(60, 30)
        self.color_preview.setStyleSheet("border: 1px solid black;")
        color_layout.addWidget(self.color_preview)

        # 透明度滑块
        color_layout.addWidget(QtWidgets.QLabel("透明度:"))
        self.alpha_slider = QtWidgets.QSlider(QtCore.Qt.Horizontal)
        self.alpha_slider.setRange(0, 255)
        self.alpha_slider.setValue(200)
        self.alpha_slider.valueChanged.connect(self._on_alpha_changed)
        color_layout.addWidget(self.alpha_slider)

        self.alpha_label = QtWidgets.QLabel("200")
        self.alpha_label.setFixedWidth(30)
        color_layout.addWidget(self.alpha_label)

        layout.addLayout(color_layout)

        # 保存当前颜色（RGB，不含 alpha）
        self._current_rgb = [255, 255, 255]

        # 线条样式
        line_style_layout = QtWidgets.QHBoxLayout()
        line_style_layout.addWidget(QtWidgets.QLabel("线条样式:"))
        self.line_style_combo = QtWidgets.QComboBox()
        self.line_style_combo.addItems(["Solid", "Dash", "Dot", "DashDot"])
        self.line_style_combo.currentTextChanged.connect(self._on_param_changed)
        line_style_layout.addWidget(self.line_style_combo)
        layout.addLayout(line_style_layout)

        # 文字特有参数
        self.text_params_widget = QtWidgets.QWidget()
        text_params_layout = QtWidgets.QVBoxLayout(self.text_params_widget)
        text_params_layout.setContentsMargins(0, 0, 0, 0)

        font_layout = QtWidgets.QHBoxLayout()
        font_layout.addWidget(QtWidgets.QLabel("字体:"))
        self.font_family = QtWidgets.QLineEdit("Arial")
        self.font_family.textChanged.connect(self._on_param_changed)
        font_layout.addWidget(self.font_family)
        text_params_layout.addLayout(font_layout)

        font_size_layout = QtWidgets.QHBoxLayout()
        font_size_layout.addWidget(QtWidgets.QLabel("字号:"))
        self.font_size_spin = QtWidgets.QSpinBox()
        self.font_size_spin.setRange(6, 24)
        self.font_size_spin.valueChanged.connect(self._on_param_changed)
        font_size_layout.addWidget(self.font_size_spin)
        text_params_layout.addLayout(font_size_layout)

        content_layout = QtWidgets.QHBoxLayout()
        content_layout.addWidget(QtWidgets.QLabel("内容:"))
        self.text_content = QtWidgets.QLineEdit("x, y")
        self.text_content.textChanged.connect(self._on_param_changed)
        content_layout.addWidget(self.text_content)
        text_params_layout.addLayout(content_layout)

        distance_layout = QtWidgets.QHBoxLayout()
        distance_layout.addWidget(QtWidgets.QLabel("距离圆心(像素):"))
        self.text_distance = QtWidgets.QSpinBox()
        self.text_distance.setRange(0, 100)
        self.text_distance.setValue(15)
        self.text_distance.valueChanged.connect(self._on_param_changed)
        distance_layout.addWidget(self.text_distance)
        text_params_layout.addLayout(distance_layout)

        offset_layout = QtWidgets.QHBoxLayout()
        offset_layout.addWidget(QtWidgets.QLabel("偏移 (X, Y):"))
        self.offset_x = QtWidgets.QSpinBox()
        self.offset_y = QtWidgets.QSpinBox()
        for spin in [self.offset_x, self.offset_y]:
            spin.setRange(-50, 50)
            spin.valueChanged.connect(self._on_param_changed)
        offset_layout.addWidget(self.offset_x)
        offset_layout.addWidget(self.offset_y)
        text_params_layout.addLayout(offset_layout)

        layout.addWidget(self.text_params_widget)

        layout.addStretch()

        # 导入/导出按钮
        btn_layout = QtWidgets.QHBoxLayout()
        btn_load = QtWidgets.QPushButton("加载 YAML")
        btn_load.clicked.connect(self._on_load_yaml)
        btn_save = QtWidgets.QPushButton("导出 YAML")
        btn_save.clicked.connect(self._on_save_yaml)
        btn_layout.addWidget(btn_load)
        btn_layout.addWidget(btn_save)
        layout.addLayout(btn_layout)

        # 初始化显示
        self._load_component_params()

        return panel

    def _create_preview_panel(self):
        """创建预览面板。"""
        panel = QtWidgets.QGroupBox("实时预览")
        layout = QtWidgets.QVBoxLayout(panel)

        self.preview_label = QtWidgets.QLabel()
        self.preview_label.setMinimumSize(300, 300)
        self.preview_label.setAlignment(QtCore.Qt.AlignCenter)
        self.preview_label.setStyleSheet("background-color: #2b2b2b; border: 1px solid #555;")
        layout.addWidget(self.preview_label)

        # 预览说明
        info = QtWidgets.QLabel("预览效果（中心点坐标: 150, 150）")
        info.setAlignment(QtCore.Qt.AlignCenter)
        layout.addWidget(info)

        return panel

    def _on_crosshair_style_changed(self, style_text):
        """Crosshair 样式改变。"""
        if "crosshair" not in self.current_style:
            self.current_style["crosshair"] = {}
        # 保存样式类型：cross（十字）或 x（X型）
        self.current_style["crosshair"]["style_type"] = "cross" if style_text == "十字" else "x"
        self.update_preview()
        self.style_changed.emit(self.current_style)

    def _on_contour_shape_changed(self, shape_text):
        """Outer Contour 形状改变。"""
        if "outer_contour" not in self.current_style:
            self.current_style["outer_contour"] = {}
        # 保存形状类型
        shape_map = {"圆形": "circle", "正方形": "square", "菱形": "diamond", "五角星": "star"}
        self.current_style["outer_contour"]["shape"] = shape_map.get(shape_text, "circle")
        self.update_preview()
        self.style_changed.emit(self.current_style)

    def _on_text_position_changed(self, position_text):
        """Text 位置改变。"""
        if "text" not in self.current_style:
            self.current_style["text"] = {}
        # 保存位置类型
        position_map = {"左上角": "top_left", "右上角": "top_right", "左下角": "bottom_left", "右下角": "bottom_right"}
        self.current_style["text"]["position"] = position_map.get(position_text, "top_right")
        self.update_preview()
        self.style_changed.emit(self.current_style)

    def _on_component_changed(self, component: str):
        """组件切换。"""
        self.current_component = component
        self._load_component_params()

    def _on_color_picker(self):
        """打开颜色选择器。"""
        # 获取当前颜色
        current_color = QtGui.QColor(self._current_rgb[0], self._current_rgb[1], self._current_rgb[2])

        # 打开颜色对话框
        color = QtWidgets.QColorDialog.getColor(current_color, self, "选择颜色")

        if color.isValid():
            self._current_rgb = [color.red(), color.green(), color.blue()]
            self._update_color_preview()
            self._on_param_changed()

    def _on_alpha_changed(self, value):
        """透明度改变。"""
        self.alpha_label.setText(str(value))
        self._update_color_preview()
        self._on_param_changed()

    def _load_component_params(self):
        """加载当前组件的参数到编辑器。"""
        comp = self.current_style.get(self.current_component, {})

        # 阻止信号触发
        self.enabled_cb.blockSignals(True)
        self.size_spin.blockSignals(True)
        self.thickness_spin.blockSignals(True)
        self.alpha_slider.blockSignals(True)
        self.line_style_combo.blockSignals(True)

        # 加载参数
        self.enabled_cb.setChecked(comp.get("enabled", True))
        self.size_spin.setValue(comp.get("size", 10))
        self.thickness_spin.setValue(comp.get("thickness", 1))

        color = comp.get("color", [255, 255, 255, 200])
        self._current_rgb = [
            color[0] if len(color) > 0 else 255,
            color[1] if len(color) > 1 else 255,
            color[2] if len(color) > 2 else 255,
        ]
        alpha = color[3] if len(color) > 3 else 200
        self.alpha_slider.setValue(alpha)
        self.alpha_label.setText(str(alpha))
        self._update_color_preview()

        line_style = comp.get("line_style", "Solid")
        idx = self.line_style_combo.findText(line_style)
        if idx >= 0:
            self.line_style_combo.setCurrentIndex(idx)

        # 文字特有参数
        if self.current_component == "text":
            self.text_params_widget.setVisible(True)
            self.font_family.blockSignals(True)
            self.font_size_spin.blockSignals(True)
            self.text_content.blockSignals(True)
            self.text_distance.blockSignals(True)
            self.offset_x.blockSignals(True)
            self.offset_y.blockSignals(True)

            self.font_family.setText(comp.get("font_family", "Arial"))
            self.font_size_spin.setValue(comp.get("font_size", 9))
            self.text_content.setText(comp.get("content", "x, y"))
            self.text_distance.setValue(comp.get("distance", 15))
            self.offset_x.setValue(comp.get("offset_x", 8))
            self.offset_y.setValue(comp.get("offset_y", -8))

            self.font_family.blockSignals(False)
            self.font_size_spin.blockSignals(False)
            self.text_content.blockSignals(False)
            self.text_distance.blockSignals(False)
            self.offset_x.blockSignals(False)
            self.offset_y.blockSignals(False)
        else:
            self.text_params_widget.setVisible(False)

        # 恢复信号
        self.enabled_cb.blockSignals(False)
        self.size_spin.blockSignals(False)
        self.thickness_spin.blockSignals(False)
        self.alpha_slider.blockSignals(False)
        self.line_style_combo.blockSignals(False)

    def _on_param_changed(self):
        """参数改变，更新当前样式。"""
        if self.current_component not in self.current_style:
            self.current_style[self.current_component] = {}

        comp = self.current_style[self.current_component]
        comp["enabled"] = self.enabled_cb.isChecked()
        comp["size"] = self.size_spin.value()
        comp["thickness"] = self.thickness_spin.value()
        comp["color"] = self._current_rgb + [self.alpha_slider.value()]
        comp["line_style"] = self.line_style_combo.currentText()

        if self.current_component == "text":
            comp["font_family"] = self.font_family.text()
            comp["font_size"] = self.font_size_spin.value()
            comp["content"] = self.text_content.text()
            comp["distance"] = self.text_distance.value()
            comp["offset_x"] = self.offset_x.value()
            comp["offset_y"] = self.offset_y.value()

        self._update_color_preview()
        self.update_preview()
        self.style_changed.emit(self.current_style)

    def _update_color_preview(self):
        """更新颜色预览。"""
        r, g, b = self._current_rgb
        alpha = self.alpha_slider.value()
        # 显示带透明度的颜色预览
        self.color_preview.setStyleSheet(
            f"background-color: rgba({r}, {g}, {b}, {alpha/255.0}); border: 1px solid black;"
        )

    def update_preview(self):
        """更新预览图像。"""
        # 创建预览图像
        pixmap = QtGui.QPixmap(300, 300)
        pixmap.fill(QtGui.QColor(43, 43, 43))  # 深灰色背景

        painter = QtGui.QPainter(pixmap)
        painter.setRenderHint(QtGui.QPainter.Antialiasing)

        # 绘制网格
        pen = QtGui.QPen(QtGui.QColor(80, 80, 80))
        painter.setPen(pen)
        for i in range(0, 300, 30):
            painter.drawLine(i, 0, i, 300)
            painter.drawLine(0, i, 300, i)

        # 绘制 img_marker
        center = QtCore.QPoint(150, 150)
        paint_img_marker(painter, center, self.current_style, coord_text="150,150")

        painter.end()

        self.preview_label.setPixmap(pixmap)

    def _on_load_yaml(self):
        """加载 YAML 文件。"""
        file_path, _ = QtWidgets.QFileDialog.getOpenFileName(
            self, "加载样式", "", "YAML Files (*.yaml *.yml);;All Files (*)"
        )
        if not file_path:
            return

        try:
            import yaml
            with open(file_path, "r", encoding="utf-8") as f:
                loaded_style = yaml.safe_load(f)

            if isinstance(loaded_style, dict):
                self.current_style = loaded_style
                self._load_component_params()
                self.update_preview()
                self.style_changed.emit(self.current_style)
                QtWidgets.QMessageBox.information(self, "成功", f"已加载样式: {file_path}")
            else:
                QtWidgets.QMessageBox.warning(self, "错误", "YAML 文件格式不正确")
        except ImportError:
            QtWidgets.QMessageBox.warning(self, "错误", "需要安装 PyYAML: pip install pyyaml")
        except Exception as e:
            QtWidgets.QMessageBox.warning(self, "错误", f"加载失败: {e}")

    def _on_save_yaml(self):
        """导出 YAML 文件。"""
        file_path, _ = QtWidgets.QFileDialog.getSaveFileName(
            self, "导出样式", "img_marker_style.yaml", "YAML Files (*.yaml *.yml);;All Files (*)"
        )
        if not file_path:
            return

        try:
            import yaml
            with open(file_path, "w", encoding="utf-8") as f:
                yaml.dump(self.current_style, f, default_flow_style=False, allow_unicode=True)
            QtWidgets.QMessageBox.information(self, "成功", f"已导出样式: {file_path}")
        except ImportError:
            QtWidgets.QMessageBox.warning(self, "错误", "需要安装 PyYAML: pip install pyyaml")
        except Exception as e:
            QtWidgets.QMessageBox.warning(self, "错误", f"导出失败: {e}")

    def get_current_style(self) -> Dict[str, Any]:
        """获取当前编辑的样式。"""
        return copy.deepcopy(self.current_style)

    def set_style(self, style: Dict[str, Any]):
        """设置样式。"""
        self.current_style = copy.deepcopy(style)
        self._load_component_params()
        self.update_preview()
