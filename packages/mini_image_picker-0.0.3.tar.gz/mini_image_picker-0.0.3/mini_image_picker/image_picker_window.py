# -*- coding: utf-8 -*-
"""
图像选点窗口：缩放、平移、左键选点、微调、Enter 确认。所有视觉与交互参数由 config 驱动。
"""

import logging
import cv2
import numpy as np
from typing import List, Optional, Tuple, Any, Dict
from PySide6 import QtCore, QtGui, QtWidgets

from ._ui_image_picker import Ui_ImagePickerWindow
from ._data_structures import PointPair
from ._ui_mapping import map_label_pos_to_image_coord
from .config import get_merged_config
from .img_marker_style import paint_img_marker

logger = logging.getLogger(__name__)


def _get_cfg(cfg: Dict, *keys, default=None):
    v = cfg
    for k in keys:
        v = v.get(k, {}) if isinstance(v, dict) else default
        if v is None:
            return default
    return v if v is not None else default


class ImagePickerWindow(QtWidgets.QWidget):
    """图像选点窗口（支持缩放、平移和多图切换）。"""

    point_picked = QtCore.Signal(tuple)
    point_confirmed = QtCore.Signal(tuple)
    points_finalized = QtCore.Signal(list)  # [(x, y), ...] 所有点被 Ctrl+Enter 最终确认时发射
    image_switch_requested = QtCore.Signal(str)
    stop_requested = QtCore.Signal()

    def __init__(
        self,
        image: np.ndarray,
        config: Optional[Dict[str, Any]] = None,
        parent=None,
        distortion_mode: str = "image_undistort",
        projection_mgr=None,
    ):
        super().__init__(parent)
        self._cfg = get_merged_config(config)
        self.setWindowFlags(QtCore.Qt.Window)

        self.original_image = image.copy()
        self.display_image = image.copy()
        self.distortion_mode = distortion_mode
        self.projection_mgr = projection_mgr

        self.zoom_factor = 1.0
        self.initial_zoom_calculated = False
        self.pan_offset = QtCore.QPoint(0, 0)
        self.is_panning = False
        self.last_pan_point = QtCore.QPoint()
        self.current_mouse_pos = None
        self.current_image_coord = None
        self.fine_tune_mode = False
        self.pending_point = None

        # 最终确认状态（Ctrl+Enter 后锁定所有操作）
        self._confirmed_points: List[Tuple[int, int]] = []
        self._is_finalized = False
        self._last_confirmed_pos: Optional[Tuple[int, int]] = None

        self.init_ui()

    def _zoom_in_factor(self):
        return float(_get_cfg(self._cfg, "zoom", "factor_in", default=1.2))

    def _zoom_out_factor(self):
        return float(_get_cfg(self._cfg, "zoom", "factor_out", default=1.2))

    def _zoom_min(self):
        return float(_get_cfg(self._cfg, "zoom", "min_factor", default=0.1))

    def _fine_tune_step(self):
        return int(_get_cfg(self._cfg, "hotkeys", "fine_tune_step", default=1))

    def _fine_tune_step_fast(self):
        return int(_get_cfg(self._cfg, "hotkeys", "fine_tune_step_fast", default=5))

    def init_ui(self):
        self._ui = Ui_ImagePickerWindow()
        self._ui.setupUi(self)
        self.image_label = self._ui.image_label
        self.setWindowFlags(QtCore.Qt.Window)

        h, w = self.original_image.shape[:2]
        image_aspect_ratio = w / h
        win_cfg = self._cfg.get("window", {})
        initial_width = int(win_cfg.get("initial_width", 1080))
        initial_height = int(initial_width / image_aspect_ratio)
        screen = QtWidgets.QApplication.primaryScreen().geometry()
        ratio_max = float(win_cfg.get("screen_ratio_max", 0.9))
        max_height = int(screen.height() * ratio_max)
        if initial_height > max_height:
            initial_height = max_height
            initial_width = int(initial_height * image_aspect_ratio)
        self.setGeometry(100, 100, initial_width, initial_height)
        min_w = int(win_cfg.get("min_width", 400))
        min_h = int(win_cfg.get("min_height", 300))
        self.setMinimumSize(min_w, min_h)

        self.image_label.setMouseTracking(True)
        self.image_label.setFocusPolicy(QtCore.Qt.StrongFocus)
        self.image_label.installEventFilter(self)
        self.update_display()

    def update_display(self):
        rgb = cv2.cvtColor(self.display_image, cv2.COLOR_BGR2RGB)
        h, w, ch = rgb.shape
        bytes_per_line = ch * w
        q_image = QtGui.QImage(rgb.data, w, h, bytes_per_line, QtGui.QImage.Format_RGB888)
        self.base_pixmap = QtGui.QPixmap.fromImage(q_image)
        self._render_with_transform()

    def _render_with_transform(self):
        if not hasattr(self, "base_pixmap") or self.base_pixmap is None:
            return
        label_w = self.image_label.width()
        label_h = self.image_label.height()
        if not self.initial_zoom_calculated and label_w > 0 and label_h > 0:
            img_w = self.base_pixmap.width()
            img_h = self.base_pixmap.height()
            scale_w = label_w / img_w
            scale_h = label_h / img_h
            self.zoom_factor = min(scale_w, scale_h)
            if label_w >= 200 and label_h >= 200:
                self.initial_zoom_calculated = True

        scaled_width = int(self.base_pixmap.width() * self.zoom_factor)
        scaled_height = int(self.base_pixmap.height() * self.zoom_factor)
        scaled_pixmap = self.base_pixmap.scaled(
            scaled_width, scaled_height,
            QtCore.Qt.KeepAspectRatio,
            QtCore.Qt.SmoothTransformation,
        )
        canvas = QtGui.QPixmap(self.image_label.size())
        canvas.fill(QtCore.Qt.black)
        painter = QtGui.QPainter(canvas)
        x = (self.image_label.width() - scaled_width) // 2 + self.pan_offset.x()
        y = (self.image_label.height() - scaled_height) // 2 + self.pan_offset.y()
        painter.drawPixmap(x, y, scaled_pixmap)
        self._draw_crosshair_and_coords(painter)
        painter.end()
        self.image_label.setPixmap(canvas)
        self.setWindowTitle(
            f"图像选点窗口 [{int(self.zoom_factor * 100)}%] - 左键选点 | 右键拖拽 | 滚轮缩放 | R重置 | ←→切换图像"
        )

    def _draw_crosshair_and_coords(self, painter: QtGui.QPainter):
        if self.current_mouse_pos is None:
            return
        painter.setRenderHint(QtGui.QPainter.Antialiasing)
        style = self._cfg.get("img_marker_style") or self._cfg.get("cursor_style")
        coord_text = None
        if self.current_image_coord is not None:
            img_x, img_y = self.current_image_coord
            coord_text = f"X: {img_x}, Y: {img_y}"
        if style:
            paint_img_marker(painter, self.current_mouse_pos, style, coord_text=coord_text)
        else:
            ch = self._cfg.get("crosshair", {})
            r, g, b, a = ch.get("color", [255, 255, 255, 180])
            pen = QtGui.QPen(QtGui.QColor(r, g, b, a))
            pen.setWidth(int(ch.get("pen_width", 1)))
            painter.setPen(pen)
            crosshair_size = int(ch.get("size", 10))
            mx = self.current_mouse_pos.x()
            my = self.current_mouse_pos.y()
            painter.drawLine(mx - crosshair_size, my, mx + crosshair_size, my)
            painter.drawLine(mx, my - crosshair_size, mx, my + crosshair_size)
            if coord_text:
                ct = self._cfg.get("coord_text", {})
                font = QtGui.QFont(
                    ct.get("font_family", "Arial"),
                    int(ct.get("font_size", 10)),
                    QtGui.QFont.Bold if ct.get("bold", True) else QtGui.QFont.Normal,
                )
                painter.setFont(font)
                text_x = int(ct.get("offset_x", 10))
                text_y = int(ct.get("offset_y", 20))
                o = ct.get("outline_color", [0, 0, 0, 220])
                painter.setPen(QtGui.QPen(QtGui.QColor(o[0], o[1], o[2], o[3])))
                for dx in [-1, 0, 1]:
                    for dy in [-1, 0, 1]:
                        if dx != 0 or dy != 0:
                            painter.drawText(text_x + dx, text_y + dy, coord_text)
                c = ct.get("color", [255, 255, 255, 255])
                painter.setPen(QtGui.QPen(QtGui.QColor(c[0], c[1], c[2], c[3])))
                painter.drawText(text_x, text_y, coord_text)
        if self.fine_tune_mode and self.pending_point is not None:
            self._draw_pending_point_marker(painter)

    def _draw_pending_point_marker(self, painter: QtGui.QPainter):
        if self.pending_point is None:
            return
        screen_pos = self._image_coord_to_screen(self.pending_point)
        if screen_pos is None:
            return
        pm = self._cfg.get("pending_marker", {})
        c = pm.get("color", [255, 255, 0, 220])
        pen = QtGui.QPen(QtGui.QColor(c[0], c[1], c[2], c[3]))
        pen.setWidth(int(pm.get("pen_width", 2)))
        pen.setStyle(QtCore.Qt.DashLine)
        painter.setPen(pen)
        radius = int(pm.get("radius", 15))
        painter.drawEllipse(screen_pos, radius, radius)
        pen.setStyle(QtCore.Qt.SolidLine)
        painter.setPen(pen)
        cross_size = int(pm.get("cross_size", 5))
        painter.drawLine(
            screen_pos.x() - cross_size, screen_pos.y(),
            screen_pos.x() + cross_size, screen_pos.y(),
        )
        painter.drawLine(
            screen_pos.x(), screen_pos.y() - cross_size,
            screen_pos.x(), screen_pos.y() + cross_size,
        )

    def _image_coord_to_screen(self, image_coord: Tuple[int, int]) -> Optional[QtCore.QPoint]:
        if not hasattr(self, "base_pixmap") or self.base_pixmap is None:
            return None
        img_x, img_y = image_coord
        scaled_width = self.base_pixmap.width() * self.zoom_factor
        scaled_height = self.base_pixmap.height() * self.zoom_factor
        offset_x = (self.image_label.width() - scaled_width) / 2.0 + self.pan_offset.x()
        offset_y = (self.image_label.height() - scaled_height) / 2.0 + self.pan_offset.y()
        screen_x = offset_x + img_x * self.zoom_factor
        screen_y = offset_y + img_y * self.zoom_factor
        return QtCore.QPoint(int(screen_x), int(screen_y))

    def eventFilter(self, obj, event):
        if obj == self.image_label:
            if event.type() == QtCore.QEvent.MouseButtonPress:
                return self.handle_mouse_press(event)
            if event.type() == QtCore.QEvent.MouseMove:
                return self.handle_mouse_move(event)
            if event.type() == QtCore.QEvent.MouseButtonRelease:
                return self.handle_mouse_release(event)
            if event.type() == QtCore.QEvent.Wheel:
                return self.handle_wheel(event)
        return super().eventFilter(obj, event)

    def handle_mouse_press(self, event):
        if event.button() == QtCore.Qt.LeftButton:
            # 如果已最终确认，阻止所有选点操作
            if self._is_finalized:
                return True
            coord = self.screen_to_image_coord(event.pos())
            if coord is not None:
                if self.fine_tune_mode:
                    self.pending_point = coord
                    self.current_image_coord = coord
                    self._render_with_transform()
                else:
                    self.enter_fine_tune_mode(coord)
        elif event.button() == QtCore.Qt.RightButton:
            self.is_panning = True
            self.last_pan_point = event.pos()
            self.setCursor(QtCore.Qt.ClosedHandCursor)
        return True

    def handle_mouse_move(self, event):
        self.current_mouse_pos = event.pos()
        self.current_image_coord = self.screen_to_image_coord(event.pos())
        if self.is_panning:
            delta = event.pos() - self.last_pan_point
            self.last_pan_point = event.pos()
            self.pan_offset += delta
        self._render_with_transform()
        return True

    def handle_mouse_release(self, event):
        if event.button() == QtCore.Qt.RightButton:
            self.is_panning = False
            self.setCursor(QtCore.Qt.ArrowCursor)
        return True

    def handle_wheel(self, event):
        mouse_pos = event.position().toPoint()
        if event.angleDelta().y() > 0:
            self.zoom_in(mouse_pos)
        else:
            self.zoom_out(mouse_pos)
        return True

    def screen_to_image_coord(self, pos: QtCore.QPoint) -> Optional[Tuple[int, int]]:
        if not hasattr(self, "base_pixmap") or self.base_pixmap is None:
            return None
        return map_label_pos_to_image_coord(
            pos=pos,
            pixmap=self.base_pixmap,
            zoom=self.zoom_factor,
            pan_offset=self.pan_offset,
            label_size=(self.image_label.width(), self.image_label.height()),
        )

    def _zoom_at(self, mouse_pos: Optional[QtCore.QPoint], factor: float, direction: int):
        if not hasattr(self, "base_pixmap") or self.base_pixmap is None:
            return
        old_zoom = self.zoom_factor
        scaled_width = self.base_pixmap.width() * old_zoom
        scaled_height = self.base_pixmap.height() * old_zoom
        if mouse_pos is not None and scaled_width > 0 and scaled_height > 0:
            old_offset_x = (self.image_label.width() - scaled_width) / 2.0 + self.pan_offset.x()
            old_offset_y = (self.image_label.height() - scaled_height) / 2.0 + self.pan_offset.y()
            rel_x = (mouse_pos.x() - old_offset_x) / scaled_width
            rel_y = (mouse_pos.y() - old_offset_y) / scaled_height
        else:
            rel_x = rel_y = 0.5
            mouse_pos = QtCore.QPoint(self.image_label.width() // 2, self.image_label.height() // 2)
        if direction > 0:
            self.zoom_factor = self.zoom_factor * factor
        else:
            self.zoom_factor = max(self.zoom_factor / factor, self._zoom_min())
        new_scaled_width = self.base_pixmap.width() * self.zoom_factor
        new_scaled_height = self.base_pixmap.height() * self.zoom_factor
        new_offset_x = (self.image_label.width() - new_scaled_width) / 2.0
        new_offset_y = (self.image_label.height() - new_scaled_height) / 2.0
        target_x = mouse_pos.x() - rel_x * new_scaled_width
        target_y = mouse_pos.y() - rel_y * new_scaled_height
        self.pan_offset.setX(int(target_x - new_offset_x))
        self.pan_offset.setY(int(target_y - new_offset_y))
        self._render_with_transform()

    def zoom_in(self, mouse_pos: Optional[QtCore.QPoint] = None):
        self._zoom_at(mouse_pos, self._zoom_in_factor(), 1)

    def zoom_out(self, mouse_pos: Optional[QtCore.QPoint] = None):
        self._zoom_at(mouse_pos, self._zoom_out_factor(), -1)

    def reset_view(self):
        self.initial_zoom_calculated = False
        self.pan_offset = QtCore.QPoint(0, 0)
        self._render_with_transform()

    def resizeEvent(self, event):
        super().resizeEvent(event)
        if hasattr(self, "base_pixmap"):
            self._render_with_transform()

    def draw_markers(
        self,
        pairs: List[PointPair],
        pending_point: Optional[Tuple[int, int]] = None,
        pending_confirmed: bool = False,
    ):
        saved_zoom = self.zoom_factor
        saved_pan = QtCore.QPoint(self.pan_offset)
        self.display_image = self.original_image.copy()
        m = self._cfg.get("marker", {})
        size = int(m.get("size", 12))
        thickness = int(m.get("thickness", 2))
        font_scale = float(m.get("font_scale", 0.6))
        font_thickness = int(m.get("font_thickness", 2))
        to = m.get("text_offset", (5, -5))
        dx, dy = (to[0], to[1]) if isinstance(to, (list, tuple)) else (5, -5)

        for pair in pairs:
            display_coord = self._get_display_coord(pair.image_coord)
            color = m.get("color_inlier", (0, 255, 0)) if pair.is_valid else m.get("color_outlier", (0, 0, 255))
            if isinstance(color, list):
                color = tuple(color)
            cv2.drawMarker(
                self.display_image, display_coord, color,
                getattr(cv2, m.get("type", "MARKER_TILTED_CROSS"), cv2.MARKER_TILTED_CROSS),
                size, thickness,
            )
            cv2.putText(
                self.display_image, str(pair.index),
                (display_coord[0] + dx, display_coord[1] + dy),
                cv2.FONT_HERSHEY_SIMPLEX, font_scale, color, font_thickness,
            )
        if pending_point is not None:
            display_coord = self._get_display_coord(pending_point)
            color = m.get("color_inlier", (0, 255, 0)) if pending_confirmed else m.get("color_pending", (0, 255, 255))
            if isinstance(color, list):
                color = tuple(color)
            cv2.drawMarker(
                self.display_image, display_coord, color,
                getattr(cv2, m.get("type", "MARKER_TILTED_CROSS"), cv2.MARKER_TILTED_CROSS),
                size, thickness,
            )
            cv2.putText(
                self.display_image, "?",
                (display_coord[0] + dx, display_coord[1] + dy),
                cv2.FONT_HERSHEY_SIMPLEX, font_scale, color, font_thickness,
            )
        self.zoom_factor = saved_zoom
        self.pan_offset = saved_pan
        self.update_display()

    def keyPressEvent(self, event):
        # 如果已最终确认，阻止所有键盘操作（除了窗口关闭）
        if self._is_finalized:
            if event.key() in (QtCore.Qt.Key_Escape, QtCore.Qt.Key_Q):
                self.stop_requested.emit()
            return

        if self.fine_tune_mode:
            # Ctrl+Enter：最终确认所有点
            if (event.key() in (QtCore.Qt.Key_Return, QtCore.Qt.Key_Enter)) and (event.modifiers() & QtCore.Qt.ControlModifier):
                # 先确认当前待定点
                if self.pending_point is not None:
                    self._confirmed_points.append(self.pending_point)
                    self._last_confirmed_pos = self.pending_point
                    self.point_confirmed.emit(self.pending_point)
                    self.pending_point = None
                    self.exit_fine_tune_mode()
                # 最终确认
                self._is_finalized = True
                self.points_finalized.emit(list(self._confirmed_points))
                self._render_with_transform()
                return
            # 普通 Enter：确认当前点
            if event.key() in (QtCore.Qt.Key_Return, QtCore.Qt.Key_Enter):
                self.confirm_fine_tune()
                return
            if event.key() == QtCore.Qt.Key_Escape:
                self.cancel_fine_tune()
                return
            if event.key() in (QtCore.Qt.Key_Up, QtCore.Qt.Key_Down, QtCore.Qt.Key_Left, QtCore.Qt.Key_Right):
                self.adjust_pending_point(event)
                return
        else:
            # 非 fine_tune 模式下，Enter 重新进入活动状态
            if event.key() in (QtCore.Qt.Key_Return, QtCore.Qt.Key_Enter):
                if self._last_confirmed_pos is not None:
                    self.enter_fine_tune_mode(self._last_confirmed_pos)
                return

        if event.key() in (QtCore.Qt.Key_Escape, QtCore.Qt.Key_Q):
            self.stop_requested.emit()
            return
        if event.key() in (QtCore.Qt.Key_Plus, QtCore.Qt.Key_Equal):
            self.zoom_in()
        elif event.key() == QtCore.Qt.Key_Minus:
            self.zoom_out()
        elif event.key() == QtCore.Qt.Key_R:
            self.reset_view()
        elif event.key() == QtCore.Qt.Key_Left:
            self.image_switch_requested.emit("prev")
        elif event.key() == QtCore.Qt.Key_Right:
            self.image_switch_requested.emit("next")
        else:
            super().keyPressEvent(event)

    def enter_fine_tune_mode(self, coord: Tuple[int, int]):
        self.fine_tune_mode = True
        self.pending_point = coord
        self.setWindowTitle(f"微调模式 [{int(self.zoom_factor * 100)}%] - 方向键调整 | Enter确认 | Esc取消")
        self._render_with_transform()

    def confirm_fine_tune(self):
        if self.pending_point is not None:
            self._confirmed_points.append(self.pending_point)
            self._last_confirmed_pos = self.pending_point
            self.point_confirmed.emit(self.pending_point)
            self.exit_fine_tune_mode()

    def cancel_fine_tune(self):
        self.exit_fine_tune_mode()

    def exit_fine_tune_mode(self):
        self.fine_tune_mode = False
        self.pending_point = None
        self.setWindowTitle(
            f"图像选点窗口 [{int(self.zoom_factor * 100)}%] - 左键选点 | 右键拖拽 | 滚轮缩放 | R重置 | ←→切换图像"
        )
        self._render_with_transform()

    def adjust_pending_point(self, event):
        if self.pending_point is None:
            return
        x, y = self.pending_point
        step = self._fine_tune_step_fast() if event.modifiers() & QtCore.Qt.ShiftModifier else self._fine_tune_step()
        if event.key() == QtCore.Qt.Key_Up:
            y -= step
        elif event.key() == QtCore.Qt.Key_Down:
            y += step
        elif event.key() == QtCore.Qt.Key_Left:
            x -= step
        elif event.key() == QtCore.Qt.Key_Right:
            x += step
        img_h, img_w = self.original_image.shape[:2]
        x = max(0, min(x, img_w - 1))
        y = max(0, min(y, img_h - 1))
        self.pending_point = (x, y)
        self.current_image_coord = self.pending_point
        self._render_with_transform()

    def closeEvent(self, event):
        self.stop_requested.emit()
        super().closeEvent(event)

    def update_image(self, image: np.ndarray, keep_view_state: bool = True):
        saved_zoom = self.zoom_factor if keep_view_state else 1.0
        saved_pan = QtCore.QPoint(self.pan_offset) if keep_view_state else QtCore.QPoint(0, 0)
        self.original_image = image.copy()
        self.display_image = image.copy()
        self.zoom_factor = saved_zoom
        self.pan_offset = saved_pan
        self.update_display()

    def _get_display_coord(self, undistorted_coord: Tuple[int, int]) -> Tuple[int, int]:
        if self.distortion_mode == "pointcloud_distort" and self.projection_mgr is not None:
            try:
                distorted_coords = self.projection_mgr.apply_distortion_to_2d([undistorted_coord])
                if distorted_coords is not None and len(distorted_coords) > 0:
                    return (
                        int(round(distorted_coords[0][0])),
                        int(round(distorted_coords[0][1])),
                    )
            except Exception:
                pass
        return undistorted_coord

    def finalize_points(self) -> List[Tuple[int, int]]:
        """程序化触发 Ctrl+Enter 最终确认（供 UI 按钮调用）。"""
        if self._is_finalized:
            return list(self._confirmed_points)
        # 如果有待定点，先自动确认
        if self.pending_point is not None:
            self._confirmed_points.append(self.pending_point)
            self._last_confirmed_pos = self.pending_point
            self.point_confirmed.emit(self.pending_point)
            self.pending_point = None
            self.exit_fine_tune_mode()
        # 最终确认
        self._is_finalized = True
        self.points_finalized.emit(list(self._confirmed_points))
        self._render_with_transform()
        return list(self._confirmed_points)

    def get_confirmed_points(self) -> List[Tuple[int, int]]:
        """获取已确认点列表（不包括待定点）。"""
        return list(self._confirmed_points)

    def is_finalized(self) -> bool:
        """检查是否已最终确认。"""
        return self._is_finalized
