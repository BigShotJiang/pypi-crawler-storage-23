# -*- coding: utf-8 -*-
"""
ImgMarker 样式：3 种组件（十字、外轮廓、文字）的配置与绘制。
"""

from typing import Any, Dict, Optional
from PySide6 import QtCore, QtGui


def get_default_img_marker_style() -> Dict[str, Any]:
    """返回默认 ImgMarker 样式（3 组件：crosshair, outer_contour, text）。"""
    return {
        "crosshair": {"enabled": True, "size": 10, "color": [255, 255, 255, 200], "thickness": 1, "line_style": "Solid", "style_type": "cross"},
        "outer_contour": {"enabled": True, "size": 20, "color": [200, 200, 200, 150], "thickness": 2, "line_style": "Solid", "shape": "circle"},
        "text": {"enabled": True, "content": "x, y", "font_family": "Arial", "font_size": 9, "color": [255, 255, 255, 255], "position": "top_right", "distance": 15, "offset_x": 8, "offset_y": -8},
    }


def _line_style_qt(style: str) -> QtCore.Qt.PenStyle:
    m = {"Solid": QtCore.Qt.SolidLine, "Dash": QtCore.Qt.DashLine, "Dot": QtCore.Qt.DotLine, "DashDot": QtCore.Qt.DashDotLine}
    return m.get(style, QtCore.Qt.SolidLine)


def _color_from_list(arr) -> QtGui.QColor:
    if len(arr) >= 4:
        return QtGui.QColor(arr[0], arr[1], arr[2], arr[3])
    if len(arr) >= 3:
        return QtGui.QColor(arr[0], arr[1], arr[2])
    return QtGui.QColor(255, 255, 255)


def make_gray_style(style: Dict[str, Any]) -> Dict[str, Any]:
    """将任意光标样式转换为灰色版本（用于已确认点）。"""
    gray_style = {}
    gray_color = [128, 128, 128, 200]

    for component in ["crosshair", "outer_contour", "text"]:
        if component in style:
            gray_style[component] = dict(style[component])
            gray_style[component]["color"] = gray_color
        elif component == "crosshair":
            gray_style[component] = {"enabled": True, "size": 10, "color": gray_color, "thickness": 1, "line_style": "Solid", "style_type": "cross"}
        elif component == "outer_contour":
            gray_style[component] = {"enabled": True, "size": 20, "color": gray_color, "thickness": 2, "line_style": "Solid", "shape": "circle"}
        elif component == "text":
            gray_style[component] = {"enabled": True, "content": "x, y", "font_family": "Arial", "font_size": 9, "color": gray_color, "position": "top_right", "distance": 15, "offset_x": 8, "offset_y": -8}

    return gray_style


def paint_img_marker(
    painter: QtGui.QPainter,
    center: QtCore.QPoint,
    style: Dict[str, Any],
    coord_text: Optional[str] = None,
    force_gray: bool = False,
) -> None:
    """在 painter 上以 center 为圆心绘制 ImgMarker（3 组件：外轮廓、十字、文字）。"""
    if force_gray:
        style = make_gray_style(style)

    painter.setRenderHint(QtGui.QPainter.Antialiasing)
    cx, cy = center.x(), center.y()

    # 1. 外轮廓 outer_contour：支持多种形状
    oc = style.get("outer_contour", {})
    if oc.get("enabled", True):
        size = int(oc.get("size", 20))
        pen = QtGui.QPen(_color_from_list(oc.get("color", [200, 200, 200, 150])))
        pen.setWidth(int(oc.get("thickness", 2)))
        pen.setStyle(_line_style_qt(oc.get("line_style", "Solid")))
        painter.setPen(pen)
        painter.setBrush(QtCore.Qt.NoBrush)

        shape = oc.get("shape", "circle")
        if shape == "circle":
            painter.drawEllipse(center, size, size)
        elif shape == "square":
            painter.drawRect(cx - size, cy - size, size * 2, size * 2)
        elif shape == "diamond":
            # 菱形
            points = [
                QtCore.QPoint(cx, cy - size),
                QtCore.QPoint(cx + size, cy),
                QtCore.QPoint(cx, cy + size),
                QtCore.QPoint(cx - size, cy),
            ]
            painter.drawPolygon(points)
        elif shape == "star":
            # 五角星
            import math
            points = []
            for i in range(10):
                angle = math.pi / 2 + i * math.pi / 5
                r = size if i % 2 == 0 else size * 0.4
                x = cx + r * math.cos(angle)
                y = cy - r * math.sin(angle)
                points.append(QtCore.QPoint(int(x), int(y)))
            painter.drawPolygon(points)

    # 2. 十字 crosshair：支持十字和X型
    ch = style.get("crosshair", {})
    if ch.get("enabled", True):
        size = int(ch.get("size", 10))
        pen = QtGui.QPen(_color_from_list(ch.get("color", [255, 255, 255, 200])))
        pen.setWidth(int(ch.get("thickness", 1)))
        pen.setStyle(_line_style_qt(ch.get("line_style", "Solid")))
        painter.setPen(pen)

        style_type = ch.get("style_type", "cross")
        if style_type == "cross":
            # 十字
            painter.drawLine(cx - size, cy, cx + size, cy)
            painter.drawLine(cx, cy - size, cx, cy + size)
        elif style_type == "x":
            # X型
            painter.drawLine(cx - size, cy - size, cx + size, cy + size)
            painter.drawLine(cx - size, cy + size, cx + size, cy - size)

    # 3. 文字 text：支持四个角位置和距离设置
    tx = style.get("text", {})
    if tx.get("enabled", True) and (coord_text or tx.get("content")):
        content = coord_text if coord_text is not None else tx.get("content", "x, y")
        font = QtGui.QFont(tx.get("font_family", "Arial"), int(tx.get("font_size", 9)))
        painter.setFont(font)
        painter.setPen(QtGui.QPen(_color_from_list(tx.get("color", [255, 255, 255, 255]))))

        # 获取位置和距离
        position = tx.get("position", "top_right")
        distance = int(tx.get("distance", 15))

        # 根据位置计算偏移
        if position == "top_left":
            text_x = cx - distance
            text_y = cy - distance
        elif position == "top_right":
            text_x = cx + distance
            text_y = cy - distance
        elif position == "bottom_left":
            text_x = cx - distance
            text_y = cy + distance
        elif position == "bottom_right":
            text_x = cx + distance
            text_y = cy + distance
        else:
            # 默认右上角
            text_x = cx + distance
            text_y = cy - distance

        painter.drawText(text_x, text_y, str(content))


def build_preset(preset_id: int) -> Dict[str, Any]:
    """生成 20 种预设之一（4×5 网格用），preset_id 0..19。"""
    base = get_default_img_marker_style()
    # 按 preset_id 变化各组件：0-4 变 crosshair，5-9 变 center，10-14 变 contour，15-19 变 text 等
    row = preset_id // 5
    col = preset_id % 5
    colors = [
        [255, 255, 255, 200],
        [255, 200, 100, 220],
        [100, 255, 200, 220],
        [255, 100, 255, 220],
        [100, 200, 255, 220],
    ]
    sizes = [8, 10, 12, 15, 20]
    if row == 0:
        base["crosshair"]["size"] = sizes[col]
        base["crosshair"]["color"] = colors[col]
        base["crosshair"]["thickness"] = 1 + (col % 2)
    elif row == 1:
        base["center_point"]["size"] = 2 + col
        base["center_point"]["color"] = colors[col]
    elif row == 2:
        base["outer_contour"]["size"] = 15 + col * 3
        base["outer_contour"]["color"] = colors[col]
        base["outer_contour"]["line_style"] = ["Solid", "Dash", "Dot", "DashDot", "Solid"][col]
    else:
        base["text"]["font_size"] = 7 + col
        base["text"]["color"] = colors[col]
        base["text"]["content"] = f"P{preset_id}"
    return base
