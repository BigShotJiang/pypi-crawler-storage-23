# -*- coding: utf-8 -*-
# Form generated from reading UI file 'image_picker_window.ui'
# WARNING! All changes made in this file will be lost when recompiling UI file!

from PySide6.QtCore import QCoreApplication, QMetaObject, QPoint, QSize, Qt
from PySide6.QtGui import QPixmap
from PySide6.QtWidgets import QLabel, QSizePolicy, QVBoxLayout, QWidget


class Ui_ImagePickerWindow(object):
    def setupUi(self, ImagePickerWindow):
        if not ImagePickerWindow.objectName():
            ImagePickerWindow.setObjectName("ImagePickerWindow")
        ImagePickerWindow.resize(800, 600)
        self.verticalLayout = QVBoxLayout(ImagePickerWindow)
        self.verticalLayout.setSpacing(0)
        self.verticalLayout.setObjectName("verticalLayout")
        self.verticalLayout.setContentsMargins(0, 0, 0, 0)
        self.image_label = QLabel(ImagePickerWindow)
        self.image_label.setObjectName("image_label")
        self.image_label.setStyleSheet("QLabel { background-color: black; }")
        self.image_label.setAlignment(Qt.AlignCenter)
        sizePolicy = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        self.image_label.setSizePolicy(sizePolicy)
        self.image_label.setMinimumSize(QSize(0, 0))
        self.verticalLayout.addWidget(self.image_label)
        self.retranslateUi(ImagePickerWindow)
        QMetaObject.connectSlotsByName(ImagePickerWindow)

    def retranslateUi(self, ImagePickerWindow):
        ImagePickerWindow.setWindowTitle(
            QCoreApplication.translate(
                "ImagePickerWindow",
                "图像选点窗口 - 左键选点 | 右键拖拽 | 滚轮缩放 | R重置 | ←→切换图像",
                None,
            )
        )
        self.image_label.setText("")
