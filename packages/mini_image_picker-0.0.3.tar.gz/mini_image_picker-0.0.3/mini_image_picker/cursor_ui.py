# -*- coding: utf-8 -*-
"""
图像标记样式展示与自定义 UI：4×5 展示窗口、自定义编辑器对话框。
"""

from typing import Any, Dict, Optional
from PySide6 import QtCore, QtGui, QtWidgets

from .img_marker_style import get_default_img_marker_style, build_preset, paint_img_marker


class ImgMarkerPreviewWidget(QtWidgets.QWidget):
    """单个图像标记预览：在中心绘制一种样式，可选显示预设编号。"""

    def __init__(self, style: Dict[str, Any], label: str = "", parent=None):
        super().__init__(parent)
        self._style = dict(style)
        self._label = label
        self.setMinimumSize(80, 80)
        self.setSizePolicy(QtWidgets.QSizePolicy.Policy.Fixed, QtWidgets.QSizePolicy.Policy.Fixed)

    def set_style(self, style: Dict[str, Any]) -> None:
        self._style = dict(style)
        self.update()

    def paintEvent(self, event):
        super().paintEvent(event)
        painter = QtGui.QPainter(self)
        painter.fillRect(self.rect(), QtCore.Qt.darkGray)
        center = self.rect().center()
        text_for_marker = self._label if self._label else None
        paint_img_marker(painter, center, self._style, coord_text=text_for_marker)
        if self._label and not self._style.get("text", {}).get("enabled", True):
            painter.setPen(QtGui.QPen(QtCore.Qt.white))
            painter.drawText(2, self.height() - 2, self._label)
        painter.end()


class ImgMarkerStyleEditorDialog(QtWidgets.QDialog):
    """自定义图像标记样式：4 种组件（十字、中心点、外轮廓、文字）各有 有/无、大小、颜色、粗细、线条样式。"""

    def __init__(self, initial_style: Optional[Dict[str, Any]] = None, parent=None):
        super().__init__(parent)
        self.setWindowTitle("自定义图像标记样式")
        self._style = dict(initial_style or get_default_img_marker_style())
        self._build_ui()
        self._sync_ui_to_style()

    def _build_ui(self):
        layout = QtWidgets.QVBoxLayout(self)

        # 预览
        self._preview = ImgMarkerPreviewWidget(self._style, "预览", self)
        self._preview.setMinimumSize(120, 120)
        layout.addWidget(QtWidgets.QLabel("预览："))
        layout.addWidget(self._preview, 0, QtCore.Qt.AlignCenter)

        scroll = QtWidgets.QScrollArea()
        scroll.setWidgetResizable(True)
        form_w = QtWidgets.QWidget()
        form = QtWidgets.QFormLayout(form_w)

        self._widgets = {}
        for comp_key, comp_label in [
            ("crosshair", "十字"),
            ("center_point", "中心点"),
            ("outer_contour", "外轮廓"),
            ("text", "文字"),
        ]:
            g = QtWidgets.QGroupBox(comp_label)
            gl = QtWidgets.QFormLayout(g)
            w = {}
            w["enabled"] = QtWidgets.QCheckBox("启用")
            w["enabled"].toggled.connect(self._on_change)
            gl.addRow("", w["enabled"])
            w["size"] = QtWidgets.QSpinBox()
            w["size"].setRange(1, 100)
            w["size"].valueChanged.connect(self._on_change)
            gl.addRow("大小:", w["size"])
            w["color"] = QtWidgets.QPushButton("颜色")
            w["color"].clicked.connect(lambda checked, c=comp_key: self._pick_color(c))
            gl.addRow("颜色:", w["color"])
            w["thickness"] = QtWidgets.QSpinBox()
            w["thickness"].setRange(1, 10)
            w["thickness"].valueChanged.connect(self._on_change)
            gl.addRow("粗细:", w["thickness"])
            if comp_key == "text":
                w["content"] = QtWidgets.QLineEdit()
                w["content"].setPlaceholderText("x, y")
                w["content"].textChanged.connect(self._on_change)
                gl.addRow("内容:", w["content"])
                w["font_family"] = QtWidgets.QLineEdit()
                w["font_family"].setPlaceholderText("Arial")
                gl.addRow("字体:", w["font_family"])
                w["font_family"].textChanged.connect(self._on_change)
                w["font_size"] = QtWidgets.QSpinBox()
                w["font_size"].setRange(6, 24)
                w["font_size"].valueChanged.connect(self._on_change)
                gl.addRow("字号:", w["font_size"])
                w["offset_x"] = QtWidgets.QSpinBox()
                w["offset_x"].setRange(-50, 50)
                w["offset_x"].valueChanged.connect(self._on_change)
                gl.addRow("偏移X:", w["offset_x"])
                w["offset_y"] = QtWidgets.QSpinBox()
                w["offset_y"].setRange(-50, 50)
                w["offset_y"].valueChanged.connect(self._on_change)
                gl.addRow("偏移Y:", w["offset_y"])
            else:
                w["line_style"] = QtWidgets.QComboBox()
                w["line_style"].addItems(["Solid", "Dash", "Dot", "DashDot"])
                w["line_style"].currentTextChanged.connect(self._on_change)
                gl.addRow("线型:", w["line_style"])
            self._widgets[comp_key] = w
            form.addRow(g)

        scroll.setWidget(form_w)
        layout.addWidget(scroll)

        bb = QtWidgets.QDialogButtonBox(QtWidgets.QDialogButtonBox.StandardButton.Ok | QtWidgets.QDialogButtonBox.StandardButton.Cancel)
        bb.accepted.connect(self.accept)
        bb.rejected.connect(self.reject)
        layout.addWidget(bb)

    def _pick_color(self, comp_key: str):
        comp = self._style.get(comp_key, {})
        c = comp.get("color", [255, 255, 255, 255])
        if len(c) >= 4:
            initial = QtGui.QColor(c[0], c[1], c[2], c[3])
        else:
            initial = QtGui.QColor(255, 255, 255)
        color = QtWidgets.QColorDialog.getColor(initial, self, "选择颜色")
        if color.isValid():
            self._style.setdefault(comp_key, {})["color"] = [color.red(), color.green(), color.blue(), color.alpha()]
            self._sync_ui_to_style()
            self._preview.set_style(self._style)

    def _on_change(self):
        self._sync_style_from_ui()
        self._preview.set_style(self._style)

    def _sync_ui_to_style(self):
        for comp_key, w in self._widgets.items():
            comp = self._style.get(comp_key, {})
            w["enabled"].setChecked(comp.get("enabled", True))
            w["size"].setValue(int(comp.get("size", 10)))
            w["thickness"].setValue(int(comp.get("thickness", 1)))
            if "line_style" in w:
                ls = comp.get("line_style", "Solid")
                idx = w["line_style"].findText(ls)
                if idx >= 0:
                    w["line_style"].setCurrentIndex(idx)
            if comp_key == "text":
                w.get("content", None) and w["content"].setText(comp.get("content", "x, y"))
                w.get("font_family", None) and w["font_family"].setText(comp.get("font_family", "Arial"))
                w.get("font_size", None) and w["font_size"].setValue(int(comp.get("font_size", 9)))
                w.get("offset_x", None) and w["offset_x"].setValue(int(comp.get("offset_x", 8)))
                w.get("offset_y", None) and w["offset_y"].setValue(int(comp.get("offset_y", -8)))
        self._preview.set_style(self._style)

    def _sync_style_from_ui(self):
        for comp_key, w in self._widgets.items():
            comp = self._style.setdefault(comp_key, {})
            comp["enabled"] = w["enabled"].isChecked()
            comp["size"] = w["size"].value()
            comp["thickness"] = w["thickness"].value()
            if "line_style" in w:
                comp["line_style"] = w["line_style"].currentText()
            if comp_key == "text":
                comp["content"] = w["content"].text() or "x, y"
                comp["font_family"] = w["font_family"].text() or "Arial"
                comp["font_size"] = w["font_size"].value()
                comp["offset_x"] = w["offset_x"].value()
                comp["offset_y"] = w["offset_y"].value()
            comp["color"] = comp.get("color", [255, 255, 255, 255])

    def get_style(self) -> Dict[str, Any]:
        self._sync_style_from_ui()
        return dict(self._style)


class ImgMarkerShowcaseWindow(QtWidgets.QWidget):
    """4×5 展示窗口：20 种预设图像标记样式；按钮打开自定义编辑器。"""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("图像标记样式展示 - 4×5 预设")
        layout = QtWidgets.QVBoxLayout(self)

        grid = QtWidgets.QGridLayout()
        for i in range(20):
            style = build_preset(i)
            w = ImgMarkerPreviewWidget(style, f"#{i}")
            row, col = i // 5, i % 5
            grid.addWidget(w, row, col)
        layout.addLayout(grid)

        btn = QtWidgets.QPushButton("自定义图像标记样式...")
        btn.clicked.connect(self._open_editor)
        layout.addWidget(btn)

    def _open_editor(self):
        from .img_marker_style import get_default_img_marker_style
        dlg = ImgMarkerStyleEditorDialog(get_default_img_marker_style(), self)
        if dlg.exec() == QtWidgets.QDialog.DialogCode.Accepted:
            style = dlg.get_style()
            # 可选：应用到全局或仅提示
            QtWidgets.QMessageBox.information(self, "已保存", "自定义样式已获取，可在程序中传入 config['img_marker_style'] 使用。")
