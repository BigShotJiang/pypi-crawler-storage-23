# -*- coding: utf-8 -*-
"""
坐标转换：将 label 坐标映射到原始图像坐标（ZoomPanLabel 与 ImagePickerWindow 共用）
"""

from typing import Optional, Tuple
from PySide6 import QtCore, QtGui


def map_label_pos_to_image_coord(
    pos: QtCore.QPoint,
    pixmap: Optional[QtGui.QPixmap],
    zoom: float,
    pan_offset: QtCore.QPoint,
    label_size: Tuple[int, int],
) -> Optional[Tuple[int, int]]:
    """
    将 label 坐标映射到原始图像坐标。

    Args:
        pos:          label 上的点击位置
        pixmap:       当前显示的 QPixmap
        zoom:         当前缩放系数
        pan_offset:   当前平移偏移（QPoint）
        label_size:   (width, height)

    Returns:
        (x, y) 若点在原图范围内，否则 None
    """
    if pixmap is None:
        return None

    pixmap_w = pixmap.width()
    pixmap_h = pixmap.height()
    if pixmap_w <= 0 or pixmap_h <= 0 or zoom <= 0:
        return None

    label_w, label_h = label_size

    scaled_w = pixmap_w * zoom
    scaled_h = pixmap_h * zoom

    offset_x = (label_w - scaled_w) / 2.0 + pan_offset.x()
    offset_y = (label_h - scaled_h) / 2.0 + pan_offset.y()

    x = (pos.x() - offset_x) / zoom
    y = (pos.y() - offset_y) / zoom

    if 0 <= x < pixmap_w and 0 <= y < pixmap_h:
        return int(round(x)), int(round(y))
    return None
