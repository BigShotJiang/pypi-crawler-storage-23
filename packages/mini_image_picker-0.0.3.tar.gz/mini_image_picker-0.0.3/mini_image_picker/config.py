# -*- coding: utf-8 -*-
"""
配置默认值与合并：供 ZoomPanLabel、ImagePickerWindow、PickerSession 使用。
"""

from typing import Any, Dict, Optional


def get_default_config() -> Dict[str, Any]:
    """返回包内默认配置（覆盖计划第 3 节全部 key）。未传入的项由调用方用此默认值填充。"""
    return {
        "picking": {
            # 主窗口/弹窗均适用：最多缓存多少个已确认的 img_marker 点（超限丢弃最早的点，保留最新 N 个）
            "max_points": 30,
        },
        "hotkeys": {
            "confirm": ["Return", "Enter"],
            "finalize": ["Ctrl+Return", "Ctrl+Enter"],  # 最终确认所有选点
            "cancel": "Escape",
            "stop": ["Escape", "Q"],
            "zoom_in": ["Plus", "Equal"],
            "zoom_out": "Minus",
            "reset_view": "R",
            "image_prev": "Left",
            "image_next": "Right",
            "fine_tune_step": 1,
            "fine_tune_step_fast": 5,
        },
        "crosshair": {
            "size": 10,
            "color": [255, 255, 255, 180],
            "pen_width": 1,
        },
        "coord_text": {
            "font_family": "Arial",
            "font_size": 10,
            "bold": True,
            "color": [255, 255, 255, 255],
            "outline_color": [0, 0, 0, 220],
            "offset_x": 10,
            "offset_y": 20,
        },
        "pending_marker": {
            "radius": 15,
            "pen_width": 2,
            "pen_style": "DashLine",
            "color": [255, 255, 0, 220],
            "cross_size": 5,
        },
        "marker": {
            "type": "MARKER_TILTED_CROSS",
            "size": 12,
            "thickness": 2,
            "color_inlier": (0, 255, 0),
            "color_outlier": (0, 0, 255),
            "color_pending": (0, 255, 255),
            "color_confirmed": (128, 128, 128),  # 已确认点的灰色
            "font_scale": 0.6,
            "font_thickness": 2,
            "text_offset": (5, -5),
        },
        "window": {
            "initial_width": 1080,
            "min_width": 400,
            "min_height": 300,
            "screen_ratio_max": 0.9,
            "label_background": "black",
        },
        "zoom": {
            "factor_in": 1.2,
            "factor_out": 1.2,
            "min_factor": 0.1,
        },
        "zoom_pan_label": {
            "zoom_factor_in": 1.1,
            "zoom_factor_out": 1.1,
            "zoom_min": 0.2,
            # 主窗口默认选点开启（可通过 ZoomPanLabel.set_pick_mode(False) 关闭）
            "pick_enabled_default": True,
            # 主窗口 img_marker 叠加绘制默认开启（可通过 ZoomPanLabel.set_img_marker_enabled(False) 关闭）
            "img_marker_enabled_default": True,
            # 有活动点时是否同时绘制已确认点；False 时只绘制活动点（只显示当前一个），供主窗口 3D 选点等场景
            "draw_confirmed_while_active": True,
        },
        # img_marker 样式（推荐使用 img_marker_style；cursor_style 仅为兼容历史配置别名）
        "img_marker_style": {
            "crosshair": {"enabled": True, "size": 10, "color": [255, 255, 255, 200], "thickness": 1, "line_style": "Solid"},
            "center_point": {"enabled": True, "size": 3, "color": [255, 255, 0, 255], "thickness": 1, "line_style": "Solid"},
            "outer_contour": {"enabled": True, "size": 20, "color": [200, 200, 200, 150], "thickness": 2, "line_style": "Solid"},
            "text": {"enabled": True, "content": "x, y", "font_family": "Arial", "font_size": 9, "color": [255, 255, 255, 255], "offset_x": 8, "offset_y": -8},
        },
        "cursor_style": {
            "crosshair": {"enabled": True, "size": 10, "color": [255, 255, 255, 200], "thickness": 1, "line_style": "Solid"},
            "center_point": {"enabled": True, "size": 3, "color": [255, 255, 0, 255], "thickness": 1, "line_style": "Solid"},
            "outer_contour": {"enabled": True, "size": 20, "color": [200, 200, 200, 150], "thickness": 2, "line_style": "Solid"},
            "text": {"enabled": True, "content": "x, y", "font_family": "Arial", "font_size": 9, "color": [255, 255, 255, 255], "offset_x": 8, "offset_y": -8},
        },
        # 已确认点的灰色样式
        "img_marker_style_confirmed": {
            "crosshair": {"enabled": True, "size": 10, "color": [128, 128, 128, 200], "thickness": 1, "line_style": "Solid"},
            "center_point": {"enabled": True, "size": 3, "color": [128, 128, 128, 255], "thickness": 1, "line_style": "Solid"},
            "outer_contour": {"enabled": True, "size": 20, "color": [128, 128, 128, 150], "thickness": 2, "line_style": "Solid"},
            "text": {"enabled": True, "content": "x, y", "font_family": "Arial", "font_size": 9, "color": [128, 128, 128, 255], "offset_x": 8, "offset_y": -8},
        },
    }


def _deep_merge(base: Dict, override: Optional[Dict]) -> Dict:
    """递归合并 override 到 base，override 中存在的 key 覆盖 base。不修改 base。"""
    if override is None:
        return dict(base)
    result = dict(base)
    for k, v in override.items():
        if k in result and isinstance(result[k], dict) and isinstance(v, dict):
            result[k] = _deep_merge(result[k], v)
        else:
            result[k] = v
    return result


def get_merged_config(override: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """返回默认配置与 override 的合并结果；override 中未提供的 key 使用默认值。"""
    return _deep_merge(get_default_config(), override)
