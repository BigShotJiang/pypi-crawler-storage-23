def main():
    print("Hello from sina-finace-stock!")


if __name__ == "__main__":
    main()
