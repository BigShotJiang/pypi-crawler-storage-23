"""
AgniPod SDK — API Key Management
===================================

Usage::

    from agnipod import AgniPod

    client = AgniPod()

    # List keys
    keys = client.keys.list()
    for k in keys:
        print(k.id, k.name, k.is_active)

    # Create a new key
    new_key = client.keys.create(name="production-key")
    print(new_key.key)   # full secret — store it safely!
"""

from __future__ import annotations
from typing import Optional

from ._client import HttpClient
from ._types import ApiKey, ApiKeyCreated, ApiKeyList, KeyUsage, _APIObject


class Keys:
    """Namespace for ``/keys`` operations."""

    def __init__(self, client: HttpClient):
        self._client = client

    def create(self, *, name: Optional[str] = None) -> ApiKeyCreated:
        """Create a new API key.

        Parameters
        ----------
        name : str, optional
            Friendly name for the key.

        Returns
        -------
        ApiKeyCreated
            Contains the full ``.key`` (secret) — store it securely.
        """
        payload = {}
        if name:
            payload["name"] = name
        data = self._client.post("/keys", json_data=payload)
        key_data = data.get("key", data)
        return ApiKeyCreated(key_data)

    def list(
        self,
        *,
        page: int = 1,
        limit: int = 20,
        include_revoked: bool = False,
    ) -> ApiKeyList:
        """List API keys.

        Parameters
        ----------
        page : int
            Page number.
        limit : int
            Items per page.
        include_revoked : bool
            Include revoked keys in the listing.

        Returns
        -------
        ApiKeyList
            Iterable of ``ApiKey`` objects.
        """
        data = self._client.get("/keys", params={
            "page": page,
            "limit": limit,
            "include_revoked": include_revoked,
        })
        return ApiKeyList(data)

    def get(self, key_id: int) -> ApiKey:
        """Get details of a specific API key.

        Parameters
        ----------
        key_id : int

        Returns
        -------
        ApiKey
        """
        data = self._client.get(f"/keys/{key_id}")
        key_data = data.get("key", data)
        return ApiKey(key_data)

    def update(self, key_id: int, *, name: Optional[str] = None, regenerate: Optional[bool] = None) -> _APIObject:
        """Update an API key.

        Parameters
        ----------
        key_id : int
        name : str, optional
            New name.
        regenerate : bool, optional
            If ``True``, regenerate the key secret.

        Returns
        -------
        _APIObject
            Contains ``success`` and optionally the new ``key``.
        """
        payload = {}
        if name is not None:
            payload["name"] = name
        if regenerate is not None:
            payload["regenerate"] = regenerate
        data = self._client.put(f"/keys/{key_id}", json_data=payload)
        return _APIObject(data)

    def delete(self, key_id: int) -> _APIObject:
        """Permanently delete an API key.

        Parameters
        ----------
        key_id : int

        Returns
        -------
        _APIObject
        """
        data = self._client.delete(f"/keys/{key_id}")
        return _APIObject(data)

    def toggle(self, key_id: int) -> _APIObject:
        """Toggle an API key between active and inactive.

        Parameters
        ----------
        key_id : int

        Returns
        -------
        _APIObject
        """
        data = self._client.patch(f"/keys/{key_id}/toggle")
        return _APIObject(data)

    def usage(self, key_id: int, *, days: int = 30) -> KeyUsage:
        """Get usage statistics for a specific key.

        Parameters
        ----------
        key_id : int
        days : int
            Number of days to look back (1–90, default 30).

        Returns
        -------
        KeyUsage
        """
        data = self._client.get(f"/keys/{key_id}/usage", params={"days": days})
        usage_data = data.get("usage", data)
        return KeyUsage(usage_data)
