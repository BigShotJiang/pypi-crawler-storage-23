"""Allow running the AgniPod CLI via ``python -m agnipod``."""

from agnipod._cli import main

main()
