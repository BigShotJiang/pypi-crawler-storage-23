"""
AgniPod SDK — Text Generation
================================

Usage::

    from agnipod import AgniPod

    client = AgniPod()

    response = client.generate.create(
        model="qwen3:8b",
        prompt="Once upon a time",
    )
    print(response.content)
"""

from __future__ import annotations
from typing import Any, Dict, List, Optional

from ._client import HttpClient
from ._types import Completion
from ._exceptions import ValidationError


class Generate:
    """Namespace for ``/generate`` operations."""

    def __init__(self, client: HttpClient):
        self._client = client

    def create(
        self,
        *,
        model: str,
        prompt: str,
        system_prompt: Optional[str] = None,
        context: Optional[str] = None,
        temperature: Optional[float] = None,
        top_p: Optional[float] = None,
        top_k: Optional[int] = None,
        min_p: Optional[float] = None,
        max_tokens: Optional[int] = None,
        stop: Optional[List[str]] = None,
        repeat_penalty: Optional[float] = None,
        presence_penalty: Optional[float] = None,
        frequency_penalty: Optional[float] = None,
        seed: Optional[int] = None,
    ) -> Completion:
        """Create a text completion.

        Parameters
        ----------
        model : str
            Name of the model (e.g. ``"qwen3:8b"``).
        prompt : str
            The input text to complete.
        system_prompt : str, optional
            System-level instruction prepended to the prompt.
        context : str, optional
            Additional context for the model.
        temperature, top_p, top_k, min_p, max_tokens, stop, repeat_penalty,
        presence_penalty, frequency_penalty, seed :
            Optional sampling parameters.

        Returns
        -------
        Completion
            Response with ``.content``, ``.prompt_tokens``, etc.
        """
        if not model:
            raise ValidationError("model is required")
        if not prompt:
            raise ValidationError("prompt is required")

        payload: Dict[str, Any] = {
            "model": model,
            "prompt": prompt,
        }

        if system_prompt is not None:
            payload["system_prompt"] = system_prompt
        if context is not None:
            payload["context"] = context

        _add_optional(payload, "temperature", temperature)
        _add_optional(payload, "top_p", top_p)
        _add_optional(payload, "top_k", top_k)
        _add_optional(payload, "min_p", min_p)
        _add_optional(payload, "max_tokens", max_tokens)
        _add_optional(payload, "stop", stop)
        _add_optional(payload, "repeat_penalty", repeat_penalty)
        _add_optional(payload, "presence_penalty", presence_penalty)
        _add_optional(payload, "frequency_penalty", frequency_penalty)
        _add_optional(payload, "seed", seed)

        data = self._client.post("/generate", json_data=payload)
        return Completion(data)


def _add_optional(d: dict, key: str, value: Any):
    if value is not None:
        d[key] = value
