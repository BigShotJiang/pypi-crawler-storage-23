# NeuroMath

NeuroMath is a lightweight symbolic mathematical DSL (Domain Specific Language) built on top of SymPy.  
It provides a clean notebook-style computation experience with both CLI and Streamlit GUI support.

---

## ✨ Features

- Symbolic computation
- Variable assignment
- Function definitions
- Differentiation
- Expression evaluation
- Built-in constants (`pi`, `e`)
- CLI interface
- Notebook-style Streamlit GUI
- Lightweight and easy to extend

---

## 📦 Installation

Install from PyPI:

```bash
pip install neuromath