"""
Simple Math - A lightweight Python package for numeric and set operations.
"""

from . import numbers
from . import sets
from . import equations

__version__ = "0.3.0"
__all__ = ["numbers", "sets", "equations"]
