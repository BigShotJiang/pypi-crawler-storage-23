"""
Set operations: union, intersection, difference, symmetric_difference, etc.
"""

from typing import Set, TypeVar

T = TypeVar("T")


def union(a: Set[T], b: Set[T]) -> Set[T]:
    """Return the union of sets a and b (elements in a or b or both)."""
    return a | b


def intersection(a: Set[T], b: Set[T]) -> Set[T]:
    """Return the intersection of sets a and b (elements in both)."""
    return a & b


def difference(a: Set[T], b: Set[T]) -> Set[T]:
    """Return the set difference a - b (elements in a but not in b)."""
    return a - b


def symmetric_difference(a: Set[T], b: Set[T]) -> Set[T]:
    """Return the symmetric difference (elements in a or b but not both)."""
    return a ^ b


def is_subset(a: Set[T], b: Set[T]) -> bool:
    """Return True if a is a subset of b (every element of a is in b)."""
    return a <= b


def is_superset(a: Set[T], b: Set[T]) -> bool:
    """Return True if a is a superset of b (every element of b is in a)."""
    return a >= b


def is_disjoint(a: Set[T], b: Set[T]) -> bool:
    """Return True if a and b have no elements in common."""
    return a.isdisjoint(b)
