"""
Operations on linear equations in one variable: a*x + b = c.

An equation is represented as (a, b, c) meaning a*x + b = c.
"""

from typing import Optional, Tuple

# Equation as (a, b, c) for a*x + b = c
LinearEquation = Tuple[float, float, float]


def solve_linear(a: float, b: float, c: float) -> Optional[float]:
    """Solve a*x + b = c for x. Returns None if a is 0 (no unique solution)."""
    if a == 0:
        return None
    return (c - b) / a


def evaluate_linear(a: float, b: float, x: float) -> float:
    """Evaluate the left-hand side a*x + b at the given x."""
    return a * x + b


def add_equations(
    eq1: LinearEquation, eq2: LinearEquation
) -> LinearEquation:
    """Add two equations (a1*x+b1=c1) + (a2*x+b2=c2) -> ((a1+a2)*x + (b1+b2) = c1+c2)."""
    a1, b1, c1 = eq1
    a2, b2, c2 = eq2
    return (a1 + a2, b1 + b2, c1 + c2)


def subtract_equations(
    eq1: LinearEquation, eq2: LinearEquation
) -> LinearEquation:
    """Subtract eq2 from eq1: (a1*x+b1=c1) - (a2*x+b2=c2)."""
    a1, b1, c1 = eq1
    a2, b2, c2 = eq2
    return (a1 - a2, b1 - b2, c1 - c2)


def scale_equation(eq: LinearEquation, k: float) -> LinearEquation:
    """Multiply equation by scalar k: k*(a*x + b) = k*c."""
    a, b, c = eq
    return (k * a, k * b, k * c)
