"""
Numeric operations: add, subtract, multiply, divide, power, modulo.
"""


def add(a: float, b: float) -> float:
    """Return a + b."""
    return a + b


def subtract(a: float, b: float) -> float:
    """Return a - b."""
    return a - b


def multiply(a: float, b: float) -> float:
    """Return a * b."""
    return a * b


def divide(a: float, b: float) -> float:
    """Return a / b. Raises ZeroDivisionError if b is 0."""
    if b == 0:
        raise ZeroDivisionError("division by zero")
    return a / b


def power(a: float, b: float) -> float:
    """Return a ** b."""
    return a ** b


def modulo(a: float, b: float) -> float:
    """Return a % b. Raises ZeroDivisionError if b is 0."""
    if b == 0:
        raise ZeroDivisionError("integer division or modulo by zero")
    return a % b
