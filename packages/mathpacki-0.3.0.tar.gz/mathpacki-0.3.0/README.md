# mathpacki

A lightweight Python package for numeric and set operations.

## Installation

```bash
pip install mathpacki
```

## Usage

### Modular imports

```python
from mathpacki import numbers
from mathpacki import sets
from mathpacki import equations
```

### Number operations

```python
from mathpacki import numbers

numbers.add(2, 3)        # 5
numbers.subtract(10, 4)  # 6
numbers.multiply(3, 7)   # 21
numbers.divide(15, 3)    # 5.0
numbers.power(2, 8)      # 256
numbers.modulo(17, 5)    # 2
```

Or import individual functions:

```python
from mathpacki.numbers import add, multiply
add(2, 3)    # 5
multiply(3, 7)  # 21
```

### Set operations

```python
from mathpacki import sets

a, b = {1, 2, 3}, {2, 3, 4}

sets.union(a, b)                  # {1, 2, 3, 4}
sets.intersection(a, b)           # {2, 3}
sets.difference(a, b)             # {1}
sets.symmetric_difference(a, b)   # {1, 4}
sets.is_subset({1, 2}, a)         # True
sets.is_superset(a, {1, 2})       # True
sets.is_disjoint({1, 2}, {3, 4})  # True
```

Or import individual functions:

```python
from mathpacki.sets import union, intersection
union({1, 2}, {2, 3})  # {1, 2, 3}
```

### Equation operations (linear: a*x + b = c)

Equations are represented as tuples `(a, b, c)` for **a·x + b = c**.

```python
from mathpacki import equations

# Solve a*x + b = c for x
equations.solve_linear(2, -3, 7)   # 2x - 3 = 7  ->  x = 5.0
equations.solve_linear(1, 0, 4)    # x = 4  ->  4.0

# Evaluate left-hand side at x
equations.evaluate_linear(2, -3, 5)   # 2*5 - 3 = 7.0

# Operate on equations (each eq = (a, b, c) for a*x + b = c)
eq1 = (2, 1, 5)   # 2x + 1 = 5
eq2 = (1, -1, 1)  # x - 1 = 1
equations.add_equations(eq1, eq2)      # (3, 0, 6)  ->  3x = 6
equations.subtract_equations(eq1, eq2)  # (1, 2, 4)  ->  x + 2 = 4
equations.scale_equation(eq1, 2)      # (4, 2, 10)  ->  4x + 2 = 10
```

## Requirements

- Python 3.8+

## Publishing to PyPI

1. **Create a PyPI account** at [pypi.org](https://pypi.org/account/register/).

2. **Install build tools**:
   ```bash
   pip install --upgrade build twine
   ```

3. **Update `pyproject.toml`**: Set your name, email, and project URLs (and change the package `name` if `mathpack` is already taken on PyPI).

4. **Build the package**:
   ```bash
   python -m build
   ```
   This creates `dist/` with a `.whl` and `.tar.gz` file.

5. **Upload to PyPI** (you will be prompted for your PyPI username and password or API token):
   ```bash
   python -m twine upload dist/*
   ```
   For first-time testing, use TestPyPI: `python -m twine upload --repository testpypi dist/*`

## License

MIT
