"""LangExtract provider plugin for matrixai."""

from langextract_matrixai.provider import matrixaiLanguageModel

__all__ = ['matrixaiLanguageModel']
__version__ = "0.1.0"
