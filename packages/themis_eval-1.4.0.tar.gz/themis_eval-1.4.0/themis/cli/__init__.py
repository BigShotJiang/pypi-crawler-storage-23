"""Command-line helpers for running Themis experiments."""

from . import main

__all__ = ["main"]
