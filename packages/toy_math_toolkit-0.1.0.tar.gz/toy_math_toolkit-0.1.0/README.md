# Toy Math Toolkit
This is a meaningless toy library for testing some features.

## Installation
```bash
pip install toy-math-toolkit
```