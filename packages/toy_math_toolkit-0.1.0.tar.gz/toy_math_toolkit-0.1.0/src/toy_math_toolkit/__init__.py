from .ops import *

# Expose all the operations in the package's namespace
__all__ = ["add", "subtract", "multiply", "divide"]
