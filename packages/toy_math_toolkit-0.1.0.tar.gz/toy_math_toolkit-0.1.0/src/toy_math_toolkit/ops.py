def add(a, b):
    """[TEST_PREFIX] Adds two numbers together."""
    return a + b


def subtract(a, b):
    """[TEST_PREFIX] Subtracts the second number from the first."""
    return a - b


def multiply(a, b):
    """[TEST_PREFIX] Multiplies two numbers together."""
    return a * b


def divide(a, b):
    """[TEST_PREFIX] Divides the first number by the second."""
    if b == 0:
        raise ValueError("Cannot divide by zero.")
    return a / b
