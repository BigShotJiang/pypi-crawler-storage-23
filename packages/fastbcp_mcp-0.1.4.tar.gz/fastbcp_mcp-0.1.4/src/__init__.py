"""FastBCP MCP Server - A Model Context Protocol server for FastBCP CLI tool."""

__version__ = "0.1.0"
