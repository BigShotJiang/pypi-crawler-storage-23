"""
Phylax Meta-Enforcement Package (Axis 3 - Phase 3.4)

Protects against expectation dilution.

Design rules:
- No evaluation of complexity or usefulness
- No semantic diff — only hash comparison
- No judgment on removal reason
- User chooses rules, engine enforces them
"""
