"""
Main CLI entry point for CheckodAI.
"""

import typer
from typing import Optional

from checkod.agent import run_agent


app = typer.Typer(
    name="checkod",
    help="CheckodAI - AI Impact Assessment for code changes.",
)


@app.command()
def assess(
    repo_path: Optional[str] = typer.Option(
        ".",
        "--repo",
        "-r",
        help="Path to the git repository to analyze",
    ),
    risk_assessment: bool = typer.Option(
        True,
        "--risk/--no-risk",
        help="Enable AI-powered risk assessment (requires local Ollama)",
    ),
) -> None:
    """
    Assess the impact of changes in the repository.
    
    Reads git diff, detects changed symbols, and prints a summary.
    Optionally runs AI risk assessment using local Ollama.
    
    HIGH risk changes trigger advisory warnings but do not block commits.
    """
    typer.echo("🔍 Starting Impact Assessment...")
    exit_code = run_agent(
        repo_path=repo_path,
        enable_risk_assessment=risk_assessment
    )
    
    if exit_code == 0:
        typer.echo("\n✅ Assessment complete!")
    else:
        raise typer.Exit(code=exit_code)


@app.command()
def version() -> None:
    """Show version information."""
    from checkod import __version__
    typer.echo(f"impact-agent v{__version__}")


if __name__ == "__main__":
    app()
