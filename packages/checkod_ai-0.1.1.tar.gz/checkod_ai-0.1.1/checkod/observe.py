"""
Observe module - reads git diff from the repository.
"""

from typing import Optional
from git import Repo
from git.exc import InvalidGitRepositoryError


def get_diff(repo_path: str = ".") -> Optional[str]:
    """
    Get the git diff from the repository.
    
    Compares the working directory against HEAD to detect changes.
    
    Args:
        repo_path: Path to the git repository
        
    Returns:
        Git diff as a string, or None if no changes or error occurred
        
    Raises:
        InvalidGitRepositoryError: If the path is not a valid git repository
    """
    try:
        repo = Repo(repo_path)
        
        # Get diff of unstaged changes
        diff = repo.git.diff()
        
        # If no unstaged changes, check staged changes
        if not diff:
            diff = repo.git.diff("--cached")
        
        return diff if diff else None
        
    except InvalidGitRepositoryError:
        raise InvalidGitRepositoryError(
            f"'{repo_path}' is not a valid git repository"
        )
    except Exception as e:
        raise Exception(f"Failed to read git diff: {str(e)}")
