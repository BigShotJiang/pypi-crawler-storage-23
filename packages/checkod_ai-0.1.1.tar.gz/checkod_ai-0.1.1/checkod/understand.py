"""
Understand module - extracts changed symbols from git diff.
"""

from typing import List
import re


def extract_symbols(diff_content: str) -> List[str]:
    """
    Extract changed symbols (functions, classes, variables) from a git diff.
    
    This is a stub implementation that extracts basic patterns.
    Full AST-based parsing will be implemented in future versions.
    
    Args:
        diff_content: Raw git diff content
        
    Returns:
        List of changed symbol names
    """
    symbols = []
    
    # Pattern 1: Function definitions (Python)
    # Matches: def function_name(
    func_pattern = r'^\+\s*(?:async\s+)?def\s+(\w+)\s*\('
    func_matches = re.findall(func_pattern, diff_content, re.MULTILINE)
    symbols.extend(func_matches)
    
    # Pattern 2: Function definitions (JavaScript)
    # Matches: function functionName( or const functionName = (
    js_func_pattern = r'^\+\s*(?:function\s+(\w+)\s*\(|const\s+(\w+)\s*=\s*(?:async\s*)?\(|let\s+(\w+)\s*=\s*(?:async\s*)?\()'
    js_func_matches = re.findall(js_func_pattern, diff_content, re.MULTILINE)
    for match in js_func_matches:
        # match is a tuple with up to 3 groups, get the non-empty one
        symbol = next((g for g in match if g), None)
        if symbol:
            symbols.append(symbol)
    
    # Pattern 3: Class definitions
    # Matches: class ClassName(
    class_pattern = r'^\+\s*class\s+(\w+)\s*[\(\:]'
    class_matches = re.findall(class_pattern, diff_content, re.MULTILINE)
    symbols.extend(class_matches)
    
    # Pattern 4: Class attributes/constants (UPPERCASE_NAMES)
    # Matches: CONSTANT_NAME = value
    const_pattern = r'^\+\s+([A-Z_][A-Z0-9_]*)\s*='
    const_matches = re.findall(const_pattern, diff_content, re.MULTILINE)
    symbols.extend(const_matches)
    
    # Pattern 5: JavaScript/Python variable declarations with assignment
    # Matches: const varName =, let varName =, var varName =, variable_name =
    var_pattern = r'^\+\s+(?:const|let|var)?\s*([a-zA-Z_]\w*)\s*='
    var_matches = re.findall(var_pattern, diff_content, re.MULTILINE)
    # Filter out common non-symbol patterns
    var_matches = [m for m in var_matches if not m.startswith('_') and m.lower() not in ['return']]
    symbols.extend(var_matches)
    
    # Remove duplicates while preserving order
    seen = set()
    unique_symbols = []
    for symbol in symbols:
        if symbol not in seen and symbol and len(symbol) > 1:
            seen.add(symbol)
            unique_symbols.append(symbol)
    
    return unique_symbols
