# CheckodAI

AI Impact Assessment for code changes - understand what Copilot changed before you commit it.

## Overview

CheckodAI is a Python CLI tool that helps developers understand the scope and implications of their code changes by analyzing git diffs and extracting modified symbols (functions, classes, variables). It can optionally use a local LLM (Ollama) to assess the risk of each change.

## Privacy

CheckodAI runs entirely locally.

- No code is uploaded
- No cloud calls required
- No telemetry
- Works offline with local LLM (Ollama)

All analysis happens on your machine.

**Key Features:**
- 🚀 Local-first: Runs entirely on your machine - no cloud calls
- 🔍 Symbol-level analysis: Detects changed functions, classes, and variables
- 🏷️ Change type detection: Identifies what type of change (added, removed, modified, signature changed)
- 💡 Impact summaries: Human-readable recommendations for each changed symbol
- 🤖 AI-powered risk assessment: Uses local Ollama for intelligent impact analysis
- 🛡️ Commit guard: Advisory warnings for HIGH risk changes (non-blocking)
- 🎯 CLI-first interface: Simple `checkod assess` command
- 📊 Summary reports: Clear output of what changed and risk levels
- ⚡ Graceful fallback: Works without Ollama using heuristic analysis

## Installation

### Prerequisites
- Python 3.8+
- Git
- Ollama (optional, for AI risk assessment)

### Quick Start

Install from PyPI:
```bash
pip install checkod-ai
```

Run assessment on your repository:
```bash
checkod assess
```

### Optional: Install Ollama for AI Risk Assessment

Ollama enables intelligent risk scoring. Install and configure:

```bash
# macOS / Linux
curl -fsSL https://ollama.ai/install.sh | sh

# Or use Homebrew (macOS)
brew install ollama

# Pull the model
ollama pull llama3

# Start the server (runs on localhost:11434)
ollama serve
```

## Usage

### Basic Commands

Analyze changes in the current repository:
```bash
checkod assess
```

Analyze a specific repository:
```bash
checkod assess --repo /path/to/repo
```

Skip AI risk assessment:
```bash
checkod assess --no-risk
```

### Example Output

```
🔍 Starting Impact Assessment...

📊 Changed Symbols (3 detected):
  • calculateDiscount
  • OrderStatus
  • userTier

📈 Change Summary:
  Functions: 1 function added
  Classes: 1 class added
  Variables: 1 variable added

================================================================================
📋 Impact Summary
================================================================================
You changed: calculateDiscount()
Change Type: function added
Risk Level: MEDIUM

This may affect:
  • checkout_service (logic flow)
  • /api/orders (user-facing behavior)
  • test_checkout (test coverage)

Recommended Actions:
  • Write unit tests for calculateDiscount
  • Test integration with checkout service
  • Document function parameters and return type
```

With Ollama running, you'll also get AI-powered risk assessment:

```
================================================================================
🤖 AI Risk Assessment (powered by local Ollama)
================================================================================
Symbol: calculateDiscount
────────────────────────────────
Risk Classification: MEDIUM

Reason: Used in multiple modules; requires testing and code review.

Validation Steps:
• Test discount calculation across pricing tiers
• Verify integration with checkout service
• Add regression tests if coverage is low
```

## How It Works

1. **Reads git diff** - Gets all staged and unstaged changes
2. **Extracts symbols** - Finds functions, classes, and variables
3. **Detects change type** - Identifies what kind of change was made
4. **Assesses risk** - Uses local AI (Ollama) or heuristics
5. **Generates recommendations** - Suggests testing and review actions
6. **Advisory warnings** - HIGH risk changes trigger warnings

## Documentation

- **[DOCS.md](DOCS.md)** - Complete documentation including architecture, development, and detailed guides
- **[CONTRIBUTING.md](CONTRIBUTING.md)** - How to contribute
- **[LICENSE](LICENSE)** - MIT License

## Development

For development setup and contributing:

```bash
# Clone repository
git clone <repository-url>
cd checkod

# Create virtual environment
python3 -m venv venv
source venv/bin/activate

# Install in development mode
pip install -e .

# Run tests
pytest

# Code quality
black .
flake8 .
mypy checkod
```

See [DOCS.md](DOCS.md) for architecture and detailed development information.

## License

MIT License - See [LICENSE](LICENSE) file for details

## Author

Anup Moncy - n93181165@gmail.com
- Integration with CI/CD
- Web-based dashboard

---

**Note**: This is an early-stage project. The API and behavior are subject to change.
