"""
SimGen - GPU Simulation Engine
==============================

Modules:
    vla - Zero-Error GPU Arithmetic
"""

__version__ = "6.0.1"
