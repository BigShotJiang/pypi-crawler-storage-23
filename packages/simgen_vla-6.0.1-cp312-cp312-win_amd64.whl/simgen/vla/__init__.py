"""
VLA - TRUE ZERO Error GPU Arithmetic
=====================================

Drop-in PyTorch replacement with exact arithmetic.
No floating point drift. 424-bit precision on GPU (8 limbs x FP64).

Usage:
    from simgen import vla

    x = vla.tensor([1e16, 1.0, -1e16])
    y = x.sum()  # Returns EXACTLY 1.0, not 0.0

    # All PyTorch ops work with TRUE ZERO precision
    a = vla.randn(100, 100)
    b = vla.matmul(a, a.T)

Requirements:
    PyTorch 2.0+ with CUDA support (not auto-installed to avoid breaking your build)
    Install separately: pip install torch --index-url https://download.pytorch.org/whl/cu121

License:
    Free for personal/research use.
    Commercial: https://simgen.dev
"""

__version__ = "6.0.1"

# Check for PyTorch before importing anything else
try:
    import torch as _torch
    if not _torch.cuda.is_available():
        import warnings
        warnings.warn(
            "VLA requires PyTorch with CUDA support for GPU acceleration. "
            "CPU fallback available but slower. "
            "Install CUDA PyTorch: pip install torch --index-url https://download.pytorch.org/whl/cu121"
        )
except ImportError:
    raise ImportError(
        "VLA requires PyTorch 2.0+ (not auto-installed to avoid breaking your build).\n"
        "Install: pip install torch --index-url https://download.pytorch.org/whl/cu121\n"
        "See: https://pytorch.org/get-started/locally/"
    )

# License check on import
from .license import check_license
check_license(silent=True)

# Linear algebra module
from . import linalg

# Core exports - all torch-compatible API
from .vla import (
    # Core class
    Tensor,

    # Creation functions
    tensor,
    from_limbs,
    zeros,
    ones,
    randn,
    rand,
    arange,
    linspace,
    eye,

    # Reductions
    sum,
    mean,
    prod,
    min,
    max,
    std,
    var,
    norm,
    argmin,
    argmax,

    # Linear algebra
    matmul,
    mm,
    mv,
    dot,
    bmm,

    # Math functions
    exp,
    log,
    sqrt,
    abs,
    sin,
    cos,
    tan,
    tanh,
    sigmoid,
    floor,
    ceil,
    round,
    clamp,

    # Activations
    relu,
    softmax,
    log_softmax,
    gelu,
    silu,

    # Shape functions
    reshape,
    transpose,
    squeeze,
    unsqueeze,
    stack,
    cat,
    split,
    chunk,
    permute,
    repeat,

    # Comparison/utility
    where,
    isnan,
    isinf,
    isfinite,

    # Reproducibility
    manual_seed,
    get_rng_state,
    set_rng_state,

    # Device/dtype
    float32,
    float64,
    device,
    cuda,
    cpu,
)

__all__ = [
    '__version__',
    # Core
    'Tensor', 'tensor', 'from_limbs', 'zeros', 'ones', 'randn', 'rand', 'arange', 'linspace', 'eye',
    # Reductions
    'sum', 'mean', 'prod', 'min', 'max', 'std', 'var', 'norm', 'argmin', 'argmax',
    # Linear algebra
    'matmul', 'mm', 'mv', 'dot', 'bmm',
    # Math
    'exp', 'log', 'sqrt', 'abs', 'sin', 'cos', 'tan', 'tanh', 'sigmoid',
    'floor', 'ceil', 'round', 'clamp',
    # Activations
    'relu', 'softmax', 'log_softmax', 'gelu', 'silu',
    # Shape
    'reshape', 'transpose', 'squeeze', 'unsqueeze', 'stack', 'cat',
    'split', 'chunk', 'permute', 'repeat',
    # Comparison/utility
    'where', 'isnan', 'isinf', 'isfinite',
    # Reproducibility
    'manual_seed', 'get_rng_state', 'set_rng_state',
    # Device/dtype
    'float32', 'float64', 'device', 'cuda', 'cpu',
]
