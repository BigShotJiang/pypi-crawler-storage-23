# validattr
Attribute with validator.

## Installation
```sh
$ pip install validattr
```

## Requirements
```txt

```

## See Also
### Github repository
* https://github.com/Chitaoji/validattr/

### PyPI project
* https://pypi.org/project/validattr/

## License
This project falls under the BSD 3-Clause License.

## History
### v0.0.0
* Initial release.