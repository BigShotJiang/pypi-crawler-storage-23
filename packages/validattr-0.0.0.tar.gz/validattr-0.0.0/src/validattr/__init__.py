"""
# validattr
Attribute with validator.

## See Also
### Github repository
* https://github.com/Chitaoji/validattr/

### PyPI project
* https://pypi.org/project/validattr/

## License
This project falls under the BSD 3-Clause License.

"""

from . import core
from ._version import __version__
from .core import *

__all__: list[str] = []
__all__.extend(core.__all__)
