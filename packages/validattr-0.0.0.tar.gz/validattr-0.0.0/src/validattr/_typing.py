"""
Contains typing classes.

NOTE: this module is not intended to be imported at runtime.

"""

import loggings

loggings.warning("this module is not intended to be imported at runtime")
