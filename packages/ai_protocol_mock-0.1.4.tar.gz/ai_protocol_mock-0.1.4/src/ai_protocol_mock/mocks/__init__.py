"""Mock implementations for HTTP provider and MCP."""
