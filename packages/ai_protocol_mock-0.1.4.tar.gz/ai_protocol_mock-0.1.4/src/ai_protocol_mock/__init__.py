"""ai-protocol-mock - Unified mock server for AI-Protocol runtimes.

AI-Protocol 统一 mock 服务：为 ai-lib-rust、ai-lib-python 等运行时提供 HTTP 与 MCP 模拟。
"""

__version__ = "0.1.4"
