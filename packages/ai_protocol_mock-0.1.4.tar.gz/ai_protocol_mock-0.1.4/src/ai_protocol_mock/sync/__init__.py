"""Manifest sync utilities."""
