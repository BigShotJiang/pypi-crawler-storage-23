from sd_webui_all_in_one.cli_manager.cli import main


if __name__ == "__main__":
    main()
