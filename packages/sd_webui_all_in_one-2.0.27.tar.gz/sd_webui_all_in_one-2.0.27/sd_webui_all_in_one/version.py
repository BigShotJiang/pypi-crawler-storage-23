"""SD WebUI All In One 版本"""

VERSION = "2.0.27"
