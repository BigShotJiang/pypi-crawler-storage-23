Once installed and the 'Sell and purchase products in different units of
measure' option is enabled, the 'Unit of Measure' field will become
updatable on the 'Product' form for users with the permission 'Manage
Multiple Units of Measure'.

If the displayed value is 0.00 and a warning icon is displayed in front
of the unit of measure, it means that the value is too small to be
displayed in the current unit of measure. You should change the unit of
measure to a larger one to see the value.
