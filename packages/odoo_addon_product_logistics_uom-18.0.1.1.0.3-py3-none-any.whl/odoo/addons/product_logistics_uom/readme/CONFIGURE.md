To change the default UoM

1.  Go "General Settings", then in "Products"
2.  you have to select a default unit of measure for weights and
    volumes.

To change on a specific product

1.  Go the product form you can change the UoM directly.
