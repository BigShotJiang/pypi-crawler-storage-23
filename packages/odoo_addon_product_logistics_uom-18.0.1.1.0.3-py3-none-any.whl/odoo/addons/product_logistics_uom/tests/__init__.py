from . import test_product_logistics_uom
