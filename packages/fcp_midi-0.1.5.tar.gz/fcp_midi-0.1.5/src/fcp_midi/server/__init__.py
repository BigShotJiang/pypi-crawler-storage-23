"""Server package — MCP tools, intent dispatch, and formatting."""
