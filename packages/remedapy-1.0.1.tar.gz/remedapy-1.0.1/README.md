# Remedapy

Data-first and data-last utility library for python.

A port of [Remeda.js](https://github.com/remeda/remeda).

## Features

- As typed as possible with current python typing system.
- Supports data-first (`R.filter(array, fn)`) and data-last (`R.filter(fn)(array)`) approaches.
- Lazy evaluation support with functions returning iterables.
- Fully documented with [numpydoc](https://numpydoc.readthedocs.io/en/latest/format.html), supports in-editor function documentation.
- 100% code coverage.
- Typing passes on basedpyright.
- Docstring examples tested with doctest.
- Zero runtime dependencies.

## Getting started

### Installation

```bash
pip install remedapy # pip
uv add remedapy # uv
```

### Usage

```python
import remedapy as R

R.pipe(
    [1, 2, 2, 3, 3, 4, 5, 6],
    R.for_each(print),
    R.unique(),
    R.take(3),
    list
)
# Returns [1, 2, 3]
# Prints:
# 1
# 2
# 2
# 3
```

## Function catalogue

Iterable:

- [all_pass](#all_pass)
- [any_pass](#any_pass)
- [chunk](#chunk)
- [concat](#concat)
- [count_by](#count_by)
- [difference](#difference)
- [difference_with](#difference_with)
- [drop](#drop)
- [drop_first_by](#drop_first_by)
- [drop_last](#drop_last)
- [drop_last_while](#drop_last_while)
- [drop_while](#drop_while)
- [filter](#filter)
- [find](#find)
- [find_index](#find_index)
- [find_last](#find_last)
- [find_last_index](#find_last_index)
- [first](#first)
- [first_by](#first_by)
- [flat](#flat)
- [flat_map](#flat_map)
- [get](#get)
- [group_by](#group_by)
- [group_by_prop](#group_by_prop)
- [index_by](#index_by)
- [intersection](#intersection)
- [intersection_with](#intersection_with)
- [last](#last)
- [length](#length)
- [map](#map)
- [map_to_obj](#map_to_obj)
- [map_with_feedback](#map_with_feedback)
- [mean](#mean)
- [mean_by](#mean_by)
- [nth_by](#nth_by)
- [only](#only)
- [partition](#partition)
- [pull_object](#pull_object)
- [range](#range)
- [rank_by](#rank_by)
- [reduce](#reduce)
- [reverse](#reverse)
- [sample](#sample)
- [shuffle](#shuffle)
- [slice](#slice)
- [sort](#sort)
- [sorted_index](#sorted_index)
- [sorted_index_by](#sorted_index_by)
- [sorted_index_with](#sorted_index_with)
- [sorted_last_index](#sorted_last_index)
- [sorted_last_index_by](#sorted_last_index_by)
- [splice](#splice)
- [split](#split)
- [split_at](#split_at)
- [split_when](#split_when)
- [sum](#sum)
- [sum_by](#sum_by)
- [swap_indices](#swap_indices)
- [take](#take)
- [take_first_by](#take_first_by)
- [take_last](#take_last)
- [take_last_while](#take_last_while)
- [take_while](#take_while)
- [times](#times)
- [unique](#unique)
- [unique_by](#unique_by)
- [unique_with](#unique_with)
- [zip](#zip)
- [zip_with](#zip_with)

Function:

- [apply](#apply)
- [conditional](#conditional)
- [constant](#constant)
- [do_nothing](#do_nothing)
- [fold](#fold)
- [for_each](#for_each)
- [identity](#identity)
- [negate](#negate)
- [once](#once)
- [partial](#partial)
- [pipe](#pipe)
- [piped](#piped)
- [tap](#tap)
- [when](#when)

TypeGuard:

- [is_bool](#is_bool)
- [is_callable](#is_callable)
- [is_empty](#is_empty)
- [is_float](#is_float)
- [is_int](#is_int)
- [is_list](#is_list)
- [is_none](#is_none)
- [is_number](#is_number)
- [is_sequence](#is_sequence)
- [is_sized](#is_sized)
- [is_string](#is_string)

Number:

- [add](#add)
- [ceil](#ceil)
- [clamp](#clamp)
- [floor](#floor)
- [is_divisible_by](#is_divisible_by)
- [is_even](#is_even)
- [is_odd](#is_odd)
- [mod](#mod)
- [multiply](#multiply)
- [round](#round)
- [subtract](#subtract)

String:

- [capitalise](#capitalise)
- [ends_with](#ends_with)
- [join](#join)
- [random_string](#random_string)
- [slice_string](#slice_string)
- [starts_with](#starts_with)
- [to_camel_case](#to_camel_case)
- [to_kebab_case](#to_kebab_case)
- [to_lower_case](#to_lower_case)
- [to_snake_case](#to_snake_case)
- [to_title_case](#to_title_case)
- [to_upper_case](#to_upper_case)
- [to_words](#to_words)
- [truncate](#truncate)
- [uncapitalise](#uncapitalise)

Other:

- [default_to](#default_to)
- [is_truthy](#is_truthy)

Set:

- [is_subset](#is_subset)
- [is_superset](#is_superset)

Dict:

- [entries](#entries)
- [evolve](#evolve)
- [for_each_dict](#for_each_dict)
- [from_entries](#from_entries)
- [from_keys](#from_keys)
- [invert](#invert)
- [keys](#keys)
- [map_keys](#map_keys)
- [map_values](#map_values)
- [merge](#merge)
- [merge_all](#merge_all)
- [merge_deep](#merge_deep)
- [omit](#omit)
- [omit_by](#omit_by)
- [path_or](#path_or)
- [pick](#pick)
- [pick_by](#pick_by)
- [prop](#prop)
- [set](#set)
- [set_path](#set_path)
- [swap_props](#swap_props)
- [values](#values)

Comparison:

- [eq](#eq)
- [ge](#ge)
- [gt](#gt)
- [le](#le)
- [lt](#lt)
- [neq](#neq)

## Documentation

### Iterable

#### all_pass

Determines whether all predicates are true for the input data.

Examples:

```pycon
Data first:
>>> R.all_pass(6, [R.is_divisible_by(3), R.is_divisible_by(2)])
True
>>> R.all_pass(6, [R.is_divisible_by(3), R.is_divisible_by(5)])
False
Data last:
>>> R.all_pass([R.is_divisible_by(3), R.is_divisible_by(2)])(12)
True
>>> R.all_pass([R.is_divisible_by(3), R.is_divisible_by(2)])(15)
False
```

Parameters:

```plaintext
data : T
    Input data (positional-only).
predicates : Iterable[Callable[[T], bool]]
    Predicates to check data against(positional-only).
```

Returns:

```plaintext
bool
    Whether all predicates are true for the input data.
```

#### any_pass

Determines whether any predicate is true for the input data.

Examples:

```pycon
Data first:
>>> R.any_pass(9, [R.is_divisible_by(3), R.is_divisible_by(2)])
True
>>> R.any_pass(11, [R.is_divisible_by(3), R.is_divisible_by(5)])
False
Data last:
>>> R.any_pass([R.is_divisible_by(3), R.is_divisible_by(2)])(2)
True
>>> R.any_pass([R.is_divisible_by(3), R.is_divisible_by(2)])(7)
False
```

Parameters:

```plaintext
data : T
    Input data (positional-only).
predicates : Iterable[Callable[[T], bool]]
    Predicates to check data against(positional-only).
```

Returns:

```plaintext
bool
    Whether any predicate is true for the input data.
```

#### chunk

Yields lists of specified size from the iterable.

Examples:

```pycon
Data first:
>>> list(R.chunk([1,2,3,4,5,6], 3))
[[1, 2, 3], [4, 5, 6]]
>>> list(R.chunk(range(1, 8), 3))
[[1, 2, 3], [4, 5, 6], [7]]
Data last:
>>> R.pipe(range(1, 8), R.chunk(3), list)
[[1, 2, 3], [4, 5, 6], [7]]
>>> R.pipe([1,2,3], R.chunk(2), list)
[[1, 2], [3]]
```

Parameters:

```plaintext
iterable : Iterable[T]
    Input iterable (positional-only).
size : int
    Size (length) of the chunks (positional-only).
```

Returns:

```plaintext
Iterable[list[T]]
    Iterable of lists of specified size.
```

#### concat

Yields from one iterable and then from the other.

Examples:

```pycon
Data first:
>>> list(R.concat([1,2,3], [4,5,6]))
[1, 2, 3, 4, 5, 6]
Data last:
>>> list(R.concat([4,5,6])([1,2,3]))
[1, 2, 3, 4, 5, 6]
```

Parameters:

```plaintext
iterable1: Iterable[T]
    First iterable.
iterable2: Iterable[U]
    Second iterable.
```

Returns:

```plaintext
result: Iterable[T | U]
    Iterable being the result of concatenation.
```

#### count_by

Counts the number of elements in the iterable provided that map to the kay when passed to the function provided.

Examples:

```pycon
Data first:
>>> R.count_by(['a', 'b', 'c', 'B', 'A', 'a'], R.to_lower_case())
{'a': 3, 'b': 2, 'c': 1}
Data last:
>>> R.pipe(['a', 'b', 'c', 'B', 'A', 'a'], R.count_by(R.to_lower_case()))
{'a': 3, 'b': 2, 'c': 1}
```

Parameters:

```plaintext
iterable : Iterable[T]
    Input iterable (positional-only).
function : Callable[[T], U]
    Function to apply to each element of the iterable (positional-only).
```

Returns:

```plaintext
dict[U, int]
    Dictionary with keys being the result of passing elements of the iterable to the function
    and values being the count of elements that map to the key.
```

#### difference

Given two iterables, yields elements of the first iterable that do not appear in the other iterable.
The inputs are treated as multi-sets/bags (multiple copies of items are treated as unique items).
The order of elements is maintained.

Examples:

```pycon
Data first:
>>> list(R.difference([1, 2, 3, 4], [2, 5, 3]))
[1, 4]
>>> list(R.difference([1, 1, 2, 2], [1]))
[1, 2, 2]
Data last:
>>> R.pipe([1, 2, 3, 4], R.difference([2, 5, 3]), list)
[1, 4]
>>> R.pipe([1, 1, 2, 2], R.difference([1]), list)
[1, 2, 2]
```

Parameters:

```plaintext
iterable : Iterable[T]
    First iterable (positional-only).
other: Iterable[T]
    Second iterable (positional-only).
```

Returns:

```plaintext
Iterable[T]
    Iterable of elements of the first iterable that do not appear in the other iterable.
```

#### difference_with

Yields elements of the first iterable that are not equal to an element in the other iterable.
Given two iterables and an equality function.
The inputs are treated as multi-sets/bags (multiple copies of items are treated as unique items).
The order of elements is maintained.

Examples:

```pycon
Data first:
>>> list(R.difference_with([{'a': 1}, {'a': 2}, {'a': 3}, {'a': 4}], [2, 5, 3], lambda d, x: d['a'] == x))
[{'a': 1}, {'a': 4}]
Data last:
>>> R.pipe(
...     [{'a': 1}, {'a': 2}, {'a': 3}, {'a': 4}, {'a': 5}, {'a': 6}],
...     R.difference_with([2, 3], lambda d, x: d['a'] == x),
...     list,
... )
[{'a': 1}, {'a': 4}, {'a': 5}, {'a': 6}]
```

Parameters:

```plaintext
iterable : Iterable[T]
    First iterable (positional-only).
other: Iterable[U]
    Second iterable (positional-only).
equality_function: Callable[[T, U], bool]
    Equality function, predicate of arity 2 (positional-only).
```

Returns:

```plaintext
Iterable[T]
    Iterable of elements of the first iterable that do not appear in the other iterable.
```

#### drop

Yields the elements of the iterable skipping the first n elements.

Examples:

```pycon
Data first:
>>> list(R.drop(range(5), 2))
[2, 3, 4]
>>> list(R.drop([2, 1, 3, 7, 6, 6, 6], 4))
[6, 6, 6]
Data last:
>>> list(R.drop([2, 1, 3, 7, 6, 6, 6], 4))
[6, 6, 6]
>>> list(R.drop(range(10), 8))
[8, 9]
```

Parameters:

```plaintext
iterable : Iterable[T]
    Input iterable (positional-only).
n : int
    Number of elements to not yield (positional-only).
```

Returns:

```plaintext
Iterable[T]
    Elements of the iterable skipping the first n elements.
```

#### drop_first_by

Yields all elements of the iterable except the first*n.
*Where &quot;first&quot; means first if the iterable were sorted by the function provided.
The elements are yielded in the order they appear in the iterable.

Examples:

```pycon
Data first:
>>> list(R.drop_first_by(['aa', 'aaaa', 'a', 'aaa'], 2, R.length))
['aaaa', 'aaa']
Data last:
>>> list(R.pipe(['aa', 'aaaa', 'a', 'aaa'], R.drop_first_by(2, R.length)))
['aaaa', 'aaa']
```

Parameters:

```plaintext
iterable : Iterable[T]
    Input iterable (positional-only).
n : int
    Number of elements to skip (positional-only).
function: Callable[[T], SupportsGtLt]
    Function to &quot;sort&quot; the iterable by (positional-only).
```

Returns:

```plaintext
Iterable[T]
    All elements of the iterable without the first* n.
```

#### drop_last

Returns the list of elements of the iterable skipping the last n elements.

Examples:

```pycon
Data first:
>>> list(R.drop_last(range(5), 2))
[0, 1, 2]
>>> list(R.drop_last([2, 1, 3, 7, 6, 6, 6], 3))
[2, 1, 3, 7]
Data last:
>>> list(R.drop_last([2, 1, 3, 7, 6, 6, 6], 3))
[2, 1, 3, 7]
>>> list(R.drop_last(range(10), 8))
[0, 1]
```

Parameters:

```plaintext
iterable : Iterable[T]
    Input iterable (positional-only).
n : int
    Number of elements to not yield (positional-only).
```

Returns:

```plaintext
list[T]
    Elements of the iterable skipping the last n elements.
```

#### drop_last_while

Returns the elements of the iterable until the last one that does not satisfy the predicate.
Does return that last element that does not satisfy the predicate.
Tantamount to skipping all the elements of the iterable from the end
until the first element that does not satisfy the predicate,
but the elements are returned in the original order.

Examples:

```pycon
Data first:
>>> R.drop_last_while([1, 2, 10, 3, 4], R.lt(10))
[1, 2, 10]
Data last:
>>> R.pipe([1, 2, 10, 3, 4], R.drop_last_while(R.lt(10)))
[1, 2, 10]
```

Parameters:

```plaintext
iterable : Iterable[T]
    Input iterable (positional-only).
predicate: Callable[[T], bool]
    Predicate to check the elements of the iterable (positional-only).
```

Returns:

```plaintext
list[T]
    Elements of the iterable from the last one that does not satisfy the predicate.
```

#### drop_while

Yields the elements of the iterable after encountering the element that does not satisfy the predicate.
Yields the element that does not satisfy the predicate.

Examples:

```pycon
Data first:
>>> list(R.drop_while([1, 2, 3, 4, 3, 2, 1], R.lt(4)))
[4, 3, 2, 1]
Data last:
>>> R.pipe([1, 2, 3, 4, 3, 2, 1], R.drop_while(R.lt(4)), list)
[4, 3, 2, 1]
```

Parameters:

```plaintext
iterable : Iterable[T]
    Input iterable (positional-only).
predicate: Callable[[T], bool]
    Predicate to check the elements of the iterable (positional-only).
```

Returns:

```plaintext
Iterable[T]
    Elements of the iterable after encountering the element that does not satisfy the predicate.
```

#### filter

Given an iterable and a predicate yields the elements satisfying the predicate.
Predicate can appept a value, a value and index, or a value, index, and the whole sequence.
If iterable is not a sequence it is collected into a list first.

Examples:

```pycon
Data first:
>>> list(R.filter([1, 2, 3], lambda x: x % 2 == 1))
[1, 3]
Data last:
>>> R.pipe([1, 2, 3], R.filter(R.is_odd), list)
[1, 3]
```

Parameters:

```plaintext
iterable: Iterable[T]
    The iterable to partition.
predicate: Callable[[T], bool] | Callable[[T, int], bool] | Callable[[T, int, Sequence[T]], bool]
    The predicate to use for filtering.
```

Yields:

```plaintext
T
    Elements satisfying the predicate.
```

See Also:

- [partition](#partition)

#### find

Returns the first element of the iterable that satisfies the predicate.
If no element does returns None.

Examples:

```pycon
Data first:
>>> R.find([1, 3, 4, 6], R.is_even)
4
>>> R.find([1, 3, 4, 6], lambda x: x % 2 == 0)
4
>>> R.find([1, 3, 4, 6], lambda x: 1 < x < 4)
3
>>> R.find([1, 3, 4, 6], lambda x: x > 8)
Data last:
>>> R.find(R.is_even)([1, 3, 4, 6])
4
>>> R.pipe([1, 2, 3, 4, 3, 8, 1], R.find(R.is_even))
2
```

Parameters:

```plaintext
iterable : Iterable[T]
    Input iterable (positional-only).
predicate: Callable[[T], bool]
    Predicate to check the elements of the iterable (positional-only).
```

Returns:

```plaintext
T | None
    First element of the iterable that satisfies the predicate or None.
```

#### find_index

Returns the index of the first element of the iterable that satisfies the predicate.
If no element does returns default provided (default default value is -1).

Examples:

```pycon
Data first:
>>> R.find_index([1, 3, 4, 6], R.is_even)
2
>>> R.find_index([1, 3, 4, 6], lambda x: x % 2 == 0)
2
>>> R.find_index([1, 3, 4, 6], lambda x: 1 < x < 4)
1
>>> R.find_index([1, 3, 4, 6], lambda x: x > 8)
-1
>>> R.find_index([1, 3, 4, 6], lambda x: x > 8, default=69)
69
Data last:
>>> R.find_index(R.is_even)([1, 3, 4, 6])
2
>>> R.pipe([1, 2, 3, 4, 3, 2, 1], R.find_index(R.is_even))
1
>>> R.pipe([1, 3, 5], R.find_index(R.is_even, default=10))
10
```

Parameters:

```plaintext
iterable : Iterable[T]
    Input iterable (positional-only).
predicate: Callable[[T], bool]
    Predicate to check the elements of the iterable (positional-only).
default: U
    Default value to return if no element satisfies the predicate (keyword-only, optional).
```

Returns:

```plaintext
int | U
    Index of the first element of the iterable that satisfies the predicate or the default value.
```

#### find_last

Returns the last element of the iterable that satisfies the predicate.
If no element does returns None.

Examples:

```pycon
Data first:
>>> R.find_last([1, 3, 4, 6], R.is_even)
6
>>> R.find_last([1, 3, 4, 6], lambda x: x % 2 == 0)
6
>>> R.find_last([1, 3, 4, 6], lambda x: 1 < x < 4)
3
>>> R.find_last([1, 3, 4, 6], lambda x: x > 8)
Data last:
>>> R.find_last(R.is_even)([1, 3, 4, 6])
6
>>> R.pipe([1, 2, 3, 4, 3, 8, 1], R.find_last(R.is_even))
8
```

Parameters:

```plaintext
iterable : Iterable[T]
    Input iterable (positional-only).
predicate: Callable[[T], bool]
    Predicate to check the elements of the iterable (positional-only).
```

Returns:

```plaintext
T | None
    Last element of the iterable that satisfies the predicate or None.
```

#### find_last_index

Returns the index of the last element of the iterable that satisfies the predicate.
If no element does returns default provided (default default value is -1).

Examples:

```pycon
Data first:
>>> R.find_last_index([1, 3, 4, 6], R.is_even)
3
>>> R.find_last_index([1, 3, 4, 6], lambda x: x % 2 == 0)
3
>>> R.find_last_index([1, 3, 4, 6], lambda x: 1 < x < 4)
1
>>> R.find_last_index([1, 3, 4, 6], lambda x: x > 8)
-1
>>> R.find_last_index([1, 3, 4, 6], lambda x: x > 8, default=69)
69
Data last:
>>> R.find_last_index(R.is_even)([1, 3, 4, 6])
3
>>> R.pipe([1, 2, 3, 4, 3, 2, 1], R.find_last_index(R.is_even))
5
>>> R.pipe([1, 3, 5], R.find_last_index(R.is_even, default=10))
10
```

Parameters:

```plaintext
iterable : Iterable[T]
    Input iterable (positional-only).
predicate: Callable[[T], bool]
    Predicate to check the elements of the iterable (positional-only).
default: U
    Default value to return if no element satisfies the predicate (keyword-only, optional).
```

Returns:

```plaintext
int | U
    Index of the last element of the iterable that satisfies the predicate or the default value.
```

#### first

Returns the first element of the iterable.
If the iterable is empty, returns `None`.

Examples:

```pycon
Data first:
>>> R.first([1, 2, 3])
1
Data last:
>>> R.pipe([1, 2, 4, 8, 16], R.filter(R.gt(3)), R.first(), R.default_to(0), R.add(1))
5
```

Parameters:

```plaintext
iterable : Iterable[T]
    Input iterable (positional-only).
```

Returns:

```plaintext
T | None
    First element of the iterable or `None` if the iterable is empty.
```

#### first_by

Returns the elements that would be first if the iterable were sorted by the function.
They are yielded in the order they appear in the iterable.

Examples:

```pycon
Data first:
>>> R.first_by([1, 2, 3], R.identity())
1
>>> R.first_by([{'a': 'a'}, {'a': 'aa'}, {'a': 'aaa'}], R.piped(R.prop('a'), R.default_to(''), R.length))
{'a': 'a'}
Data last:
>>> R.pipe([3, 2, 1], R.first_by(R.identity()))
1
>>> R.pipe([{'a': 'a'}, {'a': 'aa'}, {'a': 'aaa'}], R.first_by(R.piped(R.prop('a'), R.default_to(''), R.length)))
{'a': 'a'}
```

Parameters:

```plaintext
iterable : Iterable[T]
    Input iterable (positional-only).
function: Callable[[T], SupportsGtLt]
    Function to &quot;sort&quot; the iterable by (positional-only).
```

Returns:

```plaintext
T
    The first element of the iterable if sorted by the function provided.
```

#### flat

Yields elements for the iterable and sub-iterables up to the specified depth.

Examples:

```pycon
Data first:
>>> list(R.flat([[1, 2], [3, 4], [5], [[6]]]))
[1, 2, 3, 4, 5, 6]
>>> list(R.flat([[[1]], [[[2]]]], depth=2))
[1, [2]]
Data last:
>>> R.pipe([[1, 2], [3, 4], [5], [[6]]], R.flat(), list)
[1, 2, 3, 4, 5, 6]
>>> R.pipe([[[1]], [[[2]]]], R.flat(depth=2), list)
[1, [2]]
```

Parameters:

```plaintext
iterable: NestedList[T]
    The iterable to flatten (positional-only).
depth: int | None
    The depth to flatten to. If None, flattens infinitely (keyword-only).
```

Yields:

```plaintext
T
    The flattened elements.
```

#### flat_map

Yields the elements resulting from applying given function to the given iterable's elements.

Examples:

```pycon
Data first:
>>> list(R.flat_map([1, 2, 3], lambda x: [x, x * 10]))
[1, 10, 2, 20, 3, 30]
>>> list(R.flat_map([1, 2, 3], lambda: [0, 1]))
[0, 1, 0, 1, 0, 1]
>>> list(R.flat_map([1, 2, 3], lambda x, i: [x, x * 10 + i]))
[1, 10, 2, 21, 3, 32]
>>> list(R.flat_map([1, 2, 3], lambda x, i, arr: [x + i, x * 10 + len(arr)]))
[1, 13, 3, 23, 5, 33]
Data last:
>>> R.pipe([1, 2, 3], R.flat_map(lambda x: [x, x * 10]), list)
[1, 10, 2, 20, 3, 30]
```

Parameters:

```plaintext
iterable: Iterable[T]
    The iterable to flatten (positional-only).
callbackfn: Callable[[], Iterable[R]] |
            Callable[[T], Iterable[R]] |
            Callable[[T, int], Iterable[R]] |
            Callable[[T, int, Sequence[T]], Iterable[R]]
    The function to apply to each element of the iterable (positional-only).
```

Yields:

```plaintext
T
    The flattened elements.
```

#### get

Gets value under key from a dict, or under index from a sequence.
Accepts optional default.

Examples:

```pycon
Data first:
>>> R.get([], 0) is None
True
>>> R.get([1], 0)
1
>>> R.get([1], 2, 5)
5
>>> R.get({'a': 3}, 'a', 5)
3
>>> R.get({'a': 3}, 'aa', 5)
5
>>> R.get({'a': 3}, 'aa', 'ab')
'ab'
Data last:
>>> R.get(1)([9, 8])
8
```

Parameters:

```plaintext
thing: dict[Key, T] | Sequenct[T]
    Dict or sequence to get value from.
key: Key | int
    Key to get value from.
default: U
    Default value to return if key is not found.
```

Returns:

```plaintext
T | U
    Value from the dict or sequence, or default if key is not found.
```

#### group_by

Groups elements of an iterable by a key function.
Returns a dict with keys being the results of applying the function to the elements of the iterable.
Values of the returned dict are lists of elements that map to the same key. Order is preserved.
Elements mapping to None are skipped.

Examples:

```pycon
Data first:
>>> R.group_by([{'a': 'cat'}, {'a': 'dog'}], R.prop('a'))
{'cat': [{'a': 'cat'}], 'dog': [{'a': 'dog'}]}
>>> R.group_by([0, 1], lambda x: 'even' if R.is_even(x) else None)
{'even': [0]}
Data last:
>>> R.pipe([{'a': 'cat'}, {'a': 'dog'}], R.group_by(R.prop('a')))
{'cat': [{'a': 'cat'}], 'dog': [{'a': 'dog'}]}
>>> R.pipe([0, 1], R.group_by(lambda x: 'even' if R.is_even(x) else None))
{'even': [0]}
```

Parameters:

```plaintext
iterable: Iterable[T]
    The iterable (positional-only).
function: Callable[[T], K | None]
    Function to apply to each element (positional-only).
```

Returns:

```plaintext
dict[K,T]
```

See Also:
See Also:

- [group_by_prop](#group_by_prop)
- [index_by](#index_by)

#### group_by_prop

Groups dicts by the value under a key.
Returns a dict with keys being the values of the given key in the dicts in the iterable.
Values of the returned dict are lists of dicts with the same value for the key. Order is preserved.
If the value is not in the dict or if it is None the dict is skipped.

Examples:

```pycon
Data first:
>>> R.group_by_prop([{'a': 'cat'}, {'a': 'dog'}, {}, {'b': 'cat'}], 'a')
{'cat': [{'a': 'cat'}], 'dog': [{'a': 'dog'}]}
Data last:
>>> R.pipe([{'a': 'cat'}, {'a': 'dog'}], R.group_by_prop('a'))
{'cat': [{'a': 'cat'}], 'dog': [{'a': 'dog'}]}
```

Parameters:

```plaintext
iterable: Iterable[dict[K, V]
    The iterable (positional-only).
prop: K
    Function to apply to each element (positional-only).
```

Returns:

```plaintext
dictVK,T]
```

See Also:

- [group_by](#group_by)

#### index_by

Given an iterable and a function returns a dict.
The dicts keys are the results of applying the function to the elements of the iterable.
The values are the values from the iterable.

Examples:

```pycon
Data first:
>>> R.index_by(['one', 'two', 'three'], R.length)
{3: 'two', 5: 'three'}
Data last:
>>> R.pipe(['one', 'two', 'three'], R.index_by(R.length))
{3: 'two', 5: 'three'}
```

Parameters:

```plaintext
iterable : iterable
    Iterable to sum (positional-only).
function: Callable[[T], K]
    The function to apply to each element of the iterable (positional-only).
```

Returns:

```plaintext
dict[K, T]
    The dict.
```

See Also:

- [group_by](#group_by)

#### intersection

Given two iterables, yields elements of the first iterable that appear in the other iterable.
The inputs are treated as multi-sets/bags (multiple copies of items are treated as unique items).
The order of elements is maintained.

Examples:

```pycon
Data first:
>>> list(R.intersection([1, 2, 3], [2, 3, 5]))
[2, 3]
>>> list(R.intersection([1, 1, 2, 2], [1]))
[1]
Data last:
>>> R.pipe([1, 2, 3], R.intersection([2, 3, 5]), list)
[2, 3]
>>> R.pipe([1, 1, 2, 2], R.intersection([1]), list)
[1]
```

Parameters:

```plaintext
iterable : Iterable[T]
    First iterable (positional-only).
other: Iterable[T]
    Second iterable (positional-only).
```

Returns:

```plaintext
Iterable[T]
    Iterable of elements of the first iterable that appear in the other iterable.
```

#### intersection_with

Yields elements of the first iterable that equal to an element in the other iterable.
Given two iterables and an equality function.
The inputs are treated as multi-sets/bags (multiple copies of items are treated as unique items).
The order of elements is maintained.

Examples:

```pycon
Data first:
>>> list(
...  R.intersection_with(
...   [{'id': 1, 'name': 'Ryan'}, {'id': 3, 'name': 'Emma'}],
...   [3, 5],
...   lambda d, x: d['id'] == x,
...  )
... )
[{'id': 3, 'name': 'Emma'}]
Data last:
>>> R.pipe(
...  [{'id': 1, 'name': 'Ryan'}, {'id': 3, 'name': 'Emma'}],
...  R.intersection_with([3, 5], lambda d, x: d['id'] == x),
...  list,
... )
[{'id': 3, 'name': 'Emma'}]
```

Parameters:

```plaintext
iterable : Iterable[T]
    First iterable (positional-only).
other: Iterable[U]
    Second iterable (positional-only).
equality_function: Callable[[T, U], bool]
    Equality function, predicate of arity 2 (positional-only).
```

Returns:

```plaintext
Iterable[T]
    Iterable of elements of the first iterable that appear in the other iterable.
```

#### last

Returns the last element of the iterable.
If the iterable is empty, returns `None`.

Examples:

```pycon
Data first:
>>> R.last([1, 2, 3])
3
Data last:
>>> R.pipe([1, 2, 4, 8, 16], R.filter(R.gt(3)), R.last(), R.default_to(0), R.add(1))
17
```

Parameters:

```plaintext
iterable : Iterable[T]
    Input iterable (positional-only).
```

Returns:

```plaintext
T | None
    Last element of the iterable or `None` if the iterable is empty.
```

#### length

Determines length of the iterable.

Examples:

```pycon
Data first:
>>> R.length([1, 2, 3])
3
>>> R.length((x for x in range(3)))
3
Data last:
>>> R.length()([1, 2, 3])
3
```

Parameters:

```plaintext
iterable : Iterable[Any]
    Input iterable (positional-only).
```

Returns:

```plaintext
length: int
    Length of the iterable, should not be negative.
```

#### map

Maps iterable with a function.

Examples:

```pycon
Data first:
>>> list(R.map([1, 2, 3], R.multiply(2)))
[2, 4, 6]
>>> list(R.map([0, 0], R.add(1)))
[1, 1]
>>> list(R.map([0, 0], lambda value, index: value + index))
[0, 1]
Data last:
>>> list(R.map(R.multiply(2))([1, 2, 3]))
[2, 4, 6]
>>> list(R.map(R.add(1))([0, 0]))
[1, 1]
>>> R.pipe([1, 2, 3], R.map(R.multiply(2)), list)
[2, 4, 6]
>>> R.pipe([0, 0], R.map(R.add(1)), list)
[1, 1]
```

Parameters:

```plaintext
iterable: Iterable[T]
    The iterable to map.
function: Callable[[T], R] | Callable[[T, int], R] | Callable[[T, int, Sequence[T]], R]
    The function to apply to each element.
```

Yields:

```plaintext
R
    Elements satisfying the predicate.
```

#### map_to_obj

Given an iterable and a function returning key-value pairs returns a dict.

Examples:

```pycon
Data first:
>>> R.map_to_obj([1, 2, 3], lambda x: (str(x), x * 2))
{'1': 2, '2': 4, '3': 6}
Data last:
>>> R.pipe([1, 2, 3], R.map_to_obj(lambda x: (str(x), x * 2)))
{'1': 2, '2': 4, '3': 6}
```

Parameters:

```plaintext
iterable : iterable
    Iterable to sum (positional-only).
function: Callable[[T], tuple[K, V]]
    The function to apply to each element of the iterable (positional-only).
```

Returns:

```plaintext
dict[K, V]
    The dict.
```

See Also:

- [index_by](#index_by)

#### map_with_feedback

Maps iterable with a function accepting an accumulated values.

Examples:

```pycon
Data first:
>>> list(R.map_with_feedback([1, 2, 3, 4, 5], lambda prev, x: prev + x, 100))
[101, 103, 106, 110, 115]
Data last:
>>> R.pipe([1, 2, 3, 4, 5], R.map_with_feedback(R.add, 100), list)
[101, 103, 106, 110, 115]
```

Parameters:

```plaintext
iterable: Iterable[T]
    The iterable to map.
function: Callable[[R, T], R],
    The function to apply to each element.
initial_value: R
    The first value for the acculumator.
```

Yields:

```plaintext
R
    Mapped elements.
```

See Also:
See Also:
See Also:

- [fold](#fold)
- [map](#map)
- [reduce](#reduce)

#### mean

Sums the iterable of numbers and divides the result by its length.

Examples:

```pycon
Data first:
>>> R.mean([1, 2, 3])
2.0
>>> R.mean([])
0
Data last:
>>> R.mean()([1, 2, 3])
2.0
>>> R.pipe([], R.mean)
0
```

Parameters:

```plaintext
iterable : iterable
    Iterable to sum (positional-only).
```

Returns:

```plaintext
float
    Mean of the iterable.
```

#### mean_by

Given an iterable and a function returns the mean result of applying the function to the elements of the iterable.

Examples:

```pycon
Data first:
>>> R.mean_by([{'a': 5}, {'a': 1}, {'a': 3}], R.prop('a'))
3.0
Data last:
>>> R.pipe([{'a': 5}, {'a': 1}, {'a': 3}], R.mean_by(R.prop('a')))
3.0
```

Parameters:

```plaintext
iterable : iterable
    Iterable to sum (positional-only).
callbackfn: Callable[[T], float | int]
    The function to apply to each element of the iterable (positional-only).
```

Returns:

```plaintext
float
    The mean.
```

#### nth_by

Returns the elements that would be n-th if the iterable were sorted by the function.
They are yielded in the order they appear in the iterable.

Examples:

```pycon
Data first:
>>> R.nth_by([2, 1, 4, 5, 3], 2, R.identity())
3
Data last:
>>> R.pipe([2, 1, 4, 5, 3], R.nth_by(2, R.identity()))
3
```

Parameters:

```plaintext
iterable : Iterable[T]
    Input iterable (positional-only).
index : int
    Index of the element to return (positional-only).
function: Callable[[T], SupportsGtLt]
    Function to &quot;sort&quot; the iterable by (positional-only).
```

Returns:

```plaintext
T
    The n-th element of the iterable if sorted by the function provided.
```

See Also:
See Also:

- [first_by](#first_by)
- [take_first_by](#take_first_by)

#### only

Returns the only element of the sequence if it has exactly one element, otherwise `None`.

Examples:

```pycon
Data first:
>>> R.only([1])
1
>>> R.only([])
>>> R.only([1, 2])
Data last:
>>> R.only()([1])
1
>>> R.only()([])
>>> R.only()([1, 2])
```

Parameters:

```plaintext
sequence : Sequence[T]
    Input sequence (positional-only).
```

Returns:

```plaintext
T | None
    Only element of the sequence or `None` if the sequence is empty or has more than one element.
```

#### partition

Given an iterable and a predicate returns 2 lists: one with items that satisfy the predicate and one with the rest.
Predicate can appept a value, a value and index, or a value, index, and the whole sequence.
If iterable is not a sequence it is collected into a list first.

Examples:

```pycon
Data first:
>>> R.partition(
...     ['one', 'two', 'forty two'],
...     lambda x: len(x) == 3,
... )
(['one', 'two'], ['forty two'])
>>> R.partition(['one', 'two', 'forty two'], lambda x, i: len(x) == 3 and i % 2 == 0)
(['one'], ['two', 'forty two'])
>>> R.partition(['one', 'two', 'forty two'], lambda x, i, data: len(x) == 3 and i % 2 == 0 and data[0] != x)
([], ['one', 'two', 'forty two'])
Data last:
>>> R.pipe(['one', 'two', 'forty two'], R.partition(lambda x: len(x) == 3))
(['one', 'two'], ['forty two'])
```

Parameters:

```plaintext
iterable: Iterable[T]
    The iterable to partition.
predicate: Callable[[T], bool] | Callable[[T, int], bool] | Callable[[T, int, Sequence[T]], bool]
    The predicate to use for partitioning.
```

Returns:

```plaintext
tuple[list[T], list[T]]
    A tuple of two lists: the first with items that satisfy the predicate and the second with items that don't.
```

See Also:

- [filter](#filter)

#### pull_object

Given an iterable, key function, and value function; returns a dict.

Examples:

```pycon
Data first:
>>> R.pull_object(
...     [{'name': 'john', 'email': 'john@remedajs.com'}, {'name': 'jane', 'email': 'jane@remedajs.com'}],
...     R.prop('name'),
...     R.prop('email')
... )
{'john': 'john@remedajs.com', 'jane': 'jane@remedajs.com'}
Data last:
>>> R.pipe(
...     [{'name': 'john', 'email': 'john@remedajs.com'}, {'name': 'jane', 'email': 'jane@remedajs.com'}],
...     R.pull_object(R.prop('name'), R.prop('email'))
... )
{'john': 'john@remedajs.com', 'jane': 'jane@remedajs.com'}
```

Parameters:

```plaintext
data: Iterable[T]
    The iterable to pull objects from.
key_fn: Callable[[T], K]
    The key function to apply to the objects.
v_fn: Callable[[T], V]
    The value function to apply to the objects.
```

Returns:

```plaintext
dict[K, V]
    The dict from mapped values from the iterable.
```

#### range

Yields numbers from start to end with given step.
Start is inclusive, end is exclusive.

Examples:

```pycon
Data first:
>>> list(R.range(1, 5))
[1, 2, 3, 4]
>>> list(R.range(1.5, 7.8, step=1.2))
[1.5, 2.7, 3.9..., 5.1..., 6.3..., 7.5...]
Data last:
>>> list(R.range(5)(1))
[1, 2, 3, 4]
>>> R.pipe(1, R.range(5), list)
[1, 2, 3, 4]
>>> R.pipe(1.5, R.range(7.8, step=1.2), R.map(R.round(1)), list)
[1.5, 2.7, 3.9, 5.1, 6.3, 7.5]
```

Parameters:

```plaintext
start: int | float
    Start of the range (positional-only).
end: int | float
    End of the range (positional-only).
step: int | float
    Step of the range(keyword-only, optional).
```

Returns:

```plaintext
Iterable[int | float]
    Iterable of numbers from start to end with given step.
```

#### rank_by

Calculates the rank of the item in data by function.
That means how many items in data are less than or equal to the item when mapped with the function.

Examples:

```pycon
Data first:
>>> DATA = [{'a': 5}, {'a': 1}, {'a': 3}]
>>> R.rank_by(DATA, 0, R.prop('a'))
0
>>> R.rank_by(DATA, 1, R.prop('a'))
1
>>> R.rank_by(DATA, 2, R.prop('a'))
1
>>> R.rank_by(DATA, 3, R.prop('a'))
2
Data last:
>>> R.pipe(DATA, R.rank_by(0, R.prop('a')))
0
>>> R.pipe(DATA, R.rank_by(1, R.prop('a')))
1
>>> R.pipe(DATA, R.rank_by(2, R.prop('a')))
1
>>> R.pipe(DATA, R.rank_by(3, R.prop('a')))
2
```

Parameters:

```plaintext
data: Iterable[T]
    The data to rank.
item: SupportsRichComparisonT
    The item to rank.
function: Callable[T, SupportsRichComparisonT]
    The function to apply to each item in data.
```

Returns:

```plaintext
int
    The rank of the item in data. Will be non-negative.
```

#### reduce

Applies the given function to each element of the iterable in order passing previous result to the function.

Examples:

```pycon
Data first:
>>> R.reduce([1, 2, 3, 4, 5], lambda a, x: a + x)
15
Data last:
>>> R.reduce(R.add)([1, 2, 3, 4, 5])
15
>>> R.pipe([1, 2, 3, 4, 5], R.reduce(R.add))
15
```

Parameters:

```plaintext
iterable: Iterable[T]
    The iterable (positional-only).
callbackfn: Callable[[T, T], T]
    The reducer function (positional-only).
```

Returns:

```plaintext
T
    The reduced value.
```

#### reverse

Yields the elements of the iterable from last to first.
Accumulates the elements of the iterable in a list before yielding them.

Examples:

```pycon
Data first:
>>> list(R.reverse([1, 2, 3]))
[3, 2, 1]
Data last:
>>> list(R.reverse()(range(1, 4)))
[3, 2, 1]
```

Parameters:

```plaintext
iterable : Iterable[T]
    Iterable to reverse (positional-only).
```

Returns:

```plaintext
Iterable[T]
    Iterable with elements in reverse order.
```

#### sample

Returns a random sample of size given from the iterable.

Examples:

```pycon
Data first:
>>> import random; random.seed(0)
>>> R.sample([4, 2, 7, 5], 2)
[5, 2]
Data last:
>>> R.pipe([4, 2, 7, 5], R.sample(2))
[4, 2]
>>> R.sample(2)(range(1, 5))
[4, 2]
```

Parameters:

```plaintext
iterable : Iterable[T]
    Iterable to sample from (positional-only).
size: int
    Size of the sample (positional-only).
```

Returns:

```plaintext
list[T]
    List of the sample elements in the iterable in random order.
```

#### shuffle

Returns the elements of the iterable in random order.

Examples:

```pycon
Data first:
>>> import random; random.seed(0)
>>> R.shuffle([4, 2, 7, 5])
[7, 4, 2, 5]
Data last:
>>> R.pipe([4, 2, 7, 5], R.shuffle())
[4, 2, 5, 7]
>>> R.shuffle()(range(1, 5))
[1, 3, 2, 4]
```

Parameters:

```plaintext
iterable : Iterable[T]
    Iterable to shuffle (positional-only).
```

Returns:

```plaintext
list[T]
    List of the elements in the iterable in random order.
```

#### slice

Given an iterable and start and end index returns a string from the start index to the end index.
Works like list[start:end].
Start index is inclusive, end index is exclusive.
End is optional if not provided returns the iterable from start to the end of the iterable given.

Examples:

```pycon
Data first:
>>> list(R.slice(range(5), 2))
[2, 3, 4]
>>> list(R.slice([10, 20, 30, 40, 50], 2, 5))
[30, 40, 50]
>>> ''.join(R.slice('abcdefghijkl', 1))
'bcdefghijkl'
>>> ''.join(R.slice('abcdefghijkl', 4, 7))
'efg'
Data last:
>>> list(R.slice(2)(range(5)))
[2, 3, 4]
>>> list(R.slice(2, 5)([10, 20, 30, 40, 50]))
[30, 40, 50]
>>> ''.join(R.slice(1)('abcdefghijkl'))
'bcdefghijkl'
>>> ''.join(R.slice(4, 7)('abcdefghijkl'))
'efg'
```

Parameters:

```plaintext
iterable : Iterable[T]
    Input iterable (positional-only).
start : int
    Start index (positional-only).
end : int, optional
    End index (positional-only).
```

Returns:

```plaintext
Iterable[T]
    Iterable from the start index to the end index.
```

See Also:
See Also:

- [slice_string](#slice_string)
- [splice](#splice)

#### sort

Given an iterable and a function, returns a list of the elements of the iterable sorted by the function.
Alias to sorted(it, key=fn).

Examples:

```pycon
Data first:
>>> R.sort([{'a': 1}, {'a': 3}, {'a': 7}, {'a': 2}], R.prop('a'))
[{'a': 1}, {'a': 2}, {'a': 3}, {'a': 7}]
Data last:
>>> R.pipe([{'a': 1}, {'a': 3}, {'a': 7}, {'a': 2}], R.sort(R.prop('a')))
[{'a': 1}, {'a': 2}, {'a': 3}, {'a': 7}]
```

Parameters:

```plaintext
iterable : Iterable[T]
    Iterable to sort (positional-only).
function: Callable[[T], 'SupportsRichComparison']
    Function to use for sorting (positional-only).
```

Returns:

```plaintext
list[T]
    List of the elements in the iterable sorted by the function.
```

#### sorted_index

Given a sorted sequence and an item, returns the index.
The index is the first position where the item should be inserted to keep the sequence sorted.
&quot;sorted&quot; means that elements are sorted.
The result is also the number of elements smaller that the item.

Examples:

```pycon
Data first:
>>> R.sorted_index(['a', 'a', 'b', 'c', 'c'], 'c')
3
>>> R.sorted_index(['a', 'a', 'b', 'c', 'c'], 'd')
5
Data last:
>>> R.pipe(['a', 'a', 'b', 'c', 'c'], R.sorted_index('c'))
3
```

Parameters:

```plaintext
data: Sequence[T]
    The data.
item: T
    The item to insert.
```

Returns:

```plaintext
int
    The index. Will be non-negative.
```

See Also:

- [sorted_last_index](#sorted_last_index)

#### sorted_index_by

Given a sorted sequence and a comparison function and an item, returns the index.
The index is the first position where the item should be inserted to keep the sequence sorted.
&quot;sorted&quot; means that elements are sorted by the function.
The result is also the number of elements smaller that the item when compared with the function.

Examples:

```pycon
Data first:
>>> R.sorted_index_by([{'age': 20}, {'age': 22}], {'age': 21}, R.prop('age'))
1
>>> R.sorted_index_by([{'age': 20}, {'age': 21}], {'age': 21}, R.prop('age'))
1
>>> R.sorted_index_by([{'age': 20}, {'age': 22}], {'age': 24}, R.prop('age'))
2
Data last:
>>> R.sorted_index_by({'age': 21}, R.prop('age'))([{'age': 20}, {'age': 22}])
1
```

Parameters:

```plaintext
data: Sequence[T]
    The data.
item: T
    The item to insert.
function: Callable[[T], SupportsRichComparison]
    The comparison function.
```

Returns:

```plaintext
int
    The index. Will be non-negative.
```

See Also:

- [sorted_last_index_by](#sorted_last_index_by)

#### sorted_index_with

Given a sorted sequence and a predicate, returns the index where the predicate becomes false.
&quot;sorted&quot; means that elements for whom the predicate is true are first in the sequence.
The result is also the number of elements for whom the predicate is true.

Examples:

```pycon
Data first:
>>> R.sorted_index_with(['a', 'ab', 'abc'], R.piped(R.length, R.lt(2)))
1
>>> R.sorted_index_with(['a', 'ab', 'abc'], R.piped(R.length, R.lt(5)))
3
>>> R.sorted_index_with(['a', 'ab', 'abc'], R.piped(R.length, R.gt(0)))
3
>>> R.sorted_index_with(['a', 'ab', 'abc'], R.piped(R.length, R.lt(0)))
0
Data last:
>>> R.pipe(['a', 'ab', 'abc'], R.sorted_index_with(R.piped(R.length, R.lt(2))))
1
```

Parameters:

```plaintext
data: Sequence[T]
    The data.
predicate: Callable[[T], bool]
    Predicate to check.
```

Returns:

```plaintext
int
    The index. Will be non-negative.
```

#### sorted_last_index

Given a sorted sequence and an item, returns the index.
The index is the last position where the item should be inserted to keep the sequence sorted.
&quot;sorted&quot; means that elements are sorted.
The result is also the number of elements smaller or equal to the item.

Examples:

```pycon
Data first:
>>> R.sorted_last_index(['a', 'a', 'b', 'c', 'c'], 'c')
5
>>> R.sorted_last_index(['a', 'a', 'b', 'c', 'c', 'd'], 'c')
5
Data last:
>>> R.pipe(['a', 'a', 'b', 'c', 'c'], R.sorted_last_index('c'))
5
```

Parameters:

```plaintext
data: Sequence[T]
    The data.
item: T
    The item to insert.
```

Returns:

```plaintext
int
    The index. Will be non-negative.
```

See Also:

- [sorted_index](#sorted_index)

#### sorted_last_index_by

Given a sorted sequence and a comparison function and an item, returns the index.
The index is the last position where the item should be inserted to keep the sequence sorted.
&quot;sorted&quot; means that elements are sorted by the function.
The result is also the number of elements smaller or equal to the item when compared with the function.

Examples:

```pycon
Data first:
>>> R.sorted_index_by([{'age': 20}, {'age': 22}], {'age': 21}, R.prop('age'))
1
>>> R.sorted_index_by([{'age': 20}, {'age': 21}], {'age': 21}, R.prop('age'))
1
>>> R.sorted_index_by([{'age': 20}, {'age': 22}], {'age': 24}, R.prop('age'))
2
Data last:
>>> R.sorted_index_by({'age': 21}, R.prop('age'))([{'age': 20}, {'age': 22}])
1
```

Parameters:

```plaintext
data: Sequence[T]
    The data.
item: T
    The item to insert.
fn: Callable[[T], SupportsRichComparison]
    The comparison function.
```

Returns:

```plaintext
int
    The index. Will be non-negative.
```

See Also:

- [sorted_last_index_by](#sorted_last_index_by)

#### splice

Removes elements from an iterable and inserts new elements in their place.
Start index will be removed.

Examples:

```pycon
Data first:
>>> list(R.splice([1, 2, 3, 4, 5, 6, 7, 8], 2, 3, []))
[1, 2, 6, 7, 8]
>>> list(R.splice([1, 2, 3, 4, 5, 6, 7, 8], 2, 3, [9, 10]))
[1, 2, 9, 10, 6, 7, 8]
Data last:
>>> R.pipe([1, 2, 3, 4, 5, 6, 7, 8], R.splice(2, 3, []), list)
[1, 2, 6, 7, 8]
>>> R.pipe([1, 2, 3, 4, 5, 6, 7, 8], R.splice(2, 3, [9, 10]), list)
[1, 2, 9, 10, 6, 7, 8]
>>> R.pipe((x for x in [1, 2, 3, 4, 5, 6, 7, 8]), R.splice(2, 3, []), list)
[1, 2, 6, 7, 8]
>>> R.pipe((x for x in [1, 2, 3, 4, 5, 6, 7, 8]), R.splice(2, 3, [9, 10]), list)
[1, 2, 9, 10, 6, 7, 8]
```

Parameters:

```plaintext
iterable : Iterable[T]
    Input iterable (positional-only).
start : int
    Removal start index (positional-only).
delete_count : int
    Number of elements to remove (positional-only).
replacement : Iterable[T]
    Iterable of elements to insert (positional-only).
```

Returns:

```plaintext
Iterable[T]
    Iterable with removed elements and inserted new elements.
```

See Also:

- [slice](#slice)

#### split

Splits the given string by separator.
If limit is specified the string will be split at max `limit` number of times into
at most `limit + 1` parts.

Examples:

```pycon
Data first:
>>> R.split('a,b,c', ',')
['a', 'b', 'c']
>>> R.split('a,b,c', ',', limit=2)
['a', 'b', 'c']
>>> R.split('a,b,c', ',', limit=1)
['a', 'b,c']
>>> R.split('a,,b,,c', ',,', limit=1)
['a', 'b,,c']
>>> R.split('a1b2c3d', '\\d')
['a', 'b', 'c', 'd']
>>> R.split('a1b2c3d', '[0-9]')
['a', 'b', 'c', 'd']
Data last:
>>> R.pipe('a,b,c', R.split(','))
['a', 'b', 'c']
>>> R.pipe('a,b,c', R.split(',', limit=2))
['a', 'b', 'c']
>>> R.pipe('a,b,c', R.split(',', limit=1))
['a', 'b,c']
>>> R.pipe('a1b2c3d', R.split('\\d'))
['a', 'b', 'c', 'd']
>>> R.pipe('a1b2c3d', R.split('[0-9]'))
['a', 'b', 'c', 'd']
```

Parameters:

```plaintext
string: str
    String to split (positional-only).
separator: Separator | re.Pattern[str]
    Separator to split by (positional-only).
limit: int | None
    Maximum number of splits (keyword-only, optional).
```

Returns:

```plaintext
list[str]
    List of substrings.
```

#### split_at

Splits the given iterable at the given index.

Examples:

```pycon
Data first:
>>> R.split_at([1, 2, 3], 1)
([1], [2, 3])
>>> R.split_at(range(1, 4), 1)
([1], [2, 3])
>>> R.split_at((x for x in range(1, 4)), 1)
([1], [2, 3])
>>> R.split_at([1, 2, 3, 4, 5], -1)
([1, 2, 3, 4], [5])
Data last:
>>> R.split_at(1)([1, 2, 3])
([1], [2, 3])
>>> R.split_at(-1)([1, 2, 3, 4, 5])
([1, 2, 3, 4], [5])
```

Parameters:

```plaintext
iterable: Iterable[T]
    Iterable to split (positional-only).
index: int
    Index to split at (positional-only).
```

Returns:

```plaintext
tuple[list[T], list[T]]
    Tuple of two sequences.
```

#### split_when

Splits the given iterable at the first element for whom the predicate returns True.

Examples:

```pycon
Data first:
>>> R.split_when([1, 2, 3], R.eq(2))
([1], [2, 3])
>>> R.split_when([1, 2, 3, 4], lambda x, i: x % 2 == 0 and i > 1)
([1, 2, 3], [4])
>>> R.split_when([1, 2, 3, 4], lambda x, i, arr: x % 2 == 0 and i > 1)
([1, 2, 3], [4])
Data last:
>>> R.split_when(R.eq(2))([1, 2, 3])
([1], [2, 3])
```

Parameters:

```plaintext
iterable: Iterable[T]
    Iterable to split (positional-only).
predicate: Callable[[T], bool] | Callable[[T, int], bool] | Callable[[T, int, Sequence[T]], bool]
    Predicate to split by (positional-only).
```

Returns:

```plaintext
tuple[list[T], list[T]]
    Tuple of two sequences.
```

#### sum

Sums the iterable of numbers.
Alias for built-in sum function.

Examples:

```pycon
Data first:
>>> R.sum([1, 2, 3])
6
Data last:
>>> R.sum()([1, 2, 3])
6
>>> R.pipe([1, 2, 3], R.sum)
6
```

Parameters:

```plaintext
iterable : iterable
    Iterable to sum (positional-only).
```

Returns:

```plaintext
int | float
    Sum of the iterable.
```

#### sum_by

Given an iterable and a function, returns the sum of the results of applying the function to each element.

Examples:

```pycon
Data first:
>>> R.sum_by([{'a': 5}, {'a': 1}, {'a': 3}], R.prop('a'))
9
Data last:
>>> R.pipe([{'a': 5}, {'a': 1}, {'a': 3}], R.sum_by(R.prop('a')))
9
```

Parameters:

```plaintext
iterable : Iterable[T]
    Iterable to sum (positional-only).
fn : Callable[[T], TNum]
    Function to apply to each element (positional-only).
```

Returns:

```plaintext
int | float
    Sum of the results of applying the function to each element.
```

#### swap_indices

Yields elements of the given iterable swapping the 2 elements at the given indices.

Examples:

```pycon
Data first:
>>> list(R.swap_indices(['a', 'b', 'c'], 0, 1))
['b', 'a', 'c']
>>> list(R.swap_indices(['a', 'b', 'c'], 1, -1))
['a', 'c', 'b']
>>> R.swap_indices('abc', 0, 1)
'bac'
Data last:
>>> list(R.swap_indices(0, 1)(['a', 'b', 'c']))
['b', 'a', 'c']
>>> R.swap_indices(0, -1)('abc')
'cba'
```

Parameters:

```plaintext
iterable : Iterable[T]
    Iterable to yield elements from (positional-only).
index1 : int
    Index of the first element to swap (positional-only).
index2 : int
    Index of the second element to swap (positional-only).
```

Returns:

```plaintext
Iterable[T]
    Iterable with the elements at the given indices swapped.
```

#### take

Yields the first n elements of the iterable.

Examples:

```pycon
Data first:
>>> list(R.take(range(100), 2))
[0, 1]
>>> list(R.take([2, 1, 3, 7, 6, 6, 6], 4))
[2, 1, 3, 7]
Data last:
>>> list(R.take([2, 1, 3, 7, 6, 6, 6], 4))
[2, 1, 3, 7]
>>> list(R.take(range(100), 2))
[0, 1]
```

Parameters:

```plaintext
iterable : Iterable[T]
    Input iterable (positional-only).
n : int
    Number of elements to yield (positional-only).
```

Returns:

```plaintext
Iterable[T]
    First n elements of the iterable.
```

#### take_first_by

Yields the first n elements of the iterable, as if it were sorted by the function provided.
They are yielded in the order they appear in the iterable.

Examples:

```pycon
Data first:
>>> list(R.take_first_by(['aa', 'aaaa', 'a', 'aaa'], 2, R.length))
['aa', 'a']
Data last:
>>> list(R.pipe(['aa', 'aaaa', 'a', 'aaa'], R.take_first_by(2, R.length)))
['aa', 'a']
```

Parameters:

```plaintext
iterable : Iterable[T]
    Input iterable (positional-only).
n : int
    Number of elements to yield (positional-only).
function: Callable[[T], SupportsGtLt]
    Function to &quot;sort&quot; the iterable by (positional-only).
```

Yields:

```plaintext
T
    First n elements of the iterable if sorted by the function provided.
```

#### take_last

Returns the list of the last n elements of the iterable.

Examples:

```pycon
Data first:
>>> R.take_last(range(5), 2)
[3, 4]
>>> R.take_last([2, 1, 3, 7, 6, 6, 6], 3)
[6, 6, 6]
Data last:
>>> R.take_last(3)([2, 1, 3, 7, 6, 6, 6])
[6, 6, 6]
>>> R.take_last(2)(range(10))
[8, 9]
```

Parameters:

```plaintext
iterable : Iterable[T]
    Input iterable (positional-only).
n : int
    Number of elements to not yield (positional-only).
```

Returns:

```plaintext
list[T]
    The last n elements of the iterable.
```

#### take_last_while

Returns the elements of the iterable from the last one that does not satisfy the predicate.
Doesn't return that last element that does not satisfy the predicate.
Tantamount to iterating the iterable from the end until the first element that does not satisfy the predicate,
but the elements are returned in the original order.

Examples:

```pycon
Data first:
>>> R.take_last_while([1, 2, 10, 3, 4, 5], R.lt(10))
[3, 4, 5]
Data last:
>>> R.pipe([1, 2, 10, 3, 4, 5], R.take_last_while(R.lt(10)))
[3, 4, 5]
```

Parameters:

```plaintext
iterable : Iterable[T]
    Input iterable (positional-only).
predicate: Callable[[T], bool]
    Predicate to check the elements of the iterable (positional-only).
```

Returns:

```plaintext
list[T]
    Elements of the iterable from the last one that does not satisfy the predicate.
```

#### take_while

Yields the elements of the iterable until encountering the element that does not satisfy the predicate.
Doesn't yield the element that does not satisfy the predicate.

Examples:

```pycon
Data first:
>>> list(R.take_while([1, 2, 3, 4, 3, 2, 1], R.neq(4)))
[1, 2, 3]
Data last:
>>> R.pipe([1, 2, 3, 4, 3, 2, 1], R.take_while(R.neq(4)), list)
[1, 2, 3]
```

Parameters:

```plaintext
iterable : Iterable[T]
    Input iterable (positional-only).
predicate: Callable[[T], bool]
    Predicate to check the elements of the iterable (positional-only).
```

Returns:

```plaintext
Iterable[T]
    Elements of the iterable until encountering the element that does not satisfy the predicate.
```

#### times

Yields the result of applying function n times, passing the index as an argument.
If the function accepts 0 arguments, the index is not passed.

Examples:

```pycon
Data first:
>>> list(R.times(5, R.identity()))
[0, 1, 2, 3, 4]
>>> list(R.times(5, R.constant('a')))
['a', 'a', 'a', 'a', 'a']
Data last:
>>> list(R.times(R.identity())(5))
[0, 1, 2, 3, 4]
>>> list(R.times(R.constant('a'))(5))
['a', 'a', 'a', 'a', 'a']
```

Parameters:

```plaintext
n : int
    Number of times to apply the function.
function : Callable[[], T] | Callable[[int], T]
    Function to apply (positional-only).
```

Returns:

```plaintext
Iterable[T]
    Result of applying function to data.
```

#### unique

Yields elements of the iterable without duplicates in the order they appear.

Examples:

```pycon
Data first:
>>> list(R.unique(['1', '2', '3', '2', '1']))
['1', '2', '3']
Data last:
>>> R.pipe(['1', '2', '3', '2', '1'], R.unique, list)
['1', '2', '3']
```

Parameters:

```plaintext
iterable: Iterable[T]
    Iterable (positional-only).
```

Returns:

```plaintext
Iterable[T]
    Unique elements from the iterable.
```

#### unique_by

Yields unique elements from the iterable, given the iterable and a mapping function.
Uniqueness is determined by resulting in the same value when passed to the mapping function.

Examples:

```pycon
Data first:
>>> list(
...     R.unique_by(
...             [{'n': 1}, {'n': 2}, {'n': 2}, {'n': 5}, {'n': 1}, {'n': 6}, {'n': 7}],
...             R.prop('n'),
...         )
... )
[{'n': 1}, {'n': 2}, {'n': 5}, {'n': 6}, {'n': 7}]
Data last:
>>> R.pipe(
...     [{'n': 1}, {'n': 2}, {'n': 2}, {'n': 5}, {'n': 1}, {'n': 6}, {'n': 7}],
...     R.unique_by(R.prop('n')),
...     R.take(3),
...     list,
... )
[{'n': 1}, {'n': 2}, {'n': 5}]
```

Parameters:

```plaintext
iterable: Iterable[T]
    Iterable (positional-only).
function: Callable[[T], U]
    Function to apply to each element of the iterable (positional-only).
```

Returns:

```plaintext
Iterable[T]
    Unique elements from the iterable.
```

#### unique_with

Yields unique elements from the iterable, given the iterable and a comparison function.
Uniqueness is determined by the comparison function.

Examples:

```pycon
Data first:
>>> list(
...     R.unique_with(
...         [{'a': 1}, {'a': 2}, {'a': 2}, {'a': 5}, {'a': 1}, {'a': 6}, {'a': 7}],
...         lambda x, y: x == y,
...     )
... )
[{'a': 1}, {'a': 2}, {'a': 5}, {'a': 6}, {'a': 7}]
>>> list(
...     R.unique_with(
...         [{'a': 1}, {'a': 2}, {'a': 2}, {'a': 5}, {'a': 1}, {'a': 6}, {'a': 7}],
...         lambda x, y: x['a'] % 2 == y['a'] % 2
...     )
... )
[{'a': 1}, {'a': 2}]
>>> list(
...     R.unique_with(
...         [{'a': 1}, {'a': 2}, {'a': 2}, {'a': 5}, {'a': 1}, {'a': 6}, {'a': 7}],
...         lambda x, y: x['a'] % 3 == y['a'] % 3
...     )
... )
[{'a': 1}, {'a': 2}, {'a': 6}]
Data last:
>>> list(
...     R.unique_with(R.eq)(
...         [{'a': 1}, {'a': 2}, {'a': 2}, {'a': 5}, {'a': 1}, {'a': 6}, {'a': 7}]
...     )
... )
[{'a': 1}, {'a': 2}, {'a': 5}, {'a': 6}, {'a': 7}]
>>> R.pipe(
...     [{'a': 1}, {'a': 2}, {'a': 2}, {'a': 5}, {'a': 1}, {'a': 6}, {'a': 7}],
...     R.unique_with(R.eq),
...     R.take(3),
...     list,
... )
[{'a': 1}, {'a': 2}, {'a': 5}]
```

Parameters:

```plaintext
iterable: Iterable[T]
    Iterable (positional-only).
function: Callable[[T, T], bool]
    Function to compare elements (positional-only).
```

Returns:

```plaintext
Iterable[T]
    Unique elements from the iterable.
```

#### zip

Yields pairs of elements from the two iterables.
Alias for zip(first, second, strict=strict).

Examples:

```pycon
Data first:
>>> list(R.zip([1, 2], ['a', 'b']))
[(1, 'a'), (2, 'b')]
Data last:
>>> list(R.zip(['a', 'b'])([1, 2]))
[(1, 'a'), (2, 'b')]
```

Parameters:

```plaintext
first: Iterable[T]
    First iterable (positional-only).
second: Iterable[U]
    Second iterable (positional-only).
strict: bool
    Whether to raise StopIteration if the iterables are of different lengths (keyword-only, optional).
```

Yields:

```plaintext
tuple[T, U]
    Pairs of elements from the two iterables.
```

#### zip_with

Yields the result of applying the function to pairs of elements from two iterables.

Examples:

```pycon
Data first:
>>> list(R.zip_with(['1', '2', '3'], ['a', 'b', 'c'], R.add))
['1a', '2b', '3c']
Data last:
>>> R.pipe(['1', '2', '3'], R.zip_with(['a', 'b', 'c'], R.add), list)
['1a', '2b', '3c']
```

Parameters:

```plaintext
first: Iterable[T]
    First iterable (positional-only).
second: Iterable[U]
    Second iterable (positional-only).
function: Callable[[T, U], V]
    Function to apply to pairs of elements (positional-only).
strict: bool
    Whether to raise StopIteration if the iterables are of different lengths (keyword-only, optional).
```

Yields:

```plaintext
V
    Result of applying the function to pairs of elements from two iterables.
```

### Function

#### apply

Applies function accepting 1 or 0 arguments to the data.
Saves the user the manual check for the number of arguments (function's arity).
Can be used data-first, data-last or data-first without function (assuming the data is not a callable).

Examples:

```pycon
Data first:
>>> R.apply(10, R.add(5))
15
>>> R.apply(10, R.constant('asd'))
'asd'
Data first without function:
>>> R.apply(10)(R.add(5))
15
>>> R.apply(10)(R.constant('asd'))
'asd'
Data last:
>>> R.apply(R.add(5))(10)
15
>>> R.apply(R.constant('asd'))(10)
'asd'
```

Parameters:

```plaintext
data : T
    Input data (positional-only).
function : Callable[[T], R] | Callable[[], R]
    Function to apply (positional-only).
```

Returns:

```plaintext
R
    Result of applying function to data.
```

#### conditional

For data and a list of (predicate, transformer) executes the first transformer for which the predicate is True.
Acts like a switch statement or if-elif-else construct.
The condition can be only a transformers instead of a tuple in which case it is always used if reached.

Examples:

```pycon
Data first:
>>> R.conditional(
...     3,
...     [
...         (R.is_string, lambda name: f'Hello {name}'),
...         (R.is_number, lambda id: f'Hello ID: {id}'),
...         R.constant(None),
...     ],
... )
'Hello ID: 3'
Data last:
>>> R.conditional(
...     [
...         (R.is_string, lambda name: f'Hello {name}'),
...         (R.is_number, lambda id: f'Hello ID: {id}'),
...     ],
... )('a')
'Hello a'
```

Parameters:

```plaintext
data: T
    The value on which to test the predicates and execute the transformers.
conditions: Conditions[T, ReturnType]
    List of (predicate, transformer) tuples.
```

Returns:

```plaintext
ReturnType
    The result of the first transformer for which the predicate is True.
```

#### constant

Given a value, returns a function (closure) that returns the value.

Examples:

```pycon
Data first:
>>> R.constant(1)()
1
Data last:
>>> list(R.map([1, 2, 3], R.constant('a')))
['a', 'a', 'a']
>>> list(R.times(3, R.constant(6)))
[6, 6, 6]
```

Parameters:

```plaintext
value : T
    Value to return (positional-only).
```

Returns:

```plaintext
Callable[[], T]
    Closure that returns the value.
```

#### do_nothing

Returns a function that does nothing.

Examples:

```pycon
>>> R.do_nothing()(1, 2, 3)
```

Parameters:

```plaintext

```

Returns:

```plaintext
function: Callable[..., None]
    A function that does nothing.
```

#### fold

Applies the given function to each element of the iterable in order passing previous result to the function.

Examples:

```pycon
Data first:
>>> R.fold([1, 2, 3, 4, 5], lambda a, x: a + x, 100)
115
Data last:
>>> R.fold(R.add, 100)([1, 2, 3, 4, 5])
115
>>> R.pipe([1, 2, 3, 4, 5], R.fold(R.add, 100))
115
```

Parameters:

```plaintext
iterable: Iterable[T]
    The iterable (positional-only).
callbackfn: Callable[[Acc, T], Acc]
    The reducer function (positional-only).
initial_value: Acc
    The initial value (positional-only).
```

Returns:

```plaintext
result: Acc
    The reduced value.
```

#### for_each

Applies the given function to each element of the iterable and then yields the element.

Examples:

```pycon
Data first:
>>> x = []
>>> result = list(R.for_each([1, 2, 3], lambda i: x.append(i*10)))
>>> x
[10, 20, 30]
>>> result
[1, 2, 3]
Data last:
>>> x = []
>>> result = list(R.for_each(lambda i: x.append(i*10))([1, 2, 3]))
>>> x
[10, 20, 30]
>>> result
[1, 2, 3]
```

Parameters:

```plaintext
iterable: Iterable[T]
    The iterable to flatten (positional-only).
callbackfn: Callable[[], Any] |
            Callable[[T], Any]
    The function to apply to each element of the iterable (positional-only).
```

Yields:

```plaintext
T
    The elements of the original iterable.
```

#### identity

Given a value, returns it.

Examples:

```pycon
Data first:
>>> R.identity(1)
1
Data last:
>>> R.pipe([1, 2, 3], R.map(R.identity()), list)
[1, 2, 3]
```

Parameters:

```plaintext
value : T
    Value (positional-only).
```

Returns:

```plaintext
T
    Value.
```

See Also:

- [constant](#constant)

#### negate

Given a value and a predicate returns the opposite of the predicate applied to the value.
Can be given only a value.

Examples:

```pycon
Data first:
>>> R.negate(0, R.is_truthy)
True
>>> R.negate([1, 2, 3], R.is_truthy)
False
>>> R.negate(False)
True
Data last:
>>> R.negate(R.is_truthy)(0)
True
>>> R.negate()(True)
False
```

Parameters:

```plaintext
data: T
    Data to pass to predicate.
predicate:
    Predicate to check data on.
```

Returns:

```plaintext
boolean
    Whether the data doesn't satisfy the predicate.
```

#### once

Wraps a function into a function that runs the original at the first call and caches the result.
Subsequent calls with return the cached value without re-running the function.

Examples:

```pycon
Data first:
>>> x = []
>>> fn = R.once(lambda: x.append(1))
>>> fn()
>>> fn()
>>> x
[1]
```

Parameters:

```plaintext
function: Callable[P, T]
    The function to wrap.
```

Returns:

```plaintext
Callable[P, T]
    Wrapped function.
```

#### partial

Returns a closure with args pre-set.

Examples:

```pycon
Data first:
>>> def sum3(a: int, b: int, c: int) -> int:
...     return a + b + c
>>> p = R.partial(sum3, 1, 2)
>>> p(3)
6
>>> p2 = R.partial(sum3, 1)
>>> p2(2, 3)
6
```

Parameters:

```plaintext
function : Callable[..., T]
    The function to partialize (positional-only).
*args : Any
    The arguments to pre-set (positional-only).
```

Returns:

```plaintext
Callable[..., T]
    The resulting closure.
```

#### pipe

Performs left-to-right function composition, passing data through functions in sequence.
Each function receives the output of the previous function.

Examples:

```pycon
Data first:
>>> R.pipe({'a': 'x', 'b': 'y', 'c': 'z'}, R.values(), list)
['x', 'y', 'z']
```

Parameters:

```plaintext
data: Any
    The data to pass to the first function (positional-only).
*functions : Callable
    The functions to compose (positional-only).
```

Returns:

```plaintext
Any
    The result of the composed functions.
```

See Also:

- [piped](#piped)

#### piped

Data last version of `pipe`.

Examples:

```pycon
Data last:
>>> list(R.map([{'a': 1}, {'a': 2}, {'a': 3}], R.piped(R.prop('a'), R.default_to(0), R.add(1))))
[2, 3, 4]
```

Parameters:

```plaintext
*functions : Callable
    The functions to compose (positional-only).
```

Returns:

```plaintext
Callable
    The function composed of the given functions.
```

See Also:

- [pipe](#pipe)

#### tap

Applies the givent function to the value and returns the value.

Examples:

```pycon
Data first:
>>> acc = []
>>> R.tap(5, lambda x: acc.append(x))
5
>>> acc
[5]
Data last:
>>> acc = []
>>> R.tap(lambda x: acc.append(x))(5)
5
>>> acc
[5]
```

Parameters:

```plaintext
value : T
    Input value (positional-only).
function: Callable[[T], Any]
    Function to apply to the value (positional-only).
```

Returns:

```plaintext
T
    The value given
```

#### when

Given data, predicate, and transformer; applies the transformer to the data if the predicate is true on the data.
Accepts optional on_false transformer.
Predicate and transformers can have arity 0 or 1.

Examples:

```pycon
Data first:
>>> R.when(4, R.gt(3), R.add(1))
5
>>> R.when(2, R.gt(3), R.add(1))
2
>>> R.when(2, R.gt(3), R.add(1), on_false=R.multiply(2))
4
>>> R.when(2, R.gt(3), R.add(1), on_false=R.constant(5))
5
Data last:
>>> R.when(R.gt(3), R.add(1))(4)
5
>>> R.when(R.gt(3), R.add(1))(2)
2
>>> R.when(R.gt(3), R.add(1), on_false=R.multiply(2))(2)
4
>>> R.when(R.gt(3), R.add(1), on_false=R.constant(5))(2)
5
```

Parameters:

```plaintext
data: T
    Value (positional-only).
predicate: Callable[[T], bool] | Callable[[], bool]
    The predicate to apply to data (positional-only).
transformer: Callable[[T], ReturnType] | Callable[[], ReturnType]
    The transformer to apply to data if the predicate is true (positional-only).
on_false: Callable[[T], ReturnType] | Callable[[], ReturnType] | None
    The transformer to apply to data if the predicate is false (keyword-only, optional).
```

Returns:

```plaintext
ReturnType | T
    The result of the transformer if the predicate is true, otherwise the original data.
```

### TypeGuard

#### is_bool

A function that checks if the passed parameter is a boolean and narrows its type accordingly.

Examples:

```pycon
Data first:
>>> R.is_bool(True)
True
>>> R.is_bool(False)
True
>>> R.is_bool(1)
False
Data last:
>>> R.is_bool()(True)
True
>>> R.is_bool()(False)
True
>>> R.is_bool()(1)
False
```

Parameters:

```plaintext
value: Any
    Value to check.
```

Returns:

```plaintext
result: TypeGuard[bool]
    Whether the value passed is boolean.
```

#### is_callable

A function that checks if the passed parameter is a callable and narrows its type accordingly.
Alias to `isinstance(value, Callable)`.

Examples:

```pycon
Data first:
>>> R.is_callable(lambda x: x + 1)
True
>>> R.is_callable(R.is_callable)
True
>>> R.is_callable(True)
False
Data last:
>>> R.is_callable()(R.add(3))
True
>>> R.is_callable()(2137)
False
```

Parameters:

```plaintext
value: Any
    Value to check.
```

Returns:

```plaintext
result: bool
    Whether the value passed is an integer.
```

#### is_empty

A function that checks if the passed parameter is empty and narrows its type accordingly.
Empty are:

- [] (list)
- '' (string)
- () (tuple)
- {} (dictionary)
- set() (set)

Examples:

```pycon
Data first:
>>> R.is_empty([])
True
>>> R.is_empty(range(10))
False
Data last:
>>> R.is_empty()([])
True
>>> R.is_empty()([1])
False
```

Parameters:

```plaintext
data: Any
    Value to check.
```

Returns:

```plaintext
TypeGuard[Empty]
    Whether the value passed is empty.
```

#### is_float

A function that checks if the passed parameter is a float and narrows its type accordingly.
Alias to `isinstance(value, float)`.

Examples:

```pycon
Data first:
>>> R.is_float(1.1)
True
>>> R.is_float(1)
False
Data last:
>>> R.is_float()(1.1)
True
>>> R.is_float()(1)
False
```

Parameters:

```plaintext
value: Any
    Value to check.
```

Returns:

```plaintext
result: TypeGuard[float]
    Whether the value passed is float.
```

#### is_int

A function that checks if the passed parameter is an integer and narrows its type accordingly.
Alias to `isinstance(value, int)`.

Examples:

```pycon
Data first:
>>> R.is_int(1)
True
>>> R.is_int(1.0)
False
>>> R.is_int(True) # True and False are ints in python
True
Data last:
>>> R.is_int()([0])
False
>>> R.is_int()(2137)
True
```

Parameters:

```plaintext
value: Any
    Value to check.
```

Returns:

```plaintext
result: bool
    Whether the value passed is an integer.
```

#### is_list

A function that checks if the passed parameter is a list and narrows its type accordingly.

Examples:

```pycon
Data first:
>>> R.is_list([])
True
>>> R.is_list(range(10))
False
>>> R.is_list(0)
False
Data last:
>>> R.is_list()([1,2])
True
>>> R.is_list()((1,2))
False
```

Parameters:

```plaintext
value: Any
    Value to check.
```

Returns:

```plaintext
result: TypeGuard[bool]
    Whether the value passed is list.
```

#### is_none

A function that checks if the passed parameter is None.
Alias to `value is None`.

Examples:

```pycon
Data first:
>>> R.is_none(None)
True
>>> R.is_none(2.0)
False
>>> R.is_none(2)
False
Data last:
>>> R.is_none()(None)
True
>>> R.is_none()(2)
False
```

Parameters:

```plaintext
value: Any
    Value to check.
```

Returns:

```plaintext
result: bool
    Whether the value passed is None.
```

#### is_number

A function that checks if the passed parameter is a int or float and narrows its type accordingly.
Alias to `isinstance(value, (int, float))`.

Examples:

```pycon
Data first:
>>> R.is_float(1.1)
True
>>> R.is_float(1)
False
>>> R.is_float('1')
False
Data last:
>>> R.is_float()(1.1)
True
>>> R.is_float()(1)
False
>>> R.is_float()('1')
False
```

Parameters:

```plaintext
value: Any
    Value to check.
```

Returns:

```plaintext
result: TypeGuard[int | float]
    Whether the value passed is int or float.
```

#### is_sequence

A function that checks if the passed parameter is a sequence and narrows its type accordingly.
Alias to `isinstance(value, Sequence).` with `Sequence` from `collections.abc`.

Examples:

```pycon
Data first:
>>> R.is_sequence([1,2])
True
>>> R.is_sequence((x for x in range(3)))
False
Data last:
>>> R.is_sequence()([1,2])
True
>>> R.is_sequence()(range(3))
True
```

Parameters:

```plaintext
value: Any
    Value to check.
```

Returns:

```plaintext
result: bool
    Whether the value passed is a sequence.
```

#### is_sized

A function that checks if the passed parameter is Sized and narrows its type accordingly.
Alias to `isinstance(value, Sized).` with `Sized` from `collections.abc`.

Examples:

```pycon
Data first:
>>> R.is_sized([1,2])
True
>>> R.is_sized(3)
False
Data last:
>>> R.is_sized()([1,2])
True
>>> R.is_sized()(False)
False
```

Parameters:

```plaintext
value: Any
    Value to check.
```

Returns:

```plaintext
result: bool
    Whether the value passed is Sized.
```

#### is_string

A function that checks if the passed parameter is a string and narrows its type accordingly.
Alias to `isinstance(value, str).`

Examples:

```pycon
Data first:
>>> R.is_string('')
True
>>> R.is_string('1')
True
>>> R.is_string(1)
False
Data last:
>>> R.is_string()("It's a sin")
True
>>> R.is_string()(1)
False
```

Parameters:

```plaintext
value: Any
    Value to check.
```

Returns:

```plaintext
result: bool
    Whether the value passed is a string.
```

### Number

#### add

Adds two numbers.
Alias for `operator.add` (+) - `__add__` magic method.

Examples:

```pycon
Data first:
>>> R.add(2, 3)
5
Data last:
>>> R.add(3)(2)
5
>>> R.add(0.1)(0.2)
0.3...
```

Parameters:

```plaintext
a : int | float | T
    First thing (positional-only).
b : int | float | T
    Second thing (positional-only).
```

Returns:

```plaintext
int | float | result of adding T to T
    Sum of a and b.
```

#### ceil

Rounds up a given number to a specific precision.

Examples:

```pycon
Data first:
>>> R.ceil(123.9876, 3)
123.988
>>> R.ceil(8541.1, -1)
8550
Data last:
>>> R.ceil(1)(483.22243)
483.3
>>> R.ceil(-3)(456789)
457000
```

Parameters:

```plaintext
value : int | float
    Number to round up (positional-only).
precision : int
    Desired precision (positional-only).
```

Returns:

```plaintext
int | float
    rounded value, int if precision is non-positive, otherwise float.
```

#### clamp

Returns a number if it is within the range specified by the arguments, otherwise the closer boundary.
Works like min and max at the same time.
If you want to specify only one boundary you can do this, but only as a keyword.

Examples:

```pycon
Data first:
>>> R.clamp(10, 5, 15)
10
>>> R.clamp(20, 5, 15)
15
>>> R.clamp(2, 5, 15)
5
>>> R.clamp(10, min=5)
10
>>> R.clamp(2, min=5)
5
>>> R.clamp(2, max=15)
2
>>> R.clamp(20, max=15)
15
Data last:
>>> R.clamp(5, 15)(10)
10
>>> R.clamp(5, 15)(20)
15
>>> R.clamp(5, 15)(2)
5
>>> R.clamp(min=5)(10)
10
>>> R.clamp(min=5)(2)
5
>>> R.clamp(max=15)(2)
2
>>> R.clamp(max=15)(20)
15
```

Parameters:

```plaintext
value: int | float
    Value to clamp.
min: int | float
    Minimal boundary.
max: int | float
    Maximal boundary.
```

Returns:

```plaintext
result: int | float
    Clamped value.
```

#### floor

Rounds down a given number to a specific precision.

Examples:

```pycon
Data first:
>>> R.floor(123.9876, 3)
123.987
>>> R.floor(8541.1, -1)
8540
Data last:
>>> R.floor(1)(483.22243)
483.2
>>> R.floor(-3)(456789)
456000
```

Parameters:

```plaintext
value : int | float
    Number to round down (positional-only).
precision : int
    Desired precision (positional-only).
```

Returns:

```plaintext
int | float
    rounded value, int if precision is non-positive, otherwise float.
```

#### is_divisible_by

Checks whether the first number is divisible by the second.
Tantamount to `divisor % dividend == 0`.

Examples:

```pycon
Data first:
>>> R.is_divisible_by(2, 3)
False
>>> R.is_divisible_by(4, 2)
True
Data last:
>>> R.is_divisible_by(3)(2)
False
>>> R.is_divisible_by(2)(4)
True
```

Parameters:

```plaintext
dividend : int
    Number to divide (positional-only).
divisor : int
    Number to divide by (positional-only).
```

Returns:

```plaintext
bool
    Whether the first number is divisible by the second.
```

#### is_even

A function that checks if the passed parameter is an even number.
Alias to `value % 2 == 0`.

Examples:

```pycon
Data first:
>>> R.is_even(1)
False
>>> R.is_even(2.0)
True
>>> R.is_even(2)
True
Data last:
>>> R.is_even()(1)
False
>>> R.is_even()(2)
True
```

Parameters:

```plaintext
value: Any
    Value to check.
```

Returns:

```plaintext
result: bool
    Whether the value passed is even.
```

#### is_odd

A function that checks if the passed parameter is an odd number.
Alias to `value % 2 != 0`.

Examples:

```pycon
Data first:
>>> R.is_odd(1)
True
>>> R.is_odd(2.0)
False
>>> R.is_odd(2)
False
Data last:
>>> R.is_odd()(1)
True
>>> R.is_odd()(2)
False
```

Parameters:

```plaintext
value: Any
    Value to check.
```

Returns:

```plaintext
result: bool
    Whether the value passed is odd.
```

#### mod

Adds two numbers.
Alias for `operator.mod` (+) - `__mod__` magic method.

Examples:

```pycon
Data first:
>>> R.mod(5, 2)
1
Data last:
>>> R.mod(3)(6)
0
>>> R.mod(3)(8)
2
```

Parameters:

```plaintext
a : int | float | T
    First thing (positional-only).
b : int | float | T
    Second thing (positional-only).
```

Returns:

```plaintext
reminder: int
    Reminder of the division.
```

#### multiply

Multiplies two numbers.
Alias for `operator.mul` (*) - `__mul__` magic method.

Examples:

```pycon
Data first:
>>> R.multiply(2, 3)
6
Data last:
>>> R.multiply(3)(2)
6
>>> R.multiply(0.1)(0.2)
0.02...
```

Parameters:

```plaintext
a : int | float | T
    First thing (positional-only).
b : int | float | T
    Second thing (positional-only).
```

Returns:

```plaintext
int | float | str | result of multiplying T by T
    Product of a and b.
```

#### round

Rounds a given number to a specific precision.
Alias for built-in `round`.

Examples:

```pycon
Data first:
>>> R.round(123.9876, 3)
123.988
>>> R.round(8541.1, -1)
8540
Data last:
>>> R.round(1)(483.22243)
483.2
>>> R.round(-3)(456789)
457000
```

Parameters:

```plaintext
value : int | float
    Number to round (positional-only).
precision : int
    Desired precision (positional-only).
```

Returns:

```plaintext
int | float
    rounded value, int if precision is non-positive, otherwise float.
```

#### subtract

Subtracts two numbers.
Alias for `operator.sub` (-) - `__sub__` magic method.

Examples:

```pycon
Data first:
>>> R.subtract(2, 3)
-1
Data last:
>>> R.subtract(3)(2)
-1
>>> R.subtract(0.2)(0.1)
-0.1...
```

Parameters:

```plaintext
a : int | float | T
    First thing (positional-only).
b : int | float | T
    Second thing (positional-only).
```

Returns:

```plaintext
int | float | result of subtracting T from T
    Difference between a and b.
```

### String

#### capitalise

Make the first character of the string uppercase.

Examples:

```pycon
Data first:
>>> R.capitalise('hello world')
'Hello world'
>>> R.capitalise('')
''
Data last:
>>> R.capitalise()('hello world')
'Hello world'
>>> R.capitalise()('')
''
```

Parameters:

```plaintext
s : str
    String to capitalise (positional-only).
```

Returns:

```plaintext
str
    Capitalised string.
```

#### ends_with

Determines whether a string ends with the given suffix.
Alias for string.endswith(suffix).

Examples:

```pycon
Data first:
>>> R.ends_with('hello world', 'hello')
False
>>> R.ends_with('hello world', 'world')
True
Data last:
>>> R.pipe('hello world', R.ends_with('hello'))
False
>>> R.pipe('hello world', R.ends_with('world'))
True
```

Parameters:

```plaintext
string : str
    Input string (positional-only).
suffix : str
    Suffix to check (positional-only).
```

Returns:

```plaintext
bool
    Whether the string ends with the given suffix.
```

#### join

Joins the iterable with provided delimiter.
The elements of the iterable are joined by:

- casting them to a string and
- concatenating them one to the other, with the provided glue string in between every two elements.

Examples:

```pycon
Data first:
>>> R.join([1, 2, 3], ",")
'1,2,3'
Data last:
>>> R.join(",")(range(3))
'0,1,2'
```

Parameters:

```plaintext
data : iterable
    Iterable to join (positional-only).
glue : str
    Glue string (positional-only).
```

Returns:

```plaintext
str
    Joined string.
```

#### random_string

Returns a random string of ascii letters and digits of the given length.

Examples:

```pycon
Data first:
>>> import random; random.seed(0)
>>> R.random_string(8)
'0UAqFzWs'
Data last:
>>> R.random_string()(5)
'DK4Fr'
```

Parameters:

```plaintext
length: int
    Desired string length(positional-only).
```

Returns:

```plaintext
str
    Random string of ascii letters and digits of the given length.
```

#### slice_string

Given a string and start and end index returns a string from the start index to the end index.
Alias to string[start:end].
Start index is inclusive, end index is exclusive.
End is optional if not provided returns the string from start to the end of the string given.

Examples:

```pycon
Data first:
>>> R.slice_string('abcdefghijkl', 1)
'bcdefghijkl'
>>> R.slice_string('abcdefghijkl', 4, 7)
'efg'
Data last:
>>> R.slice_string(1)('abcdefghijkl')
'bcdefghijkl'
>>> R.slice_string(4, 7)('abcdefghijkl')
'efg'
```

Parameters:

```plaintext
string : str
    Input string (positional-only).
start : int
    Start index (positional-only).
end : int, optional
    End index (positional-only).
```

Returns:

```plaintext
str
    String from the start index to the end index.
```

See Also:

- [slice](#slice)

#### starts_with

Determines whether a string starts with the given prefix.
Alias for string.startswith(prefix).

Examples:

```pycon
Data first:
>>> R.starts_with('hello world', 'hello')
True
>>> R.starts_with('hello world', 'world')
False
Data last:
>>> R.pipe('hello world', R.starts_with('hello'))
True
>>> R.pipe('hello world', R.starts_with('world'))
False
```

Parameters:

```plaintext
string : str
    Input string (positional-only).
prefix : str
    Prefix to check (positional-only).
```

Returns:

```plaintext
bool
    Whether the string starts with the given prefix.
```

#### to_camel_case

Makes the string camel case - no spaces, first letter lowercase, next words capitalised.

Examples:

```pycon
Data first:
>>> R.to_camel_case('hello world')
'helloWorld'
>>> R.to_camel_case('__HELLO_WORLD__')
'helloWorld'
>>> R.to_camel_case('HasHTML')
'hasHTML'
>>> R.to_camel_case('HasHTML', preserve_consecutive_uppercase=False)
'hasHtml'
Data last:
>>> R.to_camel_case()('hello world')
'helloWorld'
>>> R.to_camel_case()('__HELLO_WORLD__')
'helloWorld'
>>> R.to_camel_case()('HasHTML')
'hasHTML'
>>> R.to_camel_case(preserve_consecutive_uppercase=False)('HasHTML')
'hasHtml'
```

Parameters:

```plaintext
s : str
    String to camel case (positional-only).
preserve_consecutive_uppercase: bool
    Whether to not change words made of consecutive uppercase letters. Default: True.
```

Returns:

```plaintext
str
    Camel cased string.
```

#### to_kebab_case

Makes the string kebab - lowercase, words separated by hyphens.

Examples:

```pycon
Data first:
>>> R.to_kebab_case('hello world')
'hello-world'
>>> R.to_kebab_case('__HELLO_WORLD__')
'hello-world'
Data last:
>>> R.to_kebab_case()('hello world')
'hello-world'
>>> R.to_kebab_case()('__HELLO_WORLD__')
'hello-world'
```

Parameters:

```plaintext
s : str
    String to kebab case (positional-only).
```

Returns:

```plaintext
str
    Kebab cased string.
```

#### to_lower_case

Makes the string lowercase.

Examples:

```pycon
Data first:
>>> R.to_lower_case('Hello World')
'hello world'
Data last:
>>> R.to_lower_case()('Hello WORLD')
'hello world'
```

Parameters:

```plaintext
s : str
    String to lowercase (positional-only).
```

Returns:

```plaintext
str
    Lower cased string.
```

#### to_snake_case

Makes the string snake case - lowercase, words separated by underscores.

Examples:

```pycon
Data first:
>>> R.to_snake_case('hello world')
'hello_world'
>>> R.to_snake_case('__HELLO_WORLD__')
'hello_world'
Data last:
>>> R.to_snake_case()('hello world')
'hello_world'
>>> R.to_snake_case()('__HELLO_WORLD__')
'hello_world'
```

Parameters:

```plaintext
s : str
    String to snake case (positional-only).
```

Returns:

```plaintext
str
    Snake cased string.
```

#### to_title_case

Makes the string title case - words are spaced, every word capitalised.

Examples:

```pycon
Data first:
>>> R.to_title_case('hello world')
'Hello World'
>>> R.to_title_case('--foo-bar--')
'Foo Bar'
>>> R.to_title_case('fooBar')
'Foo Bar'
>>> R.to_title_case('__FOO_BAR__')
'Foo Bar'
>>> R.to_title_case('XMLHttpRequest')
'XML Http Request'
>>> R.to_title_case('XMLHttpRequest', preserve_consecutive_uppercase=False)
'Xml Http Request'
Data last:
>>> R.to_title_case()('hello world')
'Hello World'
>>> R.to_title_case()('--foo-bar--')
'Foo Bar'
>>> R.to_title_case()('fooBar')
'Foo Bar'
>>> R.to_title_case()('__FOO_BAR__')
'Foo Bar'
>>> R.to_title_case()('XMLHttpRequest')
'XML Http Request'
>>> R.to_title_case(preserve_consecutive_uppercase=False)('XMLHttpRequest')
'Xml Http Request'
```

Parameters:

```plaintext
s : str
    String to title case (positional-only).
preserve_consecutive_uppercase: bool
    Whether to not change words made of consecutive uppercase letters. Default: True.
```

Returns:

```plaintext
str
    Title cased string.
```

#### to_upper_case

Makes the string camel case - no spaces, first letter lowercase, next words capitalised.

Examples:

```pycon
Data first:
>>> R.to_camel_case('hello world')
'helloWorld'
>>> R.to_camel_case('__HELLO_WORLD__')
'helloWorld'
>>> R.to_camel_case('HasHTML')
'hasHTML'
>>> R.to_camel_case('HasHTML', preserve_consecutive_uppercase=False)
'hasHtml'
Data last:
>>> R.to_camel_case()('hello world')
'helloWorld'
>>> R.to_camel_case()('__HELLO_WORLD__')
'helloWorld'
>>> R.to_camel_case()('HasHTML')
'hasHTML'
>>> R.to_camel_case(preserve_consecutive_uppercase=False)('HasHTML')
'hasHtml'
```

Parameters:

```plaintext
s : str
    String to camel case (positional-only).
preserve_consecutive_uppercase: bool
    Whether to not change words made of consecutive uppercase letters. Default: True.
```

Returns:

```plaintext
str
    Camel cased string.
```

#### to_words

Split sting into words.

Examples:

```pycon
Data first:
>>> R.to_words('is_string-CamelCase')
['is', 'string', 'Camel', 'Case']
Data last:
>>> R.to_words()('is_string-CamelCase')
['is', 'string', 'Camel', 'Case']
```

Parameters:

```plaintext
s : str
    String to split (positional-only).
```

Returns:

```plaintext
list[str]
    List of words.
```

#### truncate

Given a string, a number, and optional omission, truncates the string to the specified length.
If len(string) &lt;= n, returns the string as is.
The specified length includes the length of the omission,
so the number of characters retained from the string is n - len(omission).
Default omission is '...'.
You can optionally specify a separator to truncate the string at the last occurrence of the separator.
This can prevent words being cut weirdly.

Examples:

```pycon
Data first:
>>> R.truncate('Hello, world!', 8)
'Hello...'
>>> R.truncate('Hello, world!', 20)
'Hello, world!'
>>> R.truncate('Hello, world!', 5, omission='')
'Hello'
>>> R.truncate('cat, dog, mouse', 12, omission='__', separator=',')
'cat, dog__'
>>> R.truncate('cat, dog, mouse', 12, omission='__', separator='-')
'cat, dog, __'
Data last:
>>> R.pipe('Hello, world!', R.truncate(8))
'Hello...'
>>> R.pipe('cat, dog, mouse', R.truncate(12, omission='__', separator=','))
'cat, dog__'
```

Parameters:

```plaintext
string: str
    The string to truncate (positional-only).
n: int
    Desired length of output (positional-only).
omission: str
    The suffix to put after truncation (keyword-only, optional).
separator: str
    Separator at whose last occurrence to truncate the string (keyword-only, optional).
```

Returns:

```plaintext
str
    The truncated string.
```

#### uncapitalise

Make the first character of the string lowercase.

Examples:

```pycon
Data first:
>>> R.uncapitalise('HELLO WORLD')
'hELLO WORLD'
>>> R.uncapitalise('')
''
Data last:
>>> R.uncapitalise()('HEllo world')
'hEllo world'
>>> R.uncapitalise()('')
''
```

Parameters:

```plaintext
s : str
    String to uncapitalise (positional-only).
```

Returns:

```plaintext
str
    Uncapitalised string.
```

### Other

#### default_to

Given two values, returns the first if it is not None, otherwise the second.

Examples:

```pycon
Data first:
>>> R.default_to('hello', 'world')
'hello'
>>> R.default_to(None, 'world')
'world'
Data last:
>>> R.pipe('hello', R.default_to('world'))
'hello'
>>> R.pipe(None, R.default_to('world'))
'world'
```

Parameters:

```plaintext
value : T | None
    Value check for being None (positional-only).
fallback: Fallback
    Value to return if the first is None (positional-only).
```

Returns:

```plaintext
T | Fallback
    First value if it is not None, otherwise the second.
```

#### is_truthy

Returns true if the passed value is truthy.
Alias to bool(value).
Truthy in python definition, so falsy are e.g.:

- 0 (int zero)
- 0.0 (float zero)
- '' (empty string)
- None
- False
- [] (empty list)
- {} (empty dict)
- set() (empty set)
- () (empty tuple)
- range(0) (empty range)

Examples:

```pycon
Data first:
>>> R.is_truthy(3)
True
>>> R.is_truthy('asd')
True
>>> R.is_truthy([4])
True
>>> R.is_truthy(0)
False
>>> R.is_truthy('')
False
>>> R.is_truthy(None)
False
Data last:
>>> R.is_truthy()(True)
True
>>> R.is_truthy()(False)
False
>>> R.is_truthy()(1)
True
```

Parameters:

```plaintext
value: Any
    Value to check.
```

Returns:

```plaintext
result: bool
    Whether the value passed is truthy.
```

### Set

#### is_subset

Returns true if set1 is a subset of set2.

Examples:

```pycon
Data first:
>>> R.is_subset({1, 2}, {1, 2, 3})
True
>>> R.is_subset({1, 2, 3}, {1, 2, 3})
True
>>> R.is_subset({1, 2}, {1, 4})
False
>>> R.is_subset({'a': 3}, {'a': 3, 'b': 5})
True
>>> R.is_subset({'a': 3}, {'a': 3})
True
>>> R.is_subset({'a': 4}, {'a': 3, 'b': 5})
False
Data last:
>>> R.is_subset({1, 2, 3})({1, 2})
True
>>> R.is_subset({1, 2})({1, 4})
False
```

Parameters:

```plaintext
set1: Set[T] | dict[Key, T]
    Set that should be a subset of the other for the result to be true.
set2: Set[T] | dict[Key, T]
    Set that should be a superset of the other for the result to be true.
```

Returns:

```plaintext
result: bool
    Whether set1 is a subset of set2.
```

#### is_superset

Returns true if set1 is a superset of set2.

Examples:

```pycon
Data first:
>>> R.is_superset({1, 2, 3}, {1, 2})
True
>>> R.is_superset({1, 2, 3}, {1, 2, 3})
True
>>> R.is_superset({1, 2}, {1, 4})
False
>>> R.is_superset({'a': 3, 'b': 5}, {'a': 3})
True
>>> R.is_superset({'a': 3}, {'a': 3})
True
>>> R.is_superset(
... {'a': 3, 'b': 5},
... {'a': 4},
... )
False
Data last:
>>> R.is_superset({1, 2})({1, 2, 3})
True
>>> R.is_superset({1, 2})({1, 4})
False
```

Parameters:

```plaintext
set1: Set[T] | dict[Key, T]
    Set that should be a superset of the other for the result to be true.
set2: Set[T] | dict[Key, T]
    Set that should be a subset of the other for the result to be true.
```

Returns:

```plaintext
result: bool
    Whether set1 is a superset of set2.
```

### Dict

#### entries

Given a dict yields tuples of key-value pairs.

Examples:

```pycon
Data first:
>>> list(R.entries({'a': 1, 'b': 2, 'c': 3}))
[('a', 1), ('b', 2), ('c', 3)]
Data last:
>>> R.pipe({'a': 1, 'b': 2, 'c': 3}, R.entries(), list)
[('a', 1), ('b', 2), ('c', 3)]
```

Parameters:

```plaintext
data: dict[K, V]
    The dict to yield key-value pairs from.
```

Returns:

```plaintext
Iterable[tuple[K, V]]
    Key-value pairs from the dict (positional-only).
```

#### evolve

Creates a new dict by applying functions from evolver to the values from the given dict.

Examples:

```pycon
Data first:
>>> evolver = {
...     'count': R.add(1),
...     'time': {'elapsed': R.add(1), 'remaining': R.add(-1)},
... }
>>> data = {
...     'id': 10,
...     'count': 10,
...     'time': {'elapsed': 100, 'remaining': 1400},
... }
>>> R.evolve(data, evolver)
{'id': 10, 'count': 11, 'time': {'elapsed': 101, 'remaining': 1399}}
Data last:
>>> R.evolve(evolver)(data)
{'id': 10, 'count': 11, 'time': {'elapsed': 101, 'remaining': 1399}}
```

Parameters:

```plaintext
data: dict[K, V]
    The dict to apply the evolver to.
evolver: Evolver[K]
    The evolver to apply to the values from the given dict.
```

Returns:

```plaintext
dict[K, V]
    The new dict with the same keys as the given dict and the values transformed by the evolver.
```

#### for_each_dict

Applies the given function to each key-value pair of the dict and then yields the element.

Examples:

```pycon
Data first:
>>> x = []
>>> result = R.for_each_dict({'a': 1, 'b': 2, 'c': 3}, lambda v, k: x.append(k + str(v)))
>>> x
['a1', 'b2', 'c3']
>>> result
{'a': 1, 'b': 2, 'c': 3}
Data last:
>>> x = []
>>> result = R.for_each_dict(lambda v, k: x.append(k + str(v)))({'a': 1, 'b': 2, 'c': 3})
>>> x
['a1', 'b2', 'c3']
>>> result
{'a': 1, 'b': 2, 'c': 3}
```

Parameters:

```plaintext
data: dict[Key, T]
    The dict to iterate over (positional-only).
fn: Callable[[], Any] |
   Callable[[T], Any] |
   Callable[[T, Key], Any] |
   Callable[[T, Key, dict[Key, T]], Any]
    The function to apply to each key-value pair of the dict (positional-only).
```

Returns:

```plaintext
dict[Key, T]
    The given dict.
```

#### from_entries

Given an iterable of key-value pairs returns a dict.
Aliast to `dict(tuples)`.

Examples:

```pycon
Data first:
>>> R.from_entries([('a', 'b'), ('c', 'd')])
{'a': 'b', 'c': 'd'}
Data last:
>>> R.from_entries()([('a', 'b'), ('c', 'd')])
{'a': 'b', 'c': 'd'}
```

Parameters:

```plaintext
tuples: dict[K, V]
    Iterable of key-value pairs (positional-only).
```

Returns:

```plaintext
Iterable[tuple[K, V]]
    Key-value pairs from the dict.
```

#### from_keys

Given an iterable and a function, returns a dict.
Keys are elements from the iterable, values are results of applying the function to the keys.

Examples:

```pycon
Data first:
>>> R.from_keys(['cat', 'dog'], R.length())
{'cat': 3, 'dog': 3}
>>> R.from_keys([1, 2], R.add(1))
{1: 2, 2: 3}
>>> R.from_keys(['cat', 'dog'], R.constant('uwu'))
{'cat': 'uwu', 'dog': 'uwu'}
Data last:
>>> R.pipe(['cat', 'dog'], R.from_keys(R.length()))
{'cat': 3, 'dog': 3}
>>> R.pipe([1, 2], R.from_keys(R.add(1)))
{1: 2, 2: 3}
```

Parameters:

```plaintext
data: Iterable[T]
    Iterable of keys (positional-only).
function: Callable[[T], V] | Callable[[], V]
    Function to apply to the keys (positional-only).
```

Returns:

```plaintext
dict[T, V]
    Dict with keys from the iterable and values from the function.
```

See Also:

- [from_entries](#from_entries)

#### invert

Given a dict returns a dict with the original ones values as keys and keys as values.
Alias to `{v: k for k, v in tuples.items()}`.

Examples:

```pycon
Data first:
>>> R.invert({'a': 'd', 'b': 'e', 'c': 'f'})
{'d': 'a', 'e': 'b', 'f': 'c'}
Data last:
>>> R.invert()({'a': 'd', 'b': 'e', 'c': 'f'})
{'d': 'a', 'e': 'b', 'f': 'c'}
```

Parameters:

```plaintext
data: dict[K, V]
    Dict to invert.
```

Returns:

```plaintext
result: dict[V, K]
    Dict with the original ones values as keys and keys as values.
```

#### keys

Yields keys from dict.

Examples:

```pycon
Data first:
>>> list(R.keys({'a': 'x', 'b': 'y', '5': 'z'}))
['a', 'b', '5']
Data last:
>>> R.pipe({'a': 'x', 'b': 'y', '5': 'z'}, R.keys(), list)
['a', 'b', '5']
```

Parameters:

```plaintext
source: dict[Any, T] | Iterable[T]
    Iterable or dict (positional-only).
```

Yields:

```plaintext
T
    The values.
```

#### map_keys

Given a dict and a function, returns a new dict with the same values but with keys mapped by the function.

Examples:

```pycon
Data first:
>>> glue = lambda k, v: f'{k}{v}'
>>> R.map_keys({'a': 1, 'b': 2}, glue)
{'a1': 1, 'b2': 2}
>>> R.map_keys({'a': 1, 'bbb': 2}, R.length)
{1: 1, 3: 2}
>>> R.map_keys({'a': 1, 'bbb': 2}, R.constant('a'))
{'a': 2}
Data last:
>>> R.pipe({'a': 1, 'b': 2}, R.map_keys(glue))
{'a1': 1, 'b2': 2}
```

Parameters:

```plaintext
data: dict[Key, V]
    Dict to map keys.
function: Callable[[Key, V], NewKey] | Callable[[Key], NewKey] | Callable[[], NewKey]
    Function to map keys.
```

Returns:

```plaintext
dict[NewKey, V]
    Dict with mapped keys.
```

#### map_values

Given a dict and a mapping function returns a dict with values mapped.

Examples:

```pycon
Data first:
>>> R.map_values({'a': 1, 'b': 2}, lambda v, key: f'{v}{key}')
{'a': '1a', 'b': '2b'}
>>> R.map_values({'a': 1, 'b': 2}, R.add(1))
{'a': 2, 'b': 3}
>>> R.map_values({'a': 1, 'b': 2}, R.constant('1'))
{'a': '1', 'b': '1'}
Data last:
>>> R.pipe({'a': 1, 'b': 2}, R.map_values(lambda v, key: f'{v}{key}'))
{'a': '1a', 'b': '2b'}
```

Parameters:

```plaintext
data : dict[Key, V]
    Original dict (positional-only).
function: Callable[[V, Key], NewV] | Callable[[V], NewV] | Callable[[], NewV]
    The function to apply to each element of the iterable (positional-only).
```

Returns:

```plaintext
dict[K, V]
    The dict.
```

#### merge

Merges two dicts.
Alias for `destination | source`.

Examples:

```pycon
Data first:
>>> R.merge({'x': 1, 'y': 2}, {'y': 10, 'z': 2})
{'x': 1, 'y': 10, 'z': 2}
>>> R.merge({'x': 1, 'y': {'a': 3}}, {'y': {'b': 3}, 'z': 2})
{'x': 1, 'y': {'b': 3}, 'z': 2}
Data last:
>>> R.pipe({'x': 1, 'y': 2}, R.merge({'y': 10, 'z': 2}))
{'x': 1, 'y': 10, 'z': 2}
```

Parameters:

```plaintext
destination : dict[Key, T]
    The destination dict (positional-only).
source : dict[Key, T]
    The source dict (positional-only).
```

Returns:

```plaintext
dict[K, T]
    The resulting dict.
```

See Also:
See Also:

- [merge_all](#merge_all)
- [merge_deep](#merge_deep)

#### merge_all

Merges an iterable of dicts.

Examples:

```pycon
Data first:
>>> R.merge_all([{'a': 1, 'b': 1}, {'b': 2, 'c': 3}, {'d': 10}])
{'a': 1, 'b': 2, 'c': 3, 'd': 10}
>>> R.merge_all([])
{}
Data last:
>>> R.merge_all()([{'a': 1, 'b': 1}, {'b': 2, 'c': 3}, {'d': 10}])
{'a': 1, 'b': 2, 'c': 3, 'd': 10}
>>> R.merge_all()([])
{}
```

Parameters:

```plaintext
dicts: Iterable[dict[Key, T]]
    The iterable.
```

Returns:

```plaintext
dict[K, T]
    The resulting dict.
```

See Also:
See Also:

- [merge](#merge)
- [merge_deep](#merge_deep)

#### merge_deep

Merges two dicts recursively.

Examples:

```pycon
Data first:
>>> R.merge_deep({'foo': 'bar', 'x': 1}, {'foo': 'baz', 'y': 2})
{'foo': 'baz', 'x': 1, 'y': 2}
>>> R.merge_deep({'x': 1, 'y': {'a': 3}}, {'y': {'b': 3}, 'z': 2})
{'x': 1, 'y': {'a': 3, 'b': 3}, 'z': 2}
Data last:
>>> R.pipe({'foo': 'bar', 'x': 1}, R.merge_deep({'foo': 'baz', 'y': 2}))
{'foo': 'baz', 'x': 1, 'y': 2}
```

Parameters:

```plaintext
destination : dict[Key, T]
    The destination dict (positional-only).
source : dict[Key, T]
    The source dict (positional-only).
```

Returns:

```plaintext
dict[K, T]
    The resulting dict.
```

See Also:
See Also:

- [merge](#merge)
- [merge_all](#merge_all)

#### omit

Creates a new dict by removing the given keys from the given dict.

Examples:

```pycon
Data first:
>>> R.omit({'a': 1, 'b': 2, 'c': 3, 'd': 4}, ['a', 'd'])
{'b': 2, 'c': 3}
Data last:
>>> R.pipe({'a': 1, 'b': 2, 'c': 3, 'd': 4}, R.omit(['a', 'd']))
{'b': 2, 'c': 3}
```

Parameters:

```plaintext
data: dict[K, V]
    The dict to omit keys from.
keys: Collection[K]
    The keys to omit from the dict.
```

Returns:

```plaintext
dict[K, V]
    The new dict with the omitted keys.
```

See Also:
See Also:

- [omit_by](#omit_by)
- [pick](#pick)

#### omit_by

Creates a new dict by removinf key-value pairs satisfying the predicate.
The predicate can have arity:

- 0 - accept no arguments
- 1 - accept value
- 2 - accept value and key

Examples:

```pycon
Data first:
>>> R.omit_by({'a': 1, 'b': 2, 'A': 3, 'B': 4}, lambda v, k: k == k.upper())
{'a': 1, 'b': 2}
>>> R.omit_by({'a': 1, 'b': 2, 'A': 3, 'B': 4}, R.gt(2))
{'a': 1, 'b': 2}
>>> R.omit_by({'a': 1, 'b': 2, 'A': 3, 'B': 4}, R.constant(False))
{'a': 1, 'b': 2, 'A': 3, 'B': 4}
>>> R.omit_by({'a': 1, 'b': 2, 'A': 3, 'B': 4}, R.constant(True))
{}
Data last:
>>> R.omit_by(lambda v, k: k == k.upper())({'a': 1, 'b': 2, 'A': 3, 'B': 4})
{'a': 1, 'b': 2}
>>> R.omit_by(R.gt(2))({'a': 1, 'b': 2, 'A': 3, 'B': 4})
{'a': 1, 'b': 2}
>>> R.omit_by(R.constant(False))({'a': 1, 'b': 2, 'A': 3, 'B': 4})
{'a': 1, 'b': 2, 'A': 3, 'B': 4}
>>> R.omit_by(R.constant(True))({'a': 1, 'b': 2, 'A': 3, 'B': 4})
{}
```

Parameters:

```plaintext
data: dict[K, V]
    The dict to omit key-value pairs from.
predicate: Callable[[T, Key], bool] | Callable[[T], bool] | Callable[[], bool]
    The predicate to apply to the key-value pairs.
```

Returns:

```plaintext
dict[K, V]
    The new dict with the omitted keys.
```

See Also:
See Also:

- [omit](#omit)
- [pick_by](#pick_by)

#### path_or

Returns the value at the given path or the default value.

Examples:

```pycon
Data first:
>>> R.path_or({'x': 10}, ['y'], 2)
2
>>> R.path_or({'y': 10}, ['y'], 2)
10
>>> R.path_or({'y': {'x': 10}}, ['y', 'x'], 2)
10
>>> R.path_or({'y': {'x': 10}}, ['y', 'y'], 2)
2
Data last:
>>> R.pipe({'x': 10}, R.path_or(['y'], 2))
2
>>> R.pipe({'y': 10}, R.path_or(['y'], 2))
10
```

Parameters:

```plaintext
data: dict[K, V]
    The dict to get the value from.
path: list[int | str]
    The path to get the value from.
default: V
    The default value to return if the path is not found.
```

Returns:

```plaintext
T | Any
    The value at the given path or the default value.
```

#### pick

Creates a new dict by picking the given keys from the given dict.

Examples:

```pycon
Data first:
>>> R.pick({'a': 1, 'b': 2, 'c': 3, 'd': 4}, ['a', 'd'])
{'a': 1, 'd': 4}
Data last:
>>> R.pipe({'a': 1, 'b': 2, 'c': 3, 'd': 4}, R.pick(['a', 'd']))
{'a': 1, 'd': 4}
```

Parameters:

```plaintext
data: dict[K, V]
    The dict to pick keys from.
keys: Collection[K]
    The keys to pick from the dict.
```

Returns:

```plaintext
dict[K, V]
    The new dict with the picked keys.
```

See Also:
See Also:

- [omit](#omit)
- [pick_by](#pick_by)

#### pick_by

Creates a new dict by picking key-value pairs satisfying the predicate.
The predicate can have arity:

- 0 - accept no arguments
- 1 - accept value
- 2 - accept value and key

Examples:

```pycon
Data first:
>>> R.pick_by({'a': 1, 'b': 2, 'A': 3, 'B': 4}, lambda v, k: k == k.upper())
{'A': 3, 'B': 4}
>>> R.pick_by({'a': 1, 'b': 2, 'A': 3, 'B': 4}, R.gt(2))
{'A': 3, 'B': 4}
>>> R.pick_by({'a': 1, 'b': 2, 'A': 3, 'B': 4}, R.constant(False))
{}
>>> R.pick_by({'a': 1, 'b': 2, 'A': 3, 'B': 4}, R.constant(True))
{'a': 1, 'b': 2, 'A': 3, 'B': 4}
Data last:
>>> R.pipe({'a': 1, 'b': 2, 'A': 3, 'B': 4}, R.pick_by(lambda v, k: k == k.upper()))
{'A': 3, 'B': 4}
```

Parameters:

```plaintext
data: dict[K, V]
    The dict to pick key-value pairs from.
predicate: Callable[[T, Key], bool] | Callable[[T], bool] | Callable[[], bool]
    The predicate to apply to the key-value pairs.
```

Returns:

```plaintext
dict[K, V]
    The new dict with the picked keys.
```

See Also:
See Also:

- [omit_by](#omit_by)
- [pick](#pick)

#### prop

Given a dict, list, or tuple, returns the value at the given key or index.
Supports getting a nested value by passing multiple keys.

Examples:

```pycon
Data first:
>>> R.prop({'foo': {'bar': 'baz'}}, 'foo')
{'bar': 'baz'}
>>> R.prop({'foo': {'bar': 'baz'}}, 'foo', 'bar')
'baz'
>>> R.prop(['cat', 'dog'], 1)
'dog'
Data last:
>>> R.pipe({'foo': {'bar': 'baz'}}, R.prop('foo'))
{'bar': 'baz'}
>>> R.pipe({'foo': {'bar': 'baz'}}, R.prop('foo', 'bar'))
'baz'
>>> R.pipe(['cat', 'dog'], R.prop(1))
'dog'
```

Parameters:

```plaintext
data: dict[K, V] | Sequence[T]
    The dict to get the value from.
keys: Iterable[K]
    The keys to get the value from.
```

Returns:

```plaintext
Any
    The value at the given key or index.
```

#### set

Returns a dict with the given key-value pair set.

Examples:

```pycon
Data first:
>>> R.set({'a': 1}, 'a', 2)
{'a': 2}
>>> R.set({'a': 1}, 'b', 2)
{'a': 1, 'b': 2}
Data last:
>>> R.pipe({'a': 1}, R.set('a', 2))
{'a': 2}
```

Parameters:

```plaintext
data: dict[K, V]
    The dict to set the key-value pair in.
key: K
    The key to set the value for.
value: V
    The value to set for the key.
```

Returns:

```plaintext
dict[K, V]
    The new dict with the key-value pair set.
```

#### set_path

Returns a dict with the value set at the given path.

Examples:

```pycon
Data first:
>>> R.set_path({'a': {'b': 1}}, ['a', 'b'], 2)
{'a': {'b': 2}}
>>> R.set_path({'a': {'b': 1}}, ['a', 'c'], 2)
{'a': {'b': 1, 'c': 2}}
Data last:
>>> R.pipe({'a': {'b': 1}}, R.set_path(['a', 'b'], 2))
{'a': {'b': 2}}
>>> R.pipe({'a': {'b': 1}}, R.set_path(['a', 'c'], 2))
{'a': {'b': 1, 'c': 2}}
```

Parameters:

```plaintext
data: dict[K, V]
    The dict to set the value in.
path: list[int | str]
    The path to set the value at.
value: V
    The value to set.
```

Returns:

```plaintext
dict[K, V]
    The new dict with the key-value pair set.
```

#### swap_props

Returns a dict with the values of the given properties swapped.

Examples:

```pycon
Data first:
>>> R.swap_props({'a': 1, 'b': 2, 'c': 3}, 'a', 'b')
{'a': 2, 'b': 1, 'c': 3}
Data last:
>>> R.swap_props('a', 'b')({'a': 1, 'b': 2, 'c': 3})
{'a': 2, 'b': 1, 'c': 3}
```

Parameters:

```plaintext
data : dict[Key, T]
    Dict to swap properties in (positional-only).
prop1 : Key
    First property to swap (positional-only).
prop2 : Key
    Second property to swap (positional-only).
```

Returns:

```plaintext
dict[Key, T]
    Dict with the values of the given properties swapped.
```

See Also:

- [swap_indices](#swap_indices)

#### values

Given an iterable or dict yields its values.

Examples:

```pycon
Data first:
>>> list(R.values(['x', 'y', 'z']))
['x', 'y', 'z']
>>> list(R.values({'a': 'x', 'b': 'y', 'c': 'z'}))
['x', 'y', 'z']
Data last:
>>> R.pipe(['x', 'y', 'z'], R.values(), list)
['x', 'y', 'z']
>>> R.pipe({'a': 'x', 'b': 'y', 'c': 'z'}, R.values(), list)
['x', 'y', 'z']
>>> R.pipe({'a': 'x', 'b': 'y', 'c': 'z'}, R.values(), R.first())
'x'
```

Parameters:

```plaintext
source: dict[Any, T] | Iterable[T]
    Iterable or dict (positional-only).
```

Yields:

```plaintext
T
    The values.
```

### Comparison

#### eq

Compares two values and returns True if the first is equal to the second.
Alias for `operator.eq` (==) - `__eq__` magic method.

Examples:

```pycon
Data first:
>>> R.eq(2, 3)
False
>>> R.eq(3, 3)
True
>>> R.eq(4, 3)
False
Data last:
>>> R.eq(3)(2)
False
>>> R.eq(3)(3)
True
>>> R.eq(3)(5)
False
```

Parameters:

```plaintext
a : int | float | T
    First thing (positional-only).
b : int | float | T
    Second thing (positional-only).
```

Returns:

```plaintext
bool
    True if a is equal to b, False otherwise.
```

#### ge

Compares two values and returns True if the first is greater than or equal to the second.
Alias for `operator.ge` (&gt;=) - `__ge__` magic method.

Examples:

```pycon
Data first:
>>> R.ge(2, 3)
False
>>> R.ge(3, 3)
True
>>> R.ge(4, 3)
True
Data last:
>>> R.ge(3)(2)
False
>>> R.ge(3)(3)
True
>>> R.ge(3)(5)
True
```

Parameters:

```plaintext
a : int | float | T
    First thing (positional-only).
b : int | float | T
    Second thing (positional-only).
```

Returns:

```plaintext
bool
    True if a is greater than or equal to b, False otherwise.
```

#### gt

Compares two values and returns True if the first is greater than the second.
Alias for `operator.gt` (&gt;) - `__gt__` magic method.

Examples:

```pycon
Data first:
>>> R.gt(2, 3)
False
>>> R.gt(3, 3)
False
>>> R.gt(4, 3)
True
Data last:
>>> R.gt(3)(2)
False
>>> R.gt(3)(3)
False
>>> R.gt(3)(5)
True
```

Parameters:

```plaintext
a : int | float | T
    First thing (positional-only).
b : int | float | T
    Second thing (positional-only).
```

Returns:

```plaintext
bool
    True if a is greater than b, False otherwise.
```

#### le

Compares two values and returns True if the first is less than or equal to the second.
Alias for `operator.le` (&lt;=) - `__le__` magic method.

Examples:

```pycon
Data first:
>>> R.le(2, 3)
True
>>> R.le(3, 3)
True
>>> R.le(4, 3)
False
Data last:
>>> R.le(3)(2)
True
>>> R.le(3)(3)
True
>>> R.le(3)(5)
False
```

Parameters:

```plaintext
a : int | float | T
    First thing (positional-only).
b : int | float | T
    Second thing (positional-only).
```

Returns:

```plaintext
bool
    True if a is less than or equal to b, False otherwise.
```

#### lt

Compares two values and returns True if the first is less than the second.
Alias for `operator.lt` (&lt;) - `__lt__` magic method.

Examples:

```pycon
Data first:
>>> R.lt(2, 3)
True
>>> R.lt(3, 3)
False
>>> R.lt(4, 3)
False
Data last:
>>> R.lt(3)(2)
True
>>> R.lt(3)(3)
False
>>> R.lt(3)(5)
False
```

Parameters:

```plaintext
a : int | float | T
    First thing (positional-only).
b : int | float | T
    Second thing (positional-only).
```

Returns:

```plaintext
bool
    True if a is less than b, False otherwise.
```

#### neq

Compares two values and returns True if the first is not equal to the second.
Alias for `operator.neq` (!=) - `__neq__` magic method.

Examples:

```pycon
Data first:
>>> R.neq(2, 3)
True
>>> R.neq(3, 3)
False
>>> R.neq(4, 3)
True
Data last:
>>> R.neq(3)(2)
True
>>> R.neq(3)(3)
False
>>> R.neq(3)(5)
True
```

Parameters:

```plaintext
a : int | float | T
    First thing (positional-only).
b : int | float | T
    Second thing (positional-only).
```

Returns:

```plaintext
bool
    True if a is not equal to b, False otherwise.
```
