from collections.abc import Callable
from typing import Any, TypeVar, overload

from remedapy.decorator import make_data_last

T = TypeVar('T')


@overload
def le(addend: int | float, /) -> Callable[[int | float], bool]: ...


@overload
def le(addend: T, /) -> Callable[[T], bool]: ...


@overload
def le(value: int | float, addend: int | float, /) -> bool: ...


@overload
def le(value: T, addend: T, /) -> bool: ...


@make_data_last
def le(
    a: Any,
    b: Any,
    /,
) -> Any:
    """
    Compares two values and returns True if the first is less than or equal to the second.

    Alias for `operator.le` (<=) - `__le__` magic method.

    Parameters
    ----------
    a : int | float | T
        First thing (positional-only).
    b : int | float | T
        Second thing (positional-only).

    Returns
    -------
    bool
        True if a is less than or equal to b, False otherwise.

    Examples
    --------
    Data first:
    >>> R.le(2, 3)
    True
    >>> R.le(3, 3)
    True
    >>> R.le(4, 3)
    False

    Data last:
    >>> R.le(3)(2)
    True
    >>> R.le(3)(3)
    True
    >>> R.le(3)(5)
    False

    """
    return a <= b
