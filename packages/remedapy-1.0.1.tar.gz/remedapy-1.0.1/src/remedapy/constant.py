from collections.abc import Callable
from typing import TypeVar

T = TypeVar('T')


def constant(value: T, /) -> Callable[[], T]:
    """
    Given a value, returns a function (closure) that returns the value.

    Parameters
    ----------
    value : T
        Value to return (positional-only).

    Returns
    -------
    Callable[[], T]
        Closure that returns the value.

    Examples
    --------
    Data first:
    >>> R.constant(1)()
    1

    Data last:
    >>> list(R.map([1, 2, 3], R.constant('a')))
    ['a', 'a', 'a']
    >>> list(R.times(3, R.constant(6)))
    [6, 6, 6]

    """

    def fn() -> T:
        return value

    return fn
