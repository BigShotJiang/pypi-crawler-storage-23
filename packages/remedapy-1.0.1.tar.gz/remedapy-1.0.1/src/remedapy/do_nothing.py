from collections.abc import Callable
from typing import Any


def do_nothing() -> Callable[..., None]:
    """
    Returns a function that does nothing.

    Returns
    -------
    function: Callable[..., None]
        A function that does nothing.

    Examples
    --------
    >>> R.do_nothing()(1, 2, 3)

    """

    def fn(*args: Any, **kwargs: Any) -> None:
        pass

    return fn
