from collections.abc import Callable
from typing import Any, TypeGuard, TypeVar, overload

from remedapy.decorator import make_data_last

T = TypeVar('T')


@overload
def is_int() -> Callable[[Any], TypeGuard[int]]: ...


@overload
def is_int(value: Any, /) -> TypeGuard[int]: ...


@make_data_last
def is_int(value: Any, /) -> TypeGuard[int]:
    """
    A function that checks if the passed parameter is an integer and narrows its type accordingly.

    Alias to `isinstance(value, int)`.

    Parameters
    ----------
    value: Any
        Value to check.

    Returns
    -------
    result: bool
        Whether the value passed is an integer.

    Examples
    --------
    Data first:
    >>> R.is_int(1)
    True
    >>> R.is_int(1.0)
    False
    >>> R.is_int(True) # True and False are ints in python
    True

    Data last:
    >>> R.is_int()([0])
    False
    >>> R.is_int()(2137)
    True

    """
    return isinstance(value, int)
