from collections.abc import Callable, Iterable
from typing import TypeVar, overload

from .decorator import make_data_last
from .find_last_index import find_last_index

T = TypeVar('T')


@overload
def take_last_while(iterable: Iterable[T], n: Callable[[T], bool], /) -> list[T]: ...


@overload
def take_last_while(n: Callable[[T], bool], /) -> Callable[[Iterable[T]], list[T]]: ...


@make_data_last
def take_last_while(iterable: Iterable[T], predicate: Callable[[T], bool], /) -> list[T]:
    """
    Returns the elements of the iterable from the last one that does not satisfy the predicate.

    Doesn't return that last element that does not satisfy the predicate.

    Tantamount to iterating the iterable from the end until the first element that does not satisfy the predicate,
    but the elements are returned in the original order.

    Parameters
    ----------
    iterable : Iterable[T]
        Input iterable (positional-only).
    predicate: Callable[[T], bool]
        Predicate to check the elements of the iterable (positional-only).

    Returns
    -------
    list[T]
        Elements of the iterable from the last one that does not satisfy the predicate.

    Examples
    --------
    Data first:
    >>> R.take_last_while([1, 2, 10, 3, 4, 5], R.lt(10))
    [3, 4, 5]

    Data last:
    >>> R.pipe([1, 2, 10, 3, 4, 5], R.take_last_while(R.lt(10)))
    [3, 4, 5]

    """
    list_ = list(iterable)
    index = find_last_index(list_, lambda x: not predicate(x))
    return list_[index + 1 :]
