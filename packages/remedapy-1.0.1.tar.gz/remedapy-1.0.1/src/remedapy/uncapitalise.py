from collections.abc import Callable
from typing import overload

from remedapy.decorator import make_data_last


@overload
def uncapitalise(s: str, /) -> str: ...


@overload
def uncapitalise() -> Callable[[str], str]: ...


@make_data_last
def uncapitalise(s: str, /) -> str:
    """
    Make the first character of the string lowercase.

    Parameters
    ----------
    s : str
        String to uncapitalise (positional-only).

    Returns
    -------
    str
        Uncapitalised string.

    Examples
    --------
    Data first:
    >>> R.uncapitalise('HELLO WORLD')
    'hELLO WORLD'
    >>> R.uncapitalise('')
    ''

    Data last:
    >>> R.uncapitalise()('HEllo world')
    'hEllo world'
    >>> R.uncapitalise()('')
    ''

    """
    if not s:
        return s
    return f'{s[0].lower()}{s[1:]}'
