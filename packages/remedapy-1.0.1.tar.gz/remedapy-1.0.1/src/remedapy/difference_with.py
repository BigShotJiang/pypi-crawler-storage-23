from collections.abc import Callable, Iterable
from typing import TypeVar, overload

from .decorator import make_data_last
from .find import find

T = TypeVar('T')
U = TypeVar('U')


@overload
def difference_with(
    data: Iterable[T],
    other: Iterable[U],
    is_equal: Callable[[T, U], bool],
    /,
) -> Iterable[T]: ...


@overload
def difference_with(
    other: Iterable[U],
    is_equal: Callable[[T, U], bool],
    /,
) -> Callable[[Iterable[T]], Iterable[T]]: ...


@make_data_last
def difference_with(
    iterable: Iterable[T],
    other: Iterable[U],
    equality_function: Callable[[T, U], bool],
    /,
) -> Iterable[T] | Callable[[Iterable[T]], Iterable[T]]:
    """
    Yields elements of the first iterable that are not equal to an element in the other iterable.

    Given two iterables and an equality function.

    The inputs are treated as multi-sets/bags (multiple copies of items are treated as unique items).
    The order of elements is maintained.

    Parameters
    ----------
    iterable : Iterable[T]
        First iterable (positional-only).
    other: Iterable[U]
        Second iterable (positional-only).
    equality_function: Callable[[T, U], bool]
        Equality function, predicate of arity 2 (positional-only).

    Returns
    -------
    Iterable[T]
        Iterable of elements of the first iterable that do not appear in the other iterable.

    Examples
    --------
    Data first:
    >>> list(R.difference_with([{'a': 1}, {'a': 2}, {'a': 3}, {'a': 4}], [2, 5, 3], lambda d, x: d['a'] == x))
    [{'a': 1}, {'a': 4}]

    Data last:
    >>> R.pipe(
    ...     [{'a': 1}, {'a': 2}, {'a': 3}, {'a': 4}, {'a': 5}, {'a': 6}],
    ...     R.difference_with([2, 3], lambda d, x: d['a'] == x),
    ...     list,
    ... )
    [{'a': 1}, {'a': 4}, {'a': 5}, {'a': 6}]

    """
    other_ = list(other)
    for x in iterable:
        if (i := find(other_, lambda a, xx=x: equality_function(xx, a))) is not None:
            other_.remove(i)
        else:
            yield x
