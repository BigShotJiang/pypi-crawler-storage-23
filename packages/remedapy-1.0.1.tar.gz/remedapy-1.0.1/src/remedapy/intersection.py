from collections import Counter
from collections.abc import Callable, Iterable
from typing import TypeVar, overload

from remedapy.decorator import make_data_last

T = TypeVar('T')


@overload
def intersection(
    data: Iterable[T],
    other: Iterable[T],
    /,
) -> Iterable[T]: ...


@overload
def intersection(
    other: Iterable[T],
    /,
) -> Callable[[Iterable[T]], Iterable[T]]: ...


def intersection_helper(
    iterable: Iterable[T],
    other: Iterable[T],
    /,
) -> Iterable[T]:
    to_keep = Counter(other)
    for i in iterable:
        if to_keep[i] > 0:
            yield i
            to_keep[i] -= 1


@make_data_last
def intersection(
    iterable: Iterable[T],
    other: Iterable[T],
    /,
) -> Iterable[T]:
    """
    Given two iterables, yields elements of the first iterable that appear in the other iterable.

    The inputs are treated as multi-sets/bags (multiple copies of items are treated as unique items).
    The order of elements is maintained.

    Parameters
    ----------
    iterable : Iterable[T]
        First iterable (positional-only).
    other: Iterable[T]
        Second iterable (positional-only).

    Returns
    -------
    Iterable[T]
        Iterable of elements of the first iterable that appear in the other iterable.

    Examples
    --------
    Data first:
    >>> list(R.intersection([1, 2, 3], [2, 3, 5]))
    [2, 3]
    >>> list(R.intersection([1, 1, 2, 2], [1]))
    [1]

    Data last:
    >>> R.pipe([1, 2, 3], R.intersection([2, 3, 5]), list)
    [2, 3]
    >>> R.pipe([1, 1, 2, 2], R.intersection([1]), list)
    [1]

    """
    return intersection_helper(iterable, other)
