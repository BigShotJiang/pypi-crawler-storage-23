from collections.abc import Callable, Iterable
from typing import TypeVar, overload

from remedapy.decorator import make_data_last

K = TypeVar('K')
V = TypeVar('V')


@overload
def from_entries(tuples: Iterable[tuple[K, V]], /) -> dict[K, V]: ...


@overload
def from_entries() -> Callable[[Iterable[tuple[K, V]]], dict[K, V]]: ...


@make_data_last
def from_entries(
    tuples: Iterable[tuple[K, V]],
    /,
) -> dict[K, V]:
    """
    Given an iterable of key-value pairs returns a dict.

    Aliast to `dict(tuples)`.

    Parameters
    ----------
    tuples: dict[K, V]
        Iterable of key-value pairs (positional-only).

    Returns
    -------
    Iterable[tuple[K, V]]
        Key-value pairs from the dict.

    Examples
    --------
    Data first:
    >>> R.from_entries([('a', 'b'), ('c', 'd')])
    {'a': 'b', 'c': 'd'}

    Data last:
    >>> R.from_entries()([('a', 'b'), ('c', 'd')])
    {'a': 'b', 'c': 'd'}

    """
    return dict(tuples)
