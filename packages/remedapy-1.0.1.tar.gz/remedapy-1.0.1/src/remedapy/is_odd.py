from collections.abc import Callable
from typing import TypeVar, overload

from .decorator import make_data_last

T = TypeVar('T')


@overload
def is_odd(it: int | float, /) -> bool: ...


@overload
def is_odd() -> Callable[[int | float], bool]: ...


@make_data_last
def is_odd(value: int | float, /) -> bool:
    """
    A function that checks if the passed parameter is an odd number.

    Alias to `value % 2 != 0`.

    Parameters
    ----------
    value: Any
        Value to check.

    Returns
    -------
    result: bool
        Whether the value passed is odd.

    Examples
    --------
    Data first:
    >>> R.is_odd(1)
    True
    >>> R.is_odd(2.0)
    False
    >>> R.is_odd(2)
    False

    Data last:
    >>> R.is_odd()(1)
    True
    >>> R.is_odd()(2)
    False

    """
    return value % 2 != 0
