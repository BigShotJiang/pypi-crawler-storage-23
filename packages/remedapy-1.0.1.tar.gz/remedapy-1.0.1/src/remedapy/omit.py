from collections.abc import Callable, Collection
from typing import TypeVar, overload

from remedapy.decorator import make_data_last

Key = TypeVar('Key', str, int)
T = TypeVar('T')


@overload
def omit(data: dict[Key, T], /, keys: Collection[Key]) -> dict[Key, T]: ...


@overload
def omit(keys: Collection[Key], /) -> Callable[[dict[Key, T]], dict[Key, T]]: ...


@make_data_last
def omit(data: dict[Key, T], keys: Collection[Key], /) -> dict[Key, T]:
    """
    Creates a new dict by removing the given keys from the given dict.

    Parameters
    ----------
    data: dict[K, V]
        The dict to omit keys from.
    keys: Collection[K]
        The keys to omit from the dict.

    Returns
    -------
    dict[K, V]
        The new dict with the omitted keys.

    See Also
    --------
    omit_by
    pick

    Examples
    --------
    Data first:
    >>> R.omit({'a': 1, 'b': 2, 'c': 3, 'd': 4}, ['a', 'd'])
    {'b': 2, 'c': 3}

    Data last:
    >>> R.pipe({'a': 1, 'b': 2, 'c': 3, 'd': 4}, R.omit(['a', 'd']))
    {'b': 2, 'c': 3}

    """
    return {k: v for k, v in data.items() if k not in keys}
