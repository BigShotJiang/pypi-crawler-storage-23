from collections.abc import Callable
from typing import TypeVar, overload

from remedapy.decorator import make_data_last

T = TypeVar('T')


@overload
def identity(x: T, /) -> T: ...


@overload
def identity() -> Callable[[T], T]: ...


@make_data_last
def identity(value: T, /) -> T:
    """
    Given a value, returns it.

    Parameters
    ----------
    value : T
        Value (positional-only).

    Returns
    -------
    T
        Value.

    See Also
    --------
    constant

    Examples
    --------
    Data first:
    >>> R.identity(1)
    1

    Data last:
    >>> R.pipe([1, 2, 3], R.map(R.identity()), list)
    [1, 2, 3]

    """
    return value
