from collections.abc import Callable
from typing import TypeVar, overload

TNum = TypeVar('TNum', int, float)


@overload
def subtract(a: int, /) -> Callable[[TNum], TNum]: ...


@overload
def subtract(a: float, /) -> Callable[[int | float], float]: ...


@overload
def subtract(a: int, b: TNum, /) -> TNum: ...


@overload
def subtract(a: TNum, b: int, /) -> TNum: ...
# rename to value, subtractend
def subtract(
    a: int | float,
    b: int | float | None = None,
    /,
) -> int | float | Callable[[int | float], int | float] | Callable[[TNum], TNum]:
    """
    Subtracts two numbers.

    Alias for `operator.sub` (-) - `__sub__` magic method.

    Parameters
    ----------
    a : int | float | T
        First thing (positional-only).
    b : int | float | T
        Second thing (positional-only).

    Returns
    -------
    int | float | result of subtracting T from T
        Difference between a and b.

    Examples
    --------
    Data first:
    >>> R.subtract(2, 3)
    -1

    Data last:
    >>> R.subtract(3)(2)
    -1
    >>> R.subtract(0.2)(0.1)
    -0.1...

    """
    if b is None:
        return lambda x: x - a
    return a - b
