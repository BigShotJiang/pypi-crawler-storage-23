from collections.abc import Callable
from typing import Any, TypeVar, overload

from remedapy.decorator import make_data_last

T = TypeVar('T')
TNum = TypeVar('TNum', int, float)


@overload
def gt(addend: int | float, /) -> Callable[[int | float], bool]: ...


@overload
def gt(addend: T, /) -> Callable[[T], bool]: ...


@overload
def gt(value: int | float, addend: int | float, /) -> bool: ...


@overload
def gt(value: T, addend: T, /) -> bool: ...


@make_data_last
def gt(
    a: Any,
    b: Any,
    /,
) -> Any:
    """
    Compares two values and returns True if the first is greater than the second.

    Alias for `operator.gt` (>) - `__gt__` magic method.

    Parameters
    ----------
    a : int | float | T
        First thing (positional-only).
    b : int | float | T
        Second thing (positional-only).

    Returns
    -------
    bool
        True if a is greater than b, False otherwise.

    Examples
    --------
    Data first:
    >>> R.gt(2, 3)
    False
    >>> R.gt(3, 3)
    False
    >>> R.gt(4, 3)
    True

    Data last:
    >>> R.gt(3)(2)
    False
    >>> R.gt(3)(3)
    False
    >>> R.gt(3)(5)
    True

    """
    return a > b
