from collections.abc import Callable
from typing import Any, TypeGuard, TypeVar, overload

from remedapy.decorator import make_data_last

T = TypeVar('T')


@overload
def is_bool() -> Callable[[Any], TypeGuard[bool]]: ...


@overload
def is_bool(data: Any, /) -> TypeGuard[bool]: ...


@make_data_last
def is_bool(value: Any, /) -> TypeGuard[bool]:
    """
    A function that checks if the passed parameter is a boolean and narrows its type accordingly.

    Parameters
    ----------
    value: Any
        Value to check.

    Returns
    -------
    result: TypeGuard[bool]
        Whether the value passed is boolean.

    Examples
    --------
    Data first:
    >>> R.is_bool(True)
    True
    >>> R.is_bool(False)
    True
    >>> R.is_bool(1)
    False

    Data last:
    >>> R.is_bool()(True)
    True
    >>> R.is_bool()(False)
    True
    >>> R.is_bool()(1)
    False

    """
    return isinstance(value, bool)
