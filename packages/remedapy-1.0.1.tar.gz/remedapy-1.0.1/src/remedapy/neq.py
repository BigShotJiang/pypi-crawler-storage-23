from collections.abc import Callable
from typing import Any, TypeVar, overload

from remedapy.decorator import make_data_last

T = TypeVar('T')


@overload
def neq(addend: int | float, /) -> Callable[[int | float], bool]: ...


@overload
def neq(addend: T, /) -> Callable[[T], bool]: ...


@overload
def neq(value: int | float, addend: int | float, /) -> bool: ...


@overload
def neq(value: T, addend: T, /) -> bool: ...


@make_data_last
def neq(
    a: Any,
    b: Any,
    /,
) -> Any:
    """
    Compares two values and returns True if the first is not equal to the second.

    Alias for `operator.neq` (!=) - `__neq__` magic method.

    Parameters
    ----------
    a : int | float | T
        First thing (positional-only).
    b : int | float | T
        Second thing (positional-only).

    Returns
    -------
    bool
        True if a is not equal to b, False otherwise.

    Examples
    --------
    Data first:
    >>> R.neq(2, 3)
    True
    >>> R.neq(3, 3)
    False
    >>> R.neq(4, 3)
    True

    Data last:
    >>> R.neq(3)(2)
    True
    >>> R.neq(3)(3)
    False
    >>> R.neq(3)(5)
    True

    """
    return a != b
