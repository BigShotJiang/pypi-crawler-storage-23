from collections.abc import Callable, Iterable
from typing import TypeVar, overload

from .decorator import make_data_last

T = TypeVar('T')


@overload
def take_last(it: Iterable[T], n: int, /) -> list[T]: ...


@overload
def take_last(n: int, /) -> Callable[[Iterable[T]], list[T]]: ...


@make_data_last
def take_last(iterable: Iterable[T], n: int, /) -> list[T]:
    """
    Returns the list of the last n elements of the iterable.

    Parameters
    ----------
    iterable : Iterable[T]
        Input iterable (positional-only).
    n : int
        Number of elements to not yield (positional-only).

    Returns
    -------
    list[T]
        The last n elements of the iterable.

    Examples
    --------
    Data first:
    >>> R.take_last(range(5), 2)
    [3, 4]
    >>> R.take_last([2, 1, 3, 7, 6, 6, 6], 3)
    [6, 6, 6]

    Data last:
    >>> R.take_last(3)([2, 1, 3, 7, 6, 6, 6])
    [6, 6, 6]
    >>> R.take_last(2)(range(10))
    [8, 9]

    """
    list_ = list(iterable)
    return list_[-n:]
