from collections.abc import Callable
from typing import TypeVar, overload

from remedapy.decorator import make_data_last

K = TypeVar('K')
V = TypeVar('V')


@overload
def invert(tuples: dict[K, V], /) -> dict[V, K]: ...


@overload
def invert() -> Callable[[dict[K, V]], dict[V, K]]: ...


@make_data_last
def invert(
    data: dict[K, V],
    /,
) -> dict[V, K]:
    """
    Given a dict returns a dict with the original ones values as keys and keys as values.

    Alias to `{v: k for k, v in tuples.items()}`.

    Parameters
    ----------
    data: dict[K, V]
        Dict to invert.

    Returns
    -------
    result: dict[V, K]
        Dict with the original ones values as keys and keys as values.

    Examples
    --------
    Data first:
    >>> R.invert({'a': 'd', 'b': 'e', 'c': 'f'})
    {'d': 'a', 'e': 'b', 'f': 'c'}

    Data last:
    >>> R.invert()({'a': 'd', 'b': 'e', 'c': 'f'})
    {'d': 'a', 'e': 'b', 'f': 'c'}

    """
    return {v: k for k, v in data.items()}
