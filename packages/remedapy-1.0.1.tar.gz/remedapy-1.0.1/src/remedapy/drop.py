from collections.abc import Callable, Iterable
from typing import TypeVar, overload

from .decorator import make_data_last

T = TypeVar('T')


@overload
def drop(it: Iterable[T], n: int, /) -> Iterable[T]: ...


@overload
def drop(n: int, /) -> Callable[[Iterable[T]], Iterable[T]]: ...


@make_data_last
def drop(iterable: Iterable[T], n: int, /) -> Iterable[T]:
    """
    Yields the elements of the iterable skipping the first n elements.

    Parameters
    ----------
    iterable : Iterable[T]
        Input iterable (positional-only).
    n : int
        Number of elements to not yield (positional-only).

    Returns
    -------
    Iterable[T]
        Elements of the iterable skipping the first n elements.

    Examples
    --------
    Data first:
    >>> list(R.drop(range(5), 2))
    [2, 3, 4]
    >>> list(R.drop([2, 1, 3, 7, 6, 6, 6], 4))
    [6, 6, 6]

    Data last:
    >>> list(R.drop([2, 1, 3, 7, 6, 6, 6], 4))
    [6, 6, 6]
    >>> list(R.drop(range(10), 8))
    [8, 9]

    """
    for i, x in enumerate(iterable):
        if i < n:
            continue
        yield x
