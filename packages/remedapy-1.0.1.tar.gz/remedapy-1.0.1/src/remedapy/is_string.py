from collections.abc import Callable
from typing import Any, TypeGuard, TypeVar, overload

from remedapy.decorator import make_data_last

T = TypeVar('T')


@overload
def is_string() -> Callable[[Any], TypeGuard[str]]: ...


@overload
def is_string(value: Any, /) -> TypeGuard[str]: ...


@make_data_last
def is_string(value: Any, /) -> TypeGuard[str]:
    """
    A function that checks if the passed parameter is a string and narrows its type accordingly.

    Alias to `isinstance(value, str).`

    Parameters
    ----------
    value: Any
        Value to check.

    Returns
    -------
    result: bool
        Whether the value passed is a string.

    Examples
    --------
    Data first:
    >>> R.is_string('')
    True
    >>> R.is_string('1')
    True
    >>> R.is_string(1)
    False

    Data last:
    >>> R.is_string()("It's a sin")
    True
    >>> R.is_string()(1)
    False

    """
    return isinstance(value, str)
