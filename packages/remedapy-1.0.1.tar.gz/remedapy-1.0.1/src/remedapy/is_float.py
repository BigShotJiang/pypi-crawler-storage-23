from collections.abc import Callable
from typing import Any, TypeGuard, TypeVar, overload

from remedapy.decorator import make_data_last

T = TypeVar('T')


@overload
def is_float() -> Callable[[Any], TypeGuard[float]]: ...


@overload
def is_float(data: Any, /) -> TypeGuard[float]: ...


@make_data_last
def is_float(value: Any, /) -> TypeGuard[float]:
    """
    A function that checks if the passed parameter is a float and narrows its type accordingly.

    Alias to `isinstance(value, float)`.

    Parameters
    ----------
    value: Any
        Value to check.

    Returns
    -------
    result: TypeGuard[float]
        Whether the value passed is float.

    Examples
    --------
    Data first:
    >>> R.is_float(1.1)
    True
    >>> R.is_float(1)
    False

    Data last:
    >>> R.is_float()(1.1)
    True
    >>> R.is_float()(1)
    False

    """
    return isinstance(value, float)
