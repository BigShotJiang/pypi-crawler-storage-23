from collections.abc import Callable, Sized
from typing import Any, TypeGuard, TypeVar, overload

from remedapy.decorator import make_data_last

T = TypeVar('T')


@overload
def is_sized() -> Callable[[Any], TypeGuard[Sized]]: ...


@overload
def is_sized(data: Any, /) -> TypeGuard[Sized]: ...


@make_data_last
def is_sized(value: Any, /) -> TypeGuard[Sized]:
    """
    A function that checks if the passed parameter is Sized and narrows its type accordingly.

    Alias to `isinstance(value, Sized).` with `Sized` from `collections.abc`.

    Parameters
    ----------
    value: Any
        Value to check.

    Returns
    -------
    result: bool
        Whether the value passed is Sized.

    Examples
    --------
    Data first:
    >>> R.is_sized([1,2])
    True
    >>> R.is_sized(3)
    False

    Data last:
    >>> R.is_sized()([1,2])
    True
    >>> R.is_sized()(False)
    False

    """
    return isinstance(value, Sized)
