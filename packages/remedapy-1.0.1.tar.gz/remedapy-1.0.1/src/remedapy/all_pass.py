from collections.abc import Callable, Iterable
from typing import TypeVar, cast, overload

T = TypeVar('T')


@overload
def all_pass(data: T, fns: Iterable[Callable[[T], bool]], /) -> bool: ...


@overload
def all_pass(fns: Iterable[Callable[[T], bool]], /) -> Callable[[T], bool]: ...


def all_pass(
    data: T | Iterable[Callable[[T], bool]],
    predicates: Iterable[Callable[[T], bool]] | None = None,
    /,
) -> bool | Callable[[T], bool]:
    """
    Determines whether all predicates are true for the input data.

    Parameters
    ----------
    data : T
        Input data (positional-only).
    predicates : Iterable[Callable[[T], bool]]
        Predicates to check data against(positional-only).

    Returns
    -------
    bool
        Whether all predicates are true for the input data.

    Examples
    --------
    Data first:
    >>> R.all_pass(6, [R.is_divisible_by(3), R.is_divisible_by(2)])
    True
    >>> R.all_pass(6, [R.is_divisible_by(3), R.is_divisible_by(5)])
    False

    Data last:
    >>> R.all_pass([R.is_divisible_by(3), R.is_divisible_by(2)])(12)
    True
    >>> R.all_pass([R.is_divisible_by(3), R.is_divisible_by(2)])(15)
    False

    """
    if predicates is None:
        data = cast(Iterable[Callable[[T], bool]], data)
        return lambda value: all_pass(value, data)
    data = cast(T, data)
    for fn in predicates:
        if not fn(data):
            return False
    return True
