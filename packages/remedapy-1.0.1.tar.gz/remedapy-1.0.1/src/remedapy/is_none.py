from collections.abc import Callable
from typing import Any, TypeGuard, TypeVar, overload

from remedapy.decorator import make_data_last

T = TypeVar('T')


@overload
def is_none() -> Callable[[Any], TypeGuard[None]]: ...


@overload
def is_none(data: Any, /) -> TypeGuard[None]: ...


@make_data_last
def is_none(value: Any, /) -> TypeGuard[None]:
    """
    A function that checks if the passed parameter is None.

    Alias to `value is None`.

    Parameters
    ----------
    value: Any
        Value to check.

    Returns
    -------
    result: bool
        Whether the value passed is None.

    Examples
    --------
    Data first:
    >>> R.is_none(None)
    True
    >>> R.is_none(2.0)
    False
    >>> R.is_none(2)
    False

    Data last:
    >>> R.is_none()(None)
    True
    >>> R.is_none()(2)
    False

    """
    return value is None
