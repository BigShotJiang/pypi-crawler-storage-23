from collections.abc import Callable, Iterable
from typing import overload

from remedapy.decorator import make_data_last
from remedapy.identity import identity
from remedapy.mean_by import mean_by


@overload
def mean(iterable: Iterable[int | float], /) -> float: ...


@overload
def mean() -> Callable[[Iterable[int | float]], float]: ...


@make_data_last
def mean(iterable: Iterable[int | float], /) -> float:
    """
    Sums the iterable of numbers and divides the result by its length.

    Parameters
    ----------
    iterable : iterable
        Iterable to sum (positional-only).

    Returns
    -------
    float
        Mean of the iterable.

    Examples
    --------
    Data first:
    >>> R.mean([1, 2, 3])
    2.0
    >>> R.mean([])
    0

    Data last:
    >>> R.mean()([1, 2, 3])
    2.0
    >>> R.pipe([], R.mean)
    0

    """
    return mean_by(iterable, identity())
