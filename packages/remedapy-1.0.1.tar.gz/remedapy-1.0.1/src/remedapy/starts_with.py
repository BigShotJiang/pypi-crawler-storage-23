from collections.abc import Callable
from typing import overload

from remedapy.decorator import make_data_last


@overload
def starts_with(data: str, prefix: str, /) -> bool: ...


@overload
def starts_with(prefix: str, /) -> Callable[[str], bool]: ...


@make_data_last
def starts_with(string: str, prefix: str, /) -> bool:
    """
    Determines whether a string starts with the given prefix.

    Alias for string.startswith(prefix).

    Parameters
    ----------
    string : str
        Input string (positional-only).
    prefix : str
        Prefix to check (positional-only).

    Returns
    -------
    bool
        Whether the string starts with the given prefix.

    Examples
    --------
    Data first:
    >>> R.starts_with('hello world', 'hello')
    True
    >>> R.starts_with('hello world', 'world')
    False

    Data last:
    >>> R.pipe('hello world', R.starts_with('hello'))
    True
    >>> R.pipe('hello world', R.starts_with('world'))
    False

    """
    return string.startswith(prefix)
