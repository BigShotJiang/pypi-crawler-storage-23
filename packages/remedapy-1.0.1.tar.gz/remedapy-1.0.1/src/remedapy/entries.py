from collections.abc import Callable, Iterable
from typing import TypeVar, overload

from remedapy.decorator import make_data_last

K = TypeVar('K')
V = TypeVar('V')


@overload
def entries(object: dict[K, V], /) -> Iterable[tuple[K, V]]: ...


@overload
def entries() -> Callable[[dict[K, V]], Iterable[tuple[K, V]]]: ...


@make_data_last
def entries(
    data: dict[K, V],
    /,
) -> Iterable[tuple[K, V]]:
    """
    Given a dict yields tuples of key-value pairs.

    Parameters
    ----------
    data: dict[K, V]
        The dict to yield key-value pairs from.

    Returns
    -------
    Iterable[tuple[K, V]]
        Key-value pairs from the dict (positional-only).

    Examples
    --------
    Data first:
    >>> list(R.entries({'a': 1, 'b': 2, 'c': 3}))
    [('a', 1), ('b', 2), ('c', 3)]

    Data last:
    >>> R.pipe({'a': 1, 'b': 2, 'c': 3}, R.entries(), list)
    [('a', 1), ('b', 2), ('c', 3)]

    """
    yield from data.items()
