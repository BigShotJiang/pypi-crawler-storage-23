from collections.abc import Callable
from typing import TypeVar, overload

from .decorator import make_data_last

T = TypeVar('T')


@overload
def is_even(it: int | float, /) -> bool: ...


@overload
def is_even() -> Callable[[int | float], bool]: ...


@make_data_last
def is_even(value: int | float, /) -> bool:
    """
    A function that checks if the passed parameter is an even number.

    Alias to `value % 2 == 0`.

    Parameters
    ----------
    value: Any
        Value to check.

    Returns
    -------
    result: bool
        Whether the value passed is even.

    Examples
    --------
    Data first:
    >>> R.is_even(1)
    False
    >>> R.is_even(2.0)
    True
    >>> R.is_even(2)
    True

    Data last:
    >>> R.is_even()(1)
    False
    >>> R.is_even()(2)
    True

    """
    return value % 2 == 0
