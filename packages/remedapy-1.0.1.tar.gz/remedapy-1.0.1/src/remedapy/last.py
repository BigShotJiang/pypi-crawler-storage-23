from collections.abc import Callable, Iterable
from typing import TypeVar, overload

from remedapy.decorator import make_data_last

T = TypeVar('T')


@overload
def last() -> Callable[[Iterable[T]], T | None]: ...


@overload
def last(iterable: Iterable[T], /) -> T | None: ...


@make_data_last
def last(iterable: Iterable[T], /) -> T | None:
    """
    Returns the last element of the iterable.

    If the iterable is empty, returns `None`.

    Parameters
    ----------
    iterable : Iterable[T]
        Input iterable (positional-only).

    Returns
    -------
    T | None
        Last element of the iterable or `None` if the iterable is empty.

    Examples
    --------
    Data first:
    >>> R.last([1, 2, 3])
    3

    Data last:
    >>> R.pipe([1, 2, 4, 8, 16], R.filter(R.gt(3)), R.last(), R.default_to(0), R.add(1))
    17

    """
    x = None
    for i in iterable:
        x = i
    return x
