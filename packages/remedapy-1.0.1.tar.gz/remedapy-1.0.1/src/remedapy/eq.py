from collections.abc import Callable
from typing import Any, TypeVar, overload

from remedapy.decorator import make_data_last

T = TypeVar('T')


@overload
def eq(addend: int | float, /) -> Callable[[int | float], bool]: ...


@overload
def eq(addend: T, /) -> Callable[[T], bool]: ...


@overload
def eq(value: int | float, addend: int | float, /) -> bool: ...


@overload
def eq(value: T, addend: T, /) -> bool: ...


@make_data_last
def eq(
    a: Any,
    b: Any,
    /,
) -> Any:
    """
    Compares two values and returns True if the first is equal to the second.

    Alias for `operator.eq` (==) - `__eq__` magic method.

    Parameters
    ----------
    a : int | float | T
        First thing (positional-only).
    b : int | float | T
        Second thing (positional-only).

    Returns
    -------
    bool
        True if a is equal to b, False otherwise.

    Examples
    --------
    Data first:
    >>> R.eq(2, 3)
    False
    >>> R.eq(3, 3)
    True
    >>> R.eq(4, 3)
    False

    Data last:
    >>> R.eq(3)(2)
    False
    >>> R.eq(3)(3)
    True
    >>> R.eq(3)(5)
    False

    """
    return a == b
