from collections.abc import Callable, Iterable
from typing import TypeVar, overload

from remedapy.decorator import make_data_last

real_sum = sum
T = TypeVar('T')
U = TypeVar('U')
TNum = TypeVar('TNum', int, float)


@overload
def sum(data: Iterable[TNum], /) -> TNum: ...


@overload
def sum() -> Callable[[Iterable[TNum]], TNum]: ...


@make_data_last
def sum(iterable: Iterable[TNum], /) -> TNum:
    """
    Sums the iterable of numbers.

    Alias for built-in sum function.

    Parameters
    ----------
    iterable : iterable
        Iterable to sum (positional-only).

    Returns
    -------
    int | float
        Sum of the iterable.

    Examples
    --------
    Data first:
    >>> R.sum([1, 2, 3])
    6

    Data last:
    >>> R.sum()([1, 2, 3])
    6
    >>> R.pipe([1, 2, 3], R.sum)
    6

    """
    return real_sum(iterable)  # pyright: ignore[reportReturnType]
