import random
import string
from collections.abc import Callable
from typing import overload

from remedapy.decorator import make_data_last


@overload
def random_string(length: int, /) -> str: ...


@overload
def random_string() -> Callable[[int], str]: ...


@make_data_last
def random_string(length: int, /) -> str:
    """
    Returns a random string of ascii letters and digits of the given length.

    Parameters
    ----------
    length: int
        Desired string length(positional-only).

    Returns
    -------
    str
        Random string of ascii letters and digits of the given length.

    Examples
    --------
    Data first:
    >>> import random; random.seed(0)
    >>> R.random_string(8)
    '0UAqFzWs'

    Data last:
    >>> R.random_string()(5)
    'DK4Fr'

    """
    characters = string.ascii_letters + string.digits
    return ''.join(random.choices(characters, k=length))
