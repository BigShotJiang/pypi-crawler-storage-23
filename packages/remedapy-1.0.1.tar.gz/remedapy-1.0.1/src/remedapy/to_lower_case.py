from collections.abc import Callable
from typing import overload

from remedapy.decorator import make_data_last


@overload
def to_lower_case(s: str, /) -> str: ...


@overload
def to_lower_case() -> Callable[[str], str]: ...


@make_data_last
def to_lower_case(s: str, /) -> str:
    """
    Makes the string lowercase.

    Parameters
    ----------
    s : str
        String to lowercase (positional-only).

    Returns
    -------
    str
        Lower cased string.

    Examples
    --------
    Data first:
    >>> R.to_lower_case('Hello World')
    'hello world'

    Data last:
    >>> R.to_lower_case()('Hello WORLD')
    'hello world'

    """
    return s.lower()
