import remedapy as R


class TestSortedLastIndexBy:
    def test_data_first(self):
        # R.sorted_last_index_by(data, item, valueFunction)
        assert R.sorted_last_index_by([{'age': 20}, {'age': 22}], {'age': 21}, R.prop('age')) == 1  # pyright: ignore[reportArgumentType]
        assert R.sorted_last_index_by([{'age': 20}, {'age': 21}], {'age': 21}, R.prop('age')) == 2  # pyright: ignore[reportArgumentType]

    def test_data_last(self):
        # R.sorted_last_index_by(item, valueFunction)(data)
        assert R.pipe([{'age': 20}, {'age': 22}], R.sorted_last_index_by({'age': 21}, R.prop('age'))) == 1  # pyright: ignore[reportArgumentType]
