import remedapy as R


class TestSortedLastIndex:
    def test_data_first(self):
        # R.sorted_last_index(data, item)
        assert R.sorted_last_index(['a', 'a', 'b', 'c', 'c'], 'c') == 5
        assert R.sorted_last_index(['a', 'a', 'b', 'c', 'c', 'd'], 'c') == 5

    def test_data_last(self):
        # R.sorted_last_index(item)(data)
        assert R.pipe(['a', 'a', 'b', 'c', 'c'], R.sorted_last_index('c')) == 5
