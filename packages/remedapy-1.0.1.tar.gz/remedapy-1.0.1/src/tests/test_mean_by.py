import remedapy as R


class TestMeanBy:
    def test_data_first(self):
        # R.mean_by(array, fn)
        assert (
            R.mean_by(
                [{'a': 5}, {'a': 1}, {'a': 3}],
                R.prop('a'),  # pyright: ignore[reportArgumentType]
            )
            == 3
        )

    def test_data_last(self):
        # R.mean_by(fn)(array)
        assert (
            R.pipe(
                [{'a': 5}, {'a': 1}, {'a': 3}],
                R.mean_by(R.prop('a')),  # pyright: ignore[reportArgumentType]
            )
            == 3
        )
