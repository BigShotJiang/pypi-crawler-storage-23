import remedapy as R


class TestSplit:
    def test_data_first(self):
        # R.split(data, separator, limit);
        assert R.split('a,b,c', ',') == ['a', 'b', 'c']
        assert R.split('a,b,c', ',', limit=2) == ['a', 'b', 'c']
        assert R.split('a,b,c', ',', limit=1) == ['a', 'b,c']
        assert R.split('a,,b,,c', ',,', limit=1) == ['a', 'b,,c']
        assert R.split('a1b2c3d', r'\d') == ['a', 'b', 'c', 'd']
        assert R.split('a1b2c3d', r'[0-9]') == ['a', 'b', 'c', 'd']

    def test_data_last(self):
        # R.split(separator, limit)(data);
        assert R.pipe('a,b,c', R.split(',')) == ['a', 'b', 'c']
        assert R.pipe('a,b,c', R.split(',', limit=2)) == ['a', 'b', 'c']
        assert R.pipe('a,b,c', R.split(',', limit=1)) == ['a', 'b,c']
        assert R.pipe('a1b2c3d', R.split(r'\d')) == ['a', 'b', 'c', 'd']
        assert R.pipe('a1b2c3d', R.split(r'[0-9]')) == ['a', 'b', 'c', 'd']
