import remedapy as R


class TestCountBy:
    def test_data_first(self):
        # R.count_by(data, categorizationFn)
        assert R.count_by(['a', 'b', 'c', 'B', 'A', 'a'], R.to_lower_case()) == {'a': 3, 'b': 2, 'c': 1}

    def test_data_last(self):
        # R.count_by(categorizationFn)(data)
        assert R.pipe(
            ['a', 'b', 'c', 'B', 'A', 'a'],
            R.count_by(R.to_lower_case()),
        ) == {'a': 3, 'b': 2, 'c': 1}
