import remedapy as R


class TestKeys:
    def test_data_first(self):
        # R.keys(source)
        keys = R.keys({'a': 'x', 'b': 'y', '5': 'z'})
        assert list(keys) == ['a', 'b', '5']
        # TODO: should typecheck
        # assert list(R.keys({'a': 'x', 'b': 'y', '5': 'z'})) == ['a', 'b', '5']

    def test_data_last(self):
        # R.keys()(source)
        result = R.pipe({'a': 'x', 'b': 'y', '5': 'z'}, R.keys(), list)
        assert result == ['a', 'b', '5']
