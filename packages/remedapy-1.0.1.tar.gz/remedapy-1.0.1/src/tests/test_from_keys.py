import remedapy as R


class TestFromKeys:
    def test_data_first(self):
        # R.from_keys(data, mapper);
        assert R.from_keys(['cat', 'dog'], R.length()) == {'cat': 3, 'dog': 3}
        assert R.from_keys([1, 2], R.add(1)) == {1: 2, 2: 3}
        assert R.from_keys(['cat', 'dog'], R.constant('uwu')) == {'cat': 'uwu', 'dog': 'uwu'}

    def test_data_last(self):
        # R.from_keys(mapper)(data);
        assert R.pipe(['cat', 'dog'], R.from_keys(R.length())) == {'cat': 3, 'dog': 3}
        assert R.pipe([1, 2], R.from_keys(R.add(1))) == {1: 2, 2: 3}
