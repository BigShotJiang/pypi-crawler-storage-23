import remedapy as R


class TestFirstBy:
    def test_data_first(self):
        # R.first_by(data, ...rules);
        assert R.first_by([1, 2, 3], R.identity()) == 1
        data = [{'a': 'a'}, {'a': 'aa'}, {'a': 'aaa'}]
        assert R.first_by(data, R.piped(R.prop('a'), R.default_to(''), R.length)) == {'a': 'a'}

    def test_data_last(self):
        # R.first_by(...rules)(data);
        assert R.pipe([1, 2, 3], R.first_by(R.identity())) == 1
        data = [{'a': 'aa'}, {'a': 'a'}, {'a': 'aaa'}]
        assert R.pipe(data, R.first_by(R.piped(R.prop('a'), R.default_to(''), R.length))) == {'a': 'a'}
