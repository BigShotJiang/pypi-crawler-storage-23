import remedapy as R


class TestPickBy:
    def test_data_first(self):
        # R.pick_by(data, predicate)
        def predicate2(v: int, k: str) -> bool:
            return k == k.upper()

        assert R.pick_by({'a': 1, 'b': 2, 'A': 3, 'B': 4}, predicate2) == {'A': 3, 'B': 4}
        assert R.pick_by({'a': 1, 'b': 2, 'A': 3, 'B': 4}, R.gt(2)) == {'A': 3, 'B': 4}
        assert R.pick_by({'a': 1, 'b': 2, 'A': 3, 'B': 4}, R.constant(False)) == {}
        assert R.pick_by({'a': 1, 'b': 2, 'A': 3, 'B': 4}, R.constant(True)) == {'a': 1, 'b': 2, 'A': 3, 'B': 4}

    def test_data_last(self):
        # R.pick_by(predicate)(data)
        def predicate2(v: int, k: str) -> bool:
            return k == k.upper()

        assert R.pipe({'a': 1, 'b': 2, 'A': 3, 'B': 4}, R.pick_by(predicate2)) == {'A': 3, 'B': 4}
