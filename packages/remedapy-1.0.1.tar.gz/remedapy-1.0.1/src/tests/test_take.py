import remedapy as R


class TestTake:
    def test_data_first(self):
        # R.take(array, n);
        assert list(R.take([1, 2, 3, 4, 3, 2, 1], 3)) == [1, 2, 3]
        assert list(R.take(range(100), 0)) == []

    def test_data_last(self):
        # R.take(n)(array);
        assert R.pipe([1, 2, 3, 4, 3, 2, 1], R.take(3), list) == [1, 2, 3]
