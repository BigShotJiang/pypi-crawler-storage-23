import remedapy as R


class TestGroupByProp:
    def test_data_first(self):
        # R.group_by_prop(data, prop)
        assert R.group_by_prop(
            [{'a': 'cat'}, {'a': 'dog'}],
            'a',
        ) == {'cat': [{'a': 'cat'}], 'dog': [{'a': 'dog'}]}

    def test_data_last(self):
        # R.group_by_prop(prop)(data);
        assert R.pipe(
            [{'a': 'cat'}, {'a': 'dog'}],
            R.group_by_prop('a'),
        ) == {'cat': [{'a': 'cat'}], 'dog': [{'a': 'dog'}]}
