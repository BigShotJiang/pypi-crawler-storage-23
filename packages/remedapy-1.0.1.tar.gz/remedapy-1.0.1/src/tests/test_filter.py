from collections.abc import Iterable
from typing import Any, TypeGuard

import remedapy as R


class TestFilter:
    def test_data_first(self):
        # R.filter(data, predicate);

        assert list(R.filter([1, 2, 3], lambda x: x % 2 == 1)) == [1, 3]
        x: Iterable[int] = R.filter([1, 2, 3], R.gt(2))
        assert list(x) == [3]

    def test_data_last(self):
        # R.filter(callbackfn)(data);
        assert R.pipe([1, 2, 3], R.filter(R.is_odd), list) == [1, 3]

    def test_more_params(self):
        assert list(R.filter([1, 2, 3], lambda _, i: i % 2 == 1)) == [2]
        assert list(R.filter([1, 2, 4, 5], lambda x, _, z: x + 1 in z)) == [1, 4]

    def test_typing(self):
        a: list[int | bool | str] = [1, True, '']

        def t(x: Any) -> TypeGuard[bool]:
            return isinstance(x, bool)

        _: list[bool] = list(R.filter(a, t))
        _: list[bool] = list(R.filter(a, R.is_bool))
        _: list[bool] = [y for y in a if t(y)]
        _: list[bool] = [y for y in a if R.is_bool(y)]
        _: list[bool] = list(filter(R.is_bool, a))
        _: list[bool] = list(filter(R.is_bool, a))
