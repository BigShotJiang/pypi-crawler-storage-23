import remedapy as R


class TestIsString:
    def test_data_first(self):
        # R.is_string(data);
        assert R.is_sized([])
        assert R.is_sized(range(10))
        assert not R.is_sized(0)
        assert not R.is_sized(x for x in range(10))

    def test_data_last(self):
        # R.is_string()(data);
        assert R.is_sized([])
        assert not R.is_sized(0)
