from collections.abc import Callable

import remedapy as R


class TestGt:
    def test_data_first(self):
        # R.gt(value, addend);
        assert R.gt(10, 5)
        assert not R.gt(10, 11)

    def test_data_last(self):
        # R.gt(addend)(value);
        assert R.gt(5)(10)
        assert not R.gt(11)(10)
        assert list(R.map([1, 2, 3, 4], R.gt(2))) == [False, False, True, True]
        fn: Callable[[int | float], bool] = R.gt(2)
        assert fn(3)
