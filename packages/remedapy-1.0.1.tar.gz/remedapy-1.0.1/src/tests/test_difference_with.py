import remedapy as R


class TestDifferenceWith:
    def test_data_first(self):
        # R.difference_with(data, other, isEqual);
        assert list(
            R.difference_with([{'a': 1}, {'a': 2}, {'a': 3}, {'a': 4}], [2, 5, 3], lambda d, x: d['a'] == x),
        ) == [{'a': 1}, {'a': 4}]

    def test_data_last(self):
        # R.difference_with(other, isEqual)(data);
        def cmp(d: dict[str, int], x: int) -> bool:
            return d['a'] == x

        assert R.pipe(
            [{'a': 1}, {'a': 2}, {'a': 3}, {'a': 4}, {'a': 5}, {'a': 6}],
            R.difference_with([2, 3], cmp),
            list,
        ) == [{'a': 1}, {'a': 4}, {'a': 5}, {'a': 6}]
