import remedapy as R


class TestIsString:
    def test_data_first(self):
        # R.is_string(data);
        assert R.is_superset({1, 2, 3}, {1, 2})
        assert R.is_superset({1, 2, 3}, {1, 2, 3})
        assert not R.is_superset({1, 2}, {1, 4})
        assert R.is_superset({'a': 3, 'b': 5}, {'a': 3})
        assert R.is_superset({'a': 3}, {'a': 3})
        assert not R.is_superset(
            {'a': 3, 'b': 5},
            {'a': 4},
        )

    def test_data_last(self):
        # R.is_string()(data);
        assert R.is_superset({1, 2})({1, 2, 3})
        assert not R.is_superset({1, 2})({1, 4})
