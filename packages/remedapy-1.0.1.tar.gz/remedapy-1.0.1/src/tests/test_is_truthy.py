import remedapy as R


class TestIsString:
    def test_data_first(self):
        # R.is_string(data);
        assert R.is_truthy('a')
        assert not R.is_truthy(0)
        assert R.is_truthy(3)
        assert R.is_truthy('asd')
        assert R.is_truthy([4])
        assert not R.is_truthy(0)
        assert not R.is_truthy(0.0)
        assert not R.is_truthy('')
        assert not R.is_truthy(None)
        assert not R.is_truthy(False)
        assert not R.is_truthy([])
        assert not R.is_truthy({})
        assert not R.is_truthy(set())
        assert not R.is_truthy(())
        assert not R.is_truthy(range(0))

    def test_data_last(self):
        # R.is_string()(data);
        assert R.is_truthy()('a')
        assert not R.is_truthy()(0)
