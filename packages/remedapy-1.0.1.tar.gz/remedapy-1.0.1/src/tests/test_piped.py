import remedapy as R


class TestPiped:
    def test_data_last(self):
        # R.piped(...functions)(data);
        assert list(R.map([{'a': 1}, {'a': 2}, {'a': 3}], R.piped(R.prop('a'), R.default_to(0), R.add(1)))) == [2, 3, 4]
