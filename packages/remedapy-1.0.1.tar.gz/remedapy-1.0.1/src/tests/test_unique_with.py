import remedapy as R


class TestUniqueWith:
    def test_data_first(self):
        # R.unique_with(array, isEquals)
        assert list(
            R.unique_with(
                [{'a': 1}, {'a': 2}, {'a': 2}, {'a': 5}, {'a': 1}, {'a': 6}, {'a': 7}],
                lambda x, y: x == y,
            ),
        ) == [{'a': 1}, {'a': 2}, {'a': 5}, {'a': 6}, {'a': 7}]
        assert list(
            R.unique_with(
                [{'a': 1}, {'a': 2}, {'a': 2}, {'a': 5}, {'a': 1}, {'a': 6}, {'a': 7}],
                lambda x, y: x['a'] % 2 == y['a'] % 2,
            ),
        ) == [{'a': 1}, {'a': 2}]
        assert list(
            R.unique_with(
                [{'a': 1}, {'a': 2}, {'a': 2}, {'a': 5}, {'a': 1}, {'a': 6}, {'a': 7}],
                lambda x, y: x['a'] % 3 == y['a'] % 3,
            ),
        ) == [{'a': 1}, {'a': 2}, {'a': 6}]

    def test_data_last(self):
        # R.unique_with(isEquals)(array)
        def eq_(x: dict[str, int], y: dict[str, int]) -> bool:
            return x == y

        assert list(
            R.unique_with(eq_)(
                [{'a': 1}, {'a': 2}, {'a': 2}, {'a': 5}, {'a': 1}, {'a': 6}, {'a': 7}],
            ),
        ) == [{'a': 1}, {'a': 2}, {'a': 5}, {'a': 6}, {'a': 7}]
        assert R.pipe(
            [{'a': 1}, {'a': 2}, {'a': 2}, {'a': 5}, {'a': 1}, {'a': 6}, {'a': 7}],
            R.unique_with(eq_),
            R.take(3),
            list,
        ) == [{'a': 1}, {'a': 2}, {'a': 5}]
