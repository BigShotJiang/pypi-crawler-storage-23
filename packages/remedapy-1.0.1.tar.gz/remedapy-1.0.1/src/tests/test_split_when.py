from collections.abc import Sequence

import remedapy as R


class TestSplitWhen:
    def test_data_first(self):
        # R.split_when(array, fn)
        assert R.split_when([1, 2, 3], R.eq(2)) == ([1], [2, 3])

        def predicate2(x: int, i: int) -> bool:
            return x % 2 == 0 and i > 1

        assert R.split_when([1, 2, 3, 4], predicate2) == ([1, 2, 3], [4])

        def predicate3(x: int, i: int, arr: Sequence[int]) -> bool:
            return x % 2 == 0 and i > 1

        assert R.split_when([1, 2, 3, 4], predicate3) == ([1, 2, 3], [4])

    def test_data_last(self):
        # R.split_when(fn)(array)
        assert R.split_when(R.eq(2))([1, 2, 3]) == ([1], [2, 3])
