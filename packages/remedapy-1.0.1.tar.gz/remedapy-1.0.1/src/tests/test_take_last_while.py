import remedapy as R


class TestTakeLastWhile:
    def test_data_first(self):
        # R.take_last_while(data, predicate)
        assert R.take_last_while([1, 2, 10, 3, 4, 5], R.lt(10)) == [3, 4, 5]

    def test_data_last(self):
        # R.take_last_while(predicate)(data)
        assert R.pipe([1, 2, 10, 3, 4, 5], R.take_last_while(R.lt(10))) == [3, 4, 5]
