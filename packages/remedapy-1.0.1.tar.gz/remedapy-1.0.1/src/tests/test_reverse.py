import remedapy as R


class TestReverse:
    def test_data_first(self):
        # R.reverse(arr);
        assert list(R.reverse([1, 2, 3])) == [3, 2, 1]

    def test_data_last(self):
        # R.reverse()(array);
        assert list(R.reverse()(range(1, 4))) == [3, 2, 1]
