import remedapy as R


class TestIsInt:
    def test_data_first(self):
        # R.is_string(data);
        assert R.is_int(1)
        assert not R.is_int(1.1)

    def test_data_last(self):
        # R.is_string()(data);
        assert R.is_int()(1)
        assert not R.is_string()(1)
