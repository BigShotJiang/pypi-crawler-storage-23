import remedapy as R


class TestDropFirstBy:
    def test_data_first(self):
        # R.drop_first_by(data, n, fn);
        # assert list(R.drop_first_by(['aa', 'aaaa', 'a', 'aaa'], 2, R.length)) == ['aaaa', 'aaa']
        assert list(R.drop_first_by(['aa', 'aaaa', 'a', 'aaa'], 0, R.length)) == ['aa', 'aaaa', 'a', 'aaa']

    def test_data_last(self):
        # R.drop_first_by(n, fn)(data);
        assert R.pipe(['aa', 'aaaa', 'a', 'aaa'], R.drop_first_by(2, R.length), list) == ['aaaa', 'aaa']
