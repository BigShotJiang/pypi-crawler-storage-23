import remedapy as R


class TestConcat:
    def test_data_first(self):
        # R.concat(data, other);
        assert list(R.concat([1, 2, 3], ['a'])) == [1, 2, 3, 'a']

    def test_data_last(self):
        # R.concat(arr2)(arr1);
        assert list(R.concat(['a'])([1, 2, 3])) == [1, 2, 3, 'a']
