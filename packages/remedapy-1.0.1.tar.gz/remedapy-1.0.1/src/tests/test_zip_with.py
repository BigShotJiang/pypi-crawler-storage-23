import remedapy as R


class TestZipWith:
    def test_data_first(self):
        # R.zip_with(first, second, fn)
        assert list(R.zip_with(['1', '2', '3'], ['a', 'b', 'c'], R.add)) == ['1a', '2b', '3c']

    def test_data_last(self):
        # R.zip_with(second, fn)(first)
        assert R.pipe(['1', '2', '3'], R.zip_with(['a', 'b', 'c'], R.add), list) == ['1a', '2b', '3c']

    def test_fn_first(self):
        # R.zip_with(fn)(first, second)
        def concat_str(a: str, b: str) -> str:
            return a + b

        assert list(R.zip_with(concat_str)(['1', '2', '3'], ['a', 'b'])) == ['1a', '2b']
