import remedapy as R


class TestToSnakeCase:
    def test_data_first(self):
        # R.to_snake_case(data);
        assert R.to_snake_case('hello world') == 'hello_world'
        assert R.to_snake_case('__HELLO_WORLD__') == 'hello_world'

    def test_data_last(self):
        # R.to_snake_case()(data);
        assert R.pipe('hello world', R.to_snake_case()) == 'hello_world'
        assert R.pipe('__HELLO_WORLD__', R.to_snake_case()) == 'hello_world'
