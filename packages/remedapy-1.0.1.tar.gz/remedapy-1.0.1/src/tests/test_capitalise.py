import remedapy as R


class TestCapitalise:
    def test_data_first(self):
        # R.capitalise(data);
        assert R.capitalise('hello world') == 'Hello world'
        assert R.uncapitalise('') == ''

    def test_data_last(self):
        # R.capitalise()(data);
        assert R.pipe('hello world', R.capitalise()) == 'Hello world'
        assert R.pipe('', R.capitalise()) == ''
