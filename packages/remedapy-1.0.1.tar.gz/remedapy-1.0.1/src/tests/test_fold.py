import remedapy as R


class TestFold:
    def test_data_first(self):
        # R.fold(data, callbackfn, initialValue);
        assert R.fold([1, 2, 3, 4, 5], lambda a, x: a + x, 100) == 115

    def test_data_last(self):
        # R.fold(callbackfn, initialValue)(data);
        assert R.fold(R.add, 100)([1, 2, 3, 4, 5]) == 115
        assert R.pipe([1, 2, 3, 4, 5], R.fold(R.add, 100)) == 115
