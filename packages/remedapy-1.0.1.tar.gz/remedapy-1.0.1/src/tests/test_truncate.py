import remedapy as R


class TestTruncate:
    def test_data_first(self):
        # R.truncate(data, n, { omission, separator });
        assert R.truncate('Hello, world!', 8) == 'Hello...'
        assert R.truncate('Hello, world!', 20) == 'Hello, world!'
        assert R.truncate('Hello, world!', 5, omission='') == 'Hello'
        assert (
            R.truncate(
                'cat, dog, mouse',
                12,
                omission='__',
                separator=',',
            )
            == 'cat, dog__'
        )
        assert (
            R.truncate(
                'cat, dog, mouse',
                12,
                omission='__',
                separator='-',
            )
            == 'cat, dog, __'
        )

    def test_data_last(self):
        # R.truncate(n, { omission, separator })(data);
        assert R.pipe('Hello, world!', R.truncate(8)) == 'Hello...'
        assert (
            R.pipe(
                'cat, dog, mouse',
                R.truncate(12, omission='__', separator=','),
            )
            == 'cat, dog__'
        )
