import remedapy as R


class TestMerge:
    def test_data_first(self):
        # R.merge(data, source)
        assert R.merge({'x': 1, 'y': 2}, {'y': 10, 'z': 2}) == {'x': 1, 'y': 10, 'z': 2}
        assert R.merge({'x': 1, 'y': {'a': 3}}, {'y': {'b': 3}, 'z': 2}) == {'x': 1, 'y': {'b': 3}, 'z': 2}

    def test_data_last(self):
        # R.merge(source)(data)
        assert R.pipe(
            {'x': 1, 'y': 2},
            R.merge({'y': 10, 'z': 2}),
        ) == {'x': 1, 'y': 10, 'z': 2}
