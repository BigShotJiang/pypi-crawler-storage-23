import remedapy as R


class TestDrop:
    def test_data_first(self):
        # R.drop(array, n)
        assert list(R.drop([1, 2, 3, 4, 5], 2)) == [3, 4, 5]

    def test_data_last(self):
        # R.drop(n)(array)
        assert list(R.drop(2)([1, 2, 3, 4, 5])) == [3, 4, 5]
