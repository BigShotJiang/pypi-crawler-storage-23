import remedapy as R


class TestRankBy:
    def test_data_first(self):
        # R.rank_by(data, item, ...rules)
        DATA = [{'a': 5}, {'a': 1}, {'a': 3}]
        assert R.rank_by(DATA, 0, R.prop('a')) == 0  # pyright: ignore[reportArgumentType]
        assert R.rank_by(DATA, 1, R.prop('a')) == 1  # pyright: ignore[reportArgumentType]
        assert R.rank_by(DATA, 2, R.prop('a')) == 1  # pyright: ignore[reportArgumentType]
        assert R.rank_by(DATA, 3, R.prop('a')) == 2  # pyright: ignore[reportArgumentType]

    def test_data_last(self):
        # R.rank_by(item, ...rules)(data)
        DATA = [{'a': 5}, {'a': 1}, {'a': 3}]
        assert R.pipe(DATA, R.rank_by(0, R.prop('a'))) == 0  # pyright: ignore[reportArgumentType]
        assert R.pipe(DATA, R.rank_by(1, R.prop('a'))) == 1  # pyright: ignore[reportArgumentType]
        assert R.pipe(DATA, R.rank_by(2, R.prop('a'))) == 1  # pyright: ignore[reportArgumentType]
        assert R.pipe(DATA, R.rank_by(3, R.prop('a'))) == 2  # pyright: ignore[reportArgumentType]
