import remedapy as R


class TestSample:
    def test_data_first(self):
        # R.sample(array, sampleSize)
        s1 = R.sample(['hello', 'world'], 1)
        assert len(s1) == 1
        assert s1[0] in {'hello', 'world'}

    def test_data_last(self):
        # R.sample(sampleSize)(array)
        s1 = R.pipe(['hello', 'world'], R.sample(1))
        assert len(s1) == 1
        assert s1[0] in {'hello', 'world'}
