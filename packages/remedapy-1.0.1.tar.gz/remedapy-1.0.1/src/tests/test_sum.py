import remedapy as R


class TestSum:
    def test_data_first(self):
        # R.sum(data);
        x: int = R.sum([1, 2, 3])
        assert x == 6
        y: float = R.sum([1, 2, 3.5])
        assert y == 6.5
        assert R.sum([]) == 0

    def test_data_last(self):
        # R.sum()(data);
        assert R.pipe([1, 2, 3], R.sum()) == 6
        x: list[int] = []
        assert R.pipe(x, R.sum()) == 0
