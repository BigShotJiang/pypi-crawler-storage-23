import remedapy as R


class TestMapWithFeedback:
    def test_data_first(self):
        # R.map_with_feedback(data, callbackfn, initialValue);
        assert list(
            R.map_with_feedback(
                [1, 2, 3, 4, 5],
                lambda prev, x: prev + x,
                100,
            ),
        ) == [101, 103, 106, 110, 115]

    def test_data_last(self):
        # R.map_with_feedback(callbackfn, initialValue)(data);
        assert R.pipe([1, 2, 3, 4, 5], R.map_with_feedback(R.add, 100), list) == [101, 103, 106, 110, 115]
