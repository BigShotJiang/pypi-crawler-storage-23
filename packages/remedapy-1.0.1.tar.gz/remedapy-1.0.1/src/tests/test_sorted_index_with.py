import remedapy as R


class TestSortedIndexWith:
    def test_data_first(self):
        # R.sorted_index_with(data, predicate)
        assert R.sorted_index_with(['a', 'ab', 'abc'], R.piped(R.length, R.lt(2))) == 1
        assert R.sorted_index_with(['a', 'ab', 'abc'], R.piped(R.length, R.lt(5))) == 3
        assert R.sorted_index_with(['a', 'ab', 'abc'], R.piped(R.length, R.gt(0))) == 3
        assert R.sorted_index_with(['a', 'ab', 'abc'], R.piped(R.length, R.lt(0))) == 0

    def test_data_last(self):
        # R.sorted_index_with(predicate)(data)
        assert R.pipe(['a', 'ab', 'abc'], R.sorted_index_with(R.piped(R.length, R.lt(2)))) == 1
