import remedapy as R


class TestFromEntries:
    def test_data_first(self):
        # R.from_entries(tuples)
        assert R.from_entries([('a', 'b'), ('c', 'd')]) == {'a': 'b', 'c': 'd'}

    def test_data_last(self):
        # R.from_entries()(tuples)
        assert R.pipe(
            [('a', 'b'), ('c', 'd')],
            R.from_entries(),
        ) == {'a': 'b', 'c': 'd'}
