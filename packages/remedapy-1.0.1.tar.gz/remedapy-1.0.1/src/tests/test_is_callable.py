import remedapy as R


class TestIsString:
    def test_data_first(self):
        # R.is_string(data);
        assert R.is_callable(lambda x: x + 1)  # pyright: ignore[reportUnknownLambdaType]
        assert R.is_callable(R.is_callable)

    def test_data_last(self):
        # R.is_string()(data);
        assert R.is_callable()(lambda x: x + 1)  # pyright: ignore[reportUnknownLambdaType]
