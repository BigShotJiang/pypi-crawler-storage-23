import remedapy as R


class TestNegate:
    def test_data_first(self):
        # R.invert(object)
        x: list[int] = []
        assert R.negate(x, R.is_truthy)
        assert not R.negate([1, 2, 3], R.is_truthy)
        assert R.negate(False)
        assert not R.negate(True)

    def test_data_last(self):
        # R.invert()(object)
        x: list[int] = []
        assert R.negate(R.is_truthy)(x)
        assert not R.negate(R.is_truthy)([1, 2, 3])
        assert R.negate()(False)
        assert not R.negate()(True)
