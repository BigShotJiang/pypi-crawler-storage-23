import remedapy as R


class TestToUpperCase:
    def test_data_first(self):
        # R.to_upper_case(data);
        assert R.to_upper_case('Hello World') == 'HELLO WORLD'

    def test_data_last(self):
        # R.to_upper_case()(data);
        assert R.pipe('Hello World', R.to_upper_case()) == 'HELLO WORLD'
