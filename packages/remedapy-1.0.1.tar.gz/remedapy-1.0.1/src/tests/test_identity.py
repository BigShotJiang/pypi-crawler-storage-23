import remedapy as R


class TestIdentity:
    def test_data_last(self):
        # R.identity();
        assert R.pipe([1, 2, 3], R.map(R.identity()), list) == [1, 2, 3]
