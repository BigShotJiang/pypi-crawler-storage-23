import remedapy as R


class TestSplitAt:
    def test_data_first(self):
        # R.split_at(array, index)
        assert R.split_at([1, 2, 3], 1) == ([1], [2, 3])
        assert R.split_at(range(1, 4), 1) == ([1], [2, 3])
        assert R.split_at((x for x in range(1, 4)), 1) == ([1], [2, 3])
        assert R.split_at([1, 2, 3, 4, 5], -1) == ([1, 2, 3, 4], [5])
        assert R.split_at((x for x in range(1, 6)), -1) == ([1, 2, 3, 4], [5])

    def test_data_last(self):
        # R.split_at(index)(array)
        assert R.split_at(1)([1, 2, 3]) == ([1], [2, 3])
        assert R.split_at(-1)([1, 2, 3, 4, 5]) == ([1, 2, 3, 4], [5])
