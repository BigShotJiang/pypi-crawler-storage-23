import remedapy as R


class TestIntersection:
    def test_data_first(self):
        # R.intersection(data, other)
        assert list(R.intersection([1, 2, 3], [2, 3, 5])) == [2, 3]
        assert list(R.intersection([1, 1, 2, 2], [1])) == [1]

    def test_data_last(self):
        # R.intersection(other)(data)
        assert R.pipe([1, 2, 3], R.intersection([2, 3, 5]), list) == [2, 3]
        assert R.pipe([1, 1, 2, 2], R.intersection([1]), list) == [1]
