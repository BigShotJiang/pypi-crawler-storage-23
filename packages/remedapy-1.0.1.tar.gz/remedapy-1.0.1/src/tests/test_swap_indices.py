import remedapy as R


class TestSwapIndices:
    def test_data_first(self):
        # R.swap_indices(data, index1, index2)
        assert list(R.swap_indices(['a', 'b', 'c'], 0, 1)) == ['b', 'a', 'c']
        assert list(R.swap_indices(['a', 'b', 'c'], 1, -1)) == ['a', 'c', 'b']
        assert R.swap_indices('abc', 0, 1) == 'bac'

    def test_data_last(self):
        # R.swap_indices(index1, index2)(data)
        assert list(R.swap_indices(0, 1)(['a', 'b', 'c'])) == ['b', 'a', 'c']
        assert R.swap_indices(0, -1)('abc') == 'cba'
