import remedapy as R


class TestGet:
    def test_data_first(self):
        #
        a = R.get([], 0)
        assert a is None
        a1 = R.get([1], 0)
        assert a1 == 1
        assert R.get([1], 2, 5) == 5
        assert R.get({'a': 3}, 'a', 5) == 3
        x = R.get({'a': 3}, 'aa', 5)
        assert x == 5
        y = R.get({'a': 3}, 'aa', 'ab')
        assert y == 'ab'

    def test_data_last(self):
        #
        assert R.get(1)([9, 8]) == 8
