import remedapy as R


class TestSubtract:
    def test_data_first(self):
        # R.subtract(value, subtrahend);
        assert R.subtract(10, 5) == 5
        assert R.subtract(10, -5) == 15
        assert R.fold([1, 2, 3, 4], R.subtract, 20) == 10

    def test_data_last(self):
        # R.subtract(subtrahend)(value);
        assert R.subtract(5)(10) == 5
        assert R.subtract(-5)(10) == 15
        assert list(R.map([1, 2, 3, 4], R.subtract(1))) == [0, 1, 2, 3]
