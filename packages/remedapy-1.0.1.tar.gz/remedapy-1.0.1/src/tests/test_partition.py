from collections.abc import Sequence

import remedapy as R


class TestPartition:
    def test_data_first(self):
        # R.partition(data, predicate)
        def predicate(x: str):
            return len(x) == 3

        result = R.partition(
            ['one', 'two', 'forty two'],
            predicate,
        )
        assert result == (['one', 'two'], ['forty two'])

        def predicate2(x: str, i: int) -> bool:
            return len(x) == 3 and i % 2 == 0

        assert R.partition(
            ['one', 'two', 'forty two'],
            predicate2,
        ) == (['one'], ['two', 'forty two'])

        def predicate3(x: str, i: int, data: Sequence[str]) -> bool:
            return len(x) == 3 and i % 2 == 0 and data[0] != x

        assert R.partition(
            ['one', 'two', 'forty two'],
            predicate3,
        ) == ([], ['one', 'two', 'forty two'])

    def test_data_last(self):
        # R.partition(predicate)(data)
        def predicate(x: str):
            return len(x) == 3

        assert R.pipe(
            ['one', 'two', 'forty two'],
            R.partition(predicate),
        ) == (['one', 'two'], ['forty two'])
