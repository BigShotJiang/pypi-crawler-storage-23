import remedapy as R


class TestSet:
    def test_data_first(self):
        # R.set(obj, prop, value)
        assert R.set({'a': 1}, 'a', 2) == {'a': 2}

    def test_data_last(self):
        # R.set(prop, value)(obj)
        assert R.pipe({'a': 1}, R.set('a', 2)) == {'a': 2}
