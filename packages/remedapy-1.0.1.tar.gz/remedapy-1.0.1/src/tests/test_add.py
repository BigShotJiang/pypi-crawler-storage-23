import remedapy as R


class TestAdd:
    def test_data_first(self):
        # R.add(value, addend);
        assert R.add(10, 5) == 15
        assert R.add(10, -5) == 5

    def test_data_last(self):
        # R.add(addend)(value);
        assert R.add(5)(10) == 15
        assert R.add(-5)(10) == 5
        assert list(R.map([1, 2, 3, 4], R.add(1))) == [2, 3, 4, 5]
        fn = R.add(1)
        x1: int = fn(1)
        assert x1 == 2
        x2: float = fn(1.5)
        assert x2 == 2.5
