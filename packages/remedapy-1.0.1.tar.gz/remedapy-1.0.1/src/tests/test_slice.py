import remedapy as R


class TestSlice:
    def test_data_first(self):
        # R.slice(data, indexStart, indexEnd)
        assert list(R.slice(range(5), 2)) == [2, 3, 4]
        assert list(R.slice([10, 20, 30, 40, 50], 2, 5)) == [30, 40, 50]
        assert ''.join(R.slice('abcdefghijkl', 1)) == 'bcdefghijkl'
        assert ''.join(R.slice('abcdefghijkl', 4, 7)) == 'efg'

    def test_data_last(self):
        # R.slice(indexStart, indexEnd)(string)
        assert list(R.slice(2)(range(5))) == [2, 3, 4]
        assert list(R.slice(2, 5)([10, 20, 30, 40, 50])) == [30, 40, 50]
        assert ''.join(R.slice(1)('abcdefghijkl')) == 'bcdefghijkl'
        assert ''.join(R.slice(4, 7)('abcdefghijkl')) == 'efg'
