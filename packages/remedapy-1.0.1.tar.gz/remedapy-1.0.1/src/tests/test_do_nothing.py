import remedapy as R


class TestDoNothing:
    def test_data_last(self):
        # R.do_nothing();
        assert R.do_nothing()(1, 2, 3) is None
