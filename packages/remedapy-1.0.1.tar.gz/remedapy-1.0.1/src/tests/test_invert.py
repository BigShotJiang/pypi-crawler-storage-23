import remedapy as R


class TestInvert:
    def test_data_first(self):
        # R.invert(object)
        assert R.invert({'a': 'd', 'b': 'e', 'c': 'f'}) == {'d': 'a', 'e': 'b', 'f': 'c'}

    def test_data_last(self):
        # R.invert()(object)
        assert R.pipe({'a': 'd', 'b': 'e', 'c': 'f'}, R.invert()) == {'d': 'a', 'e': 'b', 'f': 'c'}
