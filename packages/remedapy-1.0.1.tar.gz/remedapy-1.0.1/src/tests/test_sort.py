import remedapy as R


class TestSort:
    def test_data_first(self):
        # R.sort(data, ...rules)
        assert R.sort(
            [{'a': 1}, {'a': 3}, {'a': 7}, {'a': 2}],
            R.prop('a'),  # pyright: ignore[reportArgumentType]
        ) == [{'a': 1}, {'a': 2}, {'a': 3}, {'a': 7}]
        # assert R.sort(
        #  [
        #  {'color': 'red', weight: 2},
        #  {'color': 'blue', weight: 3},
        #  {'color': 'green', weight: 1},
        #  {'color': 'purple', weight: 1},
        #  ],
        #  [prop('weight'), 'asc'],
        #  prop('color'),
        #  ) == [
        #     {'color': 'green', weight: 1},
        #     {'color': 'purple', weight: 1},
        #     {'color': 'red', weight: 2},
        #     {'color': 'blue', weight: 3},
        #   ]

    def test_data_last(self):
        # R.sort(...rules)(data)
        assert R.pipe(
            [{'a': 1}, {'a': 3}, {'a': 7}, {'a': 2}],
            R.sort(R.prop('a')),  # pyright: ignore[reportArgumentType]
        ) == [{'a': 1}, {'a': 2}, {'a': 3}, {'a': 7}]
