import remedapy as R


class TestIsString:
    def test_data_first(self):
        # R.is_string(data);
        assert R.is_string('a')
        assert not R.is_string(1)

    def test_data_last(self):
        # R.is_string()(data);
        assert R.is_string()('a')
        assert not R.is_string()(1)
