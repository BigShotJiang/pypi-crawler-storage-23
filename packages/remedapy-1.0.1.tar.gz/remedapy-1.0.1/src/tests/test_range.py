import remedapy as R


class TestRange:
    def test_data_first(self):
        # R.range(start, end);
        assert list(R.range(1, 5)) == [1, 2, 3, 4]

    def test_data_last(self):
        # R.range(end)(start);
        assert list(R.range(5)(1)) == [1, 2, 3, 4]
        assert R.pipe(1, R.range(5), list) == [1, 2, 3, 4]
