import remedapy as R


class TestApply:
    def test_data_first(self):
        # R.apply(data, fn);
        assert R.apply(10, R.add(5)) == 15
        x = R.apply(10, R.constant('asd'))
        assert x == 'asd'

    def test_data_first_without_fn(self):
        # R.apply(data)(fn);
        assert R.apply(10)(R.add(5)) == 15
        assert R.apply(10)(R.add(-5)) == 5

    def test_data_last(self):
        # R.apply(fn)(data);
        assert R.apply(R.add(5))(10) == 15
        assert R.apply(R.add(-5))(10) == 5
