import remedapy as R


class TestMeanBy:
    def test_data_first(self):
        # R.mean_by(array, fn)
        def sum3(a: int, b: int, c: int) -> int:
            return a + b + c

        p = R.partial(sum3, 1, 2)
        p2 = R.partial(sum3, 1)
        assert p(3) == 6
        assert p2(2, 3) == 6
