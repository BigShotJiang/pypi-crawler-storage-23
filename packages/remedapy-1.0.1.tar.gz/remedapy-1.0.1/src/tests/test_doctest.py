import doctest
from pathlib import Path

import pytest

import remedapy as R


class TestDoctests:
    @pytest.mark.parametrize(
        'fn',
        R.__all__,
    )
    def test_doctests(self, fn: str):
        """Test all doctests using pytest."""
        path = str(Path(__file__).parent.parent / 'remedapy' / f'{fn}.py')
        results = doctest.testfile(path, module_relative=False, extraglobs={'R': R}, optionflags=doctest.ELLIPSIS)
        assert results.attempted > 0
        if results.failed:
            assert not results.failed
