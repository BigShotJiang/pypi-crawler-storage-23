import remedapy as R


class TestIsFloat:
    def test_data_first(self):
        # R.is_string(data);
        assert R.is_float(1.1)
        assert not R.is_float(1)

    def test_data_last(self):
        # R.is_string()(data);
        assert R.is_float()(1.1)
        assert not R.is_float()(1)
