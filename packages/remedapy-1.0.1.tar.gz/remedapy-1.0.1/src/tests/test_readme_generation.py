from pathlib import Path

import remedapy as R
from tests.util import Spy


class TestReadmeGeneration:
    def test_everything_in_grouping(self):
        """Test every file is mentioned in grouping."""
        IGNORED = {'__init__', 'util', 'local_types', 'decorator'}
        files_dir = Path(__file__).parent.parent / 'remedapy'
        files_paths = set(files_dir.glob('**/*.py'))
        files = {x.stem for x in files_paths}
        groupings_files = Path(__file__).parent.parent.parent / 'readme_generation' / 'Grouping.md'
        content = groupings_files.read_text()
        mentioned = R.pipe(content, R.split('\n'), R.filter(R.starts_with('- ')), R.map(R.slice_string(2)), set)
        assert mentioned | IGNORED == files

    def test_example(self):
        """Test example from readme."""
        spy = Spy()
        result = R.pipe([1, 2, 2, 3, 3, 4, 5, 6], R.for_each(spy), R.for_each(print), R.unique(), R.take(3), list)
        assert result == [1, 2, 3]
        assert spy.calls == [(1,), (2,), (2,), (3,)]
