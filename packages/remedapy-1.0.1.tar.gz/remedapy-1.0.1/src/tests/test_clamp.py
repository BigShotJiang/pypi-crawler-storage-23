import remedapy as R


class TestClamp:
    def test_data_first(self):
        # R.clamp(value, { min, max });
        x: int = R.clamp(10, min=20)
        assert x == 20
        assert R.clamp(10, max=5) == 5
        assert R.clamp(10, max=20, min=5) == 10
        x2: float = R.clamp(1, max=20, min=5.5)
        assert x2 == 5.5

    def test_data_last(self):
        # R.clamp({ min, max })(value);
        assert R.clamp(min=20)(10) == 20
        assert R.clamp(max=5)(10) == 5
        assert R.clamp(5, 20)(10) == 10
