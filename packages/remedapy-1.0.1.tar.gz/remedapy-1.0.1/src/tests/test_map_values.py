import remedapy as R


class TestMapValues:
    def test_data_first(self):
        # R.map_values(data, mapper)
        def glue(
            v: int,
            key: str,
        ) -> str:
            return f'{v}{key}'

        assert R.map_values({'a': 1, 'b': 2}, glue) == {'a': '1a', 'b': '2b'}
        assert R.map_values({'a': 1, 'b': 2}, R.add(1)) == {'a': 2, 'b': 3}
        assert R.map_values({'a': 1, 'b': 2}, R.constant('1')) == {'a': '1', 'b': '1'}

    def test_data_last(self):
        # R.map_values(mapper)(data)
        def glue(
            v: int,
            key: str,
        ) -> str:
            return f'{v}{key}'

        assert R.pipe({'a': 1, 'b': 2}, R.map_values(glue)) == {'a': '1a', 'b': '2b'}
