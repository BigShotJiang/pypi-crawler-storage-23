import remedapy as R


class TestToKebabCase:
    def test_data_first(self):
        # R.to_kebab_case(data);
        assert R.to_kebab_case('hello world') == 'hello-world'
        assert R.to_kebab_case('__HELLO_WORLD__') == 'hello-world'

    def test_data_last(self):
        # R.to_kebab_case()(data);
        assert R.pipe('hello world', R.to_kebab_case()) == 'hello-world'
        assert R.pipe('__HELLO_WORLD__', R.to_kebab_case()) == 'hello-world'
