import remedapy as R


class TestDifference:
    def test_data_first(self):
        # R.difference(data, other);
        assert list(R.difference([1, 2, 3, 4], [2, 5, 3])) == [1, 4]
        assert list(R.difference([1, 1, 2, 2], [1])) == [1, 2, 2]

    def test_data_last(self):
        # R.difference(other)(data);
        assert R.pipe([1, 2, 3, 4], R.difference([2, 5, 3]), list) == [1, 4]
        assert R.pipe([1, 1, 2, 2], R.difference([1]), list) == [1, 2, 2]
