import remedapy as R


class TestRound:
    def test_data_first(self):
        # R.round(value, precision);
        assert R.round(123.9876, 3) == 123.988
        assert R.round(483.22243, 1) == 483.2
        assert R.round(8541, -1) == 8540
        assert R.round(456789, -3) == 457000

    def test_data_last(self):
        # R.round(precision)(value);
        assert R.round(3)(123.9876) == 123.988
        assert R.round(1)(483.22243) == 483.2
        assert R.round(-1)(8541) == 8540
        assert R.round(-3)(456789) == 457000
