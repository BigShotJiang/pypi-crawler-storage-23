import remedapy as R


class TestUncapitalise:
    def test_data_first(self):
        # R.uncapitalise(data);
        assert R.uncapitalise('HELLO WORLD') == 'hELLO WORLD'
        assert R.uncapitalise('') == ''

    def test_data_last(self):
        # R.uncapitalise()(data);
        assert R.pipe('HELLO WORLD', R.uncapitalise()) == 'hELLO WORLD'
        assert R.pipe('', R.uncapitalise()) == ''
