import remedapy as R


class TestDropLast:
    def test_data_first(self):
        # R.drop_last(array, n)
        assert R.drop_last([1, 2, 3, 4, 5], 2) == [1, 2, 3]

    def test_data_last(self):
        # R.drop_last(n)(array)
        assert R.drop_last(2)([1, 2, 3, 4, 5]) == [1, 2, 3]
