import remedapy as R


class TestSortedIndex:
    def test_data_first(self):
        # R.sorted_index(data, item)
        assert R.sorted_index(['a', 'a', 'b', 'c', 'c'], 'c') == 3
        assert R.sorted_index(['a', 'a', 'b', 'c', 'c'], 'd') == 5

    def test_data_last(self):
        # R.sorted_index(item)(data)
        assert R.pipe(['a', 'a', 'b', 'c', 'c'], R.sorted_index('c')) == 3
