import remedapy as R


class TestEvolve:
    def test_data_first(self):
        # R.evolve(data, evolver)
        evolver = {
            'count': R.add(1),
            'time': {'elapsed': R.add(1), 'remaining': R.add(-1)},
        }
        data = {
            'id': 10,
            'count': 10,
            'time': {'elapsed': 100, 'remaining': 1400},
        }
        assert R.evolve(data, evolver) == {
            'id': 10,
            'count': 11,
            'time': {'elapsed': 101, 'remaining': 1399},
        }

    def test_data_last(self):
        # R.evolve(evolver)(data)
        evolver = {
            'count': R.add(1),
            'time': {'elapsed': R.add(1), 'remaining': R.add(-1)},
        }
        data = {
            'id': 10,
            'count': 10,
            'time': {'elapsed': 100, 'remaining': 1400},
        }
        assert R.pipe(data, R.evolve(evolver)) == {
            'id': 10,
            'count': 11,
            'time': {'elapsed': 101, 'remaining': 1399},
        }
