import remedapy as R


class TestMap:
    def test_data_first(self):
        # R.map(data, callbackfn);

        assert list(R.map([1, 2, 3], R.multiply(2))) == [2, 4, 6]
        assert list(R.map([0, 0], R.add(1))) == [1, 1]
        assert list(R.map([0, 0], lambda value, index: value + index)) == [0, 1]

    def test_data_last(self):
        # R.map(callbackfn)(data);

        assert list(R.map(R.multiply(2))([1, 2, 3])) == [2, 4, 6]
        assert list(R.map(R.add(1))([0, 0])) == [1, 1]

        def add_index(value: int, index: int) -> int:
            return value + index

        assert list(R.map(add_index)([0, 0])) == [0, 1]

        assert list(R.pipe([1, 2, 3], R.map(R.multiply(2)))) == [2, 4, 6]

        assert list(R.pipe([0, 0], R.map(R.add(1)))) == [1, 1]
        assert R.pipe([0, 0], R.map(add_index), list) == [0, 1]

    def test_more_params(self):
        assert list(R.map([1, 2, 3], lambda x, y: x + y)) == [1, 3, 5]
        assert list(R.map([1, 2, 3], lambda x, y, z: x + y + len(z))) == [4, 6, 8]
