import remedapy as R


class TestFindLastIndex:
    def test_data_first(self):
        # R.find_last_index(data, predicate)
        assert R.find_last_index([1, 3, 4, 6], R.is_odd) == 1
        assert R.find_last_index((x for x in range(10)), R.is_odd) == 9

    def test_data_last(self):
        # R.find_last_index(fn)(items)
        assert R.pipe([1, 3, 4, 6], R.find_last_index(R.is_odd)) == 1
