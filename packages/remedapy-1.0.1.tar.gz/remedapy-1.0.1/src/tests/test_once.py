import remedapy as R
from tests.util import Spy


class TestOnce:
    def test_data_first(self):
        # R.once(fn)
        spy = Spy()
        fn = R.once(spy)
        fn()
        fn()
        assert spy.calls == [()]
