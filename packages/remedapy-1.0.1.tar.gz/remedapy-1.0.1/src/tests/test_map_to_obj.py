import remedapy as R


class TestMapToObj:
    def test_data_first(self):
        # R.map_to_obj(array, fn)
        assert R.map_to_obj([1, 2, 3], lambda x: (str(x), x * 2)) == {'1': 2, '2': 4, '3': 6}

    def test_data_last(self):
        # R.map_to_obj(fn)(array)
        def fn(x: int) -> tuple[str, int]:
            return (str(x), x * 2)

        assert R.pipe([1, 2, 3], R.map_to_obj(fn)) == {'1': 2, '2': 4, '3': 6}
