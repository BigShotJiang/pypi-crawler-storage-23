import remedapy as R


class TestValues:
    def test_data_first(self):
        # R.values(source)
        assert list(R.values(['x', 'y', 'z'])) == ['x', 'y', 'z']
        assert list(R.values({'a': 'x', 'b': 'y', 'c': 'z'})) == ['x', 'y', 'z']

    def test_data_last(self):
        # R.values()(source)
        assert R.pipe(['x', 'y', 'z'], R.values(), list) == ['x', 'y', 'z']
        assert R.pipe({'a': 'x', 'b': 'y', 'c': 'z'}, R.values(), list) == ['x', 'y', 'z']
        assert (
            R.pipe(
                {'a': 'x', 'b': 'y', 'c': 'z'},
                R.values(),
                R.first(),
            )
            == 'x'
        )
