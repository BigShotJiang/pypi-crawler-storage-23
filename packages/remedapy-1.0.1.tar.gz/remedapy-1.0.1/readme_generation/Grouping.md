Iterable:

- all_pass
- any_pass
- chunk
- concat
- count_by
- difference
- difference_with
- drop
- drop_first_by
- drop_last
- drop_last_while
- drop_while
- filter
- find
- find_index
- find_last
- find_last_index
- first
- first_by
- flat
- flat_map
- get
- group_by
- group_by_prop
- index_by
- intersection
- intersection_with
- last
- length
- map
- map_to_obj
- map_with_feedback
- mean
- mean_by
- nth_by
- only
- partition
- pull_object
- range
- rank_by
- reduce
- reverse
- sample
- shuffle
- slice
- sort
- sorted_index
- sorted_index_by
- sorted_index_with
- sorted_last_index
- sorted_last_index_by
- splice
- split
- split_at
- split_when
- sum
- sum_by
- swap_indices
- take
- take_first_by
- take_last
- take_last_while
- take_while
- times
- unique
- unique_by
- unique_with
- zip
- zip_with

Function:

- apply
- conditional
- constant
- do_nothing
- fold
- for_each
- identity
- negate
- once
- partial
- pipe
- piped
- tap
- when

TypeGuard:

- is_bool
- is_callable
- is_empty
- is_float
- is_int
- is_list
- is_none
- is_number
- is_sequence
- is_sized
- is_string

Number:

- add
- ceil
- clamp
- floor
- is_divisible_by
- is_even
- is_odd
- mod
- multiply
- round
- subtract

String:

- capitalise
- ends_with
- join
- random_string
- slice_string
- starts_with
- to_camel_case
- to_kebab_case
- to_lower_case
- to_snake_case
- to_title_case
- to_upper_case
- to_words
- truncate
- uncapitalise

Other:

- default_to
- is_truthy

Set:

- is_subset
- is_superset

Dict:

- entries
- evolve
- for_each_dict
- from_entries
- from_keys
- invert
- keys
- map_keys
- map_values
- merge
- merge_all
- merge_deep
- omit
- omit_by
- path_or
- pick
- pick_by
- prop
- set
- set_path
- swap_props
- values

Comparison:

- eq
- ge
- gt
- le
- lt
- neq
