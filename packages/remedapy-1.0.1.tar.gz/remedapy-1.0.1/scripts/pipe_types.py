
for i in range(ord('B'), ord('P') + 1):

    x = '''@overload
def pipe(data: A, '''
    for j in range(ord('B'), i + 1):
        x += f"func{chr(j - 1)}: Callable[[{chr(j - 1)}], {chr(j)}], "
    x += f"/) -> {chr(i)}: ...\n"
    print(x)

for i in range(ord('B'), ord('P') + 1):

    x = '''@overload
def pipe('''
    for j in range(ord('B'), i + 1):
        x += f"func{chr(j - 1)}: Callable[[{chr(j - 1)}], {chr(j)}], "
    x += f"/) -> Callable[[A], {chr(i)}]: ...\n"
    print(x)
