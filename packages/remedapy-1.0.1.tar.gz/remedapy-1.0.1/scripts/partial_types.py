for i in range(ord('A'), ord('O') + 1):

    x = '''@overload
def partial(fn: Callable[Concatenate['''
    for j in range(ord('A'), i + 1):
        x += chr(j) + ', '
    x += 'P], R], '
    for j in range(ord('A'), i + 1):
        x += f'arg{chr(j)}: {chr(j)}, '
    x += "/) -> Callable[P, R]: ...\n"
    print(x)
