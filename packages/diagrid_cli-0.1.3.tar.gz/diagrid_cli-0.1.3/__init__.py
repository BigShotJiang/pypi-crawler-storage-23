"""Diagrid CLI - Command-line interface for Diagrid Catalyst agents."""
