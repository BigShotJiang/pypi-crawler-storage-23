"""彩色日志记录器 - 提供带颜色输出的日志功能."""

from __future__ import annotations

import logging
import os
import sys
from typing import ClassVar

# Windows ANSI 颜色码支持
if sys.platform in {"win32", "cygwin"}:
    try:
        import ctypes

        kernel32 = ctypes.windll.kernel32  # type: ignore[attr-defined]
        kernel32.SetConsoleMode(kernel32.GetStdHandle(-11), 7)
    except (OSError, AttributeError, ctypes.ArgumentError):
        sys.stderr.write("ANSI colors are not supported in this environment.")


class ColoredFormatter(logging.Formatter):
    """支持彩色输出的日志格式化器."""

    COLORS: ClassVar[dict[str, str]] = {
        "DEBUG": "\033[35m",
        "INFO": "\033[36m",
        "WARNING": "\033[33m",
        "ERROR": "\033[31m",
        "CRITICAL": "\033[31m\033[1m",
        "SUCCESS": "\033[32m",
        "RESET": "\033[0m",
    }

    def __init__(
        self,
        fmt: str | None = None,
        datefmt: str | None = None,
        *,
        use_colors: bool = True,
    ) -> None:
        super().__init__()
        if fmt is None:
            fmt = "%(message)s"
        self.datefmt = datefmt or "%Y-%m-%d %H:%M:%S"
        self.formats: dict[str, str] = {}
        for level, color in self.COLORS.items():
            if level == "RESET":
                continue
            if use_colors:
                self.formats[level] = f"{color}{fmt}{self.COLORS['RESET']}"
            else:
                self.formats[level] = fmt

    def format(self, record: logging.LogRecord) -> str:
        """格式化日志记录.

        Args:
            record: 日志记录对象

        Returns
        -------
            格式化后的日志字符串
        """
        log_fmt = self.formats.get(record.levelname, self.formats.get("INFO", ""))
        formatter = logging.Formatter(log_fmt, datefmt=self.datefmt)
        return formatter.format(record)


# 注册 SUCCESS 级别 (仅一次)
SUCCESS_LEVEL = logging.INFO + 5
# 使用模块级变量避免重复注册
if "VEKTOR_SUCCESS_LEVEL_REGISTERED" not in globals():
    logging.addLevelName(SUCCESS_LEVEL, "SUCCESS")
    globals()["VEKTOR_SUCCESS_LEVEL_REGISTERED"] = True


class ColoredLogger:
    """彩色日志记录器."""

    DEBUG = logging.DEBUG
    INFO = logging.INFO
    SUCCESS = SUCCESS_LEVEL
    WARNING = logging.WARNING
    ERROR = logging.ERROR
    CRITICAL = logging.CRITICAL

    _instances: ClassVar[dict[str, ColoredLogger]] = {}

    def __init__(self, name: str = "Vektor", level: int = logging.INFO) -> None:
        self.logger = logging.getLogger(name)
        self.logger.setLevel(level)

        # Store the initial state, but we'll dynamically check the environment in property
        self._name = name
        self._level = level

        # Check if we're in a test environment initially
        in_test_env = "PYTEST_CURRENT_TEST" in os.environ

        if not self.logger.handlers and not in_test_env:
            handler = logging.StreamHandler(sys.stdout)
            handler.setFormatter(ColoredFormatter(use_colors=sys.stdout.isatty()))
            self.logger.addHandler(handler)

    @property
    def propagate(self):
        """Dynamic property that checks test environment on access."""
        return "PYTEST_CURRENT_TEST" in os.environ

    @propagate.setter
    def propagate(self, value):
        """Setter for propagate property (for compatibility)."""
        # We don't actually set a fixed value since it's dynamic
        pass

    def _update_propagate(self):
        """Update the propagate setting based on current environment."""
        in_test_env = "PYTEST_CURRENT_TEST" in os.environ
        self.logger.propagate = in_test_env

    def addHandler(self, handler: logging.Handler) -> None:  # noqa: N802
        """Add a handler to the underlying logger."""
        self.logger.addHandler(handler)

    def removeHandler(self, handler: logging.Handler) -> None:  # noqa: N802
        """Remove a handler from the underlying logger."""
        self.logger.removeHandler(handler)

    def isEnabledFor(self, level: int) -> bool:  # noqa: N802
        """Check if the logger is enabled for the given level."""
        return self.logger.isEnabledFor(level)

    def exception(self, message: str, *args, **kwargs) -> None:
        """记录异常级别日志."""
        self._update_propagate()
        self.logger.exception(message, *args, **kwargs)

    def debug(self, message: str) -> None:
        """记录调试级别日志."""
        self._update_propagate()
        self.logger.debug(message)

    def info(self, message: str) -> None:
        """记录信息级别日志."""
        self._update_propagate()
        self.logger.info(message)

    def success(self, message: str) -> None:
        """记录成功级别日志."""
        self._update_propagate()
        self.logger.log(SUCCESS_LEVEL, message)

    def warning(self, message: str) -> None:
        """记录警告级别日志."""
        self._update_propagate()
        self.logger.warning(message)

    def error(self, message: str) -> None:
        """记录错误级别日志."""
        self._update_propagate()
        self.logger.error(message)

    def critical(self, message: str) -> None:
        """记录严重错误级别日志."""
        self._update_propagate()
        self.logger.critical(message)

    def setLevel(self, level: int) -> None:  # noqa: N802
        """设置日志级别."""
        self.logger.setLevel(level)

    @classmethod
    def get_logger(
        cls,
        name: str = "Vektor",
        level: int = logging.INFO,
    ) -> ColoredLogger:
        """获取指定名称的日志记录器实例.

        Args:
            name: 日志记录器名称
            level: 日志级别

        Returns
        -------
            ColoredLogger 实例
        """
        if name not in cls._instances:
            cls._instances[name] = cls(name, level)
        return cls._instances[name]


def get_logger(name: str = "pytola", level: int = logging.INFO) -> ColoredLogger:
    """获取彩色日志记录器实例.

    Args:
        name: 日志记录器名称
        level: 日志级别

    Returns
    -------
        ColoredLogger 实例
    """
    return ColoredLogger.get_logger(name, level)


_default = get_logger()
logger = get_logger()
debug = _default.debug
info = _default.info
success = _default.success
warning = _default.warning
error = _default.error
critical = _default.critical
