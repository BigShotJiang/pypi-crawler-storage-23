# Which

Find executable paths for commands cross-platform.

## Features

- Cross-platform command path lookup (Windows/Linux/macOS)
- Support for Windows built-in commands (dir, echo, cls, etc.)
- Fuzzy matching capability
- Quiet mode for scripting
- Handles both regular executables and shell built-ins

## Installation

```bash
pip install -e .
```

## Usage

### Command Line

```bash
# Find single command
which python

# Find multiple commands
which gcc ls dir

# Enable fuzzy matching
which -f pyt  # finds python, python3, etc.

# Quiet mode (only show paths)
which -q python gcc

# Show help
which -h
```

### Python API

```python
from pytola.system.which.cli import find_executable

# Find executable path
name, path = find_executable("python", fuzzy=False)
if path:
    print(f"{name} -> {path}")
else:
    print(f"{name} not found")
```

## Examples

```bash
$ which gcc ls dir echo
✓ gcc -> C:\Environment\mingw64\bin\gcc.exe
✓ ls -> C:\Environment\Gow_v0.8.0\bin\ls.exe
✓ dir -> C:\Windows\System32\cmd.exe (built-in)
✓ echo -> C:\Windows\System32\cmd.exe (built-in)

Found 4/4 commands
```

## Supported Commands

### Windows

- Regular executables: `gcc`, `ls`, `notepad`, etc.
- Built-in commands: `dir`, `echo`, `cls`, `cd`, `md`, `rd`, etc.

### Linux/macOS

- Standard POSIX commands: `ls`, `cat`, `grep`, etc.
- System binaries in `/usr/bin/`

## License

MIT
