"""Unit test for SSH Copy ID GUI logic without GUI rendering."""

from __future__ import annotations

from unittest.mock import MagicMock

import pytest


# Test the core logic without GUI rendering
class TestSSHCopyIDGUILogic:
    """Tests for SSH Copy ID GUI logic components."""

    def test_update_test_button_state_logic(self):
        """Test the button state update logic."""
        # Mock the GUI window components
        mock_window = MagicMock()
        mock_window.hostname_input.text.return_value = ""
        mock_window.username_input.text.return_value = ""
        mock_window.password_input.text.return_value = ""
        mock_window.test_connection_button = MagicMock()
        mock_window.connection_status_label = MagicMock()

        # Define the method we want to test
        def update_test_button_state(window):
            """Update test button enabled state based on required fields."""
            hostname = window.hostname_input.text().strip()
            username = window.username_input.text().strip()
            password = window.password_input.text().strip()

            # Enable test button only when all required fields are filled
            has_required_fields = bool(hostname and username and password)
            window.test_connection_button.setEnabled(has_required_fields)

            if not has_required_fields:
                window.connection_status_label.setText("")
                window.connection_status_label.setStyleSheet("font-size: 16px; font-weight: bold;")

        # Test initial state - all empty
        update_test_button_state(mock_window)
        mock_window.test_connection_button.setEnabled.assert_called_with(False)

        # Test with only hostname
        mock_window.hostname_input.text.return_value = "192.168.1.1"
        update_test_button_state(mock_window)
        mock_window.test_connection_button.setEnabled.assert_called_with(False)

        # Test with hostname and username
        mock_window.username_input.text.return_value = "testuser"
        update_test_button_state(mock_window)
        mock_window.test_connection_button.setEnabled.assert_called_with(False)

        # Test with all required fields
        mock_window.password_input.text.return_value = "testpass"
        update_test_button_state(mock_window)
        mock_window.test_connection_button.setEnabled.assert_called_with(True)

        # Test clearing one field
        mock_window.password_input.text.return_value = ""
        update_test_button_state(mock_window)
        mock_window.test_connection_button.setEnabled.assert_called_with(False)

    def test_connection_status_reset_logic(self):
        """Test that connection status resets when fields become incomplete."""
        mock_window = MagicMock()
        mock_window.hostname_input.text.return_value = "192.168.1.1"
        mock_window.username_input.text.return_value = "testuser"
        mock_window.password_input.text.return_value = "testpass"
        mock_window.connection_status_label = MagicMock()

        # Simulate successful connection
        def update_connection_status(window, success, message):
            """Update the connection status display."""
            if success:
                window.connection_status_label.setText("✓")
                window.connection_status_label.setStyleSheet("color: green; font-size: 16px; font-weight: bold;")
            else:
                window.connection_status_label.setText("✗")
                window.connection_status_label.setStyleSheet("color: red; font-size: 16px; font-weight: bold;")

        # Set successful status
        update_connection_status(mock_window, True, "Connected")
        mock_window.connection_status_label.setText.assert_called_with("✓")

        # Clear username - should trigger status reset in update_test_button_state
        mock_window.username_input.text.return_value = ""

        def update_test_button_state_with_reset(window):
            """Update test button state and reset status when incomplete."""
            hostname = window.hostname_input.text().strip()
            username = window.username_input.text().strip()
            password = window.password_input.text().strip()

            has_required_fields = bool(hostname and username and password)
            window.test_connection_button.setEnabled(has_required_fields)

            if not has_required_fields:
                window.connection_status_label.setText("")
                window.connection_status_label.setStyleSheet("font-size: 16px; font-weight: bold;")

        update_test_button_state_with_reset(mock_window)
        mock_window.connection_status_label.setText.assert_called_with("")


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
