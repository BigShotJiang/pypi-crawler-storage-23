# SSH Copy ID

A Python utility for deploying SSH public keys to remote servers, similar to the traditional `ssh-copy-id` command but with enhanced features and cross-platform support.

## Features

- 🔐 Secure SSH key deployment to remote servers
- 🌐 Cross-platform support (Windows, Linux, macOS)
- ⚙️ Configurable SSH ports and connection timeouts
- 📋 Detailed error handling and logging
- 🔧 Command-line interface with helpful options
- 🛡️ Security warnings for host key verification settings

## Installation

```bash
pip install sshcopyid
```

Or install from source:

```bash
cd pytola/sshcopyid
pip install -e .
```

## Requirements

- Python >= 3.8
- `sshpass` utility installed on the system

### Installing sshpass

**Ubuntu/Debian:**
```bash
sudo apt-get install sshpass
```

**CentOS/RHEL:**
```bash
sudo yum install sshpass
```

**macOS:**
```bash
brew install hudochenkov/sshpass/sshpass
```

## Usage

### Basic Usage

```bash
sshcopyid hostname username password
```

### Advanced Options

```bash
# Specify custom SSH port
sshcopyid hostname username password -p 2222

# Use different public key file
sshcopyid hostname username password -k ~/.ssh/id_ed25519.pub

# Set custom timeout
sshcopyid hostname username password -t 60

# Enable verbose logging
sshcopyid hostname username password -v
```

### Examples

```bash
# Deploy default RSA key to server
sshcopyid 192.168.1.100 myuser mypassword

# Deploy ED25519 key to server on custom port
sshcopyid example.com myuser mypassword -p 2222 -k ~/.ssh/id_ed25519.pub

# Deploy with longer timeout for slow connections
sshcopyid remote-server.com user pass -t 120
```

## How It Works

1. Reads the specified public key file (defaults to `~/.ssh/id_rsa.pub`)
2. Uses `sshpass` to authenticate with the remote server
3. Creates `.ssh` directory with proper permissions if it doesn't exist
4. Adds the public key to `~/.ssh/authorized_keys` if not already present
5. Sets appropriate file permissions (700 for `.ssh`, 600 for `authorized_keys`)

## Security Notes

⚠️ **Important Security Warning:**

This tool disables SSH host key verification (`StrictHostKeyChecking=no`) for convenience. This makes man-in-the-middle attacks theoretically possible. Only use this tool in trusted network environments.

For production environments, consider using the system's built-in `ssh-copy-id` command instead.

## Error Handling

The tool provides specific exit codes for different error conditions:

- `0`: Success
- `1`: General error
- `2`: Authentication failed
- `3`: Connection failed
- `4`: Key file error

## API Usage

You can also use sshcopyid programmatically:

```python
from pytola.sshcopyid import SSHCopyIDConfig, ssh_copy_id

config = SSHCopyIDConfig(
    hostname="192.168.1.100",
    username="myuser",
    password="mypassword",
    port=22,
    public_key_path="~/.ssh/id_rsa.pub"
)

try:
    ssh_copy_id(config)
    print("SSH key deployed successfully!")
except Exception as e:
    print(f"Deployment failed: {e}")
```

## Contributing

Contributions are welcome! Please feel free to submit pull requests or open issues for bugs and feature requests.

## License

This project is licensed under the MIT License.
