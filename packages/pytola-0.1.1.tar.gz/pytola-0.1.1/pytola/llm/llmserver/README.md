# LLM Server Manager

A graphical tool for managing and running local LLM servers using llama.cpp models.

## Features

- **Easy Model Management**: Browse and select GGUF model files
- **Server Configuration**: Configure port, thread count, and other server parameters
- **Real-time Monitoring**: View server output and logs in real-time
- **Browser Integration**: One-click launch of web interface
- **Persistent Settings**: Configuration automatically saved between sessions
- **Cross-platform**: Works on Windows, macOS, and Linux

## Prerequisites

- Python 3.8+
- [llama.cpp](https://github.com/ggerganov/llama.cpp) installed and available in PATH
- GGUF format model files

## Installation

The tool is part of the pytola project. Install the complete package:

```bash
pip install pytola
```

Or install only the llmserver module:

```bash
pip install pytola[llmserver]
```

## Usage

### Graphical Interface

Launch the GUI application:

```bash
llmserver
# or
llmserver-gui
```

The GUI provides:
- Model file selection with native file browser
- Server configuration (port, threads)
- Start/stop server controls
- Real-time server output display
- Browser launch button

### Basic Workflow

1. **Select Model**: Click "Browse..." to locate your GGUF model file
2. **Configure Server**: Adjust port and thread settings as needed
3. **Start Server**: Click "Start Server" to launch the LLM server
4. **Monitor Output**: Watch server logs in the output area
5. **Access Interface**: Click "Start Browser" to open the web interface
6. **Stop Server**: Click "Stop Server" when finished

## Configuration

The application automatically saves your settings to `~/.pytola/llmserver.json`. Configuration includes:

- Last used model path
- Server port number
- Thread count
- Window position and size

## Supported Models

Works with GGUF format models compatible with llama.cpp:
- LLaMA family models
- Mistral models
- Phi models
- And other llama.cpp compatible models

## Development

### Running Tests

```bash
# Run unit tests
pytest pytola/llmserver/tests/

# Run with coverage
pytest pytola/llmserver/tests/ --cov=pytola.llmserver
```

### Building

```bash
# Install development dependencies
pip install -e .[dev]

# Run linter
ruff check pytola/llmserver/

# Format code
ruff format pytola/llmserver/
```

## Troubleshooting

### Common Issues

1. **"llama-server not found"**: Ensure llama.cpp is installed and in your PATH
2. **Model file not loading**: Verify the model file exists and is in GGUF format
3. **Port already in use**: Change the port number in server configuration
4. **Server fails to start**: Check model compatibility and system resources

### Logs

Server output is displayed in real-time in the GUI. For detailed debugging, check the console output when running from command line.

## Contributing

Contributions are welcome! Please:

1. Fork the repository
2. Create a feature branch
3. Add tests for new functionality
4. Ensure all tests pass
5. Submit a pull request

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Changelog

### v1.0.0
- Initial release
- GUI interface for LLM server management
- Model file selection and configuration
- Real-time server monitoring
- Persistent configuration storage
