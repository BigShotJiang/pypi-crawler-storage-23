"""pytest configuration for llmclient tests."""

import os
import sys

# Configure Qt to use offscreen platform on Windows to avoid GUI issues
if sys.platform == "win32":
    os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
