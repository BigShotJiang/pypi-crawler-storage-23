"""Benchmark tests for LSC Optimizer GUI."""

from __future__ import annotations

import pytest

# Check if PySide2 is available
try:
    from PySide2.QtWidgets import QApplication

    GUI_AVAILABLE = True
except ImportError:
    GUI_AVAILABLE = False

# Import GUI components conditionally
if GUI_AVAILABLE:
    try:
        from ..lscopt_gui import LSCOptimizerGUI
    except ImportError:
        try:
            from ..lscopt_gui import LSCOptimizerGUI
        except ImportError:
            GUI_AVAILABLE = False


@pytest.mark.skipif(not GUI_AVAILABLE, reason="PySide2 not available")
@pytest.mark.benchmark(group="gui")
def test_gui_window_creation(benchmark):
    """Benchmark GUI window creation time."""

    def create_window():
        app = QApplication.instance()
        if app is None:
            app = QApplication([])

        return LSCOptimizerGUI()

    window = benchmark(create_window)
    assert window is not None


@pytest.mark.skipif(not GUI_AVAILABLE, reason="PySide2 not available")
@pytest.mark.benchmark(group="gui")
def test_parameter_widget_creation(benchmark):
    """Benchmark parameter widget creation."""
    app = QApplication.instance()
    if app is None:
        app = QApplication([])

    def create_param_widget():
        from ..lscopt_gui import ParameterWidget

        return ParameterWidget("test", "Test Parameter", 1.0, 0.0, 10.0, 0.1)

    widget = benchmark(create_param_widget)
    assert widget.name == "test"


@pytest.mark.skipif(not GUI_AVAILABLE, reason="PySide2 not available")
@pytest.mark.benchmark(group="gui")
def test_config_loading(benchmark):
    """Benchmark configuration loading."""

    def load_config():
        from ..lscopt_gui import ConfigManager

        config_manager = ConfigManager()
        return config_manager.get_config()

    config = benchmark(load_config)
    assert config is not None


@pytest.mark.skipif(not GUI_AVAILABLE, reason="PySide2 not available")
@pytest.mark.benchmark(group="calculation")
def test_simple_calculation(benchmark):
    """Benchmark simple LSC calculation through GUI."""
    app = QApplication.instance()
    if app is None:
        app = QApplication([])

    def perform_calculation():
        from ..lscopt import LSCCurve

        lscc = LSCCurve()
        return lscc.x, lscc.R.cost

    result = benchmark(perform_calculation)
    assert result is not None
    assert len(result) == 2


@pytest.mark.skipif(not GUI_AVAILABLE, reason="PySide2 not available")
@pytest.mark.benchmark(group="plotting")
def test_plot_update(benchmark):
    """Benchmark plot update performance."""
    app = QApplication.instance()
    if app is None:
        app = QApplication([])

    def update_plot():
        from ..lscopt import LSCCurve
        from ..lscopt_gui import PlotWidget

        lscc = LSCCurve()
        plot_widget = PlotWidget()
        plot_widget.update_plot(lscc)
        return plot_widget

    plot_widget = benchmark(update_plot)
    assert plot_widget.ax is not None


if __name__ == "__main__":
    # Run benchmarks if executed directly
    pytest.main([__file__, "-v", "--benchmark-only"])
