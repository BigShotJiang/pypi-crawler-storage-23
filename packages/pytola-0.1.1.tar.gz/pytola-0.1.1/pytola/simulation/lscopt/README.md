# LSC Optimizer

LSC (Least Squares Curve fitting) Optimizer is a Python tool for optimizing LSC curves with a graphical user interface.

## Features

- **Interactive GUI**: User-friendly PySide2 interface for parameter adjustment
- **Real-time Visualization**: Live plotting of LSC curves using matplotlib
- **Persistent Configuration**: Automatic saving and loading of settings
- **Comprehensive Parameters**: Support for all LSC curve parameters
- **Error Handling**: Robust error handling and validation

## Installation

```bash
pip install -e .
```

## Requirements

- Python 3.8+
- PySide2
- NumPy
- SciPy
- Matplotlib

## Usage

### Command Line

Run the GUI application:

```bash
python -m pytola.lscopt.lscopt_gui
```

Or directly:

```bash
python lscopt_gui.py
```

### Programmatic Usage

```python
from pytola.lscopt.lscopt_gui import LSCOptimizerGUI
from PySide2.QtWidgets import QApplication
import sys

app = QApplication(sys.argv)
window = LSCOptimizerGUI()
window.show()
sys.exit(app.exec_())
```

## Parameters

The LSC optimizer supports the following parameters:

- **m**: First breakpoint (-5.0 to 0.0, default: -1.3)
- **m1**: Second breakpoint (-10.0 to 0.0, default: -2.4)
- **s**: Internal slope (0.0 to 10.0, default: 1.2183)
- **s1**: External slope (0.0 to 20.0, default: 8.1)
- **H**: Cutting height (0.0 to 5.0, default: 0.5)
- **m2**: Specific point (-2.0 to 2.0, default: 0.5)
- **H1**: Internal retention height (0.0 to 2.0, default: 0.2)
- **H2**: External retention height (0.0 to 2.0, default: 0.65)
- **J**: Overall angle (0.0 to 180.0, default: 80.0)
- **J1**: Internal angle (0.0 to 180.0, default: 40.0)

## GUI Interface

The GUI consists of two main panels:

### Left Panel - Parameters

- Scrollable parameter input section
- Real-time parameter adjustment
- Calculate button to perform optimization
- Reset button to restore default values

### Right Panel - Results & Visualization

- Calculation results display
- Interactive matplotlib plot
- Real-time curve visualization

## Configuration

Settings are automatically saved to `~/.pytola/lscopt.json` including:

- Window position and size
- Last used parameter values
- Application preferences

## Testing

Run unit tests:

```bash
pytest tests/test_lscopt_gui.py -v
```

Run benchmark tests:

```bash
pytest tests/test_benchmark.py --benchmark-only -v
```

## License

MIT License
