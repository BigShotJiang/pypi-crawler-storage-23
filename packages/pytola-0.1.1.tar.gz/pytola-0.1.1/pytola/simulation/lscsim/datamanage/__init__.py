"""Data management module for LSCSIM."""
