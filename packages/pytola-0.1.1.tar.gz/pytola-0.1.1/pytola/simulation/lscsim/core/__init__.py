"""Core module containing main application components."""
