"""UI components for different functional modules."""

from .analysis_view import AnalysisView
from .database_views import DatabaseViews
from .file_model_view import FileModelView
from .modeling_view import ModelingView
from .settings_view import SettingsView

__all__ = [
    "AnalysisView",
    "DatabaseViews",
    "FileModelView",
    "ModelingView",
    "SettingsView",
]
