"""Logging utilities for the application."""

from __future__ import annotations

import logging
import logging.handlers
from pathlib import Path

# Create logs directory
LOG_DIR = Path.home() / ".lscsim" / "logs"
LOG_DIR.mkdir(parents=True, exist_ok=True)

# Configure root logger
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    handlers=[
        logging.StreamHandler(),
        logging.handlers.RotatingFileHandler(
            LOG_DIR / "lscsim.log",
            maxBytes=10 * 1024 * 1024,  # 10MB
            backupCount=5,
        ),
    ],
)

# Create logger for the application
logger = logging.getLogger("lscsim")


def get_logger(name: str) -> logging.Logger:
    """Get a logger with the specified name."""
    return logging.getLogger(f"lscsim.{name}")
