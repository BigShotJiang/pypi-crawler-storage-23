# LSCSIM - Python-based Simulation System

A modern Python implementation of the simulation system based on PySide2 framework.

## Features

- Component-based architecture
- Modern GUI with PySide2
- Database integration
- Configuration management
- Modular design

## Installation

```bash
pip install -e .
```

## Development

Install development dependencies:

```bash
pip install -e .[dev]
```

## Usage

```python
from lscsim import main

if __name__ == "__main__":
    main()
```
