"""Multimedia module."""
