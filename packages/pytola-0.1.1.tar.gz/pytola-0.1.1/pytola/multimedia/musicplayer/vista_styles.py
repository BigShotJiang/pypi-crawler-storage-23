"""Vista Glass Style Definitions for Music Player."""

from typing import ClassVar, Dict


class VistaStyleManager:
    """Manager for Vista glass style themes."""

    # Vista Glass Style Color Schemes
    VISTA_LIGHT: ClassVar[Dict[str, str]] = {
        "primary": "#3b82f6",  # 主要蓝色调
        "secondary": "#2563eb",  # 次要蓝色调
        "glass_primary": "rgba(59, 130, 246, 0.7)",  # 半透明主要蓝
        "glass_secondary": "rgba(37, 99, 235, 0.7)",  # 半透明次要蓝
        "glass_accent": "rgba(245, 158, 11, 0.7)",  # 半透明强调色
        "background": "rgba(255, 255, 255, 0.85)",  # 半透明白色背景
        "surface": "rgba(248, 250, 252, 0.9)",  # 半透明表面
        "text": "#0f172a",
        "text_secondary": "#64748b",
        "accent": "#f59e0b",
        "success": "#10b981",
        "warning": "#f59e0b",
        "error": "#ef4444",
        "border": "rgba(203, 213, 225, 0.6)",  # 半透明边框
        "hover": "rgba(241, 245, 249, 0.7)",  # 半透明悬停
        "glass_effect": "rgba(255, 255, 255, 0.3)",  # 玻璃反射效果
    }

    VISTA_DARK: ClassVar[Dict[str, str]] = {
        "primary": "#60a5fa",
        "secondary": "#3b82f6",
        "glass_primary": "rgba(96, 165, 250, 0.7)",
        "glass_secondary": "rgba(59, 130, 246, 0.7)",
        "glass_accent": "rgba(251, 191, 36, 0.7)",
        "background": "rgba(15, 23, 42, 0.85)",
        "surface": "rgba(30, 41, 59, 0.9)",
        "text": "#f1f5f9",
        "text_secondary": "#94a3b8",
        "accent": "#fbbf24",
        "success": "#34d399",
        "warning": "#fbbf24",
        "error": "#f87171",
        "border": "rgba(51, 65, 85, 0.6)",
        "hover": "rgba(51, 65, 85, 0.7)",
        "glass_effect": "rgba(255, 255, 255, 0.1)",
    }

    @classmethod
    def get_vista_light_theme(cls) -> str:
        """Get Vista glass light theme stylesheet."""
        colors = cls.VISTA_LIGHT
        return cls._generate_vista_stylesheet(colors)

    @classmethod
    def get_vista_dark_theme(cls) -> str:
        """Get Vista glass dark theme stylesheet."""
        colors = cls.VISTA_DARK
        return cls._generate_vista_stylesheet(colors)

    @classmethod
    def _generate_vista_stylesheet(cls, colors: Dict[str, str]) -> str:
        """Generate Vista glass style stylesheet with transparency effects."""
        return f"""
/* Vista Glass Style Main Window */
QMainWindow {{
    background-color: {colors["background"]};
    font-family: 'Microsoft YaHei UI', 'Segoe UI', 'PingFang SC', sans-serif;
    font-size: 15px;
    border: 1px solid {colors["border"]};
}}

QWidget {{
    font-family: 'Microsoft YaHei UI', 'Segoe UI', 'PingFang SC', sans-serif;
    font-size: 15px;
    background-color: transparent;
}}

/* Vista玻璃中央部件 */
QWidget#centralWidget {{
    background-color: {colors["background"]};
    border-radius: 12px;
    border: 1px solid {colors["border"]};
}}

/* Vista标题栏 - 玻璃效果 */
QLabel#titleLabel {{
    font-size: 18px;
    font-weight: 600;
    color: {colors["text"]};
    padding: 12px 16px;
    border-bottom: 2px solid {colors["primary"]};
    font-family: 'Microsoft YaHei UI', 'Segoe UI', sans-serif;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    background-color: {colors["surface"]};
    border-top-left-radius: 12px;
    border-top-right-radius: 12px;
}}

/* Vista玻璃按钮基础样式 */
QPushButton {{
    background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                              stop:0 {colors["glass_primary"]},
                              stop:0.5 {colors["glass_secondary"]},
                              stop:1 rgba(29, 78, 216, 0.7));
    color: white;
    border: 1px solid {colors["primary"]};
    border-radius: 8px;
    padding: 8px 16px;
    font-size: 14px;
    font-weight: 500;
    font-family: 'Microsoft YaHei UI', 'Segoe UI', sans-serif;
    min-height: 32px;
    min-width: 80px;
    background-clip: padding-box;
}}

QPushButton:hover {{
    background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                              stop:0 {colors["glass_secondary"]},
                              stop:0.5 rgba(29, 78, 216, 0.8),
                              stop:1 rgba(30, 64, 175, 0.8));
    border: 1px solid {colors["secondary"]};
}}

QPushButton:pressed {{
    background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                              stop:0 rgba(29, 78, 216, 0.9),
                              stop:0.5 rgba(30, 64, 175, 0.9),
                              stop:1 rgba(23, 37, 84, 0.9));
}}

QPushButton:disabled {{
    background: rgba(148, 163, 184, 0.5);
    color: rgba(203, 213, 225, 0.7);
    border: 1px solid rgba(203, 213, 225, 0.3);
}}

/* Vista播放控制按钮 - 突出主要蓝色调 */
QPushButton#playButton {{
    background: qradialgradient(cx:0.5, cy:0.5, radius:0.8,
                               fx:0.5, fy:0.3,
                               stop:0 {colors["glass_primary"]},
                               stop:0.7 {colors["glass_secondary"]},
                               stop:1 rgba(29, 78, 216, 0.8));
    border: 2px solid {colors["primary"]};
    border-radius: 36px;
    min-width: 72px;
    min-height: 72px;
    font-size: 40px;
    font-weight: 600;
    color: white;
    padding: 16px;
}}

QPushButton#playButton:hover {{
    background: qradialgradient(cx:0.5, cy:0.5, radius:0.8,
                               fx:0.5, fy:0.3,
                               stop:0 {colors["glass_secondary"]},
                               stop:0.7 rgba(29, 78, 216, 0.9),
                               stop:1 rgba(30, 64, 175, 0.9));
    border-color: {colors["secondary"]};
}}

QPushButton#pauseButton {{
    background: qradialgradient(cx:0.5, cy:0.5, radius:0.8,
                               fx:0.5, fy:0.3,
                               stop:0 {colors["glass_primary"]},
                               stop:0.7 {colors["glass_secondary"]},
                               stop:1 rgba(29, 78, 216, 0.8));
    border: 2px solid {colors["primary"]};
    border-radius: 36px;
    min-width: 72px;
    min-height: 72px;
    font-size: 40px;
    font-weight: 600;
    color: white;
    padding: 16px;
}}

QPushButton#pauseButton:hover {{
    background: qradialgradient(cx:0.5, cy:0.5, radius:0.8,
                               fx:0.5, fy:0.3,
                               stop:0 {colors["glass_secondary"]},
                               stop:0.7 rgba(29, 78, 216, 0.9),
                               stop:1 rgba(30, 64, 175, 0.9));
    border-color: {colors["secondary"]};
}}

/* Vista次要控制按钮 - 使用次要色调 */
QPushButton#stopButton {{
    background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                              stop:0 {colors["glass_accent"]},
                              stop:1 rgba(192, 132, 9, 0.7));
    border: 2px solid {colors["accent"]};
    border-radius: 28px;
    min-width: 56px;
    min-height: 56px;
    font-size: 28px;
    font-weight: 600;
    color: white;
    padding: 12px;
}}

QPushButton#stopButton:hover {{
    background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                              stop:0 rgba(245, 158, 11, 0.9),
                              stop:1 rgba(192, 132, 9, 0.9));
    border-color: #d97706;
}}

QPushButton#modeButton {{
    background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                              stop:0 {colors["glass_accent"]},
                              stop:1 rgba(192, 132, 9, 0.7));
    border: 2px solid {colors["accent"]};
    border-radius: 28px;
    min-width: 56px;
    min-height: 56px;
    font-size: 28px;
    font-weight: 600;
    color: white;
    padding: 12px;
}}

QPushButton#modeButton:hover {{
    background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                              stop:0 rgba(245, 158, 11, 0.9),
                              stop:1 rgba(192, 132, 9, 0.9));
    border-color: #d97706;
}}

/* Vista导航按钮 - 辅助色调 */
QPushButton#prevButton, QPushButton#nextButton {{
    background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                              stop:0 rgba(100, 116, 139, 0.7),
                              stop:1 rgba(71, 85, 105, 0.7));
    border: 2px solid rgba(100, 116, 139, 0.8);
    border-radius: 24px;
    min-width: 48px;
    min-height: 48px;
    font-size: 20px;
    color: white;
    padding: 8px;
}}

QPushButton#prevButton:hover, QPushButton#nextButton:hover {{
    background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                              stop:0 rgba(100, 116, 139, 0.9),
                              stop:1 rgba(71, 85, 105, 0.9));
    border-color: rgba(71, 85, 105, 0.9);
}}

/* Vista进度控制区域 */
QWidget#progressSection {{
    background-color: {colors["surface"]};
    padding: 12px 16px;
    border-radius: 8px;
    margin: 8px;
}}

QWidget#mainControls {{
    background-color: {colors["surface"]};
    border-radius: 16px;
    padding: 16px;
    margin: 8px;
    border: 1px solid {colors["border"]};
}}

QWidget#bottomSection {{
    background-color: {colors["surface"]};
    padding: 12px 16px;
    border-radius: 8px;
    margin: 8px;
    border: 1px solid {colors["border"]};
}}

/* Vista时间标签 */
QLabel#currentTimeLabel, QLabel#totalTimeLabel {{
    font-size: 14px;
    font-family: 'Consolas', monospace;
    color: {colors["text_secondary"]};
    padding: 4px 8px;
    background-color: {colors["glass_effect"]};
    border-radius: 4px;
}}

QLabel#currentTimeLabel {{
    color: {colors["primary"]};
    font-weight: 600;
    border: 1px solid {colors["primary"]};
}}

/* Vista进度滑块 */
QSlider#progressSlider::groove:horizontal {{
    border: 1px solid {colors["border"]};
    height: 8px;
    background: {colors["surface"]};
    border-radius: 4px;
}}

QSlider#progressSlider::handle:horizontal {{
    background: qradialgradient(cx:0.5, cy:0.5, radius:0.6,
                               fx:0.5, fy:0.3,
                               stop:0 {colors["glass_primary"]},
                               stop:1 {colors["primary"]});
    border: 2px solid {colors["background"]};
    width: 20px;
    margin: -6px 0;
    border-radius: 10px;
}}

QSlider#progressSlider::handle:horizontal:hover {{
    background: qradialgradient(cx:0.5, cy:0.5, radius:0.6,
                               fx:0.5, fy:0.3,
                               stop:0 {colors["glass_secondary"]},
                               stop:1 {colors["secondary"]});
    border-color: {colors["primary"]};
}}

QSlider#progressSlider::sub-page:horizontal {{
    background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                              stop:0 {colors["primary"]},
                              stop:1 {colors["secondary"]});
    border-radius: 4px;
}}

/* Vista音量控制 */
QSlider#volumeSlider::groove:horizontal {{
    border: 1px solid {colors["border"]};
    height: 6px;
    background: {colors["surface"]};
    border-radius: 3px;
}}

QSlider#volumeSlider::handle:horizontal {{
    background: qradialgradient(cx:0.5, cy:0.5, radius:0.6,
                               fx:0.5, fy:0.3,
                               stop:0 {colors["glass_accent"]},
                               stop:1 {colors["accent"]});
    border: 1px solid {colors["background"]};
    width: 16px;
    margin: -5px 0;
    border-radius: 8px;
}}

QSlider#volumeSlider::sub-page:horizontal {{
    background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                              stop:0 {colors["accent"]},
                              stop:1 #d97706);
    border-radius: 3px;
}}

QLabel#volumeLabel {{
    color: {colors["text_secondary"]};
    font-size: 13px;
    padding: 0 6px;
    background-color: {colors["glass_effect"]};
    border-radius: 3px;
}}

/* Vista控制面板 */
QWidget#controlPanel {{
    background-color: {colors["surface"]};
    border: 1px solid {colors["border"]};
    border-radius: 12px;
    padding: 12px;
}}

/* Vista进度条 */
QProgressBar {{
    border: 1px solid {colors["border"]};
    border-radius: 6px;
    text-align: center;
    background-color: {colors["surface"]};
    color: {colors["text"]};
}}

QProgressBar::chunk {{
    background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                              stop:0 {colors["primary"]},
                              stop:1 {colors["secondary"]});
    border-radius: 5px;
}}

/* Vista列表视图 */
QListWidget {{
    background-color: {colors["surface"]};
    border: 1px solid {colors["border"]};
    border-radius: 8px;
    alternate-background-color: {colors["hover"]};
}}

QListWidget::item:selected {{
    background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                              stop:0 {colors["primary"]},
                              stop:1 {colors["secondary"]});
    color: white;
}}

QListWidget::item:hover {{
    background-color: {colors["hover"]};
}}
"""
