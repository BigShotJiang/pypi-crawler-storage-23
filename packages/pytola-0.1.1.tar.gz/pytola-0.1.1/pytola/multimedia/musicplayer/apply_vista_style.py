#!/usr/bin/env python3
"""External Vista Style Application Script."""

from __future__ import annotations

import sys
from pathlib import Path

# 添加项目路径
sys.path.insert(0, str(Path(__file__).parent.parent))

try:
    import logging

    from PySide2.QtWidgets import QApplication

    from pytola.multimedia.musicplayer.vista_styles import VistaStyleManager

    logging.basicConfig(level=logging.INFO)
    logger = logging.getLogger(__name__)

    def apply_vista_style_to_existing_app() -> bool | None:
        """Apply Vista glass style to existing music player application."""
        app = QApplication.instance()
        if app is None:
            logger.warning("No Qt application instance found")
            return False

        try:
            # 应用Vista玻璃主题
            vista_theme = VistaStyleManager.get_vista_light_theme()
            app.setStyleSheet(vista_theme)
            logger.info("Successfully applied Vista glass theme")
            return True
        except Exception as e:
            logger.exception(f"Failed to apply Vista theme: {e}")
            return False

    if __name__ == "__main__":
        # 这个脚本应该由主程序调用
        pass

except ImportError:
    pass
