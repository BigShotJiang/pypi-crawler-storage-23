"""Tests for img2ico module."""

from __future__ import annotations
