"""Tests for img2ico GUI application."""

from __future__ import annotations

import sys
from pathlib import Path

import pytest


# Test basic imports
def test_gui_imports():
    """Test that GUI module can be imported."""
    try:
        from pytola.img2ico import img2ico_gui

        assert img2ico_gui is not None
    except ImportError:
        pytest.skip("PySide2 not installed")


def test_config_manager_creation():
    """Test ConfigManager initialization."""
    try:
        from pytola.office.img2ico.img2ico_gui import ConfigManager

        config_manager = ConfigManager()
        assert config_manager is not None
        assert config_manager.config is not None
    except ImportError:
        pytest.skip("PySide2 not installed")


def test_config_defaults():
    """Test configuration default values."""
    try:
        from pytola.office.img2ico.img2ico_gui import Img2IcoConfig

        config = Img2IcoConfig()
        assert config.input_path is not None
        assert config.sizes == "16,24,32,48,64,128,256,512,1024"
        assert config.quality == "high"
        assert config.recent_input_paths == []
        assert config.recent_output_paths == []
    except ImportError:
        pytest.skip("PySide2 not installed")


def test_worker_signals():
    """Test WorkerSignals creation."""
    try:
        from pytola.office.img2ico.img2ico_gui import WorkerSignals

        signals = WorkerSignals()
        assert signals is not None
        assert hasattr(signals, "progress_message")
        assert hasattr(signals, "progress_update")
        assert hasattr(signals, "finished")
        assert hasattr(signals, "error")
    except ImportError:
        pytest.skip("PySide2 not installed")


@pytest.mark.skipif("PySide2" not in sys.modules, reason="PySide2 not installed")
def test_gui_window_creation(qtbot):
    """Test GUI window can be created."""
    try:
        from pytola.office.img2ico.img2ico_gui import Img2IcoGUI

        window = Img2IcoGUI()
        qtbot.addWidget(window)

        assert window is not None
        assert window.windowTitle() == "Image to ICO Converter"
        assert window.convert_btn is not None
        assert window.input_edit is not None
        assert window.output_edit is not None
        assert window.sizes_edit is not None
        assert window.quality_combo is not None
    except ImportError:
        pytest.skip("PySide2 not installed")


@pytest.mark.skipif("PySide2" not in sys.modules, reason="PySide2 not installed")
def test_gui_initial_state(qtbot):
    """Test GUI initial state."""
    try:
        from pytola.office.img2ico.img2ico_gui import Img2IcoGUI

        window = Img2IcoGUI()
        qtbot.addWidget(window)

        # Check initial button state
        assert window.convert_btn.isEnabled()
        assert not window.is_converting

        # Check initial progress
        assert window.progress_bar.value() == 0
    except ImportError:
        pytest.skip("PySide2 not installed")


def test_config_persistence():
    """Test configuration save and load."""
    try:
        import tempfile

        from pytola.office.img2ico.img2ico_gui import ConfigManager

        # Use temporary config file
        with tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False) as f:
            config_file = Path(f.name)

        try:
            # Create config manager
            config_manager = ConfigManager(config_file=config_file)

            # Set some values
            config_manager.set("input_path", "/test/path")
            config_manager.set("quality", "medium")
            config_manager.set("sizes", "16,32,64")

            # Save config
            config_manager.save_config()

            # Load config again
            config_manager2 = ConfigManager(config_file=config_file)

            # Verify values persisted
            assert config_manager2.get("input_path") == "/test/path"
            assert config_manager2.get("quality") == "medium"
            assert config_manager2.get("sizes") == "16,32,64"
        finally:
            # Cleanup
            if config_file.exists():
                config_file.unlink()
    except ImportError:
        pytest.skip("PySide2 not installed")
