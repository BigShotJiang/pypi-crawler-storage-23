"""Zip encryption utility module."""

from .zipencrypt import (
    CONFIG_FILE,
    EncryptZipConfig,
    _create_encrypted_zip,
    _create_unencrypted_zip,
    _execute_command,
    _get_valid_entries,
    _make_archive,
    conf,
    encrypt_zip,
    logger,
)

# Export all public API
__all__ = [
    "CONFIG_FILE",
    "EncryptZipConfig",
    "_create_encrypted_zip",
    "_create_unencrypted_zip",
    "_execute_command",
    "_get_valid_entries",
    "_make_archive",
    "conf",
    "encrypt_zip",
    "logger",
]
