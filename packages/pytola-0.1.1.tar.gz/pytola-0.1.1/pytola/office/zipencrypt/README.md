# ZipEncrypt

A utility for encrypting files and directories into password-protected ZIP archives.

## Features

- Supports multiple encryption tools (7z, zip, rar)
- Falls back to standard zipfile when external tools unavailable
- Parallel processing for multiple files
- Configurable password and worker settings
- Skip hidden and system directories

## Installation

```bash
pip install zipencrypt
```

## Usage

### Command Line

```bash
# Encrypt files in current directory
zipencrypt

# Encrypt files in specific directory with custom password
zipencrypt /path/to/files mypassword

# Replace existing archives
zipencrypt --replace
```

### Python API

```python
from pytola.zipencrypt import encrypt_zip

# Encrypt with default settings
encrypt_zip()

# Encrypt with custom settings
encrypt_zip("/path/to/files", "mypassword", replace=True)
```

## Configuration

The module uses TOML configuration files. Default settings:

```toml
[PASSWORD]
default = "DEFAULT_PASSWORD"

[MAX_NAME_LEN]
default = 20

[MAX_FILE_COUNT]
default = 5

[MAX_WORKERS]
default = 10
```

## Supported Tools

1. **7-Zip** (`7z`) - AES-256 encryption
2. **Info-ZIP** (`zip`) - Standard ZIP encryption
3. **RAR** (`rar`) - RAR encryption
4. **Fallback** - Standard zipfile (no encryption)

## Requirements

- Python >= 3.8
- One of: 7z, zip, or rar command-line tools (optional but recommended)

## License

MIT
