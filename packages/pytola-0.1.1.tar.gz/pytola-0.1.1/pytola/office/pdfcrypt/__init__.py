"""PDF encryption/decryption utilities.

This module provides functionality to encrypt and decrypt PDF files
using strong encryption algorithms. It supports batch processing
of multiple files with configurable passwords and security settings.
"""

from .pdfcrypt import PDFCryptConfig, conf, decrypt, decrypt_pdf, encrypt, encrypt_pdf, is_encrypted, main

__all__ = [
    "PDFCryptConfig",
    "conf",
    "decrypt",
    "decrypt_pdf",
    "encrypt",
    "encrypt_pdf",
    "is_encrypted",
    "main",
]

__version__ = "0.1.1"
