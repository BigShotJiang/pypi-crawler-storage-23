"""Tests for quizbase module."""
