# DocDiff - Word Document Comparison Tool

DocDiff is a Python tool that compares two Microsoft Word documents (.doc/.docx) and generates a comparison report highlighting the differences between them.

## Features

- Compares two Word documents and highlights differences
- Supports both .doc and .docx file formats
- Configurable comparison options
- Automatic configuration persistence
- Command-line interface for easy automation

## Installation

This module is part of the pytola package. Make sure you have the required dependencies:

```bash
pip install pywin32
```

Note: This tool only works on Windows systems with Microsoft Word installed.

## Usage

### Command Line Interface

```bash
# Basic usage
python -m pytola.docdiff old_document.docx new_document.docx

# Specify output directory
python -m pytola.docdiff old_document.docx new_document.docx --output-dir ./results

# Customize the comparison title
python -m pytola.docdiff old_document.docx new_document.docx --title "My Comparison Report"

# Control change visibility
python -m pytola.docdiff old_document.docx new_document.docx --show-changes
python -m pytola.docdiff old_document.docx new_document.docx --hide-changes

# Specify comparison mode
python -m pytola.docdiff old_document.docx new_document.docx --compare-mode original
python -m pytola.docdiff old_document.docx new_document.docx --compare-mode revised

# Specify custom output path
python -m pytola.docdiff old_document.docx new_document.docx -o ./output/comparison_result.docx
```

### Configuration

The tool automatically saves and loads configuration from `~/.pytola/docdiff.json`. The configuration includes:

- `DOC_DIFF_TITLE`: Title for the comparison result
- `OUTPUT_DIR`: Directory for output files
- `COMPARE_MODE`: Comparison mode (original/revised)
- `SHOW_CHANGES`: Whether to show changes in the comparison
- `TRACK_REVISIONS`: Whether to track revisions

## Programmatic Usage

```python
from pytola.office.docdiff.docdiff import diff_doc
from pathlib import Path

# Compare two documents
old_file = Path("old_document.docx")
new_file = Path("new_document.docx")
diff_doc(old_file, new_file)
```

## Configuration API

```python
from pytola.office.docdiff.docdiff import DocDiffConfig

# Access current configuration
config = DocDiffConfig()
print(config.DOC_DIFF_TITLE)

# Modify configuration (will be saved on program exit)
config.DOC_DIFF_TITLE = "New Title"
config.SHOW_CHANGES = False
```

## Requirements

- Windows operating system
- Microsoft Word installed
- Python 3.8+
- pywin32 package

## Testing

Run the unit tests:

```bash
python -m pytest pytola/docdiff/tests/test_docdiff.py
```

Run the benchmark tests:

```bash
python -m pytest pytola/docdiff/tests/test_benchmark.py
```

## License

This project is part of pytola and is licensed under the terms specified in the main project repository.
