"""Benchmark tests for docdiff module."""

import contextlib
from unittest.mock import MagicMock, patch

import pytest

from pytola.office.docdiff.docdiff import DiffDocCommand, DocDiffConfig


class TestDocDiffBenchmark:
    """Benchmark tests for docdiff functionality."""

    @pytest.mark.benchmark(group="config_operations")
    def test_config_creation_benchmark(self, benchmark):
        """Benchmark configuration creation."""
        result = benchmark(DocDiffConfig)
        assert result is not None

    @pytest.mark.benchmark(group="config_operations")
    def test_config_save_benchmark(self, benchmark, tmp_path):
        """Benchmark configuration save operation."""
        # Create a temporary config file
        temp_config_file = tmp_path / "benchmark_config.json"

        # Patch the global CONFIG_FILE
        with patch("pytola.office.docdiff.docdiff.CONFIG_FILE", temp_config_file):
            config = DocDiffConfig()

            result = benchmark(config.save)
            assert result is None


def test_command_creation_benchmark(benchmark, tmp_path):
    """Benchmark DiffDocCommand creation."""
    old_file = tmp_path / "old.docx"
    new_file = tmp_path / "new.docx"
    output_path = tmp_path / "output"

    old_file.touch()
    new_file.touch()

    def create_command():
        return DiffDocCommand(old_file, new_file, output_path)

    result = benchmark(create_command)
    assert result is not None


def test_full_workflow_benchmark(benchmark, tmp_path):
    """Benchmark the full workflow including config and command."""

    def full_workflow():
        # Create config
        _ = DocDiffConfig()

        # Create dummy files
        old_file = tmp_path / "old_bench.docx"
        new_file = tmp_path / "new_bench.docx"

        old_file.touch()
        new_file.touch()

        # Create command
        command = DiffDocCommand(old_file, new_file)

        # Mock the win32com import and Word operations
        with patch.dict("sys.modules", {"win32com": MagicMock(), "win32com.client": MagicMock()}):
            import win32com.client as win32

            with patch.object(win32.gencache, "EnsureDispatch") as mock_dispatch:
                mock_word_app = MagicMock()
                mock_dispatch.return_value = mock_word_app

                mock_doc_old = MagicMock()
                mock_doc_new = MagicMock()
                mock_doc_compare = MagicMock()

                # Configure the mocked documents
                mock_word_app.Documents.Open.side_effect = [mock_doc_old, mock_doc_new]
                mock_word_app.CompareDocuments.return_value = mock_doc_compare

                # We can't call run() directly because of the complex property dependencies
                # So we'll just test property access
                with contextlib.suppress(BaseException):
                    _ = command.validate_files

    benchmark(full_workflow)


if __name__ == "__main__":
    # Run benchmark tests
    pytest.main([__file__, "-v", "--benchmark-only", "--benchmark-sort=fullname"])
