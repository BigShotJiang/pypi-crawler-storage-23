"""Alarmclock module."""

from .gui import main

__all__ = ["main"]
