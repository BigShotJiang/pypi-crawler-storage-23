"""Document scanner module for scanning and extracting content from various document formats."""

__version__ = "0.1.1"
