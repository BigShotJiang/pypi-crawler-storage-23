"""GUI components for Resource Hacker."""
