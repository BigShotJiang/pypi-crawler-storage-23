"""Reshack module."""

from .cli import main
from .gui import main as gui_main

__all__ = [
    "gui_main",
    "main",
]
