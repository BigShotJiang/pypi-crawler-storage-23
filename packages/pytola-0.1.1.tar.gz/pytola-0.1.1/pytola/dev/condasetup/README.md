# Conda Setup Tool

A command-line tool for configuring Conda environments with popular Chinese mirrors for faster package installation.

## Features

- **Multiple mirror support**: Configures Conda to use popular Chinese mirrors
- **Automatic backup**: Backs up existing `.condarc` configuration before making changes
- **Channel configuration**: Automatically adds essential channels including conda-forge, bioconda, and pytorch
- **Easy to use**: Simple command-line interface with intuitive options

## Supported Mirrors

- **Tsinghua** (`tsinghua`): 清华大学开源软件镜像站
- **USTC** (`ustc`): 中国科学技术大学镜像站  
- **BSFU** (`bsfu`): 北京师范大学镜像站
- **Aliyun** (`aliyun`): 阿里云镜像站

## Installation

Install the package in development mode:

```bash
pip install -e .
```

## Usage

### Basic Usage

Configure Conda to use Tsinghua mirror (default):

```bash
condasetup
```

### Specify Different Mirror

Use USTC mirror:

```bash
condasetup ustc
```

Use Aliyun mirror:

```bash
condasetup aliyun
```

### View Help

```bash
condasetup --help
```

## Command Line Options

- `mirror`: Mirror name (tsinghua, ustc, bsfu, or aliyun) - default: tsinghua
- `-d, --debug`: Enable debug mode for verbose output
- `-h, --help`: Show help message

## Configuration Changes

The tool will:

1. Backup existing `.condarc` file to `.condarc.bak` if it exists
2. Add mirror URLs for main, free, r, msys2, pro, dev channels
3. Add cloud channels for conda-forge, bioconda, menpo, and pytorch
4. Enable `show_channel_urls` for better visibility

## Example Output

```
Found existing .condarc file, backing it up
Conda mirror set successfully
```

## Channels Added

The following channels will be configured:

### Main Channels
- pkgs/main/
- pkgs/free/
- pkgs/r/
- pkgs/msys2/
- pkgs/pro/
- pkgs/dev/

### Cloud Channels
- cloud/conda-forge/
- cloud/bioconda/
- cloud/menpo/
- cloud/pytorch/

## Dependencies

- Python 3.7+
- conda (must be installed and in PATH)

## Troubleshooting

### Permission Issues

If you encounter permission errors, try running with elevated privileges:

```bash
sudo condasetup tsinghua
```

### Verification

Verify the configuration was applied:

```bash
conda config --show-sources
```

### Restore Original Configuration

If needed, restore the original configuration:

```bash
mv ~/.condarc.bak ~/.condarc
```

## Development

### Running Tests

```bash
python -m pytest tests/ -v
```

### Code Structure

- `condasetup.py`: Main module with configuration logic
- `_CONDA_MIRROR_URLS`: Dictionary mapping mirror names to URL lists
- `set_conda_mirror()`: Main function that applies the configuration

## License

MIT License
