# piptool - Python包管理工具

piptool 是一个简化 pip 命令操作的工具, 提供了更便捷的包管理功能。

## 功能特性

- 📦 **包安装与卸载** - 简化的安装、卸载、重新安装操作
- ⬇️ **包下载** - 支持在线和离线包下载
- 📋 **依赖管理** - 生成和管理 requirements.txt 文件
- 🔍 **包查询** - 列出已安装包、查看包详情
- ✅ **依赖检查** - 检查依赖冲突
- 🔄 **批量操作** - 支持从 requirements 文件批量操作

## 安装

```bash
# 从源码安装
pip install .

# 或者直接使用
python -m pip install .
```

## 使用方法

### 基本命令

```bash
# 显示帮助信息
piptool --help

# 显示版本信息
piptool --version
```

### 包安装

```bash
# 安装单个包
piptool install requests

# 安装多个包
piptool install numpy pandas matplotlib

# 升级已安装的包
piptool install requests --upgrade
# 或使用别名
piptool i requests -U

# 从 requirements 文件安装
piptool install-req
# 或指定文件
piptool install-req --file requirements-dev.txt
# 别名
piptool ir -f requirements-dev.txt
```

### 包下载

```bash
# 下载包到本地
piptool download requests pandas
# 别名
piptool d requests pandas

# 从 requirements 文件下载
piptool download-req
# 或指定文件
piptool download-req --file requirements.txt
# 别名
piptool dr -f requirements.txt
```

### 包卸载

```bash
# 卸载包
piptool uninstall requests
# 别名
piptool u requests

# 从 requirements 文件卸载
piptool uninstall-req
# 或指定文件
piptool uninstall-req --file requirements.txt
# 别名
piptool ur -f requirements.txt
```

### 依赖管理

```bash
# 生成 requirements.txt
piptool freeze
# 或指定输出文件
piptool freeze --output requirements-prod.txt
# 别名
piptool f -o requirements-prod.txt

# 包含可编辑安装的包
piptool freeze --include-editable
```

### 包查询

```bash
# 列出所有已安装的包
piptool list
# 别名
piptool l

# 列出过期的包
piptool list --outdated
# 别名
piptool l -o

# 按模式过滤包
piptool list --pattern django
# 别名
piptool l -p django
```

### 包信息查看

```bash
# 查看包详细信息
piptool show requests
# 别名
piptool s requests
```

### 依赖检查

```bash
# 检查依赖冲突
piptool check
# 别名
piptool c
```

### 其他功能

```bash
# 离线安装包
piptool install-offline requests pandas
# 或指定包目录
piptool install-offline requests --find-links ./packages
# 别名
piptool io requests -f ./packages

# 重新安装包
piptool reinstall requests
# 别名
piptool r requests

# 升级 pip 本身
piptool upgrade-pip
# 别名
piptool up
```

## 配置说明

piptool 默认使用阿里云镜像源以提高下载速度:

```
--trusted-host mirrors.aliyun.com
-i http://mirrors.aliyun.com/pypi/simple/
```

下载的包默认保存在 `packages` 目录下。

## 开发

### 运行测试

```bash
# 直接运行
python piptool.py --help

# 安装后运行
pip install -e .
piptool --help
```

### 代码结构

```
piptool/
├── piptool.py      # 主程序文件
├── pyproject.toml  # 项目配置
└── README.md       # 说明文档
```

## 许可证

MIT License

## 贡献

欢迎提交 Issue 和 Pull Request!
