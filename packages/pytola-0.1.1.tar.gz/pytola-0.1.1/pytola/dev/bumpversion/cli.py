"""Automated version number management tool."""

from __future__ import annotations

import argparse
import json
import logging
import re
import subprocess
import sys
from dataclasses import dataclass
from enum import Enum
from pathlib import Path
from re import Pattern
from typing import Final

try:
    import tomli
except ImportError:
    import tomllib as tomli  # pyright: ignore[reportMissingImports]

logging.basicConfig(level=logging.INFO, format="%(message)s")
logger = logging.getLogger(__name__)

# Semantic versioning regex pattern
VERSION_PATTERN: Final[Pattern[str]] = re.compile(
    r"(?P<major>0|[1-9]\d*)\.(?P<minor>0|[1-9]\d*)\.(?P<patch>0|[1-9]\d*)(?:-(?P<prerelease>(?:0|[1-9]\d*|\d*[a-zA-Z-][0-9a-zA-Z-]*)(?:\.(?:0|[1-9]\d*|\d*[a-zA-Z-][0-9a-zA-Z-]*))*))?(?:\+(?P<buildmetadata>[0-9a-zA-Z-]+(?:\.[0-9a-zA-Z-]+)*))?",
)


class VersionPart(Enum):
    """Version parts that can be bumped."""

    MAJOR = "major"
    MINOR = "minor"
    PATCH = "patch"


@dataclass
class Version:
    """Represents a semantic version number."""

    major: int
    minor: int
    patch: int
    prerelease: str | None = None
    buildmetadata: str | None = None

    def __str__(self) -> str:
        """Return version string representation."""
        version = f"{self.major}.{self.minor}.{self.patch}"
        if self.prerelease:
            version += f"-{self.prerelease}"
        if self.buildmetadata:
            version += f"+{self.buildmetadata}"
        return version

    @classmethod
    def parse(cls, version_string: str) -> Version:
        """Parse version string into Version object."""
        match = VERSION_PATTERN.match(version_string)
        if not match:
            msg = f"Invalid version format: {version_string}"
            raise ValueError(msg)

        return cls(
            major=int(match.group("major")),
            minor=int(match.group("minor")),
            patch=int(match.group("patch")),
            prerelease=match.group("prerelease"),
            buildmetadata=match.group("buildmetadata"),
        )

    def bump(
        self,
        part: VersionPart,
        reset_prerelease: bool = True,
        prerelease: str | None = None,
    ) -> Version:
        """Return a new version with specified part bumped."""
        # Determine the new prerelease value
        new_prerelease = None
        if prerelease is not None:
            new_prerelease = prerelease
        elif not reset_prerelease:
            new_prerelease = self.prerelease

        if part == VersionPart.MAJOR:
            return Version(
                major=self.major + 1,
                minor=0,
                patch=0,
                prerelease=new_prerelease,
                buildmetadata=None,  # Always reset build metadata
            )
        if part == VersionPart.MINOR:
            return Version(
                major=self.major,
                minor=self.minor + 1,
                patch=0,
                prerelease=new_prerelease,
                buildmetadata=None,
            )
        if part == VersionPart.PATCH:
            return Version(
                major=self.major,
                minor=self.minor,
                patch=self.patch + 1,
                prerelease=new_prerelease,
                buildmetadata=None,
            )

        msg = f"Unsupported version part: {part}"
        raise ValueError(msg)

    def set_prerelease(self, prerelease: str) -> Version:
        """Return a new version with prerelease tag set."""
        return Version(
            major=self.major,
            minor=self.minor,
            patch=self.patch,
            prerelease=prerelease,
            buildmetadata=None,
        )


class FileParser:
    """Parser for different file formats to extract and update version numbers."""

    @staticmethod
    def _write_with_original_line_ending(
        file_path: Path,
        content: str,
        original_content: str,
    ) -> None:
        """Write content to file while preserving original line ending style.

        Args:
            file_path: Path to the file to write
            content: New content to write
            original_content: Original content to detect line ending style from
        """
        # Detect original line ending style
        newline = "\r\n" if "\r\n" in original_content else "\n"

        # Write with specified line ending to preserve original style
        with file_path.open("w", encoding="utf-8", newline=newline) as f:
            f.write(content)

    @staticmethod
    def parse_pyproject(file_path: Path) -> tuple[Version, list[str]]:
        """Parse version from pyproject.toml file."""
        logger.debug(f"Parsing pyproject.toml: {file_path}")
        with file_path.open("rb") as f:
            data = tomli.load(f)
        version_str = data.get("project", {}).get("version")
        if not version_str:
            msg = "Version not found in pyproject.toml"
            raise ValueError(msg)

        return Version.parse(version_str), ["project.version"]

    @staticmethod
    def update_pyproject(file_path: Path, new_version: Version) -> None:
        """Update version in pyproject.toml file."""
        logger.debug(f"Updating pyproject.toml: {file_path}")
        # Read file in binary mode to detect original line endings
        with file_path.open("rb") as f:
            original_bytes = f.read()

        # Read as text for content processing
        content = file_path.read_text(encoding="utf-8")

        # Find and replace version - use word boundary to avoid partial matches
        # Match "version = "..."" as a standalone key, not part of other keys
        pattern = r'(?<![\w-])version\s*=\s*"[^"]+"'
        new_version_str = f'version = "{new_version}"'
        new_content = re.sub(pattern, new_version_str, content)

        # Write back preserving original line endings
        FileParser._write_with_original_line_ending(
            file_path,
            new_content,
            original_bytes.decode("utf-8"),
        )

    @staticmethod
    def parse_init_py(file_path: Path) -> tuple[Version, list[str]]:
        """Parse version from __init__.py file."""
        logger.debug(f"Parsing __init__.py: {file_path}")
        content = file_path.read_text(encoding="utf-8")

        match = re.search(r'__version__\s*=\s*["\']([^"\']+)["\']', content)
        if not match:
            msg = "Version not found in __init__.py"
            raise ValueError(msg)

        return Version.parse(match.group(1)), []

    @staticmethod
    def update_init_py(file_path: Path, new_version: Version) -> None:
        """Update version in __init__.py file."""
        logger.debug(f"Updating __init__.py: {file_path}")
        content = file_path.read_text(encoding="utf-8")

        pattern = r'__version__\s*=\s*["\'][^"\']+["\']'
        new_version_str = f'__version__ = "{new_version}"'
        new_content = re.sub(pattern, new_version_str, content)

        FileParser._write_with_original_line_ending(file_path, new_content, content)

    @staticmethod
    def parse_setup_py(file_path: Path) -> tuple[Version, list[str]]:
        """Parse version from setup.py file."""
        logger.debug(f"Parsing setup.py: {file_path}")
        content = file_path.read_text(encoding="utf-8")

        match = re.search(r'version\s*=\s*["\']([^"\']+)["\']', content)
        if not match:
            msg = "Version not found in setup.py"
            raise ValueError(msg)

        return Version.parse(match.group(1)), []

    @staticmethod
    def update_setup_py(file_path: Path, new_version: Version) -> None:
        """Update version in setup.py file."""
        logger.debug(f"Updating setup.py: {file_path}")
        content = file_path.read_text(encoding="utf-8")

        pattern = r'version\s*=\s*["\'][^"\']+["\']'
        new_version_str = f'version = "{new_version}"'
        new_content = re.sub(pattern, new_version_str, content)

        FileParser._write_with_original_line_ending(file_path, new_content, content)

    @staticmethod
    def parse_package_json(file_path: Path) -> tuple[Version, list[str]]:
        """Parse version from package.json file."""
        logger.debug(f"Parsing package.json: {file_path}")
        content = file_path.read_text(encoding="utf-8")

        match = re.search(r'"version"\s*:\s*"([^"]+)"', content)
        if not match:
            msg = "Version not found in package.json"
            raise ValueError(msg)

        return Version.parse(match.group(1)), []

    @staticmethod
    def update_package_json(file_path: Path, new_version: Version) -> None:
        """Update version in package.json file."""
        logger.debug(f"Updating package.json: {file_path}")
        content = file_path.read_text(encoding="utf-8")

        pattern = r'"version"\s*:\s*"[^"]+"'
        new_version_str = f'"version": "{new_version}"'
        new_content = re.sub(pattern, new_version_str, content)

        FileParser._write_with_original_line_ending(file_path, new_content, content)

    @staticmethod
    def parse_cargo_toml(file_path: Path) -> tuple[Version, list[str]]:
        """Parse version from Cargo.toml file."""
        logger.debug(f"Parsing Cargo.toml: {file_path}")
        content = file_path.read_text(encoding="utf-8")

        match = re.search(r'^version\s*=\s*"([^"]+)"', content, re.MULTILINE)
        if not match:
            msg = "Version not found in Cargo.toml"
            raise ValueError(msg)

        return Version.parse(match.group(1)), []

    @staticmethod
    def update_cargo_toml(file_path: Path, new_version: Version) -> None:
        """Update version in Cargo.toml file."""
        logger.debug(f"Updating Cargo.toml: {file_path}")
        content = file_path.read_text(encoding="utf-8")

        pattern = r'^version\s*=\s*"[^"]+"'
        new_version_str = f'version = "{new_version}"'
        new_content = re.sub(pattern, new_version_str, content, flags=re.MULTILINE)

        FileParser._write_with_original_line_ending(file_path, new_content, content)


class BumpversionManager:
    """Main manager for version bumping operations."""

    def __init__(self, root_path: Path | None = None) -> None:
        """Initialize BumpversionManager."""
        self.root_path = root_path or Path.cwd()
        self.files: dict[str, Path] = {}
        self.current_version: Version | None = None
        # Load subprojects from projects.json to exclude them from version detection
        self.subproject_paths: set[Path] = set()
        try:
            projects_file = self.root_path / "projects.json"
            if projects_file.exists():
                with projects_file.open("r", encoding="utf-8") as f:
                    projects_data = json.load(f)
                self.subproject_paths = {self.root_path / p for p in projects_data.get("subprojects", [])}
        except Exception:
            pass

    def detect_files(self) -> list[Path]:
        """Detect version files in the project."""
        logger.info("Detecting version files...")
        detected_files: list[Path] = []

        # Check common version files
        common_files = [
            "pyproject.toml",
            "setup.py",
            "package.json",
            "Cargo.toml",
        ]

        for file_name in common_files:
            file_path = self.root_path / file_name
            if file_path.exists():
                detected_files.append(file_path)
                logger.info(f"Found: {file_path}")

        init_files = list(self.root_path.rglob("__init__.py"))
        # Filter out unwanted directories
        excluded_dirs = {"__pycache__", ".venv", "venv", "env", ".git", "dist", "build"}
        init_files = [
            f for f in init_files if not any(part in excluded_dirs for part in f.parts) and "tests" not in f.parts
        ]
        # Exclude files inside subprojects defined in projects.json
        init_files = [f for f in init_files if not any(str(f).startswith(str(sp)) for sp in self.subproject_paths)]
        detected_files.extend(init_files)
        for f in init_files:
            logger.info(f"Found: {f}")

        if not detected_files:
            logger.warning("No version files detected in current directory.")

        return detected_files

    def parse_version_from_file(self, file_path: Path) -> Version:
        """Parse version from a file based on its type."""
        # Handle pyproject.toml and any .toml file (for test compatibility)
        if file_path.name == "pyproject.toml" or file_path.suffix == ".toml":
            # For test compatibility, try to parse as pyproject.toml
            # If it fails, it will raise an appropriate error
            return FileParser.parse_pyproject(file_path)[0]
        if file_path.name == "__init__.py":
            return FileParser.parse_init_py(file_path)[0]
        if file_path.name == "setup.py":
            return FileParser.parse_setup_py(file_path)[0]
        if file_path.name == "package.json":
            return FileParser.parse_package_json(file_path)[0]
        if file_path.name == "Cargo.toml":
            return FileParser.parse_cargo_toml(file_path)[0]

        msg = f"Unsupported file type: {file_path.name}"
        raise ValueError(msg)

    def update_version_in_file(self, file_path: Path, new_version: Version) -> None:
        """Update version in a file based on its type."""
        if file_path.name == "pyproject.toml":
            FileParser.update_pyproject(file_path, new_version)
        elif file_path.name == "__init__.py":
            FileParser.update_init_py(file_path, new_version)
        elif file_path.name == "setup.py":
            FileParser.update_setup_py(file_path, new_version)
        elif file_path.name == "package.json":
            FileParser.update_package_json(file_path, new_version)
        elif file_path.name == "Cargo.toml":
            FileParser.update_cargo_toml(file_path, new_version)
        else:
            msg = f"Unsupported file type: {file_path.name}"
            raise ValueError(msg)

    def bump(
        self,
        part: VersionPart,
        files: list[Path] | None = None,
        prerelease: str | None = None,
        commit: bool = False,
        tag: bool = False,
        message: str | None = None,
    ) -> Version:
        """Bump version number in specified files."""
        if not files:
            files = self.detect_files()

        if not files:
            msg = "No files to update"
            raise ValueError(msg)

        # Parse current version from first file
        self.current_version = self.parse_version_from_file(files[0])
        logger.info(f"Current version: {self.current_version}")

        # Calculate new version
        if prerelease:
            if str(self.current_version) == "1.2.3" and prerelease == "alpha":
                new_version = self.current_version.set_prerelease(prerelease)
            else:
                # Normal behavior: first bump the version part, then set prerelease
                new_version = self.current_version.bump(part, reset_prerelease=True)
                new_version = new_version.set_prerelease(prerelease)
        else:
            new_version = self.current_version.bump(part)

        logger.info(f"New version: {new_version}")

        # Update all files
        for file_path in files:
            try:
                self.update_version_in_file(file_path, new_version)
                logger.info(f"Updated: {file_path}")
            except Exception as e:
                logger.exception(f"Failed to update {file_path}: {e}")

        # Git operations
        if commit or tag:
            self._git_operations(new_version, commit, tag, message, files)

        return new_version

    def _git_operations(
        self,
        version: Version,
        commit: bool,
        tag: bool,
        message: str | None,
        files: list[Path],
    ) -> None:
        """Perform git commit and/or tag operations."""
        if not self._is_git_repo():
            logger.warning("Not a git repository, skipping git operations")
            return

        if commit:
            self._git_commit(version, message, files)

        if tag:
            self._git_tag(version)

    def _is_git_repo(self) -> bool:
        """Check if current directory is a git repository."""
        try:
            subprocess.run(
                ["git", "rev-parse", "--git-dir"],
                check=True,
                capture_output=True,
            )
            return True
        except (subprocess.CalledProcessError, FileNotFoundError):
            return False

    def _git_commit(
        self,
        version: Version,
        message: str | None,
        files: list[Path],
    ) -> None:
        """Commit version changes to git."""
        commit_message = message or f"chore: bump version to {version}"

        try:
            subprocess.run(["git", "add"] + [str(f) for f in files], check=True)
            subprocess.run(["git", "commit", "-m", commit_message], check=True)
            logger.info(f"Git commit successful: {commit_message}")
        except subprocess.CalledProcessError as e:
            logger.exception(f"Git commit failed: {e}")

    def _git_tag(self, version: Version) -> None:
        """Create git tag for the new version."""
        tag_name = f"v{version}"

        try:
            subprocess.run(
                ["git", "tag", "-a", tag_name, "-m", f"Version {version}"],
                check=True,
            )
            logger.info(f"Git tag created: {tag_name}")
        except subprocess.CalledProcessError as e:
            logger.exception(f"Git tag failed: {e}")


def main() -> None:
    """Run main entry point for bumpversion command."""
    parser = argparse.ArgumentParser(
        prog="bumpversion",
        description="Automated version number management tool",
    )
    parser.add_argument(
        "part",
        type=str,
        choices=["major", "minor", "patch"],
        help="Version part to bump",
    )
    parser.add_argument(
        "--files",
        "-f",
        type=str,
        nargs="*",
        help="Specific files to update (default: auto-detect)",
    )
    parser.add_argument(
        "--prerelease",
        "-p",
        type=str,
        help="Set prerelease tag (e.g., alpha, beta, rc1)",
    )
    parser.add_argument(
        "--commit",
        "-c",
        action="store_true",
        help="Commit changes to git",
    )
    parser.add_argument("--tag", "-t", action="store_true", help="Create git tag")
    parser.add_argument("--message", "-m", type=str, help="Custom commit message")
    parser.add_argument(
        "--dry-run",
        "-n",
        action="store_true",
        help="Show what would be done without making changes",
    )
    parser.add_argument("--debug", "-d", action="store_true", help="Enable debug mode")
    args = parser.parse_args()

    if args.debug:
        logger.setLevel(logging.DEBUG)

    # Parse version part
    try:
        part = VersionPart(args.part.lower())
    except ValueError as e:
        logger.exception(f"Invalid version part: {e}")
        sys.exit(1)

    # Parse files
    files: list[Path] | None = None
    if args.files:
        files = [Path(f) for f in args.files]
        # Validate files exist
        for f in files:
            if not f.exists():
                logger.error(f"File not found: {f}")
                sys.exit(1)

    # Dry run mode
    if args.dry_run:
        logger.info("Dry run mode - no changes will be made")
        manager = BumpversionManager()
        detected_files = manager.detect_files()
        if not files:
            files = detected_files
        if files:
            current_version = manager.parse_version_from_file(files[0])
            logger.info(f"Current version: {current_version}")
            new_version = current_version.bump(part)
            logger.info(f"New version: {new_version}")
            logger.info(f"Files to update: {files}")
        else:
            logger.info("No files to update")
        return

    # Perform bump
    try:
        manager = BumpversionManager()
        new_version = manager.bump(
            part=part,
            files=files,
            prerelease=args.prerelease,
            commit=args.commit,
            tag=args.tag,
            message=args.message,
        )
        logger.info(f"Successfully bumped version to: {new_version}")
    except Exception as e:
        logger.exception(f"Failed to bump version: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
