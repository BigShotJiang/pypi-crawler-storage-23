# MakePython

Automated Python project building and management tool for the pytola ecosystem.

## Overview

MakePython is a command-line utility that simplifies common Python development workflows including building, testing, publishing, and version management. It automatically detects your project's build system (uv, poetry, or hatch) and provides consistent commands across different project types.

## Features

- **Automatic Build System Detection**: Automatically detects uv, poetry, or hatch from your pyproject.toml
- **Persistent Configuration**: Remembers your preferences across sessions
- **Cross-Platform Support**: Works on Windows, macOS, and Linux
- **Comprehensive Testing**: Includes unit tests and benchmark tests
- **Robust Error Handling**: Graceful handling of encoding issues and command failures
- **Clean Architecture**: Follows Python best practices with dataclasses and proper error handling
- **Complete Development Workflow**: Virtual environment management, version control, documentation generation
- **Advanced Project Management**: Build date updates, code linting, coverage reporting
- **Intelligent Project Analysis**: Automatic project type detection (GUI/CLI/Library) with emoji indicators
- **Performance Monitoring**: Built-in performance tracking and statistics
- **Enhanced User Experience**: Colorful output, progress indicators, and helpful error messages

## Installation

```bash
# Install via pip
pip install pytola-makepython

# Or install in development mode
pip install -e .
```

## Usage

```bash
# Show project information and type detection
makepython --info
makepython -i

# Build your project
makepython build
makepython b  # alias

# Activate virtual environment
makepython activate
makepython a  # alias

# Run tests
makepython test
makepython t  # alias

# Run benchmark tests
makepython test-benchmark
makepython tb  # alias

# Run tests with coverage
makepython test-coverage
makepython tc  # alias

# Run tests with coverage (slow mode)
makepython test-coverage-slow
makepython tcs  # alias

# Clean build artifacts
makepython clean
makepython c  # alias

# Bump version
makepython bumpversion
makepython bump  # alias

# Bump version and publish
makepython bump-publish
makepython bp  # alias

# Publish to PyPI
makepython publish
makepython p  # alias

# Set PyPI token
makepython token
makepython tk  # alias

# Generate documentation
makepython doc
makepython d  # alias

# Initialize new project
makepython init
makepython i  # alias

# Lint code
makepython lint
makepython l  # alias

# Update build dates
makepython update
makepython u  # alias

# Generate distribution package
makepython dist
makepython d  # alias

# Show performance statistics
makepython build --stats
makepython test --stats
```

## Configuration

MakePython automatically saves your configuration to `~/.pytola/makepython.json`. You can customize:

```python
{
    "default_build_tool": "uv",  # uv, poetry, or hatch
    "auto_detect_tool": true,
    "verbose_output": false,
    "max_retries": 3,
    "timeout_seconds": 300
}
```

## Commands Reference

| Command              | Alias  | Description                                           |
| -------------------- | ------ | ----------------------------------------------------- |
| `activate`           | `a`    | Activate virtual environment                          |
| `build`              | `b`    | Build the project using detected build system         |
| `bumpversion`        | `bump` | Bump project version (patch/minor/major)              |
| `bump-publish`       | `bp`   | Bump version and publish project                      |
| `clean`              | `c`    | Clean build artifacts and temporary files             |
| `dist`               | `d`    | Generate distribution package with complete workflow  |
| `doc`                | `d`    | Generate Sphinx HTML documentation including API docs |
| `init`               | `i`    | Initialize project with git and pre-commit hooks      |
| `lint`               | `l`    | Lint code using Ruff with auto-fix                    |
| `publish`            | `p`    | Publish package to PyPI with cleanup and git ops      |
| `test`               | `t`    | Run pytest tests                                      |
| `test-benchmark`     | `tb`   | Run benchmark tests                                   |
| `test-coverage`      | `tc`   | Run tests with coverage reporting                     |
| `test-coverage-slow` | `tcs`  | Run tests with coverage reporting (slow mode)         |
| `token`              | `tk`   | Set PyPI authentication token                         |
| `update`             | `u`    | Update build dates in __init__.py files               |

## Development

### Running Tests

```bash
# Run unit tests
pytest

# Run benchmark tests
pytest --benchmark-only

# Run tests with coverage
pytest --cov=pytola.makepython

# Run specific test file
pytest tests/test_makepython.py
```

### Code Quality

```bash
# Format code
black .

# Lint code
ruff check .

# Type checking
mypy .
```

## Project Structure

```
pytola/makepython/
├── makepython.py          # Main module
├── pyproject.toml         # Project configuration
├── README.md             # This file
└── tests/
    ├── test_makepython.py    # Unit tests
    └── test_benchmark.py     # Benchmark tests
```

## API Reference

### Main Classes

#### `MakePythonConfig`
Configuration class for MakePython tool with persistent settings.

#### `ProjectInfo`
Dataclass representing project information extracted from pyproject.toml.

#### `SubprocessExecutor`
Protocol-based command executor with proper error handling.

### Enums

#### `BuildTool`
Enumeration of supported build tools:
- `UV`: uv build system
- `POETRY`: Poetry build system  
- `HATCH`: Hatch build system

#### `CommandType`
Enumeration of command types:
- `BUILD`: Build commands
- `CLEAN`: Cleanup commands
- `TEST`: Test commands
- `PUBLISH`: Publishing commands
- `BUMP_VERSION`: Version bumping commands
- `TOKEN`: Token management commands

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests for new functionality
5. Run the test suite
6. Submit a pull request

## License

MIT License - see LICENSE file for details.

## Changelog

### 0.2.0
- Major refactor using dataclasses and proper Python patterns
- Added persistent configuration management
- Improved error handling and logging
- Added comprehensive test suite with benchmarks
- Enhanced documentation and type hints
- Better cross-platform support

### 0.1.0
- Initial release with basic functionality
