# PyPack - Python Packaging Tool

A comprehensive tool for packaging Python projects with workflow orchestration.

## Features

- **Multi-format Packaging**: Support for ZIP, 7z, and NSIS archives
- **Concurrent Processing**: Parallel execution of packaging tasks for improved performance
- **GUI and CLI Interfaces**: Both graphical and command-line interfaces available
- **Cross-platform**: Works on Windows, Linux, and macOS
- **Dependency Management**: Automatic dependency detection and packaging
- **Runtime Embedding**: Bundle Python runtime with your application

## Installation

```bash
pip install pytola-pypack
```

## Usage

### Command Line Interface

```bash
# Build a project
pypack build

# List available projects
pypack list

# Clean build artifacts
pypack clean

# Run a packaged application
pypack run myapp

# Show help
pypack --help
```

### Graphical Interface

```bash
# Launch GUI
pypack-gui
```

## Project Structure

```
pypack/
├── core/           # Core business logic
├── cli/            # Command line interface
├── gui/            # Graphical user interface
├── components/     # Core components
├── models/         # Data models
├── utils/          # Utility functions
├── tests/          # Test files
└── assets/         # Static assets
```

## Configuration

PyPack can be configured through command-line arguments or configuration files.
See `pypack --help` for available options.

## Development

### Setup Development Environment

```bash
# Clone the repository
git clone <repository-url>
cd pytola/dev/pypack

# Install dependencies
pip install -e .

# Run tests
pytest

# Run linting
ruff check .
ruff format .
```

### Running Tests

```bash
# Run all tests
pytest

# Run with coverage
pytest --cov=pytola.dev.pypack

# Run specific test file
pytest tests/test_workflow.py
```

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests for new functionality
5. Run tests and linting
6. Submit a pull request

## License

MIT License

## Authors

Pytola Team
