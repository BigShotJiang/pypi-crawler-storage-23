"""Pyloadergen module for tools."""

from __future__ import annotations

import argparse
import logging
from pathlib import Path

from pytola.dev.pypack.components import PyLoaderGenerator

cwd = Path.cwd()
logger = logging.getLogger(__name__)


def parse_args() -> argparse.Namespace:
    """Parse command line arguments for pyloadergen.

    Returns
    -------
        argparse.Namespace: Parsed arguments
    """
    parser = argparse.ArgumentParser(
        description="Generate Python loader executables for all projects in directory",
    )
    parser.add_argument(
        "directory",
        nargs="?",
        default=str(cwd),
        help="Directory containing projects (will create/load projects.json)",
    )
    parser.add_argument("--debug", "-d", action="store_true", help="Enable debug mode")
    parser.add_argument(
        "--compiler",
        help="Specify compiler to use. Examples: gcc, clang, cl, or full path like C:\\vc\\bin\\cl.exe",
    )
    return parser.parse_args()


def main() -> None:
    """Run main entry point for pyloadergen."""
    args = parse_args()

    if args.debug:
        logger.setLevel(logging.DEBUG)

    working_dir = Path(args.directory)
    if not working_dir.is_dir():
        logger.error(f"Directory does not exist: {working_dir}")
        return

    logger.info(f"Working directory: {working_dir}")

    generator = PyLoaderGenerator(root_dir=working_dir, compiler=args.compiler)
    generator.run(debug=args.debug)
