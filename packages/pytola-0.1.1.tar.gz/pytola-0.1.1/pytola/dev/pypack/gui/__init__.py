"""Graphical user interface for pypack."""
