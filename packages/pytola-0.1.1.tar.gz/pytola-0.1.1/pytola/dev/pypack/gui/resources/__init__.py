"""GUI resources for pypack."""
