"""Constants for pypack."""

# Log separator
LOG_SEPARATOR = "=" * 50

# Protected directories that should not be cleaned
PROTECTED_DIRS = {
    ".git",
    ".venv",
    ".virtualenv",
    ".vscode",
    ".idea",
    ".codebuddy",
    ".qoder",
}

# Directories that can be safely cleaned
CLEANABLE_DIRS = {"build", "dist", "pytola_build", "cbuild", "benchmarks"}

# File extensions
EXECUTABLE_EXTENSION = ".exe" if __import__("platform").system() == "Windows" else ""
