# Checksum Tool

A comprehensive checksum calculation and verification tool supporting multiple hash algorithms for both files and strings.

## Features

- **Multiple Algorithms**: Supports MD5, SHA1, SHA256, SHA384, SHA512, Blake2b, and Blake2s
- **Dual Interface**: Both command-line and graphical user interface
- **File and String Support**: Calculate checksums for files or string content
- **Verification**: Compare calculated checksums against expected values
- **Cross-platform**: Works on Windows, macOS, and Linux

## Installation

The tool is part of the pytola project. Install the complete package:

```bash
pip install pytola
```

Or install only the checksum module:

```bash
pip install pytola[checksum]
```

## Usage

### Command Line Interface

Basic usage examples:

```bash
# Calculate string checksum
checksum --algorithm sha256 --string "hello world"

# Calculate file checksum
checksum --algorithm md5 --file document.pdf

# Verify checksum
checksum --algorithm sha256 --file data.zip --compare "expected_hash_value"

# List all supported algorithms
checksum --help
```

Command line options:

```
--algorithm, -a    Hash algorithm to use (md5, sha1, sha256, sha384, sha512, blake2b, blake2s)
--string, -s       Calculate checksum for string content
--file, -f         Calculate checksum for file
--compare, -c      Verify calculated checksum against expected value
--gui              Launch graphical user interface
```

### Graphical User Interface

Launch the GUI version:

```bash
checksum --gui
```

The GUI provides:
- Easy algorithm selection via radio buttons
- File browsing with native dialog
- String input field
- Real-time checksum calculation
- Optional verification against expected values

## API Usage

The checksum module can be used programmatically:

```python
from pytola.checksum.checksum import ChecksumCalculator, HashAlgorithm
from pathlib import Path

# Initialize calculator
calculator = ChecksumCalculator()

# Calculate string checksum
result = calculator.calculate_string_checksum("hello world")
print(f"MD5: {result}")

# Calculate file checksum
file_hash = calculator.calculate_file_checksum(Path("document.pdf"))
print(f"File MD5: {file_hash}")

# Change algorithm
calculator.set_algorithm(HashAlgorithm.SHA256)
sha256_result = calculator.calculate_string_checksum("hello world")
print(f"SHA256: {sha256_result}")

# Verify checksum
is_valid = calculator.verify_checksum(calculated_hash, expected_hash)
```

## Supported Algorithms

| Algorithm | Description                   | Typical Use Cases                         |
| --------- | ----------------------------- | ----------------------------------------- |
| MD5       | Message Digest 5              | Quick file integrity checks               |
| SHA1      | Secure Hash Algorithm 1       | Legacy systems, version control           |
| SHA256    | Secure Hash Algorithm 256-bit | Security applications, digital signatures |
| SHA384    | Secure Hash Algorithm 384-bit | High-security applications                |
| SHA512    | Secure Hash Algorithm 512-bit | Cryptographic applications                |
| Blake2b   | Blake2 big variant            | Fast cryptographic hashing                |
| Blake2s   | Blake2 small variant          | Fast hashing for smaller inputs           |

## Configuration

The tool uses sensible defaults but can be configured:

```python
from pytola.checksum.checksum import ChecksumConfig, HashAlgorithm

config = ChecksumConfig(
    default_algorithm=HashAlgorithm.SHA256,
    enable_comparison=True,
    output_format="hex"
)
```

## Development

### Running Tests

```bash
# Run unit tests
pytest pytola/checksum/tests/

# Run with coverage
pytest pytola/checksum/tests/ --cov=pytola.checksum
```

### Building

```bash
# Install development dependencies
pip install -e .[dev]

# Run linter
ruff check pytola/checksum/

# Format code
ruff format pytola/checksum/
```

## Contributing

Contributions are welcome! Please:

1. Fork the repository
2. Create a feature branch
3. Add tests for new functionality
4. Ensure all tests pass
5. Submit a pull request

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Changelog

### v1.0.0
- Initial release
- Support for 7 hash algorithms
- Both CLI and GUI interfaces
- File and string checksum calculation
- Verification capability
