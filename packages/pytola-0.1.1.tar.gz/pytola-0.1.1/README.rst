=======
Pytola
=======

.. image:: https://img.shields.io/pypi/v/pytola.svg
        :target: https://pypi.python.org/pypi/pytola

.. image:: https://img.shields.io/travis/gooker_young/pytola.svg
        :target: https://travis-ci.com/gooker_young/pytola

.. image:: https://readthedocs.org/projects/pytola/badge/?version=latest
        :target: https://pytola.readthedocs.io/en/latest/?version=latest
        :alt: Documentation Status

Pytola: Essential Utilities for Python Devs

* Free software: MIT license
* Documentation: https://pytola.readthedocs.io/zh-cn/stable/

Features
--------

* **纯 Python 实现**: 无需复杂的构建过程, 安装简单快速
* **跨平台支持**: 完美支持 Windows、macOS 和 Linux
* **易于使用**: 简洁直观的 API 设计
* **易于使用**: 简单直观的 API 设计
* **跨平台**: 支持 Windows、macOS 和 Linux

Installation
------------

从 PyPI 安装::

    pip install pytola

或者从源码安装::

    git clone https://gitee.com/gooker_young/pytola.git
    cd pytola
    pip install .

开发安装::

    git clone https://gitee.com/gooker_young/pytola.git
    cd pytola
    pip install -e .

Usage
-----

基础使用::

    from pytola import pytola

    # Fibonacci 数列计算
    result = pytola.fibonacci(10)  # 返回 55
    print(f"Fibonacci(10) = {result}")

    # 阶乘计算
    result = pytola.factorial(5)   # 返回 120
    print(f"Factorial(5) = {result}")

    # 素数检测
    is_prime = pytola.is_prime(17) # 返回 True
    print(f"Is 17 prime? {is_prime}")

    # 检查版本信息
    version = pytola.utils.get_version()
    print(f"Pytola version: {version}"

API Reference
-------------

fibonacci(n: int) -> int
    计算第 n 个斐波那契数

factorial(n: int) -> int
    计算 n 的阶乘

is_prime(n: int) -> bool
    检查数字 n 是否为素数

sum_as_arr(arr: list) -> int
    计算数组元素之和

别名函数:
- fib(n) → fibonacci(n)
- fact(n) → factorial(n)
- prime_check(n) → is_prime(n)

Performance
-----------

Pytola 提供高效的纯 Python 实现, 专注于易用性和可靠性:

+----------------+------------------+
| 函数           | 性能特点         |
+================+==================+
| fibonacci(35)  | 高效迭代实现     |
+----------------+------------------+
| factorial(100) | 优化的循环算法   |
+----------------+------------------+

构建要求
--------

**要求:**
- Python >= 3.8
- pip

开发流程
--------

使用 Makefile 命令:

.. code-block:: bash

    # 清理构建文件
    make clean

    # 构建发布版本
    make build

    # 运行测试
    make test

    # 开发模式安装
    make develop

    # 检查代码质量
    make check

或者直接使用 pip:

.. code-block:: bash

    # 开发模式安装
    pip install -e .

    # 运行测试
    pytest

    # 检查代码风格
    ruff check .

Credits
-------

This package was created with Cookiecutter_ and the `audreyr/cookiecutter-pypackage`_ project template.

.. _Cookiecutter: https://github.com/audreyr/cookiecutter
.. _`audreyr/cookiecutter-pypackage`: https://github.com/audreyr/cookiecutter-pypackage
