__version__ = "1.40.0"
