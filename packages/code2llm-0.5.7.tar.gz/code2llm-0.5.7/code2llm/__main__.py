"""Entry point for running code2llm as a module."""

from .cli import main

if __name__ == '__main__':
    main()
