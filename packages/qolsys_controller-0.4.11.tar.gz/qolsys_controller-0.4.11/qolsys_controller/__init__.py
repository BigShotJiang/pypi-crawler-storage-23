from .controller import QolsysController as qolsys_controller  # noqa: D104, F401, N813
