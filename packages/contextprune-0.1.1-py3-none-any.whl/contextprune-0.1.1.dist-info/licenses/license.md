## END USER LICENSE AGREEMENT (EULA)

**1. Grant of License:** Grapine.AI ("Licensor") grants you a non-exclusive, royalty-free, non-transferable license to use the compiled version of this package for any purpose, including commercial applications.

**2. Restrictions:** You shall not:
- Decompile, reverse engineer, or disassemble the software to attempt to derive the source code.
- Modify, alter, or create derivative works of the software.
- Redistribute the package as a standalone product without prior written consent.

**3. Ownership:** All intellectual property rights, including the source code, remain the exclusive property of the Licensor.

**4. Disclaimer of Warranty:** THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED.

**5. Limitation of Liability:** In no event shall the Licensor be liable for any damages arising out of the use or inability to use this software.