from enum import Enum


class ColumnType(str, Enum):
    BOOLEAN = "boolean"
    DATE = "date"
    DATETIME = "datetime"
    NUMBER = "number"
    STRING = "string"

    def __str__(self) -> str:
        return str(self.value)
