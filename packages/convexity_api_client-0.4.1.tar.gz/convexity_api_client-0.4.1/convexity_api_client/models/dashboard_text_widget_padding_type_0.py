from enum import Enum


class DashboardTextWidgetPaddingType0(str, Enum):
    LARGE = "large"
    MEDIUM = "medium"
    NONE = "none"
    SMALL = "small"

    def __str__(self) -> str:
        return str(self.value)
