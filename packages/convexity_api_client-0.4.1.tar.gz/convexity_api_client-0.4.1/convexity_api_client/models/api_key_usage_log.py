from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.project_api_key import ProjectApiKey


T = TypeVar("T", bound="ApiKeyUsageLog")


@_attrs_define
class ApiKeyUsageLog:
    """Represents a ApiKeyUsageLog record

    Attributes:
        id (str):
        api_key_id (str):
        endpoint (str):
        method (str):
        status_code (int):
        created_at (datetime.datetime):
        ip_address (None | str | Unset):
        user_agent (None | str | Unset):
        response_time (int | None | Unset):
        api_key (None | ProjectApiKey | Unset):
    """

    id: str
    api_key_id: str
    endpoint: str
    method: str
    status_code: int
    created_at: datetime.datetime
    ip_address: None | str | Unset = UNSET
    user_agent: None | str | Unset = UNSET
    response_time: int | None | Unset = UNSET
    api_key: None | ProjectApiKey | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.project_api_key import ProjectApiKey

        id = self.id

        api_key_id = self.api_key_id

        endpoint = self.endpoint

        method = self.method

        status_code = self.status_code

        created_at = self.created_at.isoformat()

        ip_address: None | str | Unset
        if isinstance(self.ip_address, Unset):
            ip_address = UNSET
        else:
            ip_address = self.ip_address

        user_agent: None | str | Unset
        if isinstance(self.user_agent, Unset):
            user_agent = UNSET
        else:
            user_agent = self.user_agent

        response_time: int | None | Unset
        if isinstance(self.response_time, Unset):
            response_time = UNSET
        else:
            response_time = self.response_time

        api_key: dict[str, Any] | None | Unset
        if isinstance(self.api_key, Unset):
            api_key = UNSET
        elif isinstance(self.api_key, ProjectApiKey):
            api_key = self.api_key.to_dict()
        else:
            api_key = self.api_key

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "id": id,
                "api_key_id": api_key_id,
                "endpoint": endpoint,
                "method": method,
                "status_code": status_code,
                "created_at": created_at,
            }
        )
        if ip_address is not UNSET:
            field_dict["ip_address"] = ip_address
        if user_agent is not UNSET:
            field_dict["user_agent"] = user_agent
        if response_time is not UNSET:
            field_dict["response_time"] = response_time
        if api_key is not UNSET:
            field_dict["api_key"] = api_key

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.project_api_key import ProjectApiKey

        d = dict(src_dict)
        id = d.pop("id")

        api_key_id = d.pop("api_key_id")

        endpoint = d.pop("endpoint")

        method = d.pop("method")

        status_code = d.pop("status_code")

        created_at = isoparse(d.pop("created_at"))

        def _parse_ip_address(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        ip_address = _parse_ip_address(d.pop("ip_address", UNSET))

        def _parse_user_agent(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        user_agent = _parse_user_agent(d.pop("user_agent", UNSET))

        def _parse_response_time(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        response_time = _parse_response_time(d.pop("response_time", UNSET))

        def _parse_api_key(data: object) -> None | ProjectApiKey | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                api_key_type_0 = ProjectApiKey.from_dict(data)

                return api_key_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | ProjectApiKey | Unset, data)

        api_key = _parse_api_key(d.pop("api_key", UNSET))

        api_key_usage_log = cls(
            id=id,
            api_key_id=api_key_id,
            endpoint=endpoint,
            method=method,
            status_code=status_code,
            created_at=created_at,
            ip_address=ip_address,
            user_agent=user_agent,
            response_time=response_time,
            api_key=api_key,
        )

        api_key_usage_log.additional_properties = d
        return api_key_usage_log

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
