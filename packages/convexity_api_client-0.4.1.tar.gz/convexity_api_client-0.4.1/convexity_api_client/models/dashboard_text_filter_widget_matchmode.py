from enum import Enum


class DashboardTextFilterWidgetMatchmode(str, Enum):
    CONTAINS = "contains"
    ENDSWITH = "endswith"
    EXACT = "exact"
    STARTSWITH = "startswith"

    def __str__(self) -> str:
        return str(self.value)
