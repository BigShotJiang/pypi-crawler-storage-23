from enum import Enum


class ConnectionType(str, Enum):
    API = "API"
    DATABASE = "DATABASE"
    DATABRICKS_V1 = "DATABRICKS_V1"
    FILE = "FILE"
    S3 = "S3"
    WEBHOOK = "WEBHOOK"

    def __str__(self) -> str:
        return str(self.value)
