from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.task_scenario import TaskScenario
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.api_connection import ApiConnection
    from ..models.database_connection import DatabaseConnection
    from ..models.databricks_connection import DatabricksConnection
    from ..models.file_connection import FileConnection
    from ..models.notebook_document import NotebookDocument
    from ..models.s3_connection import S3Connection
    from ..models.update_task_request_parameter_schema_type_0 import UpdateTaskRequestParameterSchemaType0
    from ..models.webhook_connection import WebhookConnection


T = TypeVar("T", bound="UpdateTaskRequest")


@_attrs_define
class UpdateTaskRequest:
    """Payload for updating an existing task.

    Attributes:
        name (None | str | Unset):
        description (None | str | Unset):
        scenario (None | TaskScenario | Unset):
        notebook (None | NotebookDocument | Unset):
        connections (list[ApiConnection | DatabaseConnection | DatabricksConnection | FileConnection | S3Connection |
            WebhookConnection] | None | Unset):
        parameter_schema (None | Unset | UpdateTaskRequestParameterSchemaType0):
    """

    name: None | str | Unset = UNSET
    description: None | str | Unset = UNSET
    scenario: None | TaskScenario | Unset = UNSET
    notebook: None | NotebookDocument | Unset = UNSET
    connections: (
        list[
            ApiConnection
            | DatabaseConnection
            | DatabricksConnection
            | FileConnection
            | S3Connection
            | WebhookConnection
        ]
        | None
        | Unset
    ) = UNSET
    parameter_schema: None | Unset | UpdateTaskRequestParameterSchemaType0 = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.api_connection import ApiConnection
        from ..models.database_connection import DatabaseConnection
        from ..models.file_connection import FileConnection
        from ..models.notebook_document import NotebookDocument
        from ..models.s3_connection import S3Connection
        from ..models.update_task_request_parameter_schema_type_0 import UpdateTaskRequestParameterSchemaType0
        from ..models.webhook_connection import WebhookConnection

        name: None | str | Unset
        if isinstance(self.name, Unset):
            name = UNSET
        else:
            name = self.name

        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description

        scenario: None | str | Unset
        if isinstance(self.scenario, Unset):
            scenario = UNSET
        elif isinstance(self.scenario, TaskScenario):
            scenario = self.scenario.value
        else:
            scenario = self.scenario

        notebook: dict[str, Any] | None | Unset
        if isinstance(self.notebook, Unset):
            notebook = UNSET
        elif isinstance(self.notebook, NotebookDocument):
            notebook = self.notebook.to_dict()
        else:
            notebook = self.notebook

        connections: list[dict[str, Any]] | None | Unset
        if isinstance(self.connections, Unset):
            connections = UNSET
        elif isinstance(self.connections, list):
            connections = []
            for connections_type_0_item_data in self.connections:
                connections_type_0_item: dict[str, Any]
                if isinstance(connections_type_0_item_data, DatabaseConnection):
                    connections_type_0_item = connections_type_0_item_data.to_dict()
                elif isinstance(connections_type_0_item_data, S3Connection):
                    connections_type_0_item = connections_type_0_item_data.to_dict()
                elif isinstance(connections_type_0_item_data, ApiConnection):
                    connections_type_0_item = connections_type_0_item_data.to_dict()
                elif isinstance(connections_type_0_item_data, WebhookConnection):
                    connections_type_0_item = connections_type_0_item_data.to_dict()
                elif isinstance(connections_type_0_item_data, FileConnection):
                    connections_type_0_item = connections_type_0_item_data.to_dict()
                else:
                    connections_type_0_item = connections_type_0_item_data.to_dict()

                connections.append(connections_type_0_item)

        else:
            connections = self.connections

        parameter_schema: dict[str, Any] | None | Unset
        if isinstance(self.parameter_schema, Unset):
            parameter_schema = UNSET
        elif isinstance(self.parameter_schema, UpdateTaskRequestParameterSchemaType0):
            parameter_schema = self.parameter_schema.to_dict()
        else:
            parameter_schema = self.parameter_schema

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if name is not UNSET:
            field_dict["name"] = name
        if description is not UNSET:
            field_dict["description"] = description
        if scenario is not UNSET:
            field_dict["scenario"] = scenario
        if notebook is not UNSET:
            field_dict["notebook"] = notebook
        if connections is not UNSET:
            field_dict["connections"] = connections
        if parameter_schema is not UNSET:
            field_dict["parameterSchema"] = parameter_schema

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.api_connection import ApiConnection
        from ..models.database_connection import DatabaseConnection
        from ..models.databricks_connection import DatabricksConnection
        from ..models.file_connection import FileConnection
        from ..models.notebook_document import NotebookDocument
        from ..models.s3_connection import S3Connection
        from ..models.update_task_request_parameter_schema_type_0 import UpdateTaskRequestParameterSchemaType0
        from ..models.webhook_connection import WebhookConnection

        d = dict(src_dict)

        def _parse_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        name = _parse_name(d.pop("name", UNSET))

        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        description = _parse_description(d.pop("description", UNSET))

        def _parse_scenario(data: object) -> None | TaskScenario | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                scenario_type_0 = TaskScenario(data)

                return scenario_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | TaskScenario | Unset, data)

        scenario = _parse_scenario(d.pop("scenario", UNSET))

        def _parse_notebook(data: object) -> None | NotebookDocument | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                notebook_type_0 = NotebookDocument.from_dict(data)

                return notebook_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | NotebookDocument | Unset, data)

        notebook = _parse_notebook(d.pop("notebook", UNSET))

        def _parse_connections(
            data: object,
        ) -> (
            list[
                ApiConnection
                | DatabaseConnection
                | DatabricksConnection
                | FileConnection
                | S3Connection
                | WebhookConnection
            ]
            | None
            | Unset
        ):
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                connections_type_0 = []
                _connections_type_0 = data
                for connections_type_0_item_data in _connections_type_0:

                    def _parse_connections_type_0_item(
                        data: object,
                    ) -> (
                        ApiConnection
                        | DatabaseConnection
                        | DatabricksConnection
                        | FileConnection
                        | S3Connection
                        | WebhookConnection
                    ):
                        try:
                            if not isinstance(data, dict):
                                raise TypeError()
                            connections_type_0_item_type_0 = DatabaseConnection.from_dict(data)

                            return connections_type_0_item_type_0
                        except (TypeError, ValueError, AttributeError, KeyError):
                            pass
                        try:
                            if not isinstance(data, dict):
                                raise TypeError()
                            connections_type_0_item_type_1 = S3Connection.from_dict(data)

                            return connections_type_0_item_type_1
                        except (TypeError, ValueError, AttributeError, KeyError):
                            pass
                        try:
                            if not isinstance(data, dict):
                                raise TypeError()
                            connections_type_0_item_type_2 = ApiConnection.from_dict(data)

                            return connections_type_0_item_type_2
                        except (TypeError, ValueError, AttributeError, KeyError):
                            pass
                        try:
                            if not isinstance(data, dict):
                                raise TypeError()
                            connections_type_0_item_type_3 = WebhookConnection.from_dict(data)

                            return connections_type_0_item_type_3
                        except (TypeError, ValueError, AttributeError, KeyError):
                            pass
                        try:
                            if not isinstance(data, dict):
                                raise TypeError()
                            connections_type_0_item_type_4 = FileConnection.from_dict(data)

                            return connections_type_0_item_type_4
                        except (TypeError, ValueError, AttributeError, KeyError):
                            pass
                        if not isinstance(data, dict):
                            raise TypeError()
                        connections_type_0_item_type_5 = DatabricksConnection.from_dict(data)

                        return connections_type_0_item_type_5

                    connections_type_0_item = _parse_connections_type_0_item(connections_type_0_item_data)

                    connections_type_0.append(connections_type_0_item)

                return connections_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(
                list[
                    ApiConnection
                    | DatabaseConnection
                    | DatabricksConnection
                    | FileConnection
                    | S3Connection
                    | WebhookConnection
                ]
                | None
                | Unset,
                data,
            )

        connections = _parse_connections(d.pop("connections", UNSET))

        def _parse_parameter_schema(data: object) -> None | Unset | UpdateTaskRequestParameterSchemaType0:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                parameter_schema_type_0 = UpdateTaskRequestParameterSchemaType0.from_dict(data)

                return parameter_schema_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Unset | UpdateTaskRequestParameterSchemaType0, data)

        parameter_schema = _parse_parameter_schema(d.pop("parameterSchema", UNSET))

        update_task_request = cls(
            name=name,
            description=description,
            scenario=scenario,
            notebook=notebook,
            connections=connections,
            parameter_schema=parameter_schema,
        )

        update_task_request.additional_properties = d
        return update_task_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
