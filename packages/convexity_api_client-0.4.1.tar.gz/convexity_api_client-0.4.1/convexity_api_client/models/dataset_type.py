from enum import Enum


class DatasetType(str, Enum):
    API = "API"
    CSV = "CSV"
    DERIVED = "DERIVED"
    JSON = "JSON"
    SQL = "SQL"
    STATIC = "STATIC"

    def __str__(self) -> str:
        return str(self.value)
