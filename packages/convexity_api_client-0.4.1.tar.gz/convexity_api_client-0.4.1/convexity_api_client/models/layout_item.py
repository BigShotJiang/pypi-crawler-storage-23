from __future__ import annotations

from collections.abc import Mapping
from typing import Any, Literal, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="LayoutItem")


@_attrs_define
class LayoutItem:
    """Single widget layout item for react-grid-layout.

    Attributes:
        i (str): Widget ID
        x (int): X position in grid units
        y (int): Y position in grid units
        w (int): Width in grid units
        h (int): Height in grid units
        type_ (Literal['layout_item'] | Unset): Model type discriminator Default: 'layout_item'.
        min_w (int | None | Unset): Minimum width
        min_h (int | None | Unset): Minimum height
    """

    i: str
    x: int
    y: int
    w: int
    h: int
    type_: Literal["layout_item"] | Unset = "layout_item"
    min_w: int | None | Unset = UNSET
    min_h: int | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        i = self.i

        x = self.x

        y = self.y

        w = self.w

        h = self.h

        type_ = self.type_

        min_w: int | None | Unset
        if isinstance(self.min_w, Unset):
            min_w = UNSET
        else:
            min_w = self.min_w

        min_h: int | None | Unset
        if isinstance(self.min_h, Unset):
            min_h = UNSET
        else:
            min_h = self.min_h

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "i": i,
                "x": x,
                "y": y,
                "w": w,
                "h": h,
            }
        )
        if type_ is not UNSET:
            field_dict["type"] = type_
        if min_w is not UNSET:
            field_dict["minW"] = min_w
        if min_h is not UNSET:
            field_dict["minH"] = min_h

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        i = d.pop("i")

        x = d.pop("x")

        y = d.pop("y")

        w = d.pop("w")

        h = d.pop("h")

        type_ = cast(Literal["layout_item"] | Unset, d.pop("type", UNSET))
        if type_ != "layout_item" and not isinstance(type_, Unset):
            raise ValueError(f"type must match const 'layout_item', got '{type_}'")

        def _parse_min_w(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        min_w = _parse_min_w(d.pop("minW", UNSET))

        def _parse_min_h(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        min_h = _parse_min_h(d.pop("minH", UNSET))

        layout_item = cls(
            i=i,
            x=x,
            y=y,
            w=w,
            h=h,
            type_=type_,
            min_w=min_w,
            min_h=min_h,
        )

        layout_item.additional_properties = d
        return layout_item

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
