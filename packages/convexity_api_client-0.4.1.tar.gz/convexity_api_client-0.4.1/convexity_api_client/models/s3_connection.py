from __future__ import annotations

from collections.abc import Mapping
from typing import Any, Literal, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.connection_status import ConnectionStatus
from ..types import UNSET, Unset

T = TypeVar("T", bound="S3Connection")


@_attrs_define
class S3Connection:
    """Connection to AWS S3 or S3-compatible storage (MinIO, DigitalOcean Spaces, etc.).

    Attributes:
        project_id (str): Project this connection belongs to
        name (str): Connection name
        bucket (str): S3 bucket name
        region (str): AWS region or region for S3-compatible service
        access_key_id (str): AWS access key ID or S3-compatible access key
        secret_access_key (str): AWS secret access key or S3-compatible secret key
        id (None | str | Unset): Connection ID
        user_id (None | str | Unset): Owner user ID
        description (None | str | Unset): Connection description
        type_ (Literal['S3'] | Unset):  Default: 'S3'.
        status (ConnectionStatus | Unset):
        last_tested (None | str | Unset): Last verification timestamp
        error_message (None | str | Unset): Error message if status is error
        created_at (None | str | Unset): Creation timestamp
        updated_at (None | str | Unset): Last update timestamp
        prefix (None | str | Unset): Optional key prefix filter Default: ''.
        endpoint_url (None | str | Unset): Custom endpoint URL for S3-compatible services (e.g., MinIO, DigitalOcean
            Spaces)
    """

    project_id: str
    name: str
    bucket: str
    region: str
    access_key_id: str
    secret_access_key: str
    id: None | str | Unset = UNSET
    user_id: None | str | Unset = UNSET
    description: None | str | Unset = UNSET
    type_: Literal["S3"] | Unset = "S3"
    status: ConnectionStatus | Unset = UNSET
    last_tested: None | str | Unset = UNSET
    error_message: None | str | Unset = UNSET
    created_at: None | str | Unset = UNSET
    updated_at: None | str | Unset = UNSET
    prefix: None | str | Unset = ""
    endpoint_url: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        project_id = self.project_id

        name = self.name

        bucket = self.bucket

        region = self.region

        access_key_id = self.access_key_id

        secret_access_key = self.secret_access_key

        id: None | str | Unset
        if isinstance(self.id, Unset):
            id = UNSET
        else:
            id = self.id

        user_id: None | str | Unset
        if isinstance(self.user_id, Unset):
            user_id = UNSET
        else:
            user_id = self.user_id

        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description

        type_ = self.type_

        status: str | Unset = UNSET
        if not isinstance(self.status, Unset):
            status = self.status.value

        last_tested: None | str | Unset
        if isinstance(self.last_tested, Unset):
            last_tested = UNSET
        else:
            last_tested = self.last_tested

        error_message: None | str | Unset
        if isinstance(self.error_message, Unset):
            error_message = UNSET
        else:
            error_message = self.error_message

        created_at: None | str | Unset
        if isinstance(self.created_at, Unset):
            created_at = UNSET
        else:
            created_at = self.created_at

        updated_at: None | str | Unset
        if isinstance(self.updated_at, Unset):
            updated_at = UNSET
        else:
            updated_at = self.updated_at

        prefix: None | str | Unset
        if isinstance(self.prefix, Unset):
            prefix = UNSET
        else:
            prefix = self.prefix

        endpoint_url: None | str | Unset
        if isinstance(self.endpoint_url, Unset):
            endpoint_url = UNSET
        else:
            endpoint_url = self.endpoint_url

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "projectId": project_id,
                "name": name,
                "bucket": bucket,
                "region": region,
                "accessKeyId": access_key_id,
                "secretAccessKey": secret_access_key,
            }
        )
        if id is not UNSET:
            field_dict["id"] = id
        if user_id is not UNSET:
            field_dict["userId"] = user_id
        if description is not UNSET:
            field_dict["description"] = description
        if type_ is not UNSET:
            field_dict["type"] = type_
        if status is not UNSET:
            field_dict["status"] = status
        if last_tested is not UNSET:
            field_dict["lastTested"] = last_tested
        if error_message is not UNSET:
            field_dict["errorMessage"] = error_message
        if created_at is not UNSET:
            field_dict["createdAt"] = created_at
        if updated_at is not UNSET:
            field_dict["updatedAt"] = updated_at
        if prefix is not UNSET:
            field_dict["prefix"] = prefix
        if endpoint_url is not UNSET:
            field_dict["endpointUrl"] = endpoint_url

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        project_id = d.pop("projectId")

        name = d.pop("name")

        bucket = d.pop("bucket")

        region = d.pop("region")

        access_key_id = d.pop("accessKeyId")

        secret_access_key = d.pop("secretAccessKey")

        def _parse_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        id = _parse_id(d.pop("id", UNSET))

        def _parse_user_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        user_id = _parse_user_id(d.pop("userId", UNSET))

        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        description = _parse_description(d.pop("description", UNSET))

        type_ = cast(Literal["S3"] | Unset, d.pop("type", UNSET))
        if type_ != "S3" and not isinstance(type_, Unset):
            raise ValueError(f"type must match const 'S3', got '{type_}'")

        _status = d.pop("status", UNSET)
        status: ConnectionStatus | Unset
        if isinstance(_status, Unset):
            status = UNSET
        else:
            status = ConnectionStatus(_status)

        def _parse_last_tested(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        last_tested = _parse_last_tested(d.pop("lastTested", UNSET))

        def _parse_error_message(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        error_message = _parse_error_message(d.pop("errorMessage", UNSET))

        def _parse_created_at(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        created_at = _parse_created_at(d.pop("createdAt", UNSET))

        def _parse_updated_at(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        updated_at = _parse_updated_at(d.pop("updatedAt", UNSET))

        def _parse_prefix(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        prefix = _parse_prefix(d.pop("prefix", UNSET))

        def _parse_endpoint_url(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        endpoint_url = _parse_endpoint_url(d.pop("endpointUrl", UNSET))

        s3_connection = cls(
            project_id=project_id,
            name=name,
            bucket=bucket,
            region=region,
            access_key_id=access_key_id,
            secret_access_key=secret_access_key,
            id=id,
            user_id=user_id,
            description=description,
            type_=type_,
            status=status,
            last_tested=last_tested,
            error_message=error_message,
            created_at=created_at,
            updated_at=updated_at,
            prefix=prefix,
            endpoint_url=endpoint_url,
        )

        s3_connection.additional_properties = d
        return s3_connection

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
