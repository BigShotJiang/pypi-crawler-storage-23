from enum import Enum


class ColumnSemanticTypeType0(str, Enum):
    CATEGORICAL = "categorical"
    QUANTITATIVE = "quantitative"
    TEMPORAL = "temporal"

    def __str__(self) -> str:
        return str(self.value)
