from enum import Enum


class ApiKeyStatus(str, Enum):
    ACTIVE = "ACTIVE"
    EXPIRED = "EXPIRED"
    REVOKED = "REVOKED"

    def __str__(self) -> str:
        return str(self.value)
