from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.series_style_line_style_type_0 import SeriesStyleLineStyleType0
from ..types import UNSET, Unset

T = TypeVar("T", bound="SeriesStyle")


@_attrs_define
class SeriesStyle:
    """Style configuration for an individual chart series.

    Attributes:
        id (str): Unique identifier for this series. Format: '{yFieldName}' or '{yFieldName}:{groupValue}'
        name (None | str | Unset): Display name for the series (overrides default)
        color (None | str | Unset): Series color (hex or CSS color string)
        line_style (None | SeriesStyleLineStyleType0 | Unset): Line style
        line_width (int | None | Unset): Line width in pixels
    """

    id: str
    name: None | str | Unset = UNSET
    color: None | str | Unset = UNSET
    line_style: None | SeriesStyleLineStyleType0 | Unset = UNSET
    line_width: int | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        id = self.id

        name: None | str | Unset
        if isinstance(self.name, Unset):
            name = UNSET
        else:
            name = self.name

        color: None | str | Unset
        if isinstance(self.color, Unset):
            color = UNSET
        else:
            color = self.color

        line_style: None | str | Unset
        if isinstance(self.line_style, Unset):
            line_style = UNSET
        elif isinstance(self.line_style, SeriesStyleLineStyleType0):
            line_style = self.line_style.value
        else:
            line_style = self.line_style

        line_width: int | None | Unset
        if isinstance(self.line_width, Unset):
            line_width = UNSET
        else:
            line_width = self.line_width

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "id": id,
            }
        )
        if name is not UNSET:
            field_dict["name"] = name
        if color is not UNSET:
            field_dict["color"] = color
        if line_style is not UNSET:
            field_dict["lineStyle"] = line_style
        if line_width is not UNSET:
            field_dict["lineWidth"] = line_width

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        id = d.pop("id")

        def _parse_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        name = _parse_name(d.pop("name", UNSET))

        def _parse_color(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        color = _parse_color(d.pop("color", UNSET))

        def _parse_line_style(data: object) -> None | SeriesStyleLineStyleType0 | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                line_style_type_0 = SeriesStyleLineStyleType0(data)

                return line_style_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | SeriesStyleLineStyleType0 | Unset, data)

        line_style = _parse_line_style(d.pop("lineStyle", UNSET))

        def _parse_line_width(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        line_width = _parse_line_width(d.pop("lineWidth", UNSET))

        series_style = cls(
            id=id,
            name=name,
            color=color,
            line_style=line_style,
            line_width=line_width,
        )

        series_style.additional_properties = d
        return series_style

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
