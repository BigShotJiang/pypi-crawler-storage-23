from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.dashboard_chart_widget import DashboardChartWidget
    from ..models.dashboard_date_filter_widget import DashboardDateFilterWidget
    from ..models.dashboard_date_range_filter_widget import DashboardDateRangeFilterWidget
    from ..models.dashboard_e_chart_widget import DashboardEChartWidget
    from ..models.dashboard_layout import DashboardLayout
    from ..models.dashboard_multi_select_filter_widget import DashboardMultiSelectFilterWidget
    from ..models.dashboard_number_filter_widget import DashboardNumberFilterWidget
    from ..models.dashboard_number_range_filter_widget import DashboardNumberRangeFilterWidget
    from ..models.dashboard_s3_object_widget import DashboardS3ObjectWidget
    from ..models.dashboard_select_filter_widget import DashboardSelectFilterWidget
    from ..models.dashboard_sql_chart_widget import DashboardSqlChartWidget
    from ..models.dashboard_table_widget import DashboardTableWidget
    from ..models.dashboard_task_widget import DashboardTaskWidget
    from ..models.dashboard_text_filter_widget import DashboardTextFilterWidget
    from ..models.dashboard_text_widget import DashboardTextWidget


T = TypeVar("T", bound="UpdateDashboardRequest")


@_attrs_define
class UpdateDashboardRequest:
    """Request to update a dashboard.

    Attributes:
        name (None | str | Unset): Dashboard name
        description (None | str | Unset): Dashboard description
        tags (list[str] | None | Unset): Dashboard tags
        widgets (list[DashboardChartWidget | DashboardDateFilterWidget | DashboardDateRangeFilterWidget |
            DashboardEChartWidget | DashboardMultiSelectFilterWidget | DashboardNumberFilterWidget |
            DashboardNumberRangeFilterWidget | DashboardS3ObjectWidget | DashboardSelectFilterWidget |
            DashboardSqlChartWidget | DashboardTableWidget | DashboardTaskWidget | DashboardTextFilterWidget |
            DashboardTextWidget] | None | Unset): Dashboard widgets
        layout (DashboardLayout | None | Unset): Grid layout configuration
        last_refreshed_at (None | str | Unset): Last refresh timestamp
    """

    name: None | str | Unset = UNSET
    description: None | str | Unset = UNSET
    tags: list[str] | None | Unset = UNSET
    widgets: (
        list[
            DashboardChartWidget
            | DashboardDateFilterWidget
            | DashboardDateRangeFilterWidget
            | DashboardEChartWidget
            | DashboardMultiSelectFilterWidget
            | DashboardNumberFilterWidget
            | DashboardNumberRangeFilterWidget
            | DashboardS3ObjectWidget
            | DashboardSelectFilterWidget
            | DashboardSqlChartWidget
            | DashboardTableWidget
            | DashboardTaskWidget
            | DashboardTextFilterWidget
            | DashboardTextWidget
        ]
        | None
        | Unset
    ) = UNSET
    layout: DashboardLayout | None | Unset = UNSET
    last_refreshed_at: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.dashboard_chart_widget import DashboardChartWidget
        from ..models.dashboard_date_filter_widget import DashboardDateFilterWidget
        from ..models.dashboard_date_range_filter_widget import DashboardDateRangeFilterWidget
        from ..models.dashboard_e_chart_widget import DashboardEChartWidget
        from ..models.dashboard_layout import DashboardLayout
        from ..models.dashboard_multi_select_filter_widget import DashboardMultiSelectFilterWidget
        from ..models.dashboard_number_filter_widget import DashboardNumberFilterWidget
        from ..models.dashboard_s3_object_widget import DashboardS3ObjectWidget
        from ..models.dashboard_select_filter_widget import DashboardSelectFilterWidget
        from ..models.dashboard_sql_chart_widget import DashboardSqlChartWidget
        from ..models.dashboard_table_widget import DashboardTableWidget
        from ..models.dashboard_task_widget import DashboardTaskWidget
        from ..models.dashboard_text_filter_widget import DashboardTextFilterWidget
        from ..models.dashboard_text_widget import DashboardTextWidget

        name: None | str | Unset
        if isinstance(self.name, Unset):
            name = UNSET
        else:
            name = self.name

        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description

        tags: list[str] | None | Unset
        if isinstance(self.tags, Unset):
            tags = UNSET
        elif isinstance(self.tags, list):
            tags = self.tags

        else:
            tags = self.tags

        widgets: list[dict[str, Any]] | None | Unset
        if isinstance(self.widgets, Unset):
            widgets = UNSET
        elif isinstance(self.widgets, list):
            widgets = []
            for widgets_type_0_item_data in self.widgets:
                widgets_type_0_item: dict[str, Any]
                if isinstance(widgets_type_0_item_data, DashboardChartWidget):
                    widgets_type_0_item = widgets_type_0_item_data.to_dict()
                elif isinstance(widgets_type_0_item_data, DashboardSqlChartWidget):
                    widgets_type_0_item = widgets_type_0_item_data.to_dict()
                elif isinstance(widgets_type_0_item_data, DashboardTaskWidget):
                    widgets_type_0_item = widgets_type_0_item_data.to_dict()
                elif isinstance(widgets_type_0_item_data, DashboardS3ObjectWidget):
                    widgets_type_0_item = widgets_type_0_item_data.to_dict()
                elif isinstance(widgets_type_0_item_data, DashboardEChartWidget):
                    widgets_type_0_item = widgets_type_0_item_data.to_dict()
                elif isinstance(widgets_type_0_item_data, DashboardTableWidget):
                    widgets_type_0_item = widgets_type_0_item_data.to_dict()
                elif isinstance(widgets_type_0_item_data, DashboardTextWidget):
                    widgets_type_0_item = widgets_type_0_item_data.to_dict()
                elif isinstance(widgets_type_0_item_data, DashboardSelectFilterWidget):
                    widgets_type_0_item = widgets_type_0_item_data.to_dict()
                elif isinstance(widgets_type_0_item_data, DashboardMultiSelectFilterWidget):
                    widgets_type_0_item = widgets_type_0_item_data.to_dict()
                elif isinstance(widgets_type_0_item_data, DashboardDateFilterWidget):
                    widgets_type_0_item = widgets_type_0_item_data.to_dict()
                elif isinstance(widgets_type_0_item_data, DashboardDateRangeFilterWidget):
                    widgets_type_0_item = widgets_type_0_item_data.to_dict()
                elif isinstance(widgets_type_0_item_data, DashboardTextFilterWidget):
                    widgets_type_0_item = widgets_type_0_item_data.to_dict()
                elif isinstance(widgets_type_0_item_data, DashboardNumberFilterWidget):
                    widgets_type_0_item = widgets_type_0_item_data.to_dict()
                else:
                    widgets_type_0_item = widgets_type_0_item_data.to_dict()

                widgets.append(widgets_type_0_item)

        else:
            widgets = self.widgets

        layout: dict[str, Any] | None | Unset
        if isinstance(self.layout, Unset):
            layout = UNSET
        elif isinstance(self.layout, DashboardLayout):
            layout = self.layout.to_dict()
        else:
            layout = self.layout

        last_refreshed_at: None | str | Unset
        if isinstance(self.last_refreshed_at, Unset):
            last_refreshed_at = UNSET
        else:
            last_refreshed_at = self.last_refreshed_at

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if name is not UNSET:
            field_dict["name"] = name
        if description is not UNSET:
            field_dict["description"] = description
        if tags is not UNSET:
            field_dict["tags"] = tags
        if widgets is not UNSET:
            field_dict["widgets"] = widgets
        if layout is not UNSET:
            field_dict["layout"] = layout
        if last_refreshed_at is not UNSET:
            field_dict["lastRefreshedAt"] = last_refreshed_at

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.dashboard_chart_widget import DashboardChartWidget
        from ..models.dashboard_date_filter_widget import DashboardDateFilterWidget
        from ..models.dashboard_date_range_filter_widget import DashboardDateRangeFilterWidget
        from ..models.dashboard_e_chart_widget import DashboardEChartWidget
        from ..models.dashboard_layout import DashboardLayout
        from ..models.dashboard_multi_select_filter_widget import DashboardMultiSelectFilterWidget
        from ..models.dashboard_number_filter_widget import DashboardNumberFilterWidget
        from ..models.dashboard_number_range_filter_widget import DashboardNumberRangeFilterWidget
        from ..models.dashboard_s3_object_widget import DashboardS3ObjectWidget
        from ..models.dashboard_select_filter_widget import DashboardSelectFilterWidget
        from ..models.dashboard_sql_chart_widget import DashboardSqlChartWidget
        from ..models.dashboard_table_widget import DashboardTableWidget
        from ..models.dashboard_task_widget import DashboardTaskWidget
        from ..models.dashboard_text_filter_widget import DashboardTextFilterWidget
        from ..models.dashboard_text_widget import DashboardTextWidget

        d = dict(src_dict)

        def _parse_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        name = _parse_name(d.pop("name", UNSET))

        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        description = _parse_description(d.pop("description", UNSET))

        def _parse_tags(data: object) -> list[str] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                tags_type_0 = cast(list[str], data)

                return tags_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[str] | None | Unset, data)

        tags = _parse_tags(d.pop("tags", UNSET))

        def _parse_widgets(
            data: object,
        ) -> (
            list[
                DashboardChartWidget
                | DashboardDateFilterWidget
                | DashboardDateRangeFilterWidget
                | DashboardEChartWidget
                | DashboardMultiSelectFilterWidget
                | DashboardNumberFilterWidget
                | DashboardNumberRangeFilterWidget
                | DashboardS3ObjectWidget
                | DashboardSelectFilterWidget
                | DashboardSqlChartWidget
                | DashboardTableWidget
                | DashboardTaskWidget
                | DashboardTextFilterWidget
                | DashboardTextWidget
            ]
            | None
            | Unset
        ):
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                widgets_type_0 = []
                _widgets_type_0 = data
                for widgets_type_0_item_data in _widgets_type_0:

                    def _parse_widgets_type_0_item(
                        data: object,
                    ) -> (
                        DashboardChartWidget
                        | DashboardDateFilterWidget
                        | DashboardDateRangeFilterWidget
                        | DashboardEChartWidget
                        | DashboardMultiSelectFilterWidget
                        | DashboardNumberFilterWidget
                        | DashboardNumberRangeFilterWidget
                        | DashboardS3ObjectWidget
                        | DashboardSelectFilterWidget
                        | DashboardSqlChartWidget
                        | DashboardTableWidget
                        | DashboardTaskWidget
                        | DashboardTextFilterWidget
                        | DashboardTextWidget
                    ):
                        try:
                            if not isinstance(data, dict):
                                raise TypeError()
                            widgets_type_0_item_type_0 = DashboardChartWidget.from_dict(data)

                            return widgets_type_0_item_type_0
                        except (TypeError, ValueError, AttributeError, KeyError):
                            pass
                        try:
                            if not isinstance(data, dict):
                                raise TypeError()
                            widgets_type_0_item_type_1 = DashboardSqlChartWidget.from_dict(data)

                            return widgets_type_0_item_type_1
                        except (TypeError, ValueError, AttributeError, KeyError):
                            pass
                        try:
                            if not isinstance(data, dict):
                                raise TypeError()
                            widgets_type_0_item_type_2 = DashboardTaskWidget.from_dict(data)

                            return widgets_type_0_item_type_2
                        except (TypeError, ValueError, AttributeError, KeyError):
                            pass
                        try:
                            if not isinstance(data, dict):
                                raise TypeError()
                            widgets_type_0_item_type_3 = DashboardS3ObjectWidget.from_dict(data)

                            return widgets_type_0_item_type_3
                        except (TypeError, ValueError, AttributeError, KeyError):
                            pass
                        try:
                            if not isinstance(data, dict):
                                raise TypeError()
                            widgets_type_0_item_type_4 = DashboardEChartWidget.from_dict(data)

                            return widgets_type_0_item_type_4
                        except (TypeError, ValueError, AttributeError, KeyError):
                            pass
                        try:
                            if not isinstance(data, dict):
                                raise TypeError()
                            widgets_type_0_item_type_5 = DashboardTableWidget.from_dict(data)

                            return widgets_type_0_item_type_5
                        except (TypeError, ValueError, AttributeError, KeyError):
                            pass
                        try:
                            if not isinstance(data, dict):
                                raise TypeError()
                            widgets_type_0_item_type_6 = DashboardTextWidget.from_dict(data)

                            return widgets_type_0_item_type_6
                        except (TypeError, ValueError, AttributeError, KeyError):
                            pass
                        try:
                            if not isinstance(data, dict):
                                raise TypeError()
                            widgets_type_0_item_type_7 = DashboardSelectFilterWidget.from_dict(data)

                            return widgets_type_0_item_type_7
                        except (TypeError, ValueError, AttributeError, KeyError):
                            pass
                        try:
                            if not isinstance(data, dict):
                                raise TypeError()
                            widgets_type_0_item_type_8 = DashboardMultiSelectFilterWidget.from_dict(data)

                            return widgets_type_0_item_type_8
                        except (TypeError, ValueError, AttributeError, KeyError):
                            pass
                        try:
                            if not isinstance(data, dict):
                                raise TypeError()
                            widgets_type_0_item_type_9 = DashboardDateFilterWidget.from_dict(data)

                            return widgets_type_0_item_type_9
                        except (TypeError, ValueError, AttributeError, KeyError):
                            pass
                        try:
                            if not isinstance(data, dict):
                                raise TypeError()
                            widgets_type_0_item_type_10 = DashboardDateRangeFilterWidget.from_dict(data)

                            return widgets_type_0_item_type_10
                        except (TypeError, ValueError, AttributeError, KeyError):
                            pass
                        try:
                            if not isinstance(data, dict):
                                raise TypeError()
                            widgets_type_0_item_type_11 = DashboardTextFilterWidget.from_dict(data)

                            return widgets_type_0_item_type_11
                        except (TypeError, ValueError, AttributeError, KeyError):
                            pass
                        try:
                            if not isinstance(data, dict):
                                raise TypeError()
                            widgets_type_0_item_type_12 = DashboardNumberFilterWidget.from_dict(data)

                            return widgets_type_0_item_type_12
                        except (TypeError, ValueError, AttributeError, KeyError):
                            pass
                        if not isinstance(data, dict):
                            raise TypeError()
                        widgets_type_0_item_type_13 = DashboardNumberRangeFilterWidget.from_dict(data)

                        return widgets_type_0_item_type_13

                    widgets_type_0_item = _parse_widgets_type_0_item(widgets_type_0_item_data)

                    widgets_type_0.append(widgets_type_0_item)

                return widgets_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(
                list[
                    DashboardChartWidget
                    | DashboardDateFilterWidget
                    | DashboardDateRangeFilterWidget
                    | DashboardEChartWidget
                    | DashboardMultiSelectFilterWidget
                    | DashboardNumberFilterWidget
                    | DashboardNumberRangeFilterWidget
                    | DashboardS3ObjectWidget
                    | DashboardSelectFilterWidget
                    | DashboardSqlChartWidget
                    | DashboardTableWidget
                    | DashboardTaskWidget
                    | DashboardTextFilterWidget
                    | DashboardTextWidget
                ]
                | None
                | Unset,
                data,
            )

        widgets = _parse_widgets(d.pop("widgets", UNSET))

        def _parse_layout(data: object) -> DashboardLayout | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                layout_type_0 = DashboardLayout.from_dict(data)

                return layout_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(DashboardLayout | None | Unset, data)

        layout = _parse_layout(d.pop("layout", UNSET))

        def _parse_last_refreshed_at(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        last_refreshed_at = _parse_last_refreshed_at(d.pop("lastRefreshedAt", UNSET))

        update_dashboard_request = cls(
            name=name,
            description=description,
            tags=tags,
            widgets=widgets,
            layout=layout,
            last_refreshed_at=last_refreshed_at,
        )

        update_dashboard_request.additional_properties = d
        return update_dashboard_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
