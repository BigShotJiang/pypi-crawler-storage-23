from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.cell_execution_status import CellExecutionStatus
from ..models.cell_type import CellType
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.notebook_cell_metadata_type_0 import NotebookCellMetadataType0
    from ..models.notebook_cell_output import NotebookCellOutput


T = TypeVar("T", bound="NotebookCell")


@_attrs_define
class NotebookCell:
    """Notebook cell representation.

    Attributes:
        id (str):
        type_ (CellType): Notebook cell types.
        content (str):
        output (None | NotebookCellOutput | Unset):
        execution_status (CellExecutionStatus | None | Unset):
        execution_count (int | None | Unset):
        metadata (None | NotebookCellMetadataType0 | Unset):
    """

    id: str
    type_: CellType
    content: str
    output: None | NotebookCellOutput | Unset = UNSET
    execution_status: CellExecutionStatus | None | Unset = UNSET
    execution_count: int | None | Unset = UNSET
    metadata: None | NotebookCellMetadataType0 | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.notebook_cell_metadata_type_0 import NotebookCellMetadataType0
        from ..models.notebook_cell_output import NotebookCellOutput

        id = self.id

        type_ = self.type_.value

        content = self.content

        output: dict[str, Any] | None | Unset
        if isinstance(self.output, Unset):
            output = UNSET
        elif isinstance(self.output, NotebookCellOutput):
            output = self.output.to_dict()
        else:
            output = self.output

        execution_status: None | str | Unset
        if isinstance(self.execution_status, Unset):
            execution_status = UNSET
        elif isinstance(self.execution_status, CellExecutionStatus):
            execution_status = self.execution_status.value
        else:
            execution_status = self.execution_status

        execution_count: int | None | Unset
        if isinstance(self.execution_count, Unset):
            execution_count = UNSET
        else:
            execution_count = self.execution_count

        metadata: dict[str, Any] | None | Unset
        if isinstance(self.metadata, Unset):
            metadata = UNSET
        elif isinstance(self.metadata, NotebookCellMetadataType0):
            metadata = self.metadata.to_dict()
        else:
            metadata = self.metadata

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "id": id,
                "type": type_,
                "content": content,
            }
        )
        if output is not UNSET:
            field_dict["output"] = output
        if execution_status is not UNSET:
            field_dict["execution_status"] = execution_status
        if execution_count is not UNSET:
            field_dict["execution_count"] = execution_count
        if metadata is not UNSET:
            field_dict["metadata"] = metadata

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.notebook_cell_metadata_type_0 import NotebookCellMetadataType0
        from ..models.notebook_cell_output import NotebookCellOutput

        d = dict(src_dict)
        id = d.pop("id")

        type_ = CellType(d.pop("type"))

        content = d.pop("content")

        def _parse_output(data: object) -> None | NotebookCellOutput | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                output_type_0 = NotebookCellOutput.from_dict(data)

                return output_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | NotebookCellOutput | Unset, data)

        output = _parse_output(d.pop("output", UNSET))

        def _parse_execution_status(data: object) -> CellExecutionStatus | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                execution_status_type_0 = CellExecutionStatus(data)

                return execution_status_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(CellExecutionStatus | None | Unset, data)

        execution_status = _parse_execution_status(d.pop("execution_status", UNSET))

        def _parse_execution_count(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        execution_count = _parse_execution_count(d.pop("execution_count", UNSET))

        def _parse_metadata(data: object) -> None | NotebookCellMetadataType0 | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                metadata_type_0 = NotebookCellMetadataType0.from_dict(data)

                return metadata_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | NotebookCellMetadataType0 | Unset, data)

        metadata = _parse_metadata(d.pop("metadata", UNSET))

        notebook_cell = cls(
            id=id,
            type_=type_,
            content=content,
            output=output,
            execution_status=execution_status,
            execution_count=execution_count,
            metadata=metadata,
        )

        notebook_cell.additional_properties = d
        return notebook_cell

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
