from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, Literal, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.chart_config import ChartConfig
    from ..models.sql_dataset import SqlDataset


T = TypeVar("T", bound="DashboardSqlChartWidget")


@_attrs_define
class DashboardSqlChartWidget:
    """SQL Chart widget definition.

    Attributes:
        id (str): Unique widget identifier
        title (None | str | Unset): Widget title
        description (None | str | Unset): Widget description
        show_title (bool | None | Unset): Whether to display the widget title Default: True.
        show_description (bool | None | Unset): Whether to display the widget description Default: True.
        type_ (Literal['sqlchart'] | Unset):  Default: 'sqlchart'.
        connection_id (None | str | Unset): Database connection ID
        query (None | str | Unset): SQL query
        row_limit (int | None | Unset): Row limit for query
        sql_dataset (None | SqlDataset | Unset): SQL query result data
        chart_config (ChartConfig | None | Unset): Chart configuration
        last_error (None | str | Unset): Last error message
        last_run_at (None | str | Unset): Last run timestamp
    """

    id: str
    title: None | str | Unset = UNSET
    description: None | str | Unset = UNSET
    show_title: bool | None | Unset = True
    show_description: bool | None | Unset = True
    type_: Literal["sqlchart"] | Unset = "sqlchart"
    connection_id: None | str | Unset = UNSET
    query: None | str | Unset = UNSET
    row_limit: int | None | Unset = UNSET
    sql_dataset: None | SqlDataset | Unset = UNSET
    chart_config: ChartConfig | None | Unset = UNSET
    last_error: None | str | Unset = UNSET
    last_run_at: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.chart_config import ChartConfig
        from ..models.sql_dataset import SqlDataset

        id = self.id

        title: None | str | Unset
        if isinstance(self.title, Unset):
            title = UNSET
        else:
            title = self.title

        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description

        show_title: bool | None | Unset
        if isinstance(self.show_title, Unset):
            show_title = UNSET
        else:
            show_title = self.show_title

        show_description: bool | None | Unset
        if isinstance(self.show_description, Unset):
            show_description = UNSET
        else:
            show_description = self.show_description

        type_ = self.type_

        connection_id: None | str | Unset
        if isinstance(self.connection_id, Unset):
            connection_id = UNSET
        else:
            connection_id = self.connection_id

        query: None | str | Unset
        if isinstance(self.query, Unset):
            query = UNSET
        else:
            query = self.query

        row_limit: int | None | Unset
        if isinstance(self.row_limit, Unset):
            row_limit = UNSET
        else:
            row_limit = self.row_limit

        sql_dataset: dict[str, Any] | None | Unset
        if isinstance(self.sql_dataset, Unset):
            sql_dataset = UNSET
        elif isinstance(self.sql_dataset, SqlDataset):
            sql_dataset = self.sql_dataset.to_dict()
        else:
            sql_dataset = self.sql_dataset

        chart_config: dict[str, Any] | None | Unset
        if isinstance(self.chart_config, Unset):
            chart_config = UNSET
        elif isinstance(self.chart_config, ChartConfig):
            chart_config = self.chart_config.to_dict()
        else:
            chart_config = self.chart_config

        last_error: None | str | Unset
        if isinstance(self.last_error, Unset):
            last_error = UNSET
        else:
            last_error = self.last_error

        last_run_at: None | str | Unset
        if isinstance(self.last_run_at, Unset):
            last_run_at = UNSET
        else:
            last_run_at = self.last_run_at

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "id": id,
            }
        )
        if title is not UNSET:
            field_dict["title"] = title
        if description is not UNSET:
            field_dict["description"] = description
        if show_title is not UNSET:
            field_dict["showTitle"] = show_title
        if show_description is not UNSET:
            field_dict["showDescription"] = show_description
        if type_ is not UNSET:
            field_dict["type"] = type_
        if connection_id is not UNSET:
            field_dict["connectionId"] = connection_id
        if query is not UNSET:
            field_dict["query"] = query
        if row_limit is not UNSET:
            field_dict["rowLimit"] = row_limit
        if sql_dataset is not UNSET:
            field_dict["sqlDataset"] = sql_dataset
        if chart_config is not UNSET:
            field_dict["chartConfig"] = chart_config
        if last_error is not UNSET:
            field_dict["lastError"] = last_error
        if last_run_at is not UNSET:
            field_dict["lastRunAt"] = last_run_at

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.chart_config import ChartConfig
        from ..models.sql_dataset import SqlDataset

        d = dict(src_dict)
        id = d.pop("id")

        def _parse_title(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        title = _parse_title(d.pop("title", UNSET))

        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        description = _parse_description(d.pop("description", UNSET))

        def _parse_show_title(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        show_title = _parse_show_title(d.pop("showTitle", UNSET))

        def _parse_show_description(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        show_description = _parse_show_description(d.pop("showDescription", UNSET))

        type_ = cast(Literal["sqlchart"] | Unset, d.pop("type", UNSET))
        if type_ != "sqlchart" and not isinstance(type_, Unset):
            raise ValueError(f"type must match const 'sqlchart', got '{type_}'")

        def _parse_connection_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        connection_id = _parse_connection_id(d.pop("connectionId", UNSET))

        def _parse_query(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        query = _parse_query(d.pop("query", UNSET))

        def _parse_row_limit(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        row_limit = _parse_row_limit(d.pop("rowLimit", UNSET))

        def _parse_sql_dataset(data: object) -> None | SqlDataset | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                sql_dataset_type_0 = SqlDataset.from_dict(data)

                return sql_dataset_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | SqlDataset | Unset, data)

        sql_dataset = _parse_sql_dataset(d.pop("sqlDataset", UNSET))

        def _parse_chart_config(data: object) -> ChartConfig | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                chart_config_type_0 = ChartConfig.from_dict(data)

                return chart_config_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(ChartConfig | None | Unset, data)

        chart_config = _parse_chart_config(d.pop("chartConfig", UNSET))

        def _parse_last_error(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        last_error = _parse_last_error(d.pop("lastError", UNSET))

        def _parse_last_run_at(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        last_run_at = _parse_last_run_at(d.pop("lastRunAt", UNSET))

        dashboard_sql_chart_widget = cls(
            id=id,
            title=title,
            description=description,
            show_title=show_title,
            show_description=show_description,
            type_=type_,
            connection_id=connection_id,
            query=query,
            row_limit=row_limit,
            sql_dataset=sql_dataset,
            chart_config=chart_config,
            last_error=last_error,
            last_run_at=last_run_at,
        )

        dashboard_sql_chart_widget.additional_properties = d
        return dashboard_sql_chart_widget

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
