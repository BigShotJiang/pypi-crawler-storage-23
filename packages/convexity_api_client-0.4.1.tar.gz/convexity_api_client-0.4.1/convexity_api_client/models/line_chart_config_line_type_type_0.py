from enum import Enum


class LineChartConfigLineTypeType0(str, Enum):
    SMOOTH = "smooth"
    STEP_END = "step-end"
    STEP_MIDDLE = "step-middle"
    STEP_START = "step-start"
    STRAIGHT = "straight"

    def __str__(self) -> str:
        return str(self.value)
