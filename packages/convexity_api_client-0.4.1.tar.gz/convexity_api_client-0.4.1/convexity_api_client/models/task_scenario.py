from enum import Enum


class TaskScenario(str, Enum):
    CHURN = "CHURN"
    FORECASTING = "FORECASTING"
    FRAUD = "FRAUD"
    INVENTORY = "INVENTORY"
    OPTIMIZATION = "OPTIMIZATION"
    PRICING = "PRICING"
    RECOMMENDATION = "RECOMMENDATION"
    SEGMENTATION = "SEGMENTATION"

    def __str__(self) -> str:
        return str(self.value)
