from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.preview_type import PreviewType
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.spreadsheet_preview import SpreadsheetPreview


T = TypeVar("T", bound="S3ObjectContent")


@_attrs_define
class S3ObjectContent:
    """Preview response for a single S3 object.

    Attributes:
        key (str):
        size (int):
        content_type (str):
        extension (str):
        previewable (bool):
        preview_type (None | PreviewType | Unset):
        content (None | SpreadsheetPreview | str | Unset):
        error (None | str | Unset):
    """

    key: str
    size: int
    content_type: str
    extension: str
    previewable: bool
    preview_type: None | PreviewType | Unset = UNSET
    content: None | SpreadsheetPreview | str | Unset = UNSET
    error: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.spreadsheet_preview import SpreadsheetPreview

        key = self.key

        size = self.size

        content_type = self.content_type

        extension = self.extension

        previewable = self.previewable

        preview_type: None | str | Unset
        if isinstance(self.preview_type, Unset):
            preview_type = UNSET
        elif isinstance(self.preview_type, PreviewType):
            preview_type = self.preview_type.value
        else:
            preview_type = self.preview_type

        content: dict[str, Any] | None | str | Unset
        if isinstance(self.content, Unset):
            content = UNSET
        elif isinstance(self.content, SpreadsheetPreview):
            content = self.content.to_dict()
        else:
            content = self.content

        error: None | str | Unset
        if isinstance(self.error, Unset):
            error = UNSET
        else:
            error = self.error

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "key": key,
                "size": size,
                "contentType": content_type,
                "extension": extension,
                "previewable": previewable,
            }
        )
        if preview_type is not UNSET:
            field_dict["previewType"] = preview_type
        if content is not UNSET:
            field_dict["content"] = content
        if error is not UNSET:
            field_dict["error"] = error

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.spreadsheet_preview import SpreadsheetPreview

        d = dict(src_dict)
        key = d.pop("key")

        size = d.pop("size")

        content_type = d.pop("contentType")

        extension = d.pop("extension")

        previewable = d.pop("previewable")

        def _parse_preview_type(data: object) -> None | PreviewType | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                preview_type_type_0 = PreviewType(data)

                return preview_type_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | PreviewType | Unset, data)

        preview_type = _parse_preview_type(d.pop("previewType", UNSET))

        def _parse_content(data: object) -> None | SpreadsheetPreview | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                content_type_1 = SpreadsheetPreview.from_dict(data)

                return content_type_1
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | SpreadsheetPreview | str | Unset, data)

        content = _parse_content(d.pop("content", UNSET))

        def _parse_error(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        error = _parse_error(d.pop("error", UNSET))

        s3_object_content = cls(
            key=key,
            size=size,
            content_type=content_type,
            extension=extension,
            previewable=previewable,
            preview_type=preview_type,
            content=content,
            error=error,
        )

        s3_object_content.additional_properties = d
        return s3_object_content

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
