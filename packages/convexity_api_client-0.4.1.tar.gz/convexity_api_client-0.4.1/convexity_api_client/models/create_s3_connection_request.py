from __future__ import annotations

from collections.abc import Mapping
from typing import Any, Literal, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="CreateS3ConnectionRequest")


@_attrs_define
class CreateS3ConnectionRequest:
    """
    Attributes:
        name (str): Connection name
        project_id (str): Project this connection belongs to
        bucket (str): S3 bucket name
        region (str): AWS region
        access_key_id (str): AWS access key ID
        secret_access_key (str): AWS secret access key
        type_ (Literal['S3'] | Unset):  Default: 'S3'.
        description (None | str | Unset): Connection description
        prefix (None | str | Unset): Key prefix Default: ''.
        endpoint_url (None | str | Unset): Custom endpoint URL for S3-compatible services (e.g., MinIO, DigitalOcean
            Spaces)
    """

    name: str
    project_id: str
    bucket: str
    region: str
    access_key_id: str
    secret_access_key: str
    type_: Literal["S3"] | Unset = "S3"
    description: None | str | Unset = UNSET
    prefix: None | str | Unset = ""
    endpoint_url: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        name = self.name

        project_id = self.project_id

        bucket = self.bucket

        region = self.region

        access_key_id = self.access_key_id

        secret_access_key = self.secret_access_key

        type_ = self.type_

        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description

        prefix: None | str | Unset
        if isinstance(self.prefix, Unset):
            prefix = UNSET
        else:
            prefix = self.prefix

        endpoint_url: None | str | Unset
        if isinstance(self.endpoint_url, Unset):
            endpoint_url = UNSET
        else:
            endpoint_url = self.endpoint_url

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "name": name,
                "projectId": project_id,
                "bucket": bucket,
                "region": region,
                "accessKeyId": access_key_id,
                "secretAccessKey": secret_access_key,
            }
        )
        if type_ is not UNSET:
            field_dict["type"] = type_
        if description is not UNSET:
            field_dict["description"] = description
        if prefix is not UNSET:
            field_dict["prefix"] = prefix
        if endpoint_url is not UNSET:
            field_dict["endpointUrl"] = endpoint_url

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        name = d.pop("name")

        project_id = d.pop("projectId")

        bucket = d.pop("bucket")

        region = d.pop("region")

        access_key_id = d.pop("accessKeyId")

        secret_access_key = d.pop("secretAccessKey")

        type_ = cast(Literal["S3"] | Unset, d.pop("type", UNSET))
        if type_ != "S3" and not isinstance(type_, Unset):
            raise ValueError(f"type must match const 'S3', got '{type_}'")

        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        description = _parse_description(d.pop("description", UNSET))

        def _parse_prefix(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        prefix = _parse_prefix(d.pop("prefix", UNSET))

        def _parse_endpoint_url(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        endpoint_url = _parse_endpoint_url(d.pop("endpointUrl", UNSET))

        create_s3_connection_request = cls(
            name=name,
            project_id=project_id,
            bucket=bucket,
            region=region,
            access_key_id=access_key_id,
            secret_access_key=secret_access_key,
            type_=type_,
            description=description,
            prefix=prefix,
            endpoint_url=endpoint_url,
        )

        create_s3_connection_request.additional_properties = d
        return create_s3_connection_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
