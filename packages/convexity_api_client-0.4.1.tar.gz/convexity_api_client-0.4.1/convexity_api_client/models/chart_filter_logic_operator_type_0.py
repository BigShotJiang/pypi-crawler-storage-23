from enum import Enum


class ChartFilterLogicOperatorType0(str, Enum):
    AND = "and"
    OR = "or"

    def __str__(self) -> str:
        return str(self.value)
