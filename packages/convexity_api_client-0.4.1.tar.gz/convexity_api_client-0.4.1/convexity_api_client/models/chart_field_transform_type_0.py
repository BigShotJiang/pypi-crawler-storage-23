from enum import Enum


class ChartFieldTransformType0(str, Enum):
    AVG = "avg"
    COUNT = "count"
    COUNT_DISTINCT = "count_distinct"
    MAX = "max"
    MEDIAN = "median"
    MIN = "min"
    NONE = "none"
    PERCENTILE = "percentile"
    STD = "std"
    SUM = "sum"
    VAR = "var"

    def __str__(self) -> str:
        return str(self.value)
