from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.tooltip_series_config import TooltipSeriesConfig


T = TypeVar("T", bound="TooltipConfig")


@_attrs_define
class TooltipConfig:
    """Configuration for tooltip display and formatting.

    Attributes:
        show (bool | None | Unset): Whether to show tooltips Default: True.
        series_configs (list[TooltipSeriesConfig] | None | Unset): Per-series tooltip configuration
    """

    show: bool | None | Unset = True
    series_configs: list[TooltipSeriesConfig] | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        show: bool | None | Unset
        if isinstance(self.show, Unset):
            show = UNSET
        else:
            show = self.show

        series_configs: list[dict[str, Any]] | None | Unset
        if isinstance(self.series_configs, Unset):
            series_configs = UNSET
        elif isinstance(self.series_configs, list):
            series_configs = []
            for series_configs_type_0_item_data in self.series_configs:
                series_configs_type_0_item = series_configs_type_0_item_data.to_dict()
                series_configs.append(series_configs_type_0_item)

        else:
            series_configs = self.series_configs

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if show is not UNSET:
            field_dict["show"] = show
        if series_configs is not UNSET:
            field_dict["seriesConfigs"] = series_configs

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.tooltip_series_config import TooltipSeriesConfig

        d = dict(src_dict)

        def _parse_show(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        show = _parse_show(d.pop("show", UNSET))

        def _parse_series_configs(data: object) -> list[TooltipSeriesConfig] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                series_configs_type_0 = []
                _series_configs_type_0 = data
                for series_configs_type_0_item_data in _series_configs_type_0:
                    series_configs_type_0_item = TooltipSeriesConfig.from_dict(series_configs_type_0_item_data)

                    series_configs_type_0.append(series_configs_type_0_item)

                return series_configs_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[TooltipSeriesConfig] | None | Unset, data)

        series_configs = _parse_series_configs(d.pop("seriesConfigs", UNSET))

        tooltip_config = cls(
            show=show,
            series_configs=series_configs,
        )

        tooltip_config.additional_properties = d
        return tooltip_config

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
