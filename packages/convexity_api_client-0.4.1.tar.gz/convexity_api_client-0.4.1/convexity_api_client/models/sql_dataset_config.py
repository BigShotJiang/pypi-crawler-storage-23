from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.sql_dataset_config_parameters_type_0 import SqlDatasetConfigParametersType0


T = TypeVar("T", bound="SqlDatasetConfig")


@_attrs_define
class SqlDatasetConfig:
    """Configuration for SQL datasets.

    Attributes:
        query (str): SQL query
        row_limit (int | None | Unset): Maximum rows to return (None for no limit)
        parameters (None | SqlDatasetConfigParametersType0 | Unset): Query parameters
        primary_keys (list[str] | None | Unset): Column names forming the primary key for incremental upsert. When set,
            refresh operations use MERGE/upsert instead of full overwrite, only updating changed rows. Requires DuckLake or
            Delta Lake backend.
    """

    query: str
    row_limit: int | None | Unset = UNSET
    parameters: None | SqlDatasetConfigParametersType0 | Unset = UNSET
    primary_keys: list[str] | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.sql_dataset_config_parameters_type_0 import SqlDatasetConfigParametersType0

        query = self.query

        row_limit: int | None | Unset
        if isinstance(self.row_limit, Unset):
            row_limit = UNSET
        else:
            row_limit = self.row_limit

        parameters: dict[str, Any] | None | Unset
        if isinstance(self.parameters, Unset):
            parameters = UNSET
        elif isinstance(self.parameters, SqlDatasetConfigParametersType0):
            parameters = self.parameters.to_dict()
        else:
            parameters = self.parameters

        primary_keys: list[str] | None | Unset
        if isinstance(self.primary_keys, Unset):
            primary_keys = UNSET
        elif isinstance(self.primary_keys, list):
            primary_keys = self.primary_keys

        else:
            primary_keys = self.primary_keys

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "query": query,
            }
        )
        if row_limit is not UNSET:
            field_dict["rowLimit"] = row_limit
        if parameters is not UNSET:
            field_dict["parameters"] = parameters
        if primary_keys is not UNSET:
            field_dict["primaryKeys"] = primary_keys

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.sql_dataset_config_parameters_type_0 import SqlDatasetConfigParametersType0

        d = dict(src_dict)
        query = d.pop("query")

        def _parse_row_limit(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        row_limit = _parse_row_limit(d.pop("rowLimit", UNSET))

        def _parse_parameters(data: object) -> None | SqlDatasetConfigParametersType0 | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                parameters_type_0 = SqlDatasetConfigParametersType0.from_dict(data)

                return parameters_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | SqlDatasetConfigParametersType0 | Unset, data)

        parameters = _parse_parameters(d.pop("parameters", UNSET))

        def _parse_primary_keys(data: object) -> list[str] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                primary_keys_type_0 = cast(list[str], data)

                return primary_keys_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[str] | None | Unset, data)

        primary_keys = _parse_primary_keys(d.pop("primaryKeys", UNSET))

        sql_dataset_config = cls(
            query=query,
            row_limit=row_limit,
            parameters=parameters,
            primary_keys=primary_keys,
        )

        sql_dataset_config.additional_properties = d
        return sql_dataset_config

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
