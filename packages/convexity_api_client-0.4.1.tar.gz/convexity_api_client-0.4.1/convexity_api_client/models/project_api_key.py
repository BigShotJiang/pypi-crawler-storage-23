from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..models.api_key_permission import ApiKeyPermission
from ..models.api_key_status import ApiKeyStatus
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.api_key_usage_log import ApiKeyUsageLog
    from ..models.profile import Profile
    from ..models.project import Project


T = TypeVar("T", bound="ProjectApiKey")


@_attrs_define
class ProjectApiKey:
    """Represents a ProjectApiKey record

    Attributes:
        id (str):
        project_id (str):
        name (str):
        key_prefix (str):
        key_hash (str):
        permission (ApiKeyPermission):
        status (ApiKeyStatus):
        created_by (str):
        use_count (int):
        allowed_ips (list[str]):
        created_at (datetime.datetime):
        updated_at (datetime.datetime):
        description (None | str | Unset):
        expires_at (datetime.datetime | None | Unset):
        last_used_at (datetime.datetime | None | Unset):
        last_used_ip (None | str | Unset):
        rate_limit (int | None | Unset):
        revoked_at (datetime.datetime | None | Unset):
        revoked_by (None | str | Unset):
        project (None | Project | Unset):
        creator (None | Profile | Unset):
        revoker (None | Profile | Unset):
        usage_logs (list[ApiKeyUsageLog] | None | Unset):
    """

    id: str
    project_id: str
    name: str
    key_prefix: str
    key_hash: str
    permission: ApiKeyPermission
    status: ApiKeyStatus
    created_by: str
    use_count: int
    allowed_ips: list[str]
    created_at: datetime.datetime
    updated_at: datetime.datetime
    description: None | str | Unset = UNSET
    expires_at: datetime.datetime | None | Unset = UNSET
    last_used_at: datetime.datetime | None | Unset = UNSET
    last_used_ip: None | str | Unset = UNSET
    rate_limit: int | None | Unset = UNSET
    revoked_at: datetime.datetime | None | Unset = UNSET
    revoked_by: None | str | Unset = UNSET
    project: None | Project | Unset = UNSET
    creator: None | Profile | Unset = UNSET
    revoker: None | Profile | Unset = UNSET
    usage_logs: list[ApiKeyUsageLog] | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.profile import Profile
        from ..models.project import Project

        id = self.id

        project_id = self.project_id

        name = self.name

        key_prefix = self.key_prefix

        key_hash = self.key_hash

        permission = self.permission.value

        status = self.status.value

        created_by = self.created_by

        use_count = self.use_count

        allowed_ips = self.allowed_ips

        created_at = self.created_at.isoformat()

        updated_at = self.updated_at.isoformat()

        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description

        expires_at: None | str | Unset
        if isinstance(self.expires_at, Unset):
            expires_at = UNSET
        elif isinstance(self.expires_at, datetime.datetime):
            expires_at = self.expires_at.isoformat()
        else:
            expires_at = self.expires_at

        last_used_at: None | str | Unset
        if isinstance(self.last_used_at, Unset):
            last_used_at = UNSET
        elif isinstance(self.last_used_at, datetime.datetime):
            last_used_at = self.last_used_at.isoformat()
        else:
            last_used_at = self.last_used_at

        last_used_ip: None | str | Unset
        if isinstance(self.last_used_ip, Unset):
            last_used_ip = UNSET
        else:
            last_used_ip = self.last_used_ip

        rate_limit: int | None | Unset
        if isinstance(self.rate_limit, Unset):
            rate_limit = UNSET
        else:
            rate_limit = self.rate_limit

        revoked_at: None | str | Unset
        if isinstance(self.revoked_at, Unset):
            revoked_at = UNSET
        elif isinstance(self.revoked_at, datetime.datetime):
            revoked_at = self.revoked_at.isoformat()
        else:
            revoked_at = self.revoked_at

        revoked_by: None | str | Unset
        if isinstance(self.revoked_by, Unset):
            revoked_by = UNSET
        else:
            revoked_by = self.revoked_by

        project: dict[str, Any] | None | Unset
        if isinstance(self.project, Unset):
            project = UNSET
        elif isinstance(self.project, Project):
            project = self.project.to_dict()
        else:
            project = self.project

        creator: dict[str, Any] | None | Unset
        if isinstance(self.creator, Unset):
            creator = UNSET
        elif isinstance(self.creator, Profile):
            creator = self.creator.to_dict()
        else:
            creator = self.creator

        revoker: dict[str, Any] | None | Unset
        if isinstance(self.revoker, Unset):
            revoker = UNSET
        elif isinstance(self.revoker, Profile):
            revoker = self.revoker.to_dict()
        else:
            revoker = self.revoker

        usage_logs: list[dict[str, Any]] | None | Unset
        if isinstance(self.usage_logs, Unset):
            usage_logs = UNSET
        elif isinstance(self.usage_logs, list):
            usage_logs = []
            for usage_logs_type_0_item_data in self.usage_logs:
                usage_logs_type_0_item = usage_logs_type_0_item_data.to_dict()
                usage_logs.append(usage_logs_type_0_item)

        else:
            usage_logs = self.usage_logs

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "id": id,
                "project_id": project_id,
                "name": name,
                "key_prefix": key_prefix,
                "key_hash": key_hash,
                "permission": permission,
                "status": status,
                "created_by": created_by,
                "use_count": use_count,
                "allowed_ips": allowed_ips,
                "created_at": created_at,
                "updated_at": updated_at,
            }
        )
        if description is not UNSET:
            field_dict["description"] = description
        if expires_at is not UNSET:
            field_dict["expires_at"] = expires_at
        if last_used_at is not UNSET:
            field_dict["last_used_at"] = last_used_at
        if last_used_ip is not UNSET:
            field_dict["last_used_ip"] = last_used_ip
        if rate_limit is not UNSET:
            field_dict["rate_limit"] = rate_limit
        if revoked_at is not UNSET:
            field_dict["revoked_at"] = revoked_at
        if revoked_by is not UNSET:
            field_dict["revoked_by"] = revoked_by
        if project is not UNSET:
            field_dict["project"] = project
        if creator is not UNSET:
            field_dict["creator"] = creator
        if revoker is not UNSET:
            field_dict["revoker"] = revoker
        if usage_logs is not UNSET:
            field_dict["usage_logs"] = usage_logs

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.api_key_usage_log import ApiKeyUsageLog
        from ..models.profile import Profile
        from ..models.project import Project

        d = dict(src_dict)
        id = d.pop("id")

        project_id = d.pop("project_id")

        name = d.pop("name")

        key_prefix = d.pop("key_prefix")

        key_hash = d.pop("key_hash")

        permission = ApiKeyPermission(d.pop("permission"))

        status = ApiKeyStatus(d.pop("status"))

        created_by = d.pop("created_by")

        use_count = d.pop("use_count")

        allowed_ips = cast(list[str], d.pop("allowed_ips"))

        created_at = isoparse(d.pop("created_at"))

        updated_at = isoparse(d.pop("updated_at"))

        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        description = _parse_description(d.pop("description", UNSET))

        def _parse_expires_at(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                expires_at_type_0 = isoparse(data)

                return expires_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        expires_at = _parse_expires_at(d.pop("expires_at", UNSET))

        def _parse_last_used_at(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                last_used_at_type_0 = isoparse(data)

                return last_used_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        last_used_at = _parse_last_used_at(d.pop("last_used_at", UNSET))

        def _parse_last_used_ip(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        last_used_ip = _parse_last_used_ip(d.pop("last_used_ip", UNSET))

        def _parse_rate_limit(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        rate_limit = _parse_rate_limit(d.pop("rate_limit", UNSET))

        def _parse_revoked_at(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                revoked_at_type_0 = isoparse(data)

                return revoked_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        revoked_at = _parse_revoked_at(d.pop("revoked_at", UNSET))

        def _parse_revoked_by(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        revoked_by = _parse_revoked_by(d.pop("revoked_by", UNSET))

        def _parse_project(data: object) -> None | Project | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                project_type_0 = Project.from_dict(data)

                return project_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Project | Unset, data)

        project = _parse_project(d.pop("project", UNSET))

        def _parse_creator(data: object) -> None | Profile | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                creator_type_0 = Profile.from_dict(data)

                return creator_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Profile | Unset, data)

        creator = _parse_creator(d.pop("creator", UNSET))

        def _parse_revoker(data: object) -> None | Profile | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                revoker_type_0 = Profile.from_dict(data)

                return revoker_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Profile | Unset, data)

        revoker = _parse_revoker(d.pop("revoker", UNSET))

        def _parse_usage_logs(data: object) -> list[ApiKeyUsageLog] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                usage_logs_type_0 = []
                _usage_logs_type_0 = data
                for usage_logs_type_0_item_data in _usage_logs_type_0:
                    usage_logs_type_0_item = ApiKeyUsageLog.from_dict(usage_logs_type_0_item_data)

                    usage_logs_type_0.append(usage_logs_type_0_item)

                return usage_logs_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[ApiKeyUsageLog] | None | Unset, data)

        usage_logs = _parse_usage_logs(d.pop("usage_logs", UNSET))

        project_api_key = cls(
            id=id,
            project_id=project_id,
            name=name,
            key_prefix=key_prefix,
            key_hash=key_hash,
            permission=permission,
            status=status,
            created_by=created_by,
            use_count=use_count,
            allowed_ips=allowed_ips,
            created_at=created_at,
            updated_at=updated_at,
            description=description,
            expires_at=expires_at,
            last_used_at=last_used_at,
            last_used_ip=last_used_ip,
            rate_limit=rate_limit,
            revoked_at=revoked_at,
            revoked_by=revoked_by,
            project=project,
            creator=creator,
            revoker=revoker,
            usage_logs=usage_logs,
        )

        project_api_key.additional_properties = d
        return project_api_key

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
