from enum import Enum


class ColumnRole(str, Enum):
    DIMENSION = "dimension"
    MEASURE = "measure"

    def __str__(self) -> str:
        return str(self.value)
