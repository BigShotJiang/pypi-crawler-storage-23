from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.profile import Profile
    from ..models.token_purchase import TokenPurchase


T = TypeVar("T", bound="TokenPackage")


@_attrs_define
class TokenPackage:
    """Represents a TokenPackage record

    Attributes:
        id (str):
        name (str):
        tokens (int):
        price_usd (float | str):
        price_per_token (float | str):
        is_active (bool):
        is_featured (bool):
        sort_order (int):
        created_at (datetime.datetime):
        updated_at (datetime.datetime):
        description (None | str | Unset):
        discount_percent (int | None | Unset):
        profiles (list[Profile] | None | Unset):
        token_purchases (list[TokenPurchase] | None | Unset):
    """

    id: str
    name: str
    tokens: int
    price_usd: float | str
    price_per_token: float | str
    is_active: bool
    is_featured: bool
    sort_order: int
    created_at: datetime.datetime
    updated_at: datetime.datetime
    description: None | str | Unset = UNSET
    discount_percent: int | None | Unset = UNSET
    profiles: list[Profile] | None | Unset = UNSET
    token_purchases: list[TokenPurchase] | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        id = self.id

        name = self.name

        tokens = self.tokens

        price_usd: float | str
        price_usd = self.price_usd

        price_per_token: float | str
        price_per_token = self.price_per_token

        is_active = self.is_active

        is_featured = self.is_featured

        sort_order = self.sort_order

        created_at = self.created_at.isoformat()

        updated_at = self.updated_at.isoformat()

        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description

        discount_percent: int | None | Unset
        if isinstance(self.discount_percent, Unset):
            discount_percent = UNSET
        else:
            discount_percent = self.discount_percent

        profiles: list[dict[str, Any]] | None | Unset
        if isinstance(self.profiles, Unset):
            profiles = UNSET
        elif isinstance(self.profiles, list):
            profiles = []
            for profiles_type_0_item_data in self.profiles:
                profiles_type_0_item = profiles_type_0_item_data.to_dict()
                profiles.append(profiles_type_0_item)

        else:
            profiles = self.profiles

        token_purchases: list[dict[str, Any]] | None | Unset
        if isinstance(self.token_purchases, Unset):
            token_purchases = UNSET
        elif isinstance(self.token_purchases, list):
            token_purchases = []
            for token_purchases_type_0_item_data in self.token_purchases:
                token_purchases_type_0_item = token_purchases_type_0_item_data.to_dict()
                token_purchases.append(token_purchases_type_0_item)

        else:
            token_purchases = self.token_purchases

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "id": id,
                "name": name,
                "tokens": tokens,
                "price_usd": price_usd,
                "price_per_token": price_per_token,
                "is_active": is_active,
                "is_featured": is_featured,
                "sort_order": sort_order,
                "created_at": created_at,
                "updated_at": updated_at,
            }
        )
        if description is not UNSET:
            field_dict["description"] = description
        if discount_percent is not UNSET:
            field_dict["discount_percent"] = discount_percent
        if profiles is not UNSET:
            field_dict["profiles"] = profiles
        if token_purchases is not UNSET:
            field_dict["token_purchases"] = token_purchases

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.profile import Profile
        from ..models.token_purchase import TokenPurchase

        d = dict(src_dict)
        id = d.pop("id")

        name = d.pop("name")

        tokens = d.pop("tokens")

        def _parse_price_usd(data: object) -> float | str:
            return cast(float | str, data)

        price_usd = _parse_price_usd(d.pop("price_usd"))

        def _parse_price_per_token(data: object) -> float | str:
            return cast(float | str, data)

        price_per_token = _parse_price_per_token(d.pop("price_per_token"))

        is_active = d.pop("is_active")

        is_featured = d.pop("is_featured")

        sort_order = d.pop("sort_order")

        created_at = isoparse(d.pop("created_at"))

        updated_at = isoparse(d.pop("updated_at"))

        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        description = _parse_description(d.pop("description", UNSET))

        def _parse_discount_percent(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        discount_percent = _parse_discount_percent(d.pop("discount_percent", UNSET))

        def _parse_profiles(data: object) -> list[Profile] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                profiles_type_0 = []
                _profiles_type_0 = data
                for profiles_type_0_item_data in _profiles_type_0:
                    profiles_type_0_item = Profile.from_dict(profiles_type_0_item_data)

                    profiles_type_0.append(profiles_type_0_item)

                return profiles_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[Profile] | None | Unset, data)

        profiles = _parse_profiles(d.pop("profiles", UNSET))

        def _parse_token_purchases(data: object) -> list[TokenPurchase] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                token_purchases_type_0 = []
                _token_purchases_type_0 = data
                for token_purchases_type_0_item_data in _token_purchases_type_0:
                    token_purchases_type_0_item = TokenPurchase.from_dict(token_purchases_type_0_item_data)

                    token_purchases_type_0.append(token_purchases_type_0_item)

                return token_purchases_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[TokenPurchase] | None | Unset, data)

        token_purchases = _parse_token_purchases(d.pop("token_purchases", UNSET))

        token_package = cls(
            id=id,
            name=name,
            tokens=tokens,
            price_usd=price_usd,
            price_per_token=price_per_token,
            is_active=is_active,
            is_featured=is_featured,
            sort_order=sort_order,
            created_at=created_at,
            updated_at=updated_at,
            description=description,
            discount_percent=discount_percent,
            profiles=profiles,
            token_purchases=token_purchases,
        )

        token_package.additional_properties = d
        return token_package

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
