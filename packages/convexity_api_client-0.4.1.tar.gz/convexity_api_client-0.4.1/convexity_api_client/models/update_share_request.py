from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

T = TypeVar("T", bound="UpdateShareRequest")


@_attrs_define
class UpdateShareRequest:
    """Request to update share settings.

    Attributes:
        is_active (bool | None | Unset): Whether the share is active
        expires_at (datetime.datetime | None | Unset): When the share link expires
        allowed_domains (list[str] | None | Unset): Domains allowed to embed
        allow_filtering (bool | None | Unset): Allow viewers to use filters
        show_branding (bool | None | Unset): Show branding in shared view
        custom_title (None | str | Unset): Custom title for shared view
    """

    is_active: bool | None | Unset = UNSET
    expires_at: datetime.datetime | None | Unset = UNSET
    allowed_domains: list[str] | None | Unset = UNSET
    allow_filtering: bool | None | Unset = UNSET
    show_branding: bool | None | Unset = UNSET
    custom_title: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        is_active: bool | None | Unset
        if isinstance(self.is_active, Unset):
            is_active = UNSET
        else:
            is_active = self.is_active

        expires_at: None | str | Unset
        if isinstance(self.expires_at, Unset):
            expires_at = UNSET
        elif isinstance(self.expires_at, datetime.datetime):
            expires_at = self.expires_at.isoformat()
        else:
            expires_at = self.expires_at

        allowed_domains: list[str] | None | Unset
        if isinstance(self.allowed_domains, Unset):
            allowed_domains = UNSET
        elif isinstance(self.allowed_domains, list):
            allowed_domains = self.allowed_domains

        else:
            allowed_domains = self.allowed_domains

        allow_filtering: bool | None | Unset
        if isinstance(self.allow_filtering, Unset):
            allow_filtering = UNSET
        else:
            allow_filtering = self.allow_filtering

        show_branding: bool | None | Unset
        if isinstance(self.show_branding, Unset):
            show_branding = UNSET
        else:
            show_branding = self.show_branding

        custom_title: None | str | Unset
        if isinstance(self.custom_title, Unset):
            custom_title = UNSET
        else:
            custom_title = self.custom_title

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if is_active is not UNSET:
            field_dict["isActive"] = is_active
        if expires_at is not UNSET:
            field_dict["expiresAt"] = expires_at
        if allowed_domains is not UNSET:
            field_dict["allowedDomains"] = allowed_domains
        if allow_filtering is not UNSET:
            field_dict["allowFiltering"] = allow_filtering
        if show_branding is not UNSET:
            field_dict["showBranding"] = show_branding
        if custom_title is not UNSET:
            field_dict["customTitle"] = custom_title

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)

        def _parse_is_active(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        is_active = _parse_is_active(d.pop("isActive", UNSET))

        def _parse_expires_at(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                expires_at_type_0 = isoparse(data)

                return expires_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        expires_at = _parse_expires_at(d.pop("expiresAt", UNSET))

        def _parse_allowed_domains(data: object) -> list[str] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                allowed_domains_type_0 = cast(list[str], data)

                return allowed_domains_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[str] | None | Unset, data)

        allowed_domains = _parse_allowed_domains(d.pop("allowedDomains", UNSET))

        def _parse_allow_filtering(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        allow_filtering = _parse_allow_filtering(d.pop("allowFiltering", UNSET))

        def _parse_show_branding(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        show_branding = _parse_show_branding(d.pop("showBranding", UNSET))

        def _parse_custom_title(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        custom_title = _parse_custom_title(d.pop("customTitle", UNSET))

        update_share_request = cls(
            is_active=is_active,
            expires_at=expires_at,
            allowed_domains=allowed_domains,
            allow_filtering=allow_filtering,
            show_branding=show_branding,
            custom_title=custom_title,
        )

        update_share_request.additional_properties = d
        return update_share_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
