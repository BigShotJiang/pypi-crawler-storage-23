from enum import Enum


class ScatterChartConfigSymbolType0(str, Enum):
    CIRCLE = "circle"
    DIAMOND = "diamond"
    RECT = "rect"
    TRIANGLE = "triangle"

    def __str__(self) -> str:
        return str(self.value)
