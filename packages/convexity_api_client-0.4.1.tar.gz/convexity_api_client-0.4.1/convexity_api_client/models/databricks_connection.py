from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, Literal, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.connection_status import ConnectionStatus
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.table_info import TableInfo


T = TypeVar("T", bound="DatabricksConnection")


@_attrs_define
class DatabricksConnection:
    """Connection to Databricks SQL Warehouse.

    Attributes:
        project_id (str): Project this connection belongs to
        name (str): Connection name
        server_hostname (str): Databricks workspace hostname
        http_path (str): SQL warehouse HTTP path
        access_token (str): Personal access token
        id (None | str | Unset): Connection ID
        user_id (None | str | Unset): Owner user ID
        description (None | str | Unset): Connection description
        type_ (Literal['DATABRICKS_V1'] | Unset):  Default: 'DATABRICKS_V1'.
        status (ConnectionStatus | Unset):
        last_tested (None | str | Unset): Last verification timestamp
        error_message (None | str | Unset): Error message if status is error
        created_at (None | str | Unset): Creation timestamp
        updated_at (None | str | Unset): Last update timestamp
        catalog (None | str | Unset): Default catalog
        db_schema (None | str | Unset): Default schema Default: 'default'.
        tables (list[TableInfo] | None | Unset): Discovered tables with their schemas
    """

    project_id: str
    name: str
    server_hostname: str
    http_path: str
    access_token: str
    id: None | str | Unset = UNSET
    user_id: None | str | Unset = UNSET
    description: None | str | Unset = UNSET
    type_: Literal["DATABRICKS_V1"] | Unset = "DATABRICKS_V1"
    status: ConnectionStatus | Unset = UNSET
    last_tested: None | str | Unset = UNSET
    error_message: None | str | Unset = UNSET
    created_at: None | str | Unset = UNSET
    updated_at: None | str | Unset = UNSET
    catalog: None | str | Unset = UNSET
    db_schema: None | str | Unset = "default"
    tables: list[TableInfo] | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        project_id = self.project_id

        name = self.name

        server_hostname = self.server_hostname

        http_path = self.http_path

        access_token = self.access_token

        id: None | str | Unset
        if isinstance(self.id, Unset):
            id = UNSET
        else:
            id = self.id

        user_id: None | str | Unset
        if isinstance(self.user_id, Unset):
            user_id = UNSET
        else:
            user_id = self.user_id

        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description

        type_ = self.type_

        status: str | Unset = UNSET
        if not isinstance(self.status, Unset):
            status = self.status.value

        last_tested: None | str | Unset
        if isinstance(self.last_tested, Unset):
            last_tested = UNSET
        else:
            last_tested = self.last_tested

        error_message: None | str | Unset
        if isinstance(self.error_message, Unset):
            error_message = UNSET
        else:
            error_message = self.error_message

        created_at: None | str | Unset
        if isinstance(self.created_at, Unset):
            created_at = UNSET
        else:
            created_at = self.created_at

        updated_at: None | str | Unset
        if isinstance(self.updated_at, Unset):
            updated_at = UNSET
        else:
            updated_at = self.updated_at

        catalog: None | str | Unset
        if isinstance(self.catalog, Unset):
            catalog = UNSET
        else:
            catalog = self.catalog

        db_schema: None | str | Unset
        if isinstance(self.db_schema, Unset):
            db_schema = UNSET
        else:
            db_schema = self.db_schema

        tables: list[dict[str, Any]] | None | Unset
        if isinstance(self.tables, Unset):
            tables = UNSET
        elif isinstance(self.tables, list):
            tables = []
            for tables_type_0_item_data in self.tables:
                tables_type_0_item = tables_type_0_item_data.to_dict()
                tables.append(tables_type_0_item)

        else:
            tables = self.tables

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "projectId": project_id,
                "name": name,
                "serverHostname": server_hostname,
                "httpPath": http_path,
                "accessToken": access_token,
            }
        )
        if id is not UNSET:
            field_dict["id"] = id
        if user_id is not UNSET:
            field_dict["userId"] = user_id
        if description is not UNSET:
            field_dict["description"] = description
        if type_ is not UNSET:
            field_dict["type"] = type_
        if status is not UNSET:
            field_dict["status"] = status
        if last_tested is not UNSET:
            field_dict["lastTested"] = last_tested
        if error_message is not UNSET:
            field_dict["errorMessage"] = error_message
        if created_at is not UNSET:
            field_dict["createdAt"] = created_at
        if updated_at is not UNSET:
            field_dict["updatedAt"] = updated_at
        if catalog is not UNSET:
            field_dict["catalog"] = catalog
        if db_schema is not UNSET:
            field_dict["dbSchema"] = db_schema
        if tables is not UNSET:
            field_dict["tables"] = tables

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.table_info import TableInfo

        d = dict(src_dict)
        project_id = d.pop("projectId")

        name = d.pop("name")

        server_hostname = d.pop("serverHostname")

        http_path = d.pop("httpPath")

        access_token = d.pop("accessToken")

        def _parse_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        id = _parse_id(d.pop("id", UNSET))

        def _parse_user_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        user_id = _parse_user_id(d.pop("userId", UNSET))

        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        description = _parse_description(d.pop("description", UNSET))

        type_ = cast(Literal["DATABRICKS_V1"] | Unset, d.pop("type", UNSET))
        if type_ != "DATABRICKS_V1" and not isinstance(type_, Unset):
            raise ValueError(f"type must match const 'DATABRICKS_V1', got '{type_}'")

        _status = d.pop("status", UNSET)
        status: ConnectionStatus | Unset
        if isinstance(_status, Unset):
            status = UNSET
        else:
            status = ConnectionStatus(_status)

        def _parse_last_tested(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        last_tested = _parse_last_tested(d.pop("lastTested", UNSET))

        def _parse_error_message(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        error_message = _parse_error_message(d.pop("errorMessage", UNSET))

        def _parse_created_at(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        created_at = _parse_created_at(d.pop("createdAt", UNSET))

        def _parse_updated_at(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        updated_at = _parse_updated_at(d.pop("updatedAt", UNSET))

        def _parse_catalog(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        catalog = _parse_catalog(d.pop("catalog", UNSET))

        def _parse_db_schema(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        db_schema = _parse_db_schema(d.pop("dbSchema", UNSET))

        def _parse_tables(data: object) -> list[TableInfo] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                tables_type_0 = []
                _tables_type_0 = data
                for tables_type_0_item_data in _tables_type_0:
                    tables_type_0_item = TableInfo.from_dict(tables_type_0_item_data)

                    tables_type_0.append(tables_type_0_item)

                return tables_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[TableInfo] | None | Unset, data)

        tables = _parse_tables(d.pop("tables", UNSET))

        databricks_connection = cls(
            project_id=project_id,
            name=name,
            server_hostname=server_hostname,
            http_path=http_path,
            access_token=access_token,
            id=id,
            user_id=user_id,
            description=description,
            type_=type_,
            status=status,
            last_tested=last_tested,
            error_message=error_message,
            created_at=created_at,
            updated_at=updated_at,
            catalog=catalog,
            db_schema=db_schema,
            tables=tables,
        )

        databricks_connection.additional_properties = d
        return databricks_connection

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
