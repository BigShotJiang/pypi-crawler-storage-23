from enum import Enum


class KpiChartConfigFontWeightType0(str, Enum):
    BOLD = "bold"
    MEDIUM = "medium"
    NORMAL = "normal"
    SEMIBOLD = "semibold"

    def __str__(self) -> str:
        return str(self.value)
