from enum import Enum


class ApiKeyPermission(str, Enum):
    ADMIN = "ADMIN"
    READ = "READ"
    WRITE = "WRITE"

    def __str__(self) -> str:
        return str(self.value)
