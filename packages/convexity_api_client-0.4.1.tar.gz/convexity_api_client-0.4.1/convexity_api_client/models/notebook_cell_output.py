from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.notebook_cell_error import NotebookCellError
    from ..models.notebook_cell_output_item import NotebookCellOutputItem


T = TypeVar("T", bound="NotebookCellOutput")


@_attrs_define
class NotebookCellOutput:
    """Complete output from executing a notebook cell.

    Attributes:
        success (bool):
        execution_time_ms (int):
        outputs (list[NotebookCellOutputItem] | None | Unset):
        error (None | NotebookCellError | Unset):
    """

    success: bool
    execution_time_ms: int
    outputs: list[NotebookCellOutputItem] | None | Unset = UNSET
    error: None | NotebookCellError | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.notebook_cell_error import NotebookCellError

        success = self.success

        execution_time_ms = self.execution_time_ms

        outputs: list[dict[str, Any]] | None | Unset
        if isinstance(self.outputs, Unset):
            outputs = UNSET
        elif isinstance(self.outputs, list):
            outputs = []
            for outputs_type_0_item_data in self.outputs:
                outputs_type_0_item = outputs_type_0_item_data.to_dict()
                outputs.append(outputs_type_0_item)

        else:
            outputs = self.outputs

        error: dict[str, Any] | None | Unset
        if isinstance(self.error, Unset):
            error = UNSET
        elif isinstance(self.error, NotebookCellError):
            error = self.error.to_dict()
        else:
            error = self.error

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "success": success,
                "execution_time_ms": execution_time_ms,
            }
        )
        if outputs is not UNSET:
            field_dict["outputs"] = outputs
        if error is not UNSET:
            field_dict["error"] = error

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.notebook_cell_error import NotebookCellError
        from ..models.notebook_cell_output_item import NotebookCellOutputItem

        d = dict(src_dict)
        success = d.pop("success")

        execution_time_ms = d.pop("execution_time_ms")

        def _parse_outputs(data: object) -> list[NotebookCellOutputItem] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                outputs_type_0 = []
                _outputs_type_0 = data
                for outputs_type_0_item_data in _outputs_type_0:
                    outputs_type_0_item = NotebookCellOutputItem.from_dict(outputs_type_0_item_data)

                    outputs_type_0.append(outputs_type_0_item)

                return outputs_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[NotebookCellOutputItem] | None | Unset, data)

        outputs = _parse_outputs(d.pop("outputs", UNSET))

        def _parse_error(data: object) -> None | NotebookCellError | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                error_type_0 = NotebookCellError.from_dict(data)

                return error_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | NotebookCellError | Unset, data)

        error = _parse_error(d.pop("error", UNSET))

        notebook_cell_output = cls(
            success=success,
            execution_time_ms=execution_time_ms,
            outputs=outputs,
            error=error,
        )

        notebook_cell_output.additional_properties = d
        return notebook_cell_output

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
