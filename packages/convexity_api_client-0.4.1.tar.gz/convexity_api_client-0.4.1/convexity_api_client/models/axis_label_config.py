from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.axis_label_config_format_type_0 import AxisLabelConfigFormatType0
from ..types import UNSET, Unset

T = TypeVar("T", bound="AxisLabelConfig")


@_attrs_define
class AxisLabelConfig:
    """Configuration for axis labels and formatting.

    Attributes:
        show (bool | None | Unset): Whether to show the axis label Default: True.
        text (None | str | Unset): Custom axis label text
        format_ (AxisLabelConfigFormatType0 | None | Unset): Number format for axis values Default:
            AxisLabelConfigFormatType0.NUMBER.
        decimal_places (int | None | Unset): Number of decimal places to display
        prefix (None | str | Unset): Prefix for axis values (e.g., '$')
        suffix (None | str | Unset): Suffix for axis values (e.g., '%', 'K', 'M')
    """

    show: bool | None | Unset = True
    text: None | str | Unset = UNSET
    format_: AxisLabelConfigFormatType0 | None | Unset = AxisLabelConfigFormatType0.NUMBER
    decimal_places: int | None | Unset = UNSET
    prefix: None | str | Unset = UNSET
    suffix: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        show: bool | None | Unset
        if isinstance(self.show, Unset):
            show = UNSET
        else:
            show = self.show

        text: None | str | Unset
        if isinstance(self.text, Unset):
            text = UNSET
        else:
            text = self.text

        format_: None | str | Unset
        if isinstance(self.format_, Unset):
            format_ = UNSET
        elif isinstance(self.format_, AxisLabelConfigFormatType0):
            format_ = self.format_.value
        else:
            format_ = self.format_

        decimal_places: int | None | Unset
        if isinstance(self.decimal_places, Unset):
            decimal_places = UNSET
        else:
            decimal_places = self.decimal_places

        prefix: None | str | Unset
        if isinstance(self.prefix, Unset):
            prefix = UNSET
        else:
            prefix = self.prefix

        suffix: None | str | Unset
        if isinstance(self.suffix, Unset):
            suffix = UNSET
        else:
            suffix = self.suffix

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if show is not UNSET:
            field_dict["show"] = show
        if text is not UNSET:
            field_dict["text"] = text
        if format_ is not UNSET:
            field_dict["format"] = format_
        if decimal_places is not UNSET:
            field_dict["decimalPlaces"] = decimal_places
        if prefix is not UNSET:
            field_dict["prefix"] = prefix
        if suffix is not UNSET:
            field_dict["suffix"] = suffix

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)

        def _parse_show(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        show = _parse_show(d.pop("show", UNSET))

        def _parse_text(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        text = _parse_text(d.pop("text", UNSET))

        def _parse_format_(data: object) -> AxisLabelConfigFormatType0 | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                format_type_0 = AxisLabelConfigFormatType0(data)

                return format_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(AxisLabelConfigFormatType0 | None | Unset, data)

        format_ = _parse_format_(d.pop("format", UNSET))

        def _parse_decimal_places(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        decimal_places = _parse_decimal_places(d.pop("decimalPlaces", UNSET))

        def _parse_prefix(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        prefix = _parse_prefix(d.pop("prefix", UNSET))

        def _parse_suffix(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        suffix = _parse_suffix(d.pop("suffix", UNSET))

        axis_label_config = cls(
            show=show,
            text=text,
            format_=format_,
            decimal_places=decimal_places,
            prefix=prefix,
            suffix=suffix,
        )

        axis_label_config.additional_properties = d
        return axis_label_config

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
