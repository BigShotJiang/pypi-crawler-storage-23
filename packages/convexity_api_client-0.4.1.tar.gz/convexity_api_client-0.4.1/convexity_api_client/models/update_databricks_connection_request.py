from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="UpdateDatabricksConnectionRequest")


@_attrs_define
class UpdateDatabricksConnectionRequest:
    """
    Attributes:
        name (None | str | Unset): Connection name
        description (None | str | Unset): Connection description
        server_hostname (None | str | Unset): Databricks workspace hostname
        http_path (None | str | Unset): SQL warehouse HTTP path
        access_token (None | str | Unset): Personal access token
        catalog (None | str | Unset): Default catalog
        db_schema (None | str | Unset): Default schema
    """

    name: None | str | Unset = UNSET
    description: None | str | Unset = UNSET
    server_hostname: None | str | Unset = UNSET
    http_path: None | str | Unset = UNSET
    access_token: None | str | Unset = UNSET
    catalog: None | str | Unset = UNSET
    db_schema: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        name: None | str | Unset
        if isinstance(self.name, Unset):
            name = UNSET
        else:
            name = self.name

        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description

        server_hostname: None | str | Unset
        if isinstance(self.server_hostname, Unset):
            server_hostname = UNSET
        else:
            server_hostname = self.server_hostname

        http_path: None | str | Unset
        if isinstance(self.http_path, Unset):
            http_path = UNSET
        else:
            http_path = self.http_path

        access_token: None | str | Unset
        if isinstance(self.access_token, Unset):
            access_token = UNSET
        else:
            access_token = self.access_token

        catalog: None | str | Unset
        if isinstance(self.catalog, Unset):
            catalog = UNSET
        else:
            catalog = self.catalog

        db_schema: None | str | Unset
        if isinstance(self.db_schema, Unset):
            db_schema = UNSET
        else:
            db_schema = self.db_schema

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if name is not UNSET:
            field_dict["name"] = name
        if description is not UNSET:
            field_dict["description"] = description
        if server_hostname is not UNSET:
            field_dict["serverHostname"] = server_hostname
        if http_path is not UNSET:
            field_dict["httpPath"] = http_path
        if access_token is not UNSET:
            field_dict["accessToken"] = access_token
        if catalog is not UNSET:
            field_dict["catalog"] = catalog
        if db_schema is not UNSET:
            field_dict["dbSchema"] = db_schema

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)

        def _parse_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        name = _parse_name(d.pop("name", UNSET))

        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        description = _parse_description(d.pop("description", UNSET))

        def _parse_server_hostname(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        server_hostname = _parse_server_hostname(d.pop("serverHostname", UNSET))

        def _parse_http_path(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        http_path = _parse_http_path(d.pop("httpPath", UNSET))

        def _parse_access_token(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        access_token = _parse_access_token(d.pop("accessToken", UNSET))

        def _parse_catalog(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        catalog = _parse_catalog(d.pop("catalog", UNSET))

        def _parse_db_schema(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        db_schema = _parse_db_schema(d.pop("dbSchema", UNSET))

        update_databricks_connection_request = cls(
            name=name,
            description=description,
            server_hostname=server_hostname,
            http_path=http_path,
            access_token=access_token,
            catalog=catalog,
            db_schema=db_schema,
        )

        update_databricks_connection_request.additional_properties = d
        return update_databricks_connection_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
