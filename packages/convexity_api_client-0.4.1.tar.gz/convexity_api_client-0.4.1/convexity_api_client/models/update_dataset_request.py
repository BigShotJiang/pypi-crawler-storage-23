from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.refresh_mode import RefreshMode
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.column import Column
    from ..models.dataset_config import DatasetConfig


T = TypeVar("T", bound="UpdateDatasetRequest")


@_attrs_define
class UpdateDatasetRequest:
    """Request to update a dataset.

    Attributes:
        name (None | str | Unset): Dataset name
        description (None | str | Unset): Dataset description
        connection_id (None | str | Unset): Connection ID
        config (DatasetConfig | None | Unset): Dataset configuration
        schema (list[Column] | None | Unset): Column schema
        refresh_mode (None | RefreshMode | Unset): Refresh mode
        refresh_schedule (None | str | Unset): Cron schedule
        cache_ttl_seconds (int | None | Unset): Cache TTL
        tags (list[str] | None | Unset): Tags
    """

    name: None | str | Unset = UNSET
    description: None | str | Unset = UNSET
    connection_id: None | str | Unset = UNSET
    config: DatasetConfig | None | Unset = UNSET
    schema: list[Column] | None | Unset = UNSET
    refresh_mode: None | RefreshMode | Unset = UNSET
    refresh_schedule: None | str | Unset = UNSET
    cache_ttl_seconds: int | None | Unset = UNSET
    tags: list[str] | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.dataset_config import DatasetConfig

        name: None | str | Unset
        if isinstance(self.name, Unset):
            name = UNSET
        else:
            name = self.name

        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description

        connection_id: None | str | Unset
        if isinstance(self.connection_id, Unset):
            connection_id = UNSET
        else:
            connection_id = self.connection_id

        config: dict[str, Any] | None | Unset
        if isinstance(self.config, Unset):
            config = UNSET
        elif isinstance(self.config, DatasetConfig):
            config = self.config.to_dict()
        else:
            config = self.config

        schema: list[dict[str, Any]] | None | Unset
        if isinstance(self.schema, Unset):
            schema = UNSET
        elif isinstance(self.schema, list):
            schema = []
            for schema_type_0_item_data in self.schema:
                schema_type_0_item = schema_type_0_item_data.to_dict()
                schema.append(schema_type_0_item)

        else:
            schema = self.schema

        refresh_mode: None | str | Unset
        if isinstance(self.refresh_mode, Unset):
            refresh_mode = UNSET
        elif isinstance(self.refresh_mode, RefreshMode):
            refresh_mode = self.refresh_mode.value
        else:
            refresh_mode = self.refresh_mode

        refresh_schedule: None | str | Unset
        if isinstance(self.refresh_schedule, Unset):
            refresh_schedule = UNSET
        else:
            refresh_schedule = self.refresh_schedule

        cache_ttl_seconds: int | None | Unset
        if isinstance(self.cache_ttl_seconds, Unset):
            cache_ttl_seconds = UNSET
        else:
            cache_ttl_seconds = self.cache_ttl_seconds

        tags: list[str] | None | Unset
        if isinstance(self.tags, Unset):
            tags = UNSET
        elif isinstance(self.tags, list):
            tags = self.tags

        else:
            tags = self.tags

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if name is not UNSET:
            field_dict["name"] = name
        if description is not UNSET:
            field_dict["description"] = description
        if connection_id is not UNSET:
            field_dict["connectionId"] = connection_id
        if config is not UNSET:
            field_dict["config"] = config
        if schema is not UNSET:
            field_dict["schema"] = schema
        if refresh_mode is not UNSET:
            field_dict["refreshMode"] = refresh_mode
        if refresh_schedule is not UNSET:
            field_dict["refreshSchedule"] = refresh_schedule
        if cache_ttl_seconds is not UNSET:
            field_dict["cacheTtlSeconds"] = cache_ttl_seconds
        if tags is not UNSET:
            field_dict["tags"] = tags

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.column import Column
        from ..models.dataset_config import DatasetConfig

        d = dict(src_dict)

        def _parse_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        name = _parse_name(d.pop("name", UNSET))

        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        description = _parse_description(d.pop("description", UNSET))

        def _parse_connection_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        connection_id = _parse_connection_id(d.pop("connectionId", UNSET))

        def _parse_config(data: object) -> DatasetConfig | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                config_type_0 = DatasetConfig.from_dict(data)

                return config_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(DatasetConfig | None | Unset, data)

        config = _parse_config(d.pop("config", UNSET))

        def _parse_schema(data: object) -> list[Column] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                schema_type_0 = []
                _schema_type_0 = data
                for schema_type_0_item_data in _schema_type_0:
                    schema_type_0_item = Column.from_dict(schema_type_0_item_data)

                    schema_type_0.append(schema_type_0_item)

                return schema_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[Column] | None | Unset, data)

        schema = _parse_schema(d.pop("schema", UNSET))

        def _parse_refresh_mode(data: object) -> None | RefreshMode | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                refresh_mode_type_0 = RefreshMode(data)

                return refresh_mode_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | RefreshMode | Unset, data)

        refresh_mode = _parse_refresh_mode(d.pop("refreshMode", UNSET))

        def _parse_refresh_schedule(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        refresh_schedule = _parse_refresh_schedule(d.pop("refreshSchedule", UNSET))

        def _parse_cache_ttl_seconds(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        cache_ttl_seconds = _parse_cache_ttl_seconds(d.pop("cacheTtlSeconds", UNSET))

        def _parse_tags(data: object) -> list[str] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                tags_type_0 = cast(list[str], data)

                return tags_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[str] | None | Unset, data)

        tags = _parse_tags(d.pop("tags", UNSET))

        update_dataset_request = cls(
            name=name,
            description=description,
            connection_id=connection_id,
            config=config,
            schema=schema,
            refresh_mode=refresh_mode,
            refresh_schedule=refresh_schedule,
            cache_ttl_seconds=cache_ttl_seconds,
            tags=tags,
        )

        update_dataset_request.additional_properties = d
        return update_dataset_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
