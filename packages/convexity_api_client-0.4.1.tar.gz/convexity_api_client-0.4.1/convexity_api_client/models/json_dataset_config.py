from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.json_dataset_config_sourcetype import JsonDatasetConfigSourcetype
from ..types import UNSET, Unset

T = TypeVar("T", bound="JsonDatasetConfig")


@_attrs_define
class JsonDatasetConfig:
    """Configuration for JSON data from S3, URL, or upload.

    Attributes:
        source_type (JsonDatasetConfigSourcetype | Unset): Source type Default: JsonDatasetConfigSourcetype.S3.
        connection_id (None | str | Unset): S3 connection ID
        object_key (None | str | Unset): S3 object key
        url (None | str | Unset): URL for remote JSON
        file_id (None | str | Unset): Uploaded file ID
        json_path (None | str | Unset): JSONPath to extract specific data
    """

    source_type: JsonDatasetConfigSourcetype | Unset = JsonDatasetConfigSourcetype.S3
    connection_id: None | str | Unset = UNSET
    object_key: None | str | Unset = UNSET
    url: None | str | Unset = UNSET
    file_id: None | str | Unset = UNSET
    json_path: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        source_type: str | Unset = UNSET
        if not isinstance(self.source_type, Unset):
            source_type = self.source_type.value

        connection_id: None | str | Unset
        if isinstance(self.connection_id, Unset):
            connection_id = UNSET
        else:
            connection_id = self.connection_id

        object_key: None | str | Unset
        if isinstance(self.object_key, Unset):
            object_key = UNSET
        else:
            object_key = self.object_key

        url: None | str | Unset
        if isinstance(self.url, Unset):
            url = UNSET
        else:
            url = self.url

        file_id: None | str | Unset
        if isinstance(self.file_id, Unset):
            file_id = UNSET
        else:
            file_id = self.file_id

        json_path: None | str | Unset
        if isinstance(self.json_path, Unset):
            json_path = UNSET
        else:
            json_path = self.json_path

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if source_type is not UNSET:
            field_dict["sourceType"] = source_type
        if connection_id is not UNSET:
            field_dict["connectionId"] = connection_id
        if object_key is not UNSET:
            field_dict["objectKey"] = object_key
        if url is not UNSET:
            field_dict["url"] = url
        if file_id is not UNSET:
            field_dict["fileId"] = file_id
        if json_path is not UNSET:
            field_dict["jsonPath"] = json_path

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        _source_type = d.pop("sourceType", UNSET)
        source_type: JsonDatasetConfigSourcetype | Unset
        if isinstance(_source_type, Unset):
            source_type = UNSET
        else:
            source_type = JsonDatasetConfigSourcetype(_source_type)

        def _parse_connection_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        connection_id = _parse_connection_id(d.pop("connectionId", UNSET))

        def _parse_object_key(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        object_key = _parse_object_key(d.pop("objectKey", UNSET))

        def _parse_url(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        url = _parse_url(d.pop("url", UNSET))

        def _parse_file_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        file_id = _parse_file_id(d.pop("fileId", UNSET))

        def _parse_json_path(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        json_path = _parse_json_path(d.pop("jsonPath", UNSET))

        json_dataset_config = cls(
            source_type=source_type,
            connection_id=connection_id,
            object_key=object_key,
            url=url,
            file_id=file_id,
            json_path=json_path,
        )

        json_dataset_config.additional_properties = d
        return json_dataset_config

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
