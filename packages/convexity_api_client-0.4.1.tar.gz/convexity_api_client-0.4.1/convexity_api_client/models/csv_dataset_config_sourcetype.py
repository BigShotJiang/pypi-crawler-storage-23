from enum import Enum


class CsvDatasetConfigSourcetype(str, Enum):
    S3 = "s3"
    UPLOAD = "upload"
    URL = "url"

    def __str__(self) -> str:
        return str(self.value)
