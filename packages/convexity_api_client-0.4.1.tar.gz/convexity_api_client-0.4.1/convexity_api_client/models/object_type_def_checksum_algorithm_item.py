from enum import Enum


class ObjectTypeDefChecksumAlgorithmItem(str, Enum):
    CRC32 = "CRC32"
    CRC32C = "CRC32C"
    CRC64NVME = "CRC64NVME"
    SHA1 = "SHA1"
    SHA256 = "SHA256"

    def __str__(self) -> str:
        return str(self.value)
