from enum import Enum


class OutputType(str, Enum):
    DISPLAY_DATA = "display_data"
    ERROR = "error"
    EXECUTE_RESULT = "execute_result"
    STREAM = "stream"

    def __str__(self) -> str:
        return str(self.value)
