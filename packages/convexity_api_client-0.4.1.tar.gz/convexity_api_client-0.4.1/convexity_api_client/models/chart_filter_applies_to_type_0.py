from enum import Enum


class ChartFilterAppliesToType0(str, Enum):
    AGGREGATED_DATA = "aggregated_data"
    RAW_DATA = "raw_data"

    def __str__(self) -> str:
        return str(self.value)
