from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

T = TypeVar("T", bound="RestoreStatusTypeDef")


@_attrs_define
class RestoreStatusTypeDef:
    """
    Attributes:
        is_restore_in_progress (bool | Unset):
        restore_expiry_date (datetime.datetime | Unset):
    """

    is_restore_in_progress: bool | Unset = UNSET
    restore_expiry_date: datetime.datetime | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        is_restore_in_progress = self.is_restore_in_progress

        restore_expiry_date: str | Unset = UNSET
        if not isinstance(self.restore_expiry_date, Unset):
            restore_expiry_date = self.restore_expiry_date.isoformat()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if is_restore_in_progress is not UNSET:
            field_dict["IsRestoreInProgress"] = is_restore_in_progress
        if restore_expiry_date is not UNSET:
            field_dict["RestoreExpiryDate"] = restore_expiry_date

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        is_restore_in_progress = d.pop("IsRestoreInProgress", UNSET)

        _restore_expiry_date = d.pop("RestoreExpiryDate", UNSET)
        restore_expiry_date: datetime.datetime | Unset
        if isinstance(_restore_expiry_date, Unset):
            restore_expiry_date = UNSET
        else:
            restore_expiry_date = isoparse(_restore_expiry_date)

        restore_status_type_def = cls(
            is_restore_in_progress=is_restore_in_progress,
            restore_expiry_date=restore_expiry_date,
        )

        restore_status_type_def.additional_properties = d
        return restore_status_type_def

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
