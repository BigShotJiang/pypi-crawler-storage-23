from __future__ import annotations

from collections.abc import Mapping
from typing import Any, Literal, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.dashboard_text_widget_padding_type_0 import DashboardTextWidgetPaddingType0
from ..models.dashboard_text_widget_text_align_type_0 import DashboardTextWidgetTextAlignType0
from ..types import UNSET, Unset

T = TypeVar("T", bound="DashboardTextWidget")


@_attrs_define
class DashboardTextWidget:
    """Text widget definition for displaying static markdown content.

    Attributes:
        id (str): Unique widget identifier
        title (None | str | Unset): Widget title
        description (None | str | Unset): Widget description
        show_title (bool | None | Unset): Whether to display the widget title Default: True.
        show_description (bool | None | Unset): Whether to display the widget description Default: True.
        type_ (Literal['text'] | Unset):  Default: 'text'.
        content (None | str | Unset): Markdown content to display
        text_align (DashboardTextWidgetTextAlignType0 | None | Unset): Text alignment Default:
            DashboardTextWidgetTextAlignType0.LEFT.
        show_border (bool | None | Unset): Show widget border Default: True.
        background_color (None | str | Unset): Background color (CSS color value)
        padding (DashboardTextWidgetPaddingType0 | None | Unset): Content padding size Default:
            DashboardTextWidgetPaddingType0.MEDIUM.
    """

    id: str
    title: None | str | Unset = UNSET
    description: None | str | Unset = UNSET
    show_title: bool | None | Unset = True
    show_description: bool | None | Unset = True
    type_: Literal["text"] | Unset = "text"
    content: None | str | Unset = UNSET
    text_align: DashboardTextWidgetTextAlignType0 | None | Unset = DashboardTextWidgetTextAlignType0.LEFT
    show_border: bool | None | Unset = True
    background_color: None | str | Unset = UNSET
    padding: DashboardTextWidgetPaddingType0 | None | Unset = DashboardTextWidgetPaddingType0.MEDIUM
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        id = self.id

        title: None | str | Unset
        if isinstance(self.title, Unset):
            title = UNSET
        else:
            title = self.title

        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description

        show_title: bool | None | Unset
        if isinstance(self.show_title, Unset):
            show_title = UNSET
        else:
            show_title = self.show_title

        show_description: bool | None | Unset
        if isinstance(self.show_description, Unset):
            show_description = UNSET
        else:
            show_description = self.show_description

        type_ = self.type_

        content: None | str | Unset
        if isinstance(self.content, Unset):
            content = UNSET
        else:
            content = self.content

        text_align: None | str | Unset
        if isinstance(self.text_align, Unset):
            text_align = UNSET
        elif isinstance(self.text_align, DashboardTextWidgetTextAlignType0):
            text_align = self.text_align.value
        else:
            text_align = self.text_align

        show_border: bool | None | Unset
        if isinstance(self.show_border, Unset):
            show_border = UNSET
        else:
            show_border = self.show_border

        background_color: None | str | Unset
        if isinstance(self.background_color, Unset):
            background_color = UNSET
        else:
            background_color = self.background_color

        padding: None | str | Unset
        if isinstance(self.padding, Unset):
            padding = UNSET
        elif isinstance(self.padding, DashboardTextWidgetPaddingType0):
            padding = self.padding.value
        else:
            padding = self.padding

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "id": id,
            }
        )
        if title is not UNSET:
            field_dict["title"] = title
        if description is not UNSET:
            field_dict["description"] = description
        if show_title is not UNSET:
            field_dict["showTitle"] = show_title
        if show_description is not UNSET:
            field_dict["showDescription"] = show_description
        if type_ is not UNSET:
            field_dict["type"] = type_
        if content is not UNSET:
            field_dict["content"] = content
        if text_align is not UNSET:
            field_dict["textAlign"] = text_align
        if show_border is not UNSET:
            field_dict["showBorder"] = show_border
        if background_color is not UNSET:
            field_dict["backgroundColor"] = background_color
        if padding is not UNSET:
            field_dict["padding"] = padding

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        id = d.pop("id")

        def _parse_title(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        title = _parse_title(d.pop("title", UNSET))

        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        description = _parse_description(d.pop("description", UNSET))

        def _parse_show_title(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        show_title = _parse_show_title(d.pop("showTitle", UNSET))

        def _parse_show_description(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        show_description = _parse_show_description(d.pop("showDescription", UNSET))

        type_ = cast(Literal["text"] | Unset, d.pop("type", UNSET))
        if type_ != "text" and not isinstance(type_, Unset):
            raise ValueError(f"type must match const 'text', got '{type_}'")

        def _parse_content(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        content = _parse_content(d.pop("content", UNSET))

        def _parse_text_align(data: object) -> DashboardTextWidgetTextAlignType0 | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                text_align_type_0 = DashboardTextWidgetTextAlignType0(data)

                return text_align_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(DashboardTextWidgetTextAlignType0 | None | Unset, data)

        text_align = _parse_text_align(d.pop("textAlign", UNSET))

        def _parse_show_border(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        show_border = _parse_show_border(d.pop("showBorder", UNSET))

        def _parse_background_color(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        background_color = _parse_background_color(d.pop("backgroundColor", UNSET))

        def _parse_padding(data: object) -> DashboardTextWidgetPaddingType0 | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                padding_type_0 = DashboardTextWidgetPaddingType0(data)

                return padding_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(DashboardTextWidgetPaddingType0 | None | Unset, data)

        padding = _parse_padding(d.pop("padding", UNSET))

        dashboard_text_widget = cls(
            id=id,
            title=title,
            description=description,
            show_title=show_title,
            show_description=show_description,
            type_=type_,
            content=content,
            text_align=text_align,
            show_border=show_border,
            background_color=background_color,
            padding=padding,
        )

        dashboard_text_widget.additional_properties = d
        return dashboard_text_widget

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
