from enum import Enum


class VisualEncodingConfigColorby(str, Enum):
    GROUP = "group"
    METRIC = "metric"
    NONE = "none"

    def __str__(self) -> str:
        return str(self.value)
