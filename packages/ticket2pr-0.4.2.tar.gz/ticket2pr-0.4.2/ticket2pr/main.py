"""Main entry point for the ticket2pr CLI application."""

from ticket2pr.cli import app

if __name__ == "__main__":
    app()
