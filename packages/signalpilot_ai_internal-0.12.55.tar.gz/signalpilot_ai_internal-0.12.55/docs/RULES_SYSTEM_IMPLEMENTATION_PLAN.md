# SignalPilot Rules System — Implementation Plan

**Owner:** Tarik
**Status:** Draft
**Last Updated:** January 2025

---

## Overview

This document outlines the files that need to be created or modified to implement the three-mode rules system: **Always Apply**, **Apply Intelligently**, and **Apply Manually**.

---

## File Format (Cursor-style)

Rules will be stored as markdown files with YAML frontmatter:

```markdown
---
alwaysApply: true
description: This is a rule that enforces SQL naming conventions
---

Rule body content goes here...
```

**Frontmatter fields:**
- `alwaysApply`: `true` | `false` (default: `false`)
- `applyIntelligently`: `true` | `false` (default: `false`)
- `description`: Required string (< 50 words, used for hints)
- `id`: Auto-generated UUID
- `title`: Rule name
- `source`: `default` | `team` | `user`
- `created_at`: ISO timestamp
- `updated_at`: ISO timestamp

**Mode logic:**
- If `alwaysApply: true` → Always Apply mode
- If `applyIntelligently: true` → Apply Intelligently mode
- If both are `false` → Apply Manually mode (default)

---

## Token Budgets

| Category | Limit |
|----------|-------|
| Always-apply rules (total) | 2,000 tokens |
| Intelligent rule hints (total) | 300 tokens |
| Individual rule content | 1,000 tokens (soft limit, warn user) |
| Fetched rules per thread | 5 rules (IDs only stored in thread) |

---

## Files to Update

### 1. Data Model — `src/AppState.ts`

**Location:** Lines 30-37

**Current:**
```typescript
export interface ISnippet {
  id: string;
  title: string;
  description: string;
  content: string;
  createdAt: string;
  updatedAt: string;
}
```

**Update to:**
```typescript
export type RuleMode = 'always' | 'intelligent' | 'manual';
export type RuleSource = 'default' | 'team' | 'user';

export interface IRule {
  id: string;
  title: string;
  description: string;  // Required, < 50 words
  content: string;
  mode: RuleMode;
  source: RuleSource;
  filePath: string;     // Path reference for LLM
  createdAt: string;
  updatedAt: string;
  tokenCount?: number;  // Estimated token count
}

// Keep ISnippet as alias for backwards compatibility
export type ISnippet = IRule;
```

**Also update:**
- State interface (around line 98): rename `snippets` to `rules` or keep both
- Add `ruleSessionCache` to track fetched intelligent rules in current session

---

### 2. Backend Rules Manager — `signalpilot_ai_internal/signalpilot_home.py`

**Location:** Lines 635-960 (`UserRulesManager` class)

**Changes:**

#### a) Update `_parse_frontmatter()` (line 689)
Add parsing for new fields:
- `alwaysApply` (boolean)
- `applyIntelligently` (boolean)
- `source` (string)

#### b) Update `_format_frontmatter()` (line 717)
Add serialization for new fields in Cursor-style format.

#### c) Update `list_rules()` (line 737)
Return new fields in response:
```python
rules.append({
    'id': rule_id,
    'title': frontmatter.get('title', md_file.stem),
    'description': frontmatter.get('description', ''),
    'content': body,
    'mode': self._determine_mode(frontmatter),  # New
    'source': frontmatter.get('source', 'user'),  # New
    'file_path': str(md_file),  # New - full path for LLM reference
    'created_at': frontmatter.get('created_at', ''),
    'updated_at': frontmatter.get('updated_at', ''),
    'token_count': self._estimate_tokens(body),  # New
})
```

#### d) Add helper methods:
```python
def _determine_mode(self, frontmatter: Dict) -> str:
    """Determine rule mode from frontmatter."""
    if frontmatter.get('alwaysApply', False):
        return 'always'
    if frontmatter.get('applyIntelligently', False):
        return 'intelligent'
    return 'manual'

def _estimate_tokens(self, content: str) -> int:
    """Rough token estimate (4 chars = 1 token)."""
    return len(content) // 4
```

#### e) Update `create_rule()` and `update_rule()`
Accept `mode` parameter and translate to frontmatter fields.

---

### 3. Backend API Handler — `signalpilot_ai_internal/handlers.py`

**Location:** Lines 61-252 (`UserRulesHandler`)

**Changes:**

#### a) Add `get_rules` endpoint for batch fetching
New handler or update existing to support:
```
POST /signalpilot-ai-internal/rules/batch
Body: { "rule_ids": ["id1", "id2", "id3"] }
```

#### b) Update response format
Include `mode`, `source`, `file_path`, `token_count` in all rule responses.

---

### 4. Tool Definition — `src/Config/tools.json`

**Add new tool:**
```json
{
  "name": "rules-get_rules",
  "description": "Fetch the full content of specific rules by reading their markdown files. Use this when you need detailed context from rules marked as 'Apply Intelligently'. You can fetch 1-3 rules per call. The tool reads the .md files directly from the filesystem using the file paths provided in the hints.\n\nArgs:\n    rule_ids: Array of rule IDs to fetch (required, max 3)\n\nReturns:\n    str: Rule contents read from markdown files, or error if cache limit exceeded.",
  "input_schema": {
    "type": "object",
    "properties": {
      "rule_ids": {
        "type": "array",
        "items": { "type": "string" },
        "minItems": 1,
        "maxItems": 3,
        "title": "Rule IDs",
        "description": "IDs of rules to fetch (1-3 per call)"
      }
    },
    "required": ["rule_ids"],
    "title": "get_rulesArguments"
  }
}
```

**Note:** The tool implementation will use the `terminal-execute_command` tool internally to read the markdown files from disk. The file paths are provided in the intelligent rule hints.

---

### 5. Tool Service — `src/Services/ToolService.ts`

**Add handler for `rules-get_rules` tool:**

```typescript
case 'rules-get_rules':
  return this.handleGetRules(params.rule_ids);
```

**Implementation:**
```typescript
private async handleGetRules(ruleIds: string[]): Promise<string> {
  const rules = AppStateService.getSnippets();
  const chatHistoryManager = AppStateService.getChatHistoryManager();
  const results: string[] = [];
  const errors: string[] = [];

  for (const id of ruleIds.slice(0, 3)) { // Enforce max 3
    const rule = rules.find(r => r.id === id);
    if (!rule) {
      errors.push(`Rule not found: ${id}`);
      continue;
    }

    // Check if at limit (only for NEW rules, already-fetched don't count against limit)
    if (!chatHistoryManager.isRuleFetched(id) &&
        chatHistoryManager.getFetchedRuleCount() >= 5) {
      errors.push(`${id}: Skipped (session limit of 5 rules reached)`);
      continue;
    }

    // Read file content using terminal command
    const filePath = rule.filePath;
    try {
      const readResult = await this.executeTerminalCommand(
        `cat "${filePath}"`,
        `Reading rule file: ${rule.title}`
      );

      const content = this.stripFrontmatter(readResult);

      // Track that this rule was fetched (if not already)
      chatHistoryManager.addFetchedRuleId(id);

      results.push(`## ${rule.title}\n\nFile: ${filePath}\n\n${content}`);
    } catch (error) {
      errors.push(`${id}: Failed to read file`);
    }
  }

  let response = results.join('\n\n---\n\n');
  if (errors.length > 0) {
    response += `\n\nNotes:\n${errors.map(e => `- ${e}`).join('\n')}`;
  }

  response += `\n\nFetched rules in session: ${chatHistoryManager.getFetchedRuleCount()}/5`;

  return response;
}

private stripFrontmatter(content: string): string {
  if (!content.startsWith('---')) return content;
  const parts = content.split('---', 3);
  return parts.length >= 3 ? parts[2].trim() : content;
}
```

**Key points:**
- Uses `terminal-execute_command` to read the .md file from disk
- Only stores rule ID reference in thread, not content
- Re-reads file each time (content stays in .md files)
- Limit of 5 unique rules per thread
- Already-fetched rules can be re-read without counting against limit

---

### 6. Session Cache — Thread Metadata in `src/Chat/ChatHistoryManager.ts`

**Add to `IChatThread` interface (line 8-18):**

```typescript
export interface IChatThread {
  id: string;
  name: string;
  messages: IChatMessage[];
  lastUpdated: number;
  contexts: Map<string, IMentionContext>;
  message_timestamps: Map<string, number>;
  continueButtonShown?: boolean;
  needsContinue?: boolean;
  agent?: string;
  fetchedRuleIds?: string[];  // NEW - IDs of intelligent rules fetched in this thread
}
```

**Add helper functions to `ChatHistoryManager` class:**

```typescript
private readonly MAX_FETCHED_RULES = 5;

/**
 * Get fetched rule IDs for the current thread
 */
public getFetchedRuleIds(): string[] {
  const thread = this.getCurrentThread();
  return thread?.fetchedRuleIds || [];
}

/**
 * Check if a rule has been fetched in this thread
 */
public isRuleFetched(ruleId: string): boolean {
  return this.getFetchedRuleIds().includes(ruleId);
}

/**
 * Add a rule ID to the fetched list
 */
public addFetchedRuleId(ruleId: string): boolean {
  const thread = this.getCurrentThread();
  if (!thread) return false;

  if (!thread.fetchedRuleIds) {
    thread.fetchedRuleIds = [];
  }

  if (thread.fetchedRuleIds.length >= this.MAX_FETCHED_RULES) {
    return false; // At limit
  }

  if (!thread.fetchedRuleIds.includes(ruleId)) {
    thread.fetchedRuleIds.push(ruleId);
    this.saveCurrentThread();
  }
  return true;
}

/**
 * Get count of fetched rules
 */
public getFetchedRuleCount(): number {
  return this.getFetchedRuleIds().length;
}
```

**Note:** Only store rule IDs (references), not content:
- Content is read from .md files when needed
- Keeps thread metadata lightweight
- Each thread tracks its own fetched rules
- New threads start with empty list automatically

---

### 7. Prompt Injection — `src/Services/AnthropicMessageCreator.ts`

**Location:** Lines 318-336 (`prepareExtraSystemMessages`)

**Replace current snippet injection with:**

```typescript
// 1. Inject ALWAYS APPLY rules (full content)
const alwaysRules = rules.filter(r => r.mode === 'always');
if (alwaysRules.length > 0) {
  const alwaysContent = alwaysRules
    .map(r => `=== Rule: ${r.title} ===\n${r.content}\n=== End ${r.title} ===`)
    .join('\n\n');

  extraSystemMessages.push({
    type: 'text',
    text: `<rules_always_apply>\nThe following rules ALWAYS apply to this conversation:\n\n${alwaysContent}\n</rules_always_apply>`
  });
}

// 2. Inject INTELLIGENT rules as hints (id + description + file path)
const intelligentRules = rules.filter(r => r.mode === 'intelligent');
if (intelligentRules.length > 0) {
  const hints = intelligentRules
    .map(r => `- ${r.id}: ${r.description}\n  File: ${r.filePath}`)
    .join('\n');

  extraSystemMessages.push({
    type: 'text',
    text: `<rules_available>
You can fetch additional context using the rules-get_rules tool.
- Fetch 1-3 rules per call (max 3)
- Fetched rules persist in this conversation
- Session limit: 5 rules or 20K tokens
- The tool will read the markdown files from the paths listed below

Available rules:
${hints}
</rules_available>`
  });
}

// 3. Inject FETCHED rules (read from files based on stored IDs)
const chatHistoryManager = AppStateService.getChatHistoryManager();
const fetchedRuleIds = chatHistoryManager.getFetchedRuleIds();
if (fetchedRuleIds.length > 0) {
  const fetchedRules = rules.filter(r => fetchedRuleIds.includes(r.id));
  const fetchedContent = fetchedRules
    .map(r => `=== Fetched Rule: ${r.title} ===\n${r.content}\n=== End ===`)
    .join('\n\n');

  extraSystemMessages.push({
    type: 'text',
    text: `<rules_fetched>\nPreviously fetched rules in this session:\n\n${fetchedContent}\n</rules_fetched>`
  });
}

// 4. MANUAL rules only via @-mention (handled in ChatContextLoaders)
```

---

### 8. UI Types — `src/Components/SnippetCreationWidget/types.ts`

**Update interfaces:**

```typescript
import { IRule, RuleMode, RuleSource } from '../../AppState';

export interface ISnippetCreationState {
  isVisible: boolean;
  snippets: IRule[];  // Changed from ISnippet[]
  isCreating: boolean;
  editingSnippet: IRule | null;
  viewingSnippet: IRule | null;
  title: string;
  description: string;
  content: string;
  mode: RuleMode;      // New
  source: RuleSource;  // New
}

export interface ISnippetFormProps {
  title: string;
  description: string;
  content: string;
  mode: RuleMode;           // New
  isEditing: boolean;
  onSave: () => void;
  onClose: () => void;
  onTitleChange: (value: string) => void;
  onDescriptionChange: (value: string) => void;
  onContentChange: (value: string) => void;
  onModeChange: (mode: RuleMode) => void;  // New
  tokenBudget: TokenBudgetInfo;  // New - for UI display
}

// New interface for budget display
export interface TokenBudgetInfo {
  alwaysUsed: number;
  alwaysLimit: number;
  hintsUsed: number;
  hintsLimit: number;
  sessionUsed: number;
  sessionLimit: number;
  sessionRuleCount: number;
  sessionRuleLimit: number;
}
```

---

### 9. Form Modal — `src/Components/SnippetCreationWidget/SnippetFormModal.tsx`

**Add mode selector and budget display:**

```tsx
// Add mode selector after description field
<Form.Group className="mb-3">
  <Form.Label>Application Mode</Form.Label>
  <div className="sage-ai-rule-mode-selector">
    <button
      type="button"
      className={`sage-ai-mode-btn ${localMode === 'always' ? 'active' : ''}`}
      onClick={() => handleModeChange('always')}
    >
      <AlwaysIcon /> Always Apply
    </button>
    <button
      type="button"
      className={`sage-ai-mode-btn ${localMode === 'intelligent' ? 'active' : ''}`}
      onClick={() => handleModeChange('intelligent')}
    >
      <BrainIcon /> Apply Intelligently
    </button>
    <button
      type="button"
      className={`sage-ai-mode-btn ${localMode === 'manual' ? 'active' : ''}`}
      onClick={() => handleModeChange('manual')}
    >
      <PointerIcon /> Apply Manually
    </button>
  </div>
  <Form.Text className="text-muted">
    {localMode === 'always' && 'Rule will be included in every prompt'}
    {localMode === 'intelligent' && 'AI will fetch this rule when relevant'}
    {localMode === 'manual' && 'Only included when you @-mention it'}
  </Form.Text>
</Form.Group>

// Add budget info display
<div className="sage-ai-rule-budget-info">
  <div className="budget-item">
    <span>Always Apply Budget:</span>
    <span className={tokenBudget.alwaysUsed > tokenBudget.alwaysLimit * 0.8 ? 'warning' : ''}>
      {tokenBudget.alwaysUsed} / {tokenBudget.alwaysLimit} tokens
    </span>
  </div>
  <div className="budget-item">
    <span>Session Cache:</span>
    <span>
      {tokenBudget.sessionRuleCount} / {tokenBudget.sessionRuleLimit} rules,
      {tokenBudget.sessionUsed} / {tokenBudget.sessionLimit} tokens
    </span>
  </div>
</div>
```

---

### 10. Rule List — `src/Components/SnippetCreationWidget/SnippetList.tsx`

**Add mode icons and source badges:**

```tsx
// Import icons
import { BrainIcon, AlwaysIcon, PointerIcon } from './icons';

// In the render, add mode icon and source badge
<div className="sage-ai-snippet-item-header">
  <div className="sage-ai-snippet-title-container">
    {/* Mode icon */}
    <span className="sage-ai-rule-mode-icon">
      {snippet.mode === 'always' && <AlwaysIcon title="Always Apply" />}
      {snippet.mode === 'intelligent' && <BrainIcon title="Apply Intelligently" />}
      {snippet.mode === 'manual' && <PointerIcon title="Apply Manually" />}
    </span>

    <h5>{snippet.title}</h5>

    {/* Source badge */}
    <span className={`sage-ai-rule-source-badge ${snippet.source}`}>
      {snippet.source === 'user' ? 'User' : snippet.source === 'team' ? 'Team' : 'Default'}
    </span>

    {/* Existing checkmark for inserted */}
    {insertedSnippets?.includes(snippet.id) && (
      <svg className="sage-ai-snippet-checkmark">...</svg>
    )}
  </div>

  <div className="sage-ai-snippet-item-actions">
    {/* Edit button - always visible */}
    <button
      className="sage-ai-snippet-edit-btn-inline"
      onClick={e => handleEdit(e, snippet)}
      title="Edit rule"
    >
      <EditIcon />
    </button>

    {/* Existing menu button */}
    <button className="sage-ai-snippet-menu-btn">...</button>
  </div>
</div>
```

---

### 11. CSS Styles — `style/snippet-creation.css`

**Add new styles:**

```css
/* Mode selector */
.sage-ai-rule-mode-selector {
  display: flex;
  gap: 8px;
  flex-wrap: wrap;
}

.sage-ai-mode-btn {
  display: flex;
  align-items: center;
  gap: 6px;
  padding: 8px 12px;
  border: 1px solid var(--jp-border-color2);
  border-radius: 6px;
  background: var(--jp-layout-color1);
  color: var(--jp-ui-font-color1);
  cursor: pointer;
  transition: all 0.2s;
}

.sage-ai-mode-btn:hover {
  border-color: var(--jp-brand-color1);
}

.sage-ai-mode-btn.active {
  border-color: var(--jp-brand-color1);
  background: var(--jp-brand-color3);
  color: var(--jp-brand-color1);
}

/* Mode icons in list */
.sage-ai-rule-mode-icon {
  width: 16px;
  height: 16px;
  display: flex;
  align-items: center;
  justify-content: center;
  color: var(--jp-ui-font-color2);
}

.sage-ai-rule-mode-icon svg {
  width: 14px;
  height: 14px;
}

/* Source badges */
.sage-ai-rule-source-badge {
  font-size: 10px;
  padding: 2px 6px;
  border-radius: 4px;
  text-transform: uppercase;
  font-weight: 600;
}

.sage-ai-rule-source-badge.user {
  background: var(--jp-brand-color3);
  color: var(--jp-brand-color1);
}

.sage-ai-rule-source-badge.team {
  background: var(--jp-success-color3);
  color: var(--jp-success-color1);
}

.sage-ai-rule-source-badge.default {
  background: var(--jp-layout-color2);
  color: var(--jp-ui-font-color2);
}

/* Budget info */
.sage-ai-rule-budget-info {
  margin-top: 16px;
  padding: 12px;
  background: var(--jp-layout-color2);
  border-radius: 6px;
  font-size: 12px;
}

.sage-ai-rule-budget-info .budget-item {
  display: flex;
  justify-content: space-between;
  margin-bottom: 4px;
}

.sage-ai-rule-budget-info .budget-item:last-child {
  margin-bottom: 0;
}

.sage-ai-rule-budget-info .warning {
  color: var(--jp-warn-color1);
}

/* Inline edit button */
.sage-ai-snippet-edit-btn-inline {
  background: none;
  border: none;
  padding: 4px;
  cursor: pointer;
  color: var(--jp-ui-font-color2);
  opacity: 0;
  transition: opacity 0.2s;
}

.sage-ai-snippet-item:hover .sage-ai-snippet-edit-btn-inline {
  opacity: 1;
}

.sage-ai-snippet-edit-btn-inline:hover {
  color: var(--jp-brand-color1);
}
```

---

### 12. Icons — New file `src/Components/SnippetCreationWidget/icons.tsx`

**Create SVG icon components:**

```tsx
import * as React from 'react';

// Always Apply icon - Infinity symbol (∞)
export const AlwaysIcon: React.FC<{ title?: string }> = ({ title }) => (
  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" title={title}>
    <path d="M18.178 8c5.096 0 5.096 8 0 8-5.095 0-7.133-8-12.739-8-4.585 0-4.585 8 0 8 5.606 0 7.644-8 12.74-8z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
  </svg>
);

// Apply Intelligently icon - Brain (🧠)
export const BrainIcon: React.FC<{ title?: string }> = ({ title }) => (
  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" title={title}>
    <path d="M12 5a3 3 0 1 0-5.997.125 4 4 0 0 0-2.526 5.77 4 4 0 0 0 .556 6.588A4 4 0 1 0 12 18Z" stroke="currentColor" strokeWidth="2"/>
    <path d="M12 5a3 3 0 1 1 5.997.125 4 4 0 0 1 2.526 5.77 4 4 0 0 1-.556 6.588A4 4 0 1 1 12 18Z" stroke="currentColor" strokeWidth="2"/>
    <path d="M15 13a4.5 4.5 0 0 1-3-4 4.5 4.5 0 0 1-3 4" stroke="currentColor" strokeWidth="2"/>
  </svg>
);

// Apply Manually icon - Cursor pointer (👆)
export const PointerIcon: React.FC<{ title?: string }> = ({ title }) => (
  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" title={title}>
    <path d="M4 4l7.07 17 2.51-7.39L21 11.07 4 4z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
  </svg>
);

// Edit icon
export const EditIcon: React.FC = () => (
  <svg width="14" height="14" viewBox="0 0 24 24" fill="none">
    <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="m18.5 2.5 3 3L12 15l-4 1 1-4 9.5-9.5z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
  </svg>
);
```

---

### 13. Backend Caching Service — `src/utils/backendCaching.ts`

**Location:** Lines 444-581

**Update API methods:**

```typescript
// Update createRule to accept mode
public static async createRule(rule: {
  title: string;
  content: string;
  description?: string;
  mode?: RuleMode;  // New
  id?: string;
}): Promise<any | null>

// Update updateRule to accept mode
public static async updateRule(
  ruleId: string,
  updates: {
    title?: string;
    content?: string;
    description?: string;
    mode?: RuleMode;  // New
  }
): Promise<any | null>

// Add batch fetch method
public static async getRulesBatch(ruleIds: string[]): Promise<any[]> {
  try {
    const response = await BackendCacheService.makeRulesRequest(
      'rules/batch',
      'POST',
      { rule_ids: ruleIds }
    );
    return response.rules || [];
  } catch (error) {
    console.error('[BackendCacheService] Failed to batch get rules:', error);
    return [];
  }
}
```

---

### 14. Chat Context Loaders — `src/Chat/ChatContextMenu/ChatContextLoaders.ts`

**Location:** Lines 119-131

**Update `loadSnippets()` to filter by mode:**

```typescript
public async loadSnippets(): Promise<IMentionContext[]> {
  const rules = AppStateService.getSnippets();

  // Only return manual rules for @-mention
  // (always and intelligent are handled via system messages)
  return rules
    .filter(rule => rule.mode === 'manual')
    .map(rule => ({
      type: 'snippets' as const,
      id: rule.id,
      name: rule.title,
      description: rule.description.length > 100
        ? rule.description.substring(0, 100) + '...'
        : rule.description,
      content: rule.content
    }));
}
```

---

### 15. Thread Cache Behavior — Automatic via Thread Metadata

**No code changes needed for cache clearing.**

Since the cache is stored in `IChatThread.rulesSessionCache`:
- **New thread**: No `rulesSessionCache` field = empty cache (automatic)
- **Switch thread**: Each thread has its own cache (automatic)
- **Persist**: Cache saved when thread is saved to storage (automatic)

---

## Migration Strategy

1. **Backwards Compatibility:**
   - Existing rules without `alwaysApply`/`applyIntelligently` default to `manual` mode
   - Existing `insertedSnippets` behavior preserved for manual rules

2. **Migration Script:** (optional)
   - Read all existing rules
   - Add default `mode: 'manual'` to frontmatter
   - Preserve all other fields

---

## Implementation Order

### Phase 1: Core Data Model (Day 1)
1. Update `ISnippet` interface in `AppState.ts`
2. Update `UserRulesManager` in `signalpilot_home.py`
3. Update backend handlers

### Phase 2: Tool & Thread Cache (Day 1-2)
4. Add `get_rules` tool definition
5. Add `ICachedRule` and cache methods to `ChatHistoryManager.ts`
6. Implement tool handler in `ToolService`

### Phase 3: Prompt Injection (Day 2)
7. Update `AnthropicMessageCreator` for three-mode injection
8. Update `ChatContextLoaders` for @-mention filtering

### Phase 4: UI (Day 2-3)
9. Update types
10. Create icon components
11. Update `SnippetFormModal` with mode selector + budget
12. Update `SnippetList` with icons and badges
13. Add CSS styles

### Phase 5: Testing & Polish (Day 3)
14. Test all three modes
15. Test token budgets and limits
16. Test session cache behavior (per-thread persistence)

---

## File Summary

| File | Change Type | Priority |
|------|-------------|----------|
| `src/AppState.ts` | Modify | High |
| `signalpilot_ai_internal/signalpilot_home.py` | Modify | High |
| `signalpilot_ai_internal/handlers.py` | Modify | High |
| `src/Config/tools.json` | Modify | High |
| `src/Services/ToolService.ts` | Modify | High |
| `src/Chat/ChatHistoryManager.ts` | Modify | High |
| `src/Services/AnthropicMessageCreator.ts` | Modify | High |
| `src/Components/SnippetCreationWidget/types.ts` | Modify | Medium |
| `src/Components/SnippetCreationWidget/icons.tsx` | Create | Medium |
| `src/Components/SnippetCreationWidget/SnippetFormModal.tsx` | Modify | Medium |
| `src/Components/SnippetCreationWidget/SnippetList.tsx` | Modify | Medium |
| `src/Chat/ChatContextMenu/ChatContextLoaders.ts` | Modify | Medium |
| `src/utils/backendCaching.ts` | Modify | Medium |
| `style/snippet-creation.css` | Modify | Medium |

---

## Visual: UI Layout

### Rule List Item
```
┌─────────────────────────────────────────────────────────────────┐
│ ∞ SQL Style Guide                           [User]    [Edit] ⋯ │
│ 🧠 Metric Definitions                       [Team]    [Edit] ⋯ │
│ 👆 Executive Summary Template               [Default] [Edit] ⋯ │
└─────────────────────────────────────────────────────────────────┘

Legend:
∞  = Always Apply (infinity)
🧠 = Apply Intelligently (brain)
👆 = Apply Manually (pointer)
```

### Rule Form Modal
```
┌─────────────────────────────────────────────────────────────────┐
│  Create New Rule                                           [X] │
├─────────────────────────────────────────────────────────────────┤
│  Title: [________________________]                              │
│                                                                 │
│  Description: [________________________]                        │
│                                                                 │
│  Application Mode:                                              │
│  ┌──────────────┐ ┌──────────────────┐ ┌───────────────┐       │
│  │ ∞  Always   │ │ 🧠 Intelligently │ │ 👆 Manually   │       │
│  │    Apply    │ │    Apply         │ │    Apply      │       │
│  └──────────────┘ └──────────────────┘ └───────────────┘       │
│  Rule will be included in every prompt                          │
│                                                                 │
│  Content:                                                       │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │ # SQL Style Guide                                        │   │
│  │                                                          │   │
│  │ - Use lowercase for SQL keywords...                      │   │
│  │                                                          │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                 │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │ Budget Info:                                             │   │
│  │ Always Apply:   1,234 / 2,000 tokens                     │   │
│  │ Session Cache:  2/5 rules, 8,000/20,000 tokens           │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                 │
│                                      [Cancel]  [Save]           │
└─────────────────────────────────────────────────────────────────┘
```

---

## Visual: File Path Flow

```
1. STORAGE: Rule saved as markdown file
   ~/SignalPilotHome/user-rules/sql-style.md
   ─────────────────────────────────────────
   ---
   alwaysApply: false
   applyIntelligently: true
   description: SQL formatting conventions
   id: sql-style
   title: SQL Style Guide
   ---
   # SQL Style Guide
   Use lowercase for SQL keywords...


2. BACKEND: UserRulesManager reads file, returns metadata + file_path
   {
     id: "sql-style",
     title: "SQL Style Guide",
     description: "SQL formatting conventions",
     mode: "intelligent",
     file_path: "/Users/me/SignalPilotHome/user-rules/sql-style.md",
     ...
   }


3. PROMPT: AnthropicMessageCreator injects hints with file path
   <rules_available>
   Available rules:
   - sql-style: SQL formatting conventions
     File: /Users/me/SignalPilotHome/user-rules/sql-style.md
   </rules_available>


4. TOOL CALL: LLM calls get_rules with rule_id
   rules-get_rules({ rule_ids: ["sql-style"] })


5. TOOL HANDLER: Reads .md file using terminal command
   → cat "/Users/me/SignalPilotHome/user-rules/sql-style.md"
   → Strip frontmatter, return content
   → Add rule ID to thread's fetchedRuleIds


6. THREAD METADATA: Only stores rule ID references
   {
     id: "thread-123",
     name: "SQL Investigation",
     messages: [...],
     fetchedRuleIds: ["sql-style", "metric-definitions"]  // Just IDs
   }


7. RESPONSE: Full rule content returned to LLM
   ## SQL Style Guide
   File: /Users/me/SignalPilotHome/user-rules/sql-style.md

   # SQL Style Guide
   Use lowercase for SQL keywords...
```

---

## Key Design Decisions

1. **Cursor-style frontmatter**: Uses `alwaysApply: true` instead of `mode: always` for familiarity with Cursor users

2. **File path in hints**: LLM gets the actual file path so it understands where rules come from and can reference them

3. **Terminal command for reading**: Uses existing `terminal-execute_command` infrastructure instead of creating new API endpoints

4. **Store references, not content**: Thread only stores `fetchedRuleIds: string[]`, content read from .md files when needed

5. **5 rule limit per thread**: Simple count limit, no token tracking (content lives in files)

6. **Thread-based tracking**: Fetched rule IDs stored in `IChatThread.fetchedRuleIds`:
   - Each conversation tracks its own fetched rules
   - Switching threads preserves each thread's state
   - New threads start with empty list automatically
   - Lightweight metadata (just IDs)
