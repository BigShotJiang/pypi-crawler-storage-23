import * as React from 'react';
import { ISnippetListProps } from './types';
import { ISnippet, RuleMode, RuleCategory } from '../../stores';

// Subcategory labels for default rules (nested under "Defaults")
const DEFAULT_SUBCATEGORY_CONFIG: Record<
  Exclude<RuleCategory, 'user'>,
  { label: string; order: number }
> = {
  core: { label: 'Core', order: 0 },
  database: { label: 'Database Integrations', order: 1 },
  mcp: { label: 'App Integrations', order: 2 }
};

// Chevron icon for collapsible sections
const ChevronIcon = ({ expanded }: { expanded: boolean }) => (
  <svg
    width="12"
    height="12"
    viewBox="0 0 24 24"
    fill="none"
    style={{
      transform: expanded ? 'rotate(90deg)' : 'rotate(0deg)',
      transition: 'transform 0.2s ease'
    }}
  >
    <path
      d="M9 18l6-6-6-6"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
  </svg>
);

// Toggle switch component for activate/deactivate
const ToggleSwitch = ({
  active,
  onToggle
}: {
  active: boolean;
  onToggle: (e: React.MouseEvent) => void;
}) => (
  <div
    className={`sage-ai-toggle-switch ${active ? 'active' : ''}`}
    onClick={onToggle}
    title={active ? 'Deactivate' : 'Activate'}
  />
);

// Edit icon component
const EditIcon = ({ onClick }: { onClick: (e: React.MouseEvent) => void }) => (
  <button
    className="sage-ai-snippet-action-icon-btn"
    onClick={onClick}
    title="Edit rule"
  >
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none">
      <path
        d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="m18.5 2.5 3 3L12 15l-4 1 1-4 9.5-9.5z"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  </button>
);

// Delete icon component
const DeleteIcon = ({ onClick }: { onClick: (e: React.MouseEvent) => void }) => (
  <button
    className="sage-ai-snippet-action-icon-btn sage-ai-snippet-delete-icon"
    onClick={onClick}
    title="Delete rule"
  >
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none">
      <path
        d="M3 6h18M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2m3 0v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6h14z"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  </button>
);

// Duplicate icon component
const DuplicateIcon = ({ onClick }: { onClick: (e: React.MouseEvent) => void }) => (
  <button
    className="sage-ai-snippet-action-icon-btn"
    onClick={onClick}
    title="Duplicate rule"
  >
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none">
      <rect x="9" y="9" width="13" height="13" rx="2" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
      <path
        d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  </button>
);

// Mode icons
const getModeIcon = (mode: RuleMode) => {
  const icons: Record<RuleMode, JSX.Element> = {
    always: (
      <svg width="10" height="10" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M13 10V3L4 14h7v7l9-11h-7z" />
      </svg>
    ),
    intelligent: (
      <svg width="10" height="10" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" />
      </svg>
    ),
    manual: (
      <svg width="10" height="10" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M15 15l-2 5L9 9l11 4-5 2zm0 0l5 5" />
      </svg>
    )
  };
  return icons[mode];
};

// Mode badge component with icon and tooltip
const ModeBadge = ({ mode }: { mode: RuleMode }) => {
  const config: Record<RuleMode, { label: string; tooltip: string }> = {
    always: { label: 'Always', tooltip: 'Injected in every request' },
    intelligent: { label: 'Auto', tooltip: 'AI decides when relevant' },
    manual: { label: 'Manual', tooltip: 'Only when added to context' }
  };

  return (
    <span className={`sage-ai-rule-mode-badge ${mode}`}>
      {getModeIcon(mode)}
      <span className="sage-ai-mode-tooltip">{config[mode].tooltip}</span>
    </span>
  );
};

// Badge for user rules that override a default
const OverridesBadge = () => (
  <span className="sage-ai-rule-overrides-badge">OVERRIDES</span>
);

/**
 * Component for displaying the list of snippets grouped by category
 */
export function SnippetList({
  snippets,
  onView,
  onDelete,
  onDuplicate,
  onCreateNew,
  onToggleActive
}: ISnippetListProps): JSX.Element {
  const [selectedSnippet, setSelectedSnippet] = React.useState<ISnippet | null>(
    null
  );
  const [openMenuId, setOpenMenuId] = React.useState<string | null>(null);

  // Collapsed state for main sections and subcategories
  // Only Core and User Rules are expanded by default
  const [defaultsCollapsed, setDefaultsCollapsed] = React.useState(false);
  const [userCollapsed, setUserCollapsed] = React.useState(false);
  const [subcategoryCollapsed, setSubcategoryCollapsed] = React.useState<
    Record<Exclude<RuleCategory, 'user'>, boolean>
  >({
    core: false,      // Core expanded by default
    database: true,   // Database collapsed by default
    mcp: true         // MCP collapsed by default
  });

  // Group snippets by category
  const groupedSnippets = React.useMemo(() => {
    const groups: Record<RuleCategory, ISnippet[]> = {
      core: [],
      database: [],
      mcp: [],
      user: []
    };

    snippets.forEach(s => {
      if (s.isDefault) {
        const category = s.category || 'core';
        groups[category].push(s);
      } else {
        groups.user.push(s);
      }
    });

    return groups;
  }, [snippets]);

  // Track which user rules override deactivated defaults
  const overriddenDefaultFilenames = React.useMemo(() => {
    const deactivatedDefaults = snippets.filter(s => s.isDefault && s.deactivated);
    return new Set(deactivatedDefaults.map(s => s.filename));
  }, [snippets]);

  // Update selectedSnippet when snippets change (to reflect updates)
  React.useEffect(() => {
    if (selectedSnippet) {
      const updatedSnippet = snippets.find(
        snippet => snippet.filename === selectedSnippet.filename
      );
      if (
        updatedSnippet &&
        (updatedSnippet.title !== selectedSnippet.title ||
          updatedSnippet.content !== selectedSnippet.content ||
          updatedSnippet.description !== selectedSnippet.description)
      ) {
        setSelectedSnippet(updatedSnippet);
      } else if (!updatedSnippet) {
        // Snippet was deleted
        setSelectedSnippet(null);
      }
    }
  }, [snippets, selectedSnippet]);

  // Close context menu when clicking outside
  React.useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      const target = event.target as Element;
      if (
        !target.closest('.sage-ai-snippet-context-menu') &&
        !target.closest('.sage-ai-snippet-menu-btn')
      ) {
        setOpenMenuId(null);
      }
    };

    document.addEventListener('click', handleClickOutside);
    return () => {
      document.removeEventListener('click', handleClickOutside);
    };
  }, []);

  const toggleSubcategory = (category: Exclude<RuleCategory, 'user'>) => {
    setSubcategoryCollapsed(prev => ({
      ...prev,
      [category]: !prev[category]
    }));
  };

  const handleSnippetClick = (snippet: ISnippet) => {
    const isSameSnippet =
      selectedSnippet?.filename === snippet.filename &&
      selectedSnippet?.isDefault === snippet.isDefault;
    setSelectedSnippet(isSameSnippet ? null : snippet);
  };

  // Create a unique ID for menu state (filename + isDefault to distinguish overrides)
  const getMenuId = (snippet: ISnippet) =>
    `${snippet.filename}-${snippet.isDefault ? 'default' : 'user'}`;

  const handleContextMenu = (e: React.MouseEvent, snippet: ISnippet) => {
    e.stopPropagation();
    const menuId = getMenuId(snippet);
    setOpenMenuId(openMenuId === menuId ? null : menuId);
  };

  const handleEdit = (e: React.MouseEvent, snippet: ISnippet) => {
    e.stopPropagation();
    setOpenMenuId(null);
    onView(snippet); // This will trigger edit mode in the parent
  };

  const handleDelete = (e: React.MouseEvent, snippetFilename: string) => {
    e.stopPropagation();
    setOpenMenuId(null);
    onDelete(snippetFilename);
  };

  const handleToggleActive = (e: React.MouseEvent, snippet: ISnippet) => {
    e.stopPropagation();
    setOpenMenuId(null);
    onToggleActive(snippet.filename, !snippet.active);
  };

  const handleDuplicate = (e: React.MouseEvent, snippet: ISnippet) => {
    e.stopPropagation();
    onDuplicate(snippet);
  };

  const renderSnippetItem = (snippet: ISnippet) => {
    const isSelected =
      selectedSnippet !== null && selectedSnippet.filename === snippet.filename && selectedSnippet.isDefault === snippet.isDefault;
    const isInactive = !snippet.active;
    const isDeactivated = snippet.deactivated;
    // Check if this user rule overrides a default
    const overridesDefault = !snippet.isDefault && overriddenDefaultFilenames.has(snippet.filename);
    const menuId = getMenuId(snippet);

    return (
      <div key={menuId} className="sage-ai-snippet-item-container">
        <div
          className={`sage-ai-snippet-item ${isSelected ? 'selected' : ''} ${isInactive ? 'inactive' : ''} ${isDeactivated ? 'deactivated' : ''}`}
          onClick={() => handleSnippetClick(snippet)}
        >
          <div className="sage-ai-snippet-item-content">
            <div className="sage-ai-snippet-item-info">
              <div className="sage-ai-snippet-item-header">
                <h5>{snippet.title}</h5>
                <div className="sage-ai-snippet-badges">
                  {overridesDefault && <OverridesBadge />}
                  <ModeBadge mode={snippet.mode || 'manual'} />
                </div>
              </div>
              {snippet.description && (
                <p className="sage-ai-snippet-item-description">{snippet.description}</p>
              )}
            </div>
            <div className="sage-ai-snippet-item-actions">
              <div className="sage-ai-snippet-hover-actions">
                {/* Order: Toggle >> Delete >> Duplicate >> Edit */}
                <ToggleSwitch
                  active={snippet.active}
                  onToggle={e => handleToggleActive(e, snippet)}
                />
                {!snippet.isDefault && (
                  <>
                    <DeleteIcon onClick={e => handleDelete(e, snippet.filename)} />
                    <DuplicateIcon onClick={e => handleDuplicate(e, snippet)} />
                  </>
                )}
                <EditIcon onClick={e => handleEdit(e, snippet)} />
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  };

  // Render a subcategory within Defaults
  const renderSubcategory = (category: Exclude<RuleCategory, 'user'>) => {
    const rules = groupedSnippets[category];
    if (rules.length === 0) return null;

    const config = DEFAULT_SUBCATEGORY_CONFIG[category];
    const isCollapsed = subcategoryCollapsed[category];

    return (
      <div key={category} className="sage-ai-rule-subcategory">
        <button
          className="sage-ai-subcategory-header"
          onClick={() => toggleSubcategory(category)}
        >
          <ChevronIcon expanded={!isCollapsed} />
          <span className="sage-ai-subcategory-label">{config.label}</span>
          <span className="sage-ai-category-count">{rules.length}</span>
        </button>
        {!isCollapsed && (
          <div className="sage-ai-subcategory-rules">
            {rules.map(rule => renderSnippetItem(rule))}
          </div>
        )}
      </div>
    );
  };

  // Get sorted subcategories for defaults
  const sortedSubcategories = (
    Object.keys(DEFAULT_SUBCATEGORY_CONFIG) as Exclude<RuleCategory, 'user'>[]
  ).sort(
    (a, b) => DEFAULT_SUBCATEGORY_CONFIG[a].order - DEFAULT_SUBCATEGORY_CONFIG[b].order
  );

  // Check if there are any default rules
  const hasDefaultRules =
    groupedSnippets.core.length > 0 ||
    groupedSnippets.database.length > 0 ||
    groupedSnippets.mcp.length > 0;

  // Count total default rules
  const totalDefaultRules =
    groupedSnippets.core.length +
    groupedSnippets.database.length +
    groupedSnippets.mcp.length;

  const hasAnySnippets = snippets.length > 0;
  const hasUserRules = groupedSnippets.user.length > 0;

  return (
    <div className="sage-ai-snippet-list">
      <div className="sage-ai-snippet-list-container">
        {!hasAnySnippets ? (
          <div className="sage-ai-snippet-empty">
            <p>No rules created yet.</p>
            <p>Click the + button to create your first rule.</p>
          </div>
        ) : (
          <div className="sage-ai-snippet-categories">
            {/* Defaults section with nested subcategories */}
            {hasDefaultRules && (
              <div className="sage-ai-rule-category">
                <button
                  className="sage-ai-category-header"
                  onClick={() => setDefaultsCollapsed(!defaultsCollapsed)}
                >
                  <ChevronIcon expanded={!defaultsCollapsed} />
                  <span className="sage-ai-category-label">Defaults</span>
                  <span className="sage-ai-category-count">{totalDefaultRules}</span>
                </button>
                {!defaultsCollapsed && (
                  <div className="sage-ai-category-rules">
                    {sortedSubcategories.map(category => renderSubcategory(category))}
                  </div>
                )}
              </div>
            )}

            {/* My Rules section */}
            {hasUserRules && (
              <div className="sage-ai-rule-category">
                <button
                  className="sage-ai-category-header"
                  onClick={() => setUserCollapsed(!userCollapsed)}
                >
                  <ChevronIcon expanded={!userCollapsed} />
                  <span className="sage-ai-category-label">My Rules</span>
                  <span className="sage-ai-category-count">{groupedSnippets.user.length}</span>
                </button>
                {!userCollapsed && (
                  <div className="sage-ai-category-rules">
                    {groupedSnippets.user.map(rule => renderSnippetItem(rule))}
                  </div>
                )}
              </div>
            )}
          </div>
        )}
      </div>

      {selectedSnippet && (
        <div className="sage-ai-snippet-viewer-inline">
          {/* First Row: Rule Preview | Mode Badge | Edit Icon | Close Icon */}
          <div className="sage-ai-snippet-viewer-toolbar">
            <div className="sage-ai-snippet-preview-header">
              <span className="sage-ai-snippet-preview-label">
                Rule Preview
              </span>
              {!selectedSnippet.isDefault && overriddenDefaultFilenames.has(selectedSnippet.filename) && <OverridesBadge />}
              <ModeBadge mode={selectedSnippet.mode || 'manual'} />
            </div>
            <div className="sage-ai-snippet-viewer-actions">
              <button
                className="sage-ai-snippet-edit-btn"
                onClick={e => handleEdit(e, selectedSnippet)}
                title="Edit rule"
              >
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
                  <path
                    d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                  <path
                    d="m18.5 2.5 3 3L12 15l-4 1 1-4 9.5-9.5z"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                </svg>
              </button>
              <button
                className="sage-ai-snippet-close-btn"
                onClick={() => setSelectedSnippet(null)}
                title="Close preview"
              >
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
                  <path
                    d="M18 6L6 18M6 6l12 12"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                </svg>
              </button>
            </div>
          </div>

          {/* Second Row: Title */}
          <div className="sage-ai-snippet-viewer-title-row">
            <span className="sage-ai-snippet-title-label">Title:</span>
            <span className="sage-ai-snippet-title-text">
              {selectedSnippet.title}
            </span>
          </div>

          {selectedSnippet.description && (
            <p className={'sage-ai-snippet-description'}>
              {selectedSnippet.description}
            </p>
          )}

          {/* Third Row: Snippet Content */}
          <div className="sage-ai-snippet-code-block">
            <pre className="sage-ai-snippet-code-content">
              <code>{selectedSnippet.content}</code>
            </pre>
          </div>
        </div>
      )}
    </div>
  );
}
