/**
 * ModeDropdown - Unified mode selector with auto-run toggle
 *
 * Combines Executive Mode and Auto Run into a single dropdown:
 * - MODE section: Audit Mode / Executive Mode
 * - EXECUTION section: Auto Run toggle
 *
 * Mode switching logic:
 * - Executive Mode: sets autoRun=true (user can still toggle off)
 * - Audit Mode: sets autoRun=false
 */

import * as React from 'react';
// @ts-ignore - createPortal types may not be available in all environments
import { createPortal } from 'react-dom';
import { useState, useRef, useEffect, useCallback } from 'react';
import { useSettingsStore } from '@/stores/settingsStore';

// ═══════════════════════════════════════════════════════════════
// COLORS
// ═══════════════════════════════════════════════════════════════

const COLORS = {
  audit: '#39FF14',
  auditMuted: '#2ed610',
  executive: '#C4B5FD',
  autoRun: '#39FF14'
};

// ═══════════════════════════════════════════════════════════════
// SVG ICONS
// ═══════════════════════════════════════════════════════════════

const ChevronIcon = ({ open }: { open: boolean }) => (
  <svg
    width="12"
    height="12"
    viewBox="0 0 12 12"
    fill="none"
    style={{
      transition: 'transform 0.2s ease',
      transform: open ? 'rotate(180deg)' : 'rotate(0deg)'
    }}
  >
    <path
      d="M3 4.5L6 7.5L9 4.5"
      stroke="currentColor"
      strokeWidth="1.5"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
  </svg>
);

const AuditIcon = ({ active }: { active?: boolean }) => {
  const c = active ? COLORS.audit : '#64648a';
  const c2 = active ? COLORS.auditMuted : '#4a4a6a';
  return (
    <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
      <rect x="2" y="3" width="14" height="12" rx="2" stroke={c} strokeWidth="1.5" fill="none" />
      <line x1="5" y1="7" x2="13" y2="7" stroke={c} strokeWidth="1.2" strokeLinecap="round" />
      <line x1="5" y1="10" x2="10" y2="10" stroke={c2} strokeWidth="1.2" strokeLinecap="round" />
    </svg>
  );
};

const ExecutiveIcon = ({ active }: { active?: boolean }) => {
  const c = active ? COLORS.executive : '#64648a';
  return (
    <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
      <path
        d="M9 2L11.5 7H15L12 10.5L13.5 16L9 12.5L4.5 16L6 10.5L3 7H6.5L9 2Z"
        stroke={c}
        strokeWidth="1.4"
        strokeLinejoin="round"
        fill={active ? 'rgba(196,181,253,0.15)' : 'none'}
      />
    </svg>
  );
};

const BoltIcon = () => (
  <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
    <path
      d="M7.5 1.5L3 8H7L6.5 12.5L11 6H7L7.5 1.5Z"
      stroke={COLORS.audit}
      strokeWidth="1.2"
      strokeLinejoin="round"
      fill="rgba(57,255,20,0.12)"
    />
  </svg>
);

const CheckIcon = ({ color }: { color?: string }) => (
  <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
    <path
      d="M3.5 7.5L5.5 9.5L10.5 4.5"
      stroke={color || 'currentColor'}
      strokeWidth="1.5"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
  </svg>
);

// ═══════════════════════════════════════════════════════════════
// TOGGLE COMPONENT
// ═══════════════════════════════════════════════════════════════

interface ToggleProps {
  checked: boolean;
  onChange: (value: boolean) => void;
}

const Toggle = ({ checked, onChange }: ToggleProps) => (
  <button
    className="sage-mode-dropdown-toggle"
    onClick={() => onChange(!checked)}
    data-checked={checked}
    type="button"
    aria-checked={checked}
    role="switch"
  >
    <div className="sage-mode-dropdown-toggle-knob" />
  </button>
);

// ═══════════════════════════════════════════════════════════════
// MODE CONFIG
// ═══════════════════════════════════════════════════════════════

type ModeKey = 'audit' | 'executive';

interface ModeConfig {
  key: ModeKey;
  label: string;
  desc: string;
  icon: JSX.Element;
  color: string;
}

const MODES: ModeConfig[] = [
  {
    key: 'audit',
    label: 'Audit Mode',
    desc: 'Full code visibility & manual control',
    icon: <AuditIcon />,
    color: COLORS.audit
  },
  {
    key: 'executive',
    label: 'Executive Mode',
    desc: 'Streamlined — less code, auto-run on',
    icon: <ExecutiveIcon />,
    color: COLORS.executive
  }
];

// ═══════════════════════════════════════════════════════════════
// COMPONENT
// ═══════════════════════════════════════════════════════════════

export function ModeDropdown(): JSX.Element {
  const [open, setOpen] = useState(false);
  const triggerRef = useRef<HTMLButtonElement>(null);
  const panelRef = useRef<HTMLDivElement>(null);
  const [panelPos, setPanelPos] = useState({ top: 0, left: 0 });

  // Store state (all persisted in settingsStore via localStorage)
  const autoRun = useSettingsStore(state => state.autoRun);
  const setAutoRun = useSettingsStore(state => state.setAutoRun);
  const executiveMode = useSettingsStore(state => state.executiveMode);
  const setExecutiveMode = useSettingsStore(state => state.setExecutiveMode);

  const currentMode: ModeKey = executiveMode ? 'executive' : 'audit';
  const currentConfig = MODES.find(m => m.key === currentMode)!;

  // Calculate panel position from trigger button rect
  const updatePosition = useCallback(() => {
    if (!triggerRef.current) return;
    const rect = triggerRef.current.getBoundingClientRect();
    const panelWidth = 280;
    let left = rect.right - panelWidth;
    if (left < 8) left = 8;
    setPanelPos({ top: rect.bottom + 6, left });
  }, []);

  // Close dropdown on Escape
  useEffect(() => {
    if (!open) return;

    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setOpen(false);
    };

    document.addEventListener('keydown', handleEscape);
    return () => {
      document.removeEventListener('keydown', handleEscape);
    };
  }, [open]);

  // Update position when opened or on scroll/resize
  useEffect(() => {
    if (!open) return;
    updatePosition();

    window.addEventListener('resize', updatePosition);
    window.addEventListener('scroll', updatePosition, true);
    return () => {
      window.removeEventListener('resize', updatePosition);
      window.removeEventListener('scroll', updatePosition, true);
    };
  }, [open, updatePosition]);

  const handleToggle = useCallback(() => {
    setOpen(prev => !prev);
  }, []);

  const handleModeChange = useCallback(
    (modeKey: ModeKey) => {
      if (modeKey === 'executive') {
        setExecutiveMode(true);
        setAutoRun(true);
      } else {
        setExecutiveMode(false);
        setAutoRun(false);
      }
    },
    [setExecutiveMode, setAutoRun]
  );

  const handleAutoRunChange = useCallback(
    (value: boolean) => {
      setAutoRun(value);
    },
    [setAutoRun]
  );

  const panelContent = open
    ? createPortal(
        <>
          {/* Invisible backdrop to catch all outside clicks */}
          <div
            style={{
              position: 'fixed',
              inset: 0,
              zIndex: 9999
            }}
            onClick={() => setOpen(false)}
          />
          <div
            ref={panelRef}
            className="sage-mode-dropdown-panel"
            style={{
              position: 'fixed',
              top: panelPos.top,
              left: panelPos.left,
              zIndex: 10000
            }}
          >
          {/* Mode Section Header */}
          <div className="sage-mode-dropdown-section-header">Mode</div>

          {/* Mode Options */}
          {MODES.map(m => {
            const active = currentMode === m.key;
            return (
              <button
                key={m.key}
                className="sage-mode-dropdown-item"
                onClick={() => handleModeChange(m.key)}
                data-active={active}
                style={
                  {
                    '--mode-color': m.color
                  } as React.CSSProperties
                }
                type="button"
              >
                <span
                  className="sage-mode-dropdown-item-icon"
                  style={{
                    background: active
                      ? `${m.color}18`
                      : 'rgba(255,255,255,0.04)',
                    border: `0.5px solid ${active ? `${m.color}30` : 'rgba(255,255,255,0.08)'}`,
                    borderRadius: '8px',
                    width: '32px',
                    height: '32px',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    flexShrink: 0
                  }}
                >
                  {m.key === 'executive' ? (
                    <ExecutiveIcon active={active} />
                  ) : (
                    <AuditIcon active={active} />
                  )}
                </span>
                <div className="sage-mode-dropdown-item-content">
                  <div className="sage-mode-dropdown-item-label">{m.label}</div>
                  <div className="sage-mode-dropdown-item-desc">{m.desc}</div>
                </div>
                {active && (
                  <span className="sage-mode-dropdown-item-check">
                    <CheckIcon color={m.color} />
                  </span>
                )}
              </button>
            );
          })}

          {/* Divider */}
          <div className="sage-mode-dropdown-divider" />

          {/* Execution Section Header */}
          <div className="sage-mode-dropdown-section-header">Execution</div>

          {/* Auto Run Toggle */}
          <div className="sage-mode-dropdown-autorun">
            <span
              className="sage-mode-dropdown-autorun-icon"
              style={{
                background: autoRun
                  ? `${COLORS.autoRun}18`
                  : 'rgba(255,255,255,0.04)',
                border: `0.5px solid ${autoRun ? `${COLORS.autoRun}30` : 'rgba(255,255,255,0.08)'}`,
                color: autoRun ? COLORS.autoRun : undefined,
                borderRadius: '8px',
                width: '32px',
                height: '32px',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                flexShrink: 0
              }}
            >
              <BoltIcon />
            </span>
            <div className="sage-mode-dropdown-autorun-content">
              <div className="sage-mode-dropdown-autorun-label">Auto Run</div>
              <div className="sage-mode-dropdown-autorun-desc">
                Auto-approve code generations
              </div>
            </div>
            <Toggle checked={autoRun} onChange={handleAutoRunChange} />
          </div>
          </div>
        </>,
        document.body
      )
    : null;

  return (
    <div className="sage-mode-dropdown" data-mode={currentMode}>
      {/* Trigger Button */}
      <button
        ref={triggerRef}
        className="sage-mode-dropdown-trigger"
        onClick={handleToggle}
        type="button"
        data-open={open}
        style={{ color: currentConfig.color }}
      >
        {/* Colorful dot indicator */}
        <span
          className="sage-mode-dropdown-trigger-dot"
          style={{ background: currentConfig.color }}
        />
        {currentConfig.label}
        <ChevronIcon open={open} />
      </button>

      {/* Dropdown Panel - portaled to document.body */}
      {panelContent}
    </div>
  );
}
