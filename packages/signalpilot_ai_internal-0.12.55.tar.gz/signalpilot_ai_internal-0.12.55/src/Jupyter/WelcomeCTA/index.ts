export { registerAddCtaDivCommand } from './welcomeCTAMount';
