"""Databricks connection test handler.

Schema and query handlers are in sqlalchemy/handlers.py (unified handler).
"""

import json
import logging
import time
import warnings
from typing import Any, Dict

import tornado.web

# Suppress Databricks connector warnings
warnings.filterwarnings("ignore", message=".*pyarrow is not installed.*")
warnings.filterwarnings("ignore", message=".*_user_agent_entry.*deprecated.*")
logging.getLogger("databricks.sql.client").setLevel(logging.ERROR)
logging.getLogger("databricks.sql.session").setLevel(logging.ERROR)
from jupyter_server.base.handlers import APIHandler

from signalpilot_ai_internal.schema_service.base.package_manager import PackageManager
from signalpilot_ai_internal.db_config.databricks.auth import DatabricksTokenProvider


def _get_connection_params(config: Dict) -> Dict[str, Any]:
    """Build Databricks native connector parameters from configuration."""
    server_hostname = config.get("connectionUrl") or config.get("host", "")
    if not server_hostname:
        raise ValueError("connectionUrl (hostname) is required for Databricks")

    http_path = config.get("warehouseHttpPath") or config.get("httpPath")
    if not http_path:
        raise ValueError("warehouseHttpPath is required for Databricks")

    access_token = DatabricksTokenProvider.get_token(config)

    conn_params = {
        "server_hostname": server_hostname,
        "http_path": http_path,
        "access_token": access_token,
    }

    if config.get("catalog"):
        conn_params["catalog"] = config["catalog"]
    if config.get("schema"):
        conn_params["schema"] = config["schema"]

    return conn_params


def _get_databricks_sql():
    """Get Databricks SQL module."""
    PackageManager.ensure_installed("databricks")
    from databricks import sql as databricks_sql
    return databricks_sql


class DatabricksTestHandler(APIHandler):
    """Handler for testing Databricks connection."""

    @tornado.web.authenticated
    def post(self):
        """Test Databricks connection and return status."""
        try:
            try:
                body = json.loads(self.request.body.decode("utf-8"))
            except json.JSONDecodeError:
                body = {}

            config = body.get("config")
            if not config:
                self.set_status(400)
                self.finish(json.dumps({"error": "No configuration provided"}))
                return

            try:
                databricks_sql = _get_databricks_sql()
            except ImportError as e:
                self.set_status(500)
                self.finish(json.dumps({"ok": False, "error": str(e)}))
                return

            try:
                start_time = time.time()

                conn_params = _get_connection_params(config)
                connection = databricks_sql.connect(**conn_params)
                cursor = connection.cursor()

                try:
                    cursor.execute("SELECT 1 as test")
                    cursor.fetchall()

                    sql_latency = int((time.time() - start_time) * 1000)

                    identity_info = {"type": "unknown", "name": "unknown"}
                    try:
                        cursor.execute("SELECT current_user() as user")
                        user_row = cursor.fetchone()
                        if user_row:
                            auth_type = config.get("authType", "pat")
                            identity_info = {
                                "type": "user" if auth_type == "pat" else "service_principal",
                                "name": user_row[0],
                            }
                    except Exception:
                        pass

                    self.finish(json.dumps({
                        "ok": True,
                        "identity": identity_info,
                        "sql": {"ok": True, "latency_ms": sql_latency},
                        "api": {"ok": True},
                    }))

                finally:
                    cursor.close()
                    connection.close()

            except Exception as e:
                error_msg = str(e)
                self.finish(json.dumps({
                    "ok": False,
                    "error": error_msg,
                    "identity": None,
                    "sql": {"ok": False, "error": error_msg},
                    "api": {"ok": False},
                }))

        except Exception as e:
            self.set_status(500)
            self.finish(json.dumps({
                "ok": False,
                "error": "Internal server error",
                "message": str(e),
            }))
