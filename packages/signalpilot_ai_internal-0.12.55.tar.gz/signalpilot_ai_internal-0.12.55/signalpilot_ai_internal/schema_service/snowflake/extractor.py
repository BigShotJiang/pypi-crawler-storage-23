"""Snowflake schema extraction with parallel processing."""

import sys
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Any, Dict, List, Optional

from signalpilot_ai_internal.log_utils import print


class SnowflakeSchemaExtractor:
    """Extract schema from Snowflake with parallel processing."""

    def __init__(self, connector, connection):
        self._connector = connector
        self._conn = connection

    def list_databases(self, cursor) -> List[str]:
        """List all databases."""
        cursor.execute("SHOW DATABASES")
        cursor.execute('SELECT "name" FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))')
        rows = cursor.fetchall()
        if rows and isinstance(rows[0], dict):
            return [r["name"] for r in rows]
        return [r[0] for r in rows]

    def list_schemas(self, cursor, database: str) -> List[str]:
        """List all schemas for a database (excluding INFORMATION_SCHEMA)."""
        cursor.execute(f'USE DATABASE "{database}"')
        cursor.execute("SHOW SCHEMAS")
        cursor.execute('SELECT "name" FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))')
        rows = cursor.fetchall()
        if rows and isinstance(rows[0], dict):
            schemas = [r["name"] for r in rows]
        else:
            schemas = [r[0] for r in rows]
        return [s for s in schemas if s.upper() != "INFORMATION_SCHEMA"]

    def list_tables_with_columns(
        self,
        database: str,
        schema: str,
        limit: int = 5000,
    ) -> List[Dict]:
        """Get tables and columns for a schema using bulk query."""
        cursor = self._conn.cursor(self._connector.DictCursor)
        try:
            cursor.execute(f'USE DATABASE "{database}"')
            cursor.execute(f'USE SCHEMA "{schema}"')

            cursor.execute("""
                SELECT
                    t.TABLE_SCHEMA,
                    t.TABLE_NAME,
                    t.TABLE_TYPE,
                    c.COLUMN_NAME,
                    c.DATA_TYPE,
                    c.ORDINAL_POSITION,
                    c.IS_NULLABLE,
                    c.COLUMN_DEFAULT,
                    c.CHARACTER_MAXIMUM_LENGTH,
                    c.NUMERIC_PRECISION,
                    c.NUMERIC_SCALE,
                    c.COMMENT
                FROM INFORMATION_SCHEMA.TABLES t
                LEFT JOIN INFORMATION_SCHEMA.COLUMNS c
                    ON t.TABLE_SCHEMA = c.TABLE_SCHEMA
                    AND t.TABLE_NAME = c.TABLE_NAME
                WHERE t.TABLE_SCHEMA = %s
                ORDER BY t.TABLE_NAME, c.ORDINAL_POSITION
                LIMIT 50000
            """, (schema,))
            rows = cursor.fetchall()

            # Group by table
            tables_dict = {}
            for r in rows:
                if isinstance(r, dict):
                    table_key = r["TABLE_NAME"]
                    if table_key not in tables_dict:
                        tables_dict[table_key] = {
                            "schema": r["TABLE_SCHEMA"],
                            "table": r["TABLE_NAME"],
                            "type": r["TABLE_TYPE"],
                            "columns": [],
                        }

                    if r.get("COLUMN_NAME"):
                        col = {
                            "name": r["COLUMN_NAME"],
                            "type": r["DATA_TYPE"],
                            "ordinal": r["ORDINAL_POSITION"],
                            "nullable": r["IS_NULLABLE"] == "YES",
                        }
                        if r.get("COMMENT"):
                            col["description"] = r["COMMENT"]
                        if r.get("COLUMN_DEFAULT"):
                            col["default"] = r["COLUMN_DEFAULT"]
                        if r.get("CHARACTER_MAXIMUM_LENGTH"):
                            col["max_length"] = r["CHARACTER_MAXIMUM_LENGTH"]
                        if r.get("NUMERIC_PRECISION"):
                            col["precision"] = r["NUMERIC_PRECISION"]
                        if r.get("NUMERIC_SCALE") is not None:
                            col["scale"] = r["NUMERIC_SCALE"]
                        tables_dict[table_key]["columns"].append(col)

            return list(tables_dict.values())[:limit]
        finally:
            cursor.close()

    def _process_schema(self, database: str, schema: str) -> Dict:
        """Process a single schema with its tables and columns."""
        try:
            tables = self.list_tables_with_columns(database, schema)
            return {"schema": schema, "tables": tables, "error": None}
        except Exception as e:
            print(f"Warning: Error processing schema {database}.{schema}: {e}", file=sys.stderr)
            return {"schema": schema, "tables": [], "error": str(e)}

    def build_catalog(
        self,
        warehouse: str,
        databases: Optional[List[str]] = None,
        max_workers: int = 5,
    ) -> Dict[str, Any]:
        """Build complete catalog with parallel schema processing."""
        cursor = self._conn.cursor(self._connector.DictCursor)
        try:
            cursor.execute(f'USE WAREHOUSE "{warehouse}"')

            if databases is None:
                databases = self.list_databases(cursor)

            cursor.close()

            catalog = []
            print(f"Processing {len(databases)} databases...", file=sys.stderr)

            for db in databases:
                print(f"  Processing database: {db}", file=sys.stderr)
                cursor = self._conn.cursor(self._connector.DictCursor)
                try:
                    schemas = self.list_schemas(cursor, db)
                    print(f"    Found {len(schemas)} schemas", file=sys.stderr)
                finally:
                    cursor.close()

                # Process schemas in parallel
                schema_objs = []
                with ThreadPoolExecutor(max_workers=max_workers) as executor:
                    future_to_schema = {
                        executor.submit(self._process_schema, db, s): s
                        for s in schemas
                    }

                    for future in as_completed(future_to_schema):
                        schema_name = future_to_schema[future]
                        try:
                            result = future.result()
                            schema_objs.append(result)
                            print(
                                f"      Completed schema: {schema_name} ({len(result['tables'])} tables)",
                                file=sys.stderr,
                            )
                        except Exception as e:
                            print(f"      Error with schema {schema_name}: {e}", file=sys.stderr)
                            schema_objs.append({"schema": schema_name, "tables": [], "error": str(e)})

                catalog.append({"database": db, "schemas": schema_objs})

            return {"warehouse": warehouse, "databases": catalog}
        finally:
            if not cursor.is_closed():
                cursor.close()
