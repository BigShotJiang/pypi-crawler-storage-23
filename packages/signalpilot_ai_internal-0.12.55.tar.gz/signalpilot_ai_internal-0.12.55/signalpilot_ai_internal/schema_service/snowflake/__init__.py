"""Snowflake schema service handlers."""
