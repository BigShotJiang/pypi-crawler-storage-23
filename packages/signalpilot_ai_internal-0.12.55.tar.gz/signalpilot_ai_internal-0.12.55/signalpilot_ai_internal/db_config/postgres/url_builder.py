"""PostgreSQL URL builder."""

from signalpilot_ai_internal.db_config.base.url_builder import StandardURLBuilder


class PostgresURLBuilder(StandardURLBuilder):
    """Builds PostgreSQL SQLAlchemy connection URLs."""

    DRIVER = "postgresql"
    DEFAULT_PORT = "5432"
