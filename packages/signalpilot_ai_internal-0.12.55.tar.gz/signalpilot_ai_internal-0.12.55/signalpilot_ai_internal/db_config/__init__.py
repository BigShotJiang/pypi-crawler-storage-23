"""Database configuration module."""
