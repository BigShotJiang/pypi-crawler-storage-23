"""Snowflake URL builder and private key authentication."""

import os
from typing import Any, Dict, Optional

from signalpilot_ai_internal.db_config.base.url_builder import BaseURLBuilder


class SnowflakeURLBuilder(BaseURLBuilder):
    """Builds Snowflake SQLAlchemy connection URLs.

    Note: private_key_path is NOT included in the URL because Snowflake's
    SQLAlchemy dialect doesn't support it. Use get_connect_args() to get
    the private key bytes for passing to create_engine().
    """

    def build(self, config: Dict[str, Any]) -> str:
        """Build Snowflake connection URL.

        Format: snowflake://{user}@{account}/{database}?warehouse={warehouse}
        """
        account = self._get_required(config, "account")
        username = self._get_required(config, "username")
        database = self._get_optional(config, "database")
        warehouse = self._get_optional(config, "warehouse")

        url = f"snowflake://{username}@{account}/{database or ''}"

        if warehouse:
            url += f"?warehouse={warehouse}"

        return url


def load_private_key_bytes(key_path: str) -> bytes:
    """Load and convert PEM private key to DER bytes for Snowflake connector."""
    from cryptography.hazmat.backends import default_backend
    from cryptography.hazmat.primitives import serialization

    expanded_path = os.path.expanduser(key_path)
    with open(expanded_path, "rb") as key_file:
        private_key = serialization.load_pem_private_key(
            key_file.read(),
            password=None,
            backend=default_backend()
        )

    return private_key.private_bytes(
        encoding=serialization.Encoding.DER,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption()
    )


def get_snowflake_connect_args(config: Dict[str, Any]) -> Dict[str, Any]:
    """Get connect_args for Snowflake SQLAlchemy engine.

    Returns dict with private_key bytes if privateKeyPath is provided.
    """
    connect_args: Dict[str, Any] = {}

    private_key_path = config.get("privateKeyPath")
    if private_key_path:
        connect_args["private_key"] = load_private_key_bytes(private_key_path)

    return connect_args
