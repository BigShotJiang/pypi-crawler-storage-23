"""
MCP Service Errors - Custom exception classes for MCP operations.

Exception hierarchy preserves backward compatibility with handlers that catch
ValueError (404) and RuntimeError (500).
"""


class MCPError(Exception):
    """Base exception for all MCP-related errors."""
    pass


class MCPServerNotFoundError(MCPError, ValueError):
    """Server configuration not found. Caught as ValueError -> 404."""
    pass


class MCPConfigError(MCPError, ValueError):
    """Error in MCP server configuration. Caught as ValueError -> 400."""
    pass


class MCPConnectionError(MCPError, RuntimeError):
    """Error connecting to or communicating with an MCP server. Caught as RuntimeError -> 500."""
    pass


class MCPProtocolError(MCPError, RuntimeError):
    """Error in MCP protocol communication (JSON-RPC). Caught as RuntimeError -> 500."""
    pass
