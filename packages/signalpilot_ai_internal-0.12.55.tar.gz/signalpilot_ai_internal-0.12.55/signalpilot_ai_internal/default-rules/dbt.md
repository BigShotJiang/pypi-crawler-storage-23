---
title: dbt Integration
description: dbt (data build tool) integration via MCP for querying metrics, getting compiled SQL, and discovering models. Use when the user needs to understand data models, metrics definitions, or generate queries based on dbt semantic layer.
when_to_apply: Auto
alwaysApply: false
applyIntelligently: true
updated_at: "2026-01-27T16:36:16Z"
default: true
category: mcp
version: "1.0.0"
active: true
---

# dbt Integration

You are an expert at working with dbt (data build tool) projects. You help users explore models, understand metrics, and generate correct SQL queries.

## Connection Requirements

This skill requires the dbt MCP server to be connected.

**If tools are unavailable:**
1. Inform user: "The dbt integration is not connected. Please configure the dbt MCP server in your SignalPilot settings."
2. Do NOT attempt to simulate dbt functionality or guess at metrics/models
3. Suggest alternatives: "You can query the underlying tables directly if you know the table names, or check your dbt documentation for metric definitions."

## dbt Concepts

### Models
SQL transformations that define how raw data becomes analytics-ready tables.

```
raw_data -> staging_models -> intermediate_models -> mart_models
```

### Metrics
Business-defined calculations with consistent semantics:
- Revenue
- Customer count
- Conversion rate

### Semantic Layer
dbt's abstraction that lets you query metrics without writing SQL.

## Available MCP Tools

When the dbt MCP server is connected, you have access to:

| Tool | Purpose |
|------|---------|
| `query_metrics` | Query dbt metrics |
| `get_metrics_compiled_sql` | Get SQL for a metric query |
| `get_all_models` | List all models in project |
| `get_model_details` | Get details of specific model |
| `get_all_metrics` | List all defined metrics |
| `get_metric_details` | Get details of specific metric |

## Discovering Models

### List All Models
Use `get_all_models`:

```json
{}
```

Returns all models with:
- Model name
- Model type (source, staging, intermediate, mart)
- Description
- Tags

### Get Model Details
Use `get_model_details`:

```json
{
  "model_name": "fct_orders"
}
```

Returns:
- Column definitions
- Description
- Relationships
- Upstream dependencies
- Downstream dependencies

## Working with Metrics

### List All Metrics
Use `get_all_metrics`:

```json
{}
```

Returns all metrics with:
- Metric name
- Calculation type
- Time grains supported
- Dimensions available

### Get Metric Details
Use `get_metric_details`:

```json
{
  "metric_name": "revenue"
}
```

Returns:
- Full definition
- Expression/formula
- Available dimensions
- Filters
- Time grains

## Querying Metrics

### Basic Metric Query
Use `query_metrics`:

```json
{
  "metrics": ["revenue"],
  "group_by": ["order_date__month"],
  "limit": 100
}
```

### Multiple Metrics
```json
{
  "metrics": ["revenue", "order_count"],
  "group_by": ["customer_segment"],
  "limit": 100
}
```

### With Filters
```json
{
  "metrics": ["revenue"],
  "group_by": ["product_category"],
  "where": [
    {"column": "region", "operator": "=", "value": "US"},
    {"column": "order_date", "operator": ">=", "value": "2024-01-01"}
  ],
  "limit": 100
}
```

### Time Grain Options
```json
{
  "metrics": ["revenue"],
  "group_by": ["order_date__day"],
  "limit": 365
}
```

Time grains: `__day`, `__week`, `__month`, `__quarter`, `__year`

## Getting Compiled SQL

### Get SQL for Metric
Use `get_metrics_compiled_sql`:

```json
{
  "metrics": ["revenue", "order_count"],
  "group_by": ["customer_segment", "order_date__month"],
  "where": [
    {"column": "region", "operator": "=", "value": "US"}
  ]
}
```

Returns the actual SQL that would be executed, useful for:
- Understanding metric implementation
- Custom modifications
- Debugging
- Learning SQL patterns

## Common Workflows

### Explore Available Data
1. List all models: `get_all_models`
2. Identify relevant mart models
3. Get model details: `get_model_details`
4. Understand columns and relationships

### Build a Report
1. List available metrics: `get_all_metrics`
2. Identify relevant metrics for report
3. Query metrics with dimensions: `query_metrics`
4. Format results for presentation

### Understand Metric Definition
1. Get metric details: `get_metric_details`
2. Get compiled SQL: `get_metrics_compiled_sql`
3. Explain calculation to user
4. Suggest appropriate usage

### Compare Metrics
1. Query multiple metrics together
2. Use consistent grouping
3. Present comparison table/chart

## dbt Project Structure

Understanding typical project layout helps find things:

```
dbt_project/
+-- models/
|   +-- staging/           # Clean raw data
|   |   +-- stg_orders.sql
|   |   +-- stg_customers.sql
|   +-- intermediate/      # Business logic
|   |   +-- int_customer_orders.sql
|   +-- marts/            # Final tables
|       +-- dim_customers.sql
|       +-- fct_orders.sql
+-- metrics/
|   +-- revenue.yml        # Metric definitions
+-- seeds/
    +-- static_data.csv    # Static reference data
```

### Model Naming Conventions

| Prefix | Layer | Purpose |
|--------|-------|---------|
| `stg_` | Staging | Clean, typed raw data |
| `int_` | Intermediate | Business logic, joins |
| `dim_` | Marts | Dimension tables |
| `fct_` | Marts | Fact tables |

## Metric Types

### Simple Metrics
Single aggregation on a column:
```yaml
- name: total_revenue
  type: simple
  type_params:
    measure: revenue
```

### Derived Metrics
Calculation from other metrics:
```yaml
- name: average_order_value
  type: derived
  type_params:
    expr: total_revenue / order_count
```

### Ratio Metrics
One metric divided by another:
```yaml
- name: conversion_rate
  type: ratio
  type_params:
    numerator: converted_users
    denominator: total_users
```

### Cumulative Metrics
Running totals over time:
```yaml
- name: cumulative_revenue
  type: cumulative
  type_params:
    measure: revenue
    window: all_time
```

## Response Formatting

When presenting dbt content:

```markdown
## Metric: revenue

**Definition**: Sum of order amounts for completed orders

**Calculation**:
```sql
SUM(order_amount) WHERE order_status = 'completed'
```

**Available Dimensions**:
- customer_segment
- product_category
- region
- order_date (day/week/month/quarter/year)

**Usage Example**:
```python
# Monthly revenue by segment
results = query_metrics(
    metrics=["revenue"],
    group_by=["customer_segment", "order_date__month"]
)
```
```

## Error Handling

### Common Issues

**"Metric not found"**
- Check exact metric name
- Metric may not be defined in project
- Case sensitivity matters

**"Invalid dimension"**
- Dimension not available for this metric
- Check `get_metric_details` for valid dimensions

**"Incompatible time grain"**
- Metric may not support requested grain
- Check supported time grains

**"Query timeout"**
- Reduce date range
- Reduce number of dimensions
- Add filters to limit data

## Integration with Notebooks

### Load Metric Results into pandas
```python
import pandas as pd

# Assuming query_metrics returns JSON
results = query_metrics(...)
df = pd.DataFrame(results)
```

### Generate and Execute SQL
```python
# Get compiled SQL
sql = get_metrics_compiled_sql(...)

# Execute against data warehouse
# (using appropriate connector)
df = pd.read_sql(sql, connection)
```

## Best Practices

1. **Use metrics over raw SQL** - Metrics ensure consistent definitions
2. **Check available dimensions** - Not all dimensions work with all metrics
3. **Mind time grains** - Use appropriate granularity for analysis
4. **Understand lineage** - Know where data comes from
5. **Document findings** - Reference metric definitions in notebooks

## Limitations

- Metrics must be pre-defined in dbt project
- Query performance depends on underlying warehouse
- Not all dimension combinations may be valid
- Time-based metrics require proper date handling
- Semantic layer must be configured in dbt project