---
title: Snowflake Connector
description: Snowflake Data Cloud connection and querying skill. Use when the user needs to connect to Snowflake, explore schemas, or query data from Snowflake databases.
when_to_apply: Auto
alwaysApply: false
applyIntelligently: true
updated_at: "2026-01-27T16:36:51Z"
default: true
category: database
version: "1.0.0"
active: true
---

# Snowflake Connector

Expert guidance for working with Snowflake Data Cloud.

## Critical Safety Rules

### Destructive Operations - ALWAYS WARN

Before generating ANY of these operations, you MUST warn the user about potential data loss:

- `DROP TABLE`, `DROP DATABASE`, `DROP SCHEMA`
- `DELETE` (especially without WHERE clause)
- `TRUNCATE TABLE`
- `ALTER TABLE` (structure changes)
- `UPDATE` without WHERE clause

When user requests destructive operations:
1. **Warn clearly**: "This operation will permanently delete/modify data and cannot be undone."
2. **Suggest safer alternatives**: soft deletes, CLONE backups, WHERE clause additions, Time Travel for recovery
3. **Show exactly what will be affected**: row counts, table names
4. **Never execute DELETE/UPDATE without WHERE** unless user explicitly confirms

Note: Snowflake's Time Travel can recover data for a limited period (default 1 day), but don't rely on this - always warn first.

### Query Safety - LIMIT Enforcement

For exploratory or ad-hoc SELECT queries:

1. **Always apply LIMIT** (default 1000) unless user explicitly requests all rows
2. **Warn about large result sets**: "This query may return many rows. Adding LIMIT 1000."
3. **Consider SAMPLE** for very large tables: `SELECT * FROM table SAMPLE (1000 ROWS)`

Never generate unbounded `SELECT *` on tables without knowing their size.

### Data Privacy

Be cautious with columns that may contain PII:
- `email`, `phone`, `ssn`, `address`, `name`, `first_name`, `last_name`
- Columns containing `personal`, `private`, `secret`, `password`, `token`

Note: Snowflake supports Dynamic Data Masking policies - check if sensitive columns have masking applied.

## Package

```python
# Install package (use your environment's package manager):
# - If using uv: !uv pip install snowflake-connector-python
# - Otherwise: !pip install snowflake-connector-python
```

## Connection Setup

### Using Environment Variables
```python
import os
import snowflake.connector

conn = snowflake.connector.connect(
    user=os.environ['MYDB_USERNAME'],
    password=os.environ['MYDB_PASSWORD'],
    account=os.environ['MYDB_ACCOUNT'],
    warehouse=os.environ.get('MYDB_WAREHOUSE'),
    database=os.environ['MYDB_DATABASE'],
    role=os.environ.get('MYDB_ROLE')
)
```

### Using Context Managers (Recommended)
```python
import snowflake.connector

with snowflake.connector.connect(
    user='USERNAME',
    password='PASSWORD',
    account='ACCOUNT_IDENTIFIER',
    warehouse='WAREHOUSE_NAME',
    database='DATABASE_NAME'
) as conn:
    with conn.cursor() as cursor:
        cursor.execute("SELECT * FROM table_name")
        results = cursor.fetchall()
```

### Using with pandas
```python
import pandas as pd
import snowflake.connector
from snowflake.connector.pandas_tools import write_pandas

conn = snowflake.connector.connect(
    user='USERNAME',
    password='PASSWORD',
    account='ACCOUNT_IDENTIFIER',
    warehouse='WAREHOUSE_NAME',
    database='DATABASE_NAME'
)

# Read into DataFrame
df = pd.read_sql("SELECT * FROM table_name", conn)

# Write DataFrame to Snowflake
success, nchunks, nrows, _ = write_pandas(conn, df, 'TABLE_NAME')
conn.close()
```

### Dict Cursor (returns dicts instead of tuples)
```python
import snowflake.connector
from snowflake.connector import DictCursor

conn = snowflake.connector.connect(...)

cursor = conn.cursor(DictCursor)
cursor.execute("SELECT * FROM users")
rows = cursor.fetchall()  # List of dicts
```

## Namespace

Snowflake uses a 3-level namespace: `DATABASE.SCHEMA.OBJECT`

```sql
-- Fully qualified reference
SELECT * FROM my_database.my_schema.my_table;

-- With current context set
USE DATABASE my_database;
USE SCHEMA my_schema;
SELECT * FROM my_table;
```

## Case Sensitivity

```sql
-- Unquoted identifiers are converted to UPPERCASE
SELECT * FROM MyTable;  -- Looks for MYTABLE

-- Use double quotes for case-sensitive identifiers
SELECT * FROM "MyTable";  -- Looks for MyTable exactly
```

## Schema Discovery

```sql
-- List all databases
SHOW DATABASES;

-- List schemas in a database
SHOW SCHEMAS IN DATABASE database_name;

-- List tables in a schema
SHOW TABLES IN SCHEMA database_name.schema_name;

-- List views
SHOW VIEWS IN SCHEMA database_name.schema_name;

-- Get table structure
DESCRIBE TABLE database_name.schema_name.table_name;

-- Checking Current Context
SELECT
    CURRENT_DATABASE() as current_database,
    CURRENT_SCHEMA() as current_schema,
    CURRENT_WAREHOUSE() as current_warehouse,
    CURRENT_ROLE() as current_role,
    CURRENT_USER() as current_user;
```

## Query Patterns

### Date/Time Functions

```sql
-- Current timestamp
SELECT CURRENT_TIMESTAMP();
SELECT CURRENT_DATE();

-- Date arithmetic
SELECT DATEADD(day, 7, CURRENT_DATE());
SELECT DATEADD(month, -1, CURRENT_DATE());
SELECT DATEDIFF(day, '2024-01-01', CURRENT_DATE());

-- Date truncation
SELECT DATE_TRUNC('month', date_column) as month_start;

-- Parsing strings to dates
SELECT TO_DATE('2024-01-15', 'YYYY-MM-DD');
SELECT TO_TIMESTAMP('2024-01-15 10:30:00', 'YYYY-MM-DD HH24:MI:SS');

-- Extract parts
SELECT YEAR(date_column), MONTH(date_column), DAY(date_column);
SELECT DAYOFWEEK(date_column);  -- 0=Sunday, 6=Saturday
```

### Semi-Structured Data (JSON/VARIANT)

```sql
-- Access JSON fields
SELECT raw_json:field_name::string as field_value
FROM table_with_json;

-- Nested access
SELECT raw_json:nested.field::number as nested_value
FROM table_with_json;

-- Array access
SELECT raw_json:array[0]::string as first_element
FROM table_with_json;

-- Flatten arrays (unnest)
SELECT f.value::string as array_element
FROM table_with_json,
LATERAL FLATTEN(input => raw_json:array_field) f;

-- Parse JSON string
SELECT PARSE_JSON('{"key": "value"}'):key::string;

-- Build JSON
SELECT OBJECT_CONSTRUCT('id', id, 'name', name) as json_record
FROM users;
```

### Window Functions

```sql
-- Row number
SELECT
    *,
    ROW_NUMBER() OVER (PARTITION BY category ORDER BY amount DESC) as rank
FROM products;

-- Running total
SELECT
    date,
    amount,
    SUM(amount) OVER (ORDER BY date) as running_total
FROM transactions;

-- Moving average
SELECT
    date,
    amount,
    AVG(amount) OVER (
        ORDER BY date
        ROWS BETWEEN 6 PRECEDING AND CURRENT ROW
    ) as seven_day_avg
FROM daily_metrics;
```

### Merge (Upsert)

```sql
MERGE INTO target_table t
USING source_table s
ON t.id = s.id
WHEN MATCHED THEN
    UPDATE SET
        t.column1 = s.column1,
        t.updated_at = CURRENT_TIMESTAMP()
WHEN NOT MATCHED THEN
    INSERT (id, column1, created_at)
    VALUES (s.id, s.column1, CURRENT_TIMESTAMP());
```

### Sampling Data

```sql
-- Random sample (approximate percentage)
SELECT * FROM large_table SAMPLE (10);  -- ~10% of rows

-- Fixed number of rows
SELECT * FROM large_table SAMPLE (1000 ROWS);

-- Bernoulli sampling (row-level)
SELECT * FROM large_table SAMPLE BERNOULLI (10);
```

## Time Travel

```sql
-- Query data as of a specific time
SELECT * FROM my_table AT(TIMESTAMP => '2024-01-01 00:00:00'::timestamp);

-- Query data as of N seconds ago
SELECT * FROM my_table AT(OFFSET => -3600);  -- 1 hour ago

-- Query data before a specific statement
SELECT * FROM my_table BEFORE(STATEMENT => 'statement-id');

-- Undrop a table
UNDROP TABLE dropped_table_name;
```

## Performance

### Query Profiling
```sql
-- Disable result cache for testing
ALTER SESSION SET USE_CACHED_RESULT = FALSE;

-- View query stats
SELECT * FROM TABLE(GET_QUERY_OPERATOR_STATS(LAST_QUERY_ID()));

-- Query history
SELECT * FROM TABLE(INFORMATION_SCHEMA.QUERY_HISTORY())
WHERE QUERY_TEXT ILIKE '%my_table%'
ORDER BY START_TIME DESC
LIMIT 10;
```

### Clustering
```sql
-- Check table clustering info
SELECT SYSTEM$CLUSTERING_INFORMATION('database.schema.table', '(column1, column2)');

-- Add clustering key
ALTER TABLE my_table CLUSTER BY (date_column, category_column);

-- Re-cluster manually (usually automatic)
ALTER TABLE my_table RECLUSTER;
```

### Best Practices
1. **Use appropriate warehouse size** - Start small (XS), scale up if needed
2. **Filter early** - Apply WHERE clauses before joins
3. **Select only needed columns** - Avoid `SELECT *`
4. **Use clustering keys** - For large tables with common filter patterns
5. **Leverage caching** - Same queries hit result cache
6. **Use LIMIT during development** - Avoid scanning entire tables

## Common Errors

| Error | Cause | Solution |
|-------|-------|----------|
| Object does not exist | Wrong name or case sensitivity | Use double quotes for mixed-case |
| Warehouse is suspended | Auto-suspended | Will auto-resume, or `ALTER WAREHOUSE name RESUME` |
| Insufficient privileges | Missing role grants | Contact admin for grants |
| Authentication failed | Wrong credentials | Verify username, password, account |

## Key Rules

1. Use double quotes for case-sensitive identifiers
2. Snowflake uses 3-level namespace: `DATABASE.SCHEMA.TABLE`
3. Unquoted identifiers are converted to UPPERCASE
4. Use LIMIT during development to avoid full table scans
5. Leverage Time Travel for debugging and recovery