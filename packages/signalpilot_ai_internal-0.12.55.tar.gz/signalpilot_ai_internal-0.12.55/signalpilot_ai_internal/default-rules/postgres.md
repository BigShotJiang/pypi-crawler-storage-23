---
title: PostgreSQL Connector
description: PostgreSQL database connection and querying skill. Use when the user needs to connect to PostgreSQL, explore schemas, or query data from Postgres databases.
when_to_apply: Auto
alwaysApply: false
applyIntelligently: true
updated_at: "2026-01-27T16:36:35Z"
default: true
category: database
version: "1.1.0"
active: true
---

# PostgreSQL Connector

Expert guidance for working with PostgreSQL databases.

## Critical Safety Rules

### Destructive Operations - ALWAYS WARN

Before generating ANY of these operations, you MUST warn the user about potential data loss:

- `DROP TABLE`, `DROP DATABASE`, `DROP SCHEMA`
- `DELETE` (especially without WHERE clause)
- `TRUNCATE TABLE`
- `ALTER TABLE` (structure changes)
- `UPDATE` without WHERE clause

When user requests destructive operations:
1. **Warn clearly**: "This operation will permanently delete/modify data and cannot be undone."
2. **Suggest safer alternatives**: soft deletes, backups, WHERE clause additions
3. **Show exactly what will be affected**: row counts, table names
4. **Never execute DELETE/UPDATE without WHERE** unless user explicitly confirms

### Query Safety - LIMIT Enforcement

For exploratory or ad-hoc SELECT queries:

1. **Always apply LIMIT** (default 1000) unless user explicitly requests all rows
2. **Warn about large result sets**: "This query may return many rows. Adding LIMIT 1000."
3. **For aggregations**, LIMIT is usually not needed but consider the grouping cardinality

Never generate unbounded `SELECT *` on tables without knowing their size.

### Data Privacy

Be cautious with columns that may contain PII:
- `email`, `phone`, `ssn`, `address`, `name`, `first_name`, `last_name`
- Columns containing `personal`, `private`, `secret`, `password`, `token`

## Package

```python
# Install packages (use your environment's package manager):
# - If using uv: !uv pip install psycopg2-binary sqlalchemy
# - Otherwise: !pip install psycopg2-binary sqlalchemy
```

## Connection Setup

### Using Environment Variables (with SQLAlchemy - Recommended for pandas)
```python
import os
from sqlalchemy import create_engine

engine = create_engine(
    f"postgresql+psycopg2://{os.environ['MYDB_USERNAME']}:{os.environ['MYDB_PASSWORD']}"
    f"@{os.environ['MYDB_HOST']}:{os.environ.get('MYDB_PORT', 5432)}"
    f"/{os.environ['MYDB_DATABASE']}"
)
```

### Using Environment Variables (raw psycopg2)
```python
import os
import psycopg2

conn = psycopg2.connect(
    host=os.environ['MYDB_HOST'],
    port=int(os.environ.get('MYDB_PORT', 5432)),
    database=os.environ['MYDB_DATABASE'],
    user=os.environ['MYDB_USERNAME'],
    password=os.environ['MYDB_PASSWORD']
)
```

### Using Context Managers (Recommended)
```python
import psycopg2

with psycopg2.connect(
    host="hostname",
    database="database_name",
    user="username",
    password="password"
) as conn:
    with conn.cursor() as cursor:
        cursor.execute("SELECT * FROM table_name")
        results = cursor.fetchall()
# Connection auto-closed
```

### Using with pandas (Recommended)
```python
import pandas as pd
from sqlalchemy import create_engine

# IMPORTANT: Always use SQLAlchemy engine with pd.read_sql().
# Raw psycopg2 connections cause UserWarning and may break in future pandas versions.
engine = create_engine("postgresql+psycopg2://username:password@hostname/database_name")

df = pd.read_sql("SELECT * FROM table_name", engine)
engine.dispose()
```

### Dict Cursor (returns dicts instead of tuples)
```python
import psycopg2
from psycopg2.extras import RealDictCursor

conn = psycopg2.connect(
    host="hostname",
    database="database_name",
    user="username",
    password="password"
)

cursor = conn.cursor(cursor_factory=RealDictCursor)
cursor.execute("SELECT * FROM users")
rows = cursor.fetchall()  # List of dicts
```

## Namespace

PostgreSQL uses a 2-level namespace: `schema.table` (default schema is `public`)

```sql
-- Fully qualified reference
SELECT * FROM schema_name.table_name;

-- With search_path set
SET search_path TO my_schema, public;
SELECT * FROM my_table;  -- Searches my_schema first, then public
```

## Case Sensitivity

```sql
-- Unquoted identifiers are converted to lowercase
SELECT * FROM MyTable;  -- Looks for mytable

-- Use double quotes for case-sensitive identifiers
SELECT * FROM "MyTable";  -- Looks for MyTable exactly
```

## Schema Discovery

```sql
-- List all schemas
SELECT schema_name FROM information_schema.schemata;

-- List all tables in a schema
SELECT table_name, table_type
FROM information_schema.tables
WHERE table_schema = 'public'
ORDER BY table_name;

-- Get table structure
SELECT
    column_name,
    data_type,
    character_maximum_length,
    is_nullable,
    column_default
FROM information_schema.columns
WHERE table_schema = 'public'
  AND table_name = 'your_table'
ORDER BY ordinal_position;

-- List indexes
SELECT indexname, indexdef
FROM pg_indexes
WHERE tablename = 'your_table';
```

## Query Patterns

### Date/Time Functions

```sql
-- Current timestamp
SELECT NOW();
SELECT CURRENT_TIMESTAMP;

-- Date arithmetic
SELECT CURRENT_DATE + INTERVAL '7 days';
SELECT CURRENT_DATE - INTERVAL '1 month';

-- Date difference
SELECT AGE('2024-12-31', '2024-01-01');  -- Returns interval
SELECT DATE_PART('day', '2024-12-31'::date - '2024-01-01'::date);  -- Days

-- Date truncation
SELECT DATE_TRUNC('month', created_at) as month_start;

-- Extract parts
SELECT EXTRACT(YEAR FROM created_at) as year;
SELECT EXTRACT(DOW FROM created_at) as day_of_week;  -- 0=Sunday
```

### JSON/JSONB Functions

```sql
-- Access JSON fields
SELECT data->>'field_name' as field_value  -- Returns text
FROM table_with_json;

SELECT data->'field_name' as field_value   -- Returns JSON
FROM table_with_json;

-- Nested access
SELECT data->'nested'->>'field' as nested_value
FROM table_with_json;

-- Check if key exists
SELECT * FROM table_with_json
WHERE data ? 'key_name';

-- JSONB containment
SELECT * FROM table_with_json
WHERE data @> '{"status": "active"}'::jsonb;

-- Build JSON object
SELECT json_build_object(
    'id', id,
    'name', name,
    'created', created_at
) as json_record
FROM users;
```

### Array Functions

```sql
-- Array literal
SELECT ARRAY[1, 2, 3];

-- Array contains
SELECT * FROM table_name
WHERE tags @> ARRAY['tag1'];

-- Array overlap
SELECT * FROM table_name
WHERE tags && ARRAY['tag1', 'tag2'];

-- Unnest array to rows
SELECT unnest(tags) as tag FROM table_name;
```

### Window Functions

```sql
-- Row number
SELECT
    *,
    ROW_NUMBER() OVER (PARTITION BY category ORDER BY amount DESC) as rank
FROM products;

-- Running total
SELECT
    date,
    amount,
    SUM(amount) OVER (ORDER BY date) as running_total
FROM transactions;

-- Moving average
SELECT
    date,
    amount,
    AVG(amount) OVER (
        ORDER BY date
        ROWS BETWEEN 6 PRECEDING AND CURRENT ROW
    ) as seven_day_avg
FROM daily_metrics;
```

### Upsert (INSERT ON CONFLICT)

```sql
INSERT INTO users (email, name, updated_at)
VALUES ('user@example.com', 'User Name', NOW())
ON CONFLICT (email)
DO UPDATE SET
    name = EXCLUDED.name,
    updated_at = NOW();
```

### Bulk Insert (Python)

```python
from psycopg2.extras import execute_values

data = [(1, 'a'), (2, 'b'), (3, 'c')]
execute_values(cursor,
    "INSERT INTO table_name (id, value) VALUES %s",
    data
)
```

## Performance

### EXPLAIN ANALYZE
```sql
-- View query plan with actual times
EXPLAIN ANALYZE
SELECT * FROM large_table
WHERE category = 'A'
ORDER BY created_at DESC
LIMIT 100;
```

### Index Creation
```sql
-- B-tree index (default, good for equality and range)
CREATE INDEX idx_name ON table_name(column_name);

-- Partial index
CREATE INDEX idx_active_users ON users(email)
WHERE status = 'active';

-- GIN index for arrays/JSONB
CREATE INDEX idx_tags ON articles USING GIN(tags);
```

### Full-Text Search
```sql
-- Create search vector
ALTER TABLE articles ADD COLUMN search_vector tsvector;
UPDATE articles SET search_vector = to_tsvector('english', title || ' ' || content);

-- Create index
CREATE INDEX articles_search_idx ON articles USING GIN(search_vector);

-- Search
SELECT * FROM articles
WHERE search_vector @@ to_tsquery('english', 'python & data');
```

### Table Maintenance
```sql
-- Analyze table statistics
ANALYZE table_name;

-- Vacuum to reclaim space
VACUUM ANALYZE table_name;
```

## Common Errors

| Error | Cause | Solution |
|-------|-------|----------|
| Connection refused | Wrong host/port or server not running | Verify server is running and accessible |
| Authentication failed | Wrong username/password | Verify credentials |
| Database does not exist | Wrong database name | Check database name |
| Relation does not exist | Wrong table name or schema | Check table name and schema |
| Permission denied | Insufficient privileges | Contact admin for grants |
| pandas UserWarning: only supports SQLAlchemy | Using raw psycopg2 conn with pd.read_sql() | Use `create_engine("postgresql+psycopg2://...")` instead |

## Key Rules

1. **Always use SQLAlchemy `create_engine()` with `pd.read_sql()`** - never pass raw psycopg2 connections to pandas
2. Use double quotes for case-sensitive identifiers
3. Always use parameterized queries
4. Use context managers for connections
5. VACUUM regularly for optimal performance