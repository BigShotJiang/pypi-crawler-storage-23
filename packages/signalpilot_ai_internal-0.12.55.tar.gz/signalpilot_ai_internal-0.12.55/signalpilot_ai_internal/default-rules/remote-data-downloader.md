---
title: Remote Data Downloader
description: Financial and economic data downloading skill for yfinance, FRED, and other remote APIs. Use when the user needs to download market data, economic indicators, or external financial data. Contains critical API usage notes.
when_to_apply: Auto
alwaysApply: false
applyIntelligently: true
updated_at: "2026-01-27T16:36:38Z"
default: true
category: core
version: "1.0.0"
active: true
---

# Remote Data Downloader

You are an expert at downloading financial and economic data from various APIs. This skill contains critical information about current API behavior to avoid common errors.

## yfinance (Yahoo Finance)

### CRITICAL: Current API Changes

**The yfinance API has changed significantly. Key differences:**

1. **No "Adj Close" column** - Use "Close" instead
2. **Column format changed** - Single-ticker downloads return different column names
3. **Multi-ticker format** - Returns MultiIndex columns with ticker as first level

### Installation
```python
# Install package (use your environment's package manager):
# - If using uv: !uv pip install yfinance
# - Otherwise: !pip install yfinance
```

### Basic Usage - Single Ticker
```python
import yfinance as yf
import pandas as pd

# Download single ticker
ticker = yf.Ticker("AAPL")
df = ticker.history(period="1y")

# Available columns: Open, High, Low, Close, Volume, Dividends, Stock Splits
# NOTE: "Adj Close" does NOT exist - use "Close"
print(df.columns)
```

### Download with Date Range
```python
# Specific date range
df = yf.download("AAPL", start="2023-01-01", end="2024-01-01")

# Or use Ticker object
ticker = yf.Ticker("AAPL")
df = ticker.history(start="2023-01-01", end="2024-01-01")
```

### Period Options
```python
# Valid periods: 1d, 5d, 1mo, 3mo, 6mo, 1y, 2y, 5y, 10y, ytd, max
df = yf.download("AAPL", period="1y")
```

### Interval Options
```python
# Valid intervals: 1m, 2m, 5m, 15m, 30m, 60m, 90m, 1h, 1d, 5d, 1wk, 1mo, 3mo
# Note: Intraday data limited to last 60 days for 1m, last 730 days for 1h
df = yf.download("AAPL", period="5d", interval="1h")
```

### Multiple Tickers
```python
# Download multiple tickers
tickers = ["AAPL", "GOOGL", "MSFT"]
df = yf.download(tickers, period="1y")

# Result has MultiIndex columns: (Price Type, Ticker)
# Access like: df['Close']['AAPL'] or df[('Close', 'AAPL')]

# Get just Close prices
close_prices = df['Close']
print(close_prices.columns)  # ['AAPL', 'GOOGL', 'MSFT']
```

### Ticker Information
```python
ticker = yf.Ticker("AAPL")

# Company info
info = ticker.info
print(info['longName'])
print(info['sector'])
print(info['marketCap'])

# Financial statements
income_stmt = ticker.income_stmt
balance_sheet = ticker.balance_sheet
cashflow = ticker.cashflow

# Dividends and splits
dividends = ticker.dividends
splits = ticker.splits

# Options
options = ticker.options  # Expiration dates
opt_chain = ticker.option_chain(options[0])  # Calls and puts
```

### Common Patterns

**Daily Returns**
```python
df = yf.download("AAPL", period="1y")
returns = df['Close'].pct_change()
```

**Moving Averages**
```python
df = yf.download("AAPL", period="2y")
df['MA50'] = df['Close'].rolling(window=50).mean()
df['MA200'] = df['Close'].rolling(window=200).mean()
```

**Portfolio Download**
```python
portfolio = ["AAPL", "GOOGL", "MSFT", "AMZN", "META"]
data = yf.download(portfolio, period="1y")['Close']
returns = data.pct_change()
correlation = returns.corr()
```

### Error Handling
```python
import yfinance as yf

def safe_download(ticker, **kwargs):
    """Safely download data with error handling."""
    try:
        df = yf.download(ticker, **kwargs, progress=False)
        if df.empty:
            print(f"No data returned for {ticker}")
            return None
        return df
    except Exception as e:
        print(f"Error downloading {ticker}: {e}")
        return None
```

## FRED (Federal Reserve Economic Data)

### Installation
```python
# Install package (use your environment's package manager):
# - If using uv: !uv pip install fredapi
# - Otherwise: !pip install fredapi
```

### Setup
```python
from fredapi import Fred

# Requires API key from https://fred.stlouisfed.org/docs/api/api_key.html
fred = Fred(api_key='your_api_key_here')
```

### Common Series IDs

| Series ID | Description |
|-----------|-------------|
| `GDP` | Real Gross Domestic Product |
| `GDPC1` | Real GDP (Chained 2012 Dollars) |
| `UNRATE` | Unemployment Rate |
| `CPIAUCSL` | Consumer Price Index |
| `FEDFUNDS` | Federal Funds Effective Rate |
| `DGS10` | 10-Year Treasury Constant Maturity Rate |
| `T10Y2Y` | 10-Year Minus 2-Year Treasury Yield Spread |
| `HOUST` | Housing Starts |
| `INDPRO` | Industrial Production Index |
| `M2SL` | M2 Money Supply |

### Basic Usage
```python
# Get series
gdp = fred.get_series('GDP')

# With date range
unemployment = fred.get_series('UNRATE', start='2020-01-01')

# Get series info
info = fred.get_series_info('GDP')
print(info['title'])
```

### Search for Series
```python
# Search FRED
results = fred.search('inflation')
print(results[['title', 'id', 'frequency']])
```

### Multiple Series
```python
import pandas as pd

series_ids = ['UNRATE', 'CPIAUCSL', 'FEDFUNDS']
data = {}
for sid in series_ids:
    data[sid] = fred.get_series(sid)

df = pd.DataFrame(data)
```

## pandas-datareader (Alternative)

### Installation
```python
# Install package (use your environment's package manager):
# - If using uv: !uv pip install pandas-datareader
# - Otherwise: !pip install pandas-datareader
```

### Usage
```python
import pandas_datareader as pdr
from datetime import datetime

# Yahoo Finance (alternative to yfinance)
df = pdr.get_data_yahoo('AAPL', start='2023-01-01')

# FRED
df = pdr.get_data_fred('GDP', start='2020-01-01')

# Multiple FRED series
df = pdr.get_data_fred(['GDP', 'UNRATE'], start='2020-01-01')
```

## Common Patterns

### Download and Cache
```python
import os
import pandas as pd
import yfinance as yf

def get_cached_data(ticker, period="1y", cache_dir="./data"):
    """Download data with local caching."""
    os.makedirs(cache_dir, exist_ok=True)
    cache_file = os.path.join(cache_dir, f"{ticker}_{period}.csv")

    if os.path.exists(cache_file):
        # Check if cache is fresh (less than 1 day old)
        import time
        if time.time() - os.path.getmtime(cache_file) < 86400:
            return pd.read_csv(cache_file, index_col=0, parse_dates=True)

    # Download fresh data
    df = yf.download(ticker, period=period, progress=False)
    df.to_csv(cache_file)
    return df
```

### Handle Timezone Issues
```python
import yfinance as yf

df = yf.download("AAPL", period="1mo")
# Index is timezone-aware by default

# Remove timezone for compatibility
df.index = df.index.tz_localize(None)
```

### Align Multiple Data Sources
```python
import pandas as pd
import yfinance as yf
from fredapi import Fred

# Stock data
stocks = yf.download("SPY", period="5y")['Close']

# Economic data (monthly)
fred = Fred(api_key='...')
gdp = fred.get_series('GDP')

# Resample stock data to monthly and align
stocks_monthly = stocks.resample('MS').last()

# Merge
combined = pd.DataFrame({
    'SPY': stocks_monthly,
    'GDP': gdp
}).dropna()
```

## Troubleshooting

### yfinance Issues

**Empty DataFrame returned:**
```python
# Check if ticker exists
ticker = yf.Ticker("INVALID")
if not ticker.info:
    print("Invalid ticker")
```

**Rate limiting:**
```python
# Add delays for bulk downloads
import time
for t in tickers:
    df = yf.download(t, period="1y", progress=False)
    time.sleep(1)  # Be respectful to the API
```

**"Adj Close" not found:**
```python
# WRONG (old API)
returns = df['Adj Close'].pct_change()

# CORRECT (current API)
returns = df['Close'].pct_change()
```

### FRED Issues

**API key errors:**
- Register at https://fred.stlouisfed.org/docs/api/api_key.html
- Set key in environment: `export FRED_API_KEY=your_key`

**Series not found:**
```python
# Search for correct series ID
results = fred.search('consumer price index')
print(results[['id', 'title']])
```

## Best Practices

1. **Verify tickers first** - Use search tools before downloading
2. **Use Close, not Adj Close** - yfinance API changed
3. **Handle missing data** - Check for empty DataFrames
4. **Respect rate limits** - Add delays for bulk operations
5. **Cache when possible** - Avoid redundant API calls
6. **Check data quality** - Look for gaps, outliers, incorrect values
7. **Document sources** - Note where data came from and when downloaded