"""Tests for the Kai client library."""


