"""Test package for fastapi-mcp-router."""
