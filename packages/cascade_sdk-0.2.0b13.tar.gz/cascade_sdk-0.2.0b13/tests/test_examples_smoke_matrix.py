import py_compile
from pathlib import Path


def test_example_scripts_compile_smoke():
    """
    Lightweight smoke matrix: key example scripts should be syntactically valid.
    """
    base = Path(__file__).resolve().parents[1] / "examples"
    targets = [
        "test_full_sdk.py",
        "test_integrations.py",
        "test_streaming_llm.py",
        "test_openai_streaming.py",
        "test_tool_decorator.py",
    ]

    for name in targets:
        py_compile.compile(str(base / name), doraise=True)
