import pytest


def test_instrument_langgraph_smoke(monkeypatch):
    import cascade.integrations.langgraph as mod

    monkeypatch.setattr(mod, "_instrumented", False)
    try:
        mod.instrument_langgraph()
    except ImportError:
        pytest.skip("langgraph/langchain-core not installed")
    # Idempotency path
    mod.instrument_langgraph()
    assert mod._instrumented is True


def test_instrument_openai_agents_smoke(monkeypatch):
    import cascade.integrations.openai_agents as mod

    monkeypatch.setattr(mod, "_instrumented", False)
    try:
        mod.instrument_openai_agents()
    except ImportError:
        pytest.skip("openai-agents not installed")
    mod.instrument_openai_agents()
    assert mod._instrumented is True


def test_instrument_claude_agents_smoke(monkeypatch):
    import cascade.integrations.claude_agents as mod

    monkeypatch.setattr(mod, "_instrumented", False)
    try:
        mod.instrument_claude_agents()
    except ImportError:
        pytest.skip("claude-agent-sdk not installed")
    mod.instrument_claude_agents()
    assert mod._instrumented is True

