from backend.vercel_ai_normalize import normalize_vercel_ai_span


def test_normalize_toolcall_span():
    attrs = {
        "ai.operationId": "ai.toolCall",
        "ai.toolCall.name": "weather",
        "ai.toolCall.args": {"location": "SF"},
        "ai.toolCall.result": {"temperatureF": 70},
    }

    out = normalize_vercel_ai_span("ai.toolCall", attrs)
    assert out["cascade.span_type"] == "tool"
    assert out["tool.name"] == "weather"
    assert out["tool.input"] == {"location": "SF"}
    assert out["tool.output"] == {"temperatureF": 70}


def test_normalize_llm_span_with_gen_ai_semconv():
    attrs = {
        "ai.operationId": "ai.generateText.doGenerate",
        "gen_ai.request.model": "gpt-5",
        "gen_ai.system": "openai",
        "gen_ai.usage.input_tokens": 11,
        "gen_ai.usage.output_tokens": 22,
        "ai.prompt": "hello",
        "ai.response.text": "world",
        "ai.prompt.messages": [{"role": "user", "content": "hello"}],
    }

    out = normalize_vercel_ai_span("ai.generateText.doGenerate", attrs)
    assert out["cascade.span_type"] == "llm"
    assert out["llm.model"] == "gpt-5"
    assert out["llm.provider"] == "openai"
    assert out["llm.input_tokens"] == 11
    assert out["llm.output_tokens"] == 22
    assert out["llm.total_tokens"] == 33
    assert out["llm.prompt"] == "hello"
    assert out["llm.completion"] == "world"
    assert out["llm.messages"] == [{"role": "user", "content": "hello"}]


def test_normalize_top_level_span_as_function():
    attrs = {"ai.operationId": "ai.generateText"}
    out = normalize_vercel_ai_span("ai.generateText", attrs)
    assert out["cascade.span_type"] == "function"

