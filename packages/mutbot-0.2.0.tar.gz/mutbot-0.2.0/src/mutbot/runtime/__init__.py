"""Runtime layer — workspace, session, storage, and terminal management."""
