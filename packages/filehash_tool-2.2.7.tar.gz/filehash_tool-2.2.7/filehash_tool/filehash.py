import argparse
import datetime
import hashlib
import os
import shutil
import sqlite3
import time

from collections import defaultdict
from dataclasses import dataclass
from fnmatch import fnmatch
from glob import glob
from pathlib import Path
from typing import Tuple, List, Dict, Union

# OpenSSL版本<1.0.2L或<1.1.1
try:
    from ssl import OPENSSL_VERSION_INFO as OV
    if ((OV[:2] == (1, 0) and OV[:4] < (1, 0, 2, 12))
        or
        (OV[:2] == (1, 1) and OV[:3] < (1, 1, 1))):
        raise RuntimeError(f'OpenSSL的SHA实现有误，版本：{OV}')
except ImportError:
    pass

try:
    from . import cr
except ImportError:
    import cr

VER1 = 2
VER2 = 2
VER3 = 7
HASH_METH = 'sha256'
NO_SPACE = False
DB_MIN_BACKUP = 10
READ_BUFFER = 64*1024

std_path = lambda path: str(Path(path).resolve())

class FHException(Exception):
    pass

def hash_str(hash_bytes):
    h = hash_bytes.hex()
    sep = '' if NO_SPACE else ' '
    h = sep.join([cr.colored(h[i : i + 8], cr.Fore.YELLOW)
                  for i in range(0, len(h), 8)])
    return h

UNITS = ('B', 'KiB', 'MiB', 'GiB', 'TiB', 'PiB')
def s_size(size):
    i = sub = 0
    left = size
    while left >= 1024 and i < len(UNITS) - 1:
        left, t = divmod(left, 1024)
        sub = t or (1 if sub else 0)
        i += 1
    if sub:
        sub = f'{sub/1024:.2f}'
        if sub[0] == '1':
            sub = '0.99'
        return f'{left}{sub[1:4]} {UNITS[i]} ({size:,})'
    else:
        return f'{left} {UNITS[i]} ({size:,})'

def progress_bar(total, title, width=50):
    last_percent = -1
    if len(title) > width:
        left, rem = divmod(width - 3, 2)
        right = left + rem
        title = title[:left] + '...' + title[-right:]
    else:
        title += '-' * (width - len(title))

    def progress(progress):
        nonlocal total, title, width, last_percent
        percent = (progress + 1) / total
        if percent - last_percent < 0.001:
            return
        last_percent = percent
        now = int(width * percent)
        bar = title[:now] + '|' + title[now+1:]
        print("%s %.1f%%" % (bar, 100*percent), end="\r", flush=True)

    def finish():
        print((width + 9) * ' ', end='\r')

    return progress, finish

@dataclass
class File:
    db_id: int
    time: int
    path: str
    size: int
    hash: bytes
    acc_hash: bytes

    def __str__(self):
        return (f'ID: {self.db_id:,} 大小: {s_size(self.size)}\n'
                f'文件: {self.path}\n'
                f'文件hash: {hash_str(self.hash)}\n'
                f'累积hash: {hash_str(self.acc_hash)}')

class Database:
    def __init__(self, db_dir, backup_dir, backup_size, write_mode: bool) -> None:
        # 检查参数
        if db_dir and not os.path.isdir(db_dir):
            raise FHException(f'--db_dir不是目录: {db_dir}')
        if backup_dir and not os.path.isdir(backup_dir):
            raise FHException(f'--backup_dir不是目录: {backup_dir}')
        if backup_size < DB_MIN_BACKUP:
            raise FHException(f'--backup_size应不小于{DB_MIN_BACKUP}')

        self.write_mode = write_mode
        self.db_version = 0
        self.hash_method = ''

        # 获取数据库路径
        root_path = os.getcwd()
        self.db_folder = db_dir or \
                         os.path.join(root_path, 'filehash_database')
        if not os.path.isdir(self.db_folder):
            os.makedirs(self.db_folder)

        print(f' - 数库目录: {self.db_folder}')
        print(f' - 备份目录: {backup_dir or "无"}')
        print(f' - 备份数量: {backup_size}')
        self.backup_dir = backup_dir
        self.backup_size = backup_size

        self.open_db()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_value, traceback):
        self.close_db()

    # get sorted db file list
    def _get_dbfile_list(self, folder) -> List[str]:
        lst = glob(os.path.join(folder, 'files_*.db'))
        lst.sort()
        return lst

    def _del_old_dbfile(self, folder) -> None:
        db_lst = self._get_dbfile_list(folder)

        assert self.backup_size >= DB_MIN_BACKUP
        if len(db_lst) > self.backup_size:
            db_lst = db_lst[0:len(db_lst)-self.backup_size]
            for del_fn in db_lst:
                try:
                    os.remove(del_fn)
                except Exception as e:
                    print(f'删除旧备份数据库文件{del_fn}时出错。', e)

    # 创建数据库
    def _creat_db(self) -> None:
        # info table
        sql = ('CREATE TABLE IF NOT EXISTS info( '
               'key TEXT NOT NULL UNIQUE, '
               'value TEXT);')
        self.cursor.execute(sql)

        # 写入创建数据库的程序版本
        sql = "INSERT INTO info VALUES('db_version', ?);"
        self.cursor.execute(sql, (str(100*VER1 + 10*VER2 + VER3),))

        # 写入hash方法
        sql = "INSERT INTO info VALUES('hash_method', ?);"
        self.cursor.execute(sql, (HASH_METH,))

        # files table
        sql = ('CREATE TABLE IF NOT EXISTS files( '
               'id        INTEGER PRIMARY KEY AUTOINCREMENT, '
               'time      INTEGER NOT NULL, '
               'path      TEXT    NOT NULL, '
               'size      INTEGER NOT NULL, '
               'hash      BLOB    NOT NULL, '
               'acc_hash  BLOB    NOT NULL);')
        self.cursor.execute(sql)

    def _check_db_integrity(self):
        r = self.cursor.execute('PRAGMA integrity_check;')
        lst = r.fetchall()
        if lst == [('ok',),]:
            print('数据库已通过完整性检查。')
        else:
            for row in lst:
                print(row)
            raise FHException('数据库完整性检查失败。')

    @staticmethod
    def file_hash(hash_method: str, path: str) -> bytes:
        # 计算文件hash
        h = hashlib.new(hash_method)
        buf = bytearray(READ_BUFFER)
        view = memoryview(buf)
        progress, finish = progress_bar(os.path.getsize(path),
                                       os.path.basename(path))
        acc_size = 0

        with open(path, 'rb') as f:
            while True:
                size = f.readinto(buf)
                if not size:
                    break
                h.update(view[:size])
                acc_size += size
                progress(acc_size)
        finish()
        return h.digest()

    @staticmethod
    def _int_to_8bytes(i: int) -> bytes:
        return i.to_bytes(length = 8,
                          byteorder = 'little',
                          signed = False)

    def _get_acc_hash(self,
                      id: int,
                      time: int,
                      path: str,
                      size: int,
                      file_hash: bytes) -> bytes:
        # 得到acc_hash
        h = hashlib.new(self.hash_method)
        if self.lst:
            acc_hash = self.lst[-1].acc_hash
        else:
            # 长度digest_size，填充0。
            acc_hash = bytearray(h.digest_size)

        # 重要信息在前，id在最后，用户可见路径在倒数第二。
        h.update(acc_hash)
        h.update(file_hash)
        h.update(self._int_to_8bytes(size))
        h.update(self._int_to_8bytes(time))
        h.update(path.encode('utf_32_le'))
        h.update(self._int_to_8bytes(id))
        return h.digest()

    def print_db_info(self) -> None:
        if self.lst:
            c = cr.colored(self.lst[-1].db_id,
                           cr.Fore.LIGHTCYAN_EX,
                           cr.Back.MAGENTA)
            print(f'数据库ID: {c}')

            # 累积hash
            ah = self.lst[-1].acc_hash

            # 打印累积hash
            print(f'累积hash: ', end='')
            GROUP_SIZE = 4
            ROW_GROUP = 4
            for i in range(0, len(ah), GROUP_SIZE):
                group = i // GROUP_SIZE + 1
                if group % ROW_GROUP == 0:
                    if group == len(ah) // GROUP_SIZE:
                        end = ''
                    else:
                        end = '\n' + 10 * ' '
                else:
                    end = ' '

                # 打印组序号
                c = cr.colored(f'{group:02}' if cr.ENABLED else f'[{group:02}]',
                               cr.Fore.YELLOW,
                               cr.Back.BLACK)
                print(c, end=' ')
                # 打印组内容
                c = cr.colored(' '.join(f'{one:02x}'
                                    for one
                                    in ah[i : i + GROUP_SIZE]),
                               cr.Fore.LIGHTYELLOW_EX,
                               cr.Back.BLUE)
                print(c, end=end)
            print()

    def close_db(self) -> None:
        # 关闭数据库
        self.cursor.close()
        self.conn.close()

        # 只读模式，使用已有数据库文件。
        if not self.write_mode:
            print('数据库已正常关闭。')
            return

        c = cr.colored(len(self.lst)-self.db_row, cr.Fore.LIGHTGREEN_EX)
        print(f'数据库已正常关闭，添加了{c}条数据。')

        if len(self.lst) == self.db_row:
            # 未修改，删除未修改的新文件。
            try:
                os.remove(self.db_file)
            except Exception as e:
                print(f'删除文件{self.db_file}时出错。', e)
        else:
            # 有修改，重命名。
            fn = 'files_%s_%d.db' % (time.strftime('%y%m%d_%H%M%S'),
                                     len(self.lst))
            path = os.path.join(self.db_folder, fn)
            try:
                os.rename(self.db_file, path)
            except Exception as e:
                print(f'重命名数据库文件{self.db_file}到{path}时出错:\n{e}')
                raise

            # 打印信息
            print(f'最新数据库文件: {path}\n')
            self.print_db_info()

            # 删除旧备份
            self._del_old_dbfile(self.db_folder)

            # 备份
            if self.backup_dir:
                shutil.copy(path, self.backup_dir)
                # 删除旧备份
                self._del_old_dbfile(self.backup_dir)

    def open_db(self):
        db_lst = self._get_dbfile_list(self.db_folder)
        if self.write_mode:
            self.db_file = os.path.join(self.db_folder, '~temp.db')
            if os.path.isfile(self.db_file):
                msg = (f'数据库文件{self.db_file}已存在，无法写入。'
                       f'请等待其它filehash进程结束。'
                       f'如果没有其它filehash进程在运行，可手动删除该文件。')
                raise FHException(msg)
            if db_lst:
                shutil.copy(db_lst[-1], self.db_file)
        else:
            if db_lst:
                self.db_file = db_lst[-1]
            else:
                self.db_file = ':memory:'

        # autocommit=True && isolation_level=None:
        # sqlite3 module doesn't issue BEGIN and commit implicitly
        # sqlite3 engine uses autocommit mode
        if hasattr(sqlite3, 'LEGACY_TRANSACTION_CONTROL'):
            self.conn = sqlite3.connect(self.db_file,
                                        autocommit=True)
        else:
            self.conn = sqlite3.connect(self.db_file,
                                        isolation_level=None)
        self.cursor = self.conn.cursor()

        # create table if not exists
        if not db_lst:
            self._creat_db()

        # load data
        self.load_all_entries()

    def _append_one_entry_data(self, f: File) -> None:
        self.lst.append(f)
        self.path_dict[f.path] = f
        self.hash_dict[(f.hash, f.size)].append(f)
        self.acc_size += f.size

    def load_all_entries(self) -> None:
        t1 = time.perf_counter()

        # 检查数据库完整性
        self._check_db_integrity()

        # 读取创建数据库的程序版本
        sql = "SELECT value FROM info WHERE key = 'db_version'"
        r = self.cursor.execute(sql)
        db_version = r.fetchone()
        if db_version is None:
            raise FHException('创建数据库的程序版本应>=2.2.0')
        self.db_version = db_version[0]

        # 读取hash方法
        sql = "SELECT value FROM info WHERE key = 'hash_method'"
        r = self.cursor.execute(sql)
        self.hash_method = r.fetchone()[0]
        print(f'当前hash算法: {cr.colored(self.hash_method, cr.Fore.YELLOW)}')

        # 加载数据
        sql = 'SELECT * FROM files ORDER BY id'
        r = self.cursor.execute(sql)

        self.lst : List[File] = []
        self.path_dict : Dict[str, File] = {}
        self.hash_dict : Dict[Tuple[bytes, int], List[File]] = defaultdict(list)
        self.acc_size : int = 0

        for row in r.fetchall():
            f = File(row[0], row[1], row[2],
                     row[3], row[4], row[5])

            # 计算累积hash
            acc_hash = self._get_acc_hash(f.db_id, f.time, f.path,
                                          f.size, f.hash)
            if acc_hash != f.acc_hash:
                c = cr.colored('数据库累积hash链验证失败',
                               cr.Fore.WHITE,
                               cr.Back.RED)
                print(f'{c}: {f.path}')
                raise FHException((f'数据库文件{f.path}的累积hash值有误，hash链不可信。\n'
                                   f'计算的累积hash: {hash_str(acc_hash)}\n'
                                   f'数库的累积hash: {hash_str(f.acc_hash)}'))

            self._append_one_entry_data(f)

        # 记录数据库行数
        self.db_row = len(self.lst)

        t2 = time.perf_counter()
        print(f'加载数据用时{t2-t1:.5f}秒, 共有{len(self.lst):,}条记录。\n')

        # 打印数据库信息
        self.print_db_info()
        print()

    def add_one(self, path) -> Union[File, None]:
        path = std_path(path)
        if path in self.path_dict:
            c = cr.colored('已存在',
                           cr.Fore.LIGHTYELLOW_EX,
                           cr.Back.BLUE)
            print(f'文件{c}于数据库，不再计算、录入hash值:\n{path}\n')
            return None

        # 计算文件hash
        file_hash = self.file_hash(self.hash_method, path)

        # 文件大小
        file_size = os.path.getsize(path)

        # 当前计算时间，单位秒。
        hash_time = int(time.time())

        self.cursor.execute('BEGIN')
        try:
            # 插入数据库
            sql = ('INSERT INTO files(id, time, path, size, hash, acc_hash) '
                   'VALUES(NULL, ?, ?, ?, ?, ?);')
            self.cursor.execute(sql,
                                (hash_time, path, file_size,
                                 file_hash, b''))
            last_id = self.cursor.lastrowid

            # 计算累积hash
            acc_hash = self._get_acc_hash(last_id, hash_time, path,
                                          file_size, file_hash)
            sql = 'UPDATE files SET acc_hash = ? WHERE id = ?'
            self.cursor.execute(sql, (acc_hash, last_id))

            self.cursor.execute('COMMIT')
        except:
            self.cursor.execute('ROLLBACK')
            raise

        # 加入list
        f = File(last_id, hash_time, path, file_size,
                 file_hash, acc_hash)
        self._append_one_entry_data(f)

        # 打印信息
        print(cr.colored('成功添加一条信息', cr.Fore.LIGHTGREEN_EX))
        print(f, '\n')

        return f

    def add(self, path: str):
        f_lst = []
        for one in glob(path, recursive=True):
            if os.path.isfile(one):
                f = self.add_one(one)
                if f is not None:
                    f_lst.append(f)

        count = cr.colored(len(f_lst), cr.Fore.LIGHTGREEN_EX)
        print(f'添加了{count}个文件。')
        if f_lst:
            for f in f_lst:
                print(f.path)
            print()

    def verify_record(self, glob_path: str) -> None:
        # 查找匹配的路径
        lst = []
        for f in self.lst:
            if fnmatch(f.path, glob_path):
                lst.append(f)

        # 验证文件
        count = 0
        for i, f in enumerate(lst, 1):
            # 文件不存在
            if not os.path.isfile(f.path):
                c = cr.colored('文件不存在',
                               cr.Fore.LIGHTYELLOW_EX,
                               cr.Back.MAGENTA)
                print(f'({i}/{len(lst)}){c}: {f.path}')
                continue

            # 验证文件大小
            size = os.path.getsize(f.path)
            if size != f.size:
                c = cr.colored('文件验证失败', cr.Fore.WHITE, cr.Back.RED)
                print(f'{c}: {f.path}')
                raise FHException((f'文件{f.path}的大小与数据库不符。\n'
                                   f'文件大小: {s_size(size)}\n'
                                   f'数库大小: {s_size(f.size)}\n'
                                   f'数库hash: {hash_str(f.hash)}'))

            # 验证hash
            hash = self.file_hash(self.hash_method, f.path)
            if hash != f.hash:
                c = cr.colored('文件验证失败', cr.Fore.WHITE, cr.Back.RED)
                print(f'{c}: {f.path}')
                raise FHException((f'文件{f.path}的hash值与数据库不符。\n'
                                   f'文件hash: {hash_str(hash)}\n'
                                   f'数库hash: {hash_str(f.hash)}\n'
                                   f'文件大小符合数据库记录: {s_size(f.size)}'))

            # 验证成功
            c = cr.colored('文件验证成功',
                           cr.Fore.LIGHTWHITE_EX,
                           cr.Back.GREEN)
            print(f'({i}/{len(lst)}){c}: {f.path}' )
            count += 1

        # 打印数据库信息
        count = cr.colored(count, cr.Fore.LIGHTRED_EX)
        print(f'验证了{count}个文件。\n')
        self.print_db_info()

    def print_record(self, glob_path: str, *, only_existing: bool) -> None:
        count = exist_count = 0
        for f in self.lst:
            if fnmatch(f.path, glob_path):
                count += 1

                # 文件是否存在
                if os.path.isfile(f.path):
                    exist = cr.colored('文件存在',
                                       cr.Fore.LIGHTWHITE_EX,
                                       cr.Back.GREEN)
                    exist_count += 1
                else:
                    if only_existing:
                        continue
                    exist = cr.colored('文件不存在',
                                       cr.Fore.LIGHTWHITE_EX,
                                       cr.Back.RED)

                time = datetime.datetime.fromtimestamp(f.time).\
                            strftime('%Y-%m-%d %H:%M:%S')
                print((f'文件: {f.path}\n'
                       f'大小: {s_size(f.size)}\n'
                       f'hash: {hash_str(f.hash)}\n'
                       f'登记: {time}\n'
                       f'状态: {exist}\n'))

        # 打印数据库信息
        count = cr.colored(count, cr.Fore.LIGHTRED_EX)
        exist_count = cr.colored(exist_count, cr.Fore.LIGHTRED_EX)
        if only_existing:
            print(f'匹配了{count}条记录，其中{exist_count}个文件存在。\n')
        else:
            print(f'打印了{count}条记录，其中{exist_count}个文件存在。\n')
        self.print_db_info()

    def verify_file_one(self, path) -> None:
        path = std_path(path)
        size = os.path.getsize(path)
        hash = self.file_hash(self.hash_method, path)

        # 在hash_dict中
        lst = self.hash_dict.get((hash, size))
        if lst:
            c = cr.colored('文件验证成功',
                           cr.Fore.LIGHTWHITE_EX,
                           cr.Back.GREEN)
            print(f'{c}: {path}')

            for f in lst:
                if len(lst) > 1 or path != f.path:
                    c = cr.colored('数据库中路径',
                                   cr.Fore.LIGHTWHITE_EX,
                                   cr.Back.MAGENTA)
                    print(f'{c}: {f.path}')

            print((f'大小: {s_size(size)}\n'
                   f'hash: {hash_str(hash)}\n'))
            return

        # 在path_dict中
        if path in self.path_dict:
            f = self.path_dict[path]

            if size != f.size:
                c = cr.colored('文件验证失败', cr.Fore.WHITE, cr.Back.RED)
                print(f'{c}: {path}')
                raise FHException((f'文件{path}的大小与数据库不符。\n'
                                   f'文件大小: {s_size(size)}\n'
                                   f'数库大小: {s_size(f.size)}\n'
                                   f'数库hash: {hash_str(f.hash)}'))

            if hash != f.hash:
                c = cr.colored('文件验证失败', cr.Fore.WHITE, cr.Back.RED)
                print(f'{c}: {path}')
                raise FHException((f'文件{path}的hash值与数据库不符。\n'
                                   f'文件hash: {hash_str(hash)}\n'
                                   f'数库hash: {hash_str(f.hash)}\n'
                                   f'文件大小符合数据库记录: {s_size(f.size)}'))

            raise Exception('不可到达代码路径')

        c = cr.colored('文件验证失败', cr.Fore.WHITE, cr.Back.RED)
        print(f'{c}: {path}')
        raise FHException((f'文件{path}的hash值、大小不在数据库中。\n'
                           f'文件hash: {hash_str(hash)}\n'
                           f'文件大小: {s_size(size)}'))

    def verify_file(self, path: str):
        count = 0
        for one in glob(path, recursive=True):
            if os.path.isfile(one):
                self.verify_file_one(one)
                count += 1

        # 打印数据库信息
        count = cr.colored(count, cr.Fore.LIGHTRED_EX)
        print(f'验证了{count}个文件。\n')
        self.print_db_info()

def print_file(path: str):
    print(f'使用hash算法: {cr.colored(HASH_METH, cr.Fore.YELLOW)}\n')

    count = 0
    for one in glob(path, recursive=True):
        if os.path.isfile(one):
            file_size = os.path.getsize(one)
            hash = Database.file_hash(HASH_METH, one)
            s = (f'文件: {std_path(one)}\n'
                 f'大小: {s_size(file_size)}\n'
                 f'hash: {hash_str(hash)}\n')
            print(s)
            count += 1

    count = cr.colored(count, cr.Fore.LIGHTRED_EX)
    print(f'计算了{count}个文件。')

def args_config(args):
    # hash方法
    global HASH_METH
    HASH_METH = (args.hash_meth[0] or
                 os.getenv('FILEHASH_HASH_METH', HASH_METH))
    if HASH_METH not in hashlib.algorithms_available:
        raise FHException(f'指定的hash算法"{HASH_METH}"不可用。')

    # print文件hash时无空格
    global NO_SPACE
    NO_SPACE = args.no_space

def get_hash_meth_list():
    guaranteed = list(hashlib.algorithms_guaranteed)
    guaranteed.sort()
    s = '保证存在的hash算法: ' + ', '.join(guaranteed)

    available = hashlib.algorithms_available.difference(hashlib.algorithms_guaranteed)
    available = list(available)
    available.sort()
    s += '\n其它可用的hash算法: ' + ', '.join(available)
    return s

def backup_config(args):
    # 数据库目录
    db_dir = (args.db_dir[0] or
              os.getenv('FILEHASH_DB_DIR', ''))

    # 备份目录
    backup_dir = (args.backup_dir[0] or
                  os.getenv('FILEHASH_BACKUP_DIR', ''))

    # 备份数量
    backup_size_str = (args.backup_size[0] or
                       os.getenv('FILEHASH_BACKUP_SIZE', '20'))

    try:
        backup_size = int(backup_size_str)
    except ValueError:
        raise FHException((f'解析环境变量FILEHASH_BACKUP_SIZE或'
                           f'参数--backup_size失败: {backup_size_str}'))

    return db_dir, backup_dir, backup_size

def main_impl():
    parser = argparse.ArgumentParser(
        description = (f'文件hash校验。版本: {VER1}.{VER2}.{VER3}\n'
                       f'https://pypi.org/project/filehash-tool'),
        epilog = ('可用命令:\n'
                  '  add/a                     登记文件到数据库\n'
                  '  verify_record/vr          验证数据库中的记录\n'
                  '  print_record/pr           打印数据库中的记录\n'
                  '  print_existing_record/per 打印数据库中尚存在的记录\n'
                  '  verify_file/vf            验证磁盘文件\n'
                  '  print_file/pf             计算文件hash值 (不加载数据库)\n\n') +
                  get_hash_meth_list(),
        formatter_class = argparse.RawDescriptionHelpFormatter)
    cmds = ['',
            'a', 'add',
            'vr', 'verify_record',
            'pr', 'print_record',
            'print_existing_record', 'per',
            'vf', 'verify_file',
            'pf', 'print_file']
    parser.add_argument('command', nargs='?', default='', choices=cmds,
                        metavar='CMD', help='命令')
    parser.add_argument('path', nargs='?', default='.',
                        metavar='PATH',
                        help='路径，使用glob语法，*表示所有文件，dir/**/*.exe遍历子目录。')
    parser.add_argument('-m', '--hash-meth', nargs=1, default=[''], metavar='HASH_METH',
                        help='创建数据库时使用的hash算法，覆盖FILEHASH_HASH_METH环境变量。')
    parser.add_argument('-n', '--no-space', action='store_true', dest='no_space', default=False,
                        help='打印hash时，不添加空格。')
    parser.add_argument('--db-dir', nargs=1, default=[''], metavar='DIR',
                        help='数据库目录，覆盖FILEHASH_DB_DIR环境变量。')
    parser.add_argument('--backup-dir', nargs=1, default=[''], metavar='DIR',
                        help='备份保存的数据库目录，覆盖FILEHASH_BACKUP_DIR环境变量。')
    parser.add_argument('--backup-size', nargs=1, default=[''], metavar='SIZE',
                        help='备份保存的数据库数量，覆盖FILEHASH_BACKUP_SIZE环境变量。')
    args = parser.parse_args()
    cmd = args.command.lower()
    path = args.path
    if cmd != '' and path == '.':
        raise FHException('PATH路径不支持"."默认路径，需明确指定路径。')
    args_config(args)

    if cmd in ('print_file', 'pf'):
        print_file(path)
    elif cmd == '':
        parser.print_help()
        print(f'当前创建数据库使用的hash算法: {HASH_METH}')
    else:
        db_dir, backup_dir, backup_size = backup_config(args)
        with Database(db_dir, backup_dir, backup_size,
                      cmd in ('add', 'a')) as db:
            if cmd in ('add', 'a'):
                db.add(path)
            elif cmd in ('verify_record', 'vr'):
                db.verify_record(path)
            elif cmd in ('print_record', 'pr'):
                db.print_record(path, only_existing=False)
            elif cmd in ('print_existing_record', 'per'):
                db.print_record(path, only_existing=True)
            elif cmd in ('verify_file', 'vf'):
                db.verify_file(path)
            else:
                raise ValueError('未知参数')

def main():
    with cr.cr_block():
        try:
            main_impl()
        except FHException as e:
            s = str(e)
            c = cr.colored('程序出现异常，中止运行：',
                           cr.Fore.WHITE,
                           cr.Back.RED)
            print(f'\n{c}\n{s}')

if __name__ == '__main__':
    main()