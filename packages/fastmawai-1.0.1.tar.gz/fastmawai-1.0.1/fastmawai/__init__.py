def gpt(text):
    return f"GPT: {text}"