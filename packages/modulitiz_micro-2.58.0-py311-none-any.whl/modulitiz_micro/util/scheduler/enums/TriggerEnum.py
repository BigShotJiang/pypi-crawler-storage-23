from enum import StrEnum
from enum import unique


@unique
class TriggerEnum(StrEnum):
	CRON="cron"
	DATE="date"
	INTERVAL="interval"
