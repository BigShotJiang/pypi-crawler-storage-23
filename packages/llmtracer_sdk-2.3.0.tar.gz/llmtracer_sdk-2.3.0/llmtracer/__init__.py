"""LLM Tracer — Auto-track LLM cost, latency, and usage.

Quick start::

    import llmtracer
    llmtracer.init(api_key="lt_...")

    # Every OpenAI / Anthropic call is now tracked automatically.

Optional grouping::

    with llmtracer.trace(conversation_id="abc", user_id="tim"):
        response = openai.chat.completions.create(...)
"""

import asyncio
import contextlib
import functools
import os
import uuid

from . import _config, _context, _patcher, _transport

__version__ = "2.3.0"

__all__ = ["init", "trace", "flush", "__version__"]


def init(api_key=None, debug=False, endpoint=None):
    """Initialize LLM Tracer. Patches installed provider SDKs.

    Parameters
    ----------
    api_key : str, optional
        Your LLM Tracer API key. Falls back to LLMTRACER_API_KEY env var.
    debug : bool
        If True, print patch confirmations and per-call logs.
    endpoint : str, optional
        Override the event ingestion endpoint.
    """
    try:
        _config.api_key = api_key or os.environ.get("LLMTRACER_API_KEY", "")
        _config.debug = debug
        _config.endpoint = (
            endpoint
            or "https://us-central1-llmtracer-alt.cloudfunctions.net/v1Events"
        )
        _config.enabled = bool(_config.api_key)

        # Generate a process-level session ID for grouping events
        try:
            _config.session_id = str(uuid.uuid4())
        except Exception:
            _config.session_id = ""

        if not _config.enabled:
            if debug:
                print("[llmtracer] No API key found. Tracing disabled.")
            return

        if debug:
            print(f"[llmtracer] Session: {_config.session_id}")

        _transport.start()

        # Auto-discover and patch providers
        _patcher.patch_openai(debug=debug)
        _patcher.patch_anthropic(debug=debug)
        _patcher.patch_google(debug=debug)

        if debug:
            print("[llmtracer] Ready. Events \u2192 app.llmtracer.com")

    except Exception as e:
        _config.enabled = False
        if debug:
            print(f"[llmtracer] init() failed: {e}. Tracing disabled.")


def flush():
    """Force send all buffered events."""
    try:
        _transport.flush()
    except Exception:
        pass


class _TraceContextManager:
    """Works as both context manager and decorator."""

    def __init__(self, tags):
        self.tags = tags
        self._token = None
        self._ctx = None

    def __enter__(self):
        self._token, self._ctx = _context.push(self.tags)
        return self._ctx

    def __exit__(self, *exc):
        if self._token is not None:
            _context.pop(self._token)
        return False

    def __call__(self, fn):
        """Support use as decorator."""
        if asyncio.iscoroutinefunction(fn):

            @functools.wraps(fn)
            async def async_wrapper(*args, **kwargs):
                with _TraceContextManager(self.tags):
                    return await fn(*args, **kwargs)

            return async_wrapper
        else:

            @functools.wraps(fn)
            def sync_wrapper(*args, **kwargs):
                with _TraceContextManager(self.tags):
                    return fn(*args, **kwargs)

            return sync_wrapper


def trace(fn=None, **tags):
    """Group LLM calls into a trace with optional tags.

    Usage::

        # Context manager
        with llmtracer.trace(conversation_id="abc", user_id="tim"):
            response = openai.chat.completions.create(...)

        # Decorator with args
        @llmtracer.trace(phase="planning")
        def plan(query): ...

        # Bare decorator
        @llmtracer.trace
        def plan(query): ...
    """
    try:
        if fn is not None and callable(fn):
            # @llmtracer.trace without parens — fn is the decorated function
            return _TraceContextManager({})(fn)
        # @llmtracer.trace(...) or with llmtracer.trace(...)
        return _TraceContextManager(tags)
    except Exception:
        # If trace setup fails, return the function unmodified or a no-op ctx manager
        if fn is not None:
            return fn
        return contextlib.nullcontext()
