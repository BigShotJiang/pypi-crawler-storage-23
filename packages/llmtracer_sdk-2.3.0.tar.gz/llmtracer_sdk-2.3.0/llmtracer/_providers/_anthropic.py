"""Anthropic-specific: patch targets, response parsing, stream wrapping."""

import time

from .. import _config
from .._wrapper import _build_and_enqueue

# ── Patch targets ─────────────────────────────────────────────────────────────

SYNC_TARGET = ("anthropic.resources.messages", "Messages", "create")
ASYNC_TARGET = ("anthropic.resources.messages", "AsyncMessages", "create")
SYNC_STREAM_TARGET = ("anthropic.resources.messages", "Messages", "stream")
ASYNC_STREAM_TARGET = ("anthropic.resources.messages", "AsyncMessages", "stream")


# ── Response parsing ──────────────────────────────────────────────────────────


def parse_response(result):
    """Extract provider/model/tokens from an Anthropic Message."""
    usage = getattr(result, "usage", None)
    input_tokens = getattr(usage, "input_tokens", 0) or 0 if usage else 0
    output_tokens = getattr(usage, "output_tokens", 0) or 0 if usage else 0

    # Cache tokens are reported separately from input_tokens by Anthropic
    cache_creation = 0
    cache_read = 0
    if usage:
        cache_creation = getattr(usage, "cache_creation_input_tokens", 0) or 0
        cache_read = getattr(usage, "cache_read_input_tokens", 0) or 0
        input_tokens += cache_creation + cache_read

    if _config.debug and usage:
        print(f"[llmtracer] Anthropic tokens — in={input_tokens} (base={input_tokens - cache_creation - cache_read} cache_create={cache_creation} cache_read={cache_read}) out={output_tokens}")

    return {
        "provider": "anthropic",
        "model": getattr(result, "model", None) or "unknown",
        "input_tokens": input_tokens,
        "output_tokens": output_tokens,
        "status": "success",
    }


# ── Sync stream wrapper ──────────────────────────────────────────────────────


class _WrappedStream:
    """Transparent wrapper for Anthropic streaming responses.

    Anthropic's stream=True returns an iterable of MessageStreamEvent objects.
    We watch for message_start (input tokens), message_delta (output tokens),
    and record the event when the stream completes (via StopIteration, close,
    context-manager exit, or exception).
    """

    def __init__(self, original_stream, context, start_elapsed_ms, kwargs):
        self._stream = original_stream
        self._context = context
        self._create_elapsed_ms = start_elapsed_ms
        self._start_time = time.monotonic()
        self._kwargs = kwargs
        self._model = kwargs.get("model", "unknown")
        self._input_tokens = 0
        self._output_tokens = 0
        self._cache_creation_tokens = 0
        self._cache_read_tokens = 0
        self._recorded = False

    def __iter__(self):
        return self

    def __next__(self):
        try:
            event = next(self._stream)
            self._extract(event)
            return event
        except StopIteration:
            self._record(status="success")
            raise
        except Exception:
            self._record(status="error")
            raise

    def _extract(self, event):
        """Extract token counts from stream events."""
        event_type = getattr(event, "type", None)

        if event_type == "message_start":
            msg = getattr(event, "message", None)
            if msg:
                self._model = getattr(msg, "model", self._model)
                usage = getattr(msg, "usage", None)
                if usage:
                    self._input_tokens = getattr(usage, "input_tokens", 0) or 0
                    self._cache_creation_tokens = getattr(usage, "cache_creation_input_tokens", 0) or 0
                    self._cache_read_tokens = getattr(usage, "cache_read_input_tokens", 0) or 0

        elif event_type == "message_delta":
            usage = getattr(event, "usage", None)
            if usage:
                self._output_tokens = getattr(usage, "output_tokens", 0) or 0

    def _record(self, status="success"):
        """Record the tracing event once; subsequent calls are no-ops."""
        if self._recorded:
            return
        self._recorded = True
        try:
            elapsed_ms = self._create_elapsed_ms + int(
                (time.monotonic() - self._start_time) * 1000
            )
            total_input = (
                self._input_tokens
                + self._cache_creation_tokens
                + self._cache_read_tokens
            )

            if _config.debug and (
                self._cache_creation_tokens or self._cache_read_tokens
            ):
                print(
                    f"[llmtracer] Anthropic stream tokens — "
                    f"in={total_input} (base={self._input_tokens} "
                    f"cache_create={self._cache_creation_tokens} "
                    f"cache_read={self._cache_read_tokens}) "
                    f"out={self._output_tokens}"
                )

            response_data = {
                "provider": "anthropic",
                "model": self._model,
                "input_tokens": total_input,
                "output_tokens": self._output_tokens,
                "status": status,
            }
            _build_and_enqueue(self._context, response_data, elapsed_ms)
        except Exception:
            pass

    def __getattr__(self, name):
        return getattr(self._stream, name)

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        # FIRST: close the underlying stream (user's resource)
        try:
            if hasattr(self._stream, "__exit__"):
                result = self._stream.__exit__(exc_type, exc_val, exc_tb)
            else:
                result = False
        except Exception:
            # Record what we can, then re-raise the stream close exception
            self._record(status="error" if exc_type else "success")
            raise
        # SECOND: record the event (never raises)
        self._record(status="error" if exc_type else "success")
        return result

    def close(self):
        self._record(status="success")
        if hasattr(self._stream, "close"):
            self._stream.close()

    def __del__(self):
        try:
            self._record(status="error")
        except Exception:
            pass


def wrap_stream(result, context, elapsed_ms, kwargs):
    """Wrap a sync Anthropic stream."""
    return _WrappedStream(result, context, elapsed_ms, kwargs)


# ── Async stream wrapper ─────────────────────────────────────────────────────


class _WrappedAsyncStream:
    """Async transparent wrapper for Anthropic streaming."""

    def __init__(self, original_stream, context, start_elapsed_ms, kwargs):
        self._stream = original_stream
        self._context = context
        self._create_elapsed_ms = start_elapsed_ms
        self._start_time = time.monotonic()
        self._kwargs = kwargs
        self._model = kwargs.get("model", "unknown")
        self._input_tokens = 0
        self._output_tokens = 0
        self._cache_creation_tokens = 0
        self._cache_read_tokens = 0
        self._recorded = False

    def __aiter__(self):
        return self

    async def __anext__(self):
        try:
            event = await self._stream.__anext__()
            self._extract(event)
            return event
        except StopAsyncIteration:
            self._record(status="success")
            raise
        except Exception:
            self._record(status="error")
            raise

    def _extract(self, event):
        event_type = getattr(event, "type", None)

        if event_type == "message_start":
            msg = getattr(event, "message", None)
            if msg:
                self._model = getattr(msg, "model", self._model)
                usage = getattr(msg, "usage", None)
                if usage:
                    self._input_tokens = getattr(usage, "input_tokens", 0) or 0
                    self._cache_creation_tokens = getattr(usage, "cache_creation_input_tokens", 0) or 0
                    self._cache_read_tokens = getattr(usage, "cache_read_input_tokens", 0) or 0

        elif event_type == "message_delta":
            usage = getattr(event, "usage", None)
            if usage:
                self._output_tokens = getattr(usage, "output_tokens", 0) or 0

    def _record(self, status="success"):
        """Record the tracing event once; subsequent calls are no-ops."""
        if self._recorded:
            return
        self._recorded = True
        try:
            elapsed_ms = self._create_elapsed_ms + int(
                (time.monotonic() - self._start_time) * 1000
            )
            total_input = (
                self._input_tokens
                + self._cache_creation_tokens
                + self._cache_read_tokens
            )

            if _config.debug and (
                self._cache_creation_tokens or self._cache_read_tokens
            ):
                print(
                    f"[llmtracer] Anthropic stream tokens — "
                    f"in={total_input} (base={self._input_tokens} "
                    f"cache_create={self._cache_creation_tokens} "
                    f"cache_read={self._cache_read_tokens}) "
                    f"out={self._output_tokens}"
                )

            response_data = {
                "provider": "anthropic",
                "model": self._model,
                "input_tokens": total_input,
                "output_tokens": self._output_tokens,
                "status": status,
            }
            _build_and_enqueue(self._context, response_data, elapsed_ms)
        except Exception:
            pass

    def __getattr__(self, name):
        return getattr(self._stream, name)

    async def __aenter__(self):
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        # FIRST: close the underlying stream (user's resource)
        try:
            if hasattr(self._stream, "__aexit__"):
                result = await self._stream.__aexit__(exc_type, exc_val, exc_tb)
            else:
                result = False
        except Exception:
            # Record what we can, then re-raise the stream close exception
            self._record(status="error" if exc_type else "success")
            raise
        # SECOND: record the event (never raises)
        self._record(status="error" if exc_type else "success")
        return result

    def close(self):
        self._record(status="success")
        if hasattr(self._stream, "close"):
            self._stream.close()

    def __del__(self):
        try:
            self._record(status="error")
        except Exception:
            pass


def wrap_async_stream(result, context, elapsed_ms, kwargs):
    """Wrap an async Anthropic stream."""
    return _WrappedAsyncStream(result, context, elapsed_ms, kwargs)


# ── Sync .stream() context-manager wrapper ────────────────────────────────────


class _WrappedStreamManager:
    """Wraps the context manager returned by Messages.stream().

    Anthropic's .stream() returns a MessageStreamManager whose __enter__
    yields a MessageStream.  We intercept __exit__ to pull token usage
    from get_final_message() and record the tracing event.
    """

    def __init__(self, original_manager, context, start_time, kwargs):
        self._manager = original_manager
        self._context = context
        self._start_time = start_time
        self._kwargs = kwargs
        self._stream = None

    def __enter__(self):
        self._stream = self._manager.__enter__()
        return self._stream

    def __exit__(self, exc_type, exc_val, exc_tb):
        elapsed_ms = int((time.monotonic() - self._start_time) * 1000)
        model = self._kwargs.get("model", "unknown")
        input_tokens = 0
        output_tokens = 0
        status = "ok" if exc_type is None else "error"

        # FIRST: try to extract data before stream closes
        try:
            if self._stream and self._context:
                final = self._stream.get_final_message()
                model = getattr(final, "model", model)
                usage = getattr(final, "usage", None)
                if usage:
                    input_tokens = getattr(usage, "input_tokens", 0) or 0
                    output_tokens = getattr(usage, "output_tokens", 0) or 0
                    cache_creation = getattr(usage, "cache_creation_input_tokens", 0) or 0
                    cache_read = getattr(usage, "cache_read_input_tokens", 0) or 0
                    input_tokens += cache_creation + cache_read
        except Exception:
            if _config.debug:
                print("[llmtracer] \u26a0 Failed to extract stream final message")

        # SECOND: close the underlying stream (user's resource) — MUST happen
        try:
            result = self._manager.__exit__(exc_type, exc_val, exc_tb)
        except Exception:
            # Try to record before re-raising user's exception
            try:
                if self._context:
                    response_data = {
                        "provider": "anthropic",
                        "model": model,
                        "input_tokens": input_tokens,
                        "output_tokens": output_tokens,
                        "status": "error",
                    }
                    _build_and_enqueue(self._context, response_data, elapsed_ms)
            except Exception:
                pass
            raise  # User's exception from stream close

        # THIRD: record the event (never raises)
        try:
            if self._context:
                response_data = {
                    "provider": "anthropic",
                    "model": model,
                    "input_tokens": input_tokens,
                    "output_tokens": output_tokens,
                    "status": status,
                }
                _build_and_enqueue(self._context, response_data, elapsed_ms)
        except Exception:
            pass

        return result

    def __getattr__(self, name):
        return getattr(self._manager, name)


def wrap_stream_manager(result, context, start_time, kwargs):
    """Wrap a sync Anthropic .stream() context manager."""
    return _WrappedStreamManager(result, context, start_time, kwargs)


# ── Async .stream() context-manager wrapper ───────────────────────────────────


class _WrappedAsyncStreamManager:
    """Wraps the async context manager returned by AsyncMessages.stream().

    Same approach as _WrappedStreamManager but with __aenter__/__aexit__.
    """

    def __init__(self, original_manager, context, start_time, kwargs):
        self._manager = original_manager
        self._context = context
        self._start_time = start_time
        self._kwargs = kwargs
        self._stream = None

    async def __aenter__(self):
        self._stream = await self._manager.__aenter__()
        return self._stream

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        elapsed_ms = int((time.monotonic() - self._start_time) * 1000)
        model = self._kwargs.get("model", "unknown")
        input_tokens = 0
        output_tokens = 0
        status = "ok" if exc_type is None else "error"

        # FIRST: try to extract data before stream closes
        try:
            if self._stream and self._context:
                final = self._stream.get_final_message()
                # Handle both sync and async get_final_message
                if hasattr(final, "__await__"):
                    final = await final
                model = getattr(final, "model", model)
                usage = getattr(final, "usage", None)
                if usage:
                    input_tokens = getattr(usage, "input_tokens", 0) or 0
                    output_tokens = getattr(usage, "output_tokens", 0) or 0
                    cache_creation = getattr(usage, "cache_creation_input_tokens", 0) or 0
                    cache_read = getattr(usage, "cache_read_input_tokens", 0) or 0
                    input_tokens += cache_creation + cache_read
        except Exception:
            if _config.debug:
                print("[llmtracer] \u26a0 Failed to extract async stream final message")

        # SECOND: close the underlying stream (user's resource) — MUST happen
        try:
            result = await self._manager.__aexit__(exc_type, exc_val, exc_tb)
        except Exception:
            # Try to record before re-raising user's exception
            try:
                if self._context:
                    response_data = {
                        "provider": "anthropic",
                        "model": model,
                        "input_tokens": input_tokens,
                        "output_tokens": output_tokens,
                        "status": "error",
                    }
                    _build_and_enqueue(self._context, response_data, elapsed_ms)
            except Exception:
                pass
            raise  # User's exception from stream close

        # THIRD: record the event (never raises)
        try:
            if self._context:
                response_data = {
                    "provider": "anthropic",
                    "model": model,
                    "input_tokens": input_tokens,
                    "output_tokens": output_tokens,
                    "status": status,
                }
                _build_and_enqueue(self._context, response_data, elapsed_ms)
        except Exception:
            pass

        return result

    def __getattr__(self, name):
        return getattr(self._manager, name)


def wrap_async_stream_manager(result, context, start_time, kwargs):
    """Wrap an async Anthropic .stream() context manager."""
    return _WrappedAsyncStreamManager(result, context, start_time, kwargs)
