"""Auto-patching logic for each provider SDK."""

import importlib

from . import _config
from ._wrapper import make_sync_wrapper, make_async_wrapper, make_stream_wrapper

# Track originals so we can unpatch in tests
_originals = {}


def _patch_target(module_path, class_name, method_name, wrapper_factory, provider_mod, is_async=False):
    """Patch a single method on a class.

    Returns True if patched, False if skipped.
    """
    try:
        module = importlib.import_module(module_path)
    except (ImportError, ModuleNotFoundError):
        return False

    cls = getattr(module, class_name, None)
    if cls is None:
        return False

    original = getattr(cls, method_name, None)
    if original is None:
        return False

    # Don't double-patch
    key = f"{module_path}.{class_name}.{method_name}"
    if key in _originals:
        return True

    _originals[key] = (cls, method_name, original)

    if is_async:
        wrapped = make_async_wrapper(
            original,
            provider_mod.parse_response.__code__.co_consts[1]  # skip this, use provider name
            if False else provider_mod.SYNC_TARGET[0].split(".")[0],
            provider_mod.parse_response,
            provider_mod.wrap_async_stream,
        )
    else:
        wrapped = make_sync_wrapper(
            original,
            provider_mod.SYNC_TARGET[0].split(".")[0],
            provider_mod.parse_response,
            provider_mod.wrap_stream,
        )

    setattr(cls, method_name, wrapped)
    return True


def _patch_method(module_path, class_name, method_name, make_wrapped_fn):
    """Patch a single method using a custom wrapper factory.

    Like _patch_target but accepts a callable(original) -> wrapped
    instead of relying on the is_async branch.  Includes double-patch guard.
    Returns True if patched, False if skipped.
    """
    try:
        module = importlib.import_module(module_path)
    except (ImportError, ModuleNotFoundError):
        return False

    cls = getattr(module, class_name, None)
    if cls is None:
        return False

    original = getattr(cls, method_name, None)
    if original is None:
        return False

    key = f"{module_path}.{class_name}.{method_name}"
    if key in _originals:
        return True

    _originals[key] = (cls, method_name, original)
    setattr(cls, method_name, make_wrapped_fn(original))
    return True


def patch_openai(debug=False):
    """Discover and patch OpenAI SDK."""
    try:
        from ._providers import _openai as oai

        sync_ok = _patch_target(
            *oai.SYNC_TARGET,
            wrapper_factory=make_sync_wrapper,
            provider_mod=oai,
            is_async=False,
        )
        async_ok = _patch_target(
            *oai.ASYNC_TARGET,
            wrapper_factory=make_async_wrapper,
            provider_mod=oai,
            is_async=True,
        )

        if (sync_ok or async_ok) and debug:
            version = _get_version("openai")
            modes = []
            if sync_ok:
                modes.append("sync")
            if async_ok:
                modes.append("async")
            print(f"[llmtracer] \u2713 Patched openai ({version}) \u2014 {' + '.join(modes)}")

    except Exception as e:
        if debug:
            print(f"[llmtracer] Could not patch openai: {e}")


def patch_anthropic(debug=False):
    """Discover and patch Anthropic SDK."""
    try:
        from ._providers import _anthropic as anth

        provider = "anthropic"

        sync_ok = _patch_target(
            *anth.SYNC_TARGET,
            wrapper_factory=make_sync_wrapper,
            provider_mod=anth,
            is_async=False,
        )
        async_ok = _patch_target(
            *anth.ASYNC_TARGET,
            wrapper_factory=make_async_wrapper,
            provider_mod=anth,
            is_async=True,
        )

        # Patch .stream() context-manager methods
        sync_stream_ok = _patch_method(
            *anth.SYNC_STREAM_TARGET,
            make_wrapped_fn=lambda orig: make_stream_wrapper(
                orig, provider, anth.parse_response, anth.wrap_stream_manager,
            ),
        )
        async_stream_ok = _patch_method(
            *anth.ASYNC_STREAM_TARGET,
            make_wrapped_fn=lambda orig: make_stream_wrapper(
                orig, provider, anth.parse_response, anth.wrap_async_stream_manager,
            ),
        )

        patched_any = sync_ok or async_ok or sync_stream_ok or async_stream_ok
        if patched_any and debug:
            version = _get_version("anthropic")
            modes = []
            if sync_ok:
                modes.append("sync")
            if async_ok:
                modes.append("async")
            if sync_stream_ok:
                modes.append("sync-stream")
            if async_stream_ok:
                modes.append("async-stream")
            print(f"[llmtracer] \u2713 Patched anthropic ({version}) \u2014 {' + '.join(modes)}")

    except Exception as e:
        if debug:
            print(f"[llmtracer] Could not patch anthropic: {e}")


def unpatch_all():
    """Restore all original methods. Used in tests."""
    for key, (cls, method_name, original) in _originals.items():
        setattr(cls, method_name, original)
    _originals.clear()


def _get_version(package):
    """Get installed package version."""
    try:
        mod = importlib.import_module(package)
        return getattr(mod, "__version__", "?")
    except Exception:
        return "?"


def patch_google(debug=False):
    """Discover and patch Google Generative AI SDK."""
    try:
        from ._providers import _google as goog

        sync_ok = _patch_target(
            *goog.SYNC_TARGET,
            wrapper_factory=make_sync_wrapper,
            provider_mod=goog,
            is_async=False,
        )
        async_ok = _patch_target(
            *goog.ASYNC_TARGET,
            wrapper_factory=make_async_wrapper,
            provider_mod=goog,
            is_async=True,
        )

        if (sync_ok or async_ok) and debug:
            version = _get_version("google.generativeai")
            modes = []
            if sync_ok:
                modes.append("sync")
            if async_ok:
                modes.append("async")
            print(f"[llmtracer] \u2713 Patched google-genai ({version}) \u2014 {' + '.join(modes)}")

    except Exception as e:
        if debug:
            print(f"[llmtracer] Could not patch google-genai: {e}")
