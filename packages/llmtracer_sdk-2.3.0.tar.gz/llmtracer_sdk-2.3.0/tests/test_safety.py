"""Tests that the SDK never breaks the user's application.

These tests verify the two core principles:
1. NEVER BREAK THE USER'S APPLICATION
2. SIMPLE INSTALLATION (silent by default)
"""

import asyncio
import sys
import types
from unittest import mock

import pytest


# ── Helpers ───────────────────────────────────────────────────────────────────

class _FakeUsage:
    def __init__(self, input_tokens=200, output_tokens=80):
        self.input_tokens = input_tokens
        self.output_tokens = output_tokens


class _FakeResponse:
    def __init__(self, model="gpt-4o"):
        self.model = model
        self.usage = _FakeUsage()


def _install_fake_openai():
    openai_mod = types.ModuleType("openai")
    openai_mod.__version__ = "1.51.0"
    resources_mod = types.ModuleType("openai.resources")
    chat_mod = types.ModuleType("openai.resources.chat")
    completions_mod = types.ModuleType("openai.resources.chat.completions")

    class Completions:
        @staticmethod
        def create(*args, **kwargs):
            return _FakeResponse(model=kwargs.get("model", "gpt-4o"))

    class AsyncCompletions:
        @staticmethod
        async def create(*args, **kwargs):
            return _FakeResponse(model=kwargs.get("model", "gpt-4o"))

    completions_mod.Completions = Completions
    completions_mod.AsyncCompletions = AsyncCompletions
    chat_mod.completions = completions_mod
    resources_mod.chat = chat_mod
    openai_mod.resources = resources_mod

    sys.modules["openai"] = openai_mod
    sys.modules["openai.resources"] = resources_mod
    sys.modules["openai.resources.chat"] = chat_mod
    sys.modules["openai.resources.chat.completions"] = completions_mod
    return Completions, AsyncCompletions


def _cleanup():
    for key in list(sys.modules):
        if key.startswith("openai") or key.startswith("anthropic"):
            del sys.modules[key]


@pytest.fixture(autouse=True)
def _reset_state():
    import llmtracer
    from llmtracer import _config, _patcher, _transport

    _config.api_key = ""
    _config.debug = False
    _config.enabled = False
    _config.session_id = ""
    _config.endpoint = "https://us-central1-llmtracer-alt.cloudfunctions.net/v1Events"

    _transport._reset()
    from llmtracer._transport import enqueue as _orig
    _transport.enqueue = _orig

    _patcher.unpatch_all()
    _cleanup()

    yield

    _config.enabled = False
    _transport._reset()
    _transport.enqueue = _orig
    _patcher.unpatch_all()
    _cleanup()


# ── Test 1: init with no key is silent ────────────────────────────────────────

def test_init_no_key_is_silent(capsys):
    """init() with no API key prints nothing."""
    import llmtracer
    llmtracer.init()
    captured = capsys.readouterr()
    assert captured.out == ""
    assert captured.err == ""


# ── Test 2: init with empty string key is silent ─────────────────────────────

def test_init_empty_key_is_silent(capsys):
    """init(api_key='') prints nothing."""
    import llmtracer
    llmtracer.init(api_key="")
    captured = capsys.readouterr()
    assert captured.out == ""


# ── Test 3: Patched method returns same result as original ────────────────────

def test_patched_create_returns_identical_result():
    """Wrapper returns the exact same object as the original."""
    Completions, _ = _install_fake_openai()

    import llmtracer
    from llmtracer import _transport
    _transport.enqueue = lambda e: None

    llmtracer.init(api_key="lt_test")

    result = Completions.create(model="gpt-4o", messages=[])
    assert isinstance(result, _FakeResponse)
    assert result.model == "gpt-4o"


# ── Test 4: Patched method propagates same exceptions ─────────────────────────

def test_patched_create_propagates_user_exceptions():
    """User exceptions propagate with identical type and message."""
    _install_fake_openai()

    import llmtracer
    from llmtracer import _transport, _patcher
    _transport.enqueue = lambda e: None

    llmtracer.init(api_key="lt_test")

    # Make the original raise a specific error
    class FakeAPIError(Exception):
        pass

    from openai.resources.chat.completions import Completions
    key = "openai.resources.chat.completions.Completions.create"
    if key in _patcher._originals:
        cls, method_name, _ = _patcher._originals[key]

        def failing_create(*args, **kwargs):
            raise FakeAPIError("rate limit exceeded")

        _patcher._originals[key] = (cls, method_name, failing_create)
        from llmtracer._providers import _openai
        from llmtracer._wrapper import make_sync_wrapper
        wrapped = make_sync_wrapper(failing_create, "openai", _openai.parse_response, _openai.wrap_stream)
        setattr(cls, method_name, wrapped)

    with pytest.raises(FakeAPIError, match="rate limit exceeded"):
        Completions.create(model="gpt-4o", messages=[])


# ── Test 5: SDK extraction failure doesn't affect user ────────────────────────

def test_extraction_failure_doesnt_raise():
    """If parse_response raises, user still gets their result."""
    from llmtracer import _config, _wrapper, _transport

    _config.enabled = True
    _config.api_key = "lt_test"

    events = []
    _transport.enqueue = lambda e: events.append(e)

    call_log = []

    def original_fn(*args, **kwargs):
        call_log.append("called")
        return _FakeResponse()

    def bad_parse(result):
        raise RuntimeError("parse exploded")

    wrapped = _wrapper.make_sync_wrapper(original_fn, "test", bad_parse, lambda *a: None)
    result = wrapped(model="test-model")

    assert result.model == "gpt-4o"
    assert len(call_log) == 1
    # Should NOT raise — AND should record a partial event
    assert len(events) == 1
    assert events[0]["model"] == "test-model"
    assert events[0]["input_tokens"] == 0
    assert events[0]["output_tokens"] == 0


# ── Test 6: Stream __aexit__ always closes the stream ─────────────────────────

@pytest.mark.asyncio
async def test_stream_aexit_always_closes_even_on_sdk_error():
    """Underlying stream manager __aexit__ is called even if extraction fails."""
    from llmtracer._providers._anthropic import _WrappedAsyncStreamManager

    aexit_called = []

    class FakeStream:
        def get_final_message(self):
            raise RuntimeError("stream broke during extraction")

    class FakeManager:
        async def __aenter__(self):
            return FakeStream()

        async def __aexit__(self, *exc):
            aexit_called.append(True)
            return False

    from llmtracer import _config, _transport
    _config.enabled = True
    _config.api_key = "lt_test"
    _transport.enqueue = lambda e: None

    import time
    mgr = _WrappedAsyncStreamManager(
        FakeManager(), {"context": {}, "caller": {}}, time.monotonic(), {"model": "claude"}
    )
    mgr._stream = FakeStream()

    # __aexit__ should still close the underlying manager even when extraction fails
    await mgr.__aexit__(None, None, None)
    assert len(aexit_called) == 1


# ── Test 7: Network failure during flush doesn't raise ────────────────────────

def test_flush_network_failure_is_silent():
    """ConnectionError during flush is silently swallowed."""
    from llmtracer import _transport, _config
    _config.api_key = "lt_test"

    _transport.enqueue({"test": "event"})

    with mock.patch("urllib.request.urlopen", side_effect=ConnectionError("refused")):
        _transport.flush()  # Must not raise

    # Events should be dropped
    assert _transport._event_queue.empty()


# ── Test 8: debug=False produces zero output ──────────────────────────────────

def test_debug_false_is_completely_silent(capsys):
    """With debug=False, the entire SDK produces zero stdout output."""
    Completions, _ = _install_fake_openai()

    import llmtracer
    from llmtracer import _transport
    _transport.enqueue = lambda e: None

    llmtracer.init(api_key="lt_test", debug=False)

    # Clear any init output
    capsys.readouterr()

    Completions.create(model="gpt-4o", messages=[])

    captured = capsys.readouterr()
    assert captured.out == ""


# ── Test 9: debug=True produces output ────────────────────────────────────────

def test_debug_true_shows_patching(capsys):
    """With debug=True, init() prints patching info."""
    _install_fake_openai()

    import llmtracer
    llmtracer.init(api_key="lt_test", debug=True)

    captured = capsys.readouterr()
    assert "[llmtracer]" in captured.out
    assert "Patched" in captured.out


# ── Test 10: Partial events recorded on extraction failure ────────────────────

def test_partial_event_on_extraction_failure():
    """When parse_response fails, a partial event (model from kwargs, 0 tokens) is recorded."""
    from llmtracer import _config, _wrapper, _transport

    _config.enabled = True
    _config.api_key = "lt_test"

    events = []
    _transport.enqueue = lambda e: events.append(e)

    def original_fn(*args, **kwargs):
        return _FakeResponse()

    def exploding_parse(result):
        raise ValueError("can't parse this")

    wrapped = _wrapper.make_sync_wrapper(original_fn, "anthropic", exploding_parse, lambda *a: None)
    result = wrapped(model="claude-sonnet-4-5-20250929")

    # User gets their result
    assert result is not None

    # Partial event was recorded
    assert len(events) == 1
    assert events[0]["provider"] == "anthropic"
    assert events[0]["model"] == "claude-sonnet-4-5-20250929"
    assert events[0]["input_tokens"] == 0
    assert events[0]["output_tokens"] == 0
    assert events[0]["status"] == "ok"
    assert events[0]["latency_ms"] >= 0


# ── Test 11: Error event recorded when user's call fails ──────────────────────

def test_error_event_recorded_on_user_exception():
    """When the original function raises, we record a partial error event."""
    from llmtracer import _config, _wrapper, _transport

    _config.enabled = True
    _config.api_key = "lt_test"

    events = []
    _transport.enqueue = lambda e: events.append(e)

    def failing_fn(*args, **kwargs):
        raise RuntimeError("API is down")

    wrapped = _wrapper.make_sync_wrapper(failing_fn, "openai", lambda r: {}, lambda *a: None)

    with pytest.raises(RuntimeError, match="API is down"):
        wrapped(model="gpt-4o")

    # Error event should still be recorded
    assert len(events) == 1
    assert events[0]["model"] == "gpt-4o"
    assert events[0]["status"] == "error"


# ── Test 12: Async error event recorded ───────────────────────────────────────

@pytest.mark.asyncio
async def test_async_error_event_recorded():
    """Async wrapper records error event when original raises."""
    from llmtracer import _config, _wrapper, _transport

    _config.enabled = True
    _config.api_key = "lt_test"

    events = []
    _transport.enqueue = lambda e: events.append(e)

    async def failing_fn(*args, **kwargs):
        raise RuntimeError("timeout")

    wrapped = _wrapper.make_async_wrapper(failing_fn, "anthropic", lambda r: {}, lambda *a: None)

    with pytest.raises(RuntimeError, match="timeout"):
        await wrapped(model="claude-sonnet-4-5-20250929")

    assert len(events) == 1
    assert events[0]["status"] == "error"
    assert events[0]["model"] == "claude-sonnet-4-5-20250929"


# ── Test 13: Disabled mode is zero-overhead passthrough ───────────────────────

def test_disabled_mode_passthrough():
    """When disabled, wrapper adds zero overhead — direct passthrough."""
    from llmtracer import _config, _wrapper, _transport

    _config.enabled = False

    events = []
    _transport.enqueue = lambda e: events.append(e)

    sentinel = object()

    def original_fn(*args, **kwargs):
        return sentinel

    wrapped = _wrapper.make_sync_wrapper(original_fn, "test", lambda r: {}, lambda *a: None)
    result = wrapped(model="test")

    assert result is sentinel
    assert len(events) == 0


# ── Test 14: Queue full drops silently ────────────────────────────────────────

def test_queue_full_drops_silently(capsys):
    """When queue is full, enqueue drops silently (no exception, no output)."""
    from llmtracer import _transport, _config

    _config.debug = False

    # Fill the queue
    for i in range(_transport._MAX_QUEUE_SIZE):
        _transport.enqueue({"i": i})

    # This should not raise
    _transport.enqueue({"overflow": True})

    captured = capsys.readouterr()
    assert captured.out == ""


# ── Test 15: Stream __exit__ ordering — cleanup before recording ──────────────

def test_sync_stream_exit_closes_underlying_first():
    """__exit__ closes the underlying stream even if SDK recording would fail."""
    from llmtracer._providers._openai import _WrappedStream
    from llmtracer import _config, _transport

    _config.enabled = True
    _config.api_key = "lt_test"
    _transport.enqueue = lambda e: None

    exit_called = []

    class FakeStream:
        def __exit__(self, *exc):
            exit_called.append(True)
            return False

    stream = _WrappedStream(
        FakeStream(), {"context": {}, "caller": {}}, 0, {"model": "gpt-4o"}
    )

    stream.__exit__(None, None, None)
    assert len(exit_called) == 1
