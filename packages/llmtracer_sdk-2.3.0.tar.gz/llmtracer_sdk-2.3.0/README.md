# LLM Tracer — Python SDK

Track cost, latency, and token usage across OpenAI, Anthropic, and Google Gemini — in one line of code.

![version](https://img.shields.io/badge/version-2.0.8-blue)

## Install

```bash
pip install llmtracer-sdk
```

## Quick Start

```python
import llmtracer

llmtracer.init(api_key="lt_...")

# That's it. All OpenAI, Anthropic, and Google Gemini calls are now tracked automatically.
```

No wrappers, no callbacks, no code changes. The SDK auto-patches your provider clients at import time.

View your dashboard at [llmtracer.dev](https://llmtracer.dev).

## What Gets Captured

Every LLM call is automatically tracked with:

- **Provider, model, tokens** (input + output), latency, cost
- **Google Gemini**: thinking tokens (2.5 models), tool tokens, cached tokens
- **Anthropic**: cache creation + read tokens
- **OpenAI**: reasoning tokens (o1/o3/o4), cached tokens
- **Caller file, function, and line number**
- **Auto-flush on process exit** (no manual flush needed)

## Environment Variable Pattern

```python
import os
import llmtracer

llmtracer.init(
    api_key=os.environ["LLMTRACER_API_KEY"],
    debug=True,  # prints token counts to console
)
```

## Trace Context and Tags

```python
with llmtracer.trace(tags={"feature": "chat", "user_id": "u_sarah"}):
    response = client.chat.completions.create(...)
```

Tags appear in the dashboard's Breakdown page and Top Tags card. Use them to answer questions like "which user costs the most?" or "which feature should I optimize?"

### Tagging Patterns

| Pattern | Tag | Example |
|---------|-----|---------|
| Track cost by feature | `feature` | `"chat"`, `"search"`, `"summarize"` |
| Track cost by user | `user_id` | `"u_sarah"`, `"u_mike"` |
| Track cost by customer (B2B) | `customer` | `"acme-corp"`, `"initech"` |
| Track cost by conversation | `conversation_id` | `"conv_abc123"` |
| Track environment | `env` | `"production"`, `"staging"` |

## Supported Providers

| Provider | Package | Auto-patched |
|----------|---------|-------------|
| OpenAI | `openai` | ✅ |
| Anthropic | `anthropic` | ✅ |
| Google Gemini | `google-genai` | ✅ |

## LangChain Support

If you use LangChain with `ChatOpenAI`, `ChatAnthropic`, or `ChatGoogleGenerativeAI`, the underlying SDK calls are auto-captured. No callback handler needed — just `llmtracer.init()` and you're done.

## Debug Mode

Enable `debug=True` to print token counts to the console:

```python
llmtracer.init(api_key="lt_...", debug=True)
```

```
[llmtracer] openai gpt-4o | 1,247 in → 384 out | $0.0094 | 1.2s
[llmtracer] anthropic claude-sonnet-4-5 | 2,100 in → 512 out (cache_read: 1,800) | $0.0031 | 0.8s
[llmtracer] google gemini-2.5-pro | 900 in → 280 out (thinking: 1,420) | $0.0067 | 2.1s
```

## Requirements

- Python 3.8+
- Works with any version of `openai`, `anthropic`, or `google-genai` SDKs

## Zero Dependencies

The core SDK uses only Python stdlib (`urllib.request`, `threading`, `hashlib`).

## License

MIT
