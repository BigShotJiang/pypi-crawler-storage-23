# Antaris Suite v4.2.0

Agent infrastructure for intelligent, secure, and memory-persistent AI systems.

**v4.2.0** — Memory export/import • GCS backend stub • Hard budget enforcement • Pipeline telemetry

## Packages

| Package | PyPI Version | Description |
|---------|-------------|-------------|
| `antaris-memory` | 4.2.0 | Persistent memory with BM25 search, WAL, sharding, export/import, GCS backend stub |
| `antaris-router` | 4.0.1 | Intelligent model routing with cost tracking, confidence gating, A/B testing |
| `antaris-guard` | 4.0.1 | Prompt injection detection (pattern library v1.2.0), reputation tracking, rate limiting |
| `antaris-context` | 4.2.0 | Context compression, hard budget enforcement, summarization, relevance scoring |
| `antaris-pipeline` | 4.2.0 | Agent orchestration pipeline with per-stage telemetry and OpenClaw bridge |
| `antaris-contracts` | 4.0.0 | Versioned state schemas, failure semantics, and debug CLI |
| `antaris-openclaw-plugin` | 4.0.3 | OpenClaw plugin — auto-recall, auto-ingest, Discord bridge, compaction recovery |

## Architecture

```
antaris-openclaw-plugin   (lifecycle hooks — auto-recall + auto-ingest)
        │
antaris-pipeline          (orchestration)
   ┌────┴────────────────────┐
antaris-memory         antaris-router      antaris-guard      antaris-context
(persistence)          (model selection)   (security)         (compression)
```

## Design Principles

- **Zero external dependencies** on all core Python packages — stdlib only
- **File-based persistence** — no database required
- **Multi-process safe** — cross-platform `FileLock` using `os.mkdir()` atomicity
- **Fully portable** — no hardcoded paths, works on any machine
- **Fully tested** — 1,508 tests + 50-check QA runner with automated git hooks

## Installation

```bash
# Install the full suite
pip install antaris-suite==4.2.0

# Or install individual packages
pip install antaris-memory antaris-guard antaris-router antaris-context antaris-pipeline
```

For **OpenClaw plugin** installation, see [`antaris-openclaw-plugin/INSTALL.md`](antaris-openclaw-plugin/INSTALL.md).

## Quality Gates

Every push is gated by:
- **Pre-commit hook** — blocks hardcoded paths (`/Users/`, `/home/`) and `require()` in ESM
- **Pre-push hook** — runs `qa_runner.py` (50 checks across 4 layers), blocks push on failure
- **QA Runner** — `python3 qa_runner.py` (portability, compliance, benchmarks, bridge integration)

Set up hooks after cloning: `bash scripts/install-hooks.sh`

## What's New in 4.2

### antaris-memory — Export/Import + GCS Backend Stub
- **`MemorySystem.export(output_path)`** — Serialize all memories to a single portable JSON snapshot. Returns count of exported entries.
- **`MemorySystem.import_from(input_path, merge=True)`** — Import a snapshot into any workspace with content-hash deduplication. Returns count of newly added entries.
- **`GCSMemoryBackend`** — Google Cloud Storage backend interface fully defined and importable (`from antaris_memory.backends.gcs import GCSMemoryBackend`). Full cloud persistence ships in v4.3.

### antaris-context — Hard Budget Enforcement
- **`ContextManager.render_hard_limited(budget_tokens)`** — Strict token ceiling: trims context to fit, raises `ContextBudgetExceeded` if the budget cannot be satisfied. Guarantees the returned messages never exceed the specified limit.

### antaris-pipeline — Pipeline Telemetry
- **`PipelineTelemetry`** dataclass attached to every pipeline run with per-stage timing (`stages: dict[str, float]`), total elapsed time, and token count.
- **`telemetry.summary()`** — One-line performance report: `"Pipeline: 145ms total | recall=12ms guard=5ms llm=120ms | 342 tokens"`.
- **`telemetry.slowest_stage()`** → `(stage_name, ms)` — Instantly identify pipeline bottlenecks.

### antaris-router / antaris-guard
- No functional changes in 4.2. Fully compatible with the 4.2.0 suite.

## Changelog

### v4.2.0 (2026-02-26) — Current
- **antaris-memory 4.2.0**: `MemorySystem.export()` / `import_from()` with JSON snapshot and content-hash deduplication; GCS backend stub (`antaris_memory.backends.gcs`)
- **antaris-context 4.2.0**: `render_hard_limited(budget_tokens)` — strict token ceiling with `ContextBudgetExceeded` exception
- **antaris-pipeline 4.2.0**: `PipelineTelemetry` dataclass with `summary()` and `slowest_stage()` for per-run performance introspection
- antaris-router 4.0.1, antaris-guard 4.0.1 — no changes, compatible with 4.2.0 suite

### v4.0.4 (2026-02-24)
- **Guard TPR 20% → 100%** — pattern library v1.2.0 with ~15 new patterns (DAN, ChatML, jailbreak variants, system prompt injection, harmful content, guideline bypass)
- **Guard FPR 0%** — zero false positives on clean business language
- **Full portability audit** — removed all hardcoded machine paths, ESM compatibility, `__file__`-relative bridge paths
- **QA runner built** — 4-layer automated test suite (portability, compliance, benchmarks, bridge integration)
- **Git hooks** — pre-commit (path check) + pre-push (QA gate) enforced on all pushes
- **INSTALL.md** — complete plugin installation guide with troubleshooting
- **50/50 QA score (100%)**

### v4.0.3 (2026-02-24)
- Bridge `sys.path` now `__file__`-relative + `ANTARIS_PYTHON` env var support
- Warning log when `workspacePath` not configured
- `antaris-suite` PyPI dependency pins corrected from stale v3.x → v4.x

### v4.0.2 (2026-02-24)
- Fixed hardcoded `/Users/moro` path in plugin
- Fixed `require()` in ESM module
- Fixed `message_in` → `message_received` hook name
- Fixed stale `api.pluginConfig` reference

### v4.0.1 (2026-02-24)
- `antaris-pipeline` 4.0.1: 8 bridge patches for v4.0.0 API compatibility
- `antaris-router` 4.0.1: minor fixes
- `antaris-guard` 4.0.1: pattern library v1.2.0

### v4.0.0 (2026-02-23)
- **Major version bump** — all 6 packages at v4.0.0
- Component-based architecture (`MemorySystem`, `PromptGuard`, `ContextManager`, `AdaptiveRouter`)
- Bridge NDJSON protocol (stdin/stdout)
- `kind: memory` plugin declaration for OpenClaw memory slot
- `discordChannels` config for selective message ingestion
- Recovery presets (smart/minimal) for post-compaction context restoration

### v3.1.0 (2026-02-21)
- Discord message bridge (auto-ingestion via `message_in` hook)
- Compaction hook fixes (5s timeout + 30s watchdog)
- All 6 modules consolidated under single canonical repo
- 1,508 tests passing

### v3.0.0 (2026-02-20)
- Suite 3.0 launch — all 6 packages on PyPI
- 4 external reviews passed (Claude Opus, GPT-5.2, Gemini, Shiro)
- READMEs fully rewritten, docs + website updated
- 61,030× faster than mem0 (verified benchmarks)

### v2.0.0 (2026-02-18)
- Suite 2.0 — 835 tests, 3 external security reviews
- OpenClaw plugin first install
- Website + docs infrastructure live

## License

MIT
