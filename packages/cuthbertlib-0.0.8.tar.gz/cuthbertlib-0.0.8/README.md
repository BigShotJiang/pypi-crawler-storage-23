# `cuthbertlib`: Atomic modules for `cuthbert`

A collection of atomic, smaller-scoped tools useful for state-space model inference.
This package contains the building blocks that power the main `cuthbert` package.

For more information, including installation and contributing guidelines, see the
main `cuthbert` [README](https://github.com/state-space-models/cuthbert).
