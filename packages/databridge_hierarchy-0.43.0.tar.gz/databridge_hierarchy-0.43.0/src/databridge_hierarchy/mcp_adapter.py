"""Package-backed MCP adapter for hierarchy tools."""

from src.hierarchy.mcp_impl import register_hierarchy_tools

__all__ = ["register_hierarchy_tools"]
