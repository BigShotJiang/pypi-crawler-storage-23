"""Shim for legacy `pip install -e .` and `python setup.py` invocations."""

from setuptools import setup

setup()
