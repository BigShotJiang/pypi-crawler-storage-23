# purpleflea

Python SDK for the [Purple Flea](https://purpleflea.com) Casino & Trading APIs.

## Installation

```bash
pip install purpleflea
```

## Quick Start

### Casino

```python
from purpleflea import CasinoClient

casino = CasinoClient("your-api-key")

# Register a new account
casino.register("alice", "alice@example.com")

# Deposit funds
casino.deposit(100.0, currency="USD")

# List available games
games = casino.list_games()

# Play a round
result = casino.play("slots-classic", bet_amount=5.0)

# Check balance & withdraw
balance = casino.get_balance()
casino.withdraw(50.0)

# Referrals
casino.create_referral()
casino.redeem_referral("REF123")

casino.close()
```

### Trading

```python
from purpleflea import TradingClient

trading = TradingClient("your-api-key")

# Register a new account
trading.register("bob", "bob@example.com")

# Browse markets
markets = trading.list_markets()
btc = trading.get_market("BTC-USD")
book = trading.get_orderbook("BTC-USD")

# Open a long position
pos = trading.open_position("BTC-USD", side="long", size=0.5)

# Check position and close
details = trading.get_position(pos["position_id"])
trading.close_position(pos["position_id"])

# Referrals
trading.create_referral()
trading.redeem_referral("TREF1")

trading.close()
```

### Context Manager

Both clients support context managers for automatic cleanup:

```python
from purpleflea import CasinoClient

with CasinoClient("your-api-key") as casino:
    casino.deposit(50.0)
    result = casino.play("roulette", bet_amount=10.0)
```

### Custom Base URL

```python
from purpleflea import CasinoClient

casino = CasinoClient("your-api-key", base_url="https://staging.api.purpleflea.com")
```

### Error Handling

```python
from purpleflea import CasinoClient, APIError

try:
    with CasinoClient("your-api-key") as casino:
        casino.play("invalid-game", bet_amount=10.0)
except APIError as e:
    print(f"API error {e.status_code}: {e.message}")
```

## API Reference

### `CasinoClient(api_key, base_url=None, timeout=30.0)`

Casino API routes use the `/api/v1/` prefix.

| Method | Description |
|---|---|
| `register(username, email)` | Register a new player |
| `get_account()` | Get account details |
| `deposit(amount, currency="USD")` | Deposit funds |
| `withdraw(amount, currency="USD")` | Withdraw funds |
| `get_balance()` | Get wallet balance |
| `list_games()` | List available games |
| `get_game(game_id)` | Get game details |
| `play(game_id, bet_amount)` | Play a round |
| `get_game_history()` | Get past results |
| `create_referral()` | Generate referral code |
| `list_referrals()` | List referrals |
| `redeem_referral(code)` | Redeem a referral code |

### `TradingClient(api_key, base_url=None, timeout=30.0)`

Trading API routes use the `/v1/` prefix.

| Method | Description |
|---|---|
| `register(username, email)` | Register a new trader |
| `get_account()` | Get account details |
| `list_markets()` | List available markets |
| `get_market(market_id)` | Get market details |
| `get_orderbook(market_id)` | Get order book |
| `open_position(market_id, side, size)` | Open a position |
| `close_position(position_id)` | Close a position |
| `get_position(position_id)` | Get position details |
| `list_positions()` | List open positions |
| `create_referral()` | Generate referral code |
| `list_referrals()` | List referrals |
| `redeem_referral(code)` | Redeem a referral code |

## Development

```bash
git clone https://github.com/Purple-flea/python-sdk.git
cd python-sdk
pip install -e ".[dev]"
pytest
```

## License

MIT
