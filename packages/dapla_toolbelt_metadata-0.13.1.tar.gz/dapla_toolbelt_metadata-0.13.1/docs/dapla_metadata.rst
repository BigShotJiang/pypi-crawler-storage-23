dapla\_metadata package
=======================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   dapla_metadata.dapla
   dapla_metadata.datasets
   dapla_metadata.standards
   dapla_metadata.variable_definitions
