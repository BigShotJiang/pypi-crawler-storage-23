dapla\_metadata.datasets package
================================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   dapla_metadata.datasets.compatibility
   dapla_metadata.datasets.external_sources
   dapla_metadata.datasets.utility


dapla\_metadata.datasets.code\_list module
------------------------------------------

.. automodule:: dapla_metadata.datasets.code_list
   :members:
   :show-inheritance:
   :undoc-members:

dapla\_metadata.datasets.core module
------------------------------------

.. automodule:: dapla_metadata.datasets.core
   :members:
   :show-inheritance:
   :undoc-members:

dapla\_metadata.datasets.dapla\_dataset\_path\_info module
----------------------------------------------------------

.. automodule:: dapla_metadata.datasets.dapla_dataset_path_info
   :members:
   :show-inheritance:
   :undoc-members:

dapla\_metadata.datasets.dataset\_parser module
-----------------------------------------------

.. automodule:: dapla_metadata.datasets.dataset_parser
   :members:
   :show-inheritance:
   :undoc-members:

dapla\_metadata.datasets.model\_validation module
-------------------------------------------------

.. automodule:: dapla_metadata.datasets.model_validation
   :members:
   :show-inheritance:
   :undoc-members:

dapla\_metadata.datasets.statistic\_subject\_mapping module
-----------------------------------------------------------

.. automodule:: dapla_metadata.datasets.statistic_subject_mapping
   :members:
   :show-inheritance:
   :undoc-members:
