"""Abstract parent class for interacting with external resources asynchorously."""
