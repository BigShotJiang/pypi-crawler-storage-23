<div align="center">

# nf-docs

**Generate beautiful API documentation for Nextflow pipelines**

[![Python 3.10+](https://img.shields.io/badge/python-3.10+-blue.svg)](https://www.python.org/downloads/)
[![License](https://img.shields.io/badge/license-Apache%202.0-green.svg)](LICENSE)

![nf-docs demo](docs/images/demo.gif)

**[Full documentation →](https://ewels.github.io/nf-docs)**

Choose from 3 different output formats:

</div>

<table width="100%">
<tr>
<td width="33%">
<h3 align="center">HTML</h3>
<ul><li>Single-file output</li><li>Share anywhere, even offline</li><li>Full-text search built in</li></ul><hr>
</td>
<td width="33%">
<h3 align="center">Markdown</h3>
<ul><li>Multiple files by section</li><li>Perfect for static site generators</li></ul><hr>
</td>
<td width="33%">
<h3 align="center">JSON / YAML</h3>
<ul><li>Machine-readable output</li><li>Build custom integrations</li><li>CI/CD friendly</li></ul><hr>
</td>
</tr>
</table>

## What is nf-docs?

<!-- prettier-ignore-start -->
> [!INFO]
> This is not an official Nextflow project. It's a fun side-project by
> [Phil Ewels](https://github.com/ewels). Please use at your own risk :)
<!-- prettier-ignore-end -->

Information is pulled from multiple sources to construct the docs (each only if available):

- **README.md** - Pipeline overview and description
- **nextflow.config** - Runtime configuration defaults
- **nextflow_schema.json** - Typed input parameters with descriptions and validation rules
- **Language Server** - Processes, workflows, functions with their Groovydoc comments
- **meta.yml** - nf-core module metadata (tools, keywords, authors)

The documentation for workflows, processes and functions is relatively unique. `nf-docs` extracts
this from your Nextflow pipelines by querying the
[Nextflow Language Server](https://github.com/nextflow-io/language-server). It produces structured
API documentation similar to Sphinx for Python or Javadoc for Java.

## Examples and docs

See https://ewels.github.io/nf-docs

## Quick Start

With [`uv`](https://docs.astral.sh/uv/):

```bash
uvx nf-docs generate ./my_pipeline
```

With `pip`:

```bash
# Install
pip install nf-docs

# Generate HTML documentation
nf-docs generate ./my_pipeline
```

That's it! Open `docs/index.html` in your browser.

## Development

See [CONTRIBUTING.md](CONTRIBUTING.md) for development setup, testing, and contribution guidelines.

## License

Apache 2.0 - see [LICENSE](LICENSE) for details.
