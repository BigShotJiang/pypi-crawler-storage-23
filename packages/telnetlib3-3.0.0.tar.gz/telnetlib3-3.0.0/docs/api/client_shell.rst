client_shell
------------

.. automodule:: telnetlib3.client_shell
   :members:
