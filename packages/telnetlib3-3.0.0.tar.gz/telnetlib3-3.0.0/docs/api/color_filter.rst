color_filter
------------

.. automodule:: telnetlib3.color_filter
   :members:
   :undoc-members:
   :show-inheritance:
