server_pty_shell
----------------

.. automodule:: telnetlib3.server_pty_shell
   :members:

