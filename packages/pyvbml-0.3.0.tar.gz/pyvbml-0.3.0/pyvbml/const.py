"""Constants."""

from __future__ import annotations

from typing import Final

DIMENSIONS_FLAGSHIP: Final[tuple[int, int]] = (6, 22)
DIMENSIONS_NOTE: Final[tuple[int, int]] = (3, 15)
