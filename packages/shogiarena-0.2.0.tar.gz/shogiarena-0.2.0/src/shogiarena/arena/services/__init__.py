"""Service layer segmented by concern: artifacts, persistence, statistics, game control."""
