"""Tournament scheduling algorithms."""
