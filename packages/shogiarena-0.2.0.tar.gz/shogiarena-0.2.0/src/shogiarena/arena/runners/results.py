from __future__ import annotations

from shogiarena.arena.results import SpsaRunResult, TournamentRunResult

__all__ = ["TournamentRunResult", "SpsaRunResult"]
