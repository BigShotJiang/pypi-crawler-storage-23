"""Configuration error types."""


class ConfigError(ValueError):
    """Raised when configuration validation fails."""
