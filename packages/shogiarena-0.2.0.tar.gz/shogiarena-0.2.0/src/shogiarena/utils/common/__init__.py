"""共通ユーティリティ

ログ、プロジェクトディレクトリ、定数など、共通機能のサブモジュールを提供します。

推奨インポート:
- `from shogiarena.utils.common.project_dirs import ...`
- `from shogiarena.utils.common.logging import ...`
"""

# Intentionally avoid wildcard re-exports to keep API explicit.
__all__: list[str] = []
