# Instances 設定ガイド

このディレクトリはインスタンス設定のテンプレート置き場です。
設計方針や挙動の詳細は次を参照してください。

- 設計方針: `docs/technical/instances.md`
- サンプル: `configs/resources/instances/example.yaml`
