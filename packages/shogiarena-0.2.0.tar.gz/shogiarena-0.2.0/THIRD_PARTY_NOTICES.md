# Third-party notices

This project is licensed under the MIT License (see `LICENSE`).

ShogiArena depends on third-party libraries that may have different licenses.

## rshogi-py-avx2

- Project: `rshogi` (`https://github.com/nyoki-mtl/rshogi`)
- License: MIT

## Other dependencies

For a complete list of dependencies, refer to:

- `pyproject.toml` (Python dependencies)
- `package.json` (JavaScript dependencies)
