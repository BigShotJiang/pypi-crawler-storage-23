# リポジトリ運用ガイドライン

- 内部思考は英語で、ユーザーとの対話は日本語で行うこと。

## 実行環境
- pythonはuvで管理されています。そのため"uv run ..."などでスクリプトを実行し、ライブラリ追加は"uv add ... (--dev)"で行ってください。

## プロジェクト構成とモジュール整理
- コアパッケージ: `src/shogiarena/`
  - `arena/`: トーナメント関連のロジック（エンジン、ランナー、オーケストレータ、スケジューラ、サービス）。
  - `web/dashboard/`: ライブダッシュボード用 API サーバと静的アセット。
  - `utils/`, `shogidb/`: 各種ヘルパーと DB ユーティリティ。
- 参考リソース: `_refs/`（ベンダリング済みの例・ツール。変更禁止）。
- テスト配置: `tests/{unit,property,integration}/` のいずれかに配置すること。
- 実行チェックは現在、`.sandbox`以下で行う。すなわち設定ファイルは`.sandbox/configs/`以下、実行時出力は`.sandbox/work_dir/`以下。
- エントリポイント: CLI `shogiarena`（例: `shogiarena run tournament`）。

## ビルド・テスト・開発コマンド
- 全テスト実行: `make test` カバレッジ付きは `make test-cov`
- 品質チェック: `make format`（ruff format）、`make lint`（ruff check --fix）、`make typecheck`（ty）。
- 一括チェック: `make check`（format, lint, typecheck, test を順に実行）。

## リポジトリ運用とブランチ戦略

### 2リポジトリ構成
```
ShogiArena-dev (private) ← 開発用リポジトリ
  └─ dev ブランチ: 日常開発（履歴は残す）
  └─ main ブランチ: 安定版（publicと同期）
  └─ CI/CD: lint, test, typecheck (dev, main 両方)

ShogiArena (public) ← 公開リポジトリ
  └─ main ブランチ: 公開版
  └─ CI/CD: lint, test, typecheck (main のみ)
  └─ GitHub Pages: ドキュメント自動デプロイ
```

### Gitワークフロー

**基本原則: dev → main の一方向フロー（private） / public へは export で公開**

#### develop リポジトリに `main` を残す理由

- `dev`: 日常開発（履歴は残す）
- `main`: リリース前の安定版（**public に出す“固定点”**）

public は dev-only を含められないため、公開は `develop/main`（private の stable 点）を起点に export する運用にします（`develop/dev` から直接 export しない）。

1. **日常開発**
   ```bash
   git checkout dev
   # ... 開発作業 ...
   git commit -m "feat: something"
   git push develop dev  # private リポジトリへ
   ```

2. **公開リリース準備**
   ```bash
   git checkout main
   git merge dev --squash  # 履歴をまとめる
   git commit -m "Release vX.Y.Z"
   git push develop main
   ```

3. **公開リポジトリへ export（dev-only を除外して 1コミットで公開）**

   public には開発用ファイルを含めないため、`dev/main` をそのまま push せず、`public/main` の上に「公開用スナップショットコミット」を作ります。

   ```bash
   # 最新化
   git fetch develop public

   # 公開用ブランチを public/main から作る
   git checkout -B export-public public/main

   # private main の内容をワークツリーへ展開
   git checkout develop/main -- .

   # dev-only を削除（publicに出さない）
   git rm -r --ignore-unmatch agent-docs .claude _refs .sandbox .serena
   git rm --ignore-unmatch AGENTS.md CLAUDE.md GEMINI.md

   # 公開スナップショットを作成
   git commit -m "Release vX.Y.Z

   - <ユーザー向けの変更点を箇条書きで記載（2〜6行程度）>
   "

   # public へ公開（public/main はリリースコミットのみが積まれる）
   git push public HEAD:main
   ```

   **コミットメッセージ規約（export-public）**

   - **目的**: public の履歴は「ユーザー向けの変更点」が一目で分かることを優先する
   - **書く**: 2〜6 行のユーザー向け変更点（箇条書き）
   - **書かない**: `Excluded: ...` のような運用メモ / dev-only 削除の羅列

   **テンプレ**

   ```text
   Release vX.Y.Z

   - <ユーザー向けの変更点 1>
   - <ユーザー向けの変更点 2>
   - <必要なら 3〜6>
   ```

   **例（v0.1.1）**

   ```text
   Release v0.1.1

   - Bump package version to 0.1.1
   - Fix CLI --version to reflect package version
   - Update changelog for v0.1.1
   - Docs: point development guide to contributing workflow
   ```

4. **GitHub Release 作成**
   ```bash
   git tag -a vX.Y.Z -m "Release version X.Y.Z"
   git push public vX.Y.Z
   gh release create vX.Y.Z --title "vX.Y.Z" --notes "..."
   ```

5. **PyPI へ publish**

   `.env` の `PYPI_TOKEN` を使います。

   ```bash
   uv build
   UV_PUBLISH_TOKEN="$PYPI_TOKEN" uv publish dist/*
   ```

### 除外ファイル（publicに含めない）

- `agent-docs/` - エージェント用タスク管理
- `AGENTS.md`, `CLAUDE.md`, `GEMINI.md` - エージェント設定
- `_refs/` - 参照コード
- `.sandbox/` - 開発用サンドボックス
- `.serena/`, `.claude/` - AI開発ツール

これらは `.gitignore` または選択的コピーで除外される。

### リモート設定

```bash
develop → https://github.com/nyoki-mtl/ShogiArena-dev.git (private)
public → https://github.com/nyoki-mtl/ShogiArena.git (public)
```

### CI/CD 動作

- **Private (develop)**: dev/main への push で実行
- **Public**: main への push と PR で実行
- **GitHub Pages**: public の main への push で自動デプロイ

## コミット
- コミットメッセージは Conventional Commits を採用する（例: `feat:`, `fix:`, `docs:`, `refactor:`, `test:`, `chore:`）。例: `fix: repair import paths in arena runners`。
- **必ず dev ブランチで開発し、main にマージする**。main で直接開発しない。

## エラーハンドリング:
  - 安易な try/except を避け、例外は握りつぶさない。
  - `except Exception: pass` のような握り潰しは禁止。必要なら特定の例外型で捕捉し、適切にログ出力して再送出または明示的な失敗を返す。
  - フォールバックやサイレントリトライで場当たり的に対応しない。まず根本原因の修正を優先。
  - まだ開発版なのでAPI仕様などはどんどん変更している。後方互換性は作らずに常にクリーンなコードに。
