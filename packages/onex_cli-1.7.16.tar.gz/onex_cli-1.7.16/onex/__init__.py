# OneXEOS Services CLI
__version__ = "1.7.16"
