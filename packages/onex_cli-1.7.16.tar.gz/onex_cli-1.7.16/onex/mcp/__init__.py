"""
OneX MCP Server

Model Context Protocol server for OneXEOS Platform CLI tools.
Allows AI assistants like Claude to directly investigate issues,
check platform health, view logs, trace requests, and manage services.
"""

from onex import __version__
