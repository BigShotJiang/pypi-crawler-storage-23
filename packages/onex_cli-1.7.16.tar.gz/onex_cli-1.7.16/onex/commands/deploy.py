"""
Deploy command - Deploy service to OneXEOS Platform
"""

import click
import requests
import json
from pathlib import Path
from onex.config import get_config, get_access_token, get_active_environment
from onex.utils import (
    load_service_yml,
    create_service_bundle,
    validate_service_structure,
    validate_service_schema,
    validate_bundle_compilation,
    format_size,
    print_success,
    print_error,
    print_info,
    print_warning,
    monitor_deployment_progress,
    format_progress_message,
)


@click.command()
@click.option('--env', default=None, help='Environment (local/dev/staging/prod, defaults to active)')
@click.option('--platform-url', help='Override platform URL')
@click.option('--service-dir', type=click.Path(exists=True), default='.', help='Service directory path')
def deploy(env, platform_url, service_dir):
    """Deploy service to OneXEOS Platform"""

    # Use active environment if not specified
    if env is None:
        env = get_active_environment()
        print_info(f"Using active environment: {env}")

    # Environment display names
    env_names = {
        'local': 'Local Laptop',
        'dev': 'Dev VPS',
        'staging': 'Staging VPS',
        'prod': 'Production VPS'
    }

    service_path = Path(service_dir).resolve()

    click.echo(f"🚀 Deploying service from {service_path}")
    click.echo()

    # Step 1: Validate service structure
    click.echo("📋 Validating service structure...")
    errors = validate_service_structure(service_path)
    if errors:
        print_error("Service validation failed:")
        for error in errors:
            click.echo(f"  - {error}")
        return

    print_success("Service structure valid")

    # Step 2: Validate service.yml schema
    click.echo("\n📋 Validating service configuration...")
    is_valid, schema_errors, warnings = validate_service_schema(service_path)

    if not is_valid:
        print_error("Service configuration validation failed:")
        for error in schema_errors:
            click.echo(f"  ❌ {error}")
        click.echo()
        print_info("Fix the errors above and try again")
        print_info("See: docs/SERVICE_YML_SPECIFICATION.md")
        return

    # Display warnings (non-fatal)
    if warnings:
        for warning in warnings:
            print_warning(warning)

    print_success("Service configuration valid")

    # Step 3: Load service configuration
    try:
        config = load_service_yml(service_path)
        service_name = config['name']  # Updated to use 'name' instead of 'service'
        version = config.get('version', '1.0.0')
        isolated = config.get('isolated', False)

        click.echo(f"\n📦 Service: {service_name}")
        click.echo(f"   Version: {version}")
        click.echo(f"   Mode: {'Isolated' if isolated else 'Shared runtime'}")
        click.echo(f"   Environment: {env_names.get(env, env)}")

    except Exception as e:
        print_error(f"Failed to load service.yml: {e}")
        return

    # Step 4: Create service bundle
    click.echo("\n📦 Creating service bundle...")
    try:
        bundle_path = create_service_bundle(
            service_path,
            Path('/tmp'),
            exclude=['__pycache__', '*.pyc', '.git', 'tests', '*.log', '.DS_Store']
            # NOTE: .env is NOT excluded - it must be bundled with service code
            # Service-specific env vars (JWT_SECRET_KEY, etc.) are loaded by shared runtime
        )
        bundle_size = bundle_path.stat().st_size
        print_success(f"Created {bundle_path.name} ({format_size(bundle_size)})")
    except Exception as e:
        print_error(f"Failed to create bundle: {e}")
        return

    # Step 4.5: Validate bundle compilation (NEW - Pre-deployment validation)
    click.echo("\n🔍 Validating Python imports and syntax...")
    try:
        validation_errors = validate_bundle_compilation(bundle_path, service_path)
        if validation_errors:
            print_error("Bundle validation failed:")
            for error in validation_errors[:10]:  # Show first 10 errors
                click.echo(f"  ❌ {error}")

            if len(validation_errors) > 10:
                click.echo(f"  ... and {len(validation_errors) - 10} more errors")

            click.echo()
            print_info("Fix the errors above and try again")
            print_info("Common fixes:")
            click.echo("  - Ensure shared libs are in repository root: libs/python/helpers/")
            click.echo("  - Check for typos in import statements")
            click.echo("  - Verify Python syntax is correct")

            # Cleanup bundle
            bundle_path.unlink()
            return

        print_success("All imports and syntax validated successfully")
    except Exception as e:
        # Compilation check is best-effort - don't fail deployment if it errors
        print_warning(f"Compilation validation skipped: {e}")

    # Step 5: Get platform URL and JWT token
    cli_config = get_config()
    platform_base_url = platform_url or cli_config.get_platform_url(env)

    # Use JWT token from onex login (already imported at top)
    access_token = get_access_token(env)

    # Skip authentication check for local environment
    if not access_token and env != "local":
        print_error(f"Not authenticated for environment: {env}")
        print_info(f"Please login first: onex login --env {env}")
        return

    if env == "local" and not access_token:
        print_info("Local environment - skipping authentication")

    click.echo(f"\n🔗 Connecting to platform: {platform_base_url}")

    # Step 6: Health check
    try:
        health_response = requests.get(f"{platform_base_url}/health", timeout=5)
        if health_response.status_code == 200:
            print_success("Platform healthy")
        else:
            print_error(f"Platform unhealthy: {health_response.status_code}")
            return
    except requests.exceptions.RequestException as e:
        print_error(f"Cannot connect to platform: {e}")
        print_info(f"Make sure platform is running at {platform_base_url}")
        return

    # Step 7: Deploy to platform (async mode with progress monitoring)
    click.echo("\n🚀 Deploying to platform...")

    try:
        with open(bundle_path, 'rb') as f:
            files = {
                'service_zip': (bundle_path.name, f, 'application/zip')
            }

            data = {
                'service_name': service_name,
                'isolated': str(isolated).lower(),
                'config': json.dumps(config),
                'environment': env,
                'async_mode': '1'  # Enable async deployment (FastAPI converts '1' to True)
            }

            # Only add Authorization header if we have an access token
            headers = {}
            if access_token:
                headers['Authorization'] = f'Bearer {access_token}'

            deploy_url = f"{platform_base_url}/_internal/deploy"
            response = requests.post(
                deploy_url,
                files=files,
                data=data,
                headers=headers,
                timeout=30  # Just for initial request
            )

        if response.status_code == 200:
            initial_response = response.json()
            deployment_id = initial_response.get('deployment_id')

            if not deployment_id:
                print_error("Deployment started but no deployment_id returned")
                return

            click.echo()

            # Monitor deployment progress
            last_progress = -1
            final_result = None
            deployment_failed = False

            for progress_data in monitor_deployment_progress(platform_base_url, deployment_id, access_token):
                # Check for errors
                if progress_data.get('error'):
                    print_error(f"Deployment error: {progress_data['error']}")
                    deployment_failed = True
                    break

                # Display progress (only if changed)
                current_progress = progress_data.get('progress_pct', 0)
                if current_progress != last_progress:
                    progress_msg = format_progress_message(progress_data)
                    # Use \r to overwrite the same line
                    click.echo(f"\r{progress_msg}", nl=False)
                    last_progress = current_progress

                # Check if completed
                if progress_data.get('completed'):
                    click.echo()  # New line after progress

                    if progress_data.get('result'):
                        final_result = progress_data['result']
                    elif progress_data.get('failed'):
                        deployment_failed = True

                    break

            # Display final result
            if deployment_failed:
                print_error("Deployment failed!")
                return

            if not final_result:
                print_error("Deployment completed but no result returned")
                return

            print_success("Deployment successful!")

            click.echo()
            click.echo("📊 Deployment Summary:")
            click.echo(f"   Service: {final_result.get('service')}")
            click.echo(f"   Version: {final_result.get('version', 'N/A')}")
            click.echo(f"   Status: {final_result.get('status')}")
            click.echo(f"   Mode: {final_result.get('mode')}")
            click.echo(f"   Duration: {final_result.get('duration_ms', 0)}ms")
            click.echo(f"   Deployment ID: {deployment_id}")

            # Display timeline breakdown
            if 'timeline' in final_result and final_result['timeline']:
                click.echo("\n⏱️  Deployment Timeline:")
                for phase in final_result['timeline']:
                    phase_name = phase.get('name', 'Unknown')
                    duration = phase.get('duration_ms', 0)
                    status = phase.get('status', 'unknown')

                    # Status icon
                    status_icon = "✅" if status == "success" else ("⏭️" if status == "skipped" else ("⚠️" if status == "warning" else "❌"))

                    # Format duration
                    if duration < 1000:
                        duration_str = f"{duration}ms"
                    else:
                        duration_str = f"{duration/1000:.2f}s"

                    click.echo(f"   {status_icon} {phase_name:30} {duration_str:>8}")

            # HTTP Routes
            if 'routes' in final_result and final_result['routes']:
                click.echo(f"\n🔗 HTTP Routes ({len(final_result['routes'])}):")
                for route in final_result['routes']:
                    method = route.get('method', 'GET')
                    path = route.get('path', '')
                    click.echo(f"   {method:6} {path}")

            # Invoke Handlers
            if 'invokes' in final_result and final_result['invokes']:
                click.echo(f"\n⚡ Invoke Handlers ({len(final_result['invokes'])}):")
                for invoke in final_result['invokes'][:5]:  # Show first 5
                    name = invoke.get('name', 'N/A')
                    summary = invoke.get('docs', {}).get('summary', '')
                    click.echo(f"   invoke:{service_name}:{name}")
                    if summary:
                        click.echo(f"      └─ {summary}")
                if len(final_result['invokes']) > 5:
                    click.echo(f"   ... and {len(final_result['invokes']) - 5} more")

            # Get endpoint summary if available
            endpoints_summary = final_result.get('endpoints_summary', {})

            # Schedule Triggers
            schedule_triggers = endpoints_summary.get('schedule_triggers', [])
            if schedule_triggers:
                click.echo(f"\n⏰ Schedule Triggers ({len(schedule_triggers)}):")
                for schedule in schedule_triggers:
                    func = schedule.get('function', 'N/A')
                    cron = schedule.get('cron', 'N/A')
                    desc = schedule.get('description', '')
                    click.echo(f"   {func} → {cron}")
                    if desc:
                        click.echo(f"      └─ {desc}")

            # Event Triggers
            event_triggers = endpoints_summary.get('event_triggers', [])
            if event_triggers:
                click.echo(f"\n📨 Event Triggers ({len(event_triggers)}):")
                for event in event_triggers:
                    func = event.get('function', 'N/A')
                    event_type = event.get('event_type', 'N/A')
                    desc = event.get('description', '')
                    click.echo(f"   {func} → {event_type}")
                    if desc:
                        click.echo(f"      └─ {desc}")

            # Stream Triggers
            stream_triggers = endpoints_summary.get('stream_triggers', [])
            if stream_triggers:
                click.echo(f"\n🌊 Stream Triggers ({len(stream_triggers)}):")
                for stream in stream_triggers:
                    func = stream.get('function', 'N/A')
                    collection = stream.get('collection', 'N/A')
                    operations = stream.get('operations', [])
                    ops_str = ', '.join(operations) if operations else 'N/A'
                    desc = stream.get('description', '')
                    click.echo(f"   {func} → {collection} ({ops_str})")
                    if desc:
                        click.echo(f"      └─ {desc}")

            # Total endpoints
            total_endpoints = endpoints_summary.get('total_endpoints', 0)
            if total_endpoints:
                click.echo(f"\n📋 Total Endpoints: {total_endpoints}")

            if isolated:
                click.echo(f"\n🐳 Container: {final_result.get('container_name', 'N/A')}")
                click.echo(f"   Replicas: {final_result.get('replicas', 1)}")

            click.echo()
            print_info(f"Test your service: curl {platform_base_url}/...")
            click.echo()
            click.echo(f"💡 Troubleshooting:")
            click.echo(f"   Diagnose deployment: ./scripts/diagnose-deployment.sh {service_name} {deployment_id}")
            click.echo(f"   View service status: onex status {service_name} --env {env}")

        else:
            print_error(f"Deployment failed: {response.status_code}")

            if response.status_code == 401:
                print_error("Authentication failed - Invalid or expired token")
                print_info(f"Try logging in again: onex login --env {env}")
            elif response.status_code == 403:
                try:
                    error_detail = response.json()
                    click.echo(f"   Error: {error_detail.get('detail', 'Forbidden')}")
                    if "environment mismatch" in error_detail.get('detail', '').lower():
                        print_info("You're trying to deploy to the wrong environment")
                        print_info("Make sure platform and service environments match")
                except:
                    click.echo("   Error: Forbidden")
            else:
                try:
                    error_detail = response.json()
                    click.echo(f"   Error: {error_detail.get('detail', 'Unknown error')}")
                except:
                    click.echo(f"   Response: {response.text}")

    except requests.exceptions.Timeout:
        print_error("Deployment request timeout")
        print_info("Check platform logs: docker logs deployment-controller")

    except Exception as e:
        print_error(f"Deployment failed: {e}")

    finally:
        # Cleanup bundle
        if bundle_path.exists():
            bundle_path.unlink()
