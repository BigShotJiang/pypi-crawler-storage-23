"""Test-Agent 单元测试。"""

import pytest
import tempfile
import shutil
import json
from pathlib import Path

import sys
sys.path.insert(0, str(Path(__file__).parent.parent))

from src.core.project import ProjectManager
from src.core.agent import AgentManager
from src.core.isolation import DatabaseManager
from src.core.ipc import IPCManager
from src.utils.errors import (
    ValidationError,
    ProjectExistsError,
    ProjectNotFoundError,
    AgentExistsError,
    AgentNotFoundError
)


class TestProjectManager:
    """ProjectManager 测试类。"""
    
    @pytest.fixture
    def temp_dir(self):
        """创建临时目录。"""
        temp = tempfile.mkdtemp()
        yield temp
        shutil.rmtree(temp, ignore_errors=True)
    
    @pytest.fixture
    def pm(self, temp_dir):
        """创建ProjectManager实例。"""
        return ProjectManager(base_path=f"{temp_dir}/projects")
    
    def test_create_project(self, pm):
        """TC-PM-001: 创建测试项目。"""
        success, message = pm.create("test_project1", "Test Project 1")
        assert success is True
        assert "创建成功" in message
    
    def test_create_project_invalid_id(self, pm):
        """TC-PM-002: 创建项目 - 无效ID。"""
        with pytest.raises(ValidationError):
            pm.create("invalid_project", "Test")
    
    def test_create_duplicate_project(self, pm):
        """TC-PM-003: 创建重复项目。"""
        pm.create("test_project1", "Test Project 1")
        with pytest.raises(ProjectExistsError):
            pm.create("test_project1", "Test Project 1")
    
    def test_get_project(self, pm):
        """TC-PM-004: 获取项目配置。"""
        pm.create("test_project1", "Test Project 1")
        config = pm.get("test_project1")
        assert config["project_id"] == "test_project1"
        assert config["name"] == "Test Project 1"
    
    def test_get_nonexistent_project(self, pm):
        """TC-PM-005: 获取不存在的项目。"""
        with pytest.raises(ProjectNotFoundError):
            pm.get("test_nonexistent")
    
    def test_update_project(self, pm):
        """TC-PM-006: 更新项目配置。"""
        pm.create("test_project1", "Test Project 1")
        success, message = pm.update("test_project1", {"max_agents": 10})
        assert success is True
    
    def test_delete_project(self, pm):
        """TC-PM-007: 删除项目。"""
        pm.create("test_project1", "Test Project 1")
        success, message = pm.delete("test_project1")
        assert success is True
        
        with pytest.raises(ProjectNotFoundError):
            pm.get("test_project1")
    
    def test_list_projects(self, pm):
        """TC-PM-008: 列出所有项目。"""
        pm.create("test_project1", "Test Project 1")
        pm.create("test_project2", "Test Project 2")
        
        projects = pm.list_all()
        assert len(projects) == 2
    
    def test_add_agent_to_project(self, pm):
        """TC-PM-009: 添加Agent到项目。"""
        pm.create("test_project1", "Test Project 1")
        success, message = pm.add_agent("test_project1", "test_agent_001")
        assert success is True
    
    def test_remove_agent_from_project(self, pm):
        """TC-PM-010: 从项目移除Agent。"""
        pm.create("test_project1", "Test Project 1")
        pm.add_agent("test_project1", "test_agent_001")
        
        success, message = pm.remove_agent("test_project1", "test_agent_001")
        assert success is True


class TestAgentManager:
    """AgentManager 测试类。"""
    
    @pytest.fixture
    def temp_dir(self):
        """创建临时目录。"""
        temp = tempfile.mkdtemp()
        yield temp
        shutil.rmtree(temp, ignore_errors=True)
    
    @pytest.fixture
    def am(self, temp_dir):
        """创建AgentManager实例。"""
        return AgentManager(base_path=f"{temp_dir}/agents", max_workers=5)
    
    def test_register_agent(self, am):
        """TC-AM-001: 注册Agent。"""
        success, message = am.register("test_agent_001", {"name": "Agent 1"})
        assert success is True
        assert "注册成功" in message
    
    def test_register_agent_invalid_id(self, am):
        """TC-AM-002: 注册Agent - 无效ID。"""
        with pytest.raises(ValidationError):
            am.register("invalid_agent", {})
    
    def test_register_duplicate_agent(self, am):
        """TC-AM-003: 注册重复Agent。"""
        am.register("test_agent_001", {})
        with pytest.raises(AgentExistsError):
            am.register("test_agent_001", {})
    
    def test_get_agent_status(self, am):
        """TC-AM-004: 获取Agent状态。"""
        am.register("test_agent_001", {})
        status = am.get_status("test_agent_001")
        assert status == "idle"
    
    def test_get_nonexistent_agent(self, am):
        """TC-AM-005: 获取不存在的Agent。"""
        with pytest.raises(AgentNotFoundError):
            am.get_status("test_nonexistent")
    
    def test_unregister_agent(self, am):
        """TC-AM-006: 注销Agent。"""
        am.register("test_agent_001", {})
        success, message = am.unregister("test_agent_001")
        assert success is True
        
        with pytest.raises(AgentNotFoundError):
            am.get_status("test_agent_001")
    
    def test_list_agents(self, am):
        """TC-AM-007: 列出所有Agent。"""
        am.register("test_agent_001", {})
        am.register("test_agent_002", {})
        
        agents = am.list_all()
        assert len(agents) == 2
    
    def test_pool_status(self, am):
        """TC-AM-008: 进程池状态。"""
        status = am.get_pool_status()
        assert status["max_workers"] == 5
        assert status["running"] == 0
        assert status["available"] == 5
    
    def test_is_pool_available(self, am):
        """TC-AM-009: 检查进程池可用性。"""
        assert am.is_pool_available() is True
    
    def test_update_agent_status(self, am):
        """TC-AM-010: 更新Agent状态。"""
        am.register("test_agent_001", {})
        am.update_status("test_agent_001", "running", "test_project")
        
        agent = am.get("test_agent_001")
        assert agent["status"] == "running"
        assert agent["current_project"] == "test_project"


class TestDatabaseManager:
    """DatabaseManager 测试类 - 共享数据库方案。"""
    
    @pytest.fixture
    def temp_dir(self):
        """创建临时目录。"""
        temp = tempfile.mkdtemp()
        yield temp
        shutil.rmtree(temp, ignore_errors=True)
    
    @pytest.fixture
    def dm(self, temp_dir):
        """创建DatabaseManager实例。"""
        return DatabaseManager(base_path=temp_dir)
    
    def test_shared_database_path(self, dm):
        """TC-DB-001: 验证共享数据库路径。"""
        assert dm.db_path.name == "todos_test.db"
    
    def test_get_connection(self, dm):
        """TC-DB-002: 获取共享数据库连接。"""
        conn = dm.get_connection()
        assert conn is not None
    
    def test_init_schema(self, dm):
        """TC-DB-003: 初始化数据库Schema。"""
        dm.init_schema()
        conn = dm.get_connection()
        
        cursor = conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table'"
        )
        tables = [row[0] for row in cursor.fetchall()]
        assert "test_tasks" in tables
        assert "test_results" in tables
        assert "agent_heartbeats" in tables
    
    def test_create_task(self, dm):
        """TC-DB-004: 创建测试任务。"""
        dm.create_task("test_ns", "task_001", "test_project", "test_agent", "echo test")
        
        conn = dm.get_connection()
        cursor = conn.execute("SELECT * FROM test_tasks WHERE task_id = 'task_001'")
        task = cursor.fetchone()
        
        assert task is not None
        assert task["task_id"] == "task_001"
        assert task["namespace"] == "test_ns"
    
    def test_update_task_status(self, dm):
        """TC-DB-005: 更新任务状态。"""
        dm.create_task("test_ns", "task_001", "test_project", "test_agent", "echo test")
        dm.update_task_status("test_ns", "task_001", "running")
        
        status = dm.get_task_field("test_ns", "task_001", "status")
        assert status == "running"
    
    def test_get_tasks_by_namespace(self, dm):
        """TC-DB-006: 获取命名空间任务。"""
        dm.create_task("test_ns", "task_001", "test_project", "test_agent", "echo test")
        dm.create_task("test_ns", "task_002", "test_project", "test_agent", "echo test2")
        
        tasks = dm.get_tasks_by_namespace("test_ns")
        assert len(tasks) == 2
    
    def test_get_tasks_by_project(self, dm):
        """TC-DB-007: 获取项目任务。"""
        dm.create_task("test_ns", "task_001", "test_project", "test_agent", "echo test")
        dm.create_task("test_ns", "task_002", "test_project", "test_agent", "echo test2")
        
        tasks = dm.get_tasks_by_project("test_ns", "test_project")
        assert len(tasks) == 2
    
    def test_namespace_isolation(self, dm):
        """TC-DB-008: 验证命名空间隔离。"""
        dm.create_task("ns1", "task_1", "proj1", "agent1", "cmd1")
        dm.create_task("ns2", "task_2", "proj2", "agent2", "cmd2")
        
        ns1_tasks = dm.get_tasks_by_namespace("ns1")
        ns2_tasks = dm.get_tasks_by_namespace("ns2")
        
        assert len(ns1_tasks) == 1
        assert len(ns2_tasks) == 1
        assert ns1_tasks[0]["task_id"] == "task_1"
        assert ns2_tasks[0]["task_id"] == "task_2"
    
    def test_project_isolation(self, dm):
        """TC-DB-009: 验证项目数据隔离。"""
        dm.create_task("shared_ns", "task_1", "project1", "agent1", "cmd1")
        dm.create_task("shared_ns", "task_2", "project2", "agent2", "cmd2")
        
        proj1_tasks = dm.get_tasks_by_project("shared_ns", "project1")
        proj2_tasks = dm.get_tasks_by_project("shared_ns", "project2")
        
        assert len(proj1_tasks) == 1
        assert len(proj2_tasks) == 1
        assert proj1_tasks[0]["project_id"] == "project1"
        assert proj2_tasks[0]["project_id"] == "project2"
    
    def test_cleanup_namespace(self, dm):
        """TC-DB-010: 清理命名空间。"""
        dm.create_task("test_ns", "task_001", "test_project", "test_agent", "echo test")
        success = dm.cleanup_namespace("test_ns")
        
        assert success is True
        tasks = dm.get_tasks_by_namespace("test_ns")
        assert len(tasks) == 0
    
    def test_cleanup_project(self, dm):
        """TC-DB-011: 清理项目数据。"""
        dm.create_task("test_ns", "task_001", "test_project", "test_agent", "echo test")
        success = dm.cleanup_project("test_project")
        
        assert success is True
        tasks = dm.get_tasks_by_project("test_ns", "test_project")
        assert len(tasks) == 0
    
    def test_close_all(self, dm):
        """TC-DB-012: 关闭连接。"""
        dm.get_connection()
        dm.close_all()
        assert dm._connection is None


class TestIPCManager:
    """IPCManager 测试类。"""
    
    @pytest.fixture
    def ipc(self):
        """创建IPCManager实例。"""
        return IPCManager("test_namespace")
    
    def test_create_queue(self, ipc):
        """TC-IPC-001: 创建队列。"""
        queue = ipc.create_queue("test_queue")
        assert queue is not None
    
    def test_send_receive_message(self, ipc):
        """TC-IPC-002: 发送接收消息。"""
        ipc.create_queue("test_queue")
        
        message = {"data": "test"}
        success = ipc.send("test_queue", message)
        
        assert success is True
        
        received = ipc.receive("test_queue", timeout=1)
        assert received is not None
        assert received["message"]["data"] == "test"
    
    def test_broadcast(self, ipc):
        """TC-IPC-003: 广播消息。"""
        ipc.create_queue("queue1")
        ipc.create_queue("queue2")
        
        count = ipc.broadcast({"data": "broadcast"})
        assert count == 2
    
    def test_clear_queue(self, ipc):
        """TC-IPC-004: 清空队列。"""
        ipc.create_queue("test_queue")
        ipc.send("test_queue", {"data": "test"})
        
        ipc.clear_queue("test_queue")
        
        ipc.send("test_queue", {"data": "test2"})
        ipc.clear_queue("test_queue")
        
        received = ipc.receive("test_queue", timeout=0.1)
        assert received is None
    
    def test_close_queue(self, ipc):
        """TC-IPC-005: 关闭队列。"""
        ipc.create_queue("test_queue")
        ipc.close_queue("test_queue")
        
        queue = ipc.get_queue("test_queue")
        assert queue is None
    
    def test_list_queues(self, ipc):
        """TC-IPC-006: 列出所有队列。"""
        ipc.create_queue("queue1")
        ipc.create_queue("queue2")
        
        queues = ipc.list_queues()
        assert len(queues) == 2
        assert "queue1" in queues


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
