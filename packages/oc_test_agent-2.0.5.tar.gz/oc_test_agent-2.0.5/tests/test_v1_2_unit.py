"""Test-Agent v1.2 单元测试"""

import pytest
import sqlite3
import tempfile
import os
from pathlib import Path
from datetime import datetime
import json

# 设置测试环境
os.environ["TEST_ENV"] = "1"

from src.models.test_result import TestResult, TestStatus
from src.db.database import Database
from src.db.repositories.result_repo import ResultRepository


class TestDatabase:
    """测试数据库类"""
    
    @pytest.fixture
    def temp_db(self):
        """创建临时数据库"""
        with tempfile.NamedTemporaryFile(suffix='.db', delete=False) as f:
            db_path = f.name
        
        db = Database(db_path)
        db.init_schema()
        
        yield db
        
        db.close()
        os.unlink(db_path)
    
    def test_init_schema(self, temp_db):
        """测试数据库Schema初始化"""
        conn = temp_db.get_connection()
        cursor = conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table'"
        )
        tables = [row[0] for row in cursor.fetchall()]
        
        assert "test_results" in tables
        assert "test_dependencies" in tables
        assert "test_config" in tables
    
    def test_indexes(self, temp_db):
        """测试索引创建"""
        conn = temp_db.get_connection()
        cursor = conn.execute(
            "SELECT name FROM sqlite_master WHERE type='index'"
        )
        indexes = [row[0] for row in cursor.fetchall()]
        
        assert "idx_results_project" in indexes
        assert "idx_results_version" in indexes
        assert "idx_results_status" in indexes


class TestTestResultModel:
    """测试TestResult模型"""
    
    def test_to_dict(self):
        """测试模型转字典"""
        result = TestResult(
            id="test_001",
            project="test-project",
            version="v1.0.0",
            status=TestStatus.PASSED,
            test_type="unit",
            duration=10.5,
            passed=5,
            failed=0,
            errors=0,
            total=5,
            created_at=datetime.now()
        )
        
        data = result.to_dict()
        
        assert data["id"] == "test_001"
        assert data["project"] == "test-project"
        assert data["status"] == "passed"
        assert data["passed"] == 5
    
    def test_from_row(self):
        """测试从数据库行创建模型"""
        row = {
            "id": "test_001",
            "project": "test-project",
            "version": "v1.0.0",
            "test_type": "unit",
            "status": "passed",
            "duration": 10.5,
            "passed": 5,
            "failed": 0,
            "errors": 0,
            "total": 5,
            "report_path": None,
            "logs_path": None,
            "container_id": None,
            "created_at": "2026-02-21T10:00:00",
            "finished_at": None,
            "metadata": "{}"
        }
        
        result = TestResult.from_row(row)
        
        assert result.id == "test_001"
        assert result.status == TestStatus.PASSED
        assert result.passed == 5


class TestResultRepository:
    """测试ResultRepository"""
    
    @pytest.fixture
    def repo(self, temp_db):
        """创建仓库实例"""
        return ResultRepository(temp_db)
    
    @pytest.fixture
    def temp_db(self):
        """创建临时数据库"""
        with tempfile.NamedTemporaryFile(suffix='.db', delete=False) as f:
            db_path = f.name
        
        db = Database(db_path)
        db.init_schema()
        
        yield db
        
        db.close()
        os.unlink(db_path)
    
    def test_insert_and_find(self, repo):
        """测试插入和查询"""
        result = TestResult(
            id="test_001",
            project="test-project",
            version="v1.0.0",
            status=TestStatus.PASSED,
            created_at=datetime.now()
        )
        
        repo.insert(result)
        
        found = repo.find_by_id("test_001")
        
        assert found is not None
        assert found.id == "test_001"
        assert found.project == "test-project"
    
    def test_find_all(self, repo):
        """测试查询所有"""
        for i in range(5):
            result = TestResult(
                id=f"test_{i:03d}",
                project="test-project",
                version="v1.0.0",
                status=TestStatus.PASSED,
                created_at=datetime.now()
            )
            repo.insert(result)
        
        results = repo.find_all(project="test-project", limit=10)
        
        assert len(results) == 5
    
    def test_update_status(self, repo):
        """测试更新状态"""
        result = TestResult(
            id="test_001",
            project="test-project",
            version="v1.0.0",
            status=TestStatus.RUNNING,
            created_at=datetime.now()
        )
        repo.insert(result)
        
        repo.update_status("test_001", TestStatus.PASSED, duration=10.5, passed=5, total=5)
        
        updated = repo.find_by_id("test_001")
        
        assert updated.status == TestStatus.PASSED
        assert updated.duration == 10.5
        assert updated.passed == 5
    
    def test_delete(self, repo):
        """测试删除"""
        result = TestResult(
            id="test_001",
            project="test-project",
            version="v1.0.0",
            status=TestStatus.PASSED,
            created_at=datetime.now()
        )
        repo.insert(result)
        
        deleted = repo.delete("test_001")
        
        assert deleted is True
        
        found = repo.find_by_id("test_001")
        assert found is None
    
    def test_delete_before(self, repo):
        """测试删除指定日期之前的记录"""
        old_date = "2025-01-01"
        
        for i in range(3):
            result = TestResult(
                id=f"test_{i:03d}",
                project="test-project",
                version="v1.0.0",
                status=TestStatus.PASSED,
                created_at=datetime.now()
            )
            repo.insert(result)
        
        deleted = repo.delete_before(old_date, "test-project")
        
        # 当前日期的记录不会被删除
        assert deleted == 0


class TestDependencyService:
    """测试DependencyService"""
    
    def test_parse_dependencies(self):
        """测试解析依赖字符串"""
        from src.core.dependency_service import DependencyService
        
        svc = DependencyService()
        
        deps_string = "conf-man:/path/to/conf-man,pm-agent:/path/to/pm-agent:v1.0.0"
        deps = svc.parse_dependencies(deps_string)
        
        assert len(deps) == 2
        assert deps[0]["name"] == "conf-man"
        assert deps[0]["path"] == "/path/to/conf-man"
        assert deps[1]["name"] == "pm-agent"
        assert deps[1]["version"] == "v1.0.0"
    
    def test_parse_empty(self):
        """测试解析空字符串"""
        from src.core.dependency_service import DependencyService
        
        svc = DependencyService()
        
        deps = svc.parse_dependencies("")
        
        assert len(deps) == 0
    
    def test_resolve_version_explicit(self):
        """测试显式版本解析"""
        from src.core.dependency_service import DependencyService
        
        svc = DependencyService()
        
        dep = {"name": "test", "path": "/path", "version": "v1.0.0"}
        version = svc.resolve_version(dep)
        
        assert version == "v1.0.0"


class TestConfigService:
    """测试ConfigService"""
    
    def test_get_project_path(self):
        """测试获取项目路径"""
        from src.core.config_service import ConfigService
        
        # 使用不存在的配置目录
        svc = ConfigService("/nonexistent")
        
        path = svc.get_project_path("test-project")
        
        assert path is None


class TestReportService:
    """测试ReportService"""
    
    def test_generate_markdown(self):
        """测试生成Markdown报告"""
        from src.core.report_service import ReportService
        
        svc = ReportService()
        
        result = TestResult(
            id="test_001",
            project="test-project",
            version="v1.0.0",
            status=TestStatus.PASSED,
            duration=10.5,
            passed=5,
            failed=0,
            errors=0,
            total=5,
            created_at=datetime.now()
        )
        
        report = svc.generate(result, "markdown")
        
        assert "# 测试报告" in report
        assert "test-project" in report
        assert "passed" in report.lower()
    
    def test_generate_json(self):
        """测试生成JSON报告"""
        from src.core.report_service import ReportService
        
        svc = ReportService()
        
        result = TestResult(
            id="test_001",
            project="test-project",
            version="v1.0.0",
            status=TestStatus.PASSED,
            created_at=datetime.now()
        )
        
        report = svc.generate(result, "json")
        data = json.loads(report)
        
        assert data["id"] == "test_001"
        assert data["project"] == "test-project"


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
