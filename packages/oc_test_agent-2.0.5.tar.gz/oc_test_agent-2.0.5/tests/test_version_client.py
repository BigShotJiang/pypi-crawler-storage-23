"""Test-Agent version_client模块测试。"""

import pytest
import tempfile
import shutil
import yaml
import json
from pathlib import Path
from unittest.mock import Mock, patch, MagicMock

import sys
sys.path.insert(0, str(Path(__file__).parent.parent))

from src.core.version_client import VersionClient, AutoRegisterMixin
from src.models.test_report import TestReport, TestReportStatus, TestReportResult


class TestVersionClient:
    """VersionClient 测试类。"""
    
    @pytest.fixture
    def temp_dir(self):
        """创建临时目录。"""
        temp = tempfile.mkdtemp()
        yield temp
        shutil.rmtree(temp, ignore_errors=True)
    
    @pytest.fixture
    def test_report(self):
        """创建测试报告。"""
        return TestReport(
            version="v1.0.0",
            status=TestReportStatus.PASSED,
            timestamp="2026-01-01T00:00:00",
            results={"unit": TestReportResult(passed=10, failed=0, skipped=0, errors=0)},
            coverage=95,
            project="test-project"
        )
    
    @pytest.fixture
    def manifest_file(self, temp_dir):
        """创建清单文件。"""
        path = Path(temp_dir) / "manifest.yaml"
        data = {"name": "test-project", "version": "v1.0.0"}
        with open(path, 'w') as f:
            yaml.dump(data, f)
        return str(path)
    
    def test_init_default(self):
        """TC-VC-001: 默认初始化。"""
        client = VersionClient()
        assert client.conf_man_path == "conf-man"
    
    def test_init_custom_path(self):
        """TC-VC-002: 自定义路径初始化。"""
        client = VersionClient("/usr/local/bin/conf-man")
        assert client.conf_man_path == "/usr/local/bin/conf-man"
    
    @patch('subprocess.run')
    def test_register_success(self, mock_run, test_report, manifest_file):
        """TC-VC-010: 注册成功。"""
        mock_run.return_value = Mock(returncode=0, stdout="ok", stderr="")
        
        client = VersionClient()
        result = client.register("v1.0.0", manifest_file, test_report, "test-project")
        
        assert result is True
        assert mock_run.called
    
    @patch('subprocess.run')
    def test_register_failure(self, mock_run, test_report, manifest_file):
        """TC-VC-011: 注册失败。"""
        mock_run.return_value = Mock(returncode=1, stdout="", stderr="not found")
        
        client = VersionClient()
        result = client.register("v1.0.0", manifest_file, test_report, "test-project")
        
        assert result is False
    
    @patch('subprocess.run')
    def test_list_versions(self, mock_run):
        """TC-VC-012: 列出版本。"""
        mock_run.return_value = Mock(
            returncode=0,
            stdout=json.dumps([{"version": "v1.0.0"}, {"version": "v2.0.0"}]),
            stderr=""
        )
        
        client = VersionClient()
        versions = client.list_versions()
        
        assert len(versions) == 2
        assert versions[0]["version"] == "v1.0.0"
    
    @patch('subprocess.run')
    def test_show_version(self, mock_run):
        """TC-VC-013: 显示版本详情。"""
        mock_run.return_value = Mock(
            returncode=0,
            stdout=json.dumps({"version": "v1.0.0", "status": "registered"}),
            stderr=""
        )
        
        client = VersionClient()
        version = client.show_version("v1.0.0")
        
        assert version is not None
        assert version["version"] == "v1.0.0"
    
    @patch('subprocess.run')
    def test_release_version(self, mock_run):
        """TC-VC-014: 发布版本。"""
        mock_run.return_value = Mock(returncode=0, stdout="released", stderr="")
        
        client = VersionClient()
        result = client.release_version("v1.0.0")
        
        assert result is True
    
    @patch('subprocess.run')
    def test_get_dependencies(self, mock_run):
        """TC-VC-015: 获取依赖。"""
        mock_run.return_value = Mock(
            returncode=0,
            stdout=json.dumps({"dependencies": ["dep1", "dep2"]}),
            stderr=""
        )
        
        client = VersionClient()
        deps = client.get_dependencies("v1.0.0")
        
        assert deps == ["dep1", "dep2"]
    
    @patch('subprocess.run')
    def test_lock_dependencies(self, mock_run):
        """TC-VC-016: 锁定依赖。"""
        mock_run.return_value = Mock(returncode=0, stdout="locked", stderr="")
        
        client = VersionClient()
        result = client.lock_dependencies("v1.0.0")
        
        assert result is True
    
    def test_save_test_report(self, test_report):
        """TC-VC-020: 保存测试报告。"""
        client = VersionClient()
        path = client._save_test_report(test_report, "v1.0.0")
        
        assert Path(path).exists()
        assert path.endswith(".yaml")
        
        with open(path, 'r') as f:
            data = yaml.safe_load(f)
            assert data["version"] == "v1.0.0"
            assert data["status"] == "passed"
        
        Path(path).unlink()


class TestAutoRegisterMixin:
    """AutoRegisterMixin 测试类。"""
    
    @pytest.fixture
    def test_report(self):
        """创建测试报告。"""
        return TestReport(
            version="v1.0.0",
            status=TestReportStatus.PASSED,
            timestamp="2026-01-01T00:00:00",
            results={"unit": TestReportResult(passed=10, failed=0)},
            coverage=95
        )
    
    @patch('src.core.version_client.VersionClient.register')
    @patch('src.core.version_client.VersionClient.release_version')
    def test_auto_register_with_release(
        self, mock_release, mock_register, test_report
    ):
        """TC-VC-030: 自动注册并发布。"""
        mock_register.return_value = True
        mock_release.return_value = True
        
        class TestClass(AutoRegisterMixin):
            pass
        
        obj = TestClass()
        result = obj.auto_register_version(
            version="v1.0.0",
            manifest_path="/tmp/manifest.yaml",
            test_report=test_report,
            auto_release=True,
            project="test"
        )
        
        assert result is True
        assert mock_register.called
        assert mock_release.called
    
    @patch('src.core.version_client.VersionClient.register')
    def test_auto_register_without_release(self, mock_register, test_report):
        """TC-VC-031: 自动注册不发布。"""
        mock_register.return_value = True
        
        class TestClass(AutoRegisterMixin):
            pass
        
        obj = TestClass()
        result = obj.auto_register_version(
            version="v1.0.0",
            manifest_path="/tmp/manifest.yaml",
            test_report=test_report,
            auto_release=False
        )
        
        assert result is True
        assert mock_register.called
