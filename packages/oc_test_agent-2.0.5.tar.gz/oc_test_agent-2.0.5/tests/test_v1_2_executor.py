"""Test-Agent v1.2 测试执行器完整测试"""

import pytest
import tempfile
import os
from datetime import datetime
from unittest.mock import Mock, patch, MagicMock

os.environ["TEST_ENV"] = "1"

from src.models.test_result import TestResult, TestStatus
from src.db.database import Database


class TestTestExecutorPaths:
    """测试TestExecutor各个执行路径"""
    
    @pytest.fixture
    def temp_db(self):
        with tempfile.NamedTemporaryFile(suffix='.db', delete=False) as f:
            db_path = f.name
        
        db = Database(db_path)
        db.init_schema()
        
        yield db
        
        db.close()
        os.unlink(db_path)
    
    @patch('src.core.test_executor.DockerService')
    def test_execute_success(self, mock_docker, temp_db):
        """测试执行成功路径"""
        mock_ds = MagicMock()
        mock_ds.build_image.return_value = True
        mock_ds.run_container.return_value = "container123"
        mock_ds.wait_container.return_value = {
            "status_code": 0,
            "logs": "10 passed in 5s",
            "duration": 5.0
        }
        mock_docker.return_value = mock_ds
        
        from src.core.test_executor import TestExecutor
        
        executor = TestExecutor(
            project="test",
            version="v1.0",
            project_path="/tmp",
            timeout=60
        )
        executor.docker = mock_ds
        executor.db = temp_db
        from src.db.repositories.result_repo import ResultRepository
        executor.repo = ResultRepository(temp_db)
        
        result = executor.execute()
        
        assert result.status == TestStatus.PASSED
        assert result.passed == 10
    
    @patch('src.core.test_executor.DockerService')
    def test_execute_failed(self, mock_docker, temp_db):
        """测试执行失败路径"""
        mock_ds = MagicMock()
        mock_ds.build_image.return_value = True
        mock_ds.run_container.return_value = "container123"
        mock_ds.wait_container.return_value = {
            "status_code": 1,
            "logs": "5 passed, 3 failed",
            "duration": 10.0
        }
        mock_docker.return_value = mock_ds
        
        from src.core.test_executor import TestExecutor
        
        executor = TestExecutor(
            project="test",
            version="v1.0",
            project_path="/tmp",
            timeout=60
        )
        executor.docker = mock_ds
        executor.db = temp_db
        from src.db.repositories.result_repo import ResultRepository
        executor.repo = ResultRepository(temp_db)
        
        result = executor.execute()
        
        assert result.status == TestStatus.FAILED
    
    @patch('src.core.test_executor.DockerService')
    def test_execute_timeout(self, mock_docker, temp_db):
        """测试执行超时"""
        mock_ds = MagicMock()
        mock_ds.build_image.return_value = True
        mock_ds.run_container.return_value = "container123"
        mock_ds.wait_container.return_value = {
            "status_code": -1,
            "logs": "timeout",
            "duration": 60.0
        }
        mock_docker.return_value = mock_ds
        
        from src.core.test_executor import TestExecutor
        
        executor = TestExecutor(
            project="test",
            version="v1.0",
            project_path="/tmp",
            timeout=60
        )
        executor.docker = mock_ds
        executor.db = temp_db
        from src.db.repositories.result_repo import ResultRepository
        executor.repo = ResultRepository(temp_db)
        
        result = executor.execute()
        
        assert result.status == TestStatus.ERROR
    
    @patch('src.core.test_executor.DockerService')
    def test_execute_with_container(self, mock_docker, temp_db):
        """测试带容器取消"""
        mock_ds = MagicMock()
        mock_ds.build_image.return_value = True
        mock_ds.run_container.return_value = "container123"
        mock_ds.wait_container.return_value = {
            "status_code": 0,
            "logs": "5 passed",
            "duration": 5.0
        }
        mock_docker.return_value = mock_ds
        
        from src.core.test_executor import TestExecutor
        
        executor = TestExecutor(
            project="test",
            version="v1.0",
            project_path="/tmp",
            timeout=60
        )
        executor.docker = mock_ds
        executor.db = temp_db
        from src.db.repositories.result_repo import ResultRepository
        executor.repo = ResultRepository(temp_db)
        
        result = executor.execute()
        
        mock_ds.remove_container.assert_called_once()
    
    @patch('src.core.test_executor.DockerService')
    def test_cancel_with_container(self, mock_docker, temp_db):
        """测试取消正在运行的容器"""
        mock_ds = MagicMock()
        mock_ds.build_image.return_value = True
        mock_ds.run_container.return_value = "container123"
        mock_ds.wait_container.return_value = {
            "status_code": 0,
            "logs": "5 passed",
            "duration": 5.0
        }
        mock_docker.return_value = mock_ds
        
        from src.core.test_executor import TestExecutor
        
        executor = TestExecutor(
            project="test",
            version="v1.0",
            project_path="/tmp",
            timeout=60
        )
        executor.docker = mock_ds
        executor.db = temp_db
        from src.db.repositories.result_repo import ResultRepository
        executor.repo = ResultRepository(temp_db)
        
        executor.container_id = "container123"
        
        result = executor.cancel()
        
        assert result is True
        mock_ds.stop_container.assert_called_once()


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
