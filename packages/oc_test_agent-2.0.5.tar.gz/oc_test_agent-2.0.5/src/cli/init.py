import click
from pathlib import Path


@click.command()
def init():
    """初始化 test-agent 环境"""
    
    dirs = [
        "state",
        "test-reports",
        "test-logs",
        "config"
    ]
    
    for d in dirs:
        Path(d).mkdir(parents=True, exist_ok=True)
        click.echo(f"Created: {d}/")
    
    from ..db.database import Database
    db = Database.get_instance()
    db.init_schema()
    click.echo("Database initialized: state/test_results.db")
    
    click.echo("\nInitialized successfully!")
    click.echo("Please configure projects in config/projects.yaml")
