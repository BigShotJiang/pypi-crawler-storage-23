"""
Version Client for test-agent to interact with conf-man version management.
"""

import json
import subprocess
import logging
from pathlib import Path
from typing import Optional, List, Dict, Any
from datetime import datetime

from ..models.test_report import TestReport, TestReportStatus

logger = logging.getLogger(__name__)


class VersionClient:
    """Client for interacting with conf-man version management."""
    
    def __init__(self, conf_man_path: str = "conf-man"):
        """
        Initialize VersionClient.
        
        Args:
            conf_man_path: Path to conf-man CLI executable
        """
        self.conf_man_path = conf_man_path
    
    def _run_command(self, args: List[str], cwd: Optional[str] = None) -> tuple:
        """Run conf-man command and return (success, output, error)"""
        try:
            result = subprocess.run(
                [self.conf_man_path] + args,
                capture_output=True,
                text=True,
                cwd=cwd,
                timeout=30
            )
            return result.returncode == 0, result.stdout, result.stderr
        except FileNotFoundError:
            return False, "", f"conf-man not found at {self.conf_man_path}"
        except subprocess.TimeoutExpired:
            return False, "", "Command timed out"
        except Exception as e:
            return False, "", str(e)
    
    def register(
        self,
        version: str,
        manifest_path: str,
        test_report: TestReport,
        project: Optional[str] = None
    ) -> bool:
        """
        Register a version with conf-man.
        
        Args:
            version: Version string (e.g., "v2.4.0")
            manifest_path: Path to version manifest file
            test_report: TestReport object
            project: Optional project name
            
        Returns:
            True if registration succeeded
        """
        test_report_path = self._save_test_report(test_report, version)
        
        args = [
            "register",
            version,
            "--manifest", manifest_path,
            "--test-report", test_report_path
        ]
        
        if project:
            args.extend(["--project", project])
        
        success, stdout, stderr = self._run_command(args)
        
        if success:
            logger.info(f"Successfully registered version {version}")
        else:
            logger.error(f"Failed to register version {version}: {stderr}")
        
        return success
    
    def _save_test_report(self, test_report: TestReport, version: str) -> str:
        """Save test report to temporary file and return path"""
        import tempfile
        
        report_data = test_report.to_yaml_dict()
        
        fd, path = tempfile.mkstemp(suffix=".yaml", prefix="test_report_")
        with open(path, 'w') as f:
            import yaml
            yaml.dump(report_data, f, default_flow_style=False)
        
        logger.info(f"Test report saved to {path}")
        return path
    
    def list_versions(self) -> List[Dict[str, Any]]:
        """List all registered versions"""
        success, stdout, stderr = self._run_command(["list"])
        
        if not success:
            logger.error(f"Failed to list versions: {stderr}")
            return []
        
        try:
            return json.loads(stdout)
        except json.JSONDecodeError:
            return []
    
    def show_version(self, version: str) -> Optional[Dict[str, Any]]:
        """Get details of a specific version"""
        success, stdout, stderr = self._run_command(["show", version])
        
        if not success:
            logger.error(f"Failed to show version {version}: {stderr}")
            return None
        
        try:
            return json.loads(stdout)
        except json.JSONDecodeError:
            return None
    
    def release_version(self, version: str) -> bool:
        """Trigger release for a version"""
        success, stdout, stderr = self._run_command(["release", version])
        
        if success:
            logger.info(f"Successfully triggered release for {version}")
        else:
            logger.error(f"Failed to release version {version}: {stderr}")
        
        return success
    
    def get_dependencies(self, version: str) -> List[str]:
        """Get dependencies for a version"""
        success, stdout, stderr = self._run_command(["deps", version])
        
        if not success:
            return []
        
        try:
            data = json.loads(stdout)
            return data.get("dependencies", [])
        except json.JSONDecodeError:
            return []
    
    def lock_dependencies(self, version: str) -> bool:
        """Lock dependencies for a version"""
        success, stdout, stderr = self._run_command(["lock", version])
        
        if success:
            logger.info(f"Successfully locked dependencies for {version}")
        else:
            logger.error(f"Failed to lock dependencies: {stderr}")
        
        return success


class AutoRegisterMixin:
    """Mixin for automatic version registration after test execution"""
    
    def __init__(self):
        self.version_client = VersionClient()
    
    def auto_register_version(
        self,
        version: str,
        manifest_path: str,
        test_report: TestReport,
        auto_release: bool = False,
        project: Optional[str] = None
    ) -> bool:
        """
        Automatically register version after test execution.
        
        Args:
            version: Version to register
            manifest_path: Path to manifest file
            test_report: Test report from test execution
            auto_release: Whether to automatically release after registration
            project: Optional project name
            
        Returns:
            True if registration succeeded
        """
        success = self.version_client.register(
            version=version,
            manifest_path=manifest_path,
            test_report=test_report,
            project=project
        )
        
        if success and auto_release:
            self.version_client.release_version(version)
        
        return success
