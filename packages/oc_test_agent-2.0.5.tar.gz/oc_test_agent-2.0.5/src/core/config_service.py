import os
import yaml
from pathlib import Path
from typing import Optional, Dict


class ConfigService:
    """配置服务"""
    
    def __init__(self, config_dir: str = None):
        config_dir = config_dir or os.environ.get('OC_CONFIG_DIR', 'config')
        self.config_dir = Path(config_dir)
        self.projects = self._load_projects()
        self.cleanup = self._load_cleanup()
    
    def _load_projects(self) -> Dict:
        """加载项目配置"""
        config_file = self.config_dir / "projects.yaml"
        if config_file.exists():
            with open(config_file, 'r') as f:
                data = yaml.safe_load(f)
                return data.get('projects', {})
        return {}
    
    def _load_cleanup(self) -> Dict:
        """加载清理配置"""
        config_file = self.config_dir / "cleanup.yaml"
        if config_file.exists():
            with open(config_file, 'r') as f:
                return yaml.safe_load(f)
        return {}
    
    def get_project_path(self, project: str) -> Optional[str]:
        """获取项目路径"""
        return self.projects.get(project, {}).get('path')
    
    def get_project_config(self, project: str) -> Optional[Dict]:
        """获取项目配置"""
        return self.projects.get(project)
