"""执行引擎模块。"""

import os
import subprocess
import multiprocessing
import time
import uuid
import json
from pathlib import Path
from typing import Optional
from datetime import datetime
from concurrent.futures import ProcessPoolExecutor, as_completed

from .agent import AgentManager
from .isolation import DatabaseManager
from .ipc import IPCManager
from ..utils.errors import ProcessStartError, AgentNotFoundError
from ..utils.logger import LogManager

# 环境变量配置
OC_STATE_DIR = os.environ.get('OC_STATE_DIR', 'state')
OC_TEST_LOGS_DIR = os.environ.get('OC_TEST_LOGS_DIR', os.path.join(OC_STATE_DIR, 'test_logs'))


class ExecutionEngine:
    """测试执行引擎。"""
    
    def __init__(self, project_id: str, max_workers: int = 5):
        self.project_id = project_id
        self.max_workers = max_workers
        self.agent_manager = AgentManager(max_workers=max_workers)
        self.db_manager = DatabaseManager()
        self.ipc_manager = IPCManager(project_id)
        self.log_manager = LogManager(Path(OC_TEST_LOGS_DIR) / project_id)
        self.results = {}
        self._execution_id = None
    
    def run(self, agent_ids: list[str], test_commands: list[str]) -> dict:
        """执行测试。
        
        Args:
            agent_ids: 要执行的Agent列表
            test_commands: 测试命令列表
            
        Returns:
            执行结果字典
        """
        self._execution_id = f"exec_{uuid.uuid4().hex[:8]}"
        started_at = datetime.utcnow().isoformat()
        
        if not agent_ids:
            return {
                "execution_id": self._execution_id,
                "status": "error",
                "error": "No agents specified"
            }
        
        if not test_commands:
            return {
                "execution_id": self._execution_id,
                "status": "error",
                "error": "No commands specified"
            }
        
        pool_status = self.agent_manager.get_pool_status()
        if pool_status["is_full"]:
            return {
                "execution_id": self._execution_id,
                "status": "error",
                "error": "T007: Agent pool is full"
            }
        
        results = {}
        
        with ProcessPoolExecutor(max_workers=self.max_workers) as executor:
            future_to_agent = {}
            
            for i, agent_id in enumerate(agent_ids):
                if i >= self.max_workers:
                    break
                    
                command = test_commands[i] if i < len(test_commands) else test_commands[0]
                
                try:
                    self.agent_manager.get(agent_id)
                except AgentNotFoundError:
                    results[agent_id] = {
                        "status": "error",
                        "error": f"T005: Agent {agent_id} not registered"
                    }
                    continue
                
                future = executor.submit(
                    self._execute_agent_test,
                    agent_id,
                    command,
                    self.project_id
                )
                future_to_agent[future] = agent_id
                self.agent_manager.assign_process(agent_id, None)
            
            for future in as_completed(future_to_agent):
                agent_id = future_to_agent[future]
                try:
                    result = future.result()
                    results[agent_id] = result
                    
                    self.log_manager.log_test_result(
                        self.project_id,
                        agent_id,
                        result
                    )
                except Exception as e:
                    results[agent_id] = {
                        "status": "error",
                        "error": str(e)
                    }
                finally:
                    self.agent_manager.release_process(agent_id)
        
        completed_at = datetime.utcnow().isoformat()
        
        summary = self._generate_summary(results)
        
        final_result = {
            "execution_id": self._execution_id,
            "project_id": self.project_id,
            "started_at": started_at,
            "completed_at": completed_at,
            "status": "completed" if summary["failed"] == 0 else "partial",
            "results": results,
            "summary": summary
        }
        
        result_file = Path(f"{OC_TEST_LOGS_DIR}/{self.project_id}/result.json")
        result_file.parent.mkdir(parents=True, exist_ok=True)
        
        import json
        with open(result_file, 'w', encoding='utf-8') as f:
            json.dump(final_result, f, ensure_ascii=False, indent=2)
        
        return final_result
    
    def _execute_agent_test(self, agent_id: str, command: str, project_id: str) -> dict:
        """执行单个Agent测试。
        
        Args:
            agent_id: Agent ID
            command: 测试命令
            project_id: 项目ID
            
        Returns:
            测试结果
        """
        namespace = f"{project_id}_{agent_id}"
        task_id = f"task_{uuid.uuid4().hex[:8]}"
        
        self.db_manager.create_task(namespace, task_id, project_id, agent_id, command)
        self.db_manager.update_task_status(namespace, task_id, "running")
        
        try:
            result = subprocess.run(
                command,
                shell=True,
                capture_output=True,
                text=True,
                timeout=300
            )
            
            status = "success" if result.returncode == 0 else "failed"
            
            self.db_manager.update_task_status(
                namespace,
                task_id,
                status,
                result=json.dumps({"returncode": result.returncode}),
                output=result.stdout,
                error=result.stderr if result.returncode != 0 else None
            )
            
            return {
                "status": status,
                "command": command,
                "returncode": result.returncode,
                "output": result.stdout[:1000] if result.stdout else "",
                "error": result.stderr[:500] if result.stderr else None
            }
            
        except subprocess.TimeoutExpired:
            self.db_manager.update_task_status(
                namespace,
                task_id,
                "error",
                error="T009: Process execution timeout"
            )
            return {
                "status": "error",
                "command": command,
                "error": "T009: Process execution timeout"
            }
        except Exception as e:
            self.db_manager.update_task_status(
                namespace,
                task_id,
                "error",
                error=str(e)
            )
            return {
                "status": "error",
                "command": command,
                "error": str(e)
            }
    
    def _generate_summary(self, results: dict) -> dict:
        """生成结果摘要。
        
        Args:
            results: 测试结果
            
        Returns:
            摘要字典
        """
        total = len(results)
        passed = sum(1 for r in results.values() if r.get("status") == "success")
        failed = sum(1 for r in results.values() if r.get("status") == "failed")
        error = sum(1 for r in results.values() if r.get("status") == "error")
        
        return {
            "total": total,
            "passed": passed,
            "failed": failed,
            "error": error
        }
    
    def run_async(self, agent_id: str, command: str) -> tuple[bool, str]:
        """异步执行单个Agent测试。
        
        Args:
            agent_id: Agent ID
            command: 测试命令
            
        Returns:
            (成功标志, 结果/错误)
        """
        try:
            self.agent_manager.get(agent_id)
        except AgentNotFoundError:
            return False, "T005: Agent未注册"
        
        pool_status = self.agent_manager.get_pool_status()
        if pool_status["is_full"]:
            return False, "T007: Agent池已满"
        
        result = self.run([agent_id], [command])
        return True, str(result)
    
    def collect_results(self) -> dict:
        """收集测试结果。
        
        Returns:
            结果汇总字典
        """
        return self.results
    
    def cleanup(self) -> None:
        """清理执行资源。"""
        self.agent_manager.cleanup()
        self.db_manager.close_all()
        self.ipc_manager.close_all()
