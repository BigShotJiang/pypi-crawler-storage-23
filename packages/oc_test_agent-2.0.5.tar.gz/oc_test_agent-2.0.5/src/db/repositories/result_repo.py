from typing import List, Optional
from datetime import datetime
import logging

from ..database import Database
from ...models.test_result import TestResult, TestStatus

logger = logging.getLogger(__name__)


class ResultRepository:
    """测试结果仓库"""
    
    def __init__(self, db: Database):
        self.db = db
    
    def insert(self, result: TestResult) -> None:
        """插入测试结果"""
        conn = self.db.get_connection()
        conn.execute("""
            INSERT INTO test_results (
                id, project, version, test_type, status, duration,
                passed, failed, errors, total, report_path, logs_path,
                container_id, created_at, finished_at, metadata
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            result.id,
            result.project,
            result.version,
            result.test_type,
            result.status.value,
            result.duration,
            result.passed,
            result.failed,
            result.errors,
            result.total,
            result.report_path,
            result.logs_path,
            result.container_id,
            result.created_at.isoformat() if result.created_at else datetime.now().isoformat(),
            result.finished_at.isoformat() if result.finished_at else None,
            str(result.metadata)
        ))
        conn.commit()
        logger.info(f"Inserted test result: {result.id}")
    
    def find_by_id(self, test_id: str) -> Optional[TestResult]:
        """根据ID查找测试结果"""
        conn = self.db.get_connection()
        cursor = conn.execute(
            "SELECT * FROM test_results WHERE id = ?",
            (test_id,)
        )
        row = cursor.fetchone()
        return TestResult.from_row(dict(row)) if row else None
    
    def find_all(
        self,
        project: Optional[str] = None,
        version: Optional[str] = None,
        status: Optional[TestStatus] = None,
        limit: int = 10
    ) -> List[TestResult]:
        """查询测试结果列表"""
        conn = self.db.get_connection()
        
        query = "SELECT * FROM test_results WHERE 1=1"
        params = []
        
        if project:
            query += " AND project = ?"
            params.append(project)
        if version:
            query += " AND version = ?"
            params.append(version)
        if status:
            query += " AND status = ?"
            params.append(status.value)
        
        query += " ORDER BY created_at DESC LIMIT ?"
        params.append(limit)
        
        cursor = conn.execute(query, params)
        return [TestResult.from_row(dict(row)) for row in cursor.fetchall()]
    
    def update_status(
        self,
        test_id: str,
        status: TestStatus,
        duration: Optional[float] = None,
        passed: Optional[int] = None,
        failed: Optional[int] = None,
        errors: Optional[int] = None,
        total: Optional[int] = None,
        report_path: Optional[str] = None,
        logs_path: Optional[str] = None,
        container_id: Optional[str] = None
    ) -> None:
        """更新测试结果"""
        conn = self.db.get_connection()
        
        updates = ["status = ?"]
        params = [status.value]
        
        if duration is not None:
            updates.append("duration = ?")
            params.append(duration)
        if passed is not None:
            updates.append("passed = ?")
            params.append(passed)
        if failed is not None:
            updates.append("failed = ?")
            params.append(failed)
        if errors is not None:
            updates.append("errors = ?")
            params.append(errors)
        if total is not None:
            updates.append("total = ?")
            params.append(total)
        if report_path is not None:
            updates.append("report_path = ?")
            params.append(report_path)
        if logs_path is not None:
            updates.append("logs_path = ?")
            params.append(logs_path)
        if container_id is not None:
            updates.append("container_id = ?")
            params.append(container_id)
        
        if status in (TestStatus.PASSED, TestStatus.FAILED, TestStatus.ERROR, TestStatus.CANCELLED):
            updates.append("finished_at = ?")
            params.append(datetime.now().isoformat())
        
        params.append(test_id)
        
        conn.execute(
            f"UPDATE test_results SET {', '.join(updates)} WHERE id = ?",
            params
        )
        conn.commit()
    
    def delete(self, test_id: str) -> bool:
        """删除测试结果"""
        conn = self.db.get_connection()
        cursor = conn.execute(
            "DELETE FROM test_results WHERE id = ?",
            (test_id,)
        )
        conn.commit()
        return cursor.rowcount > 0
    
    def delete_before(self, before_date: str, project: Optional[str] = None) -> int:
        """删除指定日期之前的测试结果"""
        conn = self.db.get_connection()
        
        query = "DELETE FROM test_results WHERE created_at < ?"
        params = [before_date]
        
        if project:
            query += " AND project = ?"
            params.append(project)
        
        cursor = conn.execute(query, params)
        conn.commit()
        return cursor.rowcount
    
    def insert_test_case_record(self, record: dict) -> int:
        """插入测试用例记录"""
        conn = self.db.get_connection()
        cursor = conn.execute(
            """INSERT INTO test_case_records 
               (test_id, test_case_name, status, duration, requirement_id, agent_id, created_at)
               VALUES (?, ?, ?, ?, ?, ?, ?)""",
            (
                record['test_id'],
                record['test_case_name'],
                record['status'],
                record.get('duration', 0),
                record.get('requirement_id'),
                record.get('agent_id'),
                record.get('created_at', datetime.now().isoformat())
            )
        )
        conn.commit()
        return cursor.lastrowid
    
    def get_test_case_records(self, test_id: str) -> list:
        """获取测试的所有用例记录"""
        conn = self.db.get_connection()
        cursor = conn.execute(
            "SELECT * FROM test_case_records WHERE test_id = ? ORDER BY created_at DESC",
            (test_id,)
        )
        return [dict(row) for row in cursor.fetchall()]
    
    def count_test_case_runs(self, test_case_name: str) -> int:
        """统计测试用例被执行次数"""
        conn = self.db.get_connection()
        cursor = conn.execute(
            "SELECT COUNT(*) as count FROM test_case_records WHERE test_case_name = ?",
            (test_case_name,)
        )
        return cursor.fetchone()['count']
    
    def get_test_case_records_by_requirement(self, requirement_id: str) -> list:
        """根据需求ID查询用例记录"""
        conn = self.db.get_connection()
        cursor = conn.execute(
            "SELECT * FROM test_case_records WHERE requirement_id = ? ORDER BY created_at DESC",
            (requirement_id,)
        )
        return [dict(row) for row in cursor.fetchall()]
    
    def get_test_case_records_by_agent(self, agent_id: str) -> list:
        """根据Agent ID查询用例记录"""
        conn = self.db.get_connection()
        cursor = conn.execute(
            "SELECT * FROM test_case_records WHERE agent_id = ? ORDER BY created_at DESC",
            (agent_id,)
        )
        return [dict(row) for row in cursor.fetchall()]
