# Test-Agent 测试平台子系统

**版本**: v2.0.4  
**状态**: 已发布 (PyPI)

---

## 一、项目定位

Test-Agent 是独立的测试平台子系统，为 oc-collab 和 PM-Agent 提供隔离的测试环境。

### 1.1 核心能力

| 能力 | 说明 |
|------|------|
| 独立测试数据库 | 隔离生产数据 |
| 多Agent互动测试 | 多进程真实Agent通信 |
| 动态测试项目 | 支持任意类型项目 |
| 版本自动注册 | 与conf-man集成，自动注册测试版本 |
| Docker测试执行 | 强制在Docker内运行测试 |
| 测试报告生成 | 生成标准化测试报告 |

### 1.2 技术架构

| 组件 | 技术 |
|------|------|
| CLI框架 | Click |
| 数据库 | SQLite |
| 测试执行 | Docker容器 |
| 版本集成 | REST API (conf-man) |

---

## 二、安装

### 2.1 PyPI安装（推荐）

```bash
pip install oc-test-agent
```

### 2.2 验证安装

```bash
test-agent --version
# 输出: test-agent, version 2.0.4
```

### 2.3 开发模式安装

```bash
# 克隆项目
git clone https://gitee.com/zhang-xiuqin01/test-agent.git
cd test-agent

# 开发模式安装
pip install -e .
```

---

## 三、快速开始

### 3.1 初始化环境

```bash
test-agent init
```

### 3.2 基本使用

```bash
# 项目管理
test-agent project create --id test_project --name "测试项目"
test-agent project list

# Agent管理
test-agent agent register --id test_agent1 --name "测试Agent"
test-agent agent status

# 测试执行
test-agent run --project test_project --agents test_agent1 --commands "pytest"

# 清理数据
test-agent cleanup --project test_project
```

---

## 四、CLI命令

### 4.1 主要命令

| 命令 | 说明 |
|------|------|
| `test-agent execute` | 在Docker容器内执行测试 |
| `test-agent build` | 构建Docker测试镜像 |
| `test-agent query` | 查询历史测试结果 |
| `test-agent report` | 生成测试报告 |
| `test-agent cancel` | 取消正在执行的测试 |
| `test-agent cleanup` | 清理历史测试数据 |
| `test-agent init` | 初始化测试环境 |

### 4.2 项目管理

| 命令 | 说明 |
|------|------|
| `test-agent project create` | 创建测试项目 |
| `test-agent project list` | 列出所有项目 |
| `test-agent project delete` | 删除测试项目 |

### 4.3 Agent管理

| 命令 | 说明 |
|------|------|
| `test-agent agent register` | 注册测试Agent |
| `test-agent agent status` | 查看Agent状态 |
| `test-agent agent unregister` | 注销Agent |

---

## 五、版本集成 (v2.0)

### 5.1 自动注册测试

```bash
# 执行测试并自动注册版本
test-agent execute \
    --project my-project \
    --version v2.0.4 \
    --auto-register \
    --manifest version_manifest.yaml
```

### 5.2 生成测试报告

```bash
# 执行测试并生成报告
test-agent execute \
    --project my-project \
    --version v2.0.4 \
    --test-type unit \
    --auto-register
```

---

## 六、目录结构

```
test-agent/
├── src/                    # 源代码
│   ├── cli/               # CLI命令
│   ├── core/              # 核心模块
│   ├── db/                # 数据库
│   ├── models/            # 数据模型
│   └── utils/             # 工具类
├── tests/                 # 测试用例
├── docs/                  # 项目文档
│   ├── 01-requirements/
│   ├── 02-design/
│   ├── 03-reviews/
│   └── 06-roadmap/
├── state/                 # 测试状态数据
├── config/                # 配置文件
└── pyproject.toml         # 项目配置
```

---

## 七、相关文档

- 需求文档: `docs/01-requirements/`
- 设计文档: `docs/02-design/`
- 发布记录: `docs/03-reviews/`
- 路线图: `docs/06-roadmap/`
- oc-collab主项目: `../dual-agent-collaboration-system`
- PM-Agent项目: `../pm-agent`

---

## 八、PyPI发布

- 包名: `oc-test-agent`
- PyPI链接: https://pypi.org/project/oc-test-agent/
- 版本: v2.0.4

---

**作者**: oc-collab团队  
**维护者**: test-agent团队  
**创建日期**: 2026-02-18  
**更新日期**: 2026-02-22
