# Planes, Circles, Lines, and Other Geometric Objects

## Planes

## Circles and Arcs 

## Lines