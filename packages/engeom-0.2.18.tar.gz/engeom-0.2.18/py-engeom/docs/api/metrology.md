# Metrology Module

!!! warning
    The metrology feature set is still experimental and is under heavy development in the Rust `engeom` library.
    Expect significant changes to the API in the future.

::: engeom.metrology
    options:
        show_source: false