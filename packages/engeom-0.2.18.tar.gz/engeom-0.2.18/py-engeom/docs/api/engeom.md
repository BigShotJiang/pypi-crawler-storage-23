# Engeom

The `engeom` main module has a handful of common entities shared across other parts of the library.

::: engeom
