# Primitive Shapes

## Lines/Rays

## Circles