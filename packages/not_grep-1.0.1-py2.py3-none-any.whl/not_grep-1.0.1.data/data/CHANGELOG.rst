*********
Changelog
*********

Versions follow `Semantic Versioning`_.

Changes or the upcoming release can be found in
the `"changelog.d" directory
<https://github.com/mattsb42-meta/not-grep/changelog.d>`_.

..
   Do *NOT* add changelog entries here!

   This changelog is managed by towncrier
   and is compiled at release time.

.. _Semantic Versioning: https://semver.org

.. towncrier release notes start

1.0.1 -- 2026-02-18
===================

No significant changes.


1.0.0 -- 2020-05-16
===================

GitHub Action release.

0.1.1 -- 2020-05-16
===================

Pre-release to test PyPI automation.

0.1.0 -- 2020-05-16
===================

Initial release.
