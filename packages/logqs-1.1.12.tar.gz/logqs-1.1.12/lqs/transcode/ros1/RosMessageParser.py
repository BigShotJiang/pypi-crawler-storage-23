# Generated from RosMessageParser.g4 by ANTLR 4.13.0
# encoding: utf-8
from antlr4 import *
from io import StringIO
import sys

if sys.version_info[1] > 5:
    from typing import TextIO
else:
    from typing.io import TextIO


def serializedATN():
    return [
        4,
        1,
        45,
        193,
        2,
        0,
        7,
        0,
        2,
        1,
        7,
        1,
        2,
        2,
        7,
        2,
        2,
        3,
        7,
        3,
        2,
        4,
        7,
        4,
        2,
        5,
        7,
        5,
        2,
        6,
        7,
        6,
        2,
        7,
        7,
        7,
        2,
        8,
        7,
        8,
        2,
        9,
        7,
        9,
        2,
        10,
        7,
        10,
        2,
        11,
        7,
        11,
        2,
        12,
        7,
        12,
        2,
        13,
        7,
        13,
        2,
        14,
        7,
        14,
        2,
        15,
        7,
        15,
        2,
        16,
        7,
        16,
        2,
        17,
        7,
        17,
        2,
        18,
        7,
        18,
        2,
        19,
        7,
        19,
        2,
        20,
        7,
        20,
        2,
        21,
        7,
        21,
        2,
        22,
        7,
        22,
        2,
        23,
        7,
        23,
        2,
        24,
        7,
        24,
        2,
        25,
        7,
        25,
        1,
        0,
        1,
        0,
        1,
        0,
        3,
        0,
        56,
        8,
        0,
        1,
        1,
        1,
        1,
        1,
        1,
        1,
        2,
        1,
        2,
        1,
        2,
        1,
        2,
        1,
        2,
        1,
        2,
        1,
        2,
        1,
        3,
        1,
        3,
        1,
        3,
        1,
        3,
        1,
        3,
        1,
        4,
        1,
        4,
        5,
        4,
        75,
        8,
        4,
        10,
        4,
        12,
        4,
        78,
        9,
        4,
        1,
        4,
        1,
        4,
        1,
        5,
        1,
        5,
        1,
        5,
        1,
        5,
        1,
        6,
        1,
        6,
        1,
        6,
        5,
        6,
        89,
        8,
        6,
        10,
        6,
        12,
        6,
        92,
        9,
        6,
        1,
        7,
        1,
        7,
        3,
        7,
        96,
        8,
        7,
        1,
        7,
        1,
        7,
        1,
        8,
        1,
        8,
        1,
        8,
        1,
        8,
        1,
        8,
        1,
        8,
        1,
        8,
        1,
        8,
        1,
        8,
        1,
        8,
        3,
        8,
        110,
        8,
        8,
        1,
        8,
        1,
        8,
        1,
        8,
        1,
        8,
        1,
        8,
        3,
        8,
        117,
        8,
        8,
        1,
        8,
        1,
        8,
        1,
        8,
        1,
        8,
        1,
        8,
        3,
        8,
        124,
        8,
        8,
        1,
        9,
        1,
        9,
        1,
        9,
        3,
        9,
        129,
        8,
        9,
        1,
        10,
        1,
        10,
        1,
        11,
        1,
        11,
        1,
        11,
        1,
        11,
        1,
        11,
        1,
        11,
        3,
        11,
        139,
        8,
        11,
        1,
        12,
        1,
        12,
        1,
        12,
        1,
        12,
        3,
        12,
        145,
        8,
        12,
        1,
        13,
        1,
        13,
        3,
        13,
        149,
        8,
        13,
        1,
        14,
        1,
        14,
        1,
        14,
        1,
        14,
        1,
        15,
        1,
        15,
        1,
        15,
        1,
        15,
        1,
        15,
        1,
        15,
        1,
        15,
        1,
        15,
        1,
        15,
        1,
        15,
        3,
        15,
        165,
        8,
        15,
        1,
        16,
        1,
        16,
        1,
        17,
        1,
        17,
        1,
        18,
        1,
        18,
        1,
        19,
        1,
        19,
        1,
        20,
        1,
        20,
        1,
        21,
        1,
        21,
        1,
        22,
        3,
        22,
        180,
        8,
        22,
        1,
        22,
        1,
        22,
        1,
        23,
        3,
        23,
        185,
        8,
        23,
        1,
        23,
        1,
        23,
        1,
        24,
        1,
        24,
        1,
        25,
        1,
        25,
        1,
        25,
        0,
        0,
        26,
        0,
        2,
        4,
        6,
        8,
        10,
        12,
        14,
        16,
        18,
        20,
        22,
        24,
        26,
        28,
        30,
        32,
        34,
        36,
        38,
        40,
        42,
        44,
        46,
        48,
        50,
        0,
        9,
        2,
        0,
        23,
        23,
        39,
        39,
        3,
        0,
        1,
        16,
        27,
        29,
        34,
        34,
        2,
        0,
        18,
        18,
        35,
        35,
        2,
        0,
        19,
        19,
        36,
        36,
        1,
        0,
        2,
        11,
        1,
        0,
        12,
        13,
        1,
        0,
        15,
        16,
        1,
        0,
        21,
        22,
        1,
        0,
        27,
        28,
        189,
        0,
        55,
        1,
        0,
        0,
        0,
        2,
        57,
        1,
        0,
        0,
        0,
        4,
        60,
        1,
        0,
        0,
        0,
        6,
        67,
        1,
        0,
        0,
        0,
        8,
        72,
        1,
        0,
        0,
        0,
        10,
        81,
        1,
        0,
        0,
        0,
        12,
        90,
        1,
        0,
        0,
        0,
        14,
        95,
        1,
        0,
        0,
        0,
        16,
        123,
        1,
        0,
        0,
        0,
        18,
        128,
        1,
        0,
        0,
        0,
        20,
        130,
        1,
        0,
        0,
        0,
        22,
        138,
        1,
        0,
        0,
        0,
        24,
        144,
        1,
        0,
        0,
        0,
        26,
        148,
        1,
        0,
        0,
        0,
        28,
        150,
        1,
        0,
        0,
        0,
        30,
        164,
        1,
        0,
        0,
        0,
        32,
        166,
        1,
        0,
        0,
        0,
        34,
        168,
        1,
        0,
        0,
        0,
        36,
        170,
        1,
        0,
        0,
        0,
        38,
        172,
        1,
        0,
        0,
        0,
        40,
        174,
        1,
        0,
        0,
        0,
        42,
        176,
        1,
        0,
        0,
        0,
        44,
        179,
        1,
        0,
        0,
        0,
        46,
        184,
        1,
        0,
        0,
        0,
        48,
        188,
        1,
        0,
        0,
        0,
        50,
        190,
        1,
        0,
        0,
        0,
        52,
        56,
        3,
        2,
        1,
        0,
        53,
        56,
        3,
        4,
        2,
        0,
        54,
        56,
        3,
        6,
        3,
        0,
        55,
        52,
        1,
        0,
        0,
        0,
        55,
        53,
        1,
        0,
        0,
        0,
        55,
        54,
        1,
        0,
        0,
        0,
        56,
        1,
        1,
        0,
        0,
        0,
        57,
        58,
        3,
        12,
        6,
        0,
        58,
        59,
        5,
        0,
        0,
        1,
        59,
        3,
        1,
        0,
        0,
        0,
        60,
        61,
        3,
        12,
        6,
        0,
        61,
        62,
        5,
        24,
        0,
        0,
        62,
        63,
        3,
        12,
        6,
        0,
        63,
        64,
        5,
        24,
        0,
        0,
        64,
        65,
        3,
        12,
        6,
        0,
        65,
        66,
        5,
        0,
        0,
        1,
        66,
        5,
        1,
        0,
        0,
        0,
        67,
        68,
        3,
        12,
        6,
        0,
        68,
        69,
        5,
        24,
        0,
        0,
        69,
        70,
        3,
        12,
        6,
        0,
        70,
        71,
        5,
        0,
        0,
        1,
        71,
        7,
        1,
        0,
        0,
        0,
        72,
        76,
        3,
        12,
        6,
        0,
        73,
        75,
        3,
        10,
        5,
        0,
        74,
        73,
        1,
        0,
        0,
        0,
        75,
        78,
        1,
        0,
        0,
        0,
        76,
        74,
        1,
        0,
        0,
        0,
        76,
        77,
        1,
        0,
        0,
        0,
        77,
        79,
        1,
        0,
        0,
        0,
        78,
        76,
        1,
        0,
        0,
        0,
        79,
        80,
        5,
        0,
        0,
        1,
        80,
        9,
        1,
        0,
        0,
        0,
        81,
        82,
        5,
        30,
        0,
        0,
        82,
        83,
        3,
        24,
        12,
        0,
        83,
        84,
        3,
        12,
        6,
        0,
        84,
        11,
        1,
        0,
        0,
        0,
        85,
        89,
        3,
        14,
        7,
        0,
        86,
        89,
        3,
        16,
        8,
        0,
        87,
        89,
        3,
        18,
        9,
        0,
        88,
        85,
        1,
        0,
        0,
        0,
        88,
        86,
        1,
        0,
        0,
        0,
        88,
        87,
        1,
        0,
        0,
        0,
        89,
        92,
        1,
        0,
        0,
        0,
        90,
        88,
        1,
        0,
        0,
        0,
        90,
        91,
        1,
        0,
        0,
        0,
        91,
        13,
        1,
        0,
        0,
        0,
        92,
        90,
        1,
        0,
        0,
        0,
        93,
        96,
        3,
        22,
        11,
        0,
        94,
        96,
        3,
        26,
        13,
        0,
        95,
        93,
        1,
        0,
        0,
        0,
        95,
        94,
        1,
        0,
        0,
        0,
        96,
        97,
        1,
        0,
        0,
        0,
        97,
        98,
        3,
        20,
        10,
        0,
        98,
        15,
        1,
        0,
        0,
        0,
        99,
        100,
        3,
        32,
        16,
        0,
        100,
        101,
        3,
        20,
        10,
        0,
        101,
        102,
        5,
        20,
        0,
        0,
        102,
        103,
        3,
        44,
        22,
        0,
        103,
        124,
        1,
        0,
        0,
        0,
        104,
        105,
        3,
        34,
        17,
        0,
        105,
        106,
        3,
        20,
        10,
        0,
        106,
        109,
        5,
        20,
        0,
        0,
        107,
        110,
        3,
        44,
        22,
        0,
        108,
        110,
        3,
        46,
        23,
        0,
        109,
        107,
        1,
        0,
        0,
        0,
        109,
        108,
        1,
        0,
        0,
        0,
        110,
        124,
        1,
        0,
        0,
        0,
        111,
        112,
        3,
        40,
        20,
        0,
        112,
        113,
        3,
        20,
        10,
        0,
        113,
        116,
        5,
        20,
        0,
        0,
        114,
        117,
        3,
        48,
        24,
        0,
        115,
        117,
        3,
        44,
        22,
        0,
        116,
        114,
        1,
        0,
        0,
        0,
        116,
        115,
        1,
        0,
        0,
        0,
        117,
        124,
        1,
        0,
        0,
        0,
        118,
        119,
        3,
        38,
        19,
        0,
        119,
        120,
        3,
        20,
        10,
        0,
        120,
        121,
        5,
        38,
        0,
        0,
        121,
        122,
        3,
        50,
        25,
        0,
        122,
        124,
        1,
        0,
        0,
        0,
        123,
        99,
        1,
        0,
        0,
        0,
        123,
        104,
        1,
        0,
        0,
        0,
        123,
        111,
        1,
        0,
        0,
        0,
        123,
        118,
        1,
        0,
        0,
        0,
        124,
        17,
        1,
        0,
        0,
        0,
        125,
        126,
        7,
        0,
        0,
        0,
        126,
        129,
        5,
        44,
        0,
        0,
        127,
        129,
        7,
        0,
        0,
        0,
        128,
        125,
        1,
        0,
        0,
        0,
        128,
        127,
        1,
        0,
        0,
        0,
        129,
        19,
        1,
        0,
        0,
        0,
        130,
        131,
        7,
        1,
        0,
        0,
        131,
        21,
        1,
        0,
        0,
        0,
        132,
        139,
        3,
        32,
        16,
        0,
        133,
        139,
        3,
        34,
        17,
        0,
        134,
        139,
        3,
        36,
        18,
        0,
        135,
        139,
        3,
        40,
        20,
        0,
        136,
        139,
        3,
        38,
        19,
        0,
        137,
        139,
        3,
        24,
        12,
        0,
        138,
        132,
        1,
        0,
        0,
        0,
        138,
        133,
        1,
        0,
        0,
        0,
        138,
        134,
        1,
        0,
        0,
        0,
        138,
        135,
        1,
        0,
        0,
        0,
        138,
        136,
        1,
        0,
        0,
        0,
        138,
        137,
        1,
        0,
        0,
        0,
        139,
        23,
        1,
        0,
        0,
        0,
        140,
        145,
        5,
        29,
        0,
        0,
        141,
        142,
        5,
        29,
        0,
        0,
        142,
        143,
        5,
        17,
        0,
        0,
        143,
        145,
        5,
        29,
        0,
        0,
        144,
        140,
        1,
        0,
        0,
        0,
        144,
        141,
        1,
        0,
        0,
        0,
        145,
        25,
        1,
        0,
        0,
        0,
        146,
        149,
        3,
        28,
        14,
        0,
        147,
        149,
        3,
        30,
        15,
        0,
        148,
        146,
        1,
        0,
        0,
        0,
        148,
        147,
        1,
        0,
        0,
        0,
        149,
        27,
        1,
        0,
        0,
        0,
        150,
        151,
        3,
        22,
        11,
        0,
        151,
        152,
        7,
        2,
        0,
        0,
        152,
        153,
        7,
        3,
        0,
        0,
        153,
        29,
        1,
        0,
        0,
        0,
        154,
        155,
        3,
        22,
        11,
        0,
        155,
        156,
        5,
        18,
        0,
        0,
        156,
        157,
        5,
        25,
        0,
        0,
        157,
        158,
        5,
        19,
        0,
        0,
        158,
        165,
        1,
        0,
        0,
        0,
        159,
        160,
        3,
        22,
        11,
        0,
        160,
        161,
        5,
        35,
        0,
        0,
        161,
        162,
        5,
        37,
        0,
        0,
        162,
        163,
        5,
        36,
        0,
        0,
        163,
        165,
        1,
        0,
        0,
        0,
        164,
        154,
        1,
        0,
        0,
        0,
        164,
        159,
        1,
        0,
        0,
        0,
        165,
        31,
        1,
        0,
        0,
        0,
        166,
        167,
        7,
        4,
        0,
        0,
        167,
        33,
        1,
        0,
        0,
        0,
        168,
        169,
        7,
        5,
        0,
        0,
        169,
        35,
        1,
        0,
        0,
        0,
        170,
        171,
        7,
        6,
        0,
        0,
        171,
        37,
        1,
        0,
        0,
        0,
        172,
        173,
        5,
        14,
        0,
        0,
        173,
        39,
        1,
        0,
        0,
        0,
        174,
        175,
        5,
        1,
        0,
        0,
        175,
        41,
        1,
        0,
        0,
        0,
        176,
        177,
        7,
        7,
        0,
        0,
        177,
        43,
        1,
        0,
        0,
        0,
        178,
        180,
        3,
        42,
        21,
        0,
        179,
        178,
        1,
        0,
        0,
        0,
        179,
        180,
        1,
        0,
        0,
        0,
        180,
        181,
        1,
        0,
        0,
        0,
        181,
        182,
        5,
        25,
        0,
        0,
        182,
        45,
        1,
        0,
        0,
        0,
        183,
        185,
        3,
        42,
        21,
        0,
        184,
        183,
        1,
        0,
        0,
        0,
        184,
        185,
        1,
        0,
        0,
        0,
        185,
        186,
        1,
        0,
        0,
        0,
        186,
        187,
        5,
        26,
        0,
        0,
        187,
        47,
        1,
        0,
        0,
        0,
        188,
        189,
        7,
        8,
        0,
        0,
        189,
        49,
        1,
        0,
        0,
        0,
        190,
        191,
        5,
        42,
        0,
        0,
        191,
        51,
        1,
        0,
        0,
        0,
        15,
        55,
        76,
        88,
        90,
        95,
        109,
        116,
        123,
        128,
        138,
        144,
        148,
        164,
        179,
        184,
    ]


class RosMessageParser(Parser):

    grammarFileName = "RosMessageParser.g4"

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [DFA(ds, i) for i, ds in enumerate(atn.decisionToState)]

    sharedContextCache = PredictionContextCache()

    literalNames = [
        "<INVALID>",
        "'bool'",
        "'int8'",
        "'uint8'",
        "'byte'",
        "'char'",
        "'int16'",
        "'uint16'",
        "'int32'",
        "'uint32'",
        "'int64'",
        "'uint64'",
        "'float32'",
        "'float64'",
        "'string'",
        "'time'",
        "'duration'",
        "'/'",
        "<INVALID>",
        "<INVALID>",
        "<INVALID>",
        "'+'",
        "'-'",
        "<INVALID>",
        "'---'",
        "<INVALID>",
        "<INVALID>",
        "'True'",
        "'False'",
    ]

    symbolicNames = [
        "<INVALID>",
        "BOOL",
        "INT8",
        "UINT8",
        "BYTE",
        "CHAR",
        "INT16",
        "UINT16",
        "INT32",
        "UINT32",
        "INT64",
        "UINT64",
        "FLOAT32",
        "FLOAT64",
        "STRING",
        "TIME",
        "DURATION",
        "SLASH",
        "OPEN_BRACKET",
        "CLOSE_BRACKET",
        "ASSIGNMENT",
        "PLUS",
        "MINUS",
        "HASH",
        "MESSAGE_SEPARATOR",
        "INTEGER_LITERAL",
        "REAL_LITERAL",
        "TRUE",
        "FALSE",
        "IDENTIFIER",
        "ROSBAG_MESSAGE_SEPARATOR",
        "WHITESPACES",
        "NEWLINES",
        "NEWLINE",
        "STRING_IDENTIFIER",
        "STRING_OPEN_BRACKET",
        "STRING_CLOSE_BRACKET",
        "STRING_INTEGER_LITERAL",
        "STRING_ASSIGNMENT",
        "STRING_HASH",
        "STRING_WHITESPACES",
        "STRING_NEWLINE",
        "STRING_VALUE",
        "STRIN_ASSIGNMENT_NEWLINE",
        "COMMENT",
        "COMMENT_NEWLINE",
    ]

    RULE_ros_file_input = 0
    RULE_ros_message_input = 1
    RULE_ros_action_input = 2
    RULE_ros_service_input = 3
    RULE_rosbag_input = 4
    RULE_rosbag_nested_message = 5
    RULE_ros_message = 6
    RULE_field_declaration = 7
    RULE_constant_declaration = 8
    RULE_comment = 9
    RULE_identifier = 10
    RULE_type_ = 11
    RULE_ros_type = 12
    RULE_array_type = 13
    RULE_variable_array_type = 14
    RULE_fixed_array_type = 15
    RULE_integral_type = 16
    RULE_floating_point_type = 17
    RULE_temporal_type = 18
    RULE_string_type = 19
    RULE_boolean_type = 20
    RULE_sign = 21
    RULE_integral_value = 22
    RULE_floating_point_value = 23
    RULE_bool_value = 24
    RULE_string_value = 25

    ruleNames = [
        "ros_file_input",
        "ros_message_input",
        "ros_action_input",
        "ros_service_input",
        "rosbag_input",
        "rosbag_nested_message",
        "ros_message",
        "field_declaration",
        "constant_declaration",
        "comment",
        "identifier",
        "type_",
        "ros_type",
        "array_type",
        "variable_array_type",
        "fixed_array_type",
        "integral_type",
        "floating_point_type",
        "temporal_type",
        "string_type",
        "boolean_type",
        "sign",
        "integral_value",
        "floating_point_value",
        "bool_value",
        "string_value",
    ]

    EOF = Token.EOF
    BOOL = 1
    INT8 = 2
    UINT8 = 3
    BYTE = 4
    CHAR = 5
    INT16 = 6
    UINT16 = 7
    INT32 = 8
    UINT32 = 9
    INT64 = 10
    UINT64 = 11
    FLOAT32 = 12
    FLOAT64 = 13
    STRING = 14
    TIME = 15
    DURATION = 16
    SLASH = 17
    OPEN_BRACKET = 18
    CLOSE_BRACKET = 19
    ASSIGNMENT = 20
    PLUS = 21
    MINUS = 22
    HASH = 23
    MESSAGE_SEPARATOR = 24
    INTEGER_LITERAL = 25
    REAL_LITERAL = 26
    TRUE = 27
    FALSE = 28
    IDENTIFIER = 29
    ROSBAG_MESSAGE_SEPARATOR = 30
    WHITESPACES = 31
    NEWLINES = 32
    NEWLINE = 33
    STRING_IDENTIFIER = 34
    STRING_OPEN_BRACKET = 35
    STRING_CLOSE_BRACKET = 36
    STRING_INTEGER_LITERAL = 37
    STRING_ASSIGNMENT = 38
    STRING_HASH = 39
    STRING_WHITESPACES = 40
    STRING_NEWLINE = 41
    STRING_VALUE = 42
    STRIN_ASSIGNMENT_NEWLINE = 43
    COMMENT = 44
    COMMENT_NEWLINE = 45

    def __init__(self, input: TokenStream, output: TextIO = sys.stdout):
        super().__init__(input, output)
        self.checkVersion("4.13.0")
        self._interp = ParserATNSimulator(
            self, self.atn, self.decisionsToDFA, self.sharedContextCache
        )
        self._predicates = None

    class Ros_file_inputContext(ParserRuleContext):
        __slots__ = "parser"

        def __init__(
            self, parser, parent: ParserRuleContext = None, invokingState: int = -1
        ):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ros_message_input(self):
            return self.getTypedRuleContext(
                RosMessageParser.Ros_message_inputContext, 0
            )

        def ros_action_input(self):
            return self.getTypedRuleContext(RosMessageParser.Ros_action_inputContext, 0)

        def ros_service_input(self):
            return self.getTypedRuleContext(
                RosMessageParser.Ros_service_inputContext, 0
            )

        def getRuleIndex(self):
            return RosMessageParser.RULE_ros_file_input

        def enterRule(self, listener: ParseTreeListener):
            if hasattr(listener, "enterRos_file_input"):
                listener.enterRos_file_input(self)

        def exitRule(self, listener: ParseTreeListener):
            if hasattr(listener, "exitRos_file_input"):
                listener.exitRos_file_input(self)

        def accept(self, visitor: ParseTreeVisitor):
            if hasattr(visitor, "visitRos_file_input"):
                return visitor.visitRos_file_input(self)
            else:
                return visitor.visitChildren(self)

    def ros_file_input(self):

        localctx = RosMessageParser.Ros_file_inputContext(self, self._ctx, self.state)
        self.enterRule(localctx, 0, self.RULE_ros_file_input)
        try:
            self.state = 55
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input, 0, self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 52
                self.ros_message_input()
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 53
                self.ros_action_input()
                pass

            elif la_ == 3:
                self.enterOuterAlt(localctx, 3)
                self.state = 54
                self.ros_service_input()
                pass

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class Ros_message_inputContext(ParserRuleContext):
        __slots__ = "parser"

        def __init__(
            self, parser, parent: ParserRuleContext = None, invokingState: int = -1
        ):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ros_message(self):
            return self.getTypedRuleContext(RosMessageParser.Ros_messageContext, 0)

        def EOF(self):
            return self.getToken(RosMessageParser.EOF, 0)

        def getRuleIndex(self):
            return RosMessageParser.RULE_ros_message_input

        def enterRule(self, listener: ParseTreeListener):
            if hasattr(listener, "enterRos_message_input"):
                listener.enterRos_message_input(self)

        def exitRule(self, listener: ParseTreeListener):
            if hasattr(listener, "exitRos_message_input"):
                listener.exitRos_message_input(self)

        def accept(self, visitor: ParseTreeVisitor):
            if hasattr(visitor, "visitRos_message_input"):
                return visitor.visitRos_message_input(self)
            else:
                return visitor.visitChildren(self)

    def ros_message_input(self):

        localctx = RosMessageParser.Ros_message_inputContext(
            self, self._ctx, self.state
        )
        self.enterRule(localctx, 2, self.RULE_ros_message_input)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 57
            self.ros_message()
            self.state = 58
            self.match(RosMessageParser.EOF)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class Ros_action_inputContext(ParserRuleContext):
        __slots__ = "parser"

        def __init__(
            self, parser, parent: ParserRuleContext = None, invokingState: int = -1
        ):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ros_message(self, i: int = None):
            if i is None:
                return self.getTypedRuleContexts(RosMessageParser.Ros_messageContext)
            else:
                return self.getTypedRuleContext(RosMessageParser.Ros_messageContext, i)

        def MESSAGE_SEPARATOR(self, i: int = None):
            if i is None:
                return self.getTokens(RosMessageParser.MESSAGE_SEPARATOR)
            else:
                return self.getToken(RosMessageParser.MESSAGE_SEPARATOR, i)

        def EOF(self):
            return self.getToken(RosMessageParser.EOF, 0)

        def getRuleIndex(self):
            return RosMessageParser.RULE_ros_action_input

        def enterRule(self, listener: ParseTreeListener):
            if hasattr(listener, "enterRos_action_input"):
                listener.enterRos_action_input(self)

        def exitRule(self, listener: ParseTreeListener):
            if hasattr(listener, "exitRos_action_input"):
                listener.exitRos_action_input(self)

        def accept(self, visitor: ParseTreeVisitor):
            if hasattr(visitor, "visitRos_action_input"):
                return visitor.visitRos_action_input(self)
            else:
                return visitor.visitChildren(self)

    def ros_action_input(self):

        localctx = RosMessageParser.Ros_action_inputContext(self, self._ctx, self.state)
        self.enterRule(localctx, 4, self.RULE_ros_action_input)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 60
            self.ros_message()
            self.state = 61
            self.match(RosMessageParser.MESSAGE_SEPARATOR)
            self.state = 62
            self.ros_message()
            self.state = 63
            self.match(RosMessageParser.MESSAGE_SEPARATOR)
            self.state = 64
            self.ros_message()
            self.state = 65
            self.match(RosMessageParser.EOF)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class Ros_service_inputContext(ParserRuleContext):
        __slots__ = "parser"

        def __init__(
            self, parser, parent: ParserRuleContext = None, invokingState: int = -1
        ):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ros_message(self, i: int = None):
            if i is None:
                return self.getTypedRuleContexts(RosMessageParser.Ros_messageContext)
            else:
                return self.getTypedRuleContext(RosMessageParser.Ros_messageContext, i)

        def MESSAGE_SEPARATOR(self):
            return self.getToken(RosMessageParser.MESSAGE_SEPARATOR, 0)

        def EOF(self):
            return self.getToken(RosMessageParser.EOF, 0)

        def getRuleIndex(self):
            return RosMessageParser.RULE_ros_service_input

        def enterRule(self, listener: ParseTreeListener):
            if hasattr(listener, "enterRos_service_input"):
                listener.enterRos_service_input(self)

        def exitRule(self, listener: ParseTreeListener):
            if hasattr(listener, "exitRos_service_input"):
                listener.exitRos_service_input(self)

        def accept(self, visitor: ParseTreeVisitor):
            if hasattr(visitor, "visitRos_service_input"):
                return visitor.visitRos_service_input(self)
            else:
                return visitor.visitChildren(self)

    def ros_service_input(self):

        localctx = RosMessageParser.Ros_service_inputContext(
            self, self._ctx, self.state
        )
        self.enterRule(localctx, 6, self.RULE_ros_service_input)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 67
            self.ros_message()
            self.state = 68
            self.match(RosMessageParser.MESSAGE_SEPARATOR)
            self.state = 69
            self.ros_message()
            self.state = 70
            self.match(RosMessageParser.EOF)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class Rosbag_inputContext(ParserRuleContext):
        __slots__ = "parser"

        def __init__(
            self, parser, parent: ParserRuleContext = None, invokingState: int = -1
        ):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ros_message(self):
            return self.getTypedRuleContext(RosMessageParser.Ros_messageContext, 0)

        def EOF(self):
            return self.getToken(RosMessageParser.EOF, 0)

        def rosbag_nested_message(self, i: int = None):
            if i is None:
                return self.getTypedRuleContexts(
                    RosMessageParser.Rosbag_nested_messageContext
                )
            else:
                return self.getTypedRuleContext(
                    RosMessageParser.Rosbag_nested_messageContext, i
                )

        def getRuleIndex(self):
            return RosMessageParser.RULE_rosbag_input

        def enterRule(self, listener: ParseTreeListener):
            if hasattr(listener, "enterRosbag_input"):
                listener.enterRosbag_input(self)

        def exitRule(self, listener: ParseTreeListener):
            if hasattr(listener, "exitRosbag_input"):
                listener.exitRosbag_input(self)

        def accept(self, visitor: ParseTreeVisitor):
            if hasattr(visitor, "visitRosbag_input"):
                return visitor.visitRosbag_input(self)
            else:
                return visitor.visitChildren(self)

    def rosbag_input(self):

        localctx = RosMessageParser.Rosbag_inputContext(self, self._ctx, self.state)
        self.enterRule(localctx, 8, self.RULE_rosbag_input)
        self._la = 0  # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 72
            self.ros_message()
            self.state = 76
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la == 30:
                self.state = 73
                self.rosbag_nested_message()
                self.state = 78
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 79
            self.match(RosMessageParser.EOF)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class Rosbag_nested_messageContext(ParserRuleContext):
        __slots__ = "parser"

        def __init__(
            self, parser, parent: ParserRuleContext = None, invokingState: int = -1
        ):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ROSBAG_MESSAGE_SEPARATOR(self):
            return self.getToken(RosMessageParser.ROSBAG_MESSAGE_SEPARATOR, 0)

        def ros_type(self):
            return self.getTypedRuleContext(RosMessageParser.Ros_typeContext, 0)

        def ros_message(self):
            return self.getTypedRuleContext(RosMessageParser.Ros_messageContext, 0)

        def getRuleIndex(self):
            return RosMessageParser.RULE_rosbag_nested_message

        def enterRule(self, listener: ParseTreeListener):
            if hasattr(listener, "enterRosbag_nested_message"):
                listener.enterRosbag_nested_message(self)

        def exitRule(self, listener: ParseTreeListener):
            if hasattr(listener, "exitRosbag_nested_message"):
                listener.exitRosbag_nested_message(self)

        def accept(self, visitor: ParseTreeVisitor):
            if hasattr(visitor, "visitRosbag_nested_message"):
                return visitor.visitRosbag_nested_message(self)
            else:
                return visitor.visitChildren(self)

    def rosbag_nested_message(self):

        localctx = RosMessageParser.Rosbag_nested_messageContext(
            self, self._ctx, self.state
        )
        self.enterRule(localctx, 10, self.RULE_rosbag_nested_message)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 81
            self.match(RosMessageParser.ROSBAG_MESSAGE_SEPARATOR)
            self.state = 82
            self.ros_type()
            self.state = 83
            self.ros_message()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class Ros_messageContext(ParserRuleContext):
        __slots__ = "parser"

        def __init__(
            self, parser, parent: ParserRuleContext = None, invokingState: int = -1
        ):
            super().__init__(parent, invokingState)
            self.parser = parser

        def field_declaration(self, i: int = None):
            if i is None:
                return self.getTypedRuleContexts(
                    RosMessageParser.Field_declarationContext
                )
            else:
                return self.getTypedRuleContext(
                    RosMessageParser.Field_declarationContext, i
                )

        def constant_declaration(self, i: int = None):
            if i is None:
                return self.getTypedRuleContexts(
                    RosMessageParser.Constant_declarationContext
                )
            else:
                return self.getTypedRuleContext(
                    RosMessageParser.Constant_declarationContext, i
                )

        def comment(self, i: int = None):
            if i is None:
                return self.getTypedRuleContexts(RosMessageParser.CommentContext)
            else:
                return self.getTypedRuleContext(RosMessageParser.CommentContext, i)

        def getRuleIndex(self):
            return RosMessageParser.RULE_ros_message

        def enterRule(self, listener: ParseTreeListener):
            if hasattr(listener, "enterRos_message"):
                listener.enterRos_message(self)

        def exitRule(self, listener: ParseTreeListener):
            if hasattr(listener, "exitRos_message"):
                listener.exitRos_message(self)

        def accept(self, visitor: ParseTreeVisitor):
            if hasattr(visitor, "visitRos_message"):
                return visitor.visitRos_message(self)
            else:
                return visitor.visitChildren(self)

    def ros_message(self):

        localctx = RosMessageParser.Ros_messageContext(self, self._ctx, self.state)
        self.enterRule(localctx, 12, self.RULE_ros_message)
        self._la = 0  # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 90
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while ((_la) & ~0x3F) == 0 and ((1 << _la) & 550301204478) != 0:
                self.state = 88
                self._errHandler.sync(self)
                la_ = self._interp.adaptivePredict(self._input, 2, self._ctx)
                if la_ == 1:
                    self.state = 85
                    self.field_declaration()
                    pass

                elif la_ == 2:
                    self.state = 86
                    self.constant_declaration()
                    pass

                elif la_ == 3:
                    self.state = 87
                    self.comment()
                    pass

                self.state = 92
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class Field_declarationContext(ParserRuleContext):
        __slots__ = "parser"

        def __init__(
            self, parser, parent: ParserRuleContext = None, invokingState: int = -1
        ):
            super().__init__(parent, invokingState)
            self.parser = parser

        def identifier(self):
            return self.getTypedRuleContext(RosMessageParser.IdentifierContext, 0)

        def type_(self):
            return self.getTypedRuleContext(RosMessageParser.Type_Context, 0)

        def array_type(self):
            return self.getTypedRuleContext(RosMessageParser.Array_typeContext, 0)

        def getRuleIndex(self):
            return RosMessageParser.RULE_field_declaration

        def enterRule(self, listener: ParseTreeListener):
            if hasattr(listener, "enterField_declaration"):
                listener.enterField_declaration(self)

        def exitRule(self, listener: ParseTreeListener):
            if hasattr(listener, "exitField_declaration"):
                listener.exitField_declaration(self)

        def accept(self, visitor: ParseTreeVisitor):
            if hasattr(visitor, "visitField_declaration"):
                return visitor.visitField_declaration(self)
            else:
                return visitor.visitChildren(self)

    def field_declaration(self):

        localctx = RosMessageParser.Field_declarationContext(
            self, self._ctx, self.state
        )
        self.enterRule(localctx, 14, self.RULE_field_declaration)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 95
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input, 4, self._ctx)
            if la_ == 1:
                self.state = 93
                self.type_()
                pass

            elif la_ == 2:
                self.state = 94
                self.array_type()
                pass

            self.state = 97
            self.identifier()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class Constant_declarationContext(ParserRuleContext):
        __slots__ = "parser"

        def __init__(
            self, parser, parent: ParserRuleContext = None, invokingState: int = -1
        ):
            super().__init__(parent, invokingState)
            self.parser = parser

        def integral_type(self):
            return self.getTypedRuleContext(RosMessageParser.Integral_typeContext, 0)

        def identifier(self):
            return self.getTypedRuleContext(RosMessageParser.IdentifierContext, 0)

        def ASSIGNMENT(self):
            return self.getToken(RosMessageParser.ASSIGNMENT, 0)

        def integral_value(self):
            return self.getTypedRuleContext(RosMessageParser.Integral_valueContext, 0)

        def floating_point_type(self):
            return self.getTypedRuleContext(
                RosMessageParser.Floating_point_typeContext, 0
            )

        def floating_point_value(self):
            return self.getTypedRuleContext(
                RosMessageParser.Floating_point_valueContext, 0
            )

        def boolean_type(self):
            return self.getTypedRuleContext(RosMessageParser.Boolean_typeContext, 0)

        def bool_value(self):
            return self.getTypedRuleContext(RosMessageParser.Bool_valueContext, 0)

        def string_type(self):
            return self.getTypedRuleContext(RosMessageParser.String_typeContext, 0)

        def STRING_ASSIGNMENT(self):
            return self.getToken(RosMessageParser.STRING_ASSIGNMENT, 0)

        def string_value(self):
            return self.getTypedRuleContext(RosMessageParser.String_valueContext, 0)

        def getRuleIndex(self):
            return RosMessageParser.RULE_constant_declaration

        def enterRule(self, listener: ParseTreeListener):
            if hasattr(listener, "enterConstant_declaration"):
                listener.enterConstant_declaration(self)

        def exitRule(self, listener: ParseTreeListener):
            if hasattr(listener, "exitConstant_declaration"):
                listener.exitConstant_declaration(self)

        def accept(self, visitor: ParseTreeVisitor):
            if hasattr(visitor, "visitConstant_declaration"):
                return visitor.visitConstant_declaration(self)
            else:
                return visitor.visitChildren(self)

    def constant_declaration(self):

        localctx = RosMessageParser.Constant_declarationContext(
            self, self._ctx, self.state
        )
        self.enterRule(localctx, 16, self.RULE_constant_declaration)
        try:
            self.state = 123
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [2, 3, 4, 5, 6, 7, 8, 9, 10, 11]:
                self.enterOuterAlt(localctx, 1)
                self.state = 99
                self.integral_type()
                self.state = 100
                self.identifier()
                self.state = 101
                self.match(RosMessageParser.ASSIGNMENT)
                self.state = 102
                self.integral_value()
                pass
            elif token in [12, 13]:
                self.enterOuterAlt(localctx, 2)
                self.state = 104
                self.floating_point_type()
                self.state = 105
                self.identifier()
                self.state = 106
                self.match(RosMessageParser.ASSIGNMENT)
                self.state = 109
                self._errHandler.sync(self)
                la_ = self._interp.adaptivePredict(self._input, 5, self._ctx)
                if la_ == 1:
                    self.state = 107
                    self.integral_value()
                    pass

                elif la_ == 2:
                    self.state = 108
                    self.floating_point_value()
                    pass

                pass
            elif token in [1]:
                self.enterOuterAlt(localctx, 3)
                self.state = 111
                self.boolean_type()
                self.state = 112
                self.identifier()
                self.state = 113
                self.match(RosMessageParser.ASSIGNMENT)
                self.state = 116
                self._errHandler.sync(self)
                token = self._input.LA(1)
                if token in [27, 28]:
                    self.state = 114
                    self.bool_value()
                    pass
                elif token in [21, 22, 25]:
                    self.state = 115
                    self.integral_value()
                    pass
                else:
                    raise NoViableAltException(self)

                pass
            elif token in [14]:
                self.enterOuterAlt(localctx, 4)
                self.state = 118
                self.string_type()
                self.state = 119
                self.identifier()
                self.state = 120
                self.match(RosMessageParser.STRING_ASSIGNMENT)
                self.state = 121
                self.string_value()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class CommentContext(ParserRuleContext):
        __slots__ = "parser"

        def __init__(
            self, parser, parent: ParserRuleContext = None, invokingState: int = -1
        ):
            super().__init__(parent, invokingState)
            self.parser = parser

        def COMMENT(self):
            return self.getToken(RosMessageParser.COMMENT, 0)

        def HASH(self):
            return self.getToken(RosMessageParser.HASH, 0)

        def STRING_HASH(self):
            return self.getToken(RosMessageParser.STRING_HASH, 0)

        def getRuleIndex(self):
            return RosMessageParser.RULE_comment

        def enterRule(self, listener: ParseTreeListener):
            if hasattr(listener, "enterComment"):
                listener.enterComment(self)

        def exitRule(self, listener: ParseTreeListener):
            if hasattr(listener, "exitComment"):
                listener.exitComment(self)

        def accept(self, visitor: ParseTreeVisitor):
            if hasattr(visitor, "visitComment"):
                return visitor.visitComment(self)
            else:
                return visitor.visitChildren(self)

    def comment(self):

        localctx = RosMessageParser.CommentContext(self, self._ctx, self.state)
        self.enterRule(localctx, 18, self.RULE_comment)
        self._la = 0  # Token type
        try:
            self.state = 128
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input, 8, self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 125
                _la = self._input.LA(1)
                if not (_la == 23 or _la == 39):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 126
                self.match(RosMessageParser.COMMENT)
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 127
                _la = self._input.LA(1)
                if not (_la == 23 or _la == 39):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                pass

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class IdentifierContext(ParserRuleContext):
        __slots__ = "parser"

        def __init__(
            self, parser, parent: ParserRuleContext = None, invokingState: int = -1
        ):
            super().__init__(parent, invokingState)
            self.parser = parser

        def IDENTIFIER(self):
            return self.getToken(RosMessageParser.IDENTIFIER, 0)

        def STRING_IDENTIFIER(self):
            return self.getToken(RosMessageParser.STRING_IDENTIFIER, 0)

        def INT8(self):
            return self.getToken(RosMessageParser.INT8, 0)

        def UINT8(self):
            return self.getToken(RosMessageParser.UINT8, 0)

        def INT16(self):
            return self.getToken(RosMessageParser.INT16, 0)

        def UINT16(self):
            return self.getToken(RosMessageParser.UINT16, 0)

        def INT32(self):
            return self.getToken(RosMessageParser.INT32, 0)

        def UINT32(self):
            return self.getToken(RosMessageParser.UINT32, 0)

        def INT64(self):
            return self.getToken(RosMessageParser.INT64, 0)

        def UINT64(self):
            return self.getToken(RosMessageParser.UINT64, 0)

        def BYTE(self):
            return self.getToken(RosMessageParser.BYTE, 0)

        def CHAR(self):
            return self.getToken(RosMessageParser.CHAR, 0)

        def FLOAT32(self):
            return self.getToken(RosMessageParser.FLOAT32, 0)

        def FLOAT64(self):
            return self.getToken(RosMessageParser.FLOAT64, 0)

        def TIME(self):
            return self.getToken(RosMessageParser.TIME, 0)

        def DURATION(self):
            return self.getToken(RosMessageParser.DURATION, 0)

        def STRING(self):
            return self.getToken(RosMessageParser.STRING, 0)

        def BOOL(self):
            return self.getToken(RosMessageParser.BOOL, 0)

        def TRUE(self):
            return self.getToken(RosMessageParser.TRUE, 0)

        def FALSE(self):
            return self.getToken(RosMessageParser.FALSE, 0)

        def getRuleIndex(self):
            return RosMessageParser.RULE_identifier

        def enterRule(self, listener: ParseTreeListener):
            if hasattr(listener, "enterIdentifier"):
                listener.enterIdentifier(self)

        def exitRule(self, listener: ParseTreeListener):
            if hasattr(listener, "exitIdentifier"):
                listener.exitIdentifier(self)

        def accept(self, visitor: ParseTreeVisitor):
            if hasattr(visitor, "visitIdentifier"):
                return visitor.visitIdentifier(self)
            else:
                return visitor.visitChildren(self)

    def identifier(self):

        localctx = RosMessageParser.IdentifierContext(self, self._ctx, self.state)
        self.enterRule(localctx, 20, self.RULE_identifier)
        self._la = 0  # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 130
            _la = self._input.LA(1)
            if not ((((_la) & ~0x3F) == 0 and ((1 << _la) & 18119524350) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class Type_Context(ParserRuleContext):
        __slots__ = "parser"

        def __init__(
            self, parser, parent: ParserRuleContext = None, invokingState: int = -1
        ):
            super().__init__(parent, invokingState)
            self.parser = parser

        def integral_type(self):
            return self.getTypedRuleContext(RosMessageParser.Integral_typeContext, 0)

        def floating_point_type(self):
            return self.getTypedRuleContext(
                RosMessageParser.Floating_point_typeContext, 0
            )

        def temporal_type(self):
            return self.getTypedRuleContext(RosMessageParser.Temporal_typeContext, 0)

        def boolean_type(self):
            return self.getTypedRuleContext(RosMessageParser.Boolean_typeContext, 0)

        def string_type(self):
            return self.getTypedRuleContext(RosMessageParser.String_typeContext, 0)

        def ros_type(self):
            return self.getTypedRuleContext(RosMessageParser.Ros_typeContext, 0)

        def getRuleIndex(self):
            return RosMessageParser.RULE_type_

        def enterRule(self, listener: ParseTreeListener):
            if hasattr(listener, "enterType_"):
                listener.enterType_(self)

        def exitRule(self, listener: ParseTreeListener):
            if hasattr(listener, "exitType_"):
                listener.exitType_(self)

        def accept(self, visitor: ParseTreeVisitor):
            if hasattr(visitor, "visitType_"):
                return visitor.visitType_(self)
            else:
                return visitor.visitChildren(self)

    def type_(self):

        localctx = RosMessageParser.Type_Context(self, self._ctx, self.state)
        self.enterRule(localctx, 22, self.RULE_type_)
        try:
            self.state = 138
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [2, 3, 4, 5, 6, 7, 8, 9, 10, 11]:
                self.enterOuterAlt(localctx, 1)
                self.state = 132
                self.integral_type()
                pass
            elif token in [12, 13]:
                self.enterOuterAlt(localctx, 2)
                self.state = 133
                self.floating_point_type()
                pass
            elif token in [15, 16]:
                self.enterOuterAlt(localctx, 3)
                self.state = 134
                self.temporal_type()
                pass
            elif token in [1]:
                self.enterOuterAlt(localctx, 4)
                self.state = 135
                self.boolean_type()
                pass
            elif token in [14]:
                self.enterOuterAlt(localctx, 5)
                self.state = 136
                self.string_type()
                pass
            elif token in [29]:
                self.enterOuterAlt(localctx, 6)
                self.state = 137
                self.ros_type()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class Ros_typeContext(ParserRuleContext):
        __slots__ = "parser"

        def __init__(
            self, parser, parent: ParserRuleContext = None, invokingState: int = -1
        ):
            super().__init__(parent, invokingState)
            self.parser = parser

        def IDENTIFIER(self, i: int = None):
            if i is None:
                return self.getTokens(RosMessageParser.IDENTIFIER)
            else:
                return self.getToken(RosMessageParser.IDENTIFIER, i)

        def SLASH(self):
            return self.getToken(RosMessageParser.SLASH, 0)

        def getRuleIndex(self):
            return RosMessageParser.RULE_ros_type

        def enterRule(self, listener: ParseTreeListener):
            if hasattr(listener, "enterRos_type"):
                listener.enterRos_type(self)

        def exitRule(self, listener: ParseTreeListener):
            if hasattr(listener, "exitRos_type"):
                listener.exitRos_type(self)

        def accept(self, visitor: ParseTreeVisitor):
            if hasattr(visitor, "visitRos_type"):
                return visitor.visitRos_type(self)
            else:
                return visitor.visitChildren(self)

    def ros_type(self):

        localctx = RosMessageParser.Ros_typeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 24, self.RULE_ros_type)
        try:
            self.state = 144
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input, 10, self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 140
                self.match(RosMessageParser.IDENTIFIER)
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 141
                self.match(RosMessageParser.IDENTIFIER)
                self.state = 142
                self.match(RosMessageParser.SLASH)
                self.state = 143
                self.match(RosMessageParser.IDENTIFIER)
                pass

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class Array_typeContext(ParserRuleContext):
        __slots__ = "parser"

        def __init__(
            self, parser, parent: ParserRuleContext = None, invokingState: int = -1
        ):
            super().__init__(parent, invokingState)
            self.parser = parser

        def variable_array_type(self):
            return self.getTypedRuleContext(
                RosMessageParser.Variable_array_typeContext, 0
            )

        def fixed_array_type(self):
            return self.getTypedRuleContext(RosMessageParser.Fixed_array_typeContext, 0)

        def getRuleIndex(self):
            return RosMessageParser.RULE_array_type

        def enterRule(self, listener: ParseTreeListener):
            if hasattr(listener, "enterArray_type"):
                listener.enterArray_type(self)

        def exitRule(self, listener: ParseTreeListener):
            if hasattr(listener, "exitArray_type"):
                listener.exitArray_type(self)

        def accept(self, visitor: ParseTreeVisitor):
            if hasattr(visitor, "visitArray_type"):
                return visitor.visitArray_type(self)
            else:
                return visitor.visitChildren(self)

    def array_type(self):

        localctx = RosMessageParser.Array_typeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 26, self.RULE_array_type)
        try:
            self.state = 148
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input, 11, self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 146
                self.variable_array_type()
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 147
                self.fixed_array_type()
                pass

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class Variable_array_typeContext(ParserRuleContext):
        __slots__ = "parser"

        def __init__(
            self, parser, parent: ParserRuleContext = None, invokingState: int = -1
        ):
            super().__init__(parent, invokingState)
            self.parser = parser

        def type_(self):
            return self.getTypedRuleContext(RosMessageParser.Type_Context, 0)

        def OPEN_BRACKET(self):
            return self.getToken(RosMessageParser.OPEN_BRACKET, 0)

        def STRING_OPEN_BRACKET(self):
            return self.getToken(RosMessageParser.STRING_OPEN_BRACKET, 0)

        def CLOSE_BRACKET(self):
            return self.getToken(RosMessageParser.CLOSE_BRACKET, 0)

        def STRING_CLOSE_BRACKET(self):
            return self.getToken(RosMessageParser.STRING_CLOSE_BRACKET, 0)

        def getRuleIndex(self):
            return RosMessageParser.RULE_variable_array_type

        def enterRule(self, listener: ParseTreeListener):
            if hasattr(listener, "enterVariable_array_type"):
                listener.enterVariable_array_type(self)

        def exitRule(self, listener: ParseTreeListener):
            if hasattr(listener, "exitVariable_array_type"):
                listener.exitVariable_array_type(self)

        def accept(self, visitor: ParseTreeVisitor):
            if hasattr(visitor, "visitVariable_array_type"):
                return visitor.visitVariable_array_type(self)
            else:
                return visitor.visitChildren(self)

    def variable_array_type(self):

        localctx = RosMessageParser.Variable_array_typeContext(
            self, self._ctx, self.state
        )
        self.enterRule(localctx, 28, self.RULE_variable_array_type)
        self._la = 0  # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 150
            self.type_()
            self.state = 151
            _la = self._input.LA(1)
            if not (_la == 18 or _la == 35):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
            self.state = 152
            _la = self._input.LA(1)
            if not (_la == 19 or _la == 36):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class Fixed_array_typeContext(ParserRuleContext):
        __slots__ = "parser"

        def __init__(
            self, parser, parent: ParserRuleContext = None, invokingState: int = -1
        ):
            super().__init__(parent, invokingState)
            self.parser = parser

        def type_(self):
            return self.getTypedRuleContext(RosMessageParser.Type_Context, 0)

        def OPEN_BRACKET(self):
            return self.getToken(RosMessageParser.OPEN_BRACKET, 0)

        def INTEGER_LITERAL(self):
            return self.getToken(RosMessageParser.INTEGER_LITERAL, 0)

        def CLOSE_BRACKET(self):
            return self.getToken(RosMessageParser.CLOSE_BRACKET, 0)

        def STRING_OPEN_BRACKET(self):
            return self.getToken(RosMessageParser.STRING_OPEN_BRACKET, 0)

        def STRING_INTEGER_LITERAL(self):
            return self.getToken(RosMessageParser.STRING_INTEGER_LITERAL, 0)

        def STRING_CLOSE_BRACKET(self):
            return self.getToken(RosMessageParser.STRING_CLOSE_BRACKET, 0)

        def getRuleIndex(self):
            return RosMessageParser.RULE_fixed_array_type

        def enterRule(self, listener: ParseTreeListener):
            if hasattr(listener, "enterFixed_array_type"):
                listener.enterFixed_array_type(self)

        def exitRule(self, listener: ParseTreeListener):
            if hasattr(listener, "exitFixed_array_type"):
                listener.exitFixed_array_type(self)

        def accept(self, visitor: ParseTreeVisitor):
            if hasattr(visitor, "visitFixed_array_type"):
                return visitor.visitFixed_array_type(self)
            else:
                return visitor.visitChildren(self)

    def fixed_array_type(self):

        localctx = RosMessageParser.Fixed_array_typeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 30, self.RULE_fixed_array_type)
        try:
            self.state = 164
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input, 12, self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 154
                self.type_()
                self.state = 155
                self.match(RosMessageParser.OPEN_BRACKET)
                self.state = 156
                self.match(RosMessageParser.INTEGER_LITERAL)
                self.state = 157
                self.match(RosMessageParser.CLOSE_BRACKET)
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 159
                self.type_()
                self.state = 160
                self.match(RosMessageParser.STRING_OPEN_BRACKET)
                self.state = 161
                self.match(RosMessageParser.STRING_INTEGER_LITERAL)
                self.state = 162
                self.match(RosMessageParser.STRING_CLOSE_BRACKET)
                pass

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class Integral_typeContext(ParserRuleContext):
        __slots__ = "parser"

        def __init__(
            self, parser, parent: ParserRuleContext = None, invokingState: int = -1
        ):
            super().__init__(parent, invokingState)
            self.parser = parser

        def INT8(self):
            return self.getToken(RosMessageParser.INT8, 0)

        def UINT8(self):
            return self.getToken(RosMessageParser.UINT8, 0)

        def INT16(self):
            return self.getToken(RosMessageParser.INT16, 0)

        def UINT16(self):
            return self.getToken(RosMessageParser.UINT16, 0)

        def INT32(self):
            return self.getToken(RosMessageParser.INT32, 0)

        def UINT32(self):
            return self.getToken(RosMessageParser.UINT32, 0)

        def INT64(self):
            return self.getToken(RosMessageParser.INT64, 0)

        def UINT64(self):
            return self.getToken(RosMessageParser.UINT64, 0)

        def BYTE(self):
            return self.getToken(RosMessageParser.BYTE, 0)

        def CHAR(self):
            return self.getToken(RosMessageParser.CHAR, 0)

        def getRuleIndex(self):
            return RosMessageParser.RULE_integral_type

        def enterRule(self, listener: ParseTreeListener):
            if hasattr(listener, "enterIntegral_type"):
                listener.enterIntegral_type(self)

        def exitRule(self, listener: ParseTreeListener):
            if hasattr(listener, "exitIntegral_type"):
                listener.exitIntegral_type(self)

        def accept(self, visitor: ParseTreeVisitor):
            if hasattr(visitor, "visitIntegral_type"):
                return visitor.visitIntegral_type(self)
            else:
                return visitor.visitChildren(self)

    def integral_type(self):

        localctx = RosMessageParser.Integral_typeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 32, self.RULE_integral_type)
        self._la = 0  # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 166
            _la = self._input.LA(1)
            if not ((((_la) & ~0x3F) == 0 and ((1 << _la) & 4092) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class Floating_point_typeContext(ParserRuleContext):
        __slots__ = "parser"

        def __init__(
            self, parser, parent: ParserRuleContext = None, invokingState: int = -1
        ):
            super().__init__(parent, invokingState)
            self.parser = parser

        def FLOAT32(self):
            return self.getToken(RosMessageParser.FLOAT32, 0)

        def FLOAT64(self):
            return self.getToken(RosMessageParser.FLOAT64, 0)

        def getRuleIndex(self):
            return RosMessageParser.RULE_floating_point_type

        def enterRule(self, listener: ParseTreeListener):
            if hasattr(listener, "enterFloating_point_type"):
                listener.enterFloating_point_type(self)

        def exitRule(self, listener: ParseTreeListener):
            if hasattr(listener, "exitFloating_point_type"):
                listener.exitFloating_point_type(self)

        def accept(self, visitor: ParseTreeVisitor):
            if hasattr(visitor, "visitFloating_point_type"):
                return visitor.visitFloating_point_type(self)
            else:
                return visitor.visitChildren(self)

    def floating_point_type(self):

        localctx = RosMessageParser.Floating_point_typeContext(
            self, self._ctx, self.state
        )
        self.enterRule(localctx, 34, self.RULE_floating_point_type)
        self._la = 0  # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 168
            _la = self._input.LA(1)
            if not (_la == 12 or _la == 13):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class Temporal_typeContext(ParserRuleContext):
        __slots__ = "parser"

        def __init__(
            self, parser, parent: ParserRuleContext = None, invokingState: int = -1
        ):
            super().__init__(parent, invokingState)
            self.parser = parser

        def TIME(self):
            return self.getToken(RosMessageParser.TIME, 0)

        def DURATION(self):
            return self.getToken(RosMessageParser.DURATION, 0)

        def getRuleIndex(self):
            return RosMessageParser.RULE_temporal_type

        def enterRule(self, listener: ParseTreeListener):
            if hasattr(listener, "enterTemporal_type"):
                listener.enterTemporal_type(self)

        def exitRule(self, listener: ParseTreeListener):
            if hasattr(listener, "exitTemporal_type"):
                listener.exitTemporal_type(self)

        def accept(self, visitor: ParseTreeVisitor):
            if hasattr(visitor, "visitTemporal_type"):
                return visitor.visitTemporal_type(self)
            else:
                return visitor.visitChildren(self)

    def temporal_type(self):

        localctx = RosMessageParser.Temporal_typeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 36, self.RULE_temporal_type)
        self._la = 0  # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 170
            _la = self._input.LA(1)
            if not (_la == 15 or _la == 16):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class String_typeContext(ParserRuleContext):
        __slots__ = "parser"

        def __init__(
            self, parser, parent: ParserRuleContext = None, invokingState: int = -1
        ):
            super().__init__(parent, invokingState)
            self.parser = parser

        def STRING(self):
            return self.getToken(RosMessageParser.STRING, 0)

        def getRuleIndex(self):
            return RosMessageParser.RULE_string_type

        def enterRule(self, listener: ParseTreeListener):
            if hasattr(listener, "enterString_type"):
                listener.enterString_type(self)

        def exitRule(self, listener: ParseTreeListener):
            if hasattr(listener, "exitString_type"):
                listener.exitString_type(self)

        def accept(self, visitor: ParseTreeVisitor):
            if hasattr(visitor, "visitString_type"):
                return visitor.visitString_type(self)
            else:
                return visitor.visitChildren(self)

    def string_type(self):

        localctx = RosMessageParser.String_typeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 38, self.RULE_string_type)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 172
            self.match(RosMessageParser.STRING)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class Boolean_typeContext(ParserRuleContext):
        __slots__ = "parser"

        def __init__(
            self, parser, parent: ParserRuleContext = None, invokingState: int = -1
        ):
            super().__init__(parent, invokingState)
            self.parser = parser

        def BOOL(self):
            return self.getToken(RosMessageParser.BOOL, 0)

        def getRuleIndex(self):
            return RosMessageParser.RULE_boolean_type

        def enterRule(self, listener: ParseTreeListener):
            if hasattr(listener, "enterBoolean_type"):
                listener.enterBoolean_type(self)

        def exitRule(self, listener: ParseTreeListener):
            if hasattr(listener, "exitBoolean_type"):
                listener.exitBoolean_type(self)

        def accept(self, visitor: ParseTreeVisitor):
            if hasattr(visitor, "visitBoolean_type"):
                return visitor.visitBoolean_type(self)
            else:
                return visitor.visitChildren(self)

    def boolean_type(self):

        localctx = RosMessageParser.Boolean_typeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 40, self.RULE_boolean_type)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 174
            self.match(RosMessageParser.BOOL)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class SignContext(ParserRuleContext):
        __slots__ = "parser"

        def __init__(
            self, parser, parent: ParserRuleContext = None, invokingState: int = -1
        ):
            super().__init__(parent, invokingState)
            self.parser = parser

        def PLUS(self):
            return self.getToken(RosMessageParser.PLUS, 0)

        def MINUS(self):
            return self.getToken(RosMessageParser.MINUS, 0)

        def getRuleIndex(self):
            return RosMessageParser.RULE_sign

        def enterRule(self, listener: ParseTreeListener):
            if hasattr(listener, "enterSign"):
                listener.enterSign(self)

        def exitRule(self, listener: ParseTreeListener):
            if hasattr(listener, "exitSign"):
                listener.exitSign(self)

        def accept(self, visitor: ParseTreeVisitor):
            if hasattr(visitor, "visitSign"):
                return visitor.visitSign(self)
            else:
                return visitor.visitChildren(self)

    def sign(self):

        localctx = RosMessageParser.SignContext(self, self._ctx, self.state)
        self.enterRule(localctx, 42, self.RULE_sign)
        self._la = 0  # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 176
            _la = self._input.LA(1)
            if not (_la == 21 or _la == 22):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class Integral_valueContext(ParserRuleContext):
        __slots__ = "parser"

        def __init__(
            self, parser, parent: ParserRuleContext = None, invokingState: int = -1
        ):
            super().__init__(parent, invokingState)
            self.parser = parser

        def INTEGER_LITERAL(self):
            return self.getToken(RosMessageParser.INTEGER_LITERAL, 0)

        def sign(self):
            return self.getTypedRuleContext(RosMessageParser.SignContext, 0)

        def getRuleIndex(self):
            return RosMessageParser.RULE_integral_value

        def enterRule(self, listener: ParseTreeListener):
            if hasattr(listener, "enterIntegral_value"):
                listener.enterIntegral_value(self)

        def exitRule(self, listener: ParseTreeListener):
            if hasattr(listener, "exitIntegral_value"):
                listener.exitIntegral_value(self)

        def accept(self, visitor: ParseTreeVisitor):
            if hasattr(visitor, "visitIntegral_value"):
                return visitor.visitIntegral_value(self)
            else:
                return visitor.visitChildren(self)

    def integral_value(self):

        localctx = RosMessageParser.Integral_valueContext(self, self._ctx, self.state)
        self.enterRule(localctx, 44, self.RULE_integral_value)
        self._la = 0  # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 179
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la == 21 or _la == 22:
                self.state = 178
                self.sign()

            self.state = 181
            self.match(RosMessageParser.INTEGER_LITERAL)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class Floating_point_valueContext(ParserRuleContext):
        __slots__ = "parser"

        def __init__(
            self, parser, parent: ParserRuleContext = None, invokingState: int = -1
        ):
            super().__init__(parent, invokingState)
            self.parser = parser

        def REAL_LITERAL(self):
            return self.getToken(RosMessageParser.REAL_LITERAL, 0)

        def sign(self):
            return self.getTypedRuleContext(RosMessageParser.SignContext, 0)

        def getRuleIndex(self):
            return RosMessageParser.RULE_floating_point_value

        def enterRule(self, listener: ParseTreeListener):
            if hasattr(listener, "enterFloating_point_value"):
                listener.enterFloating_point_value(self)

        def exitRule(self, listener: ParseTreeListener):
            if hasattr(listener, "exitFloating_point_value"):
                listener.exitFloating_point_value(self)

        def accept(self, visitor: ParseTreeVisitor):
            if hasattr(visitor, "visitFloating_point_value"):
                return visitor.visitFloating_point_value(self)
            else:
                return visitor.visitChildren(self)

    def floating_point_value(self):

        localctx = RosMessageParser.Floating_point_valueContext(
            self, self._ctx, self.state
        )
        self.enterRule(localctx, 46, self.RULE_floating_point_value)
        self._la = 0  # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 184
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la == 21 or _la == 22:
                self.state = 183
                self.sign()

            self.state = 186
            self.match(RosMessageParser.REAL_LITERAL)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class Bool_valueContext(ParserRuleContext):
        __slots__ = "parser"

        def __init__(
            self, parser, parent: ParserRuleContext = None, invokingState: int = -1
        ):
            super().__init__(parent, invokingState)
            self.parser = parser

        def TRUE(self):
            return self.getToken(RosMessageParser.TRUE, 0)

        def FALSE(self):
            return self.getToken(RosMessageParser.FALSE, 0)

        def getRuleIndex(self):
            return RosMessageParser.RULE_bool_value

        def enterRule(self, listener: ParseTreeListener):
            if hasattr(listener, "enterBool_value"):
                listener.enterBool_value(self)

        def exitRule(self, listener: ParseTreeListener):
            if hasattr(listener, "exitBool_value"):
                listener.exitBool_value(self)

        def accept(self, visitor: ParseTreeVisitor):
            if hasattr(visitor, "visitBool_value"):
                return visitor.visitBool_value(self)
            else:
                return visitor.visitChildren(self)

    def bool_value(self):

        localctx = RosMessageParser.Bool_valueContext(self, self._ctx, self.state)
        self.enterRule(localctx, 48, self.RULE_bool_value)
        self._la = 0  # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 188
            _la = self._input.LA(1)
            if not (_la == 27 or _la == 28):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class String_valueContext(ParserRuleContext):
        __slots__ = "parser"

        def __init__(
            self, parser, parent: ParserRuleContext = None, invokingState: int = -1
        ):
            super().__init__(parent, invokingState)
            self.parser = parser

        def STRING_VALUE(self):
            return self.getToken(RosMessageParser.STRING_VALUE, 0)

        def getRuleIndex(self):
            return RosMessageParser.RULE_string_value

        def enterRule(self, listener: ParseTreeListener):
            if hasattr(listener, "enterString_value"):
                listener.enterString_value(self)

        def exitRule(self, listener: ParseTreeListener):
            if hasattr(listener, "exitString_value"):
                listener.exitString_value(self)

        def accept(self, visitor: ParseTreeVisitor):
            if hasattr(visitor, "visitString_value"):
                return visitor.visitString_value(self)
            else:
                return visitor.visitChildren(self)

    def string_value(self):

        localctx = RosMessageParser.String_valueContext(self, self._ctx, self.state)
        self.enterRule(localctx, 50, self.RULE_string_value)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 190
            self.match(RosMessageParser.STRING_VALUE)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx
