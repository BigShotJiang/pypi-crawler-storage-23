class DefinitionNotFoundError(Exception):
    pass


class DeserializationError(Exception):
    pass
