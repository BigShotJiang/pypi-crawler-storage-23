"""Test package for action-level permission system (E8.1)."""
from __future__ import annotations
