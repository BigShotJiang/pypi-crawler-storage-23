"""Tests for the isolation subpackage."""
