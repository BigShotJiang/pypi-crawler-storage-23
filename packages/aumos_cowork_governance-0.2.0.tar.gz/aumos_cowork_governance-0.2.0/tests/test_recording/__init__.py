"""Tests for the recording subpackage."""
