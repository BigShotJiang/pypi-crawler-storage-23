"""Tests for the screen subpackage."""
