from enum import Enum


class Extra(str, Enum):
    ignore = "ignore"
    forbid = "forbid"
