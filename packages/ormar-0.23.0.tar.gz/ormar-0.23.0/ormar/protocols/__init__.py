from ormar.protocols.queryset_protocol import QuerySetProtocol
from ormar.protocols.relation_protocol import RelationProtocol

__all__ = ["QuerySetProtocol", "RelationProtocol"]
