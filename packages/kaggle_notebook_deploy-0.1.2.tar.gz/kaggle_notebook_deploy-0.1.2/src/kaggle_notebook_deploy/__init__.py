"""kaggle-notebook-deploy: git pushするだけでKaggle NotebookをデプロイするCLIツール"""

__version__ = "0.1.0"
