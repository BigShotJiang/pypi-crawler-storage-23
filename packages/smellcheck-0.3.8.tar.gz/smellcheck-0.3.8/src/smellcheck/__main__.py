"""Allow ``python -m smellcheck``."""

from smellcheck.detector import main

if __name__ == "__main__":
    main()
