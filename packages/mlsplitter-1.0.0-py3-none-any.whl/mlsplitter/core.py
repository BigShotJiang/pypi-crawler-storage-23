"""
mlsplitter
~~~~~~~~~~~~~~~~~~~
Utilities for splitting features/target and creating train/dev/test splits.
"""

from __future__ import annotations

from typing import Optional, Tuple, Union

import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split

# ---------------------------------------------------------------------------
# Type aliases
# ---------------------------------------------------------------------------
ArrayLike = Union[pd.DataFrame, pd.Series, np.ndarray]


# ---------------------------------------------------------------------------
# x_y_splitter
# ---------------------------------------------------------------------------

def x_y_splitter(
    data: pd.DataFrame,
    *,
    column_name: Optional[str] = None,
    column_index: Optional[int] = None,
) -> Tuple[pd.DataFrame, pd.Series]:
    """Split a DataFrame into features *X* and target *y*.

    Exactly one of *column_name* or *column_index* must be provided.  When
    both are given they must refer to the same column; otherwise a
    ``ValueError`` is raised.

    Parameters
    ----------
    data:
        Input DataFrame.
    column_name:
        Name of the target column.
    column_index:
        Integer position of the target column (0-based).

    Returns
    -------
    X : pd.DataFrame
        All columns **except** the target column.
    y : pd.Series
        The target column.

    Raises
    ------
    TypeError
        If *data* is not a ``pd.DataFrame``.
    ValueError
        If neither or both identifiers are given (and they disagree), if the
        column name is not found, or if the column index is out of range.
    """
    if not isinstance(data, pd.DataFrame):
        raise TypeError(
            f"'data' must be a pandas DataFrame, got {type(data).__name__!r}."
        )
    if data.empty:
        raise ValueError("'data' is empty.")

    n_cols = len(data.columns)

    # ── Resolve index from whichever identifier(s) were supplied ────────────
    if column_name is None and column_index is None:
        raise ValueError(
            "Provide at least one of 'column_name' or 'column_index'."
        )

    if column_name is not None and column_index is not None:
        # Both supplied — validate consistency
        if column_name not in data.columns:
            raise ValueError(
                f"Column {column_name!r} not found in DataFrame. "
                f"Available columns: {list(data.columns)}"
            )
        resolved_index = data.columns.get_loc(column_name)
        if not isinstance(column_index, int):
            raise TypeError(
                f"'column_index' must be an int, got {type(column_index).__name__!r}."
            )
        if column_index < 0 or column_index >= n_cols:
            raise ValueError(
                f"'column_index' {column_index} is out of range for a "
                f"DataFrame with {n_cols} column(s)."
            )
        if column_index != resolved_index:
            raise ValueError(
                f"'column_name' {column_name!r} is at index {resolved_index}, "
                f"but 'column_index' {column_index} was given. They must match."
            )
        target_index = resolved_index

    elif column_name is not None:
        if not isinstance(column_name, str):
            raise TypeError(
                f"'column_name' must be a str, got {type(column_name).__name__!r}."
            )
        if column_name not in data.columns:
            raise ValueError(
                f"Column {column_name!r} not found in DataFrame. "
                f"Available columns: {list(data.columns)}"
            )
        target_index = data.columns.get_loc(column_name)

    else:  # column_index is not None
        if not isinstance(column_index, int):
            raise TypeError(
                f"'column_index' must be an int, got {type(column_index).__name__!r}."
            )
        # Support negative indexing
        if column_index < -n_cols or column_index >= n_cols:
            raise ValueError(
                f"'column_index' {column_index} is out of range for a "
                f"DataFrame with {n_cols} column(s)."
            )
        target_index = column_index % n_cols  # normalise negative indices

    # ── Build X and y ────────────────────────────────────────────────────────
    target_col = data.columns[target_index]
    X = data.drop(columns=[target_col])
    y = data[target_col]
    return X, y


# ---------------------------------------------------------------------------
# train_test_splitter
# ---------------------------------------------------------------------------

def train_test_splitter(
    X: ArrayLike,
    y: ArrayLike,
    *,
    test_size: float = 0.2,
    random_state: Optional[int] = 42,
    shuffle: bool = True,
    stratify: Optional[ArrayLike] = None,
) -> Tuple[ArrayLike, ArrayLike, ArrayLike, ArrayLike]:
    """Thin, validated wrapper around :func:`sklearn.model_selection.train_test_split`.

    Parameters
    ----------
    X:
        Feature matrix.
    y:
        Target vector.
    test_size:
        Proportion of the dataset to include in the test split (0 < test_size < 1).
    random_state:
        Controls the shuffling applied to the data before the split.
    shuffle:
        Whether to shuffle the data before splitting.
    stratify:
        If not ``None``, data is split in a stratified fashion using this array.

    Returns
    -------
    x_train, x_test, y_train, y_test
    """
    _validate_array_like(X, "X")
    _validate_array_like(y, "y")
    _validate_split_size(test_size, "test_size")
    _validate_lengths_match(X, y)

    return train_test_split(
        X,
        y,
        test_size=test_size,
        random_state=random_state,
        shuffle=shuffle,
        stratify=stratify,
    )


# ---------------------------------------------------------------------------
# train_dev_test_splitter
# ---------------------------------------------------------------------------

def train_dev_test_splitter(
    X: ArrayLike,
    y: ArrayLike,
    *,
    dev_size: float = 0.1,
    test_size: float = 0.2,
    random_state: Optional[int] = 42,
    shuffle: bool = True,
    stratify: Optional[ArrayLike] = None,
) -> Tuple[ArrayLike, ArrayLike, ArrayLike, ArrayLike, ArrayLike, ArrayLike]:
    """Split data into train / dev (validation) / test sets.

    The split is performed in two stages:

    1. ``(train+dev)`` vs ``test``  — using *test_size* as a fraction of the
       full dataset.
    2. ``train`` vs ``dev``         — using *dev_size* as a fraction of the
       full dataset (re-scaled internally).

    Parameters
    ----------
    X:
        Feature matrix.
    y:
        Target vector.
    dev_size:
        Proportion of the **full** dataset to include in the dev split.
    test_size:
        Proportion of the **full** dataset to include in the test split.
    random_state:
        Seed for reproducibility.
    shuffle:
        Whether to shuffle before splitting.
    stratify:
        Stratification array applied to the first split only.

    Returns
    -------
    x_train, x_dev, x_test, y_train, y_dev, y_test

    Raises
    ------
    ValueError
        If *dev_size* + *test_size* >= 1.
    """
    _validate_array_like(X, "X")
    _validate_array_like(y, "y")
    _validate_split_size(dev_size, "dev_size")
    _validate_split_size(test_size, "test_size")
    _validate_lengths_match(X, y)

    if dev_size + test_size >= 1.0:
        raise ValueError(
            f"'dev_size' ({dev_size}) + 'test_size' ({test_size}) must be "
            f"less than 1.0, but got {dev_size + test_size:.4f}."
        )

    # Stage 1: split off the test set
    x_traindev, x_test, y_traindev, y_test = train_test_split(
        X,
        y,
        test_size=test_size,
        random_state=random_state,
        shuffle=shuffle,
        stratify=stratify,
    )

    # Stage 2: split dev from the remaining data
    # dev_size is a fraction of the *full* dataset; re-scale to the remainder.
    dev_size_adjusted = dev_size / (1.0 - test_size)

    x_train, x_dev, y_train, y_dev = train_test_split(
        x_traindev,
        y_traindev,
        test_size=dev_size_adjusted,
        random_state=random_state,
        shuffle=shuffle,
    )

    return x_train, x_dev, x_test, y_train, y_dev, y_test


# ---------------------------------------------------------------------------
# Private helpers
# ---------------------------------------------------------------------------

def _validate_array_like(obj: object, name: str) -> None:
    """Raise ``TypeError`` if *obj* is not a recognised array-like."""
    if not isinstance(obj, (pd.DataFrame, pd.Series, np.ndarray, list)):
        raise TypeError(
            f"'{name}' must be a DataFrame, Series, ndarray, or list; "
            f"got {type(obj).__name__!r}."
        )
    # Zero-length check
    try:
        if len(obj) == 0:
            raise ValueError(f"'{name}' must not be empty.")
    except TypeError:
        pass  # scalar — will fail later in sklearn


def _validate_split_size(value: float, name: str) -> None:
    """Raise ``ValueError`` / ``TypeError`` for invalid split fractions."""
    if not isinstance(value, (int, float)):
        raise TypeError(
            f"'{name}' must be a float in (0, 1), got {type(value).__name__!r}."
        )
    if not (0.0 < float(value) < 1.0):
        raise ValueError(
            f"'{name}' must be in the open interval (0, 1), got {value!r}."
        )


def _validate_lengths_match(X: ArrayLike, y: ArrayLike) -> None:
    """Raise ``ValueError`` if *X* and *y* have different numbers of samples."""
    len_X = len(X)
    len_y = len(y)
    if len_X != len_y:
        raise ValueError(
            f"'X' and 'y' must have the same number of samples, "
            f"but got len(X)={len_X} and len(y)={len_y}."
        )
