"""
mlsplitter
~~~~~~~~~~
Convenient helpers for splitting DataFrames into features/target and
creating reproducible train / dev / test splits.

Quick start::

    from mlsplitter import x_y_splitter, train_test_splitter, train_dev_test_splitter

    X, y = x_y_splitter(df, column_name="price")
    x_train, x_test, y_train, y_test = train_test_splitter(X, y)
    x_train, x_dev, x_test, y_train, y_dev, y_test = train_dev_test_splitter(X, y)
"""

from .core import (
    train_dev_test_splitter,
    train_test_splitter,
    x_y_splitter,
)

__all__ = [
    "x_y_splitter",
    "train_test_splitter",
    "train_dev_test_splitter",
]

__version__ = "1.0.0"
__author__ = "Fares Ayman"
