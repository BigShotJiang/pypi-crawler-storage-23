"""
NeuroFlow - A local-first, node-based ML orchestrator

Usage:
    $ neuroflow              # Start the server
    $ neuroflow --port 3000  # Start on custom port
    $ neuroflow --help       # Show help

Or use programmatically:
    >>> from app import run_server
    >>> run_server(port=8000)
"""

__version__ = "0.1.0"
__author__ = "Aayush Gokhale"


def run_server(host: str = "127.0.0.1", port: int = 8000, open_browser: bool = True):
    """Start the NeuroFlow server programmatically."""
    from .cli import main
    import sys
    
    args = ["neuroflow", "--host", host, "--port", str(port)]
    if not open_browser:
        args.append("--no-browser")
    
    sys.argv = args
    main()
