# 🧠 NeuroFlow

A **local-first, node-based ML orchestrator** with a visual pipeline builder.

![NeuroFlow](https://img.shields.io/badge/version-0.1.0-green)
![Python](https://img.shields.io/badge/python-3.9+-blue)
![License](https://img.shields.io/badge/license-MIT-blue)

## ✨ Features

- 🎨 **Visual Pipeline Builder** - Drag-and-drop nodes to create ML workflows
- 🔌 **Node-Based Architecture** - Connect data loaders, preprocessors, models, and evaluators
- 📊 **Built-in Visualizations** - View metrics, charts, and model performance
- 💾 **Local-First** - All data stays on your machine
- 📦 **Export/Import** - Save and share workflows as JSON
- 🚀 **One Command** - Install and run with a single command

## 🚀 Quick Start

### Installation

```bash
# Install from PyPI (coming soon)
pip install neuroflow

# Or install from source
git clone https://github.com/aayushgokhale/neuroflow.git
cd neuroflow/NeuroFlow
pip install -e .
```

### Running NeuroFlow

```bash
# Start NeuroFlow (opens browser automatically)
neuroflow

# Or specify a custom port
neuroflow --port 3000

# Don't open browser automatically
neuroflow --no-browser
```

Visit `http://localhost:8000` to access the visual pipeline builder.

## 📖 Usage

### Building a Pipeline

1. **Drag nodes** from the left sidebar onto the canvas
2. **Connect nodes** by dragging from output ports to input ports
3. **Configure nodes** by clicking on them and editing parameters
4. **Run the workflow** by clicking the "Run Workflow" button
5. **View results** in the Results Panel with metrics and charts

### Node Types

| Category | Nodes |
|----------|-------|
| **Data** | CSV Loader, SQL Query, API Fetch |
| **Preprocessing** | Normalize, Encode, Split Data |
| **Models** | Random Forest, Neural Net, XGBoost |
| **Evaluate** | Accuracy Chart, Loss Curve, Confusion Matrix |

### Example Workflow

```
CSV Loader → Split Data → Random Forest → Evaluator
```

## 🛠️ Development

### Prerequisites

- Python 3.9+
- Node.js 18+
- pnpm (recommended)

### Setup

```bash
# Clone the repository
git clone https://github.com/aayushgokhale/neuroflow.git
cd neuroflow

# Install backend dependencies
cd NeuroFlow
pip install -e ".[dev]"

# Install frontend dependencies
cd ../Frontend
pnpm install

# Run development servers
# Terminal 1: Backend
cd NeuroFlow && uvicorn app.main:app --reload

# Terminal 2: Frontend
cd Frontend && pnpm dev
```

### Building for Distribution

```bash
cd NeuroFlow
./build.sh
pip install -e .
```

## 📁 Project Structure

```
neuroflow/
├── Frontend/                 # Next.js frontend
│   ├── app/                  # App router pages
│   ├── components/           # React components
│   │   └── neuroflow/        # NeuroFlow-specific components
│   └── public/               # Static assets
├── NeuroFlow/                # Python backend package
│   ├── app/                  # FastAPI application
│   │   ├── cli.py            # CLI entry point
│   │   ├── main.py           # FastAPI app
│   │   ├── engine.py         # Workflow execution engine
│   │   ├── schemas.py        # Pydantic models
│   │   └── executors/        # Node executors
│   ├── data/                 # Demo datasets
│   ├── static/               # Built frontend (after build)
│   └── pyproject.toml        # Package configuration
```

## 🔧 API Reference

### REST Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| `GET` | `/health` | Health check |
| `POST` | `/workflows/execute` | Execute a workflow |
| `GET` | `/workflows/{id}/status` | Get execution status |
| `POST` | `/data/upload` | Upload data files |
| `GET` | `/models/{id}/download` | Download trained model |

### WebSocket

Connect to `/ws/workflow/{run_id}` for real-time execution progress updates.

## 📝 License

MIT License - see [LICENSE](LICENSE) for details.

## 🤝 Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## 📧 Contact

Created by [Aayush Gokhale](https://github.com/aayushgokhale)
