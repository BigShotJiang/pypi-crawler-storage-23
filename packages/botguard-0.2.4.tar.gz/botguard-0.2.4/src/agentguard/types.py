"""Type definitions for AgentGuard SDK."""

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional


@dataclass
class ShieldVerdict:
    """Result of AgentGuard Shield analysis."""
    action: str  # "allowed", "blocked_input", "blocked_output"
    reason: Optional[str] = None
    confidence: Optional[float] = None
    analysis_path: Optional[str] = None
    matched_patterns: Optional[List[str]] = None
    pii_detections: Optional[List[Dict[str, Any]]] = None
    guardrail_violation: Optional[str] = None
    policy_violation: Optional[str] = None
    latency_ms: Optional[int] = None

    @property
    def blocked(self) -> bool:
        return self.action != "allowed"


@dataclass
class ShieldResult:
    """Wraps an OpenAI response with Shield analysis metadata."""
    response: Any
    shield: ShieldVerdict = field(default_factory=lambda: ShieldVerdict(action="allowed"))

    @property
    def blocked(self) -> bool:
        return self.shield.blocked

    @property
    def content(self) -> Optional[str]:
        try:
            return self.response.choices[0].message.content
        except (AttributeError, IndexError):
            return None
