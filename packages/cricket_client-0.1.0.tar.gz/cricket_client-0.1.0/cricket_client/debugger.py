"""Debugger API client — smart contract vulnerability scanning."""

from __future__ import annotations

from cricket_client.http import HttpClient
from cricket_client.types import AnalysisResult, Language


class DebuggerClient:
    def __init__(self, http: HttpClient):
        self._http = http

    async def analyze(self, source: str, language: Language | str) -> AnalysisResult:
        """Analyze source code for vulnerabilities and gas optimizations."""
        data = await self._http.post(
            "/debugger/analyze",
            json={"source": source, "language": str(language)},
        )
        return AnalysisResult(**data)
