"""Main Cricket client — unified entry point for all API modules."""

from __future__ import annotations

from dataclasses import dataclass

from cricket_client.http import HttpClient
from cricket_client.pulse import PulseClient
from cricket_client.mantis import MantisClient
from cricket_client.firefly import FireflyClient
from cricket_client.chirps import ChirpsClient
from cricket_client.debugger import DebuggerClient


@dataclass
class CricketConfig:
    """Configuration for the Cricket client."""

    base_url: str = "https://api.cricket.vylth.com/api/v1"
    api_key: str = ""
    timeout: float = 30.0


class CricketClient:
    """Unified client for Cricket Protocol APIs."""

    def __init__(self, config: CricketConfig | None = None, **kwargs):
        cfg = config or CricketConfig(**kwargs)
        self._http = HttpClient(cfg.base_url, cfg.api_key, cfg.timeout)
        self._pulse: PulseClient | None = None
        self._mantis: MantisClient | None = None
        self._firefly: FireflyClient | None = None
        self._chirps: ChirpsClient | None = None
        self._debugger: DebuggerClient | None = None

    @property
    def pulse(self) -> PulseClient:
        if self._pulse is None:
            self._pulse = PulseClient(self._http)
        return self._pulse

    @property
    def mantis(self) -> MantisClient:
        if self._mantis is None:
            self._mantis = MantisClient(self._http)
        return self._mantis

    @property
    def firefly(self) -> FireflyClient:
        if self._firefly is None:
            self._firefly = FireflyClient(self._http)
        return self._firefly

    @property
    def chirps(self) -> ChirpsClient:
        if self._chirps is None:
            self._chirps = ChirpsClient(self._http)
        return self._chirps

    @property
    def debugger(self) -> DebuggerClient:
        if self._debugger is None:
            self._debugger = DebuggerClient(self._http)
        return self._debugger

    async def close(self) -> None:
        """Close the underlying HTTP client."""
        await self._http.close()

    async def __aenter__(self) -> CricketClient:
        return self

    async def __aexit__(self, *args) -> None:
        await self.close()
