"""Domain types mirroring Go shared/types and Rust core types."""

from __future__ import annotations

from enum import Enum
from typing import Optional

from pydantic import BaseModel


# --- Enums ---

class Chain(str, Enum):
    SOLANA = "solana"
    ETHEREUM = "ethereum"
    BASE = "base"
    ARBITRUM = "arbitrum"


class VenueType(str, Enum):
    CEX = "cex"
    DEX = "dex"


class RiskRating(str, Enum):
    LOW = "low"
    MODERATE = "moderate"
    HIGH = "high"
    CRITICAL = "critical"


class Severity(str, Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


class Tier(str, Enum):
    SCOUT = "scout"
    HUNTER = "hunter"
    APEX = "apex"
    COLONY = "colony"


class WalletStyle(str, Enum):
    EARLY_ACCUMULATOR = "early_accumulator"
    MOMENTUM_TRADER = "momentum_trader"
    SNIPER = "sniper"
    WHALE_MOVER = "whale_mover"
    SMART_CONTRACT_DEPLOYER = "smart_contract_deployer"
    UNKNOWN = "unknown"


class Language(str, Enum):
    SOLIDITY = "solidity"
    RUST = "rust"
    VYPER = "vyper"


class SignalType(str, Enum):
    ACCUMULATION = "accumulation"
    DIVERGENCE = "divergence"
    EXODUS = "exodus"


class SignalStrength(str, Enum):
    WEAK = "weak"
    MODERATE = "moderate"
    STRONG = "strong"


# --- Pulse types ---

class Venue(BaseModel):
    name: str
    venue_type: VenueType
    chain: Optional[Chain] = None


class PriceQuote(BaseModel):
    venue: str
    venue_type: VenueType
    bid: Optional[float] = None
    ask: Optional[float] = None
    mid: float
    volume_24h: float
    liquidity_usd: Optional[float] = None
    timestamp: str
    latency_us: int


class VenuePricePair(BaseModel):
    venue: str
    price: float


class SpreadAnalysis(BaseModel):
    best_bid: Optional[VenuePricePair] = None
    best_ask: Optional[VenuePricePair] = None
    spread_bps: float
    venue_count: int


# --- Mantis types ---

class RiskFlag(BaseModel):
    check: str
    severity: Severity
    status: str
    detail: str


class RiskScore(BaseModel):
    score: int
    rating: RiskRating
    flags: list[RiskFlag]
    scanned_at: str


class ScanResult(BaseModel):
    token_address: str
    mint_authority_revoked: bool
    freeze_authority_revoked: bool
    lp_locked: bool
    lp_lock_duration_days: Optional[int] = None
    top_10_holder_pct: float
    deployer_wallet_age_days: int
    upgrade_authority_revoked: bool
    metadata_mutable: bool
    flags: list[RiskFlag]


class ScanResponse(BaseModel):
    scan: ScanResult
    risk_score: RiskScore


# --- Firefly types ---

class WalletProfile(BaseModel):
    address: str
    chain: Chain
    score: int
    total_trades: int
    win_rate: float
    avg_return_pct: float
    total_pnl_usd: float
    style: WalletStyle
    active_since: str


class SignalEvidence(BaseModel):
    smart_wallets_count: int
    avg_wallet_score: int
    total_volume_usd: float
    time_window_hours: int


class Signal(BaseModel):
    signal_type: SignalType
    token_address: str
    token_symbol: str
    strength: SignalStrength
    evidence: SignalEvidence
    detected_at: str


# --- Debugger types ---

class SuggestedFix(BaseModel):
    description: str
    code_before: str
    code_after: str


class Finding(BaseModel):
    severity: Severity
    finding_type: str
    location: str
    description: str
    fix: Optional[SuggestedFix] = None


class GasOptimization(BaseModel):
    optimization_type: str
    location: str
    estimated_savings: str
    suggestion: SuggestedFix


class AnalysisResult(BaseModel):
    scan_id: str
    language: Language
    findings: list[Finding]
    gas_optimizations: list[GasOptimization]
    overall_risk_score: int


# --- Chirps types ---

class ChirpChannel(BaseModel):
    id: str
    type: str
    active: bool
    created_at: str
    user_id: Optional[str] = None
    config: Optional[dict] = None
    filters: Optional[dict] = None


class ChirpRecord(BaseModel):
    id: str
    channel_id: str
    type: str
    status: str
    sent_at: str


# --- Watchlist ---

class WatchlistEntry(BaseModel):
    token_address: str
    added_at: str
    risk_score: int
    risk_rating: RiskRating
