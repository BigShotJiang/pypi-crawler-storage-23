"""Firefly API client — wallet intelligence and smart money signals."""

from __future__ import annotations

from urllib.parse import quote

from cricket_client.http import HttpClient
from cricket_client.types import WalletProfile, Signal


class FireflyClient:
    def __init__(self, http: HttpClient):
        self._http = http

    async def get_wallet(self, address: str) -> WalletProfile:
        """Get a wallet's intelligence profile."""
        data = await self._http.get(f"/firefly/wallet/{quote(address)}")
        return WalletProfile(**data)

    async def get_signals(self) -> list[Signal]:
        """Get active smart money signals."""
        data = await self._http.get("/firefly/signals")
        return [Signal(**s) for s in data]

    async def get_leaderboard(self) -> list[WalletProfile]:
        """Get the top wallets leaderboard."""
        data = await self._http.get("/firefly/leaderboard")
        return [WalletProfile(**w) for w in data]

    async def track(self, address: str) -> dict:
        """Start tracking a wallet."""
        return await self._http.post("/firefly/track", json={"address": address})
