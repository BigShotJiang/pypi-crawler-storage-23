"""Mantis API client — rug-pull detection and token risk scoring."""

from __future__ import annotations

from urllib.parse import quote

from cricket_client.http import HttpClient
from cricket_client.types import ScanResponse, RiskScore, WatchlistEntry


class MantisClient:
    def __init__(self, http: HttpClient):
        self._http = http

    async def scan(self, token: str) -> ScanResponse:
        """Run a full security scan on a token."""
        data = await self._http.get(f"/mantis/scan/{quote(token)}")
        return ScanResponse(**data)

    async def get_score(self, token: str) -> RiskScore:
        """Get only the risk score for a token."""
        data = await self._http.get(f"/mantis/score/{quote(token)}")
        return RiskScore(**data)

    async def add_to_watchlist(self, tokens: list[str]) -> dict:
        """Add tokens to the watchlist."""
        return await self._http.post("/mantis/watchlist", json={"tokens": tokens})

    async def get_watchlist(self) -> list[WatchlistEntry]:
        """Get all watched tokens."""
        data = await self._http.get("/mantis/watchlist")
        return [WatchlistEntry(**e) for e in data]
