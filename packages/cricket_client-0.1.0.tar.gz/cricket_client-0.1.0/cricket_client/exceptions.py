"""Cricket API exceptions."""


class CricketError(Exception):
    """Raised when the Cricket API returns an error."""

    def __init__(self, code: str, message: str, status: int):
        self.code = code
        self.message = message
        self.status = status
        super().__init__(f"[{code}] {message} (HTTP {status})")
