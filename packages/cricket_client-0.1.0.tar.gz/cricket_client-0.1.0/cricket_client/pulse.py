"""Pulse API client — unified price feeds across CEX and DEX venues."""

from __future__ import annotations

from urllib.parse import quote

from cricket_client.http import HttpClient
from cricket_client.types import PriceQuote, SpreadAnalysis, Venue


class PulseClient:
    def __init__(self, http: HttpClient):
        self._http = http

    async def get_price(self, token: str) -> list[PriceQuote]:
        """Get price quotes for a token across all venues."""
        data = await self._http.get(f"/pulse/price/{quote(token)}")
        return [PriceQuote(**q) for q in data]

    async def get_spread(self, token: str) -> SpreadAnalysis:
        """Get cross-venue spread analysis for a token."""
        data = await self._http.get(f"/pulse/spread/{quote(token)}")
        return SpreadAnalysis(**data)

    async def get_venues(self) -> list[Venue]:
        """List all supported venues."""
        data = await self._http.get("/pulse/venues")
        return [Venue(**v) for v in data]
