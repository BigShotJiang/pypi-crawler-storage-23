"""Base HTTP client for Cricket API."""

from __future__ import annotations

from typing import Any, TypeVar

import httpx

from cricket_client.exceptions import CricketError

T = TypeVar("T")


class HttpClient:
    """Async HTTP client with API key auth and error handling."""

    def __init__(self, base_url: str, api_key: str, timeout: float = 30.0):
        self._client = httpx.AsyncClient(
            base_url=base_url.rstrip("/"),
            headers={
                "Content-Type": "application/json",
                "X-API-Key": api_key,
            },
            timeout=timeout,
        )

    async def get(self, path: str) -> Any:
        return await self._request("GET", path)

    async def post(self, path: str, json: Any = None) -> Any:
        return await self._request("POST", path, json=json)

    async def delete(self, path: str) -> None:
        resp = await self._client.delete(path)
        if resp.status_code not in (200, 204):
            raise CricketError("REQUEST_FAILED", f"HTTP {resp.status_code}", resp.status_code)

    async def _request(self, method: str, path: str, json: Any = None) -> Any:
        resp = await self._client.request(method, path, json=json)
        data = resp.json()

        if not data.get("success") or data.get("error"):
            err = data.get("error", {})
            raise CricketError(
                code=err.get("code", "UNKNOWN_ERROR"),
                message=err.get("message", "Unknown error"),
                status=resp.status_code,
            )

        return data.get("data")

    async def close(self) -> None:
        await self._client.aclose()
