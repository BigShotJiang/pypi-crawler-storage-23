"""Chirps API client — notification channel management."""

from __future__ import annotations

from urllib.parse import quote

from cricket_client.http import HttpClient
from cricket_client.types import ChirpChannel, ChirpRecord


class ChirpsClient:
    def __init__(self, http: HttpClient):
        self._http = http

    async def create_channel(self, channel: dict) -> ChirpChannel:
        """Create a notification channel."""
        data = await self._http.post("/chirps/channels", json=channel)
        return ChirpChannel(**data)

    async def list_channels(self) -> list[ChirpChannel]:
        """List all notification channels."""
        data = await self._http.get("/chirps/channels")
        return [ChirpChannel(**c) for c in data]

    async def delete_channel(self, channel_id: str) -> None:
        """Delete a notification channel."""
        await self._http.delete(f"/chirps/channels/{quote(channel_id)}")

    async def test_channel(self, channel_id: str) -> dict:
        """Send a test chirp to verify channel configuration."""
        return await self._http.post(f"/chirps/test/{quote(channel_id)}")

    async def get_history(self) -> list[ChirpRecord]:
        """Get notification delivery history."""
        data = await self._http.get("/chirps/history")
        return [ChirpRecord(**r) for r in data]
