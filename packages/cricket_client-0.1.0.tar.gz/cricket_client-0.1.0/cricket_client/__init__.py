"""Cricket Protocol Python Client — DeFi intelligence and execution suite."""

from cricket_client.client import CricketClient, CricketConfig
from cricket_client.types import *  # noqa: F401,F403
from cricket_client.exceptions import CricketError

__all__ = ["CricketClient", "CricketConfig", "CricketError"]
__version__ = "0.1.0"
