# cricket-client

Python client for [Cricket Protocol](https://github.com/VYLTH/cricket) — DeFi intelligence and execution suite.

## Install

```bash
pip install cricket-client
```

## Usage

```python
import asyncio
from cricket_client import CricketClient

async def main():
    async with CricketClient(api_key="your-api-key") as client:
        # Price feeds
        quotes = await client.pulse.get_price("SOL")

        # Rug-pull scanning
        scan = await client.mantis.scan("token-address")

        # Wallet intelligence
        profile = await client.firefly.get_wallet("wallet-address")

        # Smart contract analysis
        result = await client.debugger.analyze(source_code, "solidity")

asyncio.run(main())
```

## Modules

- **Pulse** — unified price feeds across CEX and DEX venues
- **Mantis** — rug-pull detection and token risk scoring
- **Firefly** — wallet intelligence and smart money signals
- **Chirps** — notification channel management
- **Debugger** — smart contract vulnerability scanning
