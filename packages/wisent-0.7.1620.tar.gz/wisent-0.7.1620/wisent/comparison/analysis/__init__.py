"""Auto-grouped modules."""
