from strapi_client.models.base_populatable import BasePopulatable


class BaseComponent(BasePopulatable):
    """Strapi component."""
