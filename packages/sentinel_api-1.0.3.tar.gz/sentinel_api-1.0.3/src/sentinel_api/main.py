"""FastAPI application entrypoint for SentinelAPI.

This module wires auth, rate limiting, proxying, and request logging into a
single API-edge service with one architecture and tunable runtime knobs.
"""

import logging
import time

import httpx
from fastapi import Depends, FastAPI, HTTPException, Request, Response
from redis.asyncio import Redis

from sentinel_api.config import settings
from sentinel_api.models.security import AuthContext
from sentinel_api.services.auth import AuthError, JWTAuthenticator
from sentinel_api.services.proxy import forward_request
from sentinel_api.services.rate_limiter import RateLimiter as RedisRateLimiter
from sentinel_api.services.rate_limiter_base import RateLimiterProtocol
from sentinel_api.services.request_logger import build_request_logger

logging.basicConfig(level=getattr(logging, settings.log_level.upper(), logging.INFO))
logger = logging.getLogger(__name__)

app = FastAPI(title=settings.app_name)


async def _build_rate_limiter() -> tuple[RateLimiterProtocol, Redis | None]:
    """Instantiate Redis-backed rate limiter."""
    redis_client = Redis.from_url(settings.redis_url, decode_responses=True)
    rate_limiter = RedisRateLimiter(redis_client=redis_client, settings=settings)
    return rate_limiter, redis_client


@app.on_event("startup")
async def startup() -> None:
    """Initialize shared clients/services and store them on app state."""
    rate_limiter, redis_client = await _build_rate_limiter()
    app.state.http_client = httpx.AsyncClient(timeout=settings.request_timeout_seconds)
    app.state.redis_client = redis_client
    app.state.rate_limiter = rate_limiter
    app.state.request_logger = build_request_logger(settings=settings)
    app.state.authenticator = JWTAuthenticator(settings=settings)

    logger.info(
        "SentinelAPI startup rate_limit_backend=redis request_log_backend=dynamodb",
    )


@app.on_event("shutdown")
async def shutdown() -> None:
    """Close network clients gracefully on process shutdown."""
    await app.state.http_client.aclose()
    if app.state.redis_client is not None:
        await app.state.redis_client.aclose()


def extract_bearer_token(request: Request) -> str:
    """Extract Bearer token from Authorization header or raise 401."""
    header = request.headers.get("authorization", "")
    if not header.lower().startswith("bearer "):
        raise HTTPException(status_code=401, detail="Missing Bearer token")
    return header[7:].strip()


async def authenticate(request: Request) -> AuthContext:
    """Validate JWT and return authenticated user context."""
    token = extract_bearer_token(request)
    try:
        return app.state.authenticator.decode_token(token)
    except AuthError as exc:
        raise HTTPException(status_code=401, detail=str(exc)) from exc


@app.get("/health")
async def health() -> dict[str, str]:
    """Liveness endpoint that also returns active backend wiring info."""
    return {
        "status": "ok",
        "rateLimitBackend": "redis",
        "requestLogBackend": "dynamodb",
    }


@app.get("/auth/verify")
async def auth_verify(auth: AuthContext = Depends(authenticate)) -> dict[str, str | bool | None]:
    """Return auth context for quick JWT verification testing."""
    return {
        "authenticated": True,
        "userId": auth.user_id,
        "tokenId": auth.token_id,
    }


@app.api_route("/proxy/{full_path:path}", methods=["GET", "POST", "PUT", "PATCH", "DELETE"])
async def proxy(
    full_path: str,
    request: Request,
    auth: AuthContext = Depends(authenticate),
) -> Response:
    """Authenticate, rate-limit, proxy upstream call, and persist request telemetry."""
    start = time.perf_counter()
    allowed, tokens_remaining = await app.state.rate_limiter.allow_request(auth.user_id)

    if not allowed:
        detail = "User blocked" if tokens_remaining is None else "Rate limit exceeded"
        raise HTTPException(status_code=429, detail=detail)

    response = await forward_request(
        request=request,
        client=app.state.http_client,
        upstream_base_url=settings.upstream_base_url,
    )

    latency_ms = (time.perf_counter() - start) * 1000
    client_host = request.client.host if request.client else "unknown"
    user_agent = request.headers.get("user-agent", "unknown")

    try:
        await app.state.request_logger.log_request(
            user_id=auth.user_id,
            endpoint=f"/{full_path}",
            latency_ms=latency_ms,
            status_code=response.status_code,
            ip_address=client_host,
            user_agent=user_agent,
        )
    except Exception as exc:  # noqa: BLE001
        logger.warning(
            "Request logging failed for user=%s endpoint=/%s: %s",
            auth.user_id,
            full_path,
            exc,
        )

    response.headers["x-rate-limit-remaining"] = str(int(tokens_remaining or 0))
    return response
