# Django Bub Translate 🚀

**ترجمه خودکار قالب‌های جنگو با هوش مصنوعی**

این کتابخانه به شما کمک می‌کند تا فرآیند چندزبانه کردن پروژه‌های جنگو را خودکار کنید.

## ویژگی‌ها
- اسکن خودکار فایل‌های HTML و اضافه کردن تگ‌های `{% trans %}`.
- ترجمه خودکار فایل‌های `.po` با استفاده از Google Translate.
- مدیریت هوشمند تگ‌های جینجا و جلوگیری از ترجمه کدهای برنامه‌نویسی.

## نصب

```bash
pip install django-autotranslate-ai
```

سپس `django_autotranslate` را به `INSTALLED_APPS` در فایل `settings.py` اضافه کنید:

```python
INSTALLED_APPS = [
    ...
    'django_autotranslate',
]
```

## نحوه استفاده

### ۱. آماده‌سازی تنظیمات پروژه (Settings)
برای پیکربندی خودکار `settings.py` و افزودن زبان‌های مورد نظر:

```bash
python manage.py setup_i18n --langs fa ar
```
این دستور کارهای زیر را انجام می‌دهد:
- فعال‌سازی `USE_I18N = True`.
- افزودن `LocaleMiddleware` به لیست میان‌افزارها.
- تعریف `LANGUAGES` و `LOCALE_PATHS`.
- ایجاد پوشه `locale` در ریشه پروژه.

### ۲. آماده‌سازی تگ‌ها
برای اضافه کردن تگ‌های ترجمه به تمام فایل‌های HTML در پوشه قالب‌ها:

```bash
python manage.py prepare_tags templates/
```

### ۳. ترجمه خودکار
برای استخراج پیام‌ها و ترجمه آن‌ها به زبان مورد نظر (مثلاً فارسی):

```bash
python manage.py auto_translate --lang fa
```

### ۴. مدیریت با رابط گرافیکی (GUI)
برای مشاهده، جستجو و ویرایش دستی ترجمه‌ها در یک محیط گرافیکی:

```bash
python manage.py translate_gui --lang fa
```
این دستور یک پنجره باز می‌کند که در آن می‌توانید:
- تمامی عبارات استخراج شده را ببینید.
- در میان متون اصلی و ترجمه‌ها جستجو کنید.
- ترجمه‌ها را به صورت دستی ویرایش و ذخیره کنید.
- فایل `.mo` را به صورت خودکار کامپایل کنید.


### ۵. تنظیمات موتورهای ترجمه (اختیاری)
به طور پیش‌فرض از Google Translate (رایگان) استفاده می‌شود. برای استفاده از سایر سرویس‌ها، تنظیمات زیر را به `settings.py` اضافه کنید:

```python
# برای DeepL
AUTOTRANSLATE_ENGINE = 'deepl'
AUTOTRANSLATE_API_KEY = 'your-deepl-api-key'

# برای Microsoft Azure
AUTOTRANSLATE_ENGINE = 'microsoft'
AUTOTRANSLATE_API_KEY = 'your-azure-key'
AUTOTRANSLATE_REGION = 'global' # اختیاری
```

## پیش‌نیازها
- Python 3.7+
- Django 3.0+
- BeautifulSoup4
- googletrans (نسخه alpha برای پایداری بیشتر)
- polib (برای مدیریت فایل‌های ترجمه به صورت خالص در پایتون)
- requests (در صورت استفاده از DeepL یا Microsoft)

> **نکته:** این کتابخانه **هیچ وابستگی به gettext ندارد** و تمامی مراحل استخراج، ترجمه و کامپایل را به صورت داخلی انجام می‌دهد. این یعنی روی ویندوز، لینوکس و مک بدون نصب هیچ ابزار اضافه‌ای کار می‌کند.


## لایسنس
MIT
