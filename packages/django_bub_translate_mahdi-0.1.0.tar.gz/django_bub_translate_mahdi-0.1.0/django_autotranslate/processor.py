import os
import re
from bs4 import BeautifulSoup, NavigableString

class SmartHTMLProcessor:
    """
    مسئول اسکن کردن فایل های HTML و جایگذاری هوشمند تگ های ترجمه
    """
    def __init__(self):
        self.ignored_tags = ['script', 'style', 'code', 'pre', 'noscript']
        # الگو برای تشخیص متغیرهای جنگو/جینجا {{ variable }}
        self.variable_pattern = re.compile(r'\{\{\s*.*?\s*\}\}')
        # الگو برای تشخیص اینکه آیا متن فقط شامل اعداد، علائم یا کلمات فنی خاص است
        self.technical_pattern = re.compile(r'^[0-9\s\.\,\!\?\-\_\/\:\%\&\#\*\+\=\(\)\[\]\{\}\<\>]+$')
        self.common_tech_terms = {'html', 'css', 'js', 'json', 'xml', 'api', 'url', 'http', 'https', 'id', 'class'}

    def is_technical_content(self, text):
        clean_text = text.strip().lower()
        if not clean_text:
            return True
        if self.technical_pattern.match(clean_text):
            return True
        if clean_text in self.common_tech_terms:
            return True
        return False

    def should_translate(self, text, parent_name):
        if not text.strip():
            return False
        if parent_name in self.ignored_tags:
            return False
        # اگر قبلا تگ trans یا blocktrans داشته باشد
        if '{% trans' in text or '{% blocktrans' in text:
            return False
        if self.is_technical_content(text):
            return False
        return True

    def process_file(self, file_path):
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read()

        if '{% load i18n %}' not in content:
            content = '{% load i18n %}\n' + content

        soup = BeautifulSoup(content, 'html.parser')
        
        for element in soup.find_all(string=True):
            if isinstance(element, NavigableString):
                original_text = element.string.strip()
                if self.should_translate(original_text, element.parent.name):
                    # تشخیص اینکه آیا متغیر در متن وجود دارد
                    if self.variable_pattern.search(original_text):
                        # استفاده از blocktrans برای متن‌های دارای متغیر
                        new_tag = f'{{% blocktrans %}}{original_text}{{% endblocktrans %}}'
                    else:
                        # استفاده از trans برای متن‌های ساده
                        safe_text = original_text.replace('"', "'")
                        new_tag = f'{{% trans "{safe_text}" %}}'
                    
                    element.replace_with(new_tag)

        final_html = soup.decode(formatter=None)
        
        with open(file_path, 'w', encoding='utf-8') as f:
            f.write(final_html)
