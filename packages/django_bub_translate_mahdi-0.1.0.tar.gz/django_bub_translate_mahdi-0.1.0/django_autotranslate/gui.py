import tkinter as tk
from tkinter import ttk, messagebox
import polib
import os
from pathlib import Path

class TranslationGUI:
    def __init__(self, root, po_path, lang_code):
        self.root = root
        self.po_path = po_path
        self.lang_code = lang_code
        self.root.title(f"Django AutoTranslate GUI - [{lang_code}]")
        self.root.geometry("900x600")
        
        self.po = polib.pofile(str(po_path))
        self.entries = list(self.po)
        self.filtered_entries = self.entries[:]
        
        self.setup_ui()

    def setup_ui(self):
        # Header / Search
        top_frame = ttk.Frame(self.root, padding="10")
        top_frame.pack(fill=tk.X)
        
        ttk.Label(top_frame, text="Search:").pack(side=tk.LEFT)
        self.search_var = tk.StringVar()
        self.search_var.trace_add("write", self.filter_entries)
        ttk.Entry(top_frame, textvariable=self.search_var, width=40).pack(side=tk.LEFT, padx=10)
        
        ttk.Label(top_frame, text=f"Total: {len(self.entries)} | Language: {self.lang_code}").pack(side=tk.RIGHT)

        # Table (Treeview)
        table_frame = ttk.Frame(self.root, padding="10")
        table_frame.pack(fill=tk.BOTH, expand=True)
        
        columns = ("msgid", "msgstr")
        self.tree = ttk.Treeview(table_frame, columns=columns, show="headings")
        self.tree.heading("msgid", text="Original (msgid)")
        self.tree.heading("msgstr", text="Translation (msgstr)")
        self.tree.column("msgid", width=400)
        self.tree.column("msgstr", width=400)
        
        scrollbar = ttk.Scrollbar(table_frame, orient=tk.VERTICAL, command=self.tree.yview)
        self.tree.configure(yscroll=scrollbar.set)
        
        self.tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        self.tree.bind("<<TreeviewSelect>>", self.on_select)

        # Edit Area
        edit_frame = ttk.LabelFrame(self.root, text="Edit Translation", padding="10")
        edit_frame.pack(fill=tk.X, padx=10, pady=10)
        
        ttk.Label(edit_frame, text="Original:").grid(row=0, column=0, sticky=tk.W)
        self.orig_text = tk.Text(edit_frame, height=3, width=80, state=tk.DISABLED, bg="#f0f0f0")
        self.orig_text.grid(row=1, column=0, columnspan=2, pady=5)
        
        ttk.Label(edit_frame, text="Translation:").grid(row=2, column=0, sticky=tk.W)
        self.trans_text = tk.Text(edit_frame, height=3, width=80)
        self.trans_text.grid(row=3, column=0, columnspan=2, pady=5)
        
        btn_frame = ttk.Frame(edit_frame)
        btn_frame.grid(row=4, column=0, columnspan=2, pady=5)
        
        ttk.Button(btn_frame, text="Apply Changes", command=self.save_entry).pack(side=tk.LEFT, padx=5)
        ttk.Button(btn_frame, text="Save to File & Compile", command=self.save_to_disk).pack(side=tk.LEFT, padx=5)

        self.refresh_table()

    def filter_entries(self, *args):
        query = self.search_var.get().lower()
        self.filtered_entries = [
            e for e in self.entries 
            if query in e.msgid.lower() or query in e.msgstr.lower()
        ]
        self.refresh_table()

    def refresh_table(self):
        for item in self.tree.get_children():
            self.tree.delete(item)
        for i, entry in enumerate(self.filtered_entries):
            self.tree.insert("", tk.END, iid=i, values=(entry.msgid, entry.msgstr))

    def on_select(self, event):
        selected = self.tree.selection()
        if not selected:
            return
        idx = int(selected[0])
        entry = self.filtered_entries[idx]
        
        self.orig_text.config(state=tk.NORMAL)
        self.orig_text.delete("1.0", tk.END)
        self.orig_text.insert("1.0", entry.msgid)
        self.orig_text.config(state=tk.DISABLED)
        
        self.trans_text.delete("1.0", tk.END)
        self.trans_text.insert("1.0", entry.msgstr)

    def save_entry(self):
        selected = self.tree.selection()
        if not selected:
            messagebox.showwarning("Warning", "Please select an entry first.")
            return
        
        idx = int(selected[0])
        new_val = self.trans_text.get("1.0", tk.END).strip()
        self.filtered_entries[idx].msgstr = new_val
        self.refresh_table()

    def save_to_disk(self):
        try:
            self.po.save(str(self.po_path))
            mo_path = self.po_path.with_suffix('.mo')
            self.po.save_as_mofile(str(mo_path))
            messagebox.showinfo("Success", f"Saved and compiled successfully!\n{mo_path}")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to save: {e}")

def launch_gui(po_path, lang_code):
    root = tk.Tk()
    app = TranslationGUI(root, po_path, lang_code)
    root.mainloop()
