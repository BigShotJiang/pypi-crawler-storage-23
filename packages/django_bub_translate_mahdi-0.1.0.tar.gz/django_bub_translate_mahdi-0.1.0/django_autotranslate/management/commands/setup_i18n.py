import os
import re
from django.core.management.base import BaseCommand
from django.conf import settings

class Command(BaseCommand):
    """
    Command: python manage.py setup_i18n --langs fa ar
    """
    help = 'Automatically configures settings.py for i18n and adds target languages'

    def add_arguments(self, parser):
        parser.add_argument('--langs', nargs='+', required=True, help='List of language codes to add (e.g. fa ar es)')

    def handle(self, *args, **options):
        langs = options['langs']
        
        # پیدا کردن مسیر settings.py
        settings_module = os.environ.get('DJANGO_SETTINGS_MODULE')
        if not settings_module:
            self.stdout.write(self.style.ERROR("DJANGO_SETTINGS_MODULE not found. Make sure you are in a Django project."))
            return

        # تبدیل dot notation به مسیر فایل
        try:
            settings_path = settings_module.replace('.', '/') + '.py'
            if not os.path.exists(settings_path):
                # تلاش برای پیدا کردن در دایرکتوری جاری اگر مسیر مستقیم کار نکرد
                settings_path = os.path.join(*settings_module.split('.')) + '.py'
        except Exception:
            self.stdout.write(self.style.ERROR("Could not determine settings.py path."))
            return

        if not os.path.exists(settings_path):
            self.stdout.write(self.style.ERROR(f"Settings file not found at {settings_path}"))
            return

        with open(settings_path, 'r', encoding='utf-8') as f:
            content = f.read()

        # 1. فعال‌سازی تنظیمات پایه i18n
        changes_made = False
        
        config_map = {
            'USE_I18N': 'True',
            'USE_L10N': 'True',
            'USE_TZ': 'True',
        }

        for key, value in config_map.items():
            pattern = rf'^{key}\s*=\s*.*'
            replacement = f'{key} = {value}'
            if re.search(pattern, content, re.MULTILINE):
                if f'{key} = {value}' not in content:
                    content = re.sub(pattern, replacement, content, flags=re.MULTILINE)
                    changes_made = True
            else:
                content += f'\n{key} = {value}'
                changes_made = True

        # 2. تنظیم LOCALE_PATHS
        if 'LOCALE_PATHS' not in content:
            locale_path_setting = "\nLOCALE_PATHS = [\n    BASE_DIR / 'locale',\n]"
            content += locale_path_setting
            changes_made = True
            # ایجاد پوشه locale اگر وجود ندارد
            if not os.path.exists('locale'):
                os.makedirs('locale')
                self.stdout.write("Created 'locale' directory.")

        # 3. تنظیم LANGUAGES
        languages_list = "LANGUAGES = [\n    ('en', 'English'),"
        for lang in langs:
            # نام زبان را ساده در نظر می‌گیریم (می‌توان بعداً کامل‌تر کرد)
            languages_list += f"\n    ('{lang}', '{lang.upper()}'),"
        languages_list += "\n]"

        if 'LANGUAGES = [' in content:
            # جایگزینی LANGUAGES موجود (ساده شده)
            content = re.sub(r'LANGUAGES\s*=\s*\[.*?\]', languages_list, content, flags=re.DOTALL)
        else:
            content += f'\n\n{languages_list}'
        
        changes_made = True

        # 4. افزودن Middleware اگر نباشد
        if 'django.middleware.locale.LocaleMiddleware' not in content:
            if 'MIDDLEWARE = [' in content:
                content = content.replace(
                    "'django.middleware.common.CommonMiddleware',",
                    "'django.middleware.common.CommonMiddleware',\n    'django.middleware.locale.LocaleMiddleware',"
                )
                changes_made = True

        if changes_made:
            with open(settings_path, 'w', encoding='utf-8') as f:
                f.write(content)
            self.stdout.write(self.style.SUCCESS(f"Successfully updated {settings_path} with i18n configurations."))
        else:
            self.stdout.write("No changes needed in settings.py.")
