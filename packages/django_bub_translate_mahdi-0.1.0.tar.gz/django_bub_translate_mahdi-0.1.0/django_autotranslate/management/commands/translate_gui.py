import os
from django.core.management.base import BaseCommand
from django.conf import settings
from pathlib import Path
from django_autotranslate.gui import launch_gui

class Command(BaseCommand):
    """
    Command: python manage.py translate_gui --lang fa
    """
    help = 'Opens a GUI to manage, search, and edit translations for a specific language'

    def add_arguments(self, parser):
        parser.add_argument('--lang', type=str, required=True, help='Target language code (e.g., fa, ar, es)')

    def handle(self, *args, **options):
        self.stdout.write(self.style.SUCCESS("Django Bub Translate by: https://github.com/mahdi1212-max\n"))
        target_lang = options['lang']
        
        locale_dir = Path(settings.BASE_DIR) / 'locale'
        po_path = locale_dir / target_lang / 'LC_MESSAGES' / 'django.po'

        if not po_path.exists():
            self.stdout.write(self.style.ERROR(f"PO file not found at {po_path}. Run auto_translate first."))
            return

        self.stdout.write(f"Launching GUI for '{target_lang}'...")
        try:
            launch_gui(po_path, target_lang)
        except Exception as e:
            self.stdout.write(self.style.ERROR(f"Failed to launch GUI: {e}"))
            self.stdout.write(self.style.WARNING("Make sure you have Tkinter installed (usually comes with Python)."))
