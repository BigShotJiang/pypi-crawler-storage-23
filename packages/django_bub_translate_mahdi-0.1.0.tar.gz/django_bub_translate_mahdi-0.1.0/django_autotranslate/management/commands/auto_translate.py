import os
import re
import time
import polib
from django.core.management.base import BaseCommand
from googletrans import Translator
from django.conf import settings
from pathlib import Path

class Command(BaseCommand):
    """
    Command: python manage.py auto_translate --lang fa
    """
    help = 'Automatically extracts, translates and compiles Django messages WITHOUT gettext'

    def add_arguments(self, parser):
        parser.add_argument('--lang', type=str, required=True, help='Target language code (e.g., fa, ar, es)')
        parser.add_argument('--no-input', action='store_true', help='Do not ask for confirmation')

    def extract_messages_from_project(self):
        """
        استخراج دستی msgid ها از فایل‌های HTML و پایتون (gettext, gettext_lazy)
        """
        msgids = set()
        
        # ۱. استخراج از قالب‌های HTML
        template_dirs = getattr(settings, 'TEMPLATES', [{}])[0].get('DIRS', [])
        if not template_dirs:
            template_dirs = [Path(settings.BASE_DIR) / 'templates']

        trans_pattern = re.compile(r'\{%\s*trans\s+["\'](.*?)["\']\s*%\}')
        blocktrans_pattern = re.compile(r'\{%\s*blocktrans\s*%\}(.*?)\{%\s*endblocktrans\s*%\}', re.DOTALL)

        for t_dir in template_dirs:
            path = Path(t_dir)
            if not path.exists(): continue
            for html_file in path.glob('**/*.html'):
                with open(html_file, 'r', encoding='utf-8') as f:
                    content = f.read()
                    msgids.update(trans_pattern.findall(content))
                    block_matches = blocktrans_pattern.findall(content)
                    for match in block_matches:
                        msgids.add(match.strip())

        # ۲. استخراج از فایل‌های پایتون (مدل‌ها، فرم‌ها و غیره)
        # الگو برای _, gettext, gettext_lazy, ngettext
        py_pattern = re.compile(r'(?:_|\bgettext(?:_lazy|_noop)?)\s*\(\s*["\'](.*?)["\']\s*\)')
        
        project_root = Path(settings.BASE_DIR)
        for py_file in project_root.glob('**/*.py'):
            # نادیده گرفتن پوشه‌های سیستمی و مجازی
            if any(part in py_file.parts for part in ['venv', '.venv', 'migrations', 'env']):
                continue
            with open(py_file, 'r', encoding='utf-8') as f:
                try:
                    content = f.read()
                    msgids.update(py_pattern.findall(content))
                except Exception:
                    continue
                    
        return msgids

    def translate_batch(self, texts, target_lang):
        # دریافت تنظیمات موتور ترجمه از settings
        engine = getattr(settings, 'AUTOTRANSLATE_ENGINE', 'google')
        api_key = getattr(settings, 'AUTOTRANSLATE_API_KEY', None)
        
        results = {}
        var_pattern = re.compile(r'\{\{\s*.*?\s*\}\}')
        
        try:
            for text in texts:
                if not text.strip(): continue
                
                variables = var_pattern.findall(text)
                placeholders = [f"__VAR_{i}__" for i in range(len(variables))]
                temp_text = text
                for i, var in enumerate(variables):
                    temp_text = temp_text.replace(var, placeholders[i])
                
                translated = self._call_engine(temp_text, target_lang, engine, api_key)
                
                for i, var in enumerate(variables):
                    translated = translated.replace(placeholders[i], var)
                
                results[text] = translated
                if engine == 'google':
                    time.sleep(0.5)
            return results
        except Exception as e:
            self.stdout.write(self.style.ERROR(f"Translation Error: {e}"))
            return None

    def _call_engine(self, text, target_lang, engine, api_key):
        if engine == 'google':
            translator = Translator()
            translated = translator.translate(text, dest=target_lang).text
            if translated == text and any(c.isalpha() for c in text):
                translated = translator.translate(text, src='en', dest=target_lang).text
            return translated
            
        elif engine == 'deepl':
            import requests
            if not api_key: raise ValueError("DeepL API Key is missing in settings.")
            url = "https://api-free.deepl.com/v2/translate" # Or Pro URL
            params = {
                "auth_key": api_key,
                "text": text,
                "target_lang": target_lang.upper()
            }
            response = requests.post(url, data=params)
            return response.json()['translations'][0]['text']
            
        elif engine == 'microsoft':
            import requests, uuid
            if not api_key: raise ValueError("Microsoft Azure Key is missing in settings.")
            region = getattr(settings, 'AUTOTRANSLATE_REGION', 'global')
            endpoint = "https://api.cognitive.microsofttranslator.com/translate"
            params = {'api-version': '3.0', 'to': [target_lang]}
            headers = {
                'Ocp-Apim-Subscription-Key': api_key,
                'Ocp-Apim-Subscription-Region': region,
                'Content-type': 'application/json',
                'X-ClientTraceId': str(uuid.uuid4())
            }
            body = [{'text': text}]
            request = requests.post(endpoint, params=params, headers=headers, json=body)
            return request.json()[0]['translations'][0]['text']
            
        return text

    def handle(self, *args, **options):
        self.stdout.write(self.style.SUCCESS("Django Bub Translate by: https://github.com/mahdi1212-max\n"))
        target_lang = options['lang']
        no_input = options['no_input']
        
        # 1. آماده‌سازی مسیر فایل‌ها
        locale_dir = Path(settings.BASE_DIR) / 'locale'
        lang_dir = locale_dir / target_lang / 'LC_MESSAGES'
        lang_dir.mkdir(parents=True, exist_ok=True)
        po_path = lang_dir / 'django.po'
        mo_path = lang_dir / 'django.mo'

        # 2. استخراج متن‌ها
        self.stdout.write("Extracting messages from project (HTML & Python files)...")
        extracted_msgids = self.extract_messages_from_project()
        
        if not extracted_msgids:
            self.stdout.write(self.style.WARNING("No translatable strings found."))
            return

        # 3. ایجاد یا بارگذاری فایل PO
        if po_path.exists():
            po = polib.pofile(str(po_path))
        else:
            po = polib.POFile()
            po.metadata = {
                'Project-Id-Version': '1.0',
                'Last-Translator': 'AutoTranslate AI',
                'Language-Team': 'AutoTranslate AI',
                'MIME-Version': '1.0',
                'Content-Type': 'text/plain; charset=utf-8',
                'Content-Transfer-Encoding': '8bit',
            }

        # افزودن msgid های جدید
        existing_msgids = [e.msgid for e in po]
        new_entries = [m for m in extracted_msgids if m not in existing_msgids]
        
        for msgid in new_entries:
            entry = polib.POEntry(msgid=msgid, msgstr='')
            po.append(entry)

        # ۴. بررسی تایید کاربر
        untranslated_entries = [e for e in po if not e.msgstr and e.msgid]
        if not untranslated_entries:
            self.stdout.write(self.style.SUCCESS("No new strings to translate."))
            # حتی اگر ترجمه جدیدی نباشد، ممکن است نیاز به کامپایل مجدد باشد
            po.save_as_mofile(str(mo_path))
            return

        if not no_input:
            self.stdout.write(f"\nFound {len(untranslated_entries)} new strings to translate:")
            for e in untranslated_entries[:10]:
                self.stdout.write(f" - {e.msgid}")
            if len(untranslated_entries) > 10:
                self.stdout.write(f" ... and {len(untranslated_entries) - 10} more.")
            
            confirm = input(f"\nProceed with translating to '{target_lang}'? [y/N]: ")
            if confirm.lower() != 'y':
                self.stdout.write(self.style.ERROR("Operation cancelled."))
                return

        # ۵. ترجمه
        self.stdout.write(f"Translating {len(untranslated_entries)} items to {target_lang}...")
        texts_to_translate = [e.msgid for e in untranslated_entries]
        translated_map = self.translate_batch(texts_to_translate, target_lang)

        if translated_map:
            for entry in untranslated_entries:
                if entry.msgid in translated_map:
                    entry.msgstr = translated_map[entry.msgid]
            po.save(str(po_path))
            self.stdout.write(self.style.SUCCESS(f"Successfully translated and saved PO file."))

        # 5. کامپایل دستی به MO بدون نیاز به compilemessages (توسط polib)
        self.stdout.write("Compiling messages to .mo file...")
        po.save_as_mofile(str(mo_path))
        
        self.stdout.write(self.style.SUCCESS(f"Finished! Site is ready in '{target_lang}' without any OS-level tools."))
