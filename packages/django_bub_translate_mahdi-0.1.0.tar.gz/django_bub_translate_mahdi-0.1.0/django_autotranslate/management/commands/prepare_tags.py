import os
from django.core.management.base import BaseCommand
from django_autotranslate.processor import SmartHTMLProcessor

class Command(BaseCommand):
    """
    Command: python manage.py prepare_tags <path>
    """
    help = 'Scans HTML files and wraps translatable strings with Django {% trans %} tags'

    def add_arguments(self, parser):
        parser.add_argument('path', type=str, help='Path to templates directory')
        parser.add_argument('--no-input', action='store_true', help='Do not ask for confirmation')

    def handle(self, *args, **options):
        self.stdout.write(self.style.SUCCESS("Django Bub Translate by: https://github.com/mahdi1212-max\n"))
        path = options['path']
        no_input = options['no_input']
        processor = SmartHTMLProcessor()
        
        files_to_process = []
        for root, _, files in os.walk(path):
            for file in files:
                if file.endswith(".html"):
                    files_to_process.append(os.path.join(root, file))
        
        if not files_to_process:
            self.stdout.write(self.style.WARNING('No HTML files found.'))
            return

        if not no_input:
            self.stdout.write(f'Found {len(files_to_process)} HTML files to process:')
            for f in files_to_process[:10]:
                self.stdout.write(f' - {f}')
            if len(files_to_process) > 10:
                self.stdout.write(f' ... and {len(files_to_process) - 10} more.')
            
            confirm = input('\nDo you want to proceed? [y/N]: ')
            if confirm.lower() != 'y':
                self.stdout.write(self.style.ERROR('Operation cancelled.'))
                return

        count = 0
        for file_path in files_to_process:
            self.stdout.write(f'Processing: {os.path.basename(file_path)}')
            processor.process_file(file_path)
            count += 1
        
        self.stdout.write(self.style.SUCCESS(f'Successfully tagged {count} files.'))
