"""Allow running with ``python -m socketry``."""

from socketry.cli import app

app()
