"""Encoder/decoder architectures."""
