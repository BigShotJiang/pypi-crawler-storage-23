# Work on Jira Issue - Setup Step

Pre-flight checks failed. Your environment needs to be configured before working
on this issue.

## Issue Details

- **Issue Key**: {{issue_key}}

## Issues Detected

{{failure_reasons}}

## Setup Instructions

{{setup_instructions}}

---

**Next Step**: After setting up your environment, run
`agdt-initiate-work-on-jira-issue-workflow` again in the new VS Code window.
