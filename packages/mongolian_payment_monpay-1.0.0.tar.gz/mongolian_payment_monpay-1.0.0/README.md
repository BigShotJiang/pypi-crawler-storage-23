# mongolian-payment-monpay

MonPay payment gateway SDK for Python. Supports both **QR** and **Deeplink** payment flows with synchronous and asynchronous clients.

## Installation

```bash
pip install mongolian-payment-monpay
```

## QR Payments

### Sync

```python
from mongolian_payment_monpay import MonPayQrClient, MonPayQrConfig

client = MonPayQrClient(MonPayQrConfig(
    endpoint="https://api.monpay.mn",
    username="my-username",
    account_id="my-account-id",
    callback_url="https://example.com/callback",
))

# Generate a QR code
qr = client.generate_qr(5000)
print(qr.result.qrcode)  # base64 QR image
print(qr.result.uuid)     # unique payment ID

# Check payment status
status = client.check_qr(qr.result.uuid)
print(status.result.transaction_id)

# Parse a callback URL
callback = MonPayQrClient.parse_callback(
    "https://example.com/callback?amount=5000&uuid=abc&status=paid&tnxId=txn-1"
)
print(callback.amount, callback.status)
```

### Async

```python
import asyncio
from mongolian_payment_monpay import AsyncMonPayQrClient, MonPayQrConfig

async def main():
    async with AsyncMonPayQrClient(MonPayQrConfig(
        endpoint="https://api.monpay.mn",
        username="my-username",
        account_id="my-account-id",
        callback_url="https://example.com/callback",
    )) as client:
        qr = await client.generate_qr(5000)
        print(qr.result.qrcode)

asyncio.run(main())
```

## Deeplink Payments

### Sync

```python
from mongolian_payment_monpay import MonPayDeeplinkClient, MonPayDeeplinkConfig

client = MonPayDeeplinkClient(MonPayDeeplinkConfig(
    endpoint="https://api.monpay.mn",
    client_id="my-client-id",
    client_secret="my-client-secret",
    grant_type="client_credentials",
    webhook_url="https://example.com/webhook",
    redirect_url="https://example.com/redirect",
))

# Create a deeplink invoice (authenticates automatically)
invoice = client.create_deeplink(
    amount=5000,
    invoice_type="P2B",
    branch_username="branch1",
    description="Order #123",
)
print(invoice.result.id)
print(invoice.result.status)

# Check invoice status
status = client.check_invoice(invoice.result.id)
print(status.result.status)

# Parse a callback URL
callback = MonPayDeeplinkClient.parse_callback(
    "https://example.com/webhook?amount=5000&invoiceId=123&status=paid&tnxId=txn-1&info=ok"
)
print(callback.amount, callback.invoice_id, callback.status)
```

### Async

```python
import asyncio
from mongolian_payment_monpay import AsyncMonPayDeeplinkClient, MonPayDeeplinkConfig

async def main():
    async with AsyncMonPayDeeplinkClient(MonPayDeeplinkConfig(
        endpoint="https://api.monpay.mn",
        client_id="my-client-id",
        client_secret="my-client-secret",
        grant_type="client_credentials",
        webhook_url="https://example.com/webhook",
        redirect_url="https://example.com/redirect",
    )) as client:
        invoice = await client.create_deeplink(5000, "P2B", "branch1", "Order #123")
        print(invoice.result.id)

asyncio.run(main())
```

## Environment Variables

You can load configuration from environment variables:

```python
from mongolian_payment_monpay import (
    MonPayQrClient,
    MonPayDeeplinkClient,
    load_qr_config_from_env,
    load_deeplink_config_from_env,
)

# QR: reads MONPAY_ENDPOINT, MONPAY_USERNAME, MONPAY_ACCOUNT_ID, MONPAY_CALLBACK_URL
qr_client = MonPayQrClient(load_qr_config_from_env())

# Deeplink: reads MONPAY_ENDPOINT, MONPAY_CLIENT_ID, MONPAY_CLIENT_SECRET,
#           MONPAY_GRANT_TYPE, MONPAY_WEBHOOK_URL, MONPAY_REDIRECT_URL
dl_client = MonPayDeeplinkClient(load_deeplink_config_from_env())
```

## License

MIT
