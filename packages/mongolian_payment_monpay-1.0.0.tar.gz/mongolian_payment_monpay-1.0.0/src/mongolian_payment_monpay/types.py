"""Type definitions for the MonPay SDK."""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Optional


# -- Constants --


class InvoiceType(str, Enum):
    """Invoice type for deeplink invoices."""

    P2P = "P2P"
    P2B = "P2B"
    B2B = "B2B"


class Bank(str, Enum):
    """Supported bank identifiers."""

    KHAN = "KHAN"
    GOLOMT = "GOLOMT"
    STATE = "STATE"
    ULAANBAATAR = "ULAANBAATAR"
    XAC = "XAC"
    CAPITRON = "CAPITRON"
    ARIG = "ARIG"
    CHINGGIS = "CHINGGIS"
    BOGD = "BOGD"
    CREDIT = "CREDIT"
    HUGJIL = "HUGJIL"
    TURIIN_SAN = "TURIIN_SAN"


# -- Configuration --


@dataclass
class MonPayQrConfig:
    """Configuration for MonPayQrClient."""

    endpoint: str
    """MonPay API base endpoint."""

    username: str
    """Username for HTTP Basic Auth."""

    account_id: str
    """Account ID used as password for HTTP Basic Auth."""

    callback_url: str
    """Callback URL for payment notifications."""


@dataclass
class MonPayDeeplinkConfig:
    """Configuration for MonPayDeeplinkClient."""

    endpoint: str
    """MonPay API base endpoint."""

    client_id: str
    """OAuth2 client ID."""

    client_secret: str
    """OAuth2 client secret."""

    grant_type: str
    """OAuth2 grant type (typically 'client_credentials')."""

    webhook_url: str
    """Webhook URL for payment notifications."""

    redirect_url: str
    """Redirect URL after payment."""


# -- QR Types --


@dataclass
class MonPayQrRequest:
    """Request body for generating a QR code."""

    amount: float
    """Payment amount."""

    string: str
    """Display name."""

    generate_uuid: bool
    """Whether to generate a UUID."""

    callback_url: str
    """Callback URL."""


@dataclass
class MonPayQrResult:
    """Result containing QR code data."""

    qrcode: str
    """Base64 QR code image."""

    uuid: str
    """Unique identifier for this QR payment."""


@dataclass
class MonPayQrResponse:
    """Response from QR code generation."""

    code: int
    """Response code."""

    info: str
    """Response info message."""

    result: MonPayQrResult
    """QR result containing the QR code and UUID."""


@dataclass
class MonPayCheckResult:
    """Result from checking QR payment status."""

    uuid: str
    """Unique identifier."""

    used_at: int
    """Timestamp when the QR was used."""

    used_by_id: int
    """User ID who used the QR."""

    transaction_id: str
    """Transaction ID."""

    amount: float
    """Payment amount."""

    created_at: int
    """Timestamp when the QR was created."""

    user_phone: str
    """Phone number of the payer."""

    user_account_no: str
    """Account number of the payer."""

    user_vat_id: str
    """VAT ID of the payer."""

    used_at_ui: str
    """Human-readable used-at date."""

    created_at_ui: str
    """Human-readable created-at date."""

    amount_ui: str
    """Human-readable amount."""


@dataclass
class MonPayCheckResponse:
    """Response from checking QR payment status."""

    code: int
    """Response code."""

    info: str
    """Response info message."""

    result: MonPayCheckResult
    """Payment check result."""


@dataclass
class MonPayCallback:
    """QR callback payload (from callback URL query params)."""

    amount: float
    """Payment amount."""

    uuid: str
    """Unique identifier."""

    status: str
    """Payment status."""

    tnx_id: str
    """Transaction ID."""


# -- Deeplink Types --


@dataclass
class MonPayTokenResponse:
    """OAuth2 token response."""

    access_token: str
    """Access token."""

    token_type: str
    """Token type (e.g. 'Bearer')."""


@dataclass
class DeeplinkCreateRequest:
    """Request body for creating a deeplink invoice."""

    redirect_uri: str
    """Redirect URI after payment."""

    amount: float
    """Payment amount."""

    client_service_url: str
    """Webhook URL for notifications."""

    receiver: str
    """Receiver identifier (branch username)."""

    invoice_type: str
    """Type of invoice."""

    description: str
    """Invoice description."""


@dataclass
class DeeplinkCreateResult:
    """Result from creating a deeplink invoice."""

    id: int
    """Invoice ID."""

    receiver: str
    """Receiver identifier."""

    amount: float
    """Payment amount."""

    user_id: int
    """User ID."""

    mini_app_id: int
    """Mini app ID."""

    create_date: str
    """Creation date."""

    update_date: str
    """Last update date."""

    status: str
    """Invoice status."""

    description: str
    """Invoice description."""

    redirect_uri: str
    """Redirect URI."""

    invoice_type: str
    """Type of invoice."""


@dataclass
class DeeplinkCreateResponse:
    """Response from creating a deeplink invoice."""

    code: str
    """Response code."""

    int_code: int
    """Integer response code."""

    info: str
    """Response info message."""

    result: DeeplinkCreateResult
    """Invoice result."""


@dataclass
class DeeplinkCheckResult:
    """Result from checking a deeplink invoice."""

    id: int
    """Invoice ID."""

    receiver: str
    """Receiver identifier."""

    amount: float
    """Payment amount."""

    user_id: int
    """User ID."""

    mini_app_id: int
    """Mini app ID."""

    create_date: str
    """Creation date."""

    update_date: str
    """Last update date."""

    status: str
    """Invoice status."""

    description: str
    """Invoice description."""

    status_info: str
    """Status info."""

    redirect_uri: str
    """Redirect URI."""

    invoice_type: str
    """Type of invoice."""

    bank_name: str
    """Bank name."""

    bank_account: str
    """Bank account number."""

    bank_account_name: str
    """Bank account holder name."""


@dataclass
class DeeplinkCheckResponse:
    """Response from checking a deeplink invoice."""

    code: str
    """Response code."""

    int_code: int
    """Integer response code."""

    info: str
    """Response info message."""

    result: DeeplinkCheckResult
    """Invoice check result."""


@dataclass
class DeeplinkCallback:
    """Deeplink callback payload (from callback URL query params)."""

    amount: float
    """Payment amount."""

    invoice_id: str
    """Invoice ID."""

    status: str
    """Payment status."""

    tnx_id: str
    """Transaction ID."""

    info: str
    """Additional info."""
