"""Configuration validation and environment helpers for the MonPay SDK."""

from __future__ import annotations

import os

from .types import MonPayQrConfig, MonPayDeeplinkConfig


def validate_qr_config(config: MonPayQrConfig) -> None:
    """Validate the QR client configuration, raising if any required field is missing."""
    if not config.endpoint:
        raise ValueError("MonPayQrConfig: endpoint is required")
    if not config.username:
        raise ValueError("MonPayQrConfig: username is required")
    if not config.account_id:
        raise ValueError("MonPayQrConfig: account_id is required")
    if not config.callback_url:
        raise ValueError("MonPayQrConfig: callback_url is required")


def validate_deeplink_config(config: MonPayDeeplinkConfig) -> None:
    """Validate the Deeplink client configuration, raising if any required field is missing."""
    if not config.endpoint:
        raise ValueError("MonPayDeeplinkConfig: endpoint is required")
    if not config.client_id:
        raise ValueError("MonPayDeeplinkConfig: client_id is required")
    if not config.client_secret:
        raise ValueError("MonPayDeeplinkConfig: client_secret is required")
    if not config.grant_type:
        raise ValueError("MonPayDeeplinkConfig: grant_type is required")
    if not config.webhook_url:
        raise ValueError("MonPayDeeplinkConfig: webhook_url is required")
    if not config.redirect_url:
        raise ValueError("MonPayDeeplinkConfig: redirect_url is required")


def load_qr_config_from_env() -> MonPayQrConfig:
    """Load QR client configuration from environment variables.

    Environment variables:
        MONPAY_ENDPOINT: MonPay API base endpoint
        MONPAY_USERNAME: Username for HTTP Basic Auth
        MONPAY_ACCOUNT_ID: Account ID for HTTP Basic Auth
        MONPAY_CALLBACK_URL: Callback URL for payment notifications

    Returns:
        A MonPayQrConfig populated from environment variables.
    """
    return MonPayQrConfig(
        endpoint=os.environ.get("MONPAY_ENDPOINT", ""),
        username=os.environ.get("MONPAY_USERNAME", ""),
        account_id=os.environ.get("MONPAY_ACCOUNT_ID", ""),
        callback_url=os.environ.get("MONPAY_CALLBACK_URL", ""),
    )


def load_deeplink_config_from_env() -> MonPayDeeplinkConfig:
    """Load Deeplink client configuration from environment variables.

    Environment variables:
        MONPAY_ENDPOINT: MonPay API base endpoint
        MONPAY_CLIENT_ID: OAuth2 client ID
        MONPAY_CLIENT_SECRET: OAuth2 client secret
        MONPAY_GRANT_TYPE: OAuth2 grant type (default: client_credentials)
        MONPAY_WEBHOOK_URL: Webhook URL for payment notifications
        MONPAY_REDIRECT_URL: Redirect URL after payment

    Returns:
        A MonPayDeeplinkConfig populated from environment variables.
    """
    return MonPayDeeplinkConfig(
        endpoint=os.environ.get("MONPAY_ENDPOINT", ""),
        client_id=os.environ.get("MONPAY_CLIENT_ID", ""),
        client_secret=os.environ.get("MONPAY_CLIENT_SECRET", ""),
        grant_type=os.environ.get("MONPAY_GRANT_TYPE", "client_credentials"),
        webhook_url=os.environ.get("MONPAY_WEBHOOK_URL", ""),
        redirect_url=os.environ.get("MONPAY_REDIRECT_URL", ""),
    )
