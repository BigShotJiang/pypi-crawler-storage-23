"""Custom error classes for the MonPay SDK."""

from __future__ import annotations

from typing import Any, Optional


class MonPayError(Exception):
    """Custom error class for MonPay API errors.

    Includes the HTTP status code and raw response body when available.
    """

    def __init__(
        self,
        message: str,
        status_code: Optional[int] = None,
        response: Optional[Any] = None,
    ) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.response = response
