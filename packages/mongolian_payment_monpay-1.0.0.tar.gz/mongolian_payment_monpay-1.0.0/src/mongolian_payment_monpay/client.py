"""MonPay payment gateway clients (QR and Deeplink, sync and async)."""

from __future__ import annotations

import base64
from typing import Optional
from urllib.parse import parse_qs, urlparse, quote

import httpx

from .config import validate_qr_config, validate_deeplink_config
from .errors import MonPayError
from .types import (
    MonPayQrConfig,
    MonPayDeeplinkConfig,
    MonPayQrResponse,
    MonPayQrResult,
    MonPayCheckResponse,
    MonPayCheckResult,
    MonPayCallback,
    MonPayTokenResponse,
    DeeplinkCreateResponse,
    DeeplinkCreateResult,
    DeeplinkCheckResponse,
    DeeplinkCheckResult,
    DeeplinkCallback,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _build_basic_auth(username: str, account_id: str) -> str:
    """Build HTTP Basic Auth header value."""
    credentials = f"{username}:{account_id}"
    encoded = base64.b64encode(credentials.encode()).decode()
    return f"Basic {encoded}"


def _parse_qr_response(data: dict) -> MonPayQrResponse:
    result = data.get("result", {})
    return MonPayQrResponse(
        code=data.get("code", 0),
        info=data.get("info", ""),
        result=MonPayQrResult(
            qrcode=result.get("qrcode", ""),
            uuid=result.get("uuid", ""),
        ),
    )


def _parse_check_response(data: dict) -> MonPayCheckResponse:
    result = data.get("result", {})
    return MonPayCheckResponse(
        code=data.get("code", 0),
        info=data.get("info", ""),
        result=MonPayCheckResult(
            uuid=result.get("uuid", ""),
            used_at=result.get("usedAt", 0),
            used_by_id=result.get("usedById", 0),
            transaction_id=result.get("transactionId", ""),
            amount=result.get("amount", 0),
            created_at=result.get("createdAt", 0),
            user_phone=result.get("userPhone", ""),
            user_account_no=result.get("userAccountNo", ""),
            user_vat_id=result.get("userVatId", ""),
            used_at_ui=result.get("usedAtUI", ""),
            created_at_ui=result.get("createdAtUI", ""),
            amount_ui=result.get("amountUI", ""),
        ),
    )


def _parse_token_response(data: dict) -> MonPayTokenResponse:
    return MonPayTokenResponse(
        access_token=data.get("access_token", ""),
        token_type=data.get("token_type", ""),
    )


def _parse_deeplink_create_response(data: dict) -> DeeplinkCreateResponse:
    result = data.get("result", {})
    return DeeplinkCreateResponse(
        code=data.get("code", ""),
        int_code=data.get("intCode", 0),
        info=data.get("info", ""),
        result=DeeplinkCreateResult(
            id=result.get("id", 0),
            receiver=result.get("receiver", ""),
            amount=result.get("amount", 0),
            user_id=result.get("userId", 0),
            mini_app_id=result.get("miniAppId", 0),
            create_date=result.get("createDate", ""),
            update_date=result.get("updateDate", ""),
            status=result.get("status", ""),
            description=result.get("description", ""),
            redirect_uri=result.get("redirectUri", ""),
            invoice_type=result.get("invoiceType", ""),
        ),
    )


def _parse_deeplink_check_response(data: dict) -> DeeplinkCheckResponse:
    result = data.get("result", {})
    return DeeplinkCheckResponse(
        code=data.get("code", ""),
        int_code=data.get("intCode", 0),
        info=data.get("info", ""),
        result=DeeplinkCheckResult(
            id=result.get("id", 0),
            receiver=result.get("receiver", ""),
            amount=result.get("amount", 0),
            user_id=result.get("userId", 0),
            mini_app_id=result.get("miniAppId", 0),
            create_date=result.get("createDate", ""),
            update_date=result.get("updateDate", ""),
            status=result.get("status", ""),
            description=result.get("description", ""),
            status_info=result.get("statusInfo", ""),
            redirect_uri=result.get("redirectUri", ""),
            invoice_type=result.get("invoiceType", ""),
            bank_name=result.get("bankName", ""),
            bank_account=result.get("bankAccount", ""),
            bank_account_name=result.get("bankAccountName", ""),
        ),
    )


def _parse_callback_params(url: str) -> dict:
    """Parse query parameters from a callback URL string."""
    parsed = urlparse(url)
    params = parse_qs(parsed.query)
    # parse_qs returns lists; take first value for each key
    return {k: v[0] for k, v in params.items()}


# ---------------------------------------------------------------------------
# QR Client (sync)
# ---------------------------------------------------------------------------


class MonPayQrClient:
    """MonPay QR payment client (synchronous).

    Uses HTTP Basic Auth (username:accountId) to generate and check QR payments.

    Example::

        client = MonPayQrClient(MonPayQrConfig(
            endpoint="https://api.monpay.mn",
            username="my-username",
            account_id="my-account-id",
            callback_url="https://example.com/callback",
        ))

        qr = client.generate_qr(5000)
        print(qr.result.qrcode, qr.result.uuid)
    """

    def __init__(self, config: MonPayQrConfig) -> None:
        validate_qr_config(config)
        self._config = config
        self._auth_header = _build_basic_auth(config.username, config.account_id)
        self._client = httpx.Client()

    # -- public API --

    def generate_qr(self, amount: float) -> MonPayQrResponse:
        """Generate a QR code for a payment.

        Args:
            amount: Payment amount in MNT.

        Returns:
            QR code response containing the QR image and UUID.
        """
        body = {
            "amount": amount,
            "string": self._config.username,
            "generateUuid": True,
            "callbackUrl": self._config.callback_url,
        }
        url = f"{self._config.endpoint}/rest/branch/qrpurchase/generate"

        res = self._client.post(
            url,
            json=body,
            headers={
                "Content-Type": "application/json",
                "Authorization": self._auth_header,
            },
        )

        if res.status_code >= 400:
            raise MonPayError(
                f"QR generate failed: {res.status_code}",
                res.status_code,
                res.text,
            )

        return _parse_qr_response(res.json())

    def check_qr(self, uuid: str) -> MonPayCheckResponse:
        """Check the payment status of a QR code by its UUID.

        Args:
            uuid: The UUID returned from generate_qr.

        Returns:
            Payment check response.
        """
        url = f"{self._config.endpoint}/rest/branch/qrpurchase/check?uuid={quote(uuid)}"

        res = self._client.get(
            url,
            headers={"Authorization": self._auth_header},
        )

        if res.status_code >= 400:
            raise MonPayError(
                f"QR check failed: {res.status_code}",
                res.status_code,
                res.text,
            )

        return _parse_check_response(res.json())

    @staticmethod
    def parse_callback(url: str) -> MonPayCallback:
        """Parse a MonPay QR callback URL into a typed object.

        Args:
            url: The callback URL string with query parameters.

        Returns:
            Parsed callback data.
        """
        params = _parse_callback_params(url)
        return MonPayCallback(
            amount=float(params.get("amount", "0")),
            uuid=params.get("uuid", ""),
            status=params.get("status", ""),
            tnx_id=params.get("tnxId", ""),
        )

    def close(self) -> None:
        """Close the underlying HTTP client."""
        self._client.close()

    def __enter__(self) -> "MonPayQrClient":
        return self

    def __exit__(self, *args: object) -> None:
        self.close()


# ---------------------------------------------------------------------------
# QR Client (async)
# ---------------------------------------------------------------------------


class AsyncMonPayQrClient:
    """MonPay QR payment client (asynchronous).

    Uses HTTP Basic Auth (username:accountId) to generate and check QR payments.

    Example::

        async with AsyncMonPayQrClient(MonPayQrConfig(
            endpoint="https://api.monpay.mn",
            username="my-username",
            account_id="my-account-id",
            callback_url="https://example.com/callback",
        )) as client:
            qr = await client.generate_qr(5000)
            print(qr.result.qrcode, qr.result.uuid)
    """

    def __init__(self, config: MonPayQrConfig) -> None:
        validate_qr_config(config)
        self._config = config
        self._auth_header = _build_basic_auth(config.username, config.account_id)
        self._client = httpx.AsyncClient()

    # -- public API --

    async def generate_qr(self, amount: float) -> MonPayQrResponse:
        """Generate a QR code for a payment.

        Args:
            amount: Payment amount in MNT.

        Returns:
            QR code response containing the QR image and UUID.
        """
        body = {
            "amount": amount,
            "string": self._config.username,
            "generateUuid": True,
            "callbackUrl": self._config.callback_url,
        }
        url = f"{self._config.endpoint}/rest/branch/qrpurchase/generate"

        res = await self._client.post(
            url,
            json=body,
            headers={
                "Content-Type": "application/json",
                "Authorization": self._auth_header,
            },
        )

        if res.status_code >= 400:
            raise MonPayError(
                f"QR generate failed: {res.status_code}",
                res.status_code,
                res.text,
            )

        return _parse_qr_response(res.json())

    async def check_qr(self, uuid: str) -> MonPayCheckResponse:
        """Check the payment status of a QR code by its UUID.

        Args:
            uuid: The UUID returned from generate_qr.

        Returns:
            Payment check response.
        """
        url = f"{self._config.endpoint}/rest/branch/qrpurchase/check?uuid={quote(uuid)}"

        res = await self._client.get(
            url,
            headers={"Authorization": self._auth_header},
        )

        if res.status_code >= 400:
            raise MonPayError(
                f"QR check failed: {res.status_code}",
                res.status_code,
                res.text,
            )

        return _parse_check_response(res.json())

    @staticmethod
    def parse_callback(url: str) -> MonPayCallback:
        """Parse a MonPay QR callback URL into a typed object.

        Args:
            url: The callback URL string with query parameters.

        Returns:
            Parsed callback data.
        """
        params = _parse_callback_params(url)
        return MonPayCallback(
            amount=float(params.get("amount", "0")),
            uuid=params.get("uuid", ""),
            status=params.get("status", ""),
            tnx_id=params.get("tnxId", ""),
        )

    async def close(self) -> None:
        """Close the underlying HTTP client."""
        await self._client.aclose()

    async def __aenter__(self) -> "AsyncMonPayQrClient":
        return self

    async def __aexit__(self, *args: object) -> None:
        await self.close()


# ---------------------------------------------------------------------------
# Deeplink Client (sync)
# ---------------------------------------------------------------------------


class MonPayDeeplinkClient:
    """MonPay Deeplink payment client (synchronous).

    Uses OAuth2 client_credentials to obtain a Bearer token, then creates
    and checks deeplink invoices.

    Example::

        client = MonPayDeeplinkClient(MonPayDeeplinkConfig(
            endpoint="https://api.monpay.mn",
            client_id="my-client-id",
            client_secret="my-client-secret",
            grant_type="client_credentials",
            webhook_url="https://example.com/webhook",
            redirect_url="https://example.com/redirect",
        ))

        invoice = client.create_deeplink(5000, "P2B", "branch1", "Order #123")
        print(invoice.result.id)
    """

    def __init__(self, config: MonPayDeeplinkConfig) -> None:
        validate_deeplink_config(config)
        self._config = config
        self._access_token: Optional[str] = None
        self._client = httpx.Client()

    # -- auth --

    def authenticate(self) -> None:
        """Obtain or refresh the OAuth2 access token.

        This is called automatically before each API request.
        You can also call it manually to pre-authenticate.
        """
        url = f"{self._config.endpoint}/oauth/token"

        body = {
            "client_id": self._config.client_id,
            "client_secret": self._config.client_secret,
            "grant_type": self._config.grant_type,
        }

        res = self._client.post(
            url,
            data=body,
            headers={"Content-Type": "application/x-www-form-urlencoded"},
        )

        if res.status_code >= 400:
            raise MonPayError(
                f"OAuth token request failed: {res.status_code}",
                res.status_code,
                res.text,
            )

        token_data = _parse_token_response(res.json())
        self._access_token = token_data.access_token

    def _ensure_auth(self) -> str:
        """Ensure we have a valid access token, fetching one if needed."""
        if not self._access_token:
            self.authenticate()
        assert self._access_token is not None
        return self._access_token

    # -- public API --

    def create_deeplink(
        self,
        amount: float,
        invoice_type: str,
        branch_username: str,
        description: str,
        invoice_id: Optional[str] = None,
    ) -> DeeplinkCreateResponse:
        """Create a deeplink invoice.

        Args:
            amount: Payment amount in MNT.
            invoice_type: Type of invoice (P2P, P2B, or B2B).
            branch_username: Receiver branch username.
            description: Invoice description.
            invoice_id: Optional existing invoice ID to include in the redirect.

        Returns:
            Created invoice response.
        """
        token = self._ensure_auth()

        redirect_uri = self._config.redirect_url
        if invoice_id:
            redirect_uri = f"{self._config.redirect_url}?invoiceId={quote(invoice_id)}"

        body = {
            "redirectUri": redirect_uri,
            "amount": amount,
            "clientServiceUrl": self._config.webhook_url,
            "receiver": branch_username,
            "invoiceType": invoice_type,
            "description": description,
        }

        url = f"{self._config.endpoint}/api/oauth/invoice"

        res = self._client.post(
            url,
            json=body,
            headers={
                "Content-Type": "application/json",
                "Authorization": f"Bearer {token}",
            },
        )

        if res.status_code >= 400:
            raise MonPayError(
                f"Deeplink create failed: {res.status_code}",
                res.status_code,
                res.text,
            )

        return _parse_deeplink_create_response(res.json())

    def check_invoice(self, invoice_id: int) -> DeeplinkCheckResponse:
        """Check the status of a deeplink invoice.

        Args:
            invoice_id: The invoice ID to check.

        Returns:
            Invoice status response.
        """
        token = self._ensure_auth()

        url = f"{self._config.endpoint}/api/oauth/invoice/{invoice_id}"

        res = self._client.get(
            url,
            headers={"Authorization": f"Bearer {token}"},
        )

        if res.status_code >= 400:
            raise MonPayError(
                f"Invoice check failed: {res.status_code}",
                res.status_code,
                res.text,
            )

        return _parse_deeplink_check_response(res.json())

    @staticmethod
    def parse_callback(url: str) -> DeeplinkCallback:
        """Parse a MonPay deeplink callback URL into a typed object.

        Args:
            url: The callback URL string with query parameters.

        Returns:
            Parsed callback data.
        """
        params = _parse_callback_params(url)
        return DeeplinkCallback(
            amount=float(params.get("amount", "0")),
            invoice_id=params.get("invoiceId", ""),
            status=params.get("status", ""),
            tnx_id=params.get("tnxId", ""),
            info=params.get("info", ""),
        )

    def close(self) -> None:
        """Close the underlying HTTP client."""
        self._client.close()

    def __enter__(self) -> "MonPayDeeplinkClient":
        return self

    def __exit__(self, *args: object) -> None:
        self.close()


# ---------------------------------------------------------------------------
# Deeplink Client (async)
# ---------------------------------------------------------------------------


class AsyncMonPayDeeplinkClient:
    """MonPay Deeplink payment client (asynchronous).

    Uses OAuth2 client_credentials to obtain a Bearer token, then creates
    and checks deeplink invoices.

    Example::

        async with AsyncMonPayDeeplinkClient(MonPayDeeplinkConfig(
            endpoint="https://api.monpay.mn",
            client_id="my-client-id",
            client_secret="my-client-secret",
            grant_type="client_credentials",
            webhook_url="https://example.com/webhook",
            redirect_url="https://example.com/redirect",
        )) as client:
            invoice = await client.create_deeplink(5000, "P2B", "branch1", "Order #123")
            print(invoice.result.id)
    """

    def __init__(self, config: MonPayDeeplinkConfig) -> None:
        validate_deeplink_config(config)
        self._config = config
        self._access_token: Optional[str] = None
        self._client = httpx.AsyncClient()

    # -- auth --

    async def authenticate(self) -> None:
        """Obtain or refresh the OAuth2 access token.

        This is called automatically before each API request.
        You can also call it manually to pre-authenticate.
        """
        url = f"{self._config.endpoint}/oauth/token"

        body = {
            "client_id": self._config.client_id,
            "client_secret": self._config.client_secret,
            "grant_type": self._config.grant_type,
        }

        res = await self._client.post(
            url,
            data=body,
            headers={"Content-Type": "application/x-www-form-urlencoded"},
        )

        if res.status_code >= 400:
            raise MonPayError(
                f"OAuth token request failed: {res.status_code}",
                res.status_code,
                res.text,
            )

        token_data = _parse_token_response(res.json())
        self._access_token = token_data.access_token

    async def _ensure_auth(self) -> str:
        """Ensure we have a valid access token, fetching one if needed."""
        if not self._access_token:
            await self.authenticate()
        assert self._access_token is not None
        return self._access_token

    # -- public API --

    async def create_deeplink(
        self,
        amount: float,
        invoice_type: str,
        branch_username: str,
        description: str,
        invoice_id: Optional[str] = None,
    ) -> DeeplinkCreateResponse:
        """Create a deeplink invoice.

        Args:
            amount: Payment amount in MNT.
            invoice_type: Type of invoice (P2P, P2B, or B2B).
            branch_username: Receiver branch username.
            description: Invoice description.
            invoice_id: Optional existing invoice ID to include in the redirect.

        Returns:
            Created invoice response.
        """
        token = await self._ensure_auth()

        redirect_uri = self._config.redirect_url
        if invoice_id:
            redirect_uri = f"{self._config.redirect_url}?invoiceId={quote(invoice_id)}"

        body = {
            "redirectUri": redirect_uri,
            "amount": amount,
            "clientServiceUrl": self._config.webhook_url,
            "receiver": branch_username,
            "invoiceType": invoice_type,
            "description": description,
        }

        url = f"{self._config.endpoint}/api/oauth/invoice"

        res = await self._client.post(
            url,
            json=body,
            headers={
                "Content-Type": "application/json",
                "Authorization": f"Bearer {token}",
            },
        )

        if res.status_code >= 400:
            raise MonPayError(
                f"Deeplink create failed: {res.status_code}",
                res.status_code,
                res.text,
            )

        return _parse_deeplink_create_response(res.json())

    async def check_invoice(self, invoice_id: int) -> DeeplinkCheckResponse:
        """Check the status of a deeplink invoice.

        Args:
            invoice_id: The invoice ID to check.

        Returns:
            Invoice status response.
        """
        token = await self._ensure_auth()

        url = f"{self._config.endpoint}/api/oauth/invoice/{invoice_id}"

        res = await self._client.get(
            url,
            headers={"Authorization": f"Bearer {token}"},
        )

        if res.status_code >= 400:
            raise MonPayError(
                f"Invoice check failed: {res.status_code}",
                res.status_code,
                res.text,
            )

        return _parse_deeplink_check_response(res.json())

    @staticmethod
    def parse_callback(url: str) -> DeeplinkCallback:
        """Parse a MonPay deeplink callback URL into a typed object.

        Args:
            url: The callback URL string with query parameters.

        Returns:
            Parsed callback data.
        """
        params = _parse_callback_params(url)
        return DeeplinkCallback(
            amount=float(params.get("amount", "0")),
            invoice_id=params.get("invoiceId", ""),
            status=params.get("status", ""),
            tnx_id=params.get("tnxId", ""),
            info=params.get("info", ""),
        )

    async def close(self) -> None:
        """Close the underlying HTTP client."""
        await self._client.aclose()

    async def __aenter__(self) -> "AsyncMonPayDeeplinkClient":
        return self

    async def __aexit__(self, *args: object) -> None:
        await self.close()
