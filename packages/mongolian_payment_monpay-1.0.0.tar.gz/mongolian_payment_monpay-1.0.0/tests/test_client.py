"""Tests for the MonPay SDK clients."""

from __future__ import annotations

from unittest.mock import patch, MagicMock

import pytest
import httpx

from mongolian_payment_monpay import (
    MonPayQrClient,
    AsyncMonPayQrClient,
    MonPayDeeplinkClient,
    AsyncMonPayDeeplinkClient,
    MonPayQrConfig,
    MonPayDeeplinkConfig,
    MonPayError,
    MonPayCallback,
    DeeplinkCallback,
)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

QR_CONFIG = MonPayQrConfig(
    endpoint="https://api.monpay.mn",
    username="test-user",
    account_id="test-account-id",
    callback_url="https://example.com/callback",
)

DEEPLINK_CONFIG = MonPayDeeplinkConfig(
    endpoint="https://api.monpay.mn",
    client_id="test-client-id",
    client_secret="test-client-secret",
    grant_type="client_credentials",
    webhook_url="https://example.com/webhook",
    redirect_url="https://example.com/redirect",
)


def _mock_response(status_code: int = 200, json_data: dict | None = None, text: str = "") -> MagicMock:
    """Create a mock httpx.Response."""
    resp = MagicMock()
    resp.status_code = status_code
    resp.json.return_value = json_data or {}
    resp.text = text
    return resp


# ---------------------------------------------------------------------------
# QR Config validation
# ---------------------------------------------------------------------------


class TestQrConfigValidation:
    def test_missing_endpoint(self) -> None:
        with pytest.raises(ValueError, match="endpoint is required"):
            MonPayQrClient(MonPayQrConfig(
                endpoint="",
                username="u",
                account_id="a",
                callback_url="http://cb",
            ))

    def test_missing_username(self) -> None:
        with pytest.raises(ValueError, match="username is required"):
            MonPayQrClient(MonPayQrConfig(
                endpoint="https://api.monpay.mn",
                username="",
                account_id="a",
                callback_url="http://cb",
            ))

    def test_missing_account_id(self) -> None:
        with pytest.raises(ValueError, match="account_id is required"):
            MonPayQrClient(MonPayQrConfig(
                endpoint="https://api.monpay.mn",
                username="u",
                account_id="",
                callback_url="http://cb",
            ))

    def test_missing_callback_url(self) -> None:
        with pytest.raises(ValueError, match="callback_url is required"):
            MonPayQrClient(MonPayQrConfig(
                endpoint="https://api.monpay.mn",
                username="u",
                account_id="a",
                callback_url="",
            ))


# ---------------------------------------------------------------------------
# Deeplink Config validation
# ---------------------------------------------------------------------------


class TestDeeplinkConfigValidation:
    def test_missing_endpoint(self) -> None:
        with pytest.raises(ValueError, match="endpoint is required"):
            MonPayDeeplinkClient(MonPayDeeplinkConfig(
                endpoint="",
                client_id="c",
                client_secret="s",
                grant_type="client_credentials",
                webhook_url="http://wh",
                redirect_url="http://rd",
            ))

    def test_missing_client_id(self) -> None:
        with pytest.raises(ValueError, match="client_id is required"):
            MonPayDeeplinkClient(MonPayDeeplinkConfig(
                endpoint="https://api.monpay.mn",
                client_id="",
                client_secret="s",
                grant_type="client_credentials",
                webhook_url="http://wh",
                redirect_url="http://rd",
            ))

    def test_missing_client_secret(self) -> None:
        with pytest.raises(ValueError, match="client_secret is required"):
            MonPayDeeplinkClient(MonPayDeeplinkConfig(
                endpoint="https://api.monpay.mn",
                client_id="c",
                client_secret="",
                grant_type="client_credentials",
                webhook_url="http://wh",
                redirect_url="http://rd",
            ))


# ---------------------------------------------------------------------------
# QR Client (sync)
# ---------------------------------------------------------------------------


class TestMonPayQrClient:
    def test_generate_qr_success(self) -> None:
        mock_resp = _mock_response(200, {
            "code": 0,
            "info": "success",
            "result": {
                "qrcode": "base64-qr-image",
                "uuid": "qr-uuid-123",
            },
        })

        with patch.object(httpx.Client, "post", return_value=mock_resp) as mock_post:
            client = MonPayQrClient(QR_CONFIG)
            result = client.generate_qr(5000)

            assert result.code == 0
            assert result.info == "success"
            assert result.result.qrcode == "base64-qr-image"
            assert result.result.uuid == "qr-uuid-123"

            call_args = mock_post.call_args
            assert "/rest/branch/qrpurchase/generate" in call_args[0][0]
            body = call_args[1]["json"]
            assert body["amount"] == 5000
            assert body["string"] == "test-user"
            assert body["generateUuid"] is True
            assert body["callbackUrl"] == "https://example.com/callback"

    def test_generate_qr_error(self) -> None:
        mock_resp = _mock_response(401, text="Unauthorized")

        with patch.object(httpx.Client, "post", return_value=mock_resp):
            client = MonPayQrClient(QR_CONFIG)
            with pytest.raises(MonPayError, match="QR generate failed: 401"):
                client.generate_qr(5000)

    def test_check_qr_success(self) -> None:
        mock_resp = _mock_response(200, {
            "code": 0,
            "info": "success",
            "result": {
                "uuid": "qr-uuid-123",
                "usedAt": 1700000000,
                "usedById": 42,
                "transactionId": "txn-abc",
                "amount": 5000,
                "createdAt": 1699999000,
                "userPhone": "99001122",
                "userAccountNo": "1234567890",
                "userVatId": "VAT123",
                "usedAtUI": "2024-01-01 12:00",
                "createdAtUI": "2024-01-01 11:00",
                "amountUI": "5,000 MNT",
            },
        })

        with patch.object(httpx.Client, "get", return_value=mock_resp):
            client = MonPayQrClient(QR_CONFIG)
            result = client.check_qr("qr-uuid-123")

            assert result.code == 0
            assert result.result.uuid == "qr-uuid-123"
            assert result.result.transaction_id == "txn-abc"
            assert result.result.amount == 5000
            assert result.result.user_phone == "99001122"

    def test_check_qr_error(self) -> None:
        mock_resp = _mock_response(404, text="Not Found")

        with patch.object(httpx.Client, "get", return_value=mock_resp):
            client = MonPayQrClient(QR_CONFIG)
            with pytest.raises(MonPayError, match="QR check failed: 404"):
                client.check_qr("nonexistent-uuid")

    def test_parse_callback(self) -> None:
        url = "https://example.com/callback?amount=5000&uuid=qr-uuid-123&status=paid&tnxId=txn-abc"
        result = MonPayQrClient.parse_callback(url)

        assert isinstance(result, MonPayCallback)
        assert result.amount == 5000.0
        assert result.uuid == "qr-uuid-123"
        assert result.status == "paid"
        assert result.tnx_id == "txn-abc"

    def test_context_manager(self) -> None:
        with patch.object(httpx.Client, "close") as mock_close:
            with MonPayQrClient(QR_CONFIG) as client:
                assert client is not None
            mock_close.assert_called_once()

    def test_basic_auth_header(self) -> None:
        """Verify Basic Auth header is correctly constructed."""
        import base64

        client = MonPayQrClient(QR_CONFIG)
        expected = base64.b64encode(b"test-user:test-account-id").decode()
        assert client._auth_header == f"Basic {expected}"


# ---------------------------------------------------------------------------
# Deeplink Client (sync)
# ---------------------------------------------------------------------------


class TestMonPayDeeplinkClient:
    def _mock_auth(self, mock_post: MagicMock) -> None:
        """Set up mock to handle authenticate() then the actual API call."""
        auth_resp = _mock_response(200, {
            "access_token": "test-token-abc",
            "token_type": "Bearer",
        })
        mock_post.return_value = auth_resp

    def test_authenticate_success(self) -> None:
        auth_resp = _mock_response(200, {
            "access_token": "test-token-abc",
            "token_type": "Bearer",
        })

        with patch.object(httpx.Client, "post", return_value=auth_resp):
            client = MonPayDeeplinkClient(DEEPLINK_CONFIG)
            client.authenticate()
            assert client._access_token == "test-token-abc"

    def test_authenticate_error(self) -> None:
        mock_resp = _mock_response(401, text="Invalid credentials")

        with patch.object(httpx.Client, "post", return_value=mock_resp):
            client = MonPayDeeplinkClient(DEEPLINK_CONFIG)
            with pytest.raises(MonPayError, match="OAuth token request failed: 401"):
                client.authenticate()

    def test_create_deeplink_success(self) -> None:
        auth_resp = _mock_response(200, {
            "access_token": "test-token-abc",
            "token_type": "Bearer",
        })
        create_resp = _mock_response(200, {
            "code": "SUCCESS",
            "intCode": 0,
            "info": "Invoice created",
            "result": {
                "id": 12345,
                "receiver": "branch1",
                "amount": 5000,
                "userId": 1,
                "miniAppId": 10,
                "createDate": "2024-01-01T00:00:00",
                "updateDate": "2024-01-01T00:00:00",
                "status": "NEW",
                "description": "Order #123",
                "redirectUri": "https://example.com/redirect",
                "invoiceType": "P2B",
            },
        })

        call_count = 0

        def side_effect(*args, **kwargs):
            nonlocal call_count
            call_count += 1
            if call_count == 1:
                return auth_resp
            return create_resp

        with patch.object(httpx.Client, "post", side_effect=side_effect):
            client = MonPayDeeplinkClient(DEEPLINK_CONFIG)
            result = client.create_deeplink(5000, "P2B", "branch1", "Order #123")

            assert result.code == "SUCCESS"
            assert result.int_code == 0
            assert result.result.id == 12345
            assert result.result.receiver == "branch1"
            assert result.result.amount == 5000
            assert result.result.status == "NEW"
            assert result.result.invoice_type == "P2B"

    def test_create_deeplink_with_invoice_id(self) -> None:
        auth_resp = _mock_response(200, {
            "access_token": "test-token-abc",
            "token_type": "Bearer",
        })
        create_resp = _mock_response(200, {
            "code": "SUCCESS",
            "intCode": 0,
            "info": "Invoice created",
            "result": {
                "id": 12345,
                "receiver": "branch1",
                "amount": 5000,
                "userId": 1,
                "miniAppId": 10,
                "createDate": "2024-01-01T00:00:00",
                "updateDate": "2024-01-01T00:00:00",
                "status": "NEW",
                "description": "Order #123",
                "redirectUri": "https://example.com/redirect?invoiceId=inv-999",
                "invoiceType": "P2B",
            },
        })

        call_count = 0

        def side_effect(*args, **kwargs):
            nonlocal call_count
            call_count += 1
            if call_count == 1:
                return auth_resp
            return create_resp

        with patch.object(httpx.Client, "post", side_effect=side_effect) as mock_post:
            client = MonPayDeeplinkClient(DEEPLINK_CONFIG)
            result = client.create_deeplink(5000, "P2B", "branch1", "Order #123", invoice_id="inv-999")

            # Verify the redirect URI includes the invoice ID
            create_call = mock_post.call_args_list[1]
            body = create_call[1]["json"]
            assert "invoiceId=inv-999" in body["redirectUri"]

    def test_create_deeplink_error(self) -> None:
        auth_resp = _mock_response(200, {
            "access_token": "test-token-abc",
            "token_type": "Bearer",
        })
        error_resp = _mock_response(400, text="Bad Request")

        call_count = 0

        def side_effect(*args, **kwargs):
            nonlocal call_count
            call_count += 1
            if call_count == 1:
                return auth_resp
            return error_resp

        with patch.object(httpx.Client, "post", side_effect=side_effect):
            client = MonPayDeeplinkClient(DEEPLINK_CONFIG)
            with pytest.raises(MonPayError, match="Deeplink create failed: 400"):
                client.create_deeplink(5000, "P2B", "branch1", "Order #123")

    def test_check_invoice_success(self) -> None:
        auth_resp = _mock_response(200, {
            "access_token": "test-token-abc",
            "token_type": "Bearer",
        })
        check_resp = _mock_response(200, {
            "code": "SUCCESS",
            "intCode": 0,
            "info": "Invoice found",
            "result": {
                "id": 12345,
                "receiver": "branch1",
                "amount": 5000,
                "userId": 1,
                "miniAppId": 10,
                "createDate": "2024-01-01T00:00:00",
                "updateDate": "2024-01-01T00:00:00",
                "status": "PAID",
                "description": "Order #123",
                "statusInfo": "Payment successful",
                "redirectUri": "https://example.com/redirect",
                "invoiceType": "P2B",
                "bankName": "KHAN",
                "bankAccount": "1234567890",
                "bankAccountName": "Test User",
            },
        })

        with patch.object(httpx.Client, "post", return_value=auth_resp):
            with patch.object(httpx.Client, "get", return_value=check_resp):
                client = MonPayDeeplinkClient(DEEPLINK_CONFIG)
                client.authenticate()
                result = client.check_invoice(12345)

                assert result.code == "SUCCESS"
                assert result.result.id == 12345
                assert result.result.status == "PAID"
                assert result.result.bank_name == "KHAN"
                assert result.result.bank_account == "1234567890"

    def test_check_invoice_error(self) -> None:
        auth_resp = _mock_response(200, {
            "access_token": "test-token-abc",
            "token_type": "Bearer",
        })
        error_resp = _mock_response(404, text="Not Found")

        with patch.object(httpx.Client, "post", return_value=auth_resp):
            with patch.object(httpx.Client, "get", return_value=error_resp):
                client = MonPayDeeplinkClient(DEEPLINK_CONFIG)
                client.authenticate()
                with pytest.raises(MonPayError, match="Invoice check failed: 404"):
                    client.check_invoice(99999)

    def test_parse_callback(self) -> None:
        url = "https://example.com/webhook?amount=5000&invoiceId=inv-123&status=paid&tnxId=txn-abc&info=success"
        result = MonPayDeeplinkClient.parse_callback(url)

        assert isinstance(result, DeeplinkCallback)
        assert result.amount == 5000.0
        assert result.invoice_id == "inv-123"
        assert result.status == "paid"
        assert result.tnx_id == "txn-abc"
        assert result.info == "success"

    def test_context_manager(self) -> None:
        with patch.object(httpx.Client, "close") as mock_close:
            with MonPayDeeplinkClient(DEEPLINK_CONFIG) as client:
                assert client is not None
            mock_close.assert_called_once()

    def test_auto_authenticate_on_create(self) -> None:
        """Verify authenticate is called automatically if no token exists."""
        auth_resp = _mock_response(200, {
            "access_token": "auto-token",
            "token_type": "Bearer",
        })
        create_resp = _mock_response(200, {
            "code": "SUCCESS",
            "intCode": 0,
            "info": "ok",
            "result": {
                "id": 1,
                "receiver": "r",
                "amount": 100,
                "userId": 1,
                "miniAppId": 1,
                "createDate": "",
                "updateDate": "",
                "status": "NEW",
                "description": "d",
                "redirectUri": "",
                "invoiceType": "P2B",
            },
        })

        call_count = 0

        def side_effect(*args, **kwargs):
            nonlocal call_count
            call_count += 1
            if call_count == 1:
                return auth_resp
            return create_resp

        with patch.object(httpx.Client, "post", side_effect=side_effect):
            client = MonPayDeeplinkClient(DEEPLINK_CONFIG)
            assert client._access_token is None
            client.create_deeplink(100, "P2B", "r", "d")
            assert client._access_token == "auto-token"


# ---------------------------------------------------------------------------
# Async QR Client
# ---------------------------------------------------------------------------


class TestAsyncMonPayQrClient:
    @pytest.mark.asyncio
    async def test_generate_qr_success(self) -> None:
        mock_resp = _mock_response(200, {
            "code": 0,
            "info": "success",
            "result": {
                "qrcode": "async-base64-qr",
                "uuid": "async-qr-uuid",
            },
        })

        with patch.object(httpx.AsyncClient, "post", return_value=mock_resp):
            client = AsyncMonPayQrClient(QR_CONFIG)
            result = await client.generate_qr(3000)

            assert result.result.qrcode == "async-base64-qr"
            assert result.result.uuid == "async-qr-uuid"

    @pytest.mark.asyncio
    async def test_check_qr_success(self) -> None:
        mock_resp = _mock_response(200, {
            "code": 0,
            "info": "success",
            "result": {
                "uuid": "async-qr-uuid",
                "usedAt": 1700000000,
                "usedById": 1,
                "transactionId": "async-txn",
                "amount": 3000,
                "createdAt": 1699999000,
                "userPhone": "88001122",
                "userAccountNo": "0987654321",
                "userVatId": "VAT456",
                "usedAtUI": "2024-01-01",
                "createdAtUI": "2024-01-01",
                "amountUI": "3,000 MNT",
            },
        })

        with patch.object(httpx.AsyncClient, "get", return_value=mock_resp):
            client = AsyncMonPayQrClient(QR_CONFIG)
            result = await client.check_qr("async-qr-uuid")

            assert result.result.transaction_id == "async-txn"
            assert result.result.amount == 3000

    @pytest.mark.asyncio
    async def test_parse_callback(self) -> None:
        url = "https://example.com/callback?amount=3000&uuid=async-uuid&status=paid&tnxId=txn-999"
        result = AsyncMonPayQrClient.parse_callback(url)
        assert result.amount == 3000.0
        assert result.uuid == "async-uuid"

    @pytest.mark.asyncio
    async def test_async_context_manager(self) -> None:
        with patch.object(httpx.AsyncClient, "aclose") as mock_close:
            async with AsyncMonPayQrClient(QR_CONFIG) as client:
                assert client is not None
            mock_close.assert_called_once()


# ---------------------------------------------------------------------------
# Async Deeplink Client
# ---------------------------------------------------------------------------


class TestAsyncMonPayDeeplinkClient:
    @pytest.mark.asyncio
    async def test_authenticate_success(self) -> None:
        auth_resp = _mock_response(200, {
            "access_token": "async-token",
            "token_type": "Bearer",
        })

        with patch.object(httpx.AsyncClient, "post", return_value=auth_resp):
            client = AsyncMonPayDeeplinkClient(DEEPLINK_CONFIG)
            await client.authenticate()
            assert client._access_token == "async-token"

    @pytest.mark.asyncio
    async def test_create_deeplink_success(self) -> None:
        auth_resp = _mock_response(200, {
            "access_token": "async-token",
            "token_type": "Bearer",
        })
        create_resp = _mock_response(200, {
            "code": "SUCCESS",
            "intCode": 0,
            "info": "ok",
            "result": {
                "id": 99,
                "receiver": "async-branch",
                "amount": 2000,
                "userId": 1,
                "miniAppId": 1,
                "createDate": "",
                "updateDate": "",
                "status": "NEW",
                "description": "async order",
                "redirectUri": "",
                "invoiceType": "P2P",
            },
        })

        call_count = 0

        async def side_effect(*args, **kwargs):
            nonlocal call_count
            call_count += 1
            if call_count == 1:
                return auth_resp
            return create_resp

        with patch.object(httpx.AsyncClient, "post", side_effect=side_effect):
            client = AsyncMonPayDeeplinkClient(DEEPLINK_CONFIG)
            result = await client.create_deeplink(2000, "P2P", "async-branch", "async order")

            assert result.result.id == 99
            assert result.result.receiver == "async-branch"

    @pytest.mark.asyncio
    async def test_check_invoice_success(self) -> None:
        auth_resp = _mock_response(200, {
            "access_token": "async-token",
            "token_type": "Bearer",
        })
        check_resp = _mock_response(200, {
            "code": "SUCCESS",
            "intCode": 0,
            "info": "ok",
            "result": {
                "id": 99,
                "receiver": "async-branch",
                "amount": 2000,
                "userId": 1,
                "miniAppId": 1,
                "createDate": "",
                "updateDate": "",
                "status": "PAID",
                "description": "async order",
                "statusInfo": "Done",
                "redirectUri": "",
                "invoiceType": "P2P",
                "bankName": "GOLOMT",
                "bankAccount": "111222333",
                "bankAccountName": "Async User",
            },
        })

        with patch.object(httpx.AsyncClient, "post", return_value=auth_resp):
            with patch.object(httpx.AsyncClient, "get", return_value=check_resp):
                client = AsyncMonPayDeeplinkClient(DEEPLINK_CONFIG)
                await client.authenticate()
                result = await client.check_invoice(99)

                assert result.result.status == "PAID"
                assert result.result.bank_name == "GOLOMT"

    @pytest.mark.asyncio
    async def test_parse_callback(self) -> None:
        url = "https://example.com/webhook?amount=2000&invoiceId=inv-88&status=paid&tnxId=txn-88&info=ok"
        result = AsyncMonPayDeeplinkClient.parse_callback(url)
        assert result.amount == 2000.0
        assert result.invoice_id == "inv-88"

    @pytest.mark.asyncio
    async def test_async_context_manager(self) -> None:
        with patch.object(httpx.AsyncClient, "aclose") as mock_close:
            async with AsyncMonPayDeeplinkClient(DEEPLINK_CONFIG) as client:
                assert client is not None
            mock_close.assert_called_once()


# ---------------------------------------------------------------------------
# Error class
# ---------------------------------------------------------------------------


class TestMonPayError:
    def test_error_attributes(self) -> None:
        err = MonPayError("test error", 500, "server error body")
        assert str(err) == "test error"
        assert err.status_code == 500
        assert err.response == "server error body"

    def test_error_without_optional_fields(self) -> None:
        err = MonPayError("basic error")
        assert str(err) == "basic error"
        assert err.status_code is None
        assert err.response is None

    def test_error_is_exception(self) -> None:
        err = MonPayError("test")
        assert isinstance(err, Exception)
