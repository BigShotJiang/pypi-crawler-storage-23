from __future__ import annotations

import shutil
from dataclasses import dataclass
from pathlib import Path


@dataclass
class LinuxEnvironment:
    distro_family: str
    has_systemd: bool
    has_python3: bool
    has_venv: bool


def detect_distro_family(os_release_path: Path = Path("/etc/os-release")) -> str:
    if not os_release_path.exists():
        return "unknown"
    values: dict[str, str] = {}
    for raw_line in os_release_path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        values[key] = value.strip().strip('"')
    haystack = " ".join([values.get("ID", ""), values.get("ID_LIKE", "")]).lower()
    if any(token in haystack for token in ("debian", "ubuntu")):
        return "debian"
    if any(token in haystack for token in ("rhel", "fedora", "centos", "rocky", "almalinux")):
        return "rhel"
    if "arch" in haystack:
        return "arch"
    return "unknown"


def detect_linux_environment() -> LinuxEnvironment:
    has_systemd = Path("/run/systemd/system").exists() or shutil.which("systemctl") is not None
    has_python3 = shutil.which("python3") is not None
    has_venv = False
    if has_python3:
        try:
            import venv  # noqa: F401

            has_venv = True
        except Exception:
            has_venv = False
    return LinuxEnvironment(
        distro_family=detect_distro_family(),
        has_systemd=has_systemd,
        has_python3=has_python3,
        has_venv=has_venv,
    )


def missing_venv_guidance(distro_family: str) -> str:
    if distro_family == "debian":
        return "Install python3-venv and python3-full: apt install python3-venv python3-full"
    if distro_family == "rhel":
        return "Install python3 (and python3-venv if separately packaged): dnf install python3"
    return "Install a Python 3 package that includes the venv module."
