from __future__ import annotations

import argparse
import os
import shutil
import stat
import subprocess
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urlparse

from .fs import group_exists, user_exists
from .linux import detect_linux_environment, missing_venv_guidance
from .systemd import write_systemd_unit
from .templates import render_agent_config, render_env_file


def _validate_install_endpoint(endpoint: str) -> None:
    parsed = urlparse(endpoint)
    if parsed.scheme not in {"http", "https"} or not parsed.netloc:
        raise SystemExit(
            "Invalid --endpoint value. Expected absolute URL like https://<your-domain>/v1/ingest"
        )
    if "://" in parsed.path:
        raise SystemExit(
            "Invalid --endpoint value. It looks like the URL contains a nested scheme "
            f"in the path: {endpoint}. Use https://<your-domain>/v1/ingest"
        )


@dataclass
class ActionExecutor:
    dry_run: bool = False
    changes: list[str] = field(default_factory=list)

    def note(self, message: str) -> None:
        self.changes.append(message)
        if self.dry_run:
            print(f"[dry-run] {message}")

    def run(
        self,
        cmd: list[str],
        *,
        secret_values: list[str] | None = None,
    ) -> subprocess.CompletedProcess:
        secret_values = secret_values or []
        display_cmd = " ".join(cmd)
        for secret in secret_values:
            if secret:
                display_cmd = display_cmd.replace(secret, "***")
        self.note(f"run: {display_cmd}")
        if self.dry_run:
            return subprocess.CompletedProcess(cmd, 0)
        return subprocess.run(cmd, check=True, text=True, capture_output=True)

    def ensure_dir(self, path: Path, *, owner: str, group: str, mode: int) -> None:
        if path.exists() and not path.is_dir():
            raise RuntimeError(f"Path exists and is not directory: {path}")
        self.note(f"ensure dir {path} owner={owner}:{group} mode={oct(mode)}")
        if self.dry_run:
            return
        path.mkdir(parents=True, exist_ok=True)
        shutil.chown(path, user=owner, group=group)
        path.chmod(mode)

    def write_file(
        self,
        path: Path,
        content: str,
        *,
        owner: str,
        group: str,
        mode: int,
        force: bool,
    ) -> None:
        existing = path.exists()
        if existing and not force:
            self.note(f"skip file (exists, use --force to overwrite): {path}")
            return
        if existing and force:
            stamp = datetime.now(tz=timezone.utc).strftime("%Y%m%d%H%M%S")
            backup = path.with_name(f"{path.name}.bak-{stamp}")
            self.note(f"backup file {path} -> {backup}")
            if not self.dry_run:
                shutil.copy2(path, backup)
        self.note(f"write file {path} owner={owner}:{group} mode={oct(mode)}")
        if self.dry_run:
            return
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content, encoding="utf-8")
        shutil.chown(path, user=owner, group=group)
        os.chmod(path, mode)

    def remove_path(self, path: Path) -> None:
        if not path.exists():
            self.note(f"skip remove (missing): {path}")
            return
        self.note(f"remove path {path}")
        if self.dry_run:
            return
        if path.is_dir() and not path.is_symlink():
            shutil.rmtree(path)
        else:
            path.unlink()


def _require_root() -> None:
    if os.geteuid() != 0:
        raise SystemExit("Run with sudo")


def _assert_supported_environment() -> None:
    env = detect_linux_environment()
    if not env.has_systemd:
        raise SystemExit("systemd is required for install.")
    if not env.has_python3:
        raise SystemExit("python3 is required for install.")
    if not env.has_venv:
        guidance = missing_venv_guidance(env.distro_family)
        raise SystemExit(
            (
                "python3 venv module is required. "
                f"{guidance}. If you previously used global pip and saw PEP 668 errors, "
                "this installer uses an isolated venv."
            )
        )


def _add_groups(executor: ActionExecutor, *, user: str, add_groups: list[str]) -> None:
    for group in add_groups:
        if group_exists(group):
            executor.run(["usermod", "-aG", group, user])
        else:
            print(f"Warning: group '{group}' not found; skipping")


def _build_add_groups(args: argparse.Namespace) -> list[str]:
    groups = list(args.add_group or [])
    if args.log_access == "adm" and "adm" not in groups:
        groups.append("adm")
    return groups


def run_install(args: argparse.Namespace) -> int:
    _require_root()
    _assert_supported_environment()
    _validate_install_endpoint(args.endpoint)
    executor = ActionExecutor(dry_run=args.dry_run)

    config_path = Path(args.config_path).resolve()
    env_path = Path(args.env_path).resolve()
    state_dir = Path(args.state_dir).resolve()
    venv_dir = Path(args.venv_dir).resolve()
    service_name = args.service_name
    service_path = Path(f"/etc/systemd/system/{service_name}.service")

    if not group_exists(args.group):
        executor.run(["groupadd", "--system", args.group])
    else:
        executor.note(f"group exists: {args.group}")

    if not user_exists(args.user):
        executor.run(
            [
                "useradd",
                "--system",
                "--gid",
                args.group,
                "--home-dir",
                str(state_dir),
                "--shell",
                "/usr/sbin/nologin",
                args.user,
            ]
        )
    else:
        executor.note(f"user exists: {args.user}")

    add_groups = _build_add_groups(args)
    _add_groups(executor, user=args.user, add_groups=add_groups)

    executor.ensure_dir(config_path.parent, owner="root", group=args.group, mode=0o750)
    executor.ensure_dir(state_dir, owner=args.user, group=args.group, mode=0o750)
    executor.ensure_dir(venv_dir.parent, owner="root", group="root", mode=0o755)

    if (venv_dir / "bin" / "python").exists():
        executor.note(f"venv exists: {venv_dir}")
    else:
        executor.run(["python3", "-m", "venv", str(venv_dir)])

    pip_cmd = [str(venv_dir / "bin" / "python"), "-m", "pip"]
    executor.run([*pip_cmd, "install", "--upgrade", "pip"])
    executor.run([*pip_cmd, "install", "-U", "logsentry-agent"])
    bin_path = venv_dir / "bin" / "logsentry-agent"
    executor.run([str(bin_path), "--version"])

    config_body = render_agent_config(
        agent_id=args.agent_id,
        endpoint=args.endpoint,
        state_dir=state_dir,
        source=args.source,
        file_paths=args.file_path or [],
    )
    executor.write_file(
        config_path,
        config_body,
        owner="root",
        group=args.group,
        mode=stat.S_IRUSR | stat.S_IWUSR | stat.S_IRGRP,
        force=args.force,
    )
    executor.write_file(
        env_path,
        render_env_file(args.agent_secret),
        owner="root",
        group=args.group,
        mode=stat.S_IRUSR | stat.S_IWUSR | stat.S_IRGRP,
        force=args.force,
    )

    write_systemd_unit(
        executor=executor,
        service_name=service_name,
        service_path=service_path,
        user=args.user,
        group=args.group,
        env_path=env_path,
        config_path=config_path,
        venv_dir=venv_dir,
        working_dir=state_dir,
        force=args.force,
    )

    executor.run(["systemctl", "daemon-reload"])
    if args.enable:
        executor.run(["systemctl", "enable", service_name])
    if args.start:
        executor.run(["systemctl", "start", service_name])
        executor.run(["systemctl", "is-active", service_name])

    if args.test_send:
        try:
            executor.run(
                [
                    "runuser",
                    "-u",
                    args.user,
                    "--",
                    str(bin_path),
                    "--config",
                    str(config_path),
                    "test-send",
                ]
            )
        except subprocess.CalledProcessError as exc:
            stderr = (exc.stderr or "").strip()
            stdout = (exc.stdout or "").strip()
            details = stderr or stdout or f"Command exited with status {exc.returncode}."
            raise SystemExit(
                "Install completed, but test-send failed. "
                f"Endpoint={args.endpoint}. Expected endpoint format: "
                "https://<your-domain>/v1/ingest\n"
                f"test-send output:\n{details}"
            ) from exc

    print("\nInstall summary")
    print(f"- Config: {config_path}")
    print(f"- Env: {env_path} (secret hidden)")
    print(f"- Service: {service_path}")
    print(f"- Service user: {args.user}:{args.group}")
    print("\nNext steps")
    print(f"- systemctl status {service_name}")
    print(f"- journalctl -u {service_name} -n 100 --no-pager")
    print(f"- logsentry-agent --config {config_path} doctor")

    if args.dry_run:
        print("\nDry-run complete.")
    else:
        print("\nInstalled and running.")
    return 0


def run_uninstall(args: argparse.Namespace) -> int:
    _require_root()
    executor = ActionExecutor(dry_run=args.dry_run)

    state_dir = Path(args.state_dir).resolve()
    config_path = Path(args.config_path).resolve()
    env_path = Path(args.env_path).resolve()
    venv_dir = Path(args.venv_dir).resolve()
    service_path = Path(f"/etc/systemd/system/{args.service_name}.service")

    executor.run(["systemctl", "stop", args.service_name])
    executor.run(["systemctl", "disable", args.service_name])
    executor.remove_path(service_path)
    executor.run(["systemctl", "daemon-reload"])

    executor.remove_path(venv_dir)
    if not args.keep_config:
        executor.remove_path(config_path)
        executor.remove_path(env_path)
        config_parent = config_path.parent
        if config_parent.exists() and not any(config_parent.iterdir()):
            executor.remove_path(config_parent)
    if not args.keep_data:
        executor.remove_path(state_dir)

    if args.remove_user:
        executor.run(["userdel", args.user])
        executor.run(["groupdel", args.group])

    print("Uninstall complete.")
    return 0
