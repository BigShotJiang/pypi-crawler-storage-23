from pathlib import Path

from logsentry_agent.installer.templates import (
    render_agent_config,
    render_env_file,
    render_systemd_unit,
)


def test_render_agent_config_file_source_includes_paths():
    rendered = render_agent_config(
        agent_id="abc",
        endpoint="https://example.com/v1/ingest",
        state_dir=Path("/var/lib/logsentry"),
        source="file",
        file_paths=["/var/log/auth.log"],
    )

    assert "agent_id: abc" in rendered
    assert "endpoint: https://example.com/v1/ingest" in rendered
    assert "state_path: /var/lib/logsentry/state.json" in rendered
    assert "spool_path: /var/lib/logsentry/spool.db" in rendered
    assert "sources:" in rendered
    assert "  - file" in rendered
    assert "    - /var/log/auth.log" in rendered


def test_render_env_file_contains_only_secret():
    assert render_env_file("super-secret") == "LOGSENTRY_AGENT_SECRET=super-secret\n"


def test_render_systemd_unit_hardening_and_execstart():
    rendered = render_systemd_unit(
        service_name="logsentry-agent",
        user="logsentry",
        group="logsentry",
        env_path=Path("/etc/logsentry/logsentry-agent.env"),
        config_path=Path("/etc/logsentry/agent.yml"),
        venv_dir=Path("/opt/logsentry-agent/venv"),
        working_dir=Path("/var/lib/logsentry"),
    )

    assert "User=logsentry" in rendered
    assert "Group=logsentry" in rendered
    assert "EnvironmentFile=/etc/logsentry/logsentry-agent.env" in rendered
    assert (
        "ExecStart=/opt/logsentry-agent/venv/bin/logsentry-agent "
        "--config /etc/logsentry/agent.yml run"
    ) in rendered
    assert "NoNewPrivileges=true" in rendered
    assert "PrivateTmp=true" in rendered
    assert "ProtectSystem=strict" in rendered
    assert "ProtectHome=true" in rendered
    assert "ReadWritePaths=/var/lib/logsentry" in rendered
    assert "ReadOnlyPaths=/etc/logsentry" in rendered
