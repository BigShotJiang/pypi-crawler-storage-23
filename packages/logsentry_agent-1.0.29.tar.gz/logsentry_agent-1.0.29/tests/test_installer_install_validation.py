import pytest
from logsentry_agent.installer.install import _validate_install_endpoint


def test_validate_install_endpoint_accepts_valid_https():
    _validate_install_endpoint("https://example.com/v1/ingest")


def test_validate_install_endpoint_rejects_nested_scheme_in_path():
    with pytest.raises(SystemExit, match="nested scheme"):
        _validate_install_endpoint("https://example.com/https:///v1/ingest")


def test_validate_install_endpoint_rejects_relative_path():
    with pytest.raises(SystemExit, match="Invalid --endpoint"):
        _validate_install_endpoint("/v1/ingest")
