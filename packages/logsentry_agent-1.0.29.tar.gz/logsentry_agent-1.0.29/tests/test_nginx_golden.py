from __future__ import annotations

from pathlib import Path

from logsentry_agent.collectors.nginx import parse_line

from tests.helpers.deterministic_ids import patch_uuid4
from tests.helpers.golden import assert_events_match, load_expected, load_lines
from tests.helpers.host_patch import patch_hostname
from tests.helpers.time_patch import patch_time

FIXTURES = Path(__file__).parent / "fixtures" / "nginx"


def test_nginx_fixtures():
    with patch_hostname(), patch_time(), patch_uuid4("FIXTURE-NGX"):
        for fixture in sorted(FIXTURES.glob("*.input.log")):
            events = [parse_line(line) for line in load_lines(fixture)]
            events = [event for event in events if event is not None]
            expected = load_expected(fixture.with_suffix(fixture.suffix + ".expected.json"))
            assert_events_match(events, expected)


def test_nginx_drops_internal_ingest_requests():
    line = (
        "170.64.168.119 - - [14/Feb/2026:07:30:54 +0000] "
        '"POST /v1/ingest HTTP/1.1" 400 91 "-" "python-requests/2.32.5"'
    )

    assert parse_line(line) is None
