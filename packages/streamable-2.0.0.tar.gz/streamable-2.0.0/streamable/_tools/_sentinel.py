from typing import Any, cast


STOP_ITERATION = cast(Any, object())
