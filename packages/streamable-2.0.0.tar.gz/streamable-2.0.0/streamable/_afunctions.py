from concurrent.futures import Executor
import datetime
from contextlib import suppress
from inspect import iscoroutinefunction
from operator import itemgetter
from typing import (
    Any,
    AsyncIterable,
    AsyncIterator,
    Callable,
    Iterable,
    List,
    Optional,
    Tuple,
    Type,
    TypeVar,
    Union,
    cast,
)

from streamable._tools._observation import Observation

from streamable import _aiterators
from streamable._tools._async import AsyncFunction
from streamable._tools._func import asyncify

with suppress(ImportError):
    pass

T = TypeVar("T")
U = TypeVar("U")
Exc = TypeVar("Exc", bound=Exception)


def buffer(
    aiterator: AsyncIterator[T],
    up_to: int,
) -> AsyncIterator[T]:
    return _aiterators.BufferAsyncIterator(aiterator, up_to)


def catch(
    aiterator: AsyncIterator[T],
    errors: Union[Type[Exc], Tuple[Type[Exc], ...]],
    *,
    where: Optional[Union[Callable[[Exc], Any], AsyncFunction[Exc, Any]]] = None,
    replace: Optional[Union[Callable[[Exc], U], AsyncFunction[Exc, U]]] = None,
    do: Optional[Union[Callable[[Exc], Any], AsyncFunction[Exc, Any]]] = None,
    stop: bool = False,
) -> AsyncIterator[Union[T, U]]:
    return _aiterators.CatchAsyncIterator(
        aiterator,
        errors,
        where=asyncify(where),
        replace=asyncify(replace),
        do=asyncify(do),
        stop=stop,
    )


def filter(
    where: Union[Callable[[T], Any], AsyncFunction[T, Any]],
    aiterator: AsyncIterator[T],
) -> AsyncIterator[T]:
    return _aiterators.FilterAsyncIterator(aiterator, asyncify(where))


def flatten(
    aiterator: AsyncIterator[Union[Iterable[T], AsyncIterable[T]]],
    *,
    concurrency: int = 1,
) -> AsyncIterator[T]:
    if concurrency == 1:
        return _aiterators.FlattenAsyncIterator(aiterator)
    return _aiterators.ConcurrentFlattenAsyncIterator(
        aiterator,
        concurrency=concurrency,
    )


def group(
    aiterator: AsyncIterator[T],
    up_to: Optional[int] = None,
    *,
    within: Optional[datetime.timedelta] = None,
    by: Union[None, Callable[[T], U], AsyncFunction[T, U]] = None,
) -> Union[AsyncIterator[List[T]], AsyncIterator[Tuple[U, List[T]]]]:
    if within is None:
        if by is None:
            return _aiterators.GroupAsyncIterator(aiterator, up_to=up_to)
        return _aiterators.FlattenAsyncIterator(
            _aiterators.GroupByAsyncIterator(
                aiterator, by=cast(AsyncFunction[T, U], asyncify(by)), up_to=up_to
            )
        )
    if by is None:
        return _aiterators.MapAsyncIterator(
            _aiterators.GroupByWithinAsyncIterator(
                aiterator,
                by=asyncify(lambda _: None),
                up_to=up_to,
                within=within,
            ),
            asyncify(itemgetter(1)),
        )
    return _aiterators.GroupByWithinAsyncIterator(
        aiterator, by=asyncify(by), up_to=up_to, within=within
    )


def map(
    into: Union[Callable[[T], U], AsyncFunction[T, U]],
    aiterator: AsyncIterator[T],
    *,
    concurrency: Union[int, Executor] = 1,
    as_completed: bool = False,
) -> AsyncIterator[U]:
    if concurrency == 1:
        return _aiterators.MapAsyncIterator(aiterator, asyncify(into))
    if iscoroutinefunction(into):
        return _aiterators.AsyncConcurrentMapAsyncIterator(
            aiterator,
            cast(AsyncFunction[T, U], into),
            concurrency=cast(int, concurrency),
            as_completed=as_completed,
        )
    else:
        return _aiterators.ExecutorConcurrentMapAsyncIterator(
            aiterator,
            cast(Callable[[T], U], into),
            concurrency=concurrency,
            as_completed=as_completed,
        )


def observe(
    aiterator: AsyncIterator[T],
    subject: str,
    every: Union[None, int, datetime.timedelta],
    do: Union[
        Callable[[Observation], Any],
        AsyncFunction[Observation, Any],
    ],
) -> AsyncIterator[T]:
    if every is None:
        return _aiterators.PowerObserveAsyncIterator(aiterator, subject, asyncify(do))
    elif isinstance(every, int):
        return _aiterators.EveryIntObserveAsyncIterator(
            aiterator, subject, every, asyncify(do)
        )
    return _aiterators.EveryIntervalObserveAsyncIterator(
        aiterator, subject, every, asyncify(do)
    )


def skip(
    aiterator: AsyncIterator[T],
    until: Union[int, Callable[[T], Any], AsyncFunction[T, Any]],
) -> AsyncIterator[T]:
    if isinstance(until, int):
        return _aiterators.CountSkipAsyncIterator(aiterator, until)
    return _aiterators.PredicateSkipAsyncIterator(aiterator, asyncify(until))


def take(
    aiterator: AsyncIterator[T],
    until: Union[int, Callable[[T], Any], AsyncFunction[T, Any]],
) -> AsyncIterator[T]:
    if isinstance(until, int):
        return _aiterators.CountTakeAsyncIterator(aiterator, until)
    return _aiterators.PredicateTakeAsyncIterator(aiterator, asyncify(until))


def throttle(
    aiterator: AsyncIterator[T],
    count: int,
    *,
    per: datetime.timedelta,
) -> AsyncIterator[T]:
    return _aiterators.ThrottleAsyncIterator(aiterator, count, per)
