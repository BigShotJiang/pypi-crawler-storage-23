from streamable.visitors._base import Visitor

Visitor.__module__ = __name__

__all__ = ["Visitor"]
