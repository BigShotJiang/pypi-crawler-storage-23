"""Common schema elements shared across all supported Tableau versions."""

from __future__ import annotations
