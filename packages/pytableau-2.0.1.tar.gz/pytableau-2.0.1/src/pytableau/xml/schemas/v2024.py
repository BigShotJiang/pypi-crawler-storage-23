"""Tableau 2024.x XML schema specifics."""

from __future__ import annotations
