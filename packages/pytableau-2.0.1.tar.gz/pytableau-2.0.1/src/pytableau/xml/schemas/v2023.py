"""Tableau 2023.x XML schema specifics."""

from __future__ import annotations
