# API Reference

## Package Surface

```{py:module} pytableau
```

```{py:currentmodule} pytableau
```

::: pytableau

## Workbook API

::: pytableau.core.workbook.Workbook

## Template Engine

::: pytableau.templates.engine.TemplateEngine

## Inspect & Analysis

::: pytableau.inspect.catalog.WorkbookCatalog
::: pytableau.inspect.lineage.FieldLineage
::: pytableau.inspect.report.WorkbookReport

## Server Workflows

::: pytableau.server.workflows.publish_workbook
::: pytableau.server.workflows.download_workbook
::: pytableau.server.workflows.refresh_workbook
