# [utahML/utah/__init__.py]
from .core import UtahApp
from .perception import OmniRetina
from .memory import EpistemicReactor
from .evolution import Transmuter
from .data import SemanticFluid, ZeroPointNetwork
from .ui import OmniGlass, UtahNotebook
from .acoustic import CymaticResonator
from .stenographer import HolographicStenographer
from .lazarus import LazarusDaemon
from .forge import OntologicalForge
from .swarm import CognitiveSwarm

# Ignite Immortality Protocol automatically upon library import
LazarusDaemon.ignite()
