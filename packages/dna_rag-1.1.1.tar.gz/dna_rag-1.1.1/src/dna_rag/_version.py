"""Single-source version for dna-rag."""

__version__ = "1.1.1"
