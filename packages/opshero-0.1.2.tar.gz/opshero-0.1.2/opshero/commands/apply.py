"""
Apply command — execute a fix suggestion from a previous analysis.

Usage:
  opshero apply                     # use last analysis, interactive pick
  opshero apply <analysis-id>       # specify analysis by ID or prefix
  opshero apply <id> --fix 1        # directly apply fix #1
  opshero apply <id> --dry-run      # print command without running it
  opshero apply <id> --fix 1 --yes  # skip confirmation prompt
"""

import asyncio
import subprocess
import sys
from typing import Optional

import click
from rich.console import Console
from rich.markup import escape
from rich.panel import Panel
from rich.syntax import Syntax
from rich.table import Table

from opshero.api import APIError, AuthError, OpsHeroClient
from opshero.config import Config

console = Console()
err_console = Console(stderr=True)


def _risk_style(risk: str) -> str:
    return {
        "none":   "[dim]none[/dim]",
        "low":    "[green]low[/green]",
        "medium": "[yellow]medium[/yellow]",
        "high":   "[bold red]HIGH[/bold red]",
    }.get(risk, risk)


def _confidence_color(c: float) -> str:
    if c >= 0.8:  return "green"
    if c >= 0.55: return "yellow"
    return "red"


def _render_solutions(solutions: list[dict]) -> None:
    """Print a numbered table of solutions."""
    table = Table(
        show_header=True,
        header_style="bold cyan",
        border_style="dim",
        expand=True,
    )
    table.add_column("#", width=3, justify="right")
    table.add_column("Fix", min_width=22)
    table.add_column("Confidence", width=12, justify="right")
    table.add_column("Risk", width=10)
    table.add_column("Command preview", min_width=24)

    for sol in solutions:
        rank = sol.get("rank", "?")
        title = sol.get("title", "")
        conf = sol.get("confidence", 0.0) or 0.0
        risk = sol.get("risk", "low")
        cmd = sol.get("command") or sol.get("command_template", "")
        color = _confidence_color(conf)

        cmd_preview = cmd.split("\n")[0][:50] + ("…" if len(cmd) > 50 else "") if cmd else "[dim]—[/dim]"

        table.add_row(
            str(rank),
            escape(title),
            f"[{color}]{conf:.0%}[/{color}]",
            _risk_style(risk),
            f"[dim]{escape(cmd_preview)}[/dim]" if cmd else "[dim]—[/dim]",
        )

    console.print(table)


# ── Main command ───────────────────────────────────────────────────────────────

@click.command("apply")
@click.argument("analysis_id", default="", required=False)
@click.option("--fix", "-f", type=int, default=None, help="Fix number to apply (skips interactive pick)")
@click.option("--dry-run", is_flag=True, help="Print command but do not execute")
@click.option("--yes", "-y", is_flag=True, help="Skip confirmation prompt")
def apply_cmd(analysis_id: str, fix: Optional[int], dry_run: bool, yes: bool):
    """
    Apply a fix suggestion from a previous analysis.

    \b
    Examples:
      opshero apply                    # pick from last analysis
      opshero apply 54a177d2           # use 8-char ID prefix
      opshero apply 54a177d2 --fix 1   # apply fix #1 directly
      opshero apply 54a177d2 --dry-run # preview without running
    """
    asyncio.run(_apply(analysis_id or "", fix, dry_run, yes))


async def _apply(analysis_id: str, fix_rank: Optional[int], dry_run: bool, yes: bool) -> None:
    cfg = Config.load()

    if not cfg.is_authenticated:
        err_console.print(
            "[red]Not authenticated.[/red] Run [bold cyan]opshero login[/bold cyan] first."
        )
        raise SystemExit(1)

    async with OpsHeroClient(cfg) as client:
        # ── Resolve analysis ────────────────────────────────────────────────────
        result: dict
        if not analysis_id:
            # Fetch the most recent analysis
            try:
                data = await client.list_analyses(per_page=1)
                items = data.get("items") or data.get("analyses") or []
            except APIError as e:
                err_console.print(f"[red]API error:[/red] {e}")
                raise SystemExit(1)

            if not items:
                err_console.print("[yellow]No analyses found.[/yellow] Run [bold cyan]opshero analyze[/bold cyan] first.")
                raise SystemExit(1)

            result = items[0]
            # Fetch full detail for solutions
            try:
                result = await client.get_analysis(result["id"])
            except APIError as e:
                err_console.print(f"[red]API error:[/red] {e}")
                raise SystemExit(1)
        else:
            # Lookup by full or prefix ID
            try:
                result = await client.get_analysis(analysis_id)
            except APIError as e:
                if e.status_code == 404 and len(analysis_id) < 32:
                    try:
                        data = await client.list_analyses(per_page=100)
                        items = data.get("items") or data.get("analyses") or []
                        matches = [i for i in items if i.get("id", "").startswith(analysis_id)]
                        if not matches:
                            err_console.print(f"[red]Analysis not found:[/red] {analysis_id}")
                            raise SystemExit(1)
                        if len(matches) > 1:
                            err_console.print(f"[yellow]Ambiguous prefix — {len(matches)} matches. Use more characters.[/yellow]")
                            raise SystemExit(1)
                        result = await client.get_analysis(matches[0]["id"])
                    except SystemExit:
                        raise
                    except Exception as inner:
                        err_console.print(f"[red]Error:[/red] {inner}")
                        raise SystemExit(1)
                else:
                    err_console.print(f"[red]API error:[/red] {e}")
                    raise SystemExit(1)

    # ── Validate solutions ──────────────────────────────────────────────────────
    solutions: list[dict] = result.get("solutions") or []
    actionable = [s for s in solutions if s.get("command") or s.get("command_template")]

    if not actionable:
        err_console.print(
            "[yellow]No executable fixes available for this analysis.[/yellow]\n"
            "[dim]This pattern may only have descriptive suggestions.[/dim]"
        )
        raise SystemExit(0)

    pattern_id = result.get("pattern_id", "?")
    category   = result.get("detected_category", "?")
    aid        = result.get("id", "")[:8]

    # ── Show analysis summary ───────────────────────────────────────────────────
    console.print(Panel(
        f"[bold]Analysis:[/bold] [dim]{aid}[/dim]  "
        f"[bold]Pattern:[/bold] [cyan]{escape(pattern_id)}[/cyan]  "
        f"[bold]Category:[/bold] {escape(category)}",
        title="[bold green]OpsHero — Apply Fix[/bold green]",
        border_style="green",
    ))
    console.print()
    _render_solutions(actionable)
    console.print()

    # ── Select fix ─────────────────────────────────────────────────────────────
    chosen: dict
    if fix_rank is not None:
        matched = [s for s in actionable if s.get("rank") == fix_rank]
        if not matched:
            ranks = [str(s.get("rank", "?")) for s in actionable]
            err_console.print(
                f"[red]Fix #{fix_rank} not found.[/red] Available: {', '.join(ranks)}"
            )
            raise SystemExit(1)
        chosen = matched[0]
    else:
        # Interactive prompt
        ranks = [str(s.get("rank", "?")) for s in actionable]
        while True:
            try:
                pick = console.input(
                    f"[dim]Apply fix [bold]#[{', '.join(ranks)}][/bold] (or q to quit): [/dim]"
                ).strip().lower()
            except (EOFError, KeyboardInterrupt):
                console.print("\n[dim]Cancelled.[/dim]")
                raise SystemExit(0)

            if pick in ("q", "quit", ""):
                console.print("[dim]Cancelled.[/dim]")
                raise SystemExit(0)

            try:
                rank_int = int(pick)
                matched = [s for s in actionable if s.get("rank") == rank_int]
                if matched:
                    chosen = matched[0]
                    break
                err_console.print(f"[red]No fix #{rank_int}.[/red]")
            except ValueError:
                err_console.print("[red]Enter a number.[/red]")

    # ── Show chosen fix detail ──────────────────────────────────────────────────
    cmd = chosen.get("command") or chosen.get("command_template", "")
    risk = chosen.get("risk", "low")
    title = chosen.get("title", "")
    explanation = chosen.get("explanation", "")
    reversible = chosen.get("reversible", True)

    console.print(f"\n[bold]Fix #{chosen.get('rank')}:[/bold] {escape(title)}")
    if explanation:
        console.print(f"[dim]{escape(explanation)}[/dim]")
    console.print(f"Risk: {_risk_style(risk)}  Reversible: {'[green]yes[/green]' if reversible else '[yellow]no[/yellow]'}")
    console.print()
    console.print(Syntax(cmd, "bash", theme="monokai", background_color="default", padding=1))
    console.print()

    if dry_run:
        console.print("[dim]Dry-run mode — command not executed.[/dim]")
        raise SystemExit(0)

    # ── Confirmation ────────────────────────────────────────────────────────────
    if not yes:
        # High-risk always gets an explicit warning
        if risk == "high":
            console.print("[bold red]⚠  HIGH RISK[/bold red] — This command may have significant side effects.")
            if not reversible:
                console.print("[yellow]This action is irreversible.[/yellow]")

        try:
            confirm = console.input("[dim]Run this command? [[bold]y[/bold]/N]: [/dim]").strip().lower()
        except (EOFError, KeyboardInterrupt):
            console.print("\n[dim]Cancelled.[/dim]")
            raise SystemExit(0)

        if confirm not in ("y", "yes"):
            console.print("[dim]Aborted.[/dim]")
            raise SystemExit(0)

    # ── Execute ─────────────────────────────────────────────────────────────────
    console.print(f"[dim]Running…[/dim]\n")
    try:
        proc = subprocess.run(
            cmd,
            shell=True,
            text=True,
        )
        if proc.returncode == 0:
            console.print("\n[green]✓[/green] Command completed successfully.")
        else:
            console.print(f"\n[red]✗[/red] Command exited with code {proc.returncode}.")
            raise SystemExit(proc.returncode)
    except FileNotFoundError as e:
        err_console.print(f"[red]Command not found:[/red] {e}")
        raise SystemExit(1)
