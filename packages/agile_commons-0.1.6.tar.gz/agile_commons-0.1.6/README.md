# Agile Commons

A lightweight Python utility package for agile development workflows, providing common tools like config parsing, colored logging.