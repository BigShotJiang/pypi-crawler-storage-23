"""AutoWSGR — 战舰少女R 自动化框架 (v2)"""

__version__ = "2.0.2r1"
