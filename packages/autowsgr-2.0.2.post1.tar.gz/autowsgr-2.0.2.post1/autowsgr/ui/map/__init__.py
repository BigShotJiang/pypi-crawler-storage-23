"""地图页面子包。

re-export 公开 API，外部统一通过 ``autowsgr.ui.map`` 导入。
"""

from autowsgr.ui.map.page import MapPage

__all__ = [
    "MapPage",
]
