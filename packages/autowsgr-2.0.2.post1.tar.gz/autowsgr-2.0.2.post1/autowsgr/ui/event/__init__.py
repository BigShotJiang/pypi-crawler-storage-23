"""活动 UI 控制层。"""

from .event_page import BaseEventPage

__all__ = ["BaseEventPage"]
