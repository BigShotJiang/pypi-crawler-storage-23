from .shipnames import DECISIVE_SKILL_NAMES, SHIPNAMES, update_shipnames

__all__ = [
    "DECISIVE_SKILL_NAMES",
    "SHIPNAMES",
    "update_shipnames",
]