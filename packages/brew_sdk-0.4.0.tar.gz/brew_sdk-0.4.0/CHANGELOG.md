# Changelog

## 0.4.0 (2026-02-20)

Full Changelog: [v0.3.1...v0.4.0](https://github.com/GetBrew/brew-python-sdk/compare/v0.3.1...v0.4.0)

### Features

* **api:** api update ([f3d2494](https://github.com/GetBrew/brew-python-sdk/commit/f3d24942d04e3e186f65d8c07b7d491a8d6bbade))


### Chores

* format all `api.md` files ([2bc375c](https://github.com/GetBrew/brew-python-sdk/commit/2bc375ce74b41faf7f3ff7a428000427568ce775))
* **internal:** remove mock server code ([cdf234d](https://github.com/GetBrew/brew-python-sdk/commit/cdf234dc14172463060a3e4e0decf8df65bbb058))
* update mock server docs ([4a6de76](https://github.com/GetBrew/brew-python-sdk/commit/4a6de76d845506396e7bee7e7c97a4d94be41628))

## 0.3.1 (2026-02-12)

Full Changelog: [v0.3.0...v0.3.1](https://github.com/GetBrew/brew-python-sdk/compare/v0.3.0...v0.3.1)

### Chores

* **internal:** bump dependencies ([cfb2f81](https://github.com/GetBrew/brew-python-sdk/commit/cfb2f81b9d82f691780f58996ca23d7a6c046c25))
* **internal:** fix lint error on Python 3.14 ([d95eeee](https://github.com/GetBrew/brew-python-sdk/commit/d95eeee3f4beb8a0488c33629a512920339e1563))

## 0.3.0 (2026-02-03)

Full Changelog: [v0.2.0...v0.3.0](https://github.com/GetBrew/brew-python-sdk/compare/v0.2.0...v0.3.0)

### Features

* **client:** add custom JSON encoder for extended type support ([11ad7ae](https://github.com/GetBrew/brew-python-sdk/commit/11ad7ae652f437bbeb408b9cae951e5ae4281699))

## 0.2.0 (2026-01-28)

Full Changelog: [v0.1.0...v0.2.0](https://github.com/GetBrew/brew-python-sdk/compare/v0.1.0...v0.2.0)

### Features

* **api:** api update ([ec4e068](https://github.com/GetBrew/brew-python-sdk/commit/ec4e0682f928323d3a3d222336dbbaa0c217ce97))


### Chores

* **ci:** upgrade `actions/github-script` ([e69e877](https://github.com/GetBrew/brew-python-sdk/commit/e69e877a6d7977563a6df9d5b80c5a9ebb83c87b))

## 0.1.0 (2026-01-21)

Full Changelog: [v0.0.1...v0.1.0](https://github.com/GetBrew/brew-python-sdk/compare/v0.0.1...v0.1.0)

### Features

* **api:** api update ([2260b6b](https://github.com/GetBrew/brew-python-sdk/commit/2260b6b69b8afb6445b8b3deffa2a518e04e359e))


### Chores

* configure new SDK language ([375c6d1](https://github.com/GetBrew/brew-python-sdk/commit/375c6d1a3a37f397ff38cd7900c29b4a0dbb1352))
* update SDK settings ([2ecb007](https://github.com/GetBrew/brew-python-sdk/commit/2ecb007217d2269988b273e31f2a9bbd7e107014))
* update SDK settings ([f9a8a95](https://github.com/GetBrew/brew-python-sdk/commit/f9a8a953fee090d15e2fbd5780e07f4caa8fd08e))
