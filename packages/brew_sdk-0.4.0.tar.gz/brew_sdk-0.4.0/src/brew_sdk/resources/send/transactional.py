# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Dict, Union

import httpx

from ..._types import Body, Omit, Query, Headers, NotGiven, SequenceNotStr, omit, not_given
from ..._utils import maybe_transform, async_maybe_transform
from ..._compat import cached_property
from ..._resource import SyncAPIResource, AsyncAPIResource
from ..._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ...types.send import transactional_send_params
from ..._base_client import make_request_options
from ...types.send.transactional_send_response import TransactionalSendResponse
from ...types.send.transactional_documentation_response import TransactionalDocumentationResponse

__all__ = ["TransactionalResource", "AsyncTransactionalResource"]


class TransactionalResource(SyncAPIResource):
    @cached_property
    def with_raw_response(self) -> TransactionalResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/GetBrew/brew-python-sdk#accessing-raw-response-data-eg-headers
        """
        return TransactionalResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> TransactionalResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/GetBrew/brew-python-sdk#with_streaming_response
        """
        return TransactionalResourceWithStreamingResponse(self)

    def documentation(
        self,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> TransactionalDocumentationResponse:
        """Get API documentation and endpoint information"""
        return self._get(
            "/send/transactional",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=TransactionalDocumentationResponse,
        )

    def send(
        self,
        *,
        chat_id: str,
        to: Union[str, SequenceNotStr[str]],
        from_: str | Omit = omit,
        reply_to: str | Omit = omit,
        subject: str | Omit = omit,
        variables: Dict[str, object] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> TransactionalSendResponse:
        """
        Send a transactional email using a published email template.

        **Permission required:** `transactional` or `all`

        The template must be published (status: "live") in Brew before it can be used
        via API.

        Args:
          chat_id: The transactional email template ID (from Brew)

          to: Recipient email(s) - single email or array of up to 1000

          from_: Override default sender email

          reply_to: Reply-to email address

          subject: Override default subject line

          variables: Template variables as key-value pairs

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._post(
            "/send/transactional",
            body=maybe_transform(
                {
                    "chat_id": chat_id,
                    "to": to,
                    "from_": from_,
                    "reply_to": reply_to,
                    "subject": subject,
                    "variables": variables,
                },
                transactional_send_params.TransactionalSendParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=TransactionalSendResponse,
        )


class AsyncTransactionalResource(AsyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AsyncTransactionalResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/GetBrew/brew-python-sdk#accessing-raw-response-data-eg-headers
        """
        return AsyncTransactionalResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncTransactionalResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/GetBrew/brew-python-sdk#with_streaming_response
        """
        return AsyncTransactionalResourceWithStreamingResponse(self)

    async def documentation(
        self,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> TransactionalDocumentationResponse:
        """Get API documentation and endpoint information"""
        return await self._get(
            "/send/transactional",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=TransactionalDocumentationResponse,
        )

    async def send(
        self,
        *,
        chat_id: str,
        to: Union[str, SequenceNotStr[str]],
        from_: str | Omit = omit,
        reply_to: str | Omit = omit,
        subject: str | Omit = omit,
        variables: Dict[str, object] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> TransactionalSendResponse:
        """
        Send a transactional email using a published email template.

        **Permission required:** `transactional` or `all`

        The template must be published (status: "live") in Brew before it can be used
        via API.

        Args:
          chat_id: The transactional email template ID (from Brew)

          to: Recipient email(s) - single email or array of up to 1000

          from_: Override default sender email

          reply_to: Reply-to email address

          subject: Override default subject line

          variables: Template variables as key-value pairs

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._post(
            "/send/transactional",
            body=await async_maybe_transform(
                {
                    "chat_id": chat_id,
                    "to": to,
                    "from_": from_,
                    "reply_to": reply_to,
                    "subject": subject,
                    "variables": variables,
                },
                transactional_send_params.TransactionalSendParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=TransactionalSendResponse,
        )


class TransactionalResourceWithRawResponse:
    def __init__(self, transactional: TransactionalResource) -> None:
        self._transactional = transactional

        self.documentation = to_raw_response_wrapper(
            transactional.documentation,
        )
        self.send = to_raw_response_wrapper(
            transactional.send,
        )


class AsyncTransactionalResourceWithRawResponse:
    def __init__(self, transactional: AsyncTransactionalResource) -> None:
        self._transactional = transactional

        self.documentation = async_to_raw_response_wrapper(
            transactional.documentation,
        )
        self.send = async_to_raw_response_wrapper(
            transactional.send,
        )


class TransactionalResourceWithStreamingResponse:
    def __init__(self, transactional: TransactionalResource) -> None:
        self._transactional = transactional

        self.documentation = to_streamed_response_wrapper(
            transactional.documentation,
        )
        self.send = to_streamed_response_wrapper(
            transactional.send,
        )


class AsyncTransactionalResourceWithStreamingResponse:
    def __init__(self, transactional: AsyncTransactionalResource) -> None:
        self._transactional = transactional

        self.documentation = async_to_streamed_response_wrapper(
            transactional.documentation,
        )
        self.send = async_to_streamed_response_wrapper(
            transactional.send,
        )
