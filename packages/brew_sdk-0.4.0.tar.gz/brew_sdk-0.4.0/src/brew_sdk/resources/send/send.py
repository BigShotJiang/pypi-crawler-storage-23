# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from ..._compat import cached_property
from ..._resource import SyncAPIResource, AsyncAPIResource
from .transactional import (
    TransactionalResource,
    AsyncTransactionalResource,
    TransactionalResourceWithRawResponse,
    AsyncTransactionalResourceWithRawResponse,
    TransactionalResourceWithStreamingResponse,
    AsyncTransactionalResourceWithStreamingResponse,
)

__all__ = ["SendResource", "AsyncSendResource"]


class SendResource(SyncAPIResource):
    @cached_property
    def transactional(self) -> TransactionalResource:
        return TransactionalResource(self._client)

    @cached_property
    def with_raw_response(self) -> SendResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/GetBrew/brew-python-sdk#accessing-raw-response-data-eg-headers
        """
        return SendResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> SendResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/GetBrew/brew-python-sdk#with_streaming_response
        """
        return SendResourceWithStreamingResponse(self)


class AsyncSendResource(AsyncAPIResource):
    @cached_property
    def transactional(self) -> AsyncTransactionalResource:
        return AsyncTransactionalResource(self._client)

    @cached_property
    def with_raw_response(self) -> AsyncSendResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/GetBrew/brew-python-sdk#accessing-raw-response-data-eg-headers
        """
        return AsyncSendResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncSendResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/GetBrew/brew-python-sdk#with_streaming_response
        """
        return AsyncSendResourceWithStreamingResponse(self)


class SendResourceWithRawResponse:
    def __init__(self, send: SendResource) -> None:
        self._send = send

    @cached_property
    def transactional(self) -> TransactionalResourceWithRawResponse:
        return TransactionalResourceWithRawResponse(self._send.transactional)


class AsyncSendResourceWithRawResponse:
    def __init__(self, send: AsyncSendResource) -> None:
        self._send = send

    @cached_property
    def transactional(self) -> AsyncTransactionalResourceWithRawResponse:
        return AsyncTransactionalResourceWithRawResponse(self._send.transactional)


class SendResourceWithStreamingResponse:
    def __init__(self, send: SendResource) -> None:
        self._send = send

    @cached_property
    def transactional(self) -> TransactionalResourceWithStreamingResponse:
        return TransactionalResourceWithStreamingResponse(self._send.transactional)


class AsyncSendResourceWithStreamingResponse:
    def __init__(self, send: AsyncSendResource) -> None:
        self._send = send

    @cached_property
    def transactional(self) -> AsyncTransactionalResourceWithStreamingResponse:
        return AsyncTransactionalResourceWithStreamingResponse(self._send.transactional)
