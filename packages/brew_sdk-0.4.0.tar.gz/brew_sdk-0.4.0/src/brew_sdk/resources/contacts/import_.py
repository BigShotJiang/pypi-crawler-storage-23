# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Any, Iterable, cast

import httpx

from ..._types import Body, Omit, Query, Headers, NotGiven, omit, not_given
from ..._utils import maybe_transform, async_maybe_transform
from ..._compat import cached_property
from ..._resource import SyncAPIResource, AsyncAPIResource
from ..._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ..._base_client import make_request_options
from ...types.contacts import import_create_params, import_get_status_params
from ...types.contacts.import_create_response import ImportCreateResponse
from ...types.contacts.import_get_status_response import ImportGetStatusResponse

__all__ = ["ImportResource", "AsyncImportResource"]


class ImportResource(SyncAPIResource):
    @cached_property
    def with_raw_response(self) -> ImportResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/GetBrew/brew-python-sdk#accessing-raw-response-data-eg-headers
        """
        return ImportResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> ImportResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/GetBrew/brew-python-sdk#with_streaming_response
        """
        return ImportResourceWithStreamingResponse(self)

    def create(
        self,
        *,
        contacts: Iterable[import_create_params.Contact],
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ImportCreateResponse:
        """Import multiple contacts via API.

        Contacts are queued for processing.

        **Permission required:** `contacts` or `all`

        **Note:** Automations are triggered via the dedicated endpoint
        (`/automations/{automationId}/trigger`), not through contact imports.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._post(
            "/contacts/import",
            body=maybe_transform({"contacts": contacts}, import_create_params.ImportCreateParams),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=ImportCreateResponse,
        )

    def get_status(
        self,
        *,
        import_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ImportGetStatusResponse:
        """
        Get the status of an import job or list recent imports.

        **Permission required:** `contacts` or `all`

        Args:
          import_id: Import job ID (omit to list recent imports)

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return cast(
            ImportGetStatusResponse,
            self._get(
                "/contacts/import",
                options=make_request_options(
                    extra_headers=extra_headers,
                    extra_query=extra_query,
                    extra_body=extra_body,
                    timeout=timeout,
                    query=maybe_transform({"import_id": import_id}, import_get_status_params.ImportGetStatusParams),
                ),
                cast_to=cast(
                    Any, ImportGetStatusResponse
                ),  # Union types cannot be passed in as arguments in the type system
            ),
        )


class AsyncImportResource(AsyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AsyncImportResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/GetBrew/brew-python-sdk#accessing-raw-response-data-eg-headers
        """
        return AsyncImportResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncImportResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/GetBrew/brew-python-sdk#with_streaming_response
        """
        return AsyncImportResourceWithStreamingResponse(self)

    async def create(
        self,
        *,
        contacts: Iterable[import_create_params.Contact],
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ImportCreateResponse:
        """Import multiple contacts via API.

        Contacts are queued for processing.

        **Permission required:** `contacts` or `all`

        **Note:** Automations are triggered via the dedicated endpoint
        (`/automations/{automationId}/trigger`), not through contact imports.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._post(
            "/contacts/import",
            body=await async_maybe_transform({"contacts": contacts}, import_create_params.ImportCreateParams),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=ImportCreateResponse,
        )

    async def get_status(
        self,
        *,
        import_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ImportGetStatusResponse:
        """
        Get the status of an import job or list recent imports.

        **Permission required:** `contacts` or `all`

        Args:
          import_id: Import job ID (omit to list recent imports)

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return cast(
            ImportGetStatusResponse,
            await self._get(
                "/contacts/import",
                options=make_request_options(
                    extra_headers=extra_headers,
                    extra_query=extra_query,
                    extra_body=extra_body,
                    timeout=timeout,
                    query=await async_maybe_transform(
                        {"import_id": import_id}, import_get_status_params.ImportGetStatusParams
                    ),
                ),
                cast_to=cast(
                    Any, ImportGetStatusResponse
                ),  # Union types cannot be passed in as arguments in the type system
            ),
        )


class ImportResourceWithRawResponse:
    def __init__(self, import_: ImportResource) -> None:
        self._import_ = import_

        self.create = to_raw_response_wrapper(
            import_.create,
        )
        self.get_status = to_raw_response_wrapper(
            import_.get_status,
        )


class AsyncImportResourceWithRawResponse:
    def __init__(self, import_: AsyncImportResource) -> None:
        self._import_ = import_

        self.create = async_to_raw_response_wrapper(
            import_.create,
        )
        self.get_status = async_to_raw_response_wrapper(
            import_.get_status,
        )


class ImportResourceWithStreamingResponse:
    def __init__(self, import_: ImportResource) -> None:
        self._import_ = import_

        self.create = to_streamed_response_wrapper(
            import_.create,
        )
        self.get_status = to_streamed_response_wrapper(
            import_.get_status,
        )


class AsyncImportResourceWithStreamingResponse:
    def __init__(self, import_: AsyncImportResource) -> None:
        self._import_ = import_

        self.create = async_to_streamed_response_wrapper(
            import_.create,
        )
        self.get_status = async_to_streamed_response_wrapper(
            import_.get_status,
        )
