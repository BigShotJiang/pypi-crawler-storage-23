# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Any, Dict, cast

import httpx

from ...types import contact_delete_params, contact_update_params
from .import_ import (
    ImportResource,
    AsyncImportResource,
    ImportResourceWithRawResponse,
    AsyncImportResourceWithRawResponse,
    ImportResourceWithStreamingResponse,
    AsyncImportResourceWithStreamingResponse,
)
from ..._types import Body, Omit, Query, Headers, NotGiven, SequenceNotStr, omit, not_given
from ..._utils import maybe_transform, async_maybe_transform
from ..._compat import cached_property
from ..._resource import SyncAPIResource, AsyncAPIResource
from ..._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ..._base_client import make_request_options
from ...types.contact_delete_response import ContactDeleteResponse
from ...types.contact_update_response import ContactUpdateResponse

__all__ = ["ContactsResource", "AsyncContactsResource"]


class ContactsResource(SyncAPIResource):
    @cached_property
    def import_(self) -> ImportResource:
        return ImportResource(self._client)

    @cached_property
    def with_raw_response(self) -> ContactsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/GetBrew/brew-python-sdk#accessing-raw-response-data-eg-headers
        """
        return ContactsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> ContactsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/GetBrew/brew-python-sdk#with_streaming_response
        """
        return ContactsResourceWithStreamingResponse(self)

    def update(
        self,
        *,
        email: str,
        custom_fields: Dict[str, object] | Omit = omit,
        first_name: str | Omit = omit,
        last_name: str | Omit = omit,
        subscribed: bool | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ContactUpdateResponse:
        """Update a contact by email address.

        Custom fields are merged with existing values
        (not replaced).

        **Permission required:** `contacts` or `all`

        **Protected fields (cannot be updated):**

        - `email` (used as lookup key)
        - `createdAt`
        - `updatedAt`

        **Note:** Automations are now triggered via the dedicated automation trigger
        endpoint (`/automations/{automationId}/trigger`), not through contact updates.

        Args:
          email: Email address of contact to update (lookup key)

          custom_fields: Custom fields to merge (not replace)

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._patch(
            "/contacts",
            body=maybe_transform(
                {
                    "email": email,
                    "custom_fields": custom_fields,
                    "first_name": first_name,
                    "last_name": last_name,
                    "subscribed": subscribed,
                },
                contact_update_params.ContactUpdateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=ContactUpdateResponse,
        )

    def delete(
        self,
        *,
        email: str,
        delete_fields: SequenceNotStr[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ContactDeleteResponse:
        """
        Delete a contact by email, or delete specific custom fields from a contact.

        **Permission required:** `contacts` or `all`

        If `deleteFields` is provided, only those custom fields are removed. If
        `deleteFields` is omitted, the entire contact is deleted.

        Args:
          email: Email address of contact to delete

          delete_fields: Specific custom fields to delete. If omitted, deletes entire contact. Cannot
              delete standard fields (firstName, lastName, subscribed, tags).

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return cast(
            ContactDeleteResponse,
            self._delete(
                "/contacts",
                body=maybe_transform(
                    {
                        "email": email,
                        "delete_fields": delete_fields,
                    },
                    contact_delete_params.ContactDeleteParams,
                ),
                options=make_request_options(
                    extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
                ),
                cast_to=cast(
                    Any, ContactDeleteResponse
                ),  # Union types cannot be passed in as arguments in the type system
            ),
        )


class AsyncContactsResource(AsyncAPIResource):
    @cached_property
    def import_(self) -> AsyncImportResource:
        return AsyncImportResource(self._client)

    @cached_property
    def with_raw_response(self) -> AsyncContactsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/GetBrew/brew-python-sdk#accessing-raw-response-data-eg-headers
        """
        return AsyncContactsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncContactsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/GetBrew/brew-python-sdk#with_streaming_response
        """
        return AsyncContactsResourceWithStreamingResponse(self)

    async def update(
        self,
        *,
        email: str,
        custom_fields: Dict[str, object] | Omit = omit,
        first_name: str | Omit = omit,
        last_name: str | Omit = omit,
        subscribed: bool | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ContactUpdateResponse:
        """Update a contact by email address.

        Custom fields are merged with existing values
        (not replaced).

        **Permission required:** `contacts` or `all`

        **Protected fields (cannot be updated):**

        - `email` (used as lookup key)
        - `createdAt`
        - `updatedAt`

        **Note:** Automations are now triggered via the dedicated automation trigger
        endpoint (`/automations/{automationId}/trigger`), not through contact updates.

        Args:
          email: Email address of contact to update (lookup key)

          custom_fields: Custom fields to merge (not replace)

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._patch(
            "/contacts",
            body=await async_maybe_transform(
                {
                    "email": email,
                    "custom_fields": custom_fields,
                    "first_name": first_name,
                    "last_name": last_name,
                    "subscribed": subscribed,
                },
                contact_update_params.ContactUpdateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=ContactUpdateResponse,
        )

    async def delete(
        self,
        *,
        email: str,
        delete_fields: SequenceNotStr[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ContactDeleteResponse:
        """
        Delete a contact by email, or delete specific custom fields from a contact.

        **Permission required:** `contacts` or `all`

        If `deleteFields` is provided, only those custom fields are removed. If
        `deleteFields` is omitted, the entire contact is deleted.

        Args:
          email: Email address of contact to delete

          delete_fields: Specific custom fields to delete. If omitted, deletes entire contact. Cannot
              delete standard fields (firstName, lastName, subscribed, tags).

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return cast(
            ContactDeleteResponse,
            await self._delete(
                "/contacts",
                body=await async_maybe_transform(
                    {
                        "email": email,
                        "delete_fields": delete_fields,
                    },
                    contact_delete_params.ContactDeleteParams,
                ),
                options=make_request_options(
                    extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
                ),
                cast_to=cast(
                    Any, ContactDeleteResponse
                ),  # Union types cannot be passed in as arguments in the type system
            ),
        )


class ContactsResourceWithRawResponse:
    def __init__(self, contacts: ContactsResource) -> None:
        self._contacts = contacts

        self.update = to_raw_response_wrapper(
            contacts.update,
        )
        self.delete = to_raw_response_wrapper(
            contacts.delete,
        )

    @cached_property
    def import_(self) -> ImportResourceWithRawResponse:
        return ImportResourceWithRawResponse(self._contacts.import_)


class AsyncContactsResourceWithRawResponse:
    def __init__(self, contacts: AsyncContactsResource) -> None:
        self._contacts = contacts

        self.update = async_to_raw_response_wrapper(
            contacts.update,
        )
        self.delete = async_to_raw_response_wrapper(
            contacts.delete,
        )

    @cached_property
    def import_(self) -> AsyncImportResourceWithRawResponse:
        return AsyncImportResourceWithRawResponse(self._contacts.import_)


class ContactsResourceWithStreamingResponse:
    def __init__(self, contacts: ContactsResource) -> None:
        self._contacts = contacts

        self.update = to_streamed_response_wrapper(
            contacts.update,
        )
        self.delete = to_streamed_response_wrapper(
            contacts.delete,
        )

    @cached_property
    def import_(self) -> ImportResourceWithStreamingResponse:
        return ImportResourceWithStreamingResponse(self._contacts.import_)


class AsyncContactsResourceWithStreamingResponse:
    def __init__(self, contacts: AsyncContactsResource) -> None:
        self._contacts = contacts

        self.update = async_to_streamed_response_wrapper(
            contacts.update,
        )
        self.delete = async_to_streamed_response_wrapper(
            contacts.delete,
        )

    @cached_property
    def import_(self) -> AsyncImportResourceWithStreamingResponse:
        return AsyncImportResourceWithStreamingResponse(self._contacts.import_)
