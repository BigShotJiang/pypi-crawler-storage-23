# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Dict, Optional
from typing_extensions import Literal

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = ["ContactUpdateResponse", "Data", "Meta"]


class Data(BaseModel):
    created_at: Optional[int] = FieldInfo(alias="createdAt", default=None)
    """Unix timestamp in milliseconds"""

    custom_fields: Optional[Dict[str, object]] = FieldInfo(alias="customFields", default=None)

    email: Optional[str] = None

    first_name: Optional[str] = FieldInfo(alias="firstName", default=None)

    last_name: Optional[str] = FieldInfo(alias="lastName", default=None)

    subscribed: Optional[bool] = None

    updated_at: Optional[int] = FieldInfo(alias="updatedAt", default=None)
    """Unix timestamp in milliseconds"""


class Meta(BaseModel):
    request_id: Optional[str] = FieldInfo(alias="requestId", default=None)


class ContactUpdateResponse(BaseModel):
    data: Data

    success: Literal[True]

    meta: Optional[Meta] = None
