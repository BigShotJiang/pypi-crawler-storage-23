# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional
from typing_extensions import Literal

from pydantic import Field as FieldInfo

from ..._models import BaseModel

__all__ = ["TransactionalSendResponse", "Data", "DataDroppedRecipient", "DataResult", "Meta", "Warning"]


class DataDroppedRecipient(BaseModel):
    email: Optional[str] = None
    """Blocked email address"""

    reason: Optional[str] = None
    """Reason for block (e.g., "bounced", "unsubscribed", "suppressed")"""


class DataResult(BaseModel):
    id: Optional[str] = None
    """Email ID (if successful)"""

    email: Optional[str] = None

    error: Optional[str] = None
    """Error message (if failed)"""


class Data(BaseModel):
    dropped: Optional[int] = None
    """Number of recipients blocked from sending (suppressed, bounced, etc.)"""

    dropped_recipients: Optional[List[DataDroppedRecipient]] = FieldInfo(alias="droppedRecipients", default=None)
    """Recipients that were blocked from sending"""

    failed: Optional[int] = None
    """Number of emails that failed to send"""

    results: Optional[List[DataResult]] = None

    sent: Optional[int] = None
    """Number of emails sent successfully"""


class Meta(BaseModel):
    request_id: Optional[str] = FieldInfo(alias="requestId", default=None)


class Warning(BaseModel):
    """Present if some recipients were dropped"""

    code: Optional[Literal["RECIPIENTS_DROPPED"]] = None
    """Warning code"""

    message: Optional[str] = None
    """Human-readable warning message"""


class TransactionalSendResponse(BaseModel):
    data: Data

    success: bool
    """True if at least one email was sent successfully"""

    meta: Optional[Meta] = None

    warning: Optional[Warning] = None
    """Present if some recipients were dropped"""
