# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Dict, Union
from typing_extensions import Required, Annotated, TypedDict

from ..._types import SequenceNotStr
from ..._utils import PropertyInfo

__all__ = ["TransactionalSendParams"]


class TransactionalSendParams(TypedDict, total=False):
    chat_id: Required[Annotated[str, PropertyInfo(alias="chatId")]]
    """The transactional email template ID (from Brew)"""

    to: Required[Union[str, SequenceNotStr[str]]]
    """Recipient email(s) - single email or array of up to 1000"""

    from_: Annotated[str, PropertyInfo(alias="from")]
    """Override default sender email"""

    reply_to: Annotated[str, PropertyInfo(alias="replyTo")]
    """Reply-to email address"""

    subject: str
    """Override default subject line"""

    variables: Dict[str, object]
    """Template variables as key-value pairs"""
