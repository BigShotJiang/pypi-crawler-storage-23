# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional

from ..._models import BaseModel

__all__ = ["TransactionalDocumentationResponse", "Endpoint"]


class Endpoint(BaseModel):
    description: Optional[str] = None

    methods: Optional[List[str]] = None

    path: Optional[str] = None


class TransactionalDocumentationResponse(BaseModel):
    """API documentation and endpoint information"""

    documentation: Optional[str] = None
    """Link to full API documentation"""

    endpoints: Optional[List[Endpoint]] = None
    """List of available endpoints"""

    version: Optional[str] = None
    """API version"""
