# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Union, Optional
from typing_extensions import Literal, TypeAlias

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = [
    "ContactDeleteResponse",
    "DeleteContactResponse",
    "DeleteContactResponseData",
    "DeleteContactResponseMeta",
    "DeleteFieldsResponse",
    "DeleteFieldsResponseData",
    "DeleteFieldsResponseMeta",
]


class DeleteContactResponseData(BaseModel):
    deleted: Optional[Literal[True]] = None

    email: Optional[str] = None


class DeleteContactResponseMeta(BaseModel):
    request_id: Optional[str] = FieldInfo(alias="requestId", default=None)


class DeleteContactResponse(BaseModel):
    data: DeleteContactResponseData

    success: Literal[True]

    meta: Optional[DeleteContactResponseMeta] = None


class DeleteFieldsResponseData(BaseModel):
    deleted_fields: Optional[List[str]] = FieldInfo(alias="deletedFields", default=None)

    missing_fields: Optional[List[str]] = FieldInfo(alias="missingFields", default=None)
    """Fields that were requested but didn't exist"""


class DeleteFieldsResponseMeta(BaseModel):
    request_id: Optional[str] = FieldInfo(alias="requestId", default=None)


class DeleteFieldsResponse(BaseModel):
    data: DeleteFieldsResponseData

    success: Literal[True]

    meta: Optional[DeleteFieldsResponseMeta] = None


ContactDeleteResponse: TypeAlias = Union[DeleteContactResponse, DeleteFieldsResponse]
