# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Required, Annotated, TypedDict

from .._types import SequenceNotStr
from .._utils import PropertyInfo

__all__ = ["ContactDeleteParams"]


class ContactDeleteParams(TypedDict, total=False):
    email: Required[str]
    """Email address of contact to delete"""

    delete_fields: Annotated[SequenceNotStr[str], PropertyInfo(alias="deleteFields")]
    """Specific custom fields to delete.

    If omitted, deletes entire contact. Cannot delete standard fields (firstName,
    lastName, subscribed, tags).
    """
