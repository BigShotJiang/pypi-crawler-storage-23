# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional
from typing_extensions import Literal

from pydantic import Field as FieldInfo

from ..._models import BaseModel

__all__ = ["ImportCreateResponse", "Data", "DataError", "DataStats", "Meta"]


class DataError(BaseModel):
    email: Optional[str] = None

    error: Optional[str] = None

    index: Optional[int] = None


class DataStats(BaseModel):
    invalid: Optional[int] = None
    """Invalid contacts (validation errors)"""

    total: Optional[int] = None
    """Total contacts in request"""

    valid: Optional[int] = None
    """Valid contacts queued for import"""


class Data(BaseModel):
    errors: Optional[List[DataError]] = None
    """First 10 validation errors"""

    import_id: Optional[str] = FieldInfo(alias="importId", default=None)
    """Import job ID for status tracking"""

    stats: Optional[DataStats] = None


class Meta(BaseModel):
    request_id: Optional[str] = FieldInfo(alias="requestId", default=None)


class ImportCreateResponse(BaseModel):
    data: Data

    success: Literal[True]

    message: Optional[str] = None

    meta: Optional[Meta] = None
