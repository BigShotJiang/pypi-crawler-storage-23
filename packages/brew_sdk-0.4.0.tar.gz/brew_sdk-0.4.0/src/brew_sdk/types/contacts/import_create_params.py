# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Dict, Iterable
from typing_extensions import Required, Annotated, TypedDict

from ..._utils import PropertyInfo

__all__ = ["ImportCreateParams", "Contact"]


class ImportCreateParams(TypedDict, total=False):
    contacts: Required[Iterable[Contact]]


class Contact(TypedDict, total=False):
    email: Required[str]
    """Contact email address (required)"""

    custom_fields: Annotated[Dict[str, object], PropertyInfo(alias="customFields")]
    """Custom fields as key-value pairs"""

    first_name: Annotated[str, PropertyInfo(alias="firstName")]
    """First name"""

    last_name: Annotated[str, PropertyInfo(alias="lastName")]
    """Last name"""

    subscribed: bool
    """Subscription status (default true)"""
