# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Union, Optional
from typing_extensions import Literal, TypeAlias

from pydantic import Field as FieldInfo

from ..._models import BaseModel

__all__ = [
    "ImportGetStatusResponse",
    "ImportStatusResponse",
    "ImportStatusResponseData",
    "ImportStatusResponseDataImport",
    "ImportStatusResponseMeta",
    "ImportListResponse",
    "ImportListResponseData",
    "ImportListResponseDataImport",
    "ImportListResponseMeta",
]


class ImportStatusResponseDataImport(BaseModel):
    id: Optional[str] = None

    added_count: Optional[int] = FieldInfo(alias="addedCount", default=None)

    created_at: Optional[int] = FieldInfo(alias="createdAt", default=None)

    error_count: Optional[int] = FieldInfo(alias="errorCount", default=None)

    error_message: Optional[str] = FieldInfo(alias="errorMessage", default=None)

    file_name: Optional[str] = FieldInfo(alias="fileName", default=None)

    processed_rows: Optional[int] = FieldInfo(alias="processedRows", default=None)

    status: Optional[Literal["pending", "processing", "completed", "failed"]] = None

    total_rows: Optional[int] = FieldInfo(alias="totalRows", default=None)

    updated_at: Optional[int] = FieldInfo(alias="updatedAt", default=None)

    updated_count: Optional[int] = FieldInfo(alias="updatedCount", default=None)


class ImportStatusResponseData(BaseModel):
    import_: Optional[ImportStatusResponseDataImport] = FieldInfo(alias="import", default=None)


class ImportStatusResponseMeta(BaseModel):
    request_id: Optional[str] = FieldInfo(alias="requestId", default=None)


class ImportStatusResponse(BaseModel):
    data: ImportStatusResponseData

    success: Literal[True]

    meta: Optional[ImportStatusResponseMeta] = None


class ImportListResponseDataImport(BaseModel):
    id: Optional[str] = None

    added_count: Optional[int] = FieldInfo(alias="addedCount", default=None)

    created_at: Optional[int] = FieldInfo(alias="createdAt", default=None)

    error_count: Optional[int] = FieldInfo(alias="errorCount", default=None)

    file_name: Optional[str] = FieldInfo(alias="fileName", default=None)

    processed_rows: Optional[int] = FieldInfo(alias="processedRows", default=None)

    status: Optional[str] = None

    total_rows: Optional[int] = FieldInfo(alias="totalRows", default=None)

    updated_at: Optional[int] = FieldInfo(alias="updatedAt", default=None)

    updated_count: Optional[int] = FieldInfo(alias="updatedCount", default=None)


class ImportListResponseData(BaseModel):
    imports: Optional[List[ImportListResponseDataImport]] = None


class ImportListResponseMeta(BaseModel):
    request_id: Optional[str] = FieldInfo(alias="requestId", default=None)


class ImportListResponse(BaseModel):
    data: ImportListResponseData

    success: Literal[True]

    meta: Optional[ImportListResponseMeta] = None


ImportGetStatusResponse: TypeAlias = Union[ImportStatusResponse, ImportListResponse]
