# Contacts

Types:

```python
from brew_sdk.types import ContactUpdateResponse, ContactDeleteResponse
```

Methods:

- <code title="patch /contacts">client.contacts.<a href="./src/brew_sdk/resources/contacts/contacts.py">update</a>(\*\*<a href="src/brew_sdk/types/contact_update_params.py">params</a>) -> <a href="./src/brew_sdk/types/contact_update_response.py">ContactUpdateResponse</a></code>
- <code title="delete /contacts">client.contacts.<a href="./src/brew_sdk/resources/contacts/contacts.py">delete</a>(\*\*<a href="src/brew_sdk/types/contact_delete_params.py">params</a>) -> <a href="./src/brew_sdk/types/contact_delete_response.py">ContactDeleteResponse</a></code>

## Import

Types:

```python
from brew_sdk.types.contacts import ImportCreateResponse, ImportGetStatusResponse
```

Methods:

- <code title="post /contacts/import">client.contacts.import*.<a href="./src/brew_sdk/resources/contacts/import*.py">create</a>(\*\*<a href="src/brew_sdk/types/contacts/import_create_params.py">params</a>) -> <a href="./src/brew_sdk/types/contacts/import_create_response.py">ImportCreateResponse</a></code>
- <code title="get /contacts/import">client.contacts.import*.<a href="./src/brew_sdk/resources/contacts/import*.py">get_status</a>(\*\*<a href="src/brew_sdk/types/contacts/import_get_status_params.py">params</a>) -> <a href="./src/brew_sdk/types/contacts/import_get_status_response.py">ImportGetStatusResponse</a></code>

# Send

## Transactional

Types:

```python
from brew_sdk.types.send import TransactionalDocumentationResponse, TransactionalSendResponse
```

Methods:

- <code title="get /send/transactional">client.send.transactional.<a href="./src/brew_sdk/resources/send/transactional.py">documentation</a>() -> <a href="./src/brew_sdk/types/send/transactional_documentation_response.py">TransactionalDocumentationResponse</a></code>
- <code title="post /send/transactional">client.send.transactional.<a href="./src/brew_sdk/resources/send/transactional.py">send</a>(\*\*<a href="src/brew_sdk/types/send/transactional_send_params.py">params</a>) -> <a href="./src/brew_sdk/types/send/transactional_send_response.py">TransactionalSendResponse</a></code>
