"""ml3macro Pydantic - Base models and frozen dict type for ml3macro projects."""
