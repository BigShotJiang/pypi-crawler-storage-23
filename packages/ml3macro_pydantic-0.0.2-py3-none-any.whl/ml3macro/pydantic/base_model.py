"""Base Pydantic model with GalaxyFlow-specific configurations"""

from pydantic import BaseModel, ConfigDict  # type: ignore[attr-defined]
from pydantic.alias_generators import to_camel


class ML3MacroBaseModel(BaseModel):
    """Base model for all GalaxyFlow Pydantic models.

    Features:
    - Automatic camelCase alias generation for JSON serialization
    - Consistent naming conventions
    - GalaxyFlow-specific configurations
    - Hashability for use in sets and dictionaries
    """

    model_config = ConfigDict(
        alias_generator=to_camel,
        populate_by_name=True,
        from_attributes=True,
        arbitrary_types_allowed=True,
        use_enum_values=False,
        extra="forbid",
        frozen=True,
    )

    def __hash__(self) -> int:
        """Make models hashable based on their content.

        This enables models to be used in sets and as dictionary keys.
        Hash is based on the model's field values to ensure consistent hashing.
        """
        # Use a tuple of field values for consistent hashing
        # Only include fields that are hashable themselves
        hashable_fields = []
        for field_name, field_value in self.__dict__.items():
            if (
                isinstance(field_value, (str, int, float, bool, tuple, frozenset))
                or field_value is None
            ):
                hashable_fields.append((field_name, field_value))
            elif hasattr(field_value, "__hash__") and callable(
                getattr(field_value, "__hash__")
            ):
                try:
                    hash(field_value)  # Test if it's actually hashable
                    hashable_fields.append((field_name, field_value))
                except TypeError:
                    # Skip unhashable fields
                    pass

        return hash(tuple(hashable_fields))
