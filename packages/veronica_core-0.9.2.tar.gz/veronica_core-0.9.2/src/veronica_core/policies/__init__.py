"""VERONICA Runtime Policies."""
from veronica_core.policies.minimal_response import MinimalResponsePolicy

__all__ = ["MinimalResponsePolicy"]
