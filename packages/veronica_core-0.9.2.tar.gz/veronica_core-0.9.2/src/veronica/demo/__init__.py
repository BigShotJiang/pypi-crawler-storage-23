"""VERONICA LLM Control OS -- CLI demo."""
