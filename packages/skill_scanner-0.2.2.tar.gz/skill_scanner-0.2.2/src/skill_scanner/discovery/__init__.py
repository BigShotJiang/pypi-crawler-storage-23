"""Discovery utilities."""

from skill_scanner.discovery.finder import discover_targets

__all__ = ["discover_targets"]
