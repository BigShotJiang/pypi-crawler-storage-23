"""Module entry point for python -m skill_scanner."""

from skill_scanner.cli import app

if __name__ == "__main__":
    app()
