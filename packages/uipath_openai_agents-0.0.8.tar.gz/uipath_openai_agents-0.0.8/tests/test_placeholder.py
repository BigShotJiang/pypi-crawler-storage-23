"""Placeholder test file for uipath-openai-agents package."""


def test_placeholder():
    """Placeholder test to ensure pytest runs successfully."""
    assert True
