#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Stock Data Kit 범용 MCP Server (무료 데이터 통합)

FastMCP 기반 로컬 MCP 서버 (포트 8200)
13개 함수를 하나의 datakit_call 도구로 통합 제공.

도구 3개:
  - datakit_call           : 13개 함수 범용 호출 + DB 자동저장
  - datakit_list_functions : 사용 가능한 함수 카탈로그
  - datakit_get_env_info   : 환경 정보 + API 키 상태

데이터 소스 5개:
  [PyKRX]       get_price, get_ohlcv, get_supply, search_stock, get_market_cap, get_index
  [DART 공시]   dart_disclosures, dart_company
  [ECOS 거시]   ecos_indicator
  [환율]        exchange_rate
  [지배구조]    governance_majority, governance_bulk_holding, governance_executives

DB 저장 흐름:
  1) hub_api_responses — 모든 호출 무조건 JSONB 저장
  2) 정규화 테이블 — function 라우팅
     get_price/get_ohlcv/get_market_cap → shared_ohlcv
     get_supply                         → shared_supply
     dart_disclosures                   → shared_dart_disclosures
     ecos_indicator                     → shared_macro (source='ecos')
     exchange_rate                      → shared_macro (source='exchange_rate')

필요한 환경변수:
  PG_HOST, PG_PORT, PG_DB, PG_USER, PG_PASSWORD  (PostgreSQL)
  DART_API_KEY   (DART 공시 + 지배구조)
  ECOS_API_KEY   (한국은행 경제지표)
  EXIM_API_KEY   (수출입은행 환율)
"""

import os
import json
import hashlib
import logging
import time
import ssl
import urllib.request
import urllib.parse
import urllib.error
from datetime import datetime, timedelta

from fastmcp import FastMCP
from response import ok_response, error_response, ErrorCode

try:
    from pykrx import stock as pykrx_stock
    _HAS_PYKRX = True
except ImportError:
    _HAS_PYKRX = False
    print("[WARN] pykrx not installed - PyKRX disabled")

try:
    import psycopg2
    import psycopg2.extras
    _HAS_PG = True
except ImportError:
    _HAS_PG = False

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("datakit")

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# 상수 정의
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

DART_API_BASE = "https://opendart.fss.or.kr/api"
ECOS_API_BASE = "https://ecos.bok.or.kr/api/StatisticSearch"
EXIM_API_URL = "https://www.koreaexim.go.kr/site/program/financial/exchangeJSON"

# ECOS 경제지표 코드 (통계표코드, 항목코드, 주기, 단위, 설명)
ECOS_INDICATORS = {
    "기준금리": ("722Y001", "0101000", "M", "%", "한국은행 기준금리"),
    "CPI": ("901Y009", "0", "M", "2020=100", "소비자물가지수"),
    "GDP성장률": ("200Y002", "10111", "Q", "%", "실질GDP성장률(전년동기대비)"),
    "실업률": ("901Y027", "2222", "M", "%", "실업률(계절조정)"),
    "코스피지수": ("802Y001", "0001000", "D", "pt", "코스피지수(종가기준)"),
}

# 환율 주요 통화
EXCHANGE_CURRENCIES = {
    "USD": "미국 달러", "EUR": "유럽연합 유로", "JPY": "일본 엔(100)",
    "CNH": "중국 위안", "GBP": "영국 파운드", "AUD": "호주 달러",
    "CAD": "캐나다 달러", "CHF": "스위스 프랑", "HKD": "홍콩 달러",
    "SGD": "싱가포르 달러",
}

# 지배구조 분기코드
QUARTER_CODES = {1: "11013", 2: "11012", 3: "11014", 4: "11011"}

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# function → 정규화 테이블 라우팅
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

_NORMALIZED_ROUTES = {
    "get_price": "ohlcv",           # → shared_ohlcv
    "get_ohlcv": "ohlcv",           # → shared_ohlcv
    "get_supply": "supply",         # → shared_supply
    "get_market_cap": "ohlcv",      # → shared_ohlcv (market_cap)
    "dart_disclosures": "dart",     # → shared_dart_disclosures
    "ecos_indicator": "macro",      # → shared_macro (source='ecos')
    "exchange_rate": "macro",       # → shared_macro (source='exchange_rate')
}

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# 함수 카탈로그 (LLM이 참조)
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

_FUNCTIONS = {
    # ── PyKRX (6개) ──
    "get_price": {
        "source": "PyKRX", "name": "현재가 조회",
        "description": "종목의 현재가(최근 거래일 종가) 조회",
        "params": {"ticker": "종목코드 (예: '005930')"},
        "api_key": None,
    },
    "get_ohlcv": {
        "source": "PyKRX", "name": "일봉 데이터",
        "description": "종목의 일봉(OHLCV) 데이터 조회",
        "params": {"ticker": "종목코드", "days": "조회 일수 (기본 10)"},
        "api_key": None,
    },
    "get_supply": {
        "source": "PyKRX", "name": "투자자별 수급",
        "description": "기관/외국인/개인 순매수 데이터",
        "params": {"ticker": "종목코드", "days": "조회 일수 (기본 10)"},
        "api_key": None,
    },
    "search_stock": {
        "source": "PyKRX", "name": "종목 검색",
        "description": "종목명/코드로 검색 (최대 20건)",
        "params": {"keyword": "검색어"},
        "api_key": None,
    },
    "get_market_cap": {
        "source": "PyKRX", "name": "시가총액 조회",
        "description": "시가총액, PER, PBR 등 기본 정보",
        "params": {"ticker": "종목코드"},
        "api_key": None,
    },
    "get_index": {
        "source": "PyKRX", "name": "지수 데이터",
        "description": "코스피/코스닥 등 지수 데이터",
        "params": {"index_name": "코스피/코스닥/코스피200/KRX100", "days": "조회 일수 (기본 10)"},
        "api_key": None,
    },
    # ── DART 공시 (2개) ──
    "dart_disclosures": {
        "source": "DART", "name": "공시 목록 조회",
        "description": "기간별 상장기업 공시 목록 (전자공시시스템)",
        "params": {
            "days": "최근 N일 (기본 3)",
            "start_date": "시작일 (YYYY-MM-DD, days 대신 사용)",
            "end_date": "종료일 (YYYY-MM-DD)",
            "market": "Y=유가증권, K=코스닥, N=코넥스 (선택, 기본=전체)",
        },
        "api_key": "DART_API_KEY",
    },
    "dart_company": {
        "source": "DART", "name": "기업개황 조회",
        "description": "DART 고유번호로 기업개황 조회 (CEO, 설립일 등)",
        "params": {"corp_code": "DART 고유번호 (8자리, 예: '00126380')"},
        "api_key": "DART_API_KEY",
    },
    # ── ECOS 거시지표 (1개) ──
    "ecos_indicator": {
        "source": "ECOS", "name": "경제지표 조회",
        "description": "한국은행 경제지표 (기준금리, CPI, GDP성장률, 실업률, 코스피지수)",
        "params": {
            "indicator": "지표명 (기준금리/CPI/GDP성장률/실업률/코스피지수)",
            "days": "최근 N일 (기본 365)",
            "start_date": "시작일 (YYYYMMDD, days 대신 사용)",
            "end_date": "종료일 (YYYYMMDD)",
        },
        "api_key": "ECOS_API_KEY",
    },
    # ── 환율 (1개) ──
    "exchange_rate": {
        "source": "수출입은행", "name": "환율 조회",
        "description": "주요 통화 환율 (매매기준율, 전신환매입/매도율)",
        "params": {
            "date": "조회일 (YYYY-MM-DD, 기본=오늘)",
            "currencies": "통화 리스트 (기본=['USD','EUR','JPY'])",
        },
        "api_key": "EXIM_API_KEY",
    },
    # ── 지배구조 (3개) ──
    "governance_majority": {
        "source": "DART", "name": "최대주주 변동",
        "description": "최대주주 변동 현황 (DART 사업보고서 기반)",
        "params": {
            "corp_codes": "DART 고유번호 리스트 (예: ['00126380'])",
            "year": "사업연도 (예: 2025)",
            "quarter": "분기 (1~4, 기본=4 사업보고서)",
        },
        "api_key": "DART_API_KEY",
    },
    "governance_bulk_holding": {
        "source": "DART", "name": "대량보유 상황보고",
        "description": "대량보유 상황보고 (지분공시) 검색",
        "params": {
            "corp_codes": "DART 고유번호 리스트",
            "year": "사업연도 (예: 2025)",
        },
        "api_key": "DART_API_KEY",
    },
    "governance_executives": {
        "source": "DART", "name": "임원 현황",
        "description": "임원 현황 조회 (DART 사업보고서 기반)",
        "params": {
            "corp_codes": "DART 고유번호 리스트",
            "year": "사업연도 (예: 2025)",
            "quarter": "분기 (1~4, 기본=4 사업보고서)",
        },
        "api_key": "DART_API_KEY",
    },
}

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# PostgreSQL 자동저장
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

_pg_conn = None
_pg_getter = None  # Gateway에서 주입, 없으면 로컬 _get_pg 사용


def _get_pg():
    """PostgreSQL 연결 (재사용, 실패 시 None)"""
    global _pg_conn
    if not _HAS_PG:
        return None
    try:
        if _pg_conn is None or _pg_conn.closed:
            _pg_conn = psycopg2.connect(
                host=os.getenv("PG_HOST", "localhost"),
                port=int(os.getenv("PG_PORT", "5432")),
                dbname=os.getenv("PG_DB", "shared_data_lake"),
                user=os.getenv("PG_USER", "hub"),
                password=os.getenv("PG_PASSWORD", ""),
                connect_timeout=5,
            )
            _pg_conn.autocommit = True
            logger.info("[DB] PostgreSQL 연결 성공 (datakit)")
        return _pg_conn
    except Exception as e:
        logger.warning(f"[DB] PostgreSQL 연결 실패: {e}")
        return None


def _db_save(func_name: str, params: dict, result: dict):
    """API 응답을 hub_api_responses(통합 로그) + 정규화 테이블에 동시 저장"""
    conn = (_pg_getter or _get_pg)()
    if not conn:
        return
    try:
        p_json = json.dumps(params, ensure_ascii=False, default=str)
        p_hash = hashlib.md5(p_json.encode()).hexdigest()
        r_json = json.dumps(result, ensure_ascii=False, default=str)

        with conn.cursor() as cur:
            # 1) hub_api_responses — 모든 호출 무조건 저장
            cur.execute(
                """INSERT INTO hub_api_responses (tool_name, params_hash, params, response)
                   VALUES (%s, %s, %s::jsonb, %s::jsonb)""",
                (f"datakit:{func_name}", p_hash, p_json, r_json),
            )
            # 2) 정규화 테이블 — 성공 응답만
            if result.get("ok"):
                _db_save_normalized(cur, func_name, params, result.get("data"))
    except Exception as e:
        logger.warning(f"[DB] 저장 실패 (datakit:{func_name}): {e}")


def _db_save_normalized(cur, func_name: str, params: dict, data):
    """function 기반 정규화 테이블 라우팅 저장"""
    route = _NORMALIZED_ROUTES.get(func_name)
    if not route:
        return  # 매핑 없는 함수 → hub_api_responses만

    source = "datakit"
    ticker = params.get("ticker", "")

    # ── shared_ohlcv ──
    if route == "ohlcv":
        if func_name == "get_price" and isinstance(data, dict) and ticker:
            cur.execute(
                """INSERT INTO shared_ohlcv (source, ticker, date, open, high, low, close, volume)
                   VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
                   ON CONFLICT (source, ticker, date) DO NOTHING""",
                (source, ticker, data.get("date"), data.get("open"),
                 data.get("high"), data.get("low"), data.get("close"),
                 data.get("volume")),
            )
        elif func_name == "get_ohlcv" and isinstance(data, list) and ticker:
            for row in data:
                if isinstance(row, dict) and not row.get("error"):
                    cur.execute(
                        """INSERT INTO shared_ohlcv (source, ticker, date, open, high, low, close, volume)
                           VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
                           ON CONFLICT (source, ticker, date) DO NOTHING""",
                        (source, ticker, row.get("date"), row.get("open"),
                         row.get("high"), row.get("low"), row.get("close"),
                         row.get("volume")),
                    )
        elif func_name == "get_market_cap" and isinstance(data, dict) and ticker:
            cur.execute(
                """INSERT INTO shared_ohlcv (source, ticker, date, market_cap)
                   VALUES (%s, %s, %s, %s)
                   ON CONFLICT (source, ticker, date) DO UPDATE SET market_cap = EXCLUDED.market_cap""",
                (source, ticker, data.get("date"), data.get("market_cap")),
            )

    # ── shared_supply ──
    elif route == "supply":
        if isinstance(data, list) and ticker:
            for row in data:
                if isinstance(row, dict) and not row.get("error"):
                    cur.execute(
                        """INSERT INTO shared_supply (source, ticker, date, inst_buy, foreign_buy, individual_buy)
                           VALUES (%s, %s, %s, %s, %s, %s)
                           ON CONFLICT (source, ticker, date) DO NOTHING""",
                        (source, ticker, row.get("date"),
                         row.get("institution_net"), row.get("foreign_net"),
                         row.get("individual_net")),
                    )

    # ── shared_dart_disclosures ──
    elif route == "dart":
        if isinstance(data, list):
            for item in data:
                if isinstance(item, dict) and item.get("rcpt_no"):
                    cur.execute(
                        """INSERT INTO shared_dart_disclosures
                               (rcpNo, corpCode, corpName, reportNm, rcptDt, flrNm, rmk)
                           VALUES (%s, %s, %s, %s, %s, %s, %s)
                           ON CONFLICT (rcpNo) DO NOTHING""",
                        (item.get("rcpt_no"), item.get("corp_code"),
                         item.get("corp_name"), item.get("report_nm"),
                         item.get("rcpt_dt"), item.get("flr_nm"),
                         item.get("corp_cls")),
                    )

    # ── shared_macro (ECOS / 환율) ──
    elif route == "macro":
        if func_name == "ecos_indicator" and isinstance(data, list):
            for row in data:
                if isinstance(row, dict):
                    cur.execute(
                        """INSERT INTO shared_macro (source, indicator, date, value, unit)
                           VALUES (%s, %s, %s, %s, %s)
                           ON CONFLICT (source, indicator, date) DO NOTHING""",
                        ("ecos", row.get("indicator"), row.get("date"),
                         row.get("value"), row.get("unit")),
                    )
        elif func_name == "exchange_rate" and isinstance(data, list):
            for row in data:
                if isinstance(row, dict):
                    cur.execute(
                        """INSERT INTO shared_macro (source, indicator, date, value, unit)
                           VALUES (%s, %s, %s, %s, %s)
                           ON CONFLICT (source, indicator, date) DO NOTHING""",
                        ("exchange_rate", row.get("currency"),
                         row.get("date"), row.get("deal_bas_r"), "KRW"),
                    )


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# 공통 헬퍼
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

def _check_api_key(env_var: str) -> str:
    """환경변수에서 API 키를 가져오고, 없으면 에러 dict 반환용 문자열"""
    val = os.getenv(env_var)
    if not val:
        raise ValueError(f"{env_var} 환경변수가 설정되지 않았습니다")
    return val


def _http_get_json(url: str, timeout: int = 15) -> dict:
    """HTTP GET → JSON 파싱 (한국 정부 사이트 SSL 호환)"""
    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    req = urllib.request.Request(url)
    req.add_header("User-Agent", "Mozilla/5.0 (DataKit MCP)")
    with urllib.request.urlopen(req, timeout=timeout, context=ctx) as resp:
        return json.loads(resp.read().decode("utf-8"))


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# PyKRX 내부 구현 (6개)
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

def _get_recent_trading_date(max_days_back: int = 10) -> str:
    """최근 거래일 (비거래일 대응)"""
    today = datetime.now()
    for i in range(max_days_back):
        check_date = today - timedelta(days=i)
        date_str = check_date.strftime("%Y%m%d")
        try:
            df = pykrx_stock.get_index_ohlcv(date_str, date_str, "1001")
            if not df.empty:
                return date_str
        except Exception as e:
            logger.debug(f"[PyKRX] {date_str} 조회 실패: {e}")
            continue
    return today.strftime("%Y%m%d")


def _format_date(date_str: str) -> str:
    if isinstance(date_str, str) and len(date_str) == 8:
        return f"{date_str[:4]}-{date_str[4:6]}-{date_str[6:]}"
    return str(date_str)


def _impl_get_price(ticker: str):
    if not _HAS_PYKRX:
        return {"error": True, "message": "pykrx 미설치"}
    date_str = _get_recent_trading_date()
    df = pykrx_stock.get_market_ohlcv_by_date(date_str, date_str, ticker)
    if df.empty:
        return {"error": True, "message": f"종목코드 {ticker}의 데이터를 찾을 수 없습니다."}
    row = df.iloc[0]
    prev_date = (datetime.strptime(date_str, "%Y%m%d") - timedelta(days=7)).strftime("%Y%m%d")
    df_prev = pykrx_stock.get_market_ohlcv_by_date(prev_date, date_str, ticker)
    change_pct = 0.0
    if len(df_prev) >= 2:
        prev_close = df_prev.iloc[-2]['종가']
        curr_close = row['종가']
        change_pct = round(((curr_close - prev_close) / prev_close) * 100, 2)
    return {
        "ticker": ticker, "date": _format_date(date_str),
        "open": int(row['시가']), "high": int(row['고가']),
        "low": int(row['저가']), "close": int(row['종가']),
        "volume": int(row['거래량']), "change_pct": change_pct,
    }


def _impl_get_ohlcv(ticker: str, days: int = 10):
    if not _HAS_PYKRX:
        return [{"error": True, "message": "pykrx 미설치"}]
    end_date = _get_recent_trading_date()
    start_date = (datetime.strptime(end_date, "%Y%m%d") - timedelta(days=days * 2)).strftime("%Y%m%d")
    df = pykrx_stock.get_market_ohlcv_by_date(start_date, end_date, ticker)
    if df.empty:
        return [{"error": True, "message": f"종목코드 {ticker}의 데이터를 찾을 수 없습니다."}]
    df = df.tail(days)
    result = []
    for date, row in df.iterrows():
        result.append({
            "date": date.strftime("%Y-%m-%d") if hasattr(date, 'strftime') else str(date),
            "open": int(row['시가']), "high": int(row['고가']),
            "low": int(row['저가']), "close": int(row['종가']),
            "volume": int(row['거래량']),
        })
    return result


def _impl_get_supply(ticker: str, days: int = 10):
    if not _HAS_PYKRX:
        return [{"error": True, "message": "pykrx 미설치"}]
    end_date = _get_recent_trading_date()
    start_date = (datetime.strptime(end_date, "%Y%m%d") - timedelta(days=days * 2)).strftime("%Y%m%d")
    df = pykrx_stock.get_market_trading_value_by_date(start_date, end_date, ticker)
    if df.empty:
        return [{"error": True, "message": f"종목코드 {ticker}의 수급 데이터를 찾을 수 없습니다."}]
    df = df.tail(days)
    result = []
    for date, row in df.iterrows():
        result.append({
            "date": date.strftime("%Y-%m-%d") if hasattr(date, 'strftime') else str(date),
            "institution_net": int(row.get('기관', 0)),
            "foreign_net": int(row.get('외국인', 0)),
            "individual_net": int(row.get('개인', 0)),
        })
    return result


# 종목명 캐시 (한 번만 로딩)
_TICKER_NAME_CACHE = {}
_TICKER_NAME_CACHE_TIME = 0

def _impl_search_stock(keyword: str):
    global _TICKER_NAME_CACHE, _TICKER_NAME_CACHE_TIME
    if not _HAS_PYKRX:
        return [{"error": True, "message": "pykrx 미설치"}]

    # 캐시 갱신 (6시간마다)
    now = time.time()
    if not _TICKER_NAME_CACHE or (now - _TICKER_NAME_CACHE_TIME) > 21600:
        try:
            kospi = pykrx_stock.get_market_ticker_list(market="KOSPI")
            kosdaq = pykrx_stock.get_market_ticker_list(market="KOSDAQ")
            cache = {}
            for t in kospi:
                try:
                    cache[t] = (pykrx_stock.get_market_ticker_name(t), "KOSPI")
                except Exception:
                    pass
            for t in kosdaq:
                try:
                    cache[t] = (pykrx_stock.get_market_ticker_name(t), "KOSDAQ")
                except Exception:
                    pass
            _TICKER_NAME_CACHE = cache
            _TICKER_NAME_CACHE_TIME = now
            logger.info(f"[PyKRX] 종목명 캐시 로딩: {len(cache)}종목")
        except Exception as e:
            logger.warning(f"[PyKRX] 종목명 캐시 로딩 실패: {e}")
            if not _TICKER_NAME_CACHE:
                return [{"error": True, "message": f"종목 목록 조회 실패: {e}"}]

    keyword_lower = keyword.lower()
    result = []
    for ticker, (name, market) in _TICKER_NAME_CACHE.items():
        if keyword_lower in ticker.lower() or keyword_lower in name.lower():
            result.append({"ticker": ticker, "name": name, "market": market})
            if len(result) >= 20:
                break

    if not result:
        return [{"error": False, "message": f"'{keyword}' 검색 결과가 없습니다."}]
    return result


def _impl_get_market_cap(ticker: str):
    if not _HAS_PYKRX:
        return {"error": True, "message": "pykrx 미설치"}
    date_str = _get_recent_trading_date()
    df = pykrx_stock.get_market_cap_by_date(date_str, date_str, ticker)
    if df.empty:
        return {"error": True, "message": f"종목코드 {ticker}의 시가총액 데이터를 찾을 수 없습니다."}
    row = df.iloc[0]
    name = pykrx_stock.get_market_ticker_name(ticker)
    df_fund = pykrx_stock.get_market_fundamental_by_date(date_str, date_str, ticker)
    per, pbr = 0.0, 0.0
    if not df_fund.empty:
        fund_row = df_fund.iloc[0]
        per = round(fund_row.get('PER', 0.0), 2)
        pbr = round(fund_row.get('PBR', 0.0), 2)
    return {
        "ticker": ticker, "name": name, "date": _format_date(date_str),
        "market_cap": int(row['시가총액']), "shares": int(row['상장주식수']),
        "per": per, "pbr": pbr,
    }


def _impl_get_index(index_name: str = "코스피", days: int = 10):
    if not _HAS_PYKRX:
        return [{"error": True, "message": "pykrx 미설치"}]
    index_map = {"코스피": "1001", "코스닥": "2001", "코스피200": "1028", "KRX100": "1006"}
    index_code = index_map.get(index_name, "1001")
    end_date = _get_recent_trading_date()
    start_date = (datetime.strptime(end_date, "%Y%m%d") - timedelta(days=days * 2)).strftime("%Y%m%d")
    df = pykrx_stock.get_index_ohlcv(start_date, end_date, index_code)
    if df.empty:
        return [{"error": True, "message": f"지수 {index_name}의 데이터를 찾을 수 없습니다."}]
    df = df.tail(days)
    result = []
    prev_close = None
    for date, row in df.iterrows():
        change_pct = 0.0
        if prev_close is not None:
            change_pct = round(((row['종가'] - prev_close) / prev_close) * 100, 2)
        result.append({
            "date": date.strftime("%Y-%m-%d") if hasattr(date, 'strftime') else str(date),
            "close": float(row['종가']),
            "change_pct": change_pct,
            "volume": int(row.get('거래량', 0)),
        })
        prev_close = row['종가']
    return result


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# DART 공시 내부 구현 (2개)
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

def _dart_api(endpoint: str, params: dict) -> dict:
    """DART OpenAPI 공통 호출"""
    api_key = _check_api_key("DART_API_KEY")
    params["crtfc_key"] = api_key
    url = f"{DART_API_BASE}/{endpoint}?{urllib.parse.urlencode(params)}"
    data = _http_get_json(url)
    status = data.get("status", "")
    if status == "000":
        return data
    elif status == "013":
        return {"status": "013", "list": []}
    else:
        raise ValueError(f"DART API 오류 [{status}]: {data.get('message', '')}")


def _impl_dart_disclosures(days: int = 3, start_date: str = None,
                           end_date: str = None, market: str = None):
    """공시 목록 조회"""
    if start_date:
        s = datetime.strptime(start_date, "%Y-%m-%d")
    else:
        s = datetime.now() - timedelta(days=days)
    if end_date:
        e = datetime.strptime(end_date, "%Y-%m-%d")
    else:
        e = datetime.now()

    all_items = []
    seen = set()
    current = s
    while current <= e:
        date_str = current.strftime("%Y%m%d")
        params = {"bgn_de": date_str, "end_de": date_str,
                  "page_no": "1", "page_count": "100"}
        if market:
            params["corp_cls"] = market

        resp = _dart_api("list.json", params)
        for item in resp.get("list", []):
            rcpt_no = item.get("rcept_no")
            if rcpt_no and rcpt_no not in seen:
                seen.add(rcpt_no)
                all_items.append({
                    "rcpt_no": rcpt_no,
                    "corp_cls": item.get("corp_cls"),
                    "corp_code": item.get("corp_code"),
                    "corp_name": item.get("corp_name"),
                    "report_nm": item.get("report_nm"),
                    "rcpt_dt": item.get("rcept_dt"),
                    "flr_nm": item.get("flr_nm"),
                })

        current += timedelta(days=1)
        time.sleep(0.3)

    return all_items


def _impl_dart_company(corp_code: str):
    """기업개황 조회"""
    data = _dart_api("company.json", {"corp_code": corp_code})
    return {
        "corp_code": data.get("corp_code"),
        "corp_name": data.get("corp_name"),
        "stock_code": data.get("stock_code"),
        "ceo_nm": data.get("ceo_nm"),
        "corp_cls": data.get("corp_cls"),
        "est_dt": data.get("est_dt"),
        "acc_mt": data.get("acc_mt"),
    }


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# ECOS 거시지표 내부 구현 (1개)
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

def _impl_ecos_indicator(indicator: str, days: int = 365,
                         start_date: str = None, end_date: str = None):
    """경제지표 단일 조회"""
    api_key = _check_api_key("ECOS_API_KEY")

    if indicator not in ECOS_INDICATORS:
        avail = list(ECOS_INDICATORS.keys())
        return {"error": True, "message": f"알 수 없는 지표: {indicator}", "available": avail}

    stat_code, item_code, cycle, unit, desc = ECOS_INDICATORS[indicator]

    if start_date:
        s = start_date
    else:
        s = (datetime.now() - timedelta(days=days)).strftime("%Y%m%d")
    if end_date:
        e = end_date
    else:
        e = datetime.now().strftime("%Y%m%d")

    # 주기별 날짜 포맷 조정
    if cycle == "M":
        s, e = s[:6], e[:6]
    elif cycle == "Q":
        sq = (int(s[4:6]) - 1) // 3 + 1
        eq = (int(e[4:6]) - 1) // 3 + 1
        s, e = f"{s[:4]}Q{sq}", f"{e[:4]}Q{eq}"
    elif cycle == "Y":
        s, e = s[:4], e[:4]

    url = f"{ECOS_API_BASE}/{api_key}/json/kr/1/100000/{stat_code}/{cycle}/{s}/{e}/{item_code}"
    data = _http_get_json(url, timeout=30)

    if "StatisticSearch" not in data:
        return []

    rows = data["StatisticSearch"].get("row", [])
    result = []
    for row in rows:
        try:
            date_str = row.get("TIME", "")
            value_str = row.get("DATA_VALUE", "0")
            if cycle == "D":
                date_obj = datetime.strptime(date_str, "%Y%m%d")
            elif cycle == "M":
                date_obj = datetime.strptime(date_str, "%Y%m")
            elif cycle == "Q":
                year = int(date_str[:4])
                quarter = int(date_str[-1])
                date_obj = datetime(year, (quarter - 1) * 3 + 1, 1)
            elif cycle == "Y":
                date_obj = datetime.strptime(date_str, "%Y")
            else:
                date_obj = datetime.strptime(date_str, "%Y%m%d")
            result.append({
                "indicator": indicator,
                "date": date_obj.strftime("%Y-%m-%d"),
                "value": float(value_str),
                "unit": unit,
            })
        except (ValueError, KeyError):
            continue

    return result


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# 환율 내부 구현 (1개)
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

def _impl_exchange_rate(date: str = None, currencies: list = None):
    """환율 조회 (단일 날짜)"""
    api_key = _check_api_key("EXIM_API_KEY")

    if date:
        search_date = datetime.strptime(date, "%Y-%m-%d").strftime("%Y%m%d")
    else:
        search_date = datetime.now().strftime("%Y%m%d")

    if not currencies:
        currencies = ["USD", "EUR", "JPY"]

    import requests as _req
    params = {"authkey": api_key, "searchdate": search_date, "data": "AP01"}
    resp = _req.get(EXIM_API_URL, params=params, verify=False, timeout=15)
    data = resp.json()

    if not isinstance(data, list) or not data:
        return [{"error": False, "message": f"{search_date}: 데이터 없음 (주말/공휴일 가능)"}]

    currency_set = set(currencies)
    result = []
    for row in data:
        cur_unit = row.get("cur_unit", "")
        # JPY(100) → JPY
        currency_code = cur_unit.split("(")[0] if "(" in cur_unit else cur_unit
        if currency_code not in currency_set:
            continue

        deal_bas_r = row.get("deal_bas_r", "0").replace(",", "")
        bkpr = row.get("bkpr", "0").replace(",", "")
        ttb = row.get("ttb", "0").replace(",", "")
        tts = row.get("tts", "0").replace(",", "")

        display_date = f"{search_date[:4]}-{search_date[4:6]}-{search_date[6:]}"
        result.append({
            "date": display_date,
            "currency": currency_code,
            "currency_name": row.get("cur_nm", ""),
            "deal_bas_r": float(deal_bas_r) if deal_bas_r else 0.0,
            "bkpr": float(bkpr) if bkpr else 0.0,
            "ttb": float(ttb) if ttb else 0.0,
            "tts": float(tts) if tts else 0.0,
        })

    if not result:
        return [{"error": False, "message": f"{search_date}: 요청한 통화 데이터 없음"}]
    return result


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# 지배구조 내부 구현 (3개)
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

def _impl_governance_majority(corp_codes: list, year: int, quarter: int = 4):
    """최대주주 변동 수집"""
    reprt_code = QUARTER_CODES.get(quarter, "11011")
    all_rows = []
    for code in corp_codes:
        resp = _dart_api("hyslrChgSttus.json", {
            "corp_code": code, "bsns_year": str(year), "reprt_code": reprt_code,
        })
        all_rows.extend(resp.get("list", []))
        time.sleep(0.3)
    return all_rows


def _impl_governance_bulk_holding(corp_codes: list, year: int):
    """대량보유 상황보고 검색"""
    bgn_de = f"{year}0101"
    end_de = f"{year}1231"
    all_rows = []
    for code in corp_codes:
        resp = _dart_api("list.json", {
            "corp_code": code, "bgn_de": bgn_de, "end_de": end_de,
            "pblntf_ty": "I", "page_no": "1", "page_count": "100",
        })
        bulk = [r for r in resp.get("list", []) if "대량보유" in r.get("report_nm", "")]
        all_rows.extend(bulk)
        time.sleep(0.3)
    return all_rows


def _impl_governance_executives(corp_codes: list, year: int, quarter: int = 4):
    """임원 현황 수집"""
    reprt_code = QUARTER_CODES.get(quarter, "11011")
    all_rows = []
    for code in corp_codes:
        resp = _dart_api("exctvSttus.json", {
            "corp_code": code, "bsns_year": str(year), "reprt_code": reprt_code,
        })
        all_rows.extend(resp.get("list", []))
        time.sleep(0.3)
    return all_rows


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# function → 구현 매핑
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

_FUNCTION_MAP = {
    # PyKRX
    "get_price": _impl_get_price,
    "get_ohlcv": _impl_get_ohlcv,
    "get_supply": _impl_get_supply,
    "search_stock": _impl_search_stock,
    "get_market_cap": _impl_get_market_cap,
    "get_index": _impl_get_index,
    # DART
    "dart_disclosures": _impl_dart_disclosures,
    "dart_company": _impl_dart_company,
    # ECOS
    "ecos_indicator": _impl_ecos_indicator,
    # 환율
    "exchange_rate": _impl_exchange_rate,
    # 지배구조
    "governance_majority": _impl_governance_majority,
    "governance_bulk_holding": _impl_governance_bulk_holding,
    "governance_executives": _impl_governance_executives,
}


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# MCP 도구 등록
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

def register_tools(mcp, get_pg=None):
    """FastMCP 인스턴스에 Stock Data Kit 도구 3개 등록

    Args:
        mcp: FastMCP 인스턴스
        get_pg: PostgreSQL 연결 함수 (공유용, None이면 로컬 _get_pg 사용)
    """
    global _pg_getter
    if get_pg is not None:
        _pg_getter = get_pg

    @mcp.tool()
    def datakit_call(function: str, params_json: str = "{}") -> dict:
        """Stock Data Kit 범용 함수 호출 — 과거 주가/공시/거시지표 (무료, 키 불필요)

        USE THIS WHEN: 과거 주가, 일봉/시총, 종목검색, DART 공시, ECOS 금리, 환율 조회
        DO NOT USE: 실시간 현재가/호가 → kiwoom_call_api, 뉴스 → news_search_stock

        5개 데이터 소스 (PyKRX, DART 공시, ECOS 거시지표, 환율, 지배구조) 통합.

        Args:
            function: 함수명 (아래 13개 중 택1)
              [PyKRX 무료]  get_price, get_ohlcv, get_supply, search_stock, get_market_cap, get_index
              [DART 키필요] dart_disclosures, dart_company
              [ECOS 키필요] ecos_indicator
              [환율 키필요] exchange_rate
              [지배구조]    governance_majority, governance_bulk_holding, governance_executives
            params_json: JSON 문자열 파라미터

        Returns:
            {"success": true, "data": {...}, "function": "..."}

        DB 자동저장:
            - hub_api_responses: 모든 호출 JSONB 저장
            - shared_ohlcv: get_price/get_ohlcv/get_market_cap
            - shared_supply: get_supply
            - shared_dart_disclosures: dart_disclosures
            - shared_macro: ecos_indicator (source='ecos'), exchange_rate (source='exchange_rate')

        사용 예시:
            datakit_call("get_price", '{"ticker":"005930"}')
            datakit_call("dart_disclosures", '{"days":3}')
            datakit_call("ecos_indicator", '{"indicator":"기준금리","days":365}')
            datakit_call("exchange_rate", '{"currencies":["USD","EUR"]}')
            datakit_call("governance_majority", '{"corp_codes":["00126380"],"year":2025}')
        """
        try:
            params = json.loads(params_json) if params_json else {}
        except json.JSONDecodeError:
            return error_response(ErrorCode.INVALID_PARAMS, "params_json 파싱 실패", source="datakit", meta={"function": function})

        impl = _FUNCTION_MAP.get(function)
        if not impl:
            return error_response(
                ErrorCode.NOT_FOUND,
                f"알 수 없는 함수: {function}",
                source="datakit",
                meta={"function": function, "available": list(_FUNCTION_MAP.keys())},
            )

        try:
            data = impl(**params)
            # 에러 체크 (내부 함수가 error dict/list 반환하는 경우)
            is_error = False
            if isinstance(data, dict) and data.get("error"):
                is_error = True
            elif isinstance(data, list) and data and isinstance(data[0], dict) and data[0].get("error"):
                is_error = True

            if is_error:
                if isinstance(data, dict) and data.get("error"):
                    msg = str(data["error"])
                elif isinstance(data, list) and data and isinstance(data[0], dict) and data[0].get("error"):
                    msg = str(data[0]["error"])
                else:
                    msg = "API 오류"
                result = error_response(ErrorCode.API_ERROR, msg, source="datakit", meta={"function": function})
            else:
                result = ok_response(data, source="datakit", meta={"function": function})
        except ValueError as e:
            # API 키 미설정 등
            result = error_response(ErrorCode.API_KEY_MISSING, str(e), source="datakit", meta={"function": function})
        except TypeError as e:
            result = error_response(ErrorCode.INVALID_PARAMS, f"파라미터 오류: {e}", source="datakit", meta={"function": function})
        except Exception as e:
            result = error_response(ErrorCode.UNKNOWN, str(e), source="datakit", meta={"function": function, "error_type": type(e).__name__})

        try:
            _db_save(function, params, result)
        except Exception as e:
            logger.warning(f"[DB] datakit_call 저장 실패: {e}")
        return result


    @mcp.tool()
    def datakit_list_functions() -> dict:
        """Stock Data Kit 13개 함수 카탈로그

        Returns:
            소스별 함수 목록 + 파라미터 설명 + 정규화 테이블 매핑 + 사용법 예시
        """
        # 소스별 그룹핑
        by_source = {}
        for fname, info in _FUNCTIONS.items():
            src = info["source"]
            by_source.setdefault(src, []).append({
                "function": fname,
                "name": info["name"],
                "description": info["description"],
                "params": info["params"],
                "api_key_required": info.get("api_key"),
            })

        return ok_response(
            {
                "total_count": len(_FUNCTIONS),
                "sources": by_source,
                "normalized_tables": {
                    "get_price": "shared_ohlcv",
                    "get_ohlcv": "shared_ohlcv",
                    "get_supply": "shared_supply",
                    "get_market_cap": "shared_ohlcv",
                    "dart_disclosures": "shared_dart_disclosures",
                    "ecos_indicator": "shared_macro (source='ecos')",
                    "exchange_rate": "shared_macro (source='exchange_rate')",
                    "search_stock": "hub_api_responses only",
                    "get_index": "hub_api_responses only",
                    "dart_company": "hub_api_responses only",
                    "governance_majority": "hub_api_responses only",
                    "governance_bulk_holding": "hub_api_responses only",
                    "governance_executives": "hub_api_responses only",
                },
                "usage_examples": [
                    'datakit_call("get_price", \'{"ticker":"005930"}\')',
                    'datakit_call("get_ohlcv", \'{"ticker":"005930","days":30}\')',
                    'datakit_call("dart_disclosures", \'{"days":3,"market":"Y"}\')',
                    'datakit_call("dart_company", \'{"corp_code":"00126380"}\')',
                    'datakit_call("ecos_indicator", \'{"indicator":"기준금리","days":365}\')',
                    'datakit_call("exchange_rate", \'{"currencies":["USD","EUR","JPY"]}\')',
                    'datakit_call("governance_majority", \'{"corp_codes":["00126380"],"year":2025}\')',
                ],
            },
            source="datakit",
        )


    @mcp.tool()
    def datakit_get_env_info() -> dict:
        """Stock Data Kit 환경 정보 + API 키 상태

        Returns:
            서버 정보, 함수 수, DB 상태, API 키 설정 여부
        """
        api_keys = {
            "DART_API_KEY": bool(os.getenv("DART_API_KEY")),
            "ECOS_API_KEY": bool(os.getenv("ECOS_API_KEY")),
            "EXIM_API_KEY": bool(os.getenv("EXIM_API_KEY")),
        }

        # 소스별 활성화 상태
        sources = {
            "PyKRX": _HAS_PYKRX,
            "DART": api_keys["DART_API_KEY"],
            "ECOS": api_keys["ECOS_API_KEY"],
            "환율": api_keys["EXIM_API_KEY"],
            "지배구조": api_keys["DART_API_KEY"],
        }

        active_count = sum(1 for v in sources.values() if v)

        return ok_response(
            {
                "server": "Stock Data Kit",
                "total_functions": len(_FUNCTIONS),
                "normalized_routes": len(_NORMALIZED_ROUTES),
                "db_enabled": _HAS_PG,
                "api_keys": api_keys,
                "sources": sources,
                "active_sources": f"{active_count}/{len(sources)}",
            },
            source="datakit",
        )



if __name__ == "__main__":
    from fastmcp import FastMCP
    mcp = FastMCP("Stock Data Kit", port=8200)
    register_tools(mcp)

    logger.info("Stock Data Kit MCP Server starting...")
    logger.info(f"   Tools: datakit_call, datakit_list_functions, datakit_get_env_info")
    logger.info(f"   Functions: {len(_FUNCTIONS)} (5 sources)")
    logger.info(f"   Normalized Routes: {len(_NORMALIZED_ROUTES)} -> shared_ohlcv, shared_supply, shared_dart_disclosures, shared_macro")
    logger.info(f"   PyKRX: {'OK' if _HAS_PYKRX else 'MISSING'}")
    logger.info(f"   DART_API_KEY: {'SET' if os.getenv('DART_API_KEY') else 'NOT SET'}")
    logger.info(f"   ECOS_API_KEY: {'SET' if os.getenv('ECOS_API_KEY') else 'NOT SET'}")
    logger.info(f"   EXIM_API_KEY: {'SET' if os.getenv('EXIM_API_KEY') else 'NOT SET'}")
    logger.info(f"   Port: 8200")

    mcp.run(transport="sse", host="0.0.0.0", port=8200)
