#!/usr/bin/env python3
"""Kiwoom WebSocket client — 조건검색 전용 (ka10171~ka10174)

WebSocket-only APIs (REST 호출 시 오류 — HTTP로 라우팅 불가):
  ka10171  CNSRLST    조건검색식 목록 조회
  ka10172  CNSRREQ    조건검색식 종목조회   (search_type=0, 일반조회)
  ka10173  CNSRREQ    실시간 조건검색 등록  (search_type=1)
  ka10174  CNSRCLR    실시간 조건검색 해제  ← trnm="CNSRCLR" (CNSRREQ 아님!)

WebSocket endpoint (공식 문서 기준):
  Live : wss://api.kiwoom.com:10000/api/dostk/websocket
  Mock : wss://mockapi.kiwoom.com:10000/api/dostk/websocket

Connection flow (API 호출당 1 WebSocket 세션):
  1. CONNECT  HTTP 헤더: api-id, authorization (Bearer <token>)
             ※ LOGIN 메시지 없음 — 헤더로 인증 처리
  2. → Send  JSON 요청 바디 (trnm 포함)
  3. ← Recv  응답 (cont_yn="N" 또는 타임아웃이면 종료)
  4. DISCONNECT

ka10172 요청 파라미터:
  trnm="CNSRREQ", seq, search_type="0", stex_tp="K", cont_yn="N", next_key=""

ka10172 응답 data 필드 (숫자 키):
  "9001" = 종목코드(A+6자리), "302" = 종목명, "10" = 현재가
  "25" = 전일대비부호, "11" = 전일대비, "12" = 등락률
  "13" = 거래량, "16" = 시가, "17" = 고가, "18" = 저가

ka10173 초기 응답 data 필드:
  [{"jmcode": "A005930"}, ...] ← ka10172와 다름

의존성:
  websockets>=12.0
  pip install "openclaw-stock-kit[kiwoom]"  또는  pip install "websockets>=12"
"""
from __future__ import annotations

import asyncio
import json
import sys
from pathlib import Path
from typing import Any, Dict, List

sys.path.insert(0, str(Path(__file__).parent))
import kiwoom_rest_client as krc

try:
    import websockets
    _HAS_WS = True
except ImportError:
    _HAS_WS = False

_WS_LIVE = "wss://api.kiwoom.com:10000/api/dostk/websocket"
_WS_MOCK = "wss://mockapi.kiwoom.com:10000/api/dostk/websocket"
_TIMEOUT = 15.0


class KiwoomWsError(RuntimeError):
    pass


def _ws_url() -> str:
    return _WS_MOCK if krc.pick_env() == "mock" else _WS_LIVE


def _check_ws() -> None:
    if not _HAS_WS:
        raise KiwoomWsError(
            "websockets 패키지 필요. "
            'pip install "openclaw-stock-kit[kiwoom]"  또는  pip install "websockets>=12"'
        )


async def _ws_session(
    api_id: str,
    request: Dict[str, Any],
    *,
    paginate: bool = False,
) -> List[Dict[str, Any]]:
    """WebSocket 세션: CONNECT(헤더 인증) → 요청 → 응답 수집 → DISCONNECT.

    Args:
        api_id: HTTP 헤더에 담을 TR 코드 (ka10171 ~ ka10174)
        request: 요청 JSON 바디
        paginate: True면 cont_yn="Y" 시 연속 페이지 자동 조회 (ka10172 전용)
    """
    _check_ws()
    token_obj = krc.fetch_token(force=False)
    token = str(token_obj["token"])
    url = _ws_url()

    auth_headers = {
        "api-id": api_id,
        "authorization": f"Bearer {token}",
    }

    results: List[Dict[str, Any]] = []
    async with websockets.connect(url, additional_headers=auth_headers, open_timeout=_TIMEOUT) as ws:
        await ws.send(json.dumps(request, ensure_ascii=False))

        current_req = dict(request)
        try:
            while True:
                raw = await asyncio.wait_for(ws.recv(), timeout=_TIMEOUT)
                msg = json.loads(raw)
                results.append(msg)

                if msg.get("return_code", 0) != 0:
                    break

                # 페이지 연속 조회 (ka10172 only)
                if paginate and msg.get("cont_yn") == "Y":
                    current_req["cont_yn"] = "Y"
                    current_req["next_key"] = msg.get("next_key", "")
                    await ws.send(json.dumps(current_req, ensure_ascii=False))
                    continue

                break  # cont_yn != "Y" 또는 paginate=False → 종료
        except asyncio.TimeoutError:
            pass  # 타임아웃 = 응답 끝 (정상)

    return results


# ── 공개 async API ──────────────────────────────────────────

async def get_condition_list() -> Dict[str, Any]:
    """ka10171: 조건검색식 목록 조회 (CNSRLST).

    Returns:
        {
            "conditions": [{"seq": "0", "name": "조건명"}, ...],
            "count": N,
            "return_code": 0,
            "return_msg": ""
        }
    """
    msgs = await _ws_session("ka10171", {"trnm": "CNSRLST"})
    if not msgs:
        raise KiwoomWsError("CNSRLST 응답 없음")
    msg = msgs[0]
    if msg.get("return_code", 0) != 0:
        raise KiwoomWsError(
            f"CNSRLST 오류 (code={msg.get('return_code')}): {msg.get('return_msg')}"
        )
    # 응답 data 형식: [["0", "조건명1"], ["1", "조건명2"], ...]
    raw_data = msg.get("data") or []
    conditions = [
        {"seq": str(item[0]), "name": str(item[1])}
        for item in raw_data
        if isinstance(item, (list, tuple)) and len(item) >= 2
    ]
    return {
        "conditions": conditions,
        "count": len(conditions),
        "return_code": 0,
        "return_msg": msg.get("return_msg", ""),
    }


async def search_condition(
    seq: str,
    search_type: str = "0",
    stex_tp: str = "K",
) -> Dict[str, Any]:
    """ka10172/10173: CNSRREQ — 조건검색식 종목조회 또는 실시간 등록.

    Args:
        seq: 조건검색식 순번 (get_condition_list()로 조회)
        search_type: "0" = 일반조회(ka10172), "1" = 실시간등록(ka10173)
        stex_tp: 거래소 구분 "K" = KRX (기본값, 현재 유일한 유효값)

    Returns:
        {
            "seq": "1",
            "search_type": "0",
            "stk_list": [
                {
                    "stk_cd": "A005930",   # 종목코드
                    "stk_nm": "삼성전자",  # 종목명
                    "price":  "75000",     # 현재가
                    "sign":   "5",         # 전일대비부호
                    "change": "-100",      # 전일대비
                    "chg_rate": "-0.13",   # 등락률
                    "volume": "10386116",  # 거래량
                    "open":   "75100",     # 시가
                    "high":   "75600",     # 고가
                    "low":    "74700",     # 저가
                }, ...
            ],
            "stk_cnt": N,
            "return_code": 0
        }
    """
    api_id = "ka10172" if search_type == "0" else "ka10173"
    request: Dict[str, Any] = {
        "trnm": "CNSRREQ",
        "seq": str(seq),
        "search_type": str(search_type),
        "stex_tp": str(stex_tp),
    }
    # 일반조회(ka10172)만 pagination 필드 포함
    if search_type == "0":
        request["cont_yn"] = "N"
        request["next_key"] = ""

    msgs = await _ws_session(api_id, request, paginate=(search_type == "0"))
    if not msgs:
        raise KiwoomWsError("CNSRREQ 응답 없음")

    stk_list: List[Dict[str, Any]] = []
    last_msg: Dict[str, Any] = {}

    for m in msgs:
        if m.get("return_code", 0) != 0:
            raise KiwoomWsError(
                f"CNSRREQ 오류 (code={m.get('return_code')}): {m.get('return_msg')}"
            )
        items = m.get("data") or []
        if not isinstance(items, list):
            last_msg = m
            continue
        for item in items:
            if not isinstance(item, dict):
                continue
            if "jmcode" in item:
                # ka10173 실시간 초기 응답 형식: {"jmcode": "A005930"}
                stk_list.append({
                    "stk_cd": item["jmcode"],
                    "stk_nm": "", "price": "", "sign": "",
                    "change": "", "chg_rate": "", "volume": "",
                    "open": "", "high": "", "low": "",
                })
            else:
                # ka10172 일반조회 응답 형식: 숫자 키 필드
                stk_list.append({
                    "stk_cd":   item.get("9001", ""),   # 종목코드
                    "stk_nm":   item.get("302",  ""),   # 종목명
                    "price":    item.get("10",   ""),   # 현재가
                    "sign":     item.get("25",   ""),   # 전일대비부호
                    "change":   item.get("11",   ""),   # 전일대비
                    "chg_rate": item.get("12",   ""),   # 등락률
                    "volume":   item.get("13",   ""),   # 거래량
                    "open":     item.get("16",   ""),   # 시가
                    "high":     item.get("17",   ""),   # 고가
                    "low":      item.get("18",   ""),   # 저가
                })
        last_msg = m

    return {
        "seq": seq,
        "search_type": search_type,
        "stk_list": stk_list,
        "stk_cnt": len(stk_list),
        "return_code": last_msg.get("return_code", 0),
        "return_msg": last_msg.get("return_msg", ""),
    }


async def stop_condition(seq: str) -> Dict[str, Any]:
    """ka10174: 실시간 조건검색 해제 (CNSRCLR).

    ※ trnm은 "CNSRCLR" (CNSRREQ search_type=2 아님!)

    Args:
        seq: 해제할 조건검색식 순번

    Returns:
        {"seq": "1", "return_code": 0, "return_msg": ""}
    """
    msgs = await _ws_session("ka10174", {"trnm": "CNSRCLR", "seq": str(seq)})
    if not msgs:
        raise KiwoomWsError("CNSRCLR 응답 없음")
    msg = msgs[0]
    if msg.get("return_code", 0) != 0:
        raise KiwoomWsError(
            f"CNSRCLR 오류 (code={msg.get('return_code')}): {msg.get('return_msg')}"
        )
    return {
        "seq": msg.get("seq", seq),
        "return_code": 0,
        "return_msg": msg.get("return_msg", ""),
    }
