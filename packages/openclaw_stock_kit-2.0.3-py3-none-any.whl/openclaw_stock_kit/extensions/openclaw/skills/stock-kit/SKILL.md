---
name: stock-kit
description: |
  Korean stock market data & trading toolkit.
  Call tools directly via CLI — no MCP protocol needed.

  Triggers: 주식, 현재가, 시세, 매매, 주문, 잔고, 뉴스, 공시, 차트,
  종목, 코스피, 코스닥, 환율, 금리, 시가총액, 급등주, 호가, 배당,
  stock, price, trade, order, balance, news, disclosure, chart, KOSPI

  Do NOT use for: general knowledge, coding, non-stock questions, cryptocurrency
argument-hint: "[종목명|질문]"
user-invocable: true
---

# StockClaw Kit — CLI 직접 호출 가이드

## 핵심: exec 도구로 바로 호출

MCP 프로토콜 불필요. exec 도구(bash)로 직접 호출한다.

```bash
/root/.local/bin/openclaw-stock-kit call <도구명> '<JSON 파라미터>' 2>/dev/null
```

중요: `2>/dev/null`을 항상 붙여서 로딩 로그를 숨긴다.

---

## 빠른 시작

```bash
# 종목 검색 (무료, 키 불필요)
openclaw-stock-kit call datakit_call '{"function":"search_stock","params_json":"{\"keyword\":\"삼성전자\"}"}' 2>/dev/null

# 과거 주가 (무료)
openclaw-stock-kit call datakit_call '{"function":"get_price","params_json":"{\"ticker\":\"005930\",\"start\":\"20260101\",\"end\":\"20260219\"}"}' 2>/dev/null

# 뉴스 검색
openclaw-stock-kit call news_search_stock '{"stock_name":"삼성전자","days":7}' 2>/dev/null

# 키움 실시간 현재가 (키움 인증 필요)
openclaw-stock-kit call kiwoom_call_api '{"tr_id":"ka10001","inputs":{"종목코드":"005930"}}' 2>/dev/null

# 전체 상태 확인
openclaw-stock-kit call gateway_status 2>/dev/null

# 도구 목록
openclaw-stock-kit call list 2>/dev/null
```

---

## 의사결정 트리 — 서브 스킬 라우팅

사용자 의도를 파악하여 해당 서브 스킬 파일을 **Read 도구**로 읽고, 그 안의 상세 가이드를 따른다.

| 사용자 의도 | 서브 스킬 파일 | CLI 도구 |
|------------|--------------|---------|
| 종목검색, 과거 주가, 시총, 수급, 지수 | `{baseDir}/skills/datakit-pykrx.md` | `datakit_call` |
| DART 공시, 기업개황, 최대주주, 임원 | `{baseDir}/skills/datakit-dart.md` | `datakit_call` |
| 기준금리, CPI, GDP, 실업률, 환율 | `{baseDir}/skills/datakit-macro.md` | `datakit_call` |
| 뉴스 검색, 종목별 뉴스 | `{baseDir}/skills/news-naver.md` | `news_search` / `news_search_stock` |
| 텔레그램 채널, 메시지, 인증 | `{baseDir}/skills/news-telegram.md` | `telegram_*` |
| 키움 실시간 시세, 호가, 차트 | `{baseDir}/skills/kiwoom-market.md` | `kiwoom_call_api` |
| 키움 매수, 매도, 잔고, 예수금 | `{baseDir}/skills/kiwoom-trading.md` | `kiwoom_call_api` |
| 키움 외국인, 기관, 순위, 업종, 테마 | `{baseDir}/skills/kiwoom-analysis.md` | `kiwoom_call_api` |
| 키움 ELW, ETF, 대차 | `{baseDir}/skills/kiwoom-specialty.md` | `kiwoom_call_api` |
| 키움 조건검색 | `{baseDir}/skills/kiwoom-condition.md` | `kiwoom_condition_*` |
| 한투 국내주식 (시세, 주문, 잔고) | `{baseDir}/skills/kis-domestic.md` | `kis_domestic_stock` |
| 한투 해외주식 (미국, 중국, 일본 등) | `{baseDir}/skills/kis-overseas.md` | `kis_overseas_stock` |
| 한투 선물옵션, 채권, ETF/ETN, ELW | `{baseDir}/skills/kis-derivatives.md` | `kis_*` |
| 브리핑, 백테스트, 강좌, 프리미엄 | `{baseDir}/skills/premium.md` | `premium_call` |

---

## 모듈 커버리지

| 모듈 | 내부 API 수 | 인증 필요 | 비고 |
|------|-----------|----------|------|
| DataKit (PyKRX) | 6개 함수 | 불필요 (무료) | 과거 데이터 |
| DataKit (DART) | 5개 함수 | DART_API_KEY | 공시+지배구조 |
| DataKit (ECOS+환율) | 2개 함수 | ECOS_API_KEY, EXIM_API_KEY | 거시지표 |
| 뉴스 (Naver) | 2개 도구 | NAVER_CLIENT_ID/SECRET | 멀티키 지원 |
| 텔레그램 | 3개 도구 | TELEGRAM_API_ID/HASH | 실시간 채널 |
| 키움 REST | 185개 API | KIWOOM_APP_KEY/SECRET | 실시간+매매 |
| 키움 WS | 4개 API | 키움 인증 | 조건검색 |
| 한투 (KIS) | 166개 API | KIS_APP_KEY/SECRET | 국내+해외 |
| 프리미엄 | 6개 함수 | 라이선스 키 | 브리핑/백테스트 |

---

## 에러 대처

- "Tool not found" → `call list`로 정확한 도구명 확인
- "Unexpected keyword argument" → 해당 서브 스킬에서 파라미터 확인
- "KIWOOM_APP_KEY not set" → 키움 API 키 미설정 (Settings 페이지에서 입력)
- "KIS 인증 필요" → 한투 API 키/계좌 미설정
- 종목코드 모를 때 → `datakit_call` + `search_stock` 먼저 호출
- "Connection refused" → call 모드는 SSE 서버 불필요 (독립 실행)
