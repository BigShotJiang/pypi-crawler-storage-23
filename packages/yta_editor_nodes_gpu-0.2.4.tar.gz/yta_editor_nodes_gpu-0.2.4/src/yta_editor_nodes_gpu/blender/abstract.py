from yta_video_opengl.opengl_nodes import _BaseAndOverlayTexturesOpenGLNode


class _NodeBlenderGPU(_BaseAndOverlayTexturesOpenGLNode):
    """
    Just a class to be able to identify the children
    as blenders.
    """

    mandatory_inputs = ['base_input', 'overlay_input']
    optional_inputs = []

    pass