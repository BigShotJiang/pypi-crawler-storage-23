"""
CLI module - Interface de linha de comando

Interface premium usando Rich e Typer.
"""

from squidy.cli.app import main

__all__ = ["main"]
