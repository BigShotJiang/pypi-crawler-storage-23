"""
UI module - Componentes visuais da CLI
"""

from squidy.cli.ui.theme import SquidyTheme

__all__ = ["SquidyTheme"]
