from logging import Logger
from pathlib import Path
from typing import Any

from pypdf import DocumentInformation, PdfReader, PdfWriter

from useful_tools.common.config.base_config import convert_from_dt_type_to_str_type, get_log_extra


class EditPdf:
    """
    Edit the PDF files.
    """

    def __init__(self, logger: Logger):
        """Constructor"""
        self.logger: Logger = logger
        # ファイルパス
        self.file_path: str = ""
        self.reader: PdfReader | None = None
        # ページ数
        self.num_of_pages: int = 0
        self.writer: PdfWriter | None = None
        self.metadata_of_reader: DocumentInformation | None = None
        self.metadata_of_writer: dict = {}
        # ファイルの読み込みが初回かどうか判定する
        self.first_read: bool = True
        # 暗号化されているかどうか
        self.encrypted: bool = False
        # 暗号化のパスワード
        self.password: str = ""
        # pdfファイルの拡張子
        self.EXTENSION: str = ".pdf"
        # メタデータの書き込み用の辞書
        self.fields: dict = {
            "title": "/Title",  # タイトル
            "author": "/Author",  # 作成者
            "subject": "/Subject",  # サブタイトル
            "creator": "/Creator",  # アプリケーション
            "producer": "/Producer",  # PDF変換
            "keywords": "/Keywords",  # キーワード
            "creation_date": "/CreationDate",  # 作成日
            "modification_date": "/ModDate",  # 更新日
        }
        # メタデータの書き込み用の作成日
        self.creation_date: DocumentInformation | None = None
        # メタデータの書き込み用の更新日
        self.modification_date: DocumentInformation | None = None

    def append_log_for_constructor(self) -> bool:
        """Append log for the constructor."""
        result: bool = False
        try:
            self.logger.info(f"{self.__class__.__qualname__}: {self.__class__.__doc__}")
        except Exception:
            raise
        else:
            result = True
        finally:
            pass
        return result

    def read_file(self, file_path: str = "") -> bool:
        """Read the PDF file."""
        result: bool = False
        try:
            if file_path != "":
                self.file_path = file_path
            self.logger.info(f"User-specified file path: {self.file_path}")
            self.reader = PdfReader(stream=self.file_path)
            if self.first_read and self.reader.is_encrypted or self.encrypted:
                raise Exception("User-specified file is encrypted.")
            self.metadata_of_reader = self.reader.metadata
            self.num_of_pages = len(self.reader.pages)
            if self.metadata_of_reader is not None:
                self.creation_date = self.metadata_of_reader.get("/CreationDate")
        except Exception:
            raise
        else:
            result = True
            self.first_read = False
            self.logger.info("***Succeeded***", extra=get_log_extra(func_flag=True))
        finally:
            pass
        return result

    def encrypt_file(self, password: str) -> bool:
        """Encrypt the PDF file."""
        result: bool = False
        try:
            self.reader = PdfReader(stream=self.file_path)
            if self.reader is None:
                raise Exception("Read a PDF file.")
            self.logger.info(f"User-specified file path: {self.file_path}")
            self.logger.info(f"Password: {password}")
            self.writer = PdfWriter(clone_from=self.reader)
            self.writer.encrypt(user_password=password, algorithm="AES-256")
            with open(self.file_path, "wb") as f:
                self.writer.write(stream=f)
        except Exception:
            raise
        else:
            result = True
            self.encrypted = True
            self.logger.info("***Succeeded***", extra=get_log_extra(func_flag=True))
        finally:
            pass
        return result

    def decrypt_file(self, password: str) -> bool:
        """Decrypt the PDF file."""
        result: bool = False
        try:
            self.reader = PdfReader(stream=self.file_path)
            if self.reader is None:
                raise Exception("Read a PDF file.")
            self.logger.info(f"User-specified file path: {self.file_path}")
            self.logger.info(f"Password: {password}")
            self.reader.decrypt(password=password)
            self.writer = PdfWriter(clone_from=self.reader)
            with open(self.file_path, "wb") as f:
                self.writer.write(stream=f)
        except Exception:
            raise
        else:
            result = True
            self.encrypted = False
            self.logger.info("***Succeeded***", extra=get_log_extra(func_flag=True))
        finally:
            pass
        return result

    def get_metadata(self) -> bool:
        """Get the metadata of the PDF file."""
        result: bool = False
        try:
            if self.reader is None:
                raise Exception("Read a PDF file.")
            self.logger.info(f"User-specified file path: {self.file_path}")
            for key in self.fields.keys():
                value: Any = getattr(self.metadata_of_reader, key, None)
                self.logger.info(f"{key.capitalize().replace("_", " ")}: {value or None}")
        except Exception:
            raise
        else:
            result = True
            self.logger.info("***Succeeded***", extra=get_log_extra(func_flag=True))
        finally:
            pass
        return result

    def write_metadata(self, metadata_of_writer: dict) -> bool:
        """Write the metadata to the PDF file."""
        result: bool = False
        try:
            if self.reader is None:
                raise Exception("Read a PDF file.")
            self.logger.info(f"User-specified file path: {self.file_path}")
            self.writer = PdfWriter()
            for page in self.reader.pages:
                self.writer.add_page(page=page)
            self.writer.add_metadata(infos=metadata_of_writer)
            with open(self.file_path, "wb") as f:
                self.writer.write(stream=f)
        except Exception:
            raise
        else:
            result = True
            self.logger.info("***Succeeded***", extra=get_log_extra(func_flag=True))
        finally:
            pass
        return result

    def merge_files(self, pdfs: list) -> bool:
        """Merge multiple PDF files."""
        result: bool = False
        try:
            # ファイルパスを退避させる
            file_path_of_tmp: str = self.file_path
            # 暗号化されたファイルのリスト
            is_encrypted_lst: list = []
            file_p: Path = (
                Path(pdfs[0]).parent / f"merged_file_{convert_from_dt_type_to_str_type("for_file_name")}.pdf"
            )
            file_s: str = str(file_p)
            self.writer = PdfWriter()
            for pdf in pdfs:
                try:
                    self.read_file(pdf)
                    self.writer.append(fileobj=self.file_path)
                except Exception:
                    is_encrypted_lst.append(pdf)
            if is_encrypted_lst:
                raise Exception("There are encrypted files among the specified files.")
            with open(file_s, "wb") as f:
                self.writer.write(stream=f)
            # マージされたファイルを読み込む
            self.read_file(file_s)
            # マージされたファイルにメタデータの作成日を付与する
            self.add_creation_date_in_metadata()
            # 退避させたファイルパスを読み込む
            self.read_file(file_path_of_tmp)
        except Exception:
            if is_encrypted_lst:
                self.logger.error("The list of encrypted files: ")
                self.logger.error("\n".join(is_encrypted_lst))
            raise
        else:
            result = True
            self.logger.info("from: ")
            self.logger.info("\n".join(pdfs))
            self.logger.info("to: ")
            self.logger.info(file_s)
            self.logger.info("***Succeeded***", extra=get_log_extra(func_flag=True))
        finally:
            pass
        return result

    def extract_pages(self, start_page: int, end_page: int) -> bool:
        """Extract the specified range of pages from the PDF file."""
        result: bool = False
        try:
            if self.reader is None:
                raise Exception("Read a PDF file.")
            # ファイルパスを退避させる
            file_path_of_tmp: str = self.file_path
            b: int = start_page - 1
            e: int = end_page - 1
            self.writer = PdfWriter()
            for i in range(self.num_of_pages):
                if b <= i and i <= e:
                    self.writer.add_page(page=self.reader.pages[i])
            file_p: Path = (
                Path(self.file_path).parent
                / f"edited_file_{convert_from_dt_type_to_str_type("for_file_name")}.pdf"
            )
            file_s: str = str(file_p)
            with open(file_s, "wb") as f:
                self.writer.write(stream=f)
            # マージされたファイルを読み込む
            self.read_file(file_s)
            # ページを抽出したファイルにメタデータの作成日を付与する
            self.add_creation_date_in_metadata()
            # 退避させたファイルパスを読み込む
            self.read_file(file_path_of_tmp)
        except Exception:
            raise
        else:
            result = True
            self.logger.info("from: ")
            self.logger.info(self.file_path)
            self.logger.info(f"start page: {start_page}")
            self.logger.info(f"end page: {end_page}")
            self.logger.info("to: ")
            self.logger.info(file_s)
            self.logger.info("***Succeeded***", extra=get_log_extra(func_flag=True))
        finally:
            pass
        return result

    def delete_pages(self, start_page: int, end_page: int) -> bool:
        """Delete the specified range of pages from the PDF file."""
        result: bool = False
        try:
            if self.reader is None:
                raise Exception("Read a PDF file.")
            # ファイルパスを退避させる
            file_path_of_tmp: str = self.file_path
            b: int = start_page - 1
            e: int = end_page - 1
            self.writer = PdfWriter()
            for i in range(self.num_of_pages):
                if b <= i and i <= e:
                    continue
                self.writer.add_page(page=self.reader.pages[i])
            file_p: Path = (
                Path(self.file_path).parent
                / f"edited_file_{convert_from_dt_type_to_str_type("for_file_name")}.pdf"
            )
            file_s: str = str(file_p)
            with open(file_s, "wb") as f:
                self.writer.write(stream=f)
            # マージされたファイルを読み込む
            self.read_file(file_s)
            # ページを削除したファイルにメタデータの作成日を付与する
            self.add_creation_date_in_metadata()
            # 退避させたファイルパスを読み込む
            self.read_file(file_path_of_tmp)
        except Exception:
            raise
        else:
            result = True
            self.logger.info("from: ")
            self.logger.info(self.file_path)
            self.logger.info(f"start page: {start_page}")
            self.logger.info(f"end page: {end_page}")
            self.logger.info("to: ")
            self.logger.info(file_s)
            self.logger.info("***Succeeded***", extra=get_log_extra(func_flag=True))
        finally:
            pass
        return result

    def extract_text(self, start_page: int, end_page: int) -> bool:
        """Extract text from the specified range of pages in the PDF file."""
        result: bool = False
        try:
            if self.reader is None:
                raise Exception("Read a PDF file.")
            self.logger.info(f"User-specified file path: {self.file_path}")
            lst_of_text_in_pages: list = []
            b: int = start_page - 1
            e: int = end_page - 1
            for i in range(self.num_of_pages):
                if b <= i and i <= e:
                    lst_of_text_in_pages.append(f"{i + 1} page: {self.reader.pages[i].extract_text()}")
            self.logger.info("\n".join(lst_of_text_in_pages))
        except Exception:
            raise
        else:
            result = True
            self.logger.info(f"start page: {start_page}")
            self.logger.info(f"end page: {end_page}")
            self.logger.info("***Succeeded***", extra=get_log_extra(func_flag=True))
        finally:
            pass
        return result

    def rotate_page_clockwise(self, page: int, degrees: int) -> bool:
        """Rotate the specified page of the PDF file clockwise."""
        result: bool = False
        try:
            if self.reader is None:
                raise Exception("Read a PDF file.")
            self.logger.info(f"User-specified file path: {self.file_path}")
            self.writer = PdfWriter()
            for p in range(self.num_of_pages):
                self.writer.add_page(page=self.reader.pages[p])
                if p == page - 1:
                    self.writer.pages[p].rotate(angle=degrees)
            with open(self.file_path, "wb") as f:
                self.writer.write(stream=f)
        except Exception:
            raise
        else:
            result = True
            self.logger.info(f"page: {page}")
            self.logger.info(f"degrees: {degrees}")
            self.logger.info("***Succeeded***", extra=get_log_extra(func_flag=True))
        finally:
            pass
        return result

    def add_creation_date_in_metadata(self) -> bool:
        """Add creation date in the metadata of the PDF file"""
        result: bool = False
        try:
            self.logger.info(f"User-specified file path: {self.file_path}")
            self.metadata_of_writer = {}
            for key, value in self.fields.items():
                if key == "creation_date":
                    self.metadata_of_writer[value] = convert_from_dt_type_to_str_type(
                        "for_metadata_of_pdf_file"
                    )
                    break
            self.write_metadata(self.metadata_of_writer)
        except Exception:
            raise
        else:
            result = True
            self.logger.info("***Succeeded***", extra=get_log_extra(func_flag=True))
        finally:
            pass
        return result
