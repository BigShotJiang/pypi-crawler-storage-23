import shutil
import subprocess
from logging import Logger
from pathlib import Path

from useful_tools.common.config.base_config import get_log_extra


class ConvertLibreToPDF:
    """
    Convert Office files to PDF files.
    LibreOffice required.
    """

    def __init__(self, logger: Logger):
        """Constructor"""
        self.command: str = "soffice"
        # コマンドのパスが通っているか確認する
        if not shutil.which(self.command):
            raise ImportError(
                "Install LibreOffice (https://www.libreoffice.org/) "
                f"and add the {self.command} command to your path."
            )
        self.logger: Logger = logger
        # 拡張子の辞書
        self.file_types: dict = {
            "Excel": [".xls", ".xlsx"],
            "Word": [".doc", ".docx"],
            "Powerpoint": [".ppt", ".pptx"],
            "Calc": [".ods"],
            "Writer": [".odt"],
            "Impress": [".odp"],
        }
        # 拡張子のリスト
        self.valid_exts: list = sum(self.file_types.values(), [])
        # 変換元のフォルダパス
        self.src_folder_path: str = ""
        # 変換先のフォルダパス
        self.dst_folder_path: str = ""
        # 変換元のフォルダのフィルター後のファイルのリスト
        self.filtered_lst_of_f: list = []
        # 変換元のフォルダのファイルの数
        self.number_of_f: int = 0
        # ファイルリストのポインタ
        self.p: int = 0
        # 処理中の変換元のファイルパス
        self.current_src_file_path: str = ""
        # 処理したファイルの数
        self.count: int = 0
        # 処理が成功したファイルの数
        self.success: int = 0
        # 全てのファイルを変換できたかどうか
        self.complete: bool = False

    def append_log_for_constructor(self) -> bool:
        """Append log for the constructor."""
        result: bool = False
        try:
            self.logger.info(f"{self.__class__.__qualname__}: {self.__class__.__doc__}")
            self.logger.info(
                "Below is a list of file extensions that can be specified as the source for conversion."
            )
            exts: str = "\n"
            for key, info in self.file_types.items():
                values: str = ""
                for value in info:
                    values += f"{value}, "
                values = values.rstrip(", ")
                exts += f"{key}: {values}\n"
            self.logger.info(exts)
        except Exception:
            raise
        else:
            result = True
        finally:
            pass
        return result

    def create_file_lst(self) -> bool:
        """Create a file list in the source folder."""
        result: bool = False
        # 初期化する
        self.p = 0
        self.count = 0
        self.success = 0
        self.complete = False
        try:
            # 指定のフォルダにあるファイルパスのリストから指定の拡張子で抽出する
            self.filtered_lst_of_f = [
                str(f) for f in Path(self.src_folder_path).glob("*") if f.suffix.lower() in self.valid_exts
            ]
            self.number_of_f = len(self.filtered_lst_of_f)
            if not self.number_of_f:
                raise Exception("There is no source file to convert.")
            self.current_src_file_path = self.filtered_lst_of_f[self.p]
        except Exception:
            self.logger.error("***Failed***", extra=get_log_extra(func_flag=True))
            raise
        else:
            result = True
            self.logger.info("***Succeeded***", extra=get_log_extra(func_flag=True))
            self.logger.info(f"Number of files: {self.number_of_f}")
            self.logger.info(f"Destination folder: {self.dst_folder_path}")
        finally:
            pass
        return result

    def move_to_previous_file(self) -> bool:
        """Move the target file to the previous file."""
        result: bool = False
        try:
            if not self.p:
                self.p = self.number_of_f - 1
            else:
                self.p -= 1
            self.current_src_file_path = self.filtered_lst_of_f[self.p]
        except Exception:
            raise
        else:
            result = True
        finally:
            pass
        return result

    def move_to_next_file(self) -> bool:
        """Move the target file to the next file."""
        result: bool = False
        try:
            if self.p == self.number_of_f - 1:
                self.p = 0
            else:
                self.p += 1
            self.current_src_file_path = self.filtered_lst_of_f[self.p]
        except Exception:
            raise
        else:
            result = True
        finally:
            pass
        return result

    def convert_file(self) -> bool:
        """Convert the file to a PDF file."""
        result: bool = False
        try:
            self.logger.info(
                f"* [{self.count + 1} / {self.number_of_f}]", extra=get_log_extra(func_flag=True)
            )
            self.logger.info(f"{self.current_src_file_path} -> PDF")
            convert_obj: subprocess.CompletedProcess = subprocess.run(
                args=[
                    self.command,
                    "--headless",
                    "--convert-to",
                    "pdf",
                    "--outdir",
                    self.dst_folder_path,
                    self.current_src_file_path,
                ],
                capture_output=True,
                text=True,
            )
            result = not convert_obj.returncode
            self.count += 1
            if result:
                self.success += 1
                self.logger.info("***Succeeded***", extra=get_log_extra(func_flag=True))
            else:
                self.logger.error("***Failed***", extra=get_log_extra(func_flag=True))
            if self.count == self.number_of_f:
                if self.success == self.number_of_f:
                    self.complete = True
                    self.logger.info("***Completed***", extra=get_log_extra(func_flag=True))
                else:
                    self.logger.error("Some files failed to convert.")
        except Exception:
            raise
        else:
            pass
        finally:
            pass
        return result
