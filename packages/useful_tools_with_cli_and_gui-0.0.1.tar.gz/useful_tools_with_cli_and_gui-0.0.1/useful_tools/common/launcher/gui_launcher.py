import sys
from dataclasses import dataclass
from functools import partial
from typing import Any, Callable

from PySide6.QtWidgets import (
    QApplication,
    QLabel,
    QMainWindow,
    QMessageBox,
    QPushButton,
    QScrollArea,
    QVBoxLayout,
    QWidget,
)

from useful_tools.common.config.gui_config import (
    ConfigureShortcutsWithQtOnWsl,
    wrap_closeevent_with_gui,
    wrap_notifying_result_with_gui,
    wrap_showevent_with_gui,
    wrap_start_up_with_gui,
)
from useful_tools.convert_to_md.ctm_class import ConvertToMd
from useful_tools.edit_pdf.ep_class import EditPdf
from useful_tools.get_file_list.gfl_class import GetFileList
from useful_tools.get_japan_government_statistics.gjgs_class import GetJapanGovernmentStatistics


@dataclass
class LauncherItem:
    title: str
    callback: Callable
    description: str | None


class MainApp_Of_Gui_Launcher(QMainWindow):
    def __init__(self, app: QApplication):
        """Constructor"""
        super().__init__()
        self.app: QApplication = app
        self.sc_init_flag: bool = False
        self.obj_of_sc: ConfigureShortcutsWithQtOnWsl = ConfigureShortcutsWithQtOnWsl(self.app)
        self.child_windows: list = []
        self.setup_ui()

    @wrap_showevent_with_gui
    def showEvent(self, event) -> None:
        """Show."""
        super().showEvent(event)

    @wrap_closeevent_with_gui
    def closeEvent(self, event) -> None:
        """Quit."""
        super().closeEvent(event)

    def display_info(self, msg: str) -> None:
        """Display info."""
        QMessageBox.information(self, "Information", msg)

    def launch(self, tool: str) -> None:
        """Call the user-specified tool."""
        match tool:
            case "cltp":
                from useful_tools.convert_libre_to_pdf.cltp_with_gui import create_window
            case "cotp":
                from useful_tools.convert_office_to_pdf.cotp_with_gui import create_window
            case "ctm":
                from useful_tools.convert_to_md.ctm_with_gui import create_window
            case "ep":
                from useful_tools.edit_pdf.ep_with_gui import create_window
            case "gfl":
                from useful_tools.get_file_list.gfl_with_gui import create_window
            case "gjgs":
                from useful_tools.get_japan_government_statistics.gjgs_with_gui import create_window
            case _:
                raise Exception("That tool is invalid.")
        window: Any = create_window(self.app)
        window.showMaximized()
        self.child_windows.append(window)

    @wrap_notifying_result_with_gui
    def setup_ui(self) -> None:
        """Configure the User Interface."""
        from useful_tools.convert_libre_to_pdf.cltp_class import ConvertLibreToPDF
        from useful_tools.convert_office_to_pdf.cotp_class import ConvertOfficeToPDF

        # タイトル
        self.setWindowTitle("Useful Tools - GUI Launcher - ")
        central: QWidget = QWidget()
        self.setCentralWidget(central)
        base_layout: QVBoxLayout = QVBoxLayout(central)
        # 主要
        main_scroll_area: QScrollArea = QScrollArea()
        main_scroll_area.setWidgetResizable(True)
        base_layout.addWidget(main_scroll_area)
        main_container: QWidget = QWidget()
        main_container_layout: QVBoxLayout = QVBoxLayout(main_container)
        main_scroll_area.setWidget(main_container)
        main_container_layout.addWidget(QLabel("Select from the list below."))
        # 選択
        launcher_items: tuple = (
            LauncherItem(
                title="source/convert_libre_to_pdf",
                callback=partial(self.launch, "cltp"),
                description=ConvertLibreToPDF.__doc__,
            ),
            LauncherItem(
                title="source/convert_office_to_pdf",
                callback=partial(self.launch, "cotp"),
                description=ConvertOfficeToPDF.__doc__,
            ),
            LauncherItem(
                title="source/convert_to_md",
                callback=partial(self.launch, "ctm"),
                description=ConvertToMd.__doc__,
            ),
            LauncherItem(
                title="source/edit_pdf",
                callback=partial(self.launch, "ep"),
                description=EditPdf.__doc__,
            ),
            LauncherItem(
                title="source/get_file_list",
                callback=partial(self.launch, "gfl"),
                description=GetFileList.__doc__,
            ),
            LauncherItem(
                title="source/get_japan_government_statistics",
                callback=partial(self.launch, "gjgs"),
                description=GetJapanGovernmentStatistics.__doc__,
            ),
        )
        for item in launcher_items:
            description: QLabel = QLabel(item.description)
            description.setWordWrap(True)
            btn: QPushButton = QPushButton(item.title)
            btn.clicked.connect(item.callback)
            main_container_layout.addWidget(description)
            main_container_layout.addWidget(btn)
        main_container_layout.addStretch()


def create_window(app: QApplication) -> MainApp_Of_Gui_Launcher:
    window: MainApp_Of_Gui_Launcher = MainApp_Of_Gui_Launcher(app)
    return window


@wrap_start_up_with_gui
def main() -> tuple:
    """Main function."""
    app: QApplication = QApplication(sys.argv)
    return app, create_window


if __name__ == "__main__":
    main()
