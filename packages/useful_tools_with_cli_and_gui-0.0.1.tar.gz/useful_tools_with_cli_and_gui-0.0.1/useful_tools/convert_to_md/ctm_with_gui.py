import platform
import subprocess
import sys
from pathlib import Path

from PySide6.QtCore import QDir, Signal, Slot
from PySide6.QtWidgets import (
    QApplication,
    QFileDialog,
    QFormLayout,
    QLabel,
    QListWidget,
    QMainWindow,
    QMessageBox,
    QProgressBar,
    QPushButton,
    QScrollArea,
    QTextEdit,
    QVBoxLayout,
    QWidget,
)

from useful_tools.common.config.gui_config import (
    ConfigureShortcutsWithQtOnWsl,
    GUILogTools,
    is_wsl,
    wrap_closeevent_with_gui,
    wrap_notifying_result_with_gui,
    wrap_settingup_log_with_gui,
    wrap_showevent_with_gui,
    wrap_start_up_with_gui,
)
from useful_tools.convert_to_md.ctm_class import ConvertToMd


class MainApp_Of_CTM(QMainWindow):
    """GUI app"""

    log: Signal = Signal(str)

    @wrap_settingup_log_with_gui
    def __init__(self, app: QApplication):
        """Constructor"""
        super().__init__()
        self.app: QApplication = app
        self.sc_init_flag: bool = False
        self.obj_of_sc: ConfigureShortcutsWithQtOnWsl = ConfigureShortcutsWithQtOnWsl(self.app)
        self.obj_of_lt: GUILogTools = getattr(self, "obj_of_lt")
        self.obj_of_cls: ConvertToMd = ConvertToMd(self.obj_of_lt.logger)
        self.setup_ui()

    @wrap_showevent_with_gui
    def showEvent(self, event) -> None:
        """Show."""
        super().showEvent(event)

    @wrap_closeevent_with_gui
    def closeEvent(self, event) -> None:
        """Quit."""
        super().closeEvent(event)

    def display_info(self, msg: str) -> None:
        """Display info."""
        QMessageBox.information(self, "Information", msg)
        self.obj_of_lt.logger.info(msg)

    @Slot(str)
    def append_log_to_qtextedit(self, msg: str) -> None:
        """Append log to QTextEdit."""
        self.log_area.append(msg)

    @wrap_notifying_result_with_gui
    def setup_ui(self) -> None:
        """Configure the User Interface."""
        # タイトル
        self.setWindowTitle("Specified file to Markdown file batch conversion app")
        central: QWidget = QWidget()
        self.setCentralWidget(central)
        base_layout: QVBoxLayout = QVBoxLayout(central)
        # 主要
        main_scroll_area: QScrollArea = QScrollArea()
        main_scroll_area.setWidgetResizable(True)
        base_layout.addWidget(main_scroll_area)
        main_container: QWidget = QWidget()
        main_container_layout: QFormLayout = QFormLayout(main_container)
        main_scroll_area.setWidget(main_container)
        # 概要
        overview_area: QTextEdit = QTextEdit()
        overview_area.setReadOnly(True)
        lines_of_overview: list = []
        lines_of_overview.append(
            "Below is a list of file extensions that can be specified as the source for conversion.\n"
        )
        for key, info in self.obj_of_cls.file_types.items():
            values: str = ""
            for value in info:
                values += f"{value}, "
            values = values.rstrip(", ")
            lines_of_overview.append(f"{key}: {values}")
        overview_area.setText("\n".join(lines_of_overview))
        main_container_layout.addRow(QLabel("Notice: "))
        main_container_layout.addRow(overview_area)
        # 変換元
        self.label_src: QLabel = QLabel("Source folder: Not selected")
        main_container_layout.addRow(self.label_src)
        btn_select_src: QPushButton = QPushButton("Browse the source folder")
        main_container_layout.addRow(btn_select_src)
        btn_select_src.clicked.connect(self.browse_src_folder)
        btn_open_src: QPushButton = QPushButton("Open the source folder")
        main_container_layout.addRow(btn_open_src)
        btn_open_src.clicked.connect(self.open_explorer_in_src_folder)
        # 対象ファイルの一覧
        main_container_layout.addRow(QLabel("List of files to be converted: "))
        self.lst_widget: QListWidget = QListWidget()
        main_container_layout.addRow(self.lst_widget)
        # 変換先
        self.label_dst: QLabel = QLabel("Destination folder: Not selected")
        main_container_layout.addRow(self.label_dst)
        btn_select_dst: QPushButton = QPushButton("Browse the destination folder")
        main_container_layout.addRow(btn_select_dst)
        btn_select_dst.clicked.connect(self.browse_dst_folder)
        btn_open_dst: QPushButton = QPushButton("Open the destination folder")
        main_container_layout.addRow(btn_open_dst)
        btn_open_dst.clicked.connect(self.open_explorer_in_dst_folder)
        # Progress
        main_container_layout.addRow(QLabel("Progress: "))
        self.progress_bar: QProgressBar = QProgressBar()
        main_container_layout.addRow(self.progress_bar)
        # 実行
        btn_convert: QPushButton = QPushButton("Execute")
        main_container_layout.addRow(btn_convert)
        btn_convert.clicked.connect(self.convert_all_files)
        # ログ
        self.log_area: QTextEdit = QTextEdit()
        self.log_area.setReadOnly(True)
        main_container_layout.addRow(QLabel("Log: "))
        main_container_layout.addRow(self.log_area)

    def display_file_lst(self) -> None:
        """Display the list of files."""
        self.obj_of_cls.create_file_lst()
        self.lst_widget.clear()
        for f in self.obj_of_cls.filtered_lst_of_f:
            file_p: Path = Path(f)
            file_s: str = file_p.name
            self.lst_widget.addItem(file_s)
        self.progress_bar.setValue(0)

    @Slot()
    @wrap_notifying_result_with_gui
    def browse_src_folder(self) -> None:
        """Browse the source folder."""
        self.obj_of_cls.src_folder_path = QFileDialog.getExistingDirectory(
            self, caption="Browse source folder", dir=QDir.homePath(), options=QFileDialog.Option.ShowDirsOnly
        )
        if not self.obj_of_cls.src_folder_path:
            raise Exception("Browse the source folder.")
        folder_p: Path = Path(self.obj_of_cls.src_folder_path).expanduser()
        self.obj_of_cls.src_folder_path = str(folder_p)
        self.label_src.setText(f"Source folder: {self.obj_of_cls.src_folder_path}")
        if self.obj_of_cls.dst_folder_path:
            self.display_file_lst()

    @Slot()
    @wrap_notifying_result_with_gui
    def browse_dst_folder(self) -> None:
        """Browse the destination folder."""
        self.obj_of_cls.dst_folder_path = QFileDialog.getExistingDirectory(
            self,
            caption="Browse destination folder",
            dir=QDir.homePath(),
            options=QFileDialog.Option.ShowDirsOnly,
        )
        if not self.obj_of_cls.dst_folder_path:
            raise Exception("Browse the destination folder.")
        folder_p: Path = Path(self.obj_of_cls.dst_folder_path).expanduser()
        self.obj_of_cls.dst_folder_path = str(folder_p)
        self.label_dst.setText(f"Destination folder: {self.obj_of_cls.dst_folder_path}")
        if self.obj_of_cls.src_folder_path:
            self.display_file_lst()

    def open_explorer(self, folder_path: str) -> None:
        """Open File Explorer."""
        if folder_path == "":
            raise Exception("Browse the folder.")
        if platform.system().lower() == "windows":
            subprocess.run(args=["explorer", folder_path], shell=False)
        elif is_wsl():
            filepath_of_explorer_on_wsl: str = "/mnt/c/Windows/explorer.exe"
            # Windowsのパスに変換（/mnt/c/... 形式）
            wsl_path: str = (
                subprocess.check_output(args=["wslpath", "-w", folder_path]).decode("utf-8").strip()
            )
            subprocess.run(args=[filepath_of_explorer_on_wsl, wsl_path])

    @Slot()
    @wrap_notifying_result_with_gui
    def open_explorer_in_src_folder(self) -> None:
        """Open File Explorer in the source folder."""
        self.open_explorer(self.obj_of_cls.src_folder_path)

    @Slot()
    @wrap_notifying_result_with_gui
    def open_explorer_in_dst_folder(self) -> None:
        """Open File Explorer in the destination folder."""
        self.open_explorer(self.obj_of_cls.dst_folder_path)

    @Slot()
    @wrap_notifying_result_with_gui
    def convert_all_files(self) -> None:
        """Convert all files at once."""
        if not self.obj_of_cls.filtered_lst_of_f:
            raise Exception("The file list has not been initialized.")
        self.progress_bar.setRange(0, self.obj_of_cls.number_of_f)
        for i in range(self.obj_of_cls.number_of_f):
            self.obj_of_cls.convert_file()
            self.progress_bar.setValue(i + 1)
            if self.obj_of_cls.complete:
                break
            self.obj_of_cls.move_to_next_file()


def create_window(app: QApplication) -> MainApp_Of_CTM:
    window: MainApp_Of_CTM = MainApp_Of_CTM(app)
    return window


@wrap_start_up_with_gui
def main() -> tuple:
    """Main function."""
    app: QApplication = QApplication(sys.argv)
    return app, create_window


if __name__ == "__main__":
    main()
