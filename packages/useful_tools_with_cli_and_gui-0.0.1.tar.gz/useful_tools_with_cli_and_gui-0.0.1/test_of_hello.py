import hello


# テスト関数: 指定されている関数の動作を確認するためのテストをする
def test_func():
    # 指定された関数を呼び出す
    hello.main()
