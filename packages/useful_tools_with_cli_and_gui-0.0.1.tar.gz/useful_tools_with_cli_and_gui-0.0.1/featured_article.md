---
title: "Graduating from VBA: Building a Serious Productivity Repository with Python and WSL2"
emoji: "🐥"
type: "tech" # tech / idea
topics: ["wsl2", "github", "vscode", "python"]
published: true
---
# Introduction

I worked in an administrative role in my previous job.

I was doing it almost entirely by myself, and I felt that PC work was such a chore when the volume was high! I kept thinking, "Isn't there a better way?"

So, to make things easier for myself (secretly), I decided to try my hand at `VBA (Visual Basic for Application)`.

However, as you realize once you try it, VBA is dominated by Excel and Access (though Word and PowerPoint are also available).

* About VBA
  * You have to write it in the `VBE (Visual Basic Editor)`.
  * External integration is a bit difficult for beginners.
  * Managing source code is also a concern.

While it's possible to build things with it, I felt its limitations and gave up.

And then, while I was drifting around, I encountered `Python`.

* About Python
  * You can write it in your favorite editor.
  * It's an all-rounder with a rich ecosystem of libraries.
  * Since it's text-based, you can manage the source code.

Nowadays, I only use Python.

I've read introductory and advanced guidebooks, and I build tools while consulting generative AI for the more advanced parts.

# Development Environment

For my editor, I use `VSCode (Visual Studio Code)`.

My terminal is `Windows Terminal`.

For source code management, I use `Git`.

My OS is Windows, but since `WSL2 (Windows Subsystem for Linux 2)` is well-suited for programming, I've set it up and work within `Ubuntu`.

# Custom Business Efficiency Tools

The following repository is what I built.

https://github.com/yellow-x-black/useful_tools

* Design Philosophy
  * Dual CLI/GUI Support: Covers both quick usage for actual work and intuitive operation.
  * Robust Design: To ensure stable operation on my own, I spent the most time on exception handling and debugging.
  * Designed for Distribution: By placing executables in GitHub `Releases`, I've made it accessible even for those without a Python environment.

# Conclusion

It's a great time to be alive.

In the past, if there was something I didn't understand about programming, I would ask on [`Stack Overflow`](https://stackoverflow.com).

Now, although verification is necessary due to `hallucinations`, `generative AI` such as ChatGPT, Copilot, and Gemini give immediate answers.

You can proceed with your programming by asking generative AI and researching things on your own.

# Reference Articles and Links

https://learn.microsoft.com/ja-jp/windows/wsl/
