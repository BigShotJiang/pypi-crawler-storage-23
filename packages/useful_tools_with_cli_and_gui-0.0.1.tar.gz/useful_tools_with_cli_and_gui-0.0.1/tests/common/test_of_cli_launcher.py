import pytest

from useful_tools.common.launcher import cli_launcher


# テスト関数: 指定されている関数の動作を確認するためのテストをする
def test_func(monkeypatch):
    # main を強制的に KeyboardInterrupt させる
    def fake_loop():
        raise KeyboardInterrupt

    monkeypatch.setattr("useful_tools.common.launcher.cli_launcher.main", fake_loop)
    with pytest.raises(KeyboardInterrupt):
        cli_launcher.main()
