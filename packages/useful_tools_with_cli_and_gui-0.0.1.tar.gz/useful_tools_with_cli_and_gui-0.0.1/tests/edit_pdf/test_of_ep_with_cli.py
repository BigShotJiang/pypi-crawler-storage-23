import pytest

from useful_tools.edit_pdf import ep_with_cli


# テスト関数: 指定されている関数の動作を確認するためのテストをする
def test_func(monkeypatch):
    # main を強制的に KeyboardInterrupt させる
    def fake_loop():
        raise KeyboardInterrupt

    monkeypatch.setattr("useful_tools.edit_pdf.ep_with_cli.main", fake_loop)
    with pytest.raises(KeyboardInterrupt):
        ep_with_cli.main()
