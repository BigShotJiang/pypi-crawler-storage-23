def main():
    print("Hello from useful_tools!")


if __name__ == "__main__":
    main()
