"""Tests for client initialization and error handling."""

from __future__ import annotations

import pytest
import httpx
from pytest_httpx import HTTPXMock

from khaleejiapi import (
    AsyncKhaleejiAPI,
    KhaleejiAPI,
    AuthenticationError,
    KhaleejiAPIError,
    RateLimitError,
    ServerError,
    ValidationError,
)


# ---------------------------------------------------------------------------
# Initialization
# ---------------------------------------------------------------------------


class TestClientInit:
    def test_requires_api_key(self) -> None:
        with pytest.raises(ValueError, match="non-empty"):
            KhaleejiAPI("")

    def test_creates_resource_namespaces(self) -> None:
        client = KhaleejiAPI("test-key", base_url="http://test")
        assert hasattr(client, "validation")
        assert hasattr(client, "geo")
        assert hasattr(client, "finance")
        assert hasattr(client, "documents")
        assert hasattr(client, "communication")
        assert hasattr(client, "utility")
        client.close()

    def test_context_manager(self) -> None:
        with KhaleejiAPI("test-key", base_url="http://test") as client:
            assert client is not None


class TestAsyncClientInit:
    def test_requires_api_key(self) -> None:
        with pytest.raises(ValueError, match="non-empty"):
            AsyncKhaleejiAPI("")

    @pytest.mark.asyncio
    async def test_async_context_manager(self) -> None:
        async with AsyncKhaleejiAPI("test-key", base_url="http://test") as client:
            assert client is not None


# ---------------------------------------------------------------------------
# Error handling (sync)
# ---------------------------------------------------------------------------


class TestSyncErrors:
    def test_authentication_error(self, httpx_mock: HTTPXMock) -> None:
        httpx_mock.add_response(
            status_code=401,
            json={"error": {"code": "UNAUTHORIZED", "message": "API key is required"}},
        )
        with KhaleejiAPI("bad-key", base_url="http://test") as client:
            with pytest.raises(AuthenticationError) as exc_info:
                client.validation.validate_email("a@b.com")
            assert exc_info.value.status_code == 401
            assert exc_info.value.code == "UNAUTHORIZED"

    def test_validation_error(self, httpx_mock: HTTPXMock) -> None:
        httpx_mock.add_response(
            status_code=400,
            json={"error": {"code": "MISSING_PARAMETER", "message": "email is required"}},
        )
        with KhaleejiAPI("key", base_url="http://test") as client:
            with pytest.raises(ValidationError) as exc_info:
                client.validation.validate_email("")
            assert exc_info.value.status_code == 400

    def test_rate_limit_error(self, httpx_mock: HTTPXMock) -> None:
        httpx_mock.add_response(
            status_code=429,
            headers={"Retry-After": "30", "X-RateLimit-Limit": "60"},
            json={
                "error": {
                    "code": "RATE_LIMIT_EXCEEDED",
                    "message": "Rate limit exceeded",
                }
            },
        )
        with KhaleejiAPI("key", base_url="http://test", max_retries=0) as client:
            with pytest.raises(RateLimitError) as exc_info:
                client.validation.validate_email("a@b.com")
            assert exc_info.value.retry_after == 30

    def test_server_error(self, httpx_mock: HTTPXMock) -> None:
        httpx_mock.add_response(
            status_code=500,
            json={"error": {"code": "INTERNAL_ERROR", "message": "Server error"}},
        )
        with KhaleejiAPI("key", base_url="http://test", max_retries=0) as client:
            with pytest.raises(ServerError):
                client.geo.lookup_ip("8.8.8.8")


# ---------------------------------------------------------------------------
# Rate-limit header parsing
# ---------------------------------------------------------------------------


class TestRateLimitHeaders:
    def test_parses_rate_limit_headers(self, httpx_mock: HTTPXMock) -> None:
        httpx_mock.add_response(
            status_code=200,
            headers={
                "X-RateLimit-Limit": "1000",
                "X-RateLimit-Remaining": "999",
                "X-RateLimit-Reset": "1700000000",
            },
            json={"data": {"email": "a@b.com", "valid": True}, "meta": {"timestamp": "2025-01-01T00:00:00Z"}},
        )
        with KhaleejiAPI("key", base_url="http://test") as client:
            client.validation.validate_email("a@b.com")
            rl = client.last_rate_limit
            assert rl["limit"] == 1000
            assert rl["remaining"] == 999


# ---------------------------------------------------------------------------
# Retry logic
# ---------------------------------------------------------------------------


class TestRetry:
    def test_retries_on_500_then_succeeds(self, httpx_mock: HTTPXMock) -> None:
        httpx_mock.add_response(
            status_code=500,
            json={"error": {"code": "INTERNAL_ERROR", "message": "fail"}},
        )
        httpx_mock.add_response(
            status_code=200,
            json={"data": {"ip": "8.8.8.8"}, "meta": {"timestamp": "2025-01-01T00:00:00Z"}},
        )
        with KhaleejiAPI("key", base_url="http://test", max_retries=1) as client:
            result = client.geo.lookup_ip("8.8.8.8")
            assert result["ip"] == "8.8.8.8"
