"""Asynchronous KhaleejiAPI client."""

from __future__ import annotations

from typing import Optional

from ._client import DEFAULT_BASE_URL, DEFAULT_TIMEOUT, MAX_RETRIES, AsyncHTTPClient
from .resources.communication import AsyncCommunicationResource
from .resources.documents import AsyncDocumentsResource
from .resources.finance import AsyncFinanceResource
from .resources.geo import AsyncGeoResource
from .resources.utility import AsyncUtilityResource
from .resources.islamic import AsyncIslamicResource
from .resources.validation import AsyncValidationResource


class AsyncKhaleejiAPI:
    """Asynchronous client for the KhaleejiAPI platform.

    Example::

        import asyncio
        from khaleejiapi import AsyncKhaleejiAPI

        async def main():
            client = AsyncKhaleejiAPI("kapi_live_...")
            result = await client.validation.validate_email("user@example.com")
            print(result["valid"])
            await client.close()

        asyncio.run(main())

    The client can also be used as an async context manager::

        async with AsyncKhaleejiAPI("kapi_live_...") as client:
            ip = await client.geo.lookup_ip("8.8.8.8")
    """

    validation: AsyncValidationResource
    geo: AsyncGeoResource
    finance: AsyncFinanceResource
    documents: AsyncDocumentsResource
    communication: AsyncCommunicationResource
    utility: AsyncUtilityResource
    islamic: AsyncIslamicResource

    def __init__(
        self,
        api_key: str,
        *,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = DEFAULT_TIMEOUT,
        max_retries: int = MAX_RETRIES,
    ) -> None:
        if not api_key:
            raise ValueError("api_key must be a non-empty string")
        self._http = AsyncHTTPClient(
            api_key=api_key,
            base_url=base_url,
            timeout=timeout,
            max_retries=max_retries,
        )
        self.validation = AsyncValidationResource(self._http)
        self.geo = AsyncGeoResource(self._http)
        self.finance = AsyncFinanceResource(self._http)
        self.documents = AsyncDocumentsResource(self._http)
        self.communication = AsyncCommunicationResource(self._http)
        self.utility = AsyncUtilityResource(self._http)
        self.islamic = AsyncIslamicResource(self._http)

    # -- context manager ----------------------------------------------------

    async def __aenter__(self) -> "AsyncKhaleejiAPI":
        return self

    async def __aexit__(self, *_: object) -> None:
        await self.close()

    # -- lifecycle ----------------------------------------------------------

    async def close(self) -> None:
        """Close the underlying HTTP connection pool."""
        await self._http.close()

    # -- helpers ------------------------------------------------------------

    @property
    def last_rate_limit(self) -> dict:  # type: ignore[type-arg]
        """Rate-limit headers from the most recent response."""
        return dict(self._http.last_rate_limit)
