"""TypedDict response types for the KhaleejiAPI SDK."""

from __future__ import annotations

from typing import Any, Dict, List, Optional
from typing_extensions import TypedDict


# ---------------------------------------------------------------------------
# Envelope
# ---------------------------------------------------------------------------


class Meta(TypedDict):
    timestamp: str


class APIResponse(TypedDict):
    data: Dict[str, Any]
    meta: Meta


class ErrorDetail(TypedDict):
    code: str
    message: str


class ErrorResponse(TypedDict):
    error: ErrorDetail


# ---------------------------------------------------------------------------
# Rate-limit info returned alongside every response
# ---------------------------------------------------------------------------


class RateLimitInfo(TypedDict, total=False):
    limit: int
    remaining: int
    reset: int


# ---------------------------------------------------------------------------
# Validation
# ---------------------------------------------------------------------------


class EmailChecks(TypedDict):
    syntax: bool
    disposable: bool
    mx: bool
    role: bool


class EmailValidationResult(TypedDict, total=False):
    email: str
    valid: bool
    reason: str
    checks: EmailChecks
    suggestion: Optional[str]
    domain: str
    localPart: str


class PhoneCountry(TypedDict):
    code: str
    name: str
    nameAr: str
    prefix: str


class PhoneValidationResult(TypedDict, total=False):
    phone: str
    valid: bool
    e164: Optional[str]
    country: PhoneCountry
    type: str
    nationalNumber: str
    reason: str
    supported_countries: List[str]


class VatValidationResult(TypedDict, total=False):
    trn: str
    country: str
    countryName: str
    valid: bool
    reason: str


class IbanBank(TypedDict, total=False):
    name: str
    bic: str


class IbanValidationResult(TypedDict, total=False):
    iban: str
    valid: bool
    countryCode: str
    country: str
    reason: str
    bank: Optional[IbanBank]
    supportedCountries: List[str]


class EmiratesIdComponents(TypedDict):
    year: str
    random: str
    checkDigit: str


class EmiratesIdValidationResult(TypedDict, total=False):
    emiratesId: str
    valid: bool
    formatted: str
    components: EmiratesIdComponents
    message: str


# ---------------------------------------------------------------------------
# Geo
# ---------------------------------------------------------------------------


class Continent(TypedDict):
    code: str
    name: str


class Country(TypedDict, total=False):
    code: str
    name: str
    isEU: bool


class Region(TypedDict):
    code: str
    name: str


class Location(TypedDict):
    latitude: float
    longitude: float
    timezone: str


class Connection(TypedDict, total=False):
    asn: Optional[int]
    isp: str
    organization: str


class IpLookupResult(TypedDict, total=False):
    ip: str
    type: str
    continent: Continent
    country: Country
    region: Region
    city: str
    postal: Optional[str]
    location: Location
    connection: Connection


class TimezoneResult(TypedDict, total=False):
    timezone: str
    utcOffset: str
    dstOffset: str
    localTime: str
    isDST: bool
    location: str


class GeocodeResult(TypedDict, total=False):
    formattedAddress: str
    latitude: float
    longitude: float
    components: Dict[str, Any]
    placeId: str


class WeatherCurrent(TypedDict, total=False):
    temperature: float
    feelsLike: float
    humidity: int
    description: str
    icon: str
    windSpeed: float
    windDirection: str


class WeatherResult(TypedDict, total=False):
    city: str
    country: str
    current: WeatherCurrent
    forecast: List[Dict[str, Any]]


# ---------------------------------------------------------------------------
# Finance
# ---------------------------------------------------------------------------


class ExchangeRatesResult(TypedDict, total=False):
    base: str
    timestamp: str
    rates: Dict[str, float]


class ExchangeConvertResult(TypedDict, total=False):
    """Returned when amount + target are provided."""

    # keep same name; union at call-site
    amount: float
    converted: float
    rate: float
    timestamp: str


class VatCalculationResult(TypedDict, total=False):
    amount: float
    vatRate: float
    vatAmount: float
    total: float
    country: str
    inclusive: bool


class Holiday(TypedDict, total=False):
    name: str
    nameAr: str
    date: str
    type: str


class HolidaysResult(TypedDict, total=False):
    country: str
    year: int
    holidays: List[Holiday]


# ---------------------------------------------------------------------------
# Communication
# ---------------------------------------------------------------------------


class TranslationResult(TypedDict, total=False):
    text: str
    translated: str
    detectedLanguage: str
    confidence: float
    wordsMatched: int
    totalWords: int


class UrlShortenResult(TypedDict, total=False):
    code: str
    shortUrl: str
    originalUrl: str
    expiresInDays: int
    createdAt: str


# ---------------------------------------------------------------------------
# Utility
# ---------------------------------------------------------------------------


class FraudSignal(TypedDict):
    field: str
    risk: str
    score: int
    reason: str


class FraudCheckResult(TypedDict, total=False):
    riskScore: int
    riskLevel: str
    signals: List[FraudSignal]
    recommendation: str


# ---------------------------------------------------------------------------
# Hijri Calendar
# ---------------------------------------------------------------------------


class HijriDateInfo(TypedDict, total=False):
    date: str
    year: int
    month: int
    day: int
    monthName: str
    monthNameAr: str
    dayOfWeek: str
    dayOfWeekAr: str


class HijriConversionResult(TypedDict):
    gregorian: HijriDateInfo
    hijri: HijriDateInfo
    direction: str


# ---------------------------------------------------------------------------
# Prayer Times
# ---------------------------------------------------------------------------


class PrayerTimesLocation(TypedDict, total=False):
    lat: float
    lng: float
    city: str
    country: str


class Prayers(TypedDict):
    fajr: str
    sunrise: str
    dhuhr: str
    asr: str
    maghrib: str
    isha: str


class QiblaInfo(TypedDict):
    direction: float
    compass: str


class PrayerTimesResult(TypedDict, total=False):
    location: PrayerTimesLocation
    date: str
    method: Dict[str, Any]
    school: str
    prayers: Prayers
    qibla: QiblaInfo


# ---------------------------------------------------------------------------
# Arabic Text Processing
# ---------------------------------------------------------------------------


class ArabicProcessResult(TypedDict, total=False):
    operation: str
    original: str
    text: str
    result: str


# ---------------------------------------------------------------------------
# Saudi ID Validation
# ---------------------------------------------------------------------------


class SaudiIdDetails(TypedDict, total=False):
    prefix: int
    birthYearHijri: str
    estimatedBirthYearGregorian: str
    serialPart: str


class SaudiIdResult(TypedDict, total=False):
    id: str
    valid: bool
    type: str
    typeAr: str
    nationality: str
    details: SaudiIdDetails
    errors: List[str]


class SaudiIdBatchSummary(TypedDict):
    total: int
    valid: int
    invalid: int


class SaudiIdBatchResult(TypedDict):
    results: List[SaudiIdResult]
    summary: SaudiIdBatchSummary


# ---------------------------------------------------------------------------
# Business Days
# ---------------------------------------------------------------------------


class BusinessDaysResult(TypedDict, total=False):
    date: str
    isBusinessDay: bool
    businessDays: int
    totalDays: int
    resultDate: str


# ---------------------------------------------------------------------------
# AI Translation (updated)
# ---------------------------------------------------------------------------


class TranslationSourceInfo(TypedDict):
    language: str
    name: str
    text: str


class TranslationTargetInfo(TypedDict):
    language: str
    name: str


class AITranslationResult(TypedDict, total=False):
    translatedText: str
    source: TranslationSourceInfo
    target: TranslationTargetInfo
    transliteration: Optional[str]
    confidence: float
    formality: str
    cached: bool


__all__ = [
    "Meta",
    "APIResponse",
    "ErrorDetail",
    "ErrorResponse",
    "RateLimitInfo",
    "EmailChecks",
    "EmailValidationResult",
    "PhoneCountry",
    "PhoneValidationResult",
    "VatValidationResult",
    "IbanBank",
    "IbanValidationResult",
    "EmiratesIdComponents",
    "EmiratesIdValidationResult",
    "Continent",
    "Country",
    "Region",
    "Location",
    "Connection",
    "IpLookupResult",
    "TimezoneResult",
    "GeocodeResult",
    "WeatherCurrent",
    "WeatherResult",
    "ExchangeRatesResult",
    "ExchangeConvertResult",
    "VatCalculationResult",
    "Holiday",
    "HolidaysResult",
    "TranslationResult",
    "UrlShortenResult",
    "FraudSignal",
    "FraudCheckResult",
    "HijriDateInfo",
    "HijriConversionResult",
    "PrayerTimesLocation",
    "Prayers",
    "QiblaInfo",
    "PrayerTimesResult",
    "ArabicProcessResult",
    "SaudiIdDetails",
    "SaudiIdResult",
    "SaudiIdBatchSummary",
    "SaudiIdBatchResult",
    "BusinessDaysResult",
    "TranslationSourceInfo",
    "TranslationTargetInfo",
    "AITranslationResult",
]
