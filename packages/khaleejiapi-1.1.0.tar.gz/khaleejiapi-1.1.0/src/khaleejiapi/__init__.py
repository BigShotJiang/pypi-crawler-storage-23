"""KhaleejiAPI — Official Python SDK for the KhaleejiAPI platform."""

from __future__ import annotations

from .client import KhaleejiAPI
from .async_client import AsyncKhaleejiAPI
from ._errors import (
    AuthenticationError,
    ConflictError,
    ForbiddenError,
    KhaleejiAPIError,
    NotFoundError,
    RateLimitError,
    ServerError,
    ValidationError,
)
from ._types import (
    AITranslationResult,
    APIResponse,
    ArabicProcessResult,
    BusinessDaysResult,
    EmailChecks,
    EmailValidationResult,
    EmiratesIdComponents,
    EmiratesIdValidationResult,
    ErrorDetail,
    ErrorResponse,
    ExchangeConvertResult,
    ExchangeRatesResult,
    FraudCheckResult,
    FraudSignal,
    GeocodeResult,
    HijriConversionResult,
    HijriDateInfo,
    Holiday,
    HolidaysResult,
    IbanBank,
    IbanValidationResult,
    IpLookupResult,
    Meta,
    PhoneCountry,
    PhoneValidationResult,
    Prayers,
    PrayerTimesLocation,
    PrayerTimesResult,
    QiblaInfo,
    RateLimitInfo,
    SaudiIdBatchResult,
    SaudiIdBatchSummary,
    SaudiIdDetails,
    SaudiIdResult,
    TimezoneResult,
    TranslationResult,
    TranslationSourceInfo,
    TranslationTargetInfo,
    UrlShortenResult,
    VatCalculationResult,
    VatValidationResult,
    WeatherCurrent,
    WeatherResult,
)

__version__ = "1.1.0"

__all__ = [
    # Clients
    "KhaleejiAPI",
    "AsyncKhaleejiAPI",
    # Errors
    "KhaleejiAPIError",
    "AuthenticationError",
    "ForbiddenError",
    "ValidationError",
    "NotFoundError",
    "ConflictError",
    "RateLimitError",
    "ServerError",
    # Types – envelope
    "APIResponse",
    "ErrorDetail",
    "ErrorResponse",
    "Meta",
    "RateLimitInfo",
    # Types – validation
    "EmailChecks",
    "EmailValidationResult",
    "PhoneCountry",
    "PhoneValidationResult",
    "VatValidationResult",
    "IbanBank",
    "IbanValidationResult",
    "EmiratesIdComponents",
    "EmiratesIdValidationResult",
    # Types – geo
    "IpLookupResult",
    "TimezoneResult",
    "GeocodeResult",
    "WeatherCurrent",
    "WeatherResult",
    # Types – finance
    "ExchangeRatesResult",
    "ExchangeConvertResult",
    "VatCalculationResult",
    "Holiday",
    "HolidaysResult",
    # Types – communication
    "TranslationResult",
    "UrlShortenResult",
    "AITranslationResult",
    "TranslationSourceInfo",
    "TranslationTargetInfo",
    # Types – islamic & arabic
    "HijriDateInfo",
    "HijriConversionResult",
    "PrayerTimesLocation",
    "Prayers",
    "QiblaInfo",
    "PrayerTimesResult",
    "ArabicProcessResult",
    # Types – saudi id
    "SaudiIdDetails",
    "SaudiIdResult",
    "SaudiIdBatchSummary",
    "SaudiIdBatchResult",
    # Types – business days
    "BusinessDaysResult",
    # Types – utility
    "FraudSignal",
    "FraudCheckResult",
]
