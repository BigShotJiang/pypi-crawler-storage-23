"""Resource namespaces for the KhaleejiAPI SDK."""

from .validation import ValidationResource, AsyncValidationResource
from .geo import GeoResource, AsyncGeoResource
from .finance import FinanceResource, AsyncFinanceResource
from .documents import DocumentsResource, AsyncDocumentsResource
from .communication import CommunicationResource, AsyncCommunicationResource
from .utility import UtilityResource, AsyncUtilityResource
from .islamic import IslamicResource, AsyncIslamicResource

__all__ = [
    "ValidationResource",
    "AsyncValidationResource",
    "GeoResource",
    "AsyncGeoResource",
    "FinanceResource",
    "AsyncFinanceResource",
    "DocumentsResource",
    "AsyncDocumentsResource",
    "CommunicationResource",
    "AsyncCommunicationResource",
    "UtilityResource",
    "AsyncUtilityResource",
    "IslamicResource",
    "AsyncIslamicResource",
]
