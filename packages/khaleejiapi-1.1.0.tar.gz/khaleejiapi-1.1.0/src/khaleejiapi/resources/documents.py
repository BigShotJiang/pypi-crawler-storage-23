"""Documents (image processing & PDF generation) API resources."""

from __future__ import annotations

from typing import Any, Dict, Optional

from .._client import AsyncHTTPClient, SyncHTTPClient


class DocumentsResource:
    """Synchronous document endpoints."""

    def __init__(self, client: SyncHTTPClient) -> None:
        self._client = client

    def process_image(
        self,
        image: bytes,
        operations: Optional[Dict[str, Any]] = None,
    ) -> bytes:
        """Process an image (resize, crop, compress, convert).

        Args:
            image: Raw image bytes.
            operations: Dict of operations, e.g.
                ``{"width": 800, "height": 600, "format": "webp", "quality": 80}``.

        Returns:
            Processed image bytes.
        """
        headers: Dict[str, str] = {"Content-Type": "application/octet-stream"}
        params: Dict[str, Any] = {}
        if operations:
            params.update(operations)
        return self._client.request(  # type: ignore[return-value]
            "POST",
            "/v1/image/process",
            content=image,
            params=params,
            headers=headers,
            raw_response=True,
        )

    def generate_pdf(
        self,
        *,
        html: Optional[str] = None,
        url: Optional[str] = None,
        options: Optional[Dict[str, Any]] = None,
    ) -> bytes:
        """Generate a PDF from HTML content or a URL.

        Args:
            html: HTML string to render.
            url: URL of the page to render.
            options: Extra options (e.g. ``{"format": "A4", "landscape": True}``).

        Returns:
            PDF file bytes.
        """
        body: Dict[str, Any] = {}
        if html is not None:
            body["html"] = html
        if url is not None:
            body["url"] = url
        if options is not None:
            body["options"] = options
        return self._client.request(  # type: ignore[return-value]
            "POST",
            "/v1/pdf/generate",
            json=body,
            raw_response=True,
        )


class AsyncDocumentsResource:
    """Asynchronous document endpoints."""

    def __init__(self, client: AsyncHTTPClient) -> None:
        self._client = client

    async def process_image(
        self,
        image: bytes,
        operations: Optional[Dict[str, Any]] = None,
    ) -> bytes:
        """Process an image (resize, crop, compress, convert).

        Args:
            image: Raw image bytes.
            operations: Dict of operations, e.g.
                ``{"width": 800, "height": 600, "format": "webp", "quality": 80}``.

        Returns:
            Processed image bytes.
        """
        headers: Dict[str, str] = {"Content-Type": "application/octet-stream"}
        params: Dict[str, Any] = {}
        if operations:
            params.update(operations)
        return await self._client.request(  # type: ignore[return-value]
            "POST",
            "/v1/image/process",
            content=image,
            params=params,
            headers=headers,
            raw_response=True,
        )

    async def generate_pdf(
        self,
        *,
        html: Optional[str] = None,
        url: Optional[str] = None,
        options: Optional[Dict[str, Any]] = None,
    ) -> bytes:
        """Generate a PDF from HTML content or a URL.

        Args:
            html: HTML string to render.
            url: URL of the page to render.
            options: Extra options (e.g. ``{"format": "A4", "landscape": True}``).

        Returns:
            PDF file bytes.
        """
        body: Dict[str, Any] = {}
        if html is not None:
            body["html"] = html
        if url is not None:
            body["url"] = url
        if options is not None:
            body["options"] = options
        return await self._client.request(  # type: ignore[return-value]
            "POST",
            "/v1/pdf/generate",
            json=body,
            raw_response=True,
        )
