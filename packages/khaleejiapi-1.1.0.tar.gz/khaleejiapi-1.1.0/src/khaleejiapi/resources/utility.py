"""Utility API resources (QR codes, fraud detection)."""

from __future__ import annotations

from typing import Any, Dict, Optional

from .._client import AsyncHTTPClient, SyncHTTPClient
from .._types import FraudCheckResult


class UtilityResource:
    """Synchronous utility endpoints."""

    def __init__(self, client: SyncHTTPClient) -> None:
        self._client = client

    def generate_qr(
        self,
        data: str,
        *,
        size: int = 300,
        format: str = "png",
    ) -> bytes:
        """Generate a QR code image.

        Args:
            data: The data to encode in the QR code.
            size: Image size in pixels (default ``300``).
            format: Output format — ``"png"`` or ``"svg"`` (default ``"png"``).

        Returns:
            QR code image bytes.
        """
        return self._client.request(  # type: ignore[return-value]
            "GET",
            "/v1/qr/generate",
            params={"data": data, "size": size, "format": format},
            raw_response=True,
        )

    def check_fraud(
        self,
        *,
        email: Optional[str] = None,
        ip: Optional[str] = None,
        phone: Optional[str] = None,
        user_agent: Optional[str] = None,
    ) -> FraudCheckResult:
        """Run fraud detection on the provided signals.

        At least one signal must be provided.

        Args:
            email: Email address to check.
            ip: IP address to check.
            phone: Phone number to check.
            user_agent: User-Agent string to check.

        Returns:
            Risk score, risk level, individual signals, and recommendation.
        """
        body: Dict[str, Any] = {}
        if email is not None:
            body["email"] = email
        if ip is not None:
            body["ip"] = ip
        if phone is not None:
            body["phone"] = phone
        if user_agent is not None:
            body["user_agent"] = user_agent
        return self._client.post("/v1/fraud/check", json=body)  # type: ignore[return-value]


class AsyncUtilityResource:
    """Asynchronous utility endpoints."""

    def __init__(self, client: AsyncHTTPClient) -> None:
        self._client = client

    async def generate_qr(
        self,
        data: str,
        *,
        size: int = 300,
        format: str = "png",
    ) -> bytes:
        """Generate a QR code image.

        Args:
            data: The data to encode in the QR code.
            size: Image size in pixels (default ``300``).
            format: Output format — ``"png"`` or ``"svg"`` (default ``"png"``).

        Returns:
            QR code image bytes.
        """
        return await self._client.request(  # type: ignore[return-value]
            "GET",
            "/v1/qr/generate",
            params={"data": data, "size": size, "format": format},
            raw_response=True,
        )

    async def check_fraud(
        self,
        *,
        email: Optional[str] = None,
        ip: Optional[str] = None,
        phone: Optional[str] = None,
        user_agent: Optional[str] = None,
    ) -> FraudCheckResult:
        """Run fraud detection on the provided signals.

        At least one signal must be provided.

        Args:
            email: Email address to check.
            ip: IP address to check.
            phone: Phone number to check.
            user_agent: User-Agent string to check.

        Returns:
            Risk score, risk level, individual signals, and recommendation.
        """
        body: Dict[str, Any] = {}
        if email is not None:
            body["email"] = email
        if ip is not None:
            body["ip"] = ip
        if phone is not None:
            body["phone"] = phone
        if user_agent is not None:
            body["user_agent"] = user_agent
        return await self._client.post("/v1/fraud/check", json=body)  # type: ignore[return-value]
