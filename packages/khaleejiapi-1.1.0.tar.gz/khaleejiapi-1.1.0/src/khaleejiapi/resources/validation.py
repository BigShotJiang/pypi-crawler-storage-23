"""Validation API resources."""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from .._client import AsyncHTTPClient, SyncHTTPClient
from .._types import (
    EmailValidationResult,
    EmiratesIdValidationResult,
    IbanValidationResult,
    PhoneValidationResult,
    SaudiIdBatchResult,
    SaudiIdResult,
    VatValidationResult,
)


class ValidationResource:
    """Synchronous validation endpoints."""

    def __init__(self, client: SyncHTTPClient) -> None:
        self._client = client

    def validate_email(self, email: str) -> EmailValidationResult:
        """Validate an email address (syntax, MX, disposable, role-account checks).

        Args:
            email: The email address to validate.

        Returns:
            Validation result with ``valid`` flag and detailed checks.
        """
        return self._client.get("/v1/email/validate", params={"email": email})  # type: ignore[return-value]

    def validate_phone(
        self,
        phone: str,
        country: Optional[str] = None,
    ) -> PhoneValidationResult:
        """Validate a phone number with carrier and type detection.

        Args:
            phone: The phone number (E.164 or national format).
            country: Optional ISO-3166-1 alpha-2 country code hint.

        Returns:
            Validation result with E.164 format, type, and country info.
        """
        params: Dict[str, Any] = {"phone": phone}
        if country is not None:
            params["country"] = country
        return self._client.get("/v1/phone/validate", params=params)  # type: ignore[return-value]

    def validate_vat(self, trn: str) -> VatValidationResult:
        """Validate a UAE Tax Registration Number (TRN).

        Args:
            trn: The TRN / VAT number to validate.

        Returns:
            Validation result with country and validity reason.
        """
        return self._client.get("/v1/vat/validate", params={"trn": trn})  # type: ignore[return-value]

    def validate_iban(self, iban: str) -> IbanValidationResult:
        """Validate an IBAN with bank and branch information (MENA region).

        Args:
            iban: The International Bank Account Number.

        Returns:
            Validation result with bank details and country info.
        """
        return self._client.get("/v1/iban/validate", params={"iban": iban})  # type: ignore[return-value]

    def validate_emirates_id(self, id: str) -> EmiratesIdValidationResult:
        """Validate and parse a UAE Emirates ID number.

        Args:
            id: The Emirates ID (15 digits, with or without dashes).

        Returns:
            Validation result with parsed components.
        """
        return self._client.get("/v1/validation/emirates-id", params={"id": id})  # type: ignore[return-value]

    def validate_saudi_id(self, id: str) -> SaudiIdResult:
        """Validate a Saudi National ID or Iqama number.

        Args:
            id: 10-digit Saudi National ID or Iqama number.

        Returns:
            Validation result with type, nationality, and details.
        """
        return self._client.get("/v1/validation/saudi-id", params={"id": id})  # type: ignore[return-value]

    def validate_saudi_id_batch(self, ids: List[str]) -> SaudiIdBatchResult:
        """Validate a batch of Saudi National IDs or Iqama numbers.

        Args:
            ids: List of 10-digit IDs (max 100).

        Returns:
            Batch results with summary counts.
        """
        return self._client.post("/v1/validation/saudi-id", json={"ids": ids})  # type: ignore[return-value]


class AsyncValidationResource:
    """Asynchronous validation endpoints."""

    def __init__(self, client: AsyncHTTPClient) -> None:
        self._client = client

    async def validate_email(self, email: str) -> EmailValidationResult:
        """Validate an email address (syntax, MX, disposable, role-account checks).

        Args:
            email: The email address to validate.

        Returns:
            Validation result with ``valid`` flag and detailed checks.
        """
        return await self._client.get("/v1/email/validate", params={"email": email})  # type: ignore[return-value]

    async def validate_phone(
        self,
        phone: str,
        country: Optional[str] = None,
    ) -> PhoneValidationResult:
        """Validate a phone number with carrier and type detection.

        Args:
            phone: The phone number (E.164 or national format).
            country: Optional ISO-3166-1 alpha-2 country code hint.

        Returns:
            Validation result with E.164 format, type, and country info.
        """
        params: Dict[str, Any] = {"phone": phone}
        if country is not None:
            params["country"] = country
        return await self._client.get("/v1/phone/validate", params=params)  # type: ignore[return-value]

    async def validate_vat(self, trn: str) -> VatValidationResult:
        """Validate a UAE Tax Registration Number (TRN).

        Args:
            trn: The TRN / VAT number to validate.

        Returns:
            Validation result with country and validity reason.
        """
        return await self._client.get("/v1/vat/validate", params={"trn": trn})  # type: ignore[return-value]

    async def validate_iban(self, iban: str) -> IbanValidationResult:
        """Validate an IBAN with bank and branch information (MENA region).

        Args:
            iban: The International Bank Account Number.

        Returns:
            Validation result with bank details and country info.
        """
        return await self._client.get("/v1/iban/validate", params={"iban": iban})  # type: ignore[return-value]

    async def validate_emirates_id(self, id: str) -> EmiratesIdValidationResult:
        """Validate and parse a UAE Emirates ID number.

        Args:
            id: The Emirates ID (15 digits, with or without dashes).

        Returns:
            Validation result with parsed components.
        """
        return await self._client.get("/v1/validation/emirates-id", params={"id": id})  # type: ignore[return-value]

    async def validate_saudi_id(self, id: str) -> SaudiIdResult:
        """Validate a Saudi National ID or Iqama number.

        Args:
            id: 10-digit Saudi National ID or Iqama number.

        Returns:
            Validation result with type, nationality, and details.
        """
        return await self._client.get("/v1/validation/saudi-id", params={"id": id})  # type: ignore[return-value]

    async def validate_saudi_id_batch(self, ids: List[str]) -> SaudiIdBatchResult:
        """Validate a batch of Saudi National IDs or Iqama numbers.

        Args:
            ids: List of 10-digit IDs (max 100).

        Returns:
            Batch results with summary counts.
        """
        return await self._client.post("/v1/validation/saudi-id", json={"ids": ids})  # type: ignore[return-value]
