"""Low-level HTTP transport for the KhaleejiAPI SDK (sync + async)."""

from __future__ import annotations

import time
import asyncio
from typing import Any, Dict, Optional, Union

import httpx

from ._errors import KhaleejiAPIError, RateLimitError, _error_from_response
from ._types import RateLimitInfo

DEFAULT_BASE_URL = "https://khaleejiapi.dev/api"
DEFAULT_TIMEOUT = 30.0
MAX_RETRIES = 2
RETRY_STATUS_CODES = {429, 500, 502, 503, 504}


def _build_headers(api_key: str) -> Dict[str, str]:
    return {
        "x-api-key": api_key,
        "Accept": "application/json",
        "User-Agent": "khaleejiapi-python/1.0.0",
    }


def _parse_rate_limit(headers: httpx.Headers) -> RateLimitInfo:
    info: RateLimitInfo = {}
    if "X-RateLimit-Limit" in headers:
        info["limit"] = int(headers["X-RateLimit-Limit"])
    if "X-RateLimit-Remaining" in headers:
        info["remaining"] = int(headers["X-RateLimit-Remaining"])
    if "X-RateLimit-Reset" in headers:
        info["reset"] = int(headers["X-RateLimit-Reset"])
    return info


def _backoff_delay(attempt: int) -> float:
    """Exponential backoff: 0.5s, 1s, 2s …"""
    return 0.5 * (2**attempt)


def _handle_error_body(response: httpx.Response) -> KhaleejiAPIError:
    retry_after: Optional[int] = None
    if "Retry-After" in response.headers:
        try:
            retry_after = int(response.headers["Retry-After"])
        except (ValueError, TypeError):
            retry_after = None

    try:
        body = response.json()
        err = body.get("error", {})
        code = err.get("code", "UNKNOWN_ERROR")
        message = err.get("message", response.text)
    except Exception:
        code = "UNKNOWN_ERROR"
        message = response.text or f"HTTP {response.status_code}"

    return _error_from_response(
        status_code=response.status_code,
        code=code,
        message=message,
        retry_after=retry_after,
    )


# ---------------------------------------------------------------------------
# Synchronous transport
# ---------------------------------------------------------------------------


class SyncHTTPClient:
    """Thin wrapper around ``httpx.Client`` with retry logic."""

    def __init__(
        self,
        api_key: str,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = DEFAULT_TIMEOUT,
        max_retries: int = MAX_RETRIES,
    ) -> None:
        self._api_key = api_key
        self._base_url = base_url.rstrip("/")
        self._max_retries = max_retries
        self._client = httpx.Client(
            base_url=self._base_url,
            headers=_build_headers(api_key),
            timeout=timeout,
        )

    # -- public helpers -----------------------------------------------------

    @property
    def last_rate_limit(self) -> RateLimitInfo:
        return self._last_rl

    # -- request methods ----------------------------------------------------

    def request(
        self,
        method: str,
        path: str,
        *,
        params: Optional[Dict[str, Any]] = None,
        json: Optional[Dict[str, Any]] = None,
        content: Optional[bytes] = None,
        headers: Optional[Dict[str, str]] = None,
        raw_response: bool = False,
    ) -> Any:
        """Execute an HTTP request with automatic retry on transient errors."""
        last_exc: Optional[Exception] = None
        self._last_rl: RateLimitInfo = {}

        for attempt in range(self._max_retries + 1):
            try:
                response = self._client.request(
                    method,
                    path,
                    params=_clean_params(params),
                    json=json,
                    content=content,
                    headers=headers,
                )
            except httpx.TransportError as exc:
                last_exc = exc
                if attempt < self._max_retries:
                    time.sleep(_backoff_delay(attempt))
                    continue
                raise KhaleejiAPIError(
                    f"Connection error: {exc}",
                    code="CONNECTION_ERROR",
                    status_code=0,
                ) from exc

            self._last_rl = _parse_rate_limit(response.headers)

            if response.status_code < 400:
                if raw_response:
                    return response.content
                return response.json().get("data", response.json())

            # Retry on transient errors
            if (
                response.status_code in RETRY_STATUS_CODES
                and attempt < self._max_retries
            ):
                delay = _backoff_delay(attempt)
                if response.status_code == 429 and "Retry-After" in response.headers:
                    try:
                        delay = max(delay, float(response.headers["Retry-After"]))
                    except (ValueError, TypeError):
                        pass
                time.sleep(delay)
                continue

            raise _handle_error_body(response)

        # Shouldn't reach here, but just in case
        if last_exc is not None:
            raise KhaleejiAPIError(
                f"Max retries exceeded: {last_exc}",
                code="MAX_RETRIES",
                status_code=0,
            ) from last_exc
        raise KhaleejiAPIError("Max retries exceeded", code="MAX_RETRIES", status_code=0)

    def get(self, path: str, **kwargs: Any) -> Any:
        return self.request("GET", path, **kwargs)

    def post(self, path: str, **kwargs: Any) -> Any:
        return self.request("POST", path, **kwargs)

    def close(self) -> None:
        self._client.close()


# ---------------------------------------------------------------------------
# Asynchronous transport
# ---------------------------------------------------------------------------


class AsyncHTTPClient:
    """Thin wrapper around ``httpx.AsyncClient`` with retry logic."""

    def __init__(
        self,
        api_key: str,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = DEFAULT_TIMEOUT,
        max_retries: int = MAX_RETRIES,
    ) -> None:
        self._api_key = api_key
        self._base_url = base_url.rstrip("/")
        self._max_retries = max_retries
        self._client = httpx.AsyncClient(
            base_url=self._base_url,
            headers=_build_headers(api_key),
            timeout=timeout,
        )

    @property
    def last_rate_limit(self) -> RateLimitInfo:
        return self._last_rl

    async def request(
        self,
        method: str,
        path: str,
        *,
        params: Optional[Dict[str, Any]] = None,
        json: Optional[Dict[str, Any]] = None,
        content: Optional[bytes] = None,
        headers: Optional[Dict[str, str]] = None,
        raw_response: bool = False,
    ) -> Any:
        last_exc: Optional[Exception] = None
        self._last_rl: RateLimitInfo = {}

        for attempt in range(self._max_retries + 1):
            try:
                response = await self._client.request(
                    method,
                    path,
                    params=_clean_params(params),
                    json=json,
                    content=content,
                    headers=headers,
                )
            except httpx.TransportError as exc:
                last_exc = exc
                if attempt < self._max_retries:
                    await asyncio.sleep(_backoff_delay(attempt))
                    continue
                raise KhaleejiAPIError(
                    f"Connection error: {exc}",
                    code="CONNECTION_ERROR",
                    status_code=0,
                ) from exc

            self._last_rl = _parse_rate_limit(response.headers)

            if response.status_code < 400:
                if raw_response:
                    return response.content
                return response.json().get("data", response.json())

            if (
                response.status_code in RETRY_STATUS_CODES
                and attempt < self._max_retries
            ):
                delay = _backoff_delay(attempt)
                if response.status_code == 429 and "Retry-After" in response.headers:
                    try:
                        delay = max(delay, float(response.headers["Retry-After"]))
                    except (ValueError, TypeError):
                        pass
                await asyncio.sleep(delay)
                continue

            raise _handle_error_body(response)

        if last_exc is not None:
            raise KhaleejiAPIError(
                f"Max retries exceeded: {last_exc}",
                code="MAX_RETRIES",
                status_code=0,
            ) from last_exc
        raise KhaleejiAPIError("Max retries exceeded", code="MAX_RETRIES", status_code=0)

    async def get(self, path: str, **kwargs: Any) -> Any:
        return await self.request("GET", path, **kwargs)

    async def post(self, path: str, **kwargs: Any) -> Any:
        return await self.request("POST", path, **kwargs)

    async def close(self) -> None:
        await self._client.aclose()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _clean_params(params: Optional[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
    """Remove ``None`` values from query parameters."""
    if params is None:
        return None
    return {k: v for k, v in params.items() if v is not None}
