STANDARD_SCHEMA = {
    "income_statement": {
        "revenue": 0,
        "cogs": 0,
        "operating_expense": 0,
        "net_income": 0
    },
    "balance_sheet": {
        "total_assets": 0,
        "total_liabilities": 0,
        "equity": 0
    },
    "cash_flow": {
        "operating_cash_flow": 0,
        "investing_cash_flow": 0,
        "financing_cash_flow": 0
    }
}