from . import (
    account_move,
    account_move_line,
    account_payment_mode,
    res_company,
    res_config_settings,
    res_partner,
)
