"""
Lightweight wrapper around vamos PortManager for handler messaging.
"""
from amitools.vamos.lib.lexec.PortManager import PortManager  # type: ignore


class HandlerPortManager(PortManager):
    pass
