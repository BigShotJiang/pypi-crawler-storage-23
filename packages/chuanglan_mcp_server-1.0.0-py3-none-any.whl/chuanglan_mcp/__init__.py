"""
创蓝 253 MCP Server

企业级创蓝 253 短信平台 MCP 服务器实现
基于 FastMCP 框架构建，提供完整的类型注解和错误处理

Copyright (c) 2026 ChuangLan. MIT License.
"""

# 支持相对导入和绝对导入两种模式
try:
    from .server import mcp, main
    from .client import ChuanglanClient
    from .config import settings
    from .models import (
        SmsResponse,
        BalanceResponse,
        StatusResponse,
        SmsSendRequest,
        SmsStatusRequest,
    )
    from .exceptions import (
        ChuanglanError,
        ChuanglanAuthError,
        ChuanglanApiError,
        ChuanglanValidationError,
    )
except ImportError:
    from server import mcp, main
    from client import ChuanglanClient
    from config import settings
    from models import (
        SmsResponse,
        BalanceResponse,
        StatusResponse,
        SmsSendRequest,
        SmsStatusRequest,
    )
    from exceptions import (
        ChuanglanError,
        ChuanglanAuthError,
        ChuanglanApiError,
        ChuanglanValidationError,
    )

__version__ = "1.0.0"
__author__ = "ChuangLan"
__email__ = "support@chuanglan.com"
__all__ = [
    # Server
    "mcp",
    "main",
    # Client
    "ChuanglanClient",
    # Config
    "settings",
    # Models
    "SmsResponse",
    "BalanceResponse",
    "StatusResponse",
    "SmsSendRequest",
    "SmsStatusRequest",
    # Exceptions
    "ChuanglanError",
    "ChuanglanAuthError",
    "ChuanglanApiError",
    "ChuanglanValidationError",
]
