"""
入口点

支持以下运行方式：
1. python -m chuanglan_mcp
2. chuanglan-mcp (安装后)
3. 直接导入：from chuanglan_mcp import main
"""

from .server import main

if __name__ == "__main__":
    main()
