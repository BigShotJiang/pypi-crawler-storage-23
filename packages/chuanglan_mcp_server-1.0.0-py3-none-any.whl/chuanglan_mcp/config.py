"""
配置管理模块

使用 Pydantic Settings 进行配置管理，支持环境变量和.env 文件
"""

from functools import lru_cache
from typing import Optional, Dict

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """
    应用配置类

    配置优先级：
    1. 环境变量
    2. .env 文件
    3. 默认值
    """

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )

    # 创蓝 API 配置
    chuanglan_account: str = Field(
        ...,
        description="创蓝 API 账号",
        alias="CHUANGLAN_ACCOUNT",
    )
    chuanglan_password: str = Field(
        ...,
        description="创蓝 API 密码",
        alias="CHUANGLAN_PASSWORD",
    )

    # API 端点配置
    sms_url: str = Field(
        default="https://smssh1.253.com/msg/json",
        description="短信发送地址",
        alias="CHUANGLAN_SMS_URL",
    )
    balance_url: str = Field(
        default="https://smssh1.253.com/msg/balance/json",
        description="余额查询地址",
        alias="CHUANGLAN_BALANCE_URL",
    )
    status_url: str = Field(
        default="https://smssh1.253.com/msg/status/json",
        description="状态报告查询地址",
        alias="CHUANGLAN_STATUS_URL",
    )

    # 请求配置
    request_timeout: int = Field(
        default=30,
        description="请求超时时间（秒）",
        alias="REQUEST_TIMEOUT",
    )
    max_retries: int = Field(
        default=3,
        description="最大重试次数",
        alias="REQUEST_MAX_RETRIES",
    )
    retry_delay: float = Field(
        default=1.0,
        description="重试延迟（秒）",
        alias="REQUEST_RETRY_DELAY",
    )

    # 日志配置
    log_level: str = Field(
        default="INFO",
        description="日志级别",
        alias="LOG_LEVEL",
    )

    @property
    def api_config(self) -> Dict[str, str]:
        """获取 API 客户端配置"""
        return {
            "account": self.chuanglan_account,
            "password": self.chuanglan_password,
            "sms_url": self.sms_url,
            "balance_url": self.balance_url,
            "status_url": self.status_url,
            "timeout": self.request_timeout,
        }


@lru_cache
def get_settings() -> Settings:
    """
    获取配置实例（单例模式）

    Returns:
        Settings: 配置实例

    Raises:
        ValidationError: 配置验证失败时抛出
    """
    return Settings()


# 全局配置实例
settings = get_settings()
