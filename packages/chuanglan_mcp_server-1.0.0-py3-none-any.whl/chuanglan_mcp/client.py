"""
创蓝 253 API 客户端模块

提供异步 HTTP 客户端，用于与创蓝 253 API 交互
"""

import asyncio
import json as json_module
import logging
from typing import Optional, Dict, List

import httpx
from tenacity import (
    retry,
    stop_after_attempt,
    wait_exponential,
    retry_if_exception_type,
    RetryError,
)

from .config import Settings
from .exceptions import (
    ChuanglanAuthError,
    ChuanglanApiError,
    ChuanglanNetworkError,
    ChuanglanTimeoutError,
)
from .models import (
    SmsResponse,
    BalanceResponse,
    StatusResponse,
    StatusItem,
)

logger = logging.getLogger(__name__)


class ChuanglanClient:
    """
    创蓝 253 API 客户端

    提供短信发送、余额查询、状态查询等功能

    Attributes:
        config: 配置对象
        _http_client: HTTP 客户端实例

    Example:
        ```python
        from chuanglan_mcp import ChuanglanClient, settings

        client = ChuanglanClient(settings)

        # 发送短信
        response = await client.send_template_sms(
            phone="13800138000",
            template_id="TD20240101001",
            params={"code": "123456"}
        )

        # 查询余额
        balance = await client.query_balance()

        # 关闭客户端
        await client.close()
        ```
    """

    # API 返回码说明
    RESPONSE_CODES: dict[str, str] = {
        "0": "发送成功",
        "101": "无此用户名",
        "102": "密码错误",
        "103": "账户已冻结",
        "104": "账户已过期",
        "105": "账户已停用",
        "106": "账户余额不足",
        "201": "参数错误",
        "202": "手机号格式错误",
        "203": "短信内容为空",
        "204": "模板 ID 不存在",
        "205": "模板未审核",
        "206": "签名格式错误",
        "301": "系统异常",
        "302": "系统繁忙",
        "401": "流量控制",
        "402": "发送频率过高",
    }

    def __init__(self, config: Settings):
        """
        初始化客户端

        Args:
            config: 配置对象
        """
        self.config = config
        self._http_client: Optional[httpx.AsyncClient] = None

    async def _get_client(self) -> httpx.AsyncClient:
        """
        获取 HTTP 客户端（单例模式）

        Returns:
            httpx.AsyncClient: HTTP 客户端实例
        """
        if self._http_client is None:
            self._http_client = httpx.AsyncClient(
                timeout=httpx.Timeout(
                    self.config.request_timeout,
                    connect=10.0,
                ),
                headers={
                    "Content-Type": "application/json",
                    "User-Agent": "ChuanglanMCP/1.0.0",
                },
                limits=httpx.Limits(
                    max_keepalive_connections=10,
                    max_connections=100,
                ),
            )
        return self._http_client

    async def close(self) -> None:
        """关闭 HTTP 客户端"""
        if self._http_client:
            await self._http_client.aclose()
            self._http_client = None
            logger.info("HTTP client closed")

    def _check_response_code(self, code: str) -> None:
        """
        检查 API 返回码并抛出相应异常

        Args:
            code: API 返回码

        Raises:
            ChuanglanAuthError: 认证错误
            ChuanglanApiError: API 错误
        """
        if code == "0":
            return

        # 认证错误 (101-106)
        if code in ("101", "102", "103", "104", "105"):
            raise ChuanglanAuthError(code)

        # API 业务错误
        if code in self.RESPONSE_CODES:
            raise ChuanglanApiError(code)

        # 未知错误
        logger.warning(f"Unknown response code: {code}")

    @retry(
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=1, min=1, max=10),
        retry=retry_if_exception_type((httpx.NetworkError, httpx.TimeoutException)),
    )
    async def _request(self, method: str, url: str, json: dict) -> dict:
        """
        发送 HTTP 请求（带重试）

        Args:
            method: HTTP 方法
            url: 请求 URL
            json: 请求体

        Returns:
            dict: 响应数据

        Raises:
            ChuanglanNetworkError: 网络错误
            ChuanglanTimeoutError: 超时错误
        """
        client = await self._get_client()

        try:
            response = await client.request(method, url, json=json)
            response.raise_for_status()
            return response.json()

        except httpx.TimeoutException as e:
            logger.error(f"Request timeout: {url}")
            raise ChuanglanTimeoutError(self.config.request_timeout) from e

        except httpx.NetworkError as e:
            logger.error(f"Network error: {url}")
            raise ChuanglanNetworkError(str(e), e) from e

        except httpx.HTTPStatusError as e:
            logger.error(f"HTTP error: {e.response.status_code}")
            raise ChuanglanApiError(
                str(e.response.status_code),
                e.response.text,
            ) from e

        except RetryError as e:
            logger.error(f"Retry failed: {e}")
            raise ChuanglanNetworkError("重试失败", e) from e

    async def send_template_sms(
        self,
        phone: str,
        template_id: str,
        params: Optional[Dict[str, str]] = None,
        extend: Optional[str] = None,
        batch_id: Optional[str] = None,
    ) -> SmsResponse:
        """
        发送模板短信

        Args:
            phone: 接收手机号，支持单个手机号或逗号分隔的多个手机号
            template_id: 模板 ID
            params: 模板变量参数
            extend: 扩展码，可选
            batch_id: 批次 ID，可选

        Returns:
            SmsResponse: 发送响应

        Example:
            ```python
            response = await client.send_template_sms(
                phone="13800138000",
                template_id="TD20240101001",
                params={"code": "123456", "expire": "5"}
            )
            print(f"发送成功：{response.task_id}")
            ```
        """
        import json as json_module

        payload = {
            "account": self.config.chuanglan_account,
            "password": self.config.chuanglan_password,
            "phone": phone,
            "templateId": template_id,
        }

        if params:
            payload["param"] = json_module.dumps(params, ensure_ascii=False)

        if extend:
            payload["extend"] = extend

        if batch_id:
            payload["batchId"] = batch_id

        logger.info(f"Sending template SMS to {phone}, template: {template_id}")

        try:
            data = await self._request("POST", self.config.sms_url, payload)
            code = str(data.get("code", ""))

            self._check_response_code(code)

            return SmsResponse(
                code=code,
                msg=data.get("msg", self.RESPONSE_CODES.get(code, "")),
                task_id=data.get("taskId"),
                success=(code == "0"),
            )

        except (ChuanglanAuthError, ChuanglanApiError):
            raise
        except Exception as e:
            logger.error(f"Unexpected error: {e}")
            return SmsResponse(
                code="ERROR",
                msg=f"发送失败：{str(e)}",
                success=False,
            )

    async def query_balance(self) -> BalanceResponse:
        """
        查询账户余额

        Returns:
            BalanceResponse: 余额响应

        Example:
            ```python
            balance = await client.query_balance()
            print(f"账户余额：{balance.balance}")
            ```
        """
        payload = {
            "account": self.config.chuanglan_account,
            "password": self.config.chuanglan_password,
        }

        logger.info("Querying balance")

        try:
            data = await self._request("POST", self.config.balance_url, payload)
            code = str(data.get("code", ""))

            self._check_response_code(code)

            balance = data.get("balance")
            if balance is not None:
                try:
                    balance = float(balance)
                except (ValueError, TypeError):
                    balance = None

            return BalanceResponse(
                code=code,
                msg=data.get("msg", self.RESPONSE_CODES.get(code, "")),
                balance=balance,
                success=(code == "0"),
            )

        except (ChuanglanAuthError, ChuanglanApiError):
            raise
        except Exception as e:
            logger.error(f"Unexpected error: {e}")
            return BalanceResponse(
                code="ERROR",
                msg=f"查询失败：{str(e)}",
                success=False,
            )

    async def query_status(
        self,
        task_id: str,
        start_time: Optional[str] = None,
        end_time: Optional[str] = None,
        page: int = 1,
        page_size: int = 50,
    ) -> StatusResponse:
        """
        查询短信发送状态

        Args:
            task_id: 任务 ID
            start_time: 开始时间，格式：yyyy-MM-dd HH:mm:ss
            end_time: 结束时间，格式：yyyy-MM-dd HH:mm:ss
            page: 页码，默认 1
            page_size: 每页数量，默认 50

        Returns:
            StatusResponse: 状态响应

        Example:
            ```python
            status = await client.query_status(
                task_id="xxx",
                start_time="2024-01-01 00:00:00",
                end_time="2024-01-01 23:59:59"
            )
            for item in status.statuses:
                print(f"{item.phone}: {item.status}")
            ```
        """
        payload = {
            "account": self.config.chuanglan_account,
            "password": self.config.chuanglan_password,
            "taskId": task_id,
            "page": page,
            "pageSize": page_size,
        }

        if start_time:
            payload["startTime"] = start_time

        if end_time:
            payload["endTime"] = end_time

        logger.info(f"Querying status for task: {task_id}")

        try:
            data = await self._request("POST", self.config.status_url, payload)
            code = str(data.get("code", ""))

            self._check_response_code(code)

            status_list = data.get("status", [])
            statuses = [
                StatusItem(
                    phone=item.get("phone", ""),
                    status=item.get("status", ""),
                    send_time=item.get("sendTime"),
                    receive_time=item.get("receiveTime"),
                    report_status=item.get("reportStatus"),
                )
                for item in status_list
            ]

            return StatusResponse(
                code=code,
                msg=data.get("msg", self.RESPONSE_CODES.get(code, "")),
                statuses=statuses,
                total=len(statuses),
                page=page,
                page_size=page_size,
                success=(code == "0"),
            )

        except (ChuanglanAuthError, ChuanglanApiError):
            raise
        except Exception as e:
            logger.error(f"Unexpected error: {e}")
            return StatusResponse(
                code="ERROR",
                msg=f"查询失败：{str(e)}",
                success=False,
            )
