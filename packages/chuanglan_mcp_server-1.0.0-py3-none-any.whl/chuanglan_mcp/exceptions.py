"""
异常处理模块

定义创蓝 API 相关的自定义异常类
"""

from typing import Optional, Dict


class ChuanglanError(Exception):
    """创蓝 API 基础异常类"""

    def __init__(self, message: str, code: Optional[str] = None):
        self.message = message
        self.code = code
        super().__init__(self.message)

    def to_dict(self) -> Dict[str, Optional[str]]:
        """转换为字典格式"""
        return {
            "error": self.__class__.__name__,
            "message": self.message,
            "code": self.code,
        }


class ChuanglanAuthError(ChuanglanError):
    """认证错误

    当账号、密码错误或账户状态异常时抛出
    """

    ERROR_CODES = {
        "101": "无此用户名",
        "102": "密码错误",
        "103": "账户已冻结",
        "104": "账户已过期",
        "105": "账户已停用",
    }

    def __init__(self, code: str, message: Optional[str] = None):
        if message is None:
            message = self.ERROR_CODES.get(code, "认证失败")
        super().__init__(message, code)


class ChuanglanApiError(ChuanglanError):
    """API 调用错误

    当 API 请求失败时抛出
    """

    ERROR_CODES = {
        "201": "参数错误",
        "202": "手机号格式错误",
        "203": "短信内容为空",
        "204": "模板 ID 不存在",
        "205": "模板未审核",
        "206": "签名格式错误",
        "301": "系统异常",
        "302": "系统繁忙",
        "401": "流量控制",
        "402": "发送频率过高",
        "106": "账户余额不足",
    }

    def __init__(self, code: str, message: Optional[str] = None):
        if message is None:
            message = self.ERROR_CODES.get(code, f"API 错误：{code}")
        super().__init__(message, code)


class ChuanglanValidationError(ChuanglanError):
    """参数验证错误

    当输入参数验证失败时抛出
    """

    def __init__(self, field: str, message: str):
        self.field = field
        super().__init__(f"{field}: {message}", "VALIDATION_ERROR")

    def to_dict(self) -> Dict[str, Optional[str]]:
        """转换为字典格式"""
        result = super().to_dict()
        result["field"] = self.field
        return result


class ChuanglanNetworkError(ChuanglanError):
    """网络错误

    当网络请求失败时抛出
    """

    def __init__(self, message: str, original_error: Optional[Exception] = None):
        self.original_error = original_error
        super().__init__(f"网络错误：{message}", "NETWORK_ERROR")


class ChuanglanTimeoutError(ChuanglanError):
    """超时错误

    当请求超时时抛出
    """

    def __init__(self, timeout: int):
        super().__init__(f"请求超时（{timeout}秒）", "TIMEOUT_ERROR")
