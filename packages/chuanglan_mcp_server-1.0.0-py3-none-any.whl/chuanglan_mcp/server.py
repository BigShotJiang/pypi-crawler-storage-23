"""
MCP 服务器模块

基于 FastMCP 框架构建 MCP 服务器
提供短信发送、余额查询、状态查询等工具
"""

import logging
from typing import Optional, Dict

from fastmcp import FastMCP

# 支持相对导入和绝对导入两种模式
try:
    from .client import ChuanglanClient
    from .config import Settings, settings
    from .models import SmsSendRequest, SmsStatusRequest
    from .exceptions import ChuanglanError
except ImportError:
    from client import ChuanglanClient
    from config import Settings, settings
    from models import SmsSendRequest, SmsStatusRequest
    from exceptions import ChuanglanError

# 配置日志
logging.basicConfig(
    level=getattr(logging, settings.log_level),
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)
logger = logging.getLogger(__name__)

# 初始化 MCP 服务器
mcp = FastMCP(
    name="chuanglan-mcp",
    version="1.0.0"
)

# 全局客户端实例
_client: Optional[ChuanglanClient] = None


def get_client() -> ChuanglanClient:
    """
    获取全局 API 客户端实例（单例模式）

    Returns:
        ChuanglanClient: API 客户端实例
    """
    global _client
    if _client is None:
        _client = ChuanglanClient(settings)
        logger.info("ChuanglanClient initialized")
    return _client


@mcp.tool()
async def send_template_sms(
    phone: str,
    template_id: str,
    params: Optional[Dict[str, str]] = None,
    extend: Optional[str] = None,
    batch_id: Optional[str] = None,
) -> dict:
    """
    发送模板短信

    使用预设模板发送短信，支持变量替换。
    模板需要在创蓝平台提前创建并审核通过。

    Args:
        phone: 接收手机号，支持单个手机号或逗号分隔的多个手机号
        template_id: 模板 ID，需在创蓝平台提前创建并审核通过
        params: 模板变量参数，如：{"code": "123456"}
        extend: 扩展码，可选
        batch_id: 批次 ID，可选

    Returns:
        dict: 发送结果，包含 code、msg、task_id、success 字段

    Example:
        ```python
        result = await send_template_sms(
            phone="13800138000",
            template_id="TD20240101001",
            params={"code": "123456", "expire": "5"}
        )
        # 返回：{"code": "0", "msg": "发送成功", "task_id": "xxx", "success": true}
        ```
    """
    logger.info(f"Tool call: send_template_sms, phone: {phone}, template_id: {template_id}")

    try:
        # 验证参数
        request = SmsSendRequest(
            phone=phone,
            template_id=template_id,
            params=params,
            extend=extend,
            batch_id=batch_id,
        )

        client = get_client()
        result = await client.send_template_sms(
            phone=request.phone,
            template_id=request.template_id,
            params=request.params,
            extend=request.extend,
            batch_id=request.batch_id,
        )

        logger.info(f"SMS sent successfully, task_id: {result.task_id}")
        return result.model_dump()

    except ValueError as e:
        logger.error(f"Validation error: {e}")
        return {"code": "VALIDATION_ERROR", "msg": str(e), "success": False}

    except ChuanglanError as e:
        logger.error(f"Chuanglan error: {e}")
        return e.to_dict() | {"success": False}

    except Exception as e:
        logger.error(f"Unexpected error: {e}", exc_info=True)
        return {"code": "UNKNOWN_ERROR", "msg": f"发送失败：{str(e)}", "success": False}


@mcp.tool()
async def query_balance() -> dict:
    """
    查询账户余额

    查看当前账户剩余金额。

    Returns:
        dict: 查询结果，包含 code、msg、balance、success 字段

    Example:
        ```python
        result = await query_balance()
        # 返回：{"code": "0", "msg": "查询成功", "balance": 1000.50, "success": true}
        ```
    """
    logger.info("Tool call: query_balance")

    try:
        client = get_client()
        result = await client.query_balance()

        logger.info(f"Balance queried successfully: {result.balance}")
        return result.model_dump()

    except ChuanglanError as e:
        logger.error(f"Chuanglan error: {e}")
        return e.to_dict() | {"success": False}

    except Exception as e:
        logger.error(f"Unexpected error: {e}", exc_info=True)
        return {"code": "UNKNOWN_ERROR", "msg": f"查询失败：{str(e)}", "success": False}


@mcp.tool()
async def query_status(
    task_id: str,
    start_time: Optional[str] = None,
    end_time: Optional[str] = None,
    page: int = 1,
    page_size: int = 50,
) -> dict:
    """
    查询短信发送状态

    查看短信是否成功送达，支持按时间范围查询。

    Args:
        task_id: 任务 ID，发送短信时返回
        start_time: 开始时间，格式：yyyy-MM-dd HH:mm:ss
        end_time: 结束时间，格式：yyyy-MM-dd HH:mm:ss
        page: 页码，默认 1
        page_size: 每页数量，默认 50

    Returns:
        dict: 查询结果，包含 code、msg、statuses、total、page、page_size、success 字段

    Example:
        ```python
        result = await query_status(
            task_id="xxx",
            start_time="2024-01-01 00:00:00",
            end_time="2024-01-01 23:59:59"
        )
        # 返回：{"code": "0", "msg": "查询成功", "statuses": [...], "success": true}
        ```
    """
    logger.info(f"Tool call: query_status, task_id: {task_id}")

    try:
        # 验证参数
        request = SmsStatusRequest(
            task_id=task_id,
            start_time=start_time,
            end_time=end_time,
            page=page,
            page_size=page_size,
        )

        client = get_client()
        result = await client.query_status(
            task_id=request.task_id,
            start_time=request.start_time,
            end_time=request.end_time,
            page=request.page,
            page_size=request.page_size,
        )

        logger.info(f"Status queried successfully, total: {result.total}")
        return result.model_dump()

    except ValueError as e:
        logger.error(f"Validation error: {e}")
        return {"code": "VALIDATION_ERROR", "msg": str(e), "success": False}

    except ChuanglanError as e:
        logger.error(f"Chuanglan error: {e}")
        return e.to_dict() | {"success": False}

    except Exception as e:
        logger.error(f"Unexpected error: {e}", exc_info=True)
        return {"code": "UNKNOWN_ERROR", "msg": f"查询失败：{str(e)}", "success": False}


@mcp.tool()
async def send_normal_sms(
    phone: str,
    content: str,
    sign: Optional[str] = None,
) -> dict:
    """
    发送普通短信（兼容模式）

    直接发送短信内容，不依赖模板。
    注意：推荐使用 send_template_sms 以获得更好的效果。

    Args:
        phone: 接收手机号
        content: 短信内容
        sign: 短信签名，可选

    Returns:
        dict: 发送结果

    Example:
        ```python
        result = await send_normal_sms(
            phone="13800138000",
            content="您的验证码是 123456",
            sign="【公司名称】"
        )
        ```
    """
    logger.info(f"Tool call: send_normal_sms, phone: {phone}")

    # 普通短信通过模板短信接口发送，content 作为参数
    return await send_template_sms(
        phone=phone,
        template_id="DEFAULT",
        params={"content": content, "sign": sign} if sign else {"content": content},
    )


def main() -> None:
    """
    启动 MCP 服务器

    验证配置并启动 FastMCP 服务器。
    """
    import sys

    # 验证配置
    if not settings.chuanglan_account or not settings.chuanglan_password:
        print(
            "错误：请设置 CHUANGLAN_ACCOUNT 和 CHUANGLAN_PASSWORD 环境变量",
            file=sys.stderr,
        )
        print("可以通过 .env 文件或环境变量设置", file=sys.stderr)
        sys.exit(1)

    logger.info(f"Starting Chuanglan MCP Server v{mcp.version}")
    logger.info(f"Account: {settings.chuanglan_account[:4]}****")

    # 运行服务器
    mcp.run()


if __name__ == "__main__":
    main()
