"""
数据模型模块

使用 Pydantic 定义数据结构，提供自动验证和序列化
"""

from datetime import datetime
from typing import Optional, Dict, List

from pydantic import BaseModel, Field, validator, ConfigDict


class SmsSendRequest(BaseModel):
    """短信发送请求模型"""

    model_config = ConfigDict(extra="forbid")

    phone: str = Field(
        ...,
        description="接收手机号，支持单个手机号或逗号分隔的多个手机号",
        min_length=11,
        max_length=200,
    )
    template_id: str = Field(
        ...,
        description="模板 ID，需在创蓝平台提前创建并审核通过",
        min_length=1,
        max_length=50,
    )
    params: Optional[Dict[str, str]] = Field(
        default=None,
        description="模板变量参数，如：{'code': '123456'}",
    )
    extend: Optional[str] = Field(
        default=None,
        description="扩展码，可选",
        max_length=20,
    )
    batch_id: Optional[str] = Field(
        default=None,
        description="批次 ID，可选",
        max_length=50,
    )

    @validator("phone")
    @classmethod
    def validate_phone(cls, v: str) -> str:
        """验证手机号格式"""
        # 支持单个手机号或多个手机号（逗号分隔）
        phones = [p.strip() for p in v.split(",")]
        for phone in phones:
            if not phone.isdigit():
                raise ValueError("手机号必须全为数字")
            if len(phone) < 11 or len(phone) > 15:
                raise ValueError(f"手机号格式错误：{phone}")
        return v


class SmsStatusRequest(BaseModel):
    """短信状态查询请求模型"""

    model_config = ConfigDict(extra="forbid")

    task_id: str = Field(
        ...,
        description="任务 ID，发送短信时返回",
    )
    start_time: Optional[str] = Field(
        default=None,
        description="开始时间，格式：yyyy-MM-dd HH:mm:ss",
    )
    end_time: Optional[str] = Field(
        default=None,
        description="结束时间，格式：yyyy-MM-dd HH:mm:ss",
    )
    page: int = Field(
        default=1,
        description="页码，默认 1",
        ge=1,
        le=1000,
    )
    page_size: int = Field(
        default=50,
        description="每页数量，默认 50",
        ge=1,
        le=100,
    )

    @validator("start_time", "end_time")
    @classmethod
    def validate_datetime(cls, v: str | None) -> str | None:
        """验证时间格式"""
        if v is None:
            return v
        try:
            datetime.strptime(v, "%Y-%m-%d %H:%M:%S")
        except ValueError:
            raise ValueError("时间格式错误，应为：yyyy-MM-dd HH:mm:ss")
        return v


class SmsResponse(BaseModel):
    """短信发送响应模型"""

    model_config = ConfigDict(from_attributes=True)

    code: str = Field(..., description="返回码")
    msg: str = Field(..., description="返回消息")
    task_id: Optional[str] = Field(default=None, description="任务 ID")
    success: bool = Field(default=False, description="是否成功")

    @validator("success", pre=True)
    @classmethod
    def set_success(cls, v: bool, values: dict) -> bool:
        """根据返回码自动设置成功状态"""
        if v is not None:
            return v
        return values.get("code") == "0"


class BalanceResponse(BaseModel):
    """余额查询响应模型"""

    model_config = ConfigDict(from_attributes=True)

    code: str = Field(..., description="返回码")
    msg: str = Field(..., description="返回消息")
    balance: Optional[float] = Field(default=None, description="账户余额")
    success: bool = Field(default=False, description="是否成功")

    @validator("success", pre=True)
    @classmethod
    def set_success(cls, v: bool, values: dict) -> bool:
        """根据返回码自动设置成功状态"""
        if v is not None:
            return v
        return values.get("code") == "0"


class StatusItem(BaseModel):
    """单条短信状态"""

    model_config = ConfigDict(from_attributes=True)

    phone: str = Field(..., description="手机号")
    status: str = Field(..., description="发送状态")
    send_time: Optional[str] = Field(default=None, description="发送时间")
    receive_time: Optional[str] = Field(default=None, description="接收时间")
    report_status: Optional[str] = Field(default=None, description="报告状态")


class StatusResponse(BaseModel):
    """状态查询响应模型"""

    model_config = ConfigDict(from_attributes=True)

    code: str = Field(..., description="返回码")
    msg: str = Field(..., description="返回消息")
    statuses: List[StatusItem] = Field(default_factory=list, description="状态列表")
    total: int = Field(default=0, description="总数")
    page: int = Field(default=1, description="当前页码")
    page_size: int = Field(default=50, description="每页数量")
    success: bool = Field(default=False, description="是否成功")

    @validator("success", pre=True)
    @classmethod
    def set_success(cls, v: bool, values: dict) -> bool:
        """根据返回码自动设置成功状态"""
        if v is not None:
            return v
        return values.get("code") == "0"


class APIResponse(BaseModel):
    """通用 API 响应模型"""

    model_config = ConfigDict(from_attributes=True)

    success: bool = Field(..., description="是否成功")
    data: Optional[Dict] = Field(default=None, description="响应数据")
    error: Optional[str] = Field(default=None, description="错误信息")
    code: Optional[str] = Field(default=None, description="错误码")
