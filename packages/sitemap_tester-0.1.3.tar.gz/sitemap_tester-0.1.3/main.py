import requests
from bs4 import BeautifulSoup
import argparse, sys

class SitemapTester:

    def extract_sitemap(self,url_sitemap):
        ans=requests.get(url_sitemap)
        data=BeautifulSoup(ans.content,"xml")
        return data

    def extract_urls(self,data,key_locator):
        urls=[loc.text for loc in data.find_all(key_locator)]
        return urls

    def analyze_urls(self,urls):
        print(f"Analyzing {len(urls)} URLs....")
        error=0
        canonical_error=0
        counter=0
        for url in urls:
            try:
                counter+=1
                response=requests.get(url,allow_redirects=True,timeout=5)
                content=f"{counter} {url} : response_code:{response.status_code} "
                if response.status_code!=200:
                    error+=1
                if response.url != url:
                    content+=f"Redirected from {url} to {response.url}"
                soup=BeautifulSoup(response.content,"lxml")
                tag = soup.find_all("link", rel="canonical")
                if len(tag)>1:
                    content+=f"Canonical : {len(tag)}"
                    canonical_error+=1
                elif len(tag)==0:
                    content+=f"Canonical : {len(tag)}"
                    canonical_error+=1
                else:
                    canonical_error+= canonical_error+1 if tag[0].get('href')!=url else 0
                    content+=f"Canonical : {tag[0].get('href')==url}"
                print(content)
            except Exception as e:
                print(f"Error analyzing {url}: {e}")
                error+=1
        print(f"Total status errors: {error}")
        print(f"Total canonical errors: {canonical_error}")

def main():
    parser = argparse.ArgumentParser(description='Sitemap Tester: Analyze SEO, CANONICAL URLS')
    parser.add_argument('url_sitemap', help='Enter the URL of the sitemap')
    parser.add_argument('--key_locator',default='loc', help='Enter the key locator for the URLs')
    args=parser.parse_args()
    url_sitemap=args.url_sitemap
    key_locator=args.key_locator
    testers=SitemapTester()
    data = testers.extract_sitemap(url_sitemap)
    urls=testers.extract_urls(data,key_locator)
    testers.analyze_urls(urls)

if __name__ == "__main__":
    main()

