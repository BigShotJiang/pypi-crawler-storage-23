# Sitemap Tester 🔍

[![PyPI version](https://img.shields.io/pypi/v/sitemap-tester.svg)](https://pypi.org/project/sitemap-tester/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

A lightweight, high-speed terminal utility to audit XML sitemaps. It checks every URL for HTTP status codes, redirects, and canonical tag accuracy.

## 🌟 Features

- **Automated Crawling**: Extracts all URLs from any standard XML sitemap.
- **Status Checker**: Identifies broken links (404), server errors (500), and redirects (301/302).
- **Canonical Validation**: 
    - Detects missing canonical tags.
    - Flags pages with multiple canonical tags.
    - Verifies if the canonical URL matches the sitemap URL (Self-referential check).
- **Modern Tech**: Built with `uv`, `requests`, and `BeautifulSoup4`.

## 📦 Installation

Install directly from PyPI:

    pip install sitemap-tester

Or using uv:

    uv tool install sitemap-tester

## 🚀 Usage

Once installed, you can run the tool from anywhere in your terminal using the `sitemap-tester` command:

### Basic Check

    sitemap-tester https://example.com/sitemap.xml

### Using a Custom Tag

If your sitemap uses a tag other than `<loc>` for URLs, you can specify it:

    sitemap-tester https://example.com/sitemap.xml --key url

## 📊 Example Output

    🚀 Analyzing 54 URLs....

    1. https://example.com/ | Status: 200 | Canonical Match: ✅
    2. https://example.com/about | Status: 200 | Canonical Match: ✅
    3. https://example.com/old-page | Status: 301 | Redirected to https://example.com/new-page | Canonical Match: ❌

    ========================================
    Total status errors: 1
    Total canonical errors: 1
    ========================================

## 🛠️ Development

To contribute or run locally:

1. Clone the repo: `git clone https://github.com/Mayank170906/sitemap-tester.git`
2. Install dependencies: `uv sync`
3. Run tests: `uv run sitemap-tester [URL]`

## 📄 License

This project is licensed under the MIT License.