import esphome.config_validation as cv

CONFIG_SCHEMA = cv.invalid(
    "The bmp581 sensor component has been renamed to bmp581_i2c."
)
