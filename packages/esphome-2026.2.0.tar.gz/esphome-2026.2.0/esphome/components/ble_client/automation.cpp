#ifdef USE_ESP32

#include "automation.h"

namespace esphome::ble_client {

const char *const Automation::TAG = "ble_client.automation";

}  // namespace esphome::ble_client

#endif
