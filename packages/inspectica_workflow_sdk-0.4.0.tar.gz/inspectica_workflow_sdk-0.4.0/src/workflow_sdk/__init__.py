# Workflow SDK - Python Worker for Workflows and Activities
#
# Usage:
#   from workflow_sdk import Worker, workflow, activity
#
#   @activity.defn
#   async def say_hello(input_data: dict) -> dict:
#       return {"message": f"Hello, {input_data.get('name', 'World')}!"}
#
#   @workflow.defn
#   class HelloWorldWorkflow:
#       @workflow.run
#       async def run(self, input_data: dict) -> dict:
#           return await workflow.execute_activity(say_hello, input_data)
#
#   worker = Worker(
#       server_url="http://localhost:8080",
#       api_key="wk_your_key",
#       task_queue="default",
#   )
#   worker.register(workflows=[HelloWorldWorkflow], activities=[say_hello])
#   worker.run()

from workflow_sdk.worker import Worker, ActivityTask, ActivityResult
from workflow_sdk import decorators as activity
from workflow_sdk import workflow as workflow

__all__ = ["Worker", "ActivityTask", "ActivityResult", "activity", "workflow"]
__version__ = "0.1.0"
