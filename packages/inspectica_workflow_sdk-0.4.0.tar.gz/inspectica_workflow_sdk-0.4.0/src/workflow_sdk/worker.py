"""Worker - Python implementation for executing workflows and activities."""

import asyncio
import inspect
import json
import logging
import signal
import socket
import traceback
from datetime import datetime, timezone
from typing import Any, Callable

import aiohttp
from aiokafka import AIOKafkaConsumer, AIOKafkaProducer
from aiokafka.errors import KafkaConnectionError
from pydantic import BaseModel

logger = logging.getLogger(__name__)


class CompletedActivity(BaseModel):
    """Completed activity from previous execution (for resume/replay)."""

    index: int
    name: str
    output: Any | None = None
    is_remote: bool = False


class WorkflowTask(BaseModel):
    """Workflow task received from the workflow server."""

    task_id: str
    workflow_id: str
    workflow_name: str
    input: Any
    timeout_ms: int = 300000
    created_at: str
    # Resume data (optional, present when resuming a failed workflow)
    completed_activities: list[CompletedActivity] | None = None
    # Metadata passed to workflow context (e.g., access_token for authorization)
    metadata: dict[str, Any] | None = None


class ActivityTask(BaseModel):
    """Activity task received from the workflow server."""

    task_id: str
    workflow_id: str
    activity_name: str
    activity_index: int
    input: Any
    fan_out_index: int | None = None
    fan_out_total: int | None = None
    timeout_ms: int = 60000
    retry_count: int = 0
    created_at: str
    # Cross-worker routing fields
    requester_worker_id: str | None = None
    correlation_id: str | None = None


class WorkflowResult(BaseModel):
    """Workflow result to send back to the workflow server."""

    task_id: str
    workflow_id: str
    workflow_name: str
    status: str  # "completed" or "failed"
    output: Any | None = None
    error: "WorkflowResultError | None" = None
    started_at: str
    completed_at: str
    duration_ms: int
    worker_id: str


class WorkflowResultError(BaseModel):
    """Error details for failed workflow."""

    type: str
    message: str
    stack_trace: str | None = None


class ActivityResultError(BaseModel):
    """Error details for failed activity."""

    type: str
    message: str
    stack_trace: str | None = None


class ActivityResult(BaseModel):
    """Activity result to send back to the workflow server."""

    task_id: str
    workflow_id: str
    activity_name: str
    activity_index: int
    fan_out_index: int | None = None
    status: str  # "completed" or "failed"
    output: Any | None = None
    error: ActivityResultError | None = None
    started_at: str
    completed_at: str
    duration_ms: int
    worker_id: str
    # Cross-worker routing fields
    requester_worker_id: str | None = None
    correlation_id: str | None = None


def _create_static_credential_provider(access_key: str, secret_key: str):
    """Create a static credential provider that inherits from botocore.credentials.CredentialProvider."""
    from botocore.credentials import CredentialProvider, Credentials

    class StaticCredentialProvider(CredentialProvider):
        METHOD = "static"

        def __init__(self):
            self._access_key = access_key
            self._secret_key = secret_key

        def load(self):
            return Credentials(self._access_key, self._secret_key)

    return StaticCredentialProvider()


def _create_msk_token_provider(region: str, access_key_id: str, secret_access_key: str):
    """Create an MSK token provider that properly inherits from AbstractTokenProvider."""
    from aiokafka.abc import AbstractTokenProvider
    from aws_msk_iam_sasl_signer import MSKAuthTokenProvider

    class MSKTokenProvider(AbstractTokenProvider):
        """Token provider for AWS MSK IAM authentication."""

        async def token(self) -> str:
            credential_provider = _create_static_credential_provider(
                access_key_id,
                secret_access_key,
            )
            token, _ = MSKAuthTokenProvider.generate_auth_token_from_credentials_provider(
                region,
                credential_provider,
            )
            return token

    return MSKTokenProvider()


class Worker:
    """
    Worker that executes workflows and activities.

    Usage:
        from workflow_sdk import Worker, workflow, activity

        @activity.defn
        async def say_hello(input_data: dict) -> dict:
            name = input_data.get("name", "World")
            return {"message": f"Hello, {name}!"}

        @workflow.defn
        class HelloWorldWorkflow:
            @workflow.run
            async def run(self, input_data: dict) -> dict:
                result = await workflow.execute_activity(
                    say_hello,
                    {"name": input_data.get("name")},
                )
                return result

        worker = Worker(
            server_url="https://workflow.example.com",
            api_key="wk_your_worker_api_key",  # Worker API key from server UI
        )
        worker.register(workflows=[HelloWorldWorkflow], activities=[say_hello])
        worker.run()
    """

    def __init__(
        self,
        server_url: str,
        api_key: str,
        group_id: str | None = None,
        max_concurrent_workflows: int = 10,
    ):
        self.server_url = server_url.rstrip("/")
        self.api_key = api_key
        self.group_id = group_id
        self.max_concurrent_workflows = max_concurrent_workflows

        # Runtime state
        self.worker_id: str | None = None
        self.instance_id: str | None = None
        self.workflows: dict[str, type] = {}
        self.activities: dict[str, Callable] = {}
        self._running = False
        self._consumer: AIOKafkaConsumer | None = None
        self._producer: AIOKafkaProducer | None = None
        self._heartbeat_task: asyncio.Task | None = None
        self._heartbeat_interval_ms = 30000
        
        # Workflow concurrency control - prevents OOM from too many in-flight workflows
        self._workflow_semaphore: asyncio.Semaphore | None = None
        
        self._result_topic: str | None = None
        self._needs_reconnect = False
        self._kafka_config: dict[str, Any] | None = None
        self._worker_topic: str | None = None

    def register(
        self,
        workflows: list[type] | None = None,
        activities: list[Callable] | None = None,
    ) -> None:
        """Register workflows and activities."""
        for wf_cls in workflows or []:
            wf_name = getattr(wf_cls, "__workflow_name__", wf_cls.__name__)
            self.workflows[wf_name] = wf_cls

        for activity_fn in activities or []:
            activity_name = getattr(activity_fn, "__activity_name__", activity_fn.__name__)
            self.activities[activity_name] = activity_fn

    def run(self) -> None:
        """Start the worker (blocking)."""
        asyncio.run(self._run_async())

    def _format_connection_error(self, status: int, error_text: str) -> str:
        """Format a user-friendly connection error message."""
        if status == 401:
            return f"Invalid or expired API key. Please check your worker API key."
        elif status == 403:
            return f"API key does not have permission to connect. Please check worker permissions."
        elif status == 404:
            return f"Server endpoint not found. Please check the server URL."
        elif status >= 500:
            return f"Server error (HTTP {status}). The server may be temporarily unavailable."
        else:
            return f"HTTP {status} - {error_text}"

    async def _connect_to_server_once(self) -> dict[str, Any]:
        """Attempt a single connection to the workflow server."""
        hostname = socket.gethostname()
        
        connect_payload = {
            "workflows": list(self.workflows.keys()),
            "activities": list(self.activities.keys()),
            "hostname": hostname,
        }

        async with aiohttp.ClientSession() as session:
            async with session.post(
                f"{self.server_url}/workflow/api/v1/workers/connect",
                json=connect_payload,
                headers={"Authorization": f"Bearer {self.api_key}"},
            ) as resp:
                if resp.status != 200:
                    error = await resp.text()
                    error_msg = self._format_connection_error(resp.status, error)
                    raise RuntimeError(
                        f"Failed to connect to {self.server_url}: {error_msg}"
                    )
                
                data = await resp.json()
                
        self.worker_id = data["worker_id"]
        self.instance_id = data["instance_id"]
        self._heartbeat_interval_ms = data.get("heartbeat_interval_ms", 30000)
        
        logger.info(f"Connected to server as worker_id={self.worker_id}, instance_id={self.instance_id}")
        
        return data["kafka"]

    async def _connect_to_server(self) -> dict[str, Any]:
        """Connect to workflow server with exponential backoff retry."""
        retry_interval = 1.0  # Start at 1 second
        max_retry_interval = 600.0  # Max 10 minutes
        backoff_multiplier = 2.0
        
        while self._running:
            try:
                return await self._connect_to_server_once()
            except Exception as e:
                error_msg = str(e)
                # Don't retry on auth errors - they won't resolve without user action
                if "Invalid or expired API key" in error_msg or "does not have permission" in error_msg:
                    logger.error(f"Worker failed to start: {error_msg}")
                    raise
                
                logger.warning(
                    f"Connection failed: {error_msg}. Retrying in {retry_interval:.0f}s..."
                )
                await asyncio.sleep(retry_interval)
                retry_interval = min(retry_interval * backoff_multiplier, max_retry_interval)
        
        raise RuntimeError("Worker stopped before connection could be established")

    async def _send_heartbeat(self) -> None:
        """Send periodic heartbeats to the server with reconnection on failure."""
        consecutive_failures = 0
        max_failures_before_reconnect = 3
        
        while self._running:
            try:
                await asyncio.sleep(self._heartbeat_interval_ms / 1000)
                if not self._running:
                    break
                    
                async with aiohttp.ClientSession() as session:
                    async with session.post(
                        f"{self.server_url}/workflow/api/v1/workers/heartbeat",
                        json={"instance_id": self.instance_id},
                        headers={"Authorization": f"Bearer {self.api_key}"},
                    ) as resp:
                        if resp.status == 200:
                            consecutive_failures = 0
                        elif resp.status == 401:
                            logger.error("Heartbeat failed: Invalid or expired API key")
                            consecutive_failures += 1
                        else:
                            logger.warning(f"Heartbeat failed: HTTP {resp.status}")
                            consecutive_failures += 1
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.warning(f"Heartbeat error: {e}")
                consecutive_failures += 1
            
            # Trigger reconnection if too many consecutive failures
            if consecutive_failures >= max_failures_before_reconnect:
                logger.warning(
                    f"Heartbeat failed {consecutive_failures} times consecutively. "
                    "Connection may be lost, triggering reconnection..."
                )
                self._needs_reconnect = True
                break

    async def _disconnect_from_server(self) -> None:
        """Notify server of disconnect."""
        if not self.instance_id:
            return

        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(
                    f"{self.server_url}/workflow/api/v1/workers/disconnect",
                    json={"instance_id": self.instance_id},
                    headers={"Authorization": f"Bearer {self.api_key}"},
                ) as resp:
                    if resp.status == 200:
                        logger.info("Disconnected from server")
        except Exception as e:
            logger.warning(f"Failed to disconnect from server: {e}")

    def _get_kafka_config(self, server_kafka_config: dict) -> dict[str, Any]:
        """Build Kafka client configuration from server response."""
        import ssl

        config: dict[str, Any] = {
            "bootstrap_servers": server_kafka_config["brokers"],
        }

        auth = server_kafka_config.get("auth", {})
        auth_type = auth.get("type", "plaintext")

        if auth_type == "msk_iam":
            config["security_protocol"] = "SASL_SSL"
            config["sasl_mechanism"] = "OAUTHBEARER"
            config["sasl_oauth_token_provider"] = _create_msk_token_provider(
                region=auth["region"],
                access_key_id=auth["access_key_id"],
                secret_access_key=auth["secret_access_key"],
            )
            config["ssl_context"] = ssl.create_default_context()

        elif auth_type == "sasl":
            security_protocol = auth.get("security_protocol", "SASL_SSL")
            config["security_protocol"] = security_protocol
            if "SSL" in security_protocol:
                config["ssl_context"] = ssl.create_default_context()
            if auth.get("sasl_mechanism"):
                config["sasl_mechanism"] = auth["sasl_mechanism"]
            if auth.get("sasl_username"):
                config["sasl_plain_username"] = auth["sasl_username"]
            if auth.get("sasl_password"):
                config["sasl_plain_password"] = auth["sasl_password"]

        return config

    def _is_kafka_connection_error(self, e: Exception) -> bool:
        """Check if an exception is a Kafka connection error that should trigger reconnection."""
        if isinstance(e, KafkaConnectionError):
            return True
        error_str = str(e).lower()
        return any(keyword in error_str for keyword in ["disconnected", "connection", "closed"])

    async def _run_async(self) -> None:
        """Async implementation of worker run loop with automatic reconnection."""
        self._running = True

        # Setup signal handlers
        loop = asyncio.get_event_loop()
        for sig in (signal.SIGINT, signal.SIGTERM):
            loop.add_signal_handler(sig, lambda: asyncio.create_task(self.stop()))

        while self._running:
            try:
                await self._connect_and_run()
            except Exception as e:
                if not self._running:
                    break
                # Check if it's an auth error that shouldn't be retried
                error_msg = str(e)
                if "Invalid or expired API key" in error_msg or "does not have permission" in error_msg:
                    logger.error(f"Worker stopped: {error_msg}")
                    break
                logger.error(f"Worker error: {e}. Will attempt to reconnect...")
                await self._cleanup_kafka()
                # Small delay before reconnection attempt
                await asyncio.sleep(5)

    async def _connect_and_run(self) -> None:
        """Connect to server and Kafka, then run the message loop."""
        self._needs_reconnect = False
        
        # Connect to server and get Kafka config
        server_kafka_config = await self._connect_to_server()
        worker_topic = server_kafka_config["worker_topic"]
        result_topic = server_kafka_config["result_topic"]
        self._result_topic = result_topic
        self._worker_topic = worker_topic

        kafka_config = self._get_kafka_config(server_kafka_config)
        self._kafka_config = kafka_config

        # Use provided group_id or default to worker_id-based group
        consumer_group_id = self.group_id or f"workflow-worker-{self.worker_id}"

        # Create consumer for tasks
        self._consumer = AIOKafkaConsumer(
            worker_topic,
            group_id=consumer_group_id,
            auto_offset_reset="earliest",
            enable_auto_commit=False,
            value_deserializer=lambda m: json.loads(m.decode("utf-8")),
            **kafka_config,
        )

        # Create producer
        self._producer = AIOKafkaProducer(
            value_serializer=lambda v: json.dumps(v).encode("utf-8"),
            **kafka_config,
        )

        try:
            await self._consumer.start()
            await self._producer.start()

            # Initialize workflow concurrency semaphore
            self._workflow_semaphore = asyncio.Semaphore(self.max_concurrent_workflows)

            workflows_str = ", ".join(self.workflows.keys()) if self.workflows else "(none)"
            activities_str = ", ".join(self.activities.keys()) if self.activities else "(none)"
            logger.info(f"Worker {self.worker_id} started, consuming from {worker_topic}")
            logger.info(f"Max concurrent workflows: {self.max_concurrent_workflows}")
            logger.info(f"Registered workflows: {workflows_str}")
            logger.info(f"Registered activities: {activities_str}")

            # Start heartbeat task
            self._heartbeat_task = asyncio.create_task(self._send_heartbeat())

            while self._running and not self._needs_reconnect:
                try:
                    # Acquire semaphore BEFORE fetching
                    if self._workflow_semaphore:
                        await self._workflow_semaphore.acquire()
                    
                    try:
                        msg = await asyncio.wait_for(
                            self._consumer.getone(),
                            timeout=1.0,
                        )
                        await self._consumer.commit()
                        asyncio.create_task(self._process_message_with_release(msg.value, result_topic))
                    except asyncio.TimeoutError:
                        if self._workflow_semaphore:
                            self._workflow_semaphore.release()
                        continue
                except Exception as e:
                    if self._running and not self._needs_reconnect:
                        logger.warning(f"Error processing message: {e}")
                    if self._workflow_semaphore:
                        self._workflow_semaphore.release()
                    # Check if this is a Kafka connection error

                    if self._is_kafka_connection_error(e):
                        logger.warning("Kafka connection lost, triggering reconnection...")
                        self._needs_reconnect = True
                        break

            if self._needs_reconnect:
                logger.info("Reconnecting to server and Kafka...")
        finally:
            await self._cleanup_kafka()

    async def _cleanup_kafka(self) -> None:
        """Clean up Kafka connections only (not full cleanup)."""
        if self._heartbeat_task:
            self._heartbeat_task.cancel()
            try:
                await self._heartbeat_task
            except asyncio.CancelledError:
                pass
            self._heartbeat_task = None

        if self._consumer:
            try:
                await self._consumer.stop()
            except Exception:
                pass
            self._consumer = None

        if self._producer:
            try:
                await self._producer.stop()
            except Exception:
                pass
            self._producer = None

    async def _process_message_with_release(self, data: dict, result_topic: str) -> None:
        """Process a message and release semaphore when done."""
        try:
            await self._process_message(data, result_topic)
        finally:
            if self._workflow_semaphore:
                self._workflow_semaphore.release()
                logger.debug("Released worker slot after message processing")

    async def _process_message(self, data: dict, result_topic: str) -> None:
        """Process a task message (workflow, activity, or activity result)."""
        # Check if this is an activity result (response from another worker via server)
        # Activity results have 'status' and 'completed_at' fields but no 'task_type'
        if "status" in data and "completed_at" in data and "task_type" not in data:
            # This is an ActivityResult routed back from the server
            # Currently we use polling, so just log and ignore
            logger.debug(f"Received activity result on worker topic (ignored - using polling): {data.get('activity_name')}")
            return

        task_type = data.get("task_type", "activity")

        if task_type == "workflow":
            await self._process_workflow_task(data, result_topic)
        else:
            await self._process_activity_task(data, result_topic)

    async def _process_workflow_task(self, data: dict, result_topic: str) -> None:
        """Process a workflow task (semaphore already acquired at worker level)."""
        from workflow_sdk.workflow import WorkflowContext, set_context

        try:
            task = WorkflowTask(**data)
        except Exception as e:
            logger.error(f"Failed to parse workflow task: {e}")
            return

        await self._execute_workflow(task, result_topic)

    async def _execute_workflow(self, task: WorkflowTask, result_topic: str) -> None:
        """Execute a workflow task (called after acquiring semaphore)."""
        from workflow_sdk.workflow import WorkflowContext, set_context

        logger.info(f"Received workflow task {task.task_id}: {task.workflow_name}")

        # Find the workflow class
        workflow_cls = self.workflows.get(task.workflow_name)
        if not workflow_cls:
            logger.warning(f"Unknown workflow: {task.workflow_name}")
            await self._send_workflow_result(
                task,
                result_topic,
                status="failed",
                error=WorkflowResultError(
                    type="UnknownWorkflow",
                    message=f"Workflow '{task.workflow_name}' not registered",
                ),
            )
            return

        # Find the run method
        run_method = None
        for name, method in inspect.getmembers(workflow_cls, predicate=inspect.isfunction):
            if getattr(method, "__is_workflow_run__", False):
                run_method = method
                break

        if not run_method:
            await self._send_workflow_result(
                task,
                result_topic,
                status="failed",
                error=WorkflowResultError(
                    type="NoRunMethod",
                    message=f"Workflow '{task.workflow_name}' has no @workflow.run method",
                ),
            )
            return

        # Execute the workflow
        started_at = datetime.now(timezone.utc)
        try:
            # Build completed activities map for replay (index -> output)
            completed_activities_map: dict[int, Any] = {}
            if task.completed_activities:
                for ca in task.completed_activities:
                    completed_activities_map[ca.index] = ca.output
                logger.info(
                    f"Resuming workflow {task.workflow_id} with {len(completed_activities_map)} completed activities"
                )

            # Create workflow context with activities, worker reference, replay data, and metadata
            ctx = WorkflowContext(
                self.activities,
                task.workflow_id,
                worker=self,
                completed_activities=completed_activities_map if completed_activities_map else None,
                metadata=task.metadata,
            )
            token = set_context(ctx)

            try:
                # Instantiate workflow and call run method
                workflow_instance = workflow_cls()
                if inspect.iscoroutinefunction(run_method):
                    output = await asyncio.wait_for(
                        run_method(workflow_instance, task.input),
                        timeout=task.timeout_ms / 1000,
                    )
                else:
                    output = run_method(workflow_instance, task.input)
            finally:
                set_context(None)

            completed_at = datetime.now(timezone.utc)
            duration_ms = int((completed_at - started_at).total_seconds() * 1000)

            logger.info(f"Workflow {task.task_id} completed in {duration_ms}ms")

            await self._send_workflow_result(
                task,
                result_topic,
                status="completed",
                output=output,
                started_at=started_at,
                completed_at=completed_at,
                duration_ms=duration_ms,
            )

        except asyncio.TimeoutError:
            completed_at = datetime.now(timezone.utc)
            duration_ms = int((completed_at - started_at).total_seconds() * 1000)

            logger.error(f"Workflow {task.task_id} timed out after {task.timeout_ms}ms")

            await self._send_workflow_result(
                task,
                result_topic,
                status="failed",
                error=WorkflowResultError(
                    type="Timeout",
                    message=f"Workflow timed out after {task.timeout_ms}ms",
                ),
                started_at=started_at,
                completed_at=completed_at,
                duration_ms=duration_ms,
            )

        except Exception as e:
            completed_at = datetime.now(timezone.utc)
            duration_ms = int((completed_at - started_at).total_seconds() * 1000)

            logger.exception(f"Workflow {task.task_id} failed: {e}")

            await self._send_workflow_result(
                task,
                result_topic,
                status="failed",
                error=WorkflowResultError(
                    type=type(e).__name__,
                    message=str(e),
                    stack_trace=traceback.format_exc(),
                ),
                started_at=started_at,
                completed_at=completed_at,
                duration_ms=duration_ms,
            )

    async def _process_activity_task(self, data: dict, result_topic: str) -> None:
        """Process an activity task."""
        try:
            task = ActivityTask(**data)
        except Exception as e:
            logger.error(f"Failed to parse activity task: {e}")
            return

        logger.info(
            f"Received activity task {task.task_id}: {task.activity_name} "
            f"(workflow={task.workflow_id})"
        )

        # Find the activity handler
        activity_fn = self.activities.get(task.activity_name)
        if not activity_fn:
            logger.warning(f"Unknown activity: {task.activity_name}")
            await self._send_activity_result(
                task,
                result_topic,
                status="failed",
                error=ActivityResultError(
                    type="UnknownActivity",
                    message=f"Activity '{task.activity_name}' not registered",
                ),
            )
            return

        # Execute the activity
        started_at = datetime.now(timezone.utc)
        try:
            # Call the activity function
            if inspect.iscoroutinefunction(activity_fn):
                output = await asyncio.wait_for(
                    activity_fn(task.input),
                    timeout=task.timeout_ms / 1000,
                )
            else:
                output = activity_fn(task.input)

            completed_at = datetime.now(timezone.utc)
            duration_ms = int((completed_at - started_at).total_seconds() * 1000)

            logger.info(f"Activity {task.task_id} completed in {duration_ms}ms")

            await self._send_activity_result(
                task,
                result_topic,
                status="completed",
                output=output,
                started_at=started_at,
                completed_at=completed_at,
                duration_ms=duration_ms,
            )

        except asyncio.TimeoutError:
            completed_at = datetime.now(timezone.utc)
            duration_ms = int((completed_at - started_at).total_seconds() * 1000)

            logger.error(f"Activity {task.task_id} timed out after {task.timeout_ms}ms")

            await self._send_activity_result(
                task,
                result_topic,
                status="failed",
                error=ActivityResultError(
                    type="Timeout",
                    message=f"Activity timed out after {task.timeout_ms}ms",
                ),
                started_at=started_at,
                completed_at=completed_at,
                duration_ms=duration_ms,
            )

        except Exception as e:
            completed_at = datetime.now(timezone.utc)
            duration_ms = int((completed_at - started_at).total_seconds() * 1000)

            logger.exception(f"Activity {task.task_id} failed: {e}")

            await self._send_activity_result(
                task,
                result_topic,
                status="failed",
                error=ActivityResultError(
                    type=type(e).__name__,
                    message=str(e),
                    stack_trace=traceback.format_exc(),
                ),
                started_at=started_at,
                completed_at=completed_at,
                duration_ms=duration_ms,
            )

    async def _report_workflow_error(
        self,
        workflow_id: str,
        error_type: str,
        error_message: str,
        activity_name: str = "",
        activity_index: int = 0,
        stack_trace: str | None = None,
    ) -> None:
        """
        Report a runtime error to the server for workflow state update.
        
        This is used for errors that occur outside of workflow/activity execution,
        such as connection errors, configuration issues, serialization errors, etc.
        The error is sent to the server so it can update the workflow state for UI visibility.
        """
        if not self._producer or not self._result_topic:
            logger.warning(f"Cannot report error to server - producer not initialized")
            return
        
        error_report = {
            "request_type": "workflow_error",
            "workflow_id": workflow_id,
            "error_type": error_type,
            "error_source": "worker",
            "message": error_message,
            "activity_name": activity_name,
            "activity_index": activity_index,
            "stack_trace": stack_trace,
            "worker_id": self.worker_id,
            "timestamp": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
        }
        
        try:
            await self._producer.send_and_wait(
                self._result_topic,
                value=error_report,
                key=workflow_id.encode("utf-8"),
            )
            logger.info(f"Reported error to server: workflow_id={workflow_id}, error_type={error_type}")
        except Exception as e:
            logger.error(f"Failed to report error to server: {e}")

    async def _report_local_activity_completion(
        self,
        workflow_id: str,
        activity_name: str,
        activity_index: int,
        output: Any,
        duration_ms: int = 0,
    ) -> None:
        """
        Report a local activity completion to the server for activity history tracking.
        
        This is needed so that on workflow resume, the server knows which activities
        were already completed and can send the completed_activities list to the worker.
        """
        if not self._producer or not self._result_topic:
            logger.debug("Cannot report local activity - producer not initialized")
            return
        
        from datetime import timedelta
        
        completed_at = datetime.now(timezone.utc)
        started_at = completed_at - timedelta(milliseconds=duration_ms)
        
        # Send as an ActivityResult with a special marker indicating it's from local execution
        result = {
            "task_id": f"local-{workflow_id}-{activity_index}",
            "workflow_id": workflow_id,
            "activity_name": activity_name,
            "activity_index": activity_index,
            "status": "completed",
            "output": output,
            "started_at": started_at.isoformat().replace("+00:00", "Z"),
            "completed_at": completed_at.isoformat().replace("+00:00", "Z"),
            "duration_ms": duration_ms,
            "worker_id": self.worker_id,
            # No requester_worker_id - this is a local activity, not cross-worker
        }
        
        try:
            await self._producer.send_and_wait(
                self._result_topic,
                value=result,
                key=workflow_id.encode("utf-8"),
            )
            logger.debug(
                f"Reported local activity completion: workflow_id={workflow_id}, "
                f"activity={activity_name}, index={activity_index}"
            )
        except Exception as e:
            logger.warning(f"Failed to report local activity completion: {e}")

    async def _report_local_activity_failure(
        self,
        workflow_id: str,
        activity_name: str,
        activity_index: int,
        error: str,
        error_type: str = "Exception",
        duration_ms: int = 0,
    ) -> None:
        """
        Report a local activity failure to the server for activity history tracking.
        """
        if not self._producer or not self._result_topic:
            logger.debug("Cannot report local activity failure - producer not initialized")
            return
        
        from datetime import timedelta
        
        completed_at = datetime.now(timezone.utc)
        started_at = completed_at - timedelta(milliseconds=duration_ms)
        
        # Send as an ActivityResult with failed status
        result = {
            "task_id": f"local-{workflow_id}-{activity_index}",
            "workflow_id": workflow_id,
            "activity_name": activity_name,
            "activity_index": activity_index,
            "status": "failed",
            "output": None,
            "error": {
                "type": error_type,
                "message": error,
            },
            "started_at": started_at.isoformat().replace("+00:00", "Z"),
            "completed_at": completed_at.isoformat().replace("+00:00", "Z"),
            "duration_ms": duration_ms,
            "worker_id": self.worker_id,
            # No requester_worker_id - this is a local activity, not cross-worker
        }
        
        try:
            await self._producer.send_and_wait(
                self._result_topic,
                value=result,
                key=workflow_id.encode("utf-8"),
            )
            logger.debug(
                f"Reported local activity failure: workflow_id={workflow_id}, "
                f"activity={activity_name}, index={activity_index}, error={error}"
            )
        except Exception as e:
            logger.warning(f"Failed to report local activity failure: {e}")

    async def _send_workflow_result(
        self,
        task: WorkflowTask,
        result_topic: str,
        status: str,
        output: Any = None,
        error: WorkflowResultError | None = None,
        started_at: datetime | None = None,
        completed_at: datetime | None = None,
        duration_ms: int = 0,
    ) -> None:
        """Send workflow result back to the workflow server."""
        now = datetime.now(timezone.utc)
        result = WorkflowResult(
            task_id=task.task_id,
            workflow_id=task.workflow_id,
            workflow_name=task.workflow_name,
            status=status,
            output=output,
            error=error,
            started_at=(started_at or now).isoformat().replace("+00:00", "Z"),
            completed_at=(completed_at or now).isoformat().replace("+00:00", "Z"),
            duration_ms=duration_ms,
            worker_id=self.worker_id,
        )

        if self._producer:
            await self._producer.send_and_wait(
                result_topic,
                value=result.model_dump(exclude_none=True),
                key=task.workflow_id.encode("utf-8"),
            )
            logger.debug(f"Sent workflow result for task {task.task_id}")

    async def _send_activity_result(
        self,
        task: ActivityTask,
        result_topic: str,
        status: str,
        output: Any = None,
        error: ActivityResultError | None = None,
        started_at: datetime | None = None,
        completed_at: datetime | None = None,
        duration_ms: int = 0,
    ) -> None:
        """Send activity result back to the workflow server."""
        now = datetime.now(timezone.utc)
        result = ActivityResult(
            task_id=task.task_id,
            workflow_id=task.workflow_id,
            activity_name=task.activity_name,
            activity_index=task.activity_index,
            fan_out_index=task.fan_out_index,
            status=status,
            output=output,
            error=error,
            started_at=(started_at or now).isoformat().replace("+00:00", "Z"),
            completed_at=(completed_at or now).isoformat().replace("+00:00", "Z"),
            duration_ms=duration_ms,
            worker_id=self.worker_id,
            # Include routing fields for cross-worker activity execution
            requester_worker_id=task.requester_worker_id,
            correlation_id=task.correlation_id,
        )

        if self._producer:
            await self._producer.send_and_wait(
                result_topic,
                value=result.model_dump(exclude_none=True),
                key=task.workflow_id.encode("utf-8"),
            )
            logger.debug(f"Sent activity result for task {task.task_id}")


    async def _cleanup(self) -> None:
        """Cleanup resources."""
        # Cancel heartbeat task
        if self._heartbeat_task:
            self._heartbeat_task.cancel()
            try:
                await self._heartbeat_task
            except asyncio.CancelledError:
                pass

        # Disconnect from server
        await self._disconnect_from_server()

        # Stop Kafka clients
        if self._consumer:
            await self._consumer.stop()
        if self._producer:
            await self._producer.stop()
        logger.info(f"Worker {self.worker_id} stopped")

    async def stop(self) -> None:
        """Stop the worker gracefully."""
        logger.info("Stopping worker...")
        self._running = False

    async def execute_remote_activity(
        self,
        workflow_id: str,
        activity_name: str,
        activity_index: int,
        input_data: Any,
        timeout_ms: int = 60000,
    ) -> Any:
        """
        Execute an activity via the server (cross-worker routing).
        
        This sends an ActivityRequest to the activity-results Kafka topic.
        The server receives it, routes to the appropriate worker, and
        the SDK polls the server for the result with exponential backoff.
        
        Args:
            workflow_id: The workflow ID
            activity_name: Name of the activity to execute
            activity_index: The activity index (from WorkflowContext)
            input_data: Input data for the activity
            timeout_ms: Timeout in milliseconds
        """
        import uuid
        import aiohttp
        from datetime import datetime, timezone

        # Send ActivityRequest to server via Kafka (activity-results topic)
        request_payload = {
            "request_type": "activity_request",
            "request_id": str(uuid.uuid4()),
            "workflow_id": workflow_id,
            "activity_name": activity_name,
            "activity_index": activity_index,
            "input": input_data,
            "timeout_ms": timeout_ms,
            "requester_worker_id": self.worker_id,
            "correlation_id": str(uuid.uuid4()),
            "created_at": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
        }

        try:
            if not self._producer:
                raise RuntimeError("Kafka producer not initialized")
            
            # Send to the result topic (server consumes from this)
            await self._producer.send_and_wait(
                self._result_topic,
                value=request_payload,
                key=workflow_id.encode("utf-8"),
            )
            
            logger.info(
                f"Activity request sent via Kafka: activity={activity_name}, "
                f"workflow_id={workflow_id}, activity_index={activity_index}"
            )

            # Poll server for result with exponential backoff
            # Start at 2 seconds, max 15 minutes (900 seconds)
            poll_interval = 2.0
            max_poll_interval = 900.0
            backoff_multiplier = 1.5
            start_time = datetime.now(timezone.utc)
            timeout_seconds = timeout_ms / 1000

            poll_url = f"{self.server_url}/workflow/api/v1/workflows/{workflow_id}/activities/{activity_index}/result"
            headers = {"Authorization": f"Bearer {self.api_key}"}

            async with aiohttp.ClientSession() as session:
                while True:
                    elapsed = (datetime.now(timezone.utc) - start_time).total_seconds()
                    if elapsed >= timeout_seconds:
                        error_msg = f"Activity {activity_name} timed out after {timeout_ms}ms"
                        await self._report_workflow_error(
                            workflow_id=workflow_id,
                            error_type="activity_timeout",
                            error_message=error_msg,
                            activity_name=activity_name,
                            activity_index=activity_index,
                        )
                        raise RuntimeError(error_msg)

                    try:
                        async with session.get(poll_url, headers=headers) as response:
                            if response.status == 200:
                                # Activity completed or failed
                                result = await response.json()
                                if result["status"] == "completed":
                                    logger.info(
                                        f"Activity {activity_name} completed for workflow {workflow_id}"
                                    )
                                    return result.get("output")
                                elif result["status"] == "failed":
                                    error_msg = result.get("error", "Activity failed")
                                    logger.error(
                                        f"Activity {activity_name} failed: {error_msg}"
                                    )
                                    raise RuntimeError(error_msg)
                            elif response.status == 202:
                                # Still pending/running, continue polling
                                logger.debug(
                                    f"Activity {activity_name} still running, "
                                    f"polling again in {poll_interval:.1f}s"
                                )
                            elif response.status == 404:
                                # Activity not found yet, might not be recorded
                                logger.debug(
                                    f"Activity {activity_name} not found yet, "
                                    f"polling again in {poll_interval:.1f}s"
                                )
                            else:
                                logger.warning(
                                    f"Unexpected response {response.status} when polling activity result"
                                )
                    except aiohttp.ClientError as e:
                        logger.warning(f"Error polling activity result: {e}")

                    # Wait with exponential backoff
                    await asyncio.sleep(poll_interval)
                    poll_interval = min(poll_interval * backoff_multiplier, max_poll_interval)

        except RuntimeError:
            raise
        except Exception as e:
            # Report error to server for workflow state update, then rethrow
            await self._report_workflow_error(
                workflow_id=workflow_id,
                error_type="runtime_error",
                error_message=str(e),
                activity_name=activity_name,
                activity_index=activity_index,
                stack_trace=traceback.format_exc(),
            )
            raise
