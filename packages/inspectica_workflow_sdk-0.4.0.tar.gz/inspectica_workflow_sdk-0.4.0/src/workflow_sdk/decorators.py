# Activity decorators

from typing import Callable, TypeVar

F = TypeVar("F", bound=Callable)
T = TypeVar("T")


def defn(fn: F) -> F:
    """
    Decorator to mark a function as an activity definition.
    
    Usage:
        from workflow_sdk import activity
        
        @activity.defn
        async def my_activity(item_id: str) -> dict:
            return {"processed": True}
    """
    fn.__activity_name__ = fn.__name__
    fn.__is_activity__ = True
    return fn


def name(activity_name: str) -> Callable[[F], F]:
    """
    Decorator to specify a custom activity name.
    
    Usage:
        @activity.defn
        @activity.name("custom_name")
        async def my_activity(item_id: str) -> dict:
            return {"processed": True}
    """
    def decorator(fn: F) -> F:
        fn.__activity_name__ = activity_name
        return fn
    return decorator
