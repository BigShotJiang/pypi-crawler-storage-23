# Workflow decorators and utilities

import contextvars
from typing import TYPE_CHECKING, Any, Callable, TypeVar

if TYPE_CHECKING:
    from workflow_sdk.worker import Worker

F = TypeVar("F", bound=Callable)
T = TypeVar("T", bound=type)

# Context variable to hold the current workflow execution context
_workflow_context: contextvars.ContextVar["WorkflowContext | None"] = contextvars.ContextVar(
    "_workflow_context", default=None
)


class WorkflowContext:
    """Context for workflow execution, holds activities and allows execute_activity calls."""

    def __init__(
        self,
        activities: dict[str, Callable],
        workflow_id: str,
        worker: "Worker | None" = None,
        completed_activities: dict[int, Any] | None = None,
        metadata: dict[str, Any] | None = None,
    ):
        self.activities = activities
        self.workflow_id = workflow_id
        self.worker = worker
        self.activity_results: list[Any] = []
        # For replay: map of activity_index -> cached output
        self._completed_activities = completed_activities or {}
        # Current activity index (incremented on each execute_activity call)
        self._current_activity_index = 0
        # Track if we're in replay mode
        self._is_replaying = bool(completed_activities)
        # Metadata from workflow submission (e.g., access_token for authorization)
        self.metadata = metadata or {}

    async def execute_activity(
        self,
        activity: Callable | str,
        input_data: Any = None,
        start_to_close_timeout_ms: int = 60000,
    ) -> Any:
        """Execute an activity and return its result.
        
        Args:
            activity: Either an activity function (decorated with @activity.defn)
                     or a string name of the activity for cross-worker calls.
            input_data: Input to pass to the activity.
            start_to_close_timeout_ms: Timeout for activity execution.
        """
        import logging
        logger = logging.getLogger(__name__)

        # Increment activity index for this call
        self._current_activity_index += 1
        current_index = self._current_activity_index

        # Check if this activity was already completed (replay mode)
        if current_index in self._completed_activities:
            cached_result = self._completed_activities[current_index]
            logger.info(
                f"Replay: Returning cached result for activity index {current_index}"
            )
            self.activity_results.append(cached_result)
            return cached_result

        # Support both function reference and string name
        if isinstance(activity, str):
            activity_name = activity
        else:
            activity_name = getattr(activity, "__activity_name__", activity.__name__)

        # Check if activity is registered locally
        if activity_name in self.activities:
            # Execute locally (in-process)
            activity_fn = self.activities[activity_name]
            import asyncio
            import inspect
            import time

            start_time = time.time()

            try:
                if inspect.iscoroutinefunction(activity_fn):
                    result = await asyncio.wait_for(
                        activity_fn(input_data),
                        timeout=start_to_close_timeout_ms / 1000,
                    )
                else:
                    result = activity_fn(input_data)

                duration_ms = int((time.time() - start_time) * 1000)

                # Report local activity completion to server for activity history tracking
                # This is needed so resume can replay completed activities
                if self.worker is not None:
                    await self.worker._report_local_activity_completion(
                        workflow_id=self.workflow_id,
                        activity_name=activity_name,
                        activity_index=current_index,
                        output=result,
                        duration_ms=duration_ms,
                    )

                self.activity_results.append(result)
                return result

            except Exception as e:
                duration_ms = int((time.time() - start_time) * 1000)

                # Report local activity failure to server for activity history tracking
                if self.worker is not None:
                    await self.worker._report_local_activity_failure(
                        workflow_id=self.workflow_id,
                        activity_name=activity_name,
                        activity_index=current_index,
                        error=str(e),
                        error_type=type(e).__name__,
                        duration_ms=duration_ms,
                    )

                raise  # Re-raise the exception

        # Activity not registered locally - route via server
        if self.worker is None:
            raise ValueError(
                f"Activity '{activity_name}' not registered locally and no worker available for remote execution"
            )

        # Execute remotely via server routing
        result = await self.worker.execute_remote_activity(
            workflow_id=self.workflow_id,
            activity_name=activity_name,
            activity_index=current_index,
            input_data=input_data,
            timeout_ms=start_to_close_timeout_ms,
        )

        self.activity_results.append(result)
        return result


def get_current_context() -> WorkflowContext:
    """Get the current workflow context."""
    ctx = _workflow_context.get()
    if ctx is None:
        raise RuntimeError("Not running inside a workflow context")
    return ctx


def set_context(ctx: WorkflowContext | None) -> contextvars.Token:
    """Set the current workflow context."""
    return _workflow_context.set(ctx)


def defn(cls: T) -> T:
    """
    Decorator to mark a class as a workflow definition.

    Usage:
        from workflow_sdk import workflow

        @workflow.defn
        class MyWorkflow:
            @workflow.run
            async def run(self, input_data: dict) -> dict:
                return {"result": "done"}
    """
    cls.__workflow_name__ = cls.__name__
    cls.__is_workflow__ = True
    return cls


def run(fn: F) -> F:
    """
    Decorator to mark a method as the workflow entry point.

    Usage:
        @workflow.defn
        class MyWorkflow:
            @workflow.run
            async def run(self, input_data: dict) -> dict:
                return {"result": "done"}
    """
    fn.__is_workflow_run__ = True
    return fn


async def execute_activity(
    activity: Callable | str,
    input_data: Any = None,
    start_to_close_timeout_ms: int = 60000,
) -> Any:
    """
    Execute an activity within a workflow.

    Args:
        activity: Either an activity function (decorated with @activity.defn)
                 or a string name of the activity for cross-worker calls.
        input_data: Input to pass to the activity.
        start_to_close_timeout_ms: Timeout for activity execution.

    Usage:
        # Option 1: Local activity (function reference)
        result = await workflow.execute_activity(my_activity, {"key": "value"})
        
        # Option 2: Remote activity (string name) - for cross-worker calls
        result = await workflow.execute_activity("say_count", {"message": "hi", "count": 1})
    """
    ctx = get_current_context()
    return await ctx.execute_activity(
        activity,
        input_data,
        start_to_close_timeout_ms,
    )
