import pandas as pd
from abc import ABC, abstractmethod

class FeatureStyleHere(ABC):


    def __init__(self, name=None):
        self.name = name or self.__class__.__name__

    @abstractmethod
    def fit(self, X: pd.DataFrame, y=None):
        pass

    @abstractmethod
    def transform(self, X: pd.DataFrame) -> pd.DataFrame:
        pass

    def fit_transform(self, X: pd.DataFrame, y=None) -> pd.DataFrame:
        return self.fit(X, y).transform(X)