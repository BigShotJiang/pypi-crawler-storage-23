class AivoraComponent:

    def fit(self, X, y=None):
        return self
    
    def transform(self, X):
        return X

    def fit_transform(self, X, y=None):
        
        self.fit(X, y)
        return self.transform(X)