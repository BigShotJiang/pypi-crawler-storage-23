class FeaturePipeline:

    def __init__(self, steps):

        self.steps = steps

    def fit(self, X, y=None):

        for name, step in self.steps:
            X = step.fit_transform(X, y)
        return self
    
    def transform(self, X):

        for name, step in self.steps:
            X = step.transform(X)

        return X
    
    def fit_transform(self, X, y=None):

        for name, step in self.steps:
            X = self.fit_transform(X, y)

        return X