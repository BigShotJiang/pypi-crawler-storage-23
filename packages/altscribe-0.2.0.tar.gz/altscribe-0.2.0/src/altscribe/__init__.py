"""altscribe — AI-powered image alt-text generator for documents via pandoc."""

__version__ = "0.1.1"
