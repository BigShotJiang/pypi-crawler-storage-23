"""MCP server for OrionBelt Semantic Layer."""

from orionbelt.mcp.server import mcp

__all__ = ["mcp"]
