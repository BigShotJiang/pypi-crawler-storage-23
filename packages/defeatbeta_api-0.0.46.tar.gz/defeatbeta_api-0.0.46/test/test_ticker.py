import logging
import unittest

from defeatbeta_api.data.ticker import Ticker

class TestTicker(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.ticker = Ticker("SHOP", http_proxy="http://127.0.0.1:8118", log_level=logging.DEBUG)

    @classmethod
    def tearDownClass(cls):
        result = cls.ticker.download_data_performance()
        print(result)

    def test_info(self):
        result = self.ticker.info()
        print(result.to_string())
        self.assertIn('symbol', result.columns)

    def test_sec_filing(self):
        result = self.ticker.sec_filing()
        print(result)
        self.assertIn('symbol', result.columns)

    def test_officers(self):
        result = self.ticker.officers()
        print(result.to_string())
        self.assertIn('symbol', result.columns)

    def test_calendar(self):
        result = self.ticker.calendar()
        print(result.to_string())
        self.assertIn('symbol', result.columns)

    def test_splits(self):
        result = self.ticker.splits()
        print(result.to_string())
        self.assertIn('symbol', result.columns)

    def test_dividends(self):
        result = self.ticker.dividends()
        print(result.to_string())
        self.assertIn('symbol', result.columns)

    def test_ttm_eps(self):
        result = self.ticker.ttm_eps()
        print(result.to_string(float_format="{:,}".format))
        self.assertIn('symbol', result.columns)

    def test_price(self):
        result = self.ticker.price()
        print(result)
        self.assertIn('symbol', result.columns)

    def _assert_row_meta(self, result):
        df = result.df()
        meta = result.row_meta
        self.assertEqual(len(meta), len(df), "row_meta length must match DataFrame row count")
        for i, m in enumerate(meta):
            self.assertIn("indent", m, f"row {i} missing 'indent'")
            self.assertIn("is_section", m, f"row {i} missing 'is_section'")
            self.assertIsInstance(m["indent"], int, f"row {i} indent must be int")
            self.assertIsInstance(m["is_section"], bool, f"row {i} is_section must be bool")
            self.assertGreaterEqual(m["indent"], 0, f"row {i} indent must be >= 0")
        has_section = any(m["is_section"] for m in meta)
        has_indent = any(m["indent"] > 0 for m in meta)
        self.assertTrue(has_section, "expected at least one section header row")
        self.assertTrue(has_indent, "expected at least one indented sub-item row")
        print(f"  row_meta sample (first 5): {meta[:5]}")

    def test_statement_1(self):
        result = self.ticker.quarterly_income_statement()
        result.print_pretty_table()
        print(result.df().to_string())
        self._assert_row_meta(result)

    def test_statement_2(self):
        result = self.ticker.annual_income_statement()
        result.print_pretty_table()
        print(result.df().to_string())
        self._assert_row_meta(result)

    def test_statement_3(self):
        result = self.ticker.quarterly_balance_sheet()
        result.print_pretty_table()
        print(result.df().to_string())
        self._assert_row_meta(result)

    def test_statement_4(self):
        result = self.ticker.annual_balance_sheet()
        result.print_pretty_table()
        print(result.df().to_string())
        self._assert_row_meta(result)

    def test_statement_5(self):
        result = self.ticker.quarterly_cash_flow()
        result.print_pretty_table()
        print(result.df().to_string())
        self._assert_row_meta(result)

    def test_statement_6(self):
        result = self.ticker.annual_cash_flow()
        result.print_pretty_table()
        print(result.df().to_string())
        self._assert_row_meta(result)

    def test_ttm_pe(self):
        result = self.ticker.ttm_pe()
        print(result)
        self.assertIn('symbol', result.columns)

    def test_earning_call_transcripts(self):
        transcripts = self.ticker.earning_call_transcripts()
        print(transcripts)
        print(transcripts.get_transcripts_list())
        print(transcripts.get_transcript(2025, 2))
        transcripts.print_pretty_table(2025, 2)

    def test_news(self):
        news = self.ticker.news()

        df = news.get_news_list()
        print(df.to_string())

        first_uuid = df.iloc[0]["uuid"]

        print(first_uuid)
        print(news.get_news(first_uuid))
        news.print_pretty_table(first_uuid)

    def test_revenue_by_segment(self):
        result = self.ticker.revenue_by_segment()
        print(result.to_string())
        self.assertIn('symbol', result.columns)

    def test_revenue_by_geography(self):
        result = self.ticker.revenue_by_geography()
        print(result.to_string())
        self.assertIn('symbol', result.columns)

    def test_revenue_by_product(self):
        result = self.ticker.revenue_by_product()
        print(result.to_string())
        self.assertIn('symbol', result.columns)

    def test_quarterly_gross_margin(self):
        result = self.ticker.quarterly_gross_margin()
        print(result.to_string())
        self.assertIn('symbol', result.columns)

    def test_annual_gross_margin(self):
        result = self.ticker.annual_gross_margin()
        print(result.to_string())
        self.assertIn('symbol', result.columns)

    def test_quarterly_operating_margin(self):
        result = self.ticker.quarterly_operating_margin()
        print(result.to_string())
        self.assertIn('symbol', result.columns)

    def test_annual_operating_margin(self):
        result = self.ticker.annual_operating_margin()
        print(result.to_string())
        self.assertIn('symbol', result.columns)

    def test_quarterly_net_margin(self):
        result = self.ticker.quarterly_net_margin()
        print(result.to_string())
        self.assertIn('symbol', result.columns)

    def test_annual_net_margin(self):
        result = self.ticker.annual_net_margin()
        print(result.to_string())
        self.assertIn('symbol', result.columns)

    def test_quarterly_ebitda_margin(self):
        result = self.ticker.quarterly_ebitda_margin()
        print(result.to_string())
        self.assertIn('symbol', result.columns)

    def test_annual_ebitda_margin(self):
        result = self.ticker.annual_ebitda_margin()
        print(result.to_string())
        self.assertIn('symbol', result.columns)

    def test_quarterly_fcf_margin(self):
        result = self.ticker.quarterly_fcf_margin()
        print(result.to_string())
        self.assertIn('symbol', result.columns)

    def test_annual_fcf_margin(self):
        result = self.ticker.annual_fcf_margin()
        print(result.to_string())
        self.assertIn('symbol', result.columns)

    def test_quarterly_revenue_yoy_growth(self):
        result = self.ticker.quarterly_revenue_yoy_growth()
        print(result.to_string())
        self.assertIn('symbol', result.columns)

    def test_annual_revenue_yoy_growth(self):
        result = self.ticker.annual_revenue_yoy_growth()
        print(result.to_string())
        self.assertIn('symbol', result.columns)

    def test_quarterly_operating_income_yoy_growth(self):
        result = self.ticker.quarterly_operating_income_yoy_growth()
        print(result.to_string())
        self.assertIn('symbol', result.columns)

    def test_annual_operating_income_yoy_growth(self):
        result = self.ticker.annual_operating_income_yoy_growth()
        print(result.to_string())
        self.assertIn('symbol', result.columns)

    def test_quarterly_ebitda_yoy_growth(self):
        result = self.ticker.quarterly_ebitda_yoy_growth()
        print(result.to_string())
        self.assertIn('symbol', result.columns)

    def test_annual_ebitda_yoy_growth(self):
        result = self.ticker.annual_ebitda_yoy_growth()
        print(result.to_string())
        self.assertIn('symbol', result.columns)

    def test_quarterly_net_income_yoy_growth(self):
        result = self.ticker.quarterly_net_income_yoy_growth()
        print(result.to_string())
        self.assertIn('symbol', result.columns)

    def test_annual_net_income_yoy_growth(self):
        result = self.ticker.annual_net_income_yoy_growth()
        print(result.to_string())
        self.assertIn('symbol', result.columns)

    def test_quarterly_fcf_yoy_growth(self):
        result = self.ticker.quarterly_fcf_yoy_growth()
        print(result.to_string())
        self.assertIn('symbol', result.columns)

    def test_annual_fcf_yoy_growth(self):
        result = self.ticker.annual_fcf_yoy_growth()
        print(result.to_string())
        self.assertIn('symbol', result.columns)

    def test_quarterly_eps_yoy_growth(self):
        result = self.ticker.quarterly_eps_yoy_growth()
        print(result.to_string())
        self.assertIn('symbol', result.columns)

    def test_quarterly_ttm_eps_yoy_growth(self):
        result = self.ticker.quarterly_ttm_eps_yoy_growth()
        print(result.to_string())
        self.assertIn('symbol', result.columns)

    def test_market_capitalization(self):
        result = self.ticker.market_capitalization()
        print(result.to_string())
        self.assertIn('symbol', result.columns)

    def test_ps_ratio(self):
        result = self.ticker.ps_ratio()
        print(result.to_string())
        self.assertIn('symbol', result.columns)

    def test_pb_ratio(self):
        result = self.ticker.pb_ratio()
        print(result.to_string())
        self.assertIn('symbol', result.columns)

    def test_peg_ratio(self):
        result = self.ticker.peg_ratio()
        print(result.to_string())
        self.assertIn('symbol', result.columns)

    def test_ttm_revenue(self):
        result = self.ticker.ttm_revenue()
        print(result.to_string())
        self.assertIn('symbol', result.columns)

    def test_ttm_net_income_common_stockholders(self):
        result = self.ticker.ttm_net_income_common_stockholders()
        print(result.to_string())
        self.assertIn('symbol', result.columns)

    def test_quarterly_book_value_of_equity(self):
        result = self.ticker._quarterly_book_value_of_equity()
        print(result.to_string())
        self.assertIn('symbol', result.columns)

    def test_roe(self):
        result = self.ticker.roe()
        print(result.to_string())
        self.assertIn('symbol', result.columns)

    def test_roa(self):
        result = self.ticker.roa()
        print(result.to_string())
        self.assertIn('symbol', result.columns)

    def test_roic(self):
        result = self.ticker.roic()
        print(result.to_string())
        self.assertIn('symbol', result.columns)

    def test_equity_multiplier(self):
        result = self.ticker.equity_multiplier()
        print(result.to_string())
        self.assertIn('symbol', result.columns)

    def test_asset_turnover(self):
        result = self.ticker.asset_turnover()
        print(result.to_string())
        self.assertIn('symbol', result.columns)

    def test_wacc(self):
        result = self.ticker.wacc()
        print(result.to_string())
        self.assertIn('symbol', result.columns)

    def test_dcf(self):
        result = self.ticker.dcf()
        print(result)

    def test_beta(self):
        """Test beta calculation with different time periods"""
        print("\n=== Testing Beta Calculation ===\n")

        periods = ["1y", "3y", "5y"]

        for period in periods:
            result = self.ticker.beta(period)
            print(result.to_string())
            self.assertIn('symbol', result.columns)
