SELECT * FROM
             '{url}'
         WHERE symbol = '{ticker}'
             and finance_type = '{finance_type}'
             and period_type = '{period_type}'