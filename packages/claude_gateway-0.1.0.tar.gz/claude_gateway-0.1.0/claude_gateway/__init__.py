"""Claude Gateway - Telegram bot for remote Claude Code CLI access."""

__version__ = "0.1.0"
