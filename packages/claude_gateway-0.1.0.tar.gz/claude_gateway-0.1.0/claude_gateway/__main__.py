"""Allow running as python -m claude_gateway."""
from .cli import main

if __name__ == "__main__":
    main()
