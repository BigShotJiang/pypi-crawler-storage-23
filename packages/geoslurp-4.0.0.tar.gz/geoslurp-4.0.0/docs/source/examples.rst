Tutorial
========

.. toctree::
   
   usingcli.rst
   notebooks/pyexamples.rst
