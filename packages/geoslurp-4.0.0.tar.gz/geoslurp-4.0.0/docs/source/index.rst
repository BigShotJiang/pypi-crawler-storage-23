.. geoslurp documentation master file, created by
   sphinx-quickstart on Mon Mar  4 20:45:17 2019.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.


Data management with geoslurp
=============================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   introduction
   installation
   confsettings
   examples
   reference

Indices and tables
==================

* :ref:`genindex`
* :ref:`search`
