.. _clihelp:

Command line tools
==================

.. _geoslurphelp:

.. autoprogram:: geoslurp.cli.geoslurper:addCommandLineArgs()
   :prog: geoslurper
