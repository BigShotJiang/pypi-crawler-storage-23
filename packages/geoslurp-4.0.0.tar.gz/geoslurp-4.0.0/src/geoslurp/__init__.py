"""API Documentation for the geoslurp python module"""
from .manager import GeoslurpManager

