#Contains the implementation of datasets, database functions and views which are provided along the geoslurp package

Other python modules can additionally register plugins through the Python entry_points mechanism

