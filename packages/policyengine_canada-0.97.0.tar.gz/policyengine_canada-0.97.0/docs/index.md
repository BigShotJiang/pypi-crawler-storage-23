# PolicyEngine Canada

This is the documentation for PolicyEngine Canada, a microsimulation model of Canada's tax-benefit system.
