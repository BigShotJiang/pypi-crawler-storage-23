"""
Examples demonstrating mps_sim capabilities.

Run with: python examples.py
"""
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import numpy as np
from mps_sim import Circuit, MPSSimulator, MultiChiRunner, SweepConfig
from mps_sim import RichardsonExtrapolator


def example_1_bell_state():
    print("\n" + "="*60)
    print("Example 1: Bell State")
    print("="*60)

    c = Circuit(2)
    c.h(0).cx(0, 1)

    sim = MPSSimulator(chi=16)
    state = sim.run(c)

    sv = state.to_statevector()
    print(f"State vector: {sv}")
    print(f"<Z0>: {state.expectation_pauli_z(0):.6f}  (expected: 0.0)")
    print(f"<Z1>: {state.expectation_pauli_z(1):.6f}  (expected: 0.0)")
    print(f"<X0>: {state.expectation_pauli_x(0):.6f}  (expected: 0.0)")
    print(f"Bond dims: {state.bond_dimensions()}")


def example_2_ghz_chain():
    print("\n" + "="*60)
    print("Example 2: GHZ State (10 qubits)")
    print("="*60)

    n = 10
    c = Circuit(n)
    c.h(0)
    for i in range(n - 1):
        c.cx(i, i + 1)

    sim = MPSSimulator(chi=64)
    state = sim.run(c)

    print(f"GHZ state: {state}")
    print("Expectation values <Z_i>:")
    for i in range(n):
        z = state.expectation_pauli_z(i)
        print(f"  <Z_{i}> = {z:.6f}  (expected: 0.0)")

    print(f"Total truncation error: {state.total_truncation_error():.2e}")


def example_3_richardson_extrapolation():
    print("\n" + "="*60)
    print("Example 3: Richardson Extrapolation")
    print("="*60)

    # Transverse-field Ising chain
    n = 8
    J = 1.0
    h = 0.5

    def build_ising_circuit(steps=3):
        c = Circuit(n)
        c.h(0)
        for _ in range(steps):
            # Transverse field: Rx rotations
            for q in range(n):
                c.rx(2 * h * 0.1, q)
            # ZZ interactions
            for q in range(n - 1):
                c.zz(2 * J * 0.1, q, q + 1)
        return c

    circuit = build_ising_circuit(steps=5)
    print(f"Circuit: {circuit}")

    # Standard simulation at different chi
    print("\nStandard simulation at different bond dimensions:")
    chi_values = [8, 16, 32]
    z0_values = []

    for chi in chi_values:
        sim = MPSSimulator(chi=chi)
        state = sim.run(circuit)
        z0 = state.expectation_pauli_z(0)
        z0_values.append(z0)
        print(f"  χ={chi:4d}: <Z_0> = {z0:.8f}  (trunc_err={state.total_truncation_error():.2e})")

    # Richardson extrapolation
    ext = RichardsonExtrapolator(ratio=2.0)
    result = ext.extrapolate(chi_values, z0_values)

    print("\n" + result.summary())

    # Compare: what did we get at χ=64 directly?
    sim64 = MPSSimulator(chi=64)
    state64 = sim64.run(circuit)
    z0_64 = state64.expectation_pauli_z(0)
    print(f"Direct simulation at χ=64: <Z_0> = {z0_64:.8f}")
    print(f"Extrapolated from χ=8,16,32: <Z_0> = {result.extrapolated:.8f}")
    print(f"Error vs χ=64: {abs(result.extrapolated - z0_64):.2e}")


def example_4_multi_chi_runner():
    print("\n" + "="*60)
    print("Example 4: MultiChiRunner (automated sweep + extrapolation)")
    print("="*60)

    n = 6
    c = Circuit(n)

    # Brick-layer random circuit
    np.random.seed(123)
    for layer in range(4):
        for q in range(n):
            c.ry(np.random.uniform(0, np.pi), q)
        for q in range(layer % 2, n - 1, 2):
            c.cx(q, q + 1)

    print(f"Circuit: {circuit}")

    observables = {f'Z{q}': ('Z', q) for q in range(n)}

    cfg = SweepConfig(base_chi=8, ratio=2.0, n_levels=3)
    runner = MultiChiRunner(cfg, verbose=True)
    result = runner.run(c, observables)

    print("\n" + result.summary())


def example_5_convergence_analysis():
    print("\n" + "="*60)
    print("Example 5: Convergence Analysis")
    print("="*60)

    # Generate data with known alpha to demonstrate diagnostic accuracy
    true_value = 0.42
    alpha_true = 1.5

    print(f"True value:    {true_value}")
    print(f"True α:        {alpha_true}")
    print()

    chi_list = [16, 32, 64, 128]
    # Simulate "measured" values with power-law error
    values = [true_value + 2.0 / chi**alpha_true for chi in chi_list]

    print("Simulated data (with synthetic truncation error):")
    for chi, val in zip(chi_list, values):
        print(f"  χ={chi:4d}: {val:.8f}")

    ext = RichardsonExtrapolator()
    result = ext.extrapolate(chi_list, values)

    print()
    print(result.summary())
    print(f"True value:       {true_value:.8f}")
    print(f"Extrapolated:     {result.extrapolated:.8f}")
    print(f"Error:            {abs(result.extrapolated - true_value):.2e}")
    print(f"Estimated α:      {result.alpha:.3f}  (true: {alpha_true})")


if __name__ == '__main__':
    example_1_bell_state()
    example_2_ghz_chain()
    example_3_richardson_extrapolation()
    example_4_multi_chi_runner()
    example_5_convergence_analysis()
    print("\n✓ All examples completed.")
