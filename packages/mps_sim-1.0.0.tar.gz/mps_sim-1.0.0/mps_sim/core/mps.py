"""
Matrix Product State (MPS) core implementation.

An MPS represents an n-qubit state as a chain of rank-3 tensors:
    Γ[0][σ0, r0] · Γ[1][l1, σ1, r1] · ... · Γ[n-1][ln-1, σn-1]

where σ are physical (qubit) indices and l,r are virtual (bond) indices.
"""

from __future__ import annotations
import numpy as np
from numpy.typing import NDArray
from typing import Optional, List, Tuple
import copy
import logging

logger = logging.getLogger(__name__)


class MPS:
    """
    Matrix Product State representation of an n-qubit quantum state.

    Tensors are stored in mixed-canonical form centered at a sweep position,
    which ensures numerically stable expectation value computation.

    Attributes
    ----------
    n : int
        Number of qubits.
    chi : int
        Maximum bond dimension (truncation threshold).
    tensors : list of ndarray
        MPS tensors. Shape of tensor[i] is (chi_l, 2, chi_r) with
        boundary shapes (2, chi_r) for i=0 and (chi_l, 2) for i=n-1.
    center : int or None
        Orthogonality center site.
    truncation_errors : list of float
        Cumulative truncation errors from SVD truncations.
    """

    def __init__(self, n: int, chi: int):
        self.n = n
        self.chi = chi
        self.tensors: List[NDArray] = []
        self.center: Optional[int] = None
        self.truncation_errors: List[float] = []
        self._initialize_product_state()

    def _initialize_product_state(self):
        """Initialize |00...0> product state."""
        self.tensors = []
        for i in range(self.n):
            if i == 0:
                t = np.zeros((2, 1), dtype=complex)
                t[0, 0] = 1.0
            elif i == self.n - 1:
                t = np.zeros((1, 2), dtype=complex)
                t[0, 0] = 1.0
            else:
                t = np.zeros((1, 2, 1), dtype=complex)
                t[0, 0, 0] = 1.0
            self.tensors.append(t)
        self.center = None
        self.truncation_errors = []

    # ------------------------------------------------------------------
    # Tensor shape helpers
    # ------------------------------------------------------------------

    def bond_dim(self, bond: int) -> int:
        """Bond dimension of bond between site bond and bond+1."""
        if bond < 0 or bond >= self.n - 1:
            raise ValueError(f"Bond {bond} out of range for {self.n} qubits.")
        t = self.tensors[bond]
        if bond == 0:
            return t.shape[1]
        else:
            return t.shape[2]

    def get_tensor(self, i: int) -> NDArray:
        """Return tensor at site i with uniform shape (chi_l, 2, chi_r)."""
        t = self.tensors[i]
        if i == 0:
            return t[np.newaxis, :, :]  # (1, 2, chi_r)
        elif i == self.n - 1:
            return t[:, :, np.newaxis]  # (chi_l, 2, 1)
        return t

    def set_tensor(self, i: int, t: NDArray):
        """Set tensor at site i, stripping trivial boundary indices."""
        if i == 0:
            if t.ndim == 3:
                t = t[0, :, :]  # (2, chi_r)
        elif i == self.n - 1:
            if t.ndim == 3:
                t = t[:, :, 0]  # (chi_l, 2)
        self.tensors[i] = t

    # ------------------------------------------------------------------
    # Canonicalization
    # ------------------------------------------------------------------

    def left_normalize_site(self, i: int) -> NDArray:
        """
        Left-normalize site i via QR.
        Returns the R matrix to be absorbed into site i+1.
        """
        t = self.get_tensor(i)          # (chi_l, 2, chi_r)
        chi_l, d, chi_r = t.shape
        mat = t.reshape(chi_l * d, chi_r)
        Q, R = np.linalg.qr(mat)
        new_chi = Q.shape[1]
        new_t = Q.reshape(chi_l, d, new_chi)
        self.set_tensor(i, new_t)
        return R  # (new_chi, chi_r)

    def right_normalize_site(self, i: int) -> NDArray:
        """
        Right-normalize site i via QR.
        Returns the L matrix to be absorbed into site i-1.
        """
        t = self.get_tensor(i)          # (chi_l, 2, chi_r)
        chi_l, d, chi_r = t.shape
        mat = t.reshape(chi_l, d * chi_r).T  # (d*chi_r, chi_l)
        Q, R = np.linalg.qr(mat)
        # Q: (d*chi_r, new_chi), R: (new_chi, chi_l)
        new_chi = Q.shape[1]
        new_t = Q.T.reshape(new_chi, d, chi_r)  # actually need transpose back
        # Redo cleanly
        mat2 = t.reshape(chi_l, d * chi_r)
        Q2, R2 = np.linalg.qr(mat2.T)
        # Q2: (d*chi_r, k), R2: (k, chi_l)
        new_chi2 = Q2.shape[1]
        new_t2 = Q2.T.reshape(new_chi2, d, chi_r)
        self.set_tensor(i, new_t2)
        return R2  # (new_chi2, chi_l) → to be absorbed to left: site[i-1] @ R2.T

    def canonicalize(self, center: int):
        """
        Bring MPS to mixed-canonical form with orthogonality center at `center`.
        Sites 0..center-1 are left-normalized, sites center+1..n-1 are right-normalized.
        """
        # Left sweep: sites 0 to center-1
        for i in range(center):
            R = self.left_normalize_site(i)
            # Absorb R into site i+1
            t_next = self.get_tensor(i + 1)          # (chi_l, 2, chi_r)
            t_next = np.einsum('ij,jkl->ikl', R, t_next)
            self.set_tensor(i + 1, t_next)

        # Right sweep: sites n-1 down to center+1
        for i in range(self.n - 1, center, -1):
            t = self.get_tensor(i)
            chi_l, d, chi_r = t.shape
            mat = t.reshape(chi_l, d * chi_r)
            Q, R = np.linalg.qr(mat.T)
            # Q.T is right-normalized
            new_chi = Q.shape[1]
            new_t = Q.T.reshape(new_chi, d, chi_r)
            self.set_tensor(i, new_t)
            # Absorb R into site i-1
            t_prev = self.get_tensor(i - 1)
            t_prev = np.einsum('ijk,kl->ijl', t_prev, R.T)
            self.set_tensor(i - 1, t_prev)

        self.center = center

    # ------------------------------------------------------------------
    # SVD-based gate application with truncation
    # ------------------------------------------------------------------

    def apply_svd_truncation(
        self,
        i: int,
        theta: NDArray,
        chi: Optional[int] = None,
        svd_threshold: float = 1e-14,
    ) -> float:
        """
        Apply SVD on the combined tensor theta at bond (i, i+1).

        Parameters
        ----------
        i : int
            Left site of the bond.
        theta : ndarray
            Shape (chi_l, 2, 2, chi_r) — combined two-site tensor.
        chi : int, optional
            Bond dimension cap. Defaults to self.chi.
        svd_threshold : float
            Singular values below this threshold are dropped.

        Returns
        -------
        float
            Truncation error (sum of squared discarded singular values).
        """
        if chi is None:
            chi = self.chi

        chi_l, d1, d2, chi_r = theta.shape
        mat = theta.reshape(chi_l * d1, d2 * chi_r)

        U, S, Vh = np.linalg.svd(mat, full_matrices=False)

        # Determine truncation
        keep = np.sum(S > svd_threshold)
        keep = min(keep, chi)
        keep = max(keep, 1)

        trunc_err = float(np.sum(S[keep:] ** 2))
        self.truncation_errors.append(trunc_err)

        S_trunc = S[:keep]
        U_trunc = U[:, :keep]
        Vh_trunc = Vh[:keep, :]

        # Absorb S into right tensor (left tensor U is left-normalized, right gets S·Vh).
        # Do NOT renormalize S here: SVD of a unit-norm matrix has sum(S²)=1,
        # and renormalizing after truncation would change the physical state norm.
        SV = np.diag(S_trunc) @ Vh_trunc

        A = U_trunc.reshape(chi_l, d1, keep)
        B = SV.reshape(keep, d2, chi_r)

        self.set_tensor(i, A)
        self.set_tensor(i + 1, B)

        return trunc_err

    # ------------------------------------------------------------------
    # Expectation values
    # ------------------------------------------------------------------

    def expectation_single(self, op: NDArray, site: int) -> complex:
        """
        Compute <ψ|op|ψ> for a single-site operator.

        Uses efficient contraction with left/right environments.
        """
        self.canonicalize(site)
        t = self.get_tensor(site)  # (chi_l, 2, chi_r)
        # Contract: sum_{s,s'} op[s,s'] * t_conj[l,s,r] * t[l,s',r]
        # Contract: <t|op|t> = sum_{l,r,s,s2} t_conj[l,s,r] * op[s,s2] * t[l,s2,r]
        val = np.einsum('lsr,sa,lar->', t.conj(), op, t)
        return complex(val)

    def expectation_two(self, op: NDArray, site_i: int) -> complex:
        """
        Compute <ψ|op|ψ> for a two-site operator at sites (site_i, site_i+1).

        Parameters
        ----------
        op : ndarray shape (2,2,2,2) — op[s1',s2',s1,s2]
        """
        self.canonicalize(site_i)
        A = self.get_tensor(site_i)        # (chi_l, 2, chi_r)
        B = self.get_tensor(site_i + 1)    # (chi_l, 2, chi_r)

        # theta[chi_l, 2, 2, chi_r]
        theta = np.einsum('lir,rjs->lijs', A, B)
        val = np.einsum('lijs,abij,labs->',
                        theta.conj(), op, theta)
        return complex(val)

    def expectation_pauli_z(self, site: int) -> float:
        """Compute <Z> at site."""
        Z = np.array([[1, 0], [0, -1]], dtype=complex)
        return float(np.real(self.expectation_single(Z, site)))

    def expectation_pauli_x(self, site: int) -> float:
        """Compute <X> at site."""
        X = np.array([[0, 1], [1, 0]], dtype=complex)
        return float(np.real(self.expectation_single(X, site)))

    def expectation_pauli_y(self, site: int) -> float:
        """Compute <Y> at site."""
        Y = np.array([[0, -1j], [1j, 0]], dtype=complex)
        return float(np.real(self.expectation_single(Y, site)))

    # ------------------------------------------------------------------
    # State vector (for small systems only!)
    # ------------------------------------------------------------------

    def to_statevector(self) -> NDArray:
        """
        Contract MPS into full statevector. Exponential cost — use only for n ≤ 20.
        """
        if self.n > 20:
            raise ValueError("to_statevector is only safe for n <= 20 qubits.")

        result = self.get_tensor(0)  # (1, 2, chi_r) → treat as (2, chi_r)
        result = result[0]           # (2, chi_r)

        for i in range(1, self.n):
            t = self.get_tensor(i)   # (chi_l, 2, chi_r)
            # result: (2^i, chi_l), t: (chi_l, 2, chi_r)
            result = np.einsum('...l,lsr->...sr', result, t)
            result = result.reshape(-1, t.shape[2])

        return result[:, 0]  # drop trivial right bond dim=1

    def norm(self) -> float:
        """Compute <ψ|ψ>."""
        sv = self.to_statevector() if self.n <= 20 else self._norm_mps()
        return float(np.abs(np.dot(sv.conj(), sv)) ** 0.5) if self.n <= 20 else sv

    def _norm_mps(self) -> float:
        """MPS norm via transfer matrix contraction (efficient for large n)."""
        L = np.ones((1, 1), dtype=complex)
        for i in range(self.n):
            t = self.get_tensor(i)  # (chi_l, 2, chi_r) via get_tensor
            # new_L[r, p] = sum_{a, b, s} L[a,b] * t[a,s,r] * conj(t)[b,s,p]
            L = np.einsum('ab,asr,bsp->rp', L, t, t.conj())
        return float(np.real(L[0, 0]) ** 0.5)

    # ------------------------------------------------------------------
    # Utilities
    # ------------------------------------------------------------------

    def copy(self) -> 'MPS':
        new = MPS(self.n, self.chi)
        new.tensors = [t.copy() for t in self.tensors]
        new.center = self.center
        new.truncation_errors = list(self.truncation_errors)
        return new

    def total_truncation_error(self) -> float:
        """Sum of all squared truncation errors accumulated during simulation."""
        return sum(self.truncation_errors)

    def bond_dimensions(self) -> List[int]:
        """Return list of all bond dimensions."""
        dims = []
        for i in range(self.n - 1):
            dims.append(self.bond_dim(i))
        return dims

    def max_bond_dim(self) -> int:
        return max(self.bond_dimensions()) if self.n > 1 else 1

    def __repr__(self) -> str:
        bonds = self.bond_dimensions()
        return (f"MPS(n={self.n}, chi={self.chi}, "
                f"bonds={bonds}, "
                f"trunc_err={self.total_truncation_error():.2e})")
