#!/usr/bin/env python3
"""
mps_sim CLI — MPS quantum circuit simulator with Richardson extrapolation.

Usage
-----
  python cli.py simulate --circuit bell --chi 64
  python cli.py extrapolate --circuit ising --chi-base 16 --levels 3
  python cli.py benchmark --circuit ghz --n 10
  python cli.py info
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import argparse
import numpy as np
import time
from mps_sim import Circuit, MPSSimulator, MultiChiRunner, SweepConfig
from mps_sim import RichardsonExtrapolator


# ---------------------------------------------------------------------------
# Built-in circuit library
# ---------------------------------------------------------------------------

def make_bell(n=2) -> Circuit:
    c = Circuit(max(2, n))
    c.h(0).cx(0, 1)
    return c

def make_ghz(n=6) -> Circuit:
    c = Circuit(n)
    c.h(0)
    for i in range(n - 1):
        c.cx(i, i + 1)
    return c

def make_ising(n=8, steps=5, J=1.0, h=0.5, dt=0.05) -> Circuit:
    c = Circuit(n)
    for _ in range(steps):
        for q in range(n):
            c.rx(2 * h * dt, q)
        for q in range(n - 1):
            c.zz(2 * J * dt, q, q + 1)
    return c

def make_qft(n=6) -> Circuit:
    """Quantum Fourier Transform."""
    c = Circuit(n)
    for i in range(n):
        c.h(i)
        for j in range(i + 1, n):
            c.cp(np.pi / 2 ** (j - i), i, j)
    # Bit reversal swaps
    for i in range(n // 2):
        c.swap(i, n - 1 - i)
    return c

def make_random(n=8, depth=10, seed=42) -> Circuit:
    np.random.seed(seed)
    c = Circuit(n)
    for _ in range(depth):
        for q in range(n):
            c.ry(np.random.uniform(0, np.pi), q)
        for q in range(n - 1):
            if np.random.random() < 0.5:
                c.cx(q, q + 1)
    return c

CIRCUITS = {
    'bell': make_bell,
    'ghz': make_ghz,
    'ising': make_ising,
    'qft': make_qft,
    'random': make_random,
}


# ---------------------------------------------------------------------------
# CLI commands
# ---------------------------------------------------------------------------

def cmd_simulate(args):
    print(f"\n── Simulation ──────────────────────────────────────────")
    circuit_fn = CIRCUITS.get(args.circuit)
    if circuit_fn is None:
        print(f"Unknown circuit '{args.circuit}'. Available: {list(CIRCUITS)}")
        return

    c = circuit_fn(n=args.n)
    print(f"Circuit: {c}")
    print(f"Bond dim: χ={args.chi}")

    t0 = time.time()
    sim = MPSSimulator(chi=args.chi)
    state = sim.run(c)
    elapsed = time.time() - t0

    print(f"\nResults (time: {elapsed:.2f}s):")
    for q in range(min(c.n, 10)):
        z = state.expectation_pauli_z(q)
        x = state.expectation_pauli_x(q)
        print(f"  q{q}: <Z>={z:+.6f}  <X>={x:+.6f}")

    print(f"\nBond dims: {state.bond_dimensions()}")
    print(f"Max bond dim reached: {state.max_bond_dim()} / {args.chi}")
    print(f"Total truncation error: {state.total_truncation_error():.2e}")
    print(f"State: {state}")


def cmd_extrapolate(args):
    print(f"\n── Richardson Extrapolation ────────────────────────────")
    circuit_fn = CIRCUITS.get(args.circuit)
    if circuit_fn is None:
        print(f"Unknown circuit '{args.circuit}'. Available: {list(CIRCUITS)}")
        return

    c = circuit_fn(n=args.n)
    print(f"Circuit: {c}")

    cfg = SweepConfig(
        base_chi=args.chi_base,
        ratio=args.ratio,
        n_levels=args.levels,
    )
    print(f"Bond dims: {cfg.bond_dims}")
    print(f"Effective equivalent χ: {cfg.effective_chi()}")
    print()

    observables = {f'Z{q}': ('Z', q) for q in range(min(c.n, args.obs_qubits))}
    runner = MultiChiRunner(cfg, verbose=True)

    t0 = time.time()
    result = runner.run(c, observables)
    elapsed = time.time() - t0

    print(f"\n{result.summary()}")
    print(f"Total runtime: {elapsed:.2f}s")


def cmd_benchmark(args):
    print(f"\n── Benchmark ───────────────────────────────────────────")
    circuit_fn = CIRCUITS.get(args.circuit)
    if circuit_fn is None:
        print(f"Unknown circuit '{args.circuit}'. Available: {list(CIRCUITS)}")
        return

    c = circuit_fn(n=args.n)
    print(f"Circuit: {c}")
    print(f"{'χ':>6}  {'Time(s)':>10}  {'<Z0>':>12}  {'TruncErr':>12}  {'MaxBond':>8}")
    print("-" * 60)

    chi_list = [args.chi_start * (2 ** i) for i in range(args.chi_levels)]
    results = []

    for chi in chi_list:
        t0 = time.time()
        sim = MPSSimulator(chi=chi)
        state = sim.run(c)
        elapsed = time.time() - t0
        z0 = state.expectation_pauli_z(0)
        trunc = state.total_truncation_error()
        maxb = state.max_bond_dim()
        results.append((chi, elapsed, z0, trunc, maxb))
        print(f"{chi:>6}  {elapsed:>10.3f}  {z0:>+12.8f}  {trunc:>12.2e}  {maxb:>8}")

    if len(results) >= 2:
        print("\nRichardson extrapolation from all points:")
        chi_vals = [r[0] for r in results]
        z0_vals = [r[2] for r in results]
        ext = RichardsonExtrapolator()
        res = ext.extrapolate(chi_vals, z0_vals)
        print(f"  Extrapolated <Z0> = {res.extrapolated:.8f} ± {res.uncertainty:.2e}")
        print(f"  Alpha (error exponent) = {res.alpha:.3f}")
        print(f"  Reliable: {res.is_reliable}")


def cmd_info(args):
    print("""
mps_sim — MPS Quantum Circuit Simulator with Richardson Extrapolation
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

ABOUT
  Simulates quantum circuits using Matrix Product States (MPS).
  Unique feature: multilevel Richardson extrapolation to estimate
  expectation values at arbitrarily high bond dimensions from
  simulations at a geometric sequence of modest bond dimensions.

GATES SUPPORTED
  Single-qubit: I, X, Y, Z, H, S, T, Sdg, Tdg, Rx, Ry, Rz, P, U
  Two-qubit:    CNOT/CX, CZ, SWAP, iSWAP, XX, YY, ZZ, CRz, CP

BUILT-IN CIRCUITS
  bell    — 2-qubit Bell state
  ghz     — N-qubit GHZ state
  ising   — Transverse-field Ising Trotterized evolution
  qft     — Quantum Fourier Transform
  random  — Random brick-layer circuit

EXTRAPOLATION THEORY
  Truncation error scales as: ε(χ) ≈ a₁/χ^α + a₂/χ^2α + ...
  Richardson extrapolation cancels successive error orders using
  simulations at χ, 2χ, 4χ, ..., analogous to Romberg integration.
  Reliability diagnostics flag when the power-law assumption breaks down.

EXAMPLES
  python cli.py simulate  --circuit ghz   --n 10 --chi 64
  python cli.py extrapolate --circuit ising --n 8 --chi-base 16 --levels 3
  python cli.py benchmark --circuit ising --n 8 --chi-start 8 --chi-levels 4
""")


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(
        description='mps_sim — MPS Quantum Simulator with Richardson Extrapolation'
    )
    sub = parser.add_subparsers(dest='command')

    # simulate
    p_sim = sub.add_parser('simulate', help='Run a single simulation')
    p_sim.add_argument('--circuit', default='ghz', choices=list(CIRCUITS))
    p_sim.add_argument('--n', type=int, default=8, help='Number of qubits')
    p_sim.add_argument('--chi', type=int, default=64, help='Bond dimension')

    # extrapolate
    p_ext = sub.add_parser('extrapolate', help='Run multi-chi sweep with extrapolation')
    p_ext.add_argument('--circuit', default='ising', choices=list(CIRCUITS))
    p_ext.add_argument('--n', type=int, default=8)
    p_ext.add_argument('--chi-base', type=int, default=16)
    p_ext.add_argument('--ratio', type=float, default=2.0)
    p_ext.add_argument('--levels', type=int, default=3)
    p_ext.add_argument('--obs-qubits', type=int, default=4, help='Number of qubits to measure')

    # benchmark
    p_bench = sub.add_parser('benchmark', help='Benchmark across chi values')
    p_bench.add_argument('--circuit', default='ising', choices=list(CIRCUITS))
    p_bench.add_argument('--n', type=int, default=8)
    p_bench.add_argument('--chi-start', type=int, default=8)
    p_bench.add_argument('--chi-levels', type=int, default=4)

    # info
    sub.add_parser('info', help='Show package info and supported gates')

    args = parser.parse_args()

    if args.command == 'simulate':
        cmd_simulate(args)
    elif args.command == 'extrapolate':
        cmd_extrapolate(args)
    elif args.command == 'benchmark':
        cmd_benchmark(args)
    elif args.command == 'info':
        cmd_info(args)
    else:
        parser.print_help()


if __name__ == '__main__':
    main()
