"""
Multilevel Richardson Extrapolation for MPS quantum circuit simulation.

Theory
------
MPS truncation error in an expectation value <O> scales approximately as:

    <O>(χ) ≈ <O>(∞) + a₁/χ^α + a₂/χ^(2α) + ...

When bond dimensions are chosen as a geometric sequence χ, r·χ, r²·χ, ...
Richardson extrapolation can cancel successive powers of the error:

    Level-1: E₁[i] = (r^α · f(χᵢ₊₁) - f(χᵢ)) / (r^α - 1)
    Level-2: E₂[i] = (r^α · E₁[i+1] - E₁[i]) / (r^α - 1)
    ...

This is analogous to Romberg integration applied to bond-dimension convergence.

The key assumption is that truncation error decays as a power law in χ.
This holds well for:
  - Gapped 1D systems (area-law entanglement)
  - Circuits in the weakly-entangled regime
  - Deep circuits at large enough χ (tail of entanglement spectrum)

Reliability diagnostics:
  - Convergence ratio test: successive corrections should decrease geometrically
  - Error bar estimation from spread of extrapolated values
  - Consistency check across multiple extrapolation orders

References
----------
- Richardson (1911), Romberg (1955) for the extrapolation framework
- Vidal (2003), Schollwöck (2011) for MPS and bond-dimension convergence
"""

from __future__ import annotations
import numpy as np
from numpy.typing import NDArray
from dataclasses import dataclass, field
from typing import List, Optional, Tuple, Dict, Callable
import warnings
import logging

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Data structures
# ---------------------------------------------------------------------------

@dataclass
class ExtrapolationResult:
    """
    Result of Richardson extrapolation.

    Attributes
    ----------
    bond_dims : list of int
        Bond dimensions used.
    raw_values : list of float
        Expectation values at each bond dimension.
    extrapolated : float
        Best extrapolated estimate.
    uncertainty : float
        Estimated uncertainty of extrapolated value.
    table : ndarray
        Full Richardson tableau (rows = levels, cols = bond dims).
    convergence_ratios : list of float
        Ratios of successive corrections (should be ~r^α for reliable result).
    is_reliable : bool
        Whether the extrapolation passes reliability diagnostics.
    reliability_notes : list of str
        Explanations of any reliability concerns.
    alpha : float
        Estimated truncation error exponent.
    ratio : float
        Geometric ratio r between bond dimensions.
    """
    bond_dims: List[int]
    raw_values: List[float]
    extrapolated: float
    uncertainty: float
    table: NDArray
    convergence_ratios: List[float]
    is_reliable: bool
    reliability_notes: List[str]
    alpha: float
    ratio: float

    def summary(self) -> str:
        lines = [
            "=" * 60,
            "Richardson Extrapolation Result",
            "=" * 60,
            f"Bond dimensions: {self.bond_dims}",
            f"Raw values:      {[f'{v:.8f}' for v in self.raw_values]}",
            f"Extrapolated:    {self.extrapolated:.8f} ± {self.uncertainty:.2e}",
            f"Alpha (exponent): {self.alpha:.3f}",
            f"Reliable:        {self.is_reliable}",
        ]
        if self.reliability_notes:
            lines.append("Notes:")
            for note in self.reliability_notes:
                lines.append(f"  • {note}")
        lines.append("=" * 60)
        return '\n'.join(lines)

    def improvement_factor(self) -> float:
        """How much the extrapolation improved over the largest raw value."""
        best_raw = self.raw_values[-1]
        if abs(self.extrapolated - best_raw) < 1e-15:
            return 1.0
        return abs(self.raw_values[0] - self.raw_values[-1]) / \
               max(abs(self.extrapolated - best_raw), 1e-15)


@dataclass
class MultiObservableResult:
    """Results for multiple observables extrapolated simultaneously."""
    observables: Dict[str, ExtrapolationResult]
    bond_dims: List[int]

    def summary(self) -> str:
        lines = ["Multi-Observable Richardson Extrapolation", "=" * 50]
        lines.append(f"Bond dims: {self.bond_dims}")
        for name, res in self.observables.items():
            rel = "✓" if res.is_reliable else "⚠"
            lines.append(
                f"  {rel} {name:20s}: {res.extrapolated:.8f} ± {res.uncertainty:.2e}"
            )
        return '\n'.join(lines)


# ---------------------------------------------------------------------------
# Core extrapolation engine
# ---------------------------------------------------------------------------

class RichardsonExtrapolator:
    """
    Multilevel Richardson extrapolation for MPS bond-dimension convergence.

    Parameters
    ----------
    ratio : float
        Geometric ratio between successive bond dimensions (default 2).
    alpha : float or None
        Known truncation error exponent. If None, it is estimated from data.
    min_reliable_improvement : float
        Minimum relative improvement between Richardson levels to be
        considered reliable (default 0.1 means 10% improvement).
    """

    def __init__(
        self,
        ratio: float = 2.0,
        alpha: Optional[float] = None,
        min_reliable_improvement: float = 0.1,
    ):
        self.ratio = ratio
        self.alpha = alpha
        self.min_reliable_improvement = min_reliable_improvement

    def estimate_alpha(self, bond_dims: List[int], values: List[float]) -> float:
        """
        Estimate the truncation error exponent α from observed convergence.

        Uses log-log regression of |f(χᵢ) - f(χᵢ₊₁)| vs χᵢ.
        """
        if len(values) < 3:
            return 1.0  # Default assumption

        diffs = [abs(values[i + 1] - values[i]) for i in range(len(values) - 1)]
        diffs = [d for d in diffs if d > 1e-15]  # Ignore numerically zero diffs

        if len(diffs) < 2:
            return 1.0

        log_chi = np.log([bond_dims[i] for i in range(len(diffs))])
        log_diff = np.log(diffs)

        # Linear regression in log-log space: log|Δf| = -α·log(χ) + const
        coeffs = np.polyfit(log_chi, log_diff, 1)
        alpha = -coeffs[0]  # Positive exponent

        # Clamp to physically reasonable range
        alpha = np.clip(alpha, 0.1, 10.0)
        return float(alpha)

    def _richardson_step(
        self,
        f_lo: float,
        f_hi: float,
        ratio: float,
        alpha: float,
    ) -> float:
        """
        Single Richardson extrapolation step canceling O(χ^{-α}) error.

        f_extrapolated = (r^α · f_hi - f_lo) / (r^α - 1)
        """
        r_alpha = ratio ** alpha
        return (r_alpha * f_hi - f_lo) / (r_alpha - 1.0)

    def extrapolate(
        self,
        bond_dims: List[int],
        values: List[float],
        alpha: Optional[float] = None,
    ) -> ExtrapolationResult:
        """
        Apply multilevel Richardson extrapolation.

        Parameters
        ----------
        bond_dims : list of int
            Bond dimensions in increasing order.
        values : list of float
            Expectation values at each bond dimension.
        alpha : float, optional
            Override for truncation error exponent.

        Returns
        -------
        ExtrapolationResult
        """
        n = len(values)
        if n < 2:
            raise ValueError("Need at least 2 data points for extrapolation.")

        # Estimate or use provided alpha
        if alpha is not None:
            used_alpha = alpha
        elif self.alpha is not None:
            used_alpha = self.alpha
        else:
            used_alpha = self.estimate_alpha(bond_dims, values)

        # Check geometric ratio consistency
        ratios = [bond_dims[i + 1] / bond_dims[i] for i in range(n - 1)]
        ratio_consistency = np.std(ratios) / np.mean(ratios) if len(ratios) > 1 else 0.0
        use_ratio = float(np.mean(ratios))

        # Build Richardson tableau
        # table[level][i] = extrapolated value at level using points i..i+level+1
        table = np.full((n, n), np.nan)
        table[0, :] = values  # Level 0 = raw values

        for level in range(1, n):
            for i in range(n - level):
                f_lo = table[level - 1, i]
                f_hi = table[level - 1, i + 1]
                # Use local ratio for this pair
                local_ratio = bond_dims[i + level] / bond_dims[i]
                table[level, i] = self._richardson_step(
                    f_lo, f_hi, local_ratio, used_alpha
                )

        # Best estimate: highest level, leftmost entry
        max_level = n - 1
        extrapolated = table[max_level, 0]

        # Uncertainty estimate: spread across extrapolation orders
        all_top_level = [table[max_level, 0]]
        alternative_estimates = []
        for lvl in range(max(1, max_level - 2), max_level + 1):
            val = table[lvl, 0]
            if not np.isnan(val):
                alternative_estimates.append(val)

        if len(alternative_estimates) > 1:
            uncertainty = float(np.std(alternative_estimates))
        else:
            # Fallback: use difference between last two raw values
            uncertainty = abs(values[-1] - values[-2]) / (use_ratio ** used_alpha - 1)

        # Convergence ratio diagnostics
        corrections = []
        for level in range(1, max_level + 1):
            if not np.isnan(table[level, 0]) and not np.isnan(table[level - 1, 0]):
                corr = abs(table[level, 0] - table[level - 1, 0])
                corrections.append(corr)

        conv_ratios = []
        for i in range(len(corrections) - 1):
            if corrections[i + 1] > 1e-15:
                conv_ratios.append(corrections[i] / corrections[i + 1])

        # Reliability checks
        notes = []
        is_reliable = True

        # Check 1: Monotone convergence in raw values
        diffs = [values[i + 1] - values[i] for i in range(n - 1)]
        if not (all(d >= 0 for d in diffs) or all(d <= 0 for d in diffs)):
            notes.append("Raw values are not monotonically converging with bond dimension.")
            is_reliable = False

        # Check 2: Richardson corrections decreasing
        if corrections and len(corrections) >= 2:
            if corrections[-1] > corrections[-2] * 1.5:
                notes.append("Richardson corrections are not decreasing — extrapolation may be unreliable.")
                is_reliable = False

        # Check 3: Uncertainty relative to signal
        signal = abs(extrapolated)
        if signal > 1e-10 and uncertainty / signal > 0.5:
            notes.append(
                f"Uncertainty ({uncertainty:.2e}) is large relative to signal ({signal:.2e}). "
                "Consider using more bond dimension points."
            )
            is_reliable = False

        # Check 4: Ratio consistency
        if ratio_consistency > 0.1:
            notes.append(
                f"Bond dimension ratios are not uniform (CV={ratio_consistency:.2f}). "
                "Results may be less accurate."
            )

        # Check 5: Alpha plausibility
        if used_alpha < 0.3 or used_alpha > 8.0:
            notes.append(
                f"Estimated α={used_alpha:.2f} is outside plausible range [0.3, 8.0]. "
                "Truncation error may not follow power law."
            )
            is_reliable = False

        if not notes:
            notes.append("All reliability checks passed.")

        return ExtrapolationResult(
            bond_dims=list(bond_dims),
            raw_values=list(values),
            extrapolated=float(np.real(extrapolated)),
            uncertainty=float(uncertainty),
            table=table,
            convergence_ratios=conv_ratios,
            is_reliable=is_reliable,
            reliability_notes=notes,
            alpha=used_alpha,
            ratio=use_ratio,
        )

    def extrapolate_multi(
        self,
        bond_dims: List[int],
        values_dict: Dict[str, List[float]],
        alpha: Optional[float] = None,
    ) -> MultiObservableResult:
        """
        Extrapolate multiple observables simultaneously.

        Parameters
        ----------
        bond_dims : list of int
        values_dict : dict mapping observable name → list of values
        alpha : float, optional

        Returns
        -------
        MultiObservableResult
        """
        results = {}
        for obs_name, vals in values_dict.items():
            try:
                results[obs_name] = self.extrapolate(bond_dims, vals, alpha=alpha)
            except Exception as e:
                logger.warning(f"Extrapolation failed for {obs_name}: {e}")

        return MultiObservableResult(observables=results, bond_dims=list(bond_dims))


# ---------------------------------------------------------------------------
# Multi-bond-dimension sweep runner
# ---------------------------------------------------------------------------

@dataclass
class SweepConfig:
    """
    Configuration for a multi-bond-dimension sweep.

    Attributes
    ----------
    base_chi : int
        Smallest bond dimension to simulate.
    ratio : float
        Geometric ratio between successive bond dimensions.
    n_levels : int
        Number of bond dimensions to simulate (including base).
    alpha : float or None
        Truncation error exponent (estimated if None).
    """
    base_chi: int = 64
    ratio: float = 2.0
    n_levels: int = 3
    alpha: Optional[float] = None

    @property
    def bond_dims(self) -> List[int]:
        return [int(self.base_chi * self.ratio ** i) for i in range(self.n_levels)]

    def effective_chi(self) -> int:
        """Equivalent bond dimension of the extrapolated result."""
        chi_max = self.bond_dims[-1]
        return int(chi_max * self.ratio)


class MultiChiRunner:
    """
    Runs a circuit at multiple bond dimensions and applies Richardson extrapolation.

    This is the main user-facing class for the extrapolation feature.

    Parameters
    ----------
    config : SweepConfig
        Bond dimension sweep configuration.
    extrapolator : RichardsonExtrapolator
        Extrapolation engine.
    verbose : bool
        Print progress.
    """

    def __init__(
        self,
        config: Optional[SweepConfig] = None,
        extrapolator: Optional[RichardsonExtrapolator] = None,
        verbose: bool = True,
    ):
        self.config = config or SweepConfig()
        self.extrapolator = extrapolator or RichardsonExtrapolator(
            ratio=self.config.ratio,
            alpha=self.config.alpha,
        )
        self.verbose = verbose

    def run(
        self,
        circuit,
        observables: Dict[str, Tuple[str, int]],
    ) -> MultiObservableResult:
        """
        Run circuit at all bond dimensions and extrapolate.

        Parameters
        ----------
        circuit : Circuit
            The circuit to simulate.
        observables : dict
            Mapping: label → (observable_type, site).
            E.g., {'Z0': ('Z', 0), 'Z1': ('Z', 1)}

        Returns
        -------
        MultiObservableResult
        """
        from ..circuits import MPSSimulator

        bond_dims = self.config.bond_dims
        values_dict = {name: [] for name in observables}
        raw_states = {}

        for chi in bond_dims:
            if self.verbose:
                print(f"  Simulating χ={chi}...", end=" ", flush=True)

            sim = MPSSimulator(chi=chi)
            state = sim.run(circuit)

            for name, (obs, site) in observables.items():
                val = sim.expectation_value(state, obs, site)
                values_dict[name].append(val)

            trunc = state.total_truncation_error()
            if self.verbose:
                print(f"done (trunc_err={trunc:.2e})")

            raw_states[chi] = state

        result = self.extrapolator.extrapolate_multi(
            bond_dims=bond_dims,
            values_dict=values_dict,
            alpha=self.config.alpha,
        )

        return result

    def run_custom(
        self,
        simulate_fn: Callable[[int], Dict[str, float]],
    ) -> MultiObservableResult:
        """
        Advanced: Run with a custom simulation function.

        Parameters
        ----------
        simulate_fn : callable
            Takes bond dimension χ, returns dict {obs_name: value}.

        Returns
        -------
        MultiObservableResult
        """
        bond_dims = self.config.bond_dims
        values_dict: Dict[str, List[float]] = {}

        for chi in bond_dims:
            if self.verbose:
                print(f"  Running custom sim χ={chi}...", end=" ", flush=True)

            results = simulate_fn(chi)

            for name, val in results.items():
                if name not in values_dict:
                    values_dict[name] = []
                values_dict[name].append(float(val))

            if self.verbose:
                print("done")

        return self.extrapolator.extrapolate_multi(
            bond_dims=bond_dims,
            values_dict=values_dict,
            alpha=self.config.alpha,
        )
