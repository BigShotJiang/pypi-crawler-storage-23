"""
Production test suite for mps_sim.

Covers physics correctness, gate algebra, numerical stability,
SVD truncation, canonicalization, extrapolation edge cases,
and state vector equivalence.
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import numpy as np
import subprocess
import traceback

results = {"passed": [], "failed": [], "skipped": []}

def test(name, fn, section=""):
    try:
        fn()
        results["passed"].append((section, name))
        print(f"  ✓ {name}")
    except Exception as e:
        results["failed"].append((section, name, str(e), traceback.format_exc()))
        print(f"  ✗ {name}: {e}")

def section(title):
    print(f"\n{'='*60}")
    print(f"  {title}")
    print(f"{'='*60}")
    return title

# ---------------------------------------------------------------------------
# Imports
# ---------------------------------------------------------------------------
from mps_sim import Circuit, MPSSimulator, MPS, RichardsonExtrapolator, SweepConfig, MultiChiRunner
from mps_sim.gates import (
    H, X, Y, Z, S, T, Sdg, Tdg, Rx, Ry, Rz, P,
    CNOT, CZ, SWAP, iSWAP, XX, YY, ZZ, CP, get_gate
)


# ===========================================================================
# 1. GATE ALGEBRA & IDENTITIES
# ===========================================================================
sec = section("1. Gate Algebra & Identities")

def check_unitary(G):
    assert np.allclose(G @ G.conj().T, np.eye(len(G)), atol=1e-12), "Not unitary"
    assert np.allclose(G.conj().T @ G, np.eye(len(G)), atol=1e-12), "Not unitary (dag side)"

# All single-qubit gates are unitary
for name, fn in [("H",H),("X",X),("Y",Y),("Z",Z),("S",S),("T",T),("Sdg",Sdg),("Tdg",Tdg)]:
    test(f"{name} is unitary", lambda f=fn: check_unitary(f()), sec)

for theta in [0, np.pi/6, np.pi/4, np.pi/3, np.pi/2, np.pi, 2*np.pi]:
    for name, fn in [("Rx",Rx),("Ry",Ry),("Rz",Rz)]:
        test(f"{name}({theta:.3f}) unitary", lambda f=fn,t=theta: check_unitary(f(t)), sec)

# Inverse relationships
test("S · S† = I",    lambda: np.allclose(S() @ Sdg(), np.eye(2), atol=1e-12) or True if np.allclose(S() @ Sdg(), np.eye(2)) else (_ for _ in ()).throw(AssertionError()), sec)
test("S · S† = I",    lambda: [None for _ in [None] if np.allclose(S() @ Sdg(), np.eye(2), atol=1e-12) or exec("raise AssertionError")], sec)

def t_inv():
    assert np.allclose(S() @ Sdg(), np.eye(2), atol=1e-12), "S·S† ≠ I"
    assert np.allclose(T() @ Tdg(), np.eye(2), atol=1e-12), "T·T† ≠ I"
    assert np.allclose(H() @ H(), np.eye(2), atol=1e-12), "H·H ≠ I"
    assert np.allclose(X() @ X(), np.eye(2), atol=1e-12), "X·X ≠ I"
    assert np.allclose(Z() @ Z(), np.eye(2), atol=1e-12), "Z·Z ≠ I"
test("Self-inverse / inverse pairs (H,X,Z,S·Sdg,T·Tdg)", t_inv, sec)

def t_pauli_algebra():
    # XY = iZ, YZ = iX, ZX = iY
    assert np.allclose(X() @ Y(), 1j * Z(), atol=1e-12), "XY ≠ iZ"
    assert np.allclose(Y() @ Z(), 1j * X(), atol=1e-12), "YZ ≠ iX"
    assert np.allclose(Z() @ X(), 1j * Y(), atol=1e-12), "ZX ≠ iY"
test("Pauli algebra (XY=iZ, YZ=iX, ZX=iY)", t_pauli_algebra, sec)

def t_hadamard_conjugation():
    # H·X·H = Z, H·Z·H = X, H·Y·H = -Y
    assert np.allclose(H() @ X() @ H(), Z(), atol=1e-12), "HXH ≠ Z"
    assert np.allclose(H() @ Z() @ H(), X(), atol=1e-12), "HZH ≠ X"
    assert np.allclose(H() @ Y() @ H(), -Y(), atol=1e-12), "HYH ≠ -Y"
test("Hadamard conjugation (HXH=Z, HZH=X, HYH=-Y)", t_hadamard_conjugation, sec)

def t_rotation_composition():
    # Rx(a)·Rx(b) = Rx(a+b)
    a, b = 0.7, 1.3
    assert np.allclose(Rx(a) @ Rx(b), Rx(a+b), atol=1e-12), "Rx composition failed"
    assert np.allclose(Ry(a) @ Ry(b), Ry(a+b), atol=1e-12), "Ry composition failed"
    assert np.allclose(Rz(a) @ Rz(b), Rz(a+b), atol=1e-12), "Rz composition failed"
test("Rotation composition Rx(a)·Rx(b) = Rx(a+b)", t_rotation_composition, sec)

def t_rx_to_x():
    # Rx(π) = -iX (up to global phase)
    assert np.allclose(Rx(np.pi), -1j * X(), atol=1e-12), f"Rx(π) ≠ -iX: {Rx(np.pi)}"
test("Rx(π) = -iX", t_rx_to_x, sec)

def t_2q_unitarity():
    for name, fn in [("CNOT",CNOT),("CZ",CZ),("SWAP",SWAP),("iSWAP",iSWAP)]:
        G = fn().reshape(4, 4)
        assert np.allclose(G @ G.conj().T, np.eye(4), atol=1e-12), f"{name} not unitary"
test("2-qubit gates unitary (CNOT,CZ,SWAP,iSWAP)", t_2q_unitarity, sec)

def t_cnot_self_inverse():
    G = CNOT().reshape(4,4)
    assert np.allclose(G @ G, np.eye(4), atol=1e-12), "CNOT² ≠ I"
test("CNOT² = I", t_cnot_self_inverse, sec)

def t_swap_self_inverse():
    G = SWAP().reshape(4,4)
    assert np.allclose(G @ G, np.eye(4), atol=1e-12), "SWAP² ≠ I"
test("SWAP² = I", t_swap_self_inverse, sec)


# ===========================================================================
# 2. GATE APPLICATION CORRECTNESS (vs exact numpy)
# ===========================================================================
sec = section("2. Gate Application vs Exact numpy")

def exact_apply(gate_matrix, statevec, qubits, n):
    """Apply gate to statevector exactly using numpy."""
    sv = statevec.copy()
    # Build full unitary via tensor product
    if len(qubits) == 1:
        ops = [np.eye(2)] * n
        ops[qubits[0]] = gate_matrix
        U = ops[0]
        for op in ops[1:]:
            U = np.kron(U, op)
        return U @ sv
    elif len(qubits) == 2:
        q1, q2 = qubits
        # Build 4x4 gate in computational basis
        G = gate_matrix.reshape(4, 4)
        # Full 2^n x 2^n unitary
        U = np.eye(2**n, dtype=complex)
        for i in range(2**n):
            for j in range(2**n):
                # Extract bits for q1, q2
                bi1 = (i >> (n-1-q1)) & 1
                bi2 = (i >> (n-1-q2)) & 1
                bj1 = (j >> (n-1-q1)) & 1
                bj2 = (j >> (n-1-q2)) & 1
                # Only interact if other bits match
                same_others = True
                for q in range(n):
                    if q != q1 and q != q2:
                        if ((i >> (n-1-q)) & 1) != ((j >> (n-1-q)) & 1):
                            same_others = False
                            break
                if same_others:
                    out_idx = bi1 * 2 + bi2
                    in_idx  = bj1 * 2 + bj2
                    U[i, j] = G[out_idx, in_idx]
                else:
                    U[i, j] = 1.0 if i == j else 0.0
        return U @ sv

def mps_sv(circuit, chi=512):
    """Get statevector from MPS simulation."""
    state = MPSSimulator(chi=chi).run(circuit)
    return state.to_statevector()

n = 4
zero_sv = np.zeros(2**n, dtype=complex); zero_sv[0] = 1.0

def check_gate_vs_exact(gate_name, gate_matrix, qubits, n=4):
    """Apply a gate via MPS and via exact numpy, compare."""
    c = Circuit(n)
    # Add some rotation first to make state non-trivial
    for q in range(n):
        c.ry(0.3 * (q + 1), q)

    # Get state after rotations
    sv_after_rot = mps_sv(c, chi=512)

    # Apply gate via MPS
    if len(qubits) == 1:
        c_gate = Circuit(n)
        for q in range(n): c_gate.ry(0.3 * (q + 1), q)
        c_gate._add(gate_name, qubits)
    else:
        c_gate = Circuit(n)
        for q in range(n): c_gate.ry(0.3 * (q + 1), q)
        c_gate._add(gate_name, qubits)
    sv_mps = mps_sv(c_gate, chi=512)

    # Apply gate via exact numpy
    sv_exact = exact_apply(gate_matrix, sv_after_rot, qubits, n)

    assert np.allclose(sv_mps, sv_exact, atol=1e-8), \
        f"{gate_name} on qubits {qubits}: MPS vs exact mismatch\n  MPS:   {sv_mps[:4]}\n  Exact: {sv_exact[:4]}"

test("H gate matches exact", lambda: check_gate_vs_exact("H", H(), [0]), sec)
test("X gate matches exact", lambda: check_gate_vs_exact("X", X(), [1]), sec)
test("Y gate matches exact", lambda: check_gate_vs_exact("Y", Y(), [2]), sec)
test("Z gate matches exact", lambda: check_gate_vs_exact("Z", Z(), [3]), sec)
test("S gate matches exact", lambda: check_gate_vs_exact("S", S(), [0]), sec)
test("T gate matches exact", lambda: check_gate_vs_exact("T", T(), [1]), sec)

def t_cnot_exact():
    c = Circuit(4)
    c.h(0).h(1)
    sv_before = mps_sv(c)
    c2 = Circuit(4); c2.h(0).h(1).cx(0, 1)
    sv_mps = mps_sv(c2)
    sv_exact = exact_apply(CNOT().reshape(4,4), sv_before, [0,1], 4)
    assert np.allclose(sv_mps, sv_exact, atol=1e-8)
test("CNOT matches exact", t_cnot_exact, sec)

def t_cz_exact():
    c = Circuit(4); c.h(0).h(2)
    sv_before = mps_sv(c)
    c2 = Circuit(4); c2.h(0).h(2).cz(1, 2)
    sv_mps = mps_sv(c2)
    # CZ on qubits 1,2 with qubit 1 in |0>: no effect on superposition in 0,2
    sv_exact = exact_apply(CZ().reshape(4,4), sv_before, [1,2], 4)
    assert np.allclose(sv_mps, sv_exact, atol=1e-8)
test("CZ matches exact", t_cz_exact, sec)

def t_rx_exact():
    theta = 0.7
    c = Circuit(3)
    c.h(0).h(1).h(2)
    sv_before = mps_sv(c)
    c2 = Circuit(3); c2.h(0).h(1).h(2).rx(theta, 1)
    sv_mps = mps_sv(c2)
    sv_exact = exact_apply(Rx(theta), sv_before, [1], 3)
    assert np.allclose(sv_mps, sv_exact, atol=1e-8)
test("Rx(0.7) matches exact", t_rx_exact, sec)

# Verify all 2^n basis states for X gate on each qubit
def t_x_all_basis():
    n = 3
    for q in range(n):
        for basis in range(2**n):
            # Prepare basis state
            c = Circuit(n)
            for bit in range(n):
                if (basis >> (n-1-bit)) & 1:
                    c.x(bit)
            c.x(q)  # Apply X
            sv = mps_sv(c)
            # Expected: flip bit q
            expected_idx = basis ^ (1 << (n-1-q))
            assert abs(sv[expected_idx] - 1.0) < 1e-10, \
                f"X on q{q}, basis|{basis:03b}>: expected |{expected_idx:03b}>, got {sv}"
test("X gate on all 3-qubit basis states", t_x_all_basis, sec)


# ===========================================================================
# 3. PHYSICS CORRECTNESS
# ===========================================================================
sec = section("3. Physics Correctness")

def t_bloch_sphere():
    """For any single-qubit state: <X>² + <Y>² + <Z>² ≤ 1"""
    np.random.seed(0)
    for _ in range(20):
        theta, phi = np.random.uniform(0, np.pi), np.random.uniform(0, 2*np.pi)
        c = Circuit(1)
        c.ry(theta, 0).rz(phi, 0)
        state = MPSSimulator(16).run(c)
        x = state.expectation_pauli_x(0)
        y = state.expectation_pauli_y(0)
        z = state.expectation_pauli_z(0)
        r2 = x**2 + y**2 + z**2
        assert r2 <= 1.0 + 1e-10, f"Bloch sphere violated: |r|²={r2:.6f} > 1"
test("Bloch sphere: <X>²+<Y>²+<Z>² ≤ 1 for all pure states", t_bloch_sphere, sec)

def t_bloch_pure_state():
    """For a pure single-qubit state: <X>² + <Y>² + <Z>² = 1 exactly"""
    np.random.seed(42)
    for _ in range(10):
        theta, phi = np.random.uniform(0, np.pi), np.random.uniform(0, 2*np.pi)
        c = Circuit(1)
        c.ry(theta, 0).rz(phi, 0)
        state = MPSSimulator(16).run(c)
        x = state.expectation_pauli_x(0)
        y = state.expectation_pauli_y(0)
        z = state.expectation_pauli_z(0)
        r2 = x**2 + y**2 + z**2
        assert abs(r2 - 1.0) < 1e-10, f"Pure state Bloch sphere: |r|²={r2:.8f} ≠ 1"
test("Bloch sphere: |r|² = 1 for all pure single-qubit states", t_bloch_pure_state, sec)

def t_bell_correlations():
    """Bell state |Φ+>: <ZZ>=1, <XX>=1, <YY>=-1, <Z>=0, <X>=0"""
    c = Circuit(2); c.h(0).cx(0,1)
    state = MPSSimulator(64).run(c)
    # <Z> on each qubit should be 0
    assert abs(state.expectation_pauli_z(0)) < 1e-10, "<Z0> ≠ 0 for Bell state"
    assert abs(state.expectation_pauli_z(1)) < 1e-10, "<Z1> ≠ 0 for Bell state"
    # <X> on each qubit should be 0
    assert abs(state.expectation_pauli_x(0)) < 1e-10, "<X0> ≠ 0 for Bell state"
    # <ZZ> = +1 for |Φ+>
    sv = state.to_statevector()
    # <ZZ> = sum_i P(|i>) * Z_eigenval(q0) * Z_eigenval(q1)
    zz = sum(abs(sv[i])**2 * (1-2*((i>>1)&1)) * (1-2*(i&1)) for i in range(4))
    assert abs(zz - 1.0) < 1e-10, f"<ZZ> = {zz} ≠ 1 for Bell state"
    # <XX> = +1 for |Φ+>
    xx = sum(abs(sv[i])**2 * (1-2*bin(i).count('1')%2) for i in range(4))  # simplified
    # Use exact formula: <XX> via Hadamard basis
    c2 = Circuit(2); c2.h(0).cx(0,1).h(0).h(1)
    sv2 = MPSSimulator(64).run(c2).to_statevector()
    xx_exact = sum(abs(sv2[i])**2 * (1-2*((i>>1)&1)) * (1-2*(i&1)) for i in range(4))
    assert abs(xx_exact - 1.0) < 1e-10, f"<XX> measured in Bell basis = {xx_exact} ≠ 1"
test("Bell state correlations (<ZZ>=1, <Z>=0, <X>=0)", t_bell_correlations, sec)

def t_ghz_parity():
    """GHZ state has definite parity: prob(even # of |1>s) = 1"""
    n = 6
    c = Circuit(n); c.h(0)
    for i in range(n-1): c.cx(i,i+1)
    sv = MPSSimulator(64).run(c).to_statevector()
    for i, amp in enumerate(sv):
        if abs(amp) > 1e-10:
            parity = bin(i).count('1') % 2
            assert parity == 0, f"GHZ has odd-parity component at |{i:06b}>: amp={amp}"
test("GHZ state parity conservation (all even-parity)", t_ghz_parity, sec)

def t_product_state_expectations():
    """For a product state |+>⊗|0>: <X0>=1, <Z0>=0, <Z1>=1, <X1>=0"""
    c = Circuit(2); c.h(0)
    state = MPSSimulator(16).run(c)
    assert abs(state.expectation_pauli_x(0) - 1.0) < 1e-10, "<X0> ≠ 1"
    assert abs(state.expectation_pauli_z(0))        < 1e-10, "<Z0> ≠ 0"
    assert abs(state.expectation_pauli_z(1) - 1.0) < 1e-10, "<Z1> ≠ 1"
    assert abs(state.expectation_pauli_x(1))        < 1e-10, "<X1> ≠ 0"
test("Product state |+>⊗|0> expectation values", t_product_state_expectations, sec)

def t_phase_kickback():
    """Phase kickback: CZ flips control qubit phase when target = |1>.
    H·CZ(ctrl,tgt)·H with tgt=|1>, ctrl=|+>:
    CZ|+1> = (|01>-|11>)/sqrt(2) = |->|1>, then H on ctrl gives |1>.
    Final state: |11>."""
    c = Circuit(2)
    c.x(1)    # target = |1>
    c.h(0)    # control = |+>
    c.cz(0,1) # phase kickback: |+>|1> -> |->|1>
    c.h(0)    # H|-> = |1>, so control becomes |1>
    sv = MPSSimulator(16).run(c).to_statevector()
    # State should be |11> (index 3)
    assert abs(abs(sv[3]) - 1.0) < 1e-10, \
        f"Phase kickback: expected |11>, got sv={sv}"
test("Phase kickback via CZ", t_phase_kickback, sec)

def t_no_cloning():
    """Verify MPS can't clone: CNOT|+0> = |Φ+>, not |+>|+>"""
    c = Circuit(2); c.h(0).cx(0,1)
    sv = MPSSimulator(64).run(c).to_statevector()
    # Should be (|00>+|11>)/√2, not (|00>+|01>+|10>+|11>)/2
    assert abs(sv[1]) < 1e-10, f"|01> component non-zero: {sv[1]}"
    assert abs(sv[2]) < 1e-10, f"|10> component non-zero: {sv[2]}"
test("No-cloning: CNOT|+0> = Bell state, not |+>⊗|+>", t_no_cloning, sec)

def t_teleportation_fidelity():
    """Quantum teleportation circuit: probability of each measurement outcome = 0.25"""
    theta = 0.7
    n = 3  # q0=state, q1q2=Bell pair
    c = Circuit(n)
    c.ry(theta, 0)        # prepare state on q0
    c.h(1).cx(1, 2)       # Bell pair on q1,q2
    c.cx(0, 1).h(0)       # Bell measurement on q0,q1
    sv = MPSSimulator(64).run(c).to_statevector()
    # For 3 qubits: sv has 2^3=8 elements, indexed as q0q1q2 in binary
    # p(q0=0,q1=0) = sum over q2 of |sv[0b00q2]|^2 = |sv[0]|^2 + |sv[1]|^2
    # For any input state, each of the 4 Bell outcomes has probability 0.25
    p00 = abs(sv[0])**2 + abs(sv[1])**2  # q0=0, q1=0, q2=0 or 1
    assert abs(p00 - 0.25) < 1e-8, f"Teleportation: p(00) = {p00:.6f} ≠ 0.25"
test("Teleportation: p(00 outcome) = 0.25 for any input state", t_teleportation_fidelity, sec)


# ===========================================================================
# 4. SVD TRUNCATION & BOND DIMENSION
# ===========================================================================
sec = section("4. SVD Truncation & Bond Dimension")

def t_trunc_error_nonneg():
    """Truncation error is always non-negative."""
    for chi in [4, 8, 16]:
        n = 6; c = Circuit(n); c.h(0)
        for i in range(n-1): c.cx(i,i+1)
        state = MPSSimulator(chi=chi).run(c)
        for err in state.truncation_errors:
            assert err >= -1e-15, f"Negative truncation error: {err}"
        assert state.total_truncation_error() >= -1e-15
test("Truncation errors are non-negative", t_trunc_err_nonneg := t_trunc_error_nonneg, sec)

def t_bond_dim_caps():
    """Bond dimension never exceeds chi."""
    for chi in [2, 4, 8, 16]:
        n = 8; c = Circuit(n); c.h(0)
        for i in range(n-1): c.cx(i,i+1)
        for i in range(n): c.ry(0.5, i)
        for i in range(n-1): c.cx(i,i+1)
        state = MPSSimulator(chi=chi).run(c)
        for d in state.bond_dimensions():
            assert d <= chi, f"Bond dim {d} exceeds chi={chi}"
test("Bond dimensions never exceed chi", t_bond_dim_caps, sec)

def t_trunc_decreases_with_chi():
    """Truncation error decreases (or stays 0) as chi increases."""
    n = 6; c = Circuit(n); c.h(0)
    for i in range(n-1): c.cx(i,i+1)
    for i in range(n): c.ry(0.4, i)
    for i in range(n-1): c.cx(i,i+1)

    prev_err = float("inf")
    for chi in [4, 8, 16, 32]:
        state = MPSSimulator(chi=chi).run(c)
        err = state.total_truncation_error()
        assert err <= prev_err + 1e-12, f"Truncation error increased with chi: chi={chi}, err={err:.2e} > prev={prev_err:.2e}"
        prev_err = err
test("Truncation error decreases monotonically with chi", t_trunc_decreases_with_chi, sec)

def t_product_state_zero_error():
    """Product state (no entanglement) has zero truncation error at any chi."""
    c = Circuit(6)
    for i in range(6): c.ry(0.4 * i, i)
    state = MPSSimulator(chi=4).run(c)
    assert state.total_truncation_error() < 1e-14, \
        f"Product state has nonzero truncation error: {state.total_truncation_error()}"
test("Product state has zero truncation error", t_product_state_zero_error, sec)

def t_expectation_converges_with_chi():
    """Expectation value converges to a fixed point as chi increases."""
    n = 6; c = Circuit(n); c.h(0)
    for i in range(n-1): c.cx(i,i+1)
    for i in range(n): c.ry(0.3, i)
    for i in range(n-1): c.cx(i,i+1)

    z_vals = []
    for chi in [4, 8, 16, 32, 64]:
        state = MPSSimulator(chi=chi).run(c)
        z_vals.append(state.expectation_pauli_z(0))

    # Each chi should bring us closer to the chi=64 value
    diffs = [abs(z_vals[i] - z_vals[-1]) for i in range(len(z_vals)-1)]
    for i in range(len(diffs)-1):
        assert diffs[i+1] <= diffs[i] + 1e-10, \
            f"Convergence non-monotone: chi seq diffs={diffs}"
test("<Z> converges monotonically with increasing chi", t_expectation_converges_with_chi, sec)

def t_max_entanglement_bond_dim():
    """A maximally entangled n-qubit GHZ state has bond dim min(2^k, 2^(n-k)) at bond k."""
    n = 6; c = Circuit(n); c.h(0)
    for i in range(n-1): c.cx(i,i+1)
    state = MPSSimulator(chi=64).run(c)
    bonds = state.bond_dimensions()
    # GHZ state: rank-2 on every bond (one Schmidt coefficient = 1/sqrt(2))
    for i, d in enumerate(bonds):
        assert d == 2, f"GHZ bond dim at bond {i} should be 2, got {d}"
test("GHZ state has bond dim 2 on every bond (with chi≥2)", t_max_entanglement_bond_dim, sec)


# ===========================================================================
# 5. MPS CANONICALIZATION
# ===========================================================================
sec = section("5. MPS Canonicalization")

def t_canonicalize_preserves_state():
    """Canonicalize should not change the physical state."""
    n = 5; c = Circuit(n); c.h(0)
    for i in range(n-1): c.cx(i,i+1)
    for i in range(n): c.ry(0.3, i)

    state = MPSSimulator(chi=32).run(c)
    sv_before = state.to_statevector()

    for center in range(n):
        state2 = state.copy()
        state2.canonicalize(center)
        sv_after = state2.to_statevector()
        assert np.allclose(sv_before, sv_after, atol=1e-10), \
            f"Canonicalize(center={center}) changed state"
test("Canonicalize preserves physical state for all centers", t_canonicalize_preserves_state, sec)

def t_canonicalize_center_normalized():
    """After canonicalize(c), tensor at center should have unit Frobenius norm (mixed-canonical)."""
    n = 5; c = Circuit(n); c.h(0)
    for i in range(n-1): c.cx(i,i+1)
    state = MPSSimulator(chi=32).run(c)

    for center in range(n):
        state2 = state.copy()
        state2.canonicalize(center)
        t = state2.get_tensor(center)
        # In mixed-canonical form, the center tensor has norm = 1 iff state is normalized
        norm = state2._norm_mps()
        assert abs(norm - 1.0) < 1e-8, f"After canonicalize({center}), norm={norm}"
test("State remains normalized after canonicalize", t_canonicalize_center_normalized, sec)


# ===========================================================================
# 6. NORMALIZATION & NUMERICAL STABILITY
# ===========================================================================
sec = section("6. Normalization & Numerical Stability")

def t_norm_product_state():
    """Product states have norm 1 exactly."""
    np.random.seed(1)
    for trial in range(5):
        n = 8; c = Circuit(n)
        for q in range(n): c.ry(np.random.uniform(0, np.pi), q)
        state = MPSSimulator(chi=4).run(c)
        norm = state._norm_mps()
        assert abs(norm - 1.0) < 1e-10, f"Product state norm = {norm}"
test("Product state norm = 1 exactly (5 random trials)", t_norm_product_state, sec)

def t_norm_after_2q_gates():
    """Norm preserved after many 2-qubit gates."""
    np.random.seed(42)
    n = 8; c = Circuit(n)
    for _ in range(50):
        q = np.random.randint(n)
        c.ry(np.random.uniform(0, 2*np.pi), q)
        if np.random.random() < 0.5 and q < n-1:
            c.cx(q, q+1)
    state = MPSSimulator(chi=32).run(c)
    norm = state._norm_mps()
    assert abs(norm - 1.0) < 1e-8, f"Norm after many gates = {norm}"
test("Norm preserved after 50 mixed single+2Q gates", t_norm_after_2q_gates, sec)

def t_norm_high_entanglement():
    """With moderate truncation (chi=16 on a 10-qubit circuit), norm stays close to 1."""
    n = 10; c = Circuit(n)
    for _ in range(3):
        c.h(0)
        for i in range(n-1): c.cx(i, i+1)
        for i in range(n): c.ry(0.5, i)
    state = MPSSimulator(chi=16).run(c)
    norm = state._norm_mps()
    # Truncation error reduces norm below 1; with chi=16 it should stay reasonably close
    assert 0.5 < norm <= 1.0 + 1e-10, f"High-truncation norm = {norm} out of (0.5, 1]"
test("Norm ≈ 1 even with significant truncation", t_norm_high_entanglement, sec)

def t_deep_circuit_stability():
    """Deep circuit (100+ gates) stays numerically stable."""
    np.random.seed(99)
    n = 6; c = Circuit(n)
    for _ in range(100):
        q = np.random.randint(n)
        c.ry(np.random.uniform(0, 2*np.pi), q)
        if np.random.random() < 0.4 and q < n-1: c.cx(q, q+1)
    state = MPSSimulator(chi=16).run(c)
    norm = state._norm_mps()
    assert abs(norm - 1.0) < 1e-6, f"Deep circuit norm = {norm}"
    for q in range(n):
        for m in [state.expectation_pauli_x, state.expectation_pauli_y, state.expectation_pauli_z]:
            v = m(q)
            assert abs(v) <= 1.0 + 1e-10, f"Expectation {v} out of [-1,1] at site {q}"
test("Deep circuit (100 gates) stays numerically stable", t_deep_circuit_stability, sec)

def t_repeated_gate_stability():
    """Applying the same gate many times stays numerically stable."""
    # Rz(θ) = diag(e^{-iθ/2}, e^{iθ/2}), so Rz(4π/k)^k = Rz(4π) = I
    k = 100
    c = Circuit(1)
    for _ in range(k): c.rz(4*np.pi/k, 0)
    sv = MPSSimulator(16).run(c).to_statevector()
    # Should return to |0> (up to global phase)
    assert abs(abs(sv[0]) - 1.0) < 1e-10, f"Rz(4π/100)^100 ≠ I: sv={sv}"
test("Rz(2π/100)^100 = I (repeated gate stability)", t_repeated_gate_stability, sec)


# ===========================================================================
# 7. ALL GATES PRODUCE CORRECT OUTPUT ON KNOWN STATES
# ===========================================================================
sec = section("7. Gate Output on Known Input States")

def sv_after(n, gates_fn, chi=256):
    c = Circuit(n); gates_fn(c)
    return MPSSimulator(chi=chi).run(c).to_statevector()

# Single qubit
test("X|0> = |1>",    lambda: np.allclose(sv_after(1,lambda c:c.x(0)),   [0,1], atol=1e-10), sec)
test("X|1> = |0>",    lambda: np.allclose(sv_after(1,lambda c:c.x(0).x(0).x(0)), [0,1], atol=1e-10), sec)
test("Y|0> = i|1>",   lambda: np.allclose(sv_after(1,lambda c:c.y(0)),   [0,1j], atol=1e-10), sec)
test("Z|1> = -|1>",   lambda: np.allclose(sv_after(1,lambda c:c.x(0).z(0)), [0,-1], atol=1e-10), sec)
test("H|0> = |+>",    lambda: np.allclose(sv_after(1,lambda c:c.h(0)),   [1,1]/np.sqrt(2), atol=1e-10), sec)
test("H|1> = |->",    lambda: np.allclose(sv_after(1,lambda c:c.x(0).h(0)), [1,-1]/np.sqrt(2), atol=1e-10), sec)
test("S|0> = |0>",    lambda: np.allclose(sv_after(1,lambda c:c.s(0)),   [1,0], atol=1e-10), sec)
test("S|1> = i|1>",   lambda: np.allclose(sv_after(1,lambda c:c.x(0).s(0)), [0,1j], atol=1e-10), sec)
test("T|1> = e^{iπ/4}|1>", lambda: np.allclose(sv_after(1,lambda c:c.x(0).t(0)), [0, np.exp(1j*np.pi/4)], atol=1e-10), sec)

# Two qubit on known states
test("CNOT|00> = |00>", lambda: np.allclose(sv_after(2,lambda c:c.cx(0,1)), [1,0,0,0], atol=1e-10), sec)
test("CNOT|10> = |11>", lambda: np.allclose(sv_after(2,lambda c:c.x(0).cx(0,1)), [0,0,0,1], atol=1e-10), sec)
test("CNOT|01> = |01>", lambda: np.allclose(sv_after(2,lambda c:c.x(1).cx(0,1)), [0,1,0,0], atol=1e-10), sec)
test("CNOT|11> = |10>", lambda: np.allclose(sv_after(2,lambda c:c.x(0).x(1).cx(0,1)), [0,0,1,0], atol=1e-10), sec)
test("CZ|11> = -|11>",  lambda: np.allclose(sv_after(2,lambda c:c.x(0).x(1).cz(0,1)), [0,0,0,-1], atol=1e-10), sec)
test("SWAP|10> = |01>", lambda: np.allclose(sv_after(2,lambda c:c.x(0).swap(0,1)), [0,1,0,0], atol=1e-10), sec)
test("SWAP|01> = |10>", lambda: np.allclose(sv_after(2,lambda c:c.x(1).swap(0,1)), [0,0,1,0], atol=1e-10), sec)

def t_iswap():
    sv = sv_after(2, lambda c: c.x(0).iswap(0,1))  # iSWAP|10> = i|01>
    assert abs(sv[1] - 1j) < 1e-10, f"iSWAP|10> ≠ i|01>: sv={sv}"
test("iSWAP|10> = i|01>", t_iswap, sec)


# ===========================================================================
# 8. NON-ADJACENT GATE HANDLING
# ===========================================================================
sec = section("8. Non-Adjacent Gate Handling")

def t_nonadj_same_as_adjacent():
    """Gate on qubits (0,2) via SWAP chain = gate on (0,1) with permuted qubits."""
    # Apply CNOT(0,2) by swapping qubit 2 to position 1, applying CNOT(0,1), swapping back
    # Compare to direct CNOT(0,2) via simulator

    n = 4
    # Build state with known superposition
    c = Circuit(n)
    c.h(0).h(1).h(2).h(3)

    sv_base = MPSSimulator(chi=256).run(c).to_statevector()

    # Direct CNOT(0,2) via simulator
    c1 = Circuit(n); c1.h(0).h(1).h(2).h(3).cx(0,2)
    sv1 = MPSSimulator(chi=256).run(c1).to_statevector()

    # Manual: SWAP(1,2), CNOT(0,1), SWAP(1,2)
    c2 = Circuit(n); c2.h(0).h(1).h(2).h(3)
    c2.swap(1,2).cx(0,1).swap(1,2)
    sv2 = MPSSimulator(chi=256).run(c2).to_statevector()

    assert np.allclose(sv1, sv2, atol=1e-9), \
        f"Non-adjacent CNOT(0,2) ≠ SWAP·CNOT·SWAP:\n  sv1={sv1}\n  sv2={sv2}"
test("CNOT(0,2) = SWAP(1,2)·CNOT(0,1)·SWAP(1,2)", t_nonadj_same_as_adjacent, sec)

def t_nonadj_norm():
    """Non-adjacent gate preserves normalization."""
    n = 5
    c = Circuit(n)
    for i in range(n): c.ry(0.4*i, i)
    c.cx(0, 3)  # non-adjacent
    c.cx(1, 4)  # non-adjacent
    state = MPSSimulator(chi=64).run(c)
    norm = state._norm_mps()
    assert abs(norm - 1.0) < 1e-8, f"Norm after non-adjacent gates = {norm}"
test("Non-adjacent gates preserve normalization", t_nonadj_norm, sec)


# ===========================================================================
# 9. CIRCUIT PROPERTIES
# ===========================================================================
sec = section("9. Circuit Properties")

def t_depth_calculation():
    c = Circuit(4)
    c.h(0).h(1).h(2).h(3)   # depth 1 (parallel)
    c.cx(0,1).cx(2,3)        # depth 2 (parallel)
    c.cx(1,2)                # depth 3
    assert c.depth() == 3, f"Depth should be 3, got {c.depth()}"
test("Circuit depth calculation", t_depth_calculation, sec)

def t_two_qubit_count():
    c = Circuit(4)
    c.h(0).h(1)
    c.cx(0,1).cz(1,2).swap(2,3)
    assert c.two_qubit_count() == 3, f"2Q count should be 3, got {c.two_qubit_count()}"
test("Two-qubit gate count", t_two_qubit_count, sec)

def t_large_circuit_doesnt_crash():
    """Large circuit (n=20, 200 gates) completes without error."""
    np.random.seed(11)
    n = 20; c = Circuit(n)
    for _ in range(200):
        q = np.random.randint(n)
        c.ry(np.random.uniform(0, np.pi), q)
        if np.random.random() < 0.3 and q < n-1: c.cx(q, q+1)
    state = MPSSimulator(chi=16).run(c)
    assert len(state.bond_dimensions()) == n - 1
test("n=20 circuit with 200 gates completes without error", t_large_circuit_doesnt_crash, sec)

def t_fluent_builder():
    c = (Circuit(5)
         .h(0).x(1).y(2).z(3).s(4)
         .cx(0,1).cz(1,2).swap(3,4)
         .rx(0.5,0).ry(0.6,1).rz(0.7,2)
         .sdg(3).tdg(4))
    assert len(c.instructions) == 13
    assert c.n == 5
test("Fluent builder API chains correctly", t_fluent_builder, sec)


# ===========================================================================
# 10. RICHARDSON EXTRAPOLATION — EDGE CASES
# ===========================================================================
sec = section("10. Richardson Extrapolation Edge Cases")

def t_perfect_convergence():
    """With zero error (all values identical), extrapolation = raw value, uncertainty = 0."""
    chi_list = [16, 32, 64]
    values = [0.42, 0.42, 0.42]  # already converged
    result = RichardsonExtrapolator().extrapolate(chi_list, values)
    assert abs(result.extrapolated - 0.42) < 1e-10
    assert result.uncertainty < 1e-10
test("Perfect convergence: extrapolated = raw, uncertainty = 0", t_perfect_convergence, sec)

def t_different_ratios():
    """Extrapolation works for ratio ≠ 2 (e.g. ratio=3)."""
    true_val = 0.314159
    alpha = 1.0
    chi_list = [10, 30, 90]  # ratio = 3
    values = [true_val + 1.0/c**alpha for c in chi_list]
    result = RichardsonExtrapolator(ratio=3.0, alpha=1.0).extrapolate(chi_list, values, alpha=1.0)
    assert abs(result.extrapolated - true_val) < 1e-8
test("Richardson works with ratio=3 (not just ratio=2)", t_different_ratios, sec)

def t_higher_alpha():
    """Extrapolation works for higher truncation exponent (alpha=2)."""
    true_val = 0.5
    alpha = 2.0
    chi_list = [16, 32, 64, 128]
    values = [true_val + 1.0/c**alpha for c in chi_list]
    result = RichardsonExtrapolator(alpha=2.0).extrapolate(chi_list, values, alpha=2.0)
    assert abs(result.extrapolated - true_val) < 1e-10
test("Richardson works for alpha=2 (faster decaying error)", t_higher_alpha, sec)

def t_negative_true_value():
    """Extrapolation works for negative expectation values."""
    true_val = -0.7
    chi_list = [16, 32, 64]
    values = [true_val + 0.5/c for c in chi_list]
    result = RichardsonExtrapolator(alpha=1.0).extrapolate(chi_list, values, alpha=1.0)
    assert abs(result.extrapolated - true_val) < 1e-6
test("Richardson works for negative true values", t_negative_true_value, sec)

def t_extrapolation_better_than_raw():
    """Extrapolated value is closer to true value than any raw value."""
    true_val = 0.271828
    chi_list = [8, 16, 32]
    values = [true_val + 2.0/c**1.5 for c in chi_list]
    result = RichardsonExtrapolator().extrapolate(chi_list, values)
    raw_best_err = abs(values[-1] - true_val)
    extrap_err = abs(result.extrapolated - true_val)
    assert extrap_err < raw_best_err, \
        f"Extrapolated error {extrap_err:.2e} ≥ raw best error {raw_best_err:.2e}"
test("Extrapolated error < best raw error", t_extrapolation_better_than_raw, sec)

def t_summary_output():
    """ExtrapolationResult.summary() runs without error."""
    chi_list = [16, 32, 64]
    values = [0.5 + 1.0/c for c in chi_list]
    result = RichardsonExtrapolator().extrapolate(chi_list, values)
    s = result.summary()
    assert "Extrapolated" in s and "Bond dimensions" in s
test("ExtrapolationResult.summary() produces correct output", t_summary_output, sec)

def t_multi_obs_summary():
    """MultiObservableResult.summary() runs without error."""
    chi_list = [16, 32, 64]
    vd = {f"Z{i}": [0.1*i + 1.0/c for c in chi_list] for i in range(4)}
    result = RichardsonExtrapolator().extrapolate_multi(chi_list, vd)
    s = result.summary()
    assert "Z0" in s and "Z3" in s
test("MultiObservableResult.summary() produces correct output", t_multi_obs_summary, sec)

def t_improvement_factor():
    """improvement_factor() > 1 when extrapolation helps."""
    chi_list = [8, 16, 32]
    values = [0.5 + 2.0/c for c in chi_list]
    result = RichardsonExtrapolator(alpha=1.0).extrapolate(chi_list, values, alpha=1.0)
    assert result.improvement_factor() > 1.0
test("improvement_factor() > 1 for power-law data", t_improvement_factor, sec)


# ===========================================================================
# 11. SWEEP CONFIG & MULTI-CHI RUNNER
# ===========================================================================
sec = section("11. SweepConfig & MultiChiRunner")

def t_bond_dims_geometric():
    for base in [8, 16, 32]:
        for ratio in [2.0, 3.0]:
            for levels in [2, 3, 4]:
                cfg = SweepConfig(base_chi=base, ratio=ratio, n_levels=levels)
                bd = cfg.bond_dims
                assert len(bd) == levels
                for i in range(levels-1):
                    assert abs(bd[i+1]/bd[i] - ratio) < 0.01, f"Non-geometric: {bd}"
test("SweepConfig bond_dims is geometric for various (base,ratio,levels)", t_bond_dims_geometric, sec)

def t_effective_chi():
    # bond_dims=[16,32,64], effective = 64*2 = 128
    cfg = SweepConfig(base_chi=16, ratio=2.0, n_levels=3)
    assert cfg.effective_chi() == 128, f"Expected 128, got {cfg.effective_chi()}"
    # bond_dims=[10,30], effective = 30*3 = 90
    cfg2 = SweepConfig(base_chi=10, ratio=3.0, n_levels=2)
    assert cfg2.effective_chi() == 90, f"Expected 90, got {cfg2.effective_chi()}"
test("SweepConfig.effective_chi() correct", t_effective_chi, sec)

def t_runner_all_observables_present():
    n = 4; c = Circuit(n); c.h(0)
    for i in range(n-1): c.cx(i,i+1)
    obs = {f"Z{q}": ("Z", q) for q in range(n)}
    obs.update({f"X{q}": ("X", q) for q in range(n)})
    result = MultiChiRunner(SweepConfig(base_chi=4, ratio=2.0, n_levels=3), verbose=False).run(c, obs)
    for key in obs:
        assert key in result.observables, f"{key} missing from result"
test("MultiChiRunner returns all requested observables", t_runner_all_observables_present, sec)

def t_runner_custom_fn():
    """MultiChiRunner.run_custom() works with a custom simulation function."""
    true_val = 0.314
    def simulate(chi):
        return {"Z0": true_val + 1.0/chi}

    cfg = SweepConfig(base_chi=8, ratio=2.0, n_levels=3)
    result = MultiChiRunner(cfg, verbose=False).run_custom(simulate)
    extrap = result.observables["Z0"].extrapolated
    assert abs(extrap - true_val) < 1e-5
test("MultiChiRunner.run_custom() with synthetic function", t_runner_custom_fn, sec)


# ===========================================================================
# 12. STATEVECTOR EQUIVALENCE (MPS vs numpy)
# ===========================================================================
sec = section("12. MPS vs Exact Statevector Equivalence")

def build_exact_sv(circuit, n):
    """Build exact statevector using matrix multiplication."""
    sv = np.zeros(2**n, dtype=complex); sv[0] = 1.0
    for inst in circuit.instructions:
        if len(inst.qubits) == 1:
            sv = exact_apply(inst.get_matrix(), sv, inst.qubits, n)
        elif len(inst.qubits) == 2:
            sv = exact_apply(inst.get_matrix().reshape(4,4), sv, inst.qubits, n)
    return sv

def t_equivalence_random_circuits():
    """MPS statevector = exact numpy for several random circuits."""
    np.random.seed(7)
    n = 5
    for trial in range(5):
        c = Circuit(n)
        for _ in range(15):
            q = np.random.randint(n)
            gate = np.random.choice(["H","X","Ry","Rz"])
            if gate == "Ry": c.ry(np.random.uniform(0,np.pi), q)
            elif gate == "Rz": c.rz(np.random.uniform(0,2*np.pi), q)
            elif gate == "H": c.h(q)
            else: c.x(q)
            if np.random.random() < 0.4 and q < n-1:
                c.cx(q, q+1)

        sv_mps = MPSSimulator(chi=256).run(c).to_statevector()
        sv_exact = build_exact_sv(c, n)
        # Allow global phase
        if abs(sv_exact[0]) > 0.01:
            phase = sv_mps[0] / sv_exact[0]
        else:
            idx = np.argmax(np.abs(sv_exact))
            phase = sv_mps[idx] / sv_exact[idx]
        assert np.allclose(sv_mps, phase * sv_exact, atol=1e-8), \
            f"Trial {trial}: MPS ≠ exact (max diff={np.max(np.abs(sv_mps - phase*sv_exact)):.2e})"
test("MPS = exact statevector for 5 random n=5 circuits", t_equivalence_random_circuits, sec)

def t_equivalence_standard_circuits():
    """MPS matches exact for standard circuits: QFT-like, Ising, random Clifford."""
    n = 5

    # Ising Trotterized
    c = Circuit(n)
    for step in range(3):
        for q in range(n): c.rx(0.2, q)
        for q in range(n-1): c.zz(0.3, q, q+1)
    sv_mps = MPSSimulator(chi=256).run(c).to_statevector()
    sv_exact = build_exact_sv(c, n)
    idx = np.argmax(np.abs(sv_exact))
    phase = sv_mps[idx] / sv_exact[idx]
    assert np.allclose(sv_mps, phase * sv_exact, atol=1e-8), "Ising circuit mismatch"
test("MPS = exact for Ising Trotterized circuit", t_equivalence_standard_circuits, sec)


# ===========================================================================
# 13. EDGE CASES & ROBUSTNESS
# ===========================================================================
sec = section("13. Edge Cases & Robustness")

def t_single_qubit_circuit():
    c = Circuit(1); c.h(0).x(0).ry(0.5, 0)
    sv = MPSSimulator(16).run(c).to_statevector()
    assert len(sv) == 2
    assert abs(np.linalg.norm(sv) - 1.0) < 1e-10
test("Single-qubit circuit works", t_single_qubit_circuit, sec)

def t_two_qubit_circuit():
    c = Circuit(2); c.h(0).cx(0,1).rz(0.5, 1).cz(0,1)
    sv = MPSSimulator(16).run(c).to_statevector()
    assert len(sv) == 4
    assert abs(np.linalg.norm(sv) - 1.0) < 1e-10
test("Two-qubit circuit works", t_two_qubit_circuit, sec)

def t_identity_circuit():
    n = 5; c = Circuit(n)  # Empty circuit
    sv = MPSSimulator(16).run(c).to_statevector()
    assert abs(sv[0] - 1.0) < 1e-12, "Empty circuit ≠ |0...0>"
test("Empty circuit = |0...0>", t_identity_circuit, sec)

def t_chi_1():
    """chi=1 forces product-state approximation. Norm may be < 1 (truncation projection).
    Key requirements: no crash, norm > 0, expectations in [-1, 1]."""
    n = 4; c = Circuit(n); c.h(0)
    for i in range(n-1): c.cx(i, i+1)
    state = MPSSimulator(chi=1).run(c)
    norm = state._norm_mps()
    assert 0.0 < norm <= 1.0 + 1e-10, f"chi=1 norm = {norm} out of (0, 1]"
    for q in range(n):
        z = state.expectation_pauli_z(q)
        assert -1.0 <= z <= 1.0, f"chi=1 <Z_{q}> = {z} out of range"
test("chi=1 simulation completes without crash", t_chi_1, sec)

def t_get_gate_registry():
    """All registered gate names are retrievable."""
    single = ['I','X','Y','Z','H','S','T','Sdg','Tdg']
    two = ['CNOT','CX','CZ','SWAP','iSWAP']
    for name in single + two:
        g = get_gate(name)
        assert g is not None
test("All standard gate names retrievable from registry", t_get_gate_registry, sec)

def t_invalid_gate_raises():
    try: get_gate("NotAGate"); assert False, "Should have raised"
    except ValueError: pass
test("get_gate raises ValueError for unknown gate name", t_invalid_gate_raises, sec)

def t_mps_repr():
    mps = MPS(4, 16)
    r = repr(mps)
    assert "n=4" in r and "chi=16" in r
test("MPS.__repr__() contains n and chi", t_mps_repr, sec)

def t_circuit_repr():
    c = Circuit(4); c.h(0).cx(0,1)
    r = repr(c)
    assert "n=4" in r and "gates=2" in r
test("Circuit.__repr__() contains n and gate count", t_circuit_repr, sec)


# ===========================================================================
# 14. CLI
# ===========================================================================
sec = section("14. CLI Commands")

cli_base = ["python", "-m", "mps_sim.cli"]

def run_cli(*args, expect_in=""):
    r = subprocess.run(cli_base + list(args), capture_output=True, text=True)
    assert r.returncode == 0, f"CLI exited {r.returncode}:\nstdout={r.stdout}\nstderr={r.stderr}"
    if expect_in:
        assert expect_in in r.stdout, f"Expected '{expect_in}' in:\n{r.stdout}"
    return r.stdout

test("simulate bell",    lambda: run_cli("simulate","--circuit","bell","--n","2","--chi","16", expect_in="<Z>=+0.000000"), sec)
test("simulate ghz",     lambda: run_cli("simulate","--circuit","ghz","--n","5","--chi","32",  expect_in="<Z>=+0.000000"), sec)
test("simulate ising",   lambda: run_cli("simulate","--circuit","ising","--n","6","--chi","32"), sec)
test("simulate qft",     lambda: run_cli("simulate","--circuit","qft","--n","4","--chi","64"), sec)
test("simulate random",  lambda: run_cli("simulate","--circuit","random","--n","5","--chi","32"), sec)
test("extrapolate",      lambda: run_cli("extrapolate","--circuit","ising","--n","6","--chi-base","8","--levels","3", expect_in="Richardson"), sec)
test("benchmark",        lambda: run_cli("benchmark","--circuit","ising","--n","4","--chi-start","8","--chi-levels","3", expect_in="Extrapolated"), sec)
test("info",             lambda: run_cli("info", expect_in="Richardson"), sec)


# ===========================================================================
# RESULTS
# ===========================================================================
print(f"\n{'='*60}")
print(f"  FINAL RESULTS")
print(f"{'='*60}")
print(f"  PASSED: {len(results['passed'])}")
print(f"  FAILED: {len(results['failed'])}")

if results["failed"]:
    print(f"\n  Failed tests:")
    for section_name, name, err, tb in results["failed"]:
        print(f"\n  ✗ [{section_name}] {name}")
        print(f"    Error: {err}")
        # Print just the relevant part of traceback
        lines = tb.strip().split("\n")
        for line in lines[-4:]:
            print(f"    {line}")
    print(f"\n  ⚠ Fix the above before publishing.")
else:
    print(f"\n  ✓ All tests passed — production ready!")
