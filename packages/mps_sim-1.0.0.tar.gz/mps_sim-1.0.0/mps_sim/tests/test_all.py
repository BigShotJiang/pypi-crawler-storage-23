"""
Test suite for mps_sim.

Tests cover:
- MPS initialization and basic operations
- Gate application correctness
- Single and two-qubit gate accuracy vs exact state vector
- Richardson extrapolation correctness and reliability diagnostics
- End-to-end circuit simulation
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import numpy as np
import pytest

from mps_sim import Circuit, MPSSimulator, MPS
from mps_sim import RichardsonExtrapolator, SweepConfig, MultiChiRunner
from mps_sim.gates import H, X, Y, Z, CNOT, CZ, Rx, Ry, Rz, get_gate


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def run_circuit_exact(circuit: Circuit) -> np.ndarray:
    """Run circuit with very large chi to get near-exact result."""
    sim = MPSSimulator(chi=512)
    state = sim.run(circuit)
    return state.to_statevector()


def exact_z_expectation(sv: np.ndarray, qubit: int, n: int) -> float:
    """Compute <Z_qubit> from statevector."""
    vals = []
    for i, amp in enumerate(sv):
        bit = (i >> (n - 1 - qubit)) & 1
        eigenval = 1 - 2 * bit  # 0 → +1, 1 → -1
        vals.append(eigenval * abs(amp) ** 2)
    return float(np.real(sum(vals)))


# ---------------------------------------------------------------------------
# MPS initialization tests
# ---------------------------------------------------------------------------

class TestMPSInit:
    def test_zero_state(self):
        mps = MPS(4, 32)
        sv = mps.to_statevector()
        assert abs(sv[0] - 1.0) < 1e-12, "Should start in |0000>"
        assert abs(np.linalg.norm(sv) - 1.0) < 1e-12

    def test_bond_dims_initial(self):
        mps = MPS(5, 32)
        bonds = mps.bond_dimensions()
        assert all(b == 1 for b in bonds), "Product state has all bond dims = 1"

    def test_norm_initial(self):
        mps = MPS(4, 32)
        n = mps._norm_mps()
        assert abs(n - 1.0) < 1e-12

    def test_copy(self):
        mps = MPS(4, 32)
        mps2 = mps.copy()
        mps2.tensors[0] *= 2
        # Original should be unchanged
        assert abs(mps.to_statevector()[0] - 1.0) < 1e-12


# ---------------------------------------------------------------------------
# Gate tests
# ---------------------------------------------------------------------------

class TestGates:
    def test_h_gate_shape(self):
        h = H()
        assert h.shape == (2, 2)

    def test_h_unitary(self):
        h = H()
        assert np.allclose(h @ h.conj().T, np.eye(2)), "H must be unitary"

    def test_cnot_shape(self):
        cnot = CNOT()
        assert cnot.shape == (2, 2, 2, 2)

    def test_rx_unitary(self):
        for theta in [0, np.pi/4, np.pi/2, np.pi]:
            rx = Rx(theta)
            assert np.allclose(rx @ rx.conj().T, np.eye(2)), f"Rx({theta}) must be unitary"

    def test_get_gate_single(self):
        h = get_gate('H')
        assert np.allclose(h, H())

    def test_get_gate_parametric(self):
        rx = get_gate('Rx', np.pi / 3)
        assert np.allclose(rx, Rx(np.pi / 3))

    def test_get_gate_two(self):
        cnot = get_gate('CNOT')
        assert cnot.shape == (2, 2, 2, 2)

    def test_get_gate_unknown(self):
        with pytest.raises(ValueError):
            get_gate('NotAGate')


# ---------------------------------------------------------------------------
# Single-qubit gate application tests
# ---------------------------------------------------------------------------

class TestSingleQubitGates:
    def _run_and_sv(self, circuit):
        sim = MPSSimulator(chi=64)
        state = sim.run(circuit)
        return state.to_statevector()

    def test_x_gate(self):
        c = Circuit(2)
        c.x(0)
        sv = self._run_and_sv(c)
        # |10> = index 2 (binary 10)
        assert abs(sv[2] - 1.0) < 1e-12, f"X on qubit 0 should give |10>, got {sv}"

    def test_h_gate_superposition(self):
        c = Circuit(1)
        c.h(0)
        sv = self._run_and_sv(c)
        assert abs(sv[0] - 1 / np.sqrt(2)) < 1e-12
        assert abs(sv[1] - 1 / np.sqrt(2)) < 1e-12

    def test_xx_rotation(self):
        c = Circuit(1)
        c.rx(np.pi, 0)
        sv = self._run_and_sv(c)
        # Rx(π)|0> = -i|1>
        assert abs(abs(sv[1]) - 1.0) < 1e-12

    def test_z_expectation_zero_state(self):
        c = Circuit(3)
        sim = MPSSimulator(chi=16)
        state = sim.run(c)
        assert abs(state.expectation_pauli_z(0) - 1.0) < 1e-12

    def test_z_expectation_after_x(self):
        c = Circuit(1)
        c.x(0)
        sim = MPSSimulator(chi=16)
        state = sim.run(c)
        assert abs(state.expectation_pauli_z(0) + 1.0) < 1e-12

    def test_x_expectation_after_h(self):
        c = Circuit(1)
        c.h(0)
        sim = MPSSimulator(chi=16)
        state = sim.run(c)
        assert abs(state.expectation_pauli_x(0) - 1.0) < 1e-12


# ---------------------------------------------------------------------------
# Two-qubit gate tests
# ---------------------------------------------------------------------------

class TestTwoQubitGates:
    def _run_and_sv(self, circuit):
        sim = MPSSimulator(chi=256)
        state = sim.run(circuit)
        return state.to_statevector()

    def test_cnot_creates_bell(self):
        c = Circuit(2)
        c.h(0).cx(0, 1)
        sv = self._run_and_sv(c)
        # |Φ+> = (|00> + |11>) / sqrt(2)
        assert abs(sv[0] - 1 / np.sqrt(2)) < 1e-10
        assert abs(sv[1]) < 1e-10
        assert abs(sv[2]) < 1e-10
        assert abs(sv[3] - 1 / np.sqrt(2)) < 1e-10

    def test_cnot_normalization(self):
        c = Circuit(3)
        c.h(0).cx(0, 1).cx(1, 2)
        sv = self._run_and_sv(c)
        assert abs(np.linalg.norm(sv) - 1.0) < 1e-10

    def test_cz_gate(self):
        c = Circuit(2)
        c.x(0).x(1).cz(0, 1)
        sv = self._run_and_sv(c)
        # CZ|11> = -|11>
        assert abs(sv[3] + 1.0) < 1e-10

    def test_ghz_state(self):
        n = 5
        c = Circuit(n)
        c.h(0)
        for i in range(n - 1):
            c.cx(i, i + 1)
        sv = self._run_and_sv(c)
        # GHZ: (|00000> + |11111>) / sqrt(2)
        assert abs(sv[0] - 1 / np.sqrt(2)) < 1e-10
        assert abs(sv[-1] - 1 / np.sqrt(2)) < 1e-10
        # All other amplitudes should be 0
        other = [sv[i] for i in range(1, len(sv) - 1)]
        assert all(abs(a) < 1e-10 for a in other)

    def test_expectation_value_ghz(self):
        n = 4
        c = Circuit(n)
        c.h(0)
        for i in range(n - 1):
            c.cx(i, i + 1)
        sim = MPSSimulator(chi=64)
        state = sim.run(c)
        # <Z> on any qubit of GHZ = 0
        for q in range(n):
            z_val = state.expectation_pauli_z(q)
            assert abs(z_val) < 1e-10, f"<Z_{q}> should be 0 for GHZ, got {z_val}"


# ---------------------------------------------------------------------------
# Richardson extrapolation tests
# ---------------------------------------------------------------------------

class TestRichardsonExtrapolation:
    def _make_fake_values(self, true_val, alpha, chi_list):
        """Generate fake values with known power-law truncation error."""
        return [true_val + 1.0 / chi ** alpha for chi in chi_list]

    def test_extrapolation_known_alpha(self):
        """With exact power-law data, extrapolation should be very accurate."""
        true_val = 0.7654321
        alpha = 1.0
        chi_list = [16, 32, 64]
        values = self._make_fake_values(true_val, alpha, chi_list)

        ext = RichardsonExtrapolator(ratio=2.0, alpha=alpha)
        result = ext.extrapolate(chi_list, values, alpha=alpha)

        assert abs(result.extrapolated - true_val) < 1e-8, \
            f"Expected {true_val}, got {result.extrapolated}"

    def test_extrapolation_estimated_alpha(self):
        """With power-law data, alpha estimation + extrapolation should converge."""
        true_val = 0.5
        alpha = 2.0
        chi_list = [32, 64, 128, 256]
        values = self._make_fake_values(true_val, alpha, chi_list)

        ext = RichardsonExtrapolator(ratio=2.0)
        result = ext.extrapolate(chi_list, values)

        assert abs(result.extrapolated - true_val) < 1e-4, \
            f"Expected ~{true_val}, got {result.extrapolated}"

    def test_alpha_estimation(self):
        alpha = 1.5
        chi_list = [32, 64, 128, 256]
        values = self._make_fake_values(0.0, alpha, chi_list)

        ext = RichardsonExtrapolator()
        estimated = ext.estimate_alpha(chi_list, values)
        assert abs(estimated - alpha) < 0.3, f"Expected α≈{alpha}, estimated {estimated}"

    def test_reliability_monotone(self):
        """Non-monotone raw values should flag as unreliable."""
        chi_list = [16, 32, 64]
        values = [0.5, 0.7, 0.6]  # Non-monotone

        ext = RichardsonExtrapolator()
        result = ext.extrapolate(chi_list, values)

        assert not result.is_reliable
        assert any("monoton" in note.lower() for note in result.reliability_notes)

    def test_result_summary(self):
        chi_list = [16, 32, 64]
        values = self._make_fake_values(0.5, 1.0, chi_list)
        ext = RichardsonExtrapolator()
        result = ext.extrapolate(chi_list, values)
        summary = result.summary()
        assert "Extrapolated" in summary

    def test_multi_observable(self):
        chi_list = [16, 32, 64]
        values_dict = {
            'Z0': self._make_fake_values(0.3, 1.0, chi_list),
            'Z1': self._make_fake_values(-0.3, 1.0, chi_list),
        }
        ext = RichardsonExtrapolator()
        result = ext.extrapolate_multi(chi_list, values_dict)

        assert 'Z0' in result.observables
        assert 'Z1' in result.observables
        assert abs(result.observables['Z0'].extrapolated - 0.3) < 1e-6

    def test_insufficient_data_raises(self):
        ext = RichardsonExtrapolator()
        with pytest.raises(ValueError):
            ext.extrapolate([64], [0.5])


# ---------------------------------------------------------------------------
# Sweep config tests
# ---------------------------------------------------------------------------

class TestSweepConfig:
    def test_bond_dims(self):
        cfg = SweepConfig(base_chi=16, ratio=2.0, n_levels=4)
        assert cfg.bond_dims == [16, 32, 64, 128]

    def test_effective_chi(self):
        cfg = SweepConfig(base_chi=64, ratio=2.0, n_levels=3)
        assert cfg.effective_chi() == 256


# ---------------------------------------------------------------------------
# End-to-end integration tests
# ---------------------------------------------------------------------------

class TestEndToEnd:
    def test_ising_model_z_expectation(self):
        """
        Transverse field Ising chain: apply many Ry and ZZ rotations.
        Check that <Z> is real and in [-1, 1].
        """
        n = 6
        c = Circuit(n)
        theta = 0.3

        # Transverse field
        for q in range(n):
            c.ry(theta, q)

        # ZZ interactions
        for q in range(n - 1):
            c.zz(theta, q, q + 1)

        sim = MPSSimulator(chi=64)
        state = sim.run(c)

        for q in range(n):
            z = state.expectation_pauli_z(q)
            assert -1.0 <= z <= 1.0, f"<Z_{q}> = {z} out of range"

    def test_random_circuit_normalization(self):
        """Random circuit should produce normalized state."""
        np.random.seed(42)
        n = 6
        c = Circuit(n)
        for _ in range(20):
            q = np.random.randint(n)
            theta = np.random.uniform(0, 2 * np.pi)
            c.ry(theta, q)
            if np.random.random() < 0.5 and q < n - 1:
                c.cx(q, q + 1)

        sim = MPSSimulator(chi=64)
        state = sim.run(c)
        norm = state._norm_mps()
        assert abs(norm - 1.0) < 1e-8, f"Norm = {norm}"

    def test_multi_chi_runner_basic(self):
        """MultiChiRunner should produce reasonable extrapolated values."""
        n = 4
        c = Circuit(n)
        c.h(0)
        for i in range(n - 1):
            c.cx(i, i + 1)

        cfg = SweepConfig(base_chi=8, ratio=2.0, n_levels=3)
        runner = MultiChiRunner(cfg, verbose=False)
        result = runner.run(c, {'Z0': ('Z', 0)})

        # GHZ <Z0> = 0
        z0 = result.observables['Z0'].extrapolated
        assert abs(z0) < 0.1, f"<Z0> for GHZ should be ~0, got {z0}"

    def test_circuit_builder_api(self):
        """Test fluent circuit builder doesn't crash."""
        c = (Circuit(4)
             .h(0)
             .cx(0, 1)
             .rz(np.pi / 4, 2)
             .ry(np.pi / 3, 3)
             .cz(1, 2)
             .x(0))
        assert len(c.instructions) == 6
        assert c.n == 4


# ---------------------------------------------------------------------------
# Main runner
# ---------------------------------------------------------------------------

if __name__ == '__main__':
    # Run with pytest or directly
    import subprocess
    subprocess.run([sys.executable, '-m', 'pytest', __file__, '-v'], check=False)
