"""
mps_sim — MPS-based quantum circuit simulator with Richardson extrapolation.

Quick start
-----------
>>> from mps_sim import Circuit, MPSSimulator, MultiChiRunner, SweepConfig
>>>
>>> # Simple simulation
>>> c = Circuit(4)
>>> c.h(0).cx(0,1).cx(1,2).cx(2,3)
>>> sim = MPSSimulator(chi=64)
>>> state = sim.run(c)
>>> print(state.expectation_pauli_z(0))
>>>
>>> # Extrapolated simulation
>>> runner = MultiChiRunner(SweepConfig(base_chi=16, ratio=2, n_levels=3))
>>> result = runner.run(c, {'Z0': ('Z', 0), 'Z1': ('Z', 1)})
>>> print(result.summary())
"""

from .core.mps import MPS
from .circuits import Circuit, MPSSimulator
from .extrapolation import (
    RichardsonExtrapolator,
    MultiChiRunner,
    SweepConfig,
    ExtrapolationResult,
    MultiObservableResult,
)
from .gates import get_gate

__version__ = "1.0.0"
__author__ = "MPS Sim"

__all__ = [
    "MPS",
    "Circuit",
    "MPSSimulator",
    "RichardsonExtrapolator",
    "MultiChiRunner",
    "SweepConfig",
    "ExtrapolationResult",
    "MultiObservableResult",
    "get_gate",
]
