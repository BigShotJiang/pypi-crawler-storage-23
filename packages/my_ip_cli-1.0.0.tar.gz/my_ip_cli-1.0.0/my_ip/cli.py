import socket
import requests
import shutil

API_URL = "https://ifconfig.co/json"

RESET = "\033[0m"
BOLD = "\033[1m"
DIM = "\033[2m"
CYAN = "\033[36m"

def line(char="─"):
    width = shutil.get_terminal_size((80, 20)).columns
    return char * width

def title(text):
    width = shutil.get_terminal_size((80, 20)).columns
    return text.center(width)

def label(name, value):
    return f"{BOLD}{name:<28}{RESET}{value}"

def get_ip_info():
    try:
        r = requests.get(API_URL, timeout=5)
        r.raise_for_status()
        data = r.json()

        return {
            "ip": data.get("ip", "Unknown"),
            "hostname": socket.gethostname(),
            "country": data.get("country", "Unknown"),
            "latitude": data.get("latitude", "Unknown"),
            "longitude": data.get("longitude", "Unknown"),
            "timezone": data.get("time_zone", "Unknown"),
            "isp": data.get("asn_org", "Unknown"),
        }

    except Exception:
        return {
            "ip": "Unavailable",
            "hostname": socket.gethostname(),
            "country": "Unavailable",
            "latitude": "Unavailable",
            "longitude": "Unavailable",
            "timezone": "Unavailable",
            "isp": "Unavailable",
        }

def main():
    info = get_ip_info()

    print(CYAN + line() + RESET)
    print(CYAN + title("NETWORK INFORMATION") + RESET)
    print(CYAN + line() + RESET)
    print()

    print(label("Public IP Address:", info["ip"]))
    print(label("Host Name:", info["hostname"]))
    print(label("Country:", info["country"]))
    print(label("Coordinates:", f"{info['latitude']}, {info['longitude']}"))
    print(label("Time Zone:", info["timezone"]))
    print(label("Network Provider:", info["isp"]))

    print()
    print(DIM + line() + RESET)