# my-ip-cli

A simple terminal command that displays your public IP address and network information.

## Features

- Public IP address
- Host name
- Country
- Coordinates
- Time zone
- Network provider
- Clean terminal output

## Installation

Install from PyPI:

```bash
pip install my-ip-cli