DEFAULT = [
    {
        "role": "system",
        "content": "You are a helpful assistant."
    }
]

SEQUENCE = 'SEQUENCE'
PARALLEL = 'PARALLEL'

DATE_TIME_FORMAT = "%Y-%m-%d %H:%M:%S.%f"
