
class InvalidHandler(Exception):
    pass


class InvalidAction(Exception):
    pass
