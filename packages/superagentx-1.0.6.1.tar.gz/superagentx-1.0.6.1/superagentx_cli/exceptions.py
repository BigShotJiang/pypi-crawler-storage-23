class AppConfigError(Exception):
    pass
