"""Utility functions shared across the package."""
