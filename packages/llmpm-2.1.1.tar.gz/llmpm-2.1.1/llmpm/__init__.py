"""llmpm — LLM Package Manager."""

__version__ = "2.1.1"
__author__ = "llmpm contributors"
