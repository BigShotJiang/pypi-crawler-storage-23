"""Kalign benchmark suite for alignment quality regression testing."""
