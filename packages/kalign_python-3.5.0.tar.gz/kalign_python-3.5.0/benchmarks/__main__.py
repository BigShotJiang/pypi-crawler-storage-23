"""Entry point for `python -m benchmarks`."""

from .runner import main

main()
