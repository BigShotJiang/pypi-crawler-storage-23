class RecognitionError(RuntimeError):
    pass


class SeasoningError(RuntimeError):
    pass
