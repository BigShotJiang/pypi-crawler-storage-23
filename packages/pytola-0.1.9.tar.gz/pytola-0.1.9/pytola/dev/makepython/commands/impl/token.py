"""Token command implementation for MakePython."""

from __future__ import annotations

import getpass
import json
import logging
from pathlib import Path
from typing import TYPE_CHECKING

from ..._tool_utils import CONFIG_DIR_NAME
from ...interfaces.command import CommandResult, CommandType, ValidatableCommand

if TYPE_CHECKING:
    from ...core.context import ExecutionContext


logger = logging.getLogger(__name__)

# PyPI token configuration file
TOKEN_FILE = Path.home() / CONFIG_DIR_NAME / "pypi_token.json"


class TokenCommand(ValidatableCommand):
    """Set PyPI authentication token."""

    name = "token"
    alias = "tk"
    description = "Set PyPI authentication token"
    command_type = CommandType.TOKEN

    def __init__(self):
        """Initialize the token command."""
        self.logger = logging.getLogger(__name__)

    def validate(self, context: ExecutionContext) -> bool:
        """Validate token command prerequisites.

        Args:
            context: Execution context

        Returns
        -------
            True if validation passes, False otherwise
        """
        # Always valid - token can be set anytime
        return True

    def _load_token(self) -> str | None:
        """Load token from configuration file.

        Returns
        -------
            Token string if exists, None otherwise
        """
        if not TOKEN_FILE.exists():
            return None

        try:
            data = json.loads(TOKEN_FILE.read_text(encoding="utf-8"))
            return data.get("token")
        except Exception as e:
            self.logger.warning(f"Failed to load token: {e}")
            return None

    def _save_token(self, token: str) -> bool:
        """Save token to configuration file.

        Args:
            token: PyPI token to save

        Returns
        -------
            True if successfully saved, False otherwise
        """
        try:
            TOKEN_FILE.parent.mkdir(parents=True, exist_ok=True)
            TOKEN_FILE.write_text(
                json.dumps({"token": token}, indent=2),
                encoding="utf-8",
            )
            self.logger.debug(f"Token saved to {TOKEN_FILE}")
            return True
        except Exception as e:
            self.logger.error(f"Failed to save token: {e}")
            return False

    def execute(self, context: ExecutionContext) -> CommandResult:
        """Execute token command.

        Args:
            context: Execution context

        Returns
        -------
            CommandResult with execution status
        """
        if not self.validate(context):
            return CommandResult(success=False, message="Validation failed")

        self.logger.info("Configure PyPI authentication token")

        try:
            # Prompt for token
            print("\nEnter your PyPI API token (will not be visible):")
            token = getpass.getpass("> ")

            if not token.strip():
                return CommandResult(success=False, message="Token cannot be empty")

            # Validate token format (basic check)
            if not token.startswith("pypi-"):
                self.logger.warning("Token doesn't start with 'pypi-'. Are you sure it's correct?")
                confirm = input("Continue anyway? (y/n): ").strip().lower()
                if confirm != "y":
                    return CommandResult(success=False, message="Token configuration cancelled")

            # Save token
            if self._save_token(token):
                self.logger.info("PyPI token configured successfully")
                return CommandResult(success=True, message="PyPI token configured successfully")
            return CommandResult(success=False, message="Failed to save token")

        except KeyboardInterrupt:
            self.logger.info("Token configuration cancelled by user")
            return CommandResult(success=False, message="Cancelled by user")
        except Exception as e:
            self.logger.exception(f"Failed to configure token: {e}")
            return CommandResult(success=False, message=str(e))


def get_pypi_token() -> str | None:
    """Get PyPI token from configuration.

    Returns
    -------
        Token string if configured, None otherwise
    """
    if not TOKEN_FILE.exists():
        return None

    try:
        data = json.loads(TOKEN_FILE.read_text(encoding="utf-8"))
        return data.get("token")
    except Exception:
        logger.warning("Failed to load PyPI token")
        return None


def check_pypi_token() -> bool:
    """Check if PyPI token is configured.

    Returns
    -------
        True if token exists, False otherwise
    """
    token = get_pypi_token()
    return bool(token)
