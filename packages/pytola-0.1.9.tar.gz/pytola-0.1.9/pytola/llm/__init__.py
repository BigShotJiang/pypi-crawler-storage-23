"""Large Language Model tools."""
