"""HC Services portal client (hcservices.ecourts.gov.in)."""

from bharat_courts.hcservices.client import HCServicesClient

__all__ = ["HCServicesClient"]
