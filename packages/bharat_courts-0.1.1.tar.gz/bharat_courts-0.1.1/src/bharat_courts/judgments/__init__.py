"""Judgment search portal client (judgments.ecourts.gov.in)."""

from bharat_courts.judgments.client import JudgmentSearchClient

__all__ = ["JudgmentSearchClient"]
