session_context
---------------

.. automodule:: telnetlib3._session_context
   :members:
