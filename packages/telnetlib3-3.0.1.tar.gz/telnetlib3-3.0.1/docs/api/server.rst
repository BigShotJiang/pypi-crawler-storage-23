server
------

.. automodule:: telnetlib3.server
   :members:
