guard_shells
------------

.. automodule:: telnetlib3.guard_shells
   :members:
