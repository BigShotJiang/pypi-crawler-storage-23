sync
----

.. automodule:: telnetlib3.sync
   :members:
   :undoc-members:
   :show-inheritance:
