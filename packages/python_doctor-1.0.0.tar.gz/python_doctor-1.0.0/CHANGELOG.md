# Changelog

## 0.2.0 (2026-02-19)

### Added
- Claude Code plugin with `/python-doctor` skill
- `uvx` support in skill for zero-setup execution

### Changed
- Updated README install instructions for PyPI publication
- Fixed changelog

## 0.1.0 (2026-02-19)

### Added
- 9 analyzers: security (Bandit), lint (Ruff), dead code (Vulture), complexity (Radon), structure, dependencies, docstrings, imports, exceptions
- Structure checks: test-to-source ratio, README, LICENSE, .gitignore, linter config, type checker config, py.typed
- Bandit B101 (assert) auto-filtered in test files
- CLI with `--verbose`, `--score`, `--json`, `--fix` flags
- Exit code 1 if score < 50
- Tests via pytest
- PyPI publishing via Trusted Publishers
