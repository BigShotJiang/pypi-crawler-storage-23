# MediLink_RemittancePipeline.py
import json
import os
import time

# NOTE: This module provides lightweight helpers for downstream remittance
# normalization and JSONL persistence. It is intentionally minimal so it can
# be wired into the download/parsing pipeline in stages.

UNIFIED_FIELDS = [
    'claim_number',
    'chart',
    'dos',
    'payer_id',
    'payer_name',
    'patient_name',
    'status',
    'charged',
    'allowed',
    'paid',
    'patient_resp',
    'adjustments',
    'service_lines',
    'messages',
    'source_file',
    'source_type',
    'source_endpoint',
    'source_timestamp',
    'data_source',
]


def _safe_str(value):
    if value is None:
        return ''
    return str(value)


def normalize_unified_record(unified_record, source_meta=None):
    """
    Normalize a UnifiedRecord (from MediLink_Decoder) into remittance_parsed schema.
    This does not attempt to parse chart/DOS from claim number yet.
    """
    record_dict = unified_record.to_dict() if hasattr(unified_record, 'to_dict') else dict(unified_record)
    source_meta = source_meta or {}

    return {
        'claim_number': _safe_str(record_dict.get('Claim #', '')),
        'chart': _safe_str(record_dict.get('Chart', '')),
        'dos': _safe_str(record_dict.get('Serv.', '')),
        'payer_id': _safe_str(record_dict.get('Payer ID', '')),
        'payer_name': _safe_str(record_dict.get('Payer', '')),
        'patient_name': _safe_str(record_dict.get('Patient', '')),
        'status': _safe_str(record_dict.get('Status', '')),
        'charged': _safe_str(record_dict.get('Charged', '')),
        'allowed': _safe_str(record_dict.get('Allowed', '')),
        'paid': _safe_str(record_dict.get('Paid', '')),
        'patient_resp': _safe_str(record_dict.get('Pt Resp', '')),
        'adjustments': record_dict.get('adjustments', []),
        'service_lines': record_dict.get('service_lines', []),
        'messages': record_dict.get('messages', []),
        'raw_segments': record_dict.get('raw_segments', []),
        'payer_claim_number': _safe_str(record_dict.get('Payer Claim Number', '')),
        'source_file': source_meta.get('source_file', ''),
        'source_type': source_meta.get('source_type', ''),
        'source_endpoint': source_meta.get('source_endpoint', ''),
        'source_timestamp': source_meta.get('source_timestamp', None),
        'data_source': source_meta.get('data_source', 'parsed_file'),
    }


def normalize_claims_inquiry_record(claim_data, source_meta=None):
    """
    Normalize Claims Inquiry output into remittance_parsed schema.
    claim_data should follow the legacy claims summary format.
    """
    source_meta = source_meta or {}

    return {
        'claim_number': _safe_str(claim_data.get('claim_number', '')),
        'chart': '',
        'dos': _safe_str(claim_data.get('first_service_date', '')),
        'payer_id': _safe_str(claim_data.get('payer_id', '')),
        'payer_name': _safe_str(claim_data.get('payer_name', '')),
        'patient_name': _safe_str(claim_data.get('patient_name', '')),
        'status': _safe_str(claim_data.get('claim_status', '')),
        'charged': _safe_str(claim_data.get('total_charged_amount', '')),
        'allowed': _safe_str(claim_data.get('total_allowed_amount', '')),
        'paid': _safe_str(claim_data.get('total_paid_amount', '')),
        'patient_resp': _safe_str(claim_data.get('total_patient_responsibility_amount', '')),
        'adjustments': [],
        'service_lines': [],
        'messages': claim_data.get('messages', []),
        'raw_segments': [],
        'payer_claim_number': '',
        'source_file': source_meta.get('source_file', ''),
        'source_type': source_meta.get('source_type', ''),
        'source_endpoint': source_meta.get('source_endpoint', ''),
        'source_timestamp': source_meta.get('source_timestamp', None),
        'data_source': source_meta.get('data_source', 'claims_inquiry'),
    }


def write_jsonl(records, output_path):
    if not records:
        return 0
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    written = 0
    with open(output_path, 'a') as handle:
        for record in records:
            handle.write(json.dumps(record) + '\n')
            written += 1
    return written


def build_source_meta(source_file=None, source_type=None, source_endpoint=None, source_timestamp=None, data_source=None):
    return {
        'source_file': source_file or '',
        'source_type': source_type or '',
        'source_endpoint': source_endpoint or '',
        'source_timestamp': source_timestamp if source_timestamp is not None else int(time.time()),
        'data_source': data_source or 'parsed_file',
    }
