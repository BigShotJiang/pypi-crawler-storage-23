"""Shared reject-code registries for preprocessor and processor stages."""

from __future__ import annotations

PREPROCESSOR_REJECT_CODE_REGISTRY = frozenset({
    "missing_machine_id",
    "missing_message_id",
    "missing_received_at",
    "empty_files_not_otp",
    "invalid_files_item",
    "unhandled_exception",
})
PROCESSOR_REJECT_CODE_REGISTRY = frozenset({
    "machine_id_resolution_failure",
    "processor_unhandled_exception",
})
KNOWN_INGEST_ERROR_CODES = PREPROCESSOR_REJECT_CODE_REGISTRY | PROCESSOR_REJECT_CODE_REGISTRY
