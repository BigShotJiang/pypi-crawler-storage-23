"""Canonical Gmail watch registration shared by API endpoint and validator."""

from __future__ import annotations

from typing import Any, Dict, List, Optional, Tuple

from config import Config
import services


def normalize_label_ids(
    raw: Optional[str] = None,
    from_list: Optional[List[str]] = None,
) -> List[str]:
    """
    Normalize label IDs for Gmail watch. Single source of truth for label fallback.
    - raw: comma-separated string (e.g. GMAIL_LABEL_IDS env)
    - from_list: list of label IDs (may contain empty/whitespace)
    Returns ["INBOX"] when both empty or produce no valid IDs.
    """
    if raw and raw.strip():
        ids = [x.strip() for x in raw.split(",") if x.strip()]
        if ids:
            return ids
    if from_list:
        ids = [x.strip() for x in from_list if x and x.strip()]
        if ids:
            return ids
    return ["INBOX"]


def register_gmail_watch_impl(
    gmail_client: Any,
    project_id: str,
    mailbox_user: str,
    topic: str,
    label_ids: List[str],
) -> Tuple[str, str, Dict[str, Any]]:
    """
    Single implementation of Gmail watch registration.
    Caller supplies authenticated Gmail client and params.
    Raises on Gmail API failure.

    Returns:
        (detail, history_id, watch_response)
    """
    topic_name = "projects/{}/topics/{}".format(project_id, topic)
    ids = normalize_label_ids(from_list=label_ids)
    body = {
        "topicName": topic_name,
        "labelFilterAction": "include",
        "labelIds": ids,
    }
    response = gmail_client.users().watch(userId=mailbox_user, body=body).execute()
    history_id = str(response.get("historyId") or "").strip()
    expiration = str(response.get("expiration") or "").strip()
    detail = "watch registered (historyId={}, expiration={})".format(history_id, expiration)
    return detail, history_id, response


def register_gmail_watch(config: Config) -> Tuple[str, str, Dict[str, Any]]:
    """
    Register Gmail watch using config-driven auth and params.
    Uses services.gmail_client(config) so DWD/keyless and AUTH_MODE are respected.
    Raises on failure.

    Returns:
        (detail, history_id, watch_response)
    """
    gmail = services.gmail_client(config)
    label_ids = normalize_label_ids(from_list=config.gmail_label_ids or [])
    return register_gmail_watch_impl(
        gmail,
        config.project_id,
        config.mailbox_user,
        config.gmail_pubsub_topic,
        label_ids,
    )
