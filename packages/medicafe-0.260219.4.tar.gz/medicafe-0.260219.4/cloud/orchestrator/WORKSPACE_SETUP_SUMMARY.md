# Workspace Cloud Setup Summary

## Active Configuration

- **GCP Project ID**: `genial-analyzer-476721-f8`
- **Cloud Run Service Account**: `medilink-gmail-orchestrator@genial-analyzer-476721-f8.iam.gserviceaccount.com`
- **Monitored Workspace Mailbox**: `daniel@strategicimplementation.us`
- **Source Forwarding Mailbox**: `mariavidaud@gmail.com`
- **Gmail Auth Method**: `user_oauth` (OAuth credentials in Secret Manager)

## Current Architecture

```
mariavidaud@gmail.com
    ↓ (forwarding rule)
daniel@strategicimplementation.us
    ↓ (Gmail API watch)
Pub/Sub topic: gmail-new-emails
    ↓
Cloud Run: medilink-gmail-orchestrator
    ↓
Firestore queue + GCS attachments
    ↓
XP daemon polling /ready and /files
```

## Completion Script

Use the new cross-platform script from a local IDE with GCP SDK installed:

```bash
python cloud/orchestrator/validate_and_complete_setup.py \
  --project-id genial-analyzer-476721-f8 \
  --mailbox-user daniel@strategicimplementation.us \
  # script auto-selects required actions
```

What it validates and auto-remediates when possible:
- gcloud auth + project context
- required APIs
- orchestrator service account and IAM roles
- bucket/topic/subscription resources
- Cloud Run env vars needed for mailbox + OAuth Secret Manager integration
- Gmail watch registration

## Required Secrets

Create/update these Secret Manager entries in the same project:

- `gmail_oauth_client_id`
- `gmail_oauth_client_secret`
- `gmail_oauth_refresh_token`

Cloud Run reads them through:
- `GMAIL_OAUTH_CLIENT_ID_SECRET`
- `GMAIL_OAUTH_CLIENT_SECRET_SECRET`
- `GMAIL_OAUTH_REFRESH_TOKEN_SECRET`

## Final Verification Checklist

1. `curl https://<service-url>/health` returns `config_loaded: true`.
2. Send a test attachment email that should pass filters (`docx`/`csv` etc.).
3. Confirm queue item creation in Firestore `queues`.
4. Confirm XP daemon downloads file and posts `/ack`.


## Automation Boundaries

The validator can automate most infrastructure checks/fixes but still depends on manual steps for:
- initial Cloud Run deployment if service does not exist yet
- Firestore first-time Native initialization/indexing
- entering actual OAuth secret values

When these are missing, the script now prints detailed guided steps for GCP beginners.

## Launcher / client activation

Use one of these activation paths from MediCafe:
- `python -m MediCafe cloud_daemon` (explicit cloud client launch)
- `python -m MediCafe download_emails` with `MEDILINK_DOWNLOAD_MODE=cloud` (soft-switch migration path)
