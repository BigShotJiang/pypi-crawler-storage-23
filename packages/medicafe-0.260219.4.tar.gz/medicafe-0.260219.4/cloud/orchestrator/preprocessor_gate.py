"""
Preprocessor promotion gate: queries Firestore to compute gate metrics.

Validator is authoritative only from queues + ingest_errors (or summary doc).
No log scraping.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Iterable, Optional, Set, Tuple

try:
    from google.cloud import firestore
    FIRESTORE_AVAILABLE = True
except ImportError:
    FIRESTORE_AVAILABLE = False
    firestore = None  # type: ignore

try:
    from .reject_codes import KNOWN_INGEST_ERROR_CODES
except ImportError:
    from reject_codes import KNOWN_INGEST_ERROR_CODES

GATE_THRESHOLD = 50


@dataclass
class PreprocessorGateMetrics:
    """Gate metrics from Firestore."""

    unique_shadow_processed_count: int
    unknown_reject_code_count: int
    preprocess_unhandled_exception_count: int
    dropped_without_repair_record_count: int
    duplicate_queue_doc_count_by_message_id: int
    reject_count: int
    mode: str


def _query_preprocessor_gate(
    project_id: str,
    queue_collection: str = "queues",
    state_collection: str = "sync_state",
    ingest_errors_collection: str = "ingest_errors",
) -> Tuple[Optional[PreprocessorGateMetrics], Optional[str]]:
    """
    Query Firestore for gate metrics. Returns (metrics, error).
    metrics=None when Firestore cannot be queried.
    """
    if not FIRESTORE_AVAILABLE:
        return None, "google-cloud-firestore not available"

    try:
        client = firestore.Client(project=project_id)
    except Exception as exc:
        return None, "Firestore client init failed: {}".format(exc)

    # Get shadow_started_at from sync_state/preprocessor
    shadow_started_at = None
    preprocessor_doc = client.collection(state_collection).document("preprocessor").get()
    if preprocessor_doc.exists:
        data = preprocessor_doc.to_dict() or {}
        shadow_started_at = data.get("shadow_started_at")

    # Get PREPROCESSOR_MODE from Cloud Run - we would need to pass it or get from env.
    # For now, assume we get it from the caller (env or args).
    mode = "shadow"  # default; caller can override

    def _in_cohort(obj: Dict[str, Any]) -> bool:
        """True if obj.created_at >= shadow_started_at (cohort-bound)."""
        if not shadow_started_at:
            return True
        created = obj.get("created_at")
        if created is None:
            return False
        try:
            c_ts = created.timestamp() if hasattr(created, "timestamp") else 0
            s_ts = shadow_started_at.timestamp() if hasattr(shadow_started_at, "timestamp") else 0
            return c_ts >= s_ts
        except Exception:
            return False

    def _stream_cohort_docs(collection_name: str) -> Iterable[Any]:
        coll = client.collection(collection_name)
        if not shadow_started_at:
            return coll.stream()
        try:
            return coll.where("created_at", ">=", shadow_started_at).stream()
        except Exception:
            # Fallback to full scan if query/filter is unavailable.
            return coll.stream()

    # unique_shadow_processed_count: distinct message_id from queues where
    # created_at >= shadow_started_at and attempt_id present
    queue_docs = list(_stream_cohort_docs(queue_collection))
    seen_message_ids: set = set()
    cohort_queue_docs: list = []
    for doc in queue_docs:
        data = doc.to_dict() or {}
        if not data.get("attempt_id"):
            continue
        if not _in_cohort(data):
            continue
        cohort_queue_docs.append(data)
        mid = data.get("message_id")
        if mid:
            seen_message_ids.add(mid)
    unique_shadow_processed_count = len(seen_message_ids)

    # duplicate_queue_doc_count_by_message_id: message_ids that appear more than once
    # within cohort (created_at >= shadow_started_at)
    mid_counts: Dict[str, int] = {}
    for data in cohort_queue_docs:
        mid = data.get("message_id")
        if mid:
            mid_counts[mid] = mid_counts.get(mid, 0) + 1
    duplicate_queue_doc_count_by_message_id = sum(1 for c in mid_counts.values() if c > 1)

    # ingest_errors metrics (cohort-bound: created_at >= shadow_started_at)
    ingest_docs = list(_stream_cohort_docs(ingest_errors_collection))
    unknown_reject_code_count = 0
    preprocess_unhandled_exception_count = 0
    cohort_ingest_docs: list = []
    for doc in ingest_docs:
        data = doc.to_dict() or {}
        if not _in_cohort(data):
            continue
        cohort_ingest_docs.append(data)
        code = data.get("reject_code", "")
        if code and code not in KNOWN_INGEST_ERROR_CODES:
            unknown_reject_code_count += 1
        if code == "unhandled_exception":
            preprocess_unhandled_exception_count += 1

    reject_count = len(cohort_ingest_docs)

    # dropped_without_repair_record_count:
    # In shadow mode, rejected queue writes carry preprocessor_reject_code + attempt_id.
    # Count reject attempts in queues that do not have a matching ingest_errors record.
    reject_attempt_keys: Set[Tuple[str, str, str]] = set()
    for data in cohort_queue_docs:
        code = data.get("preprocessor_reject_code")
        attempt_id = data.get("attempt_id")
        message_id = data.get("message_id")
        if code and attempt_id and message_id:
            reject_attempt_keys.add((str(message_id), str(code), str(attempt_id)))

    repair_keys: Set[Tuple[str, str, str]] = set()
    for data in cohort_ingest_docs:
        code = data.get("reject_code")
        attempt_id = data.get("attempt_id")
        message_id = data.get("message_id")
        if code and attempt_id and message_id:
            repair_keys.add((str(message_id), str(code), str(attempt_id)))

    dropped_without_repair_record_count = len(reject_attempt_keys - repair_keys)

    metrics = PreprocessorGateMetrics(
        unique_shadow_processed_count=unique_shadow_processed_count,
        unknown_reject_code_count=unknown_reject_code_count,
        preprocess_unhandled_exception_count=preprocess_unhandled_exception_count,
        dropped_without_repair_record_count=dropped_without_repair_record_count,
        duplicate_queue_doc_count_by_message_id=duplicate_queue_doc_count_by_message_id,
        reject_count=reject_count,
        mode=mode,
    )
    return metrics, None


def check_preprocessor_gate(
    project_id: str,
    queue_collection: str = "queues",
    state_collection: str = "sync_state",
    ingest_errors_collection: str = "ingest_errors",
    preprocessor_mode: str = "shadow",
) -> Tuple[bool, Optional[str], Optional[PreprocessorGateMetrics]]:
    """
    Check if preprocessor gate passes. Returns (gate_passed, first_fail_reason, metrics).
    gate_passed=True when unique_shadow_processed_count >= 50 and all four counts are 0.
    """
    metrics, err = _query_preprocessor_gate(
        project_id, queue_collection, state_collection, ingest_errors_collection
    )
    if err or metrics is None:
        return False, err or "metrics unavailable", metrics

    metrics.mode = preprocessor_mode

    if metrics.unique_shadow_processed_count < GATE_THRESHOLD:
        return False, "unique_shadow_processed_count={} < 50".format(metrics.unique_shadow_processed_count), metrics
    if metrics.unknown_reject_code_count != 0:
        return False, "unknown_reject_code_count={}".format(metrics.unknown_reject_code_count), metrics
    if metrics.preprocess_unhandled_exception_count != 0:
        return False, "preprocess_unhandled_exception_count={}".format(metrics.preprocess_unhandled_exception_count), metrics
    if metrics.dropped_without_repair_record_count != 0:
        return False, "dropped_without_repair_record_count={}".format(metrics.dropped_without_repair_record_count), metrics
    if metrics.duplicate_queue_doc_count_by_message_id != 0:
        return False, "duplicate_queue_doc_count_by_message_id={}".format(metrics.duplicate_queue_doc_count_by_message_id), metrics

    return True, None, metrics
