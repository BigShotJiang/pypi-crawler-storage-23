"""Minimal regression tests for /admin/resume-history endpoint.

Tests cover request/response contract and hardening: valid requests succeed,
missing/wrong secret returns 403, and exceptions in process_history_event
are caught and return 500 with a generic body (no internal details leaked).
The production 500 fix was setting DEFAULT_MACHINE_ID; the handler change
improves diagnostics and safe failure mode.
"""

import sys
import os
import base64
import json
import unittest
from unittest.mock import Mock, patch

from googleapiclient.errors import HttpError

# Add parent directory to path to import modules
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

try:
    from fastapi.testclient import TestClient
    from api import APP
    TESTCLIENT_AVAILABLE = True
except ImportError:
    TESTCLIENT_AVAILABLE = False
    TestClient = None


if not TESTCLIENT_AVAILABLE:
    class TestAdminResumeHistoryDeps(unittest.TestCase):
        def test_missing_test_deps(self):
            self.skipTest(
                "FastAPI TestClient is not available. Install dev dependency: py -3.11 -m pip install httpx"
            )

else:
    def _pubsub_envelope(payload: dict, message_id: str = "msg-1") -> dict:
        encoded = base64.b64encode(json.dumps(payload).encode("utf-8")).decode("ascii")
        return {"message": {"messageId": message_id, "data": encoded}}


    class TestAdminResumeHistory(unittest.TestCase):
        """Test /admin/resume-history endpoint."""

        @patch('api.get_config')
        @patch('api.processor.process_history_event')
        @patch('api.services.gmail_client')
        def test_valid_request_with_secret_and_history_id(self, mock_gmail, mock_process, mock_config):
            """Test valid request with secret and history_id returns 200."""
            # Setup mocks
            config = Mock()
            config.admin_shared_secret = "test_secret_123"
            mock_config.return_value = config
            mock_process.return_value = {"processed": 1}

            # Test
            client = TestClient(APP)
            response = client.post(
                "/admin/resume-history",
                json={"secret": "test_secret_123", "history_id": 12345}
            )

            # Verify
            self.assertEqual(response.status_code, 200)
            self.assertIn("status", response.json())
            self.assertEqual(response.json()["status"], "ok")
            mock_process.assert_called_once()

        @patch('api.get_config')
        def test_missing_secret_returns_403(self, mock_config):
            """Test missing secret returns 403 Forbidden."""
            # Setup mocks
            config = Mock()
            config.admin_shared_secret = "test_secret_123"
            mock_config.return_value = config

            # Test
            client = TestClient(APP)
            response = client.post(
                "/admin/resume-history",
                json={"history_id": 12345}
            )

            # Verify
            self.assertEqual(response.status_code, 403)
            self.assertIn("detail", response.json())

        @patch('api.get_config')
        def test_wrong_secret_returns_403(self, mock_config):
            """Test wrong secret returns 403 Forbidden."""
            # Setup mocks
            config = Mock()
            config.admin_shared_secret = "test_secret_123"
            mock_config.return_value = config

            # Test
            client = TestClient(APP)
            response = client.post(
                "/admin/resume-history",
                json={"secret": "wrong_secret", "history_id": 12345}
            )

            # Verify
            self.assertEqual(response.status_code, 403)

        @patch('api.get_config')
        def test_secret_not_configured_returns_500(self, mock_config):
            """Test ADMIN_SHARED_SECRET not set returns 500."""
            # Setup mocks
            config = Mock()
            config.admin_shared_secret = None
            mock_config.return_value = config

            # Test
            client = TestClient(APP)
            response = client.post(
                "/admin/resume-history",
                json={"secret": "any_secret", "history_id": 12345}
            )

            # Verify
            self.assertEqual(response.status_code, 500)

        @patch('api.get_config')
        @patch('api.processor.process_history_event')
        def test_process_history_event_exception_returns_500_generic(self, mock_process, mock_config):
            """Test exception in process_history_event returns 500 with generic message.

            Hardening: any exception (e.g. RuntimeError from machine_id extraction) is
            caught and returned as 500 with generic body; actionable detail stays in logs.
            """
            # Setup mocks
            config = Mock()
            config.admin_shared_secret = "test_secret_123"
            mock_config.return_value = config

            # Simulate the actual bug: RuntimeError from _extract_machine_id
            mock_process.side_effect = RuntimeError("Unable to determine machine id for message 19c4453dbc96c88e")

            # Test
            client = TestClient(APP)
            response = client.post(
                "/admin/resume-history",
                json={"secret": "test_secret_123", "history_id": 12345}
            )

            # Verify
            self.assertEqual(response.status_code, 500)
            # Response body should be generic (not leak internal details)
            self.assertIn("detail", response.json())
            self.assertEqual(response.json()["detail"], "Internal Server Error")
            # The actual error should be in logs (verified manually via exc_info=True)

        @patch('api.get_config')
        @patch('api.processor.process_history_event')
        def test_accepts_historyId_camelcase(self, mock_process, mock_config):
            """Test endpoint accepts historyId (camelCase) as well as history_id."""
            # Setup mocks
            config = Mock()
            config.admin_shared_secret = "test_secret_123"
            mock_config.return_value = config
            mock_process.return_value = {"processed": 0}

            # Test
            client = TestClient(APP)
            response = client.post(
                "/admin/resume-history",
                json={"secret": "test_secret_123", "historyId": "67890"}
            )

            # Verify
            self.assertEqual(response.status_code, 200)
            # Verify historyId was passed as string
            call_args = mock_process.call_args
            self.assertIn("historyId", call_args[0][0])


    class TestPubSubPushRetrySemantics(unittest.TestCase):
        """Verify /pubsub/push returns retry-safe status codes."""

        @patch("api.processor.process_history_event")
        def test_malformed_payload_acks_2xx(self, mock_process):
            client = TestClient(APP)
            response = client.post(
                "/pubsub/push",
                json={"message": {"messageId": "m-bad", "data": "%%%not-base64%%%"}},
            )
            self.assertEqual(response.status_code, 200)
            payload = response.json()
            self.assertEqual(payload.get("status"), "acked_permanent_error")
            self.assertEqual(payload.get("retryable"), False)
            self.assertEqual(payload.get("error_class"), "invalid_base64")
            mock_process.assert_not_called()

        @patch("api.get_config")
        @patch("api.processor.process_history_event")
        def test_transient_processing_failure_returns_non_2xx(self, mock_process, mock_get_config):
            mock_get_config.return_value = Mock()
            mock_process.side_effect = RuntimeError("temporary firestore outage")
            client = TestClient(APP)
            response = client.post("/pubsub/push", json=_pubsub_envelope({"historyId": "12345"}, "m-transient"))
            self.assertEqual(response.status_code, 503)
            payload = response.json()
            self.assertEqual(payload.get("status"), "retryable_error")
            self.assertEqual(payload.get("retryable"), True)

        @patch("api.get_config")
        @patch("api.processor.process_history_event")
        def test_retryable_classification_is_logged(self, mock_process, mock_get_config):
            mock_get_config.return_value = Mock()
            mock_process.side_effect = TimeoutError("timeout")
            client = TestClient(APP)
            with self.assertLogs("medilink.orchestrator.api", level="ERROR") as logs:
                response = client.post("/pubsub/push", json=_pubsub_envelope({"historyId": "12345"}, "m-timeout"))
            self.assertEqual(response.status_code, 503)
            joined = "\n".join(logs.output)
            self.assertIn("retryable=True", joined)
            self.assertIn("error_class=network_or_os_error", joined)

        @patch("api.get_config")
        @patch("api.processor.process_history_event")
        def test_downstream_http_4xx_is_still_retryable(self, mock_process, mock_get_config):
            mock_get_config.return_value = Mock()
            mock_resp = Mock()
            mock_resp.status = 401
            mock_process.side_effect = HttpError(mock_resp, b"unauthorized")
            client = TestClient(APP)
            response = client.post("/pubsub/push", json=_pubsub_envelope({"historyId": "12345"}, "m-http-401"))
            self.assertEqual(response.status_code, 503)
            payload = response.json()
            self.assertEqual(payload.get("status"), "retryable_error")
            self.assertEqual(payload.get("error_class"), "downstream_http_error")
            self.assertEqual(payload.get("retryable"), True)


if __name__ == '__main__':
    unittest.main()
