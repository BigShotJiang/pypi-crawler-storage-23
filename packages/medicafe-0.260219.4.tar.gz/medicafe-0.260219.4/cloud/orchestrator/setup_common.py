#!/usr/bin/env python3
"""Validate and auto-complete MediLink cloud orchestrator setup.

Requires Python 3.11+. Run with your Python 3.11 environment, e.g.:
  py -3.11 validate_and_complete_setup.py
  python3.11 validate_and_complete_setup.py

This script is intended to be run from a developer machine with gcloud installed.
It can run in interactive mode (default) to query GCP for information and prompt
you for or confirm each setting. It then:
- validates resources (idempotent: re-running is safe; existing resources are detected)
- creates/fixes what can be safely automated
- optionally builds and deploys Cloud Run via Artifact Registry (2024+; avoids gcr.io NOT_FOUND)
- auto-falls back to a dedicated build service account when Cloud Build default SA is missing
- reports guided manual steps for what cannot be automated (including Docker build if Cloud Build returns NOT_FOUND)
"""

from __future__ import annotations

import argparse
import base64
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import time
import urllib.error
import urllib.request
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Sequence, Tuple


# Windows consoles can default to a legacy codepage (e.g. cp932) that cannot encode emoji.
# Keep output robust by forcing UTF-8 with replacement, and by avoiding non-ASCII markers.
try:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    if hasattr(sys.stderr, "reconfigure"):
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass


_ICON_OK = "OK"
_ICON_FAIL = "FAIL"
_ICON_INFO = "INFO"

# ----- Optional ANSI colors (best-effort) -----
_COLOR_MODE = "auto"  # "auto" | "always" | "never"
_COLOR_ENABLED = False

_ANSI_RESET = "\x1b[0m"
_ANSI_BOLD = "\x1b[1m"
_ANSI_DIM = "\x1b[2m"
_ANSI_RED = "\x1b[31m"
_ANSI_GREEN = "\x1b[32m"
_ANSI_YELLOW = "\x1b[33m"
_ANSI_CYAN = "\x1b[36m"


def _enable_windows_vt_processing() -> bool:
    """Best-effort enable ANSI escape sequence processing on Windows consoles."""
    if os.name != "nt":
        return True
    try:
        import ctypes  # local import: only needed on Windows

        kernel32 = ctypes.windll.kernel32  # type: ignore[attr-defined]
        handle = kernel32.GetStdHandle(-11)  # STD_OUTPUT_HANDLE = -11
        if handle in (0, -1):
            return False
        mode = ctypes.c_uint32()
        if kernel32.GetConsoleMode(handle, ctypes.byref(mode)) == 0:
            return False
        ENABLE_VIRTUAL_TERMINAL_PROCESSING = 0x0004
        new_mode = mode.value | ENABLE_VIRTUAL_TERMINAL_PROCESSING
        if kernel32.SetConsoleMode(handle, new_mode) == 0:
            return False
        return True
    except Exception:
        return False


def _supports_color() -> bool:
    if os.environ.get("NO_COLOR"):
        return False
    if not hasattr(sys.stdout, "isatty") or not sys.stdout.isatty():
        return False
    if os.name == "nt":
        # Windows Terminal/VSCode/ConEmu generally support ANSI; legacy hosts vary.
        if os.environ.get("WT_SESSION") or os.environ.get("TERM_PROGRAM") or os.environ.get("ANSICON") or os.environ.get("ConEmuANSI") == "ON":
            return True
        return _enable_windows_vt_processing()
    return True


def _configure_color(mode: str) -> None:
    global _COLOR_MODE, _COLOR_ENABLED
    _COLOR_MODE = (mode or "auto").strip().lower()
    if _COLOR_MODE == "never":
        _COLOR_ENABLED = False
    elif _COLOR_MODE == "always":
        _COLOR_ENABLED = True
        _enable_windows_vt_processing()
    else:
        _COLOR_ENABLED = _supports_color()


def _c(text: str, *styles: str) -> str:
    if not _COLOR_ENABLED or not styles:
        return text
    return "{}{}{}".format("".join(styles), text, _ANSI_RESET)


def _sanitize_console_text(text: str) -> str:
    """
    Avoid control characters that can cause "overprinting" or garbled copy/paste in Windows terminals.
    Keep ANSI (ESC) intact for coloring.
    """
    t = text or ""
    # Carriage returns can move the cursor to column 0 and cause later prints to appear duplicated.
    t = t.replace("\r", "")
    # NULs can break some terminals/log sinks.
    t = t.replace("\x00", "")
    return t


def _tag_ok() -> str:
    return _c(_ICON_OK, _ANSI_GREEN, _ANSI_BOLD)


def _tag_fail() -> str:
    return _c(_ICON_FAIL, _ANSI_RED, _ANSI_BOLD)


def _tag_info() -> str:
    return _c(_ICON_INFO, _ANSI_CYAN, _ANSI_BOLD)

REQUIRED_APIS = (
    "gmail.googleapis.com",
    "pubsub.googleapis.com",
    "run.googleapis.com",
    "iam.googleapis.com",
    "iamcredentials.googleapis.com",
    "secretmanager.googleapis.com",
    "firestore.googleapis.com",
    "storage.googleapis.com",
    "cloudbuild.googleapis.com",
    "compute.googleapis.com",            # required for Cloud Build worker (2024+ uses Compute default SA)
    "containerregistry.googleapis.com",  # legacy gcr.io (may NOT_FOUND in some projects)
    "artifactregistry.googleapis.com",   # preferred for new projects; use if gcr.io fails
    "cloudscheduler.googleapis.com",
)

SERVICE_ACCOUNT_ROLES = (
    "roles/storage.objectAdmin",
    "roles/datastore.user",
    "roles/pubsub.publisher",
    "roles/run.invoker",
)

# Minimum project-level roles for a dedicated Cloud Build execution identity.
CUSTOM_BUILD_SERVICE_ACCOUNT_PROJECT_ROLES = (
    "roles/artifactregistry.writer",
    "roles/logging.logWriter",
)

@dataclass
class CheckResult:
    name: str
    ok: bool
    detail: str


@dataclass
class ManualStep:
    title: str
    why: str
    instructions: List[str]


# Things you must obtain or do manually in GCP Console (or OAuth flow).
REQUIRED_MANUAL_STEPS: Tuple[ManualStep, ...] = (
    ManualStep(
        title="GCP Project",
        why="Script needs your GCP Project ID (and optionally project number for reference).",
        instructions=[
            "Use your Project ID (e.g. genial-analyzer-476721-f8). Project number (e.g. 442263322931) is shown for confirmation only.",
            "If not set: gcloud config set project YOUR_PROJECT_ID",
        ],
    ),
    ManualStep(
        title="OAuth 2.0 Client ID and Client Secret",
        why="Gmail API access and watch registration require OAuth credentials.",
        instructions=[
            "Go to: https://console.cloud.google.com/apis/credentials",
            "Create OAuth 2.0 Client ID (Application type: Desktop app or Web application).",
            "Download the JSON (installed or web format). This script will ask for its path and push client_id and client_secret to Secret Manager.",
        ],
    ),
    ManualStep(
        title="Gmail OAuth Refresh Token",
        why="The orchestrator uses a refresh token to access the mailbox and register the Gmail watch.",
        instructions=[
            "After providing the OAuth client JSON, this script can run the OAuth flow (opens browser) and store the refresh token in Secret Manager.",
            "Alternatively: run tools/get_gmail_oauth_token.ps1, or add the refresh token to Secret Manager manually.",
        ],
    ),
    ManualStep(
        title="Firestore database (if not created)",
        why="Initial database creation is a one-time console action. This script checks GCP and reports if (default) already exists and its location.",
        instructions=[
            "Console -> Firestore Database -> Create database -> Native mode.",
            "Choose a region consistent with your Cloud Run region (e.g. us-central1).",
            "Add composite index for collection 'queues': machine_id ASC, acked ASC, created_at ASC.",
        ],
    ),
    ManualStep(
        title="ADMIN_SHARED_SECRET (for Cloud Scheduler)",
        why="The scheduler job calls /admin/resume-history with this secret in the body.",
        instructions=[
            "Generate: openssl rand -hex 16",
            "Set on Cloud Run env: ADMIN_SHARED_SECRET=<value> (script can prompt to set it after first deploy).",
        ],
    ),
)


@dataclass
class Context:
    service_url: Optional[str]
    admin_secret: Optional[str]
    service_account_email: str


_gcloud_path: Optional[str] = None


def _resolve_gcloud_path() -> str:
    """
    Resolve a runnable gcloud executable path.

    On Windows, prefer gcloud.cmd/gcloud.exe over gcloud.ps1 to avoid
    PowerShell execution-policy failures when invoked from subprocess.
    """
    if os.name == "nt":
        for candidate in ("gcloud.cmd", "gcloud.exe", "gcloud.bat", "gcloud"):
            found = shutil.which(candidate)
            if found:
                return found
        return "gcloud.cmd"
    return shutil.which("gcloud") or "gcloud"


def _gcloud_exe() -> str:
    """Return path to gcloud executable (resolved so Windows finds gcloud.cmd)."""
    global _gcloud_path
    if _gcloud_path is None:
        _gcloud_path = _resolve_gcloud_path()
    return _gcloud_path


def _run(cmd: Sequence[str], cwd: Optional[str] = None) -> subprocess.CompletedProcess:
    cmd_list = list(cmd)
    if cmd_list and cmd_list[0] == "gcloud":
        cmd_list[0] = _gcloud_exe()
    return subprocess.run(
        cmd_list,
        check=False,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        cwd=cwd,
    )


def _run_json(cmd: Sequence[str]) -> Optional[object]:
    proc = _run(cmd)
    if proc.returncode != 0:
        return None
    text = (proc.stdout or "").strip()
    if not text:
        return None
    try:
        return json.loads(text)
    except Exception:
        return None


def _result(name: str, ok: bool, detail: str) -> CheckResult:
    return CheckResult(name=name, ok=ok, detail=detail)


def _print_result(result: CheckResult) -> None:
    icon = _tag_ok() if result.ok else _tag_fail()
    name = _c(result.name, _ANSI_BOLD)
    print("{} {}: {}".format(icon, name, _sanitize_console_text(result.detail)))


def _print_auto_action(message: str) -> None:
    print("{} AUTO ACTION: {}".format(_tag_info(), _sanitize_console_text(_c(message, _ANSI_YELLOW))))


def _command_error(proc: subprocess.CompletedProcess) -> str:
    return (proc.stderr or proc.stdout or "command failed").strip()


def _format_gcloud_dict_flag(pairs: Dict[str, str]) -> str:
    """
    Format KEY=VALUE pairs for gcloud dict flags.

    gcloud dict flags use comma separators by default, which breaks when values
    contain commas (for example "docx,csv"). Use custom delimiter syntax:
    ^<DELIM>^KEY1=VALUE1<DELIM>KEY2=VALUE2
    """
    items = ["{}={}".format(k, str(v)) for k, v in pairs.items()]
    # Avoid cmd.exe metacharacters first ("|", "%", "&", "<", ">") because
    # this script often executes gcloud.cmd on Windows.
    for delim in ("~", "#", "@", ";", ":"):
        if all(delim not in item for item in items):
            return "^{}^{}".format(delim, delim.join(items))
    # Fallback when all candidate delimiters appear in values.
    return ",".join(items)


def _gcloud_config_get(property_name: str) -> str:
    """Return gcloud config property value or empty string if unset/unavailable."""
    proc = _run(["gcloud", "config", "get-value", property_name])
    if proc.returncode != 0:
        return ""
    value = (proc.stdout or "").strip()
    if not value or value == "(unset)":
        return ""
    return value


def _gcloud_config_unset_if_set(property_name: str) -> bool:
    """Unset a gcloud config property if set (best effort). Returns True if it was unset."""
    val = _gcloud_config_get(property_name)
    if not val:
        return False
    _print_auto_action("Unsetting gcloud config {} (was set)".format(property_name))
    _run(["gcloud", "config", "unset", property_name])
    return True


def _gcloud_storage_ls_uris(prefix: str, project_id: str) -> List[str]:
    """
    Return object URIs under a gs:// prefix.

    gcloud storage ls exits non-zero when no objects match; treat that as empty.
    """
    proc = _run(["gcloud", "storage", "ls", prefix, "--project", project_id])
    if proc.returncode != 0:
        msg = _command_error(proc).lower()
        if "matched no objects" in msg or "no objects" in msg:
            return []
        return []
    return [ln.strip() for ln in (proc.stdout or "").splitlines() if ln.strip().startswith("gs://")]


def _cloudbuild_source_timestamp(uri: str) -> Optional[float]:
    """
    Parse Cloud Build source object names like:
      .../source/1770688941.610315-<uuid>.tgz
    Returns unix timestamp (seconds) or None if not parseable.
    """
    try:
        name = uri.split("/source/", 1)[1]
        head = name.split("-", 1)[0]
        return float(head)
    except Exception:
        return None


def _cleanup_cloud_build_source_tarballs(
    project_id: str,
    region: str,
    *,
    days: int,
    all_regions: bool,
    validate_only: bool,
    interactive: bool,
) -> CheckResult:
    """
    Safe cleanup for Cloud Build submit source archives (tgz) in staging buckets.

    This only deletes objects under bucket prefix /source/ and only when there are no ongoing builds.
    """
    if validate_only:
        return _result("Cloud Build source cleanup", True, "skipped in validate-only mode")

    # Safety: do not delete while builds are in progress.
    ongoing = _run([
        "gcloud", "builds", "list",
        "--project", project_id,
        "--region", region,
        "--ongoing",
        "--format", "value(id)",
        "--limit", "1",
    ])
    if ongoing.returncode == 0 and (ongoing.stdout or "").strip():
        return _result("Cloud Build source cleanup", False, "skipped: builds are currently running")

    buckets = _list_buckets(project_id)
    if not buckets:
        return _result("Cloud Build source cleanup", True, "skipped: could not list buckets")

    # Prefer known defaults; include additional regions only if requested.
    wanted: List[str] = []
    expected_regional = "{}_{}_cloudbuild".format(project_id, region)
    expected_global = "{}_cloudbuild".format(project_id)
    for b in (expected_regional, expected_global):
        if b in buckets and b not in wanted:
            wanted.append(b)

    for b in buckets:
        if b in wanted:
            continue
        if b.startswith(project_id + "_") and b.endswith("_cloudbuild") and all_regions:
            wanted.append(b)
        if b.startswith(project_id + "-cloudbuild-"):
            # Custom staging bucket pattern used by some setups.
            if all_regions or b.endswith("-" + region):
                wanted.append(b)

    if not wanted:
        return _result("Cloud Build source cleanup", True, "no cloudbuild staging buckets detected")

    now = time.time()
    cutoff = now - (max(days, 0) * 86400)
    delete_all = days <= 0

    to_delete: List[str] = []
    scanned = 0
    for b in wanted:
        prefix = "gs://{}/source/**".format(b)
        uris = _gcloud_storage_ls_uris(prefix, project_id)
        for u in uris:
            scanned += 1
            if not (u.lower().endswith(".tgz") or u.lower().endswith(".tar.gz")):
                continue
            if delete_all:
                to_delete.append(u)
                continue
            ts = _cloudbuild_source_timestamp(u)
            if ts is None:
                continue
            if ts < cutoff:
                to_delete.append(u)

    if not to_delete:
        if scanned == 0:
            return _result("Cloud Build source cleanup", True, "no source archives found")
        return _result("Cloud Build source cleanup", True, "no eligible source archives found (days={})".format(days))

    if interactive:
        preview = ", ".join(to_delete[:3])
        if len(to_delete) > 3:
            preview += " (+{} more)".format(len(to_delete) - 3)
        if not _confirm(
            "Delete {} Cloud Build source archive(s) from staging buckets (days={}, all_regions={})? {}".format(
                len(to_delete), days, all_regions, preview
            ),
            default=False,
        ):
            return _result("Cloud Build source cleanup", True, "skipped by user")

    _print_auto_action("Cleaning Cloud Build source archives (count={})".format(len(to_delete)))
    deleted = 0
    for u in to_delete:
        rm = _run(["gcloud", "storage", "rm", u, "--project", project_id])
        if rm.returncode == 0:
            deleted += 1
    return _result("Cloud Build source cleanup", True, "deleted {} object(s)".format(deleted))


def _cloud_build_auto_remediate_gcloud_overrides() -> List[str]:
    """Clear hidden build overrides that can force NOT_FOUND by referencing missing resources."""
    cleared: List[str] = []
    for prop in ("builds/worker_pool", "builds/service_account", "api_endpoint_overrides/cloudbuild"):
        if _gcloud_config_unset_if_set(prop):
            cleared.append(prop)
    return cleared


def _resolve_secret_marker(project_id: str, value: str) -> str:
    """
    Resolve '<secret:NAME:VERSION>' marker values to their Secret Manager payload via gcloud.
    Returns '' if not resolvable (e.g. permission denied or missing secret/version).
    """
    raw = (value or "").strip()
    m = re.match(r"^<secret:([^:>]+):([^>]+)>$", raw)
    if not m:
        return raw
    secret_name = m.group(1)
    version = m.group(2) or "latest"
    proc = _run([
        "gcloud", "secrets", "versions", "access", version,
        "--secret", secret_name,
        "--project", project_id,
    ])
    if proc.returncode != 0:
        return ""
    return (proc.stdout or "").strip()


def _print_identity_token(project_id: str, audience: str, *, impersonate_service_account: str = "") -> Tuple[str, str]:
    """
    Return an identity token for the given audience, or '' on failure.
    Note: Cloud Run expects aud = service URL (no path).
    """
    cmd = [
        "gcloud", "auth", "print-identity-token",
        "--project", project_id,
        "--audiences", audience,
    ]
    if impersonate_service_account:
        cmd.extend(["--impersonate-service-account", impersonate_service_account])
    proc = _run(cmd)
    if proc.returncode != 0:
        err = _command_error(proc)
        # Some gcloud installations do not accept --project on this command; retry without it.
        if "unrecognized arguments" in err.lower() and "--project" in err:
            cmd2 = [
                "gcloud", "auth", "print-identity-token",
                "--audiences", audience,
            ]
            if impersonate_service_account:
                cmd2.extend(["--impersonate-service-account", impersonate_service_account])
            proc2 = _run(cmd2)
            if proc2.returncode != 0:
                return "", _command_error(proc2)
            proc = proc2
        else:
            return "", err
    text = (proc.stdout or "").strip()
    for line in reversed(text.splitlines()):
        t = line.strip()
        if re.match(r"^[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+$", t):
            return t, ""
    return "", "identity token output did not contain a JWT"


def _call_cloud_run_admin_post(
    project_id: str,
    region: str,
    service_name: str,
    service_url: str,
    path: str,
    body_dict: Dict[str, Any],
    validate_only: bool,
    interactive: bool,
) -> Tuple[bool, Optional[Dict[str, Any]], str]:
    """
    POST to Cloud Run admin endpoint. Returns (ok, response_body, error).
    Best-effort; should never crash the validator.
    """
    if not service_url:
        return False, None, "missing service URL"
    if not body_dict.get("secret"):
        return False, None, "ADMIN_SHARED_SECRET missing/unresolvable"

    token, token_err = _print_identity_token(project_id, service_url)
    if not token:
        if (
            "invalid account type" in (token_err or "").lower()
            and "--audiences" in (token_err or "")
            and interactive
            and not validate_only
        ):
            acct = _get_active_gcloud_account()
            if acct and _confirm(
                "gcloud cannot mint a user identity token with --audiences. Impersonate the Cloud Run service account to call the admin endpoint?",
                default=True,
            ):
                imp_sa = "{}@{}.iam.gserviceaccount.com".format(service_name, project_id)
                token2, token2_err = _print_identity_token(project_id, service_url, impersonate_service_account=imp_sa)
                if not token2 and ("permission" in (token2_err or "").lower() or "denied" in (token2_err or "").lower()) and acct:
                    if _confirm(
                        "Impersonation failed. Grant roles/iam.serviceAccountTokenCreator on {} to user:{} and retry?".format(imp_sa, acct),
                        default=False,
                    ):
                        ok_bind, err_bind = _ensure_service_account_binding(
                            project_id,
                            imp_sa,
                            "user:{}".format(acct),
                            "roles/iam.serviceAccountTokenCreator",
                        )
                        if ok_bind:
                            token2, token2_err = _print_identity_token(project_id, service_url, impersonate_service_account=imp_sa)
                        else:
                            return False, None, "grant Token Creator failed: {}".format(err_bind)
                if not token2:
                    return False, None, "could not obtain identity token via impersonation: {}".format(token2_err)
                token = token2
        if not token:
            return False, None, "could not obtain identity token (aud={}): {}".format(service_url, token_err)

    url = service_url.rstrip("/") + path
    body = json.dumps(body_dict).encode("utf-8")
    req = urllib.request.Request(
        url,
        data=body,
        method="POST",
        headers={
            "Authorization": "Bearer {}".format(token),
            "Content-Type": "application/json",
        },
    )

    def _do_request() -> Tuple[bool, Optional[Dict[str, Any]], str]:
        try:
            with urllib.request.urlopen(req, timeout=60) as resp:
                raw = resp.read()
                try:
                    parsed = json.loads(raw.decode("utf-8"))
                except Exception:
                    parsed = None
                return True, parsed, ""
        except urllib.error.HTTPError as exc:
            code = getattr(exc, "code", None)
            if code in (401, 403) and (not validate_only) and interactive:
                acct = _get_active_gcloud_account()
                if acct and _confirm(
                    "Admin endpoint returned HTTP {}. Grant roles/run.invoker on Cloud Run service '{}' to user:{} and retry once?".format(code, service_name, acct),
                    default=False,
                ):
                    add = _run([
                        "gcloud", "run", "services", "add-iam-policy-binding", service_name,
                        "--project", project_id, "--region", region,
                        "--member", "user:{}".format(acct),
                        "--role", "roles/run.invoker",
                        "--quiet",
                    ])
                    if add.returncode == 0:
                        token2, _ = _print_identity_token(project_id, service_url)
                        if token2:
                            req2 = urllib.request.Request(url, data=body, method="POST", headers={
                                "Authorization": "Bearer {}".format(token2),
                                "Content-Type": "application/json",
                            })
                            try:
                                with urllib.request.urlopen(req2, timeout=60) as resp2:
                                    raw2 = resp2.read()
                                    try:
                                        parsed = json.loads(raw2.decode("utf-8"))
                                    except Exception:
                                        parsed = None
                                    return True, parsed, "ok (after granting invoker)"
                            except Exception as exc2:
                                return False, None, "retry failed: {}".format(exc2)
            return False, None, "HTTP {}: {}".format(code, str(exc))
        except Exception as exc:
            return False, None, str(exc)

    return _do_request()


def _call_cloud_run_admin_resume_history(
    project_id: str,
    region: str,
    service_name: str,
    service_url: str,
    admin_secret_value: str,
    validate_only: bool,
    interactive: bool,
) -> Tuple[bool, str]:
    """
    Best-effort call to POST /admin/resume-history to force a Gmail-using action.
    This is intentionally best-effort and should never crash the validator.
    """
    ok, _, err = _call_cloud_run_admin_post(
        project_id,
        region,
        service_name,
        service_url,
        "/admin/resume-history",
        {"secret": admin_secret_value},
        validate_only,
        interactive,
    )
    if ok:
        return True, err or "ok"
    return False, err


def _extract_service_account_email(value: str) -> str:
    """Normalize service account value to email if possible."""
    v = (value or "").strip().strip('"').strip("'")
    if not v:
        return ""
    marker = "/serviceAccounts/"
    if marker in v:
        return v.split(marker, 1)[1]
    return v


def _service_account_resource_name(default_project_id: str, value: str) -> str:
    """Return projects/<id>/serviceAccounts/<email> from email or full resource."""
    raw = (value or "").strip().strip('"').strip("'")
    if not raw:
        return ""
    if raw.startswith("projects/") and "/serviceAccounts/" in raw:
        return raw
    email = _extract_service_account_email(raw)
    if not email:
        return ""
    m = re.match(r"^[^@]+@([^.]+)\.iam\.gserviceaccount\.com$", email)
    sa_project = m.group(1) if m else default_project_id
    return "projects/{}/serviceAccounts/{}".format(sa_project, email)


def _is_permission_denied(proc: subprocess.CompletedProcess) -> bool:
    msg = _command_error(proc).lower()
    return "permission_denied" in msg or "permission denied" in msg or "iam.serviceaccounts.get" in msg


def _get_active_gcloud_account() -> str:
    proc = _run(["gcloud", "auth", "list", "--filter=status:ACTIVE", "--format=value(account)"])
    if proc.returncode != 0:
        return ""
    return (proc.stdout or "").strip()


def _get_project_number(project_id: str) -> str:
    info = _get_project_info(project_id)
    return str((info or {}).get("projectNumber") or "").strip()


def _get_cloud_build_default_service_account(project_id: str, region: str) -> str:
    """Return Cloud Build default SA email for region, or empty string if unavailable."""
    payload = _run_json([
        "gcloud", "builds", "get-default-service-account",
        "--project", project_id, "--region", region, "--format=json",
    ])
    if isinstance(payload, dict):
        email = _extract_service_account_email(str(payload.get("serviceAccountEmail") or ""))
        if email:
            return email
    proc = _run([
        "gcloud", "builds", "get-default-service-account",
        "--project", project_id, "--region", region, "--format=value(serviceAccountEmail)",
    ])
    if proc.returncode != 0:
        return ""
    return _extract_service_account_email(proc.stdout or "")


def _service_account_state(project_id: str, service_account_email: str) -> str:
    """Return one of: exists, not_found, permission_denied, error."""
    proc = _run([
        "gcloud", "iam", "service-accounts", "describe", service_account_email,
        "--project", project_id,
    ])
    if proc.returncode == 0:
        return "exists"
    if _is_permission_denied(proc):
        return "permission_denied"
    err = _command_error(proc).lower()
    if "unknown service account" in err or "not found" in err:
        return "not_found"
    return "error"


def _ensure_project_role_binding(project_id: str, member: str, role: str) -> Tuple[bool, str]:
    bind = _run([
        "gcloud", "projects", "add-iam-policy-binding", project_id,
        "--member", member, "--role", role, "--quiet",
    ])
    if bind.returncode == 0:
        return True, ""
    err = _command_error(bind)
    if "already exists" in err.lower():
        return True, ""
    return False, err


def _ensure_cloud_build_logs_bucket_access(project_id: str, region: str, build_service_account_email: str) -> Tuple[bool, str]:
    """
    Ensure the regional Cloud Build logs bucket exists and is writable by the build SA.

    gcloud builds submit can fail with FAILED_PRECONDITION if the selected build SA cannot
    create/read objects in gs://<PROJECT_NUMBER>-<REGION>-cloudbuild-logs.
    """
    project_number = _get_project_number(project_id)
    if not project_number:
        return False, "could not get project number for logs bucket"
    bucket_uri = "gs://{}-{}-cloudbuild-logs".format(project_number, region)
    describe = _run([
        "gcloud", "storage", "buckets", "describe", bucket_uri, "--project", project_id,
    ])
    if describe.returncode != 0:
        create = _run([
            "gcloud", "storage", "buckets", "create", bucket_uri,
            "--project", project_id, "--location", region, "--uniform-bucket-level-access",
        ])
        if create.returncode != 0:
            return False, "create logs bucket {}: {}".format(bucket_uri, _command_error(create))
    ok, err = _ensure_bucket_role_binding(bucket_uri, project_id, build_service_account_email, "roles/storage.admin")
    if not ok:
        return False, "grant roles/storage.admin on {} to {}: {}".format(bucket_uri, build_service_account_email, err)
    return True, bucket_uri


def _ensure_service_account_binding(
    project_id: str,
    target_service_account_email: str,
    member: str,
    role: str,
) -> Tuple[bool, str]:
    bind = _run([
        "gcloud", "iam", "service-accounts", "add-iam-policy-binding",
        target_service_account_email,
        "--member", member,
        "--role", role,
        "--project", project_id,
    ])
    if bind.returncode == 0:
        return True, ""
    err = _command_error(bind)
    if "already exists" in err.lower():
        return True, ""
    return False, err


def _ensure_bucket_role_binding(bucket_uri: str, project_id: str, service_account_email: str, role: str) -> Tuple[bool, str]:
    bind = _run([
        "gcloud", "storage", "buckets", "add-iam-policy-binding", bucket_uri,
        "--member", "serviceAccount:{}".format(service_account_email),
        "--role", role, "--project", project_id,
    ])
    if bind.returncode == 0:
        return True, ""
    err = _command_error(bind)
    if "already exists" in err.lower():
        return True, ""
    return False, err


def _ensure_service_account_exists(project_id: str, service_account_email: str, *, display_name: str) -> Tuple[bool, str]:
    """
    Ensure a service account exists.

    Note: this helper lives in setup_common to avoid circular imports (setup_flow also has an _ensure_service_account).
    """
    sa_email = (service_account_email or "").strip()
    if not sa_email or "@" not in sa_email:
        return False, "invalid service account email: {}".format(service_account_email)

    describe = _run([
        "gcloud", "iam", "service-accounts", "describe", sa_email,
        "--project", project_id,
    ])
    if describe.returncode == 0:
        return True, ""
    if _is_permission_denied(describe):
        return False, "permission denied describing service account {} (need iam.serviceAccounts.get)".format(sa_email)

    account_id = sa_email.split("@", 1)[0]
    create = _run([
        "gcloud", "iam", "service-accounts", "create", account_id,
        "--project", project_id,
        "--display-name", display_name,
    ])
    if create.returncode == 0:
        return True, ""
    return False, _command_error(create)


def _ensure_custom_cloud_build_service_account(
    project_id: str,
    region: str,
    account_name: str,
) -> Tuple[bool, str]:
    """
    Ensure a dedicated build SA exists and has minimum permissions.

    Why this exists:
    Some projects now default Cloud Build to the Compute Engine default SA.
    If that default SA was deleted (common hardening step), CreateBuild may fail
    before a build record is created. A dedicated SA plus --service-account avoids
    that hidden dependency.
    """
    build_sa_email = "{}@{}.iam.gserviceaccount.com".format(account_name, project_id)
    ok_sa, err_sa = _ensure_service_account_exists(
        project_id,
        build_sa_email,
        display_name="MediLink Cloud Build SA ({})".format(region),
    )
    if not ok_sa:
        return False, "ensure custom build service account: {}".format(err_sa)

    # Grant project-level roles needed for image push/logging.
    for role in CUSTOM_BUILD_SERVICE_ACCOUNT_PROJECT_ROLES:
        ok, err = _ensure_project_role_binding(project_id, "serviceAccount:{}".format(build_sa_email), role)
        if not ok:
            return False, "grant {} to {}: {}".format(role, build_sa_email, err)

    project_number = _get_project_number(project_id)
    if project_number:
        # Allow Cloud Build control-plane identity to run builds as this SA.
        control_plane_member = "serviceAccount:service-{}@gcp-sa-cloudbuild.iam.gserviceaccount.com".format(project_number)
        ok, err = _ensure_service_account_binding(
            project_id=project_id,
            target_service_account_email=build_sa_email,
            member=control_plane_member,
            role="roles/iam.serviceAccountUser",
        )
        if not ok:
            return False, "grant roles/iam.serviceAccountUser to Cloud Build service agent on {}: {}".format(build_sa_email, err)

    active_account = _get_active_gcloud_account()
    if active_account:
        # Caller also needs actAs when passing --service-account on submit.
        ok, err = _ensure_service_account_binding(
            project_id=project_id,
            target_service_account_email=build_sa_email,
            member="user:{}".format(active_account),
            role="roles/iam.serviceAccountUser",
        )
        if not ok:
            return False, "grant roles/iam.serviceAccountUser to {} on {}: {}".format(active_account, build_sa_email, err)

    logs_ok, logs_msg = _ensure_cloud_build_logs_bucket_access(project_id, region, build_sa_email)
    if not logs_ok:
        return False, logs_msg
    return True, build_sa_email


def _cloud_build_preflight_hints(project_id: str, region: str) -> List[str]:
    """Detect common hidden Cloud Build submit misconfigurations that cause NOT_FOUND."""
    hints: List[str] = []

    # Hidden gcloud property can force builds to use a deleted/missing private pool.
    worker_pool = _gcloud_config_get("builds/worker_pool")
    if worker_pool:
        m = re.match(
            r"^projects/(?P<project>[^/]+)/locations/(?P<region>[^/]+)/workerPools/(?P<pool>[^/]+)$",
            worker_pool,
        )
        if m:
            pool_project = m.group("project")
            pool_region = m.group("region")
            pool_name = m.group("pool")
            describe = _run([
                "gcloud", "builds", "worker-pools", "describe", pool_name,
                "--region", pool_region, "--project", pool_project,
            ])
            if describe.returncode != 0:
                hints.append(
                    "gcloud config builds/worker_pool is set to '{}' but that worker pool was not found.".format(worker_pool)
                )
        else:
            hints.append(
                "gcloud config builds/worker_pool is set to '{}'. Verify this worker pool exists and is in the intended project/region.".format(worker_pool)
            )

    # Hidden gcloud property can force builds to use a deleted service account.
    configured_sa = _gcloud_config_get("builds/service_account")
    if configured_sa:
        sa_email = _extract_service_account_email(configured_sa)
        if sa_email:
            describe_sa = _run([
                "gcloud", "iam", "service-accounts", "describe", sa_email,
                "--project", project_id,
            ])
            if describe_sa.returncode != 0:
                if _is_permission_denied(describe_sa):
                    hints.append(
                        "Unable to verify gcloud config builds/service_account '{}' because iam.serviceAccounts.get is denied for the current caller.".format(configured_sa)
                    )
                else:
                    hints.append(
                        "gcloud config builds/service_account is set to '{}' but that service account was not found.".format(configured_sa)
                    )
        else:
            hints.append(
                "gcloud config builds/service_account is set to '{}'. Verify this service account exists.".format(configured_sa)
            )

    # Non-default endpoint overrides can point the CLI at wrong/retired endpoints.
    endpoint_override = _gcloud_config_get("api_endpoint_overrides/cloudbuild")
    if endpoint_override:
        hints.append(
            "gcloud config api_endpoint_overrides/cloudbuild is set to '{}'. Unset it unless intentionally required.".format(endpoint_override)
        )

    # Check Cloud Build default service account selected by backend.
    default_sa = _get_cloud_build_default_service_account(project_id, region)
    if default_sa:
        describe_default_sa = _run([
            "gcloud", "iam", "service-accounts", "describe", default_sa,
            "--project", project_id,
        ])
        if describe_default_sa.returncode != 0:
            if _is_permission_denied(describe_default_sa):
                hints.append(
                    "Unable to verify Cloud Build default service account '{}' because iam.serviceAccounts.get is denied for the current caller.".format(default_sa)
                )
            else:
                hints.append(
                    "Cloud Build default service account '{}' was not found in project '{}'.".format(default_sa, project_id)
                )

    return hints


def _require_python_311() -> None:
    """Ensure we are running under Python 3.11+ (recommended for this project)."""
    if sys.version_info < (3, 11):
        print("This script requires Python 3.11 or newer. Current: {}".format(sys.version), file=sys.stderr)
        print("Run with Python 3.11, e.g.: py -3.11 validate_and_complete_setup.py", file=sys.stderr)
        raise RuntimeError("Python 3.11+ required")


def _require_gcloud() -> None:
    resolved = _gcloud_exe()
    # resolved may be an absolute path or a command name fallback.
    if os.path.isabs(resolved):
        if os.path.exists(resolved):
            return
        raise RuntimeError("gcloud CLI not found at resolved path: {}".format(resolved))
    if shutil.which(resolved):
        return
    raise RuntimeError("gcloud CLI not found in PATH")


def _get_project_from_gcloud() -> Optional[str]:
    """Return current gcloud project ID, or None if unset."""
    proc = _run(["gcloud", "config", "get-value", "project"])
    if proc.returncode != 0:
        return None
    out = (proc.stdout or "").strip()
    return out if out and not out.startswith("(") else None


def _get_project_info(project_id: str) -> Optional[Dict[str, Any]]:
    """Return project details (projectNumber, name, projectId) from GCP, or None."""
    payload = _run_json([
        "gcloud", "projects", "describe", project_id,
        "--format=json",
    ])
    if isinstance(payload, dict):
        return payload
    return None


def _list_cloud_run_services(project_id: str) -> List[Tuple[str, str, str]]:
    """Return list of (region, service_name, url) for all Cloud Run services in project."""
    # Cloud Run is regional; we must list per region.
    regions_payload = _run_json(["gcloud", "run", "regions", "list", "--project", project_id, "--format=json"])
    if not isinstance(regions_payload, list):
        return []
    regions: List[str] = []
    for item in regions_payload:
        if isinstance(item, dict):
            region = (
                item.get("locationId")
                or item.get("LOCATION")
                or (item.get("metadata") or {}).get("name")
                or item.get("name")
                or ""
            )
            region = str(region).strip()
            if region and "/" in region:
                region = region.split("/")[-1]
            if region:
                regions.append(region)
    regions = sorted(set(regions))
    result: List[Tuple[str, str, str]] = []
    for region in regions:
        payload = _run_json([
            "gcloud", "run", "services", "list",
            "--project", project_id, "--region", region, "--format=json",
        ])
        if not isinstance(payload, list):
            continue
        for item in payload:
            if not isinstance(item, dict):
                continue
            name = (item.get("metadata") or {}).get("name") or item.get("name") or ""
            name = str(name).strip()
            if "/" in name:
                name = name.split("/")[-1]
            url = str((item.get("status") or {}).get("url") or item.get("uri") or "").strip()
            if name:
                result.append((region, name, url))
    return result


def _try_get_cloud_run_service(project_id: str, region: str, service_name: str) -> Optional[Tuple[str, str, str]]:
    """Fast path: describe a specific Cloud Run service in a specific region."""
    if not project_id or not region or not service_name:
        return None
    payload = _run_json([
        "gcloud", "run", "services", "describe", service_name,
        "--project", project_id,
        "--region", region,
        "--format=json",
    ])
    if not isinstance(payload, dict):
        return None
    name = (payload.get("metadata") or {}).get("name") or service_name
    url = str((payload.get("status") or {}).get("url") or payload.get("uri") or "").strip()
    return (region, name, url)


def _list_buckets(project_id: str) -> List[str]:
    """Return list of bucket names in the project."""
    payload = _run_json([
        "gcloud", "storage", "buckets", "list",
        "--project", project_id, "--format=json",
    ])
    if not isinstance(payload, list):
        return []
    names = []
    for item in payload:
        if isinstance(item, dict):
            n = item.get("name")
            if n:
                names.append(n)
    return names


def _list_pubsub_topics(project_id: str) -> List[str]:
    """Return list of Pub/Sub topic names in the project."""
    payload = _run_json([
        "gcloud", "pubsub", "topics", "list",
        "--project", project_id, "--format=json",
    ])
    if not isinstance(payload, list):
        return []
    names = []
    for item in payload:
        if isinstance(item, dict):
            n = (item.get("name") or "").split("/")[-1]
            if n:
                names.append(n)
    return names


def _check_secret_has_version(project_id: str, secret_name: str) -> bool:
    """Return True if the secret exists and has at least one version."""
    proc = _run([
        "gcloud", "secrets", "versions", "list", secret_name,
        "--project", project_id, "--limit", "1", "--format=value(name)",
    ])
    if proc.returncode != 0:
        return False
    return bool((proc.stdout or "").strip())


def _parse_oauth_client_json(path_or_content: str) -> Optional[Dict[str, Any]]:
    """Parse OAuth client JSON (file path or raw JSON string). Returns dict with 'installed' or 'web' key for InstalledAppFlow, or None."""
    raw: Optional[str] = None
    if path_or_content.strip().startswith("{"):
        raw = path_or_content.strip()
    else:
        path = path_or_content.strip()
        # Strip surrounding quotes so pasted paths like "C:\path\to\file.json" work
        if len(path) >= 2 and path[0] == path[-1] and path[0] in ("'", '"'):
            path = path[1:-1]
        if os.path.isfile(path):
            try:
                with open(path, "r", encoding="utf-8") as f:
                    raw = f.read()
            except Exception:
                return None
        else:
            return None
    if not raw:
        return None
    try:
        data = json.loads(raw)
    except json.JSONDecodeError:
        return None
    if not isinstance(data, dict):
        return None
    # Support both "installed" and "web" credential types (Google client JSON format).
    if "installed" in data and isinstance(data["installed"], dict):
        return data
    if "web" in data and isinstance(data["web"], dict):
        # InstalledAppFlow expects "installed" with redirect_uris; web has redirect_uris.
        # Use as-is; InstalledAppFlow.from_client_config accepts "web" too.
        return data
    return None


def _ensure_secret_created(project_id: str, secret_name: str) -> Tuple[bool, str]:
    """Create the secret if it does not exist. Returns (True, '') if secret exists or was created, (False, error_msg) otherwise."""
    proc = _run(["gcloud", "secrets", "describe", secret_name, "--project", project_id])
    if proc.returncode == 0:
        return True, ""
    create = _run([
        "gcloud", "secrets", "create", secret_name,
        "--replication-policy", "automatic", "--project", project_id,
    ])
    if create.returncode == 0:
        return True, ""
    err = _command_error(create)
    # Secret might already exist (e.g. created in same project by another tool); describe can sometimes fail.
    if "already exists" in err.lower() or "ALREADY_EXISTS" in err:
        return True, ""
    return False, err


def _add_secret_version_gcloud(project_id: str, secret_name: str, value: str) -> Tuple[bool, str]:
    """Add a new version to the secret with the given string value. Returns (True, '') on success, (False, error_msg) otherwise."""
    try:
        with tempfile.NamedTemporaryFile(mode="w", suffix=".txt", delete=False, encoding="utf-8") as f:
            f.write(value)
            path = f.name
        try:
            proc = _run([
                "gcloud", "secrets", "versions", "add", secret_name,
                "--project", project_id, "--data-file", path,
            ])
            if proc.returncode == 0:
                return True, ""
            return False, _command_error(proc)
        finally:
            try:
                os.unlink(path)
            except Exception:
                pass
    except Exception as e:
        return False, str(e)


def _run_oauth_flow_and_store_refresh_token(
    project_id: str,
    client_config: Dict[str, Any],
    refresh_token_secret: str,
    mailbox_user: str = "",
    client_id_secret_name: str = "gmail_oauth_client_id",
    client_secret_secret_name: str = "gmail_oauth_client_secret",
    oauth_client_json_path: str = "",
    prefer_powershell: bool = False,
) -> Tuple[bool, str]:
    """Run local OAuth flow (opens browser), get refresh token, store in Secret Manager. Returns (success, message)."""
    def _run_ps1_fallback(reason: str) -> Tuple[bool, str]:
        # Optional Windows fallback: invoke tools/get_gmail_oauth_token.ps1
        # when the Python OAuth flow fails in this environment.
        if os.name != "nt":
            return False, ""
        script_candidates = [
            os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..", "tools", "get_gmail_oauth_token.ps1")),
            os.path.abspath(os.path.join(os.getcwd(), "tools", "get_gmail_oauth_token.ps1")),
        ]
        script_path = next((p for p in script_candidates if os.path.exists(p)), "")
        if not script_path:
            return False, "OAuth flow failed: {}. PowerShell fallback script not found at tools/get_gmail_oauth_token.ps1.".format(reason)
        _print_auto_action("Python OAuth flow failed; invoking PowerShell fallback token tool")
        proc = _run([
            "powershell.exe",
            "-NoProfile",
            "-ExecutionPolicy", "Bypass",
            "-File", script_path,
            "-ProjectId", project_id,
            "-Mailbox", mailbox_user,
            "-ClientIdSecret", client_id_secret_name,
            "-ClientSecretSecret", client_secret_secret_name,
            "-RefreshTokenSecret", refresh_token_secret,
        ] + (["-ClientJsonPath", oauth_client_json_path] if oauth_client_json_path else []))
        if proc.returncode == 0:
            return True, "Refresh token stored in Secret Manager (PowerShell fallback)"
        return False, "OAuth flow failed: {}. PowerShell fallback failed: {}".format(reason, _command_error(proc))

    if prefer_powershell and os.name == "nt":
        _print_auto_action("Using PowerShell token tool for OAuth refresh token flow")
        ok, msg = _run_ps1_fallback("requested PowerShell token flow")
        if ok:
            return True, msg
        print("PowerShell token flow failed; falling back to Python OAuth flow: {}".format(msg))

    try:
        from google_auth_oauthlib.flow import InstalledAppFlow
    except ImportError:
        ok, msg = _run_ps1_fallback("google-auth-oauthlib not installed in {}".format(sys.executable))
        if ok:
            return True, msg
        return False, (
            "{} Install it in this Python environment: "
            "'{} -m pip install google-auth-oauthlib' (or -r cloud/orchestrator/requirements.txt), "
            "then re-run this script with the same Python and choose the OAuth flow again."
        ).format(msg or "google-auth-oauthlib not installed.", sys.executable)
    scopes = ["https://www.googleapis.com/auth/gmail.modify"]
    # Ensure config has a key InstalledAppFlow accepts (installed or web) with redirect_uris.
    config = dict(client_config)
    if "installed" in config and isinstance(config["installed"], dict):
        block = config["installed"]
    elif "web" in config and isinstance(config["web"], dict):
        block = dict(config["web"])
        if "redirect_uris" not in block or not block["redirect_uris"]:
            block["redirect_uris"] = ["http://localhost"]
        config = {"installed": block}
    else:
        return False, "OAuth config must contain 'installed' or 'web' block"
    if "redirect_uris" not in config.get("installed", {}) or not config["installed"].get("redirect_uris"):
        config.setdefault("installed", {})["redirect_uris"] = ["http://localhost"]
    try:
        flow = InstalledAppFlow.from_client_config(config, scopes=scopes)
        creds = flow.run_local_server(port=0, prompt="consent")
    except Exception as e:
        ok, msg = _run_ps1_fallback(str(e))
        if ok:
            return True, msg
        return False, msg or "OAuth flow failed: {}".format(e)
    refresh_token = getattr(creds, "refresh_token", None) if creds else None
    if not refresh_token:
        ok, msg = _run_ps1_fallback("No refresh token returned from InstalledAppFlow")
        if ok:
            return True, msg
        return False, msg or "No refresh token returned; ensure you grant offline access (prompt=consent)."
    ok, err = _ensure_secret_created(project_id, refresh_token_secret)
    if not ok:
        return False, "Could not create Secret Manager secret for refresh token: {}".format(err)
    ok, err = _add_secret_version_gcloud(project_id, refresh_token_secret, refresh_token)
    if not ok:
        return False, "Could not add refresh token version to Secret Manager: {}".format(err)
    return True, "Refresh token stored in Secret Manager"


def _prompt(message: str, default: Optional[str] = None) -> str:
    """Read a line from stdin; return default if default is set and user hits Enter."""
    if default is not None:
        prompt = "{} [{}]: ".format(message, default)
    else:
        prompt = "{}: ".format(message)
    try:
        line = input(prompt).strip()
    except EOFError:
        line = ""
    if line:
        return line
    return default if default is not None else ""


def _confirm(message: str, default: bool = True) -> bool:
    """Ask yes/no; return True for yes, False for no."""
    suffix = " (Y/n)" if default else " (y/N)"
    try:
        line = input("{}{}: ".format(message, suffix)).strip().lower()
    except EOFError:
        return default
    if not line:
        return default
    return line in ("y", "yes")


