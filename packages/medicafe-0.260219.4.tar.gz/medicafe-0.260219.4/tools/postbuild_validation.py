#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Strict post-build artifact validation for MediCafe wheels.

Workflow:
1) Build isolated venv in a temporary directory.
2) Install built wheel from dist/ (no source-tree imports).
3) Run console script smoke test: medicafe version.
4) Validate critical import contract inside isolated environment.

This script does not write to the repository and exits non-zero on failure.
"""

from __future__ import print_function

import argparse
import glob
import os
import shutil
import subprocess
import sys
import tempfile
import zipfile

# Ensure project root is in path for tools.build_colors
_script_dir = os.path.dirname(os.path.abspath(__file__))
_project_root = os.path.dirname(_script_dir)
if _project_root not in sys.path:
    sys.path.insert(0, _project_root)
from tools.build_colors import bold, dim, fail, green_bold, pass_, step


REQUIRED_DATAMGMT_ATTRS = [
    'read_general_fixed_width_data',
    'read_fixed_width_data',
    'parse_fixed_width_data',
]


def run_cmd(cmd, cwd=None, env=None, timeout=300, label=None):
    if label:
        print(label)
    proc = subprocess.Popen(
        cmd,
        cwd=cwd,
        env=env,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        universal_newlines=True,
    )
    try:
        stdout, stderr = proc.communicate(timeout=timeout)
    except Exception:
        proc.kill()
        raise

    if proc.returncode != 0:
        print("  STDOUT:\n{}".format(stdout.strip()))
        print("  STDERR:\n{}".format(stderr.strip()))
        raise RuntimeError("Command failed with code {}: {}".format(proc.returncode, " ".join(cmd)))

    return stdout, stderr


def resolve_default_project_root(script_file):
    tools_dir = os.path.dirname(os.path.abspath(script_file))
    return os.path.dirname(tools_dir)


def find_wheel(dist_dir, explicit_wheel=None):
    if explicit_wheel:
        wheel_path = os.path.abspath(explicit_wheel)
        if not os.path.isfile(wheel_path):
            raise RuntimeError("Specified wheel not found: {}".format(wheel_path))
        return wheel_path

    wheels = sorted(glob.glob(os.path.join(dist_dir, '*.whl')))
    if not wheels:
        raise RuntimeError("No wheel files found in {}".format(dist_dir))
    wheels = sorted(wheels, key=lambda p: os.path.getmtime(p), reverse=True)
    return os.path.abspath(wheels[0])


def extract_requires_python(wheel_path):
    try:
        with zipfile.ZipFile(wheel_path, 'r') as zf:
            metadata_names = [n for n in zf.namelist() if n.endswith('.dist-info/METADATA')]
            if not metadata_names:
                return ''
            metadata = zf.read(metadata_names[0]).decode('utf-8', 'replace')
    except Exception:
        return ''

    for line in metadata.splitlines():
        if line.startswith('Requires-Python:'):
            return line.split(':', 1)[1].strip()
    return ''


def venv_python_path(venv_dir):
    if os.name == 'nt':
        return os.path.join(venv_dir, 'Scripts', 'python.exe')
    return os.path.join(venv_dir, 'bin', 'python')


def venv_console_script_path(venv_dir, script_name):
    if os.name == 'nt':
        return os.path.join(venv_dir, 'Scripts', script_name + '.exe')
    return os.path.join(venv_dir, 'bin', script_name)


def sanitized_env():
    env = os.environ.copy()
    if 'PYTHONPATH' in env:
        del env['PYTHONPATH']
    env['PIP_DISABLE_PIP_VERSION_CHECK'] = '1'
    return env


def critical_import_check_snippet(project_root):
    project_root_escaped = project_root.replace('\\', '\\\\')
    attrs_repr = repr(REQUIRED_DATAMGMT_ATTRS)
    return (
        "import os\n"
        "import MediLink.MediLink_DataMgmt as m\n"
        "project_root = os.path.normcase(os.path.abspath(r'{project_root}'))\n"
        "module_file = os.path.normcase(os.path.abspath(getattr(m, '__file__', '')))\n"
        "if module_file.startswith(project_root):\n"
        "    raise SystemExit('Imported from source tree instead of wheel: ' + module_file)\n"
        "required = {attrs}\n"
        "missing = [n for n in required if not hasattr(m, n)]\n"
        "if missing:\n"
        "    raise SystemExit('Missing required attributes: ' + ', '.join(missing))\n"
        "print('OK critical import contract')\n"
    ).format(project_root=project_root_escaped, attrs=attrs_repr)


def main():
    parser = argparse.ArgumentParser(description="MediCafe strict post-build artifact validation")
    parser.add_argument('--project-root', default=None, help='Project root path (defaults to parent of tools/)')
    parser.add_argument('--wheel', default=None, help='Explicit wheel path; defaults to newest dist/*.whl')
    args = parser.parse_args()

    project_root = args.project_root or resolve_default_project_root(__file__)
    project_root = os.path.abspath(project_root)
    dist_dir = os.path.join(project_root, 'dist')

    if not os.path.isdir(dist_dir):
        print(fail("FAIL") + " dist directory not found: {}".format(dist_dir))
        return 1

    try:
        wheel_path = find_wheel(dist_dir, args.wheel)
    except RuntimeError as exc:
        print(fail("FAIL") + " {}".format(exc))
        return 1
    requires_python = extract_requires_python(wheel_path)

    print(bold("MediCafe Post-Build Validation"))
    print(dim("Project root: {}".format(project_root)))
    print(dim("Wheel: {}".format(wheel_path)))
    if requires_python:
        print(dim("Wheel Requires-Python: {}".format(requires_python)))
    print(dim("Validation interpreter: {}".format(sys.executable)))
    print(dim("NOTE: Installing wheel with --ignore-requires-python for dev-machine artifact smoke testing."))

    tmp_root = tempfile.mkdtemp(prefix='medicafe_postbuild_')
    venv_dir = os.path.join(tmp_root, 'venv')
    run_dir = os.path.join(tmp_root, 'run')
    os.makedirs(run_dir)

    env = sanitized_env()

    try:
        run_cmd([sys.executable, '-m', 'venv', venv_dir], cwd=run_dir, env=env, timeout=300, label=step('[1/4]') + ' Creating isolated virtual environment...')
        py = venv_python_path(venv_dir)
        if not os.path.isfile(py):
            raise RuntimeError("Venv python not found: {}".format(py))

        run_cmd([py, '-m', 'pip', 'install', '--no-deps', '--ignore-requires-python', wheel_path], cwd=run_dir, env=env, timeout=300, label=step('[2/4]') + ' Installing built wheel...')

        console_script = venv_console_script_path(venv_dir, 'medicafe')
        if not os.path.isfile(console_script):
            raise RuntimeError("Console script not found after install: {}".format(console_script))
        run_cmd([console_script, 'version'], cwd=run_dir, env=env, timeout=120, label=step('[3/4]') + ' Running console script smoke test...')

        snippet = critical_import_check_snippet(project_root)
        run_cmd([py, '-c', snippet], cwd=run_dir, env=env, timeout=120, label=step('[4/4]') + ' Running critical import contract check...')

    except RuntimeError as exc:
        print(fail("FAIL") + " {}".format(exc))
        return 1
    except Exception as exc:
        print(fail("FAIL") + " Unexpected error: {}".format(exc))
        return 1
    finally:
        shutil.rmtree(tmp_root, ignore_errors=True)

    print(green_bold("PASS Post-build artifact validation passed."))
    return 0


if __name__ == '__main__':
    sys.exit(main())
