# MediCafe

MediCafe is a healthcare workflow automation suite for claims, eligibility, remittance, and operations support.

## What It Covers

- `MediBot`: local preprocessing and Medisoft-oriented workflow automation
- `MediLink`: claims flow, payer API integration, eligibility/status, remittance handling
- `cloud/orchestrator`: Cloud Run/PubSub/Firestore pipeline for Gmail ingestion and queueing
- `xp_client`: XP-compatible daemon for cloud queue consumption

## Choose Your Runtime Track

MediCafe intentionally supports two runtime tracks.

| Track | Scope | Python | Primary Use |
|---|---|---|---|
| XP / Local | `MediBot` + `MediLink` legacy-compatible clinic workflows | 3.4.4 | Production-style local runtime |
| Cloud / Orchestrator | `cloud/orchestrator` setup, deployment, runtime operations | 3.11+ | Cloud ingestion and ops tooling |

This split is expected and by design.

## Quick Start

Run the interactive launcher:

```bash
medicafe launcher
```

Or use module form:

```bash
python -m MediCafe launcher
```

Common task commands:

- `medicafe medilink`
- `medicafe claims_status`
- `medicafe deductible`
- `medicafe preflight`
- `medicafe send_error_report`

## CLI Reference

Available commands:

- `medicafe launcher`
- `medicafe medibot [config_file]`
- `medicafe medilink`
- `medicafe claims_status`
- `medicafe deductible`
- `medicafe download_emails`
- `medicafe cloud_daemon [config_file]`
- `medicafe send_error_report`
- `medicafe send_queued_error_reports`
- `medicafe docx_index_rebuild`
- `medicafe preflight`
- `medicafe reconcile`
- `medicafe version`

## Preflight Check

Run before workflows to catch environment issues:

```bash
medicafe preflight
```

Also available from the launcher: preflight runs automatically before local workflows (MediLink, MediBot, download_emails, etc.) when risk signals change (first run of session, config/crosswalk file change, or prior preflight failure). Output: PASS/WARN/FAIL lines with remediation hints. Exit code 0 if no failures, non-zero if any FAIL. In scripted mode (`--auto-choice`, `--direct-action`), preflight failures abort without prompting.

## Install and Dev Notes

### Legacy package path (XP runtime compatibility)

Package metadata targets Python 3.4.x runtime compatibility.

```bash
pip install medicafe
```

### Active repo workflow (recommended for maintainers)

```bash
git clone https://github.com/katanada2/MediCafe.git
cd MediCafe
```

For cloud tooling, run with Python 3.11+ directly from repo scripts (for example `cloud/orchestrator/validate_and_complete_setup.py`).

## Configuration

Primary local config files:

- `json/config.json`
- `json/crosswalk.json`
- `json/medisoftconfig.json`

## Documentation Map

Start here:

- `docs/README.md`
- `docs/MEDICAFE_MASTER_GUIDE.md`
- `docs/MEDICAFE_API_ARCHITECTURE.md`
- `docs/MEDILINK_CLOUD_MIGRATION.md`

Cloud-specific docs:

- `docs/architecture/MediLink_Gmail_GCP_Implementation.md`
- `docs/runbooks/MediLink_Gmail_Orchestrator_Operations.md`

## Security and Compliance

- Avoid PHI in logs
- Use endpoint-specific OAuth/token flows as documented
- Use `send_error_report` for diagnostics instead of ad hoc data exports

## License

MIT License. See `LICENSE`.

## Author

Daniel Vidaud  
daniel@personalizedtransformation.com
