#!/usr/bin/env python
"""
Phase D QA and canonicalization orchestrator.
Deterministic QA on ingest_artifact, replay routing for rejects, canonical extraction for passes.
XP-compatible: Python 3.4.4, stdlib only.
"""
from __future__ import print_function

import argparse
import json
import os
import sqlite3
import sys

_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
_WORKSPACE_ROOT = os.path.abspath(os.path.join(_SCRIPT_DIR, "..", ".."))
if _WORKSPACE_ROOT not in sys.path:
    sys.path.insert(0, _WORKSPACE_ROOT)
if _SCRIPT_DIR not in sys.path:
    sys.path.insert(0, _SCRIPT_DIR)

from phase_d_common import (
    CANONICALIZATION_VERSION,
    QA_STAGE_PHASE_D,
    QA_POLICY_VERSION,
    PHASE_D_DB_WRITE_ERROR,
    PHASE_D_LOCK_FAIL,
    PHASE_D_REPLAY_QUEUE_ERROR,
    PHASE_D_STATE_WRITE_ERROR,
    QA_ARTIFACT_CLASS_REQUIRED_FIELDS,
    QA_PARSE_ERROR,
    compute_qa_deterministic_key,
    iso_utc_now,
    run_id,
)
from lab_lock import acquire_lock, release_lock, replace_safe_write
from lab_path_utils import resolve_lab_root
from parse_providers import parse_artifact
from parse_providers import get_last_parse_diag
from qa_evaluator import evaluate_qa
from canonical_extractor import extract_canonical_records, build_domain_upserts
from failure_contract import build_failure_context


def _workspace_root():
    return os.path.abspath(os.path.join(_SCRIPT_DIR, "..", ".."))


def _resolve_lab_root(args):
    return resolve_lab_root(args.lab_dir, _workspace_root())


def _execute_domain_upserts(conn, domain_upsert_rows):
    """
    Write domain entity upserts to DB. Phase D v1: patient only.
    Returns dict of actual inserted row counts per entity type.
    patient: INSERT OR IGNORE (CHECK constraint may skip invalid external_patient_id).
    Exceptions propagate; no silent ignore of DB errors.
    """
    counts = {"patient": 0, "payer": 0, "insurance_plan": 0, "coverage": 0, "encounter": 0, "claim": 0, "claim_line": 0}
    for row in domain_upsert_rows.get("patient") or []:
        cur = conn.execute(
            "INSERT OR IGNORE INTO patient (patient_key, external_patient_id, full_name, birth_date, source_system) "
            "VALUES (?, ?, ?, ?, ?)",
            (
                row.get("patient_key"),
                row.get("external_patient_id"),
                row.get("full_name"),
                row.get("birth_date"),
                row.get("source_system") or "xp_local",
            ),
        )
        if cur.rowcount > 0:
            counts["patient"] += cur.rowcount
    return counts


def select_eligible_artifacts(conn, qa_version):
    """Select ingest_artifact rows not yet evaluated for (phase_d, qa_version)."""
    cur = conn.execute(
        "SELECT artifact_id, ingest_key, source_system, source_type, source_ref, payload_json "
        "FROM ingest_artifact WHERE artifact_id NOT IN "
        "(SELECT artifact_id FROM qa_result WHERE qa_stage=? AND qa_version=?)",
        (QA_STAGE_PHASE_D, qa_version),
    )
    return cur.fetchall()


def run_qa_canonical(lab_root):
    """Main flow. Returns (ok, run_id, summary, error_code)."""
    rid = run_id()
    reports_dir = os.path.join(lab_root, "reports")
    summary_json_path = os.path.join(reports_dir, "qa_canonical_summary_{0}.json".format(rid))
    summary_txt_path = os.path.join(reports_dir, "qa_canonical_summary_{0}.txt".format(rid))
    reject_samples_path = os.path.join(reports_dir, "qa_reject_samples_{0}.jsonl".format(rid))
    db_path = os.path.join(lab_root, "unified_model_xp.db")

    if not os.path.exists(db_path):
        summary_fail = _build_summary(rid, ok=False, rows_selected=0, error_code=PHASE_D_DB_WRITE_ERROR)
        _handle_prelock_failure(lab_root, rid, summary_fail, summary_json_path, summary_txt_path, reports_dir)
        return False, rid, summary_fail, summary_fail.get("error_code")

    qa_results = []
    replay_entries = []
    canonical_records = []
    domain_upsert_rows = {"patient": [], "payer": [], "insurance_plan": [], "coverage": [], "encounter": [], "claim": [], "claim_line": []}
    entity_upserts = {"patient": 0, "payer": 0, "insurance_plan": 0, "coverage": 0, "encounter": 0, "claim": 0, "claim_line": 0}
    reject_samples = []
    reject_counts_by_code = {}

    try:
        conn = sqlite3.connect(db_path)
        rows = select_eligible_artifacts(conn, QA_POLICY_VERSION)
        conn.close()
    except Exception as e:
        summary_fail = _build_summary(
            rid, ok=False, rows_selected=0, error_code=PHASE_D_DB_WRITE_ERROR,
            error_detail=str(e)[:200], source_exception_class=e.__class__.__name__
        )
        _handle_prelock_failure(lab_root, rid, summary_fail, summary_json_path, summary_txt_path, reports_dir)
        return False, rid, summary_fail, PHASE_D_DB_WRITE_ERROR

    if not rows:
        summary_ok = _build_summary(rid, ok=True, rows_selected=0, qa_pass_count=0, qa_reject_count=0,
                                   replay_enqueued_count=0, canonical_record_count=0,
                                   reject_counts_by_code={}, entity_upsert_counts=entity_upserts)
        try:
            acquire_lock(lab_root)
            try:
                if reports_dir and not os.path.exists(reports_dir):
                    os.makedirs(reports_dir, exist_ok=True)
                _write_summary_json(summary_ok, summary_json_path)
                _write_summary_txt(summary_ok, summary_txt_path)
                persist_phase_d_state(lab_root, rid, True, None, 0, 0, 0, 0, entity_upserts)
            finally:
                release_lock(lab_root, owner_pid=os.getpid())
        except SystemExit:
            return False, rid, None, PHASE_D_LOCK_FAIL
        return True, rid, summary_ok, None

    for row in rows:
        artifact_id, ingest_key, source_system, source_type, source_ref, payload_json = row
        payload = {}
        try:
            payload = json.loads(payload_json) if payload_json else {}
        except (ValueError, TypeError):
            pass
        locator = payload.get("locator") or ""
        artifact_class = payload.get("artifact_class") or ""

        ok, envelope, parse_code = parse_artifact(locator, artifact_class, payload)
        if not ok:
            reject_code = parse_code or QA_PARSE_ERROR
            parse_diag = get_last_parse_diag()
            reject_counts_by_code[reject_code] = reject_counts_by_code.get(reject_code, 0) + 1
            reject_reason = "Parse failed [{0}]".format(
                parse_diag.get("source_exception_class") or "unknown"
            ) if isinstance(parse_diag, dict) else "Parse failed"
            qa_results.append((artifact_id, "reject", reject_code, reject_reason))
            replay_entries.append((artifact_id, reject_code))
            reject_samples.append({
                "artifact_id": artifact_id,
                "reject_code": reject_code,
                "locator": locator[:80],
                "locator_full": locator,
                "parse_diag": parse_diag if isinstance(parse_diag, dict) else {},
            })
            continue

        pass_qa, reject_code, reject_reason = evaluate_qa(artifact_class, envelope)
        if not pass_qa:
            reject_code = reject_code or QA_ARTIFACT_CLASS_REQUIRED_FIELDS
            reject_counts_by_code[reject_code] = reject_counts_by_code.get(reject_code, 0) + 1
            qa_results.append((artifact_id, "reject", reject_code, reject_reason or ""))
            replay_entries.append((artifact_id, reject_code))
            reject_samples.append({"artifact_id": artifact_id, "reject_code": reject_code, "reason": reject_reason})
            continue

        qa_results.append((artifact_id, "pass", None, None))
        recs = extract_canonical_records(artifact_id, artifact_class, envelope, source_system, source_ref)
        for rec in recs:
            rec["artifact_id"] = artifact_id
            canonical_records.append(rec)
        upserts = build_domain_upserts(recs, artifact_id, source_system)
        for k, v in upserts.items():
            if isinstance(v, list):
                domain_upsert_rows[k].extend(v)
                entity_upserts[k] += len(v)

    qa_pass_count = sum(1 for r in qa_results if r[1] == "pass")
    qa_reject_count = len(qa_results) - qa_pass_count
    replay_enqueued_count = len(replay_entries)

    try:
        acquire_lock(lab_root)
    except SystemExit:
        return False, rid, None, PHASE_D_LOCK_FAIL

    actual_entity_counts = dict(entity_upserts)
    try:
        conn = sqlite3.connect(db_path)
        conn.execute("BEGIN")
        try:
            for artifact_id, status, reject_code, reject_reason in qa_results:
                det_key = compute_qa_deterministic_key(artifact_id, QA_STAGE_PHASE_D, QA_POLICY_VERSION, status, reject_code)
                conn.execute(
                    "INSERT OR REPLACE INTO qa_result (artifact_id, qa_stage, qa_version, status, reject_code, reject_reason, deterministic_key) "
                    "VALUES (?, ?, ?, ?, ?, ?, ?)",
                    (artifact_id, QA_STAGE_PHASE_D, QA_POLICY_VERSION, status, reject_code, reject_reason, det_key),
                )
            try:
                for artifact_id, reason_code in replay_entries:
                    conn.execute(
                        "INSERT OR REPLACE INTO replay_queue (artifact_id, reason_code, status, attempt_count) "
                        "VALUES (?, ?, 'pending', 0)",
                        (artifact_id, reason_code),
                    )
            except Exception as replay_err:
                raise RuntimeError((PHASE_D_REPLAY_QUEUE_ERROR, str(replay_err)))
            for rec in canonical_records:
                conn.execute(
                    "INSERT OR IGNORE INTO extracted_canonical_record "
                    "(artifact_id, canonical_type, canonical_key, extractor_version, canonical_json, provenance_json) "
                    "VALUES (?, ?, ?, ?, ?, ?)",
                    (rec["artifact_id"], rec["canonical_type"], rec["canonical_key"], CANONICALIZATION_VERSION,
                     rec["canonical_json"], rec["provenance_json"]),
                )
            actual_entity_counts = _execute_domain_upserts(conn, domain_upsert_rows)
            conn.commit()
        except Exception as e:
            conn.rollback()
            actual_entity_counts = {k: 0 for k in actual_entity_counts}
            error_code = PHASE_D_DB_WRITE_ERROR
            error_detail = str(e)[:200]
            if isinstance(e, RuntimeError) and e.args and e.args[0][0] == PHASE_D_REPLAY_QUEUE_ERROR:
                error_code = PHASE_D_REPLAY_QUEUE_ERROR
                error_detail = str(e.args[0][1])[:200] if len(e.args[0]) > 1 else str(e)[:200]
            summary_fail = _build_summary(rid, ok=False, rows_selected=len(rows), qa_pass_count=qa_pass_count,
                                         qa_reject_count=qa_reject_count, reject_counts_by_code=reject_counts_by_code,
                                         replay_enqueued_count=replay_enqueued_count,
                                         canonical_record_count=len(canonical_records),
                                         entity_upsert_counts=actual_entity_counts, error_code=error_code,
                                         error_detail=error_detail, source_exception_class=e.__class__.__name__)
            if reports_dir and not os.path.exists(reports_dir):
                os.makedirs(reports_dir, exist_ok=True)
            _write_summary_json(summary_fail, summary_json_path)
            _write_summary_txt(summary_fail, summary_txt_path)
            try:
                persist_phase_d_state(lab_root, rid, False, error_code, qa_pass_count, qa_reject_count,
                                      replay_enqueued_count, len(canonical_records), actual_entity_counts)
            except Exception:
                pass
            release_lock(lab_root, owner_pid=os.getpid())
            try:
                from phase_d_auto_report import submit_phase_d_failure_report
                submit_phase_d_failure_report(lab_root, {"error_code": error_code, "run_id": rid,
                                                         "first_failed": error_detail[:100], "lab_root": lab_root,
                                                         "report_json_path": summary_json_path,
                                                         "report_txt_path": summary_txt_path, "summary": summary_fail})
            except Exception:
                pass
            return False, rid, summary_fail, error_code
        finally:
            conn.close()

        summary = _build_summary(rid, ok=True, rows_selected=len(rows), qa_pass_count=qa_pass_count,
                                qa_reject_count=qa_reject_count, reject_counts_by_code=reject_counts_by_code,
                                replay_enqueued_count=replay_enqueued_count,
                                canonical_record_count=len(canonical_records),
                                entity_upsert_counts=actual_entity_counts)
        if reports_dir and not os.path.exists(reports_dir):
            os.makedirs(reports_dir, exist_ok=True)
        _write_summary_json(summary, summary_json_path)
        _write_summary_txt(summary, summary_txt_path)
        with open(reject_samples_path, "w", encoding="utf-8") as f:
            for s in reject_samples[:50]:
                f.write(json.dumps(s, ensure_ascii=False) + "\n")
        try:
            persist_phase_d_state(lab_root, rid, True, None, qa_pass_count, qa_reject_count,
                                  replay_enqueued_count, len(canonical_records), actual_entity_counts)
        except Exception as persist_err:
            summary["ok"] = False
            summary["error_code"] = PHASE_D_STATE_WRITE_ERROR
            summary["error_detail"] = str(persist_err)[:200]
            summary["source_exception_class"] = persist_err.__class__.__name__
            summary["recoverability"] = build_failure_context(
                "D", PHASE_D_STATE_WRITE_ERROR, str(persist_err)[:200], persist_err.__class__.__name__
            ).get("recoverability", "")
            summary["failure_contract"] = build_failure_context(
                "D", PHASE_D_STATE_WRITE_ERROR, str(persist_err)[:200], persist_err.__class__.__name__
            )
            _write_summary_json(summary, summary_json_path)
            _write_summary_txt(summary, summary_txt_path)
            release_lock(lab_root, owner_pid=os.getpid())
            try:
                from phase_d_auto_report import submit_phase_d_failure_report
                submit_phase_d_failure_report(lab_root, {"error_code": PHASE_D_STATE_WRITE_ERROR, "run_id": rid,
                                                         "first_failed": str(persist_err)[:100], "lab_root": lab_root,
                                                         "report_json_path": summary_json_path,
                                                         "report_txt_path": summary_txt_path, "summary": summary})
            except Exception:
                pass
            return False, rid, summary, PHASE_D_STATE_WRITE_ERROR
    finally:
        release_lock(lab_root, owner_pid=os.getpid())

    return True, rid, summary, None


def _build_summary(rid, ok, rows_selected, qa_pass_count=0, qa_reject_count=0, reject_counts_by_code=None,
                   replay_enqueued_count=0, canonical_record_count=0, entity_upsert_counts=None,
                   error_code=None, error_detail="", source_exception_class="", recoverability=""):
    failure = build_failure_context("D", error_code, error_detail, source_exception_class) if error_code else {}
    recoverability_value = recoverability or (failure.get("recoverability", "") if failure else "")
    return {
        "phase": "D",
        "ok": ok,
        "run_id": rid,
        "generated_at_utc": iso_utc_now(),
        "qa_policy_version": QA_POLICY_VERSION,
        "canonicalization_version": CANONICALIZATION_VERSION,
        "rows_selected": rows_selected,
        "qa_pass_count": qa_pass_count,
        "qa_reject_count": qa_reject_count,
        "reject_counts_by_code": reject_counts_by_code or {},
        "replay_enqueued_count": replay_enqueued_count,
        "canonical_record_count": canonical_record_count,
        "entity_upsert_counts": entity_upsert_counts or {},
        "error_code": error_code,
        "error_detail": error_detail or "",
        "recoverability": recoverability_value,
        "source_exception_class": source_exception_class or "",
        "failure_contract": failure,
    }


def _handle_prelock_failure(lab_root, rid, summary_fail, summary_json_path, summary_txt_path, reports_dir):
    try:
        acquire_lock(lab_root)
        try:
            if reports_dir and not os.path.exists(reports_dir):
                os.makedirs(reports_dir, exist_ok=True)
            _write_summary_json(summary_fail, summary_json_path)
            _write_summary_txt(summary_fail, summary_txt_path)
            persist_phase_d_state(lab_root, rid, False, summary_fail.get("error_code"), 0, 0, 0, 0, {})
        finally:
            release_lock(lab_root, owner_pid=os.getpid())
        try:
            from phase_d_auto_report import submit_phase_d_failure_report
            submit_phase_d_failure_report(lab_root, {"error_code": summary_fail.get("error_code"),
                                                     "run_id": rid, "first_failed": "prelock",
                                                     "lab_root": lab_root, "report_json_path": summary_json_path,
                                                     "report_txt_path": summary_txt_path, "summary": summary_fail})
        except Exception:
            pass
    except SystemExit:
        pass


def _write_summary_json(summary, path):
    dir_path = os.path.dirname(path)
    if dir_path and not os.path.exists(dir_path):
        os.makedirs(dir_path, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(summary, f, indent=2)


def _write_summary_txt(summary, path):
    lines = [
        "Phase D QA and Canonicalization Summary",
        "run_id: {0}".format(summary.get("run_id", "")),
        "generated_at_utc: {0}".format(summary.get("generated_at_utc", "")),
        "ok: {0}".format(summary.get("ok", False)),
        "rows_selected: {0}".format(summary.get("rows_selected", 0)),
        "qa_pass_count: {0}".format(summary.get("qa_pass_count", 0)),
        "qa_reject_count: {0}".format(summary.get("qa_reject_count", 0)),
        "replay_enqueued_count: {0}".format(summary.get("replay_enqueued_count", 0)),
        "canonical_record_count: {0}".format(summary.get("canonical_record_count", 0)),
        "error_code: {0}".format(summary.get("error_code", "")),
        "recoverability: {0}".format(summary.get("recoverability", "")),
        "source_exception_class: {0}".format(summary.get("source_exception_class", "")),
    ]
    dir_path = os.path.dirname(path)
    if dir_path and not os.path.exists(dir_path):
        os.makedirs(dir_path, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")


def persist_phase_d_state(lab_root, rid, ok, error_code, pass_count, reject_count, replay_pending, canonical_count, entity_upserts):
    """Update run_cursor.json and diagnostics_state.json with Phase D outcome."""
    cursor_path = os.path.join(lab_root, "run_cursor.json")
    state_path = os.path.join(lab_root, "diagnostics_state.json")
    now = iso_utc_now()
    cursor = {}
    if os.path.exists(cursor_path):
        try:
            with open(cursor_path, "r", encoding="utf-8") as f:
                cursor = json.load(f)
        except Exception:
            pass
    cursor["last_phase_d_run_id"] = rid
    cursor["last_phase_d_ok"] = ok
    cursor["last_qa_policy_version"] = QA_POLICY_VERSION
    cursor["last_canonicalization_version"] = CANONICALIZATION_VERSION
    cursor["last_phase_d_pass_count"] = pass_count
    cursor["last_phase_d_reject_count"] = reject_count
    cursor["last_phase_d_replay_pending"] = replay_pending
    cursor["last_phase_d_error_code"] = error_code
    cursor["last_phase_d_at_utc"] = now
    replace_safe_write(cursor_path, cursor)
    state = {}
    if os.path.exists(state_path):
        try:
            with open(state_path, "r", encoding="utf-8") as f:
                state = json.load(f)
        except Exception:
            pass
    state["last_phase_d_run_id"] = rid
    state["last_phase_d_ok"] = ok
    state["last_qa_policy_version"] = QA_POLICY_VERSION
    state["last_canonicalization_version"] = CANONICALIZATION_VERSION
    state["last_phase_d_pass_count"] = pass_count
    state["last_phase_d_reject_count"] = reject_count
    state["last_phase_d_replay_pending"] = replay_pending
    state["last_phase_d_error_code"] = error_code
    state["last_phase_d_at_utc"] = now
    replace_safe_write(state_path, state)


def main():
    parser = argparse.ArgumentParser(description="Phase D QA and canonicalization")
    parser.add_argument("--lab-dir", help="Override lab root")
    args = parser.parse_args()
    lab_root = _resolve_lab_root(args)
    if not os.path.exists(lab_root):
        os.makedirs(lab_root, exist_ok=True)
    ok, rid, summary, error_code = run_qa_canonical(lab_root)
    if not ok:
        print("Phase D failed: {0}".format(error_code), file=sys.stderr)
        sys.exit(1)
    print("Phase D ok: {0} pass, {1} reject, {2} canonical".format(
        summary.get("qa_pass_count", 0), summary.get("qa_reject_count", 0),
        summary.get("canonical_record_count", 0)))


if __name__ == "__main__":
    main()
