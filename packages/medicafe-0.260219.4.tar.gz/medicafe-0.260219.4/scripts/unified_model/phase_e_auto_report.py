#!/usr/bin/env python
"""
Phase E autonomous failure report: builds bundle and submits via MediCafe error reporter.
Uses skip_interactive_reauth=True for unattended operation.
XP-compatible: Python 3.4.4, stdlib only.
"""
from __future__ import print_function

import hashlib
import os
import sys

_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
_WORKSPACE_ROOT = os.path.abspath(os.path.join(_SCRIPT_DIR, "..", ".."))
if _WORKSPACE_ROOT not in sys.path:
    sys.path.insert(0, _WORKSPACE_ROOT)
if _SCRIPT_DIR not in sys.path:
    sys.path.insert(0, _SCRIPT_DIR)

from phase_a_common import iso_utc_now

DEDUP_WINDOW_SEC = 4 * 3600  # 4 hours


def submit_phase_e_failure_report(lab_root, failure_context):
    """
    Build Phase E failure bundle and submit via error reporter.
    Uses skip_interactive_reauth=True; no token => leave in queue.

    failure_context: dict with error_code, run_id, first_failed, lab_root,
                     report_json_path, report_txt_path (optional),
                     summary (optional dict for extra_files).

    Returns True if report sent, False if queued or failed.
    """
    try:
        from MediCafe.error_reporter import (
            check_report_dedup,
            collect_support_bundle,
            submit_support_bundle_email,
        )
    except ImportError as e:
        try:
            import logging
            logging.getLogger(__name__).warning(
                "Phase E report: error_reporter unavailable: {0}".format(e)
            )
        except Exception:
            pass
        return False

    _lab_lock_module = None
    try:
        import lab_lock as _lab_lock_module
    except ImportError:
        pass

    error_code = failure_context.get("error_code", "PHASE_E_DB_WRITE_ERROR")
    first_failed = failure_context.get("first_failed", "unknown")
    run_id_val = failure_context.get("run_id", "")
    lab_root_val = failure_context.get("lab_root", lab_root)

    dedup_key = hashlib.sha256(
        ("phase_e" + error_code + first_failed + lab_root_val).encode("utf-8")
    ).hexdigest()

    state_path = os.path.join(lab_root, "diagnostics_state.json")
    state_dir = os.path.dirname(state_path)
    if state_dir and not os.path.exists(state_dir):
        try:
            os.makedirs(state_dir, exist_ok=True)
        except (IOError, OSError):
            pass

    should_send, state = check_report_dedup(state_path, dedup_key, DEDUP_WINDOW_SEC)
    if not should_send:
        return False

    extra_meta = {
        "phase_e_failure": True,
        "error_code": error_code,
        "run_id": run_id_val,
        "first_failed": first_failed,
        "lab_root": lab_root_val,
        "error_summary": "Phase E projection/parity failed: {0} ({1})".format(
            error_code, first_failed
        ),
    }

    extra_files = []
    report_json = failure_context.get("report_json_path")
    report_txt = failure_context.get("report_txt_path")
    if report_json and os.path.exists(report_json):
        extra_files.append(("projection_parity_summary.json", report_json))
    if report_txt and os.path.exists(report_txt):
        extra_files.append(("projection_parity_summary.txt", report_txt))
    summary = failure_context.get("summary")
    if isinstance(summary, dict):
        extra_files.append(("projection_parity_summary.json", summary))

    zip_path = collect_support_bundle(
        include_traceback=False,
        extra_meta=extra_meta,
        extra_files=extra_files if extra_files else None,
    )
    if not zip_path:
        return False

    success = submit_support_bundle_email(
        zip_path,
        skip_interactive_reauth=True,
        extra_meta=extra_meta,
        extra_files=extra_files if extra_files else None,
    )

    if success and state_path:
        state["last_report_sent_at_utc"] = iso_utc_now()
        state["last_report_dedup_key"] = dedup_key
        state["version"] = state.get("version", 1)
        if _lab_lock_module and hasattr(_lab_lock_module, "replace_safe_write"):
            try:
                _lab_lock_module.replace_safe_write(state_path, state)
            except (IOError, OSError):
                pass

    return success


def submit_phase_f_report(lab_root, report_json_path, report_txt_path, index_path, failure_context):
    """
    Build Phase F shadow evidence bundle and submit via error reporter.
    failure_context: run_id, pipeline_ok, failed_phase, error_code, contract_parity_status
    Returns True if report sent, False if queued or deduped.
    """
    try:
        from MediCafe.error_reporter import (
            check_report_dedup,
            collect_support_bundle,
            submit_support_bundle_email,
        )
    except ImportError as e:
        try:
            import logging
            logging.getLogger(__name__).warning(
                "Phase F report: error_reporter unavailable: {0}".format(e)
            )
        except Exception:
            pass
        return False

    failed_phase = failure_context.get("failed_phase", "") or ""
    error_code = failure_context.get("error_code", "") or ""
    contract_parity = failure_context.get("contract_parity_status", "") or ""
    lab_root_val = str(lab_root)

    pipeline_ok = bool(failure_context.get("pipeline_ok", False))
    # For healthy runs, include run_id so each run can emit health telemetry once.
    if pipeline_ok and not failed_phase and not error_code and contract_parity == "pass":
        dedup_material = "phase_f_health" + str(failure_context.get("run_id", "")) + lab_root_val
    else:
        dedup_material = "phase_f" + failed_phase + error_code + contract_parity + lab_root_val
    dedup_key = hashlib.sha256(dedup_material.encode("utf-8")).hexdigest()

    state_path = os.path.join(lab_root, "diagnostics_state.json")
    state_dir = os.path.dirname(state_path)
    if state_dir and not os.path.exists(state_dir):
        try:
            os.makedirs(state_dir, exist_ok=True)
        except (IOError, OSError):
            pass

    should_send, state = check_report_dedup(state_path, dedup_key, DEDUP_WINDOW_SEC)
    if not should_send:
        return False

    extra_meta = {
        "phase_f_report": True,
        "run_id": failure_context.get("run_id", ""),
        "pipeline_ok": failure_context.get("pipeline_ok", False),
        "failed_phase": failed_phase,
        "error_code": error_code,
        "lab_root": lab_root_val,
        "error_summary": "Shadow pipeline report: ok={0}, failed_phase={1}, parity={2}".format(
            failure_context.get("pipeline_ok", False), failed_phase, contract_parity
        ),
    }

    extra_files = []
    if report_json_path and os.path.exists(report_json_path):
        extra_files.append(("shadow_run_report.json", report_json_path))
    if report_txt_path and os.path.exists(report_txt_path):
        extra_files.append(("shadow_run_report.txt", report_txt_path))
    if index_path and os.path.exists(index_path):
        extra_files.append(("shadow_evidence_index.json", index_path))

    zip_path = collect_support_bundle(
        include_traceback=False,
        extra_meta=extra_meta,
        extra_files=extra_files if extra_files else None,
    )
    if not zip_path:
        return False

    success = submit_support_bundle_email(
        zip_path,
        skip_interactive_reauth=True,
        extra_meta=extra_meta,
        extra_files=extra_files if extra_files else None,
    )

    if success and state_path:
        state["last_report_sent_at_utc"] = iso_utc_now()
        state["last_report_dedup_key"] = dedup_key
        state["version"] = state.get("version", 1)
        try:
            import lab_lock as _lab_lock_module
            if hasattr(_lab_lock_module, "replace_safe_write"):
                _lab_lock_module.replace_safe_write(state_path, state)
        except (ImportError, IOError, OSError):
            pass

    return success
