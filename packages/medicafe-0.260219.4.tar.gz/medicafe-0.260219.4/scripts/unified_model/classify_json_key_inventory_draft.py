#!/usr/bin/env python
"""
Classify JSON key inventory rows into draft concern/priority/decision buckets.

Input: CSVs produced by extract_json_key_inventory.py
Output: *_classification_draft.csv files (no value content)

XP-compatible (Python 3.4.4, stdlib only).
"""
from __future__ import print_function

import argparse
import csv
import os
import sys


def _lower(s):
    try:
        return s.lower()
    except Exception:
        return ""


def _path_starts(path, prefix):
    return path == prefix or path.startswith(prefix + "/")


def _contains_any(text, tokens):
    for t in tokens:
        if t in text:
            return True
    return False


def classify_concern(source_stem, key_path):
    lower_path = _lower(key_path)

    if key_path == "$":
        return "meta_container"

    if "/api test case" in lower_path:
        return "test_fixture"

    if source_stem == "crosswalk":
        if (
            _path_starts(key_path, "$/payer_id")
            or _path_starts(key_path, "$/endpoint_payer_ids")
            or _path_starts(key_path, "$/diagnosis_to_medisoft")
            or _path_starts(key_path, "$/procedure_to_diagnosis")
            or _path_starts(key_path, "$/csv_replacements")
            or _path_starts(key_path, "$/mains_mapping")
            or _path_starts(key_path, "$/mapat_mapping")
        ):
            return "mapping_rule"
        if _path_starts(key_path, "$/optum_payer_list"):
            return "derived_cache"
        return "legacy_unknown"

    # config
    if (
        _path_starts(key_path, "$/field_mapping")
        or _path_starts(key_path, "$/fixed_values")
        or _path_starts(key_path, "$/medicare_added_fixed_values")
        or _path_starts(key_path, "$/required_fields")
        or _path_starts(key_path, "$/page_end_markers")
    ):
        return "mapping_rule"

    if _path_starts(key_path, "$/MediLink_Config"):
        if "/fixedwidthslices" in lower_path:
            return "mapping_rule"
        if (
            "/endpoints" in lower_path
            or "/api_endpoints" in lower_path
            or "/certificate_provider" in lower_path
            or "/error_reporting" in lower_path
            or "/validation" in lower_path
            or "/insurance_options" in lower_path
            or "/receiveredi" in lower_path
            or "/receiverid" in lower_path
            or "/submitteredi" in lower_path
            or "/submitterid" in lower_path
            or "/submitter_name" in lower_path
            or "/submitter_tel" in lower_path
            or "/script_id" in lower_path
            or "/webapp_deployment_id" in lower_path
            or "/winscp_path" in lower_path
            or "/use_http_mode" in lower_path
        ):
            return "integration_protocol"
        if (
            "/logging" in lower_path
            or "/logfilepath" in lower_path
        ):
            return "observability_reporting"
        return "runtime_config"

    top_runtime_like = [
        "$/AHK_EXECUTABLE",
        "$/CSV_FILE_PATH",
        "$/MAINS_MED_PATH",
        "$/MAPAT_MED_PATH",
        "$/MEDICARE_MAPAT_MED_PATH",
        "$/MEDICARE_SHORTCUT",
        "$/PRIVATE_SHORTCUT",
        "$/VK_END",
        "$/VK_PAUSE",
        "$/medisoft_claims_directory",
        "$/cities",
        "$/ENABLE_INTERACTIVE_CHARGES",
    ]
    for p in top_runtime_like:
        if _path_starts(key_path, p):
            return "runtime_config"

    protocol_like = [
        "$/script_id",
        "$/webapp_deployment_id",
        "$/receiverEdi",
        "$/receiverId",
        "$/submitterEdi",
        "$/submitterId",
        "$/winscp_path",
    ]
    for p in protocol_like:
        if _path_starts(key_path, p):
            return "integration_protocol"

    return "legacy_unknown"


def classify_determinism_impact(concern_type, key_path):
    lower_path = _lower(key_path)
    high_tokens = [
        "path",
        "directory",
        "file",
        "input",
        "output",
        "source",
        "target",
        "claims",
        "crosswalk",
        "z_dat",
        "medisoft",
        "payer",
        "mapping",
    ]

    if concern_type in ("meta_container", "test_fixture", "observability_reporting", "derived_cache"):
        return "low"
    if concern_type == "integration_protocol":
        return "medium"
    if _contains_any(lower_path, high_tokens):
        return "high"
    if concern_type == "mapping_rule":
        return "high"
    if concern_type == "runtime_config":
        return "medium"
    if concern_type in ("derived_cache", "state_or_telemetry"):
        return "low"
    return "low"


def classify_priority(concern_type, determinism_impact):
    if concern_type == "meta_container":
        return "P2"
    if concern_type == "test_fixture":
        return "P2"
    if concern_type == "integration_protocol":
        return "P1"
    if concern_type == "observability_reporting":
        return "P2"
    if concern_type == "legacy_unknown":
        return "P0"
    if determinism_impact == "high":
        return "P0"
    if determinism_impact == "medium":
        return "P1"
    return "P2"


def classify_decision(source_stem, concern_type):
    if concern_type == "meta_container":
        return "KEEP_AS_IS"
    if concern_type == "mapping_rule" and source_stem == "crosswalk":
        return "KEEP_RESHAPE"
    if concern_type == "mapping_rule" and source_stem == "config":
        return "MOVE_CONFIG_TO_CROSSWALK"
    if concern_type == "runtime_config" and source_stem == "config":
        return "KEEP_RESHAPE"
    if concern_type == "runtime_config" and source_stem == "crosswalk":
        return "MOVE_CROSSWALK_TO_CONFIG"
    if concern_type in ("integration_protocol", "observability_reporting"):
        return "KEEP_RESHAPE"
    if concern_type == "test_fixture":
        return "LEGACY_COMPAT_ONLY"
    if concern_type == "derived_cache":
        return "DERIVE_NOT_STORE"
    if concern_type == "state_or_telemetry":
        return "MOVE_TO_RELATIONAL_MODEL"
    return "LEGACY_COMPAT_ONLY"


def classify_operational_domain(concern_type):
    if concern_type == "mapping_rule":
        return "db_ingest_mapping"
    if concern_type == "runtime_config":
        return "io_runtime_paths"
    if concern_type == "integration_protocol":
        return "api_transport_protocol"
    if concern_type == "observability_reporting":
        return "ops_reporting"
    if concern_type == "derived_cache":
        return "cache_projection"
    if concern_type == "test_fixture":
        return "test_harness"
    if concern_type == "meta_container":
        return "schema_meta"
    return "unknown"


def classify_db_relevance(concern_type):
    if concern_type == "mapping_rule":
        return "high"
    if concern_type == "runtime_config":
        return "medium"
    if concern_type in ("integration_protocol", "derived_cache"):
        return "low"
    if concern_type in ("observability_reporting", "test_fixture", "meta_container"):
        return "none"
    return "unknown"


def rationale_for(concern_type, decision, key_path):
    if concern_type == "mapping_rule":
        return "Mapping semantics should be centrally owned and versioned."
    if concern_type == "runtime_config":
        return "Runtime behavior should be controlled by explicit config contract."
    if concern_type == "integration_protocol":
        return "API protocol/interfacing config is operationally critical but not a DB schema concern."
    if concern_type == "observability_reporting":
        return "Reporting/logging controls are operational support concerns."
    if concern_type == "derived_cache":
        return "Prefer regeneration over persistent control-plane storage."
    if concern_type == "test_fixture":
        return "Test fixture data should remain isolated from production-critical contract keys."
    if concern_type == "meta_container":
        return "Container/root row for inventory bookkeeping."
    if decision == "LEGACY_COMPAT_ONLY":
        return "Usage/ownership unclear; keep for compatibility until resolved."
    return "Draft heuristic classification."


def process_inventory(input_csv, out_csv):
    source_stem = os.path.basename(input_csv).replace("_key_inventory.csv", "")
    rows = []
    with open(input_csv, "r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            key_path = row.get("key_path", "")
            concern_type = classify_concern(source_stem, key_path)
            determinism_impact = classify_determinism_impact(concern_type, key_path)
            migration_priority = classify_priority(concern_type, determinism_impact)
            draft_decision = classify_decision(source_stem, concern_type)
            operational_domain = classify_operational_domain(concern_type)
            db_relevance = classify_db_relevance(concern_type)
            rationale = rationale_for(concern_type, draft_decision, key_path)

            out_row = {
                "source_file": source_stem + ".json",
                "key_path": key_path,
                "value_type": row.get("value_type", ""),
                "depth": row.get("depth", ""),
                "occurrences": row.get("occurrences", ""),
                "is_container": row.get("is_container", ""),
                "concern_type": concern_type,
                "operational_domain": operational_domain,
                "db_relevance": db_relevance,
                "determinism_impact": determinism_impact,
                "migration_priority": migration_priority,
                "draft_decision": draft_decision,
                "rationale": rationale,
            }
            rows.append(out_row)

    rows = sorted(rows, key=lambda r: (r["key_path"], r["value_type"]))
    with open(out_csv, "w", newline="", encoding="utf-8") as f:
        fieldnames = [
            "source_file",
            "key_path",
            "value_type",
            "depth",
            "occurrences",
            "is_container",
            "concern_type",
            "operational_domain",
            "db_relevance",
            "determinism_impact",
            "migration_priority",
            "draft_decision",
            "rationale",
        ]
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            writer.writerow(row)
    return rows


def summarize(rows):
    by_concern = {}
    by_decision = {}
    for r in rows:
        c = r["concern_type"]
        d = r["draft_decision"]
        by_concern[c] = by_concern.get(c, 0) + 1
        by_decision[d] = by_decision.get(d, 0) + 1
    return by_concern, by_decision


def main():
    p = argparse.ArgumentParser(description="Draft classify JSON key inventory CSVs.")
    p.add_argument(
        "--input",
        dest="inputs",
        action="append",
        required=True,
        help="Input inventory CSV path. Can be passed multiple times.",
    )
    p.add_argument(
        "--out-dir",
        required=True,
        help="Output directory for classification CSV files.",
    )
    args = p.parse_args()

    out_dir = os.path.abspath(args.out_dir)
    if not os.path.exists(out_dir):
        os.makedirs(out_dir)

    for input_csv in args.inputs:
        abs_input = os.path.abspath(input_csv)
        if not os.path.exists(abs_input):
            print("Missing input: {0}".format(abs_input), file=sys.stderr)
            return 1
        source_stem = os.path.basename(abs_input).replace("_key_inventory.csv", "")
        out_csv = os.path.join(out_dir, "{0}_classification_draft.csv".format(source_stem))
        rows = process_inventory(abs_input, out_csv)
        by_concern, by_decision = summarize(rows)
        print("- input: {0}".format(abs_input))
        print("  output: {0}".format(out_csv))
        print("  rows: {0}".format(len(rows)))
        print("  concern_counts: {0}".format(by_concern))
        print("  decision_counts: {0}".format(by_decision))

    return 0


if __name__ == "__main__":
    sys.exit(main())
