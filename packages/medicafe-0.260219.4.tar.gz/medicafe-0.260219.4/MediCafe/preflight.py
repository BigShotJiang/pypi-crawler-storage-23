# preflight.py
"""
Lightweight local preflight check for XP/local workflows.
Catches common environment and config issues before runtime.
Read-only; no auto-fix. Python 3.4.4 compatible.
"""
from __future__ import print_function

import os
import sys
import time
import json
import platform

# Import core_utils for path defaults and import helpers
try:
    from MediCafe import core_utils
except ImportError:
    core_utils = None


def _check_runtime(context, previous_results):
    """Validate Python interpreter version."""
    v = sys.version_info
    if v < (3, 4):
        return {
            'id': 'runtime',
            'status': 'FAIL',
            'message': 'Python 3.4+ required',
            'hint': 'Upgrade to Python 3.4.4 or later',
            'details': '',
        }
    if v < (3, 4, 4):
        return {
            'id': 'runtime',
            'status': 'WARN',
            'message': 'Python {0}.{1}.{2} below 3.4.4'.format(v[0], v[1], v[2] if len(v) > 2 else 0),
            'hint': 'Consider upgrading for XP compatibility',
            'details': '',
        }
    return {
        'id': 'runtime',
        'status': 'PASS',
        'message': 'Python {0}.{1}.{2} OK'.format(v[0], v[1], v[2] if len(v) > 2 else 0),
        'hint': '',
        'details': '',
    }


def _resolve_paths(context):
    """Resolve config/crosswalk paths. Uses context if provided, else env/core_utils."""
    project_dir = core_utils.project_dir if core_utils else os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
    if context:
        config_path = context.get('config_path', '')
        crosswalk_path = context.get('crosswalk_path', '')
        if config_path and crosswalk_path:
            return config_path, crosswalk_path, project_dir
    env_config = os.environ.get('MEDICAFE_CONFIG_FILE', '').strip()
    if env_config:
        config_path = os.path.abspath(env_config)
        env_crosswalk = os.environ.get('MEDICAFE_CROSSWALK_FILE', '').strip()
        crosswalk_path = os.path.abspath(env_crosswalk) if env_crosswalk else os.path.join(os.path.dirname(config_path), 'crosswalk.json')
        return config_path, crosswalk_path, project_dir
    if platform.system() == 'Windows' and getattr(platform, 'release', lambda: '')() == 'XP':
        config_path = r'F:\Medibot\json\config.json'
        crosswalk_path = r'F:\Medibot\json\crosswalk.json'
        return config_path, crosswalk_path, project_dir
    if core_utils:
        config_path = core_utils.DEFAULT_CONFIG_PATH
        crosswalk_path = core_utils.DEFAULT_CROSSWALK_PATH
    else:
        config_path = os.path.join(project_dir, 'json', 'config.json')
        crosswalk_path = os.path.join(project_dir, 'json', 'crosswalk.json')
    if not os.path.exists(config_path):
        current_dir = os.getcwd()
        config_path = os.path.join(current_dir, 'json', 'config.json')
        crosswalk_path = os.path.join(current_dir, 'json', 'crosswalk.json')
    return config_path, crosswalk_path, project_dir


def _check_config_files(context, previous_results):
    """Check config.json and crosswalk.json exist and parse. Do NOT use load_configuration()."""
    config_path, crosswalk_path, _ = _resolve_paths(context)
    if not os.path.exists(config_path):
        return {
            'id': 'config_files',
            'status': 'FAIL',
            'message': 'config.json missing',
            'hint': 'Create json/config.json from template',
            'details': config_path,
        }
    if not os.path.exists(crosswalk_path):
        return {
            'id': 'config_files',
            'status': 'FAIL',
            'message': 'crosswalk.json missing',
            'hint': 'Create json/crosswalk.json from template',
            'details': crosswalk_path,
        }
    try:
        with open(config_path, 'r') as f:
            json.load(f)
    except (ValueError, TypeError) as e:
        return {
            'id': 'config_files',
            'status': 'FAIL',
            'message': 'config.json invalid JSON',
            'hint': 'Fix JSON syntax',
            'details': str(e),
        }
    except OSError as e:
        return {
            'id': 'config_files',
            'status': 'FAIL',
            'message': 'config.json not readable',
            'hint': 'Check file permissions and path',
            'details': str(e),
        }
    try:
        with open(crosswalk_path, 'r') as f:
            json.load(f)
    except (ValueError, TypeError) as e:
        return {
            'id': 'config_files',
            'status': 'FAIL',
            'message': 'crosswalk.json invalid JSON',
            'hint': 'Fix JSON syntax',
            'details': str(e),
        }
    except OSError as e:
        return {
            'id': 'config_files',
            'status': 'FAIL',
            'message': 'crosswalk.json not readable',
            'hint': 'Check file permissions and path',
            'details': str(e),
        }
    return {
        'id': 'config_files',
        'status': 'PASS',
        'message': 'config.json and crosswalk.json present and parseable',
        'hint': '',
        'details': '',
    }


def _check_config_contract(context, previous_results):
    """Validate critical config keys. Skip with WARN if config_files failed."""
    for r in previous_results:
        if r.get('id') == 'config_files' and r.get('status') == 'FAIL':
            return {
                'id': 'config_contract',
                'status': 'WARN',
                'message': 'Skipped (config load failed)',
                'hint': '',
                'details': '',
            }
    config_path, crosswalk_path, project_dir = _resolve_paths(context)
    if not os.path.exists(config_path):
        return {
            'id': 'config_contract',
            'status': 'WARN',
            'message': 'Skipped (config load failed)',
            'hint': '',
            'details': '',
        }
    try:
        with open(config_path, 'r') as f:
            config = json.load(f)
    except Exception:
        return {
            'id': 'config_contract',
            'status': 'WARN',
            'message': 'Skipped (config load failed)',
            'hint': '',
            'details': '',
        }
    if 'MediLink_Config' not in config:
        return {
            'id': 'config_contract',
            'status': 'FAIL',
            'message': 'MediLink_Config missing',
            'hint': 'Add MediLink_Config section to config.json',
            'details': '',
        }
    medi = config.get('MediLink_Config', {})
    local_storage = medi.get('local_storage_path', '')
    if not local_storage or not str(local_storage).strip():
        return {
            'id': 'config_contract',
            'status': 'WARN',
            'message': 'local_storage_path not set',
            'hint': "Add to MediLink_Config; defaults to '.'",
            'details': '',
        }
    return {
        'id': 'config_contract',
        'status': 'PASS',
        'message': 'Config contract OK',
        'hint': '',
        'details': '',
    }


def _check_path_access(context, previous_results):
    """Validate read/write access for required paths."""
    config_path, crosswalk_path, project_dir = _resolve_paths(context)
    config_dir = os.path.dirname(config_path)
    if context:
        local_storage = context.get('local_storage_path', '')
        source_folder = context.get('source_folder', '')
        target_folder = context.get('target_folder', '')
    else:
        local_storage = os.path.join(project_dir, 'MediBot', 'DOWNLOADS')
        source_folder = local_storage
        target_folder = os.path.join(local_storage, 'CSV')
        try:
            with open(config_path, 'r') as f:
                cfg = json.load(f)
            medi = cfg.get('MediLink_Config', {})
            if medi.get('local_storage_path'):
                local_storage = medi['local_storage_path']
                if not os.path.isabs(local_storage):
                    local_storage = os.path.join(project_dir, local_storage)
            source_folder = local_storage
            target_folder = os.path.join(local_storage, 'CSV')
        except Exception:
            pass
    if not os.path.isabs(local_storage):
        local_storage = os.path.join(project_dir, local_storage)
    if not os.path.isabs(source_folder):
        source_folder = os.path.join(project_dir, source_folder)
    if not os.path.isabs(target_folder):
        target_folder = os.path.join(project_dir, target_folder)
    if not os.path.exists(config_dir):
        return {
            'id': 'path_access',
            'status': 'FAIL',
            'message': 'Config directory missing',
            'hint': 'Create json/ directory',
            'details': config_dir,
        }
    if not os.access(config_dir, os.R_OK):
        return {
            'id': 'path_access',
            'status': 'FAIL',
            'message': 'Config directory not readable',
            'hint': 'Check permissions on json/',
            'details': config_dir,
        }
    if os.path.exists(local_storage) and not os.access(local_storage, os.W_OK):
        return {
            'id': 'path_access',
            'status': 'FAIL',
            'message': 'local_storage_path not writable',
            'hint': 'Check permissions on local_storage_path',
            'details': local_storage,
        }
    if not os.path.exists(local_storage):
        return {
            'id': 'path_access',
            'status': 'WARN',
            'message': 'local_storage_path does not exist',
            'hint': 'Directory will be created on first run',
            'details': local_storage,
        }
    if not os.path.exists(source_folder):
        return {
            'id': 'path_access',
            'status': 'WARN',
            'message': 'source_folder does not exist',
            'hint': 'Create directory or update config',
            'details': source_folder,
        }
    if not os.path.exists(target_folder):
        return {
            'id': 'path_access',
            'status': 'WARN',
            'message': 'target_folder does not exist',
            'hint': 'Create directory or update config',
            'details': target_folder,
        }
    if not os.access(source_folder, os.R_OK):
        return {
            'id': 'path_access',
            'status': 'WARN',
            'message': 'source_folder not readable',
            'hint': 'Check permissions',
            'details': source_folder,
        }
    if not os.access(target_folder, os.W_OK):
        return {
            'id': 'path_access',
            'status': 'WARN',
            'message': 'target_folder not writable',
            'hint': 'Check permissions',
            'details': target_folder,
        }
    return {
        'id': 'path_access',
        'status': 'PASS',
        'message': 'Required paths accessible',
        'hint': '',
        'details': '',
    }


def _check_imports(context, previous_results):
    """Verify critical MediLink_DataMgmt import."""
    if not core_utils:
        return {
            'id': 'imports',
            'status': 'FAIL',
            'message': 'core_utils import failed',
            'hint': 'Ensure MediCafe package is on PYTHONPATH',
            'details': '',
        }
    mod = core_utils.import_medilink_module('MediLink_DataMgmt')
    if mod is None:
        return {
            'id': 'imports',
            'status': 'FAIL',
            'message': 'MediLink_DataMgmt import failed',
            'hint': 'Ensure MediLink package is on PYTHONPATH',
            'details': '',
        }
    ok = core_utils.require_functions(mod, ['read_general_fixed_width_data', 'read_fixed_width_data', 'parse_fixed_width_data'])
    if not ok:
        return {
            'id': 'imports',
            'status': 'WARN',
            'message': 'MediLink_DataMgmt missing functions',
            'hint': 'Update MediLink_DataMgmt module',
            'details': '',
        }
    return {
        'id': 'imports',
        'status': 'PASS',
        'message': 'MediLink_DataMgmt OK',
        'hint': '',
        'details': '',
    }


CHECKS = [
    ('runtime', _check_runtime),
    ('config_files', _check_config_files),
    ('config_contract', _check_config_contract),
    ('path_access', _check_path_access),
    ('imports', _check_imports),
]


def run_preflight(context=None):
    """
    Run all checks. Returns (exit_code, report).
    context: optional dict with config_path, crosswalk_path, local_storage_path,
             source_folder, target_folder to override path resolution.
    """
    started = time.time()
    results = []
    for cid, check_fn in CHECKS:
        r = check_fn(context or {}, results)
        r['id'] = cid
        results.append(r)
    finished = time.time()
    counts = {'pass': 0, 'warn': 0, 'fail': 0}
    for r in results:
        s = r.get('status', 'PASS')
        if s == 'PASS':
            counts['pass'] += 1
        elif s in ('WARN', 'SKIP'):
            counts['warn'] += 1
        else:
            counts['fail'] += 1
    report = {
        'started_at': started,
        'finished_at': finished,
        'duration_ms': (finished - started) * 1000,
        'results': results,
        'counts': counts,
    }
    exit_code = 0 if counts['fail'] == 0 else 1
    return exit_code, report


def should_run_preflight(session_state, inputs):
    """
    Launcher decision. Returns True if preflight should run.
    """
    if session_state.get('first_local_workflow', True):
        return True
    if session_state.get('last_preflight_ok') is False:
        return True
    last_cfg = session_state.get('config_mtime')
    last_cw = session_state.get('crosswalk_mtime')
    cfg_path = inputs.get('config_path', '')
    cw_path = inputs.get('crosswalk_path', '')
    try:
        curr_cfg = os.path.getmtime(cfg_path) if cfg_path and os.path.exists(cfg_path) else None
        curr_cw = os.path.getmtime(cw_path) if cw_path and os.path.exists(cw_path) else None
    except (OSError, TypeError):
        return True
    if last_cfg is None or last_cw is None:
        return True
    if curr_cfg != last_cfg or curr_cw != last_cw:
        return True
    return False


def format_preflight_report(report, compact=False):
    """Print report to stdout. compact=True for launcher."""
    counts = report.get('counts', {})
    npass = counts.get('pass', 0)
    nwarn = counts.get('warn', 0)
    nfail = counts.get('fail', 0)
    if compact:
        print('Preflight: {0} pass, {1} warn, {2} fail'.format(npass, nwarn, nfail))
        for r in report.get('results', []):
            if r.get('status') in ('WARN', 'SKIP', 'FAIL'):
                msg = r.get('message', '')
                hint = r.get('hint', '')
                print('[{0}] {1}: {2}'.format(r.get('status', ''), r.get('id', ''), msg))
                if hint:
                    print('  -> hint: {0}'.format(hint))
    else:
        print('MediCafe Preflight Check')
        print('-' * 23)
        for r in report.get('results', []):
            status = r.get('status', 'PASS')
            cid = r.get('id', '')
            msg = r.get('message', '')
            hint = r.get('hint', '')
            print('[{0}] {1}: {2}'.format(status, cid, msg))
            if hint:
                print('  -> hint: {0}'.format(hint))
        print('-' * 23)
        print('Pass: {0}  Warn: {1}  Fail: {2}'.format(npass, nwarn, nfail))
        dur_ms = report.get('duration_ms', 0)
        print('Duration: {0:.2f}s'.format(dur_ms / 1000.0))
