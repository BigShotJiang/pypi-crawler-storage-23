"""
submission_query.py - Multi-source submission query system

Purpose:
- Unified query system that aggregates claim submission data from multiple sources
- Combines JSONL index, 837p receipt files, and DAT source files
- Provides deduplication and prioritization of results

Compatible with: Windows XP SP3, Python 3.4.4, ASCII-only
"""
import os
import json
import time

try:
    from MediCafe.core_utils import get_shared_config_loader, extract_medilink_config
    MediLink_ConfigLoader = get_shared_config_loader()
except ImportError:
    MediLink_ConfigLoader = None


def get_recent_submissions_from_all_sources(config, days=30, limit=50):
    """
    Query recent submissions from all available data sources and combine results.
    
    Sources queried (in priority order):
    1. JSONL submission index (most complete, has transactionId)
    2. 837p receipt files (generated X12, may not be indexed yet)
    3. DAT source files (original fixed-width files, pre-submission)
    
    Args:
        config: Configuration dictionary
        days: Number of days to look back (default 30)
        limit: Maximum number of results to return (default 50)
    
    Returns:
        list: Unified list of submission records sorted by most recent first
    """
    if MediLink_ConfigLoader:
        MediLink_ConfigLoader.log(
            "Starting multi-source submission query: days={}, limit={}".format(days, limit),
            level="INFO"
        )
    
    try:
        if extract_medilink_config:
            medi = extract_medilink_config(config)
            if not medi:
                medi = config.get('MediLink_Config', {})
        else:
            medi = config.get('MediLink_Config', {})
    except Exception:
        medi = config.get('MediLink_Config', {})
    
    receipts_root = medi.get('local_claims_path')
    dat_directory = medi.get('Z_DAT_PATH')
    if dat_directory:
        # Check if Z_DAT_PATH is a file or directory
        if os.path.isfile(dat_directory):
            dat_directory = os.path.dirname(dat_directory)
        elif not os.path.isdir(dat_directory):
            dat_directory = None
    
    # Query each source
    index_results = []
    receipt_results = []
    dat_results = []
    
    # Query JSONL index
    if receipts_root:
        try:
            index_results = get_recent_submissions_from_index(receipts_root, days, limit)
            if MediLink_ConfigLoader:
                MediLink_ConfigLoader.log(
                    "Found {} submissions from JSONL index".format(len(index_results)),
                    level="INFO"
                )
        except Exception as e:
            if MediLink_ConfigLoader:
                MediLink_ConfigLoader.log(
                    "Error querying JSONL index: {}".format(e),
                    level="WARNING"
                )
    else:
        if MediLink_ConfigLoader:
            MediLink_ConfigLoader.log(
                "local_claims_path not configured, skipping JSONL index query",
                level="INFO"
            )
    
    # Query 837p receipt files
    if receipts_root:
        try:
            receipt_results = get_recent_submissions_from_receipts(receipts_root, days, limit)
            if MediLink_ConfigLoader:
                MediLink_ConfigLoader.log(
                    "Found {} submissions from 837p receipt files".format(len(receipt_results)),
                    level="INFO"
                )
        except Exception as e:
            if MediLink_ConfigLoader:
                MediLink_ConfigLoader.log(
                    "Error querying 837p receipts: {}".format(e),
                    level="WARNING"
                )
    
    # Query DAT source files
    if dat_directory and os.path.isdir(dat_directory):
        try:
            dat_results = get_recent_submissions_from_dat_files(dat_directory, config, days, limit)
            if MediLink_ConfigLoader:
                MediLink_ConfigLoader.log(
                    "Found {} submissions from DAT source files".format(len(dat_results)),
                    level="INFO"
                )
        except Exception as e:
            if MediLink_ConfigLoader:
                MediLink_ConfigLoader.log(
                    "Error querying DAT files: {}".format(e),
                    level="WARNING"
                )
    else:
        if MediLink_ConfigLoader:
            MediLink_ConfigLoader.log(
                "Z_DAT_PATH not configured or directory does not exist, skipping DAT file query",
                level="INFO"
            )
    
    # Combine and deduplicate
    combined_results = combine_and_deduplicate_submissions(
        index_results, receipt_results, dat_results
    )
    
    # Limit results
    if len(combined_results) > limit:
        combined_results = combined_results[:limit]
    
    if MediLink_ConfigLoader:
        MediLink_ConfigLoader.log(
            "Multi-source query complete: {} total submissions after deduplication".format(
                len(combined_results)
            ),
            level="INFO"
        )
    
    return combined_results


def get_recent_submissions_from_index(receipts_root, days=30, limit=50):
    """
    Query recent submissions from JSONL submission index.
    
    Args:
        receipts_root: Path to receipts directory containing submission_index.jsonl
        days: Number of days to look back
        limit: Maximum number of results
    
    Returns:
        list: List of submission records from index
    """
    from MediCafe.submission_index import _index_path
    
    results = []
    cutoff_time = time.time() - (days * 86400)
    
    index_path = _index_path(receipts_root)
    if not os.path.exists(index_path):
        return results
    
    try:
        with open(index_path, 'r') as f:
            for line in f:
                try:
                    entry = json.loads(line.strip())
                    if not isinstance(entry, dict):
                        continue
                    
                    # Skip ack events, we want submission records
                    if entry.get('notes') == 'ack event':
                        continue
                    
                    # Check timestamp
                    submitted_at = entry.get('submitted_at', '')
                    if submitted_at:
                        try:
                            # Handle both timestamp formats
                            if isinstance(submitted_at, (int, float)):
                                timestamp = float(submitted_at)
                            else:
                                # Try parsing datetime string
                                from datetime import datetime
                                dt = datetime.strptime(submitted_at, "%Y-%m-%d %H:%M:%S")
                                timestamp = time.mktime(dt.timetuple())
                            
                            if timestamp < cutoff_time:
                                continue
                        except Exception:
                            pass
                    
                    # Add source metadata
                    entry['source'] = 'index'
                    entry['source_priority'] = 1
                    results.append(entry)
                    
                except Exception:
                    continue
        
        # Sort by most recent first (normalize timestamps for consistent comparison)
        def get_timestamp(record):
            submitted_at = record.get('submitted_at', '')
            if isinstance(submitted_at, (int, float)):
                return float(submitted_at)
            elif isinstance(submitted_at, str):
                try:
                    from datetime import datetime
                    dt = datetime.strptime(submitted_at, "%Y-%m-%d %H:%M:%S")
                    return time.mktime(dt.timetuple())
                except Exception:
                    return 0
            return 0
        
        results.sort(key=get_timestamp, reverse=True)
        
        if len(results) > limit:
            results = results[:limit]
            
    except Exception:
        pass
    
    return results


def get_recent_submissions_from_receipts(receipts_root, days=30, limit=50):
    """
    Scan 837p receipt files directory for recent submissions.
    
    Args:
        receipts_root: Path to receipts directory containing .837p files
        days: Number of days to look back
        limit: Maximum number of results
    
    Returns:
        list: List of submission records from 837p files
    """
    results = []
    cutoff_time = time.time() - (days * 86400)
    
    if not os.path.isdir(receipts_root):
        return results
    
    try:
        # Scan for .837p files
        for filename in os.listdir(receipts_root):
            if not filename.endswith('.837p'):
                continue
            
            filepath = os.path.join(receipts_root, filename)
            try:
                mtime = os.path.getmtime(filepath)
                if mtime < cutoff_time:
                    continue
                
                # Create basic record from file
                record = {
                    'source': 'receipt',
                    'source_priority': 2,
                    'receipt_file': filepath,
                    'submitted_at': mtime,
                    'dos': '',  # Will be extracted by x12_utils if needed
                    'payer_id': '',
                    'primary_insurance': '',
                    'patient_id': '',
                }

                # Best-effort enrichment from X12 contents so UI can show patient info.
                # Keep failures non-fatal to preserve resilience on legacy environments.
                try:
                    from MediCafe.x12_utils import extract_member_data_from_x12_file
                    x12_data = extract_member_data_from_x12_file(filepath)
                    if isinstance(x12_data, dict):
                        first = (x12_data.get('member_first_name') or '').strip()
                        last = (x12_data.get('member_last_name') or '').strip()
                        if first:
                            record['member_first_name'] = first
                        if last:
                            record['member_last_name'] = last
                        if first or last:
                            record['patient_name'] = "{} {}".format(first, last).strip()

                        member_id = (x12_data.get('member_id') or '').strip()
                        if member_id:
                            record['patient_id'] = member_id

                        payer_id = (x12_data.get('payer_id') or '').strip()
                        if payer_id:
                            record['payer_id'] = payer_id

                        # Populate dos so receipt records can deduplicate (dedup requires payer_id, dos, patient_id)
                        service_start = (x12_data.get('service_start_date') or '').strip()
                        if service_start:
                            record['dos'] = service_start
                except Exception:
                    pass
                
                results.append(record)
                
            except Exception:
                continue
        
        # Sort by most recent first
        results.sort(key=lambda x: x.get('submitted_at', 0), reverse=True)
        
        if len(results) > limit:
            results = results[:limit]
            
    except Exception:
        pass
    
    return results


def get_recent_submissions_from_dat_files(dat_directory, config, days=30, limit=50):
    """
    Scan DAT source files directory for recent submissions.
    
    Args:
        dat_directory: Path to directory containing .DAT files
        config: Configuration dictionary
        days: Number of days to look back
        limit: Maximum number of results
    
    Returns:
        list: List of submission records from DAT files
    """
    results = []
    cutoff_time = time.time() - (days * 86400)
    
    if not os.path.isdir(dat_directory):
        return results
    
    try:
        # Scan for .DAT files
        for filename in os.listdir(dat_directory):
            if not filename.lower().endswith('.dat'):
                continue
            
            filepath = os.path.join(dat_directory, filename)
            try:
                mtime = os.path.getmtime(filepath)
                if mtime < cutoff_time:
                    continue
                
                # Create basic record from file
                record = {
                    'source': 'dat',
                    'source_priority': 3,
                    'dat_file': filepath,
                    'submitted_at': mtime,
                    'dos': '',  # Will be extracted by dat_utils if needed
                    'payer_id': '',
                    'primary_insurance': '',
                    'patient_id': '',
                }
                
                results.append(record)
                
            except Exception:
                continue
        
        # Sort by most recent first
        results.sort(key=lambda x: x.get('submitted_at', 0), reverse=True)
        
        if len(results) > limit:
            results = results[:limit]
            
    except Exception:
        pass
    
    return results


def combine_and_deduplicate_submissions(index_results, receipt_results, dat_results):
    """
    Combine and deduplicate submission records from multiple sources.
    
    Deduplication strategy:
    - Prefer index records (most complete, priority 1)
    - Then receipt records (have X12, priority 2)
    - Then DAT records (source files, priority 3)
    - Deduplicate by (payer_id, dos, patient_id) when available
    
    Args:
        index_results: List of records from JSONL index
        receipt_results: List of records from 837p files
        dat_results: List of records from DAT files
    
    Returns:
        list: Combined and deduplicated list sorted by most recent first
    """
    def _merge_missing_fields(primary, secondary):
        """Fill empty fields in primary record from secondary record."""
        if not isinstance(primary, dict) or not isinstance(secondary, dict):
            return primary

        # Merge only fields used in status lookup display/search context.
        for key in [
            'patient_name', 'name', 'member_first_name', 'member_last_name',
            'memberFirstName', 'memberLastName', 'member_id', 'patient_id',
            'payer_id', 'primary_insurance', 'dos', 'transactionId', 'transaction_id'
        ]:
            primary_val = primary.get(key)
            if primary_val is None or (isinstance(primary_val, str) and not primary_val.strip()):
                secondary_val = secondary.get(key)
                if secondary_val is not None:
                    if isinstance(secondary_val, str):
                        if secondary_val.strip():
                            primary[key] = secondary_val
                    else:
                        primary[key] = secondary_val
        return primary

    # Use dict to track unique submissions by key
    seen = {}
    combined = []
    
    # Process in priority order (index first, then receipts, then DAT)
    all_results = index_results + receipt_results + dat_results
    
    for record in all_results:
        # Try to create deduplication key
        payer_id = record.get('payer_id', '')
        dos = record.get('dos', '')
        patient_id = record.get('patient_id', '')
        
        # Deduplicate only when claim identity is sufficiently specific.
        # If patient_id is missing, payer+DOS can collide across multiple patients.
        if not payer_id or not dos or not patient_id:
            combined.append(record)
            continue
        
        # Create key for deduplication
        key = "{}_{}_{}".format(payer_id, dos, patient_id)
        
        # Check if we've seen this before
        if key in seen:
            existing = seen[key]
            # Always backfill missing data from duplicate record.
            _merge_missing_fields(existing, record)

            # Keep the one with higher priority (lower priority number)
            if record.get('source_priority', 999) < existing.get('source_priority', 999):
                # Replace with higher priority record
                _merge_missing_fields(record, existing)
                seen[key] = record
                # Remove old record from combined
                try:
                    combined.remove(existing)
                except ValueError:
                    pass
                combined.append(record)
        else:
            seen[key] = record
            combined.append(record)
    
    # Sort by most recent first
    combined.sort(key=lambda x: x.get('submitted_at', 0), reverse=True)
    
    return combined
