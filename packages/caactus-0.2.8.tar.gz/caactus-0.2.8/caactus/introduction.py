DESCRIPTION = """
<images/ascii-art-text.png>
                                                                                                 

Welcome to the caactus pipeline.

caactus (cell analysis and counting tool using ilastik software) is a collection of python scripts to provide a streamlined workflow for ilastik (https://www.ilastik.org/).

It includes data preparation, processing and analysis. 

It aims to provide biologist with an easy-to-use tool for counting and analyzing cells from a large number of microscopy pictures.

The workflow is organized into multiple steps, each with its own specific purpose and requirements.

To begin, select a step from the tabs on the left. Each tab provides detailed instructions for completing that stage.

Some steps allow you to choose between training mode and batch processing mode.
Use the dropdown menu within the step to select the desired stage.

Three steps need to be performed in ilastik, a user-friendly tool for image analysis. 
The instructions for these steps will guide you through the necessary actions in ilastik.


All folder names referenced in the instructions correspond to the structure of your main project directory.

Default folder names are provided, but they can be modified either directly in the interface or in the `config.toml` file.



"""