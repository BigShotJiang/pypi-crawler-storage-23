"""Allow running ossuary as: python -m ossuary"""

from ossuary.cli import app

app()
