"""Sentiment analysis for maintainer communications."""

from ossuary.sentiment.analyzer import SentimentAnalyzer

__all__ = ["SentimentAnalyzer"]
