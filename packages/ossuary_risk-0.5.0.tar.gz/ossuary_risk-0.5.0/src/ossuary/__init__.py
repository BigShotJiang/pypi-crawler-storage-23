"""
Ossuary - OSS Supply Chain Risk Scoring

Where abandoned packages come to rest.
"""

__version__ = "0.5.0"
