"""Tests for ossuary."""
