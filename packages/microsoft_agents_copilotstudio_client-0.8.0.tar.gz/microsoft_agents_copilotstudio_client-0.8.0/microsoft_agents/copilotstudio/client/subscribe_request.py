# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License.

from microsoft_agents.activity import AgentsModel


class SubscribeRequest(AgentsModel):
    """
    Request model for subscribe operations.
    """

    pass
