# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License.

from microsoft_agents.activity import AgentsModel


class SubscribeResponse(AgentsModel):
    """
    Response model for subscribe operations.
    """

    pass
