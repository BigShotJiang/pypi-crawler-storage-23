import asyncio
import logging
import os

import pyrogram
from pyrogram.crypto import aes

from .tcp import TCP

log = logging.getLogger(__name__)


class TCPAbridgedO(TCP):
    RESERVED = (b"HEAD", b"POST", b"GET ", b"OPTI", b"\xee" * 4)

    def __init__(self, ipv6: bool, proxy: dict | None = None) -> None:
        super().__init__(ipv6, proxy)

        self.encrypt: tuple[bytes, bytes, bytearray] | None = None
        self.decrypt: tuple[bytes, bytes, bytearray] | None = None

    async def connect(self, address: tuple[str, int]) -> None:
        await super().connect(address)

        while True:
            nonce = bytearray(os.urandom(64))

            if (
                nonce[0:1] != b"\xef"
                and nonce[:4] not in self.RESERVED
                and nonce[4:8] != b"\x00" * 4
            ):
                nonce[56] = nonce[57] = nonce[58] = nonce[59] = 0xEF
                break

        temp = bytearray(nonce[55:7:-1])

        self.encrypt = (bytes(nonce[8:40]), bytes(nonce[40:56]), bytearray(1))
        self.decrypt = (bytes(temp[0:32]), bytes(temp[32:48]), bytearray(1))

        nonce[56:64] = aes.ctr256_encrypt(bytes(nonce), *self.encrypt)[56:64]

        await super().send(bytes(nonce))

    async def send(self, data: bytes) -> None:
        length = len(data) // 4
        payload = (
            bytes([length])
            if length <= 126
            else b"\x7f" + length.to_bytes(3, "little")
        ) + data

        loop = asyncio.get_running_loop()
        encrypted = await loop.run_in_executor(
            pyrogram.crypto_executor, aes.ctr256_encrypt, payload, *self.encrypt
        )

        await super().send(encrypted)

    async def recv(self, length: int = 0) -> bytes | None:
        length_bytes = await super().recv(1)

        if length_bytes is None:
            return None

        length_bytes = aes.ctr256_decrypt(length_bytes, *self.decrypt)

        if length_bytes == b"\x7f":
            length_bytes = await super().recv(3)

            if length_bytes is None:
                return None

            length_bytes = aes.ctr256_decrypt(length_bytes, *self.decrypt)

        data = await super().recv(int.from_bytes(length_bytes, "little") * 4)

        if data is None:
            return None

        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(
            pyrogram.crypto_executor, aes.ctr256_decrypt, data, *self.decrypt
        )