import asyncio
import logging
import os
from struct import pack, unpack

import pyrogram
from pyrogram.crypto import aes

from .tcp import TCP

log = logging.getLogger(__name__)


class TCPIntermediateO(TCP):
    RESERVED = (b"HEAD", b"POST", b"GET ", b"OPTI", b"\xee" * 4)

    def __init__(self, ipv6: bool, proxy: dict | None = None) -> None:
        super().__init__(ipv6, proxy)

        self.encrypt: tuple[bytes, bytes, bytearray] | None = None
        self.decrypt: tuple[bytes, bytes, bytearray] | None = None

    async def connect(self, address: tuple[str, int]) -> None:
        await super().connect(address)

        while True:
            nonce = bytearray(os.urandom(64))

            if (
                nonce[0:1] != b"\xef"
                and nonce[:4] not in self.RESERVED
                and nonce[4:8] != b"\x00" * 4
            ):
                nonce[56] = nonce[57] = nonce[58] = nonce[59] = 0xEE
                break

        temp = bytearray(nonce[55:7:-1])

        self.encrypt = (bytes(nonce[8:40]), bytes(nonce[40:56]), bytearray(1))
        self.decrypt = (bytes(temp[0:32]), bytes(temp[32:48]), bytearray(1))

        nonce[56:64] = aes.ctr256_encrypt(bytes(nonce), *self.encrypt)[56:64]

        await super().send(bytes(nonce))

    async def send(self, data: bytes) -> None:
        payload = pack("<i", len(data)) + data

        loop = asyncio.get_running_loop()
        encrypted = await loop.run_in_executor(
            pyrogram.crypto_executor,
            aes.ctr256_encrypt,
            payload,
            *self.encrypt,
        )

        await super().send(encrypted)

    async def recv(self, length: int = 0) -> bytes | None:
        length_bytes = await super().recv(4)

        if length_bytes is None:
            return None

        loop = asyncio.get_running_loop()

        length_bytes = await loop.run_in_executor(
            pyrogram.crypto_executor,
            aes.ctr256_decrypt,
            length_bytes,
            *self.decrypt,
        )

        data = await super().recv(unpack("<i", length_bytes)[0])

        if data is None:
            return None

        return await loop.run_in_executor(
            pyrogram.crypto_executor,
            aes.ctr256_decrypt,
            data,
            *self.decrypt,
        )