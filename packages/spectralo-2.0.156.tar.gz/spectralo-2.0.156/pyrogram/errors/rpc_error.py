import re
from datetime import datetime
from importlib import import_module

from pyrogram import raw
from pyrogram.raw.core import TLObject

from .exceptions.all import exceptions


class RPCError(Exception):
    ID = None
    CODE = None
    NAME = None
    MESSAGE = "{value}"

    def __init__(
        self,
        value: int | str | raw.types.RpcError = None,
        rpc_name: str = None,
        is_unknown: bool = False,
        is_signed: bool = False,
    ):
        # ALWAYS safe — message fallback
        message_template = self.MESSAGE or "{value}"

        # Safe formatting protection
        try:
            formatted_message = message_template.format(value=value)
        except Exception:
            formatted_message = str(value) if value is not None else "Unknown error"

        # Build final human-readable message
        super().__init__(
            f"Telegram says: [{"-" if is_signed else ""}"
            f"{self.CODE} {self.ID or self.NAME}] - "
            f"{formatted_message} "
            f"{f"(caused by \"{rpc_name}\")" if rpc_name else ""}"
        )

        # Save error value
        try:
            self.value = int(value)
        except (ValueError, TypeError):
            self.value = value

        # Log unknown errors into file
        if is_unknown:
            with open("unknown_errors.txt", "a", encoding="utf-8") as f:
                f.write(f"{datetime.now()}\t{value}\t{rpc_name}\n")

    @staticmethod
    def raise_it(rpc_error: "raw.types.RpcError", rpc_type: type[TLObject]):
        error_code = rpc_error.error_code
        is_signed = error_code < 0
        error_message = rpc_error.error_message
        rpc_name = ".".join(rpc_type.QUALNAME.split(".")[1:])

        if is_signed:
            error_code = -error_code

        # If no entry for error code → unknown error
        if error_code not in exceptions:
            raise UnknownError(
                value=f"[{error_code} {error_message}]",
                rpc_name=rpc_name,
                is_unknown=True,
                is_signed=is_signed,
            )

        # Normalize error ID (replace trailing _123 → _X)
        error_id = re.sub(r"_\d+", "_X", error_message)

        # If this specific error type is not mapped → use default class
        if error_id not in exceptions[error_code]:
            raise getattr(
                import_module("pyrogram.errors"),
                exceptions[error_code]["_"],
            )(
                value=f"[{error_code} {error_message}]",
                rpc_name=rpc_name,
                is_unknown=True,
                is_signed=is_signed,
            )

        # Extract numeric value for MESSAGE formatting
        match = re.search(r"_(\d+)", error_message)
        value = match.group(1) if match else ""

        # Raise the specific mapped error class
        raise getattr(
            import_module("pyrogram.errors"),
            exceptions[error_code][error_id],
        )(
            value=value,
            rpc_name=rpc_name,
            is_unknown=False,
            is_signed=is_signed,
        )


class UnknownError(RPCError):
    CODE = 520
    NAME = "Unknown error"