from .compat import extract_stream_ptr
from .player import Screenshoter, Player