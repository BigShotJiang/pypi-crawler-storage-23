"""
Safe Mode — Your AI can't delete your files, leak your secrets, or blow your budget.

Local safety layer for AI agents. Intercepts tool calls, detects dangerous actions,
and blocks catastrophic mistakes before they happen.

https://safemode.run
"""

__version__ = "0.0.1"
__author__ = "TrustScope"
__license__ = "MIT"
