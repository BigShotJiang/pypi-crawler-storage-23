# Safe Mode for AI Agents

**Your AI can't delete your files, leak your secrets, or blow your budget.**

Safe Mode is a local safety layer for AI agents. It intercepts tool calls, detects dangerous actions, and blocks catastrophic mistakes — before they happen.

## Installation

```bash
pip install safemode-ai
```

## Coming Soon

The Safe Mode Python SDK is under active development. It will provide:

- **Action gating** — Allow, approve, or block AI actions by category
- **Detection engines** — Secret scanning, PII detection, prompt injection, path traversal, loop killing, budget caps
- **Preset configurations** — Safe-ish (YOLO with seatbelt), Coding (standard guardrails), Personal (AI assistant mode), Strict (read-only)
- **Framework integration** — Works with LangChain, CrewAI, AutoGen, and custom Python AI agents
- **Local-first** — Runs on your machine. No account required. No data leaves your device.

## Also Available

- **npm package (MCP proxy):** `npm install -g safemode`
- **TrustScope (cloud governance):** [trustscope.ai](https://trustscope.ai)

## Links

- **Website:** [safemode.run](https://safemode.run)
- **GitHub:** [github.com/trustscope/safemode-ai](https://github.com/trustscope/safemode-ai)

## License

MIT
