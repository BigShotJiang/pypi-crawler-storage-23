"""
Agent Step Classifier - Calls YOUR backend for AI classification.

NO USER API KEY NEEDED - classification powered by YOUR server!
"""

import os
import asyncio
from typing import Dict, Tuple, Optional, List

try:
    # Import from same package
    from .agent_tracker import StepType
    from .cache_manager import get_pattern_cache
except ImportError:
    from agent_tracker import StepType
    from cache_manager import get_pattern_cache

try:
    # Calculator is in aioptimize_core
    from llmoptimize_core.llmoptimized.calculator import MODEL_PRICING, MODEL_ALTERNATIVES, get_cheapest_model
except ImportError:
    try:
        # Fallback if in same directory
        from llmoptimize_core.llmoptimized.calculator import MODEL_PRICING, MODEL_ALTERNATIVES, get_cheapest_model
    except ImportError:
        # Last resort - try relative
        from llmoptimize_core.llmoptimized.calculator import MODEL_PRICING, MODEL_ALTERNATIVES, get_cheapest_model


class AgentStepClassifier:
    """
    Hybrid classifier - calls YOUR backend for AI, fallback to rules.
    
    Flow:
    1. Check cache (pattern-based) → instant, free
    2. Try rule-based (if cache miss) → 1ms, free
    3. Use YOUR AI (if low confidence) → 300ms, YOUR server
    4. Cache result for future → next time is instant!
    """
    
    # Keywords for rule-based classification
    STEP_PATTERNS = {
        StepType.PLANNING: [
            "plan", "strategy", "approach", "think about",
            "consider", "analyze", "evaluate", "decide",
            "determine", "figure out", "should i", "let me think",
            "first i will", "my approach", "i need to"
        ],
        StepType.TOOL_CALL: [
            "use tool", "call function", "execute", "run",
            "search", "query", "fetch", "get", "retrieve",
            "lookup", "find", "access", "invoke", "api"
        ],
        StepType.PARSING: [
            "extract", "parse", "find", "identify",
            "get the", "pull out", "locate", "read",
            "from the", "in the", "contains"
        ],
        StepType.REASONING: [
            "because", "therefore", "thus", "hence",
            "reasoning", "rationale", "why", "how",
            "given that", "considering", "since"
        ],
        StepType.SYNTHESIS: [
            "combine", "merge", "synthesize", "aggregate",
            "summarize", "conclude", "overall", "together",
            "final", "result", "outcome"
        ],
        StepType.FORMATTING: [
            "format", "structure", "organize", "arrange",
            "present", "display", "show as", "output",
            "convert to", "transform"
        ],
        StepType.VERIFICATION: [
            "verify", "check if", "validate", "ensure",
            "confirm", "test", "is correct", "matches"
        ],
        StepType.REFLECTION: [
            "reflect", "review", "check", "verify",
            "validate", "confirm", "assess quality",
            "did i", "was that", "is this correct"
        ]
    }
    
    def __init__(
        self,
        confidence_threshold: float = 0.75,
        enable_cache: bool = True
    ):
        """
        Initialize hybrid classifier with caching.
        
        Args:
            confidence_threshold: Use AI if confidence below this
            enable_cache: Enable pattern-based caching
        """
        self.confidence_threshold = confidence_threshold
        self.enable_cache = enable_cache
        
        # Server URL
        self.server_url = os.getenv(
            "AIOPTIMIZE_SERVER_URL",
            "https://aioptimize.up.railway.app"  # YOUR production URL
        )
        
        # Get cache instance
        self.cache = get_pattern_cache() if enable_cache else None
        self.cache_namespace = "agent_classifier"
        
        # Build model recommendations dynamically from calculator
        self._build_optimal_models()
        
        # Stats
        self.total_classifications = 0
        self.cache_hits = 0
        self.rule_based_count = 0
        self.ai_based_count = 0
    
    def _build_optimal_models(self):
        """Build optimal model recommendations for each step type"""
        
        # Find expensive models
        best_expensive = "gpt-4"  # fallback
        for model in ["gpt-4o", "gpt-4-turbo", "gpt-4", "claude-3-opus"]:
            if model in MODEL_PRICING:
                best_expensive = model
                break
        
        # Get best cheap model
        best_cheap, _ = get_cheapest_model(1000, 500, exclude_embeddings=True)
        
        # Build optimal models map
        self.OPTIMAL_MODELS = {
            StepType.PLANNING: best_expensive,
            StepType.REASONING: best_expensive,
            StepType.TOOL_CALL: best_cheap,
            StepType.PARSING: best_cheap,
            StepType.SYNTHESIS: best_expensive,
            StepType.FORMATTING: best_cheap,
            StepType.VERIFICATION: best_cheap,
            StepType.REFLECTION: best_expensive,
            StepType.UNKNOWN: best_cheap
        }
    
    def _can_use_ai(self) -> bool:
        """Check if AI classification is available (through YOUR server)"""
        return True  # AI always available through YOUR backend
    
    def classify_step(
        self,
        prompt: str,
        context: Dict
    ) -> Tuple[StepType, str, float]:
        """
        Classify step using hybrid approach with caching.
        
        Args:
            prompt: The prompt being used
            context: Context (step number, etc.)
        
        Returns:
            (step_type, recommended_model, confidence)
        """
        
        try:
            loop = asyncio.get_event_loop()
            if loop.is_running():
                return self._classify_sync(prompt, context)
            else:
                return loop.run_until_complete(self.classify_step_async(prompt, context))
        except RuntimeError:
            return self._classify_sync(prompt, context)
    
    async def classify_step_async(
        self,
        prompt: str,
        context: Dict
    ) -> Tuple[StepType, str, float]:
        """Classify step (async version with caching)"""
        
        self.total_classifications += 1
        
        # Check cache first
        if self.cache:
            cached = self.cache.get_pattern(self.cache_namespace, prompt)
            
            if cached:
                self.cache_hits += 1
                step_type = StepType[cached["step_type"]]
                recommended_model = cached["recommended_model"]
                confidence = cached["confidence"]
                return step_type, recommended_model, confidence
        
        # Try rule-based classification
        step_type, recommended_model, confidence = self._rule_based_classify(
            prompt, context
        )
        
        # If confident enough, cache and return
        if confidence >= self.confidence_threshold:
            self.rule_based_count += 1
            self._cache_result(prompt, step_type, recommended_model, confidence, "rule_based")
            return step_type, recommended_model, confidence
        
        # Use AI classification from YOUR server
        if self._can_use_ai():
            try:
                ai_step_type, ai_model, ai_confidence = await self._ai_classify(
                    prompt, context
                )
                
                self.ai_based_count += 1
                self._cache_result(prompt, ai_step_type, ai_model, ai_confidence, "ai")
                return ai_step_type, ai_model, ai_confidence
                
            except Exception as e:
                print(f"⚠️  AI classification failed: {e}")
                self.rule_based_count += 1
                self._cache_result(prompt, step_type, recommended_model, confidence, "rule_based_fallback")
                return step_type, recommended_model, confidence
        else:
            self.rule_based_count += 1
            self._cache_result(prompt, step_type, recommended_model, confidence, "rule_based_no_ai")
            return step_type, recommended_model, confidence
    
    def _classify_sync(
        self,
        prompt: str,
        context: Dict
    ) -> Tuple[StepType, str, float]:
        """Synchronous version with caching"""
        
        self.total_classifications += 1
        
        # Check cache
        if self.cache:
            cached = self.cache.get_pattern(self.cache_namespace, prompt)
            
            if cached:
                self.cache_hits += 1
                step_type = StepType[cached["step_type"]]
                return step_type, cached["recommended_model"], cached["confidence"]
        
        # Rule-based
        self.rule_based_count += 1
        step_type, recommended_model, confidence = self._rule_based_classify(prompt, context)
        
        # Cache result
        self._cache_result(prompt, step_type, recommended_model, confidence, "rule_based_sync")
        
        return step_type, recommended_model, confidence
    
    def _cache_result(
        self,
        prompt: str,
        step_type: StepType,
        recommended_model: str,
        confidence: float,
        source: str
    ):
        """Cache classification result"""
        
        if not self.cache:
            return
        
        cache_value = {
            "step_type": step_type.name,
            "recommended_model": recommended_model,
            "confidence": confidence,
            "source": source
        }
        
        self.cache.set_pattern(
            self.cache_namespace,
            prompt,
            cache_value,
            ttl_hours=168,  # 7 days
            metadata={"source": source}
        )
    
    def _rule_based_classify(
        self,
        prompt: str,
        context: Dict
    ) -> Tuple[StepType, str, float]:
        """Fast rule-based classification"""
        
        prompt_lower = prompt.lower()
        
        # Score each step type
        scores = {}
        for step_type, keywords in self.STEP_PATTERNS.items():
            scores[step_type] = self._score_keywords(prompt_lower, keywords)
        
        # Context adjustments
        step_number = context.get("step_number", 1)
        
        if step_number == 1:
            scores[StepType.PLANNING] = scores.get(StepType.PLANNING, 0) + 0.3
        
        total_steps = context.get("total_steps", 10)
        if step_number >= total_steps - 2:
            scores[StepType.SYNTHESIS] = scores.get(StepType.SYNTHESIS, 0) + 0.2
            scores[StepType.FORMATTING] = scores.get(StepType.FORMATTING, 0) + 0.2
        
        # Get best match
        if not scores or max(scores.values()) == 0:
            return StepType.UNKNOWN, self.OPTIMAL_MODELS[StepType.UNKNOWN], 0.5
        
        step_type = max(scores, key=scores.get)
        confidence = min(1.0, scores[step_type])
        
        # Boost confidence if multiple indicators
        keyword_matches = sum(1 for score in scores.values() if score > 0)
        if keyword_matches >= 2:
            confidence = min(1.0, confidence * 1.2)
        
        # Get recommended model
        recommended_model = self.OPTIMAL_MODELS.get(step_type, self.OPTIMAL_MODELS[StepType.UNKNOWN])
        
        return step_type, recommended_model, confidence
    
    async def _ai_classify(
        self,
        prompt: str,
        context: Dict
    ) -> Tuple[StepType, str, float]:
        """Call YOUR server for AI-powered step classification"""
        
        try:
            import requests
            
            # Get available model options
            expensive_model = self.OPTIMAL_MODELS[StepType.PLANNING]
            cheap_model = self.OPTIMAL_MODELS[StepType.TOOL_CALL]
            
            # Call YOUR server
            response = requests.post(
                f"{self.server_url}/api/classify-step",
                json={
                    "prompt": prompt[:500],
                    "context": context,
                    "expensive_model": expensive_model,
                    "cheap_model": cheap_model
                },
                timeout=2  # Fast classification
            )
            
            if response.status_code == 200:
                data = response.json()
                
                if data.get("success"):
                    result = data.get("classification", {})
                    
                    step_type_str = result.get("step_type", "UNKNOWN").upper()
                    step_type = self._string_to_step_type(step_type_str)
                    
                    recommended_model = result.get("recommended_model")
                    if not recommended_model or recommended_model not in MODEL_PRICING:
                        recommended_model = self.OPTIMAL_MODELS.get(step_type, cheap_model)
                    
                    confidence = float(result.get("confidence", 0.8))
                    
                    return step_type, recommended_model, confidence
            
            # Server unavailable - fall back to rule-based
            raise Exception("Server unavailable")
            
        except Exception:
            # Fall back to rule-based classification
            return self._rule_based_classify(prompt, context)
    
    def _string_to_step_type(self, step_str: str) -> StepType:
        """Convert string to StepType enum"""
        
        mapping = {
            "PLANNING": StepType.PLANNING,
            "REASONING": StepType.REASONING,
            "TOOL_CALL": StepType.TOOL_CALL,
            "PARSING": StepType.PARSING,
            "SYNTHESIS": StepType.SYNTHESIS,
            "FORMATTING": StepType.FORMATTING,
            "VERIFICATION": StepType.VERIFICATION,
            "REFLECTION": StepType.REFLECTION
        }
        
        return mapping.get(step_str.upper(), StepType.UNKNOWN)
    
    def _score_keywords(self, text: str, keywords: list) -> float:
        """Score text based on keyword matches"""
        matches = sum(1 for kw in keywords if kw in text)
        return min(1.0, matches * 0.2)
    
    def get_stats(self) -> Dict:
        """Get classification statistics"""
        
        rule_pct = (self.rule_based_count / self.total_classifications * 100) if self.total_classifications > 0 else 0
        ai_pct = (self.ai_based_count / self.total_classifications * 100) if self.total_classifications > 0 else 0
        cache_hit_pct = (self.cache_hits / self.total_classifications * 100) if self.total_classifications > 0 else 0
        
        stats = {
            "total_classifications": self.total_classifications,
            "cache_hits": self.cache_hits,
            "cache_hit_rate": f"{cache_hit_pct:.1f}%",
            "rule_based": self.rule_based_count,
            "rule_based_percent": f"{rule_pct:.1f}%",
            "ai_based": self.ai_based_count,
            "ai_based_percent": f"{ai_pct:.1f}%",
            "estimated_cost": self.ai_based_count * 0.0001,
            "estimated_savings_from_cache": self.cache_hits * 0.0001,
            "confidence_threshold": self.confidence_threshold
        }
        
        return stats
    
    def get_model_for_step(self, step_type: StepType) -> str:
        """Get optimal model for a given step type"""
        return self.OPTIMAL_MODELS.get(step_type, self.OPTIMAL_MODELS[StepType.UNKNOWN])