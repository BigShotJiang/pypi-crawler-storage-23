"""
Smart Analyzer - Main intelligence engine with ML integration.

Coordinates:
- Heuristic analysis (fast rules)
- RAG pattern detection (specialized)
- LLM analysis (intelligent)
- ML model predictions (learns over time)

Gets smarter with every API call!
"""

import asyncio
from typing import Dict, Optional
from datetime import datetime

from .models import Recommendation
from .heuristic_analyzer import AgentHeuristicAnalyzer
from .rag_analyzer import RAGAnalyzer
from .llm_analyzer import FreeLLMAnalyzer
from .ml_trainer import MLTrainer


class SmartAnalyzer:
    """
    Main intelligence engine that coordinates all analyzers.
    
    Analysis Pipeline:
    1. Heuristics (5ms) - Fast pattern matching
    2. RAG detection (3ms) - Specialized for RAG patterns
    3. LLM analysis (300ms) - Intelligent reasoning
    4. ML model (10ms) - Learned from past decisions
    5. Synthesis - Combine all signals
    
    The ML model gets trained automatically and improves over time!
    """
    
    def __init__(self, config: Dict):
        """
        Initialize analyzer with configuration.
        
        Args:
            config: {
                "llm_provider": "groq" | "gemini" | "claude_haiku",
                "enable_rag_detection": True,
                "enable_ml": True,
                "min_confidence": 0.7,
                "timeout_ms": 500
            }
        """
        self.config = config
        
        # Initialize all analyzers
        self.heuristic = AgentHeuristicAnalyzer()
        self.rag = RAGAnalyzer()
        self.llm = FreeLLMAnalyzer(config.get("llm_provider", "groq"))
        
        # Initialize ML trainer (self-learning)
        self.ml_trainer = None
        if config.get("enable_ml", True):
            try:
                self.ml_trainer = MLTrainer()
                
                # Check if we have trained models
                if self.ml_trainer.model_recommender:
                    stats = self.ml_trainer.get_stats()
                    print(f"🧠 Loaded ML model (trained on {stats['total_samples']} samples)")
            except Exception as e:
                print(f"⚠️  ML trainer initialization failed: {e}")
                self.ml_trainer = None
    
    async def analyze(
        self,
        prompt: str,
        current_model: str,
        user_id: str,
        context: Optional[Dict] = None
    ) -> Optional[Recommendation]:
        """
        Main analysis function - called BEFORE API call.
        
        Runs all analyzers and synthesizes results into final recommendation.
        
        Args:
            prompt: User's prompt text
            current_model: Current model user is about to use
            user_id: Anonymized user ID
            context: User context (industry, use case, etc.)
        
        Returns:
            Recommendation object or None if no recommendation
        """
        
        start_time = datetime.now()
        
        try:
            # Timeout protection
            result = await asyncio.wait_for(
                self._analyze_internal(prompt, current_model, user_id, context),
                timeout=self.config.get("timeout_ms", 500) / 1000
            )
            
            # Add analysis time
            if result:
                elapsed = (datetime.now() - start_time).total_seconds() * 1000
                result.analysis_time_ms = int(elapsed)
            
            return result
            
        except asyncio.TimeoutError:
            print("⚠️  Analysis timeout (>500ms)")
            return None
        except Exception as e:
            print(f"⚠️  Analysis error: {e}")
            return None
    
    async def _analyze_internal(
        self,
        prompt: str,
        current_model: str,
        user_id: str,
        context: Optional[Dict]
    ) -> Optional[Recommendation]:
        """Internal analysis logic with all analyzers"""
        
        # Estimate tokens for analysis
        estimated_tokens = len(prompt) // 4
        
        # ═══════════════════════════════════════════════════════════════
        # STEP 1: HEURISTIC ANALYSIS (5ms - Fast patterns)
        # ═══════════════════════════════════════════════════════════════
        
        heuristic_result = self.heuristic.analyze(prompt, current_model)
        
        # If super confident from heuristics, return immediately
        if heuristic_result and heuristic_result.confidence >= 0.95:
            print(f"⚡ Quick match: {heuristic_result.suggested_model} ({heuristic_result.confidence:.0%})")
            return heuristic_result
        
        # ═══════════════════════════════════════════════════════════════
        # STEP 2: RAG DETECTION (3ms - Specialized for RAG)
        # ═══════════════════════════════════════════════════════════════
        
        rag_result = None
        if self.config.get("enable_rag_detection", True):
            rag_result = self.rag.analyze_rag_call(
                prompt=prompt,
                current_model=current_model,
                prompt_length=len(prompt),
                estimated_tokens=estimated_tokens
            )
        
        # If strong RAG match, prioritize it
        if rag_result and rag_result.confidence >= 0.85:
            print(f"📚 RAG detected: {rag_result.suggested_model} ({rag_result.confidence:.0%})")
            return rag_result
        
        # ═══════════════════════════════════════════════════════════════
        # STEP 3: ML MODEL PREDICTION (10ms - Learned intelligence)
        # ═══════════════════════════════════════════════════════════════
        
        ml_result = None
        if self.ml_trainer and self.ml_trainer.model_recommender:
            try:
                # Extract features for ML
                prompt_features = {
                    "length": len(prompt),
                    "word_count": len(prompt.split()),
                    "estimated_tokens": estimated_tokens,
                    "task_type": self._quick_task_classification(prompt)
                }
                
                # Get ML prediction
                ml_prediction = self.ml_trainer.predict(
                    prompt_features=prompt_features,
                    context=context or {}
                )
                
                if ml_prediction:
                    # Convert to Recommendation object
                    ml_result = self._ml_prediction_to_recommendation(
                        ml_prediction,
                        current_model,
                        estimated_tokens
                    )
                    
                    # If ML is confident, use it
                    if ml_result and ml_result.confidence >= 0.85:
                        print(f"🧠 ML model: {ml_result.suggested_model} ({ml_result.confidence:.0%})")
                        return ml_result
            
            except Exception as e:
                print(f"⚠️  ML prediction failed: {e}")
                ml_result = None
        
        # ═══════════════════════════════════════════════════════════════
        # STEP 4: LLM ANALYSIS (300ms - Deep reasoning)
        # ═══════════════════════════════════════════════════════════════
        
        llm_result = None
        if self.llm.client:
            # Give LLM context from previous analyzers
            best_hint = (
                ml_result or 
                rag_result or 
                heuristic_result
            )
            
            llm_result = self.llm.analyze(
                prompt=prompt,
                current_model=current_model,
                heuristic_hint=best_hint,
                user_context=context
            )
            
            if llm_result:
                print(f"🤖 LLM analysis: {llm_result.suggested_model} ({llm_result.confidence:.0%})")
        
        # ═══════════════════════════════════════════════════════════════
        # STEP 5: SYNTHESIZE ALL SIGNALS
        # ═══════════════════════════════════════════════════════════════
        
        final_recommendation = self._synthesize_recommendations(
            heuristic=heuristic_result,
            rag=rag_result,
            llm=llm_result,
            ml=ml_result
        )
        
        # Only return if confident enough
        min_confidence = self.config.get("min_confidence", 0.7)
        if final_recommendation and final_recommendation.confidence >= min_confidence:
            return final_recommendation
        
        return None
    
    def _quick_task_classification(self, prompt: str) -> str:
        """Quick task type classification for ML"""
        
        prompt_lower = prompt.lower()
        
        # Quick keyword matching
        if any(kw in prompt_lower for kw in ["classify", "categorize", "sentiment"]):
            return "classification"
        elif any(kw in prompt_lower for kw in ["extract", "find", "get"]):
            return "extraction"
        elif any(kw in prompt_lower for kw in ["summarize", "summary"]):
            return "summarization"
        elif len(prompt) > 1000:
            return "rag"  # Long prompts likely RAG
        else:
            return "general"
    
    def _ml_prediction_to_recommendation(
        self,
        ml_prediction: Dict,
        current_model: str,
        estimated_tokens: int
    ) -> Recommendation:
        """Convert ML prediction to Recommendation object"""
        
        from ..aioptimize_core.aioptimized.calculator import calculate_cost
        
        suggested_model = ml_prediction["suggested_model"]
        
        # Calculate costs
        current_cost = calculate_cost(current_model, estimated_tokens, estimated_tokens)
        suggested_cost = calculate_cost(suggested_model, estimated_tokens, estimated_tokens)
        
        savings = current_cost - suggested_cost
        savings_percent = int((savings / current_cost * 100)) if current_cost > 0 else 0
        
        return Recommendation(
            should_switch=True,
            current_model=current_model,
            suggested_model=suggested_model,
            confidence=ml_prediction["confidence"],
            reasoning=f"ML model recommendation (learned from real usage patterns). {ml_prediction['reasoning']}",
            quality_impact="learned",
            estimated_current_cost=current_cost,
            estimated_suggested_cost=suggested_cost,
            estimated_savings=savings,
            estimated_savings_percent=savings_percent,
            based_on="ml_model",
            analysis_time_ms=10
        )
    
    def _synthesize_recommendations(
        self,
        heuristic: Optional[Recommendation],
        rag: Optional[Recommendation],
        llm: Optional[Recommendation],
        ml: Optional[Recommendation]
    ) -> Optional[Recommendation]:
        """
        Combine multiple signals into final recommendation.
        
        Weighting strategy:
        - ML model (if available): 70% - Most reliable (learned from real data)
        - LLM analysis: 50% - Intelligent reasoning
        - RAG analyzer: 60% - Specialized, high accuracy
        - Heuristics: 30% - Simple rules
        
        If multiple sources agree, boost confidence.
        """
        
        recommendations = []
        
        # Collect all recommendations with weights
        if ml:
            recommendations.append((ml, 0.70, "ml"))
        if rag:
            recommendations.append((rag, 0.60, "rag"))
        if llm:
            recommendations.append((llm, 0.50, "llm"))
        if heuristic:
            recommendations.append((heuristic, 0.30, "heuristic"))
        
        if not recommendations:
            return None
        
        # Strategy: Use highest weighted confidence
        # Weight = source_weight × recommendation_confidence
        best = max(
            recommendations,
            key=lambda x: x[0].confidence * x[1]
        )
        best_rec, weight, source = best
        
        # Check if multiple sources agree
        suggested_models = [
            rec.suggested_model 
            for rec, _, _ in recommendations 
            if rec.suggested_model
        ]
        
        agreement_count = suggested_models.count(best_rec.suggested_model)
        
        # Boost confidence if multiple sources agree
        if agreement_count > 1:
            # Multiple sources agree - boost confidence
            boost_factor = 1.0 + (agreement_count - 1) * 0.05  # +5% per agreement
            boosted_confidence = min(0.98, best_rec.confidence * boost_factor)
            
            # List agreeing sources
            agreeing_sources = [
                src for rec, _, src in recommendations
                if rec.suggested_model == best_rec.suggested_model
            ]
            
            reasoning_suffix = f" (Confirmed by: {', '.join(agreeing_sources)})"
        else:
            boosted_confidence = best_rec.confidence
            reasoning_suffix = ""
        
        # Create final recommendation
        return Recommendation(
            should_switch=best_rec.should_switch,
            current_model=best_rec.current_model,
            suggested_model=best_rec.suggested_model,
            confidence=boosted_confidence,
            reasoning=best_rec.reasoning + reasoning_suffix,
            quality_impact=best_rec.quality_impact,
            estimated_current_cost=best_rec.estimated_current_cost,
            estimated_suggested_cost=best_rec.estimated_suggested_cost,
            estimated_savings=best_rec.estimated_savings,
            estimated_savings_percent=best_rec.estimated_savings_percent,
            based_on=f"hybrid_{source}",
            analysis_time_ms=0  # Will be set by caller
        )
    
    def get_analyzer_status(self) -> Dict:
        """Get status of all analyzers"""
        
        return {
            "heuristic": "active",
            "rag": "active" if self.config.get("enable_rag_detection") else "disabled",
            "llm": "active" if self.llm.client else "disabled (no API key)",
            "ml": "active" if self.ml_trainer and self.ml_trainer.model_recommender else "training (need more data)",
            "ml_samples": self.ml_trainer.stats["total_samples"] if self.ml_trainer else 0,
            "ml_accuracy": f"{self.ml_trainer.get_stats()['acceptance_rate']:.1%}" if self.ml_trainer and self.ml_trainer.stats["total_samples"] > 0 else "N/A"
        }