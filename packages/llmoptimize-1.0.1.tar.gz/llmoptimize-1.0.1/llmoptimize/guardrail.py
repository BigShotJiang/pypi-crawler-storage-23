"""
Guardrails - Security, privacy, and compliance protection.

Detects and blocks:
- PII (emails, phones, SSNs, credit cards)
- API keys and secrets
- Sensitive data patterns
- Budget violations
- Runaway loops
"""

import re
import hashlib
from typing import Dict, List, Optional, Tuple
from datetime import datetime, timedelta


class SecurityGuardrails:
    """
    Security checks for sensitive data in prompts.
    
    Detects:
    - Email addresses
    - Phone numbers
    - Credit card numbers
    - Social Security Numbers
    - API keys
    - IP addresses
    - AWS keys
    - Private keys
    """
    
    # Regex patterns for sensitive data
    PATTERNS = {
        "email": r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b',
        "phone": r'\b(?:\+?1[-.]?)?\(?([0-9]{3})\)?[-.]?([0-9]{3})[-.]?([0-9]{4})\b',
        "ssn": r'\b\d{3}-?\d{2}-?\d{4}\b',
        "credit_card": r'\b(?:\d{4}[-\s]?){3}\d{4}\b',
        "ip_address": r'\b(?:\d{1,3}\.){3}\d{1,3}\b',
        "api_key_generic": r'\b[A-Za-z0-9]{32,}\b',
        "openai_key": r'\bsk-[A-Za-z0-9]{48}\b',
        "anthropic_key": r'\bsk-ant-[A-Za-z0-9-]{95}\b',
        "aws_key": r'\bAKIA[0-9A-Z]{16}\b',
        "private_key": r'-----BEGIN (?:RSA |EC )?PRIVATE KEY-----'
    }
    
    def scan_prompt(self, prompt: str) -> Dict:
        """
        Scan prompt for sensitive data.
        
        Args:
            prompt: The prompt to scan
            
        Returns:
            {
                "has_issues": bool,
                "severity": "critical|high|medium|low",
                "issues": [{"type": str, "pattern": str, "location": int}],
                "redacted_prompt": str
            }
        """
        
        issues = []
        redacted_prompt = prompt
        
        for data_type, pattern in self.PATTERNS.items():
            matches = list(re.finditer(pattern, prompt))
            
            for match in matches:
                issues.append({
                    "type": data_type,
                    "pattern": match.group(0),
                    "location": match.start(),
                    "length": len(match.group(0))
                })
                
                # Redact from prompt
                redacted_prompt = redacted_prompt.replace(
                    match.group(0),
                    f"[REDACTED_{data_type.upper()}]"
                )
        
        # Determine severity
        critical_types = ["credit_card", "ssn", "openai_key", "anthropic_key", "aws_key", "private_key"]
        high_types = ["email", "phone", "api_key_generic"]
        
        has_critical = any(issue["type"] in critical_types for issue in issues)
        has_high = any(issue["type"] in high_types for issue in issues)
        
        if has_critical:
            severity = "critical"
        elif has_high:
            severity = "high"
        elif issues:
            severity = "medium"
        else:
            severity = "low"
        
        return {
            "has_issues": len(issues) > 0,
            "severity": severity,
            "issues": issues,
            "redacted_prompt": redacted_prompt,
            "recommendations": self._generate_recommendations(issues)
        }
    
    def _generate_recommendations(self, issues: List[Dict]) -> List[str]:
        """Generate security recommendations based on issues found"""
        
        recommendations = []
        
        issue_types = set(issue["type"] for issue in issues)
        
        if "email" in issue_types:
            recommendations.append("❌ Remove email addresses before sending to AI")
        
        if "phone" in issue_types:
            recommendations.append("❌ Remove phone numbers before sending to AI")
        
        if any(t in issue_types for t in ["credit_card", "ssn"]):
            recommendations.append("🚨 CRITICAL: Never send payment/identity info to AI APIs")
        
        if any(t in issue_types for t in ["openai_key", "anthropic_key", "aws_key", "api_key_generic"]):
            recommendations.append("🚨 CRITICAL: API keys detected - NEVER send keys to AI")
        
        if "private_key" in issue_types:
            recommendations.append("🚨 CRITICAL: Private cryptographic keys detected - STOP IMMEDIATELY")
        
        return recommendations


class CostGuardrails:
    """
    Budget and cost protection guardrails.
    
    Prevents:
    - Budget overruns
    - Runaway loops
    - Expensive calls for simple tasks
    """
    
    def __init__(
        self,
        daily_budget: Optional[float] = None,
        monthly_budget: Optional[float] = None
    ):
        self.daily_budget = daily_budget
        self.monthly_budget = monthly_budget
        self.daily_spend = {}
        self.monthly_spend = {}
    
    def check_budget(
        self,
        estimated_cost: float,
        call_history: List[Dict]
    ) -> Dict:
        """
        Check if call would exceed budget.
        
        Returns:
            {
                "should_proceed": bool,
                "reason": str,
                "current_daily_spend": float,
                "current_monthly_spend": float
            }
        """
        
        # Calculate current spend
        today = datetime.now().date()
        current_month = datetime.now().strftime("%Y-%m")
        
        daily_spend = sum(
            call["cost"] for call in call_history
            if datetime.fromisoformat(call["timestamp"]).date() == today
        )
        
        monthly_spend = sum(
            call["cost"] for call in call_history
            if datetime.fromisoformat(call["timestamp"]).strftime("%Y-%m") == current_month
        )
        
        # Check daily budget
        if self.daily_budget:
            if daily_spend + estimated_cost > self.daily_budget:
                return {
                    "should_proceed": False,
                    "reason": f"Would exceed daily budget of ${self.daily_budget:.2f}",
                    "current_daily_spend": daily_spend,
                    "remaining_daily": self.daily_budget - daily_spend
                }
        
        # Check monthly budget
        if self.monthly_budget:
            if monthly_spend + estimated_cost > self.monthly_budget:
                return {
                    "should_proceed": False,
                    "reason": f"Would exceed monthly budget of ${self.monthly_budget:.2f}",
                    "current_monthly_spend": monthly_spend,
                    "remaining_monthly": self.monthly_budget - monthly_spend
                }
        
        return {
            "should_proceed": True,
            "current_daily_spend": daily_spend,
            "current_monthly_spend": monthly_spend
        }
    
    def detect_runaway_loop(self, call_history: List[Dict]) -> Dict:
        """
        Detect if calls are being made in a runaway loop.
        
        Returns:
            {
                "is_runaway": bool,
                "calls_per_minute": float,
                "recommendation": str
            }
        """
        
        if len(call_history) < 10:
            return {"is_runaway": False}
        
        # Check last 5 minutes
        now = datetime.now()
        five_min_ago = now - timedelta(minutes=5)
        
        recent_calls = [
            call for call in call_history[-100:]
            if datetime.fromisoformat(call["timestamp"]) > five_min_ago
        ]
        
        if len(recent_calls) > 100:
            return {
                "is_runaway": True,
                "calls_per_minute": len(recent_calls) / 5,
                "recommendation": "⚠️ Detected >100 calls in 5 minutes - possible runaway loop!"
            }
        
        return {"is_runaway": False}


class ComplianceGuardrails:
    """
    Compliance and regulatory checks.
    
    - GDPR compliance
    - Data retention policies
    - Audit logging
    """
    
    def check_gdpr_compliance(self, user_context: Dict) -> Dict:
        """Check GDPR compliance requirements"""
        
        issues = []
        
        # Check if processing EU user data
        if user_context.get("region") in ["EU", "UK", "EEA"]:
            if not user_context.get("gdpr_consent"):
                issues.append("Missing GDPR consent for EU user")
            
            if not user_context.get("data_retention_policy"):
                issues.append("No data retention policy specified")
        
        return {
            "compliant": len(issues) == 0,
            "issues": issues
        }


class GuardrailManager:
    """
    Coordinates all guardrails.
    """
    
    def __init__(
        self,
        daily_budget: Optional[float] = None,
        monthly_budget: Optional[float] = None
    ):
        self.security = SecurityGuardrails()
        self.cost = CostGuardrails(daily_budget, monthly_budget)
        self.compliance = ComplianceGuardrails()
    
    def check_before_call(
        self,
        prompt: str,
        model: str,
        estimated_cost: float,
        estimated_tokens: int,
        call_history: List[Dict],
        user_context: Optional[Dict] = None
    ) -> Dict:
        """
        Run all pre-call checks.
        
        Returns:
            {
                "should_proceed": bool,
                "severity": "critical|high|medium|low",
                "security_issues": [],
                "cost_issues": [],
                "compliance_issues": []
            }
        """
        
        result = {
            "should_proceed": True,
            "severity": "low",
            "security_issues": [],
            "cost_issues": [],
            "compliance_issues": [],
            "warnings": []
        }
        
        # Security check
        security_result = self.security.scan_prompt(prompt)
        if security_result["has_issues"]:
            result["security_issues"] = security_result["issues"]
            result["severity"] = security_result["severity"]
            
            if security_result["severity"] == "critical":
                result["should_proceed"] = False
                result["warnings"].append(
                    "🚨 BLOCKED: Critical security issues detected"
                )
        
        # Cost check
        budget_result = self.cost.check_budget(estimated_cost, call_history)
        if not budget_result["should_proceed"]:
            result["should_proceed"] = False
            result["cost_issues"].append(budget_result["reason"])
            result["warnings"].append(
                f"❌ BLOCKED: {budget_result['reason']}"
            )
        
        # Runaway loop check
        loop_result = self.cost.detect_runaway_loop(call_history)
        if loop_result.get("is_runaway"):
            result["should_proceed"] = False
            result["cost_issues"].append(loop_result["recommendation"])
            result["warnings"].append(
                "🚨 BLOCKED: Runaway loop detected"
            )
        
        # Compliance check
        if user_context:
            compliance_result = self.compliance.check_gdpr_compliance(user_context)
            if not compliance_result["compliant"]:
                result["compliance_issues"] = compliance_result["issues"]
                result["warnings"].extend([
                    f"⚠️ {issue}" for issue in compliance_result["issues"]
                ])
        
        return result
    
    def format_guardrail_report(self, result: Dict) -> str:
        """Format guardrail results for display"""
        
        output = []
        
        if result["severity"] in ["critical", "high"]:
            output.append("\n" + "🚨" * 35)
            output.append("⚠️  GUARDRAIL ALERT")
            output.append("🚨" * 35)
        
        if result["security_issues"]:
            output.append("\n🔒 SECURITY ISSUES:")
            for issue in result["security_issues"]:
                output.append(f"   • {issue['type'].upper()} detected at position {issue['location']}")
        
        if result["cost_issues"]:
            output.append("\n💰 COST ISSUES:")
            for issue in result["cost_issues"]:
                output.append(f"   • {issue}")
        
        if result["compliance_issues"]:
            output.append("\n📋 COMPLIANCE ISSUES:")
            for issue in result["compliance_issues"]:
                output.append(f"   • {issue}")
        
        if result["warnings"]:
            output.append("\n" + "─" * 70)
            for warning in result["warnings"]:
                output.append(warning)
            output.append("─" * 70)
        
        return "\n".join(output)