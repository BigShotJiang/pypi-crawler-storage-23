"""
Groq Auditor - AI-powered code auditor using Groq models.

Uses smart model selection to pick cheapest Groq model for auditing.
Falls back gracefully if rate limited (free tier).
"""

import os
import re
import json
from typing import Dict, Optional
from .aiauditor import AIAuditor
from .groq_model_selector import GroqModelSelector
from .cache_manager import get_pattern_cache


class GroqAuditor:
    """
    Code auditor powered by Groq with adaptive model selection.

    Features:
    - Smart model selection (saves 84%)
    - Free tier support with graceful fallback
    - Caching for repeat audits
    - Detailed cost tracking

    Usage:
        auditor = GroqAuditor()
        report = auditor.audit_code(my_code)
    """

    def __init__(
        self,
        force_model: Optional[str] = None,
        enable_cache: bool = True
    ):
        """
        Initialize Groq auditor.

        Args:
            force_model: Force specific Groq model ID (or auto-select)
            enable_cache: Cache audit results
        """
        self.force_model = force_model
        self.enable_cache = enable_cache

        # Core auditor (handles caching + rule scanning)
        self.ai_auditor = AIAuditor(
            ai_provider="groq",
            enable_cache=enable_cache,
            enable_ai=True
        )

        # Smart model selector
        self.selector = GroqModelSelector(
            enable_ai=True,
            enable_cache=enable_cache,
            ai_provider="groq"
        )

        # Cache
        self.cache = get_pattern_cache() if enable_cache else None
        self.cache_namespace = "groq_auditor"

        # Stats
        self.total_audits = 0
        self.total_cost = 0.0
        self.model_usage = {}
        self.free_tier_hits = 0
        self.rate_limit_errors = 0

        # Groq client (lazy loaded)
        self._client = None

    @property
    def client(self):
        """Lazy load Groq client"""
        if self._client is None:
            try:
                from groq import Groq
                self._client = Groq(api_key=os.getenv("GROQ_API_KEY"))
            except Exception as e:
                print(f"⚠️  Groq client init failed: {e}")
        return self._client

    def audit_code(
        self,
        code: str,
        filename: Optional[str] = None,
        force_refresh: bool = False,
        explain_selection: bool = True
    ) -> Dict:
        """
        Audit code using Groq with smart model selection.

        Args:
            code: Python code to analyze
            filename: Optional filename for context
            force_refresh: Skip cache
            explain_selection: Show which model was selected and why

        Returns:
            Complete audit report
        """

        self.total_audits += 1

        # Select optimal model
        if self.force_model:
            model_id = self.force_model
            complexity = "forced"
        else:
            model_id, complexity, model_info = self.selector.select_model(
                code=code,
                explain=explain_selection
            )

        # Track model usage
        self.model_usage[model_id] = self.model_usage.get(model_id, 0) + 1

        # Use core auditor (handles cache + rules + AI)
        # Override the AI client to use selected Groq model
        try:
            report = self._groq_audit(
                code=code,
                filename=filename,
                model_id=model_id,
                complexity=complexity,
                force_refresh=force_refresh
            )

            # Calculate actual cost
            actual_cost = self.selector.estimate_cost(code, model_id)
            self.total_cost += actual_cost

            report["groq_metadata"] = {
                "model_used": model_id,
                "complexity": complexity,
                "actual_cost": actual_cost,
                "is_free_tier": actual_cost == 0.0
            }

            return report

        except Exception as e:
            error_msg = str(e).lower()

            # Handle rate limiting (free tier)
            if "rate limit" in error_msg or "429" in error_msg:
                self.rate_limit_errors += 1
                print(f"\n⚠️  Groq rate limit hit - using rule-based analysis")
                print(f"   Free tier limit reached. Upgrade at console.groq.com")

                # Fall back to rule-based only
                return self.ai_auditor._build_report(
                    code=code,
                    filename=filename,
                    rule_findings=self.ai_auditor._rule_based_scan(code),
                    ai_findings=None,
                    analysis_method="rule_based_fallback"
                )

            raise

    def _groq_audit(
        self,
        code: str,
        filename: Optional[str],
        model_id: str,
        complexity: str,
        force_refresh: bool
    ) -> Dict:
        """Run Groq-specific audit"""

        if not self.client:
            raise ValueError("Groq client not initialized. Set GROQ_API_KEY.")

        # Rule scan first (always fast + free)
        rule_findings = self.ai_auditor._rule_based_scan(code)

        # Build prompt
        system_prompt = """You are an expert AI cost optimization consultant.

Analyze Python code that uses AI APIs and identify cost optimization opportunities.

For each API call found:
1. Identify what the code is ACTUALLY doing (the task)
2. Assess if the current model is appropriate
3. Recommend the cheapest model that maintains quality
4. Estimate savings percentage

Respond ONLY in valid JSON:
{
  "issues": [
    {
      "line_number": <number>,
      "current_model": "<model name>",
      "step_type": "planning|tool_call|parsing|synthesis|formatting|verification",
      "reasoning": "<why this model is or isn't appropriate>",
      "recommended_model": "<cheaper alternative or same if justified>",
      "savings_percent": <0-100>,
      "quality_impact": "none|minimal|moderate|significant",
      "confidence": <0.0-1.0>
    }
  ],
  "optimized_code": "<full code with model changes applied>",
  "overall_recommendation": "<key findings summary>"
}"""

        models_found = rule_findings.get("models_found", [])
        user_prompt = f"""Analyze this code for AI cost optimization:

FILE: {filename or 'unnamed.py'}
COMPLEXITY: {complexity}
MODELS FOUND: {', '.join(models_found) if models_found else 'scanning...'}

CODE:
```python
{code[:2500]}
```

Find all optimization opportunities and provide JSON response."""

        # Call Groq
        response = self.client.chat.completions.create(
            model=model_id,
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt}
            ],
            temperature=0.2,
            max_tokens=2000
        )

        raw = response.choices[0].message.content

        # Parse AI response
        ai_findings = None
        try:
            json_match = re.search(r'\{.*\}', raw, re.DOTALL)
            if json_match:
                ai_findings = json.loads(json_match.group(0))
        except Exception:
            pass

        # Build report
        return self.ai_auditor._build_report(
            code=code,
            filename=filename,
            rule_findings=rule_findings,
            ai_findings=ai_findings,
            analysis_method=f"groq_{model_id.split('/')[-1]}"
        )

    def get_stats(self) -> Dict:
        """Get auditor statistics"""

        return {
            "total_audits": self.total_audits,
            "total_cost": f"${self.total_cost:.4f}",
            "avg_cost_per_audit": f"${self.total_cost/self.total_audits:.6f}" if self.total_audits > 0 else "$0",
            "model_usage": self.model_usage,
            "rate_limit_errors": self.rate_limit_errors,
            "free_tier_status": "OK" if self.rate_limit_errors == 0 else f"{self.rate_limit_errors} limits hit"
        }

    def print_stats(self):
        """Print formatted statistics"""
        stats = self.get_stats()
        print("\n" + "="*70)
        print("📊 GROQ AUDITOR STATISTICS")
        print("="*70)
        print(f"Total Audits:        {stats['total_audits']}")
        print(f"Total Cost:          {stats['total_cost']}")
        print(f"Avg Cost/Audit:      {stats['avg_cost_per_audit']}")
        print(f"Rate Limit Errors:   {stats['rate_limit_errors']}")
        print(f"\nModel Usage:")
        for model, count in stats['model_usage'].items():
            pct = (count / self.total_audits * 100) if self.total_audits > 0 else 0
            print(f"  {model:35} {count:3} ({pct:.0f}%)")
        print("="*70 + "\n")