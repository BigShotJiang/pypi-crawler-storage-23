"""
data_collector.py - Classifies API calls locally and batches for server.

What it does:
1. Receives every intercepted call from magic.py
2. Classifies prompt LOCALLY (category + complexity)
3. Stores in local batch
4. Every 10 calls → sends batch to server via cloud_sync.py

Privacy:
- Prompt TEXT is classified locally, never sent
- Only the CATEGORY LABEL is sent to server
- User can disable with: aioptimize.configure(share_data=False)
"""

import os
import re
from typing import Dict, List, Optional, Tuple
from datetime import datetime


# ═══════════════════════════════════════════════════════════════════════════
# LOCAL PROMPT CLASSIFIER
# Runs on user's machine — prompt text never leaves here
# ═══════════════════════════════════════════════════════════════════════════

# Category keyword patterns
_CATEGORY_PATTERNS = {
    "json_formatting": [
        r"\bjson\b", r"\bformat\b.*\bdata\b", r"\bparse\b.*\bjson\b",
        r"\bconvert\b.*\bjson\b", r"\bstructured\b.*\boutput\b"
    ],
    "code_generation": [
        r"\bwrite\b.*\bcode\b", r"\bgenerate\b.*\bfunction\b",
        r"\bcreate\b.*\bscript\b", r"\bimplement\b", r"\bcode\b.*\bthat\b",
        r"\bfunction\b.*\bthat\b", r"\bpython\b.*\bfunction\b", r"\bwrite\b.*\bfunction\b",
        r"\bscript\b", r"\bprogram\b.*\bthat\b", r"\bfunction\b.*\bsort"
    ],
    "code_review": [
        r"\breview\b.*\bcode\b", r"\bcheck\b.*\bcode\b", r"\bbug\b",
        r"\bfix\b.*\bcode\b", r"\bdebug\b", r"\boptimize\b.*\bcode\b"
    ],
    "summarization": [
        r"\bsummariz\b", r"\bsummar\b", r"\btldr\b", r"\bbrief\b",
        r"\bcondense\b", r"\bshorten\b", r"\bkey\b.*\bpoints\b",
        r"\bsummary\b", r"\bdocument\b.*\bbrief", r"\bthis\b.*\bdocument\b"
    ],
    "translation": [
        r"\btranslat\b", r"\bin\b.*\blanguage\b", r"\bfrench\b",
        r"\bspanish\b", r"\bgerman\b", r"\bchinese\b", r"\bjapanese\b"
    ],
    "question_answering": [
        r"\bwhat\s+is\b", r"\bwho\s+is\b", r"\bhow\s+does\b",
        r"\bwhy\s+does\b", r"\bexplain\b", r"\btell\s+me\b"
    ],
    "creative_writing": [
        r"\bwrite\b.*\bstory\b", r"\bpoem\b", r"\bcreative\b",
        r"\bfiction\b", r"\bnarrative\b", r"\bblog\b.*\bpost\b"
    ],
    "data_extraction": [
        r"\bextract\b", r"\bpull\b.*\bdata\b", r"\bfind\b.*\bin\b.*\btext\b",
        r"\bidentify\b.*\bfrom\b", r"\blist\b.*\ball\b"
      ],
    "classification": [
        r"\bclassif\b", r"\bcategor\b", r"\blabel\b", r"\bclassify\b", r"\binto\b.*\bcategor\b",
        r"\bsort\b.*\binto\b", r"\bwhich\b.*\bcategory\b"
    ],
    "reasoning": [
        r"\banalyze\b", r"\banalysis\b", r"\bthink\b.*\bthrough\b",
        r"\bstep\b.*\bby\b.*\bstep\b", r"\breason\b", r"\bsolve\b"
    ],
    "planning": [
        r"\bplan\b", r"\bstrateg\b", r"\bsteps\b.*\bto\b",
        r"\bhow\b.*\bshould\b.*\bi\b", r"\bapproach\b"
    ],
    "formatting": [
        r"\bformat\b", r"\breformat\b", r"\bstructure\b.*\bthis\b",
        r"\bmake\b.*\breadable\b", r"\bclean\b.*\bup\b"
    ],
}

# Complexity indicators
_COMPLEX_INDICATORS = [
    r"\bstep\b.*\bby\b.*\bstep\b", r"\bmultiple\b", r"\bcomplex\b",
    r"\badvanced\b", r"\bdetailed\b.*\banalysis\b", r"\bcomprehensive\b",
    r"\bconsider\b.*\ball\b", r"\bpros\b.*\bcons\b"
]

_SIMPLE_INDICATORS = [
    r"\bsimple\b", r"\bquick\b", r"\bjust\b", r"\bonly\b",
    r"\bbasic\b", r"\bone\b.*\bsentence\b", r"\bbriefly\b"
]


def classify_prompt(prompt_text: str) -> Tuple[str, str]:
    """
    Classify a prompt LOCALLY into category + complexity.

    Args:
        prompt_text: The actual prompt (stays on user's machine!)

    Returns:
        (category, complexity)  ← only these labels are sent to server
    """

    text = prompt_text.lower()

    # ── Category ────────────────────────────────────────────────────────
    category    = "unknown"
    best_score  = 0

    for cat, patterns in _CATEGORY_PATTERNS.items():
        score = sum(1 for p in patterns if re.search(p, text))
        if score > best_score:
            best_score = score
            category   = cat

    # ── Complexity ───────────────────────────────────────────────────────
    complex_score = sum(1 for p in _COMPLEX_INDICATORS if re.search(p, text))
    simple_score  = sum(1 for p in _SIMPLE_INDICATORS  if re.search(p, text))

    token_estimate = len(prompt_text) // 4

    if complex_score >= 2 or token_estimate > 1000:
        complexity = "complex"
    elif simple_score >= 2 or token_estimate < 100:
        complexity = "simple"
    else:
        complexity = "medium"

    return category, complexity


# ═══════════════════════════════════════════════════════════════════════════
# DATA COLLECTOR
# ═══════════════════════════════════════════════════════════════════════════

class CloudSyncCollector:
    """
    Collects anonymized API call data and batches it for the server.

    Flow:
      call intercepted → classify locally → add to batch
      batch reaches 10 → send to server → clear batch
    """

    def __init__(
        self,
        batch_size:  int  = 10,
        share_data:  bool = True,
        session_id:  str  = None,
        sdk_version: str  = "1.0.0",
    ):
        self.batch_size  = batch_size
        self.share_data  = share_data
        self.sdk_version = sdk_version
        self.batch:      List[Dict] = []
        self.total_sent  = 0
        self.total_failed= 0

        # Load or generate anonymous session ID
        self.session_id  = session_id or self._load_session_id()

        # Lazy cloud sync
        self._sync = None

    def _load_session_id(self) -> str:
        """Load or generate anonymous session ID (persists across runs)"""
        import json
        import uuid

        try:
            usage_file = os.path.expanduser("~/.aioptimize/usage.json")
            if os.path.exists(usage_file):
                with open(usage_file) as f:
                    data = json.load(f)
                    if "session_id" in data:
                        return data["session_id"]
        except Exception:
            pass

        # Generate new anonymous ID
        new_id = str(uuid.uuid4())

        try:
            usage_dir  = os.path.expanduser("~/.aioptimize")
            usage_file = os.path.join(usage_dir, "usage.json")
            os.makedirs(usage_dir, exist_ok=True)

            data = {}
            if os.path.exists(usage_file):
                with open(usage_file) as f:
                    data = json.load(f)

            data["session_id"] = new_id

            with open(usage_file, "w") as f:
                json.dump(data, f, indent=2)

        except Exception:
            pass

        return new_id

    @property
    def sync(self):
        """Lazy load cloud sync"""
        if self._sync is None:
            from .cloud_sync import CloudSync
            self._sync = CloudSync()
        return self._sync

    def collect(
        self,
        provider:          str,
        model_used:        str,
        prompt_text:       str,
        prompt_length:     int,
        token_count:       int,
        cost_usd:          float,
        our_recommendation:Optional[str],
        user_accepted:     Optional[bool],
        savings_percent:   Optional[float],
        timestamp:         str,
        is_licensed:       bool = False,
    ):
        """
        Collect one API call.

        Classifies prompt locally → adds anonymized data to batch.
        Sends batch when it reaches batch_size.
        """

        if not self.share_data:
            return

        # Classify LOCALLY — text never sent to server
        category, complexity = classify_prompt(prompt_text)

        # Build anonymized record
        record = {
            "provider":           provider,
            "model_used":         model_used,
            "prompt_category":    category,      # ← label only
            "prompt_complexity":  complexity,    # ← label only
            "prompt_length":      prompt_length, # ← number only
            "token_count":        token_count,
            "cost_usd":           round(cost_usd, 8),
            "our_recommendation": our_recommendation,
            "user_accepted":      user_accepted,
            "savings_percent":    savings_percent,
            "timestamp":          timestamp,
            # Prompt text is NOT included — stays on user's machine
        }

        self.batch.append(record)

        # Send when batch is full
        if len(self.batch) >= self.batch_size:
            self._flush(is_licensed=is_licensed)

    def _flush(self, is_licensed: bool = False):
        """Send current batch to server and clear it"""
        if not self.batch:
            return

        batch_to_send = self.batch.copy()
        self.batch.clear()

        try:
            success = self.sync.send_batch(
                session_id  = self.session_id,
                sdk_version = self.sdk_version,
                is_licensed = is_licensed,
                calls       = batch_to_send,
            )

            if success:
                self.total_sent += len(batch_to_send)
            else:
                self.total_failed += len(batch_to_send)

        except Exception:
            # Never crash user code
            self.total_failed += len(batch_to_send)

    def flush_now(self, is_licensed: bool = False):
        """Force send remaining batch (called at script end)"""
        self._flush(is_licensed=is_licensed)

    def get_stats(self) -> Dict:
        return {
            "session_id":    self.session_id[:8] + "...",
            "batch_pending": len(self.batch),
            "total_sent":    self.total_sent,
            "total_failed":  self.total_failed,
            "share_data":    self.share_data,
        }


# ── Global singleton ──────────────────────────────────────────────────────
_cloud_collector: Optional[CloudSyncCollector] = None


def get_collector() -> CloudSyncCollector:
    global _collector
    if _collector is None:
        _cloud_collector = CloudSyncCollector(
            share_data = os.getenv("AIOPTIMIZE_SHARE_DATA", "true").lower() != "false"
        )
    return _collector