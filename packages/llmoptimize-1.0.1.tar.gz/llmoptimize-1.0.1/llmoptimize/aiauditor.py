"""
AI Auditor - AI-powered code auditing with hybrid approach and caching.

Analyzes Python code BEFORE running to identify:
- Which models are being used
- Which models are overkill
- How much you could save
- What quality impact to expect

Features:
1. Rule-based detection (fast, free, always runs)
2. AI-powered analysis (smart, accurate, Groq/Claude)
3. Pattern caching (learns from previous audits)
4. Detailed recommendations with code fixes
5. Post-audit analysis report

Flow:
1. Check cache (same code seen before? FREE!)
2. Rule-based scan (find API calls instantly)
3. AI analysis (deep understanding of code intent)
4. Cache result + return report
"""

import os
import re
import hashlib
import json
from typing import Dict, List, Optional, Tuple
from datetime import datetime
from .cache_manager import get_pattern_cache


class AIAuditor:
    """
    AI-powered code auditor with caching and hybrid analysis.

    Analyzes code BEFORE you run it to find cost savings.

    Usage:
        auditor = AIAuditor()
        report = auditor.audit_code(my_code)
        print(report['summary'])
    """

    # Model cost lookup (per 1K tokens, input/output)
    # ── Chat / Completion Models ─────────────────────────────────────────
    MODEL_COSTS = {
        # OpenAI
        "gpt-4":                        {"input": 0.03,      "output": 0.06},
        "gpt-4-32k":                    {"input": 0.06,      "output": 0.12},
        "gpt-4-turbo":                  {"input": 0.01,      "output": 0.03},
        "gpt-4-turbo-preview":          {"input": 0.01,      "output": 0.03},
        "gpt-4o":                       {"input": 0.005,     "output": 0.015},
        "gpt-4o-2024-11-20":            {"input": 0.0025,    "output": 0.01},
        "gpt-4o-mini":                  {"input": 0.00015,   "output": 0.0006},
        "gpt-3.5-turbo":                {"input": 0.0005,    "output": 0.0015},
        "gpt-3.5-turbo-16k":            {"input": 0.003,     "output": 0.004},
        "o1":                           {"input": 0.015,     "output": 0.06},
        "o1-preview":                   {"input": 0.015,     "output": 0.06},
        "o1-mini":                      {"input": 0.003,     "output": 0.012},
        "o3-mini":                      {"input": 0.0011,    "output": 0.0044},
        # Anthropic
        "claude-3-opus":                {"input": 0.015,     "output": 0.075},
        "claude-3-opus-20240229":       {"input": 0.015,     "output": 0.075},
        "claude-3-sonnet":              {"input": 0.003,     "output": 0.015},
        "claude-3-sonnet-20240229":     {"input": 0.003,     "output": 0.015},
        "claude-3-haiku":               {"input": 0.00025,   "output": 0.00125},
        "claude-3-haiku-20240307":      {"input": 0.00025,   "output": 0.00125},
        "claude-3-5-sonnet":            {"input": 0.003,     "output": 0.015},
        "claude-3-5-sonnet-20241022":   {"input": 0.003,     "output": 0.015},
        "claude-3-5-haiku":             {"input": 0.0008,    "output": 0.004},
        "claude-3-5-haiku-20241022":    {"input": 0.0008,    "output": 0.004},
        # Google Gemini
        "gemini-1.5-pro":               {"input": 0.00125,   "output": 0.005},
        "gemini-1.5-pro-002":           {"input": 0.00125,   "output": 0.005},
        "gemini-1.5-flash":             {"input": 0.000075,  "output": 0.0003},
        "gemini-1.5-flash-002":         {"input": 0.000075,  "output": 0.0003},
        "gemini-1.5-flash-8b":          {"input": 0.0000375, "output": 0.00015},
        "gemini-2.0-flash":             {"input": 0.0001,    "output": 0.0004},
        "gemini-2.0-flash-lite":        {"input": 0.000075,  "output": 0.0003},
        "gemini-2.0-pro":               {"input": 0.00125,   "output": 0.005},
        # Groq
        "llama-3.3-70b-versatile":      {"input": 0.00059,   "output": 0.00079},
        "llama-3.1-70b-versatile":      {"input": 0.00059,   "output": 0.00079},
        "llama-3.1-8b-instant":         {"input": 0.00005,   "output": 0.00008},
        "llama-3.2-90b-vision":         {"input": 0.00090,   "output": 0.00090},
        "llama-3.2-11b-vision":         {"input": 0.00018,   "output": 0.00018},
        "mixtral-8x7b-32768":           {"input": 0.00024,   "output": 0.00024},
        "gemma2-9b-it":                 {"input": 0.00020,   "output": 0.00020},
        # Mistral
        "mistral-large":                {"input": 0.003,     "output": 0.009},
        "mistral-large-2407":           {"input": 0.003,     "output": 0.009},
        "mistral-small":                {"input": 0.001,     "output": 0.003},
        "mistral-small-2409":           {"input": 0.001,     "output": 0.003},
        "mistral-nemo":                 {"input": 0.00015,   "output": 0.00015},
        "codestral":                    {"input": 0.001,     "output": 0.003},
        "open-mixtral-8x22b":           {"input": 0.002,     "output": 0.006},
        "open-mixtral-8x7b":            {"input": 0.00065,   "output": 0.00065},
        "open-mistral-7b":              {"input": 0.00025,   "output": 0.00025},
        # Cohere
        "command-r-plus":               {"input": 0.003,     "output": 0.015},
        "command-r-plus-08-2024":       {"input": 0.003,     "output": 0.015},
        "command-r":                    {"input": 0.00015,   "output": 0.0006},
        "command-r-08-2024":            {"input": 0.00015,   "output": 0.0006},
        "command":                      {"input": 0.001,     "output": 0.002},
        "command-light":                {"input": 0.0003,    "output": 0.0006},
    }

    # ── Embedding Models (input only — no output tokens) ─────────────────
    EMBEDDING_COSTS = {
        # OpenAI
        "text-embedding-3-large":        {"input": 0.00013,  "output": 0.0},
        "text-embedding-3-small":        {"input": 0.00002,  "output": 0.0},
        "text-embedding-ada-002":        {"input": 0.0001,   "output": 0.0},
        # Cohere
        "embed-english-v3.0":            {"input": 0.0001,   "output": 0.0},
        "embed-multilingual-v3.0":       {"input": 0.0001,   "output": 0.0},
        "embed-english-light-v3.0":      {"input": 0.00001,  "output": 0.0},
        "embed-multilingual-light-v3.0": {"input": 0.00001,  "output": 0.0},
        # Google
        "text-embedding-004":            {"input": 0.000025, "output": 0.0},
        "embedding-001":                 {"input": 0.0001,   "output": 0.0},
        # Mistral
        "mistral-embed":                 {"input": 0.0001,   "output": 0.0},
    }

    # ── Cheaper chat model alternatives ──────────────────────────────────
    MODEL_ALTERNATIVES = {
        # OpenAI
        "gpt-4":                    ["gpt-4o", "gpt-4o-mini", "gpt-3.5-turbo",     "claude-3-haiku"],
        "gpt-4-32k":                ["gpt-4-turbo", "gpt-4o", "claude-3-sonnet"],
        "gpt-4-turbo":              ["gpt-4o", "gpt-4o-mini", "gpt-3.5-turbo"],
        "gpt-4-turbo-preview":      ["gpt-4o", "gpt-4o-mini", "gpt-3.5-turbo"],
        "gpt-4o":                   ["gpt-4o-mini", "gpt-3.5-turbo",               "gemini-1.5-flash"],
        "gpt-3.5-turbo":            ["gpt-4o-mini", "gemini-1.5-flash",            "claude-3-haiku"],
        "gpt-3.5-turbo-16k":        ["gpt-4o-mini", "gemini-1.5-flash"],
        "o1":                       ["o1-mini", "o3-mini", "gpt-4o"],
        "o1-preview":               ["o1-mini", "o3-mini", "gpt-4o"],
        # Anthropic
        "claude-3-opus":            ["claude-3-5-sonnet", "claude-3-sonnet",        "claude-3-haiku"],
        "claude-3-opus-20240229":   ["claude-3-5-sonnet", "claude-3-sonnet",        "claude-3-haiku"],
        "claude-3-sonnet":          ["claude-3-5-haiku",  "claude-3-haiku",         "gpt-4o-mini"],
        "claude-3-sonnet-20240229": ["claude-3-5-haiku",  "claude-3-haiku",         "gpt-4o-mini"],
        "claude-3-5-sonnet":        ["claude-3-5-haiku",  "claude-3-haiku",         "gpt-4o-mini"],
        "claude-3-5-sonnet-20241022":["claude-3-5-haiku", "claude-3-haiku",         "gpt-4o-mini"],
        # Google
        "gemini-1.5-pro":           ["gemini-1.5-flash",  "gemini-1.5-flash-8b",   "gpt-4o-mini"],
        "gemini-1.5-pro-002":       ["gemini-1.5-flash-002", "gemini-1.5-flash-8b"],
        "gemini-2.0-pro":           ["gemini-2.0-flash",  "gemini-1.5-flash",       "gpt-4o-mini"],
        "gemini-2.0-flash":         ["gemini-2.0-flash-lite", "gemini-1.5-flash-8b"],
        "gemini-1.5-flash":         ["gemini-1.5-flash-8b", "gemini-2.0-flash-lite"],
        # Mistral
        "mistral-large":            ["mistral-small", "mistral-nemo",               "open-mistral-7b"],
        "mistral-large-2407":       ["mistral-small-2409", "mistral-nemo",          "open-mistral-7b"],
        "open-mixtral-8x22b":       ["open-mixtral-8x7b", "mistral-small",          "mistral-nemo"],
        "open-mixtral-8x7b":        ["open-mistral-7b", "mistral-nemo",             "gemma2-9b-it"],
        # Cohere
        "command-r-plus":           ["command-r", "command-light",                  "gpt-4o-mini"],
        "command-r-plus-08-2024":   ["command-r-08-2024", "command-light"],
        "command":                  ["command-light", "command-r"],
    }

    # ── Cheaper embedding alternatives ────────────────────────────────────
    EMBEDDING_ALTERNATIVES = {
        "text-embedding-ada-002":        ["text-embedding-3-small", "embed-english-light-v3.0"],
        "text-embedding-3-large":        ["text-embedding-3-small", "embed-english-v3.0"],
        "embed-english-v3.0":            ["embed-english-light-v3.0", "text-embedding-3-small"],
        "embed-multilingual-v3.0":       ["embed-multilingual-light-v3.0", "text-embedding-3-small"],
        "embedding-001":                 ["text-embedding-004", "text-embedding-3-small"],
        "mistral-embed":                 ["text-embedding-3-small", "embed-english-light-v3.0"],
    }

    def __init__(
        self,
        enable_cache: bool = True,
        enable_ai: bool = True
    ):
        """
        Initialize AI auditor.

        Args:
            enable_cache: Cache audit results
            enable_ai: Use AI for deep analysis (calls YOUR backend)
        """
        self.enable_cache = enable_cache
        self.enable_ai = enable_ai
        
        # Server URL
        self.server_url = os.getenv(
            "AIOPTIMIZE_SERVER_URL",
            "https://aioptimize.up.railway.app"  # YOUR production URL
        )

        # Cache
        self.cache = get_pattern_cache() if enable_cache else None
        self.cache_namespace = "ai_auditor"

        # Stats
        self.total_audits = 0
        self.cache_hits = 0
        self.ai_audits = 0
        self.rule_audits = 0
        self.total_cost = 0.0
        self.total_savings_found = 0.0

    def _can_use_ai(self) -> bool:
        """Check if AI analysis is available (through YOUR server)"""
        return self.enable_ai

    # ═══════════════════════════════════════════════════════════════════════
    # MAIN AUDIT METHOD
    # ═══════════════════════════════════════════════════════════════════════

    def audit_code(
        self,
        code: str,
        filename: Optional[str] = None,
        force_refresh: bool = False
    ) -> Dict:
        """
        Audit code for AI cost optimization opportunities.

        Flow:
        1. Check cache (same code before? Return instantly FREE!)
        2. Rule-based scan (find all API calls)
        3. AI analysis (understand code intent)
        4. Cache + return report

        Args:
            code: Python code to analyze
            filename: Optional filename for context
            force_refresh: Skip cache, always re-analyze

        Returns:
            Complete audit report with recommendations
        """

        self.total_audits += 1

        # ════════════════════════════
        # STEP 1: Check cache (FREE)
        # ════════════════════════════

        if self.cache and not force_refresh:
            cache_key = self._generate_cache_key(code)
            cached = self.cache.get(self.cache_namespace, cache_key)

            if cached:
                self.cache_hits += 1
                cached["from_cache"] = True
                cached["cache_age_hours"] = self._calculate_cache_age(cached.get("timestamp", ""))
                return cached

        # ════════════════════════════
        # STEP 2: Rule-based scan
        # ════════════════════════════

        rule_findings = self._rule_based_scan(code)

        # ════════════════════════════
        # STEP 3: AI deep analysis
        # ════════════════════════════

        ai_findings = None
        analysis_method = "rule_based"

        if self._can_use_ai():
            try:
                ai_findings = self._ai_analyze(code, filename, rule_findings)
                analysis_method = "ai_powered"
                self.ai_audits += 1
            except Exception as e:
                print(f"⚠️  AI analysis failed: {e}. Using rule-based only.")
                self.rule_audits += 1
        else:
            self.rule_audits += 1

        # ════════════════════════════
        # STEP 4: Build final report
        # ════════════════════════════

        report = self._build_report(
            code=code,
            filename=filename,
            rule_findings=rule_findings,
            ai_findings=ai_findings,
            analysis_method=analysis_method
        )

        # Track savings found
        self.total_savings_found += report["summary"].get("potential_savings", 0)

        # ════════════════════════════
        # STEP 5: Cache result
        # ════════════════════════════

        if self.cache:
            cache_key = self._generate_cache_key(code)
            report["timestamp"] = datetime.now().isoformat()
            report["from_cache"] = False
            self.cache.set(
                self.cache_namespace,
                cache_key,
                report,
                ttl_hours=720,  # 30 days
                metadata={"filename": filename, "method": analysis_method}
            )

        return report

    # ═══════════════════════════════════════════════════════════════════════
    # RULE-BASED SCAN
    # ═══════════════════════════════════════════════════════════════════════

    def _rule_based_scan(self, code: str) -> Dict:
        """
        Fast rule-based scan to find all API calls.

        Detects:
        - Model names being used
        - Line numbers
        - Estimated costs
        - Obvious optimizations

        Returns:
            Rule-based findings
        """

        lines = code.split('\n')
        findings = []

        # Patterns to detect model usage
        model_patterns = [
            (r'model\s*=\s*["\']([^"\']+)["\']', "model_param"),
            (r'engine\s*=\s*["\']([^"\']+)["\']', "engine_param"),
            (r'"model":\s*"([^"]+)"', "dict_key"),
            (r"'model':\s*'([^']+)'", "dict_key_single"),
        ]

        for line_num, line in enumerate(lines, 1):
            line_stripped = line.strip()

            # Skip comments
            if line_stripped.startswith('#'):
                continue

            for pattern, pattern_type in model_patterns:
                matches = re.finditer(pattern, line, re.IGNORECASE)

                for match in matches:
                    model_name = match.group(1)

                    # Check chat models first, then embedding models
                    _is_embedding = model_name in self.EMBEDDING_COSTS
                    _cost_dict    = self.EMBEDDING_COSTS if _is_embedding else self.MODEL_COSTS
                    _alt_dict     = self.EMBEDDING_ALTERNATIVES if _is_embedding else self.MODEL_ALTERNATIVES

                    if model_name in _cost_dict:
                        costs = _cost_dict[model_name]
                        alternatives = _alt_dict.get(model_name, [])

                        # Calculate potential savings
                        best_alt = None
                        best_savings = 0.0

                        for alt in alternatives:
                            if alt in _cost_dict:
                                alt_costs = _cost_dict[alt]
                                # Estimate savings per 1K tokens
                                current_cost = costs["input"] + costs["output"]
                                alt_cost = alt_costs["input"] + alt_costs["output"]
                                savings = current_cost - alt_cost

                                if savings > best_savings:
                                    best_savings = savings
                                    best_alt = alt

                        savings_pct = (best_savings / (costs["input"] + costs["output"]) * 100) if (costs["input"] + costs["output"]) > 0 else 0

                        finding = {
                            "line_number": line_num,
                            "line_content": line.strip(),
                            "current_model": model_name,
                            "pattern_type": pattern_type,
                            "current_cost_per_1k": costs["input"] + costs["output"],
                            "recommended_model": best_alt,
                            "savings_percent": savings_pct,
                            "severity": self._calculate_severity(model_name, savings_pct),
                            "alternatives": alternatives[:3]
                        }

                        findings.append(finding)

        return {
            "findings": findings,
            "total_api_calls": len(findings),
            "models_found": list(set(f["current_model"] for f in findings)),
            "has_expensive_models": any(
                f["current_model"] in ["gpt-4", "claude-3-opus"] for f in findings
            )
        }

    # ═══════════════════════════════════════════════════════════════════════
    # AI ANALYSIS
    # ═══════════════════════════════════════════════════════════════════════

    def _ai_analyze(
        self,
        code: str,
        filename: Optional[str],
        rule_findings: Dict
    ) -> Optional[Dict]:
        """
        Call YOUR server for AI-powered code analysis.
        
        User doesn't need API key - YOU provide the AI!
        """
        
        if not self.enable_ai:
            return None
        
        try:
            import requests
            
            # Call YOUR AI audit endpoint
            response = requests.post(
                f"{self.server_url}/api/audit",
                json={
                    "code": code[:3000],  # Limit code size for API
                    "filename": filename or "unnamed.py",
                    "rule_findings": {
                        "total_api_calls": rule_findings["total_api_calls"],
                        "models_found": rule_findings["models_found"],
                        "has_expensive_models": rule_findings["has_expensive_models"]
                    }
                },
                timeout=5  # AI analysis can take a bit longer
            )
            
            if response.status_code == 200:
                data = response.json()
                if data.get("success"):
                    return data.get("analysis")
            
            # Server unavailable - return None (fall back to rule-based)
            return None
            
        except requests.exceptions.Timeout:
            print("⚠️  AI analysis timeout - using rule-based only")
            return None
        except requests.exceptions.ConnectionError:
            # Server unreachable - silent fallback
            return None
        except Exception as e:
            print(f"⚠️  AI analysis failed: {e} - using rule-based only")
            return None

    # ═══════════════════════════════════════════════════════════════════════
    # REPORT BUILDER
    # ═══════════════════════════════════════════════════════════════════════

    def _build_report(
        self,
        code: str,
        filename: Optional[str],
        rule_findings: Dict,
        ai_findings: Optional[Dict],
        analysis_method: str
    ) -> Dict:
        """Build comprehensive audit report combining rule + AI findings"""

        issues = []
        optimized_code = code
        overall_recommendation = ""

        # Use AI findings if available (more detailed)
        if ai_findings and "issues" in ai_findings:
            for issue in ai_findings["issues"]:
                # Merge with rule findings for completeness
                rule_match = next(
                    (f for f in rule_findings["findings"]
                     if f["line_number"] == issue.get("line_number")),
                    None
                )

                issues.append({
                    "line_number": issue.get("line_number", 0),
                    "current_model": issue.get("current_model", "unknown"),
                    "recommended_model": issue.get("recommended_model", ""),
                    "step_type": issue.get("step_type", "unknown"),
                    "reasoning": issue.get("reasoning", ""),
                    "explanation": issue.get("explanation", ""),
                    "savings_percent": issue.get("savings_percent", 0),
                    "quality_impact": issue.get("quality_impact", "unknown"),
                    "confidence": issue.get("confidence", 0.7),
                    "severity": self._calculate_severity(
                        issue.get("current_model", ""),
                        issue.get("savings_percent", 0)
                    ),
                    "source": "ai"
                })

            optimized_code = ai_findings.get("optimized_code", code)
            overall_recommendation = ai_findings.get("overall_recommendation", "")

        else:
            # Fall back to rule-based findings
            for finding in rule_findings["findings"]:
                issues.append({
                    "line_number": finding["line_number"],
                    "current_model": finding["current_model"],
                    "recommended_model": finding.get("recommended_model", ""),
                    "step_type": "unknown",
                    "reasoning": f"Model {finding['current_model']} may be overkill",
                    "explanation": finding["line_content"],
                    "savings_percent": finding["savings_percent"],
                    "quality_impact": "minimal",
                    "confidence": 0.7,
                    "severity": finding["severity"],
                    "source": "rule"
                })

            overall_recommendation = (
                f"Found {len(issues)} optimization opportunities. "
                f"Enable AI analysis for deeper insights."
            )

        # Calculate summary stats
        total_savings_pct = (
            sum(i["savings_percent"] for i in issues) / len(issues)
            if issues else 0
        )

        high_confidence_issues = [i for i in issues if i["confidence"] >= 0.8]
        critical_issues = [i for i in issues if i["severity"] == "critical"]

        # Estimate cost impact
        current_cost_estimate = self._estimate_code_cost(code, rule_findings)
        potential_savings = current_cost_estimate * (total_savings_pct / 100)

        return {
            "filename": filename or "unnamed.py",
            "analysis_method": analysis_method,
            "from_cache": False,
            "summary": {
                "total_api_calls": rule_findings["total_api_calls"],
                "issues_found": len(issues),
                "critical_issues": len(critical_issues),
                "high_confidence_issues": len(high_confidence_issues),
                "models_found": rule_findings["models_found"],
                "avg_savings_percent": total_savings_pct,
                "current_cost_estimate": current_cost_estimate,
                "potential_savings": potential_savings,
                "overall_recommendation": overall_recommendation
            },
            "issues": sorted(issues, key=lambda x: x["savings_percent"], reverse=True),
            "optimized_code": optimized_code,
            "monthly_savings_estimate": ai_findings.get("estimated_monthly_savings", "") if ai_findings else "",
            "timestamp": datetime.now().isoformat()
        }

    # ═══════════════════════════════════════════════════════════════════════
    # HELPERS
    # ═══════════════════════════════════════════════════════════════════════

    def _generate_cache_key(self, code: str) -> str:
        """Generate cache key from code hash"""
        normalized = self._normalize_code(code)
        return hashlib.sha256(normalized.encode()).hexdigest()[:16]

    def _normalize_code(self, code: str) -> str:
        """Normalize code for cache key (remove comments, normalize whitespace)"""
        lines = []
        for line in code.split('\n'):
            stripped = line.strip()
            if stripped and not stripped.startswith('#'):
                lines.append(stripped)
        return '\n'.join(lines)

    def _calculate_severity(self, model: str, savings_pct: float) -> str:
        """Calculate issue severity"""
        expensive_models = ["gpt-4", "claude-3-opus"]

        if model in expensive_models and savings_pct >= 80:
            return "critical"
        elif savings_pct >= 60:
            return "high"
        elif savings_pct >= 30:
            return "medium"
        else:
            return "low"

    def _estimate_code_cost(self, code: str, rule_findings: Dict) -> float:
        """Estimate current monthly cost of running this code 1000x"""
        total_cost = 0.0

        for finding in rule_findings["findings"]:
            model = finding["current_model"]
            # Check both chat and embedding dicts
            _cost_dict2 = (self.EMBEDDING_COSTS
                           if model in self.EMBEDDING_COSTS
                           else self.MODEL_COSTS)
            if model in _cost_dict2:
                costs = _cost_dict2[model]
                # Assume 1K input + 0.5K output per call, 1000x/month
                monthly_cost = ((costs["input"] * 1) + (costs["output"] * 0.5)) * 1000
                total_cost += monthly_cost

        return total_cost

    def _calculate_cache_age(self, timestamp_str: str) -> float:
        """Calculate cache age in hours"""
        if not timestamp_str:
            return 0.0
        try:
            timestamp = datetime.fromisoformat(timestamp_str)
            age = datetime.now() - timestamp
            return age.total_seconds() / 3600
        except Exception:
            return 0.0

    def get_stats(self) -> Dict:
        """Get auditor statistics"""
        cache_hit_rate = (self.cache_hits / self.total_audits * 100) if self.total_audits > 0 else 0

        return {
            "total_audits": self.total_audits,
            "cache_hits": self.cache_hits,
            "cache_hit_rate": f"{cache_hit_rate:.1f}%",
            "ai_audits": self.ai_audits,
            "rule_audits": self.rule_audits,
            "total_cost": f"${self.total_cost:.4f}",
            "total_savings_found": f"${self.total_savings_found:.2f}"
        }

    def print_stats(self):
        """Print formatted statistics"""
        stats = self.get_stats()
        print("\n" + "="*70)
        print("📊 AI AUDITOR STATISTICS")
        print("="*70)
        print(f"Total Audits:        {stats['total_audits']}")
        print(f"Cache Hits:          {stats['cache_hits']} ({stats['cache_hit_rate']})")
        print(f"AI-Powered Audits:   {stats['ai_audits']}")
        print(f"Rule-Based Audits:   {stats['rule_audits']}")
        print(f"Total Savings Found: {stats['total_savings_found']}/month")
        print("="*70 + "\n")