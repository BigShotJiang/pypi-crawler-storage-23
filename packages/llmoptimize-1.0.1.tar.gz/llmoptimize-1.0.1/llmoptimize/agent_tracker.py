"""
Agent Workflow Tracker - Tracks multi-step AI agent executions.

Handles:
- Multi-call workflows
- Loop detection
- Context window growth
- Step-by-step optimization
- Workflow-level analytics
"""

import time
import uuid
from typing import Dict, List, Optional, Any
from datetime import datetime
from dataclasses import dataclass, field
from enum import Enum


class StepType(Enum):
    """Types of agent steps"""
    PLANNING = "planning"           # Initial reasoning, complex
    REASONING = "reasoning"         # Decision making, complex
    TOOL_CALL = "tool_call"        # Executing tools, simple
    PARSING = "parsing"            # Extracting data, simple
    SYNTHESIS = "synthesis"        # Combining results, medium
    FORMATTING = "formatting"      # Output formatting, simple
    VERIFICATION = "verification"  # Quality check, simple
    REFLECTION = "reflection"      # Self-evaluation, complex
    UNKNOWN = "unknown"


@dataclass
class AgentStep:
    """Single step in agent workflow"""
    step_id: str
    step_number: int
    step_type: StepType
    prompt: str
    model_used: str
    tokens: int
    cost: float
    duration_ms: float
    timestamp: str
    
    # Optimization metadata
    recommended_model: Optional[str] = None
    could_have_saved: float = 0.0
    was_optimized: bool = False
    
    # Context tracking
    context_size: int = 0
    is_repeat: bool = False
    repeat_count: int = 0


@dataclass
class AgentWorkflow:
    """Complete agent workflow execution"""
    workflow_id: str
    agent_name: str
    user_goal: str
    start_time: str
    end_time: Optional[str] = None
    
    # Steps
    steps: List[AgentStep] = field(default_factory=list)
    
    # Metrics
    total_steps: int = 0
    total_cost: float = 0.0
    total_tokens: int = 0
    total_duration_ms: float = 0.0
    
    # Optimization
    potential_savings: float = 0.0
    actual_savings: float = 0.0
    optimization_rate: float = 0.0
    
    # Issues
    loops_detected: int = 0
    stuck_iterations: List[int] = field(default_factory=list)
    context_overflow_warnings: int = 0
    
    # Status
    completed: bool = False
    failed: bool = False
    failure_reason: Optional[str] = None


class AgentWorkflowTracker:
    """
    Tracks entire agent workflows across multiple API calls.
    
    Features:
    - Step-by-step tracking
    - Loop detection
    - Context window monitoring
    - Automatic optimization recommendations
    - Workflow analytics
    """
    
    def __init__(self):
        self.active_workflows: Dict[str, AgentWorkflow] = {}
        self.completed_workflows: List[AgentWorkflow] = []
        
        # Configuration
        self.max_repeats = 3  # Alert after 3 repeats
        self.max_context_size = 100000  # ~100K tokens
        self.max_workflow_steps = 50  # Alert if >50 steps
    
    def start_workflow(
        self,
        agent_name: str,
        user_goal: str,
        workflow_id: Optional[str] = None
    ) -> str:
        """
        Start tracking a new agent workflow.
        
        Args:
            agent_name: Name of the agent
            user_goal: User's goal/request
            workflow_id: Optional custom workflow ID
        
        Returns:
            workflow_id for tracking
        """
        
        if workflow_id is None:
            workflow_id = str(uuid.uuid4())[:8]
        
        workflow = AgentWorkflow(
            workflow_id=workflow_id,
            agent_name=agent_name,
            user_goal=user_goal,
            start_time=datetime.now().isoformat()
        )
        
        self.active_workflows[workflow_id] = workflow
        
        print(f"\n🤖 Started workflow: {workflow_id}")
        print(f"   Agent: {agent_name}")
        print(f"   Goal: {user_goal}\n")
        
        return workflow_id
    
    def track_step(
        self,
        workflow_id: str,
        step_type: StepType,
        prompt: str,
        model_used: str,
        tokens: int,
        cost: float,
        duration_ms: float,
        recommended_model: Optional[str] = None
    ) -> AgentStep:
        """
        Track a single step in the agent workflow.
        
        Args:
            workflow_id: ID of the workflow
            step_type: Type of step (planning, tool_call, etc.)
            prompt: The prompt used
            model_used: Model that was used
            tokens: Total tokens
            cost: Cost of this step
            duration_ms: Duration in milliseconds
            recommended_model: Optimal model for this step
        
        Returns:
            AgentStep object
        """
        
        workflow = self.active_workflows.get(workflow_id)
        if not workflow:
            raise ValueError(f"Workflow {workflow_id} not found")
        
        # Create step
        step_number = len(workflow.steps) + 1
        
        step = AgentStep(
            step_id=f"{workflow_id}_step_{step_number}",
            step_number=step_number,
            step_type=step_type,
            prompt=prompt[:100] + "..." if len(prompt) > 100 else prompt,
            model_used=model_used,
            tokens=tokens,
            cost=cost,
            duration_ms=duration_ms,
            timestamp=datetime.now().isoformat(),
            recommended_model=recommended_model,
            context_size=sum(s.tokens for s in workflow.steps)
        )
        
        # Check if optimized
        if recommended_model and recommended_model != model_used:
            try:
                # Try aioptimize_core first
                from llmoptimize_core.llmoptimized.calculator import calculate_cost
            except ImportError:
                try:
                    # Try local
                    from llmoptimize_core.llmoptimized.calculator import calculate_cost
                except ImportError:
                    try:
                        # Try relative
                        from llmoptimize_core.llmoptimized.calculator import calculate_cost
                    except ImportError:
                        calculate_cost = None
            
            if calculate_cost:
                optimal_cost = calculate_cost(recommended_model, tokens // 2, tokens // 2)
                step.could_have_saved = cost - optimal_cost
                step.was_optimized = False
        elif recommended_model == model_used:
            step.was_optimized = True
        
        # Check for repeats (loop detection)
        step.is_repeat, step.repeat_count = self._detect_repeat(workflow, prompt)
        
        # Add to workflow
        workflow.steps.append(step)
        workflow.total_steps += 1
        workflow.total_cost += cost
        workflow.total_tokens += tokens
        workflow.total_duration_ms += duration_ms
        workflow.potential_savings += step.could_have_saved
        
        # Check for issues
        self._check_for_issues(workflow, step)
        
        # Print step summary
        self._print_step(step)
        
        return step
    
    def _detect_repeat(
        self,
        workflow: AgentWorkflow,
        prompt: str
    ) -> tuple:
        """Detect if this prompt is a repeat (loop detection)"""
        
        if len(workflow.steps) < 2:
            return False, 0
        
        # Check last 5 steps for similar prompts
        recent_steps = workflow.steps[-5:]
        
        # Simple similarity check (first 50 chars)
        prompt_start = prompt[:50].lower()
        
        repeat_count = 0
        for step in recent_steps:
            if step.prompt[:50].lower() == prompt_start:
                repeat_count += 1
        
        is_repeat = repeat_count >= 2
        
        return is_repeat, repeat_count
    
    def _check_for_issues(self, workflow: AgentWorkflow, step: AgentStep):
        """Check for workflow issues"""
        
        # Loop detection
        if step.is_repeat and step.repeat_count >= self.max_repeats:
            workflow.loops_detected += 1
            workflow.stuck_iterations.append(step.step_number)
            print(f"\n⚠️  WARNING: Possible loop detected at step {step.step_number}")
            print(f"   Same action repeated {step.repeat_count} times\n")
        
        # Context overflow
        if step.context_size > self.max_context_size:
            workflow.context_overflow_warnings += 1
            print(f"\n⚠️  WARNING: Context window very large ({step.context_size:,} tokens)")
            print(f"   Consider summarizing or truncating history\n")
        
        # Too many steps
        if workflow.total_steps > self.max_workflow_steps:
            print(f"\n⚠️  WARNING: Workflow has {workflow.total_steps} steps")
            print(f"   Agent may be stuck or inefficient\n")
    
    def _print_step(self, step: AgentStep):
        """Print step summary"""
        
        # Color by cost
        if step.cost > 0.10:
            color = "\033[91m"  # Red
        elif step.cost > 0.01:
            color = "\033[93m"  # Yellow
        else:
            color = "\033[92m"  # Green
        reset = "\033[0m"
        
        # Type emoji
        type_emoji = {
            StepType.PLANNING: "🧠",
            StepType.REASONING: "💭",
            StepType.TOOL_CALL: "🔧",
            StepType.PARSING: "📊",
            StepType.SYNTHESIS: "🔄",
            StepType.FORMATTING: "✨",
            StepType.VERIFICATION: "✅",
            StepType.REFLECTION: "🤔"
        }
        
        emoji = type_emoji.get(step.step_type, "➡️")
        
        print(f"  {emoji} Step {step.step_number} [{step.step_type.value}]")
        print(f"     {color}${step.cost:.6f}{reset} | {step.model_used} | {step.tokens} tokens")
        
        if step.recommended_model and not step.was_optimized:
            print(f"     💡 Could use {step.recommended_model} (save ${step.could_have_saved:.6f})")
        elif step.was_optimized:
            print(f"     ✓ Optimized")
        
        if step.is_repeat:
            print(f"     ⚠️  Repeat detected ({step.repeat_count}x)")
    
    def end_workflow(
        self,
        workflow_id: str,
        success: bool = True,
        failure_reason: Optional[str] = None
    ):
        """
        End workflow tracking and generate summary.
        
        Args:
            workflow_id: ID of the workflow
            success: Whether workflow completed successfully
            failure_reason: Reason for failure if applicable
        """
        
        workflow = self.active_workflows.get(workflow_id)
        if not workflow:
            print(f"⚠️  Workflow {workflow_id} not found")
            return
        
        # Update workflow
        workflow.end_time = datetime.now().isoformat()
        workflow.completed = success
        workflow.failed = not success
        workflow.failure_reason = failure_reason
        
        # Calculate optimization rate
        if workflow.total_steps > 0:
            optimized_steps = sum(1 for s in workflow.steps if s.was_optimized)
            workflow.optimization_rate = optimized_steps / workflow.total_steps
        
        # Move to completed
        self.completed_workflows.append(workflow)
        del self.active_workflows[workflow_id]
        
        # Print summary
        self._print_workflow_summary(workflow)
    
    def _print_workflow_summary(self, workflow: AgentWorkflow):
        """Print detailed workflow summary"""
        
        print("\n" + "="*70)
        print(f"🤖 AGENT WORKFLOW SUMMARY: {workflow.workflow_id}")
        print("="*70)
        
        print(f"\nAgent: {workflow.agent_name}")
        print(f"Goal: {workflow.user_goal}")
        print(f"Status: {'✅ Completed' if workflow.completed else '❌ Failed'}")
        
        if workflow.failed:
            print(f"Failure: {workflow.failure_reason}")
        
        # Duration
        if workflow.end_time:
            start = datetime.fromisoformat(workflow.start_time)
            end = datetime.fromisoformat(workflow.end_time)
            duration = end - start
            print(f"Duration: {str(duration).split('.')[0]}")
        
        print(f"\n{'─'*70}")
        print("METRICS")
        print(f"{'─'*70}")
        print(f"Total Steps:     {workflow.total_steps}")
        print(f"Total Cost:      ${workflow.total_cost:.6f}")
        print(f"Total Tokens:    {workflow.total_tokens:,}")
        print(f"Avg Cost/Step:   ${workflow.total_cost/workflow.total_steps:.6f}")
        
        print(f"\n{'─'*70}")
        print("OPTIMIZATION")
        print(f"{'─'*70}")
        print(f"Optimization Rate: {workflow.optimization_rate:.1%}")
        print(f"Potential Savings: ${workflow.potential_savings:.6f}")
        
        if workflow.potential_savings > 0:
            savings_pct = (workflow.potential_savings / workflow.total_cost * 100)
            print(f"Could Save:        {savings_pct:.0f}%")
        
        # Issues
        if workflow.loops_detected > 0 or workflow.context_overflow_warnings > 0:
            print(f"\n{'─'*70}")
            print("⚠️  ISSUES DETECTED")
            print(f"{'─'*70}")
            
            if workflow.loops_detected > 0:
                print(f"Loops Detected: {workflow.loops_detected}")
                print(f"Stuck at steps: {workflow.stuck_iterations}")
            
            if workflow.context_overflow_warnings > 0:
                print(f"Context Overflows: {workflow.context_overflow_warnings}")
        
        # Step breakdown
        print(f"\n{'─'*70}")
        print("STEP BREAKDOWN BY TYPE")
        print(f"{'─'*70}")
        
        step_types = {}
        for step in workflow.steps:
            step_type = step.step_type.value
            if step_type not in step_types:
                step_types[step_type] = {"count": 0, "cost": 0.0}
            step_types[step_type]["count"] += 1
            step_types[step_type]["cost"] += step.cost
        
        for step_type, stats in sorted(step_types.items()):
            print(f"{step_type:15} → {stats['count']:2} steps | ${stats['cost']:.6f}")
        
        print("\n" + "="*70 + "\n")