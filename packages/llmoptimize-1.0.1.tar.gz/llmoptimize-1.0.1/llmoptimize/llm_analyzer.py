"""
LLM Analyzer - Gets AI recommendations from AIOptimize backend.

NO USER API KEY NEEDED - recommendations powered by YOUR server!
"""

import os
import json
import requests
from typing import Optional, Dict

try:
    from .models import Recommendation
except ImportError:
    from models import Recommendation


class FreeLLMAnalyzer:
    """
    Gets AI-powered recommendations from AIOptimize backend.
    
    User doesn't need any API keys - YOU provide the AI!
    """
    
    def __init__(self, provider: str = "aioptimize"):
        """
        Initialize analyzer.
        
        Args:
            provider: Always uses "aioptimize" backend (YOUR server)
        """
        self.provider = "aioptimize"
        self.server_url = os.getenv(
            "AIOPTIMIZE_SERVER_URL",
            "https://aioptimize.up.railway.app"  # YOUR production URL (change this!)
        )
        self.client = True  # Indicates AI is available
        self.model = "server_powered"
        print(f"✅ AI recommendations powered by AIOptimize (no API key needed)")
    
    def analyze(
        self,
        prompt: str,
        current_model: str,
        heuristic_hint: Optional[Recommendation] = None,
        user_context: Optional[Dict] = None
    ) -> Optional[Recommendation]:
        """
        Get AI recommendation from YOUR server.
        
        Args:
            prompt: User's prompt
            current_model: Current model
            heuristic_hint: Optional hint from heuristics
            user_context: Optional user context
            
        Returns:
            Recommendation from YOUR AI backend or None if unavailable
        """
        
        if not self.client:
            return None
        
        try:
            # Call YOUR server API
            response = requests.post(
                f"{self.server_url}/api/recommend",
                json={
                    "prompt_preview": prompt[:200],  # Short preview only (privacy!)
                    "current_model": current_model,
                    "heuristic_hint": {
                        "suggested_model": heuristic_hint.suggested_model,
                        "confidence": heuristic_hint.confidence,
                        "reasoning": heuristic_hint.reasoning
                    } if heuristic_hint else None,
                    "user_context": user_context
                },
                timeout=3  # Fast, never block user
            )
            
            if response.status_code == 200:
                data = response.json()
                
                if data.get("success"):
                    rec_data = data.get("recommendation", {})
                    
                    # Build Recommendation from server response
                    return Recommendation(
                        should_switch=rec_data.get("should_switch", False),
                        current_model=current_model,
                        suggested_model=rec_data.get("suggested_model", current_model),
                        confidence=rec_data.get("confidence", 0.5),
                        reasoning=rec_data.get("reasoning", ""),
                        quality_impact=rec_data.get("quality_impact", "unknown"),
                        estimated_current_cost=rec_data.get("estimated_current_cost", 0),
                        estimated_suggested_cost=rec_data.get("estimated_suggested_cost", 0),
                        estimated_savings=rec_data.get("estimated_savings", 0),
                        estimated_savings_percent=rec_data.get("estimated_savings_percent", 0),
                        based_on="llm_server",
                        analysis_time_ms=300
                    )
            
            # Server unavailable or error - silent failure
            return None
            
        except requests.exceptions.Timeout:
            # Server timeout - fail silently, never crash user code
            return None
        except requests.exceptions.ConnectionError:
            # Server unreachable - fail silently
            return None
        except Exception:
            # Any other error - fail silently (never crash user code)
            return None