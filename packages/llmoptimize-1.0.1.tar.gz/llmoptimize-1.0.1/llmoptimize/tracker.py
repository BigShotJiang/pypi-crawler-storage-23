"""
Cost Tracker - Main tracking system with smart pre-call recommendations.

This module provides:
1. Cost tracking for AI API calls
2. Pre-call smart recommendations (RAG-aware, LLM-powered)
3. Data collection for ML training
4. Session summaries and analytics
"""

import time
import json
import os
import asyncio
from functools import wraps
from typing import Any, Callable, Optional, Dict, List, Tuple, TYPE_CHECKING
from datetime import datetime

# ── TYPE-ONLY IMPORT (avoids circular import at runtime) ──────────────────
# AIOptimizeConfig is only used for type hints, so we guard it with
# TYPE_CHECKING so Python never actually imports it at module load time.
if TYPE_CHECKING:
    from .config import AIOptimizeConfig


class CostTracker:
    """
    Singleton tracker that manages all cost tracking and recommendations.
    """

    def __init__(self):
        self.calls: List[Dict] = []
        self.session_start = datetime.now()
        self.total_cost = 0.0
        self.total_tokens = 0
        self.log_file = "aioptimize_log.jsonl"
        self.data_collection_file = "aioptimize_data.jsonl"

        # Initialize analyzers lazily (only when needed)
        self._smart_analyzer = None
        self._data_collector = None

    @property
    def smart_analyzer(self):
        """Lazy load smart analyzer"""
        if self._smart_analyzer is None:
            try:
                from .smart_analyzer import SmartAnalyzer
                self._smart_analyzer = SmartAnalyzer({
                    "llm_provider": os.getenv("AIOPTIMIZE_LLM_PROVIDER", "groq"),
                    "enable_rag_detection": True,
                    "min_confidence": 0.7,
                    "timeout_ms": 500
                })
            except ImportError as e:
                print(f"⚠️  SmartAnalyzer not available: {e}")
                self._smart_analyzer = None
        return self._smart_analyzer

    @property
    def data_collector(self):
        """Lazy load data collector"""
        if self._data_collector is None:
            try:
                from .data_collector import DataCollector
                self._data_collector = DataCollector()
            except ImportError as e:
                print(f"⚠️  DataCollector not available: {e}")
                self._data_collector = None
        return self._data_collector

    def track_call(
        self,
        model: str,
        prompt_tokens: int,
        completion_tokens: int,
        cost: float,
        duration_ms: float,
        function_name: str = "unknown",
        metadata: Optional[Dict] = None
    ):
        """
        Track a single API call.

        Args:
            model: Model name
            prompt_tokens: Input tokens
            completion_tokens: Output tokens
            cost: Total cost
            duration_ms: Call duration in milliseconds
            function_name: Name of the function
            metadata: Additional metadata
        """

        call_data = {
            "timestamp": datetime.now().isoformat(),
            "model": model,
            "prompt_tokens": prompt_tokens,
            "completion_tokens": completion_tokens,
            "total_tokens": prompt_tokens + completion_tokens,
            "cost": cost,
            "duration_ms": duration_ms,
            "function_name": function_name,
            "metadata": metadata or {}
        }

        self.calls.append(call_data)
        self.total_cost += cost
        self.total_tokens += prompt_tokens + completion_tokens

        self._print_call(call_data)
        self._save_to_file(call_data)

    def _print_call(self, call_data: Dict):
        """Print call to console with colors"""

        model    = call_data["model"]
        cost     = call_data["cost"]
        tokens   = call_data["total_tokens"]
        duration = call_data["duration_ms"]

        if cost > 0.10:
            color = "\033[91m"      # Red   (expensive)
        elif cost > 0.01:
            color = "\033[93m"      # Yellow (moderate)
        else:
            color = "\033[92m"      # Green  (cheap)

        reset = "\033[0m"
        print(f"{color}💰 ${cost:.6f}{reset} | {model} | {tokens} tokens | {duration:.0f}ms")

    def _save_to_file(self, call_data: Dict):
        """Save call to JSONL file"""
        try:
            with open(self.log_file, "a") as f:
                f.write(json.dumps(call_data) + "\n")
        except Exception as e:
            print(f"⚠️  Failed to save to log: {e}")

    def get_session_summary(self) -> Dict:
        """Get summary of current session"""

        if not self.calls:
            return {
                "total_calls": 0,
                "total_cost": 0.0,
                "total_tokens": 0,
                "session_duration": "0s"
            }

        duration = datetime.now() - self.session_start

        model_stats: Dict[str, Dict] = {}
        for call in self.calls:
            model = call["model"]
            if model not in model_stats:
                model_stats[model] = {"calls": 0, "cost": 0.0, "tokens": 0}
            model_stats[model]["calls"]  += 1
            model_stats[model]["cost"]   += call["cost"]
            model_stats[model]["tokens"] += call["total_tokens"]

        return {
            "total_calls":       len(self.calls),
            "total_cost":        self.total_cost,
            "total_tokens":      self.total_tokens,
            "avg_cost_per_call": self.total_cost / len(self.calls),
            "session_duration":  str(duration).split(".")[0],
            "model_breakdown":   model_stats
        }

    def print_summary(self):
        """Print session summary to console"""

        summary = self.get_session_summary()

        print("\n" + "="*70)
        print("📊 SESSION SUMMARY")
        print("="*70)
        print(f"Total Calls:     {summary['total_calls']}")
        print(f"Total Cost:      ${summary['total_cost']:.6f}")
        print(f"Total Tokens:    {summary['total_tokens']:,}")
        if summary['total_calls'] > 0:
            print(f"Avg Cost/Call:   ${summary['avg_cost_per_call']:.6f}")
        print(f"Duration:        {summary['session_duration']}")

        if summary.get("model_breakdown"):
            print(f"\n{'─'*70}")
            print("MODEL BREAKDOWN:")
            print(f"{'─'*70}")
            for model, stats in summary["model_breakdown"].items():
                print(f"\n{model}:")
                print(f"  Calls:  {stats['calls']}")
                print(f"  Cost:   ${stats['cost']:.6f}")
                print(f"  Tokens: {stats['tokens']:,}")

        print("\n" + "="*70 + "\n")


# ── Global tracker singleton ──────────────────────────────────────────────
_tracker = CostTracker()


def get_tracker() -> CostTracker:
    """Get global tracker instance"""
    return _tracker


def print_summary():
    """Print session summary"""
    _tracker.print_summary()


# ═══════════════════════════════════════════════════════════════════════════
# DECORATOR
# ═══════════════════════════════════════════════════════════════════════════

def track_cost(
    model: str = "gpt-4",
    smart_suggestions: bool = False,
    auto_optimize: bool = False,
    config=None,                        # accepts AIOptimizeConfig at runtime
    enable_guardrails: bool = False,
    daily_budget: Optional[float] = None,
    monthly_budget: Optional[float] = None
):
    """
    Decorator for automatic cost tracking with smart recommendations.

    Args:
        model: Model to use (e.g., "gpt-4", "gpt-3.5-turbo")
        smart_suggestions: Enable intelligent pre-call recommendations
        auto_optimize: Automatically switch to cheaper model if confidence > 90%
        config: Optional AIOptimizeConfig object (imported at call-time to
                avoid circular imports)
        enable_guardrails: Enable security/budget guardrails
        daily_budget: Maximum daily spend
        monthly_budget: Maximum monthly spend

    Example:
        @track_cost(model="gpt-4", smart_suggestions=True)
        async def my_function(prompt):
            return openai.chat.completions.create(...)
    """

    def decorator(func: Callable) -> Callable:

        if asyncio.iscoroutinefunction(func):
            @wraps(func)
            async def async_wrapper(*args, **kwargs) -> Any:
                return await _execute_with_tracking(
                    func, args, kwargs, model, smart_suggestions,
                    auto_optimize, config, enable_guardrails,
                    daily_budget, monthly_budget, is_async=True
                )
            return async_wrapper

        else:
            @wraps(func)
            def sync_wrapper(*args, **kwargs) -> Any:
                try:
                    loop = asyncio.get_event_loop()
                    if loop.is_running():
                        # Already inside an event loop (e.g. Jupyter)
                        import concurrent.futures
                        with concurrent.futures.ThreadPoolExecutor() as pool:
                            future = pool.submit(
                                asyncio.run,
                                _execute_with_tracking(
                                    func, args, kwargs, model, smart_suggestions,
                                    auto_optimize, config, enable_guardrails,
                                    daily_budget, monthly_budget, is_async=False
                                )
                            )
                            return future.result()
                    else:
                        return loop.run_until_complete(
                            _execute_with_tracking(
                                func, args, kwargs, model, smart_suggestions,
                                auto_optimize, config, enable_guardrails,
                                daily_budget, monthly_budget, is_async=False
                            )
                        )
                except RuntimeError:
                    return asyncio.run(
                        _execute_with_tracking(
                            func, args, kwargs, model, smart_suggestions,
                            auto_optimize, config, enable_guardrails,
                            daily_budget, monthly_budget, is_async=False
                        )
                    )
            return sync_wrapper

    return decorator


# ═══════════════════════════════════════════════════════════════════════════
# INTERNAL EXECUTION ENGINE
# ═══════════════════════════════════════════════════════════════════════════

async def _execute_with_tracking(
    func: Callable,
    args: tuple,
    kwargs: dict,
    model: str,
    smart_suggestions: bool,
    auto_optimize: bool,
    config,                             # AIOptimizeConfig | None
    enable_guardrails: bool,
    daily_budget: Optional[float],
    monthly_budget: Optional[float],
    is_async: bool
) -> Any:
    """Internal function that handles the full tracking lifecycle."""

    prompt     = _extract_prompt(args, kwargs)
    final_model = model

    # ── Helper: safely read config attributes ─────────────────────────
    def _cfg(attr: str, default=None):
        """Read attribute from config safely — config may be None."""
        return getattr(config, attr, default) if config is not None else default

    user_id = _cfg("user_id", "anonymous")
    context = {
        "industry":     _cfg("industry",     "unknown"),
        "company_size": _cfg("company_size", "unknown"),
        "use_case":     _cfg("use_case",     "unknown"),
    }

    recommendation = None

    # ── PRE-CALL: Smart suggestions ────────────────────────────────────
    if smart_suggestions and prompt and _tracker.smart_analyzer:
        try:
            recommendation = await _tracker.smart_analyzer.analyze(
                prompt=prompt,
                current_model=model,
                user_id=user_id,
                context=context
            )

            if recommendation:
                if auto_optimize and recommendation.confidence >= 0.90:
                    final_model = recommendation.suggested_model
                    print(f"\n✨ Auto-optimized: {model} → {final_model}")
                    print(f"   Savings:    ${recommendation.estimated_savings:.4f} "
                          f"({recommendation.estimated_savings_percent:.0f}%)")
                    print(f"   Confidence: {recommendation.confidence:.0%}\n")
                else:
                    _display_recommendation(recommendation)

        except Exception as e:
            print(f"⚠️  Pre-call analysis failed: {e}")

    # ── PRE-CALL: Guardrails ───────────────────────────────────────────
    if enable_guardrails and prompt:
        try:
            from .guardrail import GuardrailManager
            from ..aioptimize_core.aioptimized.calculator import estimate_tokens, calculate_cost

            manager         = GuardrailManager(
                daily_budget=daily_budget,
                monthly_budget=monthly_budget
            )
            estimated_tokens = estimate_tokens(prompt)
            estimated_cost   = calculate_cost(
                final_model, estimated_tokens, estimated_tokens
            )

            guardrail_result = manager.check_before_call(
                prompt=prompt,
                model=final_model,
                estimated_cost=estimated_cost,
                estimated_tokens=estimated_tokens * 2,
                call_history=_tracker.calls
            )

            if guardrail_result.get("severity") in ("critical", "high", "medium"):
                print(manager.format_guardrail_report(guardrail_result))

            if not guardrail_result.get("should_proceed", True):
                raise RuntimeError(
                    "❌ API call blocked by guardrails. See warnings above."
                )

        except ImportError:
            pass
        except RuntimeError:
            raise
        except Exception as e:
            print(f"⚠️  Guardrail check failed: {e}")

    # ── Override model kwarg if auto-optimized ─────────────────────────
    if "model" in kwargs:
        kwargs["model"] = final_model

    # ── EXECUTE API CALL ───────────────────────────────────────────────
    start_time = time.time()

    try:
        result = await func(*args, **kwargs) if is_async else func(*args, **kwargs)
    except Exception as e:
        print(f"❌ API call failed: {e}")
        raise

    duration_ms = (time.time() - start_time) * 1000

    # ── POST-CALL: Track cost ──────────────────────────────────────────
    prompt_tokens, completion_tokens = _extract_tokens(result)

    try:
        from ..aioptimize_core.aioptimized.calculator import calculate_cost
        actual_cost = calculate_cost(final_model, prompt_tokens, completion_tokens)
    except ImportError:
        # Fallback: rough estimate if calculator missing
        actual_cost = (prompt_tokens + completion_tokens) * 0.000002

    _tracker.track_call(
        model=final_model,
        prompt_tokens=prompt_tokens,
        completion_tokens=completion_tokens,
        cost=actual_cost,
        duration_ms=duration_ms,
        function_name=func.__name__,
        metadata={
            "original_model":  model if final_model != model else None,
            "had_recommendation": recommendation is not None,
            "auto_optimized":  auto_optimize and final_model != model
        }
    )

    # ── POST-CALL: Data collection ─────────────────────────────────────
    if _cfg("share_data", False) and recommendation and _tracker.data_collector:
        try:
            _tracker.data_collector.collect_decision(
                recommendation=recommendation,
                user_choice=final_model,
                actual_cost=actual_cost,
                actual_tokens=prompt_tokens + completion_tokens,
                user_context=context
            )
        except Exception as e:
            print(f"⚠️  Data collection failed: {e}")

    return result


# ═══════════════════════════════════════════════════════════════════════════
# HELPERS
# ═══════════════════════════════════════════════════════════════════════════

def _extract_prompt(args: tuple, kwargs: dict) -> str:
    """Extract prompt string from function arguments"""

    if "prompt" in kwargs:
        return str(kwargs["prompt"])

    if "messages" in kwargs:
        messages = kwargs["messages"]
        if isinstance(messages, list) and messages:
            last = messages[-1]
            if isinstance(last, dict):
                return last.get("content", "")
            return str(last)

    if args:
        return str(args[0])

    return ""


def _extract_tokens(response: Any) -> Tuple[int, int]:
    """
    Extract (prompt_tokens, completion_tokens) from API response.

    Handles OpenAI, Anthropic, and dict formats.
    """

    try:
        # OpenAI object
        if hasattr(response, "usage") and response.usage is not None:
            usage = response.usage
            # OpenAI style
            if hasattr(usage, "prompt_tokens"):
                return usage.prompt_tokens, usage.completion_tokens
            # Anthropic style
            if hasattr(usage, "input_tokens"):
                return usage.input_tokens, usage.output_tokens

        # Dict format
        if isinstance(response, dict):
            usage = response.get("usage", {})
            return (
                usage.get("prompt_tokens",     usage.get("input_tokens",  0)),
                usage.get("completion_tokens", usage.get("output_tokens", 0))
            )

    except Exception as e:
        print(f"⚠️  Token extraction failed: {e}")

    return 0, 0


def _display_recommendation(rec) -> None:
    """Display recommendation in a formatted box"""

    if rec.confidence >= 0.9:
        confidence_emoji = "🟢"
    elif rec.confidence >= 0.75:
        confidence_emoji = "🟡"
    else:
        confidence_emoji = "🟠"

    print("\n" + "╔" + "═"*68 + "╗")
    print("║" + " SMART RECOMMENDATION ".center(68) + "║")
    print("╚" + "═"*68 + "╝")

    print(f"\n{confidence_emoji} Confidence: {rec.confidence:.0%}  |  Source: {rec.based_on}")

    print(f"\n📊 Current Plan:")
    print(f"   Model:     {rec.current_model}")
    print(f"   Est. Cost: ${rec.estimated_current_cost:.6f}")

    print(f"\n✨ Suggested:")
    print(f"   Model:     {rec.suggested_model}")
    print(f"   Est. Cost: ${rec.estimated_suggested_cost:.6f}")
    print(f"   💰 YOU SAVE: ${rec.estimated_savings:.6f}  "
          f"({rec.estimated_savings_percent:.0f}%)")

    print(f"\n📈 Quality Impact: {rec.quality_impact.upper()}")

    print(f"\n💬 Why:")
    for line in _wrap_text(rec.reasoning, 65):
        print(f"   {line}")

    print("\n" + "─"*70)
    print("Tip: Set auto_optimize=True to switch automatically when confident")
    print("─"*70 + "\n")


def _wrap_text(text: str, width: int) -> List[str]:
    """Word-wrap text to given column width"""
    words   = text.split()
    lines:  List[str] = []
    current: List[str] = []
    length  = 0

    for word in words:
        if length + len(word) + 1 <= width:
            current.append(word)
            length += len(word) + 1
        else:
            if current:
                lines.append(" ".join(current))
            current = [word]
            length  = len(word)

    if current:
        lines.append(" ".join(current))

    return lines


# ── Backward compatibility ────────────────────────────────────────────────
def track_call(*args, **kwargs):
    """Legacy function — use @track_cost decorator instead"""
    _tracker.track_call(*args, **kwargs)