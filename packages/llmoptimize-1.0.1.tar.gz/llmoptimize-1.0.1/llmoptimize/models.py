"""
Data models for recommendations and analysis.
"""

from dataclasses import dataclass
from typing import Optional
from datetime import datetime


@dataclass
class Recommendation:
    """Structured recommendation for model optimization."""
    
    # Decision
    should_switch: bool
    current_model: str
    suggested_model: Optional[str]
    confidence: float  # 0.0 to 1.0
    
    # Explanation
    reasoning: str
    quality_impact: str  # "none", "minimal", "moderate", "significant"
    
    # Cost analysis
    estimated_current_cost: float
    estimated_suggested_cost: float
    estimated_savings: float
    estimated_savings_percent: float
    
    # Metadata
    based_on: str  # "heuristic", "llm", "ml", "hybrid"
    analysis_time_ms: int
    timestamp: str = None
    
    def __post_init__(self):
        if self.timestamp is None:
            self.timestamp = datetime.now().isoformat()


@dataclass
class PromptFeatures:
    """Extracted features from a prompt."""
    
    length: int
    word_count: int
    has_question: bool
    has_code: bool
    starts_with_what: bool
    starts_with_how: bool
    complexity_score: float  # 0-1
    estimated_tokens: int