"""
ML Trainer - Self-learning system that improves recommendations over time.

Learns from:
- User decisions (followed suggestion or not)
- Actual outcomes (cost, quality)
- Task patterns
- Industry patterns

Trains:
- Classification model (task type detection)
- Recommendation model (which model to suggest)
- Confidence calibration
"""

import json
import os
from typing import Dict, List, Optional
from datetime import datetime
from pathlib import Path


class MLTrainer:
    """
    Self-learning system for improving recommendations.
    
    Collects data from every API call and periodically trains ML models.
    """
    
    def __init__(self):
        self.data_file = "aioptimize_training_data.jsonl"
        self.model_dir = Path("aioptimize_models")
        self.model_dir.mkdir(exist_ok=True)
        
        # ML models (will be trained)
        self.task_classifier = None
        self.model_recommender = None
        self.confidence_calibrator = None
        
        # Learning statistics
        self.stats = {
            "total_samples": 0,
            "accepted_suggestions": 0,
            "rejected_suggestions": 0,
            "last_training": None,
            "model_accuracy": None
        }
        
        # Load existing models if available
        self._load_models()
    
    def collect_training_sample(
        self,
        prompt_features: Dict,
        recommendation: Dict,
        user_decision: str,
        actual_outcome: Dict,
        context: Dict
    ):
        """
        Collect one training sample from a real API call.
        
        Args:
            prompt_features: Extracted features from prompt
            recommendation: What we recommended
            user_decision: What user actually chose
            actual_outcome: Actual cost, tokens, quality
            context: User context (industry, use case, etc.)
        """
        
        sample = {
            "timestamp": datetime.now().isoformat(),
            
            # Input features
            "features": {
                "prompt_length": prompt_features.get("length"),
                "word_count": prompt_features.get("word_count"),
                "has_question": prompt_features.get("has_question"),
                "has_code": prompt_features.get("has_code"),
                "estimated_tokens": prompt_features.get("estimated_tokens"),
                "task_type": prompt_features.get("task_type"),
                "complexity": prompt_features.get("complexity_score")
            },
            
            # What we recommended
            "recommendation": {
                "suggested_model": recommendation.get("suggested_model"),
                "confidence": recommendation.get("confidence"),
                "reasoning": recommendation.get("based_on")  # heuristic, llm, rag, etc.
            },
            
            # What user did
            "user_decision": {
                "model_used": user_decision,
                "followed_suggestion": user_decision == recommendation.get("suggested_model")
            },
            
            # Actual outcome
            "outcome": {
                "actual_cost": actual_outcome.get("cost"),
                "actual_tokens": actual_outcome.get("tokens"),
                "quality_acceptable": True  # Will be updated with feedback
            },
            
            # Context
            "context": {
                "industry": context.get("industry"),
                "use_case": context.get("use_case"),
                "company_size": context.get("company_size")
            }
        }
        
        # Save to training data
        self._save_sample(sample)
        
        # Update statistics
        self.stats["total_samples"] += 1
        if sample["user_decision"]["followed_suggestion"]:
            self.stats["accepted_suggestions"] += 1
        else:
            self.stats["rejected_suggestions"] += 1
        
        # Check if we should retrain
        if self._should_retrain():
            self.train_models()
    
    def _save_sample(self, sample: Dict):
        """Save training sample to file"""
        try:
            with open(self.data_file, "a") as f:
                f.write(json.dumps(sample) + "\n")
        except Exception as e:
            print(f"⚠️ Failed to save training sample: {e}")
    
    def _should_retrain(self) -> bool:
        """Determine if we should retrain models"""
        
        # Retrain every 1,000 samples
        if self.stats["total_samples"] % 1000 == 0:
            return True
        
        # Or if acceptance rate dropped significantly
        if self.stats["total_samples"] > 100:
            acceptance_rate = (
                self.stats["accepted_suggestions"] / 
                self.stats["total_samples"]
            )
            
            # If acceptance rate < 50%, retrain to improve
            if acceptance_rate < 0.5:
                return True
        
        return False
    
    def train_models(self):
        """
        Train ML models on collected data.
        
        This is where the self-learning happens!
        """
        
        print("\n🧠 Training ML models on collected data...")
        
        # Load all training data
        samples = self._load_training_data()
        
        if len(samples) < 100:
            print(f"⚠️ Need at least 100 samples to train (have {len(samples)})")
            return
        
        try:
            # Train task classifier
            print("   Training task classifier...")
            self._train_task_classifier(samples)
            
            # Train model recommender
            print("   Training model recommender...")
            self._train_model_recommender(samples)
            
            # Calibrate confidence scores
            print("   Calibrating confidence scores...")
            self._calibrate_confidence(samples)
            
            # Save models
            self._save_models()
            
            # Update stats
            self.stats["last_training"] = datetime.now().isoformat()
            
            print(f"✅ Models trained on {len(samples)} samples!")
            print(f"   Acceptance rate: {self._calculate_acceptance_rate(samples):.1%}")
            
        except Exception as e:
            print(f"❌ Training failed: {e}")
    
    def _load_training_data(self) -> List[Dict]:
        """Load all training samples from file"""
        
        samples = []
        
        if not os.path.exists(self.data_file):
            return samples
        
        try:
            with open(self.data_file, "r") as f:
                for line in f:
                    sample = json.loads(line.strip())
                    samples.append(sample)
        except Exception as e:
            print(f"⚠️ Failed to load training data: {e}")
        
        return samples
    
    def _train_task_classifier(self, samples: List[Dict]):
        """
        Train model to classify task types from prompt features.
        
        Real implementation would use sklearn or similar.
        For now, we'll create a simple pattern-based classifier.
        """
        
        # Analyze patterns in data
        task_patterns = {}
        
        for sample in samples:
            task_type = sample["features"].get("task_type", "unknown")
            
            if task_type not in task_patterns:
                task_patterns[task_type] = {
                    "count": 0,
                    "avg_length": 0,
                    "avg_tokens": 0,
                    "has_question_pct": 0
                }
            
            patterns = task_patterns[task_type]
            patterns["count"] += 1
            patterns["avg_length"] += sample["features"].get("prompt_length", 0)
            patterns["avg_tokens"] += sample["features"].get("estimated_tokens", 0)
            if sample["features"].get("has_question"):
                patterns["has_question_pct"] += 1
        
        # Calculate averages
        for task_type, patterns in task_patterns.items():
            count = patterns["count"]
            patterns["avg_length"] /= count
            patterns["avg_tokens"] /= count
            patterns["has_question_pct"] /= count
        
        # Store learned patterns
        self.task_classifier = task_patterns
    
    def _train_model_recommender(self, samples: List[Dict]):
        """
        Train model to recommend which AI model to use.
        
        Learns from: which recommendations users accepted vs rejected
        """
        
        # Analyze acceptance patterns by task type
        acceptance_by_task = {}
        
        for sample in samples:
            task_type = sample["features"].get("task_type", "unknown")
            suggested_model = sample["recommendation"].get("suggested_model")
            followed = sample["user_decision"].get("followed_suggestion")
            
            key = (task_type, suggested_model)
            
            if key not in acceptance_by_task:
                acceptance_by_task[key] = {
                    "total": 0,
                    "accepted": 0
                }
            
            acceptance_by_task[key]["total"] += 1
            if followed:
                acceptance_by_task[key]["accepted"] += 1
        
        # Calculate acceptance rates
        for key, stats in acceptance_by_task.items():
            stats["acceptance_rate"] = stats["accepted"] / stats["total"]
        
        # Store learned model
        self.model_recommender = acceptance_by_task
    
    def _calibrate_confidence(self, samples: List[Dict]):
        """
        Calibrate confidence scores based on actual acceptance rates.
        
        If we say 90% confidence, users should accept 90% of the time.
        """
        
        confidence_buckets = {
            0.9: {"predicted": [], "actual": []},
            0.8: {"predicted": [], "actual": []},
            0.7: {"predicted": [], "actual": []},
        }
        
        for sample in samples:
            confidence = sample["recommendation"].get("confidence", 0)
            followed = sample["user_decision"].get("followed_suggestion")
            
            # Find closest bucket
            bucket = min(confidence_buckets.keys(), key=lambda x: abs(x - confidence))
            
            confidence_buckets[bucket]["predicted"].append(confidence)
            confidence_buckets[bucket]["actual"].append(1 if followed else 0)
        
        # Calculate calibration factors
        calibration = {}
        for bucket, data in confidence_buckets.items():
            if data["actual"]:
                actual_rate = sum(data["actual"]) / len(data["actual"])
                calibration[bucket] = actual_rate / bucket  # Adjustment factor
        
        self.confidence_calibrator = calibration
    
    def _calculate_acceptance_rate(self, samples: List[Dict]) -> float:
        """Calculate overall acceptance rate"""
        if not samples:
            return 0.0
        
        accepted = sum(
            1 for s in samples 
            if s["user_decision"].get("followed_suggestion")
        )
        
        return accepted / len(samples)
    
    def predict(self, prompt_features: Dict, context: Dict) -> Optional[Dict]:
        """
        Use trained ML models to make prediction.
        
        Returns:
            {
                "suggested_model": str,
                "confidence": float,
                "reasoning": str
            }
        """
        
        if not self.model_recommender:
            return None  # Models not trained yet
        
        # Use trained models to make prediction
        task_type = prompt_features.get("task_type", "unknown")
        
        # Find best model for this task type
        best_model = None
        best_acceptance = 0
        
        for (t_type, model), stats in self.model_recommender.items():
            if t_type == task_type:
                if stats["acceptance_rate"] > best_acceptance:
                    best_acceptance = stats["acceptance_rate"]
                    best_model = model
        
        if not best_model:
            return None
        
        # Calibrate confidence
        confidence = best_acceptance
        if self.confidence_calibrator:
            bucket = min(self.confidence_calibrator.keys(), key=lambda x: abs(x - confidence))
            calibration_factor = self.confidence_calibrator.get(bucket, 1.0)
            confidence *= calibration_factor
        
        return {
            "suggested_model": best_model,
            "confidence": min(0.95, confidence),
            "reasoning": f"ML model trained on {self.stats['total_samples']} samples"
        }
    
    def _save_models(self):
        """Save trained models to disk"""
        
        model_data = {
            "task_classifier": self.task_classifier,
            "model_recommender": self.model_recommender,
            "confidence_calibrator": self.confidence_calibrator,
            "stats": self.stats,
            "version": "0.1.0",
            "trained_at": datetime.now().isoformat()
        }
        
        model_file = self.model_dir / "trained_models.json"
        
        try:
            with open(model_file, "w") as f:
                json.dumps(model_data, f, indent=2)
            
            print(f"💾 Models saved to {model_file}")
        except Exception as e:
            print(f"⚠️ Failed to save models: {e}")
    
    def _load_models(self):
        """Load trained models from disk"""
        
        model_file = self.model_dir / "trained_models.json"
        
        if not model_file.exists():
            return
        
        try:
            with open(model_file, "r") as f:
                model_data = json.load(f)
            
            self.task_classifier = model_data.get("task_classifier")
            self.model_recommender = model_data.get("model_recommender")
            self.confidence_calibrator = model_data.get("confidence_calibrator")
            self.stats = model_data.get("stats", self.stats)
            
            print(f"✅ Loaded ML models trained on {self.stats['total_samples']} samples")
            
        except Exception as e:
            print(f"⚠️ Failed to load models: {e}")
    
    def get_stats(self) -> Dict:
        """Get learning statistics"""
        return {
            **self.stats,
            "acceptance_rate": (
                self.stats["accepted_suggestions"] / 
                self.stats["total_samples"]
                if self.stats["total_samples"] > 0 else 0
            ),
            "has_trained_models": self.model_recommender is not None
        }