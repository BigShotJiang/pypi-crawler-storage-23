"""
Heuristic Analyzer - Fast, rule-based checks.
"""

from typing import Optional
from .models import Recommendation


class AgentHeuristicAnalyzer:
    """Heuristics optimized for AI agent use cases"""
    
    def analyze(self, prompt: str, current_model: str) -> Optional[Recommendation]:
        """Analyze based on REAL AI agent patterns"""
        
        if current_model not in ["gpt-4", "gpt-4-turbo", "claude-3-opus"]:
            return None
        
        prompt_lower = prompt.lower()
        
        # Rule 1: Classification tasks (VERY COMMON)
        classification_keywords = [
            "classify", "categorize", "category", "sentiment", 
            "detect", "label", "tag", "type", "urgency"
        ]
        if any(kw in prompt_lower for kw in classification_keywords):
            return self._suggest_cheaper(
                current_model,
                reasoning="Classification task - GPT-3.5 maintains 95%+ accuracy",
                confidence=0.90
            )
        
        # Rule 2: Extraction tasks
        extraction_keywords = [
            "extract", "find", "get", "retrieve", "parse", 
            "pull out", "identify"
        ]
        if any(kw in prompt_lower for kw in extraction_keywords):
            return self._suggest_cheaper(
                current_model,
                reasoning="Extraction task - cheaper models handle structured output well",
                confidence=0.85
            )
        
        # Rule 3: Summarization
        summary_keywords = ["summarize", "summary", "tldr", "brief", "key points"]
        if any(kw in prompt_lower for kw in summary_keywords):
            return self._suggest_cheaper(
                current_model,
                reasoning="Summarization - cheaper models perform well for concise summaries",
                confidence=0.80
            )
        
        # Rule 4: Email/Message generation (repetitive)
        generation_keywords = ["generate", "write", "create", "draft", "compose"]
        message_keywords = ["email", "message", "response", "reply"]
        if (any(g in prompt_lower for g in generation_keywords) and 
            any(m in prompt_lower for m in message_keywords)):
            return self._suggest_cheaper(
                current_model,
                reasoning="Template-based generation - GPT-3.5 sufficient for standard responses",
                confidence=0.85
            )
        
        # Rule 5: Translation
        if "translate" in prompt_lower:
            return self._suggest_cheaper(
                current_model,
                reasoning="Translation - GPT-3.5 matches GPT-4 quality for most languages",
                confidence=0.90
            )
        
        # Rule 6: Sentiment analysis
        if "sentiment" in prompt_lower:
            return self._suggest_cheaper(
                current_model,
                reasoning="Sentiment analysis - simple task, cheaper model sufficient",
                confidence=0.90
            )
        
        # Rule 7: Very short prompts (still useful for agents)
        if len(prompt) < 100:
            return self._suggest_cheaper(
                current_model,
                reasoning="Short prompt - likely simple task requiring less reasoning",
                confidence=0.75
            )
        
        # Rule 8: Data processing/formatting
        format_keywords = ["format", "convert", "transform", "structure"]
        if any(kw in prompt_lower for kw in format_keywords):
            return self._suggest_cheaper(
                current_model,
                reasoning="Data formatting - GPT-3.5 handles structured tasks well",
                confidence=0.85
            )
        
        return None
    
    def _suggest_cheaper(
        self,
        current_model: str,
        reasoning: str,
        confidence: float
    ) -> Recommendation:
        """
        Suggest a cheaper alternative using calculator's model database.
        
        Args:
            current_model: Current expensive model
            reasoning: Why we can use cheaper model
            confidence: Confidence score (0.0-1.0)
        
        Returns:
            Recommendation object
        """
        from ..aioptimize_core.aioptimized.calculator import calculate_cost, MODEL_ALTERNATIVES
        
        # Get cheaper alternatives from calculator (same data as AIAuditor)
        alternatives = MODEL_ALTERNATIVES.get(current_model, [])
        
        if not alternatives:
            # No alternatives found - fallback to gpt-3.5-turbo
            suggested_model = "gpt-3.5-turbo"
        else:
            # Use the best (first) alternative
            suggested_model = alternatives[0]
        
        # Estimate costs (assuming 500 input + 200 output tokens)
        estimated_tokens_in = 500
        estimated_tokens_out = 200
        
        try:
            current_cost = calculate_cost(current_model, estimated_tokens_in, estimated_tokens_out)
            suggested_cost = calculate_cost(suggested_model, estimated_tokens_in, estimated_tokens_out)
            
            savings = current_cost - suggested_cost
            savings_percent = int((savings / current_cost * 100)) if current_cost > 0 else 0
        except Exception:
            # If cost calculation fails, use conservative estimates
            current_cost = 0.015
            suggested_cost = 0.0005
            savings = 0.0145
            savings_percent = 97
        
        return Recommendation(
            should_switch=True,
            current_model=current_model,
            suggested_model=suggested_model,
            confidence=confidence,
            reasoning=reasoning,
            quality_impact="minimal",
            estimated_current_cost=current_cost,
            estimated_suggested_cost=suggested_cost,
            estimated_savings=savings,
            estimated_savings_percent=savings_percent,
            based_on="heuristic",
            analysis_time_ms=5
        )