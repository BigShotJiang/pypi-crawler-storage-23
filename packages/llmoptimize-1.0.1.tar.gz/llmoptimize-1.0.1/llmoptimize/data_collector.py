"""
Data Collector - Collects anonymized usage data for ML training.

Privacy-first approach:
- No actual prompts stored (only feature hashes)
- Anonymized user IDs (SHA256 hashed)
- Opt-in only (respects user preferences)
- GDPR compliant
"""

import json
import hashlib
import os
from datetime import datetime
from typing import Dict, Optional, TYPE_CHECKING
from pathlib import Path

# TYPE-ONLY import — avoids circular import at runtime.
# Recommendation lives in models.py which may import data_collector.py.
# TYPE_CHECKING is False at runtime so this import never actually executes.
if TYPE_CHECKING:
    from .models import OptimizationRecommendation as Recommendation


# ── module-level helper ───────────────────────────────────────────────────

def _pf(features: Optional[Dict], key: str, default):
    """Safely read from prompt_features dict that might be None."""
    if features is None:
        return default
    return features.get(key, default)


def _attr(obj, name: str, default=None):
    """Read attribute from object OR dict safely."""
    if isinstance(obj, dict):
        return obj.get(name, default)
    return getattr(obj, name, default)


# Import only for type checkers (mypy/pylance) — never at runtime
# Avoids circular import since models.py may import data_collector.py
if TYPE_CHECKING:
    from .models import OptimizationRecommendation as Recommendation


def _attr(obj, name: str, default=None):
    """Safely read attribute from object or dict."""
    if isinstance(obj, dict):
        return obj.get(name, default)
    return getattr(obj, name, default)


class DataCollector:
    """
    Collects anonymized usage data for improving recommendations.

    All data is privacy-first:
    - Prompts are hashed, not stored
    - User IDs are anonymized
    - Opt-in only
    """

    def __init__(self):
        self.data_file  = "aioptimize_collected_data.jsonl"
        self.backup_dir = Path("aioptimize_data_backups")
        self.backup_dir.mkdir(exist_ok=True)

        self.session_collected = 0
        self.total_collected   = self._count_existing_samples()

    def collect_decision(
        self,
        recommendation,             # OptimizationRecommendation — no hard import needed
        user_choice:     str,
        actual_cost:     float,
        actual_tokens:   int,
        user_context:    Dict,
        prompt_features: Optional[Dict] = None,
    ):
        """
        Collect data about a recommendation and the user's decision.

        'recommendation' is typed loosely (no import) to avoid circular
        imports.  It can be any object or dict with the expected attributes.
        """

        data = {
            "timestamp":  datetime.now().isoformat(),
            "version":    "0.4.0",

            "user_id_hash": self._anonymize_user_id(
                user_context.get("user_id", "anonymous")
            ),

            "prompt_features": {
                "length":           _pf(prompt_features, "length",           0),
                "word_count":       _pf(prompt_features, "word_count",       0),
                "estimated_tokens": _pf(prompt_features, "estimated_tokens", 0),
                "has_question":     _pf(prompt_features, "has_question",     False),
                "has_code":         _pf(prompt_features, "has_code",         False),
                "complexity_score": _pf(prompt_features, "complexity_score", 0.5),
                "prompt_hash":      self._hash_prompt_features(prompt_features),
            },

            "recommendation": {
                "current_model":             _attr(recommendation, "current_model",             "unknown"),
                "suggested_model":           _attr(recommendation, "suggested_model",           "unknown"),
                "confidence":                _attr(recommendation, "confidence",                0.0),
                "estimated_savings":         _attr(recommendation, "estimated_savings",         0.0),
                "estimated_savings_percent": _attr(recommendation, "estimated_savings_percent", 0.0),
                "quality_impact":            _attr(recommendation, "quality_impact",            "unknown"),
                "reasoning_source":          _attr(recommendation, "based_on",                  "unknown"),
            },

            "user_decision": {
                "model_used":         user_choice,
                "followed_suggestion": user_choice == _attr(recommendation, "suggested_model"),
                "switched_model":     user_choice != _attr(recommendation, "current_model"),
            },

            "actual_outcome": {
                "cost":   actual_cost,
                "tokens": actual_tokens,
                "actual_savings": (
                    (_attr(recommendation, "estimated_current_cost", 0.0) - actual_cost)
                    if user_choice == _attr(recommendation, "suggested_model")
                    else 0.0
                ),
                "prediction_accuracy": self._calculate_prediction_accuracy(
                    recommendation, actual_cost
                ),
            },

            "context": {
                "industry":     user_context.get("industry",     "unknown"),
                "use_case":     user_context.get("use_case",     "unknown"),
                "company_size": user_context.get("company_size", "unknown"),
            },

            "quality_feedback": {
                "user_satisfaction":  None,
                "regenerated":        False,
                "edited_output":      False,
                "feedback_collected": False,
            },
        }

        self._save_sample(data)
        self.session_collected += 1
        self.total_collected   += 1

        if os.getenv("AIOPTIMIZE_BACKEND_URL"):
            self._send_to_backend(data)

        if self.total_collected % 100 == 0:
            print(f"📊 Collected {self.total_collected} samples (ML trains every 1000)")

    # ── private helpers ───────────────────────────────────────────────────

    def _anonymize_user_id(self, user_id: str) -> str:
        return hashlib.sha256(user_id.encode()).hexdigest()[:16]

    def _hash_prompt_features(self, features: Optional[Dict]) -> Optional[str]:
        if not features:
            return None
        s = (f"{features.get('length',0)}_"
             f"{features.get('word_count',0)}_"
             f"{features.get('has_question',False)}")
        return hashlib.sha256(s.encode()).hexdigest()[:12]

    def _calculate_prediction_accuracy(self, recommendation, actual_cost: float) -> float:
        predicted = _attr(recommendation, "estimated_current_cost", 0.0) or 0.0
        if predicted == 0:
            return 0.0
        error    = abs(predicted - actual_cost) / predicted
        accuracy = max(0.0, 1.0 - error) * 100
        return round(accuracy, 2)

    def _save_sample(self, data: Dict):
        try:
            with open(self.data_file, "a") as f:
                f.write(json.dumps(data) + "\n")
        except Exception as e:
            print(f"⚠️  Failed to save data: {e}")

    def _send_to_backend(self, data: Dict):
        backend_url = os.getenv("AIOPTIMIZE_BACKEND_URL")
        if not backend_url:
            return
        try:
            import urllib.request
            body = json.dumps(data).encode("utf-8")
            req  = urllib.request.Request(
                url     = f"{backend_url}/api/v1/collect",
                data    = body,
                method  = "POST",
                headers = {"Content-Type": "application/json"},
            )
            urllib.request.urlopen(req, timeout=5)
        except Exception:
            pass    # never block user code

    def _count_existing_samples(self) -> int:
        if not os.path.exists(self.data_file):
            return 0
        try:
            with open(self.data_file) as f:
                return sum(1 for _ in f)
        except Exception:
            return 0

    # ── public API ────────────────────────────────────────────────────────

    def get_statistics(self) -> Dict:
        stats = {
            "total_collected":   self.total_collected,
            "session_collected": self.session_collected,
            "data_file":         self.data_file,
            "file_exists":       os.path.exists(self.data_file),
        }
        if os.path.exists(self.data_file):
            try:
                accepted = total = 0
                with open(self.data_file) as f:
                    for line in f:
                        sample = json.loads(line.strip())
                        total += 1
                        if sample.get("user_decision", {}).get("followed_suggestion"):
                            accepted += 1
                stats["acceptance_rate"]      = (accepted / total * 100) if total else 0
                stats["accepted_suggestions"] = accepted
                stats["rejected_suggestions"] = total - accepted
            except Exception:
                pass
        return stats

    def export_for_analysis(self, output_file: str = "exported_data.json"):
        if not os.path.exists(self.data_file):
            print("⚠️  No data to export")
            return
        try:
            samples = []
            with open(self.data_file) as f:
                for line in f:
                    samples.append(json.loads(line.strip()))
            with open(output_file, "w") as f:
                json.dump({
                    "metadata": {
                        "total_samples": len(samples),
                        "exported_at":   datetime.now().isoformat(),
                        "version":       "0.4.0",
                    },
                    "samples": samples,
                }, f, indent=2)
            print(f"✅ Exported {len(samples)} samples to {output_file}")
        except Exception as e:
            print(f"❌ Export failed: {e}")

    def backup_data(self):
        if not os.path.exists(self.data_file):
            print("⚠️  No data to backup")
            return
        timestamp   = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_file = self.backup_dir / f"backup_{timestamp}.jsonl"
        try:
            import shutil
            shutil.copy2(self.data_file, backup_file)
            print(f"✅ Backup created: {backup_file}")
        except Exception as e:
            print(f"❌ Backup failed: {e}")

    def clear_data(self, confirm: bool = False):
        if not confirm:
            print("⚠️  Set confirm=True to actually clear data")
            return
        self.backup_data()
        try:
            if os.path.exists(self.data_file):
                os.remove(self.data_file)
                print("✅ Data cleared (backup saved)")
                self.total_collected   = 0
                self.session_collected = 0
        except Exception as e:
            print(f"❌ Clear failed: {e}")