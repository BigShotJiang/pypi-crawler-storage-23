"""
Agent Decorator - Ties all components together.

The @track_agent decorator automatically:
1. Starts workflow tracking
2. Classifies each step (hybrid: cache → rules → AI)
3. Detects loops (hybrid: cache → rules → AI)
4. Optimizes context window (hybrid: cache → AI → rules)
5. Selects optimal model (hybrid: cache → rules → AI)
6. Generates post-workflow analysis

Usage:
    @track_agent(agent_name="My Agent")
    async def my_agent(query):
        # All steps tracked automatically!
        pass
"""

import os
import time
import asyncio
import functools
from typing import Optional, Callable, Dict, Any
from datetime import datetime

from .agent_tracker import AgentWorkflowTracker, StepType
from .agent_classifier import AgentStepClassifier
from .loop_detector import LoopDetector, LoopPrevention
from .context_optimizer import ContextWindowOptimizer
from .groq_model_selector import GroqModelSelector
from .cache_manager import get_pattern_cache


class AgentSession:
    """
    Manages a single agent workflow session.

    Coordinates all components:
    - Tracker: Records every step
    - Classifier: Detects step type + optimal model
    - Loop Detector: Prevents loops
    - Context Optimizer: Manages context size
    - Model Selector: Picks cheapest Groq model
    """

    def __init__(
        self,
        agent_name: str,
        user_goal: str,
        enable_loop_detection: bool = True,
        enable_context_optimization: bool = True,
        enable_model_selection: bool = True,
        enable_classification: bool = True,
        enable_cache: bool = True,
        enable_ai: bool = True,
        ai_provider: str = "groq",
        max_steps: int = 50,
        verbose: bool = True
    ):
        self.agent_name = agent_name
        self.user_goal = user_goal
        self.verbose = verbose
        self.max_steps = max_steps
        self.step_count = 0
        self.start_time = datetime.now()

        # Initialize all components
        self.tracker = AgentWorkflowTracker()

        self.classifier = AgentStepClassifier(
            ai_provider=ai_provider,
            enable_cache=enable_cache
        ) if enable_classification else None

        self.loop_detector = LoopDetector(
            enable_ai=enable_ai,
            enable_cache=enable_cache,
            ai_provider=ai_provider
        ) if enable_loop_detection else None

        self.loop_prevention = LoopPrevention(self.loop_detector) if self.loop_detector else None

        self.context_optimizer = ContextWindowOptimizer(
            enable_ai=enable_ai,
            enable_cache=enable_cache,
            ai_provider=ai_provider
        ) if enable_context_optimization else None

        self.model_selector = GroqModelSelector(
            enable_ai=enable_ai,
            enable_cache=enable_cache,
            ai_provider=ai_provider
        ) if enable_model_selection else None

        # Global cache
        self.cache = get_pattern_cache() if enable_cache else None

        # Stats
        self.total_cost = 0.0
        self.total_tokens = 0
        self.steps_blocked = 0
        self.workflow_id = None

    def start(self):
        """Start the agent session"""

        self.workflow_id = self.tracker.start_workflow(
            agent_name=self.agent_name,
            user_goal=self.user_goal
        )

        return self.workflow_id

    def before_step(
        self,
        prompt: str,
        model: str,
        step_type: Optional[str] = None
    ) -> Dict:
        """
        Called BEFORE each API call.

        Does:
        1. Check loop (prevent if detected)
        2. Classify step type
        3. Recommend optimal model
        4. Get optimized context

        Args:
            prompt: The prompt being used
            model: Current model being used
            step_type: Optional override for step type

        Returns:
            {
                "allowed": bool,
                "block_reason": str or None,
                "step_type": StepType,
                "recommended_model": str,
                "optimized_context": str,
                "estimated_cost": float
            }
        """

        self.step_count += 1
        result = {
            "allowed": True,
            "block_reason": None,
            "step_type": StepType.UNKNOWN,
            "recommended_model": model,
            "optimized_context": prompt,
            "estimated_cost": 0.0,
            "step_number": self.step_count
        }

        # ══════════════════════════════════════════
        # CHECK 1: Loop Detection (BEFORE API call)
        # ══════════════════════════════════════════

        if self.loop_prevention:
            should_block, reason = self.loop_prevention.should_block_action(
                action=prompt,
                step_number=self.step_count
            )

            if should_block:
                self.steps_blocked += 1
                result["allowed"] = False
                result["block_reason"] = reason

                if self.verbose:
                    print(f"\n🚨 Step {self.step_count} BLOCKED - Loop detected!")

                return result  # Don't proceed

        # ══════════════════════════════════════════
        # CHECK 2: Step Classification
        # ══════════════════════════════════════════

        if self.classifier:
            context = {
                "step_number": self.step_count,
                "total_steps": self.max_steps
            }

            detected_type, recommended_model, confidence = self.classifier.classify_step(
                prompt=prompt,
                context=context
            )

            result["step_type"] = detected_type
            result["recommended_model"] = recommended_model
            result["classification_confidence"] = confidence

            if self.verbose and recommended_model != model:
                print(f"\n💡 Step {self.step_count}: Consider {recommended_model} instead of {model}")
                print(f"   Step type: {detected_type.value} (confidence: {confidence:.0%})")

        # ══════════════════════════════════════════
        # CHECK 3: Context Optimization
        # ══════════════════════════════════════════

        if self.context_optimizer:
            optimized_context = self.context_optimizer.get_context_for_api_call()
            result["optimized_context"] = optimized_context

        return result

    def after_step(
        self,
        prompt: str,
        response: str,
        model: str,
        tokens: int,
        cost: float,
        duration_ms: float,
        step_type: Optional[StepType] = None
    ):
        """
        Called AFTER each API call.

        Does:
        1. Track step in workflow
        2. Add to context optimizer
        3. Update stats

        Args:
            prompt: The prompt used
            response: The response received
            model: Model that was used
            tokens: Total tokens used
            cost: Cost of this step
            duration_ms: Duration in milliseconds
            step_type: Classified step type
        """

        # Determine step type
        if step_type is None:
            step_type = StepType.UNKNOWN

        # Determine recommended model
        recommended_model = None
        if self.classifier:
            _, recommended_model, _ = self.classifier.classify_step(
                prompt=prompt,
                context={"step_number": self.step_count}
            )

        # Track step
        if self.workflow_id:
            self.tracker.track_step(
                workflow_id=self.workflow_id,
                step_type=step_type,
                prompt=prompt,
                model_used=model,
                tokens=tokens,
                cost=cost,
                duration_ms=duration_ms,
                recommended_model=recommended_model
            )

        # Add to context optimizer
        if self.context_optimizer:
            # Determine importance based on step type
            importance_map = {
                StepType.PLANNING: 0.9,
                StepType.REASONING: 0.85,
                StepType.SYNTHESIS: 0.8,
                StepType.REFLECTION: 0.75,
                StepType.TOOL_CALL: 0.5,
                StepType.PARSING: 0.4,
                StepType.VERIFICATION: 0.4,
                StepType.FORMATTING: 0.3,
                StepType.UNKNOWN: 0.5
            }

            importance = importance_map.get(step_type, 0.5)

            self.context_optimizer.add_step(
                step_number=self.step_count,
                content=f"PROMPT:\n{prompt}\n\nRESPONSE:\n{response}",
                tokens=tokens,
                importance=importance,
                step_type=step_type.value
            )

        # Update totals
        self.total_cost += cost
        self.total_tokens += tokens

    def end(
        self,
        success: bool = True,
        failure_reason: Optional[str] = None,
        show_report: bool = True
    ) -> Dict:
        """
        End the agent session and generate full report.

        Args:
            success: Whether workflow completed successfully
            failure_reason: Reason for failure if applicable
            show_report: Print full report

        Returns:
            Complete workflow report
        """

        # End workflow tracking
        if self.workflow_id:
            self.tracker.end_workflow(
                workflow_id=self.workflow_id,
                success=success,
                failure_reason=failure_reason
            )

        # Generate full report
        report = self._generate_full_report(success)

        if show_report:
            self._print_full_report(report)

        return report

    def _generate_full_report(self, success: bool) -> Dict:
        """Generate comprehensive session report"""

        duration = (datetime.now() - self.start_time).total_seconds()

        # Collect reports from all components
        report = {
            "session": {
                "agent_name": self.agent_name,
                "user_goal": self.user_goal,
                "success": success,
                "duration_seconds": duration,
                "total_steps": self.step_count,
                "steps_blocked": self.steps_blocked,
                "total_cost": self.total_cost,
                "total_tokens": self.total_tokens
            }
        }

        # Classifier stats
        if self.classifier:
            report["classifier"] = self.classifier.get_stats()

        # Loop detection analysis
        if self.loop_detector:
            report["loop_detection"] = self.loop_detector.generate_loop_analysis()

        # Context optimization analysis
        if self.context_optimizer:
            report["context_optimization"] = self.context_optimizer.generate_analysis_report()

        # Model selector analysis
        if self.model_selector:
            report["model_selection"] = self.model_selector.generate_analysis_report()

        # Overall savings
        report["savings_summary"] = self._calculate_total_savings(report)

        return report

    def _calculate_total_savings(self, report: Dict) -> Dict:
        """Calculate total savings across all components"""

        savings = {
            "context_tokens_saved": 0,
            "context_cost_saved": 0.0,
            "loop_cost_saved": 0.0,
            "model_selection_saved": 0.0,
            "cache_savings": 0.0,
            "total_saved": 0.0
        }

        # Context savings
        if "context_optimization" in report:
            ctx = report["context_optimization"].get("summary", {})
            savings["context_tokens_saved"] = ctx.get("tokens_saved", 0)
            # Estimate cost saved from context reduction
            savings["context_cost_saved"] = ctx.get("tokens_saved", 0) * 0.00003

        # Loop prevention savings
        if "loop_detection" in report:
            loop = report["loop_detection"].get("summary", {})
            savings["loop_cost_saved"] = loop.get("cost_saved", 0.0)

        # Model selection savings
        if "model_selection" in report:
            model = report["model_selection"].get("summary", {})
            savings["model_selection_saved"] = model.get("total_saved", 0.0)

        # Cache savings (from classifier)
        if "classifier" in report:
            clf = report["classifier"]
            savings["cache_savings"] = clf.get("estimated_savings_from_cache", 0.0)

        # Total
        savings["total_saved"] = (
            savings["context_cost_saved"] +
            savings["loop_cost_saved"] +
            savings["model_selection_saved"] +
            savings["cache_savings"]
        )

        return savings

    def _print_full_report(self, report: Dict):
        """Print comprehensive session report"""

        print("\n" + "█"*70)
        print("🤖 COMPLETE AGENT SESSION REPORT")
        print("█"*70)

        # Session summary
        session = report["session"]
        print(f"\n{'─'*70}")
        print("SESSION SUMMARY")
        print(f"{'─'*70}")
        print(f"Agent:           {session['agent_name']}")
        print(f"Goal:            {session['user_goal']}")
        print(f"Status:          {'✅ Success' if session['success'] else '❌ Failed'}")
        print(f"Duration:        {session['duration_seconds']:.1f}s")
        print(f"Total Steps:     {session['total_steps']}")
        print(f"Steps Blocked:   {session['steps_blocked']} (loops prevented)")
        print(f"Total Cost:      ${session['total_cost']:.6f}")
        print(f"Total Tokens:    {session['total_tokens']:,}")

        # Savings summary
        savings = report["savings_summary"]
        print(f"\n{'─'*70}")
        print("💰 TOTAL SAVINGS SUMMARY")
        print(f"{'─'*70}")
        print(f"Context Savings:      ${savings['context_cost_saved']:.4f}")
        print(f"Loop Prevention:      ${savings['loop_cost_saved']:.4f}")
        print(f"Model Selection:      ${savings['model_selection_saved']:.4f}")
        print(f"Cache Savings:        ${savings['cache_savings']:.4f}")
        print(f"{'─'*30}")
        print(f"TOTAL SAVED:          ${savings['total_saved']:.4f}")

        # Component reports
        if "classifier" in report:
            clf = report["classifier"]
            print(f"\n{'─'*70}")
            print("🏷️  STEP CLASSIFICATION")
            print(f"{'─'*70}")
            print(f"Total:        {clf['total_classifications']}")
            print(f"Cache Hits:   {clf['cache_hits']} ({clf['cache_hit_rate']})")
            print(f"Rule-based:   {clf['rule_based']} ({clf['rule_based_percent']})")
            print(f"AI-based:     {clf['ai_based']} ({clf['ai_based_percent']})")

        if "loop_detection" in report:
            loop = report["loop_detection"]
            loop_summary = loop.get("summary", {})
            if loop_summary.get("total_loops", 0) > 0:
                print(f"\n{'─'*70}")
                print("🔁 LOOP DETECTION")
                print(f"{'─'*70}")
                print(f"Loops Detected:   {loop_summary.get('total_loops', 0)}")
                print(f"Loops Prevented:  {loop_summary.get('loops_prevented', 0)}")
                print(f"Cost Saved:       ${loop_summary.get('cost_saved', 0):.4f}")
                print(f"Rating:           {loop.get('efficiency_rating', 'N/A')}")
            else:
                print(f"\n{'─'*70}")
                print("🔁 LOOP DETECTION: ✅ No loops detected!")

        if "context_optimization" in report:
            ctx = report["context_optimization"]
            ctx_summary = ctx.get("summary", {})
            print(f"\n{'─'*70}")
            print("📦 CONTEXT OPTIMIZATION")
            print(f"{'─'*70}")
            print(f"Original Tokens:  {ctx_summary.get('original_tokens', 0):,}")
            print(f"Final Tokens:     {ctx_summary.get('final_tokens', 0):,}")
            print(f"Tokens Saved:     {ctx_summary.get('tokens_saved', 0):,} ({ctx_summary.get('savings_percent', 0):.1f}%)")
            print(f"Rating:           {ctx.get('efficiency_rating', 'N/A')}")

        print("\n" + "█"*70 + "\n")


# ═══════════════════════════════════════════════════════════════════════════
# DECORATOR
# ═══════════════════════════════════════════════════════════════════════════

def track_agent(
    agent_name: str = "Agent",
    enable_loop_detection: bool = True,
    enable_context_optimization: bool = True,
    enable_model_selection: bool = True,
    enable_classification: bool = True,
    enable_cache: bool = True,
    enable_ai: bool = True,
    ai_provider: str = "groq",
    max_steps: int = 50,
    verbose: bool = True,
    show_report: bool = True
):
    """
    Decorator to automatically track agent workflows.

    Wraps agent function with:
    - Loop detection (prevents wasted API calls)
    - Step classification (finds optimal model)
    - Context optimization (reduces token costs)
    - Model selection (picks cheapest Groq model)
    - Full post-analysis report

    Usage:
        @track_agent(agent_name="Research Agent")
        async def my_agent(query):
            # Agent code here
            pass

        # Or with custom settings:
        @track_agent(
            agent_name="My Agent",
            enable_ai=True,
            enable_cache=True,
            ai_provider="groq",
            verbose=True
        )
        async def my_agent(query):
            pass
    """

    def decorator(func: Callable):

        @functools.wraps(func)
        async def async_wrapper(*args, **kwargs):

            # Create session
            goal = str(args[0]) if args else str(kwargs)

            session = AgentSession(
                agent_name=agent_name,
                user_goal=goal[:100],
                enable_loop_detection=enable_loop_detection,
                enable_context_optimization=enable_context_optimization,
                enable_model_selection=enable_model_selection,
                enable_classification=enable_classification,
                enable_cache=enable_cache,
                enable_ai=enable_ai,
                ai_provider=ai_provider,
                max_steps=max_steps,
                verbose=verbose
            )

            # Start session
            session.start()

            # Inject session into function kwargs
            kwargs['_agent_session'] = session

            try:
                # Run agent
                result = await func(*args, **kwargs)

                # End session successfully
                session.end(success=True, show_report=show_report)

                return result

            except LoopBlockedException as e:
                # Loop was detected and blocked
                session.end(
                    success=False,
                    failure_reason=f"Loop detected: {str(e)}",
                    show_report=show_report
                )
                raise

            except Exception as e:
                # Other error
                session.end(
                    success=False,
                    failure_reason=str(e),
                    show_report=show_report
                )
                raise

        @functools.wraps(func)
        def sync_wrapper(*args, **kwargs):

            goal = str(args[0]) if args else str(kwargs)

            session = AgentSession(
                agent_name=agent_name,
                user_goal=goal[:100],
                enable_loop_detection=enable_loop_detection,
                enable_context_optimization=enable_context_optimization,
                enable_model_selection=enable_model_selection,
                enable_classification=enable_classification,
                enable_cache=enable_cache,
                enable_ai=enable_ai,
                ai_provider=ai_provider,
                max_steps=max_steps,
                verbose=verbose
            )

            session.start()
            kwargs['_agent_session'] = session

            try:
                result = func(*args, **kwargs)
                session.end(success=True, show_report=show_report)
                return result

            except Exception as e:
                session.end(success=False, failure_reason=str(e), show_report=show_report)
                raise

        # Return appropriate wrapper
        if asyncio.iscoroutinefunction(func):
            return async_wrapper
        else:
            return sync_wrapper

    return decorator


class LoopBlockedException(Exception):
    """Raised when a loop is detected and blocked"""
    pass


# ═══════════════════════════════════════════════════════════════════════════
# HELPER: Step tracking helper for use inside agents
# ═══════════════════════════════════════════════════════════════════════════

class AgentStep:
    """
    Context manager for tracking individual steps.

    Usage inside tracked agents:
        async with AgentStep(session, prompt, model) as step:
            if not step.allowed:
                raise LoopBlockedException(step.block_reason)

            result = await api_call(
                model=step.recommended_model,
                context=step.optimized_context,
                prompt=prompt
            )

            step.complete(
                response=result,
                tokens=response.usage.total_tokens,
                cost=calculate_cost(model, tokens)
            )
    """

    def __init__(
        self,
        session: AgentSession,
        prompt: str,
        model: str,
        step_type: Optional[str] = None
    ):
        self.session = session
        self.prompt = prompt
        self.model = model
        self.step_type = step_type
        self.start_time = None

        # Populated by before_step
        self.allowed = True
        self.block_reason = None
        self.recommended_model = model
        self.optimized_context = prompt
        self.classification_confidence = 0.0
        self.detected_step_type = None

        # Populated by complete()
        self._response = None
        self._tokens = 0
        self._cost = 0.0
        self._duration_ms = 0.0

    async def __aenter__(self):
        self.start_time = time.time()

        # Run before_step checks
        result = self.session.before_step(
            prompt=self.prompt,
            model=self.model,
            step_type=self.step_type
        )

        self.allowed = result["allowed"]
        self.block_reason = result.get("block_reason")
        self.recommended_model = result.get("recommended_model", self.model)
        self.optimized_context = result.get("optimized_context", self.prompt)
        self.classification_confidence = result.get("classification_confidence", 0.0)
        self.detected_step_type = result.get("step_type")

        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        # Only track if step was allowed and completed
        if self.allowed and self._response is not None:
            self.session.after_step(
                prompt=self.prompt,
                response=self._response,
                model=self.model,
                tokens=self._tokens,
                cost=self._cost,
                duration_ms=self._duration_ms,
                step_type=self.detected_step_type
            )

        return False  # Don't suppress exceptions

    def complete(
        self,
        response: str,
        tokens: int,
        cost: float
    ):
        """Mark step as complete with results"""
        self._response = response
        self._tokens = tokens
        self._cost = cost
        self._duration_ms = (time.time() - self.start_time) * 1000 if self.start_time else 0