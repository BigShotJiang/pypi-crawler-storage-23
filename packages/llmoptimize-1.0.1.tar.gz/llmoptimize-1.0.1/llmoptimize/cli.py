"""
CLI - Main command line interface for AIOptimize.

Commands:
    aioptimize audit <file>          - Audit with AI
    aioptimize stats                 - Show cache statistics
    aioptimize clear-cache           - Clear all caches
"""

import sys
import argparse
from .aiauditor import AIAuditor
from .report_formatter import format_audit_report, format_quick_summary
from .cache_manager import get_pattern_cache


def main():
    """Main CLI entry point"""

    parser = argparse.ArgumentParser(
        description="AIOptimize - AI Cost Optimization SDK",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  aioptimize audit mycode.py
  aioptimize audit mycode.py --force
  aioptimize audit mycode.py --provider claude_haiku
  aioptimize stats
  aioptimize clear-cache
        """
    )

    subparsers = parser.add_subparsers(dest='command', help='Commands')

    # ── AUDIT COMMAND ──
    audit_parser = subparsers.add_parser('audit', help='Audit Python file for AI cost optimization')
    audit_parser.add_argument('file', help='Python file to audit')
    audit_parser.add_argument(
        '--provider',
        choices=['groq', 'claude_haiku'],
        default='groq',
        help='AI provider for analysis (default: groq)'
    )
    audit_parser.add_argument(
        '--force',
        action='store_true',
        help='Force fresh analysis (skip cache)'
    )
    audit_parser.add_argument(
        '--no-ai',
        action='store_true',
        help='Use rule-based only (no AI cost)'
    )
    audit_parser.add_argument(
        '--quiet',
        action='store_true',
        help='Show quick summary only'
    )

    # ── STATS COMMAND ──
    stats_parser = subparsers.add_parser('stats', help='Show cache and usage statistics')
    stats_parser.add_argument(
        '--namespace',
        help='Show stats for specific namespace'
    )

    # ── CLEAR-CACHE COMMAND ──
    clear_parser = subparsers.add_parser('clear-cache', help='Clear cached audit results')
    clear_parser.add_argument(
        '--namespace',
        help='Clear specific namespace only'
    )
    clear_parser.add_argument(
        '--confirm',
        action='store_true',
        help='Skip confirmation prompt'
    )

    args = parser.parse_args()

    if args.command == 'audit':
        _run_audit(args)

    elif args.command == 'stats':
        _show_stats(args)

    elif args.command == 'clear-cache':
        _clear_cache(args)

    else:
        parser.print_help()


def _run_audit(args):
    """Run audit command"""

    # Read file
    try:
        with open(args.file, 'r') as f:
            code = f.read()
    except FileNotFoundError:
        print(f"❌ File not found: {args.file}")
        sys.exit(1)
    except Exception as e:
        print(f"❌ Error reading file: {e}")
        sys.exit(1)

    # Create auditor
    auditor = AIAuditor(
        ai_provider=args.provider,
        enable_cache=True,
        enable_ai=not args.no_ai
    )

    print(f"🔍 Auditing {args.file}...")
    if args.no_ai:
        print("   Mode: Rule-based only")
    else:
        print(f"   Mode: AI-powered ({args.provider})")

    # Run audit
    try:
        report = auditor.audit_code(
            code=code,
            filename=args.file,
            force_refresh=args.force
        )

        # Display results
        if args.quiet:
            print(format_quick_summary(report))
        else:
            print(format_audit_report(report))

        # Show stats
        auditor.print_stats()

    except Exception as e:
        print(f"❌ Audit failed: {e}")
        sys.exit(1)


def _show_stats(args):
    """Show statistics command"""

    cache = get_pattern_cache()
    stats = cache.get_stats(args.namespace if args.namespace else None)

    print("\n" + "="*70)
    print("📊 AIOPTIMIZE STATISTICS")
    print("="*70)

    for key, value in stats.items():
        formatted_key = key.replace('_', ' ').title()
        print(f"{formatted_key:25} {value}")

    # Show top entries if namespace specified
    if args.namespace:
        top = cache.get_top_entries(args.namespace, limit=5)
        if top:
            print(f"\nTop 5 Most Used ({args.namespace}):")
            for entry in top:
                print(f"  {entry['key'][:40]:40} {entry['hits']} hits")

    print("="*70 + "\n")


def _clear_cache(args):
    """Clear cache command"""

    cache = get_pattern_cache()

    if not args.confirm:
        if args.namespace:
            confirm = input(f"Clear cache for '{args.namespace}'? (y/N): ")
        else:
            confirm = input("Clear ALL caches? This cannot be undone. (y/N): ")

        if confirm.lower() != 'y':
            print("❌ Cancelled")
            return

    if args.namespace:
        cache.clear_namespace(args.namespace)
        print(f"✅ Cache cleared for namespace: {args.namespace}")
    else:
        cache.clear_all()
        print("✅ All caches cleared")


if __name__ == '__main__':
    main()