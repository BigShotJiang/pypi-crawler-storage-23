"""
Report Formatter - Beautiful formatted output for audit reports.

Turns raw audit dictionaries into readable console output.
"""

from typing import Dict


def format_audit_report(report: Dict) -> str:
    """
    Format audit report into beautiful console output.

    Args:
        report: Audit report from AIAuditor or GroqAuditor

    Returns:
        Formatted string ready to print
    """

    lines = []
    summary = report.get("summary", {})
    issues = report.get("issues", [])

    # Header
    lines.append("\n" + "╔" + "═"*68 + "╗")
    lines.append("║" + "      🤖 AI CODE AUDIT REPORT      ".center(68) + "║")
    lines.append("╚" + "═"*68 + "╝")

    # File info
    filename = report.get("filename", "unnamed.py")
    method = report.get("analysis_method", "unknown")
    from_cache = report.get("from_cache", False)
    cache_age = report.get("cache_age_hours", 0)

    lines.append(f"\n📄 File: {filename}")
    lines.append(f"🔬 Method: {method}")

    if from_cache:
        lines.append(f"💾 From Cache (age: {cache_age:.1f} hours)")
    else:
        lines.append(f"🔄 Fresh Analysis")

    # Groq metadata if available
    groq_meta = report.get("groq_metadata", {})
    if groq_meta:
        lines.append(f"🤖 Groq Model: {groq_meta.get('model_used', 'N/A')}")
        lines.append(f"💰 Audit Cost: ${groq_meta.get('actual_cost', 0):.6f}")

    # Summary section
    lines.append(f"\n{'─'*70}")
    lines.append("📊 ANALYSIS SUMMARY")
    lines.append(f"{'─'*70}")
    lines.append(f"Total API Calls:         {summary.get('total_api_calls', 0)}")
    lines.append(f"Issues Found:            {summary.get('issues_found', 0)}")
    lines.append(f"Critical Issues:         {summary.get('critical_issues', 0)}")
    lines.append(f"Models Used:             {', '.join(summary.get('models_found', []))}")

    current_cost = summary.get("current_cost_estimate", 0)
    potential_savings = summary.get("potential_savings", 0)
    avg_savings = summary.get("avg_savings_percent", 0)

    if current_cost > 0:
        lines.append(f"\nEst. Monthly Cost:       ${current_cost:.2f} (at 1000 runs/month)")
        lines.append(f"POTENTIAL SAVINGS:       ${potential_savings:.2f} ({avg_savings:.0f}%)")

    monthly = report.get("monthly_savings_estimate", "")
    if monthly:
        lines.append(f"Monthly Estimate:        {monthly}")

    # Overall recommendation
    overall = summary.get("overall_recommendation", "")
    if overall:
        lines.append(f"\n💡 {overall}")

    # Issues section
    if issues:
        lines.append(f"\n{'─'*70}")
        lines.append("🔍 DETAILED RECOMMENDATIONS")
        lines.append(f"{'─'*70}")

        severity_emoji = {
            "critical": "🔴",
            "high": "🟠",
            "medium": "🟡",
            "low": "🟢"
        }

        for i, issue in enumerate(issues, 1):
            severity = issue.get("severity", "medium")
            emoji = severity_emoji.get(severity, "🔵")

            lines.append(f"\n{emoji} ISSUE #{i}: Line {issue.get('line_number', '?')} - {severity.upper()}")
            lines.append(f"   Current Model:  {issue.get('current_model', 'unknown')}")
            lines.append(f"   Step Type:      {issue.get('step_type', 'unknown')}")

            explanation = issue.get("explanation", "")
            if explanation and len(explanation) < 80:
                lines.append(f"   Doing:          {explanation}")

            rec_model = issue.get("recommended_model", "")
            savings_pct = issue.get("savings_percent", 0)
            quality = issue.get("quality_impact", "unknown")
            confidence = issue.get("confidence", 0)

            if rec_model and rec_model != issue.get("current_model"):
                lines.append(f"\n   ✨ RECOMMENDATION: {rec_model}")
                lines.append(f"   Reasoning:      {issue.get('reasoning', '')[:120]}")
                lines.append(f"   Savings:        {savings_pct:.0f}%")
                lines.append(f"   Quality Impact: {quality.upper()}")
                lines.append(f"   Confidence:     {confidence:.0%}")
            else:
                lines.append(f"\n   ✅ Model is appropriate for this task")
                lines.append(f"   Reasoning: {issue.get('reasoning', '')[:120]}")

    else:
        lines.append(f"\n✅ No optimization issues found!")
        lines.append(f"   Your code is already using models efficiently.")

    # Optimized code section (only show if different)
    optimized = report.get("optimized_code", "")
    original_code_hint = report.get("filename", "")

    if optimized and optimized.strip() and issues:
        lines.append(f"\n{'─'*70}")
        lines.append("📝 OPTIMIZED CODE PREVIEW")
        lines.append(f"{'─'*70}")
        # Show first 20 lines of optimized code
        opt_lines = optimized.split('\n')[:20]
        for line in opt_lines:
            lines.append(f"  {line}")
        if len(optimized.split('\n')) > 20:
            lines.append(f"  ... ({len(optimized.split(chr(10)))-20} more lines)")

    lines.append("\n" + "═"*70 + "\n")

    return "\n".join(lines)


def format_comparison_table(models: list) -> str:
    """
    Format model comparison table.

    Args:
        models: List of model dicts from GroqModelSelector.compare_models()

    Returns:
        Formatted table string
    """

    lines = []
    lines.append("\n" + "═"*70)
    lines.append("🔍 MODEL COMPARISON TABLE")
    lines.append("═"*70)

    # Header
    lines.append(f"\n{'Model':25} {'Cost':10} {'Quality':10} {'Speed':10} {'Free/day':10}")
    lines.append(f"{'─'*25} {'─'*10} {'─'*10} {'─'*10} {'─'*10}")

    for model in models:
        name = model.get("model", "unknown")[:24]
        cost = f"${model.get('cost', 0):.6f}"
        quality = f"{model.get('quality', 0):.0%}"
        speed = f"{model.get('speed', 0)} t/s"
        free = str(model.get("free_rpd", 0))

        # Mark recommended
        marker = " ✅" if model.get("cost_rank") == 1 else ""

        lines.append(f"{name:25} {cost:10} {quality:10} {speed:10} {free:10}{marker}")

    lines.append("═"*70 + "\n")

    return "\n".join(lines)


def format_quick_summary(report: Dict) -> str:
    """
    Format a quick one-line summary of audit results.

    Args:
        report: Audit report

    Returns:
        Short summary string
    """

    summary = report.get("summary", {})
    issues = summary.get("issues_found", 0)
    savings = summary.get("avg_savings_percent", 0)
    models = ", ".join(summary.get("models_found", []))
    cached = "📦 CACHED" if report.get("from_cache") else "🔄 FRESH"

    if issues == 0:
        return f"✅ {cached} | No issues | Models: {models}"
    else:
        return f"⚠️  {cached} | {issues} issues | Avg savings: {savings:.0f}% | Models: {models}"