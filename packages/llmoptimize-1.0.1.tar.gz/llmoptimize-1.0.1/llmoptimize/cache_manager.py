"""
Unified Cache Manager - Smart caching for all AIOptimize components.

Features:
- Pattern-based caching (learns patterns, not exact matches)
- Automatic cache warming
- TTL (time-to-live) support
- Statistics tracking
- Persistent storage
"""

import hashlib
import json
import os
from typing import Any, Optional, Dict, Tuple
from datetime import datetime, timedelta
from pathlib import Path


class CacheManager:
    """
    Unified cache manager for all AIOptimize components.
    
    Each component gets its own namespace to avoid collisions.
    """
    
    def __init__(
        self,
        cache_dir: str = ".aioptimize_cache",
        default_ttl_hours: int = 168  # 7 days
    ):
        """
        Initialize cache manager.
        
        Args:
            cache_dir: Directory to store cache files
            default_ttl_hours: Default TTL in hours (168 = 7 days)
        """
        self.cache_dir = Path(cache_dir)
        self.cache_dir.mkdir(exist_ok=True)
        
        self.default_ttl = timedelta(hours=default_ttl_hours)
        
        # In-memory cache (fast access)
        self.memory_cache: Dict[str, Dict] = {}
        
        # Statistics
        self.stats = {
            "hits": 0,
            "misses": 0,
            "sets": 0,
            "evictions": 0
        }
        
        # Load existing caches
        self._load_all_caches()
    
    def get(
        self,
        namespace: str,
        key: str,
        default: Any = None
    ) -> Optional[Any]:
        """
        Get value from cache.
        
        Args:
            namespace: Component namespace (e.g., "agent_classifier")
            key: Cache key
            default: Default value if not found
        
        Returns:
            Cached value or default
        """
        
        cache_key = self._make_cache_key(namespace, key)
        
        # Check memory cache first
        if cache_key in self.memory_cache:
            entry = self.memory_cache[cache_key]
            
            # Check if expired
            if self._is_expired(entry):
                del self.memory_cache[cache_key]
                self.stats["evictions"] += 1
                self.stats["misses"] += 1
                return default
            
            # Update access stats
            entry["hits"] += 1
            entry["last_accessed"] = datetime.now().isoformat()
            
            self.stats["hits"] += 1
            return entry["value"]
        
        # Not in cache
        self.stats["misses"] += 1
        return default
    
    def set(
        self,
        namespace: str,
        key: str,
        value: Any,
        ttl_hours: Optional[int] = None,
        metadata: Optional[Dict] = None
    ):
        """
        Set value in cache.
        
        Args:
            namespace: Component namespace
            key: Cache key
            value: Value to cache
            ttl_hours: Custom TTL in hours (None = default)
            metadata: Additional metadata to store
        """
        
        cache_key = self._make_cache_key(namespace, key)
        
        ttl = timedelta(hours=ttl_hours) if ttl_hours else self.default_ttl
        expires_at = datetime.now() + ttl
        
        entry = {
            "value": value,
            "namespace": namespace,
            "key": key,
            "created_at": datetime.now().isoformat(),
            "expires_at": expires_at.isoformat(),
            "last_accessed": datetime.now().isoformat(),
            "hits": 0,
            "metadata": metadata or {}
        }
        
        self.memory_cache[cache_key] = entry
        self.stats["sets"] += 1
        
        # Persist to disk
        self._persist_cache(namespace)
    
    def get_or_compute(
        self,
        namespace: str,
        key: str,
        compute_fn,
        ttl_hours: Optional[int] = None,
        metadata: Optional[Dict] = None
    ) -> Tuple[Any, bool]:
        """
        Get from cache or compute if not exists.
        
        Args:
            namespace: Component namespace
            key: Cache key
            compute_fn: Function to compute value if not cached
            ttl_hours: Custom TTL
            metadata: Additional metadata
        
        Returns:
            (value, was_cached)
        """
        
        cached = self.get(namespace, key)
        
        if cached is not None:
            return cached, True
        
        # Compute new value
        value = compute_fn()
        
        # Cache it
        self.set(namespace, key, value, ttl_hours, metadata)
        
        return value, False
    
    def _make_cache_key(self, namespace: str, key: str) -> str:
        """Create cache key with namespace"""
        return f"{namespace}:{key}"
    
    def _is_expired(self, entry: Dict) -> bool:
        """Check if cache entry is expired"""
        expires_at = datetime.fromisoformat(entry["expires_at"])
        return datetime.now() > expires_at
    
    def _load_all_caches(self):
        """Load all cache files from disk"""
        
        for cache_file in self.cache_dir.glob("*.json"):
            try:
                with open(cache_file, 'r') as f:
                    data = json.load(f)
                    
                    for cache_key, entry in data.items():
                        # Only load non-expired entries
                        if not self._is_expired(entry):
                            self.memory_cache[cache_key] = entry
            except Exception as e:
                print(f"⚠️  Failed to load cache {cache_file}: {e}")
    
    def _persist_cache(self, namespace: str):
        """Persist namespace cache to disk"""
        
        # Get all entries for this namespace
        namespace_entries = {
            key: entry
            for key, entry in self.memory_cache.items()
            if entry["namespace"] == namespace
        }
        
        if not namespace_entries:
            return
        
        # Save to file
        cache_file = self.cache_dir / f"{namespace}.json"
        
        try:
            with open(cache_file, 'w') as f:
                json.dump(namespace_entries, f, indent=2)
        except Exception as e:
            print(f"⚠️  Failed to persist cache for {namespace}: {e}")
    
    def clear_namespace(self, namespace: str):
        """Clear all cache entries for a namespace"""
        
        keys_to_remove = [
            key for key, entry in self.memory_cache.items()
            if entry["namespace"] == namespace
        ]
        
        for key in keys_to_remove:
            del self.memory_cache[key]
        
        # Remove file
        cache_file = self.cache_dir / f"{namespace}.json"
        if cache_file.exists():
            cache_file.unlink()
    
    def clear_all(self):
        """Clear all caches"""
        self.memory_cache.clear()
        
        for cache_file in self.cache_dir.glob("*.json"):
            cache_file.unlink()
        
        self.stats = {
            "hits": 0,
            "misses": 0,
            "sets": 0,
            "evictions": 0
        }
    
    def get_stats(self, namespace: Optional[str] = None) -> Dict:
        """
        Get cache statistics.
        
        Args:
            namespace: Specific namespace or None for all
        
        Returns:
            Statistics dictionary
        """
        
        if namespace:
            # Stats for specific namespace
            entries = [
                entry for entry in self.memory_cache.values()
                if entry["namespace"] == namespace
            ]
            
            total_hits = sum(e["hits"] for e in entries)
            
            return {
                "namespace": namespace,
                "entries": len(entries),
                "total_hits": total_hits,
                "avg_hits_per_entry": total_hits / len(entries) if entries else 0
            }
        
        # Global stats
        hit_rate = (self.stats["hits"] / (self.stats["hits"] + self.stats["misses"]) * 100) if (self.stats["hits"] + self.stats["misses"]) > 0 else 0
        
        return {
            "total_entries": len(self.memory_cache),
            "hits": self.stats["hits"],
            "misses": self.stats["misses"],
            "hit_rate": f"{hit_rate:.1f}%",
            "sets": self.stats["sets"],
            "evictions": self.stats["evictions"],
            "namespaces": len(set(e["namespace"] for e in self.memory_cache.values()))
        }
    
    def print_stats(self, namespace: Optional[str] = None):
        """Print formatted statistics"""
        
        stats = self.get_stats(namespace)
        
        print("\n" + "="*70)
        if namespace:
            print(f"📊 CACHE STATISTICS - {namespace.upper()}")
        else:
            print("📊 GLOBAL CACHE STATISTICS")
        print("="*70)
        
        for key, value in stats.items():
            formatted_key = key.replace('_', ' ').title()
            print(f"{formatted_key:20} {value}")
        
        print("="*70 + "\n")
    
    def get_top_entries(self, namespace: str, limit: int = 10) -> list:
        """Get most frequently accessed entries"""
        
        entries = [
            {
                "key": entry["key"],
                "hits": entry["hits"],
                "created_at": entry["created_at"],
                "last_accessed": entry["last_accessed"]
            }
            for entry in self.memory_cache.values()
            if entry["namespace"] == namespace
        ]
        
        # Sort by hits
        entries.sort(key=lambda e: e["hits"], reverse=True)
        
        return entries[:limit]
    
    def optimize(self):
        """
        Optimize cache by removing expired and rarely used entries.
        """
        
        keys_to_remove = []
        
        for key, entry in self.memory_cache.items():
            # Remove expired
            if self._is_expired(entry):
                keys_to_remove.append(key)
                continue
            
            # Remove rarely used old entries
            created_at = datetime.fromisoformat(entry["created_at"])
            age_days = (datetime.now() - created_at).days
            
            if age_days > 30 and entry["hits"] < 3:
                keys_to_remove.append(key)
        
        # Remove entries
        for key in keys_to_remove:
            del self.memory_cache[key]
            self.stats["evictions"] += 1
        
        # Persist all namespaces
        namespaces = set(e["namespace"] for e in self.memory_cache.values())
        for namespace in namespaces:
            self._persist_cache(namespace)
        
        return {
            "entries_removed": len(keys_to_remove),
            "entries_remaining": len(self.memory_cache)
        }


class PatternCache(CacheManager):
    """
    Pattern-based cache that normalizes inputs for better hit rates.
    
    Example:
    - "Search for flights to Paris" → "search for [entity] to [location]"
    - "Search for hotels in London" → "search for [entity] in [location]"
    Both map to same pattern → cache hit!
    """
    
    def __init__(self, cache_dir: str = ".aioptimize_cache", default_ttl_hours: int = 168):
        super().__init__(cache_dir, default_ttl_hours)
        
        # Pattern extraction rules
        self.patterns = {
            # Numbers
            r'\b\d+\b': '[NUMBER]',
            # URLs
            r'https?://[^\s]+': '[URL]',
            # Emails
            r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b': '[EMAIL]',
            # File paths
            r'[A-Za-z]:[\\\/][^\s]+': '[PATH]',
            # Common entities (basic)
            r'\b[A-Z][a-z]+ [A-Z][a-z]+\b': '[ENTITY]',  # Proper names
        }
    
    def normalize_key(self, key: str) -> str:
        """
        Normalize key to extract pattern.
        
        Args:
            key: Original key
        
        Returns:
            Normalized pattern key
        """
        import re
        
        normalized = key.lower()
        
        # Apply pattern replacements
        for pattern, replacement in self.patterns.items():
            normalized = re.sub(pattern, replacement, normalized, flags=re.IGNORECASE)
        
        # Remove extra whitespace
        normalized = ' '.join(normalized.split())
        
        return normalized
    
    def get_pattern(
        self,
        namespace: str,
        key: str,
        default: Any = None
    ) -> Optional[Any]:
        """Get using pattern-based matching"""
        
        normalized_key = self.normalize_key(key)
        return self.get(namespace, normalized_key, default)
    
    def set_pattern(
        self,
        namespace: str,
        key: str,
        value: Any,
        ttl_hours: Optional[int] = None,
        metadata: Optional[Dict] = None
    ):
        """Set using pattern-based key"""
        
        normalized_key = self.normalize_key(key)
        
        # Add original key to metadata for debugging
        if metadata is None:
            metadata = {}
        metadata["original_key"] = key
        
        self.set(namespace, normalized_key, value, ttl_hours, metadata)


# Global cache instance
_global_cache = None


def get_cache() -> CacheManager:
    """Get global cache instance (singleton)"""
    global _global_cache
    
    if _global_cache is None:
        _global_cache = CacheManager()
    
    return _global_cache


def get_pattern_cache() -> PatternCache:
    """Get global pattern cache instance (singleton)"""
    global _global_cache
    
    if _global_cache is None:
        _global_cache = PatternCache()
    elif not isinstance(_global_cache, PatternCache):
        # Upgrade to pattern cache
        _global_cache = PatternCache()
    
    return _global_cache