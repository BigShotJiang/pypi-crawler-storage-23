"""
cloud_sync.py - Sends anonymized batches to your server over HTTPS.

Features:
- Retry on failure (3 attempts)
- Timeout (5 seconds — never blocks user code)
- Falls back silently if server unreachable
- Works with localhost (dev) and production URL
- Checks server health before sending

Config:
  AIOPTIMIZE_SERVER_URL=http://localhost:8000    ← development
  AIOPTIMIZE_SERVER_URL=https://api.aioptimize.dev  ← production
"""

import os
import json
import time
from typing import Dict, List, Optional
from datetime import datetime


# Server URL — change this one line when you deploy
DEFAULT_SERVER_URL = os.getenv(
    "AIOPTIMIZE_SERVER_URL",
    "http://localhost:8000"     # ← dev default, change for prod
)

# Request settings
TIMEOUT_SECONDS  = 5       # never block user code for long
MAX_RETRIES      = 3
RETRY_DELAY      = 1.0     # seconds between retries


class CloudSync:
    """
    Handles HTTPS communication with your AIOptimize server.

    Silent failures — if server is unreachable, user code
    is completely unaffected.
    """

    def __init__(self, server_url: str = DEFAULT_SERVER_URL):
        self.server_url     = server_url.rstrip("/")
        self._server_ok     = None      # None = not checked yet
        self._last_check    = 0.0
        self._check_interval= 300.0     # re-check server every 5 minutes
        self._total_sent    = 0
        self._total_failed  = 0
        self._total_batches = 0

    # ── HEALTH CHECK ─────────────────────────────────────────────────────

    def _check_server(self) -> bool:
        """
        Ping server health endpoint.
        Cached for 5 minutes to avoid constant pings.
        """
        now = time.time()

        # Use cached result if fresh
        if self._server_ok is not None:
            if now - self._last_check < self._check_interval:
                return self._server_ok

        try:
            import urllib.request
            url     = f"{self.server_url}/health"
            req     = urllib.request.Request(url, method="GET")
            with urllib.request.urlopen(req, timeout=3) as resp:
                self._server_ok  = resp.status == 200
                self._last_check = now
                return self._server_ok

        except Exception:
            self._server_ok  = False
            self._last_check = now
            return False

    # ── SEND BATCH ───────────────────────────────────────────────────────

    def send_batch(
        self,
        session_id:  str,
        sdk_version: str,
        is_licensed: bool,
        calls:       List[Dict],
    ) -> bool:
        """
        Send a batch of anonymized calls to the server.

        Returns True if sent successfully, False otherwise.
        Never raises an exception — silent failures only.
        """

        if not calls:
            return True

        # Quick server check (cached)
        if not self._check_server():
            self._total_failed += len(calls)
            return False

        payload = {
            "session_id":  session_id,
            "sdk_version": sdk_version,
            "is_licensed": is_licensed,
            "calls":       calls,
        }

        # Try up to MAX_RETRIES times
        for attempt in range(1, MAX_RETRIES + 1):
            try:
                success = self._post(
                    endpoint = "/collect",
                    data     = payload,
                )

                if success:
                    self._total_sent    += len(calls)
                    self._total_batches += 1
                    return True

            except Exception:
                pass

            # Wait before retry (except last attempt)
            if attempt < MAX_RETRIES:
                time.sleep(RETRY_DELAY * attempt)

        self._total_failed += len(calls)
        return False

    def _post(self, endpoint: str, data: Dict) -> bool:
        """
        Send a POST request using only stdlib (no requests library needed).
        Returns True if server responded with 2xx.
        """
        import urllib.request
        import urllib.error

        url         = f"{self.server_url}{endpoint}"
        body        = json.dumps(data).encode("utf-8")

        req = urllib.request.Request(
            url     = url,
            data    = body,
            method  = "POST",
            headers = {
                "Content-Type": "application/json",
                "User-Agent":   f"aioptimize-sdk/1.0.0",
            }
        )

        try:
            with urllib.request.urlopen(req, timeout=TIMEOUT_SECONDS) as resp:
                return 200 <= resp.status < 300

        except urllib.error.HTTPError as e:
            # 4xx/5xx — server rejected the data
            return False

        except urllib.error.URLError:
            # Network unreachable
            self._server_ok = False
            return False

        except Exception:
            return False

    # ── PATTERN FETCH ────────────────────────────────────────────────────

    def get_server_recommendation(
        self,
        category:   str,
        complexity: str = "simple"
    ) -> Optional[Dict]:
        """
        Fetch server-learned recommendation for a prompt category.

        SDK calls this to enhance local recommendations with
        global patterns learned from all users.

        Returns:
            Dict with recommended_model, confidence, etc.
            None if server unreachable or no pattern yet.
        """

        if not self._check_server():
            return None

        try:
            import urllib.request

            url = f"{self.server_url}/patterns/{category}?complexity={complexity}"
            req = urllib.request.Request(url, method="GET")

            with urllib.request.urlopen(req, timeout=TIMEOUT_SECONDS) as resp:
                if resp.status == 200:
                    return json.loads(resp.read().decode("utf-8"))

        except Exception:
            pass

        return None

    # ── STATS ─────────────────────────────────────────────────────────────

    def get_stats(self) -> Dict:
        return {
            "server_url":      self.server_url,
            "server_status":   "ok" if self._server_ok else "unreachable",
            "total_batches":   self._total_batches,
            "total_sent":      self._total_sent,
            "total_failed":    self._total_failed,
            "success_rate":    (
                f"{self._total_sent / max(self._total_sent + self._total_failed, 1) * 100:.1f}%"
            ),
        }