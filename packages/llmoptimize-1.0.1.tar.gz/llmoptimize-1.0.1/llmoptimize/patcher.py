"""
patcher.py - Silently patches AI libraries to intercept API calls.

Patches:
- OpenAI    (sync + async) — chat + embeddings
- Anthropic (sync + async)
- Groq      (sync + async)
- Gemini    (sync + async)
- Mistral   (sync + async)
- Cohere    (sync + async)

Each patch:
1. Wraps the original method
2. Calls original (user's call works exactly the same!)
3. Extracts tokens + cost from response
4. Records to MagicSession with caller line number
5. Returns original response untouched
"""

import time
import functools
from typing import Any, Tuple

from llmoptimize_core.llmoptimized.magic import get_session, get_caller_frame


# ── patch state ──────────────────────────────────────────────────────────
_patched = {
    "openai":    False,
    "anthropic": False,
    "groq":      False,
    "gemini":    False,
    "mistral":   False,
    "cohere":    False,
}


# ═══════════════════════════════════════════════════════════════════════════
# SHARED HELPERS
# ═══════════════════════════════════════════════════════════════════════════

def _extract_prompt_preview(messages: Any) -> str:
    """Get first 80 chars of last user message"""
    try:
        if isinstance(messages, list) and messages:
            last = messages[-1]
            if isinstance(last, dict):
                content = last.get("content", "")
                if isinstance(content, str):
                    return content[:80]
                if isinstance(content, list):
                    for block in content:
                        if isinstance(block, dict) and block.get("type") == "text":
                            return block.get("text", "")[:80]
            # Gemini message format
            if hasattr(last, "parts"):
                for part in last.parts:
                    if hasattr(part, "text"):
                        return part.text[:80]
        if isinstance(messages, str):
            return messages[:80]
    except Exception:
        pass
    return ""


def _openai_tokens(response: Any) -> Tuple[int, int]:
    """Extract (prompt_tokens, completion_tokens) — OpenAI / Groq style"""
    try:
        if hasattr(response, "usage") and response.usage:
            return (
                getattr(response.usage, "prompt_tokens",     0) or 0,
                getattr(response.usage, "completion_tokens", 0) or 0,
            )
    except Exception:
        pass
    return 0, 0


def _anthropic_tokens(response: Any) -> Tuple[int, int]:
    """Extract (input_tokens, output_tokens) — Anthropic style"""
    try:
        if hasattr(response, "usage") and response.usage:
            return (
                getattr(response.usage, "input_tokens",  0) or 0,
                getattr(response.usage, "output_tokens", 0) or 0,
            )
    except Exception:
        pass
    return 0, 0


def _gemini_tokens(response: Any) -> Tuple[int, int]:
    """Extract tokens from Gemini response"""
    try:
        if hasattr(response, "usage_metadata"):
            meta = response.usage_metadata
            return (
                getattr(meta, "prompt_token_count",     0) or 0,
                getattr(meta, "candidates_token_count", 0) or 0,
            )
    except Exception:
        pass
    return 0, 0


def _mistral_tokens(response: Any) -> Tuple[int, int]:
    """Extract tokens from Mistral response"""
    try:
        if hasattr(response, "usage") and response.usage:
            return (
                getattr(response.usage, "prompt_tokens",     0) or 0,
                getattr(response.usage, "completion_tokens", 0) or 0,
            )
    except Exception:
        pass
    return 0, 0


def _cohere_tokens(response: Any) -> Tuple[int, int]:
    """Extract tokens from Cohere response"""
    try:
        # Cohere v2 chat response
        if hasattr(response, "usage") and response.usage:
            tokens = response.usage
            input_t  = getattr(tokens, "input_tokens",  None)
            output_t = getattr(tokens, "output_tokens", None)
            # Older Cohere format
            if input_t is None and hasattr(tokens, "billed_units"):
                input_t  = getattr(tokens.billed_units, "input_tokens",  0)
                output_t = getattr(tokens.billed_units, "output_tokens", 0)
            return (input_t or 0, output_t or 0)
    except Exception:
        pass
    return 0, 0


def _record(provider, model, p, c, duration_ms, caller, prompt_preview):
    """Convenience wrapper around session.record_call"""
    get_session().record_call(
        provider          = provider,
        model             = model,
        prompt_tokens     = p,
        completion_tokens = c,
        duration_ms       = duration_ms,
        caller_frame      = caller,
        prompt_preview    = prompt_preview,
    )


# ═══════════════════════════════════════════════════════════════════════════
# OPENAI PATCHER — chat + embeddings
# ═══════════════════════════════════════════════════════════════════════════

def patch_openai():
    global _patched
    if _patched["openai"]:
        return

    try:
        from openai.resources.chat.completions import Completions  # type: ignore[import]

        _orig = Completions.create

        @functools.wraps(_orig)
        def _sync(self_obj, *args, **kwargs):
            caller = get_caller_frame()
            prev   = _extract_prompt_preview(kwargs.get("messages", []))
            model  = kwargs.get("model", "gpt-4")
            t0     = time.time()
            resp   = _orig(self_obj, *args, **kwargs)
            p, c   = _openai_tokens(resp)
            _record("openai", model, p, c, (time.time()-t0)*1000, caller, prev)
            return resp

        Completions.create = _sync

        try:
            from openai.resources.chat.completions import AsyncCompletions  # type: ignore[import]
            _orig_a = AsyncCompletions.create

            @functools.wraps(_orig_a)
            async def _async(self_obj, *args, **kwargs):
                caller = get_caller_frame()
                prev   = _extract_prompt_preview(kwargs.get("messages", []))
                model  = kwargs.get("model", "gpt-4")
                t0     = time.time()
                resp   = await _orig_a(self_obj, *args, **kwargs)
                p, c   = _openai_tokens(resp)
                _record("openai", model, p, c, (time.time()-t0)*1000, caller, prev)
                return resp

            AsyncCompletions.create = _async
        except (ImportError, AttributeError):
            pass

        _patched["openai"] = True

    except ImportError:
        pass
    except Exception:
        pass

    # ── OpenAI Embeddings ────────────────────────────────────────────────
    try:
        from openai.resources.embeddings import Embeddings  # type: ignore[import]

        _orig_embed = Embeddings.create

        @functools.wraps(_orig_embed)
        def _sync_embed(self_obj, *args, **kwargs):
            caller = get_caller_frame()
            model  = kwargs.get("model", "text-embedding-3-small")
            # input can be str or list
            inp    = kwargs.get("input", "")
            prev   = (inp[:80] if isinstance(inp, str)
                      else inp[0][:80] if isinstance(inp, list) and inp else "")
            t0     = time.time()
            resp   = _orig_embed(self_obj, *args, **kwargs)
            # Embeddings usage: prompt_tokens only
            p      = getattr(getattr(resp, "usage", None), "prompt_tokens", 0) or 0
            _record("openai", model, p, 0, (time.time()-t0)*1000, caller, str(prev))
            return resp

        Embeddings.create = _sync_embed

    except (ImportError, AttributeError):
        pass
    except Exception:
        pass


# ═══════════════════════════════════════════════════════════════════════════
# ANTHROPIC PATCHER
# ═══════════════════════════════════════════════════════════════════════════

def patch_anthropic():
    global _patched
    if _patched["anthropic"]:
        return

    try:
        from anthropic.resources.messages import Messages  # type: ignore[import]

        _orig = Messages.create

        @functools.wraps(_orig)
        def _sync(self_obj, *args, **kwargs):
            caller = get_caller_frame()
            prev   = _extract_prompt_preview(kwargs.get("messages", []))
            model  = kwargs.get("model", "claude-3-sonnet-20240229")
            t0     = time.time()
            resp   = _orig(self_obj, *args, **kwargs)
            p, c   = _anthropic_tokens(resp)
            _record("anthropic", model, p, c, (time.time()-t0)*1000, caller, prev)
            return resp

        Messages.create = _sync

        try:
            from anthropic.resources.messages import AsyncMessages  # type: ignore[import]
            _orig_a = AsyncMessages.create

            @functools.wraps(_orig_a)
            async def _async(self_obj, *args, **kwargs):
                caller = get_caller_frame()
                prev   = _extract_prompt_preview(kwargs.get("messages", []))
                model  = kwargs.get("model", "claude-3-sonnet-20240229")
                t0     = time.time()
                resp   = await _orig_a(self_obj, *args, **kwargs)
                p, c   = _anthropic_tokens(resp)
                _record("anthropic", model, p, c, (time.time()-t0)*1000, caller, prev)
                return resp

            AsyncMessages.create = _async
        except (ImportError, AttributeError):
            pass

        _patched["anthropic"] = True

    except ImportError:
        pass
    except Exception:
        pass


# ═══════════════════════════════════════════════════════════════════════════
# GROQ PATCHER
# Strategy 1: resource class (groq >= 0.4)
# Strategy 2: patch Groq client __init__ (newer groq)
# ═══════════════════════════════════════════════════════════════════════════

def patch_groq():
    global _patched
    if _patched["groq"]:
        return

    try:
        from groq.resources.chat.completions import Completions as GC  # type: ignore[import]

        _orig = GC.create

        @functools.wraps(_orig)
        def _sync(self_obj, *args, **kwargs):
            caller = get_caller_frame()
            prev   = _extract_prompt_preview(kwargs.get("messages", []))
            model  = kwargs.get("model", "llama-3.1-8b-instant")
            t0     = time.time()
            resp   = _orig(self_obj, *args, **kwargs)
            p, c   = _openai_tokens(resp)
            _record("groq", model, p, c, (time.time()-t0)*1000, caller, prev)
            return resp

        GC.create = _sync

        try:
            from groq.resources.chat.completions import AsyncCompletions as GAC  # type: ignore[import]
            _orig_a = GAC.create

            @functools.wraps(_orig_a)
            async def _async(self_obj, *args, **kwargs):
                caller = get_caller_frame()
                prev   = _extract_prompt_preview(kwargs.get("messages", []))
                model  = kwargs.get("model", "llama-3.1-8b-instant")
                t0     = time.time()
                resp   = await _orig_a(self_obj, *args, **kwargs)
                p, c   = _openai_tokens(resp)
                _record("groq", model, p, c, (time.time()-t0)*1000, caller, prev)
                return resp

            GAC.create = _async
        except (ImportError, AttributeError):
            pass

        _patched["groq"] = True
        return

    except (ImportError, AttributeError):
        pass
    except Exception:
        pass

    # Strategy 2: patch via Groq() __init__
    try:
        import groq as _groq_module  # type: ignore[import]

        GroqClient = getattr(_groq_module, "Groq", None)
        if GroqClient is None:
            return

        _orig_init = GroqClient.__init__

        @functools.wraps(_orig_init)
        def _patched_init(self_client, *args, **kwargs):
            _orig_init(self_client, *args, **kwargs)
            try:
                comp    = self_client.chat.completions
                _orig_c = comp.create

                @functools.wraps(_orig_c)
                def _inst_create(*a, **kw):
                    caller = get_caller_frame()
                    prev   = _extract_prompt_preview(kw.get("messages", []))
                    model  = kw.get("model", "llama-3.1-8b-instant")
                    t0     = time.time()
                    resp   = _orig_c(*a, **kw)
                    p, c   = _openai_tokens(resp)
                    _record("groq", model, p, c, (time.time()-t0)*1000, caller, prev)
                    return resp

                comp.create = _inst_create

                if hasattr(comp, "acreate"):
                    _orig_ac = comp.acreate

                    @functools.wraps(_orig_ac)
                    async def _inst_acreate(*a, **kw):
                        caller = get_caller_frame()
                        prev   = _extract_prompt_preview(kw.get("messages", []))
                        model  = kw.get("model", "llama-3.1-8b-instant")
                        t0     = time.time()
                        resp   = await _orig_ac(*a, **kw)
                        p, c   = _openai_tokens(resp)
                        _record("groq", model, p, c, (time.time()-t0)*1000, caller, prev)
                        return resp

                    comp.acreate = _inst_acreate

            except (AttributeError, TypeError):
                pass

        GroqClient.__init__ = _patched_init
        _patched["groq"] = True

    except ImportError:
        pass
    except Exception:
        pass


# ═══════════════════════════════════════════════════════════════════════════
# GEMINI PATCHER
# google-generativeai uses GenerativeModel.generate_content
# ═══════════════════════════════════════════════════════════════════════════

def patch_gemini():
    global _patched
    if _patched["gemini"]:
        return

    try:
        import google.genai as genai  # type: ignore[import]

        GenerativeModel = getattr(genai, "GenerativeModel", None)
        if GenerativeModel is None:
            return

        _orig_generate = GenerativeModel.generate_content

        @functools.wraps(_orig_generate)
        def _sync(self_obj, *args, **kwargs):
            caller = get_caller_frame()
            model  = getattr(self_obj, "model_name", "gemini-1.5-flash") or "gemini-1.5-flash"
            # Normalize model name (strip "models/" prefix)
            model  = model.replace("models/", "")
            # Extract prompt preview
            contents = args[0] if args else kwargs.get("contents", "")
            prev     = _extract_prompt_preview(
                contents if isinstance(contents, list) else str(contents)
            )
            t0   = time.time()
            resp = _orig_generate(self_obj, *args, **kwargs)
            p, c = _gemini_tokens(resp)
            _record("gemini", model, p, c, (time.time()-t0)*1000, caller, prev[:80])
            return resp

        GenerativeModel.generate_content = _sync

        # async
        _orig_async = getattr(GenerativeModel, "generate_content_async", None)
        if _orig_async:
            @functools.wraps(_orig_async)
            async def _async(self_obj, *args, **kwargs):
                caller = get_caller_frame()
                model  = getattr(self_obj, "model_name", "gemini-1.5-flash") or "gemini-1.5-flash"
                model  = model.replace("models/", "")
                contents = args[0] if args else kwargs.get("contents", "")
                prev     = _extract_prompt_preview(
                    contents if isinstance(contents, list) else str(contents)
                )
                t0   = time.time()
                resp = await _orig_async(self_obj, *args, **kwargs)
                p, c = _gemini_tokens(resp)
                _record("gemini", model, p, c, (time.time()-t0)*1000, caller, prev[:80])
                return resp

            GenerativeModel.generate_content_async = _async

        _patched["gemini"] = True

    except ImportError:
        pass
    except Exception:
        pass


# ═══════════════════════════════════════════════════════════════════════════
# MISTRAL PATCHER
# mistralai SDK uses client.chat.complete / client.chat.complete_async
# ═══════════════════════════════════════════════════════════════════════════

def patch_mistral():
    global _patched
    if _patched["mistral"]:
        return

    try:
        from mistralai import Mistral  # type: ignore[import]

        _orig_init = Mistral.__init__

        @functools.wraps(_orig_init)
        def _patched_init(self_client, *args, **kwargs):
            _orig_init(self_client, *args, **kwargs)

            try:
                # Patch sync complete
                _orig_complete = self_client.chat.complete

                @functools.wraps(_orig_complete)
                def _sync_complete(*a, **kw):
                    caller = get_caller_frame()
                    prev   = _extract_prompt_preview(kw.get("messages", []))
                    model  = kw.get("model", "mistral-small")
                    t0     = time.time()
                    resp   = _orig_complete(*a, **kw)
                    p, c   = _mistral_tokens(resp)
                    _record("mistral", model, p, c, (time.time()-t0)*1000, caller, prev)
                    return resp

                self_client.chat.complete = _sync_complete

                # Patch async complete
                if hasattr(self_client.chat, "complete_async"):
                    _orig_async = self_client.chat.complete_async

                    @functools.wraps(_orig_async)
                    async def _async_complete(*a, **kw):
                        caller = get_caller_frame()
                        prev   = _extract_prompt_preview(kw.get("messages", []))
                        model  = kw.get("model", "mistral-small")
                        t0     = time.time()
                        resp   = await _orig_async(*a, **kw)
                        p, c   = _mistral_tokens(resp)
                        _record("mistral", model, p, c, (time.time()-t0)*1000, caller, prev)
                        return resp

                    self_client.chat.complete_async = _async_complete

            except (AttributeError, TypeError):
                pass

        Mistral.__init__ = _patched_init
        _patched["mistral"] = True

    except ImportError:
        pass
    except Exception:
        pass


# ═══════════════════════════════════════════════════════════════════════════
# COHERE PATCHER
# cohere SDK uses ClientV2.chat
# ═══════════════════════════════════════════════════════════════════════════

def patch_cohere():
    global _patched
    if _patched["cohere"]:
        return

    try:
        import cohere  # type: ignore[import]

        # Try ClientV2 first (newer), fall back to Client
        CohereClient = getattr(cohere, "ClientV2", None) or getattr(cohere, "Client", None)
        if CohereClient is None:
            return

        _orig_init = CohereClient.__init__

        @functools.wraps(_orig_init)
        def _patched_init(self_client, *args, **kwargs):
            _orig_init(self_client, *args, **kwargs)

            try:
                _orig_chat = self_client.chat

                @functools.wraps(_orig_chat)
                def _sync_chat(*a, **kw):
                    caller = get_caller_frame()
                    model  = kw.get("model", "command-r")
                    # Cohere messages format
                    msgs   = kw.get("messages", [])
                    prev   = _extract_prompt_preview(msgs)
                    t0     = time.time()
                    resp   = _orig_chat(*a, **kw)
                    p, c   = _cohere_tokens(resp)
                    _record("cohere", model, p, c, (time.time()-t0)*1000, caller, prev)
                    return resp

                self_client.chat = _sync_chat

                # Cohere embed
                if hasattr(self_client, "embed"):
                    _orig_embed = self_client.embed

                    @functools.wraps(_orig_embed)
                    def _sync_embed(*a, **kw):
                        caller = get_caller_frame()
                        model  = kw.get("model", "embed-english-v3.0")
                        texts  = kw.get("texts", [])
                        prev   = texts[0][:80] if texts else ""
                        t0     = time.time()
                        resp   = _orig_embed(*a, **kw)
                        # Cohere embed has no token count in response
                        # Estimate from input texts
                        total_chars = sum(len(t) for t in texts)
                        p = max(1, total_chars // 4)
                        _record("cohere", model, p, 0, (time.time()-t0)*1000, caller, str(prev))
                        return resp

                    self_client.embed = _sync_embed

            except (AttributeError, TypeError):
                pass

        CohereClient.__init__ = _patched_init
        _patched["cohere"] = True

    except ImportError:
        pass
    except Exception:
        pass


# ═══════════════════════════════════════════════════════════════════════════
# PATCH ALL
# ═══════════════════════════════════════════════════════════════════════════

def patch_all():
    """
    Patch all installed AI libraries.
    Called automatically when `import aioptimize` runs.
    Each library is fully independent — failure in one never affects others.
    """
    patch_openai()
    patch_anthropic()
    patch_groq()
    patch_gemini()
    patch_mistral()
    patch_cohere()


def get_patch_status() -> dict:
    """Return dict showing which libraries were successfully patched"""
    return dict(_patched)