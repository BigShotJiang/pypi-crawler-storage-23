"""
Configuration for AIOptimize SDK.
"""

from dataclasses import dataclass
from typing import Optional


@dataclass
class AIOptimizeConfig:
    """
    User configuration for AIOptimize SDK.
    
    Provides context to improve recommendations and enables data sharing.
    
    Args:
        user_id: Unique identifier for the user/company
        industry: Industry type (e.g., "saas", "ecommerce", "healthcare")
        company_size: Company size (e.g., "startup", "mid", "enterprise")
        use_case: Primary use case (e.g., "customer_support", "rag", "content")
        share_data: Share anonymized data to improve recommendations
        share_prompts: Share actual prompts (always False for privacy)
    
    Example:
        >>> config = AIOptimizeConfig(
        ...     user_id="company-abc",
        ...     industry="saas",
        ...     company_size="startup",
        ...     use_case="customer_support",
        ...     share_data=True
        ... )
        >>> 
        >>> @track_cost(model="gpt-4", config=config)
        >>> def my_function(prompt):
        ...     return openai.create(...)
    """
    
    # Required
    user_id: str
    
    # Optional context (helps personalize recommendations)
    industry: str = "unknown"
    company_size: str = "unknown"
    use_case: str = "unknown"
    
    # Privacy controls
    share_data: bool = True  # Share anonymized usage data
    share_prompts: bool = True  # Never share actual prompts (privacy-first)
    
    def __post_init__(self):
        """Validate configuration"""
        if not self.user_id:
            raise ValueError("user_id is required")
        
        # # Ensure share_prompts is always False (privacy protection)
        # if self.share_prompts:
        #     print("⚠️  Warning: share_prompts forced to False for privacy")
        #     self.share_prompts = False