"""
AIOptimize SDK
==============

AI cost optimization SDK for Python.
Automatically reduces LLM API costs through smart model selection,
context optimization, loop detection, and intelligent caching.

QUICK START:
    # Audit existing code
    from aioptimize import GroqAuditor
    auditor = GroqAuditor()
    report = auditor.audit_code(open("mycode.py").read())

    # Track agent workflows
    from aioptimize import track_agent, AgentStep
    @track_agent(agent_name="My Agent")
    async def my_agent(query, _agent_session=None):
        pass

    # Smart model selection
    from aioptimize import GroqModelSelector
    selector = GroqModelSelector()
    model_id, complexity, info = selector.select_model(my_code)

VERSION: 1.0.0
AUTHOR: AIOptimize Team
"""

# ═══════════════════════════════════════════════════════════════════════════
# VERSION
# ═══════════════════════════════════════════════════════════════════════════

__version__ = "1.0.0"
__author__ = "AIOptimize Team"
__description__ = "AI cost optimization SDK - reduce LLM API costs automatically"


# ═══════════════════════════════════════════════════════════════════════════
# MAGIC MODE - Runs automatically on "import aioptimize"
# Patches OpenAI, Anthropic, Groq silently in background.
# User's code works exactly the same — we just intercept calls.
# ═══════════════════════════════════════════════════════════════════════════

from llmoptimize_core.llmoptimized.magic import get_session, reset_session
from .patcher import patch_all, get_patch_status

# Patch all installed AI libraries right now
patch_all()


# ── Public magic mode API ─────────────────────────────────────────────────

def report(save_to: str = None):
    """
    Print full cost report for all AI calls made so far.

    Shows:
    - Total cost + tokens
    - Every call with file:line number
    - Most expensive call
    - Savings opportunities per line
    - Free tier usage

    Usage:
        import aioptimize
        import openai

        response = openai.chat.completions.create(...)

        aioptimize.report()               # print to console
        aioptimize.report("report.json")  # also save to file
    """
    session = get_session()
    session.print_report()
    if save_to:
        session.save_report(save_to)


def configure(
    verbose: bool = False,
    auto_optimize: bool = False,
    show_report: bool = False,
    save_report: str = None,
    license_key: str = None,
):
    """
    Configure magic mode behaviour.

    Args:
        verbose:      Print each call live as it happens
        auto_optimize: Auto-switch to cheaper model when confident
        show_report:  Print report automatically at script end
        save_report:  Save report to this JSON file at end
        license_key:  Activate paid tier

    Usage:
        import aioptimize
        aioptimize.configure(verbose=True, auto_optimize=True)
    """
    import atexit

    session = get_session()
    session.verbose       = verbose
    session.auto_optimize = auto_optimize

    if license_key:
        session.license_key = license_key

    if show_report:
        atexit.register(session.print_report)

    if save_report:
        atexit.register(session.save_report, save_report)


def verbose():
    """
    Enable live feed — shows each call as it happens.

    Usage:
        import aioptimize
        aioptimize.verbose()
    """
    get_session().verbose = True


def optimize():
    """
    Enable smart mode — suggests + auto-switches to cheaper models.

    Usage:
        import aioptimize
        aioptimize.optimize()
    """
    get_session().auto_optimize = True


def activate(license_key: str):
    """
    Activate paid tier with a license key.

    Usage:
        import aioptimize
        aioptimize.activate("sk_live_abc123")

        # Or via CLI:
        # aioptimize activate sk_live_abc123

        # Or via env var:
        # AIOPTIMIZE_LICENSE_KEY=sk_live_abc123
    """
    import json
    import os

    session = get_session()
    session.license_key = license_key

    # Persist key
    try:
        usage_dir  = os.path.expanduser("~/.aioptimize")
        usage_file = os.path.join(usage_dir, "usage.json")
        os.makedirs(usage_dir, exist_ok=True)
        data = {}
        if os.path.exists(usage_file):
            with open(usage_file) as f:
                data = json.load(f)
        data["license_key"] = license_key
        with open(usage_file, "w") as f:
            json.dump(data, f, indent=2)
        print(f"✅ AIOptimize activated! Unlimited calls enabled.")
    except Exception:
        print(f"✅ AIOptimize activated for this session.")


def reset():
    """
    Clear all recorded calls and start fresh.

    Usage:
        aioptimize.reset()   # clear history, keep patches
    """
    get_session().reset()


def status():
    """
    Show which libraries are being tracked.

    Usage:
        aioptimize.status()
    """
    patches = get_patch_status()
    session = get_session()

    print("\n🤖 AIOptimize Status")
    print("─" * 30)
    for lib, patched in patches.items():
        icon = "✅" if patched else "⚪"
        print(f"  {icon} {lib}")
    print(f"\n  Calls recorded:  {len(session.calls)}")
    print(f"  Total cost:      ${session.total_cost:.6f}")
    licensed = "✅ Licensed" if session._is_licensed() else f"{session.free_calls_used}/100 free"
    print(f"  License:         {licensed}")
    print()


# ═══════════════════════════════════════════════════════════════════════════
# CORE - Data structures and configuration
# ═══════════════════════════════════════════════════════════════════════════

try:
    from .models import (
        OptimizationRecommendation,
        CostEstimate,
        ModelComparison,
    )
except ImportError:
    pass

try:
    from .config import (
        AIOptimizeConfig,
        IndustryConfig,
        UserConfig,
        BudgetConfig,
    )
except ImportError:
    pass

try:
    from llmoptimize_core.llmoptimized.calculator import CostCalculator
except ImportError:
    pass


# ═══════════════════════════════════════════════════════════════════════════
# ANALYZERS
# ═══════════════════════════════════════════════════════════════════════════

try:
    from .heuristic_analyzer import HeuristicAnalyzer
except ImportError:
    pass

try:
    from .rag_analyzer import RAGAnalyzer
except ImportError:
    pass

try:
    from .llm_analyzer import LLMAnalyzer
except ImportError:
    pass

try:
    from .smart_analyzer import SmartAnalyzer
except ImportError:
    pass


# ═══════════════════════════════════════════════════════════════════════════
# GUARDRAILS + TRACKING
# ═══════════════════════════════════════════════════════════════════════════

try:
    from .guardrail import Guardrails
except ImportError:
    pass

try:
    from .tracker import track, OptimizationTracker
except ImportError:
    pass

try:
    from .ml_trainer import MLTrainer
except ImportError:
    pass

try:
    from .data_collector import DataCollector
except ImportError:
    pass


# ═══════════════════════════════════════════════════════════════════════════
# CACHE SYSTEM (Foundation - import first)
# ═══════════════════════════════════════════════════════════════════════════

from .cache_manager import (
    CacheManager,
    PatternCache,
    get_cache,
    get_pattern_cache,
)


# ═══════════════════════════════════════════════════════════════════════════
# AGENT SUPPORT
# ═══════════════════════════════════════════════════════════════════════════

from .agent_tracker import (
    AgentWorkflowTracker,
    StepType,
)

from .agent_classifier import AgentStepClassifier

from .loop_detector import (
    LoopDetector,
    LoopPrevention,
    LoopPattern,
)

from .context_optimizer import (
    ContextWindowOptimizer,
    ContextChunk,
)

from .groq_model_selector import GroqModelSelector

from .agent_decorator import (
    track_agent,
    AgentSession,
    AgentStep,
    LoopBlockedException,
)


# ═══════════════════════════════════════════════════════════════════════════
# AI AUDITING
# ═══════════════════════════════════════════════════════════════════════════

from .aiauditor import AIAuditor
from .cloud_sync_collector import CloudSyncCollector, get_collector

from .groq_auditor import GroqAuditor

from .report_formatter import (
    format_audit_report,
    format_comparison_table,
    format_quick_summary,
)


# ═══════════════════════════════════════════════════════════════════════════
# FRAMEWORK INTEGRATIONS (optional - only if installed)
# ═══════════════════════════════════════════════════════════════════════════

try:
    from .integrations.langchain_integration import LangChainOptimizer
    _has_langchain = True
except (ImportError, NameError):
    _has_langchain = False
    LangChainOptimizer = None

try:
    from .integrations.crewai_integration import CrewAIOptimizer
    _has_crewai = True
except (ImportError, NameError):
    _has_crewai = False
    CrewAIOptimizer = None


# ═══════════════════════════════════════════════════════════════════════════
# CONVENIENCE FUNCTIONS
# ═══════════════════════════════════════════════════════════════════════════

def audit(code: str, provider: str = "groq", filename: str = None):
    """
    Quick one-line audit of Python code.

    Usage:
        from aioptimize import audit
        report = audit(open("mycode.py").read())

    Args:
        code: Python code string to analyze
        provider: "groq" or "claude_haiku"
        filename: Optional filename for context

    Returns:
        Audit report dict with issues and recommendations
    """
    if provider == "groq":
        auditor = GroqAuditor(enable_cache=True)
    else:
        auditor = AIAuditor(ai_provider=provider, enable_cache=True)

    return auditor.audit_code(code, filename=filename)


def select_model(code: str, explain: bool = False):
    """
    Quick one-line model selection for code.

    Usage:
        from aioptimize import select_model
        model_id, complexity, info = select_model(my_code)

    Args:
        code: Python code to analyze
        explain: Print selection reasoning

    Returns:
        (model_id, complexity_level, model_info)
    """
    selector = GroqModelSelector(enable_cache=True)
    return selector.select_model(code, explain=explain)


def clear_cache(namespace: str = None):
    """
    Clear cached results.

    Usage:
        from aioptimize import clear_cache
        clear_cache()               # Clear all
        clear_cache("ai_auditor")   # Clear specific namespace

    Args:
        namespace: Specific namespace to clear (None = clear all)
    """
    cache = get_pattern_cache()
    if namespace:
        cache.clear_namespace(namespace)
        print(f"✅ Cache cleared: {namespace}")
    else:
        cache.clear_all()
        print("✅ All caches cleared")


def get_stats(namespace: str = None):
    """
    Get cache and usage statistics.

    Usage:
        from aioptimize import get_stats
        stats = get_stats()
        print(stats)

    Args:
        namespace: Specific namespace (None = all)

    Returns:
        Statistics dict
    """
    cache = get_pattern_cache()
    return cache.get_stats(namespace)


# ═══════════════════════════════════════════════════════════════════════════
# PUBLIC API - What gets exported with "from aioptimize import *"
# ═══════════════════════════════════════════════════════════════════════════

__all__ = [

    # ── VERSION ──
    "__version__",
    "__author__",

    # ── MAGIC MODE (primary API) ──
    "report",
    "configure",
    "verbose",
    "optimize",
    "activate",
    "reset",
    "status",

    # ── CONVENIENCE ──
    "audit",
    "select_model",
    "clear_cache",
    "get_stats",

    # ── CACHE SYSTEM ──
    "CacheManager",
    "PatternCache",
    "get_cache",
    "get_pattern_cache",

    # ── AGENT SUPPORT ──
    "AgentWorkflowTracker",
    "StepType",
    "AgentStepClassifier",
    "LoopDetector",
    "LoopPrevention",
    "LoopPattern",
    "ContextWindowOptimizer",
    "ContextChunk",
    "GroqModelSelector",

    # ── AGENT DECORATOR (main entry point) ──
    "track_agent",
    "AgentSession",
    "AgentStep",
    "LoopBlockedException",

    # ── CLOUD SYNC ──
    "CloudSyncCollector",
    "get_collector",

    # ── AI AUDITING ──
    "AIAuditor",
    "GroqAuditor",
    "format_audit_report",
    "format_comparison_table",
    "format_quick_summary",
]

# Add core exports if available
_optional_core = [
    "OptimizationRecommendation", "CostEstimate", "ModelComparison",
    "AIOptimizeConfig", "IndustryConfig", "UserConfig", "BudgetConfig",
    "CostCalculator", "HeuristicAnalyzer", "RAGAnalyzer",
    "LLMAnalyzer", "SmartAnalyzer", "Guardrails",
    "track", "OptimizationTracker", "MLTrainer", "DataCollector",
]

for _name in _optional_core:
    if _name in dir():
        __all__.append(_name)

# Add integrations if available
if _has_langchain:
    __all__.append("LangChainOptimizer")
if _has_crewai:
    __all__.append("CrewAIOptimizer")


# ═══════════════════════════════════════════════════════════════════════════
# STARTUP MESSAGE (only shown in interactive mode)
# ═══════════════════════════════════════════════════════════════════════════

def _print_welcome():
    """Print welcome message with quick start guide"""
    print(f"""
╔══════════════════════════════════════════════════════════════╗
║           AIOptimize SDK v{__version__} - Ready!                   ║
╚══════════════════════════════════════════════════════════════╝

Quick Start:
  # Audit code
  from aioptimize import audit
  report = audit(open("mycode.py").read())

  # Track agent
  from aioptimize import track_agent
  @track_agent(agent_name="My Agent")
  async def my_agent(query, _agent_session=None):
      pass

  # Select model
  from aioptimize import select_model
  model_id, level, info = select_model(my_code)

Docs: https://github.com/hackrudra1234/aioptimize
""")