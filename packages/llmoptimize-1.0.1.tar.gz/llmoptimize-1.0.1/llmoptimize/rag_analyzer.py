"""
RAG-specific optimization analyzer.

RAG (Retrieval-Augmented Generation) is the most common AI agent pattern.
This analyzer provides specialized optimizations for RAG use cases.
"""

from typing import Optional, Dict, List
from .models import Recommendation
from ..aioptimize_core.aioptimized.calculator import (
    MODEL_PRICING, MODEL_ALTERNATIVES, is_embedding_model, 
    calculate_cost, EMBEDDING_MODELS
)


class RAGAnalyzer:
    """
    Specialized analyzer for RAG (Retrieval-Augmented Generation) patterns.
    
    RAG applications typically:
    1. Generate embeddings for documents
    2. Retrieve relevant chunks based on query
    3. Pass chunks + query to LLM
    4. Generate response
    
    Each step has optimization opportunities.
    """
    
    def __init__(self):
        """Initialize with access to full model database."""
        # Build expensive models list dynamically
        self.expensive_models = self._build_expensive_models_list()
    
    def _build_expensive_models_list(self) -> List[str]:
        """
        Build list of expensive models from pricing database.
        
        A model is "expensive" if:
        - Input cost >= $0.003 per 1K tokens, OR
        - It's a premium model (GPT-4, Claude Opus, o1, etc.)
        """
        expensive = []
        
        for model, pricing in MODEL_PRICING.items():
            # Skip embedding models
            if is_embedding_model(model):
                continue
            
            input_cost = pricing.get("input", 0)
            
            # High cost models
            if input_cost >= 0.003:
                expensive.append(model)
            # Premium branded models
            elif any(keyword in model for keyword in [
                "gpt-4", "claude-3-opus", "claude-3-5-sonnet",
                "o1", "o3", "gemini-pro", "mistral-large"
            ]):
                expensive.append(model)
        
        return expensive
    
    def _get_cheap_alternative(self, current_model: str) -> str:
        """
        Get cheapest alternative for current model.
        
        Uses MODEL_ALTERNATIVES from calculator for consistency.
        """
        alternatives = MODEL_ALTERNATIVES.get(current_model, [])
        
        if not alternatives:
            # Fallback defaults based on provider
            if "gpt-4" in current_model or "gpt-3.5" in current_model:
                return "gpt-3.5-turbo"
            elif "claude" in current_model:
                return "claude-3-haiku"
            elif "gemini" in current_model:
                return "gemini-1.5-flash"
            elif "mistral" in current_model:
                return "mistral-small"
            elif "command" in current_model:
                return "command-light"
            else:
                return "gpt-3.5-turbo"  # Universal fallback
        
        # Return first (cheapest) alternative
        return alternatives[0]
    
    def analyze_rag_call(
        self,
        prompt: str,
        current_model: str,
        prompt_length: Optional[int] = None,
        estimated_tokens: Optional[int] = None
    ) -> Optional[Recommendation]:
        """
        Analyze a potential RAG call for optimization opportunities.
        
        Args:
            prompt: The full prompt (may include retrieved context)
            current_model: Current model being used
            prompt_length: Character length of prompt
            estimated_tokens: Estimated token count
            
        Returns:
            Recommendation if RAG pattern detected and optimization possible
        """
        
        # Only analyze expensive models
        if current_model not in self.expensive_models:
            return None
        
        # Detect if this is a RAG pattern
        is_rag, rag_confidence = self._detect_rag_pattern(
            prompt, prompt_length, estimated_tokens
        )
        
        if not is_rag:
            return None
        
        # Analyze query type
        query_type = self._classify_rag_query(prompt)
        
        # Generate recommendation based on query type
        return self._generate_rag_recommendation(
            prompt, current_model, query_type, estimated_tokens, rag_confidence
        )
    
    def _detect_rag_pattern(
        self,
        prompt: str,
        prompt_length: Optional[int],
        estimated_tokens: Optional[int]
    ) -> tuple:
        """
        Detect if this looks like a RAG call.
        
        Returns:
            (is_rag: bool, confidence: float)
        """
        
        indicators = []
        prompt_lower = prompt.lower()
        
        # Indicator 1: Very long prompts (likely includes retrieved context)
        length = prompt_length or len(prompt)
        if length > 2000:
            indicators.append(("long_prompt", 0.8))
        elif length > 1000:
            indicators.append(("medium_prompt", 0.5))
        
        # Indicator 2: High token count
        if estimated_tokens and estimated_tokens > 1500:
            indicators.append(("high_tokens", 0.8))
        elif estimated_tokens and estimated_tokens > 800:
            indicators.append(("medium_tokens", 0.5))
        
        # Indicator 3: RAG-specific phrases
        rag_phrases = [
            "based on the document",
            "according to the context",
            "from the provided text",
            "using the information",
            "in the passage",
            "the document states",
            "as mentioned in",
            "referring to the text"
        ]
        
        for phrase in rag_phrases:
            if phrase in prompt_lower:
                indicators.append(("rag_phrase", 0.9))
                break
        
        # Indicator 4: Question + context structure
        if "?" in prompt and length > 500:
            # Likely question with context
            indicators.append(("question_with_context", 0.6))
        
        # Indicator 5: Multiple paragraphs/sections
        paragraph_count = prompt.count('\n\n')
        if paragraph_count > 3:
            indicators.append(("structured_context", 0.7))
        
        # Calculate overall confidence
        if not indicators:
            return False, 0.0
        
        # Weighted average of indicators
        total_confidence = sum(conf for _, conf in indicators)
        avg_confidence = total_confidence / len(indicators)
        
        # Need at least 0.5 confidence to classify as RAG
        is_rag = avg_confidence >= 0.5
        
        return is_rag, avg_confidence
    
    def _classify_rag_query(self, prompt: str) -> str:
        """
        Classify the type of RAG query.
        
        Returns:
            "simple_extraction", "factual_lookup", "summarization",
            "comparison", "complex_reasoning"
        """
        
        prompt_lower = prompt.lower()
        
        # Simple extraction
        extraction_keywords = [
            "extract", "find", "get", "retrieve", "list",
            "identify", "locate", "pull out"
        ]
        if any(kw in prompt_lower for kw in extraction_keywords):
            return "simple_extraction"
        
        # Summarization
        summary_keywords = [
            "summarize", "summary", "summarise", "tldr",
            "brief", "overview", "key points", "main ideas"
        ]
        if any(kw in prompt_lower for kw in summary_keywords):
            return "summarization"
        
        # Comparison
        comparison_keywords = [
            "compare", "contrast", "difference", "versus",
            "vs", "similarities", "how does"
        ]
        if any(kw in prompt_lower for kw in comparison_keywords):
            return "comparison"
        
        # Factual lookup (questions)
        question_words = ["what", "who", "when", "where", "which"]
        if any(prompt_lower.startswith(qw) for qw in question_words):
            return "factual_lookup"
        
        # Complex reasoning (default if nothing else matches)
        reasoning_keywords = [
            "analyze", "evaluate", "assess", "determine",
            "predict", "recommend", "suggest", "why"
        ]
        if any(kw in prompt_lower for kw in reasoning_keywords):
            return "complex_reasoning"
        
        # Default
        return "factual_lookup"
    
    def _generate_rag_recommendation(
        self,
        prompt: str,
        current_model: str,
        query_type: str,
        estimated_tokens: Optional[int],
        rag_confidence: float
    ) -> Recommendation:
        """
        Generate specific recommendation for RAG query using real calculator.
        """
        
        suggested_model = self._get_cheap_alternative(current_model)
        
        # Adjust confidence based on query type
        if query_type == "simple_extraction":
            confidence = min(0.95, rag_confidence + 0.15)
            reasoning = f"RAG query - simple extraction from provided context. {suggested_model} excels at finding information in given text. {current_model}'s advanced reasoning not needed."
            quality_impact = "none"
            
        elif query_type == "factual_lookup":
            confidence = min(0.90, rag_confidence + 0.10)
            reasoning = f"RAG factual lookup with context provided. Answer is in the retrieved documents - {suggested_model} can extract it accurately."
            quality_impact = "minimal"
            
        elif query_type == "summarization":
            confidence = min(0.88, rag_confidence + 0.08)
            reasoning = f"RAG summarization from retrieved chunks. {suggested_model} handles summarization well at fraction of cost."
            quality_impact = "minimal"
            
        elif query_type == "comparison":
            confidence = min(0.80, rag_confidence + 0.05)
            reasoning = f"RAG comparison task with provided context. {suggested_model} can compare information from chunks effectively."
            quality_impact = "minimal"
            
        else:  # complex_reasoning
            confidence = min(0.65, rag_confidence)
            reasoning = f"RAG query requiring complex reasoning. Consider if {current_model} is truly needed or if {suggested_model} with good context is sufficient."
            quality_impact = "moderate"
        
        # Calculate costs using real calculator
        avg_context_tokens = estimated_tokens or 2000
        avg_output_tokens = 200
        
        try:
            estimated_current = calculate_cost(current_model, avg_context_tokens, avg_output_tokens)
            estimated_suggested = calculate_cost(suggested_model, avg_context_tokens, avg_output_tokens)
            
            estimated_savings = estimated_current - estimated_suggested
            savings_percent = int((estimated_savings / estimated_current * 100)) if estimated_current > 0 else 0
        except Exception:
            # Fallback if calculate_cost fails
            estimated_current = 0.06
            estimated_suggested = 0.002
            estimated_savings = 0.058
            savings_percent = 97
        
        return Recommendation(
            should_switch=confidence >= 0.7,
            current_model=current_model,
            suggested_model=suggested_model,
            confidence=confidence,
            reasoning=reasoning,
            quality_impact=quality_impact,
            estimated_current_cost=estimated_current,
            estimated_suggested_cost=estimated_suggested,
            estimated_savings=estimated_savings,
            estimated_savings_percent=savings_percent,
            based_on="rag_analyzer",
            analysis_time_ms=3
        )
    
    def analyze_embedding_optimization(self, embedding_model: str) -> Optional[Dict]:
        """
        Analyze embedding model for cost optimization using full database.
        
        Args:
            embedding_model: Current embedding model
            
        Returns:
            Optimization recommendation for embeddings
        """
        
        # Check if it's an embedding model
        if not is_embedding_model(embedding_model):
            return None
        
        # Get alternatives from calculator
        alternatives = MODEL_ALTERNATIVES.get(embedding_model, [])
        
        if not alternatives:
            return None
        
        # Get pricing
        current_pricing = MODEL_PRICING.get(embedding_model, {})
        alt_pricing = MODEL_PRICING.get(alternatives[0], {})
        
        current_cost = current_pricing.get("input", 0)
        alt_cost = alt_pricing.get("input", 0)
        
        if alt_cost >= current_cost:
            return None  # No savings
        
        savings_percent = int(((current_cost - alt_cost) / current_cost * 100)) if current_cost > 0 else 0
        
        return {
            "optimization_type": "embedding_model",
            "current_model": embedding_model,
            "current_cost_per_1k": current_cost,
            "suggested_model": alternatives[0],
            "suggested_cost_per_1k": alt_cost,
            "savings_percent": savings_percent,
            "quality_impact": "minimal (typically <5% difference)",
            "reasoning": f"{alternatives[0]} costs {savings_percent}% less with minimal quality loss. For most RAG use cases, this difference is negligible.",
            "alternatives": alternatives[:3],  # Show top 3
            "estimated_monthly_savings": None  # Calculate based on volume
        }


class RAGPatternDetector:
    """
    Detects RAG patterns in usage history and provides aggregate insights.
    """
    
    def __init__(self):
        self.rag_analyzer = RAGAnalyzer()
    
    def analyze_usage_pattern(self, call_history: List[Dict]) -> Dict:
        """
        Analyze historical API calls to detect RAG patterns and opportunities.
        
        Args:
            call_history: List of past API calls with metadata
            
        Returns:
            Comprehensive RAG optimization report
        """
        
        report = {
            "is_rag_application": False,
            "confidence": 0.0,
            "evidence": [],
            "optimization_opportunities": {
                "embedding": None,
                "llm": None,
                "overall": None
            },
            "estimated_monthly_savings": 0.0
        }
        
        if not call_history:
            return report
        
        # Detect RAG patterns
        rag_calls = []
        embedding_calls = []
        
        for call in call_history:
            model = call.get("model", "")
            prompt = call.get("prompt", "")
            tokens = call.get("tokens", 0)
            
            # Check for embedding calls
            if is_embedding_model(model):
                embedding_calls.append(call)
            
            # Check for RAG-like LLM calls
            elif tokens > 1000 or len(prompt) > 2000:
                is_rag, confidence = self.rag_analyzer._detect_rag_pattern(
                    prompt, len(prompt), tokens
                )
                if is_rag:
                    rag_calls.append({**call, "rag_confidence": confidence})
        
        # Determine if this is a RAG application
        if len(rag_calls) > len(call_history) * 0.3:  # 30%+ are RAG calls
            report["is_rag_application"] = True
            report["confidence"] = min(0.95, len(rag_calls) / len(call_history))
            report["evidence"].append(f"{len(rag_calls)} out of {len(call_history)} calls match RAG pattern")
        
        if embedding_calls:
            report["evidence"].append(f"Found {len(embedding_calls)} embedding calls")
            report["is_rag_application"] = True
        
        # Calculate optimization opportunities
        if report["is_rag_application"]:
            
            # Embedding optimization
            if embedding_calls:
                total_embedding_cost = sum(c.get("cost", 0) for c in embedding_calls)
                
                # Find how many can be optimized
                optimizable = []
                for call in embedding_calls:
                    model = call.get("model", "")
                    alternatives = MODEL_ALTERNATIVES.get(model, [])
                    if alternatives:
                        optimizable.append(call)
                
                if optimizable:
                    # Estimate 80% average savings on embeddings
                    current_cost = sum(c.get("cost", 0) for c in optimizable)
                    optimized_cost = current_cost * 0.2
                    
                    report["optimization_opportunities"]["embedding"] = {
                        "current_monthly_cost": current_cost * 30,
                        "optimized_monthly_cost": optimized_cost * 30,
                        "monthly_savings": (current_cost - optimized_cost) * 30,
                        "optimizable_calls": len(optimizable),
                        "action": "Switch to cheaper embedding models (see alternatives in calculator)"
                    }
            
            # LLM optimization
            expensive_rag_calls = [
                c for c in rag_calls 
                if c.get("model", "") in self.rag_analyzer.expensive_models
            ]
            
            if expensive_rag_calls:
                # Estimate 70% could switch to cheaper model
                switchable_ratio = 0.7
                current_llm_cost = sum(c.get("cost", 0) for c in expensive_rag_calls)
                
                # 70% switch to cheap model (97% savings), 30% keep expensive
                optimized_cost = (current_llm_cost * 0.3) + (current_llm_cost * 0.7 * 0.03)
                
                report["optimization_opportunities"]["llm"] = {
                    "current_monthly_cost": current_llm_cost * 30,
                    "optimized_monthly_cost": optimized_cost * 30,
                    "monthly_savings": (current_llm_cost - optimized_cost) * 30,
                    "switchable_calls_percent": int(switchable_ratio * 100),
                    "expensive_calls": len(expensive_rag_calls),
                    "action": "Use cheaper models for simple RAG queries (extraction, lookup, summarization)"
                }
            
            # Calculate total savings
            total_savings = 0
            if report["optimization_opportunities"]["embedding"]:
                total_savings += report["optimization_opportunities"]["embedding"]["monthly_savings"]
            if report["optimization_opportunities"]["llm"]:
                total_savings += report["optimization_opportunities"]["llm"]["monthly_savings"]
            
            report["estimated_monthly_savings"] = total_savings
            
            if total_savings > 0:
                total_current_cost = sum(c.get("cost", 0) for c in call_history) * 30
                
                report["optimization_opportunities"]["overall"] = {
                    "total_monthly_savings": total_savings,
                    "savings_percent": int((total_savings / total_current_cost) * 100) if total_current_cost > 0 else 0,
                    "recommendation": "Implement RAG-specific optimizations for significant cost reduction"
                }
        
        return report