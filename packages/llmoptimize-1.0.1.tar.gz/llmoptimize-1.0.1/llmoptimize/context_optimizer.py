"""
Context Window Optimizer - Manages growing agent context.

Features:
1. Real-time optimization (reduces tokens BEFORE API calls)
2. AI-powered summarization (smart, meaningful summaries)
3. Rule-based summarization (fast, cheap fallback)
4. Pattern caching (learns what to summarize)
5. Post-workflow analysis (shows what was saved AFTER)
6. Recommendations for future optimization

Flow:
- BEFORE API call: Check if context needs trimming
- DURING optimization: Use AI or rules to summarize
- AFTER workflow: Show full analysis report

Cost Savings:
- Prevents context overflow
- Reduces tokens sent per API call
- Caches summarization patterns
- AI summarization only when needed
"""

import os
import asyncio
from typing import List, Dict, Optional, Tuple
from dataclasses import dataclass, field
from datetime import datetime
from .cache_manager import get_pattern_cache


@dataclass
class ContextChunk:
    """A chunk of context (one step's content)"""
    step_number: int
    content: str
    tokens: int
    importance: float       # 0-1 scale (higher = more important)
    can_summarize: bool
    step_type: str          # "planning", "tool_call", etc.
    is_summarized: bool = False
    summary: Optional[str] = None
    original_tokens: int = 0
    timestamp: str = ""
    summarization_method: str = ""  # "ai", "rule", "cached"


@dataclass
class OptimizationEvent:
    """Record of a single optimization event"""
    timestamp: str
    trigger: str                    # "threshold", "emergency", "manual"
    before_tokens: int
    after_tokens: int
    tokens_saved: int
    chunks_affected: List[int]
    strategy_used: str              # "summarize", "remove", "aggressive"
    method_used: str                # "ai", "rule", "cached"


class ContextWindowOptimizer:
    """
    Context optimizer with caching, AI summarization, and full analysis.

    Real-time: Reduces context BEFORE each API call
    AI-powered: Generates meaningful summaries (not just truncation)
    Cached: Learns what to summarize for similar content
    Post-analysis: Shows complete savings report after workflow
    """

    def __init__(
        self,
        max_tokens: int = 100000,
        summary_threshold: int = 50000,
        keep_recent: int = 5,
        importance_threshold: float = 0.3,
        enable_ai: bool = True,
        enable_cache: bool = True,
        ai_provider: str = "groq"
    ):
        """
        Initialize context optimizer.

        Args:
            max_tokens: Maximum total context size (default: 100K)
            summary_threshold: Start summarizing when exceeding this (default: 50K)
            keep_recent: Always keep N most recent steps unsummarized (default: 5)
            importance_threshold: Remove chunks below this importance (default: 0.3)
            enable_ai: Use AI for smart summarization
            enable_cache: Cache summarization patterns
            ai_provider: "groq" or "claude_haiku"
        """
        self.max_tokens = max_tokens
        self.summary_threshold = summary_threshold
        self.keep_recent = keep_recent
        self.importance_threshold = importance_threshold
        self.enable_ai = enable_ai
        self.enable_cache = enable_cache
        self.ai_provider = ai_provider

        # Storage
        self.context_chunks: List[ContextChunk] = []
        self.total_tokens = 0

        # Stats
        self.original_tokens = 0
        self.tokens_saved = 0
        self.chunks_summarized = 0
        self.chunks_removed = 0

        # Tracking for analysis
        self.optimization_events: List[OptimizationEvent] = []
        self.workflow_start_time = datetime.now()
        self.ai_summarizations = 0
        self.rule_summarizations = 0
        self.cached_summarizations = 0

        # Cache
        self.cache = get_pattern_cache() if enable_cache else None
        self.cache_namespace = "context_optimizer"

        # AI client (lazy loaded)
        self._ai_client = None

    @property
    def ai_client(self):
        """Lazy load AI client"""
        if self._ai_client is None and self.enable_ai:
            if self.ai_provider == "groq":
                try:
                    from groq import Groq
                    self._ai_client = Groq(api_key=os.getenv("GROQ_API_KEY"))
                except Exception:
                    pass
            elif self.ai_provider == "claude_haiku":
                try:
                    from anthropic import Anthropic
                    self._ai_client = Anthropic(api_key=os.getenv("ANTHROPIC_API_KEY"))
                except Exception:
                    pass
        return self._ai_client

    # ═══════════════════════════════════════════════════════════════════════
    # REAL-TIME OPTIMIZATION (During workflow)
    # ═══════════════════════════════════════════════════════════════════════

    def add_step(
        self,
        step_number: int,
        content: str,
        tokens: int,
        importance: float = 0.5,
        can_summarize: bool = True,
        step_type: str = "unknown"
    ):
        """
        Add a new step to context.

        REAL-TIME: Automatically optimizes if threshold exceeded.
        Called BEFORE each API call to manage context size.

        Args:
            step_number: Step number in workflow
            content: Step content (prompt + response)
            tokens: Token count for this step
            importance: Importance score 0-1 (higher = more important)
            can_summarize: Whether this step can be summarized
            step_type: Type of step ("planning", "tool_call", etc.)
        """

        chunk = ContextChunk(
            step_number=step_number,
            content=content,
            tokens=tokens,
            importance=importance,
            can_summarize=can_summarize,
            step_type=step_type,
            is_summarized=False,
            original_tokens=tokens,
            timestamp=datetime.now().isoformat()
        )

        self.context_chunks.append(chunk)
        self.total_tokens += tokens
        self.original_tokens += tokens

        # REAL-TIME: Auto-optimize if threshold exceeded
        if self.total_tokens > self.summary_threshold:
            print(f"\n🔧 Context threshold exceeded ({self.total_tokens:,} tokens)")
            print(f"   Auto-optimizing before next API call...")
            self.optimize(trigger="threshold")

    def get_context_for_api_call(self) -> str:
        """
        Get optimized context string for API call.

        Called BEFORE each API call.
        Returns optimized context that fits within budget.

        Returns:
            Optimized context string ready for API
        """

        # Sort by step number
        sorted_chunks = sorted(self.context_chunks, key=lambda c: c.step_number)

        context_parts = []

        for chunk in sorted_chunks:
            if chunk.is_summarized and chunk.summary:
                context_parts.append(
                    f"[Step {chunk.step_number} - {chunk.step_type} - SUMMARIZED "
                    f"({chunk.summarization_method})]\n{chunk.summary}"
                )
            else:
                context_parts.append(
                    f"[Step {chunk.step_number} - {chunk.step_type}]\n{chunk.content}"
                )

        return "\n\n".join(context_parts)

    def optimize(self, trigger: str = "manual") -> Dict:
        """
        Optimize context window (REAL-TIME).

        Runs BEFORE API calls when context is too large.
        Uses hybrid approach: cache → AI → rules

        Args:
            trigger: What triggered optimization

        Returns:
            Optimization statistics
        """

        if not self.context_chunks:
            return {"optimized": False, "reason": "no_chunks"}

        before_tokens = self.total_tokens
        chunks_affected = []

        # Identify summarizable chunks
        chunks_to_summarize = self._identify_summarizable_chunks()

        if chunks_to_summarize:
            for chunk in chunks_to_summarize:
                # Try hybrid summarization
                summary, method = self._hybrid_summarize(chunk)

                if summary:
                    original = chunk.tokens
                    chunk.summary = summary
                    chunk.is_summarized = True
                    chunk.summarization_method = method

                    # Estimate compressed tokens
                    compressed_tokens = max(50, int(len(summary) / 4))
                    chunk.tokens = compressed_tokens

                    # Update totals
                    saved = original - compressed_tokens
                    self.total_tokens -= saved
                    self.tokens_saved += saved
                    self.chunks_summarized += 1
                    chunks_affected.append(chunk.step_number)

                    # Track by method
                    if method == "ai":
                        self.ai_summarizations += 1
                    elif method == "cached":
                        self.cached_summarizations += 1
                    else:
                        self.rule_summarizations += 1

                # Stop if under threshold
                if self.total_tokens < self.max_tokens * 0.8:
                    break

        # Strategy 2: Remove low-importance if still over
        if self.total_tokens > self.max_tokens * 0.9:
            removed = self._remove_low_importance()
            chunks_affected.extend(removed)

        # Strategy 3: Aggressive if emergency
        if self.total_tokens > self.max_tokens * 0.95:
            emergency = self._emergency_summarization()
            chunks_affected.extend(emergency)

        after_tokens = self.total_tokens
        tokens_saved = before_tokens - after_tokens
        savings_percent = (tokens_saved / before_tokens * 100) if before_tokens > 0 else 0

        # Record event
        if tokens_saved > 0:
            event = OptimizationEvent(
                timestamp=datetime.now().isoformat(),
                trigger=trigger,
                before_tokens=before_tokens,
                after_tokens=after_tokens,
                tokens_saved=tokens_saved,
                chunks_affected=chunks_affected,
                strategy_used="summarize",
                method_used="hybrid"
            )
            self.optimization_events.append(event)

            print(f"   ✅ {before_tokens:,} → {after_tokens:,} tokens saved {tokens_saved:,} ({savings_percent:.0f}%)")

        return {
            "optimized": True,
            "trigger": trigger,
            "before_tokens": before_tokens,
            "after_tokens": after_tokens,
            "tokens_saved": tokens_saved,
            "savings_percent": savings_percent,
            "chunks_summarized": len(chunks_affected)
        }

    # ═══════════════════════════════════════════════════════════════════════
    # HYBRID SUMMARIZATION (Cache → AI → Rules)
    # ═══════════════════════════════════════════════════════════════════════

    def _hybrid_summarize(self, chunk: ContextChunk) -> Tuple[Optional[str], str]:
        """
        Summarize chunk using hybrid approach.

        Flow:
        1. Check cache for similar content (FREE, instant)
        2. Use AI for smart summarization (PAID, quality)
        3. Fall back to rule-based (FREE, fast)

        Returns:
            (summary_text, method_used)
        """

        # Step 1: Check cache
        if self.cache:
            cache_key = self._create_content_cache_key(chunk.content)
            cached_summary = self.cache.get_pattern(self.cache_namespace, cache_key)

            if cached_summary:
                return cached_summary["summary"], "cached"

        # Step 2: AI summarization
        if self.enable_ai and self.ai_client and chunk.tokens > 500:
            try:
                loop = asyncio.get_event_loop()
                if loop.is_running():
                    # Use rules if already in async context
                    summary = self._rule_summarize(chunk)
                    method = "rule"
                else:
                    summary = loop.run_until_complete(self._ai_summarize(chunk))
                    method = "ai"

                if summary:
                    # Cache the summary
                    if self.cache:
                        cache_key = self._create_content_cache_key(chunk.content)
                        self.cache.set_pattern(
                            self.cache_namespace,
                            cache_key,
                            {"summary": summary, "method": method},
                            ttl_hours=168,  # 7 days
                            metadata={"step_type": chunk.step_type}
                        )
                    return summary, method

            except Exception as e:
                pass

        # Step 3: Rule-based fallback
        summary = self._rule_summarize(chunk)
        return summary, "rule"

    async def _ai_summarize(self, chunk: ContextChunk) -> Optional[str]:
        """
        Use AI to generate intelligent summary.

        AI understands context and preserves important details.
        """

        # Determine compression ratio based on importance
        if chunk.importance >= 0.7:
            target_words = 80   # High importance: detailed summary
            ratio_desc = "detailed"
        elif chunk.importance >= 0.4:
            target_words = 50   # Medium: balanced summary
            ratio_desc = "concise"
        else:
            target_words = 25   # Low: brief summary
            ratio_desc = "brief"

        system_prompt = f"""You are a context compression expert for AI agent workflows.
Your job: Summarize agent steps to save tokens while preserving critical information.

Rules:
- Write a {ratio_desc} summary in {target_words} words or less
- Preserve: key decisions, important results, critical data
- Remove: verbose explanations, redundant details, filler text
- Format: Single paragraph, no bullet points
- Start with: "Step {chunk.step_number} [{chunk.step_type}]:"
"""

        user_prompt = f"""Summarize this agent step:

STEP TYPE: {chunk.step_type}
IMPORTANCE: {chunk.importance:.1f}/1.0
CONTENT:
{chunk.content[:2000]}

Write a {ratio_desc} summary preserving the most important information."""

        try:
            if self.ai_provider == "groq":
                response = self.ai_client.chat.completions.create(
                    model="llama-3.1-8b-instant",
                    messages=[
                        {"role": "system", "content": system_prompt},
                        {"role": "user", "content": user_prompt}
                    ],
                    temperature=0.3,
                    max_tokens=150
                )
                return response.choices[0].message.content.strip()

            elif self.ai_provider == "claude_haiku":
                response = self.ai_client.messages.create(
                    model="claude-3-haiku-20240307",
                    max_tokens=150,
                    system=system_prompt,
                    messages=[{"role": "user", "content": user_prompt}]
                )
                return response.content[0].text.strip()

        except Exception as e:
            return None

    def _rule_summarize(self, chunk: ContextChunk) -> str:
        """
        Fast rule-based summarization fallback.

        No AI cost, instant, but less intelligent.
        """

        # Ratio based on importance
        if chunk.importance >= 0.7:
            ratio = 0.5     # Keep 50%
        elif chunk.importance >= 0.4:
            ratio = 0.3     # Keep 30%
        else:
            ratio = 0.15    # Keep 15%

        # Truncate content
        keep_chars = int(len(chunk.content) * ratio)
        truncated = chunk.content[:keep_chars]

        return f"[Step {chunk.step_number} - {chunk.step_type}] {truncated}..."

    def _create_content_cache_key(self, content: str) -> str:
        """Create cache key from content (first 100 chars normalized)"""
        normalized = content[:100].lower().strip()
        normalized = ' '.join(normalized.split())
        return normalized

    def _identify_summarizable_chunks(self) -> List[ContextChunk]:
        """Identify chunks that should be summarized"""

        if len(self.context_chunks) <= self.keep_recent:
            return []

        old_chunks = self.context_chunks[:-self.keep_recent]

        summarizable = [
            chunk for chunk in old_chunks
            if (not chunk.is_summarized and
                chunk.can_summarize and
                chunk.importance < 0.9 and
                chunk.tokens > 200)
        ]

        # Summarize least important first
        summarizable.sort(key=lambda c: c.importance)

        return summarizable

    def _remove_low_importance(self) -> List[int]:
        """Remove very low importance chunks"""

        if len(self.context_chunks) <= self.keep_recent:
            return []

        old_chunks = self.context_chunks[:-self.keep_recent]
        to_remove = [c for c in old_chunks if c.importance < self.importance_threshold]
        to_remove.sort(key=lambda c: c.importance)

        removed_steps = []
        for chunk in to_remove:
            if self.total_tokens <= self.max_tokens * 0.8:
                break

            self.context_chunks.remove(chunk)
            self.total_tokens -= chunk.tokens
            self.tokens_saved += chunk.tokens
            self.chunks_removed += 1
            removed_steps.append(chunk.step_number)

        return removed_steps

    def _emergency_summarization(self) -> List[int]:
        """Emergency: aggressively summarize everything"""

        if len(self.context_chunks) <= self.keep_recent:
            return []

        old_chunks = self.context_chunks[:-self.keep_recent]
        affected = []

        for chunk in old_chunks:
            if chunk.is_summarized or chunk.importance >= 0.95:
                continue

            original = chunk.tokens
            chunk.tokens = max(30, int(chunk.tokens * 0.1))
            chunk.is_summarized = True
            chunk.summary = f"[Emergency Summary] {chunk.content[:30]}..."
            chunk.summarization_method = "emergency"

            self.total_tokens -= (original - chunk.tokens)
            self.tokens_saved += (original - chunk.tokens)
            affected.append(chunk.step_number)

            if self.total_tokens < self.max_tokens * 0.85:
                break

        return affected

    # ═══════════════════════════════════════════════════════════════════════
    # POST-ANALYSIS (After workflow)
    # ═══════════════════════════════════════════════════════════════════════

    def generate_analysis_report(self) -> Dict:
        """
        Generate comprehensive post-workflow analysis.

        Shows:
        - What was optimized and how
        - How much was saved (tokens + money)
        - Breakdown by step
        - Method effectiveness
        - Recommendations for future
        """

        # Savings totals
        total_savings_pct = (self.tokens_saved / self.original_tokens * 100) if self.original_tokens > 0 else 0

        # Step breakdown
        step_breakdown = self._analyze_steps()

        # Method breakdown
        method_breakdown = {
            "ai": self.ai_summarizations,
            "cached": self.cached_summarizations,
            "rule": self.rule_summarizations
        }

        # Cost analysis
        cost_analysis = self.estimate_cost_savings()

        # Timeline
        timeline = self._build_timeline()

        # Recommendations
        recommendations = self._generate_recommendations()

        return {
            "summary": {
                "total_steps": len(self.context_chunks) + self.chunks_removed,
                "remaining_steps": len(self.context_chunks),
                "original_tokens": self.original_tokens,
                "final_tokens": self.total_tokens,
                "tokens_saved": self.tokens_saved,
                "savings_percent": total_savings_pct,
                "chunks_summarized": self.chunks_summarized,
                "chunks_removed": self.chunks_removed,
                "optimization_events": len(self.optimization_events)
            },
            "method_breakdown": method_breakdown,
            "step_breakdown": step_breakdown,
            "cost_analysis": cost_analysis,
            "timeline": timeline,
            "recommendations": recommendations,
            "efficiency_rating": self._calculate_efficiency_rating()
        }

    def _analyze_steps(self) -> List[Dict]:
        """Analyze each step's contribution"""

        breakdown = []

        for chunk in sorted(self.context_chunks, key=lambda c: c.step_number):
            tokens_saved = chunk.original_tokens - chunk.tokens if chunk.is_summarized else 0
            savings_pct = (tokens_saved / chunk.original_tokens * 100) if chunk.original_tokens > 0 else 0

            breakdown.append({
                "step_number": chunk.step_number,
                "step_type": chunk.step_type,
                "original_tokens": chunk.original_tokens,
                "final_tokens": chunk.tokens,
                "tokens_saved": tokens_saved,
                "savings_percent": savings_pct,
                "importance": chunk.importance,
                "was_summarized": chunk.is_summarized,
                "summarization_method": chunk.summarization_method if chunk.is_summarized else "none"
            })

        return breakdown

    def _build_timeline(self) -> List[Dict]:
        """Build timeline of optimization events"""

        timeline = []

        for event in self.optimization_events:
            timeline.append({
                "timestamp": event.timestamp,
                "trigger": event.trigger,
                "tokens_before": event.before_tokens,
                "tokens_after": event.after_tokens,
                "tokens_saved": event.tokens_saved,
                "steps_affected": event.chunks_affected,
                "strategy": event.strategy_used
            })

        return timeline

    def _generate_recommendations(self) -> List[str]:
        """Generate actionable recommendations"""

        recommendations = []

        # Check savings rate
        savings_pct = (self.tokens_saved / self.original_tokens * 100) if self.original_tokens > 0 else 0

        if savings_pct >= 50:
            recommendations.append(
                f"🎯 Excellent optimization: {savings_pct:.0f}% tokens saved!"
            )
        elif savings_pct >= 30:
            recommendations.append(
                f"✅ Good optimization: {savings_pct:.0f}% tokens saved."
            )
        else:
            recommendations.append(
                f"📈 Moderate optimization: {savings_pct:.0f}% saved. More aggressive summarization possible."
            )

        # Check AI effectiveness
        if self.ai_summarizations > 0:
            recommendations.append(
                f"🤖 AI summarization used {self.ai_summarizations} times - providing smart context compression."
            )

        # Check cache effectiveness
        if self.cached_summarizations > 0:
            recommendations.append(
                f"⚡ Cache hit {self.cached_summarizations} times - system is learning patterns!"
            )

        # Check removals
        if self.chunks_removed > 0:
            recommendations.append(
                f"🗑️  {self.chunks_removed} low-importance steps removed. "
                f"Review if important data was lost."
            )

        # Check frequency of optimization events
        if len(self.optimization_events) > 5:
            recommendations.append(
                f"🔄 {len(self.optimization_events)} optimization events - "
                f"consider lowering summary_threshold for earlier optimization."
            )
        elif len(self.optimization_events) == 0:
            recommendations.append(
                f"💡 No optimization triggered - context stayed under {self.summary_threshold:,} tokens."
            )

        # Check importance distribution
        importance_scores = [c.importance for c in self.context_chunks]
        if importance_scores:
            avg_importance = sum(importance_scores) / len(importance_scores)
            if avg_importance < 0.4:
                recommendations.append(
                    f"⚠️  Average importance is low ({avg_importance:.1f}). "
                    f"Consider setting higher importance for critical steps."
                )

        return recommendations if recommendations else ["✨ Context was already efficient!"]

    def _calculate_efficiency_rating(self) -> str:
        """Calculate A-F efficiency rating"""

        savings_pct = (self.tokens_saved / self.original_tokens * 100) if self.original_tokens > 0 else 0

        if savings_pct >= 60:
            return "A+ (Excellent)"
        elif savings_pct >= 50:
            return "A (Very Good)"
        elif savings_pct >= 40:
            return "B (Good)"
        elif savings_pct >= 30:
            return "C (Average)"
        elif savings_pct >= 20:
            return "D (Below Average)"
        elif savings_pct >= 10:
            return "E (Poor)"
        else:
            return "F (Needs Improvement)"

    def estimate_cost_savings(self, cost_per_token: float = 0.00003) -> Dict:
        """Estimate cost savings (GPT-4 default pricing)"""

        original_cost = self.original_tokens * cost_per_token
        current_cost = self.total_tokens * cost_per_token
        savings = original_cost - current_cost

        return {
            "original_cost": f"${original_cost:.6f}",
            "current_cost": f"${current_cost:.6f}",
            "cost_saved": f"${savings:.6f}",
            "savings_percent": f"{(savings / original_cost * 100) if original_cost > 0 else 0:.1f}%"
        }

    def print_analysis_report(self):
        """Print formatted post-analysis report"""

        report = self.generate_analysis_report()

        print("\n" + "="*70)
        print("📊 CONTEXT OPTIMIZATION ANALYSIS REPORT")
        print("="*70)

        # Summary
        summary = report["summary"]
        print(f"\n{'─'*70}")
        print("SUMMARY")
        print(f"{'─'*70}")
        print(f"Total Steps:          {summary['total_steps']}")
        print(f"Original Tokens:      {summary['original_tokens']:,}")
        print(f"Final Tokens:         {summary['final_tokens']:,}")
        print(f"Tokens Saved:         {summary['tokens_saved']:,} ({summary['savings_percent']:.1f}%)")
        print(f"Chunks Summarized:    {summary['chunks_summarized']}")
        print(f"Chunks Removed:       {summary['chunks_removed']}")
        print(f"Optimization Events:  {summary['optimization_events']}")
        print(f"Efficiency Rating:    {report['efficiency_rating']}")

        # Method breakdown
        print(f"\n{'─'*70}")
        print("SUMMARIZATION METHODS")
        print(f"{'─'*70}")
        method_emoji = {"ai": "🤖", "cached": "📦", "rule": "📏"}
        for method, count in report["method_breakdown"].items():
            if count > 0:
                emoji = method_emoji.get(method, "•")
                print(f"{emoji} {method.upper():10} {count} summarizations")

        # Cost analysis
        cost = report["cost_analysis"]
        print(f"\n{'─'*70}")
        print("COST IMPACT")
        print(f"{'─'*70}")
        print(f"Original Cost:        {cost['original_cost']}")
        print(f"Optimized Cost:       {cost['current_cost']}")
        print(f"Cost Saved:           {cost['cost_saved']} ({cost['savings_percent']})")

        # Timeline
        if report["timeline"]:
            print(f"\n{'─'*70}")
            print("OPTIMIZATION TIMELINE")
            print(f"{'─'*70}")
            for i, event in enumerate(report["timeline"], 1):
                print(f"\n{i}. {event['trigger'].upper()} Optimization:")
                print(f"   Before: {event['tokens_before']:,} → After: {event['tokens_after']:,}")
                print(f"   Saved:  {event['tokens_saved']:,} tokens")
                if event['steps_affected']:
                    print(f"   Steps:  {event['steps_affected'][:5]}"
                          f"{'...' if len(event['steps_affected']) > 5 else ''}")

        # Step breakdown
        print(f"\n{'─'*70}")
        print("STEP-BY-STEP BREAKDOWN")
        print(f"{'─'*70}")
        print(f"{'Step':6} {'Type':15} {'Original':10} {'Final':8} {'Saved':8} {'Method':10} {'Importance':10}")
        print(f"{'─'*70}")
        for step in report["step_breakdown"]:
            method = step["summarization_method"] if step["was_summarized"] else "kept"
            print(
                f"{step['step_number']:<6} "
                f"{step['step_type']:<15} "
                f"{step['original_tokens']:<10} "
                f"{step['final_tokens']:<8} "
                f"{step['tokens_saved']:<8} "
                f"{method:<10} "
                f"{step['importance']:.1f}"
            )

        # Recommendations
        print(f"\n{'─'*70}")
        print("💡 RECOMMENDATIONS FOR FUTURE RUNS")
        print(f"{'─'*70}")
        for rec in report["recommendations"]:
            print(f"\n{rec}")

        print("\n" + "="*70 + "\n")

    def export_analysis(self, filename: str = "context_analysis.json"):
        """Export analysis to JSON"""

        import json

        report = self.generate_analysis_report()

        with open(filename, 'w') as f:
            json.dump(report, f, indent=2)

        print(f"📊 Context analysis exported to {filename}")

    # ═══════════════════════════════════════════════════════════════════════
    # UTILITY METHODS
    # ═══════════════════════════════════════════════════════════════════════

    def get_stats(self) -> Dict:
        """Get current context statistics"""

        utilization = (self.total_tokens / self.max_tokens * 100) if self.max_tokens > 0 else 0
        savings_rate = (self.tokens_saved / self.original_tokens * 100) if self.original_tokens > 0 else 0

        return {
            "total_chunks": len(self.context_chunks),
            "total_tokens": self.total_tokens,
            "original_tokens": self.original_tokens,
            "tokens_saved": self.tokens_saved,
            "savings_rate": f"{savings_rate:.1f}%",
            "max_tokens": self.max_tokens,
            "utilization": f"{utilization:.1f}%",
            "chunks_summarized": self.chunks_summarized,
            "chunks_removed": self.chunks_removed,
            "ai_summarizations": self.ai_summarizations,
            "cached_summarizations": self.cached_summarizations,
            "rule_summarizations": self.rule_summarizations,
            "can_add_more": self.total_tokens < self.max_tokens * 0.9
        }

    def print_stats(self):
        """Print formatted real-time statistics"""

        stats = self.get_stats()

        print("\n" + "="*70)
        print("📦 CONTEXT WINDOW STATISTICS (REAL-TIME)")
        print("="*70)
        print(f"Total Chunks:        {stats['total_chunks']}")
        print(f"Current Tokens:      {stats['total_tokens']:,}")
        print(f"Original Tokens:     {stats['original_tokens']:,}")
        print(f"Tokens Saved:        {stats['tokens_saved']:,} ({stats['savings_rate']})")
        print(f"Max Tokens:          {stats['max_tokens']:,}")
        print(f"Utilization:         {stats['utilization']}")
        print(f"\n{'─'*70}")
        print("SUMMARIZATION METHODS:")
        print(f"{'─'*70}")
        print(f"AI Summaries:        {stats['ai_summarizations']}")
        print(f"Cached Summaries:    {stats['cached_summarizations']}")
        print(f"Rule Summaries:      {stats['rule_summarizations']}")
        print(f"Chunks Removed:      {stats['chunks_removed']}")
        print(f"Can Add More:        {stats['can_add_more']}")
        print("="*70 + "\n")

    def set_importance(self, step_number: int, importance: float):
        """Update importance score for a specific step"""

        for chunk in self.context_chunks:
            if chunk.step_number == step_number:
                chunk.importance = importance
                break

    def reset(self):
        """Reset optimizer for new workflow"""

        self.context_chunks.clear()
        self.total_tokens = 0
        self.original_tokens = 0
        self.tokens_saved = 0
        self.chunks_summarized = 0
        self.chunks_removed = 0
        self.optimization_events.clear()
        self.ai_summarizations = 0
        self.rule_summarizations = 0
        self.cached_summarizations = 0
        self.workflow_start_time = datetime.now()