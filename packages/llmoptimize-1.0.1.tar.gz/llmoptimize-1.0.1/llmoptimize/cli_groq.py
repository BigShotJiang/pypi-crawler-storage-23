"""
CLI Groq - Groq-specific CLI commands for AIOptimize.

Commands:
    aioptimize-groq audit <file>     - Audit with optimal Groq model
    aioptimize-groq models           - List all Groq models + costs
    aioptimize-groq compare <file>   - Compare all models for this code
    aioptimize-groq select <file>    - Just select the best model
    aioptimize-groq stats            - Show model selector statistics
"""

import sys
import argparse
from .groq_auditor import GroqAuditor
from .groq_model_selector import GroqModelSelector
from .report_formatter import format_audit_report, format_comparison_table, format_quick_summary


def main():
    """Main Groq CLI entry point"""

    parser = argparse.ArgumentParser(
        description="AIOptimize Groq - Groq-specific cost optimization",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  aioptimize-groq audit mycode.py
  aioptimize-groq audit mycode.py --model llama-3.1-8b-instant
  aioptimize-groq models
  aioptimize-groq compare mycode.py
  aioptimize-groq select mycode.py
  aioptimize-groq stats
        """
    )

    subparsers = parser.add_subparsers(dest='command', help='Commands')

    # ── AUDIT COMMAND ──
    audit_parser = subparsers.add_parser(
        'audit',
        help='Audit Python file using optimal Groq model'
    )
    audit_parser.add_argument('file', help='Python file to audit')
    audit_parser.add_argument(
        '--model',
        help='Force specific Groq model ID'
    )
    audit_parser.add_argument(
        '--force',
        action='store_true',
        help='Force fresh analysis (skip cache)'
    )
    audit_parser.add_argument(
        '--quiet',
        action='store_true',
        help='Show quick summary only'
    )
    audit_parser.add_argument(
        '--no-cache',
        action='store_true',
        help='Disable caching for this audit'
    )

    # ── MODELS COMMAND ──
    models_parser = subparsers.add_parser(
        'models',
        help='List all available Groq models with pricing'
    )

    # ── COMPARE COMMAND ──
    compare_parser = subparsers.add_parser(
        'compare',
        help='Compare all Groq models for a specific file'
    )
    compare_parser.add_argument('file', help='Python file to analyze')

    # ── SELECT COMMAND ──
    select_parser = subparsers.add_parser(
        'select',
        help='Show which Groq model would be selected for a file'
    )
    select_parser.add_argument('file', help='Python file to analyze')
    select_parser.add_argument(
        '--explain',
        action='store_true',
        default=True,
        help='Explain the selection reasoning'
    )

    # ── STATS COMMAND ──
    stats_parser = subparsers.add_parser(
        'stats',
        help='Show Groq model selector statistics'
    )

    args = parser.parse_args()

    if args.command == 'audit':
        _run_groq_audit(args)

    elif args.command == 'models':
        _show_models()

    elif args.command == 'compare':
        _compare_models(args)

    elif args.command == 'select':
        _select_model(args)

    elif args.command == 'stats':
        _show_stats()

    else:
        parser.print_help()


# ═══════════════════════════════════════════════════════════════════════
# COMMAND HANDLERS
# ═══════════════════════════════════════════════════════════════════════

def _run_groq_audit(args):
    """Run Groq audit command"""

    # Read file
    try:
        with open(args.file, 'r') as f:
            code = f.read()
    except FileNotFoundError:
        print(f"❌ File not found: {args.file}")
        sys.exit(1)
    except Exception as e:
        print(f"❌ Error reading file: {e}")
        sys.exit(1)

    # Check API key
    import os
    if not os.getenv("GROQ_API_KEY"):
        print("❌ GROQ_API_KEY not set!")
        print("   Get your free key at: console.groq.com")
        print("   Then: export GROQ_API_KEY='your-key'")
        sys.exit(1)

    # Create auditor
    auditor = GroqAuditor(
        force_model=args.model,
        enable_cache=not args.no_cache
    )

    print(f"\n🔍 Auditing: {args.file}")
    if args.model:
        print(f"   Model: {args.model} (forced)")
    else:
        print(f"   Model: Auto-selected (smart)")

    if args.no_cache:
        print("   Cache: Disabled")
    else:
        print("   Cache: Enabled (saves money on repeat audits)")

    print()

    # Run audit
    try:
        report = auditor.audit_code(
            code=code,
            filename=args.file,
            force_refresh=args.force,
            explain_selection=not args.quiet
        )

        # Display results
        if args.quiet:
            print(format_quick_summary(report))
        else:
            print(format_audit_report(report))

        # Show auditor stats
        auditor.print_stats()

    except Exception as e:
        error_str = str(e)
        if "GROQ_API_KEY" in error_str or "authentication" in error_str.lower():
            print(f"❌ Authentication failed. Check your GROQ_API_KEY.")
        elif "rate limit" in error_str.lower():
            print(f"⚠️  Rate limit hit. Free tier: 14,400 requests/day.")
            print(f"   Try again in a minute, or upgrade at console.groq.com")
        else:
            print(f"❌ Audit failed: {e}")
        sys.exit(1)


def _show_models():
    """Show all available Groq models"""

    selector = GroqModelSelector()

    print("\n" + "═"*70)
    print("🤖 AVAILABLE GROQ MODELS")
    print("═"*70)

    tiers = {
        "simple": "💚 SIMPLE TASKS",
        "medium": "💛 MEDIUM TASKS",
        "complex": "🔴 COMPLEX TASKS"
    }

    for tier_key, tier_label in tiers.items():
        model = selector.MODELS[tier_key]
        print(f"\n{tier_label}")
        print(f"{'─'*50}")
        print(f"  Model:        {model['name']}")
        print(f"  Model ID:     {model['id']}")
        print(f"  Input Cost:   ${model['input_cost']}/1M tokens")
        print(f"  Output Cost:  ${model['output_cost']}/1M tokens")
        print(f"  Quality:      {model['quality']:.0%}")
        print(f"  Speed:        {model['speed']} tokens/sec")
        print(f"  Free/Day:     {model['rpd_free']} requests")
        print(f"  Best For:     {model['best_for']}")

    print(f"\n{'─'*70}")
    print("💡 COST COMPARISON (per audit, ~1K input + 1.5K output):")
    print(f"{'─'*70}")

    dummy_code = "x = 1\n" * 30
    for tier_key, model in selector.MODELS.items():
        cost = selector.estimate_cost(dummy_code, model["id"])
        print(f"  {model['name']:25} ${cost:.6f}/audit")

    print(f"\n{'─'*70}")
    print("📊 SAVINGS vs Always Using 70B:")
    print(f"{'─'*70}")

    base_cost = selector.estimate_cost(dummy_code, selector.MODELS["complex"]["id"])
    for tier_key, model in selector.MODELS.items():
        cost = selector.estimate_cost(dummy_code, model["id"])
        savings = ((base_cost - cost) / base_cost * 100) if base_cost > 0 else 0
        if savings > 0:
            print(f"  {model['name']:25} saves {savings:.0f}% vs 70B")
        else:
            print(f"  {model['name']:25} (baseline)")

    print("═"*70 + "\n")


def _compare_models(args):
    """Compare all models for a file"""

    # Read file
    try:
        with open(args.file, 'r') as f:
            code = f.read()
    except FileNotFoundError:
        print(f"❌ File not found: {args.file}")
        sys.exit(1)

    selector = GroqModelSelector()
    comparison = selector.compare_models(code)

    print(f"\n🔍 Model Comparison for: {args.file}")
    print(f"   Lines: {comparison['code_stats']['lines']}")
    print(f"   Complexity Factors: {comparison['code_stats']['complexity_factors']}")

    # Format and print comparison table
    print(format_comparison_table(comparison['comparisons']))

    # Show recommendation
    rec = comparison['recommended']
    print(f"✅ RECOMMENDATION: {rec['recommended_model']}")
    print(f"   Model ID:  {rec['model_id']}")
    print(f"   Cost:      ${rec['estimated_cost']:.6f}")
    print(f"   Quality:   {rec['quality_score']:.0%}")
    print(f"   Best for:  {rec['best_for']}")
    print()


def _select_model(args):
    """Select optimal model for a file"""

    # Read file
    try:
        with open(args.file, 'r') as f:
            code = f.read()
    except FileNotFoundError:
        print(f"❌ File not found: {args.file}")
        sys.exit(1)

    selector = GroqModelSelector()

    print(f"\n🎯 Selecting model for: {args.file}\n")

    model_id, complexity, model_info = selector.select_model(
        code=code,
        explain=True
    )

    print(f"\n{'═'*50}")
    print(f"SELECTED: {model_info['name']}")
    print(f"{'═'*50}")
    print(f"Model ID:   {model_id}")
    print(f"Complexity: {complexity.upper()}")
    print(f"Quality:    {model_info['quality']:.0%}")
    print(f"Speed:      {model_info['speed']} tokens/sec")
    print(f"Best for:   {model_info['best_for']}")
    print(f"Est. Cost:  ${selector.estimate_cost(code, model_id):.6f}")
    print(f"{'═'*50}\n")

    # Show alternatives
    print("Alternatives considered:")
    for tier, info in selector.MODELS.items():
        if info['id'] != model_id:
            alt_cost = selector.estimate_cost(code, info['id'])
            diff = ((alt_cost - selector.estimate_cost(code, model_id)) /
                    selector.estimate_cost(code, model_id) * 100) if selector.estimate_cost(code, model_id) > 0 else 0
            print(f"  {info['name']:25} ${alt_cost:.6f} ({diff:+.0f}%)")
    print()


def _show_stats():
    """Show Groq model selector statistics"""

    selector = GroqModelSelector()

    print("\n" + "="*70)
    print("📊 GROQ MODEL SELECTOR STATISTICS")
    print("="*70)
    print("No selections made yet in this session.")
    print("Run some audits first to see statistics!")
    print("="*70 + "\n")


if __name__ == '__main__':
    main()