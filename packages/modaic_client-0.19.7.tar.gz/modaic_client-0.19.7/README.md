# modaic-client

Python client SDK for the Modaic API.

## Installation

```bash
pip install modaic-client
```

## Documentation

Full documentation at [docs.modaic.dev](https://docs.modaic.dev).
