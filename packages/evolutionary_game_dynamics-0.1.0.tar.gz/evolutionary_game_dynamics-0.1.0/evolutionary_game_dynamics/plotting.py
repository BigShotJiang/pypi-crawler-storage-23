from .utils import *
from .analysis import *


def plot_pre_post_frequency_overall(results_df, title=None):
    d = results_df.copy()

    summary = (
        d.groupby("pair", observed=True)
        .agg(mean_pre=("pre_freq", "mean"),
             mean_post=("post_freq", "mean"))
        .reset_index()
    )

    df_melt = summary.melt(
        id_vars="pair",
        value_vars=["mean_pre", "mean_post"],
        var_name="phase",
        value_name="frequency"
    )

    df_melt["Phase"] = df_melt["phase"].map({
        "mean_pre": "Pre-shock",
        "mean_post": "Post-shock"
    })

    fig, ax = plt.subplots(figsize=(8,5))
    sns.barplot(data=df_melt, x="pair", y="frequency", hue="Phase", ax=ax)

    for container in ax.containers:
        ax.bar_label(container, fmt="%.2f", padding=3)

    ax.set_xlabel("Pair")
    ax.set_ylabel("Average relative frequency (%)")
    if title:
        ax.set_title(title)


def plot_recovery_time_per_pair(results_df, title=None):
    # d = results_df.copy()
    d = filter_invalid_recovery(results_df.copy())
    d = d[d["recovery_time"].notna()]

    summary = (
        d.groupby("pair", observed=True)["recovery_time"]
        .agg(mean_rec="mean")
        .reset_index()
    )

    fig, ax = plt.subplots(figsize=(8,5))
    sns.barplot(data=summary, x="pair", y="mean_rec", color="skyblue", ax=ax)

    for i, row in summary.iterrows():
        ax.text(i, row["mean_rec"], f"{row['mean_rec']:.2f}",
                ha="center", va="bottom", fontsize=9)

    ax.set_xlabel("Pair")
    ax.set_ylabel("Average recovery time\n(Count of timeperiods)")
    if title:
        ax.set_title(title)



def plot_pre_freq_vs_memory_allpairs(results_df, title=None):
    d = results_df.copy()

    summary = (
        d.groupby(["memory_length", "pair"], observed=True)["pre_freq"]
        .agg(mean_pre="mean")
        .reset_index()
    )

    summary["memory_length"] = summary["memory_length"].astype(int)
    summary = summary.sort_values(["pair", "memory_length"])

    fig, ax = plt.subplots(figsize=(8,5))

    for pair in sorted(summary["pair"].unique()):
        sub = summary[summary["pair"] == pair]
        ax.plot(sub["memory_length"], sub["mean_pre"], marker="o", label=pair)

    ax.set_xlabel("Memory length")
    ax.set_ylabel("Average pre-shock relative frequency (%)")
    ax.set_xticks(sorted(summary["memory_length"].unique()))
    if title:
        ax.set_title(title)
    ax.legend(title="Pair")


def plot_recovery_vs_memory_allpairs(results_df, title=None):
    # d = results_df.copy()
    d = filter_invalid_recovery(results_df.copy())
    d = d[d["recovery_time"].notna()]

    summary = (
        d.groupby(["memory_length", "pair"], observed=True)["recovery_time"]
        .agg(mean_rec="mean")
        .reset_index()
    )

    summary["memory_length"] = summary["memory_length"].astype(int)
    summary = summary.sort_values(["pair", "memory_length"])

    fig, ax = plt.subplots(figsize=(8,5))

    for pair in sorted(summary["pair"].unique()):
        sub = summary[summary["pair"] == pair]
        ax.plot(sub["memory_length"], sub["mean_rec"], marker="o", label=pair)

    ax.set_xlabel("Memory length")
    ax.set_ylabel("Average recovery time\n(Count of timeperiods)")
    ax.set_xticks(sorted(summary["memory_length"].unique()))
    if title:
        ax.set_title(title)
    ax.legend(title="Pair")


def plot_pre_freq_vs_epsilon_allpairs(results_df, title=None):
    d = results_df.copy()

    summary = (
        d.groupby(["epsilon", "pair"], observed=True)["pre_freq"]
        .agg(mean_pre="mean")
        .reset_index()
    )

    summary = summary.sort_values(["pair", "epsilon"])

    fig, ax = plt.subplots(figsize=(8,5))

    for pair in sorted(summary["pair"].unique()):
        sub = summary[summary["pair"] == pair]
        ax.plot(sub["epsilon"], sub["mean_pre"], marker="o", label=pair)

    ax.set_xlabel("Epsilon")
    ax.set_ylabel("Average pre-shock relative frequency (%)")
    if title:
        ax.set_title(title)
    ax.legend(title="Pair")

def plot_recovery_vs_epsilon_allpairs(results_df, title=None):
    # d = results_df.copy()
    d = filter_invalid_recovery(results_df.copy())
    d = d[d["recovery_time"].notna()]

    summary = (
        d.groupby(["epsilon", "pair"], observed=True)["recovery_time"]
        .agg(mean_rec="mean")
        .reset_index()
    )

    summary = summary.sort_values(["pair", "epsilon"])

    fig, ax = plt.subplots(figsize=(8,5))

    for pair in sorted(summary["pair"].unique()):
        sub = summary[summary["pair"] == pair]
        ax.plot(sub["epsilon"], sub["mean_rec"], marker="o", label=pair)

    ax.set_xlabel("Epsilon")
    ax.set_ylabel("Average recovery time\n(Count of timeperiods)")
    if title:
        ax.set_title(title)
    ax.legend(title="Pair")




def plot_binned_init_share_pre_freq_all_focal_pairs(
    results_df,
    focal_pairs=None,
    title_prefix="Average Pre-shock Relative Frequency vs Initial State Pair",
    output_dir=None
):
    """
    Generates and saves one plot per focal pair.
    If output_dir is provided, saves PNG files there.
    """
    focal_pairs=[(0,0),(0,1),(1,0),(1,1)]
    for fp in focal_pairs:
        
        d = results_df.copy()
        
        if fp == (0,0):
            d["init_share_pct"] = d["initial_distribution"].apply(
                lambda s: parse_initial_distribution_string(s).get((0, 0), 0.0) * 100
            )
        elif fp == (0,1):
            d["init_share_pct"] = d["initial_distribution"].apply(
                lambda s: parse_initial_distribution_string(s).get((0, 1), 0.0) * 100
            )
        elif fp == (1,0):
            d["init_share_pct"] = d["initial_distribution"].apply(
                lambda s: parse_initial_distribution_string(s).get((1, 0), 0.0) * 100
            )
        elif fp == (1,1):
            d["init_share_pct"] = d["initial_distribution"].apply(
            lambda s: parse_initial_distribution_string(s).get((1, 1), 0.0) * 100
        )

        

        # 2. Bin into 10% intervals
        bins = np.arange(0, 110, 10)
        d["init_bin"] = pd.cut(d["init_share_pct"], bins=bins, include_lowest=True)

        d["init_bin_label"] = d["init_bin"].apply(
            lambda x: f"({int(x.left)}, {int(x.right)}]" if pd.notna(x) else "NA"
        )

        ordered_bins = sorted(
            d["init_bin_label"].dropna().unique(),
            key=lambda s: int(s.split(",")[0][1:])
        )
        d["init_bin_label"] = pd.Categorical(
            d["init_bin_label"], categories=ordered_bins, ordered=True
        )

        # 3. Aggregate
        agg = (
            d.groupby(["init_bin_label", "pair"], observed=True)["pre_freq"]
            .agg(mean_pre="mean")
            .reset_index()
        )

        # 4. Plot
        plt.figure(figsize=(8, 6))
        ax = plt.gca()

        for pair in sorted(agg["pair"].unique()):
            sub = agg[agg["pair"] == pair].sort_values("init_bin_label")
            x = np.arange(len(sub))
            y = sub["mean_pre"]
            ax.plot(x, y, marker="o", label=str(pair))

        ax.set_xticks(np.arange(len(ordered_bins)))
        ax.set_xticklabels(ordered_bins, rotation=45, ha="right")

        ax.set_ylabel("Average pre-shock relative frequency (%)")
        # ax.set_xlabel(f"Initial state % share - {fp} (%)")
        ax.set_xlabel(f"Pair {fp} contribution in initial state (%)")
        # ax.set_title(f"{title_prefix} — Pair {fp}")
        ax.set_title(f"{title_prefix} {fp}")
        ax.legend(title="Pair")

        plt.tight_layout()
        # plt.show()

        # 5. Save if output_dir provided
        if output_dir:
            fname = f"init_share_pre_freq_fp_{fp[0]}_{fp[1]}.png"
            plt.savefig(os.path.join(output_dir, fname))

        plt.close()



def plot_pre_shock_heatmap_grid(results_df):
    outcome_pairs = sorted(results_df["pair"].unique())

    

    fig = plt.figure(figsize=(16, 14))

    gs = gridspec.GridSpec(2, 2, figure=fig, hspace=0.3, wspace=0.2)

    axes = [fig.add_subplot(gs[i, j]) for i in range(2) for j in range(2)]

    vmin = results_df["pre_freq"].min()
    vmax = results_df["pre_freq"].max()

    for ax, pair in zip(axes, outcome_pairs):
        df = results_df[results_df["pair"] == pair].copy()

        agg = (
            df.groupby(["memory_length", "epsilon"])
            .agg(pre_mean=("pre_freq", "mean"))
            .reset_index()
        )

        
        heat = agg.pivot_table(
            index="epsilon",
            columns="memory_length",
            values="pre_mean",
            aggfunc="mean"
        )
        heat = heat.sort_index(ascending=False)

        sns.heatmap(
            heat,
            annot=True,
            fmt=".1f",
            cmap="viridis",
            ax=ax,
            vmin=vmin,
            vmax=vmax,
            cbar=True  # optional: remove individual colorbars
        )

        # ax.set_title(f"Outcome Pair {pair}")
        ax.set_title(f"Pair {pair}", loc='left', fontsize=12,weight='bold')
        # ax.set_xlabel("Epsilon")
        # ax.set_ylabel("Memory Length")
        ax.set_xlabel("Memory Length")
        ax.set_ylabel("Epsilon")
        # ax.tick_params(axis='x', labelrotation=45)

    # fig.suptitle("Average Pre-shock Relative Frequency (%) - Memory Length vs Epsilon", fontsize=18, y=0.97)
    fig.suptitle("Average Pre-shock Relative Frequency (%) - Epsilon vs Memory Length", fontsize=18, y=0.97)
    plt.show()


def plot_recovery_heatmap_grid(results_df):
    results_df = filter_invalid_recovery(results_df.copy()).copy()
    results_df = results_df[results_df["recovery_time"].notna()]
    outcome_pairs = sorted(results_df["pair"].unique())

    
    fig = plt.figure(figsize=(16, 14))
    gs = gridspec.GridSpec(2, 2, figure=fig, hspace=0.3, wspace=0.2)

    axes = [fig.add_subplot(gs[i, j]) for i in range(2) for j in range(2)]

    vmin = results_df["recovery_time"].min()
    vmax = results_df["recovery_time"].max()

    for ax, pair in zip(axes, outcome_pairs):
        df = results_df[results_df["pair"] == pair].copy()

        agg = (
            df.groupby(["memory_length", "epsilon"])
            .agg(pre_mean=("recovery_time", "mean"))
            .reset_index()
        )

        
        heat = agg.pivot_table(
            index="epsilon",
            columns="memory_length",
            values="pre_mean",
            aggfunc="mean"
        )
        heat = heat.sort_index(ascending=False)

        sns.heatmap(
            heat,
            annot=True,
            fmt=".0f",
            cmap="viridis",
            ax=ax,
            vmin=vmin,
            vmax=vmax,
            cbar=True  # optional: remove individual colorbars
        )

        # ax.set_title(f"Outcome Pair {pair}")
        ax.set_title(f"Pair {pair}", loc='left', fontsize=12,weight='bold')
        # ax.set_xlabel("Epsilon")
        ax.set_xlabel("Memory Length")
        ax.set_ylabel("Epsilon")
        # ax.set_ylabel("Memory Length")
        # ax.tick_params(axis='x', labelrotation=45)

    # fig.suptitle("Average Recovery Time (Count of timeperiods) - Memory Length vs Epsilon", fontsize=18, y=0.97)
    fig.suptitle("Average Recovery Time (Count of timeperiods) - Epsilon vs Memory Length", fontsize=18, y=0.97)
    plt.show()



def heatmap_standard_deviation_grid(results_df,var1):
    outcome_pairs = sorted(results_df["Norm pair"].unique())

    fig = plt.figure(figsize=(16, 14))

    gs = gridspec.GridSpec(2, 2, figure=fig, hspace=0.3, wspace=0.2)

    axes = [fig.add_subplot(gs[i, j]) for i in range(2) for j in range(2)]

    vmin = results_df[var1].min()
    vmax = results_df[var1].max()

    for ax, pair in zip(axes, outcome_pairs):
        df = results_df[results_df["Norm pair"] == pair].copy()

        
        heat = df.pivot_table(
            index="Epsilon",
            columns="Memory length",
            values=var1,
            aggfunc="mean"
        )
        heat = heat.sort_index(ascending=False)

        if var1 != 'Recovery time standard deviation':
            sns.heatmap(
                heat,
                annot=True,
                fmt=".1f",
                cmap="viridis",
                ax=ax,
                vmin=vmin,
                vmax=vmax,
                cbar=True  # optional: remove individual colorbars
            )
        else:
            sns.heatmap(
                heat,
                annot=True,
                fmt=".0f",
                cmap="viridis",
                ax=ax,
                vmin=vmin,
                vmax=vmax,
                cbar=True  # optional: remove individual colorbars
            )


        ax.set_title(f"Pair {pair}", loc='left', fontsize=12,weight='bold')
        ax.set_xlabel("Memory Length")
        ax.set_ylabel("Epsilon")
       
    if var1 == 'Pre-shock relative frequency standard deviation':
        fig.suptitle("Pre-shock Relative Frequency Standard Deviation (%) - Epsilon vs Memory Length", fontsize=18, y=0.97)
    elif var1 == 'Recovery time standard deviation':
        fig.suptitle("Recovery Time Standard Deviation (Count of timeperiods) - Epsilon vs Memory Length", fontsize=18, y=0.97)
    elif var1 == 'Fraction of runs returning to pre-shock norm (%)':
        fig.suptitle("Post-shock Recovery Rate (%) - Epsilon vs Memory Length", fontsize=18, y=0.97)

    
    plt.show()



def plot_individual_run(
    traj_df,
    shock_start,
    shock_end,
    pair_types=("0,0", "0,1", "1,0", "1,1"),
    figsize=(10, 5)
):
    """
    Plot pre- vs post-shock cumulative relative frequencies for each joint action pair,
    plus the sequence of pairs played during the shock window.

    Parameters
    ----------
    traj_df : pandas.DataFrame
        Must contain columns ["t", "row_action", "col_action"].
    shock_start : int
        First period of the shock.
    shock_end : int
        Last period of the shock.
    pair_types : tuple of str
        Joint action pairs to plot, formatted as "r,c".
    figsize : tuple
        Figure size for each subplot.
    """

    # Create pair column
    df = traj_df.copy()
    df["pair"] = df["row_action"].astype(str) + "," + df["col_action"].astype(str)

    pre_length = shock_start

    colors = {
        "0,0": "blue",
        "0,1": "orange",
        "1,0": "green",
        "1,1": "red"
    }

    # Compute cumulative pre/post frequencies
    for p in pair_types:
        df[f"pre_{p}"] = (
            (df["t"] < shock_start) & (df["pair"] == p)
        ).astype(int).cumsum()

        df[f"post_{p}"] = (
            (df["t"] > shock_end) & (df["pair"] == p)
        ).astype(int).cumsum()

        df[f"pre_{p}_pct"] = np.round(df[f"pre_{p}"] / pre_length * 100, 2)
        df[f"post_{p}_pct"] = np.round(df[f"post_{p}"] / pre_length * 100, 2)

    # ---- Plot cumulative curves for each pair ----
    for p in pair_types:
        plt.figure(figsize=figsize)

        plt.plot(df["t"], df[f"pre_{p}_pct"], label="Pre-shock", color=colors[p])
        plt.plot(df["t"], df[f"post_{p}_pct"], label="Post-shock",
                 linestyle="--", color=colors[p])

        plt.axvspan(shock_start, shock_end, color="gray", alpha=0.2)

        plt.xlabel("Time period")
        plt.ylabel("Cumulative Relative Frequency (%)")
        plt.title(f"Pre vs Post-shock Cumulative Frequency for pair ({p})")
        plt.legend()
        plt.grid(True)
        plt.tight_layout()
        plt.show()

    # ---- Plot the shock window sequence ----
    shock_df = df[(df["t"] >= shock_start) & (df["t"] <= shock_end)].copy()
    shock_df["pair"] = "(" + shock_df["row_action"].astype(str) + "," + shock_df["col_action"].astype(str) + ")"

    plt.figure(figsize=(12, 5))
    plt.plot(shock_df["t"], shock_df["pair"], marker="o")
    plt.yticks(["(0,0)", "(0,1)", "(1,0)", "(1,1)"])
    plt.xlabel("Time period")
    plt.ylabel("Pair played")
    plt.title("Agents' choices during the shock window")
    plt.grid(True)
    plt.tight_layout()
    plt.show()



def generate_all_outputs(results_df, output_dir=None):
    """
    Generates ALL graphs and ALL tables after Monte Carlo simulation.
    If output_dir is provided, saves all graphs and tables there.
    """

    import os
    if output_dir is not None:
        os.makedirs(output_dir, exist_ok=True)

    # -----------------------------
    # 1. GRAPHS
    # -----------------------------

    print("Generating graphs...")

    # 1. Pre vs Post shock frequency (all pairs)
    plt.figure()
    plot_pre_post_frequency_overall(results_df, 
        title="Average Pre vs Post Shock Relative Frequencies")
    if output_dir:
        plt.savefig(os.path.join(output_dir, "pre_post_freq_all_pairs.png"))
    plt.close()

    # 2. Recovery time per pair (mean ± sd)
    plt.figure()
    plot_recovery_time_per_pair(results_df, 
        title="Average Recovery Time per Pair")
    if output_dir:
        plt.savefig(os.path.join(output_dir, "recovery_time_per_pair.png"))
    plt.close()

    # 3. Pre-shock frequency vs memory (all pairs)
    plt.figure()
    plot_pre_freq_vs_memory_allpairs(results_df, 
        title="Average Pre-shock Relative Frequency vs Memory Length")
    if output_dir:
        plt.savefig(os.path.join(output_dir, "pre_freq_vs_memory.png"))
    plt.close()

    # 4. Recovery vs memory (all pairs)
    plt.figure()
    plot_recovery_vs_memory_allpairs(results_df, 
        title="Average Recovery Time vs Memory Length")
    if output_dir:
        plt.savefig(os.path.join(output_dir, "recovery_vs_memory.png"))
    plt.close()

    # 5. Pre-shock frequency vs epsilon (all pairs)
    plt.figure()
    plot_pre_freq_vs_epsilon_allpairs(results_df, 
        title="Average Pre-shock Relative Frequency vs Epsilon")
    if output_dir:
        plt.savefig(os.path.join(output_dir, "pre_freq_vs_epsilon.png"))
    plt.close()

    # 6. Recovery vs epsilon (all pairs)
    plt.figure()
    plot_recovery_vs_epsilon_allpairs(results_df, 
        title="Average Recovery Time vs Epsilon")
    if output_dir:
        plt.savefig(os.path.join(output_dir, "recovery_vs_epsilon.png"))
    plt.close()


    plot_binned_init_share_pre_freq_all_focal_pairs(
    results_df,
    output_dir=output_dir
    # title_prefix="Initial State vs Average Pre-shock Relative Frequency (%)"
)

    
    print("Graphs generated.")

    # -----------------------------
    # 2. TABLES
    # -----------------------------

    print("Generating tables...")

    # Table 1
    table1 = build_table_norm_epsilon_memory(results_df)
    if output_dir:
        table1.to_excel(os.path.join(output_dir, "table_norm_epsilon_memory.xlsx"), index=False)

    # Table 2
    table2 = build_table_norm_initial_state_bin(results_df)
    if output_dir:
        table2.to_excel(os.path.join(output_dir, "table_norm_initial_state_bin.xlsx"), index=False)

    # Table 3
    table3 = build_table_norm_shock_pair(results_df)
    if output_dir:
        table3.to_excel(os.path.join(output_dir, "table_norm_shock_pair.xlsx"), index=False)

    print("Tables generated.")

    return {
        "table1": table1,
        "table2": table2,
        "table3": table3
    }

