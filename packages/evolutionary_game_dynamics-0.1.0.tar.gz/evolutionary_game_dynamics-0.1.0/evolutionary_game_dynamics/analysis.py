from .utils import *

def build_table_norm_epsilon_memory(results_df):
    d = results_df.copy()

    # First compute simple aggregations using agg()
    base = (
        d.groupby(["pair", "epsilon", "memory_length"], observed=True)
        .agg(
            mean_pre=("pre_freq", "mean"),
            mean_post=("post_freq", "mean"),
            n_runs=("run_id", "count"),
            n_runs1=("run_id", "nunique"),
            sd_pre=("pre_freq", "std"),
            sd_post=("post_freq", "std")
        )
    )

    # Now compute recovery-related columns using apply() on full groups
    rec = (
        d.groupby(["pair", "epsilon", "memory_length"], observed=True)
        .apply(lambda g: pd.Series({
            "mean_rec": safe_mean_recovery(g),
            "sd_rec": safe_sd_recovery(g),
            "frac_returned":safe_frac_returned(g)
        }))
    )

    table = base.join(rec).reset_index()

    table.rename(columns={
        "pair": "Norm pair",
        "epsilon": "Epsilon",
        "memory_length": "Memory length",
        "mean_pre": "Mean relative frequency-pre shock (%)",
        "mean_post": "Mean relative frequency-post shock (%)",
        "mean_rec": "Mean recovery time (Count of timeperiods)",
        "sd_pre": "Pre-shock relative frequency standard deviation",
        "sd_post": "Post-shock relative frequency standard deviation",
        "sd_rec": "Recovery time standard deviation",
        "frac_returned":"Fraction of runs returning to pre-shock norm (%)",
        "n_runs":"Runs count",
        "n_runs1":"Runs count unique"
    }, inplace=True)

    return table



def build_table_norm_shock_pair(results_df):
    d = results_df.copy()

    base = (
        d.groupby(["pair", "shock_joint"], observed=True)
        .agg(
            mean_pre=("pre_freq", "mean"),
            mean_post=("post_freq", "mean"),
            n_runs=("run_id", "count"),
            n_runs1=("run_id", "nunique"),
            sd_pre=("pre_freq", "std"),
            sd_post=("post_freq", "std")
        )
    )

    rec = (
        d.groupby(["pair", "shock_joint"], observed=True)
        .apply(lambda g: pd.Series({
            "mean_rec": safe_mean_recovery(g),
            "sd_rec": safe_sd_recovery(g),
            "frac_ret": safe_frac_returned(g)
        }))
    )

    table = base.join(rec).reset_index()

    table.rename(columns={
        "pair": "Norm pair",
        "shock_joint": "Shock Pair",
        "mean_pre": "Mean relative frequency-pre shock (%)",
        "mean_post": "Mean relative frequency-post shock (%)",
        "mean_rec": "Mean recovery time (Count of timeperiods)",
        "frac_ret": "Fraction of runs returning to pre-shock norm (%)",
        "sd_pre": "Pre-shock relative frequency standard deviation",
        "sd_post": "Post-shock relative frequency standard deviation",
        "sd_rec": "Recovery time standard deviation",
        "n_runs":"Runs count",
        "n_runs1":"Runs count unique"
    }, inplace=True)

    
    return table




def build_table_norm_initial_state_bin(results_df, bins=np.arange(0,110,10)):

    records = []

    for pair_str in results_df["pair"].unique():
        d = results_df[results_df["focal_pair"] == pair_str].copy()
        d["init_share_self"] = d["init_share_focal"] * 100



       
        d["init_bin"] = pd.cut(d["init_share_self"], bins=bins, include_lowest=True)
        d["init_bin_label"] = d["init_bin"].apply(
            lambda x: f"({int(x.left)}, {int(x.right)}]" if pd.notna(x) else "NA"
        )

        agg = (
            
            d.groupby(["init_bin_label", "pair","memory_length"], observed=True)
            .agg(
                mean_pre=("pre_freq", "mean"),
                sd_pre=("pre_freq", "std"),
                n_runs=("run_id", "nunique")
            )
            .reset_index()
        )

        agg["Initial state pair"] = pair_str
        records.append(agg)

    table = pd.concat(records, ignore_index=True)

    table.rename(columns={
        "init_bin_label": "Initial state pair share - bins (%)",
        "mean_pre": "Mean relative frequency-pre shock (%)",
        "sd_pre": "Pre-shock relative frequency standard deviation",
        "pair":"Outcome pair",
        "n_runs":"Runs count"
    }, inplace=True)


    return table



