import numpy as np
import pandas as pd
import random
import secrets
from collections import Counter
import itertools
import os
import matplotlib.gridspec as gridspec

import matplotlib.pyplot as plt
import seaborn as sns

sns.set(style="whitegrid")

def get_distinct_actions_from_history(history):
    """
    history: list of (row_action, col_action)
    returns:
        distinct_cols_seen_by_row, distinct_rows_seen_by_col
    """
    cols = [c for (r, c) in history]
    rows = [r for (r, c) in history]
    return sorted(list(set(cols))), sorted(list(set(rows)))

def best_responses_row(distinct_cols, payoff_matrix_row):
    """
    distinct_cols: list of column actions seen
    payoff_matrix_row: shape (num_rows, num_cols)
    returns: sorted list of row actions that are best responses
            to at least one distinct column action
    """
    num_rows, _ = payoff_matrix_row.shape
    best_rows = set()
    for col_a in distinct_cols:
        payoffs = [payoff_matrix_row[r, col_a] for r in range(num_rows)]
        max_payoff = max(payoffs)
        for r, p in enumerate(payoffs):
            if p == max_payoff:
                best_rows.add(r)
    return sorted(list(best_rows))


def best_responses_col(distinct_rows, payoff_matrix_col):
    """
    distinct_rows: list of row actions seen
    payoff_matrix_col: shape (num_rows, num_cols)
    returns: sorted list of column actions that are best responses
            to at least one distinct row action
    """
    num_rows, num_cols = payoff_matrix_col.shape
    best_cols = set()
    for row_a in distinct_rows:
        payoffs = [payoff_matrix_col[row_a, c] for c in range(num_cols)]
        max_payoff = max(payoffs)
        for c, p in enumerate(payoffs):
            if p == max_payoff:
                best_cols.add(c)
    return sorted(list(best_cols))



def update_epsilon(epsilon_current,
                   t,
                   time_period_randomness_reduce=None,
                   percent_reduce_randomness=0.5,
                   remove_randomness='No'):
    """
    epsilon_current: float in [0,1]
    t: current time step (int)
    time_period_randomness_reduce: int or None
    percent_reduce_randomness: fraction by which epsilon is reduced at that time
    remove_randomness: 'Yes' -> epsilon = 0 at that time
    """
    if time_period_randomness_reduce is not None and t == time_period_randomness_reduce:
        if remove_randomness == 'Yes':
            return 0.0
        else:
            new_eps = epsilon_current * (1 - percent_reduce_randomness)
            return max(0.0, min(1.0, new_eps))
    else:
        return epsilon_current
    

def epsilon_greedy_choice(best_actions, all_actions, epsilon):
    """
    best_actions: list of indices considered best responses
    all_actions: full action set, e.g. list(range(num_rows))
    epsilon in [0, 1]

    With prob 1 - epsilon: choose uniformly among best_actions.
    With prob epsilon: choose uniformly among all_actions.
    """
    if len(best_actions) == 0:
        return random.choice(all_actions)

    epsilon = max(0.0, min(1.0, epsilon))

    if random.random() < (1 - epsilon):
        return random.choice(best_actions)
    else:
        return random.choice(all_actions)
    

def compute_initial_distribution(initial_history, num_rows, num_cols):
    """
    initial_history: list of (row_action, col_action) of length memory_length
    Returns a dict { (r,c): frequency } over all joint actions.
    """
    counts = Counter(initial_history)
    total = len(initial_history)
    all_pairs = [(r, c) for r in range(num_rows) for c in range(num_cols)]

    dist = {}
    for pair in all_pairs:
        dist[pair] = counts[pair] / total if total > 0 else 0.0
    return dist


def initial_distribution_to_string(initial_dist):
    """
    Convert initial distribution dict to a stable, compact string
    for grouping/Excel export.
    """
    items = sorted(initial_dist.items())
    return ";".join([f"{pair}:{freq:.3f}" for pair, freq in items])


def generate_initial_history(num_rows, num_cols, memory_length, scheme="random"):
    """
    Returns a list of (row_action, col_action) of length memory_length.
    scheme can be:
        - "random"
        - "all_00"
        - "all_11"
        - etc., you can extend.
    """
    if scheme == "random":
        return [(random.randrange(num_rows), random.randrange(num_cols)) for _ in range(memory_length)]
    elif scheme == "all_00":
        return [(0, 0) for _ in range(memory_length)]
    elif scheme == "all_11":
        r = min(1, num_rows - 1)
        c = min(1, num_cols - 1)
        return [(r, c) for _ in range(memory_length)]
    else:
        # default to random
        return [(random.randrange(num_rows), random.randrange(num_cols)) for _ in range(memory_length)]
    

def generate_initial_history_balanced(num_rows, num_cols, memory_length, focal_pair):
    # 1. Choose a count uniformly from 0..memory_length
    possible_counts = list(range(0, memory_length + 1))
    count = random.choice(possible_counts)

    # 2. Build history with required number of focal-pair occurrences
    history = [focal_pair] * count

    # 3. Fill remaining slots with random other pairs
    remaining = memory_length - count
    for _ in range(remaining):
        others = [(r,c) for r in range(num_rows) for c in range(num_cols) if (r,c) != focal_pair]
        history.append(random.choice(others))
        
    # 4. Shuffle to avoid ordering bias
    random.shuffle(history)

    return history


def generate_all_distributions(num_rows, num_cols, memory_length):
    """
    Generate ALL possible initial distributions for memory_length M.
    Returns a list of (dist_str, counts_dict).
    """
    actions = [(r,c) for r in range(num_rows) for c in range(num_cols)]
    results = []

    # Enumerate all integer partitions n1+n2+n3+n4 = M
    for n00 in range(memory_length + 1):
        for n01 in range(memory_length - n00 + 1):
            for n10 in range(memory_length - n00 - n01 + 1):
                n11 = memory_length - n00 - n01 - n10

                counts = {
                    actions[0]: n00,
                    actions[1]: n01,
                    actions[2]: n10,
                    actions[3]: n11
                }

                # Convert to distribution string
                dist_str = ";".join([
                    f"{pair}:{counts[pair]/memory_length:.3f}"
                    for pair in actions
                ])

                results.append((dist_str, counts))

    return results


def build_history_from_counts(counts):
    """
    counts: dict {(r,c): count}
    Returns a shuffled list of (r,c) pairs of total length M.
    """
    history = []
    for pair, cnt in counts.items():
        history.extend([pair] * cnt)

    random.shuffle(history)
    return history



def filter_invalid_recovery(df):
    return df[~((df["pre_freq"] == 0) &
                (df["recovery_time"] == 0) &
                (df["returned"] == True))].reset_index(drop=True)



def parse_pair_string(s):
    """
    s like '(0, 0)' -> (0, 0)
    """
    return eval(s)


def parse_initial_distribution_string(s):
    """
    s like '(0, 0):0.000;(0, 1):0.000;(1, 0):1.000;(1, 1):0.000'
    returns dict {(0,0): 0.0, ...}
    """
    parts = s.split(";")
    dist = {}
    for part in parts:
        part = part.strip()
        if not part:
            continue
        key_str, freq_str = part.split(":")
        key = eval(key_str.strip())
        freq = float(freq_str)
        dist[key] = freq
    return dist



def compute_init_share_for_pair(results_df, focal_pair=(0,0)):
    """
    Returns a copy of results_df with a new column 'init_share_focal',
    the initial share of 'focal_pair' in the initial_distribution.
    """
    d = results_df.copy()
    shares = []
    fp = tuple(focal_pair)
    for s in d["initial_distribution"]:
        dist = parse_initial_distribution_string(s)
        shares.append(dist.get(fp, 0.0))
    d["init_share_focal"] = shares
    return d



def safe_mean_recovery(df_group):
    d = df_group.copy()
    invalid = (
        (d["pre_freq"] == 0) &
        (d["recovery_time"] == 0) &
        (d["returned"] == True)
    )
    d = d[~invalid & d["recovery_time"].notna()]
    if len(d) == 0:
        return np.nan
    return d["recovery_time"].mean()


def safe_sd_recovery(df_group):
    d = df_group.copy()
    invalid = (
        (d["pre_freq"] == 0) &
        (d["recovery_time"] == 0) &
        (d["returned"] == True)
    )
    d = d[~invalid & d["recovery_time"].notna()]
    if len(d) == 0:
        return np.nan
    return d["recovery_time"].std()


def safe_frac_returned(df_group):
    d = df_group.copy()
    invalid = (
        (d["pre_freq"] == 0) &
        (d["recovery_time"] == 0) &
        (d["returned"] == True)
    )
    d = d[~invalid]
    if len(d) == 0:
        return np.nan
    return (d["returned"].mean() * 100.0)  # percent


