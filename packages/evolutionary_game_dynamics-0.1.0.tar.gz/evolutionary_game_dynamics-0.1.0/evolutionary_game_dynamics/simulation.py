from .utils import *
from .response_functions import *


def simulate_two_player_game(
    num_rows,
    num_cols,
    memory_length,
    timeperiod,
    row_player_payoffs,
    column_player_payoffs,
    epsilon_row=0.1,
    epsilon_col=0.1,
    time_period_randomness_reduce_row=None,
    time_period_randomness_reduce_col=None,
    percent_reduce_randomness_row=0.5,
    percent_reduce_randomness_col=0.5,
    remove_randomness_row='No',
    remove_randomness_col='No',
    initial_history=None,
    random_seed=0,
    response_rule=None,
    export_history_path=None
):
    """
    Stochastic trajectory simulation of the exhaustive best-response process.

    Returns:
        traj_df: columns ["t", "row_action", "col_action", "initial_distribution", "seed"]
        freq_df: columns ["joint_action", "count", "frequency", "initial_distribution", "seed"]
    """

    # random.seed(random_seed)
    # np.random.seed(random_seed)

    payoff_matrix_row = np.array(row_player_payoffs).reshape((num_rows, num_cols))
    payoff_matrix_col = np.array(column_player_payoffs).reshape((num_rows, num_cols))

    # initialize history
    if initial_history is None:
        history = [
            (random.randrange(num_rows), random.randrange(num_cols))
            for _ in range(memory_length)
        ]
    else:
        history = list(initial_history)

    initial_dist = compute_initial_distribution(history, num_rows, num_cols)
    initial_dist_str = initial_distribution_to_string(initial_dist)

    trajectory = []
    joint_counts = Counter()

    eps_row = epsilon_row
    eps_col = epsilon_col

    for t in range(timeperiod):
        eps_row = update_epsilon(
            eps_row, t,
            time_period_randomness_reduce=time_period_randomness_reduce_row,
            percent_reduce_randomness=percent_reduce_randomness_row,
            remove_randomness=remove_randomness_row
        )
        eps_col = update_epsilon(
            eps_col, t,
            time_period_randomness_reduce=time_period_randomness_reduce_col,
            percent_reduce_randomness=percent_reduce_randomness_col,
            remove_randomness=remove_randomness_col
        )

        # row_action = exhaustive_epsilon_policy_row(history, payoff_matrix_row, num_rows, eps_row)
        # col_action = exhaustive_epsilon_policy_col(history, payoff_matrix_col, num_cols, eps_col)
        
        
        row_action = unified_response(
                        history=history,
                        payoff_matrix=payoff_matrix_row,
                        epsilon=eps_row,
                        player="row",
                        rule=response_rule,  # "exhaustive" or "expected"
                        exhaustive_row=exhaustive_epsilon_policy_row,
                        exhaustive_col=exhaustive_epsilon_policy_col,
                        expected_row=expected_payoff_policy_row,
                        expected_col=expected_payoff_policy_col,
                        num_rows=num_rows,
                        num_cols=num_cols
                        )

        col_action = unified_response(
                        history=history,
                        payoff_matrix=payoff_matrix_col,
                        epsilon=eps_col,
                        player="col",
                        rule=response_rule,
                        exhaustive_row=exhaustive_epsilon_policy_row,
                        exhaustive_col=exhaustive_epsilon_policy_col,
                        expected_row=expected_payoff_policy_row,
                        expected_col=expected_payoff_policy_col,
                        num_rows=num_rows,
                        num_cols=num_cols
                        )
        
        
        joint = (row_action, col_action)

        trajectory.append((t, joint[0], joint[1]))
        joint_counts[str(joint)] += 1

        if memory_length > 0:
            history.pop(0)
            history.append(joint)

    traj_df = pd.DataFrame(trajectory, columns=["t", "row_action", "col_action"])
    traj_df["initial_distribution"] = initial_dist_str
    traj_df["seed"] = random_seed

    if export_history_path is not None:
        os.makedirs(os.path.dirname(export_history_path), exist_ok=True)
        traj_df.to_excel(export_history_path, index=False)

    total = sum(joint_counts.values())
    freq_data = []
    for k, v in joint_counts.items():
        freq_data.append({
            "joint_action": k,
            "count": v,
            "frequency": v / total if total > 0 else 0.0,
            "initial_distribution": initial_dist_str,
            "seed": random_seed
        })
    freq_df = pd.DataFrame(freq_data).sort_values(by="frequency", ascending=False).reset_index(drop=True)

    return traj_df, freq_df




def simulate_with_shock(
    num_rows,
    num_cols,
    memory_length,
    timeperiod,
    row_player_payoffs,
    column_player_payoffs,
    epsilon_row=0.1,
    epsilon_col=0.1,
    time_period_randomness_reduce_row=None,
    time_period_randomness_reduce_col=None,
    percent_reduce_randomness_row=0.5,
    percent_reduce_randomness_col=0.5,
    remove_randomness_row='No',
    remove_randomness_col='No',
    initial_history=None,
    random_seed=0,
    shock_time=None,           # int or None
    shock_duration=0,          # integer ≥ 0
    shock_joint=None,          # tuple (row_action, col_action) or None
    shock_payoff_row=None,
    shock_payoff_col=None,
    response_rule=None,
    export_history_path=None
):
    """
    Like simulate_two_player_game, but:
    - if shock_time is not None, then for t in [shock_time, shock_time+shock_duration-1]
      we override the chosen actions with shock_joint.

    shock_joint is passed from outside; if None, random pair is chosen.

    Returns:
        traj_df, freq_df (with initial_distribution, seed, shock info)
    """

    # random.seed(random_seed)
    # np.random.seed(random_seed)

    payoff_matrix_row = np.array(row_player_payoffs).reshape((num_rows, num_cols))
    payoff_matrix_col = np.array(column_player_payoffs).reshape((num_rows, num_cols))

    if shock_payoff_row is not None:
        shock_payoff_matrix_row = np.array(shock_payoff_row).reshape((num_rows, num_cols))
    else:
        shock_payoff_matrix_row = None

    if shock_payoff_col is not None:
        shock_payoff_matrix_col = np.array(shock_payoff_col).reshape((num_rows, num_cols))
    else:
        shock_payoff_matrix_col = None

    # initialize history
    if initial_history is None:
        history = [
            (random.randrange(num_rows), random.randrange(num_cols))
            for _ in range(memory_length)
        ]
    else:
        history = list(initial_history)

    initial_dist = compute_initial_distribution(history, num_rows, num_cols)
    initial_dist_str = initial_distribution_to_string(initial_dist)

    if shock_joint is None:
        shock_joint = (random.randrange(num_rows), random.randrange(num_cols))

    trajectory = []
    joint_counts = Counter()

    eps_row = epsilon_row
    eps_col = epsilon_col

    for t in range(timeperiod):
        eps_row = update_epsilon(
            eps_row, t,
            time_period_randomness_reduce=time_period_randomness_reduce_row,
            percent_reduce_randomness=percent_reduce_randomness_row,
            remove_randomness=remove_randomness_row
        )
        eps_col = update_epsilon(
            eps_col, t,
            time_period_randomness_reduce=time_period_randomness_reduce_col,
            percent_reduce_randomness=percent_reduce_randomness_col,
            remove_randomness=remove_randomness_col
        )

        # 1. Choose which payoff matrices to use this period
        current_payoff_row = payoff_matrix_row
        current_payoff_col = payoff_matrix_col

        if shock_time is not None and shock_duration > 0:
            if shock_time <= t < shock_time + shock_duration:
                if shock_payoff_matrix_row is not None:
                    current_payoff_row = shock_payoff_matrix_row
                if shock_payoff_matrix_col is not None:
                    current_payoff_col = shock_payoff_matrix_col

        # 2. Choose actions based on CURRENT payoffs
        # row_action = exhaustive_epsilon_policy_row(
        #     history, current_payoff_row, num_rows, eps_row
        # )
        # col_action = exhaustive_epsilon_policy_col(
        #     history, current_payoff_col, num_cols, eps_col
        # )
        
        row_action = unified_response(
                        history=history,
                        payoff_matrix=payoff_matrix_row,
                        epsilon=eps_row,
                        player="row",
                        rule=response_rule,  # "exhaustive" or "expected"
                        exhaustive_row=exhaustive_epsilon_policy_row,
                        exhaustive_col=exhaustive_epsilon_policy_col,
                        expected_row=expected_payoff_policy_row,
                        expected_col=expected_payoff_policy_col,
                        num_rows=num_rows,
                        num_cols=num_cols
                        )

        col_action = unified_response(
                        history=history,
                        payoff_matrix=payoff_matrix_col,
                        epsilon=eps_col,
                        player="col",
                        rule=response_rule,
                        exhaustive_row=exhaustive_epsilon_policy_row,
                        exhaustive_col=exhaustive_epsilon_policy_col,
                        expected_row=expected_payoff_policy_row,
                        expected_col=expected_payoff_policy_col,
                        num_rows=num_rows,
                        num_cols=num_cols
                        )
        
        
        
        
        joint = (row_action, col_action)

        
        # row_action = exhaustive_epsilon_policy_row(history, payoff_matrix_row, num_rows, eps_row)
        # col_action = exhaustive_epsilon_policy_col(history, payoff_matrix_col, num_cols, eps_col)
        # joint = (row_action, col_action)

        # if shock_time is not None and shock_duration > 0:
        #     if shock_time <= t < shock_time + shock_duration:
        #         joint = shock_joint

        trajectory.append((t, joint[0], joint[1]))
        joint_counts[str(joint)] += 1

        if memory_length > 0:
            history.pop(0)
            history.append(joint)

    traj_df = pd.DataFrame(trajectory, columns=["t", "row_action", "col_action"])
    traj_df["initial_distribution"] = initial_dist_str
    traj_df["seed"] = random_seed
    traj_df["shock_time"] = shock_time
    traj_df["shock_duration"] = shock_duration
    traj_df["shock_joint"] = str(shock_joint)

    if export_history_path is not None:
        os.makedirs(os.path.dirname(export_history_path), exist_ok=True)
        traj_df.to_excel(export_history_path, index=False)

    total = sum(joint_counts.values())
    freq_data = []
    for k, v in joint_counts.items():
        freq_data.append({
            "joint_action": k,
            "count": v,
            "frequency": v / total if total > 0 else 0.0,
            "initial_distribution": initial_dist_str,
            "seed": random_seed,
            "shock_time": shock_time,
            "shock_duration": shock_duration,
            "shock_joint": str(shock_joint)
        })
    freq_df = pd.DataFrame(freq_data).sort_values(by="frequency", ascending=False).reset_index(drop=True)

    return traj_df, freq_df



def compute_post_shock_frequencies(traj_df, shock_time, shock_duration, num_rows, num_cols):
    """
    Computes post-shock frequencies for all pairs.
    Returns dict: { "(r, c)": percentage }
    """
    start_post = shock_time + shock_duration
    post = traj_df[traj_df["t"] >= start_post]

    total = len(post)
    counts = Counter()

    for _, row in post.iterrows():
        pair = (row["row_action"], row["col_action"])
        counts[pair] += 1

    all_pairs = [(r, c) for r in range(num_rows) for c in range(num_cols)]
    post_freqs = {}

    for p in all_pairs:
        freq = (counts[p] / total * 100) if total > 0 else 0.0
        post_freqs[str(p)] = round(freq, 2)

    return post_freqs


def compute_pre_shock_frequencies(traj_df, shock_time, num_rows, num_cols):
    """
    traj_df: ["t","row_action","col_action", ...]
    shock_time: int, use data with t < shock_time
    Returns a dict: { (r,c): pre_shock_freq }
    """
    pre = traj_df[traj_df["t"] < shock_time]
    total = len(pre)
    counts = Counter()
    for _, row in pre.iterrows():
        joint = (row["row_action"], row["col_action"])
        counts[joint] += 1

    freqs = {}
    all_pairs = [(r, c) for r in range(num_rows) for c in range(num_cols)]
    for pair in all_pairs:
        freqs[pair] = counts[pair] / total if total > 0 else 0.0

    return freqs


def compute_recovery_times_for_all_pairs(traj_df,
                                         pre_shock_freqs,
                                         post_shock_freqs,
                                         shock_time,
                                         shock_duration,
                                         num_rows,
                                         num_cols):
    """
    traj_df: full trajectory, shock already applied
    pre_shock_freqs: dict { (r,c): pre_shock_freq }
    Returns a DataFrame with columns:
    ["pair", "pre_freq", "recovery_time", "returned",
     "initial_distribution", "seed", "shock_time", "shock_duration", "shock_joint"]
    """
    start_post = shock_time + shock_duration
    post = traj_df[traj_df["t"] >= start_post].copy()

    initial_dist_str = traj_df["initial_distribution"].iloc[0]
    seed = traj_df["seed"].iloc[0]
    shock_time_val = traj_df["shock_time"].iloc[0]
    shock_duration_val = traj_df["shock_duration"].iloc[0]
    shock_joint_str = traj_df["shock_joint"].iloc[0]

    # initialize counters for each pair
    all_pairs = [(r, c) for r in range(num_rows) for c in range(num_cols)]
    counts = {pair: 0 for pair in all_pairs}
    recovery_times = {pair: None for pair in all_pairs}

    if len(post) == 0:
        rows = []
        for p in all_pairs:
            rows.append({
                "pair": str(p),
                "pre_freq": pre_shock_freqs[p],
                "post_freq":post_shock_freqs[str(p)],
                "recovery_time": None,
                "returned": False,
                "initial_distribution": initial_dist_str,
                "seed": seed,
                "shock_time": shock_time_val,
                "shock_duration": shock_duration_val,
                "shock_joint": shock_joint_str,
                "post_length": len(post)
            })
        return pd.DataFrame(rows)

    # first_idx = post.index[0]
    total=len(post)

    for idx, row in post.iterrows():
        t_rel = row["t"] - start_post  # time since end of shock
        pair = (row["row_action"], row["col_action"])

        counts[pair] += 1
        # total = (idx - first_idx) + 1

        for p in all_pairs:
            if recovery_times[p] is None:
                freq = counts[p] / total*100
                if freq >= pre_shock_freqs[p]:
                    recovery_times[p] = t_rel

    rows = []
    for p in all_pairs:
        rows.append({
            "pair": str(p),
            "pre_freq": pre_shock_freqs[p],
            "post_freq":post_shock_freqs[str(p)],
            "recovery_time": recovery_times[p],
            "returned": recovery_times[p] is not None,
            "initial_distribution": initial_dist_str,
            "seed": seed,
            "shock_time": shock_time_val,
            "shock_duration": shock_duration_val,
            "shock_joint": shock_joint_str,
            "post_length": len(post)
        })

    return pd.DataFrame(rows)



def run_sensitivity_with_shock(
    num_rows,
    num_cols,
    row_player_payoffs,
    column_player_payoffs,
    shock_payoff_row,
    shock_payoff_col,
    memory_lengths,
    epsilons,
    timeperiods,
    shock_times,
    shock_durations,
    initial_schemes,
    n_runs_per_setting=20,
    random_seed=None,
    response_rule=None,
    export_dir=None,
    iter_name=None
):
    """
    Runs Monte Carlo sensitivity analysis with shock.

    For each combination of:
        memory_length, epsilon, timeperiod, shock_time, shock_duration, initial_scheme
    we run n_runs_per_setting simulations, compute pre-shock freqs and
    recovery times for all pairs.

    Returns:
        results_df: one row per (setting, run, pair)
    """

    
    random.seed(random_seed)
    np.random.seed(random_seed)
    
    payoff_row = row_player_payoffs
    payoff_col = column_player_payoffs

    results = []
    # seed_idx = 0
    run_counter = 0

    focal_pairs = [(r, c) for r in range(num_rows) for c in range(num_cols)]
    num_pairs = len(focal_pairs)


    if export_dir is not None:
        os.makedirs(export_dir, exist_ok=True)

    for mem in memory_lengths:
        for eps in epsilons:
            for T in timeperiods:
                for sh_time in shock_times:
                    for sh_dur in shock_durations:
                        for init_scheme in initial_schemes:
                            for run_id in range(n_runs_per_setting):
                                
                                pair_index = run_id % num_pairs
                                focal_pair = focal_pairs[pair_index]
                                
                                if init_scheme == "balanced":
                                    
                                    # pair_index = run_id % num_pairs
                                    # focal_pair = focal_pairs[pair_index]

                                    initial_history = generate_initial_history_balanced(
                                        num_rows, num_cols, mem, focal_pair=focal_pair
                                    )
                                else:
                                    initial_history = generate_initial_history(
                                        num_rows, num_cols, mem, scheme=init_scheme
                                    )

                                # Count how many times the focal pair appears in the initial history
                                init_count = sum(1 for h in initial_history if h == focal_pair)
                                init_share_focal = init_count / mem   # value in [0,1]
                                shock_joint = (random.randrange(num_rows), random.randrange(num_cols))

                                export_path = None
                                if export_dir is not None:
                                    export_path = os.path.join(
                                        export_dir,
                                        f"traj_mem{mem}_eps{eps}_T{T}_shT{sh_time}_shD{sh_dur}_"
                                        f"init{init_scheme}_run{run_id}_seed{random_seed}.xlsx"
                                    )

                                traj_df, _ = simulate_with_shock(
                                    num_rows=num_rows,
                                    num_cols=num_cols,
                                    memory_length=mem,
                                    timeperiod=T,
                                    row_player_payoffs=payoff_row,
                                    column_player_payoffs=payoff_col,
                                    epsilon_row=eps,
                                    epsilon_col=eps,
                                    time_period_randomness_reduce_row=None,
                                    time_period_randomness_reduce_col=None,
                                    percent_reduce_randomness_row=0.5,
                                    percent_reduce_randomness_col=0.5,
                                    remove_randomness_row='No',
                                    remove_randomness_col='No',
                                    initial_history=initial_history,
                                    random_seed=random_seed,
                                    shock_time=sh_time,
                                    shock_duration=sh_dur,
                                    shock_joint=shock_joint,
                                    shock_payoff_row=shock_payoff_row,
                                    shock_payoff_col=shock_payoff_col,
                                    export_history_path=export_path,
                                    response_rule=response_rule
                                )

                                pre_freqs = compute_pre_shock_frequencies(
                                    traj_df, sh_time, num_rows, num_cols
                                )
                                # pre_freqs=round(pre_freqs * 100, 2)
                                pre_freqs = {k: round(v * 100, 2) for k, v in pre_freqs.items()}
                                
                                post_freqs = compute_post_shock_frequencies(
                                                traj_df,
                                                shock_time=sh_time,
                                                shock_duration=sh_dur,
                                                num_rows=num_rows,
                                                num_cols=num_cols
                                            )

                                rec_df = compute_recovery_times_for_all_pairs(
                                    traj_df,
                                    pre_shock_freqs=pre_freqs,
                                    post_shock_freqs=post_freqs,
                                    shock_time=sh_time,
                                    shock_duration=sh_dur,
                                    num_rows=num_rows,
                                    num_cols=num_cols
                                )

                                rec_df["memory_length"] = mem
                                rec_df["epsilon"] = eps
                                rec_df["timeperiod"] = T
                                rec_df["shock_time"] = sh_time
                                rec_df["shock_duration"] = sh_dur
                                rec_df["run_id"] = run_id
                                rec_df["initial_scheme"] = init_scheme
                                rec_df["focal_pair"] = str(focal_pair)
                                rec_df["init_share_focal"] = init_share_focal
                                
                                results.append(rec_df)
                                run_counter += 1

    if len(results) == 0:
        return pd.DataFrame()

    results_df = pd.concat(results, ignore_index=True)

    if export_dir is not None:
        results_path = os.path.join(export_dir, f"monte_carlo_results_{iter_name}.xlsx")
        results_df.to_excel(results_path, index=False)

    return results_df


def run_sensitivity_with_shock_adjusted_init_state(
    num_rows,
    num_cols,
    row_player_payoffs,
    column_player_payoffs,
    shock_payoff_row,
    shock_payoff_col,
    memory_lengths,
    epsilons,
    timeperiods,
    shock_times,
    shock_durations,
    canonical_sets,
    n_runs_per_setting=20,
    random_seed=None,
    export_dir=None,
    iter_name=None,
    response_rule=None
):
    """
    Runs Monte Carlo sensitivity analysis with shock.

    For each combination of:
        memory_length, epsilon, timeperiod, shock_time, shock_duration, initial_scheme
    we run n_runs_per_setting simulations, compute pre-shock freqs and
    recovery times for all pairs.

    Returns:
        results_df: one row per (setting, run, pair)
    """

    
    random.seed(random_seed)
    np.random.seed(random_seed)
    
    payoff_row = row_player_payoffs
    payoff_col = column_player_payoffs

    results = []
    # seed_idx = 0
    run_counter = 0

    focal_pairs = [(r, c) for r in range(num_rows) for c in range(num_cols)]
    num_pairs = len(focal_pairs)

    initial_schemes=['canonical']


    if export_dir is not None:
        os.makedirs(export_dir, exist_ok=True)

    for mem in memory_lengths:
        full = canonical_sets[mem]
        needed = n_runs_per_setting

        if len(full) >= needed:
            selected = full[:needed]
        else:
            repeats = needed // len(full)
            remainder = needed % len(full)
            selected = full * repeats
            selected += random.sample(full, remainder)

        for eps in epsilons:
            for T in timeperiods:
                for sh_time in shock_times:
                    for sh_dur in shock_durations:
                        for init_scheme in initial_schemes:
                            for run_id in range(n_runs_per_setting):
                                
                                dist_str, counts = selected[run_id]
                                initial_history = build_history_from_counts(counts)
                                init_share_focal = max(counts.values()) / mem if mem > 0 else 0.0

                                shock_joint = (random.randrange(num_rows), random.randrange(num_cols))

                                export_path = None
                                if export_dir is not None:
                                    export_path = os.path.join(
                                        export_dir,
                                        f"traj_mem{mem}_eps{eps}_T{T}_shT{sh_time}_shD{sh_dur}_"
                                        f"init{init_scheme}_run{run_id}_seed{random_seed}.xlsx"
                                    )

                                traj_df, _ = simulate_with_shock(
                                    num_rows=num_rows,
                                    num_cols=num_cols,
                                    memory_length=mem,
                                    timeperiod=T,
                                    row_player_payoffs=payoff_row,
                                    column_player_payoffs=payoff_col,
                                    epsilon_row=eps,
                                    epsilon_col=eps,
                                    time_period_randomness_reduce_row=None,
                                    time_period_randomness_reduce_col=None,
                                    percent_reduce_randomness_row=0.5,
                                    percent_reduce_randomness_col=0.5,
                                    remove_randomness_row='No',
                                    remove_randomness_col='No',
                                    initial_history=initial_history,
                                    random_seed=random_seed,
                                    shock_time=sh_time,
                                    shock_duration=sh_dur,
                                    shock_joint=shock_joint,
                                    shock_payoff_row=shock_payoff_row,
                                    shock_payoff_col=shock_payoff_col,
                                    export_history_path=export_path,
                                    response_rule=response_rule
                                )

                                pre_freqs = compute_pre_shock_frequencies(
                                    traj_df, sh_time, num_rows, num_cols
                                )
                                # pre_freqs=round(pre_freqs * 100, 2)
                                pre_freqs = {k: round(v * 100, 2) for k, v in pre_freqs.items()}
                                
                                post_freqs = compute_post_shock_frequencies(
                                                traj_df,
                                                shock_time=sh_time,
                                                shock_duration=sh_dur,
                                                num_rows=num_rows,
                                                num_cols=num_cols
                                            )

                                rec_df = compute_recovery_times_for_all_pairs(
                                    traj_df,
                                    pre_shock_freqs=pre_freqs,
                                    post_shock_freqs=post_freqs,
                                    shock_time=sh_time,
                                    shock_duration=sh_dur,
                                    num_rows=num_rows,
                                    num_cols=num_cols
                                )

                                rec_df["memory_length"] = mem
                                rec_df["epsilon"] = eps
                                rec_df["timeperiod"] = T
                                rec_df["shock_time"] = sh_time
                                rec_df["shock_duration"] = sh_dur
                                rec_df["run_id"] = run_id
                                rec_df["initial_scheme"] = init_scheme
                                # rec_df["focal_pair"] = str(focal_pair)
                                rec_df["focal_pair"] = ''
                                rec_df["init_share_focal"] = init_share_focal
                                
                                results.append(rec_df)
                                run_counter += 1

    if len(results) == 0:
        return pd.DataFrame()

    results_df = pd.concat(results, ignore_index=True)

    if export_dir is not None:
        results_path = os.path.join(export_dir, f"monte_carlo_results_{iter_name}.xlsx")
        results_df.to_excel(results_path, index=False)

    return results_df



def run_sensitivity(
    initial_state_mode,
    num_rows,
    num_cols,
    row_player_payoffs,
    column_player_payoffs,
    shock_payoff_row,
    shock_payoff_col,
    memory_lengths,
    epsilons,
    timeperiods,
    shock_times,
    shock_durations,
    canonical_sets=None,
    n_runs_per_setting=20,
    random_seed=None,
    export_dir=None,
    iter_name=None,
    response_rule=None
):
    """
    Unified sensitivity runner.
    Routes to the correct underlying function based on initial_mode.
    """

    if initial_state_mode in ("random", "balanced"):
        # Use your existing random/balanced function
        return run_sensitivity_with_shock(
            num_rows=num_rows,
            num_cols=num_cols,
            row_player_payoffs=row_player_payoffs,
            column_player_payoffs=column_player_payoffs,
            shock_payoff_row=shock_payoff_row,
            shock_payoff_col=shock_payoff_col,
            memory_lengths=memory_lengths,
            epsilons=epsilons,
            timeperiods=timeperiods,
            shock_times=shock_times,
            shock_durations=shock_durations,
            initial_schemes=[initial_state_mode],
            n_runs_per_setting=n_runs_per_setting,
            random_seed=random_seed,
            export_dir=export_dir,
            iter_name=iter_name,
            response_rule=response_rule
            
        )

    elif initial_state_mode == "canonical":
        # Use your existing canonical function
        return run_sensitivity_with_shock_adjusted_init_state(
            num_rows=num_rows,
            num_cols=num_cols,
            row_player_payoffs=row_player_payoffs,
            column_player_payoffs=column_player_payoffs,
            shock_payoff_row=shock_payoff_row,
            shock_payoff_col=shock_payoff_col,
            memory_lengths=memory_lengths,
            epsilons=epsilons,
            timeperiods=timeperiods,
            shock_times=shock_times,
            shock_durations=shock_durations,
            canonical_sets=canonical_sets,
            n_runs_per_setting=n_runs_per_setting,
            random_seed=random_seed,
            export_dir=export_dir,
            iter_name=iter_name,
            response_rule=response_rule
        )

    else:
        raise ValueError(
            f"Unknown initial_mode '{initial_state_mode}'. "
            "Choose from {'random', 'balanced', 'canonical'}."
        )
