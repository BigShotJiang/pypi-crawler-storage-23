from .utils import *

def exhaustive_epsilon_policy_row(history, payoff_matrix_row,
                                  num_rows,
                                  epsilon):
    """
    Row player's policy: exhaustive best responses (over own action set,
    to distinct opponent actions in history) + epsilon-greedy choice.
    """
    distinct_cols, _ = get_distinct_actions_from_history(history)
    best_rows = best_responses_row(distinct_cols, payoff_matrix_row)
    all_rows = list(range(num_rows))
    action = epsilon_greedy_choice(best_rows, all_rows, epsilon)
    return action


def exhaustive_epsilon_policy_col(history, payoff_matrix_col,
                                  num_cols,
                                  epsilon):
    """
    Column player's policy: analogous to row.
    """
    _, distinct_rows = get_distinct_actions_from_history(history)
    best_cols = best_responses_col(distinct_rows, payoff_matrix_col)
    all_cols = list(range(num_cols))
    action = epsilon_greedy_choice(best_cols, all_cols, epsilon)
    return action



def expected_payoff_policy_row(history, payoff_matrix_row, num_rows, num_cols, epsilon):
    """
    Row player's policy:
    - Build empirical distribution over opponent's column actions from `history`
    - Compute expected payoff for each row action under that distribution
    - Choose best response(s), then apply epsilon-greedy choice.
    """

    if len(history) == 0:
        # If no history, fall back to uniform random
        return random.randrange(num_rows)

    # 1. Empirical distribution over column actions
    col_counts = Counter(c for (r, c) in history)
    total = sum(col_counts.values())
    probs = {c: col_counts[c] / total for c in range(num_cols)}

    # 2. Expected payoff for each row action
    expected_payoffs = []
    for r in range(num_rows):
        exp_u = 0.0
        for c in range(num_cols):
            exp_u += payoff_matrix_row[r, c] * probs.get(c, 0.0)
        expected_payoffs.append(exp_u)

    # 3. Best response set
    max_payoff = max(expected_payoffs)
    best_rows = [r for r, u in enumerate(expected_payoffs) if u == max_payoff]

    # 4. Epsilon-greedy over best_rows vs all rows
    all_rows = list(range(num_rows))
    return epsilon_greedy_choice(best_rows, all_rows, epsilon)



def expected_payoff_policy_col(history, payoff_matrix_col, num_rows, num_cols, epsilon):
    """
    Column player's policy:
    - Empirical distribution over opponent's row actions
    - Expected payoff for each column action
    - Best response(s) + epsilon-greedy choice.
    """

    if len(history) == 0:
        return random.randrange(num_cols)

    row_counts = Counter(r for (r, c) in history)
    total = sum(row_counts.values())
    probs = {r: row_counts[r] / total for r in range(num_rows)}

    expected_payoffs = []
    for c in range(num_cols):
        exp_u = 0.0
        for r in range(num_rows):
            exp_u += payoff_matrix_col[r, c] * probs.get(r, 0.0)
        expected_payoffs.append(exp_u)

    max_payoff = max(expected_payoffs)
    best_cols = [c for c, u in enumerate(expected_payoffs) if u == max_payoff]

    all_cols = list(range(num_cols))
    return epsilon_greedy_choice(best_cols, all_cols, epsilon)


def unified_response(
    history,
    payoff_matrix,
    epsilon,
    player,
    rule,
    exhaustive_row=None,
    exhaustive_col=None,
    expected_row=None,
    expected_col=None,
    num_rows=None,
    num_cols=None
):
    """
    Wrapper that selects the correct existing response function
    based on:
        - player ("row" or "col")
        - rule ("exhaustive" or "expected")

    It does NOT rewrite logic — it simply calls the functions
    you already have.
    """

    # -------------------------
    # Exhaustive response rule
    # -------------------------
    if rule == "exhaustive":
        if player == "row":
            if exhaustive_row is None:
                raise ValueError("exhaustive_row function not provided")
            return exhaustive_row(history, payoff_matrix, num_rows, epsilon)

        elif player == "col":
            if exhaustive_col is None:
                raise ValueError("exhaustive_col function not provided")
            return exhaustive_col(history, payoff_matrix, num_cols, epsilon)

        else:
            raise ValueError("player must be 'row' or 'col'")

    # -------------------------
    # Expected-payoff rule
    # -------------------------
    elif rule == "expected":
        if player == "row":
            if expected_row is None:
                raise ValueError("expected_row function not provided")
            return expected_row(history, payoff_matrix, num_rows, num_cols, epsilon)

        elif player == "col":
            if expected_col is None:
                raise ValueError("expected_col function not provided")
            return expected_col(history, payoff_matrix, num_rows, num_cols, epsilon)

        else:
            raise ValueError("player must be 'row' or 'col'")

    else:
        raise ValueError("Unknown rule type: must be 'exhaustive' or 'expected'")

