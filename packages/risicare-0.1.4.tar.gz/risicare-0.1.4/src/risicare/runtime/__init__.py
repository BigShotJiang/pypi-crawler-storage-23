"""
Fix Runtime - SDK-embedded fix application engine.

The runtime loads active fixes from the API and applies them
transparently during agent execution.

Components:
- FixLoader: Fetches and caches active fixes
- FixApplier: Applies fixes based on error patterns
- FixCache: Local cache with TTL
- Interceptors: Hook into LLM/tool calls to apply fixes
"""

from risicare.runtime.applier import FixApplier
from risicare.runtime.cache import FixCache
from risicare.runtime.config import FixRuntimeConfig
from risicare.runtime.interceptors import FixInterceptor
from risicare.runtime.loader import FixLoader
from risicare.runtime.runtime import FixRuntime

__all__ = [
    "FixRuntime",
    "FixLoader",
    "FixApplier",
    "FixCache",
    "FixRuntimeConfig",
    "FixInterceptor",
]
