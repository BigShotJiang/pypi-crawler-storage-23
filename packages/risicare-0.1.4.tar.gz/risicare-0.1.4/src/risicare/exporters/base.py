"""
Base classes for span exporters.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from enum import Enum
from typing import List, TYPE_CHECKING

if TYPE_CHECKING:
    from risicare_core import Span


class ExportResult(Enum):
    """Result of an export operation."""
    SUCCESS = "success"
    FAILURE = "failure"
    TIMEOUT = "timeout"


class SpanExporter(ABC):
    """
    Abstract base class for span exporters.

    Implement this class to create custom exporters that send spans
    to different backends (HTTP, file, queue, etc.).
    """

    @abstractmethod
    def export(self, spans: List["Span"]) -> ExportResult:
        """
        Export a batch of spans.

        Args:
            spans: List of spans to export.

        Returns:
            ExportResult indicating success or failure.
        """
        pass

    def shutdown(self) -> None:
        """
        Shutdown the exporter.

        Called when the SDK is shutting down. Override to clean up
        resources like HTTP connections.
        """
        pass

    @property
    def name(self) -> str:
        """Return the exporter name for logging."""
        return self.__class__.__name__
