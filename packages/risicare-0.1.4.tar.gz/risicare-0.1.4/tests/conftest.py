"""Pytest configuration for risicare-sdk tests."""

import pytest
import sys
from pathlib import Path

# Add source paths for imports
sdk_src = Path(__file__).parent.parent / "src"
core_src = Path(__file__).parent.parent.parent / "risicare-core" / "src"

for src_path in [sdk_src, core_src]:
    if str(src_path) not in sys.path:
        sys.path.insert(0, str(src_path))


def pytest_configure(config):
    """Configure pytest."""
    config.addinivalue_line(
        "markers", "asyncio: mark test as async"
    )
