# Risicare

Self-healing observability for AI agents. Captures decision-level traces, diagnoses failures, and deploys fixes — automatically.

[![PyPI version](https://img.shields.io/pypi/v/risicare.svg)](https://pypi.org/project/risicare/)
[![Python](https://img.shields.io/pypi/pyversions/risicare.svg)](https://pypi.org/project/risicare/)

## Quick Start

```bash
pip install risicare
```

```python
import risicare

risicare.init(
    api_key="rsk-...",
    endpoint="https://app.risicare.ai"
)

# That's it. LLM calls are now traced automatically.
```

## Progressive Integration

| Tier | Effort | What You Get |
|------|--------|-------------|
| **Tier 0** | `RISICARE_TRACING=true` (env var) | Auto-instrument all LLM calls |
| **Tier 1** | `import risicare` (1 line) | Explicit config, custom endpoint |
| **Tier 2** | `@agent()` decorator | Agent identity and hierarchy |
| **Tier 3** | `@session` decorator | User session tracking |
| **Tier 4** | `@trace_think / @trace_decide / @trace_act` | Decision phase visibility |
| **Tier 5** | `@trace_message / @trace_delegate` | Multi-agent communication |

## Supported Providers (20)

Auto-instrumented with zero code changes:

| Provider | | Provider | |
|----------|---|----------|---|
| OpenAI | `openai` | Anthropic | `anthropic` |
| Google Gemini | `google-generativeai` | Mistral | `mistralai` |
| Cohere | `cohere` | Groq | `groq` |
| Together AI | `together` | Ollama | `ollama` |
| AWS Bedrock | `boto3` | Google Vertex AI | `google-cloud-aiplatform` |
| Cerebras | `cerebras-cloud-sdk` | HuggingFace | `huggingface-hub` |
| DeepSeek | via OpenAI `base_url` | xAI (Grok) | via OpenAI `base_url` |
| Fireworks | via OpenAI `base_url` | Baseten | via OpenAI `base_url` |
| Novita | via OpenAI `base_url` | BytePlus | via OpenAI `base_url` |
| vLLM | via OpenAI `base_url` | Any OpenAI-compatible | via `base_url` |

## Supported Frameworks (10)

```bash
pip install risicare[langchain]    # LangChain + LangGraph
pip install risicare[crewai]       # CrewAI
pip install risicare[autogen]      # AutoGen
pip install risicare[instructor]   # Instructor
pip install risicare[litellm]      # LiteLLM
pip install risicare[dspy]         # DSPy
pip install risicare[pydantic-ai]  # Pydantic AI
pip install risicare[llamaindex]   # LlamaIndex
pip install risicare[all]          # Everything
```

## OpenTelemetry

```bash
pip install risicare[otel]
```

```python
risicare.init(api_key="rsk-...", otel_bridge=True)
```

Compatible with any OTel-instrumented application. Export to Risicare alongside your existing OTel pipeline.

## Links

- [Documentation](https://risicare.ai/docs)
- [Dashboard](https://app.risicare.ai)
