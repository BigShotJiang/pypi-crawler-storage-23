# =============================================================================
# C O P Y R I G H T
# -----------------------------------------------------------------------------
# Copyright (c) 2019-2023 by Helmut Konrad Schewe. All rights reserved.
# This file is property of Helmut Konrad Schewe. Any unauthorized copy,
# use or distribution is an offensive act against international law and may
# be prosecuted under federal law. Its content is company confidential.
# =============================================================================

import baw
from baw.resources import CODE_WORKSPACE
from baw.resources import RCFILE_PATH
from baw.resources import template_replace


def test_template_replace():
    """Test replace pattern from variable key word argument"""
    assert '{{RCFILE}}' in CODE_WORKSPACE
    assert RCFILE_PATH not in CODE_WORKSPACE

    replaced = template_replace(baw.ROOT, CODE_WORKSPACE, rcfile=RCFILE_PATH)

    assert '{{RCFILE}}' not in replaced
    assert RCFILE_PATH in replaced
