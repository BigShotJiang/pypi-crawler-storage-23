from hpc_mcp.utils import format_rules

# TODO:
- make option for agent to persist between attempts / steps (so we retry with memory)
- make the hpc optiizations agent, with parameter for "this is what ou did last time"
- make the deploy agent to kubernetes, also with "this is what you didlast time"
- need to figure out how deploy works with optimization...


def get_build_text(application, environment, build_rules):
    """
    Get prompt text for an initial build.
    """
    return f"""
### PERSONA
You are an HPC application deployment expert.

### CONTEXT
We are running experiments to run HPC applications.
You are the agent responsible for executing the application run.

### GOAL
I need to create a job submission command using the workload manager '{manager}'.
The target environment is '{environment}'.
You MUST generate a response with ONLY Dockerfile content.
You MUST NOT include other text or thinking with your response.
You do NOT need to write the Dockerfile to disk, but rather provide to the build tool to handle.
You MUST return a JSON response with a "dockerfile" field.
The dockerfile field MUST be a list of commands, where each entry is a single line.

### REQUIREMENTS & CONSTRAINTS
You must adhere to these rules strictly:
Assume a default of CPU if GPU or CPU is not stated."
If the application involves MPI, configure it for compatibility with the system.

### INSTRUCTIONS
1. Analyze the requirements and generate the Dockerfile content.
2. You MUST generate a json structure with a "dockerfile"
"""


def get_retry_prompt(fix_rules, error_message):
    return f"""
### PERSONA
{PERSONA}

### CONTEXT
{CONTEXT}

### STATUS: BUILD FAILED
Your previous Dockerfile build has failed. Here is the instruction for how to fix it:

```text
{error_message}
```

### REQUIREMENTS

Please analyze the error and your previous work, and provide a corrected version.
{format_rules(fix_rules)}

### INSTRUCTIONS
1. Read the error log above carefully.
2. Modify the Dockerfile using your file tools.
3. Use a provided tool to retry the build.
"""
