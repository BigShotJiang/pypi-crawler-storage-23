from setuptools import setup, find_packages

setup(
    name="sumit403",
    version="0.3",
    packages=find_packages(),
    description="Deep Learning Experiments Library for Jupyter and Google Colab",
    author="Sumit",
)
