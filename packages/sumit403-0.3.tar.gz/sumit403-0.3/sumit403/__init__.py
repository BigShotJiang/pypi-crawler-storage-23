def hello():
    return "Hello from sumit403!"
from IPython.core.getipython import get_ipython

class Experiment:
    def __init__(self, name, code):
        self.name = name
        self.code = code

    def __repr__(self):
        return self.code

    def __call__(self):
        """Injects the code into a new cell safely in Colab and Jupyter."""
        ipython = get_ipython()
        if ipython is not None:
            ipython.set_next_input(self.code, replace=False)
        else:
            print("Not running in a Jupyter/Colab environment.")

p1 = Experiment("p1", r"""# EXPERIMENT 01: Implementation of Feed Forward Neural Network
import tensorflow as tf
from tensorflow import keras  
import matplotlib.pyplot as plt
import random
(x_train, y_train), (x_test, y_test) = tf.keras.datasets.mnist.load_data()
x_train = x_train / 255.0
x_test = x_test / 255.0
model = keras.Sequential([
    keras.layers.Flatten(input_shape=(28, 28)), 
    keras.layers.Dense(128, activation="relu"),  
    keras.layers.Dense(10, activation="softmax")  
])
model.compile(optimizer="sgd", loss="sparse_categorical_crossentropy", metrics=["accuracy"])
history = model.fit(x_train, y_train, validation_data=(x_test, y_test), epochs=5)

#evaluate the network
test_loss,test_acc=model.evaluate(x_test,y_test)
print("Loss=%.3f"%test_loss)
print("Accuracy=%.3f"%test_acc)
n=random.randint(0,9999)
plt.imshow(x_test[n])
plt.show()
predicted_value=model.predict(x_test)
plt.imshow(x_test[n])
plt.show()
print("Predicted Value:", predicted_value[n])

#plotting the training accuracy
plt.plot(history.history["accuracy"])
plt.plot(history.history["val_accuracy"])
plt.title("model accuracy")
plt.ylabel("accuracy")
plt.xlabel("epoch")
plt.legend(["Train","Validation"],loc="upper left")
plt.show()

#plotting the training loss
plt.plot(history.history["loss"])
plt.plot(history.history["val_loss"])
plt.title("model loss")
plt.ylabel("loss")
plt.xlabel("epoch")
plt.legend(["Train","Validation"],loc="upper right")
plt.show()""")

p2 = Experiment("p2", r"""# EXPERIMENT 02: XOR gate using perceptron
import numpy as np
import matplotlib.pyplot as plt
x=np.array([[0,1],[1,0],[1,1],[0,0]])
y=np.array([[1],[1],[0],[0]])
num_input=2
num_hidden=1
num_output=1
wxh=np.random.randn(num_input,num_hidden)
bh=np.zeros((1,num_hidden))
why=np.random.randn(num_hidden,num_output)
def sigmoid(z):
    return 1/(1+np.exp(-z))
def sigmoid_derivative(z):
    return sigmoid(z)*(1-sigmoid(z))
def forward_prop(x,wxh,why):
    z1 = np.dot(x,wxh)+bh
    a1 = sigmoid(z1)
    z2 = np.dot(a1,why)
    return z1,a1,z2
def cost_function(y,y_hat):
    return 0.5*np.sum((y-y_hat)**2)
def backward_prop(x,y,z1,a1,z2,why):
    m=y.shape[0]
    dl_dz2=z2-y
    dl_da1=np.dot(dl_dz2,why.T)
    dl_dz1=dl_da1 * sigmoid_derivative(z1)
    dj_dwhy=np.dot(a1.T,dl_dz2)/m
    dj_dwxh=np.dot(x.T,dl_dz1)/m
    dj_dbh=np.sum(dl_dz1,axis=0,keepdims=True)/m
    return dj_dwxh,dj_dwhy,dj_dbh
n=0.01
num_iterations = 5000
costs=[]
for i in range(num_iterations):
    z1,a1,z2=forward_prop(x,wxh,why)
    y_hat=z2
    cost=cost_function(y,y_hat)
    costs.append(cost)
    dj_dwxh,dj_dwhy,dj_dbh=backward_prop(x,y,z1,a1,z2,why)
    wxh -=n*dj_dwxh
    why -=n*dj_dwhy
    bh -=n*dj_dbh
plt.grid()
plt.plot(range(num_iterations),costs)
plt.title('cost funtion')
plt.xlabel('Training Iterations')
plt.ylabel('cost')
plt.show()
z1,hidden_layer_activation,output=forward_prop(x,wxh,why)
print("output of the network:\n",output)""")

p3 = Experiment("p3", r"""# EXPERIMENT 03: Image classification model stages
import tensorflow as tf
from tensorflow import keras
import matplotlib.pyplot as plt
import random

mnist = tf.keras.datasets.mnist
(x_train, y_train), (x_test, y_test) = mnist.load_data()
x_train = x_train / 255.0
x_test = x_test / 255.0
model = keras.Sequential([
    keras.layers.Flatten(input_shape=(28, 28)),  
    keras.layers.Dense(128, activation="relu"),  
    keras.layers.Dense(10, activation="softmax")  
])
model.summary()
model.compile(optimizer="sgd", 
              loss="sparse_categorical_crossentropy", 
              metrics=['accuracy'])
history = model.fit(x_train, y_train, validation_data=(x_test, y_test), epochs=3)


# Evaluate the model on the test data
test_loss, test_accuracy = model.evaluate(x_test, y_test, verbose=2)
print(f"Test Accuracy: {test_accuracy * 100:.2f}%")
print(f"Test Loss: {test_loss:.4f}")
# Plotting the training and validation accuracy
plt.figure(figsize=(12, 6))
plt.subplot(1, 2, 1)
plt.plot(history.history['accuracy'], label='Training Accuracy')
plt.plot(history.history['val_accuracy'], label='Validation Accuracy')
plt.title('Training and Validation Accuracy')
plt.xlabel('Epochs')
plt.ylabel('Accuracy')
plt.legend()

# Plotting the training and validation loss
plt.subplot(1, 2, 2)
plt.plot(history.history['loss'], label='Training Loss')
plt.plot(history.history['val_loss'], label='Validation Loss')
plt.title('Training and Validation Loss')
plt.xlabel('Epochs')
plt.ylabel('Loss')
plt.legend()
plt.show()

# Making predictions on random test images
num_images = 5
random_indices = random.sample(range(x_test.shape[0]), num_images)
for idx in random_indices:
    plt.imshow(x_test[idx], cmap=plt.cm.binary)
    plt.title(f"Predicted Label: {model.predict(x_test[idx:idx+1]).argmax()}\nTrue Label: {y_test[idx]}")
    plt.axis('off')
    plt.show()""")

p4 = Experiment("p4", r"""# EXPERIMENT 04: Simple CNN
import torch  
import torch.nn.functional as F  
import matplotlib.pyplot as plt    
# Define the input image tensor  
image = torch.tensor([  
    [0., 0., 0., 0., 0.],  
    [0., 1., 1., 1., 0.],  
    [0., 1., 1., 1., 0.],  
    [0., 1., 1., 1., 0.],  
    [0., 0., 0., 0., 0.]  
])  
# Reshape the image to match (N, C, H, W)  
image = image.unsqueeze(0).unsqueeze(0)  # shape: (1, 1, 5, 5)  
  
# Define the kernel (e.g., Laplacian filter)  
kernel = torch.tensor([  
    [[  
        [0.,  1., 0.],  
        [1., -4., 1.],  
        [0.,  1., 0.]  
    ]]  
])    
# Apply convolution  
conv = F.conv2d(image, kernel, stride=1, padding=0)  
# Apply max pooling  
pooled = F.max_pool2d(conv, kernel_size=2, stride=2)  
# Plotting  
fig, ax = plt.subplots(1, 3, figsize=(15, 5))    
# Original Image  
ax[0].imshow(image.squeeze().numpy(), cmap='gray')  
ax[0].set_title('Input Image')  
ax[0].axis('off')  
# After Convolution  
ax[1].imshow(conv.squeeze().detach().numpy(), cmap='gray')  
ax[1].set_title('After Convolution')  
ax[1].axis('off')  
# After Max Pooling  
pooled_image = pooled.squeeze(0).squeeze(0)  
ax[2].imshow(pooled_image.detach().numpy(), cmap='gray')  
ax[2].set_title('After Max Pooling')  
ax[2].axis('off')  
plt.show()""")

p5 = Experiment("p5", r"""# EXPERIMENT 05: Sentiment Analysis using RNN
import tensorflow as tf
from tensorflow.keras.datasets import imdb
from tensorflow.keras.preprocessing.sequence import pad_sequences
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Embedding, LSTM, Dense

vocab_size = 5000
maxlen     = 500
batch_size = 64
epochs     = 3
(x_train, y_train), (x_test, y_test) = imdb.load_data(num_words=vocab_size)
x_train = pad_sequences(x_train, maxlen=maxlen)
x_test  = pad_sequences(x_test,  maxlen=maxlen)

model = Sequential([ Embedding(vocab_size, 32, input_length=maxlen), LSTM(100), Dense(1, activation='sigmoid') ])
model.compile( loss='binary_crossentropy', optimizer='adam', metrics=['accuracy'] )
print(model.summary())
model.fit( x_train, y_train, validation_split=0.1, batch_size=batch_size, epochs=epochs)
loss,acc=model.evaluate(x_test,y_test)
print(f"loss: {loss}\naccuracy: {acc}")""")

p6 = Experiment("p6", r"""# EXPERIMENT 06: LSTM based Auto encoding in Tensorflow/Keras
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler
from tensorflow import keras
df = pd.read_csv('spx.csv', parse_dates=['date'], index_col='date')
print("Original columns:", df.columns.tolist())

#Normalize column names
df.columns = [col.strip().lower() for col in df.columns]
print("Normalized columns:", df.columns.tolist())

#Ensure 'close' is numeric, drop any bad rows
df['close'] = pd.to_numeric(df['close'], errors='coerce')
n_bad = df['close'].isna().sum()
if n_bad > 0:
    print(f"Dropping {n_bad} rows where 'close' was not numeric")
    df = df.dropna(subset=['close'])

#Train/Test split
TRAIN_RATIO = 0.9
train_size = int(len(df) * TRAIN_RATIO)
train_df = df.iloc[:train_size].copy()
test_df  = df.iloc[train_size:].copy()

#Scale the 'close' prices
scaler = StandardScaler()
train_df['close'] = scaler.fit_transform(train_df[['close']])
test_df['close']  = scaler.transform(test_df[['close']])

#Create sliding-window datasets
def create_dataset(series: pd.Series, time_steps: int = 30):
       X, y = [], []
       for i in range(len(series) - time_steps):
           window = series.iloc[i : i + time_steps].values.reshape(-1, 1)
           X.append(window)
           y.append(series.iloc[i + time_steps])
       return np.array(X), np.array(y)
TIME_STEPS = 30
X_train, y_train = create_dataset(train_df['close'], TIME_STEPS)
X_test,  y_test  = create_dataset(test_df['close'],  TIME_STEPS)
print("X_train shape:", X_train.shape)  # e.g. (n_samples, 30, 1)
print("y_train shape:", y_train.shape)

#Build LSTM autoencoder
model = keras.Sequential([ keras.layers.LSTM(64, input_shape=(TIME_STEPS, 1)), keras.layers.RepeatVector(TIME_STEPS), keras.layers.LSTM(64, return_sequences=True), keras.layers.Dropout(0.2), keras.layers.TimeDistributed(keras.layers.Dense(1)) ])
model.compile(optimizer='adam', loss='mse')
model.summary()

#Train (using X_train as both input and target for autoencoder)
history = model.fit( X_train, X_train, epochs=20, batch_size=32, validation_split=0.1, shuffle=False )

#Plot losses
plt.figure(figsize=(8,4))
plt.plot(history.history['loss'],  label='train loss')
plt.plot(history.history['val_loss'],label='validation loss')
plt.title('LSTM Autoencoder Loss')
plt.xlabel('Epoch')
plt.ylabel('MSE')
plt.legend()
plt.show()
X_test_pred = model.predict(X_test, verbose=0)
test_mse = np.mean((X_test_pred - X_test)**2, axis=(1,2))
print("Average test MSE:", test_mse.mean())""")

p7 = Experiment("p7", r"""# EXPERIMENT 07: Image generation using GAN
import os, numpy as np
from keras.datasets import mnist
from keras.models import Model
from keras.layers import Input, Dense, Reshape, Flatten, LeakyReLU, BatchNormalization, Dropout
from keras.optimizers import Adam
import matplotlib.pyplot as plt

# Hyperparameters
z_dim, img_shape = 100, (28,28,1)
batch_size, steps = 64, 15000
os.makedirs('imgs', exist_ok=True)

# Reduced learning rates for more stable training
opt_g = Adam(1e-4, 0.5)  # Generator optimizer
opt_d = Adam(2e-4, 0.5)  # Discriminator optimizer

# Generator - Improved architecture
z = Input((z_dim,))
x = Dense(256)(z)
x = LeakyReLU(0.2)(x)
x = BatchNormalization(momentum=0.8)(x)
x = Dense(512)(x)
x = LeakyReLU(0.2)(x)
x = BatchNormalization(momentum=0.8)(x)
x = Dense(1024)(x)
x = LeakyReLU(0.2)(x)
x = BatchNormalization(momentum=0.8)(x)
x = Dense(np.prod(img_shape), activation='tanh')(x)
G = Model(z, Reshape(img_shape)(x))

# Discriminator - Improved architecture with dropout
img = Input(img_shape)
y = Flatten()(img)
y = Dense(1024)(y)
y = LeakyReLU(0.2)(y)
y = Dropout(0.3)(y)
y = Dense(512)(y)
y = LeakyReLU(0.2)(y)
y = Dropout(0.3)(y)
y = Dense(256)(y)
y = LeakyReLU(0.2)(y)
y = Dropout(0.3)(y)
y = Dense(1, activation='sigmoid')(y)
D = Model(img, y)
D.compile(optimizer=opt_d, loss='binary_crossentropy', metrics=['accuracy'])
# Create combined model
for layer in D.layers:
    layer.trainable = False
   
z2 = Input((z_dim,))
C = Model(z2, D(G(z2)))
C.compile(optimizer=opt_g, loss='binary_crossentropy')

# Re-enable discriminator training
for layer in D.layers:
    layer.trainable = True

# Load & preprocess MNIST
(X,_), _ = mnist.load_data()
X = (X.astype('float32') - 127.5) / 127.5
X = np.expand_dims(X, -1)
# Label smoothing for more stable training
real_labels = np.ones((batch_size, 1)) * 0.9  # Real labels = 0.9 instead of 1.0
fake_labels = np.zeros((batch_size, 1))

# Training with improved strategy
d_losses, g_losses, d_accuracies = [], [], []
for step in range(1, steps + 1):
    # Train Discriminator
    # Sample real images
     
    idx = np.random.randint(0, X.shape[0], batch_size)
    real_imgs = X[idx]    
    # Generate fake images
    noise = np.random.normal(0, 1, (batch_size, z_dim))
    fake_imgs = G.predict(noise, verbose=0)
    
    # Train discriminator on real and fake images
    d_loss_real, d_acc_real = D.train_on_batch(real_imgs, real_labels)
    d_loss_fake, d_acc_fake = D.train_on_batch(fake_imgs, fake_labels)
    
    # Train Generator (via combined model)
    # We want the generator to fool the discriminator, so we use real_labels
  
    noise = np.random.normal(0, 1, (batch_size, z_dim))
    
    # Freeze discriminator for generator training
    for layer in D.layers:
        layer.trainable = False
    g_loss = C.train_on_batch(noise, real_labels)
    
    # Unfreeze discriminator for next iteration
    for layer in D.layers:
        layer.trainable = True
    
    # Store metrics
    d_loss = 0.5 * (d_loss_real + d_loss_fake)
    d_acc = 0.5 * (d_acc_real + d_acc_fake)
    
    d_losses.append(d_loss)
    g_losses.append(g_loss)
    d_accuracies.append(d_acc)
    
    # Print progress and save samples
    if step % 1000 == 0:
        print(f"Step {step:5d}: D_loss: {d_loss:.4f}, D_acc: {d_acc*100:.2f}%, G_loss: {g_loss:.4f}")
        
        # Generate and save sample images
        n = 25
        noise = np.random.normal(0, 1, (n, z_dim))
        gen_imgs = G.predict(noise, verbose=0)
        
        # Rescale images to [0, 1]
        gen_imgs = 0.5 * gen_imgs + 0.5
        
        fig, axs = plt.subplots(5, 5, figsize=(5, 5))
        cnt = 0
        for i in range(5):
            for j in range(5):
                axs[i, j].imshow(gen_imgs[cnt, :, :, 0], cmap='gray')
                axs[i, j].axis('off')
                cnt += 1
        
        plt.tight_layout()
        fig.savefig(f"imgs/step_{step}.png", dpi=100, bbox_inches='tight')
        plt.close()

# Plot training metrics
plt.figure(figsize=(12, 4))

plt.subplot(1, 3, 1)
plt.plot(d_losses)
plt.title('Discriminator Loss')
plt.xlabel('Steps')
plt.ylabel('Loss')

plt.subplot(1, 3, 2)
plt.plot(g_losses)
plt.title('Generator Loss')
plt.xlabel('Steps')
plt.ylabel('Loss')

plt.subplot(1, 3, 3)
plt.plot([x*100 for x in d_accuracies])
plt.title('Discriminator Accuracy')
plt.xlabel('Steps')
plt.ylabel('Accuracy (%)')

plt.tight_layout()
plt.savefig('training_metrics.png', dpi=100, bbox_inches='tight')
plt.show()

print("Training completed!")
print(f"Final D_acc: {d_accuracies[-1]*100:.2f}%")
print(f"Final G_loss: {g_losses[-1]:.4f}")
print(f"Final D_loss: {d_losses[-1]:.4f}")""")
