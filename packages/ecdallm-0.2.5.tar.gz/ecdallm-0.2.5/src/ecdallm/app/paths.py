from __future__ import annotations
from pathlib import Path

APP_DIR = Path(__file__).resolve().parent

UPLOAD_DIR = APP_DIR / "uploads"
RAG_STORE_DIR = APP_DIR / "rag_store"
JSON_STORE_DIR = APP_DIR / "json_store"   # ← fixed name
TEMPLATES_DIR = APP_DIR / "templates"
STATIC_DIR = APP_DIR / "static"


def ensure_dirs() -> None:
    UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
    RAG_STORE_DIR.mkdir(parents=True, exist_ok=True)
    JSON_STORE_DIR.mkdir(parents=True, exist_ok=True)

    (RAG_STORE_DIR / "chroma_db").mkdir(parents=True, exist_ok=True)
