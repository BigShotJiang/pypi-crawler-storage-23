"""Minimal event logger for hybrid mode observability (ISSUE-SAAS-042).

This module provides a standalone event logger that works in both:
- Development environment (running from source)
- Installed package (pip install obra)

The logger writes JSONL events to the resolved runtime log path.

Why this exists:
- ProductionLogger (src/monitoring/production_logger.py) is not packaged
- Sessions run from installed package had no event logging (silent failure)
- This minimal implementation provides observability for all obra users

Design principles:
- No dependencies on src/ modules (must work in installed package)
- Thread-safe for concurrent event logging
- Simple JSONL format compatible with ProductionLogger events
- Immediate flush for real-time monitoring
- ISSUE-OBS-003: Log rotation at 10MB with 5 backup files

Event Schemas (Derivation Pipeline - FEAT-UNIFIED-DERIVE-001):
- derivation_pipeline_started:
    session_id: str - Session identifier
    objective_length: int - Length of the objective string

- derivation_pipeline_completed:
    session_id: str - Session identifier
    total_duration_ms: int - Total pipeline duration in milliseconds
    total_tokens: int - Total tokens used across all steps
    item_count: int - Number of plan items produced

- derivation_pipeline_failed:
    session_id: str - Session identifier
    failed_at_step: int - Step number where failure occurred (1-3)
    step_name: str - Step name (structure/tasks/serialize)
    error_type: str - Error class name
    error_message: str - Error description

- derivation_step_completed:
    session_id: str - Session identifier
    step: int - Step number (1-3)
    step_name: str - Step name (structure/tasks/serialize)
    duration_ms: int - Step duration in milliseconds
    input_tokens: int - Input tokens for this step
    output_tokens: int - Output tokens for this step
    items_produced: int - Number of items produced in this step

- derivation_stall_warning:
    session_id: str - Session identifier
    step: int - Step number (1-3)
    step_name: str - Step name (structure/tasks/serialize)
    no_output_seconds: int - Seconds with no output from LLM
"""

import json
import logging
from datetime import UTC, datetime
from pathlib import Path
from threading import Lock
from typing import Any

from obra.constants import EVENT_LOG_MAX_BACKUP_COUNT, EVENT_LOG_MAX_SIZE_BYTES
from obra.utils.obra_home import get_runtime_dir

# Log rotation settings
MAX_LOG_SIZE_BYTES = EVENT_LOG_MAX_SIZE_BYTES  # 10MB
MAX_BACKUP_COUNT = EVENT_LOG_MAX_BACKUP_COUNT  # Keep 5 rotated files

logger = logging.getLogger(__name__)


class HybridEventLogger:
    """Minimal JSONL event logger for hybrid mode.

    Thread-safe event logger that writes structured events to a JSONL file.
    Compatible with ProductionLogger event format for tooling compatibility.

    FIX-HYBRID-053: Optionally forwards key lifecycle events to the
    production logger to close the production observability gap.

    Example:
        >>> logger = HybridEventLogger()
        >>> logger.log_event("session_started", session_id="abc-123", objective="test")
    """

    # FIX-HYBRID-053: Event types forwarded to production.jsonl
    PRODUCTION_FORWARD_EVENTS: set[str] = {
        "review_completed",
        "review_loop_completed",
        "fix_completed",
        "fix_scope_warning",
        "fix_scope_exceeded",
        "escalation_decision",
        "session_completed",
        "pipeline_completed",
        # Execution lifecycle (closes production telemetry gap for
        # execute/review phases — previously only derive/examine/revise
        # had production coverage).
        "item_started",
        "item_completed",
        # Session lifecycle
        "session_interrupted",
        # Parallel refinement telemetry (session 76b9473a gap analysis:
        # these events were only in hybrid.jsonl, invisible in production).
        "refinement_parallel_examine",
        "refinement_parallel_revise",
        # Fix lifecycle (fix_started + fix_issue_result were missing from
        # production, preventing escalation root-cause diagnosis).
        "fix_started",
        "fix_issue_result",
    }

    # ISSUE-HYBRID-059: Events explicitly suppressed from production forwarding.
    # Every event type MUST appear in either PRODUCTION_FORWARD_EVENTS or
    # PRODUCTION_SUPPRESSED_EVENTS. Adding a new event type without declaring
    # its forwarding policy will fail test_telemetry_parity.
    PRODUCTION_SUPPRESSED_EVENTS: set[str] = {
        # High-frequency internal events (hybrid-only observability)
        "client_request_started",
        "client_request_completed",
        "refinement_batch_completed",
        "progress_stage_heartbeat",
        "resource_snapshot",
        # LLM pipeline internals (too granular for production)
        "llm_call",
        "template_created",
        "template_read",
        "parse_attempt",
        "parse_success",
        "parse_error",
        "template_unchanged_detected",
        "template_unchanged_rejected",
        "template_unchanged_short_circuit",
        # Session lifecycle detail (hybrid-only)
        "session_started",
        "session_failed",
        "session_resumed",
        "session_runtime_warning",
        "stall_detected",
        "cli_cache_warning",
        # Phase/subphase lifecycle (hybrid-only)
        "phase_started",
        "phase_completed",
        "phase_failed",
        "subphase_started",
        "subphase_completed",
        # Pipeline lifecycle (hybrid-only)
        "pipeline_started",
        "pipeline_failed",
        # Derivation detail (production gets direct ProductionLogger calls)
        "derivation_started",
        "derivation_complete",
        "derived_plan_snapshot",
        "userplan_snapshot",
        # Escalation prompt detail
        "escalation_prompt_waiting",
        # Skip tracking
        "item_skipped",
        # Revision merge detail
        "revision_merge_rejected",
        "report_revision",
        # Handler lifecycle (examine/revise start/complete/fail)
        "examine_start",
        "examine_complete",
        "examine_failed",
        "revise_start",
        "revise_complete",
        "revise_failed",
        # Refinement guard
        "refinement_guard_triggered",
        # Plan derivation detail
        "derived_plan_item_keys_dropped",
        # Server-side validation diagnostics
        "c9_non_fixable_findings",
    }

    def __init__(
        self,
        log_path: Path | None = None,
        production_logger: Any | None = None,
    ):
        """Initialize HybridEventLogger.

        Args:
            log_path: Path to log file. Defaults to the runtime hybrid.jsonl log.
            production_logger: Optional ProductionLogger instance for forwarding
                key lifecycle events (FIX-HYBRID-053).
        """
        self._lock = Lock()
        self._log_path = log_path or self._get_default_log_path()
        self._production_logger = production_logger
        self._trace_id: str | None = None
        self._span_id: str | None = None
        self._parent_span_id: str | None = None
        self._component: str | None = "hybrid_client"
        self._work_unit_id: str | None = None
        self._project_id: str | None = None
        self._project_name: str | None = None

        # Ensure log directory exists
        self._log_path.parent.mkdir(parents=True, exist_ok=True)

        logger.debug(f"HybridEventLogger initialized: {self._log_path}")

    def set_trace_context(
        self,
        trace_id: str,
        span_id: str | None = None,
        parent_span_id: str | None = None,
    ) -> None:
        """Set trace context for subsequent log events."""
        self._trace_id = trace_id
        if span_id:
            self._span_id = span_id
        if parent_span_id:
            self._parent_span_id = parent_span_id

    def set_component(self, component: str) -> None:
        """Set component label for subsequent log events."""
        self._component = component

    def set_work_unit(self, work_unit_id: str | None) -> None:
        """Set work unit ID for subsequent log events."""
        self._work_unit_id = work_unit_id

    def set_project(self, project_id: str | None, project_name: str | None = None) -> None:
        """Set project context for subsequent log events.

        Args:
            project_id: Project ID (UUID or short form)
            project_name: Human-readable project name (optional)
        """
        self._project_id = project_id
        self._project_name = project_name

    @staticmethod
    def _get_default_log_path() -> Path:
        """Get the default log file path.

        Returns:
            Path to the resolved runtime hybrid.jsonl log
        """
        runtime_dir = get_runtime_dir()
        return runtime_dir / "logs" / "hybrid.jsonl"

    def _rotate_if_needed(self) -> None:
        """Rotate log file if it exceeds MAX_LOG_SIZE_BYTES.

        ISSUE-OBS-003: Implements simple log rotation to prevent unbounded growth.
        Rotates to .1, .2, etc. and keeps MAX_BACKUP_COUNT backups.
        """
        try:
            if not self._log_path.exists():
                return

            current_size = self._log_path.stat().st_size
            if current_size < MAX_LOG_SIZE_BYTES:
                return

            # Rotate existing backups (.5 -> deleted, .4 -> .5, etc.)
            for i in range(MAX_BACKUP_COUNT, 0, -1):
                old_path = self._log_path.with_suffix(f".jsonl.{i}")
                if i == MAX_BACKUP_COUNT:
                    # Delete oldest backup
                    if old_path.exists():
                        old_path.unlink()
                else:
                    # Rename to next number
                    new_path = self._log_path.with_suffix(f".jsonl.{i + 1}")
                    if old_path.exists():
                        old_path.rename(new_path)

            # Rotate current file to .1
            backup_path = self._log_path.with_suffix(".jsonl.1")
            self._log_path.rename(backup_path)

            logger.info(f"Rotated log file: {self._log_path} -> {backup_path}")

        except Exception as e:
            # Never fail logging due to rotation errors
            logger.warning(f"Log rotation failed: {e}")

    def log_event(self, event_type: str, session_id: str = "", **kwargs: Any) -> None:
        """Log a structured event to the JSONL file.

        Args:
            event_type: Type of event (session_started, phase_started, etc.)
            session_id: Session ID for event correlation
            **kwargs: Event-specific data

        Example:
            >>> logger.log_event(
            ...     "derivation_started",
            ...     session_id="abc-123",
            ...     objective="Build calculator app"
            ... )
        """
        with self._lock:
            try:
                # ISSUE-OBS-003: Check for log rotation before writing
                self._rotate_if_needed()

                now_iso = datetime.now(UTC).isoformat()
                local_iso = datetime.now().astimezone().isoformat()
                event = {
                    "type": event_type,
                    "ts": now_iso,
                    "timestamp": now_iso,
                    "timestamp_local": local_iso,
                    "session": session_id,
                    **kwargs,
                }

                if "trace_id" not in event and self._trace_id:
                    event["trace_id"] = self._trace_id
                if "span_id" not in event and self._span_id:
                    event["span_id"] = self._span_id
                if "parent_span_id" not in event and self._parent_span_id:
                    event["parent_span_id"] = self._parent_span_id
                if "component" not in event and self._component:
                    event["component"] = self._component
                if "work_unit_id" not in event and self._work_unit_id:
                    event["work_unit_id"] = self._work_unit_id
                if "project_id" not in event and self._project_id:
                    event["project_id"] = self._project_id
                if "project_name" not in event and self._project_name:
                    event["project_name"] = self._project_name

                # Append JSONL line to file
                with self._log_path.open("a", encoding="utf-8") as f:
                    f.write(json.dumps(event, default=str) + "\n")
                    f.flush()  # Immediate flush for real-time monitoring

            except Exception as e:
                # Never fail the main operation due to logging
                logger.warning(f"Failed to log event '{event_type}': {e}")

        # FIX-HYBRID-053: Forward key lifecycle events to production.jsonl
        if (
            self._production_logger
            and event_type in self.PRODUCTION_FORWARD_EVENTS
        ):
            try:
                self._production_logger.log_event(
                    event_type,
                    work_unit_id=kwargs.get("work_unit_id", self._work_unit_id),
                    **{k: v for k, v in kwargs.items() if k != "work_unit_id"},
                )
            except Exception as e:
                logger.debug("Failed to forward '%s' to production: %s", event_type, e)


# Module-level singleton for convenience
_hybrid_logger: HybridEventLogger | None = None


def get_hybrid_logger() -> HybridEventLogger:
    """Get or create the module-level HybridEventLogger instance.

    Returns:
        HybridEventLogger singleton instance
    """
    global _hybrid_logger
    if _hybrid_logger is None:
        _hybrid_logger = HybridEventLogger()
    return _hybrid_logger


__all__ = ["HybridEventLogger", "get_hybrid_logger"]
