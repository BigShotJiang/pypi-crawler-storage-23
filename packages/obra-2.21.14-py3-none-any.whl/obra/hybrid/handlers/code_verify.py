"""CodeVerify validator handler for post-derive plan verification."""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

from obra.agents.base import AgentIssue, AgentResult
from obra.agents.code_verify import CodeVerifyAgent
from obra.api.protocol import Priority, ValidatorRequest, ValidatorResult

logger = logging.getLogger(__name__)


class CodeVerifyHandler:
    """Handle VALIDATOR actions where stage == 'code_verify'."""

    def __init__(
        self,
        working_dir: Path,
        *,
        llm_config: dict[str, Any] | None = None,
        log_event: Any = None,
        trace_id: str | None = None,
        parent_span_id: str | None = None,
    ) -> None:
        self._working_dir = working_dir
        self._llm_config = llm_config or {}
        self._log_event = log_event
        self._trace_id = trace_id
        self._parent_span_id = parent_span_id

    def handle(self, request: ValidatorRequest) -> ValidatorResult:
        """Run CodeVerify against plan payload and convert AgentResult to ValidatorResult."""
        subject_payload = (
            request.subject_payload if isinstance(request.subject_payload, dict) else {}
        )
        plan_items = subject_payload.get("plan_items", [])
        if not isinstance(plan_items, list):
            plan_items = []

        exploration_context = subject_payload.get("exploration_context")
        item_id = str(subject_payload.get("session_id", "")).strip() or "code_verify"

        agent = CodeVerifyAgent(
            self._working_dir,
            llm_config=self._llm_config,
            log_event=self._log_event,
        )
        if self._trace_id:
            agent._trace_id = self._trace_id

        result = agent.analyze(
            item_id=item_id,
            plan_items=plan_items,
            exploration_context=exploration_context,
            timeout_ms=request.timeout_s * 1000,
        )
        cached_validator_result = agent.get_validator_result()
        if cached_validator_result is not None:
            return cached_validator_result
        return self._to_validator_result(result)

    def _to_validator_result(self, result: AgentResult) -> ValidatorResult:
        v0_issues = [
            issue
            for issue in result.issues
            if isinstance(issue, AgentIssue) and issue.priority == Priority.P0
        ]
        should_auto_revise = bool(v0_issues)
        issues = [issue.to_dict() for issue in v0_issues]
        constraints = [issue.suggestion for issue in v0_issues if issue.suggestion]

        provenance: dict[str, Any] = {
            "should_auto_revise": should_auto_revise,
            "code_verify_version": "1.0",
            "checks_run": result.metadata.get("checks_run", []),
            "status": result.status,
        }
        if result.error:
            provenance["error"] = result.error

        # If execution failed before producing findings, return unsound with diagnostics.
        if result.status != "complete" and not issues:
            issues = [
                {
                    "id": "CV-EXECUTION-1",
                    "description": result.error or "CodeVerify execution failed.",
                    "priority": "P0",
                    "check": "C0",
                }
            ]
            should_auto_revise = True
            provenance["should_auto_revise"] = True

        return ValidatorResult(
            sound=(not should_auto_revise),
            issues=issues,
            constraints=constraints,
            provenance=provenance,
        )
