"""Pipeline Options View widget.

Provides an interface for configuring pipeline behavior settings,
organized by execution phase: Pre-Planning, Planning, Execution, Review.
This view shows behavior settings (non-LLM model configuration).

Each phase section displays inherited models from Menu 3 (LLM Custom)
with optional per-phase override capability.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

from textual.app import ComposeResult
from textual.containers import Horizontal, ScrollableContainer, Vertical
from textual.message import Message
from textual.widgets import Collapsible, Input, Select, Static, Switch

from obra.config.explorer.llm_registry import get_role_tier_defaults
from obra.config.explorer.metadata import PHASE_OPTION_LABELS, PHASE_SETTINGS
from obra.config.explorer.widgets.navigation_menu import get_menu_info
from obra.config.explorer.widgets.saveable_view import SaveableViewMixin
from obra.model_registry import MODEL_REGISTRY

if TYPE_CHECKING:
    pass


# Phase to action mapping for model inheritance display
# Maps phase_id to (primary_action, profile, tier)
PHASE_MODEL_MAPPING: dict[str, tuple[str, str, str]] = {
    "pre_planning": ("enrichment_assumptions", "orchestrator", "high"),
    "planning": ("derive", "orchestrator", "high"),
    "execution": ("execute", "implementation", "medium"),
    "review": ("review", "implementation", "high"),
}

# Pipeline breadcrumb for phase context
PIPELINE_PHASES = ["Enrich", "Plan", "Execute", "Review", "Fix"]

# Maps phase_id to which phases to bold in the breadcrumb
PHASE_BOLD_MAP: dict[str, list[str]] = {
    "pre_planning": ["Enrich"],
    "planning": ["Plan"],
    "execution": ["Execute"],
    "review": ["Review", "Fix"],
}

# Phase descriptions for subtitle hints
PHASE_DESCRIPTIONS: dict[str, str] = {
    "pre_planning": "Expands your prompt with inferred requirements and context",
    "planning": "Configures plan decomposition and refinement behavior",
    "execution": "Controls iteration limits, timeouts, and agent settings",
    "review": "Sets quality thresholds and fix behavior",
}


# Setting metadata for display and editing.
# Maps setting path to description and type information.
SETTING_METADATA: dict[str, dict[str, Any]] = {
    # ═══ Pre-Planning (Enrichment) Settings ═══
    # Virtual setting that maps to enabled + always_on
    "_enrichment_mode": {
        "label": "Enrichment Mode",
        "description": "Off = skip enrichment | Smart = enrich vague inputs | Always = enrich all",
        "type": "select",
        "options": ["off", "smart", "always"],
        "default": "smart",
    },
    # Assumptions stage settings
    "planning.enrichment.stages.assumptions.reasoning_level": {
        "label": "Assumptions Reasoning",
        "description": "Configure in Menu 3: LLM Custom",
        "type": "inherited",
        "source_action": "enrichment_assumptions",
    },
    "planning.enrichment.stages.assumptions.max_passes": {
        "label": "Assumptions Max Passes",
        "description": "Retry attempts on parse failure (1-5)",
        "type": "int",
        "min": 1,
        "max": 5,
        "default": 3,
    },
    # Analogues stage settings
    "planning.enrichment.stages.analogues.reasoning_level": {
        "label": "Analogues Reasoning",
        "description": "Configure in Menu 3: LLM Custom",
        "type": "inherited",
        "source_action": "enrichment_analogues",
    },
    "planning.enrichment.stages.analogues.max_passes": {
        "label": "Analogues Max Passes",
        "description": "Retry attempts on parse failure (1-5)",
        "type": "int",
        "min": 1,
        "max": 5,
        "default": 3,
    },
    # Brief stage settings
    "planning.enrichment.stages.brief.reasoning_level": {
        "label": "Brief Reasoning",
        "description": "Configure in Menu 3: LLM Custom",
        "type": "inherited",
        "source_action": "enrichment_brief",
    },
    "planning.enrichment.stages.brief.max_passes": {
        "label": "Brief Max Passes",
        "description": "Retry attempts on parse failure (1-5)",
        "type": "int",
        "min": 1,
        "max": 5,
        "default": 3,
    },
    # ═══ Planning (Derivation) Settings ═══
    "derivation.max_depth": {
        "label": "Derivation Max Depth",
        "description": "Levels: 1=Epic, 2=Story, 3=Task, 4=Subtask",
        "type": "int",
        "min": 1,
        "max": 4,
    },
    "derivation.approval_required": {
        "label": "Require Plan Approval",
        "description": "Pause for user approval before execution",
        "type": "bool",
    },
    "derivation.hierarchy.enabled": {
        "label": "Hierarchical Derivation",
        "description": "Enable Epic → Story → Task hierarchy",
        "type": "bool",
    },
    "derivation.hierarchy.story.max_per_epic": {
        "label": "Max Stories per Epic",
        "description": "Limit stories per epic (1-20)",
        "type": "int",
        "min": 1,
        "max": 20,
    },
    "derivation.steps.step1_tier": {
        "label": "Step 1 Tier (Epic Derivation)",
        "description": "LLM tier for deriving epics from objective",
        "type": "select",
        "options": ["fast", "medium", "high"],
        "default": "high",
        "show_tier_hint": True,
    },
    "derivation.steps.step2_tier": {
        "label": "Step 2 Tier (Story Expansion)",
        "description": "LLM tier for expanding epics into stories/tasks",
        "type": "select",
        "options": ["fast", "medium", "high"],
        "default": "high",
        "show_tier_hint": True,
    },
    "derivation.steps.step3_tier": {
        "label": "Step 3 Tier (JSON Serialize)",
        "description": "LLM tier for converting prose to JSON (fast recommended)",
        "type": "select",
        "options": ["fast", "medium", "high"],
        "default": "fast",
        "show_tier_hint": True,
    },
    "derivation.serialize.max_concurrent": {
        "label": "Step 3 Parallel Workers",
        "description": "Concurrent workers for step 3 epic serialization (1-8)",
        "type": "int",
        "min": 1,
        "max": 8,
        "default": 4,
    },
    # ═══ Intent Alignment (QA) Settings ═══
    "planning.intent_alignment.model_tier": {
        "label": "Intent Check Tier",
        "description": "LLM tier for story intent alignment checks",
        "type": "select",
        "options": ["fast", "medium", "high"],
        "default": "high",
        "show_tier_hint": True,
    },
    "planning.intent_alignment.max_concurrent": {
        "label": "Intent Check Parallel Workers",
        "description": "Concurrent workers for per-story intent checks (1-8)",
        "type": "int",
        "min": 1,
        "max": 8,
        "default": 4,
    },
    # ═══ Enrichment Review Settings ═══
    "planning.enrichment.stages.review.model_tier": {
        "label": "Enrichment Review Tier",
        "description": "LLM tier for per-story plan review",
        "type": "select",
        "options": ["fast", "medium", "high"],
        "default": "high",
        "show_tier_hint": True,
    },
    "planning.enrichment.stages.review.max_concurrent": {
        "label": "Enrichment Review Parallel Workers",
        "description": "Concurrent workers for per-story review (1-8)",
        "type": "int",
        "min": 1,
        "max": 8,
        "default": 4,
    },
    "refinement.planning.enabled": {
        "label": "Plan Refinement",
        "description": "Iteratively improve plans before execution",
        "type": "bool",
    },
    "refinement.planning.quality_gate.min_score": {
        "label": "Refinement Min Score",
        "description": "Minimum score to pass refinement (0.0-1.0)",
        "type": "float",
        "min": 0.0,
        "max": 1.0,
    },
    # ═══ Execution Settings ═══
    # -- Iteration Limits --
    "orchestration.max_iterations": {
        "label": "Max Iterations",
        "description": "Maximum iterations per task (1-500)",
        "type": "int",
        "min": 1,
        "max": 500,
    },
    "orchestration.iteration_timeout_s": {
        "label": "Iteration Timeout",
        "description": "Seconds per iteration, 0 = no limit",
        "type": "int",
        "min": 0,
        "max": 3600,
    },
    "orchestration.timeouts.agent_execution_s": {
        "label": "Agent Execution Timeout",
        "description": "Seconds for agent execution, 0 = no limit",
        "type": "int",
        "min": 0,
        "max": 14400,
    },
    # -- Environment Setup --
    "story0.enabled": {
        "label": "Environment Prep (Story 0)",
        "description": "Run pre-execution environment setup",
        "type": "bool",
    },
    "story0.auto_env_setup": {
        "label": "Auto Environment Setup",
        "description": "Create project manifests automatically",
        "type": "bool",
    },
    "story0.install_target": {
        "label": "Install Target",
        "description": "Where to install dependencies",
        "type": "select",
        "options": ["project_local", "existing_env_only", "system"],
    },
    # -- Agent Configuration --
    "agent.timeout": {
        "label": "Agent Timeout",
        "description": "Default operation timeout in seconds, 0 = no limit",
        "type": "int",
        "min": 0,
        "max": 7200,
    },
    # ═══ Review & Fix Settings ═══
    # -- Quality Policy --
    "orchestration.quality.policy_mode": {
        "label": "Quality Policy Mode",
        "description": "Override quality gates independent of model tier (auto = derive from model)",
        "type": "select",
        "options": ["auto", "fast", "medium", "high"],
        "default": "auto",
    },
    # -- Quality Thresholds --
    "review.default_quality_threshold": {
        "label": "Quality Threshold",
        "description": "Minimum score to pass review (0.0-1.0)",
        "type": "float",
        "min": 0.0,
        "max": 1.0,
    },
    "validation.quality.threshold": {
        "label": "Validation Threshold",
        "description": "Minimum score for validation pass (0.0-1.0)",
        "type": "float",
        "min": 0.0,
        "max": 1.0,
    },
    # -- Review Agents --
    "review.agents.parallel": {
        "label": "Parallel Review Agents",
        "description": "Run review agents concurrently",
        "type": "bool",
    },
    "review.agents.max_workers": {
        "label": "Max Review Workers",
        "description": "Concurrent review agents (1-8)",
        "type": "int",
        "min": 1,
        "max": 8,
    },
    # -- Fix Behavior --
    "fix.batching.enabled": {
        "label": "Batch Fixes",
        "description": "Group issues by file to reduce context switches",
        "type": "bool",
    },
    "fix.verification.required": {
        "label": "Require Verification",
        "description": "Run linters/tests before attempting fixes",
        "type": "bool",
    },
    # -- Bypass Options --
    "review.permissive_mode": {
        "label": "Permissive Mode",
        "description": "Bypass P1 blockers - issues logged as warnings (--permissive)",
        "type": "bool",
        "default": False,
    },
}


@dataclass
class SettingValue:
    """Holds a setting's current value and metadata."""

    path: str
    value: Any
    label: str
    description: str
    setting_type: str  # 'bool', 'int', 'float', 'select', 'str'
    options: list[str] | None = None
    min_val: float | None = None
    max_val: float | None = None


class PipelineOptionsView(SaveableViewMixin, Static):
    """Pipeline options configuration view.

    Shows behavior settings organized by pipeline phase:
    - Pre-Planning (Enrichment): Intent enrichment stages (Assumptions, Analogues, Brief)
    - Planning (Derivation): Plan decomposition and refinement settings
    - Execution: Iteration limits, environment setup, agent configuration
    - Review & Fix: Quality thresholds, review agents, fix behavior

    Settings are grouped with sub-headers for improved scannability.

    Emits:
        Changed: When any setting value changes.
    """

    DEFAULT_CSS = """
    PipelineOptionsView {
        width: 100%;
        height: 100%;
        padding: 1 2;
    }

    PipelineOptionsView > Vertical {
        width: 100%;
        height: 100%;
    }

    PipelineOptionsView #content-scroll {
        width: 100%;
        height: 1fr;
        min-height: 10;
        min-width: 90;
    }

    PipelineOptionsView .header {
        text-style: bold;
        text-align: center;
        margin-bottom: 1;
        width: 100%;
    }

    PipelineOptionsView .description {
        color: $text-muted;
        text-align: center;
        margin-bottom: 2;
        width: 100%;
    }

    PipelineOptionsView .phase-section {
        width: 100%;
        margin-bottom: 1;
    }

    PipelineOptionsView .setting-row {
        width: 100%;
        height: auto;
        padding: 0 1;
        margin-bottom: 1;
    }

    PipelineOptionsView .setting-info {
        width: 2fr;
        height: auto;
    }

    PipelineOptionsView .setting-label {
        text-style: bold;
    }

    PipelineOptionsView .setting-description {
        color: $text-muted;
    }

    PipelineOptionsView .setting-control {
        width: 1fr;
        height: auto;
        align: right middle;
    }

    PipelineOptionsView Switch {
        width: auto;
    }

    PipelineOptionsView Select {
        width: 100%;
    }

    PipelineOptionsView Input {
        width: 100%;
    }

    PipelineOptionsView .help-text {
        color: $text-muted;
        margin-top: 2;
        text-align: center;
        width: 100%;
    }

    PipelineOptionsView Collapsible {
        width: 100%;
    }

    PipelineOptionsView .model-info {
        color: $text-muted;
        text-style: italic;
        padding: 0 1;
        margin-bottom: 1;
        width: 100%;
    }

    PipelineOptionsView .model-label {
        color: $primary;
    }

    PipelineOptionsView .phase-header-row {
        width: 100%;
        min-width: 80;
        height: auto;
        margin-bottom: 1;
    }

    PipelineOptionsView .phase-subtitle {
        width: 1fr;
        min-width: 40;
        color: $text-muted;
        text-style: italic;
        padding-left: 2;
    }

    PipelineOptionsView .phase-breadcrumb {
        width: 30;
        min-width: 28;
        color: $text-disabled;
        text-align: right;
        padding-right: 2;
    }

    PipelineOptionsView .group-header {
        color: $text-muted;
        text-style: bold;
        padding: 0 1 1 1;
        margin-top: 1;
        border-top: solid $surface-darken-2;
    }

    PipelineOptionsView .inherited-value {
        color: $text-muted;
        text-style: italic;
        padding: 0 1;
    }

    PipelineOptionsView .tier-hint {
        color: $text-muted;
        text-style: italic;
        padding: 0 1;
        margin-top: 0;
    }
    """

    class Changed(Message):
        """Message emitted when a pipeline setting changes."""

        def __init__(self, path: str, value: Any) -> None:
            """Initialize the Changed message.

            Args:
                path: Config path that changed (e.g., 'derivation.max_depth')
                value: New value for the setting
            """
            super().__init__()
            self.path = path
            self.value = value

    def __init__(
        self,
        current_values: dict[str, Any] | None = None,
        orchestrator_provider: str = "anthropic",
        orchestrator_tiers: dict[str, Any] | None = None,
        orchestrator_reasoning_tiers: dict[str, str] | None = None,
        implementation_provider: str = "anthropic",
        implementation_tiers: dict[str, Any] | None = None,
        implementation_reasoning_tiers: dict[str, str] | None = None,
        role_configs: dict[str, dict[str, Any]] | None = None,
        **kwargs,
    ) -> None:
        """Initialize the PipelineOptionsView.

        Args:
            current_values: Dict mapping config paths to current values
            orchestrator_provider: Provider configured for orchestrator profile
            orchestrator_tiers: Tier models for orchestrator {fast, medium, high}
            orchestrator_reasoning_tiers: Tier reasoning for orchestrator {fast, medium, high}
            implementation_provider: Provider configured for implementation profile
            implementation_tiers: Tier models for implementation {fast, medium, high}
            implementation_reasoning_tiers: Tier reasoning for implementation {fast, medium, high}
            role_configs: Menu 3 role configs (action_id -> {provider?, model?, ...})
        """
        super().__init__(**kwargs)
        self._current_values: dict[str, Any] = current_values or {}

        # Store role configs from Menu 3 (per-action overrides)
        self._role_configs: dict[str, dict[str, Any]] = role_configs or {}

        # Store tier configs from Menu 2 (profile-level defaults)
        self._profile_tier_configs = {
            "orchestrator": {
                "provider": orchestrator_provider,
                "tiers": orchestrator_tiers
                or {"fast": "default", "medium": "default", "high": "default"},
                "reasoning_tiers": orchestrator_reasoning_tiers
                or {"fast": "medium", "medium": "medium", "high": "medium"},
            },
            "implementation": {
                "provider": implementation_provider,
                "tiers": implementation_tiers
                or {"fast": "default", "medium": "default", "high": "default"},
                "reasoning_tiers": implementation_reasoning_tiers
                or {"fast": "medium", "medium": "medium", "high": "medium"},
            },
        }

        # Suppress change emissions during initial mount
        self._initializing = True
        # Take snapshot for dirty tracking
        self._snapshot_state()

    def on_mount(self) -> None:
        """Allow change emissions after mount completes."""
        from obra.config.explorer.debug import is_debug_enabled, log_action

        # CRITICAL: Use call_after_refresh to delay setting _initializing = False
        # until AFTER all queued widget Changed events from initial value setting
        # have been processed. This prevents phantom changes from mount events.
        def finish_initialization() -> None:
            self._initializing = False
            # Re-snapshot state AFTER all mount events are processed
            self._snapshot_state()
            if is_debug_enabled():
                log_action(
                    "PipelineOptionsView.on_mount.finish_init",
                    f"_initializing={self._initializing}, snapshot taken",
                )

        self.call_after_refresh(finish_initialization)

    def _resolve_model_display(self, provider: str, model_id: str) -> str:
        """Resolve a model ID to its display name.

        Args:
            provider: Provider ID (anthropic, openai, etc.)
            model_id: Model ID to resolve (may be 'default' or specific model)

        Returns:
            Human-readable model name (e.g., "Claude Opus 4.6")
        """
        provider_config = MODEL_REGISTRY.get(provider)
        if not provider_config:
            return model_id

        # Handle 'default' by resolving to the provider's default model
        if model_id == "default":
            actual_id = provider_config.default_model or "auto"
            model_info = provider_config.models.get(actual_id)
            return model_info.display_name if model_info else actual_id

        model_info = provider_config.models.get(model_id)
        return model_info.display_name if model_info else model_id

    def _resolve_profile_tier_model(
        self,
        profile: str,
        tier: str,
        provider_override: str | None = None,
    ) -> tuple[str, str]:
        """Resolve effective provider/model from profile tier configuration.

        Args:
            profile: Profile role name (orchestrator or implementation)
            tier: Tier name (fast, medium, high)
            provider_override: Optional explicit provider override from Menu 3

        Returns:
            Tuple of (provider, model_id)
        """
        profile_cfg = self._profile_tier_configs.get(profile, {})
        provider = provider_override or str(profile_cfg.get("provider", "anthropic"))

        tiers = profile_cfg.get("tiers", {})
        model_id = "default"
        if isinstance(tiers, dict):
            tier_value = tiers.get(tier, "default")
            if isinstance(tier_value, dict):
                model_id = str(tier_value.get("model", "default"))
            elif tier_value is not None:
                model_id = str(tier_value)

        if model_id in ("", "None"):
            model_id = "default"

        if model_id == "default":
            role_defaults = get_role_tier_defaults(provider, profile)
            model_id = str(role_defaults.get(tier, model_id))

        return provider, model_id

    def _get_phase_model_info(self, phase_id: str) -> str:
        """Get the inherited model info for a phase.

        Checks Menu 3 role overrides first, then falls back to Menu 2 tier configs.

        Args:
            phase_id: Phase identifier (pre_planning, planning, execution, review)

        Returns:
            Display string like "Opus 4.6 (from Menu 3: LLM Custom)"
        """
        mapping = PHASE_MODEL_MAPPING.get(phase_id)
        if not mapping:
            return "Unknown"

        action, default_profile, default_tier = mapping
        role_cfg = self._role_configs.get(action, {})

        # Resolve Menu 3 role profile/tier inheritance using action defaults.
        from obra.config.explorer.widgets.llm_custom_view import DEFAULT_ACTION_CONFIG

        defaults = DEFAULT_ACTION_CONFIG.get(action, {})
        profile = str(role_cfg.get("profile", defaults.get("profile", default_profile)))
        tier = str(role_cfg.get("tier", defaults.get("tier", default_tier)))
        if profile not in ("orchestrator", "implementation"):
            profile = default_profile
        if tier not in ("fast", "medium", "high"):
            tier = default_tier

        explicit_provider = role_cfg.get("provider")
        provider_override = str(explicit_provider) if explicit_provider else None
        explicit_model = role_cfg.get("model")
        if explicit_model:
            provider = provider_override
            if not provider:
                provider, _ = self._resolve_profile_tier_model(profile, tier)
            model_name = self._resolve_model_display(provider, str(explicit_model))
            return f"{model_name} (from Menu 3: LLM Custom)"

        provider, model_id = self._resolve_profile_tier_model(
            profile, tier, provider_override=provider_override
        )

        model_name = self._resolve_model_display(provider, model_id)
        role_selected_source = (
            provider_override is not None
            or profile != default_profile
            or tier != default_tier
        )
        source = "Menu 3: LLM Custom" if role_selected_source else "Menu 2: LLM Moderate"
        return f"{model_name} (from {source})"

    def _compose_phase_header(self, phase_id: str) -> ComposeResult:
        """Compose phase subtitle and pipeline breadcrumb.

        Args:
            phase_id: The phase identifier (pre_planning, planning, etc.)
        """
        # Build breadcrumb with current phase(s) bolded
        bold_phases = PHASE_BOLD_MAP.get(phase_id, [])
        breadcrumb_parts = []
        for phase_name in PIPELINE_PHASES:
            if phase_name in bold_phases:
                # Use cyan for visibility (bold is hard to see on terminals)
                breadcrumb_parts.append(f"[cyan]{phase_name}[/cyan]")
            else:
                breadcrumb_parts.append(phase_name)
        breadcrumb = " · ".join(breadcrumb_parts)

        with Horizontal(classes="phase-header-row"):
            # Left: Phase description
            description = PHASE_DESCRIPTIONS.get(phase_id, "")
            yield Static(description, classes="phase-subtitle", markup=False)
            # Right: Pipeline breadcrumb
            yield Static(breadcrumb, classes="phase-breadcrumb", markup=True)

    def compose(self) -> ComposeResult:
        """Create the view content."""
        menu_info = get_menu_info("pipeline")
        with Vertical():
            yield Static(menu_info["label"], classes="header")
            yield Static(menu_info["subtitle"], classes="description")

            # Scrollable container for phase sections
            with ScrollableContainer(id="content-scroll"):
                # Render each phase section
                for phase_id, phase_label in PHASE_OPTION_LABELS.items():
                    settings = PHASE_SETTINGS.get(phase_id, [])
                    with Collapsible(title=phase_label, collapsed=False, id=f"phase-{phase_id}"):
                        # Phase header with breadcrumb
                        yield from self._compose_phase_header(phase_id)
                        # Show inherited model info
                        model_info = self._get_phase_model_info(phase_id)
                        yield Static(
                            f"[bold]Model:[/bold] {model_info}",
                            classes="model-info",
                            id=f"model-info-{phase_id}",
                        )
                        for setting_entry in settings:
                            # Check for group header
                            if setting_entry.startswith("GROUP:"):
                                group_name = setting_entry[6:]  # Remove "GROUP:" prefix
                                yield Static(f"── {group_name} ──", classes="group-header")
                            else:
                                yield from self._compose_setting_row(setting_entry)

            yield Static(
                "Changes are applied when you save. Use 's' to save.",
                classes="help-text",
            )

    def _get_enrichment_mode(self) -> str:
        """Get current enrichment mode from enabled + always_on config.

        Returns:
            'off', 'smart', or 'always'
        """
        enabled = self._current_values.get("planning.enrichment.enabled", True)
        always_on = self._current_values.get("planning.enrichment.always_on", False)

        if not enabled:
            return "off"
        elif always_on:
            return "always"
        else:
            return "smart"

    def _get_inherited_reasoning_display(self, action_id: str) -> str:
        """Get reasoning level display for an action from Menu 3 config.

        Args:
            action_id: Action ID (e.g., 'enrichment_assumptions')

        Returns:
            Display string like 'Medium' or 'Off'
        """
        # Check role configs from Menu 3 for explicit override
        role_cfg = self._role_configs.get(action_id, {})
        explicit_reasoning = role_cfg.get("reasoning_level")
        if explicit_reasoning:
            return str(explicit_reasoning).capitalize()

        # Inherit from profile-level reasoning (Menu 2/1)
        from obra.config.explorer.widgets.llm_custom_view import DEFAULT_ACTION_CONFIG

        defaults = DEFAULT_ACTION_CONFIG.get(action_id, {})
        profile = str(role_cfg.get("profile", defaults.get("profile", "implementation")))
        tier = str(role_cfg.get("tier", defaults.get("tier", "medium")))
        profile_cfg = self._profile_tier_configs.get(profile, {})
        reasoning_tiers = profile_cfg.get("reasoning_tiers", {})
        inherited_reasoning = "medium"
        if isinstance(reasoning_tiers, dict):
            inherited_reasoning = str(reasoning_tiers.get(tier, "medium"))
        else:
            tiers = profile_cfg.get("tiers", {})
            if isinstance(tiers, dict):
                tier_value = tiers.get(tier)
                if isinstance(tier_value, dict):
                    inherited_reasoning = str(tier_value.get("thinking_level", "medium"))
        return inherited_reasoning.capitalize()

    def _get_step_tier_hint(self, tier: str) -> str:
        """Get hint text showing which model the tier resolves to.

        Uses effective parent tier configuration (Menu 2/1) to show the
        model selected for the current orchestrator tier.

        Args:
            tier: Tier name (fast, medium, high)

        Returns:
            Hint text like "→ Sonnet" or "→ Opus"
        """
        provider, model_id = self._resolve_profile_tier_model("orchestrator", tier)
        model_display = self._resolve_model_display(provider, model_id)
        return f"[dim]→ {model_display}[/dim]"

    def _update_step_tier_hints(self) -> None:
        """Update all step tier hint labels to show resolved models."""
        step_tier_paths = [
            "derivation.steps.step1_tier",
            "derivation.steps.step2_tier",
            "derivation.steps.step3_tier",
        ]
        for path in step_tier_paths:
            widget_id = path.replace(".", "-")
            try:
                hint = self.query_one(f"#hint-{widget_id}", Static)
                tier_value = self._current_values.get(path, "high")
                hint_text = self._get_step_tier_hint(str(tier_value))
                hint.update(hint_text)
            except Exception:
                pass

    def _compose_setting_row(self, path: str) -> ComposeResult:
        """Compose a single setting configuration row.

        Args:
            path: Config path for the setting
        """
        metadata = SETTING_METADATA.get(path, {})
        label = metadata.get("label", path.split(".")[-1])
        description = metadata.get("description", "")
        setting_type = metadata.get("type", "str")
        options = metadata.get("options")
        default_value = metadata.get("default")
        current_value = self._current_values.get(path)

        # Use default if no current value
        if current_value is None and default_value is not None:
            current_value = default_value

        # Create unique ID from path
        widget_id = path.replace(".", "-")

        # Handle virtual enrichment_mode setting
        if path == "_enrichment_mode":
            current_value = self._get_enrichment_mode()
            widget_id = "enrichment-mode"

        with Horizontal(classes="setting-row", id=f"setting-{widget_id}"):
            # Left: Setting info
            with Vertical(classes="setting-info"):
                yield Static(label, classes="setting-label")
                yield Static(description, classes="setting-description")

            # Right: Control widget
            with Vertical(classes="setting-control"):
                if setting_type == "inherited":
                    # Read-only display with hint to Menu 3
                    source_action = metadata.get("source_action", "")
                    display_value = self._get_inherited_reasoning_display(source_action)
                    yield Static(
                        f"{display_value}  [dim]→ Menu 3[/dim]",
                        classes="inherited-value",
                        markup=True,
                    )
                elif setting_type == "bool":
                    yield Switch(
                        value=(bool(current_value) if current_value is not None else False),
                        id=f"switch-{widget_id}",
                    )
                elif setting_type == "select" and options:
                    # Format options for display (capitalize)
                    select_options = [(opt.capitalize(), opt) for opt in options]
                    yield Select(
                        select_options,
                        id=f"select-{widget_id}",
                        value=str(current_value) if current_value else options[0],
                        allow_blank=False,
                    )
                    # Add tier hint for step tier settings
                    if metadata.get("show_tier_hint"):
                        tier_value = str(current_value) if current_value else options[0]
                        hint_text = self._get_step_tier_hint(tier_value)
                        yield Static(
                            hint_text,
                            id=f"hint-{widget_id}",
                            classes="tier-hint",
                            markup=True,
                        )
                elif setting_type in ("int", "float"):
                    default = (
                        default_value
                        if default_value is not None
                        else (0 if setting_type == "int" else 0.0)
                    )
                    yield Input(
                        value=(str(current_value) if current_value is not None else str(default)),
                        id=f"input-{widget_id}",
                        type="integer" if setting_type == "int" else "number",
                    )
                else:
                    # String or unknown type
                    yield Input(
                        value=str(current_value) if current_value is not None else "",
                        id=f"input-{widget_id}",
                    )

    def _emit_change(self, path: str, value: Any) -> None:
        """Emit a change message if not initializing.

        Skips emission during initial mount to prevent spurious changes.
        """
        if self._initializing:
            return
        self.post_message(self.Changed(path, value))

    def on_switch_changed(self, event: Switch.Changed) -> None:
        """Handle switch toggle changes."""
        # Skip processing during initial mount to prevent spurious state changes
        if self._initializing:
            return

        switch_id = event.switch.id
        if not switch_id or not switch_id.startswith("switch-"):
            return

        # Extract path from ID
        path = switch_id.replace("switch-", "").replace("-", ".")
        self._current_values[path] = event.value
        self._emit_change(path, event.value)

    def on_select_changed(self, event: Select.Changed) -> None:
        """Handle select dropdown changes."""
        # Skip processing during initial mount to prevent spurious state changes
        if self._initializing:
            return

        select_id = event.select.id
        if not select_id or not select_id.startswith("select-"):
            return

        # Handle Select.BLANK sentinel - skip processing for blank selections
        if event.value is Select.BLANK:
            return

        # Handle virtual enrichment mode setting
        if select_id == "select-enrichment-mode":
            mode = str(event.value)
            # Map mode to enabled + always_on config values
            if mode == "off":
                enabled, always_on = False, False
            elif mode == "smart":
                enabled, always_on = True, False
            else:  # "always"
                enabled, always_on = True, True

            self._current_values["planning.enrichment.enabled"] = enabled
            self._current_values["planning.enrichment.always_on"] = always_on
            self._emit_change("planning.enrichment.enabled", enabled)
            self._emit_change("planning.enrichment.always_on", always_on)
            return

        # Extract path from ID
        path = select_id.replace("select-", "").replace("-", ".")
        value = str(event.value)
        self._current_values[path] = value
        self._emit_change(path, value)

        # Update step tier hints if this is a tier setting
        if path.startswith("derivation.steps.step") and path.endswith("_tier"):
            self._update_step_tier_hints()

    def on_input_changed(self, event: Input.Changed) -> None:
        """Handle input field changes."""
        # Skip processing during initial mount to prevent spurious state changes
        if self._initializing:
            return

        input_id = event.input.id
        if not input_id or not input_id.startswith("input-"):
            return

        # Extract path from ID
        path = input_id.replace("input-", "").replace("-", ".")

        # Get the setting type to convert the value
        metadata = SETTING_METADATA.get(path, {})
        setting_type = metadata.get("type", "str")

        value: int | float | str
        try:
            if setting_type == "int":
                value = int(event.value) if event.value else 0
            elif setting_type == "float":
                value = float(event.value) if event.value else 0.0
            else:
                value = event.value
        except ValueError:
            # Invalid input, skip update
            return

        self._current_values[path] = value
        self._emit_change(path, value)

    def get_current_values(self) -> dict[str, Any]:
        """Get all current setting values.

        Returns:
            Dict mapping config paths to current values
        """
        return self._current_values.copy()

    # --- SaveableViewMixin implementation ---

    def _get_saveable_state(self) -> dict[str, Any]:
        """Get current state for dirty tracking.

        Returns config paths mapped to current values.
        """
        return self._current_values.copy()

    def _restore_state(self, state: dict[str, Any]) -> None:
        """Restore state from snapshot and update UI."""
        self._current_values = state.copy()
        # Update all UI widgets to reflect restored state
        for path, value in state.items():
            widget_id = path.replace(".", "-")
            metadata = SETTING_METADATA.get(path, {})
            setting_type = metadata.get("type", "str")

            try:
                if setting_type == "bool":
                    from textual.widgets import Switch

                    switch = self.query_one(f"#switch-{widget_id}", Switch)
                    switch.value = bool(value) if value is not None else False
                elif setting_type == "select":
                    from textual.widgets import Select

                    select = self.query_one(f"#select-{widget_id}", Select)
                    select.value = str(value) if value else ""
                else:
                    from textual.widgets import Input

                    input_widget = self.query_one(f"#input-{widget_id}", Input)
                    input_widget.value = str(value) if value is not None else ""
            except Exception:
                pass
