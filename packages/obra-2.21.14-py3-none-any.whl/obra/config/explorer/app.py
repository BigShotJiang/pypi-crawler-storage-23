"""Configuration Explorer Textual Application.

Main application class for the interactive configuration browser.
"""

import logging
from importlib.resources import files
from typing import Any

from textual.app import App, ComposeResult
from textual.binding import Binding
from textual.containers import Container, Vertical
from textual.widgets import Footer, Header, Static, Tree

from obra import config
from obra.config.loaders import get_config_explorer_config

from .models import ConfigNode, ConfigTree, SettingTier, ValueType
from .utils import (
    build_pipeline_root,
    dict_to_config_tree,
    filter_tree_by_predicate,
    find_nodes_by_path_pattern,
    get_preset_name,
)
from .widgets import (
    Breadcrumb,
    ConfigTreeView,
    CustomLLMView,
    DebugAdvancedView,
    EditModal,
    HelpOverlay,
    LLMSelection,
    LLMWizard,
    ModerateLLMView,
    NavigationMenu,
    PersonaView,
    PipelineOptionsView,
    PresetPicker,
    PresetSelection,
    QuickActionsBar,
    RoleConfig,
    SavePreviewModal,
    SearchBar,
    SimpleLLMView,
    SpecializedAgentsView,
    UnsavedAction,
    UnsavedChangesModal,
    ValidationToolingView,
)
from .widgets.saveable_view import SaveableViewMixin

logger = logging.getLogger(__name__)


class OfflineBanner(Static):
    """Warning banner shown when server connection is unavailable."""

    DEFAULT_CSS = """
    OfflineBanner {
        height: auto;
        padding: 0 1;
        background: $warning-darken-3;
        color: $warning;
        text-style: bold;
    }
    """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)
        self.update(
            "Offline Mode - Server unavailable. "
            "Local settings are editable, server settings are read-only."
        )


class DescriptionPanel(Static):
    """Panel showing the description of the currently selected setting."""

    DEFAULT_CSS = """
    DescriptionPanel {
        height: auto;
        min-height: 3;
        max-height: 6;
        padding: 0 1;
        background: $surface;
        border-top: solid $primary;
    }
    """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)
        self._description = "Select a setting to see its description."

    def update_description(self, description: str | None, path: str = "") -> None:
        """Update the displayed description.

        Args:
            description: Description text to show
            path: Path of the setting being described
        """
        if description:
            self._description = f"[bold]{path}[/bold]\n{description}"
        else:
            self._description = f"[bold]{path}[/bold]\nNo description available."
        self.update(self._description)


class StatusBar(Static):
    """Status bar showing pending changes, persona, and connection status."""

    DEFAULT_CSS = """
    StatusBar {
        height: 1;
        dock: bottom;
        padding: 0 1;
        background: $primary-background;
        color: $text;
    }
    """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)
        self._pending_count = 0
        self._persona = "Custom"
        self._connected = True
        self._view_mode = "tree"
        self._tag_filter: str | None = None
        self._session_overrides: dict[str, str] | None = None

    def update_status(
        self,
        pending_count: int = 0,
        preset: str = "Custom",
        connected: bool = True,
        view_mode: str = "tree",
        tag_filter: str | None = None,
        persona: str | None = None,
        session_overrides: dict[str, str] | None = None,
    ) -> None:
        """Update the status bar content.

        Args:
            pending_count: Number of pending changes
            preset: Current preset name (legacy, for backward compatibility)
            connected: Whether server connection is active
            view_mode: Current view mode (tree or pipeline)
            tag_filter: Active tag filter
            persona: Current detected persona name
            session_overrides: Dict of CLI flag overrides (e.g., {"model": "sonnet via --model"})
        """
        self._pending_count = pending_count
        self._persona = persona or preset
        self._connected = connected
        self._view_mode = view_mode
        self._tag_filter = tag_filter
        self._session_overrides = session_overrides

        # Build status components
        parts = []

        # Pending changes
        changes_text = f"{pending_count} unsaved" if pending_count > 0 else "saved"
        parts.append(changes_text)

        # Persona indicator
        parts.append(f"Persona: {self._persona}")

        # Session overrides indicator (S7.T3)
        if self._session_overrides:
            override_text = ", ".join(f"{k}: {v}" for k, v in self._session_overrides.items())
            parts.append(f"[yellow]Override: {override_text}[/yellow]")

        # View mode and tag filter
        view_text = f"view: {view_mode}"
        if tag_filter:
            view_text = f"{view_text} | tag: {tag_filter}"
        parts.append(view_text)

        # Connection status
        connection_icon = "[green]o[/green]" if connected else "[red]x[/red]"
        connection_text = "Connected" if connected else "Offline"
        parts.append(f"{connection_icon} {connection_text}")

        self.update(" | ".join(parts))


class ConfigExplorerApp(App):
    """Interactive TUI for browsing and editing Obra configuration.

    Features:
    - Tree-based navigation of configuration
    - Inline editing of values
    - Quick action wizards for common operations
    - Staged changes with explicit save
    """

    TITLE = "Obra Configuration Explorer"

    # Use importlib.resources to access package data file (works in installed packages)
    CSS_PATH = str(files("obra.config.explorer.styles").joinpath("explorer.tcss"))

    BINDINGS = [
        # q = contextual: back when in subview, quit when on menu
        Binding("q", "back_or_quit", "Back/Quit", priority=True),
        # Escape = always safe back (never quits)
        Binding("escape", "safe_back", "Back", priority=True),
        Binding("s", "save", "Save"),
        Binding("u", "discard", "Discard"),
        Binding("R", "reset_to_defaults", "Reset All"),
        Binding("slash", "search", "Search"),
        Binding("question_mark", "show_shortcuts", "Shortcuts"),
        Binding("v", "toggle_view", "View"),
        # Navigation shortcuts (0-7) - ordered by increasing complexity
        Binding("0", "nav_personas", "Personas", show=False),
        Binding("1", "nav_simple_llm", "LLM Simple", show=False),
        Binding("2", "nav_moderate_llm", "LLM Moderate", show=False),
        Binding("3", "nav_custom_llm", "LLM Custom", show=False),
        Binding("4", "nav_pipeline", "Pipeline", show=False),
        Binding("5", "nav_agents", "Agents", show=False),
        Binding("6", "nav_validation", "Validation", show=False),
        Binding("7", "nav_debug_advanced", "Debug & Advanced", show=False),
        Binding("8", "nav_full_config", "Full Config", show=False),
        Binding("9", "nav_menu", "Menu", show=False),
        Binding("p", "nav_personas", "Personas", show=False),
    ]

    def __init__(
        self,
        local_config: dict[str, Any] | None = None,
        server_config: dict[str, Any] | None = None,
        initial_section: str | None = None,
        api_client: Any | None = None,
        origins: dict[str, str] | None = None,
    ) -> None:
        """Initialize the Configuration Explorer.

        Args:
            local_config: Local configuration dictionary
            server_config: Server configuration dictionary
            initial_section: Section to expand initially (llm, features, advanced)
            api_client: API client for server operations
        """
        super().__init__()
        self._local_config = local_config or {}
        self._server_config = server_config or {}
        self._initial_section = initial_section
        self._api_client = api_client
        self._origins = origins or {}
        self._config_tree: ConfigTree | None = None
        self._base_tree: ConfigTree | None = None
        self._view_mode = "tree"
        self._active_tag_filter: str | None = None
        # Assume disconnected if no API client or no server config
        self._connected = api_client is not None and bool(server_config)
        # Navigation state
        self._current_view = "menu"  # 'menu', 'simple_llm', 'moderate_llm', etc.

    def compose(self) -> ComposeResult:
        """Create child widgets for the app."""
        yield Header()
        # Show offline banner if not connected
        if not self._connected:
            yield OfflineBanner(id="offline-banner")
        # Breadcrumb (hidden when on menu)
        yield Breadcrumb(id="breadcrumb")
        yield QuickActionsBar(id="quick-actions")
        yield SearchBar(id="search")
        # Navigation menu (shown on launch)
        yield NavigationMenu(id="nav-menu")
        yield Container(
            Vertical(
                # Tree will be added after config_tree is built in on_mount
                id="tree-container",
            ),
            DescriptionPanel(id="description"),
            id="main",
        )
        yield StatusBar(id="status")
        yield Footer()

    def on_mount(self) -> None:
        """Initialize the app when mounted."""
        from obra.config.explorer.debug import is_debug_enabled, log_tree_rebuild

        # Build the config tree
        if is_debug_enabled():
            log_tree_rebuild("on_mount: initial build")

        self._base_tree = dict_to_config_tree(
            self._local_config,
            self._server_config,
            origins=self._origins,
        )
        self._config_tree = self._build_view_tree()

        # Add the tree view to the container
        tree_container = self.query_one("#tree-container", Vertical)
        tree_view = ConfigTreeView(self._config_tree, id="tree")
        tree_container.mount(tree_view)

        # Update status bar with preset info
        preset = get_preset_name(self._server_config) or "default"
        status_bar = self.query_one("#status", StatusBar)
        status_bar.update_status(
            pending_count=0,
            preset=preset,
            connected=self._connected,
        )

        # Set up initial navigation state - show menu, hide main content
        self._show_menu()

        # If initial_section specified, navigate to it directly
        if self._initial_section:
            section_mappings = {
                "llm": "simple_llm",
                "features": "personas",
                "advanced": "full_config",
            }
            target_view = section_mappings.get(self._initial_section)
            if target_view:
                self._show_view(target_view)

    # --- Navigation Methods ---

    # Human-readable names for entry points (ordered by complexity 0-7)
    VIEW_NAMES = {
        "personas": "Personas",
        "simple_llm": "LLM Simple",
        "moderate_llm": "LLM Moderate",
        "custom_llm": "LLM Custom",
        "pipeline": "Pipeline Options",
        "agents": "Specialized Agents",
        "validation": "Validation & Tooling",
        "debug_advanced": "Debug & Advanced",
        "full_config": "Full Config",
    }

    def on_navigation_menu_selected(self, event: NavigationMenu.Selected) -> None:
        """Handle navigation menu selection."""
        self._show_view(event.entry_point)

    def on_breadcrumb_home_clicked(self, _event: Breadcrumb.HomeClicked) -> None:
        """Handle breadcrumb home button click."""
        self._show_menu()

    def _show_menu(self) -> None:
        """Show the navigation menu and hide other views."""
        self._current_view = "menu"

        # Remove any custom view widgets to prevent stale state
        self._remove_custom_views()

        # Show navigation menu
        try:
            nav_menu = self.query_one("#nav-menu", NavigationMenu)
            nav_menu.display = True
            nav_menu.focus()
        except Exception:
            pass

        # Hide breadcrumb
        try:
            breadcrumb = self.query_one("#breadcrumb", Breadcrumb)
            breadcrumb.display = False
        except Exception:
            pass

        # Hide main content area
        try:
            main = self.query_one("#main", Container)
            main.display = False
        except Exception:
            pass

        # Hide quick actions and search when on menu
        try:
            self.query_one("#quick-actions", QuickActionsBar).display = False
            self.query_one("#search", SearchBar).display = False
        except Exception:
            pass

    def _show_view(self, entry_point: str) -> None:
        """Navigate to a specific view.

        Args:
            entry_point: ID of the view to show ('simple_llm', 'full_config', etc.)
        """
        self._current_view = entry_point

        # Hide navigation menu
        try:
            nav_menu = self.query_one("#nav-menu", NavigationMenu)
            nav_menu.display = False
        except Exception:
            pass

        # Show and update breadcrumb
        try:
            breadcrumb = self.query_one("#breadcrumb", Breadcrumb)
            breadcrumb.display = True
            breadcrumb.set_location(self.VIEW_NAMES.get(entry_point, entry_point))
        except Exception:
            pass

        # Remove any existing custom view widgets
        self._remove_custom_views()

        # Show main content area
        try:
            main = self.query_one("#main", Container)
            main.display = True

            if entry_point == "full_config":
                # Show tree view for full config
                self.query_one("#quick-actions", QuickActionsBar).display = True
                self.query_one("#search", SearchBar).display = True
                self.query_one("#tree-container", Vertical).display = True
                self.query_one("#description", DescriptionPanel).display = True
                tree_view = self.query_one("#tree", ConfigTreeView)
                tree_view.focus()
            elif entry_point == "simple_llm":
                # Show Simple LLM view
                self.query_one("#quick-actions", QuickActionsBar).display = False
                self.query_one("#search", SearchBar).display = False
                self.query_one("#tree-container", Vertical).display = False
                self.query_one("#description", DescriptionPanel).display = False
                self._mount_simple_llm_view()
            elif entry_point == "moderate_llm":
                # Show Moderate LLM view
                self.query_one("#quick-actions", QuickActionsBar).display = False
                self.query_one("#search", SearchBar).display = False
                self.query_one("#tree-container", Vertical).display = False
                self.query_one("#description", DescriptionPanel).display = False
                self._mount_moderate_llm_view()
            elif entry_point == "custom_llm":
                # Show Custom LLM view
                self.query_one("#quick-actions", QuickActionsBar).display = False
                self.query_one("#search", SearchBar).display = False
                self.query_one("#tree-container", Vertical).display = False
                self.query_one("#description", DescriptionPanel).display = False
                self._mount_custom_llm_view()
            elif entry_point == "pipeline":
                # Show Pipeline Options view
                self.query_one("#quick-actions", QuickActionsBar).display = False
                self.query_one("#search", SearchBar).display = False
                self.query_one("#tree-container", Vertical).display = False
                self.query_one("#description", DescriptionPanel).display = False
                self._mount_pipeline_options_view()
            elif entry_point == "agents":
                # Show Specialized Agents view
                self.query_one("#quick-actions", QuickActionsBar).display = False
                self.query_one("#search", SearchBar).display = False
                self.query_one("#tree-container", Vertical).display = False
                self.query_one("#description", DescriptionPanel).display = False
                self._mount_specialized_agents_view()
            elif entry_point == "validation":
                # Show Validation & Tooling view
                self.query_one("#quick-actions", QuickActionsBar).display = False
                self.query_one("#search", SearchBar).display = False
                self.query_one("#tree-container", Vertical).display = False
                self.query_one("#description", DescriptionPanel).display = False
                self._mount_validation_tooling_view()
            elif entry_point == "debug_advanced":
                # Show Debug & Advanced view
                self.query_one("#quick-actions", QuickActionsBar).display = False
                self.query_one("#search", SearchBar).display = False
                self.query_one("#tree-container", Vertical).display = False
                self.query_one("#description", DescriptionPanel).display = False
                self._mount_debug_advanced_view()
            elif entry_point == "personas":
                # Show Personas view (full-screen like other LLM views)
                self.query_one("#quick-actions", QuickActionsBar).display = False
                self.query_one("#search", SearchBar).display = False
                self.query_one("#tree-container", Vertical).display = False
                self.query_one("#description", DescriptionPanel).display = False
                self._mount_persona_view()
            else:
                # For now, show placeholder for other views
                self.query_one("#quick-actions", QuickActionsBar).display = False
                self.query_one("#search", SearchBar).display = False
                self.query_one("#tree-container", Vertical).display = False
                self.query_one("#description", DescriptionPanel).display = False
                self.notify(f"{self.VIEW_NAMES.get(entry_point, entry_point)}: Coming soon")
        except Exception:
            pass

    def _remove_custom_views(self) -> None:
        """Remove any mounted custom view widgets."""
        for widget in self.query(".custom-view"):
            widget.remove()

    def _sanitize_model_value(self, model: str | None, provider: str) -> str:
        """Sanitize model value for Select widget compatibility.

        Special config values like 'per-tier' and 'per-role' are delegation
        markers, not actual model IDs. This method validates the model value
        against available options and falls back to 'default' if invalid.

        Args:
            model: Model value from config (may be None or special value)
            provider: Provider to check valid models for

        Returns:
            Valid model ID for the Select widget
        """
        from .llm_registry import get_models

        # Special delegation values that aren't actual models
        delegation_values = {"per-tier", "per-role", None, ""}

        if model in delegation_values:
            return "default"

        # Verify model exists in provider's model list
        all_models = get_models()
        provider_models = all_models.get(provider, [])
        valid_model_ids = {m[0] for m in provider_models}

        if model not in valid_model_ids:
            return "default"

        return model

    def _sanitize_reasoning_value(self, reasoning: str | None) -> str:
        """Sanitize reasoning value for Select widget compatibility."""
        valid_levels = {"off", "low", "medium", "high", "extra high", "maximum"}
        if isinstance(reasoning, str) and reasoning in valid_levels:
            return reasoning
        return "medium"

    def _extract_tier_model(
        self, tier_value: Any, provider: str, default: str = "default"
    ) -> str:
        """Extract model from a tier entry (string or mapping)."""
        if isinstance(tier_value, dict):
            model = tier_value.get("model", default)
            return self._sanitize_model_value(str(model), provider)
        if tier_value is None:
            return default
        return self._sanitize_model_value(str(tier_value), provider)

    def _extract_tier_reasoning(self, tier_value: Any, fallback: str = "medium") -> str:
        """Extract reasoning from a tier entry (string or mapping)."""
        if isinstance(tier_value, dict):
            return self._sanitize_reasoning_value(str(tier_value.get("thinking_level", fallback)))
        return self._sanitize_reasoning_value(fallback)

    def _mount_persona_view(self) -> None:
        """Mount the Persona configuration view with current config values."""
        # Detect current active persona from config
        current_persona = self._detect_active_persona_id()

        # Get current provider for tier resolution
        current_provider = "anthropic"
        if self._config_tree:
            provider_node = self._config_tree.get_node("llm.orchestrator.provider")
            if provider_node and provider_node.value:
                current_provider = provider_node.value

        # Create and mount the view
        view = PersonaView(
            current_persona=current_persona,
            current_provider=current_provider,
            classes="custom-view",
            id="persona-view",
        )
        main = self.query_one("#main", Container)
        main.mount(view)
        view.focus()

    def _detect_active_persona_id(self) -> str:
        """Detect which persona ID matches the current configuration.

        Returns:
            Persona ID (recommended, genie, quick_start, local_only) or 'genie' as default.
        """
        if self._config_tree is None:
            return "genie"

        from .widgets.preset_picker import PERSONAS

        # Get current automation_mode - key differentiator between personas
        automation_mode = "auto_full"  # default
        automation_node = self._config_tree.get_node("automation_mode")
        if automation_node and automation_node.value:
            automation_mode = automation_node.value

        # Get current provider
        provider = "anthropic"
        provider_node = self._config_tree.get_node("llm.orchestrator.provider")
        if provider_node and provider_node.value:
            provider = provider_node.value

        # Check scaffolded settings
        scaffolded_enabled = True  # default
        scaffolded_node = self._config_tree.get_node("planning.scaffolded.enabled")
        if scaffolded_node and scaffolded_node.value is not None:
            scaffolded_enabled = scaffolded_node.value

        # Match against personas
        for persona_id, persona in PERSONAS.items():
            features = persona.get("features", {})
            llm_profiles = persona.get("llm_profiles", {})

            # Check automation_mode match
            persona_automation = features.get("automation_mode")
            if persona_automation and persona_automation != automation_mode:
                continue

            # Check scaffolded.enabled match
            persona_scaffolded = features.get("planning.scaffolded.enabled")
            if persona_scaffolded is not None and persona_scaffolded != scaffolded_enabled:
                continue

            # Check provider match for local_only
            orch_profile = llm_profiles.get("orchestrator", {})
            persona_provider = orch_profile.get("provider")
            if persona_provider == "ollama" and provider != "ollama":
                continue
            if persona_provider != "ollama" and provider == "ollama":
                continue

            # This persona matches
            return persona_id

        return "genie"

    def on_persona_view_changed(self, event: PersonaView.Changed) -> None:
        """Handle Persona view selection changes.

        Persona cascades down to all LLM views (Simple, Moderate, Custom).
        """
        if not self._config_tree:
            return

        result = event.selection
        changes_made = self._apply_persona_to_config(result)

        # Note: We do NOT modify llm.roles.* here because those paths contain
        # profile references (e.g., "orchestrator", "implementation"), not model names.
        # LLM model settings are applied via llm_profiles in _apply_persona_to_config.

        # Update the view to show new ACTIVE state
        try:
            persona_view = self.query_one("#persona-view", PersonaView)
            persona_view.set_current_persona(result.preset_id)
        except Exception:
            pass

        # Update status bar
        self._update_status_bar()

        self.notify(
            f"Persona applied: {result.preset_name} ({changes_made} changes)",
            severity="information",
        )

    def _mount_simple_llm_view(self) -> None:
        """Mount the Simple LLM configuration view with current config values."""
        from .debug import is_debug_enabled, log_action

        # Get current values from config for orchestrator and implementation separately
        orch_provider = "anthropic"
        orch_model = "default"
        orch_reasoning = "medium"
        impl_provider = "anthropic"
        impl_model = "default"
        impl_reasoning = "medium"

        # Track raw values for debug
        raw_orch_model = "default"
        raw_impl_model = "default"

        if self._config_tree:
            # Orchestrator config
            orch_prov_node = self._config_tree.get_node("llm.orchestrator.provider")
            if orch_prov_node and orch_prov_node.value:
                orch_provider = orch_prov_node.value

            # Check is_using_default to preserve "Let Obra choose" intent
            orch_model_node = self._config_tree.get_node("llm.orchestrator.model")
            if orch_model_node:
                if orch_model_node.is_using_default:
                    orch_model = "default"
                elif orch_model_node.value:
                    orch_model = orch_model_node.value
                raw_orch_model = orch_model

            # Implementation config
            impl_prov_node = self._config_tree.get_node("llm.implementation.provider")
            if impl_prov_node and impl_prov_node.value:
                impl_provider = impl_prov_node.value

            # Check is_using_default to preserve "Let Obra choose" intent
            impl_model_node = self._config_tree.get_node("llm.implementation.model")
            if impl_model_node:
                if impl_model_node.is_using_default:
                    impl_model = "default"
                elif impl_model_node.value:
                    impl_model = impl_model_node.value
                raw_impl_model = impl_model

            # When model is 'per-tier', derive from tier settings (Menu 2)
            # Use the 'high' tier as the representative model for Menu 1
            if orch_model == "per-tier":
                high_tier = self._config_tree.get_node("llm.orchestrator.tiers.high")
                if high_tier:
                    if high_tier.is_using_default:
                        orch_model = "default"
                    elif high_tier.value:
                        orch_model = self._extract_tier_model(high_tier.value, orch_provider)

            if impl_model == "per-tier":
                high_tier = self._config_tree.get_node("llm.implementation.tiers.high")
                if high_tier:
                    if high_tier.is_using_default:
                        impl_model = "default"
                    elif high_tier.value:
                        impl_model = self._extract_tier_model(high_tier.value, impl_provider)

            # Reasoning (role-level thinking defaults)
            orch_reasoning_node = self._config_tree.get_node("llm.orchestrator.thinking_level")
            if orch_reasoning_node and orch_reasoning_node.value:
                orch_reasoning = self._sanitize_reasoning_value(str(orch_reasoning_node.value))
            impl_reasoning_node = self._config_tree.get_node("llm.implementation.thinking_level")
            if impl_reasoning_node and impl_reasoning_node.value:
                impl_reasoning = self._sanitize_reasoning_value(str(impl_reasoning_node.value))

        # Sanitize model values (handle delegation values and validate)
        orch_model_sanitized = self._sanitize_model_value(orch_model, orch_provider)
        impl_model_sanitized = self._sanitize_model_value(impl_model, impl_provider)

        if is_debug_enabled():
            log_action(
                "_mount_simple_llm_view",
                f"RAW config: orch={orch_provider}/{raw_orch_model}, impl={impl_provider}/{raw_impl_model}",
            )
            log_action(
                "_mount_simple_llm_view",
                f"SANITIZED: orch={orch_provider}/{orch_model_sanitized}, impl={impl_provider}/{impl_model_sanitized}",
            )

        # Build authoritative inheritance context for preview panel.
        _, preview_orch_tiers = self._get_orchestrator_tier_config()
        _, preview_impl_tiers = self._get_implementation_tier_config()
        preview_orch_reasoning_tiers = self._get_tier_reasoning_config("orchestrator")
        preview_impl_reasoning_tiers = self._get_tier_reasoning_config("implementation")
        role_configs = self._get_role_configs()

        # Create and mount the view
        view = SimpleLLMView(
            orchestrator_provider=orch_provider,
            orchestrator_model=orch_model_sanitized,
            orchestrator_reasoning=orch_reasoning,
            orchestrator_tiers=preview_orch_tiers,
            orchestrator_reasoning_tiers=preview_orch_reasoning_tiers,
            implementation_provider=impl_provider,
            implementation_model=impl_model_sanitized,
            implementation_reasoning=impl_reasoning,
            implementation_tiers=preview_impl_tiers,
            implementation_reasoning_tiers=preview_impl_reasoning_tiers,
            role_configs=role_configs,
            classes="custom-view",
            id="simple-llm-view",
        )
        main = self.query_one("#main", Container)
        main.mount(view)
        view.focus()

    def on_simple_llmview_changed(self, event: SimpleLLMView.Changed) -> None:
        """Handle Simple LLM view configuration changes.

        Menu 1 (Simple) cascades down to Menu 2 (Moderate) and Menu 3 (Custom).
        When a single model is selected, all tiers are set to that model.
        """
        from .debug import is_debug_enabled, log_action

        if is_debug_enabled():
            log_action(
                "on_simple_llmview_changed",
                f"RECEIVED Changed event: orch={event.orchestrator_provider}/{event.orchestrator_model}, "
                f"impl={event.implementation_provider}/{event.implementation_model}",
            )

        if not self._config_tree:
            return

        # Update Menu 1 config paths
        self._config_tree.set_value("llm.orchestrator.provider", event.orchestrator_provider)
        self._config_tree.set_value("llm.orchestrator.model", event.orchestrator_model)
        self._config_tree.set_value("llm.orchestrator.thinking_level", event.orchestrator_reasoning)
        self._config_tree.set_value("llm.implementation.provider", event.implementation_provider)
        self._config_tree.set_value("llm.implementation.model", event.implementation_model)
        self._config_tree.set_value(
            "llm.implementation.thinking_level", event.implementation_reasoning
        )

        # CASCADE to Menu 2: Set all tiers to the selected model
        for tier in ("fast", "medium", "high"):
            self._config_tree.set_value(
                f"llm.orchestrator.tiers.{tier}",
                {"model": event.orchestrator_model, "thinking_level": event.orchestrator_reasoning},
            )
            self._config_tree.set_value(
                f"llm.implementation.tiers.{tier}",
                {
                    "model": event.implementation_model,
                    "thinking_level": event.implementation_reasoning,
                },
            )

        # CASCADE to Menu 3: Update CustomLLMView if mounted
        self._cascade_to_custom_view(
            orchestrator_provider=event.orchestrator_provider,
            orchestrator_tiers={
                "fast": event.orchestrator_model,
                "medium": event.orchestrator_model,
                "high": event.orchestrator_model,
            },
            orchestrator_reasoning_tiers={
                "fast": event.orchestrator_reasoning,
                "medium": event.orchestrator_reasoning,
                "high": event.orchestrator_reasoning,
            },
            implementation_provider=event.implementation_provider,
            implementation_tiers={
                "fast": event.implementation_model,
                "medium": event.implementation_model,
                "high": event.implementation_model,
            },
            implementation_reasoning_tiers={
                "fast": event.implementation_reasoning,
                "medium": event.implementation_reasoning,
                "high": event.implementation_reasoning,
            },
        )

        # Update status bar to show pending changes
        self._update_status_bar()

    def _mount_moderate_llm_view(self) -> None:
        """Mount the Moderate LLM configuration view with tier-based config values."""
        from obra.config.explorer.debug import is_debug_enabled, log_view_mount

        # Get authoritative values from config tree.
        orch_provider, orch_tiers = self._get_orchestrator_tier_config()
        impl_provider, impl_tiers = self._get_implementation_tier_config()
        orch_reasoning_tiers = self._get_tier_reasoning_config("orchestrator")
        impl_reasoning_tiers = self._get_tier_reasoning_config("implementation")
        role_configs = self._get_role_configs()

        # Create and mount the view
        if is_debug_enabled():
            log_view_mount(
                "ModerateLLMView",
                {
                    "orch_provider": orch_provider,
                    "orch_tiers": orch_tiers,
                    "orch_reasoning_tiers": orch_reasoning_tiers,
                    "impl_provider": impl_provider,
                    "impl_tiers": impl_tiers,
                    "impl_reasoning_tiers": impl_reasoning_tiers,
                },
            )

        view = ModerateLLMView(
            orchestrator_provider=orch_provider,
            orchestrator_tiers=orch_tiers if orch_tiers else None,
            orchestrator_reasoning_tiers=orch_reasoning_tiers if orch_reasoning_tiers else None,
            implementation_provider=impl_provider,
            implementation_tiers=impl_tiers if impl_tiers else None,
            implementation_reasoning_tiers=impl_reasoning_tiers if impl_reasoning_tiers else None,
            role_configs=role_configs,
            classes="custom-view",
            id="moderate-llm-view",
        )
        main = self.query_one("#main", Container)
        main.mount(view)
        view.focus()

    def on_moderate_llmview_changed(self, event: ModerateLLMView.Changed) -> None:
        """Handle Moderate LLM view configuration changes.

        Menu 2 (Moderate) cascades down to Menu 3 (Custom).
        Tier-based models propagate to per-action inheritance.
        """
        from obra.config.explorer.debug import (
            is_debug_enabled,
            log_message_received,
            log_pending_changes,
        )

        if is_debug_enabled():
            log_message_received(
                "on_moderate_llmview_changed",
                {
                    "orch_provider": event.orchestrator_provider,
                    "orch_tiers": event.orchestrator_tiers,
                    "impl_provider": event.implementation_provider,
                    "impl_tiers": event.implementation_tiers,
                },
            )

        if not self._config_tree:
            if is_debug_enabled():
                log_pending_changes(None, "handler_early_exit")
            return

        # Update Menu 2 config: providers and tiers
        self._config_tree.set_value("llm.orchestrator.provider", event.orchestrator_provider)
        self._config_tree.set_value(
            "llm.orchestrator.thinking_level", event.orchestrator_reasoning_tiers.get("medium")
        )
        self._config_tree.set_value("llm.implementation.provider", event.implementation_provider)
        self._config_tree.set_value(
            "llm.implementation.thinking_level", event.implementation_reasoning_tiers.get("medium")
        )

        # Update orchestrator tiers
        for tier, model in event.orchestrator_tiers.items():
            self._config_tree.set_value(
                f"llm.orchestrator.tiers.{tier}",
                {
                    "model": model,
                    "thinking_level": event.orchestrator_reasoning_tiers.get(tier, "medium"),
                },
            )

        # Update implementation tiers
        for tier, model in event.implementation_tiers.items():
            self._config_tree.set_value(
                f"llm.implementation.tiers.{tier}",
                {
                    "model": model,
                    "thinking_level": event.implementation_reasoning_tiers.get(tier, "medium"),
                },
            )

        # CASCADE to Menu 3: Update CustomLLMView if mounted
        self._cascade_to_custom_view(
            orchestrator_provider=event.orchestrator_provider,
            orchestrator_tiers=event.orchestrator_tiers,
            orchestrator_reasoning_tiers=event.orchestrator_reasoning_tiers,
            implementation_provider=event.implementation_provider,
            implementation_tiers=event.implementation_tiers,
            implementation_reasoning_tiers=event.implementation_reasoning_tiers,
        )

        # Debug: log pending changes after handler completes
        if is_debug_enabled():
            log_pending_changes(self._config_tree, "after_moderate_handler")

        # Update status bar to show pending changes
        self._update_status_bar()

    def _mount_custom_llm_view(self) -> None:
        """Mount the Custom LLM configuration view with current config values.

        Menu 3 (Custom) inherits tier configs from Menu 2 (Moderate).
        Each action has a profile.tier mapping that resolves to actual models.
        """
        from .widgets.llm_custom_view import DEFAULT_ACTION_CONFIG

        # Get tier configs from Menu 2 (the parent in the hierarchy)
        orch_provider, orch_tiers = self._get_orchestrator_tier_config()
        impl_provider, impl_tiers = self._get_implementation_tier_config()
        orch_reasoning_tiers = self._get_tier_reasoning_config("orchestrator")
        impl_reasoning_tiers = self._get_tier_reasoning_config("implementation")

        # Build role configs from current llm.roles config
        role_configs = {}
        for role_id, action_config in DEFAULT_ACTION_CONFIG.items():
            # Check if there's an explicit config for this role
            role_node = None
            if self._config_tree:
                role_node = self._config_tree.get_node(f"llm.roles.{role_id}")

            role_provider = None
            model = None
            reasoning_level = None
            profile = action_config["profile"]
            tier = action_config["tier"]

            if role_node and role_node.value:
                if isinstance(role_node.value, str):
                    # Simple profile reference
                    profile = role_node.value
                elif isinstance(role_node.value, dict):
                    # Dict config with potential overrides
                    profile = role_node.value.get("profile", profile)
                    tier = role_node.value.get("tier", tier)
                    role_provider = role_node.value.get("provider")
                    model = role_node.value.get("model")
                    reasoning_level = role_node.value.get("reasoning_level")

            role_configs[role_id] = RoleConfig(
                role_id=role_id,
                profile=profile,
                tier=tier,
                provider=role_provider,
                model=model,
                reasoning_level=reasoning_level,
            )

        # Create and mount the view with tier configs for inheritance resolution
        view = CustomLLMView(
            current_configs=role_configs,
            orchestrator_provider=orch_provider,
            orchestrator_tiers=orch_tiers,
            orchestrator_reasoning_tiers=orch_reasoning_tiers,
            implementation_provider=impl_provider,
            implementation_tiers=impl_tiers,
            implementation_reasoning_tiers=impl_reasoning_tiers,
            classes="custom-view",
            id="custom-llm-view",
        )

        main = self.query_one("#main", Container)
        main.mount(view)
        view.focus()

    def _get_orchestrator_tier_config(self) -> tuple[str, dict[str, str]]:
        """Get orchestrator provider and tier models from config.

        Returns:
            Tuple of (provider, {fast: model, medium: model, high: model})
        """
        provider = "anthropic"
        tiers = {"fast": "default", "medium": "default", "high": "default"}

        if self._config_tree:
            # Provider
            prov_node = self._config_tree.get_node("llm.orchestrator.provider")
            if prov_node and prov_node.value:
                provider = prov_node.value

            # If Menu 1 sets an explicit role model, reflect it for default tiers
            # so Menu 2/4 display remains consistent with role-level selection.
            role_model_override = None
            role_model_node = self._config_tree.get_node("llm.orchestrator.model")
            if role_model_node and role_model_node.value and not role_model_node.is_using_default:
                sanitized_model = self._sanitize_model_value(str(role_model_node.value), provider)
                if sanitized_model != "default":
                    role_model_override = sanitized_model

            # Tiers - check is_using_default to preserve "Let Obra choose" intent
            for tier in ("fast", "medium", "high"):
                tier_node = self._config_tree.get_node(f"llm.orchestrator.tiers.{tier}")
                if tier_node:
                    if tier_node.is_using_default:
                        tiers[tier] = role_model_override or "default"
                    elif tier_node.value:
                        tiers[tier] = self._extract_tier_model(tier_node.value, provider)

        return provider, tiers

    def _get_implementation_tier_config(self) -> tuple[str, dict[str, str]]:
        """Get implementation provider and tier models from config.

        Returns:
            Tuple of (provider, {fast: model, medium: model, high: model})
        """
        provider = "anthropic"
        tiers = {"fast": "default", "medium": "default", "high": "default"}

        if self._config_tree:
            # Provider
            prov_node = self._config_tree.get_node("llm.implementation.provider")
            if prov_node and prov_node.value:
                provider = prov_node.value

            # If Menu 1 sets an explicit role model, reflect it for default tiers
            # so Menu 2/4 display remains consistent with role-level selection.
            role_model_override = None
            role_model_node = self._config_tree.get_node("llm.implementation.model")
            if role_model_node and role_model_node.value and not role_model_node.is_using_default:
                sanitized_model = self._sanitize_model_value(str(role_model_node.value), provider)
                if sanitized_model != "default":
                    role_model_override = sanitized_model

            # Tiers - check is_using_default to preserve "Let Obra choose" intent
            for tier in ("fast", "medium", "high"):
                tier_node = self._config_tree.get_node(f"llm.implementation.tiers.{tier}")
                if tier_node:
                    if tier_node.is_using_default:
                        tiers[tier] = role_model_override or "default"
                    elif tier_node.value:
                        tiers[tier] = self._extract_tier_model(tier_node.value, provider)

        return provider, tiers

    def _get_tier_reasoning_config(self, role: str) -> dict[str, str]:
        """Get per-tier reasoning from config for a role."""
        fallback = self._get_role_reasoning_level(role)
        reasoning_tiers = {"fast": fallback, "medium": fallback, "high": fallback}

        if not self._config_tree:
            return reasoning_tiers

        for tier in ("fast", "medium", "high"):
            tier_node = self._config_tree.get_node(f"llm.{role}.tiers.{tier}")
            if not tier_node:
                continue
            if tier_node.is_using_default:
                reasoning_tiers[tier] = fallback
            elif tier_node.value is not None:
                reasoning_tiers[tier] = self._extract_tier_reasoning(tier_node.value, fallback)

        return reasoning_tiers

    def _get_role_reasoning_level(self, role: str) -> str:
        """Get role-level reasoning (thinking_level) from config."""
        default_level = "medium"
        if self._config_tree:
            node = self._config_tree.get_node(f"llm.{role}.thinking_level")
            if node and node.value:
                return self._sanitize_reasoning_value(str(node.value))
        return default_level

    def _get_role_configs(self) -> dict[str, dict[str, Any]]:
        """Get Menu 3 role configs (per-action overrides).

        Returns:
            Dict mapping action_id to role config dict with optional
            provider, model, reasoning_level overrides.
        """
        from obra.config.explorer.widgets.llm_custom_view import DEFAULT_ACTION_CONFIG

        role_configs: dict[str, dict[str, Any]] = {}

        if self._config_tree:
            for action_id in DEFAULT_ACTION_CONFIG:
                node = self._config_tree.get_node(f"llm.roles.{action_id}")
                if node and node.value and isinstance(node.value, dict):
                    role_configs[action_id] = node.value

        return role_configs

    def _cascade_to_custom_view(
        self,
        orchestrator_provider: str | None = None,
        orchestrator_tiers: dict[str, str] | None = None,
        orchestrator_reasoning_tiers: dict[str, str] | None = None,
        implementation_provider: str | None = None,
        implementation_tiers: dict[str, str] | None = None,
        implementation_reasoning_tiers: dict[str, str] | None = None,
    ) -> None:
        """Cascade tier config changes to Menu 3 (Custom) if mounted.

        Called when Menu 1 or Menu 2 changes to propagate new tier settings
        down to the Custom view's "Inherit" labels.

        Args:
            orchestrator_provider: New orchestrator provider
            orchestrator_tiers: New orchestrator tier models
            orchestrator_reasoning_tiers: New orchestrator tier reasoning
            implementation_provider: New implementation provider
            implementation_tiers: New implementation tier models
            implementation_reasoning_tiers: New implementation tier reasoning
        """
        try:
            custom_view = self.query_one("#custom-llm-view", CustomLLMView)
            custom_view.update_tier_configs(
                orchestrator_provider=orchestrator_provider,
                orchestrator_tiers=orchestrator_tiers,
                orchestrator_reasoning_tiers=orchestrator_reasoning_tiers,
                implementation_provider=implementation_provider,
                implementation_tiers=implementation_tiers,
                implementation_reasoning_tiers=implementation_reasoning_tiers,
            )
        except Exception:
            # View not mounted, cascade will happen when it's mounted
            pass

    def on_custom_llmview_changed(self, event: CustomLLMView.Changed) -> None:
        """Handle Custom LLM view configuration changes.

        Menu 3 (Custom) is the source of truth. Updates llm.roles.* config paths
        based on role configurations including profile, tier, and explicit overrides.
        """
        if not self._config_tree:
            return

        for role_id, role_cfg in event.role_configs.items():
            # Check if there are any explicit overrides
            has_overrides = (
                role_cfg.provider is not None
                or role_cfg.model is not None
                or role_cfg.reasoning_level is not None
            )

            if not has_overrides:
                # No overrides - save as profile.tier reference for inheritance
                # Format: {profile: "orchestrator", tier: "high"}
                self._config_tree.set_value(
                    f"llm.roles.{role_id}",
                    {"profile": role_cfg.profile, "tier": role_cfg.tier},
                )
            else:
                # Has explicit overrides - save full config
                role_value: dict[str, str] = {
                    "profile": role_cfg.profile,
                    "tier": role_cfg.tier,
                }
                if role_cfg.provider:
                    role_value["provider"] = role_cfg.provider
                if role_cfg.model:
                    role_value["model"] = role_cfg.model
                if role_cfg.reasoning_level:
                    role_value["reasoning_level"] = role_cfg.reasoning_level

                self._config_tree.set_value(f"llm.roles.{role_id}", role_value)

        # Update status bar to show pending changes
        self._update_status_bar()

    def _mount_pipeline_options_view(self) -> None:
        """Mount the Pipeline Options view with current config values.

        Passes both Menu 2 tier configs and Menu 3 role configs so Pipeline
        Options can display accurate inherited model info per phase.
        """
        from obra.config.explorer.metadata import PHASE_SETTINGS

        # Collect current values for all pipeline settings
        current_values: dict[str, Any] = {}

        if self._config_tree:
            for phase_settings in PHASE_SETTINGS.values():
                for setting_path in phase_settings:
                    node = self._config_tree.get_node(setting_path)
                    if node and node.value is not None:
                        current_values[setting_path] = node.value

        # Get tier configs from Menu 2 (Moderate) for model inheritance display
        orch_provider, orch_tiers = self._get_orchestrator_tier_config()
        impl_provider, impl_tiers = self._get_implementation_tier_config()
        orch_reasoning_tiers = self._get_tier_reasoning_config("orchestrator")
        impl_reasoning_tiers = self._get_tier_reasoning_config("implementation")

        # Get role configs from Menu 3 (Custom) for per-action overrides
        role_configs = self._get_role_configs()

        # Create and mount the view with tier configs and role configs
        view = PipelineOptionsView(
            current_values=current_values,
            orchestrator_provider=orch_provider,
            orchestrator_tiers=orch_tiers,
            orchestrator_reasoning_tiers=orch_reasoning_tiers,
            implementation_provider=impl_provider,
            implementation_tiers=impl_tiers,
            implementation_reasoning_tiers=impl_reasoning_tiers,
            role_configs=role_configs,
            classes="custom-view",
            id="pipeline-options-view",
        )
        main = self.query_one("#main", Container)
        main.mount(view)
        view.focus()

    def on_pipeline_options_view_changed(self, event: PipelineOptionsView.Changed) -> None:
        """Handle Pipeline Options view configuration changes.

        Updates the config tree with the new setting value.
        """
        if not self._config_tree:
            return

        # Update the config value
        self._config_tree.set_value(event.path, event.value)

        # Update status bar to show pending changes
        self._update_status_bar()

    def _mount_specialized_agents_view(self) -> None:
        """Mount the Specialized Agents view with current config values.

        Agents inherit from the Review role configuration (llm.roles.review).
        The Review role can have explicit overrides or point to a profile
        (orchestrator or implementation) whose settings are then used.
        """
        from obra.config.explorer.widgets.specialized_agents_view import (
            AGENTS,
            LLM_FIELDS,
        )

        current_values: dict[str, Any] = {}
        review_provider = "anthropic"
        review_thinking = "medium"
        review_tiers: dict[str, str] = {}

        if self._config_tree:
            # Get the Review role configuration
            review_role_node = self._config_tree.get_node("llm.roles.review")
            review_role_config = review_role_node.value if review_role_node else None

            # Determine which profile the Review role uses (default: implementation)
            review_profile = "implementation"
            review_tier = "high"  # Default tier for review
            explicit_provider = None
            explicit_model = None
            explicit_reasoning = None

            if isinstance(review_role_config, dict):
                # Review role has configuration - check for profile and overrides
                review_profile = review_role_config.get("profile", "implementation")
                review_tier = review_role_config.get("tier", "high")
                explicit_provider = review_role_config.get("provider")
                explicit_model = review_role_config.get("model")
                explicit_reasoning = review_role_config.get("reasoning_level")
            elif isinstance(review_role_config, str):
                # Simple profile reference (e.g., "implementation")
                review_profile = review_role_config

            # Get provider from the Review role's profile (or explicit override)
            if explicit_provider:
                review_provider = explicit_provider
            else:
                profile_prov_node = self._config_tree.get_node(f"llm.{review_profile}.provider")
                if profile_prov_node and profile_prov_node.value:
                    review_provider = profile_prov_node.value

            # Get thinking level from the Review role's profile (or explicit override)
            if explicit_reasoning:
                review_thinking = explicit_reasoning
            else:
                profile_thinking_node = self._config_tree.get_node(
                    f"llm.{review_profile}.thinking_level"
                )
                if profile_thinking_node and profile_thinking_node.value:
                    review_thinking = profile_thinking_node.value

            # Get tier models from the Review role's profile
            # Use the shared tier resolver so Menu 5 stays consistent with
            # Menu 1 explicit role-model selections and Menu 2/4 displays.
            if review_profile == "orchestrator":
                resolved_provider, resolved_tiers = self._get_orchestrator_tier_config()
            else:
                resolved_provider, resolved_tiers = self._get_implementation_tier_config()

            # Preserve explicit provider override from llm.roles.review when present.
            if not explicit_provider:
                review_provider = resolved_provider
            review_tiers = resolved_tiers

            # If Review role has explicit model override, use that as the default tier
            if explicit_model:
                review_tiers[review_tier] = explicit_model

            # Collect current values for all agent config paths
            for agent in AGENTS:
                node = self._config_tree.get_node(agent.enabled_path)
                if node and node.value is not None:
                    current_values[agent.enabled_path] = node.value

                if agent.llm_capable and agent.llm_config_path:
                    for field in LLM_FIELDS:
                        path = f"{agent.llm_config_path}.{field}"
                        node = self._config_tree.get_node(path)
                        if node and node.value is not None:
                            current_values[path] = node.value

            # Collect SenseCheck pipeline stage values
            from obra.config.explorer.widgets.specialized_agents_view import (
                SENSECHECK_FRAMEWORK_PATH,
                SENSECHECK_PIPELINE_STAGES,
            )

            framework_node = self._config_tree.get_node(SENSECHECK_FRAMEWORK_PATH)
            if framework_node and framework_node.value is not None:
                current_values[SENSECHECK_FRAMEWORK_PATH] = framework_node.value

            for stage in SENSECHECK_PIPELINE_STAGES:
                node = self._config_tree.get_node(stage["config_path"])
                if node and node.value is not None:
                    current_values[stage["config_path"]] = node.value

        view = SpecializedAgentsView(
            current_values=current_values,
            implementation_provider=review_provider,
            implementation_tiers=review_tiers if review_tiers else None,
            implementation_thinking_level=review_thinking,
            review_tier=review_tier,
            classes="custom-view",
            id="specialized-agents-view",
        )
        main = self.query_one("#main", Container)
        main.mount(view)
        view.focus()

    def on_specialized_agents_view_changed(self, event: SpecializedAgentsView.Changed) -> None:
        """Handle Specialized Agents view configuration changes.

        Updates the config tree with the new agent enabled state.
        Uses canonical config paths (features.quality_automation.agents.*.enabled).
        """
        if not self._config_tree:
            return

        # Update the config value using canonical path
        self._config_tree.set_value(event.config_path, event.enabled)

        # Update status bar to show pending changes
        self._update_status_bar()

    def on_specialized_agents_view_llm_changed(
        self, event: SpecializedAgentsView.LLMChanged
    ) -> None:
        """Handle Specialized Agents LLM config changes."""
        if not self._config_tree:
            return

        self._config_tree.set_value(event.config_path, event.value)
        self._update_status_bar()

    def _mount_validation_tooling_view(self) -> None:
        """Mount the Validation & Tooling view with current config values."""
        from pathlib import Path

        from obra.config.explorer.widgets.validation_tooling_view import (
            DISCOVERY_SETTINGS,
            STORY0_SETTINGS,
        )

        # Collect current values for automation_mode, story0, and discovery settings
        current_values: dict[str, Any] = {}

        if self._config_tree:
            # Get automation_mode (top-level config)
            automation_node = self._config_tree.get_node("automation_mode")
            if automation_node and automation_node.value is not None:
                current_values["automation_mode"] = automation_node.value

            # Get all story0 settings
            for setting_path in STORY0_SETTINGS:
                node = self._config_tree.get_node(setting_path)
                if node and node.value is not None:
                    current_values[setting_path] = node.value

            # Get all discovery settings
            for setting_path in DISCOVERY_SETTINGS:
                node = self._config_tree.get_node(setting_path)
                if node and node.value is not None:
                    current_values[setting_path] = node.value

        # Determine working_dir: check if .obra exists in cwd
        cwd = Path.cwd()
        working_dir: Path | None = None
        if (cwd / ".obra").exists():
            working_dir = cwd

        # Get LLM config for tooling discovery
        llm_config = self._local_config.get("llm", {})
        # Use orchestrator config if available
        if "orchestrator" in llm_config:
            llm_config = llm_config.get("orchestrator", {})

        # Create and mount the view
        view = ValidationToolingView(
            current_values=current_values,
            working_dir=working_dir,
            llm_config=llm_config if llm_config else None,
            classes="custom-view",
            id="validation-tooling-view",
        )
        main = self.query_one("#main", Container)
        main.mount(view)
        view.focus()

    def on_validation_tooling_view_changed(self, event: ValidationToolingView.Changed) -> None:
        """Handle Validation & Tooling view configuration changes.

        Updates the config tree with the new setting value.
        Handles nested tool command paths specially.
        """
        if not self._config_tree:
            return

        # Handle tool command paths specially (may not exist in tree)
        if event.path.startswith("fix.verification.tools."):
            # These are dynamic paths that may not exist in the tree
            # Track them in pending_changes directly
            if event.path not in self._config_tree.pending_changes:
                self._config_tree.pending_changes[event.path] = (None, event.value)
            else:
                original_old = self._config_tree.pending_changes[event.path][0]
                self._config_tree.pending_changes[event.path] = (
                    original_old,
                    event.value,
                )
        else:
            # Update the config value normally
            self._config_tree.set_value(event.path, event.value)

        # Update status bar to show pending changes
        self._update_status_bar()

    def _mount_debug_advanced_view(self) -> None:
        """Mount the Debug & Advanced view with current config values."""
        from obra.config.explorer.widgets.debug_advanced_view import ALL_DEBUG_SETTINGS

        current_values: dict[str, Any] = {}

        if self._config_tree:
            for setting_path in ALL_DEBUG_SETTINGS:
                node = self._config_tree.get_node(setting_path)
                if node and node.value is not None:
                    current_values[setting_path] = node.value

        view = DebugAdvancedView(
            current_values=current_values,
            classes="custom-view",
            id="debug-advanced-view",
        )
        main = self.query_one("#main", Container)
        main.mount(view)
        view.focus()

    def on_debug_advanced_view_changed(self, event: DebugAdvancedView.Changed) -> None:
        """Handle Debug & Advanced view configuration changes."""
        if not self._config_tree:
            return

        self._config_tree.set_value(event.path, event.value)
        self._update_status_bar()

    # --- Navigation Action Methods (keyboard shortcuts) ---

    def action_nav_simple_llm(self) -> None:
        """Navigate to Simple LLM view."""
        self._navigate_with_dirty_check("simple_llm")

    def action_nav_moderate_llm(self) -> None:
        """Navigate to Moderate LLM view."""
        self._navigate_with_dirty_check("moderate_llm")

    def action_nav_custom_llm(self) -> None:
        """Navigate to Custom LLM view."""
        self._navigate_with_dirty_check("custom_llm")

    def action_nav_personas(self) -> None:
        """Navigate to Personas view."""
        self._navigate_with_dirty_check("personas")

    def action_nav_pipeline(self) -> None:
        """Navigate to Pipeline Options view."""
        self._navigate_with_dirty_check("pipeline")

    def action_nav_agents(self) -> None:
        """Navigate to Specialized Agents view."""
        self._navigate_with_dirty_check("agents")

    def action_nav_validation(self) -> None:
        """Navigate to Validation & Tooling view."""
        self._navigate_with_dirty_check("validation")

    def action_nav_debug_advanced(self) -> None:
        """Navigate to Debug & Advanced view."""
        self._navigate_with_dirty_check("debug_advanced")

    def action_nav_full_config(self) -> None:
        """Navigate to Full Config (tree view)."""
        self._navigate_with_dirty_check("full_config")

    def action_nav_menu(self) -> None:
        """Return to navigation menu."""
        self._navigate_with_dirty_check("menu")

    def action_back_or_quit(self) -> None:
        """Contextual back/quit handler (q key).

        - In subview: go back to menu (prompts if dirty)
        - On menu: quit the app

        This follows the Lazygit pattern where 'q' means "I'm done with this level".
        """
        if self._current_view == "menu":
            # On menu - quit the app
            self.exit()
        else:
            # In subview - check dirty state before leaving
            self._navigate_with_dirty_check(target="menu")

    def action_safe_back(self) -> None:
        """Safe back handler (Escape key) - never quits.

        Goes back to menu from any subview.
        On menu, does nothing (safe - won't accidentally quit).
        """
        if self._current_view != "menu":
            self._navigate_with_dirty_check(target="menu")

    def _get_current_view_widget(self) -> SaveableViewMixin | None:
        """Get the current view widget if it supports save/discard.

        Returns:
            The current view widget if it implements SaveableViewMixin, None otherwise.
        """
        view_id_map = {
            "simple_llm": "#simple-llm-view",
            "moderate_llm": "#moderate-llm-view",
            "custom_llm": "#custom-llm-view",
            "pipeline": "#pipeline-options-view",
            "agents": "#specialized-agents-view",
            "validation": "#validation-tooling-view",
            "debug_advanced": "#debug-advanced-view",
            "personas": "#persona-view",
        }
        widget_id = view_id_map.get(self._current_view)
        if not widget_id:
            return None

        try:
            widget = self.query_one(widget_id)
            if isinstance(widget, SaveableViewMixin):
                return widget
        except Exception:
            pass
        return None

    def _navigate_with_dirty_check(self, target: str) -> None:
        """Navigate to target, prompting if current view is dirty.

        Args:
            target: Navigation target ('menu' or a view name)
        """
        current_widget = self._get_current_view_widget()

        # If no saveable widget or not dirty, navigate immediately
        if current_widget is None or not current_widget.is_dirty():
            if target == "menu":
                self._show_menu()
            else:
                self._show_view(target)
            return

        # Show unsaved changes modal
        def handle_result(action: UnsavedAction | None) -> None:
            if action == UnsavedAction.SAVE:
                # Save current view's changes then navigate
                self._save_current_view()
                if target == "menu":
                    self._show_menu()
                else:
                    self._show_view(target)
            elif action == UnsavedAction.DISCARD:
                # Discard view's internal state
                if current_widget is not None:
                    current_widget.discard_changes()

                # Reload config from disk to reset all in-memory changes
                # This ensures no stale state leaks between screens
                from obra.config.loaders import load_layered_config

                self._local_config, self._origins, _ = load_layered_config(include_defaults=True)
                self._base_tree = dict_to_config_tree(
                    self._local_config, self._server_config, origins=self._origins
                )
                self._config_tree = self._build_view_tree()
                self._update_status_bar()

                # Then navigate
                if target == "menu":
                    self._show_menu()
                else:
                    self._show_view(target)
            # CANCEL: do nothing, stay in current view

        # Count pending changes from the current view
        pending_count = len(current_widget.get_pending_changes())
        self.push_screen(UnsavedChangesModal(pending_count), handle_result)

    def on_tree_node_highlighted(self, event: Tree.NodeHighlighted) -> None:
        """Update description panel when tree selection changes."""
        node_data = event.node.data
        description_panel = self.query_one("#description", DescriptionPanel)

        if node_data is not None:
            description_panel.update_description(
                node_data.description,
                node_data.path or node_data.key,
            )
        else:
            description_panel.update_description(None, "")

    def on_config_tree_view_value_changed(self, _event: ConfigTreeView.ValueChanged) -> None:
        """Update status bar when a config value changes."""
        self._update_status_bar()

    def _build_view_tree(self) -> ConfigTree:
        if self._base_tree is None:
            return dict_to_config_tree(self._local_config, self._server_config)

        local_root = self._base_tree.local_root
        server_root = self._base_tree.server_root

        if self._active_tag_filter:
            tag = self._active_tag_filter
            local_filtered = filter_tree_by_predicate(
                local_root,
                lambda n: tag in n.tags,
            )
            server_filtered = filter_tree_by_predicate(
                server_root,
                lambda n: tag in n.tags,
            )
            if local_filtered is None:
                local_filtered = ConfigNode(
                    key="Local Settings",
                    path="local",
                    value=None,
                    value_type=ValueType.OBJECT,
                    source=local_root.source,
                    tier=SettingTier.STANDARD,
                    description="Local settings (no matches)",
                )
            if server_filtered is None:
                server_filtered = ConfigNode(
                    key="[Server] SaaS - Read Only",
                    path="server",
                    value=None,
                    value_type=ValueType.OBJECT,
                    source=server_root.source,
                    tier=SettingTier.STANDARD,
                    description="Server settings (no matches)",
                )
            local_root = local_filtered
            server_root = server_filtered

        if self._view_mode == "pipeline":
            pipeline_root = build_pipeline_root(local_root)
            pipeline_root.key = "Local Settings"
            local_root = pipeline_root

        return ConfigTree(
            local_root=local_root,
            server_root=server_root,
            pending_changes=self._base_tree.pending_changes,
        )

    def on_config_tree_view_edit_requested(self, event: ConfigTreeView.EditRequested) -> None:
        """Open edit modal when a non-boolean node is selected."""
        self._open_edit_modal(event.node)

    def _open_edit_modal(self, node: Any) -> None:
        """Open the edit modal for a config node.

        Args:
            node: ConfigNode to edit
        """
        from .models import ConfigNode

        if not isinstance(node, ConfigNode):
            return

        def handle_result(result: Any) -> None:
            if result is not None and self._config_tree is not None:
                # Apply the change (set_value cascades internally for model settings)
                self._config_tree.set_value(node.path, result)

                # Refresh the changed node first
                tree_view = self.query_one("#tree", ConfigTreeView)
                tree_view.refresh_node(node.path)

                # Refresh any cascaded nodes (for model cascade)
                cascade_paths = self._config_tree.get_cascade_paths(node.path)
                for cascade_path in cascade_paths:
                    tree_view.refresh_node(cascade_path)

                # Auto-update tier models when role provider changes
                if node.path in (
                    "llm.orchestrator.provider",
                    "llm.implementation.provider",
                ):
                    self._auto_update_tiers_for_provider(node.path, result)
                    # Refresh the entire tier section to show updated fast/medium/high values
                    role_path = node.path.rsplit(".provider", 1)[0]
                    tier_section_path = f"{role_path}.tiers"
                    tree_view.refresh_subtree(tier_section_path)
                # Update status bar
                self._update_status_bar()

        self.push_screen(EditModal(node, self._config_tree), handle_result)

    def _auto_update_tiers_for_provider(self, provider_path: str, new_provider: str) -> None:
        """Auto-update tier models and git settings when role provider changes.

        When a user changes a role's provider, automatically update the tier models
        (fast/medium/high) to match the new provider's defaults.

        For OpenAI Codex: Auto-enable llm.git.skip_check for Codex trust compatibility.

        Args:
            provider_path: Path to the role provider field (e.g., "llm.orchestrator.provider")
            new_provider: New provider value (e.g., "openai")
        """
        if not self._config_tree:
            return

        # Import here to avoid circular dependency
        from obra.config.llm import PROVIDER_TIER_DEFAULTS

        # Get the provider's default tier models
        tier_defaults = PROVIDER_TIER_DEFAULTS.get(new_provider, {})
        if not tier_defaults:
            return

        # Determine the tier path prefix from role path
        # e.g., "llm.orchestrator.provider" -> "llm.orchestrator.tiers"
        role_path = provider_path.rsplit(".provider", 1)[0]
        tier_section_path = f"{role_path}.tiers"

        # Update fast/medium/high to the provider's defaults
        changes_made = []
        for tier_name, default_model in tier_defaults.items():
            tier_path = f"{tier_section_path}.{tier_name}"
            # Only update if the node exists in the tree
            tier_node = self._config_tree.get_node(tier_path)
            if tier_node:
                self._config_tree.set_value(tier_path, default_model)
                changes_made.append(f"{tier_name}={default_model}")

        # Notify user about the auto-update
        if changes_made:
            provider_display = new_provider.capitalize()
            tier_list = ", ".join(changes_made)
            section_name = "orchestrator" if "orchestrator" in role_path else "implementation"
            self.notify(
                f"Updated {section_name} tiers to match {provider_display}: {tier_list}",
                severity="information",
                timeout=5,
            )

        # Auto-enable OpenAI Codex compatibility flags.
        # This "heals" the config when switching to OpenAI and aligns with runtime enforcement.
        if new_provider == "openai":
            git_skip_node = self._config_tree.get_node("llm.git.skip_check")
            if git_skip_node and git_skip_node.value is not True:
                self._config_tree.set_value("llm.git.skip_check", True)
            approval_node = self._config_tree.get_node("llm.codex.approval_mode")
            if approval_node and approval_node.value != "full-auto":
                self._config_tree.set_value("llm.codex.approval_mode", "full-auto")
            sandbox_node = self._config_tree.get_node("llm.codex.bypass_sandbox")
            if sandbox_node and sandbox_node.value is not True:
                self._config_tree.set_value("llm.codex.bypass_sandbox", True)
            self.notify(
                "OpenAI selected: forcing git.skip_check, codex.approval_mode=full-auto, "
                "and codex.bypass_sandbox=true for Codex CLI compatibility.",
                severity="warning",
                timeout=8,
            )

    def _update_status_bar(self) -> None:
        """Update the status bar with current pending changes count and persona."""
        if self._config_tree is None:
            return

        status_bar = self.query_one("#status", StatusBar)

        # Detect current persona
        persona = self._detect_active_persona()

        status_bar.update_status(
            pending_count=self._config_tree.pending_count,
            preset=persona,
            connected=self._connected,
            view_mode=self._view_mode,
            tag_filter=self._active_tag_filter,
            persona=persona,
        )

    def _detect_active_persona(self) -> str:
        """Detect which persona matches the current configuration.

        Returns:
            Persona name if matched, 'Custom' if no match.
        """
        if self._config_tree is None:
            return "Custom"

        from .widgets.preset_picker import detect_active_persona

        # Get current provider
        provider = "anthropic"
        provider_node = self._config_tree.get_node("llm.orchestrator.provider")
        if provider_node and provider_node.value:
            provider = provider_node.value

        # Collect current feature values
        current_features: dict[str, Any] = {}
        feature_paths = [
            "planning.scaffolded.enabled",
            "planning.scaffolded.always_on",
            "review.agents.max_workers",
            "features.quality_automation.agents.rca_agent.enabled",
            "features.quality_automation.agents.security_audit.enabled",
        ]
        for path in feature_paths:
            node = self._config_tree.get_node(path)
            if node and node.value is not None:
                current_features[path] = node.value

        # Collect current role model assignments
        current_roles: dict[str, str] = {}
        role_names = ["derive", "examine", "revise", "execute", "fix", "review"]
        for role in role_names:
            node = self._config_tree.get_node(f"llm.roles.{role}")
            if node and node.value:
                if isinstance(node.value, str):
                    current_roles[role] = node.value
                elif isinstance(node.value, dict) and "model" in node.value:
                    current_roles[role] = node.value["model"]

        return detect_active_persona(current_features, current_roles, provider)

    async def action_quit(self) -> None:
        """Quit the application, checking for unsaved changes."""
        if self._config_tree and self._config_tree.has_pending_changes:
            # Show unsaved changes modal
            self._show_unsaved_changes_modal()
        else:
            self.exit()

    def _show_unsaved_changes_modal(self) -> None:
        """Show the unsaved changes modal and handle the result."""
        pending_count = self._config_tree.pending_count if self._config_tree else 0

        def handle_result(action: UnsavedAction | None) -> None:
            if action == UnsavedAction.SAVE:
                # Save changes then quit
                self.action_save()
                # Check if save succeeded (no more pending changes)
                if self._config_tree and not self._config_tree.has_pending_changes:
                    self.exit()
                # If save failed, stay in app (errors already notified)
            elif action == UnsavedAction.DISCARD:
                # Discard changes and quit
                if self._config_tree:
                    self._config_tree.discard_changes()
                self.exit()
            # CANCEL: do nothing, stay in app

        self.push_screen(UnsavedChangesModal(pending_count), handle_result)

    def action_save(self) -> None:
        """Save current view's changes to config.

        Per-screen save: only saves changes made in the current menu screen.
        Shows a preview modal before saving to let user review changes.
        """
        from obra.config.explorer.debug import (
            is_debug_enabled,
            log_action,
        )

        if is_debug_enabled():
            log_action("save_requested", f"current_view={self._current_view}")

        # For full_config view, use the legacy global save behavior
        if self._current_view == "full_config":
            self._save_full_config()
            return

        # For personas view, use global save since it directly modifies config tree
        # (PersonaView is "instant apply" - changes go to config tree immediately)
        if self._current_view == "personas":
            self._save_full_config()
            return

        # Per-screen save: get current view widget
        current_widget = self._get_current_view_widget()
        if current_widget is None:
            self.notify("No saveable view active")
            return

        if not current_widget.is_dirty():
            self.notify("No changes to save")
            return

        # Get the pending changes from the current view
        pending_changes = current_widget.get_pending_changes()
        if not pending_changes:
            self.notify("No changes to save")
            return

        # Show preview modal before saving
        def handle_save_preview(confirmed: bool | None) -> None:
            if not confirmed:
                return  # User cancelled

            self._save_current_view()

        self.push_screen(
            SavePreviewModal(pending_changes=pending_changes),
            handle_save_preview,
        )

    def _save_full_config(self) -> None:
        """Save all pending changes in full config view (legacy global save)."""
        from obra.config.explorer.debug import (
            is_debug_enabled,
            log_action,
            log_pending_changes,
        )

        if is_debug_enabled():
            log_action("save_full_config_requested")
            log_pending_changes(self._config_tree, "at_save_request")

        if not self._config_tree or not self._config_tree.has_pending_changes:
            if is_debug_enabled():
                log_action("save_rejected", "no pending changes")
            self.notify("No changes to save")
            return

        # Show preview modal before saving
        def handle_save_preview(confirmed: bool | None) -> None:
            if not confirmed:
                return  # User cancelled

            self._perform_save()

        self.push_screen(
            SavePreviewModal(pending_changes=self._config_tree.pending_changes),
            handle_save_preview,
        )

    def _save_current_view(self) -> None:
        """Save only the current view's changes."""
        current_widget = self._get_current_view_widget()
        if current_widget is None or not current_widget.is_dirty():
            return

        pending_changes = current_widget.get_pending_changes()
        if not pending_changes:
            return

        # Extract just new values for saving
        # pending_changes is dict[path, (old_value, new_value)]
        new_values = {path: new_val for path, (_, new_val) in pending_changes.items()}

        # Apply changes to config tree
        if self._config_tree:
            for path, value in new_values.items():
                self._config_tree.set_value(path, value)

        # Save to disk
        try:
            self._save_local_changes(new_values)
            # Mark the view as saved (updates its snapshot)
            current_widget.mark_saved()
            # Clear these changes from the config tree's pending list
            if self._config_tree:
                for path in pending_changes:
                    if path in self._config_tree.pending_changes:
                        del self._config_tree.pending_changes[path]
            self._update_status_bar()
            self.notify(
                f"Saved {len(pending_changes)} change{'s' if len(pending_changes) != 1 else ''}"
            )
        except Exception as e:
            self.notify(f"Save failed: {e}", severity="error")

    def _perform_save(self) -> None:
        """Actually perform the save operation after user confirms."""
        from obra.config.explorer.debug import (
            is_debug_enabled,
            log_action,
            log_tree_rebuild,
        )

        if is_debug_enabled():
            log_action("perform_save", "starting")

        if not self._config_tree:
            return

        # Get local and server changes separately
        local_changes = self._config_tree.get_local_changes()
        server_changes = self._config_tree.get_server_changes()

        if is_debug_enabled():
            log_action(
                "perform_save",
                f"local={len(local_changes)}, server={len(server_changes)}",
            )

        saved_count = 0
        errors: list[str] = []

        # Save local changes
        if local_changes:
            try:
                self._save_local_changes(local_changes)
                saved_count += len(local_changes)
            except Exception as e:
                errors.append(f"Local save failed: {e}")

        # Save server changes
        if server_changes:
            try:
                self._save_server_changes(server_changes)
                saved_count += len(server_changes)
            except Exception as e:
                errors.append(f"Server save failed: {e}")

        # Clear pending changes on success
        if not errors:
            self._config_tree.clear_pending()
            try:
                from obra.config.loaders import load_layered_config

                if is_debug_enabled():
                    log_tree_rebuild("after_save: reloading config")

                local_config, origins, warnings = load_layered_config(include_defaults=True)
                if warnings:
                    for warning in warnings:
                        logger.warning("Config layer warning: %s", warning)
                self._local_config = local_config
                self._origins = origins
                self._base_tree = dict_to_config_tree(
                    self._local_config,
                    self._server_config,
                    origins=self._origins,
                )
                self._config_tree = self._build_view_tree()
                self._rebuild_tree_view()
            except Exception as exc:
                logger.warning("Failed to refresh layered config after save: %s", exc)
                self._update_status_bar()
            self.notify(f"Saved {saved_count} change{'s' if saved_count != 1 else ''}")
        else:
            # Partial save - report errors
            error_msg = "; ".join(errors)
            self.notify(f"Save errors: {error_msg}", severity="error")

    def _save_local_changes(self, changes: dict[str, Any]) -> None:
        """Save local config changes to ~/.obra/config-layers/01-user.yaml.

        Args:
            changes: Dictionary of path -> new_value pairs

        Raises:
            Exception: If save fails
        """
        # Load current config
        current_config = config.load_config()

        # Apply changes (paths are dot-notation like "llm.orchestrator.provider")
        for path, value in changes.items():
            self._set_nested_value(current_config, path, value)

        # Save updated config
        config.save_config(current_config)

        # Update our local copy
        self._local_config = current_config

    def _set_nested_value(self, d: dict[str, Any], path: str, value: Any) -> None:
        """Set a value in a nested dictionary using dot-notation path.

        Args:
            d: Dictionary to modify
            path: Dot-notation path like "llm.orchestrator.provider"
            value: Value to set
        """
        parts = path.split(".")
        current = d

        # Navigate/create nested structure
        for part in parts[:-1]:
            if part not in current:
                current[part] = {}
            current = current[part]

        # Set the final value
        current[parts[-1]] = value

    def _save_server_changes(self, changes: dict[str, Any]) -> None:
        """Save server config changes via API client.

        Args:
            changes: Dictionary of path -> new_value pairs

        Raises:
            RuntimeError: If no API client configured
            Exception: If API call fails
        """
        if self._api_client is None:
            msg = (
                "No API client configured - cannot save server changes. You may be in offline mode."
            )
            raise RuntimeError(msg)

        if not self._connected:
            msg = "Server connection unavailable. Please check your network and try again."
            raise RuntimeError(msg)

        # Convert changes to overrides format for API
        overrides = {}
        for path, value in changes.items():
            # Strip any "Server Settings (SaaS)." prefix if present
            clean_path = path
            for prefix in ["Server Settings (SaaS).", "resolved."]:
                if clean_path.startswith(prefix):
                    clean_path = clean_path[len(prefix) :]
            overrides[clean_path] = value

        try:
            # Call API to update config
            result = self._api_client.update_user_config(overrides=overrides)

            # Update our server config copy
            self._server_config = result
        except Exception as e:
            # Mark as disconnected on API failure
            self._set_offline_mode()
            msg = f"Server save failed: {e}"
            raise RuntimeError(msg) from e

    def _set_offline_mode(self) -> None:
        """Switch to offline mode when server becomes unavailable."""
        if self._connected:
            self._connected = False
            self._update_status_bar()
            # Add offline banner if not already present
            try:
                self.query_one("#offline-banner", OfflineBanner)
            except Exception:
                # Banner not present, add it after header
                header = self.query_one(Header)
                self.mount(OfflineBanner(id="offline-banner"), after=header)

    async def action_discard(self) -> None:
        """Discard all pending (unsaved) changes and reload from disk."""
        if not self._config_tree:
            return

        # Check if there are pending changes
        if not self._config_tree.has_pending_changes:
            self.notify("No pending changes to discard")
            return

        pending_count = self._config_tree.pending_count

        # Discard pending changes in the model
        self._config_tree.discard_changes()

        # Reload config from disk to ensure we're in sync
        from obra.config.loaders import load_layered_config

        self._local_config, self._origins, warnings = load_layered_config(include_defaults=True)
        if warnings:
            for warning in warnings:
                logger.warning("Config layer warning: %s", warning)

        self._base_tree = dict_to_config_tree(
            self._local_config,
            self._server_config,
            origins=self._origins,
        )
        self._config_tree = self._build_view_tree()

        # Refresh the tree view
        self._rebuild_tree_view()

        # Update status bar
        self._update_status_bar()

        self.notify(f"Discarded {pending_count} pending change(s)")

    async def action_reset_to_defaults(self) -> None:
        """Reset ALL settings to bundled defaults (preserves auth/account).

        This is a soft reset - wipes all config settings but keeps:
        - Auth tokens (stays logged in)
        - Account info (email, uid, etc.)
        - Terms acceptance (no need to re-accept)

        Equivalent to 'obra config reset --yes' from CLI.
        """
        from obra.config import save_config
        from obra.config.explorer.utils import load_default_config_schema

        # Fields to preserve (auth/account/terms)
        auth_preserve_fields = {
            "terms_accepted",
            "firebase_uid",
            "user_email",
            "auth_token",
            "refresh_token",
            "auth_provider",
            "auth_timestamp",
            "token_expires_at",
            "display_name",
            "user_id",
        }

        # Load bundled defaults
        defaults = load_default_config_schema()
        if not defaults:
            self.notify("Could not load bundled defaults", severity="error")
            return

        # Extract auth fields from current config to preserve
        current_config = config.load_config()
        preserved = {}
        for field in auth_preserve_fields:
            if field in current_config:
                preserved[field] = current_config[field]

        # Merge preserved auth into defaults
        new_config = {**defaults, **preserved}

        # Save the new config to disk
        save_config(new_config)

        from obra.config.loaders import load_layered_config

        self._local_config, self._origins, warnings = load_layered_config(include_defaults=True)
        if warnings:
            for warning in warnings:
                logger.warning("Config layer warning: %s", warning)

        self._base_tree = dict_to_config_tree(
            self._local_config,
            self._server_config,
            origins=self._origins,
        )
        self._config_tree = self._build_view_tree()

        # Refresh the tree view
        self._rebuild_tree_view()

        # Update status bar
        self._update_status_bar()

        preserved_count = len(preserved)
        self.notify(
            f"Reset to defaults (preserved {preserved_count} auth fields)",
            severity="information",
        )

    def action_search(self) -> None:
        """Enter search/filter mode."""
        search_bar = self.query_one("#search", SearchBar)
        search_bar.activate()

    def on_search_bar_search_applied(self, event: SearchBar.SearchApplied) -> None:
        """Handle search submission."""
        self._apply_search_filter(event.query)

    def on_search_bar_search_changed(self, event: SearchBar.SearchChanged) -> None:
        """Handle live search filtering as user types."""
        self._apply_search_filter(event.query)

    def on_search_bar_search_cleared(self, _event: SearchBar.SearchCleared) -> None:
        """Handle search cancellation - show all nodes."""
        self._clear_search_filter()
        # Re-focus tree
        try:
            tree_view = self.query_one("#tree", ConfigTreeView)
            tree_view.focus()
        except Exception:
            pass

    def on_quick_actions_bar_action_clicked(self, event: QuickActionsBar.ActionClicked) -> None:
        """Handle quick action button clicks."""
        if event.action == "llm":
            self.action_quick_llm()
        elif event.action == "preset":
            self.action_quick_preset()
        elif event.action == "features":
            self.action_quick_features()

    def _apply_search_filter(self, query: str) -> None:
        """Apply search filter to the tree.

        Args:
            query: Search query to filter by
        """
        if not self._config_tree or not query:
            return

        if query.startswith("tag:"):
            tag = query.split("tag:", 1)[1].strip()
            if tag:
                self._active_tag_filter = tag
                self._config_tree = self._build_view_tree()
                self._rebuild_tree_view()
                self.notify(f"Filtered by tag: {tag}")
            return

        # Find matching nodes in both local and server trees
        local_matches = find_nodes_by_path_pattern(self._config_tree.local_root, query)
        server_matches = find_nodes_by_path_pattern(self._config_tree.server_root, query)

        all_matches = local_matches + server_matches

        if all_matches:
            # Expand and scroll to first match
            tree_view = self.query_one("#tree", ConfigTreeView)
            first_match = all_matches[0]
            if first_match.path:
                tree_view.scroll_to_path(first_match.path)

            self.notify(f"Found {len(all_matches)} matching settings")
        else:
            self.notify("No matching settings found", severity="warning")

    def _clear_search_filter(self) -> None:
        """Clear search filter and restore normal view."""
        if self._active_tag_filter:
            self._active_tag_filter = None
            self._config_tree = self._build_view_tree()
            self._rebuild_tree_view()
            self.notify("Tag filter cleared")

    def action_toggle_view(self) -> None:
        """Toggle between tree and pipeline views."""
        if self._view_mode == "tree":
            self._view_mode = "pipeline"
        else:
            self._view_mode = "tree"
        self._config_tree = self._build_view_tree()
        self._rebuild_tree_view()
        self.notify(f"View: {self._view_mode}")

    def _rebuild_tree_view(self) -> None:
        """Rebuild the tree widget with the current view tree."""
        if self._config_tree is None:
            return

        try:
            tree_view = self.query_one("#tree", ConfigTreeView)
            tree_view.config_tree = self._config_tree
            tree_view.refresh_tree()
            self._update_status_bar()
        except Exception:
            pass
        else:
            return

        tree_container = self.query_one("#tree-container", Vertical)
        tree_view = ConfigTreeView(self._config_tree, id="tree")
        tree_container.mount(tree_view)
        self._update_status_bar()

    def action_help(self) -> None:
        """Show help overlay with all keybindings."""
        self.push_screen(HelpOverlay())

    def action_show_shortcuts(self) -> None:
        """Show keyboard shortcuts help."""
        shortcuts = (
            "Navigation Shortcuts (by complexity):\n"
            "  0: Personas      4: Pipeline\n"
            "  1: LLM Simple    5: Agents\n"
            "  2: LLM Moderate  6: Validation\n"
            "  3: LLM Custom    7: Full Config\n"
            "  9: Return to Menu\n"
            "\n"
            "Back/Quit:\n"
            "  q: Back (in view) / Quit (on menu)\n"
            "  Esc: Back (safe, never quits)\n"
            "\n"
            "Actions: R=Reset All  s=Save  u=Discard"
        )
        # Get notification timeout from config (CHORE-CONFIG-DEFAULTS-001-E3 S3)
        timeout_s = get_config_explorer_config()["notification_timeout_s"]
        self.notify(shortcuts, title="Keyboard Shortcuts", timeout=timeout_s)

    def action_quick_llm(self) -> None:
        """Launch LLM change wizard."""
        # Get current LLM settings from local config
        llm_config = self._local_config.get("llm", {})
        orchestrator = llm_config.get("orchestrator", {})
        implementation = llm_config.get("implementation", {})

        wizard = LLMWizard(
            current_orchestrator_provider=orchestrator.get("provider", "anthropic"),
            current_orchestrator_model=orchestrator.get("model", "default"),
            current_implementation_provider=implementation.get("provider", "anthropic"),
            current_implementation_model=implementation.get("model", "default"),
        )

        def handle_result(result: LLMSelection | None) -> None:
            if result is None:
                return  # User cancelled

            # Apply the changes to config tree
            if self._config_tree is None:
                return

            roles = ["orchestrator", "implementation"] if result.role == "both" else [result.role]

            for role in roles:
                provider_path = f"llm.{role}.provider"
                model_path = f"llm.{role}.model"

                # Set provider and model
                self._config_tree.set_value(provider_path, result.provider)
                self._config_tree.set_value(model_path, result.model)

                # Auto-update tiers and git settings for the new provider
                self._auto_update_tiers_for_provider(provider_path, result.provider)

            # Refresh the tree display
            tree_view = self.query_one("#tree", ConfigTreeView)
            tree_view.refresh_tree()

            # Update status bar
            self._update_status_bar()

            role_text = "orchestrator and implementation" if result.role == "both" else result.role
            self.notify(
                f"LLM changed: {role_text} -> {result.provider}/{result.model}",
                severity="information",
            )

        self.push_screen(wizard, handle_result)

    def _apply_persona_to_config(self, result: PresetSelection) -> int:
        """Apply persona LLM profiles and features to config tree.

        Cascades: Persona -> Menu 1 -> Menu 2 -> Menu 3 -> Menu 4

        Args:
            result: Persona selection result with features and llm_profiles

        Returns:
            Number of config changes made
        """
        if self._config_tree is None:
            return 0

        changes_made = 0

        # Apply LLM profiles
        if result.llm_profiles:
            from obra.config.llm import PROVIDER_TIER_DEFAULTS

            orch = result.llm_profiles.get("orchestrator", {})
            impl = result.llm_profiles.get("implementation", {})

            # Set Menu 1 (Simple) config values and cascade to Menu 2 tiers
            for profile, cfg in [("orchestrator", orch), ("implementation", impl)]:
                if cfg:
                    # Get provider - use specified or keep current
                    provider = cfg.get("provider")
                    if not provider:
                        # Keep user's current provider
                        prov_node = self._config_tree.get_node(f"llm.{profile}.provider")
                        provider = prov_node.value if prov_node and prov_node.value else "anthropic"

                    model = cfg.get("model", "default")

                    # Resolve "tier:xxx" syntax to actual model name
                    if isinstance(model, str) and model.startswith("tier:"):
                        tier_name = model[5:]  # e.g., "fast" from "tier:fast"
                        tier_defaults = PROVIDER_TIER_DEFAULTS.get(provider, {})
                        model = (
                            tier_defaults.get(tier_name, "default") if tier_defaults else "default"
                        )

                    self._config_tree.set_value(f"llm.{profile}.provider", provider)
                    self._config_tree.set_value(f"llm.{profile}.model", model)
                    changes_made += 2
                    for tier in ("fast", "medium", "high"):
                        self._config_tree.set_value(f"llm.{profile}.tiers.{tier}", model)
                        changes_made += 1

            # CASCADE to Menu 3: Update CustomLLMView if mounted
            self._cascade_to_custom_view(
                orchestrator_provider=orch.get("provider") if orch else None,
                orchestrator_tiers=(
                    {t: orch.get("model", "default") for t in ("fast", "medium", "high")}
                    if orch
                    else None
                ),
                implementation_provider=impl.get("provider") if impl else None,
                implementation_tiers=(
                    {t: impl.get("model", "default") for t in ("fast", "medium", "high")}
                    if impl
                    else None
                ),
            )

        # Apply feature toggles
        # Note: feature paths in personas are the actual config paths (e.g., "automation_mode",
        # "planning.scaffolded.enabled") - do NOT prefix with "features."
        for feature_path, value in result.features.items():
            self._config_tree.set_value(feature_path, value)
            changes_made += 1

        return changes_made

    def action_quick_preset(self, from_navigation: bool = False) -> None:
        """Launch persona picker.

        Args:
            from_navigation: True if launched from nav menu (returns to menu on cancel)
        """
        current_preset = get_preset_name(self._server_config) or "genie"

        # Get current provider from config for tier resolution
        current_provider = "anthropic"
        if self._config_tree:
            provider_node = self._config_tree.get_node("llm.orchestrator.provider")
            if provider_node and provider_node.value:
                current_provider = provider_node.value

        picker = PresetPicker(
            current_preset=current_preset,
            current_provider=current_provider,
        )

        def handle_result(result: PresetSelection | None) -> None:
            # If launched from navigation and cancelled, return to menu
            if result is None:
                if from_navigation:
                    self._show_menu()
                return

            # Apply persona to config tree
            if self._config_tree is None:
                return

            changes_made = self._apply_persona_to_config(result)

            # Apply resolved LLM models to llm.roles.*
            for role, model in result.llm_models.items():
                role_path = f"llm.roles.{role}"
                self._config_tree.set_value(role_path, model)
                changes_made += 1

            # Refresh the tree display if currently showing full config
            if self._current_view == "full_config":
                try:
                    tree_view = self.query_one("#tree", ConfigTreeView)
                    tree_view.refresh_tree()
                except Exception:
                    pass

            # Update status bar
            self._update_status_bar()

            # Return to menu after applying persona if launched from navigation
            if from_navigation:
                self._show_menu()

            self.notify(
                f"Persona applied: {result.preset_name} ({changes_made} changes)",
                severity="information",
            )

        self.push_screen(picker, handle_result)

    def action_quick_features(self) -> None:
        """Jump to features section in the tree."""
        tree_view = self.query_one("#tree", ConfigTreeView)

        # Try to find the features section - could be under server config
        # Look for nodes with "features" in their path
        features_paths = [
            "features",
            "resolved.features",
            "Server Settings (SaaS).resolved.features",
            "Server Settings (SaaS).features",
        ]

        for path in features_paths:
            node = tree_view.find_node_by_path(path)
            if node is not None:
                # Expand and scroll to this node
                tree_view.scroll_to_path(path)
                self.notify("Jumped to Features section")
                return

        # Fallback: try to find any node with "features" in it
        if self._config_tree is not None:
            matches = find_nodes_by_path_pattern(self._config_tree.server_root, "features")
            if matches:
                first_match = matches[0]
                if first_match.path:
                    tree_view.scroll_to_path(first_match.path)
                    self.notify("Jumped to Features section")
                    return

        self.notify("Features section not found", severity="warning")


def run_explorer(
    local_config: dict[str, Any] | None = None,
    server_config: dict[str, Any] | None = None,
    initial_section: str | None = None,
    api_client: Any | None = None,
    origins: dict[str, str] | None = None,
    debug: bool = False,
    max_runtime_hours: float = 1.0,
) -> None:
    """Run the Configuration Explorer application.

    Args:
        local_config: Local configuration dictionary
        server_config: Server configuration dictionary
        initial_section: Section to expand initially
        api_client: API client for server operations
        origins: Origins map for layered config
        debug: Enable debug logging to ~/.obra/logs/config-explorer.log
        max_runtime_hours: Maximum runtime before auto-termination (default: 1 hour)
    """
    from obra.utils.process_guard import ProcessGuard

    # Acquire process guard to prevent duplicates and enable watchdogs
    guard = ProcessGuard(
        "config",
        max_runtime_hours=max_runtime_hours,
        cpu_threshold_percent=90.0,
        cpu_violation_minutes=5,
    )

    if not guard.acquire():
        import sys

        print("Config explorer already running. Kill it first or use: obra procs --kill")
        sys.exit(1)

    try:
        if debug:
            from obra.config.explorer.debug import enable_debug_logging

            session_id, log_file = enable_debug_logging()
            print(f"Debug session: {session_id}")
            print(f"Log file: {log_file}")
            print()

        app = ConfigExplorerApp(
            local_config=local_config,
            server_config=server_config,
            initial_section=initial_section,
            api_client=api_client,
            origins=origins,
        )
        app.run()
    finally:
        guard.release()


if __name__ == "__main__":
    # Allow running directly for testing
    run_explorer(
        local_config={
            "llm": {
                "orchestrator": {"provider": "anthropic", "model": "default"},
            }
        },
        server_config={
            "preset": "beta-tester",
            "resolved": {
                "features": {"budgets": {"enabled": True}},
            },
        },
    )
