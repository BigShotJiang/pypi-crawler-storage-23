"""Intent generation and conversion prompts.

This package contains prompts for intent processing:
- generation: Intent generation and project classification
- conversion: Intent to plan conversion
"""

from __future__ import annotations

# Define lazy-loaded exports
_SUBMODULE_EXPORTS = {
    # generation.py exports
    "build_intent_generation_prompt": ".generation",
    "build_project_classification_prompt": ".generation",
    # conversion.py exports
    "build_intent_to_plan_prompt": ".conversion",
}

__all__ = list(_SUBMODULE_EXPORTS.keys())


def __getattr__(name: str):
    """PEP 562 lazy loading for submodule exports."""
    if name in _SUBMODULE_EXPORTS:
        from importlib import import_module

        module_name = _SUBMODULE_EXPORTS[name]
        module = import_module(module_name, package=__name__)
        return getattr(module, name)
    msg = f"module {__name__!r} has no attribute {name!r}"
    raise AttributeError(msg)


def __dir__():
    """List available exports."""
    return __all__
