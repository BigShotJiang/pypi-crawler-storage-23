"""HTTP response handler with status code abstraction.

Provides semantic HTTP status handling using the stdlib http.HTTPStatus enum,
eliminating magic number comparisons throughout the codebase.
"""

from http import HTTPStatus
from typing import Protocol

from obra.exceptions import APIError


class ResponseLike(Protocol):
    status_code: int


# Transient errors: temporary failures that may succeed if retried
TRANSIENT_STATUSES: frozenset[HTTPStatus] = frozenset(
    {
        HTTPStatus.REQUEST_TIMEOUT,  # 408
        HTTPStatus.TOO_EARLY,  # 425
        HTTPStatus.TOO_MANY_REQUESTS,  # 429
        HTTPStatus.INTERNAL_SERVER_ERROR,  # 500
        HTTPStatus.BAD_GATEWAY,  # 502
        HTTPStatus.SERVICE_UNAVAILABLE,  # 503
        HTTPStatus.GATEWAY_TIMEOUT,  # 504
    }
)


class ResponseHandler:
    """Wrapper for HTTP responses with semantic status code handling.

    Uses http.HTTPStatus enum instead of magic number comparisons.

    Attributes:
        response: The wrapped HTTP response object
        status: HTTPStatus enum value for the response status code

    Example:
        handler = ResponseHandler(response)
        if handler.is_success:
            return handler.response.json()
        if handler.is_transient_error:
            raise RetryableError()
        handler.raise_for_status()
    """

    def __init__(self, response: ResponseLike) -> None:
        """Initialize ResponseHandler with a response object.

        Args:
            response: HTTP response object with status_code attribute
        """
        self.response = response
        self.status = HTTPStatus(response.status_code)

    @property
    def is_success(self) -> bool:
        """Check if response indicates success (2xx status code)."""
        return HTTPStatus.OK <= self.status < HTTPStatus.MULTIPLE_CHOICES

    @property
    def is_transient_error(self) -> bool:
        """Check if response indicates a transient (retryable) error."""
        return self.status in TRANSIENT_STATUSES

    def raise_for_status(
        self,
        error_map: dict[HTTPStatus, type[Exception]] | None = None,
    ) -> None:
        """Raise an exception if the response indicates an error.

        Args:
            error_map: Optional mapping of HTTPStatus to exception types.
                       If the status code matches a key, that exception is raised.
                       Otherwise, APIError is raised for non-success responses.

        Raises:
            APIError: For non-success responses not in error_map
            Custom exception: If status matches a key in error_map
        """
        if self.is_success:
            return

        if error_map and self.status in error_map:
            error_class = error_map[self.status]
            # Try to call from_response if available, otherwise just instantiate
            if hasattr(error_class, "from_response"):
                raise error_class.from_response(self.response)
            msg = f"HTTP {self.status.value}: {self.status.phrase}"
            raise error_class(msg)

        # Default to APIError
        try:
            body = self.response.text
        except Exception:
            body = ""

        msg = f"HTTP {self.status.value}: {self.status.phrase}"
        raise APIError(
            msg,
            status_code=self.status.value,
            response_body=body,
        )
