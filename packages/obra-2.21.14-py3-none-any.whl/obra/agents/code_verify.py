"""CodeVerify agent for deterministic plan verification checks."""

from __future__ import annotations

import json
import logging
import re
import time
from collections.abc import Callable
from concurrent.futures import ThreadPoolExecutor
from concurrent.futures import TimeoutError as FutureTimeoutError
from pathlib import Path
from typing import Any

from obra.agents.base import AgentIssue, AgentResult, BaseAgent
from obra.agents.code_verify_runner import VerificationSessionRunner
from obra.agents.dependency_graph import DependencyGraphValidator
from obra.agents.registry import register_agent
from obra.api.protocol import AgentType, Priority, ValidatorResult
from obra.config.loaders import get_code_verify_config, get_intent_thresholds_config
from obra.intent.detection import ProjectState, detect_project_state
from obra.prompts.agents import load_prompt

logger = logging.getLogger(__name__)

_READ_ONLY_TOOLS = ["Read", "Grep", "Glob"]
_GROUNDING_CHECKS = ["C1", "C2", "C3", "C4", "C5"]
_COMPLIANCE_CHECKS = ["C6", "C7", "C8"]
_PRIORITY_ORDER = {
    Priority.P0: 0,
    Priority.P1: 1,
    Priority.P2: 2,
    Priority.P3: 3,
}


def _extract_plan_ref_from_issue(issue: AgentIssue) -> str:
    metadata = issue.metadata if isinstance(issue.metadata, dict) else {}
    plan_ref = str(metadata.get("plan_ref", "")).strip()
    if plan_ref:
        return plan_ref

    match = re.search(r"S\d+(?:\.T\d+(?:\.\d+)?)?", issue.id)
    if match:
        return match.group(0)
    return ""


def persist_verification_annotations(
    findings: list[AgentIssue],
    plan_items: list[dict[str, Any]],
) -> int:
    """Persist non-blocking verification findings into plan item context.

    Parameter Contracts (ADR-042):
        - findings: list of AgentIssue objects
        - plan_items: list of plan-item dictionaries
    """
    if not findings or not plan_items:
        return 0

    id_map: dict[str, dict[str, Any]] = {}
    for item in plan_items:
        if not isinstance(item, dict):
            continue
        item_id = str(item.get("id", "")).strip()
        if item_id:
            id_map[item_id] = item

    annotations_written = 0
    for issue in findings:
        if issue.priority not in {Priority.P1, Priority.P2}:
            continue

        plan_ref = _extract_plan_ref_from_issue(issue)
        if not plan_ref:
            continue

        item = id_map.get(plan_ref)
        if item is None:
            continue

        context = item.get("context")
        if not isinstance(context, dict):
            context = {}
            item["context"] = context

        notes = context.get("verification_notes")
        if not isinstance(notes, list):
            notes = []
            context["verification_notes"] = notes

        notes.append(
            {
                "severity": issue.priority.name,
                "check": issue.dimension,
                "description": issue.description,
                "file": issue.file_path,
                "line": issue.line_number,
                "recommendation": issue.suggestion,
            }
        )
        annotations_written += 1

    return annotations_written


@register_agent(AgentType.CODE_VERIFY)
class CodeVerifyAgent(BaseAgent):
    """Plan verification agent (C1-C9 checks + finding annotations)."""

    agent_type = AgentType.CODE_VERIFY

    def __init__(
        self,
        working_dir: Path,
        llm_config: dict[str, Any] | None = None,
        log_event: Callable[..., None] | None = None,
    ) -> None:
        super().__init__(working_dir=working_dir, llm_config=llm_config, log_event=log_event)
        self._dependency_graph_validator = DependencyGraphValidator()
        self._runner = VerificationSessionRunner(
            working_dir=working_dir,
            llm_config=llm_config or {},
            log_event=log_event,
            trace_id=getattr(self, "_trace_id", None),
        )
        self._validator_result: ValidatorResult | None = None

    def get_validator_result(self) -> ValidatorResult | None:
        """Get the latest validator result emitted by analyze()."""
        return self._validator_result

    def analyze(
        self,
        item_id: str,
        changed_files: list[str] | None = None,
        timeout_ms: int | None = None,
        plan_items: list[dict[str, Any]] | None = None,
        exploration_context: dict[str, Any] | None = None,
    ) -> AgentResult:
        """Analyze plan integrity using C1-C9 verification checks.

        Parameter Contracts (ADR-042):
            - item_id: non-empty string
            - timeout_ms: positive integer (resolved from config when None)
        """
        del changed_files
        self._validator_result = None

        timeout_ms = self._resolve_timeout_ms(timeout_ms)
        self._validate_analyze_params(item_id, timeout_ms)

        started = time.time()

        try:
            config = get_code_verify_config()
        except Exception as exc:
            logger.exception("CodeVerifyAgent failed to load configuration")
            return AgentResult(
                agent_type=self.agent_type,
                status="error",
                error=f"Failed to load code_verify config: {exc}",
                execution_time_ms=int((time.time() - started) * 1000),
            )

        checks = config.get("checks", {}) if isinstance(config, dict) else {}
        run_c9 = bool(checks.get("dependency_graph", True))
        run_grounding = bool(checks.get("grounding", False))
        run_compliance = bool(checks.get("compliance", False))
        parallel_calls = bool(config.get("parallel_calls", False))
        timeout_s = int(config.get("timeout_s", 900))
        max_findings = int(config.get("max_findings", 50))

        c9_findings: list[dict[str, Any]] = []
        call1_findings: list[dict[str, Any]] = []
        call2_findings: list[dict[str, Any]] = []
        call1_summary: dict[str, Any] = {}
        call2_summary: dict[str, Any] = {}
        c9_issues: list[AgentIssue] = []
        call1_issues: list[AgentIssue] = []
        call2_issues: list[AgentIssue] = []
        checks_run: list[str] = []

        if run_c9:
            c9_findings = self._dependency_graph_validator.validate(plan_items or [])
            for index, finding in enumerate(c9_findings, start=1):
                c9_issues.append(self._to_issue(finding, index))
            checks_run.append("C9")

        gating_metadata = self._resolve_gating_metadata(item_id=item_id, config=config)
        if gating_metadata["gating"] == "greenfield_story1_skip":
            merged_issues, truncated = self._merge_and_cap_issues(
                c9_issues,
                max_findings=max_findings,
            )
            status = "needs_revision" if self._has_blocking_issues(merged_issues) else "complete"
            result = AgentResult(
                agent_type=self.agent_type,
                status=status,
                issues=merged_issues,
                execution_time_ms=int((time.time() - started) * 1000),
                metadata={
                    "checks_run": checks_run,
                    "c9_findings": c9_findings,
                    "call1_findings": call1_findings,
                    "call2_findings": call2_findings,
                    "call1_summary": call1_summary,
                    "call2_summary": call2_summary,
                    "merged_count": len(merged_issues),
                    "truncated": truncated,
                    **gating_metadata,
                },
            )
            self._validator_result = self._build_validator_result(merged_issues, checks_run)
            return result

        call1_result: dict[str, Any] = {
            "status": "complete",
            "findings": [],
            "summary": {},
        }
        call2_result: dict[str, Any] = {
            "status": "complete",
            "findings": [],
            "summary": {},
        }

        if run_grounding and run_compliance and parallel_calls:
            parallel_results = self._run_parallel_verification_calls(
                plan_items=plan_items or [],
                exploration_context=exploration_context,
                timeout_s=timeout_s,
            )
            call1_result = parallel_results["call1"]
            call2_result = parallel_results["call2"]
        else:
            if run_grounding:
                call1_result = self._run_grounding_call(
                    plan_items=plan_items or [],
                    exploration_context=exploration_context,
                    timeout_s=timeout_s,
                )
            if run_compliance:
                call2_result = self._run_compliance_call(
                    plan_items=plan_items or [],
                    exploration_context=exploration_context,
                    timeout_s=timeout_s,
                )

        if run_grounding:
            maybe_error = self._build_failed_call_result(
                call_result=call1_result,
                fallback_issues=c9_issues,
                checks_run=checks_run,
                c9_findings=c9_findings,
                call1_findings=call1_findings,
                call2_findings=call2_findings,
                call1_summary=call1_summary,
                call2_summary=call2_summary,
                started=started,
                gating_metadata=gating_metadata,
            )
            if maybe_error is not None:
                return maybe_error
            call1_findings = call1_result["findings"]
            call1_summary = call1_result["summary"]
            checks_run.extend(_GROUNDING_CHECKS)
            for index, finding in enumerate(call1_findings, start=1):
                if isinstance(finding, dict):
                    call1_issues.append(self._to_verification_issue(finding, index))

        if run_compliance:
            maybe_error = self._build_failed_call_result(
                call_result=call2_result,
                fallback_issues=(c9_issues + call1_issues),
                checks_run=checks_run,
                c9_findings=c9_findings,
                call1_findings=call1_findings,
                call2_findings=call2_findings,
                call1_summary=call1_summary,
                call2_summary=call2_summary,
                started=started,
                gating_metadata=gating_metadata,
            )
            if maybe_error is not None:
                return maybe_error
            call2_findings = call2_result["findings"]
            call2_summary = call2_result["summary"]
            checks_run.extend(_COMPLIANCE_CHECKS)
            for index, finding in enumerate(call2_findings, start=1):
                if isinstance(finding, dict):
                    call2_issues.append(self._to_verification_issue(finding, index))

        merged_issues, truncated = self._merge_and_cap_issues(
            c9_issues + call1_issues + call2_issues,
            max_findings=max_findings,
        )
        status = "needs_revision" if self._has_blocking_issues(merged_issues) else "complete"

        annotation_count = persist_verification_annotations(merged_issues, plan_items or [])
        self._validator_result = self._build_validator_result(merged_issues, checks_run)

        return AgentResult(
            agent_type=self.agent_type,
            status=status,
            issues=merged_issues,
            execution_time_ms=int((time.time() - started) * 1000),
            metadata={
                "checks_run": checks_run,
                "c9_findings": c9_findings,
                "call1_findings": call1_findings,
                "call2_findings": call2_findings,
                "call1_summary": call1_summary,
                "call2_summary": call2_summary,
                "merged_count": len(merged_issues),
                "truncated": truncated,
                "annotations_written": annotation_count,
                **gating_metadata,
            },
        )

    def _run_parallel_verification_calls(
        self,
        *,
        plan_items: list[dict[str, Any]],
        exploration_context: Any,
        timeout_s: int,
    ) -> dict[str, dict[str, Any]]:
        with ThreadPoolExecutor(max_workers=2) as executor:
            call1_future = executor.submit(
                self._run_grounding_call,
                plan_items=plan_items,
                exploration_context=exploration_context,
                timeout_s=timeout_s,
            )
            call2_future = executor.submit(
                self._run_compliance_call,
                plan_items=plan_items,
                exploration_context=exploration_context,
                timeout_s=timeout_s,
            )
            call1_result = self._read_parallel_future(
                call1_future,
                timeout_s=timeout_s,
                label="Grounding",
            )
            call2_result = self._read_parallel_future(
                call2_future,
                timeout_s=timeout_s,
                label="Compliance",
            )

        return {"call1": call1_result, "call2": call2_result}

    def _read_parallel_future(
        self,
        future: Any,
        *,
        timeout_s: int,
        label: str,
    ) -> dict[str, Any]:
        try:
            result = future.result(timeout=timeout_s + 5)
            if not isinstance(result, dict):
                return {
                    "status": "error",
                    "error": f"{label} verification returned invalid payload",
                    "findings": [],
                    "summary": {},
                }
            return result
        except FutureTimeoutError:
            return {
                "status": "timeout",
                "error": f"{label} verification timed out",
                "findings": [],
                "summary": {},
            }
        except Exception as exc:
            logger.exception("CodeVerify %s parallel call failed", label.lower())
            return {
                "status": "error",
                "error": f"{label} verification failed: {exc}",
                "findings": [],
                "summary": {},
            }

    def _run_grounding_call(
        self,
        *,
        plan_items: list[dict[str, Any]],
        exploration_context: Any,
        timeout_s: int,
    ) -> dict[str, Any]:
        prompt = self._build_grounding_prompt(
            plan_items=plan_items,
            exploration_context=exploration_context,
        )
        return self._run_session(prompt=prompt, timeout_s=timeout_s, label="Grounding")

    def _run_compliance_call(
        self,
        *,
        plan_items: list[dict[str, Any]],
        exploration_context: Any,
        timeout_s: int,
    ) -> dict[str, Any]:
        prompt = self._build_compliance_prompt(
            plan_items=plan_items,
            exploration_context=exploration_context,
        )
        return self._run_session(prompt=prompt, timeout_s=timeout_s, label="Compliance")

    def _run_session(
        self,
        *,
        prompt: str,
        timeout_s: int,
        label: str,
    ) -> dict[str, Any]:
        try:
            result = self._runner.run_session(
                prompt=prompt,
                timeout_s=timeout_s,
                allowed_tools=_READ_ONLY_TOOLS,
            )
        except Exception as exc:
            logger.exception("CodeVerify %s check failed", label.lower())
            return {
                "status": "error",
                "error": f"{label} verification failed: {exc}",
                "findings": [],
                "summary": {},
            }

        if not isinstance(result, dict):
            return {
                "status": "error",
                "error": f"{label} verification returned invalid payload",
                "findings": [],
                "summary": {},
            }

        status = str(result.get("status", "complete"))
        if status in {"timeout", "error"}:
            return {
                "status": status,
                "error": str(result.get("error", f"{label} verification failed")),
                "findings": [],
                "summary": {},
            }

        raw_findings = result.get("findings", [])
        raw_summary = result.get("verification_summary", {})
        return {
            "status": "complete",
            "findings": raw_findings if isinstance(raw_findings, list) else [],
            "summary": raw_summary if isinstance(raw_summary, dict) else {},
        }

    def _build_failed_call_result(
        self,
        *,
        call_result: dict[str, Any],
        fallback_issues: list[AgentIssue],
        checks_run: list[str],
        c9_findings: list[dict[str, Any]],
        call1_findings: list[dict[str, Any]],
        call2_findings: list[dict[str, Any]],
        call1_summary: dict[str, Any],
        call2_summary: dict[str, Any],
        started: float,
        gating_metadata: dict[str, Any],
    ) -> AgentResult | None:
        status = str(call_result.get("status", "complete"))
        if status not in {"timeout", "error"}:
            return None

        return AgentResult(
            agent_type=self.agent_type,
            status=status,
            issues=fallback_issues,
            error=str(call_result.get("error", "CodeVerify session failed")),
            execution_time_ms=int((time.time() - started) * 1000),
            metadata={
                "checks_run": checks_run,
                "c9_findings": c9_findings,
                "call1_findings": call1_findings,
                "call2_findings": call2_findings,
                "call1_summary": call1_summary,
                "call2_summary": call2_summary,
                **gating_metadata,
            },
        )

    def _build_validator_result(
        self,
        issues: list[AgentIssue],
        checks_run: list[str],
    ) -> ValidatorResult:
        v0_issues = [issue for issue in issues if issue.priority == Priority.P0]
        constraints = [issue.suggestion for issue in v0_issues if issue.suggestion]
        return ValidatorResult(
            sound=not bool(v0_issues),
            issues=[issue.to_dict() for issue in v0_issues],
            constraints=constraints,
            provenance={
                "should_auto_revise": bool(v0_issues),
                "code_verify_version": "1.0",
                "checks_run": checks_run,
            },
        )

    def _has_blocking_issues(self, issues: list[AgentIssue]) -> bool:
        return any(issue.priority == Priority.P0 for issue in issues)

    def _merge_and_cap_issues(
        self,
        issues: list[AgentIssue],
        *,
        max_findings: int,
    ) -> tuple[list[AgentIssue], bool]:
        deduplicated: list[AgentIssue] = []
        seen_keys: set[tuple[str | None, int | None, str]] = set()
        for issue in issues:
            key = (issue.file_path, issue.line_number, issue.dimension)
            if key in seen_keys:
                continue
            seen_keys.add(key)
            deduplicated.append(issue)

        if max_findings <= 0 or len(deduplicated) <= max_findings:
            return deduplicated, False

        prioritized = sorted(
            deduplicated,
            key=lambda issue: _PRIORITY_ORDER.get(issue.priority, 99),
        )
        return prioritized[:max_findings], True

    def _build_grounding_prompt(
        self,
        *,
        plan_items: list[dict[str, Any]],
        exploration_context: Any,
    ) -> str:
        prompt_template = load_prompt("code_verify_grounding")
        plan_payload = json.dumps(plan_items, indent=2, sort_keys=True)
        exploration_markdown = self._render_exploration_context(exploration_context)
        return (
            f"{prompt_template}\n\n"
            f"## Working Directory\n{self._working_dir}\n\n"
            f"## Plan Items (JSON)\n```json\n{plan_payload}\n```\n\n"
            f"## Exploration Context\n{exploration_markdown}\n"
        )

    def _build_compliance_prompt(
        self,
        *,
        plan_items: list[dict[str, Any]],
        exploration_context: Any,
    ) -> str:
        prompt_template = load_prompt("code_verify_compliance")
        plan_payload = json.dumps(plan_items, indent=2, sort_keys=True)
        exploration_markdown = self._render_exploration_context(exploration_context)
        architectural_rules = (
            "- Rule 1: StateManager only (no direct DB writes)\n"
            "- Rule 35: TemplateEditPipeline for structured outputs\n"
            "- Rule 27: Domain abstractions over magic values\n"
            "- Rule 24: Prompt catalog/templates, not inline multi-line strings\n"
            "- Rule 6: Plugin/registry based agent resolution"
        )
        return (
            f"{prompt_template}\n\n"
            f"## Working Directory\n{self._working_dir}\n\n"
            f"## Plan Items (JSON)\n```json\n{plan_payload}\n```\n\n"
            f"## Exploration Context\n{exploration_markdown}\n\n"
            f"## Obra Architectural Rules\n{architectural_rules}\n"
        )

    def _render_exploration_context(self, exploration_context: Any) -> str:
        if exploration_context is None:
            return "None provided."

        to_markdown = getattr(exploration_context, "to_markdown", None)
        if callable(to_markdown):
            try:
                return str(to_markdown())
            except Exception:
                logger.debug("Failed to render exploration_context via to_markdown", exc_info=True)

        if isinstance(exploration_context, (dict, list)):
            return json.dumps(exploration_context, indent=2, sort_keys=True)

        return str(exploration_context)

    def _resolve_gating_metadata(
        self,
        item_id: str,
        config: dict[str, Any],
    ) -> dict[str, Any]:
        thresholds = get_intent_thresholds_config()
        brownfield_threshold = int(
            config.get(
                "brownfield_threshold",
                thresholds.get("detection_existing", 50),
            )
        )
        detection_empty = int(thresholds.get("detection_empty", 5))
        greenfield_skip_story1 = bool(config.get("greenfield_skip_story1", True))

        try:
            project_state = detect_project_state(
                self._working_dir,
                empty_threshold=detection_empty,
                existing_threshold=brownfield_threshold,
            )
            state_value = project_state.state.value
            file_count = int(project_state.file_count)
        except Exception as exc:
            logger.warning("CodeVerify project-state detection failed: %s", exc)
            state_value = "UNKNOWN"
            file_count = -1
            project_state = None

        is_story1 = self._is_first_execution_story(item_id)
        should_skip = (
            project_state is not None
            and project_state.state == ProjectState.EMPTY
            and greenfield_skip_story1
            and is_story1
        )
        gating = "greenfield_story1_skip" if should_skip else "full_checks"

        if self._log_event:
            try:
                self._log_event(
                    "code_verify_gating_decision",
                    item_id=item_id,
                    gating=gating,
                    project_state=state_value,
                    file_count=file_count,
                    brownfield_threshold=brownfield_threshold,
                    detection_empty=detection_empty,
                    greenfield_skip_story1=greenfield_skip_story1,
                )
            except Exception:
                logger.debug("CodeVerify gating log_event failed", exc_info=True)

        return {
            "gating": gating,
            "project_state": state_value,
            "file_count": file_count,
            "brownfield_threshold": brownfield_threshold,
        }

    def _is_first_execution_story(self, item_id: str) -> bool:
        match = re.match(r"^S(\d+)(?:\.|$)", item_id.strip())
        if not match:
            return False
        return int(match.group(1)) == 0

    def _to_issue(self, finding: dict[str, Any], index: int) -> AgentIssue:
        plan_ref = str(finding.get("plan_ref", ""))
        description = str(finding.get("description", "Dependency graph issue detected."))
        evidence = str(finding.get("evidence", "")).strip()
        suggestion = (
            f"Resolve the dependency graph issue for {plan_ref}: {evidence}"
            if evidence
            else f"Resolve the dependency graph issue for {plan_ref}."
        )

        return AgentIssue(
            id=f"CODE-VERIFY-C9-{index}",
            title=f"Dependency graph validation failed ({plan_ref or 'unknown item'})",
            description=description,
            priority=Priority.P0,
            dimension=str(finding.get("check", "C9")),
            suggestion=suggestion,
            issue_type="verification",
            metadata={
                "check": str(finding.get("check", "C9")),
                "severity": str(finding.get("severity", "V0")),
                "plan_ref": plan_ref,
                "evidence": evidence,
            },
        )

    def _to_verification_issue(self, finding: dict[str, Any], index: int) -> AgentIssue:
        check = str(finding.get("check", "C1")).upper()
        severity = str(finding.get("severity", "V2")).upper()
        description = str(finding.get("description", "Grounding verification issue detected."))
        recommendation = str(finding.get("recommendation", ""))

        # V0-arch (architectural crash) → P0 (blocking, triggers revision)
        # V0-spec (specification gap) → P1 (advisory, normal dev practices catch it)
        # V0 without sub-type → P0 for backward compat (legacy prompts)
        # V1 → P1, V2 → P2
        priority_map = {
            "V0-ARCH": Priority.P0,
            "V0-SPEC": Priority.P1,
            "V0": Priority.P0,
            "V1": Priority.P1,
            "V2": Priority.P2,
        }
        priority = priority_map.get(severity, Priority.P2)

        line_number: int | None = None
        raw_line = finding.get("line")
        try:
            if raw_line is not None:
                line_number = int(raw_line)
        except (TypeError, ValueError):
            line_number = None

        return AgentIssue(
            id=f"CV-{check}-{index}",
            title=description[:80],
            description=description,
            priority=priority,
            file_path=str(finding.get("file", "")) or None,
            line_number=line_number,
            dimension=check,
            issue_type="verification",
            suggestion=recommendation,
            metadata={
                "check": check,
                "severity": severity,
                "plan_ref": str(finding.get("plan_ref", "")),
                "evidence": str(finding.get("evidence", "")),
            },
        )

    def _to_grounding_issue(self, finding: dict[str, Any], index: int) -> AgentIssue:
        """Backward-compatible wrapper for existing tests."""
        return self._to_verification_issue(finding, index)
