"""Deterministic dependency graph validation for plan items."""

from __future__ import annotations

import re
from typing import Any


class DependencyGraphValidator:
    """Validate plan dependency graphs for structural correctness."""

    _STORY_ID_PATTERN = re.compile(r"^S\d+$")
    _TASK_ID_PATTERN = re.compile(r"^S\d+\.T\d+$")
    _SUBTASK_ID_PATTERN = re.compile(r"^S\d+\.T\d+\.\d+$")

    _EXECUTABLE_ITEM_TYPES = {"task", "subtask"}
    _CONTAINER_ITEM_TYPES = {"epic", "story", "milestone"}

    def validate(
        self,
        plan_items: list[dict[str, Any]],
        *,
        skip_hierarchy: bool = False,
    ) -> list[dict[str, str]]:
        """Validate dependency graph and optionally hierarchy for a plan.

        Args:
            plan_items: Plan items to validate.
            skip_hierarchy: If True, skip ID format validation. Use this when
                plan items may use formats other than the flat S<N>/S<N>.T<M>
                convention (e.g. E<N>.S<N>.T<N> from SaaS derivation).
        """
        nodes = self._collect_nodes(plan_items)
        if not nodes:
            return []

        node_ids = set(nodes.keys())
        item_types = self._collect_item_types(plan_items)
        findings: list[dict[str, str]] = []

        if not skip_hierarchy:
            findings.extend(self._validate_hierarchy(node_ids))
        findings.extend(self._validate_dependency_targets(nodes, node_ids))
        findings.extend(self._validate_no_container_dependencies(nodes, item_types))
        cycle_findings = self._detect_cycles(nodes)
        findings.extend(cycle_findings)
        findings.extend(self._validate_dependency_ordering(nodes, bool(cycle_findings)))

        return findings

    def _collect_nodes(
        self,
        plan_items: list[dict[str, Any]],
    ) -> dict[str, dict[str, list[str]]]:
        nodes: dict[str, dict[str, list[str]]] = {}

        def visit(item: Any) -> None:
            if not isinstance(item, dict):
                return

            item_id = item.get("id")
            if isinstance(item_id, str) and item_id.strip():
                # Canonical field is "dependencies" (server schema); fall back
                # to "depends_on" for backward compatibility.
                raw_depends = item.get("dependencies", item.get("depends_on", []))
                depends_on = raw_depends if isinstance(raw_depends, list) else []
                nodes[item_id] = {
                    "depends_on": [str(dep).strip() for dep in depends_on if str(dep).strip()]
                }

            for key in ("stories", "tasks", "subtasks"):
                children = item.get(key, [])
                if isinstance(children, list):
                    for child in children:
                        visit(child)

        for item in plan_items:
            visit(item)

        return nodes

    def _validate_hierarchy(self, node_ids: set[str]) -> list[dict[str, str]]:
        findings: list[dict[str, str]] = []
        for item_id in sorted(node_ids):
            if self._STORY_ID_PATTERN.match(item_id):
                continue

            if self._TASK_ID_PATTERN.match(item_id):
                story_id = item_id.split(".T", maxsplit=1)[0]
                if story_id not in node_ids:
                    findings.append(
                        self._build_finding(
                            plan_ref=item_id,
                            description="Task references a parent story that does not exist.",
                            evidence=f"Missing parent story: {story_id}",
                        )
                    )
                continue

            if self._SUBTASK_ID_PATTERN.match(item_id):
                task_id = item_id.rsplit(".", maxsplit=1)[0]
                if task_id not in node_ids:
                    findings.append(
                        self._build_finding(
                            plan_ref=item_id,
                            description="Subtask references a parent task that does not exist.",
                            evidence=f"Missing parent task: {task_id}",
                        )
                    )
                continue

            findings.append(
                self._build_finding(
                    plan_ref=item_id,
                    description=(
                        "Invalid plan item ID format. Expected S<N>, "
                        "S<N>.T<M>, or S<N>.T<M>.<K>."
                    ),
                    evidence=f"Invalid item id: {item_id}",
                )
            )

        return findings

    def _validate_dependency_targets(
        self,
        nodes: dict[str, dict[str, list[str]]],
        node_ids: set[str],
    ) -> list[dict[str, str]]:
        findings: list[dict[str, str]] = []
        for item_id, node in nodes.items():
            for dep_id in node.get("depends_on", []):
                if dep_id not in node_ids:
                    findings.append(
                        self._build_finding(
                            plan_ref=item_id,
                            description="Dependency target does not exist in plan.",
                            evidence=f"{item_id} depends_on missing item {dep_id}",
                        )
                    )
        return findings

    def _collect_item_types(
        self,
        plan_items: list[dict[str, Any]],
    ) -> dict[str, str]:
        """Build a map of item_id -> item_type for all plan items."""
        item_types: dict[str, str] = {}

        def visit(item: Any) -> None:
            if not isinstance(item, dict):
                return
            item_id = item.get("id")
            if isinstance(item_id, str) and item_id.strip():
                raw_type = item.get("item_type") or item.get("type") or "task"
                item_types[item_id.strip()] = str(raw_type).strip().lower()
            for key in ("stories", "tasks", "subtasks"):
                children = item.get(key, [])
                if isinstance(children, list):
                    for child in children:
                        visit(child)

        for item in plan_items:
            visit(item)
        return item_types

    def _validate_no_container_dependencies(
        self,
        nodes: dict[str, dict[str, list[str]]],
        item_types: dict[str, str],
    ) -> list[dict[str, str]]:
        """Reject dependencies where executable items depend on container items.

        Tasks and subtasks may only depend on other tasks or subtasks.
        Dependencies on epics or stories create unresolvable deadlocks because
        container items are never executed.
        """
        findings: list[dict[str, str]] = []
        for item_id, node in nodes.items():
            source_type = item_types.get(item_id, "task")
            if source_type not in self._EXECUTABLE_ITEM_TYPES:
                continue
            for dep_id in node.get("depends_on", []):
                dep_type = item_types.get(dep_id, "")
                if dep_type in self._CONTAINER_ITEM_TYPES:
                    findings.append(
                        self._build_finding(
                            plan_ref=item_id,
                            description=(
                                f"Executable item depends on container item "
                                f"({dep_type}). Tasks may only depend on other "
                                f"tasks or subtasks."
                            ),
                            evidence=(
                                f"{item_id} ({source_type}) depends on "
                                f"{dep_id} ({dep_type})"
                            ),
                        )
                    )
        return findings

    def _detect_cycles(
        self,
        nodes: dict[str, dict[str, list[str]]],
    ) -> list[dict[str, str]]:
        adjacency = {
            item_id: [
                dep for dep in node.get("depends_on", []) if dep in nodes
            ]
            for item_id, node in nodes.items()
        }

        findings: list[dict[str, str]] = []
        state = {item_id: 0 for item_id in nodes}  # 0=unvisited, 1=visiting, 2=done
        path: list[str] = []
        seen_cycles: set[tuple[str, ...]] = set()

        for start_id in sorted(adjacency):
            if state[start_id] != 0:
                continue

            stack: list[tuple[str, int]] = [(start_id, 0)]
            while stack:
                current_id, dep_index = stack[-1]
                if state[current_id] == 0:
                    state[current_id] = 1
                    path.append(current_id)

                deps = adjacency.get(current_id, [])
                if dep_index < len(deps):
                    dep_id = deps[dep_index]
                    stack[-1] = (current_id, dep_index + 1)
                    dep_state = state.get(dep_id, 2)
                    if dep_state == 0:
                        stack.append((dep_id, 0))
                        continue
                    if dep_state == 1:
                        cycle_start = path.index(dep_id) if dep_id in path else 0
                        cycle = [*path[cycle_start:], dep_id]
                        cycle_key = self._normalize_cycle(cycle)
                        if cycle_key not in seen_cycles:
                            seen_cycles.add(cycle_key)
                            findings.append(
                                self._build_finding(
                                    plan_ref=current_id,
                                    description="Circular dependency detected in plan graph.",
                                    evidence=" -> ".join(cycle),
                                )
                            )
                    continue

                state[current_id] = 2
                stack.pop()
                if path and path[-1] == current_id:
                    path.pop()

        return findings

    def _validate_dependency_ordering(
        self,
        nodes: dict[str, dict[str, list[str]]],
        cycle_found: bool,
    ) -> list[dict[str, str]]:
        indegree = {item_id: 0 for item_id in nodes}
        dependents: dict[str, list[str]] = {item_id: [] for item_id in nodes}

        for item_id, node in nodes.items():
            for dep_id in node.get("depends_on", []):
                if dep_id in nodes:
                    indegree[item_id] += 1
                    dependents[dep_id].append(item_id)

        queue = [item_id for item_id, degree in indegree.items() if degree == 0]
        visited = 0
        while queue:
            current_id = queue.pop()
            visited += 1
            for dependent_id in dependents.get(current_id, []):
                indegree[dependent_id] -= 1
                if indegree[dependent_id] == 0:
                    queue.append(dependent_id)

        if visited == len(nodes):
            return []

        if cycle_found:
            return []

        unresolved = sorted(item_id for item_id, degree in indegree.items() if degree > 0)
        return [
            self._build_finding(
                plan_ref=item_id,
                description="Dependency ordering is not achievable for this plan item.",
                evidence=f"Unresolved dependencies after topological sort: {unresolved}",
            )
            for item_id in unresolved
        ]

    def _normalize_cycle(self, cycle: list[str]) -> tuple[str, ...]:
        if len(cycle) <= 1:
            return tuple(cycle)
        base = cycle[:-1] if cycle[0] == cycle[-1] else cycle[:]
        rotations = [tuple(base[i:] + base[:i]) for i in range(len(base))]
        return min(rotations)

    def _build_finding(
        self,
        *,
        plan_ref: str,
        description: str,
        evidence: str,
    ) -> dict[str, str]:
        return {
            "check": "C9",
            "severity": "V0",
            "description": description,
            "plan_ref": plan_ref,
            "evidence": evidence,
        }
