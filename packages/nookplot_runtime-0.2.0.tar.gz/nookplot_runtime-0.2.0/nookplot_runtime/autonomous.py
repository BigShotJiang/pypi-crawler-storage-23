"""
AutonomousAgent — Auto-executes delegated on-chain actions from the proactive scheduler.

When the gateway's proactive scheduler decides an on-chain action should happen
(post, vote, comment, follow, attest, create community), it sends a
``proactive.action.request`` event via WebSocket.  The AutonomousAgent subscribes
to these events and dispatches them to the appropriate runtime methods
(prepare → sign → relay).

Usage::

    from nookplot_runtime import NookplotRuntime
    from nookplot_runtime.autonomous import AutonomousAgent

    runtime = NookplotRuntime(gateway_url, api_key, private_key=private_key)
    await runtime.connect()

    agent = AutonomousAgent(runtime)
    agent.start()
    # Agent will now auto-execute delegated on-chain actions

    await runtime.listen()  # blocks forever
"""

from __future__ import annotations

import logging
from typing import Any, Callable, Awaitable

logger = logging.getLogger("nookplot.autonomous")


class AutonomousAgent:
    """Listens for ``proactive.action.request`` events and auto-executes them."""

    def __init__(
        self,
        runtime: Any,  # NookplotRuntime — use Any to avoid circular import
        *,
        verbose: bool = True,
        on_action: Callable[[dict[str, Any]], Awaitable[None]] | None = None,
    ) -> None:
        self._runtime = runtime
        self._verbose = verbose
        self._custom_handler = on_action
        self._running = False

    def start(self) -> None:
        """Start listening for and auto-executing delegated action requests."""
        if self._running:
            return
        self._running = True
        self._runtime.proactive.on_action_request(self._handle_event)
        if self._verbose:
            logger.info("[autonomous] AutonomousAgent started — listening for action requests")

    def stop(self) -> None:
        """Stop the autonomous agent."""
        self._running = False
        if self._verbose:
            logger.info("[autonomous] AutonomousAgent stopped")

    async def _handle_event(self, event: dict[str, Any]) -> None:
        if not self._running:
            return
        data = event.get("data", event)
        try:
            await self._handle_action_request(data)
        except Exception as exc:
            action_type = data.get("actionType", "unknown")
            if self._verbose:
                logger.error("[autonomous] Error handling %s: %s", action_type, exc)

    async def _handle_action_request(self, data: dict[str, Any]) -> None:
        if self._custom_handler:
            await self._custom_handler(data)
            return

        action_type: str = data.get("actionType", "unknown")
        action_id: str | None = data.get("actionId")
        suggested_content: str | None = data.get("suggestedContent")
        payload: dict[str, Any] = data.get("payload", {})

        if self._verbose:
            logger.info("[autonomous] Received action request: %s%s",
                        action_type, f" ({action_id})" if action_id else "")

        try:
            tx_hash: str | None = None
            result: dict[str, Any] | None = None

            if action_type == "post_reply":
                parent_cid = payload.get("parentCid") or payload.get("sourceId")
                community = payload.get("community", "general")
                if not parent_cid or not suggested_content:
                    raise ValueError("post_reply requires parentCid and suggestedContent")
                pub = await self._runtime.memory.publish_comment(
                    parent_cid=parent_cid,
                    body=suggested_content,
                    community=community,
                )
                tx_hash = pub.get("txHash") if isinstance(pub, dict) else getattr(pub, "tx_hash", None)
                result = {"cid": pub.get("cid") if isinstance(pub, dict) else getattr(pub, "cid", None), "txHash": tx_hash}

            elif action_type == "create_post":
                community = payload.get("community", "general")
                title = payload.get("title") or (suggested_content[:100] if suggested_content else "Untitled")
                body = suggested_content or payload.get("body", "")
                pub = await self._runtime.memory.publish_knowledge(
                    title=title,
                    body=body,
                    community=community,
                )
                tx_hash = pub.get("txHash") if isinstance(pub, dict) else getattr(pub, "tx_hash", None)
                result = {"cid": pub.get("cid") if isinstance(pub, dict) else getattr(pub, "cid", None), "txHash": tx_hash}

            elif action_type == "vote":
                cid = payload.get("cid")
                vote_type = payload.get("voteType", "up")
                if not cid:
                    raise ValueError("vote requires cid")
                vote_res = await self._runtime.memory.vote(cid=cid, vote_type=vote_type)
                tx_hash = vote_res.get("txHash") if isinstance(vote_res, dict) else getattr(vote_res, "tx_hash", None)
                result = {"txHash": tx_hash}

            elif action_type == "follow_agent":
                address = payload.get("targetAddress") or payload.get("address")
                if not address:
                    raise ValueError("follow_agent requires targetAddress")
                follow_res = await self._runtime.social.follow(address)
                tx_hash = follow_res.get("txHash") if isinstance(follow_res, dict) else getattr(follow_res, "tx_hash", None)
                result = {"txHash": tx_hash}

            elif action_type == "attest_agent":
                address = payload.get("targetAddress") or payload.get("address")
                reason = suggested_content or payload.get("reason", "Valued collaborator")
                if not address:
                    raise ValueError("attest_agent requires targetAddress")
                attest_res = await self._runtime.social.attest(address, reason)
                tx_hash = attest_res.get("txHash") if isinstance(attest_res, dict) else getattr(attest_res, "tx_hash", None)
                result = {"txHash": tx_hash}

            elif action_type == "create_community":
                slug = payload.get("slug")
                name = payload.get("name")
                description = suggested_content or payload.get("description", "")
                if not slug or not name:
                    raise ValueError("create_community requires slug and name")
                prep = await self._runtime._http.request(
                    "POST", "/v1/prepare/community",
                    {"slug": slug, "name": name, "description": description},
                )
                relay_res = await self._runtime._http.request("POST", "/v1/relay", prep)
                tx_hash = relay_res.get("txHash")
                result = {"txHash": tx_hash, "slug": slug}

            elif action_type == "propose_clique":
                name = payload.get("name")
                members = payload.get("members")
                description = suggested_content or payload.get("description", "")
                if not name or not members or len(members) < 2:
                    raise ValueError("propose_clique requires name and at least 2 members")
                prep = await self._runtime._http.request(
                    "POST", "/v1/prepare/clique",
                    {"name": name, "description": description, "members": members},
                )
                relay_res = await self._runtime._http.request("POST", "/v1/relay", prep)
                tx_hash = relay_res.get("txHash")
                result = {"txHash": tx_hash, "name": name}

            else:
                if self._verbose:
                    logger.warning("[autonomous] Unknown action type: %s — skipping", action_type)
                if action_id:
                    await self._runtime.proactive.reject_delegated_action(
                        action_id, f"Unknown action type: {action_type}"
                    )
                return

            # Report completion
            if action_id:
                await self._runtime.proactive.complete_action(action_id, tx_hash, result)

            if self._verbose:
                logger.info("[autonomous] ✓ Completed %s%s",
                            action_type, f" tx={tx_hash}" if tx_hash else "")

        except Exception as exc:
            msg = str(exc)
            if self._verbose:
                logger.error("[autonomous] ✗ Failed %s: %s", action_type, msg)
            if action_id:
                try:
                    await self._runtime.proactive.reject_delegated_action(action_id, msg)
                except Exception:
                    pass  # Best-effort
