# Language Independent Interface Types For INSIGHT

The proto files can be consumed as GIT submodules or copied and built directly in the consumer project.

The compiled files are published to central repositories (Maven, ...).

## Prerequisites

### Python

```bash
pip install grpcio grpcio-tools mypy-protobuf
```

### Go

```bash
# protoc (protobuf compiler)
# Ubuntu/Debian:
sudo apt install -y protobuf-compiler
# macOS:
brew install protobuf

# Go protobuf plugins
go install google.golang.org/protobuf/cmd/protoc-gen-go@latest
go install google.golang.org/grpc/cmd/protoc-gen-go-grpc@latest
go install github.com/srikrsna/protoc-gen-gotag@latest
```

Ensure `$GOPATH/bin` (usually `~/go/bin`) is on your `PATH`.

## Generate gRPC Client Libraries

To generate the raw gRPC client libraries, use `make gen-${LANGUAGE}`. Currently supported languages are:

* python
* golang

# Using local build

When testing you can build the python version locally using `make build-python`. This will build a version of 0.0.1-dev,
this can then be installed using `pip install`.

```bash
make build-python VERSION=0.0.2
```
Then update the agent `pyproject.yaml`
```toml

dependencies = [
    "insight-proto @ file:///home/bdonnell/repo/github/opentrace/insight-proto/build/python",
]
```
Then run pip install for the agent:
```bash
pip install -e".[dev]"
```
Due to this being a dev build sometimes pip gets confused so you might need to run uninstall.
```bash
pip uninstall insight-proto
```

## Go

Build the Go protobuf locally and update the `insight-proto-go` submodule:

```bash
make build-go-local
```

Then in your Go service, add a `replace` directive in `go.mod` to point at your local copy:

```go
replace github.com/opentrace/insight-proto-go => /home/bdonnell/repo/github/opentrace/insight-proto/insight-proto-go
```

# Releasing

To release this we use GitHub Actions when a new release is tagged via GitHub.
