# Schema Module

This module contains schema definitions and validation functionality.

::: nextpipe.schema
