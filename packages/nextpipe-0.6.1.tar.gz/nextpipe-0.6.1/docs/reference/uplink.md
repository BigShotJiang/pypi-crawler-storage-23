# Uplink Module

This module contains functionality for linking with external systems and services.

::: nextpipe.uplink
