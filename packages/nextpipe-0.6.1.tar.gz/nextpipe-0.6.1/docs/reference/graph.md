# Graph Module

This module contains graph-related functionality for representing and
manipulating pipeline structures.

::: nextpipe.graph
