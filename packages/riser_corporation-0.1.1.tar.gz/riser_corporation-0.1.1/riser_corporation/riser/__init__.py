from .client import RiserClient
from .config import Config

class riser:
    @staticmethod
    def init(api_key=None, ai_name="Riser", system_prompt="You are AI", log_callback=None, prefixes=None, language="en-IN"):
        cfg = Config(api_key, ai_name, system_prompt, prefixes=prefixes, language=language)
        return RiserClient(cfg, log_callback=log_callback)
