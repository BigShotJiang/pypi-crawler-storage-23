import sys
import asyncio
from .loader import load_core
from .config import Config

class RiserClient:
    def __init__(self, config: Config, log_callback=None):
        self.config = config
        try:
            self.core = load_core(
                api_key=self.config.api_key,
                ai_name=self.config.ai_name,
                system_prompt=self.config.system_prompt,
                log_callback=log_callback,
                prefixes=self.config.prefixes,
                language=self.config.language
            )
        except Exception as e:
            print(f"[ERROR] Failed to load core engine: {e}")
            self.core = None

    def speak(self, text):
        if self.core and hasattr(self.core, 'speak'):
            # Check if speak is async
            import inspect
            if inspect.iscoroutinefunction(self.core.speak):
                try:
                    loop = asyncio.get_event_loop()
                    if loop.is_running():
                        return asyncio.create_task(self.core.speak(text))
                    else:
                        return loop.run_until_complete(self.core.speak(text))
                except RuntimeError:
                    return asyncio.run(self.core.speak(text))
            else:
                return self.core.speak(text)
        else:
            print(f"Bot (Silent): {text}")

    def ask(self, text):
        if self.core and hasattr(self.core, 'get_ai_response'):
            prompt = self.config.system_prompt + "\nUser: " + text
            return self.core.get_ai_response(prompt)
        return "Core not loaded."

    def start(self):
        if self.core and hasattr(self.core, 'main_loop'):
            try:
                asyncio.run(self.core.main_loop())
            except KeyboardInterrupt:
                pass
        else:
            print("Core engine main loop not found.")

def main():
    if len(sys.argv) < 2:
        print("Usage: riser speak <text> | riser start")
        return

    cmd = sys.argv[1]
    cfg = Config()
    client = RiserClient(cfg)

    if cmd == "speak":
        text = " ".join(sys.argv[2:]) if len(sys.argv) > 2 else "Hello"
        client.speak(text)
    elif cmd == "start":
        client.start()
    else:
        print(f"Unknown command: {cmd}")
