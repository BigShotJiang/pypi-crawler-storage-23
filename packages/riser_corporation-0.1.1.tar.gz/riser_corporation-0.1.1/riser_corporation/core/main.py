import os
import asyncio
import json
import speech_recognition
import edge_tts
import pygame
import requests
import webbrowser
import time
import pyautogui
import base64
import urllib.parse
import urllib.request  # Added for fast YouTube scraping
import re
import concurrent.futures
import io
import psutil
from io import BytesIO
from ddgs import DDGS
from dotenv import load_dotenv

# --- CONFIGURATION ---
load_dotenv()
API_KEY = os.getenv("OPENROUTER_API_KEY", "")
if not API_KEY:
    print("[WARNING] OPENROUTER_API_KEY is not set. API calls will fail.")

ELEVENLABS_API_KEY = os.getenv("ELEVENLABS_API_KEY", "")
if not ELEVENLABS_API_KEY:
    print("[WARNING] ELEVENLABS_API_KEY is not set. ElevenLabs Voice output may fail.")

ELEVENLABS_VOICE_ID = "pNInz6obpgDQGcFmaJcg"

MODEL_ID = "arcee-ai/trinity-large-preview:free" # Fast and responsive free model
VISION_MODEL = "google/gemini-2.0-flash-lite-preview-02-05:free" 
API_URL = "https://openrouter.ai/api/v1/chat/completions"
GUI_URL = ""

class Jarvis:
    # list of canned system commands
    SMART_COMMANDS = {
        "lock screen": "rundll32.exe user32.dll,LockWorkStation",
        "restart": "shutdown /r /t 1",
        "shutdown now": "shutdown /s /f /t 1", # Added /f for perfect forceful shutdown
        "sleep": "rundll32.exe powrprof.dll,SetSuspendState 0,1,0",
        "hibernate": "shutdown /h",
        "open calculator": "start calc.exe",
        "open notepad": "start notepad.exe",
        "open paint": "start mspaint.exe",
        "open cmd": "start cmd.exe",
        "open command prompt": "start cmd.exe",
        "open settings": "start ms-settings:",
        "open task manager": "start taskmgr.exe",
        "open explorer": "start explorer.exe",
        "open control panel": "start control.exe",
        "open word": "start winword.exe",
        "open excel": "start excel.exe",
        "open powerpoint": "start powerpnt.exe",
        "open edge": "start msedge",
        "open chrome": "start chrome",
        "open firefox": "start firefox",
        "wifi on": "powershell -Command \"Start-Process netsh -ArgumentList 'interface set interface \\\"Wi-Fi\\\" admin=enabled' -Verb RunAs\"",
        "wifi off": "powershell -Command \"Start-Process netsh -ArgumentList 'interface set interface \\\"Wi-Fi\\\" admin=disabled' -Verb RunAs\"",
        "bluetooth on": "powershell -Command \"Start-Process powershell -ArgumentList '-Command Enable-PnpDevice -Class Bluetooth -Confirm:$false' -Verb RunAs\"",
        "bluetooth off": "powershell -Command \"Start-Process powershell -ArgumentList '-Command Disable-PnpDevice -Class Bluetooth -Confirm:$false' -Verb RunAs\"",
        "airplane mode on": "powershell -Command \"Start-Process powershell -ArgumentList '-Command Disable-NetAdapter -Name * -Confirm:$false' -Verb RunAs\"",
        "airplane mode off": "powershell -Command \"Start-Process powershell -ArgumentList '-Command Enable-NetAdapter -Name * -Confirm:$false' -Verb RunAs\"",
        "increase brightness": "powershell -Command \"$b=(Get-WmiObject -Namespace root/WMI -Class WmiMonitorBrightness).CurrentBrightness; if ($b -ne $null) { (Get-WmiObject -Namespace root/WMI -Class WmiMonitorBrightnessMethods).WmiSetBrightness(1,[math]::Min($b+20,100)) }\"",
        "decrease brightness": "powershell -Command \"$b=(Get-WmiObject -Namespace root/WMI -Class WmiMonitorBrightness).CurrentBrightness; if ($b -ne $null) { (Get-WmiObject -Namespace root/WMI -Class WmiMonitorBrightnessMethods).WmiSetBrightness(1,[math]::Max($b-20,0)) }\"",
        "eject cd": "powershell -Command \"(New-Object -ComObject WMPlayer.OCX.7).cdromcollection.Item(0).Eject()\"",
        "open device manager": "start devmgmt.msc",
        "open network settings": "start ms-settings:network",
        "open volume mixer": "start sndvol",
        "open system info": "start msinfo32",
        "open programs and features": "start appwiz.cpl",
        "open task scheduler": "start taskschd.msc",
        "open registry editor": "start regedit",
        "open services": "start services.msc",
        "open disk management": "start diskmgmt.msc",
        "open event viewer": "start eventvwr.msc",
        "open computer management": "start compmgmt.msc",
        "open downloads": "start shell:Downloads",
        "open documents": "start shell:Personal",
        "open pictures": "start shell:My Pictures",
        "open videos": "start shell:My Video",
        "open music": "start shell:My Music",
        "open sound settings": "start ms-settings:sound",
        "open display settings": "start ms-settings:display",
        "open windows update": "start ms-settings:windowsupdate",
        "open apps and features": "start ms-settings:appsfeatures",
        "open bluetooth settings": "start ms-settings:bluetooth",
        "open time and language": "start ms-settings:dateandtime",
        "empty recycle bin": "powershell.exe -NoProfile -Command \"Clear-RecycleBin -Force\"",
        "take screenshot": "powershell -c \"Add-Type -AssemblyName System.Windows.Forms; [System.Windows.Forms.SendKeys]::SendWait('^{PRTSC}')\""
    }

    def __init__(self, api_key=None, ai_name="AI", system_prompt="You are a helpful assistant.", log_callback=None, prefixes=None, language="en-IN"):
        self.api_key = api_key or API_KEY
        self.ai_name = ai_name
        self.system_prompt = system_prompt
        self.log_callback = log_callback
        self.language = language
        
        # Dynamic Prefixes for Custom UI
        default_prefixes = {
            "system": "[SYSTEM]:",
            "assistant": f"[{self.ai_name.upper()}]:",
            "user": "[USER]:",
            "live": f"[LIVE]: {self.ai_name} is listening...",
            "error": "[ERROR]:"
        }
        self.prefixes = {**default_prefixes, **(prefixes or {})}
        
        self.recognizer = speech_recognition.Recognizer()
        self.executor = concurrent.futures.ThreadPoolExecutor(max_workers=3)
        
        # --- SIMPLE MIC SETUP (User's Format) ---
        try:
            self.microphone = speech_recognition.Microphone()
        except Exception as e:
            print(f"[WARNING]: Microphone initialization failed: {e}")
            self.microphone = None

        self.en_voice = "en-IN-PrabhatNeural"
        self.hi_voice = "hi-IN-MadhurNeural"
        self.is_listening = True
        self.is_speaking = False
        self.user_away = False
        self.battery_alerted = False
        self.loop = None
        self.audio_queue = None

        # ULTRA-STABLE NOISE GATE
        self.recognizer.energy_threshold = 4000 
        self.recognizer.pause_threshold = 0.8 
        self.recognizer.phrase_threshold = 0.3 
        # (Reduced complexity for STT simplicity)

        # Buffer reduced to eliminate Pygame delay
        pygame.mixer.init(buffer=512)
        self._init_volume_interface()

        # --- MEMORY SYSTEM ---
        self.memory_file = "riser_memory.json"
        self.user_memory = self._load_memory()
        
    def log(self, message, msg_type="info"):
        """Centralized logging for custom UI"""
        prefix = self.prefixes.get(msg_type, self.prefixes.get("system", "[LOG]:"))
        if self.log_callback:
            try:
                self.log_callback(message, msg_type)
            except:
                print(f"{prefix} {message}")
        else:
            print(f"{prefix} {message}")
        
    def is_hindi(self, text):
        return any('\u0900' <= char <= '\u097F' for char in text)

    def _load_memory(self):
        if os.path.exists(self.memory_file):
            try:
                with open(self.memory_file, "r") as f:
                    return json.load(f)
            except: return {}
        return {}

    def _save_memory(self):
        try:
            with open(self.memory_file, "w") as f:
                json.dump(self.user_memory, f)
        except: pass

    # --- volume control helpers ------------------------------------------------
    def _init_volume_interface(self):
        try:
            from ctypes import POINTER, cast
            from comtypes import CLSCTX_ALL
            from pycaw.pycaw import AudioUtilities, IAudioEndpointVolume

            try:
                devices = AudioUtilities.GetSpeakers()
                if hasattr(devices, 'Activate'):
                    interface = devices.Activate(IAudioEndpointVolume._iid_, CLSCTX_ALL, None)
                    self.volume_interface = cast(interface, POINTER(IAudioEndpointVolume))
                else:
                    self.volume_interface = None
            except Exception:
                self.volume_interface = None

            try:
                mic_devices = AudioUtilities.GetMicrophone()
                if hasattr(mic_devices, 'Activate'):
                    mic_interface = mic_devices.Activate(IAudioEndpointVolume._iid_, CLSCTX_ALL, None)
                    self.mic_interface = cast(mic_interface, POINTER(IAudioEndpointVolume))
                else:
                    self.mic_interface = None
            except Exception:
                self.mic_interface = None

        except Exception as exc:
            print("[INFO] audio interface init failed, will use hotkeys:", exc)
            self.volume_interface = None
            self.mic_interface = None

    def set_volume_level(self, percent: int) -> bool:
        if self.volume_interface:
            p = max(0, min(percent, 100))
            self.volume_interface.SetMasterVolumeLevelScalar(p / 100.0, None)
            return True
        else:
            try:
                current = 0
                for _ in range(40): pyautogui.press('volumeup')
                for _ in range(40): pyautogui.press('volumedown')
                steps = round(percent / 2.5)
                for _ in range(steps): pyautogui.press('volumeup')
                return True
            except Exception:
                return False

    def change_volume(self, delta: int) -> bool:
        if self.volume_interface:
            current = self.volume_interface.GetMasterVolumeLevelScalar() * 100
            new = max(0, min(current + delta, 100))
            return self.set_volume_level(int(new))
        else:
            key = 'volumeup' if delta > 0 else 'volumedown'
            steps = abs(delta) // 2 
            try:
                for _ in range(steps or 1): pyautogui.press(key)
                return True
            except Exception:
                return False

    def set_mute(self, status: bool) -> bool:
        if self.volume_interface:
            self.volume_interface.SetMute(1 if status else 0, None)
            return True
        try:
            pyautogui.press('volumemute')
            return True
        except Exception:
            return False

    def set_microphone_mute(self, status: bool) -> bool:
        if hasattr(self, 'mic_interface') and self.mic_interface:
            self.mic_interface.SetMute(1 if status else 0, None)
            return True
        return False

    # --- laptop command dispatcher --------------------------------------------
    def handle_laptop_command(self, query: str):
        # Updated to filter out "riser" as well
        q = query.lower().replace("riser", "").replace("jarvis", "").replace("-", " ").strip()
        q = re.sub(r"\bon of\b", "on", q)
        q = re.sub(r"\boff on\b", "off", q)
        q = re.sub(r"\b(on|off)\s+\1\b", r"\1", q)

        if "microphone" in q and ("mute" in q or "unmute" in q):
            if "unmute" in q:
                ok = self.set_microphone_mute(False)
                return "Microphone unmuted" if ok else "Microphone control unavailable"
            else:
                ok = self.set_microphone_mute(True)
                return "Microphone muted" if ok else "Microphone control unavailable"

        if "volume" in q or ("mute" in q and "microphone" not in q):
            if any(x in q for x in ("up", "increase", "louder")):
                ok = self.change_volume(10)
                return "Volume increased" if ok else "Volume control unavailable"
            if any(x in q for x in ("down", "decrease", "quieter")):
                ok = self.change_volume(-10)
                return "Volume decreased" if ok else "Volume control unavailable"
            if "mute" in q and "unmute" not in q:
                ok = self.set_mute(True)
                return "Muted" if ok else "Volume control unavailable"
            if "unmute" in q:
                ok = self.set_mute(False)
                return "Unmuted" if ok else "Volume control unavailable"
            m = re.search(r"(\d{1,3})", q)
            if m:
                level = int(m.group(1))
                ok = self.set_volume_level(level)
                return f"Volume set to {level} percent" if ok else "Volume control unavailable"
            return "I didn't catch the volume level."

        # --- MOUSE AND SCROLL CONTROLS ---
        if any(word in q for word in ["scroll", "mouse", "click"]):
            if "scroll up" in q:
                pyautogui.scroll(500)
                return "Scrolling up sir."
            if "scroll down" in q:
                pyautogui.scroll(-500)
                return "Scrolling down sir."
            if "click" in q:
                pyautogui.click()
                return "Clicked sir."
            if "right click" in q:
                pyautogui.rightClick()
                return "Right clicked sir."
            if "double click" in q:
                pyautogui.doubleClick()
                return "Double clicked sir."

        if "battery" in q or "power status" in q:
            battery = psutil.sensors_battery()
            if battery:
                return f"Sir, current battery is at {battery.percent} percent."
            return "I can't access battery data sir."

        if any(word in q for word in ["ram", "memory status", "storage"]):
            ram = psutil.virtual_memory()
            return f"Sir, RAM usage is currently at {ram.percent} percent."

        # --- FUZZY NOTES SYSTEM ---
        note_trigger = any(x in q for x in ["write a note", "rite a note", "right a note", "make a note", "save this note"])
        if note_trigger:
            raw_note = q.replace("riser", "").replace("jarvis", "").strip()
            # Try to catch content after the trigger words
            triggers = ["write a note", "rite a note", "right a note", "make a note", "save this note"]
            content = raw_note
            for t in triggers: content = content.replace(t, "").strip()
            
            if not content: return "Sir, please tell me what to write in the note."
            with open("riser_notes.txt", "a", encoding="utf-8") as f:
                f.write(f"[{time.strftime('%Y-%m-%d %H:%M')}] {content}\n")
            return f"Note saved successfully sir: {content}"

        if any(x in q for x in ["read my note", "read my notes", "padh kar batao", "check my notes"]):
            if os.path.exists("riser_notes.txt"):
                with open("riser_notes.txt", "r", encoding="utf-8") as f:
                    notes = f.readlines()
                if not notes: return "Sir, your notes file is empty."
                # If specifically asked to read "assignment", find that note
                if "assignment" in q:
                    matching = [n for n in notes if "assignment" in n.lower()]
                    if matching: return f"Sir, here is your assignment note: {matching[-1]}"
                
                last_notes = "".join(notes[-3:]) # Read only last 3 for speed
                return f"Sir, here are your recent notes: {last_notes}"
            return "Sir, you haven't saved any notes yet."

        if "weather" in q or "mausam" in q or "temperature" in q:
            # Smart logic to get weather without API key
            try:
                location = "my current location"
                if "in" in q: location = q.split("in")[-1].strip()
                search_query = f"current weather and AQI in {location}"
                weather_info = self.search_web(search_query)
                if weather_info:
                    context_weather = "Context: Use these search results to tell the weather/AQI naturally in Hinglish: " + " ".join(weather_info)
                    return context_weather # Return to be processed by speak further down or handle here
            except: pass

        for phrase, action in sorted(self.SMART_COMMANDS.items(), key=lambda kv: -len(kv[0])):
            if re.search(r"\b" + re.escape(phrase) + r"\b", q):
                try:
                    silent_action = f"{action} >nul 2>&1"
                    os.system(silent_action)
                    first = phrase.split()[0].capitalize()
                    rest = " ".join(phrase.split()[1:])
                    spoken = f"{first} {rest}" if rest else first
                    return f"{spoken} executed"
                except Exception as exc:
                    print("[ERROR] executing smart command", exc)
                    return f"Failed to {phrase}"
        return None

    # --- PERFECT SMART SHUTDOWN ADDED ---
    async def smart_shutdown(self):
        print("[SYSTEM]: Closing all background applications...")
        for i in range(5): 
            pyautogui.hotkey('alt', 'f4')
            time.sleep(0.3)
        await self.speak("All background windows removed now perfectly shutting down laptop bye bye see you later")
        time.sleep(1)
        # Added /f to completely force close everything and ensure PERFECT shutdown
        os.system("shutdown /s /f /t 1")

    # --- IMPROVED YT SEARCH ---
    def play_on_youtube(self, query_text):
        """Clean the query and play exact video instantly without flaky GUI automation"""
        # Updated stop words for Riser
        stop_words = ["play", "open", "and", "youtube", "on", "search", "riser", "jarvis", "babu"]
        clean_query = query_text.lower()
        for word in stop_words:
            clean_query = clean_query.replace(word, "")
        
        clean_query = clean_query.strip()
        print(f"[SYSTEM]: Playing clean query on YouTube: {clean_query}")
        
        if clean_query:
            try:
                # Scrape directly to get the top video ID
                search_url = f"https://www.youtube.com/results?search_query={urllib.parse.quote(clean_query)}"
                html = urllib.request.urlopen(search_url)
                video_ids = re.findall(r"watch\?v=(\S{11})", html.read().decode())
                
                if video_ids:
                    target_url = f"https://www.youtube.com/watch?v={video_ids[0]}"
                    print(f"[SYSTEM]: Playing direct video: {target_url}")
                    webbrowser.open(target_url)
                    return
            except Exception as e:
                print(f"[ERROR] Advanced Youtube search failed: {e}")

            # Fallback if regex fails
            url = f"https://www.youtube.com/results?search_query={urllib.parse.quote(clean_query)}"
            webbrowser.open(url)

    def open_website(self, query_text):
        stop_words = ["open", "website", "site", "riser", "jarvis", "please"]
        clean_query = query_text.lower()
        for word in stop_words:
            clean_query = clean_query.replace(word, "")
        website_name = clean_query.strip()
        
        if website_name:
            print(f"[SYSTEM]: Searching for accurate URL of: {website_name}")
            try:
                with DDGS(impersonate="chrome_120") as ddgs:
                    results = [r for r in ddgs.text(f"official website {website_name}", max_results=1)]
                    if results and 'href' in results[0]:
                        url = results[0]['href']
                        print(f"[SYSTEM]: Opening website: {url}")
                        webbrowser.open(url)
                        return website_name
            except Exception as e:
                print(f"[ERROR] DDGS search failed: {e}")
            
            url = f"https://{website_name.replace(' ', '')}.com"
            print(f"[SYSTEM]: Opening fallback website: {url}")
            webbrowser.open(url)
            return website_name
        return None

    def search_and_download_anime(self, query_text):
        stop_words = ["download", "thi", "series", "anime", "full", "episode", "riser", "jarvis"]
        clean_query = query_text.lower()
        for word in stop_words:
            clean_query = clean_query.replace(word, "")
            
        clean_query = clean_query.strip()
        if clean_query:
            print(f"[SYSTEM]: Downloading/Searching anime: {clean_query}")
            url = f"https://duckduckgo.com/?q={urllib.parse.quote(clean_query + ' anime full episode download')}"
            webbrowser.open(url)
            return clean_query
        return None

    # --- IMPROVED LOCAL FILE SEARCH ---
    def play_local_media(self, query_text):
        """Advanced token-based search for accurate local media matching"""
        stop_words = ["play", "downloaded", "video", "music", "song", "movie", "riser", "jarvis", "in", "system", "my", "from", "your", "downloads"]
        
        # Clean query more robustly using regex word boundaries
        q = query_text.lower()
        for word in stop_words:
            q = re.sub(r'\b' + re.escape(word) + r'\b', '', q)
        
        target = q.strip()
        if not target:
            return "Please tell me the name of the file you want to play sir."
            
        print(f"[SYSTEM]: Searching for local media: {target}")
        tokens = [t for t in target.split() if len(t) >= 2] # Keep words with 2 or more chars
        if not tokens: # Fallback if all words are very short
            tokens = target.split()
        
        user_profile = os.environ.get('USERPROFILE')
        if not user_profile:
            return "Could not access user folders sir."
            
        search_dirs = [
            os.path.join(user_profile, "Downloads"),
            os.path.join(user_profile, "Videos"),
            os.path.join(user_profile, "Music"),
            os.path.join(user_profile, "Desktop")
        ]
        
        valid_extensions = ('.mp4', '.mkv', '.avi', '.mp3', '.wav', '.flac', '.mov', '.wmv')
        
        best_match = None
        highest_score = 0

        for directory in search_dirs:
            if not os.path.exists(directory):
                continue
                
            for root, dirs, files in os.walk(directory):
                dirs[:] = [d for d in dirs if not d.startswith('.') and d.lower() not in ['node_modules', 'appdata', 'windows', 'program files']]
                
                for file in files:
                    file_lower = file.lower()
                    if file_lower.endswith(valid_extensions):
                        # Fuzzy match: Count how many tokens are in the filename
                        score = 0
                        for token in tokens:
                            if token in file_lower:
                                score += 1
                        
                        # Boost score for exact word matches or shorter filenames (closer matches)
                        if score > 0:
                            if target in file_lower: score += 2 # Exact phrase boost
                            
                            if score > highest_score:
                                highest_score = score
                                best_match = (file, os.path.join(root, file))
                            elif score == highest_score and best_match:
                                # If scores are equal, pick the shorter filename as it's likely a better match
                                if len(file_lower) < len(best_match[0].lower()):
                                    best_match = (file, os.path.join(root, file))

        if best_match:
            file_name, file_path = best_match
            try:
                os.startfile(file_path)
                return f"Playing {file_name} from your system."
            except Exception as e:
                print(f"[ERROR] failed to open local file: {e}")
                return "I found the file but failed to open it sir."
                                
        return f"I couldn't find any downloaded media matching {target} in your system sir."

    def capture_and_analyze(self, user_query):
        print("[SYSTEM]: Analyzing screen details...")
        try:
            screenshot = pyautogui.screenshot().resize((1280, 720))
            buffered = BytesIO()
            screenshot.save(buffered, format="JPEG", quality=75) 
            img_str = base64.b64encode(buffered.getvalue()).decode('utf-8')

            payload = {
                "model": VISION_MODEL,
                "messages": [{
                    "role": "user",
                    "content": [
                        {"type": "text", "text": f"You are RISER. Answer based on screen: {user_query}"},
                        {"type": "image_url", "image_url": {"url": f"data:image/jpeg;base64,{img_str}"}}
                    ]
                }]
            }
            res = requests.post(
                url=API_URL,
                headers={"Authorization": f"Bearer {self.api_key}"},
                json=payload,
                timeout=20,
            )
            res.raise_for_status()
            return res.json()['choices'][0]['message']['content']
        except requests.RequestException as exc:
            print("[ERROR] capture_and_analyze request failed:", exc)
            return "Vision link failed: network error."
        except Exception as exc:
            print("[ERROR] capture_and_analyze unexpected error:", exc)
            return "Vision link failed."

    def search_web(self, query):
        try:
            with DDGS() as ddgs:
                results = [r['body'] for r in ddgs.text(query, max_results=3)]
                return results
        except Exception as e:
            print(f"[ERROR] Web search failed: {e}")
            return []

    async def get_proactive_content(self):
        """Fetches a random interesting fact or trending news to share independently."""
        try:
            options = ["interesting space fact", "amazing human body fact", "latest tech news", "fun science fact", "current event in india"]
            import random
            topic = random.choice(options)
            with DDGS() as ddgs:
                # Search for the topic and get a summary
                results = list(ddgs.text(topic, max_results=1))
                if results:
                    content = results[0]['body']
                    # Ask AI to summarize this into a friendly 'Hinglish' message
                    prompt = f"Summarize this info into a short, friendly, exciting 'did you know' message for the user in Hinglish (max 20 words): {content}"
                    summary = await asyncio.to_thread(self.get_ai_response, prompt, context="Proactive independent talk.")
                    return summary
            return "Sir, kya aapko pata hai ki light ki speed 3 lakh kilometers per second hoti hai? Kaafi amazing hai na!"
        except:
            return "Sir, just a random thought: Science is really beautiful, isn't it?"

    async def speak(self, text):
        if not text: return
        
        # Remove AI/Riser prefixes from the response text
        text = re.sub(r'^(ai|riser):\s*', '', text, flags=re.IGNORECASE)
        
        # Keeps letters, spaces, basic punctuation, and Hindi characters (\u0900-\u097F)
        clean_text = re.sub(r'[^\w\s,.\?!:;\'"\-\u0900-\u097F]', '', text)
        
        if not clean_text.strip():
            return
            
        self.log(text, "assistant")
        
        try:
            # Detect language once for the whole text
            selected_voice = self.hi_voice if self.is_hindi(clean_text) else self.en_voice
            
            # --- ULTRA-FAST PARALLEL PRE-FETCHING ---
            # Split text into smaller chunks for instant startup (sentences and clauses)
            chunks = [s.strip() for s in re.split(r'(?<=[,.!?]) +', clean_text) if s.strip()]
            if not chunks: chunks = [clean_text]

            async def fetch_audio_chunk(text_chunk):
                """Background worker to fetch audio for a specific chunk"""
                try:
                    communicate = edge_tts.Communicate(text_chunk, selected_voice, rate="+35%")
                    data = bytearray()
                    async for chunk in communicate.stream():
                        if chunk["type"] == "audio":
                            data.extend(chunk["data"])
                    return data
                except Exception as e:
                    print(f"[ERROR] Fetch chunk failed: {e}")
                    return None

            # Start fetching ALL chunks in parallel to eliminate any gap
            audio_tasks = [asyncio.create_task(fetch_audio_chunk(c)) for c in chunks]

            for task in audio_tasks:
                audio_data = await task  # Wait for current chunk to be ready (others are pre-fetching)
                if audio_data:
                    audio_stream = BytesIO(audio_data)
                    pygame.mixer.music.stop() # Ensure previous is dead
                    pygame.mixer.music.load(audio_stream)
                    pygame.mixer.music.play()
                    
                    # Wait for current chunk to finish
                    while pygame.mixer.music.get_busy(): 
                        await asyncio.sleep(0.01) # Low latency polling
                    
                    pygame.mixer.music.unload()
        except Exception as e:
            print(f"[ERROR] Parallel speak failed: {e}")

    # --- SYNC STT LOGIC ---

    def _listen_for_audio(self):
        """Pure Synchronous Listen Logic (User's Exact Format)"""
        if self.microphone is None: return None
        with self.microphone as source:
            print("Listening...")
            audio = self.recognizer.listen(source)
        try:
            if self.is_speaking: return None
            text = self.recognizer.recognize_google(audio, language=self.language)
            print("You said: " + text)
            
            if len(text.strip()) >= 2:
                self.log(text, "user")
                return text.lower()

        except speech_recognition.UnknownValueError:
            pass

        except speech_recognition.RequestError as e:
            print(f"Could not request results; {e}")

        except Exception as e:
            # Generic catch for other errors
            pass

    def get_ai_response(self, user_input, context=""):
        if not self.api_key:
            return "OpenRouter API Key mismatch."

        try:
            # --- MEMORY INJECTION ---
            # We tell the AI everything it remembers about the user
            memory_context = ""
            if self.user_memory:
                memory_context = "THINGS YOU REMEMBER ABOUT USER: " + json.dumps(self.user_memory)

            system_prompt = (
                f"You are {self.ai_name}. {self.system_prompt} "
                "You are caring, friendly, and act like a best friend. You speak primarily in 'Hinglish' (a natural mix of Hindi and English) which is common in India. "
                "Keep responses short, human-like, and avoid robotic phrases. Focus only on the current user. "
                f"{memory_context}\n{context}"
            )

            headers = {
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type": "application/json",
                "HTTP-Referer": "https://risercorporation.github.io/riser/", 
                "X-Title": f"{self.ai_name}"
            }
            
            payload = {
                "model": MODEL_ID,
                "messages": [
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_input}
                ],
                "temperature": 0.7,
                "max_tokens": 150
            }

            response = requests.post(API_URL, headers=headers, json=payload, timeout=15)
            if response.status_code == 200:
                result = response.json()
                return result['choices'][0]['message']['content'].strip()
            else:
                return f"Error: {response.text}"
        except Exception as e:
            return f"I'm having trouble connecting right now, sir. Error: {e}"

    async def main_loop(self):
        self.loop = asyncio.get_running_loop()
        self.audio_queue = asyncio.Queue()
        
        webbrowser.open(GUI_URL)
        
        # Balanced Gate for noisy environments
        self.recognizer.energy_threshold = 4000
        self.recognizer.pause_threshold = 0.8
        
        self.log(f"Mic Ready. Clean Mode Activated.", "system")

        # Enable Stable Background Listening
        self.is_speaking = False 
        self.is_speaking = False 
        # Using simple listen logic instead of background threads
        # self.stop_listening = self.recognizer.listen_in_background(self.microphone, self.recognize_callback, phrase_time_limit=7)
        async def health_monitor():
            """Proactive Laptop Health Watcher"""
            while self.is_listening:
                battery = psutil.sensors_battery()
                if battery and battery.percent < 20 and not battery.power_plugged and not self.battery_alerted:
                    await self.speak(f"Pardon me Sir, but your laptop battery is quite low at {battery.percent} percent. Please plug in the charger.")
                    self.battery_alerted = True
                elif battery and battery.power_plugged:
                    self.battery_alerted = False # Reset alert
                
                # RAM Check (Advanced alert if RAM > 90%)
                ram = psutil.virtual_memory()
                if ram.percent > 90 and not self.is_speaking:
                    await self.speak("Sir, I noticed high RAM usage on your laptop. You might want to close some background apps for better performance.")
                
                await asyncio.sleep(600) # Check every 10 mins

        asyncio.create_task(health_monitor())
        print("\n[LIVE]: Riser is listening in the background...")
        
        last_interaction_time = time.time()
        

        last_interaction_time = time.time()
        awaiting_idle_response = False
        idle_question_time = 0

        while self.is_listening:
            try:
                # Get voice queries using simpler blocking listen (User's pattern)
                query = await asyncio.to_thread(self._listen_for_audio)
                if query is None:
                    query = "idle_timeout"
            except Exception as e:
                print(f"[ERROR]: Audio capturing failed: {e}")
                query = "idle_timeout"

            if query == "idle_timeout":
                current_time = time.time()
                
                # Agar user 1 baar answer nahi deta, to Riser pareshan karna band kar dega
                if self.user_away:
                    continue

                if awaiting_idle_response:
                    if current_time - idle_question_time > 15: 
                        import random
                        follow_ups = [
                            f"Hey, {self.ai_name} here. Lagta hai aap aas pass nahi hain. Kya aap bahar gaye hain?",
                            "Sir, aapne kuch kaha nahi, shayad aap kaam me busy hain. Jab free hon tab batana.",
                            "Koi awaaz nahi aa rahi... are you there?",
                            "Lagta hai sir busy hain. Main yahin hoon, waiting mode on."
                        ]
                        self.is_speaking = True
                        await self.speak(random.choice(follow_ups))
                        awaiting_idle_response = False
                        self.user_away = True  # Stop asking until user speaks
                        
                        # Clear old noise trapped during speaking
                        while not self.audio_queue.empty():
                            try: self.audio_queue.get_nowait()
                            except: pass
                        self.is_speaking = False
                else:
                    # --- Wait 1 Hour 30 Minutes (5400 seconds) ---
                    if current_time - last_interaction_time > 5400:
                        self.is_speaking = True
                        # Get a proactive news/fact instead of generic prompt
                        proactive_speech = await self.get_proactive_content()
                        await self.speak(proactive_speech)
                            
                        awaiting_idle_response = True
                        idle_question_time = time.time()
                        
                        # Clear old noise
                        while not self.audio_queue.empty():
                            try: self.audio_queue.get_nowait()
                            except: pass
                        self.is_speaking = False
                continue

            # --- MEMORY EXTRACTION (Smart Friend Logic) ---
            # If user tells something important, save it
            if any(k in query.lower() for k in ["my name is", "i like", "remember", "remember that", "mera naam", "i live in"]):
                # Extract key info using simple logic or store the whole sentence for AI to parse
                memory_key = f"info_{int(time.time())}"
                self.user_memory[memory_key] = query
                self._save_memory()
                print(f"[SYSTEM]: Information remembered: {query}")

            if not query:
                continue

            # --- PREVENT CONVERSATION OVERLAP ---
            self.user_away = False
            last_interaction_time = time.time()
            awaiting_idle_response = False
            self.is_speaking = True 

            try:
                # Command Processors
                # --- SHUTDOWN COMMAND (As requested) ---
                if any(word in query for word in ["shutdown", "shut down", "power off", "laptop band karo"]):
                    await self.speak("Shutting down the system Sir. Goodbye!")
                    await self.smart_shutdown()
                    break

                reply = self.handle_laptop_command(query)
                if reply is not None:
                    await self.speak(reply)
                    
                # --- CLOSE/CUT BACKGROUND WINDOW COMMAND ---
                elif any(phrase in query for phrase in ["close window", "cut window", "close this window", "close background window", "cut background window"]):
                    pyautogui.hotkey('alt', 'f4')
                    await self.speak("Window closed sir.")

                # --- TIME / KITNE BAJE HAIN ---
                elif any(word in query for word in ["time", "kitne baje", "samay", "baj rahe"]):
                    current_time = time.strftime("%I:%M %p")
                    context_time = f"The current real time is {current_time}. Tell the user naturally in Hinglish/English."
                    ans = await asyncio.to_thread(self.get_ai_response, query, context=context_time)
                    await self.speak(ans)

                # --- DYNAMIC CREATOR / PURPOSE RESPONSE ---
                elif any(phrase in query for phrase in ["who made you", "who created you", "tumhe kisne banaya", "kisliye banaya", "why were you created", "tumhe banaya"]):
                    context_info = "Answer naturally in varying sentences. Fact: You were created by Soham Sardar and his team Riser specifically for the Aura International School science project."
                    ans = await asyncio.to_thread(self.get_ai_response, query, context=context_info)
                    await self.speak(ans)

                # --- TIMER, STOPWATCH & ALARM COMMAND (Blocks Terminal) ---
                elif any(word in query for word in ["timer", "stopwatch", "alarm"]) and any(char.isdigit() for char in query):
                    match = re.search(r'(\d+)\s*(second|minute|hour|sec|min|hr)', query)
                    if match:
                        value = int(match.group(1))
                        unit = match.group(2)
                        if "min" in unit or "minute" in unit: 
                            total_seconds = value * 60
                        elif "hour" in unit or "hr" in unit: 
                            total_seconds = value * 3600
                        else: 
                            total_seconds = value
                        
                        await self.speak(f"Setting {unit} timer for {value}. Counting down on your terminal sir.")
                        
                        # Blocking loop to disable input/output
                        self.is_speaking = True 
                        for i in range(total_seconds, 0, -1):
                            print(f"\r[STOPWATCH/TIMER]: {i} seconds remaining...", end="", flush=True)
                            await asyncio.sleep(1)
                        print("\r[STOPWATCH/TIMER]: Time is UP!                                      ")
                        
                        # Flush background noise caught during timer
                        while not self.audio_queue.empty():
                            try: self.audio_queue.get_nowait()
                            except: pass
                            
                        await self.speak("Sir, your timer is up!")
                    else:
                        await self.speak("Please specify the time clearly, for example, set timer for 10 seconds.")
                    
                elif "play" in query and "downloaded" not in query and ("youtube" in query or "play" in query):
                    await self.speak("Playing video for you now.")
                    self.play_on_youtube(query)
                    ans = await asyncio.to_thread(self.get_ai_response, "Please start a human-friendly, casual and warm chat right now.", context="We just started playing a YouTube video for the user.")
                    await self.speak(ans)
                    
                elif "play" in query and ("downloaded" in query or "system" in query):
                    await self.speak("Searching your system...")
                    ans = self.play_local_media(query)
                    await self.speak(ans)
                    
                elif "download" in query and any(word in query for word in ["anime", "series", "episode"]):
                    await self.speak("Sure sir, searching across the internet for full episodes to download.")
                    self.search_and_download_anime(query)
                
                # --- NEW ADDITION FOR SECOND PROJECT ---
                elif "open our second project" in query:
                    await self.speak("Opening our second project sir.")
                    webbrowser.open("https://risercorporation.github.io/magic/")
                    
                elif "open" in query and "website" in query or re.match(r".*\bopen\b \b\w+\b\s?(website)?", query):
                    site_name = self.open_website(query)
                    if site_name:
                        await self.speak(f"Opening {site_name} for you sir.")
                        
                elif "open our next project" in query and "website" in query or re.match(r".*\bopen\b \b\w+\b\s?(website)?", query):
                    site_name = self.open_website()
                    if site_name:
                        await self.speak(f"Opening {site_name} for you sir.")
                        
                elif "weather" in query or "mausam" in query:
                    await self.speak("Checking the latest weather for you sir...")
                    res = self.handle_laptop_command(query)
                    if res and "Context:" in res:
                        ans = await asyncio.to_thread(self.get_ai_response, query, context=res)
                        await self.speak(ans)
                    else:
                        await self.speak("Sir, I'm having trouble fetching live weather right now. Check your internet.")

                elif any(word in query for word in ["look", "see", "screen", "analyze"]):
                    await self.speak("Analyzing...")
                    ans = self.capture_and_analyze(query)
                    await self.speak(ans)
                    
                elif any(word in query for word in ["news", "latest", "today"]):
                    results = self.search_web(query)
                    search_data = " | ".join(results)
                    ans = await asyncio.to_thread(self.get_ai_response, query, context=search_data)
                    await self.speak(ans)
                    
                else:
                    ans = await asyncio.to_thread(self.get_ai_response, query)
                    await self.speak(ans)
                
                # --- QUEUE FLUSHER --- 
                while not self.audio_queue.empty():
                    try:
                        self.audio_queue.get_nowait()
                    except:
                        pass
            except Exception as e:
                print(f"[ERROR] Main loop processing error: {e}")
            finally:
                self.is_speaking = False 
                await asyncio.sleep(0.05)

if __name__ == "__main__":
    jarvis_instance = Jarvis()
    try:
        asyncio.run(jarvis_instance.main_loop())
    except KeyboardInterrupt:
        print("\n[SYSTEM]: Shutting down Riser...")