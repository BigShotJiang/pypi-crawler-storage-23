"""Tests for embedding server module."""

from __future__ import annotations

from pydantic import ValidationError

from sagellm_core.embedding_server import EmbeddingRequest, app


def test_embedding_server_routes_exist() -> None:
    routes = [route.path for route in app.routes]
    assert "/health" in routes
    assert "/v1/embeddings" in routes


def test_embedding_request_model_accepts_string_and_list() -> None:
    single = EmbeddingRequest(model="m", input="hello")
    batch = EmbeddingRequest(model="m", input=["a", "b"])

    assert single.input == "hello"
    assert batch.input == ["a", "b"]


def test_embedding_request_model_requires_input() -> None:
    try:
        EmbeddingRequest(model="m")
    except ValidationError:
        assert True
        return

    raise AssertionError("EmbeddingRequest should require input")
