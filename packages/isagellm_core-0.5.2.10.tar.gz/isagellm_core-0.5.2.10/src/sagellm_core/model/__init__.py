"""Model loading for sageLLM.

This module provides model loading with two strategies:

1. **LayerWiseModelLoader** (Preferred for supported models):
   - Constructs models layer-by-layer using custom layers (CustomLinear, CustomRMSNorm)
   - Enables backend kernel injection for optimization
   - Loads HF weights into custom layers
   - Currently supports: Llama, Qwen model families
   - Issue #35 - ModelLoader 重构 - 支持逐层模型构建

2. **HFModelLoader** (Universal fallback):
   - Uses HuggingFace transformers directly
   - Supports all HF models
   - Does not enable kernel injection
   - Previous default loader

Architecture decision (2026-02):
    sageLLM supports both HF-first and custom layer approaches:
    - LayerWiseModelLoader: For models needing kernel injection (Llama, Qwen, etc.)
    - HFModelLoader: For all other models or when kernel injection not needed
    - get_model_loader(): Auto-selects best loader for the model

Model loading:
- ModelLoadConfig: Configuration for model loading
- get_model_loader: Factory to get appropriate loader (LayerWise or HF)
- LayerWiseModelLoader: Custom layer-based loader with kernel injection support
- HFModelLoader: HuggingFace compatible loader (universal fallback)
- LayerWiseModelBuilder: Base class for model architecture builders

Quantization:
- QuantConfig: Quantization configuration
- detect_quantization: Auto-detect quantization format
"""

# Model loading configuration and loaders
from sagellm_core.model.load_config import ModelLoadConfig
from sagellm_core.model.loader import ModelLoader as BaseModelLoader, get_model_loader
from sagellm_core.model.hf_loader import HFModelLoader

# Layer-wise model loading (issue #35)
from sagellm_core.model.layerwise_loader import LayerWiseModelLoader
from sagellm_core.model.architectures import (
    LayerWiseModelBuilder,
    get_model_builder,
    LlamaModelBuilder,
    QwenModelBuilder,
)

# Quantization
from sagellm_core.model.quantization import (
    QuantConfig,
    QuantizationType,
    detect_quantization,
)

# Legacy compatibility — simple HF loader utility
from sagellm_core.model.model_loader import ModelLoader, load_model

__all__ = [
    # Model loading
    "ModelLoadConfig",
    "BaseModelLoader",
    "get_model_loader",
    "HFModelLoader",
    # Layer-wise loading (issue #35)
    "LayerWiseModelLoader",
    "LayerWiseModelBuilder",
    "get_model_builder",
    "LlamaModelBuilder",
    "QwenModelBuilder",
    # Quantization
    "QuantConfig",
    "QuantizationType",
    "detect_quantization",
    # Legacy
    "ModelLoader",
    "load_model",
]
