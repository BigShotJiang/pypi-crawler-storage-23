**Configure stages**

Go to "Management System -\> Configuration -\> Actions -\> Stages"

**Configure tags**

Go to "Management System -\> Configuration -\> Actions -\> Tags"
