"""Dataset loading, formatting, and collation."""
