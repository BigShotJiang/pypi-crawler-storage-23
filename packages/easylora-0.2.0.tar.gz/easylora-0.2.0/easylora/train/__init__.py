"""Training loop, callbacks, and the EasyLoRATrainer facade."""
