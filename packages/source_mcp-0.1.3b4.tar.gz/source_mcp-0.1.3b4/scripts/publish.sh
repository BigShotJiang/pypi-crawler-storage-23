#!/usr/bin/env bash

set -e # Остановка при ошибке

# Переходим в корень проекта, если скрипт запущен из другой папки
cd "$(dirname "$0")/.."

echo "📦 Собираем пакет..."
uv build

echo "🚀 Публикуем пакет на PyPI..."
export $(grep -v '^#' .env | xargs) && uv publish

echo "✅ Готово!"
