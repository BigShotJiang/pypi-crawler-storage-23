from fastembed.rerank.cross_encoder import TextCrossEncoder
print([m["model"] for m in TextCrossEncoder.list_supported_models()])
