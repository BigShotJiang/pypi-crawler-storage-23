# Kevros Governance Middleware for Microsoft Agent Framework

Cryptographic authorization, intent binding, and hash-chained provenance for AI agents built on the [Microsoft Agent Framework](https://github.com/microsoft/agent-framework).

## Install

```bash
pip install kevros-agent-framework
```

## Quick Start

```python
from kevros_agent_framework import (
    KevrosGovernanceMiddleware,
    KevrosFunctionMiddleware,
    KevrosConfig,
    KevrosGovernanceClient,
)
from agent_framework import Agent

# Configure -- API key auto-provisions on first use if omitted
config = KevrosConfig(api_key="kvrs_...")
client = KevrosGovernanceClient(config)

# Attach both middleware types, sharing a single client
agent = Agent(
    client=chat_client,
    name="governed-assistant",
    instructions="You are a helpful assistant.",
    middleware=[
        KevrosGovernanceMiddleware(config=config, client=client),
        KevrosFunctionMiddleware(config=config, client=client),
    ],
)
```

## What It Does

Every agent invocation and tool call is cryptographically governed:

- **Precision decisioning** -- Each agent run is verified against governance policy (ALLOW / CLAMP / DENY) with an HMAC-signed release token
- **Intent binding** -- Each function call gets a cryptographic intent-to-command binding before execution
- **Hash-chained provenance** -- Every decision is logged to an append-only, tamper-evident ledger

## Comparison with Purview Policy Middleware

| Aspect | Purview | Kevros |
|--------|---------|--------|
| Purpose | Content-level DLP (redact PII, block topics) | Cryptographic authorization + audit evidence |
| Proof | None (rule-based decision) | HMAC release tokens, hash-chained provenance |
| Scope | Message content filtering | Action authorization, intent binding, provenance |
| Relationship | Complementary | Complementary |

Use both: Purview for content safety, Kevros for authorization and evidence.

## Links

- [Kevros Governance Gateway](https://governance.taskhawktech.com)
- [Agent Card](https://governance.taskhawktech.com/.well-known/agent.json)
- [Website](https://taskhawktech.com)

## License

BSL-1.1 -- See LICENSE for details.
