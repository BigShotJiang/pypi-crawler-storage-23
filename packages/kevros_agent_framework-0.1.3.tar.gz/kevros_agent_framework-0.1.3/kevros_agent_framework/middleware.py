"""
KevrosGovernanceMiddleware -- Agent-level governance for Microsoft Agent Framework.

Intercepts agent run execution to verify authorization before the agent acts.
Uses GovernanceProvider protocol -- works with both remote and embedded backends.

Usage:
    from kevros_agent_framework import KevrosGovernanceMiddleware, KevrosConfig

    config = KevrosConfig(api_key="kvrs_...")
    kevros = KevrosGovernanceMiddleware(config=config)

    agent = Agent(client=client, name="assistant", middleware=[kevros])
"""

from __future__ import annotations

import logging
from collections.abc import Awaitable, Callable
from typing import Any

from .config import KevrosConfig
from .models import Decision, VerifyRequest

logger = logging.getLogger("kevros.middleware")


def _build_provider(config: KevrosConfig, client=None):
    """Build the appropriate governance provider based on config."""
    if config.embedded:
        from .embedded import EmbeddedGovernanceProvider
        # Caller must pass a pre-built embedded provider via client param
        if client is None:
            raise ValueError(
                "Embedded mode requires passing an EmbeddedGovernanceProvider as 'client'. "
                "Create one with: EmbeddedGovernanceProvider(services, hmac_key_hex)"
            )
        return client
    else:
        if client is not None:
            return client
        from .client import KevrosGovernanceClient
        return KevrosGovernanceClient(config)


class GovernanceDeniedException(Exception):
    """Raised when Kevros governance denies an agent action."""

    def __init__(self, message: str, decision: Any = None) -> None:
        super().__init__(message)
        self.decision = decision


# ---------------------------------------------------------------------------
# AgentMiddleware -- adapted from Step 0 discovery of agent-framework v1.0.0rc1
# Context class is AgentContext (not AgentRunContext).
# call_next takes NO arguments: call_next: Callable[[], Awaitable[None]]
# ---------------------------------------------------------------------------

from agent_framework import AgentMiddleware, AgentContext


class KevrosGovernanceMiddleware(AgentMiddleware):
    """
    Kevros governance middleware for Microsoft Agent Framework.

    Verifies agent authorization via the Kevros governance provider
    before allowing agent execution. Provides cryptographic proof of
    authorization and hash-chained provenance logging.

    Analogous to PurviewPolicyMiddleware but for cryptographic authorization
    and audit-grade evidence rather than content-level DLP.
    """

    def __init__(self, config: KevrosConfig | None = None, client=None) -> None:
        self._config = config or KevrosConfig()
        self._provider = _build_provider(self._config, client)

    async def process(
        self,
        context: AgentContext,
        call_next: Callable[[], Awaitable[None]],
    ) -> None:
        """
        Intercept agent execution for governance verification.

        Pre-execution: Verify authorization.
        If DENY: raise GovernanceDeniedException (fail-closed).
        If CLAMP: attach metadata, proceed.
        If ALLOW: proceed.
        If unreachable: fail_closed=True raises, fail_closed=False proceeds.
        """
        # --- Extract context ---
        agent_id = self._config.agent_id or _extract_agent_id(context)
        action_type, action_payload = _extract_action(context)

        verify_req = VerifyRequest(
            action_type=action_type,
            action_payload=action_payload,
            agent_id=agent_id,
        )

        # --- Call provider ---
        try:
            result = await self._provider.verify(verify_req)
        except Exception as exc:
            if self._config.fail_closed:
                logger.error("Kevros governance unreachable (fail_closed=True): %s", exc)
                raise GovernanceDeniedException(
                    "Kevros governance unreachable and fail_closed is enabled."
                ) from exc
            else:
                logger.warning("Kevros governance unreachable (fail_closed=False): %s", exc)
                await call_next()
                return

        if self._config.log_decisions:
            logger.info(
                "Kevros: %s | agent=%s action_type=%s epoch=%d",
                result.decision.value, agent_id, action_type, result.epoch,
            )

        if result.decision == Decision.DENY:
            raise GovernanceDeniedException(
                f"Kevros DENY: {result.reason or 'Action not authorized'}",
                decision=result,
            )

        if result.decision == Decision.CLAMP:
            logger.warning("Kevros CLAMP: %s", result.reason)
            _attach_metadata(context, result)

        await call_next()


# ---------------------------------------------------------------------------
# Context extraction -- based on Step 0 discovery of AgentContext API
# ---------------------------------------------------------------------------
# AgentContext has: .agent, .messages, .session, .options, .stream, .metadata (dict), .result, .kwargs

def _extract_agent_id(context) -> str:
    """Extract agent identifier from AgentContext."""
    if hasattr(context, "agent") and hasattr(context.agent, "name"):
        return context.agent.name or "unknown-agent"
    return "agent-framework-agent"


def _extract_action(context) -> tuple[str, dict]:
    """
    Extract action_type and action_payload from AgentContext.

    Returns (action_type, action_payload) matching VerifyRequest schema.
    action_type is a short classifier. action_payload is the full context.
    """
    action_payload: dict[str, Any] = {}

    # Try to get the user message as the action description
    if hasattr(context, "messages") and context.messages:
        last_msg = context.messages[-1]
        if hasattr(last_msg, "text") and last_msg.text:
            action_payload["user_message"] = last_msg.text[:500]

    if hasattr(context, "agent") and hasattr(context.agent, "instructions"):
        import hashlib
        instructions = context.agent.instructions or ""
        action_payload["instructions_hash"] = hashlib.sha256(instructions.encode()).hexdigest()[:16]

    return ("agent_run", action_payload)


def _attach_metadata(context, result) -> None:
    """Attach governance decision to context for downstream middleware."""
    metadata = {
        "kevros_decision": result.decision.value,
        "kevros_release_token": result.release_token,
        "kevros_epoch": result.epoch,
        "kevros_verification_id": result.verification_id,
    }
    if result.applied_action:
        metadata["kevros_applied_action"] = result.applied_action

    if hasattr(context, "metadata") and isinstance(context.metadata, dict):
        context.metadata.update(metadata)
    elif hasattr(context, "state") and isinstance(context.state, dict):
        context.state.update(metadata)
