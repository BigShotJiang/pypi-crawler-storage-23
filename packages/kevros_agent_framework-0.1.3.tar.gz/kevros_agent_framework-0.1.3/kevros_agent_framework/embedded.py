"""
Embedded governance provider -- local enforcement via GatewayServices.

For air-gapped networks, latency-critical systems, and ITAR workloads
where governance decisions cannot leave the host.

Requires: pip install kevros-agent-framework[embedded]

The embedded provider makes the same calls the gateway routers make:
same stores, same hash chains, same PQC signatures. The only difference
is no HTTP round-trip and no API key authentication (local trust boundary).
"""

from __future__ import annotations

import hashlib
import hmac as hmac_mod
import logging
import uuid as uuid_mod
from datetime import datetime, timezone
from typing import TYPE_CHECKING, Any, Optional

from .models import (
    AttestRequest, AttestResponse,
    BindIntentRequest, BindIntentResponse,
    Decision,
    VerifyRequest, VerifyResponse,
    VerifyOutcomeRequest, VerifyOutcomeResponse,
    OutcomeStatus,
)

if TYPE_CHECKING:
    from a2a_gateway.services import GatewayServices

logger = logging.getLogger("kevros.middleware.embedded")


def _now_utc() -> str:
    return datetime.now(timezone.utc).isoformat()


class EmbeddedGovernanceProvider:
    """
    Local governance enforcement using GatewayServices.

    Implements the same GovernanceProvider protocol as KevrosGovernanceClient.
    Executes the same governance logic as the gateway routers but in-process.
    """

    def __init__(self, services: GatewayServices, hmac_key_hex: str) -> None:
        """
        Args:
            services: A GatewayServices instance (from create_default_services)
            hmac_key_hex: The gateway HMAC key (same as A2A_GATEWAY_HMAC_KEY)
        """
        self._svc = services
        self._hmac_key = bytes.fromhex(hmac_key_hex)

    def _hmac_sign(self, data: bytes) -> str:
        return hmac_mod.new(self._hmac_key, data, hashlib.sha256).hexdigest()

    def _canonical_json(self, obj: Any) -> bytes:
        """Canonical JSON for deterministic hashing. Matches gateway's _canonical_json."""
        import json
        return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=True).encode("utf-8")

    async def verify(self, request: VerifyRequest) -> VerifyResponse:
        """Action verification -- mirrors governance.verify_action logic."""
        epoch = next(self._svc.epoch_counter)
        verification_id = str(uuid_mod.uuid4())
        now = _now_utc()

        try:
            action = request.action_payload
            policy = request.policy_context or {}
            decision = Decision.ALLOW
            applied_action = dict(action)
            reason = "Action within policy bounds"

            if "max_values" in policy:
                for key, max_val in policy["max_values"].items():
                    if key in action and isinstance(action[key], (int, float)):
                        if action[key] > max_val:
                            applied_action[key] = max_val
                            decision = Decision.CLAMP
                            reason = f"Clamped {key} from {action[key]} to {max_val}"

            if "forbidden_keys" in policy:
                for key in policy["forbidden_keys"]:
                    if key in action:
                        decision = Decision.DENY
                        reason = f"Action contains forbidden key: {key}"
                        applied_action = None
                        break

            record = {
                "verification_id": verification_id,
                "epoch": epoch,
                "decision": decision.value,
                "agent_id": request.agent_id,
                "action_type": request.action_type,
                "timestamp_utc": now,
            }
            record_bytes = self._canonical_json(record)
            record_hash = hashlib.sha256(record_bytes).hexdigest()
            hash_prev, hash_curr = self._svc.provenance_store.append(record)

            release_token = None
            if decision in (Decision.ALLOW, Decision.CLAMP):
                token_preimage = f"KEVROSv1|{decision.value}|{epoch}|{hash_prev}|{record_hash}".encode()
                release_token = self._hmac_sign(token_preimage)

            return VerifyResponse(
                decision=decision,
                verification_id=verification_id,
                release_token=release_token,
                applied_action=applied_action,
                policy_applied=policy,
                reason=reason,
                epoch=epoch,
                provenance_hash=hash_curr,
                hash_prev=hash_prev,
                timestamp_utc=now,
            )
        except Exception:
            deny_record = {"verification_id": verification_id, "epoch": epoch, "decision": "DENY", "timestamp_utc": _now_utc()}
            _, hash_curr = self._svc.provenance_store.append(deny_record)
            return VerifyResponse(
                decision=Decision.DENY,
                verification_id=verification_id,
                reason="Internal verification error -- fail-closed DENY",
                epoch=epoch,
                provenance_hash=hash_curr,
                timestamp_utc=_now_utc(),
            )

    async def attest(self, request: AttestRequest) -> AttestResponse:
        """Provenance attestation -- mirrors governance.attest_action logic."""
        epoch = next(self._svc.epoch_counter)
        attestation_id = str(uuid_mod.uuid4())
        now = _now_utc()

        record = {
            "attestation_id": attestation_id,
            "epoch": epoch,
            "agent_id": request.agent_id,
            "action_description": request.action_description,
            "action_payload_hash": hashlib.sha256(self._canonical_json(request.action_payload)).hexdigest(),
            "context_hash": hashlib.sha256(self._canonical_json(request.context or {})).hexdigest(),
            "timestamp_utc": now,
        }
        hash_prev, hash_curr = self._svc.provenance_store.append(record)

        return AttestResponse(
            attestation_id=attestation_id,
            epoch=epoch,
            hash_prev=hash_prev,
            hash_curr=hash_curr,
            pqc_block_ref=None,  # PQC signing delegated to sync process in embedded mode
            timestamp_utc=now,
            chain_length=self._svc.provenance_store.chain_length,
        )

    async def bind_intent(self, request: BindIntentRequest) -> BindIntentResponse:
        """Intent binding -- mirrors governance.bind_intent logic."""
        epoch = next(self._svc.epoch_counter)
        intent_id = str(uuid_mod.uuid4())
        binding_id = str(uuid_mod.uuid4())
        now = _now_utc()

        intent_canonical = {
            "intent_id": intent_id,
            "intent_type": request.intent_type.value,
            "description": request.intent_description,
            "goal_state": request.goal_state,
            "source": request.intent_source.value,
            "source_id": request.agent_id,
            "parent_intent_id": request.parent_intent_id,
            "declared_utc": now,
        }
        intent_hash = hashlib.sha256(self._canonical_json(intent_canonical)).hexdigest()
        command_hash = hashlib.sha256(self._canonical_json(request.command_payload)).hexdigest()

        binding_preimage = intent_hash.encode() + b"|" + command_hash.encode() + b"|" + str(epoch).encode()
        binding_hmac = self._hmac_sign(binding_preimage)

        self._svc.intent_store.put(intent_id, {
            "intent_id": intent_id, "intent_hash": intent_hash,
            "binding_id": binding_id, "binding_hmac": binding_hmac,
            "command_hash": command_hash, "goal_state": request.goal_state,
            "agent_id": request.agent_id, "epoch": epoch, "timestamp_utc": now,
        })

        record = {
            "type": "intent_binding", "intent_id": intent_id, "binding_id": binding_id,
            "epoch": epoch, "agent_id": request.agent_id,
            "intent_hash": intent_hash, "command_hash": command_hash, "timestamp_utc": now,
        }
        self._svc.provenance_store.append(record)

        return BindIntentResponse(
            intent_id=intent_id, intent_hash=intent_hash,
            binding_id=binding_id, binding_hmac=binding_hmac,
            command_hash=command_hash, epoch=epoch, timestamp_utc=now,
        )

    async def verify_outcome(self, request: VerifyOutcomeRequest) -> VerifyOutcomeResponse:
        """Outcome verification -- mirrors governance.verify_outcome logic."""
        verification_id = str(uuid_mod.uuid4())
        now = _now_utc()

        intent_record = self._svc.intent_store.get(request.intent_id)
        if not intent_record:
            raise ValueError(f"Intent {request.intent_id} not found")
        if intent_record["binding_id"] != request.binding_id:
            raise ValueError("Binding ID mismatch")

        goal = intent_record.get("goal_state") or {}
        actual = request.actual_state
        status = OutcomeStatus.ACHIEVED
        achieved_pct = 100.0
        discrepancy = None

        if goal:
            matches = 0
            total = len(goal)
            delta = {}
            for key, expected in goal.items():
                actual_val = actual.get(key)
                if actual_val == expected:
                    matches += 1
                elif isinstance(expected, (int, float)) and isinstance(actual_val, (int, float)):
                    if abs(actual_val - expected) <= abs(expected * request.tolerance):
                        matches += 1
                    else:
                        delta[key] = {"expected": expected, "actual": actual_val}
                else:
                    delta[key] = {"expected": expected, "actual": actual_val}

            achieved_pct = (matches / total * 100) if total > 0 else 100.0
            discrepancy = delta if delta else None
            if achieved_pct >= 100.0:
                status = OutcomeStatus.ACHIEVED
            elif achieved_pct >= 50.0:
                status = OutcomeStatus.PARTIALLY_ACHIEVED
            else:
                status = OutcomeStatus.FAILED

        evidence = {
            "verification_id": verification_id, "agent_id": request.agent_id,
            "intent_id": request.intent_id, "status": status.value,
            "achieved_percentage": achieved_pct, "timestamp_utc": now,
        }
        evidence_hash = hashlib.sha256(self._canonical_json(evidence)).hexdigest()
        self._svc.provenance_store.append(evidence)

        return VerifyOutcomeResponse(
            verification_id=verification_id, intent_id=request.intent_id,
            status=status, achieved_percentage=achieved_pct,
            discrepancy=discrepancy, evidence_hash=evidence_hash, timestamp_utc=now,
        )

    async def health(self) -> bool:
        """Always healthy -- local enforcement."""
        return True

    async def close(self) -> None:
        """No-op for embedded mode."""
        pass
