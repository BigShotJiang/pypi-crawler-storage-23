"""Tests for KevrosFunctionMiddleware with real gateway schemas.

Adapted from Step 0: call_next() takes no args.
"""

import pytest
import respx
import httpx
from unittest.mock import MagicMock

from kevros_agent_framework import KevrosConfig, KevrosGovernanceClient
from kevros_agent_framework.function_middleware import KevrosFunctionMiddleware


@pytest.fixture
def config():
    return KevrosConfig(
        gateway_url="https://test-gateway.example.com",
        api_key="kvrs_test_key",
        fail_closed=True,
        bind_intents=True,
        record_outcomes=True,
        retry_backoff_seconds=0.01,
    )


@pytest.fixture
def client(config):
    return KevrosGovernanceClient(config)


@pytest.fixture
def func_middleware(config, client):
    return KevrosFunctionMiddleware(config=config, client=client)


def _mock_func_context():
    ctx = MagicMock()
    ctx.function = MagicMock()
    ctx.function.name = "get_weather"
    ctx.arguments = {"city": "Seattle"}
    ctx.result = None
    return ctx


def _bind_response_json():
    """Real BindIntentResponse schema."""
    return {
        "intent_id": "intent_abc123",
        "intent_hash": "sha256hex_intent",
        "binding_id": "binding_xyz789",
        "binding_hmac": "hmachex_binding",
        "command_hash": "sha256hex_command",
        "epoch": 42,
        "timestamp_utc": "2026-02-24T12:00:00+00:00",
    }


def _outcome_response_json():
    """Real VerifyOutcomeResponse schema."""
    return {
        "verification_id": "ver_outcome_001",
        "intent_id": "intent_abc123",
        "status": "ACHIEVED",
        "achieved_percentage": 100.0,
        "discrepancy": None,
        "evidence_hash": "sha256hex_evidence",
        "timestamp_utc": "2026-02-24T12:01:00+00:00",
    }


@respx.mock
@pytest.mark.asyncio
async def test_intent_bind_and_outcome_verify(func_middleware):
    respx.post("https://test-gateway.example.com/governance/bind").mock(
        return_value=httpx.Response(200, json=_bind_response_json())
    )
    respx.post("https://test-gateway.example.com/governance/verify-outcome").mock(
        return_value=httpx.Response(200, json=_outcome_response_json())
    )
    ctx = _mock_func_context()
    async def mock_next():
        ctx.result = {"temperature": 72, "unit": "F"}
    await func_middleware.process(ctx, mock_next)
    assert respx.calls.call_count == 2


@respx.mock
@pytest.mark.asyncio
async def test_function_error_still_records_outcome(func_middleware):
    respx.post("https://test-gateway.example.com/governance/bind").mock(
        return_value=httpx.Response(200, json=_bind_response_json())
    )
    respx.post("https://test-gateway.example.com/governance/verify-outcome").mock(
        return_value=httpx.Response(200, json=_outcome_response_json())
    )
    ctx = _mock_func_context()
    async def failing_next():
        raise ValueError("API returned 500")
    with pytest.raises(ValueError):
        await func_middleware.process(ctx, failing_next)
    outcome_calls = [c for c in respx.calls if "/governance/verify-outcome" in str(c.request.url)]
    assert len(outcome_calls) == 1
