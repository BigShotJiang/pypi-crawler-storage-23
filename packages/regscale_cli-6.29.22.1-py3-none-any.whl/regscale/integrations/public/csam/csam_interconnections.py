#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Integrates CSAM into RegScale"""

# standard python imports
import logging
from typing import List, Optional

from rich.progress import track

from regscale.integrations.public.csam.csam_common import (
    CSAM_FIELD_NAME,
    SSP_BASIC_TAB,
    retrieve_from_csam,
    retrieve_ssps_custom_form_map,
)
from regscale.models.regscale_models import InterConnection, User
from regscale.models.regscale_models.form_field_value import FormFieldValue
from regscale.models.regscale_models.regscale_model import RegScaleModel

logger = logging.getLogger("regscale")
CUSTOM_FIELDS_BASIC_LIST = ["Classification", "Active"]
CUSTOM_FIELDS_CONNECTION_LIST = ["Transfer Method", "Protection", "External"]


def import_csam_interconnections(import_ids: Optional[List[int]] = None):
    """
    Import the interconnections from CSAM
    Into RegScale
    """
    # Check Custom Fields
    basic_fields_map = FormFieldValue.check_custom_fields(CUSTOM_FIELDS_BASIC_LIST, "interconnects", "Basic Info")
    connection_fields_map = FormFieldValue.check_custom_fields(
        CUSTOM_FIELDS_CONNECTION_LIST, "interconnects", "Connection"
    )

    # Get existing ssps by CSAM Id
    logger.info("Retrieving SSPs from RegScale...")
    custom_fields_basic_map = FormFieldValue.check_custom_fields([CSAM_FIELD_NAME], "securityplans", SSP_BASIC_TAB)
    ssp_map = retrieve_ssps_custom_form_map(
        tab_name=SSP_BASIC_TAB, field_form_id=custom_fields_basic_map[CSAM_FIELD_NAME]
    )

    plans = import_ids if import_ids else list(ssp_map.keys())

    # Get a list of users and create a map to id
    logger.info("Building a map of existing users... ")
    users = User.get_all()
    user_map = {}
    for user in users:
        name = f"{user.lastName}, {user.firstName}"
        user_map[name] = user.id

    # Parse each SSP
    for index in track(
        range(len(plans)),
        description=f"Importing {len(plans)} interconnections...",
    ):
        regscale_ssp_id = plans[index]
        results = []
        system_id = ssp_map.get(regscale_ssp_id)

        results = retrieve_from_csam(
            csam_endpoint=f"/CSAM/api/v1/systems/{system_id}/interconnections",
        )

        if not results:
            logger.debug(f"No interconnections found for CSAM id: {system_id}, RegScale id: {regscale_ssp_id}")
            continue

        update_interconnections(
            results=results,
            ssp=regscale_ssp_id,
            user_map=user_map,
            basic_fields=basic_fields_map,
            connection_fields=connection_fields_map,
        )


def update_interconnections(results: list, ssp: int, user_map: dict, basic_fields: dict, connection_fields: dict):
    """
    Process each result from the csam call
    Create RegScale Interconnections

    :param results: list of interconnections from CSAM
    :param ssp: id of SSP
    :param user_map: map of existing users to ids
    :param basic_fields: map of custom fields in the basic info tab
    :param connection_fields: map of custom fields in connections
    """

    # Get existing interconnections
    existing = InterConnection.get_all_by_parent(parent_id=ssp, parent_module="securityplans")
    existing_map = {x.name: x.id for x in existing}

    field_values = []

    # Parse csam results
    for result in results:
        match = existing_map.get(result.get("connectedSystemName"))

        new_int = InterConnection(
            name=result.get("connectedSystemName")[:445],
            authorizationType="Interconnect Security Agreement (ISA)",
            categorization="Moderate",
            connectionType=(
                "Virtual Private Network (VPN)"
                if result.get("transferMethod") == "VPN"
                else "Internet or Firewall Rule"
            ),
            interconnectOwnerId=user_map.get(result.get("pocId")) or RegScaleModel.get_user_id(),
            status="Approved",
            agreementDate=result.get("dateAdded"),
            expirationDate=result.get("expirationDate") or "2030-12-31",
            aoId=user_map.get(result.get("primaryAuthorizingOfficial")) or RegScaleModel.get_user_id(),
            parentId=ssp,
            parentModule="securityplans",
            dataDirection=result.get("transferType"),
            description=result.get("description"),
            organization="external",
        )

        if match:
            # Update the id
            new_int.id = match
            new_int = new_int.save()
        else:
            new_int = new_int.create()

        # Setup custom fields
        field_values.append(
            {
                "record_id": new_int.id,
                "record_module": "interconnects",
                "form_field_id": connection_fields.get("External"),
                "field_value": "Yes" if result.get("isExternal") else "No",
            }
        )
        field_values.append(
            {
                "record_id": new_int.id,
                "record_module": "interconnects",
                "form_field_id": basic_fields.get("Active"),
                "field_value": "Yes" if result.get("isActive") else "No",
            }
        )
        field_values.append(
            {
                "record_id": new_int.id,
                "record_module": "interconnects",
                "form_field_id": basic_fields.get("Classification"),
                "field_value": result.get("classification"),
            }
        )
        field_values.append(
            {
                "record_id": new_int.id,
                "record_module": "interconnects",
                "form_field_id": connection_fields.get("Transfer Method"),
                "field_value": result.get("transferMethod"),
            }
        )
        protection_values = ["SSL", "TLS", "VPN"]
        field_values.append(
            {
                "record_id": new_int.id,
                "record_module": "interconnects",
                "form_field_id": connection_fields.get("Protection"),
                "field_value": (result.get("protection") if result.get("protection") in protection_values else "Other"),
            }
        )
    # Save the custom fields
    FormFieldValue.save_custom_fields(field_values)
