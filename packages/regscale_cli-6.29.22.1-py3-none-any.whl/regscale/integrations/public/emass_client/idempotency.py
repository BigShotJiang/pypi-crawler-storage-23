"""
Idempotency management for eMASS integration.

This module implements three-tier correlation between RegScale and eMASS records
using externalUid, eMASS identifiers, and content matching to ensure idempotent
operations and prevent duplicate POA&Ms.
"""

import logging
from typing import Any, Dict, List, Optional

from regscale.integrations.public.emass_client import utils

logger = logging.getLogger("regscale")


# ===========================
# Idempotency Manager
# ===========================


class IdempotencyManager:
    """
    Manages correlation between RegScale and eMASS records.

    Three-tier correlation strategy:
    1. externalUid (primary) - RegScale UUID stored in eMASS
    2. poamId/displayPoamId (fallback) - eMASS identifiers stored in RegScale
    3. Content matching (last resort) - Match by title + control acronym
    """

    def __init__(self, emass_client):
        """
        Initialize IdempotencyManager.

        Args:
            emass_client: eMASS API client instance
        """
        self.emass_client = emass_client

    # ===========================
    # POA&M Correlation
    # ===========================

    def find_existing_poam(
        self, case_data: Dict[str, Any], system_id: int, use_content_matching: bool = True
    ) -> Optional[Dict[str, Any]]:
        """
        Find existing eMASS POA&M for RegScale Case.

        Strategy (in priority order):
        1. Check for externalUid in Case metadata
        2. Query eMASS by externalUid
        3. Fall back to displayPoamId/poamId if externalUid not found
        4. Fall back to content matching (title + control acronym) if enabled

        Args:
            case_data: RegScale Case dictionary
            system_id: eMASS system ID
            use_content_matching: Enable content matching fallback (default: True)

        Returns:
            eMASS POA&M dictionary if found, None otherwise
        """
        # Tier 1: Try externalUid correlation
        external_uid = self._get_external_uid_from_case(case_data)
        if external_uid:
            poam = self._find_poam_by_external_uid(external_uid, system_id)
            if poam:
                logger.info(f"Found existing POA&M by externalUid: {external_uid}")
                return poam

        # Tier 2: Try eMASS identifier correlation
        emass_poam_id = self._get_emass_poam_id_from_case(case_data)
        if emass_poam_id:
            poam = self._find_poam_by_poam_id(emass_poam_id, system_id)
            if poam:
                logger.info(f"Found existing POA&M by poamId: {emass_poam_id}")
                return poam

        # Tier 3: Try content matching (if enabled)
        if use_content_matching:
            poam = self._find_poam_by_content(case_data, system_id)
            if poam:
                logger.info("Found existing POA&M by content matching")
                return poam

        logger.info("No existing POA&M found, will create new")
        return None

    def _get_external_uid_from_case(self, case_data: Dict[str, Any]) -> Optional[str]:
        """
        Get externalUid from RegScale Case.

        Checks:
        1. Case metadata for stored externalUid
        2. Generate from Case ID if not found

        Args:
            case_data: RegScale Case dictionary

        Returns:
            externalUid string or None
        """
        # Check metadata first
        metadata = case_data.get("metadata", {})
        if isinstance(metadata, dict):
            external_uid = metadata.get("emass_external_uid")
            if external_uid:
                return external_uid

        # Generate from Case ID
        case_id = case_data.get("id")
        if case_id:
            return utils.generate_external_uid(case_id)

        return None

    def _get_emass_poam_id_from_case(self, case_data: Dict[str, Any]) -> Optional[str]:
        """
        Get eMASS POA&M ID from RegScale Case metadata.

        Args:
            case_data: RegScale Case dictionary

        Returns:
            eMASS poamId or None
        """
        metadata = case_data.get("metadata", {})
        if isinstance(metadata, dict):
            return metadata.get("emass_poam_id")
        return None

    def _find_poam_by_external_uid(self, external_uid: str, system_id: int) -> Optional[Dict[str, Any]]:
        """
        Find POA&M in eMASS by externalUid.

        Args:
            external_uid: externalUid to search for
            system_id: eMASS system ID

        Returns:
            POA&M dictionary or None
        """
        try:
            # Query eMASS for POA&Ms with this externalUid
            poams = self.emass_client.get_system_poams(system_id)
            for poam in poams:
                if poam.get("externalUid") == external_uid:
                    return poam
        except Exception as e:
            logger.warning(f"Error querying eMASS for externalUid {external_uid}: {e}")

        return None

    def _find_poam_by_poam_id(self, poam_id: str, system_id: int) -> Optional[Dict[str, Any]]:
        """
        Find POA&M in eMASS by poamId.

        Args:
            poam_id: eMASS poamId
            system_id: eMASS system ID

        Returns:
            POA&M dictionary or None
        """
        try:
            # Get specific POA&M by ID
            poam = self.emass_client.get_system_poam(system_id, poam_id)
            return poam
        except Exception as e:
            logger.warning(f"Error querying eMASS for poamId {poam_id}: {e}")

        return None

    def _find_poam_by_content(self, case_data: Dict[str, Any], system_id: int) -> Optional[Dict[str, Any]]:
        """
        Find POA&M by content matching (title + control acronym).

        This is a last-resort fallback when externalUid and poamId are not available.

        Args:
            case_data: RegScale Case dictionary
            system_id: eMASS system ID

        Returns:
            POA&M dictionary or None
        """
        title = case_data.get("title")
        control_acronym = case_data.get("controlAcronym")

        if not title:
            logger.debug("Cannot perform content matching without title")
            return None

        try:
            # Get all POA&Ms for system
            poams = self.emass_client.get_system_poams(system_id)

            # Match by title and control acronym
            for poam in poams:
                poam_title = poam.get("displayPoamId") or poam.get("vulnerabilityDescription", "")
                poam_control = poam.get("controlAcronym")

                # Match title (case-insensitive)
                title_match = title.lower() in poam_title.lower() or poam_title.lower() in title.lower()

                # Match control acronym if both present
                control_match = True
                if control_acronym and poam_control:
                    control_match = utils.normalize_control_acronym(control_acronym) == utils.normalize_control_acronym(
                        poam_control
                    )

                if title_match and control_match:
                    logger.warning(
                        f"Content matching found POA&M {poam.get('poamId')} - "
                        f"consider updating Case metadata with externalUid for better correlation"
                    )
                    return poam

        except Exception as e:
            logger.warning(f"Error performing content matching: {e}")

        return None

    def store_poam_correlation(
        self, case_id: int, poam_id: str, display_poam_id: str, external_uid: str, system_id: int
    ) -> Dict[str, Any]:
        """
        Store eMASS identifiers in RegScale Case metadata for future correlation.

        Args:
            case_id: RegScale Case ID
            poam_id: eMASS poamId
            display_poam_id: eMASS displayPoamId
            external_uid: externalUid
            system_id: eMASS system ID

        Returns:
            Updated metadata dictionary
        """
        correlation_metadata = {
            "emass_poam_id": poam_id,
            "emass_display_poam_id": display_poam_id,
            "emass_external_uid": external_uid,
            "emass_system_id": system_id,
            "last_synced": utils.format_date_for_regscale(utils.parse_iso_date(str(utils.datetime.now()))),
        }

        logger.info(f"Storing correlation for Case {case_id} <-> POA&M {poam_id}")
        return correlation_metadata

    # ===========================
    # Control Implementation Correlation
    # ===========================

    def find_existing_test_result(
        self, control_data: Dict[str, Any], system_id: int, control_acronym: str
    ) -> Optional[Dict[str, Any]]:
        """
        Find existing eMASS Test Result for RegScale Control Implementation.

        Strategy:
        1. Check for externalUid in Control metadata
        2. Query eMASS by externalUid
        3. Fall back to control acronym matching

        Args:
            control_data: RegScale Control Implementation dictionary
            system_id: eMASS system ID
            control_acronym: Control acronym (e.g., 'AC-1')

        Returns:
            eMASS Test Result dictionary if found, None otherwise
        """
        # Tier 1: Try externalUid correlation
        external_uid = self._get_external_uid_from_control(control_data)
        if external_uid:
            test_result = self._find_test_result_by_external_uid(external_uid, system_id, control_acronym)
            if test_result:
                logger.info(f"Found existing Test Result by externalUid: {external_uid}")
                return test_result

        # Tier 2: Try control acronym matching
        test_result = self._find_test_result_by_control(system_id, control_acronym)
        if test_result:
            logger.info(f"Found existing Test Result by control acronym: {control_acronym}")
            return test_result

        logger.info(f"No existing Test Result found for {control_acronym}, will create new")
        return None

    def _get_external_uid_from_control(self, control_data: Dict[str, Any]) -> Optional[str]:
        """
        Get externalUid from RegScale Control Implementation.

        Args:
            control_data: RegScale Control Implementation dictionary

        Returns:
            externalUid string or None
        """
        # Check metadata first
        metadata = control_data.get("metadata", {})
        if isinstance(metadata, dict):
            external_uid = metadata.get("emass_external_uid")
            if external_uid:
                return external_uid

        # Generate from Control ID
        control_id = control_data.get("id")
        if control_id:
            return utils.generate_external_uid(control_id)

        return None

    def _find_test_result_by_external_uid(
        self, external_uid: str, system_id: int, control_acronym: str
    ) -> Optional[Dict[str, Any]]:
        """
        Find Test Result in eMASS by externalUid.

        Args:
            external_uid: externalUid to search for
            system_id: eMASS system ID
            control_acronym: Control acronym

        Returns:
            Test Result dictionary or None
        """
        try:
            # Query eMASS for Test Results with this control
            test_results = self.emass_client.get_system_control_test_results(system_id, control_acronym)
            for result in test_results:
                if result.get("externalUid") == external_uid:
                    return result
        except Exception as e:
            logger.warning(f"Error querying eMASS for Test Result with externalUid {external_uid}: {e}")

        return None

    def _find_test_result_by_control(self, system_id: int, control_acronym: str) -> Optional[Dict[str, Any]]:
        """
        Find most recent Test Result for control acronym.

        Args:
            system_id: eMASS system ID
            control_acronym: Control acronym

        Returns:
            Test Result dictionary or None
        """
        try:
            # Get Test Results for control
            test_results = self.emass_client.get_system_control_test_results(system_id, control_acronym)

            # Return most recent result
            if test_results:
                # Sort by testDate (most recent first)
                sorted_results = sorted(test_results, key=lambda x: x.get("testDate", 0), reverse=True)
                return sorted_results[0]

        except Exception as e:
            logger.warning(f"Error querying eMASS for Test Results for {control_acronym}: {e}")

        return None

    def store_control_correlation(
        self, control_id: int, test_result_id: str, external_uid: str, system_id: int, control_acronym: str
    ) -> Dict[str, Any]:
        """
        Store eMASS Test Result identifiers in RegScale Control metadata.

        Args:
            control_id: RegScale Control Implementation ID
            test_result_id: eMASS Test Result ID
            external_uid: externalUid
            system_id: eMASS system ID
            control_acronym: Control acronym

        Returns:
            Updated metadata dictionary
        """
        correlation_metadata = {
            "emass_test_result_id": test_result_id,
            "emass_external_uid": external_uid,
            "emass_system_id": system_id,
            "emass_control_acronym": control_acronym,
            "last_synced": utils.format_date_for_regscale(utils.parse_iso_date(str(utils.datetime.now()))),
        }

        logger.info(f"Storing correlation for Control {control_id} <-> Test Result {test_result_id}")
        return correlation_metadata

    # ===========================
    # Batch Operations
    # ===========================

    def find_existing_poams_batch(
        self, cases: List[Dict[str, Any]], system_id: int
    ) -> Dict[int, Optional[Dict[str, Any]]]:
        """
        Find existing POA&Ms for multiple Cases (batch operation).

        Args:
            cases: List of RegScale Case dictionaries
            system_id: eMASS system ID

        Returns:
            Dictionary mapping Case ID to POA&M (or None if not found)
        """
        result = {}

        # Get all POA&Ms for system once
        try:
            all_poams = self.emass_client.get_system_poams(system_id)
        except Exception as e:
            logger.error(f"Error fetching POA&Ms for batch correlation: {e}")
            all_poams = []

        # Build lookup maps for efficient matching
        poams_by_external_uid = {poam.get("externalUid"): poam for poam in all_poams if poam.get("externalUid")}

        poams_by_poam_id = {poam.get("poamId"): poam for poam in all_poams if poam.get("poamId")}

        # Match each case
        for case in cases:
            case_id = case.get("id")
            if not case_id:
                continue

            # Try externalUid
            external_uid = self._get_external_uid_from_case(case)
            if external_uid and external_uid in poams_by_external_uid:
                result[case_id] = poams_by_external_uid[external_uid]
                continue

            # Try poamId
            emass_poam_id = self._get_emass_poam_id_from_case(case)
            if emass_poam_id and emass_poam_id in poams_by_poam_id:
                result[case_id] = poams_by_poam_id[emass_poam_id]
                continue

            # No match found
            result[case_id] = None

        return result


# ===========================
# Helper Functions
# ===========================


def should_update_poam(existing_poam: Dict[str, Any], new_data: Dict[str, Any]) -> bool:
    """
    Determine if POA&M should be updated based on data changes.

    Args:
        existing_poam: Current POA&M data from eMASS
        new_data: New data from RegScale

    Returns:
        True if update needed, False otherwise
    """
    # Check key fields for changes
    key_fields = ["status", "rawSeverity", "vulnerabilityDescription", "recommendations", "scheduledCompletionDate"]

    for field in key_fields:
        existing_value = existing_poam.get(field)
        new_value = new_data.get(field)

        if existing_value != new_value:
            logger.debug(f"Field '{field}' changed: '{existing_value}' -> '{new_value}'")
            return True

    logger.debug("No significant changes detected, skipping update")
    return False
