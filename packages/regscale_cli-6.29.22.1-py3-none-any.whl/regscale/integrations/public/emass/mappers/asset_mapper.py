"""
eMASS System to Asset Mapper.

This module provides functions to convert eMASS system information to RegScale IntegrationAsset objects.
Handles Windows date format issues and system metadata mapping.
"""

import logging
from datetime import datetime
from typing import Any, Dict, List, Optional

from regscale.core.app.utils.app_utils import get_current_datetime
from regscale.integrations.scanner.models import IntegrationAsset
from regscale.models import regscale_models

logger = logging.getLogger("regscale")

# Date format constants
REGSCALE_DATETIME_FORMAT = "%Y-%m-%dT%H:%M:%S"


def map_emass_system_to_asset(
    system_data: Dict[str, Any],
    plan_id: int,
    parent_module: str = "securityplans",
) -> IntegrationAsset:
    """
    Map eMASS system data to IntegrationAsset.

    :param Dict[str, Any] system_data: Raw system data from eMASS API
    :param int plan_id: RegScale security plan ID
    :param str parent_module: Parent module name (default: "securityplans")
    :return: IntegrationAsset object
    :rtype: IntegrationAsset
    """
    # Extract system ID - this is the unique identifier for eMASS systems
    system_id = str(system_data.get("systemId", ""))

    # Extract system name
    system_name = system_data.get("systemName", "Unknown System")

    # Extract system type and map to RegScale asset type
    system_type = system_data.get("systemType", "Unknown")
    asset_type = _map_emass_system_type_to_asset_type(system_type)

    # Extract system category
    asset_category = system_data.get("category", "Information System")

    # Handle date last updated with Windows date format fix
    date_last_updated = _parse_emass_date(system_data.get("lastUpdated") or system_data.get("dateUpdated"))

    # Extract system status
    status = _map_emass_system_status(system_data.get("status", "Active"))

    # Extract description
    description = system_data.get("description", "")

    # Build notes with additional metadata
    notes = _build_system_notes(system_data)

    return IntegrationAsset(
        name=system_name,
        identifier=system_id,
        external_id=system_id,  # eMASS system ID is the external identifier
        asset_type=asset_type,
        asset_category=asset_category,
        description=description,
        parent_id=plan_id,
        parent_module=parent_module,
        status=status,
        date_last_updated=date_last_updated,
        notes=notes,
        source_data=system_data,  # Store full eMASS data for reference
        # Additional fields that may be present in eMASS data
        location=system_data.get("location"),
        management_type=system_data.get("managementType"),
        is_public_facing=system_data.get("isPublicFacing"),
        other_tracking_number=system_data.get("trackingNumber"),
    )


def _map_emass_system_type_to_asset_type(system_type: str) -> str:
    """
    Map eMASS system type to RegScale asset type.

    :param str system_type: eMASS system type
    :return: RegScale asset type
    :rtype: str
    """
    type_mapping = {
        "general support system": "Server",
        "major application": "Application",
        "minor application": "Application",
        "platform it system": "Platform",
        "cloud service": "Cloud Service",
        "saas": "Cloud Service",
        "paas": "Platform",
        "iaas": "Infrastructure",
    }

    return type_mapping.get(system_type.lower(), "Information System")


def _map_emass_system_status(status: str) -> regscale_models.AssetStatus:
    """
    Map eMASS system status to RegScale AssetStatus enum.

    :param str status: eMASS system status
    :return: RegScale AssetStatus enum value
    :rtype: regscale_models.AssetStatus
    """
    status_mapping = {
        "active": regscale_models.AssetStatus.Active,
        "operational": regscale_models.AssetStatus.Active,
        "inactive": regscale_models.AssetStatus.Inactive,
        "retired": regscale_models.AssetStatus.Retired,
        "decommissioned": regscale_models.AssetStatus.Decommissioned,
        "under development": regscale_models.AssetStatus.Planned,
        "planned": regscale_models.AssetStatus.Planned,
    }

    return status_mapping.get(status.lower() if status else "", regscale_models.AssetStatus.Active)


def _parse_emass_date(date_value: Optional[Any]) -> str:
    """
    Parse eMASS date value handling various formats including Windows date format issues.

    This function addresses the REG-19266 Windows evidence file date format issue
    by accepting multiple date formats and normalizing them to RegScale format.

    :param Optional[Any] date_value: Date value from eMASS (could be string, datetime, or None)
    :return: Formatted date string in RegScale format
    :rtype: str
    """
    if not date_value:
        return get_current_datetime()

    # If already a datetime object
    if isinstance(date_value, datetime):
        return date_value.strftime(REGSCALE_DATETIME_FORMAT)

    # If string, try to parse various formats
    if isinstance(date_value, str):
        # Common eMASS date formats to try
        date_formats = [
            "%Y-%m-%dT%H:%M:%S",  # ISO format
            "%Y-%m-%dT%H:%M:%SZ",  # ISO with Z
            "%Y-%m-%d %H:%M:%S",  # Space separated
            "%m/%d/%Y",  # US format
            "%m-%d-%Y",  # US format with dashes
            "%d-%b-%Y",  # Day-Month-Year (e.g., 15-Jan-2024)
            "%Y-%m-%d",  # Date only
            "%m/%d/%Y %H:%M:%S",  # Windows format
            "%m/%d/%Y %I:%M:%S %p",  # Windows format with AM/PM
        ]

        for date_format in date_formats:
            try:
                dt = datetime.strptime(date_value.strip(), date_format)
                return dt.strftime(REGSCALE_DATETIME_FORMAT)
            except ValueError:
                continue

        # If none of the formats worked, log warning and return current date
        logger.warning(f"Could not parse eMASS date format: {date_value}. Using current date.")

    return get_current_datetime()


def _build_system_notes(system_data: Dict[str, Any]) -> str:
    """
    Build notes field with additional eMASS system metadata.

    :param Dict[str, Any] system_data: Raw system data from eMASS
    :return: Formatted notes string
    :rtype: str
    """
    notes_parts = []

    # Add authorization information
    notes_parts.extend(_build_authorization_notes(system_data))

    # Add impact level
    if "impactLevel" in system_data:
        notes_parts.append(f"Impact Level: {system_data['impactLevel']}")

    # Add FIPS 199 categorization
    fips_note = _build_fips_199_note(system_data)
    if fips_note:
        notes_parts.append(fips_note)

    # Add registration information
    if "registrationType" in system_data:
        notes_parts.append(f"Registration Type: {system_data['registrationType']}")

    # Add existing notes from eMASS if present
    if "notes" in system_data and system_data["notes"]:
        notes_parts.append(f"eMASS Notes: {system_data['notes']}")

    return "\n".join(notes_parts) if notes_parts else ""


def _build_authorization_notes(system_data: Dict[str, Any]) -> List[str]:
    """Build authorization-related notes."""
    auth_notes = []
    if "authorizationType" in system_data:
        auth_notes.append(f"Authorization Type: {system_data['authorizationType']}")
    if "authorizationDate" in system_data:
        auth_notes.append(f"Authorization Date: {system_data['authorizationDate']}")
    if "authorizationTerminationDate" in system_data:
        auth_notes.append(f"Authorization Termination: {system_data['authorizationTerminationDate']}")
    return auth_notes


def _build_fips_199_note(system_data: Dict[str, Any]) -> str:
    """Build FIPS 199 categorization note."""
    fips_fields = ["confidentiality", "integrity", "availability"]
    if not any(field in system_data for field in fips_fields):
        return ""

    fips_parts = []
    if "confidentiality" in system_data:
        fips_parts.append(f"C={system_data['confidentiality']}")
    if "integrity" in system_data:
        fips_parts.append(f"I={system_data['integrity']}")
    if "availability" in system_data:
        fips_parts.append(f"A={system_data['availability']}")

    return f"FIPS 199: {', '.join(fips_parts)}" if fips_parts else ""
