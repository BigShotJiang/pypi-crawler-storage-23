"""
eMASS Data Mappers.

This module contains mapper functions for converting between eMASS API formats
and RegScale integration models (IntegrationAsset, IntegrationFinding).
"""

from regscale.integrations.public.emass.mappers.asset_mapper import map_emass_system_to_asset
from regscale.integrations.public.emass.mappers.poam_mapper import (
    map_emass_poam_to_finding,
    map_regscale_issue_to_emass_poam,
)
from regscale.integrations.public.emass.mappers.test_result_mapper import map_emass_test_result_to_finding

__all__ = [
    "map_emass_system_to_asset",
    "map_emass_test_result_to_finding",
    "map_emass_poam_to_finding",
    "map_regscale_issue_to_emass_poam",
]
