"""
eMASS Test Result to Finding Mapper.

This module provides functions to convert eMASS control test results to RegScale IntegrationFinding objects.
"""

import logging
from typing import Any, Dict, List, Optional

from regscale.core.app.utils.app_utils import get_current_datetime
from regscale.integrations.scanner.models import IntegrationFinding
from regscale.models import regscale_models

logger = logging.getLogger("regscale")


def map_emass_test_result_to_finding(
    test_result: Dict[str, Any],
    plan_id: int,
    asset_identifier: Optional[str] = None,
) -> IntegrationFinding:
    """
    Map eMASS test result to IntegrationFinding.

    :param Dict[str, Any] test_result: Raw test result data from eMASS API
    :param int plan_id: RegScale security plan ID
    :param Optional[str] asset_identifier: Asset identifier if available
    :return: IntegrationFinding object
    :rtype: IntegrationFinding
    """
    # Extract control identifiers for CCI mapping
    control_labels = _extract_control_labels(test_result)

    # Extract test result details
    title = test_result.get("description", "eMASS Test Result")
    description = _build_test_result_description(test_result)

    # Map compliance status to severity and status
    compliance_status = test_result.get("complianceStatus", "")
    severity = _map_compliance_to_severity(compliance_status)
    status = _map_compliance_to_status(compliance_status)

    # Extract test date
    test_date = _parse_test_date(test_result.get("testDate") or test_result.get("completionDate"))

    # Build observations and evidence
    observations = _build_observations(test_result)
    evidence = _build_evidence(test_result)

    # Extract external ID
    external_id = str(test_result.get("testResultId", ""))

    # Extract CCI reference if available
    cci_ref = test_result.get("cci") or test_result.get("cciNumber")

    return IntegrationFinding(
        control_labels=control_labels,
        title=title,
        description=description,
        category="Control Test",
        severity=severity,
        status=status,
        priority=_map_severity_to_priority(severity),
        issue_type="Control Test",
        date_created=test_date,
        date_last_updated=test_date or get_current_datetime(),
        external_id=external_id,
        asset_identifier=asset_identifier or "",
        observations=observations,
        evidence=evidence,
        cci_ref=cci_ref,
        results=test_result.get("results", ""),
        comments=test_result.get("comments"),
        source_report="eMASS Test Results",
        # Additional metadata
        baseline=test_result.get("baseline", ""),
        scan_date=test_date,
    )


def _extract_control_labels(test_result: Dict[str, Any]) -> List[str]:
    """
    Extract control labels from test result for CCI mapping.

    :param Dict[str, Any] test_result: Test result data
    :return: List of control labels
    :rtype: List[str]
    """
    control_labels = []

    # Check for control acronym (e.g., "AC-2")
    if "controlAcronym" in test_result:
        control_labels.append(test_result["controlAcronym"])

    # Check for CCI number
    if "cci" in test_result or "cciNumber" in test_result:
        cci = test_result.get("cci") or test_result.get("cciNumber")
        if cci:
            # Ensure CCI is in format CCI-XXXXXX
            if not cci.upper().startswith("CCI-"):
                cci = f"CCI-{cci}"
            control_labels.append(cci)

    # Check for control IDs in various formats
    if "controlId" in test_result:
        control_labels.append(test_result["controlId"])

    # Check for AP acronym (Assessment Procedure)
    if "apAcronym" in test_result:
        control_labels.append(test_result["apAcronym"])

    return control_labels


def _map_compliance_to_severity(compliance_status: str) -> regscale_models.IssueSeverity:
    """
    Map eMASS compliance status to RegScale severity.

    :param str compliance_status: eMASS compliance status
    :return: RegScale IssueSeverity enum
    :rtype: regscale_models.IssueSeverity
    """
    status_lower = compliance_status.lower() if compliance_status else ""

    if "non-compliant" in status_lower or "fail" in status_lower:
        # Non-compliant findings are high severity
        return regscale_models.IssueSeverity.High
    elif "other" in status_lower or "partial" in status_lower:
        # Partially compliant or other status is moderate
        return regscale_models.IssueSeverity.Moderate
    elif "compliant" in status_lower or "pass" in status_lower:
        # Compliant findings are low severity (informational)
        return regscale_models.IssueSeverity.Low
    elif "not applicable" in status_lower or "n/a" in status_lower:
        return regscale_models.IssueSeverity.Low

    # Default to moderate for unknown status
    return regscale_models.IssueSeverity.Moderate


def _map_compliance_to_status(compliance_status: str) -> regscale_models.ControlTestResultStatus:
    """
    Map eMASS compliance status to RegScale ControlTestResultStatus.

    :param str compliance_status: eMASS compliance status
    :return: RegScale ControlTestResultStatus enum
    :rtype: regscale_models.ControlTestResultStatus
    """
    status_lower = compliance_status.lower() if compliance_status else ""

    if "compliant" in status_lower or "pass" in status_lower:
        return regscale_models.ControlTestResultStatus.Pass
    elif "non-compliant" in status_lower or "fail" in status_lower:
        return regscale_models.ControlTestResultStatus.Fail
    elif "not applicable" in status_lower or "n/a" in status_lower:
        return regscale_models.ControlTestResultStatus.NotApplicable
    elif "other" in status_lower or "partial" in status_lower:
        return regscale_models.ControlTestResultStatus.PartialPass

    # Default to Open for unknown status
    return regscale_models.ControlTestResultStatus.Open


def _map_severity_to_priority(severity: regscale_models.IssueSeverity) -> str:
    """
    Map RegScale severity to priority string.

    :param regscale_models.IssueSeverity severity: Issue severity
    :return: Priority string
    :rtype: str
    """
    priority_mapping = {
        regscale_models.IssueSeverity.Critical: "Critical",
        regscale_models.IssueSeverity.High: "High",
        regscale_models.IssueSeverity.Moderate: "Medium",
        regscale_models.IssueSeverity.Low: "Low",
        regscale_models.IssueSeverity.Informational: "Low",
    }

    return priority_mapping.get(severity, "Medium")


def _parse_test_date(date_value: Optional[Any]) -> str:
    """
    Parse test date from eMASS format.

    :param Optional[Any] date_value: Date value from eMASS
    :return: Formatted date string
    :rtype: str
    """
    # Reuse the date parsing logic from asset_mapper
    from regscale.integrations.public.emass.mappers.asset_mapper import _parse_emass_date

    return _parse_emass_date(date_value)


def _build_test_result_description(test_result: Dict[str, Any]) -> str:
    """
    Build detailed description from test result data.

    :param Dict[str, Any] test_result: Test result data
    :return: Formatted description
    :rtype: str
    """
    description_parts = []

    # Add control information
    if "controlAcronym" in test_result:
        description_parts.append(f"Control: {test_result['controlAcronym']}")

    if "controlName" in test_result:
        description_parts.append(f"Control Name: {test_result['controlName']}")

    # Add description if available
    if "description" in test_result and test_result["description"]:
        description_parts.append(f"\n{test_result['description']}")

    # Add compliance status
    if "complianceStatus" in test_result:
        description_parts.append(f"\nCompliance Status: {test_result['complianceStatus']}")

    # Add test method
    if "testMethod" in test_result:
        description_parts.append(f"Test Method: {test_result['testMethod']}")

    return "\n".join(description_parts) if description_parts else "eMASS Test Result"


def _build_observations(test_result: Dict[str, Any]) -> str:
    """
    Build observations field from test result data.

    :param Dict[str, Any] test_result: Test result data
    :return: Formatted observations
    :rtype: str
    """
    observations = []

    if "findings" in test_result and test_result["findings"]:
        observations.append(f"Findings: {test_result['findings']}")

    if "observations" in test_result and test_result["observations"]:
        observations.append(test_result["observations"])

    if "technicalFindings" in test_result and test_result["technicalFindings"]:
        observations.append(f"Technical Findings: {test_result['technicalFindings']}")

    return "\n\n".join(observations) if observations else ""


def _build_evidence(test_result: Dict[str, Any]) -> str:
    """
    Build evidence field from test result data.

    :param Dict[str, Any] test_result: Test result data
    :return: Formatted evidence
    :rtype: str
    """
    evidence = []

    if "testProcedure" in test_result and test_result["testProcedure"]:
        evidence.append(f"Test Procedure: {test_result['testProcedure']}")

    if "evidenceDocumentation" in test_result and test_result["evidenceDocumentation"]:
        evidence.append(f"Evidence Documentation: {test_result['evidenceDocumentation']}")

    if "artifactReferences" in test_result and test_result["artifactReferences"]:
        refs = test_result["artifactReferences"]
        if isinstance(refs, list):
            evidence.append("Artifact References:\n" + "\n".join(f"- {ref}" for ref in refs))
        else:
            evidence.append(f"Artifact References: {refs}")

    return "\n\n".join(evidence) if evidence else ""
