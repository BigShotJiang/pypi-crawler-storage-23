"""
eMASS Test Results Integration.

This module provides integration for syncing eMASS control test results as findings in RegScale.
It extends the BaseScannerIntegration framework to leverage core handlers and caching.
"""

import logging
from typing import Any, Dict, Iterator, List, Optional

from regscale.integrations.public.emass.mappers.test_result_mapper import map_emass_test_result_to_finding
from regscale.integrations.public.emass_client.exceptions import ApiException
from regscale.integrations.public.emass_client.integration import EmassClient
from regscale.integrations.scanner.base import BaseScannerIntegration
from regscale.integrations.scanner.models import IntegrationAsset, IntegrationFinding

logger = logging.getLogger("regscale")


class EmassTestResultsIntegration(BaseScannerIntegration):
    """
    Integration for syncing eMASS control test results as findings.

    This class fetches test result data from the eMASS API and creates/updates
    issues in RegScale using the Scanner Integration framework. Test results are
    automatically mapped to their associated controls via CCI numbers.

    Usage:
        integration = EmassTestResultsIntegration(
            plan_id=123,
            emass_system_id="12345"
        )
        finding_count = integration.sync_findings()
    """

    title: str = "eMASS Test Results"
    asset_identifier_field: str = "emassSystemId"
    issue_identifier_field: str = "emassTestResultId"

    def __init__(
        self,
        plan_id: int,
        tenant_id: int = 1,
        emass_system_id: Optional[str] = None,
        emass_base_url: Optional[str] = None,
        emass_api_key: Optional[str] = None,
        **kwargs: Any,
    ) -> None:
        """
        Initialize the eMASS Test Results Integration.

        :param int plan_id: RegScale security plan ID
        :param int tenant_id: RegScale tenant ID (default: 1)
        :param Optional[str] emass_system_id: eMASS system ID to sync test results for
        :param Optional[str] emass_base_url: eMASS API base URL (optional, uses env var if not provided)
        :param Optional[str] emass_api_key: eMASS API key (optional, uses env var if not provided)
        :param kwargs: Additional configuration options
        """
        # Enable CCI mapping by default for test results
        kwargs.setdefault("enable_cci_mapping", True)

        super().__init__(plan_id, tenant_id, **kwargs)

        # Initialize eMASS client
        self.emass_client = EmassClient(
            base_url=emass_base_url,
            api_key=emass_api_key,
        )

        # Store system ID - required for test results
        if not emass_system_id:
            raise ValueError("emass_system_id is required for test results integration")

        self.emass_system_id = emass_system_id

        logger.info(
            "Initialized eMASS Test Results Integration for plan_id=%d, system_id=%s",
            plan_id,
            emass_system_id,
        )

    def fetch_findings(self) -> Iterator[IntegrationFinding]:
        """
        Fetch test results from eMASS API and yield as IntegrationFinding objects.

        This method queries the eMASS Test Results API to retrieve control test results
        and converts each result to an IntegrationFinding for processing by the IssueHandler.
        The IssueHandler will automatically map findings to controls via CCI numbers.

        :yields: IntegrationFinding objects
        :rtype: Iterator[IntegrationFinding]
        """
        try:
            # Test connection first
            if not self.emass_client.test_connection():
                logger.error("Failed to connect to eMASS API")
                return

            logger.info(
                "Fetching test results from eMASS for system %s...",
                self.emass_system_id,
            )

            # Fetch test results from eMASS
            test_results = self._fetch_test_results()

            # Convert each test result to IntegrationFinding
            finding_count = 0
            for test_result in test_results:
                try:
                    finding = map_emass_test_result_to_finding(
                        test_result=test_result,
                        plan_id=self.plan_id,
                        asset_identifier=self.emass_system_id,
                    )
                    finding_count += 1
                    yield finding

                except Exception as e:
                    logger.error(
                        "Error mapping eMASS test result %s to finding: %s",
                        test_result.get("testResultId", "UNKNOWN"),
                        str(e),
                        exc_info=True,
                    )
                    continue

            logger.info(
                "Successfully fetched and mapped %d eMASS test results",
                finding_count,
            )

        except ApiException as e:
            logger.error("eMASS API error while fetching test results: %s", str(e))
            raise
        except Exception as e:
            logger.error(
                "Unexpected error fetching eMASS test results: %s",
                str(e),
                exc_info=True,
            )
            raise

    def fetch_assets(self) -> Iterator[IntegrationAsset]:
        """
        Not used for findings-only integration.

        :yields: Empty iterator
        :rtype: Iterator[IntegrationAsset]
        """
        return iter([])

    def _fetch_test_results(self) -> List[Dict[str, Any]]:
        """
        Fetch test results from eMASS API.

        :return: List of test result data
        :rtype: List[Dict[str, Any]]
        """
        try:
            logger.info(
                "Calling eMASS Test Results API for system %s",
                self.emass_system_id,
            )

            # Call the eMASS Test Results API
            response = self.emass_client.test_results_api.get_system_test_results(system_id=int(self.emass_system_id))

            if response:
                result_count = len(response) if isinstance(response, list) else 1
                logger.info(
                    "Successfully retrieved %d test results from eMASS",
                    result_count,
                )
                return response if isinstance(response, list) else [response]
            else:
                logger.warning(
                    "No test results returned for system %s",
                    self.emass_system_id,
                )
                return []

        except ApiException as e:
            logger.error(
                "Failed to fetch test results for system %s: %s",
                self.emass_system_id,
                str(e),
            )
            raise
        except Exception as e:
            logger.error(
                "Unexpected error fetching test results: %s",
                str(e),
                exc_info=True,
            )
            raise

    def sync_findings(self) -> int:
        """
        Synchronize eMASS test results as findings in RegScale.

        This is a convenience method that wraps the base class sync_findings method
        to provide specific logging for eMASS test results integration.

        :return: Number of findings synchronized
        :rtype: int
        """
        logger.info(
            "Starting eMASS test results synchronization for plan %d, system %s",
            self.plan_id,
            self.emass_system_id,
        )

        try:
            finding_count = super().sync_findings()
            logger.info(
                "Successfully synchronized %d eMASS test results as findings",
                finding_count,
            )
            return finding_count

        except Exception as e:
            logger.error(
                "Failed to synchronize eMASS test results: %s",
                str(e),
                exc_info=True,
            )
            raise

    def push_test_results(self, control_acronyms: Optional[List[str]] = None) -> int:
        """
        Push RegScale control assessments to eMASS as test results.

        This method performs the reverse operation: it takes RegScale assessment data
        and pushes it to eMASS as test results.

        :param Optional[List[str]] control_acronyms: List of control acronyms to push (if None, push all)
        :return: Number of test results pushed
        :rtype: int
        """
        logger.info(
            "Pushing RegScale assessments to eMASS as test results for system %s",
            self.emass_system_id,
        )

        try:
            control_impls = self._get_control_implementations_with_assessments(control_acronyms)
            pushed_count = self._push_control_implementations(control_impls)

            logger.info("Successfully pushed %d test results to eMASS", pushed_count)
            return pushed_count

        except Exception as e:
            logger.error("Failed to push test results to eMASS: %s", str(e), exc_info=True)
            raise

    def _get_control_implementations_with_assessments(self, control_acronyms: Optional[List[str]] = None) -> List[Any]:
        """Get control implementations with assessments, optionally filtered by control acronyms."""
        from regscale.models import regscale_models

        control_impls = regscale_models.ControlImplementation.get_all_by_parent(
            parent_id=self.plan_id,
            parent_module="securityplans",
        )

        if control_acronyms:
            control_impls = [ci for ci in control_impls if ci.control and ci.control.controlId in control_acronyms]

        return [ci for ci in control_impls if ci.assessments]

    def _push_control_implementations(self, control_impls: List[Any]) -> int:
        """Push control implementations as test results to eMASS."""
        pushed_count = 0
        for control_impl in control_impls:
            latest_assessment = self._get_latest_assessment(control_impl)
            if self._push_single_test_result(control_impl, latest_assessment):
                pushed_count += 1
        return pushed_count

    def _get_latest_assessment(self, control_impl: Any) -> Any:
        """Get the most recent assessment from a control implementation."""
        return max(
            control_impl.assessments,
            key=lambda a: a.actualFinish or a.dateCreated or "",
        )

    def _push_single_test_result(self, control_impl: Any, assessment: Any) -> bool:
        """Push a single test result to eMASS. Returns True if successful."""
        try:
            test_result_data = self._convert_assessment_to_test_result(control_impl, assessment)
            response = self.emass_client.test_results_api.add_test_results(
                system_id=int(self.emass_system_id),
                request_body=[test_result_data],
            )

            if response:
                control_id = control_impl.control.controlId if control_impl.control else "UNKNOWN"
                logger.debug("Pushed test result for control %s", control_id)
                return True

        except Exception as e:
            control_id = control_impl.control.controlId if control_impl.control else "UNKNOWN"
            logger.error("Failed to push test result for control %s: %s", control_id, str(e))

        return False

    def _convert_assessment_to_test_result(
        self,
        control_impl: Any,
        assessment: Any,
    ) -> Dict[str, Any]:
        """
        Convert RegScale assessment to eMASS test result format.

        :param Any control_impl: RegScale ControlImplementation object
        :param Any assessment: RegScale Assessment object
        :return: Test result data in eMASS format
        :rtype: Dict[str, Any]
        """
        test_result = {
            "controlAcronym": self._get_control_acronym(control_impl),
            "description": assessment.summaryOfResults or "RegScale Assessment",
            "complianceStatus": self._map_assessment_to_compliance_status(assessment),
            "testDate": assessment.actualFinish or assessment.dateCreated,
            "testedBy": self._get_assessor_name(assessment),
            "testMethod": assessment.testMethod or "Manual",
            "results": assessment.summaryOfResults or "",
            "comments": assessment.notes or "",
        }

        # Add CCI if available
        cci_number = self._extract_cci_number(control_impl)
        if cci_number:
            test_result["cci"] = cci_number

        return test_result

    def _map_assessment_to_compliance_status(self, assessment: Any) -> str:
        """Map assessment result to eMASS compliance status."""
        status_map = {
            "Fail": "Non-Compliant",
            "Partial Pass": "Other",
            "Not Applicable": "Not Applicable",
        }
        return status_map.get(assessment.assessmentResult, "Compliant")

    def _get_control_acronym(self, control_impl: Any) -> str:
        """Extract control acronym from control implementation."""
        return control_impl.control.controlId if control_impl.control else ""

    def _get_assessor_name(self, assessment: Any) -> str:
        """Extract assessor name from assessment."""
        if assessment.leadAssessor:
            return f"{assessment.leadAssessor.firstName} {assessment.leadAssessor.lastName}"
        return ""

    def _extract_cci_number(self, control_impl: Any) -> Optional[str]:
        """Extract CCI number from control implementation."""
        if not (control_impl.control and control_impl.control.cci):
            return None

        first_cci = control_impl.control.cci[0]
        if not first_cci:
            return None

        cci_name = first_cci.name if hasattr(first_cci, "name") else str(first_cci)
        return cci_name.replace("CCI-", "") if "CCI-" in cci_name else cci_name
