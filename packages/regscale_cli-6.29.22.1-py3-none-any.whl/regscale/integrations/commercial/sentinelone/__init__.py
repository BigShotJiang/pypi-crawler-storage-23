#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
SentinelOne integration for RegScale CLI.

This module provides integration with SentinelOne for syncing
agents (assets), threats, and vulnerabilities to RegScale.
"""

from regscale.integrations.commercial.sentinelone.cli import sentinelone

__all__ = ["sentinelone"]
