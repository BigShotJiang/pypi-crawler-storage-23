#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Databricks integration for RegScale CLI to sync assets"""

import json
import logging
import warnings

import click
import polars as pl
from databricks import sql

from regscale.core.app.application import Application


# Create group to handle Databricks integration
@click.group()
def databricks():
    """Sync Scan Findings between Databricks and RegScale"""


@databricks.command(name="pull_data")
@click.option(
    "--query",
    type=click.STRING,
    help="Databricks Query",
    default="SELECT * from range(10)",
    show_default=True,
    required=True,
)
@click.option(
    "--localpath",
    type=click.STRING,
    help="Local Path to save Databricks Query JSON",
    default="artifacts/DBX_Query.json",
    show_default=True,
    required=True,
)
def pull_data(query: str, localpath: str) -> None:
    """Run Query in Databricks Catalog"""

    # Validation
    query_upper = query.strip().upper()
    if not query_upper.startswith("SELECT"):
        raise click.BadParameter("Only SELECT queries are allowed for security reasons")
    if any(keyword in query_upper for keyword in ["DROP", "DELETE", "INSERT", "UPDATE", "ALTER", "CREATE"]):
        raise click.BadParameter("Modification queries are not allowed")

    warnings.filterwarnings("ignore")
    logger = logging.getLogger("regscale")

    app = Application()
    config = app.config

    try:
        logger.info("Connecting to Databricks Server")
        connection = sql.connect(
            server_hostname=config["databricksHostname"],
            http_path=config["databricksPath"],
            access_token=config["databricksAccessToken"],
        )
    except Exception as e:
        logger.error("Failed to connect to Databricks (credentials redacted)")
        # Strip sensitive info from exception message
        safe_message = str(e).replace(config["databricksAccessToken"], "***REDACTED***")
        raise click.ClickException(f"Databricks connection failed: {safe_message}")

    cursor = None
    try:
        cursor = connection.cursor()

        logger.info(f"Running Query: {query}")
        try:
            cursor.execute(query)
        except sql.exc.QueryTimeout as e:
            raise click.ClickException(f"Query timed out: {e}")
        except sql.exc.DatabaseError as e:
            raise click.ClickException(f"Database error: {e}")
        except Exception as e:
            raise click.ClickException(f"Failed to execute query: {e}")

        # Efficient: build list first, DataFrame once
        rows = []
        while True:
            batch = cursor.fetchmany(1000)
            if not batch:
                break
            rows.extend([row.asDict() for row in batch])
            logger.debug(f"Fetched batch, total rows so far: {len(rows)}")

        logger.info("Fetched %s rows total", len(rows))
        result_df = pl.DataFrame(rows)

        try:
            logger.info("Writing %s rows to %s", len(rows), localpath)
            with open(localpath, "w") as f:
                json.dump(result_df.to_dicts(), f, indent=4, default=str)
            logger.info("Successfully wrote data to %s", localpath)
        except PermissionError as e:
            raise click.ClickException(f"Permission denied writing to {localpath}: {e}")
        except OSError as e:
            raise click.ClickException(f"Failed to write file {localpath}: {e}")

    finally:
        if cursor is not None:
            try:
                cursor.close()
            except Exception:
                pass  # Best effort cleanup
        try:
            connection.close()
        except Exception:
            pass  # Best effort cleanup
