"""
Qualys Integration using ScannerIntegration framework.

This module provides a clean, unified integration for syncing Qualys data to RegScale,
following the patterns established by AWS and Axonius integrations.

Workflow:
1. Fetch data from Qualys APIs (VMDR, Containers, WAS, Total Cloud)
2. Transform to IntegrationAsset objects
3. Sync assets using batchCreateOrUpdate
4. Transform to IntegrationFinding objects
5. Sync vulnerabilities/issues using streamBatchCreateOrUpdate
"""

import logging
from typing import Any, Dict, Iterator, List, Optional, Tuple

from regscale.core.app.utils.app_utils import get_current_datetime
from regscale.integrations.scanner_integration import (
    IntegrationAsset,
    IntegrationFinding,
    ScannerIntegration,
    ScannerIntegrationType,
    issue_due_date,
)
from regscale.integrations.variables import ScannerVariables
from regscale.models import AssetStatus, IssueSeverity, IssueStatus

logger = logging.getLogger("regscale")


class QualysIntegration(ScannerIntegration):
    """
    Unified Qualys integration using ScannerIntegration framework.

    This class provides a clean, cohesive workflow for processing Qualys data:
    1. Assets are created first using ScannerIntegration asset processing
    2. Vulnerabilities and issues are then created using ScannerIntegration methods
    3. QID + Security Plan ID used as unique keys for deduplication
    """

    title: str = "Qualys"
    asset_identifier_field: str = "otherTrackingNumber"
    type: ScannerIntegrationType = ScannerIntegrationType.VULNERABILITY

    # QID-based severity mapping (1-5 scale)
    finding_severity_map: Dict[str, Any] = {
        "1": IssueSeverity.Low,
        "2": IssueSeverity.Low,
        "3": IssueSeverity.Moderate,
        "4": IssueSeverity.High,
        "5": IssueSeverity.Critical,
    }

    finding_status_map = {
        "New": IssueStatus.Open,
        "Active": IssueStatus.Open,
        "Fixed": IssueStatus.Closed,
        "Re-Opened": IssueStatus.Open,
    }

    def __init__(self, plan_id: int, is_component: bool = False, **kwargs):
        """
        Initialize QualysIntegration.

        :param int plan_id: RegScale Security Plan or Component ID
        :param bool is_component: Whether syncing to a component (True) or security plan (False)
        :param kwargs: Additional keyword arguments passed to ScannerIntegration
        """
        # Set vulnerability creation mode if not provided
        if "vulnerability_creation" not in kwargs:
            kwargs["vulnerability_creation"] = ScannerVariables.vulnerabilityCreation or "IssueCreation"

        super().__init__(
            plan_id=plan_id,
            is_component=is_component,
            parent_module="components" if is_component else "securityplans",
            **kwargs,
        )

    def fetch_assets(self) -> Iterator[IntegrationAsset]:
        """
        Fetch assets from Qualys API.

        Note: This method is required by ScannerIntegration but QualysIntegration
        uses sync_assets() which accepts pre-fetched Qualys data. This method
        fetches assets from Qualys VMDR API.

        :yield: IntegrationAsset objects
        :rtype: Iterator[IntegrationAsset]
        """
        from regscale.integrations.commercial.qualys import get_qualys_assets_and_scan_results

        logger.info("Fetching assets from Qualys VMDR API...")
        qualys_data = get_qualys_assets_and_scan_results()

        if not qualys_data:
            logger.warning("No assets found in Qualys")
            return

        for asset in self._transform_qualys_assets(qualys_data):
            yield asset

    def fetch_findings(self) -> Iterator[IntegrationFinding]:
        """
        Fetch findings from Qualys API.

        Note: This method is required by ScannerIntegration but QualysIntegration
        uses sync_findings() which accepts pre-fetched Qualys data. This method
        fetches findings from Qualys VMDR API with KB enrichment.

        :yield: IntegrationFinding objects
        :rtype: Iterator[IntegrationFinding]
        """
        from regscale.integrations.commercial.qualys import (
            get_issue_data_for_assets,
            get_qualys_assets_and_scan_results,
        )

        logger.info("Fetching findings from Qualys VMDR API...")
        qualys_assets = get_qualys_assets_and_scan_results()

        if not qualys_assets:
            logger.warning("No assets found in Qualys")
            return

        # Enrich assets with KB data
        qualys_assets_and_issues, _ = get_issue_data_for_assets(qualys_assets)

        for finding in self._transform_qualys_findings(qualys_assets_and_issues):
            yield finding

    def sync_assets(self, qualys_data: List[Dict]) -> int:
        """
        Create/update assets from Qualys data.

        Uses ScannerIntegration asset processing with:
        - uniqueKeyFields: ["otherTrackingNumber"]
        - SSP-scoped identifiers: {host_id}::SSP-{plan_id}

        :param List[Dict] qualys_data: List of Qualys asset dictionaries
        :return: Number of assets processed
        :rtype: int
        """
        logger.info("Syncing %d Qualys assets to RegScale", len(qualys_data))

        # Transform Qualys data to IntegrationAsset objects
        assets = list(self._transform_qualys_assets(qualys_data))

        if not assets:
            logger.warning("No assets to sync")
            return 0

        # Use ScannerIntegration's asset sync method
        assets_processed = self.update_regscale_assets(iter(assets))

        # Mark asset cache as preloaded to prevent redundant warm_cache() during sync_findings
        # This ensures the cache retains the assets we just created
        self._asset_cache.mark_preloaded(build_indexes=True)
        logger.debug("Asset cache marked as preloaded with %d assets", len(self._asset_cache))

        logger.info("Successfully synced %d assets", assets_processed)
        return assets_processed

    def sync_findings(self, qualys_data: List[Dict], dedupe_early: bool = True) -> int:
        """
        Create vulnerabilities and issues from Qualys findings.

        Uses streamBatchCreateOrUpdate endpoint with:
        - uniqueKeys: ["plugInId", "parentId"]
        - assetIdentifierFieldName: "otherTrackingNumber"
        - Early deduplication to reduce findings count

        :param List[Dict] qualys_data: List of Qualys asset dictionaries with ISSUES
        :param bool dedupe_early: Whether to deduplicate findings early (default: True)
        :return: Number of findings processed
        :rtype: int
        """
        logger.info("Syncing Qualys findings to RegScale")

        # Transform Qualys data to IntegrationFinding objects
        findings = list(self._transform_qualys_findings(qualys_data))

        if not findings:
            logger.warning("No findings to sync")
            return 0

        logger.info("Transformed %d findings from Qualys data", len(findings))

        # Early deduplication if requested (reduces ~2319 findings to ~421 issues)
        if dedupe_early:
            findings = self._deduplicate_findings_early(findings)
            logger.info("Early deduplication: reduced findings to %d unique items", len(findings))

        # Use ScannerIntegration's finding sync method
        findings_processed = self.update_regscale_findings(iter(findings))

        logger.info("Successfully synced %d findings", findings_processed)
        return findings_processed

    def _is_valid_cve(self, cve_value: str) -> bool:
        """
        Validate CVE identifier format and reject placeholder values.

        Rejects:
        - Empty strings, None, whitespace
        - Placeholders: "N/A", "None", "null", "Unknown"
        - Invalid formats (must match CVE-YYYY-NNNNN pattern)

        Args:
            cve_value: CVE identifier string to validate

        Returns:
            True if valid CVE format, False otherwise
        """
        if not cve_value or not isinstance(cve_value, str):
            return False

        cve_value = cve_value.strip()

        # Reject placeholder values (case-insensitive)
        invalid_values = {"", "n/a", "none", "null", "unknown", "not applicable", "na"}
        if cve_value.lower() in invalid_values:
            logger.debug(f"CVE_VALIDATION: Rejected placeholder: '{cve_value}'")
            return False

        # Validate CVE format: CVE-YYYY-NNNNN (4-7 digit ID)
        import re

        if not re.match(r"^CVE-\d{4}-\d{4,7}$", cve_value, re.IGNORECASE):
            logger.debug(f"CVE_VALIDATION: Rejected invalid format: '{cve_value}'")
            return False

        return True

    def _transform_qualys_assets(self, qualys_data: List[Dict]) -> Iterator[IntegrationAsset]:
        """
        Transform Qualys asset data to IntegrationAsset objects.

        :param List[Dict] qualys_data: List of Qualys asset dictionaries
        :yield: IntegrationAsset objects
        :rtype: Iterator[IntegrationAsset]
        """
        for qualys_asset in qualys_data:
            asset = self._create_integration_asset_from_qualys(qualys_asset)
            if asset:
                yield asset

    def _create_integration_asset_from_qualys(self, qualys_asset: Dict) -> Optional[IntegrationAsset]:
        """
        Create an IntegrationAsset from Qualys asset data.

        :param Dict qualys_asset: Qualys asset dictionary
        :return: IntegrationAsset object or None if creation fails
        :rtype: Optional[IntegrationAsset]
        """
        try:
            # Extract asset ID (support both ASSET_ID and ID fields)
            asset_id = qualys_asset.get("ASSET_ID") or qualys_asset.get("ID")
            if not asset_id:
                logger.warning("Skipping asset without ASSET_ID or ID: %s", qualys_asset)
                return None

            # Create SSP-scoped identifier for deduplication
            identifier = f"{asset_id}::SSP-{self.plan_id}"

            # Determine tracking method and source label
            tracking_method = qualys_asset.get("TRACKING_METHOD", "VMDR")
            source_labels = {
                "CONTAINER": "Container",
                "TOTALCLOUD": "Total Cloud",
                "WAS": "WAS",
            }
            source_label = source_labels.get(tracking_method, "VMDR")

            # Extract asset information
            ip_address = self._sanitize_ip_address(qualys_asset.get("IP", ""))
            dns = qualys_asset.get("DNS", "") or qualys_asset.get("HOSTNAME", "")
            os_info = qualys_asset.get("OS", "")

            # Build asset name
            name_parts = [f"Qualys {source_label} #{asset_id}"]
            if ip_address:
                name_parts.append(f"IP: {ip_address}")
            name = " ".join(name_parts)

            return IntegrationAsset(
                name=name,
                identifier=identifier,
                other_tracking_number=identifier,  # Use SSP-scoped identifier
                ip_address=ip_address or None,  # None if empty for proper validation
                fqdn=dns,
                operating_system=os_info,
                asset_type="Server",
                asset_category="IT",
                status=AssetStatus.Active,
                external_id=str(asset_id),
                parent_id=self.plan_id,
                parent_module=self.parent_module,
                scanning_tool="Qualys",
                notes=f"Qualys Asset ID: {asset_id} - Source: {source_label}",
            )

        except Exception as e:
            logger.warning("Failed to create IntegrationAsset from Qualys data: %s", e)
            logger.debug("Qualys asset data: %s", qualys_asset)
            return None

    def _transform_qualys_findings(self, qualys_data: List[Dict]) -> Iterator[IntegrationFinding]:
        """
        Transform Qualys vulnerability data to IntegrationFinding objects.

        :param List[Dict] qualys_data: List of Qualys asset dictionaries with ISSUES
        :yield: IntegrationFinding objects
        :rtype: Iterator[IntegrationFinding]
        """
        for qualys_asset in qualys_data:
            issues = qualys_asset.get("ISSUES", {})
            if not issues:
                continue

            # Get asset identifier for linking
            asset_id = qualys_asset.get("ASSET_ID") or qualys_asset.get("ID")
            asset_identifier = f"{asset_id}::SSP-{self.plan_id}" if asset_id else None

            # Extract and sanitize asset DNS and IP for vulnerabilities
            asset_dns = qualys_asset.get("DNS", "unknown")
            asset_ip = self._sanitize_ip_address(qualys_asset.get("IP", ""))

            # Transform each vulnerability
            for vuln_id, vuln in issues.items():
                finding = self._create_integration_finding_from_qualys(vuln, asset_identifier, asset_dns, asset_ip)
                if finding:
                    yield finding

    def _get_issue_data(self, vuln: Dict, qid: str) -> Dict:
        """
        Extract or build issue_data from vulnerability.

        If ISSUE_DATA exists, return it. Otherwise build minimal issue_data from top-level fields.

        :param Dict vuln: Raw vulnerability dictionary
        :param str qid: Qualys QID
        :return: Issue data dictionary
        :rtype: Dict
        """
        issue_data = vuln.get("ISSUE_DATA", {})
        if not issue_data and vuln.get("TITLE"):
            # Fallback: create minimal issue_data from top-level fields
            issue_data = {
                "TITLE": vuln.get("TITLE", f"Vulnerability QID {qid}"),
                "DIAGNOSIS": vuln.get("DIAGNOSIS", ""),
                "CONSEQUENCE": vuln.get("CONSEQUENCE", ""),
                "SOLUTION": vuln.get("SOLUTION", ""),
                "CVE": vuln.get("CVE", ""),
                "CVSS3_BASE": vuln.get("CVSS3_BASE"),
                "CVSS_BASE": vuln.get("CVSS_BASE"),
            }
        return issue_data

    def _get_cve_id_from_entry(self, cve_entry: Any) -> str:
        """Extract CVE ID from a single CVE entry (dict or string)."""
        if isinstance(cve_entry, dict):
            return cve_entry.get("ID", "")
        if isinstance(cve_entry, str):
            return cve_entry
        return ""

    def _extract_cve_from_cve_list(self, cve_list_data: Any, qid: str) -> str:
        """
        Extract CVE from CVE_LIST structure (handles both dict and list formats).

        :param Any cve_list_data: CVE_LIST data (dict or other)
        :param str qid: QID for logging
        :return: First valid CVE or empty string
        :rtype: str
        """
        if not isinstance(cve_list_data, dict):
            return ""

        cve_entries = cve_list_data.get("CVE")
        if not cve_entries:
            return ""

        # Handle single CVE as dict
        if isinstance(cve_entries, dict):
            cve_candidate = cve_entries.get("ID", "")
            if self._is_valid_cve(cve_candidate):
                logger.debug(f"CVE_LIST_SINGLE: QID {qid} extracted {cve_candidate}")
                return cve_candidate
            return ""

        # Handle list of CVEs - take first valid one
        if isinstance(cve_entries, list):
            for idx, cve_entry in enumerate(cve_entries):
                cve_candidate = self._get_cve_id_from_entry(cve_entry)
                if self._is_valid_cve(cve_candidate):
                    logger.debug(f"CVE_LIST_MULTI: QID {qid} extracted {cve_candidate} at index {idx}")
                    return cve_candidate

        return ""

    def _extract_cve_from_qualys(self, vuln: Dict, issue_data: Dict, qid: str) -> str:
        """
        Extract CVE from Qualys vulnerability data using priority-based approach.

        Priority order:
        1. CVE_LIST.CVE[].ID structure (Total Cloud/VMDR)
        2. CVE_ID field (Total Cloud containers, JSONL data)
        3. Direct CVE field
        4. QID field contains CVE (mock server compatibility)

        :param Dict vuln: Raw vulnerability dictionary
        :param Dict issue_data: Extracted issue data
        :param str qid: Qualys QID
        :return: CVE string or empty string if not found
        :rtype: str
        """
        # PRIORITY 1: CVE_LIST.CVE[].ID structure (Total Cloud/VMDR)
        cve_list = issue_data.get("CVE_LIST") or vuln.get("CVE_LIST")
        cve = self._extract_cve_from_cve_list(cve_list, qid)
        if cve:
            return cve

        # PRIORITY 2: CVE_ID field (Total Cloud containers, JSONL data)
        cve_candidate = vuln.get("CVE_ID", "") or issue_data.get("CVE_ID", "")
        if self._is_valid_cve(cve_candidate):
            logger.debug(f"CVE_ID_FIELD: QID {qid} extracted {cve_candidate}")
            return cve_candidate

        # PRIORITY 3: Direct CVE field (with validation to reject "N/A")
        cve_candidate = issue_data.get("CVE", "") or vuln.get("CVE", "")
        if self._is_valid_cve(cve_candidate):
            logger.debug(f"CVE_FIELD: QID {qid} extracted {cve_candidate}")
            return cve_candidate
        elif cve_candidate:
            logger.debug(f"CVE_REJECTED: QID {qid} invalid value '{cve_candidate}'")

        # PRIORITY 4: QID field contains CVE (mock server compatibility)
        if str(qid).upper().startswith("CVE-") and self._is_valid_cve(str(qid)):
            logger.debug(f"CVE_FROM_QID: QID {qid} detected as CVE")
            return str(qid)

        logger.debug(f"CVE_FINAL: QID {qid} - issue_data.CVE={issue_data.get('CVE', 'N/A')}, final_cve=(none)")
        return ""

    def _build_finding_title(self, raw_title: str, cve: str) -> str:
        """
        Build finding title with CVE prefix when available.

        :param str raw_title: Raw title from issue_data
        :param str cve: CVE identifier (may be empty)
        :return: Formatted title
        :rtype: str
        """
        if cve and cve not in raw_title:
            return f"{cve}: {raw_title}"
        return raw_title

    def _build_plugin_info(self, cve: str, qid: str) -> Tuple[str, str, str]:
        """
        Build plugin name, plugin ID, and finding ID.

        :param str cve: CVE identifier (may be empty)
        :param str qid: Qualys QID
        :return: Tuple of (plugin_name, plugin_id, finding_id)
        :rtype: Tuple[str, str, str]
        """
        if cve:
            plugin_name = str(cve)  # CVE as display name
            plugin_id = str(cve)  # CVE as unique identifier
            finding_id = f"{cve}::SSP-{self.plan_id}"
            logger.debug(f"FINDING_CVE_DEBUG: QID {qid} using CVE {cve} as plugin_name/plugin_id")
        else:
            plugin_name = f"QID-{qid}"  # QID as display name
            plugin_id = str(qid)  # QID as unique identifier
            finding_id = f"QID-{qid}::SSP-{self.plan_id}"
            logger.debug(f"FINDING_CVE_DEBUG: QID {qid} has no CVE, using QID as plugin_name/plugin_id")
        return plugin_name, plugin_id, finding_id

    def _parse_cvss_score(self, score: Any) -> Optional[float]:
        """
        Parse CVSS score to float, returning None if invalid.

        :param Any score: Raw CVSS score (string or number)
        :return: Float score or None
        :rtype: Optional[float]
        """
        if score and isinstance(score, str):
            try:
                return float(score)
            except (ValueError, TypeError):
                return None
        return score

    def _extract_and_validate_timestamps(self, vuln: Dict, qid: str) -> Tuple[str, str]:
        """
        Extract first_found and last_found timestamps, validating order.

        :param Dict vuln: Raw vulnerability dictionary
        :param str qid: QID for logging
        :return: Tuple of (first_found, last_found) with corrected order
        :rtype: Tuple[str, str]
        """
        first_found = vuln.get("FIRST_FOUND_DATETIME") or vuln.get("FIRST_FOUND", get_current_datetime())
        last_found = vuln.get("LAST_FOUND_DATETIME") or vuln.get("LAST_FOUND", get_current_datetime())

        # Validate timestamps: firstSeen cannot be after lastSeen
        if first_found > last_found:
            logger.warning(
                "QID %s: Invalid timestamp order from Qualys API - "
                "first_found (%s) is after last_found (%s). Swapping to prevent API error. "
                "This may indicate a data quality issue in Qualys.",
                qid,
                first_found,
                last_found,
            )
            first_found, last_found = last_found, first_found

        return first_found, last_found

    def _create_integration_finding_from_qualys(
        self,
        vuln: Dict,
        asset_identifier: Optional[str],
        asset_dns: str = "unknown",
        asset_ip: str = "",
    ) -> Optional[IntegrationFinding]:
        """
        Create an IntegrationFinding from Qualys vulnerability data.

        :param Dict vuln: Qualys vulnerability dictionary
        :param Optional[str] asset_identifier: Asset identifier string (SSP-scoped)
        :param str asset_dns: Asset DNS name
        :param str asset_ip: Asset IP address
        :return: IntegrationFinding object or None if creation fails
        :rtype: Optional[IntegrationFinding]
        """
        try:
            # Extract QID
            qid = vuln.get("QID") or vuln.get("QUALYS_ID") or vuln.get("PLUGIN_ID") or "Unknown"

            # Extract severity
            severity_raw = vuln.get("SEVERITY", "3")
            severity = self.get_finding_severity(str(severity_raw))

            # Get issue data (with fallback construction)
            issue_data = self._get_issue_data(vuln, qid)
            logger.debug(f"RAW_ISSUE_DATA for QID {qid}: {issue_data}")

            # Extract CVE using priority-based approach
            cve = self._extract_cve_from_qualys(vuln, issue_data, qid)

            # Build title
            raw_title = issue_data.get("TITLE", f"Qualys Vulnerability QID-{qid}")
            title = self._build_finding_title(raw_title, cve)

            # Build description
            description = self._build_description(issue_data)

            # Build plugin info
            plugin_name, plugin_id, finding_id = self._build_plugin_info(cve, qid)

            # Extract and validate timestamps
            first_found, last_found = self._extract_and_validate_timestamps(vuln, qid)

            # Calculate due date
            due_date = issue_due_date(
                severity=severity,
                created_date=first_found,
                title=self.title,
                config=self.app.config,
            )

            # Extract and parse CVSS scores
            cvss_v3_score = self._parse_cvss_score(vuln.get("CVSS3_BASE") or issue_data.get("CVSS3_BASE"))
            cvss_v2_score = self._parse_cvss_score(vuln.get("CVSS_BASE") or issue_data.get("CVSS_BASE"))

            # Get solution/remediation
            solution = issue_data.get("SOLUTION", "") or vuln.get("REMEDIATION", "")

            # Extract status
            status_raw = vuln.get("STATUS", "New")
            status = self.get_finding_status(status_raw)

            return IntegrationFinding(
                title=title,
                description=description,
                external_id=finding_id,
                severity=severity,
                status=status,
                asset_identifier=asset_identifier or "",
                issue_asset_identifier_value=asset_identifier or "",
                dns=asset_dns,
                ip_address=asset_ip or None,
                plugin_name=plugin_name,
                plugin_id=plugin_id,
                category="Vulnerability",
                identification="Vulnerability Assessment",
                remediation=solution,
                recommendation_for_mitigation=solution,
                cve=cve if (cve and self._is_valid_cve(cve)) else None,
                cvss_v3_score=cvss_v3_score,
                cvss_v2_score=cvss_v2_score,
                cvss_v3_vector=vuln.get("CVSS3_VECTOR", ""),
                cvss_v2_vector=vuln.get("CVSS_VECTOR", ""),
                first_seen=first_found,
                last_seen=last_found,
                date_created=first_found,
                scan_date=get_current_datetime(),
                due_date=due_date,
                control_labels=[f"QID-{qid}"],
            )

        except Exception as e:
            logger.warning("Failed to create IntegrationFinding from Qualys vulnerability: %s", e)
            logger.debug("Qualys vulnerability data: %s", vuln)
            return None

    def _build_description(self, issue_data: Dict) -> str:
        """
        Build issue description from vulnerability data.

        :param Dict issue_data: Issue data dictionary
        :return: Formatted description
        :rtype: str
        """
        parts = []
        if issue_data.get("CONSEQUENCE"):
            parts.append(issue_data["CONSEQUENCE"])
        if issue_data.get("DIAGNOSIS"):
            parts.append(issue_data["DIAGNOSIS"])
        if issue_data.get("THREAT"):
            parts.append(f"Threat: {issue_data['THREAT']}")
        if issue_data.get("IMPACT"):
            parts.append(f"Impact: {issue_data['IMPACT']}")

        return "</br>".join(parts) if parts else "No description available"

    def _sanitize_ip_address(self, ip: str) -> str:
        """
        Sanitize IP address by replacing invalid formats with empty string.

        RegScale's API validation rejects non-standard IP formats like "WebApp", "Container", etc.
        This function ensures only valid IP addresses or empty strings are passed.

        :param str ip: Raw IP address from Qualys API
        :return: Sanitized IP address or empty string
        :rtype: str
        """
        if not ip:
            return ""

        # Known invalid IP formats from Qualys
        invalid_ips = {"webapp", "container", "web application", "unknown", "n/a"}

        if ip.lower() in invalid_ips:
            return ""

        return ip

    def _merge_asset_identifiers(self, existing: IntegrationFinding, new_asset_id: str) -> None:
        """
        Merge asset identifiers for issue display while preserving first asset for vulnerability creation.

        :param IntegrationFinding existing: Existing finding to update
        :param str new_asset_id: New asset identifier to merge
        """
        if not new_asset_id:
            return

        if not existing.issue_asset_identifier_value:
            existing.issue_asset_identifier_value = new_asset_id
            return

        # Append if not already present
        existing_assets = set(existing.issue_asset_identifier_value.split("\n"))
        if new_asset_id not in existing_assets:
            existing.issue_asset_identifier_value = f"{existing.issue_asset_identifier_value}\n{new_asset_id}"

    def _deduplicate_findings_early(self, findings: List[IntegrationFinding]) -> List[IntegrationFinding]:
        """
        Deduplicate findings early by QID + SSP ID.

        This reduces the number of findings before submission (e.g., ~2319 findings to ~421 issues).

        :param List[IntegrationFinding] findings: List of findings to deduplicate
        :return: Deduplicated list of findings
        :rtype: List[IntegrationFinding]
        """
        deduplicated: Dict[str, IntegrationFinding] = {}

        for finding in findings:
            key = finding.external_id

            if key in deduplicated:
                # Combine asset identifiers for issue display ONLY
                # Keep asset_identifier as first asset for vulnerability creation
                self._merge_asset_identifiers(deduplicated[key], finding.asset_identifier)
            else:
                deduplicated[key] = finding

        return list(deduplicated.values())

    def get_finding_status(self, status: Optional[str]) -> IssueStatus:
        """
        Convert Qualys status to RegScale IssueStatus.

        :param Optional[str] status: Qualys status string
        :return: RegScale IssueStatus
        :rtype: IssueStatus
        """
        if not status:
            return IssueStatus.Open

        normalized_status = status.strip() if isinstance(status, str) else str(status)
        return self.finding_status_map.get(normalized_status, IssueStatus.Open)

    def _build_asset_batch_options(self):
        """
        Build batch options for Qualys asset creation.

        Overrides parent to enable mop-up and use otherTrackingNumber as uniqueKeyFields.

        :return: AssetBatchOptions configured for Qualys
        :rtype: AssetBatchOptions
        """
        from regscale.models.regscale_models.batch_options import AssetBatchOptions

        return AssetBatchOptions(
            source=self.title,
            uniqueKeyFields=[self.asset_identifier_field],  # ["otherTrackingNumber"]
            enableMopUp=True,  # Enable mop-up for assets not in scan
            mopUpStatus="Off-Network",
            parentId=self.plan_id,
            parentModule=self.parent_module,
        )

    def _build_vulnerability_batch_options(self):
        """
        Build batch options for Qualys vulnerability creation.

        Overrides parent to use exact uniqueKeys as specified: ["plugInId", "parentId"]
        Uses otherTrackingNumber as assetIdentifierFieldName per requirements.

        :return: VulnerabilityBatchOptions configured for Qualys
        :rtype: VulnerabilityBatchOptions
        """
        from regscale.integrations.variables import ScannerVariables
        from regscale.models.regscale_models.batch_options import VulnerabilityBatchOptions

        return VulnerabilityBatchOptions(
            source=self.title,
            uniqueKeys=["plugInId", "parentId"],  # Exact match to requirements
            enableMopUp=ScannerVariables.closeFindingsNotInScan,
            mopUpStatus="Closed",
            enableAssetDiscovery=True,  # Enable asset discovery for linking
            suppressAssetNotFoundWarnings=True,
            poamCreation=False,  # POAM creation handled via issues
            assetIdentifierFieldName=self.asset_identifier_field,  # "otherTrackingNumber"
            assetIdentifierPoamDisplay=self.asset_identifier_field,
            parentId=self.plan_id,
            parentModule=self.parent_module,
        )
