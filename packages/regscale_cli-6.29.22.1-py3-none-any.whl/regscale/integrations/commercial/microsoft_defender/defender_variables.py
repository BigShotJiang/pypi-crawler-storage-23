#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Microsoft Defender Integration Variables"""

from regscale.integrations.variables import RsVariablesMeta, RsVariableType


BEARER_TOKEN = "Bearer <access_token>"
CLIENT_ID = "myClientIdGoesHere"
SECRET = "mySecretGoesHere"
TENANT_ID = "myTenantIdGoesHere"
SUBSCRIPTION_ID = "mySubscriptionIdGoesHere"


class DefenderVariables(metaclass=RsVariablesMeta):
    """
    Microsoft Defender Variables class to define class-level attributes with type annotations and examples
    """

    # API Connection Settings
    # Access tokens are marked as hidden because they are runtime-only values obtained via authentication
    # They should never be persisted to init.yaml, only used in memory during the session
    azure365AccessToken: RsVariableType(str, default=BEARER_TOKEN, example=BEARER_TOKEN, required=False, hidden=True)  # type: ignore
    azure365ClientId: RsVariableType(str, default=CLIENT_ID, example=CLIENT_ID)  # type: ignore
    azure365Secret: RsVariableType(str, default=SECRET, example=SECRET, sensitive=True)  # type: ignore
    azure365TenantId: RsVariableType(str, default=TENANT_ID, example=TENANT_ID)  # type: ignore
    azureCloudAccessToken: RsVariableType(str, default=BEARER_TOKEN, example=BEARER_TOKEN, required=False, hidden=True)  # type: ignore
    azureCloudClientId: RsVariableType(str, default=CLIENT_ID, example=CLIENT_ID)  # type: ignore
    azureCloudEnvironment: RsVariableType(
        str, example="commercial|government|china", default="commercial", required=False
    )  # type: ignore
    azureCloudSecret: RsVariableType(str, default=SECRET, example=SECRET, sensitive=True)  # type: ignore
    azureCloudSubscriptionId: RsVariableType(str, default=SUBSCRIPTION_ID, example=SUBSCRIPTION_ID)  # type: ignore
    azureCloudTenantId: RsVariableType(str, default=TENANT_ID, example=TENANT_ID)  # type: ignore
    azureEntraAccessToken: RsVariableType(str, default=BEARER_TOKEN, example=BEARER_TOKEN, required=False, hidden=True)  # type: ignore
    azureEntraClientId: RsVariableType(str, default=CLIENT_ID, example=CLIENT_ID)  # type: ignore
    azureEntraSecret: RsVariableType(str, default=SECRET, example=SECRET, sensitive=True)  # type: ignore
    azureEntraTenantId: RsVariableType(str, default=TENANT_ID, example=TENANT_ID)  # type: ignore
    defenderBaseUrl: RsVariableType(str, default="", example="http://localhost:8000", required=False, hidden=True)  # type: ignore
