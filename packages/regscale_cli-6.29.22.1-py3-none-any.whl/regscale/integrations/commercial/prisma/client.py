#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Prisma Cloud REST API Client

This module provides a REST API client for Prisma Cloud Compute with support for:
- Host vulnerability scanning
- Container image vulnerability scanning
- SBOM (Software Bill of Materials) retrieval
- Pagination, retry logic, and rate limiting
"""

import logging
import time
from typing import Dict, Iterator, List, Optional
from urllib.parse import quote, urljoin

import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

logger = logging.getLogger("regscale")


class PrismaCloudClient:
    """REST API client for Prisma Cloud Compute Console."""

    def __init__(
        self,
        console_url: str,
        token: str,
        verify_ssl: bool = True,
        timeout: int = 30,
        max_retries: int = 3,
        rate_limit_delay: float = 0.1,
    ):
        """
        Initialize Prisma Cloud API client.

        :param str console_url: Prisma Cloud Console URL (e.g., https://console.example.com:8083)
        :param str token: Bearer token from authentication
        :param bool verify_ssl: Verify SSL certificates (default True)
        :param int timeout: Request timeout in seconds (default 30)
        :param int max_retries: Number of retry attempts for failed requests (default 3)
        :param float rate_limit_delay: Delay between requests in seconds (default 0.1 = 10 req/sec)
        """
        self.console_url = console_url.rstrip("/")
        self.token = token
        self.verify_ssl = verify_ssl
        self.timeout = timeout
        self.rate_limit_delay = rate_limit_delay

        # Set up session with retry logic
        self.session = requests.Session()
        retry_strategy = Retry(
            total=max_retries,
            backoff_factor=1,  # Exponential backoff: 1s, 2s, 4s
            status_forcelist=[429, 500, 502, 503, 504],
            allowed_methods=["GET", "POST"],
        )
        adapter = HTTPAdapter(max_retries=retry_strategy)
        self.session.mount("https://", adapter)
        self.session.mount("http://", adapter)

        # Set default headers
        self.session.headers.update(
            {
                "Authorization": f"Bearer {self.token}",
                "Content-Type": "application/json",
                "Accept": "application/json",
            }
        )

        logger.info("Initialized Prisma Cloud client for %s", self.console_url)

    def _request(
        self,
        method: str,
        endpoint: str,
        params: Optional[Dict] = None,
        json_data: Optional[Dict] = None,
        stream: bool = False,
    ) -> requests.Response:
        """
        Make an API request with rate limiting and error handling.

        :param str method: HTTP method (GET, POST, etc.)
        :param str endpoint: API endpoint path (e.g., /api/v1/hosts)
        :param Optional[Dict] params: Query parameters
        :param Optional[Dict] json_data: JSON payload for POST requests
        :param bool stream: Enable streaming for large downloads (default False)
        :return: Response object
        :rtype: requests.Response
        :raises requests.HTTPError: If request fails
        """
        url = urljoin(self.console_url, endpoint)

        # Apply rate limiting
        if self.rate_limit_delay > 0:
            time.sleep(self.rate_limit_delay)

        try:
            logger.debug("%s %s (params: %s, stream: %s)", method, url, params, stream)
            response = self.session.request(
                method=method,
                url=url,
                params=params,
                json=json_data,
                verify=self.verify_ssl,
                timeout=self.timeout,
                stream=stream,
            )

            # Raise exception for HTTP errors
            response.raise_for_status()

            return response

        except requests.HTTPError as e:
            logger.error("HTTP %s error for %s %s: %s", e.response.status_code, method, url, e.response.text)
            raise
        except requests.RequestException as e:
            logger.error("Request failed for %s %s: %s", method, url, e)
            raise

    def _paginate(
        self,
        endpoint: str,
        params: Optional[Dict] = None,
        page_size: int = 50,
        offset: int = 0,
        max_items: int = 0,
    ) -> Iterator[Dict]:
        """
        Paginate through API results using offset-based pagination.

        Prisma Cloud uses offset/limit pagination. This generator yields individual
        items from paginated responses until all data is retrieved.

        :param str endpoint: API endpoint to paginate
        :param Optional[Dict] params: Additional query parameters
        :param int page_size: Number of items per page (default 50)
        :param int offset: Starting offset for pagination (default 0)
        :param int max_items: Maximum number of items to retrieve (0 = unlimited, default 0)
        :yield: Individual items from paginated results
        :rtype: Iterator[Dict]
        """
        if params is None:
            params = {}

        current_offset = offset
        total_retrieved = 0

        while True:
            # Set pagination parameters
            page_params = {**params, "offset": current_offset, "limit": page_size}

            response = self._request("GET", endpoint, params=page_params)
            data = response.json()

            # Handle different response formats
            # Prisma may return array directly or nested in a field
            if isinstance(data, list):
                items = data
            elif isinstance(data, dict):
                # Try common field names for lists
                items = data.get("value", data.get("items", data.get("data", [])))
            else:
                logger.warning("Unexpected response format from %s: %s", endpoint, type(data))
                break

            # Yield individual items
            for item in items:
                yield item
                total_retrieved += 1

                # Stop if we've reached max_items
                if max_items > 0 and total_retrieved >= max_items:
                    logger.info(
                        "Reached max_items limit (%d) for %s: %d total items retrieved",
                        max_items,
                        endpoint,
                        total_retrieved,
                    )
                    return

            # Check if we've retrieved all items
            items_count = len(items)
            logger.debug(
                "Retrieved %d items from %s (offset: %d, total: %d)",
                items_count,
                endpoint,
                current_offset,
                total_retrieved,
            )

            if items_count < page_size:
                # Last page reached
                logger.info("Pagination complete for %s: %d total items retrieved", endpoint, total_retrieved)
                break

            # Move to next page
            current_offset += page_size

    def get_hosts(
        self,
        filters: Optional[Dict] = None,
        page_size: int = 50,
        offset: int = 0,
        max_items: int = 0,
    ) -> Iterator[Dict]:
        """
        Retrieve host scan results from Prisma Cloud.

        API Documentation: https://pan.dev/compute/api/hosts/

        :param Optional[Dict] filters: Filter parameters (e.g., {"collections": ["prod"]})
        :param int page_size: Number of items per page (default 50)
        :param int offset: Starting offset for pagination (default 0)
        :param int max_items: Maximum number of items to retrieve (0 = unlimited, default 0)
        :yield: Host data dictionaries
        :rtype: Iterator[Dict]

        Example:
            >>> client = PrismaCloudClient(console_url, token)
            >>> for host in client.get_hosts():
            ...     print(host['hostname'])
        """
        endpoint = "/api/v1/hosts"
        logger.info("Fetching hosts from %s", self.console_url)

        params = filters or {}

        yield from self._paginate(endpoint, params=params, page_size=page_size, offset=offset, max_items=max_items)

    def get_images(
        self,
        filters: Optional[Dict] = None,
        page_size: int = 50,
        offset: int = 0,
        max_items: int = 0,
    ) -> Iterator[Dict]:
        """
        Retrieve container image scan results from Prisma Cloud.

        API Documentation: https://pan.dev/compute/api/images/

        :param Optional[Dict] filters: Filter parameters (e.g., {"collections": ["prod"]})
        :param int page_size: Number of items per page (default 50)
        :param int offset: Starting offset for pagination (default 0)
        :param int max_items: Maximum number of items to retrieve (0 = unlimited, default 0)
        :yield: Image data dictionaries
        :rtype: Iterator[Dict]

        Example:
            >>> client = PrismaCloudClient(console_url, token)
            >>> for image in client.get_images():
            ...     print(image['imageName'])
        """
        endpoint = "/api/v1/images"
        logger.info("Fetching images from %s", self.console_url)

        params = filters or {}

        yield from self._paginate(endpoint, params=params, page_size=page_size, offset=offset, max_items=max_items)

    def get_sbom(
        self,
        resource_type: str,
        resource_id: str,
    ) -> Dict:
        """
        Retrieve SBOM (Software Bill of Materials) for a specific resource.

        API Documentation: https://pan.dev/compute/api/sbom/

        :param str resource_type: Type of resource ("host" or "image")
        :param str resource_id: Resource identifier (hostname or image ID)
        :return: SBOM data in CycloneDX format
        :rtype: Dict
        :raises ValueError: If resource_type is invalid

        Example:
            >>> client = PrismaCloudClient(console_url, token)
            >>> sbom = client.get_sbom("image", "sha256:abc123...")
            >>> print(f"SBOM format: {sbom['bomFormat']}")
        """
        if resource_type not in ["host", "image"]:
            raise ValueError(f"Invalid resource_type: {resource_type}. Must be 'host' or 'image'")

        endpoint = f"/api/v1/sbom/{quote(resource_type, safe='')}/{quote(resource_id, safe='')}"
        logger.info("Fetching SBOM for %s: %s", resource_type, resource_id)

        response = self._request("GET", endpoint)
        sbom_data = response.json()

        logger.debug("Retrieved SBOM for %s/%s", resource_type, resource_id)
        return sbom_data

    def get_sbom_download_hosts(self) -> bytes:
        """
        Download bulk SBOM data for all hosts.

        This endpoint returns a tar.gz file containing CycloneDX SBOMs for all hosts.
        This is the recommended method for bulk SBOM retrieval as it avoids making
        individual API calls for each host.

        Based on Platform One (P1) customer feedback, this endpoint resolves HTTP 404
        errors encountered with individual SBOM endpoints.

        API Documentation: https://pan.dev/compute/api/sbom/
        Endpoint: GET /api/v1/sbom/download/hosts

        :return: Raw tar.gz file bytes containing SBOM JSON files
        :rtype: bytes

        Example:
            >>> client = PrismaCloudClient(console_url, token)
            >>> tar_gz_data = client.get_sbom_download_hosts()
            >>> # Extract and parse SBOMs using sbom_processor.extract_sbom_archive()
        """
        endpoint = "/api/v1/sbom/download/hosts"
        logger.info("Downloading bulk SBOM data for all hosts from %s", self.console_url)

        response = self._request("GET", endpoint, stream=True)
        sbom_archive = response.content

        logger.info("Downloaded bulk host SBOM archive: %d bytes", len(sbom_archive))
        return sbom_archive

    def get_sbom_download_images(self) -> bytes:
        """
        Download bulk SBOM data for all container images.

        This endpoint returns a tar.gz file containing CycloneDX SBOMs for all images.
        This is the recommended method for bulk SBOM retrieval as it avoids making
        individual API calls for each image.

        Based on Platform One (P1) customer feedback, this endpoint resolves HTTP 404
        errors encountered with individual SBOM endpoints.

        API Documentation: https://pan.dev/compute/api/sbom/
        Endpoint: GET /api/v1/sbom/download/images

        :return: Raw tar.gz file bytes containing SBOM JSON files
        :rtype: bytes

        Example:
            >>> client = PrismaCloudClient(console_url, token)
            >>> tar_gz_data = client.get_sbom_download_images()
            >>> # Extract and parse SBOMs using sbom_processor.extract_sbom_archive()
        """
        endpoint = "/api/v1/sbom/download/images"
        logger.info("Downloading bulk SBOM data for all images from %s", self.console_url)

        response = self._request("GET", endpoint, stream=True)
        sbom_archive = response.content

        logger.info("Downloaded bulk image SBOM archive: %d bytes", len(sbom_archive))
        return sbom_archive

    def get_hosts_csv(self) -> str:
        """
        Download CSV export of all host vulnerabilities.

        This endpoint provides a more efficient alternative to JSON pagination for
        bulk data retrieval. The CSV format includes all host vulnerability data
        in a single request.

        Based on Platform One (P1) customer workflow, this endpoint is used for
        efficient bulk data processing with comma-separated host list handling.

        API Documentation: https://pan.dev/compute/api/hosts/
        Endpoint: GET /api/v1/hosts/download

        :return: CSV string with all host vulnerability data
        :rtype: str

        Example:
            >>> client = PrismaCloudClient(console_url, token)
            >>> csv_data = client.get_hosts_csv()
            >>> # Parse using csv_parser.parse_prisma_csv()
        """
        endpoint = "/api/v1/hosts/download"
        logger.info("Downloading CSV export of all hosts from %s", self.console_url)

        response = self._request("GET", endpoint)
        csv_data = response.text

        logger.info("Downloaded host CSV data: %d characters", len(csv_data))
        return csv_data

    def get_images_csv(self) -> str:
        """
        Download CSV export of all image vulnerabilities.

        This endpoint provides a more efficient alternative to JSON pagination for
        bulk data retrieval. The CSV format includes all image vulnerability data
        in a single request.

        Based on Platform One (P1) customer workflow, this endpoint is used for
        efficient bulk data processing with comma-separated host list handling.

        API Documentation: https://pan.dev/compute/api/images/
        Endpoint: GET /api/v1/images/download

        :return: CSV string with all image vulnerability data
        :rtype: str

        Example:
            >>> client = PrismaCloudClient(console_url, token)
            >>> csv_data = client.get_images_csv()
            >>> # Parse using csv_parser.parse_prisma_csv()
        """
        endpoint = "/api/v1/images/download"
        logger.info("Downloading CSV export of all images from %s", self.console_url)

        response = self._request("GET", endpoint)
        csv_data = response.text

        logger.info("Downloaded image CSV data: %d characters", len(csv_data))
        return csv_data

    def get_host_vulnerabilities(
        self,
        hostname: str,
        filters: Optional[Dict] = None,
    ) -> List[Dict]:
        """
        Retrieve vulnerabilities for a specific host.

        :param str hostname: Hostname to query
        :param Optional[Dict] filters: Additional filter parameters
        :return: List of vulnerability dictionaries
        :rtype: List[Dict]

        Example:
            >>> client = PrismaCloudClient(console_url, token)
            >>> vulns = client.get_host_vulnerabilities("web-server-01")
            >>> print(f"Found {len(vulns)} vulnerabilities")
        """
        endpoint = f"/api/v1/hosts/{quote(hostname, safe='')}"
        logger.info("Fetching vulnerabilities for host: %s", hostname)

        params = filters or {}
        response = self._request("GET", endpoint, params=params)
        host_data = response.json()

        # Extract vulnerabilities from host data
        vulnerabilities = host_data.get("vulnerabilities", [])
        logger.debug("Found %d vulnerabilities for host %s", len(vulnerabilities), hostname)

        return vulnerabilities

    def get_image_vulnerabilities(
        self,
        image_id: str,
        filters: Optional[Dict] = None,
    ) -> List[Dict]:
        """
        Retrieve vulnerabilities for a specific container image.

        :param str image_id: Image ID (sha256 hash or name)
        :param Optional[Dict] filters: Additional filter parameters
        :return: List of vulnerability dictionaries
        :rtype: List[Dict]

        Example:
            >>> client = PrismaCloudClient(console_url, token)
            >>> vulns = client.get_image_vulnerabilities("nginx:1.21")
            >>> print(f"Found {len(vulns)} vulnerabilities")
        """
        endpoint = f"/api/v1/images/{quote(image_id, safe='')}"
        logger.info("Fetching vulnerabilities for image: %s", image_id)

        params = filters or {}
        response = self._request("GET", endpoint, params=params)
        image_data = response.json()

        # Extract vulnerabilities from image data
        vulnerabilities = image_data.get("vulnerabilities", [])
        logger.debug("Found %d vulnerabilities for image %s", len(vulnerabilities), image_id)

        return vulnerabilities

    def test_connection(self) -> bool:
        """
        Test connectivity to Prisma Cloud API.

        :return: True if connection successful, False otherwise
        :rtype: bool

        Example:
            >>> client = PrismaCloudClient(console_url, token)
            >>> if client.test_connection():
            ...     print("Connection successful!")
        """
        try:
            # Use a lightweight endpoint to test connection
            endpoint = "/api/v1/_ping"
            self._request("GET", endpoint)
            logger.info("Connection test successful")
            return True
        except requests.RequestException as e:
            logger.error("Connection test failed: %s", e)
            return False

    def get_collections(self) -> List[Dict]:
        """
        Retrieve available collections from Prisma Cloud.

        Collections are groupings of resources (hosts, images) used for organizing
        and filtering scan results.

        :return: List of collection dictionaries
        :rtype: List[Dict]

        Example:
            >>> client = PrismaCloudClient(console_url, token)
            >>> collections = client.get_collections()
            >>> for col in collections:
            ...     print(f"Collection: {col['name']}")
        """
        endpoint = "/api/v1/collections"
        logger.info("Fetching collections")

        response = self._request("GET", endpoint)
        collections = response.json()

        if isinstance(collections, list):
            logger.debug("Found %d collections", len(collections))
            return collections
        else:
            logger.warning("Unexpected collections response format: %s", type(collections))
            return []

    def close(self):
        """
        Close the HTTP session and clean up resources.

        Example:
            >>> client = PrismaCloudClient(console_url, token)
            >>> try:
            ...     # Use client
            ...     pass
            ... finally:
            ...     client.close()
        """
        self.session.close()
        logger.debug("Closed Prisma Cloud API client session")

    def __enter__(self):
        """Context manager entry."""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit with automatic cleanup."""
        self.close()
