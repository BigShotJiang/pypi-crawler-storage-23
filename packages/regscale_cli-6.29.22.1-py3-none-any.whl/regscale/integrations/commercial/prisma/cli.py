#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Prisma Cloud CLI Commands

This module provides Click commands for Prisma Cloud Compute integration:
- authenticate: Authenticate and cache session token
- sync_hosts: Sync host assets and vulnerabilities
- sync_images: Sync container image assets and vulnerabilities
- sync_sbom: Sync SBOM data as software inventory

For legacy CSV import functionality, see regscale.integrations.commercial.prisma.legacy
"""

import json
import logging
import time
from typing import Optional

import click

from regscale.core.app.api import Api
from regscale.integrations.commercial.prisma.auth import (
    authenticate_with_cache,
)
from regscale.integrations.commercial.prisma.sbom_processor import (
    attach_sbom_as_evidence,
    create_sbom_record,
    create_software_inventory_from_sbom,
    extract_sbom_archive,
    get_sbom_summary,
)
from regscale.models.regscale_models.asset import Asset
from regscale.models.regscale_models.asset import AssetCategory, AssetStatus, AssetType
from regscale.integrations.commercial.prisma.scanner import (
    PrismaCloudScanner,
    _to_dns_safe_identifier,
)
from regscale.integrations.commercial.prisma.variables import PrismaVariables
from regscale.models.app_models.orchestration_options import orchestration_options
from regscale.models.app_models.click import regscale_ssp_id

logger = logging.getLogger("regscale")


# =============================================================================
# Authentication Commands
# =============================================================================


@click.command(name="authenticate")
@click.option(
    "--console-url",
    type=str,
    required=False,
    help="Prisma Cloud Console URL (e.g., https://console.example.com:8083). "
    "Defaults to prismaConsoleUrl from init.yaml.",
)
@click.option(
    "--username",
    type=str,
    required=False,
    help="Prisma Cloud username. Defaults to prismaUsername from init.yaml.",
)
@click.option(
    "--password",
    type=str,
    required=False,
    hide_input=True,
    prompt=False,
    help="Prisma Cloud password. Defaults to prismaPassword from init.yaml. If not provided, will prompt.",
)
@click.option(
    "--force-refresh",
    is_flag=True,
    default=False,
    help="Force re-authentication even if cached token exists.",
)
def authenticate(
    console_url: Optional[str],
    username: Optional[str],
    password: Optional[str],
    force_refresh: bool,
):
    """
    Authenticate to Prisma Cloud Compute and cache session token.

    This command authenticates to Prisma Cloud and caches the bearer token
    locally for 24 hours. The token will be used automatically by other commands.

    Examples:
        # Authenticate using init.yaml settings
        regscale prisma authenticate

        # Authenticate with explicit credentials
        regscale prisma authenticate --console-url https://console.example.com:8083 \\
            --username admin --password mypassword

        # Force refresh of cached token
        regscale prisma authenticate --force-refresh
    """
    try:
        # Use variables from init.yaml if not provided
        console_url = console_url or str(PrismaVariables.prismaConsoleUrl)  # type: ignore
        username = username or str(PrismaVariables.prismaUsername)  # type: ignore

        # Prompt for password if not provided
        if not password:
            password = str(PrismaVariables.prismaPassword) or click.prompt(  # type: ignore
                "Prisma Cloud Password", hide_input=True
            )

        logger.info("Authenticating to Prisma Cloud: %s", console_url)

        # Safe type conversions for variables (handle empty strings)
        api_timeout = PrismaVariables.prismaApiTimeout or 30
        verify_ssl = PrismaVariables.prismaVerifySsl if PrismaVariables.prismaVerifySsl is not None else True

        # Authenticate with caching
        token = authenticate_with_cache(
            console_url=console_url,
            username=username,
            password=password,
            verify_ssl=bool(verify_ssl),
            timeout=int(api_timeout) if api_timeout else 30,
            force_refresh=force_refresh,
        )

        logger.info(
            "Authentication successful! Token cached securely for 24 hours (length: %d characters)",
            len(token),
        )
        logger.info("Cached session stored in ~/.regscale/prisma_sessions/ with restricted permissions")

    except Exception as e:
        logger.error("Authentication failed: %s", e)
        raise click.Abort()


# =============================================================================
# Shared Sync Logic
# =============================================================================


def _parse_filters(filters: Optional[str]) -> Optional[dict]:
    """
    Parse JSON filter string into a dictionary.

    :param Optional[str] filters: JSON filter string
    :return: Parsed filter dictionary or None
    :rtype: Optional[dict]
    :raises click.Abort: If JSON is invalid
    """
    if not filters:
        return None
    try:
        filter_dict = json.loads(filters)
        logger.info("Using filters: %s", json.dumps(filter_dict, indent=2))
        return filter_dict
    except json.JSONDecodeError as e:
        logger.error("Invalid JSON in filters: %s", e)
        raise click.Abort()


def _sync_resources(
    regscale_ssp_id: int,
    scan_type: str,
    filters: Optional[str],
    console_url: Optional[str],
    username: Optional[str],
    password: Optional[str],
    use_csv: bool,
    dry_run: bool,
    offset: int,
    limit: Optional[int],
) -> None:
    """
    Shared sync logic for hosts and images.

    :param int regscale_ssp_id: RegScale Security Plan ID
    :param str scan_type: "hosts" or "images"
    :param Optional[str] filters: JSON filter string
    :param Optional[str] console_url: Override console URL
    :param Optional[str] username: Override username
    :param Optional[str] password: Override password
    :param bool use_csv: Use CSV download endpoint
    :param bool dry_run: Preview mode - validate connectivity and count records without syncing
    :param int offset: Number of records to skip
    :param Optional[int] limit: Maximum number of records to process
    """
    filter_dict = _parse_filters(filters)

    mode_desc = "CSV mode" if use_csv else "JSON API mode"
    logger.info("Using %s for data retrieval", mode_desc)

    scanner_kwargs = {
        "scan_type": scan_type,
        "use_csv": use_csv,
        "console_url": console_url,
        "username": username,
        "password": password,
        "filters": filter_dict,
    }

    if dry_run:
        _run_dry_run(regscale_ssp_id, scan_type, scanner_kwargs)
        return

    if (offset or limit) and use_csv:
        logger.warning("--offset/--limit are ignored in CSV mode. Use JSON API mode (omit --use-csv) for pagination.")

    if offset or limit:
        scanner_kwargs["offset"] = offset
        scanner_kwargs["limit"] = limit

    logger.info("Syncing %s to RegScale SSP %d...", scan_type, regscale_ssp_id)
    PrismaCloudScanner.sync_assets(plan_id=regscale_ssp_id, **scanner_kwargs)

    logger.info("Syncing %s vulnerabilities to RegScale...", scan_type)
    PrismaCloudScanner.sync_findings(plan_id=regscale_ssp_id, **scanner_kwargs)

    logger.info("%s sync completed successfully!", scan_type.capitalize())


def _run_dry_run(regscale_ssp_id: int, scan_type: str, scanner_kwargs: dict) -> None:
    """
    Execute dry-run mode: authenticate, fetch data, and report counts without syncing.

    :param int regscale_ssp_id: RegScale Security Plan ID
    :param str scan_type: "hosts" or "images"
    :param dict scanner_kwargs: Keyword arguments for PrismaCloudScanner
    """
    logger.info("[DRY RUN] Previewing %s sync for SSP %d...", scan_type, regscale_ssp_id)

    scanner = PrismaCloudScanner(plan_id=regscale_ssp_id, **scanner_kwargs)
    scanner.authenticate(
        console_url=scanner_kwargs.get("console_url"),
        username=scanner_kwargs.get("username"),
        password=scanner_kwargs.get("password"),
    )
    logger.info("[DRY RUN] Authentication successful")

    # Count assets and findings in a single pass per iterator
    asset_count = sum(1 for _ in scanner.fetch_assets(**scanner_kwargs))
    logger.info("[DRY RUN] Assets that would be synced: %d", asset_count)

    finding_count = sum(1 for _ in scanner.fetch_findings(**scanner_kwargs))
    logger.info("[DRY RUN] Findings that would be synced: %d", finding_count)

    logger.info(
        "[DRY RUN] Summary: %d assets, %d findings would be synced to SSP %d",
        asset_count,
        finding_count,
        regscale_ssp_id,
    )
    logger.info("[DRY RUN] No records were created or updated")


# =============================================================================
# Asset and Finding Sync Commands
# =============================================================================


@click.command(name="sync_hosts")
@regscale_ssp_id()
@click.option(
    "--filters",
    type=str,
    required=False,
    help='JSON filter string for Prisma API query (e.g., \'{"collections": ["prod"]}\')',
)
@click.option(
    "--enable-software-inventory",
    is_flag=True,
    default=False,
    help="Create software inventory records from SBOM data for each host.",
)
@click.option(
    "--console-url",
    type=str,
    required=False,
    help="Override Prisma Console URL from init.yaml.",
)
@click.option(
    "--username",
    type=str,
    required=False,
    help="Override Prisma username from init.yaml.",
)
@click.option(
    "--password",
    type=str,
    required=False,
    hide_input=True,
    help="Override Prisma password from init.yaml.",
)
@click.option(
    "--use-csv",
    is_flag=True,
    default=False,
    help="Use CSV download endpoint for bulk data retrieval (faster for large datasets).",
)
@orchestration_options()
def sync_hosts(
    regscale_ssp_id: int,
    filters: Optional[str],
    enable_software_inventory: bool,
    console_url: Optional[str],
    username: Optional[str],
    password: Optional[str],
    use_csv: bool,
    dry_run: bool = False,
    offset: Optional[int] = None,
    limit: Optional[int] = None,
):
    """
    Sync host assets and vulnerabilities from Prisma Cloud.

    This command:
    1. Authenticates to Prisma Cloud (uses cached token if available)
    2. Fetches host scan results from Prisma API
    3. Creates/updates assets in RegScale
    4. Creates/updates vulnerabilities and findings in RegScale
    5. Optionally creates software inventory from SBOM data

    Examples:
        # Basic sync with defaults from init.yaml
        regscale prisma sync_hosts --regscale_ssp_id 123

        # Sync with filters
        regscale prisma sync_hosts --regscale_ssp_id 123 \\
            --filters '{"collections": ["production"]}'

        # Sync with software inventory
        regscale prisma sync_hosts --regscale_ssp_id 123 --enable-software-inventory

        # Dry run to preview sync
        regscale prisma sync_hosts --regscale_ssp_id 123 --dry-run

        # Paginated sync
        regscale prisma sync_hosts --regscale_ssp_id 123 --offset 100 --limit 50
    """
    try:
        logger.info("Prisma Cloud Host Sync")

        _sync_resources(
            regscale_ssp_id=regscale_ssp_id,
            scan_type="hosts",
            filters=filters,
            console_url=console_url,
            username=username,
            password=password,
            use_csv=use_csv,
            dry_run=dry_run,
            offset=offset,
            limit=limit,
        )

        # Software inventory
        if enable_software_inventory and not dry_run:
            logger.info("Software Inventory Creation (SBOM)")
            logger.info("Note: SBOM processing for hosts requires separate sync_sbom command per host.")
            logger.info("Use: regscale prisma sync_sbom --resource-type host --resource-id <hostname>")

    except Exception as e:
        logger.error("Host sync failed: %s", e)
        raise click.Abort()


@click.command(name="sync_images")
@regscale_ssp_id()
@click.option(
    "--filters",
    type=str,
    required=False,
    help='JSON filter string for Prisma API query (e.g., \'{"collections": ["prod"]}\')',
)
@click.option(
    "--enable-software-inventory",
    is_flag=True,
    default=False,
    help="Create software inventory records from SBOM data for each image.",
)
@click.option(
    "--console-url",
    type=str,
    required=False,
    help="Override Prisma Console URL from init.yaml.",
)
@click.option(
    "--username",
    type=str,
    required=False,
    help="Override Prisma username from init.yaml.",
)
@click.option(
    "--password",
    type=str,
    required=False,
    hide_input=True,
    help="Override Prisma password from init.yaml.",
)
@click.option(
    "--use-csv",
    is_flag=True,
    default=False,
    help="Use CSV download endpoint for bulk data retrieval (faster for large datasets).",
)
@orchestration_options()
def sync_images(
    regscale_ssp_id: int,
    filters: Optional[str],
    enable_software_inventory: bool,
    console_url: Optional[str],
    username: Optional[str],
    password: Optional[str],
    use_csv: bool,
    dry_run: bool = False,
    offset: Optional[int] = None,
    limit: Optional[int] = None,
):
    """
    Sync container image assets and vulnerabilities from Prisma Cloud.

    This command:
    1. Authenticates to Prisma Cloud (uses cached token if available)
    2. Fetches container image scan results from Prisma API
    3. Creates/updates container image assets in RegScale
    4. Creates/updates vulnerabilities and findings in RegScale
    5. Optionally creates software inventory from SBOM data

    Examples:
        # Basic sync with defaults from init.yaml
        regscale prisma sync_images --regscale_ssp_id 123

        # Sync with filters
        regscale prisma sync_images --regscale_ssp_id 123 \\
            --filters '{"collections": ["production"]}'

        # Sync with software inventory
        regscale prisma sync_images --regscale_ssp_id 123 --enable-software-inventory

        # Dry run to preview sync
        regscale prisma sync_images --regscale_ssp_id 123 --dry-run

        # Paginated sync
        regscale prisma sync_images --regscale_ssp_id 123 --offset 50 --limit 25
    """
    try:
        logger.info("Prisma Cloud Container Image Sync")

        _sync_resources(
            regscale_ssp_id=regscale_ssp_id,
            scan_type="images",
            filters=filters,
            console_url=console_url,
            username=username,
            password=password,
            use_csv=use_csv,
            dry_run=dry_run,
            offset=offset,
            limit=limit,
        )

        # Software inventory
        if enable_software_inventory and not dry_run:
            logger.info("Software Inventory Creation (SBOM)")
            logger.info("Note: SBOM processing for images requires separate sync_sbom command per image.")
            logger.info("Use: regscale prisma sync_sbom --resource-type image --resource-id <image_id>")

    except Exception as e:
        logger.error("Image sync failed: %s", e)
        raise click.Abort()


# =============================================================================
# SBOM Sync Command
# =============================================================================


@click.command(name="sync_sbom")
@regscale_ssp_id()
@click.option(
    "--resource-type",
    type=click.Choice(["host", "image", "all"], case_sensitive=False),
    default="all",
    help="Resource type to sync SBOMs for: host, image, or all (default: all).",
)
@click.option(
    "--resource-id",
    type=str,
    required=False,
    help="Specific resource identifier (optional for bulk download). Required when --no-bulk-download is used.",
)
@click.option(
    "--bulk-download",
    is_flag=True,
    default=True,
    help="Use bulk download endpoints for all SBOMs (recommended, default: True). "
    "Based on P1 customer feedback, this resolves HTTP 404 errors.",
)
@click.option(
    "--asset-id",
    type=int,
    required=False,
    help="RegScale Asset ID to associate software inventory with. If not provided, will search for asset by identifier.",
)
@click.option(
    "--enable-software-inventory",
    is_flag=True,
    default=False,
    help="Create software inventory records from SBOM data.",
)
@click.option(
    "--attach-evidence",
    is_flag=True,
    default=False,
    help="Attach SBOM JSON as evidence to the asset (requires --enable-software-inventory).",
)
@click.option(
    "--create-missing-assets",
    is_flag=True,
    default=False,
    help="Create RegScale assets for SBOMs that have no matching asset in the Security Plan. "
    "Also creates software inventory on new assets (no separate --enable-software-inventory needed).",
)
@click.option(
    "--console-url",
    type=str,
    required=False,
    help="Override Prisma Console URL from init.yaml.",
)
@click.option(
    "--username",
    type=str,
    required=False,
    help="Override Prisma username from init.yaml.",
)
@click.option(
    "--password",
    type=str,
    required=False,
    hide_input=True,
    help="Override Prisma password from init.yaml.",
)
@orchestration_options()
def sync_sbom(
    regscale_ssp_id: int,
    resource_type: str,
    resource_id: Optional[str],
    bulk_download: bool,
    asset_id: Optional[int],
    enable_software_inventory: bool,
    attach_evidence: bool,
    create_missing_assets: bool,
    console_url: Optional[str],
    username: Optional[str],
    password: Optional[str],
    dry_run: bool = False,
    offset: Optional[int] = None,
    limit: Optional[int] = None,
):
    """
    Sync SBOM (Software Bill of Materials) data from Prisma Cloud.

    Two modes:
    1. Bulk download (default): Downloads all SBOMs at once using bulk endpoints
    2. Individual: Downloads SBOM for specific resource (requires --resource-id and --no-bulk-download)

    Based on Platform One (P1) customer feedback, bulk download mode is recommended
    as it resolves HTTP 404 errors encountered with individual SBOM endpoints.

    Examples:
        # Bulk download all host SBOMs (recommended)
        regscale prisma sync_sbom --regscale_ssp_id 123 --resource-type host

        # Bulk download all image SBOMs with software inventory creation
        regscale prisma sync_sbom --regscale_ssp_id 123 --resource-type image \\
            --enable-software-inventory

        # Download all SBOMs (hosts + images)
        regscale prisma sync_sbom --regscale_ssp_id 123 --resource-type all

        # Individual SBOM download (legacy mode, may return 404)
        regscale prisma sync_sbom --regscale_ssp_id 123 --resource-type host \\
            --resource-id "web-server-01.example.com" --no-bulk-download --asset-id 456
    """
    try:
        logger.info("Prisma Cloud SBOM Sync (%s)", resource_type.upper())

        # Initialize scanner
        scanner = PrismaCloudScanner(plan_id=regscale_ssp_id, scan_type="sbom")

        # Authenticate
        logger.info("Authenticating to Prisma Cloud...")
        scanner.authenticate(console_url=console_url, username=username, password=password)

        if bulk_download:
            # === BULK DOWNLOAD MODE (Recommended) ===
            _sync_sbom_bulk_mode(
                scanner=scanner,
                resource_type=resource_type,
                plan_id=regscale_ssp_id,
                enable_software_inventory=enable_software_inventory,
                dry_run=dry_run,
                create_missing_assets=create_missing_assets,
            )
        else:
            # === INDIVIDUAL MODE (Legacy) ===
            if not resource_id:
                logger.error("--resource-id is required when --no-bulk-download is used.")
                raise click.Abort()

            _sync_sbom_individual_mode(
                scanner=scanner,
                resource_type=resource_type,
                resource_id=resource_id,
                asset_id=asset_id,
                enable_software_inventory=enable_software_inventory,
                attach_evidence=attach_evidence,
                dry_run=dry_run,
            )

        logger.info("SBOM sync completed successfully!")

    except Exception as e:
        logger.error("SBOM sync failed: %s", e)
        raise click.Abort()


def _sync_sbom_bulk_mode(
    scanner: PrismaCloudScanner,
    resource_type: str,
    plan_id: int,
    enable_software_inventory: bool,
    dry_run: bool = False,
    create_missing_assets: bool = False,
):
    """
    Handle bulk SBOM download mode.

    :param PrismaCloudScanner scanner: Initialized scanner with authenticated client
    :param str resource_type: "host", "image", or "all"
    :param int plan_id: RegScale Security Plan ID for asset lookup
    :param bool enable_software_inventory: Create software inventory records
    :param bool dry_run: If True, skip writing to RegScale
    :param bool create_missing_assets: Create assets for SBOMs with no matching asset
    """
    if dry_run:
        logger.info("[DRY RUN] Bulk SBOM sync - no data will be written to RegScale.")
    total_sboms = 0
    total_packages = 0

    # Download host SBOMs
    if resource_type in ["host", "all"]:
        host_stats = _download_and_process_sboms(
            scanner=scanner,
            resource_category="hosts",
            plan_id=plan_id,
            enable_software_inventory=enable_software_inventory,
            create_missing_assets=create_missing_assets,
        )
        total_sboms += host_stats["sbom_count"]
        total_packages += host_stats["package_count"]

    # Download image SBOMs
    if resource_type in ["image", "all"]:
        image_stats = _download_and_process_sboms(
            scanner=scanner,
            resource_category="images",
            plan_id=plan_id,
            enable_software_inventory=enable_software_inventory,
            create_missing_assets=create_missing_assets,
        )
        total_sboms += image_stats["sbom_count"]
        total_packages += image_stats["package_count"]

    # Summary
    logger.info("Total SBOMs processed: %d", total_sboms)
    logger.info("Total software components: %d", total_packages)


def _create_asset_for_sbom(
    resource_id: str,
    resource_category: str,
    plan_id: int,
) -> Optional[Asset]:
    """
    Create a new RegScale asset for an unmatched SBOM resource.

    :param str resource_id: Prisma resource identifier
    :param str resource_category: "hosts" or "images"
    :param int plan_id: Security Plan ID
    :return: Created Asset or None
    """
    asset_type = AssetType.VM if resource_category == "hosts" else AssetType.Other
    asset_category_val = AssetCategory.Hardware if resource_category == "hosts" else AssetCategory.Software
    otn = _to_dns_safe_identifier(resource_id) if "/" in resource_id or ":" in resource_id else resource_id
    try:
        new_asset = Asset(
            name=resource_id[:255] if len(resource_id) > 255 else resource_id,
            assetType=asset_type,
            status=AssetStatus.Active,
            assetCategory=asset_category_val,
            parentId=plan_id,
            parentModule="securityplans",
            otherTrackingNumber=otn,
        )
        created = new_asset.create()
        if created and created.id:
            logger.info("Created asset %d for SBOM: %s", created.id, resource_id)
            return created
    except Exception as e:
        logger.error("Failed to create asset for SBOM %s: %s", resource_id, e)
    return None


def _resolve_asset_for_sbom(
    resource_id: str,
    resource_category: str,
    asset_map: dict,
    name_map: dict,
    plan_id: int,
    create_missing_assets: bool,
) -> Optional[Asset]:
    """
    Resolve a RegScale asset for an SBOM resource.

    Tries exact match first, then DNS-safe encoded match (for container images
    where sync_assets uses DNS-safe otherTrackingNumber but SBOM uses raw names).

    :param str resource_id: Prisma resource identifier from SBOM
    :param str resource_category: "hosts" or "images"
    :param dict asset_map: Map of otherTrackingNumber -> Asset
    :param dict name_map: Map of name -> Asset
    :param int plan_id: Security Plan ID for creating assets
    :param bool create_missing_assets: Whether to create asset if no match
    :return: Asset or None
    """
    asset = asset_map.get(resource_id) or name_map.get(resource_id)
    if asset:
        return asset

    # For images/hosts with / or : in identifier, try DNS-safe encoding
    # (sync_assets creates image assets with DNS-safe otherTrackingNumber)
    if "/" in resource_id or ":" in resource_id:
        dns_safe = _to_dns_safe_identifier(resource_id)
        asset = asset_map.get(dns_safe) or name_map.get(dns_safe)
        if asset:
            return asset

    if create_missing_assets:
        return _create_asset_for_sbom(resource_id, resource_category, plan_id)

    return None


def _update_asset_lookup(asset: Asset, asset_map: dict, name_map: dict) -> None:
    """Add an asset to the lookup maps for subsequent SBOM matching."""
    if asset.otherTrackingNumber:
        asset_map[asset.otherTrackingNumber] = asset
    if asset.name:
        name_map[asset.name] = asset


def _download_and_process_sboms(
    scanner: PrismaCloudScanner,
    resource_category: str,
    plan_id: int,
    enable_software_inventory: bool,
    create_missing_assets: bool = False,
) -> dict:
    """
    Download and process SBOMs for a resource category.

    Downloads bulk SBOM archives, matches them to RegScale assets by
    otherTrackingNumber or name, creates SBOM records, and optionally
    creates software inventory records.

    :param PrismaCloudScanner scanner: Initialized scanner
    :param str resource_category: "hosts" or "images"
    :param int plan_id: RegScale Security Plan ID for asset lookup
    :param bool enable_software_inventory: Whether to create software inventory
    :param bool create_missing_assets: Create assets for SBOMs with no match
    :return: Dictionary with sbom_count and package_count
    :rtype: dict
    """
    stats = {"sbom_count": 0, "package_count": 0, "inventory_count": 0}

    if scanner.client is None:
        logger.error("Scanner client not authenticated")
        return stats

    logger.info("Downloading bulk SBOM data for %s...", resource_category)
    try:
        download_fn = (
            scanner.client.get_sbom_download_hosts
            if resource_category == "hosts"
            else scanner.client.get_sbom_download_images
        )
        tar_gz_data = download_fn()

        logger.info("Downloaded: %d bytes", len(tar_gz_data))

        logger.info("Extracting SBOM archive...")
        sbom_map = extract_sbom_archive(tar_gz_data)
        logger.info("Extracted %d %s SBOMs", len(sbom_map), resource_category)

        if not sbom_map:
            return stats

        # Build asset lookup maps using REST endpoint (GraphQL get_map exceeds field cost)
        logger.info("Loading assets for plan %d (this may take time for large plans)...", plan_id)
        t0 = time.monotonic()
        all_assets = Asset.get_all_by_parent(parent_id=plan_id, parent_module="securityplans")
        asset_map = {a.otherTrackingNumber: a for a in all_assets if a.otherTrackingNumber}
        name_map = {a.name: a for a in all_assets if a.name}
        logger.info("Loaded %d assets for plan %d in %.2fs", len(all_assets), plan_id, time.monotonic() - t0)

        for resource_id, sbom_data in sbom_map.items():
            summary = get_sbom_summary(sbom_data)
            logger.info(
                "%s: %s - Components: %d",
                resource_category[:-1].capitalize(),
                resource_id,
                summary["total_components"],
            )

            asset = _resolve_asset_for_sbom(
                resource_id=resource_id,
                resource_category=resource_category,
                asset_map=asset_map,
                name_map=name_map,
                plan_id=plan_id,
                create_missing_assets=create_missing_assets,
            )
            if not asset:
                logger.warning(
                    "No matching asset found for SBOM: %s. Run sync_assets first or use --create-missing-assets.",
                    resource_id,
                )
                stats["sbom_count"] += 1
                stats["package_count"] += summary["total_components"]
                continue

            _update_asset_lookup(asset, asset_map, name_map)

            sbom_id = create_sbom_record(asset_id=asset.id, sbom_data=sbom_data, resource_name=resource_id)
            if sbom_id:
                stats["sbom_count"] += 1

            if enable_software_inventory or create_missing_assets:
                inv_count = create_software_inventory_from_sbom(asset_id=asset.id, sbom_data=sbom_data)
                stats["inventory_count"] += inv_count

            stats["package_count"] += summary["total_components"]

    except Exception as e:
        logger.error("Failed to download %s SBOMs: %s", resource_category, e)

    return stats


def _sync_sbom_individual_mode(
    scanner: PrismaCloudScanner,
    resource_type: str,
    resource_id: str,
    asset_id: Optional[int],
    enable_software_inventory: bool,
    attach_evidence: bool,
    dry_run: bool = False,
):
    """
    Handle individual SBOM download mode (legacy).

    :param PrismaCloudScanner scanner: Initialized scanner with authenticated client
    :param str resource_type: "host" or "image"
    :param str resource_id: Resource identifier
    :param Optional[int] asset_id: RegScale Asset ID
    :param bool enable_software_inventory: Create software inventory records
    :param bool attach_evidence: Attach SBOM as evidence
    :param bool dry_run: If True, skip writing to RegScale
    """
    api = Api()
    logger.info("Resource: %s", resource_id)

    # Ensure client is authenticated
    if scanner.client is None:
        logger.error("Scanner client not authenticated")
        return

    # Fetch SBOM
    logger.info("Fetching SBOM for %s: %s...", resource_type, resource_id)
    logger.warning("Individual SBOM endpoint may return HTTP 404. Use bulk download mode (default).")

    sbom_data = scanner.client.get_sbom(resource_type, resource_id)

    # Display SBOM summary
    summary = get_sbom_summary(sbom_data)
    logger.info("SBOM Summary:")
    logger.info("  Format: %s %s", summary["bom_format"], summary["spec_version"])
    logger.info("  Total Components: %d", summary["total_components"])
    logger.info("  Target: %s %s", summary["target_name"], summary["target_version"])

    # Create SBOM record if asset_id provided
    if asset_id:
        create_sbom_record(asset_id=asset_id, sbom_data=sbom_data, resource_name=resource_id)

    # Create software inventory if enabled
    if enable_software_inventory:
        if dry_run:
            logger.info("[DRY RUN] Would create software inventory for asset %s", asset_id)
        elif not asset_id:
            logger.warning("Asset ID not provided. Please provide --asset-id for software inventory creation.")
        else:
            logger.info("Creating software inventory for asset %d...", asset_id)
            count = create_software_inventory_from_sbom(
                asset_id=asset_id,
                sbom_data=sbom_data,
                deduplicate=True,
            )
            logger.info("Created %d software inventory records", count)

            # Attach evidence if requested
            if attach_evidence:
                logger.info("Attaching SBOM as evidence...")
                success = attach_sbom_as_evidence(
                    api=api,
                    asset_id=asset_id,
                    sbom_data=sbom_data,
                    file_name=f"prisma_sbom_{resource_type}_{resource_id.replace('/', '_')}.json",
                )
                if success:
                    logger.info("SBOM attached as evidence")
                else:
                    logger.warning("Failed to attach SBOM as evidence")


# Export all commands for registration
__all__ = [
    "authenticate",
    "sync_hosts",
    "sync_images",
    "sync_sbom",
]
