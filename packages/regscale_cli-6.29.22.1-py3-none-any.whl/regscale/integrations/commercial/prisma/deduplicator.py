#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Prisma Cloud Finding Deduplication

This module provides client-side deduplication of Prisma Cloud vulnerabilities
to reduce redundant API calls to RegScale. Deduplication groups findings by
(CVE, Asset) and consolidates metadata.

Based on Platform One's CVE aggregation strategy which achieves ~17% reduction
in image vulnerability data.
"""

import logging
from collections import defaultdict
from datetime import datetime
from typing import Dict, List, Optional, Set

logger = logging.getLogger("regscale")


class PrismaDeduplicator:
    """Deduplicates Prisma Cloud findings by CVE and asset identifier."""

    # Severity hierarchy for taking the highest severity
    SEVERITY_ORDER = {
        "critical": 4,
        "high": 3,
        "medium": 2,
        "moderate": 2,
        "low": 1,
        "info": 0,
        "unknown": 0,
    }

    def __init__(self):
        """Initialize the deduplicator."""
        self.stats = {
            "original_count": 0,
            "deduplicated_count": 0,
            "reduction_percentage": 0.0,
        }

    def _consolidate_unique_values(self, values: List[str]) -> str:
        """
        Consolidate list of values into unique comma-separated string.

        :param List[str] values: List of string values
        :return: Comma-separated unique values
        :rtype: str
        """
        if not values:
            return ""

        # Remove empty strings and duplicates while preserving order
        unique_values = []
        seen: Set[str] = set()

        for value in values:
            if value and value.strip() and value.strip() not in seen:
                unique_values.append(value.strip())
                seen.add(value.strip())

        return ", ".join(unique_values)

    def _get_highest_severity(self, severities: List[str]) -> str:
        """
        Get the highest severity from a list of severities.

        :param List[str] severities: List of severity strings
        :return: Highest severity
        :rtype: str
        """
        if not severities:
            return "unknown"

        # Filter out empty values
        valid_severities = [s.lower() for s in severities if s and s.strip()]
        if not valid_severities:
            return "unknown"

        # Return highest severity based on order
        return max(valid_severities, key=lambda x: self.SEVERITY_ORDER.get(x, 0))

    def _get_highest_cvss(self, cvss_scores: List[Optional[float]]) -> Optional[float]:
        """
        Get the highest CVSS score from a list of scores.

        :param List[Optional[float]] cvss_scores: List of CVSS scores
        :return: Highest CVSS score or None
        :rtype: Optional[float]
        """
        if not cvss_scores:
            return None

        # Filter out None values
        valid_scores = [score for score in cvss_scores if score is not None]

        if not valid_scores:
            return None

        return max(valid_scores)

    def _get_earliest_date(self, dates: List[Optional[str]]) -> Optional[str]:
        """
        Get the earliest date from a list of dates.

        Used for fix_date to show when the first fix was available.

        :param List[Optional[str]] dates: List of date strings
        :return: Earliest date string or None
        :rtype: Optional[str]
        """
        if not dates:
            return None

        # Filter out empty values
        valid_dates = [d for d in dates if d and d.strip()]
        if not valid_dates:
            return None

        # Try to parse dates and return the earliest
        parsed_dates = []
        for date_str in valid_dates:
            try:
                # Try different date formats
                for fmt in [
                    "%Y-%m-%d %H:%M:%S.%f",
                    "%Y-%m-%d %H:%M:%S",
                    "%Y-%m-%dT%H:%M:%SZ",
                    "%Y-%m-%d",
                ]:
                    try:
                        parsed_dates.append((datetime.strptime(date_str.strip(), fmt), date_str.strip()))
                        break
                    except ValueError:
                        continue
            except Exception:
                continue

        if not parsed_dates:
            return None

        # Return the earliest date string
        return min(parsed_dates, key=lambda x: x[0])[1]

    def _get_most_recent_date(self, dates: List[Optional[str]]) -> Optional[str]:
        """
        Get the most recent date from a list of dates.

        Used for discovered_date and published_date to show latest occurrence.

        :param List[Optional[str]] dates: List of date strings
        :return: Most recent date string or None
        :rtype: Optional[str]
        """
        if not dates:
            return None

        # Filter out empty values
        valid_dates = [d for d in dates if d and d.strip()]
        if not valid_dates:
            return None

        # Try to parse dates and return the most recent
        parsed_dates = []
        for date_str in valid_dates:
            try:
                # Try different date formats
                for fmt in [
                    "%Y-%m-%d %H:%M:%S.%f",
                    "%Y-%m-%d %H:%M:%S",
                    "%Y-%m-%dT%H:%M:%SZ",
                    "%Y-%m-%d",
                ]:
                    try:
                        parsed_dates.append((datetime.strptime(date_str.strip(), fmt), date_str.strip()))
                        break
                    except ValueError:
                        continue
            except Exception:
                continue

        if not parsed_dates:
            return None

        # Return the most recent date string
        return max(parsed_dates, key=lambda x: x[0])[1]

    def _consolidate_fields_from_group(self, base_finding: Dict, group: List[Dict]) -> Dict:
        """
        Consolidate fields from a group of findings into a base finding.

        This is a shared helper method to reduce code duplication between
        deduplicate_findings() and _consolidate_finding_group().

        :param Dict base_finding: Base finding to update with consolidated data
        :param List[Dict] group: List of findings to consolidate
        :return: Updated base finding with consolidated fields
        :rtype: Dict
        """
        # Collect fields from all findings
        severities = [f.get("severity", "") for f in group]
        cvss_scores = [f.get("cvss_score", f.get("cvss_v3_score")) for f in group]
        packages = [f.get("package_name", "") for f in group]
        versions = [f.get("package_version", "") for f in group]
        fix_versions = [f.get("fixed_version", "") for f in group]
        fix_dates = [f.get("fix_date", "") for f in group]
        discovered_dates = [f.get("discovered_date", "") for f in group]
        published_dates = [f.get("published_date", "") for f in group]
        risk_factors = [f.get("risk_factors", "") for f in group]
        tags = [f.get("tags", "") for f in group]

        # Parse and consolidate comma-separated hosts (for images)
        all_hosts = []
        for f in group:
            hosts_str = f.get("affected_hosts", "")
            if hosts_str:
                hosts = [h.strip() for h in hosts_str.split(",") if h.strip()]
                all_hosts.extend(hosts)

        # Apply aggregation rules
        base_finding["severity"] = self._get_highest_severity(severities)
        base_finding["cvss_score"] = self._get_highest_cvss(cvss_scores)
        base_finding["cvss_v3_score"] = base_finding["cvss_score"]  # Alias for compatibility

        # Consolidate unique values
        if all_hosts:
            base_finding["affected_hosts"] = self._consolidate_unique_values(all_hosts)

        base_finding["package_name"] = self._consolidate_unique_values(packages)
        base_finding["package_version"] = self._consolidate_unique_values(versions)
        base_finding["fixed_version"] = self._consolidate_unique_values(fix_versions)
        base_finding["risk_factors"] = self._consolidate_unique_values(risk_factors)
        base_finding["tags"] = self._consolidate_unique_values(tags)

        # Date handling
        base_finding["fix_date"] = self._get_earliest_date(fix_dates)
        base_finding["discovered_date"] = self._get_most_recent_date(discovered_dates)
        base_finding["published_date"] = self._get_most_recent_date(published_dates)

        return base_finding

    def deduplicate_findings(self, findings: List[Dict]) -> List[Dict]:
        """
        Deduplicate findings by grouping on (CVE, asset_identifier).

        Consolidation rules:
        - Take highest severity
        - Take highest CVSS score
        - Merge unique packages/versions
        - Take earliest fix date (first fix available)
        - Take most recent discovered/published dates
        - Consolidate comma-separated hosts

        :param List[Dict] findings: List of finding dictionaries
        :return: Deduplicated list of findings
        :rtype: List[Dict]

        Example:
            >>> deduplicator = PrismaDeduplicator()
            >>> findings = [
            ...     {"cve": "CVE-2024-1234", "asset_id": "host1", "severity": "high"},
            ...     {"cve": "CVE-2024-1234", "asset_id": "host1", "severity": "critical"},
            ... ]
            >>> deduplicated = deduplicator.deduplicate_findings(findings)
            >>> len(deduplicated)
            1
            >>> deduplicated[0]["severity"]
            'critical'
        """
        if not findings:
            logger.info("No findings to deduplicate")
            return []

        self.stats["original_count"] = len(findings)
        logger.info(f"Starting deduplication of {len(findings)} findings")

        # Group findings by (CVE, asset_identifier)
        grouped: Dict[tuple, List[Dict]] = defaultdict(list)

        for finding in findings:
            cve = finding.get("cve", "UNKNOWN")
            asset_id = finding.get("asset_identifier", finding.get("asset_id", "UNKNOWN"))

            # Create grouping key
            key = (cve, asset_id)
            grouped[key].append(finding)

        # Aggregate grouped findings
        deduplicated = []

        for (cve, asset_id), group in grouped.items():
            # Start with the first finding as base
            base_finding = group[0].copy()

            # Consolidate fields from all findings in the group
            base_finding = self._consolidate_fields_from_group(base_finding, group)

            # Add metadata about deduplication
            if len(group) > 1:
                base_finding["deduplicated_count"] = len(group)
                logger.debug(f"Deduplicated {len(group)} findings for {cve} on {asset_id}")

            deduplicated.append(base_finding)

        self.stats["deduplicated_count"] = len(deduplicated)
        self.stats["reduction_percentage"] = round((1 - len(deduplicated) / len(findings)) * 100, 2)

        logger.info(
            "Deduplication complete: %d -> %d findings (%s%% reduction)",
            len(findings),
            len(deduplicated),
            self.stats["reduction_percentage"],
        )

        return deduplicated

    def _collect_affected_assets(self, group: List[Dict]) -> List[str]:
        """
        Collect unique affected assets from a group of findings.

        :param List[Dict] group: List of findings for same CVE
        :return: List of unique asset identifiers
        :rtype: List[str]
        """
        assets = []
        for f in group:
            asset = f.get("asset_identifier", f.get("asset_id", ""))
            if asset and asset not in assets:
                assets.append(asset)
        return assets

    def _consolidate_finding_group(self, cve: str, group: List[Dict]) -> Dict:
        """
        Consolidate a group of findings for the same CVE across multiple assets.

        :param str cve: CVE identifier
        :param List[Dict] group: List of findings for this CVE
        :return: Consolidated finding dictionary
        :rtype: Dict
        """
        base_finding = group[0].copy()
        assets = self._collect_affected_assets(group)

        # Consolidate fields from all findings in the group
        base_finding = self._consolidate_fields_from_group(base_finding, group)

        # Add cross-asset specific fields
        base_finding["affected_assets"] = ", ".join(assets)
        base_finding["affected_asset_count"] = len(assets)
        base_finding["deduplicated_count"] = len(group)
        base_finding["original_finding_count"] = len(group)

        if len(group) > 1:
            logger.debug(
                "Deduplicated %d findings for %s across %d assets (severity: %s, CVSS: %s)",
                len(group),
                cve,
                len(assets),
                base_finding["severity"],
                base_finding["cvss_score"],
            )

        return base_finding

    def deduplicate_by_cve(self, findings: List[Dict]) -> List[Dict]:
        """
        Deduplicate findings by grouping on CVE only (across all assets).

        This creates a single finding per CVE that tracks all affected assets.
        Useful for reducing RegScale API calls when the same CVE affects many hosts.

        Consolidation rules:
        - Group by CVE only (ignore asset_identifier)
        - Take highest severity across all assets
        - Take highest CVSS score across all assets
        - Collect all unique affected assets into comma-separated list
        - Merge unique packages/versions
        - Take earliest fix date (first fix available)
        - Take most recent discovered/published dates

        :param List[Dict] findings: List of finding dictionaries
        :return: Deduplicated list of findings (one per CVE)
        :rtype: List[Dict]

        Example:
            >>> deduplicator = PrismaDeduplicator()
            >>> findings = [
            ...     {"cve": "CVE-2024-1234", "asset_identifier": "host1", "severity": "high"},
            ...     {"cve": "CVE-2024-1234", "asset_identifier": "host2", "severity": "medium"},
            ...     {"cve": "CVE-2024-1234", "asset_identifier": "host3", "severity": "critical"},
            ... ]
            >>> deduplicated = deduplicator.deduplicate_by_cve(findings)
            >>> len(deduplicated)
            1
            >>> deduplicated[0]["severity"]
            'critical'
            >>> deduplicated[0]["affected_assets"]
            'host1, host2, host3'
        """
        if not findings:
            logger.info("No findings to deduplicate by CVE")
            return []

        self.stats["original_count"] = len(findings)
        logger.info("Starting CVE-based deduplication of %d findings across assets", len(findings))

        # Group findings by CVE only
        grouped: Dict[str, List[Dict]] = defaultdict(list)
        for finding in findings:
            cve = finding.get("cve", "UNKNOWN")
            grouped[cve].append(finding)

        # Consolidate each group
        deduplicated = [self._consolidate_finding_group(cve, group) for cve, group in grouped.items()]

        self.stats["deduplicated_count"] = len(deduplicated)
        self.stats["reduction_percentage"] = round((1 - len(deduplicated) / len(findings)) * 100, 2)

        logger.info(
            "CVE-based deduplication complete: %d -> %d findings (%s%% reduction)",
            len(findings),
            len(deduplicated),
            self.stats["reduction_percentage"],
        )

        return deduplicated

    def get_stats(self) -> Dict:
        """
        Get deduplication statistics.

        :return: Statistics dictionary with original_count, deduplicated_count, reduction_percentage
        :rtype: Dict
        """
        return self.stats.copy()


def deduplicate_findings(findings: List[Dict]) -> List[Dict]:
    """
    Convenience function for deduplicating findings.

    :param List[Dict] findings: List of finding dictionaries
    :return: Deduplicated list of findings
    :rtype: List[Dict]

    Example:
        >>> from regscale.integrations.commercial.prisma.deduplicator import deduplicate_findings
        >>> findings = [...]
        >>> deduplicated = deduplicate_findings(findings)
    """
    deduplicator = PrismaDeduplicator()
    return deduplicator.deduplicate_findings(findings)
