#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Prisma Cloud API Integration

This package provides API-based integration with Prisma Cloud Compute for:
- Host vulnerability scanning
- Container image vulnerability scanning
- SBOM (Software Bill of Materials) processing
- Asset and finding synchronization with RegScale

The integration uses the Scanner Integration framework for standardized
asset and finding processing.
"""

from regscale.integrations.commercial.prisma.scanner import PrismaCloudScanner

__all__ = ["PrismaCloudScanner"]
