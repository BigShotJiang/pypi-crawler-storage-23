#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Prisma Cloud Legacy CSV Import

.. deprecated::
    This module provides backward compatibility for CSV-based Prisma imports.
    For new implementations, use the API-based integration:
    - `regscale prisma sync_hosts` for host vulnerability scans
    - `regscale prisma sync_images` for container image scans
    - `regscale prisma sync_sbom` for SBOM processing

This legacy importer processes Prisma Cloud CSV exports and creates:
- Hardware assets (hosts/VMs) or container image assets
- Vulnerability findings with CVE, CVSS scores, and remediation guidance
- Software inventory (optional)
"""

import logging
import warnings
from datetime import datetime
from os import PathLike
from typing import Optional

import click

from regscale.models.integration_models.flat_file_importer import FlatFileImporter
from regscale.models.integration_models.prisma import Prisma

logger = logging.getLogger("regscale")


@click.command(name="import_prisma")
@FlatFileImporter.common_scanner_options(
    message="File path to the folder containing Prisma .csv files to process to RegScale.",
    prompt="File path for Prisma files",
    import_name="prisma",
)
@click.option(
    "--enable-software-inventory",
    is_flag=True,
    default=False,
    help="Enable software inventory processing (creates SoftwareInventory records from package data)",
)
def import_prisma(
    folder_path: PathLike[str],
    regscale_ssp_id: int,
    scan_date: datetime,
    mappings_path: PathLike[str],
    disable_mapping: bool,
    s3_bucket: str,
    s3_prefix: str,
    aws_profile: str,
    upload_file: bool,
    enable_software_inventory: bool,
):
    """
    [DEPRECATED] Import scans, vulnerabilities and assets to RegScale from Prisma CSV export files.

    .. deprecated::
        This CSV import method is deprecated. Use the API-based integration instead:

        - For host scans: `regscale prisma sync_hosts --plan-id <id>`
        - For container images: `regscale prisma sync_images --plan-id <id>`
        - For SBOM data: `regscale prisma sync_sbom --plan-id <id> --resource-type host --resource-id <id>`

    This command processes Prisma Cloud vulnerability scan CSV exports and creates:
    - Hardware assets (hosts/VMs) or container image assets
    - Vulnerability findings with CVE, CVSS scores, and remediation guidance
    - Software inventory (optional, use --enable-software-inventory flag)

    The CSV files must contain at minimum:
    - Hostname, Distro, CVSS, CVE ID, Description, Fix Status

    Example usage:
        regscale prisma import_prisma \\
            --folder-path /path/to/prisma/csvs \\
            --plan-id 123 \\
            --enable-software-inventory

    For API-based integration, first authenticate:
        regscale prisma authenticate \\
            --console-url https://console.example.com:8083 \\
            --username admin \\
            --password <password>

    Then sync data:
        regscale prisma sync_hosts --plan-id 123 --enable-software-inventory
    """
    # Display deprecation warning
    warnings.warn(
        "CSV import for Prisma is deprecated. Use API integration instead:\n"
        "  - regscale prisma sync_hosts --plan-id <id>\n"
        "  - regscale prisma sync_images --plan-id <id>\n"
        "  - regscale prisma sync_sbom --plan-id <id> --resource-type host --resource-id <id>\n"
        "See documentation for authentication and usage details.",
        DeprecationWarning,
        stacklevel=2,
    )

    logger.warning(
        "DEPRECATION WARNING: CSV import for Prisma is deprecated. "
        "Consider using the API-based integration (sync_hosts, sync_images, sync_sbom) for improved functionality."
    )

    import_prisma_data(
        folder_path=folder_path,
        regscale_ssp_id=regscale_ssp_id,
        scan_date=scan_date,
        mappings_path=mappings_path,
        disable_mapping=disable_mapping,
        s3_bucket=s3_bucket,
        s3_prefix=s3_prefix,
        aws_profile=aws_profile,
        upload_file=upload_file,
        enable_software_inventory=enable_software_inventory,
    )


def import_prisma_data(
    folder_path: PathLike[str],
    regscale_ssp_id: int,
    scan_date: datetime,
    s3_bucket: str,
    s3_prefix: str,
    aws_profile: str,
    mappings_path: Optional[PathLike[str]] = None,
    disable_mapping: bool = False,
    upload_file: Optional[bool] = True,
    enable_software_inventory: bool = False,
) -> None:
    """
    Import Prisma data to RegScale from CSV files.

    .. deprecated::
        This function is deprecated. Use the API-based scanner integration instead.

    :param PathLike[str] folder_path: Path to the folder containing Prisma .csv files
    :param int regscale_ssp_id: RegScale System Security Plan ID
    :param datetime scan_date: Date of the scan
    :param str s3_bucket: S3 bucket to download the files from
    :param str s3_prefix: S3 prefix to download the files from
    :param str aws_profile: AWS profile to use for S3 access
    :param Optional[Path] mappings_path: Path to the header mapping file, defaults to None
    :param bool disable_mapping: Whether to disable custom mapping, defaults to False
    :param Optional[bool] upload_file: Whether to upload the file to RegScale after processing, defaults to True
    :param bool enable_software_inventory: Whether to enable software inventory processing, defaults to False
    :rtype: None
    """
    # Use custom import method that handles software inventory post-sync
    Prisma.import_prisma_files_with_inventory(
        folder_path=folder_path,
        object_id=regscale_ssp_id,
        scan_date=scan_date,
        mappings_path=mappings_path,
        disable_mapping=disable_mapping,
        s3_bucket=s3_bucket,
        s3_prefix=s3_prefix,
        aws_profile=aws_profile,
        upload_file=upload_file,
        enable_software_inventory=enable_software_inventory,
    )
