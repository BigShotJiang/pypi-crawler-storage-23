"""
Mixin class providing Tenable SC file processing functionality.

This module extracts the asset/finding file processing logic from the main
TenableSCJsonlScanner class to keep the codebase maintainable and focused.
"""

import dataclasses
import inspect
import json
import logging

from regscale.core.app.utils.app_utils import get_current_datetime
from regscale.integrations.scanner_integration import IntegrationAsset, IntegrationFinding
from regscale.integrations.variables import ScannerVariables
from regscale.models import AssetStatus, regscale_models

logger = logging.getLogger("regscale")

# Import here to avoid circular imports at module level
FILE_TYPE = ".jsonl"


def _extract_ip_from_definition(definition: str) -> str:
    """
    Safely extract IP address from a Tenable SC asset definition string.

    :param str definition: The definition string (e.g., "ip=192.168.1.1&...")
    :return: Extracted IP address or empty string if not found
    :rtype: str
    """
    if "ip=" not in definition:
        return ""
    return definition.split("ip=")[1].split("&")[0].replace("%3B", ";")


class TenableFileProcessorMixin:
    """
    Mixin providing Tenable SC asset/finding file processing methods.

    This mixin is used by TenableSCJsonlScanner to handle processing
    of downloaded data files into IntegrationAsset and IntegrationFinding objects.
    """

    def _process_asset_file(self, file, data, output_f, existing_items):
        """
        Process a Tenable SC data file for assets with mapping and validation.

        :param file: The file being processed
        :param data: The data from the file
        :param output_f: The output file handle
        :param existing_items: Dictionary of existing items
        :return: Number of assets processed
        :rtype: int
        """
        assets_list = data.get("response", {}).get("usable", [])

        if assets_list and len(assets_list) > 0:
            return self._process_multiple_assets(file, assets_list, output_f, existing_items)
        return self._process_single_file_asset(file, data, output_f, existing_items)

    def _process_multiple_assets(self, file, assets_list, output_f, existing_items):
        """
        Process multiple assets from an assets file.

        :param file: The file being processed
        :param assets_list: List of asset data
        :param output_f: The output file handle
        :param existing_items: Dictionary of existing items
        :return: Number of assets processed
        :rtype: int
        """
        assets_added = 0
        logger.info("Processing %d assets from file %s", len(assets_list), file)

        for asset_data in assets_list:
            asset_id, asset_name, ip_info = self._extract_asset_info(asset_data)
            identifier = ip_info if ip_info else asset_id
            asset = self._create_basic_asset(identifier, asset_name or f"Asset {asset_id}", ip_info)
            mapped_asset = self._apply_asset_mapping(asset, asset_data, asset_id, asset_name, ip_info)

            try:
                if self._validate_and_write_asset(mapped_asset, existing_items, output_f):
                    assets_added += 1
            except Exception as e:
                logger.error("Error processing asset %s: %s", asset_id, str(e))

        logger.info("Added %d assets from file %s", assets_added, file)
        return assets_added

    def _process_single_file_asset(self, file, data, output_f, existing_items):
        """
        Process a single asset from a file.

        :param file: The file being processed
        :param data: The data from the file
        :param output_f: The output file handle
        :param existing_items: Dictionary of existing items
        :return: Number of assets processed (0 or 1)
        :rtype: int
        """
        try:
            asset = self.parse_asset(file, data)
            mapped_asset = self._apply_asset_mapping(asset, data)
            if self._validate_and_write_asset(mapped_asset, existing_items, output_f):
                return 1
            return 0
        except Exception as e:
            logger.error("Error processing asset from file %s: %s", file, str(e))
            return 0

    def _extract_asset_info(self, asset_data):
        """
        Extract asset information from the asset data.

        :param asset_data: The asset data
        :return: Tuple of (asset_id, asset_name, ip_info)
        :rtype: Tuple[str, str, str]
        """
        asset_id = asset_data.get("id", "")
        asset_name = asset_data.get("name", "")
        ip_info = _extract_ip_from_definition(asset_data.get("definition", ""))
        return asset_id, asset_name, ip_info

    def _create_basic_asset(self, identifier, name, ip_address):
        """
        Create a basic IntegrationAsset object.

        :param str identifier: Asset identifier
        :param str name: Asset name
        :param str ip_address: Asset IP address
        :return: IntegrationAsset object
        :rtype: IntegrationAsset
        """
        return IntegrationAsset(
            identifier=identifier,
            name=name,
            ip_address=ip_address,
            parent_id=self.plan_id,
            parent_module=regscale_models.SecurityPlan.get_module_slug(),
            asset_owner_id=ScannerVariables.userId,
            asset_category=regscale_models.AssetCategory.Hardware,
            asset_type=regscale_models.AssetType.Other,
            status=AssetStatus.Active,
            date_last_updated=get_current_datetime(),
        )

    def _apply_asset_mapping(self, asset, source_data, asset_id=None, asset_name=None, ip_info=None):
        """
        Apply field mapping to an asset.

        :param IntegrationAsset asset: The asset to apply mapping to
        :param dict source_data: Source data for mapping
        :param str asset_id: Optional asset ID
        :param str asset_name: Optional asset name
        :param str ip_info: Optional IP info
        :return: Mapped IntegrationAsset
        :rtype: IntegrationAsset
        """
        asset_dict = dataclasses.asdict(asset)

        if asset_id is not None:
            source_data = {"id": asset_id, "name": asset_name, "ip": ip_info}

        if not self.disable_mapping:
            mapping = getattr(self.mapping, "fields", {}).get("asset_mapping", {}) if self.mapping else {}
            mapped_asset_dict = self._apply_mapping(source_data or {}, asset_dict, mapping)

            valid_fields = {}
            for field, value in mapped_asset_dict.items():
                if hasattr(IntegrationAsset, field) or field in inspect.signature(IntegrationAsset.__init__).parameters:
                    valid_fields[field] = value

            return IntegrationAsset(**valid_fields)
        return asset

    def _validate_and_write_asset(self, asset, existing_items, output_f):
        """
        Validate an asset and write it to the output file if valid.

        :param IntegrationAsset asset: The asset to validate and write
        :param dict existing_items: Dictionary of existing items
        :param file output_f: The output file handle
        :return: True if asset was written
        :rtype: bool
        """
        self._validate_fields(asset, self.required_asset_fields)

        key = self._get_item_key(dataclasses.asdict(asset), "asset")
        if key in existing_items:
            logger.debug("Asset with identifier %s already exists, skipping", key)
            return False

        output_f.write(json.dumps(dataclasses.asdict(asset)) + "\n")
        output_f.flush()
        existing_items[key] = True
        return True

    def _process_finding_file(self, file, data, output_f, existing_items):
        """
        Process a single file for findings with memory-efficient streaming.

        :param file: The file being processed
        :param data: The data from the file
        :param output_f: The output file handle
        :param existing_items: Dictionary of existing items
        :return: Number of findings processed
        :rtype: int
        """
        file_path_str = str(file)

        if file_path_str.endswith(FILE_TYPE):
            logger.info("Processing JSONL findings file: %s", file_path_str)
            return self._process_jsonl_findings(file_path_str, output_f, existing_items)

        identifier = self._get_asset_identifier_from_file(file, data)
        findings_data = data.get("response", {}).get("results", []) if data and "response" in data else []
        return self._process_findings_list(file, findings_data, identifier, output_f, existing_items)

    def _get_asset_identifier_from_file(self, file, data):
        """
        Extract asset identifier from file data.

        :param file: The file being processed
        :param data: The data from the file
        :return: Asset identifier
        :rtype: str
        """
        try:
            asset = self.parse_asset(file, data)
            return asset.identifier
        except Exception as e:
            logger.error("Error parsing asset from file %s: %s", file, str(e))
            identifier = "unknown"
            if data and isinstance(data, dict):
                if "response" in data and "results" in data.get("response", {}):
                    results = data.get("response", {}).get("results", [])
                    if results and len(results) > 0:
                        identifier = results[0].get("ip", "unknown")
        return identifier

    def _process_findings_list(self, file, findings_data, default_identifier, output_f, existing_items):
        """
        Process a list of findings and write them to the output file.

        :param file: The source file
        :param list findings_data: List of finding data
        :param str default_identifier: Default asset identifier
        :param file output_f: Output file handle
        :param dict existing_items: Dictionary of existing items
        :return: Number of findings processed
        :rtype: int
        """
        findings_in_file = 0

        for finding_item in findings_data:
            finding_asset_id = finding_item.get("ip", default_identifier)
            if self._process_individual_finding(file, finding_item, finding_asset_id, output_f, existing_items):
                findings_in_file += 1

        if findings_in_file > 0:
            logger.info("Added %d new findings from file %s", findings_in_file, file)
        return findings_in_file

    def _process_jsonl_findings(self, jsonl_file_path, output_f, existing_items):
        """
        Process findings from a JSONL file in a memory-efficient way.

        :param str jsonl_file_path: Path to the JSONL file
        :param file output_f: Output file handle
        :param dict existing_items: Dictionary of existing items
        :return: Number of findings processed
        :rtype: int
        """
        findings_in_file = 0
        processed_count = 0

        try:
            with open(jsonl_file_path, "r") as f:
                for line_num, line in enumerate(f, 1):
                    processed_count += 1

                    if processed_count % 1000 == 0:
                        logger.info("Processing finding %d from JSONL file...", processed_count)

                    try:
                        finding_item = json.loads(line)
                        finding_asset_id = finding_item.get("ip", "unknown")
                        if self._process_individual_finding(
                            jsonl_file_path,
                            finding_item,
                            finding_asset_id,
                            output_f,
                            existing_items,
                            line_num,
                        ):
                            findings_in_file += 1
                    except json.JSONDecodeError as e:
                        logger.warning("Invalid JSON at line %d in %s: %s", line_num, jsonl_file_path, e)
                    except Exception as e:
                        logger.warning("Error processing finding at line %d in %s: %s", line_num, jsonl_file_path, e)

            logger.info(
                "Processed %d total findings from JSONL, added %d new findings", processed_count, findings_in_file
            )

        except Exception as e:
            logger.error("Error processing JSONL file %s: %s", jsonl_file_path, e, exc_info=True)

        return findings_in_file

    def _process_individual_finding(self, file, finding_item, asset_id, output_f, existing_items, line_num=None):
        """
        Process an individual finding and write it to the output file if valid.

        :param file: Source file or file path
        :param dict finding_item: The finding data
        :param str asset_id: Asset identifier
        :param file output_f: Output file handle
        :param dict existing_items: Dictionary of existing items
        :param int line_num: Optional line number for JSONL processing
        :return: True if finding was written
        :rtype: bool
        """
        data = None
        finding = self.parse_finding(asset_id, data, finding_item)

        if not finding:
            logger_fn = logger.debug if line_num else logger.warning
            msg = "Failed to parse finding from %s"
            if line_num:
                msg += " at line %d"
                logger_fn(msg, file, line_num)
            else:
                logger_fn(msg, file)
            return False

        mapped_finding = self._apply_finding_mapping(finding, finding_item)

        try:
            self._validate_fields(mapped_finding, self.required_finding_fields)

            key = self._get_item_key(dataclasses.asdict(mapped_finding), "finding")
            if key in existing_items:
                logger.debug("Finding with key %s already exists, skipping", key)
                return False

            output_f.write(json.dumps(dataclasses.asdict(mapped_finding)) + "\n")
            output_f.flush()
            existing_items[key] = True
            return True
        except Exception as e:
            logger_fn = logger.debug if line_num else logger.error
            logger_fn("Error processing finding: %s", e)
            return False

    def _apply_finding_mapping(self, finding, finding_item):
        """
        Apply mapping to a finding with field name normalization.

        :param IntegrationFinding finding: The finding to map
        :param dict finding_item: The source finding data
        :return: Mapped IntegrationFinding
        :rtype: IntegrationFinding
        """
        finding_dict = dataclasses.asdict(finding)

        if self.disable_mapping:
            return finding

        mapped_finding_dict = self._apply_mapping(
            finding_item,
            finding_dict,
            getattr(self.mapping, "fields", {}).get("finding_mapping", {}) if self.mapping else {},
        )

        normalized_dict = {}
        for key, value in mapped_finding_dict.items():
            if key == "pluginID":
                normalized_dict["plugin_id"] = value
            elif key == "pluginName":
                normalized_dict["plugin_name"] = value
            elif hasattr(IntegrationFinding, key) or key in inspect.signature(IntegrationFinding.__init__).parameters:
                normalized_dict[key] = value

        for field in self.required_finding_fields:
            if field not in normalized_dict and field in mapped_finding_dict:
                normalized_dict[field] = mapped_finding_dict[field]

        try:
            return IntegrationFinding(**normalized_dict)
        except TypeError as e:
            logger.debug("Error creating IntegrationFinding: %s. Using original finding.", e)
            return finding
