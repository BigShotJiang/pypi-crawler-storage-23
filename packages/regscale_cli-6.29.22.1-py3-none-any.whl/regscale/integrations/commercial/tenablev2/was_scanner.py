"""
Module for Tenable WAS (Web Application Scanning) integration.

Syncs web application vulnerability findings and web app assets from
Tenable.io WAS into RegScale using the same API credentials as Tenable.io.
"""

import datetime
import json
import logging
from pathlib import Path
from typing import Any, Dict, Iterator, Optional
from urllib.parse import urlparse

from regscale.core.app.utils.app_utils import get_current_datetime
from regscale.integrations.commercial.tenablev2.authenticate import gen_tio
from regscale.integrations.commercial.tenablev2.constants import ARTIFACTS_DIR
from regscale.integrations.scanner_integration import (
    IntegrationAsset,
    IntegrationFinding,
    ScannerIntegration,
    issue_due_date,
)
from regscale.integrations.variables import ScannerVariables
from regscale.models import regscale_models

logger = logging.getLogger("regscale")

ARTIFACTS_PATH = ARTIFACTS_DIR


class TenableWASIntegration(ScannerIntegration):
    """
    Integration class for Tenable WAS (Web Application Scanning).

    Uses the same Tenable.io API credentials as the standard Tenable integration.
    Fetches web application scan findings via ``tio.exports.was()`` and maps them
    to RegScale IntegrationFinding / IntegrationAsset objects.
    """

    title: str = "Tenable WAS"
    asset_identifier_field: str = "wasAppId"
    finding_severity_map: Dict[str, regscale_models.IssueSeverity] = {
        "critical": regscale_models.IssueSeverity.Critical,
        "high": regscale_models.IssueSeverity.High,
        "medium": regscale_models.IssueSeverity.Moderate,
        "low": regscale_models.IssueSeverity.Low,
    }

    def __init__(self, plan_id: int, tenant_id: int = 1, **kwargs: Any) -> None:
        """
        Initialize the TenableWASIntegration.

        :param int plan_id: The ID of the security plan
        :param int tenant_id: The ID of the tenant, defaults to 1
        :param kwargs: Additional configuration passed to ScannerIntegration
        """
        super().__init__(plan_id, tenant_id, **kwargs)
        self.client = None
        self.scan_date = kwargs.get("scan_date", get_current_datetime())

    def authenticate(self) -> None:
        """Authenticate to Tenable.io (WAS uses the same credentials)."""
        self.client = gen_tio()

    def fetch_assets(self, *args: Any, **kwargs: Any) -> Iterator[IntegrationAsset]:
        """
        Fetch web applications from Tenable WAS as assets.

        Exports WAS findings, extracts unique web apps by asset UUID,
        caches to JSONL, and yields IntegrationAsset objects.

        :yields: Iterator[IntegrationAsset]
        """
        Path.mkdir(Path(ARTIFACTS_PATH), exist_ok=True, parents=True)
        current_datetime = datetime.datetime.now().strftime("%Y%m%d%H")
        cache_file = Path(ARTIFACTS_PATH) / f"tenable_was_apps_{self.plan_id}_{current_datetime}.jsonl"

        if cache_file.exists() and not self._is_empty(cache_file) and self._is_cache_fresh(cache_file):
            logger.info("Loading WAS apps from cache...")
        else:
            self.authenticate()
            if not self.client:
                raise ValueError("Client not authenticated")

            logger.info("Fetching WAS findings to extract web applications...")
            seen_assets: set = set()
            i = 0
            with open(cache_file, "w", encoding="utf-8") as f:
                for finding in self.client.exports.was():
                    asset_data = finding.get("asset", {})
                    asset_uuid = asset_data.get("uuid", "")
                    if asset_uuid and asset_uuid not in seen_assets:
                        seen_assets.add(asset_uuid)
                        f.write(json.dumps(asset_data) + "\n")
                        i += 1
                        if i % 50 == 0:
                            logger.info("Extracted %d unique web apps", i)
            logger.info("Total unique web apps extracted: %d", i)

        with open(cache_file, encoding="utf-8") as f:
            self.num_assets_to_process = sum(1 for _ in f)
        logger.info("Total web apps to process: %d", self.num_assets_to_process)

        with open(cache_file, "r", encoding="utf-8") as f:
            for line in f:
                app_data = json.loads(line)
                yield self.parse_was_app(app_data)

    def parse_was_app(self, app_data: Dict[str, Any]) -> IntegrationAsset:
        """
        Parse a Tenable WAS web application into an IntegrationAsset.

        :param Dict[str, Any] app_data: The WAS asset data from the export
        :return: The parsed IntegrationAsset
        :rtype: IntegrationAsset
        """
        asset_uuid = app_data.get("uuid", "")
        hostname = app_data.get("hostname", "")
        fqdn_val = app_data.get("fqdn", "") or hostname

        # Extract FQDN from hostname if it looks like a URL
        if fqdn_val and ("://" in fqdn_val):
            parsed = urlparse(fqdn_val)
            fqdn_val = parsed.hostname or fqdn_val

        name = fqdn_val or hostname or asset_uuid or "Unknown Web App"

        return IntegrationAsset(
            name=name,
            external_id=asset_uuid,
            identifier=asset_uuid,
            asset_type=regscale_models.AssetType.Other,
            asset_category=regscale_models.AssetCategory.Software,
            asset_owner_id=getattr(ScannerVariables, "userId", "00000000-0000-0000-0000-000000000000"),
            parent_id=self.plan_id,
            parent_module=regscale_models.SecurityPlan.get_module_slug(),
            date_last_updated=get_current_datetime(),
            status=regscale_models.AssetStatus.Active,
            fqdn=fqdn_val,
            ip_address=app_data.get("ipv4", ""),
            notes="Tenable WAS Web Application",
            source_data=app_data,
        )

    def fetch_findings(self, *args: Any, **kwargs: Any) -> Iterator[IntegrationFinding]:
        """
        Fetch WAS vulnerability findings from Tenable.io.

        Exports WAS findings, caches to JSONL, and yields IntegrationFinding objects.

        :yields: Iterator[IntegrationFinding]
        """
        Path.mkdir(Path(ARTIFACTS_PATH), exist_ok=True, parents=True)
        current_datetime = datetime.datetime.now().strftime("%Y%m%d%H")
        cache_file = Path(ARTIFACTS_PATH) / f"tenable_was_findings_{self.plan_id}_{current_datetime}.jsonl"

        if cache_file.exists() and not self._is_empty(cache_file) and self._is_cache_fresh(cache_file):
            logger.info("Loading WAS findings from cache...")
        else:
            logger.info("Fetching WAS findings from Tenable.io...")
            self.authenticate()
            if not self.client:
                raise ValueError("Client not authenticated")

            i = 0
            with open(cache_file, "w", encoding="utf-8") as f:
                for finding in self.client.exports.was():
                    f.write(json.dumps(finding) + "\n")
                    i += 1
                    if i % 100 == 0:
                        logger.info("Fetched %d WAS findings", i)
            logger.info("Total WAS findings fetched: %d", i)

        with open(cache_file, encoding="utf-8") as f:
            self.num_findings_to_process = sum(1 for _ in f)
        logger.info("Total WAS findings to process: %d", self.num_findings_to_process)

        with open(cache_file, "r", encoding="utf-8") as f:
            for line in f:
                parsed = self.parse_was_finding(json.loads(line))
                if parsed:
                    yield parsed

    def parse_was_finding(self, finding: Dict[str, Any]) -> Optional[IntegrationFinding]:
        """
        Parse a Tenable WAS finding into an IntegrationFinding.

        :param Dict[str, Any] finding: The WAS finding dict from the export
        :return: The parsed IntegrationFinding or None if parsing fails
        :rtype: Optional[IntegrationFinding]
        """
        try:
            plugin = finding.get("plugin", {})
            asset = finding.get("asset", {})

            plugin_id = str(plugin.get("id", ""))
            plugin_name = plugin.get("name", "")
            if isinstance(plugin_name, list):
                plugin_name = plugin_name[0] if plugin_name else ""

            # Severity mapping
            severity_str = finding.get("severity", "info").lower()
            if severity_str == "info" or finding.get("severity_id", 0) == 0:
                logger.debug("Skipping informational WAS finding: %s", plugin_name)
                return None

            severity_default = regscale_models.IssueSeverity.NotAssigned
            severity = self.finding_severity_map.get(severity_str, severity_default)
            severity_map = {"critical": 4, "high": 3, "medium": 2, "low": 1, "info": 0}
            severity_int = severity_map.get(severity_str, 0)

            # State → status
            state = finding.get("state", "ACTIVE").upper()
            status = regscale_models.IssueStatus.Closed if state == "FIXED" else regscale_models.IssueStatus.Open

            # CVE extraction
            cve_list = plugin.get("cve", [])
            cve = cve_list[0] if isinstance(cve_list, list) and cve_list else None

            # Identifier for title
            identifier = cve or plugin_name
            title = f"{identifier}: {plugin_name}" if cve else plugin_name

            # Asset identifier
            asset_uuid = asset.get("uuid", "")

            # Build observations from WAS-specific context
            observations = self._build_observations(finding)

            # Category with OWASP or plugin family
            owasp = plugin.get("owasp_2021")
            family = plugin.get("family", "General")
            category = f"Tenable WAS: OWASP {owasp}" if owasp else f"Tenable WAS: {family}"

            return IntegrationFinding(
                control_labels=[],
                category=category,
                title=title,
                issue_title=title,
                description=plugin.get("description", ""),
                severity=severity,
                status=status,
                asset_identifier=asset_uuid,
                external_id=plugin_id,
                first_seen=finding.get("first_found", get_current_datetime()),
                last_seen=finding.get("last_found", get_current_datetime()),
                remediation=plugin.get("solution", ""),
                cvss_score=float(plugin.get("cvss3_base_score") or plugin.get("cvss_base_score") or 0),
                cve=cve,
                vulnerability_type=self.title,
                plugin_id=plugin_id,
                plugin_name=plugin_name,
                ip_address=asset.get("ipv4", ""),
                dns=asset.get("fqdn", ""),
                severity_int=severity_int,
                issue_type="Vulnerability",
                date_created=get_current_datetime(),
                date_last_updated=get_current_datetime(),
                gaps="",
                observations=observations,
                evidence=finding.get("proof", ""),
                identified_risk="",
                impact="",
                recommendation_for_mitigation=plugin.get("solution", ""),
                rule_id=plugin_id,
                rule_version="",
                results=finding.get("output", ""),
                comments=None,
                baseline="",
                poam_comments=None,
                vulnerable_asset=asset_uuid,
                source_rule_id=plugin_id,
                due_date=issue_due_date(
                    severity=severity,
                    created_date=self.scan_date,
                    title="tenable_was",
                    config=self.app.config,
                ),
            )
        except Exception as e:
            logger.error("Error parsing WAS finding: %s", str(e), exc_info=True)
            return None

    @staticmethod
    def _build_observations(finding: Dict[str, Any]) -> str:
        """
        Build observations string from WAS-specific finding context.

        :param Dict[str, Any] finding: The WAS finding data
        :return: Formatted observations string
        :rtype: str
        """
        parts = []
        if url := finding.get("url"):
            parts.append(f"URL: {url}")
        if method := finding.get("http_method"):
            parts.append(f"HTTP Method: {method}")
        if input_type := finding.get("input_type"):
            parts.append(f"Input Type: {input_type}")
        if input_name := finding.get("input_name"):
            parts.append(f"Input Name: {input_name}")
        if payload := finding.get("payload"):
            parts.append(f"Payload: {payload}")
        return "\n".join(parts)

    @staticmethod
    def _is_empty(file_path: Path) -> bool:
        """
        Check if a file is empty.

        :param Path file_path: The path to the file
        :return: True if empty, False otherwise
        :rtype: bool
        """
        try:
            return file_path.stat().st_size == 0
        except FileNotFoundError:
            return True

    @staticmethod
    def _is_cache_fresh(file_path: Path) -> bool:
        """
        Check if a cache file is less than 1 day old.

        :param Path file_path: The path to the cache file
        :return: True if cache is fresh, False otherwise
        :rtype: bool
        """
        try:
            mtime = datetime.datetime.fromtimestamp(file_path.stat().st_mtime)
            return (datetime.datetime.now() - mtime).days < 1
        except FileNotFoundError:
            return False
