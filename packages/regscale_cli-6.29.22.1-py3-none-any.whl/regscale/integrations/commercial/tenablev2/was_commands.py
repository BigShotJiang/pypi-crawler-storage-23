"""
Tenable WAS (Web Application Scanning) CLI commands.

Provides Click commands for syncing web application findings and assets
from Tenable.io WAS into RegScale.
"""

import logging
from datetime import datetime

import click
from rich.console import Console

from regscale.models import regscale_ssp_id

logger = logging.getLogger("regscale")
console = Console()


WAS_HELP = """Tenable WAS (Web Application Scanning) commands.

These commands use the Tenable.io WAS export API and require Tenable.io
(cloud) credentials. If you are using Tenable Security Center with the
WAS add-on, WAS findings flow through SC's standard vulnerability data
and are already captured by 'regscale tenable sc' commands (sync_jsonl,
query_vuln).
"""


@click.group(name="was", help=WAS_HELP)
def was():
    """Tenable WAS (Web Application Scanning) commands."""


@was.command(name="sync_findings")
@regscale_ssp_id(help="RegScale will create findings as children of this security plan.")
@click.option(
    "--severity",
    type=click.Choice(["critical", "high", "medium", "low", "all"], case_sensitive=False),
    default="all",
    help="Filter findings by severity.",
    required=False,
)
@click.option(
    "--scan_date",
    type=click.DateTime(formats=["%Y-%m-%d"]),
    help="The scan date of the findings.",
    required=False,
)
def was_sync_findings(regscale_ssp_id: int, severity: str = "all", scan_date: datetime = None):
    """Sync WAS vulnerability findings from Tenable.io to RegScale."""
    console.print("[bold]Starting Tenable WAS finding synchronization...[/bold]")

    try:
        from regscale.integrations.commercial.tenablev2.was_scanner import (
            TenableWASIntegration,
        )

        integration = TenableWASIntegration(plan_id=regscale_ssp_id, scan_date=scan_date)
        integration.sync_findings(plan_id=regscale_ssp_id, severity=severity)

        console.print("[bold green]Tenable WAS finding synchronization complete.[/bold green]")
    except Exception as e:
        logger.error("Error syncing WAS findings from Tenable.io: %s", e, exc_info=True)
        console.print(f"[bold red]Error syncing WAS findings: {e}[/bold red]")


@was.command(name="sync_apps")
@regscale_ssp_id(help="RegScale will create and update web app assets as children of this security plan.")
def was_sync_apps(regscale_ssp_id: int):
    """Sync web applications from Tenable WAS as assets to RegScale."""
    console.print("[bold]Starting Tenable WAS app synchronization...[/bold]")

    try:
        from regscale.integrations.commercial.tenablev2.was_scanner import (
            TenableWASIntegration,
        )

        integration = TenableWASIntegration(plan_id=regscale_ssp_id)
        integration.sync_assets(plan_id=regscale_ssp_id)

        console.print("[bold green]Tenable WAS app synchronization complete.[/bold green]")
    except Exception as e:
        logger.error("Error syncing WAS apps from Tenable.io: %s", e, exc_info=True)
        console.print(f"[bold red]Error syncing WAS apps: {e}[/bold red]")
