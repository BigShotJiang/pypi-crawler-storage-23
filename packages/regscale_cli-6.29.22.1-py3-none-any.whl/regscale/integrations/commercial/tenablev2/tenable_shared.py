"""
Shared utility functions for Tenable SC and JSONL scanner integrations.

This module centralizes parsing/mapping logic that is duplicated across
sc_scanner.py and jsonl_scanner.py.
"""

import logging
import re
from typing import Callable, Dict, List, Tuple

from regscale.integrations.commercial.tenablev2.utils import get_filtered_severities
from regscale.integrations.scanner_integration import IntegrationFinding
from regscale.models import regscale_models
from regscale.models.integration_models.tenable_models.models import TenableAsset

logger = logging.getLogger("regscale")


def get_cvss_scores(vuln: TenableAsset) -> Dict[str, float]:
    """
    Extract CVSS v2 and v3 base scores from a TenableAsset.

    :param TenableAsset vuln: The Tenable finding
    :return: Dictionary with 'cvss_v3_base_score' and 'cvss_v2_base_score'
    :rtype: Dict[str, float]
    """
    res: Dict[str, float] = {}
    try:
        res["cvss_v3_base_score"] = float(vuln.cvssV3BaseScore) if vuln.cvssV3BaseScore else 0.0
        res["cvss_v2_base_score"] = float(vuln.baseScore) if vuln.baseScore else 0.0
    except (ValueError, TypeError):
        res["cvss_v3_base_score"] = 0.0
        res["cvss_v2_base_score"] = 0.0
    return res


def extract_version_info(vuln: TenableAsset) -> Tuple[str, str, str]:
    """
    Extract installed/fixed version and package path from vulnerability plugin text.

    :param TenableAsset vuln: The Tenable finding
    :return: Tuple of (installed_versions, fixed_versions, package_path)
    :rtype: Tuple[str, str, str]
    """
    installed_versions_str = ""
    fixed_versions_str = ""
    package_path_str = ""

    if not hasattr(vuln, "pluginText"):
        return installed_versions_str, fixed_versions_str, package_path_str

    plugin_text = vuln.pluginText

    if "Installed package" in plugin_text:
        installed_versions = re.findall(r"Installed package\s*:\s*(\S+)", plugin_text)
        installed_versions_str = ", ".join(installed_versions)
    elif "Installed version" in plugin_text:
        installed_versions = re.findall(r"Installed version\s*:\s*(.+)", plugin_text)
        installed_versions_str = ", ".join(installed_versions)

    if "Fixed package" in plugin_text:
        fixed_versions = re.findall(r"Fixed package\s*:\s*(\S+)", plugin_text)
        fixed_versions_str = ", ".join(fixed_versions)
    elif "Fixed version" in plugin_text:
        fixed_versions = re.findall(r"Fixed version\s*:\s*(.+)", plugin_text)
        fixed_versions_str = ", ".join(fixed_versions)

    if "Path" in plugin_text:
        package_path = re.findall(r"Path\s*:\s*(\S+)", plugin_text)
        package_path_str = ", ".join(package_path)

    return installed_versions_str, fixed_versions_str, package_path_str


def create_finding_title(vuln: TenableAsset, cve: str, getter_func: Callable) -> str:
    """
    Create a title for a Tenable finding.

    :param TenableAsset vuln: The Tenable finding
    :param str cve: The CVE identifier
    :param callable getter_func: Function to get mapped field values
    :return: Finding title
    :rtype: str
    """
    title = getter_func("title")
    if title:
        return title
    if cve:
        return f"{cve}: {vuln.synopsis}"
    return vuln.synopsis or vuln.pluginName


def parse_tenable_findings(
    vuln: TenableAsset,
    integration_mapping,
    severity_map: dict,
    create_finding_func: Callable,
) -> List[IntegrationFinding]:
    """
    Parse a TenableAsset into IntegrationFinding objects, splitting by CVE.

    :param TenableAsset vuln: The Tenable finding
    :param integration_mapping: The IntegrationMapping/Override object
    :param dict severity_map: Mapping from severity name to IssueSeverity
    :param callable create_finding_func: Function(vuln, cve, integration_mapping) -> IntegrationFinding
    :return: A list of IntegrationFinding objects
    :rtype: List[IntegrationFinding]
    """
    findings: List[IntegrationFinding] = []
    try:
        severity = severity_map.get(vuln.severity.name, regscale_models.IssueSeverity.Low)
        cve_set = set(vuln.cve.split(",")) if vuln.cve else set()
        if severity in get_filtered_severities():
            if cve_set:
                for cve in cve_set:
                    findings.append(create_finding_func(vuln=vuln, cve=cve, integration_mapping=integration_mapping))
            else:
                findings.append(create_finding_func(vuln=vuln, cve="", integration_mapping=integration_mapping))
    except (KeyError, TypeError, ValueError) as e:
        logger.error("Error parsing Tenable finding: %s", str(e), exc_info=True)
    return findings
