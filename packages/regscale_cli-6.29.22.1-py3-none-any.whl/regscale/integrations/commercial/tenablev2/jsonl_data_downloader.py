"""
Mixin class providing Tenable SC data download functionality.

This module extracts the API download logic from the main TenableSCJsonlScanner
class to keep the codebase maintainable and focused.
"""

import json
import logging
import os
import tempfile
from typing import Dict, List

from regscale.core.app.utils.file_utils import find_files
from regscale.exceptions.validation_exception import ValidationException
from regscale.integrations.commercial.tenablev2.variables import TenableVariables

logger = logging.getLogger("regscale")


class TenableDataDownloaderMixin:
    """
    Mixin providing Tenable SC data download and file management methods.

    This mixin is used by TenableSCJsonlScanner to handle downloading data from
    the Tenable SC API and managing local data files.
    """

    def find_or_download_data(self) -> List[str]:
        """
        Find existing Tenable SC data files or download new ones.

        :return: List of file paths
        :rtype: List[str]
        """
        self._ensure_temp_directory()
        artifacts_dir = self.create_artifacts_dir()
        self._clean_existing_files(artifacts_dir)
        return self._download_data_files(artifacts_dir)

    def _ensure_temp_directory(self) -> None:
        """Ensure a temporary directory exists for processing files."""
        if not self.temp_dir:
            self.temp_dir = tempfile.mkdtemp(prefix="tenable_sc_")
            logger.info("Created temporary directory: %s", self.temp_dir)

    def _clean_existing_files(self, artifacts_dir: str) -> None:
        """
        Remove existing Tenable SC data files from the artifacts directory.

        :param str artifacts_dir: Path to the artifacts directory
        """
        existing_files = list(find_files(artifacts_dir, self.file_pattern))
        if existing_files:
            logger.info("Found %d existing Tenable SC data files to clean up", len(existing_files))
            for file_path in existing_files:
                try:
                    os.remove(file_path)
                    logger.info("Removed existing file: %s", file_path)
                except OSError as e:
                    logger.warning("Failed to remove file %s: %s", file_path, e)

    def _download_data_files(self, artifacts_dir: str) -> List[str]:
        """
        Download Tenable SC data files to the artifacts directory.

        :param str artifacts_dir: Path to the artifacts directory
        :return: List of downloaded file paths
        :rtype: List[str]
        """
        logger.info("Downloading new Tenable SC data...")

        for output_file in [self.ASSETS_FILE, self.FINDINGS_FILE]:
            if os.path.exists(output_file):
                try:
                    os.remove(output_file)
                    logger.info("Removed existing output file: %s", output_file)
                except OSError as e:
                    logger.warning("Failed to remove output file %s: %s", output_file, e)

        if not self.query_id:
            logger.error("No query_id provided and no existing files found")
            raise ValidationException("Cannot download data: No query_id provided and no existing files found")

        logger.info("Downloading data using query_id: %s", self.query_id)
        downloaded_files = self._download_sc_data(artifacts_dir)

        if not downloaded_files:
            downloaded_files = [self._create_placeholder_file(artifacts_dir)]

        logger.info("Downloaded %d files", len(downloaded_files))
        for file_path in downloaded_files:
            logger.info("  - %s", file_path)

        return downloaded_files

    def _create_placeholder_file(self, artifacts_dir: str) -> str:
        """
        Create a placeholder file when no files are downloaded.

        :param str artifacts_dir: Path to the artifacts directory
        :return: Path to the created placeholder file
        :rtype: str
        """
        logger.warning("No files were downloaded. Creating a placeholder file for debugging.")
        debug_file = os.path.join(artifacts_dir, "sc_vulns.json")
        with open(debug_file, "w") as f:
            json.dump({"response": {"results": []}}, f)
        logger.info("Created placeholder file: %s", debug_file)
        return debug_file

    def _download_sc_data(self, output_dir: str) -> List[str]:
        """
        Download Tenable SC data using the SC client and save to files.

        :param str output_dir: Directory to save the files to
        :return: List of file paths that were created
        :rtype: List[str]
        """
        logger.info("Downloading Tenable SC data...")
        files_created = []

        try:
            if not self._initialize_client_and_directory(output_dir):
                return files_created

            vulns_file = os.path.join(output_dir, "sc_vulns.json")
            files_created = self._fetch_vulnerabilities(vulns_file, files_created)

            assets_file = os.path.join(output_dir, "sc_assets.json")
            if not os.path.exists(assets_file):
                self._create_assets_file_from_vulns(assets_file, vulns_file, files_created)

        except Exception as e:
            logger.error("Error downloading Tenable SC data: %s", str(e), exc_info=True)

        return files_created

    def _initialize_client_and_directory(self, output_dir: str) -> bool:
        """
        Initialize the client and ensure the output directory exists.

        :param str output_dir: Directory to save files to
        :return: True if initialization successful
        :rtype: bool
        """
        if not self.client:
            logger.info("Authenticating to Tenable SC...")
            if not self.authenticate():
                logger.error("Failed to authenticate to Tenable SC")
                return False
        os.makedirs(output_dir, exist_ok=True)
        logger.info("Output directory: %s", output_dir)
        return True

    def _fetch_vulnerabilities(self, vulns_file: str, files_created: List[str]) -> List[str]:
        """
        Fetch vulnerabilities from Tenable SC.

        :param str vulns_file: Path to save vulnerabilities to
        :param List[str] files_created: Current list of created files
        :return: Updated list of created files
        :rtype: List[str]
        """
        updated_files = files_created.copy()

        if not self.query_id:
            logger.warning("No query_id provided, skipping vulnerability download")
            return updated_files

        logger.info("Fetching vulnerabilities using query ID: %s", self.query_id)
        vulns_count = self._fetch_vulns_with_client(vulns_file, self.query_id)

        if vulns_count > 0:
            updated_files.append(vulns_file)
            logger.info("Successfully downloaded %d vulnerabilities to %s", vulns_count, vulns_file)
        else:
            self._create_empty_vulns_file(vulns_file, updated_files)

        return updated_files

    def _create_empty_vulns_file(self, vulns_file: str, files_created: List[str]) -> None:
        """
        Create an empty vulnerabilities file.

        :param str vulns_file: Path to create file at
        :param List[str] files_created: List to append the file path to
        """
        logger.warning("No vulnerabilities found for query ID: %s", self.query_id)
        with open(vulns_file, "w") as f:
            json.dump({"response": {"results": []}}, f)
        files_created.append(vulns_file)
        logger.info("Created empty vulnerabilities file: %s", vulns_file)

    def _create_assets_file_from_vulns(self, assets_file: str, vulns_file: str, files_created: List[str]) -> None:
        """
        Create an assets file from vulnerability data.

        :param str assets_file: Path to create assets file
        :param str vulns_file: Path to vulnerabilities file
        :param List[str] files_created: List to append file path to
        """
        logger.info("Creating assets file from vulnerability results...")
        asset_data = {"response": {"usable": []}}

        if not os.path.exists(vulns_file):
            self._write_assets_file(assets_file, asset_data, files_created)
            return

        try:
            unique_assets = self._extract_assets_from_vulns(vulns_file)
            asset_data["response"]["usable"] = list(unique_assets.values())
            logger.info("Extracted %d unique assets from vulnerability data", len(unique_assets))
        except Exception as e:
            logger.error("Error extracting assets from vulnerability data: %s", str(e), exc_info=True)

        self._write_assets_file(assets_file, asset_data, files_created)

    def _extract_assets_from_vulns(self, vulns_file: str) -> Dict[str, Dict]:
        """
        Extract unique assets from vulnerability data.

        :param str vulns_file: Path to vulnerability file
        :return: Dictionary of unique assets
        :rtype: Dict[str, Dict]
        """
        unique_assets = {}
        with open(vulns_file, "r") as f:
            vuln_data = json.load(f)

        for vuln in vuln_data.get("response", {}).get("results", []):
            identifier = vuln.get("ip", "") or vuln.get("dnsName", "")
            if identifier and identifier not in unique_assets:
                asset_entry = {
                    "id": identifier,
                    "name": vuln.get("dnsName", identifier),
                    "definition": f"ip={identifier}",
                    "description": "Asset created from vulnerability data",
                }
                unique_assets[identifier] = asset_entry

        return unique_assets

    def _write_assets_file(self, assets_file: str, asset_data: Dict, files_created: List[str]) -> None:
        """
        Write asset data to file.

        :param str assets_file: File path to write to
        :param Dict asset_data: Asset data to write
        :param List[str] files_created: List to append file path to
        """
        with open(assets_file, "w") as f:
            json.dump(asset_data, f)
        files_created.append(assets_file)
        logger.info("Created assets file: %s with %d assets", assets_file, len(asset_data["response"]["usable"]))

    def _fetch_vulns_with_client(self, output_file: str, query_id: int) -> int:
        """
        Fetch vulnerabilities from Tenable SC using the client library.

        Writes results incrementally to avoid memory issues with large datasets.

        :param str output_file: File to save the vulnerabilities to
        :param int query_id: ID of the query to use
        :return: Number of vulnerabilities fetched
        :rtype: int
        """
        logger.info("Fetching vulnerabilities from Tenable SC using query ID: %s...", query_id)

        min_severity = getattr(TenableVariables, "tenableMinimumSeverityFilter", "critical").lower()
        logger.info("Using minimum severity filter: %s", min_severity)

        total_vulns = 0

        try:
            temp_dir = os.path.dirname(output_file)
            findings_jsonl = self._initialize_jsonl_file(temp_dir)
            vulns_iterator = self._create_vulns_iterator(query_id)
            total_vulns = self._process_vuln_iterator(vulns_iterator, findings_jsonl, output_file)

            logger.info("Successfully processed %d vulnerabilities", total_vulns)
            logger.info("Data written to temporary JSONL file: %s", findings_jsonl)

        except Exception as e:
            self._handle_vuln_fetch_error(e, output_file, query_id)

        return total_vulns

    def _initialize_jsonl_file(self, temp_dir: str) -> str:
        """
        Initialize JSONL file for findings.

        :param str temp_dir: Directory to create the file in
        :return: Path to the JSONL file
        :rtype: str
        """
        findings_jsonl = os.path.join(temp_dir, "sc_findings.jsonl")
        logger.info("Starting to process vulnerability data...")
        logger.info("Creating temporary JSONL file: %s", findings_jsonl)
        return findings_jsonl

    def _create_vulns_iterator(self, query_id: int):
        """
        Create an iterator for Tenable SC vulnerabilities.

        :param int query_id: Query ID to use
        :return: Iterator for vulnerabilities
        """
        logger.info("Using analysis.vulns with query_id=%s", query_id)
        query_params = {
            "query_id": query_id,
            "tool": "vulndetails",
            "sourceType": "cumulative",
        }
        logger.info("Query parameters: %s", query_params)
        return self.client.analysis.vulns(**query_params)

    def _process_vuln_iterator(self, vulns_iterator, findings_jsonl: str, output_file: str) -> int:
        """
        Process vulnerability iterator and write data to files.

        :param vulns_iterator: Iterator for vulnerabilities
        :param str findings_jsonl: Path to JSONL file for findings
        :param str output_file: Path to output file
        :return: Number of vulnerabilities processed
        :rtype: int
        """
        batch = []
        batch_size = self.batch_size or 1000
        batch_count = 0
        total_vulns = 0
        unique_assets = {}

        with open(findings_jsonl, "w") as jsonl_file:
            for vuln in vulns_iterator:
                jsonl_file.write(json.dumps(vuln) + "\n")
                self._extract_asset_from_vuln(vuln, unique_assets)
                total_vulns += 1
                batch.append(vuln)

                if len(batch) >= batch_size:
                    batch_count += 1
                    logger.info("Processed batch %d - %d vulnerabilities so far...", batch_count, total_vulns)
                    batch = []

        if batch:
            logger.info("Processed final batch - total: %d vulnerabilities", total_vulns)

        self._write_output_file(output_file, total_vulns)
        self._create_assets_file_from_unique(unique_assets, output_file)

        return total_vulns

    def _extract_asset_from_vuln(self, vuln: Dict, unique_assets: Dict) -> None:
        """
        Extract asset information from vulnerability data.

        :param Dict vuln: Vulnerability data
        :param Dict unique_assets: Dictionary to store unique assets
        """
        identifier = vuln.get("ip", "") or vuln.get("dnsName", "")
        if identifier and identifier not in unique_assets:
            asset_entry = {
                "id": identifier,
                "name": vuln.get("dnsName", identifier),
                "definition": f"ip={identifier}",
                "description": "Asset created from vulnerability data",
            }
            unique_assets[identifier] = asset_entry

    def _write_output_file(self, output_file: str, total_vulns: int) -> None:
        """
        Write output file with vulnerability data.

        :param str output_file: Path to output file
        :param int total_vulns: Number of vulnerabilities processed
        """
        logger.info("Writing %d vulnerabilities to output file: %s", total_vulns, output_file)
        with open(output_file, "w") as f:
            f.write('{"response": {"results": []}}')

    def _create_assets_file_from_unique(self, unique_assets: Dict, output_file: str) -> None:
        """
        Create assets file from unique assets dictionary.

        :param Dict unique_assets: Dictionary of unique assets
        :param str output_file: Path to output file used to determine directory
        """
        if not unique_assets:
            return
        temp_dir = os.path.dirname(output_file)
        assets_file = os.path.join(temp_dir, "sc_assets.json")
        asset_data = {"response": {"usable": list(unique_assets.values())}}
        with open(assets_file, "w") as f:
            json.dump(asset_data, f)
        logger.info("Created assets file with %d unique assets: %s", len(unique_assets), assets_file)

    def _handle_vuln_fetch_error(self, error: Exception, output_file: str, query_id: int) -> None:
        """
        Handle errors during vulnerability fetching with helpful messages.

        :param Exception error: The exception that occurred
        :param str output_file: Path to output file
        :param int query_id: Query ID that was used
        """
        logger.error("Error fetching vulnerabilities: %s", str(error), exc_info=True)

        error_str = str(error).lower()
        if "unauthorized" in error_str or "401" in str(error):
            logger.error("Authentication error. Please check credentials.")
        elif "not found" in error_str or "404" in str(error):
            logger.error("Query ID %d not found. Please verify the query exists.", query_id)
        elif "timeout" in error_str:
            logger.error("Request timed out. The query may be too large or the server is busy.")

        with open(output_file, "w") as f:
            json.dump({"response": {"results": []}}, f)
        logger.info("Created empty results file %s", output_file)
