"""
Integration class for Tenable SC vulnerability scanning using JSONLScannerIntegration.

This module provides a direct implementation of JSONLScannerIntegration for Tenable SC,
optimized for processing large volumes of scan data.
"""

import json
import logging
import os
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Iterator, List, Optional, Tuple, Union

from regscale.core.app.utils.app_utils import epoch_to_datetime, get_current_datetime
from regscale.core.app.utils.file_utils import find_files
from regscale.exceptions.validation_exception import ValidationException
from regscale.integrations.commercial.tenablev2.authenticate import gen_tsc
from regscale.integrations.commercial.tenablev2.jsonl_data_downloader import TenableDataDownloaderMixin
from regscale.integrations.commercial.tenablev2.jsonl_file_processor import TenableFileProcessorMixin
from regscale.integrations.commercial.tenablev2.tenable_shared import (
    create_finding_title,
    extract_version_info,
    get_cvss_scores,
    parse_tenable_findings,
)
from regscale.integrations.commercial.tenablev2.variables import TenableVariables
from regscale.integrations.integration_override import IntegrationOverride
from regscale.integrations.jsonl_scanner_integration import JSONLScannerIntegration
from regscale.integrations.scanner_integration import (
    IntegrationAsset,
    IntegrationFinding,
    issue_due_date,
)
from regscale.integrations.transformer.data_transformer import DataTransformer
from regscale.integrations.variables import ScannerVariables
from regscale.models import AssetStatus, AssetType, regscale_models
from regscale.models.integration_models.tenable_models.models import TenableAsset

logger = logging.getLogger("regscale")

FILE_TYPE = ".jsonl"
UNKNOWN_PLUGIN = "Unknown Plugin"


def _extract_ip_from_definition(definition: str) -> str:
    """
    Safely extract IP address from a Tenable SC asset definition string.

    :param str definition: The definition string (e.g., "ip=192.168.1.1&...")
    :return: Extracted IP address or empty string if not found
    :rtype: str
    """
    if "ip=" not in definition:
        return ""
    return definition.split("ip=")[1].split("&")[0].replace("%3B", ";")


class TenableSCJsonlScanner(TenableDataDownloaderMixin, TenableFileProcessorMixin, JSONLScannerIntegration):
    """
    Integration class for Tenable SC vulnerability scanning using JSONLScannerIntegration.

    This class provides functionality for processing Tenable SC data files and
    syncing assets and findings to RegScale. Data download logic is in
    TenableDataDownloaderMixin and file processing logic is in TenableFileProcessorMixin.
    """

    # Class attributes - customized for Tenable SC
    title: str = "Tenable SC Vulnerability Scanner"
    asset_identifier_field: str = "tenableId"

    # Custom file paths for Tenable SC data
    ASSETS_FILE = "./artifacts/tenable_sc_assets.jsonl"
    FINDINGS_FILE = "./artifacts/tenable_sc_findings.jsonl"
    file_pattern = "sc_*.*"  # Match both JSON and JSONL files

    # Severity mapping dictionary
    finding_severity_map = {
        "5": regscale_models.IssueSeverity.Critical,  # Critical
        "4": regscale_models.IssueSeverity.High,  # High
        "3": regscale_models.IssueSeverity.Moderate,  # Medium
        "2": regscale_models.IssueSeverity.Low,  # Low
        "1": regscale_models.IssueSeverity.Low,  # Info
        "0": regscale_models.IssueSeverity.Low,  # None
        "Info": regscale_models.IssueSeverity.NotAssigned,
        "Low": regscale_models.IssueSeverity.Low,
        "Medium": regscale_models.IssueSeverity.Moderate,
        "High": regscale_models.IssueSeverity.High,
        "Critical": regscale_models.IssueSeverity.Critical,
    }

    def __init__(
        self,
        plan_id: int,
        tenant_id: int = 1,
        scan_date: datetime = None,
        query_id: int = None,
        batch_size: int = None,
        optimize_memory: bool = True,
        force_download: bool = False,
        **kwargs,
    ):
        """
        Initialize the Tenable SC JSONLScannerIntegration.

        :param int plan_id: The ID of the security plan
        :param int tenant_id: The ID of the tenant, defaults to 1
        :param datetime scan_date: The date of the scan, defaults to None
        :param int query_id: The ID of the query to use, defaults to None
        :param int batch_size: Batch size for API requests, defaults to 1000
        :param bool optimize_memory: Whether to optimize memory usage, defaults to True
        :param bool force_download: Whether to force download data from Tenable SC, defaults to False
        """
        # Set specific file pattern for Tenable SC files
        kwargs["file_pattern"] = self.file_pattern
        kwargs["read_files_only"] = True
        # Pass scan_date through kwargs to parent class
        if scan_date:
            kwargs["scan_date"] = scan_date

        super().__init__(plan_id=plan_id, tenant_id=tenant_id, **kwargs)

        self.query_id = query_id
        self.batch_size = batch_size or 1000
        self.optimize_memory = optimize_memory
        self.force_download = force_download
        self.client = None
        self.scan_date = scan_date or get_current_datetime()
        self.closed_count = 0
        self.app = kwargs.get("app")
        self.temp_dir = None

    def authenticate(self) -> bool:
        """
        Authenticate to Tenable SC.

        :return: True if authentication was successful, False otherwise
        :rtype: bool
        """
        try:
            # Log Tenable URL and other settings
            logger.info(f"Authenticating to Tenable SC with URL: {TenableVariables.tenableUrl}")
            logger.info(f"Batch size: {self.batch_size}")

            # Log other relevant connection settings
            ssl_verify = getattr(ScannerVariables, "sslVerify", True)
            logger.info(f"Using SSL verification: {ssl_verify}")

            # Initialize the Tenable SC client
            self.client = gen_tsc()

            # Test authentication by making a simple API call
            if self.client:
                # Try a simple API call to verify connection
                try:
                    # Get Tenable SC version to verify connection - fixed to use the proper API
                    status = self.client.status.status()  # Use status.status() instead of status()
                    version = status.get("version", "unknown")
                    logger.info(f"Successfully authenticated to Tenable SC (version: {version})")

                    # Set client timeout for large queries if supported
                    if hasattr(self.client, "timeout"):
                        logger.info("Setting increased timeout for large queries")
                        self.client.timeout = 300  # 5 minutes

                    return True
                except Exception as e:
                    logger.error(
                        "Authentication successful but API test failed: %s",
                        str(e),
                        exc_info=True,
                    )
                    return True  # Return True since authentication was successful, even if the test API call failed. this is to not break current functionality where we assume authentication is successful if we can create the client. We can improve this in the future by adding a more robust test API call or retry logic.
            else:
                logger.error("Failed to create Tenable SC client")
                return False
        except Exception as e:
            logger.error(f"Error authenticating to Tenable SC: {str(e)}", exc_info=True)
            return False

    def find_valid_files(self, path: Union[Path, str]) -> Iterator[Tuple[Union[Path, str], Dict[str, Any]]]:
        """
        Find all valid Tenable SC data files in the given path.

        :param Union[Path, str] path: Path to search for files
        :return: Iterator of (file_path, data) tuples
        :rtype: Iterator[Tuple[Union[Path, str], Dict[str, Any]]]
        """
        if not path or path == "":
            # If no specific path provided, search artifacts directory
            path = self.create_artifacts_dir()

        # Add debug logging
        logger.info(f"Looking for files in path: {path}")

        # Add support for JSONL files
        jsonl_pattern = "sc_*.jsonl"

        # Find both JSON and JSONL files
        found_files = 0

        # First yield regular JSON files using parent implementation
        for file_data in super().find_valid_files(path):
            found_files += 1
            if isinstance(file_data, tuple) and len(file_data) >= 2:
                file_path = file_data[0]
                logger.info(f"Found valid file: {file_path}")

                # Check if it's an assets file and log details
                str_path = str(file_path)
                if "sc_assets" in str_path:
                    data = file_data[1]
                    if data and isinstance(data, dict):
                        assets = data.get("response", {}).get("usable", [])
                        logger.info(f"Assets file contains {len(assets)} assets")
            yield file_data

        # Now look for JSONL files
        for file_path in find_files(path, jsonl_pattern):
            found_files += 1
            logger.info(f"Found JSONL file: {file_path}")

            # For JSONL files, create an empty dict as placeholder
            # Actual processing is handled in _process_jsonl_findings
            yield file_path, {}

        logger.info(f"Total valid files found: {found_files}")

    def is_valid_file(self, data: Any, file_path: Union[Path, str]) -> Tuple[bool, Optional[Dict[str, Any]]]:
        """
        Validate Tenable SC data file structure.

        :param Any data: Data from the file
        :param Union[Path, str] file_path: Path to the file
        :return: Tuple of (is_valid, validated_data)
        :rtype: Tuple[bool, Optional[Dict[str, Any]]]
        """
        # Handle JSONL files separately
        str_path = str(file_path)
        if str_path.endswith(FILE_TYPE):
            logger.info(f"Validating JSONL file: {file_path}")
            # For JSONL files, we just verify the file exists and is readable
            if os.path.exists(str_path) and os.path.getsize(str_path) > 0:
                return True, {}
            return False, None

        # First use parent validation to ensure it's a non-empty dict
        is_valid, data = super().is_valid_file(data, file_path)
        if not is_valid or not data:
            return False, None

        # Now check for Tenable SC specific structures
        if "sc_assets" in str_path:
            if "response" not in data or "usable" not in data.get("response", {}):
                logger.warning(f"Invalid Tenable SC assets file format: {file_path}")
                return False, None
            return True, data

        # Validate vulnerabilities file
        if "sc_vulns" in str_path:
            if "response" not in data or "results" not in data.get("response", {}):
                logger.warning(f"Invalid Tenable SC vulnerabilities file format: {file_path}")
                return False, None
            return True, data

        # File doesn't match our expected patterns
        logger.warning(f"File doesn't appear to be a Tenable SC data file: {file_path}")
        return False, None

    def parse_asset(self, file_path: Union[Path, str], data: Dict[str, Any]) -> IntegrationAsset:
        """
        Parse a Tenable SC asset from source data.

        :param Union[Path, str] file_path: Path to the file
        :param Dict[str, Any] data: Parsed data
        :return: IntegrationAsset object
        :rtype: IntegrationAsset
        """
        if not data:
            logger.warning("Empty data provided to parse_asset")
            # Return a minimal valid asset to avoid NoneType errors
            return IntegrationAsset(
                identifier="unknown",
                name="Unknown Asset",
                ip_address="",
                status=AssetStatus.Active,
                asset_type="Other",
                asset_category="Software",
                parent_id=self.plan_id,
                parent_module=regscale_models.SecurityPlan.get_module_slug(),
            )

        try:
            # Attempt to convert to TenableAsset object if from vulnerability data
            if "response" in data and "results" in data.get("response", {}):
                results = data.get("response", {}).get("results", [])
                if results:
                    try:
                        vuln_data = TenableAsset(**results[0])
                        return self.to_integration_asset(
                            vuln_data,
                            app=self.app,
                            override=IntegrationOverride(self.app),
                        )
                    except Exception as e:
                        logger.warning(f"Could not parse vulnerability as TenableAsset: {str(e)}")
                        # Continue to parse as a basic asset instead of returning None

            # If we reach here, it's either an assets file or no valid data was found
            return self._parse_asset_from_assets_file(data)
        except Exception as e:
            logger.error(f"Error parsing Tenable SC asset: {str(e)}", exc_info=True)
            # Return a minimal valid asset to avoid NoneType errors
            return IntegrationAsset(
                identifier="error",
                name=f"Error Asset ({str(file_path)})",
                ip_address="",
                status=AssetStatus.Active,
                asset_type="Other",
                asset_category="Software",
                parent_id=self.plan_id,
                parent_module=regscale_models.SecurityPlan.get_module_slug(),
            )

    def _parse_asset_from_assets_file(self, data: Dict[str, Any]) -> IntegrationAsset:
        """
        Parse asset from a Tenable SC assets file.

        :param Dict[str, Any] data: Assets file data
        :return: IntegrationAsset object
        :rtype: IntegrationAsset
        """
        # Get first asset from usable list
        assets = data.get("response", {}).get("usable", [])
        if not assets:
            logger.warning("No assets found in Tenable SC assets file")
            return IntegrationAsset(
                identifier="unknown",
                name="Unknown Asset",
                ip_address="",
                status=AssetStatus.Active,
                asset_type="Other",
                asset_category="Software",
                parent_id=self.plan_id,
                parent_module=regscale_models.SecurityPlan.get_module_slug(),
            )

        asset = assets[0]

        # Extract asset data
        asset_id = asset.get("id", "")
        asset_name = asset.get("name", "")

        if not asset_id:
            logger.warning("Asset is missing ID, using default ID")
            asset_id = "missing_id"

        # Extract IP information if available
        ip_info = _extract_ip_from_definition(asset.get("definition", ""))

        # Use IP address as the identifier for consistency
        # If we can extract an IP from the definition, use that as the identifier
        identifier = ip_info if ip_info else asset_id

        return IntegrationAsset(
            identifier=identifier,
            name=asset_name or f"Asset {asset_id}",
            ip_address=ip_info,
            parent_id=self.plan_id,
            parent_module=regscale_models.SecurityPlan.get_module_slug(),
            asset_owner_id=ScannerVariables.userId,
            asset_category=regscale_models.AssetCategory.Hardware,
            asset_type=regscale_models.AssetType.Other,
            status=AssetStatus.Active,
            date_last_updated=get_current_datetime(),
        )

    def to_integration_asset(self, asset: TenableAsset, **kwargs: dict) -> IntegrationAsset:
        """Converts a TenableAsset object to an IntegrationAsset object

        :param TenableAsset asset: The Tenable SC asset
        :param dict **kwargs: Additional keyword arguments
        :return: An IntegrationAsset object
        :rtype: IntegrationAsset
        """
        override = kwargs.get("override")

        validated_match = None
        if override:
            validated_match = override.field_map_validation(obj=asset, model_type="asset")

        # Use IP as the primary identifier for consistency between assets and findings
        asset_identifier = asset.ip
        # If no IP, fall back to other identifiers
        if not asset_identifier:
            asset_identifier = validated_match or asset.dnsName or asset.dns or "unknown"

        name = asset.dnsName or asset.ip

        return IntegrationAsset(
            name=name,
            identifier=asset_identifier,
            ip_address=asset.ip,
            mac_address=asset.macAddress,
            asset_owner_id=ScannerVariables.userId,
            status=(
                AssetStatus.Active
                if getattr(asset, "family", None) and getattr(asset.family, "type", None)
                else AssetStatus.Inactive
            ),
            asset_type=AssetType.Other,
            asset_category="Hardware",
        )

    def parse_finding(
        self, asset_identifier: str, data: Dict[str, Any], item: Dict[str, Any]
    ) -> Optional[IntegrationFinding]:
        """
        Parse a finding from a Tenable SC vulnerability.

        :param str asset_identifier: Asset identifier
        :param Dict[str, Any] data: Asset data
        :param Dict[str, Any] item: Finding data (vulnerability)
        :return: IntegrationFinding object
        :rtype: Optional[IntegrationFinding]
        """
        if not item:
            return None

        try:
            # Try to convert to TenableAsset for consistent processing
            try:
                vuln = TenableAsset(**item)
            except Exception as e:
                logger.warning(f"Could not create TenableAsset from finding data: {str(e)}")
                # Get the IP from the vulnerability item directly rather than using passed asset_identifier
                finding_asset_id = item.get("ip", asset_identifier)

                # Create a minimal finding since TenableAsset creation failed
                return IntegrationFinding(
                    control_labels=[],  # Add an empty list for control_labels
                    title=item.get("pluginName", "Unknown Finding"),
                    description=item.get("description", "No description available"),
                    severity=regscale_models.IssueSeverity.Low,
                    status=regscale_models.IssueStatus.Open,
                    asset_identifier=finding_asset_id,  # Use the IP from the finding
                    category="Vulnerability",
                    scan_date=self.scan_date,
                    plugin_name=item.get("pluginName", UNKNOWN_PLUGIN),
                )

            # Use the integration_mapping if available
            integration_mapping = IntegrationOverride(self.app) if self.app else None

            # Process findings similar to SC scanner
            findings = self.parse_findings(vuln, integration_mapping)

            if findings:
                return findings[0]  # Return the first finding

            # If no findings were created, return a basic finding
            # Get the IP from the vulnerability directly rather than using passed asset_identifier
            finding_asset_id = vuln.ip or asset_identifier
            logger.debug(item)
            return IntegrationFinding(
                title=item.get("pluginName", "Unknown Finding"),
                description=item.get("description", "No description available"),
                severity=regscale_models.IssueSeverity.Low,
                status=regscale_models.IssueStatus.Open,
                asset_identifier=finding_asset_id,  # Use the IP from the finding
                category="Vulnerability",
                scan_date=self.scan_date,
                plugin_name=item.get("pluginName", UNKNOWN_PLUGIN),
                control_labels=item.get("controlLabels", []),
            )

        except Exception as e:
            logger.error(f"Error parsing Tenable SC finding: {str(e)}", exc_info=True)
            # Return a minimal finding on error
            return IntegrationFinding(
                control_labels=[],  # Add an empty list for control_labels
                title="Error Finding",
                description=f"Error parsing finding: {str(e)}",
                severity=regscale_models.IssueSeverity.Low,
                status=regscale_models.IssueStatus.Open,
                asset_identifier=asset_identifier,
                category="Vulnerability",
                scan_date=self.scan_date,
                plugin_name=UNKNOWN_PLUGIN,
            )

    def parse_findings(self, vuln: TenableAsset, integration_mapping: Any) -> List[IntegrationFinding]:
        """
        Parses a TenableAsset into an IntegrationFinding object

        :param TenableAsset vuln: The Tenable SC finding
        :param Any integration_mapping: The IntegrationMapping object
        :return: A list of IntegrationFinding objects
        :rtype: List[IntegrationFinding]
        """
        return parse_tenable_findings(
            vuln=vuln,
            integration_mapping=integration_mapping,
            severity_map=self.finding_severity_map,
            create_finding_func=self._create_finding,
        )

    def _create_finding(
        self, vuln: TenableAsset, cve: str, integration_mapping: IntegrationOverride
    ) -> IntegrationFinding:
        """
        Helper method to create an IntegrationFinding object

        :param TenableAsset vuln: The Tenable SC finding
        :param str cve: The CVE identifier
        :param IntegrationOverride integration_mapping: The IntegrationMapping object
        :return: An IntegrationFinding object
        :rtype: IntegrationFinding
        """

        # Extract helper method to simplify the main method
        def getter(field_name: str) -> Optional[str]:
            """
            Helper method to get the field value from the integration mapping

            :param str field_name: The field name to get the value for
            :return: The field value
            :rtype: Optional[str]
            """
            if integration_mapping and (val := integration_mapping.load("tenable_sc", field_name)):
                return getattr(vuln, val, None)
            return None

        # Get asset identifier
        asset_identifier = self._get_asset_identifier(vuln, integration_mapping)

        # Get CVSS scores
        cvss_scores = get_cvss_scores(vuln)

        # Map severity
        severity = self.finding_severity_map.get(vuln.severity.name, regscale_models.IssueSeverity.Low)

        # Extract version information
        installed_versions_str, fixed_versions_str, package_path_str = extract_version_info(vuln)

        # Handle dates
        first_seen = epoch_to_datetime(vuln.firstSeen) if vuln.firstSeen else self.scan_date
        last_seen = epoch_to_datetime(vuln.lastSeen) if vuln.lastSeen else self.scan_date

        # Create finding title
        title = create_finding_title(vuln, cve, getter)

        # Create and return the finding
        return IntegrationFinding(
            control_labels=[],  # Add an empty list for control_labels
            category="Tenable SC Vulnerability",  # Add a default category
            dns=vuln.dnsName,
            title=title,
            description=getter("description") or (vuln.description or vuln.pluginInfo),
            severity=severity,
            status=regscale_models.IssueStatus.Open,  # Findings of > Low are considered as FAIL
            asset_identifier=asset_identifier,
            external_id=vuln.pluginID,  # Weakness Source Identifier
            first_seen=first_seen,
            last_seen=last_seen,
            date_created=first_seen,
            date_last_updated=last_seen,
            recommendation_for_mitigation=vuln.solution,
            cve=cve,
            cvss_v3_score=cvss_scores.get("cvss_v3_base_score", 0.0),
            cvss_score=cvss_scores.get("cvss_v3_base_score", 0.0),
            cvss_v3_vector=vuln.cvssV3Vector,
            cvss_v2_score=cvss_scores.get("cvss_v2_base_score", 0.0),
            cvss_v2_vector=vuln.cvssVector,
            vpr_score=float(vuln.vprScore) if vuln.vprScore else None,
            comments=vuln.cvssV3Vector,
            plugin_id=vuln.pluginID,
            plugin_name=vuln.pluginName,
            rule_id=vuln.pluginID,
            rule_version=vuln.pluginName,
            basis_for_adjustment="Tenable SC import",
            vulnerability_type="Tenable SC Vulnerability",
            vulnerable_asset=vuln.dnsName,
            build_version="",
            affected_os=vuln.operatingSystem,
            affected_packages=vuln.pluginName,
            package_path=package_path_str,
            installed_versions=installed_versions_str,
            fixed_versions=fixed_versions_str,
            fix_status="",
            scan_date=self.scan_date,
            due_date=issue_due_date(
                severity=severity,
                created_date=first_seen,
                title="tenable",
                config=self.app.config if self.app else {},
            ),
        )

    def _get_asset_identifier(self, vuln: TenableAsset, integration_mapping: IntegrationOverride) -> str:
        """
        Extract asset identifier from vulnerability data

        :param TenableAsset vuln: The Tenable SC finding
        :param IntegrationOverride integration_mapping: The IntegrationMapping object
        :return: Asset identifier
        :rtype: str
        """
        validated_match = None
        if integration_mapping:
            validated_match = integration_mapping.field_map_validation(obj=vuln, model_type="asset")

        # Use IP as the primary identifier for consistency between assets and findings
        if vuln.ip:
            return vuln.ip

        # If no IP, fall back to other identifiers
        return validated_match or vuln.dnsName or vuln.dns or "unknown"

    def process_source_files(self, file_paths: List[str], assets_output_file: str, findings_output_file: str) -> None:
        """
        Process source files to extract assets and findings.

        :param List[str] file_paths: List of file paths to process
        :param str assets_output_file: Path to write assets to
        :param str findings_output_file: Path to write findings to
        """
        # Ensure output directories exist
        os.makedirs(os.path.dirname(assets_output_file), exist_ok=True)
        os.makedirs(os.path.dirname(findings_output_file), exist_ok=True)

        # Prepare output files
        asset_info = self._prepare_output_file(assets_output_file, True, "asset")
        finding_info = self._prepare_output_file(findings_output_file, True, "finding")

        # Process each file
        for file_path in file_paths:
            file_path_str = str(file_path)
            logger.info(f"Processing file: {file_path_str}")

            try:
                # Read and parse the file
                with open(file_path_str, "r") as f:
                    data = json.load(f)

                # Validate the file
                is_valid, validated_data = self.is_valid_file(data, file_path_str)
                if not is_valid or validated_data is None:
                    logger.warning(f"Invalid file: {file_path_str}")
                    continue

                # Process assets or findings based on file path
                if "sc_assets" in file_path_str:
                    # Process assets file
                    with open(assets_output_file, asset_info.get("mode", "w")) as output_f:
                        self._process_asset_file(
                            file_path_str,
                            validated_data,
                            output_f,
                            asset_info.get("existing_items", {}),
                        )
                    # Use append mode for subsequent files
                    asset_info["mode"] = "a"

                elif "sc_vulns" in file_path_str:
                    # Process findings file
                    with open(findings_output_file, finding_info.get("mode", "w")) as output_f:
                        self._process_finding_file(
                            file_path_str,
                            validated_data,
                            output_f,
                            finding_info.get("existing_items", {}),
                        )
                    # Use append mode for subsequent files
                    finding_info["mode"] = "a"

            except Exception as e:
                logger.error(f"Error processing file {file_path_str}: {str(e)}", exc_info=True)

    # Data download methods are provided by TenableDataDownloaderMixin
    # File processing methods are provided by TenableFileProcessorMixin

    def sync_assets_and_findings(self, **kwargs) -> None:
        """
        Process both assets and findings, downloading if necessary, and sync to RegScale.

        This method overrides the parent method to handle the case where file_path is not provided
        but query_id is, by first finding or downloading Tenable SC data files and then processing them.

        :param kwargs: Additional options including dry_run, offset, limit for orchestration
        :rtype: None
        """
        try:
            # Ensure we have a valid file path, downloading data if needed
            file_path = self._get_or_download_file_path()

            # Process files into JSONL format for assets and findings
            total_assets, total_findings = self._process_and_prepare_data(file_path)

            # Sync assets and findings to RegScale
            self._sync_data_to_regscale(total_assets, total_findings, **kwargs)

        except Exception as e:
            logger.error(f"Error in sync_assets_and_findings: {str(e)}", exc_info=True)
            raise

    def _get_or_download_file_path(self) -> str:
        """
        Get a valid file path, downloading data if necessary.

        :return: Valid file path to process
        :rtype: str
        """
        # If file_path is not provided, find or download files
        if not self.file_path:
            logger.info("No file path provided, finding or downloading Tenable SC data files")
            found_files = self.find_or_download_data()

            if not found_files:
                logger.error("No Tenable SC data files found or downloaded")
                raise ValidationException("No Tenable SC data files found or downloaded")

            # Use the directory containing the found files as the file_path
            if len(found_files) > 0:
                # Get the directory containing the files
                first_file = found_files[0]
                self.file_path = os.path.dirname(first_file)
                logger.info(f"Using directory containing found files as file_path: {self.file_path}")

        # Validate the file path
        return self._validate_file_path(self.file_path)

    def _process_and_prepare_data(self, file_path: str) -> Tuple[int, int]:
        """
        Process files into JSONL format for assets and findings.

        :param str file_path: Path to source files
        :return: Tuple of (asset_count, finding_count)
        :rtype: Tuple[int, int]
        """
        logger.info("Processing assets and findings together from %s", file_path)
        return self._process_files(
            file_path=file_path,
            assets_output_file=self.ASSETS_FILE,
            findings_output_file=self.FINDINGS_FILE,
            empty_assets_file=self.empty_files,
            empty_findings_file=self.empty_files,
        )

    def _sync_data_to_regscale(self, total_assets: int, total_findings: int, **kwargs) -> None:
        """
        Sync processed assets and findings to RegScale.

        :param int total_assets: Number of assets to sync
        :param int total_findings: Number of findings to sync
        :param kwargs: Additional options including dry_run, offset, limit for orchestration
        """
        # Sync assets
        logger.info("Syncing %d assets to RegScale", total_assets)
        self.sync_assets(
            plan_id=self.plan_id,
            file_path=self.file_path,
            use_jsonl_file=True,
            asset_count=total_assets,
            scan_date=self.scan_date,
            **kwargs,
        )

        # Sync findings
        logger.info("Syncing %d findings to RegScale", total_findings)
        self.sync_findings(
            plan_id=self.plan_id,
            file_path=self.file_path,
            use_jsonl_file=True,
            finding_count=total_findings,
            scan_date=self.scan_date,
            **kwargs,
        )

        logger.info("Assets and findings sync complete")

    def check_data_file(self, data_files: List[str]) -> bool:
        """
        Check if any Tenable SC data files exist.

        :param List[str] data_files: List of data file paths
        :return: True if data files exist
        :rtype: bool
        :raises ValidationException: If no data files are found
        """
        if not data_files:
            raise ValidationException("No Tenable SC data files found, nothing to sync")
        return True

    def sync_with_transformer(self, mapping_file: Optional[str] = None) -> None:
        """
        Sync assets and findings to RegScale using the DataTransformer.

        This method combines the ApiPaginator and DataTransformer to efficiently download
        and transform Tenable SC data for RegScale integration.

        Args:
            mapping_file (Optional[str]): Path to custom mapping file (uses default if None)

        Raises:
            Exception: If there is an error during synchronization
        """
        try:
            logger.info("Starting synchronization using DataTransformer...")

            # Step 1: Download or find data files
            data_files = self._get_data_files_for_sync()

            # Step 2: Create transformer
            transformer = self._create_transformer(mapping_file)

            # Step 3: Load and process data from files
            assets_list, findings_list = self._load_assets_and_findings(data_files)

            # Step 4: Transform data
            assets, findings = self._transform_data(transformer, assets_list, findings_list)

            # Step 5: Sync with RegScale
            self._sync_transformed_data(assets, findings)

        except Exception as e:
            logger.error(f"Error syncing with transformer: {str(e)}", exc_info=True)
            raise

    def _get_data_files_for_sync(self) -> List[str]:
        """
        Get data files for synchronization

        :return: List of data file paths
        :rtype: List[str]
        """
        data_files = self.find_or_download_data()
        self.check_data_file(data_files)
        logger.info(f"Processing {len(data_files)} Tenable SC data files")
        return data_files

    def _create_transformer(self, mapping_file: Optional[str] = None) -> DataTransformer:
        """
        Create a DataTransformer instance

        :param Optional[str] mapping_file: Path to custom mapping file
        :return: Configured DataTransformer instance
        :rtype: DataTransformer
        """
        transformer = DataTransformer(mapping_file=mapping_file)
        transformer.scan_date = self.scan_date
        return transformer

    def _load_assets_and_findings(self, data_files: List[str]) -> Tuple[List[Dict], List[Dict]]:
        """
        Load assets and findings from data files

        :param List[str] data_files: List of data file paths
        :return: Tuple of (assets_list, findings_list)
        :rtype: Tuple[List[Dict], List[Dict]]
        """
        assets_list = []
        findings_list = []

        for file_path in data_files:
            file_path_str = str(file_path)
            logger.info(f"Processing file: {file_path_str}")

            try:
                self._process_data_file(file_path_str, assets_list, findings_list)
            except Exception as e:
                logger.error(f"Error processing file {file_path_str}: {str(e)}", exc_info=True)

        return assets_list, findings_list

    def _process_data_file(self, file_path: str, assets_list: List[Dict], findings_list: List[Dict]) -> None:
        """
        Process a single data file and extract assets and findings

        :param str file_path: Path to data file
        :param List[Dict] assets_list: List to append assets to
        :param List[Dict] findings_list: List to append findings to
        """
        # Load the file data
        with open(file_path, "r") as f:
            data = json.load(f)

        # Validate the file
        is_valid, validated_data = self.is_valid_file(data, file_path)
        if not is_valid or validated_data is None:
            logger.warning(f"Invalid file: {file_path}")
            return

        # Process assets and findings based on file type
        if "sc_assets" in file_path:
            self._extract_assets(validated_data, assets_list, file_path)
        elif "sc_vulns" in file_path:
            self._extract_findings(validated_data, findings_list, file_path)

    def _extract_assets(self, validated_data: Dict, assets_list: List[Dict], file_path: str) -> None:
        """
        Extract assets from validated data

        :param Dict validated_data: Validated data from file
        :param List[Dict] assets_list: List to append assets to
        :param str file_path: Path to source file (for logging)
        """
        # Extract assets from assets file
        assets = validated_data.get("response", {}).get("usable", [])
        for asset_data in assets:
            assets_list.append(asset_data)
        logger.info(f"Added {len(assets)} assets from file: {file_path}")

    def _extract_findings(self, validated_data: Dict, findings_list: List[Dict], file_path: str) -> None:
        """
        Extract findings from validated data

        :param Dict validated_data: Validated data from file
        :param List[Dict] findings_list: List to append findings to
        :param str file_path: Path to source file (for logging)
        """
        # Extract findings from vulnerabilities file
        findings = validated_data.get("response", {}).get("results", [])
        for finding_data in findings:
            findings_list.append(finding_data)
        logger.info(f"Added {len(findings)} findings from file: {file_path}")

    def _transform_data(
        self,
        transformer: DataTransformer,
        assets_list: List[Dict],
        findings_list: List[Dict],
    ) -> Tuple[List[IntegrationAsset], List[IntegrationFinding]]:
        """
        Transform raw data into IntegrationAsset and IntegrationFinding objects

        :param DataTransformer transformer: DataTransformer instance
        :param List[Dict] assets_list: List of asset data
        :param List[Dict] findings_list: List of finding data
        :return: Tuple of (assets, findings)
        :rtype: Tuple[List[IntegrationAsset], List[IntegrationFinding]]
        """
        # Transform assets
        assets = list(transformer.batch_transform_to_assets(assets_list, plan_id=self.plan_id))

        # Link findings to assets
        self._link_findings_to_assets(assets, findings_list)

        # Transform findings
        findings = list(transformer.batch_transform_to_findings(findings_list))

        logger.info(f"Transformed {len(assets)} assets and {len(findings)} findings")
        return assets, findings

    def _link_findings_to_assets(self, assets: List[IntegrationAsset], findings_list: List[Dict]) -> None:
        """
        Link findings to assets using IP address

        :param List[IntegrationAsset] assets: List of assets
        :param List[Dict] findings_list: List of finding data to update
        """
        # Create mapping from IP to asset identifier
        asset_identifier_map = {asset.ip_address: asset.identifier for asset in assets if asset.ip_address}

        # Add asset identifier to each finding
        for finding_data in findings_list:
            ip = finding_data.get("ip", "")
            asset_id = asset_identifier_map.get(ip, ip)
            finding_data["asset_identifier"] = asset_id

    def _sync_transformed_data(self, assets: List[IntegrationAsset], findings: List[IntegrationFinding]) -> None:
        """
        Sync transformed data to RegScale

        :param List[IntegrationAsset] assets: List of assets
        :param List[IntegrationFinding] findings: List of findings
        """
        # Sync assets and findings to RegScale
        asset_count = self.update_regscale_assets(iter(assets))
        finding_count = self.update_regscale_findings(iter(findings))

        logger.info(f"Synchronized {asset_count} assets and {finding_count} findings to RegScale")

    def _process_files(
        self,
        file_path: Union[str, Path],
        assets_output_file: str,
        findings_output_file: str,
        empty_assets_file: bool = True,
        empty_findings_file: bool = True,
    ) -> Tuple[int, int]:
        """
        Process source files to extract assets and findings.

        :param Union[str, Path] file_path: Path to source file or directory
        :param str assets_output_file: Path to write assets to
        :param str findings_output_file: Path to write findings to
        :param bool empty_assets_file: Whether to empty the assets file before writing
        :param bool empty_findings_file: Whether to empty the findings file before writing
        :return: Tuple of (asset_count, finding_count)
        :rtype: Tuple[int, int]
        """
        # Ensure output directories exist
        os.makedirs(os.path.dirname(assets_output_file), exist_ok=True)
        os.makedirs(os.path.dirname(findings_output_file), exist_ok=True)

        # Prepare output files
        asset_info = self._prepare_output_file(assets_output_file, empty_assets_file, "asset")
        finding_info = self._prepare_output_file(findings_output_file, empty_findings_file, "finding")

        # Initialize counters for memory-efficient tracking
        asset_count = 0
        finding_count = 0
        processed_files = 0

        # Log start of processing
        logger.info(f"Starting to process files from {file_path}")

        # Process each file
        for file_path_obj, data in self.find_valid_files(file_path):
            processed_files += 1
            file_path_str = str(file_path_obj)
            file_size_mb = os.path.getsize(file_path_str) / (1024 * 1024) if os.path.exists(file_path_str) else 0

            logger.info(f"Processing file {processed_files}: {file_path_str} ({file_size_mb:.2f} MB)")

            try:
                # Check for JSONL files first - these are already in our optimized format
                if file_path_str.endswith(FILE_TYPE):
                    if "findings" in file_path_str.lower():
                        # Process findings JSONL file
                        with open(findings_output_file, finding_info.get("mode", "w")) as f:
                            count = self._process_jsonl_findings(
                                file_path_str, f, finding_info.get("existing_items", {})
                            )
                            finding_count += count
                            logger.info(f"Added {count} findings from JSONL file {file_path_str}")
                        # Use append mode after first file
                        finding_info["mode"] = "a"
                    continue

                # For JSON files, process normally
                if not self.is_valid_file(data, file_path_str)[0]:
                    logger.warning(f"Invalid file format: {file_path_str}")
                    continue

                # Process assets or findings based on file path
                if "sc_assets" in file_path_str:
                    # Process assets file
                    with open(assets_output_file, asset_info.get("mode", "w")) as output_f:
                        count = self._process_asset_file(
                            file_path_str,
                            data,
                            output_f,
                            asset_info.get("existing_items", {}),
                        )
                        asset_count += count
                    # Use append mode for subsequent files
                    asset_info["mode"] = "a"

                elif "sc_vulns" in file_path_str:
                    # Process findings file
                    with open(findings_output_file, finding_info.get("mode", "w")) as output_f:
                        count = self._process_finding_file(
                            file_path_str,
                            data,
                            output_f,
                            finding_info.get("existing_items", {}),
                        )
                        finding_count += count
                    # Use append mode for subsequent files
                    finding_info["mode"] = "a"

            except Exception as e:
                logger.error(f"Error processing file {file_path_str}: {str(e)}", exc_info=True)

        # Log completion
        logger.info(f"Finished processing {processed_files} files")
        logger.info(f"Added {asset_count} assets and {finding_count} findings to JSONL files")

        return asset_count, finding_count
