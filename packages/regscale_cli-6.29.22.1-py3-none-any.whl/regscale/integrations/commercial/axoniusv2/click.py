"""CLI commands for AxoniusV2 integration."""

import logging

import click

from regscale.models.app_models.click import regscale_ssp_id

logger = logging.getLogger("regscale")


# ── Shared option decorators ──────────────────────────────────────────


def _pagination_options(fn):
    """Add --offset, --limit, and --dry-run options to a command."""
    fn = click.option(
        "--offset",
        default=0,
        type=int,
        help="Number of records to skip (for orchestrator pagination).",
    )(fn)
    fn = click.option(
        "--limit",
        default=None,
        type=int,
        help="Maximum number of records to process (for orchestrator pagination).",
    )(fn)
    fn = click.option(
        "--dry-run",
        is_flag=True,
        default=False,
        help="Fetch and count records without pushing to RegScale.",
    )(fn)
    return fn


# ── Dry-run helper ────────────────────────────────────────────────────


def _dry_run_sync(scanner, plan_id: int, entity: str, **kwargs) -> None:
    """Consume the fetch iterator and print a summary without pushing to RegScale.

    :param scanner: An AxoniusV2ScannerIntegration instance.
    :param int plan_id: The SSP plan ID.
    :param str entity: Either 'assets' or 'findings'.
    :param kwargs: Forwarded to fetch_assets / fetch_findings.
    """
    if entity == "assets":
        stream = scanner.fetch_assets(plan_id=plan_id, **kwargs)
    else:
        stream = scanner.fetch_findings(plan_id=plan_id, **kwargs)

    count = 0
    for _ in stream:
        count += 1
    click.echo("[dry-run] Would sync %d %s to SSP %d" % (count, entity, plan_id))


# ── Commands ──────────────────────────────────────────────────────────


@click.group()
def axonius_v2():
    """Axonius V2 Integration - Sync assets and vulnerabilities from Axonius."""


@axonius_v2.command()
@regscale_ssp_id(help="RegScale SSP ID to sync assets to.")
@click.option("--tags", "-t", default=None, type=str, help="Comma-separated Axonius tags to filter by.")
@click.option(
    "--mode",
    "-m",
    type=click.Choice(["saved-query", "hybrid"], case_sensitive=False),
    default="hybrid",
    help="Sync strategy mode.",
)
@click.option(
    "--config-file",
    "-c",
    default=None,
    type=str,
    help="Path to saved query YAML config (for saved-query mode).",
)
@_pagination_options
def sync_assets(
    regscale_ssp_id: int, tags: str, mode: str, config_file: str, offset: int, limit: int, dry_run: bool
) -> None:
    """Sync assets from Axonius into RegScale."""
    from regscale.integrations.commercial.axoniusv2.scanner import AxoniusV2ScannerIntegration

    scanner = AxoniusV2ScannerIntegration(plan_id=regscale_ssp_id)
    sync_kwargs = {"tags": tags, "mode": mode, "config_file": config_file, "offset": offset, "limit": limit}

    if dry_run:
        _dry_run_sync(scanner, regscale_ssp_id, "assets", **sync_kwargs)
    else:
        scanner.sync_assets(plan_id=regscale_ssp_id, **sync_kwargs)


@axonius_v2.command()
@regscale_ssp_id(help="RegScale SSP ID to sync vulnerabilities to.")
@click.option("--tags", "-t", default=None, type=str, help="Comma-separated Axonius tags to filter by.")
@click.option(
    "--mode",
    "-m",
    type=click.Choice(["saved-query", "hybrid"], case_sensitive=False),
    default="hybrid",
    help="Sync strategy mode.",
)
@click.option(
    "--config-file",
    "-c",
    default=None,
    type=str,
    help="Path to saved query YAML config (for saved-query mode).",
)
@_pagination_options
def sync_vulnerabilities(
    regscale_ssp_id: int, tags: str, mode: str, config_file: str, offset: int, limit: int, dry_run: bool
) -> None:
    """Sync vulnerabilities from Axonius into RegScale."""
    from regscale.integrations.commercial.axoniusv2.scanner import AxoniusV2ScannerIntegration

    scanner = AxoniusV2ScannerIntegration(plan_id=regscale_ssp_id)
    sync_kwargs = {"tags": tags, "mode": mode, "config_file": config_file, "offset": offset, "limit": limit}

    if dry_run:
        _dry_run_sync(scanner, regscale_ssp_id, "findings", **sync_kwargs)
    else:
        scanner.sync_findings(plan_id=regscale_ssp_id, **sync_kwargs)


@axonius_v2.command()
@regscale_ssp_id(help="RegScale SSP ID to sync to.")
@click.option("--tags", "-t", default=None, type=str, help="Comma-separated Axonius tags to filter by.")
@click.option(
    "--mode",
    "-m",
    type=click.Choice(["saved-query", "hybrid"], case_sensitive=False),
    default="hybrid",
    help="Sync strategy mode.",
)
@click.option("--config-file", "-c", default=None, type=str, help="Path to saved query YAML config.")
@_pagination_options
def sync_all(
    regscale_ssp_id: int, tags: str, mode: str, config_file: str, offset: int, limit: int, dry_run: bool
) -> None:
    """Sync both assets and vulnerabilities from Axonius into RegScale."""
    from regscale.integrations.commercial.axoniusv2.scanner import AxoniusV2ScannerIntegration

    scanner = AxoniusV2ScannerIntegration(plan_id=regscale_ssp_id)
    sync_kwargs = {"tags": tags, "mode": mode, "config_file": config_file, "offset": offset, "limit": limit}

    if dry_run:
        _dry_run_sync(scanner, regscale_ssp_id, "assets", **sync_kwargs)
        _dry_run_sync(scanner, regscale_ssp_id, "findings", **sync_kwargs)
    else:
        scanner.sync_assets(plan_id=regscale_ssp_id, **sync_kwargs)
        scanner.sync_findings(plan_id=regscale_ssp_id, **sync_kwargs)


@axonius_v2.command()
def list_tags() -> None:
    """List available tags from Axonius."""
    from regscale.integrations.commercial.axoniusv2.scanner import create_client

    with create_client() as client:
        response = client.tags.list()
        for tag in response.tags:
            click.echo("%s (type=%s)" % (tag.name, tag.type or "unknown"))


@axonius_v2.command()
@click.option("--tags", "-t", default=None, type=str, help="Comma-separated tags to filter by.")
@click.option("--asset-type", "-a", default="devices", type=str, help="Asset type to count.")
def count(tags: str, asset_type: str) -> None:
    """Count matching assets in Axonius (dry run)."""
    from regscale.integrations.commercial.axoniusv2.scanner import create_client
    from regscale.integrations.commercial.axoniusv2.strategies.hybrid_delta import HybridDeltaStrategy, _parse_tags

    with create_client() as client:
        parsed_tags = _parse_tags(tags)
        query = HybridDeltaStrategy._build_tag_filter(parsed_tags)
        result = client.assets.count(asset_type, query=query)
        click.echo("Total matching assets: %d" % result)


@axonius_v2.command()
@click.option("--config-file", "-c", required=True, type=str, help="Path to saved query YAML config.")
@_pagination_options
def sync_saved_queries(config_file: str, offset: int, limit: int, dry_run: bool) -> None:
    """Sync assets and vulnerabilities using saved query configuration.

    Reads the YAML config file and syncs each query to its mapped regscaleSspId.
    """
    import yaml

    from regscale.integrations.commercial.axoniusv2.scanner import AxoniusV2ScannerIntegration

    with open(config_file) as f:
        mappings = yaml.safe_load(f)

    if not isinstance(mappings, list) or not mappings:
        click.echo("Error: config file must contain a YAML list of query mappings.", err=True)
        raise SystemExit(1)

    ssp_ids = sorted({m["regscaleSspId"] for m in mappings if "regscaleSspId" in m})
    if not ssp_ids:
        click.echo("Error: no regscaleSspId found in config file.", err=True)
        raise SystemExit(1)

    for ssp_id in ssp_ids:
        click.echo("Syncing saved queries for SSP %d" % ssp_id)
        scanner = AxoniusV2ScannerIntegration(plan_id=ssp_id)
        sync_kwargs = {"mode": "saved-query", "config_file": config_file, "offset": offset, "limit": limit}

        if dry_run:
            _dry_run_sync(scanner, ssp_id, "assets", **sync_kwargs)
            _dry_run_sync(scanner, ssp_id, "findings", **sync_kwargs)
        else:
            scanner.sync_assets(plan_id=ssp_id, **sync_kwargs)
            scanner.sync_findings(plan_id=ssp_id, **sync_kwargs)
