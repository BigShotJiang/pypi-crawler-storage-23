"""Hybrid Delta Sync strategy for Axonius V2."""

import logging
from collections.abc import Iterator

from regscale.integrations.commercial.axoniusv2.constants import DEFAULT_PAGE_SIZE
from regscale.integrations.commercial.axoniusv2.mappers.asset_mapper import map_device_to_integration_asset
from regscale.integrations.commercial.axoniusv2.mappers.finding_mapper import map_vuln_to_integration_finding
from regscale.integrations.commercial.axoniusv2.sdk.models.assets import MAX_TAG_LENGTH
from regscale.integrations.commercial.axoniusv2.state import SyncStateManager
from regscale.integrations.commercial.axoniusv2.strategies.base import BaseSyncStrategy
from regscale.integrations.scanner.models.integration_asset import IntegrationAsset
from regscale.integrations.scanner.models.integration_finding import IntegrationFinding

logger = logging.getLogger("regscale")


def _escape_aql_string(value: str) -> str:
    """Escape special characters for AQL string literals."""
    if not isinstance(value, str):
        raise ValueError("AQL values must be strings")
    escaped = value.replace("\\", "\\\\").replace('"', '\\"')
    if any(ord(c) < 32 for c in escaped):
        raise ValueError("Control characters not allowed in AQL values")
    return escaped


class HybridDeltaStrategy(BaseSyncStrategy):
    """Sync strategy with full bulk + incremental delta support."""

    def __init__(self, state_manager: SyncStateManager):
        self._state_manager = state_manager

    def _should_do_full_sync(self, ssp_id: int) -> bool:
        """Check if a full sync is needed (no previous sync recorded)."""
        return self._state_manager.get_last_sync(ssp_id) is None

    @staticmethod
    def _build_tag_filter(tags: list[str]) -> str:
        """Build AQL filter for tags with proper escaping."""
        if not tags:
            return ""
        tag_list = ", ".join('"%s"' % _escape_aql_string(t) for t in tags)
        return '("specific_data.data.tags" in [%s])' % tag_list

    @staticmethod
    def _build_delta_filter(last_sync: str, tags: list[str]) -> str:
        """Build AQL filter combining date and optional tag filters."""
        date_filter = '("specific_data.data.last_seen" >= date("%s"))' % _escape_aql_string(last_sync)
        tag_filter = HybridDeltaStrategy._build_tag_filter(tags)
        if tag_filter:
            return "%s and %s" % (date_filter, tag_filter)
        return date_filter

    def iter_assets(self, client, plan_id: int, **kwargs) -> Iterator[IntegrationAsset]:
        """Iterate over assets with full or incremental sync."""
        tags = _parse_tags(kwargs.get("tags"))
        page_size = kwargs.get("page_size", DEFAULT_PAGE_SIZE)
        is_full = self._should_do_full_sync(plan_id)

        if is_full:
            logger.info("Performing full asset sync for SSP %d", plan_id)
            query = self._build_tag_filter(tags)
        else:
            last_sync = self._state_manager.get_last_sync(plan_id)
            logger.info("Performing incremental asset sync for SSP %d since %s", plan_id, last_sync)
            query = self._build_delta_filter(last_sync, tags)

        for device in client.assets.iter_all("devices", query=query, page_size=page_size):
            yield map_device_to_integration_asset(device, plan_id)

        self._state_manager.update_last_sync(plan_id)

    def iter_findings(self, client, plan_id: int, **kwargs) -> Iterator[IntegrationFinding]:
        """Iterate over findings with full or incremental sync."""
        tags = _parse_tags(kwargs.get("tags"))
        page_size = kwargs.get("page_size", DEFAULT_PAGE_SIZE)
        is_full = self._should_do_full_sync(plan_id)

        if is_full:
            logger.info("Performing full finding sync for SSP %d", plan_id)
            query = self._build_tag_filter(tags)
        else:
            last_sync = self._state_manager.get_last_sync(plan_id)
            logger.info("Performing incremental finding sync for SSP %d since %s", plan_id, last_sync)
            query = self._build_delta_filter(last_sync, tags)

        for vuln in client.assets.iter_all("vulnerabilities", query=query, page_size=page_size):
            yield map_vuln_to_integration_finding(vuln)

        self._state_manager.update_last_sync(plan_id)


def _parse_tags(tags_value) -> list[str]:
    """Parse tags from comma-separated string or list with validation."""
    if not tags_value:
        return []
    if isinstance(tags_value, list):
        parsed = tags_value
    else:
        parsed = [t.strip() for t in tags_value.split(",") if t.strip()]
    for tag in parsed:
        if len(tag) > MAX_TAG_LENGTH:
            raise ValueError("Tag exceeds maximum length of %d characters" % MAX_TAG_LENGTH)
    return parsed
