"""Saved Query Bridge strategy for Axonius V2."""

import logging
from collections.abc import Iterator
from typing import Any, Optional

import yaml

from regscale.integrations.commercial.axoniusv2.constants import DEFAULT_PAGE_SIZE
from regscale.integrations.commercial.axoniusv2.mappers.asset_mapper import map_device_to_integration_asset
from regscale.integrations.commercial.axoniusv2.mappers.finding_mapper import map_vuln_to_integration_finding
from regscale.integrations.commercial.axoniusv2.strategies.base import BaseSyncStrategy
from regscale.integrations.scanner.models.integration_asset import IntegrationAsset
from regscale.integrations.scanner.models.integration_finding import IntegrationFinding

logger = logging.getLogger("regscale")


class SavedQueryStrategy(BaseSyncStrategy):
    """Sync strategy using Axonius saved queries.

    Accepts either:
    - ``config_path``: path to a YAML file containing a list of query mappings
    - ``config_dict``: an inline dict from init.yaml ``axonius.savedQueryConfig``

    When *config_dict* is provided, it is normalised to a single-element list so
    the rest of the pipeline works identically.
    """

    REQUIRED_FIELDS = {"savedQueryName", "regscaleSspId"}

    def __init__(
        self,
        config_path: Optional[str] = None,
        config_dict: Optional[dict[str, Any]] = None,
    ):
        if config_path:
            self._mappings = self._load_config(config_path)
        elif config_dict:
            self._mappings = self._normalise_dict(config_dict)
        else:
            self._mappings = []

    # ------------------------------------------------------------------
    # Config loaders
    # ------------------------------------------------------------------

    def _load_config(self, config_path: str) -> list[dict[str, Any]]:
        """Load and validate YAML config."""
        with open(config_path) as f:
            data = yaml.safe_load(f)
        if not isinstance(data, list):
            raise ValueError("Saved query config must be a YAML list of mappings")
        for i, mapping in enumerate(data):
            missing = self.REQUIRED_FIELDS - set(mapping.keys())
            if missing:
                raise ValueError("Mapping at index %d missing required fields: %s" % (i, ", ".join(sorted(missing))))
        return data

    @staticmethod
    def _normalise_dict(config_dict: dict[str, Any]) -> list[dict[str, Any]]:
        """Normalise an init.yaml savedQueryConfig dict to a list of mappings.

        The dict must contain ``queryName``.  ``regscaleSspId`` is optional here
        because the plan_id is supplied at runtime via iter_assets / iter_findings.

        :param config_dict: The savedQueryConfig dict from init.yaml.
        :return: A list with a single mapping.
        :rtype: list[dict[str, Any]]
        """
        query_name = config_dict.get("queryName")
        if not query_name:
            logger.warning("savedQueryConfig.queryName is empty — no queries to run")
            return []
        return [
            {
                "savedQueryName": query_name,
                "queryDescription": config_dict.get("queryDescription", ""),
            }
        ]

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _get_mappings_for_ssp(self, plan_id: int) -> list[dict[str, Any]]:
        """Filter mappings for a specific SSP ID.

        Mappings from init.yaml dicts have no ``regscaleSspId`` field, so they
        match *any* plan_id.
        """
        return [m for m in self._mappings if m.get("regscaleSspId", plan_id) == plan_id]

    def validate_queries(self, client) -> None:
        """Validate that all configured query names exist in Axonius."""
        existing = {q.name for q in client.queries.list("devices").queries}
        configured = {m["savedQueryName"] for m in self._mappings}
        missing = configured - existing
        if missing:
            logger.warning("Saved queries not found in Axonius: %s", ", ".join(sorted(missing)))

    # ------------------------------------------------------------------
    # Iteration
    # ------------------------------------------------------------------

    def iter_assets(self, client, plan_id: int, **kwargs) -> Iterator[IntegrationAsset]:
        """Iterate over assets using saved queries for the given SSP."""
        mappings = self._get_mappings_for_ssp(plan_id)
        if not mappings:
            logger.warning("No saved query mappings found for SSP %d", plan_id)
            return

        page_size = kwargs.get("page_size", DEFAULT_PAGE_SIZE)
        for mapping in mappings:
            query_name = mapping["savedQueryName"]
            logger.info("Fetching assets via saved query: %s", query_name)
            query_filter = '("saved_query_name" == "%s")' % query_name
            for device in client.assets.iter_all("devices", query=query_filter, page_size=page_size):
                yield map_device_to_integration_asset(device, plan_id)

    def iter_findings(self, client, plan_id: int, **kwargs) -> Iterator[IntegrationFinding]:
        """Iterate over findings using saved queries for the given SSP."""
        mappings = self._get_mappings_for_ssp(plan_id)
        if not mappings:
            logger.warning("No saved query mappings found for SSP %d", plan_id)
            return

        page_size = kwargs.get("page_size", DEFAULT_PAGE_SIZE)
        for mapping in mappings:
            query_name = mapping["savedQueryName"]
            logger.info("Fetching vulnerabilities via saved query: %s", query_name)
            query_filter = '("saved_query_name" == "%s")' % query_name
            for vuln in client.assets.iter_all("vulnerabilities", query=query_filter, page_size=page_size):
                yield map_vuln_to_integration_finding(vuln)
