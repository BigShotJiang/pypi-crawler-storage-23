#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Axonius V2 constants: field paths, severity maps, and CVSS thresholds."""

from regscale.models.regscale_models.issue import IssueSeverity

# ---------------------------------------------------------------------------
# Axonius asset field dot-paths for Asset.get_field()
# ---------------------------------------------------------------------------
AXONIUS_FIELD_HOSTNAME = "specific_data.data.hostname"
AXONIUS_FIELD_HOSTNAME_PREFERRED = "specific_data.data.hostname_preferred"
AXONIUS_FIELD_NETWORK_INTERFACES_IPS = "specific_data.data.network_interfaces.ips"
AXONIUS_FIELD_NETWORK_INTERFACES_IPS_V6 = "specific_data.data.network_interfaces.ips_v6"
AXONIUS_FIELD_NETWORK_INTERFACES_MAC = "specific_data.data.network_interfaces.mac"
AXONIUS_FIELD_OS_TYPE = "specific_data.data.os.type"
AXONIUS_FIELD_OS_STR = "specific_data.data.os.os_str"
AXONIUS_FIELD_SERIAL_NUMBER = "specific_data.data.serial_number"
AXONIUS_FIELD_AWS_DEVICE_TYPE = "specific_data.data.aws_device_type"
AXONIUS_FIELD_AZURE_DEVICE_ID = "specific_data.data.azure_device_id"
AXONIUS_FIELD_GCP_PROJECT_ID = "specific_data.data.gcp_project_id"

# ---------------------------------------------------------------------------
# Axonius vulnerability field dot-paths
# ---------------------------------------------------------------------------
AXONIUS_FIELD_CVE_ID = "specific_data.data.cve_id"
AXONIUS_FIELD_SEVERITY = "specific_data.data.severity"
AXONIUS_FIELD_TITLE = "specific_data.data.title"
AXONIUS_FIELD_DESCRIPTION = "specific_data.data.description"
AXONIUS_FIELD_SOLUTION = "specific_data.data.solution"
AXONIUS_FIELD_CVSS_SCORE = "specific_data.data.cvss_score"
AXONIUS_FIELD_CVSS_V2_SCORE = "specific_data.data.cvss_v2_score"
AXONIUS_FIELD_FIRST_SEEN = "specific_data.data.first_seen"
AXONIUS_FIELD_LAST_SEEN = "specific_data.data.last_seen"
AXONIUS_FIELD_ASSOCIATED_DEVICE_ID = "specific_data.data.associated_device_id"
AXONIUS_FIELD_PLUGIN_ID = "specific_data.data.plugin_id"
AXONIUS_FIELD_PLUGIN_NAME = "specific_data.data.plugin_name"

# ---------------------------------------------------------------------------
# Severity mapping: Axonius lowercase string -> RegScale IssueSeverity
# ---------------------------------------------------------------------------
SEVERITY_MAP = {
    "critical": IssueSeverity.Critical,
    "high": IssueSeverity.High,
    "medium": IssueSeverity.Moderate,
    "low": IssueSeverity.Low,
    "info": IssueSeverity.NotAssigned,
    "none": IssueSeverity.NotAssigned,
    "informational": IssueSeverity.NotAssigned,
}

# ---------------------------------------------------------------------------
# CVSS v3 score thresholds for severity fallback (min, max, severity)
# ---------------------------------------------------------------------------
CVSS_SEVERITY_THRESHOLDS = [
    (9.0, 10.0, IssueSeverity.Critical),
    (7.0, 8.9, IssueSeverity.High),
    (4.0, 6.9, IssueSeverity.Moderate),
    (0.1, 3.9, IssueSeverity.Low),
    (0.0, 0.0, IssueSeverity.NotAssigned),
]

DEFAULT_PAGE_SIZE = 2000
SCANNING_TOOL_NAME = "Axonius"
