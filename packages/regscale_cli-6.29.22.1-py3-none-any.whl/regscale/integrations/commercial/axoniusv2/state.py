#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Sync state persistence for the Axonius V2 integration."""

import json
import logging
import os
from datetime import datetime, timezone
from typing import Optional

logger = logging.getLogger("regscale")


class SyncStateManager:
    """Manages sync state persistence for Axonius V2 integration.

    Stores per-SSP last-sync timestamps in a JSON file so that subsequent
    syncs can request only data that has changed since the previous run.
    """

    STATE_FILE_NAME = "axonius_v2_last_sync.json"

    def __init__(self, state_dir: str) -> None:
        self._state_dir = state_dir
        self._state_file = os.path.join(state_dir, self.STATE_FILE_NAME)
        os.makedirs(state_dir, exist_ok=True)

    def _load_state(self) -> dict:
        """Load the state dictionary from disk.

        :return: The persisted state or an empty dict on error / missing file.
        :rtype: dict
        """
        if not os.path.exists(self._state_file):
            return {}
        try:
            with open(self._state_file) as f:
                return json.load(f)
        except (json.JSONDecodeError, OSError):
            logger.warning("Corrupt state file, resetting state")
            return {}

    def _save_state(self, state: dict) -> None:
        """Persist the state dictionary to disk.

        :param dict state: The state dictionary to save.
        """
        with open(self._state_file, "w") as f:
            json.dump(state, f, indent=2)

    def get_last_sync(self, ssp_id: int) -> Optional[str]:
        """Return the ISO-8601 timestamp of the last sync for *ssp_id*, or ``None``.

        :param int ssp_id: The SSP plan identifier.
        :return: ISO-8601 datetime string or None.
        :rtype: Optional[str]
        """
        state = self._load_state()
        return state.get(str(ssp_id))

    def update_last_sync(self, ssp_id: int) -> None:
        """Record the current UTC time as the last sync for *ssp_id*.

        :param int ssp_id: The SSP plan identifier.
        """
        state = self._load_state()
        state[str(ssp_id)] = datetime.now(timezone.utc).isoformat()
        self._save_state(state)

    def clear_state(self, ssp_id: int) -> None:
        """Remove the persisted sync timestamp for *ssp_id*.

        :param int ssp_id: The SSP plan identifier.
        """
        state = self._load_state()
        state.pop(str(ssp_id), None)
        self._save_state(state)
