"""AxoniusV2 Scanner Integration for RegScale."""

import logging
from collections.abc import Iterator
from itertools import islice

from regscale.integrations.commercial.axoniusv2.constants import SEVERITY_MAP
from regscale.integrations.commercial.axoniusv2.sdk.exceptions import (
    AuthenticationError,
    ConnectionError as AxoniusConnectionError,
)
from regscale.integrations.scanner_integration import (
    IntegrationAsset,
    IntegrationFinding,
    ScannerIntegration,
)

logger = logging.getLogger("regscale")


def _apply_pagination(stream: Iterator, offset: int, limit: int | None) -> Iterator:
    """Apply offset/limit pagination to an iterator.

    :param stream: The source iterator.
    :param int offset: Number of records to skip.
    :param limit: Maximum number of records to yield, or None for unlimited.
    :return: A sliced iterator.
    :rtype: Iterator
    """
    if offset:
        stream = islice(stream, offset, None)
    if limit:
        stream = islice(stream, limit)
    return stream


_PLACEHOLDER_VALUES = {"YOUR_AXONIUS_HOST", "YOUR_AXONIUS_V2_API_KEY", "YOUR_AXONIUS_V2_API_SECRET"}


def create_client(**kwargs):
    """Create an Axonius API client.

    Resolves credentials: CLI kwarg > init.yaml nested config.

    :param kwargs: Optional overrides for host, api_key, api_secret.
    :return: An AxoniusClient instance.
    :raises click.ClickException: If host or credentials are not configured.
    """
    import click

    from regscale.integrations.commercial.axoniusv2.sdk import AxoniusClient
    from regscale.integrations.commercial.axoniusv2.variables import get_axonius_config

    cfg = get_axonius_config()
    host = kwargs.get("host") or cfg["host"]
    api_key = kwargs.get("api_key") or cfg["apiKey"]
    api_secret = kwargs.get("api_secret") or cfg["apiSecret"]
    verify_ssl = cfg.get("verifySsl", True)
    timeout = cfg.get("timeout", 30)

    if not host or host in _PLACEHOLDER_VALUES:
        msg = "Axonius host is not configured. Set 'axonius.host' in init.yaml to your Axonius instance URL."
        logger.error(msg)
        raise click.ClickException(msg)
    if not api_key or api_key in _PLACEHOLDER_VALUES:
        msg = "Axonius API key is not configured. Set 'axonius.apiKey' in init.yaml."
        logger.error(msg)
        raise click.ClickException(msg)
    if not api_secret or api_secret in _PLACEHOLDER_VALUES:
        msg = "Axonius API secret is not configured. Set 'axonius.apiSecret' in init.yaml."
        logger.error(msg)
        raise click.ClickException(msg)

    return AxoniusClient(
        host=host,
        api_key=api_key,
        api_secret=api_secret,
        verify_ssl=verify_ssl,
        timeout=float(timeout),
    )


class AxoniusV2ScannerIntegration(ScannerIntegration):
    """Integration class for Axonius V2 vulnerability and asset scanning."""

    title = "Axonius"
    asset_identifier_field = "otherTrackingNumber"
    finding_severity_map = SEVERITY_MAP

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._client = None
        self._strategy = None

    @property
    def client(self):
        """Lazy-initialized Axonius API client with connection validation."""
        if self._client is None:
            self._client = create_client()
            self.validate_connection()
        return self._client

    def validate_connection(self) -> None:
        """Validate credentials by making a lightweight API call.

        :raises click.ClickException: If authentication fails or host is unreachable.
        """
        import click

        try:
            self._client.assets.count("devices")
            logger.info("Axonius connection validated successfully")
        except AuthenticationError:
            msg = (
                "Axonius authentication failed — check 'axonius.host', 'axonius.apiKey', "
                "and 'axonius.apiSecret' in init.yaml."
            )
            logger.error(msg)
            raise click.ClickException(msg)
        except AxoniusConnectionError:
            from regscale.integrations.commercial.axoniusv2.variables import get_axonius_config

            host = get_axonius_config().get("host", "unknown")
            msg = (
                "Cannot reach Axonius at '%s'. Verify 'axonius.host' in init.yaml is correct "
                "and the host is reachable from this network." % host
            )
            logger.error(msg)
            raise click.ClickException(msg)

    def close(self) -> None:
        """Close the Axonius client and release resources."""
        if self._client is not None:
            self._client.close()
            self._client = None

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()

    def close_outdated_vulnerabilities(self, current_vulnerabilities: dict) -> int:
        """Skip — the batch API mopup handles closures server-side."""
        return 0

    def close_outdated_issues(self, current_vulnerabilities: dict) -> int:
        """Skip — the batch API mopup handles closures server-side."""
        return 0

    def fetch_assets(self, *args, **kwargs) -> Iterator[IntegrationAsset]:
        """Fetch assets from Axonius via the configured strategy.

        Supports ``offset`` and ``limit`` kwargs for orchestrator pagination.

        :param kwargs: Strategy-specific keyword arguments including 'mode'.
        :return: An iterator of IntegrationAsset objects.
        :rtype: Iterator[IntegrationAsset]
        """
        mode = kwargs.pop("mode", "hybrid")
        kwargs.pop("plan_id", None)
        offset = kwargs.pop("offset", 0) or 0
        limit = kwargs.pop("limit", None)
        strategy = self._get_strategy(mode, **kwargs)
        stream = strategy.iter_assets(client=self.client, plan_id=self.plan_id, **kwargs)
        yield from _apply_pagination(stream, offset, limit)

    def fetch_findings(self, *args, **kwargs) -> Iterator[IntegrationFinding]:
        """Fetch findings from Axonius via the configured strategy.

        Supports ``offset`` and ``limit`` kwargs for orchestrator pagination.

        :param kwargs: Strategy-specific keyword arguments including 'mode'.
        :return: An iterator of IntegrationFinding objects.
        :rtype: Iterator[IntegrationFinding]
        """
        mode = kwargs.pop("mode", "hybrid")
        kwargs.pop("plan_id", None)
        offset = kwargs.pop("offset", 0) or 0
        limit = kwargs.pop("limit", None)
        strategy = self._get_strategy(mode, **kwargs)
        stream = strategy.iter_findings(client=self.client, plan_id=self.plan_id, **kwargs)
        yield from _apply_pagination(stream, offset, limit)

    def _get_strategy(self, mode: str, **kwargs):
        """Create or return a sync strategy based on mode.

        :param str mode: The sync mode ('hybrid' or 'saved-query').
        :param kwargs: Additional keyword arguments for strategy creation.
        :return: A sync strategy instance.
        """
        from regscale.integrations.commercial.axoniusv2.strategies.hybrid_delta import HybridDeltaStrategy
        from regscale.integrations.commercial.axoniusv2.strategies.saved_query import SavedQueryStrategy
        from regscale.integrations.commercial.axoniusv2.state import SyncStateManager
        from regscale.integrations.commercial.axoniusv2.variables import get_axonius_config

        cfg = get_axonius_config()

        if mode == "saved-query":
            config_file = kwargs.get("config_file")
            if config_file:
                return SavedQueryStrategy(config_path=config_file)
            saved_query_cfg = cfg.get("savedQueryConfig", {})
            return SavedQueryStrategy(config_dict=saved_query_cfg)

        state_dir = kwargs.get("state_dir") or cfg["stateDir"]
        state_manager = SyncStateManager(state_dir=state_dir)
        return HybridDeltaStrategy(state_manager=state_manager)
