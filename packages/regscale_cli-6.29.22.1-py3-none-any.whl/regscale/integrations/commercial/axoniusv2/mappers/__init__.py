"""Axonius data mappers for converting API responses to RegScale integration models."""
