"""Finding mapper for converting Axonius vulnerabilities to RegScale IntegrationFinding."""

import logging
from typing import Optional

from regscale.integrations.scanner.models.integration_finding import IntegrationFinding
from regscale.models.regscale_models.issue import IssueSeverity, IssueStatus

from regscale.integrations.commercial.axoniusv2.constants import (
    AXONIUS_FIELD_CVE_ID,
    AXONIUS_FIELD_SEVERITY,
    AXONIUS_FIELD_TITLE,
    AXONIUS_FIELD_DESCRIPTION,
    AXONIUS_FIELD_SOLUTION,
    AXONIUS_FIELD_CVSS_SCORE,
    AXONIUS_FIELD_CVSS_V2_SCORE,
    AXONIUS_FIELD_FIRST_SEEN,
    AXONIUS_FIELD_LAST_SEEN,
    AXONIUS_FIELD_ASSOCIATED_DEVICE_ID,
    AXONIUS_FIELD_PLUGIN_ID,
    AXONIUS_FIELD_PLUGIN_NAME,
    SCANNING_TOOL_NAME,
    SEVERITY_MAP,
    CVSS_SEVERITY_THRESHOLDS,
)

logger = logging.getLogger("regscale")


def map_vuln_to_integration_finding(vuln) -> IntegrationFinding:
    """Map an Axonius vulnerability to an IntegrationFinding.

    :param vuln: An Axonius SDK vulnerability object.
    :return: A populated IntegrationFinding.
    :rtype: IntegrationFinding
    """
    title = vuln.get_field(AXONIUS_FIELD_TITLE, default="") or "Unknown Vulnerability"
    description = vuln.get_field(AXONIUS_FIELD_DESCRIPTION, default="") or "No description provided"
    severity = _resolve_severity(vuln)
    plugin_name = vuln.get_field(AXONIUS_FIELD_PLUGIN_NAME, default="") or SCANNING_TOOL_NAME

    first_seen = vuln.get_field(AXONIUS_FIELD_FIRST_SEEN, default="") or ""
    last_seen = vuln.get_field(AXONIUS_FIELD_LAST_SEEN, default="") or ""
    # Ensure first_seen <= last_seen to avoid API validation errors
    if first_seen and last_seen and first_seen > last_seen:
        first_seen, last_seen = last_seen, first_seen

    return IntegrationFinding(
        control_labels=[],
        title=title,
        category="Vulnerability",
        severity=severity,
        description=description,
        status=IssueStatus.Open,
        external_id=vuln.internal_axon_id,
        cve=vuln.get_field(AXONIUS_FIELD_CVE_ID) or None,
        cvss_v3_score=_safe_float(vuln.get_field(AXONIUS_FIELD_CVSS_SCORE)),
        cvss_v2_score=_safe_float(vuln.get_field(AXONIUS_FIELD_CVSS_V2_SCORE)),
        first_seen=first_seen,
        last_seen=last_seen,
        asset_identifier=vuln.get_field(AXONIUS_FIELD_ASSOCIATED_DEVICE_ID, default="") or "",
        plugin_id=vuln.get_field(AXONIUS_FIELD_PLUGIN_ID) or None,
        plugin_name=plugin_name,
        remediation=vuln.get_field(AXONIUS_FIELD_SOLUTION) or None,
    )


def _resolve_severity(vuln) -> IssueSeverity:
    """Resolve severity from Axonius string or CVSS score fallback.

    :param vuln: An Axonius SDK vulnerability object.
    :return: The resolved IssueSeverity.
    :rtype: IssueSeverity
    """
    severity_str = vuln.get_field(AXONIUS_FIELD_SEVERITY, default="") or ""
    if severity_str:
        mapped = SEVERITY_MAP.get(severity_str.lower())
        if mapped is not None:
            return mapped

    # Fallback to CVSS v3 score
    cvss_score = _safe_float(vuln.get_field(AXONIUS_FIELD_CVSS_SCORE))
    if cvss_score is not None:
        return _severity_from_cvss(cvss_score)

    return IssueSeverity.NotAssigned


def _severity_from_cvss(score: float) -> IssueSeverity:
    """Determine severity from CVSS score using thresholds.

    :param float score: The CVSS v3 score.
    :return: The corresponding IssueSeverity.
    :rtype: IssueSeverity
    """
    for min_score, max_score, severity in CVSS_SEVERITY_THRESHOLDS:
        if min_score <= score <= max_score:
            return severity
    return IssueSeverity.NotAssigned


def _safe_float(value) -> Optional[float]:
    """Safely convert a value to float.

    :param value: The value to convert.
    :return: The float value, or None if conversion fails.
    :rtype: Optional[float]
    """
    if value is None:
        return None
    try:
        return float(value)
    except (ValueError, TypeError):
        return None
