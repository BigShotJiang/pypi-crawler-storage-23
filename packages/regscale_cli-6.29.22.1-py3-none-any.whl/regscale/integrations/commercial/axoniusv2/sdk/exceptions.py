"""Custom exceptions for the Axonious SDK."""

from __future__ import annotations

from typing import Any


class AxoniusError(Exception):
    """Base exception for all Axonius SDK errors."""

    def __init__(self, message: str, details: dict[str, Any] | None = None) -> None:
        super().__init__(message)
        self.message = message
        self.details = details or {}


class AuthenticationError(AxoniusError):
    """Raised when authentication fails."""


class APIError(AxoniusError):
    """Raised when the API returns an error response."""

    def __init__(
        self,
        message: str,
        status_code: int,
        error_id: str | None = None,
        errors: list[dict[str, str]] | None = None,
    ) -> None:
        super().__init__(message, {"status_code": status_code, "error_id": error_id})
        self.status_code = status_code
        self.error_id = error_id
        self.errors = errors or []


class BadRequestError(APIError):
    """Raised for 400 Bad Request responses."""


class NotFoundError(APIError):
    """Raised for 404 Not Found responses."""


class ValidationError(APIError):
    """Raised for 422 Validation Error responses."""


class RateLimitError(APIError):
    """Raised when rate limit is exceeded."""

    def __init__(self, message, status_code, error_id=None, errors=None, retry_after=None):
        super().__init__(message, status_code, error_id, errors)
        self.retry_after = retry_after


class ServerError(APIError):
    """Raised for 5xx server errors."""


class ConnectionError(AxoniusError):
    """Raised when connection to the server fails."""


class TimeoutError(AxoniusError):
    """Raised when a request times out."""
