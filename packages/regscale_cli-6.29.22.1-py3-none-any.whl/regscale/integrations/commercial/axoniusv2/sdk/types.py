"""Type definitions for the Axonious SDK."""

from __future__ import annotations

import sys

if sys.version_info >= (3, 11):
    from enum import StrEnum
else:
    from enum import Enum

    class StrEnum(str, Enum):
        """Backport of StrEnum for Python < 3.11."""


from typing import Literal, TypeAlias

# Asset types supported by the Axonius API
AssetType: TypeAlias = Literal[
    "devices",
    "saas_applications",
    "business_applications",
    "discovered_saas_applications",
    "users",
    "resources",
    "vulnerabilities_repository",
    "vulnerabilities",
    "manual_software",
    "software",
    "object_storages",
    "managed_users",
    "extensions",
    "security_roles",
    "groups",
    "licenses",
    "networks",
    "expenses",
    "application_settings",
    "user_extensions",
    "admin_managed_extension_instances",
    "admin_managed_extensions",
    "application_addon_instances",
    "application_addons",
    "user_initiated_extension_instances",
    "user_initiated_extensions",
    "application_keys",
    "nat_rules",
    "audit_activities",
    "tickets",
    "file_systems",
    "load_balancers",
    "databases",
    "containers",
    "accounts",
    "serverless_functions",
    "disks",
    "compute_images",
    "secrets",
    "certificates",
    "firewalls",
    "network_services",
    "network_devices",
    "incidents",
    "compute_services",
    "application_services",
    "permissions",
    "application_resources",
    "repositories",
    "urls",
    "organizational_units",
    "configurations",
    "job_titles",
    "latest_rules",
    "vulnerability_instances",
    "profiles",
    "alert_findings",
    "network_routes",
    "cases",
    "access_review_campaign_instances",
    "access_review_approval_items",
    "global_variables",
]


class AuditCategory(StrEnum):
    """Categories for activity log filtering."""

    SETTINGS_MANAGEMENT = "Settings Management"
    MAINTENANCE_MANAGEMENT = "Maintenance Management"
    USER_MANAGEMENT = "User Management"
    ACTIVITY_LOGS = "Activity Logs"
    ROLE_MANAGEMENT = "Role Management"
    ADMINISTRATION = "Administration"
    SERVICE_ACCOUNT = "Service Account"
    ACCESS_REQUESTS = "Axonius Access Requests"
    CENTRAL_CORE = "Central Core"
    TAG_MANAGEMENT = "Tag Management"
    CUSTOM_FIELDS = "Custom Fields Management"
    CUSTOM_ENRICHMENT = "Custom Enrichment Management"
    WEBHOOK_MANAGEMENT = "Webhook Management"
    USER_SESSION = "User Session"
    DISCOVERY = "Discovery"
    CUSTOM_DISCOVERY = "Custom Discovery"
    CORRELATION = "Correlation"
    HISTORICAL_SNAPSHOT = "Historical Snapshot"
    ADAPTERS = "Adapters"
    REPORTS = "Reports"
    ENFORCEMENTS = "Enforcements"
    CASE_MANAGEMENT = "Case Management"
    FIELD_MAPPING = "Field Mapping"
    WORKFLOWS = "Workflows"
    WORKFLOW_RUNS = "Workflow Runs"
    ENFORCEMENTS_TASKS = "Enforcements Tasks"
    GATEWAY = "Gateway"
    DASHBOARD = "Dashboard"
    COMPUTE_NODES = "Compute Nodes"
    CHARTS = "Charts"
    CLOUD_ASSET_COMPLIANCE = "Cloud Asset Compliance"
    BACKUP = "Backup"
    DEVICES = "Devices"
    USERS = "Users"
    VULNERABILITIES = "Vulnerabilities"
    SOFTWARE = "Software"
    DEVICE_SAVED_QUERIES = "Device Saved Queries"
    USER_SAVED_QUERIES = "User Saved Queries"


class DiscoveryStatus(StrEnum):
    """Discovery lifecycle status."""

    RUNNING = "running"
    STOPPED = "stopped"
    STOPPING = "stopping"
    STARTING = "starting"


class SortDirection(StrEnum):
    """Sort direction for queries."""

    ASC = "asc"
    DESC = "desc"
