"""Base API resource class."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, TypeVar

from pydantic import BaseModel

if TYPE_CHECKING:
    from ..transport import HTTPTransport

T = TypeVar("T", bound=BaseModel)


class BaseAPI:
    """Base class for API resources."""

    def __init__(self, transport: HTTPTransport) -> None:
        self._transport = transport

    def _get(
        self,
        path: str,
        params: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Make a GET request."""
        return self._transport.request("GET", path, params=params)

    async def _aget(
        self,
        path: str,
        params: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Make an async GET request."""
        return await self._transport.arequest("GET", path, params=params)

    def _post(
        self,
        path: str,
        data: dict[str, Any] | None = None,
        params: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Make a POST request."""
        return self._transport.request("POST", path, json=data, params=params)

    async def _apost(
        self,
        path: str,
        data: dict[str, Any] | None = None,
        params: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Make an async POST request."""
        return await self._transport.arequest("POST", path, json=data, params=params)

    def _put(
        self,
        path: str,
        data: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Make a PUT request."""
        return self._transport.request("PUT", path, json=data)

    async def _aput(
        self,
        path: str,
        data: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Make an async PUT request."""
        return await self._transport.arequest("PUT", path, json=data)

    def _patch(
        self,
        path: str,
        data: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Make a PATCH request."""
        return self._transport.request("PATCH", path, json=data)

    async def _apatch(
        self,
        path: str,
        data: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Make an async PATCH request."""
        return await self._transport.arequest("PATCH", path, json=data)

    def _delete(
        self,
        path: str,
    ) -> dict[str, Any]:
        """Make a DELETE request."""
        return self._transport.request("DELETE", path)

    async def _adelete(
        self,
        path: str,
    ) -> dict[str, Any]:
        """Make an async DELETE request."""
        return await self._transport.arequest("DELETE", path)
