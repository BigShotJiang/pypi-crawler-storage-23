"""Tags API implementation."""

from __future__ import annotations

from .base import BaseAPI
from ..models.tags import TagsResponse


class TagsAPI(BaseAPI):
    """API for managing Axonius tags."""

    def list(self) -> TagsResponse:
        """List all tags.

        Returns:
            TagsResponse containing list of tags
        """
        data = self._get("/v2/tags")
        return TagsResponse.model_validate(data)

    async def alist(self) -> TagsResponse:
        """Async version of list()."""
        data = await self._aget("/v2/tags")
        return TagsResponse.model_validate(data)
