"""Discovery API implementation."""

from __future__ import annotations

from .base import BaseAPI
from ..models.discovery import DiscoveryResponse, DiscoveryStatus


class DiscoveryAPI(BaseAPI):
    """API for managing discovery cycles."""

    def get_status(self) -> DiscoveryStatus:
        """Get the current discovery status.

        Returns:
            DiscoveryStatus
        """
        data = self._get("/v2/discovery")
        return DiscoveryStatus.model_validate(data)

    async def aget_status(self) -> DiscoveryStatus:
        """Async version of get_status()."""
        data = await self._aget("/v2/discovery")
        return DiscoveryStatus.model_validate(data)

    def start(self) -> DiscoveryResponse:
        """Start a discovery cycle.

        Returns:
            DiscoveryResponse
        """
        data = self._post("/v2/discovery/run")
        return DiscoveryResponse.model_validate(data)

    async def astart(self) -> DiscoveryResponse:
        """Async version of start()."""
        data = await self._apost("/v2/discovery/run")
        return DiscoveryResponse.model_validate(data)

    def stop(self) -> DiscoveryResponse:
        """Stop a running discovery cycle.

        Returns:
            DiscoveryResponse
        """
        data = self._post("/v2/discovery/stop")
        return DiscoveryResponse.model_validate(data)

    async def astop(self) -> DiscoveryResponse:
        """Async version of stop()."""
        data = await self._apost("/v2/discovery/stop")
        return DiscoveryResponse.model_validate(data)
