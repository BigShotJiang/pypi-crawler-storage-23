"""Adapters API implementation."""

from __future__ import annotations

from typing import Any

from .base import BaseAPI
from ..models.adapters import (
    AdapterConnection,
    AdapterConnectionRequest,
    AdapterFetchStatus,
    AdaptersResponse,
)


class AdaptersAPI(BaseAPI):
    """API for managing Axonius adapters."""

    def list(self) -> AdaptersResponse:
        """List all available adapters.

        Returns:
            AdaptersResponse containing list of adapters
        """
        data = self._get("/v2/adapters")
        return AdaptersResponse.model_validate(data)

    async def alist(self) -> AdaptersResponse:
        """Async version of list()."""
        data = await self._aget("/v2/adapters")
        return AdaptersResponse.model_validate(data)

    def get_connections(self, adapter_name: str) -> list[AdapterConnection]:
        """Get all connections for an adapter.

        Args:
            adapter_name: Name of the adapter

        Returns:
            List of adapter connections
        """
        data = self._get(f"/v2/adapters/{adapter_name}/connections")
        return [AdapterConnection.model_validate(c) for c in data.get("connections", [])]

    async def aget_connections(self, adapter_name: str) -> list[AdapterConnection]:
        """Async version of get_connections()."""
        data = await self._aget(f"/v2/adapters/{adapter_name}/connections")
        return [AdapterConnection.model_validate(c) for c in data.get("connections", [])]

    def get_connection(
        self,
        adapter_name: str,
        connection_id: str,
    ) -> AdapterConnection:
        """Get a specific adapter connection.

        Args:
            adapter_name: Name of the adapter
            connection_id: Connection ID

        Returns:
            AdapterConnection
        """
        data = self._get(f"/v2/adapters/{adapter_name}/connections/{connection_id}")
        return AdapterConnection.model_validate(data)

    async def aget_connection(
        self,
        adapter_name: str,
        connection_id: str,
    ) -> AdapterConnection:
        """Async version of get_connection()."""
        data = await self._aget(f"/v2/adapters/{adapter_name}/connections/{connection_id}")
        return AdapterConnection.model_validate(data)

    def create_connection(
        self,
        adapter_name: str,
        connection_config: dict[str, Any],
        *,
        connection_label: str | None = None,
        active: bool = True,
    ) -> AdapterConnection:
        """Create a new adapter connection.

        Args:
            adapter_name: Name of the adapter
            connection_config: Connection configuration
            connection_label: Optional label for the connection
            active: Whether the connection is active

        Returns:
            Created AdapterConnection
        """
        request = AdapterConnectionRequest(
            connection_label=connection_label,
            active=active,
            connection_config=connection_config,
        )

        data = self._post(
            f"/v2/adapters/{adapter_name}/connections",
            data=request.model_dump(exclude_none=True, by_alias=True),
        )
        return AdapterConnection.model_validate(data)

    async def acreate_connection(
        self,
        adapter_name: str,
        connection_config: dict[str, Any],
        *,
        connection_label: str | None = None,
        active: bool = True,
    ) -> AdapterConnection:
        """Async version of create_connection()."""
        request = AdapterConnectionRequest(
            connection_label=connection_label,
            active=active,
            connection_config=connection_config,
        )

        data = await self._apost(
            f"/v2/adapters/{adapter_name}/connections",
            data=request.model_dump(exclude_none=True, by_alias=True),
        )
        return AdapterConnection.model_validate(data)

    def update_connection(
        self,
        adapter_name: str,
        connection_id: str,
        connection_config: dict[str, Any],
        *,
        connection_label: str | None = None,
        active: bool | None = None,
    ) -> AdapterConnection:
        """Update an existing adapter connection.

        Args:
            adapter_name: Name of the adapter
            connection_id: Connection ID
            connection_config: Connection configuration
            connection_label: Optional label for the connection
            active: Whether the connection is active

        Returns:
            Updated AdapterConnection
        """
        request = AdapterConnectionRequest(
            connection_label=connection_label,
            active=active if active is not None else True,
            connection_config=connection_config,
        )

        data = self._put(
            f"/v2/adapters/{adapter_name}/connections/{connection_id}",
            data=request.model_dump(exclude_none=True, by_alias=True),
        )
        return AdapterConnection.model_validate(data)

    async def aupdate_connection(
        self,
        adapter_name: str,
        connection_id: str,
        connection_config: dict[str, Any],
        *,
        connection_label: str | None = None,
        active: bool | None = None,
    ) -> AdapterConnection:
        """Async version of update_connection()."""
        request = AdapterConnectionRequest(
            connection_label=connection_label,
            active=active if active is not None else True,
            connection_config=connection_config,
        )

        data = await self._aput(
            f"/v2/adapters/{adapter_name}/connections/{connection_id}",
            data=request.model_dump(exclude_none=True, by_alias=True),
        )
        return AdapterConnection.model_validate(data)

    def delete_connection(
        self,
        adapter_name: str,
        connection_id: str,
    ) -> None:
        """Delete an adapter connection.

        Args:
            adapter_name: Name of the adapter
            connection_id: Connection ID
        """
        self._delete(f"/v2/adapters/{adapter_name}/connections/{connection_id}")

    async def adelete_connection(
        self,
        adapter_name: str,
        connection_id: str,
    ) -> None:
        """Async version of delete_connection()."""
        await self._adelete(f"/v2/adapters/{adapter_name}/connections/{connection_id}")

    def fetch(
        self,
        adapter_name: str,
        connection_id: str,
    ) -> None:
        """Trigger a fetch for an adapter connection.

        Args:
            adapter_name: Name of the adapter
            connection_id: Connection ID
        """
        self._post(f"/v2/adapters/{adapter_name}/connections/{connection_id}/fetch")

    async def afetch(
        self,
        adapter_name: str,
        connection_id: str,
    ) -> None:
        """Async version of fetch()."""
        await self._apost(f"/v2/adapters/{adapter_name}/connections/{connection_id}/fetch")

    def get_fetch_status(self) -> AdapterFetchStatus:
        """Get the current fetch status for all adapters.

        Returns:
            AdapterFetchStatus
        """
        data = self._get("/v2/adapters/fetch_events")
        return AdapterFetchStatus.model_validate(data)

    async def aget_fetch_status(self) -> AdapterFetchStatus:
        """Async version of get_fetch_status()."""
        data = await self._aget("/v2/adapters/fetch_events")
        return AdapterFetchStatus.model_validate(data)

    def get_advanced_settings(self, adapter_name: str) -> dict[str, Any]:
        """Get advanced settings for an adapter.

        Args:
            adapter_name: Name of the adapter

        Returns:
            Advanced settings dictionary
        """
        data = self._get(f"/v2/adapters/{adapter_name}/advanced_settings")
        return data

    async def aget_advanced_settings(self, adapter_name: str) -> dict[str, Any]:
        """Async version of get_advanced_settings()."""
        data = await self._aget(f"/v2/adapters/{adapter_name}/advanced_settings")
        return data

    def update_advanced_settings(
        self,
        adapter_name: str,
        settings: dict[str, Any],
    ) -> dict[str, Any]:
        """Update advanced settings for an adapter.

        Args:
            adapter_name: Name of the adapter
            settings: Settings to update

        Returns:
            Updated settings
        """
        data = self._patch(f"/v2/adapters/{adapter_name}/advanced_settings", data=settings)
        return data

    async def aupdate_advanced_settings(
        self,
        adapter_name: str,
        settings: dict[str, Any],
    ) -> dict[str, Any]:
        """Async version of update_advanced_settings()."""
        data = await self._apatch(f"/v2/adapters/{adapter_name}/advanced_settings", data=settings)
        return data
