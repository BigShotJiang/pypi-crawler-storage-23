"""Adapter-related models."""

from __future__ import annotations

from datetime import datetime
from typing import Any

from pydantic import Field

from .common import BaseAxoniusModel, PaginatedResponse


class AdapterConnectionConfig(BaseAxoniusModel):
    """Connection configuration for an adapter."""

    enabled: bool = Field(default=True, description="Whether connection is enabled")
    fetch_interval: int | None = Field(default=None, description="Fetch interval in minutes")


class AdapterConnection(BaseAxoniusModel):
    """Represents an adapter connection."""

    id: str = Field(description="Connection ID")
    uuid: str = Field(description="Connection UUID")
    adapter_name: str = Field(description="Adapter name")
    node_id: str = Field(description="Node ID")
    node_name: str = Field(description="Node name")
    status: str = Field(description="Connection status")
    error: str | None = Field(default=None, description="Error message if any")
    last_fetch_time: datetime | None = Field(default=None, description="Last fetch time")
    connection_label: str | None = Field(default=None, description="Connection label")
    config: dict[str, Any] = Field(default_factory=dict, description="Connection configuration")


class AdapterConnectionRequest(BaseAxoniusModel):
    """Request body for creating/updating an adapter connection."""

    connection_label: str | None = Field(default=None, description="Connection label")
    active: bool = Field(default=True, description="Whether connection is active")
    connection_config: dict[str, Any] = Field(default_factory=dict, description="Connection configuration")


class Adapter(BaseAxoniusModel):
    """Represents an Axonius adapter."""

    name: str = Field(description="Adapter name/ID")
    name_pretty: str = Field(description="Human-readable adapter name")
    description: str | None = Field(default=None, description="Adapter description")
    icon: str | None = Field(default=None, description="Icon URL")
    connection_count: int = Field(default=0, description="Number of connections")
    status: str = Field(description="Adapter status")
    features: list[str] = Field(default_factory=list, description="Supported features")


class AdaptersResponse(PaginatedResponse):
    """Response containing a list of adapters."""

    adapters: list[Adapter] = Field(default_factory=list, description="List of adapters")


class AdapterFetchStatus(BaseAxoniusModel):
    """Status of adapter fetching."""

    status: str = Field(description="Current fetch status")
    started_at: datetime | None = Field(default=None, description="Fetch start time")
    progress: float | None = Field(default=None, description="Progress percentage")
