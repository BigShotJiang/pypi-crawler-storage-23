"""Discovery-related models."""

from __future__ import annotations

from datetime import datetime

from pydantic import Field

from .common import BaseAxoniusModel


class DiscoveryStatus(BaseAxoniusModel):
    """Discovery lifecycle status."""

    status: str = Field(description="Current discovery status")
    is_running: bool = Field(default=False, description="Whether discovery is running")
    last_started: datetime | None = Field(default=None, description="Last start time")
    last_finished: datetime | None = Field(default=None, description="Last finish time")
    next_scheduled: datetime | None = Field(default=None, description="Next scheduled run")
    progress: float | None = Field(default=None, description="Progress percentage if running")


class DiscoveryResponse(BaseAxoniusModel):
    """Response from discovery operations."""

    status: DiscoveryStatus = Field(description="Discovery status")
    message: str | None = Field(default=None, description="Status message")
