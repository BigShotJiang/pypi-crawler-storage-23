"""Activity log models."""

from __future__ import annotations

from datetime import datetime
from typing import Any

from pydantic import Field

from .common import BaseAxoniusModel, PaginatedResponse


class ActivityLog(BaseAxoniusModel):
    """Represents an activity log entry."""

    id: str = Field(description="Log entry ID")
    user_id: str | None = Field(default=None, description="User who performed the action")
    user_name: str | None = Field(default=None, description="User name")
    category: str = Field(description="Activity category")
    action: str = Field(description="Action performed")
    message: str | None = Field(default=None, description="Log message")
    timestamp: datetime = Field(description="When the action occurred")
    details: dict[str, Any] = Field(default_factory=dict, description="Additional details")
    ip_address: str | None = Field(default=None, description="Client IP address")


class ActivityLogsResponse(PaginatedResponse):
    """Response containing activity logs."""

    logs: list[ActivityLog] = Field(default_factory=list, description="List of activity logs")
