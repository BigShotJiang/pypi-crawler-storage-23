"""Tag-related models."""

from __future__ import annotations

from pydantic import AliasChoices, Field

from .common import BaseAxoniusModel, PaginatedResponse


class Tag(BaseAxoniusModel):
    """Represents an Axonius tag."""

    id: str | None = Field(default=None, description="Tag ID")
    name: str = Field(description="Tag name")
    type: str | None = Field(default=None, description="Tag type")
    description: str | None = Field(default=None, description="Tag description")
    count: int = Field(default=0, description="Number of assets with this tag")


class TagsResponse(PaginatedResponse):
    """Response containing a list of tags."""

    tags: list[Tag] = Field(
        default_factory=list,
        validation_alias=AliasChoices("tags", "data"),
        description="List of tags",
    )
