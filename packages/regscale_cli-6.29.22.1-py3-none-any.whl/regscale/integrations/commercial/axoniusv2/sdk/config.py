"""Configuration management for the Axonious SDK."""

from __future__ import annotations

import logging

from pydantic import Field, SecretStr, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

logger = logging.getLogger("regscale")


class AxoniusConfig(BaseSettings):
    """Configuration for the Axonius client.

    Configuration can be provided via:
    - Direct initialization arguments
    - Environment variables (prefixed with AXONIUS_)
    - .env file

    Example:
        >>> config = AxoniusConfig(
        ...     host="myaxonius.example.com",
        ...     api_key="my-api-key",
        ...     api_secret="my-api-secret"
        ... )

        Or via environment variables:
        - AXONIUS_HOST
        - AXONIUS_API_KEY
        - AXONIUS_API_SECRET
    """

    model_config = SettingsConfigDict(
        env_prefix="AXONIUS_",
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )

    host: str = Field(description="Axonius server hostname")
    api_key: SecretStr = Field(description="API key for authentication")
    api_secret: SecretStr = Field(description="API secret for authentication")
    port: int = Field(default=443, description="Server port")
    use_https: bool = Field(default=True, description="Use HTTPS protocol")
    verify_ssl: bool = Field(default=True, description="Verify SSL certificates")
    timeout: float = Field(default=30.0, gt=0, description="Request timeout in seconds")
    max_retries: int = Field(default=3, ge=0, description="Maximum number of retries")
    retry_delay: float = Field(default=1.0, gt=0, description="Delay between retries in seconds")

    @property
    def base_url(self) -> str:
        """Construct the base URL for API requests."""
        protocol = "https" if self.use_https else "http"
        default_port = 443 if self.use_https else 80
        if self.port == default_port:
            return "%s://%s/api" % (protocol, self.host)
        return "%s://%s:%d/api" % (protocol, self.host, self.port)

    @model_validator(mode="after")
    def validate_host(self) -> AxoniusConfig:
        """Ensure host doesn't include protocol, and extract port if embedded."""
        host = self.host
        if host.startswith("http://"):
            host = host.split("://", 1)[1]
            self.use_https = False
            if self.port == 443:
                self.port = 80
        elif host.startswith("https://"):
            host = host.split("://", 1)[1]
            self.use_https = True
        if host.endswith("/"):
            host = host.rstrip("/")
        # Extract port from host:port format
        if ":" in host:
            parts = host.rsplit(":", 1)
            if parts[1].isdigit():
                host = parts[0]
                self.port = int(parts[1])
        self.host = host
        return self

    @model_validator(mode="after")
    def warn_ssl_disabled(self) -> AxoniusConfig:
        """Warn if SSL verification is disabled."""
        if not self.verify_ssl:
            logger.warning(
                "SSL verification is disabled for Axonius API. This is insecure and should only be used in development."
            )
        return self
