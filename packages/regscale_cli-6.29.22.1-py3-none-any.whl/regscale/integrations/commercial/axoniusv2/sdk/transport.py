"""HTTP transport layer for the Axonious SDK."""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any, TypeVar

import httpx
from tenacity import (
    RetryError,
    retry,
    retry_if_exception_type,
    retry_if_result,
    stop_after_attempt,
    wait_exponential,
)

from .config import AxoniusConfig
from .exceptions import (
    APIError,
    AuthenticationError,
    BadRequestError,
    ConnectionError,
    NotFoundError,
    RateLimitError,
    ServerError,
    TimeoutError,
    ValidationError,
)

if TYPE_CHECKING:
    from collections.abc import Mapping

logger = logging.getLogger("regscale")

T = TypeVar("T")

# HTTP/connection errors that should trigger automatic retry.
_RETRYABLE_ERRORS = (
    httpx.ConnectError,
    httpx.ConnectTimeout,
    httpx.ReadTimeout,
    httpx.ReadError,
    httpx.RemoteProtocolError,
    httpx.ProxyError,
    httpx.TimeoutException,
)

# Status codes that should trigger a retry.
_RETRYABLE_STATUS_CODES = {429, 500, 502, 503, 504}


def _should_retry_response(response: httpx.Response | None) -> bool:
    """Return True if the response status code warrants a retry."""
    if response is None:
        return False
    return response.status_code in _RETRYABLE_STATUS_CODES


class HTTPTransport:
    """Low-level HTTP transport handling authentication and error handling."""

    def __init__(self, config: AxoniusConfig) -> None:
        self._config = config
        self._client: httpx.Client | None = None
        self._async_client: httpx.AsyncClient | None = None

    def _get_auth_headers(self) -> dict[str, str]:
        """Get authentication headers."""
        return {
            "api-key": self._config.api_key.get_secret_value(),
            "api-secret": self._config.api_secret.get_secret_value(),
            "Content-Type": "application/json",
        }

    def _get_client(self) -> httpx.Client:
        """Get or create the synchronous HTTP client."""
        if self._client is None:
            self._client = httpx.Client(
                base_url=self._config.base_url,
                headers=self._get_auth_headers(),
                timeout=httpx.Timeout(self._config.timeout),
                verify=self._config.verify_ssl,
            )
        return self._client

    def _get_async_client(self) -> httpx.AsyncClient:
        """Get or create the asynchronous HTTP client."""
        if self._async_client is None:
            self._async_client = httpx.AsyncClient(
                base_url=self._config.base_url,
                headers=self._get_auth_headers(),
                timeout=httpx.Timeout(self._config.timeout),
                verify=self._config.verify_ssl,
            )
        return self._async_client

    def _handle_error_response(self, response: httpx.Response) -> None:
        """Handle error responses from the API."""
        try:
            error_data = response.json()
            errors = error_data.get("errors", [])
            error_id = error_data.get("error_id")
            if errors:
                message = "%s: %s" % (errors[0].get("error", "Error"), errors[0].get("description", ""))
            else:
                message = response.text
        except Exception:
            errors = []
            error_id = None
            message = response.text or "HTTP %d" % response.status_code

        status = response.status_code

        if status == 401:
            raise AuthenticationError(message)
        if status == 400:
            raise BadRequestError(message, status, error_id, errors)
        if status == 404:
            raise NotFoundError(message, status, error_id, errors)
        if status == 422:
            raise ValidationError(message, status, error_id, errors)
        if status == 429:
            retry_after = response.headers.get("Retry-After")
            retry_after_seconds = None
            if retry_after is not None:
                try:
                    retry_after_seconds = float(retry_after)
                except (ValueError, TypeError):
                    retry_after_seconds = None
            raise RateLimitError(message, status, error_id, errors, retry_after=retry_after_seconds)
        if status >= 500:
            raise ServerError(message, status, error_id, errors)

        raise APIError(message, status, error_id, errors)

    def _handle_response(self, response: httpx.Response) -> dict[str, Any]:
        """Handle HTTP response, raising exceptions for errors.

        :param response: The HTTP response.
        :return: Parsed JSON response body, or empty dict for 204.
        :rtype: dict[str, Any]
        """
        if response.status_code >= 400:
            self._handle_error_response(response)
        if response.status_code == 204:
            return {}
        return response.json()

    def request(
        self,
        method: str,
        path: str,
        *,
        params: Mapping[str, Any] | None = None,
        json: Any | None = None,
        headers: Mapping[str, str] | None = None,
    ) -> dict[str, Any]:
        """Make a synchronous HTTP request with tenacity retry.

        Args:
            method: HTTP method (GET, POST, etc.)
            path: API path (will be appended to base URL)
            params: Query parameters
            json: JSON body
            headers: Additional headers

        Returns:
            Response JSON as dict

        Raises:
            Various exceptions based on response status
        """
        client = self._get_client()

        @retry(
            stop=stop_after_attempt(self._config.max_retries + 1),
            wait=wait_exponential(multiplier=self._config.retry_delay, max=30),
            retry=(retry_if_result(_should_retry_response) | retry_if_exception_type(_RETRYABLE_ERRORS)),
            reraise=True,
        )
        def _do_request() -> httpx.Response:
            return client.request(
                method,
                path,
                params=dict(params) if params else None,
                json=json,
                headers=dict(headers) if headers else None,
            )

        try:
            response = _do_request()
        except RetryError as e:
            # RetryError is raised for result-based retries (429/5xx status codes)
            last_attempt = e.last_attempt
            if last_attempt and not last_attempt.failed:
                result = last_attempt.result()
                if isinstance(result, httpx.Response):
                    logger.warning(
                        "Request to %s exhausted retries (status: %d)",
                        path,
                        result.status_code,
                    )
                    response = result
                else:
                    raise
            else:
                raise
        except httpx.TimeoutException as e:
            # reraise=True means tenacity re-raises the original exception directly
            raise TimeoutError("Request timed out: %s" % e) from e
        except httpx.ConnectError as e:
            raise ConnectionError("Failed to connect: %s" % e) from e

        return self._handle_response(response)

    async def arequest(
        self,
        method: str,
        path: str,
        *,
        params: Mapping[str, Any] | None = None,
        json: Any | None = None,
        headers: Mapping[str, str] | None = None,
    ) -> dict[str, Any]:
        """Make an asynchronous HTTP request with tenacity retry.

        Args:
            method: HTTP method (GET, POST, etc.)
            path: API path (will be appended to base URL)
            params: Query parameters
            json: JSON body
            headers: Additional headers

        Returns:
            Response JSON as dict

        Raises:
            Various exceptions based on response status
        """
        client = self._get_async_client()

        @retry(
            stop=stop_after_attempt(self._config.max_retries + 1),
            wait=wait_exponential(multiplier=self._config.retry_delay, max=30),
            retry=(retry_if_result(_should_retry_response) | retry_if_exception_type(_RETRYABLE_ERRORS)),
            reraise=True,
        )
        async def _do_request() -> httpx.Response:
            return await client.request(
                method,
                path,
                params=dict(params) if params else None,
                json=json,
                headers=dict(headers) if headers else None,
            )

        try:
            response = await _do_request()
        except RetryError as e:
            last_attempt = e.last_attempt
            if last_attempt and not last_attempt.failed:
                result = last_attempt.result()
                if isinstance(result, httpx.Response):
                    logger.warning(
                        "Async request to %s exhausted retries (status: %d)",
                        path,
                        result.status_code,
                    )
                    response = result
                else:
                    raise
            else:
                raise
        except httpx.TimeoutException as e:
            raise TimeoutError("Request timed out: %s" % e) from e
        except httpx.ConnectError as e:
            raise ConnectionError("Failed to connect: %s" % e) from e

        return self._handle_response(response)

    def close(self) -> None:
        """Close the synchronous client."""
        if self._client is not None:
            self._client.close()
            self._client = None

    async def aclose(self) -> None:
        """Close the asynchronous client."""
        if self._async_client is not None:
            await self._async_client.aclose()
            self._async_client = None
