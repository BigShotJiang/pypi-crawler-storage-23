"""BigQuery Scanner Integration for RegScale.

Reads asset data from a BigQuery table or query and syncs it into RegScale
using the ScannerIntegration framework.
"""

import logging
from collections.abc import Iterator

from regscale.integrations.scanner_integration import (
    IntegrationAsset,
    IntegrationFinding,
    ScannerIntegration,
)
from regscale.models import regscale_models

logger = logging.getLogger("regscale")

# Mapping from BigQuery "status" string values to RegScale AssetStatus enum.
_STATUS_MAP = {
    "active": regscale_models.AssetStatus.Active,
    "inactive": regscale_models.AssetStatus.Inactive,
    "decommissioned": regscale_models.AssetStatus.Decommissioned,
}


def _safe_str(value, default: str = "") -> str:
    """Return *value* as a stripped string, or *default* when the value is empty/None.

    :param value: Raw cell value from the DataFrame row.
    :param str default: Fallback when *value* is falsy.
    :return: Cleaned string.
    :rtype: str
    """
    if value is None:
        return default
    text = str(value).strip()
    return text if text else default


def _map_status(raw_status: str) -> regscale_models.AssetStatus:
    """Map a free-text status string to a RegScale ``AssetStatus``.

    :param str raw_status: Status value from BigQuery (e.g. ``"Active"``).
    :return: Matching ``AssetStatus`` enum member; defaults to ``Active``.
    :rtype: regscale_models.AssetStatus
    """
    return _STATUS_MAP.get(raw_status.lower().strip(), regscale_models.AssetStatus.Active)


def _row_to_asset(row) -> IntegrationAsset:
    """Convert a single BigQuery row dict to an ``IntegrationAsset``.

    :param dict row: Dictionary produced by ``DataFrame.iter_rows(named=True)``.
    :return: Populated ``IntegrationAsset``.
    :rtype: IntegrationAsset
    """
    asset_id = _safe_str(row.get("assetId"))
    name = _safe_str(row.get("name"), default=asset_id)
    asset_type = _safe_str(row.get("assetType"), default="Other")
    status_raw = _safe_str(row.get("status"), default="Active")

    return IntegrationAsset(
        name=name,
        identifier=asset_id,
        other_tracking_number=asset_id,
        asset_type=asset_type,
        asset_category="Hardware",
        component_type=regscale_models.ComponentType.Hardware,
        description=_safe_str(row.get("description")),
        status=_map_status(status_raw),
        ip_address=_safe_str(row.get("ipAddress")) or None,
        mac_address=_safe_str(row.get("macAddress")) or None,
        manufacturer=_safe_str(row.get("manufacturer")) or None,
        model=_safe_str(row.get("model")) or None,
        serial_number=_safe_str(row.get("serialNumber")) or None,
        location=_safe_str(row.get("location")) or None,
        asset_owner_id=_safe_str(row.get("owner")) or None,
    )


class BigQueryScannerIntegration(ScannerIntegration):
    """Scanner integration that reads assets from Google BigQuery."""

    title = "BigQuery"
    asset_identifier_field = "otherTrackingNumber"

    # ------------------------------------------------------------------
    # ScannerIntegration abstract method implementations
    # ------------------------------------------------------------------

    def fetch_assets(self, *args, **kwargs) -> Iterator[IntegrationAsset]:
        """Fetch assets from a BigQuery table or query.

        Keyword Args:
            source_type (str): ``"table"`` (default) or ``"query"``.
            bigquery_project (str): GCP project override.
            bigquery_dataset (str): Dataset override.
            bigquery_table (str): Table override.
            bigquery_query (str): Raw SQL query (query mode only).
            offset (int): Records to skip.
            limit (int | None): Max records to yield.

        :return: An iterator of ``IntegrationAsset`` objects.
        :rtype: Iterator[IntegrationAsset]
        """
        kwargs.pop("plan_id", None)
        offset = kwargs.pop("offset", 0) or 0
        limit = kwargs.pop("limit", None)

        source = self._build_data_source(**kwargs)
        df = source.read_data(offset=offset, limit=limit)
        logger.info("BigQuery returned %d rows", len(df))

        for row in df.iter_rows(named=True):
            yield _row_to_asset(row)

    def fetch_findings(self, *args, **kwargs) -> Iterator[IntegrationFinding]:
        """BigQuery asset sync does not produce findings.

        :return: An empty iterator.
        :rtype: Iterator[IntegrationFinding]
        """
        return iter([])

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------

    @staticmethod
    def _build_data_source(**kwargs):
        """Create an ``AssetBigQueryDataSource`` from kwargs and GcpVariables.

        Falls back to ``GcpVariables`` for any parameter not supplied on the
        command line.

        :param kwargs: CLI overrides for project, dataset, table, query.
        :return: Configured ``AssetBigQueryDataSource``.
        :rtype: AssetBigQueryDataSource
        """
        from regscale.integrations.commercial.gcp.variables import GcpVariables
        from regscale.integrations.scanner.bigquery_source import AssetBigQueryDataSource

        source_type = kwargs.get("source_type", "table")
        project_id = kwargs.get("bigquery_project") or GcpVariables.gcpBigQueryProject
        query = kwargs.get("bigquery_query")

        if source_type == "query" and query:
            return AssetBigQueryDataSource(project_id=project_id, query=query)

        dataset_id = kwargs.get("bigquery_dataset") or GcpVariables.gcpBigQueryDataset
        table_id = kwargs.get("bigquery_table") or GcpVariables.gcpBigQueryAssetTable

        return AssetBigQueryDataSource(
            project_id=project_id,
            dataset_id=dataset_id,
            table_id=table_id,
        )
