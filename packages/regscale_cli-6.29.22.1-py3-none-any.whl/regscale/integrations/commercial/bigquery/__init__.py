"""BigQuery integration for RegScale CLI."""
