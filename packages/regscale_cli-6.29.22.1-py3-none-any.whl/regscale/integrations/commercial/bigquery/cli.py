"""CLI commands for BigQuery integration."""

import logging
import math

import click

from regscale.models.app_models.click import regscale_ssp_id

logger = logging.getLogger("regscale")


# -- Shared option decorators -------------------------------------------------


def _pagination_options(fn):
    """Add --offset, --limit, and --dry-run options to a command."""
    fn = click.option(
        "--offset",
        default=0,
        type=int,
        help="Number of records to skip (for orchestrator pagination).",
    )(fn)
    fn = click.option(
        "--limit",
        default=None,
        type=int,
        help="Maximum number of records to process (for orchestrator pagination).",
    )(fn)
    fn = click.option(
        "--dry-run",
        is_flag=True,
        default=False,
        help="Fetch row count and schema without pushing data to RegScale.",
    )(fn)
    return fn


# -- Dry-run helper ------------------------------------------------------------


def _dry_run_report(scanner, **kwargs) -> None:
    """Print a dry-run summary: row count, schema, and pagination recommendations.

    :param scanner: A ``BigQueryScannerIntegration`` instance.
    :param kwargs: Forwarded to ``_build_data_source``.
    """
    source = scanner._build_data_source(**kwargs)
    total_rows = source.count_rows()

    click.echo("[dry-run] BigQuery source: %s" % (source.table_id or "custom query"))
    click.echo("[dry-run] Total rows: %d" % total_rows)

    # Show schema from table metadata when available
    if source.table_id:
        table_ref = "%s.%s.%s" % (source.project_id, source.dataset_id, source.table_id)
        table_meta = source.client.get_table(table_ref)
        click.echo("[dry-run] Schema:")
        for field in table_meta.schema:
            click.echo("  - %s (%s, %s)" % (field.name, field.field_type, field.mode))

    # Pagination recommendations
    page_size = 5000
    if total_rows > page_size:
        pages = math.ceil(total_rows / page_size)
        click.echo("[dry-run] Recommended pagination: %d pages of %d rows" % (pages, page_size))
    else:
        click.echo("[dry-run] Dataset fits in a single batch; pagination not required.")


# -- Commands ------------------------------------------------------------------


@click.command("sync_assets_bq")
@regscale_ssp_id(help="RegScale SSP ID to sync assets to.")
@click.option(
    "--source-type",
    type=click.Choice(["table", "query"], case_sensitive=False),
    default="table",
    help="Read from a BigQuery table or execute a SQL query.",
)
@click.option("--bigquery-project", default=None, type=str, help="GCP project ID (overrides init.yaml).")
@click.option("--bigquery-dataset", default=None, type=str, help="BigQuery dataset ID (overrides init.yaml).")
@click.option("--bigquery-table", default=None, type=str, help="BigQuery table name (overrides init.yaml).")
@click.option("--bigquery-query", default=None, type=str, help="SQL SELECT query (query mode only).")
@_pagination_options
def sync_assets_bq(
    regscale_ssp_id: int,
    source_type: str,
    bigquery_project: str,
    bigquery_dataset: str,
    bigquery_table: str,
    bigquery_query: str,
    offset: int,
    limit: int,
    dry_run: bool,
) -> None:
    """Sync assets from a BigQuery table or query into RegScale."""
    from regscale.integrations.commercial.bigquery.scanner import BigQueryScannerIntegration

    scanner = BigQueryScannerIntegration(plan_id=regscale_ssp_id)
    sync_kwargs = {
        "source_type": source_type,
        "bigquery_project": bigquery_project,
        "bigquery_dataset": bigquery_dataset,
        "bigquery_table": bigquery_table,
        "bigquery_query": bigquery_query,
        "offset": offset,
        "limit": limit,
    }

    if dry_run:
        _dry_run_report(scanner, **sync_kwargs)
    else:
        scanner.sync_assets(plan_id=regscale_ssp_id, **sync_kwargs)
