#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
AWS Integration Variables

Configuration variables for AWS integration.
These variables can be set in init.yaml or as environment variables.
"""

from regscale.core.app.utils.variables import RsVariablesMeta, RsVariableType


class AWSVariables(metaclass=RsVariablesMeta):
    """
    AWS Variables class to define configuration with type annotations.

    All variables follow the RegScale variables pattern and can be configured via:
    - init.yaml configuration file (under 'aws' section)
    - Environment variables (AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY)
    - Command-line parameters

    Security Note:
        Storing AWS credentials in init.yaml is convenient but less secure than
        using AWS profiles, session tokens, or environment variables. Consider
        using AWS IAM roles or temporary credentials for production environments.

    Example init.yaml configuration:
        aws:
          awsAccessKeyId: AKIAIOSFODNN7EXAMPLE
          awsSecretAccessKey: wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY
    """

    awsAccessKeyId: RsVariableType(str, "<myAwsAccessKeyIdGoesHere>", required=False, sensitive=True)  # type: ignore

    awsSecretAccessKey: RsVariableType(str, "<myAwsSecretAccessKeyGoesHere>", required=False, sensitive=True)  # type: ignore
