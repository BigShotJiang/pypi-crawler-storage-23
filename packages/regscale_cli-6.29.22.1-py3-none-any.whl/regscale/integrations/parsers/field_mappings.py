"""
Common field extraction and mapping utilities for parser framework.

Provides reusable functions for extracting and transforming data from various
integration data structures with consistent error handling and type safety.
"""

import logging
from datetime import datetime
from typing import Any, Callable, Dict, List, Optional, Union

logger = logging.getLogger("regscale")


def safe_get(data: Dict[str, Any], *keys: str, default: Any = None) -> Any:
    """
    Safely navigate nested dictionary structure.

    Args:
        data: The dictionary to navigate
        *keys: Variable number of keys representing the path to navigate
        default: Default value to return if path doesn't exist

    Returns:
        The value at the specified path, or default if not found

    Example:
        >>> data = {"a": {"b": {"c": "value"}}}
        >>> safe_get(data, "a", "b", "c")
        'value'
        >>> safe_get(data, "a", "x", "y", default="not found")
        'not found'
    """
    try:
        result = data
        for key in keys:
            if isinstance(result, dict):
                result = result[key]
            else:
                return default
        return result if result is not None else default
    except (KeyError, TypeError, AttributeError):
        return default


def extract_field(
    data: Dict[str, Any],
    field_path: Union[str, List[str]],
    default: Any = None,
    transform: Optional[Callable[[Any], Any]] = None,
) -> Any:
    """
    Extract a field from data with optional transformation.

    Args:
        data: The dictionary to extract from
        field_path: Single field name or list representing nested path
        default: Default value if field not found
        transform: Optional function to transform the extracted value

    Returns:
        The extracted and optionally transformed value

    Example:
        >>> data = {"severity": "HIGH"}
        >>> extract_field(data, "severity", transform=str.lower)
        'high'
        >>> extract_field(data, ["resource", "id"], default="unknown")
        'unknown'
    """
    if isinstance(field_path, str):
        value = safe_get(data, field_path, default=default)
    else:
        value = safe_get(data, *field_path, default=default)

    if value is not None and transform is not None:
        try:
            return transform(value)
        except Exception as e:
            logger.warning(f"Failed to transform field value: {e}")
            return default

    return value if value is not None else default


def extract_multiple_fields(data: Dict[str, Any], field_paths: List[Union[str, List[str]]], default: Any = None) -> Any:
    """
    Try extracting from multiple field paths, return first non-None value.

    Useful when different integrations use different field names for the same data.

    Args:
        data: The dictionary to extract from
        field_paths: List of field paths to try in order
        default: Default value if none of the paths yield a value

    Returns:
        First non-None extracted value, or default

    Example:
        >>> data = {"instanceId": "i-123"}
        >>> extract_multiple_fields(data, ["id", "instanceId", "resourceId"])
        'i-123'
    """
    for field_path in field_paths:
        value = extract_field(data, field_path)
        if value is not None:
            return value
    return default


def parse_datetime(value: Optional[Union[str, datetime]], default: Optional[str] = None) -> Optional[str]:
    """
    Parse datetime value to ISO format string.

    Args:
        value: DateTime value as string or datetime object
        default: Default value if parsing fails

    Returns:
        ISO formatted datetime string or default

    Example:
        >>> parse_datetime("2024-01-15T10:30:00Z")
        '2024-01-15T10:30:00+00:00'
    """
    if value is None:
        return default

    if isinstance(value, datetime):
        return value.isoformat()

    if isinstance(value, str):
        # Already an ISO string, return as-is
        return value

    return default


def _process_tag_item(tag: Union[Dict[str, Any], str]) -> Optional[tuple]:
    """
    Process a single tag item and return key-value tuple if valid.

    Args:
        tag: A tag item (dict or string)

    Returns:
        Tuple of (key, value) or None if not processable
    """
    if isinstance(tag, dict):
        # AWS-style: {"Key": "name", "Value": "value"}
        if "Key" in tag and "Value" in tag:
            return tag["Key"], tag["Value"]
        # Generic key-value pairs
        if "key" in tag and "value" in tag:
            return tag["key"], tag["value"]
        return None  # Dict without recognizable key-value structure
    if isinstance(tag, str) and "=" in tag:
        # Handle "key=value" strings
        key, value = tag.split("=", 1)
        return key.strip(), value.strip()
    return None


def build_tags_dict(data: Dict[str, Any], tags_field: str = "tags") -> Dict[str, str]:
    """
    Extract and normalize tags from various formats.

    Handles multiple tag formats commonly seen in cloud platforms:
    - List of {"Key": "name", "Value": "value"} dicts (AWS)
    - Simple {"key": "value"} dict (Azure, GCP)
    - List of "key=value" strings

    Args:
        data: The dictionary containing tags
        tags_field: Name of the field containing tags

    Returns:
        Normalized tags dictionary

    Example:
        >>> build_tags_dict({"tags": [{"Key": "Env", "Value": "prod"}]})
        {'Env': 'prod'}
        >>> build_tags_dict({"tags": {"Env": "prod", "Team": "security"}})
        {'Env': 'prod', 'Team': 'security'}
    """
    tags = safe_get(data, tags_field, default={})

    if isinstance(tags, dict):
        return tags

    if isinstance(tags, list):
        result = {}
        for tag in tags:
            processed = _process_tag_item(tag)
            if processed:
                result[processed[0]] = processed[1]
            elif isinstance(tag, dict):
                # Merge dicts without recognizable key-value structure
                result.update(tag)
        return result

    return {}


def normalize_string(value: Optional[str], max_length: Optional[int] = None) -> str:
    """
    Normalize string value: strip whitespace, handle None, optionally truncate.

    Args:
        value: String value to normalize
        max_length: Maximum length to truncate to (optional)

    Returns:
        Normalized string (empty string if None)

    Example:
        >>> normalize_string("  example  ", max_length=5)
        'examp'
        >>> normalize_string(None)
        ''
    """
    if value is None:
        return ""

    normalized = str(value).strip()

    if max_length and len(normalized) > max_length:
        return normalized[:max_length]

    return normalized


def extract_nested_json(data: Dict[str, Any], path: str, separator: str = ".") -> Any:
    """
    Extract value from nested JSON using dot notation.

    Args:
        data: The dictionary to extract from
        path: Dot-separated path (e.g., "resource.metadata.name")
        separator: Path separator character (default: ".")

    Returns:
        The extracted value or None

    Example:
        >>> data = {"resource": {"metadata": {"name": "server1"}}}
        >>> extract_nested_json(data, "resource.metadata.name")
        'server1'
    """
    keys = path.split(separator)
    return safe_get(data, *keys)


def coalesce(*values: Any) -> Any:
    """
    Return first non-None value from arguments.

    Args:
        *values: Variable number of values to check

    Returns:
        First non-None value, or None if all are None

    Example:
        >>> coalesce(None, None, "value", "other")
        'value'
    """
    for value in values:
        if value is not None:
            return value
    return None


def safe_int(value: Any, default: int = 0) -> int:
    """
    Safely convert value to integer.

    Args:
        value: Value to convert
        default: Default value if conversion fails

    Returns:
        Integer value or default

    Example:
        >>> safe_int("123")
        123
        >>> safe_int("invalid", default=-1)
        -1
    """
    try:
        return int(value)
    except (ValueError, TypeError):
        return default


def safe_float(value: Any, default: float = 0.0) -> float:
    """
    Safely convert value to float.

    Args:
        value: Value to convert
        default: Default value if conversion fails

    Returns:
        Float value or default

    Example:
        >>> safe_float("12.5")
        12.5
        >>> safe_float("invalid", default=-1.0)
        -1.0
    """
    try:
        return float(value)
    except (ValueError, TypeError):
        return default


def safe_bool(value: Any, default: bool = False) -> bool:
    """
    Safely convert value to boolean.

    Handles common boolean representations: true/false, yes/no, 1/0, etc.

    Args:
        value: Value to convert
        default: Default value if conversion fails

    Returns:
        Boolean value or default

    Example:
        >>> safe_bool("true")
        True
        >>> safe_bool("yes")
        True
        >>> safe_bool(1)
        True
        >>> safe_bool("invalid")
        False
    """
    if isinstance(value, bool):
        return value

    if isinstance(value, (int, float)):
        return bool(value)

    if isinstance(value, str):
        value_lower = value.lower().strip()
        if value_lower in ("true", "yes", "1", "on", "enabled"):
            return True
        if value_lower in ("false", "no", "0", "off", "disabled"):
            return False

    return default
