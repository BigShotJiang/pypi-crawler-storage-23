#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Framework Handlers for Control ID Matching.

This module provides specialized handlers for different compliance frameworks
to properly parse, normalize, and match control IDs.

Supported frameworks and example formats:
- NIST 800-53: AC-1, AC-1(1), AC-1.1, PTA-1
- CMMC v2: 3.1.1 (numeric), AC.1.001 (domain prefix)
- CMMC v1 (legacy): AC.L1-3.1.1, SC.L2-3.13.1 (Domain.Level-Chapter.Family.Practice)
- CIS Controls: 6.1.1, 10.1.1, 1.1.1.1
- ISO 27001: A.5.1, A.12.3.1
- SOC2: CC1.1, PI1.5, A1.2
- OWASP ASVS: V1.1.1, ASVS-1.2.3, OWASP:V5.3.3
"""

from regscale.integrations.framework_handlers.base import FrameworkHandler
from regscale.integrations.framework_handlers.registry import (
    FrameworkHandlerRegistry,
    get_registry,
)

__all__ = [
    "FrameworkHandler",
    "FrameworkHandlerRegistry",
    "get_registry",
]
