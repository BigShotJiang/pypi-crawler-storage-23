"""Version information for regscale-cli."""

from pathlib import Path


def get_version_from_metadata() -> str:
    """
    Extract version from package metadata.

    Reads directly from pyproject.toml first to ensure bumped versions
    are reflected immediately without requiring reinstall. Falls back
    to installed package metadata, then a hardcoded fallback.

    :return: Version string from package metadata or fallback
    :rtype: str
    """
    # Try reading directly from pyproject.toml (always reflects latest bump)
    try:
        import re

        pyproject_path = Path(__file__).parent.parent / "pyproject.toml"
        if pyproject_path.is_file():
            content = pyproject_path.read_text()
            match = re.search(r'version\s*=\s*["\']([^"\']+)["\']', content)
            if match:
                return match.group(1)
    except Exception:
        pass

    # Fall back to installed package metadata
    try:
        from importlib.metadata import version

        return version("regscale-cli")
    except Exception:
        pass

    return "6.29.19.20"  # fallback version


__version__ = get_version_from_metadata()
