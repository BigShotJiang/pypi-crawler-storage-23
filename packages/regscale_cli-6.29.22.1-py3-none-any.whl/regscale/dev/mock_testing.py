"""CLI commands for mock integration testing framework."""

import builtins
import logging
import os
import re
import subprocess
import sys
from pathlib import Path

import click
from rich.console import Console
from rich.table import Table

logger = logging.getLogger("regscale")

# Security: Input validation pattern for service and integration names
# Only allow alphanumeric characters, underscores, and hyphens
VALID_NAME_PATTERN = re.compile(r"^[a-zA-Z0-9_-]+$")
MAX_NAME_LENGTH = 50

# Constants for error messages and paths
ERROR_TIMEOUT = "[red]Error: Tests timed out after 600 seconds (10 minutes)"
HINT_HANGING = "[yellow]Hint: Check if mock server or tests are hanging"
SPECS_DIR = "tests/mock_integration/specs"


def validate_name_input(name: str, name_type: str) -> None:
    """
    Validate service/integration name to prevent command injection.

    Args:
        name: The name to validate
        name_type: Type of name for error messages (e.g., "service", "integration")

    Raises:
        click.BadParameter: If validation fails
    """
    if not name:
        raise click.BadParameter(f"{name_type} name cannot be empty")

    if len(name) > MAX_NAME_LENGTH:
        raise click.BadParameter(f"{name_type} name must be {MAX_NAME_LENGTH} characters or less")

    if not VALID_NAME_PATTERN.match(name):
        raise click.BadParameter(
            f"{name_type} name must contain only alphanumeric characters, underscores, and hyphens"
        )


def get_docker_compose_file() -> Path:
    """Get the docker-compose file path from environment or common locations.

    Checks in order:
    1. RS_MOCK_DOCKER_COMPOSE_FILE environment variable
    2. ../rs-mock-integrations-go/docker-compose.yml (sibling directory)
    3. ./rs-mock-integrations-go/docker-compose.yml (subdirectory)
    4. ./docker-compose.yml (current directory)

    Returns:
        Path: Path to docker-compose.yml file

    Raises:
        FileNotFoundError: If docker-compose.yml cannot be found
    """
    # Check environment variable first
    env_path = os.environ.get("RS_MOCK_DOCKER_COMPOSE_FILE")
    if env_path:
        path = Path(env_path)
        if path.exists():
            return path
        logger.warning(f"RS_MOCK_DOCKER_COMPOSE_FILE set but file not found: {path}")

    # Check common relative locations
    common_locations = [
        Path(__file__).parent.parent.parent.parent
        / "rs-mock-integrations-go"
        / "docker-compose.yml",  # Sibling to regscale-cli
        Path("rs-mock-integrations-go/docker-compose.yml"),  # Subdirectory
        Path("docker-compose.yml"),  # Current directory
    ]

    for location in common_locations:
        if location.exists():
            return location.resolve()

    # Not found - raise error with helpful message
    error_msg = (
        "docker-compose.yml not found. Please either:\n"
        "  1. Set RS_MOCK_DOCKER_COMPOSE_FILE environment variable:\n"
        "     export RS_MOCK_DOCKER_COMPOSE_FILE=/path/to/docker-compose.yml\n"
        "  2. Clone rs-mock-integrations-go as sibling directory:\n"
        "     git clone https://github.com/RegScale/rs-mock-integrations-go.git ../rs-mock-integrations-go\n"
        "  3. Place docker-compose.yml in current directory"
    )
    raise FileNotFoundError(error_msg)


def _execute_pytest(cmd: list, console: Console, error_msg: str = None) -> int:
    """Execute pytest command with timeout handling.

    Args:
        cmd: Command list to execute
        console: Rich console for output
        error_msg: Optional error message to show if test file not found

    Returns:
        Exit code from pytest
    """
    try:
        result = subprocess.run(cmd, check=False, timeout=600)
        return result.returncode
    except subprocess.TimeoutExpired:
        console.print(ERROR_TIMEOUT)
        console.print(HINT_HANGING)
        return 1
    except FileNotFoundError:
        if error_msg:
            console.print(error_msg)
            console.print("[yellow]Hint: Run 'regscale-dev mock generate' first")
        else:
            console.print("[red]Error: pytest not found")
        return 1


def _build_pytest_command(test_path: str | list[str], verbose: bool, markers: str) -> list[str]:
    """Build pytest command with options.

    Args:
        test_path: Test path or list of paths
        verbose: Enable verbose output
        markers: Pytest markers to filter tests

    Returns:
        List containing complete pytest command
    """
    cmd = ["python3", "-m", "pytest"]
    if isinstance(test_path, builtins.list):
        cmd.extend(test_path)
    else:
        cmd.append(test_path)
    if verbose:
        cmd.append("-v")
    if markers:
        cmd.extend(["-m", markers])
    return cmd


def _run_all_integrations_tests(console: Console, verbose: bool, markers: str) -> int:
    """Run fast tests for all integrations.

    Args:
        console: Rich console for output
        verbose: Enable verbose output
        markers: Pytest markers to filter tests

    Returns:
        Exit code from pytest
    """
    test_path = "tests/mock_integration/generated/"
    console.print("[cyan]Running fast tests for all integrations...")
    cmd = _build_pytest_command(test_path, verbose, markers)
    return _execute_pytest(cmd, console, f"[red]Error: Test directory not found: {test_path}")


def _run_fast_tests(integration: str, console: Console, verbose: bool, markers: str) -> int:
    """Run fast tests only for specific integration.

    Args:
        integration: Integration name
        console: Rich console for output
        verbose: Enable verbose output
        markers: Pytest markers to filter tests

    Returns:
        Exit code from pytest
    """
    test_path = f"tests/mock_integration/generated/test_{integration}_mock.py"
    console.print(f"[cyan]Running fast tests for {integration}...")
    cmd = _build_pytest_command(test_path, verbose, markers)
    return _execute_pytest(cmd, console, f"[red]Error: Test file not found: {test_path}")


def _run_all_levels_tests(integration: str, console: Console, verbose: bool, markers: str) -> int:
    """Run all 3 test levels for specific integration.

    Args:
        integration: Integration name
        console: Rich console for output
        verbose: Enable verbose output
        markers: Pytest markers to filter tests

    Returns:
        Exit code from pytest
    """
    console.print(f"[cyan]Running all 3 test levels for {integration}...")
    console.print("[dim]Level 1: Mock API tests (generated/)")
    console.print("[dim]Level 2: Scanner integration tests (scanner_tests/)")
    console.print("[dim]Level 3: End-to-end workflow tests (e2e_tests/)")

    # Build test path patterns
    test_paths = [
        f"tests/mock_integration/generated/test_{integration}_mock.py",
        f"tests/mock_integration/scanner_tests/test_{integration}_scanner.py",
        f"tests/mock_integration/e2e_tests/test_{integration}_e2e.py",
    ]

    # Filter to only existing test files
    existing_paths = [p for p in test_paths if Path(p).exists()]

    if not existing_paths:
        console.print(f"[red]Error: No test files found for {integration}")
        console.print("[yellow]Hint: Run 'regscale-dev mock generate' first for Level 1 tests")
        return 1

    # Run tests for all found levels
    cmd = _build_pytest_command(existing_paths, verbose, markers)
    return _execute_pytest(cmd, console)


@click.group()
def mock():
    """Mock Integration Testing Framework - Test mock API servers."""
    pass


@mock.command()
@click.argument("integration", required=False)
@click.option("--fast", is_flag=True, help="Run fast tests only (generated mock API tests)")
@click.option("--integrations", is_flag=True, help="Run tests for all integrations (fast tests only)")
@click.option("--verbose", "-v", is_flag=True, help="Verbose output")
@click.option("--markers", "-m", help="Run only tests matching markers (e.g., 'health_check')")
def test(integration: str, fast: bool, integrations: bool, verbose: bool, markers: str):
    """Run tests for mock integration(s).

    By default, runs all test levels (comprehensive testing).
    Use --fast for quick testing (generated tests only).

    Examples:
        regscale-dev mock test jira              # Run all levels (comprehensive) - DEFAULT
        regscale-dev mock test jira --fast       # Run fast tests only
        regscale-dev mock test --integrations    # Run all integrations (fast tests only)
        regscale-dev mock test jira -m health_check  # Run only health checks (all levels)
    """
    console = Console()

    # Security: Validate integration name to prevent command injection
    if integration:
        try:
            validate_name_input(integration, "Integration")
        except click.BadParameter as e:
            console.print(f"[red]Error: {e}")
            sys.exit(1)

    # Determine test path and execute
    if integrations:
        exit_code = _run_all_integrations_tests(console, verbose, markers)
    elif integration and fast:
        exit_code = _run_fast_tests(integration, console, verbose, markers)
    elif integration:
        exit_code = _run_all_levels_tests(integration, console, verbose, markers)
    else:
        console.print("[red]Error: Specify an integration or use --integrations")
        exit_code = 1

    sys.exit(exit_code)


@mock.command()
@click.argument("integration", required=False)
@click.option("--all", "generate_all", is_flag=True, help="Generate all test files")
def generate(integration: str, generate_all: bool):
    """Generate pytest test files from YAML specifications.

    Examples:
        regscale-dev mock generate jira     # Generate Jira tests
        regscale-dev mock generate --all    # Generate all tests
    """
    console = Console()

    # Security: Validate integration name to prevent command injection
    if integration:
        try:
            validate_name_input(integration, "Integration")
        except click.BadParameter as e:
            console.print(f"[red]Error: {e}")
            sys.exit(1)

    try:
        from tests.mock_integration.framework.spec_loader import SpecLoader
        from tests.mock_integration.framework.test_generator import TestGenerator
    except ImportError as e:
        console.print(f"[red]Error: Failed to import framework modules: {e}")
        sys.exit(1)

    specs_dir = Path(SPECS_DIR)
    output_dir = Path("tests/mock_integration/generated")

    if not specs_dir.exists():
        console.print(f"[red]Error: Specs directory not found: {specs_dir}")
        sys.exit(1)

    loader = SpecLoader(specs_dir)
    generator = TestGenerator(output_dir)

    if generate_all:
        console.print("[cyan]Generating all test files...")
        specs = loader.load_all_specs()
        generated = generator.generate_all(specs)
        console.print(f"[green]✓ Generated {len(generated)} test files")
        for file in generated:
            console.print(f"  • {file.name}")
    elif integration:
        console.print(f"[cyan]Generating test file for {integration}...")
        try:
            spec = loader.load_spec(integration)
            file = generator.generate_test_file(spec)
            console.print(f"[green]✓ Generated {file}")
        except FileNotFoundError:
            console.print(f"[red]Error: Spec not found: {integration}.yaml")
            console.print(f"[yellow]Available specs: {', '.join(loader.list_specs())}")
            sys.exit(1)
    else:
        console.print("[red]Error: Specify an integration or use --all")
        sys.exit(1)


@mock.command()
def list():
    """List all available mock integrations."""
    console = Console()

    try:
        from tests.mock_integration.framework.spec_loader import SpecLoader
    except ImportError as e:
        console.print(f"[red]Error: Failed to import spec loader: {e}")
        sys.exit(1)

    specs_dir = Path(SPECS_DIR)
    if not specs_dir.exists():
        console.print(f"[red]Error: Specs directory not found: {specs_dir}")
        sys.exit(1)

    loader = SpecLoader(specs_dir)
    specs = loader.load_all_specs()

    table = Table(title="Available Mock Integrations")
    table.add_column("Integration", style="cyan")
    table.add_column("Description", style="white")
    table.add_column("Suites", justify="right", style="green")
    table.add_column("Tests", justify="right", style="green")

    for name, spec in sorted(specs.items()):
        table.add_row(
            name,
            spec.integration.description,
            str(len(spec.test_suites)),
            str(spec.get_total_test_count()),
        )

    console.print(table)
    console.print(f"\n[cyan]Total: {len(specs)} integrations")


@mock.command()
@click.argument("integration")
def spec(integration: str):
    """Show detailed specification for an integration.

    Example:
        regscale-dev mock spec jira
    """
    console = Console()

    # Security: Validate integration name to prevent command injection
    try:
        validate_name_input(integration, "Integration")
    except click.BadParameter as e:
        console.print(f"[red]Error: {e}")
        sys.exit(1)

    try:
        from tests.mock_integration.framework.spec_loader import SpecLoader
    except ImportError as e:
        console.print(f"[red]Error: Failed to import spec loader: {e}")
        sys.exit(1)

    specs_dir = Path(SPECS_DIR)
    loader = SpecLoader(specs_dir)

    try:
        spec = loader.load_spec(integration)
    except FileNotFoundError:
        console.print(f"[red]Error: Spec not found: {integration}.yaml")
        console.print(f"[yellow]Available specs: {', '.join(loader.list_specs())}")
        sys.exit(1)

    # Integration info
    console.print(f"\n[cyan bold]{spec.integration.description}[/cyan bold]")
    console.print(f"[white]Name:[/white] {spec.integration.name}")
    console.print(f"[white]Base URL:[/white] {spec.integration.mock_server.base_url}")
    console.print(f"[white]Auth Type:[/white] {spec.auth.type}")

    # Test suites
    table = Table(title=f"\nTest Suites ({len(spec.test_suites)} suites, {spec.get_total_test_count()} tests)")
    table.add_column("Suite", style="cyan")
    table.add_column("Description", style="white")
    table.add_column("Tests", justify="right", style="green")

    for suite in spec.test_suites:
        table.add_row(suite.name, suite.description, str(len(suite.tests)))

    console.print(table)


@mock.command()
@click.argument("service", required=False)
@click.option("--all", "start_all", is_flag=True, help="Start all mock servers")
def start(service: str, start_all: bool):
    """Start mock server(s) using docker-compose.

    Examples:
        regscale-dev mock start jira    # Start Jira server
        regscale-dev mock start --all   # Start all servers

    Configuration:
        Set RS_MOCK_DOCKER_COMPOSE_FILE environment variable to specify custom location.
    """
    console = Console()

    # Security: Validate service name to prevent command injection
    if service:
        try:
            validate_name_input(service, "Service")
        except click.BadParameter as e:
            console.print(f"[red]Error: {e}")
            sys.exit(1)

    try:
        docker_compose_file = get_docker_compose_file()
        console.print(f"[dim]Using docker-compose file: {docker_compose_file}[/dim]")
    except FileNotFoundError as e:
        console.print(f"[red]Error: {e}")
        sys.exit(1)

    if start_all:
        console.print("[cyan]Starting all mock servers...")
        cmd = ["docker-compose", "-f", str(docker_compose_file), "up", "-d"]
    elif service:
        console.print(f"[cyan]Starting {service} mock server...")
        cmd = ["docker-compose", "-f", str(docker_compose_file), "up", "-d", service]
    else:
        console.print("[red]Error: Specify a service or use --all")
        sys.exit(1)

    try:
        subprocess.run(cmd, check=True, timeout=30)
        console.print("[green]✓ Server(s) started successfully")
    except subprocess.TimeoutExpired:
        console.print("[red]Error: docker-compose start timed out after 30 seconds")
        console.print("[yellow]Hint: Check if Docker is running and responsive")
        sys.exit(1)
    except subprocess.CalledProcessError as e:
        console.print(f"[red]Error: Failed to start server(s): {e}")
        sys.exit(1)


@mock.command()
@click.argument("service", required=False)
@click.option("--all", "stop_all", is_flag=True, help="Stop all mock servers")
def stop(service: str, stop_all: bool):
    """Stop mock server(s) using docker-compose.

    Examples:
        regscale-dev mock stop jira     # Stop Jira server
        regscale-dev mock stop --all    # Stop all servers

    Configuration:
        Set RS_MOCK_DOCKER_COMPOSE_FILE environment variable to specify custom location.
    """
    console = Console()

    # Security: Validate service name to prevent command injection
    if service:
        try:
            validate_name_input(service, "Service")
        except click.BadParameter as e:
            console.print(f"[red]Error: {e}")
            sys.exit(1)

    try:
        docker_compose_file = get_docker_compose_file()
        console.print(f"[dim]Using docker-compose file: {docker_compose_file}[/dim]")
    except FileNotFoundError as e:
        console.print(f"[red]Error: {e}")
        sys.exit(1)

    if stop_all:
        console.print("[cyan]Stopping all mock servers...")
        cmd = ["docker-compose", "-f", str(docker_compose_file), "down"]
    elif service:
        console.print(f"[cyan]Stopping {service} mock server...")
        cmd = ["docker-compose", "-f", str(docker_compose_file), "stop", service]
    else:
        console.print("[red]Error: Specify a service or use --all")
        sys.exit(1)

    try:
        subprocess.run(cmd, check=True, timeout=30)
        console.print("[green]✓ Server(s) stopped successfully")
    except subprocess.TimeoutExpired:
        console.print("[red]Error: docker-compose stop timed out after 30 seconds")
        console.print("[yellow]Hint: Check if Docker is running and responsive")
        sys.exit(1)
    except subprocess.CalledProcessError as e:
        console.print(f"[red]Error: Failed to stop server(s): {e}")
        sys.exit(1)
