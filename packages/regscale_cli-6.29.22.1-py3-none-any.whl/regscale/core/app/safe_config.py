#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Safe Configuration Manager for RegScale CLI.

This module provides a safety wrapper around configuration management to prevent
accidental data loss. It implements:
- Automatic backups before any write operation
- Validation to prevent saving configs with significantly fewer keys
- Atomic file operations
- Detailed logging of configuration changes
- Non-destructive merge semantics

Usage:
    from regscale.core.app.safe_config import SafeConfigManager

    manager = SafeConfigManager("init.yaml")
    manager.safe_save(new_config)  # Creates backup, validates, then saves
"""

import contextlib
import copy
import logging
import os
import tempfile
from datetime import datetime
from pathlib import Path
from threading import RLock
from typing import Any, Dict, Optional, Set

import yaml

from regscale.core.app.config_defaults import sanitize_for_yaml
from regscale.models.locking import FileLock

logger = logging.getLogger("regscale")

# Threshold for key loss warning (percentage)
KEY_LOSS_WARNING_THRESHOLD = 0.1  # Warn if losing more than 10% of keys
KEY_LOSS_BLOCK_THRESHOLD = 0.5  # Block if losing more than 50% of keys

# Maximum number of backup files to keep
MAX_BACKUPS = 5

# Backup file pattern
BACKUP_FILE_PATTERN = "init_backup_*.yaml"


class ConfigSafetyError(Exception):
    """Exception raised when a config save operation would cause data loss."""

    pass


class SafeConfigManager:
    """
    Safe configuration manager that prevents accidental data loss.

    This class wraps configuration file operations with safety mechanisms:
    - Automatic backups before writes
    - Validation against data loss
    - Atomic file operations
    - Detailed change logging

    Thread Safety & Locking Hierarchy:
    ---------------------------------
    This class uses a two-level locking strategy for maximum safety:

    1. FileLock (outer, cross-process): File-based lock that prevents multiple
       processes (pytest workers, Airflow tasks, CLI instances) from writing
       simultaneously. Default timeout is 10 seconds (configurable via lock_timeout).
       Includes stale lock detection - if the process holding the lock no longer
       exists, the lock is automatically removed.

    2. RLock (inner, thread-level): Reentrant lock that prevents race conditions
       between threads in the same process.

    Lock acquisition order is ALWAYS: FileLock → RLock (never reversed).
    This consistent ordering prevents deadlocks because:
    - No code path acquires RLock first then waits for FileLock
    - load() only uses RLock (read operations don't need cross-process lock)
    - save operations always acquire FileLock before RLock

    When enable_file_lock=False (e.g., in unit tests), only RLock is used,
    providing thread safety without the overhead of file locking.
    """

    # Default lock timeout in seconds - short enough to avoid DoS from hung processes,
    # long enough for slow disk I/O. FileLock includes stale lock detection.
    # Can be overridden via REGSCALE_LOCK_TIMEOUT environment variable.
    DEFAULT_LOCK_TIMEOUT = 10.0

    def __init__(
        self,
        config_path: str = "init.yaml",
        backup_dir: Optional[str] = None,
        enable_backups: bool = True,
        enable_file_lock: bool = True,
        lock_timeout: Optional[float] = None,
    ):
        """
        Initialize SafeConfigManager.

        :param str config_path: Path to the configuration file
        :param Optional[str] backup_dir: Directory for backups (default: .config_backups)
        :param bool enable_backups: Whether to create backups before writes
        :param bool enable_file_lock: Whether to use cross-process file locking
        :param Optional[float] lock_timeout: Max seconds to wait for lock (default: 10s).
            FileLock includes stale lock detection - if process holding lock is dead,
            the lock is automatically removed. Set higher for slow network drives.
            Can also be set via REGSCALE_LOCK_TIMEOUT environment variable.
        """
        self._config_path = config_path
        self._backup_dir = backup_dir or self._get_default_backup_dir()
        self._enable_backups = enable_backups
        self._enable_file_lock = enable_file_lock
        self._lock_timeout = self._resolve_lock_timeout(lock_timeout)
        self._lock = RLock()
        self._cached_config: Optional[Dict[str, Any]] = None
        self._lock_file = self._get_lock_file_path()

    def _resolve_lock_timeout(self, explicit_timeout: Optional[float]) -> float:
        """
        Resolve the lock timeout from explicit parameter or environment variable.

        Priority: explicit parameter > REGSCALE_LOCK_TIMEOUT env var > DEFAULT_LOCK_TIMEOUT

        :param Optional[float] explicit_timeout: Explicitly specified timeout
        :return: Resolved timeout value in seconds
        :rtype: float
        """
        if explicit_timeout is not None:
            return explicit_timeout

        env_timeout = os.getenv("REGSCALE_LOCK_TIMEOUT")
        if env_timeout:
            try:
                return float(env_timeout)
            except ValueError:
                logger.warning(
                    "Invalid REGSCALE_LOCK_TIMEOUT value '%s', using default %s",
                    env_timeout,
                    self.DEFAULT_LOCK_TIMEOUT,
                )
        return self.DEFAULT_LOCK_TIMEOUT

    def _get_lock_file_path(self) -> str:
        """
        Get the lock file path for cross-process file locking.

        Lock file is placed in the results directory to avoid cluttering
        the config directory.

        :return: Path to the lock file
        :rtype: str
        """
        # Ensure results directory exists
        results_dir = "results"
        os.makedirs(results_dir, exist_ok=True)
        config_basename = os.path.basename(self._config_path)
        return os.path.join(results_dir, f"{config_basename}.lock")

    def _get_default_backup_dir(self) -> str:
        """Get the default backup directory path.

        Can be overridden via the REGSCALE_BACKUP_DIR environment variable.
        This is useful for containerized environments where the config directory
        may not be writable.
        """
        # Allow override via environment variable for containerized environments
        env_backup_dir = os.getenv("REGSCALE_BACKUP_DIR")
        if env_backup_dir:
            return env_backup_dir

        config_dir = os.path.dirname(self._config_path) or "."
        return os.path.join(config_dir, ".config_backups")

    @staticmethod
    def _yaml_load_tolerant(stream: Any) -> Any:
        """
        Load YAML tolerating !!python/object/new: tags left by older yaml.dump calls.

        We construct a throwaway Loader that maps the ExampleConfig Python tag to a
        plain dict so legacy init.yaml files parse without error.  All other safe-load
        restrictions are preserved (no arbitrary code execution).
        """

        class _TolerantLoader(yaml.SafeLoader):
            pass

        def _construct_example_config(loader: yaml.SafeLoader, node: yaml.Node) -> dict:
            if isinstance(node, yaml.MappingNode):
                for key_node, value_node in node.value:
                    key = loader.construct_object(key_node, deep=False)
                    if key == "dictitems":
                        return loader.construct_object(value_node, deep=True)
            pairs = loader.construct_pairs(node, deep=True)
            return dict(pairs) if pairs else {}

        _TolerantLoader.add_constructor(
            "tag:yaml.org,2002:python/object/new:regscale.core.app.config_defaults.ExampleConfig",
            _construct_example_config,
        )
        return yaml.load(stream, Loader=_TolerantLoader)  # noqa: S506

    def load(self) -> Dict[str, Any]:
        """
        Load configuration from file.

        :return: Configuration dictionary (empty dict if file doesn't exist)
        :rtype: Dict[str, Any]
        """
        with self._lock:
            try:
                with open(self._config_path, encoding="utf-8") as f:
                    config = self._yaml_load_tolerant(f)
                    self._cached_config = config if isinstance(config, dict) else {}
                    return copy.copy(self._cached_config)
            except FileNotFoundError:
                logger.debug("Config file not found: %s", self._config_path)
                self._cached_config = {}
                return {}
            except yaml.YAMLError as e:
                logger.error("Error parsing config file %s: %s", self._config_path, e)
                # Don't cache invalid config - return empty but preserve file
                return {}

    def safe_save(
        self,
        new_config: Dict[str, Any],
        force: bool = False,
        reason: str = "unspecified",
    ) -> bool:
        """
        Safely save configuration with backup and validation.

        This method:
        1. Acquires cross-process file lock (prevents concurrent writes from other processes)
        2. Creates a backup of the existing config
        3. Validates the new config won't cause significant data loss
        4. Logs what's changing
        5. Performs an atomic write

        :param Dict new_config: The new configuration to save
        :param bool force: If True, bypass safety checks (use with caution)
        :param str reason: Reason for the config change (for logging)
        :return: True if save was successful
        :rtype: bool
        :raises ConfigSafetyError: If save would cause significant data loss
        """
        # Use FileLock for cross-process synchronization
        # This prevents multiple processes from writing simultaneously
        if self._enable_file_lock:
            with FileLock(lock_file=self._lock_file, timeout=self._lock_timeout):
                return self._safe_save_internal(new_config, force, reason)
        else:
            return self._safe_save_internal(new_config, force, reason)

    def _safe_save_internal(
        self,
        new_config: Dict[str, Any],
        force: bool,
        reason: str,
    ) -> bool:
        """
        Internal implementation of safe_save, called within FileLock context.

        :param Dict new_config: The new configuration to save
        :param bool force: If True, bypass safety checks
        :param str reason: Reason for the config change
        :return: True if save was successful
        :rtype: bool
        """
        with self._lock:
            # Load current config if not cached
            if self._cached_config is None:
                self.load()

            current_config = self._cached_config or {}

            # Validate the new config
            if not force:
                self._validate_config_change(current_config, new_config)

            # Create backup before writing
            if self._enable_backups and current_config:
                self._create_backup(current_config)

            # Log the changes
            self._log_config_changes(current_config, new_config, reason)

            # Perform atomic write
            self._atomic_write(new_config)

            # Update cache
            self._cached_config = new_config.copy()

            return True

    def _validate_config_change(
        self,
        current_config: Dict[str, Any],
        new_config: Optional[Dict[str, Any]],
    ) -> None:
        """
        Validate that a config change won't cause significant data loss.

        :param Dict current_config: The current configuration
        :param Dict new_config: The proposed new configuration
        :raises ConfigSafetyError: If the change would cause significant data loss
        """
        # Validate new_config is not None or empty when current_config exists
        if new_config is None:
            raise ConfigSafetyError("Cannot save None as configuration")

        if not new_config and current_config:
            raise ConfigSafetyError(
                "Cannot save empty configuration when existing config has data. "
                "Use force=True to override (not recommended)."
            )

        # Check for and auto-convert empty dict values to None - empty dicts break encryption
        empty_dict_keys = self._find_empty_dict_values(new_config)
        if empty_dict_keys:
            logger.debug(
                "Auto-converting empty dict values to None at keys: %s (empty dicts break encryption)",
                sorted(empty_dict_keys),
            )
            self._convert_empty_dicts_to_none_inplace(new_config)

        if not current_config:
            # No existing config, any new config is fine
            return

        current_keys = set(self._flatten_keys(current_config))
        new_keys = set(self._flatten_keys(new_config))

        # Check for lost keys
        lost_keys = current_keys - new_keys
        if not lost_keys:
            return

        # Calculate loss percentage
        loss_percentage = len(lost_keys) / len(current_keys) if current_keys else 0

        # Check for critical keys that should never be lost
        # These keys are essential for CLI operation and should BLOCK, not just warn
        critical_keys = {"domain", "token", "userId"}
        lost_critical = lost_keys & critical_keys

        if lost_critical:
            error_msg = (
                f"Config save blocked: would lose critical keys {sorted(lost_critical)}. "
                "These keys are essential for CLI operation. "
                "Use force=True to override (not recommended)."
            )
            logger.error(error_msg)
            raise ConfigSafetyError(error_msg)

        if loss_percentage > KEY_LOSS_BLOCK_THRESHOLD:
            error_msg = (
                f"Config save blocked: would lose {len(lost_keys)} keys "
                f"({loss_percentage:.1%} of config). "
                f"Lost keys: {sorted(lost_keys)[:10]}{'...' if len(lost_keys) > 10 else ''}"
            )
            logger.error(error_msg)
            raise ConfigSafetyError(error_msg)

        if loss_percentage > KEY_LOSS_WARNING_THRESHOLD:
            logger.warning(
                "Config save will lose %d keys (%.1f%% of config): %s",
                len(lost_keys),
                loss_percentage * 100,
                sorted(lost_keys)[:5],
            )

    def _flatten_keys(self, d: Dict[str, Any], parent_key: str = "") -> Set[str]:
        """
        Flatten nested dictionary keys into dot-notation set.

        :param Dict d: Dictionary to flatten
        :param str parent_key: Parent key prefix
        :return: Set of flattened keys
        :rtype: Set[str]
        """
        keys = set()
        for key, value in d.items():
            full_key = f"{parent_key}.{key}" if parent_key else key
            keys.add(full_key)
            if isinstance(value, dict):
                keys.update(self._flatten_keys(value, full_key))
        return keys

    def _find_empty_dict_values(
        self,
        d: Dict[str, Any],
        parent_key: str = "",
    ) -> Set[str]:
        """
        Find all keys that have empty dict {} as their value.

        Empty dicts can break encryption and should not be saved.

        :param Dict d: Dictionary to check
        :param str parent_key: Parent key prefix for nested paths
        :return: Set of keys with empty dict values
        :rtype: Set[str]
        """
        empty_keys = set()
        for key, value in d.items():
            full_key = f"{parent_key}.{key}" if parent_key else key
            if isinstance(value, dict):
                if not value:
                    # Empty dict found
                    empty_keys.add(full_key)
                else:
                    # Recurse into nested dict
                    empty_keys.update(self._find_empty_dict_values(value, full_key))
        return empty_keys

    def _convert_empty_dicts_to_none_inplace(self, d: Dict[str, Any]) -> None:
        """
        Convert all empty dict {} values to None (recursively, in-place).

        Empty dicts break encryption, but we preserve the key by setting to None.

        :param Dict d: Dictionary to clean (modified in-place)
        """
        keys_to_convert = []
        for key, value in d.items():
            if isinstance(value, dict):
                if value:
                    # Non-empty dict - recurse to clean nested empty dicts
                    self._convert_empty_dicts_to_none_inplace(value)
                else:
                    # Empty dict - mark for conversion to None
                    keys_to_convert.append(key)

        # Convert empty dicts to None
        for key in keys_to_convert:
            d[key] = None

    def _create_backup(self, config: Dict[str, Any]) -> Optional[str]:
        """
        Create a backup of the configuration.

        :param Dict config: Configuration to backup
        :return: Path to backup file, or None if backup failed
        :rtype: Optional[str]
        """
        try:
            # Ensure backup directory exists
            os.makedirs(self._backup_dir, exist_ok=True)

            # Generate backup filename with timestamp
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            backup_name = BACKUP_FILE_PATTERN.replace("*", timestamp)
            backup_path = os.path.join(self._backup_dir, backup_name)

            # Write backup using safe_dump to prevent !!python/object tags from ExampleConfig
            with open(backup_path, "w", encoding="utf-8") as f:
                yaml.safe_dump(sanitize_for_yaml(config), f, default_flow_style=False)

            logger.debug("Created config backup: %s", backup_path)

            # Clean up old backups
            self._cleanup_old_backups()

            return backup_path
        except OSError as e:
            logger.warning("Failed to create config backup: %s", e)
            return None

    def _cleanup_old_backups(self) -> None:
        """Remove old backup files, keeping only the most recent ones."""
        try:
            backup_dir = Path(self._backup_dir)
            if not backup_dir.exists():
                return

            # Get all backup files sorted by modification time
            backups = sorted(
                backup_dir.glob(BACKUP_FILE_PATTERN),
                key=lambda p: p.stat().st_mtime,
                reverse=True,
            )

            # Remove old backups with per-file error handling for race conditions
            for backup in backups[MAX_BACKUPS:]:
                try:
                    backup.unlink()
                    logger.debug("Removed old backup: %s", backup)
                except FileNotFoundError:
                    # Race condition - another process deleted it first
                    logger.debug("Backup already deleted by another process: %s", backup)
        except OSError as e:
            logger.debug("Error cleaning up backups: %s", e)

    def _log_config_changes(
        self,
        current_config: Dict[str, Any],
        new_config: Dict[str, Any],
        reason: str,
    ) -> None:
        """
        Log the changes between current and new configuration.

        :param Dict current_config: Current configuration
        :param Dict new_config: New configuration
        :param str reason: Reason for the change
        """
        current_keys = set(current_config.keys()) if current_config else set()
        new_keys = set(new_config.keys()) if new_config else set()

        added_keys = new_keys - current_keys
        removed_keys = current_keys - new_keys
        common_keys = current_keys & new_keys

        # Count modified keys (simplified - just top level)
        modified_keys = {k for k in common_keys if current_config.get(k) != new_config.get(k)}

        logger.debug(
            "Config change [%s]: +%d keys, -%d keys, ~%d modified",
            reason,
            len(added_keys),
            len(removed_keys),
            len(modified_keys),
        )

        if removed_keys:
            logger.debug("Keys being removed: %s", sorted(removed_keys))
        if added_keys:
            logger.debug("Keys being added: %s", sorted(added_keys))

    def _atomic_write(self, config: Dict[str, Any]) -> None:
        """
        Perform an atomic write of the configuration.

        Uses write-to-temp-then-rename pattern for atomicity.

        :param Dict config: Configuration to write
        :raises OSError: If write fails
        """
        config_dir = os.path.dirname(self._config_path) or "."
        # Ensure the directory exists before creating temp file
        os.makedirs(config_dir, exist_ok=True)
        temp_fd = None
        temp_path = None

        try:
            # Create temp file in same directory for atomic rename
            temp_fd, temp_path = tempfile.mkstemp(
                dir=config_dir,
                prefix=".tmp_config_",
                suffix=".yaml",
                text=True,
            )

            # Write to temp file using safe_dump to prevent !!python/object tags from ExampleConfig
            with os.fdopen(temp_fd, "w", encoding="utf-8") as temp_file:
                temp_fd = None  # fdopen takes ownership
                yaml.safe_dump(sanitize_for_yaml(config), temp_file, default_flow_style=False)
                # Always flush Python buffers to OS
                temp_file.flush()
                # Optionally sync to physical disk for reliability in CI/slow filesystems
                # Set REGSCALE_FSYNC_CONFIG=true to enable (default: false for performance)
                if os.getenv("REGSCALE_FSYNC_CONFIG", "false").lower() == "true":
                    os.fsync(temp_file.fileno())

            # Atomic rename
            os.replace(temp_path, self._config_path)
            temp_path = None  # Successfully moved

            logger.debug("Config saved to %s", self._config_path)
        except Exception:
            # Clean up on failure
            if temp_fd is not None:
                with contextlib.suppress(OSError):
                    os.close(temp_fd)
            if temp_path and os.path.exists(temp_path):
                with contextlib.suppress(OSError):
                    os.unlink(temp_path)
            raise

    def merge_and_save(
        self,
        updates: Dict[str, Any],
        defaults: Optional[Dict[str, Any]] = None,
        reason: str = "merge_update",
    ) -> Dict[str, Any]:
        """
        Merge updates into existing config and save.

        This is the RECOMMENDED way to update configuration:
        - Preserves all existing user values
        - Only adds/updates specified keys
        - Never removes keys unless explicitly requested

        Uses FileLock to wrap the entire read-modify-write operation,
        preventing lost updates from concurrent processes.

        :param Dict updates: Key-value pairs to update
        :param Optional[Dict] defaults: Default values to merge (for missing keys only)
        :param str reason: Reason for the update
        :return: The merged configuration
        :rtype: Dict[str, Any]
        """
        # Use FileLock for the entire read-modify-write operation
        # This prevents another process from writing between our read and write
        if self._enable_file_lock:
            with FileLock(lock_file=self._lock_file, timeout=self._lock_timeout):
                return self._merge_and_save_internal(updates, defaults, reason)
        else:
            return self._merge_and_save_internal(updates, defaults, reason)

    def _merge_and_save_internal(
        self,
        updates: Dict[str, Any],
        defaults: Optional[Dict[str, Any]],
        reason: str,
    ) -> Dict[str, Any]:
        """
        Internal implementation of merge_and_save, called within FileLock context.

        :param Dict updates: Key-value pairs to update
        :param Optional[Dict] defaults: Default values to merge
        :param str reason: Reason for the update
        :return: The merged configuration
        :rtype: Dict[str, Any]
        """
        # Load current config
        current = self.load()

        # Start with current config
        merged = copy.deepcopy(current)

        # Apply defaults for missing keys only
        if defaults:
            merged = self._merge_defaults(merged, defaults)

        # Apply updates (these override existing values)
        merged = self._deep_merge(merged, updates)

        # Save with safety checks (skip file lock since we already hold it)
        self._safe_save_internal(merged, force=False, reason=reason)

        return merged

    def _merge_defaults(
        self,
        config: Dict[str, Any],
        defaults: Dict[str, Any],
    ) -> Dict[str, Any]:
        """
        Merge defaults into config, only adding missing keys.

        :param Dict config: User configuration
        :param Dict defaults: Default values
        :return: Merged configuration
        :rtype: Dict[str, Any]
        """
        result = copy.deepcopy(config)

        for key, default_value in defaults.items():
            if key not in result or result[key] is None or result[key] == "":
                # Key missing or empty - add from defaults
                result[key] = copy.deepcopy(default_value)
            elif isinstance(default_value, dict) and isinstance(result[key], dict):
                # Both are dicts - recurse
                result[key] = self._merge_defaults(result[key], default_value)
            # else: user has a value, preserve it

        return result

    def _deep_merge(
        self,
        base: Dict[str, Any],
        updates: Dict[str, Any],
    ) -> Dict[str, Any]:
        """
        Deep merge updates into base dictionary.

        :param Dict base: Base dictionary
        :param Dict updates: Updates to apply
        :return: Merged dictionary
        :rtype: Dict[str, Any]
        """
        result = copy.deepcopy(base)

        for key, value in updates.items():
            if key in result and isinstance(result[key], dict) and isinstance(value, dict):
                result[key] = self._deep_merge(result[key], value)
            else:
                result[key] = copy.deepcopy(value)

        return result

    def restore_backup(self, backup_path: Optional[str] = None) -> bool:
        """
        Restore configuration from a backup file.

        :param Optional[str] backup_path: Path to backup file (uses latest if None)
        :return: True if restore was successful
        :rtype: bool
        """
        try:
            if backup_path is None:
                # Find the latest backup
                backup_dir = Path(self._backup_dir)
                if not backup_dir.exists():
                    logger.error("No backups found")
                    return False

                backups = sorted(
                    backup_dir.glob(BACKUP_FILE_PATTERN),
                    key=lambda p: p.stat().st_mtime,
                    reverse=True,
                )
                if not backups:
                    logger.error("No backups found in %s", self._backup_dir)
                    return False
                backup_path = str(backups[0])

            # Load backup
            with open(backup_path, encoding="utf-8") as f:
                backup_config = self._yaml_load_tolerant(f)

            if not backup_config:
                logger.error("Backup file is empty: %s", backup_path)
                return False

            # Restore (with force to bypass safety checks)
            self.safe_save(backup_config, force=True, reason="restore_backup")
            logger.info("Restored config from backup: %s", backup_path)
            return True
        except (OSError, yaml.YAMLError) as e:
            logger.error("Failed to restore backup: %s", e)
            return False

    def list_backups(self) -> list:
        """
        List available backup files.

        :return: List of backup file paths with metadata
        :rtype: list
        """
        backup_dir = Path(self._backup_dir)
        if not backup_dir.exists():
            return []

        backups = []
        for backup in sorted(
            backup_dir.glob(BACKUP_FILE_PATTERN),
            key=lambda p: p.stat().st_mtime,
            reverse=True,
        ):
            stat = backup.stat()
            backups.append(
                {
                    "path": str(backup),
                    "name": backup.name,
                    "modified": datetime.fromtimestamp(stat.st_mtime).isoformat(),
                    "size": stat.st_size,
                }
            )
        return backups
