#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Standard imports for RegScale API client.

This module provides the Api class for interacting with the RegScale API.
It supports both the legacy requests library and the newer httpx library
for HTTP communication. The httpx client provides HTTP/2 support, granular
timeouts, and base_url functionality.

To use the legacy requests client, set the environment variable:
    REGSCALE_USE_LEGACY_REQUESTS=true

By default, the httpx client is used for improved performance.
"""

import concurrent.futures
import logging
import os
import re
import threading
import warnings
from pathlib import Path
from typing import TYPE_CHECKING, Any, List, Optional, Tuple, Union

if TYPE_CHECKING:
    from regscale.core.app.application import Application

import httpx
import requests
from requests.adapters import HTTPAdapter, Retry
from rich.progress import Progress
from tenacity import (
    RetryError,
    retry,
    retry_if_exception,
    retry_if_exception_type,
    retry_if_result,
    stop_after_attempt,
    wait_exponential,
)
from urllib3 import disable_warnings
from urllib3.exceptions import InsecureRequestWarning

from regscale.core.app.internal.login import login, verify_token

# Type alias for SSL verification parameter - can be:
# - True: Use system default CA bundle
# - False: Disable SSL verification
# - str: Path to custom CA certificate bundle
VerifyType = Union[bool, str]

BEARER_PREFIX = "Bearer "

# HTTP/2 connection errors that should trigger automatic retry.
# These occur when the server sends a GOAWAY frame or resets the connection,
# which is common under high concurrency with HTTP/2 multiplexing.
_RETRYABLE_CONNECTION_ERRORS = (
    httpx.ConnectError,  # DNS, refused connection
    httpx.ConnectTimeout,  # Failed to establish connection
    httpx.ReadTimeout,  # Server stopped sending data
    httpx.ReadError,  # Connection dropped during read
    httpx.RemoteProtocolError,  # HTTP/2 GOAWAY or protocol issues
    httpx.ProxyError,  # If you are using proxies
)

# Optional: h2 StreamIDTooLowError when HTTP/2 stream IDs are reused after connection reset
try:
    from h2.exceptions import StreamIDTooLowError

    _RETRYABLE_CONNECTION_ERRORS = _RETRYABLE_CONNECTION_ERRORS + (StreamIDTooLowError,)
except ImportError:
    pass


def _is_retryable_http2_stream_error(exception: BaseException) -> bool:
    """Retry on HTTP/2 stream ID errors (e.g. StreamIDTooLowError) without requiring h2 import."""
    name = type(exception).__name__
    if name == "StreamIDTooLowError":
        return True
    msg = str(exception)
    # Match known format "279 is lower than 281" to avoid false positives from unrelated messages
    return " is lower than " in msg and any(c.isdigit() for c in msg)


def _resolve_ca_cert_path(custom_ca_cert: Optional[str], logger: logging.Logger) -> Optional[str]:
    """
    Resolve the CA certificate path from configuration or environment variables.

    Priority order:
    1. customCaCert configuration (from init.yaml or CUSTOMCACERT env var)
    2. SSL_CERT_FILE environment variable
    3. REQUESTS_CA_BUNDLE environment variable
    4. None (use system default CA bundle)

    :param Optional[str] custom_ca_cert: Custom CA cert path from configuration
    :param logging.Logger logger: Logger instance for warnings
    :return: Path to CA certificate bundle or None
    :rtype: Optional[str]
    """
    # Check customCaCert from config first
    if custom_ca_cert:
        ca_path = custom_ca_cert
    # Fall back to SSL_CERT_FILE env var
    elif os.environ.get("SSL_CERT_FILE"):
        ca_path = os.environ["SSL_CERT_FILE"]
        logger.debug("Using SSL_CERT_FILE environment variable: %s", ca_path)
    # Fall back to REQUESTS_CA_BUNDLE env var
    elif os.environ.get("REQUESTS_CA_BUNDLE"):
        ca_path = os.environ["REQUESTS_CA_BUNDLE"]
        logger.debug("Using REQUESTS_CA_BUNDLE environment variable: %s", ca_path)
    else:
        return None

    # Validate that the file exists
    if not Path(ca_path).exists():
        logger.warning(
            "Custom CA certificate file does not exist: %s. "
            "SSL verification may fail. Please verify the path is correct.",
            ca_path,
        )
    else:
        logger.info("Using custom CA certificate: %s", ca_path)

    return ca_path


def _normalize_timeout(timeout: Union[int, str, float], default_timeout: int) -> int:
    """
    Normalize timeout value to integer.

    :param timeout: Timeout value (may be int, str, or float)
    :param default_timeout: Default timeout if conversion fails
    :return: Normalized integer timeout
    :rtype: int
    """
    if isinstance(timeout, (str, float)):
        try:
            return int(timeout)
        except ValueError:
            return default_timeout
    return timeout


def _resolve_ssl_verify(ssl_verify: bool, custom_ca_cert: Optional[str], logger: logging.Logger) -> VerifyType:
    """
    Resolve SSL verification setting.

    :param ssl_verify: Whether SSL verification is enabled
    :param custom_ca_cert: Custom CA certificate path from config
    :param logger: Logger instance
    :return: SSL verification setting (False, True, or path string)
    :rtype: VerifyType
    """
    if not ssl_verify:
        return False

    ca_cert_path = _resolve_ca_cert_path(custom_ca_cert, logger)
    return ca_cert_path if ca_cert_path else True


def _should_retry_httpx_response(response: Optional[httpx.Response]) -> bool:
    """Determine if an httpx response should trigger a retry.

    Args:
        response: The HTTP response to evaluate

    Returns:
        bool: True if the response status indicates a retry should occur
    """
    if response is None:
        return False
    return response.status_code in [429, 500, 502, 503, 504]


class Api:
    """Wrapper for interacting with the RegScale API.

    This class implements a thread-local singleton pattern for efficient
    connection pool reuse. Each thread gets its own Api instance, and
    subsequent calls to Api() within the same thread return the existing
    instance.

    This class provides a unified interface for HTTP communication with the
    RegScale API. It supports two HTTP client backends:

    1. **httpx (default)**: Modern async-capable client with HTTP/2 support,
       granular timeouts, and base_url functionality.
    2. **requests (legacy)**: Traditional synchronous client for backward
       compatibility.

    To use the legacy requests client, set the environment variable:
        REGSCALE_USE_LEGACY_REQUESTS=true

    :param Optional[Application] app: Application object, defaults to None
    :param int timeout: timeout for API calls, defaults to 10
    :param Union[int, str] retry: number of retries for API calls, defaults to 5
    :param Optional[bool] use_legacy_requests: Force use of legacy requests
        client. If None, reads from REGSCALE_USE_LEGACY_REQUESTS env var.

    Example:
        >>> api = Api()  # Returns thread-local singleton
        >>> response = api.get("https://api.example.com/issues")
        >>> data = response.json()

        >>> # Same instance returned within the same thread
        >>> api2 = Api()
        >>> assert api is api2  # True

        >>> # For testing, reset the singleton
        >>> Api.reset_instance()
    """

    _app: "Application"
    app: "Application"
    _retry_log: str = "Retrying request with new token."
    _no_res_text: str = "No response text available"
    _ssl_warning_displayed: bool = False

    # Thread-local singleton storage
    _local: threading.local = threading.local()
    _lock: threading.Lock = threading.Lock()
    _initializing: threading.local = threading.local()

    def __new__(cls, *args, **kwargs) -> "Api":
        """Return thread-local singleton instance.

        This makes Api() fully backward compatible - existing code
        calling Api() gets the singleton without any changes needed.
        Each thread gets its own isolated instance for thread safety.

        :return: Thread-local singleton Api instance
        :rtype: Api
        """
        # Check if we already have an instance for this thread
        if hasattr(cls._local, "instance") and cls._local.instance is not None:
            # Mark that __init__ should be skipped (instance already initialized)
            cls._initializing.skip_init = True
            return cls._local.instance

        # Create new instance using normal object creation
        with cls._lock:
            # Double-check after acquiring lock
            if hasattr(cls._local, "instance") and cls._local.instance is not None:
                cls._initializing.skip_init = True
                return cls._local.instance

            # Create the actual new instance
            instance = super().__new__(cls)
            cls._local.instance = instance
            cls._initializing.skip_init = False
            return instance

    def __init__(
        self,
        timeout: int = int(os.getenv("REGSCALE_TIMEOUT", 10)),
        retry: int = 5,
        use_legacy_requests: Optional[bool] = None,
    ):
        """Initialize Api - only runs once per thread due to singleton pattern.

        :param int timeout: Timeout for API calls, defaults to REGSCALE_TIMEOUT env or 10
        :param int retry: Number of retries for API calls, defaults to 5
        :param Optional[bool] use_legacy_requests: Force use of legacy requests client
        """
        # Skip if this instance was already initialized (singleton returned)
        if getattr(self.__class__._initializing, "skip_init", False):
            return

        from regscale.core.app.application import Application
        from regscale.integrations.variables import ScannerVariables

        self.timeout = _normalize_timeout(timeout, getattr(ScannerVariables, "timeout", 60))
        self.accept = "application/json"
        self.content_type = "application/json"
        self.auth = None
        self._retry_count = retry
        super().__init__()
        self.app = Application()
        self.logger = logging.getLogger("regscale")

        # Resolve SSL verification settings
        custom_ca_cert = getattr(ScannerVariables, "customCaCert", None)
        self.verify: VerifyType = _resolve_ssl_verify(
            getattr(ScannerVariables, "sslVerify", True), custom_ca_cert, self.logger
        )

        # Determine which HTTP client to use
        self._use_legacy_requests = self._should_use_legacy_requests(use_legacy_requests)

        # Configure HTTP client based on selection
        domain = self.config.get("domain") or self.app.retrieve_domain()
        self._base_url = domain
        self._configure_http_client(domain, retry)

        # Apply SSL settings to session
        self._apply_ssl_settings()

        # Override timeout from config if present
        if self.config.get("timeout"):
            self.timeout = self.config["timeout"]

    def _should_use_legacy_requests(self, use_legacy_requests: Optional[bool]) -> bool:
        """Determine if legacy requests client should be used."""
        if use_legacy_requests is None:
            return os.getenv("REGSCALE_USE_LEGACY_REQUESTS", "false").lower() == "true"
        return use_legacy_requests

    def _configure_http_client(self, domain: str, retry: int) -> None:
        """Configure the appropriate HTTP client based on settings."""
        if self._use_legacy_requests:
            self.logger.info("Using legacy requests client")
            domain_prefix = domain[: (domain.find("://") + 3)]
            self.session = self._configure_session(domain_prefix, retry)
            self._httpx_client: Optional[httpx.Client] = None
        else:
            self.logger.info("Using httpx client with HTTP/2 support")
            self._httpx_client = self._configure_httpx_client(retry)
            self.session = self._create_compat_session()

    def _apply_ssl_settings(self) -> None:
        """Apply SSL verification settings to session and show warnings."""
        if self.verify is False:
            self._handle_ssl_disabled()
        elif isinstance(self.verify, str) and self._use_legacy_requests:
            self.session.verify = self.verify

    def _handle_ssl_disabled(self) -> None:
        """Handle SSL disabled state - show warning and configure session."""
        if not Api._ssl_warning_displayed:
            self.logger.warning("SSL Verification has been disabled.")
            Api._ssl_warning_displayed = True
        if self._use_legacy_requests:
            self.session.verify = False
        disable_warnings(InsecureRequestWarning)

    @property
    def config(self) -> dict:
        """
        Get the application config

        :return: Application config
        :rtype: dict
        """
        return self.app.config

    # Hard-coded safety limits to prevent resource exhaustion from misconfiguration
    ABSOLUTE_MAX_POOL_SIZE = 2000  # Maximum connection pool size regardless of config
    ABSOLUTE_MAX_THREADS = 500  # Maximum thread count regardless of config

    def _configure_session(self, domain: str, retry: int = 5) -> requests.Session:
        """
        Configure HTTP session with dynamic connection pooling.

        Pool size scales with maxThreads configuration to prevent thread blocking.
        Formula: pool_size = int(maxThreads * buffer_multiplier)
        Bounds: Configurable via performance.connectionPool.minSize and maxSize

        Safety limits are enforced to prevent resource exhaustion:
        - ABSOLUTE_MAX_THREADS = 500
        - ABSOLUTE_MAX_POOL_SIZE = 2000

        :param str domain: Domain URL prefix (https:// or http://)
        :param int retry: Number of retries for failed requests
        :return: Configured requests Session
        :rtype: requests.Session
        """
        r_session = requests.Session()

        # Get thread configuration with hard limit enforcement
        max_threads = self.config.get("maxThreads", 100)
        if not isinstance(max_threads, int):
            try:
                max_threads = int(max_threads)
            except (ValueError, TypeError):
                self.logger.warning("Invalid maxThreads configuration: %s, using default: 100", max_threads)
                max_threads = 100

        # Enforce absolute maximum for threads to prevent resource exhaustion
        if max_threads > self.ABSOLUTE_MAX_THREADS:
            self.logger.warning(
                "maxThreads=%d exceeds absolute maximum %d, capping at %d",
                max_threads,
                self.ABSOLUTE_MAX_THREADS,
                self.ABSOLUTE_MAX_THREADS,
            )
            max_threads = self.ABSOLUTE_MAX_THREADS

        # Get pool configuration with configurable bounds
        pool_config = self.config.get("performance", {}).get("connectionPool", {})
        buffer_multiplier = pool_config.get("bufferMultiplier", 1.2)

        # Validate bufferMultiplier range to prevent resource exhaustion
        if not isinstance(buffer_multiplier, (int, float)) or buffer_multiplier < 1.0 or buffer_multiplier > 2.0:
            self.logger.warning(
                "Invalid bufferMultiplier=%s (must be between 1.0 and 2.0), using default 1.2", buffer_multiplier
            )
            buffer_multiplier = 1.2

        min_pool_size = pool_config.get("minSize", 200)
        max_pool_size = pool_config.get("maxSize", 1000)

        # Enforce absolute maximum for pool size to prevent resource exhaustion
        if max_pool_size > self.ABSOLUTE_MAX_POOL_SIZE:
            self.logger.warning(
                "connectionPool.maxSize=%d exceeds absolute maximum %d, capping at %d",
                max_pool_size,
                self.ABSOLUTE_MAX_POOL_SIZE,
                self.ABSOLUTE_MAX_POOL_SIZE,
            )
            max_pool_size = self.ABSOLUTE_MAX_POOL_SIZE

        # Calculate pool size with configurable bounds
        pool_size = int(max_threads * buffer_multiplier)
        pool_size = max(min_pool_size, min(pool_size, max_pool_size))

        self.pool_connections = pool_size
        self.pool_maxsize = pool_size

        self.logger.info(
            "Connection pool configured - size: %d, max_threads: %d, bounds: [%d, %d], domain: %s",
            pool_size,
            max_threads,
            min_pool_size,
            max_pool_size,
            domain,
        )

        # Configure retry with 429 (rate limit) support
        self.retries = Retry(
            total=retry,
            backoff_factor=0.1,
            status_forcelist=[429, 500, 502, 503, 504],
            raise_on_status=False,
        )

        # Mount adapter with blocking behavior (threads wait for available connection)
        adapter = HTTPAdapter(
            max_retries=self.retries,
            pool_connections=self.pool_connections,
            pool_maxsize=self.pool_maxsize,
            pool_block=True,  # Block and wait for available connection instead of failing fast
        )

        r_session.mount(domain, adapter)
        # Also mount for http variant
        http_domain = domain.replace("https://", "http://")
        r_session.mount(http_domain, adapter)

        return r_session

    def _configure_httpx_client(self, retry_count: int = 5) -> httpx.Client:
        """
        Configure httpx client with HTTP/2 support and connection pooling.

        :param int retry_count: Number of retries for failed requests (not used directly,
            tenacity handles retries)
        :return: Configured httpx.Client
        :rtype: httpx.Client
        """
        # Get thread configuration with hard limit enforcement
        max_threads = self.config.get("maxThreads", 100)
        if not isinstance(max_threads, int):
            try:
                max_threads = int(max_threads)
            except (ValueError, TypeError):
                self.logger.warning("Invalid maxThreads configuration: %s, using default: 100", max_threads)
                max_threads = 100

        # Enforce absolute maximum for threads
        max_threads = min(max_threads, self.ABSOLUTE_MAX_THREADS)

        # Get pool configuration with configurable bounds
        pool_config = self.config.get("performance", {}).get("connectionPool", {})
        buffer_multiplier = pool_config.get("bufferMultiplier", 1.2)

        # Validate bufferMultiplier range
        if not isinstance(buffer_multiplier, (int, float)) or buffer_multiplier < 1.0 or buffer_multiplier > 2.0:
            buffer_multiplier = 1.2

        min_pool_size = pool_config.get("minSize", 200)
        max_pool_size = min(pool_config.get("maxSize", 1000), self.ABSOLUTE_MAX_POOL_SIZE)

        # Calculate pool size with configurable bounds
        pool_size = int(max_threads * buffer_multiplier)
        pool_size = max(min_pool_size, min(pool_size, max_pool_size))

        self.pool_connections = pool_size
        self.pool_maxsize = pool_size

        # Configure httpx timeout with granular settings
        timeout = httpx.Timeout(
            connect=5.0,
            read=float(self.timeout),
            write=30.0,
            pool=5.0,
        )

        # Configure connection limits
        limits = httpx.Limits(
            max_connections=pool_size,
            max_keepalive_connections=pool_size,
            keepalive_expiry=5.0,
        )

        # Create transport - httpx handles retries differently than requests
        # We use tenacity for retry logic instead of transport-level retries
        # NOTE: When using a custom transport, verify must be passed to HTTPTransport,
        # not just to Client, otherwise SSL verification will still occur even with verify=False
        # NOTE: http2=True must be on the transport itself — setting it only on Client is ignored
        # when a custom transport is provided.
        transport = httpx.HTTPTransport(
            retries=0,  # Retries handled by tenacity decorator
            limits=limits,
            verify=self.verify,  # CRITICAL: Pass verify to transport for SSL settings to take effect
            http2=True,
        )

        # Create the httpx client with HTTP/2 enabled
        client = httpx.Client(
            base_url=self._base_url,
            timeout=timeout,
            verify=self.verify,  # Also pass to client for completeness
            http2=True,
            transport=transport,
            event_hooks={
                "request": [self._log_httpx_request],
                "response": [self._log_httpx_response],
            },
        )

        self.logger.info(
            "httpx client configured - base_url: %s, http2: True, pool_size: %d, retry_count: %d",
            self._base_url,
            pool_size,
            retry_count,
        )

        return client

    def _log_httpx_request(self, request: httpx.Request) -> None:
        """Event hook to log outgoing httpx requests.

        :param httpx.Request request: The HTTP request being sent
        """
        self.logger.debug("httpx %s %s", request.method, request.url)

    def _log_httpx_response(self, response: httpx.Response) -> None:
        """Event hook to log received httpx responses.

        :param httpx.Response response: The HTTP response received
        """
        self.logger.debug(
            "httpx %s %s - Status: %d",
            response.request.method,
            response.request.url,
            response.status_code,
        )

    def _create_compat_session(self) -> requests.Session:
        """
        Create a minimal requests.Session for backward compatibility.

        This session is used when httpx is the primary client but some
        code still expects a session attribute.

        :return: Minimal requests.Session
        :rtype: requests.Session
        """
        session = requests.Session()
        session.verify = self.verify
        return session

    def _httpx_request_with_retry(
        self,
        method: str,
        url: str,
        headers: Optional[dict] = None,
        json: Optional[Union[dict, str, list]] = None,
        data: Optional[dict] = None,
        files: Optional[Any] = None,
        params: Optional[Any] = None,
        timeout: Optional[float] = None,
    ) -> httpx.Response:
        """
        Make an httpx request with tenacity retry support.

        :param str method: HTTP method (GET, POST, PUT, DELETE)
        :param str url: URL for the request
        :param Optional[dict] headers: Request headers
        :param Optional[Union[dict, str, list]] json: JSON body
        :param Optional[dict] data: Form data
        :param Optional[Any] files: Files to upload
        :param Optional[Any] params: Query parameters
        :param Optional[float] timeout: Request timeout override
        :return: HTTP response
        :rtype: httpx.Response
        """
        if self._httpx_client is None:
            raise RuntimeError("httpx client not initialized")

        # Build request kwargs
        request_kwargs: dict = {}
        if headers is not None:
            request_kwargs["headers"] = headers
        if json is not None:
            request_kwargs["json"] = json
        if data is not None:
            request_kwargs["data"] = data
        if files is not None:
            request_kwargs["files"] = files
        if params is not None:
            request_kwargs["params"] = params
        if timeout is not None:
            request_kwargs["timeout"] = timeout

        @retry(
            stop=stop_after_attempt(self._retry_count),
            wait=wait_exponential(multiplier=0.1, max=10),
            retry=(
                retry_if_result(_should_retry_httpx_response)
                | retry_if_exception_type(_RETRYABLE_CONNECTION_ERRORS)
                | retry_if_exception(_is_retryable_http2_stream_error)
            ),
            reraise=True,
        )
        def _do_request() -> httpx.Response:
            return self._httpx_client.request(method, url, **request_kwargs)

        try:
            return _do_request()
        except RetryError as e:
            # Extract the actual response from the last retry attempt
            # instead of losing it and returning None upstream
            last_attempt = e.last_attempt
            if last_attempt and not last_attempt.failed:
                result = last_attempt.result()
                if isinstance(result, httpx.Response):
                    self.logger.warning(
                        "Request to %s exhausted %d retries (status: %d)",
                        url,
                        self._retry_count,
                        result.status_code,
                    )
                    return result
            raise

    def _convert_httpx_to_requests_response(self, httpx_response: httpx.Response) -> requests.Response:
        """
        Convert an httpx.Response to a requests.Response for API compatibility.

        This allows code that expects requests.Response objects to work
        transparently with the httpx backend.

        :param httpx.Response httpx_response: The httpx response
        :return: Equivalent requests.Response object
        :rtype: requests.Response
        """
        # Create a requests Response object
        response = requests.Response()
        response.status_code = httpx_response.status_code
        response._content = httpx_response.content
        response.headers.update(dict(httpx_response.headers))
        response.url = str(httpx_response.url)
        response.reason = httpx_response.reason_phrase or ""
        response.encoding = httpx_response.encoding

        # Set cookies if present (httpx cookies iteration yields name strings)
        for name, value in httpx_response.cookies.items():
            response.cookies.set(name, value)

        return response

    def get(
        self,
        url: str,
        headers: Optional[dict] = None,
        params: Optional[Union[list, Tuple]] = None,
        retry_login: bool = True,
        merge_headers: bool = False,
    ) -> Optional[requests.models.Response]:
        """
        Get Request for API

        :param str url: URL for API call
        :param dict headers: headers for the api get call, defaults to None
        :param Optional[Union[list, Tuple]] params: Any parameters for the API call, defaults to None
        :param bool retry_login: Whether to retry login on 401 Unauthorized responses, defaults to True
        :param bool merge_headers: Whether to merge headers, defaults to False
        :return: Requests response
        :rtype: Optional[requests.models.Response]
        """
        url = normalize_url(url)
        headers = self._handle_headers(headers, merge_headers)
        response = None

        try:
            self.logger.debug("GET: %s", url)

            if self._use_legacy_requests:
                # Legacy requests client path
                if self.auth:
                    self.session.auth = self.auth
                response = self.session.get(
                    url=url,
                    headers=headers,
                    params=params,
                    timeout=self.timeout,
                )
            else:
                # httpx client path
                httpx_response = self._httpx_request_with_retry(
                    method="GET",
                    url=url,
                    headers=headers,
                    params=params,
                    timeout=float(self.timeout),
                )
                response = self._convert_httpx_to_requests_response(httpx_response)

            if response.status_code == 401 and self._handle_401(retry_login):
                self.logger.debug(self._retry_log)
                response = self.get(url=url, headers=headers, params=params, retry_login=False)
            return response
        except Exception as e:
            self._log_response_error(url, e, response)
            return response
        finally:
            resp_text = getattr(response, "text", self._no_res_text)
            self.logger.debug(f"{resp_text[:500]}..." if len(str(resp_text)) > 500 else resp_text)

    def delete(
        self,
        url: str,
        headers: Optional[dict] = None,
        retry_login: bool = True,
        merge_headers: bool = False,
    ) -> Optional[requests.models.Response]:
        """
        Delete data using API

        :param str url: URL for the API call
        :param Optional[dict] headers: headers for the API call, defaults to None
        :param bool retry_login: Whether to retry login on 401 Unauthorized responses, defaults to True
        :param bool merge_headers: Whether to merge headers, defaults to False
        :return: API response
        :rtype: Optional[requests.models.Response]
        """
        url = normalize_url(url)
        headers = self._handle_headers(headers, merge_headers)
        response = None

        try:
            self.logger.debug("DELETE: %s", url)

            if self._use_legacy_requests:
                # Legacy requests client path
                if self.auth:
                    self.session.auth = self.auth
                response = self.session.delete(
                    url=url,
                    headers=headers,
                    timeout=self.timeout,
                )
            else:
                # httpx client path
                httpx_response = self._httpx_request_with_retry(
                    method="DELETE",
                    url=url,
                    headers=headers,
                    timeout=float(self.timeout),
                )
                response = self._convert_httpx_to_requests_response(httpx_response)

            if response.status_code == 401 and self._handle_401(retry_login):
                self.logger.debug(self._retry_log)
                response = self.delete(url=url, headers=headers, retry_login=False)
            return response
        except Exception as e:
            self._log_response_error(url, e, response)
            return response
        finally:
            self.logger.debug(getattr(response, "text", self._no_res_text))

    def post(
        self,
        url: str,
        headers: Optional[dict] = None,
        json: Optional[Union[dict, str, list]] = None,
        data: Optional[dict] = None,
        files: Optional[list] = None,
        params: Any = None,
        retry_login: bool = True,
        merge_headers: bool = False,
    ) -> Optional[requests.models.Response]:
        """
        Post data to API

        :param str url: URL for the API call
        :param dict headers: Headers for the API call, defaults to None
        :param Optional[Union[dict, str, list]] json: Dictionary of data for the API call, defaults to None
        :param dict data: Dictionary of data for the API call, defaults to None
        :param list files: Files to post during API call, defaults to None
        :param Any params: Any parameters for the API call, defaults to None
        :param bool retry_login: Whether to retry login on 401 Unauthorized responses, defaults to True
        :param bool merge_headers: Whether to merge headers, defaults to False
        :return: API response
        :rtype: Optional[requests.models.Response]
        """
        url = normalize_url(url)
        headers = self._handle_headers(headers, merge_headers)
        response = None

        # Do not send Authorization headers if validateToken in endpoint
        if "validateToken" in url:
            headers.pop("Authorization", None)

        try:
            self.logger.debug("POST: %s", url)

            if self._use_legacy_requests:
                # Legacy requests client path
                if self.auth:
                    self.session.auth = self.auth
                if not json and data:
                    response = self.session.post(
                        url=url,
                        headers=headers,
                        data=data,
                        files=files,
                        params=params,
                        timeout=self.timeout,
                    )
                else:
                    response = self.session.post(
                        url=url,
                        headers=headers,
                        json=json,
                        files=files,
                        params=params,
                        timeout=self.timeout,
                    )
            else:
                # httpx client path
                httpx_response = self._httpx_request_with_retry(
                    method="POST",
                    url=url,
                    headers=headers,
                    json=json if json else None,
                    data=data,
                    files=files,
                    params=params,
                    timeout=float(self.timeout),
                )
                response = self._convert_httpx_to_requests_response(httpx_response)

            if getattr(response, "status_code", 0) == 401 and self._handle_401(retry_login):
                self.logger.debug(self._retry_log)
                response = self.post(
                    url=url,
                    headers=headers,
                    json=json,
                    data=data,
                    files=files,
                    params=params,
                    retry_login=False,
                )
            return response
        except Exception as e:
            self._log_response_error(url, e, response)
            return response
        finally:
            self.logger.debug(getattr(response, "text", self._no_res_text))

    def put(
        self,
        url: str,
        headers: Optional[dict] = None,
        json: Optional[Union[dict, List[dict]]] = None,
        params: Optional[Union[list, Tuple]] = None,
        retry_login: bool = True,
        merge_headers: bool = False,
    ) -> Optional[requests.models.Response]:
        """
        Update data via API call

        :param str url: URL for the API call
        :param Optional[dict] headers: Headers for the API call, defaults to None
        :param Optional[Union[dict, List[dict]]] json: Dictionary of data for the API call, defaults to None
        :param Optional[Union[list, Tuple]] params: Any parameters for the API call, defaults to None
        :param bool retry_login: Whether to retry login on 401 Unauthorized responses, defaults to True
        :param bool merge_headers: Whether to merge headers, defaults to False
        :return: API response
        :rtype: Optional[requests.models.Response]
        """
        url = normalize_url(url)
        headers = self._handle_headers(headers, merge_headers)
        response = None

        try:
            self.logger.debug("PUT: %s", url)

            if self._use_legacy_requests:
                # Legacy requests client path
                if self.auth:
                    self.session.auth = self.auth
                response = self.session.put(
                    url=url,
                    headers=headers,
                    json=json,
                    params=params,
                    timeout=self.timeout,
                )
            else:
                # httpx client path
                httpx_response = self._httpx_request_with_retry(
                    method="PUT",
                    url=url,
                    headers=headers,
                    json=json,
                    params=params,
                    timeout=float(self.timeout),
                )
                response = self._convert_httpx_to_requests_response(httpx_response)

            if getattr(response, "status_code", 0) == 401 and self._handle_401(retry_login):
                self.logger.debug(self._retry_log)
                response = self.put(
                    url=url,
                    headers=headers,
                    json=json,
                    params=params,
                    retry_login=False,
                )
            return response
        except Exception as e:
            self._log_response_error(url, e, response)
            return response
        finally:
            self.logger.debug(getattr(response, "text", self._no_res_text))

    def _log_graphql_errors(self, errors: list, query: str) -> None:
        """Log GraphQL errors with context."""
        self.logger.error("GraphQL query returned %d errors:", len(errors))
        for error in errors:
            self.logger.error("Message: %s", error.get("message"))
            self.logger.error("Locations: %s", error.get("locations"))
            self.logger.error("Path: %s", error.get("path"))
        self.logger.error("Query that caused the error: %s", query, exc_info=True)

    def _calculate_next_skip(self, query: str, items_count: int) -> str:
        """Calculate and update the skip value in the query for pagination"""
        old_skip_match = re.search(r"skip: (\d+)", query)
        if old_skip_match:
            old_skip = int(old_skip_match.group(1))
            new_skip = old_skip + items_count
            return query.replace(f"skip: {old_skip}", f"skip: {new_skip}")
        new_skip = items_count
        return query.replace("(", f"(skip: {new_skip}\n", 1)

    def _check_and_update_pagination(
        self, response_data: dict, res_data: Optional[dict], query: str
    ) -> tuple[bool, str]:
        """Check if pagination is needed and update query accordingly"""
        pagination_flag = False
        for key, value in response_data.items():
            if res_data:
                res_data[key]["items"].extend(response_data[key]["items"])
            try:
                if value.get("pageInfo", {}).get("hasNextPage") is True:
                    pagination_flag = True
                    query = self._calculate_next_skip(query, len(response_data[key]["items"]))
                    if not res_data:
                        break
            except (KeyError, AttributeError):
                continue
        return pagination_flag, query

    def _check_pagination_info(self, value: dict, page_count: int, key: str, new_items: list) -> bool:
        """Check if there's a next page in the pagination info."""
        page_info = value.get("pageInfo")
        if page_info is None:
            if page_count == 1 and new_items:
                self.logger.debug(
                    "graphql_pagination_info_missing key=%s - pagination may not work correctly",
                    key,
                )
            return False
        if isinstance(page_info, dict):
            if "hasNextPage" not in page_info:
                self.logger.debug("graphql_hasNextPage_missing key=%s - response may be incomplete", key)
                return False
            return page_info.get("hasNextPage") is True
        return False

    def _process_graphql_response_data(
        self, response_data: dict, accumulated_data: dict, page_count: int
    ) -> tuple[bool, int]:
        """Process GraphQL response data and return (has_next_page, items_in_page)."""
        has_next_page = False
        items_in_page = 0

        for key, value in response_data.items():
            if key not in accumulated_data:
                accumulated_data[key] = {"items": []}

            if isinstance(value, dict) and "items" in value:
                new_items = value.get("items", [])
                accumulated_data[key]["items"].extend(new_items)
                items_in_page += len(new_items)
                if self._check_pagination_info(value, page_count, key, new_items):
                    has_next_page = True

        return has_next_page, items_in_page

    def _update_query_skip(self, query: str, items_in_page: int) -> str:
        """Update the skip value in query for pagination."""
        old_skip_match = re.search(r"skip: (\d+)", query)
        if old_skip_match:
            old_skip = int(old_skip_match.group(1))
            return query.replace(f"skip: {old_skip}", f"skip: {old_skip + items_in_page}")
        return query.replace("(", f"(skip: {items_in_page}\n", 1)

    def _add_total_counts(self, accumulated_data: dict) -> None:
        """Add totalCount to accumulated data for backward compatibility."""
        for key in accumulated_data:
            if isinstance(accumulated_data[key], dict) and "items" in accumulated_data[key]:
                accumulated_data[key]["totalCount"] = len(accumulated_data[key]["items"])

    def _fetch_graphql_page(self, url: str, headers: dict, query: str) -> tuple[Optional[dict], Optional[Exception]]:
        """
        Fetch a single page of GraphQL data.

        :param str url: URL for the GraphQL endpoint
        :param dict headers: Headers for the API call
        :param str query: The GraphQL query to execute
        :return: Tuple of (response_data, error) - error is None on success
        :rtype: tuple[Optional[dict], Optional[Exception]]
        """
        try:
            normalized_url = normalize_url(url)

            if self._use_legacy_requests:
                # Legacy requests client path
                response = self.session.post(
                    url=normalized_url, headers=headers, json={"query": query}, timeout=self.timeout
                )
                response_json = response.json()
            else:
                # httpx client path with HTTP/2 for better multiplexing
                httpx_response = self._httpx_request_with_retry(
                    method="POST",
                    url=normalized_url,
                    headers=headers,
                    json={"query": query},
                    timeout=float(self.timeout),
                )
                response_json = httpx_response.json()

            if "errors" in response_json:
                self._log_graphql_errors(response_json["errors"], query)
                return None, None  # Signal to stop without exception

            return response_json.get("data", {}), None
        except (requests.exceptions.JSONDecodeError, ValueError) as err:
            # ValueError catches JSON decode errors from both requests and httpx
            self.logger.error("graphql_json_decode_error error=%s", err)
            return None, err
        except KeyError as err:
            self.logger.error("graphql_no_items_returned url=%s error=%s", url, err)
            return None, err
        except Exception as e:
            self.logger.error("graphql_request_exception error=%s", str(e), exc_info=True)
            return None, e

    def graph(
        self,
        query: str,
        url: Optional[str] = None,
        headers: Optional[dict] = None,
        res_data: Optional[dict] = None,
        merge_headers: bool = False,
        max_pages: int = 10000,
    ) -> dict:
        """
        Execute GraphQL query with iterative pagination (no recursion).

        Uses HTTP/2 multiplexing when httpx client is enabled for improved
        performance with paginated queries.

        :param str query: the GraphQL query to execute
        :param Optional[str] url: URL for the API call, defaults to None
        :param Optional[dict] headers: Headers for the API call, defaults to None
        :param Optional[dict] res_data: dictionary of data from GraphQL response (for backward compatibility)
        :param bool merge_headers: Whether to merge headers, defaults to False
        :param int max_pages: Maximum pages to fetch (safety limit), defaults to 10000
        :return: Dictionary response from GraphQL API
        :rtype: dict
        """
        self.logger.debug("STARTING NEW GRAPH CALL (ITERATIVE) - httpx=%s", not self._use_legacy_requests)
        # Use longer timeout for GraphQL operations (90 seconds)
        self.timeout = 90

        # Set auth for legacy requests session if provided
        if self.auth and self._use_legacy_requests:
            self.session.auth = self.auth

        headers = self._handle_headers(headers, merge_headers)
        if "skip" not in query:
            query = query.replace("(", "(skip: 0\n")

        url = normalize_url(f"{self.config['domain']}/graphql" if url is None else url)
        self.logger.debug("url=%s query=%s", url, query)

        accumulated_data = res_data if res_data else {}
        page_count = 0
        total_items = 0

        while page_count < max_pages:
            page_count += 1
            response_data, error = self._fetch_graphql_page(url, headers, query)

            if error is not None or response_data is None:
                break

            has_next_page, items_in_page = self._process_graphql_response_data(
                response_data, accumulated_data, page_count
            )
            total_items += items_in_page

            self.logger.debug(
                "graphql_page_fetched page=%d items=%d total=%d has_next=%s",
                page_count,
                items_in_page,
                total_items,
                has_next_page,
            )

            if not has_next_page:
                break
            query = self._update_query_skip(query, items_in_page)

        if page_count >= max_pages:
            self.logger.warning("graphql_pagination_limit_reached max_pages=%d total_items=%d", max_pages, total_items)

        if total_items > 0:
            self.logger.info("graphql_completed pages=%d total_items=%d", page_count, total_items)
        else:
            self.logger.debug("graphql_completed pages=%d total_items=%d", page_count, total_items)
        self._add_total_counts(accumulated_data)

        return accumulated_data

    def _get_max_workers(self) -> int:
        """Get max workers for thread pool, ensuring it's an integer."""
        max_workers = self.config.get("maxThreads", 100)
        if isinstance(max_workers, int):
            return max_workers
        try:
            return int(max_workers)
        except (ValueError, TypeError):
            return 100

    def _create_futures_for_method(
        self, executor: concurrent.futures.ThreadPoolExecutor, method: str, url: str, headers: dict, json_list: list
    ) -> list:
        """Create futures based on HTTP method."""
        method_lower = method.lower()
        if method_lower == "post":
            return [executor.submit(self.post, url, headers, x) for x in json_list]
        if method_lower == "put":
            return [executor.submit(self.put, f"{url}/{x['id']}", headers, x) for x in json_list]
        if method_lower == "delete":
            return [executor.submit(self.delete, f"{url}/{x['id']}", headers) for x in json_list]
        return []

    def _process_future_result(self, future: concurrent.futures.Future) -> None:
        """Process a single future result, logging warnings for non-200 responses."""
        try:
            result = future.result()
            if result and result.status_code != 200:
                self.logger.warning(
                    "Status code is %s: %s from %s.",
                    result.status_code,
                    result.text,
                    result.url,
                )
        except Exception as ex:
            self.logger.error("Error is %s, type: %s", ex, type(ex))

    def update_server(
        self,
        url: str,
        headers: Optional[dict] = None,
        json_list: Optional[list] = None,
        method: str = "post",
        config: Optional[dict] = None,
        message: str = "Working",
    ) -> None:
        """
        Concurrent Post or Put of multiple objects

        The 'update_server' method is deprecated, use 'RegScaleModel' create or update methods instead

        :param str url: URL for the API call
        :param Optional[dict] headers: Headers for the API call, defaults to None
        :param Optional[list] json_list: Dictionary of data for the API call, defaults to None
        :param str method: Method for API to use, defaults to "post"
        :param Optional[dict] config: Config for the API, defaults to None
        :param str message: Message to display in console, defaults to "Working"
        :rtype: None
        """
        warnings.warn(
            "The 'update_server' method is deprecated, use 'RegScaleModel' create or update methods instead",
            DeprecationWarning,
        )
        if headers is None and config:
            headers = {"Accept": self.accept, "Authorization": config["token"]}

        if not json_list:
            return

        with Progress(transient=False) as progress:
            task = progress.add_task(message, total=len(json_list))
            with concurrent.futures.ThreadPoolExecutor(max_workers=self._get_max_workers()) as executor:
                result_futures = self._create_futures_for_method(executor, method, url, headers, json_list)
                for future in concurrent.futures.as_completed(result_futures):
                    self._process_future_result(future)
                    progress.update(task, advance=1)

    def _log_response_error(
        self,
        url: str,
        error: Exception,
        response: Optional[requests.Response],
    ) -> None:
        """
        Log error messages from API responses

        :param str url: URL for the API call
        :param Exception error: Exception message
        :param Optional[requests.Response] response: API response
        :param str url: URL for the API call
        """
        if response is None:
            self.logger.error("Received unexpected response from %s: %s", url, error)
        else:
            self.logger.error(
                "Received unexpected response from %s %s\nStatus code %s: %s\nText: %s",
                url,
                error,
                response.status_code,
                response.reason,
                response.text,
            )

    def _handle_login_on_401(
        self,
        retry_login: bool = True,
    ) -> bool:
        """
        Handle login on 401 Unauthorized responses

        :param bool retry_login: Whether to retry login or not, defaults to True
        :return: Whether login was successful
        :rtype: bool
        """
        token = self.config.get("token")
        if token and BEARER_PREFIX in token:
            token = token.split(BEARER_PREFIX)[1]
        self.logger.debug("verifying token")
        is_token_valid = verify_token(app=self.app, token=token)
        self.logger.debug(f"is token valid: {is_token_valid}")
        if not is_token_valid:
            self.logger.debug("getting new token")
            new_token = login(
                app=self.app,
                str_user=os.getenv("REGSCALE_USERNAME"),
                str_password=os.getenv("REGSCALE_PASSWORD"),
                host=self.config["domain"],
            )
            self.logger.debug("Token: %s", new_token[:20])
            return retry_login
        return False

    def _handle_401(self, retry_login: bool) -> bool:
        """
        Handle 401 Unauthorized responses.

        :param bool retry_login: Whether to retry login
        :return: True if login was retried, False otherwise
        :rtype: bool
        """
        if self._handle_login_on_401(retry_login=retry_login):
            self.logger.debug("Retrying request with new token.")
            return True
        return False

    def _handle_headers(self, headers: Optional[dict], merge_headers=False) -> dict:
        """
        Handle headers for API calls

        :param Optional[dict] headers: Headers for the API call
        :param bool merge_headers: Whether to merge headers with defaults
        :return: Dictionary of headers
        :rtype: dict
        """
        default_headers = {
            "accept": self.accept,
            "Content-Type": self.content_type,
        }
        if token := self.config.get("token"):
            # Ensure token has Bearer prefix for Authorization header
            if not token.startswith(BEARER_PREFIX):
                token = f"{BEARER_PREFIX}{token}"
            default_headers["Authorization"] = token

        if headers is None:
            headers = default_headers

        headers = headers or {}

        if merge_headers:
            return {**default_headers, **headers}

        return headers

    @classmethod
    def get_instance(cls) -> "Api":
        """Get thread-local singleton instance explicitly.

        Note: Api() now returns the singleton automatically, so this method
        is optional but provides clarity of intent when you want to make
        the singleton pattern explicit in your code.

        :return: Thread-local singleton Api instance
        :rtype: Api

        Example:
            >>> api = Api.get_instance()
            >>> response = api.get("/api/issues")
        """
        return cls()  # __new__ handles singleton logic

    @classmethod
    def reset_instance(cls) -> None:
        """Reset thread-local singleton instance.

        Call this in test fixtures to ensure clean state between tests.
        This method closes any open connections before resetting.

        :rtype: None

        Example:
            >>> # In test teardown
            >>> Api.reset_instance()
        """
        if hasattr(cls._local, "instance") and cls._local.instance is not None:
            instance = cls._local.instance
            # Clean up resources
            if hasattr(instance, "_httpx_client") and instance._httpx_client:
                try:
                    instance._httpx_client.close()
                except Exception:
                    pass
            if hasattr(instance, "session") and instance.session:
                try:
                    instance.session.close()
                except Exception:
                    pass
            cls._local.instance = None

    @classmethod
    def _force_new_instance(cls) -> "Api":
        """Force creation of a new instance (bypasses singleton).

        Use only for testing or special cases where isolation is required.
        The returned instance is NOT stored as the singleton.

        :return: New isolated Api instance
        :rtype: Api

        Example:
            >>> # In tests requiring isolated Api instances
            >>> isolated_api = Api._force_new_instance()
        """
        instance = object.__new__(cls)
        # Manually run init by ensuring skip_init is False
        cls._initializing.skip_init = False
        instance.__init__()
        return instance

    def close(self) -> None:
        """Explicitly close HTTP connections.

        Note: On singleton, this closes the shared connections. The next
        request will attempt to use closed connections, which may cause errors.
        Use reset_instance() for full cleanup and re-initialization.

        :rtype: None
        """
        if self._httpx_client:
            self._httpx_client.close()
            self._httpx_client = None
        if self._use_legacy_requests and self.session:
            self.session.close()


def normalize_url(url: str) -> str:
    """
    Function to remove extra slashes and trailing slash from a given URL

    :param str url: URL string normalize
    :return: A normalized URL
    :rtype: str
    """
    segments = url.split("/")
    correct_segments = [segment for segment in segments if segment != ""]
    first_segment = str(correct_segments[0])
    if "http" not in first_segment:
        correct_segments = ["http:"] + correct_segments
    correct_segments[0] = f"{correct_segments[0]}/"
    return "/".join(correct_segments)
