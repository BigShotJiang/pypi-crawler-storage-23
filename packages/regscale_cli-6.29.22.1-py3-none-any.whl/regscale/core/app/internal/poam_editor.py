#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Module to allow user to make changes to issues in an excel spreadsheet for user friendly experience"""

# standard python imports
import os
import shutil
from pathlib import Path
from typing import TYPE_CHECKING, Any

import click
from openpyxl import Workbook, load_workbook
from openpyxl.styles import NamedStyle, Protection
from openpyxl.worksheet.datavalidation import DataValidation
from rich.console import Console
from rich.table import Table

if TYPE_CHECKING:
    import polars as pl

from regscale.core.app.logz import create_logger
from regscale.core.app.utils.app_utils import (
    check_empty_nan,
    check_file_path,
    error_and_exit,
    get_current_datetime,
    get_user_names,
    reformat_str_date,
)
from regscale.models.app_models.click import regscale_id, regscale_module
from regscale.models.regscale_models.issue import Issue

logger = create_logger()

# Constants for file names
ALL_ISSUES_XLSX = "all_issues.xlsx"
OLD_ISSUES_XLSX = "old_issues.xlsx"
DIFFERENCES_TXT = "differences.txt"

# Constants for error messages
ERROR_NOT_AVAILABLE_OPTION = "Your entry is not one of the available options"
ERROR_INVALID_ENTRY = "Invalid Entry"
PROMPT_SELECT_FROM_LIST = "Please select from the list"
ERROR_NOT_VALID_OPTION = "Your entry is not a valid option"


def _write_df_to_excel(df: "pl.DataFrame", file_path: str, sheet_name: str) -> None:
    """
    Write a polars DataFrame to an Excel sheet using openpyxl.

    :param pl.DataFrame df: The DataFrame to write
    :param str file_path: Path to the Excel file
    :param str sheet_name: Name of the sheet to write to
    """
    workbook = load_workbook(file_path)

    # Check if sheet exists, if so remove it first
    if sheet_name in workbook.sheetnames:
        del workbook[sheet_name]

    worksheet = workbook.create_sheet(sheet_name)

    # Write headers
    for col_idx, col_name in enumerate(df.columns, 1):
        worksheet.cell(row=1, column=col_idx, value=col_name)

    # Write data
    for row_idx, row in enumerate(df.iter_rows(named=True), 2):
        for col_idx, col_name in enumerate(df.columns, 1):
            worksheet.cell(row=row_idx, column=col_idx, value=row[col_name])

    workbook.save(file_path)


def _find_dataframe_differences(df1: "pl.DataFrame", df2: "pl.DataFrame") -> list[dict]:
    """
    Find differences between two DataFrames and return a list of changes.

    :param pl.DataFrame df1: The original DataFrame
    :param pl.DataFrame df2: The updated DataFrame
    :return: List of dictionaries containing Id, Column, From, and To values
    :rtype: list[dict]
    """
    changes = []
    id_col = "Id"

    # Get common columns (excluding Id)
    common_cols = [col for col in df1.columns if col in df2.columns and col != id_col]

    # Convert to dictionaries keyed by Id for easier comparison
    df1_dict = {row[id_col]: row for row in df1.iter_rows(named=True)}
    df2_dict = {row[id_col]: row for row in df2.iter_rows(named=True)}

    # Find differences
    for row_id in df2_dict:
        if row_id in df1_dict:
            for col in common_cols:
                old_val = df1_dict[row_id][col]
                new_val = df2_dict[row_id][col]
                # Handle None/null comparisons
                if old_val != new_val and not (old_val is None and new_val is None):
                    changes.append(
                        {
                            "Id": row_id,
                            "Column": col,
                            "From": old_val,
                            "To": new_val,
                        }
                    )

    return changes


@click.group(name="issues")
def issues():
    """
    Performs actions on POAM CLI Feature to update issues to RegScale.
    """


@issues.command(name="generate")
@regscale_id()
@regscale_module()
@click.option(
    "--path",
    type=click.Path(exists=False, dir_okay=True, path_type=Path),
    help="Provide the desired path for excel files to be generated into.",
    default=os.path.join(os.getcwd(), "artifacts"),
    required=True,
)
def generate_all_issues(regscale_id: int, regscale_module: str, path: Path):
    """
    This function will build and populate a spreadsheet of all issues
    with the selected RegScale Parent Id and RegScale Module for users to make any neccessary edits.

    """
    all_issues(regscale_id=regscale_id, regscale_module=regscale_module, path=path)


def _format_issue_owner(issue_owner: dict | None) -> str:
    """
    Format issue owner information into a string.

    :param dict | None issue_owner: Issue owner dictionary
    :return: Formatted owner string
    :rtype: str
    """
    if not issue_owner:
        return "None"
    return (
        f"{str(issue_owner['lastName']).strip()}, "
        f"{str(issue_owner['firstName']).strip()} "
        f"({str(issue_owner['userName']).strip()})"
    )


def _safe_get_value(issue: dict, key: str, default: str = "") -> str:
    """
    Safely get a value from issue dictionary with default.

    :param dict issue: Issue dictionary
    :param str key: Key to retrieve
    :param str default: Default value if key not found
    :return: Value or default
    :rtype: str
    """
    return issue.get(key) or default


def _safe_get_numeric(issue: dict, key: str, default: float = 0.0) -> float:
    """
    Safely get numeric value from issue dictionary.

    :param dict issue: Issue dictionary
    :param str key: Key to retrieve
    :param float default: Default value
    :return: Numeric value or default
    :rtype: float
    """
    value = issue.get(key)
    if value and value != "None":
        return float(value)
    return default


def _safe_get_string(issue: dict, key: str, default: str = "None") -> str:
    """
    Safely get string value from issue dictionary.

    :param dict issue: Issue dictionary
    :param str key: Key to retrieve
    :param str default: Default value
    :return: String value or default
    :rtype: str
    """
    value = issue.get(key)
    return value if value else default


def _process_single_issue(issue: dict) -> list:
    """
    Process a single issue record into a list of values.

    :param dict issue: Single issue dictionary from API
    :return: List of issue field values
    :rtype: list
    """
    issue_id = issue["id"]
    issue_owner = _format_issue_owner(issue.get("issueOwner"))
    title = issue["title"]
    date_created = reformat_str_date(issue["dateCreated"])
    description = _safe_get_string(issue, "description")
    severity_level = issue["severityLevel"]
    cost_estimate = _safe_get_numeric(issue, "costEstimate", 0.00)
    level_of_effort = int(_safe_get_numeric(issue, "levelOfEffort", 0))
    due_date = reformat_str_date(issue["dueDate"])
    identification = _safe_get_string(issue, "identification")
    status = _safe_get_string(issue, "status")
    date_completed = reformat_str_date(issue["dateCompleted"]) if issue.get("dateCompleted") else ""
    activities_observed = _safe_get_value(issue, "activitiesObserved")
    failures_observed = _safe_get_value(issue, "failuresObserved")
    requirements_violated = _safe_get_value(issue, "requirementsViolated")
    safety_impact = _safe_get_value(issue, "safetyImpact")
    security_impact = _safe_get_value(issue, "securityImpact")
    quality_impact = _safe_get_value(issue, "qualityImpact")
    security_checks = _safe_get_value(issue, "securityChecks")
    recommended_actions = _safe_get_value(issue, "recommendedActions")

    return [
        issue_id,
        issue_owner,
        title,
        date_created,
        description,
        severity_level,
        cost_estimate,
        level_of_effort,
        due_date,
        identification,
        status,
        date_completed,
        activities_observed,
        failures_observed,
        requirements_violated,
        safety_impact,
        security_impact,
        quality_impact,
        security_checks,
        recommended_actions,
    ]


def _process_issue_data(raw_data: list[dict]) -> "pl.DataFrame":
    """
    Process raw issue data into a polars DataFrame.

    :param list[dict] raw_data: Raw issue data from API
    :return: DataFrame with processed issue data
    :rtype: pl.DataFrame
    """
    import polars as pl

    issues_data = [_process_single_issue(issue) for issue in raw_data]

    columns = [
        "Id",
        "IssueOwner",
        "Title",
        "DateCreated",
        "Description",
        "SeverityLevel",
        "CostEstimate",
        "LevelOfEffort",
        "DueDate",
        "Identification",
        "Status",
        "DateCompleted",
        "ActivitiesObserved",
        "FailuresObserved",
        "RequirementsViolated",
        "SafetyImpact",
        "SecurityImpact",
        "QualityImpact",
        "SecurityChecks",
        "RecommendedActions",
    ]
    return pl.DataFrame(issues_data, schema=columns, orient="row")


def _create_initial_workbooks(regscale_id: int, regscale_module: str, path: Path) -> None:
    """
    Create initial Excel workbooks for issues.

    :param int regscale_id: RegScale Parent Id
    :param str regscale_module: RegScale Parent Module
    :param Path path: Directory path for files
    """
    workbook = Workbook()
    worksheet = workbook.active
    worksheet.title = f"Issues({regscale_id}_{regscale_module})"
    workbook.save(filename=os.path.join(path, ALL_ISSUES_XLSX))
    shutil.copy(
        os.path.join(path, ALL_ISSUES_XLSX),
        os.path.join(path, OLD_ISSUES_XLSX),
    )


def _setup_reference_sheets(path: Path) -> None:
    """
    Set up reference sheets (Accounts and Identifications) in the workbook.

    :param Path path: Directory path for files
    """
    import polars as pl

    # Pulling in Account Users into Excel Spreadsheet to create drop down.
    user_names_df = get_user_names()
    _write_df_to_excel(user_names_df, os.path.join(path, ALL_ISSUES_XLSX), "Accounts")

    # Pulling in Identifications into separate Excel Spreadsheet to create drop down.
    identification_list = [
        "A-123 Review",
        "Assessment/Audit (External)",
        "Assessment/Audit (Internal)",
        "Critical Control Review",
        "FDCC/USGCB",
        "GAO Audit",
        "IG Audit",
        "Incidnet Response Lessons Learned",
        "ITAR",
        "Other",
        "Penetration Test",
        "Risk Assessment",
        "Security Authorization",
        "Security Control Assessment",
        "Vulnerability Assessment",
    ]

    identifications = pl.DataFrame({"IdentificationOptions": identification_list})
    _write_df_to_excel(identifications, os.path.join(path, ALL_ISSUES_XLSX), "Identifications")


def _protect_old_issues_file(path: Path) -> None:
    """
    Add protection to old_issues.xlsx file.

    :param Path path: Directory path for files
    """
    workbook2 = load_workbook(os.path.join(path, OLD_ISSUES_XLSX))
    worksheet2 = workbook2.active
    worksheet2.protection.sheet = True
    workbook2.save(filename=os.path.join(path, OLD_ISSUES_XLSX))


def _create_data_validations(workbook: Any) -> list[DataValidation]:
    """
    Create data validation objects for the worksheet.

    :param Any workbook: OpenPyXL workbook object
    :return: List of DataValidation objects
    :rtype: list[DataValidation]
    """
    severitylevels = '"I - High - Signficant Deficiency, II - Moderate - Reportable Condition, III - Low - Other Weakness, IV - Not Asssigned"'
    statuses = '"Closed, Draft, Open, Pending Decommission, Supply Chain/Procurement Dependency, Vendor Dependency for Fix, Delayed, Cancelled, Exception/Waiver"'

    dv1 = DataValidation(
        type="list",
        formula1="=Accounts!$A$2:$A$" + str(get_maximum_rows(sheet_object=workbook["Accounts"])),
        allow_blank=False,
        showDropDown=False,
        error=ERROR_NOT_AVAILABLE_OPTION,
        errorTitle=ERROR_INVALID_ENTRY,
        prompt=PROMPT_SELECT_FROM_LIST,
    )
    dv2 = DataValidation(
        type="list",
        formula1=severitylevels,
        allow_blank=False,
        showDropDown=False,
        error=ERROR_NOT_AVAILABLE_OPTION,
        errorTitle=ERROR_INVALID_ENTRY,
        prompt=PROMPT_SELECT_FROM_LIST,
    )
    dv3 = DataValidation(
        type="list",
        formula1=statuses,
        allow_blank=True,
        showDropDown=False,
        error=ERROR_NOT_AVAILABLE_OPTION,
        errorTitle=ERROR_INVALID_ENTRY,
        prompt=PROMPT_SELECT_FROM_LIST,
    )
    dv4 = DataValidation(
        type="list",
        formula1="=Identifications!$A$2:$A$" + str(get_maximum_rows(sheet_object=workbook["Identifications"])),
        allow_blank=False,
        showDropDown=False,
        error=ERROR_NOT_AVAILABLE_OPTION,
        errorTitle=ERROR_INVALID_ENTRY,
        prompt=PROMPT_SELECT_FROM_LIST,
    )
    dv5 = DataValidation(
        type="date",
        allow_blank=False,
        showErrorMessage=True,
        showInputMessage=True,
        showDropDown=False,
        error=ERROR_NOT_VALID_OPTION,
        errorTitle=ERROR_INVALID_ENTRY,
        prompt="Please enter valid date mm/dd/yyyy",
    )
    dv6 = DataValidation(
        type="date",
        allow_blank=True,
        showErrorMessage=True,
        showInputMessage=True,
        showDropDown=False,
        error=ERROR_NOT_VALID_OPTION,
        errorTitle=ERROR_INVALID_ENTRY,
        prompt="Please enter valid date mm/dd/yyyy",
    )
    dv7 = DataValidation(
        type="whole",
        operator="greaterThanOrEqual",
        formula1=0,
        allow_blank=False,
        showErrorMessage=True,
        showInputMessage=True,
        showDropDown=False,
        error=ERROR_NOT_VALID_OPTION,
        errorTitle=ERROR_INVALID_ENTRY,
        prompt="Please enter valid whole number denoting number of hours.",
    )
    return [dv1, dv2, dv3, dv4, dv5, dv6, dv7]


def _apply_data_validations(worksheet: Any, validations: list[DataValidation]) -> None:
    """
    Apply data validations to worksheet.

    :param Any worksheet: OpenPyXL worksheet object
    :param list[DataValidation] validations: List of DataValidation objects
    """
    dv1, dv2, dv3, dv4, dv5, dv6, dv7 = validations
    worksheet.add_data_validation(dv1)
    worksheet.add_data_validation(dv2)
    worksheet.add_data_validation(dv3)
    worksheet.add_data_validation(dv4)
    worksheet.add_data_validation(dv5)
    worksheet.add_data_validation(dv6)
    worksheet.add_data_validation(dv7)
    dv1.add("B2:B1048576")
    dv2.add("F2:F1048576")
    dv3.add("K2:K1048576")
    dv4.add("J2:J1048576")
    dv5.add("I2:I1048576")
    dv6.add("D2:D1048576")
    dv6.add("L2:L1048576")
    dv7.add("H2:H1048576")


def _apply_formatting(worksheet: Any) -> None:
    """
    Apply date and currency formatting to worksheet.

    :param Any worksheet: OpenPyXL worksheet object
    """
    date_style = NamedStyle(name="date_style", number_format="mm/dd/yyyy")
    worksheet.parent.add_named_style(date_style)
    currency = '"$"* #,##0.00_);("$"* #,##0.00);"$"* #,##0.00_);'

    for col in ["D", "G", "I", "L"]:
        for cell in worksheet[col]:
            if col != "G" and cell.row > 1:
                cell.style = date_style
            elif col == "G" and cell.row > 1:
                cell.number_format = currency


def _adjust_column_widths(worksheet: Any) -> None:
    """
    Adjust column widths based on content.

    :param Any worksheet: OpenPyXL worksheet object
    """
    for col in worksheet.columns:
        max_length = 0
        column = col[0].column_letter
        for cell in col:
            if len(str(cell.value)) > max_length:
                max_length = len(str(cell.value))

        adjusted_width = (max_length + 2) * 1.2
        worksheet.column_dimensions[column].width = adjusted_width


def _unlock_editable_cells(worksheet: Any) -> None:
    """
    Unlock cells that can be edited.

    :param Any worksheet: OpenPyXL worksheet object
    """
    editable_columns = [
        "B",
        "E",
        "F",
        "G",
        "H",
        "I",
        "J",
        "K",
        "L",
        "M",
        "N",
        "O",
        "P",
        "Q",
        "R",
        "S",
        "T",
    ]
    for col in editable_columns:
        for cell in worksheet[col]:
            cell.protection = Protection(locked=False)


def all_issues(regscale_id: int, regscale_module: str, path: Path) -> None:
    """Function to build excel spreadsheet with all issues matching organizer records given.

    :param int regscale_id: RegScale Parent Id
    :param str regscale_module: RegScale Parent Module
    :param Path path: directory of file location
    :rtype: None
    """
    # see if provided RegScale Module is an accepted option in Organizer Modules list
    from regscale.core.app.api import Api

    api = Api()
    verify_organizer_module(regscale_module)

    body = """
            query {
                    issues (skip: 0, take: 50, where: {parentId: {eq: parent_id} parentModule: {eq: "parent_module"}}) {
                      items {
                       id
                       issueOwnerId
                       issueOwner {
                         firstName
                         lastName
                         userName
                       }
                       title
                       dateCreated
                       description
                       severityLevel
                       costEstimate
                       levelOfEffort
                       dueDate
                       identification
                       status
                       dateCompleted
                       activitiesObserved
                       failuresObserved
                       requirementsViolated
                       safetyImpact
                       securityImpact
                       qualityImpact
                       securityChecks
                       recommendedActions
                       parentId
                       parentModule
                      }
                      totalCount
                      pageInfo {
                        hasNextPage
                      }
                    }
                 }
                """.replace("parent_module", regscale_module).replace("parent_id", str(regscale_id))
    existing_issue_data = api.graph(query=body)

    if existing_issue_data["issues"]["totalCount"] > 0:
        check_file_path(path)

        # Create initial workbooks
        _create_initial_workbooks(regscale_id, regscale_module, path)

        # Process issue data
        raw_data = existing_issue_data["issues"]["items"]
        all_ass_df = _process_issue_data(raw_data)

        # Write to both Excel files
        sheet_name = f"Issues({regscale_id}_{regscale_module})"
        _write_df_to_excel(all_ass_df, os.path.join(path, ALL_ISSUES_XLSX), sheet_name)
        _write_df_to_excel(all_ass_df, os.path.join(path, OLD_ISSUES_XLSX), sheet_name)

        # Set up reference sheets
        _setup_reference_sheets(path)

        # Protect old issues file
        _protect_old_issues_file(path)

        # Load workbook for final configuration
        workbook = load_workbook(os.path.join(path, ALL_ISSUES_XLSX))
        worksheet = workbook.active
        accounts_worksheet = workbook["Accounts"]
        identifications_worksheet = workbook["Identifications"]

        # Protect worksheets
        accounts_worksheet.protection.sheet = True
        worksheet.protection.sheet = True
        identifications_worksheet.protection.sheet = True

        # Create and apply data validations
        validations = _create_data_validations(workbook)
        _apply_data_validations(worksheet, validations)

        # Apply formatting
        _apply_formatting(worksheet)

        # Adjust column widths
        _adjust_column_widths(worksheet)

        # Unlock editable cells
        _unlock_editable_cells(worksheet)

        workbook.save(filename=os.path.join(path, ALL_ISSUES_XLSX))

    else:
        logger.info("No Issues exist. Please check your selections for RegScale Id and RegScale Module and try again.")
        error_and_exit("There was an error creating your workbook for the given RegScale Id and RegScale Module.")

    logger.info(
        "Your data has been loaded. Please open the all_issues workbook and make your desired changes %s. " % path
    )
    return None


@issues.command(name="load")
@click.option(
    "--path",
    type=click.Path(exists=False, dir_okay=True, path_type=Path),
    help="Provide the desired path of excel workbook locations.",
    default=os.path.join(os.getcwd(), "artifacts"),
    required=True,
)
def generate_upload_data(path: Path):
    """This function uploads updated issues to the RegScale from the Excel files that users have edited."""
    upload_data(path)


def upload_data(path: Path) -> None:
    """
    This function uploads updated issues to the RegScale.

    :param Path path: directory of file location
    :rtype: None
    """
    import polars as pl  # Optimize import performance

    # Checking all_issues file for differences before updating database
    workbook = load_workbook(os.path.join(path, ALL_ISSUES_XLSX))
    sheet_name = workbook.sheetnames[0]
    sheet_name = sheet_name[sheet_name.find("(") + 1 : sheet_name.find(")")].split("_")

    # set the variables to the correct values
    for item in set(sheet_name):
        try:
            regscale_parent_id = int(item)
        except ValueError:
            regscale_module = item

    df1 = pl.read_excel(os.path.join(path, OLD_ISSUES_XLSX), sheet_id=1)
    df2 = pl.read_excel(os.path.join(path, ALL_ISSUES_XLSX), sheet_id=1)

    if df1.equals(df2):
        logger.info("No differences detected.")
        error_and_exit("No changes were made to the all_issues.xlsx file. Thank you!")
    else:
        logger.warning("*** WARNING *** Differences Found")

        # Find differences between dataframes
        changes_list = _find_dataframe_differences(df1, df2)

        # Write differences to file
        if changes_list:
            with open(os.path.join(path, DIFFERENCES_TXT), "w") as f:
                f.write("Id Column From To\n")
                for change in changes_list:
                    f.write(f"{change['Id']} {change['Column']} {change['From']} {change['To']}\n")

        # Get unique IDs that changed
        diff = pl.read_csv(os.path.join(path, DIFFERENCES_TXT), separator=" ")
        changed_ids = diff["Id"].unique().to_list()

        updated_file = os.path.join(path, ALL_ISSUES_XLSX)

        reader = pl.read_excel(updated_file, sheet_id=1)
        updated = reader.filter(pl.col("Id").is_in(changed_ids))

        accounts = pl.read_excel(updated_file, sheet_name="Accounts")
        accounts = accounts.rename({"User": "IssueOwner", "UserId": "IssueOwnerId"})
        updated = updated.join(accounts, on="IssueOwner", how="left")

        updated_issues = [
            Issue(
                id=row["Id"],
                issueOwnerId=row["IssueOwnerId"],
                title=row["Title"],
                dateCreated=row["DateCreated"],
                description=row["Description"],
                severityLevel=row["SeverityLevel"],
                costEstimate=row["CostEstimate"],
                levelOfEffort=row["LevelOfEffort"],
                dueDate=row["DueDate"],
                identification=check_empty_nan(row["Identification"], "Other"),
                status=row["Status"],
                dateCompleted=check_empty_nan(row["DateCompleted"], ""),
                activitiesObserved=check_empty_nan(row["ActivitiesObserved"]),
                failuresObserved=check_empty_nan(row["FailuresObserved"]),
                requirementsViolated=check_empty_nan(row["RequirementsViolated"]),
                safetyImpact=check_empty_nan(row["SafetyImpact"]),
                securityImpact=check_empty_nan(row["SecurityImpact"]),
                qualityImpact=check_empty_nan(row["QualityImpact"]),
                securityChecks=check_empty_nan(row["SecurityChecks"]),
                recommendedActions=check_empty_nan(row["RecommendedActions"]),
                dateLastUpdated=get_current_datetime(),
                parentModule=regscale_module,
                parentId=regscale_parent_id,
            )
            for row in updated.iter_rows(named=True)
        ]
        Issue.batch_update(updated_issues)
    logger.info("Changes made to existing files can be seen in %s file. Thank you! %s" % (DIFFERENCES_TXT, path))
    return None


@issues.command(name="delete_files")
@click.option(
    "--path",
    type=click.Path(exists=False, dir_okay=True, path_type=Path),
    help="Provide the desired path of excel workbook locations.",
    default=os.path.join(os.getcwd(), "artifacts"),
    required=True,
)
def generate_delete_file(path: Path):
    """This function deletes files used during the POAM Editor process."""
    delete_file(path)


def delete_file(path: Path) -> None:
    """
    Deletes files used during the process.

    :param Path path: Path for artifacts folder or location of excel files
    :rtype: None
    """
    os.remove(os.path.join(path, ALL_ISSUES_XLSX))
    os.remove(os.path.join(path, OLD_ISSUES_XLSX))
    differences_file = os.path.join(path, DIFFERENCES_TXT)
    if os.path.isfile(differences_file):
        os.remove(differences_file)
    logger.info("Files have been deleted. Thank you.")
    return None


def get_maximum_rows(*, sheet_object: Any) -> int:
    """This function finds the last row containing data in a spreadsheet

    :param Any sheet_object: excel worksheet to be referenced
    :return: integer representing last row with data in spreadsheet
    :rtype: int
    """
    return sum(any(col.value is not None for col in row) for max_row, row in enumerate(sheet_object, 1))


def verify_organizer_module(module: str) -> None:
    """
    Function to check the provided module is a valid RegScale Organizer Module and will display the acceptable RegScale modules

    :param str module: desired module
    :rtype: None
    """

    # create console and table objects
    console = Console()
    table = Table("RegScale Module", "Accepted Value", title="RegScale Modules", safe_box=True)

    # list of RegScaleOrganizer Modules
    organizers = ["components", "policies", "projects", "securityplans", "supplychain"]

    # iterate through items and add them to table object
    for i in range(len(organizers)):
        table.add_row(organizers[i], organizers[i])

    if module not in organizers:
        # print the table object in console
        console.print(table)
        error_and_exit("Please provide an option from the Accepted Value column.")
