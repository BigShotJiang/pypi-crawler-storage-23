"""
Distributed tracing with OpenTelemetry integration.

Provides end-to-end request tracing across components with automatic
context propagation. Compatible with Jaeger, Zipkin, and other tracing backends.

Example:
    >>> from regscale.core.observability import trace, get_current_trace_id
    >>>
    >>> # Decorator-based tracing
    >>> @trace.span("upload_items")
    >>> def upload_items(items):
    ...     for item in items:
    ...         upload_item(item)
    >>>
    >>> # Context manager tracing
    >>> with trace.span("bulk_processing", items_count=1000):
    ...     process_bulk_data()
    >>>
    >>> # Get current trace ID for logging
    >>> trace_id = get_current_trace_id()
    >>> logger.info(f"Processing with trace {trace_id}")
"""

import functools
import logging
from contextlib import contextmanager
from typing import Callable, Dict, Optional

logger = logging.getLogger("regscale")

# Try to import OpenTelemetry (optional dependency)
try:
    from opentelemetry import trace as otel_trace
    from opentelemetry.exporter.otlp.proto.grpc.trace_exporter import OTLPSpanExporter
    from opentelemetry.sdk.resources import Resource
    from opentelemetry.sdk.trace import TracerProvider
    from opentelemetry.sdk.trace.export import BatchSpanProcessor
    from opentelemetry.trace import SpanKind, Status, StatusCode
    from opentelemetry.trace.propagation.tracecontext import TraceContextTextMapPropagator

    OTEL_AVAILABLE = True
except ImportError:
    OTEL_AVAILABLE = False
    otel_trace = None
    Status = None
    StatusCode = None
    SpanKind = None


class Tracer:
    """
    Distributed tracing with OpenTelemetry integration.

    Provides span creation, context propagation, and integration with
    distributed tracing backends like Jaeger and Zipkin.

    Example:
        >>> tracer = Tracer(service_name="regscale-cli")
        >>> with tracer.span("operation", key="value"):
        ...     do_work()
    """

    def __init__(
        self,
        service_name: str = "regscale-cli",
        enable_export: bool = False,
        otlp_endpoint: Optional[str] = None,
        sample_rate: float = 1.0,
    ):
        """
        Initialize tracer.

        Args:
            service_name: Service name for trace identification
            enable_export: Whether to export traces to backend
            otlp_endpoint: OTLP endpoint URL (e.g., "http://localhost:4317")
            sample_rate: Sampling rate (0.0 to 1.0, default: 1.0 = 100%)
        """
        self.service_name = service_name
        self.enable_export = enable_export
        self.otlp_endpoint = otlp_endpoint
        self.sample_rate = sample_rate

        self._tracer = None
        self._provider = None

        # Initialize OpenTelemetry if available
        if OTEL_AVAILABLE:
            self._initialize_opentelemetry()
        else:
            logger.debug("OpenTelemetry not available, tracing disabled")

    def _initialize_opentelemetry(self) -> None:
        """Initialize OpenTelemetry tracing provider."""
        try:
            resource = Resource.create({"service.name": self.service_name})

            # Create tracer provider with sampling
            from opentelemetry.sdk.trace.sampling import ParentBasedTraceIdRatio

            sampler = ParentBasedTraceIdRatio(self.sample_rate)
            self._provider = TracerProvider(resource=resource, sampler=sampler)

            # Setup OTLP exporter if enabled
            if self.enable_export and self.otlp_endpoint:
                exporter = OTLPSpanExporter(endpoint=self.otlp_endpoint, insecure=True)
                processor = BatchSpanProcessor(exporter)
                self._provider.add_span_processor(processor)
                logger.info(f"OTLP trace exporter configured: {self.otlp_endpoint}")

            otel_trace.set_tracer_provider(self._provider)
            self._tracer = otel_trace.get_tracer(__name__)

            logger.info("OpenTelemetry tracing initialized successfully")
        except Exception as e:
            logger.warning(f"Failed to initialize OpenTelemetry tracing: {e}")
            self._tracer = None

    @contextmanager
    def span(self, name: str, **attributes):
        """
        Create a span context manager.

        Args:
            name: Span name (operation name)
            **attributes: Additional span attributes

        Yields:
            Span object (or None if tracing disabled)

        Example:
            >>> with trace.span("upload_data", item_count=100):
            ...     upload()
        """
        if not self._tracer:
            # Tracing not available, yield None
            yield None
            return

        span = self._tracer.start_span(name)

        try:
            # Set span attributes
            for key, value in attributes.items():
                span.set_attribute(key, str(value))

            yield span
        except Exception as e:
            # Record exception in span
            if span and hasattr(span, "set_status") and hasattr(span, "record_exception"):
                span.set_status(Status(StatusCode.ERROR, str(e)))
                span.record_exception(e)
            raise
        finally:
            if span and hasattr(span, "end"):
                span.end()

    def start_span(self, name: str, **attributes):
        """
        Start a new span manually (must call span.end()).

        Args:
            name: Span name
            **attributes: Span attributes

        Returns:
            Span object or None

        Example:
            >>> span = trace.start_span("long_operation")
            >>> try:
            ...     do_work()
            ... finally:
            ...     span.end()
        """
        if not self._tracer:
            return None

        span = self._tracer.start_span(name)

        for key, value in attributes.items():
            span.set_attribute(key, str(value))

        return span

    def get_current_span(self):
        """
        Get the current active span.

        Returns:
            Current span or None

        Example:
            >>> span = trace.get_current_span()
            >>> if span:
            ...     span.set_attribute("custom_key", "value")
        """
        if not OTEL_AVAILABLE or not otel_trace:
            return None

        return otel_trace.get_current_span()

    def get_current_trace_id(self) -> Optional[str]:
        """
        Get the current trace ID as a hex string.

        Returns:
            Trace ID or None if no active span

        Example:
            >>> trace_id = trace.get_current_trace_id()
            >>> logger.info(f"Trace ID: {trace_id}")
        """
        span = self.get_current_span()
        if not span:
            return None

        span_context = span.get_span_context()
        if not span_context or not span_context.is_valid:
            return None

        return format(span_context.trace_id, "032x")

    def inject_context(self, carrier: Dict[str, str]) -> None:
        """
        Inject trace context into carrier for propagation.

        Args:
            carrier: Dictionary to inject context into (e.g., HTTP headers)

        Example:
            >>> headers = {}
            >>> trace.inject_context(headers)
            >>> requests.get(url, headers=headers)
        """
        if not OTEL_AVAILABLE:
            return

        propagator = TraceContextTextMapPropagator()
        propagator.inject(carrier)

    def extract_context(self, carrier: Dict[str, str]):
        """
        Extract trace context from carrier.

        Args:
            carrier: Dictionary containing trace context (e.g., HTTP headers)

        Returns:
            Context object or None

        Example:
            >>> context = trace.extract_context(request.headers)
        """
        if not OTEL_AVAILABLE:
            return None

        propagator = TraceContextTextMapPropagator()
        return propagator.extract(carrier)

    def shutdown(self) -> None:
        """
        Shutdown tracer provider and flush pending spans.

        Call this before application exit to ensure all spans are exported.

        Example:
            >>> trace.shutdown()
        """
        if self._provider and hasattr(self._provider, "shutdown"):
            self._provider.shutdown()
            logger.info("Tracer provider shutdown complete")


# Singleton tracer instance
trace = Tracer()


def get_current_trace_id() -> Optional[str]:
    """
    Get the current trace ID.

    Returns:
        Trace ID as hex string or None

    Example:
        >>> from regscale.core.observability import get_current_trace_id
        >>> trace_id = get_current_trace_id()
        >>> if trace_id:
        ...     logger.info(f"Request trace: {trace_id}")
    """
    return trace.get_current_trace_id()


def traced(operation_name: Optional[str] = None, **attributes):
    """
    Decorator for tracing function calls.

    Args:
        operation_name: Name for the span (defaults to function name)
        **attributes: Additional span attributes

    Example:
        >>> @traced("upload_items", batch_size=100)
        >>> def upload_items(items):
        ...     for item in items:
        ...         api.upload(item)
    """

    def decorator(func: Callable) -> Callable:
        span_name = operation_name or func.__name__

        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            with trace.span(span_name, **attributes):
                return func(*args, **kwargs)

        return wrapper

    return decorator


# Integration helpers for common operations
def trace_api_call(endpoint: str, method: str = "GET"):
    """
    Decorator for tracing API calls.

    Args:
        endpoint: API endpoint path
        method: HTTP method

    Example:
        >>> @trace_api_call("/api/issues", method="POST")
        >>> def create_issue(issue_data):
        ...     return api.post("/api/issues", json=issue_data)
    """
    return traced("api_call", endpoint=endpoint, method=method)


def trace_bulk_operation(operation_name: str, item_count: Optional[int] = None):
    """
    Decorator for tracing bulk operations.

    Args:
        operation_name: Name of the bulk operation
        item_count: Number of items (if known)

    Example:
        >>> @trace_bulk_operation("bulk_upload", item_count=50000)
        >>> def upload_findings(findings):
        ...     for finding in findings:
        ...         api.upload(finding)
    """
    attrs = {"operation": operation_name}
    if item_count is not None:
        attrs["item_count"] = item_count

    return traced(f"bulk_{operation_name}", **attrs)


def trace_scanner_operation(scanner_name: str, operation_type: str):
    """
    Decorator for tracing scanner operations.

    Args:
        scanner_name: Name of the scanner (e.g., "wiz", "qualys")
        operation_type: Type of operation (e.g., "fetch", "import", "sync")

    Example:
        >>> @trace_scanner_operation("wiz", "fetch_findings")
        >>> def fetch_wiz_findings():
        ...     return wiz_api.get_findings()
    """
    return traced(f"{scanner_name}_{operation_type}", scanner=scanner_name, operation_type=operation_type)
