"""
Observability framework for RegScale CLI.

Provides structured logging, performance metrics, and distributed tracing
with OpenTelemetry and Grafana integration.

Example:
    >>> from regscale.core.observability import get_logger, metrics, trace
    >>>
    >>> # Structured logging
    >>> logger = get_logger(__name__)
    >>> logger.info("Operation completed", items_processed=1000, duration_seconds=45.2)
    >>>
    >>> # Metrics
    >>> metrics.increment("items_processed_total", 1000)
    >>> with metrics.timer("operation_duration_seconds"):
    ...     process_items()
    >>>
    >>> # Tracing
    >>> with trace.span("upload_items"):
    ...     upload(items)
"""

# Import metrics collector and helpers
from regscale.core.observability.metrics_collector import (
    MetricsCollector,
    metrics,
    track_api_request,
    track_bulk_operation,
    track_checkpoint_save,
    track_circuit_breaker_state,
    track_health_check,
    track_retry_attempt,
)
from regscale.core.observability.structured_logger import StructuredLogger, get_logger

# Tracing
from regscale.core.observability.tracing import (
    Tracer,
    get_current_trace_id,
    trace,
    trace_api_call,
    trace_bulk_operation,
    trace_scanner_operation,
    traced,
)

__all__ = [
    # Logging
    "get_logger",
    "StructuredLogger",
    # Metrics
    "metrics",
    "MetricsCollector",
    "track_api_request",
    "track_bulk_operation",
    "track_circuit_breaker_state",
    "track_retry_attempt",
    "track_checkpoint_save",
    "track_health_check",
    # Tracing
    "trace",
    "Tracer",
    "get_current_trace_id",
    "traced",
    "trace_api_call",
    "trace_bulk_operation",
    "trace_scanner_operation",
]
