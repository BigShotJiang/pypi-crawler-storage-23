"""
Circuit Breaker pattern implementation for preventing cascading failures.

The circuit breaker monitors failures and stops sending requests to failing services,
giving them time to recover. It operates in three states:

- CLOSED: Normal operation, requests pass through
- OPEN: Too many failures, requests are blocked
- HALF_OPEN: Testing if service has recovered

Example:
    >>> from regscale.core.resilience import CircuitBreaker
    >>> circuit_breaker = CircuitBreaker(failure_threshold=5, timeout=60)
    >>>
    >>> @circuit_breaker
    ... def call_api():
    ...     return requests.get("https://api.example.com/data")
    >>>
    >>> try:
    ...     result = call_api()
    ... except CircuitBreakerOpenError:
    ...     print("Service unavailable, circuit breaker is open")
"""

import logging
import threading
import time
from enum import Enum
from functools import wraps
from typing import Any, Callable, Optional

logger = logging.getLogger("regscale")


class CircuitBreakerState(Enum):
    """Circuit breaker states."""

    CLOSED = "closed"  # Normal operation
    OPEN = "open"  # Blocking requests
    HALF_OPEN = "half_open"  # Testing recovery


class CircuitBreakerOpenError(Exception):
    """Raised when circuit breaker is open and blocking requests."""

    pass


class CircuitBreaker:
    """
    Circuit breaker to prevent cascading failures.

    The circuit breaker tracks consecutive failures and opens when the threshold
    is exceeded. After a timeout period, it enters HALF_OPEN state to test if
    the service has recovered.

    Args:
        failure_threshold: Number of consecutive failures before opening (default: 5)
        timeout: Seconds to wait before trying again after opening (default: 60)
        expected_exceptions: Tuple of exceptions that count as failures (default: Exception)
        name: Optional name for this circuit breaker (for logging)

    Example:
        >>> breaker = CircuitBreaker(failure_threshold=3, timeout=30)
        >>> breaker.call(lambda: api.get("/endpoint"))
    """

    def __init__(
        self,
        failure_threshold: int = 5,
        timeout: int = 60,
        expected_exceptions: tuple = (Exception,),
        name: Optional[str] = None,
    ):
        self.failure_threshold = failure_threshold
        self.timeout = timeout
        self.expected_exceptions = expected_exceptions
        self.name = name or "unnamed"

        # Thread safety lock (RLock allows same thread to acquire multiple times)
        self._lock = threading.RLock()

        # State tracking (protected by _lock)
        self.state = CircuitBreakerState.CLOSED
        self.failure_count = 0
        self.last_failure_time: Optional[float] = None
        self.success_count = 0

        logger.info(
            "CircuitBreaker initialized: name=%s, failure_threshold=%d, timeout=%d",
            self.name,
            self.failure_threshold,
            self.timeout,
        )

    def call(self, func: Callable, *args, **kwargs) -> Any:
        """
        Execute a function through the circuit breaker.

        This method is thread-safe - multiple threads can call it concurrently.

        Args:
            func: Function to execute
            *args: Positional arguments for func
            **kwargs: Keyword arguments for func

        Returns:
            Result from func

        Raises:
            CircuitBreakerOpenError: If circuit is open
            Exception: Any exception from func

        Example:
            >>> result = breaker.call(api.get, "/endpoint")
        """
        # Check state under lock (quick check, don't hold during execution)
        with self._lock:
            if self.state == CircuitBreakerState.OPEN:
                if self._should_attempt_reset():
                    self._transition_to_half_open()
                else:
                    last_failure = self.last_failure_time or 0
                    raise CircuitBreakerOpenError(
                        f"Circuit breaker '{self.name}' is OPEN. "
                        f"Last failure: {time.time() - last_failure:.1f}s ago. "
                        f"Retry in {self.timeout - (time.time() - last_failure):.1f}s"
                    )

        # Execute outside lock (don't hold lock during user function execution)
        try:
            result = func(*args, **kwargs)

            # Record success under lock
            with self._lock:
                self._on_success()

            return result

        except self.expected_exceptions:
            # Record failure under lock
            with self._lock:
                self._on_failure()

            # Re-raise the exception
            raise

    def __call__(self, func: Callable) -> Callable:
        """
        Decorator to wrap a function with circuit breaker protection.

        Example:
            >>> @CircuitBreaker(failure_threshold=5)
            ... def call_api():
            ...     return requests.get("https://api.example.com")
        """

        @wraps(func)
        def wrapper(*args, **kwargs):
            return self.call(func, *args, **kwargs)

        return wrapper

    def _should_attempt_reset(self) -> bool:
        """Check if enough time has passed to attempt recovery."""
        if self.last_failure_time is None:
            return True

        time_since_failure = time.time() - self.last_failure_time
        return time_since_failure >= self.timeout

    def _transition_to_half_open(self):
        """Transition from OPEN to HALF_OPEN state."""
        logger.info("CircuitBreaker '%s' transitioning to HALF_OPEN (testing recovery)", self.name)
        self.state = CircuitBreakerState.HALF_OPEN
        self.failure_count = 0

    def _on_success(self):
        """Handle successful call."""
        self.success_count += 1

        if self.state == CircuitBreakerState.HALF_OPEN:
            # Recovery successful
            logger.info(
                "CircuitBreaker '%s' recovery successful, transitioning to CLOSED",
                self.name,
            )
            self.state = CircuitBreakerState.CLOSED
            self.failure_count = 0

        elif self.state == CircuitBreakerState.CLOSED:
            # Reset failure count on success
            if self.failure_count > 0:
                logger.debug(
                    "CircuitBreaker '%s' success after %d failures, resetting counter",
                    self.name,
                    self.failure_count,
                )
                self.failure_count = 0

    def _on_failure(self):
        """Handle failed call."""
        self.failure_count += 1
        self.last_failure_time = time.time()

        logger.warning(
            "CircuitBreaker '%s' failure %d/%d (state=%s)",
            self.name,
            self.failure_count,
            self.failure_threshold,
            self.state.value,
        )

        if self.state == CircuitBreakerState.HALF_OPEN:
            # Recovery failed, go back to OPEN
            logger.warning("CircuitBreaker '%s' recovery failed, transitioning back to OPEN", self.name)
            self.state = CircuitBreakerState.OPEN

        elif self.failure_count >= self.failure_threshold:
            # Too many failures, open the circuit
            logger.error(
                "CircuitBreaker '%s' OPENING after %d failures (threshold=%d)",
                self.name,
                self.failure_count,
                self.failure_threshold,
            )
            self.state = CircuitBreakerState.OPEN

    def reset(self):
        """Manually reset the circuit breaker to CLOSED state (thread-safe)."""
        with self._lock:
            logger.info("CircuitBreaker '%s' manually reset to CLOSED", self.name)
            self.state = CircuitBreakerState.CLOSED
            self.failure_count = 0
            self.last_failure_time = None

    def get_status(self) -> dict:
        """
        Get current circuit breaker status (thread-safe).

        Returns:
            Dictionary with state, failure_count, success_count, etc.

        Example:
            >>> status = breaker.get_status()
            >>> print(f"State: {status['state']}, Failures: {status['failure_count']}")
        """
        with self._lock:
            return {
                "name": self.name,
                "state": self.state.value,
                "failure_count": self.failure_count,
                "success_count": self.success_count,
                "failure_threshold": self.failure_threshold,
                "timeout": self.timeout,
                "last_failure_time": self.last_failure_time,
                "time_since_failure": time.time() - self.last_failure_time if self.last_failure_time else None,
            }
