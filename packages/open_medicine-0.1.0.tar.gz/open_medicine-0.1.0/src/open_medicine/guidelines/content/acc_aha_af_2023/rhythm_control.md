# Rhythm Control in Atrial Fibrillation — ACC/AHA 2023

## General Principles

Rhythm control (restoration and maintenance of sinus rhythm) is indicated for symptomatic patients or when rate control fails to improve quality of life. Early rhythm control (within 1 year of AF diagnosis) is associated with improved cardiovascular outcomes.

## Cardioversion

- **Pharmacological cardioversion:** Intravenous amiodarone or ibutilide for patients with normal LV function. Amiodarone IV for patients with HFrEF. Procainamide is a second-tier option.
- **Electrical cardioversion (DCCV):** Preferred for hemodynamically unstable AF, when patient desires immediate rhythm conversion, or when pharmacological cardioversion fails.
- **Anticoagulation before cardioversion:** If AF duration > 48 hours or unknown, anticoagulate for ≥ 3 weeks before cardioversion OR perform transesophageal echocardiography (TEE) to rule out left atrial appendage thrombus. Continue OAC for ≥ 4 weeks after cardioversion regardless of CHA2DS2-VASc.

## Long-Term Rhythm Control

### Catheter Ablation
- Catheter ablation (pulmonary vein isolation) is recommended as **first-line therapy** for selected patients with symptomatic paroxysmal AF, particularly younger patients with few comorbidities (Class I).
- Catheter ablation is recommended for patients with HFrEF for rhythm control (Class I).
- Catheter ablation is recommended for symptomatic AF when AADs have been ineffective, contraindicated, not tolerated, or not preferred (Class I).
- Ablation is superior to AADs for maintaining sinus rhythm but **does not eliminate the need for long-term anticoagulation** (CHA2DS2-VASc-based).
- Short-term AAD therapy following ablation may be used to reduce early recurrence (Class IIa).

### Antiarrhythmic Drugs (AADs)

> **Important:** No antiarrhythmic drug received a Class I recommendation for long-term maintenance of sinus rhythm in the 2023 guideline.

- **Dofetilide:** Class IIa. Requires inpatient initiation with QT monitoring.
- **Dronedarone:** Indicated to reduce AF hospitalization in patients with paroxysmal/persistent AF in sinus rhythm. Contraindicated in NYHA Class III-IV HF and permanent AF.
- **Flecainide, propafenone:** Only in patients WITHOUT structural heart disease. Can be initiated outpatient.
- **Sotalol:** Downgraded to Class IIb due to association with increased mortality risk. Requires inpatient initiation.
- **Amiodarone:** Most effective AAD but reserved for patients who do not respond to or have contraindications to other AADs, due to significant long-term toxicity (thyroid, pulmonary, hepatic, ocular). Can be initiated outpatient.
