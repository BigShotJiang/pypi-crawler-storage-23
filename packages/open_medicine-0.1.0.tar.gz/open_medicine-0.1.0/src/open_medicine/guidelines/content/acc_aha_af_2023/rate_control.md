# Rate Control in Atrial Fibrillation — ACC/AHA 2023

## General Principles

Rate control is recommended as the initial strategy for most patients with AF, particularly those who are asymptomatic or minimally symptomatic.

## Target Heart Rate

- **Lenient rate control** (resting HR < 110 bpm) is a reasonable initial approach (Class IIa).
- **Strict rate control** (resting HR < 80 bpm) should be considered if symptoms persist despite lenient control.

## First-Line Agents

- **Beta-blockers** (metoprolol, bisoprolol, atenolol): Preferred in patients with heart failure with reduced ejection fraction (HFrEF) or coronary artery disease.
- **Non-dihydropyridine calcium channel blockers** (diltiazem, verapamil): Preferred in patients without HFrEF. Contraindicated in HFrEF (LVEF < 40%).
- **Digoxin:** May be added as a second-line agent for rate control when beta-blockers or CCBs alone are insufficient. Should not be used as monotherapy.

## Special Populations

- **HFrEF (LVEF < 40%):** Use beta-blockers and/or digoxin. Avoid non-DHP CCBs (negative inotropy).
- **Pre-excitation (WPW):** Avoid AV nodal blocking agents (beta-blockers, CCBs, digoxin). Refer for catheter ablation of accessory pathway.
- **Acute rate control:** IV beta-blockers or IV diltiazem for rapid ventricular response. Amiodarone IV if hemodynamically compromised.
