# Antibiotic Therapy for Community Acquired Pneumonia — BTS 2009

## General Principles

- Start empirical antibiotics as soon as CAP diagnosis is made (within 4 hours of admission for inpatients).
- Choice of agent depends on severity (CURB-65) and local resistance patterns.
- Always obtain blood cultures and sputum culture before starting antibiotics in hospitalized patients.

## Recommended Regimens

### Low Severity (CURB-65 0–1, outpatient)
- **First-line:** Amoxicillin 500 mg TDS orally for 5 days.
- **Penicillin allergy:** Doxycycline 200 mg loading dose then 100 mg OD, or clarithromycin 500 mg BD.

### Moderate Severity (CURB-65 2, inpatient ward)
- **First-line:** Amoxicillin 500 mg–1 g TDS orally or IV PLUS clarithromycin 500 mg BD orally.
- **Penicillin allergy:** Levofloxacin 500 mg OD or moxifloxacin 400 mg OD (monotherapy).

### High Severity (CURB-65 3–5, inpatient/ICU)
- **First-line:** Co-amoxiclav 1.2 g TDS IV PLUS clarithromycin 500 mg BD IV.
- **Alternative:** Ceftriaxone 2 g OD IV PLUS clarithromycin 500 mg BD IV.
- **Penicillin allergy:** Levofloxacin 500 mg BD IV.
- If Legionella is suspected: Add levofloxacin or consider monotherapy with levofloxacin.

## Duration of Therapy

- **Uncomplicated low-severity CAP:** 5–7 days (extend if slow response).
- **Moderate to high severity CAP:** 7–10 days.
- **Legionella pneumonia:** 14–21 days.
- Extend if slow clinical response, empyema, lung abscess, or Staphylococcus aureus bacteremia.

## IV to Oral Switch

Switch from IV to oral antibiotics when:
1. Temperature < 37.5°C for 24 hours.
2. Clinically improving (respiratory rate, SpO2).
3. Functioning GI tract with oral intake.
