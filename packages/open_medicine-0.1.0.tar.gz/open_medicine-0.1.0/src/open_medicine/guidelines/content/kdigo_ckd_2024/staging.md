# CKD Staging — KDIGO 2024

## GFR Categories

| Stage | GFR (mL/min/1.73m²) | Description |
|-------|---------------------|-------------|
| G1 | ≥ 90 | Normal or high |
| G2 | 60–89 | Mildly decreased |
| G3a | 45–59 | Mildly to moderately decreased |
| G3b | 30–44 | Moderately to severely decreased |
| G4 | 15–29 | Severely decreased |
| G5 | < 15 | Kidney failure |

## Monitoring Frequency

Based on GFR category and albuminuria level:
- **G1-G2, A1:** Annual monitoring of eGFR and ACR.
- **G3a, A1 or G1-G2, A2:** Monitor every 6–12 months.
- **G3b or A2-A3:** Monitor every 3–6 months.
- **G4-G5:** Monitor every 1–3 months.

## Pharmacological Management by Stage

- **All stages with albuminuria (ACR ≥ 30 mg/g):** ACE inhibitor or ARB titrated to maximum tolerated dose (Grade 1B).
- **SGLT2 inhibitors** (dapagliflozin, empagliflozin) are recommended for adults with CKD regardless of diabetes status:
  - Grade 1A: If ACR > 200 mg/g (> 20 mg/mmol), or if heart failure is present (regardless of albuminuria).
  - Grade 1B: If eGFR 20–45 mL/min/1.73m² with ACR < 200 mg/g.
  - Once initiated, reasonable to continue even if eGFR falls below 20 mL/min/1.73m² unless intolerance or kidney replacement therapy is started.
- **G3-G5 with type 2 diabetes and ACR ≥ 30 mg/g:** Non-steroidal mineralocorticoid receptor antagonist (finerenone) may be added in addition to RAS blockade (Grade 1B). Requires type 2 diabetes specifically.
- **G4-G5:** Prepare for renal replacement therapy (dialysis or transplantation). Refer to nephrology if not already followed.

## Blood Pressure Targets

- Target systolic BP < 120 mmHg (measured by standardized office measurement) in adults with CKD (Grade 2B).
- Use a RAS inhibitor (ACEi or ARB) as first-line antihypertensive in CKD with albuminuria.
