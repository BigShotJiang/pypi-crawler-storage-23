# ACME Outdoor Gear — Products

## Accessories

- **[Carbon Trekking Poles](https://acme-outdoor.com/products/carbon-trekking-poles)** — USD 119.00 (In Stock)
- **[Dry Bag 20L](https://acme-outdoor.com/products/dry-bag-20l)** — USD 29.99 (In Stock)

## Bags

- **[Summit Backpack 40L](https://acme-outdoor.com/products/summit-backpack-40l)** — USD 89.99 (In Stock)

## Camping

- **[Titanium Cookset](https://acme-outdoor.com/products/titanium-cookset)** — USD 74.50 (In Stock)

## Clothing

- **[Alpine Jacket Waterproof](https://acme-outdoor.com/products/alpine-jacket)** — USD 199.99 (In Stock)
- **[Merino Wool Base Layer](https://acme-outdoor.com/products/merino-base-layer)** — USD 65.00 (In Stock)

## Electronics

- **[Solar Charger Panel](https://acme-outdoor.com/products/solar-charger)** — USD 59.99 (Pre-order)

## Footwear

- **[Trail Runner Pro](https://acme-outdoor.com/products/trail-runner-pro)** — USD 129.99 (In Stock)

## Lighting

- **[LED Headlamp 800lm](https://acme-outdoor.com/products/led-headlamp-800)** — USD 45.00 (In Stock)

## Shelter

- **[Ultralight Tent 2P](https://acme-outdoor.com/products/ultralight-tent-2p)** — USD 349.00 (Out of Stock)
