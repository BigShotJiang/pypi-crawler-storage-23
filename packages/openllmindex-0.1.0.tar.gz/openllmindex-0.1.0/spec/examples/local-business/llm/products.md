# Sunrise Bakery — Products

## Breads

- **Sourdough Loaf** — $6.50 (Available daily)
- **Whole Wheat Bread** — $5.50 (Available daily)
- **Rye Bread** — $6.00 (Wed & Sat only)
- **Ciabatta** — $5.00 (Available daily)

## Pastries

- **Butter Croissant** — $3.50 (Available daily)
- **Almond Croissant** — $4.50 (Available daily)
- **Pain au Chocolat** — $4.00 (Available daily)
- **Cinnamon Roll** — $4.50 (Fri–Sun only)

## Cakes

- **Carrot Cake (slice)** — $5.50
- **Chocolate Layer Cake (slice)** — $6.00
- **Custom Cakes** — Starting at $45, order 48 hours in advance

## Seasonal

- **Pumpkin Spice Scone** — $4.00 (Oct–Nov)
- **Stollen** — $12.00 (Dec only)

*All prices in USD. Menu items subject to daily availability.*
