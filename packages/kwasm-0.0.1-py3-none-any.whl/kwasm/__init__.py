from kwasm.embed import show

__all__ = ["show"]
__version__ = "0.0.1"
