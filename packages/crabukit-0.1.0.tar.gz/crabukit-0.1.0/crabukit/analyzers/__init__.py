"""Analyzers for different file types."""
