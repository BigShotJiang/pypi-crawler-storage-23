#!/usr/bin/env python3
"""Low risk script."""

def calculate(x, y):
    return x + y

if __name__ == "__main__":
    print(calculate(1, 2))
