# Initialize the compose_scripts package
