# 🏫 SAGE Education - Institutional Management / ERP

**Version:** 1.2.x   
**Module:** Akademy Company    
**Developer:** Zacarias Juliano Capingala  


---


## 📘 About the Project

**SAGE Education** is a ***free and open-source*** project for ***educators, educational institutions, and governments***.
It provides the functionality of **Academic Management System (AMS), School Management System (SMS), and Educational Information System (EIS)**.
Its ***modular, scalable, and secure*** design allows it to be implemented in many different scenarios: from **small schools** and **training centers** to **large national public education systems**.

SAGE Education has a growing, committed, and friendly community that brings together the best in the fields of ***educational sciences, pedagogy, educational technology, and computer science***.
No matter where in the world you live, we are passionate about upholding education and educational technology as a non-negotiable human right.

We hope you find **SAGE Education** motivating and inspiring, and we look forward to having you as part of the team.


We host a public demo server where you can try out SAGE Education with different access profiles:
[sage.comunidadedosaber.ao](https://sage.comunidadedosaber.ao)


| **Profile** | **User**     | 
|-------------|--------------|
| Student     | student      |
| Teacher     | teacher      | 
| Secretary   | secretary    | 
| Direction   | direction    | 
| Admin       | admin        |


---


## Akademy Company Module

The **Akademy Company (Institution Management)** module is a complementary module responsible for **expanding the functionalities** of the **Organization Management** module, offering advanced tools for managing organizations.

### 🎯 Purpose

This module centralizes the **institutional identity and human structure** of an educational organization, including:
- Companies and institutions,
- Employees and internal roles,
- Students as registered institutional entities,
- Student–supervisor relationships,
- Institutional reporting.

It is designed to be used by **schools, training centers, universities, and educational authorities**.

### ✨ Main Features

#### 🏢 Institutional Management
- Extension of Tryton `Company` and `Party` models
- Educational institution registration
- Centralized institutional data

#### 👥 Human Resources (Foundational)
- Employee registration and management
- Role-based organizational structure
- Employee institutional reports

#### 🎓 Student Registry
- Student registration as institutional entities
- Student–supervisor relationships
- Student institutional records

#### 📊 Reports & Documents
- Institutional reports
- Employee reports
- Student reports


---


## 🌍 Target Audience

- Educational institutions
- System administrators
- Open-source contributors
- Governments and NGOs
- Educational software integrators


### 🌐 Homepage
  
**Website:** [sage-edu.comunidadedosaber.ao](https://sage-edu.comunidadedosaber.ao)  
**App:** [sage.comunidadedosaber.ao](https://sage-edu.comunidadedosaber.ao)  
**Docs:** [docs.comunidadedosaber.ao](https://sage-edu.comunidadedosaber.ao)  
**Team:** [comunidadedosaber.ao](https://comunidadedosaber.ao)  
**PyPi:** [SAGE Edu](https://pypi.org/user/comunidade_do_saber)


---


## 🤝 Contributing

Contributions are welcome!
Please open an issue or submit a pull request following the SAGE Edu contribution guidelines.

### 💬 Technical Support

If you encounter any errors or require technical support, please contact us through the channels below:

- 📧 **E-mail:**  
    -   [suporte@comunidadedosaber.ao](mailto:suporte@comunidadedosaber.ao)
    -   [comercial@comunidadedosaber.ao](mailto:comercial@comunidadedosaber.ao)   
- 💬 **WhatsApp:** [+244 955 868 110](https://wa.me/244955868110)

