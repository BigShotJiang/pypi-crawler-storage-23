from matplotlib import pyplot, patches

from RampantTrackGeneration import TrackGenerator

from uuid import uuid4

baseWidth = 600
baseHeight = 600

diagramRegions = 18
    
percentToProcess = 0.50

newConnectionAngleMinQuantile = 0.45
lonelyConnectionMinLengthQuantile = 0.25

connectionEdgeVertexPadding = 0.20
connectionEdgeNodeBuffer = 0.10

destinationDistanceUpperQuantile = 0.50

track = TrackGenerator.generateTrack(
    diagramWidth = baseWidth, 
    diagramHeight = baseHeight,
    numDiagramRegions = diagramRegions,
    diagramEdgePercentageToProcess = percentToProcess,
    newConnectionAngleMinQuantile = newConnectionAngleMinQuantile,
    lonelyConnectionMinLengthQuantile = lonelyConnectionMinLengthQuantile,
    connectionLengthVertexPadding = connectionEdgeVertexPadding,
    connectionLengthNodeBuffer = connectionEdgeNodeBuffer,
    destinationDistanceUpperQuantile = destinationDistanceUpperQuantile
)

pyplot.figure("track")
(_, ax) = pyplot.subplots()

startColor = "blue"
endColor = "red"
defaultColor = "grey"

startNode = track.startNode
destinationNode = track.destinationNode

def determineNodeColor(node: uuid4) -> str:
    match node:
        case track.startNode:
            return startColor
        case track.destinationNode:
            return endColor
        case _:
            return defaultColor

for (edgeId, nodes) in track.stops.items():
    edge = track.edges[edgeId]

    node0Id = edge.vertex0Id
    node1Id = edge.vertex1Id

    node0 = track.nodes[node0Id]
    node1 = track.nodes[node1Id]

    pyplot.plot([node0.x, node1.x], [node0.y, node1.y])

    node0Circle = patches.Circle(xy = (node0.x, node0.y), radius = 3, color = determineNodeColor(node0Id))
    ax.add_patch(node0Circle)

    node1Circle = patches.Circle(xy = (node1.x, node1.y), radius = 3, color = determineNodeColor(node1Id))
    ax.add_patch(node1Circle)

    for node in nodes:
        nodeCircle = patches.Circle(xy = (node.x, node.y), radius = 1.5, color = 'black')
        ax.add_patch(nodeCircle)

pyplot.axis("off")
pyplot.tight_layout(pad=0)
pyplot.show()