"""Google Search FastAPI 服务 — 搜索 API + 代理状态 API。

使用 ProxyManager 管理固定代理列表（warp + 备用），
不再依赖 MongoDB 代理池。
"""

import asyncio
import uvicorn

from contextlib import asynccontextmanager
from fastapi import FastAPI, HTTPException, Query
from pydantic import BaseModel, Field
from tclogger import logger, logstr
from typing import Optional

from .proxy_manager import ProxyManager, DEFAULT_PROXIES
from .scraper import GoogleScraper
from ..fastapis.styles import setup_swagger_ui


# ═══════════════════════════════════════════════════════════════
# 请求/响应模型
# ═══════════════════════════════════════════════════════════════


class SearchRequest(BaseModel):
    """搜索请求。"""

    query: str = Field(..., description="搜索关键词", min_length=1, max_length=500)
    num: int = Field(10, description="期望的搜索结果数量", ge=1, le=50)
    lang: str = Field("en", description="搜索语言")
    proxy_url: Optional[str] = Field(None, description="指定代理 URL（可选）")


class SearchResultItem(BaseModel):
    """单个搜索结果。"""

    title: str = ""
    url: str = ""
    displayed_url: str = ""
    snippet: str = ""
    position: int = 0


class SearchResponse(BaseModel):
    """搜索响应。"""

    success: bool = True
    query: str = ""
    results: list[SearchResultItem] = []
    result_count: int = 0
    total_results_text: str = ""
    has_captcha: bool = False
    error: str = ""


class ProxyStatusItem(BaseModel):
    """单个代理状态。"""

    url: str = ""
    name: str = ""
    healthy: bool = False
    latency_ms: int = 0
    consecutive_failures: int = 0
    total_successes: int = 0
    total_failures: int = 0
    success_rate: str = ""
    last_check: str = ""


class ProxyStatusResponse(BaseModel):
    """代理状态响应。"""

    total_proxies: int = 0
    healthy_proxies: int = 0
    unhealthy_proxies: int = 0
    proxies: list[ProxyStatusItem] = []


class HealthResponse(BaseModel):
    """健康检查。"""

    status: str = "ok"
    version: str = "1.1.0"


# ═══════════════════════════════════════════════════════════════
# 应用工厂
# ═══════════════════════════════════════════════════════════════


def create_google_search_server(
    proxies: list[dict] = None,
    headless: bool = True,
) -> FastAPI:
    """创建 Google 搜索 FastAPI 应用。

    Args:
        proxies: 代理列表配置（默认使用 DEFAULT_PROXIES）
        headless: 是否无头浏览器模式
    """

    proxy_manager: ProxyManager = None
    scraper: GoogleScraper = None

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        nonlocal proxy_manager, scraper
        logger.note("> Initializing Google Search Server ...")

        # 启动代理管理器
        proxy_manager = ProxyManager(
            proxies=proxies or DEFAULT_PROXIES,
            verbose=True,
        )
        await proxy_manager.start()

        # 启动搜索抓取器
        scraper = GoogleScraper(
            proxy_manager=proxy_manager,
            headless=headless,
        )
        await scraper.start()

        logger.okay("  ✓ Google Search Server ready")
        yield

        if scraper:
            await scraper.stop()
        if proxy_manager:
            await proxy_manager.stop()

    app = FastAPI(
        title="Google Search API",
        description=(
            "基于 Playwright 的 Google 搜索 API。\n\n"
            "使用固定代理列表（warp + 备用）进行搜索，"
            "支持自动故障转移和健康检查。"
        ),
        version="1.1.0",
        lifespan=lifespan,
    )
    setup_swagger_ui(app)

    def _ensure_ready():
        if not proxy_manager or not scraper:
            raise HTTPException(status_code=503, detail="Server not ready")

    # ── 系统接口 ──────────────────────────────────────────────

    @app.get("/health", response_model=HealthResponse, tags=["系统"])
    async def health_check():
        """健康检查。"""
        return HealthResponse()

    # ── 搜索接口 ──────────────────────────────────────────────

    @app.post("/search", response_model=SearchResponse, tags=["搜索"])
    async def search(req: SearchRequest):
        """执行 Google 搜索并返回解析后的结果。"""
        _ensure_ready()
        try:
            result = await scraper.search(
                query=req.query,
                num=req.num,
                lang=req.lang,
                proxy_url=req.proxy_url,
            )
            return SearchResponse(
                success=bool(result.results) and not result.has_captcha,
                query=result.query,
                results=[
                    SearchResultItem(**r.to_dict()) for r in result.results
                ],
                result_count=len(result.results),
                total_results_text=result.total_results_text,
                has_captcha=result.has_captcha,
                error=result.error,
            )
        except Exception as e:
            logger.err(f"  × Search error: {e}")
            raise HTTPException(status_code=500, detail=str(e))

    @app.get("/search", response_model=SearchResponse, tags=["搜索"])
    async def search_get(
        q: str = Query(..., description="搜索关键词", min_length=1),
        num: int = Query(10, description="结果数量", ge=1, le=50),
        lang: str = Query("en", description="搜索语言"),
    ):
        """GET 方式执行 Google 搜索。"""
        req = SearchRequest(query=q, num=num, lang=lang)
        return await search(req)

    # ── 代理状态接口 ──────────────────────────────────────────

    @app.get("/proxy/status", response_model=ProxyStatusResponse, tags=["代理"])
    async def proxy_status():
        """获取代理健康状态。"""
        _ensure_ready()
        stats = proxy_manager.stats()
        return ProxyStatusResponse(
            total_proxies=stats["total_proxies"],
            healthy_proxies=stats["healthy_proxies"],
            unhealthy_proxies=stats["unhealthy_proxies"],
            proxies=[ProxyStatusItem(**p) for p in stats["proxies"]],
        )

    @app.get("/proxy/current", tags=["代理"])
    async def proxy_current():
        """获取当前推荐的代理。"""
        _ensure_ready()
        proxy_url = proxy_manager.get_proxy()
        if not proxy_url:
            raise HTTPException(status_code=404, detail="No proxy available")
        return {"proxy_url": proxy_url}

    @app.post("/proxy/check", tags=["代理"])
    async def proxy_check_now():
        """立即对所有代理执行健康检查。"""
        _ensure_ready()
        await proxy_manager._check_all()
        return proxy_manager.stats()

    return app


def app_instance():
    """工厂函数 — 供 uvicorn --factory 使用。"""
    return create_google_search_server()


# ═══════════════════════════════════════════════════════════════
# 入口
# ═══════════════════════════════════════════════════════════════


def main():
    """启动 Google Search API 服务。"""
    import argparse

    argparser = argparse.ArgumentParser(description="Google Search API Server")
    argparser.add_argument("--host", default="0.0.0.0", help="Bind host")
    argparser.add_argument("--port", type=int, default=18000, help="Bind port")
    argparser.add_argument("--no-headless", action="store_true", help="Show browser")
    args = argparser.parse_args()

    app = create_google_search_server(headless=not args.no_headless)
    uvicorn.run(app, host=args.host, port=args.port)


if __name__ == "__main__":
    main()
