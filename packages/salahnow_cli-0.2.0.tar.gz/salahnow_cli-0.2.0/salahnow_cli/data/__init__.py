# Package data for SalahNow CLI.
