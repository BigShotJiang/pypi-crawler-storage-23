"""AskSage connector for DeepSigma canonical record ingestion."""
from adapters.asksage.connector import AskSageConnector

__all__ = ["AskSageConnector"]
