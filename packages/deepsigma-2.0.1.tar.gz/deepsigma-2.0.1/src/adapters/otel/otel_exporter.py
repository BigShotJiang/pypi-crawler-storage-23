"""Backward compatibility re-export. Use adapters.otel.exporter instead."""
from adapters.otel.exporter import OtelExporter  # noqa: F401
