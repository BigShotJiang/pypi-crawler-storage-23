"""Excel-first Money Demo — deterministic Drift→Patch proof."""
