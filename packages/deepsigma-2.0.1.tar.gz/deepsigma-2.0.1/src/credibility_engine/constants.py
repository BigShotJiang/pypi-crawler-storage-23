"""Credibility Engine — Constants.

Shared constants for multi-tenant credibility engine.
"""

DEFAULT_TENANT_ID = "tenant-alpha"
