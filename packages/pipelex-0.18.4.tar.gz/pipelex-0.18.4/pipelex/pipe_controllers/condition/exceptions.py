from pipelex.base_exceptions import PipelexError


class PipeConditionFactoryError(PipelexError):
    pass
