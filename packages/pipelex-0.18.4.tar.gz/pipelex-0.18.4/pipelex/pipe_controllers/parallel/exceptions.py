from pipelex.base_exceptions import PipelexError


class PipeParallelFactoryError(PipelexError):
    pass
