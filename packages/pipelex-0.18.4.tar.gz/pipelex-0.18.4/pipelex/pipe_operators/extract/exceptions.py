from pipelex.base_exceptions import PipelexError


class PipeExtractFactoryError(PipelexError):
    pass
