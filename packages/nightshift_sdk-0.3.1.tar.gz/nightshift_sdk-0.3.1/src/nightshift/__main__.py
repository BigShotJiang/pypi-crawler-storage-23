"""Starts the Nightshift agent entry point"""

from __future__ import annotations

from nightshift.agent.entry import main

if __name__ == "__main__":
    main()
