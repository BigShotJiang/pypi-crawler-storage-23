import base64
import json
import re
from abc import ABC
from enum import Enum
from typing import Any, ClassVar, TypeVar, get_args, get_origin

import ormsgpack
import yaml
from pydantic import BaseModel, ValidationError

T = TypeVar("T", bound="Message")


class MessageError(Exception):
    """
    Base exception for Message errors.
    """


class SerializationError(MessageError):
    """
    Raised when serialization (pack, to_json) fails.
    """


class DeserializationError(MessageError):
    """
    Raised when deserialization (unpack, from_json) fails.
    """


class FileAccessError(MessageError):
    """
    Raised when file operations fail.
    """


class MismatchError(MessageError):
    """
    Raised when type doesn't match expected type or deserialization fails.
    """

    def __init__(self, expected: str | None, actual: str | None, details: str | None = None):
        self.expected = expected
        self.actual = actual
        self.details = details

        expected_str = "<untyped>" if expected is None else f"'{expected}'"
        actual_str = "<untyped>" if actual is None else f"'{actual}'"
        message = f"Type mismatch: expected {expected_str}, got {actual_str}"
        if details is not None:
            message += f" - {details}"

        super().__init__(message)


class Message(BaseModel, ABC):
    """
    @docs-exclude
    Base class for user-defined data types supporting serialization and deserialization.

    To add a type identifier, simply set a '_type' class variable. Otherwise, the message will
    have type=null in the serialized format.

    ```python
    class MyMessage(Message):
        _type = "my_message"
        field1: str
        field2: int
    ```
    """

    _type: ClassVar[str | None] = None

    model_config = {
        "extra": "forbid",
        "frozen": True,
        "arbitrary_types_allowed": True,
    }

    def __init_subclass__(cls, **kwargs: Any) -> None:
        """
        Validate type format and restore hashability when subclass is defined.

        Pydantic sets __hash__ = None on subclasses when a custom __eq__ is
        present. We restore the Message.__hash__ on every subclass so that
        all messages are hashable.
        """

        super().__init_subclass__(**kwargs)
        if cls._type is not None and not re.compile(r"^[a-z0-9][a-z0-9\-_/]*$").match(cls._type):
            raise ValueError(
                f"Invalid type '{cls._type}' for {cls.__name__} (must be lowercase alphanumeric with hyphens, underscores, or slashes)"
            )

        # Pydantic sets __hash__ = None on subclasses; restore it
        cls.__hash__ = Message.__hash__  # type: ignore[assignment]

    def __str__(self) -> str:
        """
        Return a clean string representation of the message.

        :return: A formatted string showing the message type and field values.
        """

        field_strs = []
        for field_name, field_value in self:
            formatted_value = f'"{field_value}"' if isinstance(field_value, str) else str(field_value)
            field_strs.append(f"{field_name}={formatted_value}")

        return f"<{self.__class__.__name__}: {' '.join(field_strs)}>"

    def __repr__(self) -> str:
        """
        Return a detailed representation that can reconstruct the object.

        :return: A string representation suitable for debugging.
        """

        return super().__repr__()

    def __hash__(self) -> int:
        """
        Make Message hashable for use in sets and as dict keys.

        Handles nested unhashable types (lists, dicts) by converting them
        to tuples recursively.

        :return: Hash value based on class type, type, and field values.
        """

        def _make_hashable(v: Any) -> Any:
            if isinstance(v, dict):
                return tuple(sorted((_make_hashable(k), _make_hashable(val)) for k, val in v.items()))
            if isinstance(v, (list, tuple)):
                return tuple(_make_hashable(item) for item in v)
            return v

        field_items = tuple(sorted((_make_hashable(k), _make_hashable(v)) for k, v in self.model_dump().items()))
        return hash((self.__class__.__name__, self.get_type(), field_items))

    def __eq__(self, other: Any) -> bool:
        """
        Compare messages based on class, type identifier, and field values.

        :param other: The other object to compare with.
        :return: True if messages are equal, False otherwise.
        """

        if not isinstance(other, self.__class__):
            return False
        if self.get_type() != other.get_type():
            return False

        return self.model_dump() == other.model_dump()

    @classmethod
    def get_type(cls) -> str | None:
        """
        Get the type identifier for this message class.

        :return: The type string if set, None otherwise.
        """

        return cls._type

    # ------------------------------------------------------------------
    # Serialization
    # ------------------------------------------------------------------

    @staticmethod
    def pack_json(data: dict[str, Any]) -> bytes:
        """
        Pack an arbitrary dict into a message envelope with null type.

        This allows flexible telemetry without requiring Message implementations.
        The dict is wrapped in an envelope with type=None and serialized to MessagePack.

        :param data: Dictionary to pack.
        :return: The MessagePack bytes.
        :raises SerializationError: If serialization fails.
        """

        try:
            envelope = {"type": None, "data": data}
            return ormsgpack.packb(envelope)
        except Exception as e:
            raise SerializationError(f"Failed to serialize dict: {e}") from None

    def pack(self) -> bytes:
        """
        Serialize the message to bytes using MessagePack.

        :return: The MessagePack bytes.
        :raises SerializationError: If serialization fails.
        """

        try:
            envelope = {
                "type": self.get_type(),
                "data": self.model_dump(mode="python", by_alias=True),
            }
            return ormsgpack.packb(envelope)
        except Exception as e:
            raise SerializationError(f"Failed to serialize message: {e}") from None

    def to_json(self, indent: int | None = None) -> str:
        """
        Serialize the message to a JSON string.

        Binary fields (bytes) are automatically base64-encoded.

        :param indent: Number of spaces to indent for pretty printing.
        :return: The JSON string.
        :raises SerializationError: If serialization fails.
        """

        try:
            return json.dumps(self._to_envelope(), indent=indent)
        except Exception as e:
            raise SerializationError(f"Failed to serialize to JSON: {e}") from e

    def to_yaml(self) -> str:
        """
        Serialize the message to a YAML string.

        Binary fields (bytes) are automatically base64-encoded. Enum values
        are normalized to plain strings for safe YAML round-tripping.

        :return: The YAML string.
        :raises SerializationError: If serialization fails.
        """

        try:
            data = self.model_dump(mode="python", by_alias=True)
            data = self._normalize_for_text(data)
            envelope = {"type": self.get_type(), "data": data}
            return yaml.dump(envelope, default_flow_style=False, sort_keys=False)
        except Exception as e:
            raise SerializationError(f"Failed to serialize to YAML: {e}") from None

    def to_dict(self) -> dict[str, Any]:
        """
        Serialize with standard envelope structure.

        :return: The serialized object.
        """

        return {
            "type": self.get_type(),
            "data": self.model_dump(mode="python", by_alias=True),
        }

    def save(self, file_path: str, format: str | None = None) -> None:
        """
        Save the message to a file.

        The format is determined by the file extension if not specified.
        Supported formats: json, yaml, msgpack

        :param file_path: Path to save the file to.
        :param format: Optional format override ('json', 'yaml', 'msgpack').
        :raises FileAccessError: If the file cannot be written.
        :raises SerializationError: If serialization fails.
        """

        if format is None:
            if file_path.endswith(".json"):
                format = "json"
            elif file_path.endswith((".yaml", ".yml")):
                format = "yaml"
            elif file_path.endswith((".msgpack", ".mp")):
                format = "msgpack"
            else:
                raise FileAccessError(f"Cannot determine format from extension: {file_path}")

        try:
            if format == "json":
                content = self.to_json(indent=2)
                mode = "w"
            elif format == "yaml":
                content = self.to_yaml()
                mode = "w"
            elif format == "msgpack":
                content = self.pack()
                mode = "wb"
            else:
                raise FileAccessError(f"Unsupported format: {format}")

            with open(file_path, mode) as f:
                f.write(content)
        except SerializationError:
            raise
        except Exception as e:
            raise FileAccessError(f"Failed to save to {file_path}: {e}") from None

    # ------------------------------------------------------------------
    # Deserialization
    # ------------------------------------------------------------------

    @classmethod
    def unpack(cls: type[T], data: bytes) -> T:
        """
        Deserialize a message from bytes using MessagePack.

        This validates that the type in the envelope matches the expected type
        for this class.

        :param data: The MessagePack bytes to deserialize.
        :return: The deserialized message.
        :raises DeserializationError: If deserialization fails.
        :raises MismatchError: If the type doesn't match.
        """

        try:
            envelope = ormsgpack.unpackb(data)
            cls._validate_envelope(envelope)

            if envelope["type"] != cls.get_type():
                raise MismatchError(expected=cls.get_type(), actual=envelope["type"])

            return cls(**envelope["data"])
        except (MismatchError, DeserializationError):
            raise
        except ValidationError as e:
            first_error = e.errors()[0]
            field_path = " -> ".join(str(loc) for loc in first_error["loc"])
            error_msg = first_error["msg"]
            raise DeserializationError(f"Validation failed at {field_path}: {error_msg}") from None
        except Exception as e:
            if "msgpack" in str(e).lower() or "unpackb" in str(e):
                raise DeserializationError("Failed to deserialize message") from None
            raise DeserializationError(f"Failed to deserialize message: {e}") from None

    @classmethod
    def from_json(cls: type[T], json_str: str) -> T:
        """
        Deserialize a message from a JSON string.

        Bytes fields are expected as base64-encoded strings.

        :param json_str: The JSON string to deserialize.
        :return: The deserialized message.
        :raises DeserializationError: If deserialization fails or JSON is invalid.
        :raises MismatchError: If the type doesn't match.
        """

        try:
            envelope = json.loads(json_str)
            return cls._from_envelope(envelope)
        except json.JSONDecodeError:
            raise DeserializationError("Invalid JSON format") from None
        except (MismatchError, DeserializationError):
            raise
        except ValidationError as e:
            first_error = e.errors()[0]
            field_path = " -> ".join(str(loc) for loc in first_error["loc"])
            error_msg = first_error["msg"]
            raise DeserializationError(f"Validation failed at {field_path}: {error_msg}") from None
        except Exception as e:
            raise DeserializationError(f"Failed to deserialize from JSON: {e}") from None

    @classmethod
    def from_yaml(cls: type[T], yaml_str: str) -> T:
        """
        Deserialize a message from a YAML string.

        Bytes fields are expected as base64-encoded strings.

        :param yaml_str: The YAML string to deserialize.
        :return: The deserialized message.
        :raises DeserializationError: If deserialization fails or YAML is invalid.
        :raises MismatchError: If the type doesn't match.
        """

        try:
            envelope = yaml.safe_load(yaml_str)
            return cls._from_envelope(envelope)
        except yaml.YAMLError as e:
            raise DeserializationError(f"Invalid YAML format: {e}") from None
        except (MismatchError, DeserializationError):
            raise
        except ValidationError as e:
            first_error = e.errors()[0]
            field_path = " -> ".join(str(loc) for loc in first_error["loc"])
            error_msg = first_error["msg"]
            raise DeserializationError(f"Validation failed at {field_path}: {error_msg}") from None
        except Exception as e:
            raise DeserializationError(f"Failed to deserialize from YAML: {e}") from None

    @classmethod
    def load(cls: type[T], file_path: str, format: str | None = None) -> T:
        """
        Load a message from a file.

        The format is determined by the file extension if not specified.
        Supported formats: json, yaml, msgpack

        :param file_path: Path to load the file from.
        :param format: Optional format override ('json', 'yaml', 'msgpack').
        :return: The loaded message.
        :raises FileAccessError: If the file cannot be read.
        :raises DeserializationError: If deserialization fails.
        :raises MismatchError: If the type doesn't match.
        """

        if format is None:
            if file_path.endswith(".json"):
                format = "json"
            elif file_path.endswith((".yaml", ".yml")):
                format = "yaml"
            elif file_path.endswith((".msgpack", ".mp")):
                format = "msgpack"
            else:
                raise FileAccessError(f"Cannot determine format from extension: {file_path}")

        try:
            if format == "json":
                with open(file_path) as f:
                    return cls.from_json(f.read())
            elif format == "yaml":
                with open(file_path) as f:
                    return cls.from_yaml(f.read())
            elif format == "msgpack":
                with open(file_path, "rb") as f:
                    return cls.unpack(f.read())
            else:
                raise FileAccessError(f"Unsupported format: {format}")
        except (DeserializationError, MismatchError):
            raise
        except FileNotFoundError:
            raise FileAccessError(f"File not found: {file_path}") from None
        except Exception as e:
            raise FileAccessError(f"Failed to load from {file_path}: {e}") from None

    # ------------------------------------------------------------------
    # Extraction (without full deserialization)
    # ------------------------------------------------------------------

    @staticmethod
    def extract_type(data: bytes) -> str | None:
        """
        Extract the type identifier from a serialized message without full deserialization.

        This is useful for dynamic message routing where you need to determine the message
        type before deciding how to deserialize it.

        :param data: The MessagePack bytes to extract type from.
        :return: The type string, or None if no type is set.
        :raises DeserializationError: If the data cannot be parsed.

        Example:
        ```python
        packed = some_message.pack()
        msg_type = Message.extract_type(packed)
        match msg_type:
            case "user_profile":
                profile = UserProfile.unpack(packed)
            case "order_update":
                order = OrderUpdate.unpack(packed)
            case _:
                raise ValueError(f"Unknown message type: {msg_type}")
        ```
        """

        try:
            envelope = ormsgpack.unpackb(data)
            Message._validate_envelope(envelope)
            return envelope["type"]
        except (ValueError, TypeError) as e:
            raise DeserializationError(f"Failed to extract message type: {e}") from None
        except RecursionError:
            raise DeserializationError("Message structure too deeply nested") from None

    @staticmethod
    def extract_type_from_json(json_str: str) -> str | None:
        """
        Extract the type identifier from a JSON string without full deserialization.

        :param json_str: The JSON string to extract type from.
        :return: The type string, or None if no type is set.
        :raises DeserializationError: If the JSON cannot be parsed.
        """

        try:
            data = json.loads(json_str)
            Message._validate_envelope(data)
            return data["type"]
        except json.JSONDecodeError:
            raise DeserializationError("Invalid JSON format") from None

    @staticmethod
    def extract_data_as_json(data: bytes) -> dict:
        """
        Extract the data field from a serialized message as a dictionary.

        :param data: The MessagePack bytes to extract data from.
        :return: The data field as a dictionary.
        :raises DeserializationError: If the data cannot be parsed.
        """

        try:
            envelope = ormsgpack.unpackb(data)
            Message._validate_envelope(envelope)
            return envelope["data"]
        except Exception as e:
            raise DeserializationError(f"Failed to extract message data: {e}") from None

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _validate_envelope(envelope: Any) -> None:
        """
        Validate envelope structure.

        :param envelope: The envelope to validate.
        :raises DeserializationError: If envelope structure is invalid.
        """

        if not isinstance(envelope, dict):
            raise DeserializationError("Invalid message format: expected dictionary")
        if "type" not in envelope or "data" not in envelope:
            raise DeserializationError("Invalid message format: missing 'type' or 'data' field")

    @staticmethod
    def _encode_bytes(obj: Any) -> Any:
        """
        Recursively base64-encode any bytes values in a data structure.

        :param obj: The data structure to process.
        :return: A copy with bytes values replaced by base64 strings.
        """

        if isinstance(obj, bytes):
            return base64.b64encode(obj).decode("ascii")
        if isinstance(obj, dict):
            return {k: Message._encode_bytes(v) for k, v in obj.items()}
        if isinstance(obj, list):
            return [Message._encode_bytes(item) for item in obj]
        return obj

    @classmethod
    def _decode_bytes(cls, obj: Any, annotation: Any) -> Any:
        """
        Recursively decode base64 strings back to bytes using type annotations.

        :param obj: The data structure to process.
        :param annotation: The type annotation for the current level.
        :return: A copy with base64 strings decoded to bytes where appropriate.
        """

        # Unwrap Optional[X] to get the inner type
        origin = get_origin(annotation)
        if origin is type(None):
            return obj
        args = get_args(annotation)
        if args and type(None) in args:
            if obj is None:
                return None
            non_none = [a for a in args if a is not type(None)]
            if len(non_none) == 1:
                annotation = non_none[0]
                origin = get_origin(annotation)
                args = get_args(annotation)

        # Direct bytes field
        if annotation is bytes and isinstance(obj, str):
            return base64.b64decode(obj)

        # dict with typed values
        if origin is dict and args and len(args) == 2 and isinstance(obj, dict):
            return {k: cls._decode_bytes(v, args[1]) for k, v in obj.items()}

        # list with typed elements
        if origin is list and args and isinstance(obj, list):
            return [cls._decode_bytes(item, args[0]) for item in obj]

        # Nested Pydantic model
        if isinstance(annotation, type) and issubclass(annotation, BaseModel) and isinstance(obj, dict):
            return {
                k: cls._decode_bytes(v, annotation.model_fields[k].annotation) if k in annotation.model_fields else v
                for k, v in obj.items()
            }

        return obj

    @staticmethod
    def _normalize_for_text(obj: Any) -> Any:
        """
        Recursively base64-encode bytes and normalize enums to plain strings.

        Combined single-pass normalization for text-based serialization
        (YAML). Avoids the need for a separate JSON round-trip to normalize
        enum values.

        :param obj: The data structure to process.
        :return: A copy with bytes base64-encoded and enums as plain strings.
        """

        if isinstance(obj, bytes):
            return base64.b64encode(obj).decode("ascii")
        if isinstance(obj, Enum):
            return obj.value
        if isinstance(obj, dict):
            return {k: Message._normalize_for_text(v) for k, v in obj.items()}
        if isinstance(obj, list):
            return [Message._normalize_for_text(item) for item in obj]
        return obj

    def _to_envelope(self) -> dict[str, Any]:
        """
        Build a serializable envelope dict with base64-encoded bytes.

        :return: Envelope dict ready for JSON/YAML serialization.
        """

        data = self.model_dump(mode="python", by_alias=True)
        data = self._encode_bytes(data)
        return {"type": self.get_type(), "data": data}

    @classmethod
    def _from_envelope(cls: type[T], envelope: dict[str, Any]) -> T:
        """
        Validate an envelope and reconstruct the message, decoding bytes.

        :param envelope: The envelope dict with type and data fields.
        :return: The deserialized message.
        :raises MismatchError: If the type doesn't match.
        """

        cls._validate_envelope(envelope)
        if envelope["type"] != cls.get_type():
            raise MismatchError(expected=cls.get_type(), actual=envelope["type"])

        # Decode base64 strings back to bytes using model field annotations
        data = {}
        for key, value in envelope["data"].items():
            if key in cls.model_fields:
                data[key] = cls._decode_bytes(value, cls.model_fields[key].annotation)
            else:
                data[key] = value

        return cls.model_validate(data)
