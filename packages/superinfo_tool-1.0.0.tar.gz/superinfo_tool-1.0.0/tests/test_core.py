"""Unit tests for SuperInfo core components."""

import json
import numpy as np
import pytest
import pytest_asyncio


class TestTextUtils:
    def test_chunk_text_short(self):
        from app.utils.text import chunk_text
        text = "Hello world. " * 5
        chunks = chunk_text(text, chunk_size=100, overlap=10)
        assert len(chunks) >= 1
        assert all(len(c) > 0 for c in chunks)

    def test_chunk_text_long(self):
        from app.utils.text import chunk_text
        text = "This is a sentence. " * 300
        chunks = chunk_text(text, chunk_size=100, overlap=20)
        assert len(chunks) > 1

    def test_clean_html_basic(self):
        from app.utils.text import clean_html
        html = "<html><body><script>alert(1)</script><p>Hello world</p></body></html>"
        text = clean_html(html)
        assert "Hello world" in text
        assert "alert" not in text

    def test_normalize_whitespace(self):
        from app.utils.text import _normalize_whitespace
        text = "Hello   world\n\n\n\nNew paragraph"
        result = _normalize_whitespace(text)
        assert "   " not in result
        assert "\n\n\n" not in result


class TestVectorStore:
    def test_initialize(self, tmp_path):
        from app.db.vector_store import VectorStore
        vs = VectorStore()
        vs._index_path = tmp_path / "index"
        vs._meta_path = tmp_path / "meta.json"
        vs.initialize(dimension=4)
        assert vs.index is not None
        assert vs.dimension == 4

    def test_add_and_search(self, tmp_path):
        from app.db.vector_store import VectorStore
        vs = VectorStore()
        vs._index_path = tmp_path / "index"
        vs._meta_path = tmp_path / "meta.json"
        vs.initialize(dimension=4)

        embeddings = np.random.rand(3, 4).astype(np.float32)
        meta = [
            {"url": "http://a.com", "title": "A", "text": "text a", "chunk_index": 0},
            {"url": "http://b.com", "title": "B", "text": "text b", "chunk_index": 0},
            {"url": "http://c.com", "title": "C", "text": "text c", "chunk_index": 0},
        ]
        ids = vs.add_chunks(embeddings, meta)
        assert len(ids) == 3

        query = np.random.rand(4).astype(np.float32)
        results = vs.search(query, top_k=2)
        assert len(results) == 2
        assert "url" in results[0]
        assert "score" in results[0]

    def test_empty_search(self, tmp_path):
        from app.db.vector_store import VectorStore
        vs = VectorStore()
        vs._index_path = tmp_path / "index"
        vs._meta_path = tmp_path / "meta.json"
        vs.initialize(dimension=4)
        query = np.random.rand(4).astype(np.float32)
        results = vs.search(query)
        assert results == []


class TestConfig:
    def test_settings_load(self):
        from app.core.config import get_settings
        settings = get_settings()
        assert settings.chunk_size > 0
        assert settings.top_k > 0
        assert settings.chunk_overlap > 0


class TestSchemas:
    def test_research_request_valid(self):
        from app.api.schemas import ResearchRequest
        req = ResearchRequest(question="What is quantum computing?")
        assert req.question == "What is quantum computing?"
        assert req.request_id is not None

    def test_research_request_too_short(self):
        from app.api.schemas import ResearchRequest
        with pytest.raises(Exception):
            ResearchRequest(question="Hi")

    def test_verify_request(self):
        from app.api.schemas import VerifyRequest
        req = VerifyRequest(claim="The earth is round.")
        assert req.claim == "The earth is round."

    def test_report_request(self):
        from app.api.schemas import ReportRequest
        req = ReportRequest(
            agent_outputs=[{"agent": "research", "answer": "test"}],
            title="Test Report",
        )
        assert len(req.agent_outputs) == 1


class TestSearchDeduplication:
    def test_osint_source_priority(self):
        from app.agents.verification import VerificationAgent

        class FakeResult:
            url: str
            def __init__(self, url):
                self.url = url

        agent = VerificationAgent()
        results = [
            FakeResult("https://example.com/article"),
            FakeResult("https://reuters.com/story"),
            FakeResult("https://gov.uk/page"),
        ]
        prioritized = agent._prioritize_sources(results)
        # reuters and gov should rank higher
        urls = [r.url for r in prioritized]
        assert "https://reuters.com/story" in urls[:2] or "https://gov.uk/page" in urls[:2]


class TestRAGContext:
    def test_format_context(self):
        from app.core.rag import format_context
        chunks = [
            {"chunk_id": 0, "url": "http://a.com", "title": "A", "text": "Hello world"},
            {"chunk_id": 1, "url": "http://b.com", "title": "B", "text": "Another chunk"},
        ]
        ctx = format_context(chunks)
        assert "[CHUNK-0]" in ctx
        assert "[CHUNK-1]" in ctx
        assert "Hello world" in ctx


class TestReportAgent:
    def test_collect_sources(self):
        from app.agents.report import ReportAgent
        agent = ReportAgent()
        outputs = [
            {"agent": "research", "sources": [
                {"url": "http://a.com", "title": "A", "snippet": "x", "source_type": "web"},
            ]},
            {"agent": "verification", "sources": [
                {"url": "http://b.com", "title": "B", "snippet": "y", "source_type": "web"},
                {"url": "http://a.com", "title": "A", "snippet": "x", "source_type": "web"},  # dup
            ]},
        ]
        sources = agent._collect_sources(outputs)
        assert len(sources) == 2  # deduped
