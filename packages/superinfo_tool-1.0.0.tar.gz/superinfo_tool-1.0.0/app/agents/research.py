"""Research Agent: web search + RAG + evidence-grounded answer."""

import asyncio
import json
import re
import uuid
from datetime import datetime
from typing import Optional

from app.core.config import settings
from app.core.llm import llm_client
from app.core.logging import logger
from app.core.rag import ingest_document, retrieve, format_context
from app.db.cache import cache
from app.utils.search import search_web, search_arxiv
from app.utils.text import fetch_and_clean


QUERY_DECOMPOSE_PROMPT = """You are a research planning assistant.
Given a research question, generate 3-5 diverse search queries to gather comprehensive information.
Return ONLY a JSON array of strings. Example: ["query 1", "query 2", "query 3"]

Research question: {question}"""

SYNTHESIS_PROMPT = """You are a rigorous research analyst. Answer the question using ONLY the provided context chunks.
Rules:
- Cite sources using [CHUNK-N] notation
- If context is insufficient, state what's missing
- Do NOT hallucinate facts not in the context
- Include a confidence score (0.0-1.0) based on evidence quality
- Identify knowledge gaps

Question: {question}

Context:
{context}

Respond in this JSON format:
{{
  "answer": "detailed answer with [CHUNK-N] citations",
  "confidence": 0.0-1.0,
  "knowledge_gaps": ["gap1", "gap2"],
  "chunk_ids_used": [0, 1, 2]
}}"""


class ResearchAgent:
    async def run(
        self,
        question: str,
        request_id: Optional[str] = None,
        include_arxiv: bool = False,
    ) -> dict:
        request_id = request_id or str(uuid.uuid4())
        start = datetime.utcnow()
        logger.info(f"[{request_id}] Research: {question[:80]}")

        # Step 1: Decompose into search queries
        queries = await self._decompose_question(question)
        logger.debug(f"[{request_id}] Queries: {queries}")

        # Step 2: Search and fetch
        all_results = []
        for q in queries[:4]:
            results = await search_web(q, num_results=5)
            all_results.extend(results)
            if include_arxiv:
                arxiv_results = await search_arxiv(q, max_results=3)
                all_results.extend(arxiv_results)

        # Deduplicate by URL
        seen_urls = set()
        unique_results = []
        for r in all_results:
            if r.url not in seen_urls:
                seen_urls.add(r.url)
                unique_results.append(r)

        logger.debug(f"[{request_id}] Fetching {len(unique_results[:8])} pages")

        # Step 3: Fetch and ingest
        fetch_tasks = [fetch_and_clean(r.url) for r in unique_results[:8]]
        fetched = await asyncio.gather(*fetch_tasks, return_exceptions=True)

        sources_ingested = []
        for result, content in zip(unique_results[:8], fetched):
            if isinstance(content, dict) and content:
                chunk_ids = await ingest_document(
                    text=content["text"],
                    url=result.url,
                    title=content.get("title") or result.title,
                    source_type=result.source,
                )
                sources_ingested.append({
                    "url": result.url,
                    "title": content.get("title") or result.title,
                    "chunk_ids": chunk_ids,
                    "snippet": result.snippet,
                    "source_type": result.source,
                })

        # Step 4: Retrieve relevant chunks
        chunks = await retrieve(question, top_k=settings.top_k)
        if not chunks:
            # Fallback to snippets
            context = "\n\n".join(
                f"Source: {r.title}\nURL: {r.url}\n{r.snippet}"
                for r in unique_results[:5]
            )
            synthesis_result = {
                "answer": f"Based on search snippets: {context[:500]}",
                "confidence": 0.3,
                "knowledge_gaps": ["Full page content unavailable"],
                "chunk_ids_used": [],
            }
        else:
            # Step 5: LLM synthesis
            context = format_context(chunks)
            prompt = SYNTHESIS_PROMPT.format(question=question, context=context)
            raw = await llm_client.complete(prompt, temperature=0.0)
            synthesis_result = self._parse_json(raw, question)

        duration_ms = int((datetime.utcnow() - start).total_seconds() * 1000)

        return {
            "request_id": request_id,
            "agent": "research",
            "question": question,
            "answer": synthesis_result.get("answer", ""),
            "confidence": synthesis_result.get("confidence", 0.5),
            "knowledge_gaps": synthesis_result.get("knowledge_gaps", []),
            "sources": sources_ingested,
            "chunks_retrieved": len(chunks),
            "search_queries": queries,
            "duration_ms": duration_ms,
        }

    async def _decompose_question(self, question: str) -> list[str]:
        prompt = QUERY_DECOMPOSE_PROMPT.format(question=question)
        try:
            raw = await llm_client.complete(prompt, temperature=0.0)
            queries = json.loads(self._extract_json(raw))
            if isinstance(queries, list):
                return [str(q) for q in queries[:5]]
        except Exception as e:
            logger.warning(f"Query decomposition failed: {e}")
        return [question]

    def _extract_json(self, text: str) -> str:
        match = re.search(r"(\[.*?\]|\{.*?\})", text, re.DOTALL)
        return match.group(1) if match else text

    def _parse_json(self, raw: str, question: str) -> dict:
        try:
            text = self._extract_json(raw)
            return json.loads(text)
        except Exception:
            return {
                "answer": raw,
                "confidence": 0.5,
                "knowledge_gaps": [],
                "chunk_ids_used": [],
            }


research_agent = ResearchAgent()
