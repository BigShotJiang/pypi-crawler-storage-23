"""Report Agent: normalizes and synthesizes multi-agent outputs into structured reports."""

import json
import uuid
from datetime import datetime
from typing import Optional

from app.core.llm import llm_client
from app.core.logging import logger


REPORT_PROMPT = """You are a professional research report writer. Synthesize the following agent outputs into a clean, structured Markdown report.

Requirements:
- Remove redundancy
- Normalize language
- Include a source table
- Add actionable insights
- Use professional tone
- Structure: Executive Summary → Findings → Evidence → Sources → Gaps → Recommendations

Agent outputs:
{agent_outputs}

Return a comprehensive Markdown report."""


class ReportAgent:
    async def synthesize(
        self,
        agent_outputs: list[dict],
        title: Optional[str] = None,
        request_id: Optional[str] = None,
    ) -> dict:
        request_id = request_id or str(uuid.uuid4())
        start = datetime.utcnow()

        serialized = json.dumps(agent_outputs, indent=2, default=str)[:8000]
        prompt = REPORT_PROMPT.format(agent_outputs=serialized)

        md_report = await llm_client.complete(prompt, temperature=0.1, max_tokens=3000)

        # Build structured JSON report
        sources = self._collect_sources(agent_outputs)
        json_report = self._build_json_report(agent_outputs, md_report, sources, title)

        duration_ms = int((datetime.utcnow() - start).total_seconds() * 1000)

        return {
            "request_id": request_id,
            "agent": "report",
            "title": title or "Research Report",
            "report_markdown": md_report,
            "report_json": json_report,
            "source_count": len(sources),
            "duration_ms": duration_ms,
        }

    def _collect_sources(self, agent_outputs: list[dict]) -> list[dict]:
        sources = []
        seen_urls = set()
        for output in agent_outputs:
            for src in output.get("sources", []):
                url = src.get("url", "")
                if url and url not in seen_urls:
                    seen_urls.add(url)
                    sources.append({
                        "url": url,
                        "title": src.get("title", ""),
                        "type": src.get("source_type", "web"),
                        "snippet": src.get("snippet", "")[:200],
                    })
        return sources

    def _build_json_report(
        self, agent_outputs: list[dict], md: str, sources: list[dict], title: Optional[str]
    ) -> dict:
        findings = []
        for output in agent_outputs:
            agent = output.get("agent", "unknown")
            if agent == "research":
                findings.append({
                    "type": "research",
                    "question": output.get("question"),
                    "answer": output.get("answer"),
                    "confidence": output.get("confidence"),
                    "knowledge_gaps": output.get("knowledge_gaps", []),
                })
            elif agent == "osint":
                findings.append({
                    "type": "osint",
                    "entity": output.get("entity"),
                    "summary": output.get("visibility_summary"),
                    "exposure_level": output.get("exposure_indicators", {}).get("level"),
                    "platforms": output.get("platforms_detected", []),
                })
            elif agent == "verification":
                findings.append({
                    "type": "verification",
                    "claim": output.get("claim"),
                    "status": output.get("status"),
                    "confidence": output.get("confidence"),
                    "verdict": output.get("verdict_summary"),
                })

        return {
            "title": title or "Research Report",
            "generated_at": datetime.utcnow().isoformat(),
            "findings": findings,
            "sources": sources,
            "raw_markdown": md,
        }


report_agent = ReportAgent()
