"""OSINT Agent: public digital footprint analysis (no auth, no scraping logins)."""

import asyncio
import json
import uuid
import re
from datetime import datetime
from typing import Optional

import httpx
from app.core.llm import llm_client
from app.core.logging import logger
from app.utils.search import search_web
from app.utils.text import fetch_and_clean


# Public platform URL patterns for username lookups
USERNAME_PLATFORMS = {
    "GitHub": "https://github.com/{username}",
    "Twitter/X": "https://twitter.com/{username}",
    "LinkedIn": "https://www.linkedin.com/in/{username}",
    "Reddit": "https://www.reddit.com/user/{username}",
    "HackerNews": "https://news.ycombinator.com/user?id={username}",
    "Medium": "https://medium.com/@{username}",
    "Dev.to": "https://dev.to/{username}",
    "Keybase": "https://keybase.io/{username}",
}

OSINT_ANALYSIS_PROMPT = """You are a professional public information analyst. 
Analyze ALL the collected public data below and extract comprehensive insights.

Entity: {entity}
Entity Type: {entity_type}

Collected Public Data:
{data}

Respond in JSON:
{{
  "visibility_summary": "2-3 paragraph detailed summary of who this person is based on public data",
  "platforms_detected": ["platform1", "platform2"],
  "exposure_indicators": {{
    "level": "low|medium|high",
    "indicators": ["what kind of info is publicly visible"]
  }},
  "professional_info": {{
    "current_role": "job title or role if found",
    "organization": "company or org if found",
    "skills": ["skill1", "skill2"],
    "education": "education background if found"
  }},
  "online_activity": {{
    "most_active_platforms": ["platform1"],
    "content_topics": ["topic1", "topic2"],
    "estimated_influence": "low|medium|high"
  }},
  "key_observations": [
    "specific finding 1",
    "specific finding 2",
    "specific finding 3"
  ],
  "public_source_refs": ["url1", "url2"]
}}"""

class OSINTAgent:
    async def run_username(self, username: str, request_id: Optional[str] = None) -> dict:
        request_id = request_id or str(uuid.uuid4())
        start = datetime.utcnow()
        logger.info(f"[{request_id}] OSINT username: {username}")

        # Check platform URLs
        platform_results = await self._check_platforms(username)

        # Web search
        search_results = await search_web(f'"{username}" site:github.com OR site:twitter.com OR site:linkedin.com')
        search_results += await search_web(f'"{username}" public profile')

        # Fetch reachable pages
        pages = []
        urls_to_fetch = [r["url"] for r in platform_results if r.get("accessible")][:4]
        for url in urls_to_fetch:
            content = await fetch_and_clean(url)
            if content:
                pages.append(content)

        collected_data = self._format_collected(platform_results, search_results, pages)
        analysis = await self._analyze(username, "username", collected_data)
        duration_ms = int((datetime.utcnow() - start).total_seconds() * 1000)

        return {
            "request_id": request_id,
            "agent": "osint",
            "entity": username,
            "entity_type": "username",
            "platform_checks": platform_results,
            "search_results": [r.to_dict() for r in search_results[:5]],
            **analysis,
            "duration_ms": duration_ms,
        }

    async def run_domain(self, domain: str, request_id: Optional[str] = None) -> dict:
        request_id = request_id or str(uuid.uuid4())
        start = datetime.utcnow()
        logger.info(f"[{request_id}] OSINT domain: {domain}")

        # Collect public domain info
        domain_data = await self._collect_domain_info(domain)
        search_results = await search_web(f"site:{domain} OR \"{domain}\"")
        search_results += await search_web(f"{domain} company organization about")

        collected_data = json.dumps(domain_data, indent=2) + "\n\nSearch Results:\n"
        collected_data += "\n".join(f"- {r.title}: {r.snippet}" for r in search_results[:8])

        analysis = await self._analyze(domain, "domain", collected_data)
        duration_ms = int((datetime.utcnow() - start).total_seconds() * 1000)

        return {
            "request_id": request_id,
            "agent": "osint",
            "entity": domain,
            "entity_type": "domain",
            "domain_info": domain_data,
            "search_results": [r.to_dict() for r in search_results[:5]],
            **analysis,
            "duration_ms": duration_ms,
        }

    async def _check_platforms(self, username: str) -> list[dict]:
        results = []
        async with httpx.AsyncClient(
            timeout=httpx.Timeout(5.0, connect=3.0),
            follow_redirects=True
        ) as client:
            tasks = []
            for platform, url_template in USERNAME_PLATFORMS.items():
                url = url_template.format(username=username)
                tasks.append(self._check_url(client, platform, url))
            checked = await asyncio.gather(*tasks, return_exceptions=True)
            for item in checked:
                if isinstance(item, dict):
                    results.append(item)
        return results

    async def _check_url(self, client: httpx.AsyncClient, platform: str, url: str) -> dict:
        try:
            resp = await client.head(url)
            accessible = resp.status_code in (200, 301, 302)
            return {"platform": platform, "url": url, "accessible": accessible, "status": resp.status_code}
        except Exception:
            return {"platform": platform, "url": url, "accessible": False, "status": 0}

    async def _collect_domain_info(self, domain: str) -> dict:
        info = {"domain": domain}
        # Fetch homepage
        content = await fetch_and_clean(f"https://{domain}")
        if content:
            info["homepage_title"] = content.get("title", "")
            info["homepage_text_preview"] = content.get("text", "")[:500]
        # Fetch robots.txt
        try:
            async with httpx.AsyncClient(timeout=5.0) as client:
                resp = await client.get(f"https://{domain}/robots.txt")
                if resp.status_code == 200:
                    info["robots_txt"] = resp.text[:500]
        except Exception:
            pass
        return info

    def _format_collected(self, platform_results, search_results, pages) -> str:
        lines = ["=== Platform Presence ==="]
        for p in platform_results:
            status = "✓ Found" if p["accessible"] else "✗ Not found"
            lines.append(f"{p['platform']}: {status} ({p['url']})")

        lines.append("\n=== Search Results ===")
        for r in search_results[:6]:
            lines.append(f"- {r.title}\n  {r.url}\n  {r.snippet}")

        if pages:
            lines.append("\n=== Page Content Previews ===")
            for page in pages[:2]:
                lines.append(f"URL: {page['url']}\nTitle: {page['title']}\n{page['text'][:400]}")

        return "\n".join(lines)

    async def _analyze(self, entity: str, entity_type: str, data: str) -> dict:
        prompt = OSINT_ANALYSIS_PROMPT.format(
            entity=entity, entity_type=entity_type, data=data
        )
        try:
            raw = await llm_client.complete(prompt, temperature=0.0)
            match = re.search(r"\{.*\}", raw, re.DOTALL)
            if match:
                return json.loads(match.group())
        except Exception as e:
            logger.warning(f"OSINT analysis failed: {e}")
        return {
            "visibility_summary": "Analysis unavailable",
            "platforms_detected": [],
            "exposure_indicators": {"level": "unknown", "indicators": []},
            "key_observations": [],
            "public_source_refs": [],
        }

    async def run_person(self, name: str, hints: str = "", request_id=None) -> dict:
        import uuid
        request_id = request_id or str(uuid.uuid4())
        start = datetime.utcnow()
        logger.info(f"[{request_id}] OSINT person: {name}")

        hint_str = f" {hints}" if hints else ""
        queries = [
            # --- Identity & Basic Presence ---
            f'"{name}"',
            f'"{name}"{hint_str}',
            f'"{name}" who is',
            f'"{name}" biography OR bio OR about',

            # --- Social Media (expanded platform list) ---
            f'"{name}"{hint_str} site:linkedin.com OR site:twitter.com OR site:x.com OR site:github.com',
            f'"{name}"{hint_str} site:facebook.com OR site:instagram.com OR site:threads.net OR site:tiktok.com',
            f'"{name}"{hint_str} site:youtube.com OR site:twitch.tv OR site:rumble.com',
            f'"{name}"{hint_str} site:medium.com OR site:substack.com OR site:hashnode.com OR site:dev.to OR site:ghost.io',
            f'"{name}"{hint_str} site:reddit.com OR site:quora.com OR site:news.ycombinator.com',
            f'"{name}"{hint_str} site:pinterest.com OR site:tumblr.com OR site:flickr.com',
            f'"{name}"{hint_str} site:mastodon.social OR site:bsky.app OR site:keybase.io',

            # --- Professional & Academic ---
            f'"{name}"{hint_str} site:researchgate.net OR site:academia.edu OR site:scholar.google.com',
            f'"{name}"{hint_str} site:orcid.org OR site:pubmed.ncbi.nlm.nih.gov OR site:arxiv.org',
            f'"{name}"{hint_str} site:crunchbase.com OR site:angel.co OR site:wellfound.com',
            f'"{name}"{hint_str} site:stackoverflow.com OR site:gitlab.com OR site:bitbucket.org',
            f'"{name}"{hint_str} resume OR CV OR curriculum vitae',
            f'"{name}"{hint_str} published OR research paper OR journal OR conference',
            f'"{name}"{hint_str} speaker OR keynote OR presentation OR TEDx',

            # --- News & Media Coverage ---
            f'"{name}"{hint_str} site:news.google.com OR site:reuters.com OR site:apnews.com',
            f'"{name}"{hint_str} site:bbc.com OR site:theguardian.com OR site:nytimes.com',
            f'"{name}"{hint_str} news OR interview OR featured OR mentioned',
            f'"{name}"{hint_str} press release OR announcement',
            f'"{name}"{hint_str} award OR recognition OR achievement',

            # --- Business & Professional Activity ---
            f'"{name}"{hint_str} CEO OR founder OR director OR manager OR consultant',
            f'"{name}"{hint_str} company OR startup OR organization OR NGO',
            f'"{name}"{hint_str} site:zoominfo.com OR site:clearbit.com OR site:rocketreach.co',
            f'"{name}"{hint_str} board member OR trustee OR advisor',

            # --- Personal Web Presence ---
            f'"{name}"{hint_str} portfolio OR personal website OR homepage',
            f'"{name}"{hint_str} blog OR newsletter OR podcast',
            f'"{name}"{hint_str} photography OR art OR music OR creative',

            # --- Public Records & Directories ---
            f'"{name}"{hint_str} site:wikipedia.org',
            f'"{name}"{hint_str} site:wikidata.org OR site:dbpedia.org',
            f'"{name}"{hint_str} directory OR listing OR profile page',

            # --- Location & Background (public info only) ---
            f'"{name}"{hint_str} location OR city OR country OR based in',
            f'"{name}"{hint_str} university OR college OR alumni OR graduated',
            f'"{name}"{hint_str} school OR education OR degree',

            # --- Events & Community ---
            f'"{name}"{hint_str} site:eventbrite.com OR site:meetup.com OR site:luma.events',
            f'"{name}"{hint_str} volunteer OR community OR nonprofit OR charity',
            f'"{name}"{hint_str} hackathon OR competition OR winner',

            # --- India-specific (since you're in Rajasthan) ---
            f'"{name}"{hint_str} site:naukri.com OR site:shine.com OR site:apna.co',
            f'"{name}"{hint_str} site:timesofindia.com OR site:hindustantimes.com OR site:ndtv.com',
        ]

        all_results = []
        # Run first 6 queries immediately (core identity + social)
        for q in queries[:6]:
            results = await search_web(q, num_results=5)
            all_results.extend(results)
            await asyncio.sleep(0.3)  # small delay to avoid rate limits
        
        # Deduplicate early so we know what we already have
        seen = set()
        unique_so_far = []
        for r in all_results:
            if r.url not in seen:
                seen.add(r.url)
                unique_so_far.append(r)
        
        # Only run deeper queries if we have fewer than 15 results so far
        if len(unique_so_far) < 15:
            for q in queries[6:20]:
                results = await search_web(q, num_results=4)
                all_results.extend(results)
                await asyncio.sleep(0.3)
        
        # Final dedup
        seen = set()
        unique = []
        for r in all_results:
            if r.url not in seen:
                seen.add(r.url)
                unique.append(r)
        
                seen = set()
                unique = []
                for r in all_results:
                    if r.url not in seen:
                        seen.add(r.url)
                        unique.append(r)

        platform_hits = self._detect_platforms(unique)

        fetch_tasks = [fetch_and_clean(r.url) for r in unique[:6]]
        fetched = await asyncio.gather(*fetch_tasks, return_exceptions=True)

        pages = []
        for result, content in zip(unique[:6], fetched):
            if isinstance(content, dict) and content:
                pages.append(content)

        collected_data = self._format_person_data(name, unique, pages, platform_hits)
        analysis = await self._analyze(name, "person", collected_data)
        duration_ms = int((datetime.utcnow() - start).total_seconds() * 1000)

        return {
            "request_id": request_id,
            "agent": "osint",
            "entity": name,
            "entity_type": "person",
            "search_results": [r.to_dict() for r in unique[:10]],
            "platforms_found": platform_hits,
            **analysis,
            "duration_ms": duration_ms,
        }

    def _detect_platforms(self, results) -> dict:
        platform_map = {
            # Social
            "Facebook": "facebook.com",
            "Instagram": "instagram.com",
            "Twitter/X": "twitter.com",
            "TikTok": "tiktok.com",
            "Snapchat": "snapchat.com",
            "Threads": "threads.net",
    
            # Forums
            "Reddit": "reddit.com",
            "Quora": "quora.com",
            "StackExchange": "stackexchange.com",
    
            # Blogs
            "Medium": "medium.com",
            "Tumblr": "tumblr.com",
            "WordPress": "wordpress.com",
            "Blogspot": "blogspot.com",
            "About.me": "about.me",
            "Medium": "medium.com",
            "Wikipedia": "wikipedia.org",
            "HackerNews": "news.ycombinator.com",
            "Quora": "quora.com",
            "ResearchGate": "researchgate.net",
            "Google Scholar": "scholar.google.com",
    
            # Media
            "YouTube": "youtube.com",
            "Pinterest": "pinterest.com",
            "Flickr": "flickr.com",
            "SoundCloud": "soundcloud.com",
    
            # Marketplaces
            "Etsy": "etsy.com",
            "eBay": "ebay.com",
            "Depop": "depop.com",
    
            # Identity hubs
            "Linktree": "linktr.ee",
            "Carrd": "carrd.co",
        }
        found = {}
        for result in results:
            url_lower = result.url.lower()
            for platform, domain in platform_map.items():
                if domain in url_lower and platform not in found:
                    found[platform] = result.url
        return found

    def _format_person_data(self, name, results, pages, platform_hits) -> str:
        lines = [f"=== Searching for: {name} ===\n"]
        if platform_hits:
            lines.append("=== Platforms Found ===")
            for platform, url in platform_hits.items():
                lines.append(f"✓ {platform}: {url}")
        lines.append("\n=== Search Results ===")
        for r in results[:8]:
            lines.append(f"- {r.title}\n  URL: {r.url}\n  {r.snippet}\n")
        if pages:
            lines.append("\n=== Page Content ===")
            for page in pages[:3]:
                lines.append(f"Source: {page.get('title','')} ({page.get('url','')})")
                lines.append(page.get("text", "")[:600])
                lines.append("---")
        return "\n".join(lines)


osint_agent = OSINTAgent()