"""Verification Agent: claim decomposition + authoritative source checking."""

import asyncio
import json
import re
import uuid
from datetime import datetime
from typing import Optional

from app.core.llm import llm_client
from app.core.logging import logger
from app.core.rag import ingest_document, retrieve, format_context
from app.utils.search import search_web
from app.utils.text import fetch_and_clean


DECOMPOSE_CLAIM_PROMPT = """Break down this claim into 2-4 verifiable sub-claims that can be independently checked.
Return ONLY a JSON array of strings.
Claim: {claim}"""

VERIFY_PROMPT = """You are a fact-checker. Assess this claim against the provided evidence.

Claim: {claim}

Evidence from sources:
{context}

Respond in JSON:
{{
  "status": "verified|refuted|partially_verified|unverifiable|contested",
  "confidence": 0.0-1.0,
  "verdict_summary": "one paragraph explanation",
  "supporting_evidence": ["evidence1 with [CHUNK-N]", "evidence2"],
  "contradicting_evidence": ["contradiction1 with [CHUNK-N]"],
  "uncertainty_notes": ["note1"],
  "authoritative_sources": ["url1", "url2"]
}}"""


class VerificationAgent:
    async def run(self, claim: str, request_id: Optional[str] = None) -> dict:
        request_id = request_id or str(uuid.uuid4())
        start = datetime.utcnow()
        logger.info(f"[{request_id}] Verify: {claim[:80]}")

        # Step 1: Decompose claim
        sub_claims = await self._decompose_claim(claim)
        logger.debug(f"[{request_id}] Sub-claims: {sub_claims}")

        # Step 2: Search authoritative sources
        all_results = []
        queries = [claim] + sub_claims[:3]
        queries.append(f'"{claim[:50]}" fact check')
        queries.append(f'"{claim[:50]}" evidence research')

        for q in queries[:5]:
            results = await search_web(q, num_results=4)
            all_results.extend(results)

        # Deduplicate
        seen = set()
        unique = []
        for r in all_results:
            if r.url not in seen:
                seen.add(r.url)
                unique.append(r)

        # Step 3: Prioritize authoritative sources
        authoritative = self._prioritize_sources(unique)

        # Step 4: Fetch and ingest
        fetch_tasks = [fetch_and_clean(r.url) for r in authoritative[:6]]
        fetched = await asyncio.gather(*fetch_tasks, return_exceptions=True)

        sources_used = []
        for result, content in zip(authoritative[:6], fetched):
            if isinstance(content, dict) and content:
                chunk_ids = await ingest_document(
                    text=content["text"],
                    url=result.url,
                    title=content.get("title") or result.title,
                )
                sources_used.append({
                    "url": result.url,
                    "title": content.get("title") or result.title,
                    "snippet": result.snippet,
                    "chunk_ids": chunk_ids,
                })

        # Step 5: Retrieve + verify
        chunks = await retrieve(claim, top_k=8)
        context = format_context(chunks) if chunks else "\n".join(
            f"{r.title}: {r.snippet}" for r in authoritative[:5]
        )

        prompt = VERIFY_PROMPT.format(claim=claim, context=context)
        raw = await llm_client.complete(prompt, temperature=0.0)
        result = self._parse_result(raw)
        duration_ms = int((datetime.utcnow() - start).total_seconds() * 1000)

        return {
            "request_id": request_id,
            "agent": "verification",
            "claim": claim,
            "sub_claims": sub_claims,
            "status": result.get("status", "unverifiable"),
            "confidence": result.get("confidence", 0.5),
            "verdict_summary": result.get("verdict_summary", ""),
            "supporting_evidence": result.get("supporting_evidence", []),
            "contradicting_evidence": result.get("contradicting_evidence", []),
            "uncertainty_notes": result.get("uncertainty_notes", []),
            "sources": sources_used,
            "duration_ms": duration_ms,
        }

    async def _decompose_claim(self, claim: str) -> list[str]:
        try:
            raw = await llm_client.complete(
                DECOMPOSE_CLAIM_PROMPT.format(claim=claim), temperature=0.0
            )
            match = re.search(r"\[.*\]", raw, re.DOTALL)
            if match:
                return json.loads(match.group())
        except Exception as e:
            logger.warning(f"Claim decomposition failed: {e}")
        return [claim]

    def _prioritize_sources(self, results) -> list:
        """Score results by domain authority heuristics."""
        authoritative_domains = {
            ".gov", ".edu", "wikipedia.org", "reuters.com", "apnews.com",
            "bbc.com", "nature.com", "science.org", "pubmed.ncbi.nlm.nih.gov",
            "scholar.google.com", "arxiv.org", "snopes.com", "factcheck.org",
        }
        scored = []
        for r in results:
            score = 0
            url_lower = r.url.lower()
            for domain in authoritative_domains:
                if domain in url_lower:
                    score += 2
                    break
            scored.append((score, r))
        scored.sort(key=lambda x: x[0], reverse=True)
        return [r for _, r in scored]

    def _parse_result(self, raw: str) -> dict:
        try:
            match = re.search(r"\{.*\}", raw, re.DOTALL)
            if match:
                return json.loads(match.group())
        except Exception:
            pass
        return {
            "status": "unverifiable",
            "confidence": 0.3,
            "verdict_summary": raw[:500],
            "supporting_evidence": [],
            "contradicting_evidence": [],
            "uncertainty_notes": ["LLM response parsing failed"],
        }


verification_agent = VerificationAgent()
