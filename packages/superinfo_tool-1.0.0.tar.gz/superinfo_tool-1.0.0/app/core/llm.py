"""LLM client for Grok API (OpenAI-compatible)."""

import asyncio
from typing import Optional
from openai import AsyncOpenAI
from app.core.config import settings
from app.core.logging import logger


class LLMClient:
    def __init__(self):
        self._client: Optional[AsyncOpenAI] = None

    def initialize(self) -> None:
        self._client = AsyncOpenAI(
            api_key=settings.grok_api_key,
            base_url=settings.grok_base_url,
        )
        logger.info(f"LLM client initialized (model={settings.grok_chat_model})")

    async def chat(
        self,
        messages: list[dict],
        temperature: float = 0.0,
        max_tokens: int = 2048,
        system: Optional[str] = None,
    ) -> str:
        if system:
            messages = [{"role": "system", "content": system}] + messages

        try:
            response = await self._client.chat.completions.create(
                model=settings.grok_chat_model,
                messages=messages,
                temperature=temperature,
                max_tokens=max_tokens,
            )
            return response.choices[0].message.content or ""
        except Exception as e:
            logger.error(f"LLM chat error: {e}")
            raise

    async def complete(self, prompt: str, temperature: float = 0.0, max_tokens: int = 2048) -> str:
        return await self.chat(
            [{"role": "user", "content": prompt}],
            temperature=temperature,
            max_tokens=max_tokens,
        )

    async def json_complete(self, prompt: str, temperature: float = 0.0) -> str:
        """Request JSON-formatted completion."""
        return await self.chat(
            [{"role": "user", "content": prompt}],
            temperature=temperature,
            max_tokens=2048,
        )


llm_client = LLMClient()
