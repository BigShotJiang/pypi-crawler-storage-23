"""RAG pipeline: document ingestion and retrieval."""

import asyncio
from typing import Optional
from app.core.config import settings
from app.core.embeddings import embedding_service
from app.core.logging import logger
from app.db.vector_store import vector_store
from app.utils.text import chunk_text


async def ingest_document(
    text: str,
    url: str,
    title: str = "",
    source_type: str = "web",
) -> list[int]:
    """Chunk, embed, and store a document. Returns list of chunk IDs."""
    chunks = chunk_text(text)
    if not chunks:
        return []

    embeddings = await embedding_service.embed(chunks)
    meta_list = [
        {
            "url": url,
            "title": title,
            "text": chunk,
            "chunk_index": i,
            "source_type": source_type,
        }
        for i, chunk in enumerate(chunks)
    ]
    chunk_ids = vector_store.add_chunks(embeddings, meta_list)
    logger.debug(f"Ingested {len(chunk_ids)} chunks from {url}")
    return chunk_ids


async def retrieve(query: str, top_k: Optional[int] = None) -> list[dict]:
    """Embed query and retrieve top-k chunks from FAISS."""
    k = top_k or settings.top_k
    query_vec = await embedding_service.embed_single(query)
    results = vector_store.search(query_vec, top_k=k)
    return results


def format_context(chunks: list[dict]) -> str:
    """Format retrieved chunks into LLM context string."""
    lines = []
    for i, chunk in enumerate(chunks):
        chunk_id = chunk.get("chunk_id", i)
        url = chunk.get("url", "unknown")
        title = chunk.get("title", "")
        text = chunk.get("text", "")
        lines.append(
            f"[CHUNK-{chunk_id}] Source: {title or url}\nURL: {url}\n{text}"
        )
    return "\n\n---\n\n".join(lines)
