"""Embedding backend: Grok API or SentenceTransformers."""

from typing import Optional
import numpy as np
from app.core.config import settings
from app.core.logging import logger


class EmbeddingService:
    def __init__(self):
        self._model = None
        self._client = None
        self.dimension: int = 384

    def initialize(self) -> None:
        backend = settings.embedding_backend
        if backend == "sentence_transformers":
            self._init_sentence_transformers()
        else:
            self._init_grok()

    def _init_sentence_transformers(self) -> None:
        try:
            from sentence_transformers import SentenceTransformer
            self._model = SentenceTransformer("all-MiniLM-L6-v2", local_files_only=True)
            self.dimension = self._model.get_sentence_embedding_dimension()
            logger.info(f"SentenceTransformer initialized (dim={self.dimension})")
        except ImportError:
            raise RuntimeError("sentence-transformers not installed")

    def _init_grok(self) -> None:
        from openai import AsyncOpenAI
        self._client = AsyncOpenAI(
            api_key=settings.grok_api_key,
            base_url=settings.grok_base_url,
        )
        self.dimension = 1536  # OpenAI text-embedding-3-small default
        logger.info("Grok embedding client initialized")

    async def embed(self, texts: list[str]) -> np.ndarray:
        if not texts:
            return np.zeros((0, self.dimension), dtype=np.float32)

        if settings.embedding_backend == "sentence_transformers":
            return self._embed_local(texts)
        else:
            return await self._embed_grok(texts)

    def _embed_local(self, texts: list[str]) -> np.ndarray:
        vecs = self._model.encode(texts, normalize_embeddings=True, show_progress_bar=False)
        return np.array(vecs, dtype=np.float32)

    async def _embed_grok(self, texts: list[str]) -> np.ndarray:
        resp = await self._client.embeddings.create(
            model=settings.grok_embedding_model,
            input=texts,
        )
        vecs = [item.embedding for item in resp.data]
        return np.array(vecs, dtype=np.float32)

    async def embed_single(self, text: str) -> np.ndarray:
        arr = await self.embed([text])
        return arr[0]


embedding_service = EmbeddingService()
