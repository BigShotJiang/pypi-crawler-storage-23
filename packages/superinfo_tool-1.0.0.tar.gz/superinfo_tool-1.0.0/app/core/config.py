"""Centralized configuration management."""

from functools import lru_cache
from typing import Literal
from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


import os
from pathlib import Path

def find_env_file():
    # 1. Check current directory first
    if Path(".env").exists():
        return ".env"
    # 2. Check user's home config folder
    home_config = Path.home() / ".superinfo" / ".env"
    if home_config.exists():
        return str(home_config)
    return ".env"  # default, may not exist

class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=find_env_file(),
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )
    # ... rest stays the same
    # LLM
    grok_api_key: str = Field(default="", alias="GROK_API_KEY")
    grok_base_url: str = Field(default="https://api.x.ai/v1", alias="GROK_BASE_URL")
    grok_chat_model: str = Field(default="grok-beta", alias="GROK_CHAT_MODEL")
    grok_embedding_model: str = Field(default="text-embedding-3-small", alias="GROK_EMBEDDING_MODEL")
    embedding_backend: Literal["grok", "sentence_transformers"] = Field(
        default="sentence_transformers", alias="EMBEDDING_BACKEND"
    )

    # Search
    search_provider: Literal["brave", "bing", "serpapi"] = Field(
        default="brave", alias="SEARCH_PROVIDER"
    )
    search_api_key: str = Field(default="", alias="SEARCH_API_KEY")
    search_max_results: int = Field(default=10, alias="SEARCH_MAX_RESULTS")

    # Database
    database_url: str = Field(
        default="postgresql+asyncpg://superinfo:superinfo@localhost:5432/superinfo",
        alias="DATABASE_URL",
    )
    redis_url: str = Field(default="redis://localhost:6379/0", alias="REDIS_URL")

    # FAISS
    faiss_index_path: str = Field(default="./data/faiss_index", alias="FAISS_INDEX_PATH")
    faiss_metadata_path: str = Field(default="./data/faiss_metadata.json", alias="FAISS_METADATA_PATH")

    # RAG
    chunk_size: int = Field(default=1000, alias="CHUNK_SIZE")
    chunk_overlap: int = Field(default=150, alias="CHUNK_OVERLAP")
    top_k: int = Field(default=5, alias="TOP_K")

    # Rate limiting
    rate_limit_requests: int = Field(default=60, alias="RATE_LIMIT_REQUESTS")
    rate_limit_window: int = Field(default=60, alias="RATE_LIMIT_WINDOW")

    # Server
    host: str = Field(default="0.0.0.0", alias="HOST")
    port: int = Field(default=8000, alias="PORT")
    log_level: str = Field(default="INFO", alias="LOG_LEVEL")


@lru_cache
def get_settings() -> Settings:
    return Settings()


settings = get_settings()
