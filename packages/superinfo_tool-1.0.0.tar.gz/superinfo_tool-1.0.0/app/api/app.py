"""FastAPI application with all agent endpoints."""

import time
import uuid
from contextlib import asynccontextmanager
from typing import Any

from fastapi import FastAPI, HTTPException, Request, Depends
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from app.agents.research import research_agent
from app.agents.osint import osint_agent
from app.agents.verification import verification_agent
from app.agents.report import report_agent
from app.api.schemas import (
    ResearchRequest, ResearchResponse,
    OSINTUsernameRequest, OSINTDomainRequest, OSINTResponse,
    VerifyRequest, VerificationResponse,
    ReportRequest, ReportResponse,
    ErrorResponse,
)
from app.core.config import settings
from app.core.embeddings import embedding_service
from app.core.llm import llm_client
from app.core.logging import logger
from app.db.cache import cache
from app.db.models import create_tables
from app.db.vector_store import vector_store


@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup
    logger.info("Starting SuperInfo API...")
    import os
    os.makedirs("logs", exist_ok=True)
    os.makedirs("data", exist_ok=True)
    await cache.connect()
    llm_client.initialize()
    embedding_service.initialize()
    vector_store.initialize(dimension=embedding_service.dimension)
    try:
        await create_tables()
        logger.info("Database tables ready")
    except Exception as e:
        logger.warning(f"DB init failed (may not be configured): {e}")
    logger.info("SuperInfo API ready")
    yield
    # Shutdown
    await cache.disconnect()
    logger.info("SuperInfo API shutdown")


app = FastAPI(
    title="SuperInfo Research API",
    description="AI-powered research, OSINT, verification, and report synthesis",
    version="1.0.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.middleware("http")
async def log_requests(request: Request, call_next):
    start = time.time()
    request_id = request.headers.get("X-Request-ID", str(uuid.uuid4()))
    response = await call_next(request)
    duration = int((time.time() - start) * 1000)
    logger.info(
        f"{request.method} {request.url.path} "
        f"status={response.status_code} duration={duration}ms req={request_id}"
    )
    response.headers["X-Request-ID"] = request_id
    response.headers["X-Duration-Ms"] = str(duration)
    return response


@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    logger.error(f"Unhandled exception: {exc}", exc_info=True)
    return JSONResponse(
        status_code=500,
        content={"error": "Internal server error", "detail": str(exc)},
    )


@app.get("/health")
async def health():
    return {"status": "ok", "version": "1.0.0"}


@app.post("/research", response_model=ResearchResponse)
async def research(req: ResearchRequest):
    """Research agent: web search + RAG + evidence-grounded answer."""
    try:
        result = await research_agent.run(
            question=req.question,
            request_id=req.request_id,
            include_arxiv=req.include_arxiv,
        )
        return result
    except Exception as e:
        logger.error(f"Research error: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/osint", response_model=OSINTResponse)
async def osint_username(req: OSINTUsernameRequest):
    """OSINT agent: public digital footprint for username."""
    try:
        result = await osint_agent.run_username(
            username=req.username, request_id=req.request_id
        )
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/osint/domain", response_model=OSINTResponse)
async def osint_domain(req: OSINTDomainRequest):
    """OSINT agent: public digital footprint for domain/organization."""
    try:
        result = await osint_agent.run_domain(
            domain=req.domain, request_id=req.request_id
        )
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/verify", response_model=VerificationResponse)
async def verify(req: VerifyRequest):
    """Verification agent: claim fact-checking against authoritative sources."""
    try:
        result = await verification_agent.run(
            claim=req.claim, request_id=req.request_id
        )
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/report", response_model=ReportResponse)
async def report(req: ReportRequest):
    """Report agent: synthesize multiple agent outputs into structured report."""
    try:
        result = await report_agent.synthesize(
            agent_outputs=req.agent_outputs,
            title=req.title,
            request_id=req.request_id,
        )
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
