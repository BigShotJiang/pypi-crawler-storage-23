"""Pydantic v2 request and response schemas."""

from typing import Optional, Any
from pydantic import BaseModel, Field
import uuid


# --- Request Models ---

class ResearchRequest(BaseModel):
    question: str = Field(..., min_length=3, max_length=2000)
    include_arxiv: bool = False
    top_k: Optional[int] = Field(default=None, ge=1, le=20)
    request_id: Optional[str] = Field(default_factory=lambda: str(uuid.uuid4()))


class OSINTUsernameRequest(BaseModel):
    username: str = Field(..., min_length=1, max_length=100)
    request_id: Optional[str] = Field(default_factory=lambda: str(uuid.uuid4()))


class OSINTDomainRequest(BaseModel):
    domain: str = Field(..., min_length=3, max_length=253)
    request_id: Optional[str] = Field(default_factory=lambda: str(uuid.uuid4()))


class VerifyRequest(BaseModel):
    claim: str = Field(..., min_length=5, max_length=2000)
    request_id: Optional[str] = Field(default_factory=lambda: str(uuid.uuid4()))


class ReportRequest(BaseModel):
    agent_outputs: list[dict] = Field(..., min_length=1)
    title: Optional[str] = None
    request_id: Optional[str] = Field(default_factory=lambda: str(uuid.uuid4()))


# --- Response Models ---

class SourceInfo(BaseModel):
    url: str
    title: Optional[str] = None
    snippet: Optional[str] = None
    source_type: Optional[str] = "web"


class ResearchResponse(BaseModel):
    request_id: str
    agent: str = "research"
    question: str
    answer: str
    confidence: float
    knowledge_gaps: list[str]
    sources: list[dict]
    chunks_retrieved: int
    search_queries: list[str]
    duration_ms: int


class OSINTResponse(BaseModel):
    request_id: str
    agent: str = "osint"
    entity: str
    entity_type: str
    platform_checks: Optional[list[dict]] = None
    domain_info: Optional[dict] = None
    search_results: list[dict]
    visibility_summary: str
    platforms_detected: list[str]
    exposure_indicators: dict
    key_observations: list[str]
    public_source_refs: list[str]
    duration_ms: int


class VerificationResponse(BaseModel):
    request_id: str
    agent: str = "verification"
    claim: str
    sub_claims: list[str]
    status: str
    confidence: float
    verdict_summary: str
    supporting_evidence: list[str]
    contradicting_evidence: list[str]
    uncertainty_notes: list[str]
    sources: list[dict]
    duration_ms: int


class ReportResponse(BaseModel):
    request_id: str
    agent: str = "report"
    title: str
    report_markdown: str
    report_json: dict
    source_count: int
    duration_ms: int


class ErrorResponse(BaseModel):
    error: str
    detail: Optional[str] = None
    request_id: Optional[str] = None
