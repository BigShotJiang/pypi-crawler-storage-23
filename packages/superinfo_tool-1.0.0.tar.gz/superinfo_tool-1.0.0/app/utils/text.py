"""Text cleaning, extraction, and chunking utilities."""

import re
from typing import Optional
import httpx
from bs4 import BeautifulSoup
from app.core.config import settings
from app.core.logging import logger


HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (compatible; SuperInfo-Research/1.0; +https://github.com/superinfo)"
    )
}

HTTP_TIMEOUT = 15.0


async def fetch_url(url: str, timeout: float = HTTP_TIMEOUT) -> Optional[str]:
    """Fetch raw HTML from a URL."""
    try:
        async with httpx.AsyncClient(
            headers=HEADERS, timeout=timeout, follow_redirects=True
        ) as client:
            resp = await client.get(url)
            resp.raise_for_status()
            return resp.text
    except Exception as e:
        logger.warning(f"fetch_url failed for {url}: {e}")
        return None


def clean_html(html: str, url: str = "") -> str:
    """Extract clean readable text from HTML using readability + BS4 fallback."""
    # Try readability first
    try:
        from readability import Document
        doc = Document(html)
        clean = doc.summary()
        soup = BeautifulSoup(clean, "lxml")
        text = soup.get_text(separator="\n", strip=True)
        if len(text) > 200:
            return _normalize_whitespace(text)
    except Exception:
        pass

    # BS4 fallback
    soup = BeautifulSoup(html, "lxml")
    for tag in soup(["script", "style", "nav", "footer", "header", "aside", "form"]):
        tag.decompose()
    text = soup.get_text(separator="\n", strip=True)
    return _normalize_whitespace(text)


def _normalize_whitespace(text: str) -> str:
    text = re.sub(r"\n{3,}", "\n\n", text)
    text = re.sub(r"[ \t]{2,}", " ", text)
    return text.strip()


def chunk_text(text: str, chunk_size: int = None, overlap: int = None) -> list[str]:
    """Split text into overlapping chunks by approximate token count (chars/4)."""
    chunk_size = chunk_size or settings.chunk_size
    overlap = overlap or settings.chunk_overlap

    # Convert tokens to chars (approximate: 1 token ≈ 4 chars)
    char_size = chunk_size * 4
    char_overlap = overlap * 4

    if len(text) <= char_size:
        return [text]

    chunks = []
    start = 0
    while start < len(text):
        end = start + char_size
        if end < len(text):
            # Try to break at a paragraph or sentence
            break_point = text.rfind("\n\n", start, end)
            if break_point == -1 or break_point < start + char_size // 2:
                break_point = text.rfind(". ", start, end)
            if break_point != -1 and break_point > start:
                end = break_point + 1
        chunk = text[start:end].strip()
        if chunk:
            chunks.append(chunk)
        start = end - char_overlap
    return chunks


async def fetch_and_clean(url: str) -> Optional[dict]:
    """Fetch URL and return cleaned text with metadata."""
    html = await fetch_url(url)
    if not html:
        return None
    text = clean_html(html, url)
    if not text or len(text) < 100:
        return None

    # Extract title
    soup = BeautifulSoup(html, "lxml")
    title = ""
    if soup.title:
        title = soup.title.get_text(strip=True)

    return {"url": url, "title": title, "text": text, "length": len(text)}
