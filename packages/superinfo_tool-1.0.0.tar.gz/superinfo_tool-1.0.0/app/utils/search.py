"""Unified search abstraction supporting Brave, Bing, and SerpAPI."""

import httpx
from typing import Optional
from app.core.config import settings
from app.core.logging import logger
from app.db.cache import cache


class SearchResult:
    def __init__(self, title: str, url: str, snippet: str, source: str = "web"):
        self.title = title
        self.url = url
        self.snippet = snippet
        self.source = source

    def to_dict(self) -> dict:
        return {
            "title": self.title,
            "url": self.url,
            "snippet": self.snippet,
            "source": self.source,
        }


async def _search_brave(query: str, num: int) -> list[SearchResult]:
    url = "https://api.search.brave.com/res/v1/web/search"
    headers = {
        "Accept": "application/json",
        "Accept-Encoding": "gzip",
        "X-Subscription-Token": settings.search_api_key,
    }
    params = {"q": query, "count": min(num, 20)}
    async with httpx.AsyncClient(timeout=10.0) as client:
        resp = await client.get(url, headers=headers, params=params)
        resp.raise_for_status()
        data = resp.json()
    results = []
    for item in data.get("web", {}).get("results", []):
        results.append(SearchResult(
            title=item.get("title", ""),
            url=item.get("url", ""),
            snippet=item.get("description", ""),
            source="brave",
        ))
    return results


async def _search_bing(query: str, num: int) -> list[SearchResult]:
    url = "https://api.bing.microsoft.com/v7.0/search"
    headers = {"Ocp-Apim-Subscription-Key": settings.search_api_key}
    params = {"q": query, "count": min(num, 50)}
    async with httpx.AsyncClient(timeout=10.0) as client:
        resp = await client.get(url, headers=headers, params=params)
        resp.raise_for_status()
        data = resp.json()
    results = []
    for item in data.get("webPages", {}).get("value", []):
        results.append(SearchResult(
            title=item.get("name", ""),
            url=item.get("url", ""),
            snippet=item.get("snippet", ""),
            source="bing",
        ))
    return results


async def _search_serpapi(query: str, num: int) -> list[SearchResult]:
    url = "https://serpapi.com/search"
    params = {
        "q": query,
        "api_key": settings.search_api_key,
        "num": min(num, 10),
        "engine": "google",
    }
    async with httpx.AsyncClient(timeout=15.0) as client:
        resp = await client.get(url, params=params)
        resp.raise_for_status()
        data = resp.json()
    results = []
    for item in data.get("organic_results", []):
        results.append(SearchResult(
            title=item.get("title", ""),
            url=item.get("link", ""),
            snippet=item.get("snippet", ""),
            source="serpapi",
        ))
    return results


async def search_web(
    query: str,
    num_results: Optional[int] = None,
    use_cache: bool = True,
) -> list[SearchResult]:
    """Run a web search with caching."""
    num = num_results or settings.search_max_results
    cache_key = f"{settings.search_provider}:{query}:{num}"

    if use_cache:
        cached = await cache.get("search", cache_key)
        if cached:
            logger.debug(f"Search cache hit: {query[:50]}")
            return [SearchResult(**r) for r in cached]

    try:
        provider = settings.search_provider
        if provider == "brave":
            results = await _search_brave(query, num)
        elif provider == "bing":
            results = await _search_bing(query, num)
        else:
            results = await _search_serpapi(query, num)

        if use_cache and results:
            await cache.set("search", cache_key, [r.to_dict() for r in results], ttl=1800)

        logger.debug(f"Search '{query[:50]}': {len(results)} results")
        return results
    except Exception as e:
        logger.error(f"Search failed ({settings.search_provider}): {e}")
        return []


async def search_arxiv(query: str, max_results: int = 5) -> list[SearchResult]:
    """Search arXiv for academic papers."""
    try:
        import arxiv
        client = arxiv.Client()
        search = arxiv.Search(query=query, max_results=max_results)
        results = []
        for paper in client.results(search):
            results.append(SearchResult(
                title=paper.title,
                url=paper.entry_id,
                snippet=paper.summary[:300] + "...",
                source="arxiv",
            ))
        return results
    except Exception as e:
        logger.warning(f"arXiv search failed: {e}")
        return []
