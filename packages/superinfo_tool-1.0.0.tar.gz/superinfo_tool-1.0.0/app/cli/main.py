"""SuperInfo CLI tool using Typer + Rich."""

import asyncio
import json
import os
import sys
from pathlib import Path
from typing import Optional

import typer
from rich import print as rprint
from rich.console import Console
from rich.markdown import Markdown
from rich.panel import Panel
from rich.table import Table
from rich.progress import Progress, SpinnerColumn, TextColumn

app = typer.Typer(
    name="superinfo",
    help="🔍 SuperInfo - AI-powered research, OSINT, verification & reports",
    no_args_is_help=True,
    pretty_exceptions_enable=True,
)

console = Console()


def _run(coro):
    """Run async coroutine in CLI context with services initialized."""
    async def _wrapper():
        import os
        os.makedirs("logs", exist_ok=True)
        os.makedirs("data", exist_ok=True)
        # Load .env
        try:
            from dotenv import load_dotenv
            load_dotenv()
        except ImportError:
            pass

        from app.core.llm import llm_client
        from app.core.embeddings import embedding_service
        from app.db.vector_store import vector_store
        from app.db.cache import cache

        await cache.connect()
        llm_client.initialize()
        embedding_service.initialize()
        vector_store.initialize(dimension=embedding_service.dimension)

        try:
            result = await coro
        finally:
            await cache.disconnect()
        return result

    return asyncio.run(_wrapper())


def _export_json(data: dict, output: Optional[str]) -> None:
    if output:
        path = Path(output)
        path.write_text(json.dumps(data, indent=2, default=str))
        console.print(f"\n[green]✓ Saved to {path}[/green]")


def _print_sources(sources: list[dict]) -> None:
    if not sources:
        return
    table = Table(title="Sources", show_header=True, header_style="bold cyan")
    table.add_column("#", style="dim", width=4)
    table.add_column("Title", max_width=40)
    table.add_column("URL", max_width=60)
    table.add_column("Type", width=10)
    for i, src in enumerate(sources[:10], 1):
        table.add_row(
            str(i),
            (src.get("title") or "")[:40],
            src.get("url", "")[:60],
            src.get("source_type", "web"),
        )
    console.print(table)


# ─────────────────────────────────────────────────
# research command
# ─────────────────────────────────────────────────
@app.command()
def research(
    question: str = typer.Argument(..., help="Research question or topic"),
    arxiv: bool = typer.Option(False, "--arxiv", help="Include arXiv academic papers"),
    top_k: int = typer.Option(5, "--top-k", help="Number of RAG chunks to retrieve"),
    output: Optional[str] = typer.Option(None, "--output", "-o", help="Save JSON to file"),
):
    """🔬 Research a topic using web search + RAG."""
    from app.agents.research import research_agent

    async def _do():
        return await research_agent.run(question=question, include_arxiv=arxiv)

    with Progress(
        SpinnerColumn(), TextColumn("[bold blue]Researching..."), transient=True
    ) as progress:
        progress.add_task("research")
        result = _run(_do())

    console.print(Panel(
        f"[bold]{question}[/bold]",
        title="🔬 Research Query",
        border_style="blue",
    ))
    console.print(Markdown(result.get("answer", "No answer generated.")))
    console.print(f"\n[yellow]Confidence:[/yellow] {result.get('confidence', 0):.0%}")

    gaps = result.get("knowledge_gaps", [])
    if gaps:
        console.print(f"\n[yellow]Knowledge Gaps:[/yellow] {', '.join(gaps)}")

    _print_sources(result.get("sources", []))
    console.print(f"\n[dim]Duration: {result.get('duration_ms')}ms | Chunks: {result.get('chunks_retrieved')}[/dim]")
    _export_json(result, output)


# ─────────────────────────────────────────────────
# osint commands
# ─────────────────────────────────────────────────
osint_app = typer.Typer(help="🕵️ OSINT: public digital footprint analysis")
app.add_typer(osint_app, name="osint")

@osint_app.command("person")
def osint_person(
    name: str = typer.Option(..., "--name", "-n", help="Full name e.g. 'Rohit Thanvi'"),
    hints: str = typer.Option("", "--hints", help="Extra context e.g. 'developer India'"),
    output: Optional[str] = typer.Option(None, "--output", "-o"),
):
    """Search public internet presence for a person by full name."""
    from app.agents.osint import osint_agent

    async def _do():
        return await osint_agent.run_person(name=name, hints=hints)

    with Progress(SpinnerColumn(), TextColumn("[bold blue]Searching..."), transient=True) as p:
        p.add_task("osint")
        result = _run(_do())

    console.print(Panel(f"[bold]{name}[/bold]", title="🕵️ OSINT - Person Search", border_style="yellow"))
    console.print(Markdown(result.get("visibility_summary", "")))

    platforms = result.get("platforms_found", {})
    if platforms:
        console.print("\n[cyan]Found on these platforms:[/cyan]")
        for platform, url in platforms.items():
            console.print(f"  ✓ [green]{platform}[/green] → {url}")

    exposure = result.get("exposure_indicators", {})
    level = exposure.get("level", "unknown")
    color = {"low": "green", "medium": "yellow", "high": "red"}.get(level, "white")
    console.print(f"\n[{color}]Exposure Level: {level.upper()}[/{color}]")

    observations = result.get("key_observations", [])
    if observations:
        console.print("\n[yellow]Key Findings:[/yellow]")
        for obs in observations:
            console.print(f"  • {obs}")

    _print_sources(result.get("search_results", []))
    # Add this after the key_observations display block
    prof = result.get("professional_info", {})
    if prof.get("current_role") or prof.get("organization"):
        console.print("\n[cyan]Professional:[/cyan]")
        if prof.get("current_role"):
            console.print(f"  Role: {prof['current_role']}")
        if prof.get("organization"):
            console.print(f"  Organization: {prof['organization']}")
        if prof.get("education"):
            console.print(f"  Education: {prof['education']}")
        if prof.get("skills"):
            console.print(f"  Skills: {', '.join(prof['skills'][:5])}")

    activity = result.get("online_activity", {})
    if activity.get("content_topics"):
        console.print(f"\n[cyan]Topics they post about:[/cyan] {', '.join(activity['content_topics'])}")
    if activity.get("most_active_platforms"):
        console.print(f"[cyan]Most active on:[/cyan] {', '.join(activity['most_active_platforms'])}")
    console.print(f"\n[dim]Duration: {result.get('duration_ms')}ms[/dim]")
    _export_json(result, output)

@osint_app.command("self")
def osint_username(
    username: str = typer.Option(..., "--username", "-u", help="Username to investigate"),
    output: Optional[str] = typer.Option(None, "--output", "-o", help="Save JSON to file"),
):
    """Analyze public footprint for a username."""
    from app.agents.osint import osint_agent

    async def _do():
        return await osint_agent.run_username(username=username)

    with Progress(SpinnerColumn(), TextColumn("[bold blue]Investigating..."), transient=True) as p:
        p.add_task("osint")
        result = _run(_do())

    console.print(Panel(
        f"[bold]@{username}[/bold]",
        title="🕵️ OSINT - Username",
        border_style="yellow",
    ))

    summary = result.get("visibility_summary", "")
    if summary:
        console.print(Markdown(summary))

    platforms = result.get("platforms_detected", [])
    if platforms:
        console.print(f"\n[cyan]Platforms:[/cyan] {', '.join(platforms)}")

    exposure = result.get("exposure_indicators", {})
    level = exposure.get("level", "unknown")
    color = {"low": "green", "medium": "yellow", "high": "red"}.get(level, "white")
    console.print(f"[{color}]Exposure Level: {level.upper()}[/{color}]")

    for obs in result.get("key_observations", []):
        console.print(f"  • {obs}")

    _export_json(result, output)


@osint_app.command("org")
def osint_domain(
    domain: str = typer.Option(..., "--domain", "-d", help="Domain/organization to investigate"),
    output: Optional[str] = typer.Option(None, "--output", "-o", help="Save JSON to file"),
):
    """Analyze public footprint for a domain/organization."""
    from app.agents.osint import osint_agent

    async def _do():
        return await osint_agent.run_domain(domain=domain)

    with Progress(SpinnerColumn(), TextColumn("[bold blue]Investigating..."), transient=True) as p:
        p.add_task("osint")
        result = _run(_do())

    console.print(Panel(f"[bold]{domain}[/bold]", title="🕵️ OSINT - Domain", border_style="yellow"))
    console.print(Markdown(result.get("visibility_summary", "")))
    _print_sources(result.get("search_results", []))
    _export_json(result, output)
# ─────────────────────────────────────────────────
# verify command
# ─────────────────────────────────────────────────
@app.command()
def verify(
    claim: str = typer.Argument(..., help="Claim or statement to verify"),
    output: Optional[str] = typer.Option(None, "--output", "-o"),
):
    """✅ Verify a claim against authoritative sources."""
    from app.agents.verification import verification_agent

    async def _do():
        return await verification_agent.run(claim=claim)

    with Progress(SpinnerColumn(), TextColumn("[bold blue]Verifying..."), transient=True) as p:
        p.add_task("verify")
        result = _run(_do())

    status = result.get("status", "unknown")
    color_map = {
        "verified": "green", "refuted": "red",
        "partially_verified": "yellow", "unverifiable": "dim", "contested": "magenta",
    }
    color = color_map.get(status, "white")
    status_icons = {
        "verified": "✅", "refuted": "❌", "partially_verified": "🟡",
        "unverifiable": "❓", "contested": "⚠️",
    }
    icon = status_icons.get(status, "❓")

    console.print(Panel(
        f"[bold]\"{claim}\"[/bold]\n\n"
        f"[{color}]{icon} Status: {status.upper()}[/{color}]  |  "
        f"Confidence: {result.get('confidence', 0):.0%}",
        title="✅ Claim Verification",
        border_style=color,
    ))

    console.print(Markdown(result.get("verdict_summary", "")))

    if result.get("supporting_evidence"):
        console.print("\n[green]Supporting Evidence:[/green]")
        for e in result["supporting_evidence"]:
            console.print(f"  + {e}")

    if result.get("contradicting_evidence"):
        console.print("\n[red]Contradicting Evidence:[/red]")
        for e in result["contradicting_evidence"]:
            console.print(f"  - {e}")

    if result.get("uncertainty_notes"):
        console.print("\n[yellow]Uncertainty Notes:[/yellow]")
        for n in result["uncertainty_notes"]:
            console.print(f"  ? {n}")

    _print_sources(result.get("sources", []))
    _export_json(result, output)


# ─────────────────────────────────────────────────
# report command
# ─────────────────────────────────────────────────
@app.command()
def report(
    inputs: Optional[list[str]] = typer.Option(None, "--input", "-i", help="JSON files from other agents"),
    title: Optional[str] = typer.Option(None, "--title", "-t"),
    output: Optional[str] = typer.Option(None, "--output", "-o"),
    last: bool = typer.Option(False, "--last", help="Use last saved outputs"),
):
    """📄 Synthesize agent outputs into a structured report."""
    from app.agents.report import report_agent

    agent_outputs = []
    if inputs:
        for path in inputs:
            try:
                data = json.loads(Path(path).read_text())
                agent_outputs.append(data)
            except Exception as e:
                console.print(f"[red]Error loading {path}: {e}[/red]")

    if not agent_outputs and last:
        # Try to load last saved output
        for f in sorted(Path(".").glob("superinfo_*.json"), reverse=True)[:3]:
            try:
                agent_outputs.append(json.loads(f.read_text()))
            except Exception:
                pass

    if not agent_outputs:
        console.print("[red]No input data. Use --input to specify JSON files.[/red]")
        raise typer.Exit(1)

    async def _do():
        return await report_agent.synthesize(agent_outputs=agent_outputs, title=title)

    with Progress(SpinnerColumn(), TextColumn("[bold blue]Generating report..."), transient=True) as p:
        p.add_task("report")
        result = _run(_do())

    console.print(Panel(
        result.get("title", "Research Report"),
        title="📄 Research Report",
        border_style="green",
    ))
    console.print(Markdown(result.get("report_markdown", "")))
    _export_json(result, output)


# ─────────────────────────────────────────────────
# serve command
# ─────────────────────────────────────────────────
@app.command()
def serve(
    host: str = typer.Option("0.0.0.0", "--host", "-h"),
    port: int = typer.Option(8000, "--port", "-p"),
    reload: bool = typer.Option(False, "--reload"),
    workers: int = typer.Option(1, "--workers"),
):
    """🚀 Start the FastAPI server."""
    import uvicorn
    console.print(Panel(
        f"[bold green]Starting SuperInfo API[/bold green]\n"
        f"[cyan]http://{host}:{port}[/cyan]\n"
        f"[dim]Docs: http://{host}:{port}/docs[/dim]",
        border_style="green",
    ))
    uvicorn.run(
        "app.api.app:app",
        host=host,
        port=port,
        reload=reload,
        workers=workers,
        log_level="info",
    )

@app.command()
def setup():
    """⚙️  First-time setup: configure your API keys."""
    from pathlib import Path

    console.print(Panel(
        "[bold green]SuperInfo Setup[/bold green]\n"
        "This will save your API keys to [cyan]~/.superinfo/.env[/cyan]",
        border_style="green"
    ))

    config_dir = Path.home() / ".superinfo"
    config_dir.mkdir(exist_ok=True)
    env_path = config_dir / ".env"

    # Load existing values if already set up
    existing = {}
    if env_path.exists():
        for line in env_path.read_text().splitlines():
            if "=" in line and not line.startswith("#"):
                k, v = line.split("=", 1)
                existing[k.strip()] = v.strip()

    console.print("\n[yellow]Press Enter to keep existing value shown in brackets[/yellow]\n")

    def ask(label, key, default="", secret=False):
        current = existing.get(key, default)
        display = f"[{current[:6]}...]" if (secret and current) else f"[{current}]" if current else ""
        value = typer.prompt(f"{label} {display}", default=current, hide_input=secret)
        return value or current

    groq_key = ask("Groq API key", "GROK_API_KEY", secret=True)
    groq_model = ask("Groq model", "GROK_CHAT_MODEL", default="llama-3.3-70b-versatile")

    console.print("\n[cyan]Search provider options: serpapi (free tier) / brave / bing[/cyan]")
    search_provider = ask("Search provider", "SEARCH_PROVIDER", default="serpapi")
    search_key = ask("Search API key", "SEARCH_API_KEY", secret=True)

    embedding = ask("Embedding backend (sentence_transformers recommended)", "EMBEDDING_BACKEND", default="sentence_transformers")

    # Write config
    config_content = f"""# SuperInfo Configuration
# Generated by: superinfo setup

GROK_API_KEY={groq_key}
GROK_BASE_URL=https://api.groq.com/openai/v1
GROK_CHAT_MODEL={groq_model}
EMBEDDING_BACKEND={embedding}

SEARCH_PROVIDER={search_provider}
SEARCH_API_KEY={search_key}

FAISS_INDEX_PATH={config_dir}/faiss_index
FAISS_METADATA_PATH={config_dir}/faiss_metadata.json

CHUNK_SIZE=1000
CHUNK_OVERLAP=150
TOP_K=5
"""
    env_path.write_text(config_content)
    console.print(f"\n[green]✓ Config saved to {env_path}[/green]")
    console.print("[green]✓ You're all set! Try: superinfo research \"What is AI?\"[/green]")
if __name__ == "__main__":
    app()
