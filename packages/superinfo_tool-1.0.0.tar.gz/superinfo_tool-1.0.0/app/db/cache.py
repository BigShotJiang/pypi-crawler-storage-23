"""Redis cache layer for search results and deduplication."""

import json
import hashlib
from typing import Any, Optional
import redis.asyncio as redis
from app.core.config import settings
from app.core.logging import logger


class RedisCache:
    def __init__(self):
        self._client: Optional[redis.Redis] = None

    async def connect(self) -> None:
        try:
            self._client = redis.from_url(settings.redis_url, decode_responses=True)
            await self._client.ping()
            logger.info("Redis connected")
        except Exception as e:
            logger.warning(f"Redis unavailable: {e}. Caching disabled.")
            self._client = None

    async def disconnect(self) -> None:
        if self._client:
            await self._client.aclose()

    def _key(self, namespace: str, value: str) -> str:
        digest = hashlib.sha256(value.encode()).hexdigest()[:16]
        return f"superinfo:{namespace}:{digest}"

    async def get(self, namespace: str, key: str) -> Optional[Any]:
        if not self._client:
            return None
        try:
            raw = await self._client.get(self._key(namespace, key))
            return json.loads(raw) if raw else None
        except Exception as e:
            logger.debug(f"Redis get error: {e}")
            return None

    async def set(self, namespace: str, key: str, value: Any, ttl: int = 3600) -> None:
        if not self._client:
            return
        try:
            await self._client.setex(self._key(namespace, key), ttl, json.dumps(value))
        except Exception as e:
            logger.debug(f"Redis set error: {e}")

    async def exists(self, namespace: str, key: str) -> bool:
        if not self._client:
            return False
        try:
            return bool(await self._client.exists(self._key(namespace, key)))
        except Exception:
            return False

    async def sadd_dedup(self, namespace: str, url: str) -> bool:
        """Add URL to dedup set. Returns True if new, False if already seen."""
        if not self._client:
            return True
        try:
            result = await self._client.sadd(f"superinfo:dedup:{namespace}", url)
            return bool(result)
        except Exception:
            return True

    async def clear_dedup(self, namespace: str) -> None:
        if not self._client:
            return
        try:
            await self._client.delete(f"superinfo:dedup:{namespace}")
        except Exception:
            pass


cache = RedisCache()
