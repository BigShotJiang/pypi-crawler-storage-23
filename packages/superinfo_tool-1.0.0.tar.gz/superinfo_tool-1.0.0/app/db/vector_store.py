"""FAISS-based local vector store with persistent index."""

import json
import os
import numpy as np
from pathlib import Path
from typing import Optional
import faiss
from app.core.config import settings
from app.core.logging import logger


class VectorStore:
    def __init__(self):
        self.index: Optional[faiss.Index] = None
        self.metadata: list[dict] = []  # chunk_id -> {source_url, title, text, chunk_index}
        self.dimension: int = 384  # default for sentence-transformers/all-MiniLM-L6-v2
        self._index_path = Path(settings.faiss_index_path)
        self._meta_path = Path(settings.faiss_metadata_path)

    def _ensure_dirs(self):
        self._index_path.parent.mkdir(parents=True, exist_ok=True)
        self._meta_path.parent.mkdir(parents=True, exist_ok=True)

    def initialize(self, dimension: int = 384) -> None:
        self.dimension = dimension
        self._ensure_dirs()
        if self._index_path.exists() and self._meta_path.exists():
            try:
                self.index = faiss.read_index(str(self._index_path))
                with open(self._meta_path) as f:
                    self.metadata = json.load(f)
                logger.info(f"FAISS index loaded: {self.index.ntotal} vectors")
                return
            except Exception as e:
                logger.warning(f"Failed to load FAISS index: {e}. Creating fresh.")
        self.index = faiss.IndexFlatL2(dimension)
        self.metadata = []
        logger.info(f"FAISS index initialized (dim={dimension})")

    def save(self) -> None:
        if self.index is None:
            return
        self._ensure_dirs()
        faiss.write_index(self.index, str(self._index_path))
        with open(self._meta_path, "w") as f:
            json.dump(self.metadata, f)
        logger.debug(f"FAISS index saved: {self.index.ntotal} vectors")

    def add_chunks(self, embeddings: np.ndarray, chunks_meta: list[dict]) -> list[int]:
        if self.index is None:
            raise RuntimeError("VectorStore not initialized")
        start_id = len(self.metadata)
        self.index.add(embeddings.astype(np.float32))
        chunk_ids = []
        for i, meta in enumerate(chunks_meta):
            chunk_id = start_id + i
            self.metadata.append({**meta, "chunk_id": chunk_id})
            chunk_ids.append(chunk_id)
        self.save()
        return chunk_ids

    def search(self, query_embedding: np.ndarray, top_k: int = 5) -> list[dict]:
        if self.index is None or self.index.ntotal == 0:
            return []
        k = min(top_k, self.index.ntotal)
        distances, indices = self.index.search(
            query_embedding.reshape(1, -1).astype(np.float32), k
        )
        results = []
        for dist, idx in zip(distances[0], indices[0]):
            if idx < 0 or idx >= len(self.metadata):
                continue
            results.append({
                **self.metadata[idx],
                "score": float(dist),
            })
        return results

    def reset(self) -> None:
        self.index = faiss.IndexFlatL2(self.dimension)
        self.metadata = []
        self.save()


vector_store = VectorStore()
