# Viper - a code complexity metrics reporter

## Input
all kinds of source code files

## Output
For each file, list of functiton information.
For a function, analyze to get following data:
- scope (namespace, class or function as ancester nodes of this function)
- fqdn (fully qualified domain name: scope + name)
- name (the identifier)
- signature (normalized function signature, keep unchanged when compiled function name is not changed)
- line (line number of identifier)
- start (start line number of function definition)
- end (end line number of function definition)
- ccm (mccabe-style cyclomatic complexity metric, Traditional: each `case` statement counts +1)
- modified_ccm (mccabe-style cyclomatic complexity metric, Modified: `switch` statement counts +1)
- statements (number of statements in the function body)

## Supported Languages
- C (`.c`, `.h`)
- C++ (`.cpp`, `.cxx`, `.cc`, `.hpp`, `.hxx`, `.hh`)
- Python (`.py`, `.pyw`)
- SystemVerilog (`.sv`, `.svh`)

## Output Formats
Viper supports multiple output formats out of the box. Use the `--format` option:
- `default`: Human-readable list of functions (default)
- `pmccabe`: pmccabe-compatible tab-separated format (Modified CCM, Traditional CCM, Statements, First line, # Lines, filename(line): function_name)

## Implementation Idea
- use python 3.14.2
- utilize tree_sitter module and tree_sitter_xxx language packs to parse source code to get AST, then analyze AST to get function information
- support inputs of multiple files, enumeration of files in directories.

## project and module management
- use tool `uv` as package/project management tool
- use `uv run <script>` to run scripts
- put code under `src` file
