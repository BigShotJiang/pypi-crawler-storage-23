"""Backward-compatible re-exports from the new ``viper.languages`` package.

All parsing logic has been moved to ``viper.languages``.  This module
re-exports the most commonly used names so that existing ``from viper.core
import ...`` statements continue to work.
"""

from viper.languages import (
    Function,
    guess_language,
    get_parser,
    parse,
    CTreeSitterParser as CParser,
    CppTreeSitterParser as CppParser,
    PythonTreeSitterParser as PythonParser,
)

__all__ = [
    "Function",
    "guess_language",
    "get_parser",
    "parse",
    "CParser",
    "CppParser",
    "PythonParser",
]