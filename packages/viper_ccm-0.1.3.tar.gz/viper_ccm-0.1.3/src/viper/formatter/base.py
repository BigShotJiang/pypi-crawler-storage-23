"""Base abstraction for output formatters."""

from __future__ import annotations

from abc import ABC, abstractmethod

from viper.languages.base import Function


class Formatter(ABC):
    """Abstract base class that every output formatter must implement."""

    format_name: str = ""

    @abstractmethod
    def format_function(self, func: Function, filepath: str) -> str:
        """Format a single function entry as a string line."""

    def format_file(
        self, filepath: str, lang: str, functions: list[Function]
    ) -> str:
        """Format all functions from a single file.

        Default implementation joins ``format_function`` results with newlines.
        Subclasses may override to add file headers/footers.
        """
        lines = [self.format_function(f, filepath) for f in functions]
        return "\n".join(lines)
