"""pmccabe-compatible output formatter.

Produces the same 6-column tab-separated format as the ``pmccabe`` tool::

    Modified_CCM  Traditional_CCM  #Statements  FirstLine  #Lines  file(line): name
"""

from __future__ import annotations

from viper.languages.base import Function
from viper.formatter.base import Formatter


class PmccabeFormatter(Formatter):
    """Output format compatible with the ``pmccabe`` tool."""

    format_name = "pmccabe"

    def format_function(self, func: Function, filepath: str) -> str:
        num_lines = func.end - func.start + 1
        return (
            f"{func.modified_ccm}\t"
            f"{func.ccm}\t"
            f"{func.statements}\t"
            f"{func.start}\t"
            f"{num_lines}\t"
            f"{filepath}({func.line}): {func.fqdn}"
        )
