"""Default formatter — reproduces the original viper CLI output."""

from __future__ import annotations

from viper.languages.base import Function
from viper.formatter.base import Formatter


class DefaultFormatter(Formatter):
    """Human-readable output format (original viper style)."""

    format_name = "default"

    def __init__(self, *, fqdn: bool = False) -> None:
        self.fqdn = fqdn

    def format_function(self, func: Function, filepath: str) -> str:
        display_name = func.fqdn if self.fqdn else func.name
        sig = f"{func.signature}" if self.fqdn and func.signature else ""
        return f"- {display_name}{sig}@{func.start}-{func.end} file: {filepath}:{func.line}"

    def format_file(
        self, filepath: str, lang: str, functions: list[Function]
    ) -> str:
        header = f"\n{filepath} ({lang})\n" + "=" * 80 + "\n"
        if not functions:
            return header + "No functions found."
        header += f"{len(functions)} functions:\n"
        body = "\n".join(self.format_function(f, filepath) for f in functions)
        return header + body
