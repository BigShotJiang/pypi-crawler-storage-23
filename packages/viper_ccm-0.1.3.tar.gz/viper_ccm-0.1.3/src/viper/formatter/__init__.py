"""viper.formatter — Output formatting for code analysis results.

Public API
----------
- ``get_formatter(name)`` — obtain a ``Formatter`` instance
- ``register_formatter()`` — register a custom formatter class

Built-in Formatters
-------------------
- ``default`` — human-readable output (original viper style)
- ``pmccabe`` — pmccabe-compatible tab-separated output
"""

from __future__ import annotations

from viper.formatter.base import Formatter

# ---------------------------------------------------------------------------
# Registry
# ---------------------------------------------------------------------------

_registry: dict[str, type[Formatter]] = {}


def register_formatter(formatter_cls: type[Formatter]) -> None:
    """Register a formatter class by its ``format_name``."""
    _registry[formatter_cls.format_name] = formatter_cls


def get_formatter(name: str, **kwargs) -> Formatter:
    """Return a formatter instance for the given *name*.

    Raises ``ValueError`` if no formatter is registered for *name*.
    """
    formatter_cls = _registry.get(name)
    if formatter_cls is None:
        available = ", ".join(sorted(_registry.keys()))
        raise ValueError(f"Unknown format: {name!r}. Available: {available}")
    return formatter_cls(**kwargs)


# ---------------------------------------------------------------------------
# Auto-register built-in formatters
# ---------------------------------------------------------------------------

from viper.formatter.default import DefaultFormatter  # noqa: E402
from viper.formatter.pmccabe import PmccabeFormatter  # noqa: E402

register_formatter(DefaultFormatter)
register_formatter(PmccabeFormatter)

__all__ = [
    "Formatter",
    "get_formatter",
    "register_formatter",
    "DefaultFormatter",
    "PmccabeFormatter",
]
