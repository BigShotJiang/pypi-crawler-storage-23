<div align="center">

# ⚡ yolotrt

**YOLO → TensorRT Auto-Export & Smart Model Loader**

*Export once, load the fastest format every time.*

![Python](https://img.shields.io/badge/Python-3.7%2B-blue?logo=python&logoColor=white)
![TensorRT](https://img.shields.io/badge/TensorRT-FP16-76B900?logo=nvidia)
![License](https://img.shields.io/badge/License-MIT-yellow)

</div>

---

## ✨ Why yolotrt?

| Feature | yolotrt | Manual Export | torch2trt |
|---|:---:|:---:|:---:|
| One-line auto export | ✅ | ❌ | ❌ |
| Smart format priority (TRT > ONNX > PT) | ✅ | ❌ | ❌ |
| Works with Ultralytics YOLO | ✅ | ✅ | ❌ |
| FP16 by default | ✅ | Manual | ✅ |
| Track + Predict API pass-through | ✅ | ❌ | ❌ |
| Zero config needed | ✅ | ❌ | ❌ |

---

## 📦 Installation

```bash
pip install yolotrt
```

> **Note:** Requires `ultralytics` and TensorRT runtime for GPU acceleration.
> `pip install ultralytics` — the TensorRT backend is optional.

---

## 🚀 Quick Start

```python
from yolotrt import ModelLoader

# First run: auto-exports .pt → .engine (5-10 min)
# Subsequent runs: loads .engine instantly
model = ModelLoader("models/best.pt", auto_trt=True, half=True)

# Inference (same API as ultralytics)
results = model.predict(frame, conf=0.5, verbose=False)
boxes = results[0].boxes.xyxy.cpu().numpy()

# Tracking
results = model.track(frame, persist=True, tracker="botsort.yaml")
```

### Manual Export

```python
from yolotrt import TRTExporter

exporter = TRTExporter("models/best.pt", half=True, imgsz=640)
if not exporter.is_exported():
    engine_path = exporter.export()
    print(f"Saved: {engine_path}")
```

---

## 🔧 API Reference

### `ModelLoader(model_path, auto_trt=True, half=True, device=0, imgsz=640)`

Smart loader that picks the fastest available format:

| Priority | Format | Extension | Speed |
|---|---|---|---|
| 1 | TensorRT | `.engine` | ⚡ Fastest |
| 2 | ONNX | `.onnx` | 🔄 Cross-platform |
| 3 | PyTorch | `.pt` | 🐢 Fallback |

### `TRTExporter(model_path, half=True, device=0, imgsz=640)`

| Method | Returns | Description |
|---|---|---|
| `export()` | str | Run export, return engine path |
| `is_exported()` | bool | Check if .engine already exists |

---

## 📜 License

MIT License — use it anywhere.

<div align="center">
<i>Built with ❤️ by <a href="https://github.com/ByIbos">ByIbos</a></i>
</div>
