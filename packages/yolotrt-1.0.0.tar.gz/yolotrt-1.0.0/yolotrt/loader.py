"""
Smart Model Loader — Auto-detects and loads the fastest YOLO format
====================================================================
Checks for TensorRT .engine first, ONNX second, and falls back
to PyTorch .pt. Optionally triggers TensorRT export on first run.

Author: ByIbos
License: MIT
"""

import os


class ModelLoader:
    """
    Smart YOLO model loader with automatic format selection.

    Loads the fastest available format in order:
        1. TensorRT .engine (fastest)
        2. ONNX .onnx (cross-platform)
        3. PyTorch .pt (fallback)

    If `auto_trt=True` and no .engine exists, automatically exports one.

    Args:
        model_path: Path to the base YOLO .pt model.
        auto_trt: Automatically export to TensorRT if not found (default: True).
        half: Use FP16 for TensorRT export (default: True).
        device: GPU device index (default: 0).
        imgsz: Image size for TensorRT engine (default: 640).

    Example:
        >>> model = ModelLoader("models/best.pt", auto_trt=True)
        >>> results = model.predict(frame, conf=0.5)
        >>> boxes = results[0].boxes.xyxy.cpu().numpy()
    """

    def __init__(self, model_path, auto_trt=True, half=True, device=0, imgsz=640):
        self.base_path = model_path
        self.auto_trt = auto_trt
        self.half = half
        self.device = device
        self.imgsz = imgsz
        self.model = None
        self.loaded_format = None

        self._load()

    def _load(self):
        """Load the best available model format."""
        try:
            from ultralytics import YOLO
        except ImportError:
            raise ImportError(
                "ultralytics package is required. "
                "Install with: pip install ultralytics"
            )

        engine_path = self.base_path.replace(".pt", ".engine")
        onnx_path = self.base_path.replace(".pt", ".onnx")

        # Priority 1: TensorRT
        if os.path.exists(engine_path):
            print(f"[yolotrt] Loading TensorRT engine: {engine_path}")
            self.model = YOLO(engine_path, task="detect")
            self.loaded_format = "tensorrt"
            return

        # Auto-export TensorRT if requested
        if self.auto_trt and os.path.exists(self.base_path):
            try:
                from yolotrt.exporter import TRTExporter
                exporter = TRTExporter(
                    self.base_path, half=self.half,
                    device=self.device, imgsz=self.imgsz
                )
                result_path = exporter.export()
                self.model = YOLO(result_path, task="detect")
                self.loaded_format = "tensorrt"
                return
            except Exception as e:
                print(f"[yolotrt] TensorRT export failed: {e}")
                print("[yolotrt] Falling back to other formats...")

        # Priority 2: ONNX
        if os.path.exists(onnx_path):
            print(f"[yolotrt] Loading ONNX model: {onnx_path}")
            self.model = YOLO(onnx_path, task="detect")
            self.loaded_format = "onnx"
            return

        # Priority 3: PyTorch
        if os.path.exists(self.base_path):
            print(f"[yolotrt] Loading PyTorch model: {self.base_path}")
            self.model = YOLO(self.base_path)
            self.loaded_format = "pytorch"
            return

        raise FileNotFoundError(
            f"No model found. Checked:\n"
            f"  TensorRT: {engine_path}\n"
            f"  ONNX:     {onnx_path}\n"
            f"  PyTorch:  {self.base_path}"
        )

    def predict(self, frame, **kwargs):
        """
        Run inference on a frame.

        Args:
            frame: BGR numpy array.
            **kwargs: Additional arguments passed to model.predict()
                (e.g., conf=0.5, verbose=False).

        Returns:
            Ultralytics Results object.
        """
        return self.model.predict(frame, **kwargs)

    def track(self, frame, **kwargs):
        """
        Run tracking on a frame.

        Args:
            frame: BGR numpy array.
            **kwargs: Additional arguments passed to model.track()
                (e.g., persist=True, tracker="botsort.yaml").

        Returns:
            Ultralytics Results object with tracking IDs.
        """
        return self.model.track(frame, **kwargs)

    def __repr__(self):
        return f"ModelLoader(format={self.loaded_format}, path={self.base_path})"
