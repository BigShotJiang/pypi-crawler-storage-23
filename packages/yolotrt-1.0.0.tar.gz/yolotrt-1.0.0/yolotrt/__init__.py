"""
yolotrt — YOLO to TensorRT Auto-Export & Smart Model Loader
=============================================================
Automatically converts YOLO .pt models to TensorRT .engine
files and loads the fastest available format.

Quick Start:
    from yolotrt import ModelLoader
    model = ModelLoader("models/best.pt", auto_trt=True)
    results = model.predict(frame)
"""

from yolotrt.loader import ModelLoader
from yolotrt.exporter import TRTExporter

__version__ = "1.0.0"
__author__ = "ByIbos"
__all__ = ["ModelLoader", "TRTExporter"]
