"""
TensorRT Exporter — YOLO .pt → .engine Conversion
====================================================
Wraps the Ultralytics export API with progress reporting,
error handling, and automatic format detection.

Author: ByIbos
License: MIT
"""

import os
import time


class TRTExporter:
    """
    Export a YOLO model to TensorRT engine format.

    Handles the full conversion pipeline: validates the source model,
    runs the export, and verifies the output file exists.

    Args:
        model_path: Path to the YOLO .pt model file.
        half: Use FP16 precision for faster inference (default: True).
        device: GPU device index (default: 0).
        imgsz: Input image size for the engine (default: 640).

    Example:
        >>> exporter = TRTExporter("models/best.pt", half=True)
        >>> engine_path = exporter.export()
        >>> print(f"Engine saved to: {engine_path}")
    """

    def __init__(self, model_path, half=True, device=0, imgsz=640):
        self.model_path = model_path
        self.half = half
        self.device = device
        self.imgsz = imgsz

    def export(self, output_path=None):
        """
        Run the TensorRT export.

        Args:
            output_path: Optional custom output path. If None, replaces
                .pt extension with .engine in the same directory.

        Returns:
            str: Path to the exported .engine file.

        Raises:
            FileNotFoundError: If the source model doesn't exist.
            RuntimeError: If the export fails.
        """
        if not os.path.exists(self.model_path):
            raise FileNotFoundError(f"Model not found: {self.model_path}")

        try:
            from ultralytics import YOLO
        except ImportError:
            raise ImportError(
                "ultralytics package is required for export. "
                "Install with: pip install ultralytics"
            )

        print(f"[yolotrt] Exporting {self.model_path} to TensorRT...")
        print(f"[yolotrt] FP16: {self.half} | Device: {self.device} | ImgSize: {self.imgsz}")
        print(f"[yolotrt] This may take 5-10 minutes on first run...")

        start = time.time()
        model = YOLO(self.model_path)
        model.export(
            format="engine",
            half=self.half,
            device=self.device,
            imgsz=self.imgsz,
        )
        elapsed = time.time() - start

        # Determine output path
        if output_path is None:
            output_path = self.model_path.replace(".pt", ".engine")

        if os.path.exists(output_path):
            size_mb = os.path.getsize(output_path) / (1024 * 1024)
            print(f"[yolotrt] Export complete! ({elapsed:.1f}s, {size_mb:.1f} MB)")
            print(f"[yolotrt] Saved to: {output_path}")
            return output_path
        else:
            raise RuntimeError(
                f"Export appeared to succeed but output file not found: {output_path}"
            )

    def is_exported(self):
        """Check if a TensorRT engine already exists for this model."""
        engine_path = self.model_path.replace(".pt", ".engine")
        return os.path.exists(engine_path)
