# Plan: `/init` REPL command

## Goal

Add an `/init` slash command to the REPL that injects a canned prompt asking the model to generate a `AGENT.md` file describing the project's conventions.

## Prompt text

```
Create or update the markdown file called AGENT.md describing the conventions (style, doc, tools) used by this project. Only list unusual choices that you didn't know about, are hard to guess and are unlikely to change in the future. Be concise and not redundant.
```

## Behavior

`/init` works like typing the prompt above as a normal REPL question:

1. Append a `{"role": "user", "content": INIT_PROMPT}` message.
2. Call `run_agent_loop()` with the current state (same as a regular question).
3. Print the answer, log to history, warn on exhaustion — identical to a normal turn.

This lets the model use its tools (`list_files`, `read_file`, `grep`, `write_file`) to inspect the project and produce `AGENT.md`.

## Changes

### `swival/agent.py`

1. **Add a module-level constant** near the top (alongside the other prompt constants):

   ```python
   INIT_PROMPT = (
       "Create or update the markdown file called AGENT.md describing the conventions "
       "(style, doc, tools) used by this project. Only list unusual choices that you "
       "didn't know about, are hard to guess and are unlikely to change in the future. "
       "Be concise and not redundant."
   )
   ```

2. **Add an `elif` branch** in `repl_loop`'s command dispatch (after `/continue`, before the fall-through that appends the raw line):

   ```python
   elif cmd == "/init":
       if cmd_arg:
           fmt.warning(f"/init takes no arguments, ignoring {cmd_arg!r}")
       line = INIT_PROMPT  # replace line, fall through to normal question handling
   ```

   No `continue` — we let execution fall through to the existing block that appends `line` as a user message and calls `run_agent_loop()`. This avoids duplicating the answer/history/exhaustion handling. Arguments are warned about and ignored — the prompt is intentionally fixed.

3. **Update `_repl_help()`** to list the new command:

   ```
   /init        generate AGENT.md for the current project
   ```

### `tests/test_repl.py`

Add two tests:

- **`test_init_command`** — Mock `run_agent_loop` to return a canned answer. Feed `/init` then `/exit` into the REPL. Assert that the user message appended to `messages` equals `INIT_PROMPT` and that `run_agent_loop` was called.
- **`test_help_lists_init`** — Call `_repl_help()` (or capture its output) and assert the output contains `/init`.

## What this does NOT do

- No new CLI flag (it's REPL-only).
- No special-casing in the agent loop — the model decides which tools to call.
- No change to `AGENT.md` loading logic (that already exists in `_run_main`). AGENT.md is a separate file from AGENT.md.
