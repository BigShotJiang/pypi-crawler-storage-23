# stucamcrack

STU CamCrack792 图像裂缝数据集（541MB）
