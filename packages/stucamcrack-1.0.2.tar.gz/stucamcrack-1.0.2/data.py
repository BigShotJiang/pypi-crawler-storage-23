import pooch
from pathlib import Path
import shutil

# __version__ = "1.0.0"

# ================== 请在这里修改 ==================
GITHUB_USER = "2020iciicii"                    # ← 改这里
DOWNLOAD_URL = f"https://github.com/{GITHUB_USER}/stucamcrack/releases/download/v1.0.0/STU_CamCrack792.zip"
SHA256_HASH = "0d363dbc9f3a3f0da856c177d64eba4d65b332eeb5ce140e0cda332f36d40e88"   # ← 改这里（不要加 sha256: 前缀）
# ================================================

_cache_dir = pooch.os_cache("stucamcrack")

def get_data_dir() -> Path:
    """
    返回数据集解压后的根文件夹路径。
    第一次调用会自动下载 541MB 并解压，之后秒开（缓存到 ~/.cache/stucamcrack）。
    """
    print("🔄 正在检查/下载数据集（541MB，仅首次需要）...")

    # 自动下载 + hash 校验
    zip_path = pooch.retrieve(
        url=DOWNLOAD_URL,
        known_hash=f"sha256:{SHA256_HASH}",
        path=_cache_dir,
        fname="STU_CamCrack792.zip",
        progressbar=True,          # 显示下载进度条
    )

    # 解压目录
    extract_dir = _cache_dir / "STU_CamCrack792_extracted"

    if not extract_dir.exists():
        print("📦 正在解压数据集（只需一次）...")
        shutil.unpack_archive(str(zip_path), extract_dir)
        print("✅ 解压完成！")

    print(f"🎉 数据集就绪！路径：{extract_dir}")
    return extract_dir.resolve()