﻿import pytest
from fastapi import FastAPI
from httpx import AsyncClient, ASGITransport
from unittest.mock import patch, MagicMock, AsyncMock
import json
import asyncio

# Prevent alru_cache from being safety-checked during tests
# This must happen before any service imports
from async_lru import alru_cache
patch("async_lru._LRUCacheWrapper._check_loop", lambda self, loop: None).start()

# Now import the components
from src.router.api import router as api_router
from src.api.common.service import check_api_key

# Create a test app
app = FastAPI()
app.include_router(api_router)

@pytest.fixture(autouse=True)
def mock_global_services():
    # Patch MySQLClient.init to avoid real DB connection attempts during tests
    with patch("src.core.db.MySQLClient.init", return_value=None):
        # Patch check_api_key in all modules where it's imported and used
        targets = [
            "src.api.common.service.check_api_key",
            "src.api.open_ai_chat.endpoint.check_api_key",
            "src.api.open_ai_chat.service.check_api_key",
            "src.api.image.endpoint.check_api_key",
            "src.api.image.service.check_api_key",
            "src.api.stt.endpoint.check_api_key",
            "src.api.stt.service.check_api_key",
            "src.api.tts.endpoint.check_api_key",
            "src.api.tts.service.check_api_key",
        ]
        
        mocks = []
        for target in targets:
            try:
                m = patch(target, new_callable=AsyncMock)
                mock_func = m.start()
                mock_func.return_value = {"id": 1, "app_id": "test_app", "name": "Test Account"}
                mocks.append(m)
            except (ImportError, AttributeError):
                continue
        
        yield
        
        for m in mocks:
            m.stop()

@pytest.fixture
def mock_db():
    with patch("src.core.db.MySQLClient.query", new_callable=AsyncMock) as mock_query, \
         patch("src.core.db.MySQLClient.query_one", new_callable=AsyncMock) as mock_query_one, \
         patch("src.core.db.MySQLClient.execute", new_callable=AsyncMock) as mock_execute:
        
        # Default behavior to avoid AsyncMock failures
        mock_query_one.return_value = {}
        mock_query.return_value = []
        
        yield {
            "query": mock_query,
            "query_one": mock_query_one,
            "execute": mock_execute
        }

@pytest.mark.asyncio
async def test_chat_models_endpoint(mock_db, mock_global_services):
    # Mock WithOpenAi list (used by get_model_list)
    mock_db["query"].return_value = [
        {"id": 1, "name": "gpt-3.5-turbo", "title": "GPT 3.5", "created_at": None, "driver": "openai", "params": "{}"}
    ]

    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as ac:
        response = await ac.get(
            "/xzy/api/v1/chat/models",
            headers={"Authorization": "Bearer test_token"}
        )
    
    assert response.status_code == 200
    data = response.json()
    assert data["object"] == "list"
    assert len(data["data"]) > 0
    assert data["data"][0]["id"] == "gpt-3.5-turbo"

@pytest.mark.asyncio
async def test_image_models_endpoint(mock_db, mock_global_services):
    # Mock models for image endpoint
    mock_db["query"].return_value = [
        {"id": 1, "name": "dall-e-3", "title": "DALL-E 3", "driver": "openai", "params": "{}"}
    ]

    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as ac:
        response = await ac.get(
            "/xzy/api/v1/img/models",
            headers={"Authorization": "Bearer test_token"}
        )
    
    assert response.status_code == 200
    data = response.json()
    assert isinstance(data, list) 

@pytest.mark.asyncio
async def test_stt_models_endpoint(mock_db, mock_global_services):
    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as ac:
        response = await ac.get(
            "/xzy/ws/stt/models",
            headers={"Authorization": "Bearer test_token"}
        )
    
    assert response.status_code == 200
    data = response.json()
    assert data["object"] == "list"

@pytest.mark.asyncio
async def test_tts_models_endpoint(mock_db, mock_global_services):
    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as ac:
        response = await ac.get(
            "/xzy/ws/tts/models",
            headers={"Authorization": "Bearer test_token"}
        )
    
    assert response.status_code == 200
    data = response.json()
    assert data["object"] == "list"


