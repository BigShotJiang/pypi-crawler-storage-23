﻿import pytest
from unittest.mock import patch, AsyncMock, MagicMock
from src.workflows.graph.lifecycle.builder import build_chat_lifecycle_graph

# Simple mock subgraph functions
async def mock_chat_subgraph(state, config=None):
    return {"response": {"choices": [{"message": {"content": "Hello from mock chat"}}]}}

async def mock_image_subgraph(state, config=None):
    return {"response": {"status": "success", "image_uids": ["test-uid"]}}

@pytest.fixture
def mock_lifecycle_env():
    # Patch targets are now super simple thanks to the graph facade
    targets = [
        "src.workflows.graph.chat",
        "src.workflows.graph.image",
        "src.workflows.graph.knowledge_agent.nodes.RAGRetriever",
        "src.workflows.graph.knowledge_agent.nodes._validate_knowledge_access",
    ]
    
    with patch("src.core.db.MySQLClient.init", return_value=None), \
         patch(targets[0], return_value=mock_chat_subgraph), \
         patch(targets[1], return_value=mock_image_subgraph), \
         patch(targets[3], return_value=True) as mock_validate, \
         patch(targets[2]) as mock_retriever_class:
        
        # Mock Retriever instance
        mock_retriever_instance = MagicMock()
        mock_doc = MagicMock()
        mock_doc.id = "doc1"
        mock_doc.title = "Test Doc"
        mock_chunk = MagicMock()
        mock_chunk.content = "This is a retrieved chunk."
        mock_chunk.similarity = 0.95
        mock_doc.chunks = [mock_chunk]
        
        mock_retriever_instance.query_relevant_documents.return_value = [mock_doc]
        mock_retriever_class.return_value = mock_retriever_instance
        
        yield {
            "validate": mock_validate,
            "retriever": mock_retriever_instance
        }

@pytest.mark.asyncio
async def test_lifecycle_chat_flow(mock_lifecycle_env):
    graph = build_chat_lifecycle_graph()
    
    initial_state = {
        "query": "浣犲ソ",
        "use_knowledge": False,
        "history": [],
        "inputs": {}
    }
    
    final_state = await graph.ainvoke(initial_state)
    assert final_state["intent"] == "chat"
    assert "choices" in final_state["response"]

@pytest.mark.asyncio
async def test_lifecycle_knowledge_flow(mock_lifecycle_env):
    graph = build_chat_lifecycle_graph()
    
    # knowledge_agent expects state["knowledge"]
    initial_state = {
        "query": "浠€涔堟槸 src锛?,
        "use_knowledge": True,
        "knowledge": {
            "question": "浠€涔堟槸 src锛?,
            "knowledge_base": [{"datasetId": "ds1", "files": [{"fileId": "f1"}]}]
        },
        "history": [],
        "inputs": {}
    }
    
    # Improved config mock
    def mock_config_get(key, default=None):
        if key == "rag.retriever":
            return {"url": "http://dummy", "api_key": "test"}
        if key == "rag.validate_url":
            return "http://dummy-validate"
        return default

    with patch("src.config.config.config.get", side_effect=mock_config_get):
        final_state = await graph.ainvoke(initial_state)
    
    assert final_state["intent"] == "chat"
    assert "knowledge_retrieval_result" in final_state
    result = final_state["knowledge_retrieval_result"]
    assert "content" in result, f"Result keys: {result.keys()}"
    assert "This is a retrieved chunk" in result["content"]
    assert len(result["documents"]) > 0
    assert "choices" in final_state["response"]

@pytest.mark.asyncio
async def test_lifecycle_image_flow(mock_lifecycle_env):
    graph = build_chat_lifecycle_graph()
    
    initial_state = {
        "query": "鐢熸垚涓€寮犵尗鐨勫浘鐗?,
        "use_knowledge": False,
        "history": [],
        "inputs": {}
    }
    
    final_state = await graph.ainvoke(initial_state)
    
    assert final_state["intent"] == "image"
    assert final_state["response"]["status"] == "success"


