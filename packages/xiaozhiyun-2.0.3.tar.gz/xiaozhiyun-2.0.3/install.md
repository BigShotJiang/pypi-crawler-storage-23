﻿# src (灏忔櫤浜? 瀹夎涓庝娇鐢ㄦ寚鍗?

src 鎻愪緵鐨勬牳蹇冭兘鍔涳紙Multi-Cloud Agentic AI锛夊凡鎵撳寘涓虹嫭绔嬬殑 Python 鍖呫€傛偍鍙互鍦ㄥ叾浠栭」鐩腑鐙珛瀹夎骞朵娇鐢ㄥ畠锛屾棤闇€渚濊禆 DeerFlow 鐨勫叾浠栭儴鍒嗐€?

## 1. 瀹夎鏂规硶

### 鏂瑰紡 A: 浠庢簮鐮佸畨瑁?(鎺ㄨ崘寮€鍙戣皟璇?

濡傛灉鎮ㄥ凡缁忓厠闅嗕簡 `deer-flow` 浠撳簱锛屽彲浠ョ洿鎺ヨ繘琛屾湰鍦板彲缂栬緫瀹夎锛?

```bash
# 鍋囪鎮ㄥ湪 deer-flow 鏍圭洰褰曚笅
cd src/xiaozhiyun
pip install -e .

uv pip install -e d:\www\AI\aippt\src
```

### 鏂瑰紡 B: 鐩存帴閫氳繃 pip 瀹夎 (鍗虫彃鍗崇敤)

鎮ㄥ彲浠ュ湪浠绘剰 Python 椤圭洰涓紝鐩存帴閫氳繃 git URL 瀹夎姝ゅ寘锛?

```bash
uv pip install "git+http://gitlab.tooking.cn/chatgpt/aippt.git#subdirectory=src"

uv add "git+http://gitlab.tooking.cn/chatgpt/aippt.git#subdirectory=src"
```

### 鏂瑰紡 C: 娣诲姞鍒?`requirements.txt` 鎴?`pyproject.toml`

**requirements.txt:**

```text
src @ git+http://gitlab.tooking.cn/chatgpt/aippt.git#subdirectory=src
```

**pyproject.toml (濡傛灉鏄?uv/pdm/poetry):**

```toml
[project.dependencies]
src = { git = "http://gitlab.tooking.cn/chatgpt/aippt.git", subdirectory = "src" }
```

---

## 2. 蹇€熶娇鐢?

瀹夎瀹屾垚鍚庯紝鎮ㄥ彲浠ョ洿鎺ュ湪浠ｇ爜涓€氳繃 `src` 妯″潡璋冪敤鎵€鏈変簯鍘傚晢鐨勮兘鍔涖€?

### 绀轰緥 1: 绠€鍗曠殑瀵硅瘽 (Chat)

```python
import asyncio
import src

async def main():
    # 鐩存帴璋冪敤闃块噷浜戠殑 Qwen
    response = await src.chat('aliyun', {
        'model': 'qwen-turbo',
        'messages': [{"role": "user", "content": "浣犲ソ锛岃浠嬬粛涓€涓嬩綘鑷繁"}]
    })
    print(response)

if __name__ == "__main__":
    asyncio.run(main())
```

### 绀轰緥 2: 璇煶鍚堟垚 (TTS)

```python
import src

async def speak():
    # 浣跨敤鐧惧害鐨?TTS
    result = await src.tts('baidu', {
        'text': '浠婂ぉ澶╂皵鐪熶笉閿欙紝閫傚悎鍑哄幓娓哥帺銆?,
        'voice_id': 'duxiao'
    })
    
    # 淇濆瓨闊抽鏂囦欢
    with open('output.mp3', 'wb') as f:
        f.write(result['audio_data'])

# 杩愯鐣?..
```

### 绀轰緥 3: 鍦?LangGraph 涓娇鐢?

src 鍘熺敓鎻愪緵浜?LangGraph 鐨?Node 灏佽锛岄潪甯搁€傚悎鏋勫缓鏅鸿兘浣撳伐浣滄祦銆?

```python
from langgraph.graph import StateGraph, START, END
from src import nodes

# 1. 瀹氫箟鍥剧姸鎬?
class State(dict):
    messages: list

builder = StateGraph(State)

# 2. 娣诲姞鍘熷瓙鑺傜偣
# 娣诲姞涓€涓樋閲屼簯鐨?Chat 鑺傜偣
builder.add_node("chat_node", nodes.chat('aliyun', {'model': 'qwen-plus'}))

# 3. 鏋勫缓杈?
builder.add_edge(START, "chat_node")
builder.add_edge("chat_node", END)

# 4. 缂栬瘧骞惰繍琛?
graph = builder.compile()
result = await graph.ainvoke({"messages": [{"role": "user", "content": "Hello!"}]})
```

---

## 3. 鐜鍙橀噺閰嶇疆

涓轰簡浣垮悇涓簯鍘傚晢鐨勯┍鍔ㄦ甯稿伐浣滐紝鎮ㄩ渶瑕佸湪椤圭洰鐨?`.env` 鏂囦欢鎴栫幆澧冨彉閲忎腑閰嶇疆鐩稿簲鐨?Key銆?

```bash
# 闃块噷浜?
ALIYUN_ACCESS_KEY_ID="your_access_key"
ALIYUN_ACCESS_KEY_SECRET="your_secret_key"
ALIYUN_APP_KEY="your_app_key"  # 鐢ㄤ簬 TTS/ASR

# 鐧惧害鏅鸿兘浜?
BAIDU_API_KEY="your_api_key"
BAIDU_SECRET_KEY="your_secret_key"

# 鑵捐浜?
TENCENT_SECRET_ID="your_secret_id"
TENCENT_SECRET_KEY="your_secret_key"

# 鐏北寮曟搸 (Volcengine)
VOLC_ACCESS_KEY="your_ak"
VOLC_SECRET_KEY="your_sk"
```

璇︾粏鐨?API 鏂囨。璇锋煡闃?[README.md](./README.md)銆?


