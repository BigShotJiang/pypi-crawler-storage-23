﻿# 馃惓 灏忔櫤浜?(src) Docker 瀹夎涓庝娇鐢ㄦ寚鍗?

鏈枃妗ｄ粙缁嶅浣曚娇鐢?Docker 瀹夎鍜岄儴缃?`src` AI 閫傞厤灞傚寘銆?

---

## 1. 鍩虹鐜瀹夎

鍦ㄥ紑濮嬩箣鍓嶏紝璇风‘淇濇偍鐨勭郴缁熷凡瀹夎 Docker銆?

* **Windows**: 鎺ㄨ崘瀹夎 [Docker Desktop](https://www.docker.com/products/docker-desktop/)锛屽苟鍚敤 WSL 2 鍚庣銆?
* **Linux**: 鍙傝€冨畼鏂规枃妗ｅ畨瑁?`docker-ce` 鍜?`docker-compose-plugin`銆?

---

## 2. 鍦?Docker 涓畨瑁?src 鍖?

鏍规嵁鎮ㄧ殑浣跨敤鍦烘櫙锛屾湁浠ヤ笅涓ょ涓昏鏂瑰紡鍦ㄥ鍣ㄤ腑浣跨敤姝ゅ寘锛?

### 鏂规 A锛氭湰鍦版簮鐮佸畨瑁?(鎺ㄨ崘鐢ㄤ簬寮€鍙戣皟璇?

濡傛灉鎮ㄦ鍦ㄥ紑鍙戜腑锛屽彲浠ラ€氳繃 `COPY` 鎸囦护灏嗘湰鍦扮殑 `src` 婧愮爜澶嶅埗鍒伴暅鍍忎腑骞跺畨瑁呫€?

**绀轰緥 Dockerfile:**

```dockerfile
# 1. 閫夋嫨鍩虹闀滃儚
FROM python:3.10-slim

# 2. 璁剧疆宸ヤ綔鐩綍
WORKDIR /app

# 3. 灏?src 婧愮爜鐩綍澶嶅埗鍒板鍣ㄥ唴
# 鍋囪 Dockerfile 浣嶄簬 src 鐩綍鐨勭埗绾э紝鎴栬€呭湪 src 鐩綍涓嬭繍琛?
COPY ./xiaozhiyun /app/xiaozhiyun

# 4. 瀹夎鍖呭強鍏朵緷璧?
RUN pip install --no-cache-dir /app/xiaozhiyun

# 5. 澶嶅埗鎮ㄧ殑搴旂敤浠ｇ爜 (鍙€?
# COPY ./your_app /app/your_app

# 6. 璁剧疆鐜鍙橀噺
ENV PYTHONUNBUFFERED=1

# 7. 鍚姩鍛戒护
# CMD ["python", "your_app/main.py"]
```

### 鏂规 B锛氶€氳繃 Git 鐩存帴瀹夎 (鎺ㄨ崘鐢ㄤ簬鐢熶骇/閮ㄧ讲)

鎮ㄤ篃鍙互鐩存帴浠?Git 浠撳簱瀹夎璇ュ寘锛岃繖鏍蜂笉闇€瑕佸湪鏈湴淇濈暀婧愮爜銆?

**绀轰緥 Dockerfile:**

```dockerfile
FROM python:3.10-slim

# 瀹夎 git (鍩虹闀滃儚閫氬父涓嶅甫 git)
RUN apt-get update && apt-get install -y git && rm -rf /var/lib/apt/lists/*

WORKDIR /app

# 浣跨敤 pip 鐩存帴浠庝粨搴撳畨瑁?
RUN pip install --no-cache-dir "git+http://gitlab.tooking.cn/chatgpt/aippt.git#subdirectory=src"

# 澶嶅埗鎮ㄧ殑搴旂敤浠ｇ爜
# ...
```

---

## 3. 杩愯瀹瑰櫒涓庣幆澧冨彉閲?

`src` 娑夊強澶氫釜浜戝巶鍟嗙殑 API 璋冪敤锛屽繀椤绘纭厤缃幆澧冨彉閲忋€?

### 鍒涘缓 `.env` 鏂囦欢

鍦ㄩ」鐩牴鐩綍涓嬪垱寤?`.env` 鏂囦欢锛?

```bash
# 闃块噷浜戦厤缃?
ALIYUN_ACCESS_KEY_ID="xxx"
ALIYUN_ACCESS_KEY_SECRET="xxx"
ALIYUN_APP_KEY="xxx"

# 鐧惧害浜戦厤缃?
BAIDU_API_KEY="xxx"
BAIDU_SECRET_KEY="xxx"

# 鑵捐浜戦厤缃?
TENCENT_SECRET_ID="xxx"
TENCENT_SECRET_KEY="xxx"

# 鐏北寮曟搸 (瀛楄妭)
VOLC_ACCESS_KEY="xxx"
VOLC_SECRET_KEY="xxx"
```

### 鍚姩瀹瑰櫒

浣跨敤 `--env-file` 鍙傛暟鍔犺浇閰嶇疆锛?

```bash
# 鏋勫缓闀滃儚
docker build -t my-ai-app .

# 杩愯瀹瑰櫒骞跺姞杞界幆澧冨彉閲?
docker run -it --rm --env-file .env my-ai-app
```

---

## 4. 浣跨敤 Docker Compose 缂栨帓

濡傛灉鎮ㄧ殑搴旂敤鍖呭惈澶氫釜鏈嶅姟锛屾帹鑽愪娇鐢?Docker Compose銆?

**docker-compose.yml 绀轰緥:**

```yaml
version: '3.8'

services:
  ai-service:
    build: 
      context: .
      dockerfile: Dockerfile
    volumes:
      - .:/app
    env_file:
      - .env
    restart: always
```

杩愯锛?

```bash
docker compose up -d
```

---

## 馃洜锔?鍥藉唴闀滃儚鍔犻€?

濡傛灉鍦ㄦ瀯寤洪暅鍍忔椂鎷夊幓 Python 渚濊禆杩囨參锛屽彲浠ユ寚瀹氬浗鍐呮簮锛?

```dockerfile
RUN pip install --no-cache-dir -i https://pypi.tuna.tsinghua.edu.cn/simple /app/xiaozhiyun
```


