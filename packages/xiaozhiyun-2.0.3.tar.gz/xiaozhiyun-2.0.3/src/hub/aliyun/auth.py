﻿import hmac
import hashlib
import base64
import time
import uuid
import logging
from typing import Dict
from urllib.parse import quote, urlencode
from src.hub.common import HttpClientManager

logger = logging.getLogger(__name__)


class AliyunAuth:
    """
    Manages Aliyun NLS Token acquisition.
    
    Docs: https://help.aliyun.com/zh/isi/getting-started/use-http-or-https-to-obtain-an-access-token
    """
    _token_cache: Dict[str, tuple] = {}  # Dict of access_key_id -> (token, expire_time)

    @staticmethod
    def _percent_encode(value: str) -> str:
        """
        URL encode with Aliyun's specific rules:
        - Replace + with %20
        - Replace * with %2A
        - Replace %7E with ~
        """
        if value is None:
            return ""
        encoded = quote(str(value), safe="")
        return encoded.replace("+", "%20").replace("*", "%2A").replace("%7E", "~")

    @staticmethod
    def _encode_dict(params: Dict[str, str]) -> str:
        """Encode and sort parameters."""
        sorted_params = sorted(params.items())
        encoded_pairs = []
        for key, value in sorted_params:
            encoded_key = AliyunAuth._percent_encode(key)
            encoded_value = AliyunAuth._percent_encode(value)
            encoded_pairs.append(f"{encoded_key}={encoded_value}")
        return "&".join(encoded_pairs)

    @classmethod
    async def get_nls_token(cls, access_key_id: str, access_key_secret: str) -> str:
        """
        Get NLS Token using OpenAPI with HMAC-SHA1 signature.
        
        Args:
            access_key_id: Aliyun AccessKey ID
            access_key_secret: Aliyun AccessKey Secret
            
        Returns:
            Token string, or empty string on failure
        """
        if not access_key_id or not access_key_secret:
            logger.error("Missing AccessKeyId or AccessKeySecret for NLS token")
            return ""
        
        # Check cache (simple, no expiry check for now)
        cache_key = access_key_id
        if cache_key in cls._token_cache:
            token, expire_time = cls._token_cache[cache_key]
            # Check if token is still valid (with 5 minute buffer)
            if expire_time and expire_time > time.time() + 300:
                return token

        try:
            # Build request parameters
            parameters = {
                "AccessKeyId": access_key_id,
                "Action": "CreateToken",
                "Format": "JSON",
                "RegionId": "cn-shanghai",
                "SignatureMethod": "HMAC-SHA1",  # Must be HMAC-SHA1
                "SignatureNonce": str(uuid.uuid1()),
                "SignatureVersion": "1.0",
                "Timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
                "Version": "2019-02-28",
            }

            # Build canonical query string
            query_string = cls._encode_dict(parameters)
            
            # Build string to sign: GET&%2F&<encoded_query_string>
            string_to_sign = "GET" + "&" + cls._percent_encode("/") + "&" + cls._percent_encode(query_string)
            
            # Calculate HMAC-SHA1 signature
            secret_key = access_key_secret + "&"
            signature = hmac.new(
                secret_key.encode("utf-8"),
                string_to_sign.encode("utf-8"),
                hashlib.sha1
            ).digest()
            signature_b64 = base64.b64encode(signature).decode("utf-8")
            
            # URL encode the signature
            encoded_signature = cls._percent_encode(signature_b64)
            
            # Build full URL
            url = f"http://nls-meta.cn-shanghai.aliyuncs.com/?Signature={encoded_signature}&{query_string}"
            
            logger.debug(f"NLS Token URL: {url}")
            
            # Make request
            client = HttpClientManager.get_client()
            resp = await client.get(url, timeout=10.0)
            
            if resp.status_code == 200:
                data = resp.json()
                if "Token" in data:
                    token = data["Token"]["Id"]
                    expire_time = data["Token"].get("ExpireTime", 0)
                    cls._token_cache[cache_key] = (token, expire_time)
                    logger.info(f"Aliyun NLS token acquired for AK {access_key_id[:8]}...")
                    return token
                else:
                    logger.error(f"NLS Token response missing Token: {data}")
            else:
                logger.error(f"NLS Token request failed: {resp.status_code} - {resp.text}")
                
        except Exception as e:
            logger.exception(f"Aliyun NLS Auth Error: {e}")
        
        return ""


