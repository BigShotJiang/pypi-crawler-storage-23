﻿import logging
import json
from typing import Any, Dict
from src.hub.common import HttpClientManager, BaseImageDriver, ImageDriverFactory

logger = logging.getLogger(__name__)

class AliyunImageDriver(BaseImageDriver):
    """
    Aliyun Wanx (Tongyi Wanxiang) Image Generation Driver.
    Supports wan2.6 (Sync) and other models.
    """

    def __init__(self, **kwargs):
        pass

    async def generate(
        self,
        prompt: str,
        model: str = None,
        size: str = "1280*1280",
        n: int = 1,
        **kwargs: Any
    ) -> Dict[str, Any]:
        import asyncio
        
        credentials = kwargs.get("credentials", {})
        api_key = credentials.get("api_key") or kwargs.get("api_key")
        
        if not api_key:
             return {"success": False, "error": "Missing Aliyun API Key (api_key)."}

        # Get model from credentials (which merges metadata/params from DB) or use passed model
        # The DB params usually contain the real model name in 'model' key
        real_model = credentials.get("model")
        if real_model:
            model = real_model
        
        # Default model to wan2.6-t2i if still not specified
        model = model or "wan2.6-t2i"

        # Construct Headers - FORCE ASYNC as per error 'current user api does not support synchronous calls'
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {api_key}",
            "X-DashScope-Async": "enable" 
        }
        # Filter None headers
        headers = {k: v for k, v in headers.items() if v is not None}

        # Select Endpoint based on model or config
        endpoint = "https://dashscope.aliyuncs.com/api/v1/services/aigc/multimodal-generation/generation"
        
        # Check if using wanx2.0 or other text-to-image specific models
        if "wanx" in model or "wan-v2" in model or "wan2.0" in model or "turbo" in model:
             # Try the older/standard text2image endpoint which is common for Wanx series
             endpoint = "https://dashscope.aliyuncs.com/api/v1/services/aigc/text2image/image-synthesis"
        
        # Prepare Input
        if "wanx" in model or "turbo" in model:
             input_data = {
                 "prompt": prompt
             }
        else:
             input_data = {
                "messages": [
                    {
                        "role": "user",
                        "content": [
                            {"text": prompt}
                        ]
                    }
                ]
            }

        # Prepare Parameters
        parameters = {
            "size": size,
            "n": n,
            "prompt_extend": kwargs.get("prompt_extend", True),
            "watermark": kwargs.get("watermark", False),
        }

        if kwargs.get("negative_prompt"):
            parameters["negative_prompt"] = kwargs.get("negative_prompt")
        
        if kwargs.get("seed"):
            parameters["seed"] = kwargs.get("seed")

        payload = {
            "model": model,
            "input": input_data,
            "parameters": parameters
        }

        logger.info(f"Aliyun Image Gen Request: {model} - {size} (Async Polling Mode)")

        client = HttpClientManager.get_client()
        
        try:
            # 1. Submit Task
            resp = await client.post(endpoint, json=payload, headers=headers, timeout=30.0)
            
            if resp.status_code != 200:
                logger.error(f"Aliyun Image Gen Submit Error: {resp.status_code} - {resp.text}")
                return {
                    "success": False, 
                    "error": f"Provider API Submit Error: {resp.status_code}. Raw: {resp.text}", 
                    "raw_response": resp.text
                }

            data = resp.json()
            
            if "code" in data and data["code"]:
                return {
                    "success": False,
                    "error": data.get("message", "Unknown error"),
                    "code": data.get("code")
                }

            output = data.get("output", {})
            task_id = output.get("task_id")
            
            if not task_id:
                 # Should not happen in async mode ?
                 # Maybe it finished instantly?
                 if output.get("task_status") == "SUCCEEDED":
                     results = output.get("results", [])
                     images = []
                     for res in results:
                        if "url" in res:
                            images.append({"url": res["url"], "content_type": "image/png"})
                        elif "b64_image" in res:
                             images.append({"base64": res["b64_image"], "content_type": "image/png"})
                     return {
                        "success": True,
                        "images": images,
                        "task_id": output.get("task_id"),
                        "usage": data.get("usage")
                    }
                 
                 return {
                    "success": False, 
                    "error": "No task_id returned in async mode."
                 }

            # 2. Poll Task Status
            # Loop for max 60 seconds (or more realistically 2-3 mins for some models, but let's say 120s)
            start_time = asyncio.get_event_loop().time()
            max_wait = 120 # seconds
            
            logger.info(f"Aliyun Task Submitted: {task_id}. Polling...")
            
            while True:
                current_time = asyncio.get_event_loop().time()
                if current_time - start_time > max_wait:
                    return {"success": False, "error": f"Image generation timed out after {max_wait}s", "task_id": task_id}
                
                await asyncio.sleep(2) # Wait 2 seconds between polls
                
                task_url = f"https://dashscope.aliyuncs.com/api/v1/tasks/{task_id}"
                task_resp = await client.get(task_url, headers={"Authorization": f"Bearer {api_key}"})
                
                if task_resp.status_code != 200:
                    logger.error(f"Aliyun Task Poll Error: {task_resp.status_code} - {task_resp.text}")
                    # Continue or break? Let's break
                    return {"success": False, "error": f"Polling failed: {task_resp.status_code}"}
                
                task_data = task_resp.json()
                task_output = task_data.get("output", {})
                task_status = task_output.get("task_status")
                
                if task_status == "SUCCEEDED":
                    results = task_output.get("results", [])
                    images = []
                    for res in results:
                         if "url" in res:
                            images.append({"url": res["url"], "content_type": "image/png"})
                         elif "b64_image" in res:
                             images.append({"base64": res["b64_image"], "content_type": "image/png"})
                    
                    logger.info(f"Aliyun Task {task_id} Succeeded.")
                    return {
                        "success": True,
                        "images": images,
                        "task_id": task_id,
                        "usage": task_data.get("usage")
                    }
                
                elif task_status == "FAILED":
                     logger.error(f"Aliyun Task {task_id} Failed: {task_data}")
                     message = task_output.get("message") or task_data.get("message", "Unknown error")
                     code = task_output.get("code") or task_data.get("code")
                     return {
                        "success": False,
                        "error": f"Task Failed: {code} - {message}",
                        "raw_response": task_data
                     }
                
                # If PENDING or RUNNING, continue loop

        except Exception as e:
            logger.exception("Aliyun Image Gen Exception")
            return {"success": False, "error": str(e)}

ImageDriverFactory.register("tongyi", AliyunImageDriver)


