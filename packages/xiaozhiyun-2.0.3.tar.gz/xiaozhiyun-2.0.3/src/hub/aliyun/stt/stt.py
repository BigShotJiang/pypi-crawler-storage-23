﻿from typing import Any, Dict, Optional, AsyncGenerator, Callable, Awaitable
from src.hub.common import HttpClientManager
import logging
import asyncio

logger = logging.getLogger(__name__)

class AliyunSTTDriver:
    """
    Aliyun STT / FunASR Driver.
    Ref: https://help.aliyun.com/zh/model-studio/fun-asr-realtime-python-sdk
    """
    
    async def asr(
        self,
        audio_generator: AsyncGenerator[bytes, None],
        callback: Callable[[Dict[str, Any]], Awaitable[None]],
        credentials: Dict[str, Any]
    ) -> None:
        """
        瀹炴椂璇煶璇嗗埆 (Fun-ASR)
        
        Args:
            audio_generator: 寮傛闊抽鏁版嵁鐢熸垚鍣紝姣忔 yield bytes 鏁版嵁
            callback: 寮傛鍥炶皟鍑芥暟锛岀敤浜庢帴鏀惰瘑鍒粨鏋?
            credentials: 鍑瘉淇℃伅锛屽寘鍚?api_key, model, format, sample_rate 绛?
        """
        import dashscope
        from dashscope.audio.asr import Recognition, RecognitionCallback, RecognitionResult
        
        # 1. 鑾峰彇鍑瘉
        # 浼樺厛绾э細鐩存帴浼犲叆鐨?api_key > app_key (鍦?stt.json 涓槧灏勪负 api_key) > access_key_id
        api_key = credentials.get("api_key") or credentials.get("app_key") or credentials.get("access_key_id")
        
        if not api_key:
            logger.error(f"Aliyun STT Credentials: {list(credentials.keys())}") # 浠呮墦鍗?key 杈呭姪璋冭瘯
            await callback({"error": "Missing Aliyun API Key for STT."})
            return

        dashscope.api_key = api_key
        
        # 2. 妯″瀷鍜屽弬鏁伴厤缃?
        model = credentials.get("model", "fun-asr-realtime")  # fun-asr-realtime 鎴?fun-asr-realtime-2025-11-07
        audio_format = credentials.get("format", "pcm")  # pcm, wav, mp3, opus, speex, aac, amr
        sample_rate = int(credentials.get("sample_rate", 16000))
        language_hints = credentials.get("language_hints", ["zh", "en"])

        loop = asyncio.get_event_loop()
        
        # 3. 瀹氫箟鍥炶皟绫?
        class MyRecognitionCallback(RecognitionCallback):
            def on_open(self) -> None:
                logger.info("ASR 杩炴帴宸插缓绔?)
                loop.call_soon_threadsafe(
                    lambda: asyncio.create_task(callback({"type": "open"}))
                )

            def on_close(self) -> None:
                logger.info("ASR 杩炴帴宸插叧闂?)
                loop.call_soon_threadsafe(
                    lambda: asyncio.create_task(callback({"type": "close"}))
                )

            def on_complete(self) -> None:
                logger.info("ASR 璇嗗埆瀹屾垚")
                loop.call_soon_threadsafe(
                    lambda: asyncio.create_task(callback({"type": "complete"}))
                )

            def on_event(self, result: RecognitionResult) -> None:
                try:
                    sentence = result.get_sentence()
                    if sentence:
                        text = sentence.get("text", "")
                        is_final = RecognitionResult.is_sentence_end(sentence)
                        begin_time = sentence.get("begin_time", 0)
                        end_time = sentence.get("end_time", 0)
                        
                        if text:
                            loop.call_soon_threadsafe(
                                lambda t=text, f=is_final, bt=begin_time, et=end_time: asyncio.create_task(callback({
                                    "type": "result",
                                    "text": t,
                                    "is_final": f,
                                    "begin_time": bt,
                                    "end_time": et
                                }))
                            )
                except Exception as e:
                    logger.error(f"ASR Callback Error: {e}")

            def on_error(self, result: RecognitionResult) -> None:
                error_msg = str(result) if result else "Unknown ASR Error"
                logger.error(f"ASR Error: {error_msg}")
                loop.call_soon_threadsafe(
                    lambda: asyncio.create_task(callback({"type": "error", "error": error_msg}))
                )

        # 4. 鍒濆鍖?Recognition
        recognition = Recognition(
            model=model,
            format=audio_format,
            sample_rate=sample_rate,
            language_hints=language_hints,
            callback=MyRecognitionCallback()
        )
        
        try:
            # 5. 鍚姩璇嗗埆
            recognition.start()
            
            # 6. 鎺ㄩ€侀煶棰戞暟鎹?
            async for chunk in audio_generator:
                if chunk:
                    # send_audio_frame 寤鸿姣忓寘 100ms 闊抽锛屽ぇ灏?1KB~16KB
                    recognition.send_audio_frame(chunk)
            
            # 7. 鍋滄璇嗗埆 (浼氶樆濉炵洿鍒?on_complete 鎴?on_error)
            recognition.stop()
            
        except Exception as e:
            logger.error(f"Aliyun ASR Exception: {e}")
            await callback({"type": "error", "error": str(e)})

    # 鍏煎鏂规硶锛歐ebSocket 鏈嶅姟璋冪敤姝ゆ柟娉?
    async def real_time_transcribe(
        self,
        audio_generator: AsyncGenerator[bytes, None],
        callback: Callable[[Dict[str, Any]], Awaitable[None]],
        credentials: Dict[str, Any]
    ) -> None:
        """
        瀹炴椂杞啓鍏ュ彛 (鍏煎 WebSocket 鏈嶅姟璋冪敤)
        """
        await self.asr(audio_generator, callback, credentials)

