﻿import asyncio
import base64
import logging
import threading
from typing import Any, AsyncGenerator

from dashscope.audio.qwen_tts_realtime import (
    QwenTtsRealtime,
    QwenTtsRealtimeCallback,
    AudioFormat,
)

logger = logging.getLogger(__name__)

class AliyunTTSDriver:
    """Aliyun Qwen-TTS-Realtime Driver using Official SDK."""

    def __init__(self):
        self.synthesizer = None
        self.queue = asyncio.Queue()
        self.loop = None
        self.connected_event = threading.Event()
        self.session_id = None
        self.is_connected = False

    class MyCallback(QwenTtsRealtimeCallback):
        def __init__(self, outer):
            self.outer = outer

        def on_open(self) -> None:
            logger.debug("QwenTtsRealtime connected")
            self.outer.is_connected = True
            self.outer.connected_event.set()

        def on_close(self, code, msg) -> None:
            logger.debug(f"QwenTtsRealtime closed: {code} {msg}")
            self.outer.is_connected = False
            self.outer.connected_event.set() # Set to unblock wait even if failed
            if self.outer.loop:
                self.outer.loop.call_soon_threadsafe(self.outer.queue.put_nowait, None)

        def on_event(self, response: dict) -> None:
            try:
                event_type = response.get('type')
                if event_type == 'session.created':
                    self.outer.session_id = response.get('session', {}).get('id')
                    logger.info(f"Aliyun TTS Session started: {self.outer.session_id}")
                
                elif event_type == 'response.audio.delta':
                    delta = response.get('delta')
                    if delta:
                        audio_bytes = base64.b64decode(delta)
                        if self.outer.loop:
                            self.outer.loop.call_soon_threadsafe(self.outer.queue.put_nowait, audio_bytes)
                
                elif event_type == 'response.audio.done' or event_type == 'response.done':
                    # Single sentence/commit is finished
                    if self.outer.loop:
                        self.outer.loop.call_soon_threadsafe(self.outer.queue.put_nowait, "FINISHED")
                
                elif event_type == 'error':
                    err = response.get('error', {}).get('message', 'Unknown error')
                    logger.error(f"Aliyun TTS SDK Error: {err}")
                    if self.outer.loop:
                        self.outer.loop.call_soon_threadsafe(self.outer.queue.put_nowait, None)
            except Exception as e:
                logger.error(f"Aliyun Callback processing error: {e}")

    async def synthesize_stream(self, text: str, voice_id: str, **kwargs: Any) -> AsyncGenerator[bytes, None]:
        api_key = kwargs.get("api_key") or kwargs.get("credentials", {}).get("api_key")
        if not api_key:
            raise ValueError("Aliyun API key is required")

        import dashscope
        dashscope.api_key = api_key
        
        if not self.loop:
            self.loop = asyncio.get_running_loop()
        
        # 1. Initialize and Connect if needed
        if self.synthesizer is None:
            model = kwargs.get("model", "qwen3-tts-flash-realtime") 
            url = 'wss://dashscope.aliyuncs.com/api-ws/v1/realtime'
            self.synthesizer = QwenTtsRealtime(model=model, callback=self.MyCallback(self), url=url)
            
            def run_connect():
                try:
                    self.synthesizer.connect()
                except Exception as e:
                    logger.error(f"QwenTtsRealtime connect error: {e}")
                    self.connected_event.set()

            threading.Thread(target=run_connect, daemon=True).start()
            
            # Wait for connection
            await asyncio.to_thread(self.connected_event.wait, timeout=10.0)
            if not self.is_connected:
                logger.error("Failed to connect to Aliyun TTS WebSocket")
                return

            # Initial session update
            voice = voice_id or kwargs.get("voice") or "Cherry"
            # format_str = kwargs.get("format", "pcm").lower()
            # Default to 24k PCM for best quality/compatibility in our setup
            self.synthesizer.update_session(
                voice=voice, 
                response_format=AudioFormat.PCM_24000HZ_MONO_16BIT,
                mode='commit'
            )

        # 2. Clear queue for new sentence
        while not self.queue.empty():
            try: self.queue.get_nowait()
            except: break

        # 3. Send text and commit
        try:
            self.synthesizer.append_text(text)
            self.synthesizer.commit()
            
            # 4. Consume chunks until sentence is done or session closed
            while True:
                item = await self.queue.get()
                if item is None:
                    # Session closed or fatal error
                    self.synthesizer = None
                    return
                if item == "FINISHED":
                    await asyncio.sleep(0.2) # Enhanced buffer to ensure all audio data is processed
                    break
                if isinstance(item, bytes):
                    yield item
        except Exception as e:
            logger.error(f"Aliyun TTS synthesis error: {e}")
            
    def close(self):
        if self.synthesizer:
            try:
                # Use finish() to tell the server we are done with the session, then close()
                self.synthesizer.finish()
                self.synthesizer.close()
                self.synthesizer = None
            except Exception as e:
                logger.debug(f"Error during synthesizer close: {e}")


