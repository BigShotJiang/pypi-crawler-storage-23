﻿from typing import Any, Dict, Optional
import os
from src.config import config
from src.chat import process_chat

class AliyunChatDriver:
    """
    Aliyun DashScope Chat Driver (Delegates to shared process_chat).
    """
    
    def __init__(self):
        self.provider_config = config.get_provider_config("aliyun")

    async def generate(
        self,
        prompt: str,
        model: str = "default",
        temperature: float = 0.7,
        max_tokens: int = 1000,
        **kwargs: Any
    ) -> Dict[str, Any]:
        
        creds = kwargs.get("credentials", {})
        
        # Determine API Key
        api_key = (
            kwargs.get("api_key") or 
            creds.get("api_key") or 
            os.getenv(self.provider_config.api_key_env)
        )
        
        # Determine Model
        if model == "default" or not model:
            model = self.provider_config.default_model

        # Base URL
        base_url = self.provider_config.base_url
        
        return await process_chat(
            messages=prompt, # process_chat handles string conversion
            model=model,
            api_key=api_key,
            base_url=base_url,
            temperature=temperature,
            max_tokens=max_tokens,
            stream=kwargs.get("stream", False),
            extra_params=kwargs.get("extra_params", {})
        )



