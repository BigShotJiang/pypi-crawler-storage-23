﻿import logging
import json
from typing import Any, Dict
from src.hub.common import HttpClientManager, BaseImageDriver, ImageDriverFactory
from src.hub.tencent.auth import TencentAuth

logger = logging.getLogger(__name__)

class TencentImageDriver(BaseImageDriver):
    """
    Tencent Hunyuan Image Generation Driver (Lite version).
    Reference: https://cloud.tencent.com/document/api/1729/108738
    """

    def __init__(self, **kwargs):
        pass

    async def generate(
        self,
        prompt: str,
        model: str = None,
        size: str = "1024*1024",
        n: int = 1,
        **kwargs: Any
    ) -> Dict[str, Any]:
        """
        Generate image using Tencent Hunyuan TextToImageLite.
        """
        credentials = kwargs.get("credentials", {})
        secret_id = credentials.get("api_key") or credentials.get("secret_id") or credentials.get("access_key") or kwargs.get("api_key") or kwargs.get("secret_id")
        secret_key = credentials.get("secret_key") or kwargs.get("secret_key")
        
        # Region can be passed in credentials or kwargs, default to ap-guangzhou
        region = credentials.get("region") or kwargs.get("region") or "ap-guangzhou"

        if not secret_id or not secret_key:
            return {"success": False, "error": "Missing Tencent Cloud credentials (secret_id/secret_key)."}

        # Resolution mapping: 1024*1024 -> 1024:1024
        resolution = size.replace("*", ":")
        
        # Action and Version
        action = "TextToImageLite"
        version = "2023-09-01"
        service = "hunyuan"
        host = "hunyuan.tencentcloudapi.com"

        # Prepare Payload
        payload = {
            "Prompt": prompt,
            "RspImgType": "url"  # Prefer URL for better performance/display
        }
        
        if kwargs.get("negative_prompt"):
            payload["NegativePrompt"] = kwargs.get("negative_prompt")
        
        if kwargs.get("style"):
            payload["Style"] = kwargs.get("style")
            
        payload["Resolution"] = resolution

        # Generate Headers
        try:
            headers = TencentAuth.get_v3_headers(
                secret_id=secret_id,
                secret_key=secret_key,
                service=service,
                host=host,
                region=region,
                action=action,
                version=version,
                payload=payload
            )
        except Exception as e:
            logger.error(f"Failed to generate Tencent signature: {e}")
            return {"success": False, "error": f"Signature Error: {str(e)}"}

        logger.info(f"Tencent Image Gen Request: {action} - {resolution} (Region: {region})")

        client = HttpClientManager.get_client()
        endpoint = f"https://{host}"
        
        try:
            resp = await client.post(endpoint, json=payload, headers=headers, timeout=60.0)
            
            if resp.status_code != 200:
                logger.error(f"Tencent Image Gen Error: {resp.status_code} - {resp.text}")
                return {
                    "success": False, 
                    "error": f"Tencent API Error: {resp.status_code}. Raw: {resp.text}", 
                    "raw_response": resp.text
                }

            data = resp.json()
            response_data = data.get("Response", {})
            
            if "Error" in response_data:
                err = response_data["Error"]
                return {
                    "success": False,
                    "error": f"{err.get('Code')}: {err.get('Message')}",
                    "request_id": response_data.get("RequestId")
                }

            images = []
            if "ResultImage" in response_data:
                # Lite version returns a single string ResultImage which is either URL or Base64
                img_data = response_data["ResultImage"]
                if img_data.startswith("http"):
                    images.append({"url": img_data, "content_type": "image/png"})
                else:
                    images.append({"base64": img_data, "content_type": "image/png"})

            return {
                "success": True,
                "images": images,
                "request_id": response_data.get("RequestId"),
                "usage": response_data.get("Usage", {"total_images": 1})
            }

        except Exception as e:
            logger.exception("Tencent Image Gen Exception")
            return {"success": False, "error": str(e)}

ImageDriverFactory.register("tencent", TencentImageDriver)


