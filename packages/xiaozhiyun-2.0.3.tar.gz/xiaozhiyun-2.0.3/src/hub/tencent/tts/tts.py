﻿import logging
import json
import base64
import time
import uuid
import hmac
import hashlib
import websockets
from urllib.parse import quote
from typing import Any, Dict, AsyncGenerator
from src.hub.common import HttpClientManager, BaseTTSDriver, TTSDriverFactory
from src.hub.tencent.auth import TencentAuth

logger = logging.getLogger(__name__)

class TencentTTSDriver(BaseTTSDriver):
    """
    Tencent Cloud Text-to-Speech (TTS) service implementation.
    Supports REST API and WebSocket streaming (v2).
    
    Ref: https://cloud.tencent.com/document/product/1073/108595
    """
    
    async def synthesize(
        self,
        text: str,
        voice_id: str,
        speed: float = 0,
        volume: float = 0,
        voice_type: int = 0,
        **kwargs: Any
    ) -> Dict[str, Any]:
        """
        Synthesize text to speech using Tencent TTS (TextToVoice).
        """
        credentials = kwargs.get("credentials", {})
        secret_id = credentials.get("api_key") or credentials.get("secret_id") or kwargs.get("api_key")
        secret_key = credentials.get("secret_key") or kwargs.get("secret_key")
        region = credentials.get("region") or kwargs.get("region") or "ap-shanghai"
        
        if not secret_id or not secret_key:
            return {"success": False, "error": "Missing Tencent credentials"}

        action = "TextToVoice"
        version = "2019-08-23"
        service = "tts"
        host = "tts.tencentcloudapi.com"
        
        # Determine VoiceType (Voice ID)
        # 1. From direct argument (voice_id)
        actual_voice_type = None
        if voice_id and voice_id.isdigit():
            actual_voice_type = int(voice_id)
        
        # 2. Match by scenario if voice_id is missing or not a digit
        if actual_voice_type is None:
            scenario = kwargs.get("scenario") or credentials.get("scenario") or "common"
            voices_conf = credentials.get("voices", [])
            if isinstance(voices_conf, list):
                # Try to find a voice matching the scenario
                for v in voices_conf:
                    if isinstance(v, dict) and v.get("scenario") == scenario:
                        actual_voice_type = int(v.get("id"))
                        break
            
        # 3. Final fallback to default or from mate_data
        if actual_voice_type is None:
            actual_voice_type = int(credentials.get("VoiceType") or kwargs.get("voice_type") or 101001)

        payload: Dict[str, Any] = {
            "Text": text,
            "SessionId": str(uuid.uuid4()),
            "VoiceType": actual_voice_type,
            "Speed": speed,
            "Volume": volume,
            "ProjectId": 0,
            "Codec": kwargs.get("format", "mp3"),
            "SampleRate": kwargs.get("sample_rate", 16000)
        }
        
        try:
            headers = TencentAuth.get_v3_headers(
                secret_id=secret_id,
                secret_key=secret_key,
                service=service,
                host=host,
                region=region,
                action=action,
                version=version,
                payload=payload
            )
            
            client = HttpClientManager.get_client()
            resp = await client.post(f"https://{host}", json=payload, headers=headers)
            data = resp.json()
            
            response_data = data.get("Response", {})
            if "Error" in response_data:
                return {
                    "success": False,
                    "error": response_data["Error"].get("Message")
                }
            
            audio_base64 = response_data.get("Audio")
            if audio_base64:
                return {
                    "success": True,
                    "audio_content": base64.b64decode(audio_base64),
                    "format": payload["Codec"],
                    "error": None
                }
            else:
                return {"success": False, "error": "No audio returned"}
                
        except Exception as e:
            return {"success": False, "error": str(e)}

    def _generate_signature(self, params: Dict[str, Any], secret_key: str, path: str = "/stream_ws") -> str:
        """Generate HMAC-SHA1 signature for WebSocket request."""
        # Sort params alphabetically
        sorted_params = sorted(params.items())
        # Join as key=value&...
        query_string = "&".join([f"{k}={v}" for k, v in sorted_params])
        # String to sign: METHOD + HOST + PATH + ? + QUERY_STRING
        host = "tts.cloud.tencent.com"
        sign_str = f"GET{host}{path}?{query_string}"
        
        signature = hmac.new(
            secret_key.encode('utf-8'),
            sign_str.encode('utf-8'),
            hashlib.sha1
        ).digest()
        
        return base64.b64encode(signature).decode('utf-8')

    async def synthesize_stream(self, text: str, voice_id: str, **kwargs: Any) -> AsyncGenerator[bytes, None]:
        """
        瀹炴椂璇煶鍚堟垚 via WebSocket (TextToStreamAudioWS)
        Ref: https://cloud.tencent.com/document/product/1073/94308
        """
        credentials = kwargs.get("credentials", {})
        secret_id = credentials.get("secret_id") or credentials.get("api_key") or kwargs.get("api_key")
        secret_key = credentials.get("secret_key") or kwargs.get("secret_key")
        app_id = credentials.get("app_id") or kwargs.get("app_id")
        
        if not secret_id or not secret_key or not app_id:
            logger.error(f"Missing Tencent credentials for stream: secret_id={bool(secret_id)}, app_id={bool(app_id)}")
            return

        timestamp = int(time.time())
        expired = timestamp + 86400
        session_id = str(uuid.uuid4())
        
        # Determine VoiceType (Voice ID)
        voice_type_val = None
        if voice_id and voice_id.isdigit():
            voice_type_val = int(voice_id)
            
        if voice_type_val is None:
            scenario = kwargs.get("scenario") or credentials.get("scenario") or "common"
            voices_conf = credentials.get("voices", [])
            if isinstance(voices_conf, list):
                for v in voices_conf:
                    if isinstance(v, dict) and v.get("scenario") == scenario:
                        voice_type_val = int(v.get("id"))
                        break
        
        if voice_type_val is None:
            voice_type_val = int(credentials.get("VoiceType") or kwargs.get("voice_type") or 101001)
        
        # Tencent stream_ws supports 8000, 16000. 
        sample_rate = int(kwargs.get("sample_rate", 16000))
        if sample_rate not in [8000, 16000]:
            sample_rate = 16000
            
        params = {
            "Action": "TextToStreamAudioWS",
            "AppId": int(app_id),
            "Codec": "pcm", 
            "EnableSubtitle": "True" if kwargs.get("enable_subtitle") is not False else "False",
            "Expired": expired,
            "SampleRate": sample_rate,
            "SecretId": secret_id,
            "SessionId": session_id,
            "Speed": int(kwargs.get("speed") or 0),
            "Text": text,
            "Timestamp": timestamp,
            "VoiceType": voice_type_val,
            "Volume": int(kwargs.get("volume") or 0)
        }
        
        # Calculate signature (on raw values as per SDK)
        signature = self._generate_signature(params, secret_key, path="/stream_ws")
        
        # Build final URL with encoded parameters
        # Note: Tencent SDK quotes the text but keeps other params as-is (they are mostly alphanumeric)
        # To be safe and compatible, we'll use urlencode but ensure it looks like what Tencent expects.
        from urllib.parse import urlencode, quote
        
        # Create a copy for encoding to not affect future use of params (though not applicable here)
        encoded_params_dict = params.copy()
        
        # Quote the signature
        ws_url = f"wss://tts.cloud.tencent.com/stream_ws?{urlencode(encoded_params_dict)}&Signature={quote(signature)}"

        try:
            async with websockets.connect(ws_url) as ws:
                async for message in ws:
                    if isinstance(message, bytes):
                         # Yield raw PCM chunks (Unify with Aliyun)
                        yield message
                    else:
                        # This is JSON metadata (subtitles or end)
                        try:
                            resp = json.loads(message)
                            if resp.get("code") != 0:
                                logger.error(f"Tencent TTS Error: {resp.get('message')}")
                                break
                            if resp.get("final") == 1:
                                break
                        except json.JSONDecodeError:
                            pass
        except Exception as e:
            logger.error(f"Tencent TTS WebSocket connection failed: {e}")

TTSDriverFactory.register("tencent", TencentTTSDriver)



