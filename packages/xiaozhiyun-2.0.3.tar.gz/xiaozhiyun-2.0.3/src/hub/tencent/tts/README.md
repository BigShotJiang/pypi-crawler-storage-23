﻿# Tencent TTS Driver

鑵捐浜戣闊冲悎鎴愰┍鍔紝鏀寔 REST API (`TextToVoice`) 鍜?WebSocket 娴佸紡鍚堟垚 (`TextToStreamAudioWSv2`).

## 鍔熻兘

- **鐭枃鏈悎鎴?* (`synthesize`) - REST API
- **娴佸紡鏂囨湰鍚堟垚** (`synthesize_websocket`) - WebSocket v2锛屾敮鎸佸疄鏃跺瓧骞?

## 蹇€熷紑濮?

### REST API 鍚堟垚

```python
from src.hub.tencent.tts.tts import TencentTTSDriver

driver = TencentTTSDriver()

result = await driver.synthesize(
    text="浣犲ソ锛屾杩庝娇鐢ㄨ吘璁簯璇煶鍚堟垚",
    voice_id="101001",
    credentials={
        "secret_id": "YOUR_SECRET_ID",
        "secret_key": "YOUR_SECRET_KEY"
    }
)

if result["success"]:
    audio_data = result["audio_content"]
```

### WebSocket 娴佸紡鍚堟垚

```python
from src.hub.tencent.tts.tts import TencentTTSDriver

driver = TencentTTSDriver()

async for chunk in driver.synthesize_websocket(
    text="浣犲ソ锛屾杩庝娇鐢ㄨ吘璁簯娴佸紡璇煶鍚堟垚",
    voice_id="101001",
    credentials={
        "secret_id": "YOUR_SECRET_ID",
        "secret_key": "YOUR_SECRET_KEY"
    },
    enable_subtitle=True
):
    if isinstance(chunk, bytes):
        # 闊抽鏁版嵁
        audio_file.write(chunk)
    elif isinstance(chunk, dict):
        # 浜嬩欢 (SynthesisStarted, SentenceSynthesis, SynthesisCompleted)
        print(chunk)
```

## WebSocket 鍗忚

### 鑵捐 v2 鍗忚

椹卞姩鍐呴儴浣跨敤鑵捐浜?WebSocket v2 鍗忚锛?

```text
1. 杩炴帴: wss://tts.cloud.tencent.com/stream_wsv2?Action=TextToStreamAudioWSv2&...&Signature=...
2. 鎺ユ敹: READY (ready=1)
3. 鍙戦€? ACTION_SYNTHESIS (鍚枃鏈?
4. 鎺ユ敹: audio/subtitles
5. 鍙戦€? ACTION_COMPLETE
6. 鎺ユ敹: FINAL (final=1)
```

### 缁熶竴鍗忚杞崲

椹卞姩杈撳嚭宸茶浆鎹负缁熶竴浜嬩欢鏍煎紡锛堝吋瀹归樋閲屼簯 NLS锛夛細

| 鑵捐 v2 鍘熺敓浜嬩欢 | 缁熶竴浜嬩欢 |
| ---------------- | -------- |
| READY (ready=1) | SynthesisStarted |
| subtitles | SentenceSynthesis |
| FINAL (final=1) | SynthesisCompleted |
| code != 0 | TaskFailed |
| binary | bytes (鐩存帴閫忎紶) |

## 鍙傛暟璇存槑

### 閫氱敤鍙傛暟

| 鍙傛暟 | 绫诲瀷 | 璇存槑 | 榛樿鍊?|
| ---- | ---- | ---- | ------ |
| text | String | 鍚堟垚鏂囨湰 | - |
| voice_id | String | 鍙戦煶浜篒D | 101001 |

### WebSocket 鍙傛暟

| 鍙傛暟 | 绫诲瀷 | 璇存槑 | 鑼冨洿 | 榛樿鍊?|
| ---- | ---- | ---- | ---- | ------ |
| speech_rate | Integer | 璇€?| -2~2 | 0 |
| volume | Integer | 闊抽噺 | -10~10 | 0 |
| sample_rate | Integer | 閲囨牱鐜?| 8000/16000 | 16000 |
| format | String | 闊抽鏍煎紡 | pcm/mp3 | pcm |
| enable_subtitle | Boolean | 鍚敤瀛楀箷 | true/false | false |

### 甯歌鍙戦煶浜?

| ID | 鍚嶇О | 璇存槑 |
| -- | ---- | ---- |
| 101001 | 鏅虹憸 | 鎯呮劅濂冲０ |
| 101002 | 鏅鸿亞 | 鎯呮劅濂冲０ |
| 101003 | 鏅虹編 | 鎯呮劅濂冲０ |
| 101004 | 鏅轰簯 | 鎯呮劅鐢峰０ |
| 101005 | 鏅鸿帀 | 鎯呮劅濂冲０ |

## 璁よ瘉

鑵捐浜戜娇鐢?SecretId / SecretKey 璁よ瘉锛?

```python
credentials = {
    "secret_id": "YOUR_SECRET_ID",
    "secret_key": "YOUR_SECRET_KEY",
    "app_id": "YOUR_APP_ID"  # 鍙€夛紝閮ㄥ垎鎺ュ彛闇€瑕?
}
```

椹卞姩浼氳嚜鍔ㄧ敓鎴愯姹傜鍚嶃€?

## 鏂囦欢缁撴瀯

```text
hub/tencent/tts/
鈹溾攢鈹€ __init__.py
鈹溾攢鈹€ tts.py          # TencentTTSDriver 瀹炵幇
鈹斺攢鈹€ README.md       # 鏈枃妗?
```

## 鍙傝€冩枃妗?

- [娴佸紡鏂囨湰璇煶鍚堟垚 (Websocket)](https://cloud.tencent.com/document/product/1073/108595)
- [鍩虹璇煶鍚堟垚](https://cloud.tencent.com/document/product/1073/94315)


