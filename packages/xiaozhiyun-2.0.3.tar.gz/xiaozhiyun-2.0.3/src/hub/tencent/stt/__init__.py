﻿# Tencent STT module


