﻿import logging
import json
import base64
import asyncio
import hmac
import hashlib
import time
import random
import uuid
import websockets
from urllib.parse import urlencode, quote
from typing import Any, Dict, Optional, AsyncGenerator, Callable, Awaitable
from src.hub.common import HttpClientManager
from src.hub.tencent.auth import TencentAuth

logger = logging.getLogger(__name__)

class TencentSTTDriver:
    """
    Tencent Cloud Speech-to-Text (ASR) service implementation.
    Real-time recogniztion via WebSocket v2.
    Ref: https://cloud.tencent.com/document/product/1093/48982
    """

    def _generate_signature(self, app_id: str, params: Dict[str, Any], secret_key: str) -> str:
        """Generate HMAC-SHA1 signature for ASR WebSocket request."""
        # Sort params alphabetically
        sorted_params = sorted(params.items())
        # Join as key=value&...
        query_string = "&".join([f"{k}={v}" for k, v in sorted_params])
        # String to sign: HOST + PATH + ? + QUERY_STRING (Tencent ASR v2 spec)
        host = "asr.cloud.tencent.com"
        path = f"/asr/v2/{app_id}"
        sign_str = f"{host}{path}?{query_string}"
        
        signature = hmac.new(
            secret_key.encode('utf-8'),
            sign_str.encode('utf-8'),
            hashlib.sha1
        ).digest()
        
        return base64.b64encode(signature).decode('utf-8')

    async def asr(
        self,
        audio_generator: AsyncGenerator[bytes, None],
        callback: Callable[[Dict[str, Any]], Awaitable[None]],
        credentials: Dict[str, Any]
    ) -> None:
        """
        瀹炴椂璇煶璇嗗埆锛圵ebSocket锛?
        https://cloud.tencent.com/document/product/1093/48982
        """
        secret_id = credentials.get("secret_id") or credentials.get("api_key")
        secret_key = credentials.get("secret_key")
        app_id = credentials.get("app_id")
        
        if not secret_id or not secret_key or not app_id:
            logger.error("Missing Tencent STT credentials")
            await callback({"error": "Missing Tencent STT credentials"})
            return

        timestamp = int(time.time())
        nonce = random.randint(100000, 999999)
        expired = timestamp + 86400
        voice_id = str(uuid.uuid4())
        
        params = {
            "secretid": secret_id,
            "timestamp": timestamp,
            "expired": expired,
            "nonce": nonce,
            "engine_model_type": credentials.get("engine_model_type", "16k_zh"),
            "voice_format": credentials.get("voice_format", 1), # 1: PCM, 8: Mp3
            "voice_id": voice_id,
            "timeout": 5000,
            "result_text_format": 0,
            "res_type": 1,
            "needvad": 1,
            "filter_dirty": 1,
            "filter_modal": 1,
            "filter_punc": 1
        }
        
        # Override with any custom mate_data
        if "hotword_id" in credentials:
            params["hotword_id"] = credentials["hotword_id"]
        if "customization_id" in credentials:
            params["customization_id"] = credentials["customization_id"]

        signature = self._generate_signature(app_id, params, secret_key)
        
        # Build URL
        encoded_params = urlencode(params)
        ws_url = f"wss://asr.cloud.tencent.com/asr/v2/{app_id}?{encoded_params}&signature={quote(signature)}"

        try:
            async with websockets.connect(ws_url) as ws:
                # 1. Start sender task
                async def send_audio():
                    try:
                        async for chunk in audio_generator:
                            if chunk:
                                await ws.send(chunk)
                        # Send end-of-stream signal
                        await ws.send(json.dumps({"type": "end"}))
                    except Exception as e:
                        logger.error(f"Error sending audio to Tencent ASR: {e}")

                sender_task = asyncio.create_task(send_audio())

                # 2. Receive loop
                async for message in ws:
                    try:
                        resp = json.loads(message)
                        if resp.get("code") != 0:
                            logger.error(f"Tencent ASR Error: {resp.get('message')}")
                            await callback({"error": resp.get("message")})
                            break
                        
                        # Map Tencent response to common format
                        # code 0: success
                        # final 1: end of voice_id
                        # res_type 1: intermediate results
                        result_data = resp.get("result", {})
                        voice_text_str = result_data.get("voice_text_str", "")
                        
                        await callback({
                            "text": voice_text_str,
                            "is_final": resp.get("final") == 1,
                            "original": resp
                        })

                        if resp.get("final") == 1:
                            break
                    except json.JSONDecodeError:
                        pass
                
                await sender_task
        except Exception as e:
            logger.error(f"Tencent STT WebSocket connection failed: {e}")
            await callback({"error": str(e)})

    # Keep old methods for compatibility if needed, but the focus is on asr()
    async def transcribe(self, **kwargs):
        # Fallback to Sentence Recognition if needed
        pass


