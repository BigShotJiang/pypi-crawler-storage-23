﻿import hashlib
import hmac
import time
import datetime
import json
import logging
from datetime import timezone
from typing import Any, Dict

logger = logging.getLogger(__name__)

class TencentAuth:
    """
    Manages Tencent Cloud API V3 Signatures.
    """
    
    @staticmethod
    def get_v3_headers(
        secret_id: str, 
        secret_key: str, 
        service: str, 
        host: str, 
        region: str, 
        action: str, 
        version: str, 
        payload: Dict[str, Any],
        token: str = ""
    ) -> Dict[str, str]:
        """
        Generates Tencent V3 Signature headers.
        """
        algorithm = "TC3-HMAC-SHA256"
        timestamp = int(time.time())
        date = datetime.datetime.fromtimestamp(timestamp, timezone.utc).strftime("%Y-%m-%d")

        http_method = "POST"
        canonical_uri = "/"
        canonical_query_string = ""
        ct = "application/json"
        payload_json = json.dumps(payload, separators=(',', ':'), ensure_ascii=False)
        
        canonical_headers = f"content-type:{ct}\nhost:{host}\n"
        signed_headers = "content-type;host"
        
        hashed_payload = hashlib.sha256(payload_json.encode("utf-8")).hexdigest()
        canonical_request = f"{http_method}\n{canonical_uri}\n{canonical_query_string}\n{canonical_headers}\n{signed_headers}\n{hashed_payload}"

        credential_scope = f"{date}/{service}/tc3_request"
        hashed_canonical_request = hashlib.sha256(canonical_request.encode("utf-8")).hexdigest()
        string_to_sign = f"{algorithm}\n{timestamp}\n{credential_scope}\n{hashed_canonical_request}"

        def sign_key(key, msg):
            return hmac.new(key, msg.encode("utf-8"), hashlib.sha256).digest()

        secret_date = sign_key(("TC3" + secret_key).encode("utf-8"), date)
        secret_service = sign_key(secret_date, service)
        secret_signing = sign_key(secret_service, "tc3_request")
        signature = hmac.new(secret_signing, string_to_sign.encode("utf-8"), hashlib.sha256).hexdigest()

        authorization = f"{algorithm} Credential={secret_id}/{credential_scope}, SignedHeaders={signed_headers}, Signature={signature}"

        headers = {
            "Authorization": authorization,
            "Content-Type": ct,
            "Host": host,
            "X-TC-Action": action,
            "X-TC-Timestamp": str(timestamp),
            "X-TC-Version": version,
            "X-TC-Region": region,
        }
        if token:
            headers["X-TC-Token"] = token
            
        return headers


