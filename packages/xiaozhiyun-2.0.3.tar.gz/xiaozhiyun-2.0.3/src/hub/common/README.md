﻿# Hub Common Utilities

#

# This module provides shared utilities for all hub services

# All hub services should import from here rather than src/audio/tts

#

# Usage

# from src.hub.common import HttpClientManager, BaseTTSDriver, TTSDriverFactory, TTSConfigs


