﻿import os
from typing import Dict, Any, Optional


class AliyunConfig:
    def __init__(self, creds: Optional[Dict[str, Any]] = None):
        creds = creds or {}
        self.app_key = creds.get("app_key") or creds.get("appkey") or creds.get("app_id") or ""
        self.api_key = creds.get("api_key") or os.getenv("ALIYUN_TTS_API_KEY", "")
        if not self.app_key and self.api_key and not self.api_key.startswith("sk-"):
            self.app_key = self.api_key
        if not self.app_key:
            self.app_key = os.getenv("ALIYUN_TTS_APP_KEY", "")
        self.access_key_id = creds.get("access_key") or os.getenv("ALIYUN_ACCESS_KEY_ID", "")
        self.access_key_secret = creds.get("secret_key") or os.getenv("ALIYUN_ACCESS_KEY_SECRET", "")


class BaiduConfig:
    def __init__(self, creds: Optional[Dict[str, Any]] = None):
        creds = creds or {}
        self.app_id = creds.get("app_id") or os.getenv("BAIDU_TTS_APP_ID", "")
        
        # Debug helper to see what's in creds (keys only for security)
        # logger.info(f"Baidu creds keys: {list(creds.keys())}")
        
        api_key = creds.get("api_key") or creds.get("access_key") or os.getenv("BAIDU_TTS_API_KEY", "")
        self.api_key = api_key
        self.secret_key = creds.get("secret_key") or os.getenv("BAIDU_TTS_SECRET_KEY", "")




class TencentConfig:
    def __init__(self, creds: Optional[Dict[str, Any]] = None):
        creds = creds or {}
        self.secret_id = creds.get("access_key") or creds.get("secret_id") or os.getenv("TENCENT_SECRET_ID", "")
        self.secret_key = creds.get("secret_key") or os.getenv("TENCENT_SECRET_KEY", "")
        self.app_id = creds.get("app_id") or os.getenv("TENCENT_TTS_APP_ID", "")


class VolcengineConfig:
    def __init__(self, creds: Optional[Dict[str, Any]] = None):
        creds = creds or {}
        self.app_id = creds.get("app_id") or os.getenv("VOLCENGINE_TTS_APPID", "")
        self.access_token = creds.get("access_token") or os.getenv("VOLCENGINE_TTS_ACCESS_TOKEN", "")
        self.cluster = creds.get("cluster_id") or os.getenv("VOLCENGINE_TTS_CLUSTER", "volcano_tts")


class TTSConfigs:
    @staticmethod
    def get_aliyun(creds=None) -> AliyunConfig:
        return AliyunConfig(creds)
    
    @staticmethod
    def get_baidu(creds=None) -> BaiduConfig:
        return BaiduConfig(creds)
    
    @staticmethod
    def get_tencent(creds=None) -> TencentConfig:
        return TencentConfig(creds)
    
    @staticmethod
    def get_volcengine(creds=None) -> VolcengineConfig:
        return VolcengineConfig(creds)

    # Global defaults
    aliyun = AliyunConfig()
    baidu = BaiduConfig()
    tencent = TencentConfig()
    volcengine = VolcengineConfig()


