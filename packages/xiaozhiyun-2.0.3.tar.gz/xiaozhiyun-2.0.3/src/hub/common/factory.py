﻿from typing import Dict, Type
from .base import BaseTTSDriver, BaseImageDriver


class TTSDriverFactory:
    """
    Factory for TTS drivers.
    Drivers register themselves on import.
    """
    _drivers: Dict[str, Type[BaseTTSDriver]] = {}

    @classmethod
    def register(cls, name: str, driver_class: Type[BaseTTSDriver]):
        cls._drivers[name] = driver_class

    @classmethod
    def get_driver(cls, name: str) -> BaseTTSDriver:
        driver_class = cls._drivers.get(name)
        if not driver_class:
            raise ValueError(f"Driver {name} not found. Available: {list(cls._drivers.keys())}")
        return driver_class()
    
    @classmethod
    def list_drivers(cls) -> list:
        return list(cls._drivers.keys())


class ImageDriverFactory:
    """Factory to create image drivers."""
    
    _drivers: Dict[str, Type[BaseImageDriver]] = {}

    @classmethod
    def register(cls, driver_name: str, driver_cls: Type[BaseImageDriver]):
        cls._drivers[driver_name] = driver_cls

    @classmethod
    def get_driver(cls, driver_name: str, **kwargs) -> BaseImageDriver:
        driver_cls = cls._drivers.get(driver_name)
        if not driver_cls:
            raise ValueError(f"Image driver '{driver_name}' not found. Available: {list(cls._drivers.keys())}")
        return driver_cls(**kwargs)


