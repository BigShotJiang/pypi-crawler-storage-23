﻿from abc import ABC, abstractmethod
from typing import Any, Dict


class BaseTTSDriver(ABC):
    """
    Abstract base class for all TTS drivers.
    """

    @abstractmethod
    async def synthesize(
        self,
        text: str,
        voice_id: str,
        speed: float = 1.0,
        pitch: float = 1.0,
        volume: float = 1.0,
        format: str = "mp3",
        **kwargs: Any
    ) -> Dict[str, Any]:
        """
        Synthesize text to speech.
        """
        pass


    @abstractmethod
    async def synthesize_stream(
        self,
        text: str,
        voice_id: str,
        **kwargs: Any
    ):
        """
        Synthesize text to speech using streaming.
        """
        pass



class BaseImageDriver(ABC):
    """
    Abstract base class for all Image Generation drivers.
    """

    @abstractmethod
    async def generate(
        self,
        prompt: str,
        model: str = None,
        size: str = "1024*1024",
        n: int = 1,
        **kwargs: Any
    ) -> Dict[str, Any]:
        """
        Generate image from text.
        
        Args:
            prompt: Text description of the image
            model: Model name to use
            size: Image size (e.g. "1024*1024")
            n: Number of images to generate
            **kwargs: Provider specific arguments

        Returns:
            Dict containing success status and image data/urls.
            Example:
            {
                "success": True,
                "images": [
                    {"url": "https://...", "content_type": "image/png"}
                ],
                "task_id": "optional_task_id"
            }
        """
        pass


