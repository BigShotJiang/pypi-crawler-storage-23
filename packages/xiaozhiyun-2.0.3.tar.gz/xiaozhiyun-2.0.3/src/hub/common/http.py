﻿import httpx
import logging
from typing import Optional

logger = logging.getLogger(__name__)

class HttpClientManager:
    """
    Global HTTP client manager for all hub services.
    Provides a shared AsyncClient with connection pooling.
    """
    _async_client: Optional[httpx.AsyncClient] = None

    @classmethod
    def get_client(cls) -> httpx.AsyncClient:
        if cls._async_client is None:
            limits = httpx.Limits(max_connections=200, max_keepalive_connections=50)
            cls._async_client = httpx.AsyncClient(limits=limits, timeout=60.0)
            logger.info("Global AsyncClient initialized with max_connections=200")
        return cls._async_client

    @classmethod
    async def close(cls):
        if cls._async_client:
            await cls._async_client.aclose()
            cls._async_client = None
            logger.info("Global AsyncClient closed")


