﻿import logging
import json
import asyncio
import websockets
from typing import Any, Dict, AsyncGenerator
from src.hub.common import HttpClientManager, BaseTTSDriver, TTSDriverFactory, TTSConfigs
from src.hub.baidu.auth import BaiduAuth

logger = logging.getLogger(__name__)

class BaiduTTSDriver(BaseTTSDriver):
    """Baidu TTS Implementation with WebSocket streaming support.
    
    Ref: https://cloud.baidu.com/doc/SPEECH/s/lm5xd63rn
    """

    def __init__(self):
        self.default_config = TTSConfigs.baidu

    def _get_active_config(self, **kwargs: Any):
        return TTSConfigs.get_baidu(kwargs.get("credentials"))

    async def _get_token(self, **kwargs: Any) -> str:
        credentials = kwargs.get("credentials", {})
        api_key = credentials.get("api_key") or kwargs.get("api_key")
        secret_key = credentials.get("secret_key") or kwargs.get("secret_key")
        
        if api_key and secret_key:
            token = await BaiduAuth.get_access_token(api_key, secret_key)
            return token or ""
        
        config = self._get_active_config(**kwargs)
        token = await BaiduAuth.get_access_token(config.api_key, config.secret_key)
        return token or ""

    async def synthesize(self, text: str, voice_id: str, **kwargs: Any) -> Dict[str, Any]:
        """Non-streaming TTS synthesis via REST API."""
        logger.info(f"Baidu TTS: {text[:20]}...")
        token = await self._get_token(**kwargs)
        if not token:
            return {"success": False, "error": "Baidu token failed."}
        
        per = kwargs.get("per", voice_id if voice_id.isdigit() else "0")
        data = {
            "tex": text, "tok": token, "cuid": "deer-flow", "ctp": 1, "lan": "zh", "per": per,
            "spd": int(kwargs.get("speed", 1.0) * 5), "pit": int(kwargs.get("pitch", 1.0) * 5),
            "vol": int(kwargs.get("volume", 1.0) * 5), "aue": 3
        }
        
        client = HttpClientManager.get_client()
        resp = await client.post("https://tsn.baidu.com/text2audio", data=data)
        if resp.headers.get("Content-Type") == "application/json":
            return {"success": False, "error": resp.text}
        return {
            "success": True, 
            "audio_content": resp.content,
            "format": "mp3", 
            "usage": {"characters": len(text)} 
        }

    async def synthesize_stream(self, text: str, voice_id: str, **kwargs: Any) -> AsyncGenerator[bytes, None]:
        """
        Streaming TTS synthesis via WebSocket.
        Ref: https://cloud.baidu.com/doc/SPEECH/s/lm5xd63rn
        """
        # Get credentials
        credentials = kwargs.get("credentials", {})
        api_key = credentials.get("api_key")
        secret_key = credentials.get("secret_key")
        
        if not api_key or not secret_key:
            # Fallback to config
            config = self._get_active_config(**kwargs)
            api_key = api_key or config.api_key
            secret_key = secret_key or config.secret_key
        
        if not api_key or not secret_key:
            logger.error("Missing Baidu TTS credentials for WebSocket")
            return

        # Get access token for authentication
        token = await self._get_token(**kwargs)
        if not token:
            logger.error("Baidu token failed for WebSocket")
            return

        # Baidu uses 0:濂冲０, 1:鐢峰０, 3:鎯呮劅濂冲０, 4:鎯呮劅鐢峰０, etc.
        # voice_id can be a string like "0", "1", or scenario-based
        per = kwargs.get("per") or (voice_id if voice_id and voice_id.isdigit() else "0")
        
        # Use official WebSocket endpoint from documentation
        ws_url = f"wss://aip.baidubce.com/ws/2.0/speech/publiccloudspeech/v1/tts?access_token={token}&per={per}"

        # Parameter mapping: 0-15 scale (default 5)
        # Assuming input speed/volume are in 0.0-2.0 or 0-100 range, we normalize
        spd = int(kwargs.get("speed", 1.0) * 5)
        spd = max(0, min(15, spd))
        pit = int(kwargs.get("pitch", 1.0) * 5)
        pit = max(0, min(15, pit))
        vol = int(kwargs.get("volume", 1.0) * 5)
        vol = max(0, min(15, vol))
        
        aue = 4 # pcm
        sample_rate = kwargs.get("sample_rate", 16000)

        try:
            async with websockets.connect(ws_url) as ws:
                # 1. Send system.start frame (initialization)
                start_payload = {
                    "type": "system.start",
                    "payload": {
                        "spd": spd,
                        "pit": pit,
                        "vol": vol,
                        "aue": aue,
                        "audio_ctrl": f"{{\"sampling_rate\":{sample_rate}}}"
                    }
                }
                await ws.send(json.dumps(start_payload))

                # 2. Wait for system.started response
                try:
                    resp_str = await asyncio.wait_for(ws.recv(), timeout=5.0)
                    resp = json.loads(resp_str)
                    
                    # Check for error response
                    if resp.get("type") == "system.started":
                        code = resp.get("code", 0)
                        if code != 0:
                            message = resp.get("message", "Unknown error")
                            logger.error(f"Baidu TTS Error: {message} (code: {code})")
                            return
                    elif "error" in resp:
                        error_msg = resp.get("error", "Unknown error")
                        logger.error(f"Baidu TTS Error: {error_msg}")
                        return
                except asyncio.TimeoutError:
                    logger.error("Baidu TTS handshake timeout")
                    return

                # 3. Send text data
                text_payload = {
                    "type": "text",
                    "payload": {
                        "text": text
                    }
                }
                await ws.send(json.dumps(text_payload))

                # 4. Send system.finish
                await ws.send(json.dumps({"type": "system.finish"}))

                # 5. Receive loop
                async for message in ws:
                    if isinstance(message, bytes):
                        # Yield raw PCM chunks (Unify with Aliyun)
                        yield message
                    else:
                        try:
                            resp = json.loads(message)
                            
                            # Check for error response
                            if resp.get("type") == "system.error":
                                message = resp.get("message", "Unknown error")
                                code = resp.get("code", 0)
                                logger.error(f"Baidu TTS Error: {message} (code: {code})")
                                break
                            elif resp.get("type") == "system.finished":
                                # End of stream
                                break
                        except json.JSONDecodeError:
                            logger.error("Failed to decode Baidu TTS response")
                            break
        except Exception as e:
            logger.error(f"Baidu TTS WebSocket connection failed: {e}")

TTSDriverFactory.register("baidu", BaiduTTSDriver)


