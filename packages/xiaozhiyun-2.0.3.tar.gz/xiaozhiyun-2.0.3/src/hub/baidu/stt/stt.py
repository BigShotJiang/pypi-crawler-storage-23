﻿import logging
import json
import uuid
import asyncio
import websockets
import hashlib
import hmac
import base64
import time
from typing import Any, Dict, Optional, AsyncGenerator, Callable, Awaitable
from src.hub.baidu.auth import BaiduAuth

logger = logging.getLogger(__name__)

class BaiduSTTService:
    """
    Baidu Cloud Speech-to-Text (ASR) service implementation.
    Real-time recognition via WebSocket.
    Ref: https://cloud.baidu.com/doc/SPEECH/s/jlbxejt2
    """
    
    def _generate_signature(self, app_id: str, api_key: str, secret_key: str, sn: str, ts: str) -> str:
        """
        Generate signature for Baidu STT WebSocket connection
        Ref: https://cloud.baidu.com/doc/SPEECH/s/jlbxejt2
        """
        str_to_sign = f"{app_id}_{ts}_{sn}"
        h = hmac.new(secret_key.encode('utf-8'), str_to_sign.encode('utf-8'), hashlib.sha256)
        sign = base64.b64encode(h.digest()).decode('utf-8')
        return sign

    async def asr(
        self,
        audio_generator: AsyncGenerator[bytes, None],
        callback: Callable[[Dict[str, Any]], Awaitable[None]],
        credentials: Dict[str, Any]
    ) -> None:
        """
        Real-time STT via WebSocket.
        """
        app_id = credentials.get("app_id")
        api_key = credentials.get("api_key")
        secret_key = credentials.get("secret_key")
        
        if not app_id or not api_key or not secret_key:
            # Fallback to credentials from stt.json if not provided directly
            try:
                from src.config import config
                baidu_conf = config.stt.get("baidu", {
                    "app_id": "",
                    "api_key": "",
                    "secret_key": ""
                })
                app_id = app_id or baidu_conf.get("app_id")
                api_key = api_key or baidu_conf.get("api_key")
                secret_key = secret_key or baidu_conf.get("secret_key")
            except:
                pass

        if not app_id or not api_key or not secret_key:
            logger.error(f"Missing Baidu STT credentials (app_id={app_id}, api_key={'set' if api_key else 'none'}, secret_key={'set' if secret_key else 'none'})")
            await callback({"error": "Missing Baidu STT credentials"})
            return

        sn = str(uuid.uuid4())
        
        # dev_pid: 1537 (mandarin), 15372 (mandarin + punctuation)
        dev_pid = credentials.get("dev_pid", 1537)
        sample_rate = credentials.get("sample", 16000)
        format_type = credentials.get("format", "pcm")
        
        # Build WebSocket URL with authentication
        ts = str(int(time.time()))
        sign = self._generate_signature(app_id, api_key, secret_key, sn, ts)
        ws_url = f"wss://vop.baidu.com/realtime_asr?sn={sn}&appid={app_id}&ts={ts}&sign={sign}"
        
        start_payload = {
            "type": "START",
            "data": {
                "appid": int(app_id),
                "appkey": api_key,
                "dev_pid": int(dev_pid),
                "cuid": credentials.get("cuid", "deer-flow"),
                "format": format_type,
                "sample": int(sample_rate),
                "channel": 1
            }
        }
        
        logger.info(f"Baidu STT configuration: sample_rate={sample_rate}, format={format_type}, dev_pid={dev_pid}")
        logger.info(f"Using WebSocket URL: {ws_url}")

        try:
            async with websockets.connect(ws_url) as ws:
                # 1. Send START frame
                await ws.send(json.dumps(start_payload))
                
                # 2. Start sender task
                async def send_audio():
                    try:
                        chunk_count = 0
                        total_bytes = 0
                        async for chunk in audio_generator:
                            if chunk:
                                chunk_count += 1
                                total_bytes += len(chunk)
                                if chunk_count <= 3:  # Log first 3 chunks for debugging
                                    logger.info(f"Sending audio chunk {chunk_count}: {len(chunk)} bytes")
                                elif chunk_count % 10 == 0:
                                    logger.info(f"Sent {chunk_count} chunks, {total_bytes} bytes total")
                                await ws.send(chunk)
                        logger.info(f"Finished sending audio: {chunk_count} chunks, {total_bytes} bytes")
                        # Send FINISH frame
                        await ws.send(json.dumps({"type": "FINISH"}))
                        logger.info("Sent FINISH frame")
                    except Exception as e:
                        logger.error(f"Error sending audio to Baidu ASR: {e}")

                sender_task = asyncio.create_task(send_audio())

                # 3. Receive loop
                async for message in ws:
                    try:
                        resp = json.loads(message)
                        
                        # Check for error response
                        err_no = resp.get("err_no")
                        if err_no is not None and err_no != 0:
                            err_msg = resp.get("err_msg", "Unknown error")
                            logger.error(f"Baidu ASR Error: {err_msg} (code: {err_no})")
                            await callback({"error": f"{err_msg} (code: {err_no})"})
                            break
                        elif err_no is None and "error" in resp:
                            # Handle error responses without err_no
                            error_msg = resp.get("error", "Unknown error")
                            logger.error(f"Baidu ASR Error: {error_msg}")
                            await callback({"error": error_msg})
                            break
                        
                        msg_type = resp.get("type")
                        result_text = resp.get("result", "")
                        
                        # Sometimes Baidu returns an array of strings in result
                        if isinstance(result_text, list):
                            result_text = "".join(result_text)
                        
                        if msg_type in ["MID_TEXT", "FIN_TEXT"]:
                            await callback({
                                "text": result_text,
                                "is_final": msg_type == "FIN_TEXT",
                                "original": resp
                            })
                        
                    except json.JSONDecodeError:
                        logger.error("Failed to decode Baidu ASR response")
                        await callback({"error": "Failed to decode server response"})
                    except Exception as e:
                        logger.error(f"Error processing Baidu ASR message: {e}")
                        await callback({"error": f"Error processing server response: {str(e)}"})
                
                await sender_task
        except Exception as e:
            logger.error(f"Baidu STT WebSocket connection failed: {e}")
            await callback({"error": f"Connection failed: {str(e)}"})

