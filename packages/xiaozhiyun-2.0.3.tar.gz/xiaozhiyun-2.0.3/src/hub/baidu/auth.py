﻿import logging
import httpx
from typing import Dict, Any, Optional
from src.hub.common import HttpClientManager

logger = logging.getLogger(__name__)

class BaiduAuth:
    """
    Manages Baidu Cloud OAuth Tokens.
    """
    _token_cache: Dict[str, str] = {} # Dict of api_key -> token

    @classmethod
    async def get_access_token(cls, api_key: str, secret_key: str) -> Optional[str]:
        """
        Baidu OAuth 2.0 Token acquisition.
        """
        if api_key in cls._token_cache:
            return cls._token_cache[api_key]

        # If it's a V2 direct API key (Permanent Key / Token), return as is
        if api_key and api_key.startswith("bce-v3/"):
            return api_key

        try:
            url = "https://aip.baidubce.com/oauth/2.0/token"
            
            # Diagnostic logging (masked)
            key_preview = f"{api_key[:4]}...{api_key[-4:]}" if api_key else "None"
            secret_preview = f"{secret_key[:4]}...{secret_key[-4:]}" if secret_key else "None"
            logger.info(f"Baidu Auth Attempt - API Key: {key_preview} (len={len(api_key if api_key else '')}), Secret: {secret_preview}")
            
            params = {
                "grant_type": "client_credentials",
                "client_id": api_key,
                "client_secret": secret_key
            }

            client = HttpClientManager.get_client()
            resp = await client.get(url, params=params)
            data = resp.json()
            token = data.get("access_token")
            if token:
                cls._token_cache[api_key] = token
                return token
            logger.error(f"Baidu Auth failed: {resp.text}")
            return None
        except Exception as e:
            logger.error(f"Baidu Auth Exception: {str(e)}")
            return None


