﻿import logging
import json
from typing import Any, Dict
from src.hub.common import HttpClientManager, BaseImageDriver, ImageDriverFactory
from src.hub.baidu.auth import BaiduAuth

logger = logging.getLogger(__name__)

class BaiduImageDriver(BaseImageDriver):
    """
    Baidu Qianfan Image Generation Driver (V2 API).
    Reference: https://cloud.baidu.com/doc/qianfan-api/s/8m7u6un8a
    """

    def __init__(self, **kwargs):
        pass

    async def generate(
        self,
        prompt: str,
        model: str = None,
        size: str = "1024x1024",
        n: int = 1,
        **kwargs: Any
    ) -> Dict[str, Any]:
        """
        Generate image using Baidu Qianfan V2 API.
        """
        credentials = kwargs.get("credentials", {})
        api_key = credentials.get("api_key") or credentials.get("client_id") or kwargs.get("api_key")
        secret_key = credentials.get("secret_key") or credentials.get("client_secret") or kwargs.get("secret_key")

        if not api_key:
            return {"success": False, "error": "Missing Baidu API Credentials (api_key/secret_key)."}

        # Get access token
        token = await BaiduAuth.get_access_token(api_key, secret_key)
            
        if not token:
            return {"success": False, "error": "Baidu Authentication Failed."}

        # Resolution: Baidu V2 uses "1024x1024" format
        resolution = size.replace("*", "x")
        
        # Model mapping: V1 names or generic names to V2 names
        model_map = {
            "Stable-Diffusion-XL": "irag-1.0",
            "baidu": "irag-1.0"
        }
        actual_model = model_map.get(model, model) or "irag-1.0"
        
        # Prepare Payload
        payload = {
            "model": actual_model,
            "prompt": prompt,
            "n": n,
            "size": resolution
        }
        
        # Add optional parameters from metadata/kwargs
        metadata = kwargs.get("metadata", {})
        
        # Merge negative_prompt from multiple possible sources
        negative_prompt = kwargs.get("negative_prompt") or metadata.get("negative_prompt")
        if negative_prompt:
            payload["negative_prompt"] = negative_prompt
        
        # Other Qianfan specific params
        if kwargs.get("steps") or metadata.get("steps"):
            payload["steps"] = int(kwargs.get("steps") or metadata.get("steps"))
            
        if kwargs.get("seed") or metadata.get("seed"):
            payload["seed"] = int(kwargs.get("seed") or metadata.get("seed"))
            
        # Watermark
        watermark = kwargs.get("watermark")
        if watermark is None:
            watermark = metadata.get("watermark")
        if watermark is not None:
            payload["watermark"] = bool(watermark)

        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {token}"
        }

        logger.info(f"Baidu Image Gen Request: {payload['model']} - {resolution}")

        client = HttpClientManager.get_client()
        endpoint = "https://qianfan.baidubce.com/v2/images/generations"
        
        try:
            resp = await client.post(endpoint, json=payload, headers=headers, timeout=60.0)
            
            if resp.status_code != 200:
                logger.error(f"Baidu Image Gen Error: {resp.status_code} - {resp.text}")
                return {
                    "success": False, 
                    "error": f"Baidu API Error: {resp.status_code}. Raw: {resp.text}", 
                    "raw_response": resp.text
                }

            data = resp.json()
            
            # Error check (Baidu V2 returns errors in a specific format)
            if "error_code" in data:
                 return {
                    "success": False,
                    "error": f"{data.get('error_code')}: {data.get('error_msg')}",
                    "request_id": data.get("id")
                }

            images = []
            results = data.get("data", [])
            for res in results:
                if "url" in res:
                    images.append({"url": res["url"], "content_type": "image/png"})
                elif "b64_image" in res:
                    images.append({"base64": res["b64_image"], "content_type": "image/png"})

            return {
                "success": True,
                "images": images,
                "request_id": data.get("id"),
                "usage": data.get("usage", {"total_images": n})
            }

        except Exception as e:
            logger.exception("Baidu Image Gen Exception")
            return {"success": False, "error": str(e)}

ImageDriverFactory.register("baidu", BaiduImageDriver)


