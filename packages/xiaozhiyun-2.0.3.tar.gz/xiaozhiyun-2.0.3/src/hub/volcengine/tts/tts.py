﻿import logging
import json
import base64
import time
import uuid
import gzip
import gzip
import hmac
import hashlib
import websockets
from websockets.client import connect as ws_connect
from typing import Any, Dict, AsyncGenerator
from src.hub.common import HttpClientManager, BaseTTSDriver, TTSDriverFactory

logger = logging.getLogger(__name__)

class VolcengineTTSDriver(BaseTTSDriver):
    """
    Volcengine Cloud Text-to-Speech (TTS) service implementation.
    Supports REST API and WebSocket streaming.
    
    Ref: https://www.volcengine.com/docs/6561/1329505
    """
    
    async def synthesize(
        self,
        text: str,
        voice_id: str,
        speed: float = 1.0,
        volume: float = 1.0,
        **kwargs: Any
    ) -> Dict[str, Any]:
        """
        Synthesize text to speech using Volcengine TTS.
        """
        credentials = kwargs.get("credentials", {})
        # Use fields from tts.json config
        app_key = credentials.get("app_key") or kwargs.get("app_key")
        access_key_id = credentials.get("access_key_id") or kwargs.get("access_key_id")
        access_key_secret = credentials.get("access_key_secret") or kwargs.get("access_key_secret")
        
        # For backward compatibility, also check api_key and app_id
        api_key = credentials.get("api_key") or kwargs.get("api_key") or access_key_id or app_key
        app_id = credentials.get("app_id") or kwargs.get("app_id") or app_key
        
        if not api_key:
            return {"success": False, "error": "Missing Volcengine API Key"}

        url = "https://openspeech.bytedance.com/api/v1/tts"
        
        headers = {
            "Authorization": f"Bearer; {api_key}",
            "Content-Type": "application/json"
        }
        
        payload: Dict[str, Any] = {
            "app": {
                "appid": app_id,
                "token": api_key,
                "cluster": kwargs.get("cluster", "volcano_tts")
            },
            "user": {"uid": "src"},
            "audio": {
                "voice_type": voice_id,
                "encoding": kwargs.get("format", "mp3"),
                "speed_ratio": speed,
                "volume_ratio": volume,
                "pitch_ratio": 1.0
            },
            "text": text
        }
        
        client = HttpClientManager.get_client()
        try:
            resp = await client.post(url, json=payload, headers=headers)
            data = resp.json()
            
            if data.get("code") == 1000:
                audio_base64 = data.get("data")
                return {
                    "success": True,
                    "audio_content": base64.b64decode(audio_base64),
                    "format": payload["audio"]["encoding"],
                    "error": None
                }
            else:
                return {
                    "success": False,
                    "error": f"Volcengine TTS Error: {data.get('message')}"
                }
        except Exception as e:
            return {"success": False, "error": str(e)}

    async def synthesize_stream(
        self,
        text: str,
        voice_id: str,
        speed: float = 1.0,
        volume: float = 1.0,
        **kwargs: Any
    ) -> AsyncGenerator[bytes, None]:
        """
        Stream synthesized audio using Volcengine TTS WebSocket.
        Ref: https://www.volcengine.com/docs/6561/79821?lang=zh
        """
        credentials = kwargs.get("credentials", {})
        # Use fields from tts.json config
        app_key = credentials.get("app_key") or kwargs.get("app_key")
        access_key_id = credentials.get("access_key_id") or kwargs.get("access_key_id")
        access_key_secret = credentials.get("access_key_secret") or kwargs.get("access_key_secret")
        
        # For backward compatibility, also check api_key and app_id
        # In Volcengine TTS, 'token' is usually the Access Token which might be mapped to api_key
        api_key = credentials.get("api_key") or kwargs.get("api_key") or access_key_id or app_key
        app_id = credentials.get("app_id") or kwargs.get("app_id") or app_key
        cluster = credentials.get("cluster_id") or kwargs.get("cluster_id") or "volcano_tts"

        if not app_id or not api_key:
            logger.error(f"Missing Volcengine app_id ({app_id}) or token ({api_key})")
            return

        # Get required parameters
        audio_format = kwargs.get("format", "mp3")
        sample_rate = kwargs.get("sample_rate", 24000)
        language_type = kwargs.get("language_type", "Chinese")
        
        # WebSocket URL
        ws_url = "wss://openspeech.bytedance.com/api/v1/tts/ws_binary"
        
        # 1. Prepare Request Payload (Before Connection)
        reqid = str(uuid.uuid4())
        request_json = {
            "app": {
                "appid": app_id,
                "token": api_key, # Use AK as token in payload
                "cluster": cluster
            },
            "user": {
                "uid": "src"
            },
            "audio": {
                "voice_type": voice_id,
                "encoding": audio_format,
                "speed_ratio": speed,
                "volume_ratio": volume,
                "pitch_ratio": 1.0,
                "rate": sample_rate
            },
            "request": {
                "reqid": reqid,
                "text": text,
                "text_type": "plain",
                "operation": "submit"
            }
        }
        
        # Build Binary Frame
        payload_bytes = json.dumps(request_json).encode('utf-8')
        payload_bytes = gzip.compress(payload_bytes) # Compress payload
        
        header = bytearray(4)
        header[0] = 0x11 # Version 1, Header Size 1 (4 bytes)
        header[1] = 0x10 # MsgType 1 (Full Request), Flags 0
        header[2] = 0x11 # Serial 1 (JSON), Comp 1 (Gzip)
        header[3] = 0x00 # Reserved
        
        # Full frame = Header + PayloadSize(4) + Payload
        full_frame = header + len(payload_bytes).to_bytes(4, 'big') + payload_bytes

        # 2. Authentication Headers
        extra_headers = {}
        if access_key_secret:
             # Implementation of Signature Authentication (same as STT)
             logger.info(f"Using Volcengine Signature Authentication for TTS with AK: {api_key}")
             
             method = "GET"
             path = "/api/v1/tts/ws_binary"
             proto = "HTTP/1.1"
             host = "openspeech.bytedance.com"
             
             # Text to sign: <Method> <Path> <Proto>\n<Host>\n + Body
             text_to_sign_str = f"{method} {path} {proto}\n{host}\n"
             # Include full_frame in signature as it's the "request body" in this context
             text_to_sign_bytes = text_to_sign_str.encode('utf-8') + full_frame
             
             mac_signature = base64.urlsafe_b64encode(
                hmac.new(
                    access_key_secret.encode('utf-8'),
                    text_to_sign_bytes,
                    hashlib.sha256
                ).digest()
             ).decode('utf-8')
             
             extra_headers["Authorization"] = f'HMAC256; access_token="{api_key}"; mac="{mac_signature}"; h="Host"'
        else:
             # Fallback to Token Auth
             extra_headers["Authorization"] = f"Bearer; {api_key}"

        try:
            async with ws_connect(ws_url, extra_headers=extra_headers) as ws:
                logger.info(f"Sending Volcengine TTS Request: {len(full_frame)} bytes")
                await ws.send(full_frame)
                
                # 3. Receive & Process Responses
                received_bytes = 0
                async for message in ws:
                    if isinstance(message, bytes):
                        # logger.info(f"Received Volcengine TTS message: {len(message)} bytes")
                        received_bytes += len(message)
                        
                        if len(message) < 4:
                            continue
                            
                        # Parse Header
                        header = message[:4]
                        header_size = (header[0] & 0x0F) * 4
                        msg_type = (header[1] >> 4) & 0x0F
                        msg_flags = header[1] & 0x0F
                        comp_method = header[2] & 0x0F
                        
                        # Payload starts after header
                        raw_payload = message[header_size:]
                        
                        # Handle Message Types
                        if msg_type == 0xB: # Audio Only Server Response
                            if msg_flags == 0: # ACK (No sequence number)
                                continue
                            
                            if len(raw_payload) < 8:
                                continue
                                
                            # Parse Sequence and Size
                            sequence = int.from_bytes(raw_payload[:4], 'big', signed=True)
                            payload_size = int.from_bytes(raw_payload[4:8], 'big', signed=False)
                            audio_data = raw_payload[8:]
                            
                            # Handle Compression
                            if comp_method == 1: # Gzip
                                try:
                                    audio_data = gzip.decompress(audio_data)
                                except Exception as e:
                                    logger.error(f"Gzip decompress error: {e}")
                                    continue
                            
                            if audio_data:
                                yield audio_data
                                
                            if sequence < 0:
                                logger.info("Received Final Audio Frame (Seq < 0)")
                                break
                                
                        elif msg_type == 0xF: # Error Message
                            if len(raw_payload) < 8:
                                logger.error("Truncated error message")
                                break
                                
                            code = int.from_bytes(raw_payload[:4], 'big', signed=False)
                            msg_size = int.from_bytes(raw_payload[4:8], 'big', signed=False)
                            error_data = raw_payload[8:]
                            
                            if comp_method == 1:
                                try:
                                    error_data = gzip.decompress(error_data)
                                except Exception as e:
                                    logger.error(f"Error msg decompress error: {e}")
                            
                            error_msg = error_data.decode('utf-8', errors='ignore')
                            logger.error(f"Volcengine TTS Error: Code={code}, Msg={error_msg}")
                            break
                            
                        elif msg_type == 0xC: # Frontend Message (Sometimes used for final?)
                            msg_size = int.from_bytes(raw_payload[:4], 'big', signed=False)
                            frontend_msg = raw_payload[4:]
                            if comp_method == 1:
                                try:
                                    frontend_msg = gzip.decompress(frontend_msg)
                                except: pass
                            logger.info(f"Frontend Message: {frontend_msg}")
                            
                    else:
                        logger.error(f"Unexpected message type: {type(message)}")
                        
        except Exception as e:
             logger.error(f"Volcengine TTS Stream Error: {e}")
             return

    def _build_frame(self, message_type: int, event: int, payload: dict = None, session_id: str = None) -> bytes:
        """
        Build binary frame for Volcengine WebSocket protocol.
        """
        # Default values
        protocol_version = 1
        header_size = 1  # 4 bytes
        serialization_method = 1  # JSON
        compression_method = 0  # No compression
        
        # Build header
        header = bytearray(4)
        header[0] = (protocol_version << 4) | header_size
        header[1] = message_type
        header[2] = (serialization_method << 4) | compression_method
        header[3] = 0  # Reserved
        
        # Add event field
        header.extend(event.to_bytes(2, byteorder='big'))
        
        # Add connect ID size and connect ID if needed
        # For simplicity, we'll omit connect ID handling
        
        # Add session ID size and session ID if provided
        if session_id:
            session_id_bytes = session_id.encode('utf-8')
            header.extend(len(session_id_bytes).to_bytes(2, byteorder='big'))
            header.extend(session_id_bytes)
        
        # Serialize payload
        if payload:
            payload_bytes = json.dumps(payload).encode('utf-8')
        else:
            payload_bytes = b''
        
        # Add payload size
        payload_size = len(payload_bytes)
        header.extend(payload_size.to_bytes(4, byteorder='big'))
        
        # Combine header and payload
        return bytes(header) + payload_bytes
    
    def _parse_frame(self, data: bytes) -> tuple[int, bytes]:
        """
        Parse binary frame from Volcengine WebSocket protocol.
        """
        if len(data) < 4:
            return 0, b''
        
        # Parse header
        header = data[:4]
        message_type = header[1]
        
        # Calculate payload start position
        payload_start = 4
        
        # Skip event field
        if len(data) > payload_start:
            payload_start += 2
        
        # Skip session ID if present
        if len(data) > payload_start:
            session_id_size = int.from_bytes(data[payload_start:payload_start+2], byteorder='big')
            payload_start += 2 + session_id_size
        
        # Skip payload size
        if len(data) > payload_start:
            payload_start += 4
        
        # Extract payload
        if len(data) > payload_start:
            payload = data[payload_start:]
        else:
            payload = b''
        
        return message_type, payload
    
    def _is_connection_started(self, data: bytes) -> bool:
        """
        Check if connection started successfully.
        """
        try:
            message_type, payload = self._parse_frame(data)
            if message_type == 0x01:  # StartConnection
                event_data = json.loads(payload.decode('utf-8'))
                return event_data.get('type') == 'ConnectionStarted'
            return False
        except:
            return False
    
    def _build_ws_binary_frame(self, payload: dict) -> bytes:
        """
        Build binary frame according to Volcengine WebSocket protocol.
        Ref: https://www.volcengine.com/docs/6561/79821?lang=zh
        """
        # Serialize payload to JSON
        payload_json = json.dumps(payload).encode('utf-8')
        payload_size = len(payload_json)
        
        # Build header (4 bytes)
        header = bytearray(4)
        # Byte 0: Protocol version (4 bits) + Header size (4 bits)
        header[0] = (0b0001 << 4) | 0b0001  # Version 1, Header size 4 bytes
        # Byte 1: Message type (4 bits) + Message type specific flags (4 bits)
        header[1] = (0b0001 << 4) | 0b0000  # Full client request, no flags
        # Byte 2: Serialization method (4 bits) + Compression method (4 bits)
        header[2] = (0b0001 << 4) | 0b0000  # JSON serialization, no compression
        # Byte 3: Reserved
        header[3] = 0x00
        
        # Add payload size (4 bytes, big-endian)
        header.extend(payload_size.to_bytes(4, byteorder='big'))
        
        # Combine header and payload
        return bytes(header) + payload_json
    
    def _parse_ws_binary_frame(self, data: bytes) -> tuple[int, bytes]:
        """
        Parse binary frame from Volcengine WebSocket protocol.
        """
        if len(data) < 4:
            return 0, b''
        
        # Parse header
        header = data[:4]
        # Extract message type (4 bits from byte 1)
        message_type = (header[1] >> 4) & 0x0F
        
        # Calculate payload start position
        payload_start = 8  # Header (4 bytes) + Payload size (4 bytes)
        
        # Extract payload
        if len(data) > payload_start:
            payload = data[payload_start:]
        else:
            payload = b''
        
        return message_type, payload
    
    def _extract_audio_data(self, message: bytes) -> bytes:
        """
        Extract audio data from Volcengine WebSocket response.
        """
        try:
            # Skip header and payload size
            if len(message) > 8:
                return message[8:]
            return b''
        except:
            return b''
    
    def _parse_error_frame(self, data: bytes) -> dict:
        """
        Parse error frame from Volcengine WebSocket protocol.
        """
        try:
            # Analyze the error frame structure
            logger.error(f"Error frame length: {len(data)}")
            
            # Try to find JSON data in the frame
            # Look for '{' which indicates the start of JSON
            json_start = -1
            for i in range(len(data)):
                if data[i] == 0x7b:  # '{' character
                    json_start = i
                    break
            
            if json_start != -1:
                # Extract JSON data from the frame
                json_data = data[json_start:]
                try:
                    # Try to decode as JSON
                    return json.loads(json_data.decode('utf-8'))
                except json.JSONDecodeError as e:
                    # Try to decode as much as possible
                    return {"error": f"JSON decode error: {str(e)}, Raw: {json_data.decode('utf-8', errors='replace')[:200]}"}
            
            # Return detailed analysis if JSON not found
            return {
                "error": "Failed to find JSON in error frame",
                "frame_length": len(data),
                "first_20_bytes": data[:20].hex(),
                "last_20_bytes": data[-20:].hex()
            }
        except Exception as e:
            return {"error": f"Failed to parse error frame: {str(e)}"}

TTSDriverFactory.register("volcengine", VolcengineTTSDriver)



