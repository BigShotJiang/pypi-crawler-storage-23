﻿import logging
import json
from typing import Any, Dict
from src.hub.common import HttpClientManager, BaseImageDriver, ImageDriverFactory

logger = logging.getLogger(__name__)

class VolcengineImageDriver(BaseImageDriver):
    """
    Volcengine Ark (鏂硅垷) Image Generation Driver.
    Reference: https://www.volcengine.com/docs/82379/1541523
    """

    def __init__(self, **kwargs):
        pass

    async def generate(
        self,
        prompt: str,
        model: str = None,
        size: str = "1024x1024",
        n: int = 1,
        **kwargs: Any
    ) -> Dict[str, Any]:
        """
        Generate image using Volcengine Ark API.
        """
        credentials = kwargs.get("credentials", {})
        api_key = credentials.get("api_key") or kwargs.get("api_key")
        
        # Volcengine Ark usually requires a Model Endpoint ID
        model_endpoint = model or credentials.get("model_endpoint") or kwargs.get("model")
        
        if not api_key:
            return {"success": False, "error": "Missing Volcengine Ark API Key."}
            
        if not model_endpoint:
             return {"success": False, "error": "Missing Volcengine Model Endpoint ID."}

        # Resolution mapping: 
        # Volcengine supports 2K, 4K, or custom WxH.
        # If the input is like 1024*1024, convert to 1024x1024
        resolution = size.replace("*", "x")
        
        # Prepare Payload
        payload = {
            "model": model_endpoint,
            "prompt": prompt,
            "size": resolution
        }
        
        # Add optional parameters
        metadata = kwargs.get("metadata", {})
        
        # Watermark
        watermark = kwargs.get("watermark")
        if watermark is None:
            watermark = metadata.get("watermark")
        if watermark is not None:
            payload["watermark"] = bool(watermark)

        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {api_key}"
        }

        logger.info(f"Volcengine Image Gen Request: {model_endpoint} - {resolution}")

        client = HttpClientManager.get_client()
        # Note: endpoint might vary by region, but ark.cn-beijing is the common one.
        endpoint = "https://ark.cn-beijing.volces.com/api/v3/images/generations"
        
        try:
            resp = await client.post(endpoint, json=payload, headers=headers, timeout=120.0)
            
            if resp.status_code != 200:
                logger.error(f"Volcengine Image Gen Error: {resp.status_code} - {resp.text}")
                return {
                    "success": False, 
                    "error": f"Volcengine API Error: {resp.status_code}. Raw: {resp.text}", 
                    "raw_response": resp.text
                }

            data = resp.json()
            
            images = []
            results = data.get("data", [])
            for res in results:
                if "url" in res:
                    images.append({"url": res["url"], "content_type": "image/png"})
                elif "b64_json" in res:
                    images.append({"base64": res["b64_json"], "content_type": "image/png"})

            return {
                "success": True,
                "images": images,
                "request_id": data.get("id"),
                "usage": data.get("usage", {"total_images": n})
            }

        except Exception as e:
            logger.exception("Volcengine Image Gen Exception")
            return {"success": False, "error": str(e)}

ImageDriverFactory.register("volcengine", VolcengineImageDriver)


