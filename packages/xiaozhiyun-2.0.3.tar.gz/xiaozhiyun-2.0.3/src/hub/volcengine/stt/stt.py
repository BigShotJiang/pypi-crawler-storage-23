﻿import logging
import json
import uuid
import asyncio
import websockets
from websockets.client import connect as ws_connect
import hmac
import hashlib
import time
import base64
from urllib.parse import urlparse
from typing import Any, Dict, AsyncGenerator, Callable, Awaitable

logger = logging.getLogger(__name__)

class VolcengineSTTService:
    """
    Volcengine Cloud Speech-to-Text (ASR) service implementation.
    Real-time recognition via WebSocket.
    Ref: https://www.volcengine.com/docs/6561/80818?lang=zh
    """
    
    async def asr(
        self,
        audio_generator: AsyncGenerator[bytes, None],
        callback: Callable[[Dict[str, Any]], Awaitable[None]],
        credentials: Dict[str, Any]
    ) -> None:
        """
        Real-time STT via WebSocket.
        """
        # Get credentials
        app_id = credentials.get("app_id") or credentials.get("app_key")
        token = credentials.get("access_token") or credentials.get("token") or credentials.get("api_key") or credentials.get("access_key_id")
        secret_key = credentials.get("secret_key") or credentials.get("access_key_secret")
        cluster_id = credentials.get("cluster_id", "volcano_asr")
        uid = credentials.get("uid", "src")
        workflow = credentials.get("workflow", "audio_in,resample,partition,vad,fe,decode")
        
        if not app_id:
            logger.error("Missing Volcengine App ID")
            await callback({"error": "Missing Volcengine STT App ID"})
            return

        # Get audio parameters
        sample_rate = int(credentials.get("sample", 16000))
        audio_format = credentials.get("format", "pcm")
        # Map pcm to raw as per Volcengine docs
        if audio_format.lower() == "pcm":
            audio_format = "raw"
        
        # WebSocket URL
        ws_url = "wss://openspeech.bytedance.com/api/v2/asr"
        
        # 1. Build full client request (Required for Signature calculation)
        reqid = str(uuid.uuid4())
        full_request = self._build_full_client_request(
            app_id=app_id,
            token=token,
            cluster_id=cluster_id,
            uid=uid,
            workflow=workflow,
            reqid=reqid,
            sample_rate=sample_rate,
            audio_format=audio_format
        )

        # 2. Prepare headers with Authentication
        extra_headers = {}
        
        if secret_key: 
            # Use Signature Authentication (HMAC256)
            # Ref: https://www.volcengine.com/docs/6561/107789?lang=zh
            # AND strictly follow streaming_asr_demo.py logic
            logger.info(f"Using Volcengine Signature Authentication with AK: {token}")
            
            # 1. Prepare Text to Sign
            # Format: <Method> <Path> <Proto>\n<HeaderValue1>\n...<Body>
            # NOTE: Official demo shows checking header VALUES only, not "Key: Value".
            
            method = "GET"
            path = "/api/v2/asr"
            proto = "HTTP/1.1"
            host = "openspeech.bytedance.com"
            
            # Text to sign: GET /api/v2/asr HTTP/1.1\nopenspeech.bytedance.com\n
            text_to_sign_str = f"{method} {path} {proto}\n{host}\n"
            text_to_sign_bytes = text_to_sign_str.encode('utf-8') + full_request
            
            # 2. Calculate MAC
            # Use urlsafe_b64encode as per demo and docs
            mac_signature = base64.urlsafe_b64encode(
                hmac.new(
                    secret_key.encode('utf-8'),
                    text_to_sign_bytes,
                    hashlib.sha256
                ).digest()
            ).decode('utf-8')
            
            # 3. Construct Auth Header
            # Header format: HMAC256; access_token="{AK}"; mac="{MAC}"; h="Host"
            auth_header = f'HMAC256; access_token="{token}"; mac="{mac_signature}"; h="Host"'
            
        else:
            # Fallback to Token Authentication (Bearer)
            # This requires a pre-generated token (STS or long-lived token) matching the App ID
            if not token:
                 logger.error("Missing Volcengine Token/AK")
                 await callback({"error": "Missing Volcengine Credentials"})
                 return
                 
            logger.info("Using Volcengine Token Authentication")
            auth_header = token
            if not auth_header.startswith("Bearer;"):
                auth_header = f"Bearer; {token}"
            
        extra_headers = {
            "Authorization": auth_header
        }
        
        try:
            # Explicitly using websockets.client.connect (aliased as ws_connect) to support extra_headers
            async with ws_connect(ws_url, extra_headers=extra_headers) as ws:
                # 3. Send full client request (already built)
                await ws.send(full_request)
                logger.info(f"Sent full client request with reqid: {reqid}")
                
                # 4. Start sender task
                async def send_audio():
                    try:
                        sequence = 1
                        audio_count = 0
                        async for chunk in audio_generator:
                            if chunk:
                                audio_count += 1
                                logger.info(f"Sending audio chunk #{audio_count}: {len(chunk)} bytes")
                                audio_frame = self._build_audio_request(chunk, sequence)
                                await ws.send(audio_frame)
                                sequence += 1
                        # Send final audio frame with sequence as negative
                        logger.info(f"Sending final audio frame, total chunks: {audio_count}")
                        final_frame = self._build_audio_request(b"", -sequence)
                        await ws.send(final_frame)
                    except Exception as e:
                        logger.error(f"Error sending audio: {e}")
                
                sender_task = asyncio.create_task(send_audio())
                
                # 3. Receive response
                async def receive_response():
                    try:
                        async for message in ws:
                            if isinstance(message, bytes):
                                try:
                                    logger.info(f"Received response from server: {len(message)} bytes")
                                    response = self._parse_server_response(message)
                                    if response:
                                        logger.info(f"Parsed response: {response}")
                                        await callback(response)
                                except Exception as e:
                                    logger.error(f"Error parsing response: {e}")
                    except Exception as e:
                        logger.error(f"Error receiving response: {e}")
                
                # Start receiver task
                receiver_task = asyncio.create_task(receive_response())
                
                # Wait for sender task to complete
                await sender_task
                
                # Wait for receiver task to complete (give server time to respond)
                try:
                    # Wait up to 10 seconds for final response
                    await asyncio.wait_for(receiver_task, timeout=10.0)
                except asyncio.TimeoutError:
                    logger.info("Receiver task timeout, closing connection")
                except Exception as e:
                    logger.error(f"Error waiting for receiver task: {e}")
        except Exception as e:
            logger.error(f"Volcengine STT WebSocket error: {e}")
            await callback({"error": f"Connection failed: {str(e)}"})
    
    def _build_full_client_request(
        self,
        app_id: str,
        token: str,
        cluster_id: str,
        uid: str,
        workflow: str,
        reqid: str,
        sample_rate: int,
        audio_format: str
    ) -> bytes:
        """
        Build full client request frame.
        """
        payload = {
            "app": {
                "appid": app_id,
                "token": token,
                "cluster": cluster_id
            },
            "user": {
                "uid": uid,
                "device": "src Client",
                "platform": "Web"
            },
            "audio": {
                "format": audio_format,
                "codec": "raw", # Assuming raw PCM for now if format is raw
                "rate": sample_rate,
                "bits": 16,
                "channel": 1
            },
            "request": {
                "reqid": reqid,
                "workflow": workflow,
                "sequence": 1,
                "nbest": 1,
                "result_type": "continuous",
                "show_utterances": True,
                "vad": True,
                "vad_start_timeout": 5000,
                "vad_end_timeout": 2000
            }
        }
        
        payload_json = json.dumps(payload).encode('utf-8')
        payload_size = len(payload_json)
        
        # Build header
        header = bytearray(4)
        header[0] = (0b0001 << 4) | 0b0001  # Version 1, Header size 4
        header[1] = (0b0001 << 4) | 0b0000  # Full client request
        header[2] = (0b0001 << 4) | 0b0000  # JSON serialization, no compression
        header[3] = 0x00  # Reserved
        
        # Add payload size
        header.extend(payload_size.to_bytes(4, byteorder='big'))
        
        return bytes(header) + payload_json
    
    def _build_audio_request(self, audio_data: bytes, sequence: int) -> bytes:
        """
        Build audio only request frame.
        """
        # Build header
        header = bytearray(4)
        header[0] = (0b0001 << 4) | 0b0001  # Version 1, Header size 4
        
        # Set message type and flags
        if sequence < 0:
            # Final audio frame
            header[1] = (0b0010 << 4) | 0b0010  # Audio only request, final
        else:
            # Normal audio frame
            header[1] = (0b0010 << 4) | 0b0000  # Audio only request, not final
        
        header[2] = (0b0000 << 4) | 0b0000  # No serialization, no compression
        header[3] = 0x00  # Reserved
        
        # Add payload size
        payload_size = len(audio_data)
        header.extend(payload_size.to_bytes(4, byteorder='big'))
        
        return bytes(header) + audio_data
    
    def _parse_server_response(self, data: bytes) -> Dict[str, Any]:
        """
        Parse server response frame.
        Ref: https://www.volcengine.com/docs/6561/80818?lang=zh
        """
        if len(data) < 4:
            logger.info(f"Response too short for header: {len(data)} bytes")
            return {}
        
        # Parse header
        header = data[:4]
        protocol_version = (header[0] >> 4) & 0x0F
        header_size = (header[0] & 0x0F) * 4
        message_type = (header[1] >> 4) & 0x0F
        message_flags = header[1] & 0x0F
        serialization = (header[2] >> 4) & 0x0F
        compression = header[2] & 0x0F
        
        logger.info(f"Protocol: v{protocol_version}, Header size: {header_size}, Type: {message_type}, Flags: {message_flags}, Serial: {serialization}, Comp: {compression}")
        
        # Calculate where the payload starts (after header)
        # Note: The 'header_size' field in protocol is just the header size.
        # But some message types have extra fields before the actual payload content.
        
        current_pos = header_size
        
        # Handle error message (Type 0x0F)
        if message_type == 0x0F:
            # Format: Header(4) + ErrorCode(4) + ErrorSize(4) + ErrorMessage(N)
            if len(data) < current_pos + 8:
                logger.error(f"Error message too short: {len(data)}")
                return {"error": "Volcengine STT Error: Truncated error message"}
            
            error_code = int.from_bytes(data[current_pos:current_pos+4], byteorder='big')
            current_pos += 4
            
            error_size = int.from_bytes(data[current_pos:current_pos+4], byteorder='big')
            current_pos += 4
            
            if len(data) < current_pos + error_size:
                logger.error(f"Error message payload truncated. Expected {error_size}, got {len(data) - current_pos}")
                return {"error": "Volcengine STT Error: Truncated error payload", "code": error_code}
            
            error_msg_bytes = data[current_pos:current_pos+error_size]
            try:
                error_msg = error_msg_bytes.decode('utf-8')
                logger.error(f"Received error message: {error_msg}, Code: {error_code}")
                # Try to parse as JSON if it looks like JSON
                try:
                    error_json = json.loads(error_msg)
                    return {
                        "error": f"Volcengine STT Error: {error_json.get('message', error_msg)}",
                        "code": error_code,
                        "original": error_json
                    }
                except json.JSONDecodeError:
                    return {"error": f"Volcengine STT Error: {error_msg}", "code": error_code}
            except Exception as e:
                logger.error(f"Failed to decode error message: {e}")
                return {"error": f"Failed to decode error message: {e}", "code": error_code}

        # Handle full server response (Type 0x09)
        elif message_type == 0x09:
            # Format: Header(4) + PayloadSize(4) + Payload(N)
            if len(data) < current_pos + 4:
                logger.error(f"Server response too short: {len(data)}")
                return {}
                
            payload_size = int.from_bytes(data[current_pos:current_pos+4], byteorder='big')
            current_pos += 4
            
            if len(data) < current_pos + payload_size:
                logger.error(f"Payload truncated. Expected {payload_size}, got {len(data) - current_pos}")
                return {}
                
            payload = data[current_pos:current_pos+payload_size]
            
            # Decompress if needed
            if compression == 1: # Gzip
                try:
                    import gzip
                    payload = gzip.decompress(payload)
                except Exception as e:
                    logger.error(f"Failed to decompress payload: {e}")
                    return {"error": f"Decompression failed: {e}"}
            
            # Deserialize
            if serialization == 1: # JSON
                try:
                    payload_str = payload.decode('utf-8')
                    logger.info(f"Server response payload: {payload_str}")
                    response = json.loads(payload_str)
                    
                    # Extract recognition result
                    if "result" in response:
                        result_data = response.get("result")
                        text = ""
                        if isinstance(result_data, dict):
                            text = result_data.get("text", "")
                        elif isinstance(result_data, list) and len(result_data) > 0:
                            # Result is a list of objects, usually the first one is the best candidate
                            item = result_data[0]
                            if isinstance(item, dict):
                                text = item.get("text", "")
                        
                        return {
                            "text": text,
                            "is_final": response.get("sequence", 0) < 0,
                            "confidence": response.get("confidence"),
                            "original": response
                        }
                    # Also check for top-level result text if structure differs
                    elif "text" in response:
                         return {
                            "text": response["text"],
                            "is_final": True,
                            "original": response
                        }
                    else:
                         # Handle list result from doc
                         # result: [{text: "...", utterances: [...]}]
                         res_list = response.get("result", [])
                         text = ""
                         if isinstance(res_list, list) and len(res_list) > 0:
                             text = res_list[0].get("text", "")
                         
                         return {
                            "text": text,
                            "is_final": response.get("sequence", 0) < 0,
                            "original": response
                        }

                except json.JSONDecodeError as e:
                    logger.error(f"Failed to parse response JSON: {e}")
                    return {"error": f"Failed to parse response: {e}"}
            else:
                logger.info(f"Unsupported serialization: {serialization}")
                return {}
        
        # Handle other message types
        else:
            logger.info(f"Unhandled message type: {message_type}")
            return {}

