﻿import logging
import os
from typing import Dict, Any, Optional

logger = logging.getLogger(__name__)


class VolcengineAuth:
    """
    Manages Volcengine (ByteDance) authentication.
    
    Volcengine TTS uses a simple Bearer Token, no signature required.
    The token is provided directly in the API call.
    """
    
    @staticmethod
    def get_auth_headers(access_token: str) -> Dict[str, str]:
        """
        Returns authorization headers for Volcengine API calls.
        
        Args:
            access_token: The access token from Volcengine console.
            
        Returns:
            Headers dict with Authorization.
        """
        return {
            "Authorization": f"Bearer;{access_token}"
        }
    
    @staticmethod
    def get_request_body(
        appid: str,
        access_token: str,
        cluster: str,
        text: str,
        voice_type: str = "BV700_V2_streaming",
        encoding: str = "mp3",
        speed_ratio: float = 1.0,
        volume_ratio: float = 1.0,
        pitch_ratio: float = 1.0,
        uid: str = None,
        reqid: str = None
    ) -> Dict[str, Any]:
        """
        Constructs the standard request body for Volcengine TTS.
        """
        import uuid
        return {
            "app": {
                "appid": appid,
                "token": access_token,
                "cluster": cluster
            },
            "user": {
                "uid": uid or str(uuid.uuid4())
            },
            "audio": {
                "voice_type": voice_type,
                "encoding": encoding,
                "speed_ratio": speed_ratio,
                "volume_ratio": volume_ratio,
                "pitch_ratio": pitch_ratio,
            },
            "request": {
                "reqid": reqid or str(uuid.uuid4()),
                "text": text,
                "text_type": "plain",
                "operation": "query",
            }
        }


