﻿"""
WebSocket Service for Real-time TTS
"""
import logging
import asyncio
import json
from typing import AsyncGenerator, Callable, Any
from fastapi import WebSocket, WebSocketDisconnect

logger = logging.getLogger(__name__)

class TTSWebSocketService:
    def __init__(self):
        self.tts_service = None

    async def handle_connection(self, websocket: WebSocket, credentials: dict = None):
        """
        Handle the full lifecycle of a WebSocket TTS connection.
        """
        await websocket.accept()
        logger.info("TTS WebSocket connected")
        logger.info("TTS WebSocket processing session")
        
        try:
             # Retrieve TTS configuration
            from src.config import config
            tts_config = config.tts
            default_provider = tts_config.get("default", "aliyun")
            
            if credentials is None:
                credentials = {}
            
            # Flatten mate_data if present (handling endpoints that nest extra data)
            if "mate_data" in credentials and isinstance(credentials["mate_data"], dict):
                mate_data = credentials.pop("mate_data")
                credentials.update(mate_data)

            # Determine provider: base_url > credentials > config default
            provider = credentials.get("provider") 
            base_url = credentials.get("base_url")

            if base_url:
                 # Infer provider from base_url check against config
                 for key, conf in tts_config.items():
                     if isinstance(conf, dict) and "base_url_indicator" in conf:
                         indicator = conf["base_url_indicator"]
                         if indicator and indicator in base_url:
                             provider = key
                             break
            
            if not provider:
                 provider = default_provider
            
            provider_classes = {}
            for key, val in tts_config.items():
                if isinstance(val, dict) and "class" in val:
                    full_class_path = val["class"]
                    if full_class_path and "." in full_class_path:
                        module_path, class_name = full_class_path.rsplit(".", 1)
                        provider_classes[key] = (module_path, class_name)
            
            if provider not in provider_classes:
                 # Standardize error handling if provider config is missing
                 logger.error(f"TTS Config Error: Provider '{provider}' not found or missing 'class' definition in tts.json")
                 await websocket.send_json({"error": f"Configuration error: Provider '{provider}' not available"})
                 return

            module_path, class_name = provider_classes[provider]
            
            try:
                import importlib
                module = importlib.import_module(module_path)
                ServiceClass = getattr(module, class_name)
                self.tts_service = ServiceClass()
            except ImportError as e:
                logger.error(f"Failed to import TTS driver for {provider}: {e}")
                await websocket.send_json({"error": f"Failed to load {provider} driver."})
                return
            
            # Enrich credentials from config
            provider_config = tts_config.get(provider, {})
            # 1. Copy config
            for key, value in provider_config.items():
                if key not in credentials or not credentials[key]:
                    credentials[key] = value
            # 2. Map credentials
            credential_map = provider_config.get("credential_map", {})
            for config_key, driver_key in credential_map.items():
                if credentials.get(config_key) and not credentials.get(driver_key):
                    credentials[driver_key] = credentials.get(config_key)
            
            # 3. 浠庨厤缃鍙栧繀闇€瀛楁骞堕獙璇?
            required_fields = provider_config.get("required_fields", [])
            missing_fields = []
            
            for field in required_fields:
                # 鏀寔澶氫釜瀛楁鍚嶇殑鍒悕妫€鏌?(鐢?/ 鍒嗛殧)
                field_names = field.split("/") if "/" in field else [field]
                has_field = any(credentials.get(f) for f in field_names)
                if not has_field:
                    missing_fields.append(field)

            if missing_fields:
                error_msg = f"Missing required credentials for TTS: {', '.join(missing_fields)}"
                logger.error(error_msg)
                await websocket.send_json({"error": error_msg})
                return
            
            
            # 4. 浠庨厤缃鍙栭粯璁ゅ弬鏁?
            default_params = provider_config.get("default_params", {})

            # --- Main Loop ---
            while True:
                message = await websocket.receive_text()
                try:
                    data = json.loads(message)
                except:
                    data = {"text": message} # Treat raw text as simple synthesis request
                
                text = data.get("text")
                if not text:
                    continue
                
                # 鍙傛暟浼樺厛绾? 璇锋眰 > credentials (mate_data) > config default_params
                voice = data.get("voice") or credentials.get("voice") or default_params.get("voice")
                scenario = data.get("scenario") or credentials.get("scenario") or default_params.get("scenario")
                audio_format = data.get("format") or credentials.get("format") or default_params.get("format", "mp3")
                sample_rate = data.get("sample_rate") or credentials.get("sample_rate") or default_params.get("sample_rate", 24000)
                language_type = data.get("language_type") or credentials.get("language_type") or default_params.get("language_type")
                region = data.get("region") or credentials.get("region_id") or credentials.get("region") or default_params.get("region")
                model = data.get("model") or credentials.get("model") or default_params.get("model")
                
                # Check stream capability
                if hasattr(self.tts_service, 'synthesize_stream'):
                    async for chunk in self.tts_service.synthesize_stream(
                        text, 
                        voice, 
                        scenario=scenario,
                        format=audio_format, 
                        sample_rate=sample_rate,
                        language_type=language_type,
                        region=region,
                        model=model,
                        credentials=credentials
                    ):
                        await websocket.send_bytes(chunk)
                    # Send end marker
                    await websocket.send_json({"type": "finish"})
                else:
                     # Fallback to non-streaming (get full audio and send)
                     # Adapting non-streaming to socket
                     pass

        except WebSocketDisconnect:
            logger.info("TTS WebSocket disconnected")
        except asyncio.CancelledError:
            logger.info("TTS WebSocket task cancelled (client disconnected)")
        except Exception as e:
            logger.error(f"TTS WebSocket error: {e}")
            try:
                await websocket.send_json({"error": str(e)})
            except:
                pass
        finally:
            try:
                 await websocket.close()
            except:
                 pass

