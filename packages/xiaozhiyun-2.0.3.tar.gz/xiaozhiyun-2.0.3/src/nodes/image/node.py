﻿import logging
from typing import Dict, Any, Optional
from src.hub.common import ImageDriverFactory

# Import Drivers to ensure registration
try:
    from src.hub.aliyun.image.image import AliyunImageDriver
    ImageDriverFactory.register("aliyun", AliyunImageDriver)
    ImageDriverFactory.register("tongyi", AliyunImageDriver)
except ImportError:
    pass

try:
    from src.hub.baidu.image.image import BaiduImageDriver
    ImageDriverFactory.register("baidu", BaiduImageDriver)
    ImageDriverFactory.register("wenxin", BaiduImageDriver)
except ImportError:
    pass

try:
    from src.hub.tencent.image.image import TencentImageDriver
    ImageDriverFactory.register("tencent", TencentImageDriver)
    ImageDriverFactory.register("hunyuan", TencentImageDriver)
except ImportError:
    pass

try:
    from src.hub.volcengine.image.image import VolcengineImageDriver
    ImageDriverFactory.register("volcengine", VolcengineImageDriver)
    ImageDriverFactory.register("doubao", VolcengineImageDriver)
except ImportError:
    pass

logger = logging.getLogger(__name__)

async def process(state: Dict[str, Any]) -> Dict[str, Any]:
    """
    Unified Image Generation Processor.
    """
    inputs = state.get("inputs", {})
    # Fallback to state root if inputs not separated
    if not inputs or not isinstance(inputs, dict):
        inputs = state
        
    provider = inputs.get("provider", "aliyun")
    logger.info(f"Image Generation Process: Provider={provider}")
    
    try:
        # Initialize Driver
        # Pass inputs as kwargs for driver initialization (credentials, config, etc.)
        driver = ImageDriverFactory.get_driver(provider, **inputs)
        
        # Execute Generation
        result = await driver.generate(**inputs)
        
        if result.get("success"):
             # 鏋勫缓缁熶竴鐨勫搷搴斿璞★紙涓嶅寘鍚?usage锛?
             response = {
                 "images": result.get("images", []),
                 "status": "completed",
                 "error": None,
                 # 淇濈暀鍘熷 API 鍝嶅簲鐨勫叾浠栧瓧娈碉紙鎺掗櫎 usage 鍜?success锛?
                 **{k: v for k, v in result.items() 
                    if k not in ["images", "status", "error", "usage", "success"]}
             }
             return {
                 "response": response,
                 "usage": result.get("usage", {})  # usage 鐙珛杩斿洖
             }
        else:
             logger.error(f"Image Generation Error: {result.get('error')}")
             response = {
                 "status": "failed",
                 "error": result.get("error", "Unknown provider error"),
                 "images": [],
                 # 淇濈暀鍘熷閿欒鍝嶅簲鐨勫叾浠栧瓧娈碉紙鎺掗櫎 usage 鍜?success锛?
                 **{k: v for k, v in result.items() 
                    if k not in ["status", "error", "images", "usage", "success"]}
             }
             return {
                 "response": response,
                 "usage": {}  # 澶辫触鏃惰繑鍥炵┖鐨?usage
             }
             
    except Exception as e:
        logger.exception(f"Image Node Process Exception: {str(e)}")
        response = {
            "status": "failed",
            "error": f"Process exception: {str(e)}",
            "images": []
        }
        return {
            "response": response,
            "usage": {}  # 寮傚父鏃惰繑鍥炵┖鐨?usage
        }

async def extra_usage(state: Dict[str, Any]) -> Dict[str, Any]:
    """
    Return usage stats for accounting/saving.
    """
    # Simply return the usage dict accumulated in state
    return state.get("usage", {})

