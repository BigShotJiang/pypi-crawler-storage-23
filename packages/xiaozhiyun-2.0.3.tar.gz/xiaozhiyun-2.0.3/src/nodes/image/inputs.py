﻿from typing import TypedDict, List, Any, Optional, Dict, Union

class ImageInputs(TypedDict, total=False):
    prompt:str
    model:str
    negative_prompt:str #鍙嶅悜鎻愮ず璇嶏紝鐢ㄤ簬鎻忚堪涓嶅笇鏈涘湪鍥惧儚涓嚭鐜扮殑鍐呭锛屽鐢婚潰杩涜闄愬埗銆?
    watermark:bool #鏄惁娣诲姞姘村嵃
    prompt_extend:bool #鏄惁寮€鍚痯rompt鏅鸿兘鏀瑰啓 榛樿寮€鍚櫤鑳芥敼鍐?
    

    n: int #1-10 榛樿 1
    size: str   #榛樿杈撳嚭鍒嗚鲸鐜囦负1024x1024锛屽缓璁緭鍑哄垎杈ㄧ巼涓猴細
                #路 閫傜敤澶村儚锛?["768x768", "1024x1024", "1536x1536", "2048x2048"]
                #路 閫傜敤鏂囩珷閰嶅浘 锛歔"1024x768", "2048x1536"]
                #路 閫傜敤娴锋姤浼犲崟锛歔"768x1024", "1536x2048"]
                #路 閫傜敤鐢佃剳澹佺焊锛歔"1024x576", "2048x1152"]
                #路 閫傜敤娴锋姤浼犲崟锛歔"576x1024", "1152x2048"]


