﻿# Image Generation Node

鍥剧墖鐢熸垚鑺傜偣锛屾敮鎸佸涓簯鏈嶅姟鎻愪緵鍟嗙殑 AI 鍥剧墖鐢熸垚鍔熻兘銆?

## 鍔熻兘姒傝堪

璇ヨ妭鐐规彁渚涗簡缁熶竴鐨勬帴鍙ｆ潵璋冪敤涓嶅悓浜戞湇鍔″晢鐨勫浘鐗囩敓鎴?API锛屾敮鎸佹枃鏈埌鍥剧墖锛圱ext-to-Image锛夌殑鐢熸垚鍔熻兘銆?

## 鏀寔鐨勬彁渚涘晢

- **闃块噷浜戦€氫箟涓囩浉** (tongyi/aliyun)
- **鐧惧害鏂囧績涓€鏍?* (baidu)
- **鑵捐娣峰厓** (tencent)
- **鐏北寮曟搸** (volcengine)
- **璁鏄熺伀** (xfyun)
- **闃惰穬鏄熻景** (stepfun)
- **OpenAI DALL-E** (chatgpt)

## 鏍稿績缁勪欢

### 1. ImageNode (node.py)

涓昏鐨勫浘鐗囩敓鎴愯妭鐐癸紝璐熻矗锛?

- 鍒濆鍖栭厤缃?
- 璋冪敤瀵瑰簲鐨勯┍鍔ㄧ▼搴?
- 澶勭悊鐢熸垚缁撴灉
- 缁熻浣跨敤鎯呭喌

### 2. ImageState (state.py)

鐘舵€佺鐞嗭紝鍖呭惈锛?

```python
class ImageState(TypedDict):
    inputs: ImageInputs          # 杈撳叆鍙傛暟
    provider: str                # 鎻愪緵鍟嗗悕绉?
    response: Optional[Dict]     # 鍝嶅簲缁撴灉
    usage: Optional[dict]        # 浣跨敤缁熻
```

#### ImageInputs 缁撴瀯

```python
class ImageInputs(TypedDict):
    prompt: str                  # 鍥剧墖鎻忚堪锛堝繀闇€锛?
    model: str                   # 妯″瀷鍚嶇О
    n: int                       # 鐢熸垚鏁伴噺 (1-4)
    size: str                    # 鍥剧墖灏哄 (濡?"1024*1024")
    negative_prompt: Optional[str]  # 璐熼潰鎻愮ず璇?
    provider: str                # 鎻愪緵鍟?
    api_key: str                 # API 瀵嗛挜
    credentials: dict            # 鍑瘉淇℃伅
```

### 3. 鍝嶅簲鏍煎紡

#### 鎴愬姛鍝嶅簲

```python
{
    "status": "success",
    "images": [
        {
            "url": "https://...",           # 鍥剧墖 URL锛堟煇浜涙彁渚涘晢锛?
            "base64": "iVBORw0KGgo...",     # Base64 缂栫爜锛堟煇浜涙彁渚涘晢锛?
            "content_type": "image/png"     # MIME 绫诲瀷
        }
    ],
    "usage": {
        "image_count": 1
    }
}
```

#### 澶辫触鍝嶅簲

```python
{
    "status": "failed",
    "error": "閿欒淇℃伅"
}
```

## 浣跨敤鏂规硶

### 鍩烘湰鐢ㄦ硶

```python
from src.nodes.image import process

# 鍑嗗鐘舵€?
state = {
    "inputs": {
        "prompt": "涓€鍙彲鐖辩殑鐚挭鍦ㄨ姳鍥噷鐜╄€?,
        "model": "wanx2.0-t2i-turbo",
        "n": 1,
        "size": "1024*1024",
        "provider": "tongyi",
        "api_key": "your-api-key",
        "credentials": {
            "api_key": "your-api-key"
        }
    },
    "provider": "tongyi"
}

# 璋冪敤鑺傜偣
result = await process(state)

# 鑾峰彇缁撴灉
if result["response"]["status"] == "success":
    images = result["response"]["images"]
    for img in images:
        print(f"Image URL: {img.get('url')}")
```

### 楂樼骇鐢ㄦ硶

```python
# 浣跨敤璐熼潰鎻愮ず璇?
state = {
    "inputs": {
        "prompt": "缇庝附鐨勯鏅敾",
        "negative_prompt": "浜虹墿, 寤虹瓚鐗?,
        "model": "stable-diffusion-xl",
        "n": 2,
        "size": "1024*768",
        "provider": "baidu",
        "api_key": "your-api-key",
        "credentials": {
            "api_key": "your-api-key",
            "secret_key": "your-secret-key"
        }
    },
    "provider": "baidu"
}

result = await process(state)
```

## 鍥剧墖灏哄鏀寔

涓嶅悓鎻愪緵鍟嗘敮鎸佺殑灏哄鍙兘涓嶅悓锛屽父瑙佸昂瀵革細

- `512*512` - 灏忓昂瀵告鏂瑰舰
- `768*768` - 涓瓑灏哄姝ｆ柟褰?
- `1024*1024` - 澶у昂瀵告鏂瑰舰
- `1024*768` - 妯悜鐭╁舰
- `768*1024` - 绾靛悜鐭╁舰

## 閿欒澶勭悊

鑺傜偣浼氭崟鑾峰苟澶勭悊浠ヤ笅閿欒锛?

1. **閰嶇疆閿欒** - 缂哄皯蹇呴渶鍙傛暟
2. **API 閿欒** - 鎻愪緵鍟?API 璋冪敤澶辫触
3. **缃戠粶閿欒** - 杩炴帴瓒呮椂鎴栫綉缁滈棶棰?
4. **璁よ瘉閿欒** - API 瀵嗛挜鏃犳晥

閿欒淇℃伅浼氬湪 `response.error` 瀛楁涓繑鍥炪€?

## 浣跨敤缁熻

鑺傜偣浼氳嚜鍔ㄧ粺璁′娇鐢ㄦ儏鍐碉細

```python
{
    "usage": {
        "image_count": 2  # 鎴愬姛鐢熸垚鐨勫浘鐗囨暟閲?
    }
}
```

## 宸ヤ綔娴侀泦鎴?

鍦?LangGraph 宸ヤ綔娴佷腑浣跨敤锛?

```python
from langgraph.graph import StateGraph
from src.nodes.image import process, extra_usage

# 鍒涘缓宸ヤ綔娴?
workflow = StateGraph(ImageState)

# 娣诲姞鑺傜偣
workflow.add_node("generate", process)
workflow.add_node("usage", extra_usage)

# 瀹氫箟娴佺▼
workflow.add_edge(START, "generate")
workflow.add_edge("generate", "usage")
workflow.add_edge("usage", END)

# 缂栬瘧
app = workflow.compile()
```

## 鏈€浣冲疄璺?

### 1. 鎻愮ず璇嶄紭鍖?

```python
# 鉁?濂界殑鎻愮ず璇?
"涓€鍙鑹茬殑鐚挭鍧愬湪绐楀彴涓婏紝闃冲厜娲掑湪瀹冪殑姣涘彂涓婏紝鑳屾櫙鏄ā绯婄殑鑺卞洯"

# 鉂?涓嶅ソ鐨勬彁绀鸿瘝
"鐚?
```

### 2. 浣跨敤璐熼潰鎻愮ず璇?

```python
inputs = {
    "prompt": "缇庝附鐨勯鏅敾锛屽北宸濇渤娴?,
    "negative_prompt": "浜虹墿, 寤虹瓚鐗? 鏂囧瓧, 姘村嵃",  # 鎺掗櫎涓嶆兂瑕佺殑鍏冪礌
    ...
}
```

### 3. 閫夋嫨鍚堥€傜殑灏哄

```python
# 绀句氦濯掍綋鍒嗕韩
size = "1024*1024"  # 姝ｆ柟褰?

# 妯箙骞垮憡
size = "1024*768"   # 妯悜

# 鎵嬫満澹佺焊
size = "768*1024"   # 绾靛悜
```

### 4. 鎵归噺鐢熸垚

```python
inputs = {
    "prompt": "鍚屼竴涓婚鐨勫涓彉浣?,
    "n": 4,  # 涓€娆＄敓鎴?4 寮?
    ...
}
```

## 鎬ц兘浼樺寲

### 1. 寮傛澶勭悊

鎵€鏈夐┍鍔ㄧ▼搴忛兘鏀寔寮傛鎿嶄綔锛?

```python
# 骞跺彂鐢熸垚澶氫釜鍥剧墖
tasks = [
    process(state1),
    process(state2),
    process(state3)
]
results = await asyncio.gather(*tasks)
```

### 2. 缁撴灉缂撳瓨

瀵逛簬鐩稿悓鐨勬彁绀鸿瘝锛屽彲浠ョ紦瀛樼粨鏋滀互鎻愰珮鎬ц兘銆?

### 3. 瓒呮椂璁剧疆

```python
# 鍦ㄩ┍鍔ㄧ▼搴忎腑璁剧疆鍚堢悊鐨勮秴鏃舵椂闂?
# 鍥剧墖鐢熸垚閫氬父闇€瑕?5-30 绉?
```

## 鏁呴殰鎺掓煡

### 甯歌闂

1. **"Invalid API Key"**
   - 妫€鏌?API 瀵嗛挜鏄惁姝ｇ‘
   - 纭瀵嗛挜鏄惁宸叉縺娲?

2. **"Model not found"**
   - 纭妯″瀷鍚嶇О鏄惁姝ｇ‘
   - 妫€鏌ユ彁渚涘晢鏄惁鏀寔璇ユā鍨?

3. **"Image generation timeout"**
   - 澧炲姞瓒呮椂鏃堕棿
   - 绠€鍖栨彁绀鸿瘝
   - 鍑忓皯鐢熸垚鏁伴噺

4. **"Invalid size"**
   - 妫€鏌ユ彁渚涘晢鏀寔鐨勫昂瀵稿垪琛?
   - 浣跨敤鏍囧噯灏哄鏍煎紡

## 鎵╁睍寮€鍙?

### 娣诲姞鏂扮殑鎻愪緵鍟?

1. 鍦?`src/hub/{provider}/image/` 鍒涘缓椹卞姩绋嬪簭
2. 瀹炵幇 `BaseImageDriver` 鎺ュ彛
3. 鍦?`ImageDriverFactory` 涓敞鍐?
4. 鏇存柊鏂囨。

### 鑷畾涔夊弬鏁?

鏌愪簺鎻愪緵鍟嗘敮鎸侀澶栫殑鍙傛暟锛?

```python
inputs = {
    "prompt": "...",
    "provider": "tongyi",
    # 鎻愪緵鍟嗙壒瀹氬弬鏁?
    "style": "anime",
    "quality": "high",
    ...
}
```

## 鐗堟湰鍘嗗彶

- **v1.0.0** - 鍒濆鐗堟湰锛屾敮鎸佸熀鏈殑鍥剧墖鐢熸垚
- **v1.1.0** - 娣诲姞璐熼潰鎻愮ず璇嶆敮鎸?
- **v1.2.0** - 鏀寔鎵归噺鐢熸垚
- **v1.3.0** - 娣诲姞鏇村浜戞湇鍔℃彁渚涘晢
- **v2.0.0** - 閲嶆瀯涓?LangGraph 鑺傜偣鏋舵瀯

## 璁稿彲璇?

MIT License

## 鐩稿叧鏂囨。

- [椹卞姩绋嬪簭寮€鍙戞寚鍗梋(../../hub/README.md)
- [鐘舵€佺鐞哴(./state.py)
- [鑺傜偣瀹炵幇](./node.py)


