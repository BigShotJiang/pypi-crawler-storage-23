﻿from typing import TypedDict, Optional, Dict, Any
from .inputs import ImageInputs

class ImageState(TypedDict, total=False):
    """鍥剧墖鐢熸垚鑺傜偣鐨勭姸鎬佸畾涔?""
    # 杈撳叆鍙傛暟
    inputs: ImageInputs
    provider: str  # 榛樿锛歛liyun 鍙€夛細baidu, tencent, volcengine
    
    # 缁熶竴鍝嶅簲锛堝寘鍚笟鍔″搷搴旀暟鎹紝涓嶅寘鍚?usage锛?
    response: Optional[Dict[str, Any]]  # 缁撴灉鍝嶅簲锛屽寘鍚細
                                         # - images: 鐢熸垚鐨勫浘鐗囧垪琛?
                                         # - status: 鐘舵€侊紙initialized, completed, failed锛?
                                         # - error: 閿欒淇℃伅
                                         # - 鍏朵粬 API 杩斿洖鐨勫師濮嬫暟鎹紙濡?task_id銆乺equest_id 绛夛級
    
    # 鐙珛鐨勪娇鐢ㄧ粺璁″瓧娈?
    usage: Optional[dict]  # 浣跨敤鎯呭喌锛坱oken/鍥剧墖鏁伴噺绛夛級锛岀嫭绔嬩簬 response


