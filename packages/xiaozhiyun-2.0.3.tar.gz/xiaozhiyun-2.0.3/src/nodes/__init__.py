﻿from typing import Dict, Any, Callable, Awaitable
from .chat.node import ChatNode

def chat(provider: str, inputs: Dict[str, Any] = None):
    async def wrapper(state: Dict[str, Any], config: Any = None):
        if inputs: 
             # Merge into state["inputs"] if exists, or state root?
             # ChatNode.process looks at state["inputs"] or state root.
             # We'll merge into a temp copy if needed, but state is usually mutable dict in LangGraph.
             # Safest is to update explicit inputs key if we want to honor `inputs` param as override.
             # logic: inputs param > state
             existing = state.get("inputs", {})
             if isinstance(existing, dict):
                 state["inputs"] = {**existing, **inputs}
        return await ChatNode.process(state, config)
    return wrapper

def image(provider: str, inputs: Dict[str, Any] = None):
     async def wrapper(state: Dict[str, Any], config: Any = None):
         return {"error": "ImageNode not implemented yet"}
     return wrapper

def tts(provider: str, inputs: Dict[str, Any] = None):
     async def wrapper(state: Dict[str, Any], config: Any = None):
         return {"error": "TTSNode not implemented yet"}
     return wrapper

def asr(provider: str, inputs: Dict[str, Any] = None):
     async def wrapper(state: Dict[str, Any], config: Any = None):
         return {"error": "ASRNode not implemented yet"}
     return wrapper

stt = asr
sst = asr
ts = asr


