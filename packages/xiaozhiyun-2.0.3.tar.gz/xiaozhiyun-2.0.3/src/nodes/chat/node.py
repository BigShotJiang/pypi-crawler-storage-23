﻿from typing import Dict, Any, Union, AsyncGenerator, Optional
import uuid
import time
import logging
from src.nodes.base_node import BaseNode
from src.chat import chat, extra_usage

logger = logging.getLogger(__name__)

try:
    from langchain_core.runnables import RunnableConfig
except ImportError:
    RunnableConfig = Any

class ChatNode(BaseNode):
    """
    Generic Chat Node that uses src.chat unified interface.
    Supports all providers via the unified entry point.
    """
    def __init__(self, provider: str = "auto", **default_config):
        super().__init__("chat", provider)
        self.default_config = default_config

    @staticmethod
    async def process(state: Dict[str, Any], run_config: Optional[RunnableConfig] = None) -> Dict[str, Any]:
        """
        Execute chat request via src.chat.
        Expects `state` to contain standard chat parameters:
        - inputs: Dict containing messages, model, etc.
        - provider: str
        - api_key/base_url/timeout: optional overrides at top level
        """
        
        # 1. Extract config from top level state as per ChatState update
        api_key = state.get("api_key")
        base_url = state.get("base_url")
        driver = state.get("provider") or "auto"
        timeout = state.get("timeout")
        
        # 2. Extract inputs (messages, model, etc.)
        inputs = state.get("inputs", {})
        if not inputs and "messages" in state:
            # Fallback for states where inputs aren't nested
            inputs = state

        # 3. Preparation for chat call
        _config = {
            "api_key": api_key,
            "base_url": base_url,
            "timeout": timeout,
            "completion_id": state.get("completion_id"),
            "created": state.get("created")
        }

        try:
            # 4. Call unified chat
            # This will return a dict for non-streaming or stream metadata for streaming
            # internal chunks are dispatched via adispatch_custom_event in chat()
            result = await chat(driver, inputs, _config, run_config=run_config)
            
            logger.info(f"ChatNode execution result: {result}")
            
            # 5. Build final return dict for the workflow state
            # Preferred usage: from result, then from extra_usage()
            usage_data = result.get("usage")
            context_usage = await extra_usage()
            if context_usage:
                if not usage_data:
                    usage_data = context_usage
                else:
                    # Merge if needed, but usually one is enough
                    usage_data.update(context_usage)
            
            logger.info(f"ChatNode final usage: {usage_data}")
            
            output_state = {**result}
            if usage_data:
                output_state.update({
                    "usage": usage_data,
                    "input_tokens": usage_data.get("prompt_tokens") or usage_data.get("input_tokens", 0),
                    "output_tokens": usage_data.get("completion_tokens") or usage_data.get("output_tokens", 0),
                    "total_tokens": usage_data.get("total_tokens") or usage_data.get("total_tokens", 0)
                })
            
            return output_state

        except Exception as e:
            logger.error(f"ChatNode execution failed: {str(e)}", exc_info=True)
            return {
                "success": False,
                "error": f"ChatNode error: {str(e)}",
                "generated_content": f"Error: {str(e)}"
            }

    @staticmethod
    async def extra_usage(state: Dict[str, Any] = None):
        """
        Get usage information from the current context.
        Only returns data if found in context to avoid overwriting state with zeros.
        """
        usage_data = await extra_usage()
        logger.info(f"ChatNode extra_usage check: {usage_data}")
        
        if not usage_data:
            return {}
            
        return {
            "usage": usage_data,
            "input_tokens": usage_data.get("prompt_tokens") or usage_data.get("input_tokens", 0),
            "output_tokens": usage_data.get("completion_tokens") or usage_data.get("output_tokens", 0),
            "total_tokens": usage_data.get("total_tokens", 0)
        }

    def validate_input(self, state: Dict[str, Any]) -> bool:
        """Check if minimum required arguments (messages or prompt) are present."""
        inputs = state.get("inputs", state)
        return "messages" in inputs or "prompt" in inputs

