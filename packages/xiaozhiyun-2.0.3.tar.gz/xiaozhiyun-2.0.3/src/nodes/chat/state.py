﻿from typing import TypedDict, Dict, Any
from .inputs import ChatInputs
from typing import Optional

class ChatState(TypedDict):

    inputs: ChatInputs

    response_message: Optional[dict] # Hold the full AIMessage as dict
    response: Optional[Dict[str, Any]] # OpenAI-compatible response
    usage: Optional[dict] 
    
      # Project Specific / Config
    provider: Optional[str]
    api_key: Optional[str]
    base_url: Optional[str]
    timeout: Optional[float]
    

