﻿# ChatNode 妯″潡璇存槑

## 妯″潡绠€浠?

`ChatNode` 鏄?`src`锛堝皬鏅轰簯锛夋鏋朵腑鐨勬牳蹇冭妭鐐癸紝璐熻矗缁熶竴澶勭悊鎵€鏈?LLM (Large Language Model) 鐨勫璇濊姹傘€傚畠灞忚斀浜嗗簳灞備笉鍚屾ā鍨嬫彁渚涘晢锛堝 Aliyun, Tencent, ChatGPT 绛夛級鐨勫樊寮傦紝鍚戝鎻愪緵涓€鑷寸殑琛屼负鍜屾爣鍑嗗寲鐨?OpenAI 鏍煎紡杈撳嚭銆?

## 鍔熻兘鐗规€?

1. **缁熶竴鎺ュ彛**锛氶€氳繃 `ChatNode.process` 闈欐€佹柟娉曟彁渚涚粺涓€鍏ュ彛锛屾帴鏀?`AgentState` 骞舵墽琛屽璇濋€昏緫銆?
2. **鏍囧噯鍖栬緭鍑?(OpenAI Format)**锛?
    * 鏃犺鏄祦寮?(`stream=True`) 杩樻槸闈炴祦寮?(`stream=False`) 璇锋眰锛宍ChatNode` **濮嬬粓** 璐熻矗鐢熸垚绗﹀悎 OpenAI API 鏍囧噯鐨勫搷搴旀牸寮忋€?
    * **娴佸紡妯″紡**锛氶€氳繃 `adispatch_custom_event` 鍒嗗彂 `openai_chunk` 浜嬩欢锛屾瘡涓簨浠舵惡甯︿竴涓爣鍑嗙殑 `chat.completion.chunk` 瀵硅薄銆?
    * **闈炴祦寮忔ā寮?*锛氬唴閮ㄦ秷璐瑰簳灞傜粨鏋滃悗锛屾瀯閫犲畬鏁寸殑 OpenAI `chat.completion` 瀛楀吀锛屽苟灏嗗叾瀛樺叆 `state["response"]`銆?
3. **Usage 缁熻**锛氳嚜鍔ㄤ粠搴曞眰鍝嶅簲涓彁鍙?Token 浣跨敤鎯呭喌锛坄prompt_tokens`, `completion_tokens`锛夛紝骞跺綊涓€鍖栦负鏍囧噯瀛楁銆?
4. **鏃犵紳闆嗘垚 LangGraph**锛氳璁′负 LangGraph 鑺傜偣锛屽彲鐩存帴宓屽叆宸ヤ綔娴?(`StateGraph`)銆?

## 浣跨敤鏂瑰紡

### 1. 鍦?LangGraph 宸ヤ綔娴佷腑娉ㄥ唽

```python
from src.nodes.chat_node import ChatNode

builder = StateGraph(AgentState)
# ... 娣诲姞鍏朵粬鑺傜偣 ...
builder.add_node("chat_node", ChatNode.process)
builder.add_node("extra_usage", ChatNode.extra_usage) # 鐢ㄤ簬鍏滃簳 Usage 缁熻

# ... 杩炴帴杈?...
builder.add_edge("generate_response", "chat_node")
builder.add_edge("chat_node", "extra_usage")
```

### 2. State 瑕佹眰 (`AgentState`)

`ChatNode` 鏈熸湜杈撳叆鐘舵€佷腑鍖呭惈浠ヤ笅鍏抽敭瀛楁锛堥€氬父鐢变笂娓歌妭鐐瑰 `generate_response` 鍑嗗锛夛細

* `inputs` (Dict): 鍖呭惈 `messages`, `model`, `stream` 绛夊弬鏁般€?
  * 鎴栬€呯洿鎺ュ湪 `state` 鏍瑰眰绾у瓨鍦ㄨ繖浜涘瓧娈碉紙涓轰簡鍏煎鎬э級銆?
* `completion_id` (str): 鐢ㄤ簬鏍囪瘑鏈瀵硅瘽鐨勫敮涓€ ID銆?
* `created` (int): 鍒涘缓鏃堕棿鎴炽€?
* `llm_config` (Dict): 鍖呭惈 `provider`, `api_key` 绛夐厤缃€?

### 3. 杈撳嚭琛屼负

* **娴佸紡 (`process`)**锛?
  * 杩唬搴曞眰 LLM 鐨勬祦銆?
  * 灏嗘瘡涓?Token 鎴?Usage 鏇存柊鍖呰鎴?`openai_chunk` 浜嬩欢銆?
  * 璋冪敤 `adispatch_custom_event("openai_chunk", chunk_data)` 鍙戦€佷簨浠躲€?
* **闈炴祦寮?(`process`)**锛?
  * 绛夊緟搴曞眰 LLM 杩斿洖瀹屾暣缁撴灉銆?
  * 鏋勫缓瀹屾暣鐨?OpenAI `response` 瀛楀吀銆?
  * 灏嗙粨鏋滃瓨鍏ヨ繑鍥炲瓧鍏革細`{"response": full_response_dict, "generated_content": ..., "usage": ...}`銆?

## 缁撳悎 Endpoint 鐨勬渶浣冲疄璺?

鍦?API 灞傦紙濡?FastAPI Endpoint锛夛紝鏃犺璇锋眰绫诲瀷濡備綍锛岄兘鍙互鏋佺畝澶勭悊锛?

**娴佸紡鍝嶅簲 (`stream=True`)**锛?
Endpoint 鍙渶鐩戝惉 `astream_events` 涓殑 `openai_chunk` 浜嬩欢骞堕€忎紶缁欏墠绔?(SSE)銆?

```python
async for event in workflow.astream_events(input_state, version="v2"):
    if kind == "on_custom_event" and event["name"] == "openai_chunk":
        yield f"data: {json.dumps(event['data'])}\n\n"
```

**闈炴祦寮忓搷搴?(`stream=False`)**锛?
Endpoint 鍙渶璋冪敤 `workflow.ainvoke`锛岀劧鍚庣洿鎺ヨ繑鍥?`state["response"]`銆?

```python
final_state = await workflow.ainvoke(input_state)
return JSONResponse(content=final_state["response"])
```

## 缁存姢璇存槑

- **淇敼鍝嶅簲鏍煎紡**锛氬鏋滈渶瑕佽皟鏁磋繑鍥炵粰鍓嶇鐨?JSON 缁撴瀯锛?*鍙渶淇敼 `ChatNode.process`** 涓殑鏋勯€犻€昏緫锛屾棤闇€淇敼 API Endpoint銆?
* **鏂板瀛楁**锛氬鏋滃簳灞傛ā鍨嬭繑鍥炰簡鏂板瓧娈碉紙濡?reasoning锛夛紝鍦?`ChatNode` 涓В鏋愬苟娣诲姞鍒版爣鍑?chunk/response 涓嵆鍙€?


