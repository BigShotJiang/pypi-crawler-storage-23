﻿from ..core.router import LoggingAPIRouter
from ..api.image.endpoint import router as image_router
from ..api.open_ai_chat.endpoint import router as chat_router
from ..api.stt.endpoint import router as stt_router
from ..api.tts.endpoint import router as tts_router

# Create main router using our custom LoggingAPIRouter
# This will automatically log any unhandled exceptions in routes to xzy_log_sys
router = LoggingAPIRouter(tags=["xzy-api"], prefix="/xzy")

# Include sub-routers
# Versioned APIs
router.include_router(chat_router, prefix="/api/v1")
router.include_router(image_router, prefix="/api/v1")

# WebSocket / Other APIs (No version prefix)
router.include_router(stt_router,prefix="/ws")
router.include_router(tts_router,prefix="/ws")
# More routers can be added here (e.g., TTS, STT, Knowledge base)

__all__ = ["router"]

