﻿import json
import os
from pathlib import Path
from typing import Dict, Any, List, Optional
from pydantic import BaseModel

# Start: Model Definitions
class ProviderConfig(BaseModel):
    enabled: bool
    base_url: str
    api_key_env: str
    default_model: str
    enable_search: Optional[bool] = False
    extra_body: Optional[Dict[str, Any]] = None
    deep_thinking_params: Optional[Dict[str, Any]] = None
    search_params: Optional[Dict[str, Any]] = None
    requires_user_message: Optional[bool] = False
    inject_system_time: Optional[bool] = False
    stream_options: Optional[Dict[str, Any]] = None
    params: Optional[Dict[str, Any]] = None
    models: List[str]

class LangChainConfig(BaseModel):
    providers: Dict[str, ProviderConfig]
    global_parameters: Dict[str, Any]
    reasoning_model_patterns: Optional[List[str]] = ["o1-", "o3-", "k2.5", "reasoner"]

class WorkflowConfig(BaseModel):
    default_timeout: int
    recursion_limit: int
    checkpointer: Dict[str, Any]

class LangGraphConfig(BaseModel):
    workflows: WorkflowConfig
    nodes: Dict[str, Any]
# End: Model Definitions

class ConfigLoader:
    _instance = None
    _langchain_config: Optional[LangChainConfig] = None
    _langgraph_config: Optional[LangGraphConfig] = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(ConfigLoader, cls).__new__(cls)
            cls._instance._load_configs()
        return cls._instance

    def _load_configs(self):
        # Fallback paths to search for config
        current_file = Path(__file__).resolve()
        
        # Candidate 1: Root of the repo/install (3 levels up from src/xiaozhiyun/config.py)
        # src/xiaozhiyun/config.py -> src/xiaozhiyun -> src -> root
        path_strategies = [
            current_file.parent.parent.parent, # editable/source root
            current_file.parent.parent,        # maybe src is root?
            current_file.parent,               # package dir
        ]

        lc_found = None
        lg_found = None
        
        # print(f"[src] Debug: searching configs in {path_strategies}")

        for root_dir in path_strategies:
            lc_path = root_dir / "langchain.json"
            lg_path = root_dir / "langgraph.json"
            stt_path = root_dir / "stt.json"
            tts_path = root_dir / "tts.json"
            
            if not lc_found and lc_path.exists():
                lc_found = lc_path
            
            if not lg_found and lg_path.exists():
                lg_found = lg_path
                
            if not hasattr(self, '_stt_path') and stt_path.exists():
                 self._stt_path = stt_path
                 
            if not hasattr(self, '_tts_path') and tts_path.exists():
                 self._tts_path = tts_path
        
        if lc_found:
            try:
                with open(lc_found, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    self._langchain_config = LangChainConfig(**data)
            except Exception as e:
                print(f"[src] Error loading langchain.json from {lc_found}: {e}")
        else:
            print(f"[src] Warning: langchain.json not found. Searched in: {[str(p) for p in path_strategies]}")

        if lg_found:
            try:
                with open(lg_found, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    self._langgraph_config = LangGraphConfig(**data)
            except Exception as e:
                 print(f"[src] Error loading langgraph.json from {lg_found}: {e}")
                 
        if hasattr(self, '_stt_path'):
            try:
                with open(self._stt_path, "r", encoding="utf-8") as f:
                    self._stt_config = json.load(f)
            except Exception as e:
                 print(f"[src] Error loading stt.json: {e}")
                 self._stt_config = {}
        else:
             self._stt_config = {}

        if hasattr(self, '_tts_path'):
            try:
                with open(self._tts_path, "r", encoding="utf-8") as f:
                    self._tts_config = json.load(f)
            except Exception as e:
                 print(f"[src] Error loading tts.json: {e}")
                 self._tts_config = {}
        else:
             self._tts_config = {}

    @property
    def langchain(self) -> LangChainConfig:
        if not self._langchain_config:
            self._load_configs()
        return self._langchain_config

    @property
    def langgraph(self) -> LangGraphConfig:
        if not self._langgraph_config:
            self._load_configs()
        return self._langgraph_config
    
    @property
    def stt(self) -> Dict[str, Any]:
        if not hasattr(self, '_stt_config') or not self._stt_config:
            self._load_configs()
        return self._stt_config

    @property
    def tts(self) -> Dict[str, Any]:
        if not hasattr(self, '_tts_config') or not self._tts_config:
            self._load_configs()
        return self._tts_config

    def get_provider_config(self, provider: str) -> Optional[ProviderConfig]:
        if not provider or provider=="auto" or provider=="default":
            provider = self.langchain.global_parameters.get("default_provider", "aliyun")
        return self.langchain.providers.get(provider)

# Singleton instance
config = ConfigLoader()


