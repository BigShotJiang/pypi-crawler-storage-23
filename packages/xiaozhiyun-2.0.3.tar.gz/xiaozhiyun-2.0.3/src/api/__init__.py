﻿from typing import Dict, Any, AsyncGenerator, Optional
import httpx
import json
import logging

logger = logging.getLogger(__name__)

class APIClient:
    """HTTP client for src AI services."""
    
    def __init__(self, host: str = '0.0.0.0', port: int = 8000):
        self.host = host
        self.port = port
        self.base_url = f"http://{host}:{port}"
        self._client: Optional[httpx.AsyncClient] = None

    def _get_client(self) -> httpx.AsyncClient:
        if self._client is None or self._client.is_closed:
            self._client = httpx.AsyncClient(timeout=300.0)
        return self._client

    async def _call(self, provider: str, service: str, inputs: Dict[str, Any]):
        # Mapping service to URL path
        path = f"/api/{provider}/{service}"
        if service == "image":
            path = f"/api/{provider}/image/generate"
        elif service in ["asr", "sst"]:
            path = f"/api/{provider}/stt"
        
        url = f"{self.base_url}{path}"
        is_stream = inputs.get("stream", False)
        client = self._get_client()

        if is_stream:
            async def stream_gen():
                try:
                    async with client.stream("POST", url, json=inputs) as response:
                        if response.status_code != 200:
                             err_text = await response.aread()
                             yield {"error": f"API Error {response.status_code}: {err_text.decode()}"}
                             return
                        
                        async for line in response.aiter_lines():
                            if line.startswith("data: "):
                                data_str = line[6:]
                                if data_str == "[DONE]":
                                    break
                                try:
                                    yield json.loads(data_str)
                                except:
                                    yield data_str
                except Exception as e:
                    yield {"error": str(e)}
            return stream_gen()
        else:
            try:
                resp = await client.post(url, json=inputs)
                if resp.status_code != 200:
                    return {"error": f"API Error {resp.status_code}: {resp.text}", "success": False}
                return resp.json()
            except Exception as e:
                return {"error": str(e), "success": False}

    async def chat(self, provider: str, inputs: Dict[str, Any]):
        return await self._call(provider, "chat", inputs)

    async def image(self, provider: str, inputs: Dict[str, Any]):
        return await self._call(provider, "image", inputs)

    async def tts(self, provider: str, inputs: Dict[str, Any]):
        return await self._call(provider, "tts", inputs)

    async def asr(self, provider: str, inputs: Dict[str, Any]):
        return await self._call(provider, "asr", inputs)

    async def sst(self, provider: str, inputs: Dict[str, Any]):
        return await self._call(provider, "sst", inputs)

    async def close(self):
        """Close the underlying HTTP client."""
        if self._client and not self._client.is_closed:
            await self._client.aclose()

# Function-like interface to create the client
def api(host: str = '0.0.0.0', port: int = 8000) -> APIClient:
    return APIClient(host, port)


