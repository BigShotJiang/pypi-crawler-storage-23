﻿# Copyright (c) 2025 Bytedance Ltd. and/or its affiliates
# SPDX-License-Identifier: MIT

import logging
from async_lru import alru_cache
from .models.api_account import ApiAccount
from .models.api_app_key import ApiAppKey

logger = logging.getLogger(__name__)

@alru_cache(maxsize=100, ttl=300) # Cache for 300s (5min)
async def check_api_key(token: str):
    # Use ORM to find the app key first
    app_key_record = await ApiAppKey.find_one(app_key=token)
    if not app_key_record:
        return None
    
    # Then find the associated account
    account = await ApiAccount.find_one(app_id=app_key_record.app_id)
    
    logger.info(f"API key check result: {account.__dict__ if account else None}")
    
    if account:
        # Return as dict for compatibility with existing code
        return vars(account)
    return None

