﻿from datetime import datetime
from src.core.orm import Model, Field

class LogSys(Model):
    __tablename__ = "xzy_log_sys"
    __logging__ = False  # Never log the logger!
    
    id = Field(primary_key=True, auto_increment=True)
    instance = Field()
    channel = Field()
    level = Field()
    level_name = Field()
    message = Field()
    context = Field()
    remote_addr = Field()
    user_agent = Field()
    created_by = Field()
    uuid = Field()
    created_at = Field()
    updated_at = Field()

    def set_created_at_attribute(self, value):
        return value or datetime.now()

    def set_updated_at_attribute(self, value):
        return value or datetime.now()

