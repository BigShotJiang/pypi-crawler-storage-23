﻿from src.core.orm import Model, Field

class WithOpenAi(Model):
    __tablename__ = "xzy_with_openai"
    __logging__ = True
    id = Field(primary_key=True, auto_increment=True)
    app_id = Field()
    title = Field()
    name = Field()
    driver = Field()
    params = Field()
    token_warning = Field()
    save_message = Field()
    created_at = Field()
    status = Field()
    desc = Field(name="desc")

