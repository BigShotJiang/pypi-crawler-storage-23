﻿from src.core.orm import Model, Field

class AiimgModel(Model):
    __tablename__ = "xzy_aiimg_model"
    __logging__ = True
    id = Field(primary_key=True, auto_increment=True)
    name = Field()
    title = Field()
    driver = Field()
    params = Field()
    app_id = Field()
    status = Field()

