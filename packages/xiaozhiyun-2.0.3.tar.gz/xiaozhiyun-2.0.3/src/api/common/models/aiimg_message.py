﻿from src.core.orm import Model, Field

class AiimgMessage(Model):
    __tablename__ = "xzy_aiimg_message"
    __logging__ = True
    id = Field(primary_key=True, auto_increment=True)
    model_id = Field()
    app_id = Field()
    question = Field()
    result = Field()
    input_tokens = Field()
    output_tokens = Field()
    total_tokens = Field()
    uuid = Field()

