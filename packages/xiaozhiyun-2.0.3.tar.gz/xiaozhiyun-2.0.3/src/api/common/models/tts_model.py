﻿from src.core.orm import Model, Field

class TtsModel(Model):
    __tablename__ = "xzy_tts_model"
    __logging__ = True
    id = Field(primary_key=True, auto_increment=True)
    name = Field()
    driver = Field()
    params = Field()
    app_id = Field()
    status = Field()

