﻿from src.core.orm import Model, Field

class Account(Model):
    __tablename__ = "xzy_account"
    __logging__ = True
    id = Field(primary_key=True, auto_increment=True)
    params = Field()
    platform = Field()
    status = Field()

