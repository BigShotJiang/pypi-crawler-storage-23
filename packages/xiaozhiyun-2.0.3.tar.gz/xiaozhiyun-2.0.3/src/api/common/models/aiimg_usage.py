﻿from src.core.orm import Model, Field

class AiimgUsage(Model):
    __tablename__ = "xzy_aiimg_usage"
    __logging__ = True
    id = Field(primary_key=True, auto_increment=True)
    app_id = Field()
    model_id = Field()
    input_tokens = Field()
    output_tokens = Field()
    total_tokens = Field()
    uuid = Field()

