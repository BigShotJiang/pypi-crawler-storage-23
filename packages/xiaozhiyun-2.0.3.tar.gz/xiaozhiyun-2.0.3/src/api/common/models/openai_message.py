﻿from src.core.orm import Model, Field

class OpenAiMessage(Model):
    __tablename__ = "xzy_generate_openai_message"
    __logging__ = True
    id = Field(primary_key=True, auto_increment=True)
    model_id = Field()
    input = Field()
    output = Field()
    uuid = Field()
    created_at = Field()
    updated_at = Field()

