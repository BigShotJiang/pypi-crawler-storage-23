﻿from src.core.orm import Model, Field

class LogModelDetail(Model):
    __tablename__ = "xzy_log_model_detail"
    __logging__ = False
    
    id = Field(primary_key=True, auto_increment=True)
    detail = Field()
    attributes = Field()
    original = Field()
    uuid = Field()

