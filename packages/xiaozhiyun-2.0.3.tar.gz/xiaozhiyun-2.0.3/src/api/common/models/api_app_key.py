﻿from src.core.orm import Model, Field

class ApiAppKey(Model):
    __tablename__ = "xzy_api_app_key"
    __logging__ = True
    id = Field(primary_key=True, auto_increment=True)
    app_id = Field()
    app_key = Field()

