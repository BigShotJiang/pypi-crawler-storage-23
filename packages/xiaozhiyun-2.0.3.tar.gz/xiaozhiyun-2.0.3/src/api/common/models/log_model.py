﻿from datetime import datetime
from src.core.orm import Model, Field

class LogModel(Model):
    __tablename__ = "xzy_log_model"
    __logging__ = False
    
    id = Field(primary_key=True, auto_increment=True)
    model_id = Field()
    model = Field()
    action = Field()
    url = Field()
    guard = Field()
    web_user = Field()
    admin_user = Field()
    ip = Field()
    uuid = Field()
    created_at = Field()
    updated_at = Field()

    def set_created_at_attribute(self, value):
        return value or datetime.now()

    def set_updated_at_attribute(self, value):
        return value or datetime.now()

