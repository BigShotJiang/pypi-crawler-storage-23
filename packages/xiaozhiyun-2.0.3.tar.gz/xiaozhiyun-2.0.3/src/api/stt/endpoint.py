﻿import logging
from typing import Annotated
from fastapi import APIRouter, WebSocket, status, Query, Header, HTTPException
from fastapi.responses import JSONResponse
from src.servers.ws_stt import STTWebSocketService
from src.config import config
from .service import check_api_key, get_config_by_token
from src.core.router import LoggingAPIRouter

router = LoggingAPIRouter(tags=["stt"], prefix="/stt")
logger = logging.getLogger(__name__)

@router.websocket("/")
async def websocket_stt_endpoint(websocket: WebSocket):
    """
    WebSocket Endpoint for Real-time STT.
    """
    # Get token from query params manually to avoid FastAPI blocking
    token = websocket.query_params.get("token")
    provider = websocket.query_params.get("provider")
    if not token:
        raise HTTPException(status_code=401, detail="Missing API key")
    api_account = await check_api_key(token)
    if not api_account:
        raise HTTPException(status_code=401, detail="Invalid API key")

    if not provider:
        raise HTTPException(status_code=401, detail="Missing provider")    
   
    # Try to get configuration from database via token
    credentials = await get_config_by_token(token, provider)
    
    if not credentials:
        logger.info(f"No database config found for token={token[:10]}... and provider={provider}, falling back to stt.json defaults")
        credentials = {
            "provider": provider
        }
    
    service = STTWebSocketService()
    await service.handle_connection(websocket, credentials)

@router.get("/models")
async def chat_model(
    authorization: Annotated[str | None, Header()] = None
):
    """
    Get model list
    """    
    if not authorization:
        raise HTTPException(status_code=401, detail="Missing API key")
    
    token = authorization.replace("Bearer ", "")
    result = await check_api_key(token)
    
    if not result:
        raise HTTPException(status_code=401, detail="Invalid API key")
    
    """ 
    todo: 寰呯悊璋冪敤鏁版嵑
    """

    stt_config = config.stt
    _list = []
    
    # Load models from stt.json
    for key, val in stt_config.items():
        if isinstance(val, dict) and "class" in val:
            title_map = {
                "aliyun": "閫氫箟鍗冮棶锛堥樋閲屼簯锛?,
                "tencent": "鑵捐",
                "baidu": "鐧惧害",
                "volcengine": "鐏北寮曟搸"
            }
            desc_map = {
                "aliyun": "瀹炴椂璇煶璇嗗埆-Fun-ASR/Gummy/Paraformer",
                "tencent": "瀵瑰疄鏃堕煶棰戞祦杩涜瘑鍒紝鍚屾杩斿洖璇嗗埢鏋滐紝杈惧埌鈥滆竟璇磋竟鍑烘枃瀛楃殑鏁堟灉",
                "baidu": "瀹炴椂璇煶璇嗗埆锛屾敮鎸佸绉嶇簿璋冩ā鍨嬪拰鏂硅█璇嗗埆",
                "volcengine": "娴佸紡璇煶璇嗗埆锛屾敮鎸佹櫘閫氳瘽鍜屾柟瑷€锛屽疄鏃惰繑鍥炶瘑鍒粨鏋?
            }
            _list.append({
                "id": key,
                "object": "model",
                "created": "2026",
                "title": title_map.get(key, key),
                "owned_by": "src",
                "desc": desc_map.get(key, "")
            })
    
    if not _list:
        _list = [
            {
                "id": "aliyun",
                "object": "model", 
                "created": '2026', 
                "title": "閫氫箟鍗冮棶锛堥樋閲屼簯锛?,
                "owned_by":"src",
                'desc':'瀹炴椂璇煶璇嗗埆-Fun-ASR/Gummy/Paraformer'
            }
        ]
    data = {
        "object": "list",
        "data": _list
    }
    return JSONResponse(content=data)       

