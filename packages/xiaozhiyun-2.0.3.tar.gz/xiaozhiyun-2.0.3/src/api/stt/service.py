﻿# Copyright (c) 2025 Bytedance Ltd. and/or its affiliates
# SPDX-License-Identifier: MIT

import json
import logging
from typing import Optional, Dict, Any
from ..common.models.stt_model import SttModel
from ..common.models.account import Account
from src.api.common.service import check_api_key
from async_lru import alru_cache

logger = logging.getLogger(__name__)

async def get_model_list(app_id: str, model: str=None):
    # get app model config (convert app_id to str for varchar comparison)
    models = await SttModel.find_all(app_id=str(app_id), status=1)
    model_config = [vars(m) for m in models]
    
    if not model_config:
        logger.warning(f"Model config not found for app_id={app_id}")
        return None
    if model:
        for m in model_config:
            if m["name"] == model:
                return [m]      
    return model_config


@alru_cache(maxsize=500, ttl=60)
async def get_config_by_token(token: str, model: str) -> Optional[Dict[str, Any]]:
    """
        閫氳繃token鑾峰彇閰嶇疆
         - token: token
         - model: 妯″瀷鍚嶇О
    """
    # check api key
    result = await check_api_key(token)

    if not result:
        return None
    
    app_id = result["id"]
    
    # get app model config
    model_config_list = await get_model_list(app_id, model)
    
    if not model_config_list:
        return None
    
    model_config = model_config_list[0]
    try:
        model_config["params"] = json.loads(model_config["params"]) if model_config.get("params") else {}
    except Exception:
        model_config["params"] = {}
        
    model_id = model_config["id"]

    if not model_config.get("params") or "account" not in model_config["params"]:
        logger.info(f"Model {model} params is missing 'account' mapping, using default driver from model_config")
        return {
            "provider": model_config.get("driver", "tencent"),
            "model_id": model_id,
            "app_id": app_id,
            "metadata": model_config["params"]
        }

    # get app model config
    acc_obj = await Account.find_one(id=model_config['params']['account'], status=1)
    account = vars(acc_obj) if acc_obj else None
    
    if not account:
        return None

    try:
        account["params"] = json.loads(account["params"]) if account.get("params") else {}
    except Exception:
        account["params"] = {}
        
    # Standardize result
    driver = model_config.get("driver") or account.get("platform") or "tencent"
    
    return {
        "provider": driver, 
        "credentials": account["params"], 
        "metadata": model_config["params"], 
        "account_id": account["id"],
        "model_id": model_id,
        "app_id": app_id
    }

