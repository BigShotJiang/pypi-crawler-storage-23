﻿import httpx
import asyncio
import json
import sys

# Configuration
BASE_URL = "http://localhost:8050" # Update if your server runs on a different port
API_KEY = "sk-LEFP01Lv21wybB1GAo33p7z6uVG1bbzhM2YJ93a141l1xXpA"      # Replace with a valid API key for your system
MODEL = "ali"


async def test_non_streaming():
    print("--- Testing Non-Streaming ---")
    url = f"{BASE_URL}/api/v1/chat/completions"
    headers = {
        "Authorization": f"Bearer {API_KEY}",
        "Content-Type": "application/json"
    }
    payload = {
        "model": MODEL,
        "messages": [
            {"role": "system", "content": "You are a helpful assistant."},
            {"role": "user", "content": "娴ｇ姴銈介崥妤嬬礉娴ｇ姷鐓￠柆鎾存付鏉╂垵褰傞悽鐔烘畱鐡掞絼绨ㄩ崥?}
        ],
        "stream": False,
        "temperature": 0.7
    }
    
    async with httpx.AsyncClient() as client:
        try:
            response = await client.post(url, json=payload, headers=headers, timeout=60.0)
            print(f"Status Code: {response.status_code}")
            if response.status_code == 200:
                print("Response Body:")
                print(json.dumps(response.json(), indent=2, ensure_ascii=False))
            else:
                print("Error Response:")
                print(response.text)
        except Exception as e:
            print(f"Request failed: {e}")

async def test_streaming():
    print("\n--- Testing Streaming ---")
    url = f"{BASE_URL}/api/v1/chat/completions"
    headers = {
        "Authorization": f"Bearer {API_KEY}",
        "Content-Type": "application/json"
    }
    payload = {
        "model": MODEL,
        "messages": [
            {"role": "user", "content": "娴ｇ姴銈介崥妤嬬礉娴ｇ姷鐓￠柆鎾存付鏉╂垵褰傞悽鐔烘畱鐡掞絼绨ㄩ崥?}
        ],
        "stream": True,
        "temperature": 0.7
    }
    
    print(f"POST {url} with stream=True")
    
    async with httpx.AsyncClient() as client:
        try:
            async with client.stream("POST", url, json=payload, headers=headers, timeout=60.0) as response:
                print(f"Status Code: {response.status_code}")
                if response.status_code != 200:
                    print(f"Error headers: {response.headers}")
                    print(f"Error body: {await response.aread()}")
                    return

                print("Stream Output Start:")
                async for line in response.aiter_lines():
                    if not line:
                        continue
                    print(f"RAW: {line}") # Debug: print raw line
                    if line.startswith("data: "):
                        data = line[6:]
                        if data.strip() == "[DONE]":
                            print("\n[Stream Completed]")
                            break
                        try:
                            chunk = json.loads(data)
                            choices = chunk.get("choices", [])
                            if choices:
                                delta = choices[0].get("delta", {})
                                content = delta.get("content", "")
                                if content:
                                    print(f"Content: {content}")
                        except json.JSONDecodeError:
                            print(f"\n[Parse Error]: {data}")
        except Exception as e:
            print(f"Request failed: {e}")

async def test_models():
    print("\n--- Testing Models Endpoint ---")
    url = f"{BASE_URL}/api/v1/models"
    headers = {
        "Authorization": f"Bearer {API_KEY}",
    }
    async with httpx.AsyncClient() as client:
        try:
            response = await client.get(url, headers=headers, timeout=10.0)
            print(f"Status Code: {response.status_code}")
            if response.status_code == 200:
                 print("Models List:")
                 print(json.dumps(response.json(), indent=2, ensure_ascii=False))
            else:
                 print(f"Error: {response.text}")
        except Exception as e:
            print(f"Request failed: {e}")

if __name__ == "__main__":
    # Check if a key was passed as argument, else warn
    if len(sys.argv) > 1:
        API_KEY = sys.argv[1]
    
    if API_KEY == "your_test_key_here":
        print("Warning: Using placeholder API_KEY. Please set a valid key in the script or pass it as an argument.")
        print("Usage: python completions_test.py [API_KEY]")
    
    print(f"Targeting: {BASE_URL}")
    
    asyncio.run(test_models())
    asyncio.run(test_non_streaming())
    # asyncio.run(test_streaming())

