﻿# Copyright (c) 2025 Bytedance Ltd. and/or its affiliates
# SPDX-License-Identifier: MIT

import json
import logging
import uuid
from datetime import datetime
from typing import Optional, Dict, Any
from ..common.models.openai_message import OpenAiMessage
from ..common.models.openai_usage import OpenAiUsage
from ..common.models.with_openai import WithOpenAi
from ..common.models.account import Account
from src.api.common.service import check_api_key



logger = logging.getLogger(__name__)

# Map DB platform strings to internal driver names
DRIVER_MAP = {
    "aliyun": "aliyun",
    "ali": "aliyun",
    "tencent": "tencent",
    "baidu": "baidu",
    "volcengine": "volcengine",
    "ByteDance": "volcengine",
    "deepseek": "aliyun"
}



async def save_message(model_id: int, input: str, output: str):
    """
        淇濆瓨娑堟伅
         - model_id: 妯″瀷ID
         - input: 杈撳叆锛涘師濮嬭緭鍏ョ殑json
         - output: 杈撳嚭锛涘師濮嬭緭鍑虹殑json
    """
    msg = OpenAiMessage(
        model_id=model_id,
        input=input,
        output=output,
        uuid=str(uuid.uuid4()),
        created_at=datetime.now(),
        updated_at=datetime.now()
    )
    await msg.save()

async def save_token_usage(app_id: int, model_id: int, prompt_tokens: int, completion_tokens: int):
    """
        淇濆瓨token浣跨敤鎯呭喌
         - app_id: 搴旂敤ID
         - model_id: 妯″瀷ID
         - prompt_tokens: 杈撳叆token?         - completion_tokens: 杈撳嚭token?    """
    usage = OpenAiUsage(
        app_id=app_id,
        model_id=model_id,
        prompt_tokens=prompt_tokens,
        completion_tokens=completion_tokens,
        total_tokens=prompt_tokens + completion_tokens,
        uuid=str(uuid.uuid4()),
        created_at=datetime.now(),
        updated_at=datetime.now()
    )
    await usage.save()


async def get_model_list(app_id: str, model: str=None):
    # get app model config (convert app_id to str for varchar comparison)
    models = await WithOpenAi.find_all(app_id=str(app_id), status=1)
    
    # Convert models to dict for downstream compatibility
    model_config = [vars(m) for m in models]
    
    # Check if model config exists before accessing properties
    if not model_config:
        logger.warning(f"Model config not found for app_id={app_id}")
        return None
    if model:
        found = False
        for m in model_config:
            if m["name"] == model:
                model_config = [m]
                found = True
                break
        if not found:
            logger.warning(f"Model '{model}' not found in config for app_id={app_id}. Available: {[m['name'] for m in model_config]}")
            return None

    return model_config


async def get_config_by_token(token: str, model: str = "ali") -> Optional[Dict[str, Any]]:
    """
        閫氳繃token鑾峰彇閰嶇疆
         - token: token
         - model: 妯″瀷鍚嶇О
    """
    model = model or "ali"
    # check api key
    result = await check_api_key(token)

    if not result:
        logger.error(f"Token invalid: {token[:10]}...")
        return None
    
    app_id = result["id"]
    
    # get app model config (convert app_id to str for varchar comparison)
    # This will now return None if model is specific and not found
    model_config = await get_model_list(app_id, model)
    
    if not model_config:
        logger.error(f"Model config retrieval failed for app_id={app_id}, model={model}")
        return None
    
    model_config = model_config[0]
   
    model_config["params"] = json.loads(model_config["params"]) if model_config.get("params") else {}
    model_config["token_warning"] = model_config["token_warning"]
    save_chat_history = True if model_config.get("save_message") == 1 else False
    model_id = model_config["id"]
    account_id = model_config["params"].get("account")

    if not account_id:
        logger.error(f"Model {model} params is missing 'account' mapping")
        return None

    # get app model config
    acc_obj = await Account.find_one(id=account_id, status=1)
    if not acc_obj:
        logger.error(f"Account not found for id={account_id}")
        return None
    account = vars(acc_obj)
    
    account["params"] = json.loads(account["params"]) if account.get("params") else {}
    account["platform"] = account["platform"]
    account["id"] = account["id"]
    
    api_key = account["params"].get("api_key", "")
    masked_key = f"{api_key[:6]}...{api_key[-4:]}" if len(api_key) > 10 else "***"
    logger.info(f"Using Account: id={account['id']}, platform={account['platform']}, api_key={masked_key}")

    # Normalize provider name
    driver = DRIVER_MAP.get(model_config["driver"], model_config["driver"])
    # If not found in map, it defaults to original value. 
    # Or should we default to 'aliyun' as safe fallback? 
    # Code below was forcing 'aliyun' for deepseek.
    # Map handles 'deepseek' -> 'aliyun'. 
    result = {
        "base_url": model_config["params"].get("proxy"),
        "model": model_config["params"].get("body", {}).get("model") if isinstance(model_config["params"].get("body"), dict) else model,
        "api_key": account["params"].get("api_key"),
        "save_chat_history": save_chat_history,
        "token_warning": model_config.get("token_warning", 0),
        "account_id": account["id"],
        "model_id": model_id,
        "app_id": app_id,
        "meta_data": model_config["params"].get("body") if isinstance(model_config["params"].get("body"), dict) else {},
        "provider": driver
    }
    logger.info(f"Result: {result}")
    return result


