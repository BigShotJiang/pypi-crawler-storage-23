﻿from fastapi import APIRouter, Header, HTTPException, Depends
from fastapi.responses import StreamingResponse, JSONResponse


from datetime import datetime
import json
import time
import uuid
import logging
from typing import Annotated, AsyncGenerator, Optional

from .schema import DynamicChatRequest
from .service import check_api_key, get_model_list, get_config_by_token
from src.workflows.graph.chat.builder import build_workflow
from src.core.router import LoggingAPIRouter

logger = logging.getLogger(__name__)

router = LoggingAPIRouter(prefix='/chat',tags=["chat"])

class OpenAIChatEndpoint:
    def __init__(self):
        self.router = router
        self.router.add_api_route("/completions", self.chat_stream, methods=["POST"])
        
        # Cache the workflow to avoid recompilation overhead per request
        self.workflow = build_workflow()
        
    async def chat_stream(self, 
                          request: DynamicChatRequest, 
                          authorization: Annotated[str | None, Header()] = None):
        """
        OpenAI-compatible /chat/completions endpoint using src workflow.
        """
        if not authorization:
             raise HTTPException(status_code=401, detail="Missing Authorization header")
        
        if not request.model:
            raise HTTPException(status_code=400, detail="Missing model parameter")

        token = authorization.replace("Bearer ", "") if authorization.startswith("Bearer ") else authorization
        config = await get_config_by_token(token,request.model)
        if not config:
            raise HTTPException(status_code=401, detail="Invalid API key")


        workflow = self.workflow
        logger.info(f"-----------request----------: {request}")
        # Prepare initial state
        input_state = {
            "request": request,
            "auth_header": authorization,
            "completion_id": f"chatcmpl-{uuid.uuid4()}",
            "created": int(time.time()),
            "intent": "chat", 
            "llm_config": config,
            "generated_content": "",
            "response_message": None,
            "usage": None,
            "input_tokens": 0,
            "output_tokens": 0
        }

        try:
            event_generator = self._chat_event_generator(workflow, input_state)
            
            if request.stream:
                logger.info("----- 濞翠礁绱?)
                return StreamingResponse(
                    event_generator,
                    media_type="text/event-stream"
                )
            else:
                logger.info("----- 闈炴祦寮?)
                # Non-streaming: standard invoke
                # ChatNode now guarantees 'response' is a valid OpenAI-compatible dictionary
                final_state = await workflow.ainvoke(input_state)
                
                content = final_state.get("generated_content", "")
                if content and content.startswith("Error:"):
                     return JSONResponse(status_code=500, content={"error": content})

                response_obj = final_state.get("response")
                if response_obj:
                    # It's likely a dict now, but keep robust checks just in case
                    if isinstance(response_obj, dict):
                        return JSONResponse(content=response_obj)
                    elif hasattr(response_obj, "to_dict"):
                        return JSONResponse(content=response_obj.to_dict())
                    elif hasattr(response_obj, "model_dump"):
                        return JSONResponse(content=response_obj.model_dump())
                
                return JSONResponse(status_code=500, content={"error": "No response object found in state"})

        except Exception as e:
            logger.error(f"Chat error: {e}", exc_info=True)
            return JSONResponse(status_code=500, content={"error": str(e)})

    async def _chat_event_generator(self, workflow, input_state) -> AsyncGenerator[str, None]:
        """Generator for SSE."""
        async for event in workflow.astream_events(input_state, version="v2"):
            kind = event["event"]
            if kind == "on_custom_event" and event["name"] == "openai_chunk":
                yield f"data: {json.dumps(event['data'])}\n\n"
        yield "data: [DONE]\n\n"



@router.get("/models")
async def chat_model(
    authorization: Annotated[str | None, Header()] = None
):
    """
    Get model list
    """    
    if not authorization:
        raise HTTPException(status_code=401, detail="Missing API key")
    
    token = authorization.replace("Bearer ", "")
    result = await check_api_key(token)
    
    if not result:
        raise HTTPException(status_code=401, detail="Invalid API key")
    
    model_list = await get_model_list(result["id"])   
    if not model_list:
        raise HTTPException(status_code=404, detail="Model list not found")
    
    _list = []
    for model in model_list:
        created_at = int(model["created_at"].timestamp()) if model["created_at"] else int(time.time())
        _list.append({"id": model["name"], "object": "model", "created": created_at, "title": model.get("title", model["name"]),"owned_by":"src",'desc':model.get('desc','')})
    data = {
        "object": "list",
        "data": _list
    }
    return JSONResponse(content=data)

# Instantiate the endpoint to register routes
openai_endpoint = OpenAIChatEndpoint()

        

