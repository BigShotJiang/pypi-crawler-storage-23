﻿from typing import Optional, List, Dict, Any, Union
from pydantic import BaseModel, Field

class DynamicChatRequest(BaseModel):
    """
    Chat request with dynamic configuration support, compatible with OpenAI format.
    """
    model: str = Field(..., description="The model name to use (e.g. gpt-4, claude-3)")
    messages: List[Dict[str, Any]] = Field(..., description="Messages for the chat completion")
    
    # OpenAI Standard Parameters
    temperature: Optional[float] = Field(1.0)
    top_p: Optional[float] = Field(1.0)
    n: Optional[int] = Field(1)
    stream: Optional[bool] = Field(False)
    stop: Optional[Union[str, List[str]]] = Field(None)
    max_tokens: Optional[int] = Field(None)
    presence_penalty: Optional[float] = Field(0.0)
    frequency_penalty: Optional[float] = Field(0.0)
    logit_bias: Optional[Dict[str, float]] = Field(None)
    user: Optional[str] = Field(None)

    # src Extended Parameters
    enable_planning: bool = Field(False, description="Whether to enable the planner agent")
    enable_web_search: Optional[bool] = Field(False, description="Whether to enable web search")
    store: Optional[bool] = Field(False, description="Whether to store the output")
    modalities: Optional[List[str]] = Field(None, description="Output modalities (e.g. ['text'])")


