﻿from fastapi import Depends, Header, HTTPException, Request
from fastapi.responses import JSONResponse, Response
from pydantic import BaseModel
from typing import Optional, List, Dict, Any
import logging
import base64
import json
from . import service
from src.workflows.graph.image.builder import build_graph
from src.core.router import LoggingAPIRouter

workflow = build_graph()

router = LoggingAPIRouter(prefix="/img", tags=["img"])
logger = logging.getLogger(__name__)

class ImageGenerationRequest(BaseModel):
    messages: List[Dict[str, str]] = [] # Support messages format: [{"role": "user", "content": "..."}]
    prompt: Optional[str] = None
    model: Optional[str] = None
    size: Optional[str] = "1024*1024"
    n: Optional[int] = 1
    negative_prompt: Optional[str] = None
    parameters: Optional[Dict[str, Any]] = {}

@router.post("/create")
async def generate_image(
    request: ImageGenerationRequest,
    authorization: str = Header(None)
):
    """
    Generate images using the configured provider via LangGraph workflow.
    """
    if not authorization:
        raise HTTPException(status_code=401, detail="Missing Authorization header")

    token = authorization.replace("Bearer ", "")
    
    # Extract query from messages or prompt field and map custom error
    prompt = request.prompt
    if request.messages:
        for msg in reversed(request.messages):
            if msg.get("role") == "user":
                prompt = msg.get("content")
                break
    
    if not prompt:
        # Error code 100000: Question / Prompt is empty
        return JSONResponse(status_code=400, content={"code": 100000, "message": "璇疯緭鍏ラ棶棰?})

    if not request.model:
         # Error code 100001: Model is empty
         return JSONResponse(status_code=400, content={"code": 100001, "message": "璇烽€夋嫨妯″瀷"})

    # Get configuration based on token
    config = await service.get_config_by_token(token, request.model)
    if not config:
        # Error code 100002: Model not found or deleted
        return JSONResponse(status_code=400, content={"code": 100002, "message": "妯″瀷涓嶅瓨鍦ㄦ垨宸插垹?璇峰湪generate/models鎺ュ彛model瀛楁槓姝ｇ‘"})

    # Construct Initial State for the Graph
    initial_state = {
        "config": config,
        "prompt": prompt,
        "size": request.size,
        "n": request.n,
        "negative_prompt": request.negative_prompt,
        "parameters": request.parameters or {}
    }

    try:
        # Invoke the graph workflow
        final_state = await workflow.ainvoke(initial_state)
        
        # ?workflow 鎵х姸?
        response = final_state.get("response", {})
        status = response.get("status", "unknown")
        error = response.get("error")
        
        if status == "failed":
            error_msg = error or "Unknown workflow error"
            logger.error(f"Image generation workflow failed: {error_msg}")
            raise HTTPException(status_code=500, detail=error_msg)
        
        # 鑾峰彇淇濆瓨鐨勫浘?UUID 鍒楄〃
        image_uids = final_state.get("image_uids", [])
        if not image_uids:
            logger.error("Image generation succeeded but no image_uids returned")
            raise HTTPException(status_code=500, detail="Failed to save images")
        
        # 杩斿洖澶氫釜鍥剧墖璁块棶 URL
        urls = [f"/img/get/{uid}" for uid in image_uids]
        return JSONResponse(content={"urls": urls})

    except HTTPException:
        raise
    except Exception as e:
        logger.exception("Image generation endpoint exception")
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/models")
async def get_image_models(authorization: str = Header(None)):
    """
    Get available image generation models.
    """
    if not authorization:
        raise HTTPException(status_code=401, detail="Missing Authorization header")

    token = authorization.replace("Bearer ", "")
    
    # Check API key to get app_id
    account_info = await service.check_api_key(token)
    if not account_info:
        raise HTTPException(status_code=403, detail="Invalid API Key")
        
    app_id = account_info["id"]
    
    # Get models
    models = await service.get_model_list(app_id)
    if not models:
        return JSONResponse(content={}) 

    _list = []    
    for model in models:
        _list.append({"id": model.get("name", ""), "title": model.get("title", "")})  
    return JSONResponse(content=_list)

@router.get("/get/{uuid}")    
async def get_image(uuid: str, authorization: str = Header(None)):
    """
    Get image by uuid.
    鐩存帴杩斿洖鍥剧墖鐨勪簩杩涘埗鏁版嵁锛屽彲浠ュ湪 <img src="/img/get/{uuid}"> 涓?
    """
    
    # Get image from database (鍙?result 瀛?
    image_record = await service.get_image(uuid)
    if not image_record:
        raise HTTPException(status_code=404, detail="Image not found")
    
    # 瑙ｆ瀽瀛樺偍?Data URL 鏍煎紡
    # 鏁版嵁搴撴牸寮忥細"data:image/png;base64,iVBORw0..."
    try:
        data_url = image_record.get("result", "")
        
        # 濡傛灉鏄妭绫诲瀷锛岃綅涓哄瓧绗︿覆
        if isinstance(data_url, bytes):
            data_url = data_url.decode('utf-8')
        
        # 纭挎槶绗︿覆绫诲瀷
        if not isinstance(data_url, str):
            logger.error(f"Invalid data type for UUID {uuid}: {type(data_url)}")
            raise HTTPException(status_code=500, detail="Invalid image data type")
        
        # 瑙ｆ瀽 Data URL 鏍煎紡锛歞ata:image/png;base64,iVBORw0...
        if data_url.startswith("data:"):
            # 鍒?MIME 绫诲瀷?base64 鏁版嵁
            header, base64_data = data_url.split(",", 1)
            mime_type = header.split(";")[0].replace("data:", "")
            
            # 瑙ｇ爜 base64 鏁版嵁
            image_bytes = base64.b64decode(base64_data)
            
            # 杩斿洖浜岃繘鍒跺浘鐗囨暟?
            return Response(content=image_bytes, media_type=mime_type)
        else:
            logger.error(f"Invalid data URL format for UUID {uuid}: {data_url[:50]}...")
            raise HTTPException(status_code=500, detail="Invalid image data format")
            
    except ValueError as e:
        logger.error(f"Failed to parse Data URL for UUID {uuid}: {e}")
        raise HTTPException(status_code=500, detail="Invalid Data URL format")
    except Exception as e:
        logger.error(f"Error processing image data for UUID {uuid}: {e}")
        raise HTTPException(status_code=500, detail="Failed to process image data")
    

