﻿import asyncio
import httpx
import json
import base64
import os

# 閰嶇疆淇℃伅
BASE_URL = "http://127.0.0.1:8050"
# Router /image imports sub-router with prefix /img
# So base prefix is /image/img
PREFIX = "/img"

# 璇风‘淇?Token 鍦ㄦ暟鎹?api_account / xzy_api_app_key 琛ㄤ腑瀛樺湪
TOKEN = "sk-LEFP01Lv21wybB1GAo33p7z6uVG1bbzhM2YJ93a141l1xXpA"
# 妯″瀷鍚嶇О
TEST_MODEL = "baidu" 

HEADERS = {
    "Authorization": f"Bearer {TOKEN}"
}

# 杈撳嚭鐩介厤缃?OUTPUT_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(__file__))))), "data", "image")
if not os.path.exists(OUTPUT_DIR):
    os.makedirs(OUTPUT_DIR)

async def test_get_models():
    """娴嬭瘯鑾峰彇妯″瀷鍒楄〃鎺ュ彛"""
    url = f"{BASE_URL}{PREFIX}/models"
    print(f"\n--- [娴嬭瘯] 鑾峰彇妯″瀷鍒楄〃 (GET {url}) ---")
    
    async with httpx.AsyncClient() as client:
        try:
            resp = await client.get(url, headers=HEADERS)
            if resp.status_code == 200:
                models = resp.json()
                print(f"妯″瀷鍒楄〃: {json.dumps(models, indent=2, ensure_ascii=False)}")
                return models
            else:
                print(f"璇锋眰澶辫触锛欻TTP {resp.status_code} - {resp.text}")
        except Exception as e:
            print(f"寮傚父锛歿str(e)}")
    return []

async def test_image_generation():
    """娴嬭瘯鍥惧儚鐢熸垚鎺ュ彛"""
    url = f"{BASE_URL}{PREFIX}/create"
    print(f"\n--- [娴嬭瘯] 鍥惧儚鐢熸垚鎺ュ彛 (POST {url}) ---")
    
    # 浣跨敤 messages 鏍煎紡锛屾ā鎷熷墠绔?
    payload = {
        "messages": [
            {"role": "user", "content": "鍙呮弧鏈潵鎰熺殑鏈烘璧涘崥鏈嬪厠鏍肩殑楣匡紝闇撹櫣鐏咃紝楂樼粏鑺?k鍒嗚鲸?}
        ],
        "model": TEST_MODEL,
        "size": "1024*1024",
        "n": 1,
        "parameters": {
            "prompt_extend": True,
            "watermark": False
        }
    }
    
    print(f"璇锋眰鍙傛暟: {json.dumps(payload, indent=2, ensure_ascii=False)}")
    
    async with httpx.AsyncClient() as client:
        try:
            # Image generation takes time, modify timeout
            resp = await client.post(url, json=payload, headers=HEADERS, timeout=60.0)
            
            if resp.status_code == 200:
                # 鎺ュ彛鐜板湪鐩存帴杩斿洖鍒楄〃
                result = resp.json() 
                print(f"鍝嶅簲缁撴灉: {json.dumps(result, indent=2, ensure_ascii=False)}")
                
                if isinstance(result, list):
                    for idx, img in enumerate(result):
                        if "url" in img:
                            print(f"鐢熸垚鐨勫浘?URL [{idx+1}]: {img['url']}")
                            # 灏濊瘯涓嬭浇鍥剧墖
                            try:
                                img_resp = await client.get(img['url'], timeout=30.0)
                                if img_resp.status_code == 200:
                                    save_path = os.path.join(OUTPUT_DIR, f"test_gen_{idx}.png")
                                    with open(save_path, "wb") as f:
                                        f.write(img_resp.content)
                                    print(f"鍥剧墖宸蹭繚瀛樿嚦: {save_path}")
                            except Exception as e:
                                print(f"涓嬭浇鍥剧墖澶辫触: {e}")
                        elif "content" in img:
                             # 澶勭悊 content (base64) 鍥剧墖
                             try:
                                img_data = base64.b64decode(img['content'])
                                save_path = os.path.join(OUTPUT_DIR, f"test_gen_b64_{idx}.png")
                                with open(save_path, "wb") as f:
                                    f.write(img_data)
                                print(f"Base64 鍥剧墖宸蹭繚瀛樿嚦: {save_path}")
                             except Exception as e:
                                 print(f"淇濆瓨 Base64 鍥剧墖澶辫触: {e}")
                elif isinstance(result, dict) and "code" in result:
                     print(f"鐢熸垚澶辫触 (閿?{result.get('code')}): {result.get('message')}")
                else:
                    print(f"鏈熺殑鍝嶅簲鏍? {result}")
            else:
                print(f"璇锋眰澶辫触锛欻TTP {resp.status_code} - {resp.text}")
                
        except httpx.ReadTimeout:
            print("璇锋眰瓒呮椂 (ReadTimeout)锛岀敓鎴愬浘鐗囧父瑕佽緝闀挎椂闂?)
        except Exception as e:
            print(f"寮傚父锛歿str(e)}")

async def main():
    print("濮嬪浘鍍忕敓鎴愭帴鍙ｆ祴?..")
    print(f"BASE_URL: {BASE_URL}")
    print(f"TOKEN: {TOKEN[:10]}...")
    
    # 1. 娴嬭瘯妯″瀷鍒楄〃
    await test_get_models()
    
    # 2. 娴嬭瘯鍥惧儚鐢熸垚
    await test_image_generation()

if __name__ == "__main__":
    asyncio.run(main())

