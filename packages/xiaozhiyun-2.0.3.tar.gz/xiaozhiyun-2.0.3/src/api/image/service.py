﻿# Copyright (c) 2025 Bytedance Ltd. and/or its affiliates
# SPDX-License-Identifier: MIT

import json
import logging
import uuid
from typing import Optional, Dict, Any
from ..common.models.aiimg_message import AiimgMessage
from ..common.models.aiimg_usage import AiimgUsage
from ..common.models.aiimg_model import AiimgModel
from ..common.models.account import Account
from src.api.common.service import check_api_key


logger = logging.getLogger(__name__)

# Map DB platform strings to internal driver names
DRIVER_MAP = {
    "aliyun": "tongyi",
    "tencent": "tencent",
    "baidu": "baidu",
    "volcengine": "volcengine",
}

async def save_message(model_id: int, app_id: int, input: str, result: str, input_tokens: int, output_tokens: int, total_tokens: int):
    """
        淇濆瓨鍥剧墖娑堟伅
         - model_id: 妯″瀷ID
         - app_id: 搴旂敤ID
         - input: 杈撳叆锛涘師濮嬭緭鍏ョ殑json
         - result: 杈撳嚭锛涘浘鐗囨暟鎹?JSON 瀛椾覆锛堝寘鍚?base64 ?url?
         - input_tokens: 杈撳叆token?
         - output_tokens: 杈撳嚭token?
         - total_tokens: 鎬籺oken?
    """
    image_uuid = str(uuid.uuid4())
    msg = AiimgMessage(
        model_id=model_id,
        app_id=app_id,
        question=input,
        result=result,
        input_tokens=input_tokens,
        output_tokens=output_tokens,
        total_tokens=total_tokens,
        uuid=image_uuid
    )
    await msg.save()
    return image_uuid

async def get_image(uuid: str):
    """
        鑾峰彇鍥剧墖
         - uuid: 鍥剧墖ID
    """
    result = await AiimgMessage.find_one(uuid=uuid)
    return vars(result) if result else None

async def save_token_usage(app_id: int, model_id: int, input_tokens: int, output_tokens: int, total_tokens: int):
    """
        淇濆瓨token浣跨敤鎯呭喌
         - app_id: 搴旂敤ID
         - model_id: 妯″瀷ID
         - input_tokens: 杈撳叆token?
         - output_tokens: 杈撳嚭token?
         - total_tokens: 鎬籺oken?
    """
    usage = AiimgUsage(
        app_id=app_id,
        model_id=model_id,
        input_tokens=input_tokens,
        output_tokens=output_tokens,
        total_tokens=total_tokens,
        uuid=str(uuid.uuid4())
    )
    await usage.save()
async def get_model_list(app_id: str, model: str=None):
    # get app model config (convert app_id to str for varchar comparison)
    models = await AiimgModel.find_all(app_id=str(app_id), status=1)
    model_config = [vars(m) for m in models]
    logger.info(f"Model config for app_id={app_id}: {model_config}")
    # Check if model config exists before accessing properties
    if not model_config:
        logger.warning(f"Model config not found for app_id={app_id}")
        return None
    if model:
        for m in model_config:
            if m["name"] == model:
                return [m]      
    return model_config


async def get_config_by_token(token: str, model: str = "tongyi") -> Optional[Dict[str, Any]]:
    """
        閫氳繃token鑾峰彇閰嶇疆
         - token: token
         - model: 妯″瀷鍚嶇О
    """
    model = model or "tongyi"
  
    # check api key
    result = await check_api_key(token)

    if not result:
        return None
    
    app_id = result["id"]
    logger.info(f" ------- App ID: {app_id} Token: {token} Model: {model}")

    # get app model config (convert app_id to str for varchar comparison)
    model_config_list = await get_model_list(app_id, model)
    
    # If specific model not found, and we are using default "tongyi", try to find ANY image model
    if not model_config_list and model == "tongyi":
        logger.info(f"Default model 'tongyi' not found for app_id={app_id}, trying to find any available image model.")
        model_config_list = await get_model_list(app_id, None)

    if not model_config_list:
        logger.warning(f"No image model config found for app_id={app_id}")
        return None
    
    # Use the first available model
    model_config = model_config_list[0]
    logger.info(f"Selected Image Model: {model_config.get('name')} (Driver: {model_config.get('driver')})")

    model_config["params"] = json.loads(model_config["params"])
    model_id = model_config["id"]

    # Initialize account-related variables
    account_params = {}
    account_id = None
    account_platform = None

    if "account" in model_config["params"]:
        # get app model config
        acc_obj = await Account.find_one(id=model_config['params']['account'], status=1)
        account = vars(acc_obj) if acc_obj else None
        
        if not account:
            logger.warning(f"Account not found for image model {model_id}")
            return None

        account_params = json.loads(account["params"])
        account_platform = account["platform"]
        account_id = account["id"]
    else:
        # Use params directly as credentials
        account_params = model_config["params"]
        account_id = None
        account_platform = None

    db_driver = model_config.get("driver") or account_platform or "aliyun"
    driver = DRIVER_MAP.get(db_driver.lower(), "tongyi")
    
    # Extract actual model name from params if available, otherwise use defaults
    actual_model = model_config["params"].get("model") or model_config["params"].get("body", {}).get("model") or model 
    
    return {
        "base_url": model_config["params"].get("proxy"),
        "model": actual_model,
        "api_key": account_params.get("api_key") or account_params.get("access_key"),
        "driver": driver,
        "credentials": account_params, 
        "metadata": model_config["params"], # Pass model params as metadata
        "account_id": account_id,
        "model_id": model_id,
        "app_id": app_id,
        "save_chat_history": True # Default to True
    }


