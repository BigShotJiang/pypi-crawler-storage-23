﻿# Copyright (c) 2025 Bytedance Ltd. and/or its affiliates
# SPDX-License-Identifier: MIT

import json
import logging
import uuid
from typing import Optional, Dict, Any
from ..common.models.tts_model import TtsModel
from ..common.models.account import Account

from src.api.common.service import check_api_key
from async_lru import alru_cache

logger = logging.getLogger(__name__)

async def get_model_list(app_id: str, model: str=None):
    # get app model config (convert app_id to str for varchar comparison)
    models = await TtsModel.find_all(app_id=str(app_id), status=1)
    model_config = [vars(m) for m in models]
    # Check if model config exists before accessing properties
    if not model_config:
        logger.warning(f"Model config not found for app_id={app_id}")
        return None
    if model:
        for m in model_config:
            if m["name"] == model:
                return [m]      
    return model_config


@alru_cache(maxsize=500, ttl=60) # High frequency call, short TTL to allow faster config updates
async def get_config_by_token(token: str, model: str) -> Optional[Dict[str, Any]]:
    """
        閫氳繃token鑾峰彇閰嶇疆
         - token: token
         - model: 妯″瀷鍚嶇О
    """
    # check api key
    result = await check_api_key(token)

    if not result:
        return None
    
    app_id = result["id"]
    
    # get app model config (convert app_id to str for varchar comparison)
    model_config = await get_model_list(app_id, model)
    
    if not model_config:
        return None
    
    model_config = model_config[0]
    try:
        model_config["params"] = json.loads(model_config["params"]) if model_config.get("params") else {}
    except Exception:
        model_config["params"] = {}
        
    model_id = model_config["id"]


    if not model_config.get("params") or "account" not in model_config["params"]:
        logger.error(f"Model {model} params is missing 'account' mapping")
        return None

    # get app model config
    acc_obj = await Account.find_one(id=model_config['params']['account'], status=1)
    account = vars(acc_obj) if acc_obj else None
    
    if not account:
        return None

    try:
        account["params"] = json.loads(account["params"]) if account.get("params") else {}
    except Exception:
        account["params"] = {}
        
    account["platform"] = account["platform"]
    account["id"] = account["id"]
    """
    鑵剧殑account["params"] 淇℃伅
    {"api_key":"sk-o8kuXN2qENAzDZDuIpBlECXwOgEfLhiY2cnCTg3mjleXssan","app_id":null,"access_key":"AKIDo7C2h93vgGiyHZkPwFJMAneJnAVdaO5f","secret_key":"sY0JRcigbKwRkqonhU6au6Meq8JXiiV7","proxy":null,"original_heartbeat":"1","heartbeat_model":"hunyuan-standard","heartbeat_proxy":"https:\/\/api.hunyuan.cloud.tencent.com\/v1\/chat\/completions"}
    """
    """
    鐏辩殑閰嶇娇?
    {"api_key":"7d5746b2-9f2f-4039-82e9-1f1ef511f045","app_id":"4372305138","access_token":"ufQdvniGkcTvH1wkp0gl27_1GVrawAwJ","secret_key":"NKqGDQ8mQe5JghZRZW8MXZfb7yQtOkRB","cluster_id":"volcano_tts","proxy":null}
    """
    """
    闃块噷浜戠殑閰嶇疆淇℃伅
    {"api_key":"sk-40429cee1b144f27a02bc7381ac125d4","access_key":null,"secret_key":null,"proxy":null}
    """
    """
    鐧惧害鐨勯厤缃?
    {"api_key":"bce-v3\/ALTAK-ZSDCWnV8MG7k9SjhGpnrO\/551bb0d78943db0bbf8c299aea5cbf76a7ac6e66","access_key":"ALTAKI1rALeawlX1Dh48rJ1C2X","secret_key":"cc97f4d98ba1401eb672884b00422053","proxy":null,"heartbeat_model":null,"heartbeat_proxy":null}
    """

    # Map platform/driver name to internal driver names
    driver_map = {
        "bytedance": "volcengine",
        "volcengine": "volcengine",
        "ali": "aliyun",
        "aliyun": "aliyun",
        "tencent": "tencent",
        "tencet": "tencent",
        "baidu": "baidu"
    }
    
    # Prefer driver from model_config, then fallback to account platform
    db_driver = model_config.get("driver") or account.get("platform") or "aliyun"
    driver = driver_map.get(db_driver.lower(), "aliyun")
    
    logger.info(f"Model '{model}' maps to DB driver '{db_driver}', using internal driver '{driver}'")
    logger.info(f"Model config for app_id={app_id}; model_config={model_config["params"]} ;account={account["params"]}")
    return {
        "base_url": model_config["params"].get("proxy"),
        "model": model_config["params"].get("body", {}).get("model") if model_config.get("params") and isinstance(model_config["params"], dict) else model,
        "api_key": account["params"].get("api_key"),
        "driver": driver, 
        "credentials": account["params"], 
        "metadata": model_config["params"], # Pass model params as metadata
        "save_chat_history": False, 
        "token_warning": model_config.get("token_warning", 0),
        "account_id": account["id"],
        "model_id": model_id,
        "app_id": app_id
    }


