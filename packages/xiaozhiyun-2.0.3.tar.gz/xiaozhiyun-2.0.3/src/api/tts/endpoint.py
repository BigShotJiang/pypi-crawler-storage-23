﻿from typing import Optional, Annotated
from fastapi import APIRouter, HTTPException, WebSocket, WebSocketDisconnect, Depends, Query, Header
from fastapi.responses import JSONResponse
from .service import check_api_key, get_model_list, get_config_by_token
from src.servers.ws_tts import TTSWebSocketService
from src.config import config
import json
import logging
from src.core.router import LoggingAPIRouter

logger = logging.getLogger(__name__)

router = LoggingAPIRouter(tags=["tts"], prefix="/tts")




@router.websocket("/")
async def websocket_synthesize(websocket: WebSocket):
    """
    WebSocket Synthesis Endpoint.
    """
    # Get token from query params manually to avoid FastAPI blocking
    token = websocket.query_params.get("token")
    provider = websocket.query_params.get("provider")
    format = websocket.query_params.get("format", "pcm")
    if not token:
        raise HTTPException(status_code=401, detail="Missing API key")
    api_account = await check_api_key(token)
    if not api_account:
        raise HTTPException(status_code=401, detail="Invalid API key")

    if not provider:
        raise HTTPException(status_code=401, detail="Missing provider")    
    
    
    # Try to get configuration from database via token
    credentials = await get_config_by_token(token, provider)
    
    if not credentials:
        # Fallback to basic provider info, TTSWebSocketService will load defaults from tts.json
        logger.info(f"No database config found for token={token[:10]}... and provider={provider}, falling back to tts.json defaults")
        credentials = {
            "provider": provider,
            "format": format
        }
    else:
        # service.py returns 'driver', ws_tts expects 'provider'
        if "driver" in credentials and "provider" not in credentials:
            credentials["provider"] = credentials["driver"]
            
        # Ensure format from query param is respected if not set in db
        if "format" not in credentials:
            credentials["format"] = format

    service = TTSWebSocketService()
    # Note: handle_connection also calls accept(), so we should either remove it there or not call it here.
    # To avoid "Already accepted" error, let's ensure it's called once.
    # Since handle_connection is a generic service, it's better if the endpoint handles the handshake.
    # I will modify handle_connection to NOT call accept if already accepted.
    await service.handle_connection(websocket, credentials=credentials)

@router.get("/models")
async def chat_model(
    authorization: Annotated[str | None, Header()] = None
):
    """
    Get model list
    """    
    if not authorization:
        raise HTTPException(status_code=401, detail="Missing API key")
    
    token = authorization.replace("Bearer ", "")
    result = await check_api_key(token)
    
    if not result:
        raise HTTPException(status_code=401, detail="Invalid API key")
    
    """ 
    todo: 寰呯悊璋冪敤鏁版嵑
    """

    tts_config = config.tts
    _list = []
    
    # Load models from tts.json
    for key, val in tts_config.items():
        if isinstance(val, dict) and "class" in val:
            title_map = {
                "aliyun": "閫氫箟鍗冮棶锛堥樋閲屼簯锛?,
                "tencent": "鑵捐",
                "baidu": "鐧惧害",
                "volcengine": "鐏北寮曟搸"
            }
            desc_map = {
                "aliyun": "瀹炴椂璇熷悎鎴?閫氫箟鍗冮棶",
                "tencent": "灏嗘眰鏂囨湊鎴愪负闊筹紝鍚屾杩斿洖鍚堟垚闊抽鏁版崗鐩稿叧鏂囨湰淇℃伅锛岃揪鍒拌竟鍚堟垚杈规挱鏀剧殑鏁堟灉",
                "baidu": "娴佸紡鏂囨湰鍦ㄧ嚎鍚堟垚锛屾敮鎸佸绉嶉煶鑹茶緭鍑?,
                "volcengine": "鍙屽悜娴佸紡WebSocket璇熷悎鎴愶紝鏀寔鍜屾柟瑷€"
            }
            _list.append({
                "id": key,
                "object": "model",
                "created": "2026",
                "title": title_map.get(key, key),
                "owned_by": "src",
                "desc": desc_map.get(key, "")
            })
    
    # If list is empty, use the hardcoded fallback
    if not _list:
        _list = [
            {
                "id": "aliyun",
                "object": "model", 
                "created": '2026', 
                "title": "閫氫箟鍗冮棶锛堥樋閲屼簯锛?,
                "owned_by":"src",
                'desc':'瀹炴椂璇熷悎鎴?閫氫箟鍗冮棶'
            }
        ]
    data = {
        "object": "list",
        "data": _list
    }
    return JSONResponse(content=data)   


