﻿import asyncio
import httpx
import json
import base64
import os

# 閰嶇疆淇℃伅
BASE_URL = "http://127.0.0.1:8050"
PREFIX = "/audio/tts"
# 璇风‘淇?Token 鍦ㄦ暟鎹?api_account / xzy_api_app_key 琛ㄤ腑瀛樺湪
TOKEN = "sk-LEFP01Lv21wybB1GAo33p7z6uVG1bbzhM2YJ93a141l1xXpA"
# 璇风‘淇濇ā鍨?tts_model 琛ㄤ腑瀛樺湪
TEST_MODEL = "ys_tencent" 

HEADERS = {
    "Authorization": f"Bearer {TOKEN}"
}

# 杈撳嚭鐩介厤缃?OUTPUT_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(__file__))))), "data", "tts")
# 鎴栫洿鎺ヤ娇鐢ㄧ浉瀵逛簬杩愮浗鐨勮矾?
OUTPUT_DIR = "data/tts"

if not os.path.exists(OUTPUT_DIR):
    os.makedirs(OUTPUT_DIR)

async def test_get_models():
    """娴嬭瘯鑾峰彇妯″瀷鍒楄〃"""
    print("\n--- [娴嬭瘯] 鑾峰彇妯″瀷鍒楄〃 (GET /models) ---")
    url = f"{BASE_URL}{PREFIX}/models"
    async with httpx.AsyncClient() as client:
        try:
            resp = await client.get(url, headers=HEADERS)
            if resp.status_code == 200:
                print(f"鎴愬姛鑾峰彇妯″瀷鍒楄〃: {json.dumps(resp.json(), indent=2, ensure_ascii=False)}")
                return resp.json().get("models", [])
            else:
                print(f"璇锋眰澶辫触锛欻TTP {resp.status_code} - {resp.text}")
        except Exception as e:
            print(f"寮傚父锛歿str(e)}")
    return []

async def test_synthesize_post():
    """娴嬭瘯鏋佺畝鍚堟垚鎺ュ彛 (POST /synthesize)"""
    print("\n--- [娴嬭瘯] 鏋佺畝鍚堟垚鎺ュ彛 (POST /synthesize) ---")
    url = f"{BASE_URL}{PREFIX}/synthesize"
    
    # 鏋佺畝鍙傛暟锛氫粎 model ?text
    payload = {
        "text": "浣犲ソ锛岃繖鏄炴帴鍙ｆ祴璇曪紝鍙紶鍏ユā鍨嬪拰鏂?,
        "model": TEST_MODEL
    }
    
    async with httpx.AsyncClient() as client:
        try:
            resp = await client.post(url, json=payload, headers=HEADERS, timeout=30.0)
            if resp.status_code == 200:
                result = resp.json()
                if result.get("success"):
                    print(f"鍚堟垚鎴愬姛锛歿result.get('metadata')}")
                    # 澶勭悊闊虫暟鎹繚瀛?(濡傛灉鎺ュ彛杩斿洖?audio_data)
                    data = result.get("audio_data")
                    if data:
                        audio_content = base64.b64decode(data) if isinstance(data, str) else data
                        save_path = os.path.join(OUTPUT_DIR, TEST_MODEL+"_test_simple_post.mp3")
                        with open(save_path, "wb") as f:
                            f.write(audio_content)
                        print(f"闊冲凡淇濆瓨鑷?{save_path}")
                else:
                    print(f"涓氬姟澶辫触锛歿result.get('error')}")
            else:
                print(f"璇锋眰澶辫触锛欻TTP {resp.status_code} - {resp.text}")
        except Exception as e:
            print(f"寮傚父锛歿str(e)}")

async def test_websocket_synthesis():
    """娴嬭瘯 WebSocket 鏋佺畝鍚堟垚鎺ュ彛"""
    print("\n--- [娴嬭瘯] WebSocket 鏋佺畝鍚堟垚鎺ュ彛 (WS /ws/synthesize) ---")
    try:
        import websockets
    except ImportError:
        print("璇峰畨?websockets 搴撲互杩愭娴? pip install websockets")
        return

    # WebSocket 閴存潈閫氳繃 query string 浼犲叆 token
    ws_url = f"{BASE_URL.replace('http', 'ws')}{PREFIX}/ws/synthesize?token={TOKEN}"
    
    try:
        async with websockets.connect(ws_url) as websocket:
            # 1. Wait for connection event
            init_msg = await websocket.recv()
            print(f"WS 鍒濆寲鍝? {init_msg}")
            
            # 2. Send synthesize event
            payload = {
                "event": "synthesize",
                "params": {
                    "text": "娆㈣繋浣撻獙浜嬩欢椹卞姩?WebSocket 璇熷悎鎴?,
                    "model": TEST_MODEL
                }
            }
            await websocket.send(json.dumps(payload))
            
            print("绛夊緟瀹炴椂闊?..")
            save_path = os.path.join(OUTPUT_DIR, TEST_MODEL+"_test_simple_ws.mp3")
            with open(save_path, "wb") as f:
                while True:
                    msg = await websocket.recv()
                    if isinstance(msg, str):
                        data = json.loads(msg)
                        print(f"WS 浜嬩欢: {data.get('event')} - {data.get('status') or data.get('message')}")
                        if data.get("event") == "synthesis" and data.get("status") == "completed":
                            break
                        if data.get("event") == "error":
                            print(f"閿欒鎯? {data.get('message')}")
                            break
                    else:
                        f.write(msg)
                        # print(f"鏀跺埌鍒嗗潡: {len(msg)} bytes")
            print(f"WebSocket 鍚堟垚瀹屾垚锛屼繚瀛樿嚦 {save_path}")
    except Exception as e:
        print(f"WS 寮傚父: {str(e)}")

async def main():
    print("濮嬫瀬 TTS 鎺ュ彛娴嬭瘯...")
    print(f"BASE_URL: {BASE_URL}")
    print(f"TOKEN: {TOKEN[:10]}...")
    
    # 1. 鍏堥獙璇佹潈闄愬苟鑾峰彇妯″瀷
    # models = await test_get_models()
    
    # 2. 濡傛灉鑾峰彇鍒颁簡妯″瀷锛屽皾璇曠敤绗镐辅鍨嬫祴璇曞悎?
    # if models:
    #     global TEST_MODEL
    #     TEST_MODEL = models[0]["name"]
    #     print(f"浣跨敤鍙戠幇鐨勬ā鍨嬭繘琛屽悗缁? {TEST_MODEL}")
    
    # 3. 娴嬭瘯 POST 鍚堟垚
    await test_synthesize_post()
    
    # 4. 娴嬭瘯 WebSocket 鍚堟垚
    await test_websocket_synthesis()

if __name__ == "__main__":
    asyncio.run(main())

