﻿"""
WebSocket Service for Real-time STT
"""
import logging
import asyncio
import json
from typing import AsyncGenerator, Callable, Any
from fastapi import WebSocket, WebSocketDisconnect


logger = logging.getLogger(__name__)

class STTWebSocketService:
    def __init__(self):
         self.stt_service = None

    async def handle_connection(self, websocket: WebSocket, credentials: dict = None):
        """
        Handle the full lifecycle of a WebSocket STT connection.
        """
        await websocket.accept()
        logger.info("STT WebSocket connected")
        
        try:
            # Interface for sending results back to client
            async def send_callback(result: dict):
                try:
                    await websocket.send_json(result)
                except Exception as e:
                    logger.error(f"Failed to send message: {e}")

            # Audio generator reading from websocket
            async def audio_generator() -> AsyncGenerator[bytes, None]:
                try:
                    while True:
                        message = await websocket.receive()
                        if "bytes" in message:
                            audio_data = message["bytes"]
                            logger.info(f"Received audio data: {len(audio_data)} bytes")
                            yield audio_data
                        elif "text" in message:
                            data = message["text"]
                            try: 
                                cmd = json.loads(data)
                                if cmd.get("type") == "stop":
                                    logger.info("Received stop command")
                                    break
                            except Exception as e:
                                logger.error(f"Error parsing text message: {e}")
                                pass
                except WebSocketDisconnect:
                    logger.info("Client disconnected from receive loop")
                except Exception as e:
                    logger.error(f"Error receiving audio: {e}")

            # Retrieve STT configuration
            from src.config import config
            stt_config = config.stt
            if not stt_config:
                logger.error("stt.json not found or empty")
                await send_callback({"error": "STT configuration not found"})
                return

            default_provider = stt_config.get("default", "tencent")
            
            # Use provided credentials or fallback to config
            creds = credentials.copy() if credentials else {}
            
            # 閼奉亜濮╃仦鏇炵磻 mate_data 閸掍即銆婄仦鍌︾礉閺傞€涚┒妞瑰崬濮╃拠璇插絿
            if "mate_data" in creds and isinstance(creds["mate_data"], dict):
                mate_data = creds.pop("mate_data")
                for k, v in mate_data.items():
                    if k not in creds:
                        creds[k] = v

            provider = creds.get("provider") or default_provider
            
            provider_config = stt_config.get(provider)
            if not provider_config:
                error_msg = f"Config for provider '{provider}' not found in stt.json"
                logger.error(error_msg)
                await send_callback({"error": error_msg})
                return

            logger.info(f"Using STT Provider: {provider}")

            full_class_path = provider_config.get("class")
            if not full_class_path or "." not in full_class_path:
                error_msg = f"Invalid or missing class path for {provider} in stt.json"
                logger.error(error_msg)
                await send_callback({"error": error_msg})
                return

            module_path, class_name = full_class_path.rsplit(".", 1)
            
            try:
                import importlib
                module = importlib.import_module(module_path)
                ServiceClass = getattr(module, class_name)
                self.stt_service = ServiceClass()
            except Exception as e:
                logger.error(f"Failed to load STT driver {full_class_path}: {e}")
                await send_callback({"error": f"Failed to load {provider} driver."})
                return

            # Merge config values into credentials (request params take precedence)
            for k, v in provider_config.items():
                if k not in ["class", "credential_map", "base_url_indicator"] and k not in creds:
                    creds[k] = v
                    
            logger.info(f"Loaded credentials keys for {provider}: {list(creds.keys())}")

            # Handle credential mapping (e.g., app_key -> api_key)
            cred_map = provider_config.get("credential_map", {})
            for src, dst in cred_map.items():
                if creds.get(src) and not creds.get(dst):
                    creds[dst] = creds.get(src)

            # Start transcription
            # Both Aliyun and Tencent drivers seem to support 'real_time_transcribe'
            # or we can check for 'asr' if that's the preferred name.
            method_name = "real_time_transcribe"
            if not hasattr(self.stt_service, method_name):
                # Fallback check
                if hasattr(self.stt_service, "asr"):
                    method_name = "asr"
                else:
                    logger.error(f"Provider {provider} does not support a known real-time method.")
                    await send_callback({"error": f"Provider {provider} does not support real-time STT."})
                    return

            await getattr(self.stt_service, method_name)(
                audio_generator=audio_generator(),
                callback=send_callback,
                credentials=creds
            )

        except WebSocketDisconnect:
            logger.info("STT WebSocket disconnected")
        except Exception as e:
            logger.error(f"STT WebSocket error: {e}")
            try:
                await websocket.send_json({"error": str(e)})
            except:
                pass
        finally:
            try:
                await websocket.close()
            except:
                pass

