﻿"""鐭ヨ瘑搴撴湇鍔＄粺绛?""
from typing import Dict, Any, Optional
from src.config import config
from src.components.kb.rag_flow import RagFlowService
from src.components.kb.diff import DiffService


class KBServiceManager:
    """鐭ヨ瘑搴撴湇鍔＄悊鍣?""
    
    def __init__(self):
        """鍒濆寲鏈嶅姟鐞嗗櫒"""
        self.config = self._load_config()
        self.services = self._init_services()
        self.default_service = self.config.get('service', {}).get('default_service', 'ragflow')
    
    def _load_config(self):
        """鍔犺浇閰嶇疆鏂囦欢"""
        return config.get('kb', {})
    
    def _init_services(self) -> Dict[str, Any]:
        """鍒濆寲鏈嶅姟瀹?""
        services = {}
        modules = self.config.get('modules', {})
        
        # 鍒?ragflow 鏈嶅姟
        if modules.get('ragflow', {}).get('enabled', False):
            ragflow_config = modules['ragflow']
            services['ragflow'] = RagFlowService(ragflow_config)
        
        # 鍒?diff 鏈嶅姟
        if modules.get('diff', {}).get('enabled', False):
            diff_config = modules['diff']
            services['diff'] = DiffService(diff_config)
        
        return services
    
    def get_service(self, service_name: Optional[str] = None) -> Any:
        """鑾峰彇鏈嶅姟瀹炰緥"""
        service_name = service_name or self.default_service
        if service_name not in self.services:
            raise ValueError(f"Service {service_name} is not initialized or disabled")
        return self.services[service_name]
    
    async def health_check(self, service_name: Optional[str] = None) -> Dict[str, Any]:
        """鎵ф湇鍔″仴搴?""
        if service_name:
            # 鏌ユ寚瀹氭湇?
            service = self.get_service(service_name)
            return await service.health_check()
        else:
            # 鏌ユ墍鏈夋湇?
            results = {}
            for name, service in self.services.items():
                results[name] = await service.health_check()
            return results
    
    async def list_documents(self, service_name: Optional[str] = None) -> Any:
        """鍒楀嚭鏈夋枃?""
        service = self.get_service(service_name)
        return await service.list_documents()
    
    async def get_document(self, document_id: str, service_name: Optional[str] = None) -> Any:
        """鑾峰彇鍗曚釜鏂囨。璇︽儏"""
        service = self.get_service(service_name)
        return await service.get_document(document_id)
    
    async def create_document(self, file_path: str, metadata: Optional[Dict[str, Any]] = None, service_name: Optional[str] = None) -> Any:
        """鍒涘缓鏂版枃?""
        service = self.get_service(service_name)
        return await service.create_document(file_path, metadata)
    
    async def update_document(self, document_id: str, metadata: Dict[str, Any], service_name: Optional[str] = None) -> Any:
        """鏇存柊鏂囨。"""
        service = self.get_service(service_name)
        return await service.update_document(document_id, metadata)
    
    async def delete_document(self, document_id: str, service_name: Optional[str] = None) -> Any:
        """鍒犻櫎鏂囨。"""
        service = self.get_service(service_name)
        return await service.delete_document(document_id)
    
    async def query(self, question: str, top_k: int = 5, score_threshold: float = 0.7, service_name: Optional[str] = None) -> Any:
        """鏌ョ煡璇?""
        service = self.get_service(service_name)
        return await service.query(question, top_k, score_threshold)
    
    async def compare_documents(self, document_id1: str, document_id2: str, service_name: str = 'diff') -> Any:
        """姣旇緝涓や釜鏂囨。鐨勫樊?""
        service = self.get_service(service_name)
        return await service.compare_documents(document_id1, document_id2)
    
    async def compare_text(self, text1: str, text2: str, service_name: str = 'diff') -> Any:
        """姣旇緝涓ゆ枃鏈殑宸?""
        service = self.get_service(service_name)
        return await service.compare_text(text1, text2)
    
    async def get_diff_history(self, service_name: str = 'diff') -> Any:
        """鑾峰彇宸兼瘮杈冨巻鍙?""
        service = self.get_service(service_name)
        return await service.get_diff_history()
    
    async def get_diff_result(self, diff_id: str, service_name: str = 'diff') -> Any:
        """鑾峰彇宸兼瘮杈冪粨鏋?""
        service = self.get_service(service_name)
        return await service.get_diff_result(diff_id)
    
    async def delete_diff_history(self, diff_id: str, service_name: str = 'diff') -> Any:
        """鍒犻櫎宸兼瘮杈冨巻鍙?""
        service = self.get_service(service_name)
        return await service.delete_diff_history(diff_id)
    
    async def get_stats(self, service_name: Optional[str] = None) -> Dict[str, Any]:
        """鑾峰彇鏈嶅姟缁熶俊鎭?""
        if service_name:
            # 鑾峰彇鎸囧畾鏈嶅姟鐨勭粺璁′俊?
            service = self.get_service(service_name)
            return await service.get_stats()
        else:
            # 鑾峰彇鏈夋湇鍔＄殑缁熶俊鎭?            results = {}
            for name, service in self.services.items():
                results[name] = await service.get_stats()
            return results
    
    def reload_config(self) -> None:
        """閲嶆柊鍔犺浇閰嶇疆骞跺垵濮嬪寲鏈嶅姟"""
        # 閲嶆柊鍔犺浇閰嶇疆
        self.config = self._load_config()
        self.services = self._init_services()
        self.default_service = self.config.get('service', {}).get('default_service', 'ragflow')
    
    def get_service_status(self) -> Dict[str, bool]:
        """鑾峰彇鏈嶅姟鐘?""
        status = {}
        modules = self.config.get('modules', {})
        
        for service_name in ['ragflow', 'diff']:
            status[service_name] = service_name in self.services
        
        return status


# 鍒涘缓鍏ㄥ眬鏈嶅姟绠＄悊鍣ㄥ疄?
kb_service_manager = KBServiceManager()

