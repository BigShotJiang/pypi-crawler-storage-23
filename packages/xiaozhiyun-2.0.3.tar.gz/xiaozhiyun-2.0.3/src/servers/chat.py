﻿from typing import Any, Dict, List, Optional, Union, AsyncGenerator
import os
import logging
import contextvars
import datetime
import json
import uuid
from src.config import config

# Dependencies
try:
    from langchain_core.runnables import RunnableConfig
    from langchain_openai import ChatOpenAI
    from langchain_core.messages import HumanMessage, SystemMessage, AIMessage, ToolMessage, BaseMessage
except ImportError:
    RunnableConfig = Any
    ChatOpenAI = Any
    HumanMessage, SystemMessage, AIMessage, ToolMessage, BaseMessage = Any, Any, Any, Any, Any

logger = logging.getLogger(__name__)

# -------------------------------------------------------------------------
# Output Formatting Adapters
# -------------------------------------------------------------------------

class ChatService:
    """Chat Service"""
    def __init__(self):
        self._usage_context = contextvars.ContextVar("usage_context", default={})

    async def extra_usage(self):
        """鑾峰彇鏈€鍚庝竴娆¤姹傜殑鐢ㄩ噺淇℃伅"""
        return self._usage_context.get()

    async def chat(
        self,
        driver: Union[Dict[str, Any], str],
        inputs: Optional[Dict[str, Any]] = None,
        _config: Optional[Dict[str, Any]] = None,
        run_config: Optional[RunnableConfig] = None,
    ) -> Union[Dict[str, Any], AsyncGenerator]:
        """Unified chat entry point."""
        try:
            if inputs is None:
                inputs = {}
            
            logger.info(f"Process Chat Raw inputs: {inputs}")
            messages = inputs.get('messages', [])
            lc_messages = await _load_messages(messages)
            
            # Determine unique IDs for this request
            completion_id = inputs.get("completion_id") or (_config.get("completion_id") if _config else None)
            if not completion_id:
                completion_id = f"chatcmpl-{uuid.uuid4().hex}"
            
            created = inputs.get("created") or (_config.get("created") if _config else int(datetime.datetime.now().timestamp()))

            # Config processing
            llm_config = self._process_driver_config(driver, inputs)
            
            # Parameter extraction
            real_api_key, real_base_url, real_model, stream = self._extract_real_params(inputs, _config, llm_config)
            logger.info(f"Process Chat Real inputs: model={real_model}, stream={stream}")

            # LLM Initialization
            llm = self._initialize_llm(real_model, real_api_key, real_base_url, inputs, _config)
            stop = inputs.get("stop")
            if stop:
                llm = llm.bind(stop=stop)

            # Execution
            if stream:
                return await _handle_streaming(llm, lc_messages, run_config, completion_id, created, real_model, self._usage_context)
            else:
                return await _handle_non_streaming(llm, lc_messages, run_config, completion_id, created, real_model, self._usage_context)

        except Exception as e:
            logger.error(f"Process chat error: {e}", exc_info=True)
            return {"success": False, "error": str(e)}

    @staticmethod
    def _process_driver_config(driver: Union[Dict[str, Any], str], inputs: Dict[str, Any]) -> Dict[str, Any]:
        """Process driver and merge provider config into inputs."""
        llm_config = {}
        if driver and driver != "auto":
            provider_config = config.get(f'langchain.providers.{driver}', {})
            if provider_config:
                llm_config['api_key'] = os.getenv(provider_config.get('api_key_env'))
                llm_config['base_url'] = provider_config.get('base_url')
                llm_config['model'] = provider_config.get('default_model')
                
                if provider_config.get('params'):
                    for k, v in provider_config.get('params', {}).items():
                        if inputs.get(k) is None:
                            inputs[k] = v
                if inputs.get("stream", False) and provider_config.get('stream_options'):
                    inputs["stream_options"] = provider_config.get('stream_options')
        return llm_config

    @staticmethod
    def _extract_real_params(inputs: Dict[str, Any], _config: Optional[Dict[str, Any]], llm_config: Dict[str, Any]) -> tuple:
        """Resolve final API credentials and model."""
        real_api_key = (_config.get("api_key") if _config else None) or inputs.get("api_key") or llm_config.get('api_key')
        real_base_url = (_config.get("base_url") if _config else None) or inputs.get("base_url") or llm_config.get('base_url')
        real_model = inputs.get("model") or llm_config.get('model')
        stream = inputs.get("stream", False)
        return real_api_key, real_base_url, real_model, stream

    @staticmethod
    def _initialize_llm(real_model: str, real_api_key: str, real_base_url: str, inputs: Dict[str, Any], _config: Optional[Dict[str, Any]]) -> ChatOpenAI:
        """Initialize LangChain ChatOpenAI instance."""
        explicit_args = {
            "messages", "prompt", "model", "api_key", "base_url", "temperature",
            "stream", "extra_params", "timeout", "enable_web_search",
            "driver", "provider", "enable_deep_thinking", "max_retries",
            "presence_penalty", "frequency_penalty", "top_p", "max_tokens", "stop"
        }

        model_kwargs = {}
        for k, v in inputs.items():
            if k not in explicit_args and v is not None:
                model_kwargs[k] = v

        llm_params = {
            "model": real_model,
            "api_key": real_api_key,
            "base_url": real_base_url,
        }
        
        llm_params["temperature"] = inputs.get("temperature", 1.0)
        
        if inputs.get('max_retries') is not None:
            llm_params["max_retries"] = inputs.get('max_retries')
        
        timeout = (_config.get('timeout') if _config else None) or inputs.get('timeout')
        if timeout is not None:
            llm_params["timeout"] = timeout
        
        if inputs.get('presence_penalty') is not None:
            llm_params["presence_penalty"] = inputs.get('presence_penalty')
        
        if inputs.get('frequency_penalty') is not None:
            llm_params["frequency_penalty"] = inputs.get('frequency_penalty')
        
        if inputs.get('top_p') is not None:
            llm_params["top_p"] = inputs.get('top_p')
        
        if inputs.get('max_tokens') is not None:
            llm_params["max_tokens"] = inputs.get('max_tokens')
        
        if model_kwargs:
            llm_params["model_kwargs"] = model_kwargs
        
        logger.info(f"Initializing ChatOpenAI with params: {list(llm_params.keys())}")
        return ChatOpenAI(**llm_params)

async def _handle_streaming(llm: ChatOpenAI, lc_messages: List[BaseMessage], run_config: Optional[RunnableConfig], completion_id: str, created: int, model: str, usage_context: contextvars.ContextVar) -> Dict[str, Any]:
    """Handle streaming output and dispatch individual chunks."""
    from langchain_core.callbacks.manager import adispatch_custom_event
    
    usage_info = {"prompt_tokens": 0, "completion_tokens": 0, "total_tokens": 0}
    full_content = ""
    last_chunk = None
    
    async for chunk in llm.astream(lc_messages, config=run_config):
        content = chunk.content
        full_content += content
        last_chunk = chunk
        
        if hasattr(chunk, 'usage_metadata') and chunk.usage_metadata:
            new_usage = {
                "prompt_tokens": chunk.usage_metadata.get("input_tokens", 0),
                "completion_tokens": chunk.usage_metadata.get("output_tokens", 0),
                "total_tokens": chunk.usage_metadata.get("total_tokens", 0)
            }
            if new_usage["total_tokens"] > 0:
                usage_info.update(new_usage)
        
        stream_chunk = {
            "id": completion_id,
            "object": "chat.completion.chunk",
            "created": created,
            "model": model,
            "choices": [{
                "index": 0,
                "delta": {"content": content},
                "finish_reason": chunk.response_metadata.get("finish_reason")
            }]
        }
        await adispatch_custom_event("openai_chunk", stream_chunk, config=run_config)
    
    if last_chunk and usage_info["total_tokens"] == 0:
        if hasattr(last_chunk, 'response_metadata') and last_chunk.response_metadata:
            meta = last_chunk.response_metadata
            if 'usage' in meta:
                usage_info = {
                    "prompt_tokens": meta['usage'].get('prompt_tokens', 0),
                    "completion_tokens": meta['usage'].get('completion_tokens', 0),
                    "total_tokens": meta['usage'].get('total_tokens', 0)
                }
            elif 'token_usage' in meta:
                usage_info = {
                    "prompt_tokens": meta['token_usage'].get('input_tokens', 0),
                    "completion_tokens": meta['token_usage'].get('output_tokens', 0),
                    "total_tokens": meta['token_usage'].get('total_tokens', 0)
                }
    
    logger.info(f"Streaming final usage: {usage_info}")
    usage_context.set(usage_info)
    
    return {
        "generated_content": full_content,
        "stream_completed": True,
        "completion_id": completion_id,
        "created": created,
        "model": model,
        "usage": usage_info
    }

async def _handle_non_streaming(llm: ChatOpenAI, lc_messages: List[BaseMessage], run_config: Optional[RunnableConfig], completion_id: str, created: int, model: str, usage_context: contextvars.ContextVar) -> Dict[str, Any]:
    """Handle non-streaming output and return standardized dict."""
    response = await llm.ainvoke(lc_messages, config=run_config)
    
    usage_info = {"prompt_tokens": 0, "completion_tokens": 0, "total_tokens": 0}
    
    if hasattr(response, 'usage_metadata') and response.usage_metadata:
        usage_info = {
            "prompt_tokens": response.usage_metadata.get("input_tokens", 0),
            "completion_tokens": response.usage_metadata.get("output_tokens", 0),
            "total_tokens": response.usage_metadata.get("total_tokens", 0)
        }
    
    if usage_info["total_tokens"] == 0 and hasattr(response, 'response_metadata') and response.response_metadata:
        meta = response.response_metadata
        if 'usage' in meta:
            usage_info = {
                "prompt_tokens": meta['usage'].get('prompt_tokens', 0),
                "completion_tokens": meta['usage'].get('completion_tokens', 0),
                "total_tokens": meta['usage'].get('total_tokens', 0)
            }
        elif 'token_usage' in meta:
            usage_info = {
                "prompt_tokens": meta['token_usage'].get('input_tokens', 0),
                "completion_tokens": meta['token_usage'].get('output_tokens', 0),
                "total_tokens": meta['token_usage'].get('total_tokens', 0)
            }
    
    logger.info(f"Non-streaming final usage: {usage_info}")
    usage_context.set(usage_info)
    
    openai_response = _format_openai_response(response, completion_id, created, model)
    
    return {
        "response": openai_response,
        "generated_content": response.content,
        "usage": usage_info,
        "completion_id": completion_id,
        "created": created,
        "model": model
    }

def _format_openai_response(response: BaseMessage, completion_id: str, created: int, model: str) -> Dict[str, Any]:
    """Format an AIMessage into an OpenAI-compatible dictionary."""
    usage_metadata = getattr(response, 'usage_metadata', {})
    response_metadata = getattr(response, 'response_metadata', {})
    
    content = response.content
    if not isinstance(content, str):
        content = str(content) if content is not None else ""

    return {
        "id": str(completion_id),
        "object": "chat.completion",
        "created": int(created),
        "model": str(model),
        "choices": [{
            "index": 0,
            "message": {
                "role": "assistant",
                "content": content,
                "refusal": None
            },
            "finish_reason": str(response_metadata.get("finish_reason", "stop"))
        }],
        "usage": {
            "prompt_tokens": int(usage_metadata.get("input_tokens", 0)),
            "completion_tokens": int(usage_metadata.get("output_tokens", 0)),
            "total_tokens": int(usage_metadata.get("total_tokens", 0))
        }
    }

async def _load_messages(messages: Union[List[Dict[str, Any]], str]) -> List[BaseMessage]:
    """Normalize various message formats into LangChain BaseMessage objects."""
    if isinstance(messages, str):
        return [HumanMessage(content=messages)]
    
    if not isinstance(messages, list):
        return []
    
    lc_messages = []
    for m in messages:
        if not isinstance(m, dict):
            if hasattr(m, 'role') and hasattr(m, 'content'):
                m = {"role": m.role, "content": m.content}
            else:
                continue
                
        role = str(m.get("role", "user")).lower()
        content = m.get("content", "")
        
        if role in ["system"]:
            lc_messages.append(SystemMessage(content=content))
        elif role in ["assistant", "ai"]:
            lc_messages.append(AIMessage(content=content))
        elif role in ["tool", "function"]:
            lc_messages.append(ToolMessage(content=content, tool_call_id=m.get("tool_call_id", "unknown")))
        else:
            lc_messages.append(HumanMessage(content=content))
        
    return lc_messages

# Global instances and functions for easier access
_service = ChatService()

async def chat(*args, **kwargs):
    return await _service.chat(*args, **kwargs)

async def extra_usage():
    return await _service.extra_usage()

