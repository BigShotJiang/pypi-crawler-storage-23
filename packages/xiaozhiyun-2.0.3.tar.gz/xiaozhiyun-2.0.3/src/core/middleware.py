﻿import logging
from fastapi import Request
from starlette.middleware.base import BaseHTTPMiddleware
from src.core.context import set_request_context

logger = logging.getLogger(__name__)

class RequestContextMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        # Extract metadata
        url = str(request.url)
        ip = request.client.host if request.client else ""
        user_agent = request.headers.get("user-agent", "")
        
        # User information (initial state)
        web_user = ""
        admin_user = ""
        
        # Set context
        set_request_context(
            url=url,
            ip=ip,
            user_agent=user_agent,
            web_user=web_user,
            admin_user=admin_user
        )
        
        try:
            response = await call_next(request)
            return response
        except Exception as e:
            # UNHANDLED EXCEPTION CAPTURE
            # This will trigger our MySQLHandler because it's recording to the root logger
            logger.exception(f"Unhandled exception during request: {str(e)}")
            # Re-raise so the framework can still return 500 or handle it
            raise e


