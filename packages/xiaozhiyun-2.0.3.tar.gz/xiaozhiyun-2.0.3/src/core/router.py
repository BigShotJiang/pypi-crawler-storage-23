﻿import logging
import time
from typing import Callable, Any
from fastapi import Request, Response
from fastapi.routing import APIRoute
from fastapi import APIRouter as FastAPIRouter

from src.core.context import set_request_context

logger = logging.getLogger("src")

class LoggingAPIRoute(APIRoute):
    def get_route_handler(self) -> Callable:
        original_handler = super().get_route_handler()

        async def custom_handler(request: Request) -> Response:
            # AUTO-SET CONTEXT: Capture request info for any log triggered inside this route
            set_request_context(
                url=str(request.url),
                ip=request.client.host if request.client else "",
                user_agent=request.headers.get("user-agent", "")
            )
            
            try:
                # Execute the actual route logic
                return await original_handler(request)
            except Exception as e:
                # AUTOMATIC LOGGING: Capture any crash within the library's routes
                logger.exception(f"Exception in route {request.url.path}: {str(e)}")
                # Re-raise so FastAPI's exception handlers (or the user's) can catch it
                raise e

        return custom_handler

class LoggingAPIRouter(FastAPIRouter):
    """
    APIRouter that uses LoggingAPIRoute by default.
    """
    def __init__(self, *args, **kwargs):
        if "route_class" not in kwargs:
            kwargs["route_class"] = LoggingAPIRoute
        super().__init__(*args, **kwargs)

