﻿import contextvars
from typing import Optional, Dict, Any

# Context variables for request information
request_url = contextvars.ContextVar("request_url", default="")
request_ip = contextvars.ContextVar("request_ip", default="")
request_guard = contextvars.ContextVar("request_guard", default="")
request_web_user = contextvars.ContextVar("request_web_user", default="")
request_admin_user = contextvars.ContextVar("request_admin_user", default="")
request_user_agent = contextvars.ContextVar("request_user_agent", default="")

def set_request_context(url: str = "", ip: str = "", guard: str = "", web_user: str = "", admin_user: str = "", user_agent: str = ""):
    request_url.set(url)
    request_ip.set(ip)
    request_guard.set(guard)
    request_web_user.set(web_user)
    request_admin_user.set(admin_user)
    request_user_agent.set(user_agent)

def get_request_context() -> Dict[str, str]:
    return {
        "url": request_url.get(),
        "ip": request_ip.get(),
        "guard": request_guard.get(),
        "web_user": request_web_user.get(),
        "admin_user": request_admin_user.get(),
        "user_agent": request_user_agent.get()
    }

