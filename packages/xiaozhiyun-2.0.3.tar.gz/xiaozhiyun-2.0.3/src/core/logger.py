﻿import logging
import json
import uuid
import asyncio
import socket
import sys
from datetime import datetime
from src.core.context import get_request_context

class MySQLHandler(logging.Handler):
    """
    Custom logging handler that asynchronously saves logs to the xzy_log_sys table.
    """
    def __init__(self):
        super().__init__()
        self.instance_name = socket.gethostname()

    def emit(self, record):
        # Prevent recursion: don't log if the logger is from src.core.orm or this module
        # or anything related to the logging infrastructure itself
        if record.name.startswith("src.core.orm") or \
           record.name.startswith("src.api.common.models") or \
           record.name == __name__:
            return

        try:
            # Prepare log data
            log_data = self.format_record(record)
            
            # Execute asynchronously
            try:
                loop = asyncio.get_event_loop()
                if loop.is_running():
                    # We use call_soon to avoid creating a task that might be cancelled 
                    # if the loop is closing, but create_task is generally better for awaitables
                    loop.create_task(self._async_save(log_data))
                else:
                    # No running loop (e.g. startup/shutdown), ignore or print to stderr
                    pass
            except RuntimeError:
                # No event loop in this thread
                pass
        except Exception:
            self.handleError(record)

    def format_record(self, record):
        ctx = get_request_context()
        
        # Format the main message
        message = self.format(record)
        
        # Prepare context data (stack trace, line info etc)
        context = {
            "pathname": record.pathname,
            "lineno": record.lineno,
            "funcName": record.funcName,
            "threadName": record.threadName,
            "processName": record.processName,
            "logger_name": record.name
        }
        
        if record.exc_info:
            context["exception"] = self.formatException(record.exc_info)

        return {
            "instance": self.instance_name,
            "channel": record.name,
            "level": str(record.levelno),
            "level_name": record.levelname,
            "message": message,
            "context": json.dumps(context, default=str),
            "remote_addr": ctx.get("ip", ""),
            "user_agent": ctx.get("user_agent", ""),
            "created_by": ctx.get("admin_user") or ctx.get("web_user") or "",
            "uuid": str(uuid.uuid4()),
        }

    async def _async_save(self, log_data):
        try:
            from src.api.common.models.log_sys import LogSys
            log = LogSys(**log_data)
            await log.save()
        except Exception as e:
            # Last resort: print to stderr to avoid infinite logging loops
            print(f"[src-logger] Critical error saving log: {e}", file=sys.stderr)

def setup_db_logging(target_logger_name: str = "src"):
    """
    Configure the specified logger to use MySQLHandler.
    If target_logger_name is empty, it targets the root logger.
    """
    target_logger = logging.getLogger(target_logger_name)
    
    # Avoid adding multiple handlers of the same type
    for h in target_logger.handlers:
        if isinstance(h, MySQLHandler):
            return
            
    handler = MySQLHandler()
    # Simple formatter, the context structure handles details
    handler.setFormatter(logging.Formatter('%(message)s'))
    target_logger.addHandler(handler)
    
    # If it's a specific logger, we should also handle children loggers in the package
    # (By default it propagates, which is fine)


