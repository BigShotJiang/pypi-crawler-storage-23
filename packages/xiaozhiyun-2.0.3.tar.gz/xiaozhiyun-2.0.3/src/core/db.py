﻿from typing import Any, Dict, List, Optional, Union
import pymysql
try:
    from dbutils.pooled_db import PooledDB
except ImportError:
    from DBUtils.PooledDB import PooledDB
import logging

logger = logging.getLogger(__name__)

class MySQLClient:
    _pool: Optional[PooledDB] = None
    _initialized: bool = False

    @classmethod
    def init(cls, config: Optional[Dict[str, Any]] = None):
        """Initialize connection pool."""
        if cls._initialized:
            return
            
        if config is None:
            from src.config import config as app_config
            config = app_config.database.get("mysql", {})
            
        try:
            cls._pool = PooledDB(
                creator=pymysql,
                maxconnections=config.get("max_connections", 10),
                mincached=config.get("min_cached", 2),
                host=config.get("host", "localhost"),
                port=config.get("port", 3306),
                user=config.get("user"),
                password=config.get("password"),
                database=config.get("database"),
                charset=config.get("charset", "utf8mb4"),
                cursorclass=pymysql.cursors.DictCursor
            )
            logger.info("MySQL connection pool initialized successfully.")
            
            # Setup database logging (target root logger for global monitoring)
            from src.core.logger import setup_db_logging
            setup_db_logging("")
            cls._initialized = True
        except Exception as e:
            logger.error(f"Failed to initialize MySQL connection pool: {e}")
            raise

    @classmethod
    def get_connection(cls):
        if not cls._initialized:
            cls.init()
        if cls._pool is None:
            raise RuntimeError("MySQLClient not initialized. Call init() first.")
        return cls._pool.connection()

    @classmethod
    async def execute(cls, sql: str, params: Optional[Union[tuple, list]] = None) -> int:
        """Execute non-query SQL (insert, update, delete)."""
        if not cls._initialized:
            cls.init()
        with cls.get_connection() as conn:
            with conn.cursor() as cur:
                result = cur.execute(sql, params or ())
                conn.commit()
                return result

    @classmethod
    async def query(cls, sql: str, params: Optional[Union[tuple, list]] = None) -> List[Dict[str, Any]]:
        """Execute query SQL."""
        if not cls._initialized:
            cls.init()
        with cls.get_connection() as conn:
            with conn.cursor() as cur:
                cur.execute(sql, params or ())
                return cur.fetchall()

    @classmethod
    async def query_one(cls, sql: str, params: Optional[Union[tuple, list]] = None) -> Optional[Dict[str, Any]]:
        """Execute query SQL and return one result."""
        results = await cls.query(sql, params)
        return results[0] if results else None

