﻿import asyncio
import json
import uuid
from datetime import datetime
from typing import Any, Dict, List, Optional, Type, TypeVar, Union
from .db import MySQLClient

T = TypeVar("T", bound="Model")

class Field:
    def __init__(self, name: Optional[str] = None, primary_key: bool = False, auto_increment: bool = False):
        self.name = name
        self.primary_key = primary_key
        self.auto_increment = auto_increment

class ModelMeta(type):
    def __new__(cls, name, bases, attrs):
        if name == "Model":
            return super().__new__(cls, name, bases, attrs)
        
        fields = {}
        for k, v in attrs.items():
            if isinstance(v, Field):
                if v.name is None:
                    v.name = k
                fields[k] = v
        
        attrs["__fields__"] = fields
        attrs["__tablename__"] = attrs.get("__tablename__", name.lower())
        
        # Identify primary key
        pk = None
        for k, v in fields.items():
            if v.primary_key:
                pk = k
                break
        attrs["__pk__"] = pk
        
        # Default logging to False, can be overridden in subclasses
        if "__logging__" not in attrs:
            # Inherit from bases or default to False
            attrs["__logging__"] = any(getattr(b, "__logging__", False) for b in bases)
            
        return super().__new__(cls, name, bases, attrs)

class Model(metaclass=ModelMeta):
    __logging__ = False

    def __init__(self, **kwargs):
        self._original_data = {}
        for k, v in kwargs.items():
            setattr(self, k, v)
        # Store original data for change tracking
        if getattr(self, "__logging__", False):
            self._original_data = self.to_dict()

    def to_dict(self) -> Dict[str, Any]:
        """Convert model fields to dictionary."""
        return {k: getattr(self, k, None) for k in self.__fields__.keys()}

    def __setattr__(self, key, value):
        mutator = f"set_{key}_attribute"
        if hasattr(self, mutator):
            value = getattr(self, mutator)(value)
        super().__setattr__(key, value)

    def __getattribute__(self, item):
        try:
            fields = super().__getattribute__("__fields__")
            if item in fields or (item != "__fields__" and not item.startswith("_")):
                accessor = f"get_{item}_attribute"
                try:
                    method = super().__getattribute__(accessor)
                    if callable(method):
                        value = super().__getattribute__(item)
                        return method(value)
                except AttributeError:
                    pass
        except AttributeError:
            pass
            
        return super().__getattribute__(item)

    async def before_save(self): pass
    async def after_save(self): 
        if self.__logging__:
            asyncio.create_task(self._record_log("create", {}, self.to_dict()))

    async def before_update(self, **kwargs): pass
    async def after_update(self, **kwargs):
        if self.__logging__:
            # Use data from before update for 'original'
            asyncio.create_task(self._record_log("update", self._original_data, self.to_dict()))
            # Update original data after successful update
            self._original_data = self.to_dict()

    async def before_delete(self): pass
    async def after_delete(self):
        if self.__logging__:
            asyncio.create_task(self._record_log("delete", self.to_dict(), {}))

    @classmethod
    async def find_one(cls: Type[T], **conditions) -> Optional[T]:
        where = " AND ".join([f"`{k}`=%s" for k in conditions.keys()])
        sql = f"SELECT * FROM `{cls.__tablename__}` WHERE {where} LIMIT 1"
        result = await MySQLClient.query_one(sql, tuple(conditions.values()))
        if result:
            instance = cls(**result)
            if cls.__logging__:
                instance._original_data = result
            return instance
        return None

    @classmethod
    async def find_all(cls: Type[T], **conditions) -> List[T]:
        where_clause = ""
        params = []
        if conditions:
            where = " AND ".join([f"`{k}`=%s" for k in conditions.keys()])
            where_clause = f" WHERE {where}"
            params = tuple(conditions.values())
            
        sql = f"SELECT * FROM `{cls.__tablename__}`{where_clause}"
        results = await MySQLClient.query(sql, params)
        instances = []
        for row in results:
            instance = cls(**row)
            if cls.__logging__:
                instance._original_data = row
            instances.append(instance)
        return instances

    async def save(self) -> int:
        await self.before_save()
        
        fields = []
        values = []
        placeholders = []
        
        for k, v in self.__fields__.items():
            if v.auto_increment and getattr(self, k, None) is None:
                continue
            fields.append(f"`{v.name}`")
            values.append(getattr(self, k, None))
            placeholders.append("%s")
            
        sql = f"INSERT INTO `{self.__tablename__}` ({', '.join(fields)}) VALUES ({', '.join(placeholders)})"
        res = await MySQLClient.execute(sql, tuple(values))
        
        await self.after_save()
        return res

    async def update(self, **kwargs) -> int:
        if not self.__pk__:
            raise ValueError("Update requires a primary key.")
            
        pk_val = getattr(self, self.__pk__)
        if pk_val is None:
            raise ValueError("Primary key value is missing.")
            
        # Prior to update, capture state if logging is enabled
        if self.__logging__ and not self._original_data:
            self._original_data = self.to_dict()

        await self.before_update(**kwargs)
            
        sets = []
        values = []
        for k, v in kwargs.items():
            sets.append(f"`{k}`=%s")
            values.append(v)
            setattr(self, k, v)
            
        values.append(pk_val)
        sql = f"UPDATE `{self.__tablename__}` SET {', '.join(sets)} WHERE `{self.__pk__}`=%s"
        res = await MySQLClient.execute(sql, tuple(values))
        
        await self.after_update(**kwargs)
        return res

    async def delete(self) -> int:
        if not self.__pk__:
            raise ValueError("Delete requires a primary key.")
        
        pk_val = getattr(self, self.__pk__)
        if pk_val is None:
            raise ValueError("Primary key value is missing.")
            
        await self.before_delete()
        
        sql = f"DELETE FROM `{self.__tablename__}` WHERE `{self.__pk__}`=%s"
        res = await MySQLClient.execute(sql, (pk_val,))
        
        await self.after_delete()
        return res

    async def _record_log(self, action: str, original: dict, current: dict):
        """Asynchronously record log to database."""
        try:
            from .context import get_request_context
            from src.api.common.models.log_model import LogModel
            from src.api.common.models.log_model_detail import LogModelDetail
            
            ctx = get_request_context()
            log_uuid = str(uuid.uuid4())
            model_id = str(getattr(self, self.__pk__, ""))
            
            # 1. Create LogModel entry
            log = LogModel(
                model_id=model_id,
                model=self.__class__.__name__,
                action=action,
                url=ctx.get("url", ""),
                guard=ctx.get("guard", ""),
                web_user=str(ctx.get("web_user", "")),
                admin_user=str(ctx.get("admin_user", "")),
                ip=ctx.get("ip", ""),
                uuid=log_uuid,
                created_at=datetime.now(),
                updated_at=datetime.now()
            )
            await log.save()
            
            # 2. Create LogModelDetail entry
            detail_json = {
                "class": self.__class__.__name__,
                "table": self.__tablename__,
                "timestamp": datetime.now().isoformat(),
            }
            
            detail = LogModelDetail(
                detail=json.dumps(detail_json),
                attributes=json.dumps(current, default=str),
                original=json.dumps(original, default=str),
                uuid=log_uuid
            )
            await detail.save()
            
        except Exception as e:
            # We don't want logging to break the main application logic
            import logging
            logging.getLogger(__name__).error(f"Error recording log: {e}", exc_info=True)


