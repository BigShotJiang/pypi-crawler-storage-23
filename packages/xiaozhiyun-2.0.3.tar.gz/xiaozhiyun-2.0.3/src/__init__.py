from . import nodes
from . import workflows as _workflow
from .api import api as api_client_factory
from . import websocket
from .chat import chat # Import the unified chat function


async def image(provider, inputs=None):
    return await _workflow.image(provider, inputs)

async def tts(provider, inputs=None):
    return await _workflow.tts(provider, inputs)

async def asr(provider, inputs=None):
    return await _workflow.asr(provider, inputs)

# 别名支持，兼容用户习惯
stt = asr
ts = asr 

# 2. 导出子模块
# workflow: 用于访问 graph 实例
# nodes: 用于在自定义 graph 中添加节点
# api: 用于创建远程 client
# websocket: WebSocket 服务端
workflow = _workflow
api = api_client_factory

__all__ = [
    "chat",
    "image",
    "tts",
    "asr",
    "stt",
    "ts",
    "nodes",
    "workflow",
    "api",
    "websocket"
]
