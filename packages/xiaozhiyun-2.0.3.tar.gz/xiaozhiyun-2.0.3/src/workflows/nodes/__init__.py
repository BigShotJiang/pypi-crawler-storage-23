﻿from typing import Dict, Any, Callable
from .chat.node import ChatNode

def chat(inputs: Dict[str, Any] = None):
    """
    Returns a node function for a LangGraph workflow that executes a chat completion.
    """
    async def wrapper(state: Dict[str, Any], config: Any = None):
        if inputs: 
             existing = state.get("inputs", {})
             if isinstance(existing, dict):
                 state["inputs"] = {**existing, **inputs}
        return await ChatNode.process(state, config)
    return wrapper

def image(inputs: Dict[str, Any] = None):
    """Placeholder for ImageNode."""
    async def wrapper(state: Dict[str, Any], config: Any = None):
        from .image import process
        return await process(state, config)
    return wrapper

def tts(inputs: Dict[str, Any] = None):
    """Placeholder for TTSNode."""
    async def wrapper(state: Dict[str, Any], config: Any = None):
        return {"error": "TTSNode not implemented as a standalone wrapper yet"}
    return wrapper

def asr(inputs: Dict[str, Any] = None):
    """Placeholder for ASRNode."""
    async def wrapper(state: Dict[str, Any], config: Any = None):
        return {"error": "ASRNode not implemented as a standalone wrapper yet"}
    return wrapper

stt = asr

__all__ = ["chat", "image", "tts", "asr", "stt"]

