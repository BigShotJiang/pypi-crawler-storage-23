﻿from typing import TypedDict, List, Any, Optional, Dict, Union

class ChatInputs(TypedDict, total=False):
    """
    Standard LangChain/OpenAI Chat Model Parameters.
    See: https://python.langchain.com/docs/integrations/chat/openai/#parameters
    """
    messages: List[Any] # Dicts or LangChain Messages
    model: str
    prompt: Optional[str]
    
    # Standard Generation Params
    frequency_penalty: Optional[float]
    logit_bias: Optional[Dict[str, float]]
    max_tokens: Optional[int]
    n: Optional[int]
    presence_penalty: Optional[float]
    response_format: Optional[Dict[str, Any]] # {"type": "json_object"}
    seed: Optional[int]
    stop: Optional[List[str]]
    stream: Optional[bool]
    stream_options: Optional[Dict[str, Any]]
    temperature: Optional[float]
    top_p: Optional[float]
    top_logprobs: Optional[int]
    logprobs: Optional[bool]
    
    # Tooling
    tools: Optional[List[Any]]
    tool_choice: Optional[Union[str, Dict[str, Any]]]
    
    # User/System
    user: Optional[str]
    
    # Project Specific / Config
    enable_web_search: Optional[bool]
  

