﻿from typing import TypedDict, List, Any, Optional, Dict, Union

class ImageInputs(TypedDict, total=False):
    prompt:str
    model:str
    negative_prompt:str #鍙嶅悜鎻愮ず璇嶏紝鐢ㄤ簬鎻忚堪涓嶅笇鏈涘湪鍥惧儚涓囩幇鐨勫唴锛岀敾闈㈣繘闄愬埗?
    watermark:bool #鏄愭坊鍔犳按鍗?    prompt_extend:bool #鏄愬惎prompt鏅鸿兘鏀瑰啓 榛樺悪鑳芥敼?
    

    n: int #1-10 榛?1
    size: str   #榛樿緭鍑哄垎杈ㄧ巼涓?024x1024锛屽缓璁惧嚭鍒嗚鲸鐜囦负锛?                #路 閫傜敤澶村儚?["768x768", "1024x1024", "1536x1536", "2048x2048"]
                #路 閫傜敤鏂囩珷閰嶅浘 锛歔"1024x768", "2048x1536"]
                #路 閫傜敤娴锋姤浼犲崟锛歔"768x1024", "1536x2048"]
                #路 閫傜敤鐢佃剳澹佺焊锛歔"1024x576", "2048x1152"]
                #路 閫傜敤娴锋姤浼犲崟锛歔"576x1024", "1152x2048"]

