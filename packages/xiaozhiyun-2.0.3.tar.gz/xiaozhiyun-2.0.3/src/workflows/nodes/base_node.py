﻿# Base node implementation for src workflows

from typing import Dict, Any, Optional
from langgraph.graph import StateGraph, START, END
from langgraph.runtime import get_runtime


try:
    from langchain_core.runnables import RunnableConfig
except ImportError:
    RunnableConfig = Any

class BaseNode:
    """Base class for all workflow nodes.
    
    This class provides a standard interface for all workflow nodes,
    ensuring consistency across different service implementations.
    """
    
    def __init__(self, service_name: str, provider: str):
        """Initialize the base node.
        
        Args:
            service_name: Name of the service this node implements
            provider: Name of the cloud provider
        """
        self.service_name = service_name
        self.provider = provider
        self.node_name = f"{provider}_{service_name}"
    
    async def process(self, state: Dict[str, Any], run_config: Optional[RunnableConfig] = None) -> Dict[str, Any]:
        """Process the input state and return the output state.
        
        Args:
            state: Input state containing necessary data for processing
            run_config: Optional RunnableConfig for context propagation
            
        Returns:
            Output state with processed results
        """
        raise NotImplementedError("Subclasses must implement process method")
    
    def get_node_definition(self):
        """Get the node definition for LangGraph.
        
        Returns:
            A callable that can be used as a node in LangGraph
        """
        async def node_fn(state, config: RunnableConfig):
            # Pass config as run_config
            return await self.process(state, run_config=config)
        
        node_fn.__name__ = self.node_name
        return node_fn
    
    def validate_input(self, state: Dict[str, Any]) -> bool:
        """Validate the input state.
        
        Args:
            state: Input state to validate
            
        Returns:
            True if input is valid, False otherwise
        """
        raise NotImplementedError("Subclasses must implement validate_input method")

    async def process_stream(self, state: Dict[str, Any]):
        """Process the input state and return an async generator of results.
        
        Args:
            state: Input state containing necessary data for processing
            
        Yields:
            Chunks of processed results
        """
        raise NotImplementedError("Subclasses must implement process_stream method if supported")

