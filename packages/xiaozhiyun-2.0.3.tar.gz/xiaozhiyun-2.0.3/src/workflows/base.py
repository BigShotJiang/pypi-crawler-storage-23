﻿from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional, Union, TypeVar, Generic
from langgraph.graph import StateGraph
from langgraph.graph.state import CompiledGraph

T = TypeVar("T")

class BaseWorkflow(ABC, Generic[T]):
    """
    Abstract base class for LangGraph workflows.
    """
    def __init__(self):
        self.builder = self._create_builder()
        self._build_graph()
        self.graph: CompiledGraph = self.builder.compile()

    @abstractmethod
    def _create_builder(self) -> StateGraph:
        """Create the StateGraph builder with the appropriate state type."""
        pass

    @abstractmethod
    def _build_graph(self):
        """Add nodes and edges to the builder."""
        pass

    async def ainvoke(self, inputs: Dict[str, Any], config: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """Invoke the workflow asynchronously."""
        return await self.graph.ainvoke(inputs, config=config)

    async def astream(self, inputs: Dict[str, Any], config: Optional[Dict[str, Any]] = None):
        """Stream the workflow execution."""
        async for event in self.graph.astream(inputs, config=config):
            yield event

