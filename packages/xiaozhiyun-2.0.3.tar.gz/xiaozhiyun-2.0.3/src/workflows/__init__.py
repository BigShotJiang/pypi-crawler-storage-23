﻿from typing import Dict, Any
import importlib
import logging

logger = logging.getLogger(__name__)

async def _run_workflow(provider: str, service: str, inputs: Dict[str, Any] = None):
    """Dynamically loads and runs a predefined workflow graph."""
    # Normalize service name
    service_norm = service
    if service == "asr":
        service_norm = "stt"
    elif service == "sst":
        # Check if sst workflow exists, else fallback to stt
        # This is a bit hacky but keeps it flexible
        service_norm = "sst"
    
    try:
        module_path = f"src.workflows.{provider}.{service_norm}.graph.builder"
        module = importlib.import_module(module_path)
        graph = getattr(module, "graph")
        return await graph.ainvoke(inputs or {})
    except (ImportError, AttributeError) as e:
        if service == "sst":
             # Fallback to stt if sst fails
             try:
                 module_path = f"src.workflows.{provider}.stt.graph.builder"
                 module = importlib.import_module(module_path)
                 graph = getattr(module, "graph")
                 return await graph.ainvoke(inputs or {})
             except:
                 pass
        
        logger.error(f"Workflow for {provider}/{service_norm} not found: {e}")
        raise ValueError(f"Workflow for {provider}/{service} not found or not properly implemented.")

async def chat(provider: str, inputs: Dict[str, Any] = None):
    """Executes a chat workflow."""
    return await _run_workflow(provider, "chat", inputs)

async def image(provider: str, inputs: Dict[str, Any] = None):
    """Executes an image generation workflow."""
    return await _run_workflow(provider, "image", inputs)

async def tts(provider: str, inputs: Dict[str, Any] = None):
    """Executes a text-to-speech workflow."""
    return await _run_workflow(provider, "tts", inputs)

async def asr(provider: str, inputs: Dict[str, Any] = None):
    """Executes an ASR workflow."""
    return await _run_workflow(provider, "asr", inputs)

async def sst(provider: str, inputs: Dict[str, Any] = None):
    """Executes an SST workflow."""
    return await _run_workflow(provider, "sst", inputs)


