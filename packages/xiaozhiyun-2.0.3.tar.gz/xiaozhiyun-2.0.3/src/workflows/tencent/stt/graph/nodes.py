﻿from src.nodes.tencent.stt_node import tencentSTTNode

_stt_node = tencentSTTNode()
stt_node = _stt_node.get_node_definition()


