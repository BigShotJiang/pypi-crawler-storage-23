﻿from src.nodes.tencent.chat_node import tencentChatNode

_chat_node = tencentChatNode()
chat_node = _chat_node.get_node_definition()


