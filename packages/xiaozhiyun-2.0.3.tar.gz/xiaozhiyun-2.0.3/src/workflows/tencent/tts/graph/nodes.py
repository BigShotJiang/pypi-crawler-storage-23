﻿from src.nodes.tencent.tts_node import tencentTTSNode

# Create the node instance
_tts_node = tencentTTSNode()

# Get the callable for the graph
tts_node = _tts_node.get_node_definition()


