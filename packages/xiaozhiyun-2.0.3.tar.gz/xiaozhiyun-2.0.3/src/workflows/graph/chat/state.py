﻿from typing import TypedDict, Any, Dict, Optional, List
from src.api.open_ai_chat.schema import DynamicChatRequest
from src.workflows.nodes.chat.state import ChatState

class OpenAIChatState(ChatState):
    # Input
    request: DynamicChatRequest
    auth_header: Optional[str]
    
    # Context
    completion_id: str
    created: int
    intent: str
    llm_config: Optional[Dict[str, Any]]
    
    # Output/Intermediate
    generated_content: str
    response_message: Optional[Dict[str, Any]]
    
    # Stats (ChatState already has usage, but endpoint uses specific token fields)
    input_tokens: int
    output_tokens: int

    # 鐭ヨ瘑搴撳瓙 agent 绱㈢粨鏋滐紙鐖跺浘 ChatLifecycleState 浼犲叆锛岄渶鍦ㄥ０鏄庡瓙鍥炬墠鑳芥敹鍒板苟鎷兼帴缁?AI?
    knowledge_retrieval_result: Optional[Dict[str, Any]]
    
    # For SSE streaming
    # response field is inherited from ChatState


