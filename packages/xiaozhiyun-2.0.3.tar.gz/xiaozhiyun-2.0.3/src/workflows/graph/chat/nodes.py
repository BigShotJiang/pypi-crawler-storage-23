﻿import logging
import json
import uuid
import time
from typing import Dict, Any

from .state import OpenAIChatState
from src.api.open_ai_chat.service import get_config_by_token, save_message, save_token_usage
from src.workflows.nodes import chat as chat_nodes

logger = logging.getLogger(__name__)

# 绯荤粺娑堟伅鍓嶇紑锛氬瓙 agent 绱㈢粨鏋滄敞鍏ョ粰鑱婂ぉ AI 浣跨敤
RETRIEVAL_SYSTEM_PREFIX = "璇风粨鍚堜互涓嬬储缁撴灉鍥炵瓟鐢ㄦ埛闂锛歕n\n"


def _messages_with_retrieval_context(state: Dict[str, Any], request_messages: list) -> list:
    """
    濡傛灉 state 涓瓨鍦?knowledge_retrieval_result 涓旀湁鏈夋晥 content锛屽垯鍦?messages 鍓嶆敞鍏ヤ竴涓?system 娑堟伅锛?    渚涜亰澶?AI 鍙傝€冩绱㈢粨鏋滐紙涓绘祦 RAG 鍋氭硶锛夈€?    """
    out = []
    retrieval = state.get("knowledge_retrieval_result")
    logger.info("init_chat 鏀跺埌 knowledge_retrieval_result: %s", "鏈? if retrieval else "鏃?)
    if isinstance(retrieval, dict) and not retrieval.get("error"):
        content = retrieval.get("content") or ""
        if content.strip():
            out.append({"role": "system", "content": RETRIEVAL_SYSTEM_PREFIX + content.strip()})
            logger.info("injected retrieval context into chat messages, len=%s", len(content))
        else:
            logger.info("knowledge_retrieval_result 鐨?content 涓虹┖锛岃烦杩囨敞鍏?)
    elif retrieval is not None:
        logger.info("knowledge_retrieval_result 鐨?error 鎴栭潪 dict: %s", retrieval)
    for msg in request_messages:
        if hasattr(msg, "model_dump"):
            out.append(msg.model_dump())
        elif hasattr(msg, "dict"):
            out.append(msg.dict())
        elif isinstance(msg, dict):
            out.append(msg)
        else:
            out.append({"role": getattr(msg, "role", "user"), "content": getattr(msg, "content", "")})
    return out


def _log_messages_to_ai(messages: list, max_content_len: int = 2000) -> None:
    """浼犵粰 AI 鍓嶆墦鍗版瘡鏉℃秷鎭殑 role 鍜?content锛坈ontent 杩囬暱鏃舵埅鏂級"""
    for i, msg in enumerate(messages):
        role = msg.get("role", "") if isinstance(msg, dict) else getattr(msg, "role", "")
        content = msg.get("content", "") if isinstance(msg, dict) else getattr(msg, "content", "")
        if isinstance(content, list):
            content = str(content)
        text = (content or "")[:max_content_len]
        if len(content or "") > max_content_len:
            text += f"... [杩囬暱锛屽叡 {len(content)} 瀛梋"
        logger.info("浼犵粰 AI 鐨勬秷鎭痆%s] role=%s content=%s", i, role, text)
        print(f"[浼犵粰AI] messages[{i}] role={role} content={text}")  # noqa: T201

async def init_chat(state: OpenAIChatState) -> Dict[str, Any]:
    """Initialize chat session and load configuration."""
    request = state["request"]
    auth_header = state["auth_header"]
    
    # Extract token
    token = auth_header.replace("Bearer ", "") if auth_header and auth_header.startswith("Bearer ") else auth_header
    
    if not token:
        raise ValueError("Missing authorization token")

    config = await get_config_by_token(token, request.model)
    if not config:
        raise ValueError("Invalid token or model configuration")

    # 娉ㄥ叆瀛?agent 妫€绱㈢粨鏋滅粰鑱婂ぉ AI 浣跨敤锛氳嫢鏈?knowledge_retrieval_result 鍒欐敞鍏ョ郴缁熸秷鎭紙涓绘祦鍋氭硶锛?    messages = _messages_with_retrieval_context(state, request.messages)

    # 浼犵粰 AI 鍓嶆墦鍗颁紶缁?AI 鐨勬枃鏈紝渚夸簬璋冭瘯
    _log_messages_to_ai(messages)

    # Prepare standard ChatInputs for ChatNode
    chat_inputs = {
        "messages": messages,
        "model": config["model"], 
        "stream": request.stream
    }

    # Merge meta_data from DB (e.g. presence_penalty, frequency_penalty if not in request)
    meta_data = config.get("meta_data", {})
    for mk, mv in meta_data.items():
        if chat_inputs.get(mk) is None:
            chat_inputs[mk] = mv
    
    # Clean None values to allow defaults to take over
    chat_inputs = {k: v for k, v in chat_inputs.items() if v is not None}
    logger.info(f"-----------chat_inputs----------: {chat_inputs}")       
    return {
        "api_key": config["api_key"],
        "base_url": config["base_url"],
        "provider": config["provider"],
        "llm_config": config, 
        "user_id": str(config["app_id"]),
        "completion_id": f"chatcmpl-{uuid.uuid4().hex[:24]}",
        "created": int(time.time()),
        "inputs": chat_inputs
    }


async def save_history(state: OpenAIChatState) -> Dict[str, Any]:
    """Save chat history and usage."""
    config = state.get("llm_config")
    
    # input_tokens 鍜?output_tokens 鍙傛暟锛宻tate 鐩墠涔熸槸 ChatState 鐨勪竴閮ㄥ垎
    usage = state.get("usage", {}) or {}
    input_tokens = usage.get("prompt_tokens") or state.get("input_tokens", 0)
    output_tokens = usage.get("completion_tokens") or state.get("output_tokens", 0)
    
    logger.info(f"淇濆瓨鍘嗗彶锛歴ave_chat_history = {config.get('save_chat_history') if config else 'N/A'}, input_tokens={input_tokens}, output_tokens={output_tokens}")
    
    if not config:
        logger.warning("save_history: Missing llm_config in state, skipping save.")
        return {}
        
    try:
        if config.get("save_chat_history"):
            # Serialize request to JSON string
            request_obj = state.get("request")
            if hasattr(request_obj, "model_dump_json"):
                input_json = request_obj.model_dump_json() # Pydantic v2
            else:
                input_json = json.dumps(request_obj) if request_obj else "{}"
                
            output_json = state.get("generated_content", "")
            
            logger.info(f"Saving message history for model_id={config.get('model_id')}")
            await save_message(
                model_id=config["model_id"],
                input=input_json,
                output=output_json
            )
            
        if input_tokens > 0 or output_tokens > 0:
            logger.info(f"Saving token usage: prompt={input_tokens}, completion={output_tokens}")
            await save_token_usage(
                app_id=config["app_id"], 
                model_id=config["model_id"],
                prompt_tokens=input_tokens,
                completion_tokens=output_tokens
            )
    except Exception as e:
        logger.error(f"Error in save_history node: {e}", exc_info=True)
        # We don't necessarily want to fail the whole request just because history saving failed,
        # but the 500 error we're seeing might be coming from here if it's not caught.
        # For now, let's re-raise to see it properly if it was the cause of 500.
        raise
        
    return {}

