﻿from langgraph.graph import StateGraph, END
from .state import OpenAIChatState
from .nodes import init_chat, save_history
from src.workflows.nodes.chat import process, extra_usage

def build_workflow():
    """
    Build the OpenAI Chat workflow graph.
    """
    builder = StateGraph(OpenAIChatState)
    
    # Add the main chat processing node
    builder.add_node("init_chat", init_chat)
    builder.add_node("chat", process)
    builder.add_node("extra_usage", extra_usage)
    builder.add_node("save_history", save_history)
    
    # Set entry point
    builder.set_entry_point("init_chat")
    
    # Direct edge to end (simple linear flow for now)
    builder.add_edge("init_chat", "chat")
    builder.add_edge("chat", "extra_usage")
    builder.add_edge("extra_usage", "save_history")
    builder.add_edge("save_history", END)
    
    return builder.compile()

