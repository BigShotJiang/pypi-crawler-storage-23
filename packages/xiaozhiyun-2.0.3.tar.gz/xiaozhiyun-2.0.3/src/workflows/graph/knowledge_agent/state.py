﻿from typing import TypedDict, Any, Dict, List, Optional

class KnowledgeAgentState(TypedDict, total=False):
    """
    State for the standalone Knowledge Agent.
    Independent of the main lifecycle state.
    """
    # Inputs
    query: str
    knowledge: Optional[Dict[str, Any]]  # Contains question and knowledge_base
    uniai: Optional[str]                # Auth token
    
    # Outputs
    knowledge_retrieval_result: Optional[Dict[str, Any]]
    
    # Internal context or other components usage
    # (Can be extended for 'other_node' logic)

