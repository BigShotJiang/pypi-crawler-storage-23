﻿# Copyright (c) 2025 Bytedance Ltd. and/or its affiliates
# SPDX-License-Identifier: MIT

import logging
import requests
from typing import Dict, Any, List, Optional
from dataclasses import dataclass

from .state import KnowledgeAgentState
from src.config import config

logger = logging.getLogger(__name__)

@dataclass
class Resource:
    uri: str
    title: str = ""
    description: str = ""

class RAGRetriever:
    """
    Simplified RAG Retriever that uses requests to call a retrieval API.
    """
    def __init__(self, url: str, api_key: str = ""):
        self.url = url
        self.api_key = api_key

    def query_relevant_documents(self, query: str, resources: List[Resource]) -> List[Any]:
        # Implementation depends on the actual RAG service API.
        # This is a placeholder that simulates the behavior.
        # In a real scenario, this would perform a POST request to self.url.
        logger.info(f"RAGRetriever: Querying '{query}' against {len(resources)} resources at {self.url}")
        
        # Mocking the response for now as we don't have a real RAG service URL in config yet
        # If this was real:
        # resp = requests.post(self.url, json={"query": query, "uris": [r.uri for r in resources]}, headers=...)
        # return parse_resp(resp)
        
        return []

def _validate_knowledge_access(kb: list, uniai: str | None) -> bool:
    """
    璋冪敤 RAGFlow 鐭ヨ瘑搴撻壌鏉冩帴鍙ｏ紝鏍￠獙鐢ㄦ埛瀵?dataset/files 鐨勮闂潈闄愩€?    """
    validate_url = config.get("rag.validate_url")
    if not validate_url or not kb:
        if not validate_url:
            logger.info("knowledge validate: 鏈厤缃?rag.validate_url锛岃烦杩囬壌鏉?)
        else:
            logger.info("knowledge validate: knowledge_base 涓虹┖锛岃烦杩囬壌鏉?)
        return True
    
    url = f"{validate_url.rstrip('/')}/ragflow/knowledge/user/validate"
    token = (uniai or "").strip()
    if token and not token.lower().startswith("bearer "):
        token = f"Bearer {token}"
    
    headers = {"Content-Type": "application/json", "Accept": "*/*"}
    if token:
        headers["Authorization"] = token
        
    body = [
        {
            "datasetId": item.get("datasetId"),
            "files": [{"fileId": f.get("fileId")} for f in (item.get("files") or []) if isinstance(f, dict) and f.get("fileId")],
        }
        for item in kb
        if isinstance(item, dict) and item.get("datasetId")
    ]
    
    if not body:
        logger.info("knowledge validate: 鏃犳湁鏁?datasetId/files锛岃烦杩囬壌鏉?)
        return True
        
    try:
        resp = requests.post(url, json=body, headers=headers, timeout=10)
        resp.raise_for_status()
        data = resp.json()
        valid = (data.get("data") or {}).get("valid") is True
        return valid
    except Exception as e:
        logger.warning("knowledge validate: 璇锋眰寮傚父, error=%s", e)
        return False


async def retrieve_node(state: KnowledgeAgentState) -> Dict[str, Any]:
    """
    妫€绱㈢粍浠讹細鏍规嵁 knowledge.question + knowledge.knowledge_base 璋冪敤 RAGFlow 妫€绱?    缁撴灉鍐欏叆 state.knowledge_retrieval_result
    """
    knowledge = state.get("knowledge")
    if not knowledge or not isinstance(knowledge, dict):
        return {"knowledge_retrieval_result": None}
        
    question = knowledge.get("question") or ""
    kb = knowledge.get("knowledge_base") or []
    
    resources: List[Resource] = []
    dataset_ids_for_api: List[str] = []
    seen_dataset: Dict[str, None] = {}
    
    for item in kb:
        dataset_id = item.get("datasetId") if isinstance(item, dict) else None
        files = item.get("files") if isinstance(item, dict) else []
        if not dataset_id:
            continue
        if dataset_id not in seen_dataset:
            seen_dataset[dataset_id] = None
            dataset_ids_for_api.append(dataset_id)
        for f in files:
            file_id = f.get("fileId") if isinstance(f, dict) else None
            if file_id:
                resources.append(Resource(uri=f"rag://dataset/{dataset_id}#{file_id}"))

    uniai = state.get("uniai")
    if not _validate_knowledge_access(kb, uniai):
        logger.info("knowledge_agent: 閴存潈鏈€氳繃锛岃繑鍥炵┖妫€绱㈢粨鏋?)
        return {
            "knowledge_retrieval_result": {
                "query": question, "documents": [], "content": ""
            }
        }

    rag_config = config.get("rag.retriever", {})
    retriever_url = rag_config.get("url")
    
    if not retriever_url or not resources:
        return {
            "knowledge_retrieval_result": {
                "query": question,
                "documents": [],
                "error": "retriever url not configured or no resources",
            }
        }
    
    try:
        retriever = RAGRetriever(url=retriever_url, api_key=rag_config.get("api_key", ""))
        documents = retriever.query_relevant_documents(question, resources)
        
        results = []
        for doc in documents:
            results.append({
                "id": getattr(doc, "id", ""),
                "title": getattr(doc, "title", ""),
                "chunks": [
                    {"content": c.content, "similarity": getattr(c, "similarity", 0.0)}
                    for c in getattr(doc, "chunks", [])
                ],
            })
            
        all_content = " ".join(
            ch.get("content", "") for r in results for ch in r.get("chunks", [])
        )
        
        return {
            "knowledge_retrieval_result": {
                "query": question,
                "documents": results,
                "content": all_content,
            },
        }
    except Exception as e:
        logger.exception("knowledge_agent retrieve_node error: %s", e)
        return {
            "knowledge_retrieval_result": {
                "query": question, "documents": [], "error": str(e),
            },
        }

async def other_node(state: KnowledgeAgentState) -> Dict[str, Any]:
    """
    鍏朵粬缁勪欢鍗犱綅
    """
    return {}


