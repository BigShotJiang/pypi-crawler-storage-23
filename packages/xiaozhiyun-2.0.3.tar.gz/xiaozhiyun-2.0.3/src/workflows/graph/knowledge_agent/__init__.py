﻿# Copyright (c) 2025 Bytedance Ltd. and/or its affiliates
# SPDX-License-Identifier: MIT

"""
鐭ヨ瘑?Agent锛氬弬鏁板垽鏂昏冻鏃舵帴鍏ワ紝鍐呴儴鍖呯储鍙婂叾浠栫粍浠?
涓诲浘 /api/uniai/chat/completions 鍙滃埌鏈?agent 鑺傜偣锛屼笉鏆撮湶鍐呴儴绱㈢瓑缁勪欢?
"""

from .builder import build_knowledge_agent

__all__ = ["build_knowledge_agent"]

