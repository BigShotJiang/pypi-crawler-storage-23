﻿# Copyright (c) 2025 Bytedance Ltd. and/or its affiliates
# SPDX-License-Identifier: MIT

from langgraph.graph import StateGraph, START, END

from .state import KnowledgeAgentState
from .nodes import retrieve_node, other_node


def build_knowledge_agent():
    """
    鏋勫缓鐭ヨ瘑?Agent 鍥撅細鍐呴儴鍖呭惈绱佸叾浠栫粍浠剁瓑锛屽浠呮毚闇蹭负涓€涓?agent 鑺傜偣?
    涓诲浘 /api/uniai/chat/completions 鍙滃埌鏈瓙鍥撅紝涓嶇湅鍒板唴閮?retrieve 绛夎妭鐐?
    """
    builder = StateGraph(KnowledgeAgentState)
    builder.add_node("retrieve", retrieve_node)
    builder.add_node("other", other_node)
    builder.add_edge(START, "retrieve")
    builder.add_edge("retrieve", "other")
    builder.add_edge("other", END)
    return builder.compile()

