﻿from typing import TypedDict, Any, Dict, List, Optional
from src.workflows.nodes.image.state import ImageState as BaseImageState

class ImageState(BaseImageState):
    """
    Represents the state of the Image Generation workflow.
    Extends base ImageState from src.
    
    缁ф壙鐨勫瓧娈碉紙鏉ヨ嚜 BaseImageState锛夛細
    - inputs: ImageInputs
    - provider: str
    - response: Optional[Dict[str, Any]]  # 鍖呭惈 images, status, error
    - usage: Optional[dict]
    """
    # deer-flow 鐗规湁鐨勯厤缃掑弬鏁?    config: Dict[str, Any]  # Configuration including credentials, model, etc.
    
    # 渚挎嵎璁块棶瀛楋紙涓?inputs 涓氬瓧瀵瑰簲?
    prompt: str             
    size: str               
    n: int                  
    negative_prompt: Optional[str]
    parameters: Dict[str, Any] 
    
    # 涓楁暟鎹?    token_info: Optional[Dict[str, int]]  # 鐢ㄤ簬淇濆瓨娑堟伅鏃剁殑 token 缁?    image_uids: Optional[List[str]]  # 鐢ㄤ簬淇濆瓨娑堟伅鏃剁殑 image uids 鍒楄〃


