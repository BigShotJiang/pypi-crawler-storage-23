﻿import logging
from typing import Dict, Any

from src.hub.common.factory import ImageDriverFactory
from .state import ImageState
from src.api.image import service
import json

logger = logging.getLogger(__name__)

async def init_node(state: ImageState) -> Dict[str, Any]:
    """
    Node that initializes the image generation process.
    """
    config = state.get("config", {})
    
    # Prepare standard inputs for generic ImageNode
    inputs = {
        "prompt": state.get("prompt"),
        "model": config.get("model"),
        "n": state.get("n", 1),
        "size": state.get("size", "1024*1024"),
        "negative_prompt": state.get("negative_prompt"),
        "provider": config.get("driver", "aliyun"),
        "api_key": config.get("api_key"),
        "credentials": {**config.get("credentials", {}), **config.get("metadata", {})},
    }
    
    # Merge additional parameters
    if state.get("parameters"):
        inputs.update(state["parameters"])
        
    return {
        "inputs": inputs,
        "provider": inputs["provider"],
        "status": "initialized"
    }

async def image_generator_node(state: ImageState) -> Dict[str, Any]:
    """
    Node that executes the image generation using the configured driver.
    """
    config = state.get("config", {})
    prompt = state.get("prompt")
    size = state.get("size", "1024*1024")
    n = state.get("n", 1)
    
    driver_name = config.get("driver", "aliyun")
    
    credentials = {**config.get("credentials", {}), **config.get("metadata", {})}
    # Prepare arguments for the driver
    driver_kwargs = {
        **state.get("parameters", {}),
        "credentials": credentials,
        "api_key": config.get("api_key"),
        "model": config.get("model"),
        "negative_prompt": state.get("negative_prompt")
    }
    
    # Remove None values
    driver_kwargs = {k: v for k, v in driver_kwargs.items() if v is not None}

    try:
        # Pass kwargs to driver init in case it needs them
        driver = ImageDriverFactory.get_driver(driver_name, **driver_kwargs)
    except ValueError as e:
        logger.error(f"Driver error: {e}")
        return {
            "status": "failed", 
            "error": str(e)
        }

    logger.info(f"Generating image with {driver_name}: {prompt[:50]}...")

    try:
        result = await driver.generate(
            prompt=prompt,
            size=size,
            n=n,
            **driver_kwargs
        )
        
        if result.get("success"):
            return {
                "images": result.get("images", []),
                "status": "completed",
                "usage": result.get("usage", {}),
                "error": None
            }
        else:
            return {
                "status": "failed",
                "error": result.get("error", "Unknown error from driver")
            }
            
    except Exception as e:
        logger.exception(f"Unexpected error in image_generator_node")
        return {
            "status": "failed", 
            "error": f"Unexpected error: {str(e)}"
        }

async def save_message_node(state: ImageState) -> Dict[str, Any]:
    """Node to save generation history to DB."""
    config = state.get("config", {})

    # Calculate tokens (placeholder logic as per previous implementation)
    n = state.get("n", 1)
    input_tokens = 0
    # Usage data might be available in state
    usage = state.get("usage", {})
    output_tokens = usage.get("image_count", n) * 1000 
    total_tokens = input_tokens + output_tokens
    
    # Store token info in state for next node
    state["token_info"] = {
        "input_tokens": input_tokens,
        "output_tokens": output_tokens,
        "total_tokens": total_tokens
    }
    image_uid = None
    try:
        # Construct input/output JSON strings
        # Input: The original parameters
        input_data = {
            "prompt": state.get("prompt"),
            "size": state.get("size"),
            "n": n,
            "negative_prompt": state.get("negative_prompt"),
            "parameters": state.get("parameters")
        }
        
        # ?response 涓?images锛堢粺鍝嶅簲缁撴瀯?
        response = state.get("response", {})
        images = response.get("images", [])
        
        # 濡傛灉 response 涓?images锛屽皾璇曠洿鎺ヤ粠 state 鑾峰彇
        if not images:
            logger.warning("No images found in response, trying to get from state directly")
            images = state.get("images", [])
        
        logger.info(f"Processing {len(images)} images for saving")
        
        # 涓烘瘡寮犲浘鐗囧崟鐙垮瓨锛岀敓鎴愮嫬?UUID
        # images 鏍煎紡锛歔{"url": "...", "content_type": "..."}, {"base64": "...", "content_type": "..."}]
        image_uids = []
        
        # Import httpx for downloading images
        import httpx
        import base64
        
        async with httpx.AsyncClient() as client:
            for idx, img in enumerate(images):
                data_url = None
                content_type = img.get("content_type", "image/png")
                
                # 澶勭悊 base64 鏍煎紡鐨勫浘?
                if "base64" in img:
                    base64_data = img["base64"]
                    data_url = f"data:{content_type};base64,{base64_data}"
                    logger.info(f"Image {idx+1}/{len(images)} is in base64 format")
                
                # 澶勭悊 URL 鏍煎紡鐨勫浘鐗囷紝涓嬭浇骞惰浆鎹?base64
                elif "url" in img:
                    url = img["url"]
                    logger.info(f"Image {idx+1}/{len(images)} is URL format, downloading from: {url[:100]}...")
                    try:
                        response = await client.get(url, timeout=30.0)
                        response.raise_for_status()
                        image_bytes = response.content
                        base64_data = base64.b64encode(image_bytes).decode('utf-8')
                        data_url = f"data:{content_type};base64,{base64_data}"
                        logger.info(f"Successfully downloaded and converted image {idx+1}/{len(images)}")
                    except Exception as e:
                        logger.error(f"Failed to download image from {url}: {e}")
                        continue
                else:
                    logger.warning(f"Image {idx+1} has neither 'base64' nor 'url' field, skipping: {img}")
                    continue
                
                # 淇濆瓨鍥剧墖鍒版暟鎹?                if data_url:
                    uid = await service.save_message(
                        model_id=config["model_id"],
                        app_id=config["app_id"],
                        input=json.dumps(input_data, ensure_ascii=False),
                        result=data_url,  # 瀛樺偍鍗曞紶鍥剧墖?Data URL
                        input_tokens=input_tokens,
                        output_tokens=output_tokens,
                        total_tokens=total_tokens
                    )
                    image_uids.append(uid)
                    logger.info(f"Saved image {idx+1}/{len(images)} to DB with UUID: {uid}")
        
        logger.info(f"Successfully saved {len(image_uids)} images to DB")
    except Exception as e:
        logger.error(f"Failed to save message: {e}")
        # We don't fail the workflow if saving fails, but log it
        return {"error": f"Save message failed: {str(e)}"}

    return {"image_uids": image_uids}  # 杩斿洖 UUID 鍒楄〃

async def save_usage_node(state: ImageState) -> Dict[str, Any]:
    """Node to save token usage to DB."""
    config = state.get("config", {})
    if not config.get("save_chat_history", True):
        return {}
        
    token_info = state.get("token_info", {})
    if not token_info:
        # Recalculate if missed (shouldn't happen if connected properly)
        n = state.get("n", 1)
        usage = state.get("usage", {})
        token_info = {
            "input_tokens": 0,
            "output_tokens": usage.get("image_count", n) * 1000,
            "total_tokens": usage.get("image_count", n) * 1000
        }

    try:
        await service.save_token_usage(
            app_id=config["app_id"],
            model_id=config["model_id"],
            input_tokens=token_info["input_tokens"],
            output_tokens=token_info["output_tokens"],
            total_tokens=token_info["total_tokens"]
        )
        logger.debug("Saved image token usage to DB")
    except Exception as e:
        logger.error(f"Failed to save usage: {e}")
        return {"error": f"Save usage failed: {str(e)}"}
        
    return {}

