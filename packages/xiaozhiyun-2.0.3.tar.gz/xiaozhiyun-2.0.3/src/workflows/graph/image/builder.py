﻿from langgraph.graph import END, START, StateGraph

from .nodes import image_generator_node, save_message_node, save_usage_node, init_node
from .state import ImageState
from src.workflows.nodes.image import process as generate, extra_usage


def build_graph():
    """Build and return the image generation workflow graph."""
    builder = StateGraph(ImageState)
    
    # Add Nodes
    builder.add_node("init", init_node)#鏁寸悊鍙傛暟
    builder.add_node("generate", generate)#鐢熸垚鍥剧墖
    builder.add_node("extra_usage", extra_usage)#缁熶娇鐢ㄦ儏鍐?    builder.add_node("save_message", save_message_node)#淇濆瓨娑堟伅
    builder.add_node("save_usage", save_usage_node)#淇濆瓨浣跨敤鎯呭喌
    
    # Define Edges
    # Flow: Start -> Generator -> Save Message -> Save Usage -> End
    builder.add_edge(START, "init")
    builder.add_edge("init", "generate")
    builder.add_edge("generate", "extra_usage")
    builder.add_edge("extra_usage", "save_message")
    builder.add_edge("save_message", "save_usage")
    builder.add_edge("save_usage", END)
    
    return builder.compile()


