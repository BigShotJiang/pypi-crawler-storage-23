﻿from typing import TypedDict, Any, Dict, List, Optional
from src.workflows.nodes.chat.state import ChatState

class ChatLifecycleState(ChatState):
    """
    Main state for the chat lifecycle coordination.
    """
    # Intent tracking
    intent: str  # e.g., "chat", "image"
    
    # Flags or parameters to control flow
    use_knowledge: bool
    
    # Context data
    query: str
    auth_header: Optional[str] # Used as 'uniai' by knowledge_agent sometimes
    uniai: Optional[str]       # Explicitly used by knowledge_agent
    
    # Knowledge input structure expected by knowledge_agent
    knowledge: Optional[Dict[str, Any]]
    
    # Knowledge output
    knowledge_retrieval_result: Optional[Dict[str, Any]]
    
    # Final consolidated response
    # (Inherited from ChatState)

