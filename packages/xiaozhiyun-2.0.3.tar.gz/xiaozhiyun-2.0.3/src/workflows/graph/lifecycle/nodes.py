﻿from typing import Dict, Any, Literal
from .state import ChatLifecycleState

async def route_before_intent(state: ChatLifecycleState) -> Literal["knowledge_agent", "detect_intent"]:
    """
    Decide whether to query the knowledge agent first.
    """
    if state.get("use_knowledge"):
        return "knowledge_agent"
    return "detect_intent"

async def detect_intent_node(state: ChatLifecycleState):
    """
    Simple intent detection logic.
    For demonstration, we check for keywords in the query.
    """
    query = state.get("query", "").lower()
    
    if any(kw in query for kw in ["鐢?, "鍥剧墖", "鐢熸垚鐓х墖", "image", "draw"]):
        intent = "image"
    else:
        intent = "chat"
    
    return {"intent": intent}

def route_intent(state: ChatLifecycleState) -> Literal["chat_subgraph", "image_subgraph"]:
    """
    Route to the appropriate subgraph based on detected intent.
    """
    intent = state.get("intent", "chat")
    if intent == "image":
        return "image_subgraph"
    return "chat_subgraph"

