﻿from langgraph.graph import StateGraph, START, END
from .state import ChatLifecycleState
from .nodes import detect_intent_node, route_before_intent, route_intent
from src.workflows.nodes.knowledge import build_knowledge_agent

# Import sub-workflow facade
import src.workflows.graph as graph

def build_chat_lifecycle_graph():
    """
    Build the main chat lifecycle graph that routes to specific sub-workflows
    based on intent detection.
    """
    builder = StateGraph(ChatLifecycleState)
    
    # 1. Register main lifecycle nodes
    builder.add_node("knowledge_agent", build_knowledge_agent())
    builder.add_node("detect_intent", detect_intent_node)
    
    # 2. Register sub-workflows as nodes (Subgraphs)
    builder.add_node("chat_subgraph", graph.chat())
    builder.add_node("image_subgraph", graph.image())
    
    # 3. Define Entry logic (Conditional)
    builder.add_conditional_edges(
        START,
        route_before_intent,
        {
            "knowledge_agent": "knowledge_agent",
            "detect_intent": "detect_intent"
        }
    )
    
    # 4. Knowledge flow back to intent detection
    builder.add_edge("knowledge_agent", "detect_intent")
    
    # 5. Intent routing (Conditional)
    builder.add_conditional_edges(
        "detect_intent",
        route_intent,
        {
            "chat_subgraph": "chat_subgraph",
            "image_subgraph": "image_subgraph"
        }
    )
    
    # 6. Final edges to END
    builder.add_edge("chat_subgraph", END)
    builder.add_edge("image_subgraph", END)
    
    return builder.compile()

