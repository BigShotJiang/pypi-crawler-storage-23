﻿from src.nodes.aliyun.chat_node import AliyunChatNode

# Create the node instance
_chat_node = AliyunChatNode()

# Get the callable for the graph
chat_node = _chat_node.get_node_definition()


