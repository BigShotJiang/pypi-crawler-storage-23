﻿from typing import TypedDict, Optional, Any, Dict

class ChatState(TypedDict):
    # Inputs
    prompt: str
    model: Optional[str]
    temperature: Optional[float]
    max_tokens: Optional[int]
    
    # Outputs
    response: Optional[Dict[str, Any]]
    error: Optional[str]


