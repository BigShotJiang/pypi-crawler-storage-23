﻿from langgraph.graph import StateGraph, START, END
from .state import ChatState
from .nodes import chat_node

# Initialize the graph
workflow = StateGraph(ChatState)

# Add nodes
workflow.add_node("chat", chat_node)

# Add edges
workflow.add_edge(START, "chat")
workflow.add_edge("chat", END)

# Compile the graph
graph = workflow.compile()


