﻿from typing import TypedDict, Optional, Any

class TTSState(TypedDict):
    # Inputs
    text: str
    voice: Optional[str]
    speed: Optional[float]
    volume: Optional[float]
    format: Optional[str]
    sample_rate: Optional[int]
    
    # Outputs
    audio_url: Optional[str]
    audio_content: Optional[bytes]
    error: Optional[str]


