﻿from src.nodes.aliyun.tts_node import AliyunTTSNode

# Create the node instance
_tts_node = AliyunTTSNode()

# Get the callable for the graph (non-streaming)
tts_node = _tts_node.get_node_definition()

# Expose streaming method for WebSocket use cases
async def tts_stream(state):
    """Stream TTS audio via WebSocket protocol."""
    async for chunk in _tts_node.process_stream(state):
        yield chunk


