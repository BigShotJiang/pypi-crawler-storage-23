﻿from langgraph.graph import StateGraph, START, END
from .state import TTSState
from .nodes import tts_node

# Initialize the graph
workflow = StateGraph(TTSState)

# Add nodes
workflow.add_node("tts", tts_node)

# Add edges
workflow.add_edge(START, "tts")
workflow.add_edge("tts", END)

# Compile the graph
graph = workflow.compile()


