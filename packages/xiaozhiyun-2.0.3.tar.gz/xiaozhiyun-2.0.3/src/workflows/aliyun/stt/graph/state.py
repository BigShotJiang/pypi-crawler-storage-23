﻿from typing import TypedDict, Optional, Any

class STTState(TypedDict):
    # Inputs
    audio_url: Optional[str]
    audio_content: Optional[str] # base64
    model: Optional[str]
    language: Optional[str]
    format: Optional[str]
    sample_rate: Optional[int]
    
    # Outputs
    text: Optional[str]
    error: Optional[str]


