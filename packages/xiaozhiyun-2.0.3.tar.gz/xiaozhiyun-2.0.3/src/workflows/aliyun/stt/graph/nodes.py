﻿from src.nodes.aliyun.stt_node import AliyunSTTNode

# Create the node instance
_stt_node = AliyunSTTNode()

# Get the callable for the graph
stt_node = _stt_node.get_node_definition()


