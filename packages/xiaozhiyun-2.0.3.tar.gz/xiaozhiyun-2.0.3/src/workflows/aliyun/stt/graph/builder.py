﻿from langgraph.graph import StateGraph, START, END
from .state import STTState
from .nodes import stt_node

# Initialize the graph
workflow = StateGraph(STTState)

# Add nodes
workflow.add_node("stt", stt_node)

# Add edges
workflow.add_edge(START, "stt")
workflow.add_edge("stt", END)

# Compile the graph
graph = workflow.compile()


