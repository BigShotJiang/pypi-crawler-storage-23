﻿from src.nodes.aliyun.image_node import AliyunImageNode

# Create the node instance
_image_node = AliyunImageNode()

# Get the callable for the graph
image_node = _image_node.get_node_definition()


