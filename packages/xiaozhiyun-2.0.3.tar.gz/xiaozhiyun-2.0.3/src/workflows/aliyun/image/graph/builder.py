﻿from langgraph.graph import StateGraph, START, END
from .state import ImageState
from .nodes import image_node

# Initialize the graph
workflow = StateGraph(ImageState)

# Add nodes
workflow.add_node("image", image_node)

# Add edges
workflow.add_edge(START, "image")
workflow.add_edge("image", END)

# Compile the graph
graph = workflow.compile()


