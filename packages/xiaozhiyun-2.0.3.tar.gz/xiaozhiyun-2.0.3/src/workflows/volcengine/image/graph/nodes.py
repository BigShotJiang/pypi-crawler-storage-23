﻿from src.nodes.volcengine.image_node import VolcengineImageNode

# Create the node instance
_image_node = VolcengineImageNode()

# Get the callable for the graph
image_node = _image_node.get_node_definition()


