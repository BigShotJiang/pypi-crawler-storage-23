﻿from src.nodes.volcengine.tts_node import VolcengineTTSNode

# Create the node instance
_tts_node = VolcengineTTSNode()

# Get the callable for the graph
tts_node = _tts_node.get_node_definition()


