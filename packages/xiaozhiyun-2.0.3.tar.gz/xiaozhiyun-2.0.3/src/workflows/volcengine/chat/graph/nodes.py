﻿from src.nodes.volcengine.chat_node import VolcengineChatNode

_chat_node = VolcengineChatNode()
chat_node = _chat_node.get_node_definition()


