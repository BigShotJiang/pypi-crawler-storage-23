﻿from src.nodes.volcengine.stt_node import VolcengineSTTNode

_stt_node = VolcengineSTTNode()
stt_node = _stt_node.get_node_definition()


