﻿from typing import Dict, Type, Optional
from .base import BaseWorkflow

class WorkflowManager:
    """
    Manager for LangGraph workflows.
    """
    _workflows: Dict[str, BaseWorkflow] = {}

    @classmethod
    def register(cls, name: str, workflow: BaseWorkflow):
        cls._workflows[name] = workflow

    @classmethod
    def get_workflow(cls, name: str) -> Optional[BaseWorkflow]:
        return cls._workflows.get(name)

    @classmethod
    async def ainvoke(cls, name: str, inputs: Dict, config: Optional[Dict] = None):
        workflow = cls.get_workflow(name)
        if not workflow:
            raise ValueError(f"Workflow {name} not found.")
        return await workflow.ainvoke(inputs, config=config)

