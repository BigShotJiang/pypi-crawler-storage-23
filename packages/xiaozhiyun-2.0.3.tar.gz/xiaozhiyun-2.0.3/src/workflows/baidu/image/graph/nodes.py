﻿from src.nodes.baidu.image_node import BaiduImageNode

# Create the node instance
_image_node = BaiduImageNode()

# Get the callable for the graph
image_node = _image_node.get_node_definition()


