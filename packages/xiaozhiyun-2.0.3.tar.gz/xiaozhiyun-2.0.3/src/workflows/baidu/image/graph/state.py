﻿from typing import TypedDict, Optional, Any, Dict

class ImageState(TypedDict):
    # Inputs
    prompt: Optional[str]      # For generation
    image_url: Optional[str]   # For processing
    task_type: Optional[str]   # "generate" or "process"
    size: Optional[str]
    style: Optional[str]
    
    # Outputs
    response: Optional[Dict[str, Any]]
    error: Optional[str]


