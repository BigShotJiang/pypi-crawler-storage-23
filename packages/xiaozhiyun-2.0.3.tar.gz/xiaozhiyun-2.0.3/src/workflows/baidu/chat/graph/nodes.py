﻿from src.nodes.baidu.chat_node import BaiduChatNode

_chat_node = BaiduChatNode()
chat_node = _chat_node.get_node_definition()


