﻿from src.nodes.baidu.tts_node import BaiduTTSNode

# Create the node instance
_tts_node = BaiduTTSNode()

# Get the callable for the graph
tts_node = _tts_node.get_node_definition()


