﻿from src.nodes.baidu.stt_node import BaiduSTTNode

_stt_node = BaiduSTTNode()
stt_node = _stt_node.get_node_definition()


