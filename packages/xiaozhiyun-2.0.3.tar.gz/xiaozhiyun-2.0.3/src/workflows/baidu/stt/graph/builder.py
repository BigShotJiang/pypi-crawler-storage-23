﻿from langgraph.graph import StateGraph, START, END
from .state import STTState
from .nodes import stt_node

workflow = StateGraph(STTState)
workflow.add_node("stt", stt_node)
workflow.add_edge(START, "stt")
workflow.add_edge("stt", END)
graph = workflow.compile()


