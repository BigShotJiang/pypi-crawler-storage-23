﻿import json
import os
from pathlib import Path
from typing import Dict, Any, List, Optional, Union
from pydantic import BaseModel, create_model


class ConfigLoader:
    """閰嶇疆鍔犺浇鍣?""
    _instance = None
    _configs: Dict[str, Any] = {}
    _config_paths: Dict[str, Path] = {}
    
    def _get_config_files(self) -> List[str]:
        """鑾峰彇閰嶇疆鐩綍涓嬬殑鎵€鏈塉SON閰嶇疆鏂囦欢"""
        config_dir = Path(__file__).parent
        config_files = []
        
        # 鎵弿config鐩綍涓嬬殑鎵€鏈塉SON鏂囦欢
        for json_file in config_dir.glob("*.json"):
            # 鎺掗櫎鍙兘鐨勪复鏃舵枃浠?or 闅愯棌鏂囦欢
            if not json_file.name.startswith('.'):
                # 鑾峰彇鏂囦欢鍚嶏紙涓嶅惈鎵╁睍鍚嶏級浣滀负閰嶇疆鍚嶇О
                config_name = json_file.stem
                config_files.append(config_name)
        
        return config_files

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(ConfigLoader, cls).__new__(cls)
            cls._instance._load_configs()
        return cls._instance

    def _load_configs(self):
        """鍔犺浇鎵€鏈夐厤缃枃浠?""
        # 鑾峰彇config鐩綍璺緞
        config_dir = Path(__file__).parent
        
        # 閲嶇疆閰嶇疆
        self._configs = {}
        self._config_paths = {}

        # 鑾峰彇閰嶇疆鏂囦欢鍒楄〃
        config_files = self._get_config_files()

        # 鍔犺浇鎵€鏈夐厤缃枃浠?
        for config_name in config_files:
            config_path = config_dir / f"{config_name}.json"
            if config_path.exists():
                self._config_paths[config_name] = config_path
                self._load_config_file(config_name, config_path)
            else:
                print(f"[src] Warning: {config_name}.json not found in {config_dir}")
                self._configs[config_name] = {}

    def _load_config_file(self, config_name: str, config_path: Path):
        """鍔犺浇閰嶇疆鏂囦欢"""
        try:
            with open(config_path, "r", encoding="utf-8") as f:
                data = json.load(f)
                # 瀵逛簬绠€鍗曢厤缃紙濡俿tt銆乼ts锛夛紝鐩存帴浣跨敤瀛楀吀
                # 瀵逛簬澶嶆潅閰嶇疆锛屽垱寤哄姩鎬佹ā鍨?
                if config_name in ["stt", "tts"]:
                    self._configs[config_name] = data
                else:
                    # 鍒涘缓鍔ㄦ€侀厤缃ā鍨?
                    config_model = self._create_config_model(config_name, data)
                    self._configs[config_name] = config_model
        except Exception as e:
            print(f"[src] Error loading {config_name}.json from {config_path}: {e}")
            self._configs[config_name] = {}

    def _create_config_model(self, config_name: str, data: Dict[str, Any]) -> Any:
        """鍒涘缓鍔ㄦ€侀厤缃ā鍨?""
        # 瀵逛簬澶嶆潅閰嶇疆锛屼娇鐢ㄥ瓧鍏稿舰寮忓瓨鍌紝鏂逛究鍚庣画璁块棶
        return data

    def __getattr__(self, name: str) -> Any:
        """鍔ㄦ€佽幏鍙栭厤缃睘鎬?""
        if name in self._configs:
            return self._configs[name]
        elif name in ["langchain", "langgraph", "database", "kb", "stt", "tts"]:
            # 濡傛灉閰嶇疆涓嶅瓨鍦紝灏濊瘯閲嶆柊鍔犺浇
            self._load_configs()
            return self._configs.get(name, {})
        raise AttributeError(f"ConfigLoader has no attribute '{name}'")

    def get(self, key: str, default: Any = None) -> Any:
        """鑾峰彇閰嶇疆鍊硷紝鏀寔鐐硅〃绀烘硶璁块棶宓屽灞炴€?
        渚嬪锛歝onfig.get('kb.default_provider')
        """
        parts = key.split('.')
        if not parts:
            return default
        
        # 绗竴涓儴鍒嗘槸閰嶇疆妯″潡鍚?
        module_name = parts[0]
        
        # 鑾峰彇瀵瑰簲鐨勯厤缃ā鍧?
        try:
            obj = getattr(self, module_name)
        except AttributeError:
            return default
        
        # 澶勭悊鍓╀綑鐨勮矾寰勯儴鍒?
        for part in parts[1:]:
            if isinstance(obj, dict):
                obj = obj.get(part, default)
            else:
                try:
                    obj = getattr(obj, part, default)
                except (AttributeError, TypeError):
                    return default
            
            # 濡傛灉涓€旇幏鍙栧け璐ワ紝杩斿洖榛樿鍊?
            if obj == default:
                return default
        
        return obj

    def reload(self) -> None:
        """閲嶆柊鍔犺浇鎵€鏈夐厤缃?""
        self._load_configs()

    def get_config_path(self, config_name: str) -> Optional[Path]:
        """鑾峰彇閰嶇疆鏂囦欢璺緞"""
        return self._config_paths.get(config_name)


# Singleton instance
config = ConfigLoader()


