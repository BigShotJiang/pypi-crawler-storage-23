﻿from .config import config

__all__ = ["config"]

