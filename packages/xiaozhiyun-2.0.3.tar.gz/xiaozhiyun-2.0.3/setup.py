from setuptools import setup, find_packages

setup(
    name="xiaozhiyun",
    version="2.0.3",
    description="A multi-cloud AI service integration package adapting LangChain/LangGraph",
    author="Deer Flow Team",
    # 保持用户习惯，保留 src 映射，同时支持顶级 import xiaozhiyun
    # 将当前目录映射为 xiaozhiyun 包
    packages=["xiaozhiyun"] + ["xiaozhiyun." + p for p in find_packages(where=".")],
    package_dir={"xiaozhiyun": "."}, 
    include_package_data=True,
    install_requires=[
        "fastapi",
        "httpx",
        "pydantic>=2.0.0",
        "langgraph",
        "langchain",
        "langchain-openai",
        "langchain-core",
        "tiktoken",
        "websockets",
        "dashscope"
    ],
    python_requires=">=3.9",
    classifiers=[
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
    ],
)
