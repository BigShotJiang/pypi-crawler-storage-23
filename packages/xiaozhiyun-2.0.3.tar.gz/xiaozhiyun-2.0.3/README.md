﻿# src (灏忔櫤浜? AI 闆嗘垚闆嗘垚鍖?

src 鏄竴涓浜?AI 鏈嶅姟闆嗘垚妗嗘灦锛岄€傞厤 LangChain 鍜?LangGraph锛屾棬鍦ㄦ彁渚涚粺涓€銆佺伒娲讳笖楂樻晥鐨?AI 鑳藉姏璋冪敤鎺ュ彛銆?

## 鏍稿績鐗规€?

- **澶氫緵搴斿晢鏀寔**锛氶€傞厤 闃块噷浜?(Aliyun)銆佺櫨搴?(Baidu)銆佽吘璁?(Tencent) 鍜?鐏北寮曟搸 (Volcengine)銆?
- **鍏ㄦ湇鍔¤鐩?*锛?
  - **Chat**: 鏂囨湰鐢熸垚/澶ц瑷€妯″瀷
  - **Image**: 鍥惧儚鐢熸垚/鏂囩敓鍥?
  - **TTS**: 璇煶鍚堟垚 (鏀寔 REST API 鍜?WebSocket 娴佸紡)
  - **ASR/STT**: 璇煶璇嗗埆 (鏀寔瀹炴椂娴佸紡璇嗗埆)
- **缁熶竴鍗忚**锛氭墍鏈変簯鍘傚晢鐨?TTS/ASR WebSocket 鎺ュ彛缁熶竴涓轰竴濂楁爣鍑嗗崗璁紝闄嶄綆鎺ュ叆鎴愭湰銆?
- **寮傛涓庢祦寮?*锛氬師鐢熸敮鎸?`asyncio` 鍜?SSE 娴佸紡杈撳嚭銆?
- **鐏垫椿闆嗘垚**锛氭彁渚?API 瀹㈡埛绔€佸師瀛愯妭鐐?(Nodes) 鍜?棰勫畾涔夊伐浣滄祦 (Workflows) 涓夌璋冪敤鏂瑰紡銆?

---

## 浣跨敤鏂规硶

### 1. 瀵瑰鎺ュ彛璋冪敤 (API Client)

閫傜敤浜庨渶瑕侀€氳繃 HTTP 杩滅▼璋冪敤 src 鏈嶅姟绔殑鍦烘櫙銆傛彁渚涜繛鎺ョ鐞嗗拰娴佸紡鏀寔銆?

```python
import src
import asyncio

async def main():
    # 鍒濆鍖栧鎴风 (鎸囧畾鏈嶅姟绔?host 鍜?port)
    api = src.api('0.0.0.0', 8000)
    
    # 璋冪敤瀵硅瘽鎺ュ彛 (鏀寔娴佸紡)
    res = await api.chat('aliyun', {
        'model': 'qwen-turbo',
        'stream': True,
        'messages': [{"role": "user", "content": "浣犲ソ"}]
    })
    
    # 鍏抽棴杩炴帴
    await api.close()

asyncio.run(main())
```

### 2. 鐙珛宸ヤ綔娴佽妭鐐?(Nodes)

閫傜敤浜庡湪鑷畾涔夌殑 LangGraph 鍥句腑浣滀负鍘熷瓙鑺傜偣浣跨敤銆傞伒寰?`(provider, inputs_dict)` 绛惧悕銆?

```python
from langgraph.graph import StateGraph, START, END
from src import nodes

builder = StateGraph(dict)

# 娣诲姞鍘熷瓙鑺傜偣
builder.add_node('chat_node', nodes.chat('aliyun', {'model': 'qwen-turbo'}))
builder.add_node('tts_node', nodes.tts('baidu', {'voice': 'standard'}))

# 鏋勫缓閫昏緫杈?
builder.add_edge(START, "chat_node")
builder.add_edge("chat_node", "tts_node")
builder.add_edge("tts_node", END)

graph = builder.compile()
```

### 3. 涓€閿紡宸ヤ綔娴?(Workflows)

閫傜敤浜庣洿鎺ヨ皟鐢ㄩ瀹氫箟鐨勩€侀拡瀵圭壒瀹氬巶鍟嗕紭鍖栫殑瀹屾暣鏈嶅姟鍥俱€?

```python
from src import workflow

async def run():
    # 鐩存帴杩愯闃块噷鐨勫浘鐗囩敓鎴愬伐浣滄祦
    result = await workflow.image('aliyun', {
        'prompt': '涓€鍙湪澶┖鍐欎綔鐨勭唺鐚?,
        'size': '1024x1024'
    })
    print(result)

asyncio.run(run())
```

### 4. WebSocket 娴佸紡鏈嶅姟

鎻愪緵缁熶竴鍗忚鐨?WebSocket 鏈嶅姟锛屽睆钄戒簯鍘傚晢鍗忚宸紓銆?

```python
import src

# 鍚姩 TTS WebSocket 鏈嶅姟
# 鏀寔: aliyun, baidu, tencent, volcengine
server = src.websockt.tts('aliyun', port=8765)
server.run()
```

- 缁熶竴鍗忚鏂囨。锛歔src/xiaozhiyun/websocket/README.md](src/xiaozhiyun/websocket/README.md)

---

## 椤圭洰缁撴瀯

```text
src/
鈹溾攢鈹€ api/             # HTTP API 瀹㈡埛绔疄鐜?
鈹溾攢鈹€ hub/             # 鏍稿績椹卞姩灞?(閫傞厤鍚勪簯鍘傚晢 SDK/API)
鈹?  鈹溾攢鈹€ aliyun/      # 闃块噷浜戝疄鐜?
鈹?  鈹溾攢鈹€ baidu/       # 鐧惧害鏅鸿兘浜戝疄鐜?
鈹?  鈹溾攢鈹€ tencent/     # 鑵捐浜戝疄鐜?
鈹?  鈹溾攢鈹€ volcengine/  # 鐏北寮曟搸瀹炵幇
鈹?  鈹斺攢鈹€ common/      # 閫氱敤鍩虹被鍜屽伐鍏?
鈹溾攢鈹€ nodes/           # LangGraph 鍘熷瓙鑺傜偣灏佽
鈹?  鈹溾攢鈹€ aliyun/
鈹?  鈹溾攢鈹€ baidu/
鈹?  鈹溾攢鈹€ tencent/
鈹?  鈹斺攢鈹€ volcengine/
鈹溾攢鈹€ websocket/       # WebSocket 鏈嶅姟绔?(缁熶竴鍗忚閫傞厤)
鈹?  鈹溾攢鈹€ aliyun/      # 闃块噷浜戦€傞厤
鈹?  鈹溾攢鈹€ baidu/       # 鐧惧害閫傞厤
鈹?  鈹溾攢鈹€ tencent/     # 鑵捐浜戦€傞厤
鈹?  鈹溾攢鈹€ volcengine/  # 鐏北寮曟搸閫傞厤
鈹?  鈹溾攢鈹€ base_tts.py  # TTS 缁熶竴鍗忚鍩虹被
鈹?  鈹斺攢鈹€ server.py    # 閫氱敤 Server 瀹炵幇
鈹溾攢鈹€ workflows/       # 棰勫畾涔夊伐浣滄祦鍥?
鈹斺攢鈹€ __init__.py      # 鍖呭叆鍙?
```

## 瀹夎

```bash
cd deer-flow/xiaozhiyun/xiaozhiyun
pip install -e .
```


