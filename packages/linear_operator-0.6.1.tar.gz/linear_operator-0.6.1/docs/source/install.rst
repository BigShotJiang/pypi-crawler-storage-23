.. role:: hidden
    :class: hidden-section

.. include:: ../../README.md
   :start-after: <!-- docs_install_start -->
   :end-before: <!-- docs_install_end -->
   :parser: myst_parser.sphinx_
