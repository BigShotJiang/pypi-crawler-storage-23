.. role:: hidden
    :class: hidden-section

Utilities
===================================

.. currentmodule:: linear_operator.utils

.. automodule:: linear_operator.utils
   :members:

.. automodule:: linear_operator.utils.lanczos
   :members:

.. automodule:: linear_operator.utils.sparse
   :members:
