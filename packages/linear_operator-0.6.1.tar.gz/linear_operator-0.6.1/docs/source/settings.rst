.. role:: hidden
    :class: hidden-section

Settings
===================================

.. currentmodule:: linear_operator.settings

.. automodule:: linear_operator.settings
   :members:
