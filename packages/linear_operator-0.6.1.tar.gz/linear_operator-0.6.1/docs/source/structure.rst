.. role:: hidden
    :class: hidden-section

Structured LinearOperators
====================================================

.. autoclass:: linear_operator.operators.TriangularLinearOperator
   :members:
