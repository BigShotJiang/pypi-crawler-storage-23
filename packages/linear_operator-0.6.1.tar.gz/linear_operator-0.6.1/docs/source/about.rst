.. role:: hidden
    :class: hidden-section

.. include:: ../../README.md
   :start-after: <!-- docs_about_start -->
   :end-before: <!-- docs_about_end -->
   :parser: myst_parser.sphinx_
