.. role:: hidden
    :class: hidden-section

LinearOperator
================================

.. autoclass:: linear_operator.LinearOperator
   :members:
