.. role:: hidden
    :class: hidden-section

Converting Between LinearOperators and torch.Tensor
====================================================

.. autofunction:: linear_operator.to_linear_operator

.. autofunction:: linear_operator.to_dense
