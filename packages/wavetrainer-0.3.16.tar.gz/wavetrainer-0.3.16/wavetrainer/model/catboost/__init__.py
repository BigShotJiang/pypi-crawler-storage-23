"""The wavetrain catboost model module."""
