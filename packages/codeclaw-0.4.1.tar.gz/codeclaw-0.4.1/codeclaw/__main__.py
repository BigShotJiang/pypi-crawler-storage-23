"""Module entry point for ``python -m codeclaw``."""

from .cli import main


if __name__ == "__main__":
    main()
