"""CodeClaw — Export your Claude Code and Codex conversations to Hugging Face."""

__version__ = "0.4.1"
