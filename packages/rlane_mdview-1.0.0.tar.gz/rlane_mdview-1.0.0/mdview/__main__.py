"""Enable running with `python -m`."""

from mdview.cli import main

if __name__ == "__main__":
    main()
