"""Markdown viewer with GitHub-style rendering."""
