import questionary
import shutil
import subprocess
from questionary import Choice
from foundry.auth import get_current_license_info
from foundry.constants import TIER_HIERARCHY, console, QUESTIONARY_STYLE
from foundry.utils import get_template_info, get_templates
from rich.panel import Panel

def _get_github_owners():
    """Fetches the user's login and their organizations via 'gh' CLI."""
    owners = []
    try:
        # Get personal username
        user_result = subprocess.run(
            ["gh", "api", "user", "--template", "{{.login}}"],
            capture_output=True, text=True, check=True
        )
        owners.append(Choice(f"👤 Personal Account ({user_result.stdout.strip()})", value=user_result.stdout.strip()))

        # Get organizations
        orgs_result = subprocess.run(
            ["gh", "api", "user/orgs", "--template", "{{range .}}{{.login}}\n{{end}}"],
            capture_output=True, text=True, check=True
        )
        for org in orgs_result.stdout.strip().split("\n"):
            if org:
                owners.append(Choice(f"🏢 Organization ({org})", value=org))
    except (subprocess.CalledProcessError, FileNotFoundError):
        pass
    
    return owners

def get_interactive_config(template_name=None):
    """Gathers all configuration interactively from the user."""
    # Filter templates based on user tier for a cleaner experience
    user_info = get_current_license_info()
    user_tier = user_info.get("tier", "free")
    user_rank = TIER_HIERARCHY.get(user_tier, 0)
    
    if not template_name:
        available_templates = []
        for tmpl in get_templates():
            info = get_template_info(tmpl.name)
            tmpl_tier = info.get("tier", "free").lower()
            if user_rank >= TIER_HIERARCHY.get(tmpl_tier, 0):
                available_templates.append(tmpl.name)

        if not available_templates:
            console.print("[yellow]No templates available for your current tier.[/yellow]")
            return None

        # Add Back button for better navigation
        choices = ["Back"] + [Choice(t, value=t) for t in available_templates]

        template_name = questionary.select(
            "Select a template to deploy:", 
            choices=choices,
            style=questionary.Style(QUESTIONARY_STYLE)
        ).ask()

        if template_name == "Back" or not template_name:
            return None

        console.print(Panel(f"[bold]Configuring {template_name}[/bold]", style="blue"))

    app_name = questionary.text(
        "Enter your Application Name:", default=f"my-{template_name}"
    ).ask()
    
    # Initialize config with defaults
    config = {
        "template_name": template_name,
        "app_name": app_name,
        "with_commerce": False,
        "with_tunnel": False,
        "with_landing": False,
        "with_admin": False,
        "with_sqlite": False,
        "with_ingestor": False,
        "with_auth": False,
        "with_merchant_dashboard": False,
        "use_linters": True,
        "use_ast_injection": False,
        "secrets_strategy": "Dotenv (Standard .env files)",
        "github_config": None
    }

    # Configuration Menu Loop
    while True:
        console.print(Panel(
            f"[bold cyan]Project Configuration: {config['app_name']}[/bold cyan]\n"
            f"[dim]Template: {config['template_name']}[/dim]\n"
            f"[dim]Features: {', '.join([f for f in ['commerce', 'tunnel', 'landing', 'admin', 'sqlite', 'ingestor', 'auth', 'merchant_dashboard'] if config.get('with_' + f)]) or 'None'}[/dim]",
            style="blue"
        ))

        choice = questionary.select(
            "What would you like to configure?",
            choices=[
                Choice("📦 Select Features & Modules", value="features"),
                Choice("🛠️ Quality & Linting", value="quality"),
                Choice("🔑 Secrets Management", value="secrets"),
                Choice("🚀 GitHub Repository", value="github"),
                Choice("✨ GENERATE PROJECT", value="generate"),
                Choice("❌ Cancel", value="cancel")
            ],
            style=questionary.Style(QUESTIONARY_STYLE)
        ).ask()

        if choice == "cancel" or not choice:
            return None
        
        if choice == "generate":
            break

        if choice == "features":
            # Granular Multi-Select for Features
            if user_rank >= TIER_HIERARCHY.get("pro"):
                feature_choices = [
                    Choice("🛒 Commerce (Shopify/Stripe)", value="commerce", checked=config["with_commerce"]),
                    Choice("🚇 Local Tunneling (ngrok)", value="tunnel", checked=config["with_tunnel"]),
                    Choice("🌱 Static Landing Page (Astro)", value="landing", checked=config["with_landing"]),
                    Choice("🔐 Authentication (Auth0/NextAuth)", value="auth", checked=config["with_auth"]),
                ]
                
                # Template-specific features
                if template_name == "react-client":
                    feature_choices.append(Choice("📊 Merchant Dashboard UI", value="merchant_dashboard", checked=config["with_merchant_dashboard"]))
                
                if template_name == "python-saas":
                    feature_choices.extend([
                        Choice("🛡️ Admin Panel (NiceGUI)", value="admin", checked=config["with_admin"]),
                        Choice("🗄️ SQLite & Alembic Setup", value="sqlite", checked=config["with_sqlite"]),
                        Choice("📥 Data Ingestor Pattern", value="ingestor", checked=config["with_ingestor"]),
                    ])

                selected_features = questionary.checkbox(
                    "Select features to include in your project:",
                    choices=feature_choices,
                    style=questionary.Style(QUESTIONARY_STYLE)
                ).ask()

                if selected_features is not None:
                    # Reset all features first
                    for f in ["commerce", "tunnel", "landing", "admin", "sqlite", "ingestor", "auth", "merchant_dashboard"]:
                        config["with_" + f] = False
                    
                    # Apply selection
                    for f in selected_features:
                        config["with_" + f] = True
                    
                    # Auto-dependency: Merchant Dashboard requires Commerce
                    if config["with_merchant_dashboard"]:
                        config["with_commerce"] = True
            else:
                console.print("[yellow]PRO features are locked for your current tier.[/yellow]")

        elif choice == "quality":
            config["use_linters"] = questionary.confirm(
                "Enable default linters (Ruff/Rubocop/ESLint)?", default=config["use_linters"]
            ).ask()
            
            if user_rank >= TIER_HIERARCHY.get("pro"):
                config["use_ast_injection"] = questionary.confirm(
                    "🔬 Use AST-based feature injection (experimental)?",
                    default=config["use_ast_injection"]
                ).ask()

        elif choice == "secrets":
            secrets_choice = questionary.select(
                "Select Secrets Management Strategy:",
                choices=[
                    Choice("Dotenv (Standard .env files)", value="dotenv"),
                    Choice("Doppler (Managed cloud secrets)", value="doppler"),
                    Choice("Environment Only (PaaS/CI friendly)", value="env"),
                ],
                default=config["secrets_strategy"].lower().split(" ")[0],
                style=questionary.Style(QUESTIONARY_STYLE)
            ).ask()
            
            if secrets_choice == "dotenv":
                config["secrets_strategy"] = "Dotenv (Standard .env files)"
            elif secrets_choice == "doppler":
                config["secrets_strategy"] = "Doppler (Managed cloud secrets)"
            elif secrets_choice == "env":
                config["secrets_strategy"] = "Environment Only (PaaS/CI friendly)"

        elif choice == "github":
            gh_available = shutil.which("gh") is not None
            if not gh_available:
                console.print("[yellow]GitHub CLI (gh) not found in PATH.[/yellow]")
                continue

            create_github_repo = questionary.confirm(
                "🚀 Create a GitHub repository for this project?",
                default=config["github_config"] is not None
            ).ask()

            if create_github_repo:
                # Ask for Owner FIRST
                owners = _get_github_owners()
                if owners:
                    repo_owner = questionary.select(
                        "    Select Repository Owner:",
                        choices=owners,
                        default=config["github_config"]["owner"] if config["github_config"] else None,
                        style=questionary.Style(QUESTIONARY_STYLE)
                    ).ask()
                else:
                    repo_owner = questionary.text(
                        "    Repository Owner (Username/Org):", 
                        default=config["github_config"]["owner"] if config["github_config"] else ""
                    ).ask()

                repo_name = questionary.text(
                    "    Repository Name:", default=config["github_config"]["name"] if config["github_config"] else config["app_name"]
                ).ask()
                repo_description = questionary.text(
                    "    Repository Description:", 
                    default=config["github_config"]["description"] if config["github_config"] else f"✨ {template_name} project created with Seed & Source"
                ).ask()
                repo_visibility = questionary.select(
                    "    Repository Visibility:",
                    choices=[
                        Choice("Private", value="private"),
                        Choice("Public", value="public")
                    ],
                    default=config["github_config"]["visibility"] if config["github_config"] else "private",
                    style=questionary.Style(QUESTIONARY_STYLE)
                ).ask()
                config["github_config"] = {
                    "owner": repo_owner,
                    "name": repo_name,
                    "description": repo_description,
                    "visibility": repo_visibility
                }
            else:
                config["github_config"] = None

    return config
