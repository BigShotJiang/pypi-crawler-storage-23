"""
AST-Grep Integration Wrapper for Stack CLI
===========================================

Provides a high-level Python interface for executing ast-grep rules
in the context of feature injection for Astro landing templates.

Usage:
    from foundry.actions.ast_grep_runner import AstGrepRunner
    
    runner = AstGrepRunner()
    runner.inject_rule(
        target_path=Path("src/pages/index.astro"),
        rule_name="astro-inject-pricing-component",
        content_vars={"PRICING_COMPONENT": "<PricingTiers />"}
    )
"""

import subprocess
import json
from pathlib import Path
from typing import Dict, Optional, List, Tuple
import shutil

from foundry.constants import console, FOUNDRY_ROOT


class AstGrepError(Exception):
    """Raised when ast-grep execution fails."""
    pass


class AstGrepRunner:
    """
    Wrapper around ast-grep CLI for code transformation.
    
    Handles:
    - Rule file discovery and validation
    - Variable substitution for dynamic content injection
    - Execution with appropriate flags
    - Error handling and fallback mechanisms
    - Verification of transformations
    """
    
    def __init__(self, rule_dir: Optional[Path] = None):
        """
        Initialize AST-Grep runner.
        
        Args:
            rule_dir: Path to directory containing YAML rules.
                     Defaults to foundry/rules/astro-injections/
        """
        self.rule_dir = rule_dir or (
            FOUNDRY_ROOT / "tooling" / "stack-cli" / "foundry" / "rules" / "astro-injections"
        )
        self.sg_config = self.rule_dir.parent / "sgconfig.yml"
        self._ast_grep_path = self._locate_ast_grep()
    
    def _locate_ast_grep(self) -> Optional[str]:
        """
        Find ast-grep binary in system PATH.
        
        Returns:
            Path to ast-grep executable, or None if not found.
        """
        return shutil.which("ast-grep") or shutil.which("sg")
    
    def is_available(self) -> bool:
        """
        Check if ast-grep is installed and available.
        
        Returns:
            True if ast-grep can be executed.
        """
        return self._ast_grep_path is not None
    
    def get_version(self) -> Optional[str]:
        """
        Get installed ast-grep version.
        
        Returns:
            Version string, or None if ast-grep not found.
        """
        if not self.is_available():
            return None
        
        try:
            result = subprocess.run(
                [self._ast_grep_path, "--version"],
                capture_output=True,
                text=True,
                timeout=5
            )
            return result.stdout.strip() if result.returncode == 0 else None
        except Exception:
            return None
    
    def validate_rule(self, rule_name: str) -> Tuple[bool, Optional[str]]:
        """
        Validate that a rule file exists and contains valid YAML.
        
        Args:
            rule_name: ID of the rule (e.g., "astro-inject-pricing-component")
        
        Returns:
            Tuple of (valid: bool, error_message: Optional[str])
        """
        rule_path = self.rule_dir / f"{rule_name}.yml"
        
        if not rule_path.exists():
            return False, f"Rule file not found: {rule_path}"
        
        try:
            import yaml
            with open(rule_path) as f:
                # Use safe_load_all to handle files with multiple documents (---)
                content_list = list(yaml.safe_load_all(f))
                if not content_list or not any(isinstance(doc, dict) for doc in content_list):
                    return False, "Rule is empty or contains no valid YAML objects"
            return True, None
        except Exception as e:
            return False, f"Invalid YAML in rule: {str(e)}"
    
    def inject_rule(
        self,
        target_path: Path,
        rule_name: str,
        content_vars: Optional[Dict[str, str]] = None,
        dry_run: bool = False,
        auto_accept: bool = True
    ) -> bool:
        """
        Execute an ast-grep rule on a target file to inject/transform code.
        
        Args:
            target_path: File to transform (e.g., src/pages/index.astro)
            rule_name: ID of the rule to apply
            content_vars: Dictionary mapping variable names to injection content
                         e.g., {"PRICING_COMPONENT": "<PricingComponent />"}
            dry_run: If True, show what would happen without modifying file
            auto_accept: If True, auto-apply changes (--update-all flag)
        
        Returns:
            True if successful, False otherwise.
        
        Raises:
            AstGrepError: If ast-grep is not available or execution fails critically.
        """
        # Validation
        if not self.is_available():
            raise AstGrepError(
                "ast-grep is not installed. "
                "Install via: brew install ast-grep or cargo install ast-grep-cli"
            )
        
        if not target_path.exists():
            console.print(f"[red]✗ Target file not found: {target_path}[/red]")
            return False
        
        valid, error = self.validate_rule(rule_name)
        if not valid:
            console.print(f"[red]✗ {error}[/red]")
            return False
        
        # Prepare target content with variable substitution
        try:
            if content_vars:
                content = target_path.read_text(encoding="utf-8")
                for var_name, var_value in content_vars.items():
                    # Replace placeholders like $$$THEME_CONTENT with actual content
                    placeholder = f"$$$/{var_name}"
                    content = content.replace(placeholder, var_value)
                target_path.write_text(content, encoding="utf-8")
        except Exception as e:
            console.print(f"[red]✗ Failed to prepare target file: {str(e)}[/red]")
            return False
        
        # Build ast-grep command
        try:
            cmd = [
                self._ast_grep_path,
                "scan",
                "--rule", str(self.rule_dir / f"{rule_name}.yml"),
            ]
            
            if auto_accept and not dry_run:
                cmd.append("--update-all")
            elif dry_run:
                # Dry run shows diff without applying
                pass  # ast-grep shows diff by default
            else:
                cmd.append("--interactive")
            
            cmd.append(str(target_path.parent))
            
            if dry_run:
                console.print(f"[yellow]DRY RUN:[/yellow] {' '.join(cmd)}")
            
            # Execute rule
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=30
            )
            
            if result.returncode not in (0, 1):  # 1 = matched but didn't auto-apply
                console.print(f"[red]✗ ast-grep error:[/red] {result.stderr}")
                return False
            
            if result.stdout:
                console.print(f"[cyan]{result.stdout}[/cyan]")
            
            console.print(f"[green]✓ Applied rule: {rule_name}[/green]")
            return True
        
        except subprocess.TimeoutExpired:
            console.print(
                f"[red]✗ ast-grep execution timed out for {target_path}[/red]"
            )
            return False
        except Exception as e:
            console.print(f"[red]✗ ast-grep execution failed: {str(e)}[/red]")
            return False
    
    def inject_rule_batch(
        self,
        target_files: List[Path],
        rule_name: str,
        content_vars: Optional[Dict[str, str]] = None,
        auto_accept: bool = True
    ) -> Tuple[int, int]:
        """
        Apply a rule to multiple files.
        
        Args:
            target_files: List of files to transform
            rule_name: Rule ID to apply
            content_vars: Shared variables for all files
            auto_accept: Auto-apply transformations
        
        Returns:
            Tuple of (success_count, failure_count)
        """
        successes = 0
        failures = 0
        
        for target in target_files:
            try:
                if self.inject_rule(target, rule_name, content_vars, auto_accept=auto_accept):
                    successes += 1
                else:
                    failures += 1
            except Exception as e:
                console.print(f"[red]✗ Error processing {target}: {str(e)}[/red]")
                failures += 1
        
        return successes, failures
    
    def parse_file(self, file_path: Path) -> Optional[Dict]:
        """
        Parse a file and return its AST structure.
        
        Useful for understanding the syntax tree for rule development.
        
        Args:
            file_path: File to parse
        
        Returns:
            AST structure as dict, or None if parsing fails.
        """
        if not self.is_available():
            console.print("[red]✗ ast-grep not available[/red]")
            return None
        
        try:
            result = subprocess.run(
                [self._ast_grep_path, "parse", str(file_path), "--format", "json"],
                capture_output=True,
                text=True,
                timeout=10
            )
            
            if result.returncode == 0:
                return json.loads(result.stdout)
            else:
                console.print(f"[red]✗ Parse error: {result.stderr}[/red]")
                return None
        
        except Exception as e:
            console.print(f"[red]✗ Failed to parse file: {str(e)}[/red]")
            return None
    
    def test_rule(self, rule_name: str, target_path: Path) -> bool:
        """
        Test a rule without applying changes (dry run mode).
        
        Args:
            rule_name: Rule ID to test
            target_path: File to test against
        
        Returns:
            True if rule matches code in target.
        """
        return self.inject_rule(target_path, rule_name, dry_run=True)
    
    def get_rule_info(self, rule_name: str) -> Optional[Dict]:
        """
        Extract metadata from a rule file.
        
        Args:
            rule_name: Rule ID
        
        Returns:
            Dict with rule metadata (id, language, message, severity) or None.
        """
        rule_path = self.rule_dir / f"{rule_name}.yml"
        
        if not rule_path.exists():
            return None
        
        try:
            import yaml
            with open(rule_path) as f:
                data = yaml.safe_load(f)
                if isinstance(data, dict):
                    return {
                        "id": data.get("id"),
                        "language": data.get("language"),
                        "message": data.get("message"),
                        "severity": data.get("severity", "info")
                    }
        except Exception:
            pass
        
        return None
    
    def list_available_rules(self) -> List[str]:
        """
        List all available rule files in the rules directory.
        
        Returns:
            List of rule IDs (filenames without .yml extension).
        """
        if not self.rule_dir.exists():
            return []
        
        rules = []
        for rule_file in self.rule_dir.glob("*.yml"):
            rules.append(rule_file.stem)
        
        return sorted(rules)


def ensure_ast_grep_available() -> bool:
    """
    Check if ast-grep is available; offer installation instructions if not.
    
    Returns:
        True if ast-grep is installed and available.
    """
    runner = AstGrepRunner()
    
    if runner.is_available():
        version = runner.get_version()
        console.print(f"[green]✓ ast-grep available[/green] ({version})")
        return True
    
    console.print("[yellow]⚠ ast-grep is not installed[/yellow]")
    console.print("[cyan]Installation options:[/cyan]")
    console.print("  macOS:   [bold]brew install ast-grep[/bold]")
    console.print("  Rust:    [bold]cargo install ast-grep-cli[/bold]")
    console.print("  GitHub:  https://github.com/ast-grep/ast-grep/releases")
    
    return False
