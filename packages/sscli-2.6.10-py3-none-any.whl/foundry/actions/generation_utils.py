from pathlib import Path
import json
import subprocess
import sys
import shutil
from rich.panel import Panel
from foundry.constants import console, TIER_HIERARCHY, PRICING_URL
from foundry.telemetry import log_event
from foundry.auth import get_current_license_info
from foundry.codemods.toml_codemods import RemoveToolSectionsCM, RemovePythonDependencyCM


def check_tier_access(template_name: str, required_tier: str) -> bool:
    """Check if the user has the required tier for a template.
    
    For ALPHA users, also checks per-template access grants.
    """
    from foundry.utils import is_internal_dev
    if is_internal_dev():
        return True
        
    user_info = get_current_license_info()
    user_tier = user_info.get("tier", "free")
    user_id = user_info.get("user_id")

    # Check tier hierarchy first
    if TIER_HIERARCHY.get(user_tier, 0) < TIER_HIERARCHY.get(required_tier.lower(), 0):
        console.print(
            Panel(
                f"[bold red]Access Denied[/bold red]\n\n"
                f"The template [cyan]{template_name}[/cyan] requires a [bold yellow]{required_tier.upper()}[/bold yellow] license.\n"
                f"Your current tier is: [bold white]{user_tier.upper()}[/bold white].\n\n"
                f"Upgrade your license at: [link={PRICING_URL}]{PRICING_URL}[/link]",
                title="License Requirement",
                border_style="red",
            )
        )
        log_event(
            "GENERATE_FORBIDDEN", f"Template: {template_name}, User Tier: {user_tier}"
        )
        return False
    return True


def apply_landing_blueprint(path: Path, content_path: str = None, theme: str = None):
    """Apply blueprint configuration to static-landing template."""
    blueprint_file = path / "blueprint.json"
    if not blueprint_file.exists():
        return

    try:
        blueprint_data = json.loads(blueprint_file.read_text(encoding="utf-8"))
        
        # Override with custom content if provided
        if content_path:
            custom_content_file = Path(content_path)
            if custom_content_file.exists():
                custom_data = json.loads(custom_content_file.read_text(encoding="utf-8"))
                blueprint_data.update(custom_data)
                console.print(f"   - Applied custom content blueprint from {content_path}")
            else:
                console.print(f"   [yellow]⚠️  Custom content file {content_path} not found.[/yellow]")

        # Override theme if provided
        if theme:
            blueprint_data["theme"] = theme
            console.print(f"   - Applied theme: {theme}")

        blueprint_file.write_text(json.dumps(blueprint_data, indent=2), encoding="utf-8")
        
    except Exception as e:
        console.print(f"   [yellow]⚠️  Failed to apply landing blueprint: {e}[/yellow]")


def inject_metadata(path: Path, template: str, app_name: str):
    """
    Inject project name into configuration files.
    
    This is the first step of project initialization, renaming template placeholders.
    """
    console.print(f"   - Injecting name '{app_name}' into configuration...")
    files_to_touch = [
        path / "package.json",
        path / "pyproject.toml",
        path / "Gemfile",
        path / "README.md",
        path / ".env.example",
        path / "astro.config.mjs",
    ]
    for f in files_to_touch:
        if f.exists():
            try:
                content = f.read_text(encoding="utf-8")
                new_content = content.replace(f"{template}", app_name)
                # Capitalized version for internal class names or readmes
                new_content = new_content.replace("StackApp", app_name.capitalize())
                f.write_text(new_content, encoding="utf-8")
            except Exception as e:
                console.print(f"   [yellow]⚠️  Failed to inject metadata into {f.name}: {e}[/yellow]")


def disable_linters(path: Path):
    """Remove linter tools and dependencies from the project."""
    pyproject = path / "pyproject.toml"
    if pyproject.exists():
        console.print("   - Removing Ruff/MyPy configurations...")
        try:
            # Use toml-based codemod for clean removal (formatting-aware)
            codemod = RemoveToolSectionsCM(sections=["ruff", "mypy"])
            codemod.apply(pyproject)
            
            # Also remove dependencies
            dep_codemod = RemovePythonDependencyCM(dependencies=["ruff", "mypy"])
            dep_codemod.execute(pyproject)
        except Exception as e:
            console.print(f"   [yellow]⚠️  Failed to disable linters in pyproject.toml: {e}[/yellow]")

    gemfile = path / "Gemfile"
    if gemfile.exists():
        try:
            content = gemfile.read_text(encoding="utf-8")
            new_content = content.replace("gem 'rubocop'", "# gem 'rubocop'").replace("gem 'rubocop-rails'", "# gem 'rubocop-rails'")
            gemfile.write_text(new_content, encoding="utf-8")
            console.print("   - Commented out Rubocop in Gemfile")
        except Exception as e:
            console.print(f"   [yellow]⚠️  Failed to disable linters in Gemfile: {e}[/yellow]")


def regenerate_poetry_lock(path: Path):
    """Regenerate poetry.lock to reflect any manual file changes (like dependency removal)."""
    if not (path / "pyproject.toml").exists() or not (path / "poetry.lock").exists():
        return
        
    console.print("   - Regenerating poetry.lock...")
    try:
        # Check if poetry is available
        subprocess.run(["poetry", "--version"], capture_output=True, check=True)
        
        result = subprocess.run(
            ["poetry", "lock", "--no-update"], 
            cwd=str(path), 
            capture_output=True, 
            text=True, 
            timeout=120
        )
        if result.returncode == 0:
            console.print("   - poetry.lock regenerated successfully")
        else:
            console.print(f"   [yellow]⚠️  Poetry lock failed: {result.stderr.strip()}[/yellow]")
    except (subprocess.CalledProcessError, FileNotFoundError):
        console.print("   [yellow]⚠️  Poetry not found, skipping lock regeneration.[/yellow]")
    except Exception as e:
        console.print(f"   [yellow]⚠️  Unexpected error regenerating poetry.lock: {str(e)}[/yellow]")


def validate_and_fix_pyproject(path: Path):
    """Validate pyproject.toml and fix common formatting issues manually."""
    pyproject = path / "pyproject.toml"
    if not pyproject.exists():
        return
        
    try:
        # Fallback to simple correction if tomlkit fails or for non-standard repairs
        content = pyproject.read_text(encoding="utf-8")
        fixed_lines = []
        in_dependencies_section = False
        
        for line in content.splitlines():
            if line.strip().startswith("[tool.poetry"):
                in_dependencies_section = "dependencies" in line
            elif line.strip().startswith("["):
                in_dependencies_section = False
            
            if in_dependencies_section and " = " in line and not line.strip().startswith("#"):
                key, value = line.split(" = ", 1)
                key, value = key.strip(), value.strip()
                if value and not value.startswith(('"', "'", "{", "[")):
                    if value[0].isdigit() or value[0] in "^~<>=!":
                        value = f'"{value}"'
                        line = f"{key} = {value}"
            fixed_lines.append(line)
        
        fixed_content = "\n".join(fixed_lines) + "\n"
        pyproject.write_text(fixed_content, encoding="utf-8")
        console.print("   - Validated pyproject.toml structure")
    except Exception as e:
        console.print(f"   [yellow]⚠️  Could not validate pyproject.toml: {e}[/yellow]")

