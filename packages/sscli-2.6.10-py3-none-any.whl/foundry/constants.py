from pathlib import Path
import os

from rich.console import Console

# Base directory navigation
# In a pipx/PyPI install, code is isolated. We need to find the actual monorepo.
def _get_foundry_root() -> Path:
    # 1. Allow explicit override
    if os.getenv("FOUNDRY_ROOT"):
        return Path(os.getenv("FOUNDRY_ROOT"))
    
    # 2. Check if we are running from within the monorepo (CWD has .github, tooling, templates, etc)
    cwd = Path.cwd()
    if (cwd / ".github").exists() and (cwd / "tooling").exists():
        return cwd
    
    # 3. If one level deep (e.g. in tooling/ or templates/), go up one
    if (cwd.parent / ".github").exists() and (cwd.parent / "tooling").exists():
        return cwd.parent
    
    # 4. If two levels deep (e.g. in tooling/stack-cli/), go up two
    if (cwd.parent.parent / ".github").exists() and (cwd.parent.parent / "tooling").exists():
        return cwd.parent.parent
        
    # 5. Fallback to where the code is installed (Legacy behavior)
    return Path(__file__).resolve().parent.parent.parent

FOUNDRY_ROOT = _get_foundry_root()
TEMPLATES_DIR = FOUNDRY_ROOT / "templates"

# Production License Server (Hardcoded for security)
SEED_SOURCE_PRODUCTION_API = "https://auth.seedsource.dev/api"

# Development Override
# Only enabled if FOUNDRY_INTERNAL_DEV is explicitly set AND we are in a dev mono-repo
def _get_api_url() -> str:
    # Check for developer override via environment variable
    env_url = os.getenv("LICENSE_SERVER_URL")
    if env_url:
        # In a production build, we might want to warn or restrict here
        # but for ALPHA we allow env var overrides.
        return env_url
    
    # If running locally in the mono-repo, default to production unless specified
    return SEED_SOURCE_PRODUCTION_API

API_BASE_URL = _get_api_url()

# Domain configuration (defaults to seedsource.dev, override via environment variables)
SEED_SOURCE_DOMAIN = os.getenv("SEED_SOURCE_DOMAIN", "seedsource.dev")
SEED_SOURCE_AUTH_URL = os.getenv("SEED_SOURCE_AUTH_URL", f"https://auth.{SEED_SOURCE_DOMAIN}")
SEED_SOURCE_LANDING_URL = os.getenv("SEED_SOURCE_LANDING_URL", f"https://{SEED_SOURCE_DOMAIN}")
FORMS_BASE_URL = os.getenv("FORMS_BASE_URL", f"https://forms.{SEED_SOURCE_DOMAIN}")

# Marketing URLs (always configured)
PRICING_URL = os.getenv("PRICING_URL", f"https://{SEED_SOURCE_DOMAIN}/pricing")
SALES_EMAIL = os.getenv("SALES_EMAIL", f"sales@{SEED_SOURCE_DOMAIN}")
ALPHA_SUPPORT_EMAIL = os.getenv("ALPHA_SUPPORT_EMAIL", f"support@{SEED_SOURCE_DOMAIN}")
ALPHA_FEEDBACK_FORM = os.getenv("ALPHA_FEEDBACK_FORM", f"{FORMS_BASE_URL}/alpha")

# Metadata-based template registry for PyPI distribution
# This allows the CLI to know about templates without them being on disk
TEMPLATE_REGISTRY = {
    "python-saas": {
        "name": "Python SaaS Boilerplate",
        "description": "Hexagonal Architecture (FastAPI + SQLAlchemy)",
        "tier": "alpha",
        "repo": "https://github.com/seed-source/python-saas.git",
    },
    "rails-api": {
        "name": "Rails API Suite",
        "description": "JSON API with Devise, RSpec, and Docker",
        "tier": "free",
        "repo": "https://github.com/seed-source/rails-api.git",
    },
    "react-client": {
        "name": "React Vite Client",
        "description": "Modern frontend with Tailwind and React Query",
        "tier": "alpha",
        "repo": "https://github.com/seed-source/react-client.git",
    },
    "rails-ui-kit": {
        "name": "Rails UI Kit",
        "description": "Full-stack Rails with ViewComponent and Tailwind",
        "tier": "alpha",
        "repo": "https://github.com/seed-source/rails-ui-kit.git",
    },
    "data-pipeline": {
        "name": "Data Pipeline (dbt)",
        "description": "Modern data stack with dbt and Python",
        "tier": "alpha",
        "repo": "https://github.com/seed-source/data-pipeline.git",
    },
    "mobile-android": {
        "name": "Mobile Android",
        "description": "Kotlin-based Android application",
        "tier": "alpha",
        "repo": "https://github.com/seed-source/mobile-android-private.git",
    },
    "mobile-ios": {
        "name": "Mobile iOS",
        "description": "SwiftUI-based iOS application",
        "tier": "alpha",
        "repo": "https://github.com/seed-source/mobile-ios-private.git",
    },
    "terraform-infra": {
        "name": "Terraform Infrastructure",
        "description": "Multi-cloud IaC modules",
        "tier": "alpha",
        "repo": "https://github.com/seed-source/terraform-infra-private.git",
    },
    "wiring": {
        "name": "Docker Wiring",
        "description": "Orchestration for multi-service stacks",
        "tier": "alpha",
        "repo": "https://github.com/seed-source/wiring-private.git",
    },
    "static-landing": {
        "name": "Astro Static Landing",
        "description": "Astro static site generator for marketing/landing pages",
        "tier": "alpha",
        "repo": "https://github.com/seed-source/static-landing.git",
    },
}

# If a local `static-landing` directory exists in the mono-repo and is a git
# repository (for example as a submodule), prefer that local path so the CLI
# can operate on the on-disk template during development.
try:
    _local_static = Path(TEMPLATES_DIR) / "static-landing"
    if _local_static.exists() and (_local_static / ".git").exists():
        TEMPLATE_REGISTRY["static-landing"]["repo"] = f"file://{_local_static.resolve()}"
except Exception:
    # Non-fatal: if anything goes wrong, keep the registry as-is.
    pass

AVAILABLE_EXTENSIONS = {
    "commerce": {
        "name": "Commerce (Shopify/Stripe)",
        "tier": "pro",
        "description": "Injects Shopify/Commerce adapters and webhooks.",
    },
    "tunnel": {
        "name": "Local Tunneling (ngrok)",
        "tier": "pro",
        "description": "Configures the project for ngrok/local tunneling.",
    },
    "admin": {
        "name": "NiceGUI Admin",
        "tier": "pro",
        "description": "Standalone NiceGUI-based admin panel.",
    },
    "sqlite": {
        "name": "SQLite Local",
        "tier": "alpha",
        "description": "Local persistence with SQLAlchemy + Alembic.",
    },
    "ingestor": {
        "name": "Data Ingestor",
        "tier": "pro",
        "description": "Adapter pattern for raw data normalization.",
    },
}

TIER_HIERARCHY = {"free": 0, "alpha": 1, "pro": 2, "enterprise": 3, "admin": 10}

console = Console()


# Menu configuration
ANIMATED_MENU_ITEMS = [
    "Explore Templates",
    "Generate Project",
    "Manage Config",
    "System Validation",
    "View Docs",
    "Exit",
]

# Apply questionary patching for description styling
from foundry.patch import apply_description_patch
apply_description_patch()

# Shared Questionary styling - consistent across all menus
QUESTIONARY_STYLE = [
    ("qmark", "fg:#673ab7 bold"),       # purple
    ("question", "bold"),               # bold question
    ("answer", "fg:#f44336 bold"),     # red answer
    ("pointer", "fg:#673ab7 bold"),    # purple pointer
    ("highlighted", "fg:#673ab7 bold"),# purple highlighted item (selected)
    ("selected", "fg:#cc5454"),        # selected item
    ("text", "fg:#ffffff"),            # white for unselected items
    ("description", "fg:#888888"),     # gray for descriptions (via patch)
    ("instruction", "fg:#888888 italic"),# gray italic for hints
    ("purple", "fg:#673ab7"),          # purple for categories
    ("yellow", "fg:#f4bf75"),          # yellow for others
    ("cyan", "fg:#66d9ef"),            # cyan for template names
    ("red", "fg:#f92672"),             # red for locked
    ("magenta", "fg:#ae81ff"),         # magenta for pro
    ("green", "fg:#a6e22e"),           # green for free/alpha
]

