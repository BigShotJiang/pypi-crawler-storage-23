"""
Development experience module.
Provides development-specific tools and debugging utilities for admins in local dev environment.
"""

from foundry.constants import console
from foundry.interactive_utils import pause
from foundry.animations import AnimationSequence, InteractiveAnimationEngine
from foundry.animations.scenes import (
    LogoDisperseAnimation,
    LogoRevealAnimation,
    LogoStaticAnimation,
    ForgeAnimation,
)
from foundry.tools.development.build_tools import (
    check_build_version,
    check_build_differences,
    run_development_tests,
    show_development_info,
)
import questionary


def development_tools_menu():
    """Menu for development-specific tools and utilities"""
    
    while True:
        choices = [
            "Check Build Version",
            "Compare Build Differences",
            "Run Development Tests",
            "View Development Info",
            "Back to Main",
        ]
        
        choice = questionary.select(
            "🔧 Development Tools:",
            choices=choices,
            style=questionary.Style([("highlighted", "fg:#00ff00 bold")]),
        ).ask()
        
        if not choice or choice == "Back to Main":
            break
        
        if choice == "Check Build Version":
            check_build_version()
            pause()
        elif choice == "Compare Build Differences":
            check_build_differences()
            pause()
        elif choice == "Run Development Tests":
            run_development_tests()
            pause()
        elif choice == "View Development Info":
            show_development_info()
            pause()


def run_development_animated_experience():
    """Plays the development animation sequence with development tools."""
    engine = InteractiveAnimationEngine(fps=60, console=console)
    
    # 1. Play Intro Sequence once
    try:
        intro = AnimationSequence(
            [
                LogoRevealAnimation(duration=1.2),
                LogoStaticAnimation(duration=1.0),
                LogoDisperseAnimation(duration=2.0),
            ]
        )
        engine.play(intro)
    except KeyboardInterrupt:
        console.print("[yellow]Goodbye![/yellow]")
        return
    except Exception as e:
        console.print(f"[red]Error during intro: {e}[/]")
    
    # 2. Show development tools menu
    development_tools_menu()
    
    console.print("[yellow]Goodbye![/yellow]")
