"""
Observability and Insights sub-application.
Commands for diff, workspace management, and project introspection.
"""

from typing import Optional
from pathlib import Path
import typer
from rich.panel import Panel
from foundry.constants import console
from foundry.telemetry import log_event
from foundry.actions.diff import compute_diff
from foundry.workspaces import create_feature_workspace, list_workspaces


observability_app = typer.Typer(help="Observability and insights tools", invoke_without_command=True)


@observability_app.callback()
def observability_callback(ctx: typer.Context):
    """Observability, insights, and workspace tools."""
    if ctx.invoked_subcommand is None:
        _show_observability_menu()


def _show_observability_menu():
    """Show observability tools menu."""
    menu_text = """
    [bold cyan]Observability & Insights Tools[/bold cyan]

    [bold]Available Commands:[/bold]
    
    1. [cyan]sscli obs diff[/cyan]
       Compare base template, current code, and injected features
       Usage: sscli obs diff --project-path /path/to/project
       
    2. [cyan]sscli obs workspace create[/cyan]
       Create an isolated workspace for feature development
       Usage: sscli obs workspace create --feature commerce --template rails-api --output /tmp/workspace
       
    3. [cyan]sscli obs workspace list[/cyan]
       List all feature workspaces in current directory or search path
       Usage: sscli obs workspace list [--search-path /path]

    [bold]Examples:[/bold]
    
    # See what changed when commerce feature was injected
    $ sscli obs diff --project-path ~/my-project
    
    # Create isolated workspace for tunnel feature
    $ sscli obs workspace create --feature tunnel --template python-saas --output ./tunnel-dev
    
    # Find all workspaces
    $ sscli obs workspace list --search-path ~/projects
    """
    console.print(menu_text)


@observability_app.command("diff")
def diff_command(
    project_path: str = typer.Option(
        ..., help="Path to project (current directory with potential modifications)"
    ),
    base_template: Optional[str] = typer.Option(
        None, "--base-template", help="Path to base template (auto-detected if not provided)"
    ),
    feature: Optional[str] = typer.Option(
        None, "--feature", help="Specific feature to compare (all features if not specified)"
    ),
    template: Optional[str] = typer.Option(
        None, "--template", help="Template type (python-saas, rails-api, react-client, static-landing)"
    ),
    output_format: str = typer.Option(
        "colored",
        "--format",
        help="Output format (colored, unified, json)",
    ),
    output_file: Optional[str] = typer.Option(
        None, "--output", help="Save output to file"
    ),
):
    """
    3-way diff between base template, current code, and injected features.
    
    Highlights:
    - Lines added by template base
    - Lines added by feature injection
    - Lines modified by user (custom changes)
    """
    log_event("COMMAND", f"obs diff --project-path {project_path}")
    
    console.print(f"[cyan]→[/cyan] Computing 3-way diff for {project_path}...")
    
    result = compute_diff(
        project_path=project_path,
        base_template_path=base_template,
        feature_name=feature,
        template_name=template,
        output_format=output_format,
    )
    
    if not result.get("success"):
        console.print(f"[red]✗ Error: {result.get('error')}[/red]")
        raise typer.Exit(code=1)
    
    # Display results based on format
    if output_format == "json":
        import json
        output_text = json.dumps(result, indent=2)
    else:
        # Display formatted output with summary
        output_text = result.get("formatted_output", "")
        
        # Add metadata info
        metadata = result.get("metadata", {})
        if metadata:
            output_text += f"\n\n[bold]Project Metadata:[/bold]\n"
            output_text += f"  Base Template: {metadata.get('base_template_version')}\n"
            output_text += f"  Created: {metadata.get('created_at')}\n"
            output_text += f"  Features: {', '.join([f.get('name', f) if isinstance(f, dict) else f for f in metadata.get('features_injected', [])])}\n"
    
    # Output to console or file
    if output_file:
        Path(output_file).write_text(output_text, encoding="utf-8")
        console.print(f"[green]✓[/green] Diff saved to {output_file}")
    else:
        console.print(output_text)


@observability_app.command("workspace")
def workspace_command(ctx: typer.Context):
    """Manage feature isolation workspaces."""
    if ctx.invoked_subcommand is None:
        console.print("[yellow]Use 'sscli obs workspace create' or 'sscli obs workspace list'[/yellow]")


@observability_app.command("workspace create")
def workspace_create_command(
    feature: str = typer.Option(
        ..., "--feature", help="Feature name (commerce, tunnel, landing, etc.)"
    ),
    template: str = typer.Option(
        ..., "--template", help="Template type (python-saas, rails-api, react-client, static-landing)"
    ),
    output: str = typer.Option(
        ..., "--output", help="Output directory for the workspace"
    ),
    description: Optional[str] = typer.Option(
        None, "--description", help="Optional description of the workspace"
    ),
    include_tests: bool = typer.Option(
        True, "--include-tests", help="Include test files"
    ),
    include_docs: bool = typer.Option(
        True, "--include-docs", help="Include documentation files"
    ),
):
    """
    Create an isolated workspace showing only relevant files for a feature.
    
    This is useful for:
    - Understanding feature structure and dependencies
    - Testing feature integration in isolation
    - Code review focused on feature changes
    """
    log_event("COMMAND", f"obs workspace create --feature {feature} --template {template}")
    
    console.print(
        f"[cyan]→[/cyan] Creating feature workspace for [bold]{feature}[/bold] "
        f"in [bold]{template}[/bold]..."
    )
    
    result = create_feature_workspace(
        feature_name=feature,
        template_name=template,
        output_path=output,
        description=description,
        include_tests=include_tests,
        include_docs=include_docs,
    )
    
    if not result.get("success"):
        console.print(f"[red]✗ Error: {result.get('error')}[/red]")
        raise typer.Exit(code=1)
    
    # Display success info
    workspace_path = result.get("workspace_path")
    files_created = result.get("files_created")
    
    console.print(
        Panel(
            f"[green]✓ Workspace created successfully![/green]\n\n"
            f"[bold]Location:[/bold] {workspace_path}\n"
            f"[bold]Files included:[/bold] {files_created}\n"
            f"[bold]Metadata:[/bold] .feature-workspace.json\n\n"
            f"[cyan]Next steps:[/cyan]\n"
            f"  1. cd {workspace_path}\n"
            f"  2. Review WORKSPACE_README.md\n"
            f"  3. Explore feature files\n"
            f"  4. Compare with base template context files",
            title="Feature Workspace Created",
            border_style="green",
        )
    )


@observability_app.command("workspace list")
def workspace_list_command(
    search_path: Optional[str] = typer.Option(
        None, "--search-path", help="Directory to search (defaults to current directory)"
    ),
    json_output: bool = typer.Option(
        False, "--json", help="Output in JSON format"
    ),
):
    """
    List all feature isolation workspaces in the current directory or search path.
    """
    log_event("COMMAND", "obs workspace list")
    
    search_path = search_path or "."
    console.print(f"[cyan]→[/cyan] Searching for workspaces in {search_path}...")
    
    result = list_workspaces(search_path=search_path)
    
    if not result.get("success"):
        console.print(f"[red]✗ Error: {result.get('error')}[/red]")
        raise typer.Exit(code=1)
    
    workspaces = result.get("workspaces", [])
    
    if json_output:
        import json
        console.print(json.dumps(result, indent=2))
    else:
        if not workspaces:
            console.print(f"[yellow]No workspaces found in {search_path}[/yellow]")
        else:
            console.print(
                f"[bold cyan]Found {len(workspaces)} workspace(s):[/bold cyan]\n"
            )
            
            for i, ws in enumerate(workspaces, 1):
                console.print(
                    f"  {i}. [bold]{ws.get('feature_name')}[/bold] ({ws.get('template_name')})\n"
                    f"     Path: {ws.get('path')}\n"
                    f"     Files: {ws.get('files_included')}\n"
                    f"     Created: {ws.get('created_at')}\n"
                )


# For import in __init__.py
__all__ = ["observability_app"]
