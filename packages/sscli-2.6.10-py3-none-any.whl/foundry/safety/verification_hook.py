"""
Verification Hook System for Phase 2 - Post-Transformation Validation

Automatically runs linters and tests after codemods execute to verify
code quality and catch any issues introduced by transformations.

Supports:
- Python (ruff, mypy, pytest)
- Ruby/Rails (rubocop, db:migrate:status)
- JavaScript/React (eslint, prettier)
- Astro (astro build dry-run)
"""

import subprocess
import json
from abc import ABC, abstractmethod
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Optional, List, Dict, Tuple, Any
from enum import Enum
from datetime import datetime


class ProjectType(Enum):
    """Supported project types."""
    PYTHON = "python"
    RUBY = "ruby"
    JAVASCRIPT = "javascript"
    REACT = "react"
    ASTRO = "astro"
    NODE = "node"
    UNKNOWN = "unknown"


@dataclass
class ValidatorCommand:
    """Configuration for a single validator command."""
    name: str
    command: List[str]
    description: str
    critical: bool = False  # If True, failure blocks deployment
    enabled: bool = True

    def __str__(self) -> str:
        return f"{self.name}: {' '.join(self.command)}"


@dataclass
class ValidationResult:
    """Result of a single validator execution."""
    validator_name: str
    success: bool
    exit_code: int
    output: str = ""
    error_output: str = ""
    duration_ms: float = 0.0
    critical: bool = False

    def __str__(self) -> str:
        status = "✓" if self.success else "✗"
        return f"{status} {self.validator_name} (exit code: {self.exit_code})"

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        return asdict(self)


@dataclass
class ValidationReport:
    """Complete validation report for a project."""
    project_path: Path
    project_type: ProjectType
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())
    validators_run: int = 0
    validators_passed: int = 0
    validators_failed: int = 0
    critical_failures: int = 0
    results: List[ValidationResult] = field(default_factory=list)
    duration_ms: float = 0.0

    @property
    def passed(self) -> bool:
        """Check if all validators passed."""
        return self.validators_failed == 0

    @property
    def has_critical_failures(self) -> bool:
        """Check if any critical validators failed."""
        return self.critical_failures > 0

    def __str__(self) -> str:
        """Human-readable report."""
        lines = [
            f"\n{'='*60}",
            f"Verification Report: {self.project_type.value}",
            f"Path: {self.project_path}",
            f"Time: {self.timestamp}",
            f"{'='*60}",
            f"Validators: {self.validators_passed}/{self.validators_run} passed",
            f"Duration: {self.duration_ms:.2f}ms",
        ]

        if self.validators_failed > 0:
            lines.append(f"\n⚠️  FAILURES ({self.validators_failed}):")
            for result in self.results:
                if not result.success:
                    lines.append(f"  {result}")
                    if result.error_output:
                        # Show first 500 chars of error
                        error_snippet = result.error_output[:500]
                        if len(result.error_output) > 500:
                            error_snippet += "...[truncated]"
                        lines.append(f"    {error_snippet}")
        else:
            lines.append("\n✓ All validators passed!")

        lines.append(f"{'='*60}\n")
        return "\n".join(lines)

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        return {
            "project_path": str(self.project_path),
            "project_type": self.project_type.value,
            "timestamp": self.timestamp,
            "validators_run": self.validators_run,
            "validators_passed": self.validators_passed,
            "validators_failed": self.validators_failed,
            "critical_failures": self.critical_failures,
            "passed": self.passed,
            "has_critical_failures": self.has_critical_failures,
            "duration_ms": self.duration_ms,
            "results": [r.to_dict() for r in self.results],
        }

    def as_json(self) -> str:
        """Machine-readable JSON report."""
        return json.dumps(self.to_dict(), indent=2)


class VerificationHook:
    """
    Automatic verification system for post-codemod validation.
    
    Detects project type, runs appropriate validators, and reports results.
    Supports rollback on critical failures if needed.
    """

    def __init__(self, skip_verification: bool = False):
        """
        Initialize verification hook.

        Args:
            skip_verification: If True, skip all verification checks
        """
        self.skip_verification = skip_verification
        self.validators_config: Dict[ProjectType, List[ValidatorCommand]] = {}
        self._setup_validators()

    def _setup_validators(self) -> None:
        """Configure validators for each project type."""
        self.validators_config = {
            ProjectType.PYTHON: [
                ValidatorCommand(
                    name="ruff-check",
                    command=["ruff", "check", "."],
                    description="Python linter and formatter (ruff)",
                    critical=True,
                ),
                ValidatorCommand(
                    name="ruff-format-check",
                    command=["ruff", "format", ".", "--check"],
                    description="Python code formatter (ruff format)",
                    critical=False,
                ),
                ValidatorCommand(
                    name="mypy",
                    command=["mypy", ".", "--ignore-missing-imports"],
                    description="Python type checker (mypy)",
                    critical=False,
                ),
                ValidatorCommand(
                    name="pytest-syntax",
                    command=["python", "-m", "pytest", "--collect-only"],
                    description="Python test collection (pytest syntax check)",
                    critical=True,
                ),
            ],
            ProjectType.RUBY: [
                ValidatorCommand(
                    name="rubocop",
                    command=["rubocop", "."],
                    description="Ruby linter and style checker (rubocop)",
                    critical=False,
                ),
                ValidatorCommand(
                    name="ruby-syntax",
                    command=["ruby", "-c", "-S", "**/*.rb"],
                    description="Ruby syntax check",
                    critical=True,
                ),
                ValidatorCommand(
                    name="rails-db-status",
                    command=["rails", "db:migrate:status"],
                    description="Rails database migration status",
                    critical=False,
                ),
            ],
            ProjectType.JAVASCRIPT: [
                ValidatorCommand(
                    name="eslint",
                    command=["eslint", ".", "--max-warnings", "0"],
                    description="JavaScript linter (eslint)",
                    critical=True,
                ),
                ValidatorCommand(
                    name="prettier-check",
                    command=["prettier", ".", "--check"],
                    description="Code formatter check (prettier)",
                    critical=False,
                ),
            ],
            ProjectType.REACT: [
                ValidatorCommand(
                    name="eslint",
                    command=["eslint", "src", "--max-warnings", "0"],
                    description="JavaScript/React linter (eslint)",
                    critical=True,
                ),
                ValidatorCommand(
                    name="prettier-check",
                    command=["prettier", "src", "--check"],
                    description="Code formatter check (prettier)",
                    critical=False,
                ),
                ValidatorCommand(
                    name="jest-syntax",
                    command=["npm", "run", "test", "--", "--listTests"],
                    description="React test collection (jest)",
                    critical=False,
                ),
            ],
            ProjectType.ASTRO: [
                ValidatorCommand(
                    name="astro-build",
                    command=["astro", "build", "--dry-run"],
                    description="Astro project build check (dry-run)",
                    critical=True,
                ),
                ValidatorCommand(
                    name="eslint",
                    command=["eslint", "src"],
                    description="JavaScript linter (eslint)",
                    critical=False,
                ),
            ],
        }

    def detect_project_type(self, project_path: Path) -> ProjectType:
        """
        Detect project type from project structure.

        Args:
            project_path: Path to project root

        Returns:
            ProjectType enum value
        """
        project_path = Path(project_path)

        # Check for Python project
        if (project_path / "pyproject.toml").exists() or (
            project_path / "setup.py"
        ).exists():
            if (project_path / "src").exists():
                return ProjectType.PYTHON
            # Could be either Python or other, check for rails indicators next
            if not ((project_path / "config").exists() and (
                project_path / "app"
            ).exists()):
                return ProjectType.PYTHON

        # Check for Rails project
        if (project_path / "config" / "routes.rb").exists() and (
            project_path / "app"
        ).exists():
            return ProjectType.RUBY

        # Check for Astro project
        if (project_path / "astro.config.mjs").exists() or (
            project_path / "astro.config.js"
        ).exists():
            return ProjectType.ASTRO

        # Check for React project
        if (project_path / "package.json").exists():
            package_json = project_path / "package.json"
            try:
                with open(package_json) as f:
                    import json
                    content = json.load(f)
                    deps = {
                        **content.get("dependencies", {}),
                        **content.get("devDependencies", {}),
                    }

                    if "react" in deps:
                        return ProjectType.REACT
                    elif "astro" in deps:
                        return ProjectType.ASTRO
                    else:
                        return ProjectType.JAVASCRIPT
            except (json.JSONDecodeError, IOError):
                return ProjectType.NODE

        return ProjectType.UNKNOWN

    def get_validators(
        self, project_type: ProjectType
    ) -> List[ValidatorCommand]:
        """
        Get list of validators for a project type.

        Args:
            project_type: ProjectType enum value

        Returns:
            List of ValidatorCommand configurations
        """
        return self.validators_config.get(project_type, [])

    def _run_validator(
        self, validator: ValidatorCommand, project_path: Path
    ) -> ValidationResult:
        """
        Run a single validator command.

        Args:
            validator: ValidatorCommand configuration
            project_path: Path to project root

        Returns:
            ValidationResult with execution details
        """
        import time

        if not validator.enabled:
            return ValidationResult(
                validator_name=validator.name,
                success=True,
                exit_code=0,
                output="(skipped)",
                critical=validator.critical,
            )

        start_time = time.time()
        try:
            result = subprocess.run(
                validator.command,
                cwd=str(project_path),
                capture_output=True,
                text=True,
                timeout=300,  # 5 minute timeout
            )

            duration_ms = (time.time() - start_time) * 1000

            return ValidationResult(
                validator_name=validator.name,
                success=result.returncode == 0,
                exit_code=result.returncode,
                output=result.stdout,
                error_output=result.stderr,
                duration_ms=duration_ms,
                critical=validator.critical,
            )
        except subprocess.TimeoutExpired:
            duration_ms = (time.time() - start_time) * 1000
            return ValidationResult(
                validator_name=validator.name,
                success=False,
                exit_code=-1,
                error_output="Validator timed out after 300 seconds",
                duration_ms=duration_ms,
                critical=validator.critical,
            )
        except FileNotFoundError as e:
            duration_ms = (time.time() - start_time) * 1000
            return ValidationResult(
                validator_name=validator.name,
                success=False,
                exit_code=-1,
                error_output=f"Validator command not found: {str(e)}",
                duration_ms=duration_ms,
                critical=validator.critical,
            )
        except Exception as e:
            duration_ms = (time.time() - start_time) * 1000
            return ValidationResult(
                validator_name=validator.name,
                success=False,
                exit_code=-1,
                error_output=f"Validator execution error: {str(e)}",
                duration_ms=duration_ms,
                critical=validator.critical,
            )

    def run_validators(
        self, project_path: Path, specific_validators: Optional[List[str]] = None
    ) -> ValidationReport:
        """
        Execute all applicable validators for a project.

        Args:
            project_path: Path to project root
            specific_validators: If provided, only run these validators (by name)

        Returns:
            ValidationReport with all results
        """
        import time

        project_path = Path(project_path)
        start_time = time.time()

        report = ValidationReport(
            project_path=project_path,
            project_type=self.detect_project_type(project_path),
        )

        # Skip if requested
        if self.skip_verification:
            report.duration_ms = (time.time() - start_time) * 1000
            return report

        validators = self.get_validators(report.project_type)

        # Filter by specific validators if provided
        if specific_validators:
            validators = [
                v for v in validators if v.name in specific_validators
            ]

        # Run each validator
        for validator in validators:
            result = self._run_validator(validator, project_path)
            report.results.append(result)
            report.validators_run += 1

            if result.success:
                report.validators_passed += 1
            else:
                report.validators_failed += 1
                if result.critical:
                    report.critical_failures += 1

        report.duration_ms = (time.time() - start_time) * 1000
        return report

    def format_report(self, report: ValidationReport) -> str:
        """
        Format validation report as human-readable text.

        Args:
            report: ValidationReport object

        Returns:
            Formatted string report
        """
        return str(report)

    def as_json(self, report: ValidationReport) -> str:
        """
        Format validation report as machine-readable JSON.

        Args:
            report: ValidationReport object

        Returns:
            JSON-formatted report string
        """
        return report.as_json()

    def configure_validator(
        self,
        project_type: ProjectType,
        validator_name: str,
        enabled: Optional[bool] = None,
        critical: Optional[bool] = None,
    ) -> None:
        """
        Configure a specific validator (enable/disable, set criticality).

        Args:
            project_type: ProjectType enum value
            validator_name: Name of validator to configure
            enabled: If provided, enable/disable this validator
            critical: If provided, set critical flag
        """
        validators = self.validators_config.get(project_type, [])
        for validator in validators:
            if validator.name == validator_name:
                if enabled is not None:
                    validator.enabled = enabled
                if critical is not None:
                    validator.critical = critical
                break

    def add_custom_validator(
        self,
        project_type: ProjectType,
        name: str,
        command: List[str],
        description: str,
        critical: bool = False,
    ) -> None:
        """
        Add a custom validator for a project type.

        Args:
            project_type: ProjectType enum value
            name: Unique validator name
            command: Command to run (as list of strings)
            description: Human-readable description
            critical: If True, failure blocks deployment
        """
        if project_type not in self.validators_config:
            self.validators_config[project_type] = []

        validator = ValidatorCommand(
            name=name,
            command=command,
            description=description,
            critical=critical,
            enabled=True,
        )
        self.validators_config[project_type].append(validator)

    @staticmethod
    def get_command_to_enable_validator(
        project_type: ProjectType, validator_name: str
    ) -> Optional[str]:
        """
        Get the shell command to enable/install a missing validator.

        Args:
            project_type: ProjectType enum value
            validator_name: Name of validator

        Returns:
            Installation command or None
        """
        install_commands = {
            (ProjectType.PYTHON, "ruff"): "pip install ruff",
            (ProjectType.PYTHON, "mypy"): "pip install mypy",
            (ProjectType.RUBY, "rubocop"): "gem install rubocop",
            (ProjectType.JAVASCRIPT, "eslint"): "npm install --save-dev eslint",
            (ProjectType.JAVASCRIPT, "prettier"): "npm install --save-dev prettier",
            (ProjectType.REACT, "eslint"): "npm install --save-dev eslint",
            (ProjectType.REACT, "prettier"): "npm install --save-dev prettier",
            (ProjectType.ASTRO, "astro"): "npm install astro",
        }
        return install_commands.get((project_type, validator_name))
