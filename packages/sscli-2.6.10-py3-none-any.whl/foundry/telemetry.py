import datetime
from pathlib import Path
from foundry.constants import ALPHA_FEEDBACK_FORM

LOG_FILE = Path(".session.log")


def log_event(event_type: str, details: str = ""):
    """Log an event to the local session log."""
    timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    log_entry = f"[{timestamp}] {event_type.upper()}: {details}\n"

    try:
        with open(LOG_FILE, "a", encoding="utf-8") as f:
            f.write(log_entry)
    except Exception:
        # Fallback to silent failure to not break the CLI experience
        pass


def get_feedback_link() -> str:
    """Returns the feedback form link."""
    return ALPHA_FEEDBACK_FORM
