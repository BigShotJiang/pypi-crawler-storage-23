from typing import List, Union
from rich.cells import cell_len
from rich.console import Group
from rich.text import Text
from .core import FRAME_WIDTH, FRAME_HEIGHT, FRAME_COLOR


def draw_frame(
    content_lines: List[Union[str, Text]],
    height: int = FRAME_HEIGHT,
    width: int = FRAME_WIDTH,
    status_line: str = None,
) -> Group:
    """Draw a bordered frame around content with optional status line."""
    content = pad_content(content_lines, height=height, width=width)
    frame = [Text(f"╔{'═' * width}╗", FRAME_COLOR)]
    for line in content:
        styled_line = Text("║", FRAME_COLOR)
        styled_line.append(line)
        styled_line.append("║", FRAME_COLOR)
        frame.append(styled_line)
    frame.append(Text(f"╚{'═' * width}╝", FRAME_COLOR))
    if status_line:
        frame.append(Text(f"  ● {status_line}", "dim"))
    return Group(*frame)


def pad_content(lines: List[Union[str, Text]], height: int, width: int) -> List[Text]:
    """Ensure content fits frame dimensions."""
    padded = []
    for i in range(height):
        if i < len(lines):
            line = lines[i] if isinstance(lines[i], Text) else Text(lines[i])
            plain = line.plain
            if cell_len(plain) < width:
                line.append(" " * (width - cell_len(plain)))
            elif cell_len(plain) > width:
                line = line[:width]
            padded.append(line)
        else:
            padded.append(Text(" " * width))
    return padded
