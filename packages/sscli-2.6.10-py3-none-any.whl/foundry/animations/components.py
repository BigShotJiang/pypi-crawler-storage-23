"""
Reusable UI components: logos, menus, text blocks.
Uses the Canvas system for rendering.
"""

from typing import List, Tuple

from rich.text import Text

from .assets import FINAL_TREE, SPROUT, SUN_CIRCLE
from .core import FRAME_HEIGHT, FRAME_WIDTH, Canvas


def render_stars(canvas: Canvas, count: int = 8, seed: int = 42):
    """Render stable background stars using a fixed seed."""
    import random

    rng = random.Random(seed)
    for _ in range(count):
        rx = rng.randint(0, canvas.width - 1)
        ry = rng.randint(0, canvas.height - 5)
        char = rng.choice([".", "+", "·"])
        canvas.draw_text(char, rx, ry, style="bright_white")


def render_sun(canvas: Canvas, pos: Tuple[int, int], lines: List[str] = SUN_CIRCLE):
    """Render the sun sprite with yellow styling and transparency."""
    y, x = pos
    canvas.draw_sprite(lines, x, y, style="yellow", transparent=True)


def render_tree(
    canvas: Canvas, tree_pos: Tuple[int, int], tree_lines: List[str] = FINAL_TREE
):
    """Render tree ASCII art onto the canvas with semantic coloring and transparency."""
    x_offset, y_start = tree_pos
    for i, line in enumerate(tree_lines):
        styled_line = Text(line)
        for char_idx, char in enumerate(line):
            if char in ("0", "O", "|"):
                styled_line.stylize("bold yellow", char_idx, char_idx + 1)
            elif char not in (" ", ".", "+", '"', ":"):
                styled_line.stylize("green", char_idx, char_idx + 1)
        canvas.draw_text_transparent(styled_line, x_offset, y_start + i)


def render_base_background(
    canvas: Canvas,
    show_sprout: bool = False,
    sprout_y_offset: int = 0,
    tree_growth: float = 0.0,
    **kwargs
):
    """Render background elements (grass, sprout, tree) directly onto a canvas."""
    base_y = FRAME_HEIGHT - 1

    # 1. Render dynamic grass at bottom
    grass_wind = kwargs.get("grass_wind", 0.6)
    grass_chars = "uvw"
    grass_idx = min(2, int(grass_wind * 1.5))
    grass_char = grass_chars[grass_idx]
    canvas.draw_text(grass_char * FRAME_WIDTH, 0, base_y, style="green")

    # 2. Render Tree or Sprout
    x_pos = 68
    if tree_growth > 0.3:
        if tree_growth >= 1.0:
            num_lines = len(FINAL_TREE)
        else:
            tree_progress = (tree_growth - 0.3) / 0.7
            num_lines = min(len(FINAL_TREE), int(tree_progress * len(FINAL_TREE)) + 2)

        start_y = base_y - num_lines + sprout_y_offset
        for i in range(num_lines):
            line_idx = len(FINAL_TREE) - num_lines + i
            if line_idx < 0:
                continue
            line_str = FINAL_TREE[line_idx]
            y = start_y + i
            if 0 <= y < FRAME_HEIGHT:
                line_text = Text(line_str)
                for char_idx, char in enumerate(line_str):
                    if char in ("#", "+", "(", ")", "/", "\\"):
                        line_text.stylize("bold green", char_idx, char_idx + 1)
                    elif char in ("0", "O", "|"):
                        line_text.stylize("bold yellow", char_idx, char_idx + 1)
                tree_x = x_pos - (len(line_str) // 2)
                canvas.draw_text(line_text, tree_x, y)
    elif show_sprout or (tree_growth > 0 and tree_growth <= 0.3):
        sprout_prog = min(1.0, tree_growth / 0.3) if tree_growth > 0 else 1.0
        s_idx = int(sprout_prog * 2)
        s_lines = SPROUT[: s_idx + 1]
        start_y = base_y - len(s_lines) + sprout_y_offset
        for i, sl in enumerate(s_lines):
            canvas.draw_text(sl, x_pos, start_y + i, style="bold green")


def get_base_background(
    show_sprout: bool = False,
    sprout_y_offset: int = 0,
    tree_growth: float = 0.0,
    **kwargs
) -> List[Text]:
    """Legacy helper that creates a canvas, renders to it, and returns lines."""
    canvas = Canvas()
    render_base_background(canvas, show_sprout, sprout_y_offset, tree_growth, **kwargs)
    return canvas.render()


def render_nature(state, canvas: Canvas):
    """Render nature background based on state directly to canvas."""
    render_base_background(
        canvas,
        show_sprout=(state.tree_growth > 0),
        tree_growth=state.tree_growth,
        grass_wind=state.grass_wind,
    )
