"""
Logo disperse animation: The logo breaks into characters that fall to the bottom right.
"""

import math
import random

from ..animation import Animation, AnimationConfig
from ..assets import RAW_LOGO
from ..components import render_base_background, render_stars
from ..core import FRAME_HEIGHT, FRAME_WIDTH, Canvas
from ..engine.frame_buffer import FrameBuffer
from ..engine.state import AnimationState, ScenePhase


class LogoDisperseAnimation(Animation):
    """
    Logo disperse animation: Characters fall and slide towards the bottom-right target.
    Target: 10 units from right (x=70), bottom of screen (y=21).
    """

    def __init__(self, duration: float = 2.0):
        super().__init__(AnimationConfig(duration=duration))
        self.particles = []
        self.target_x = FRAME_WIDTH - 10
        self.target_y = FRAME_HEIGHT - 2  # Just above the grass

    def _update_impl(self, dt: float, state: AnimationState) -> AnimationState:
        if not self.particles:
            # Initialize particles from logo
            logo_y = 4
            logo_x = (FRAME_WIDTH - len(RAW_LOGO[0])) // 2

            for y, line in enumerate(RAW_LOGO):
                for x, char in enumerate(line):
                    if char != " ":
                        self.particles.append(
                            {
                                "ox": logo_x + x,  # Original X
                                "oy": logo_y + y,  # Original Y
                                "cx": logo_x + x,  # Current X
                                "cy": logo_y + y,  # Current Y
                                "char": char,
                                "delay": random.uniform(0, self.config.duration * 0.4),
                                "speed": random.uniform(1.5, 3.0),
                                "wind_factor": random.uniform(0.5, 2.0),
                            }
                        )

        # Update particles
        for p in self.particles:
            rel_time = self.elapsed_time - p["delay"]
            if rel_time > 0:
                # Progress for this specific particle
                # We want them to reach target by the end of animation duration
                particle_duration = self.config.duration - p["delay"]
                if particle_duration <= 0:
                    particle_duration = 0.1

                prog = min(1.0, rel_time / particle_duration)

                # Ease in quint
                prog = prog * prog * prog

                # Path: original -> target
                # Add some "wind" curve
                curve = math.sin(prog * math.pi) * 10 * p["wind_factor"]

                p["cx"] = p["ox"] + (self.target_x - p["ox"]) * prog + curve
                p["cy"] = p["oy"] + (self.target_y - p["oy"]) * prog

        # Keep grass moving
        import math

        wind = 0.6 + 0.2 * math.sin(state.elapsed_time * 2)

        return state.with_updates(scene_phase=ScenePhase.LOGO_DISSOLVE, grass_wind=wind)

    def render(self, frame_buffer: FrameBuffer, state: AnimationState) -> None:
        # 1. Background layer
        bg_canvas = Canvas(FRAME_WIDTH, FRAME_HEIGHT)
        render_stars(bg_canvas, count=15)
        # Tree is not yet growing (will sprout in next scene)
        render_base_background(bg_canvas, tree_growth=0.0, grass_wind=state.grass_wind)
        frame_buffer.add_layer("background", bg_canvas.buffer)

        # 2. Particle layer
        part_canvas = Canvas(FRAME_WIDTH, FRAME_HEIGHT)
        for p in self.particles:
            x, y = int(p["cx"]), int(p["cy"])
            if 0 <= x < FRAME_WIDTH and 0 <= y < FRAME_HEIGHT:
                part_canvas.draw_text(p["char"], x, y, style="bold cyan")

        frame_buffer.add_layer("logo_particles", part_canvas.buffer)
