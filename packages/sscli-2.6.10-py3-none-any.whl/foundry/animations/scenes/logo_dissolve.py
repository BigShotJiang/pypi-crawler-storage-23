"""
Logo dissolve animation: The logo breaks apart and falls.
"""

import random

from ..animation import Animation, AnimationConfig
from ..assets import SMALL_LOGO
from ..components import render_base_background, render_stars
from ..core import FRAME_HEIGHT, FRAME_WIDTH, Canvas
from ..engine.frame_buffer import FrameBuffer
from ..engine.state import AnimationState, ScenePhase


class LogoDissolveAnimation(Animation):
    """
    Logo dissolve animation: Logo fragments and falls down.
    """

    def __init__(self, duration: float = 2.0):
        super().__init__(AnimationConfig(duration=duration))
        self.particles = []

    def _update_impl(self, dt: float, state: AnimationState) -> AnimationState:
        if not self.particles:
            # Initialize particles from logo
            logo_y = FRAME_HEIGHT // 3
            for y, line in enumerate(SMALL_LOGO):
                logo_x = (FRAME_WIDTH - len(line)) // 2
                for x, char in enumerate(line):
                    if char != " ":
                        self.particles.append(
                            {
                                "x": logo_x + x,
                                "y": logo_y + y,
                                "char": char,
                                "vx": random.uniform(-5, 5),
                                "vy": random.uniform(5, 15),
                            }
                        )

        # Update particles
        for p in self.particles:
            p["x"] += p["vx"] * dt
            p["y"] += p["vy"] * dt

        return state.with_updates(scene_phase=ScenePhase.LOGO_DISSOLVE)

    def render(self, frame_buffer: FrameBuffer, state: AnimationState) -> None:
        # 1. Background layer
        bg_canvas = Canvas(FRAME_WIDTH, FRAME_HEIGHT)
        render_stars(bg_canvas, count=15)
        render_base_background(bg_canvas, tree_growth=0.3, grass_wind=state.grass_wind)
        frame_buffer.add_layer("background", bg_canvas.buffer)

        # 2. Particle layer
        part_canvas = Canvas(FRAME_WIDTH, FRAME_HEIGHT)
        progress = self.get_progress()

        for p in self.particles:
            if 0 <= int(p["x"]) < FRAME_WIDTH and 0 <= int(p["y"]) < FRAME_HEIGHT:
                style = "bold blue"
                if progress > 0.6:
                    style = "bold blue dim"
                part_canvas.draw_text(p["char"], int(p["x"]), int(p["y"]), style=style)

        frame_buffer.add_layer("particles", part_canvas.buffer)
