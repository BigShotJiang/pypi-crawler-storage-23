"""
Entry point for running RLM Code as a module.

Allows execution via: python -m rlm_code
"""

from .main import main

if __name__ == "__main__":
    main()
