"""Tests for RLM module."""
