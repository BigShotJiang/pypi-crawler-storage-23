---
name: Bug report
about: Report a bug in agent-recall
labels: bug
---

**Describe the bug**
A clear description of what went wrong.

**To reproduce**
Steps or code to reproduce the behavior.

**Expected behavior**
What you expected to happen.

**Environment**
- Python version:
- agent-recall version:
- OS:
