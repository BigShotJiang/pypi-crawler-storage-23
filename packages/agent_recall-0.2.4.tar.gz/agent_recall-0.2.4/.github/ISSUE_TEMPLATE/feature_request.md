---
name: Feature request
about: Suggest a new feature
labels: enhancement
---

**Problem**
What problem does this solve?

**Proposed solution**
How should it work?

**Alternatives considered**
Any other approaches you've thought about.
