# PYTHON_ARGCOMPLETE_OK
"""drp — file and text sharing from the command line."""

from __future__ import annotations

import sys


def main(argv: list[str] | None = None) -> int:
    from cli.commands import build_parser

    # `drp -` → `drp up -`  (pipe shortcut)
    args_in = argv if argv is not None else sys.argv[1:]
    if args_in and args_in[0] == "-":
        args_in = ["up", "-"] + args_in[1:]

    p = build_parser()

    try:
        import argcomplete
        argcomplete.autocomplete(p)
    except ImportError:
        pass

    # Catch argparse errors and show them cleanly through rich
    original_error = p.error
    def _clean_error(message):
        from rich.console import Console
        Console(stderr=True).print(f"[red]drp:[/red] {message}")
        sys.exit(2)
    p.error = _clean_error

    ns = p.parse_args(args_in)

    if ns.version:
        from cli import __version__
        print(f"drp {__version__}")
        return 0

    if ns.command is None:
        p.print_help()
        return 0

    try:
        return _dispatch(ns)
    except KeyboardInterrupt:
        return 130
    except Exception as exc:
        # Unexpected — report in background and show clean message
        from cli.crash.reporter import handle
        handle(ns.command, exc)
        return 1


def _dispatch(ns) -> int:
    from cli import session
    from cli.session import EnsureGuestError

    if ns.command == "login":
        from cli.commands.login import run
        return run(ns)

    if ns.command == "up":
        from cli.commands.up import run
        return run(ns)

    # Commands below need an authenticated session (guest counts)
    if not session.is_logged_in():
        from rich.console import Console
        Console(stderr=True).print(
            "[red]drp:[/red] not logged in — run [bold]drp login[/bold]"
        )
        return 1

    if ns.command == "ls":
        from cli.commands.ls import run
        return run(ns)

    if ns.command == "set":
        from cli.commands.set import run
        return run(ns)

    if ns.command == "rekey":
        from cli.commands.rekey import run
        return run(ns)

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
