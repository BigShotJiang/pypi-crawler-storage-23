"""CLI UI helpers — spinner, progress bars, rich output."""

from __future__ import annotations

import os
import sys
from contextlib import contextmanager
from typing import Iterator

from rich.console import Console
from rich.progress import (
    BarColumn,
    DownloadColumn,
    Progress,
    SpinnerColumn,
    TaskID,
    TextColumn,
    TimeRemainingColumn,
    TransferSpeedColumn,
)

console = Console()
err_console = Console(stderr=True)


@contextmanager
def spinner(message: str = "Working...") -> Iterator[None]:
    if not sys.stderr.isatty():
        yield
        return
    with err_console.status(f"  {message}", spinner="dots"):
        yield


def _make_progress() -> Progress:
    return Progress(
        SpinnerColumn(spinner_name="dots", style="green"),
        TextColumn("[bold]{task.description}"),
        BarColumn(bar_width=30, style="green", complete_style="green"),
        DownloadColumn(),
        TransferSpeedColumn(),
        TimeRemainingColumn(),
        console=err_console,
        transient=True,
        refresh_per_second=10,
    )


def download_to_file(
    response,
    dest: str,
    *,
    filename: str = "",
    chunk_size: int = 65536,
) -> int:
    total = int(response.headers.get("content-length", 0))
    label = filename or os.path.basename(dest)

    if not sys.stderr.isatty() or total == 0:
        written = 0
        with open(dest, "wb") as f:
            for chunk in response.iter_content(chunk_size):
                f.write(chunk)
                written += len(chunk)
        return written

    written = 0
    with _make_progress() as progress:
        task = progress.add_task(label, total=total)
        with open(dest, "wb") as f:
            for chunk in response.iter_content(chunk_size):
                f.write(chunk)
                written += len(chunk)
                progress.update(task, advance=len(chunk))
    return written


def upload_file(
    api_post_fn,
    url: str,
    path: str,
    *,
    field: str = "file",
    filename: str = "",
    extra_data: dict | None = None,
):
    from cli.session import _session, api_url

    fname = filename or os.path.basename(path)
    file_size = os.path.getsize(path)

    if not sys.stderr.isatty() or file_size == 0:
        with open(path, "rb") as f:
            return api_post_fn(url, files={field: (fname, f)}, data=extra_data or {})

    with _make_progress() as progress:
        task = progress.add_task(fname, total=file_size)
        with open(path, "rb") as raw:
            wrapper = _ProgressFileWrapper(raw, progress, task)
            s = _session()
            return s.post(api_url(url), files={field: (fname, wrapper)},
                          data=extra_data or {})


class _ProgressFileWrapper:
    def __init__(self, fp, progress: Progress, task_id: TaskID) -> None:
        self._fp = fp
        self._progress = progress
        self._task_id = task_id

    def read(self, size: int = -1) -> bytes:
        data = self._fp.read(size)
        if data:
            self._progress.update(self._task_id, advance=len(data))
        return data

    def seek(self, *args, **kwargs):
        return self._fp.seek(*args, **kwargs)

    def tell(self) -> int:
        return self._fp.tell()

    def __len__(self) -> int:
        pos = self._fp.tell()
        self._fp.seek(0, 2)
        size = self._fp.tell()
        self._fp.seek(pos)
        return size
