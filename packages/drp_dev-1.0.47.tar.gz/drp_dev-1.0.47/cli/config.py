"""
CLI configuration — persistent settings stored per-user under a scoped directory.

    $DRP_CONFIG_BASE/<username>/session.toml   ← auth token / session
    $DRP_CONFIG_BASE/<username>/keys.toml      ← encryption keystore
    $DRP_CONFIG_BASE/<username>/prefs.toml     ← any other user prefs

DRP_CONFIG_BASE defaults to ~/.config/drp when not set in the environment.

    from cli import config
    cfg = config.load()
    cfg["host"]         # "https://drp.fyi"
    cfg["token"]        # bearer token (empty = not logged in)
    cfg["username"]     # logged-in user's name
    config.save(cfg)
"""

from __future__ import annotations

import os
import stat
import sys
from pathlib import Path
from typing import Any

if sys.version_info >= (3, 11):
    import tomllib
else:
    import tomli as tomllib  # type: ignore[no-redef]

import tomli_w


# ── Paths ─────────────────────────────────────────────────────────────────────

def config_base() -> Path:
    base = os.environ.get("DRP_CONFIG_BASE", "")
    return Path(base).expanduser() if base else Path.home() / ".config" / "drp"


def user_dir(username: str) -> Path:
    d = config_base() / username
    d.mkdir(parents=True, exist_ok=True)
    return d


def session_path(username: str) -> Path:
    return user_dir(username) / "session.toml"


def keys_path(username: str) -> Path:
    return user_dir(username) / "keys.toml"


def prefs_path(username: str) -> Path:
    return user_dir(username) / "prefs.toml"


# ── Defaults ──────────────────────────────────────────────────────────────────

_DEFAULTS: dict[str, Any] = {
    "host": "https://drp.fyi",
    "token": "",
    "username": "",
    "email": "",
}


# ── Helpers ───────────────────────────────────────────────────────────────────

def _read_toml(path: Path) -> dict[str, Any]:
    if not path.exists():
        return {}
    try:
        with path.open("rb") as f:
            return tomllib.load(f)
    except Exception:
        return {}


def _write_toml(path: Path, data: dict[str, Any], private: bool = False) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("wb") as f:
        tomli_w.dump(data, f)
    if private:
        path.chmod(stat.S_IRUSR | stat.S_IWUSR)  # 600


# ── Load / save ───────────────────────────────────────────────────────────────

def load(username: str = "") -> dict[str, Any]:
    cfg = dict(_DEFAULTS)
    if username:
        cfg.update(_read_toml(session_path(username)))
    return cfg


def save(cfg: dict[str, Any], username: str = "") -> None:
    username = username or cfg.get("username", "")
    path = session_path(username) if username else config_base() / "config.toml"
    _write_toml(path, cfg, private=bool(username))


def get(key: str, username: str = "", default: Any = None) -> Any:
    return load(username).get(key, default)


def set_val(key: str, value: Any, username: str = "") -> None:
    cfg = load(username)
    cfg[key] = value
    save(cfg, username)


def is_setup() -> bool:
    return any(config_base().iterdir()) if config_base().exists() else False