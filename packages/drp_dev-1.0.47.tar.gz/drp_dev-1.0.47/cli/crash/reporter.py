"""
Crash reporter — scrubs sensitive data, POSTs to the server in the background,
and returns a short fingerprint the user can quote in a bug report.

Usage:
    from cli.crash.reporter import handle
    try:
        run_command(...)
    except Exception as exc:
        handle("up", exc)
"""

from __future__ import annotations

import hashlib
import json
import platform
import re
import threading
import traceback
import urllib.request
import os

from cli import __version__

_HOME = os.path.expanduser("~")

# Patterns to scrub before anything leaves the machine
_SCRUB = [
    (re.compile(r"(TOKEN|SECRET|KEY|PASSWORD|CREDENTIAL|AUTH)[=:]\s*\S+", re.I), r"\1=***"),
    (re.compile(r"(Bearer\s+)\S+", re.I), r"\1<token>"),
    (re.compile(r"\b[0-9a-fA-F]{32,}\b"), "<token>"),
    (re.compile(r"[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+"), "<email>"),
]


def _scrub(text: str) -> str:
    out = text.replace(_HOME, "~")
    for pattern, replacement in _SCRUB:
        out = pattern.sub(replacement, out)
    return out


def _fingerprint(exc: BaseException) -> str:
    frames = "|".join(
        f"{f.filename.rsplit('/', 1)[-1]}:{f.lineno}:{f.name}"
        for f in traceback.extract_tb(exc.__traceback__)
    )
    raw = f"{type(exc).__qualname__}|{frames}"
    return hashlib.sha256(raw.encode()).hexdigest()


def _post(host: str, payload: bytes) -> None:
    """Fire-and-forget POST — runs in a daemon thread, never raises."""
    try:
        req = urllib.request.Request(
            f"{host}/api/v1/crash/",
            data=payload,
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        urllib.request.urlopen(req, timeout=5)
    except Exception:
        pass


def handle(command: str, exc: BaseException) -> None:
    """
    Called from main's except block.

    - Scrubs the traceback and POSTs it to the server (background thread).
    - Prints a single user-facing line with the fingerprint ref.
    """
    tb_text = "".join(traceback.format_exception(type(exc), exc, exc.__traceback__))
    fp = _fingerprint(exc)

    payload = json.dumps({
        "fingerprint": fp,
        "command": command,
        "exc_type": type(exc).__qualname__,
        "exc_message": _scrub(str(exc)),
        "traceback": _scrub(tb_text),
        "cli_version": __version__,
        "python_version": platform.python_version(),
        "platform": platform.platform(),
    }).encode()

    try:
        from cli import config
        host = config.load().get("host", "").rstrip("/") or "https://drp.fyi"
    except Exception:
        host = "https://drp.fyi"

    threading.Thread(target=_post, args=(host, payload), daemon=True).start()

    # Clear, single user-facing message — no traceback noise
    from rich.console import Console
    Console(stderr=True).print(
        f"[red]drp '{command}' encountered an error[/red] "
        f"[dim](ref {fp[:8]})[/dim] — "
        "please report at [link=https://github.com/vicnasdev/drp/issues]"
        "github.com/vicnasdev/drp/issues[/link]"
    )
