"""ls — List files on your drive."""

from __future__ import annotations

from cli.commands import Arg, Command, register

register(Command(
    name="ls",
    description="List files on your drive.",
    args=(
        Arg("path",   "Folder path (default: /).", default="/"),
        Arg("--sort", "Sort by field.", choices=("name", "size")),
        Arg("--json", "Output raw JSON.", type="bool"),
    ),
))


def run(ns) -> int:
    import json as _json
    from datetime import datetime, timezone
    from rich.console import Console
    from rich.table import Table
    from cli.session import api_get
    from cli.ui import spinner

    console = Console()
    err = Console(stderr=True)

    path = (ns.path or "/").strip("/")
    with spinner("Listing..."):
        resp = api_get("/api/v1/keys/", params={"path": path} if path else {})

    if resp.status_code != 200:
        body = resp.json() if resp.content else {}
        err.print(f"[red]drp:[/red] {body.get('error', resp.status_code)}")
        return 1

    data = resp.json()
    keys = data.get("keys", [])

    if ns.json:
        print(_json.dumps(data, indent=2, default=str))
        return 0

    if not keys:
        console.print("[dim](empty)[/dim]")
        return 0

    if ns.sort == "size":
        keys.sort(key=lambda k: k.get("filesize", 0), reverse=True)
    elif ns.sort == "name":
        keys.sort(key=lambda k: k.get("filename", ""))

    t = Table(box=None, show_header=True, header_style="bold dim", padding=(0, 2, 0, 0))
    t.add_column("KEY",      style="cyan",  no_wrap=True)
    t.add_column("FILENAME")
    t.add_column("SIZE",     justify="right", style="dim")
    t.add_column("EXPIRES",  style="dim")
    t.add_column("FLAGS",    style="yellow")

    for k in keys:
        flags = []
        if k.get("encrypted"): flags.append("enc")
        if k.get("burn"):      flags.append("burn")
        if k.get("burned"):    flags.append("burned")
        if k.get("publish"):   flags.append("pub")

        t.add_row(
            k.get("key", ""),
            k.get("filename", ""),
            _fmt_size(k.get("filesize", 0)),
            _fmt_expiry(k.get("expires_at")),
            " ".join(flags),
        )

    console.print(t)
    return 0


def _fmt_size(n: int) -> str:
    for unit in ("B", "KB", "MB", "GB"):
        if n < 1024:
            return f"{n:.0f} {unit}" if unit == "B" else f"{n:.1f} {unit}"
        n /= 1024
    return f"{n:.1f} TB"


def _fmt_expiry(iso: str | None) -> str:
    if not iso:
        return "—"
    try:
        dt = datetime.fromisoformat(iso).replace(tzinfo=timezone.utc)
        delta = dt - datetime.now(timezone.utc)
        days = delta.days
        if days < 0:    return "expired"
        if days == 0:   return f"{delta.seconds // 3600}h"
        return f"{days}d"
    except Exception:
        return iso[:10]
