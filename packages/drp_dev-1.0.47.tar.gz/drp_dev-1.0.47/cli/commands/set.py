"""set — Modify attributes of an existing key."""

from __future__ import annotations

from cli.commands import Arg, Command, register

register(Command(
    name="set",
    description="Modify attributes of an existing key.",
    args=(
        Arg("key",        "Key to modify.", required=True),
        Arg("--expires",  "New expiry: 7d, 24h, 30m.", type="duration"),
        Arg("--burn",     "Toggle burn-on-read.", type="bool"),
        Arg("--password", "Set or clear password.", type="passphrase"),
        Arg("--publish",  "Toggle public listing.", type="bool"),
        Arg("--tag",      "Replace tags — repeatable.", repeatable=True),
    ),
))


def run(ns) -> int:
    from rich.console import Console
    Console(stderr=True).print("[yellow]drp set:[/yellow] not yet implemented")
    return 1
