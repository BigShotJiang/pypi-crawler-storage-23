"""
Command registry — single source of truth for every CLI command.

Each command module calls register() with a Command spec. build_parser()
derives a fully configured argparse.ArgumentParser from those specs.
"""

from __future__ import annotations

import argparse
import importlib
import pkgutil
from dataclasses import dataclass
from typing import Any


# ── Spec dataclasses ──────────────────────────────────────────────────────────

@dataclass(frozen=True)
class Arg:
    """A positional argument or flag on a command.

    name:       positional name OR "--long/-s" style flag
    type:       str | bool | passphrase | duration | path
    repeatable: allow --tag a --tag b → list
    """
    name: str
    description: str
    required: bool = False
    default: Any = None
    type: str = "str"
    choices: tuple[str, ...] | None = None
    repeatable: bool = False


@dataclass(frozen=True)
class Command:
    """Canonical definition of a CLI command."""
    name: str
    description: str
    args: tuple[Arg, ...] = ()
    aliases: tuple[str, ...] = ()


# ── Registry ──────────────────────────────────────────────────────────────────

_COMMANDS: dict[str, Command] = {}


def register(cmd: Command) -> Command:
    _COMMANDS[cmd.name] = cmd
    for alias in cmd.aliases:
        _COMMANDS[alias] = cmd
    return cmd


def _ensure_loaded() -> None:
    if _COMMANDS:
        return
    for _finder, name, _ispkg in pkgutil.iter_modules(__path__):
        importlib.import_module(f"{__name__}.{name}")


def all_commands() -> dict[str, Command]:
    _ensure_loaded()
    return {n: c for n, c in _COMMANDS.items() if c.name == n}


def get_command(name: str) -> Command | None:
    _ensure_loaded()
    return _COMMANDS.get(name)


# ── argparse builder ──────────────────────────────────────────────────────────

def _flag_names(arg: Arg) -> list[str]:
    """Split "---long/-s" into ["--long", "-s"]."""
    return [n.strip() for n in arg.name.split("/")]


def _dest(parts: list[str]) -> str:
    """Canonical dest from the long flag: "--new-key" → "new_key"."""
    long = next((n for n in parts if n.startswith("--")), parts[0])
    return long.lstrip("-").replace("-", "_")


def _add_arg(sp: argparse.ArgumentParser, arg: Arg) -> None:
    parts = _flag_names(arg)
    is_flag = any(n.startswith("-") for n in parts)
    kwargs: dict[str, Any] = {"help": arg.description}

    if not is_flag:
        # Positional
        if not arg.required:
            kwargs["nargs"] = "?"
        if arg.default is not None:
            kwargs["default"] = arg.default
        if arg.choices:
            kwargs["choices"] = arg.choices
        sp.add_argument(parts[0], **kwargs)
        return

    # Flag — dest derived from long name
    kwargs["dest"] = _dest(parts)

    if arg.type == "bool":
        kwargs["action"] = "store_true"
    elif arg.repeatable:
        kwargs["action"] = "append"
        kwargs["metavar"] = _dest(parts).upper()
    else:
        if arg.choices:
            kwargs["choices"] = arg.choices
        if arg.type in ("passphrase", "duration", "path"):
            kwargs["metavar"] = arg.type.upper()
        if arg.default is not None:
            kwargs["default"] = arg.default
        if arg.required:
            kwargs["required"] = True

    sp.add_argument(*parts, **kwargs)


def build_parser() -> argparse.ArgumentParser:
    """Build argparse.ArgumentParser from the command registry."""
    _ensure_loaded()

    p = argparse.ArgumentParser(
        prog="drp",
        description="drp — fast file and text sharing.",
    )
    p.add_argument("--version", action="store_true", help="Print version and exit.")

    sub = p.add_subparsers(dest="command", metavar="<command>")

    for name, cmd in all_commands().items():
        sp = sub.add_parser(name, help=cmd.description, aliases=list(cmd.aliases))
        for arg in cmd.args:
            _add_arg(sp, arg)

    return p
