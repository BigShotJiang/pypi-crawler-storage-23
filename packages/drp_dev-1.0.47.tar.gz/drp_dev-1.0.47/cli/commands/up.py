"""up — Upload a file, directory, glob, or text."""

from __future__ import annotations

from cli.commands import Arg, Command, register

register(Command(
    name="up",
    description="Upload a file, directory, glob, or text.",
    args=(
        Arg("target",
            "File path, glob, '-' for stdin, or literal text with --text."),
        Arg("--key",      "Custom short key."),
        Arg("--name",     "Override filename (text uploads)."),
        Arg("--expires",  "Expiry: 7d, 24h, 30m.", type="duration"),
        Arg("--publish",  "List on /explore/ and your profile.", type="bool"),
        Arg("--burn",     "Delete after first download.", type="bool"),
        Arg("--password", "Require a password to access.", type="passphrase"),
        Arg("--tag",      "Tag — repeatable.", repeatable=True),
        Arg("--text",     "Treat target as literal text, not a file path.", type="bool"),
    ),
))


def run(ns) -> int:
    import glob as _glob
    import os
    import sys
    from rich.console import Console
    from cli import session
    from cli.session import EnsureGuestError, api_post
    from cli.ui import spinner, upload_file as ui_upload

    console = Console()
    err = Console(stderr=True)

    try:
        session.ensure_guest()
    except EnsureGuestError as e:
        err.print(f"[red]drp:[/red] {e}")
        return 1

    target = ns.target or ""
    is_stdin = (target == "-")
    is_text = ns.text or is_stdin

    if is_text:
        if is_stdin:
            try:
                content = sys.stdin.read()
            except KeyboardInterrupt:
                return 130
        else:
            if not target:
                err.print("[red]drp up:[/red] provide a target, or use --text 'content'")
                return 1
            content = target

        payload = {
            "text":     content,
            "folder":   "",
            "key":      ns.key or "",
            "name":     ns.name or "",
            "expires":  ns.expires or "",
            "burn":     ns.burn,
            "publish":  ns.publish,
            "password": ns.password or "",
            "tags":     ns.tag or [],
        }
        with spinner("Uploading..."):
            resp = api_post("/api/v1/keys/", json=payload)
        return _print_result(resp, "text", console, err)

    if not target:
        err.print("[red]drp up:[/red] no target specified")
        return 1

    paths = _glob.glob(target) or _glob.glob(os.path.join(os.getcwd(), target))
    if not paths:
        err.print(f"[red]drp up:[/red] not found: {target}")
        return 1

    rc = 0
    for path in sorted(paths):
        if os.path.isdir(path):
            for root, _dirs, filenames in os.walk(path):
                for fname in filenames:
                    rc |= _upload_file(ns, os.path.join(root, fname),
                                       api_post, ui_upload, console, err)
        else:
            rc |= _upload_file(ns, path, api_post, ui_upload, console, err)
    return rc


def _upload_file(ns, path, api_post, ui_upload, console, err) -> int:
    import os
    fname = os.path.basename(path)
    data = {
        "folder":   "",
        "key":      ns.key or "",
        "expires":  ns.expires or "",
        "burn":     "true" if ns.burn else "",
        "publish":  "true" if ns.publish else "",
        "password": ns.password or "",
        "tags":     ",".join(ns.tag or []),
    }
    resp = ui_upload(api_post, "/api/v1/keys/", path, filename=fname, extra_data=data)
    return _print_result(resp, fname, console, err)


def _print_result(resp, label, console, err) -> int:
    if resp.status_code in (200, 201):
        d = resp.json()
        console.print(
            f"[green]{d['url']}[/green]  "
            f"[dim]{d['filename']}, {_fmt_size(d.get('filesize', 0))}[/dim]"
        )
        return 0
    body = resp.json() if resp.content else {}
    err.print(f"[red]drp:[/red] {label} — {body.get('error', resp.status_code)}")
    return 1


def _fmt_size(n: int) -> str:
    for unit in ("B", "KB", "MB", "GB"):
        if n < 1024:
            return f"{n:.0f} {unit}" if unit == "B" else f"{n:.1f} {unit}"
        n /= 1024
    return f"{n:.1f} TB"
