"""rekey — Assign a new key to an existing file."""

from __future__ import annotations

from cli.commands import Arg, Command, register

register(Command(
    name="rekey",
    description="Assign a new key to an existing file.",
    args=(
        Arg("key",      "Current key.", required=True),
        Arg("--new-key", "Desired new key (default: server assigns random)."),
    ),
))


def run(ns) -> int:
    from rich.console import Console
    Console(stderr=True).print("[yellow]drp rekey:[/yellow] not yet implemented")
    return 1
