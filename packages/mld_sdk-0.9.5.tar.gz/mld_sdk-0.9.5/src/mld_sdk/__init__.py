"""
MLD Plugin SDK

SDK for building analysis plugins that integrate with the MLD platform.
"""

from mld_sdk.plugin import (
    AnalysisPlugin,
    HealthStatus,
    PluginHealth,
    LifecycleHookResult,
)
from mld_sdk.models import PluginMetadata, PluginCapabilities, PluginType
from mld_sdk.context import PlatformContext
from mld_sdk.export import auto_json_to_tree, auto_json_to_csv, auto_json_to_summary

# Exceptions
from mld_sdk.exceptions import (
    PluginException,
    ValidationException,
    PermissionException,
    ConfigurationException,
    RepositoryException,
    NotFoundException,
    ConflictException,
    PluginLifecycleException,
)

# Local database (optional dependency)
from mld_sdk.local_database import LocalDatabase, LocalDatabaseConfig

# Repository protocols and data models
from mld_sdk.repositories import (
    # Data models
    Experiment,
    DesignData,
    PluginExperimentData,  # backward compatibility alias for DesignData
    PluginAnalysisResult,
    User,
    UserPluginRole,
    # Repository protocols
    ExperimentRepository,
    PluginDataRepository,
    PluginRoleRepository,
    UserRepository,
    PlatformConfig,
)

try:
    from mld_sdk._version import __version__
except ImportError:
    __version__ = "0.0.0"

__all__ = [
    # Core plugin classes
    "AnalysisPlugin",
    "PluginMetadata",
    "PluginCapabilities",
    "PluginType",
    "PlatformContext",
    # Lifecycle types
    "HealthStatus",
    "PluginHealth",
    "LifecycleHookResult",
    # Exceptions
    "PluginException",
    "ValidationException",
    "PermissionException",
    "ConfigurationException",
    "RepositoryException",
    "NotFoundException",
    "ConflictException",
    "PluginLifecycleException",
    # Local database
    "LocalDatabase",
    "LocalDatabaseConfig",
    # Data models
    "Experiment",
    "DesignData",
    "PluginExperimentData",  # backward compatibility alias
    "PluginAnalysisResult",
    "User",
    "UserPluginRole",
    # Repository protocols
    "ExperimentRepository",
    "PluginDataRepository",
    "PluginRoleRepository",
    "UserRepository",
    "PlatformConfig",
    # Export utilities
    "auto_json_to_tree",
    "auto_json_to_csv",
    "auto_json_to_summary",
]
