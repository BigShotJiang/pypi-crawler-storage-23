# bofa

Do you know about bofa?

Run `uvx bofa` to find out.
