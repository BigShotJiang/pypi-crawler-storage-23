---
name: web
description: Skills for web searching, data retrieval, and online information gathering.
---
