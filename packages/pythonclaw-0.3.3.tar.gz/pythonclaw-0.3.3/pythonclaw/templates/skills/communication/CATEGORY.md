---
name: communication
description: Skills for sending emails, messages, and notifications.
---
