---
name: meta
description: Meta-skills that extend the agent's own capabilities at runtime.
---
