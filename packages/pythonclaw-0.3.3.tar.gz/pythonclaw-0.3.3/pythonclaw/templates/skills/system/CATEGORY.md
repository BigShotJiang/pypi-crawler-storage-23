---
name: system
description: Agent self-management — onboarding, identity, and configuration.
---
