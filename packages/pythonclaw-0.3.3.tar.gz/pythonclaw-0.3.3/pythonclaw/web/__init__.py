"""PythonClaw Web Dashboard — localhost UI for config, chat, and skill browsing."""
