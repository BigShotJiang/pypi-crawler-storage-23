"""Allow running PythonClaw as ``python -m pythonclaw``."""

from .main import main

if __name__ == "__main__":
    main()
