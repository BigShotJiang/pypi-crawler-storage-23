"""
Concert booking tool functions for agent use
These functions are exposed as tools to AI agents in the workflow
"""
from typing import Annotated, Any


def check_concert_availability(
    concert_name: Annotated[str, "Name of the concert to check availability for"],
    **state: Any
) -> str:
    """
    Check if a concert is available for booking with dates and pricing.

    Args:
        concert_name: Name of the concert to check

    Returns:
        String with concert availability details including dates and venue
    """
    # Mock concert database
    concerts = {
        "Coldplay": {
            "available": True,
            "venue": "DY Patil Stadium, Mumbai",
            "date": "2026-03-15",
            "seats_left": 5000,
            "genres": ["Rock", "Pop"]
        },
        "AR Rahman": {
            "available": True,
            "venue": "Jawaharlal Nehru Stadium, Delhi",
            "date": "2026-04-20",
            "seats_left": 3500,
            "genres": ["Classical", "Bollywood"]
        },
        "Ed Sheeran": {
            "available": True,
            "venue": "Phoenix Marketcity, Chennai",
            "date": "2026-05-10",
            "seats_left": 2000,
            "genres": ["Pop", "Folk"]
        },
        "Arijit Singh": {
            "available": True,
            "venue": "MMRDA Grounds, Mumbai",
            "date": "2026-06-05",
            "seats_left": 8000,
            "genres": ["Bollywood", "Romantic"]
        },
        "Imagine Dragons": {
            "available": False,
            "venue": "Bangalore Palace Grounds",
            "date": "2026-02-28",
            "seats_left": 0,
            "genres": ["Rock", "Alternative"]
        }
    }

    # Check if concert exists
    concert_name_normalized = concert_name.strip()

    # Try exact match first
    concert_info = concerts.get(concert_name_normalized)

    # Try case-insensitive match
    if not concert_info:
        for name, info in concerts.items():
            if name.lower() == concert_name_normalized.lower():
                concert_info = info
                concert_name_normalized = name
                break

    if not concert_info:
        # Concert not found
        available_concerts = ", ".join(concerts.keys())
        return f"Sorry, '{concert_name}' is not in our system. Available concerts: {available_concerts}"

    # Return availability information
    if concert_info["available"]:
        return (
            f"✓ {concert_name_normalized} is AVAILABLE!\n"
            f"Venue: {concert_info['venue']}\n"
            f"Date: {concert_info['date']}\n"
            f"Seats Available: {concert_info['seats_left']}\n"
            f"Genres: {', '.join(concert_info['genres'])}"
        )
    else:
        return (
            f"✗ {concert_name_normalized} is SOLD OUT\n"
            f"Venue: {concert_info['venue']}\n"
            f"Original Date: {concert_info['date']}\n"
            f"Check back later for additional dates!"
        )


def calculate_total_price(
    selected_seat: Annotated[str, "Seating section (VIP, Premium, or General)"],
    num_tickets: Annotated[int, "Number of tickets to purchase"],
    **state: Any

) -> str:
    """
    Calculate the total price for concert tickets with discounts.

    Args:
        selected_seat: Seating section (VIP, Premium, General)
        num_tickets: Number of tickets

    Returns:
        String with price breakdown and total
    """
    # Read prices from workflow state
    vip_price = state.get("vip_price", 0)
    premium_price = state.get("premium_price", 0)
    general_price = state.get("general_price", 0)

    # Normalize seat preference
    seat_preference = selected_seat.strip().title()

    # Map seat preference to price
    prices = {
        'VIP': vip_price,
        'Vip': vip_price,
        'Premium': premium_price,
        'General': general_price
    }

    price_per_ticket = prices.get(seat_preference, general_price)
    subtotal = price_per_ticket * num_tickets

    # Apply discounts based on quantity
    discount = 0
    discount_percent = 0

    if num_tickets >= 5:
        discount_percent = 10
        discount = subtotal * 0.10
    elif num_tickets >= 3:
        discount_percent = 5
        discount = subtotal * 0.05

    total = subtotal - discount

    # Build response
    response = "💰 Price Breakdown:\n"
    response += f"   Seat Type: {seat_preference}\n"
    response += f"   Price per ticket: ₹{price_per_ticket:,.0f}\n"
    response += f"   Quantity: {num_tickets}\n"
    response += f"   Subtotal: ₹{subtotal:,.0f}\n"

    if discount > 0:
        response += f"   Discount ({discount_percent}%): -₹{discount:,.0f}\n"
        response += "   ──────────────────\n"
        response += f"   TOTAL: ₹{total:,.0f} ✨"
    else:
        response += "   ──────────────────\n"
        response += f"   TOTAL: ₹{total:,.0f}"

    # Add discount tip if applicable
    if num_tickets < 3:
        response += "\n\n💡 Tip: Book 3+ tickets for 5% off, or 5+ for 10% off!"

    return response


def search_venue_info(
    venue_name: Annotated[str, "Name of the venue to search for"],
    **state: Any
) -> str:
    """
    Get detailed information about a concert venue.

    Args:
        venue_name: Name or partial name of the venue

    Returns:
        String with venue details including capacity, location, and facilities
    """
    # Mock venue database
    venues = {
        "DY Patil Stadium": {
            "full_name": "DY Patil Stadium",
            "location": "Navi Mumbai, Maharashtra",
            "capacity": 55000,
            "facilities": ["Parking", "Food Courts", "VIP Lounges", "Wheelchair Access"],
            "transport": "Metro: Nerul Station (3km), Bus routes available",
            "website": "www.dypstadium.com"
        },
        "Jawaharlal Nehru Stadium": {
            "full_name": "Jawaharlal Nehru Stadium",
            "location": "Delhi",
            "capacity": 60000,
            "facilities": ["Parking", "Metro Connectivity", "Multiple Entry Gates", "Food Stalls"],
            "transport": "Metro: Jawaharlal Nehru Stadium (direct), Well connected by roads",
            "website": "www.jnstadium.in"
        },
        "Phoenix Marketcity": {
            "full_name": "Phoenix Marketcity Arena",
            "location": "Chennai, Tamil Nadu",
            "capacity": 15000,
            "facilities": ["Mall Complex", "Restaurants", "Parking", "AC Indoor Arena"],
            "transport": "Bus: Multiple routes, Taxi/App cabs recommended",
            "website": "www.phoenixmarketcity.com"
        },
        "MMRDA Grounds": {
            "full_name": "MMRDA Grounds (Bandra-Kurla Complex)",
            "location": "Mumbai, Maharashtra",
            "capacity": 45000,
            "facilities": ["Open Air Venue", "Multiple Stages", "Food Trucks", "Parking"],
            "transport": "Metro: BKC Station (walkable), Well connected by roads",
            "website": "www.mmrdagrounds.com"
        },
        "Bangalore Palace Grounds": {
            "full_name": "Bangalore Palace Grounds",
            "location": "Bangalore, Karnataka",
            "capacity": 50000,
            "facilities": ["Historic Venue", "Spacious Grounds", "Parking", "Food Courts"],
            "transport": "Metro: Sampige Road (2km), Easily accessible by cab",
            "website": "www.bangalorepalace.gov.in"
        }
    }

    # Normalize search query
    venue_name_normalized = venue_name.strip()

    # Try exact match
    venue_info = venues.get(venue_name_normalized)

    # Try case-insensitive partial match
    if not venue_info:
        for name, info in venues.items():
            if venue_name_normalized.lower() in name.lower():
                venue_info = info
                break

    if not venue_info:
        # Venue not found
        available_venues = ", ".join(venues.keys())
        return f"Venue '{venue_name}' not found. Available venues: {available_venues}"

    # Build detailed response
    response = f"📍 {venue_info['full_name']}\n\n"
    response += f"Location: {venue_info['location']}\n"
    response += f"Capacity: {venue_info['capacity']:,} people\n\n"
    response += "Facilities:\n"
    for facility in venue_info['facilities']:
        response += f"  • {facility}\n"
    response += f"\nTransport: {venue_info['transport']}\n"
    response += f"Website: {venue_info['website']}"

    return response
