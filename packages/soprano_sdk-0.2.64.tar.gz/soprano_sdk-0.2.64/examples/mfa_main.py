#!/usr/bin/env python3
"""
MFA Workflow Test Runner

Tests the new MFA step with resend functionality.

Usage:
    python mfa_main.py

Features tested:
    ✓ Explicit MFA step (action: call_mfa)
    ✓ Resend OTP functionality
    ✓ Resend doesn't count as attempt
    ✓ Max attempts enforcement
    ✓ Cancellation support
"""

import os
import sys
import uuid
from langgraph.checkpoint.memory import MemorySaver

# Add current directory to path for imports
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from soprano_sdk.tools import WorkflowTool
from soprano_sdk.core.constants import MFAConfig, InterruptType


def create_mock_mfa_config() -> MFAConfig:
    """
    Create MFA configuration.

    For testing, you'll need to set up mock MFA endpoints or use real ones.
    Set these environment variables:
    - MFA_BASE_URL (default: http://localhost:3000)
    - GENERATE_TOKEN_BASE_URL
    - RESEND_TOKEN_BASE_URL
    - VALIDATE_TOKEN_BASE_URL
    - AUTHORIZE_TOKEN_BASE_URL
    """
    base_url = os.getenv("MFA_BASE_URL", "http://localhost:3000")

    return MFAConfig(
        generate_token_base_url=os.getenv("GENERATE_TOKEN_BASE_URL", base_url),
        generate_token_path=os.getenv("GENERATE_TOKEN_PATH", "/mfa/generate"),
        resend_token_base_url=os.getenv("RESEND_TOKEN_BASE_URL", base_url),
        resend_token_path=os.getenv("RESEND_TOKEN_PATH", "/mfa/resend"),
        validate_token_base_url=os.getenv("VALIDATE_TOKEN_BASE_URL", base_url),
        validate_token_path=os.getenv("VALIDATE_TOKEN_PATH", "/mfa/validate"),
        authorize_token_base_url=os.getenv("AUTHORIZE_TOKEN_BASE_URL", base_url),
        authorize_token_path=os.getenv("AUTHORIZE_TOKEN_PATH", "/mfa/authorize"),
        api_timeout=30,
        mfa_cancelled_message="Authentication cancelled. Your transaction was not processed."
    )


def get_model_config():
    """Get model configuration from environment"""
    provider = os.getenv("MODEL_PROVIDER", "openai")
    model_name = os.getenv("MODEL_NAME", "gpt-4o-mini")

    if provider == "ollama":
        return {
            "model_name": model_name,
            "base_url": os.getenv("OLLAMA_BASE_URL", "http://localhost:11434/v1"),
            "provider": "ollama",
            "api_key": "dummy"
        }
    else:
        api_key = os.getenv("OPENAI_API_KEY")
        if not api_key:
            print("\n⚠️  WARNING: OPENAI_API_KEY not set!")
            print("Please set your OpenAI API key:")
            print("  export OPENAI_API_KEY='your-api-key-here'")
            print("\nOr use Ollama (requires Ollama running locally):")
            print("  export MODEL_PROVIDER=ollama")
            print("  export MODEL_NAME=llama3")
            sys.exit(1)
        config = {
            "model_name": model_name,
            "provider": "openai",
            "api_key": api_key
        }
        if base_url := os.getenv("OPENAI_BASE_URL"):
            config["base_url"] = base_url
        return config


def print_welcome_banner():
    """Print welcome banner with instructions"""
    print("\n" + "=" * 80)
    print("🔐 MFA WORKFLOW TEST - Payment with OTP Authentication")
    print("=" * 80)
    print("\n📋 This test demonstrates:")
    print("  ✓ Explicit MFA step (action: mfa)")
    print("  ✓ Resend OTP functionality (doesn't count as attempt)")
    print("  ✓ Max attempts enforcement (3 OTP attempts)")
    print("  ✓ Cancellation support")
    print("\n📝 Test Instructions:")
    print("  1. Provide Customer ID (format: CUSTXXXXXX, e.g., CUST123456)")
    print("  2. Provide payment amount (₹100 - ₹50,000)")
    print("  3. When prompted for OTP:")
    print("     • Type 'resend' to get a new OTP")
    print("     • Type 'cancel' to abort authentication")
    print("     • Enter your OTP code to proceed")
    print("\n💡 Testing Resend:")
    print("  • Try typing 'resend' multiple times")
    print("  • Notice it doesn't count as validation attempt")
    print("  • You still get 3 attempts to enter correct OTP")
    print("\n⚠️  Prerequisites:")
    print("  • MFA endpoints must be running")
    print("  • Set MFA_BASE_URL environment variable")
    print("=" * 80 + "\n")


def check_mfa_endpoints():
    """Check if MFA endpoints are configured"""
    mfa_base_url = os.getenv("MFA_BASE_URL", "http://localhost:3000")
    print("🔗 MFA Endpoints Configuration:")
    print(f"  Base URL: {mfa_base_url}")
    print(f"  • Generate: {mfa_base_url}/mfa/generate")
    print(f"  • Resend:   {mfa_base_url}/mfa/resend")
    print(f"  • Validate: {mfa_base_url}/mfa/validate")
    print(f"  • Authorize: {mfa_base_url}/mfa/authorize")
    print()

    response = input("Are MFA endpoints running at this URL? (y/n): ").strip().lower()
    if response != 'y':
        print("\n❌ MFA endpoints not available!")
        print("\n📚 Quick Setup Guide:")
        print("\n1. Create a mock MFA server (Flask/FastAPI):")
        print("""
from flask import Flask, request, jsonify
app = Flask(__name__)

@app.route('/mfa/generate', methods=['POST'])
def generate():
    return jsonify({
        'error': 'MFA_REQUIRED',
        'additionalData': {
            'challengeType': 'OTP',
            'otpSentTo': ['email', 'sms']
        }
    }), 400

@app.route('/mfa/validate', methods=['POST'])
def validate():
    return jsonify({'token': 'mock-token-123'})

@app.route('/mfa/authorize', methods=['POST'])
def authorize():
    return '', 204

if __name__ == '__main__':
    app.run(port=8000)
        """)
        print("\n2. Run the server:")
        print("   python mock_mfa_server.py")
        print("\n3. Set environment variable:")
        print("   export MFA_BASE_URL=http://localhost:8000")
        print("\n4. Run this test again:")
        print("   python mfa_main.py")
        return False
    return True


def run_mfa_workflow_test():
    """Run the MFA workflow test"""
    print_welcome_banner()

    if not check_mfa_endpoints():
        return

    # Check workflow file exists
    yaml_path = "mfa_workflow.yaml"
    if not os.path.exists(yaml_path):
        print(f"\n❌ Error: Workflow file not found: {yaml_path}")
        print("Please ensure mfa_workflow.yaml is in the examples/ directory")
        return

    print("\n🔧 Initializing workflow...")

    try:
        # Create checkpointer
        checkpointer = MemorySaver()
        print("✓ Checkpointer initialized")

        # Create MFA config
        mfa_config = create_mock_mfa_config()
        print("✓ MFA config created")

        # Get model config
        model_config = get_model_config()
        print(f"✓ Model configured: {model_config['model_name']} ({model_config['provider']})")

        # Create workflow tool
        workflow_tool = WorkflowTool(
            yaml_path=yaml_path,
            name="PaymentMFAWorkflow",
            description="Payment workflow with MFA authentication",
            checkpointer=checkpointer,
            config={"model_config": model_config},
            mfa_config=mfa_config
        )

        print(f"✓ Workflow loaded: {workflow_tool.engine.workflow_name}")
        print(f"✓ Total steps: {len(workflow_tool.engine.steps)}")

        # Count MFA steps
        mfa_steps = [s for s in workflow_tool.engine.steps if s.get('action') == 'mfa']
        if mfa_steps:
            print(f"✓ MFA steps found: {len(mfa_steps)}")
            for step in mfa_steps:
                print(f"  - {step['id']}: {step.get('description', 'No description')}")

        print()

        # Generate thread ID
        thread_id = f"mfa_test_{uuid.uuid4().hex[:8]}"
        print(f"🆔 Thread ID: {thread_id}")
        print("\n" + "=" * 80)
        print("Starting workflow execution...")
        print("=" * 80 + "\n")

        # Start workflow
        result = workflow_tool.execute(thread_id=thread_id)

        # Interactive loop
        interaction_count = 0
        while InterruptType.USER_INPUT in result:
            interaction_count += 1

            # Parse interrupt
            parts = result.split("|")
            if len(parts) >= 4:
                thread_id = parts[1]
                prompt = "|".join(parts[3:])

                print(f"\n{'─' * 80}")
                print(f"Interaction #{interaction_count}")
                print(f"{'─' * 80}")
                print(f"🤖 Bot: {prompt}")

                try:
                    user_input = input("\n👤 You: ").strip()

                    if user_input.lower() in ['quit', 'exit']:
                        print("\n👋 Exiting workflow...")
                        break

                    if not user_input:
                        print("⚠️  Empty input - please provide a response")
                        continue

                    # Show what user typed (helpful for debugging)
                    print(f"✓ Input received: '{user_input}'")

                    # Resume workflow
                    print("\n⏳ Processing...")
                    result = workflow_tool.execute(
                        thread_id=thread_id,
                        user_message=user_input
                    )

                except KeyboardInterrupt:
                    print("\n\n⚠️  Interrupted by user (Ctrl+C)")
                    break
                except EOFError:
                    print("\n\n⚠️  End of input (EOF)")
                    break
            else:
                print("\n❌ Invalid interrupt format")
                print(f"Result: {result}")
                break

        # Show final result
        if InterruptType.USER_INPUT not in result:
            print("\n" + "=" * 80)
            print("✅ WORKFLOW COMPLETED")
            print("=" * 80)
            print(f"\n{result}\n")
            print("=" * 80)
            print(f"Total interactions: {interaction_count}")
            print("=" * 80 + "\n")

    except FileNotFoundError as e:
        print(f"\n❌ File not found: {e}")
        print("Please ensure all required files are in place")
    except KeyError as e:
        print(f"\n❌ Configuration error: Missing key {e}")
        print("Please check your workflow YAML and environment variables")
    except Exception as e:
        print(f"\n❌ Error: {e}")
        print("\n📋 Stack trace:")
        import traceback
        traceback.print_exc()
        print("\n💡 Troubleshooting:")
        print("  1. Check MFA endpoints are running")
        print("  2. Verify OPENAI_API_KEY is set")
        print("  3. Ensure mfa_workflow.yaml exists in examples/")
        print("  4. Check all imports are available")


def main():
    """Main entry point"""
    try:
        run_mfa_workflow_test()
    except KeyboardInterrupt:
        print("\n\n⚠️  Test interrupted by user")
        sys.exit(0)
    except Exception as e:
        print(f"\n❌ Fatal error: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()
