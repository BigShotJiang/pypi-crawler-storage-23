#!/usr/bin/env python3
"""
Test the failure_message functionality in WorkflowEngine
"""
import os
import sys
import tempfile
import yaml
import pytest

# Add parent directory to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from soprano_sdk import load_workflow
from soprano_sdk.core.engine import WorkflowEngine


class TestEngineFailureMessage:
    """Test suite for WorkflowEngine failure_message attribute"""

    @pytest.fixture
    def minimal_workflow_config(self):
        """Minimal workflow configuration without failure_message"""
        return {
            "name": "Test Workflow",
            "description": "Test workflow for failure_message",
            "version": "1.0.0",
            "data": [
                {"name": "test_field", "type": "text", "description": "Test field"}
            ],
            "steps": [
                {
                    "id": "step1",
                    "action": "call_function",
                    "function": "test.function",
                    "output": "test_field",
                    "next": "success"
                }
            ],
            "outcomes": [
                {"id": "success", "type": "success", "message": "Done"}
            ]
        }

    @pytest.fixture
    def workflow_with_failure_message(self, minimal_workflow_config):
        """Workflow configuration with custom failure_message"""
        config = minimal_workflow_config.copy()
        config["failure_message"] = "Custom error: Please contact support"
        return config

    def test_engine_loads_failure_message_from_config(self, workflow_with_failure_message):
        """Test that WorkflowEngine correctly loads failure_message from YAML config"""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
            yaml.dump(workflow_with_failure_message, f)
            yaml_path = f.name

        try:
            engine = WorkflowEngine(yaml_path, configs={})

            assert hasattr(engine, 'failure_message'), "Engine should have failure_message attribute"
            assert engine.failure_message == "Custom error: Please contact support"

        finally:
            os.unlink(yaml_path)

    def test_engine_defaults_to_none_when_no_failure_message(self, minimal_workflow_config):
        """Test that failure_message defaults to None when not provided in config"""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
            yaml.dump(minimal_workflow_config, f)
            yaml_path = f.name

        try:
            engine = WorkflowEngine(yaml_path, configs={})

            assert hasattr(engine, 'failure_message'), "Engine should have failure_message attribute"
            assert engine.failure_message is None, "failure_message should default to None"

        finally:
            os.unlink(yaml_path)

    def test_engine_handles_empty_string_failure_message(self, minimal_workflow_config):
        """Test that engine correctly handles empty string as failure_message"""
        config = minimal_workflow_config.copy()
        config["failure_message"] = ""

        with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
            yaml.dump(config, f)
            yaml_path = f.name

        try:
            engine = WorkflowEngine(yaml_path, configs={})

            assert engine.failure_message == "", "Empty string should be preserved"

        finally:
            os.unlink(yaml_path)

    def test_engine_handles_multiline_failure_message(self, minimal_workflow_config):
        """Test that engine correctly handles multiline failure_message"""
        multiline_message = """An error occurred while processing your request.
Please try again later or contact support at support@example.com.
Reference code: SYS-001"""

        config = minimal_workflow_config.copy()
        config["failure_message"] = multiline_message

        with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
            yaml.dump(config, f)
            yaml_path = f.name

        try:
            engine = WorkflowEngine(yaml_path, configs={})

            assert engine.failure_message == multiline_message
            assert "\n" in engine.failure_message, "Multiline message should preserve newlines"

        finally:
            os.unlink(yaml_path)

    def test_load_workflow_passes_failure_message_to_engine(self, workflow_with_failure_message):
        """Test that load_workflow function creates engine with failure_message"""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
            yaml.dump(workflow_with_failure_message, f)
            yaml_path = f.name

        try:
            graph, engine = load_workflow(yaml_path)

            assert hasattr(engine, 'failure_message')
            assert engine.failure_message == "Custom error: Please contact support"

        finally:
            os.unlink(yaml_path)

    def test_engine_failure_message_with_special_characters(self, minimal_workflow_config):
        """Test that failure_message correctly handles special characters"""
        special_message = "Error: Contact support@example.com or call 1-800-HELP (24/7)"

        config = minimal_workflow_config.copy()
        config["failure_message"] = special_message

        with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
            yaml.dump(config, f)
            yaml_path = f.name

        try:
            engine = WorkflowEngine(yaml_path, configs={})

            assert engine.failure_message == special_message

        finally:
            os.unlink(yaml_path)

    def test_engine_workflow_info_includes_all_metadata(self, workflow_with_failure_message):
        """Test that get_workflow_info still works correctly with failure_message present"""
        with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
            yaml.dump(workflow_with_failure_message, f)
            yaml_path = f.name

        try:
            engine = WorkflowEngine(yaml_path, configs={})
            info = engine.get_workflow_info()

            # Verify workflow info structure is intact
            assert 'name' in info
            assert 'description' in info
            assert 'version' in info
            assert 'steps' in info
            assert 'outcomes' in info
            assert 'data_fields' in info

            # Verify workflow can still be built and used
            assert engine.failure_message is not None

        finally:
            os.unlink(yaml_path)


class TestEngineIntegrationWithFailureMessage:
    """Integration tests for failure_message in real workflow scenarios"""

    def test_engine_with_mfa_and_failure_message(self):
        """Test that failure_message works alongside MFA configuration"""
        mfa_config = {
            "name": "MFA Test Workflow",
            "description": "Test workflow with MFA and failure_message",
            "version": "1.0.0",
            "failure_message": "Authentication failed. Please try again.",
            "data": [
                {"name": "user_id", "type": "text", "description": "User ID"}
            ],
            "steps": [
                {
                    "id": "collect_user",
                    "action": "call_function",
                    "function": "test.function",
                    "output": "user_id",
                    "next": "success"
                }
            ],
            "outcomes": [
                {"id": "success", "type": "success", "message": "Done"}
            ]
        }

        with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as mfa_file:
            yaml.dump(mfa_config, mfa_file)
            mfa_yaml_path = mfa_file.name

        try:
            mfa_engine = WorkflowEngine(mfa_yaml_path, configs={})

            assert mfa_engine.failure_message == "Authentication failed. Please try again."
            # Verify engine can still build graph
            mfa_graph = mfa_engine.build_graph()
            assert mfa_graph is not None

        finally:
            os.unlink(mfa_yaml_path)


def test_engine_initialization_preserves_failure_message():
    """Test that failure_message is preserved through engine initialization"""
    init_config = {
        "name": "Init Test",
        "description": "Test",
        "version": "1.0.0",
        "failure_message": "System error occurred",
        "data": [
            {"name": "field1", "type": "text", "description": "Field 1"}
        ],
        "steps": [
            {
                "id": "step1",
                "action": "call_function",
                "function": "test.func",
                "output": "field1",
                "next": "done"
            }
        ],
        "outcomes": [
            {"id": "done", "type": "success", "message": "Complete"}
        ]
    }

    with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as init_file:
        yaml.dump(init_config, init_file)
        init_yaml_path = init_file.name

    try:
        # Initialize engine
        engine1 = WorkflowEngine(init_yaml_path, configs={})
        original_message = engine1.failure_message

        # Build graph to verify it doesn't affect failure_message
        _ = engine1.build_graph()

        # Create new engine instance
        engine2 = WorkflowEngine(init_yaml_path, configs={})

        # Both should have the same failure_message
        assert engine1.failure_message == original_message
        assert engine2.failure_message == original_message
        assert engine1.failure_message == engine2.failure_message

    finally:
        os.unlink(init_yaml_path)


if __name__ == "__main__":
    # Run with pytest if available, otherwise run basic tests
    try:
        import pytest
        pytest.main([__file__, "-v"])
    except ImportError:
        print("pytest not available, running basic tests...")

        # Run basic tests
        print("\nTest 1: Engine loads failure_message from config")
        test1_config = {
            "name": "Test",
            "description": "Test",
            "version": "1.0.0",
            "failure_message": "Custom error message",
            "data": [{"name": "field", "type": "text", "description": "Field"}],
            "steps": [{
                "id": "step1",
                "action": "call_function",
                "function": "test.func",
                "output": "field",
                "next": "done"
            }],
            "outcomes": [{"id": "done", "type": "success", "message": "Done"}]
        }

        with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as test1_file:
            yaml.dump(test1_config, test1_file)
            test1_yaml_path = test1_file.name

        try:
            test1_engine = WorkflowEngine(test1_yaml_path, configs={})
            assert test1_engine.failure_message == "Custom error message"
            print("✅ PASSED")
        finally:
            os.unlink(test1_yaml_path)

        print("\nTest 2: Engine defaults to None when no failure_message")
        test2_config = {
            "name": "Test",
            "description": "Test",
            "version": "1.0.0",
            "data": [{"name": "field", "type": "text", "description": "Field"}],
            "steps": [{
                "id": "step1",
                "action": "call_function",
                "function": "test.func",
                "output": "field",
                "next": "done"
            }],
            "outcomes": [{"id": "done", "type": "success", "message": "Done"}]
        }

        with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as test2_file:
            yaml.dump(test2_config, test2_file)
            test2_yaml_path = test2_file.name

        try:
            test2_engine = WorkflowEngine(test2_yaml_path, configs={})
            assert test2_engine.failure_message is None
            print("✅ PASSED")
        finally:
            os.unlink(test2_yaml_path)

        print("\n🎉 All basic tests passed!")