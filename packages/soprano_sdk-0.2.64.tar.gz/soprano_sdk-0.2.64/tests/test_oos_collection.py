"""Out-of-scope (OOS) detection integration tests for collect_input_with_agent node.

Tests OOS detection for both PM and SO modes across all key scenarios:
  - Basic OOS detection (OOS interrupt after T1 prompt on T2)
  - In-scope responses captured normally (OOS detection doesn't break normal capture)
  - OOS on initial run (T1 before any user interaction)
  - OOS recovery (4-turn: T1→prompt, T2→OOS, T3→re-prompt, T4→capture)
  - Regression: whitespace-prefixed OOS text (leading \\n or spaces)

PM uses pm_out_of_scope.yaml  (field: status,      detect_out_of_scope: true)
SO uses so_out_of_scope.yaml  (field: choice_data,  detect_out_of_scope: true)

Checkpoint caveat for all OOS tests:
  When interrupt() is raised a second time (the OOS interrupt) inside a node that
  already resumed from a first interrupt, LangGraph does NOT persist the in-node
  state mutations that occurred after the first resume.  Concretely,
  `state['_out_of_scope_reason']` is set in-memory inside _handle_out_of_scope,
  but the second NodeInterrupt is raised before the node returns, so that mutation
  is NOT written to the checkpoint. The OOS reason travels to the caller via the
  interrupt VALUE (in the result string), not via the checkpointed state.

Coverage gaps:
  - OOS + validator combination: OOS with a validator configured not tested
  - OOS during multi-field collection: not tested
  - OOS interrupting partial data accumulation: not tested
"""

import uuid

import respx

from soprano_sdk.core.constants import InterruptType
from tests.helpers import (
    FAKE_LLM_COMPLETIONS,
    make_tool,
    snap,
    llm_text_response,
    llm_structured_response,
)

PM_OOS_CONV_KEY = "status_conversation"
PM_OOS_COLLECTOR_NODES = {"collect_status": "Collect status"}
SO_OOS_CONV_KEY = "choice_data_conversation"
SO_OOS_COLLECTOR_NODES = {"collect_choice": "Collect user choice"}


# ── PM Out-of-scope ───────────────────────────────────────────────────────────


@respx.mock
def test_oos_pm_1_out_of_scope_returns_interrupt():
    """PM + detect_out_of_scope=true: agent returns 'OUT_OF_SCOPE: pizza delivery'.

    Turn 1: normal prompt.
    Turn 2: user sends completely unrelated message; agent returns OOS marker.
      → WorkflowTool returns __OUT_OF_SCOPE_INTERRUPT__ string with the reason.
      → _status still 'collecting' (workflow not completed).

    Checkpoint caveat: _out_of_scope_reason is set in-memory inside
    _handle_out_of_scope but the second NodeInterrupt is raised before the node
    returns, so that mutation is NOT written to the checkpoint.
    The OOS reason travels to the caller via the interrupt value, not the state.
    """
    responses = iter([
        llm_text_response("What is your status?"),
        llm_text_response("OUT_OF_SCOPE: user wants pizza delivery"),
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("pm_out_of_scope.yaml")
    tid = str(uuid.uuid4())

    # ── turn 1: normal prompt ──
    result1 = tool.execute(thread_id=tid, initial_context={})
    assert "What is your status?" in str(result1)
    assert InterruptType.USER_INPUT in str(result1)

    # ── turn 2: out-of-scope message from user ──
    result2 = tool.execute(thread_id=tid, user_message="I want pizza", initial_context={})

    assert InterruptType.OUT_OF_SCOPE in str(result2)
    assert "pizza" in str(result2)   # reason surfaced via interrupt value, not state
    assert "Status A set" not in str(result2)
    assert "Status B set" not in str(result2)

    s2 = snap(tool, tid)

    # _out_of_scope_reason NOT in checkpoint (in-node mutation not persisted for 2nd interrupt)
    assert s2.get("_out_of_scope_reason") is None
    assert s2["_status"] == "collect_status_collecting"
    assert s2.get("status") is None
    # _pending_prompt still holds the Turn-1 prompt (state from last successful node return)
    assert s2["_pending_prompt"] is not None
    assert "What is your status?" in s2["_pending_prompt"]["text"]
    assert s2["_collector_nodes"] == {}
    assert s2["_node_execution_order"] == []
    # Conversation reflects only the Turn-1 checkpoint (1 assistant message)
    assert len(s2["_conversations"][PM_OOS_CONV_KEY]) == 1
    assert s2["_conversations"][PM_OOS_CONV_KEY][0]["role"] == "assistant"
    assert s2["error"] is None
    assert respx.calls.call_count == 2


@respx.mock
def test_oos_pm_2_in_scope_captures_normally():
    """PM + detect_out_of_scope=true: in-scope response captures normally.

    Verifies that OOS detection does NOT interfere with normal PM capture flow.
    Agent responds with STATUS_A: active → outcome_a.
    """
    responses = iter([
        llm_text_response("What is your status?"),
        llm_text_response("STATUS_A: active"),
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("pm_out_of_scope.yaml")
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    result2 = tool.execute(thread_id=tid, user_message="active", initial_context={})
    s2 = snap(tool, tid)

    assert "Status A set" in str(result2)
    assert InterruptType.OUT_OF_SCOPE not in str(result2)
    assert s2["status"] == "active"
    assert s2["_status"] == "collect_status_outcome_a"
    assert s2["_outcome_id"] == "outcome_a"
    assert s2.get("_out_of_scope_reason") is None
    assert s2["_collector_nodes"] == PM_OOS_COLLECTOR_NODES
    assert respx.calls.call_count == 2


@respx.mock
def test_oos_pm_3_out_of_scope_on_initial_run():
    """PM: agent returns OUT_OF_SCOPE: on initial run of step → OOS interrupt.

    Verifies that OOS is correctly detected even on the very first LLM call (T1),
    before any user interaction. The OUT_OF_SCOPE: text must NOT be shown as a
    user prompt.

    After fix: _handle_special_responses detects OUT_OF_SCOPE: prefix on T1 and
    calls _handle_out_of_scope → OOS interrupt returned from execute().
    """
    respx.post(FAKE_LLM_COMPLETIONS).mock(
        return_value=llm_text_response("OUT_OF_SCOPE: user asked about weather forecast")
    )

    tool = make_tool("pm_out_of_scope.yaml")
    tid = str(uuid.uuid4())

    result1 = tool.execute(thread_id=tid, initial_context={})

    assert InterruptType.OUT_OF_SCOPE in str(result1)
    assert "weather" in str(result1)
    assert "Status A set" not in str(result1)
    assert "Status B set" not in str(result1)
    # Not expected: OOS text displayed as user prompt
    assert InterruptType.USER_INPUT not in str(result1)
    assert respx.calls.call_count == 1


@respx.mock
def test_oos_pm_3_recovery_after_oos_captures_normally():
    """PM OOS: after an OOS interrupt, user can recover with two more turns.

    Turn 1: LLM generates prompt.
    Turn 2: user goes OOS → OOS interrupt returned.
    Turn 3: user sends a valid message → OOS interrupt resumes → framework fires
            continuation prompt interrupt (re-prompts "What is your status?"),
            NO LLM call. result3 = USER_INPUT.
    Turn 4: user sends valid answer → LLM captures STATUS_A → outcome_a.

    This is a 4-turn flow because LangGraph resumes from the OOS interrupt on T3
    (a second interrupt inside the same node run), then the framework re-fires
    the pending_prompt as a continuation interrupt before T4 can capture.

    3 total LLM calls (T1, T2, T4). T3 uses 0 LLM calls.
    """
    responses = iter([
        llm_text_response("What is your status?"),            # T1: prompt
        llm_text_response("OUT_OF_SCOPE: user wants pizza"),  # T2: OOS
        llm_text_response("STATUS_A: active"),                # T4: recovery
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("pm_out_of_scope.yaml")
    tid = str(uuid.uuid4())

    result1 = tool.execute(thread_id=tid, initial_context={})
    assert InterruptType.USER_INPUT in str(result1)

    result2 = tool.execute(thread_id=tid, user_message="I want pizza", initial_context={})
    assert InterruptType.OUT_OF_SCOPE in str(result2)
    assert "pizza" in str(result2)

    # T3: resumes OOS interrupt → continuation prompt re-fires (no LLM call)
    result3 = tool.execute(thread_id=tid, user_message="ok never mind", initial_context={})
    assert InterruptType.USER_INPUT in str(result3)
    assert "What is your status?" in str(result3)
    assert "Status A set" not in str(result3)
    assert respx.calls.call_count == 2   # T1+T2 only; no T3 LLM call

    # T4: valid answer → LLM captures STATUS_A → outcome_a
    result4 = tool.execute(thread_id=tid, user_message="STATUS_A: active", initial_context={})
    s4 = snap(tool, tid)

    assert "Status A set" in str(result4)
    assert InterruptType.OUT_OF_SCOPE not in str(result4)
    assert s4["status"] == "active"
    assert s4["_outcome_id"] == "outcome_a"
    assert s4["_status"] == "collect_status_outcome_a"
    assert s4["error"] is None
    assert respx.calls.call_count == 3


@respx.mock
def test_oos_pm_4_leading_newline_still_detected():
    """Regression: LLM response with leading newline must still trigger OOS interrupt.

    Before fix: `agent_response.startswith("OUT_OF_SCOPE:")` failed on
    "\\nOUT_OF_SCOPE: ..." so the raw text was returned as a USER_INPUT prompt
    instead of an OOS interrupt.
    After fix: `agent_response.strip().startswith(...)` detects it correctly.
    """
    responses = iter([
        llm_text_response("What is your status?"),                # T1
        llm_text_response("\nOUT_OF_SCOPE: user wants pizza"),    # T2 — leading newline
        llm_text_response("STATUS_A: active"),                    # T4
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("pm_out_of_scope.yaml")
    tid = str(uuid.uuid4())

    result1 = tool.execute(thread_id=tid, initial_context={})
    assert InterruptType.USER_INPUT in str(result1)

    result2 = tool.execute(thread_id=tid, user_message="I want pizza", initial_context={})
    # Must be an OOS interrupt, NOT a USER_INPUT with raw "OUT_OF_SCOPE:" text
    assert InterruptType.OUT_OF_SCOPE in str(result2), (
        f"Expected OOS interrupt but got: {result2!r}"
    )
    assert "pizza" in str(result2)
    assert InterruptType.USER_INPUT not in str(result2)
    assert respx.calls.call_count == 2

    # T3: resume from OOS → continuation re-prompt (0 LLM calls)
    result3 = tool.execute(thread_id=tid, user_message="ok never mind", initial_context={})
    assert InterruptType.USER_INPUT in str(result3)
    assert respx.calls.call_count == 2   # no extra LLM call

    # T4: capture
    result4 = tool.execute(thread_id=tid, user_message="STATUS_A: active", initial_context={})
    s4 = snap(tool, tid)
    assert "Status A set" in str(result4)
    assert s4["status"] == "active"
    assert s4["_outcome_id"] == "outcome_a"
    assert respx.calls.call_count == 3


# ── SO Out-of-scope ───────────────────────────────────────────────────────────


@respx.mock
def test_oos_so_1_out_of_scope_returns_interrupt():
    """SO + detect_out_of_scope=true: agent returns out_of_scope field in SO response.

    Turn 1: normal SO prompt (bot_response provided).
    Turn 2: user sends OOS message; agent's SO response has out_of_scope set.
      → WorkflowTool returns __OUT_OF_SCOPE_INTERRUPT__ string with reason in payload.

    Same checkpoint caveat as PM OOS: _out_of_scope_reason is NOT persisted.
    """
    responses = iter([
        llm_structured_response({
            "bot_response": "Please choose option_a or option_b.",
            "captured": False, "choice_value": None, "out_of_scope": None,
        }),
        llm_structured_response({
            "bot_response": None,
            "captured": False, "choice_value": None,
            "out_of_scope": "user wants weather forecast",
        }),
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("so_out_of_scope.yaml")
    tid = str(uuid.uuid4())

    # ── turn 1: normal prompt ──
    result1 = tool.execute(thread_id=tid, initial_context={})
    assert "Please choose option_a or option_b." in str(result1)
    assert InterruptType.USER_INPUT in str(result1)

    # ── turn 2: out-of-scope SO response ──
    result2 = tool.execute(thread_id=tid, user_message="what's the weather?", initial_context={})

    assert InterruptType.OUT_OF_SCOPE in str(result2)
    assert "weather" in str(result2)
    assert "Option A selected" not in str(result2)

    s2 = snap(tool, tid)

    assert s2.get("_out_of_scope_reason") is None
    assert s2["_status"] == "collect_choice_collecting"
    assert s2.get("choice_data") is None
    assert s2["_pending_prompt"] is not None
    assert "Please choose option_a or option_b." in s2["_pending_prompt"]["text"]
    assert s2["_collector_nodes"] == {}
    assert len(s2["_conversations"][SO_OOS_CONV_KEY]) == 1
    assert s2["error"] is None
    assert respx.calls.call_count == 2


@respx.mock
def test_oos_so_2_in_scope_captures_normally():
    """SO + detect_out_of_scope=true: in-scope response captures normally.

    Verifies detect_out_of_scope=true does NOT break normal SO capture flow.
    """
    responses = iter([
        llm_structured_response({
            "bot_response": "Please choose option_a or option_b.",
            "captured": False, "choice_value": None, "out_of_scope": None,
        }),
        llm_structured_response({
            "bot_response": None,
            "captured": True, "choice_value": "option_a", "out_of_scope": None,
        }),
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("so_out_of_scope.yaml")
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    result2 = tool.execute(thread_id=tid, user_message="option_a", initial_context={})
    s2 = snap(tool, tid)

    assert "Option A selected" in str(result2)
    assert InterruptType.OUT_OF_SCOPE not in str(result2)
    assert s2["choice_data"] == {
        "bot_response": None, "captured": True,
        "choice_value": "option_a", "out_of_scope": None,
    }
    assert s2["_status"] == "collect_choice_outcome_a"
    assert s2["_outcome_id"] == "outcome_a"
    assert s2.get("_out_of_scope_reason") is None
    assert s2["_collector_nodes"] == SO_OOS_COLLECTOR_NODES
    assert respx.calls.call_count == 2


@respx.mock
def test_oos_so_3_out_of_scope_on_initial_run_no_bot_response():
    """SO: out_of_scope returned with bot_response=None on initial run → OOS interrupt.

    When the LLM signals OOS on the very first call (T1 initial run) with no
    bot_response, the framework should return an OUT_OF_SCOPE interrupt immediately.

    Before fix: _check_context_extraction processed the response (out_of_scope guard
    missing), stored captured=False as field value, then incorrectly treated it as
    pre-populated.
    After fix: _check_context_extraction returns False early, _generate_prompt
    preserves out_of_scope in prompt_data, execute() calls _handle_out_of_scope.
    """
    respx.post(FAKE_LLM_COMPLETIONS).mock(
        return_value=llm_structured_response({
            "bot_response": None,
            "captured": False, "choice_value": None,
            "out_of_scope": "user asked about weather forecast",
        })
    )

    tool = make_tool("so_out_of_scope.yaml")
    tid = str(uuid.uuid4())

    result1 = tool.execute(thread_id=tid, initial_context={})

    assert InterruptType.OUT_OF_SCOPE in str(result1)
    assert "weather" in str(result1)
    assert "Option A selected" not in str(result1)
    assert "Option B selected" not in str(result1)
    assert InterruptType.USER_INPUT not in str(result1)
    assert respx.calls.call_count == 1


@respx.mock
def test_oos_so_4_out_of_scope_on_initial_run_with_bot_response():
    """SO: out_of_scope returned WITH bot_response on initial run → OOS takes priority.

    Even when the LLM returns both bot_response AND out_of_scope on T1,
    OOS should take priority. The bot_response must NOT be shown to the user.

    After fix: out_of_scope is extracted in _generate_prompt and checked in execute()
    before the text-prompt path, so OOS wins over any bot_response.
    """
    respx.post(FAKE_LLM_COMPLETIONS).mock(
        return_value=llm_structured_response({
            "bot_response": "Please choose option_a or option_b.",
            "captured": False, "choice_value": None,
            "out_of_scope": "user asked about weather forecast",
        })
    )

    tool = make_tool("so_out_of_scope.yaml")
    tid = str(uuid.uuid4())

    result1 = tool.execute(thread_id=tid, initial_context={})

    assert InterruptType.OUT_OF_SCOPE in str(result1)
    assert "weather" in str(result1)
    assert "Please choose option_a or option_b." not in str(result1)
    assert InterruptType.USER_INPUT not in str(result1)
    assert respx.calls.call_count == 1


@respx.mock
def test_oos_so_recovery_after_oos_captures_normally():
    """SO OOS: after an OOS interrupt, user can recover with two more turns.

    Turn 1: LLM generates prompt → USER_INPUT interrupt.
    Turn 2: user goes OOS → OOS interrupt returned.
    Turn 3: execute(no user_message) → continuation re-fires _pending_prompt
            (NO LLM call) → USER_INPUT interrupt.
    Turn 4: user sends valid answer → LLM captures option_a → outcome_a.

    3 total LLM calls (T1, T2, T4). T3 uses 0 LLM calls.
    """
    responses = iter([
        llm_structured_response({                      # T1: prompt
            "bot_response": "Please choose option_a or option_b.",
            "captured": False, "choice_value": None, "out_of_scope": None,
        }),
        llm_structured_response({                      # T2: OOS
            "bot_response": None,
            "captured": False, "choice_value": None,
            "out_of_scope": "user asked about weather",
        }),
        llm_structured_response({                      # T4: capture
            "bot_response": None,
            "captured": True, "choice_value": "option_a", "out_of_scope": None,
        }),
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("so_out_of_scope.yaml")
    tid = str(uuid.uuid4())

    result1 = tool.execute(thread_id=tid, initial_context={})
    assert InterruptType.USER_INPUT in str(result1)
    assert "Please choose option_a or option_b." in str(result1)
    s1 = snap(tool, tid)
    assert s1.get("choice_data") is None
    assert s1["_status"] == "collect_choice_collecting"
    assert respx.calls.call_count == 1

    result2 = tool.execute(thread_id=tid, user_message="what's the weather?", initial_context={})
    assert InterruptType.OUT_OF_SCOPE in str(result2)
    assert "weather" in str(result2)
    s2 = snap(tool, tid)
    assert s2.get("_out_of_scope_reason") is None   # not persisted (in-node mutation)
    assert s2["_status"] == "collect_choice_collecting"
    assert s2.get("choice_data") is None
    assert s2["_pending_prompt"] is not None
    assert "Please choose option_a or option_b." in s2["_pending_prompt"]["text"]
    assert len(s2["_conversations"][SO_OOS_CONV_KEY]) == 1
    assert respx.calls.call_count == 2

    # T3: resumes OOS interrupt → continuation prompt re-fires (no LLM call)
    result3 = tool.execute(thread_id=tid, initial_context={})
    assert InterruptType.USER_INPUT in str(result3)
    assert respx.calls.call_count == 2   # no new LLM call

    # T4: valid answer → captures → outcome_a
    result4 = tool.execute(thread_id=tid, user_message="option_a", initial_context={})
    s4 = snap(tool, tid)
    assert "Option A selected" in str(result4)
    assert s4["_outcome_id"] == "outcome_a"
    assert s4["_status"] == "collect_choice_outcome_a"
    assert s4["_collector_nodes"] == SO_OOS_COLLECTOR_NODES
    assert InterruptType.OUT_OF_SCOPE not in str(result4)
    assert respx.calls.call_count == 3
