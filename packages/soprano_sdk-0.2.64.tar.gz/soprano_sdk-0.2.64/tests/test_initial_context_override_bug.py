"""
Unit tests for initial_context override bug on workflow resume.

Bug: When a workflow is resumed, clients pass initial_context with values that
override state fields used by input collector nodes. The initial_context is
intended only for the first invocation — on resume, collector node fields
should never be overridden by initial_context.
"""

import pytest
from unittest.mock import MagicMock, patch
from soprano_sdk.tools import WorkflowTool
from soprano_sdk.core.constants import WorkflowKeys
from soprano_sdk.core.models import MessagePayload


class TestInitialContextOverrideBug:
    """
    Test that initial_context does NOT override any collector node fields
    when the workflow is resumed.
    """

    @patch('soprano_sdk.tools.load_workflow')
    @patch('soprano_sdk.utils.tracing.trace_workflow_execution')
    @patch('soprano_sdk.tools.CallbackHandler')
    def test_all_collector_fields_filtered_on_resume(
        self, mock_callback_handler, mock_trace, mock_load_workflow
    ):
        """
        On resume, ALL fields referenced by collector nodes should be filtered
        out from initial_context — not just the one currently being collected.

        Scenario:
        1. Node "get_name" has interrupted, asking "What's your name?"
        2. Caller passes initial_context={"name": "Alice", "age": 30, "locale": "en"}
        3. "name" and "age" are collector node fields → both filtered out
        4. "locale" is NOT a collector node field → allowed through
        """
        # Setup mocks
        mock_graph = MagicMock()
        mock_engine = MagicMock()
        mock_load_workflow.return_value = (mock_graph, mock_engine)

        # Mock trace context manager
        mock_span = MagicMock()
        mock_trace.return_value.__enter__.return_value = mock_span

        # Simulate state when "get_name" node has interrupted
        mock_state = MagicMock()
        mock_state.next = ["get_name"]  # Node is waiting for input
        mock_state.values = {
            WorkflowKeys.NODE_EXECUTION_ORDER: [],  # No nodes completed yet
            WorkflowKeys.STATUS: "get_name_collecting",
            "name": None,
        }
        mock_graph.get_state.return_value = mock_state

        # Mock collector_node_field_map (maps node_id -> field)
        mock_engine.collector_node_field_map = {
            "get_name": "name",
            "get_age": "age",
        }

        # Mock result
        mock_result = {"outcome": "success"}
        mock_graph.invoke.return_value = mock_result
        mock_engine.get_outcome_message.return_value = MessagePayload("Success", None, False)

        # Create workflow tool
        workflow = WorkflowTool(
            yaml_path="test.yaml",
            name="TestWorkflow",
            description="Test workflow",
        )

        # Execute — resuming with initial_context containing collector fields
        workflow.execute(
            thread_id="test-thread",
            user_message="John",
            initial_context={"name": "Alice", "age": 30, "locale": "en"},
        )

        # ASSERTION: Verify that ALL collector fields were filtered out
        mock_engine.update_context.assert_called_once()
        called_context = mock_engine.update_context.call_args[0][0]

        # Collector fields should NOT be in the context on resume
        assert "name" not in called_context, (
            f"'name' is a collector node field and should be filtered on resume. "
            f"Got context: {called_context}"
        )
        assert "age" not in called_context, (
            f"'age' is a collector node field and should be filtered on resume. "
            f"Got context: {called_context}"
        )

        # Non-collector fields SHOULD pass through
        assert "locale" in called_context, (
            f"'locale' is not a collector node field and should pass through. "
            f"Got context: {called_context}"
        )
        assert called_context["locale"] == "en"

    @patch('soprano_sdk.tools.load_workflow')
    @patch('soprano_sdk.utils.tracing.trace_workflow_execution')
    @patch('soprano_sdk.tools.CallbackHandler')
    def test_multi_field_collector_nodes_filtered_on_resume(
        self, mock_callback_handler, mock_trace, mock_load_workflow
    ):
        """
        Multi-field collector nodes (fields stored as a list) should also
        have all their fields filtered out on resume.
        """
        mock_graph = MagicMock()
        mock_engine = MagicMock()
        mock_load_workflow.return_value = (mock_graph, mock_engine)

        mock_span = MagicMock()
        mock_trace.return_value.__enter__.return_value = mock_span

        mock_state = MagicMock()
        mock_state.next = ["get_contact"]
        mock_state.values = {
            WorkflowKeys.NODE_EXECUTION_ORDER: [],
            WorkflowKeys.STATUS: "get_contact_collecting",
        }
        mock_graph.get_state.return_value = mock_state

        # Multi-field collector: get_contact collects both email and phone
        mock_engine.collector_node_field_map = {
            "get_contact": ["email", "phone"],
            "get_name": "name",
        }

        mock_result = {"outcome": "success"}
        mock_graph.invoke.return_value = mock_result
        mock_engine.get_outcome_message.return_value = MessagePayload("Success", None, False)

        workflow = WorkflowTool(
            yaml_path="test.yaml",
            name="TestWorkflow",
            description="Test workflow",
        )

        workflow.execute(
            thread_id="test-thread",
            user_message="test@example.com",
            initial_context={"email": "wrong@example.com", "phone": "000", "name": "Bad", "session_id": "abc123"},
        )

        mock_engine.update_context.assert_called_once()
        called_context = mock_engine.update_context.call_args[0][0]

        # All collector fields (including multi-field list) should be filtered
        assert "email" not in called_context
        assert "phone" not in called_context
        assert "name" not in called_context

        # Non-collector field should pass through
        assert called_context["session_id"] == "abc123"

    @patch('soprano_sdk.tools.load_workflow')
    @patch('soprano_sdk.utils.tracing.trace_workflow_execution')
    @patch('soprano_sdk.tools.CallbackHandler')
    def test_fresh_start_passes_all_initial_context(
        self, mock_callback_handler, mock_trace, mock_load_workflow
    ):
        """
        On fresh start (not resuming), ALL initial_context fields should be
        passed through, including collector node fields.
        """
        mock_graph = MagicMock()
        mock_engine = MagicMock()
        mock_load_workflow.return_value = (mock_graph, mock_engine)

        mock_span = MagicMock()
        mock_trace.return_value.__enter__.return_value = mock_span

        # Fresh start — state.next is empty
        mock_state = MagicMock()
        mock_state.next = []
        mock_graph.get_state.return_value = mock_state

        mock_engine.collector_node_field_map = {
            "get_name": "name",
        }

        mock_result = {"outcome": "success"}
        mock_graph.invoke.return_value = mock_result
        mock_engine.get_outcome_message.return_value = MessagePayload("Success", None, False)

        workflow = WorkflowTool(
            yaml_path="test.yaml",
            name="TestWorkflow",
            description="Test workflow",
        )

        initial_ctx = {"name": "Alice", "locale": "en"}
        workflow.execute(
            thread_id="test-thread",
            initial_context=initial_ctx,
        )

        # On fresh start, ALL fields should be passed to update_context
        mock_engine.update_context.assert_called_once_with(initial_ctx)


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
