"""
Structured Output (SO) single-field collection tests — pre-pop, agent captures,
validators, context extraction, max attempts, list-match transitions, collection failure.

Structured Output (SO) fixtures — field: choice_data (dict), step_id: collect_choice
  transitions:
    match="option_a" ref=choice_value → outcome_a ("Option A selected")
    match="option_b" ref=choice_value → outcome_b ("Option B selected")

State keys asserted in every test:
  _status / _outcome_id / choice_data / _messages / _validation_errors
  _node_execution_order / _node_field_map / _collector_nodes
  _conversations / _pending_prompt / error

Groups
  3. SO no validator        (6 tests) — pre-pop and agent captures
  4. SO with validator      (5 tests) — validate_choice rejects 'invalid_choice'
  6. SO Context extraction  (3 tests) — ce1: basic, ce2: validator pass, ce3: validator fail
  7. Max attempts SO        (1 test)  — retry_limit=2
  12. SO list-match         (3 tests) — match as list
  13. SO collection failure (2 tests) — no transition match triggers failure

── Coverage Gaps ──
  - SO OPTIONS_DATA: OPTIONS_DATA marker tested only for PM, not SO
  - OOS + validator combination: OOS detection with a validator configured not tested
  - IC + validator combination: IC + validator combo not tested
  - Max attempts + validator: Validator failures counting toward max_attempts not tested
"""

import uuid

import respx

from tests.helpers import (
    FAKE_LLM_COMPLETIONS,
    llm_structured_response,
    make_tool,
    snap,
)

# ── Conversation / collector constants ────────────────────────────────────────

SO_CONV_KEY = "choice_data_conversation"
SO_COLLECTOR_NODES = {"collect_choice": "Collect user choice"}
LM_CONV_KEY = "choice_data_conversation"
LM_COLLECTOR_NODES = {"collect_choice": "Collect user choice"}


# ── Group 3: SO Multi-Transition, No Validator ────────────────────────────────
# choice_data (dict) field; transitions match choice_value


@respx.mock
def test_so_t1_prepop_dict_first_transition():
    """SO + pre-pop dict {choice_value: 'option_a'}
    → _handle_pre_populated_field: response_dict = the dict
    → _find_matching_transition matches t1 → outcome_a.
    """
    tool = make_tool("so_multi_transition.yaml")
    tid = str(uuid.uuid4())

    result = tool.execute(
        thread_id=tid,
        initial_context={"choice_data": {"captured": True, "choice_value": "option_a"}},
    )
    s = snap(tool, tid)

    assert "Option A selected" in str(result)
    assert "Option B selected" not in str(result)

    # ── field stored as the pre-populated dict ──
    assert s["choice_data"] == {"captured": True, "choice_value": "option_a"}

    assert s["_status"] == "collect_choice_outcome_a"
    assert s["_outcome_id"] == "outcome_a"
    assert s["_node_execution_order"] == ["collect_choice"]
    assert s["_node_field_map"]["collect_choice"] == "choice_data"
    assert s["_messages"] == []
    assert s["_validation_errors"] == {}
    assert s["_collector_nodes"] == SO_COLLECTOR_NODES
    assert SO_CONV_KEY in s["_conversations"]
    assert s["_conversations"][SO_CONV_KEY] == []
    assert s.get("_pending_prompt") is None
    assert s["error"] is None
    assert respx.calls.call_count == 0


@respx.mock
def test_so_t2_prepop_dict_second_transition():
    """SO + pre-pop dict {choice_value: 'option_b'}
    → _find_matching_transition matches t2 → outcome_b.
    """
    tool = make_tool("so_multi_transition.yaml")
    tid = str(uuid.uuid4())

    result = tool.execute(
        thread_id=tid,
        initial_context={"choice_data": {"captured": True, "choice_value": "option_b"}},
    )
    s = snap(tool, tid)

    assert "Option B selected" in str(result)
    assert "Option A selected" not in str(result)

    assert s["choice_data"] == {"captured": True, "choice_value": "option_b"}
    assert s["_status"] == "collect_choice_outcome_b"
    assert s["_outcome_id"] == "outcome_b"
    assert s["_node_execution_order"] == ["collect_choice"]
    assert s["_messages"] == []
    assert s["_validation_errors"] == {}
    assert s["_collector_nodes"] == SO_COLLECTOR_NODES
    assert SO_CONV_KEY in s["_conversations"]
    assert s["_conversations"][SO_CONV_KEY] == []
    assert s.get("_pending_prompt") is None
    assert s["error"] is None
    assert respx.calls.call_count == 0


@respx.mock
def test_so_t3_prepop_string_fallback_to_first_transition():
    """SO + pre-pop string 'option_a' (not a dict)
    → _handle_pre_populated_field: response_dict = {} (string → empty dict)
    → _find_matching_transition({}): no match → fallback to transitions[0] (outcome_a).
    The field value remains the original string, no transformation applied.
    """
    tool = make_tool("so_multi_transition.yaml")
    tid = str(uuid.uuid4())

    result = tool.execute(thread_id=tid, initial_context={"choice_data": "option_a"})
    s = snap(tool, tid)

    # ── fallback always goes to first transition ──
    assert "Option A selected" in str(result)

    # ── field stored as-is (string, no dict conversion in pre-pop path) ──
    assert s["choice_data"] == "option_a"

    assert s["_status"] == "collect_choice_outcome_a"
    assert s["_outcome_id"] == "outcome_a"
    assert s["_messages"] == []
    assert s["_validation_errors"] == {}
    assert s["_collector_nodes"] == SO_COLLECTOR_NODES
    assert SO_CONV_KEY in s["_conversations"]
    assert s["_conversations"][SO_CONV_KEY] == []
    assert s.get("_pending_prompt") is None
    assert s["error"] is None
    assert respx.calls.call_count == 0


@respx.mock
def test_so_t4_agent_captures_first_transition():
    """SO + agent captures {choice_value: 'option_a'}
    Turn 1: bot_response prompt → interrupt (call 1).
    Turn 2: captured=True, choice_value='option_a' → _find_matching_transition → outcome_a (call 2).
    """
    responses = iter([
        llm_structured_response({
            "bot_response": "Please choose option_a or option_b.",
            "captured": None,
            "choice_value": None,
            "options": None,
            "is_selectable": None,
        }),
        llm_structured_response({
            "bot_response": None,
            "captured": True,
            "choice_value": "option_a",
            "options": None,
            "is_selectable": None,
        }),
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("so_multi_transition.yaml")
    tid = str(uuid.uuid4())

    # ── turn 1: agent generates prompt ──
    result1 = tool.execute(thread_id=tid, initial_context={})
    assert "Please choose option_a or option_b." in str(result1)

    s1 = snap(tool, tid)
    assert s1["_status"] == "collect_choice_collecting"
    assert s1.get("choice_data") is None
    assert s1["_validation_errors"] == {}
    assert s1["_node_execution_order"] == []
    assert s1["_collector_nodes"] == {}
    assert s1["_pending_prompt"] is not None
    assert s1["_pending_prompt"]["text"] == "Please choose option_a or option_b."
    assert s1["_pending_prompt"]["options"] == []
    assert s1["_pending_prompt"]["is_selectable"] is False
    # 1 message: assistant(prompt serialized as JSON)
    assert SO_CONV_KEY in s1["_conversations"]
    assert len(s1["_conversations"][SO_CONV_KEY]) == 1
    assert s1["_conversations"][SO_CONV_KEY][0]["role"] == "assistant"

    # ── turn 2: agent captures option_a ──
    result2 = tool.execute(thread_id=tid, user_message="option_a", initial_context={})
    s2 = snap(tool, tid)

    assert "Option A selected" in str(result2)
    assert "Option B selected" not in str(result2)

    # choice_data stores the full field_values dict from the SO agent
    assert s2["choice_data"] == {"captured": True, "choice_value": "option_a"}
    assert s2["_status"] == "collect_choice_outcome_a"
    assert s2["_outcome_id"] == "outcome_a"
    assert s2["_validation_errors"] == {}
    assert s2["_node_execution_order"] == ["collect_choice"]
    assert s2["_node_field_map"]["collect_choice"] == "choice_data"
    assert s2["_collector_nodes"] == SO_COLLECTOR_NODES
    # _messages contains the full agent_response dict representation
    assert len(s2["_messages"]) == 1
    assert "✓ Choice Data collected:" in s2["_messages"][0]
    # 3 messages: assistant(prompt) + user + assistant(capture)
    assert len(s2["_conversations"][SO_CONV_KEY]) == 3
    assert s2.get("_pending_prompt") is None
    assert s2["error"] is None
    assert respx.calls.call_count == 2


@respx.mock
def test_so_t5_agent_captures_second_transition():
    """SO + agent captures {choice_value: 'option_b'}
    Turn 1: prompt (call 1). Turn 2: captured=True, choice_value='option_b' → outcome_b (call 2).
    """
    responses = iter([
        llm_structured_response({
            "bot_response": "Please choose option_a or option_b.",
            "captured": None,
            "choice_value": None,
            "options": None,
            "is_selectable": None,
        }),
        llm_structured_response({
            "bot_response": None,
            "captured": True,
            "choice_value": "option_b",
            "options": None,
            "is_selectable": None,
        }),
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("so_multi_transition.yaml")
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    s1 = snap(tool, tid)
    assert s1["_status"] == "collect_choice_collecting"
    assert s1.get("choice_data") is None
    assert s1["_collector_nodes"] == {}
    assert s1["_pending_prompt"] is not None
    assert s1["_pending_prompt"]["text"] == "Please choose option_a or option_b."
    assert len(s1["_conversations"][SO_CONV_KEY]) == 1

    result2 = tool.execute(thread_id=tid, user_message="option_b", initial_context={})
    s2 = snap(tool, tid)

    assert "Option B selected" in str(result2)
    assert "Option A selected" not in str(result2)

    assert s2["choice_data"] == {"captured": True, "choice_value": "option_b"}
    assert s2["_status"] == "collect_choice_outcome_b"
    assert s2["_outcome_id"] == "outcome_b"
    assert s2["_validation_errors"] == {}
    assert s2["_node_execution_order"] == ["collect_choice"]
    assert s2["_collector_nodes"] == SO_COLLECTOR_NODES
    assert len(s2["_messages"]) == 1
    assert "✓ Choice Data collected:" in s2["_messages"][0]
    assert len(s2["_conversations"][SO_CONV_KEY]) == 3
    assert s2.get("_pending_prompt") is None
    assert s2["error"] is None
    assert respx.calls.call_count == 2


@respx.mock
def test_so_t6_agent_no_match_then_captures_first_transition():
    """SO + agent returns captured=False on turn 2 (no usable choice_value)
    → _handle_collection_failure: field cleared, re-prompt returned.
    Turn 3: captured=True, choice_value='option_a' → outcome_a.

    Turn 1: prompt (call 1).
    Turn 2: captured=False, choice_value=None → no transition match → collection failure (call 2).
    Turn 3: captures option_a → outcome_a (call 3).
    """
    responses = iter([
        llm_structured_response({
            "bot_response": "Please choose option_a or option_b.",
            "captured": None,
            "choice_value": None,
            "options": None,
            "is_selectable": None,
        }),
        llm_structured_response({
            "bot_response": None,
            "captured": False,         # explicitly not captured
            "choice_value": None,
            "options": None,
            "is_selectable": None,
        }),
        llm_structured_response({
            "bot_response": None,
            "captured": True,
            "choice_value": "option_a",
            "options": None,
            "is_selectable": None,
        }),
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("so_multi_transition.yaml")
    tid = str(uuid.uuid4())

    result1 = tool.execute(thread_id=tid, initial_context={})
    assert "Please choose option_a or option_b." in str(result1)

    # ── turn 2: collection failure ──
    result2 = tool.execute(thread_id=tid, user_message="something else", initial_context={})
    s2 = snap(tool, tid)

    assert "Option A selected" not in str(result2)
    assert "Option B selected" not in str(result2)

    assert s2["_status"] == "collect_choice_collecting"
    assert s2.get("choice_data") is None        # cleared by _handle_collection_failure
    assert s2["_validation_errors"] == {}   # no validator in Group 3
    assert s2["_node_execution_order"] == []
    assert s2["_collector_nodes"] == {}
    # 4 messages: assistant(prompt) + user + assistant(json-no-match) + assistant(failure-msg)
    assert len(s2["_conversations"][SO_CONV_KEY]) == 4
    assert s2["_pending_prompt"] is not None
    assert "couldn't understand" in s2["_pending_prompt"]["text"].lower() or "try again" in s2["_pending_prompt"]["text"].lower()

    # ── turn 3: valid capture ──
    result3 = tool.execute(thread_id=tid, user_message="option_a", initial_context={})
    s3 = snap(tool, tid)

    assert "Option A selected" in str(result3)

    assert s3["choice_data"] == {"captured": True, "choice_value": "option_a"}
    assert s3["_status"] == "collect_choice_outcome_a"
    assert s3["_outcome_id"] == "outcome_a"
    assert s3["_validation_errors"] == {}
    assert s3["_node_execution_order"] == ["collect_choice"]
    assert s3["_collector_nodes"] == SO_COLLECTOR_NODES
    # 6 messages: 4 from before + user(T3) + assistant(T3)
    assert len(s3["_conversations"][SO_CONV_KEY]) == 6
    assert s3.get("_pending_prompt") is None
    assert s3["error"] is None
    assert respx.calls.call_count == 3


# ── Group 4: SO Multi-Transition, With Validator ──────────────────────────────
# validate_choice: rejects choice_value == "invalid_choice"


@respx.mock
def test_so_v1_prepop_valid_dict_first_transition():
    """SO + validator + pre-pop {choice_value: 'option_a'}
    → validate_choice passes (not 'invalid_choice') → _find_matching_transition → outcome_a.
    """
    tool = make_tool("so_multi_transition_validator.yaml")
    tid = str(uuid.uuid4())

    result = tool.execute(
        thread_id=tid,
        initial_context={"choice_data": {"captured": True, "choice_value": "option_a"}},
    )
    s = snap(tool, tid)

    assert "Option A selected" in str(result)

    assert s["choice_data"] == {"captured": True, "choice_value": "option_a"}
    assert s["_status"] == "collect_choice_outcome_a"
    assert s["_outcome_id"] == "outcome_a"
    assert s["_validation_errors"] == {}
    assert s["_node_execution_order"] == ["collect_choice"]
    assert s["_messages"] == []
    assert s["_collector_nodes"] == SO_COLLECTOR_NODES
    assert SO_CONV_KEY in s["_conversations"]
    assert s["_conversations"][SO_CONV_KEY] == []
    assert s.get("_pending_prompt") is None
    assert s["error"] is None
    assert respx.calls.call_count == 0


@respx.mock
def test_so_v2_prepop_invalid_dict_reprompts_then_agent_captures():
    """SO + validator + pre-pop {choice_value: 'invalid_choice'}
    → validate_choice rejects → validation error interrupt (0 LLM calls).
    Turn 2: agent captures {choice_value: 'option_a'} → validate_choice passes → outcome_a.
    """
    responses = iter([
        llm_structured_response({
            "bot_response": None,
            "captured": True,
            "choice_value": "option_a",
            "options": None,
            "is_selectable": None,
        }),
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("so_multi_transition_validator.yaml")
    tid = str(uuid.uuid4())

    # ── turn 1: pre-pop fails validation ──
    result1 = tool.execute(
        thread_id=tid,
        initial_context={"choice_data": {"captured": True, "choice_value": "invalid_choice"}},
    )
    s1 = snap(tool, tid)

    assert "Option A selected" not in str(result1)
    assert "Option B selected" not in str(result1)
    assert respx.calls.call_count == 0           # no LLM call for the error

    assert s1["_status"] == "collect_choice_collecting"
    assert s1.get("choice_data") is None             # cleared by validator
    assert s1["_validation_errors"] == {
        "choice_data": {
            "value": {"captured": True, "choice_value": "invalid_choice"},
            "error": "'invalid_choice' is not a valid option",
        }
    }
    assert s1["_node_execution_order"] == []
    assert s1["_collector_nodes"] == {}
    # 2 messages: user(pre-pop value) + assistant(validation error)
    assert len(s1["_conversations"][SO_CONV_KEY]) == 2
    assert s1["_conversations"][SO_CONV_KEY][0]["role"] == "user"
    assert s1["_conversations"][SO_CONV_KEY][1]["role"] == "assistant"
    assert s1["_pending_prompt"] is not None
    assert "'invalid_choice' is not a valid option" in s1["_pending_prompt"]["text"]

    # ── turn 2: agent captures valid choice ──
    result2 = tool.execute(thread_id=tid, user_message="option_a", initial_context={})
    s2 = snap(tool, tid)

    assert "Option A selected" in str(result2)

    assert s2["choice_data"] == {"captured": True, "choice_value": "option_a"}
    assert s2["_status"] == "collect_choice_outcome_a"
    assert s2["_outcome_id"] == "outcome_a"
    assert s2["_validation_errors"] == {}        # cleared after success
    assert s2["_node_execution_order"] == ["collect_choice"]
    assert s2["_collector_nodes"] == SO_COLLECTOR_NODES
    # 4 messages: user(pre-pop) + assistant(error) + user(T2) + assistant(capture)
    assert len(s2["_conversations"][SO_CONV_KEY]) == 4
    assert s2.get("_pending_prompt") is None
    assert s2["error"] is None
    assert respx.calls.call_count == 1


@respx.mock
def test_so_v3_agent_captures_valid_first_transition():
    """SO + validator + agent captures option_a → validate_choice passes → outcome_a."""
    responses = iter([
        llm_structured_response({
            "bot_response": "Please choose option_a or option_b.",
            "captured": None,
            "choice_value": None,
            "options": None,
            "is_selectable": None,
        }),
        llm_structured_response({
            "bot_response": None,
            "captured": True,
            "choice_value": "option_a",
            "options": None,
            "is_selectable": None,
        }),
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("so_multi_transition_validator.yaml")
    tid = str(uuid.uuid4())

    result1 = tool.execute(thread_id=tid, initial_context={})
    assert "Please choose option_a or option_b." in str(result1)

    s1 = snap(tool, tid)
    assert s1["_status"] == "collect_choice_collecting"
    assert s1.get("choice_data") is None
    assert s1["_validation_errors"] == {}
    assert s1["_collector_nodes"] == {}
    assert s1["_pending_prompt"] is not None
    assert s1["_pending_prompt"]["text"] == "Please choose option_a or option_b."
    assert len(s1["_conversations"][SO_CONV_KEY]) == 1

    result2 = tool.execute(thread_id=tid, user_message="option_a", initial_context={})
    s2 = snap(tool, tid)

    assert "Option A selected" in str(result2)

    assert s2["choice_data"] == {"captured": True, "choice_value": "option_a"}
    assert s2["_status"] == "collect_choice_outcome_a"
    assert s2["_outcome_id"] == "outcome_a"
    assert s2["_validation_errors"] == {}
    assert s2["_node_execution_order"] == ["collect_choice"]
    assert s2["_collector_nodes"] == SO_COLLECTOR_NODES
    assert len(s2["_messages"]) == 1
    assert "✓ Choice Data collected:" in s2["_messages"][0]
    assert len(s2["_conversations"][SO_CONV_KEY]) == 3
    assert s2.get("_pending_prompt") is None
    assert s2["error"] is None
    assert respx.calls.call_count == 2


@respx.mock
def test_so_v4_agent_captures_valid_second_transition():
    """SO + validator + agent captures option_b → validate_choice passes → outcome_b."""
    responses = iter([
        llm_structured_response({
            "bot_response": "Please choose option_a or option_b.",
            "captured": None,
            "choice_value": None,
            "options": None,
            "is_selectable": None,
        }),
        llm_structured_response({
            "bot_response": None,
            "captured": True,
            "choice_value": "option_b",
            "options": None,
            "is_selectable": None,
        }),
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("so_multi_transition_validator.yaml")
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    s1 = snap(tool, tid)
    assert s1["_status"] == "collect_choice_collecting"
    assert s1.get("choice_data") is None
    assert s1["_collector_nodes"] == {}
    assert s1["_pending_prompt"] is not None
    assert s1["_pending_prompt"]["text"] == "Please choose option_a or option_b."
    assert len(s1["_conversations"][SO_CONV_KEY]) == 1

    result2 = tool.execute(thread_id=tid, user_message="option_b", initial_context={})
    s2 = snap(tool, tid)

    assert "Option B selected" in str(result2)
    assert "Option A selected" not in str(result2)

    assert s2["choice_data"] == {"captured": True, "choice_value": "option_b"}
    assert s2["_status"] == "collect_choice_outcome_b"
    assert s2["_outcome_id"] == "outcome_b"
    assert s2["_validation_errors"] == {}
    assert s2["_node_execution_order"] == ["collect_choice"]
    assert s2["_collector_nodes"] == SO_COLLECTOR_NODES
    assert len(s2["_messages"]) == 1
    assert "✓ Choice Data collected:" in s2["_messages"][0]
    assert len(s2["_conversations"][SO_CONV_KEY]) == 3
    assert s2.get("_pending_prompt") is None
    assert s2["error"] is None
    assert respx.calls.call_count == 2


@respx.mock
def test_so_v5_agent_captures_invalid_then_valid():
    """SO + validator + agent captures 'invalid_choice' first → validate_choice rejects
    → validation error interrupt. Turn 3 captures 'option_a' → passes → outcome_a.

    Turn 1: prompt (call 1).
    Turn 2: captured=True, choice_value='invalid_choice' → FAILS validate_choice (call 2).
    Turn 3: captured=True, choice_value='option_a' → passes → outcome_a (call 3).
    """
    responses = iter([
        llm_structured_response({
            "bot_response": "Please choose option_a or option_b.",
            "captured": None,
            "choice_value": None,
            "options": None,
            "is_selectable": None,
        }),
        llm_structured_response({
            "bot_response": None,
            "captured": True,
            "choice_value": "invalid_choice",
            "options": None,
            "is_selectable": None,
        }),
        llm_structured_response({
            "bot_response": None,
            "captured": True,
            "choice_value": "option_a",
            "options": None,
            "is_selectable": None,
        }),
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("so_multi_transition_validator.yaml")
    tid = str(uuid.uuid4())

    result1 = tool.execute(thread_id=tid, initial_context={})
    assert "Please choose option_a or option_b." in str(result1)

    # ── turn 2: captured 'invalid_choice' fails validation ──
    result2 = tool.execute(thread_id=tid, user_message="invalid_choice", initial_context={})
    s2 = snap(tool, tid)

    assert "Option A selected" not in str(result2)
    assert "Option B selected" not in str(result2)

    assert s2["_status"] == "collect_choice_collecting"   # still collecting
    assert s2.get("choice_data") is None                      # cleared by validator
    assert s2["_validation_errors"] == {
        "choice_data": {
            "value": {"captured": True, "choice_value": "invalid_choice"},
            "error": "'invalid_choice' is not a valid option",
        }
    }
    assert s2["_node_execution_order"] == []
    assert s2["_collector_nodes"] == {}
    # 4 messages: assistant(prompt) + user + assistant(json-capture) + assistant(validation-error)
    assert len(s2["_conversations"][SO_CONV_KEY]) == 4
    assert s2["_pending_prompt"] is not None
    assert "'invalid_choice' is not a valid option" in s2["_pending_prompt"]["text"]

    # ── turn 3: captured 'option_a' passes ──
    result3 = tool.execute(thread_id=tid, user_message="option_a", initial_context={})
    s3 = snap(tool, tid)

    assert "Option A selected" in str(result3)

    assert s3["choice_data"] == {"captured": True, "choice_value": "option_a"}
    assert s3["_status"] == "collect_choice_outcome_a"
    assert s3["_outcome_id"] == "outcome_a"
    assert s3["_validation_errors"] == {}                 # cleared after success
    assert s3["_node_execution_order"] == ["collect_choice"]
    assert s3["_collector_nodes"] == SO_COLLECTOR_NODES
    assert len(s3["_messages"]) == 1
    assert "✓ Choice Data collected:" in s3["_messages"][0]
    # 6 messages: 4 from before + user(T3) + assistant(T3-capture)
    assert len(s3["_conversations"][SO_CONV_KEY]) == 6
    assert s3.get("_pending_prompt") is None
    assert s3["error"] is None
    assert respx.calls.call_count == 3


# ── Group 6: SO Context Extraction ───────────────────────────────────────────


@respx.mock
def test_so_ce1_context_extraction_routes_to_first_transition():
    """SO + no pre-pop: LLM immediately returns captured=True, choice_value='option_a'
    on Turn 1 (context extraction — no bot_response, agent extracted from context).

    Expected: completes in 1 LLM call, routes to outcome_a.
    """
    respx.post(FAKE_LLM_COMPLETIONS).mock(
        return_value=llm_structured_response({
            "bot_response": None,
            "captured": True,
            "choice_value": "option_a",
            "options": None,
            "is_selectable": None,
        })
    )

    tool = make_tool("so_multi_transition.yaml")
    tid = str(uuid.uuid4())

    result = tool.execute(thread_id=tid, initial_context={})
    s = snap(tool, tid)

    assert "Option A selected" in str(result)
    assert "Option B selected" not in str(result)

    # SO context extraction stores the full validated SO model dict
    assert s["choice_data"] is not None
    assert s["choice_data"]["choice_value"] == "option_a"

    assert s["_status"] == "collect_choice_outcome_a"
    assert s["_outcome_id"] == "outcome_a"
    assert s["_node_execution_order"] == ["collect_choice"]
    assert s["_validation_errors"] == {}
    assert s["_collector_nodes"] == SO_COLLECTOR_NODES
    # context extraction path: no messages appended
    assert SO_CONV_KEY in s["_conversations"]
    assert s["_conversations"][SO_CONV_KEY] == []
    assert s.get("_pending_prompt") is None
    assert s["error"] is None
    assert respx.calls.call_count == 1


@respx.mock
def test_so_ce2_context_extraction_with_validator_routes_to_first_transition():
    """SO + validator + no pre-pop: LLM returns captured=True, choice_value='option_a'
    on Turn 1 (context extraction — no bot_response).

    validate_choice passes ('option_a' is not 'invalid_choice') → routes to outcome_a.
    Expected: completes in 1 LLM call, no conversation messages (CE path).
    """
    respx.post(FAKE_LLM_COMPLETIONS).mock(
        return_value=llm_structured_response({
            "bot_response": None,
            "captured": True,
            "choice_value": "option_a",
            "options": None,
            "is_selectable": None,
        })
    )

    tool = make_tool("so_multi_transition_validator.yaml")
    tid = str(uuid.uuid4())

    result = tool.execute(thread_id=tid, initial_context={})
    s = snap(tool, tid)

    assert "Option A selected" in str(result)
    assert "Option B selected" not in str(result)

    # SO context extraction stores the full validated SO model dict
    assert s["choice_data"] is not None
    assert s["choice_data"].get("choice_value") == "option_a"

    assert s["_status"] == "collect_choice_outcome_a"
    assert s["_outcome_id"] == "outcome_a"
    assert s["_node_execution_order"] == ["collect_choice"]
    assert s["_validation_errors"] == {}
    assert s["_collector_nodes"] == SO_COLLECTOR_NODES
    # context extraction path: no messages added
    assert SO_CONV_KEY in s["_conversations"]
    assert s["_conversations"][SO_CONV_KEY] == []
    assert s.get("_pending_prompt") is None
    assert s["error"] is None
    assert respx.calls.call_count == 1


@respx.mock
def test_so_ce3_context_extraction_validator_failure_then_agent_captures():
    """SO + validator + no pre-pop: LLM returns captured=True, choice_value='invalid_choice'
    on Turn 1 (context extraction), but validate_choice FAILS.

    T1: CE attempted (1 LLM call), validator rejects 'invalid_choice' → collecting state,
        re-prompt generated, conversation empty (CE path).
    T2: user sends message → LLM captures choice_value='option_a' → validator passes
        → outcome_a (LLM call 2).
    """
    responses = iter([
        llm_structured_response({           # T1: CE attempt → validator fails
            "bot_response": None,
            "captured": True,
            "choice_value": "invalid_choice",
            "options": None,
            "is_selectable": None,
        }),
        llm_structured_response({           # T2: valid capture
            "bot_response": None,
            "captured": True,
            "choice_value": "option_a",
            "options": None,
            "is_selectable": None,
        }),
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("so_multi_transition_validator.yaml")
    tid = str(uuid.uuid4())

    # ── turn 1: CE → validator fails → collecting ──
    result1 = tool.execute(thread_id=tid, initial_context={})
    s1 = snap(tool, tid)

    assert "Option A selected" not in str(result1)
    assert "Option B selected" not in str(result1)

    assert s1.get("choice_data") is None                          # cleared by validator
    assert s1["_status"] == "collect_choice_collecting"
    assert s1.get("_outcome_id") is None
    assert s1["_validation_errors"] != {}                         # validator error recorded
    assert "choice_data" in s1["_validation_errors"]
    assert s1["_validation_errors"]["choice_data"]["error"] == "'invalid_choice' is not a valid option"
    assert s1["_collector_nodes"] == {}
    # CE validator failure (both PM and SO): conversation gets 2 messages —
    #   user:      str(pre_populated_values) after field is cleared to None
    #   assistant: validation error message
    # Mirrors pm_ce3 which asserts len == 2 with user then assistant.
    assert SO_CONV_KEY in s1["_conversations"]
    assert len(s1["_conversations"][SO_CONV_KEY]) == 2
    assert s1["_conversations"][SO_CONV_KEY][0]["role"] == "user"
    assert s1["_conversations"][SO_CONV_KEY][1]["role"] == "assistant"
    assert s1["_pending_prompt"] is not None                      # re-prompt after failure
    assert s1["error"] is None
    assert respx.calls.call_count == 1

    # ── turn 2: user sends message → valid capture ──
    result2 = tool.execute(thread_id=tid, user_message="option_a", initial_context={})
    s2 = snap(tool, tid)

    assert "Option A selected" in str(result2)
    assert s2["_status"] == "collect_choice_outcome_a"
    assert s2["_outcome_id"] == "outcome_a"
    assert s2["_validation_errors"] == {}                         # cleared on success
    assert s2["_collector_nodes"] == SO_COLLECTOR_NODES
    assert s2["_node_execution_order"] == ["collect_choice"]
    assert s2.get("_pending_prompt") is None
    assert s2["error"] is None
    assert respx.calls.call_count == 2


# ── Group 7: Max Attempts (SO) ────────────────────────────────────────────────


@respx.mock
def test_so_max_attempts():
    """SO + retry_limit=2: 3 turns with captured=False → max_attempts.

    Turn 1: LLM returns bot_response prompt (call 1). User count = 0.
    Turn 2: LLM returns captured=False → _handle_collection_failure, user count = 1 (call 2).
    Turn 3: LLM returns captured=False → max_attempts, user count = 2 (call 3).

    Expected final state:
      _status = "collect_choice_max_attempts"
      choice_data = None
      _messages = [max_attempts_message with field="choice_data"]
    """
    responses = iter([
        llm_structured_response({                         # turn 1: prompt
            "bot_response": "Please choose option_a or option_b.",
            "captured": None,
            "choice_value": None,
            "options": None,
            "is_selectable": None,
        }),
        llm_structured_response({                         # turn 2: no capture
            "bot_response": None,
            "captured": False,
            "choice_value": None,
            "options": None,
            "is_selectable": None,
        }),
        llm_structured_response({                         # turn 3: no capture → max
            "bot_response": None,
            "captured": False,
            "choice_value": None,
            "options": None,
            "is_selectable": None,
        }),
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("so_multi_transition.yaml")
    tid = str(uuid.uuid4())

    # ── turn 1: generates prompt ──
    result1 = tool.execute(thread_id=tid, initial_context={})
    assert "Please choose option_a or option_b." in str(result1)

    s1 = snap(tool, tid)
    assert s1["_status"] == "collect_choice_collecting"
    assert s1.get("choice_data") is None
    assert s1["_node_execution_order"] == []
    assert s1["_collector_nodes"] == {}
    assert len(s1["_conversations"][SO_CONV_KEY]) == 1
    assert s1["_pending_prompt"] is not None
    assert s1["_pending_prompt"]["text"] == "Please choose option_a or option_b."

    # ── turn 2: collection failure → user_count = 1, continue ──
    result2 = tool.execute(thread_id=tid, user_message="nothing", initial_context={})
    s2 = snap(tool, tid)

    assert "Option A selected" not in str(result2)
    assert "Option B selected" not in str(result2)

    assert s2["_status"] == "collect_choice_collecting"
    assert s2.get("choice_data") is None         # cleared by _handle_collection_failure
    assert s2["_node_execution_order"] == []
    assert s2["_collector_nodes"] == {}
    assert s2["_validation_errors"] == {}
    # 4 msgs: assistant(prompt) + user + assistant(json-no-capture) + assistant(failure-msg)
    assert len(s2["_conversations"][SO_CONV_KEY]) == 4
    assert s2["_pending_prompt"] is not None  # continuation prompt set

    # ── turn 3: collection failure → user_count = 2 >= max → max_attempts ──
    result3 = tool.execute(thread_id=tid, user_message="still nothing", initial_context={})
    s3 = snap(tool, tid)

    assert "having trouble understanding" in str(result3).lower()
    assert "Option A selected" not in str(result3)
    assert "Option B selected" not in str(result3)

    assert s3["_status"] == "collect_choice_max_attempts"
    assert s3.get("choice_data") is None          # never successfully captured
    assert s3["_validation_errors"] == {}
    assert s3["_node_execution_order"] == []  # never registered
    assert s3["_node_field_map"] == {}
    assert s3["_collector_nodes"] == {}       # never registered
    assert s3["_messages"] == [
        "I'm having trouble understanding your choice_data. Please contact customer service for assistance."
    ]
    assert s3.get("_pending_prompt") is None
    assert s3["error"] is None
    # 7 msgs: 4 from before + user(T3) + assistant(T3-json) + assistant(T3-failure)
    assert len(s3["_conversations"][SO_CONV_KEY]) == 7
    assert respx.calls.call_count == 3


# ── Group 12: SO list-match transitions ───────────────────────────────────────


@respx.mock
def test_lm_t1_value_in_first_list_routes_to_outcome_a():
    """SO list-match: choice_value='option_x' is in match=['option_a','option_x'] → outcome_a.

    Verifies that list-valued 'match' in transitions correctly routes when
    field_value is any element of the list (not just an exact scalar match).
    """
    responses = iter([
        llm_structured_response({
            "bot_response": "Choose option_a, option_x, option_b, or option_y.",
            "captured": False, "choice_value": None,
        }),
        llm_structured_response({
            "bot_response": None,
            "captured": True, "choice_value": "option_x",
        }),
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("so_list_match.yaml")
    tid = str(uuid.uuid4())

    result1 = tool.execute(thread_id=tid, initial_context={})
    assert "Choose option_a" in str(result1)
    s1 = snap(tool, tid)
    assert s1["_status"] == "collect_choice_collecting"

    result2 = tool.execute(thread_id=tid, user_message="option_x", initial_context={})
    s2 = snap(tool, tid)

    assert "Option A/X selected" in str(result2)
    assert s2["_status"] == "collect_choice_outcome_a"
    assert s2["_outcome_id"] == "outcome_a"
    # choice_data stores full field_values dict; bot_response: None is included
    assert s2["choice_data"] == {"bot_response": None, "captured": True, "choice_value": "option_x"}
    assert s2["_validation_errors"] == {}
    assert s2["_node_execution_order"] == ["collect_choice"]
    assert s2["_node_field_map"]["collect_choice"] == "choice_data"
    assert s2["_collector_nodes"] == LM_COLLECTOR_NODES
    assert len(s2["_conversations"][LM_CONV_KEY]) == 3
    assert s2.get("_pending_prompt") is None
    assert s2["error"] is None
    assert respx.calls.call_count == 2


@respx.mock
def test_lm_t2_value_in_second_list_routes_to_outcome_b():
    """SO list-match: choice_value='option_y' is in match=['option_b','option_y'] → outcome_b."""
    responses = iter([
        llm_structured_response({
            "bot_response": "Choose option_a, option_x, option_b, or option_y.",
            "captured": False, "choice_value": None,
        }),
        llm_structured_response({
            "bot_response": None,
            "captured": True, "choice_value": "option_y",
        }),
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("so_list_match.yaml")
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    result2 = tool.execute(thread_id=tid, user_message="option_y", initial_context={})
    s2 = snap(tool, tid)

    assert "Option B/Y selected" in str(result2)
    assert s2["_status"] == "collect_choice_outcome_b"
    assert s2["_outcome_id"] == "outcome_b"
    assert s2["choice_data"] == {"bot_response": None, "captured": True, "choice_value": "option_y"}
    assert s2["_collector_nodes"] == LM_COLLECTOR_NODES
    assert respx.calls.call_count == 2


@respx.mock
def test_lm_t3_value_in_first_list_primary_element():
    """SO list-match: choice_value='option_a' (first element in list) → outcome_a.

    Ensures both head and non-head list elements match correctly.
    """
    responses = iter([
        llm_structured_response({
            "bot_response": "Choose your option.",
            "captured": False, "choice_value": None,
        }),
        llm_structured_response({
            "bot_response": None,
            "captured": True, "choice_value": "option_a",
        }),
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("so_list_match.yaml")
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    result2 = tool.execute(thread_id=tid, user_message="option_a", initial_context={})
    s2 = snap(tool, tid)

    assert "Option A/X selected" in str(result2)
    assert s2["_status"] == "collect_choice_outcome_a"
    assert s2["_outcome_id"] == "outcome_a"
    assert respx.calls.call_count == 2


# ── Group 13: SO collection failure ──────────────────────────────────────────


@respx.mock
def test_cf_1_no_transition_match_triggers_collection_failure():
    """SO: agent captures a value not in any transition list → _handle_collection_failure.

    choice_value='option_c' is not in either ['option_a','option_x'] or ['option_b','option_y'].
    No next_step defined in the YAML.
    Expected: COLLECTION_FAILURE_MESSAGE returned, status stays 'collecting'.
    """
    import json as _json

    COLLECTION_FAILURE_MSG = "I couldn't understand your response. Please try again and provide the required information."

    responses = iter([
        llm_structured_response({
            "bot_response": "Choose option_a, option_x, option_b, or option_y.",
            "captured": False, "choice_value": None,
        }),
        llm_structured_response({
            "bot_response": None,
            "captured": True, "choice_value": "option_c",   # not in any list
        }),
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("so_list_match.yaml")
    tid = str(uuid.uuid4())

    # ── turn 1: normal prompt ──
    result1 = tool.execute(thread_id=tid, initial_context={})
    assert "Choose option_a" in str(result1)

    # ── turn 2: unrecognised value → collection failure ──
    result2 = tool.execute(thread_id=tid, user_message="option_c", initial_context={})
    s2 = snap(tool, tid)

    # Not expected: workflow completed
    assert "Option A/X selected" not in str(result2)
    assert "Option B/Y selected" not in str(result2)
    # Expected: collection failure prompt
    assert COLLECTION_FAILURE_MSG in str(result2)

    # Status: still collecting
    assert s2["_status"] == "collect_choice_collecting"

    # Field cleared by _handle_collection_failure → _store_field_value(state, None)
    assert s2.get("choice_data") is None

    # Not registered as completed
    assert s2["_collector_nodes"] == {}
    assert s2["_node_execution_order"] == []

    # Conversation after T2: 4 messages
    # [assistant(T1 prompt)] + [user(T2)] + [assistant(T2 raw SO)] + [assistant(collection failure)]
    assert len(s2["_conversations"][LM_CONV_KEY]) == 4
    assert s2["_conversations"][LM_CONV_KEY][0]["role"] == "assistant"  # T1 prompt
    assert s2["_conversations"][LM_CONV_KEY][1]["role"] == "user"       # T2 user
    assert s2["_conversations"][LM_CONV_KEY][2]["role"] == "assistant"  # T2 raw SO
    assert s2["_conversations"][LM_CONV_KEY][3]["role"] == "assistant"  # collection failure
    # Verify the collection failure message is in the last assistant message
    last_msg_content = _json.loads(s2["_conversations"][LM_CONV_KEY][3]["content"])
    assert last_msg_content["text"] == COLLECTION_FAILURE_MSG

    # Pending prompt holds the collection failure message
    assert s2["_pending_prompt"] is not None
    assert s2["_pending_prompt"]["text"] == COLLECTION_FAILURE_MSG

    assert s2["error"] is None
    assert respx.calls.call_count == 2


@respx.mock
def test_cf_2_collection_failure_then_recovery():
    """SO: collection failure on T2 (unrecognised value), recovery on T3 (valid list match).

    Turn 1: prompt.
    Turn 2: 'option_c' → no transition match → collection failure (re-prompt).
    Turn 3: 'option_x' → in ['option_a','option_x'] → outcome_a (success).
    """
    responses = iter([
        llm_structured_response({
            "bot_response": "Choose your option.",
            "captured": False, "choice_value": None,
        }),
        llm_structured_response({
            "bot_response": None,
            "captured": True, "choice_value": "option_c",  # unrecognised
        }),
        llm_structured_response({
            "bot_response": None,
            "captured": True, "choice_value": "option_x",  # valid
        }),
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("so_list_match.yaml")
    tid = str(uuid.uuid4())

    # Turn 1
    tool.execute(thread_id=tid, initial_context={})

    # Turn 2 — collection failure
    result2 = tool.execute(thread_id=tid, user_message="option_c", initial_context={})
    s2 = snap(tool, tid)
    assert "Option A/X selected" not in str(result2)
    assert s2["_status"] == "collect_choice_collecting"
    assert s2.get("choice_data") is None

    # Turn 3 — recovery
    result3 = tool.execute(thread_id=tid, user_message="option_x", initial_context={})
    s3 = snap(tool, tid)

    assert "Option A/X selected" in str(result3)
    assert s3["_status"] == "collect_choice_outcome_a"
    assert s3["_outcome_id"] == "outcome_a"
    assert s3["choice_data"] == {"bot_response": None, "captured": True, "choice_value": "option_x"}
    assert s3["_validation_errors"] == {}
    assert s3["_collector_nodes"] == LM_COLLECTOR_NODES

    # Conversation after T3: 4 (T1+T2 messages) + user(T3) + assistant(T3 capture) = 6 messages
    assert len(s3["_conversations"][LM_CONV_KEY]) == 6
    assert s3.get("_pending_prompt") is None
    assert s3["error"] is None
    assert respx.calls.call_count == 3
