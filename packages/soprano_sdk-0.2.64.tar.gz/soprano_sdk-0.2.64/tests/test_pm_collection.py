"""
Pattern Matching (PM) mode collection tests — pre-pop, agent captures, validators,
context extraction, max attempts, OPTIONS_DATA, edge cases.

Cross-maps all logical combinations:
  Mode       × Population source  × Validator  × Transition taken
  PM         × pre-pop / agent    × none / yes × t1 / t2 / fallback

Pattern Matching (PM) fixtures — field: status (text), step_id: collect_status
  transitions:
    STATUS_A: → outcome_a ("Status A set")
    STATUS_B: → outcome_b ("Status B set")

State keys asserted in every test:
  _status / _outcome_id / status / _messages / _validation_errors
  _node_execution_order / _node_field_map / _collector_nodes
  _conversations / _pending_prompt / error

Groups
  1. PM no validator       (6 tests) — pre-pop and agent captures
  2. PM with validator     (5 tests) — validates stripped value
  5. PM Context extraction (4 tests) — includes validator failure case
  7. Max attempts PM       (1 test)  — retry_limit=2
  8. Edge cases            (1 test)  — empty value after strip
  14. PM OPTIONS_DATA      (3 tests) — marker extraction and stripping

── Coverage Gaps ──
  - PM multi-field: Multi-field collection only tested in SO mode
  - PM boolean transitions: Boolean value matching only tested in SO
  - OOS + validator combination: OOS detection with a validator configured not tested
  - IC + validator combination: IC + validator combo not tested
  - Max attempts + validator: Validator failures counting toward max_attempts not tested
"""

import json
import uuid

import respx

from tests.helpers import (
    FAKE_LLM_COMPLETIONS,
    llm_text_response,
    make_tool,
    snap,
)
from soprano_sdk.core.constants import InterruptType

# ── Conversation / collector constants ────────────────────────────────────────

PM_CONV_KEY = "status_conversation"
PM_COLLECTOR_NODES = {"collect_status": "Collect status"}


# ── Group 1: PM Multi-Transition, No Validator ────────────────────────────────


@respx.mock
def test_pm_t1_prepop_pattern_first_transition():
    """PM + pre-pop 'STATUS_A: active'
    → _handle_pre_populated_field strips prefix → stores 'active' → outcome_a.
    No LLM calls.
    """
    tool = make_tool("pm_multi_transition.yaml")
    tid = str(uuid.uuid4())

    result = tool.execute(thread_id=tid, initial_context={"status": "STATUS_A: active"})
    s = snap(tool, tid)

    # ── output ──
    assert "Status A set" in str(result)
    assert "Status B set" not in str(result)

    # ── field stored (prefix stripped) ──
    assert s["status"] == "active"

    # ── correct transition and outcome ──
    assert s["_status"] == "collect_status_outcome_a"
    assert s["_outcome_id"] == "outcome_a"

    # ── node registered after completion ──
    assert s["_node_execution_order"] == ["collect_status"]
    assert s["_node_field_map"]["collect_status"] == "status"

    # ── no confirmation message for pre-pop ──
    assert s["_messages"] == []

    # ── no validation errors ──
    assert s["_validation_errors"] == {}

    # ── collector node registered ──
    assert s["_collector_nodes"] == PM_COLLECTOR_NODES

    # ── conversation: no messages added for pre-pop ──
    assert PM_CONV_KEY in s["_conversations"]
    assert s["_conversations"][PM_CONV_KEY] == []

    # ── no pending prompt after completion ──
    assert s.get("_pending_prompt") is None

    # ── no error ──
    assert s["error"] is None

    # ── no LLM calls ──
    assert respx.calls.call_count == 0


@respx.mock
def test_pm_t2_prepop_pattern_second_transition():
    """PM + pre-pop 'STATUS_B: idle'
    → _handle_pre_populated_field strips prefix → stores 'idle' → outcome_b.
    No LLM calls.
    """
    tool = make_tool("pm_multi_transition.yaml")
    tid = str(uuid.uuid4())

    result = tool.execute(thread_id=tid, initial_context={"status": "STATUS_B: idle"})
    s = snap(tool, tid)

    # ── output ──
    assert "Status B set" in str(result)
    assert "Status A set" not in str(result)

    # ── field stored (prefix stripped) ──
    assert s["status"] == "idle"

    # ── correct transition and outcome ──
    assert s["_status"] == "collect_status_outcome_b"
    assert s["_outcome_id"] == "outcome_b"

    # ── node registered ──
    assert s["_node_execution_order"] == ["collect_status"]
    assert s["_node_field_map"]["collect_status"] == "status"

    # ── no messages, no validation errors ──
    assert s["_messages"] == []
    assert s["_validation_errors"] == {}

    # ── collector node registered ──
    assert s["_collector_nodes"] == PM_COLLECTOR_NODES

    # ── conversation: no messages for pre-pop ──
    assert PM_CONV_KEY in s["_conversations"]
    assert s["_conversations"][PM_CONV_KEY] == []

    # ── no pending prompt, no error ──
    assert s.get("_pending_prompt") is None
    assert s["error"] is None

    assert respx.calls.call_count == 0


@respx.mock
def test_pm_t3_prepop_no_pattern_fallback_to_first_transition():
    """PM + pre-pop 'running' (no pattern match anywhere)
    → _handle_pre_populated_field: no transition matched → fallback to transitions[0]
    → outcome_a. Value stored as-is.
    """
    tool = make_tool("pm_multi_transition.yaml")
    tid = str(uuid.uuid4())

    result = tool.execute(thread_id=tid, initial_context={"status": "running"})
    s = snap(tool, tid)

    # ── output ──
    assert "Status A set" in str(result)   # fallback to t1
    assert "Status B set" not in str(result)

    # ── field stored unchanged (no prefix to strip) ──
    assert s["status"] == "running"

    # ── outcome reflects first transition fallback ──
    assert s["_status"] == "collect_status_outcome_a"
    assert s["_outcome_id"] == "outcome_a"

    assert s["_node_execution_order"] == ["collect_status"]
    assert s["_messages"] == []
    assert s["_validation_errors"] == {}

    # ── collector node registered ──
    assert s["_collector_nodes"] == PM_COLLECTOR_NODES

    # ── no messages for pre-pop, no pending prompt, no error ──
    assert PM_CONV_KEY in s["_conversations"]
    assert s["_conversations"][PM_CONV_KEY] == []
    assert s.get("_pending_prompt") is None
    assert s["error"] is None

    assert respx.calls.call_count == 0


@respx.mock
def test_pm_t4_agent_captures_first_transition():
    """PM + agent captures 'STATUS_A: active'
    Turn 1: LLM generates prompt → interrupt (call 1).
    Turn 2: LLM returns 'STATUS_A: active' → strips to 'active' → outcome_a (call 2).
    """
    responses = iter([
        llm_text_response("What is your status?"),   # turn 1: prompt
        llm_text_response("STATUS_A: active"),        # turn 2: capture → t1
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("pm_multi_transition.yaml")
    tid = str(uuid.uuid4())

    # ── turn 1: prompt returned as interrupt ──
    result1 = tool.execute(thread_id=tid, initial_context={})
    assert "What is your status?" in str(result1)

    s1 = snap(tool, tid)
    assert s1["_status"] == "collect_status_collecting"   # still collecting
    assert s1.get("status") is None                        # not captured yet
    assert s1["_validation_errors"] == {}
    assert s1["_node_execution_order"] == []               # not registered until done
    assert s1["_collector_nodes"] == {}                    # not registered until done
    # pending_prompt holds the prompt text to show user
    assert s1["_pending_prompt"] is not None
    assert s1["_pending_prompt"]["text"] == "What is your status?"
    assert s1["_pending_prompt"]["options"] == []
    assert s1["_pending_prompt"]["is_selectable"] is False
    # conversation has 1 assistant message (the generated prompt)
    assert PM_CONV_KEY in s1["_conversations"]
    assert len(s1["_conversations"][PM_CONV_KEY]) == 1
    assert s1["_conversations"][PM_CONV_KEY][0]["role"] == "assistant"

    # ── turn 2: user responds, agent captures ──
    result2 = tool.execute(thread_id=tid, user_message="active", initial_context={})
    s2 = snap(tool, tid)

    assert "Status A set" in str(result2)
    assert "Status B set" not in str(result2)

    assert s2["status"] == "active"
    assert s2["_status"] == "collect_status_outcome_a"
    assert s2["_outcome_id"] == "outcome_a"
    assert s2["_node_execution_order"] == ["collect_status"]
    assert s2["_node_field_map"]["collect_status"] == "status"
    assert s2["_messages"] == ["✓ Status collected: active"]
    assert s2["_validation_errors"] == {}
    # collector node registered on completion
    assert s2["_collector_nodes"] == PM_COLLECTOR_NODES
    # 3 messages: assistant(prompt) + user + assistant(capture)
    assert len(s2["_conversations"][PM_CONV_KEY]) == 3
    assert s2["_conversations"][PM_CONV_KEY][0]["role"] == "assistant"
    assert s2["_conversations"][PM_CONV_KEY][1]["role"] == "user"
    assert s2["_conversations"][PM_CONV_KEY][2]["role"] == "assistant"
    # no pending prompt after completion
    assert s2.get("_pending_prompt") is None
    assert s2["error"] is None
    assert respx.calls.call_count == 2


@respx.mock
def test_pm_t5_agent_captures_second_transition():
    """PM + agent captures 'STATUS_B: idle'
    Turn 1: prompt (call 1). Turn 2: 'STATUS_B: idle' → 'idle' → outcome_b (call 2).
    """
    responses = iter([
        llm_text_response("What is your status?"),   # turn 1: prompt
        llm_text_response("STATUS_B: idle"),          # turn 2: capture → t2
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("pm_multi_transition.yaml")
    tid = str(uuid.uuid4())

    result1 = tool.execute(thread_id=tid, initial_context={})
    assert "What is your status?" in str(result1)

    s1 = snap(tool, tid)
    assert s1["_status"] == "collect_status_collecting"
    assert s1.get("status") is None
    assert s1["_collector_nodes"] == {}
    assert s1["_pending_prompt"] is not None
    assert s1["_pending_prompt"]["text"] == "What is your status?"
    assert len(s1["_conversations"][PM_CONV_KEY]) == 1

    result2 = tool.execute(thread_id=tid, user_message="idle", initial_context={})
    s2 = snap(tool, tid)

    assert "Status B set" in str(result2)
    assert "Status A set" not in str(result2)

    assert s2["status"] == "idle"
    assert s2["_status"] == "collect_status_outcome_b"
    assert s2["_outcome_id"] == "outcome_b"
    assert s2["_node_execution_order"] == ["collect_status"]
    assert s2["_messages"] == ["✓ Status collected: idle"]
    assert s2["_validation_errors"] == {}
    assert s2["_collector_nodes"] == PM_COLLECTOR_NODES
    # 3 messages: assistant(prompt) + user + assistant(capture)
    assert len(s2["_conversations"][PM_CONV_KEY]) == 3
    assert s2.get("_pending_prompt") is None
    assert s2["error"] is None
    assert respx.calls.call_count == 2


@respx.mock
def test_pm_t6_agent_no_match_then_first_transition():
    """PM + agent returns no-match response on turn 2 → re-prompt → turn 3 captures STATUS_A.

    Turn 1: prompt (call 1).
    Turn 2: 'I didn't catch that.' (no pattern) → collecting continues (call 2).
    Turn 3: 'STATUS_A: active' → outcome_a (call 3).
    """
    responses = iter([
        llm_text_response("What is your status?"),    # turn 1: prompt
        llm_text_response("I didn't catch that."),    # turn 2: no pattern → re-prompt
        llm_text_response("STATUS_A: active"),         # turn 3: capture → t1
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("pm_multi_transition.yaml")
    tid = str(uuid.uuid4())

    result1 = tool.execute(thread_id=tid, initial_context={})
    assert "What is your status?" in str(result1)

    # ── turn 2: no-match ──
    result2 = tool.execute(thread_id=tid, user_message="hmm", initial_context={})

    s2 = snap(tool, tid)
    assert "Status A set" not in str(result2)   # still collecting
    assert "Status B set" not in str(result2)
    assert s2["_status"] == "collect_status_collecting"
    assert s2.get("status") is None
    assert s2["_node_execution_order"] == []    # not registered yet
    assert s2["_validation_errors"] == {}
    assert s2["_collector_nodes"] == {}
    # 3 messages: assistant(prompt) + user + assistant(no-match)
    assert len(s2["_conversations"][PM_CONV_KEY]) == 3
    # pending_prompt holds the continuation message
    assert s2["_pending_prompt"] is not None
    assert s2["_pending_prompt"]["text"] == "I didn't catch that."

    # ── turn 3: valid capture ──
    result3 = tool.execute(thread_id=tid, user_message="active", initial_context={})
    s3 = snap(tool, tid)

    assert "Status A set" in str(result3)

    assert s3["status"] == "active"
    assert s3["_status"] == "collect_status_outcome_a"
    assert s3["_outcome_id"] == "outcome_a"
    assert s3["_node_execution_order"] == ["collect_status"]
    assert s3["_messages"] == ["✓ Status collected: active"]
    assert s3["_validation_errors"] == {}
    assert s3["_collector_nodes"] == PM_COLLECTOR_NODES
    # 5 messages: assistant(T1) + user(T2) + assistant(T2) + user(T3) + assistant(T3)
    assert len(s3["_conversations"][PM_CONV_KEY]) == 5
    assert s3.get("_pending_prompt") is None
    assert s3["error"] is None
    assert respx.calls.call_count == 3


# ── Group 2: PM Multi-Transition, With Validator ──────────────────────────────
# validate_status: status value must be ≥ 3 chars (applied to the STRIPPED value)


@respx.mock
def test_pm_v1_prepop_valid_first_transition():
    """PM + validator + pre-pop 'STATUS_A: active'
    validate_status receives raw value 'STATUS_A: active' (14 chars ≥ 3) → passes.
    Pattern strips to 'active' → stored → outcome_a.
    """
    tool = make_tool("pm_multi_transition_validator.yaml")
    tid = str(uuid.uuid4())

    result = tool.execute(thread_id=tid, initial_context={"status": "STATUS_A: active"})
    s = snap(tool, tid)

    assert "Status A set" in str(result)

    # NOTE: pre-pop validation runs on the RAW value before the pattern strip.
    # 'STATUS_A: active' passes (14 chars). After stripping: 'active' is stored.
    assert s["status"] == "active"
    assert s["_status"] == "collect_status_outcome_a"
    assert s["_outcome_id"] == "outcome_a"
    assert s["_validation_errors"] == {}
    assert s["_node_execution_order"] == ["collect_status"]
    assert s["_collector_nodes"] == PM_COLLECTOR_NODES
    assert PM_CONV_KEY in s["_conversations"]
    assert s["_conversations"][PM_CONV_KEY] == []
    assert s.get("_pending_prompt") is None
    assert s["error"] is None
    assert respx.calls.call_count == 0


@respx.mock
def test_pm_v2_prepop_invalid_reprompts_then_agent_captures():
    """PM + validator + pre-pop 'X' (1 char, fails validate_status)
    → validation error returned as interrupt (0 LLM calls).
    Turn 2: agent captures 'STATUS_A: running' → 'running' (6 chars) passes → outcome_a.
    """
    responses = iter([
        llm_text_response("STATUS_A: running"),  # turn 2: agent captures valid value
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("pm_multi_transition_validator.yaml")
    tid = str(uuid.uuid4())

    # ── turn 1: pre-pop fails validation ──
    result1 = tool.execute(thread_id=tid, initial_context={"status": "X"})

    s1 = snap(tool, tid)
    assert "Status A set" not in str(result1)         # validation error, not success
    assert respx.calls.call_count == 0                # no LLM call for the error itself

    assert s1["_status"] == "collect_status_collecting"
    assert s1.get("status") is None                    # cleared by validator
    assert s1["_validation_errors"] == {
        "status": {"value": "X", "error": "Status must be at least 3 characters"}
    }
    assert s1["_node_execution_order"] == []
    assert s1["_collector_nodes"] == {}
    # 2 messages: user(pre-pop value) + assistant(validation error)
    assert len(s1["_conversations"][PM_CONV_KEY]) == 2
    assert s1["_conversations"][PM_CONV_KEY][0]["role"] == "user"
    assert s1["_conversations"][PM_CONV_KEY][1]["role"] == "assistant"
    assert s1["_pending_prompt"] is not None
    assert "Status must be at least 3 characters" in s1["_pending_prompt"]["text"]

    # ── turn 2: agent captures valid value ──
    result2 = tool.execute(thread_id=tid, user_message="running", initial_context={})
    s2 = snap(tool, tid)

    assert "Status A set" in str(result2)

    assert s2["status"] == "running"
    assert s2["_status"] == "collect_status_outcome_a"
    assert s2["_outcome_id"] == "outcome_a"
    assert s2["_validation_errors"] == {}              # cleared after success
    assert s2["_node_execution_order"] == ["collect_status"]
    assert s2["_messages"] == ["✓ Status collected: running"]
    assert s2["_collector_nodes"] == PM_COLLECTOR_NODES
    # 4 messages: user(pre-pop) + assistant(error) + user(T2) + assistant(capture)
    assert len(s2["_conversations"][PM_CONV_KEY]) == 4
    assert s2.get("_pending_prompt") is None
    assert s2["error"] is None
    assert respx.calls.call_count == 1


@respx.mock
def test_pm_v3_agent_captures_valid_first_transition():
    """PM + validator + agent captures 'STATUS_A: running'
    → stripped 'running' (6 chars) passes validate_status → outcome_a.
    """
    responses = iter([
        llm_text_response("What is your status?"),   # turn 1: prompt
        llm_text_response("STATUS_A: running"),       # turn 2: valid capture → t1
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("pm_multi_transition_validator.yaml")
    tid = str(uuid.uuid4())

    result1 = tool.execute(thread_id=tid, initial_context={})
    assert "What is your status?" in str(result1)

    s1 = snap(tool, tid)
    assert s1["_status"] == "collect_status_collecting"
    assert s1.get("status") is None
    assert s1["_validation_errors"] == {}
    assert s1["_collector_nodes"] == {}
    assert s1["_pending_prompt"] is not None
    assert s1["_pending_prompt"]["text"] == "What is your status?"
    assert len(s1["_conversations"][PM_CONV_KEY]) == 1

    result2 = tool.execute(thread_id=tid, user_message="running", initial_context={})
    s2 = snap(tool, tid)

    assert "Status A set" in str(result2)

    assert s2["status"] == "running"
    assert s2["_status"] == "collect_status_outcome_a"
    assert s2["_outcome_id"] == "outcome_a"
    assert s2["_validation_errors"] == {}
    assert s2["_messages"] == ["✓ Status collected: running"]
    assert s2["_node_execution_order"] == ["collect_status"]
    assert s2["_collector_nodes"] == PM_COLLECTOR_NODES
    assert len(s2["_conversations"][PM_CONV_KEY]) == 3
    assert s2.get("_pending_prompt") is None
    assert s2["error"] is None
    assert respx.calls.call_count == 2


@respx.mock
def test_pm_v4_agent_captures_valid_second_transition():
    """PM + validator + agent captures 'STATUS_B: idle'
    → stripped 'idle' (4 chars) passes validate_status → outcome_b.
    """
    responses = iter([
        llm_text_response("What is your status?"),   # turn 1: prompt
        llm_text_response("STATUS_B: idle"),          # turn 2: valid capture → t2
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("pm_multi_transition_validator.yaml")
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    s1 = snap(tool, tid)
    assert s1["_status"] == "collect_status_collecting"
    assert s1["_collector_nodes"] == {}
    assert s1["_pending_prompt"] is not None
    assert s1["_pending_prompt"]["text"] == "What is your status?"
    assert len(s1["_conversations"][PM_CONV_KEY]) == 1

    result2 = tool.execute(thread_id=tid, user_message="idle", initial_context={})
    s2 = snap(tool, tid)

    assert "Status B set" in str(result2)
    assert "Status A set" not in str(result2)

    assert s2["status"] == "idle"
    assert s2["_status"] == "collect_status_outcome_b"
    assert s2["_outcome_id"] == "outcome_b"
    assert s2["_validation_errors"] == {}
    assert s2["_messages"] == ["✓ Status collected: idle"]
    assert s2["_node_execution_order"] == ["collect_status"]
    assert s2["_node_field_map"]["collect_status"] == "status"
    assert s2["_collector_nodes"] == PM_COLLECTOR_NODES
    assert len(s2["_conversations"][PM_CONV_KEY]) == 3
    assert s2.get("_pending_prompt") is None
    assert s2["error"] is None
    assert respx.calls.call_count == 2


@respx.mock
def test_pm_v5_agent_captures_invalid_then_valid():
    """PM + validator + agent captures 'ab' first (too short), then 'abc' (exactly 3 chars).

    Turn 1: prompt (call 1).
    Turn 2: 'STATUS_A: ab' → stripped 'ab' (2 chars) FAILS validate_status → re-prompt (call 2).
    Turn 3: 'STATUS_A: abc' → stripped 'abc' (3 chars) passes → outcome_a (call 3).
    """
    responses = iter([
        llm_text_response("What is your status?"),   # turn 1: prompt
        llm_text_response("STATUS_A: ab"),            # turn 2: 'ab' → INVALID (2 chars)
        llm_text_response("STATUS_A: abc"),           # turn 3: 'abc' → valid → t1
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("pm_multi_transition_validator.yaml")
    tid = str(uuid.uuid4())

    result1 = tool.execute(thread_id=tid, initial_context={})
    assert "What is your status?" in str(result1)

    # ── turn 2: captured 'ab' fails validation ──
    result2 = tool.execute(thread_id=tid, user_message="ab", initial_context={})
    s2 = snap(tool, tid)

    assert "Status A set" not in str(result2)
    assert "Status B set" not in str(result2)

    assert s2["_status"] == "collect_status_collecting"  # still collecting
    assert s2.get("status") is None                       # cleared after validation failure
    assert s2["_validation_errors"] == {
        "status": {"value": "ab", "error": "Status must be at least 3 characters"}
    }
    assert s2["_node_execution_order"] == []
    assert s2["_collector_nodes"] == {}
    # 4 messages: assistant(prompt) + user + assistant(capture) + assistant(error)
    assert len(s2["_conversations"][PM_CONV_KEY]) == 4
    assert s2["_pending_prompt"] is not None
    assert "Status must be at least 3 characters" in s2["_pending_prompt"]["text"]

    # ── turn 3: captured 'abc' passes ──
    result3 = tool.execute(thread_id=tid, user_message="abc", initial_context={})
    s3 = snap(tool, tid)

    assert "Status A set" in str(result3)

    assert s3["status"] == "abc"
    assert s3["_status"] == "collect_status_outcome_a"
    assert s3["_outcome_id"] == "outcome_a"
    assert s3["_validation_errors"] == {}                 # cleared after success
    assert s3["_messages"] == ["✓ Status collected: abc"]
    assert s3["_node_execution_order"] == ["collect_status"]
    assert s3["_collector_nodes"] == PM_COLLECTOR_NODES
    # 6 messages: assistant(T1) + user(T2) + assistant(T2cap) + assistant(T2err) + user(T3) + assistant(T3cap)
    assert len(s3["_conversations"][PM_CONV_KEY]) == 6
    assert s3.get("_pending_prompt") is None
    assert s3["error"] is None
    assert respx.calls.call_count == 3


# ── Group 5: PM Context Extraction (agent extracts value on Turn 1) ───────────
# When there is no initial_message in YAML and the LLM's first response already
# contains a transition pattern (extracted from prior workflow context), the node
# must complete WITHOUT a Turn 2 and route to the CORRECT transition — not always
# the first one.


@respx.mock
def test_pm_ce1_context_extraction_routes_to_second_transition():
    """PM + no pre-pop + no initial_message: LLM immediately returns 'STATUS_B: idle'
    on Turn 1 (context extraction).

    Expected: completes in 1 LLM call, routes to outcome_b (2nd transition).
    Bug (if present): _check_context_extraction strips prefix → stores 'idle';
    _handle_pre_populated_field can't find 'STATUS_B:' in 'idle' → falls back
    to transitions[0] → outcome_a (wrong).
    """
    respx.post(FAKE_LLM_COMPLETIONS).mock(
        return_value=llm_text_response("STATUS_B: idle")
    )

    tool = make_tool("pm_multi_transition.yaml")
    tid = str(uuid.uuid4())

    result = tool.execute(thread_id=tid, initial_context={})
    s = snap(tool, tid)

    assert "Status B set" in str(result)
    assert "Status A set" not in str(result)

    assert s["status"] == "idle"
    assert s["_status"] == "collect_status_outcome_b"
    assert s["_outcome_id"] == "outcome_b"
    assert s["_node_execution_order"] == ["collect_status"]
    assert s["_node_field_map"]["collect_status"] == "status"
    assert s["_validation_errors"] == {}
    assert s["_collector_nodes"] == PM_COLLECTOR_NODES
    # context extraction path: no messages appended to conversation
    assert PM_CONV_KEY in s["_conversations"]
    assert s["_conversations"][PM_CONV_KEY] == []
    assert s.get("_pending_prompt") is None
    assert s["error"] is None
    assert respx.calls.call_count == 1


@respx.mock
def test_pm_ce2_context_extraction_with_validator_routes_to_second_transition():
    """PM + validator + no pre-pop + no initial_message: LLM immediately returns
    'STATUS_B: abc' on Turn 1 (context extraction).

    validate_status receives 'abc' (3 chars, exactly at limit) → passes.
    Expected: routes to outcome_b (2nd transition) in 1 LLM call.
    """
    respx.post(FAKE_LLM_COMPLETIONS).mock(
        return_value=llm_text_response("STATUS_B: abc")
    )

    tool = make_tool("pm_multi_transition_validator.yaml")
    tid = str(uuid.uuid4())

    result = tool.execute(thread_id=tid, initial_context={})
    s = snap(tool, tid)

    assert "Status B set" in str(result)
    assert "Status A set" not in str(result)

    assert s["status"] == "abc"
    assert s["_status"] == "collect_status_outcome_b"
    assert s["_outcome_id"] == "outcome_b"
    assert s["_node_execution_order"] == ["collect_status"]
    assert s["_validation_errors"] == {}
    assert s["_collector_nodes"] == PM_COLLECTOR_NODES
    assert PM_CONV_KEY in s["_conversations"]
    assert s["_conversations"][PM_CONV_KEY] == []
    assert s.get("_pending_prompt") is None
    assert s["error"] is None
    assert respx.calls.call_count == 1


@respx.mock
def test_pm_ce3_context_extraction_validator_failure_then_agent_captures():
    """PM + validator + no pre-pop: LLM immediately returns 'STATUS_B: ab' on Turn 1
    (context extraction), but 'ab' (2 chars) FAILS validate_status.

    _check_context_extraction detects the pattern, strips → 'ab', validates → FAILS.
    Result: validation error shown as prompt (1 LLM call for extraction attempt).
    Turn 2: agent captures 'STATUS_A: abc' → 'abc' (3 chars) passes → outcome_a (call 2).
    """
    responses = iter([
        llm_text_response("STATUS_B: ab"),      # turn 1: extraction attempt → validator fails
        llm_text_response("STATUS_A: abc"),     # turn 2: agent captures valid value → outcome_a
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("pm_multi_transition_validator.yaml")
    tid = str(uuid.uuid4())

    # ── turn 1: context extraction validator failure ──
    result1 = tool.execute(thread_id=tid, initial_context={})

    s1 = snap(tool, tid)
    # Expected: validation error shown as re-prompt, still collecting
    assert "Status A set" not in str(result1)
    assert "Status B set" not in str(result1)
    assert "Status must be at least 3 characters" in str(result1)

    assert s1["_status"] == "collect_status_collecting"
    assert s1.get("status") is None            # cleared after validation failure
    assert s1["_validation_errors"] == {
        "status": {"value": "ab", "error": "Status must be at least 3 characters"}
    }
    assert s1["_node_execution_order"] == []
    assert s1["_collector_nodes"] == {}
    # 2 messages: user(pre-pop attempt str({'status': None})) + assistant(validation error)
    # _handle_pre_populated_field is called with the CE-extracted value ('ab'),
    # validation fails, field is cleared to None, then conversation gets:
    #   [user: "{'status': None}", assistant: "{text: error, ...}"]
    assert len(s1["_conversations"][PM_CONV_KEY]) == 2
    assert s1["_conversations"][PM_CONV_KEY][0]["role"] == "user"
    assert s1["_conversations"][PM_CONV_KEY][1]["role"] == "assistant"
    # pending_prompt holds the validation error for the next user turn
    assert s1["_pending_prompt"] is not None
    assert "Status must be at least 3 characters" in s1["_pending_prompt"]["text"]
    assert respx.calls.call_count == 1

    # ── turn 2: user sends "abc", agent captures STATUS_A: abc ──
    result2 = tool.execute(thread_id=tid, user_message="abc", initial_context={})
    s2 = snap(tool, tid)

    assert "Status A set" in str(result2)
    assert "Status B set" not in str(result2)

    assert s2["status"] == "abc"
    assert s2["_status"] == "collect_status_outcome_a"
    assert s2["_outcome_id"] == "outcome_a"
    assert s2["_validation_errors"] == {}              # cleared after success
    assert s2["_messages"] == ["✓ Status collected: abc"]
    assert s2["_node_execution_order"] == ["collect_status"]
    assert s2["_collector_nodes"] == PM_COLLECTOR_NODES
    # 4 messages: user(pre-pop) + assistant(error) [from T1] + user(T2) + assistant(capture)
    assert len(s2["_conversations"][PM_CONV_KEY]) == 4
    assert s2.get("_pending_prompt") is None
    assert s2["error"] is None
    assert respx.calls.call_count == 2


@respx.mock
def test_pm_ce4_context_extraction_routes_to_first_transition():
    """PM + no pre-pop: LLM immediately returns 'STATUS_A: active' on Turn 1
    (context extraction). Routes to outcome_a (1st transition).
    Confirms symmetry: CE works for both transitions, not just t2.
    """
    respx.post(FAKE_LLM_COMPLETIONS).mock(
        return_value=llm_text_response("STATUS_A: active")
    )

    tool = make_tool("pm_multi_transition.yaml")
    tid = str(uuid.uuid4())

    result = tool.execute(thread_id=tid, initial_context={})
    s = snap(tool, tid)

    assert "Status A set" in str(result)
    assert "Status B set" not in str(result)

    assert s["status"] == "active"
    assert s["_status"] == "collect_status_outcome_a"
    assert s["_outcome_id"] == "outcome_a"
    assert s["_node_execution_order"] == ["collect_status"]
    assert s["_validation_errors"] == {}
    assert s["_collector_nodes"] == PM_COLLECTOR_NODES
    assert s["_conversations"][PM_CONV_KEY] == []
    assert s.get("_pending_prompt") is None
    assert s["error"] is None
    assert respx.calls.call_count == 1


# ── Group 7: Max Attempts (PM) ────────────────────────────────────────────────


@respx.mock
def test_pm_max_attempts():
    """PM + retry_limit=2: 3 turns with no pattern matches → max_attempts.

    retry_limit=2 → max_attempts=2 user messages.
    Turn 1: LLM generates prompt (call 1). User count in conv = 0.
    Turn 2: LLM returns no-match, user count = 1 < 2 → continue (call 2).
    Turn 3: LLM returns no-match, user count = 2 >= 2 → max_attempts (call 3).

    Expected final state:
      _status = "collect_status_max_attempts"
      status  = None (never successfully captured)
      _messages = [max_attempts_message]
      No node registered (workflow did not complete successfully)
    """
    responses = iter([
        llm_text_response("What is your status?"),       # turn 1: prompt
        llm_text_response("I didn't catch that."),       # turn 2: no-match
        llm_text_response("Still didn't catch that."),   # turn 3: no-match → max
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("pm_multi_transition.yaml")
    tid = str(uuid.uuid4())

    # ── turn 1: generates prompt ──
    result1 = tool.execute(thread_id=tid, initial_context={})
    assert "What is your status?" in str(result1)

    s1 = snap(tool, tid)
    assert s1["_status"] == "collect_status_collecting"
    assert s1.get("status") is None
    assert s1["_node_execution_order"] == []
    assert s1["_collector_nodes"] == {}
    assert len(s1["_conversations"][PM_CONV_KEY]) == 1
    assert s1["_pending_prompt"] is not None
    assert s1["_pending_prompt"]["text"] == "What is your status?"

    # ── turn 2: no-match → user_count = 1, not yet max ──
    result2 = tool.execute(thread_id=tid, user_message="hmm", initial_context={})
    s2 = snap(tool, tid)

    assert "Status A set" not in str(result2)
    assert "Status B set" not in str(result2)

    assert s2["_status"] == "collect_status_collecting"
    assert s2.get("status") is None
    assert s2["_node_execution_order"] == []
    assert s2["_collector_nodes"] == {}
    assert s2["_validation_errors"] == {}
    # 3 messages: assistant(prompt) + user + assistant(no-match)
    assert len(s2["_conversations"][PM_CONV_KEY]) == 3
    assert s2["_pending_prompt"] is not None
    assert s2["_pending_prompt"]["text"] == "I didn't catch that."

    # ── turn 3: no-match → user_count = 2 >= max → max_attempts ──
    result3 = tool.execute(thread_id=tid, user_message="dunno", initial_context={})
    s3 = snap(tool, tid)

    # Expected: max_attempts message in result
    assert "having trouble understanding" in str(result3).lower()
    assert "Status A set" not in str(result3)
    assert "Status B set" not in str(result3)

    assert s3["_status"] == "collect_status_max_attempts"
    assert s3.get("status") is None               # never captured
    assert s3["_validation_errors"] == {}
    assert s3["_node_execution_order"] == []      # never registered
    assert s3["_node_field_map"] == {}
    assert s3["_collector_nodes"] == {}           # never registered
    assert s3["_messages"] == [
        "I'm having trouble understanding your status. Please contact customer service for assistance."
    ]
    assert s3.get("_pending_prompt") is None      # cleared when entering Turn 3 loop
    assert s3["error"] is None
    # 5 messages: assistant(T1) + user(T2) + assistant(T2) + user(T3) + assistant(T3)
    assert len(s3["_conversations"][PM_CONV_KEY]) == 5
    assert respx.calls.call_count == 3


# ── Group 8: Edge Cases ───────────────────────────────────────────────────────


@respx.mock
def test_pm_edge_prepop_empty_value_after_strip():
    """PM + pre-pop 'STATUS_A: ' (pattern matches but value is empty after stripping).

    _handle_pre_populated_field PM path:
      "STATUS_A:" found in "STATUS_A: " → clean_value = "".strip() = "".
      _store_field_value called with "" → field stored as empty string.
      next_step = "outcome_a" still set (transition matched).

    Expected: routes to outcome_a, field stored as empty string.
    """
    tool = make_tool("pm_multi_transition.yaml")
    tid = str(uuid.uuid4())

    result = tool.execute(thread_id=tid, initial_context={"status": "STATUS_A: "})
    s = snap(tool, tid)

    assert "Status A set" in str(result)
    assert "Status B set" not in str(result)

    # Field stored as empty string (pattern stripped, nothing after prefix)
    assert s["status"] == ""

    assert s["_status"] == "collect_status_outcome_a"
    assert s["_outcome_id"] == "outcome_a"
    assert s["_node_execution_order"] == ["collect_status"]
    assert s["_messages"] == []
    assert s["_validation_errors"] == {}
    assert s["_collector_nodes"] == PM_COLLECTOR_NODES
    assert s["_conversations"][PM_CONV_KEY] == []
    assert s.get("_pending_prompt") is None
    assert s["error"] is None
    assert respx.calls.call_count == 0


# ── Group 14: PM OPTIONS_DATA marker ─────────────────────────────────────────


@respx.mock
def test_od_1_options_data_in_prompt_extracted_to_pending_prompt():
    """PM: agent prompt includes OPTIONS_DATA marker → options/is_selectable extracted.

    The OPTIONS_DATA marker is stripped from the conversational text and
    parsed into options/is_selectable stored in _pending_prompt and the
    conversation message content.

    Uses pm_multi_transition.yaml (no changes to fixture needed).
    """
    OPTIONS = [{"text": "Active", "subtext": ""}, {"text": "Inactive", "subtext": ""}]
    # OPTIONS_DATA: (with colon) is the correct ResponseMarkers.OPTIONS_DATA marker
    agent_prompt = (
        "What is your status?\n"
        f'OPTIONS_DATA: {{"options": {json.dumps(OPTIONS)}, "is_selectable": true}}'
    )

    respx.post(FAKE_LLM_COMPLETIONS).mock(return_value=llm_text_response(agent_prompt))

    tool = make_tool("pm_multi_transition.yaml")
    tid = str(uuid.uuid4())

    result1 = tool.execute(thread_id=tid, initial_context={})
    s1 = snap(tool, tid)

    # Prompt text is the part BEFORE OPTIONS_DATA (stripped)
    assert "What is your status?" in str(result1)
    # OPTIONS_DATA marker itself should NOT appear in the output
    assert "OPTIONS_DATA" not in str(result1)

    # _pending_prompt has extracted options and is_selectable
    assert s1["_pending_prompt"] is not None
    assert s1["_pending_prompt"]["text"] == "What is your status?"
    assert s1["_pending_prompt"]["options"] == OPTIONS
    assert s1["_pending_prompt"]["is_selectable"] is True

    # Conversation message content is JSON with options and is_selectable
    assert len(s1["_conversations"][PM_CONV_KEY]) == 1
    conv_content = json.loads(s1["_conversations"][PM_CONV_KEY][0]["content"])
    assert conv_content["text"] == "What is your status?"
    assert conv_content["options"] == OPTIONS
    assert conv_content["is_selectable"] is True

    assert s1["_status"] == "collect_status_collecting"
    assert respx.calls.call_count == 1


@respx.mock
def test_od_2_options_data_in_capture_response_stripped_field_captured():
    """PM: agent capture response contains OPTIONS_DATA → marker stripped, field captured.

    The agent includes OPTIONS_DATA after the pattern, but _process_transitions
    runs _extract_options_from_response first so the cleaned response is used
    for pattern matching. The field is correctly captured and the workflow completes.
    """
    OPTIONS = [{"text": "Reset", "subtext": ""}]
    agent_prompt = "What is your status?"
    # OPTIONS_DATA: (with colon) is the correct marker
    agent_capture = (
        "STATUS_A: active\n"
        f'OPTIONS_DATA: {{"options": {json.dumps(OPTIONS)}, "is_selectable": false}}'
    )

    responses = iter([
        llm_text_response(agent_prompt),
        llm_text_response(agent_capture),
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("pm_multi_transition.yaml")
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    result2 = tool.execute(thread_id=tid, user_message="active", initial_context={})
    s2 = snap(tool, tid)

    # Capture succeeded despite OPTIONS_DATA being in the response
    assert "Status A set" in str(result2)
    assert s2["status"] == "active"
    assert s2["_status"] == "collect_status_outcome_a"
    assert s2["_outcome_id"] == "outcome_a"
    assert s2["_validation_errors"] == {}
    assert s2["_collector_nodes"] == PM_COLLECTOR_NODES

    # Completion message uses the clean value (no OPTIONS_DATA)
    assert s2["_messages"] == ["✓ Status collected: active"]

    assert s2.get("_pending_prompt") is None
    assert s2["error"] is None
    assert respx.calls.call_count == 2


@respx.mock
def test_od_3_options_data_invalid_json_falls_back_gracefully():
    """PM: OPTIONS_DATA value cannot be parsed as JSON → fallback: full message used as prompt.

    _extract_options_from_response calls convert_to_dict; if that returns a str
    (parse failure), the full conversational_text is used and options are NOT updated.
    """
    # OPTIONS_DATA with malformed JSON value (string result from convert_to_dict)
    agent_prompt = "What is your status? OPTIONS_DATA not-valid-json"

    respx.post(FAKE_LLM_COMPLETIONS).mock(return_value=llm_text_response(agent_prompt))

    tool = make_tool("pm_multi_transition.yaml")
    tid = str(uuid.uuid4())

    result1 = tool.execute(thread_id=tid, initial_context={})
    s1 = snap(tool, tid)

    # Workflow still pauses for user input (prompt returned)
    assert InterruptType.USER_INPUT in str(result1)
    # Default options: [] (not updated because parse failed)
    assert s1["_pending_prompt"] is not None
    assert s1["_pending_prompt"]["options"] == []
    assert s1["_pending_prompt"]["is_selectable"] is False

    assert s1["_status"] == "collect_status_collecting"
    assert respx.calls.call_count == 1
