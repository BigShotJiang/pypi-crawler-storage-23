"""
First-entry with user_message tests for collect_input_with_agent.

Covers the case where the caller passes user_message= on the very first execute()
call (fresh workflow, state.next is falsy). Without initial_message in the YAML,
the node should treat user_msg as a direct response -- call the LLM exactly ONCE,
and correctly handle whatever the LLM returns (OOS, capture, no-match).

Groups covered:
  Group 22: PM and SO first-entry with user_message (6 tests)

Coverage gaps (not in this file):
  - OOS tests without first-entry user_message -> test_out_of_scope.py
  - IC tests -> test_intent_change.py
  - Multi-field SO -> test_so_multifield.py
  - PM/SO basic transitions -> test_pm_collection.py / test_so_collection.py
"""

import uuid

import respx

from soprano_sdk.core.constants import InterruptType

from tests.helpers import (
    FAKE_LLM_COMPLETIONS,
    llm_structured_response,
    llm_text_response,
    make_tool,
    snap,
)

SO_OOS_COLLECTOR_NODES = {"collect_choice": "Collect user choice"}


# ── Group 22: First-entry with user_message ───────────────────────────────────


@respx.mock
def test_pm_first_entry_oos_with_user_message():
    """OOS on first entry: user_message provided on T1, LLM responds OUT_OF_SCOPE.

    Expected:
    - Exactly 1 LLM call (NOT _generate_prompt + _process_user_response = 2 calls)
    - Result is an OOS interrupt, NOT a USER_INPUT showing raw "OUT_OF_SCOPE: ..." text
    """
    respx.post(FAKE_LLM_COMPLETIONS).mock(
        return_value=llm_text_response("OUT_OF_SCOPE: user wants pizza")
    )

    tool = make_tool("pm_out_of_scope.yaml")
    tid = str(uuid.uuid4())

    result1 = tool.execute(thread_id=tid, user_message="I want pizza", initial_context={})

    assert InterruptType.OUT_OF_SCOPE in str(result1), (
        f"Expected OOS interrupt on first entry, got: {result1!r}"
    )
    assert "pizza" in str(result1)
    assert InterruptType.USER_INPUT not in str(result1), (
        "Should NOT be a USER_INPUT showing raw OUT_OF_SCOPE text"
    )
    assert respx.calls.call_count == 1, (
        f"Expected exactly 1 LLM call, got {respx.calls.call_count}"
    )


@respx.mock
def test_pm_first_entry_captures_with_user_message():
    """Happy path first entry: user_message provided on T1, LLM captures directly.

    Expected:
    - Exactly 1 LLM call
    - Field captured, outcome returned immediately (no intermediate prompt)
    """
    respx.post(FAKE_LLM_COMPLETIONS).mock(
        return_value=llm_text_response("STATUS_A: active")
    )

    tool = make_tool("pm_out_of_scope.yaml")
    tid = str(uuid.uuid4())

    result1 = tool.execute(thread_id=tid, user_message="My status is active", initial_context={})
    s1 = snap(tool, tid)

    assert "Status A set" in str(result1), f"Expected success, got: {result1!r}"
    assert s1["status"] == "active"
    assert s1["_outcome_id"] == "outcome_a"
    assert respx.calls.call_count == 1, (
        f"Expected exactly 1 LLM call, got {respx.calls.call_count}"
    )


@respx.mock
def test_pm_first_entry_no_match_with_user_message():
    """No match on first entry: user_message provided on T1, LLM can't capture.

    Expected:
    - Exactly 1 LLM call
    - Returns a USER_INPUT re-prompt (still collecting), NOT two prompts
    - The re-prompt text should be from the LLM's response (asking again)
    """
    respx.post(FAKE_LLM_COMPLETIONS).mock(
        return_value=llm_text_response("I didn't understand. What is your status?")
    )

    tool = make_tool("pm_out_of_scope.yaml")
    tid = str(uuid.uuid4())

    result1 = tool.execute(thread_id=tid, user_message="hmm", initial_context={})

    assert InterruptType.USER_INPUT in str(result1), f"Expected re-prompt, got: {result1!r}"
    assert "understand" in str(result1), "Re-prompt text should be LLM's response"
    assert respx.calls.call_count == 1, (
        f"Expected exactly 1 LLM call, got {respx.calls.call_count}"
    )


@respx.mock
def test_so_first_entry_oos_with_user_message():
    """SO OOS on first entry: user_message provided on T1, LLM responds with out_of_scope.

    Expected:
    - Exactly 1 LLM call (NOT _generate_prompt + _process_user_response = 2 calls)
    - Result is an OOS interrupt, NOT a USER_INPUT showing raw out_of_scope content
    """
    respx.post(FAKE_LLM_COMPLETIONS).mock(
        return_value=llm_structured_response({
            "bot_response": None,
            "captured": False,
            "choice_value": None,
            "out_of_scope": "user asked about weather forecast",
        })
    )

    tool = make_tool("so_out_of_scope.yaml")
    tid = str(uuid.uuid4())

    result1 = tool.execute(thread_id=tid, user_message="what's the weather?", initial_context={})

    assert InterruptType.OUT_OF_SCOPE in str(result1), (
        f"Expected OOS interrupt on first entry, got: {result1!r}"
    )
    assert "weather" in str(result1)
    assert InterruptType.USER_INPUT not in str(result1), (
        "Should NOT be a USER_INPUT showing raw out_of_scope content"
    )
    assert respx.calls.call_count == 1, (
        f"Expected exactly 1 LLM call, got {respx.calls.call_count}"
    )


@respx.mock
def test_so_first_entry_captures_with_user_message():
    """SO happy path first entry: user_message provided on T1, LLM captures directly.

    Expected:
    - Exactly 1 LLM call
    - Field captured, outcome returned immediately (no intermediate prompt)
    """
    respx.post(FAKE_LLM_COMPLETIONS).mock(
        return_value=llm_structured_response({
            "bot_response": None,
            "captured": True,
            "choice_value": "option_a",
            "options": None,
            "is_selectable": None,
        })
    )

    tool = make_tool("so_multi_transition.yaml")
    tid = str(uuid.uuid4())

    result1 = tool.execute(thread_id=tid, user_message="option_a", initial_context={})
    s1 = snap(tool, tid)

    assert "Option A selected" in str(result1), f"Expected success, got: {result1!r}"
    assert s1["_outcome_id"] == "outcome_a"
    assert s1["_status"] == "collect_choice_outcome_a"
    assert s1["choice_data"] is not None
    assert s1["choice_data"].get("choice_value") == "option_a"
    assert s1["_collector_nodes"] == SO_OOS_COLLECTOR_NODES
    # First-entry CE path (user_msg -> _check_context_extraction -> _handle_pre_populated_field)
    # does NOT populate _messages -- same as pre-pop. Only T2+ agent-driven captures do.
    assert s1["_messages"] == []
    assert respx.calls.call_count == 1, (
        f"Expected exactly 1 LLM call, got {respx.calls.call_count}"
    )


@respx.mock
def test_so_first_entry_no_match_with_user_message():
    """SO no match on first entry: user_message provided on T1, LLM can't capture.

    Expected:
    - Exactly 1 LLM call
    - Returns a USER_INPUT re-prompt (still collecting), NOT two prompts
    - The re-prompt text should be the bot_response from the LLM's response
    """
    respx.post(FAKE_LLM_COMPLETIONS).mock(
        return_value=llm_structured_response({
            "bot_response": "Please choose option_a or option_b.",
            "captured": False,
            "choice_value": None,
            "options": None,
            "is_selectable": None,
        })
    )

    tool = make_tool("so_multi_transition.yaml")
    tid = str(uuid.uuid4())

    result1 = tool.execute(thread_id=tid, user_message="I don't know", initial_context={})

    assert InterruptType.USER_INPUT in str(result1), f"Expected re-prompt, got: {result1!r}"
    assert "Please choose option_a or option_b." in str(result1)

    s1 = snap(tool, tid)
    assert s1.get("choice_data") is None
    assert s1["_status"] == "collect_choice_collecting"
    assert s1.get("_outcome_id") is None
    assert s1["_collector_nodes"] == {}
    assert s1["_pending_prompt"] is not None
    assert s1["_pending_prompt"]["text"] == "Please choose option_a or option_b."
    assert respx.calls.call_count == 1, (
        f"Expected exactly 1 LLM call, got {respx.calls.call_count}"
    )
