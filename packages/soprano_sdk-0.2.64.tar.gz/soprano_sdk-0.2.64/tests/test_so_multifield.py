"""
Structured Output (SO) multi-field collection tests — basic multi-field, boolean
transitions, partial pre-population, partial data accumulation.

Groups
  9.  Multi-field SO                (3 tests)  — so_multi_field.yaml / so_multi_field_validator.yaml
  15. SO Boolean Transition         (4 tests)  — so_bool_transition.yaml (captured=true/false/null)
  16. SO Boolean Pre-populated      (2 tests)  — pre-pop both fields
  17. SO Boolean Partial pre-pop    (3 tests)  — partial pre-pop + multi-turn paths
  23. SO Partial Data               (10 tests) — so_partial_data.yaml

── Coverage Gaps ──
  - PM multi-field: Multi-field collection only tested in SO mode
  - PM boolean transitions: Boolean value matching only tested in SO
  - Multi-field + OOS/IC: OOS/IC during multi-field collection not tested
  - Partial data + OOS/IC: OOS/IC interrupting partial data accumulation not tested
"""

import uuid

import respx

from soprano_sdk.core.constants import InterruptType
from tests.helpers import (
    FAKE_LLM_COMPLETIONS,
    llm_structured_response,
    make_tool,
    snap,
)

# ── Conversation / collector constants ────────────────────────────────────────

MF_CONV_KEY = "first_name_conversation"       # multi-field: primary_field = first_name
MF_COLLECTOR_NODES = {"collect_names": "Collect user's full name"}

BOOL_CONV_KEY = "captured_conversation"       # multi-field: primary_field = captured
BOOL_COLLECTOR_NODES = {"collect_form": "Collect form data"}

PD_CONV_KEY = "profile_conversation"
PD_COLLECTOR_NODES = {"collect_profile": "Collect the user's profile"}


def get_sub_field(field_details, primary, sub_field):
    """Extract a sub-field value from structured field_details."""
    for entry in field_details:
        if entry["name"] == primary:
            if isinstance(entry["value"], list):
                for sf in entry["value"]:
                    if sf["name"] == sub_field:
                        return sf["value"]
    return "NOT_FOUND"


# ── Group 9: Multi-field SO ───────────────────────────────────────────────────


@respx.mock
def test_mf_t1_prepop_both_fields_direct_next():
    """Multi-field SO + both fields pre-populated → immediate success, 0 LLM calls.

    Verifies:
    - Both fields stored in state
    - _node_field_map stores a LIST (not a string) for multi-field steps
    - _messages == [] (pre-pop path does not call _complete_collection)
    - No LLM HTTP request issued
    """
    tool = make_tool("so_multi_field.yaml")
    tid = str(uuid.uuid4())

    result = tool.execute(
        thread_id=tid,
        initial_context={"first_name": "John", "last_name": "Doe"},
    )
    s = snap(tool, tid)

    # ── output ──
    assert "Names collected" in str(result)

    # ── both fields stored ──
    assert s["first_name"] == "John"
    assert s["last_name"] == "Doe"

    # ── correct transition and outcome ──
    assert s["_status"] == "collect_names_names_collected"
    assert s["_outcome_id"] == "names_collected"

    # ── _messages: [] for pre-pop (not via _complete_collection) ──
    assert s["_messages"] == []

    # ── validation clean ──
    assert s["_validation_errors"] == {}

    # ── node registration: field map stores a LIST for multi-field ──
    assert s["_node_execution_order"] == ["collect_names"]
    assert s["_node_field_map"]["collect_names"] == ["first_name", "last_name"]
    assert s["_collector_nodes"] == MF_COLLECTOR_NODES

    # ── no conversation messages for pre-pop (empty list) ──
    assert len(s["_conversations"].get(MF_CONV_KEY, [])) == 0

    # ── no pending prompt after completion ──
    assert s.get("_pending_prompt") is None

    # ── no error ──
    assert s["error"] is None

    # ── no LLM calls ──
    assert respx.calls.call_count == 0


@respx.mock
def test_mf_t2_agent_captures_both_fields_in_one_response():
    """Multi-field SO + agent captures both fields in Turn 2 (after prompt on Turn 1).

    Verifies:
    - _node_field_map stores a list
    - _messages uses the multi-field format "✓ Collected: {...}"
    - Conversation has exactly 3 messages (assistant prompt + user + assistant capture)
    - Both fields persisted in state
    """
    responses = iter([
        llm_structured_response({
            "bot_response": "Please tell me your first and last name.",
            "first_name": None, "last_name": None,
        }),
        llm_structured_response({
            "bot_response": None,
            "first_name": "John", "last_name": "Doe",
        }),
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("so_multi_field.yaml")
    tid = str(uuid.uuid4())

    # ── turn 1: generates prompt ──
    result1 = tool.execute(thread_id=tid, initial_context={})
    s1 = snap(tool, tid)

    assert "Please tell me your first and last name." in str(result1)
    assert s1.get("first_name") is None
    assert s1.get("last_name") is None
    assert s1["_status"] == "collect_names_collecting"
    assert s1["_collector_nodes"] == {}
    assert len(s1["_conversations"][MF_CONV_KEY]) == 1
    assert s1["_conversations"][MF_CONV_KEY][0]["role"] == "assistant"
    assert s1["_pending_prompt"] is not None
    assert s1["_pending_prompt"]["text"] == "Please tell me your first and last name."
    assert s1["_pending_prompt"]["options"] == []
    assert s1["_pending_prompt"]["is_selectable"] is False

    # ── turn 2: agent captures both fields ──
    result2 = tool.execute(thread_id=tid, user_message="John Doe", initial_context={})
    s2 = snap(tool, tid)

    assert "Names collected" in str(result2)

    # ── both fields stored ──
    assert s2["first_name"] == "John"
    assert s2["last_name"] == "Doe"

    # ── correct status and outcome ──
    assert s2["_status"] == "collect_names_names_collected"
    assert s2["_outcome_id"] == "names_collected"

    # ── multi-field _messages format ──
    assert len(s2["_messages"]) == 1
    assert "first_name" in s2["_messages"][0]
    assert "last_name" in s2["_messages"][0]
    assert "John" in s2["_messages"][0]
    assert "Doe" in s2["_messages"][0]
    assert s2["_messages"][0].startswith("✓ Collected:")

    # ── validation clean ──
    assert s2["_validation_errors"] == {}

    # ── node registration: field map stores a LIST ──
    assert s2["_node_execution_order"] == ["collect_names"]
    assert s2["_node_field_map"]["collect_names"] == ["first_name", "last_name"]
    assert s2["_collector_nodes"] == MF_COLLECTOR_NODES

    # ── 3 conversation messages: assistant(T1 prompt) + user(T2) + assistant(T2 capture) ──
    assert len(s2["_conversations"][MF_CONV_KEY]) == 3
    assert s2["_conversations"][MF_CONV_KEY][0]["role"] == "assistant"
    assert s2["_conversations"][MF_CONV_KEY][1]["role"] == "user"
    assert s2["_conversations"][MF_CONV_KEY][2]["role"] == "assistant"

    assert s2.get("_pending_prompt") is None
    assert s2["error"] is None
    assert respx.calls.call_count == 2


@respx.mock
def test_mf_t3_validator_fails_first_name_preserves_last_name():
    """Multi-field SO + per-field validator: first_name fails (< 2 chars), last_name kept.

    Uses so_multi_field_validator.yaml which has:
      validators: {first_name: tests.fixtures.validators.validate_first_name}

    Turn 1: agent prompt.
    Turn 2: agent captures first_name='J' (invalid) + last_name='Doe' (valid).
      → first_name cleared, last_name preserved, validation error in state.
    Turn 3: agent captures first_name='John' only; last_name already in state.
      → both fields present → complete collection.
    """
    responses = iter([
        llm_structured_response({
            "bot_response": "What is your first and last name?",
            "first_name": None, "last_name": None,
        }),
        llm_structured_response({
            "bot_response": None,
            "first_name": "J", "last_name": "Doe",
        }),
        llm_structured_response({
            "bot_response": None,
            "first_name": "John", "last_name": None,  # last_name already set in state
        }),
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("so_multi_field_validator.yaml")
    tid = str(uuid.uuid4())

    # ── turn 1: prompt ──
    result1 = tool.execute(thread_id=tid, initial_context={})
    assert "What is your first and last name?" in str(result1)
    s1 = snap(tool, tid)
    assert s1.get("first_name") is None
    assert s1.get("last_name") is None

    # ── turn 2: first_name invalid, last_name valid ──
    result2 = tool.execute(thread_id=tid, user_message="J Doe", initial_context={})
    s2 = snap(tool, tid)

    # Not expected: success with invalid first_name
    assert "Names collected" not in str(result2)

    # first_name cleared by validator, last_name preserved
    assert s2.get("first_name") is None
    assert s2["last_name"] == "Doe"

    # Validation error recorded for first_name only
    assert "first_name" in s2["_validation_errors"]
    assert s2["_validation_errors"]["first_name"]["value"] == "J"
    assert "First name must be at least 2 characters" in s2["_validation_errors"]["first_name"]["error"]
    # last_name NOT in validation errors (it passed)
    assert "last_name" not in s2["_validation_errors"]

    assert s2["_status"] == "collect_names_collecting"
    assert s2["_collector_nodes"] == {}  # not completed yet
    assert s2["_pending_prompt"] is not None
    assert "First name must be at least 2 characters" in s2["_pending_prompt"]["text"]

    # ── turn 3: valid first_name; last_name already in state as 'Doe' ──
    result3 = tool.execute(thread_id=tid, user_message="John", initial_context={})
    s3 = snap(tool, tid)

    assert "Names collected" in str(result3)

    # Both fields now stored
    assert s3["first_name"] == "John"
    assert s3["last_name"] == "Doe"

    assert s3["_status"] == "collect_names_names_collected"
    assert s3["_outcome_id"] == "names_collected"
    assert s3["_validation_errors"] == {}
    assert s3["_collector_nodes"] == MF_COLLECTOR_NODES
    assert s3["_node_field_map"]["collect_names"] == ["first_name", "last_name"]
    assert s3.get("_pending_prompt") is None
    assert s3["error"] is None
    assert respx.calls.call_count == 3


# ── Group 15: SO Boolean Transition ──────────────────────────────────────────


@respx.mock
def test_bool_t1_false_routes_to_outcome_not_captured():
    """SO multi-field: LLM returns captured=false (boolean) → transition to outcome_not_captured.

    Uses fields: [captured, extra] — two separate data fields, transition driven by the
    boolean `captured` field.  This is the core scenario: verifying that a boolean `false`
    value in a structured output field correctly fires the `match: false` transition.

    Turn 1: LLM returns bot_response prompt → GraphInterrupt.
    Turn 2: LLM returns captured=false + extra non-None → transition fires → "Form declined".

    IMPORTANT multi-field constraint: _get_missing_fields treats any field whose state
    value is None as "still missing" — so ALL fields in `fields: [captured, extra]` must
    be non-None before `_find_matching_transition` is called.  If `extra` is None the
    framework loops back asking for more info rather than firing the transition.
    Here we supply `extra="not interested"` so captured=False can match `match: false`.

    NOT expected: collection failure / outcome_captured / any field missing from state.
    """
    responses = iter([
        llm_structured_response({
            "bot_response": "Would you like to submit the form?",
            "captured": None,
            "extra": None,
        }),
        llm_structured_response({
            "bot_response": None,
            "captured": False,
            "extra": "not interested",    # non-None so _get_missing_fields returns []
        }),
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("so_bool_transition.yaml")
    tid = str(uuid.uuid4())

    # Turn 1: prompt returned
    result1 = tool.execute(thread_id=tid, initial_context={})
    s1 = snap(tool, tid)

    assert InterruptType.USER_INPUT in str(result1)
    assert "Would you like to submit the form?" in str(result1)
    assert s1["_status"] == "collect_form_collecting"
    # Multi-field: both individual fields initialised to None
    assert s1.get("captured") is None
    assert s1.get("extra") is None
    assert s1["_pending_prompt"] is not None

    # Turn 2: user declines → captured=False + extra non-None → match: false fires
    result2 = tool.execute(thread_id=tid, user_message="no thanks", initial_context={})
    s2 = snap(tool, tid)

    # ── correct outcome ──
    assert "Form declined" in str(result2)
    assert s2["_outcome_id"] == "outcome_not_captured"
    assert s2["_status"] == "collect_form_outcome_not_captured"

    # ── multi-field: each field stored directly in state (not as a nested dict) ──
    assert s2["captured"] is False
    assert s2["extra"] == "not interested"

    # ── no validation errors ──
    assert s2["_validation_errors"] == {}

    # ── completion message: multi-field format "✓ Collected: {...}" ──
    assert len(s2["_messages"]) == 1
    assert s2["_messages"][0].startswith("✓ Collected:")
    assert "captured" in s2["_messages"][0]

    # ── node bookkeeping: field map is a LIST for multi-field ──
    assert s2["_node_execution_order"] == ["collect_form"]
    assert s2["_node_field_map"]["collect_form"] == ["captured", "extra"]
    assert s2["_collector_nodes"] == BOOL_COLLECTOR_NODES

    # ── conversation: 3 messages (T1 assistant prompt, T2 user, T2 assistant capture) ──
    conv = s2["_conversations"][BOOL_CONV_KEY]
    assert len(conv) == 3
    assert conv[0]["role"] == "assistant"
    assert conv[1]["role"] == "user"
    assert conv[2]["role"] == "assistant"

    assert s2.get("_pending_prompt") is None
    assert s2["error"] is None
    assert respx.calls.call_count == 2


@respx.mock
def test_bool_t1b_false_with_null_extra_loops_not_transitions():
    """SO multi-field: LLM returns captured=false but extra=null → framework loops, NOT transition.

    Documents the multi-field constraint: _get_missing_fields uses `state.get(f) is None`
    for EVERY field in `fields: [captured, extra]`. Even though `captured=False` would
    match `match: false`, the fact that `extra=None` means `extra` is still "missing",
    so the framework defers the transition check and loops back for more input.

    T2 LLM returns captured=False + extra=None (both optional SO fields, but extra unset).
    Expected: result2 is USER_INPUT (still collecting), NOT "Form declined".
    T3 LLM provides extra="no thanks" → now both fields non-None → transition fires.
    """
    responses = iter([
        llm_structured_response({           # T1: prompt
            "bot_response": "Would you like to submit?",
            "captured": None, "extra": None,
        }),
        llm_structured_response({           # T2: captured=False but extra=None → loops
            "bot_response": None,
            "captured": False, "extra": None,
        }),
        llm_structured_response({           # T3: both non-None → transition fires
            "bot_response": None,
            "captured": False, "extra": "declined",
        }),
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("so_bool_transition.yaml")
    tid = str(uuid.uuid4())

    result1 = tool.execute(thread_id=tid, initial_context={})
    assert InterruptType.USER_INPUT in str(result1)

    # T2: captured=False but extra=None → still missing → continues collecting
    result2 = tool.execute(thread_id=tid, user_message="no", initial_context={})
    s2 = snap(tool, tid)
    assert InterruptType.USER_INPUT in str(result2)   # still collecting
    assert "Form declined" not in str(result2)         # transition did NOT fire
    assert s2["_status"] == "collect_form_collecting"
    assert s2["captured"] is False   # partial: captured stored but transition not fired
    assert s2.get("extra") is None       # still missing

    # T3: both non-None → transition fires → outcome_not_captured
    result3 = tool.execute(thread_id=tid, user_message="declined", initial_context={})
    s3 = snap(tool, tid)
    assert "Form declined" in str(result3)
    assert s3["_outcome_id"] == "outcome_not_captured"
    assert s3["captured"] is False
    assert s3["extra"] == "declined"
    assert respx.calls.call_count == 3


@respx.mock
def test_bool_t2_true_routes_to_outcome_captured():
    """SO multi-field: LLM returns captured=true → transition to outcome_captured.

    Symmetry check: confirms the `match: true` branch works alongside `match: false`.

    Turn 1: bot_response prompt.
    Turn 2: captured=true + extra="urgent" → outcome_captured.
    """
    responses = iter([
        llm_structured_response({
            "bot_response": "Would you like to submit?",
            "captured": None,
            "extra": None,
        }),
        llm_structured_response({
            "bot_response": None,
            "captured": True,
            "extra": "urgent",
        }),
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("so_bool_transition.yaml")
    tid = str(uuid.uuid4())

    result1 = tool.execute(thread_id=tid, initial_context={})
    assert InterruptType.USER_INPUT in str(result1)

    result2 = tool.execute(thread_id=tid, user_message="yes please", initial_context={})
    s2 = snap(tool, tid)

    assert "Form submitted" in str(result2)
    assert s2["_outcome_id"] == "outcome_captured"
    assert s2["_status"] == "collect_form_outcome_captured"
    # Both fields stored individually
    assert s2["captured"] is True
    assert s2["extra"] == "urgent"
    assert s2["_node_field_map"]["collect_form"] == ["captured", "extra"]
    assert s2["_validation_errors"] == {}
    assert s2.get("_pending_prompt") is None
    assert s2["error"] is None
    assert respx.calls.call_count == 2


@respx.mock
def test_bool_t3_false_captured_on_first_turn():
    """SO multi-field: LLM returns captured=false immediately on Turn 1 (no bot_response).

    When `captured: false` and `bot_response: null` on the very first LLM call,
    the framework skips any interrupt, stores the fields, and fires `match: false`
    — all within the first execute() call.

    Expected: result1 contains "Form declined" (no USER_INPUT interrupt).
    """
    respx.post(FAKE_LLM_COMPLETIONS).mock(return_value=llm_structured_response({
        "bot_response": None,
        "captured": False,
        "extra": "changed my mind",
    }))

    tool = make_tool("so_bool_transition.yaml")
    tid = str(uuid.uuid4())

    result1 = tool.execute(thread_id=tid, initial_context={})
    s1 = snap(tool, tid)

    # No interrupt — outcome returned immediately on Turn 1
    assert InterruptType.USER_INPUT not in str(result1)
    assert "Form declined" in str(result1)
    assert s1["_outcome_id"] == "outcome_not_captured"
    assert s1["_status"] == "collect_form_outcome_not_captured"
    assert s1["captured"] is False
    assert s1["extra"] == "changed my mind"
    assert s1["_validation_errors"] == {}
    assert s1.get("_pending_prompt") is None
    assert s1["error"] is None
    assert respx.calls.call_count == 1


@respx.mock
def test_bool_t4_null_captured_causes_max_attempts():
    """SO multi-field: LLM always returns captured=null → no transition match → max_attempts.

    `None != False` and `None != True` so neither transition fires when captured=None.
    After retry_limit (2) user messages, `_handle_max_attempts` is triggered.

    Key distinction: `captured: null` must NOT be treated as `captured: false`.
    This guards against any implicit falsy-routing of None.

    Note: `_handle_max_attempts` sets `_status = "{step_id}_max_attempts"` and
    returns without routing to an outcome node — so `_outcome_id` is NOT set.
    """
    responses = iter([
        llm_structured_response({          # Turn 1: prompt
            "bot_response": "Do you want to submit?",
            "captured": None,
            "extra": None,
        }),
        llm_structured_response({          # Turn 2: bot_response again (1st user message)
            "bot_response": "Please answer yes or no.",
            "captured": None,
            "extra": None,
        }),
        llm_structured_response({          # Turn 3: 2nd user message → max_attempts fires
            "bot_response": "I still need your answer.",
            "captured": None,
            "extra": None,
        }),
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("so_bool_transition.yaml")
    tid = str(uuid.uuid4())

    result1 = tool.execute(thread_id=tid, initial_context={})
    assert InterruptType.USER_INPUT in str(result1)

    result2 = tool.execute(thread_id=tid, user_message="maybe", initial_context={})
    assert InterruptType.USER_INPUT in str(result2)   # still collecting after 1 user msg

    result3 = tool.execute(thread_id=tid, user_message="still unsure", initial_context={})
    s3 = snap(tool, tid)

    # ── max attempts reached — neither outcome fired ──
    assert "Form submitted" not in str(result3)
    assert "Form declined" not in str(result3)

    # ── fields never captured ──
    assert s3.get("captured") is None
    assert s3.get("extra") is None

    # ── _handle_max_attempts sets status but does NOT route to an outcome node ──
    assert s3["_status"] == "collect_form_max_attempts"
    assert s3.get("_outcome_id") is None   # no outcome node reached

    assert s3["_validation_errors"] == {}
    assert s3.get("_pending_prompt") is None
    assert s3["error"] is None
    assert respx.calls.call_count == 3


# ── Group 16: SO Boolean Transition - Pre-populated (both fields) ─────────────


@respx.mock
def test_bool_pp1_false_both_prepop_routes_to_not_captured():
    """Pre-populated captured=False + extra → outcome_not_captured, zero LLM calls.

    Exercises `_handle_pre_populated_field` SO multi-field path.
    `response_dict = {"captured": False, "extra": "..."}` →
    `_find_matching_transition` sees captured=False, match: false fires.

    Regression guard: if the transition guard were `not match_value` instead of
    `match_value is None`, False would be treated the same as None and this test
    would route to the fallback outcome_captured instead.
    """
    tool = make_tool("so_bool_transition.yaml")
    tid = str(uuid.uuid4())

    result = tool.execute(
        thread_id=tid,
        initial_context={"captured": False, "extra": "declined on entry"},
    )
    s = snap(tool, tid)

    assert "Form declined" in str(result)
    assert s["_outcome_id"] == "outcome_not_captured"
    assert s["_status"] == "collect_form_outcome_not_captured"

    assert s["captured"] is False
    assert s["extra"] == "declined on entry"

    # Pre-pop path does not call _complete_collection → _messages == []
    assert s["_messages"] == []

    # No conversation turns for pre-pop path
    assert len(s["_conversations"].get(BOOL_CONV_KEY, [])) == 0

    assert s["_validation_errors"] == {}
    assert s["_node_execution_order"] == ["collect_form"]
    assert s["_node_field_map"]["collect_form"] == ["captured", "extra"]
    assert s["_collector_nodes"] == BOOL_COLLECTOR_NODES
    assert s.get("_pending_prompt") is None
    assert s["error"] is None

    # Zero LLM calls
    assert respx.calls.call_count == 0


@respx.mock
def test_bool_pp2_true_both_prepop_routes_to_captured():
    """Pre-populated captured=True + extra → outcome_captured, zero LLM calls.

    Symmetric with PP1: confirms match: true fires in the pre-pop path.
    """
    tool = make_tool("so_bool_transition.yaml")
    tid = str(uuid.uuid4())

    result = tool.execute(
        thread_id=tid,
        initial_context={"captured": True, "extra": "confirmed on entry"},
    )
    s = snap(tool, tid)

    assert "Form submitted" in str(result)
    assert s["_outcome_id"] == "outcome_captured"
    assert s["_status"] == "collect_form_outcome_captured"

    assert s["captured"] is True
    assert s["extra"] == "confirmed on entry"

    assert s["_messages"] == []
    assert len(s["_conversations"].get(BOOL_CONV_KEY, [])) == 0
    assert s["_validation_errors"] == {}
    assert s["_node_execution_order"] == ["collect_form"]
    assert s["_node_field_map"]["collect_form"] == ["captured", "extra"]
    assert s.get("_pending_prompt") is None
    assert s["error"] is None
    assert respx.calls.call_count == 0


# ── Group 17: SO Boolean Transition - Partial pre-pop + multi-turn paths ──────


@respx.mock
def test_bool_pp3_captured_false_only_partial_agent_collects_extra():
    """Partial pre-pop: only captured=False in initial_context; extra missing.

    `_is_field_pre_populated` = False (extra=None) → normal LLM path taken.
    T1 LLM generates a prompt asking for extra.  T2 LLM submits captured=False
    + extra → match: false fires.

    Verifies that the pre-populated captured=False from initial_context is
    preserved in state (via invoke_state injection and _apply_context_value)
    even when the LLM collection path is taken.
    """
    responses = iter([
        llm_structured_response({
            "bot_response": "Please provide any extra information.",
            "captured": None,
            "extra": None,
        }),
        llm_structured_response({
            "bot_response": None,
            "captured": False,
            "extra": "none needed",
        }),
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("so_bool_transition.yaml")
    tid = str(uuid.uuid4())

    # Fresh start: captured=False pre-populated, extra missing → normal LLM flow
    result1 = tool.execute(thread_id=tid, initial_context={"captured": False})
    s1 = snap(tool, tid)

    assert InterruptType.USER_INPUT in str(result1)
    assert "Please provide any extra information." in str(result1)
    # captured=False from initial_context persists in checkpoint
    assert s1["captured"] is False
    assert s1.get("extra") is None
    assert s1["_status"] == "collect_form_collecting"

    result2 = tool.execute(thread_id=tid, user_message="no extra info", initial_context={})
    s2 = snap(tool, tid)

    assert "Form declined" in str(result2)
    assert s2["_outcome_id"] == "outcome_not_captured"
    assert s2["captured"] is False
    assert s2["extra"] == "none needed"
    assert s2["_validation_errors"] == {}
    assert s2.get("_pending_prompt") is None
    assert s2["error"] is None
    assert respx.calls.call_count == 2


@respx.mock
def test_bool_partial_bot_response_stores_false_t2_t3_fires():
    """T2 bot_response path stores captured=False; T3 submits → outcome_not_captured.

    In `_handle_structured_output_transition` bot_response path (line 1147),
    `_store_field_values(state, agent_response)` is called before returning.
    `False is not None` → captured=False IS stored even though bot_response
    is also present (agent is still asking for more info).

    Turn 1: opening prompt.
    Turn 2 (bot_response + captured=False stored): agent asks follow-up.
    Turn 3: agent submits captured=False + extra → match: false fires.

    Key assertion: after T2, s2["captured"] is False (stored via bot_response path).
    """
    responses = iter([
        llm_structured_response({           # T1: opening prompt
            "bot_response": "Do you want to submit the form?",
            "captured": None,
            "extra": None,
        }),
        llm_structured_response({           # T2: bot_response + captures False
            "bot_response": "Got it — you want to decline. Any extra comments?",
            "captured": False,
            "extra": None,
        }),
        llm_structured_response({           # T3: final submission
            "bot_response": None,
            "captured": False,
            "extra": "no comments",
        }),
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("so_bool_transition.yaml")
    tid = str(uuid.uuid4())

    result1 = tool.execute(thread_id=tid, initial_context={})
    assert InterruptType.USER_INPUT in str(result1)
    assert "Do you want to submit the form?" in str(result1)

    # T2: LLM returns bot_response + captured=False → captured stored in state
    result2 = tool.execute(thread_id=tid, user_message="I want to decline", initial_context={})
    s2 = snap(tool, tid)

    assert InterruptType.USER_INPUT in str(result2)
    assert "Got it" in str(result2)
    # captured=False stored during bot_response path (False is not None)
    assert s2["captured"] is False
    assert s2.get("extra") is None       # extra not yet provided
    assert s2["_status"] == "collect_form_collecting"

    # T3: submit both → fires match: false
    result3 = tool.execute(thread_id=tid, user_message="no comments", initial_context={})
    s3 = snap(tool, tid)

    assert "Form declined" in str(result3)
    assert s3["_outcome_id"] == "outcome_not_captured"
    assert s3["captured"] is False
    assert s3["extra"] == "no comments"
    assert s3["_validation_errors"] == {}
    assert s3.get("_pending_prompt") is None
    assert s3["error"] is None
    assert respx.calls.call_count == 3


@respx.mock
def test_bool_extra_stored_first_captured_false_second():
    """T2 stores extra (captured=None); T3 provides captured=False → fires.

    Reverse of test_bool_t1b (which stored captured first, extra second).
    Documents that field-by-field accumulation works regardless of arrival order.

    After T2: state["extra"]="some extra info", state["captured"]=None.
    `_get_missing_fields` → ["captured"] → still collecting.
    After T3: both fields non-None in agent_response → match: false fires.

    Note: `_find_matching_transition` uses T3's agent_response, not state.
    So T3 must explicitly include captured=False in its response.
    """
    responses = iter([
        llm_structured_response({           # T1: opening prompt
            "bot_response": "Would you like to submit? Any extra info?",
            "captured": None,
            "extra": None,
        }),
        llm_structured_response({           # T2: extra provided, captured still None
            "bot_response": None,
            "captured": None,
            "extra": "some extra info",
        }),
        llm_structured_response({           # T3: both provided → fires
            "bot_response": None,
            "captured": False,
            "extra": "some extra info",
        }),
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("so_bool_transition.yaml")
    tid = str(uuid.uuid4())

    result1 = tool.execute(thread_id=tid, initial_context={})
    assert InterruptType.USER_INPUT in str(result1)

    # T2: extra stored, captured=None → _get_missing_fields returns ["captured"]
    result2 = tool.execute(thread_id=tid, user_message="extra: some extra info", initial_context={})
    s2 = snap(tool, tid)

    assert InterruptType.USER_INPUT in str(result2)   # still collecting
    assert "Form declined" not in str(result2)
    assert s2.get("captured") is None                      # not yet provided
    assert s2["extra"] == "some extra info"            # stored from T2
    assert s2["_status"] == "collect_form_collecting"

    # T3: LLM provides both → match: false fires
    result3 = tool.execute(thread_id=tid, user_message="no I don't want to", initial_context={})
    s3 = snap(tool, tid)

    assert "Form declined" in str(result3)
    assert s3["_outcome_id"] == "outcome_not_captured"
    assert s3["captured"] is False
    assert s3["extra"] == "some extra info"
    assert s3["_validation_errors"] == {}
    assert s3.get("_pending_prompt") is None
    assert s3["error"] is None
    assert respx.calls.call_count == 3


# ── Group 23: SO Partial Data Population ──────────────────────────────────────


@respx.mock
def test_pd_1_initial_prompt_field_details_all_none():
    """T1 (initial prompt via _generate_prompt): field_details shows all None.

    On the FIRST execute() call, _generate_prompt is used (not
    _handle_structured_output_transition). _generate_prompt only extracts
    bot_response, options, is_selectable — it does NOT call _store_partial_data.
    So _partial_data["profile"] is NOT set after T1.

    _get_partial_field_value fallback returns None for all sub-fields since
    neither _partial_data nor state["profile"] has any values yet.

    Expected:
    - result.field_details has profile entry with 4 sub-fields, ALL None
      (including captured=None; False is only stored from T2+ via
       _handle_structured_output_transition, not from _generate_prompt)
    - _partial_data["profile"] key does NOT exist after T1
    - _status = "collect_profile_collecting"
    """
    respx.post(FAKE_LLM_COMPLETIONS).mock(return_value=llm_structured_response({
        "bot_response": "Tell me about yourself.",
        "captured": False, "first_name": None, "last_name": None, "email": None,
        "options": None, "is_selectable": None,
    }))

    tool = make_tool("so_partial_data.yaml")
    tid = str(uuid.uuid4())

    result1 = tool.execute(thread_id=tid, initial_context={})
    s1 = snap(tool, tid)

    # ── output: USER_INPUT interrupt with bot prompt ──
    assert InterruptType.USER_INPUT in str(result1)
    assert "Tell me about yourself." in str(result1)

    # ── field_details present with 4 sub-fields ──
    assert len(result1.field_details) == 1
    assert result1.field_details[0]["name"] == "profile"
    assert isinstance(result1.field_details[0]["value"], list)
    assert len(result1.field_details[0]["value"]) == 4

    # ── all sub-field values are None — _generate_prompt does not store partial data ──
    assert get_sub_field(result1.field_details, "profile", "captured") is None
    assert get_sub_field(result1.field_details, "profile", "first_name") is None
    assert get_sub_field(result1.field_details, "profile", "last_name") is None
    assert get_sub_field(result1.field_details, "profile", "email") is None

    # ── _partial_data["profile"] key NOT set after T1 (generate_prompt path) ──
    assert "profile" not in s1["_partial_data"]

    # ── state: field not yet captured, collecting ──
    assert s1.get("profile") is None
    assert s1["_status"] == "collect_profile_collecting"
    assert s1["_validation_errors"] == {}
    assert respx.calls.call_count == 1


@respx.mock
def test_pd_2_partial_capture_updates_field_details():
    """T2 bot_response path: partial data accumulates across turns.

    T1: all None prompt.
    T2: user replies; LLM captures first_name and last_name but not email.
        LLM still asks via bot_response (not done yet).

    Expected after T2:
    - result still USER_INPUT (still collecting)
    - field_details shows first_name="John", last_name="Doe", email=None
    - _partial_data["profile"] updated with T2 values
    - profile field NOT yet set in top-level state (bot_response path keeps collecting)
    """
    responses = iter([
        llm_structured_response({
            "bot_response": "Tell me about yourself.",
            "captured": False, "first_name": None, "last_name": None, "email": None,
            "options": None, "is_selectable": None,
        }),
        llm_structured_response({
            "bot_response": "What is your email?",
            "captured": False, "first_name": "John", "last_name": "Doe", "email": None,
            "options": None, "is_selectable": None,
        }),
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("so_partial_data.yaml")
    tid = str(uuid.uuid4())

    result1 = tool.execute(thread_id=tid, initial_context={})
    assert InterruptType.USER_INPUT in str(result1)

    result2 = tool.execute(thread_id=tid, user_message="John Doe", initial_context={})
    s2 = snap(tool, tid)

    # ── still collecting (bot_response means agent is still prompting) ──
    assert InterruptType.USER_INPUT in str(result2)
    assert "Profile collected" not in str(result2)

    # ── field_details reflects updated partial data ──
    assert get_sub_field(result2.field_details, "profile", "captured") is False
    assert get_sub_field(result2.field_details, "profile", "first_name") == "John"
    assert get_sub_field(result2.field_details, "profile", "last_name") == "Doe"
    assert get_sub_field(result2.field_details, "profile", "email") is None

    # ── _partial_data updated in state ──
    assert s2["_partial_data"]["profile"]["first_name"] == "John"
    assert s2["_partial_data"]["profile"]["last_name"] == "Doe"
    assert s2["_partial_data"]["profile"].get("email") is None

    # ── profile not yet stored at top level (bot_response keeps collecting) ──
    assert s2.get("profile") is None
    assert s2["_status"] == "collect_profile_collecting"
    assert respx.calls.call_count == 2


@respx.mock
def test_pd_3_full_capture_field_details_complete():
    """T3 no-bot_response path: full capture stores all values; field_details complete.

    T1 prompt → T2 partial → T3 all fields provided (no bot_response).

    Expected after T3:
    - Workflow completes with success outcome
    - result.field_details shows all sub-fields with final values
    - _partial_data["profile"] has complete values (stored at line ~1364)
    - state["profile"] = full dict (stored by _store_field_value)
    """
    responses = iter([
        llm_structured_response({
            "bot_response": "Tell me about yourself.",
            "captured": False, "first_name": None, "last_name": None, "email": None,
            "options": None, "is_selectable": None,
        }),
        llm_structured_response({
            "bot_response": "What is your email?",
            "captured": False, "first_name": "John", "last_name": "Doe", "email": None,
            "options": None, "is_selectable": None,
        }),
        llm_structured_response({
            "bot_response": None,
            "captured": True, "first_name": "John", "last_name": "Doe",
            "email": "john@example.com",
            "options": None, "is_selectable": None,
        }),
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("so_partial_data.yaml")
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    tool.execute(thread_id=tid, user_message="John Doe", initial_context={})
    result3 = tool.execute(thread_id=tid, user_message="john@example.com", initial_context={})
    s3 = snap(tool, tid)

    # ── success outcome ──
    assert "Profile collected" in str(result3)
    assert s3["_outcome_id"] == "end_success"

    # ── state["profile"] fully captured ──
    assert s3["profile"]["first_name"] == "John"
    assert s3["profile"]["last_name"] == "Doe"
    assert s3["profile"]["email"] == "john@example.com"
    assert s3["profile"]["captured"] is True

    # ── field_details shows all values (via STATUS-based node lookup) ──
    assert get_sub_field(result3.field_details, "profile", "captured") is True
    assert get_sub_field(result3.field_details, "profile", "first_name") == "John"
    assert get_sub_field(result3.field_details, "profile", "last_name") == "Doe"
    assert get_sub_field(result3.field_details, "profile", "email") == "john@example.com"

    # ── _partial_data preserved with final values ──
    assert s3["_partial_data"]["profile"]["first_name"] == "John"
    assert s3["_partial_data"]["profile"]["email"] == "john@example.com"

    assert s3["_validation_errors"] == {}
    assert respx.calls.call_count == 3


@respx.mock
def test_pd_4_validation_failure_clears_partial_data():
    """Validation failure: _store_partial_data(None) clears _partial_data[profile].

    T1 prompt → T2 submits invalid first_name ("J", < 2 chars) → validator rejects.

    Expected after T2:
    - Still collecting (re-prompt returned)
    - _partial_data["profile"] = {} (cleared by line ~1380)
    - _validation_errors["profile"] contains the invalid submitted dict
    - field_details shows all sub-fields as None (no partial data to show)
    - state["profile"] = None (cleared by _handle_validation_failure)
    """
    responses = iter([
        llm_structured_response({
            "bot_response": "Tell me about yourself.",
            "captured": False, "first_name": None, "last_name": None, "email": None,
            "options": None, "is_selectable": None,
        }),
        llm_structured_response({
            "bot_response": None,
            "captured": True, "first_name": "J", "last_name": "Doe",
            "email": "john@example.com",
            "options": None, "is_selectable": None,
        }),
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("so_partial_data.yaml")
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    result2 = tool.execute(thread_id=tid, user_message="J Doe", initial_context={})
    s2 = snap(tool, tid)

    # ── still collecting (re-prompt after validation failure) ──
    assert InterruptType.USER_INPUT in str(result2)
    assert "Profile collected" not in str(result2)

    # ── _partial_data cleared on validation failure ──
    assert s2["_partial_data"]["profile"] == {}

    # ── validation error recorded with the invalid submitted value ──
    assert "profile" in s2["_validation_errors"]
    assert s2["_validation_errors"]["profile"]["value"]["first_name"] == "J"
    assert "First name must be at least 2 characters" in s2["_validation_errors"]["profile"]["error"]

    # ── profile field cleared ──
    assert s2.get("profile") is None

    # ── field_details: all None (no partial data after clear) ──
    assert len(result2.field_details) == 1
    assert result2.field_details[0]["name"] == "profile"
    assert get_sub_field(result2.field_details, "profile", "captured") is None
    assert get_sub_field(result2.field_details, "profile", "first_name") is None
    assert get_sub_field(result2.field_details, "profile", "last_name") is None
    assert get_sub_field(result2.field_details, "profile", "email") is None

    assert respx.calls.call_count == 2


@respx.mock
def test_pd_5_resume_partial_persists_through_turns():
    """Partial data survives checkpoint resume across all three turns.

    Verifies the "same behaviour on initial run and after resume" requirement:
    - T1 (initial): _partial_data stored, field_details has sub-fields
    - T2 (resume): _partial_data UPDATED (not reset), field_details shows accumulated values
    - T3 (resume): full capture, field_details complete

    All checked via snap() to confirm checkpoint persistence.
    """
    responses = iter([
        llm_structured_response({
            "bot_response": "What is your name?",
            "captured": False, "first_name": None, "last_name": None, "email": None,
            "options": None, "is_selectable": None,
        }),
        llm_structured_response({
            "bot_response": "And your email?",
            "captured": False, "first_name": "Alice", "last_name": "Smith", "email": None,
            "options": None, "is_selectable": None,
        }),
        llm_structured_response({
            "bot_response": None,
            "captured": True, "first_name": "Alice", "last_name": "Smith",
            "email": "alice@example.com",
            "options": None, "is_selectable": None,
        }),
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("so_partial_data.yaml")
    tid = str(uuid.uuid4())

    # ── T1: initial run — _generate_prompt path, no partial data stored ──
    result1 = tool.execute(thread_id=tid, initial_context={})
    s1 = snap(tool, tid)
    assert InterruptType.USER_INPUT in str(result1)
    # T1 uses _generate_prompt, not _handle_structured_output_transition
    # → _partial_data["profile"] key is NOT set after T1
    assert "profile" not in s1["_partial_data"]

    # ── T2: first resume — partial data updated ──
    result2 = tool.execute(thread_id=tid, user_message="Alice Smith", initial_context={})
    s2 = snap(tool, tid)
    assert InterruptType.USER_INPUT in str(result2)
    # Partial data from T1 updated with T2 values (dict.update is cumulative)
    assert s2["_partial_data"]["profile"]["first_name"] == "Alice"
    assert s2["_partial_data"]["profile"]["last_name"] == "Smith"
    assert s2["_partial_data"]["profile"].get("email") is None
    # field_details via result reflect accumulated state
    assert get_sub_field(result2.field_details, "profile", "first_name") == "Alice"
    assert get_sub_field(result2.field_details, "profile", "last_name") == "Smith"
    assert get_sub_field(result2.field_details, "profile", "email") is None

    # ── T3: second resume — full capture ──
    result3 = tool.execute(thread_id=tid, user_message="alice@example.com", initial_context={})
    s3 = snap(tool, tid)
    assert "Profile collected" in str(result3)
    # After completion, field_details still shows all values
    assert get_sub_field(result3.field_details, "profile", "first_name") == "Alice"
    assert get_sub_field(result3.field_details, "profile", "last_name") == "Smith"
    assert get_sub_field(result3.field_details, "profile", "email") == "alice@example.com"
    assert s3["_validation_errors"] == {}
    assert respx.calls.call_count == 3


@respx.mock
def test_pd_6_missing_required_field_in_submit_preserves_other_partial_data():
    """Incomplete data: required field is None in no-bot_response submission.

    T1 prompt → T2: LLM submits (no bot_response) with captured=True but
    first_name=None (required field missing from the submitted data).

    Key distinction from test_pd_4 (validator failure):
    - missing_required_fields path (line ~1373) calls _handle_validation_failure
      WITHOUT calling _store_partial_data(None)
    - So _partial_data["profile"] is RETAINED (not cleared)
    - _validation_errors NOT set because _validate_collected_input is never called
      (early return at line ~1373 before reaching _validate_collected_input at ~1378)

    Note: agent.invoke() returns model_dump() which fills ALL Pydantic fields with
    their defaults. So even if first_name is "absent" from LLM JSON, model_dump()
    includes first_name=None. Thus "first_name" IS in agent_response, but with
    value None → added to field_values as None → stored in _partial_data as None.

    Expected after T2:
    - Still collecting (re-prompt after missing required field)
    - _partial_data["profile"] has last_name="Doe", email populated, first_name=None
    - field_details: first_name=None, last_name="Doe", email="doe@example.com"
    - _validation_errors = {} (missing-required-fields path does not call
      _validate_collected_input)
    """
    responses = iter([
        llm_structured_response({
            "bot_response": "Tell me about yourself.",
            "captured": False, "first_name": None, "last_name": None, "email": None,
            "options": None, "is_selectable": None,
        }),
        # T2: first_name deliberately None (missing from LLM response)
        llm_structured_response({
            "bot_response": None,
            "captured": True, "first_name": None, "last_name": "Doe",
            "email": "doe@example.com",
            "options": None, "is_selectable": None,
        }),
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("so_partial_data.yaml")
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})
    result2 = tool.execute(thread_id=tid, user_message="Doe doe@example.com", initial_context={})
    s2 = snap(tool, tid)

    # ── still collecting (missing required field → re-prompt) ──
    assert InterruptType.USER_INPUT in str(result2)
    assert "Profile collected" not in str(result2)
    assert s2.get("profile") is None

    # ── _partial_data NOT cleared (missing-required-fields path preserves partial data) ──
    # last_name and email were provided → in partial data with their values
    assert s2["_partial_data"]["profile"].get("last_name") == "Doe"
    assert s2["_partial_data"]["profile"].get("email") == "doe@example.com"
    # first_name was None in response → stored as None in partial data (not absent)
    assert s2["_partial_data"]["profile"].get("first_name") is None

    # ── field_details: first_name=None (missing), others show submitted values ──
    assert get_sub_field(result2.field_details, "profile", "first_name") is None
    assert get_sub_field(result2.field_details, "profile", "last_name") == "Doe"
    assert get_sub_field(result2.field_details, "profile", "email") == "doe@example.com"

    # ── _validation_errors NOT set (missing-required-fields path skips _validate_collected_input) ──
    assert s2["_validation_errors"] == {}
    assert respx.calls.call_count == 2


@respx.mock
def test_pd_7_bot_response_partial_fields_accumulate_correctly():
    """Partial data in bot_response: fields with values override None from earlier turns.

    T1 prompt → T2: LLM provides first_name="Bob" but last_name=None.
    T3: LLM provides last_name="Jones" and email="bob@example.com".

    The _store_partial_data uses dict.update(), so each turn accumulates:
    - After T2: first_name="Bob", last_name=None, email=None
    - After T3: first_name="Bob", last_name="Jones", email="bob@example.com"
      (T3 update overrides T2's None values with actual values)

    Note: agent.invoke() returns model_dump() which always includes ALL Pydantic
    fields. So even "absent" fields appear as None in agent_response, and thus
    in field_values. last_name=None in partial_data does NOT block retrieval of
    last_name="Jones" on T3 because T3 update() overwrites it.

    Expected after T3:
    - field_details shows first_name="Bob", last_name="Jones", email="bob@example.com"
    - _partial_data accumulated across 3 turns via dict.update()
    """
    responses = iter([
        llm_structured_response({
            "bot_response": "Tell me about yourself.",
            "captured": False, "first_name": None, "last_name": None, "email": None,
            "options": None, "is_selectable": None,
        }),
        # T2: first_name provided, last_name/email still None
        llm_structured_response({
            "bot_response": "What is your last name and email?",
            "captured": False, "first_name": "Bob", "last_name": None, "email": None,
            "options": None, "is_selectable": None,
        }),
        # T3: last_name + email provided; no bot_response (final submission)
        llm_structured_response({
            "bot_response": None,
            "captured": True, "first_name": "Bob", "last_name": "Jones",
            "email": "bob@example.com",
            "options": None, "is_selectable": None,
        }),
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("so_partial_data.yaml")
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})

    result2 = tool.execute(thread_id=tid, user_message="Bob", initial_context={})
    s2 = snap(tool, tid)

    # ── T2: first_name="Bob", others still None ──
    assert InterruptType.USER_INPUT in str(result2)
    assert s2["_partial_data"]["profile"]["first_name"] == "Bob"
    assert s2["_partial_data"]["profile"].get("last_name") is None
    assert get_sub_field(result2.field_details, "profile", "first_name") == "Bob"
    assert get_sub_field(result2.field_details, "profile", "last_name") is None

    result3 = tool.execute(thread_id=tid, user_message="Jones bob@example.com", initial_context={})
    s3 = snap(tool, tid)

    # ── T3: full capture; all values accumulated ──
    assert "Profile collected" in str(result3)
    assert s3["_partial_data"]["profile"]["first_name"] == "Bob"
    assert s3["_partial_data"]["profile"]["last_name"] == "Jones"
    assert s3["_partial_data"]["profile"]["email"] == "bob@example.com"

    assert get_sub_field(result3.field_details, "profile", "first_name") == "Bob"
    assert get_sub_field(result3.field_details, "profile", "last_name") == "Jones"
    assert get_sub_field(result3.field_details, "profile", "email") == "bob@example.com"

    assert s3["profile"]["first_name"] == "Bob"
    assert s3["profile"]["last_name"] == "Jones"
    assert respx.calls.call_count == 3


@respx.mock
def test_pd_8_first_turn_user_message_partial_no_partial_data_on_t1():
    """T1 with user_message (partial SO capture): _generate_prompt path, no partial data on T1.

    Even when user_message is provided on T1, ALL first entries go through
    _generate_prompt (not _handle_structured_output_transition). _generate_prompt
    extracts only bot_response/options/is_selectable — it does NOT call
    _store_partial_data. So T1 field_details are all None regardless of whether
    user_message is present.

    T1: user_message="John" → LLM processes it, returns bot_response asking for
        last_name and email → _pending_prompt set → interrupt fires.
    T2 (self-loop): user sends "Doe john@example.com" → _handle_structured_output_transition
        → _store_partial_data → field_details shows accumulated values.

    Verifies:
    - T1 field_details: all None (same as test_pd_1 — _generate_prompt doesn't store partial)
    - T1 _partial_data["profile"]: NOT set (same behavior as without user_message)
    - T2 field_details: shows all captured values via _partial_data
    - 2 total LLM calls (T1: generate prompt processing user_message; T2: capture on self-loop)
    """
    responses = iter([
        # T1: LLM processes "John" → asks for more
        llm_structured_response({
            "bot_response": "What is your last name and email?",
            "captured": False, "first_name": "John", "last_name": None, "email": None,
            "options": None, "is_selectable": None,
        }),
        # T2: LLM captures all fields on self-loop
        llm_structured_response({
            "bot_response": None,
            "captured": True, "first_name": "John", "last_name": "Doe",
            "email": "john@example.com",
            "options": None, "is_selectable": None,
        }),
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("so_partial_data.yaml")
    tid = str(uuid.uuid4())

    # T1: user provides partial data on first call
    result1 = tool.execute(thread_id=tid, user_message="John", initial_context={})
    s1 = snap(tool, tid)

    # ── T1: still collecting (bot_response → pending interrupt) ──
    assert InterruptType.USER_INPUT in str(result1)
    assert "last name" in str(result1).lower() or "email" in str(result1).lower()
    assert "Profile collected" not in str(result1)

    # ── T1: _partial_data["profile"] NOT set (_generate_prompt path, same as test_pd_1) ──
    assert "profile" not in s1["_partial_data"]

    # ── T1: field_details all None (no partial data from _generate_prompt) ──
    assert len(result1.field_details) == 1
    assert get_sub_field(result1.field_details, "profile", "first_name") is None
    assert get_sub_field(result1.field_details, "profile", "last_name") is None
    assert get_sub_field(result1.field_details, "profile", "email") is None

    assert s1.get("profile") is None
    assert s1["_status"] == "collect_profile_collecting"
    assert respx.calls.call_count == 1

    # T2: self-loop processes next user input
    result2 = tool.execute(thread_id=tid, user_message="Doe john@example.com", initial_context={})
    s2 = snap(tool, tid)

    # ── T2: success ──
    assert "Profile collected" in str(result2)
    assert s2["_outcome_id"] == "end_success"

    # ── T2: _partial_data now set (via _handle_structured_output_transition) ──
    assert "profile" in s2["_partial_data"]
    assert s2["_partial_data"]["profile"]["first_name"] == "John"
    assert s2["_partial_data"]["profile"]["last_name"] == "Doe"
    assert s2["_partial_data"]["profile"]["email"] == "john@example.com"

    # ── T2: field_details shows all captured values ──
    assert get_sub_field(result2.field_details, "profile", "first_name") == "John"
    assert get_sub_field(result2.field_details, "profile", "last_name") == "Doe"
    assert get_sub_field(result2.field_details, "profile", "email") == "john@example.com"
    assert respx.calls.call_count == 2


@respx.mock
def test_pd_9_first_turn_user_message_full_capture_partial_data_set():
    """T1 with user_message: all required fields captured immediately via _check_context_extraction.

    When user_message is provided and the LLM responds with all required fields
    (no bot_response), _check_context_extraction detects it and calls
    _store_field_value (sets state["profile"]) AND _store_partial_data
    (sets _partial_data["profile"]).

    T1: user_message="John Doe john@example.com" → LLM captures all fields →
        immediate success in one call.

    Verifies:
    - Immediate success on first execute()
    - state["profile"] IS set (via _check_context_extraction → _store_field_value)
    - _partial_data["profile"] IS set (context extraction now calls _store_partial_data)
    - field_details correct via _partial_data path
    - Only 1 LLM call
    """
    respx.post(FAKE_LLM_COMPLETIONS).mock(return_value=llm_structured_response({
        "bot_response": None,
        "captured": True, "first_name": "John", "last_name": "Doe",
        "email": "john@example.com",
        "options": None, "is_selectable": None,
    }))

    tool = make_tool("so_partial_data.yaml")
    tid = str(uuid.uuid4())

    # T1: user provides complete data on very first call
    result1 = tool.execute(thread_id=tid, user_message="John Doe john@example.com", initial_context={})
    s1 = snap(tool, tid)

    # ── immediate success ──
    assert "Profile collected" in str(result1)
    assert s1["_outcome_id"] == "end_success"
    assert InterruptType.USER_INPUT not in str(result1)

    # ── state["profile"] set via _check_context_extraction → _store_field_value ──
    assert s1["profile"]["first_name"] == "John"
    assert s1["profile"]["last_name"] == "Doe"
    assert s1["profile"]["email"] == "john@example.com"
    assert s1["profile"]["captured"] is True

    # ── _partial_data["profile"] IS set (context extraction now calls _store_partial_data) ──
    assert "profile" in s1["_partial_data"]
    assert s1["_partial_data"]["profile"]["first_name"] == "John"
    assert s1["_partial_data"]["profile"]["last_name"] == "Doe"
    assert s1["_partial_data"]["profile"]["email"] == "john@example.com"

    # ── field_details correct from _partial_data ──
    assert len(result1.field_details) == 1
    assert get_sub_field(result1.field_details, "profile", "captured") is True
    assert get_sub_field(result1.field_details, "profile", "first_name") == "John"
    assert get_sub_field(result1.field_details, "profile", "last_name") == "Doe"
    assert get_sub_field(result1.field_details, "profile", "email") == "john@example.com"

    assert s1["_validation_errors"] == {}
    assert respx.calls.call_count == 1


@respx.mock
def test_pd_10_none_mandatory_field_no_bot_response_triggers_missing_fields_reprompt():
    """bot_response=None with a required field=None → missing fields re-prompt.

    Only None is treated as "missing" (empty strings/objects are valid values).

    T1 prompt → T2: bot_response=None, first_name=None (LLM didn't provide it),
    last_name="Doe" → missing_required_fields = ["first_name"] → re-prompt.
    Partial data is PRESERVED (missing-fields path, no validator failure/clear).

    T3: all required fields provided → success.

    Expected after T2:
    - Still collecting (USER_INPUT interrupt)
    - Missing-fields error mentions "first_name"
    - _partial_data["profile"] has last_name="Doe" (NOT cleared)
    - field_details: first_name=None, last_name="Doe"
    - _validation_errors == {} (missing path skips _validate_collected_input)

    Expected after T3:
    - Profile collected (success)
    """
    responses = iter([
        llm_structured_response({
            "bot_response": "Tell me your name.",
            "captured": False, "first_name": None, "last_name": None, "email": None,
            "options": None, "is_selectable": None,
        }),
        # T2: bot_response=None, first_name=None → missing required field
        llm_structured_response({
            "bot_response": None,
            "captured": False, "first_name": None, "last_name": "Doe", "email": None,
            "options": None, "is_selectable": None,
        }),
        # T3: all required fields present
        llm_structured_response({
            "bot_response": None,
            "captured": True, "first_name": "John", "last_name": "Doe",
            "email": "john@example.com",
            "options": None, "is_selectable": None,
        }),
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("so_partial_data.yaml")
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})

    result2 = tool.execute(thread_id=tid, user_message="Doe", initial_context={})
    s2 = snap(tool, tid)

    # ── still collecting ──
    assert InterruptType.USER_INPUT in str(result2)
    assert "Profile collected" not in str(result2)

    # ── missing-fields error message names the missing field ──
    assert "first_name" in str(result2)

    # ── missing-fields path preserves partial data (last_name="Doe" kept) ──
    assert "profile" in s2["_partial_data"]
    assert s2["_partial_data"]["profile"].get("last_name") == "Doe"
    assert s2["_partial_data"]["profile"].get("first_name") is None

    # ── field_details: first_name=None, last_name="Doe" ──
    assert get_sub_field(result2.field_details, "profile", "first_name") is None
    assert get_sub_field(result2.field_details, "profile", "last_name") == "Doe"

    # ── validation_errors NOT set (missing-fields path skips _validate_collected_input) ──
    assert s2["_validation_errors"] == {}

    # ── T3: all fields → success ──
    result3 = tool.execute(thread_id=tid, user_message="John Doe john@example.com", initial_context={})
    assert "Profile collected" in str(result3)
    assert respx.calls.call_count == 3
