"""
Tests for functional output guardrails (TDD).

Run with:
    python -m pytest tests/test_functional_guardrails.py -v
"""
import json
import unittest
from unittest.mock import MagicMock

# ---------------------------------------------------------------------------
# GuardrailResult
# ---------------------------------------------------------------------------

class TestGuardrailResult(unittest.TestCase):

    def test_passed_true_no_message(self):
        from soprano_sdk.guardrails.base_guardrail import GuardrailResult
        r = GuardrailResult(passed=True)
        self.assertTrue(r.passed)
        self.assertIsNone(r.error_message)

    def test_passed_false_with_message(self):
        from soprano_sdk.guardrails.base_guardrail import GuardrailResult
        r = GuardrailResult(passed=False, error_message="Something went wrong.")
        self.assertFalse(r.passed)
        self.assertEqual(r.error_message, "Something went wrong.")


# ---------------------------------------------------------------------------
# GuardrailViolationError
# ---------------------------------------------------------------------------

class TestGuardrailViolationError(unittest.TestCase):

    def test_carries_error_message(self):
        from soprano_sdk.guardrails.base_guardrail import GuardrailViolationError
        err = GuardrailViolationError("Please try again.")
        self.assertEqual(err.error_message, "Please try again.")

    def test_is_exception(self):
        from soprano_sdk.guardrails.base_guardrail import GuardrailViolationError
        err = GuardrailViolationError("oops")
        self.assertIsInstance(err, Exception)

    def test_str_representation(self):
        from soprano_sdk.guardrails.base_guardrail import GuardrailViolationError
        err = GuardrailViolationError("oops")
        self.assertIn("oops", str(err))


# ---------------------------------------------------------------------------
# ThoughtActionGuardrail
# ---------------------------------------------------------------------------

class TestThoughtActionGuardrail(unittest.TestCase):

    def _make(self, msg="retry"):
        from soprano_sdk.guardrails.functional_guardrail import ThoughtActionGuardrail
        return ThoughtActionGuardrail(error_message=msg)

    def test_final_answer_response_passes(self):
        """Final Answer: prefix → pass (not a leaked pattern)."""
        result = self._make().check("Final Answer: Your order is confirmed.")
        self.assertTrue(result.passed)

    def test_thought_action_response_fails(self):
        """Thought:/Action: present → fail (leaked ReAct chain)."""
        response = "Thought: I need to look up the order.\nAction: lookup_order\nAction Input: {\"order_id\": \"123\"}"
        result = self._make().check(response)
        self.assertFalse(result.passed)

    def test_plain_text_passes(self):
        """No leaked ReAct markers → pass (clean conversational response)."""
        result = self._make().check("Your order has been received. How can I help?")
        self.assertTrue(result.passed)

    def test_empty_string_passes(self):
        """Empty string has no leaked patterns → pass."""
        result = self._make().check("")
        self.assertTrue(result.passed)

    def test_action_without_thought_fails(self):
        """Action: present → fail (leaked tool invocation)."""
        response = "Action: search_order\nAction Input: {\"id\": \"456\"}"
        result = self._make().check(response)
        self.assertFalse(result.passed)

    def test_returns_configured_error_message_on_failure(self):
        """Error message from config is returned on failure."""
        msg = "I encountered an issue. Please try again."
        guardrail = self._make(msg=msg)
        result = guardrail.check("Action: do_something\nAction Input: {}")
        self.assertFalse(result.passed)
        self.assertEqual(result.error_message, msg)

    def test_thought_alone_fails(self):
        """Thought: alone → fail (leaked internal reasoning)."""
        result = self._make().check("Thought: I should check the order status.")
        self.assertFalse(result.passed)


# ---------------------------------------------------------------------------
# run_guardrails_parallel
# ---------------------------------------------------------------------------

class TestRunGuardrailsParallel(unittest.TestCase):

    def test_empty_list_returns_empty(self):
        from soprano_sdk.guardrails.runner import run_guardrails_parallel
        self.assertEqual(run_guardrails_parallel("any", []), [])

    def test_single_passing_guardrail(self):
        from soprano_sdk.guardrails.runner import run_guardrails_parallel
        from soprano_sdk.guardrails.base_guardrail import BaseGuardrail, GuardrailResult
        g = MagicMock(spec=BaseGuardrail)
        g.check.return_value = GuardrailResult(passed=True)
        results = run_guardrails_parallel("clean", [g])
        self.assertEqual(len(results), 1)
        self.assertTrue(results[0].passed)

    def test_single_failing_guardrail(self):
        from soprano_sdk.guardrails.runner import run_guardrails_parallel
        from soprano_sdk.guardrails.base_guardrail import BaseGuardrail, GuardrailResult
        g = MagicMock(spec=BaseGuardrail)
        g.check.return_value = GuardrailResult(passed=False, error_message="err")
        results = run_guardrails_parallel("bad response", [g])
        self.assertFalse(results[0].passed)
        self.assertEqual(results[0].error_message, "err")

    def test_result_order_preserved(self):
        from soprano_sdk.guardrails.runner import run_guardrails_parallel
        from soprano_sdk.guardrails.base_guardrail import BaseGuardrail, GuardrailResult
        g1 = MagicMock(spec=BaseGuardrail)
        g1.check.return_value = GuardrailResult(passed=True)
        g2 = MagicMock(spec=BaseGuardrail)
        g2.check.return_value = GuardrailResult(passed=False, error_message="g2 failed")
        g3 = MagicMock(spec=BaseGuardrail)
        g3.check.return_value = GuardrailResult(passed=True)

        results = run_guardrails_parallel("response", [g1, g2, g3])
        self.assertEqual(len(results), 3)
        self.assertTrue(results[0].passed)
        self.assertFalse(results[1].passed)
        self.assertEqual(results[1].error_message, "g2 failed")
        self.assertTrue(results[2].passed)

    def test_all_guardrails_invoked(self):
        from soprano_sdk.guardrails.runner import run_guardrails_parallel
        from soprano_sdk.guardrails.base_guardrail import BaseGuardrail, GuardrailResult
        g1, g2 = MagicMock(spec=BaseGuardrail), MagicMock(spec=BaseGuardrail)
        g1.check.return_value = GuardrailResult(passed=True)
        g2.check.return_value = GuardrailResult(passed=True)
        run_guardrails_parallel("text", [g1, g2])
        g1.check.assert_called_once_with("text")
        g2.check.assert_called_once_with("text")


# ---------------------------------------------------------------------------
# build_guardrails_from_config
# ---------------------------------------------------------------------------

class TestBuildGuardrailsFromConfig(unittest.TestCase):

    def test_known_type_creates_instance(self):
        from soprano_sdk.guardrails.base_guardrail import build_guardrails_from_config
        from soprano_sdk.guardrails.functional_guardrail import ThoughtActionGuardrail
        configs = [{"type": "thought_action_check", "error_message": "oops"}]
        guardrails = build_guardrails_from_config(configs)
        self.assertEqual(len(guardrails), 1)
        self.assertIsInstance(guardrails[0], ThoughtActionGuardrail)
        self.assertEqual(guardrails[0].error_message, "oops")

    def test_unknown_type_skipped(self):
        from soprano_sdk.guardrails.base_guardrail import build_guardrails_from_config
        configs = [{"type": "nonexistent_guardrail"}]
        self.assertEqual(build_guardrails_from_config(configs), [])

    def test_missing_type_key_skipped(self):
        from soprano_sdk.guardrails.base_guardrail import build_guardrails_from_config
        configs = [{"error_message": "no type key"}]
        self.assertEqual(build_guardrails_from_config(configs), [])

    def test_empty_list_returns_empty(self):
        from soprano_sdk.guardrails.base_guardrail import build_guardrails_from_config
        self.assertEqual(build_guardrails_from_config([]), [])

    def test_default_error_message_when_absent(self):
        from soprano_sdk.guardrails.base_guardrail import build_guardrails_from_config
        configs = [{"type": "thought_action_check"}]
        guardrails = build_guardrails_from_config(configs)
        self.assertIn("try again", guardrails[0].error_message.lower())

    def test_multiple_configs(self):
        from soprano_sdk.guardrails.base_guardrail import build_guardrails_from_config
        configs = [
            {"type": "thought_action_check", "error_message": "a"},
            {"type": "thought_action_check", "error_message": "b"},
        ]
        guardrails = build_guardrails_from_config(configs)
        self.assertEqual(len(guardrails), 2)
        self.assertEqual(guardrails[0].error_message, "a")
        self.assertEqual(guardrails[1].error_message, "b")

    def test_registry_contains_thought_action_check(self):
        from soprano_sdk.guardrails.base_guardrail import GuardrailFactory
        from soprano_sdk.guardrails.functional_guardrail import ThoughtActionGuardrail
        self.assertIn("thought_action_check", GuardrailFactory._registry)
        self.assertIs(GuardrailFactory._registry["thought_action_check"], ThoughtActionGuardrail)


# ---------------------------------------------------------------------------
# CrewAIAgentAdapter guardrail integration
# ---------------------------------------------------------------------------

class TestCrewAIAdapterGuardrails(unittest.TestCase):

    def _make_adapter(self, guardrails=None, raw_response="Final Answer: Hello."):
        from soprano_sdk.agents.adaptor import CrewAIAgentAdapter
        mock_agent = MagicMock()
        mock_result = MagicMock()
        mock_result.pydantic = None
        mock_result.raw = raw_response
        mock_agent.kickoff.return_value = mock_result
        return CrewAIAgentAdapter(
            agent=mock_agent,
            output_schema=None,
            guardrails=guardrails or [],
        )

    def test_no_guardrails_returns_response(self):
        adapter = self._make_adapter()
        result = adapter.invoke([{"role": "user", "content": "hi"}])
        self.assertEqual(result, "Final Answer: Hello.")

    def test_passing_guardrail_returns_response(self):
        from soprano_sdk.guardrails.base_guardrail import BaseGuardrail, GuardrailResult
        g = MagicMock(spec=BaseGuardrail)
        g.check.return_value = GuardrailResult(passed=True)
        adapter = self._make_adapter(guardrails=[g])
        result = adapter.invoke([{"role": "user", "content": "hi"}])
        self.assertIsNotNone(result)

    def test_failing_guardrail_raises_violation_error(self):
        from soprano_sdk.guardrails.base_guardrail import BaseGuardrail, GuardrailResult, GuardrailViolationError
        g = MagicMock(spec=BaseGuardrail)
        g.check.return_value = GuardrailResult(passed=False, error_message="Please try again.")
        g.max_retries = 0
        adapter = self._make_adapter(
            guardrails=[g],
            raw_response="Thought: I need to look this up.\nAction: lookup",
        )
        with self.assertRaises(GuardrailViolationError) as ctx:
            adapter.invoke([{"role": "user", "content": "hi"}])
        self.assertEqual(ctx.exception.error_message, "Please try again.")

    def test_violation_error_not_wrapped_as_runtime_error(self):
        """GuardrailViolationError must NOT be caught by the broad except Exception."""
        from soprano_sdk.guardrails.functional_guardrail import ThoughtActionGuardrail
        from soprano_sdk.guardrails.base_guardrail import GuardrailViolationError
        g = ThoughtActionGuardrail(error_message="retry")
        # AgentAction response (leaked chain)
        adapter = self._make_adapter(
            guardrails=[g],
            raw_response="Thought: analysing\nAction: do_something\nAction Input: {}",
        )
        with self.assertRaises(GuardrailViolationError):
            adapter.invoke([{"role": "user", "content": "hi"}])

    def test_guardrail_check_runs_before_pydantic_parsing(self):
        """Even when output_schema is set, guardrails run before schema validation."""
        from pydantic import BaseModel
        from soprano_sdk.guardrails.base_guardrail import BaseGuardrail, GuardrailResult, GuardrailViolationError
        from soprano_sdk.agents.adaptor import CrewAIAgentAdapter

        class MySchema(BaseModel):
            value: str

        g = MagicMock(spec=BaseGuardrail)
        g.check.return_value = GuardrailResult(passed=False, error_message="blocked")
        g.max_retries = 0

        mock_agent = MagicMock()
        mock_result = MagicMock()
        mock_result.pydantic = None
        mock_result.raw = "Thought: analysing\nAction: do_it\nAction Input: {}"
        mock_agent.kickoff.return_value = mock_result

        adapter = CrewAIAgentAdapter(agent=mock_agent, output_schema=MySchema, guardrails=[g])
        with self.assertRaises(GuardrailViolationError):
            adapter.invoke([{"role": "user", "content": "hi"}])
        g.check.assert_called_once()


# ---------------------------------------------------------------------------
# CollectInputStrategy YAML wiring
# ---------------------------------------------------------------------------

class TestCollectInputStrategyGuardrailsWiring(unittest.TestCase):

    def _make_strategy(self, guardrail_names=None, registry=None):
        from soprano_sdk.nodes.collect_input import CollectInputStrategy
        step_config = {
            "id": "order_id_step",
            "field": "order_id",
            "agent": {
                "name": "OrderCollector",
                "instructions": "Collect the order ID.",
                "guardrails": guardrail_names or [],
            },
        }
        engine_context = MagicMock()
        engine_context.get_config_value.side_effect = lambda key, default=None: {
            "rollback_strategy": "history_based",
        }.get(key, default)
        engine_context.mfa_validator_steps = set()
        engine_context.workflow_description = "Returns workflow"
        engine_context.guardrail_registry = registry or {}
        return CollectInputStrategy(step_config, engine_context)

    def test_no_guardrails_config_stores_empty_list(self):
        strategy = self._make_strategy()
        self.assertEqual(strategy.output_guardrails, [])

    def test_valid_config_instantiates_guardrails(self):
        from soprano_sdk.guardrails.functional_guardrail import ThoughtActionGuardrail
        guardrail = ThoughtActionGuardrail(error_message="retry")
        strategy = self._make_strategy(
            guardrail_names=["thought_action_check"],
            registry={"thought_action_check": guardrail},
        )
        self.assertEqual(len(strategy.output_guardrails), 1)
        self.assertIsInstance(strategy.output_guardrails[0], ThoughtActionGuardrail)

    def test_unknown_guardrail_name_results_in_empty_list(self):
        strategy = self._make_strategy(
            guardrail_names=["does_not_exist"],
            registry={},  # registry has no matching entry
        )
        self.assertEqual(strategy.output_guardrails, [])


# ---------------------------------------------------------------------------
# CollectInputStrategy._get_agent_response guardrail failure handling
# ---------------------------------------------------------------------------

class TestGetAgentResponseGuardrailFailure(unittest.TestCase):

    def _make_strategy(self):
        from soprano_sdk.nodes.collect_input import CollectInputStrategy
        step_config = {
            "id": "order_id_step",
            "field": "order_id",
            "agent": {
                "name": "OrderCollector",
                "instructions": "Collect the order ID.",
            },
        }
        engine_context = MagicMock()
        engine_context.get_config_value.side_effect = lambda key, default=None: {
            "rollback_strategy": "history_based",
        }.get(key, default)
        engine_context.mfa_validator_steps = set()
        engine_context.workflow_description = "Returns workflow"
        return CollectInputStrategy(step_config, engine_context)

    def test_guardrail_failure_adds_error_to_conversation(self):
        from soprano_sdk.guardrails.base_guardrail import GuardrailViolationError
        from soprano_sdk.nodes.collect_input import GuardrailFailureResponse

        strategy = self._make_strategy()
        mock_agent = MagicMock()
        mock_agent.invoke.side_effect = GuardrailViolationError("Please try again.")

        conversation = [{"role": "user", "content": "some input"}]
        result = strategy._get_agent_response(mock_agent, conversation, {})

        self.assertIsInstance(result, GuardrailFailureResponse)
        self.assertEqual(result.error_message, "Please try again.")

        # Error message must be in conversation as last assistant message
        last_msg = conversation[-1]
        self.assertEqual(last_msg["role"], "assistant")
        content = json.loads(last_msg["content"])
        self.assertEqual(content["text"], "Please try again.")

    def test_successful_response_passes_through(self):
        from soprano_sdk.nodes.collect_input import GuardrailFailureResponse

        strategy = self._make_strategy()
        mock_agent = MagicMock()
        mock_agent.invoke.return_value = "What is your order ID?"

        conversation = [{"role": "user", "content": "hi"}]
        result = strategy._get_agent_response(mock_agent, conversation, {})
        self.assertNotIsInstance(result, GuardrailFailureResponse)

    def test_process_user_response_stays_collecting_on_guardrail_failure(self):
        """When _get_agent_response returns GuardrailFailureResponse, state stays collecting."""
        from soprano_sdk.guardrails.base_guardrail import GuardrailViolationError
        from soprano_sdk.core.constants import WorkflowKeys

        strategy = self._make_strategy()
        # Patch _create_agent to return an agent that raises GuardrailViolationError
        mock_agent = MagicMock()
        mock_agent.invoke.side_effect = GuardrailViolationError("retry")
        strategy._create_agent = MagicMock(return_value=mock_agent)
        strategy._update_conversation = MagicMock()

        state = {WorkflowKeys.STATUS: "collecting"}
        conversation = [{"role": "user", "content": "some input"}]

        result_state = strategy._process_user_response(state, conversation)
        # Status should remain collecting (not advanced to next step)
        self.assertEqual(result_state.get(WorkflowKeys.STATUS), "collecting")


if __name__ == "__main__":
    unittest.main()
