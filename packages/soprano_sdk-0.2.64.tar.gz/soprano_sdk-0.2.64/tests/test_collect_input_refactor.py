import pytest
import json
from unittest.mock import MagicMock
from jinja2 import Environment
from soprano_sdk.nodes.collect_input import CollectInputStrategy
from soprano_sdk.core.constants import WorkflowKeys
from soprano_sdk.core.models import MessagePayload

class TestCollectInputStrategyRefactor:
    @pytest.fixture
    def strategy(self):
        step_config = {
            "field": "test_field",
            "agent": {"name": "test_agent"}
        }
        engine_context = MagicMock()
        engine_context.get_config_value.return_value = "history_based"
        return CollectInputStrategy(step_config, engine_context)

    def test_handle_max_attempts_default_message(self):
        """Test that default error message is used when on_max_attempts_reached is not provided"""
        step_config = {
            "id": "collect_customer_name",
            "field": "customer_name",
            "agent": {"name": "test_agent"}
        }
        engine_context = MagicMock()
        engine_context.get_config_value.side_effect = lambda key, default=None: {
            "rollback_strategy": "history_based",
            "template_loader": Environment()
        }.get(key, default)
        engine_context._get_humanization_config.return_value = {"enabled": False}

        strategy = CollectInputStrategy(step_config, engine_context)
        state = {}

        result = strategy._handle_max_attempts(state)

        assert result[WorkflowKeys.STATUS] == "collect_customer_name_max_attempts"
        assert "customer_name" in result[WorkflowKeys.MESSAGES][0]
        assert "customer service" in result[WorkflowKeys.MESSAGES][0].lower()

    def test_handle_max_attempts_custom_message(self):
        """Test that custom error message is used when on_max_attempts_reached is provided"""
        custom_message = "Custom error: Too many attempts. Please call 1-800-SUPPORT."
        step_config = {
            "id": "collect_customer_name",
            "field": "customer_name",
            "agent": {"name": "test_agent"},
            "on_max_attempts_reached": custom_message
        }
        engine_context = MagicMock()
        engine_context.get_config_value.side_effect = lambda key, default=None: {
            "rollback_strategy": "history_based",
            "template_loader": Environment()
        }.get(key, default)
        engine_context._get_humanization_config.return_value = {"enabled": False}

        strategy = CollectInputStrategy(step_config, engine_context)
        state = {}

        result = strategy._handle_max_attempts(state)

        assert result[WorkflowKeys.STATUS] == "collect_customer_name_max_attempts"
        assert result[WorkflowKeys.MESSAGES][0] == custom_message
        assert "1-800-SUPPORT" in result[WorkflowKeys.MESSAGES][0]

    def test_generate_prompt_with_structured_output_no_initial_message(self):
        """Test that bot_response is extracted from structured output when no initial_message is provided"""
        step_config = {
            "id": "collect_name",
            "field": "name",
            "agent": {
                "name": "test_agent",
                "structured_output": {
                    "enabled": True,
                    "fields": [
                        {"name": "captured_name", "type": "boolean", "description": "Name captured", "required": True}
                    ]
                }
            }
        }
        engine_context = MagicMock()
        engine_context.get_config_value.side_effect = lambda key, default=None: {
            "rollback_strategy": "history_based",
            "template_loader": Environment()
        }.get(key, default)

        strategy = CollectInputStrategy(step_config, engine_context)

        # Mock agent that returns structured output
        agent = MagicMock()
        structured_response = json.dumps({
            "bot_response": "Hello! Please provide your name.",
            "captured_name": False
        })
        agent.invoke.return_value = structured_response

        conversation = []
        state = {}

        prompt = strategy._generate_prompt(agent, conversation, state)

        assert prompt["text"] == "Hello! Please provide your name."
        assert len(conversation) == 1
        assert conversation[0]["role"] == "assistant"
        content = json.loads(conversation[0]["content"])
        assert content["text"] == "Hello! Please provide your name."

    def test_generate_prompt_with_structured_output_empty_bot_response(self):
        """Test that None is returned when bot_response is empty in structured output"""
        step_config = {
            "id": "collect_name",
            "field": "name",
            "agent": {
                "name": "test_agent",
                "structured_output": {
                    "enabled": True,
                    "fields": [
                        {"name": "captured_name", "type": "boolean", "description": "Name captured", "required": True}
                    ]
                }
            }
        }
        engine_context = MagicMock()
        engine_context.get_config_value.side_effect = lambda key, default=None: {
            "rollback_strategy": "history_based",
            "template_loader": Environment()
        }.get(key, default)

        strategy = CollectInputStrategy(step_config, engine_context)

        # Mock agent that returns structured output with empty bot_response
        agent = MagicMock()
        structured_response = json.dumps({
            "bot_response": "",
            "captured_name": False
        })
        agent.invoke.return_value = structured_response

        conversation = []
        state = {}

        # Empty bot_response should return None (which causes execute() to skip interrupt)
        prompt = strategy._generate_prompt(agent, conversation, state)

        assert prompt is None
        assert len(conversation) == 0  # Nothing added to conversation

    def test_generate_prompt_without_structured_output_no_initial_message(self):
        """Test that regular agent response is used when structured output is disabled"""
        step_config = {
            "id": "collect_name",
            "field": "name",
            "agent": {
                "name": "test_agent",
                "structured_output": {
                    "enabled": False
                }
            }
        }
        engine_context = MagicMock()
        engine_context.get_config_value.side_effect = lambda key, default=None: {
            "rollback_strategy": "history_based",
            "template_loader": Environment()
        }.get(key, default)

        strategy = CollectInputStrategy(step_config, engine_context)

        # Mock agent that returns plain text
        agent = MagicMock()
        agent.invoke.return_value = "Hello! What's your name?"

        conversation = []
        state = {}

        prompt = strategy._generate_prompt(agent, conversation, state)

        assert prompt["text"] == "Hello! What's your name?"
        assert len(conversation) == 1
        assert conversation[0]["role"] == "assistant"
        content = json.loads(conversation[0]["content"])
        assert content["text"] == "Hello! What's your name?"

    def test_context_value_applied_from_engine_context(self):
        """Test that context values are applied from engine context"""
        step_config = {
            "id": "collect_customer_id",
            "field": "customer_id",
            "agent": {"name": "test_agent"}
        }
        engine_context = MagicMock()
        engine_context.get_config_value.return_value = "history_based"
        # Mock context value (from initial_context)
        engine_context.get_context_value.return_value = "CTX_12345"

        strategy = CollectInputStrategy(step_config, engine_context)

        # Simulate state
        state = {}

        span = MagicMock()

        # Call _apply_context_value
        strategy._apply_context_value(state, span)

        # Verify the context value WAS applied
        assert state["customer_id"] == "CTX_12345"
        # Verify the context.value_used event was logged
        span.add_event.assert_called_once()
        event_call = span.add_event.call_args
        assert event_call[0][0] == "context.value_used"
        assert event_call[0][1]["field"] == "customer_id"
        assert event_call[0][1]["value"] == "CTX_12345"


class TestHumanizationRefactoring:
    """Test cases for humanization - static initial_message humanization only"""

    def test_static_initial_message_still_humanized(self):
        """Test that static initial_message from config still gets humanized"""
        step_config = {
            "id": "collect_name",
            "field": "name",
            "agent": {
                "name": "test_agent",
                "initial_message": "What is your name?",
                "humanize": True
            }
        }
        engine_context = MagicMock()
        engine_context.get_config_value.side_effect = lambda key, default=None: {
            "rollback_strategy": "history_based",
            "template_loader": Environment()
        }.get(key, default)
        engine_context._get_humanization_config.return_value = {"enabled": True}
        engine_context._humanize_message.return_value = MessagePayload("Hey there! What should I call you?", None, None)

        strategy = CollectInputStrategy(step_config, engine_context)

        agent = MagicMock()
        conversation = []
        state = {}

        prompt = strategy._generate_prompt(agent, conversation, state)

        # Verify _humanize_message was called for static initial_message
        engine_context._humanize_message.assert_called_once()
        assert prompt["text"] == "Hey there! What should I call you?"

    def test_agent_generated_prompt_not_double_humanized(self):
        """Test that agent-generated prompts are NOT humanized separately"""
        step_config = {
            "id": "collect_name",
            "field": "name",
            "agent": {"name": "test_agent", "humanize": True}
        }
        engine_context = MagicMock()
        engine_context.get_config_value.side_effect = lambda key, default=None: {
            "rollback_strategy": "history_based",
            "template_loader": Environment()
        }.get(key, default)
        engine_context._get_humanization_config.return_value = {"enabled": True}
        engine_context._humanize_message.return_value = MessagePayload("Should not be called")

        strategy = CollectInputStrategy(step_config, engine_context)

        agent = MagicMock()
        agent.invoke.return_value = "What is your name?"
        conversation = []
        state = {}

        prompt = strategy._generate_prompt(agent, conversation, state)

        # Verify _humanize_message was NOT called (agent already has humanization in system prompt)
        engine_context._humanize_message.assert_not_called()
        assert prompt["text"] == "What is your name?"

    def test_localization_instructions_added(self):
        """Test that localization instructions are included when configured"""
        step_config = {
            "id": "collect_name",
            "field": "name",
            "agent": {"name": "test_agent", "instructions": "Collect the name."}
        }
        engine_context = MagicMock()
        engine_context.get_config_value.side_effect = lambda key, default=None: {
            "rollback_strategy": "history_based",
            "template_loader": Environment()
        }.get(key, default)
        engine_context._get_humanization_config.return_value = {"enabled": False}
        engine_context.get_localization_instructions.return_value = "Respond in Spanish."

        strategy = CollectInputStrategy(step_config, engine_context)
        state = {}
        collector_nodes = {}

        instructions = strategy._get_instructions(state, collector_nodes)

        # Verify localization is present
        assert "Respond in Spanish." in instructions
        assert "Collect the name." in instructions

        # Verify localization is wrapped in XML tag and comes before base instructions
        assert instructions.startswith("<localization>\nRespond in Spanish.")

    def test_static_initial_message_not_humanized_when_disabled(self):
        """Test that static initial_message is NOT humanized when humanize: false"""
        step_config = {
            "id": "collect_name",
            "field": "name",
            "agent": {
                "name": "test_agent",
                "initial_message": "What is your name?",
                "humanize": False
            }
        }
        engine_context = MagicMock()
        engine_context.get_config_value.side_effect = lambda key, default=None: {
            "rollback_strategy": "history_based",
            "template_loader": Environment()
        }.get(key, default)
        engine_context._get_humanization_config.return_value = {"enabled": True}
        engine_context._humanize_message.return_value = MessagePayload("Should not be called")

        strategy = CollectInputStrategy(step_config, engine_context)

        agent = MagicMock()
        conversation = []
        state = {}

        prompt = strategy._generate_prompt(agent, conversation, state)

        # Verify _humanize_message was NOT called when humanize: false
        engine_context._humanize_message.assert_not_called()
        assert prompt["text"] == "What is your name?"

    def test_static_initial_message_not_humanized_when_globally_disabled(self):
        """Test that static initial_message is NOT humanized when humanization is globally disabled"""
        step_config = {
            "id": "collect_name",
            "field": "name",
            "agent": {
                "name": "test_agent",
                "initial_message": "What is your name?",
                "humanize": True
            }
        }
        engine_context = MagicMock()
        engine_context.get_config_value.side_effect = lambda key, default=None: {
            "rollback_strategy": "history_based",
            "template_loader": Environment()
        }.get(key, default)
        # Global humanization disabled
        engine_context._get_humanization_config.return_value = {"enabled": False}
        engine_context._humanize_message.return_value = MessagePayload("Should not be called")

        strategy = CollectInputStrategy(step_config, engine_context)

        agent = MagicMock()
        conversation = []
        state = {}

        prompt = strategy._generate_prompt(agent, conversation, state)

        # Verify _humanize_message was NOT called when globally disabled
        engine_context._humanize_message.assert_not_called()
        assert prompt["text"] == "What is your name?"

    def test_validation_failure_message_humanized(self):
        """Test that validation failure messages are humanized when enabled"""
        step_config = {
            "id": "collect_age",
            "field": "age",
            "agent": {"name": "test_agent", "humanize": True}
        }
        engine_context = MagicMock()
        engine_context.get_config_value.side_effect = lambda key, default=None: {
            "rollback_strategy": "history_based",
            "template_loader": Environment()
        }.get(key, default)
        engine_context._get_humanization_config.return_value = {"enabled": True}
        engine_context._humanize_message.return_value = MessagePayload("Oops! That doesn't look quite right. Could you try entering your age again?")
        engine_context.update_context = MagicMock()

        strategy = CollectInputStrategy(step_config, engine_context)

        conversation = []
        state = {}
        validation_message = "validation failed for the provided input, please enter valid input"

        strategy._handle_validation_failure(state, conversation, message=validation_message)

        # Verify _humanize_message was called
        engine_context._humanize_message.assert_called_once()
        # Verify humanized message was added to conversation
        assert len(conversation) == 1
        content = json.loads(conversation[0]["content"])
        assert content["text"] == "Oops! That doesn't look quite right. Could you try entering your age again?"

    def test_validation_failure_message_not_humanized_when_disabled(self):
        """Test that validation failure messages are NOT humanized when disabled"""
        step_config = {
            "id": "collect_age",
            "field": "age",
            "agent": {"name": "test_agent", "humanize": False}
        }
        engine_context = MagicMock()
        engine_context.get_config_value.side_effect = lambda key, default=None: {
            "rollback_strategy": "history_based",
            "template_loader": Environment()
        }.get(key, default)
        engine_context._get_humanization_config.return_value = {"enabled": True}
        engine_context._humanize_message.return_value = MessagePayload("Should not be called", None, None)
        engine_context.update_context = MagicMock()

        strategy = CollectInputStrategy(step_config, engine_context)

        conversation = []
        state = {}
        validation_message = "validation failed for the provided input, please enter valid input"

        strategy._handle_validation_failure(state, conversation, message=validation_message)

        # Verify _humanize_message was NOT called
        engine_context._humanize_message.assert_not_called()
        # Verify original message was added to conversation
        assert len(conversation) == 1
        content = json.loads(conversation[0]["content"])
        assert content["text"] == validation_message

    def test_collection_failure_message_humanized(self):
        """Test that collection failure messages are humanized when enabled"""
        step_config = {
            "id": "collect_name",
            "field": "name",
            "agent": {"name": "test_agent", "humanize": True}
        }
        engine_context = MagicMock()
        engine_context.get_config_value.side_effect = lambda key, default=None: {
            "rollback_strategy": "history_based",
            "template_loader": Environment()
        }.get(key, default)
        engine_context._get_humanization_config.return_value = {"enabled": True}
        engine_context._humanize_message.return_value = MessagePayload("Hmm, I'm not quite sure what you meant. Could you rephrase that for me?", None, None)

        strategy = CollectInputStrategy(step_config, engine_context)

        conversation = []
        state = {}

        strategy._handle_collection_failure(state, conversation)

        # Verify _humanize_message was called
        engine_context._humanize_message.assert_called_once()
        # Verify humanized message was added to conversation
        assert len(conversation) == 1
        content = json.loads(conversation[0]["content"])
        assert content["text"] == "Hmm, I'm not quite sure what you meant. Could you rephrase that for me?"

    def test_max_attempts_message_humanized(self):
        """Test that max attempts messages are humanized when enabled"""
        step_config = {
            "id": "collect_email",
            "field": "email",
            "agent": {"name": "test_agent", "humanize": True}
        }
        engine_context = MagicMock()
        engine_context.get_config_value.side_effect = lambda key, default=None: {
            "rollback_strategy": "history_based",
            "template_loader": Environment()
        }.get(key, default)
        engine_context._get_humanization_config.return_value = {"enabled": True}
        engine_context._humanize_message.return_value = MessagePayload("I apologize, but we've tried a few times and I'm still having trouble getting your email address. Let me connect you with someone who can help.", None, None)

        strategy = CollectInputStrategy(step_config, engine_context)

        state = {}

        result = strategy._handle_max_attempts(state)

        # Verify _humanize_message was called
        engine_context._humanize_message.assert_called_once()
        # Verify humanized message was added to state
        assert WorkflowKeys.MESSAGES in result
        assert len(result[WorkflowKeys.MESSAGES]) == 1
        assert result[WorkflowKeys.MESSAGES][0] == "I apologize, but we've tried a few times and I'm still having trouble getting your email address. Let me connect you with someone who can help."

    def test_max_attempts_message_not_humanized_when_disabled(self):
        """Test that max attempts messages are NOT humanized when disabled"""
        step_config = {
            "id": "collect_email",
            "field": "email",
            "agent": {"name": "test_agent", "humanize": False},
            "on_max_attempts_reached": "Max attempts reached for email"
        }
        engine_context = MagicMock()
        engine_context.get_config_value.side_effect = lambda key, default=None: {
            "rollback_strategy": "history_based",
            "template_loader": Environment()
        }.get(key, default)
        engine_context._get_humanization_config.return_value = {"enabled": True}
        engine_context._humanize_message.return_value = MessagePayload("Should not be called", None, None)

        strategy = CollectInputStrategy(step_config, engine_context)

        state = {}

        result = strategy._handle_max_attempts(state)

        # Verify _humanize_message was NOT called
        engine_context._humanize_message.assert_not_called()
        # Verify original message was added to state
        assert WorkflowKeys.MESSAGES in result
        assert len(result[WorkflowKeys.MESSAGES]) == 1
        assert result[WorkflowKeys.MESSAGES][0] == "Max attempts reached for email"


class TestSOIntentChangeOnInitialEntry:
    """
    Regression tests for the bug where structured-output intent_change responses
    were silently dropped on the node's first entry (initial _generate_prompt call).

    Before the fix:
      - _generate_prompt stripped intent_change from the SO response dict and only
        returned {"text": bot_response, "options": ..., "is_selectable": ...}.
      - execute() called _handle_special_responses with that dict, so
        agent_response.get("intent_change") was always None → intent change ignored.

    After the fix:
      - intent_change / out_of_scope are forwarded into the returned prompt_data dict.
      - When bot_response is empty the function now returns a non-None dict (instead
        of None) so execute() still reaches _handle_special_responses.
    """

    SO_STEP_CONFIG = {
        "id": "collect_reason",
        "field": "reason",
        "agent": {
            "name": "reason_agent",
            "structured_output": {
                "enabled": True,
                "fields": [
                    {"name": "reason", "type": "text", "description": "Return reason", "required": True}
                ]
            }
        }
    }

    def _make_strategy(self):
        engine_context = MagicMock()
        engine_context.get_config_value.side_effect = lambda key, default=None: {
            "rollback_strategy": "history_based",
            "template_loader": Environment()
        }.get(key, default)
        return CollectInputStrategy(self.SO_STEP_CONFIG, engine_context)

    # ------------------------------------------------------------------
    # _generate_prompt: intent_change propagation
    # ------------------------------------------------------------------

    def test_generate_prompt_so_intent_change_with_bot_response(self):
        """intent_change forwarded into prompt_data even when bot_response is present."""
        strategy = self._make_strategy()
        agent = MagicMock()
        agent.invoke.return_value = json.dumps({
            "bot_response": "Let me redirect you.",
            "intent_change": "collect_order_id",
            "reason": None,
        })

        prompt_data = strategy._generate_prompt(agent, [], {})

        assert prompt_data is not None
        assert prompt_data["text"] == "Let me redirect you."
        assert prompt_data["intent_change"] == "collect_order_id"

    def test_generate_prompt_so_intent_change_without_bot_response(self):
        """When bot_response is empty, prompt_data must still be returned (not None)
        and carry intent_change so execute() can route it."""
        strategy = self._make_strategy()
        agent = MagicMock()
        agent.invoke.return_value = json.dumps({
            "bot_response": "",
            "intent_change": "collect_order_id",
            "reason": None,
        })

        prompt_data = strategy._generate_prompt(agent, [], {})

        assert prompt_data is not None, "Should not return None when intent_change is set"
        assert prompt_data["text"] is None
        assert prompt_data["intent_change"] == "collect_order_id"

    def test_generate_prompt_so_out_of_scope_without_bot_response(self):
        """Same as above but for out_of_scope."""
        strategy = self._make_strategy()
        agent = MagicMock()
        agent.invoke.return_value = json.dumps({
            "bot_response": "",
            "out_of_scope": "user is asking about the weather",
            "reason": None,
        })

        prompt_data = strategy._generate_prompt(agent, [], {})

        assert prompt_data is not None, "Should not return None when out_of_scope is set"
        assert prompt_data["text"] is None
        assert prompt_data["out_of_scope"] == "user is asking about the weather"

    def test_generate_prompt_so_no_special_fields_empty_bot_response_still_none(self):
        """Plain SO response with no intent_change / out_of_scope and empty bot_response
        should still return None (existing behaviour unchanged)."""
        strategy = self._make_strategy()
        agent = MagicMock()
        agent.invoke.return_value = json.dumps({
            "bot_response": "",
            "reason": None,
        })

        prompt_data = strategy._generate_prompt(agent, [], {})

        assert prompt_data is None

    # ------------------------------------------------------------------
    # _handle_special_responses: routes intent_change in new prompt_data format
    # ------------------------------------------------------------------

    def test_handle_special_responses_routes_intent_change_from_prompt_data(self):
        """_handle_special_responses must call _handle_intent_change when prompt_data
        carries intent_change (the shape produced by the fixed _generate_prompt)."""
        strategy = self._make_strategy()

        rollback_state = {"_status": "collect_reason_collect_order_id", "order_id": None}
        strategy._handle_intent_change = MagicMock(return_value=rollback_state)

        prompt_data = {
            "text": None,
            "options": [],
            "is_selectable": False,
            "intent_change": "collect_order_id",
        }

        result = strategy._handle_special_responses(prompt_data, state={}, user_message="I want to change my order")

        strategy._handle_intent_change.assert_called_once_with("collect_order_id", {})
        assert result == rollback_state

    def test_handle_special_responses_routes_intent_change_with_bot_response(self):
        """Works identically when text is present alongside intent_change."""
        strategy = self._make_strategy()

        rollback_state = {"_status": "collect_reason_collect_order_id"}
        strategy._handle_intent_change = MagicMock(return_value=rollback_state)

        prompt_data = {
            "text": "Let me redirect you.",
            "options": [],
            "is_selectable": False,
            "intent_change": "collect_order_id",
        }

        result = strategy._handle_special_responses(prompt_data, state={}, user_message="change order")

        strategy._handle_intent_change.assert_called_once()
        assert result == rollback_state
