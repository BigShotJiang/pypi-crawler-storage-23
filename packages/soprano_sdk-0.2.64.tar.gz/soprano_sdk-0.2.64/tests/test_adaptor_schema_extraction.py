"""Test cases for CrewAI adapter schema extraction improvements"""

from unittest.mock import MagicMock, patch
from pydantic import BaseModel, Field
from soprano_sdk.agents.adaptor import CrewAIAgentAdapter


class TestCrewAIAdapterSchemaExtraction:
    """Test improved schema field extraction using .get("properties", {})"""

    def test_schema_extraction_with_properties(self):
        """Test schema extraction when properties field exists"""

        class TestSchema(BaseModel):
            name: str = Field(description="User's name")
            age: int = Field(description="User's age")

        mock_agent = MagicMock()
        mock_result = MagicMock()
        mock_result.raw = '{"name": "John", "age": 30}'
        mock_agent.kickoff.return_value = mock_result

        adapter = CrewAIAgentAdapter(mock_agent, TestSchema)

        # Get the schema
        schema = adapter.output_schema.model_json_schema()
        properties = schema.get("properties", {})

        assert "name" in properties
        assert "age" in properties
        assert properties["name"]["description"] == "User's name"
        assert properties["age"]["description"] == "User's age"

    def test_schema_extraction_without_properties(self):
        """Test schema extraction gracefully handles missing properties field"""

        class EmptySchema(BaseModel):
            pass

        mock_agent = MagicMock()
        adapter = CrewAIAgentAdapter(mock_agent, EmptySchema)

        # Get the schema and ensure .get("properties", {}) returns empty dict
        schema = adapter.output_schema.model_json_schema()
        properties = schema.get("properties", {})

        # Should return empty dict instead of None or KeyError
        assert properties == {}
        assert isinstance(properties, dict)

    def test_schema_with_nested_models(self):
        """Test schema extraction with nested Pydantic models"""

        class Address(BaseModel):
            street: str
            city: str

        class Person(BaseModel):
            name: str
            address: Address

        mock_agent = MagicMock()
        adapter = CrewAIAgentAdapter(mock_agent, Person)

        schema = adapter.output_schema.model_json_schema()
        properties = schema.get("properties", {})

        assert "name" in properties
        assert "address" in properties
        assert isinstance(properties, dict)

    @patch('soprano_sdk.agents.adaptor.logger')
    def test_llm_response_logging(self, mock_logger):
        """Test that LLM response is logged for debugging"""

        class TestSchema(BaseModel):
            captured: bool = Field(description="Data captured")

        mock_agent = MagicMock()
        mock_result = MagicMock()
        mock_result.raw = "Some raw response"
        mock_agent.kickoff.return_value = mock_result

        # Mock LLM call
        mock_llm_response = MagicMock()
        mock_llm_response.content = '{"captured": true}'
        mock_agent.llm.call.return_value = mock_llm_response

        adapter = CrewAIAgentAdapter(mock_agent, TestSchema)

        try:
            adapter.invoke([{"role": "user", "content": "test"}])
        except Exception:
            pass  # May fail due to mocking, but we're testing logging

        # Verify that logger.info was called (LLM response logging)
        assert mock_logger.info.called

    def test_validation_works_without_isinstance_redundancy(self):
        """Test validation after removing redundant isinstance(parsed_dict, dict) check"""

        class TestSchema(BaseModel):
            name: str
            age: int

        mock_agent = MagicMock()
        mock_result = MagicMock()
        mock_result.pydantic = None  # ensure raw path is taken
        mock_result.raw = '{"name": "Alice", "age": 25}'
        mock_agent.kickoff.return_value = mock_result

        adapter = CrewAIAgentAdapter(mock_agent, TestSchema)
        result = adapter.invoke([{"role": "user", "content": "test"}])

        # Should successfully validate
        assert result is not None

    def test_dict_response_validation(self):
        """Test that dict responses are properly validated with schema"""

        class OutputSchema(BaseModel):
            success: bool
            message: str

        mock_agent = MagicMock()
        mock_result = MagicMock()
        mock_result.pydantic = None  # ensure raw path is taken
        mock_result.raw = '{"success": true, "message": "Done"}'
        mock_agent.kickoff.return_value = mock_result

        adapter = CrewAIAgentAdapter(mock_agent, OutputSchema)

        # The adapter should handle validation without the redundant isinstance check
        result = adapter.invoke([{"role": "user", "content": "test"}])
        assert result is not None
