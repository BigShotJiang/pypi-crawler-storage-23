"""
Shared test utilities for collect_input_with_agent tests.
All test modules import from here to avoid duplication.
"""

import json
from pathlib import Path

import httpx
from langgraph.checkpoint.memory import InMemorySaver
from soprano_sdk.tools import WorkflowTool

FAKE_LLM_URL = "http://fake-llm/v1"
FAKE_LLM_COMPLETIONS = f"{FAKE_LLM_URL}/chat/completions"

MODEL_CONFIG = {
    "model_name": "test-model",
    "provider": "openai",
    "api_key": "test-key",
    "base_url": FAKE_LLM_URL,
}

FIXTURES = Path(__file__).parent / "fixtures"


class CapturingCheckpointer(InMemorySaver):
    """InMemorySaver that skips thread deletion so tests can inspect the final
    state with tool.graph.get_state(config) even after the workflow completes."""

    def delete_thread(self, thread_id: str) -> None:  # type: ignore[override]
        pass  # keep checkpoint; tests will clean up naturally when the object is GC'd


def make_tool(yaml_name: str) -> WorkflowTool:
    """Create a WorkflowTool from a fixture YAML file with a CapturingCheckpointer."""
    return WorkflowTool(
        yaml_path=str(FIXTURES / yaml_name),
        name="test",
        description="test",
        checkpointer=CapturingCheckpointer(),
        config={"model_config": MODEL_CONFIG},
    )


def snap(tool: WorkflowTool, tid: str) -> dict:
    """Return a copy of the current checkpointed workflow state."""
    return tool.graph.get_state({"configurable": {"thread_id": tid}}).values


def llm_text_response(content: str) -> httpx.Response:
    """Pattern matching mode: plain text LLM response."""
    return httpx.Response(
        200,
        json={
            "id": "chatcmpl-test",
            "object": "chat.completion",
            "created": 1700000000,
            "model": "test-model",
            "choices": [
                {
                    "index": 0,
                    "message": {"role": "assistant", "content": content},
                    "finish_reason": "stop",
                }
            ],
            "usage": {"prompt_tokens": 10, "completion_tokens": 5, "total_tokens": 15},
        },
    )


def llm_structured_response(fields: dict) -> httpx.Response:
    """Structured output mode: JSON string in message.content (ProviderStrategy / json_schema format)."""
    return httpx.Response(
        200,
        json={
            "id": "chatcmpl-test",
            "object": "chat.completion",
            "created": 1700000000,
            "model": "test-model",
            "choices": [
                {
                    "index": 0,
                    "message": {
                        "role": "assistant",
                        "content": json.dumps(fields),
                    },
                    "finish_reason": "stop",
                }
            ],
            "usage": {"prompt_tokens": 10, "completion_tokens": 10, "total_tokens": 20},
        },
    )
