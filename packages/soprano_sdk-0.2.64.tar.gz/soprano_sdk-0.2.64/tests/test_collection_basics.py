"""
Integration smoke tests — PM and SO happy paths, validator failure, max attempts, pre-population.

Tests the full stack: YAML → WorkflowTool → CollectInputStrategy → real LLM adapters,
with only the HTTP layer mocked via respx.

Architecture notes:
  - The openai SDK v1.x uses httpx internally; respx intercepts httpx requests.
  - base_url: "http://fake-llm/v1" in MODEL_CONFIG routes all LLM calls to the
    mock endpoint http://fake-llm/v1/chat/completions.
  - Pattern matching mode: LLM returns plain text content.
  - Structured output mode: uses ProviderStrategy (json_schema response_format),
    so the LLM response is a JSON string in message.content — NOT tool_calls.
    The Pydantic model name is "NameStructuredOutput" (derived from field name).

State assertions use snap() after every turn to verify correctness at every
checkpoint, whether the call is a fresh start or a resume.

── Coverage Gaps ──
  - SO OPTIONS_DATA: OPTIONS_DATA marker tested only for PM, not SO
  - PM multi-field: Multi-field only tested in SO mode
  - PM boolean transitions: Boolean value matching only tested in SO
  - OOS + validator combination: OOS detection with a validator configured not tested
  - IC + validator combination: IC + validator combo not tested
  - Max attempts + validator: Validator failures counting toward max_attempts not tested
  - Multi-field + OOS/IC: OOS/IC during multi-field collection not tested
  - Partial data + OOS/IC: OOS/IC interrupting partial data accumulation not tested
"""

import uuid

import respx

from tests.helpers import (
    FAKE_LLM_COMPLETIONS,
    llm_structured_response,
    llm_text_response,
    make_tool,
    snap,
)

# ── Conversation / collector constants ────────────────────────────────────────

PM_CONV_KEY = "name_conversation"
SO_CONV_KEY = "name_conversation"
PM_COLLECTOR_NODES = {"collect_name": "Collect name"}
SO_COLLECTOR_NODES = {"collect_name": "Collect name"}


# ── PM: Pattern Matching Tests ────────────────────────────────────────────────


@respx.mock
def test_pm1_happy_path_pattern_matching():
    """PM-1: Happy path — capture on first try (pattern matching mode).

    Turn 1: GraphInterrupt with LLM-generated prompt.
    Turn 2: field set in state, result = success outcome.
    Total: 2 LLM calls.
    """
    responses = iter(
        [
            llm_text_response("What is your name?"),  # turn 1: generate prompt
            llm_text_response("NAME_CAPTURED: John"),  # turn 2: process user input
        ]
    )
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("collect_input_pattern_match.yaml")
    tid = str(uuid.uuid4())

    # ── turn 1: prompt returned as interrupt ──
    result1 = tool.execute(thread_id=tid, initial_context={})
    assert "What is your name?" in str(result1)

    s1 = snap(tool, tid)
    assert s1.get("name") is None                                    # not captured yet
    assert s1["_status"] == "collect_name_collecting"
    assert s1.get("_outcome_id") is None
    assert s1["_collector_nodes"] == {}                              # not registered until done
    assert s1["_node_execution_order"] == []
    assert s1["_validation_errors"] == {}
    assert s1["_pending_prompt"] is not None
    assert s1["_pending_prompt"]["text"] == "What is your name?"
    assert PM_CONV_KEY in s1["_conversations"]
    assert len(s1["_conversations"][PM_CONV_KEY]) == 1              # 1 assistant prompt
    assert s1["_conversations"][PM_CONV_KEY][0]["role"] == "assistant"
    assert respx.calls.call_count == 1

    # ── turn 2: user responds, agent captures ──
    result2 = tool.execute(thread_id=tid, user_message="John", initial_context={})
    assert "Name collected" in str(result2)

    s2 = snap(tool, tid)
    assert s2["name"] == "John"                                      # stripped of "NAME_CAPTURED:"
    assert s2["_status"] == "collect_name_end_success"
    assert s2["_outcome_id"] == "end_success"
    assert s2["_collector_nodes"] == PM_COLLECTOR_NODES
    assert s2["_node_execution_order"] == ["collect_name"]
    assert s2["_node_field_map"] == {"collect_name": "name"}
    assert s2["_validation_errors"] == {}
    assert s2.get("_pending_prompt") is None
    # 3 messages: assistant(prompt) + user + assistant(capture)
    assert len(s2["_conversations"][PM_CONV_KEY]) == 3
    assert s2["_messages"] == ["✓ Name collected: John"]
    assert respx.calls.call_count == 2


@respx.mock
def test_pm2_validator_failure_then_success():
    """PM-2: Validator failure then success (pattern matching mode).

    Turn 1: generate prompt (LLM call 1).
    Turn 2: captures 'J' but validator rejects (< 2 chars) — re-prompt returned.
    Turn 3: captures 'John' — valid — success.
    Total: 3 LLM calls.
    """
    responses = iter(
        [
            llm_text_response("What is your name?"),   # turn 1: prompt
            llm_text_response("NAME_CAPTURED: J"),      # turn 2: captured but invalid
            llm_text_response("NAME_CAPTURED: John"),   # turn 3: valid
        ]
    )
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("collect_input_pattern_match.yaml")
    tid = str(uuid.uuid4())

    result1 = tool.execute(thread_id=tid, initial_context={})
    assert "What is your name?" in str(result1)

    s1 = snap(tool, tid)
    assert s1.get("name") is None
    assert s1["_status"] == "collect_name_collecting"

    # ── turn 2: captures 'J', validator rejects ──
    result2 = tool.execute(thread_id=tid, user_message="J", initial_context={})
    assert "Name collected" not in str(result2)
    assert result2 is not None

    s2 = snap(tool, tid)
    assert s2.get("name") is None                                    # cleared by validator
    assert s2["_status"] == "collect_name_collecting"
    assert s2.get("_outcome_id") is None
    assert s2["_collector_nodes"] == {}
    assert s2["_validation_errors"] == {
        "name": {"value": "J", "error": "Name must be at least 2 characters"}
    }
    assert s2["_pending_prompt"] is not None                         # re-prompt pending
    assert respx.calls.call_count == 2

    # ── turn 3: valid capture ──
    result3 = tool.execute(thread_id=tid, user_message="John", initial_context={})
    assert "Name collected" in str(result3)

    s3 = snap(tool, tid)
    assert s3["name"] == "John"
    assert s3["_status"] == "collect_name_end_success"
    assert s3["_outcome_id"] == "end_success"
    assert s3["_validation_errors"] == {}                            # cleared on success
    assert s3["_collector_nodes"] == PM_COLLECTOR_NODES
    assert respx.calls.call_count == 3


@respx.mock
def test_pm3_max_attempts_pattern_matching():
    """PM-3: Max attempts reached — all collection failures (pattern matching mode).

    retry_limit: 2 means max 2 user messages before max_attempts is triggered.
    Turn 1: generate prompt (LLM call 1).
    Turn 2: no capture — continuation prompt (LLM call 2).
    Turn 3: no capture — max attempts reached, workflow ends (LLM call 3).
    Total: 3 LLM calls, no field ever set, no success outcome.
    """
    responses = iter(
        [
            llm_text_response("What is your name?"),            # turn 1: prompt
            llm_text_response("I didn't catch that."),          # turn 2: no capture
            llm_text_response("I didn't catch that either."),   # turn 3: no capture
        ]
    )
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("collect_input_pattern_match.yaml")
    tid = str(uuid.uuid4())

    # ── turn 1: generates prompt ──
    tool.execute(thread_id=tid, initial_context={})

    s1 = snap(tool, tid)
    assert s1.get("name") is None
    assert s1["_status"] == "collect_name_collecting"
    assert respx.calls.call_count == 1

    # ── turn 2: no-match → user_count=1, not yet max ──
    tool.execute(thread_id=tid, user_message="hmm", initial_context={})

    s2 = snap(tool, tid)
    assert s2.get("name") is None
    assert s2["_status"] == "collect_name_collecting"               # still collecting
    assert s2["_collector_nodes"] == {}
    assert respx.calls.call_count == 2

    # ── turn 3: no-match → user_count=2 >= retry_limit=2 → max_attempts ──
    result = tool.execute(thread_id=tid, user_message="dunno", initial_context={})

    assert "Name collected" not in str(result)

    s3 = snap(tool, tid)
    assert s3.get("name") is None
    assert s3["_status"] == "collect_name_max_attempts"
    assert s3.get("_outcome_id") is None                            # no outcome reached
    assert s3["_collector_nodes"] == {}
    assert s3["_node_execution_order"] == []
    assert respx.calls.call_count == 3


@respx.mock
def test_pm4_prepopulated_from_initial_context():
    """PM-4: Pre-populated from initial_context — no LLM calls at all.

    When name is provided in initial_context, the field is pre-populated
    before any agent is created, so no HTTP call to the LLM is made.
    """
    tool = make_tool("collect_input_pattern_match.yaml")
    tid = str(uuid.uuid4())

    result = tool.execute(thread_id=tid, initial_context={"name": "John"})
    assert "Name collected" in str(result)

    s1 = snap(tool, tid)
    assert s1["name"] == "John"                                     # from initial_context
    assert s1["_status"] == "collect_name_end_success"
    assert s1["_outcome_id"] == "end_success"
    assert s1["_collector_nodes"] == PM_COLLECTOR_NODES
    assert s1["_node_execution_order"] == ["collect_name"]
    assert s1["_node_field_map"] == {"collect_name": "name"}
    assert s1["_validation_errors"] == {}
    assert s1.get("_pending_prompt") is None
    assert s1["_conversations"].get(PM_CONV_KEY, []) == []          # no LLM conversation
    assert s1["_messages"] == []                                    # no agent messages
    assert respx.calls.call_count == 0


# ── SO: Structured Output Tests ───────────────────────────────────────────────


@respx.mock
def test_so1_happy_path_structured_output():
    """SO-1: Happy path — capture on first try (structured output mode).

    LangChain ProviderStrategy uses json_schema response_format. The model
    returns a JSON string in message.content (not tool_calls).
    Schema class name: NameStructuredOutput (derived from field name 'name').

    Turn 1: bot_response set → GraphInterrupt with prompt.
    Turn 2: captured_name=true, name='John' → field set, success.
    Total: 2 LLM calls.
    """
    responses = iter(
        [
            llm_structured_response(  # turn 1: generate prompt
                {
                    "bot_response": "What is your name?",
                    "captured_name": None,
                    "name": None,
                    "options": None,
                    "is_selectable": None,
                }
            ),
            llm_structured_response(  # turn 2: capture
                {
                    "bot_response": None,
                    "captured_name": True,
                    "name": "John",
                    "options": None,
                    "is_selectable": None,
                }
            ),
        ]
    )
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("collect_input_structured_output.yaml")
    tid = str(uuid.uuid4())

    # ── turn 1: prompt returned as interrupt ──
    result1 = tool.execute(thread_id=tid, initial_context={})
    assert "What is your name?" in str(result1)

    s1 = snap(tool, tid)
    assert s1.get("name") is None
    assert s1["_status"] == "collect_name_collecting"
    assert s1.get("_outcome_id") is None
    assert s1["_collector_nodes"] == {}
    assert s1["_validation_errors"] == {}
    assert s1["_pending_prompt"] is not None
    assert s1["_pending_prompt"]["text"] == "What is your name?"
    assert SO_CONV_KEY in s1["_conversations"]
    assert len(s1["_conversations"][SO_CONV_KEY]) == 1
    assert respx.calls.call_count == 1

    # ── turn 2: user responds, agent captures ──
    result2 = tool.execute(thread_id=tid, user_message="John", initial_context={})
    assert "Name collected" in str(result2)

    s2 = snap(tool, tid)
    assert isinstance(s2["name"], dict)                             # SO stores full dict
    assert s2["name"].get("name") == "John"
    assert s2["name"].get("captured_name") is True
    assert s2["_status"] == "collect_name_end_success"
    assert s2["_outcome_id"] == "end_success"
    assert s2["_collector_nodes"] == SO_COLLECTOR_NODES
    assert s2["_node_execution_order"] == ["collect_name"]
    assert s2["_node_field_map"] == {"collect_name": "name"}
    assert s2["_validation_errors"] == {}
    assert s2.get("_pending_prompt") is None
    # 3 messages: assistant(prompt) + user + assistant(capture)
    assert len(s2["_conversations"][SO_CONV_KEY]) == 3
    assert len(s2["_messages"]) == 1
    assert respx.calls.call_count == 2


@respx.mock
def test_so2_validator_failure_structured_output():
    """SO-2: Validator failure then success (structured output mode).

    Turn 1: bot_response set — GraphInterrupt (LLM call 1).
    Turn 2: captures 'J' (invalid, < 2 chars) — validation error, re-prompt (LLM call 2).
    Turn 3: captures 'John' (valid) — success (LLM call 3).
    Total: 3 LLM calls.
    """
    responses = iter(
        [
            llm_structured_response(  # turn 1: prompt
                {
                    "bot_response": "What is your name?",
                    "captured_name": None,
                    "name": None,
                    "options": None,
                    "is_selectable": None,
                }
            ),
            llm_structured_response(  # turn 2: captures "J" (invalid)
                {
                    "bot_response": None,
                    "captured_name": True,
                    "name": "J",
                    "options": None,
                    "is_selectable": None,
                }
            ),
            llm_structured_response(  # turn 3: valid capture
                {
                    "bot_response": None,
                    "captured_name": True,
                    "name": "John",
                    "options": None,
                    "is_selectable": None,
                }
            ),
        ]
    )
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("collect_input_structured_output.yaml")
    tid = str(uuid.uuid4())

    tool.execute(thread_id=tid, initial_context={})

    # ── turn 2: captures 'J', validator rejects ──
    result2 = tool.execute(thread_id=tid, user_message="J", initial_context={})
    assert "Name collected" not in str(result2)

    s2 = snap(tool, tid)
    assert s2.get("name") is None                                  # cleared by validator
    assert s2["_status"] == "collect_name_collecting"
    assert s2.get("_outcome_id") is None
    assert "name" in s2["_validation_errors"]
    assert s2["_validation_errors"]["name"]["error"] == "Name must be at least 2 characters"
    assert s2["_collector_nodes"] == {}
    assert s2["_pending_prompt"] is not None
    assert respx.calls.call_count == 2

    # ── turn 3: valid capture ──
    result3 = tool.execute(thread_id=tid, user_message="John", initial_context={})
    assert "Name collected" in str(result3)

    s3 = snap(tool, tid)
    assert s3["name"].get("name") == "John"
    assert s3["_status"] == "collect_name_end_success"
    assert s3["_outcome_id"] == "end_success"
    assert s3["_validation_errors"] == {}                           # cleared on success
    assert s3["_collector_nodes"] == SO_COLLECTOR_NODES
    assert respx.calls.call_count == 3


@respx.mock
def test_so3_prepopulated_structured_output():
    """SO-3: Pre-populated from initial_context (structured output mode).

    Same as PM-4: field is pre-populated before any agent is created,
    so no HTTP call to the LLM is made.

    For SO mode, a string pre-pop value falls through to transitions[0] fallback.
    The string is stored as-is (no dict transformation for pre-pop strings).
    """
    tool = make_tool("collect_input_structured_output.yaml")
    tid = str(uuid.uuid4())

    result = tool.execute(thread_id=tid, initial_context={"name": "John"})
    assert "Name collected" in str(result)

    s1 = snap(tool, tid)
    assert s1["name"] == "John"                                    # string from initial_context
    assert s1["_status"] == "collect_name_end_success"
    assert s1["_outcome_id"] == "end_success"
    assert s1["_collector_nodes"] == SO_COLLECTOR_NODES
    assert s1["_validation_errors"] == {}
    assert s1.get("_pending_prompt") is None
    assert s1["_conversations"].get(SO_CONV_KEY, []) == []
    assert s1["_messages"] == []
    assert respx.calls.call_count == 0
