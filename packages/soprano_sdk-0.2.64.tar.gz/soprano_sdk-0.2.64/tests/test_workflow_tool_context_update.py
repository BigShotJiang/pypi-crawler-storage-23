"""Tests for WorkflowTool context update behavior fix."""

from unittest.mock import MagicMock, patch
from soprano_sdk.tools import WorkflowTool
from soprano_sdk.core.constants import WorkflowKeys
from soprano_sdk.core.models import MessagePayload


class TestWorkflowToolContextUpdateFix:
    """Test suite for WorkflowTool context update fix.

    On resume, collector node fields from initial_context are filtered out
    to prevent overriding state. Non-collector fields (e.g. bearer_token)
    pass through so they can be refreshed each turn.
    """

    @patch('soprano_sdk.tools.load_workflow')
    @patch('soprano_sdk.utils.tracing.trace_workflow_execution')
    @patch('soprano_sdk.tools.CallbackHandler')
    def test_resume_filters_collector_fields_and_passes_non_collector_fields(
        self, mock_callback_handler, mock_trace, mock_load_workflow
    ):
        """On resume, collector node fields are filtered out but non-collector
        fields like bearer_token pass through for per-turn refresh."""
        # Setup mocks
        mock_graph = MagicMock()
        mock_engine = MagicMock()
        mock_load_workflow.return_value = (mock_graph, mock_engine)

        # Mock trace context manager
        mock_span = MagicMock()
        mock_trace.return_value.__enter__.return_value = mock_span

        # Mock workflow state - simulate interrupted workflow (state.next is truthy)
        mock_state = MagicMock()
        mock_state.next = ["some_next_state"]  # Truthy value indicates interrupted
        mock_graph.get_state.return_value = mock_state

        # Collector node field map — order_id is a collector field
        mock_engine.collector_node_field_map = {
            "collect_order_id": "order_id",
        }

        # Mock result
        mock_result = {"outcome": "test"}
        mock_graph.invoke.return_value = mock_result
        mock_engine.get_outcome_message.return_value = MessagePayload("Success", None, False)

        # Create workflow tool
        workflow = WorkflowTool(
            yaml_path="test.yaml",
            name="TestWorkflow",
            description="Test workflow",
        )

        # Execute with initial_context while resuming
        # order_id is a collector field (should be filtered)
        # bearer_token is not (should pass through)
        initial_context = {"order_id": "123", "bearer_token": "tok_refreshed"}
        _ = workflow.execute(
            thread_id="test-thread",
            user_message="Continue",
            initial_context=initial_context,
        )

        # Only non-collector fields should reach update_context
        mock_engine.update_context.assert_called_once()
        called_context = mock_engine.update_context.call_args[0][0]
        assert "order_id" not in called_context
        assert called_context["bearer_token"] == "tok_refreshed"

        # Verify workflow was resumed with Command
        assert mock_graph.invoke.called
        call_args = mock_graph.invoke.call_args
        from langgraph.types import Command
        assert isinstance(call_args[0][0], Command)

    @patch('soprano_sdk.tools.load_workflow')
    @patch('soprano_sdk.utils.tracing.trace_workflow_execution')
    @patch('soprano_sdk.tools.CallbackHandler')
    def test_context_updated_when_starting_fresh_workflow(
        self, mock_callback_handler, mock_trace, mock_load_workflow
    ):
        """Test that context IS updated when starting a fresh workflow."""
        # Setup mocks
        mock_graph = MagicMock()
        mock_engine = MagicMock()
        mock_load_workflow.return_value = (mock_graph, mock_engine)

        # Mock trace context manager
        mock_span = MagicMock()
        mock_trace.return_value.__enter__.return_value = mock_span

        # Mock workflow state - simulate fresh start (state.next is empty/falsy)
        mock_state = MagicMock()
        mock_state.next = []  # Empty list indicates not interrupted
        mock_graph.get_state.return_value = mock_state

        # Mock result
        mock_result = {"outcome": "test"}
        mock_graph.invoke.return_value = mock_result
        mock_engine.get_outcome_message.return_value = MessagePayload("Success", None, False)

        # Create workflow tool
        workflow = WorkflowTool(
            yaml_path="test.yaml",
            name="TestWorkflow",
            description="Test workflow"
        )

        # Execute with initial_context for fresh start
        initial_context = {"order_id": "123", "user_id": "456"}
        _ = workflow.execute(
            thread_id="test-thread",
            user_message=None,
            initial_context=initial_context
        )

        # Verify that update_context WAS called with correct context (expected behavior)
        mock_engine.update_context.assert_called_once_with(initial_context)

        # Verify workflow was invoked with raw context
        assert mock_graph.invoke.called
        call_args = mock_graph.invoke.call_args
        # Should be called with raw context dict including user_message
        assert call_args[0][0] == {"order_id": "123", "user_id": "456", WorkflowKeys.USER_MESSAGE: ""}

    @patch('soprano_sdk.tools.load_workflow')
    @patch('soprano_sdk.utils.tracing.trace_workflow_execution')
    @patch('soprano_sdk.tools.CallbackHandler')
    def test_context_updated_when_state_next_is_none(
        self, mock_callback_handler, mock_trace, mock_load_workflow
    ):
        """Test that context IS updated when state.next is None (completed workflow)."""
        # Setup mocks
        mock_graph = MagicMock()
        mock_engine = MagicMock()
        mock_load_workflow.return_value = (mock_graph, mock_engine)

        # Mock trace context manager
        mock_span = MagicMock()
        mock_trace.return_value.__enter__.return_value = mock_span

        # Mock workflow state - simulate completed workflow (state.next is None)
        mock_state = MagicMock()
        mock_state.next = None  # None indicates not interrupted
        mock_graph.get_state.return_value = mock_state

        # Mock result
        mock_result = {"outcome": "test"}
        mock_graph.invoke.return_value = mock_result
        mock_engine.get_outcome_message.return_value = MessagePayload("Success", None, False)

        # Create workflow tool
        workflow = WorkflowTool(
            yaml_path="test.yaml",
            name="TestWorkflow",
            description="Test workflow"
        )

        # Execute with initial_context
        initial_context = {"order_id": "789"}
        _ = workflow.execute(
            thread_id="test-thread-2",
            user_message=None,
            initial_context=initial_context
        )

        # Verify that update_context WAS called (expected behavior)
        mock_engine.update_context.assert_called_once_with(initial_context)

    @patch('soprano_sdk.tools.load_workflow')
    @patch('soprano_sdk.utils.tracing.trace_workflow_execution')
    @patch('soprano_sdk.tools.CallbackHandler')
    def test_resume_interrupted_workflow_filters_collector_passes_bearer_token(
        self, mock_callback_handler, mock_trace, mock_load_workflow
    ):
        """On resume with interrupt result, collector fields are filtered and
        non-collector fields like bearer_token pass through."""
        # Setup mocks
        mock_graph = MagicMock()
        mock_engine = MagicMock()
        mock_load_workflow.return_value = (mock_graph, mock_engine)

        # Mock trace context manager
        mock_span = MagicMock()
        mock_trace.return_value.__enter__.return_value = mock_span

        # Mock workflow state - interrupted
        mock_state = MagicMock()
        mock_state.next = ["waiting_for_input"]
        mock_graph.get_state.return_value = mock_state

        mock_engine.collector_node_field_map = {
            "collect_order_id": "order_id",
        }

        # Mock result with interrupt
        mock_interrupt = MagicMock()
        mock_interrupt.value = "Please provide your order ID"
        mock_result = {"__interrupt__": [mock_interrupt]}
        mock_graph.invoke.return_value = mock_result

        # Create workflow tool
        workflow = WorkflowTool(
            yaml_path="test.yaml",
            name="TestWorkflow",
            description="Test workflow",
        )

        # Execute - resuming with collector field + non-collector field
        initial_context = {"order_id": "wrong_value", "bearer_token": "tok_new"}
        result = workflow.execute(
            thread_id="test-thread",
            user_message="12345",
            initial_context=initial_context,
        )

        # Only bearer_token should reach update_context
        mock_engine.update_context.assert_called_once()
        called_context = mock_engine.update_context.call_args[0][0]
        assert "order_id" not in called_context
        assert called_context["bearer_token"] == "tok_new"

        # Should return interrupt string
        assert "__WORKFLOW_INTERRUPT__|test-thread|TestWorkflow|Please provide your order ID" == result

    @patch('soprano_sdk.tools.load_workflow')
    @patch('soprano_sdk.utils.tracing.trace_workflow_execution')
    @patch('soprano_sdk.tools.CallbackHandler')
    def test_context_update_with_empty_initial_context(
        self, mock_callback_handler, mock_trace, mock_load_workflow
    ):
        """Test that update_context is called with empty dict when no initial_context provided."""
        # Setup mocks
        mock_graph = MagicMock()
        mock_engine = MagicMock()
        mock_load_workflow.return_value = (mock_graph, mock_engine)

        # Mock trace context manager
        mock_span = MagicMock()
        mock_trace.return_value.__enter__.return_value = mock_span

        # Mock workflow state - fresh start
        mock_state = MagicMock()
        mock_state.next = None
        mock_graph.get_state.return_value = mock_state

        # Mock result
        mock_result = {"outcome": "test"}
        mock_graph.invoke.return_value = mock_result
        mock_engine.get_outcome_message.return_value = MessagePayload("Success", None, False)

        # Create workflow tool
        workflow = WorkflowTool(
            yaml_path="test.yaml",
            name="TestWorkflow",
            description="Test workflow"
        )

        # Execute with empty dict initial_context
        _ = workflow.execute(thread_id="test-thread", initial_context={})

        # Verify that update_context was called with empty dict
        mock_engine.update_context.assert_called_once_with({})


class TestWorkflowToolContextUpdateWithAsyncInterrupt:
    """Test context update behavior with async interrupts."""

    @patch('soprano_sdk.tools.load_workflow')
    @patch('soprano_sdk.utils.tracing.trace_workflow_execution')
    @patch('soprano_sdk.tools.CallbackHandler')
    def test_async_resume_filters_collector_fields_passes_bearer_token(
        self, mock_callback_handler, mock_trace, mock_load_workflow
    ):
        """On async resume, collector fields are filtered and non-collector
        fields like bearer_token pass through."""
        # Setup mocks
        mock_graph = MagicMock()
        mock_engine = MagicMock()
        mock_load_workflow.return_value = (mock_graph, mock_engine)

        # Mock trace context manager
        mock_span = MagicMock()
        mock_trace.return_value.__enter__.return_value = mock_span

        # Mock workflow state - interrupted
        mock_state = MagicMock()
        mock_state.next = ["async_step"]
        mock_graph.get_state.return_value = mock_state

        mock_engine.collector_node_field_map = {
            "collect_customer_id": "customer_id",
            "collect_amount": "payment_amount",
        }

        # Mock result with async interrupt
        mock_interrupt = MagicMock()
        mock_interrupt.value = {
            "type": "async",
            "step_id": "payment_processing",
            "pending": {"transaction_id": "txn_123"}
        }
        mock_result = {"__interrupt__": [mock_interrupt]}
        mock_graph.invoke.return_value = mock_result

        # Create workflow tool
        workflow = WorkflowTool(
            yaml_path="test.yaml",
            name="TestWorkflow",
            description="Test workflow",
        )

        # Execute - resuming with collector + non-collector fields
        initial_context = {
            "customer_id": "wrong_id",
            "bearer_token": "tok_refreshed",
            "conversation_history": [{"role": "user", "content": "hi"}],
        }
        result = workflow.execute(
            thread_id="test-thread",
            user_message="Continue",
            initial_context=initial_context,
        )

        # Only non-collector fields should reach update_context
        mock_engine.update_context.assert_called_once()
        called_context = mock_engine.update_context.call_args[0][0]
        assert "customer_id" not in called_context
        assert called_context["bearer_token"] == "tok_refreshed"
        assert called_context["conversation_history"] == [{"role": "user", "content": "hi"}]

        # Should return async interrupt string
        assert result.startswith("__ASYNC_INTERRUPT__|test-thread|TestWorkflow|")


class TestBuildFieldDetails:
    """Tests for WorkflowEngine.build_field_details()."""

    def _make_engine(self, data_fields, collector_map):
        from soprano_sdk.core.engine import WorkflowEngine
        engine = MagicMock(spec=WorkflowEngine)
        engine.data_fields = data_fields
        engine.collector_node_field_map = collector_map
        engine._get_current_node_fields = WorkflowEngine._get_current_node_fields.__get__(engine)
        engine.build_field_details = WorkflowEngine.build_field_details.__get__(engine)
        return engine

    def test_returns_current_node_fields_only(self):
        """Only fields belonging to the active collector node are returned."""
        engine = self._make_engine(
            data_fields=[
                {"name": "email", "type": "text"},
                {"name": "phone", "type": "text"},
                {"name": "order_id", "type": "text"},
            ],
            collector_map={
                "collect_contact": ["email", "phone"],
                "collect_order": "order_id",
            },
        )
        state = {
            "email": "a@b.com", "phone": "123", "order_id": "ORD-1",
            WorkflowKeys.STATUS: "collect_contact_collecting",
            WorkflowKeys.VALIDATION_ERRORS: {},
        }
        result = engine.build_field_details(state)
        assert result == [
            {"name": "email", "value": "a@b.com"},
            {"name": "phone", "value": "123"},
        ]

    def test_validation_errors_use_failed_value(self):
        """Fields with validation errors show the value that failed, not None."""
        engine = self._make_engine(
            data_fields=[
                {"name": "email", "type": "text"},
                {"name": "phone", "type": "text"},
            ],
            collector_map={"collect_contact": ["email", "phone"]},
        )
        state = {
            "email": None,  # Cleared by validation
            "phone": "1234567890",
            WorkflowKeys.STATUS: "collect_contact_collecting",
            WorkflowKeys.VALIDATION_ERRORS: {
                "email": {"value": "bad@", "error": "Invalid email format"}
            },
        }
        result = engine.build_field_details(state)
        assert result == [
            {"name": "email", "value": "bad@", "error": "Invalid email format"},
            {"name": "phone", "value": "1234567890"},
        ]

    def test_single_field_node(self):
        """Works for single-field collector nodes (field stored as string, not list)."""
        engine = self._make_engine(
            data_fields=[
                {"name": "order_id", "type": "text"},
                {"name": "email", "type": "text"},
            ],
            collector_map={"collect_order": "order_id", "collect_email": "email"},
        )
        state = {
            "order_id": "ORD-1", "email": None,
            WorkflowKeys.STATUS: "collect_order_collecting",
            WorkflowKeys.VALIDATION_ERRORS: {},
        }
        result = engine.build_field_details(state)
        assert result == [
            {"name": "order_id", "value": "ORD-1"},
        ]

    def test_no_active_collector_returns_empty(self):
        """Returns empty list when status doesn't match any collector node."""
        engine = self._make_engine(
            data_fields=[{"name": "email", "type": "text"}],
            collector_map={"collect_email": "email"},
        )
        state = {
            "email": "a@b.com",
            WorkflowKeys.STATUS: "check_eligibility_success",
            WorkflowKeys.VALIDATION_ERRORS: {},
        }
        result = engine.build_field_details(state)
        assert result == []

    def test_no_status_in_state_returns_empty(self):
        """Returns empty list when _status is missing from state."""
        engine = self._make_engine(
            data_fields=[{"name": "name", "type": "text"}],
            collector_map={"collect_name": "name"},
        )
        state = {"name": "Alice"}
        result = engine.build_field_details(state)
        assert result == []

    def test_label_included_when_present(self):
        """Fields with label show it in field_details."""
        engine = self._make_engine(
            data_fields=[
                {"name": "email", "type": "text", "label": "Email Address"},
                {"name": "phone", "type": "text", "label": "Phone Number"},
            ],
            collector_map={"collect_contact": ["email", "phone"]},
        )
        state = {
            "email": "test@example.com",
            "phone": "1234567890",
            WorkflowKeys.STATUS: "collect_contact_collecting",
            WorkflowKeys.VALIDATION_ERRORS: {},
        }
        result = engine.build_field_details(state)
        assert result == [
            {"name": "email", "value": "test@example.com", "label": "Email Address"},
            {"name": "phone", "value": "1234567890", "label": "Phone Number"},
        ]

    def test_label_optional(self):
        """Fields without label still work (backward compatibility)."""
        engine = self._make_engine(
            data_fields=[
                {"name": "email", "type": "text"},  # No label
                {"name": "phone", "type": "text", "label": "Phone Number"},
            ],
            collector_map={"collect_contact": ["email", "phone"]},
        )
        state = {
            "email": "test@example.com",
            "phone": "1234567890",
            WorkflowKeys.STATUS: "collect_contact_collecting",
            WorkflowKeys.VALIDATION_ERRORS: {},
        }
        result = engine.build_field_details(state)
        assert result == [
            {"name": "email", "value": "test@example.com"},  # No label in result
            {"name": "phone", "value": "1234567890", "label": "Phone Number"},
        ]

