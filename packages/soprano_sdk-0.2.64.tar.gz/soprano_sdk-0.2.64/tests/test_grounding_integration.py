"""
Integration tests for Bedrock Guardrails grounding check.

These tests call the real AWS Bedrock ApplyGuardrail API and require:
  - BEDROCK_GUARDRAIL_ID  (env var)
  - AWS credentials configured (via env vars, profile, or IAM role)
  - Optionally: AWS_REGION_NAME, BEDROCK_GUARDRAIL_VERSION

Run with:
    pytest tests/test_grounding_integration.py -v

Skipped automatically when BEDROCK_GUARDRAIL_ID is not set.
"""

import os

import pytest

from soprano_sdk.guardrails.grounding_guardrail import (
    GroundingCheckConfig,
    GroundingGuardrail,
)
from soprano_sdk.guardrails.base_guardrail import GuardrailResult

# ---------------------------------------------------------------------------
# Skip condition
# ---------------------------------------------------------------------------
requires_bedrock = pytest.mark.skipif(
    not os.environ.get("BEDROCK_GUARDRAIL_ID"),
    reason="BEDROCK_GUARDRAIL_ID not set; skipping Bedrock integration tests",
)

# ---------------------------------------------------------------------------
# Shared fixture
# ---------------------------------------------------------------------------

@pytest.fixture(scope="module")
def grounding_config():
    """Build a GroundingCheckConfig from the live environment."""
    return GroundingCheckConfig()


# ---------------------------------------------------------------------------
# Test data — designed to be threshold-resilient
# ---------------------------------------------------------------------------

GROUNDING_SOURCE_RETURNS = (
    "AGENT INSTRUCTIONS:\n"
    "You are a customer service agent for Acme Corp. "
    "You help customers with return requests. "
    "Our return policy allows returns within 30 days of purchase. "
    "The customer must have a valid order ID. "
    "Eligible return reasons are: damaged item, wrong item, defective product. "
    "Refunds are processed within 5-7 business days to the original payment method.\n\n"
    "WORKFLOW DATA:\n"
    "Order ID: ORD-98765\n"
    "Order Date: 2026-01-15\n"
    "Item: Wireless Headphones\n"
    "Price: $79.99\n"
    "Return window: Open (within 30 days)"
)

GROUNDED_QUERY = (
    "Can I return my headphones? What is the return policy and how long will "
    "the refund take?"
)

GROUNDED_RESPONSE = (
    "Yes, your order ORD-98765 for the Wireless Headphones is within the 30-day "
    "return window. Eligible return reasons are damaged item, wrong item, or "
    "defective product. Refunds are processed within 5-7 business days to "
    "the original payment method."
)

UNGROUNDED_RESPONSE_FABRICATED = (
    "Sure! You can call our returns hotline at 1-800-555-RETURN or visit "
    "www.acme-returns.com/portal to process your return online. Our premium "
    "customers also get a 90-day extended return window with free pickup service."
)

UNGROUNDED_RESPONSE_HALLUCINATED = (
    "Your order ORD-98765 was shipped from our warehouse in Tokyo, Japan. "
    "We offer a full 365-day return policy with complimentary gift wrapping "
    "for all replacement items. Your refund of $149.99 has already been initiated."
)


# ---------------------------------------------------------------------------
# TestCheckGroundingLive — core grounding check tests
# ---------------------------------------------------------------------------

@requires_bedrock
@pytest.mark.integration
class TestCheckGroundingLive:
    """Integration tests that call the real Bedrock ApplyGuardrail API."""

    def test_grounded_response_passes(self, grounding_config):
        """A response that restates facts from the grounding source should pass."""
        config_dict = vars(grounding_config)
        result = GroundingGuardrail(error_message="", **config_dict).check(
            response=GROUNDED_RESPONSE,
            grounding_source=GROUNDING_SOURCE_RETURNS,
            query=GROUNDED_QUERY,
        )

        assert isinstance(result, GuardrailResult)
        assert result.passed is True
        assert result.metadata.get('action') == "NONE"
        assert result.metadata.get('grounding_score') is not None
        assert isinstance(result.metadata.get('grounding_score'), (int, float))

    def test_ungrounded_fabricated_info_fails(self, grounding_config):
        """A response with fabricated phone numbers and URLs should fail grounding."""
        config_dict = vars(grounding_config)
        result = GroundingGuardrail(error_message="", **config_dict).check(
            response=UNGROUNDED_RESPONSE_FABRICATED,
            grounding_source=GROUNDING_SOURCE_RETURNS,
            query=GROUNDED_QUERY,
        )

        assert isinstance(result, GuardrailResult)
        assert result.passed is False
        assert result.metadata.get('action') == "GUARDRAIL_INTERVENED"

    def test_ungrounded_hallucinated_facts_fails(self, grounding_config):
        """A response with invented facts (wrong price, Tokyo warehouse) should fail."""
        config_dict = vars(grounding_config)
        result = GroundingGuardrail(error_message="", **config_dict).check(
            response=UNGROUNDED_RESPONSE_HALLUCINATED,
            grounding_source=GROUNDING_SOURCE_RETURNS,
            query=GROUNDED_QUERY,
        )

        assert isinstance(result, GuardrailResult)
        assert result.passed is False
        assert result.metadata.get('action') == "GUARDRAIL_INTERVENED"

    def test_result_structure_has_valid_scores(self, grounding_config):
        """Verify the result structure contains numeric scores and a valid action."""
        config_dict = vars(grounding_config)
        result = GroundingGuardrail(error_message="", **config_dict).check(
            response=GROUNDED_RESPONSE,
            grounding_source=GROUNDING_SOURCE_RETURNS,
            query=GROUNDED_QUERY,
        )

        grounding_score = result.metadata.get('grounding_score')
        relevance_score = result.metadata.get('relevance_score')

        assert grounding_score is None or isinstance(grounding_score, (int, float))
        assert relevance_score is None or isinstance(relevance_score, (int, float))

        if grounding_score is not None:
            assert 0.0 <= grounding_score <= 1.0
        if relevance_score is not None:
            assert 0.0 <= relevance_score <= 1.0

        assert result.metadata.get('action') in ("NONE", "GUARDRAIL_INTERVENED")

    def test_grounded_score_higher_for_grounded_response(self, grounding_config):
        """Grounded response should have a higher grounding score than ungrounded."""
        config_dict = vars(grounding_config)
        grounded_result = GroundingGuardrail(error_message="", **config_dict).check(
            response=GROUNDED_RESPONSE,
            grounding_source=GROUNDING_SOURCE_RETURNS,
            query=GROUNDED_QUERY,
        )
        ungrounded_result = GroundingGuardrail(error_message="", **config_dict).check(
            response=UNGROUNDED_RESPONSE_FABRICATED,
            grounding_source=GROUNDING_SOURCE_RETURNS,
            query=GROUNDED_QUERY,
        )

        grounded_score = grounded_result.metadata.get('grounding_score')
        ungrounded_score = ungrounded_result.metadata.get('grounding_score')

        assert grounded_score is not None
        assert ungrounded_score is not None
        assert grounded_score > ungrounded_score


# ---------------------------------------------------------------------------
# TestEdgeCasesLive — edge case handling with the real API
# ---------------------------------------------------------------------------

@requires_bedrock
@pytest.mark.integration
class TestEdgeCasesLive:
    """Edge case integration tests with the real Bedrock API."""

    def test_empty_agent_response(self, grounding_config):
        """Empty agent response should not crash — returns a valid result."""
        config_dict = vars(grounding_config)
        result = GroundingGuardrail(error_message="", **config_dict).check(
            response="",
            grounding_source=GROUNDING_SOURCE_RETURNS,
            query=GROUNDED_QUERY,
        )
        assert isinstance(result, GuardrailResult)
        assert result.metadata.get('action') in ("NONE", "GUARDRAIL_INTERVENED")

    def test_very_short_inputs(self, grounding_config):
        """Very short inputs should still return a valid result."""
        config_dict = vars(grounding_config)
        result = GroundingGuardrail(error_message="", **config_dict).check(
            response="OK",
            grounding_source="Help with returns.",
            query="hi",
        )
        assert isinstance(result, GuardrailResult)
        assert result.metadata.get('action') in ("NONE", "GUARDRAIL_INTERVENED")

    def test_response_identical_to_source(self, grounding_config):
        """Response that is a verbatim copy of the source should be grounded."""
        source_text = "Our return policy allows returns within 30 days of purchase."
        config_dict = vars(grounding_config)
        result = GroundingGuardrail(error_message="", **config_dict).check(
            response=source_text,
            grounding_source=source_text,
            query="What is the return policy?",
        )
        assert isinstance(result, GuardrailResult)
        assert result.passed is True

    def test_completely_irrelevant_response(self, grounding_config):
        """A response about a completely different topic should fail grounding."""
        config_dict = vars(grounding_config)
        result = GroundingGuardrail(error_message="", **config_dict).check(
            response=(
                "The mitochondria is the powerhouse of the cell. "
                "Photosynthesis converts carbon dioxide and water into glucose."
            ),
            grounding_source=GROUNDING_SOURCE_RETURNS,
            query="Can I return my order?",
        )
        assert isinstance(result, GuardrailResult)
        assert result.passed is False

    def test_empty_grounding_source(self, grounding_config):
        """Empty grounding source should be handled gracefully."""
        config_dict = vars(grounding_config)
        result = GroundingGuardrail(error_message="", **config_dict).check(
            response="Here is your order status.",
            grounding_source="",
            query="What is my order status?",
        )
        # Should not crash regardless of API behavior
        assert isinstance(result, GuardrailResult)

    def test_empty_query(self, grounding_config):
        """Empty query should be handled gracefully."""
        config_dict = vars(grounding_config)
        result = GroundingGuardrail(error_message="", **config_dict).check(
            response=GROUNDED_RESPONSE,
            grounding_source=GROUNDING_SOURCE_RETURNS,
            query="",
        )
        assert isinstance(result, GuardrailResult)


# ---------------------------------------------------------------------------
# TestToolOutputRephrasing — agent rephrases tool output, meaning preserved
# ---------------------------------------------------------------------------

# Simulates a tool returning structured JSON about order eligibility
TOOL_OUTPUT_ORDER_LOOKUP = (
    '{"order_id": "ORD-55123", "customer_name": "Sarah Johnson", '
    '"item": "Bluetooth Speaker", "purchase_date": "2026-02-01", '
    '"price": 49.99, "return_eligible": true, '
    '"return_deadline": "2026-03-03", "payment_method": "Visa ending 4242"}'
)

TOOL_OUTPUT_GROUNDING_SOURCE = (
    "AGENT INSTRUCTIONS:\n"
    "You are a customer service agent. Help customers check return eligibility. "
    "Present the tool results clearly to the customer. "
    "Only share information that was returned by the tool.\n\n"
    "TOOL OUTPUTS:\n"
    + TOOL_OUTPUT_ORDER_LOOKUP
)

TOOL_OUTPUT_QUERY = "Is my order ORD-55123 eligible for return?"


@requires_bedrock
@pytest.mark.integration
class TestToolOutputRephrasing:
    """Tests where the agent rephrases tool output in natural language.

    The agent should be allowed to rephrase structured tool output into
    conversational text as long as the semantic meaning is preserved.
    """

    def test_rephrased_tool_output_passes(self, grounding_config):
        """Agent rephrases JSON tool output into natural language — should pass."""
        config_dict = vars(grounding_config)
        result = GroundingGuardrail(error_message="", **config_dict).check(
            response=(
                "Great news, Sarah! Your order ORD-55123 for the Bluetooth Speaker "
                "is eligible for return. You have until March 3rd, 2026 to initiate "
                "the return. The refund of $49.99 will go back to your Visa ending "
                "in 4242."
            ),
            grounding_source=TOOL_OUTPUT_GROUNDING_SOURCE,
            query=TOOL_OUTPUT_QUERY,
        )
        assert result.passed is True

    def test_rephrased_with_different_wording_passes(self, grounding_config):
        """Agent uses completely different phrasing but same facts — should pass."""
        config_dict = vars(grounding_config)
        result = GroundingGuardrail(error_message="", **config_dict).check(
            response=(
                "I've checked your order and here's what I found: Order ORD-55123 "
                "for a Bluetooth Speaker purchased on February 1st is still within "
                "the return window. The last date to return it is March 3rd, 2026. "
                "Your refund of $49.99 would be credited to Visa ending 4242."
            ),
            grounding_source=TOOL_OUTPUT_GROUNDING_SOURCE,
            query=TOOL_OUTPUT_QUERY,
        )
        assert result.passed is True

    def test_partial_tool_output_passes(self, grounding_config):
        """Agent shares only a subset of tool output — should pass."""
        config_dict = vars(grounding_config)
        result = GroundingGuardrail(error_message="", **config_dict).check(
            response=(
                "Yes, your order ORD-55123 is eligible for return. "
                "You have until March 3rd to return it."
            ),
            grounding_source=TOOL_OUTPUT_GROUNDING_SOURCE,
            query=TOOL_OUTPUT_QUERY,
        )
        assert result.passed is True

    def test_rephrased_with_fabricated_extras_fails(self, grounding_config):
        """Agent rephrases tool output but adds fabricated details — should fail."""
        config_dict = vars(grounding_config)
        result = GroundingGuardrail(error_message="", **config_dict).check(
            response=(
                "Your order ORD-55123 for the Bluetooth Speaker is eligible for "
                "return. You can drop it off at any of our 500 retail locations "
                "nationwide or schedule a free doorstep pickup by calling "
                "1-800-RETURNS. As a loyalty member, you also qualify for an "
                "instant exchange with free expedited shipping."
            ),
            grounding_source=TOOL_OUTPUT_GROUNDING_SOURCE,
            query=TOOL_OUTPUT_QUERY,
        )
        assert result.passed is False

    def test_rephrased_with_wrong_values_fails(self, grounding_config):
        """Agent rephrases tool output but changes key values — should fail."""
        config_dict = vars(grounding_config)
        result = GroundingGuardrail(error_message="", **config_dict).check(
            response=(
                "Your order ORD-55123 for the Bluetooth Speaker is eligible for "
                "return. The refund of $99.99 will be processed to your "
                "Mastercard ending in 8888. You have until April 15th to "
                "complete the return."
            ),
            grounding_source=TOOL_OUTPUT_GROUNDING_SOURCE,
            query=TOOL_OUTPUT_QUERY,
        )
        assert result.passed is False


# ---------------------------------------------------------------------------
# TestGroundingConfigFromEnv — config reads env vars correctly
# ---------------------------------------------------------------------------

@requires_bedrock
@pytest.mark.integration
class TestGroundingConfigFromEnv:
    """Verify that GroundingCheckConfig correctly reads from the live environment."""

    def test_config_loads_guardrail_id(self):
        """Config should pick up the BEDROCK_GUARDRAIL_ID env var."""
        config = GroundingCheckConfig()
        assert config.bedrock_guardrail_id is not None
        assert len(config.bedrock_guardrail_id) > 0

    def test_config_has_valid_version(self):
        """Config version should be a non-empty string."""
        config = GroundingCheckConfig()
        assert config.bedrock_guardrail_version is not None
        assert len(config.bedrock_guardrail_version) > 0


# ---------------------------------------------------------------------------
# TestLangGraphToolOutputPipeline — end-to-end: LangGraph → tool capture → grounding
# ---------------------------------------------------------------------------

requires_openai = pytest.mark.skipif(
    not os.environ.get("OPENAI_API_KEY"),
    reason="OPENAI_API_KEY not set; skipping LangGraph integration tests",
)


def _lookup_order(order_id: str) -> str:
    """Look up an order by its ID and return order details as JSON."""
    # Deterministic tool — always returns the same data for testing
    return (
        '{"order_id": "ORD-77001", "customer_name": "Alice Chen", '
        '"item": "Noise-Cancelling Headphones", "purchase_date": "2026-02-10", '
        '"price": 129.99, "return_eligible": true, '
        '"return_deadline": "2026-03-12", "payment_method": "Amex ending 1234"}'
    )


@requires_bedrock
@requires_openai
@pytest.mark.integration
class TestLangGraphToolOutputPipeline:
    """End-to-end tests: LangGraph agent calls a tool → adapter captures output
    → tool output is included in grounding source → grounding check passes/fails.

    Requires both OPENAI_API_KEY and BEDROCK_GUARDRAIL_ID.
    """

    @pytest.fixture(scope="class")
    def langgraph_adapter(self):
        """Create a real LangGraph agent with a lookup_order tool."""
        from soprano_sdk.agents.factory import AgentFactory

        model_config = {
            "model_name": "gpt-4o-mini",
            "provider": "openai",
            "api_key": os.environ["OPENAI_API_KEY"],
        }

        tools = [
            (
                "lookup_order",
                "Look up an order by its ID and return order details as JSON.",
                _lookup_order,
            )
        ]

        system_prompt = (
            "You are a customer service agent. When a customer asks about an order, "
            "use the lookup_order tool to find the order details. "
            "Then present the information clearly to the customer. "
            "Only share information that was returned by the tool."
        )

        adapter = AgentFactory.create_agent(
            framework="langgraph",
            name="test_order_agent",
            model_config=model_config,
            tools=tools,
            system_prompt=system_prompt,
            structured_output_model=None,
        )
        return adapter

    def test_tool_outputs_captured(self, langgraph_adapter):
        """After invoking the agent, last_tool_outputs should contain the tool result."""
        messages = [
            {"role": "user", "content": "Can you look up order ORD-77001?"},
        ]
        langgraph_adapter.invoke(messages)

        assert len(langgraph_adapter.last_tool_outputs) > 0
        # The tool returns JSON containing ORD-77001
        combined = " ".join(langgraph_adapter.last_tool_outputs)
        assert "ORD-77001" in combined

    def test_agent_response_grounded_in_tool_output(self, langgraph_adapter, grounding_config):
        """Agent response based on tool output should pass the grounding check.

        This is the full pipeline: LangGraph invocation → tool capture → grounding.
        """
        messages = [
            {"role": "user", "content": "Is order ORD-77001 eligible for return?"},
        ]
        agent_response = langgraph_adapter.invoke(messages)

        # Tool outputs should have been captured
        assert len(langgraph_adapter.last_tool_outputs) > 0

        # Build grounding source the same way _build_grounding_source does
        tool_text = "\n".join(langgraph_adapter.last_tool_outputs)
        grounding_source = (
            "AGENT INSTRUCTIONS:\n"
            "You are a customer service agent. When a customer asks about an order, "
            "use the lookup_order tool to find the order details. "
            "Then present the information clearly to the customer. "
            "Only share information that was returned by the tool.\n\n"
            f"TOOL OUTPUTS:\n{tool_text}"
        )

        config_dict = vars(grounding_config)
        result = GroundingGuardrail(error_message="", **config_dict).check(
            response=str(agent_response),
            grounding_source=grounding_source,
            query="Is order ORD-77001 eligible for return?",
        )

        assert result.passed is True

    def test_fabricated_response_fails_against_tool_output(self, langgraph_adapter, grounding_config):
        """A fabricated response should fail grounding even when real tool output is present."""
        messages = [
            {"role": "user", "content": "Look up order ORD-77001 please."},
        ]
        langgraph_adapter.invoke(messages)

        # Build grounding source from actual captured tool output
        tool_text = "\n".join(langgraph_adapter.last_tool_outputs)
        grounding_source = (
            "AGENT INSTRUCTIONS:\n"
            "You are a customer service agent. Only share information from the tool.\n\n"
            f"TOOL OUTPUTS:\n{tool_text}"
        )

        # Fabricated response: wrong price, wrong payment method, invented details
        fabricated_response = (
            "Order ORD-77001 for the Noise-Cancelling Headphones costs $299.99. "
            "It was paid with a Discover card ending 9999. You can return it at any "
            "of our 200 retail stores or call 1-888-RETURNS for a free home pickup."
        )

        config_dict = vars(grounding_config)
        result = GroundingGuardrail(error_message="", **config_dict).check(
            response=fabricated_response,
            grounding_source=grounding_source,
            query="Look up order ORD-77001 please.",
        )

        assert result.passed is False
