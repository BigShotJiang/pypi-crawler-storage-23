"""
Tests for Bedrock Guardrails grounding check functionality.
"""
import os
from unittest.mock import MagicMock, patch

from soprano_sdk.guardrails.grounding_guardrail import (
    GroundingCheckConfig,
    GroundingGuardrail,
    _truncate,
)
from soprano_sdk.guardrails.base_guardrail import GuardrailResult
from soprano_sdk.nodes.collect_input import CollectInputStrategy


# ---------------------------------------------------------------------------
# GroundingCheckConfig
# ---------------------------------------------------------------------------

class TestGroundingCheckConfig:

    def test_defaults_when_no_env_vars(self):
        with patch.dict(os.environ, {}, clear=True):
            config = GroundingCheckConfig(
                _env_file=None,
                bedrock_guardrail_id=None,
                bedrock_guardrail_version="DRAFT",
                aws_region_name=None,
            )
        assert config.bedrock_guardrail_id is None
        assert config.bedrock_guardrail_version == "DRAFT"
        assert config.aws_region_name is None

    def test_reads_from_env_vars(self):
        env = {
            "BEDROCK_GUARDRAIL_ID": "gr-test-123",
            "BEDROCK_GUARDRAIL_VERSION": "3",
            "AWS_REGION_NAME": "us-west-2",
        }
        with patch.dict(os.environ, env, clear=True):
            config = GroundingCheckConfig(_env_file=None)
        assert config.bedrock_guardrail_id == "gr-test-123"
        assert config.bedrock_guardrail_version == "3"
        assert config.aws_region_name == "us-west-2"

    def test_partial_env_vars(self):
        env = {"BEDROCK_GUARDRAIL_ID": "gr-abc"}
        with patch.dict(os.environ, env, clear=True):
            config = GroundingCheckConfig(_env_file=None)
        assert config.bedrock_guardrail_id == "gr-abc"
        assert config.bedrock_guardrail_version == "DRAFT"
        assert config.aws_region_name is None


# ---------------------------------------------------------------------------
# GuardrailResult (from base_guardrail)
# ---------------------------------------------------------------------------

class TestGuardrailResult:

    def test_passed_result(self):
        result = GuardrailResult(
            passed=True,
            metadata={"grounding_score": 0.95, "relevance_score": 0.88, "action": "NONE"}
        )
        assert result.passed is True
        assert result.metadata["action"] == "NONE"

    def test_failed_result(self):
        result = GuardrailResult(
            passed=False,
            error_message="Response not grounded",
            metadata={"grounding_score": 0.3, "action": "GUARDRAIL_INTERVENED"}
        )
        assert result.passed is False
        assert result.metadata["grounding_score"] == 0.3

    def test_defaults(self):
        result = GuardrailResult(passed=True)
        assert result.error_message is None
        assert result.metadata == {}


# ---------------------------------------------------------------------------
# _truncate helper
# ---------------------------------------------------------------------------

class TestTruncate:

    def test_no_truncation_needed(self):
        text = "short text"
        assert _truncate(text, 100, "test") == text

    def test_truncation_applied(self):
        text = "a" * 200
        result = _truncate(text, 100, "test")
        assert len(result) == 100

    def test_exact_length(self):
        text = "a" * 100
        assert _truncate(text, 100, "test") == text


# ---------------------------------------------------------------------------
# GroundingGuardrail.check()
# ---------------------------------------------------------------------------

class TestGroundingGuardrailCheck:

    def test_skips_when_no_guardrail_id(self):
        guardrail = GroundingGuardrail(
            error_message="Not grounded",
            bedrock_guardrail_id=None,
        )
        result = guardrail.check(
            response="Hello",
            grounding_source="instructions",
            query="hi",
        )
        assert result.passed is True

    @patch("soprano_sdk.guardrails.grounding_guardrail.boto3")
    def test_grounded_response(self, mock_boto3):
        mock_client = MagicMock()
        mock_boto3.Session.return_value.client.return_value = mock_client
        mock_client.apply_guardrail.return_value = {
            "action": "NONE",
            "assessments": [{
                "contextualGroundingPolicy": {
                    "filters": [
                        {"type": "GROUNDING", "score": 0.95, "action": "NONE"},
                        {"type": "RELEVANCE", "score": 0.88, "action": "NONE"},
                    ]
                }
            }]
        }

        guardrail = GroundingGuardrail(
            error_message="Not grounded",
            bedrock_guardrail_id="gr-test",
            bedrock_guardrail_version="1",
            aws_region_name="us-east-1",
        )
        result = guardrail.check(
            response="Your order is eligible for return.",
            grounding_source="Agent instructions: help with returns.",
            query="Can I return my order?",
        )

        assert result.passed is True
        assert result.metadata["grounding_score"] == 0.95
        assert result.metadata["relevance_score"] == 0.88
        assert result.metadata["action"] == "NONE"

        mock_client.apply_guardrail.assert_called_once()
        call_kwargs = mock_client.apply_guardrail.call_args[1]
        assert call_kwargs["guardrailIdentifier"] == "gr-test"
        assert call_kwargs["guardrailVersion"] == "1"
        assert call_kwargs["source"] == "OUTPUT"
        assert len(call_kwargs["content"]) == 3

    @patch("soprano_sdk.guardrails.grounding_guardrail.boto3")
    def test_not_grounded_response(self, mock_boto3):
        mock_client = MagicMock()
        mock_boto3.Session.return_value.client.return_value = mock_client
        mock_client.apply_guardrail.return_value = {
            "action": "GUARDRAIL_INTERVENED",
            "assessments": [{
                "contextualGroundingPolicy": {
                    "filters": [
                        {"type": "GROUNDING", "score": 0.2, "action": "BLOCKED"},
                        {"type": "RELEVANCE", "score": 0.9, "action": "NONE"},
                    ]
                }
            }]
        }

        guardrail = GroundingGuardrail(
            error_message="Not grounded",
            bedrock_guardrail_id="gr-test",
            bedrock_guardrail_version="1",
        )
        result = guardrail.check(
            response="Call us at 1-800-FAKE-NUM for assistance.",
            grounding_source="Agent instructions: collect order ID.",
            query="What is your phone number?",
        )

        assert result.passed is False
        assert result.metadata.get("grounding_score") == 0.2
        assert result.metadata.get("action") == "GUARDRAIL_INTERVENED"

    @patch("soprano_sdk.guardrails.grounding_guardrail.boto3")
    def test_fail_open_on_api_error(self, mock_boto3):
        from soprano_sdk.guardrails.base_guardrail import GuardrailsConnectionError

        mock_client = MagicMock()
        mock_boto3.Session.return_value.client.return_value = mock_client
        mock_client.apply_guardrail.side_effect = Exception("API timeout")

        guardrail = GroundingGuardrail(
            error_message="Not grounded",
            bedrock_guardrail_id="gr-test",
        )

        # New behavior: raises GuardrailsConnectionError instead of failing open
        try:
            guardrail.check(
                response="Hello",
                grounding_source="instructions",
                query="hi",
            )
            assert False, "Expected GuardrailsConnectionError to be raised"
        except GuardrailsConnectionError as e:
            assert "failed to reach Bedrock" in str(e)

    def test_fail_open_when_boto3_missing(self):
        from soprano_sdk.guardrails.base_guardrail import GuardrailsConnectionError

        with patch("soprano_sdk.guardrails.grounding_guardrail.boto3", None):
            guardrail = GroundingGuardrail(
                error_message="Not grounded",
                bedrock_guardrail_id="gr-test",
            )
            try:
                guardrail.check(
                    response="Hello",
                    grounding_source="instructions",
                    query="hi",
                )
                assert False, "Expected GuardrailsConnectionError to be raised"
            except GuardrailsConnectionError as e:
                assert "boto3 is not installed" in str(e)

    @patch("soprano_sdk.guardrails.grounding_guardrail.boto3")
    def test_content_structure(self, mock_boto3):
        """Verify the three content blocks are structured correctly."""
        mock_client = MagicMock()
        mock_boto3.Session.return_value.client.return_value = mock_client
        mock_client.apply_guardrail.return_value = {
            "action": "NONE",
            "assessments": []
        }

        guardrail = GroundingGuardrail(
            error_message="Not grounded",
            bedrock_guardrail_id="gr-test",
            bedrock_guardrail_version="1",
            aws_region_name="us-west-2",
        )
        guardrail.check(
            response="The response",
            grounding_source="The source",
            query="The query",
        )

        content = mock_client.apply_guardrail.call_args[1]["content"]

        # First block: grounding_source
        assert content[0]["text"]["qualifiers"] == ["grounding_source"]
        assert content[0]["text"]["text"] == "The source"

        # Second block: query
        assert content[1]["text"]["qualifiers"] == ["query"]
        assert content[1]["text"]["text"] == "The query"

        # Third block: guard_content
        assert content[2]["text"]["qualifiers"] == ["guard_content"]
        assert content[2]["text"]["text"] == "The response"

    @patch("soprano_sdk.guardrails.grounding_guardrail.boto3")
    def test_region_passed_to_client(self, mock_boto3):
        mock_client = MagicMock()
        mock_boto3.Session.return_value.client.return_value = mock_client
        mock_client.apply_guardrail.return_value = {"action": "NONE", "assessments": []}

        guardrail = GroundingGuardrail(
            error_message="Not grounded",
            bedrock_guardrail_id="gr-test",
            aws_region_name="eu-west-1",
        )
        guardrail.check(
            response="resp",
            grounding_source="source",
            query="query",
        )

        mock_boto3.Session.assert_called_once_with(region_name="eu-west-1")
        mock_boto3.Session.return_value.client.assert_called_once_with("bedrock-runtime")

    @patch("soprano_sdk.guardrails.grounding_guardrail.boto3")
    def test_no_region_omits_kwarg(self, mock_boto3):
        mock_client = MagicMock()
        mock_boto3.Session.return_value.client.return_value = mock_client
        mock_client.apply_guardrail.return_value = {"action": "NONE", "assessments": []}

        guardrail = GroundingGuardrail(
            error_message="Not grounded",
            bedrock_guardrail_id="gr-test",
            aws_region_name=None,
        )
        guardrail.check(
            response="resp",
            grounding_source="source",
            query="query",
        )

        mock_boto3.Session.assert_called_once_with()
        mock_boto3.Session.return_value.client.assert_called_once_with("bedrock-runtime")

    @patch("soprano_sdk.guardrails.grounding_guardrail.boto3")
    def test_empty_assessments(self, mock_boto3):
        """No contextualGroundingPolicy in assessments — scores should be None."""
        mock_client = MagicMock()
        mock_boto3.Session.return_value.client.return_value = mock_client
        mock_client.apply_guardrail.return_value = {
            "action": "NONE",
            "assessments": [{}]
        }

        guardrail = GroundingGuardrail(
            error_message="Not grounded",
            bedrock_guardrail_id="gr-test",
        )
        result = guardrail.check(
            response="resp",
            grounding_source="source",
            query="query",
        )
        assert result.passed is True
        assert result.metadata.get("grounding_score") is None
        assert result.metadata.get("relevance_score") is None


# ---------------------------------------------------------------------------
# CollectInputStrategy grounding config (via guardrail registry)
# ---------------------------------------------------------------------------

class TestCollectInputStrategyGroundingConfig:

    def _create_strategy(self, agent_config=None, registry=None):
        step_config = {
            "id": "test_step",
            "field": "test_field",
            "agent": agent_config or {"name": "test_agent"},
        }
        engine_context = MagicMock()
        engine_context.get_config_value.side_effect = lambda key, default=None: {
            "rollback_strategy": "history_based",
        }.get(key, default)
        engine_context.mfa_validator_steps = set()
        engine_context.workflow_description = "Test workflow"
        engine_context.guardrail_registry = registry or {}
        return CollectInputStrategy(step_config, engine_context)

    def test_grounding_check_disabled_by_default(self):
        strategy = self._create_strategy()
        assert strategy.output_guardrails == []

    @patch("soprano_sdk.guardrails.grounding_guardrail.boto3")
    def test_grounding_check_can_be_enabled_via_registry(self, mock_boto3):
        guardrail = GroundingGuardrail(
            error_message="Not grounded",
            bedrock_guardrail_id="gr-test",
        )
        strategy = self._create_strategy(
            agent_config={"name": "test_agent", "guardrails": ["grounding_check"]},
            registry={"grounding_check": guardrail},
        )
        assert len(strategy.output_guardrails) == 1
        assert isinstance(strategy.output_guardrails[0], GroundingGuardrail)

    def test_grounding_check_explicit_false(self):
        # No guardrails in agent config → empty list
        strategy = self._create_strategy(
            agent_config={"name": "test_agent"},
        )
        assert strategy.output_guardrails == []


# ---------------------------------------------------------------------------
# _extract_conversational_text
# ---------------------------------------------------------------------------

class TestExtractConversationalText:

    def _create_strategy(self, is_structured_output=False, transitions=None):
        agent_config = {"name": "test_agent"}
        if is_structured_output:
            agent_config["structured_output"] = {
                "enabled": True,
                "fields": [{"name": "order_id", "type": "text", "description": "Order ID"}]
            }

        step_config = {
            "id": "test_step",
            "field": "order_id",
            "agent": agent_config,
        }
        if transitions:
            step_config["transitions"] = transitions

        engine_context = MagicMock()
        engine_context.get_config_value.side_effect = lambda key, default=None: {
            "rollback_strategy": "history_based",
        }.get(key, default)
        engine_context.mfa_validator_steps = set()
        engine_context.workflow_description = "Test workflow"
        return CollectInputStrategy(step_config, engine_context)

    def test_structured_output_with_bot_response(self):
        strategy = self._create_strategy(is_structured_output=True)
        result = strategy._extract_conversational_text(
            {"bot_response": "What is your order ID?", "order_id": None}
        )
        assert result == "What is your order ID?"

    def test_structured_output_without_bot_response(self):
        strategy = self._create_strategy(is_structured_output=True)
        result = strategy._extract_conversational_text(
            {"order_id": "12345"}
        )
        assert result is None

    def test_structured_output_empty_bot_response(self):
        strategy = self._create_strategy(is_structured_output=True)
        result = strategy._extract_conversational_text(
            {"bot_response": "  ", "order_id": "12345"}
        )
        assert result is None

    def test_pattern_matching_extraction_response(self):
        strategy = self._create_strategy(
            transitions=[{"pattern": "ORDER_ID_CAPTURED:", "next": "check"}]
        )
        result = strategy._extract_conversational_text(
            "ORDER_ID_CAPTURED: 12345"
        )
        assert result is None

    def test_pattern_matching_conversational_response(self):
        strategy = self._create_strategy(
            transitions=[{"pattern": "ORDER_ID_CAPTURED:", "next": "check"}]
        )
        result = strategy._extract_conversational_text(
            "Could you please provide your order ID?"
        )
        assert result == "Could you please provide your order ID?"

    def test_pattern_matching_empty_response(self):
        strategy = self._create_strategy()
        result = strategy._extract_conversational_text("")
        assert result is None


# ---------------------------------------------------------------------------
# _build_grounding_source
# ---------------------------------------------------------------------------

class TestBuildGroundingSource:

    def _create_strategy(self):
        step_config = {
            "id": "test_step",
            "field": "order_id",
            "agent": {"name": "test_agent", "instructions": "Collect the order ID."},
        }
        engine_context = MagicMock()
        engine_context.get_config_value.side_effect = lambda key, default=None: {
            "rollback_strategy": "history_based",
        }.get(key, default)
        engine_context.mfa_validator_steps = set()
        engine_context.workflow_description = "Test workflow"
        engine_context.get_localization_instructions.return_value = ""
        return CollectInputStrategy(step_config, engine_context)

    def test_includes_instructions(self):
        strategy = self._create_strategy()
        agent = MagicMock()
        agent.last_tool_outputs = []
        state = {}

        source = strategy._build_grounding_source(state, agent)
        assert "AGENT INSTRUCTIONS:" in source
        assert "Collect the order ID." in source

    def test_includes_tool_outputs(self):
        strategy = self._create_strategy()
        agent = MagicMock()
        agent.last_tool_outputs = ["Order #123 placed on Jan 15", "Eligible for return"]
        state = {}

        source = strategy._build_grounding_source(state, agent)
        assert "TOOL OUTPUTS:" in source
        assert "Order #123 placed on Jan 15" in source
        assert "Eligible for return" in source

    def test_no_tool_outputs(self):
        strategy = self._create_strategy()
        agent = MagicMock()
        agent.last_tool_outputs = []
        state = {}

        source = strategy._build_grounding_source(state, agent)
        assert "TOOL OUTPUTS:" not in source

    def test_agent_without_tool_outputs_attr(self):
        strategy = self._create_strategy()
        agent = MagicMock(spec=[])  # No attributes
        state = {}

        source = strategy._build_grounding_source(state, agent)
        assert "TOOL OUTPUTS:" not in source


# ---------------------------------------------------------------------------
# Grounding guardrail via agent adapter (new architecture)
# ---------------------------------------------------------------------------

class TestGroundingViaAdapter:
    """Grounding is now enforced inside agent.invoke() via adapter._run_guardrails()."""

    def _create_strategy(self, transitions=None, registry=None):
        step_config = {
            "id": "test_step",
            "field": "order_id",
            "agent": {
                "name": "test_agent",
                "instructions": "Collect the order ID.",
                "guardrails": list(registry.keys()) if registry else [],
            },
        }
        if transitions:
            step_config["transitions"] = transitions

        engine_context = MagicMock()
        engine_context.get_config_value.side_effect = lambda key, default=None: {
            "rollback_strategy": "history_based",
        }.get(key, default)
        engine_context.mfa_validator_steps = set()
        engine_context.workflow_description = "Test workflow"
        engine_context.get_localization_instructions.return_value = ""
        engine_context.guardrail_registry = registry or {}
        return CollectInputStrategy(step_config, engine_context)

    def _make_mock_guardrail(self, max_retries=0):
        mock_guardrail = MagicMock(spec=GroundingGuardrail)
        mock_guardrail.max_retries = max_retries
        return mock_guardrail

    def test_grounded_response_passes_through(self):
        """When grounding passes, _get_agent_response returns the agent response."""
        mock_guardrail = self._make_mock_guardrail()

        strategy = self._create_strategy(
            transitions=[{"pattern": "ORDER_ID_CAPTURED:", "next": "check"}],
            registry={"grounding_check": mock_guardrail},
        )
        agent = MagicMock()
        agent.last_tool_outputs = []
        agent.guardrail_context = {}
        agent.invoke.return_value = "Please provide your order ID."

        conversation = [{"role": "user", "content": "I want to return my order"}]
        result = strategy._get_agent_response(agent, conversation, {})

        assert result == "Please provide your order ID."

    def test_guardrail_violation_becomes_failure_response(self):
        """When guardrail raises GuardrailViolationError, a GuardrailFailureResponse is returned."""
        from soprano_sdk.guardrails.base_guardrail import GuardrailViolationError
        from soprano_sdk.nodes.collect_input import GuardrailFailureResponse

        mock_guardrail = self._make_mock_guardrail(max_retries=0)
        strategy = self._create_strategy(
            registry={"grounding_check": mock_guardrail},
        )
        agent = MagicMock()
        agent.last_tool_outputs = []
        agent.guardrail_context = {}
        agent.invoke.side_effect = GuardrailViolationError("Not grounded.")

        conversation = [{"role": "user", "content": "hi"}]
        result = strategy._get_agent_response(agent, conversation, {})

        assert isinstance(result, GuardrailFailureResponse)
        assert result.error_message == "Not grounded."

    def test_guardrail_context_set_on_agent_before_invoke(self):
        """guardrail_context (grounding_source, query) is set on agent before invoke."""
        mock_guardrail = self._make_mock_guardrail()
        strategy = self._create_strategy(registry={"grounding_check": mock_guardrail})

        agent = MagicMock()
        agent.last_tool_outputs = []
        agent.invoke.return_value = "Hello"
        agent.guardrail_context = {}

        conversation = [{"role": "user", "content": "what is my order status?"}]
        strategy._get_agent_response(agent, conversation, {})

        # Context must be set before invoke so adapter can use it
        assert "grounding_source" in agent.guardrail_context
        assert agent.guardrail_context["query"] == "what is my order status?"

    def test_no_guardrails_skips_context_setting(self):
        """When no guardrails configured, guardrail_context is never explicitly assigned."""
        strategy = self._create_strategy()  # no registry → output_guardrails is []
        assert strategy.output_guardrails == []

        agent = MagicMock()
        agent.last_tool_outputs = []
        agent.invoke.return_value = "Hello"

        conversation = [{"role": "user", "content": "hi"}]
        strategy._get_agent_response(agent, conversation, {})

        # The guardrail_context attribute on the MagicMock was never set by _get_agent_response
        agent.assert_not_called()  # no explicit set calls on the mock for guardrail_context
        # Just verify invoke was called once without errors
        agent.invoke.assert_called_once()


# ---------------------------------------------------------------------------
# LangGraphAgentAdapter tool output capture
# ---------------------------------------------------------------------------

class TestLangGraphAdapterToolOutputs:

    def test_captures_tool_messages(self):
        from soprano_sdk.agents.adaptor import LangGraphAgentAdapter

        tool_msg = MagicMock()
        tool_msg.type = "tool"
        tool_msg.content = "Order 123 is eligible for return"

        ai_msg = MagicMock()
        ai_msg.type = "ai"
        ai_msg.content = "Your order is eligible for return."

        mock_agent = MagicMock()
        mock_agent.invoke.return_value = {
            "messages": [tool_msg, ai_msg],
        }

        adapter = LangGraphAgentAdapter(mock_agent)
        adapter.invoke([{"role": "user", "content": "check order"}])

        assert len(adapter.last_tool_outputs) == 1
        assert adapter.last_tool_outputs[0] == "Order 123 is eligible for return"

    def test_no_tool_messages(self):
        from soprano_sdk.agents.adaptor import LangGraphAgentAdapter

        ai_msg = MagicMock()
        ai_msg.type = "ai"
        ai_msg.content = "Hello!"

        mock_agent = MagicMock()
        mock_agent.invoke.return_value = {
            "messages": [ai_msg],
        }

        adapter = LangGraphAgentAdapter(mock_agent)
        adapter.invoke([{"role": "user", "content": "hi"}])

        assert adapter.last_tool_outputs == []

    def test_initial_tool_outputs_empty(self):
        from soprano_sdk.agents.adaptor import LangGraphAgentAdapter

        mock_agent = MagicMock()
        adapter = LangGraphAgentAdapter(mock_agent)
        assert adapter.last_tool_outputs == []
