def validate_name(name, **kwargs):
    # In structured output mode the primary field holds the full response dict;
    # extract the actual name string from it when that's the case.
    if isinstance(name, dict):
        actual_name = name.get("name")
    else:
        actual_name = name
    if not actual_name or len(str(actual_name).strip()) < 2:
        return False, "Name must be at least 2 characters"
    return True, None


def validate_status(status, **kwargs):
    """Status value must be at least 3 characters.

    Used with pm_multi_transition_validator.yaml.
    In PM mode, `status` is always a plain string (the captured value after
    the pattern prefix has been stripped).
    """
    if not status or len(str(status).strip()) < 3:
        return False, "Status must be at least 3 characters"
    return True, None


def validate_first_name(first_name, **kwargs):
    """Validates the first_name field (must be >= 2 chars).

    Used with so_multi_field_validator.yaml.
    The validator is called with **state so `first_name` maps to state['first_name'].
    """
    if not first_name or len(str(first_name).strip()) < 2:
        return False, "First name must be at least 2 characters"
    return True, None


def validate_profile(profile, **kwargs):
    """Validates the profile dict from SO mode.

    Used with so_partial_data.yaml.
    In SO mode, `profile` holds the full field_values dict captured by the agent.
    """
    if not isinstance(profile, dict):
        return False, "Profile must be a dictionary"
    first_name = profile.get("first_name")
    if not first_name or len(str(first_name).strip()) < 2:
        return False, "First name must be at least 2 characters"
    return True, None


def validate_choice(choice_data, **kwargs):
    """Rejects 'invalid_choice' as the choice_value.

    Used with so_multi_transition_validator.yaml.
    In SO mode, `choice_data` holds the full field_values dict captured by
    the structured output agent, e.g. {"captured": True, "choice_value": "option_a"}.
    In pre-populated mode it may also be passed as a plain dict.
    """
    if isinstance(choice_data, dict):
        choice_value = choice_data.get("choice_value")
        if choice_value == "invalid_choice":
            return False, "'invalid_choice' is not a valid option"
    return True, None
