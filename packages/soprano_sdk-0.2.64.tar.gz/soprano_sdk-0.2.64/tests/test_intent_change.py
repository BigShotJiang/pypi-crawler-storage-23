"""
Intent-change (IC) detection tests for collect_input_with_agent.

Covers PM IC (rollback + re-prompt) and SO IC (initial-run intent change).

Groups covered:
  Group 20: PM IC rollback (test_ic_pm_1_intent_change_rollback_and_recollects)
            SO IC on initial run, no bot_response (test_ic_so_1)
            SO IC on initial run, with bot_response (test_ic_so_2)
  Group 21: Whitespace regression (test_ic_pm_2_leading_whitespace_still_detected)

Coverage gaps (not in this file):
  - OOS tests -> test_out_of_scope.py
  - First-entry with user_message -> test_first_entry.py
  - Multi-field SO -> test_so_multifield.py
  - PM/SO basic transitions -> test_pm_collection.py / test_so_collection.py
"""

import uuid

import respx

from soprano_sdk.core.constants import InterruptType

from tests.helpers import (
    FAKE_LLM_COMPLETIONS,
    llm_structured_response,
    llm_text_response,
    make_tool,
    snap,
)


# ── Group 20: PM Intent Change ─────────────────────────────────────────────────


@respx.mock
def test_ic_pm_1_intent_change_rollback_and_recollects():
    """PM: INTENT_CHANGE -> rollback -> fresh re-prompt -> re-collect -> outcome.

    Turn 1: LLM generates opening prompt.
    Turn 2 (user says "go back"):
        LLM#2 returns "INTENT_CHANGE: collect_status"
        -> rollback restores pre-collection snapshot (status cleared, conv cleared)
        -> _status set to "collect_status_collect_status" -> router routes to node
        -> LLM#3 generates fresh re-prompt (all within same execute() call)
        -> result2 = USER_INPUT with fresh prompt
    Turn 3 (user provides valid answer):
        LLM#4 -> "STATUS_A: active" -> outcome_a -> "Status A set"

    Verifies:
    - result2 is USER_INPUT with fresh re-prompt (not a completion)
    - After T2: status=None (cleared), _status=collecting, pending_prompt=new
    - After T3: status="active", _outcome_id="outcome_a"
    - Total: 4 LLM calls (T2 triggers 2: IC detection + re-prompt)

    Mechanism: `_rollback_state_to_node` sets _status = "collect_status_collect_status".
    Router extracts target "collect_status" -> self-loops back to node -> first entry
    re-runs _generate_prompt -> new LLM call -> new prompt.
    """
    responses = iter([
        llm_text_response("What is your status?"),               # T1: prompt
        llm_text_response("INTENT_CHANGE: collect_status"),      # T2: IC detected
        llm_text_response("What is your status (2nd attempt)?"), # T2: re-prompt
        llm_text_response("STATUS_A: active"),                   # T3: capture
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("pm_out_of_scope.yaml")
    tid = str(uuid.uuid4())

    # T1: initial prompt
    result1 = tool.execute(thread_id=tid, initial_context={})
    s1 = snap(tool, tid)
    assert InterruptType.USER_INPUT in str(result1)
    assert "What is your status?" in str(result1)
    assert s1.get("status") is None
    assert s1["_status"] == "collect_status_collecting"

    # T2: intent change -> rollback + re-prompt happen in same execute()
    result2 = tool.execute(thread_id=tid, user_message="go back", initial_context={})
    s2 = snap(tool, tid)

    # result2 is a new USER_INPUT interrupt with the fresh re-prompt
    assert InterruptType.USER_INPUT in str(result2)
    assert "2nd attempt" in str(result2)
    assert InterruptType.OUT_OF_SCOPE not in str(result2)
    assert "Status A set" not in str(result2)

    # State after T2: status cleared, re-entered collecting state
    assert s2.get("status") is None                      # cleared by rollback
    assert s2["_status"] == "collect_status_collecting"  # re-entered fresh
    assert s2["_pending_prompt"] is not None
    assert "2nd attempt" in s2["_pending_prompt"]["text"]
    assert s2["error"] is None
    assert respx.calls.call_count == 3                   # LLM#1, #2, #3

    # T3: user provides valid answer -> captures normally
    result3 = tool.execute(thread_id=tid, user_message="active", initial_context={})
    s3 = snap(tool, tid)

    assert "Status A set" in str(result3)
    assert s3["status"] == "active"
    assert s3["_outcome_id"] == "outcome_a"
    assert s3["_status"] == "collect_status_outcome_a"
    assert s3["error"] is None
    assert respx.calls.call_count == 4                   # + LLM#4 for T3


# ── Group 20: SO Intent Change ─────────────────────────────────────────────────


@respx.mock
def test_ic_so_1_intent_change_on_initial_run_no_bot_response():
    """SO: intent_change returned with bot_response=None on initial run of step2 -> rollback.

    Step1 completes normally -> step2 starts.
    On step2's first entry (initial run), the LLM returns intent_change="collect_name"
    with bot_response=None (no question asked -- agent immediately signals intent change).

    Before fix: _generate_prompt extracted only bot_response/options/is_selectable
    from the SO response dict, discarding intent_change. Since bot_response=None,
    prompt_data=None -> _handle_special_responses never called -> intent change silently ignored.

    After fix: intent_change is preserved in prompt_data -> execute() calls
    _handle_intent_change -> rollback to collect_name -> fresh re-prompt for name.

    Flow:
      LLM#1: step1 T1 prompt ("What is your name?")
      LLM#2: step1 T2 capture (captured=True, name="John")
      LLM#3: step2 T1 initial run -> intent_change="collect_name", bot_response=None
      LLM#4: step1 T1 fresh re-prompt after rollback ("What is your name again?")
      LLM#5: step1 T2 capture again (captured=True, name="John")
      LLM#6: step2 T1 prompt ("What is your status?")
      LLM#7: step2 T2 capture (captured=True, status="active")

    All within correct tool.execute() turn boundaries.
    """
    responses = iter([
        # step1 T1: generate prompt
        llm_structured_response({
            "bot_response": "What is your name?",
            "captured": False, "name": None,
            "options": None, "is_selectable": None,
        }),
        # step1 T2: capture name
        llm_structured_response({
            "bot_response": None,
            "captured": True, "name": "John",
            "options": None, "is_selectable": None,
        }),
        # step2 T1 initial run: intent_change, no bot_response
        llm_structured_response({
            "bot_response": None,
            "captured": False, "status": None,
            "intent_change": "collect_name",
            "options": None, "is_selectable": None,
        }),
        # step1 T1 fresh re-prompt after rollback
        llm_structured_response({
            "bot_response": "What is your name again?",
            "captured": False, "name": None,
            "options": None, "is_selectable": None,
        }),
        # step1 T2: capture name again
        llm_structured_response({
            "bot_response": None,
            "captured": True, "name": "John",
            "options": None, "is_selectable": None,
        }),
        # step2 T1: prompt
        llm_structured_response({
            "bot_response": "What is your status?",
            "captured": False, "status": None,
            "options": None, "is_selectable": None,
        }),
        # step2 T2: capture status
        llm_structured_response({
            "bot_response": None,
            "captured": True, "status": "active",
            "options": None, "is_selectable": None,
        }),
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("so_intent_change.yaml")
    tid = str(uuid.uuid4())

    # T1: step1 initial prompt
    result1 = tool.execute(thread_id=tid, initial_context={})
    assert InterruptType.USER_INPUT in str(result1)
    assert "What is your name?" in str(result1)

    # T2: step1 captures name -> advances to step2 -> step2 T1 fires intent_change
    #     -> rollback to step1 -> step1 T1 fresh re-prompt (all in one execute())
    result2 = tool.execute(thread_id=tid, user_message="John", initial_context={})
    s2 = snap(tool, tid)

    assert InterruptType.USER_INPUT in str(result2)
    assert "What is your name again?" in str(result2)
    assert "All collected" not in str(result2)
    # name cleared by rollback
    assert s2.get("name") is None
    assert s2["_status"] == "collect_name_collecting"

    # T3: step1 captures name again -> step2 starts -> step2 T1 normal prompt
    result3 = tool.execute(thread_id=tid, user_message="John", initial_context={})
    s3 = snap(tool, tid)

    assert InterruptType.USER_INPUT in str(result3)
    assert "What is your status?" in str(result3)
    # SO mode: primary field stores the full field_values dict
    assert s3["name"].get("name") == "John"
    assert s3.get("status") is None

    # T4: step2 captures status -> success
    result4 = tool.execute(thread_id=tid, user_message="active", initial_context={})
    s4 = snap(tool, tid)

    assert "All collected" in str(result4)
    assert s4["_outcome_id"] == "end_success"
    assert s4["name"].get("name") == "John"
    assert s4["status"].get("status") == "active"
    assert respx.calls.call_count == 7


@respx.mock
def test_ic_so_2_intent_change_on_initial_run_with_bot_response():
    """SO: intent_change returned WITH a bot_response on initial run of step2 -> rollback.

    Same as test_ic_so_1 but the LLM returns BOTH bot_response AND intent_change.
    Before fix: intent_change was discarded; bot_response would be shown to user
    (wrong -- intent change should take priority).
    After fix: intent_change in prompt_data is checked BEFORE the text prompt path,
    so rollback happens regardless of bot_response being set.
    """
    responses = iter([
        # step1 T1: prompt
        llm_structured_response({
            "bot_response": "What is your name?",
            "captured": False, "name": None,
            "options": None, "is_selectable": None,
        }),
        # step1 T2: capture
        llm_structured_response({
            "bot_response": None,
            "captured": True, "name": "John",
            "options": None, "is_selectable": None,
        }),
        # step2 T1 initial run: intent_change WITH bot_response
        llm_structured_response({
            "bot_response": "Actually, let me ask for your name again.",
            "captured": False, "status": None,
            "intent_change": "collect_name",
            "options": None, "is_selectable": None,
        }),
        # step1 T1 fresh re-prompt after rollback
        llm_structured_response({
            "bot_response": "What is your name (retry)?",
            "captured": False, "name": None,
            "options": None, "is_selectable": None,
        }),
        # step1 T2: capture
        llm_structured_response({
            "bot_response": None,
            "captured": True, "name": "Jane",
            "options": None, "is_selectable": None,
        }),
        # step2 T1: prompt
        llm_structured_response({
            "bot_response": "What is your status?",
            "captured": False, "status": None,
            "options": None, "is_selectable": None,
        }),
        # step2 T2: capture
        llm_structured_response({
            "bot_response": None,
            "captured": True, "status": "active",
            "options": None, "is_selectable": None,
        }),
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("so_intent_change.yaml")
    tid = str(uuid.uuid4())

    result1 = tool.execute(thread_id=tid, initial_context={})
    assert "What is your name?" in str(result1)

    # T2: step1 captures -> step2 T1 fires intent_change (with bot_response) -> rollback -> re-prompt
    result2 = tool.execute(thread_id=tid, user_message="John", initial_context={})
    s2 = snap(tool, tid)

    # intent_change takes priority -- bot_response from step2 T1 is NOT shown
    assert InterruptType.USER_INPUT in str(result2)
    assert "retry" in str(result2)
    # The step2 bot_response ("Actually, let me ask...") should NOT appear
    assert "Actually, let me ask" not in str(result2)
    assert s2.get("name") is None
    assert s2["_status"] == "collect_name_collecting"

    # T3: step1 captures (Jane) -> step2 starts normally
    result3 = tool.execute(thread_id=tid, user_message="Jane", initial_context={})
    assert "What is your status?" in str(result3)

    # T4: step2 captures -> success
    result4 = tool.execute(thread_id=tid, user_message="active", initial_context={})
    assert "All collected" in str(result4)
    s4 = snap(tool, tid)
    assert s4["name"].get("name") == "Jane"
    assert s4["status"].get("status") == "active"
    assert respx.calls.call_count == 7


# ── Group 21: Whitespace-prefix regression (fix for startswith bug) ───────────


@respx.mock
def test_ic_pm_2_leading_whitespace_still_detected():
    """Regression: LLM response with leading whitespace must still trigger intent change.

    Before fix: `agent_response.startswith("INTENT_CHANGE:")` failed on " INTENT_CHANGE: ..."
    After fix: stripped response is checked.
    """
    responses = iter([
        llm_text_response("What is your status?"),                    # T1
        llm_text_response("  INTENT_CHANGE: collect_status"),         # T2 -- leading spaces
        llm_text_response("What is your status (re-prompt)?"),        # T2 re-prompt after rollback
        llm_text_response("STATUS_A: active"),                        # T3
    ])
    respx.post(FAKE_LLM_COMPLETIONS).mock(side_effect=lambda req: next(responses))

    tool = make_tool("pm_out_of_scope.yaml")
    tid = str(uuid.uuid4())

    result1 = tool.execute(thread_id=tid, initial_context={})
    assert InterruptType.USER_INPUT in str(result1)

    result2 = tool.execute(thread_id=tid, user_message="go back", initial_context={})
    # IC triggers rollback + re-prompt within same turn -> USER_INPUT with fresh prompt
    assert InterruptType.USER_INPUT in str(result2)
    assert "re-prompt" in str(result2)
    assert respx.calls.call_count == 3   # LLM#1 + LLM#2(IC) + LLM#3(re-prompt)

    result3 = tool.execute(thread_id=tid, user_message="STATUS_A: active", initial_context={})
    s3 = snap(tool, tid)
    assert "Status A set" in str(result3)
    assert s3["status"] == "active"
    assert s3["_outcome_id"] == "outcome_a"
    assert respx.calls.call_count == 4
