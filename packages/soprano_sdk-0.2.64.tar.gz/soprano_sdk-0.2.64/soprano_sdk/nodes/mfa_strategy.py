from typing import Dict, Any
from .collect_input import CollectInputStrategy
from ..utils.logger import logger
from jinja2 import Environment
import uuid

def compile_values(template_loader, state: dict, values: Any):
    if isinstance(values, dict):
        return {k: compile_values(template_loader, state, v) for k, v in values.items()}
    elif isinstance(values, list):
        return [compile_values(template_loader, state, value) for value in values]
    elif isinstance(values, str):
        return template_loader.from_string(values).render(state)
    else:
        return values

class MFACollectInputStrategy(CollectInputStrategy):
    """
    MFA authentication strategy that extends CollectInputStrategy.

    Handles:
    - MFA initiation (generate token API)
    - OTP collection with agent
    - Resend functionality (doesn't count as attempt)
    - Validation and authorization
    - Cancellation

    Reuses from parent:
    - Conversation management
    - Agent creation/invocation
    - Max attempts checking
    - Transition pattern matching
    - Validation failure handling (auto-clears field)
    """

    def __init__(self, step_config: Dict[str, Any], engine_context: Any):
        # Extract MFA-specific configuration
        self.mfa_payload = step_config['payload']
        self.mfa_headers = step_config.get('headers', {})
        self.on_success = step_config.get('on_success')
        self.on_cancel = step_config.get('on_cancel', 'mfa_cancelled')
        self.mfa_authorize = step_config.get('mfa-authorize', True)

        # Transform MFA config into CollectInputStrategy format
        collector_config = self._build_collector_config(step_config, engine_context)

        # IMPORTANT: Update original step_config with built transitions
        # so the router can see them when building routing map
        step_config['transitions'] = collector_config['transitions']

        # Initialize parent CollectInputStrategy
        super().__init__(collector_config, engine_context)

        logger.info(f"MFA strategy initialized for step '{self.step_id}'")

    def _build_collector_config(self, step_config: Dict[str, Any], engine_context: Any) -> Dict[str, Any]:
        """
        Transform MFA configuration into CollectInputStrategy format.

        This allows MFA to reuse all the collector infrastructure.
        """
        self.mfa_field = f"{step_config['id']}_mfa_input"

        model_config = engine_context.get_config_value('model_config')
        if not model_config:
            raise ValueError("Model config not found in engine context")
        
        if model_id := step_config.get("model"):
            model_config = model_config.copy()
            model_config["model_name"] = model_id

        return {
            'id': step_config['id'],
            'action': 'collect_input_with_agent',
            'description': step_config.get('description', 'MFA Authentication'),
            'field': self.mfa_field,
            'max_attempts': step_config.get('max_attempts', 3),
            'on_max_attempts_reached': engine_context.mfa_config.max_attempts_message,
            'validator': 'soprano_sdk.authenticators.mfa.mfa_validate_user_input',
            'agent': {
                'name': 'MFA Collector',
                'initial_message': '{{_mfa.message}}',
                'instructions': self._get_mfa_instructions(),
                'model': model_config.get('model_name', 'gpt-4o-mini')
            },
            'transitions': [
                # Resend: loop back to same node
                {
                    'pattern': 'MFA_RESEND:',
                    'next': step_config['id']
                },
                # Success: proceed to next step (use on_success if provided, otherwise transitions)
                {
                    'pattern': 'MFA_CAPTURED:',
                    'next': self.on_success or step_config['transitions'][0]['next']
                },
                # Cancel: route to cancellation outcome
                {
                    'pattern': 'MFA_CANCELLED:',
                    'next': self.on_cancel
                }
            ]
        }

    def _get_mfa_instructions(self) -> str:
        """Return agent instructions for MFA collection"""
        return """You are an authentication value extractor. Your job is to detect resend requests, extract OTP codes, or detect cancellation.

            **RESEND DETECTION (check FIRST):**
            If the user wants to resend the authentication code, respond with: MFA_RESEND:RESEND_REQUEST
            
            Resend examples:
            * "resend" → MFA_RESEND:RESEND_REQUEST
            * "resend code" → MFA_RESEND:RESEND_REQUEST
            * "resend otp" → MFA_RESEND:RESEND_REQUEST
            * "send again" → MFA_RESEND:RESEND_REQUEST
            * "didn't receive it" → MFA_RESEND:RESEND_REQUEST
            * "I didn't get the code" → MFA_RESEND:RESEND_REQUEST
            * "send me a new code" → MFA_RESEND:RESEND_REQUEST
            * "haven't received" → MFA_RESEND:RESEND_REQUEST

            **CANCELLATION PRECEDENCE (override intent change):**
            If the user's message contains any **cancellation expression** (see the Cancellation Detection list below)

            *Cancellation expressions include (but are not limited to):*
            - cancel
            - stop
            - exit
            - nevermind
            - abort
            - quit
            - don't want
            - do not want
            - i don't want to
            - not interested
            - no thanks
            - I changed my mind

            **OTP CAPTURE (default):**
            Extract the authentication code and respond with: MFA_CAPTURED:<code>

            OTP examples:
            * "123456" → MFA_CAPTURED:123456
            * "the code is 987654" → MFA_CAPTURED:987654
            * "my otp is abc123" → MFA_CAPTURED:abc123

            **OUTPUT FORMAT:**
            - For resend: MFA_RESEND:RESEND_REQUEST
            - For OTP codes: MFA_CAPTURED:<code>
            - For cancellation: MFA_CANCELLED:

            **Rule hierarchy (from highest to lowest):**
            1. **Cancellation Detection** - produce `MFA_CANCELLED:` (overrides everything else).
            2. **Intent-Change Detection** - produce `INTENT_CHANGE: <node_name>` only if no cancellation expression is present.
            3. **Resend Detection** - (`MFA_RESEND:RESEND_REQUEST`) - evaluated only after the above two checks fail.
            4. **OTP Capture** - (`MFA_CAPTURED:<code>`) - default when none of the prior conditions match.
        """

    def pre_execute(self, state: Dict[str, Any]) -> Dict[str, Any]:
        pass

    def execute(self, state: Dict[str, Any]) -> Dict[str, Any]:
        """
        Override: Add MFA initiation before collection.

        Flow:
        1. Check if MFA already completed (skip if yes)
        2. First time: Call generate token API
        3. Use parent's execute for collection
        """
        # Skip MFA execution if already completed by another MFA node
        # if '_mfa' in state and state['_mfa'].get('status') == 'COMPLETED': # we will fix the state later
        #     logger.info(f"MFA already completed, skipping step '{self.step_id}'")
        #     # Transition directly to success path
        #     next_node = self.on_success or self.step_config['transitions'][0]['next']
        #     self._set_status(state, next_node)
        #
        #     # Set outcome if next_node is an outcome
        #     if next_node in self.engine_context.outcome_map:
        #         self._set_outcome(state, next_node)
        #
        #     return state

        # Check if MFA needs initiation
        state['_active_input_field'] = self.mfa_field
        if '_mfa' not in state or state['_mfa'].get('status') != 'IN_PROGRESS':
            state['_mfa_config'] = self.engine_context.mfa_config
            self._initiate_mfa(state)
            self._set_status(state, 'collecting')
            return state

        # Use parent's execute method for all collection logic
        return super().execute(state)

    def _initiate_mfa(self, state: Dict[str, Any]):
        """
        Initialize MFA state and call generate token API.

        This sets up the _mfa state object and triggers the initial
        OTP/challenge generation.
        """
        from soprano_sdk.authenticators.mfa import enforce_mfa_if_required

        state['_mfa'] = state.get('_mfa', {})
        state['_mfa']['post_payload'] = dict(transactionId=str(uuid.uuid4()))
        state['_mfa']['post_headers'] = {}
        state['_mfa']['mfa_authorize'] = self.mfa_authorize
        template_loader = self.engine_context.get_config_value("template_loader", Environment())
        for k, v in self.mfa_payload.items():
            state['_mfa']['post_payload'][k] = compile_values(template_loader, state, v)

        # Process headers if provided
        if self.mfa_headers:
            for k, v in self.mfa_headers.items():
                state['_mfa']['post_headers'][k] = compile_values(template_loader, state, v)

        # Store max_attempts for validator to check
        state['_mfa_max_attempts'] = self.max_attempts

        # Call generate token API (updates _mfa with challenge info)
        enforce_mfa_if_required(state, self.engine_context.mfa_config)

        logger.info(f"MFA initiated for step '{self.step_id}', status: {state['_mfa'].get('status')}")

    def _process_transitions(self, state: Dict[str, Any], conversation: list, agent_response: str):
        """
        Override: Handle resend before parent's transition processing.

        If resend is detected, handle it specially (doesn't count as attempt).
        Otherwise, use parent's transition matching logic.
        """
        # Check for resend pattern
        if 'MFA_RESEND:' in agent_response:
            return self._handle_resend(state, conversation)

        # Use parent's transition processing for other patterns
        return super()._process_transitions(state, conversation, agent_response)

    def _handle_resend(self, state: Dict[str, Any], conversation: list) -> Dict[str, Any]:
        """
        Handle resend request without counting as validation attempt.

        Flow:
        1. Call generate token API again
        2. Remove resend messages from conversation (don't count as attempt)
        3. Add new "OTP sent" message
        4. Loop back for collection
        """
        from soprano_sdk.authenticators.mfa import mfa_resend_otp

        logger.info(f"Resend OTP requested in step '{self.step_id}'")

        # Call resend API (updates _mfa['message'] with new delivery info)
        mfa_resend_otp(state, self.engine_context.mfa_config)

        # Remove resend messages from conversation to prevent counting as attempt
        # The conversation has: [..., user_message, agent_response]
        if len(conversation) >= 2:
            removed_agent = conversation.pop()  # Remove agent "MFA_RESEND:RESEND_REQUEST"
            removed_user = conversation.pop()   # Remove user "resend"
            logger.debug(
                f"Removed resend messages - "
                f"user: '{removed_user.get('content', '')}', "
                f"agent: '{removed_agent.get('content', '')}'"
            )

        # Add new message with updated delivery info
        new_message = state['_mfa'].get('message', 'A new code has been sent. Please enter it.')
        conversation.append({
            'role': 'assistant',
            'content': new_message
        })

        logger.info(f"Resend completed, new message: '{new_message}'")

        # Stay in collecting status (self-loop)
        self._set_status(state, 'collecting')

        return state
