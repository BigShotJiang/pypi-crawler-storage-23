from abc import ABC, abstractmethod
from typing import Any, Dict, List, Literal, Optional, Tuple, Callable, get_origin, get_args

from agno.models.openai import OpenAIChat
from crewai import LLM
from langchain_openai import ChatOpenAI
from pydantic import SecretStr, BaseModel

from .adaptor import (
    AgentAdapter,
    LangGraphAgentAdapter,
    CrewAIAgentAdapter,
    AgnoAgentAdapter,
    PydanticAIAgentAdapter
)


def _uses_external_auth(provider: str) -> bool:
    """Return True if the provider uses external credentials (e.g. AWS IAM) instead of API keys."""
    return provider in ("ollama", "bedrock")


def _uses_litellm(provider: str) -> bool:
    """Return True if the provider should be routed through LiteLLM."""
    return provider == "bedrock"


def _litellm_model_name(provider: str, model_name: str) -> str:
    """Build the LiteLLM model string for the given provider."""
    if provider == "bedrock":
        return f"bedrock/converse/{model_name}"
    return f"{provider}/{model_name}"


def get_model(config: Dict[str, Any], framework: Literal['langgraph', 'crewai', 'agno', 'pydantic-ai'] = "langgraph", output_schema: Optional[BaseModel] = None, tools: Optional[List] = None):
    errors = []

    model_name: str = config.get("model_name", "")
    if not model_name:
        errors.append("Model name is required in model_config")

    # Determine provider (openai, ollama, bedrock, etc.)
    provider = config.get("provider", "openai").lower()

    # Handle base_url - required for Ollama, optional for OpenAI
    base_url = config.get("base_url")
    api_key = config.get("api_key", "")
    if not api_key:
        if auth_callback := config.get("auth_callback"):
            api_key = auth_callback()
        if not api_key:
            if _uses_external_auth(provider):
                api_key = provider  # Placeholder; actual auth is external
            else:
                errors.append("API key/Auth callback for model is required in model_config")

    if errors:
        raise ValueError("; ".join(errors))

    if framework == "agno":
        if _uses_litellm(provider):
            raise ValueError(
                f"Provider '{provider}' is not supported with the 'agno' framework. "
                f"Use 'langgraph' or 'crewai' framework instead."
            )
        return OpenAIChat(
            id=model_name,
            api_key=api_key,
            base_url=base_url
        )

    if framework == "crewai":
        crewai_kwargs = {
            "model": _litellm_model_name(provider, model_name) if _uses_litellm(provider) else f"{provider}/{model_name}",
            "temperature": 0.1,
            "top_p": 0.7,
        }
        if not _uses_external_auth(provider):
            crewai_kwargs["api_key"] = api_key
        if base_url:
            crewai_kwargs["base_url"] = base_url
        return LLM(**crewai_kwargs)

    if _uses_litellm(provider):
        import os
        from langchain_community.chat_models import ChatLiteLLM

        llm_kwargs = {"model": _litellm_model_name(provider, model_name)}
        if base_url:
            llm_kwargs["api_base"] = base_url

        # Bedrock auth: pass AWS credentials via model_kwargs so ChatLiteLLM
        # forwards them to litellm.completion().
        if provider == "bedrock":
            aws_params = {}
            aws_key = config.get("aws_access_key_id") or os.getenv("AWS_ACCESS_KEY_ID")
            aws_secret = config.get("aws_secret_access_key") or os.getenv("AWS_SECRET_ACCESS_KEY")
            aws_region = config.get("aws_region_name") or os.getenv("AWS_REGION_NAME")
            if aws_key:
                aws_params["aws_access_key_id"] = aws_key
            if aws_secret:
                aws_params["aws_secret_access_key"] = aws_secret
            if aws_region:
                aws_params["aws_region_name"] = aws_region
            if aws_params:
                llm_kwargs["model_kwargs"] = aws_params

        llm = ChatLiteLLM(**llm_kwargs)
    else:
        llm = ChatOpenAI(
            model=model_name,
            api_key=SecretStr(api_key),
            base_url=base_url,
        )

    if output_schema:
        return llm.with_structured_output(output_schema)

    if tools:
        llm = llm.bind_tools(tools)

    return llm


class AgentCreator(ABC):
    @abstractmethod
    def create_agent(
        self,
        name: str,
        model_config: Dict[str, Any],
        tools: List[Any],
        system_prompt: str,
        structured_output_model: Any = None,
        guardrails: Optional[List] = None,
    ) -> AgentAdapter:
        pass


class LangGraphAgentCreator(AgentCreator):
    def create_agent(
        self,
        name: str,
        model_config: Dict[str, Any],
        tools: List[Any],
        system_prompt: str,
        structured_output_model: Any = None,
        guardrails: Optional[List] = None,
    ) -> LangGraphAgentAdapter:
        from langchain.agents import create_agent
        from langchain.tools import tool
        from langchain.agents.structured_output import ProviderStrategy

        tools = [tool(tool_name, description=description)(tool_callable) for tool_name, description, tool_callable in tools]

        output_parser = None
        if structured_output_model:
            output_parser = ProviderStrategy(structured_output_model)

        agent = create_agent(
            name=name,
            model=get_model(model_config, 'langgraph', tools=tools),
            tools=tools,
            system_prompt=system_prompt,
            response_format=output_parser
        )
        return LangGraphAgentAdapter(agent, guardrails=guardrails)


class CrewAIAgentCreator(AgentCreator):
    def create_agent(
        self,
        name: str,
        model_config: Dict[str, Any],
        tools: List[Any],
        system_prompt: str,
        structured_output_model: Any = None,
        guardrails: Optional[List] = None,
    ) -> CrewAIAgentAdapter:
        from crewai.agent import Agent
        from crewai.tools import BaseTool
        from pydantic import Field, create_model
        from typing import Type
        import inspect

        def create_crewai_tool(tool_name: str, tool_description: str, tool_callable: Callable) -> Any:
            """Create a CrewAI tool with proper Pydantic schema for type hints"""

            # Get function signature to build schema
            sig = inspect.signature(tool_callable)

            # Build Pydantic fields from function parameters
            schema_fields = {}
            for param_name, param in sig.parameters.items():
                # Skip **kwargs and **state parameters - they shouldn't be in the schema
                # These are used for validators and internal context
                if param.kind == inspect.Parameter.VAR_KEYWORD:
                    continue

                # Get parameter annotation, default to str if not specified
                param_type = param.annotation if param.annotation != inspect.Parameter.empty else str

                # Default description
                description = f"Parameter: {param_name}"

                # Check if using Annotated type hint for description
                if get_origin(param_type) is not None:
                    # Handle Annotated[type, "description", ...]
                    try:
                        from typing import Annotated
                        if get_origin(param_type) is Annotated:
                            args = get_args(param_type)
                            param_type = args[0]  # First arg is the actual type
                            # Look for string metadata as description
                            for metadata in args[1:]:
                                if isinstance(metadata, str):
                                    description = metadata
                                    break
                    except ImportError:
                        # Python < 3.9 doesn't have Annotated in typing
                        pass

                # Get default value if exists
                if param.default != inspect.Parameter.empty:
                    schema_fields[param_name] = (
                        param_type,
                        Field(default=param.default, description=description)
                    )
                else:
                    schema_fields[param_name] = (
                        param_type,
                        Field(..., description=description)
                    )

            # Create dynamic Pydantic model for tool input schema
            ToolInputSchema = create_model(
                f"{tool_name.title().replace('_', '')}Input",
                **schema_fields
            )

            # Create custom BaseTool class with proper schema
            class CustomCrewAITool(BaseTool):
                name: str = tool_name
                description: str = tool_description
                args_schema: Type[BaseModel] = ToolInputSchema

                def _run(self, **kwargs) -> str:
                    return tool_callable(**kwargs)

            return CustomCrewAITool()

        tools = [create_crewai_tool(tn, desc, tc) for tn, desc, tc in tools]

        goal = "Collect the required data from user messages using the available tools."
        if structured_output_model:
            schema_fields = structured_output_model.model_json_schema().get("properties", {})
            field_lines = [
                f"- {field_name}: {field_info['description']}"
                for field_name, field_info in schema_fields.items()
                if field_info.get("description")
            ]
            if field_lines:
                field_descriptions = "\n".join(field_lines)
                goal += (
                    "\n\nYour final answer must be the great and most complete as possible, "
                    f"it must be the outcome described:\n{field_descriptions}"
                )

        agent = Agent(
            role=name,
            backstory=system_prompt,
            goal=goal,
            tools=tools,
            llm=get_model(model_config, 'crewai'),
            max_retry_limit=2,
            response_format=structured_output_model,
        )

        return CrewAIAgentAdapter(agent, output_schema=structured_output_model, guardrails=guardrails or [])


class AgnoAgentCreator(AgentCreator):
    def create_agent(
        self,
        name: str,
        model_config: Dict[str, Any],
        tools: List[Any],
        system_prompt: str,
        structured_output_model: Any = None,
        guardrails: Optional[List] = None,
    ) -> AgnoAgentAdapter:
        from agno.agent import Agent
        from agno.tools import tool

        tools = [tool(name=tool_name, description=description)(tool_callable) for tool_name, description, tool_callable in tools]

        agent = Agent(
            name=name,
            model=get_model(model_config, 'agno'),
            tools=tools,
            instructions=[system_prompt]
        )
        
        return AgnoAgentAdapter(agent, guardrails=guardrails)


class PydanticAIAgentCreator(AgentCreator):
    def create_agent(
        self,
        name: str,
        model_config: Dict[str, Any],
        tools: List[Tuple[str, str, Callable]],
        system_prompt: str,
        structured_output_model: Any = None,
        guardrails: Optional[List] = None,
    ) -> PydanticAIAgentAdapter:
        from pydantic_ai import Agent

        agent = Agent(
            model=get_model(model_config, 'pydantic-ai'),
            system_prompt=system_prompt,
        )

        for tool_name, description, tool_callable in tools:
            agent.tool(name=tool_name, description=description)(tool_callable)

        return PydanticAIAgentAdapter(agent, guardrails=guardrails)


class AgentFactory:
    _CREATORS = {
        "langgraph": LangGraphAgentCreator,
        "crewai": CrewAIAgentCreator,
        "agno": AgnoAgentCreator,
        "pydantic-ai": PydanticAIAgentCreator,
    }
    
    @classmethod
    def get_creator(cls, framework: str) -> AgentCreator:
        framework_lower = framework.lower()
        
        if framework_lower not in cls._CREATORS:
            supported = ", ".join(cls._CREATORS.keys())
            raise ValueError(
                f"Unsupported agent framework: '{framework}'. "
                f"Supported frameworks: {supported}"
            )
        
        creator_class = cls._CREATORS[framework_lower]
        return creator_class()
    
    @classmethod
    def create_agent(
        cls,
        framework: str,
        name: str,
        model_config: Dict[str, Any],
        tools: List[Any],
        system_prompt: str,
        structured_output_model: Any,
        guardrails: Optional[List] = None,
    ) -> Any:
        creator = cls.get_creator(framework)
        return creator.create_agent(
            name=name,
            model_config=model_config,
            tools=tools,
            system_prompt=system_prompt,
            structured_output_model=structured_output_model,
            guardrails=guardrails,
        )
