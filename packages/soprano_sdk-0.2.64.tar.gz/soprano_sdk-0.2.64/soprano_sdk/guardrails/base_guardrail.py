"""
Shared base class, result types, and factory for all guardrails.
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Type

from ..utils.logger import logger


@dataclass
class GuardrailResult:
    """Unified outcome of any guardrail check."""
    passed: bool
    error_message: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)  # e.g. grounding scores


class GuardrailViolationError(Exception):
    """Raised when a guardrail check fails; carries the user-facing error message."""

    def __init__(self, error_message: str) -> None:
        super().__init__(error_message)
        self.error_message = error_message


class GuardrailsConnectionError(Exception):
    """
    Raised when a guardrail cannot reach its backing service.

    Distinct from GuardrailViolationError (a content/format failure) —
    this signals an infrastructure problem: missing SDK, network error,
    or an unexpected AWS API exception.
    """

    def __init__(self, error_message: str, cause: Optional[Exception] = None) -> None:
        super().__init__(error_message)
        self.error_message = error_message
        self.cause = cause

class BaseGuardrail(ABC):
    """
    Parent class for all guardrails — functional and grounding alike.

    Subclasses must implement check(). They may also accept extra
    constructor kwargs for guardrail-specific configuration (e.g. AWS region).
    """

    def __init__(self, error_message: str) -> None:
        self.error_message = error_message
        self.max_retries: int = 0  # Subclasses override to enable retry-on-failure

    @property
    def regeneration_feedback(self) -> str:
        """System message injected into the conversation when the agent must regenerate."""
        return (
            "[System: Your previous response was invalid. "
            "Please provide a corrected response.]"
        )

    @abstractmethod
    def check(self, response: str, **kwargs) -> GuardrailResult:
        """
        Inspect *response* and return a GuardrailResult.

        Extra runtime context (e.g. grounding_source, query) is passed
        as keyword arguments so the signature stays uniform across types.

        Implementations must not raise — handle errors internally.
        """


class GuardrailFactory:
    """
    Registry-driven factory for BaseGuardrail subclasses.

    Registration via decorator::

        @GuardrailFactory.register("my_check")
        class MyGuardrail(BaseGuardrail):
            ...

    Instantiation from config dict::

        guardrail = GuardrailFactory.create({
            "type": "my_check",
            "error_message": "Something went wrong."
        })
    """

    _registry: Dict[str, Type[BaseGuardrail]] = {}

    @classmethod
    def register(cls, name: str):
        """Class decorator that registers a guardrail type under *name*."""
        def decorator(guardrail_cls: Type[BaseGuardrail]) -> Type[BaseGuardrail]:
            if name in cls._registry:
                logger.warning(f"GuardrailFactory: overwriting existing type '{name}'")
            cls._registry[name] = guardrail_cls
            logger.info(f"GuardrailFactory: registered '{name}' → {guardrail_cls.__name__}")
            return guardrail_cls
        return decorator

    @classmethod
    def create(cls, config: Dict) -> BaseGuardrail:
        """
        Instantiate a single guardrail from a config dict.

        The dict must contain a ``type`` key matching a registered name.
        All remaining keys (except ``type``) are forwarded as kwargs to
        the guardrail constructor, allowing type-specific options like
        ``bedrock_guardrail_id`` to be set from config.

        Raises:
            ValueError: if ``type`` is missing or unknown.
        """
        guardrail_type = config.get("type")
        if not guardrail_type:
            raise ValueError(f"Guardrail config missing 'type' key: {config}")

        guardrail_cls = cls._registry.get(guardrail_type)
        if guardrail_cls is None:
            raise ValueError(
                f"Unknown guardrail type '{guardrail_type}'. "
                f"Known types: {list(cls._registry)}"
            )

        kwargs = {k: v for k, v in config.items() if k != "type"}
        kwargs.setdefault(
            "error_message",
            "I encountered an issue processing your request. Please try again."
        )
        return guardrail_cls(**kwargs)

    @classmethod
    def build_from_configs(cls, configs: List[Dict]) -> List[BaseGuardrail]:
        """
        Instantiate multiple guardrails from a list of config dicts.
        Unknown or malformed entries are skipped with a warning.
        """
        guardrails: List[BaseGuardrail] = []
        for cfg in configs:
            try:
                guardrail = cls.create(cfg)
                guardrails.append(guardrail)
            except ValueError as exc:
                logger.warning(f"GuardrailFactory: skipping config — {exc}")
        return guardrails

    @classmethod
    def registered_types(cls) -> List[str]:
        """Return all currently registered guardrail type names."""
        return list(cls._registry)


def build_guardrails_from_config(configs: List[Dict]) -> List[BaseGuardrail]:
    """
    Build guardrails from a list of config dicts.

    Convenience wrapper around GuardrailFactory.build_from_configs.

    Args:
        configs: List of guardrail configuration dicts, each with a 'type' key

    Returns:
        List of instantiated guardrail instances

    Example:
        >>> configs = [
        ...     {"type": "thought_action_check", "error_message": "Please try again."},
        ...     {
        ...         "type": "grounding_check",
        ...         "error_message": "Response not grounded.",
        ...         "bedrock_guardrail_id": "abc123",
        ...         "aws_region_name": "us-east-1",
        ...         "max_retries": 2
        ...     }
        ... ]
        >>> guardrails = build_guardrails_from_config(configs)
    """
    return GuardrailFactory.build_from_configs(configs)