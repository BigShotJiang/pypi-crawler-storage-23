"""
Functional guardrails for LLM output validation.

ThoughtActionGuardrail uses crewai.agents.parser.parse() to detect
leaked ReAct reasoning chain tokens (Thought:/Action:) in the final response.
"""
from __future__ import annotations

from ..utils.logger import logger
from .base_guardrail import BaseGuardrail, GuardrailFactory, GuardrailResult


@GuardrailFactory.register("thought_action_check")
class ThoughtActionGuardrail(BaseGuardrail):
    """
    Validates CrewAI response format using crewai.agents.parser.parse().

    Only an AgentFinish result (a proper "Final Answer:" conclusion) is valid.
    Everything else indicates a malformed response:

    - parse() → AgentFinish      : PASS  (agent properly concluded)
    - parse() → AgentAction      : FAIL  (Thought:/Action: leaked)
    - parse() → OutputParserError: FAIL  (missing expected Final Answer: format)
    - Any other exception         : FAIL  (unexpected state)

    Supports retry with regeneration:
    - max_retries: Number of regeneration attempts (default: 1)
    """

    def __init__(self, error_message: str, max_retries: int = 1, **kwargs):
        """Initialize with optional retry configuration."""
        super().__init__(error_message)
        self.max_retries = max_retries
        logger.info(f"ThoughtActionGuardrail initialized with max_retries={max_retries}")

    @property
    def regeneration_feedback(self) -> str:
        return (
            "[System: Your previous response contained internal reasoning patterns "
            "(Thought:/Action:) that should not be visible to the user. "
            "Please provide a clean, direct response starting with 'Final Answer:' "
            "containing only the user-facing message.]"
        )

    def check(self, response: str, **kwargs) -> GuardrailResult:
        react_keywords = ["Thought:", "Action:", "Observation:"]
        for keyword in react_keywords:
            if keyword in response:
                return GuardrailResult(passed=False, error_message=self.error_message)
        return GuardrailResult(passed=True)
