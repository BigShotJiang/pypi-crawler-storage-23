"""
Functional guardrails for LLM output validation.

Provides a registry-driven, parallel-executing guardrail system.
ThoughtActionGuardrail uses crewai.agents.parser.parse() to detect
leaked ReAct reasoning chain tokens (Thought:/Action:) in the final response.
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass
from typing import Dict, List, Optional, Type

from ..utils.logger import logger


# ---------------------------------------------------------------------------
# Core data types
# ---------------------------------------------------------------------------

@dataclass
class GuardrailResult:
    """Outcome of a single guardrail check."""
    passed: bool
    error_message: Optional[str] = None


class GuardrailViolationError(Exception):
    """Raised when a guardrail check fails; carries the user-facing error message."""

    def __init__(self, error_message: str) -> None:
        super().__init__(error_message)
        self.error_message = error_message


# ---------------------------------------------------------------------------
# Abstract base class
# ---------------------------------------------------------------------------

class Guardrail(ABC):
    """Base class for all functional guardrails."""

    def __init__(self, error_message: str) -> None:
        self.error_message = error_message

    @abstractmethod
    def check(self, response: str) -> GuardrailResult:
        """Inspect *response* and return a GuardrailResult.

        Implementations should not raise exceptions — handle errors internally
        and return an appropriate GuardrailResult.
        """


# ---------------------------------------------------------------------------
# Concrete guardrail: ThoughtActionGuardrail
# ---------------------------------------------------------------------------

class ThoughtActionGuardrail(Guardrail):
    """Validates CrewAI response format using crewai.agents.parser.parse().

    Only an AgentFinish result (a proper "Final Answer:" conclusion) is valid.
    Everything else indicates a malformed response:

    - parse() → AgentFinish      : PASS  (agent properly concluded)
    - parse() → AgentAction      : FAIL  (Thought:/Action: leaked — still in reasoning loop)
    - parse() → OutputParserError: FAIL  (missing expected Final Answer: format)
    - Any other exception         : FAIL  (unexpected state)
    """

    def check(self, response: str) -> GuardrailResult:
        try:
            from crewai.agents.parser import parse, AgentFinish
            result = parse(response)
            if isinstance(result, AgentFinish):
                return GuardrailResult(passed=True)
            logger.warning(
                f"ThoughtActionGuardrail: response is not AgentFinish "
                f"(got {type(result).__name__!r}), failing guardrail"
            )
            return GuardrailResult(passed=False, error_message=self.error_message)
        except Exception:
            # OutputParserError (missing Final Answer / Action markers)
            # or any other exception → response not in expected format → fail
            logger.warning(
                "ThoughtActionGuardrail: parse() raised, response not in expected format"
            )
            return GuardrailResult(passed=False, error_message=self.error_message)


# ---------------------------------------------------------------------------
# Parallel execution helper
# ---------------------------------------------------------------------------

def run_guardrails_parallel(
    response: str,
    guardrails: List[Guardrail],
) -> List[GuardrailResult]:
    """Execute all guardrails concurrently; return results in original order.

    Uses ThreadPoolExecutor so multiple guardrails run without blocking each
    other. Result order matches the input guardrails list order.
    """
    if not guardrails:
        return []

    results: List[Optional[GuardrailResult]] = [None] * len(guardrails)

    with ThreadPoolExecutor(max_workers=len(guardrails)) as executor:
        future_to_index = {
            executor.submit(g.check, response): i
            for i, g in enumerate(guardrails)
        }
        for future in as_completed(future_to_index):
            idx = future_to_index[future]
            try:
                results[idx] = future.result()
            except Exception as exc:
                logger.error(f"Guardrail at index {idx} raised from future: {exc}")
                results[idx] = GuardrailResult(passed=True)

    return results  # type: ignore[return-value]


# ---------------------------------------------------------------------------
# Registry and builder
# ---------------------------------------------------------------------------

GUARDRAIL_REGISTRY: Dict[str, Type[Guardrail]] = {
    "thought_action_check": ThoughtActionGuardrail,
}


def build_guardrails_from_config(configs: List[Dict]) -> List[Guardrail]:
    """Instantiate guardrails from a list of YAML-sourced config dicts.

    Each dict must have at minimum a ``type`` key. Unknown types are skipped
    with a warning.

    Example::

        [
            {"type": "thought_action_check",
             "error_message": "I encountered an issue. Please try again."}
        ]
    """
    guardrails: List[Guardrail] = []
    for cfg in configs:
        guardrail_type = cfg.get("type")
        if not guardrail_type:
            logger.warning(f"Guardrail config missing 'type' key, skipping: {cfg}")
            continue
        guardrail_cls = GUARDRAIL_REGISTRY.get(guardrail_type)
        if guardrail_cls is None:
            logger.warning(
                f"Unknown guardrail type '{guardrail_type}'. "
                f"Known: {list(GUARDRAIL_REGISTRY)}. Skipping."
            )
            continue
        error_message = cfg.get(
            "error_message",
            "I encountered an issue processing your request. Please try again."
        )
        guardrails.append(guardrail_cls(error_message=error_message))
        logger.info(f"Registered guardrail '{guardrail_type}'")
    return guardrails
