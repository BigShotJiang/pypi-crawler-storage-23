from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import List, Optional
from soprano_sdk.guardrails.base_guardrail import BaseGuardrail, GuardrailResult
from soprano_sdk.utils.logger import logger


def run_guardrails_parallel(
    response: str,
    guardrails: List[BaseGuardrail],
    **check_kwargs,
) -> List[GuardrailResult]:
    """
    Execute all guardrails concurrently; return results in original order.

    Extra keyword arguments (e.g. grounding_source, query) are forwarded
    to each guardrail's check() method, so mixed lists of functional and
    grounding guardrails can be run together.
    """
    if not guardrails:
        return []

    results: List[Optional[GuardrailResult]] = [None] * len(guardrails)

    with ThreadPoolExecutor(max_workers=len(guardrails)) as executor:
        future_to_index = {
            executor.submit(g.check, response, **check_kwargs): i
            for i, g in enumerate(guardrails)
        }
        for future in as_completed(future_to_index):
            idx = future_to_index[future]
            try:
                results[idx] = future.result()
            except Exception as exc:
                logger.error(f"Guardrail at index {idx} raised from future: {exc}")
                results[idx] = GuardrailResult(passed=True)  # fail-open

    return results  # type: ignore[return-value]