"""
Bedrock Guardrails contextual grounding check, expressed as a BaseGuardrail subclass.

Uses the ApplyGuardrail API to validate that agent responses are grounded
in the provided instructions, collected workflow data, and tool outputs.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

from pydantic import Field as PydanticField
from pydantic_settings import BaseSettings, SettingsConfigDict

from ..utils.logger import logger
from ..utils.tracing import trace_agent_invocation
from .base_guardrail import BaseGuardrail, GuardrailFactory, GuardrailResult, GuardrailsConnectionError

try:
    import boto3
except ImportError:
    boto3 = None


# Backward compatibility: dataclass for test compatibility
@dataclass
class GroundingCheckResult:
    """Result of a grounding check (for backward compatibility with tests)."""
    is_grounded: bool
    grounding_score: Optional[float] = None
    relevance_score: Optional[float] = None
    action: str = "NONE"

GROUNDING_SOURCE_MAX_CHARS = 100_000
QUERY_MAX_CHARS = 1_000
GUARD_CONTENT_MAX_CHARS = 5_000


class GroundingCheckConfig(BaseSettings):
    """
    Configuration loaded from environment variables or constructor.

    Env vars (auto-mapped from field names, uppercased):
        BEDROCK_GUARDRAIL_ID
        BEDROCK_GUARDRAIL_VERSION
        AWS_REGION_NAME
        AWS_ACCESS_KEY_ID
        AWS_SECRET_ACCESS_KEY

    Constructor params take precedence over env vars.
    """
    bedrock_guardrail_id: Optional[str] = PydanticField(
        default=None,
        description="Bedrock Guardrail identifier"
    )
    bedrock_guardrail_version: str = PydanticField(
        default="DRAFT",
        description="Bedrock Guardrail version"
    )
    aws_region_name: Optional[str] = PydanticField(
        default=None,
        description="AWS region for Bedrock runtime"
    )
    aws_access_key_id: Optional[str] = PydanticField(
        default=None,
        description="AWS access key ID"
    )
    aws_secret_access_key: Optional[str] = PydanticField(
        default=None,
        description="AWS secret access key"
    )
    max_retries: int = PydanticField(
        default=1,
        description="Maximum number of retries for grounding check failures"
    )

    model_config = SettingsConfigDict(extra="ignore")


def _truncate(text: str, max_chars: int, label: str) -> str:
    if len(text) > max_chars:
        logger.warning(f"GroundingGuardrail: {label} truncated from {len(text)} to {max_chars} chars")
        return text[:max_chars]
    return text



@GuardrailFactory.register("grounding_check")
class GroundingGuardrail(BaseGuardrail):
    """
    Bedrock Guardrails contextual grounding check.

    Constructor accepts AWS credentials and guardrail configuration:
        bedrock_guardrail_id: Guardrail identifier
        bedrock_guardrail_version: Guardrail version (default: DRAFT)
        aws_region_name: AWS region
        aws_access_key_id: AWS access key
        aws_secret_access_key: AWS secret key
        max_retries: Max retry attempts (default: 1)
    """

    def __init__(self, error_message: str, **config_overrides):
        """Initialize with optional config overrides from YAML."""
        super().__init__(error_message)
        # Create config with both env vars and constructor params
        self._config = GroundingCheckConfig(**config_overrides)
        self.max_retries = self._config.max_retries

        # Build a shared boto3 session once at init time
        self._client = None
        if boto3 is not None and self._config.bedrock_guardrail_id:
            session_kwargs = {}
            if self._config.aws_region_name:
                session_kwargs["region_name"] = self._config.aws_region_name
            if self._config.aws_access_key_id:
                session_kwargs["aws_access_key_id"] = self._config.aws_access_key_id
            if self._config.aws_secret_access_key:
                session_kwargs["aws_secret_access_key"] = self._config.aws_secret_access_key
            session = boto3.Session(**session_kwargs)
            self._client = session.client("bedrock-runtime")

        logger.info(
            f"GroundingGuardrail initialized: guardrail_id={self._config.bedrock_guardrail_id}, "
            f"max_retries={self.max_retries}"
        )

    def check(self, response: str, **kwargs) -> GuardrailResult:
        grounding_source: str = kwargs.get("grounding_source", "")
        query: str = kwargs.get("query", "")

        if not self._config.bedrock_guardrail_id:
            logger.warning("GroundingGuardrail: skipped — BEDROCK_GUARDRAIL_ID not configured")
            return GuardrailResult(passed=True)

        # boto3 missing is a hard infrastructure failure, not a content issue
        if boto3 is None:
            raise GuardrailsConnectionError(
                "GroundingGuardrail cannot connect to Bedrock: boto3 is not installed. "
                "Fix with: pip install boto3"
            )

        try:
            grounding_source = _truncate(grounding_source, GROUNDING_SOURCE_MAX_CHARS, "grounding_source")
            query = _truncate(query, QUERY_MAX_CHARS, "query")
            response_text = _truncate(response, GUARD_CONTENT_MAX_CHARS, "guard_content")

            client = self._client

            content = [
                {"text": {"text": grounding_source, "qualifiers": ["grounding_source"]}},
                {"text": {"text": query, "qualifiers": ["query"]}},
                {"text": {"text": response_text, "qualifiers": ["guard_content"]}},
            ]

            with trace_agent_invocation(agent_name="GroundingGuardrail", model="bedrock-guardrail") as span:
                api_response = client.apply_guardrail(
                    guardrailIdentifier=self._config.bedrock_guardrail_id,
                    guardrailVersion=self._config.bedrock_guardrail_version,
                    source="OUTPUT",
                    content=content,
                )

                action = api_response.get("action", "NONE")
                grounding_score = relevance_score = None

                for assessment in api_response.get("assessments", []):
                    for f in assessment.get("contextualGroundingPolicy", {}).get("filters", []):
                        if f.get("type") == "GROUNDING":
                            grounding_score = f.get("score")
                        elif f.get("type") == "RELEVANCE":
                            relevance_score = f.get("score")

                is_grounded = action == "NONE"

                if span and span.is_recording():
                    span.set_attribute("grounding.action", action)
                    span.set_attribute("grounding.is_grounded", is_grounded)
                    if grounding_score is not None:
                        span.set_attribute("grounding.score", grounding_score)
                    if relevance_score is not None:
                        span.set_attribute("grounding.relevance_score", relevance_score)

                logger.info(
                    f"GroundingGuardrail: action={action}, "
                    f"grounding_score={grounding_score}, relevance_score={relevance_score}"
                )

                metadata = {
                    "action": action,
                    "grounding_score": grounding_score,
                    "relevance_score": relevance_score,
                }
                return GuardrailResult(
                    passed=is_grounded,
                    error_message=None if is_grounded else self.error_message,
                    metadata=metadata,
                )

        except GuardrailsConnectionError:
            raise
        except Exception as exc:
            logger.error(f"GroundingGuardrail: Bedrock API call failed: {exc}")
            raise GuardrailsConnectionError(
                f"GroundingGuardrail failed to reach Bedrock: {exc}",
                cause=exc,
            ) from exc

    @property
    def regeneration_feedback(self) -> str:
        return (
            "[System: Your previous response contained information not supported by "
            "your instructions or context. Please respond using ONLY the information "
            "available to you. Do not fabricate any details, URLs, phone numbers, "
            "policies, or other information.]"
        )