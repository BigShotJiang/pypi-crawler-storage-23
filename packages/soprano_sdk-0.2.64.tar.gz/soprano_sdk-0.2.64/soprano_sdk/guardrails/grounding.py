"""
Bedrock Guardrails contextual grounding check.

Uses the ApplyGuardrail API to validate that agent responses are grounded
in the provided instructions, collected workflow data, and tool outputs.
"""
from dataclasses import dataclass
from typing import Optional

from pydantic import Field as PydanticField
from pydantic_settings import BaseSettings, SettingsConfigDict

from ..utils.logger import logger
from ..utils.tracing import trace_agent_invocation

try:
    import boto3
except ImportError:
    boto3 = None

GROUNDING_SOURCE_MAX_CHARS = 100_000
QUERY_MAX_CHARS = 1_000
GUARD_CONTENT_MAX_CHARS = 5_000


class GroundingCheckConfig(BaseSettings):
    """Configuration loaded from environment variables.

    Env vars (auto-mapped from field names, uppercased):
        BEDROCK_GUARDRAIL_ID
        BEDROCK_GUARDRAIL_VERSION
        AWS_REGION_NAME
    """
    bedrock_guardrail_id: Optional[str] = PydanticField(
        default=None,
        description="Bedrock Guardrail identifier"
    )
    bedrock_guardrail_version: str = PydanticField(
        default="DRAFT",
        description="Bedrock Guardrail version"
    )
    aws_region_name: Optional[str] = PydanticField(
        default=None,
        description="AWS region for Bedrock runtime"
    )

    model_config = SettingsConfigDict(extra="ignore")


@dataclass
class GroundingCheckResult:
    """Result of a Bedrock Guardrails grounding check."""
    is_grounded: bool
    grounding_score: Optional[float] = None
    relevance_score: Optional[float] = None
    action: str = "NONE"  # "NONE" or "GUARDRAIL_INTERVENED"


def _truncate(text: str, max_chars: int, label: str) -> str:
    """Truncate text to max_chars, logging a warning if truncated."""
    if len(text) > max_chars:
        logger.warning(f"Grounding check: {label} truncated from {len(text)} to {max_chars} chars")
        return text[:max_chars]
    return text


def check_grounding(
    agent_response: str,
    grounding_source: str,
    query: str,
    config: Optional[GroundingCheckConfig] = None,
) -> GroundingCheckResult:
    """Check if an agent response is grounded using Bedrock Guardrails.

    Calls the ApplyGuardrail API with contextual grounding check.
    Fail-open: returns grounded=True on any error.

    Args:
        agent_response: The agent's conversational text to validate.
        grounding_source: Combined context (instructions + state + tool outputs).
        query: The user's last message.
        config: Guardrail configuration (loaded from env if None).

    Returns:
        GroundingCheckResult with scores and action.
    """
    if config is None:
        config = GroundingCheckConfig()

    if not config.bedrock_guardrail_id:
        logger.warning("Grounding check skipped: BEDROCK_GUARDRAIL_ID not configured")
        return GroundingCheckResult(is_grounded=True, action="NONE")

    if boto3 is None:
        logger.warning("Grounding check skipped: boto3 not installed. Install with: pip install boto3")
        return GroundingCheckResult(is_grounded=True, action="NONE")

    try:
        grounding_source = _truncate(grounding_source, GROUNDING_SOURCE_MAX_CHARS, "grounding_source")
        query = _truncate(query, QUERY_MAX_CHARS, "query")
        agent_response = _truncate(agent_response, GUARD_CONTENT_MAX_CHARS, "guard_content")

        client_kwargs = {}
        if config.aws_region_name:
            client_kwargs["region_name"] = config.aws_region_name
        client = boto3.client("bedrock-runtime", **client_kwargs)

        content = [
            {"text": {"text": grounding_source, "qualifiers": ["grounding_source"]}},
            {"text": {"text": query, "qualifiers": ["query"]}},
            {"text": {"text": agent_response, "qualifiers": ["guard_content"]}},
        ]

        with trace_agent_invocation(
            agent_name="GroundingCheck",
            model="bedrock-guardrail",
        ) as span:
            response = client.apply_guardrail(
                guardrailIdentifier=config.bedrock_guardrail_id,
                guardrailVersion=config.bedrock_guardrail_version,
                source="OUTPUT",
                content=content,
            )

            action = response.get("action", "NONE")
            grounding_score = None
            relevance_score = None

            for assessment in response.get("assessments", []):
                grounding_policy = assessment.get("contextualGroundingPolicy", {})
                for filter_result in grounding_policy.get("filters", []):
                    filter_type = filter_result.get("type")
                    score = filter_result.get("score")
                    if filter_type == "GROUNDING":
                        grounding_score = score
                    elif filter_type == "RELEVANCE":
                        relevance_score = score

            is_grounded = action == "NONE"

            if span and span.is_recording():
                span.set_attribute("grounding.action", action)
                span.set_attribute("grounding.is_grounded", is_grounded)
                if grounding_score is not None:
                    span.set_attribute("grounding.score", grounding_score)
                if relevance_score is not None:
                    span.set_attribute("grounding.relevance_score", relevance_score)

            logger.info(
                f"Grounding check: action={action}, "
                f"grounding_score={grounding_score}, relevance_score={relevance_score}"
            )

            return GroundingCheckResult(
                is_grounded=is_grounded,
                grounding_score=grounding_score,
                relevance_score=relevance_score,
                action=action,
            )

    except Exception as e:
        logger.warning(f"Grounding check failed (fail-open), passing response through: {e}")
        return GroundingCheckResult(is_grounded=True, action="NONE")
