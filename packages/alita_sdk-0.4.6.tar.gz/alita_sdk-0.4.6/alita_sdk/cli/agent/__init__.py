"""Default agent prompts for Alita CLI."""

from .default import DEFAULT_PROMPT

__all__ = ['DEFAULT_PROMPT']
