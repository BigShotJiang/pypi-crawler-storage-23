# figma - get_tools

**Toolkit**: `figma`
**Method**: `get_tools`
**Source File**: `__init__.py`
**Class**: `FigmaToolkit`

---

## Method Implementation

```python
    def get_tools(self):
        return self.tools
```
