# ado - delete_page_by_path

**Toolkit**: `ado`
**Method**: `delete_page_by_path`
**Source File**: `ado_wrapper.py`
**Class**: `AzureDevOpsApiWrapper`

---

## Method Implementation

```python
    def delete_page_by_path(self, wiki_identified: Optional[str] = None, page_name: str = None, image_description_prompt=None):
        """Extract ADO wiki page content."""
        try:
            wiki_id = self._resolve_wiki_identifier(wiki_identified)
            self._client.delete_page(project=self.project, wiki_identifier=wiki_id, path=page_name)
            return f"Page '{page_name}' in wiki '{wiki_id}' has been deleted"
        except Exception as e:
            logger.error(f"Unable to delete wiki page: {str(e)}")
            return ToolException(f"Unable to delete wiki page: {str(e)}")
```
