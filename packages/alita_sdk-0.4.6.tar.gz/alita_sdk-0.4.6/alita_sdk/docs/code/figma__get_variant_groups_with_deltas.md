# figma - get_variant_groups_with_deltas

**Toolkit**: `figma`
**Method**: `get_variant_groups_with_deltas`
**Source File**: `toon_tools.py`

---

## Method Implementation

```python
def get_variant_groups_with_deltas(frames: List[Dict]) -> List[Dict]:
    """
    Get variant groups with computed deltas for efficient output.

    Returns list of variant groups:
    [
        {
            'base_name': 'Login',
            'base_frame': {...full frame data...},
            'variants': [
                {'name': 'Login_Error', 'state': 'error', 'added': {...}, ...},
                ...
            ]
        }
    ]
    """
    groups = group_variants(frames)
    result = []

    for base_name, variant_list in groups.items():
        if len(variant_list) < 2:
            continue

        # Sort variants to find the "default" state as base
        sorted_variants = sorted(variant_list, key=lambda v: (
            0 if infer_state_from_name(v['name']) == 'default' else 1,
            v['name']
        ))

        base_variant = sorted_variants[0]
        base_frame = base_variant.get('frame', {})

        group_data = {
            'base_name': base_name,
            'base_frame': base_frame,
            'variants': [],
        }

        # Compute deltas for other variants
        for variant in sorted_variants[1:]:
            variant_frame = variant.get('frame', {})
            delta = compute_frame_delta(base_frame, variant_frame)
            group_data['variants'].append(delta)

        result.append(group_data)

    return result
```

## Helper Methods

```python
Helper: compute_frame_delta
def compute_frame_delta(base_frame: Dict, variant_frame: Dict) -> Dict[str, Any]:
    """
    Compute the differences between a base frame and a variant.

    Returns dict with only the changed/added content:
    {
        'name': 'Login_Error',
        'state': 'error',
        'added': {'errors': ['Invalid email'], 'buttons': ['Retry']},
        'removed': {'buttons': ['Sign In']},
        'changed': {'headings': 'Welcome → Try Again'}
    }
    """
    delta = {
        'name': variant_frame.get('name', ''),
        'id': variant_frame.get('id', ''),
        'state': variant_frame.get('state', 'default'),
        'added': {},
        'removed': {},
        'changed': {},
    }

    # Fields to compare
    content_fields = ['headings', 'labels', 'buttons', 'body', 'errors', 'placeholders']

    for field in content_fields:
        base_values = set(base_frame.get(field, []))
        variant_values = set(variant_frame.get(field, []))

        added = variant_values - base_values
        removed = base_values - variant_values

        if added:
            delta['added'][field] = list(added)[:5]  # Limit to 5
        if removed:
            delta['removed'][field] = list(removed)[:5]

    # Check for changed components
    base_components = set(base_frame.get('components', []))
    variant_components = set(variant_frame.get('components', []))
    added_components = variant_components - base_components
    removed_components = base_components - variant_components

    if added_components:
        delta['added']['components'] = list(added_components)[:5]
    if removed_components:
        delta['removed']['components'] = list(removed_components)[:5]

    # Clean up empty dicts
    if not delta['added']:
        del delta['added']
    if not delta['removed']:
        del delta['removed']
    if not delta['changed']:
        del delta['changed']

    return delta
```
