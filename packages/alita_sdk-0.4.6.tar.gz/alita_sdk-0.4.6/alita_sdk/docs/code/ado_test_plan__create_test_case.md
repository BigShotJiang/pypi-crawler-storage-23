# ado_test_plan - create_test_case

**Toolkit**: `ado_test_plan`
**Method**: `create_test_case`
**Source File**: `test_plan_wrapper.py`
**Class**: `TestPlanApiWrapper`

---

## Method Implementation

```python
    def create_test_case(self, plan_id: int, suite_id: int, title: str, description: str, test_steps: str,
                         test_steps_format: str = 'json', additional_fields: Optional[str] = None):
        """Creates a new test case in specified suite in Azure DevOps."""
        if test_steps_format == 'json':
            steps_xml = self.get_test_steps_xml(json.loads(test_steps))
        elif test_steps_format == 'xml':
            steps_xml = self.convert_steps_tag_to_ado_steps(test_steps)
        else:
            return ToolException("Unknown test steps format: " + test_steps_format)

        # Parse additional fields if provided
        additional_fields_dict = None
        if additional_fields:
            try:
                additional_fields_dict = json.loads(additional_fields) if isinstance(additional_fields, str) else additional_fields
            except json.JSONDecodeError as e:
                return ToolException(f"Invalid JSON format for additional_fields: {e}")

        work_item_json = self.build_ado_test_case(title, description, steps_xml, additional_fields_dict)

        # Use the class-level work_item wrapper instance
        create_work_item_result = \
        self._work_item_wrapper.create_work_item(work_item_json=json.dumps(work_item_json), wi_type="Test Case")
        if isinstance(create_work_item_result, ToolException):
            # issue creating work item, return error with helpful context
            error_msg = str(create_work_item_result)
            if "TF401320" in error_msg or "validation" in error_msg.lower():
                # Add helpful suggestion about field discovery
                enhanced_error = (
                    f"{error_msg}\n\n"
                    "💡 To discover all required fields for Test Case work items in your project:\n"
                    "   • Use the get_all_test_case_fields_for_project() tool\n"
                    "   • Provide missing required fields via the additional_fields parameter\n"
                    "   • Example: additional_fields='{\"Custom.SDLC\": \"Development\"}'"
                )
                return ToolException(enhanced_error)
            return create_work_item_result
        created_work_item_id = create_work_item_result['id']
        return self.add_test_case([{"work_item": {"id": created_work_item_id}}], plan_id, suite_id)
```

## Helper Methods

```python
Helper: build_ado_test_case
    def build_ado_test_case(self, title, description, steps_xml, additional_fields: Optional[Dict] = None):
        """
        Build Test Case work item JSON with standard and custom fields.

        :param title: test title
        :param description: test description
        :param steps_xml: steps xml
        :param additional_fields: optional dictionary of additional custom fields
        :return: JSON with ADO fields
        """
        # Standard required fields for Test Case
        standard_fields = {
            "System.Title": title,
            "System.Description": description,
            "Microsoft.VSTS.TCM.Steps": steps_xml
        }

        # Merge additional fields if provided
        if additional_fields:
            # Ensure additional fields don't override standard fields
            protected_fields = ["System.Title", "System.Description", "Microsoft.VSTS.TCM.Steps"]
            for field_name, field_value in additional_fields.items():
                if field_name in protected_fields:
                    logger.warning(f"Ignoring attempt to override protected field: {field_name}")
                else:
                    standard_fields[field_name] = field_value

        return {
            "fields": standard_fields
        }
```
