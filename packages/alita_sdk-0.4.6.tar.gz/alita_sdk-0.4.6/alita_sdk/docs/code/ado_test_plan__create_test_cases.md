# ado_test_plan - create_test_cases

**Toolkit**: `ado_test_plan`
**Method**: `create_test_cases`
**Source File**: `test_plan_wrapper.py`
**Class**: `TestPlanApiWrapper`

---

## Method Implementation

```python
    def create_test_cases(self, create_test_cases_parameters):
        """Creates new test cases in specified suite in Azure DevOps."""
        test_cases = json.loads(create_test_cases_parameters)
        return [self.create_test_case(
            plan_id=test_case['plan_id'],
            suite_id=test_case['suite_id'],
            title=test_case['title'],
            description=test_case['description'],
            test_steps=test_case['test_steps'],
            test_steps_format=test_case['test_steps_format'],
            additional_fields=test_case.get('additional_fields', None)) for test_case in test_cases]
```

## Helper Methods

```python
Helper: create_test_case
    def create_test_case(self, plan_id: int, suite_id: int, title: str, description: str, test_steps: str,
                         test_steps_format: str = 'json', additional_fields: Optional[str] = None):
        """Creates a new test case in specified suite in Azure DevOps."""
        if test_steps_format == 'json':
            steps_xml = self.get_test_steps_xml(json.loads(test_steps))
        elif test_steps_format == 'xml':
            steps_xml = self.convert_steps_tag_to_ado_steps(test_steps)
        else:
            return ToolException("Unknown test steps format: " + test_steps_format)

        # Parse additional fields if provided
        additional_fields_dict = None
        if additional_fields:
            try:
                additional_fields_dict = json.loads(additional_fields) if isinstance(additional_fields, str) else additional_fields
            except json.JSONDecodeError as e:
                return ToolException(f"Invalid JSON format for additional_fields: {e}")

        work_item_json = self.build_ado_test_case(title, description, steps_xml, additional_fields_dict)

        # Use the class-level work_item wrapper instance
        create_work_item_result = \
        self._work_item_wrapper.create_work_item(work_item_json=json.dumps(work_item_json), wi_type="Test Case")
        if isinstance(create_work_item_result, ToolException):
            # issue creating work item, return error with helpful context
            error_msg = str(create_work_item_result)
            if "TF401320" in error_msg or "validation" in error_msg.lower():
                # Add helpful suggestion about field discovery
                enhanced_error = (
                    f"{error_msg}\n\n"
                    "💡 To discover all required fields for Test Case work items in your project:\n"
                    "   • Use the get_all_test_case_fields_for_project() tool\n"
                    "   • Provide missing required fields via the additional_fields parameter\n"
                    "   • Example: additional_fields='{\"Custom.SDLC\": \"Development\"}'"
                )
                return ToolException(enhanced_error)
            return create_work_item_result
        created_work_item_id = create_work_item_result['id']
        return self.add_test_case([{"work_item": {"id": created_work_item_id}}], plan_id, suite_id)
```
