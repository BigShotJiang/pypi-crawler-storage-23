# bitbucket - update_file

**Toolkit**: `bitbucket`
**Method**: `update_file`
**Source File**: `api_wrapper.py`
**Class**: `BitbucketAPIWrapper`

---

## Method Implementation

```python
    def update_file(self, file_path: str, update_query: str, branch: str) -> ToolException | str:
        """
        Updates file on the bitbucket repo
        Parameters:
            file_path(str): a string which contains the file path (example: "hello_world.md").
            update_query(str): Contains the file contents required to be updated.
                The old file contents is wrapped in OLD <<<< and >>>> OLD
                The new file contents is wrapped in NEW <<<< and >>>> NEW
                IMPORTANT: Markers must be on their own dedicated line (not inline with content).
                Multiple OLD/NEW pairs are supported for multiple edits.
                For example:
                OLD <<<<
                Hello Earth!
                >>>> OLD
                NEW <<<<
                Hello Mars!
                >>>> NEW
            branch(str): branch name (by default: active_branch)
        Returns:
            str | ToolException: A success message or a ToolException on failure.
        """
        try:
            # Use the shared edit_file logic from BaseCodeToolApiWrapper, operating on
            # this wrapper instance, which provides _read_file and _write_file.
            result = self.edit_file(
                file_path=file_path,
                branch=branch,
                file_query=update_query,
            )
            return result
        except ToolException as e:
            # Pass through ToolExceptions as-is so callers can handle them uniformly.
            return e
        except Exception as e:
            return ToolException(f"File was not updated due to error: {str(e)}")
```
