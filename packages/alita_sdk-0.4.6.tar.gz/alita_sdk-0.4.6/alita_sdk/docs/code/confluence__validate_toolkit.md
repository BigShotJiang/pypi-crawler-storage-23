# confluence - validate_toolkit

**Toolkit**: `confluence`
**Method**: `validate_toolkit`
**Source File**: `api_wrapper.py`
**Class**: `ConfluenceAPIWrapper`

---

## Method Implementation

```python
    def validate_toolkit(cls, values):
        try:
            from atlassian import Confluence  # noqa: F401
        except ImportError:
            raise ImportError(
                "`atlassian` package not found, please run "
                "`pip install atlassian-python-api`"
            )
        if not values.get('base_url'):
            raise ValueError("Base URL is required for Confluence API Wrapper.")
        url = values['base_url']
        if not (values.get('token') or (values.get('api_key') and values.get('username'))):
            raise ValueError("Either 'token' or both 'api_key' and 'username' must be provided for authentication.")

        # Normalize base_url: For Atlassian Cloud, strip /wiki suffix to prevent duplication
        # The _build_page_url method will add /wiki as needed
        cloud = values.get('cloud', True)
        if cloud and url.rstrip('/').endswith('/wiki'):
            # Remove /wiki suffix for Atlassian Cloud instances
            # This prevents URL duplication like /wiki/wiki/spaces/...
            url = url.rstrip('/')[:-5]  # Remove '/wiki'
            values['base_url'] = url
            logger.info(f"Normalized Confluence base_url by removing /wiki suffix: {url}")

        api_key = values.get('api_key')
        username = values.get('username')
        token = values.get('token')
        if token and is_cookie_token(token):
            session = requests.Session()
            session.cookies.update(parse_cookie_string(token))
            client_instance = Confluence(url=url, session=session, cloud=cloud)
        elif token:
            client_instance = Confluence(url=url, token=token, cloud=cloud)
        else:
            client_instance = Confluence(url=url, username=username, password=api_key, cloud=cloud)

        custom_headers = values.get('custom_headers') or {}
        logger.info(f"Confluence tool: custom headers length: {len(custom_headers)}")
        for header, value in custom_headers.items():
            client_instance._update_header(header, value)

        values['client'] = client_instance
        return super().validate_toolkit(values)
```
