# carrier - parse_config_from_string

**Toolkit**: `carrier`
**Method**: `parse_config_from_string`
**Source File**: `utils.py`

---

## Method Implementation

```python
def parse_config_from_string(config_str: str) -> dict:
    """
    Parse configuration from a JSON string or key-value pairs.

    Args:
        config_str (str): Configuration string in JSON or key:value format

    Returns:
        dict: Parsed configuration
    """
    try:
        # Try parsing as JSON first
        return json.loads(config_str)
    except json.JSONDecodeError:
        # If not JSON, try parsing as key:value pairs
        config = {}
        for line in config_str.split('\n'):
            if ':' in line:
                key, value = line.split(':', 1)
                config[key.strip()] = value.strip()
        return config
```
