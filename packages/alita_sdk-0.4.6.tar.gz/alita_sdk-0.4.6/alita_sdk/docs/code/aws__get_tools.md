# aws - get_tools

**Toolkit**: `aws`
**Method**: `get_tools`
**Source File**: `__init__.py`
**Class**: `DeltaLakeToolkit`

---

## Method Implementation

```python
    def get_tools(self):
        return self.tools
```
