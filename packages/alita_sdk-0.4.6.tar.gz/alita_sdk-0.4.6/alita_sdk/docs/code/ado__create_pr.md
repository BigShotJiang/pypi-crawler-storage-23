# ado - create_pr

**Toolkit**: `ado`
**Method**: `create_pr`
**Source File**: `repos_wrapper.py`
**Class**: `ReposApiWrapper`

---

## Method Implementation

```python
    def create_pr(
            self, pull_request_title: str, pull_request_body: str, target_branch: str, source_branch: str
    ) -> str:
        """
        Creates a pull request in Azure DevOps from the active branch to the base branch mentioned in params.

        Parameters:
            pull_request_title (str): Title of the pull request.
            pull_request_body (str): Description/body of the pull request.
            target_branch (str): The name of the branch which is used as target branch for pull request.
            source_branch (str): The name of the source branch which is used as source branch for pull request.

        Returns:
            str: A success or failure message.
        """
        if source_branch == target_branch:
            return f"Cannot create a pull request because the source branch '{source_branch}' is the same as the target branch '{target_branch}'"

        try:
            pull_request = {
                "sourceRefName": f"refs/heads/{source_branch}",
                "targetRefName": f"refs/heads/{target_branch}",
                "title": pull_request_title,
                "description": pull_request_body,
                "reviewers": [],
            }

            response = self._client.create_pull_request(
                git_pull_request_to_create=pull_request,
                repository_id=self.repository_id,
                project=self.project,
            )

            return f"Successfully created PR with ID {response.pull_request_id}"
        except Exception as e:
            msg = f"Unable to create pull request due to error: {str(e)}"
            logger.error(msg)
            raise ToolException(msg)
```
