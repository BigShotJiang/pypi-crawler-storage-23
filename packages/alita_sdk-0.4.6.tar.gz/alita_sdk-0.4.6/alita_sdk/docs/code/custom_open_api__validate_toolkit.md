# custom_open_api - validate_toolkit

**Toolkit**: `custom_open_api`
**Method**: `validate_toolkit`
**Source File**: `api_wrapper.py`
**Class**: `OpenApiWrapper`

---

## Method Implementation

```python
    def validate_toolkit(cls, values):
        cls._client = urllib3.PoolManager()
        return values
```
