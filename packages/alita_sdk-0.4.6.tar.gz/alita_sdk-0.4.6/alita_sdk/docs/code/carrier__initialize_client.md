# carrier - initialize_client

**Toolkit**: `carrier`
**Method**: `initialize_client`
**Source File**: `api_wrapper.py`
**Class**: `CarrierAPIWrapper`

---

## Method Implementation

```python
    def initialize_client(self):
        if not self.project_id:
            raise ValueError("project_id is required and cannot be empty.")
        try:
            credentials = CarrierCredentials(
                url=self.url,
                token=self.private_token.get_secret_value(),
                organization=self.organization,
                project_id=self.project_id
            )
            self._client = CarrierClient(credentials=credentials)
            logger.info("CarrierAPIWrapper initialized successfully.")
        except Exception as e:
            logger.error(f"Initialization failed: {e}")
            raise e
        return self
```
