# aws - validate_auth

**Toolkit**: `aws`
**Method**: `validate_auth`
**Source File**: `api_wrapper.py`
**Class**: `DeltaLakeApiWrapper`

---

## Method Implementation

```python
    def validate_auth(self) -> "DeltaLakeApiWrapper":
        if not (self.aws_access_key_id and self.aws_secret_access_key and self.aws_region):
            raise ValueError("You must provide AWS credentials and region.")
        if not (self.s3_path or self.table_path):
            raise ValueError("You must provide either s3_path or table_path.")
        return self
```
