# ado_work_item - get_work_item_type_fields

**Toolkit**: `ado_work_item`
**Method**: `get_work_item_type_fields`
**Source File**: `ado_wrapper.py`
**Class**: `AzureDevOpsApiWrapper`

---

## Method Implementation

```python
    def get_work_item_type_fields(self, work_item_type: str = "Task", force_refresh: bool = False) -> str:
        """
        Get formatted information about available fields for a specific work item type.
        This method helps discover which fields are required for work item creation.

        Args:
            work_item_type: The work item type to get fields for (e.g., 'Task', 'Bug', 'Test Case', 'Epic').
                           Default is 'Task'.
            force_refresh: If True, reload field definitions from Azure DevOps instead of using cache.
                          Use this if project configuration has changed (new fields added, etc.).

        Returns:
            Formatted string with field names, types, and requirements
        """
        cache_key = work_item_type

        if force_refresh or cache_key not in self._work_item_type_fields_cache:
            self._work_item_type_fields_cache[cache_key] = self._get_work_item_type_fields(work_item_type)

        return self._format_work_item_type_fields_for_display(work_item_type, self._work_item_type_fields_cache[cache_key])
```
