# confluence - parse_payload_params

**Toolkit**: `confluence`
**Method**: `parse_payload_params`
**Source File**: `api_wrapper.py`

---

## Method Implementation

```python
def parse_payload_params(params: Optional[str]) -> Dict[str, Any]:
    if params:
        try:
            return json.loads(params)
        except JSONDecodeError:
            stacktrace = traceback.format_exc()
            return ToolException(f"Confluence tool exception. Passed params are not valid JSON. {stacktrace}")
    return {}
```
