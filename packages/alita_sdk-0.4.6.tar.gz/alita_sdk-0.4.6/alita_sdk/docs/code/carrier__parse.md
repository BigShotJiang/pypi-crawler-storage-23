# carrier - parse

**Toolkit**: `carrier`
**Method**: `parse`
**Source File**: `excel_reporter.py`
**Class**: `GatlingReportParser`

---

## Method Implementation

```python
    def parse(self) -> Dict[str, Any]:
        latest_log_file = self.log_file
        print(f"Path: {latest_log_file}")
        groups, requests, users, date_start, date_end, ramp_up_period = self.parse_log_file(latest_log_file)

        # Combine requests and groups for reporting purposes
        requests = defaultdict(list, {**requests})
        duration = self.calculate_duration(date_start, date_end)

        transactions_data = {
            "requests": {
                transaction: self.calculate_single_metric(transaction, entries)
                for transaction, entries in requests.items()
            },
            "groups": {
                group: self.calculate_single_metric(group, entries)
                for group, entries in groups.items()
            }
        }
        # Calculate total requests only from the original requests dictionary
        total_requests = self.calculate_all_requests(requests)
        transactions_data["requests"]["Total Requests"] = total_requests

        throughput = total_requests['Total'] / (duration * 60)  # Initializing a variable with the default value

        if duration > 1:
            duration = round(duration)
        if ramp_up_period > 1:
            ramp_up_period = round(ramp_up_period, 1)
            throughput = total_requests['Total'] / (duration * 60)
        if throughput > 1:
            throughput = round(throughput, 1)

        # Add any additional required summary metrics
        # Convert to Eastern Time (EST/EDT)
        from pytz import timezone
        eastern = timezone('US/Eastern')
        date_start = date_start.astimezone(eastern) if date_start else None
        date_end = date_end.astimezone(eastern) if date_end else None

        transactions_data.update({
            'max_user_count': users,
            'ramp_up_period': ramp_up_period,
            'error_rate': total_requests['Error%'],
            'date_start': date_start.strftime('%Y-%m-%d %H:%M:%S') if date_start else None,
            'date_end': date_end.strftime('%Y-%m-%d %H:%M:%S') if date_end else None,
            'throughput': throughput,
            'duration': duration,
            'think_time': self.calculated_think_time
        })
        return transactions_data
```

## Helper Methods

```python
Helper: calculate_all_requests
    def calculate_all_requests(self, requests: defaultdict) -> dict:
        all_entries = [entry for entries in requests.values() for entry in entries]
        return self.calculate_single_metric('Total', all_entries)
```
