# aws - set_from_values_or_env

**Toolkit**: `aws`
**Method**: `set_from_values_or_env`
**Source File**: `api_wrapper.py`
**Class**: `DeltaLakeApiWrapper`

---

## Method Implementation

```python
    def set_from_values_or_env(cls, value, info: ValidationInfo):
        if value is None:
            if json_schema_extra := cls.model_fields[info.field_name].json_schema_extra:
                if env_key := json_schema_extra.get("env_key"):
                    try:
                        from langchain_core.utils import get_from_env
                        return get_from_env(
                            key=info.field_name,
                            env_key=env_key,
                            default=cls.model_fields[info.field_name].default,
                        )
                    except Exception:
                        return None
        return value
```
