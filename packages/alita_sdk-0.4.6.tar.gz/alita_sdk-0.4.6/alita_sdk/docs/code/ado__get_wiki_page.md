# ado - get_wiki_page

**Toolkit**: `ado`
**Method**: `get_wiki_page`
**Source File**: `ado_wrapper.py`
**Class**: `AzureDevOpsApiWrapper`

---

## Method Implementation

```python
    def get_wiki_page(self, wiki_identified: Optional[str] = None, page_path: Optional[str] = None, page_id: Optional[int] = None,
                      include_content: bool = False, image_description_prompt: Optional[str] = None,
                      recursion_level: str = "oneLevel"):
        """Get wiki page metadata and optionally content.

        Retrieves comprehensive metadata for a wiki page including eTag, id, path, git_item_path,
        remote_url, url, sub_pages, order, and other properties. Optionally includes page content.
        Supports lookup by either page_id (takes precedence) or page_path.

        Args:
            wiki_identified: Wiki ID or wiki name. If not provided, uses default from toolkit configuration.
            page_path: Wiki page path (e.g., '/MB_Heading/MB_2'). Optional if page_id is provided.
            page_id: Wiki page ID. Optional if page_path is provided. Takes precedence over page_path.
            include_content: Whether to include page content in response. Defaults to False (metadata only).
            image_description_prompt: Optional prompt for image description when include_content is True.
            recursion_level: Level of recursion to retrieve sub-pages. Options: 'none' (no subpages),
                           'oneLevel' (direct children only), 'full' (all descendants). Defaults to 'oneLevel'.

        Returns:
            Dictionary containing eTag and comprehensive page metadata including id, path, git_item_path,
            remote_url, url, sub_pages, order, is_parent_page, is_non_conformant, and optionally content.

        Raises:
            ToolException: If page/wiki not found, authentication fails, or other errors occur.
        """
        try:
            # Resolve wiki identifier
            wiki_id = self._resolve_wiki_identifier(wiki_identified)

            # Validate that at least one identifier is provided
            if not page_path and not page_id:
                raise ToolException("At least one of 'page_path' or 'page_id' must be provided")

            # Fetch page using page_id (priority) or page_path
            if page_id:
                logger.info(f"Fetching wiki page by ID: {page_id} from wiki: {wiki_id}")
                wiki_page_response = self._client.get_page_by_id(
                    project=self.project,
                    wiki_identifier=wiki_id,
                    id=page_id,
                    include_content=include_content,
                    recursion_level=recursion_level
                )
            else:
                logger.info(f"Fetching wiki page by path: {page_path} from wiki: {wiki_id}")
                wiki_page_response = self._client.get_page(
                    project=self.project,
                    wiki_identifier=wiki_id,
                    path=page_path,
                    include_content=include_content,
                    recursion_level=recursion_level
                )

            # Format response with comprehensive metadata
            result = _format_wiki_page_response(
                wiki_page_response,
                expanded=True,
                include_content=include_content
            )

            # Process images in content if requested
            if include_content and result.get('page', {}).get('content'):
                processed_content = self._process_images(
                    result['page']['content'],
                    image_description_prompt=image_description_prompt,
                    wiki_identified=wiki_id
                )
                result['page']['content'] = processed_content

            return result

        except AzureDevOpsServiceError as e:
            error_msg = str(e).lower()

            # Page not found errors
            if "404" in error_msg or "not found" in error_msg or "does not exist" in error_msg:
                identifier = f"ID {page_id}" if page_id else f"path '{page_path}'"
                wiki_id = wiki_identified or self.default_wiki_identifier or "unknown"
                logger.error(f"Page {identifier} not found in wiki '{wiki_id}': {str(e)}")
                return ToolException(
                    f"Page {identifier} not found in wiki '{wiki_id}'. "
                    f"Please verify the page exists and the identifier is correct."
                )

            # Path validation errors
            elif "path" in error_msg and ("correct" in error_msg or "invalid" in error_msg):
                wiki_id = wiki_identified or self.default_wiki_identifier or "unknown"
                logger.error(f"Invalid page path '{page_path}' in wiki '{wiki_id}': {str(e)}")
                return ToolException(
                    f"Invalid page path '{page_path}'. Please ensure the path format is correct (e.g., '/PageName')."
                )

            # Wiki not found errors
            elif "wiki" in error_msg and ("not found" in error_msg or "does not exist" in error_msg):
                wiki_id = wiki_identified or self.default_wiki_identifier or "unknown"
                logger.error(f"Wiki '{wiki_id}' not found: {str(e)}")
                return ToolException(
                    f"Wiki '{wiki_id}' not found. Please verify the wiki identifier is correct."
                )

            # Authentication/authorization errors
            elif "401" in error_msg or "unauthorized" in error_msg or "authentication" in error_msg:
                wiki_id = wiki_identified or self.default_wiki_identifier or "unknown"
                logger.error(f"Authentication failed for wiki '{wiki_id}': {str(e)}")
                return ToolException(
                    f"Authentication failed. Please check your access token is valid and has permission to access wiki '{wiki_id}'."
                )

            elif "403" in error_msg or "forbidden" in error_msg or "permission" in error_msg:
                wiki_id = wiki_identified or self.default_wiki_identifier or "unknown"
                logger.error(f"Permission denied for wiki '{wiki_id}': {str(e)}")
                return ToolException(
                    f"Permission denied. You do not have access to wiki '{wiki_id}' or page {page_id if page_id else page_path}."
                )

            # Generic Azure DevOps service errors
            else:
                logger.error(f"Azure DevOps service error while fetching page: {str(e)}")
                return ToolException(f"Error accessing wiki page: {str(e)}")

        except ValueError as e:
            logger.error(f"Validation error: {str(e)}")
            return ToolException(f"Validation error: {str(e)}")

        except Exception as e:
            error_msg = str(e).lower()

            # Timeout errors
            if "timeout" in error_msg or "timed out" in error_msg:
                logger.error(f"Connection timeout while fetching page: {str(e)}")
                return ToolException(
                    f"Connection timeout. Please check your network connection and try again."
                )

            # Generic errors
            logger.error(f"Unexpected error during wiki page retrieval: {str(e)}")
            return ToolException(f"Unexpected error during wiki page retrieval: {str(e)}")
```
