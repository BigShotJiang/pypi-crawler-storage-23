# carrier - add_tag_to_report

**Toolkit**: `carrier`
**Method**: `add_tag_to_report`
**Source File**: `carrier_sdk.py`
**Class**: `CarrierClient`

---

## Method Implementation

```python
    def add_tag_to_report(self, report_id, tag_name):
        endpoint = f"api/v1/backend_performance/tags/{self.credentials.project_id}/{report_id}"
        full_url = f"{self.credentials.url.rstrip('/')}/{endpoint.lstrip('/')}"
        headers = {
            'Authorization': f'bearer {self.credentials.token}',
            'content-type': 'application/json'
        }
        data = {"tags": [{"title": tag_name, "hex": "#5933c6"}]}
        res = requests.post(full_url, headers=headers, json=data)
        return res
```
