# aws - toolkit_context

**Toolkit**: `aws`
**Method**: `toolkit_context`
**Source File**: `__init__.py`
**Class**: `DeltaLakeToolkit`

---

## Method Implementation

```python
    def toolkit_context(self) -> str:
        """Returns toolkit context for descriptions (max 1000 chars)."""
        return (
            f" [Toolkit: {clean_string(self.toolkit_name, 0)}]"
            if self.toolkit_name
            else ""
        )
```
