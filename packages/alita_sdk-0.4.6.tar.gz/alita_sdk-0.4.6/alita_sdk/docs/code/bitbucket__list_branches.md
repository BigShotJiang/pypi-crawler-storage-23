# bitbucket - list_branches

**Toolkit**: `bitbucket`
**Method**: `list_branches`
**Source File**: `cloud_api_wrapper.py`
**Class**: `BitbucketCloudApi`

---

## Method Implementation

```python
    def list_branches(self) -> List[str]:
        branches = self.repository.branches.each()
        branch_names = [branch.name for branch in branches]
        return branch_names
```
