# ado_repos - get_work_items

**Toolkit**: `ado_repos`
**Method**: `get_work_items`
**Source File**: `repos_wrapper.py`
**Class**: `ReposApiWrapper`

---

## Method Implementation

```python
    def get_work_items(self, pull_request_id: int):
        """
        Fetches a specific work item and its first 10 comments from Azure DevOps.
        Parameters:
            pull_request_id (int): The ID for Pull Request based on which to get Work Item
        Returns:
            dict: A dictionary containing the work item's title, description, comments as a string,
                and the username of the user who created the work item
        """
        try:
            work_items = self._client.get_pull_request_work_item_refs(
                repository_id=self.repository_id,
                pull_request_id=pull_request_id,
                project=self.project,
            )

            work_item_ids = [work_item_ref.id for work_item_ref in work_items[:10]]
        except Exception as e:
            msg = f"Unable to get Work Items due to error:\n{str(e)}"
            logger.error(msg)
            return ToolException(msg)
        return work_item_ids
```
