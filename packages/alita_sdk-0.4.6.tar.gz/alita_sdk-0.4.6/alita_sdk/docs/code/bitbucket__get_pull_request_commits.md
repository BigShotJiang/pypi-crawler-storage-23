# bitbucket - get_pull_request_commits

**Toolkit**: `bitbucket`
**Method**: `get_pull_request_commits`
**Source File**: `cloud_api_wrapper.py`
**Class**: `BitbucketCloudApi`

---

## Method Implementation

```python
    def get_pull_request_commits(self, pr_id: str) -> List[Dict[str, Any]]:
        """
        Get commits from a pull request
        Parameters:
            pr_id(str): the pull request ID
        Returns:
            List[Dict[str, Any]]: List of commits in the pull request
        """
        return self.repository.pullrequests.get(pr_id).get('commits', {}).get('values', [])
```
