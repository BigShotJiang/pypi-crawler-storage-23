# figma - format_component_summary

**Toolkit**: `figma`
**Method**: `format_component_summary`
**Source File**: `toon_tools.py`

---

## Method Implementation

```python
def format_component_summary(components: List[str]) -> str:
    """
    Format components into a semantic summary.

    Instead of: "Button/Primary, Button/Secondary, Input/Text, Icon/Search"
    Returns: "2 buttons, 1 input, 1 icon"
    """
    if not components:
        return ''

    categorized = categorize_components(components)

    # Build summary parts with counts
    parts = []
    # Priority order for display
    priority = ['buttons', 'inputs', 'selects', 'toggles', 'cards', 'navigation',
                'modals', 'lists', 'alerts', 'badges', 'images', 'icons', 'progress', 'dividers', 'other']

    for cat in priority:
        if cat in categorized:
            count = len(categorized[cat])
            # Use singular/plural
            if cat == 'other':
                label = 'other' if count == 1 else 'other'
            else:
                label = cat.rstrip('s') if count == 1 else cat
            parts.append(f"{count} {label}")

    return ', '.join(parts[:6])  # Limit to 6 categories
```

## Helper Methods

```python
Helper: categorize_components
def categorize_components(components: List[str]) -> Dict[str, List[str]]:
    """
    Group components into semantic categories.

    Returns:
        {
            'buttons': ['Button/Primary', 'Button/Secondary'],
            'inputs': ['Input/Text', 'Input/Email'],
            'other': ['CustomComponent'],
            ...
        }
    """
    categorized = {cat: [] for cat in COMPONENT_CATEGORIES}
    categorized['other'] = []

    for component in components:
        comp_lower = component.lower()
        found_category = False

        for category, keywords in COMPONENT_CATEGORIES.items():
            if any(kw in comp_lower for kw in keywords):
                categorized[category].append(component)
                found_category = True
                break

        if not found_category:
            categorized['other'].append(component)

    # Remove empty categories
    return {k: v for k, v in categorized.items() if v}
```
