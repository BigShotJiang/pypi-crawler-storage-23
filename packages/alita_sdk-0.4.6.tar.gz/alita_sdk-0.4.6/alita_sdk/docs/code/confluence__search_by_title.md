# confluence - search_by_title

**Toolkit**: `confluence`
**Method**: `search_by_title`
**Source File**: `api_wrapper.py`
**Class**: `ConfluenceAPIWrapper`

---

## Method Implementation

```python
    def search_by_title(self, query: str, skip_images: bool = False):
        """Search pages in Confluence by query text in title."""

        query = self._escape_cql_query(query)
        if not self.space:
            cql = f'(type=page) and (title~"{query}")'
        else:
            cql = f'(type=page and space={self.__sanitize_confluence_space()}) and (title~"{query}")'
        return self._process_search(cql, skip_images)
```
