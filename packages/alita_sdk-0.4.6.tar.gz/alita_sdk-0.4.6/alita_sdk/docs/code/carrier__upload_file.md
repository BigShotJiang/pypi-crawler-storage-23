# carrier - upload_file

**Toolkit**: `carrier`
**Method**: `upload_file`
**Source File**: `carrier_sdk.py`
**Class**: `CarrierClient`

---

## Method Implementation

```python
    def upload_file(self, bucket_name: str, file_name: str):
        upload_url = f'api/v1/artifacts/artifacts/{self.credentials.project_id}/{bucket_name}'
        full_url = f"{self.credentials.url.rstrip('/')}/{upload_url.lstrip('/')}"
        files = {'file': open(file_name, 'rb')}
        headers = {'Authorization': f'bearer {self.credentials.token}'}
        s3_config = {'integration_id': 1, 'is_local': False}
        requests.post(full_url, params=s3_config, allow_redirects=True, files=files, headers=headers)
```
