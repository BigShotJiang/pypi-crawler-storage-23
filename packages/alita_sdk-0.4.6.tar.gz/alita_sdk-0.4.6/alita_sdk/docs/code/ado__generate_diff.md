# ado - generate_diff

**Toolkit**: `ado`
**Method**: `generate_diff`
**Source File**: `utils.py`

---

## Method Implementation

```python
def generate_diff(base_text, target_text, file_path):
    base_lines = base_text.splitlines(keepends=True)
    target_lines = target_text.splitlines(keepends=True)
    diff = difflib.unified_diff(
        base_lines, target_lines, fromfile=f"a/{file_path}", tofile=f"b/{file_path}"
    )

    return "".join(diff)
```
