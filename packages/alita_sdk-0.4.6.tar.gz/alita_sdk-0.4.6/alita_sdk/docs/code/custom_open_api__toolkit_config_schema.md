# custom_open_api - toolkit_config_schema

**Toolkit**: `custom_open_api`
**Method**: `toolkit_config_schema`
**Source File**: `__init__.py`
**Class**: `OpenApiToolkit`

---

## Method Implementation

```python
    def toolkit_config_schema() -> BaseModel:
        selected_tools = {x['name']: x['args_schema'].schema() for x in OpenApiWrapper.model_construct().get_available_tools()}
        return create_model(
            name,
            spec=(str, Field(default="", title="Specification", description="OpenAPI specification")),
            api_key=(str, Field(default="", title="API key", description="API key", json_schema_extra={'secret': True})),
            selected_tools=(List[Literal[tuple(selected_tools)]], Field(default=[], json_schema_extra={'args_schemas': selected_tools})),
            __config__=ConfigDict(json_schema_extra={'metadata':
                                                         {"label": "OpenAPI", "icon_url": None,
                                                          "categories": ["testing"],
                                                          "extra_categories": [ "openapi", "swagger"]}})
        )
```
