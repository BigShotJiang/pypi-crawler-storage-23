# carrier - parse_request_line

**Toolkit**: `carrier`
**Method**: `parse_request_line`
**Source File**: `excel_reporter.py`
**Class**: `GatlingReportParser`

---

## Method Implementation

```python
    def parse_request_line(requests, line):
        parts = line.split('\t')
        if len(parts) >= 7:
            request_name = parts[2]
            start_time = int(parts[3])
            end_time = int(parts[4])
            status = parts[5].strip()
            response_time = (end_time - start_time)
            requests[request_name].append((response_time, status))
```
