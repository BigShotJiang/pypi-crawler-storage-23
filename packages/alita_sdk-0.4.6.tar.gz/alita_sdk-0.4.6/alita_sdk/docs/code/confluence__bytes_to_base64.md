# confluence - bytes_to_base64

**Toolkit**: `confluence`
**Method**: `bytes_to_base64`
**Source File**: `utils.py`

---

## Method Implementation

```python
def bytes_to_base64(bt: bytes) -> str:
    return base64.b64encode(bt).decode('utf-8')
```
