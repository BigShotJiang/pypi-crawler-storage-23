# figma - check_before

**Toolkit**: `figma`
**Method**: `check_before`
**Source File**: `api_wrapper.py`
**Class**: `FigmaApiWrapper`

---

## Method Implementation

```python
    def check_before(cls, values):
        return super().validate_toolkit(values)
```
