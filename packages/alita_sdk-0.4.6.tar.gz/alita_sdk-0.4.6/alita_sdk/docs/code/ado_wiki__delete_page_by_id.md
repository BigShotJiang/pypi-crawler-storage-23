# ado_wiki - delete_page_by_id

**Toolkit**: `ado_wiki`
**Method**: `delete_page_by_id`
**Source File**: `ado_wrapper.py`
**Class**: `AzureDevOpsApiWrapper`

---

## Method Implementation

```python
    def delete_page_by_id(self, wiki_identified: Optional[str] = None, page_id: int = None, image_description_prompt=None):
        """Extract ADO wiki page content."""
        try:
            wiki_id = self._resolve_wiki_identifier(wiki_identified)
            self._client.delete_page_by_id(project=self.project, wiki_identifier=wiki_id, id=page_id)
            return f"Page with id '{page_id}' in wiki '{wiki_id}' has been deleted"
        except Exception as e:
            logger.error(f"Unable to delete wiki page: {str(e)}")
            return ToolException(f"Unable to delete wiki page: {str(e)}")
```
