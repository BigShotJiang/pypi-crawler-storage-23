# carrier - download_and_merge_reports

**Toolkit**: `carrier`
**Method**: `download_and_merge_reports`
**Source File**: `carrier_sdk.py`
**Class**: `CarrierClient`

---

## Method Implementation

```python
    def download_and_merge_reports(self, report_files_list: list, lg_type: str, bucket: str, extract_to: str = "/tmp"):
        if lg_type == "jmeter":
            summary_log_file_path = f"summary_{bucket}_jmeter.jtl"
            error_log_file_path = f"error_{bucket}_jmeter.log"
        else:
            summary_log_file_path = f"summary_{bucket}_simulation.log"
            error_log_file_path = f"error_{bucket}_simulation.log"
        extracted_reports = []
        for each in report_files_list:
            endpoint = f"api/v1/artifacts/artifact/{self.credentials.project_id}/{bucket}/{each}"
            response = self.session.get(f"{self.credentials.url}/{endpoint}")
            local_file_path = f"{extract_to}/{each}"
            with open(local_file_path, 'wb') as f:
                f.write(response.content)

            extract_dir = f"{local_file_path.replace('.zip', '')}"
            try:
                shutil.rmtree(extract_dir)
            except Exception as e:
                logger.error(e)
            import zipfile
            with zipfile.ZipFile(local_file_path, 'r') as zip_ref:
                zip_ref.extractall(extract_dir)
            import os
            if os.path.exists(local_file_path):
                os.remove(local_file_path)
            extracted_reports.append(extract_dir)

        # get files from extract_dirs and merge to summary_log_file_path and error_log_file_path
        self.merge_log_files(summary_log_file_path, extracted_reports, lg_type)
        try:
            self.merge_error_files(error_log_file_path, extracted_reports)
        except Exception as e:
            logger.error(f"Failed to merge errors log: {e}")

        # Clean up
        for each in extracted_reports:
            try:
                shutil.rmtree(each)
            except Exception as e:
                logger.error(e)

        return summary_log_file_path, error_log_file_path
```

## Helper Methods

```python
Helper: merge_log_files
    def merge_log_files(self, summary_file, extracted_reports, lg_type):
        with open(summary_file, mode='w') as summary:
            for i, log_file in enumerate(extracted_reports):
                if lg_type == "jmeter":
                    report_file = f"{log_file}/jmeter.jtl"
                else:
                    report_file = get_latest_log_file(log_file, "simulation.log")
                with open(report_file, mode='r') as f:
                    lines = f.readlines()
                    if i == 0:
                        # Write all lines from the first file (including the header)
                        summary.writelines(lines)
                    else:
                        # Skip the first line (header) for subsequent files
                        summary.writelines(lines[1:])
```

```python
Helper: merge_error_files
    def merge_error_files(self, error_file, extracted_reports):
        with open(error_file, mode='w') as summary_errors:
            for i, log_file in enumerate(extracted_reports):
                report_file = f"{log_file}/simulation-errors.log"
                with open(report_file, mode='r') as f:
                    lines = f.readlines()
                    summary_errors.writelines(lines)
```
