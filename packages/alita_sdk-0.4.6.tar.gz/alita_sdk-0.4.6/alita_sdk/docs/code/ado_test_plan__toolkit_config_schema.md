# ado_test_plan - toolkit_config_schema

**Toolkit**: `ado_test_plan`
**Method**: `toolkit_config_schema`
**Source File**: `__init__.py`
**Class**: `AzureDevOpsPlansToolkit`

---

## Method Implementation

```python
    def toolkit_config_schema() -> BaseModel:
        selected_tools = {x['name']: x['args_schema'].schema() for x in TestPlanApiWrapper.model_construct().get_available_tools()}
        m = create_model(
            name_alias,
            ado_configuration=(AdoConfiguration, Field(description="Ado configuration", json_schema_extra={'configuration_types': ['ado']})),
            limit=(Optional[int], Field(description="ADO plans limit used for limitation of the list with results", default=5, gt=0)),
            # indexer settings
            pgvector_configuration=(Optional[PgVectorConfiguration], Field(default=None,
                                                                           description="PgVector Configuration", json_schema_extra={'configuration_types': ['pgvector']})),
            # embedder settings
            embedding_model=(Optional[str], Field(default=None, description="Embedding configuration.", json_schema_extra={'configuration_model': 'embedding'})),
            selected_tools=(List[Literal[tuple(selected_tools)]], Field(default=[], json_schema_extra={'args_schemas': selected_tools})),
            __config__={'json_schema_extra': {'metadata':
                {
                    "label": "ADO plans",
                    "icon_url": "ado-plans.svg",
                    "categories": ["test management"],
                    "extra_categories": ["test case management", "qa"],
                    "sections": {
                        "auth": {
                            "required": True,
                            "subsections": [
                                {
                                    "name": "Token",
                                    "fields": ["token"]
                                }
                            ]
                        }
                    },
                    # connect different toolkits under the same configuration group with the same name,
                    # label and icon
                    "configuration_group": {
                        "name": "ado",
                        "label": "Azure DevOps",
                        "icon_url": "azure-icon.svg",
                    }
                }
            }
            }
        )

        @check_connection_response
        def check_connection(self):
            ado_config = self.ado_test_plan_configuration.ado_configuration if self.ado_test_plan_configuration else None
            if not ado_config:
                raise ValueError("ADO test plan configuration is required")
            response = requests.get(
                f'{ado_config.organization_url}/{ado_config.project}/_apis/testplan/plans?api-version=7.0',
                headers = {'Authorization': f'Bearer {ado_config.token}'},
                timeout=5
            )
            return response

        m.check_connection = check_connection
        return m
```
