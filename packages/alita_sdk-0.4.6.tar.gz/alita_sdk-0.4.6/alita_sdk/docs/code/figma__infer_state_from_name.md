# figma - infer_state_from_name

**Toolkit**: `figma`
**Method**: `infer_state_from_name`
**Source File**: `toon_tools.py`

---

## Method Implementation

```python
def infer_state_from_name(name: str) -> str:
    """
    Infer screen state from name.

    Returns: default, error, success, loading, empty, or the detected state
    """
    name_lower = name.lower()

    state_keywords = {
        'error': ['error', 'fail', 'invalid', 'wrong'],
        'success': ['success', 'complete', 'done', 'confirmed'],
        'loading': ['loading', 'progress', 'spinner', 'wait'],
        'empty': ['empty', 'no data', 'no results', 'blank'],
        'disabled': ['disabled', 'inactive', 'locked'],
    }

    for state, keywords in state_keywords.items():
        if any(kw in name_lower for kw in keywords):
            return state

    return 'default'
```
