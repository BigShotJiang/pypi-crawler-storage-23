# carrier - calculate_thresholds

**Toolkit**: `carrier`
**Method**: `calculate_thresholds`
**Source File**: `utils.py`

---

## Method Implementation

```python
def calculate_thresholds(results, report_percentile, thresholds):
    """

    :param results:
    :param report_percentile:
    :param thresholds:
    :return:
    """
    data = []
    tp_threshold = thresholds['tp_threshold']
    rt_threshold = thresholds['rt_threshold']
    er_threshold = thresholds['er_threshold']

    if results['throughput'] < tp_threshold:
        data.append({"target": "throughput", "scope": "all", "value": results['throughput'],
                    "threshold": tp_threshold, "status": "FAILED", "metric": "req/s"})
    else:
        data.append({"target": "throughput", "scope": "all", "value": results['throughput'],
                    "threshold": tp_threshold, "status": "PASSED", "metric": "req/s"})

    if results['error_rate'] > er_threshold:
        data.append({"target": "error_rate", "scope": "all", "value": results['error_rate'],
                    "threshold": er_threshold, "status": "FAILED", "metric": "%"})
    else:
        data.append({"target": "error_rate", "scope": "all", "value": results['error_rate'],
                    "threshold": er_threshold, "status": "PASSED", "metric": "%"})

    for req in results['requests']:
        if float(results['requests'][req][report_percentile]) > rt_threshold:
            data.append({"target": "response_time", "scope": results['requests'][req],
                        "value": results['requests'][req][report_percentile],
                        "threshold": rt_threshold, "status": "FAILED", "metric": "ms"})
        else:
            data.append({"target": "response_time", "scope": results['requests'][req]['request_name'],
                        "value": results['requests'][req][report_percentile],
                        "threshold": rt_threshold, "status": "PASSED", "metric": "ms"})
    return data
```
