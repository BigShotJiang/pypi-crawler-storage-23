# aws - get_available_tools

**Toolkit**: `aws`
**Method**: `get_available_tools`
**Source File**: `__init__.py`

---

## Method Implementation

```python
def get_available_tools() -> dict[str, dict]:
    api_wrapper = DeltaLakeApiWrapper.model_construct()
    available_tools: dict = {
        x["name"]: x["args_schema"].model_json_schema()
        for x in api_wrapper.get_available_tools()
    }
    return available_tools
```
