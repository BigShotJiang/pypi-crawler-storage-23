# aws - get_table_schema

**Toolkit**: `aws`
**Method**: `get_table_schema`
**Source File**: `api_wrapper.py`
**Class**: `DeltaLakeApiWrapper`

---

## Method Implementation

```python
    def get_table_schema(self) -> str:
        dt = self.delta_table
        return dt.schema().to_pyarrow().to_string()
```
