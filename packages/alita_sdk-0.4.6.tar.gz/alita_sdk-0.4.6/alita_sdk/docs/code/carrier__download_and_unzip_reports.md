# carrier - download_and_unzip_reports

**Toolkit**: `carrier`
**Method**: `download_and_unzip_reports`
**Source File**: `carrier_sdk.py`
**Class**: `CarrierClient`

---

## Method Implementation

```python
    def download_and_unzip_reports(self, file_name: str, bucket: str, extract_to: str = "/tmp") -> str:
        endpoint = f"api/v1/artifacts/artifact/{self.credentials.project_id}/{bucket}/{file_name}"
        response = self.session.get(f"{self.credentials.url}/{endpoint}")
        local_file_path = f"{extract_to}/{file_name}"
        with open(local_file_path, 'wb') as f:
            f.write(response.content)

        extract_dir = f"{local_file_path.replace('.zip', '')}"
        try:
            shutil.rmtree(extract_dir)
        except Exception as e:
            print(e)
        import zipfile
        with zipfile.ZipFile(local_file_path, 'r') as zip_ref:
            zip_ref.extractall(extract_dir)
        import os
        if os.path.exists(local_file_path):
            os.remove(local_file_path)

        return extract_dir
```
