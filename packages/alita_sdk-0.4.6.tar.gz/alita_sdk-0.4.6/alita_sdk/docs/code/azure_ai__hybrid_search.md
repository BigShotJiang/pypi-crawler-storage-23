# azure_ai - hybrid_search

**Toolkit**: `azure_ai`
**Method**: `hybrid_search`
**Source File**: `api_wrapper.py`
**Class**: `AzureSearchApiWrapper`

---

## Method Implementation

```python
    def hybrid_search(self, search_text: str, vectors: List[Dict[str, Any]], limit: Optional[int] = None) -> List[Dict[str, Any]]:
        """
        Perform a hybrid search query on the Azure Search index.

        :param search_text: The text to search for in the Azure Search index.
        :param vectors: The vectors to search for in the Azure Search index.
        :param limit: The number of results to return.
        :return: A list of search results.
        """
        results = self._client.search(search_text=search_text, vector_queries=vectors)
        res = list(results)
        if limit is None or limit == -1:
            return res
        else:
            return res[:limit]
```
