# carrier - calculate_duration

**Toolkit**: `carrier`
**Method**: `calculate_duration`
**Source File**: `excel_reporter.py`
**Class**: `GatlingReportParser`

---

## Method Implementation

```python
    def calculate_duration(date_start: datetime, date_end: datetime) -> float:
        """
        Calculate the total duration between the first and last timestamp in the logs.
        """
        if not all([date_start, date_end]):
            return 0.0
        test_dur = round((date_end - date_start).total_seconds() / 60, 3)
        print(f"Test duration, min: {test_dur}")
        return test_dur
```
