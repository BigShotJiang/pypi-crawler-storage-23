# ado_work_item - get_tools

**Toolkit**: `ado_work_item`
**Method**: `get_tools`
**Source File**: `__init__.py`
**Class**: `AzureDevOpsWorkItemsToolkit`

---

## Method Implementation

```python
    def get_tools(self):
        return self.tools
```
