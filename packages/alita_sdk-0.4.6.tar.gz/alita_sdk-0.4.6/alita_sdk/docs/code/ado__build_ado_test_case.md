# ado - build_ado_test_case

**Toolkit**: `ado`
**Method**: `build_ado_test_case`
**Source File**: `test_plan_wrapper.py`
**Class**: `TestPlanApiWrapper`

---

## Method Implementation

```python
    def build_ado_test_case(self, title, description, steps_xml, additional_fields: Optional[Dict] = None):
        """
        Build Test Case work item JSON with standard and custom fields.

        :param title: test title
        :param description: test description
        :param steps_xml: steps xml
        :param additional_fields: optional dictionary of additional custom fields
        :return: JSON with ADO fields
        """
        # Standard required fields for Test Case
        standard_fields = {
            "System.Title": title,
            "System.Description": description,
            "Microsoft.VSTS.TCM.Steps": steps_xml
        }

        # Merge additional fields if provided
        if additional_fields:
            # Ensure additional fields don't override standard fields
            protected_fields = ["System.Title", "System.Description", "Microsoft.VSTS.TCM.Steps"]
            for field_name, field_value in additional_fields.items():
                if field_name in protected_fields:
                    logger.warning(f"Ignoring attempt to override protected field: {field_name}")
                else:
                    standard_fields[field_name] = field_value

        return {
            "fields": standard_fields
        }
```
