# figma - detect_sequences

**Toolkit**: `figma`
**Method**: `detect_sequences`
**Source File**: `toon_tools.py`

---

## Method Implementation

```python
def detect_sequences(frames: List[Dict]) -> List[Tuple[str, ...]]:
    """
    Detect sequential flows from frame naming.

    Returns list of sequences: [("01_Login", "02_Verify", "03_Dashboard"), ...]
    """
    # Extract frames with sequence numbers
    sequenced = []
    for frame in frames:
        name = frame.get('name', '')
        seq_info = extract_sequence_number(name)
        if seq_info:
            sequenced.append((seq_info[0], name, frame))

    if not sequenced:
        return []

    # Sort by sequence number
    sequenced.sort(key=lambda x: x[0])

    # Build sequence
    sequence = tuple(item[1] for item in sequenced)
    return [sequence] if len(sequence) > 1 else []
```

## Helper Methods

```python
Helper: extract_sequence_number
def extract_sequence_number(name: str) -> Optional[Tuple[int, str]]:
    """
    Extract sequence number from frame name.

    Patterns detected:
      - "01_Login" -> (1, "Login")
      - "Step 1 - Login" -> (1, "Login")
      - "1. Login" -> (1, "Login")
      - "Login (1)" -> (1, "Login")
      - "Screen_001" -> (1, "Screen")

    Returns (sequence_number, base_name) or None if no pattern found.
    """
    patterns = [
        # "01_Login", "001_Login"
        (r'^(\d{1,3})[-_\s]+(.+)$', lambda m: (int(m.group(1)), m.group(2).strip())),
        # "Step 1 - Login", "Step1: Login"
        (r'^step\s*(\d+)\s*[-:_]?\s*(.*)$', lambda m: (int(m.group(1)), m.group(2).strip() or f"Step {m.group(1)}")),
        # "1. Login", "1) Login"
        (r'^(\d+)\s*[.\)]\s*(.+)$', lambda m: (int(m.group(1)), m.group(2).strip())),
        # "Login (1)", "Login [1]"
        (r'^(.+?)\s*[\(\[](\d+)[\)\]]$', lambda m: (int(m.group(2)), m.group(1).strip())),
        # "Screen_001", "Page001"
        (r'^([a-zA-Z]+)[-_]?(\d{2,3})$', lambda m: (int(m.group(2)), m.group(1).strip())),
    ]

    for pattern, extractor in patterns:
        match = re.match(pattern, name, re.IGNORECASE)
        if match:
            return extractor(match)
    return None
```
