# custom_open_api - get_open_api_spec

**Toolkit**: `custom_open_api`
**Method**: `get_open_api_spec`
**Source File**: `api_wrapper.py`
**Class**: `OpenApiWrapper`

---

## Method Implementation

```python
    def get_open_api_spec(self) -> str:
        """
        Retrieves the OpenAPI (Swagger) specification for a given API endpoint. This tool helps in obtaining the necessary information to interact with an API using the "Invoke External API" tool.
        """
        return self.spec
```
