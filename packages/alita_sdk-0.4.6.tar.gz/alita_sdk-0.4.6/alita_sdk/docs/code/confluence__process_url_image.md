# confluence - process_url_image

**Toolkit**: `confluence`
**Method**: `process_url_image`
**Source File**: `api_wrapper.py`
**Class**: `ConfluenceAPIWrapper`

---

## Method Implementation

```python
            def process_url_image(match):
                """Process URL-based image references and get contextual descriptions"""
                image_url = match.group(1)
                full_match = match.group(0)  # The complete image reference

                logger.info(f"Processing URL image reference: {image_url}")

                try:
                    # Extract image name from URL for better reference
                    image_name = image_url.split('/')[-1]

                    # Download the image
                    logger.info(f"Downloading image from URL: {image_url}")
                    image_data = self._download_image(image_url)

                    if not image_data:
                        logger.error(f"Failed to download image from URL: {image_url}")
                        return f"[Image: {image_name} - download failed]"

                    # Collect surrounding context
                    context_text = self._collect_context_for_image(page_content, full_match, context_radius)

                    # Process with LLM (will use cache if available)
                    description = self._process_image_with_llm(image_data, image_name, context_text, prompt)
                    return f"[Image {image_name} Description: {description}]"

                except Exception as e:
                    logger.error(f"Error processing URL image {image_url}: {str(e)}")
                    return f"[Image: {image_url} - Error: {str(e)}]"
```
