# aws - wrapper

**Toolkit**: `aws`
**Method**: `wrapper`
**Source File**: `api_wrapper.py`

---

## Method Implementation

```python
    def wrapper(self, *args, **kwargs):
        try:
            result = func(self, *args, **kwargs)
            if isinstance(result, Exception):
                return ToolException(str(result))
            if isinstance(result, (dict, list)):
                return json.dumps(result, default=str)
            return str(result)
        except Exception as e:
            logging.error(f"Error in '{func.__name__}': {str(e)}")
            return ToolException(str(e))
```
