# ado - safe_decode

**Toolkit**: `ado`
**Method**: `safe_decode`
**Source File**: `utils.py`

---

## Method Implementation

```python
    def safe_decode(chunk):
        try:
            return chunk.decode("utf-8")
        except UnicodeDecodeError:
            return chunk.decode("ascii", errors="backslashreplace")
```
