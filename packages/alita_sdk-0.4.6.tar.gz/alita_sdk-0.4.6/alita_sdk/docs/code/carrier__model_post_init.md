# carrier - model_post_init

**Toolkit**: `carrier`
**Method**: `model_post_init`
**Source File**: `carrier_sdk.py`
**Class**: `CarrierClient`

---

## Method Implementation

```python
    def model_post_init(self, __context):
        headers = {
            'Authorization': f'Bearer {self.credentials.token}',
            'Content-Type': 'application/json',
            'X-Organization': self.credentials.organization
        }
        self.session.headers.update(headers)
```
