# aws - get_toolkit

**Toolkit**: `aws`
**Method**: `get_toolkit`
**Source File**: `__init__.py`
**Class**: `DeltaLakeToolkit`

---

## Method Implementation

```python
    def get_toolkit(
        cls,
        selected_tools: list[str] | None = None,
        toolkit_name: Optional[str] = None,
        **kwargs,
    ) -> "DeltaLakeToolkit":
        delta_lake_api_wrapper = DeltaLakeApiWrapper(**kwargs)
        instance = cls(
            tools=[], api_wrapper=delta_lake_api_wrapper, toolkit_name=toolkit_name
        )
        if selected_tools:
            selected_tools = set(selected_tools)
            for t in instance.available_tools:
                if t["name"] in selected_tools:
                    description = t["description"]
                    if toolkit_name:
                        description = f"Toolkit: {toolkit_name}\n{description}"
                    description = f"S3 Path: {getattr(instance.api_wrapper, 's3_path', '')} Table Path: {getattr(instance.api_wrapper, 'table_path', '')}\n{description}"
                    description = description[:1000]
                    instance.tools.append(
                        DeltaLakeAction(
                            api_wrapper=instance.api_wrapper,
                            name=t["name"],
                            description=description,
                            args_schema=t["args_schema"],
                            metadata={TOOLKIT_NAME_META: toolkit_name, TOOLKIT_TYPE_META: name, TOOL_NAME_META: t["name"]} if toolkit_name else {TOOL_NAME_META: t["name"]}
                        )
                    )
        return instance
```
