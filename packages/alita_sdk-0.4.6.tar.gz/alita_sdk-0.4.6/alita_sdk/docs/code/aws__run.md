# aws - run

**Toolkit**: `aws`
**Method**: `run`
**Source File**: `api_wrapper.py`
**Class**: `DeltaLakeApiWrapper`

---

## Method Implementation

```python
    def run(self, name: str, *args: Any, **kwargs: Any):
        for tool in self.get_available_tools():
            if tool["name"] == name:
                if len(args) == 1 and isinstance(args[0], dict) and not kwargs:
                    kwargs = args[0]
                    args = ()
                try:
                    return tool["ref"](*args, **kwargs)
                except TypeError as e:
                    if kwargs and not args:
                        try:
                            return tool["ref"](**kwargs)
                        except TypeError:
                            raise ValueError(
                                f"Argument mismatch for tool '{name}'. Error: {e}"
                            ) from e
                    else:
                        raise ValueError(
                            f"Argument mismatch for tool '{name}'. Error: {e}"
                        ) from e
        else:
            raise ValueError(f"Unknown tool name: {name}")
```

## Helper Methods

```python
Helper: get_available_tools
    def get_available_tools(self) -> List[dict]:
        return [
            {
                "name": "query_table",
                "description": self.query_table.__doc__,
                "args_schema": ArgsSchema.QueryTableArgs.value,
                "ref": self.query_table,
            },
            {
                "name": "vector_search",
                "description": self.vector_search.__doc__,
                "args_schema": ArgsSchema.VectorSearchArgs.value,
                "ref": self.vector_search,
            },
            {
                "name": "get_table_schema",
                "description": self.get_table_schema.__doc__,
                "args_schema": ArgsSchema.NoInput.value,
                "ref": self.get_table_schema,
            },
        ]
```
