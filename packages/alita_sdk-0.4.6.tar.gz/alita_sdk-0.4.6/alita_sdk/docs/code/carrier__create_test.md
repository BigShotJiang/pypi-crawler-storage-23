# carrier - create_test

**Toolkit**: `carrier`
**Method**: `create_test`
**Source File**: `carrier_sdk.py`
**Class**: `CarrierClient`

---

## Method Implementation

```python
    def create_test(self, data):
        endpoint = f"api/v1/backend_performance/tests/{self.credentials.project_id}"
        full_url = f"{self.credentials.url.rstrip('/')}/{endpoint.lstrip('/')}"
        headers = {'Authorization': f'bearer {self.credentials.token}'}
        from json import dumps
        # Serialize the `data` dictionary into a JSON string
        form_data = {"data": dumps(data)}
        # Send the POST request
        res = requests.post(full_url, headers=headers, data=form_data)
        return res
```
