# ado - branch_exists

**Toolkit**: `ado`
**Method**: `branch_exists`
**Source File**: `repos_wrapper.py`
**Class**: `ReposApiWrapper`

---

## Method Implementation

```python
            def branch_exists(branch_name):
                try:
                    branch = ado_client.get_branch(
                        repository_id=repository_id, name=branch_name, project=project
                    )
                    return branch is not None
                except Exception:
                    return False
```
