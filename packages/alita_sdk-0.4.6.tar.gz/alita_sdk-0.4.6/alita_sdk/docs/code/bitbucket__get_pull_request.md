# bitbucket - get_pull_request

**Toolkit**: `bitbucket`
**Method**: `get_pull_request`
**Source File**: `cloud_api_wrapper.py`
**Class**: `BitbucketCloudApi`

---

## Method Implementation

```python
    def get_pull_request(self, pr_id: str) -> Dict[str, Any]:
        """ Get details of a pull request
        Parameters:
            pr_id(str): the pull request ID
        Returns:
            Dict[str, Any]: Details of the pull request
        """
        response = self.repository.pullrequests.get(pr_id)
        return normalize_response(response)
```

## Helper Methods

```python
Helper: normalize_response
def normalize_response(response) -> Dict[str, Any]:
    """
    Normalize API response to dictionary format.
    Handles different response types from Bitbucket APIs.
    """
    if isinstance(response, dict):
        return response
    if hasattr(response, 'to_dict'):
        return response.to_dict()
    if hasattr(response, '__dict__'):
        return {k: v for k, v in response.__dict__.items()
                if isinstance(v, (str, int, float, bool, list, dict, type(None)))}
    return {"raw_response": str(response)}
```
