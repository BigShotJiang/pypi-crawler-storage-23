# advanced_jira_mining - get_tools

**Toolkit**: `advanced_jira_mining`
**Method**: `get_tools`
**Source File**: `__init__.py`
**Class**: `AdvancedJiraMiningToolkit`

---

## Method Implementation

```python
    def get_tools(self):
        return self.tools
```
