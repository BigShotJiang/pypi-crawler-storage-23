# ado_work_item - delete_work_item

**Toolkit**: `ado_work_item`
**Method**: `delete_work_item`
**Source File**: `ado_wrapper.py`
**Class**: `AzureDevOpsApiWrapper`

---

## Method Implementation

```python
    def delete_work_item(self, id: int):
        """Delete a work item from Azure DevOps by ID."""
        try:
            self._client.delete_work_item(id=id, project=self.project)
            return f"Work item {id} was successfully deleted."
        except Exception as e:
            logger.error(f"Error deleting work item {id}: {e}")
            return ToolException(f"Error deleting work item {id}: {e}")
```
