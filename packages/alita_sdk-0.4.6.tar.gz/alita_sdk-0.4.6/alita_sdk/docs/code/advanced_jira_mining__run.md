# advanced_jira_mining - run

**Toolkit**: `advanced_jira_mining`
**Method**: `run`
**Source File**: `data_mining_wrapper.py`
**Class**: `AdvancedJiraMiningWrapper`

---

## Method Implementation

```python
    def run(self, mode: str, *args: Any, **kwargs: Any):
        for tool in self.get_available_tools():
            if tool["name"] == mode:
                return tool["ref"](*args, **kwargs)
        else:
            raise ValueError(f"Unknown mode: {mode}")
```

## Helper Methods

```python
Helper: get_available_tools
    def get_available_tools(self):
        return [
            {
                "name": "prepare_data",
                "description": self.prepare_data.__doc__,
                "args_schema": PrepareDataSchema,
                "ref": self.prepare_data,
            },
            {
                "name": "search_data",
                "description": self.search_data.__doc__,
                "args_schema": SearchDataSchema,
                "ref": self.search_data,
            },
            {
                "name": "gaps_analysis",
                "description": self.gaps_analysis.__doc__,
                "args_schema": SearchDataSchema,
                "ref": self.gaps_analysis,
            }

        ]
```
