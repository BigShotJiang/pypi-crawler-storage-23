# figma - extract_inputs

**Toolkit**: `figma`
**Method**: `extract_inputs`
**Source File**: `toon_tools.py`

---

## Method Implementation

```python
def extract_inputs(node: Dict, depth: int = 0, max_depth: int = 12) -> List[Dict[str, Any]]:
    """
    Recursively extract input fields with their labels, types, and options.

    Enhanced to detect:
    - Modal form fields with label+control patterns
    - Sliders with labels (Creativity, Reasoning, etc.)
    - Selectors with current values
    - Display fields (read-only info)
    - Radio/segment controls with options

    Returns list of dicts:
        [{'name': 'Email', 'type': 'email', 'required': True, 'placeholder': '...', 'options': [], 'value': '...'}, ...]
    """
    if depth > max_depth:
        return []

    inputs = []
    node_type = node.get('type', '').upper()
    node_name = node.get('name', '')
    node_name_lower = node_name.lower()
    children = node.get('children', [])

    # Check if this node is a form container (modal, settings panel, etc.)
    is_form_container = any(kw in node_name_lower for kw in MODAL_FORM_KEYWORDS)

    # Strategy 1: Check if this is a direct input component/instance
    is_input = False
    input_type = 'text'

    if node_type in ['COMPONENT', 'INSTANCE', 'COMPONENT_SET', 'FRAME']:
        is_input, input_type = _infer_input_type(node_name, len(children))

    if is_input:
        # Extract all text from this input node
        all_texts = _extract_all_text_from_node(node, max_depth=6)

        label = ''
        placeholder = ''
        value = ''
        options = []
        required = False

        # Check node name for required indicator
        for indicator in REQUIRED_INDICATORS:
            if indicator in node_name_lower:
                required = True
                break

        # Process extracted texts with improved categorization
        for t in all_texts:
            text = t['text']

            # Check for required indicators
            if '*' in text:
                required = True
                text = text.replace('*', '').strip()

            # Skip very short text (but allow numbers)
            if len(text) < 2:
                continue

            # Categorize text more carefully
            if t.get('is_placeholder') or (t.get('is_gray') and not t.get('is_value')):
                if not placeholder:
                    placeholder = text
            elif t.get('is_label') or (t.get('font_size', 14) <= 12 and not t.get('is_value')):
                if not label:
                    label = text
            elif t.get('is_value') or t.get('is_option'):
                # Value or option
                if input_type in ['select', 'radio', 'slider']:
                    options.append(text)
                else:
                    if not value:
                        value = text
            else:
                # Guess based on context and length
                if not label and len(text) < 40:
                    label = text
                elif input_type in ['select', 'radio', 'slider'] and len(text) < 25:
                    options.append(text)
                elif not value:
                    value = text

        # Try to get label from node name if not found
        if not label:
            label = _clean_input_label(node_name)

        # Skip if label is empty or generic
        if not label or label.lower() in ['input', 'field', '', 'text', 'frame']:
            label = _clean_input_label(node_name) or 'Input'

        # Only add if we have a meaningful label
        if label and label.lower() not in ['', 'input', 'field', 'frame', 'instance', 'component']:
            input_data = {
                'name': label,
                'type': input_type,
                'required': required,
                'placeholder': placeholder,
            }
            # Add value if present
            if value:
                input_data['value'] = value
            # Add options for select/radio/slider types
            if options and input_type in ['select', 'radio', 'slider']:
                input_data['options'] = list(dict.fromkeys(options))[:6]  # Dedupe, limit to 6

            inputs.append(input_data)
        # Don't recurse into detected input nodes
        return inputs

    # Strategy 2: For form containers, try to detect label+control patterns
    if is_form_container or node_type == 'FRAME':
        for child in children:
            field = _detect_form_field_in_subtree(child, depth=0, max_depth=4)
            if field:
                input_data = {
                    'name': field['name'],
                    'type': field['type'],
                    'required': False,
                    'placeholder': '',
                }
                if field.get('value'):
                    input_data['value'] = field['value']
                if field.get('options'):
                    input_data['options'] = field['options']
                inputs.append(input_data)

    # Recurse into children
    for child in children:
        inputs.extend(extract_inputs(child, depth + 1, max_depth))

    # Deduplicate by name (keep first occurrence)
    seen_names = set()
    deduped = []
    for inp in inputs:
        name_key = inp['name'].lower()
        if name_key not in seen_names:
            seen_names.add(name_key)
            deduped.append(inp)

    return deduped
```
