# ado - list_branches_in_repo

**Toolkit**: `ado`
**Method**: `list_branches_in_repo`
**Source File**: `repos_wrapper.py`
**Class**: `ReposApiWrapper`

---

## Method Implementation

```python
    def list_branches_in_repo(self) -> str:
        """
        Fetches a list of all branches in the repository.

        Returns:
            str: A plaintext report containing the names of the branches.
        """
        try:
            branches = [
                branch.name
                for branch in self._client.get_branches(
                    repository_id=self.repository_id, project=self.project
                )
            ]
            if branches:
                branches_str = "\n".join(branches)
                return (
                    f"Found {len(branches)} branches in the repository:"
                    f"\n{branches_str}"
                )
            else:
                return "No branches found in the repository"
        except Exception as e:
            msg = f"Error during attempt to fetch the list of branches: {str(e)}"
            logger.error(msg)
            return ToolException(msg)
```
