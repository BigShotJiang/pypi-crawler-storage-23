# ado - get_test_suite

**Toolkit**: `ado`
**Method**: `get_test_suite`
**Source File**: `test_plan_wrapper.py`
**Class**: `TestPlanApiWrapper`

---

## Method Implementation

```python
    def get_test_suite(self, plan_id: int, suite_id: Optional[int] = None):
        """Get a test suite or list of test suites in Azure DevOps."""
        try:
            if suite_id:
                test_suite = self._client.get_test_suite_by_id(self.project, plan_id, suite_id)
                return test_suite.as_dict()
            else:
                test_suites = self._client.get_test_suites_for_plan(self.project, plan_id)
                return [suite.as_dict() for suite in test_suites]
        except Exception as e:
            logger.error(f"Error getting test suite(s): {e}")
            return ToolException(f"Error getting test suite(s): {e}")
```
