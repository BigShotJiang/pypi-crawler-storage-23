# figma - analyze_flows_with_llm

**Toolkit**: `figma`
**Method**: `analyze_flows_with_llm`
**Source File**: `toon_tools.py`

---

## Method Implementation

```python
def analyze_flows_with_llm(
    frames: List[Dict],
    llm: Any,
) -> Optional[FlowAnalysis]:
    """
    Analyze user flows using LLM with structured output.

    Args:
        frames: List of processed frame data dicts
        llm: LangChain LLM instance with structured output support

    Returns:
        FlowAnalysis model or None if analysis fails
    """
    if not llm or not frames:
        return None

    try:
        # Build compact frame summary for LLM
        frame_lines = []
        for f in frames[:20]:  # Limit to 20 frames
            name = f.get('name', 'Unknown')
            buttons = f.get('buttons', [])[:3]  # Top 3 buttons
            btn_str = ', '.join(buttons) if buttons else '-'
            frame_lines.append(f"- {name}: [{btn_str}]")

        frame_summary = '\n'.join(frame_lines)

        # Build prompt
        prompt = FLOW_ANALYSIS_PROMPT.format(frame_summary=frame_summary)

        # Call LLM with structured output
        structured_llm = llm.with_structured_output(FlowAnalysis)
        result = structured_llm.invoke(prompt)

        return result

    except Exception as e:
        logging.warning(f"LLM flow analysis failed: {e}")
        return None
```
