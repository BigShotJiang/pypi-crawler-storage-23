# azure_ai - text_search

**Toolkit**: `azure_ai`
**Method**: `text_search`
**Source File**: `api_wrapper.py`
**Class**: `AzureSearchApiWrapper`

---

## Method Implementation

```python
    def text_search(self, search_text: str, limit: Optional[int] = -1, order_by: Optional[List[str]] = None, selected_fields: Optional[list] = []) -> List[Dict]:
        """
        Perform a search query on the Azure Search index.

        :param search_text: The text to search for in the Azure Search index.
        :param limit: The number of results to return (if no limit needed use -1)
        :param order_by: Ordering expression for the search results (if no order needed use empty list).
        :param selected_fields: The fields to retrieve from the document (if no fields needed use empty list).
        :return: A list of search results.
        """
        if limit == -1:
            limit = None
        if selected_fields and len(selected_fields) == 0:
            selected_fields = None
        if order_by and len(order_by) == 0:
            order_by = None
        results = self._client.search(search_text=search_text, top=limit, order_by=order_by, select=selected_fields)
        return list(results)
```
