# ado - delete_file

**Toolkit**: `ado`
**Method**: `delete_file`
**Source File**: `repos_wrapper.py`
**Class**: `ReposApiWrapper`

---

## Method Implementation

```python
    def delete_file(self, branch_name: str, file_path: str) -> str:
        """
        Deletes a file from the repository in Azure DevOps.

        Parameters:
            branch_name (str): The name of the branch where the file will be deleted.
            file_path (str): The path of the file to delete.

        Returns:
            str: Success or failure message.
        """
        try:
            branch = self._client.get_branch(
                repository_id=self.repository_id, project=self.project, name=branch_name
            )
            if not branch:
                return "Branch not found."

            current_commit_id = branch.commit.commit_id

            change = GitChange("delete", file_path).to_dict()

            new_commit = GitCommitRef(comment="Delete " + file_path, changes=[change])
            ref_update = GitRefUpdate(
                name="refs/heads/" + branch_name,
                old_object_id=current_commit_id,
                new_object_id=None,
            )
            push = GitPush(commits=[new_commit], ref_updates=[ref_update])
            self._client.create_push(
                push=push, repository_id=self.repository_id, project=self.project
            )
            return "Deleted file " + file_path
        except Exception as e:
            msg = f"Unable to delete file due to error:\n{str(e)}"
            logger.error(msg)
            return ToolException(msg)
```
