# figma - serialize_design_analysis

**Toolkit**: `figma`
**Method**: `serialize_design_analysis`
**Source File**: `toon_tools.py`

---

## Method Implementation

```python
def serialize_design_analysis(
    analysis: DesignAnalysis,
    indent: str = TOON_INDENT,
) -> str:
    """
    Serialize a complete DesignAnalysis to readable format.

    Returns formatted string.
    """
    lines = []

    lines.append(f"DESIGN ANALYSIS: {analysis.file_name}")
    lines.append(f"{indent}Type: {analysis.design_type}")
    lines.append(f"{indent}Target User: {analysis.target_user}")
    lines.append(f"{indent}Purpose: {analysis.overall_purpose}")

    if analysis.design_patterns:
        lines.append(f"{indent}Patterns: {', '.join(analysis.design_patterns)}")

    # Flows
    if analysis.flows:
        lines.append(f"{indent}USER FLOWS:")
        for flow in analysis.flows:
            lines.append(f"{indent}{indent}{flow.flow_name}: {flow.entry_point} > ... > {flow.exit_point}")
            lines.append(f"{indent}{indent}{indent}{flow.description}")
            if flow.error_states:
                lines.append(f"{indent}{indent}{indent}Error states: {', '.join(flow.error_states)}")

    # Screens
    if analysis.screens:
        lines.append(f"{indent}SCREENS ({len(analysis.screens)}):")
        for screen in analysis.screens:
            lines.append(f"{indent}{indent}{screen.frame_name}: {screen.purpose}")
            if screen.primary_action:
                lines.append(f"{indent}{indent}{indent}Primary: {screen.primary_action}")

    # Concerns
    if analysis.gaps_or_concerns:
        lines.append(f"{indent}GAPS/CONCERNS:")
        for concern in analysis.gaps_or_concerns:
            lines.append(f"{indent}{indent}- {concern}")

    # Accessibility
    if analysis.accessibility_notes:
        lines.append(f"{indent}ACCESSIBILITY:")
        for note in analysis.accessibility_notes:
            lines.append(f"{indent}{indent}- {note}")

    return '\n'.join(lines)
```
