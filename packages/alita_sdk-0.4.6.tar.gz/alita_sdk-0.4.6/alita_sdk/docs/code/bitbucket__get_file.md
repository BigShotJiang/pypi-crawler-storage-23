# bitbucket - get_file

**Toolkit**: `bitbucket`
**Method**: `get_file`
**Source File**: `cloud_api_wrapper.py`
**Class**: `BitbucketCloudApi`

---

## Method Implementation

```python
    def get_file(self, file_path: str, branch: str) -> str:
        """Fetch a file's content from Bitbucket Cloud and return it as text.

        Uses the 'get' endpoint with advanced_mode to get a rich response object.
        Branch names with slashes are URL-encoded to ensure proper API requests.
        """
        try:
            # URL-encode branch name to handle special characters like forward slashes
            branch_hash = self._get_branch(branch).hash

            file_response = self.repository.get(
                path=f"src/{branch_hash}/{file_path}",
                advanced_mode=True,
            )

            # Prefer HTTP status when available
            status = getattr(file_response, "status_code", None)
            if status is not None and status != 200:
                raise ToolException(
                    f"Failed to retrieve text from file '{file_path}' from branch '{branch}': "
                    f"HTTP {status}"
                )

            # Safely extract text content
            file_text = getattr(file_response, "text", None)
            if not isinstance(file_text, str) or not file_text:
                raise ToolException(
                    f"File '{file_path}' from branch '{branch}' is empty or could not be retrieved."
                )

            return file_text
        except Exception as e:
            # Network/transport or client-level failure
            raise ToolException(
                f"Failed to retrieve text from file '{file_path}' from branch '{branch}': {e}"
            )
```
