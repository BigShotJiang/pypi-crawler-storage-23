# ado - get_test_steps_xml

**Toolkit**: `ado`
**Method**: `get_test_steps_xml`
**Source File**: `test_plan_wrapper.py`
**Class**: `TestPlanApiWrapper`

---

## Method Implementation

```python
    def get_test_steps_xml(self, steps: dict):
        steps_elem = ET.Element("steps")
        for step in steps:
            step_number = step.get("stepNumber", 1)
            action = step.get("action", "")
            expected_result = step.get("expectedResult", "")
            steps_elem.append(self.build_step_element(step_number, action, expected_result))
        return ET.tostring(steps_elem, encoding="unicode")
```

## Helper Methods

```python
Helper: build_step_element
    def build_step_element(self, step_number: str, action: str, expected_result: str) -> ET.Element:
        """
            Creates an individual <step> element for Azure DevOps.
            """
        step_elem = ET.Element("step", id=str(step_number), type="Action")
        action_elem = ET.SubElement(step_elem, "parameterizedString", isformatted="true")
        action_elem.text = action or ""
        expected_elem = ET.SubElement(step_elem, "parameterizedString", isformatted="true")
        expected_elem.text = expected_result or ""
        return step_elem
```
