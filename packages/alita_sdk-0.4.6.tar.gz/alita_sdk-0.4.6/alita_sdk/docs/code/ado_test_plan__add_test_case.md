# ado_test_plan - add_test_case

**Toolkit**: `ado_test_plan`
**Method**: `add_test_case`
**Source File**: `test_plan_wrapper.py`
**Class**: `TestPlanApiWrapper`

---

## Method Implementation

```python
    def add_test_case(self, suite_test_case_create_update_parameters, plan_id: int, suite_id: int):
        """Add a test case to a suite in Azure DevOps."""
        try:
            if isinstance(suite_test_case_create_update_parameters, str):
                suite_test_case_create_update_parameters = json.loads(suite_test_case_create_update_parameters)
            suite_test_case_create_update_params_obj = [SuiteTestCaseCreateUpdateParameters(**param) for param in
                                                        suite_test_case_create_update_parameters]
            test_cases = self._client.add_test_cases_to_suite(suite_test_case_create_update_params_obj, self.project,
                                                              plan_id, suite_id)
            return [test_case.as_dict() for test_case in test_cases]
        except Exception as e:
            logger.error(f"Error adding test case: {e}")
            return ToolException(f"Error adding test case: {e}")
```
