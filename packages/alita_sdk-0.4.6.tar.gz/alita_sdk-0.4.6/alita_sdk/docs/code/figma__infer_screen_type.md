# figma - infer_screen_type

**Toolkit**: `figma`
**Method**: `infer_screen_type`
**Source File**: `toon_tools.py`

---

## Method Implementation

```python
def infer_screen_type(frame_data: Dict) -> str:
    """
    Infer screen type from content.

    Returns: form, list, detail, dashboard, modal, menu, settings, chat, etc.
    """
    name_lower = frame_data.get('name', '').lower()
    components = frame_data.get('components', [])
    buttons = frame_data.get('buttons', [])
    labels = frame_data.get('labels', [])

    components_lower = [c.lower() for c in components]
    buttons_lower = [b.lower() for b in buttons]

    # Check name hints
    type_hints = {
        'form': ['login', 'signup', 'register', 'checkout', 'payment', 'form', 'input'],
        'list': ['list', 'feed', 'timeline', 'results', 'search results'],
        'detail': ['detail', 'profile', 'item', 'product', 'article'],
        'dashboard': ['dashboard', 'home', 'overview', 'summary'],
        'modal': ['modal', 'dialog', 'popup', 'overlay', 'alert'],
        'menu': ['menu', 'navigation', 'sidebar', 'drawer'],
        'settings': ['settings', 'preferences', 'config', 'options'],
        'chat': ['chat', 'message', 'conversation', 'inbox'],
        'onboarding': ['onboarding', 'welcome', 'intro', 'tutorial'],
    }

    for screen_type, keywords in type_hints.items():
        if any(kw in name_lower for kw in keywords):
            return screen_type

    # Check components
    if any('input' in c or 'textfield' in c or 'form' in c for c in components_lower):
        return 'form'
    if any('card' in c or 'listitem' in c for c in components_lower):
        return 'list'
    if any('modal' in c or 'dialog' in c for c in components_lower):
        return 'modal'

    # Check buttons for form indicators
    form_buttons = ['submit', 'save', 'sign in', 'log in', 'register', 'next', 'continue']
    if any(any(fb in b for fb in form_buttons) for b in buttons_lower):
        return 'form'

    return 'screen'  # Generic fallback
```
