# figma - dedupe_and_clean_text

**Toolkit**: `figma`
**Method**: `dedupe_and_clean_text`
**Source File**: `toon_tools.py`

---

## Method Implementation

```python
def dedupe_and_clean_text(text_list: List[str], max_items: int = 10) -> List[str]:
    """
    Deduplicate and clean a list of text items.

    - Removes duplicates (case-insensitive)
    - Strips whitespace
    - Limits to max_items
    - Preserves order (first occurrence)
    """
    seen = set()
    result = []
    for text in text_list:
        clean = text.strip()
        if clean and clean.lower() not in seen:
            seen.add(clean.lower())
            result.append(clean)
            if len(result) >= max_items:
                break
    return result
```
