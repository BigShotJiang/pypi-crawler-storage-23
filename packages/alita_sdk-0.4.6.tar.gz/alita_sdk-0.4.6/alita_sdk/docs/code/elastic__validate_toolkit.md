# elastic - validate_toolkit

**Toolkit**: `elastic`
**Method**: `validate_toolkit`
**Source File**: `api_wrapper.py`
**Class**: `ELITEAElasticApiWrapper`

---

## Method Implementation

```python
    def validate_toolkit(cls, values):
        if Elasticsearch is None:
            raise ImportError(
                "'elasticsearch' package is not installed. Please install it using `pip install elasticsearch`."
            )
        url = values['url']
        api_key = values.get('api_key')
        if api_key:
            cls._client = Elasticsearch(url, api_key=api_key, verify_certs=False, ssl_show_warn=False)
        else:
            cls._client = Elasticsearch(url, verify_certs=False, ssl_show_warn=False)
        return values
```
