from terminal_demo_studio.cli import main

if __name__ == "__main__":
    main()
