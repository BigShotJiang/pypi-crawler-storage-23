# dotai 🔐

**dotai** is a project secret management tool designed to simplify Developer Experience (DevX). Aims to bridge the gap between secure vault backends and the diverse consumers that need them, providing a unified, repo-scoped interface for secret management.

## 🚀 Vision

Managing secrets across multiple projects, backends, and deployment targets is a common source of friction and security risk. dotai makes it as easy as using a `.env` file, but with the power and security of industrial-grade secret managers.

## ✨ Key Features

- **📂 Repo-Scoped Secrets:** Automatically discover and scope secrets based on your Git repository context.
- **🔄 Multi-Backend Sync:** Native integration with major secret providers:
  - HashiCorp Vault
  - Infisical
  - Doppler
  - 1Password
- **📡 Consumer Integration:** Seamlessly sync and inject secrets into:
  - **CI/CD:** GitHub Actions, GitLab CI.
  - **Environments:** GitHub Codespaces, Docker, Kubernetes.
  - **Cloud:** AWS (Secrets Manager/Parameter Store), GCP (Secret Manager).
- **🔧 Syntax Conversion:** Automatically convert between standard `.env` formats and backend-specific syntaxes.
- **📝 Templates:** Define powerful templates for generating complex configuration files from secrets.
- **🖥️ CLI First:** A powerful, developer-centric CLI for all operations.

## 📦 Installation

### Via Pixi (Recommended)
```bash
uv tool install dotaix
```

### Via pixi
```bash
pixi global install dotaix
```
