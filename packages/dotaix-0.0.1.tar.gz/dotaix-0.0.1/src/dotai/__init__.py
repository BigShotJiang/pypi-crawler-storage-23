"""dotai package exports."""

from dotai.cli import main

__all__ = ["main"]
