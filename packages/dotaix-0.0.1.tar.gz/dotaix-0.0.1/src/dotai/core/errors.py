"""Typed exception hierarchy for CLI-facing failures."""

from __future__ import annotations


class DotAgentError(Exception):
    """Base error for recoverable dotai failures."""

    exit_code: int = 1


class UsageError(DotAgentError):
    """Invalid flags, arguments, or command usage."""

    exit_code = 2


class ConfigNotFoundError(DotAgentError):
    """Requested agent config does not exist."""

    exit_code = 3


class ValidationFailureError(DotAgentError):
    """Config payload or schema validation failed."""

    exit_code = 4


class StorageError(DotAgentError):
    """Reading or writing config storage failed."""

    exit_code = 5
