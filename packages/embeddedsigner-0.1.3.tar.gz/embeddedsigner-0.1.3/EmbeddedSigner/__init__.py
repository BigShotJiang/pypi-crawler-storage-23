"""Expose the :class:`EmbedSigner` orchestrator."""

from ._embed_signer import EmbedSigner

__all__ = ["EmbedSigner"]
