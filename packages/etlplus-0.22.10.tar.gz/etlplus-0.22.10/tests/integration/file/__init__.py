"""
:mod:`tests.integration.file` subpackage.

Integration smoke tests for the :mod:`etlplus.file` subpackage.
"""

from __future__ import annotations
