"""
:mod:`tests.integration.cli` subpackage.

Integration tests for the :mod:`etlplus.cli` subpackage.
"""

from __future__ import annotations
