"""
:mod:`tests` package.

Tests for the :mod:`etlplus` package.
"""

from __future__ import annotations
