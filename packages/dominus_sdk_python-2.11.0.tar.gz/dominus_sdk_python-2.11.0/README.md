# Dominus SDK for Python

Async Python SDK for CareBridge Dominus services. It routes service calls to the Dominus Orchestrator and handles gateway-based JWT minting, base64 encoding, retries, and circuit breaking.

## What This Is
- Server-side, asyncio-first Python SDK (3.9+)
- Namespace API plus ultra-flat root shortcuts for common operations
- Defaults to production orchestrator + gateway endpoints (configurable)

## Quick Start
```python
import os
from dominus import dominus

os.environ["DOMINUS_TOKEN"] = "your-psk-token"

users = await dominus.db.query("users", filters={"status": "active"})
await dominus.redis.set("session:123", {"user": "john"}, ttl=3600)
file = await dominus.files.upload(data=buf, filename="report.pdf", category="reports")
```

## Architecture (SDK View)
- DOMINUS_TOKEN (PSK) -> Gateway `/jwt/mint` -> JWT cached in `dominus_cache`
- JSON requests/responses are base64-encoded for auth-required routes
- GET requests send no body; parameters are in path or POST body
- Gateway routing is optional per-request; AI namespace always uses gateway

## Namespaces
- `secrets`, `db`, `secure`, `redis`, `files`, `auth`, `ddl`, `logs`, `portal`, `courier`, `open`, `health`
- `admin` (reseed/reset admin category)
- `ai` (agent-runtime: LLM, RAG, artifacts, results, orchestration, speech)
- `workflow` (workflow-manager CRUD and execution)
- `oracle` / `stt` (streaming speech-to-text sessions)

## Configuration
Required:
- `DOMINUS_TOKEN`

Optional:
- `DOMINUS_GATEWAY_URL` (default production gateway)
- `DOMINUS_BASE_URL` (default production orchestrator)
- `DOMINUS_HTTP_PROXY` / `DOMINUS_HTTPS_PROXY` (httpx proxies)

## Documentation
- `docs/architecture.md`
- `docs/namespaces.md`
- `docs/development.md`

## License
Proprietary - CareBridge Systems
