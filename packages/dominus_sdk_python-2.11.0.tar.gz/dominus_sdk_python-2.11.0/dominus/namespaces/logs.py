"""
Logs Namespace - Structured logging via Logs Worker.

Routes through Gateway → Logs Worker for structured log ingestion and tailing.
SDK automatically captures callsite (file, function) - users just call:
    await dominus.logs.info("message", {"key": "value"})
"""
import inspect
import json
import sys
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Tuple, TYPE_CHECKING

if TYPE_CHECKING:
    from ..start import Dominus


class LogsNamespace:
    """
    Logging namespace — routes to Logs Worker via Gateway.

    All methods automatically capture callsite information (file, function)
    and send structured log events to /svc/logs/ingest via the gateway.

    Log levels: debug, info, notice, warn, error, critical

    Usage:
        # Basic logging
        await dominus.logs.info("User logged in", {"user_id": "123"})
        await dominus.logs.error("Payment failed", {"order_id": "456"})

        # With category
        await dominus.logs.info("Cache hit", {"key": "user:123"}, category="cache")

        # With exception
        try:
            do_something()
        except Exception as e:
            await dominus.logs.error("Operation failed", exception=e)

        # Tail recent logs
        logs = await dominus.logs.tail(minutes=10, limit=50)
    """

    def __init__(self, client: "Dominus", service_name: str = "sdk-client"):
        self._client = client
        self._service_name = service_name

    def _capture_callsite(self, depth: int = 3) -> Tuple[Optional[str], Optional[str]]:
        """Capture file and function from call stack.

        Args:
            depth: Stack frame depth to inspect (default: 3)

        Returns:
            Tuple of (filepath, function_name)
        """
        frame = inspect.currentframe()
        try:
            for _ in range(depth):
                if frame is not None:
                    frame = frame.f_back
            if frame is None:
                return None, None

            filepath = frame.f_code.co_filename
            function = frame.f_code.co_name

            # Normalize filepath - strip common prefixes
            for prefix in ['/app/', '/home/', 'C:\\', '/Users/']:
                if filepath.startswith(prefix):
                    filepath = filepath[len(prefix):]
                    break

            # Also strip any remaining absolute path prefix
            if '/' in filepath:
                # Keep last 3 path components max
                parts = filepath.split('/')
                if len(parts) > 3:
                    filepath = '/'.join(parts[-3:])
            elif '\\' in filepath:
                parts = filepath.split('\\')
                if len(parts) > 3:
                    filepath = '/'.join(parts[-3:])

            return filepath, function
        finally:
            del frame

    def _fallback_log(
        self,
        level: str,
        message: str,
        context: Optional[Dict[str, Any]] = None
    ) -> None:
        """Print to stderr as fallback when backend unavailable."""
        try:
            entry = {
                "dt": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
                "level": level.upper(),
                "message": message,
                "_fallback": True
            }
            if context:
                entry["context"] = context
            print(json.dumps(entry, separators=(",", ":")), file=sys.stderr)
        except Exception:
            pass

    def _build_event(
        self,
        level: str,
        message: str,
        context: Optional[Dict[str, Any]] = None,
        category: Optional[str] = None,
        file: Optional[str] = None,
        function: Optional[str] = None,
        exception: Optional[Exception] = None
    ) -> Dict[str, Any]:
        """Build a LogEvent in Logs Worker wire format.

        Returns:
            Dict matching LogEvent: {ts, level, service, event_name, msg, attrs}
        """
        event: Dict[str, Any] = {
            "ts": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
            "level": level.upper(),
            "service": self._service_name,
            "event_name": f"sdk.{level}",
            "msg": message,
        }

        attrs: Dict[str, Any] = {}
        if context:
            attrs.update(context)
        if category:
            attrs["category"] = category
        if file:
            attrs["file"] = file
        if function:
            attrs["function"] = function
        if exception:
            attrs["exception"] = {
                "type": type(exception).__name__,
                "message": str(exception)
            }
        if attrs:
            event["attrs"] = attrs

        return event

    async def _log(
        self,
        level: str,
        message: str,
        context: Optional[Dict[str, Any]] = None,
        category: Optional[str] = None,
        exception: Optional[Exception] = None
    ) -> bool:
        """Internal log method with callsite capture.

        Sends a single event to /svc/logs/ingest via the gateway.

        Args:
            level: Log level
            message: Log message
            context: Optional context dict (merged into attrs)
            category: Optional category (stored in attrs.category)
            exception: Optional exception to include

        Returns:
            True if successfully sent, False otherwise
        """
        file, function = self._capture_callsite(depth=3)

        event = self._build_event(
            level=level,
            message=message,
            context=context,
            category=category,
            file=file,
            function=function,
            exception=exception,
        )

        try:
            await self._client._request(
                endpoint="/api/logs/ingest",
                body={"events": [event]},
                use_gateway=True,
            )
            return True
        except Exception:
            # Never raise - fallback to local
            self._fallback_log(level, message, context)
            return False

    async def debug(
        self,
        message: str,
        context: Optional[Dict[str, Any]] = None,
        category: Optional[str] = None
    ) -> bool:
        """Log debug message.

        Args:
            message: Log message
            context: Optional structured context
            category: Optional category

        Returns:
            True if successfully sent
        """
        return await self._log("debug", message, context, category)

    async def info(
        self,
        message: str,
        context: Optional[Dict[str, Any]] = None,
        category: Optional[str] = None
    ) -> bool:
        """Log info message.

        Args:
            message: Log message
            context: Optional structured context
            category: Optional category

        Returns:
            True if successfully sent
        """
        return await self._log("info", message, context, category)

    async def notice(
        self,
        message: str,
        context: Optional[Dict[str, Any]] = None,
        category: Optional[str] = None
    ) -> bool:
        """Log notice message.

        Args:
            message: Log message
            context: Optional structured context
            category: Optional category

        Returns:
            True if successfully sent
        """
        return await self._log("notice", message, context, category)

    async def warn(
        self,
        message: str,
        context: Optional[Dict[str, Any]] = None,
        category: Optional[str] = None
    ) -> bool:
        """Log warning message.

        Args:
            message: Log message
            context: Optional structured context
            category: Optional category

        Returns:
            True if successfully sent
        """
        return await self._log("warn", message, context, category)

    async def error(
        self,
        message: str,
        context: Optional[Dict[str, Any]] = None,
        category: Optional[str] = None,
        exception: Optional[Exception] = None
    ) -> bool:
        """Log error message.

        Args:
            message: Log message
            context: Optional structured context
            category: Optional category
            exception: Optional exception to include

        Returns:
            True if successfully sent
        """
        return await self._log("error", message, context, category, exception)

    async def critical(
        self,
        message: str,
        context: Optional[Dict[str, Any]] = None,
        category: Optional[str] = None,
        exception: Optional[Exception] = None
    ) -> bool:
        """Log critical message.

        Args:
            message: Log message
            context: Optional structured context
            category: Optional category
            exception: Optional exception to include

        Returns:
            True if successfully sent
        """
        return await self._log("critical", message, context, category, exception)

    async def tail(
        self,
        minutes: int = 10,
        limit: int = 100,
    ) -> List[Dict[str, Any]]:
        """Tail recent logs from the Logs Worker.

        Returns log events from the last N minutes (newest first).

        Args:
            minutes: Time window — 1, 10, or 60 (default: 10)
            limit: Maximum results, 1-1000 (default: 100)

        Returns:
            List of log event dicts
        """
        params = []
        if minutes != 10:
            params.append(f"minutes={minutes}")
        if limit != 100:
            params.append(f"limit={limit}")
        qs = "&".join(params)
        endpoint = f"/api/logs/tail?{qs}" if qs else "/api/logs/tail"

        try:
            result = await self._client._request(
                endpoint=endpoint,
                method="GET",
                use_gateway=True,
            )
            return result.get("events", [])
        except Exception:
            return []

    async def query(
        self,
        minutes: int = 10,
        limit: int = 100,
        **kwargs,
    ) -> List[Dict[str, Any]]:
        """Query logs — alias for tail().

        Legacy method kept for backwards compatibility.
        The Logs Worker tail endpoint supports time-based queries.

        Args:
            minutes: Time window — 1, 10, or 60 (default: 10)
            limit: Maximum results, 1-1000 (default: 100)

        Returns:
            List of log event dicts
        """
        return await self.tail(minutes=minutes, limit=limit)

    async def batch(
        self,
        events: List[Dict[str, Any]]
    ) -> Dict[str, Any]:
        """Send multiple log events in one request.

        Events are transformed to the Logs Worker wire format and sent
        to /svc/logs/ingest via the gateway. Max 100 events per batch.

        Args:
            events: List of log event dicts, each with:
                - level (required): debug, info, notice, warn, error, critical
                - message (required): Log message
                - context (optional): Structured context (merged into attrs)
                - category (optional): Log category (stored in attrs)

        Returns:
            Dict with total, stored, failed counts
        """
        # Transform each event from SDK format to Logs Worker format
        transformed = []
        for evt in events[:100]:
            transformed.append(self._build_event(
                level=evt.get("level", "info"),
                message=evt.get("message", ""),
                context=evt.get("context"),
                category=evt.get("category"),
            ))

        try:
            result = await self._client._request(
                endpoint="/api/logs/ingest",
                body={"events": transformed},
                use_gateway=True,
            )
            return {
                "total": len(transformed),
                "stored": result.get("stored", len(transformed)),
                "failed": 0,
            }
        except Exception:
            # Fallback - log each locally
            for event in events:
                self._fallback_log(
                    event.get("level", "info"),
                    event.get("message", ""),
                    event.get("context")
                )
            return {
                "total": len(events),
                "stored": 0,
                "failed": len(events)
            }
