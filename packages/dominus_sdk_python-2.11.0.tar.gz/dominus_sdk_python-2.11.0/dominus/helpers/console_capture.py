"""
Console Capture - Auto-forwards print() and logging.* to Dominus Logs Worker.

Activated by DOMINUS_CAPTURE_CONSOLE=true environment variable.
Preserves original output and never throws errors.

Usage:
    # Automatic (via env var):
    # Set DOMINUS_CAPTURE_CONSOLE=true before importing SDK

    # Manual:
    from dominus import dominus
    dominus.capture_console()     # start capturing
    dominus.release_console()     # stop capturing
"""
import asyncio
import builtins
import logging
import sys
from typing import Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from ..namespaces.logs import LogsNamespace

_installed = False
_logs_ref: Optional["LogsNamespace"] = None
_original_print = builtins.print
_log_handler: Optional["DominusLogHandler"] = None

# Guard against re-entrant calls (fallback_log uses print to stderr)
_sending = False


def _format_args(args: tuple, kwargs: dict) -> str:
    """Format print-style arguments into a single string."""
    sep = kwargs.get("sep", " ")
    parts = []
    for arg in args:
        if arg is None:
            parts.append("None")
        elif isinstance(arg, Exception):
            parts.append(f"{type(arg).__name__}: {arg}")
        elif isinstance(arg, (dict, list)):
            try:
                import json
                parts.append(json.dumps(arg, default=str))
            except Exception:
                parts.append(str(arg))
        else:
            parts.append(str(arg))
    return sep.join(parts)


def _fire_log(level: str, message: str) -> None:
    """Fire-and-forget log to Dominus Logs Worker. Never blocks, never throws."""
    global _sending
    if _sending or not _logs_ref:
        return
    _sending = True

    async def _send():
        global _sending
        try:
            if level == "debug":
                await _logs_ref.debug(message, {"source": "console"}, "console")
            elif level == "info":
                await _logs_ref.info(message, {"source": "console"}, "console")
            elif level == "warn":
                await _logs_ref.warn(message, {"source": "console"}, "console")
            elif level == "error":
                await _logs_ref.error(message, {"source": "console"}, "console")
        except Exception:
            pass
        finally:
            _sending = False

    # Try to schedule in the running event loop, fall back silently
    try:
        loop = asyncio.get_running_loop()
        loop.create_task(_send())
    except RuntimeError:
        # No running event loop - skip (can't do async without one)
        _sending = False


def _patched_print(*args, **kwargs):
    """Replacement print() that also sends to Logs Worker."""
    # Always call original print first
    _original_print(*args, **kwargs)

    # Determine if this is stderr output (which may be fallback logging)
    file = kwargs.get("file")
    if file is sys.stderr:
        # Don't capture stderr prints (likely fallback logs - avoid loop)
        return

    message = _format_args(args, kwargs)
    _fire_log("info", message)


class DominusLogHandler(logging.Handler):
    """Logging handler that forwards records to Dominus Logs Worker."""

    def emit(self, record: logging.LogRecord) -> None:
        # Map Python log levels to Dominus levels
        level_map = {
            "DEBUG": "debug",
            "INFO": "info",
            "WARNING": "warn",
            "ERROR": "error",
            "CRITICAL": "error",
        }
        level = level_map.get(record.levelname, "info")
        message = self.format(record)
        _fire_log(level, message)


def install_console_capture(logs: "LogsNamespace") -> None:
    """
    Install console capture wrappers.
    Call this after LogsNamespace is initialized.

    Args:
        logs: The LogsNamespace instance to forward logs to
    """
    global _installed, _logs_ref, _log_handler

    if _installed:
        return

    _logs_ref = logs
    _installed = True

    # Patch builtins.print
    builtins.print = _patched_print

    # Install logging handler on root logger
    _log_handler = DominusLogHandler()
    _log_handler.setLevel(logging.DEBUG)
    logging.getLogger().addHandler(_log_handler)


def uninstall_console_capture() -> None:
    """Remove console capture wrappers, restoring original behavior."""
    global _installed, _logs_ref, _log_handler

    if not _installed:
        return

    _installed = False
    _logs_ref = None

    # Restore original print
    builtins.print = _original_print

    # Remove logging handler
    if _log_handler is not None:
        logging.getLogger().removeHandler(_log_handler)
        _log_handler = None


def is_console_capture_active() -> bool:
    """Check if console capture is currently active."""
    return _installed
