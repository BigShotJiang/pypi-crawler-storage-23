# datajobs

A Python ETL framework with Business Rule Validator for Databricks and PostgreSQL.

## 🚀 Features

- SQL Template and Snippet Injection
- Dynamic Rule Processing
- Config-driven ETL Execution
- PostgreSQL & Databricks support

## 📦 Installation

```bash
pip install datajobs