"""
Main entry point for the datajobs package, if run as a script.
"""

from .load_scripts import LoadScripts

def main():
    ls = LoadScripts()
    print("datajobs package entry point.")
    # Example usage:
    # ls.load_config('path/to/config.json')

if __name__ == "__main__":
    main()
