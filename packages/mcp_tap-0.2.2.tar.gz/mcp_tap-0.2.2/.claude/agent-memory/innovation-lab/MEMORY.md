# Innovation Lab Memory — mcp-tap

## Project: mcp-tap (MCP meta-server)
- No experiments yet. Fresh project.
- See `docs/CREATIVE_BRIEF.md` for product vision and feature roadmap.
