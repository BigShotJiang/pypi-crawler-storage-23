# Database Performance Architect Memory — mcp-tap

## Project: mcp-tap (no database — reads/writes JSON config files)
- No database. Config stored as JSON files on filesystem.
- This agent is unlikely to be needed for this project.
