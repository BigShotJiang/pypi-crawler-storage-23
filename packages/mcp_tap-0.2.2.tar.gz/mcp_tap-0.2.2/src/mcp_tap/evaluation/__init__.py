"""Evaluation module -- assess MCP server maturity via GitHub metadata."""
