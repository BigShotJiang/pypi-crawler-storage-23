"""Model configuration utilities."""

import argparse

from omegaconf import OmegaConf

# Valid port range bounds (avoid privileged ports 0-1023)
MIN_VALID_PORT = 1024
MAX_VALID_PORT = 65535


def load_model_config(path, overrides):
    """Load a model config file and apply CLI overrides.

    Args:
        path: Path to the YAML config file
        overrides: List of dotlist override strings (e.g., ["key=value"])

    Returns:
        Merged OmegaConf DictConfig
    """
    cfg = OmegaConf.load(path)
    cli_cfg = OmegaConf.from_dotlist(overrides)
    return OmegaConf.merge(cfg, cli_cfg)


def print_model_config_help(config_path: str) -> None:
    """Print available model configuration options from a config file.

    Shows all keys in the config with their default values and how to override them.

    Args:
        config_path: Path to the model config file (YAML)
    """
    try:
        cfg = OmegaConf.load(config_path)
    except Exception as e:
        print(f"Error loading config file '{config_path}': {e}")
        return

    print(f"\nModel configuration options from: {config_path}")
    print("=" * 60)
    print("\nAvailable parameters (override with --model.<key>=<value>):\n")

    def _print_config(config, prefix=""):
        """Recursively print config keys with their values."""
        for key, value in config.items():
            full_key = f"{prefix}{key}" if prefix else key
            if OmegaConf.is_config(value):
                # Nested config - recurse
                _print_config(value, prefix=f"{full_key}.")
            else:
                value_type = type(value).__name__
                print(f"  --model.{full_key}={value}")
                print(f"      Type: {value_type}, Default: {value}\n")

    _print_config(cfg)
    print("=" * 60)


def validate_port(port: int) -> None:
    """Validate that the port is in the valid range.

    Args:
        port: The port number to validate.

    Raises:
        ValueError: If the port is outside the valid range.
    """
    if not (MIN_VALID_PORT <= port <= MAX_VALID_PORT):
        raise ValueError(
            f"port must be between {MIN_VALID_PORT} and {MAX_VALID_PORT}, got {port}"
        )


def _valid_port(value: str) -> int:
    """Validate that the port is an integer in the valid range (for argparse)."""
    try:
        port = int(value)
    except ValueError:
        raise argparse.ArgumentTypeError(f"invalid int value: '{value}'")
    try:
        validate_port(port)
    except ValueError as e:
        raise argparse.ArgumentTypeError(str(e))
    return port
