"""
Plotting utilities for profiling data visualization.
"""
