"""
Profiler backends for different output targets.
"""

from reactor_runtime.profiling.backends.base import ProfilerBackend
from reactor_runtime.profiling.backends.file import FileProfilerBackend

__all__ = [
    "ProfilerBackend",
    "FileProfilerBackend",
]

# OTLP backend is conditionally available
try:
    from reactor_runtime.profiling.backends.otlp import (
        OTLPProfilerBackend,  # noqa: F401
    )

    __all__.append("OTLPProfilerBackend")
except ImportError:
    pass
