"""
OTLP backend for profiler - exports timing data as histograms via OpenTelemetry.
"""

from typing import Optional

from opentelemetry import metrics

from reactor_runtime.profiling.backends.base import ProfilerBackend
from reactor_runtime.utils.log import get_logger

logger = get_logger(__name__)


class OTLPProfilerBackend(ProfilerBackend):
    """
    Profiler backend that exports timing data to OTLP as histograms.

    Uses the existing ReactorMachineMetrics infrastructure for OTLP configuration.
    Creates a histogram metric for section durations with attributes for filtering.
    """

    def __init__(self) -> None:
        """
        Initialize the OTLP profiler backend.

        Uses the global meter provider that should already be configured
        by ReactorMachineMetrics.
        """
        self._enabled = False
        self._histogram: Optional[metrics.Histogram] = None
        self._machine_id: Optional[str] = None
        self._model_name: Optional[str] = None
        self._machine_info_refresh_attempted = False

        self._setup()

    def _setup(self) -> None:
        """Set up the OTLP histogram metric."""
        try:
            # Get the meter from the global provider (set up by ReactorMachineMetrics)
            meter = metrics.get_meter(__name__)

            # Create histogram for section durations (in milliseconds)
            # Using milliseconds so default OTEL bucket boundaries work well
            self._histogram = meter.create_histogram(
                name="reactor_profiler_section_ms",
                description="Duration of profiled code sections in milliseconds",
                unit="ms",
            )

            # Try to get machine info from ReactorMachineMetrics
            try:
                from reactor_runtime.runtimes._redis.reactor_machine_metrics import (
                    ReactorMachineMetrics,
                )

                self._machine_id = ReactorMachineMetrics.machine_id
                self._model_name = ReactorMachineMetrics.model_name
            except (ImportError, AttributeError):
                pass

            self._enabled = True
            logger.debug("OTLP profiler backend initialized")

        except Exception as e:
            logger.warning("Failed to set up OTLP profiler backend", error=e)
            self._enabled = False

    def _resource_attrs(self) -> dict:
        """Return resource attributes for metrics."""
        return {
            "machine_id": self._machine_id or "unknown",
            "model_name": self._model_name or "unknown",
        }

    def record(
        self, key: str, parent_path: str, full_path: str, duration: float
    ) -> None:
        """
        Record a timing measurement to the OTLP histogram.

        Args:
            key: The section key (e.g., "vae_decode").
            parent_path: The path of parent sections (e.g., "inference/diffusion").
            full_path: The complete path including this section.
            duration: The duration in seconds (converted to milliseconds for export).
        """
        if not self._enabled or self._histogram is None:
            return

        # Refresh machine info once in case it was set after init
        if self._machine_id is None and not self._machine_info_refresh_attempted:
            self._machine_info_refresh_attempted = True
            try:
                from reactor_runtime.runtimes._redis.reactor_machine_metrics import (
                    ReactorMachineMetrics,
                )

                self._machine_id = ReactorMachineMetrics.machine_id
                self._model_name = ReactorMachineMetrics.model_name
            except (ImportError, AttributeError):
                pass

        attributes = {
            "section_key": key,
            "parent_path": parent_path or "",
            "full_path": full_path,
            **self._resource_attrs(),
        }

        # Convert seconds to milliseconds for better histogram bucket coverage
        duration_ms = duration * 1000.0
        self._histogram.record(duration_ms, attributes=attributes)
