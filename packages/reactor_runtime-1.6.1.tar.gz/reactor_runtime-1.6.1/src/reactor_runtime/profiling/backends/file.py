"""
File backend for profiler - accumulates timing data and writes to JSON files.
"""

import csv
import io
import json
import os
import shutil
import socket
import subprocess
import sys
import threading
import time
from collections import defaultdict
from pathlib import Path
from typing import Dict, List, Optional

from reactor_runtime.profiling.backends.base import ProfilerBackend
from reactor_runtime.utils.log import get_logger

# Optional imports for metadata
try:
    import torch

    TORCH_AVAILABLE = True
except ImportError:
    TORCH_AVAILABLE = False
    torch = None  # type: ignore[assignment]

logger = get_logger(__name__)


def compute_percentiles(
    samples: List[float], percentiles: List[float]
) -> Dict[float, float]:
    """Compute percentiles for a list of samples.

    Args:
        samples: List of duration values in seconds.
        percentiles: List of percentile values (0-100).

    Returns:
        Dictionary mapping percentile to value in seconds.
    """
    if not samples:
        return {p: 0.0 for p in percentiles}

    sorted_samples = sorted(samples)
    result = {}
    for p in percentiles:
        if p <= 0:
            result[p] = sorted_samples[0]
        elif p >= 100:
            result[p] = sorted_samples[-1]
        else:
            index = (p / 100.0) * (len(sorted_samples) - 1)
            lower = int(index)
            upper = min(lower + 1, len(sorted_samples) - 1)
            weight = index - lower
            result[p] = (
                sorted_samples[lower] * (1 - weight) + sorted_samples[upper] * weight
            )
    return result


class FileProfilerBackend(ProfilerBackend):
    """
    Profiler backend that accumulates timing data in memory and writes to JSON files.

    Used for local development and testing when OTLP is not available.
    Timing samples are accumulated during the session and written to a JSON file
    on flush, which can then be visualized with a separate plotting script.
    """

    def __init__(self, output_dir: str) -> None:
        """
        Initialize the file profiler backend.

        Args:
            output_dir: Directory where profiling JSON files will be written.
        """
        self._output_dir = Path(output_dir)
        self._lock = threading.Lock()

        # Accumulated samples: full_path -> list of durations
        self._samples: Dict[str, List[float]] = defaultdict(list)

        # Track metadata for each section
        self._section_metadata: Dict[str, Dict] = {}

        # Track start time for wall-clock duration
        self._start_time: Optional[float] = None

        logger.debug("File profiler backend initialized", output_dir=output_dir)

    def _atomic_write(self, file_path: Path, content: str) -> None:
        """Write file atomically using temp file + rename.

        Args:
            file_path: Target file path.
            content: Content to write.
        """
        # Write to temp file in same directory
        temp_path = file_path.parent / f".{file_path.name}.tmp"
        try:
            temp_path.write_text(content)
            # Atomic rename
            temp_path.replace(file_path)
        except Exception as e:
            # Clean up temp file on error
            if temp_path.exists():
                try:
                    temp_path.unlink()
                except Exception:
                    pass
            raise e

    def record(
        self, key: str, parent_path: str, full_path: str, duration: float
    ) -> None:
        """
        Record a timing measurement.

        Args:
            key: The section key (e.g., "vae_decode").
            parent_path: The path of parent sections (e.g., "inference/diffusion").
            full_path: The complete path including this section.
            duration: The duration in seconds.
        """
        with self._lock:
            # Track start time on first record
            if self._start_time is None:
                self._start_time = time.time()

            self._samples[full_path].append(duration)

            # Store metadata on first occurrence
            if full_path not in self._section_metadata:
                self._section_metadata[full_path] = {
                    "key": key,
                    "parent_path": parent_path,
                }

    def flush(self, output_path: Optional[Path] = None) -> None:
        """
        Write accumulated samples to a JSON file.

        Args:
            output_path: Optional specific path to write to. If not provided,
                         generates a timestamped filename in the output directory.
        """
        with self._lock:
            if not self._samples:
                logger.debug("No profiling samples to flush")
                return

            # Determine output path
            if output_path is None:
                self._output_dir.mkdir(parents=True, exist_ok=True)
                timestamp = int(time.time() * 1000)  # millisecond precision
                output_path = self._output_dir / f"profiling_{timestamp}.json"

            # Build output data structure
            sections = {}
            for full_path, samples in self._samples.items():
                metadata = self._section_metadata.get(full_path, {})
                sections[full_path] = {
                    "key": metadata.get("key", full_path.split("/")[-1]),
                    "parent_path": metadata.get("parent_path", ""),
                    "samples": samples,
                    "count": len(samples),
                    "total_seconds": sum(samples),
                    "mean_seconds": sum(samples) / len(samples) if samples else 0,
                    "min_seconds": min(samples) if samples else 0,
                    "max_seconds": max(samples) if samples else 0,
                }

            data = {
                "timestamp": time.time(),
                "timestamp_iso": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
                "output_dir": str(self._output_dir),
                "total_sections": len(sections),
                "total_samples": sum(s["count"] for s in sections.values()),
                "sections": sections,
            }

            # Write to file, ensuring cleanup happens regardless of success/failure
            timestamp_str = output_path.stem.replace("profiling_", "")
            try:
                output_path.parent.mkdir(parents=True, exist_ok=True)
                # Atomic write: write to temp file then rename
                self._atomic_write(output_path, json.dumps(data, indent=2))
                logger.info("Profiling data written", output_path=output_path)

                # Write additional artifacts: summary.md, sections.csv, and meta.json
                self._write_summary_artifacts(output_path, data, sections)
                self._write_metadata_file(output_path, data)

                # Create run bundle directory and copy/link artifacts
                self._create_run_bundle(output_path, timestamp_str)
            except Exception as e:
                logger.warning(
                    "Failed to write profiling data",
                    output_path=output_path,
                    error=e,
                )
            finally:
                # Always clear accumulated data to maintain consistent state
                self._samples.clear()
                self._section_metadata.clear()
                self._start_time = None

    def _write_summary_artifacts(
        self, json_path: Path, data: Dict, sections: Dict[str, Dict]
    ) -> None:
        """Write summary.md and sections.csv artifacts alongside the JSON file.

        Args:
            json_path: Path to the JSON file (used to derive output paths).
            data: The profiling data dictionary.
            sections: The sections dictionary with computed stats.
        """
        timestamp_str = json_path.stem.replace("profiling_", "")

        # Compute wall-clock duration
        wall_clock_duration = 0.0
        if self._start_time is not None:
            wall_clock_duration = time.time() - self._start_time

        # Compute percentiles for each section
        section_stats = {}
        for full_path, section_data in sections.items():
            samples = section_data.get("samples", [])
            if samples:
                percentiles = compute_percentiles(samples, [50, 90, 99])
                section_stats[full_path] = {
                    "count": len(samples),
                    "mean_ms": section_data.get("mean_seconds", 0) * 1000,
                    "p50_ms": percentiles[50] * 1000,
                    "p90_ms": percentiles[90] * 1000,
                    "p99_ms": percentiles[99] * 1000,
                    "max_ms": section_data.get("max_seconds", 0) * 1000,
                }

        # Write summary.md
        summary_path = json_path.parent / f"profiling_{timestamp_str}_summary.md"
        try:
            # Build content in memory for atomic write
            summary_lines = []
            summary_lines.append("# Profiling Summary\n\n")
            summary_lines.append(
                f"**Timestamp:** {data.get('timestamp_iso', 'Unknown')}\n\n"
            )
            summary_lines.append(f"**Total Samples:** {data.get('total_samples', 0)}\n")
            summary_lines.append(
                f"**Total Sections:** {data.get('total_sections', 0)}\n"
            )
            if wall_clock_duration > 0:
                summary_lines.append(
                    f"**Wall-Clock Duration:** {wall_clock_duration:.2f}s\n"
                )
            summary_lines.append("\n")

            # Per-section stats
            summary_lines.append("## Section Statistics\n\n")
            summary_lines.append(
                "| Section | Count | Mean (ms) | P50 (ms) | P90 (ms) | P99 (ms) | Max (ms) |\n"
            )
            summary_lines.append(
                "|---------|-------|-----------|----------|----------|----------|----------|\n"
            )

            for full_path in sorted(section_stats.keys()):
                stats = section_stats[full_path]
                summary_lines.append(
                    f"| {full_path} | {stats['count']} | "
                    f"{stats['mean_ms']:.3f} | {stats['p50_ms']:.3f} | "
                    f"{stats['p90_ms']:.3f} | {stats['p99_ms']:.3f} | "
                    f"{stats['max_ms']:.3f} |\n"
                )

            # Top hot sections by mean
            summary_lines.append("\n## Top Hot Sections (by Mean)\n\n")
            sorted_by_mean = sorted(
                section_stats.items(), key=lambda x: x[1]["mean_ms"], reverse=True
            )[:10]
            summary_lines.append("| Section | Mean (ms) | P99 (ms) | Count |\n")
            summary_lines.append("|---------|-----------|----------|-------|\n")
            for full_path, stats in sorted_by_mean:
                summary_lines.append(
                    f"| {full_path} | {stats['mean_ms']:.3f} | "
                    f"{stats['p99_ms']:.3f} | {stats['count']} |\n"
                )

            # Top hot sections by p99
            summary_lines.append("\n## Top Hot Sections (by P99)\n\n")
            sorted_by_p99 = sorted(
                section_stats.items(), key=lambda x: x[1]["p99_ms"], reverse=True
            )[:10]
            summary_lines.append("| Section | P99 (ms) | Mean (ms) | Count |\n")
            summary_lines.append("|---------|----------|-----------|-------|\n")
            for full_path, stats in sorted_by_p99:
                summary_lines.append(
                    f"| {full_path} | {stats['p99_ms']:.3f} | "
                    f"{stats['mean_ms']:.3f} | {stats['count']} |\n"
                )

            # FPS metrics if applicable
            fps_sections = [
                (path, stats)
                for path, stats in section_stats.items()
                if "frame_pipeline" in path or "emit_block" in path
            ]
            if fps_sections:
                summary_lines.append("\n## FPS Estimates\n\n")
                summary_lines.append("| Section | Mean (ms) | Estimated FPS |\n")
                summary_lines.append("|---------|-----------|----------------|\n")
                for full_path, stats in fps_sections:
                    if stats["mean_ms"] > 0:
                        fps_estimate = 1000.0 / stats["mean_ms"]
                        summary_lines.append(
                            f"| {full_path} | {stats['mean_ms']:.3f} | "
                            f"{fps_estimate:.2f} |\n"
                        )

            # Write atomically
            self._atomic_write(summary_path, "".join(summary_lines))
            logger.debug("Summary written", summary_path=summary_path)
        except Exception as e:
            logger.warning(
                "Failed to write summary", summary_path=summary_path, error=e
            )

        # Write sections.csv
        csv_path = json_path.parent / f"profiling_{timestamp_str}_sections.csv"
        try:
            buf = io.StringIO()
            writer = csv.writer(buf)
            writer.writerow(
                [
                    "section_path",
                    "count",
                    "mean_ms",
                    "p50_ms",
                    "p90_ms",
                    "p99_ms",
                    "max_ms",
                ]
            )
            for full_path in sorted(section_stats.keys()):
                stats = section_stats[full_path]
                writer.writerow(
                    [
                        full_path,
                        stats["count"],
                        f"{stats['mean_ms']:.6f}",
                        f"{stats['p50_ms']:.6f}",
                        f"{stats['p90_ms']:.6f}",
                        f"{stats['p99_ms']:.6f}",
                        f"{stats['max_ms']:.6f}",
                    ]
                )
            self._atomic_write(csv_path, buf.getvalue())
            logger.debug("CSV written", csv_path=csv_path)
        except Exception as e:
            logger.warning("Failed to write CSV", csv_path=csv_path, error=e)

    def _write_metadata_file(self, json_path: Path, data: Dict) -> None:
        """Write metadata file with run information.

        This is separate from the profiling JSON schema and contains
        environment and run metadata for reproducibility.

        Args:
            json_path: Path to the JSON file (used to derive output path).
            data: The profiling data dictionary.
        """
        timestamp_str = json_path.stem.replace("profiling_", "")
        meta_path = json_path.parent / f"profiling_{timestamp_str}_meta.json"

        metadata = {
            "timestamp": data.get("timestamp", time.time()),
            "timestamp_iso": data.get("timestamp_iso", ""),
            "hostname": socket.gethostname(),
            "python_version": sys.version.split()[0],
            "python_executable": sys.executable,
        }

        # Git SHA (if available)
        try:
            result = subprocess.run(
                ["git", "rev-parse", "HEAD"],
                capture_output=True,
                text=True,
                timeout=2,
                cwd=Path(__file__).parent.parent.parent.parent.parent,
            )
            if result.returncode == 0:
                metadata["git_sha"] = result.stdout.strip()
        except (subprocess.TimeoutExpired, FileNotFoundError, Exception):
            pass  # Git not available or not in a git repo

        # Git branch (if available)
        try:
            result = subprocess.run(
                ["git", "rev-parse", "--abbrev-ref", "HEAD"],
                capture_output=True,
                text=True,
                timeout=2,
                cwd=Path(__file__).parent.parent.parent.parent.parent,
            )
            if result.returncode == 0:
                metadata["git_branch"] = result.stdout.strip()
        except (subprocess.TimeoutExpired, FileNotFoundError, Exception):
            pass

        # PyTorch version and device info
        if TORCH_AVAILABLE:
            try:
                metadata["torch_version"] = torch.__version__
                if torch.cuda.is_available():
                    metadata["cuda_available"] = True
                    metadata["cuda_version"] = torch.version.cuda
                    metadata["cuda_device_count"] = torch.cuda.device_count()
                    if torch.cuda.device_count() > 0:
                        metadata["cuda_device_name"] = torch.cuda.get_device_name(0)
                else:
                    metadata["cuda_available"] = False
            except Exception:
                pass

        # Command line (if available via environment)
        if "REACTOR_PROFILING_CMD" in os.environ:
            metadata["command_line"] = os.environ["REACTOR_PROFILING_CMD"]

        # Model name/path (if available via environment)
        if "REACTOR_MODEL_NAME" in os.environ:
            metadata["model_name"] = os.environ["REACTOR_MODEL_NAME"]
        if "REACTOR_MODEL_PATH" in os.environ:
            metadata["model_path"] = os.environ["REACTOR_MODEL_PATH"]

        # Runtime type (if available via environment)
        if "REACTOR_RUNTIME_TYPE" in os.environ:
            metadata["runtime_type"] = os.environ["REACTOR_RUNTIME_TYPE"]

        try:
            # Write atomically
            self._atomic_write(meta_path, json.dumps(metadata, indent=2))
            logger.debug("Metadata written", meta_path=meta_path)
        except Exception as e:
            logger.warning("Failed to write metadata", meta_path=meta_path, error=e)

    def _create_run_bundle(self, json_path: Path, timestamp_str: str) -> None:
        """Create run bundle directory and copy/link artifacts.

        Creates profiling/run_<timestamp>/ and copies all artifacts there.
        Uses hard links when possible (same filesystem) to save space.

        Args:
            json_path: Path to the JSON file.
            timestamp_str: Timestamp string for run bundle name.
        """
        try:
            run_bundle_dir = self._output_dir / f"run_{timestamp_str}"
            run_bundle_dir.mkdir(parents=True, exist_ok=True)

            # Files to copy/link
            artifacts = [
                json_path,
                json_path.parent / f"profiling_{timestamp_str}_summary.md",
                json_path.parent / f"profiling_{timestamp_str}_sections.csv",
                json_path.parent / f"profiling_{timestamp_str}_meta.json",
            ]

            for artifact in artifacts:
                if artifact.exists():
                    target = run_bundle_dir / artifact.name
                    # Try hard link first (same filesystem, saves space)
                    try:
                        target.hardlink_to(artifact)
                    except (OSError, AttributeError):
                        # Fall back to copy if hard link fails (different filesystem, etc.)
                        shutil.copy2(artifact, target)

            logger.debug("Run bundle created", run_bundle_dir=run_bundle_dir)
        except Exception as e:
            # Don't fail the flush if bundle creation fails
            logger.warning("Failed to create run bundle", error=e)

    def shutdown(self) -> None:
        """Flush any remaining data on shutdown."""
        try:
            self.flush()
        except Exception as e:
            logger.warning("Failed to flush profiling data during shutdown", error=e)
