"""
Profiling module for Reactor Runtime.

Provides profiling capabilities to measure code section durations with nested interval support.
Exports to OTLP histograms in production or writes to files locally for later visualization.

Supports three CUDA timing modes for GPU operations:
- CudaTimingMode.NONE: CPU timing only (default)
- CudaTimingMode.EVENT: CUDA events for single-stream GPU work
- CudaTimingMode.SYNC: Full synchronization for multi-stream GPU work
"""

from reactor_runtime.profiling.profiler import (
    CudaTimingMode,
    Profiler,
    ProfilerSection,
    NoOpProfiler,
)
from reactor_runtime.profiling.backends.base import ProfilerBackend
from reactor_runtime.profiling.helpers import profile_fn

__all__ = [
    "CudaTimingMode",
    "Profiler",
    "ProfilerSection",
    "NoOpProfiler",
    "ProfilerBackend",
    "profile_fn",
]
