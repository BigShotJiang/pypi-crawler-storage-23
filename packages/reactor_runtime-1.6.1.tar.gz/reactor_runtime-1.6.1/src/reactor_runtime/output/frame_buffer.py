"""
Rate-controlled media emission buffer.

The :class:`FrameBuffer` sits between the model (which pushes complete
:class:`MediaBundle` objects at a variable, bursty rate) and the runtime
callback (which must deliver frames at a smooth, predictable FPS to the
WebRTC transport).

Two emission modes are supported:

**Fixed rate** -- the emission loop ticks at exactly the declared video
FPS.  Multi-frame bundles are split so each video frame is emitted on
its own tick.  Audio is divided proportionally and resampled to
``audio_sample_rate / video_fps`` samples per frame.

* Model too slow  -> queue starves -> last frame repeated (duplicate).
* Model too fast  -> oldest queued frames dropped automatically.

**Auto mode** (default) -- the emission FPS adapts to the model's push
rate.  The time between successive :meth:`push` calls determines the
effective FPS.  Audio is resampled to maintain the correct sample rate
at whatever emission FPS is in effect.  Both video and audio slow down
together when the model is slower than real-time -- there are no silence
gaps.

Copyright (c) 2026 Reactor Technologies, Inc. All rights reserved.
"""

import collections
import threading
import time
from typing import Callable, List, Optional

import numpy as np

from reactor_runtime.transports.media import (
    MediaBundle,
    TrackData,
    TrackInfo,
    TrackKind,
)
from reactor_runtime.utils.log import get_logger

# ---------------------------------------------------------------------------
# Module constants
# ---------------------------------------------------------------------------

DEFAULT_FPS_GUESS: int = 16
DEFAULT_FRAME_DIMENSIONS: tuple[int, int, int] = (720, 1280, 3)  # 720p RGB
_DEFAULT_AUDIO_SAMPLE_RATE: int = 48000

logger = get_logger(__name__)


# ---------------------------------------------------------------------------
# FrameBuffer
# ---------------------------------------------------------------------------


class FrameBuffer:
    """Paces :class:`MediaBundle` emission from bursty model output to
    smooth, rate-controlled delivery on a dedicated thread.

    **External API** (consumed by :mod:`runtime_api` and
    :class:`ReactorContext`):

    * ``__init__(callback, maxsize, fps_debuff_factor)``
    * ``set_fixed_rate(fps)``
    * ``push(media_bundle)``
    * ``enable_monitoring()`` / ``disable_monitoring()``
    * ``start_emission()`` / ``stop_emission()``
    * ``clear()``
    * ``is_monitoring_active()``
    * ``estimated_fps()``
    """

    # -----------------------------------------------------------------
    # Construction
    # -----------------------------------------------------------------

    def __init__(
        self,
        callback: Callable[[MediaBundle, bool], None],
        maxsize: int = 50,
        fps_debuff_factor: float = 1.0,
    ) -> None:
        """
        Args:
            callback: Invoked on the emission thread with
                ``(media_bundle, is_duplicate)``.
            maxsize: Maximum number of single-frame bundles held in the
                internal queue.  When full, the oldest entries are
                silently dropped.
            fps_debuff_factor: Multiplier applied to the measured push
                FPS in auto mode (1.0 = no change).
        """
        self._callback = callback
        self._fps_debuff_factor = fps_debuff_factor

        # Internal frame queue.  ``collections.deque`` with *maxlen*
        # automatically discards the oldest (leftmost) entry on
        # overflow -- exactly the drop-oldest behaviour we want.
        self._q: collections.deque[MediaBundle] = collections.deque(maxlen=maxsize)
        self._q_lock = threading.Lock()

        # Push-rate measurement (auto mode).
        self._last_push_time: Optional[float] = None
        self._measured_fps: float = float(DEFAULT_FPS_GUESS)
        self._monitoring_active: bool = False

        # Fixed rate state.
        self._use_fixed_rate: bool = False
        self._fixed_fps: float = 0.0

        # Emission thread.
        self._emission_thread: Optional[threading.Thread] = None
        self._emission_running: bool = False
        self._emission_stop: threading.Event = threading.Event()
        self._emission_lock: threading.Lock = threading.Lock()

        # Duplicate / black-frame support.
        self._last_emitted: Optional[MediaBundle] = None
        self._frame_dims: Optional[tuple[int, int, int]] = None

        # Audio rate cache (populated from first bundle that carries
        # audio TrackInfo).
        self._audio_rate: float = 0.0

        # Diagnostics.
        self._cycle_count: int = 0

        # Optional metrics (same pattern as the old implementation).
        try:
            from reactor_runtime.runtimes._redis.reactor_machine_metrics import (
                ReactorMachineMetrics,
            )

            self._metrics = ReactorMachineMetrics
        except ImportError:
            self._metrics = None

        logger.info(
            "FrameBuffer initialized",
            maxsize=maxsize,
            fps_debuff_factor=fps_debuff_factor,
        )

    # -----------------------------------------------------------------
    # Fixed rate configuration
    # -----------------------------------------------------------------

    def set_fixed_rate(self, fps: float) -> None:
        """Lock the emission loop to a fixed FPS.

        Called by ``configure_media(fixed_rate=True)`` with the video
        track's declared rate.  The emission loop will use this value
        instead of the adaptive push-rate estimate.
        """
        self._use_fixed_rate = True
        self._fixed_fps = fps
        logger.info("FrameBuffer: fixed rate set", fps=fps)

    # -----------------------------------------------------------------
    # Monitoring lifecycle
    # -----------------------------------------------------------------

    def enable_monitoring(self) -> None:
        """Enable push-rate monitoring.

        Records a timing baseline so the first :meth:`push` can compute
        an interval.  Call this when the model starts (or resumes)
        emitting.

        **No-op in fixed rate mode** -- the emission FPS is already
        known and push timing is not needed.
        """
        if self._use_fixed_rate:
            return
        if not self._monitoring_active:
            self._monitoring_active = True
            self._last_push_time = time.perf_counter()

    def disable_monitoring(self) -> None:
        """Disable monitoring and drain stale frames.

        Any queued frames are discarded so they don't play back on the
        next resume (which would cause a delay / audio desync).

        **No-op in fixed rate mode** -- draining the queue would
        discard frames that the fixed-rate emission loop should still
        deliver.
        """
        if self._use_fixed_rate:
            return
        self._monitoring_active = False
        self._last_push_time = None
        with self._q_lock:
            drained = len(self._q)
            self._q.clear()
        if drained:
            logger.debug("Drained stale frames on disable", count=drained)

    def is_monitoring_active(self) -> bool:
        return self._monitoring_active

    # -----------------------------------------------------------------
    # Push
    # -----------------------------------------------------------------

    def push(self, media_bundle: Optional[MediaBundle]) -> None:
        """Push a :class:`MediaBundle` into the buffer.

        Multi-frame video bundles (video data shaped ``(N, H, W, 3)``)
        are split into *N* individual single-frame bundles with audio
        divided proportionally.

        In **auto mode** the time since the previous push is used to
        update the emission FPS estimate.  In **fixed mode** push
        timing is not measured -- the declared FPS is used as-is.

        Pass ``None`` to signal a black frame (e.g. during loading).
        """
        if media_bundle is None:
            with self._q_lock:
                self._q.append(self._create_black_bundle())
            return

        # Cache the audio sample rate from track metadata.
        audio_tracks = media_bundle.get_tracks_by_kind(TrackKind.AUDIO)
        if audio_tracks:
            rate = audio_tracks[0].info.rate
            if rate > 0:
                self._audio_rate = rate

        # Split multi-frame bundles into individual frames.
        singles = self._split_bundle(media_bundle)
        n_frames = len(singles)

        # Auto mode: update measured FPS from push timing.
        if not self._use_fixed_rate and self._last_push_time is not None:
            dt = time.perf_counter() - self._last_push_time
            if dt > 0:
                with self._q_lock:
                    qsize = len(self._q)
                if qsize > 2:
                    # Queue backing up (initial ramp-up or burst).
                    # Boost FPS so the emission loop drains the excess
                    # within roughly one push interval.
                    self._measured_fps = (n_frames + qsize - 1) / dt
                else:
                    self._measured_fps = (n_frames / dt) * self._fps_debuff_factor
                logger.debug(
                    "Push timing",
                    dt_ms=round(dt * 1000, 1),
                    n_frames=n_frames,
                    qsize=qsize,
                    measured_fps=round(self._measured_fps, 1),
                )

        self._last_push_time = time.perf_counter()

        # Enqueue.  deque(maxlen) auto-drops oldest on overflow.
        with self._q_lock:
            for bundle in singles:
                self._q.append(bundle)

    # -----------------------------------------------------------------
    # Bundle splitting
    # -----------------------------------------------------------------

    @staticmethod
    def _split_bundle(media_bundle: MediaBundle) -> List[MediaBundle]:
        """Split a multi-video-frame bundle into single-frame bundles.

        Audio samples are divided evenly across the resulting bundles.
        If the bundle contains only one video frame (the common case),
        it is returned as-is with no copying.
        """
        video_tracks = media_bundle.get_tracks_by_kind(TrackKind.VIDEO)

        n_video = 1
        video_td: Optional[TrackData] = None
        if video_tracks:
            video_td = video_tracks[0]
            if video_td.data.ndim == 4:
                n_video = video_td.data.shape[0]

        # Fast path: single frame (or no video) -- return as-is.
        if n_video <= 1:
            return [media_bundle]

        assert video_td is not None
        video_frames = list(video_td.data)  # N x (H, W, 3)

        # Split audio evenly across video frames.
        audio_tracks = media_bundle.get_tracks_by_kind(TrackKind.AUDIO)
        audio_chunks: Optional[List[np.ndarray]] = None
        audio_info: Optional[TrackInfo] = None
        if audio_tracks:
            audio_td = audio_tracks[0]
            audio_info = audio_td.info
            audio = audio_td.data
            if audio.ndim == 1:
                audio = audio.reshape(1, -1)
            total_samples = audio.shape[1]
            per = total_samples // n_video
            audio_chunks = []
            for i in range(n_video):
                start = i * per
                end = start + per if i < n_video - 1 else total_samples
                audio_chunks.append(audio[:, start:end])

        # Build individual bundles.
        result: List[MediaBundle] = []
        for i in range(n_video):
            tracks = {
                video_td.info.name: TrackData(info=video_td.info, data=video_frames[i])
            }
            if audio_chunks is not None and audio_info is not None:
                tracks[audio_info.name] = TrackData(
                    info=audio_info, data=audio_chunks[i]
                )
            result.append(MediaBundle(tracks=tracks))
        return result

    # -----------------------------------------------------------------
    # Accessors / diagnostics
    # -----------------------------------------------------------------

    def estimated_fps(self) -> float:
        """Return the current emission FPS (for diagnostics).

        In fixed mode this is the declared rate.  In auto mode it is
        the most recent push-rate measurement.
        """
        if self._use_fixed_rate and self._fixed_fps > 0:
            return self._fixed_fps
        return (
            self._measured_fps if self._measured_fps > 0 else float(DEFAULT_FPS_GUESS)
        )

    # -----------------------------------------------------------------
    # Emission lifecycle
    # -----------------------------------------------------------------

    def start_emission(self) -> None:
        """Start the emission thread.  Thread-safe."""
        with self._emission_lock:
            if self._emission_running:
                logger.warning("Emission already running, ignoring start_emission")
                return

            self._emission_running = True
            self._emission_stop.clear()
            self._emission_thread = threading.Thread(
                target=self._emission_loop, daemon=True
            )
            self._emission_thread.start()
            logger.info("Emission started")

    def stop_emission(self) -> None:
        """Stop the emission thread.  Thread-safe."""
        with self._emission_lock:
            if not self._emission_running:
                return
            self._emission_stop.set()
            thread = self._emission_thread
            self._emission_thread = None
            self._emission_running = False
            if thread:
                thread.join(timeout=1.0)
        logger.info("Emission stopped")

    def clear(self) -> None:
        """Reset all state for a clean session start."""
        self._last_emitted = None
        self._last_push_time = None
        self._monitoring_active = False
        self._use_fixed_rate = False
        self._fixed_fps = 0.0
        self._audio_rate = 0.0
        self._measured_fps = float(DEFAULT_FPS_GUESS)
        self._frame_dims = None
        self._cycle_count = 0
        with self._q_lock:
            self._q.clear()

    # -----------------------------------------------------------------
    # Black frame helper
    # -----------------------------------------------------------------

    def _create_black_bundle(self) -> MediaBundle:
        """Create a black-frame bundle using cached or default dims."""
        dims = self._frame_dims or DEFAULT_FRAME_DIMENSIONS
        return MediaBundle.from_video_frame(np.zeros(dims, dtype=np.uint8))

    # -----------------------------------------------------------------
    # Precise sleep
    # -----------------------------------------------------------------

    def _sleep_until(self, deadline: float) -> None:
        """Sleep until *deadline* (``time.perf_counter`` epoch).

        Uses ``time.sleep`` for the bulk of the wait and a spin-wait
        for the final 2 ms to achieve < 1 ms jitter.  This avoids the
        10-15 ms granularity of ``threading.Event.wait`` /
        ``Queue.get(timeout=)`` on macOS.

        Checks ``_emission_stop`` each coarse-sleep iteration so the
        loop can exit promptly when the buffer is stopped.
        """
        while True:
            remaining = deadline - time.perf_counter()
            if remaining <= 0:
                return
            if self._emission_stop.is_set():
                return
            if remaining > 0.002:
                time.sleep(remaining - 0.002)

    # -----------------------------------------------------------------
    # Audio resampling
    # -----------------------------------------------------------------

    @staticmethod
    def _resample_audio(
        bundle: MediaBundle, emission_fps: float, audio_rate: float
    ) -> MediaBundle:
        """Resample audio tracks so each frame delivers exactly
        ``round(audio_rate / emission_fps)`` samples.

        This ensures the transport receives exactly ``audio_rate``
        samples/sec regardless of the emission FPS.  When the model
        runs at exactly the content FPS, target == actual and no
        resampling occurs (zero overhead).

        Returns a new ``MediaBundle`` with resampled audio tracks.
        Non-audio tracks pass through unchanged.
        """
        if emission_fps <= 0 or audio_rate <= 0:
            return bundle

        target_samples = round(audio_rate / emission_fps)
        if target_samples <= 0:
            return bundle

        new_tracks = dict(bundle.tracks)
        changed = False

        for name, td in bundle.tracks.items():
            if td.info.kind != TrackKind.AUDIO:
                continue

            audio = td.data
            if audio.ndim == 1:
                audio = audio.reshape(1, -1)

            actual = audio.shape[1]
            if actual == 0 or actual == target_samples:
                continue

            # Linear interpolation: stretch or compress to target.
            # Only channel 0 — audio is always mono (Opus 48 kHz, 1 ch).
            x_old = np.linspace(0, 1, actual)
            x_new = np.linspace(0, 1, target_samples)
            resampled = np.interp(x_new, x_old, audio[0].astype(np.float32))
            new_tracks[name] = TrackData(
                info=td.info,
                data=resampled.astype(np.int16).reshape(1, -1),
            )
            changed = True

        return MediaBundle(tracks=new_tracks) if changed else bundle

    # -----------------------------------------------------------------
    # Emission loop
    # -----------------------------------------------------------------

    def _emission_loop(self) -> None:
        """Emission loop running on a dedicated daemon thread.

        Each cycle:

        1. Determine the emission FPS -- fixed or measured.
        2. Dequeue one single-frame bundle (or emit a duplicate).
        3. Resample audio to match the emission interval.
        4. Fire the callback.
        5. Precise-sleep until the next tick.

        The next tick is always scheduled relative to *now* (not
        accumulated) to prevent burst emission after a slow callback.
        """
        while not self._emission_stop.is_set():
            # --- Determine FPS ---
            if self._use_fixed_rate and self._fixed_fps > 0:
                fps = self._fixed_fps
            else:
                fps = (
                    self._measured_fps
                    if self._measured_fps > 0
                    else float(DEFAULT_FPS_GUESS)
                )

            interval = 1.0 / fps
            self._cycle_count += 1

            # --- Periodic diagnostics ---
            if self._cycle_count <= 3 or self._cycle_count % 500 == 0:
                with self._q_lock:
                    qsize = len(self._q)

                logger.debug(
                    "Emission",
                    fps=round(fps, 1),
                    mode="fixed" if self._use_fixed_rate else "auto",
                    push_fps=round(self._measured_fps, 1),
                    qsize=qsize,
                )

            if self._metrics:
                self._metrics.set_fps(fps)

            # --- Dequeue ---
            bundle: Optional[MediaBundle] = None
            with self._q_lock:
                if self._q:
                    bundle = self._q.popleft()

            if bundle is not None:
                # Cache video dimensions for black-frame fallback.
                vtracks = bundle.get_tracks_by_kind(TrackKind.VIDEO)
                if vtracks:
                    vd = vtracks[0].data
                    if vd.ndim == 3:
                        self._frame_dims = (
                            vd.shape[0],
                            vd.shape[1],
                            vd.shape[2],
                        )

                self._last_emitted = bundle

                if self._audio_rate > 0 and not self._use_fixed_rate:
                    bundle = self._resample_audio(bundle, fps, self._audio_rate)

                self._callback(bundle, False)

            else:
                # Queue empty: re-emit the last video frame as a
                # duplicate.  No audio is pushed to avoid waveform
                # discontinuities (clicks) in the jitter buffer.  The
                # OutputAudioTrack's internal buffer absorbs brief gaps.
                if self._emission_stop.is_set():
                    break
                if self._last_emitted is not None:
                    self._callback(self._last_emitted.video_only(), True)
                else:
                    self._callback(self._create_black_bundle(), True)

            # --- Precise sleep until next tick ---
            next_tick = time.perf_counter() + interval
            self._sleep_until(next_tick)
