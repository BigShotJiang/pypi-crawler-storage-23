from __future__ import annotations

from dataclasses import dataclass, field
import threading
from typing import TYPE_CHECKING, Any, Callable, Dict, List, Optional

from reactor_runtime.output.media_accumulator import BucketAccumulator
from reactor_runtime.profiling.profiler import NoOpProfiler, Profiler
from reactor_runtime.profiling.backends.file import FileProfilerBackend
from reactor_runtime.profiling.backends.otlp import OTLPProfilerBackend
from reactor_runtime.transports.media import MediaBundle, TrackDirection
from reactor_runtime.tracks import (
    Track,
    OutputTrack,
    InputTrack,
)
from reactor_runtime.registry import MODEL_REGISTRY
from reactor_runtime.model_api import _resolve_default_track
from reactor_runtime.utils.log import get_logger

if TYPE_CHECKING:
    from reactor_runtime.profiling.profiler import ProfilerType

logger = get_logger(__name__)


@dataclass
class ReactorContext:
    """
    Session-scoped context passed to the model.
    """

    _send_fn: Callable[[dict], None]
    _push_to_framebuffer_fn: Callable[[Optional[MediaBundle]], None]
    _enable_monitoring_fn: Callable[[], None]
    _disable_monitoring_fn: Callable[[], None]
    _set_fixed_rate_fn: Callable[[float], None] = lambda _: None
    _stop_evt: Optional[threading.Event] = None

    # Multi-track media accumulator (created by _configure_from_registry)
    _accumulator: Optional[BucketAccumulator] = field(default=None, init=False)

    # Track registry — populated by _configure_from_registry()
    _tracks: Dict[str, Track] = field(default_factory=dict, init=False)
    _default_track: Optional[Track] = field(default=None, init=False)

    # Profiling configuration (used to build profiler in __post_init__)
    _enable_file_profiling: bool = False
    _profiling_output_dir: str = "./profiling"

    # Profiler instance (built in __post_init__, NoOpProfiler if profiling is disabled)
    _profiler: Any = field(default=None, init=False)

    def __post_init__(self) -> None:
        """Build the session profiler based on configuration."""
        self._profiler = self._build_profiler()

    def _build_profiler(self) -> Any:
        """
        Build a new profiler instance for this session.

        Backend selection priority:
        1. OTLP backend if ReactorMachineMetrics is available and enabled
        2. File backend if _enable_file_profiling is True
        3. NoOpProfiler (profiling disabled)

        Returns:
            Profiler instance or NoOpProfiler if profiling is disabled.
        """
        # Try OTLP backend first (production environment)
        try:
            from reactor_runtime.runtimes._redis.reactor_machine_metrics import (
                ReactorMachineMetrics,
            )

            if ReactorMachineMetrics.is_enabled():
                logger.info("Session profiler initialized with OTLP backend")
                return Profiler(OTLPProfilerBackend())
        except Exception as e:
            logger.debug("OTLP backend unavailable", error=e)

        # Fall back to file backend if enabled
        if self._enable_file_profiling:
            try:
                logger.info(
                    "Session profiler initialized with file backend",
                    output_dir=self._profiling_output_dir,
                )
                return Profiler(FileProfilerBackend(self._profiling_output_dir))
            except Exception as e:
                logger.warning("File profiler backend initialization failed", error=e)

        # Profiling disabled or all backends failed
        return NoOpProfiler()

    def should_stop(self) -> bool:
        """
        Check if the session has been signaled to stop.
        Returns True if the stop event is set, False otherwise.
        """
        if self._stop_evt is None:
            return False
        return self._stop_evt.is_set()

    def send(self, data: dict) -> None:
        """
        Send a payload from the model to the frontend.
        Runtime wraps this into an ApplicationMessage envelope before sending.
        """
        self._send_fn(data)

    @property
    def is_media_configured(self) -> bool:
        """``True`` if media emission has been configured for this session."""
        return self._accumulator is not None

    def get_track(self, name: Optional[str] = None) -> Track:
        """Return a track descriptor by name, or the default track.

        Args:
            name: Track name (must match a class-attribute name on the
                model).  When ``None``, returns the default track.

        Raises:
            RuntimeError: If *name* is not declared or no default track
                exists.
        """
        if name is None:
            if self._default_track is None:
                raise RuntimeError(
                    "No default track configured. "
                    "Pass an explicit track name to get_track()."
                )
            return self._default_track
        track = self._tracks.get(name)
        if track is None:
            raise RuntimeError(
                f"Track '{name}' is not declared on this model. "
                f"Available tracks: {list(self._tracks.keys())}"
            )
        return track

    def _configure_from_registry(self, model_cls: type) -> None:
        """Read track declarations from ``MODEL_REGISTRY`` and wire them.

        Args:
            model_cls: The concrete :class:`VideoModel` subclass whose
                registry entry should be used.  Ensures the correct
                tracks are loaded even when multiple models are
                registered (e.g. in tests).

        Called once by the runtime during session setup.  Populates
        ``_tracks``, ``_default_track``, and creates the
        :class:`BucketAccumulator` for output tracks.
        """
        # TODO(REA-856): In the future, allow models to call a configure
        # method to override these defaults at runtime.
        model_info: Dict[str, Any] = next(
            (v for v in MODEL_REGISTRY.values() if v["class"] is model_cls), {}
        )
        tracks: List[Track] = model_info.get("tracks", [])
        emission_fps: Optional[float] = model_info.get("emission_fps", None)

        # Reset all tracks from any previous session
        for t in tracks:
            t._reset()

        # Populate the context's track registry
        self._tracks = {t.name: t for t in tracks}
        self._default_track = _resolve_default_track(tracks)

        # Filter to output tracks for the accumulator
        output_tracks = [t for t in tracks if t.direction == TrackDirection.OUT]

        output_track_infos = [t.to_info() for t in output_tracks]

        def _default_bucket_predicate(bucket: dict) -> bool:
            return all(t.name in bucket for t in output_tracks)

        self._accumulator = BucketAccumulator(
            track_configs=output_track_infos,
            is_complete=_default_bucket_predicate,
            on_complete=self._push_to_framebuffer_fn,
        )

        # Wire output tracks to the accumulator's push method
        for t in output_tracks:
            if isinstance(t, OutputTrack):
                t._wire(self._accumulator.push)

        if emission_fps is not None and emission_fps > 0:
            self._set_fixed_rate_fn(emission_fps)

        logger.info(
            "Configured tracks from class attributes",
            all_tracks=list(self._tracks.keys()),
            output_tracks=[t.name for t in output_tracks],
            default_track=(self._default_track.name if self._default_track else None),
            emission_fps=emission_fps,
        )

    def _update_input_tracks(self, bundle: MediaBundle) -> None:
        """Auto-update input track descriptors from an inbound bundle.

        Called by ``VideoModel._dispatch_media`` so that
        ``get_track("webcam").latest()`` stays current.

        The bundle's track names are MID-derived and match the model's
        declared attribute names directly (e.g. ``"webcam"``).
        """
        for track_name, td in bundle.tracks.items():
            target = self._tracks.get(track_name)
            if target is not None and isinstance(target, InputTrack):
                target._update(td.data)

    def enable_monitoring(self) -> None:
        """
        Enable frame monitoring mode for performance tracking.
        """
        self._enable_monitoring_fn()

    def disable_monitoring(self) -> None:
        """
        Disable frame monitoring mode for performance tracking.
        """
        self._disable_monitoring_fn()

    def profiler(self) -> "ProfilerType":
        """
        Get the profiler for measuring code section durations.

        Returns a profiler instance that can be used to measure timing of code sections:

            with get_ctx().profiler().section("inference"):
                with get_ctx().profiler().section("preprocess"):
                    ...

        If profiling is not enabled, returns a no-op profiler that adds no overhead.

        Returns:
            Profiler instance or NoOpProfiler if profiling is disabled.
        """
        return self._profiler


ctx: Optional[ReactorContext] = None


def get_ctx() -> ReactorContext:
    """Get the current global context. Raises if not set."""
    if ctx is None:
        raise RuntimeError(
            "Global context not set. This should only be called during an active session."
        )
    return ctx


def _set_global_ctx(context: ReactorContext):
    global ctx
    ctx = context
