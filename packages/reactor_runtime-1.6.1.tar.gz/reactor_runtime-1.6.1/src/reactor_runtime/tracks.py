# Copyright (c) 2026 Reactor Technologies, Inc. All rights reserved.
"""
Track descriptor classes for declaring media tracks as class attributes.

Models declare their media topology using typed descriptors on the class
body.  The ``@model()`` decorator scans for these attributes at
registration time, infers names from the Python variable name, and stores
the topology in ``MODEL_REGISTRY``.

At session startup the runtime wires each output track to the
:class:`BucketAccumulator` so that ``track.emit()`` pushes data into the
emission pipeline.

Typical usage::

    from reactor_runtime import VideoModel, model, get_ctx
    from reactor_runtime.tracks import VideoOut, AudioOut

    @model(name="my-model")
    class MyModel(VideoModel):
        main_video = VideoOut(default=True)
        main_audio = AudioOut(rate=48000.0)

        def start_session(self):
            ctx = get_ctx()
            idx = 0
            while not ctx.should_stop():
                ctx.get_track("main_video").emit(frame, bucket=idx)
                ctx.get_track("main_audio").emit(audio, bucket=idx)
                idx += 1
"""

from __future__ import annotations

import threading
from typing import Callable, Optional

import numpy as np

from reactor_runtime.transports.media import TrackDirection, TrackInfo, TrackKind

# ---------------------------------------------------------------------------
# Defaults
# ---------------------------------------------------------------------------

_DEFAULT_VIDEO_DIMENSIONS: tuple[int, int, int] = (720, 1280, 3)
_DEFAULT_AUDIO_SAMPLE_RATE: int = 48_000

# ---------------------------------------------------------------------------
# Base Track
# ---------------------------------------------------------------------------


class Track:
    """Base descriptor for a media track declared as a class attribute.

    Stores track metadata (kind, direction, rate, default) and the
    latest data seen on the track.  Subclasses add emission
    (:class:`OutputTrack`) or inbound update (:class:`InputTrack`)
    capabilities.

    **Direction is always from the model's perspective:**

    * ``OUT`` — model → client (the model sends data).
    * ``IN``  — client → model (the model receives data).

    ``latest()`` is available on **all** track types and returns a
    **reference** to the most recent data (not a copy):

    * On output tracks (``OUT``) — the last frame emitted via ``emit()``.
    * On input tracks  (``IN``)  — the last frame received from the client.

    The returned array is shared with the track's internal storage.
    Mutating it in-place will affect subsequent ``latest()`` calls
    until the next ``emit()`` or inbound update replaces it.
    """

    def __init__(
        self,
        kind: TrackKind,
        direction: TrackDirection,
        rate: float = 0.0,
        default: bool = False,
    ) -> None:
        self._kind = kind
        self._direction = direction
        self._rate = rate
        self._default = default
        self._name: str = ""
        self._latest_data: Optional[np.ndarray] = None
        self._data_lock = threading.Lock()

    # -- read-only properties -----------------------------------------------

    @property
    def name(self) -> str:
        return self._name

    @property
    def kind(self) -> TrackKind:
        return self._kind

    @property
    def direction(self) -> TrackDirection:
        return self._direction

    @property
    def rate(self) -> float:
        return self._rate

    @property
    def default(self) -> bool:
        return self._default

    # -- public API ---------------------------------------------------------

    def latest(self) -> Optional[np.ndarray]:
        """Return the last data on this track, or ``None``."""
        with self._data_lock:
            return self._latest_data

    def emit(
        self, frame: Optional[np.ndarray] = None, bucket: Optional[int] = None
    ) -> None:
        """Emit data on this track.

        Only :class:`OutputTrack` subclasses support this method.
        Calling it on an input track raises :class:`TypeError`.

        Passing ``None`` emits a black frame (video) or silence (audio)
        using default dimensions / sample rate.
        """
        raise TypeError(
            f"Track '{self._name}' (direction={self._direction.value}) "
            "does not support emit(). "
            "Only output tracks (OUT) can emit."
        )

    # -- internal -----------------------------------------------------------

    def _set_latest(self, data: np.ndarray) -> None:
        with self._data_lock:
            self._latest_data = data

    def _update(self, data: np.ndarray) -> None:
        """Called by the runtime when inbound data arrives from the client."""
        raise TypeError(
            f"Track '{self._name}' (direction={self._direction.value}) "
            "does not support inbound updates."
        )

    def to_info(self) -> TrackInfo:
        """Convert to a :class:`TrackInfo` for internal pipeline use."""
        return TrackInfo(
            name=self._name,
            kind=self._kind,
            rate=self._rate,
            direction=self._direction,
        )

    def _reset(self) -> None:
        """Reset per-session state.  Called between sessions."""
        with self._data_lock:
            self._latest_data = None

    def __repr__(self) -> str:
        return (
            f"{type(self).__name__}("
            f"name={self._name!r}, kind={self._kind.value!r}, "
            f"direction={self._direction.value!r}, rate={self._rate}, "
            f"default={self._default})"
        )


# ---------------------------------------------------------------------------
# OutputTrack
# ---------------------------------------------------------------------------


class OutputTrack(Track):
    """Track that sends data from the model to the client (direction ``OUT``).

    Data flows **model → client**.  The ``emit()`` method pushes data
    into the :class:`BucketAccumulator`, which forwards completed
    bundles to the :class:`FrameBuffer` and ultimately to the WebRTC
    transport.

    The track is wired to the accumulator at session startup by the
    runtime (via ``_wire``).

    Each track maintains an independent auto-counter for bucket indexing
    when ``bucket=None`` is passed to ``emit()``.
    """

    def __init__(
        self,
        kind: TrackKind,
        direction: TrackDirection = TrackDirection.OUT,
        rate: float = 0.0,
        default: bool = False,
    ) -> None:
        super().__init__(kind=kind, direction=direction, rate=rate, default=default)
        self._push_fn: Optional[Callable[..., None]] = None
        self._auto_counter: int = 0
        self._counter_lock = threading.Lock()

    def emit(
        self, frame: Optional[np.ndarray] = None, bucket: Optional[int] = None
    ) -> None:
        """Emit media data on this track.

        Every emission passes through the :class:`BucketAccumulator`.
        A bucket is complete when **all** declared output tracks have
        contributed data for that index; only then is the bundle
        forwarded to the :class:`FrameBuffer`.

        Passing ``None`` as *frame* emits a **black frame** (video) or
        **silence** (audio) using default dimensions / sample rate.
        The synthesised array is a real ``np.ndarray`` that flows
        through the entire pipeline normally — ``None`` never
        propagates past this method.

        Args:
            frame: The media data to emit, or ``None`` for a black /
                silent placeholder.
                Video: ``(H, W, 3)`` uint8 or ``(N, H, W, 3)`` batch.
                Audio: ``(1, M)`` int16 or ``(1, N*M)`` batch.
            bucket: Bucket index for synchronised multi-track emission.
                When ``None``, a per-track auto-counter (starting at 0)
                is used.

        .. warning:: **Auto-counter pitfall.**

           Omitting *bucket* assumes every output track emits exactly
           once per step in lockstep.  Each track maintains its own
           independent counter, so if any track conditionally skips an
           ``emit()`` call, the per-track counters desync permanently
           and buckets stop completing — data is silently lost.

           When tracks emit conditionally or at different rates, always
           pass an explicit *bucket* index.
        """
        push_fn = self._push_fn
        if push_fn is None:
            raise RuntimeError(
                f"Track '{self._name}' is not wired to a session. "
                "Ensure emit() is called during an active session."
            )
        if frame is None:
            frame = self._synthesize_blank()
        if bucket is None:
            with self._counter_lock:
                bucket = self._auto_counter
                self._auto_counter += 1
        push_fn(bucket, self._name, frame)
        self._set_latest(frame)

    def _synthesize_blank(self) -> np.ndarray:
        """Create a blank (black / silent) frame for this track's kind."""
        if self._kind == TrackKind.VIDEO:
            return np.zeros(_DEFAULT_VIDEO_DIMENSIONS, dtype=np.uint8)
        if self._kind == TrackKind.AUDIO:
            rate = self._rate if self._rate > 0 else _DEFAULT_AUDIO_SAMPLE_RATE
            return np.zeros((1, round(rate)), dtype=np.int16)
        raise NotImplementedError(
            f"_synthesize_blank is not implemented for kind={self._kind!r}"
        )

    def _wire(self, push_fn: Callable[..., None]) -> None:
        """Connect this track to the accumulator for the current session."""
        self._push_fn = push_fn

    def _reset(self) -> None:
        super()._reset()
        self._push_fn = None
        with self._counter_lock:
            self._auto_counter = 0


# ---------------------------------------------------------------------------
# InputTrack
# ---------------------------------------------------------------------------


class InputTrack(Track):
    """Track that receives data from the client (direction ``IN``).

    Data flows **client → model**.  The runtime auto-updates the track's
    latest data when new media arrives from the client.  The model reads
    the most recent frame via ``latest()``, which returns a reference
    to the stored array (not a copy).
    """

    def __init__(
        self,
        kind: TrackKind,
        direction: TrackDirection = TrackDirection.IN,
        rate: float = 0.0,
        default: bool = False,
    ) -> None:
        super().__init__(kind=kind, direction=direction, rate=rate, default=default)

    def _update(self, data: np.ndarray) -> None:
        self._set_latest(data)


# ---------------------------------------------------------------------------
# Convenience subclasses
# ---------------------------------------------------------------------------


class VideoOut(OutputTrack):
    """Output video track (model → client).  Shorthand for ``OutputTrack(kind=VIDEO, direction=OUT)``.

    When *rate* is ``0.0`` (the default) the FrameBuffer uses **auto
    mode** — emission FPS adapts to the model's push rate.  Set a
    positive rate (e.g. ``30.0``) to lock emission to a fixed FPS.
    """

    def __init__(self, rate: float = 0.0, default: bool = False) -> None:
        super().__init__(
            kind=TrackKind.VIDEO,
            direction=TrackDirection.OUT,
            rate=rate,
            default=default,
        )


class AudioOut(OutputTrack):
    """Output audio track (model → client).  Shorthand for ``OutputTrack(kind=AUDIO, direction=OUT)``."""

    def __init__(self, rate: float = 48000.0, default: bool = False) -> None:
        super().__init__(
            kind=TrackKind.AUDIO,
            direction=TrackDirection.OUT,
            rate=rate,
            default=default,
        )


class VideoIn(InputTrack):
    """Input video track (client → model).  Shorthand for ``InputTrack(kind=VIDEO, direction=IN)``."""

    def __init__(self, rate: float = 0.0, default: bool = False) -> None:
        super().__init__(
            kind=TrackKind.VIDEO,
            direction=TrackDirection.IN,
            rate=rate,
            default=default,
        )


class AudioIn(InputTrack):
    """Input audio track (client → model).  Shorthand for ``InputTrack(kind=AUDIO, direction=IN)``."""

    def __init__(self, rate: float = 0.0, default: bool = False) -> None:
        super().__init__(
            kind=TrackKind.AUDIO,
            direction=TrackDirection.IN,
            rate=rate,
            default=default,
        )
