import argparse
import asyncio
from functools import partial
import json
from dataclasses import dataclass, field
from enum import Enum
import signal

from abc import ABC, abstractmethod
import os
import threading
from typing import Optional

from omegaconf import DictConfig
from reactor_runtime import VideoModel
from reactor_runtime.context_api import ReactorContext
from reactor_runtime.model_state import ModelEvent, ModelState, ModelStateMachine
from reactor_runtime.output.frame_buffer import FrameBuffer
from reactor_runtime.transports.media import MediaBundle
from reactor_runtime.utils.loader import build_model
from reactor_runtime.utils.messages import (
    ApplicationMessage,
    RuntimeMessage,
    RuntimeMessageType,
)

from reactor_runtime.context_api import _set_global_ctx
from reactor_runtime import context_api
from reactor_runtime.utils.log import get_logger
import uuid

logger = get_logger(__name__)


class State(Enum):
    """Runtime state enumeration."""

    LOADING = "loading"
    IDLE = "idle"
    RUNNING = "running"
    RESETTING = "resetting"
    ERROR = "error"


# Environment variable and default for idling interval
_IDLING_INTERVAL_ENV_VAR = "IDLING_INTERVAL_SECONDS"
_DEFAULT_IDLING_INTERVAL = 30.0

# Environment variable for max session duration
_MAX_SESSION_DURATION_ENV_VAR = "MAX_SESSION_DURATION_SECONDS"


@dataclass
class RuntimeConfig:
    """
    Base configuration for all runtime implementations.

    Contains the configuration that gets passed to the runtime constructor.
    Each runtime implementation should extend this with additional fields.
    """

    model_name: str
    model_args: DictConfig
    model_spec: str

    # node_id depends on other fields, so it must be built in __post_init__
    node_id: str = field(init=False)
    machine_id: str = field(init=False)

    orphan_timeout: float = (
        30.0  # Seconds to wait before stopping session when WebRTC disconnects
    )

    # Idling interval in seconds for sending IDLING events when in READY state
    # Priority: ENV > CLI > default. Set to None to use default.
    idling_interval: float | None = None

    # Maximum session duration in seconds. If set, sessions will be automatically
    # stopped after this duration. Priority: ENV > CLI. Set to None to disable.
    max_session_duration: float | None = None

    # Profiling configuration
    enable_profiling: bool = (
        False  # Enable file-based profiling output (when OTLP is unavailable)
    )
    profiling_output_dir: str = "./profiling"  # Directory for profiling output files

    def __post_init__(self):
        """Build node_id from model name and machine identifier."""
        self.machine_id = os.getenv("HOSTNAME", str(uuid.uuid4()))
        self.node_id = f"{self.model_name}@{self.machine_id}"

        # Resolve idling_interval: ENV > CLI > default
        env_val = os.getenv(_IDLING_INTERVAL_ENV_VAR)
        if env_val:
            try:
                self.idling_interval = float(env_val)
            except ValueError:
                logger.warning(
                    "Invalid idling interval env value, falling back to CLI or default",
                    env_var=_IDLING_INTERVAL_ENV_VAR,
                    value=env_val,
                )

        # Validate positive value, fall back to default if invalid
        if self.idling_interval is not None and self.idling_interval <= 0:
            logger.warning(
                "Idling interval must be positive, using default",
                idling_interval=self.idling_interval,
                default=f"{_DEFAULT_IDLING_INTERVAL}s",
            )
            self.idling_interval = None

        # Apply default if still None
        if self.idling_interval is None:
            self.idling_interval = _DEFAULT_IDLING_INTERVAL

        # Resolve max_session_duration: ENV > CLI (no default - disabled if not set)
        max_duration_env = os.getenv(_MAX_SESSION_DURATION_ENV_VAR)
        if max_duration_env:
            try:
                self.max_session_duration = float(max_duration_env)
            except ValueError:
                logger.warning(
                    "Invalid max session duration env value, falling back to CLI value or disabled",
                    env_var=_MAX_SESSION_DURATION_ENV_VAR,
                    value=max_duration_env,
                )

        # Validate positive value if set
        if self.max_session_duration is not None and self.max_session_duration <= 0:
            logger.warning(
                "Max session duration must be positive, disabling",
                max_session_duration=self.max_session_duration,
            )
            self.max_session_duration = None

    @staticmethod
    def parser() -> argparse.ArgumentParser:
        """
        Return an argument parser for runtime-specific CLI arguments.

        The parsed args will be used to construct the config.

        Returns:
            argparse.ArgumentParser with runtime-specific arguments
        """
        parser = argparse.ArgumentParser(add_help=False)
        parser.add_argument(
            "--orphan-timeout",
            type=float,
            default=30.0,
            help="Seconds to wait before stopping session when no client connection is established. Default: 30.0. Set to 0 to disable.",
        )
        parser.add_argument(
            "--idling-interval",
            type=float,
            default=None,
            help=f"Interval in seconds for sending IDLING events when in READY state. "
            f"Can also be set via {_IDLING_INTERVAL_ENV_VAR} env var (takes precedence). "
            f"Default: {_DEFAULT_IDLING_INTERVAL}s",
        )
        parser.add_argument(
            "--max-session-duration",
            type=float,
            default=None,
            help=f"Maximum session duration in seconds. If set, sessions will be "
            f"automatically stopped after this duration. Can also be set via "
            f"{_MAX_SESSION_DURATION_ENV_VAR} env var (takes precedence). "
            f"Default: disabled (no maximum duration).",
        )
        parser.add_argument(
            "--enable-profiling",
            action="store_true",
            default=False,
            help="Enable file-based profiling output. When enabled, timing data is written to JSON files for later visualization. Default: False",
        )
        parser.add_argument(
            "--profiling-output-dir",
            type=str,
            default="./profiling",
            help="Directory for profiling output files. Default: ./profiling",
        )
        return parser


class Runtime(ModelStateMachine, ABC):
    def __init__(self, config: RuntimeConfig):
        """
        Initialize the runtime with a configuration object.

        Note: This does NOT load the model. Call `await load()` after construction
        to load the model asynchronously.

        Args:
            config: RuntimeConfig containing model information and runtime-specific settings.
        """
        super().__init__(ModelState.CREATED)
        self.config = config
        self.model_loaded = False
        self.model: VideoModel = None
        self.model_thread: Optional[threading.Thread] = None
        self.loop = asyncio.get_running_loop()
        self.frame_buffer = FrameBuffer(
            callback=self._send_out_app_bundle_sync,
            fps_debuff_factor=self.config.model_args.get("fps_debuff_factor", 1.0),
        )
        self.stop_evt = threading.Event()

        # Orphan timeout task - stops session if no client connection for too long
        self._orphan_task: Optional[asyncio.Task] = None

        # Idling task - sends periodic IDLING events when in READY state
        self._idling_task: Optional[asyncio.Task] = None

        # Max session duration task - stops session after configured duration
        self._max_session_duration_task: Optional[asyncio.Task] = None

        # Graceful shutdown state (for SIGTERM handling)
        self._shutdown_pending: bool = False
        self._shutdown_event: asyncio.Event = asyncio.Event()
        self._setup_signal_handlers()

        # Start idling loop (runs continuously, only sends events when in READY state)
        self._start_idling_loop()

    async def load(self) -> None:
        """
        Load the model asynchronously.

        Runs load_model() in a separate thread and waits for it to complete
        without blocking the event loop. Sends INITIALIZATION_SUCCESS or
        INITIALIZATION_FAIL event based on the result.

        Raises:
            Exception: Re-raises any exception from load_model() after sending
                       INITIALIZATION_FAIL event.
        """
        try:
            await asyncio.to_thread(self.load_model)
        except Exception as e:
            logger.critical("Failed to load model", exc_info=True, error=e)
            self.send(ModelEvent.INITIALIZATION_FAIL)
            raise

        self.send(ModelEvent.INITIALIZATION_SUCCESS)

    def load_model(self) -> None:
        self.model = build_model(self.config.model_spec, self.config.model_args)
        self.model_loaded = True
        logger.info(
            "Model loaded successfully and now available for inference",
            model=self.config.model_name,
        )

    def _send_out_app_message_sync(self, data: dict) -> None:
        wrapped = ApplicationMessage(data=data).model_dump()
        try:
            logger.info("Sending app message to client", data=wrapped)
            asyncio.run_coroutine_threadsafe(
                self.send_out_app_message(wrapped), self.loop
            )
        except Exception as e:
            logger.warning("Failed to send app message to client", error=e)

    def _build_context(self) -> None:
        """
        Build the context that hooks the model to the runtime. Defines the bindings for the functions that the model,
        when running, will be able to call. The model internally calls messages to emit frames and emit messages.
        """
        self.frame_buffer.clear()
        self.stop_evt = threading.Event()

        ctx = ReactorContext(
            _send_fn=self._send_out_app_message_sync,
            _push_to_framebuffer_fn=self.frame_buffer.push,
            _enable_monitoring_fn=self.frame_buffer.enable_monitoring,
            _disable_monitoring_fn=self.frame_buffer.disable_monitoring,
            _set_fixed_rate_fn=self.frame_buffer.set_fixed_rate,
            _stop_evt=self.stop_evt,
            _enable_file_profiling=self.config.enable_profiling,
            _profiling_output_dir=self.config.profiling_output_dir,
        )
        _set_global_ctx(ctx)

        ctx._configure_from_registry(type(self.model))

    def _send_out_app_bundle_sync(
        self, media_bundle: MediaBundle, duplicate: bool
    ) -> None:
        """Callback from the :class:`FrameBuffer` emission loop.

        Silently fails if the event loop is closed (expected during
        shutdown).

        When *duplicate* is ``True`` the bundle is a re-emission of the
        last frame (queue was empty, video-only).  We skip forwarding
        entirely: the video track already serves the last pushed frame,
        and pushing the same frame again only wastes event-loop time.

        Args:
            media_bundle: The :class:`MediaBundle` to send.
            duplicate: True if this is a re-emission of the last frame.
        """
        if duplicate:
            return

        if self.loop.is_closed():
            return
        try:
            asyncio.run_coroutine_threadsafe(
                self.send_out_app_bundle(media_bundle, duplicate), self.loop
            )
        except RuntimeError:
            pass

    def on_enter_STREAMING(self, previous_state: ModelState) -> None:
        """
        Start the model's start_session() in a separate thread. Also start emission on the frame buffer,
        and build the context that hooks the model to the runtime.

        When the model thread exits (cleanly or with error), internal cleanup is performed first,
        then the abstract on_model_exit() method is called for implementation-specific cleanup.

        State transition: IDLE/ERROR -> RUNNING

        Returns:
            True if session started successfully, False if not in IDLE or ERROR state.
        """
        self._cancel_orphan_timeout()

        # Start max session duration timeout when session begins streaming
        # Only start on fresh sessions (from WAITING), not on reconnections (from ORPHANED)
        if previous_state == ModelState.WAITING:
            self._start_max_session_duration_timeout()

        if previous_state != ModelState.WAITING:
            logger.warning(
                "Model thread already running, treating as a re-connection to already running session."
            )
            return

        # Reset stop event and build context
        self._build_context()

        self.frame_buffer.start_emission()

        def run_model() -> None:
            error: Optional[Exception] = None
            try:
                self.model.start_session()
            except Exception as e:
                logger.critical("Model error", exc_info=True, error=e)
                error = e
            finally:
                # This call is for the case in which the model:
                # - Exits with an error
                # - Exits on its own (not from an external stop request)
                if self.current_state != ModelState.CLOSING:
                    self.loop.call_soon_threadsafe(
                        partial(self.send, ModelEvent.STOP_SESSION, error=error)
                    )
                self._handle_model_thread_exit(error)

        self.model_thread = threading.Thread(
            target=run_model, daemon=False, name="model-session"
        )
        self.model_thread.start()
        logger.info("Model session started in background thread")

    def _handle_model_thread_exit(self, error: Optional[Exception]) -> None:
        """
        Internal handler called when the model thread exits.
        Performs internal cleanup first, then invokes the cleanup complete event.
        """

        # Perform internal cleanup
        self.frame_buffer.stop_emission()
        self.frame_buffer.clear()

        # Flush and shutdown session profiler (each session has its own profiler instance)
        if context_api.ctx is not None and context_api.ctx._profiler is not None:
            try:
                context_api.ctx._profiler.flush()
                context_api.ctx._profiler.shutdown()
                logger.info("Session profiler flushed and shutdown")
            except Exception as e:
                logger.warning("Failed to cleanup session profiler", error=e)

        # Clean up thread reference (don't join here - we may be called from the thread itself)
        if self.model_thread is not None and not self.model_thread.is_alive():
            self.model_thread = None

        logger.info("Session cleanup completed")

    def on_enter_ORPHANED(self, previous_state: ModelState) -> None:
        """
        Handler called when the session enters the ORPHANED state.
        Starts the orphan timeout.
        """
        self._start_orphan_timeout()

    def on_enter_WAITING(self, previous_state: ModelState) -> None:
        """
        Handler called when the session enters the WAITING state.
        Starts the orphan timeout.
        """
        self._start_orphan_timeout()

    def on_enter_READY(self, previous_state: ModelState) -> None:
        """
        Handler called when entering the READY state.
        If shutdown is pending (SIGTERM received), trigger the shutdown event.
        """
        if self._shutdown_pending:
            logger.info(
                "Reached READY state with shutdown pending, triggering shutdown"
            )
            self._shutdown_event.set()

    def on_enter_CLOSING(self, previous_state: ModelState) -> None:
        """
        Signals the model to stop, waits for the thread to exit,
        and performs cleanup.
        """
        # Cancel all session-related timeouts first to prevent TOCTOU races
        self._cancel_orphan_timeout()
        self._cancel_max_session_duration_timeout()

        # Signal model to stop
        self.stop_evt.set()

        # Wait for model thread to exit
        if self.model_thread is not None and self.model_thread.is_alive():
            # TODO(REA-156): Add safe timeout that handles case in which the thread hangs. This means manually calling cleanup if we kill the thread.
            logger.debug("Waiting for model thread to exit")
            self.model_thread.join()

            logger.debug("Model thread exited cleanly")

        self.loop.call_soon_threadsafe(self.send, ModelEvent.CLEANUP_COMPLETE)

    @abstractmethod
    async def send_out_app_message(self, data: ApplicationMessage) -> None:
        """
        Send an application message FROM the model TO the client.
        The message has already been wrapped in an ApplicationMessage envelope.
        This should be where the messages is sent out to the client.
        """
        pass

    @abstractmethod
    async def send_out_runtime_message(self, data: RuntimeMessage) -> None:
        """
        Send a runtime message FROM the runtime TO the client.
        The message has already been wrapped in a RuntimeMessage envelope.
        Used for platform-level responses (e.g., capabilities).
        """
        pass

    # ===============================
    # Common Data Channel Message Handler
    # ===============================

    async def _handle_incoming_data_channel_message(self, message: str) -> None:
        """
        Common handler for incoming data channel messages.
        Parses the outer envelope { scope: "application"|"runtime", data: {...} }
        and routes to the appropriate handler.

        Subclasses should call this from their data channel message event handler.
        """
        if not self.session_running:
            logger.warning("Received data channel message but no session running")
            return

        try:
            data = json.loads(message)
            scope = data.get("scope")
            inner = data.get("data", {})

            if scope == "runtime":
                await self._handle_runtime_message(inner)
            elif scope == "application":
                await self._handle_application_message(inner)
            else:
                logger.warning(
                    "Unknown envelope scope, treating as legacy application message",
                    scope=scope,
                )
                await self._handle_application_message(data)
        except json.JSONDecodeError:
            logger.warning("Received non-JSON data channel message", raw=message)

    async def _handle_runtime_message(self, data: dict) -> None:
        """
        Handle incoming runtime-layer messages (e.g., requestCapabilities).
        Runtime messages are platform-level and never dispatched to the model.

        Inner payload follows the same { type, data } pattern used by the
        application layer, so responses are e.g.:
            { type: "modelCapabilities", data: { commands: {...} } }
        """
        msg_type = data.get("type")
        if msg_type == RuntimeMessageType.REQUEST_CAPABILITIES:
            if self.model:
                inner = {
                    "type": RuntimeMessageType.MODEL_CAPABILITIES,
                    "data": self.model.capabilities(),
                }
                wrapped = RuntimeMessage(data=inner).model_dump()
                await self.send_out_runtime_message(wrapped)
            else:
                logger.warning("Received requestCapabilities but model is not loaded")
        elif msg_type == RuntimeMessageType.PING:
            self._on_ping_received()
        else:
            logger.warning("Unknown runtime message type", msg_type=msg_type)

    async def _handle_application_message(self, data: dict) -> None:
        """
        Handle incoming application-layer messages (model commands).
        Extracts command name and args, then dispatches to the model.
        """
        cmd_name = data.get("type")
        cmd_args = data.get("data", {})

        if cmd_name and self.model:
            try:
                result = self.model.send(cmd_name, cmd_args)
                if result is not None:
                    wrapped = ApplicationMessage(data=result).model_dump()
                    await self.send_out_app_message(wrapped)
            except ValueError as e:
                logger.warning("Invalid command", error=e)
            except Exception as e:
                logger.exception("Command execution failed", error=e)

    def _send_out_runtime_message_sync(self, data: dict) -> None:
        """
        Synchronous helper to send a runtime message.
        Wraps the data in a RuntimeMessage envelope and schedules async send.
        """
        wrapped = RuntimeMessage(data=data).model_dump()
        try:
            logger.info("Sending runtime message to client", data=wrapped)
            asyncio.run_coroutine_threadsafe(
                self.send_out_runtime_message(wrapped), self.loop
            )
        except Exception as e:
            logger.warning("Failed to send runtime message to client", error=e)

    @abstractmethod
    async def send_out_app_bundle(
        self, media_bundle: MediaBundle, duplicate: bool
    ) -> None:
        """Send a synchronised multi-track media bundle to the client.

        Called periodically by the :class:`FrameBuffer` emission loop at
        the dynamically calculated FPS.  Implementations forward the
        bundle to the transport via ``send_media``.

        Args:
            media_bundle: The :class:`MediaBundle` to send.
            duplicate: True if this is a re-emission of the last frame.
        """
        pass

    @abstractmethod
    async def run(self) -> None:
        pass

    # ===============================
    # Graceful SIGTERM Shutdown
    # ===============================

    def get_shutdown_event(self) -> asyncio.Event:
        """
        Get the shutdown event for waiting on graceful shutdown.

        Concrete runtimes should await this event in their run() method:
            await self.get_shutdown_event().wait()

        Returns:
            The asyncio.Event that is set when shutdown should occur.
        """
        return self._shutdown_event

    def _setup_signal_handlers(self) -> None:
        """
        Set up signal handlers for graceful shutdown (SIGTERM/SIGINT).

        Called automatically during __init__. The handlers trigger graceful
        shutdown logic that:
        - Immediately shuts down if in READY or CREATED state
        - Waits for grace period if in a session, then forces stop
        - Sets the shutdown event when ready to exit
        """

        def signal_handler(sig):
            # Ignore duplicate signals if shutdown is already in progress
            if self._shutdown_pending:
                logger.debug(
                    "Received signal but shutdown already in progress, ignoring",
                    signal=sig,
                )
                return
            logger.info("Received signal, initiating graceful shutdown", signal=sig)
            # Use call_soon_threadsafe to safely schedule the async task from the signal handler
            self.loop.call_soon_threadsafe(
                lambda: asyncio.create_task(self._handle_sigterm_graceful_shutdown())
            )

        for sig in (signal.SIGTERM, signal.SIGINT):
            self.loop.add_signal_handler(sig, signal_handler, sig)

    async def _handle_sigterm_graceful_shutdown(self) -> None:
        """
        Internal handler for SIGTERM graceful shutdown.

        Called by the signal handler set up via _setup_signal_handlers().
        Implements the following behavior:

        - If in READY or CREATED: set shutdown_event immediately
        - If in session states (WAITING, STREAMING, ORPHANED): wait grace period,
          then force stop the session
        - If in other states (e.g., CLOSING): the state machine will automatically
          transition to READY, which will trigger shutdown via on_enter_READY

        The grace period is controlled by the SIGTERM_GRACE_PERIOD environment
        variable (defaults to 30 seconds).
        """
        # Mark shutdown as pending first to prevent duplicate handling
        self._shutdown_pending = True

        # Get grace period from environment variable (default 30 seconds)
        try:
            grace_period = float(os.getenv("SIGTERM_GRACE_PERIOD", "30"))
        except ValueError:
            logger.warning("Invalid SIGTERM_GRACE_PERIOD value, using default 30s")
            grace_period = 30.0

        current_state = self.current_state

        # If already terminated, nothing to do
        if current_state == ModelState.TERMINATED:
            logger.debug("Already in TERMINATED state, nothing to do")
            self._shutdown_event.set()
            return

        # If in READY or CREATED, immediately trigger shutdown
        if current_state in (ModelState.READY, ModelState.CREATED):
            logger.info(
                "SIGTERM received, triggering immediate shutdown",
                state=current_state.value,
            )
            self._shutdown_event.set()
            return

        # Session states where we need to wait for graceful termination
        session_states = (ModelState.WAITING, ModelState.STREAMING, ModelState.ORPHANED)

        if current_state in session_states:
            logger.info(
                "SIGTERM received in session state, waiting for graceful termination",
                state=current_state.value,
                grace_period=f"{grace_period}s",
            )

            # Wait for grace period or until shutdown_event is set (by on_enter_READY)
            try:
                await asyncio.wait_for(
                    self._shutdown_event.wait(), timeout=grace_period
                )
                logger.info("Session ended within grace period")
            except asyncio.TimeoutError:
                logger.warning(
                    "Grace period expired, forcing session stop",
                    grace_period=f"{grace_period}s",
                )
                self.send(ModelEvent.STOP_SESSION)
                # on_enter_READY will set shutdown_event when we reach READY
        else:
            # For other states (e.g., CLOSING), just log and wait
            # The state machine will automatically transition to READY
            logger.info(
                "SIGTERM received, waiting for state machine to reach READY",
                state=current_state.value,
            )
            # on_enter_READY will set shutdown_event when we reach READY

    # ===============================
    # Shutdown Cleanup
    # ===============================

    async def shutdown(self) -> None:
        """
        Perform graceful shutdown cleanup.
        Stops any running session, waits for READY state, then sends EVICTION.

        This method is shielded from cancellation to ensure EVICTION always happens.
        Subclasses should call this in their run() method's finally block.
        """
        try:
            await asyncio.shield(self._shutdown_cleanup())
        except asyncio.CancelledError:
            logger.info("Shutdown cleanup completed despite cancellation")

    async def _shutdown_cleanup(self) -> None:
        """
        Internal shutdown cleanup implementation.
        Override in subclasses to add additional cleanup steps.
        """
        # Stop idling loop first
        await self._stop_idling_loop()

        try:
            if self.session_running or self.current_state == ModelState.WAITING:
                self.send(ModelEvent.STOP_SESSION)

            # Wait for state to settle - accept READY or terminal states
            while self.current_state not in (
                ModelState.READY,
                ModelState.TERMINATED,
                ModelState.CREATED,
            ):
                await asyncio.sleep(0.05)

            # Only send EVICTION if we're in READY (the only valid source state)
            if self.current_state == ModelState.READY:
                self.send(ModelEvent.EVICTION)

        except asyncio.CancelledError:
            # If cancelled during cleanup, still try to send EVICTION synchronously
            logger.warning("Shutdown cleanup was cancelled, attempting final eviction")
            if self.current_state == ModelState.READY:
                self.send(ModelEvent.EVICTION)
            raise

        logger.info("Runtime shutdown complete")

    # ===============================
    # Orphan Timeout Management
    # ===============================

    def _start_orphan_timeout(self) -> None:
        """
        Start the orphan timeout coroutine.

        If no Client Connection is established within the timeout period,
        the session will be stopped automatically.
        """

        if self.config.orphan_timeout <= 0:
            logger.debug("Orphan timeout disabled (orphan_timeout <= 0)")
            return

        # Cancel any existing orphan task
        self._cancel_orphan_timeout()

        async def orphan_timeout_coro():
            try:
                logger.info(
                    "Orphan timeout started",
                    timeout=f"{self.config.orphan_timeout}s",
                )
                await asyncio.sleep(self.config.orphan_timeout)

                # TOCTOU race condition is checked by the state machine - entering WAITING / ORPHANED resets the timeout
                self.send(ModelEvent.TIMEOUT)

            except asyncio.CancelledError:
                logger.info("Orphan timeout cancelled")

        self._orphan_task = asyncio.create_task(orphan_timeout_coro())

    def _cancel_orphan_timeout(self) -> None:
        """Cancel the orphan timeout if running."""
        if self._orphan_task is not None:
            self._orphan_task.cancel()
            self._orphan_task = None
            logger.debug("Orphan timeout cancelled")

    # ===============================
    # Max Session Duration Management
    # ===============================

    def _start_max_session_duration_timeout(self) -> None:
        """
        Start the max session duration timeout task.

        If max_session_duration is configured, the session will be automatically
        stopped when the duration expires. This provides a hard limit on session
        lifetime regardless of client activity.
        """
        if self.config.max_session_duration is None:
            logger.debug("Max session duration not configured, skipping timeout")
            return

        if self.config.max_session_duration <= 0:
            logger.debug("Max session duration disabled (value <= 0)")
            return

        # Cancel any existing task (shouldn't happen, but be safe)
        self._cancel_max_session_duration_timeout()

        async def max_session_duration_coro():
            try:
                logger.info(
                    "Max session duration timeout started",
                    duration=f"{self.config.max_session_duration}s",
                )
                await asyncio.sleep(self.config.max_session_duration)

                # Check if we're still in a session state before triggering stop
                # This prevents TOCTOU issues where the session may have already
                # transitioned to CLOSING or another state
                if self.current_state in (
                    ModelState.STREAMING,
                    ModelState.ORPHANED,
                ):
                    logger.info(
                        "Max session duration expired, stopping session",
                        duration=f"{self.config.max_session_duration}s",
                    )
                    self.send(ModelEvent.STOP_SESSION)
                else:
                    logger.debug(
                        "Max session duration expired but session already in non-active state, ignoring",
                        state=self.current_state,
                    )

            except asyncio.CancelledError:
                logger.debug("Max session duration timeout cancelled")

        self._max_session_duration_task = asyncio.create_task(
            max_session_duration_coro()
        )

    def _cancel_max_session_duration_timeout(self) -> None:
        """Cancel the max session duration timeout if running."""
        if self._max_session_duration_task is not None:
            self._max_session_duration_task.cancel()
            self._max_session_duration_task = None
            logger.debug("Max session duration timeout cancelled")

    def _on_ping_received(self) -> None:
        """
        Called when a client ping arrives on the runtime channel.

        The default implementation is a no-op.  WebRTC-based runtimes override
        this to forward the ping to the WebRTCClient's watchdog via
        ``notify_ping()``.
        """
        pass

    # ===============================
    # Idling Management
    # ===============================

    def _start_idling_loop(self) -> None:
        """
        Start the idling loop task.

        The idling loop periodically triggers IDLING events via the state machine.
        The event is only valid when in READY state (READY -> READY transition).
        """
        if self._idling_task is not None:
            logger.warning("Idling loop already running")
            return

        self._idling_task = asyncio.create_task(self._idling_loop())

    async def _stop_idling_loop(self) -> None:
        """Stop the idling loop task."""
        if self._idling_task is not None:
            self._idling_task.cancel()
            try:
                await self._idling_task
            except asyncio.CancelledError:
                pass
            self._idling_task = None
            logger.debug("Idling loop stopped")

    async def _idling_loop(self) -> None:
        """
        Background task that periodically triggers IDLING events via the state machine.

        The IDLING event is only valid when the runtime is in READY state (READY -> READY).
        If the runtime is not in READY state, the state machine will reject the event.
        This task runs continuously until cancelled.

        The interval is configured via config.idling_interval.
        """
        # idling_interval is guaranteed to be set by __post_init__
        assert self.config.idling_interval is not None
        interval = self.config.idling_interval
        logger.info("Idling loop started", interval=f"{interval}s")

        while True:
            try:
                await asyncio.sleep(interval)

                # Send IDLING event - state machine validates that we're in READY state
                # The after_transition hook will handle sending the event to external systems
                self.send(ModelEvent.IDLING)
            except asyncio.CancelledError:
                logger.debug("Idling loop cancelled")
                break
            except Exception as e:
                # Log but don't crash - failures are handled by concrete implementations
                logger.warning("Idling loop error", error=e)
