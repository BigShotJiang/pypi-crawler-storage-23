"""
Configuration for the HTTP Runtime.
"""

import argparse
import logging
import os
from dataclasses import dataclass

from reactor_cli.utils.config import _valid_port
from reactor_runtime.runtime_api import RuntimeConfig
from reactor_runtime.transports.config import (
    DEFAULT_STUN_SERVER,
    load_webrtc_ports_from_env,
    parse_transport_policy,
    parse_transport_type,
    parse_webrtc_port_range,
    validate_webrtc_port_range,
)
from reactor_runtime.transports.types import (
    IceServer,
    IceTransportPolicy,
    TransportType,
)

logger = logging.getLogger(__name__)

# Environment variable keys for ICE server configuration
# Comma-separated list of STUN server URLs
ENV_STUN_SERVERS = "STUN_SERVERS"
# Comma-separated list of "username;credential;url" entries
ENV_TURN_SERVERS = "TURN_SERVERS"
# ICE transport policy: "all" (default) or "relay" (TURN-only)
ENV_ICE_TRANSPORT_POLICY = "ICE_TRANSPORT_POLICY"


@dataclass
class HttpRuntimeConfig(RuntimeConfig):
    """
    Configuration for the HTTP Runtime.

    Extends RuntimeConfig with HTTP-specific settings.
    """

    host: str = "0.0.0.0"
    port: int = 8080

    # WebRTC port range configuration (format: "min:max", ":max", or "min:")
    webrtc_port_range: tuple[int, int] | None = None

    # ICE/TURN server configuration
    stun_servers: list[str] | None = None  # STUN server URLs (can specify multiple)
    turn_servers: list[str] | None = (
        None  # TURN servers in format "username;credential;url"
    )
    # ICE transport policy: "all" (default) or "relay" (forces TURN-only)
    ice_transport_policy: IceTransportPolicy = IceTransportPolicy.ALL

    # WebRTC transport backend
    transport_type: TransportType = TransportType.GSTREAMER

    def __post_init__(self):
        """Validate configuration after initialization."""
        super().__post_init__()
        # Load WebRTC port range from environment variable if not set via CLI
        if self.webrtc_port_range is None:
            env_range = load_webrtc_ports_from_env()
            if env_range != (None, None):
                self.webrtc_port_range = env_range
        self._load_ice_servers_from_env()
        self._load_ice_transport_policy_from_env()
        # Validate configurations
        if self.webrtc_port_range is not None:
            validate_webrtc_port_range(
                self.webrtc_port_range[0], self.webrtc_port_range[1]
            )
        else:
            validate_webrtc_port_range(None, None)
        self._validate_turn_servers()
        self._validate_ice_transport_policy()

    def _load_ice_servers_from_env(self):
        """Load ICE server configuration from environment variables if not set via CLI."""
        # Load STUN servers (comma-separated URLs)
        if self.stun_servers is None:
            env_val = os.getenv(ENV_STUN_SERVERS)
            if env_val:
                self.stun_servers = [s.strip() for s in env_val.split(",") if s.strip()]

        # Load TURN servers (comma-separated "username;credential;url" entries)
        if self.turn_servers is None:
            env_val = os.getenv(ENV_TURN_SERVERS)
            if env_val:
                self.turn_servers = [s.strip() for s in env_val.split(",") if s.strip()]

    def _load_ice_transport_policy_from_env(self):
        """Load ICE transport policy from environment variable if not set via CLI."""
        # Only load from env if still at default (not set via CLI)
        if self.ice_transport_policy == IceTransportPolicy.ALL:
            env_val = os.getenv(ENV_ICE_TRANSPORT_POLICY)
            if env_val:
                self.ice_transport_policy = parse_transport_policy(env_val)

    def _validate_turn_servers(self):
        """Validate TURN server configuration format."""
        if not self.turn_servers:
            return

        for i, turn_server in enumerate(self.turn_servers):
            parts = turn_server.split(";", 2)
            if len(parts) != 3:
                raise ValueError(
                    f"Invalid TURN server format at index {i}: '{turn_server}'. "
                    f"Expected format: 'username;credential;url' (e.g., 'user;pass;turn:example.com:3478')"
                )
            username, credential, url = [p.strip() for p in parts]
            if not username or not credential or not url:
                raise ValueError(
                    f"Invalid TURN server at index {i}: username, credential, and URL are all required. "
                    f"Got: username='{username}', credential='***', url='{url}'"
                )

    def _validate_ice_transport_policy(self):
        """Validate ICE transport policy configuration."""
        if self.ice_transport_policy == IceTransportPolicy.RELAY:
            # Warn if no TURN server is configured but relay-only is requested
            if not self.turn_servers:
                logger.warning(
                    "ICE transport policy is set to 'relay' but no TURN servers are configured. "
                    "WebRTC connections may fail without a TURN server."
                )
            else:
                logger.info(
                    "ICE transport policy set to 'relay' - only TURN relay candidates will be gathered"
                )

    @property
    def ice_servers(self) -> list[IceServer] | None:
        """Return list of ICE server configurations, or None to use defaults."""
        servers: list[IceServer] = []

        # Add STUN servers if configured (can be multiple)
        if self.stun_servers:
            for stun_url in self.stun_servers:
                servers.append(IceServer(urls=[stun_url]))

        # Add TURN servers if configured (format: username;credential;url)
        if self.turn_servers:
            for turn_server in self.turn_servers:
                parts = turn_server.split(";", 2)
                username, credential, url = [p.strip() for p in parts]
                servers.append(
                    IceServer(
                        urls=[url],
                        username=username,
                        credential=credential,
                    )
                )

        return servers if servers else None

    @property
    def ice_servers_json(self) -> list[dict]:
        """
        Return ICE servers in JSON format matching the coordinator API schema.

        Returns:
            List of ICE server configurations in the format:
            [
                {"uris": ["stun:..."]},
                {"uris": ["turn:..."], "credentials": {"username": "...", "password": "..."}},
                ...
            ]
        """
        ice_servers = self.ice_servers
        result: list[dict] = []

        if ice_servers is None or len(ice_servers) == 0:
            # Default to Google's public STUN server
            result.append({"uris": [DEFAULT_STUN_SERVER]})
        else:
            for server in ice_servers:
                # Ensure uris is always a list
                uris = server.urls if isinstance(server.urls, list) else [server.urls]
                entry: dict = {"uris": uris}
                if server.username and server.credential:
                    entry["credentials"] = {
                        "username": server.username,
                        "password": server.credential,
                    }
                result.append(entry)

        return result

    @staticmethod
    def parser() -> argparse.ArgumentParser:
        """
        Return an argument parser for HTTP runtime-specific arguments.

        Returns:
            argparse.ArgumentParser with HTTP-specific arguments
        """
        parser = RuntimeConfig.parser()
        parser.add_argument(
            "--host",
            type=str,
            default="0.0.0.0",
            help="Host to bind the HTTP server to. Default: 0.0.0.0",
        )
        parser.add_argument(
            "--port",
            type=_valid_port,
            default=8080,
            help="Port to bind the HTTP server to. Default: 8080",
        )
        parser.add_argument(
            "--webrtc-port-range",
            type=parse_webrtc_port_range,
            default=None,
            help="WebRTC ICE UDP port range in format 'min:max', ':max', or 'min:' "
            "(e.g., '10000:20000', ':20000', '10000:'). Default: None (ephemeral ports)",
        )
        parser.add_argument(
            "--stun-server",
            type=str,
            action="append",
            dest="stun_servers",
            default=None,
            help="STUN server URL (e.g., stun:stun.l.google.com:19302). Can be specified multiple times. Default: Google STUN",
        )
        parser.add_argument(
            "--turn-server",
            type=str,
            action="append",
            dest="turn_servers",
            default=None,
            help="TURN server in format 'username;credential;url' (e.g., 'user;pass;turn:example.com:3478'). Can be specified multiple times.",
        )
        parser.add_argument(
            "--ice-transport-policy",
            type=parse_transport_policy,
            dest="ice_transport_policy",
            default=IceTransportPolicy.ALL,
            help="ICE transport policy: 'all' (default) gathers all candidate types, "
            "'relay' gathers only TURN relay candidates (forces all traffic through TURN server).",
        )
        available = ", ".join(t.name.lower() for t in TransportType)
        parser.add_argument(
            "--transport",
            type=parse_transport_type,
            dest="transport_type",
            default=None,
            help=f"WebRTC transport backend to use. Available: {available}. "
            "Default: gstreamer (falls back to aiortc if unavailable)",
        )
        return parser
