"""
Configuration for the Headless Runtime.
"""

import argparse
from dataclasses import dataclass

from reactor_runtime.runtime_api import RuntimeConfig


@dataclass
class HeadlessRuntimeConfig(RuntimeConfig):
    """
    Configuration for the Headless Runtime.

    Extends RuntimeConfig with headless-specific settings.
    """

    output_root: str = "./output"
    ignore_duplicates: bool = True

    @staticmethod
    def parser() -> argparse.ArgumentParser:
        """
        Return an argument parser for headless runtime-specific arguments.

        Returns:
            argparse.ArgumentParser with headless-specific arguments
        """
        parser = RuntimeConfig.parser()
        parser.add_argument(
            "--output-root",
            type=str,
            default="./output",
            help="Root directory for output. Each session creates a subfolder with epoch timestamp. Default: ./output",
        )
        parser.add_argument(
            "--no-ignore-duplicates",
            action="store_true",
            dest="no_ignore_duplicates",
            help="Write all frames including duplicates (by default, duplicate frames are skipped)",
        )
        return parser
