from enum import Enum
from typing import Dict, List, Tuple

from reactor_runtime.utils.log import get_logger

logger = get_logger(__name__)


class ModelState(Enum):
    """States for the model lifecycle."""

    CREATED = "CREATED"
    TERMINATED = "TERMINATED"
    READY = "READY"
    WAITING = "WAITING"
    STREAMING = "STREAMING"
    ORPHANED = "ORPHANED"
    CLOSING = "CLOSING"


class ModelEvent(Enum):
    """Events that trigger state transitions."""

    INITIALIZATION_SUCCESS = "initialization_success"
    INITIALIZATION_FAIL = "initialization_fail"
    START_SESSION = "start_session"
    CLIENT_CONNECTED = "client_connected"
    CLIENT_DISCONNECTED = "client_disconnected"
    STOP_SESSION = "stop_session"
    TIMEOUT = "timeout"
    CLEANUP_COMPLETE = "cleanup_complete"
    EVICTION = "eviction"
    IDLING = "idling"


class ModelStateMachine:
    """State machine for managing model lifecycle."""

    # Define valid transitions: event -> list of (from_state, to_state) tuples
    TRANSITIONS: Dict[ModelEvent, List[Tuple[ModelState, ModelState]]] = {
        ModelEvent.INITIALIZATION_SUCCESS: [
            (ModelState.CREATED, ModelState.READY),
        ],
        ModelEvent.INITIALIZATION_FAIL: [
            (ModelState.CREATED, ModelState.TERMINATED),
        ],
        ModelEvent.START_SESSION: [
            (ModelState.READY, ModelState.WAITING),
        ],
        ModelEvent.CLIENT_CONNECTED: [
            (ModelState.WAITING, ModelState.STREAMING),
            (ModelState.ORPHANED, ModelState.STREAMING),
        ],
        ModelEvent.CLIENT_DISCONNECTED: [
            (ModelState.STREAMING, ModelState.ORPHANED),
        ],
        ModelEvent.STOP_SESSION: [
            (ModelState.STREAMING, ModelState.CLOSING),
            (ModelState.WAITING, ModelState.CLOSING),
            (ModelState.ORPHANED, ModelState.CLOSING),
        ],
        ModelEvent.TIMEOUT: [
            (ModelState.WAITING, ModelState.CLOSING),
            (ModelState.ORPHANED, ModelState.CLOSING),
        ],
        ModelEvent.CLEANUP_COMPLETE: [
            (ModelState.CLOSING, ModelState.READY),
        ],
        ModelEvent.EVICTION: [
            (ModelState.READY, ModelState.TERMINATED),
        ],
        ModelEvent.IDLING: [
            (ModelState.READY, ModelState.READY),
        ],
    }

    def __init__(self, initial_state: ModelState = ModelState.CREATED):
        self.current_state = initial_state

    def send(self, event: ModelEvent, **kwargs) -> bool:
        """
        Send an event to the state machine.

        Returns True if the transition was successful, False otherwise.
        """
        if event not in self.TRANSITIONS:
            logger.warning("Received invalid event", event=event)
            return False

        transitions = self.TRANSITIONS[event]

        # Find a matching transition from current state
        to_state = None
        for from_state, target_state in transitions:
            if self.current_state == from_state:
                to_state = target_state
                break

        if to_state is None:
            logger.warning(
                "Illegal state transition",
                event=event,
                current_state=self.current_state,
            )
            return False

        logger.info(
            "State transition",
            event=event,
            from_state=self.current_state,
            to=to_state,
        )

        # Save previous state
        previous_state = self.current_state

        # Call on_before_<event> handler
        self._call_before_handler(event, **kwargs)

        # Update state
        self.current_state = to_state
        logger.debug("State updated", state=self.current_state)

        # Call on_enter_<state> handler
        self._call_enter_handler(to_state, previous_state)

        self.after_transition(
            to_state=to_state, from_state=previous_state, event=event, **kwargs
        )

        return True

    def _call_before_handler(self, event: ModelEvent, **kwargs):
        """Call the appropriate on_before_<event> method."""
        handler_name = f"on_before_{event.value}"
        handler = getattr(self, handler_name, None)
        if handler:
            handler(**kwargs)

    def _call_enter_handler(self, state: ModelState, previous_state: ModelState):
        """Call the appropriate on_enter_<state> method."""
        handler_name = f"on_enter_{state.value}"
        handler = getattr(self, handler_name, None)
        if handler:
            handler(previous_state)

    def after_transition(
        self, to_state: ModelState, from_state: ModelState, event: ModelEvent, **kwargs
    ):
        """
        Generic handler for state machine transitions. Useful for actions that need to happen for all transitions.
        This handler is always called at last, after the transition has already happened.
        """
        pass

    # on_before_<event> methods
    def on_before_initialization_success(self, **kwargs):
        pass

    def on_before_initialization_fail(self, **kwargs):
        pass

    def on_before_start_session(self, **kwargs):
        pass

    def on_before_client_connected(self, **kwargs):
        pass

    def on_before_client_disconnected(self, **kwargs):
        pass

    def on_before_stop_session(self, **kwargs):
        pass

    def on_before_timeout(self, **kwargs):
        pass

    def on_before_cleanup_complete(self, **kwargs):
        pass

    def on_before_eviction(self, **kwargs):
        pass

    def on_before_idling(self, **kwargs):
        pass

    # on_enter_<state> methods
    def on_enter_CREATED(self, previous_state: ModelState):
        pass

    def on_enter_TERMINATED(self, previous_state: ModelState):
        pass

    def on_enter_READY(self, previous_state: ModelState):
        pass

    def on_enter_WAITING(self, previous_state: ModelState):
        pass

    def on_enter_STREAMING(self, previous_state: ModelState):
        pass

    def on_enter_ORPHANED(self, previous_state: ModelState):
        pass

    def on_enter_CLOSING(self, previous_state: ModelState):
        pass

    @property
    def session_running(self) -> bool:
        """Check if a session is currently running (state is STREAMING or ORPHANED)."""
        return self.current_state in (
            ModelState.STREAMING,
            ModelState.ORPHANED,
        )
