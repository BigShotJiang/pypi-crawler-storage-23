"""
Transport configuration utilities.

Shared helpers for parsing and validating WebRTC port ranges and ICE
transport policies.  These are transport-agnostic -- they are consumed
by runtime configuration classes and do not depend on any specific
transport implementation.
"""

import argparse
import importlib
import os
from typing import Union

from reactor_cli.utils.config import MAX_VALID_PORT, MIN_VALID_PORT, validate_port
from reactor_runtime.transports.types import IceTransportPolicy, TransportType
from reactor_runtime.utils.log import get_logger

logger = get_logger(__name__)

GSTREAMER_INSTALL_URL = (
    "https://gstreamer.freedesktop.org/documentation/installing/index.html"
)

_ORANGE = "\033[33m"
_RESET = "\033[0m"

# Default STUN server used when no custom ICE servers are configured
DEFAULT_STUN_SERVER = "stun:stun.l.google.com:19302"

# Environment variable key for WebRTC port configuration
ENV_WEBRTC_PORT_RANGE = "WEBRTC_PORT_RANGE"


# =============================================================================
# Port Range Utilities
# =============================================================================


def parse_webrtc_port_range(value: str) -> tuple[int, int]:
    """Parse a WebRTC port range string in Python slice-like syntax.

    Supports the following formats:
        - ``"x:y"`` -- explicit min and max ports
        - ``":y"``  -- min defaults to ``MIN_VALID_PORT`` (1024)
        - ``"x:"``  -- max defaults to ``MAX_VALID_PORT`` (65535)

    Args:
        value: The port range string to parse.

    Returns:
        Tuple of ``(min_port, max_port)``.

    Raises:
        ValueError: If the format is invalid or values are not valid integers.
    """
    parts = value.split(":")
    if len(parts) != 2:
        raise ValueError(
            f"Invalid port range format: '{value}'. "
            f"Expected exactly one ':' separator (e.g., '10000:20000', ':20000', '10000:')"
        )
    min_str, max_str = parts[0].strip(), parts[1].strip()

    # Parse min port
    if min_str == "":
        min_port = MIN_VALID_PORT
    else:
        try:
            min_port = int(min_str)
        except ValueError:
            raise ValueError(
                f"Invalid min port in range '{value}': '{min_str}' is not a valid integer"
            )

    # Parse max port
    if max_str == "":
        max_port = MAX_VALID_PORT
    else:
        try:
            max_port = int(max_str)
        except ValueError:
            raise ValueError(
                f"Invalid max port in range '{value}': '{max_str}' is not a valid integer"
            )

    # Validate the parsed port range immediately so CLI users get clear error
    # messages for invalid ranges like "20000:10000" or "100:200"
    validate_webrtc_port_range(min_port, max_port)

    return min_port, max_port


def load_webrtc_ports_from_env() -> tuple[int | None, int | None]:
    """Load WebRTC port range from the ``WEBRTC_PORT_RANGE`` environment variable.

    Reads the variable in the format ``"min:max"``, ``":max"``, or ``"min:"``.

    Returns:
        Tuple of ``(min_port, max_port)``, or ``(None, None)`` if not set.

    Raises:
        ValueError: If the environment variable value has an invalid format.
    """
    env_val = os.getenv(ENV_WEBRTC_PORT_RANGE)
    if not env_val:
        return None, None

    return parse_webrtc_port_range(env_val)


def validate_webrtc_port_range(min_port: int | None, max_port: int | None) -> None:
    """Validate a WebRTC port range configuration.

    Args:
        min_port: Minimum port number, or ``None`` if not configured.
        max_port: Maximum port number, or ``None`` if not configured.

    Raises:
        ValueError: If only one of min/max is set, if values are out of
            range, or if min > max.
    """
    # Check if only one is set
    if (min_port is None) != (max_port is None):
        raise ValueError(
            "Both min and max ports must be specified together in --webrtc-port-range"
        )

    if min_port is not None and max_port is not None:
        # Validate port range values to avoid privileged ports
        try:
            validate_port(min_port)
        except ValueError as e:
            raise ValueError(f"WebRTC port range min: {e}") from e
        try:
            validate_port(max_port)
        except ValueError as e:
            raise ValueError(f"WebRTC port range max: {e}") from e
        if min_port > max_port:
            raise ValueError(
                f"WebRTC port range min ({min_port}) must be <= max ({max_port})"
            )
        logger.debug(
            "WebRTC ICE port range configured", min_port=min_port, max_port=max_port
        )
    else:
        logger.debug("WebRTC ICE port range not configured, using ephemeral ports")


# =============================================================================
# Transport Type Utilities
# =============================================================================


def parse_transport_type(value: str) -> TransportType:
    """Parse a CLI string into a :class:`TransportType` enum member.

    The lookup is case-insensitive so ``"aiortc"`` and ``"AIORTC"`` both
    resolve to ``TransportType.AIORTC``.

    Args:
        value: Name of the transport (e.g. ``"aiortc"``, ``"gstreamer"``).

    Returns:
        The matching ``TransportType`` member.

    Raises:
        argparse.ArgumentTypeError: If *value* does not match any member.
    """
    try:
        return TransportType[value.upper()]
    except KeyError:
        valid = ", ".join(t.name.lower() for t in TransportType)
        raise argparse.ArgumentTypeError(
            f"Unknown transport: '{value}'. Available transports: {valid}"
        )


def validate_transport_available(transport_type: TransportType) -> None:
    """Eagerly verify that a transport backend can be imported.

    This is intended for early startup validation when the user explicitly
    selects a transport via ``--transport``.  When using the default
    transport the check is deferred to the first ``WebRTCTransport.create``
    call.

    Args:
        transport_type: The transport variant to check.

    Raises:
        ImportError: If the backing module cannot be imported.
    """
    try:
        module = importlib.import_module(transport_type.module_path)
        getattr(module, transport_type.class_name)
    except (ImportError, AttributeError, ValueError) as e:
        raise ImportError(
            f"Transport '{transport_type.name}' is not available: {e}. "
            f"Ensure the required dependencies are installed."
        ) from e

    if transport_type == TransportType.GSTREAMER:
        import gi

        gi.require_version("Gst", "1.0")
        from gi.repository import Gst

        Gst.init(None)
        missing = _check_gstreamer_elements()
        if missing:
            formatted = ", ".join(missing)
            raise ImportError(
                f"Transport '{transport_type.name}' is missing required "
                f"GStreamer elements: {formatted}"
            )


_REQUIRED_GST_CORE_ELEMENTS = (
    "webrtcbin",
    "appsrc",
    "appsink",
    "queue",
    "videoconvert",
    "capsfilter",
)

_REQUIRED_GST_CODEC_ELEMENTS: dict[str, tuple[str, ...]] = {
    "VP8": ("vp8enc", "vp8dec", "rtpvp8pay", "rtpvp8depay"),
    "VP9": ("vp9enc", "vp9dec", "rtpvp9pay", "rtpvp9depay"),
    "H.264": ("rtph264pay", "rtph264depay", "h264parse"),
    "H.265": ("rtph265pay", "rtph265depay"),
}


def _check_gstreamer_elements() -> list[str]:
    """Probe every GStreamer element the runtime depends on.

    Returns a list of element factory names that are *not* available.
    An empty list means the installation is complete.
    """
    import gi

    gi.require_version("Gst", "1.0")
    from gi.repository import Gst

    missing: list[str] = []

    for elem in _REQUIRED_GST_CORE_ELEMENTS:
        if Gst.ElementFactory.make(elem, None) is None:
            missing.append(elem)

    for codec, elements in _REQUIRED_GST_CODEC_ELEMENTS.items():
        codec_missing = [
            e for e in elements if Gst.ElementFactory.make(e, None) is None
        ]
        if codec_missing:
            missing.extend(codec_missing)

    return missing


def resolve_default_transport() -> TransportType:
    """Determine the best available transport when none is explicitly specified.

    Tries GStreamer first, falling back to aiortc with a warning that
    pinpoints the missing piece:

    1. PyGObject not installed  -> ``pip install reactor-runtime[gst]``
    2. System GStreamer missing -> install from gstreamer.freedesktop.org
    3. ``Gst.init`` fails       -> log the exception details
    """
    try:
        import gi  # noqa: F401 — probe only
    except ImportError:
        print(
            f"{_ORANGE}GStreamer Python bindings (PyGObject) are not installed, "
            f"falling back to aiortc. Install them with: "
            f"pip install reactor-runtime[gst]{_RESET}"
        )
        return TransportType.AIORTC

    try:
        gi.require_version("Gst", "1.0")
        from gi.repository import Gst
    except (ValueError, ImportError):
        print(
            f"{_ORANGE}PyGObject is installed but the GStreamer system libraries "
            f"or typelibs are missing, falling back to aiortc. "
            f"Install GStreamer: {GSTREAMER_INSTALL_URL}{_RESET}"
        )
        return TransportType.AIORTC

    try:
        Gst.init(None)
    except Exception as exc:
        print(
            f"{_ORANGE}GStreamer failed to initialize, falling back to aiortc. "
            f"Error: {exc}{_RESET}"
        )
        return TransportType.AIORTC

    missing = _check_gstreamer_elements()
    if missing:
        formatted = ", ".join(missing)
        print(
            f"{_ORANGE}GStreamer is missing required elements: {formatted}\n"
            f"Falling back to aiortc. "
            f"Install the missing plugins: {GSTREAMER_INSTALL_URL}{_RESET}"
        )
        return TransportType.AIORTC

    return TransportType.GSTREAMER


# =============================================================================
# Transport Policy Utilities
# =============================================================================


def parse_transport_policy(
    value: Union[str, IceTransportPolicy],
) -> IceTransportPolicy:
    """Parse a transport policy string or enum value into an ``IceTransportPolicy``.

    Args:
        value: Either a string (``"all"`` or ``"relay"``) or an
            ``IceTransportPolicy`` enum value.

    Returns:
        The corresponding ``IceTransportPolicy`` enum member.

    Raises:
        ValueError: If the string value is not recognized.
    """
    if isinstance(value, IceTransportPolicy):
        return value

    value_lower = value.lower().strip()
    if value_lower == "all":
        return IceTransportPolicy.ALL
    elif value_lower == "relay":
        return IceTransportPolicy.RELAY
    else:
        raise ValueError(
            f"Invalid transport policy: '{value}'. Must be 'all' or 'relay'."
        )
