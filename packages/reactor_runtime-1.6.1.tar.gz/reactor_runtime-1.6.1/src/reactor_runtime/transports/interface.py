"""
Abstract WebRTC transport interface.

Defines the ``WebRTCTransport`` ABC that every transport implementation
must satisfy.  Runtime code depends *only* on this interface and the
shared types in ``transports.types`` / ``transports.events`` -- never on
a concrete backend such as ``transports.aiortc``.

The static :meth:`WebRTCTransport.create` factory dynamically loads an
implementation based on a :class:`~transports.types.TransportType` enum
value, so missing backends (e.g. GStreamer) only cause an error when
actually requested, not at import time.
"""

import asyncio
import importlib
import threading
import time
from abc import ABC, abstractmethod
from typing import Dict, List, Optional, Union


from reactor_runtime.transports.events import (
    EventHandler,
    EventType,
    PingTimeoutEvent,
    WebRTCEvent,
)
from reactor_runtime.transports.media import MediaBundle
from reactor_runtime.transports.types import (
    SessionDescription,
    TransportConfig,
    TransportType,
)
from reactor_runtime.utils.log import get_logger

logger = get_logger(__name__)


class WebRTCTransport(ABC):
    """Abstract base class for WebRTC transport implementations.

    A transport manages a single WebRTC connection lifecycle and
    provides:

    * An event system for connection state changes and incoming data.
    * Thread-safe methods for sending video frames and data-channel
      messages from any thread.
    * A ping watchdog that detects stale client connections.
    * Cooperative shutdown via :meth:`stop`.

    Concrete implementations live under ``transports.<backend>/`` (e.g.
    ``transports.aiortc``) and are loaded dynamically by :meth:`create`.

    Subclasses **must** call ``super().__init__()`` and populate:

    * ``self._stop_event`` -- a :class:`threading.Event` for cooperative
      shutdown.
    * ``self._loop`` -- the :class:`asyncio.AbstractEventLoop` the
      transport runs on (may be ``None`` before the loop is started).
    """

    def __init__(self) -> None:
        # --- common state initialised by the base class ---

        # Event system
        self._event_handlers: Dict[EventType, List[EventHandler]] = {}
        self._handlers_lock = threading.Lock()

        # Ping watchdog
        self._PING_TIMEOUT_SECONDS: float = 10.0
        self._last_ping_time: Optional[float] = None
        self._ping_watchdog_task: Optional[asyncio.Task] = None

        # Cooperative shutdown flag (shared with subclass)
        self._stop_event: threading.Event = threading.Event()

        # Internal event loop — starts as ``None``; subclasses must assign
        # a running loop before calling watchdog / scheduling methods.
        self._loop: Optional[asyncio.AbstractEventLoop] = None

    # =========================================================================
    # Factory
    # =========================================================================

    @staticmethod
    async def create(
        transport_type: TransportType,
        sdp_offer: str,
        sdp_type: str = "offer",
        config: Optional[TransportConfig] = None,
    ) -> tuple["WebRTCTransport", SessionDescription]:
        """Create a transport instance and perform the SDP exchange.

        This is the **only** way to obtain a ``WebRTCTransport``.  The
        factory dynamically imports the implementation class registered
        under *transport_type* and delegates to its ``_create`` class
        method.

        Args:
            transport_type: Selects which backend to load (e.g.
                ``TransportType.AIORTC``).
            sdp_offer: The SDP offer string from the remote peer.
            sdp_type: The SDP type (``"offer"`` or ``"answer"``).
            config: Optional transport configuration (ICE servers, port
                range, transport policy).  When ``None`` the
                implementation should use sensible defaults.

        Returns:
            A tuple of ``(transport, session_description)`` where
            *session_description* contains the SDP answer.

        Raises:
            ImportError: If the requested backend is not installed.
            WebRTCSupersededError: If ``stop()`` was called during setup.
            WebRTCNoVideoError: If the SDP offer does not include video.
            RuntimeError: If connection setup fails.
        """
        impl_class = WebRTCTransport._load_implementation(transport_type)
        return await impl_class._create(sdp_offer, sdp_type, config)

    @staticmethod
    def _load_implementation(
        transport_type: TransportType,
    ) -> type["WebRTCTransport"]:
        """Dynamically import a transport class from *transport_type*.

        The :class:`TransportType` enum stores ``(module_path,
        class_name)`` so this method is a simple ``importlib`` lookup
        with no ``if/elif`` chain.

        Args:
            transport_type: The transport variant to load.

        Returns:
            The transport class (a subclass of ``WebRTCTransport``).

        Raises:
            ImportError: If the module or class cannot be found (e.g.
                the backing library is not installed).
            TypeError: If the resolved class does not subclass
                ``WebRTCTransport``.
        """
        try:
            module = importlib.import_module(transport_type.module_path)
            cls = getattr(module, transport_type.class_name)
        except (ImportError, AttributeError) as e:
            raise ImportError(
                f"Transport {transport_type.name} is not available: {e}. "
                f"Ensure the required dependencies are installed."
            ) from e
        if not issubclass(cls, WebRTCTransport):
            raise TypeError(f"{cls} does not implement WebRTCTransport")
        return cls

    # =========================================================================
    # Prewarm hook
    # =========================================================================

    @classmethod
    def _prewarm(cls) -> None:
        """Pre-warm expensive resources so the first session is fast.

        Concrete transports override this to eagerly spawn worker
        processes, allocate shared memory, or perform other one-time
        initialisation that would otherwise block the first media
        push.  Called from the :meth:`create` factory — implementations must be
        idempotent (subsequent calls are no-ops).

        The default implementation does nothing.
        """

    # =========================================================================
    # Internal factory hook (implemented by backends)
    # =========================================================================

    @classmethod
    @abstractmethod
    async def _create(
        cls,
        sdp_offer: str,
        sdp_type: str,
        config: Optional[TransportConfig],
    ) -> tuple["WebRTCTransport", SessionDescription]:
        """Backend-specific creation logic.

        Subclasses implement this to perform the full SDP
        offer/answer exchange and return a ready-to-use transport
        together with the SDP answer.

        Args:
            sdp_offer: The SDP offer string from the remote peer.
            sdp_type: The SDP type.
            config: Optional transport configuration.

        Returns:
            A tuple of ``(transport, session_description)``.
        """
        ...

    # =========================================================================
    # Event System (concrete -- shared by all implementations)
    # =========================================================================

    def on(self, event_type: EventType, handler: EventHandler) -> None:
        """Register an event handler.

        Args:
            event_type: The event type to listen for (e.g.
                ``EventType.CONNECTED``, ``EventType.MESSAGE``).
            handler: Callback receiving the corresponding
                :class:`~transports.events.WebRTCEvent` subclass.
        """
        with self._handlers_lock:
            if event_type not in self._event_handlers:
                self._event_handlers[event_type] = []
            self._event_handlers[event_type].append(handler)

    def off(
        self, event_type: EventType, handler: Optional[EventHandler] = None
    ) -> None:
        """Unregister an event handler.

        Args:
            event_type: The event type.
            handler: The specific handler to remove.  If ``None``, all
                handlers for the event type are removed.
        """
        with self._handlers_lock:
            if event_type not in self._event_handlers:
                return
            if handler is None:
                self._event_handlers[event_type] = []
            elif handler in self._event_handlers[event_type]:
                self._event_handlers[event_type].remove(handler)

    def _emit_event(self, event: WebRTCEvent) -> None:
        """Emit an event to all registered handlers.

        Handlers are called synchronously in the caller's context.

        Args:
            event: The event to emit.
        """
        with self._handlers_lock:
            handlers = self._event_handlers.get(event.event_type, [])[:]

        for handler in handlers:
            try:
                handler(event)
            except Exception as e:
                logger.exception(
                    "Error in event handler",
                    event_type=event.event_type.value,
                    error=e,
                )

    # =========================================================================
    # Ping Watchdog (concrete -- shared by all implementations)
    # =========================================================================

    def notify_ping(self) -> None:
        """Record that a ping was received from the client.

        Thread-safe -- can be called from any thread.
        """
        self._last_ping_time = time.monotonic()

    def start_ping_watchdog(self) -> None:
        """Start the ping watchdog.

        Should be called after the connection is established.  Emits a
        :class:`~transports.events.PingTimeoutEvent` if no ping arrives
        within the timeout.

        Thread-safe -- schedules on the internal event loop.
        """
        self.stop_ping_watchdog()
        self._last_ping_time = time.monotonic()

        loop = self._loop
        if not loop or loop.is_closed():
            return

        try:
            loop.call_soon_threadsafe(self._schedule_ping_watchdog)
        except RuntimeError:
            pass

    def stop_ping_watchdog(self) -> None:
        """Stop the ping watchdog.

        Safe to call even if not running.  Thread-safe.
        """
        self._last_ping_time = None
        loop = self._loop
        if loop and not loop.is_closed():
            try:
                loop.call_soon_threadsafe(self._cancel_ping_watchdog_task)
            except RuntimeError:
                pass

    def _cancel_ping_watchdog_task(self) -> None:
        """Cancel the watchdog task.  Must run on the internal event loop."""
        if self._ping_watchdog_task is not None:
            self._ping_watchdog_task.cancel()
            self._ping_watchdog_task = None

    def _schedule_ping_watchdog(self) -> None:
        """Create the watchdog task.  Must run on the internal event loop."""
        self._cancel_ping_watchdog_task()
        self._ping_watchdog_task = asyncio.create_task(self._ping_watchdog_loop())

    async def _ping_watchdog_loop(self) -> None:
        """Background task that checks whether the client is still sending pings.

        Polls every 2 s.  If the elapsed time since the last ping exceeds
        the timeout, emits a :class:`PingTimeoutEvent` and exits.
        """
        try:
            while not self._stop_event.is_set():
                await asyncio.sleep(2.0)

                last_ping = self._last_ping_time
                if last_ping is None:
                    break

                elapsed = time.monotonic() - last_ping
                if elapsed > self._PING_TIMEOUT_SECONDS:
                    logger.warning(
                        "Client ping timeout",
                        elapsed=f"{elapsed:.1f}s",
                        timeout=f"{self._PING_TIMEOUT_SECONDS}s",
                    )
                    self._emit_event(PingTimeoutEvent(elapsed=elapsed))
                    break
        except asyncio.CancelledError:
            logger.debug("Ping watchdog cancelled")
        finally:
            self._ping_watchdog_task = None

    # =========================================================================
    # Sending Data
    # =========================================================================

    @abstractmethod
    def send_media(self, bundle: MediaBundle) -> bool:
        """Send a synchronised multi-track media bundle to the remote peer.

        The implementation routes each track in the bundle to the
        appropriate output based on its :attr:`TrackInfo.kind`.  Tracks
        whose kind has no matching output on this connection are silently
        dropped (e.g. audio data when no audio transceiver was
        negotiated).

        Thread-safe -- can be called from any thread.

        Args:
            bundle: A :class:`~transports.media.MediaBundle` containing
                one or more named track payloads.

        Returns:
            ``True`` if the bundle was processed, ``False`` if the
            transport is stopped or an error occurred.
        """
        ...

    @abstractmethod
    def send_message(self, data: Union[dict, str]) -> bool:
        """Send a message over the data channel.

        Thread-safe -- can be called from any thread.

        Args:
            data: A dictionary (sent as JSON) or a raw string.

        Returns:
            ``True`` if the message was scheduled, ``False`` if stopped
            or failed.
        """
        ...

    # =========================================================================
    # Lifecycle
    # =========================================================================

    @abstractmethod
    def stop(self, timeout: float = 5.0) -> None:
        """Cooperatively stop the transport.

        Sets the stop flag so all long-running operations exit quickly,
        then waits for the background thread to finish.

        Args:
            timeout: Maximum seconds to wait for the thread to exit.
        """
        ...

    @abstractmethod
    def is_connected(self) -> bool:
        """Return ``True`` if the connection is currently established and not stopped."""
        ...

    @property
    @abstractmethod
    def is_stopped(self) -> bool:
        """``True`` if :meth:`stop` has been requested."""
        ...

    @property
    @abstractmethod
    def was_superseded(self) -> bool:
        """``True`` if this transport was stopped during setup (superseded by another)."""
        ...
