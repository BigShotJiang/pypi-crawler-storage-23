"""
Transport abstraction layer for the Reactor runtime.

This package provides a transport-agnostic interface for WebRTC
connections.  Runtime code should import exclusively from this package
(or its public sub-modules ``types``, ``events``, ``media``, ``config``)
and **never** from a concrete backend such as ``transports.aiortc``.

Public API re-exported here for convenience::

    from reactor_runtime.transports import (
        # Interface
        WebRTCTransport,
        # Types
        TransportType,
        TransportConfig,
        IceServer,
        IceTransportPolicy,
        SessionDescription,
        # Media types
        TrackKind,
        TrackDirection,
        TrackInfo,
        TrackData,
        MediaBundle,
        # Events
        EventType,
        WebRTCNoVideoError,
        WebRTCSupersededError,
        WebRTCEvent,
        ConnectedEvent,
        DisconnectedEvent,
        MessageEvent,
        VideoFrameEvent,
        MediaBundleEvent,
        PingTimeoutEvent,
        EventHandler,
    )
"""

from reactor_runtime.transports.events import (
    ConnectedEvent,
    DisconnectedEvent,
    EventHandler,
    EventType,
    MediaBundleEvent,
    MessageEvent,
    PingTimeoutEvent,
    VideoFrameEvent,
    WebRTCEvent,
    WebRTCNoVideoError,
    WebRTCSupersededError,
)
from reactor_runtime.transports.interface import WebRTCTransport
from reactor_runtime.transports.media import (
    MediaBundle,
    TrackData,
    TrackDirection,
    TrackInfo,
    TrackKind,
)
from reactor_runtime.transports.types import (
    IceServer,
    IceTransportPolicy,
    SessionDescription,
    TransportConfig,
    TransportType,
)

__all__ = [
    # Interface
    "WebRTCTransport",
    # Types
    "TransportType",
    "TransportConfig",
    "IceServer",
    "IceTransportPolicy",
    "SessionDescription",
    # Media types
    "TrackKind",
    "TrackDirection",
    "TrackInfo",
    "TrackData",
    "MediaBundle",
    # Events
    "EventType",
    "WebRTCNoVideoError",
    "WebRTCSupersededError",
    "WebRTCEvent",
    "ConnectedEvent",
    "DisconnectedEvent",
    "MessageEvent",
    "VideoFrameEvent",
    "MediaBundleEvent",
    "PingTimeoutEvent",
    "EventHandler",
]
