"""
Video track and frame-conversion helpers for the aiortc transport.

Provides:

* :func:`numpy_to_video_frame` / :func:`video_frame_to_numpy` --
  convenience converters between NumPy arrays and :class:`av.VideoFrame`.
* :class:`OutputVideoTrack` -- an aiortc
  :class:`~aiortc.VideoStreamTrack` fed by the model via
  :meth:`push_frame`, using shared-memory IPC for the heavy
  RGB -> YUV420p conversion.
"""

import threading
from fractions import Fraction
from multiprocessing import shared_memory
from typing import Any, Optional, Tuple

import numpy as np
from aiortc import VideoStreamTrack
from av import VideoFrame

from reactor_runtime.utils.log import get_logger
from reactor_runtime.transports.aiortc.frame_conversion import (
    _build_video_frame_from_shm,
    _convert_frame_via_shm,
    _get_frame_conversion_executor,
    _init_shared_memory_locked,
    _resize_shared_memory_if_needed_locked,
    _shm_lock,
)

logger = get_logger(__name__)


# =============================================================================
# NumPy <-> VideoFrame helpers
# =============================================================================


def numpy_to_video_frame(frame: np.ndarray) -> VideoFrame:
    """Convert a NumPy RGB array to a ``yuv420p`` :class:`VideoFrame`.

    Args:
        frame: NumPy array with shape ``(H, W, 3)`` in RGB format.

    Returns:
        :class:`VideoFrame` in ``yuv420p`` format suitable for WebRTC.
    """
    video_frame = VideoFrame.from_ndarray(frame, format="rgb24")
    video_frame = video_frame.reformat(format="yuv420p")
    return video_frame


def video_frame_to_numpy(frame: VideoFrame) -> np.ndarray:
    """Convert a :class:`VideoFrame` to a NumPy RGB array.

    Args:
        frame: The :class:`VideoFrame` to convert.

    Returns:
        NumPy array with shape ``(H, W, 3)`` in RGB format.
    """
    if frame.format.name != "rgb24":
        frame = frame.reformat(format="rgb24")
    return frame.to_ndarray()


# =============================================================================
# Output Video Track
# =============================================================================


class OutputVideoTrack(VideoStreamTrack):
    """Video track that outputs frames provided via :meth:`push_frame`.

    Designed to be fed frames from the model's output.  Thread-safe for
    :meth:`push_frame` calls from external threads.

    Uses shared memory for zero-copy IPC with a worker process for
    RGB -> YUV420p conversion, eliminating GIL contention with the
    inference thread.
    """

    kind = "video"

    _BLACK_FRAME_WIDTH = 1280
    _BLACK_FRAME_HEIGHT = 720

    def __init__(self, stop_event: threading.Event) -> None:
        super().__init__()
        self._frame: Optional[VideoFrame] = None
        self._frame_lock = threading.Lock()
        self._pts = 0
        self._time_base: Optional[Fraction] = None
        self._stop_event = stop_event
        # Cache YUV plane data (not VideoFrame) to avoid PTS race conditions
        # when the encoder is still processing a frame while we create a new one.
        self._cached_yuv_data: Optional[Tuple[bytes, bytes, bytes, int, int]] = None
        self._input_shm: Optional[shared_memory.SharedMemory] = None
        self._output_shm: Optional[shared_memory.SharedMemory] = None
        self._shm_initialized = False
        # Pre-built black frame in YUV420p with correct chroma values
        # (Y=0, U=128, V=128). A bare VideoFrame() leaves planes uninitialised,
        # which produces green noise because U=0,V=0 maps to green in YUV.
        self._black_frame = self._make_black_frame(
            self._BLACK_FRAME_WIDTH, self._BLACK_FRAME_HEIGHT
        )

        # Pre-warm the SHM worker process in the background so the
        # first push_frame doesn't block for seconds while the spawned
        # process imports numpy/av.  Without this, the emission loop
        # queues dozens of callbacks during the block — audio piles up
        # in the FIFO while video jumps to the latest frame.
        threading.Thread(
            target=self._prewarm_worker, daemon=False, name="shm-warmup"
        ).start()

    @staticmethod
    def _make_black_frame(width: int, height: int) -> VideoFrame:
        """Create a properly initialised black ``yuv420p`` frame.

        Using ``VideoFrame.from_ndarray`` ensures all YUV planes are
        correctly set (Y=0, U=128, V=128) rather than containing
        uninitialised memory.
        """
        black_rgb = np.zeros((height, width, 3), dtype=np.uint8)
        return VideoFrame.from_ndarray(black_rgb, format="rgb24").reformat(
            format="yuv420p"
        )

    def _prewarm_worker(self) -> None:
        """Run a dummy conversion to force the worker process to spawn
        and import its dependencies.  Runs on a background thread so it
        doesn't block track construction."""
        try:
            dummy = np.zeros(
                (self._BLACK_FRAME_HEIGHT, self._BLACK_FRAME_WIDTH, 3),
                dtype=np.uint8,
            )
            self._convert_frame_in_worker(dummy, timeout=30)
            logger.debug("SHM worker pre-warmed")
        except Exception as e:
            logger.debug("SHM worker pre-warm failed (non-fatal)", error=e)

    # -----------------------------------------------------------------
    # Shared-memory lifecycle (caller must hold ``_shm_lock``)
    # -----------------------------------------------------------------

    def _ensure_shm_initialized_locked(self) -> None:
        """Attach to module-level shared-memory blocks (idempotent).

        .. important:: Caller **must** hold :data:`_shm_lock`.
        """
        if self._shm_initialized:
            return

        input_name, output_name = _init_shared_memory_locked()
        self._input_shm = shared_memory.SharedMemory(name=input_name)
        self._output_shm = shared_memory.SharedMemory(name=output_name)
        self._shm_initialized = True

    def _reinitialize_shm_references_locked(self) -> None:
        """Close current SHM references and re-attach after a resize.

        .. important:: Caller **must** hold :data:`_shm_lock`.
        """
        if self._input_shm is not None:
            try:
                self._input_shm.close()
            except Exception:
                pass
            self._input_shm = None

        if self._output_shm is not None:
            try:
                self._output_shm.close()
            except Exception:
                pass
            self._output_shm = None

        self._shm_initialized = False
        self._ensure_shm_initialized_locked()

    # -----------------------------------------------------------------
    # Public API
    # -----------------------------------------------------------------

    def push_frame(self, frame: np.ndarray, duplicate: bool = False) -> bool:
        """Push a new frame to be sent on the next :meth:`recv` call.

        Thread-safe -- can be called from any thread.

        The shared memory will automatically resize if the frame
        dimensions exceed the current allocation (dimensions only grow,
        never shrink).

        Args:
            frame: NumPy array in RGB format with shape ``(H, W, 3)``.
            duplicate: If ``True``, reuses the previously converted YUV
                data, skipping the expensive colour-space conversion.

        Returns:
            ``True`` if the frame was queued, ``False`` if stopped or
            failed.
        """
        if self._stop_event.is_set():
            return False

        if frame.ndim != 3 or frame.shape[2] != 3:
            logger.error("Frame shape must be (H, W, 3)", shape=frame.shape)
            return False
        if frame.dtype != np.uint8:
            logger.error("Frame dtype must be uint8", dtype=frame.dtype)
            return False

        try:
            if duplicate and self._cached_yuv_data is not None:
                y_data, u_data, v_data, width, height = self._cached_yuv_data
                video_frame = VideoFrame(width=width, height=height, format="yuv420p")
                video_frame.planes[0].update(y_data)
                video_frame.planes[1].update(u_data)
                video_frame.planes[2].update(v_data)
            else:
                video_frame = self._convert_frame_in_worker(frame)
                width = video_frame.width
                height = video_frame.height
                self._cached_yuv_data = (
                    bytes(video_frame.planes[0]),
                    bytes(video_frame.planes[1]),
                    bytes(video_frame.planes[2]),
                    width,
                    height,
                )

            with self._frame_lock:
                video_frame.pts = self._pts
                if self._time_base is not None:
                    video_frame.time_base = self._time_base
                self._frame = video_frame
                self._pts += 1
            return True
        except Exception as e:
            logger.exception("Failed to push frame", error=e)
            return False

    def cleanup(self) -> None:
        """Release shared-memory references held by this track instance."""
        self._cached_yuv_data = None
        if self._input_shm is not None:
            try:
                self._input_shm.close()
            except Exception:
                pass
            self._input_shm = None
        if self._output_shm is not None:
            try:
                self._output_shm.close()
            except Exception:
                pass
            self._output_shm = None
        self._shm_initialized = False

    async def recv(self) -> VideoFrame:
        """Return the next frame to send over the WebRTC track.

        Returns:
            The current video frame, or a black frame if none is
            available.
        """
        pts, time_base = await self.next_timestamp()

        with self._frame_lock:
            if self._frame is not None:
                frame = self._frame
                frame.pts = pts
                frame.time_base = time_base
                self._time_base = time_base
                return frame

        # Return the pre-built black frame when no model frame is available yet
        frame = self._black_frame
        frame.pts = pts
        frame.time_base = time_base
        return frame

    # -----------------------------------------------------------------
    # Internal: worker-based conversion
    # -----------------------------------------------------------------

    def _convert_frame_in_worker(
        self, frame: np.ndarray, *, timeout: Optional[float] = None
    ) -> VideoFrame:
        """Convert an RGB frame to YUV420p via a worker process.

        Steps:
        1. Copy RGB data into input shared memory (fast memcpy).
        2. Worker reads from SHM, converts RGB -> YUV420p, writes to
           output SHM.
        3. Build a :class:`VideoFrame` from the output SHM.

        Holds :data:`_shm_lock` for the entire operation to prevent
        races between resize checks, initialisation, and worker
        execution.

        Args:
            frame: NumPy array in RGB format with shape ``(H, W, 3)``.
            timeout: Optional timeout in seconds for the worker result.
                ``None`` means wait indefinitely (used for real-time
                frames); a finite value is used by the prewarm path to
                avoid blocking shutdown.
        """
        height, width = frame.shape[:2]

        with _shm_lock:
            if _resize_shared_memory_if_needed_locked(width, height):
                self._reinitialize_shm_references_locked()
            else:
                self._ensure_shm_initialized_locked()

            if self._input_shm is None or self._output_shm is None:
                raise RuntimeError("Shared memory not initialised")

            input_buf = self._input_shm.buf
            if input_buf is None:
                raise RuntimeError("Input shared memory buffer is None")
            shm_array: np.ndarray[Any, np.dtype[np.uint8]] = np.ndarray(
                (height, width, 3), dtype=np.uint8, buffer=input_buf
            )
            np.copyto(shm_array, frame)

            executor = _get_frame_conversion_executor()
            future = executor.submit(
                _convert_frame_via_shm,
                self._input_shm.name,
                self._output_shm.name,
                width,
                height,
            )

            y_size, u_size, v_size = future.result(timeout=timeout)
            return _build_video_frame_from_shm(
                self._output_shm, y_size, u_size, v_size, width, height
            )
