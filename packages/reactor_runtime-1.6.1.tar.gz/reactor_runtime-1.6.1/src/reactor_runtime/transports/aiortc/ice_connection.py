"""
Custom aioice Connection with configurable port range and transport policy.

Extends the aioice :class:`Connection` class to allow:

* Binding UDP sockets to a specific port range instead of ephemeral ports.
* Configuring ICE transport policy (``ALL`` vs ``RELAY``-only mode).

Also provides the :class:`PortRangeGathererPatch` context manager that
monkey-patches aiortc's ``RTCIceGatherer`` so that
:class:`RTCPeerConnection` uses our custom connection under the hood.
"""

import asyncio
import ipaddress
import random
import socket
from typing import List, Optional, Tuple

from aioice import turn
from aioice.candidate import Candidate, candidate_foundation, candidate_priority
from aioice.ice import (
    Connection,
    StunProtocol,
    TransportPolicy,
    relayed_candidate,
    server_reflexive_candidate,
)
from aiortc import RTCIceGatherer, RTCIceServer
from aiortc.rtcicetransport import connection_kwargs
from pyee.asyncio import AsyncIOEventEmitter

# aiortc modules we need to monkey-patch
import aiortc.rtcicetransport as _rtcicetransport
import aiortc.rtcpeerconnection as _rtcpeerconnection

from reactor_runtime.utils.log import get_logger

logger = get_logger(__name__)

# Original RTCIceGatherer class -- stored for restoration after patching
_original_gatherer_class = _rtcicetransport.RTCIceGatherer


# =============================================================================
# PortRangeConnection
# =============================================================================


class PortRangeConnection(Connection):
    """ICE connection that binds UDP sockets to ports within a specified range.

    Extends the standard aioice :class:`Connection` by overriding the
    candidate-gathering process to bind sockets to ports within a
    configurable range instead of letting the OS assign ephemeral ports.

    Args:
        ice_controlling: Whether this side is the ICE controlling agent.
        port_range: ``(min_port, max_port)`` inclusive range.  ``None``
            means ephemeral ports (default aioice behaviour).
        port_bind_attempts: Maximum number of bind attempts within the
            range.
        transport_policy: ``TransportPolicy.ALL`` (default) or
            ``TransportPolicy.RELAY``.
        **kwargs: Passed through to the parent :class:`Connection`.
    """

    def __init__(
        self,
        ice_controlling: bool,
        port_range: Optional[Tuple[int, int]] = None,
        port_bind_attempts: int = 100,
        transport_policy: TransportPolicy = TransportPolicy.ALL,
        **kwargs,
    ) -> None:
        super().__init__(
            ice_controlling=ice_controlling,
            transport_policy=transport_policy,
            **kwargs,
        )
        self._port_range = port_range
        self._port_bind_attempts = port_bind_attempts

    async def get_component_candidates(
        self, component: int, addresses: list[str], timeout: int = 5
    ) -> list[Candidate]:
        """Gather ICE candidates, respecting port range and transport policy.

        Falls back to the parent implementation when no customisation is
        needed (no port range **and** ``ALL`` policy).
        """
        if self._port_range is None and self._transport_policy == TransportPolicy.ALL:
            return await super().get_component_candidates(component, addresses, timeout)

        candidates: list[Candidate] = []
        loop = asyncio.get_event_loop()

        min_port, max_port = self._port_range if self._port_range else (None, None)

        # --- host candidates ---
        host_protocols: list[StunProtocol] = []
        for address in addresses:
            protocol = await self._create_bound_protocol(
                loop, address, min_port, max_port
            )
            if protocol is None:
                continue

            host_protocols.append(protocol)

            if protocol.transport is None:
                raise RuntimeError("Protocol transport not set after binding")
            candidate_address = protocol.transport.get_extra_info("sockname")
            protocol.local_candidate = Candidate(
                foundation=candidate_foundation("host", "udp", candidate_address[0]),
                component=component,
                transport="udp",
                priority=candidate_priority(component, "host"),
                host=candidate_address[0],
                port=candidate_address[1],
                type="host",
            )
            if self._transport_policy == TransportPolicy.ALL:
                candidates.append(protocol.local_candidate)

        self._protocols += host_protocols

        tasks: list[asyncio.Task[tuple[Candidate, Optional[StunProtocol]]]] = []

        # --- server-reflexive candidates (IPv4 only, ALL policy) ---
        if self.stun_server and self._transport_policy == TransportPolicy.ALL:
            for protocol in host_protocols:
                if protocol.local_candidate is None:
                    continue
                if ipaddress.ip_address(protocol.local_candidate.host).version == 4:
                    tasks.append(
                        asyncio.create_task(
                            server_reflexive_candidate(protocol, self.stun_server)
                        )
                    )

        # --- relay candidates (TURN) ---
        if self.turn_server:
            tasks.append(
                asyncio.create_task(
                    relayed_candidate(
                        component=component,
                        protocol_factory=lambda: StunProtocol(self),
                        turn_server=self.turn_server,
                        turn_username=self.turn_username,
                        turn_password=self.turn_password,
                        turn_ssl=self.turn_ssl,
                        turn_transport=self.turn_transport,
                    )
                )
            )

        if tasks:
            done, pending = await asyncio.wait(tasks, timeout=timeout)
            for task in done:
                if task.exception() is None:
                    candidate, protocol = task.result()
                    candidates.append(candidate)
                    if protocol is not None:
                        self._protocols.append(protocol)
            for task in pending:
                task.cancel()

        return candidates

    async def _create_bound_protocol(
        self,
        loop: asyncio.AbstractEventLoop,
        address: str,
        min_port: Optional[int],
        max_port: Optional[int],
    ) -> Optional[StunProtocol]:
        """Create a :class:`StunProtocol` bound to a port in the given range.

        Args:
            loop: The running asyncio event loop.
            address: Local IP address to bind to.
            min_port: Minimum port (inclusive), or ``None`` for ephemeral.
            max_port: Maximum port (inclusive), or ``None`` for ephemeral.

        Returns:
            A :class:`StunProtocol` on success, ``None`` on failure.
        """
        if min_port is None or max_port is None:
            try:
                transport, protocol = await loop.create_datagram_endpoint(
                    lambda: StunProtocol(self), local_addr=(address, 0)
                )
                sock = transport.get_extra_info("socket")
                if sock is not None:
                    sock.setsockopt(
                        socket.SOL_SOCKET, socket.SO_RCVBUF, turn.UDP_SOCKET_BUFFER_SIZE
                    )
                actual_port = transport.get_extra_info("sockname")[1]
                logger.debug(
                    "Bound ICE socket (ephemeral)", address=address, port=actual_port
                )
                return protocol
            except OSError as exc:
                logger.warning(
                    "Could not bind with ephemeral port", address=address, error=exc
                )
                return None

        ports = list(range(min_port, max_port + 1))
        random.shuffle(ports)

        attempts = min(self._port_bind_attempts, len(ports))

        for port in ports[:attempts]:
            try:
                transport, protocol = await loop.create_datagram_endpoint(
                    lambda: StunProtocol(self), local_addr=(address, port)
                )
                sock = transport.get_extra_info("socket")
                if sock is not None:
                    sock.setsockopt(
                        socket.SOL_SOCKET, socket.SO_RCVBUF, turn.UDP_SOCKET_BUFFER_SIZE
                    )
                logger.debug("Bound ICE socket", address=address, port=port)
                return protocol
            except OSError as exc:
                logger.debug("Could not bind", address=address, port=port, error=exc)
                continue

        logger.warning(
            "Could not bind to any port in range",
            address=address,
            min_port=min_port,
            max_port=max_port,
            attempts=attempts,
        )
        return None


# =============================================================================
# PortRangeIceGatherer
# =============================================================================


class PortRangeIceGatherer(RTCIceGatherer):
    """Custom :class:`RTCIceGatherer` that uses :class:`PortRangeConnection`.

    Args:
        iceServers: ICE server list.
        port_range: ``(min, max)`` port range or ``None``.
        transport_policy: ``TransportPolicy.ALL`` or ``RELAY``.
    """

    def __init__(
        self,
        iceServers: Optional[List[RTCIceServer]] = None,
        port_range: Optional[Tuple[int, int]] = None,
        transport_policy: TransportPolicy = TransportPolicy.ALL,
    ) -> None:
        AsyncIOEventEmitter.__init__(self)

        if iceServers is None:
            iceServers = self.getDefaultIceServers()
        ice_kwargs = connection_kwargs(iceServers)

        self._connection = PortRangeConnection(
            ice_controlling=False,
            port_range=port_range,
            transport_policy=transport_policy,
            **ice_kwargs,
        )
        self._remote_candidates_end = False
        # RTCIceGatherer stores state as ``self.__state`` which Python
        # name-mangles to ``_RTCIceGatherer__state``.  We skip the
        # parent ``__init__`` (to inject our custom Connection), so we
        # must set the mangled attribute directly.
        self._RTCIceGatherer__state = "new"

        config_parts: list[str] = []
        if port_range:
            config_parts.append(f"port_range={port_range[0]}-{port_range[1]}")
        if transport_policy != TransportPolicy.ALL:
            config_parts.append(f"transport_policy={transport_policy.name}")
        if config_parts:
            logger.debug("Created PortRangeIceGatherer", config=", ".join(config_parts))


def create_port_range_gatherer_class(
    port_range: Optional[Tuple[int, int]] = None,
    transport_policy: TransportPolicy = TransportPolicy.ALL,
) -> type:
    """Create a custom ``RTCIceGatherer`` class with baked-in port range and transport policy.

    The returned class can be used to temporarily replace aiortc's
    ``RTCIceGatherer`` via :class:`PortRangeGathererPatch`.

    Args:
        port_range: ``(min, max)`` port tuple or ``None``.
        transport_policy: ``TransportPolicy.ALL`` or ``RELAY``.

    Returns:
        A class behaving like ``RTCIceGatherer`` but using
        :class:`PortRangeConnection`.
    """
    _port_range = port_range
    _transport_policy = transport_policy

    class _PortRangeGatherer(RTCIceGatherer):
        def __init__(
            self,
            iceServers: Optional[List[RTCIceServer]] = None,
            local_username: Optional[str] = None,
            local_password: Optional[str] = None,
        ) -> None:
            AsyncIOEventEmitter.__init__(self)

            if iceServers is None:
                iceServers = self.getDefaultIceServers()
            ice_kwargs = connection_kwargs(iceServers)

            self._connection = PortRangeConnection(
                ice_controlling=False,
                port_range=_port_range,
                transport_policy=_transport_policy,
                **ice_kwargs,
            )
            self._remote_candidates_end = False
            # See comment in PortRangeIceGatherer.__init__ re: name mangling.
            self._RTCIceGatherer__state = "new"

    return _PortRangeGatherer


# =============================================================================
# Monkey-patch context manager
# =============================================================================


class PortRangeGathererPatch:
    """Context manager that temporarily patches aiortc to use :class:`PortRangeIceGatherer`.

    ``RTCPeerConnection`` creates ``RTCIceGatherer`` instances internally
    and does not expose a way to customise port range or transport
    policy.  This context manager swaps the class reference in both
    aiortc modules where it is looked up.

    Usage::

        with PortRangeGathererPatch(port_range=(5000, 5100)):
            pc = RTCPeerConnection(...)
            await pc.setRemoteDescription(offer)
            answer = await pc.createAnswer()

    Args:
        port_range: ``(min, max)`` port tuple or ``None``.
        transport_policy: ``TransportPolicy.ALL`` (default) or ``RELAY``.
    """

    def __init__(
        self,
        port_range: Optional[Tuple[int, int]] = None,
        transport_policy: TransportPolicy = TransportPolicy.ALL,
    ) -> None:
        self.port_range = port_range
        self.transport_policy = transport_policy
        self._patched = False

    def __enter__(self):
        needs_patch = (
            self.port_range is not None or self.transport_policy != TransportPolicy.ALL
        )

        if needs_patch:
            patched_class = create_port_range_gatherer_class(
                port_range=self.port_range,
                transport_policy=self.transport_policy,
            )

            _rtcicetransport.RTCIceGatherer = patched_class
            _rtcpeerconnection.RTCIceGatherer = patched_class

            self._patched = True

            config_parts: list[str] = []
            if self.port_range is not None:
                config_parts.append(
                    f"port_range={self.port_range[0]}-{self.port_range[1]}"
                )
            if self.transport_policy != TransportPolicy.ALL:
                config_parts.append(f"transport_policy={self.transport_policy.name}")
            logger.debug("Patched RTCIceGatherer", config=", ".join(config_parts))
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        if self._patched:
            _rtcicetransport.RTCIceGatherer = _original_gatherer_class
            _rtcpeerconnection.RTCIceGatherer = _original_gatherer_class
            self._patched = False
            logger.debug("Restored original RTCIceGatherer")
        return False
