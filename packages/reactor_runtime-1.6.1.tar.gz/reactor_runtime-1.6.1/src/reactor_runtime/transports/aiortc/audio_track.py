"""
Output audio track for the aiortc transport.

Provides :class:`OutputAudioTrack` -- an aiortc
:class:`~aiortc.MediaStreamTrack` fed by the model via
:meth:`push_samples`.  The track converts NumPy int16 samples to
:class:`av.AudioFrame` objects that the aiortc encoder consumes in
:meth:`recv`.

Key design constraints (see DOCS.md and AUDIO_SYNC.md for rationale):

* **Opus consumes 960 samples every 20 ms (48 000/s) -- non-negotiable.**
  The push rate to the jitter buffer must match this consumption rate.
* **Clock-based timing**: ``recv()`` advances at real-time regardless
  of data availability, preventing PTS drift during pauses.
* **Absolute-clock timing**: ``recv()`` computes each deadline from
  an absolute start time (``_recv_start + _recv_count * 20 ms``).
  This prevents long-term PTS drift but means that after an event-loop
  stall, ``recv()`` will fire without sleeping until the frame count
  catches up to wall-clock time.
* **Fade transitions**: 64-sample cosine ramps at silence/audio
  boundaries eliminate clicks.
* **Jitter buffer priming**: 80 ms of accumulated samples before
  the track begins consuming, absorbing timing variance.

Copyright (c) 2026 Reactor Technologies, Inc. All rights reserved.
"""

import asyncio
import threading
import time
from fractions import Fraction
from typing import Optional

import numpy as np
from aiortc import MediaStreamTrack
from av import AudioFrame

from reactor_runtime.utils.log import get_logger

logger = get_logger(__name__)

# Default audio parameters matching typical WebRTC Opus configuration.
DEFAULT_SAMPLE_RATE = 48000
DEFAULT_CHANNELS = 1

# Opus encodes in 20 ms frames at 48 kHz -> 960 samples per frame.
SAMPLES_PER_FRAME = 960

# Duration of one Opus frame in seconds.
FRAME_DURATION = SAMPLES_PER_FRAME / DEFAULT_SAMPLE_RATE  # 0.02 s

# Jitter-buffer threshold: ``recv()`` outputs silence until the buffer
# has accumulated at least this many samples.  4 Opus frames = 3 840
# samples = 80 ms.  Must exceed the maximum intra-cycle buffer dip
# (≈ 2 880 samples at 15 fps emission) while staying small enough that
# the FIFO queuing delay roughly matches the video path's latency,
# preventing audible A/V desync.
_JITTER_BUFFER_SAMPLES = SAMPLES_PER_FRAME * 4

# Number of samples for fade-in / fade-out ramps at buffering
# boundaries.  64 samples = 1.3 ms at 48 kHz -- short enough to be
# inaudible as a volume change, long enough to eliminate clicks.
_FADE_SAMPLES = 64

# Maximum buffer length in samples.  Excess is dropped (oldest first)
# to cap latency.  1 second at 48 kHz = 48 000.
MAX_BUFFER_SAMPLES = 48000


class OutputAudioTrack(MediaStreamTrack):
    """Audio track that outputs samples provided via :meth:`push_samples`.

    Designed to be fed audio data from the model's output.  Thread-safe
    for :meth:`push_samples` calls from external threads.

    The track uses a **jitter buffer**: it accumulates at least
    :data:`_JITTER_BUFFER_SAMPLES` before it begins consuming, which
    absorbs the variable push timing of the emission loop and prevents
    buffer underruns (and the pops that come with them).

    Timing is clock-based: ``recv()`` targets exactly 20 ms intervals
    (one Opus frame duration) regardless of whether data is available.
    This prevents PTS drift when the model is paused.

    Args:
        stop_event: Shared stop event for cooperative shutdown.
        sample_rate: Audio sample rate in Hz (default 48 000).
        channels: Number of audio channels (default 1 -- mono).
    """

    kind = "audio"

    def __init__(
        self,
        stop_event: threading.Event,
        sample_rate: int = DEFAULT_SAMPLE_RATE,
        channels: int = DEFAULT_CHANNELS,
    ) -> None:
        super().__init__()
        self._stop_event = stop_event
        self._sample_rate = sample_rate
        self._channels = channels
        self._time_base = Fraction(1, sample_rate)

        # Internal sample buffer: flat int16 array
        self._buffer = np.empty(0, dtype=np.int16)
        self._buffer_lock = threading.Lock()

        # PTS counter in sample units
        self._pts: int = 0

        # Clock-based timing: absolute start time and call counter
        # for drift-free pacing (same approach as aiortc's
        # VideoStreamTrack.next_timestamp).
        self._recv_start: Optional[float] = None

        # Jitter-buffer state
        self._buffering: bool = True
        self._fade_in_next: bool = False

        # Diagnostic counters
        self._push_count: int = 0
        self._recv_count: int = 0
        self._recv_full: int = 0
        self._recv_silence: int = 0
        self._max_buffer_seen: int = 0

        logger.info(
            "OutputAudioTrack created",
            sample_rate=sample_rate,
            channels=channels,
            samples_per_frame=SAMPLES_PER_FRAME,
            jitter_buffer=_JITTER_BUFFER_SAMPLES,
            max_buffer_samples=MAX_BUFFER_SAMPLES,
        )

    # -----------------------------------------------------------------
    # Public API
    # -----------------------------------------------------------------

    def push_samples(self, samples: np.ndarray) -> bool:
        """Append audio samples to the internal buffer.

        Thread-safe -- can be called from any thread.

        Args:
            samples: NumPy ``int16`` array of shape ``(1, N)`` (mono) or
                ``(C, N)`` (multi-channel).  The data is flattened into
                the internal buffer in row-major order.

        Returns:
            ``True`` if the samples were enqueued, ``False`` if stopped.
        """
        if self._stop_event.is_set():
            return False

        flat = samples.flatten().astype(np.int16, copy=False)
        self._push_count += 1

        with self._buffer_lock:
            buf_before = len(self._buffer)
            self._buffer = np.concatenate([self._buffer, flat])

            # Cap the buffer to prevent unbounded growth.  Drop oldest
            # samples so the newest audio stays close to real-time.
            max_len = MAX_BUFFER_SAMPLES * self._channels
            trimmed = False
            if len(self._buffer) > max_len:
                self._buffer = self._buffer[-max_len:]
                trimmed = True

            buf_after = len(self._buffer)
            if buf_after > self._max_buffer_seen:
                self._max_buffer_seen = buf_after

        if trimmed:
            # Only log trim periodically -- it's expected during bursts
            if self._push_count <= 5 or self._push_count % 100 == 0:
                logger.warning(
                    "Audio buffer trimmed",
                    dropped=buf_before + len(flat) - buf_after,
                    buf=buf_after,
                )

        return True

    async def recv(self) -> AudioFrame:
        """Return the next audio frame for the aiortc encoder.

        Uses **clock-based timing**: each call sleeps until exactly
        20 ms after the previous return.

        A **jitter buffer** prevents underruns: ``recv()`` outputs
        silence until the buffer has accumulated at least
        :data:`_JITTER_BUFFER_SAMPLES`.  Once primed, frames are
        served straight from the buffer.  If the buffer empties the
        track re-enters buffering mode.

        Returns:
            An :class:`av.AudioFrame` in ``s16`` format.
        """
        needed = SAMPLES_PER_FRAME * self._channels

        # ----------------------------------------------------------
        # Clock-based pacing (absolute deadline)
        # ----------------------------------------------------------
        now = time.monotonic()
        if self._recv_start is None:
            self._recv_start = now

        deadline = self._recv_start + self._recv_count * FRAME_DURATION
        sleep_time = deadline - now
        if sleep_time > 0:
            await asyncio.sleep(sleep_time)

        # ----------------------------------------------------------
        # Consume samples from the buffer
        # ----------------------------------------------------------
        path: str
        remaining: int = 0

        with self._buffer_lock:
            available = len(self._buffer)

            if self._buffering:
                if available >= _JITTER_BUFFER_SAMPLES:
                    self._buffering = False
                    self._fade_in_next = True
                    logger.debug(
                        "Jitter buffer primed",
                        available=available,
                    )
                else:
                    raw = np.zeros(needed, dtype=np.int16)
                    path = "buffering"
                    self._recv_silence += 1
                    remaining = len(self._buffer)

            # Not an ``else`` so the freshly-primed path falls through.
            if not self._buffering:
                if available >= needed:
                    raw = self._buffer[:needed].copy()
                    self._buffer = self._buffer[needed:]
                    path = "full"
                    self._recv_full += 1

                    if self._fade_in_next:
                        fade_len = min(_FADE_SAMPLES, needed)
                        fade = np.linspace(0.0, 1.0, fade_len)
                        raw[:fade_len] = (
                            raw[:fade_len].astype(np.float32) * fade
                        ).astype(np.int16)
                        self._fade_in_next = False

                elif available > 0:
                    # Partial -- serve what we have with a fade-out ramp,
                    # then re-enter buffering.
                    raw = np.zeros(needed, dtype=np.int16)
                    raw[:available] = self._buffer[:available]

                    fade_len = min(_FADE_SAMPLES, available)
                    if fade_len > 0:
                        fade = np.linspace(1.0, 0.0, fade_len)
                        raw[available - fade_len : available] = (
                            raw[available - fade_len : available].astype(np.float32)
                            * fade
                        ).astype(np.int16)

                    self._buffer = np.empty(0, dtype=np.int16)
                    self._buffering = True
                    path = f"drain({available})"
                    self._recv_full += 1

                else:
                    raw = np.zeros(needed, dtype=np.int16)
                    self._buffering = True
                    path = "silence"
                    self._recv_silence += 1

                remaining = len(self._buffer)

        self._recv_count += 1

        if path.startswith("drain") or path == "silence":
            logger.debug("Audio underflow", path=path, buf=available)

        if self._recv_count % 500 == 0:
            logger.debug(
                "Audio jitter buffer",
                buf=remaining,
                full=self._recv_full,
                silence=self._recv_silence,
                max_seen=self._max_buffer_seen,
            )

        # ----------------------------------------------------------
        # Build and return the AudioFrame
        # ----------------------------------------------------------
        frame = AudioFrame(
            format="s16",
            layout="mono" if self._channels == 1 else "stereo",
            samples=SAMPLES_PER_FRAME,
        )
        frame.planes[0].update(raw.tobytes())
        frame.pts = self._pts
        frame.sample_rate = self._sample_rate
        frame.time_base = self._time_base
        self._pts += SAMPLES_PER_FRAME

        return frame

    # -----------------------------------------------------------------
    # Lifecycle
    # -----------------------------------------------------------------

    def cleanup(self) -> None:
        """Release internal buffers."""
        with self._buffer_lock:
            self._buffer = np.empty(0, dtype=np.int16)
        self._buffering = True
        self._fade_in_next = False
