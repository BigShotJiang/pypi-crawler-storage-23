"""
aiortc-based WebRTC transport implementation.

This package is an **internal** implementation detail of the transports
layer.  Runtime code should never import from here directly -- use
:class:`~reactor_runtime.transports.WebRTCTransport` with
:attr:`~reactor_runtime.transports.TransportType.AIORTC` instead.
"""

from reactor_runtime.transports.aiortc.client import AiortcTransport

__all__ = ["AiortcTransport"]
