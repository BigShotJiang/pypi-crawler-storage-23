"""
Transport-agnostic event types for WebRTC transports.

All transport implementations emit these same event types, so runtime
code can register handlers without knowing which backend is in use.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import TYPE_CHECKING, Callable, Optional

import numpy as np

if TYPE_CHECKING:
    from reactor_runtime.transports.media import MediaBundle

# =============================================================================
# Exceptions
# =============================================================================


class WebRTCSupersededError(Exception):
    """Raised when a WebRTC client is stopped/superseded during setup."""

    pass


class WebRTCNoVideoError(Exception):
    """Raised when an SDP offer does not include video support.

    The Reactor runtime requires video in every WebRTC session.  When a
    transport detects that the remote offer contains no video media
    section, it raises this error so that the runtime can silently drop
    the connection attempt without advancing the state machine.
    """

    pass


# =============================================================================
# Event Type Enum
# =============================================================================


class EventType(Enum):
    """Enumeration of all event types emitted by a WebRTC transport.

    Use these values when registering handlers via
    :meth:`~transports.interface.WebRTCTransport.on`::

        transport.on(EventType.CONNECTED, my_handler)
        transport.on(EventType.MESSAGE, on_message)
    """

    CONNECTED = "connected"
    DISCONNECTED = "disconnected"
    MESSAGE = "message"
    VIDEO_FRAME = "video_frame"
    MEDIA_BUNDLE = "media_bundle"
    PING_TIMEOUT = "ping_timeout"


# =============================================================================
# Event Dataclasses
# =============================================================================


@dataclass
class WebRTCEvent:
    """Base class for WebRTC events.

    Every event carries an :attr:`event_type` that identifies which kind
    of event it is.  Subclasses set this automatically.
    """

    event_type: EventType


@dataclass
class ConnectedEvent(WebRTCEvent):
    """Emitted when WebRTC connection is established."""

    event_type: EventType = field(default=EventType.CONNECTED, init=False)


@dataclass
class DisconnectedEvent(WebRTCEvent):
    """Emitted when WebRTC connection is closed or failed."""

    event_type: EventType = field(default=EventType.DISCONNECTED, init=False)
    reason: str = "unknown"


@dataclass
class MessageEvent(WebRTCEvent):
    """Emitted when a data channel message is received."""

    event_type: EventType = field(default=EventType.MESSAGE, init=False)
    data: str = ""


@dataclass
class VideoFrameEvent(WebRTCEvent):
    """Emitted when an incoming video frame is received.

    ``track_name`` is the MID-derived name of the track that produced
    this frame (e.g. ``"webcam"``).
    """

    event_type: EventType = field(default=EventType.VIDEO_FRAME, init=False)
    frame: np.ndarray = field(default_factory=lambda: np.array([]))
    track_name: str = "video"


@dataclass
class MediaBundleEvent(WebRTCEvent):
    """Emitted when a synchronised multi-track media bundle is ready.

    Carries a :class:`~reactor_runtime.transports.media.MediaBundle`
    containing one or more named track payloads.
    """

    event_type: EventType = field(default=EventType.MEDIA_BUNDLE, init=False)
    media_bundle: Optional["MediaBundle"] = field(default=None)


@dataclass
class PingTimeoutEvent(WebRTCEvent):
    """Emitted when the client stops sending pings within the expected interval."""

    event_type: EventType = field(default=EventType.PING_TIMEOUT, init=False)
    elapsed: float = 0.0  # seconds since the last ping


# =============================================================================
# Handler Type Alias
# =============================================================================

EventHandler = Callable[[WebRTCEvent], None]
