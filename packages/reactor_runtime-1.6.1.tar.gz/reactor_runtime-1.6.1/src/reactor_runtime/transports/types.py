"""
Transport-agnostic types for WebRTC transport implementations.

This module defines the types shared between all transport implementations
and consumed by the runtime layer. Runtime code should use these types
instead of implementation-specific types (e.g. aiortc's RTCIceServer).
"""

from dataclasses import dataclass
from enum import Enum


class TransportType(Enum):
    """Available transport implementations.

    Each variant maps to ``(module_path, class_name)`` for dynamic import.
    Adding a new transport only requires a new enum variant -- if the
    backing module is not installed the import fails only when that
    variant is actually used, not at import time.
    """

    AIORTC = ("reactor_runtime.transports.aiortc", "AiortcTransport")
    GSTREAMER = ("reactor_runtime.transports.gstreamer", "GStreamerTransport")

    def __init__(self, module_path: str, class_name: str) -> None:
        self._module_path = module_path
        self._class_name = class_name

    @property
    def module_path(self) -> str:
        """Fully-qualified module path for the transport implementation."""
        return self._module_path

    @property
    def class_name(self) -> str:
        """Class name of the transport implementation within the module."""
        return self._class_name


class IceTransportPolicy(Enum):
    """ICE transport policy controlling which candidate types are gathered.

    ``ALL`` gathers host, server-reflexive, and relay candidates.
    ``RELAY`` gathers only relay (TURN) candidates, forcing all traffic
    through a TURN server.
    """

    ALL = "all"
    RELAY = "relay"


@dataclass
class IceServer:
    """Transport-agnostic ICE server configuration.

    Attributes:
        urls: One or more STUN/TURN URLs
            (e.g. ``["stun:stun.l.google.com:19302"]``).
        username: Optional username for TURN authentication.
        credential: Optional credential/password for TURN authentication.
    """

    urls: list[str]
    username: str | None = None
    credential: str | None = None


@dataclass
class TransportConfig:
    """Configuration bundle passed to the transport factory.

    Attributes:
        ice_servers: Optional list of ICE server configurations. If ``None``,
            the implementation should fall back to a sensible default (e.g.
            Google's public STUN server).
        port_range: Optional ``(min_port, max_port)`` tuple restricting
            the UDP port range used for ICE candidates.
        transport_policy: ICE transport policy. Defaults to ``ALL``.
    """

    ice_servers: list[IceServer] | None = None
    port_range: tuple[int, int] | None = None
    transport_policy: IceTransportPolicy = IceTransportPolicy.ALL


@dataclass
class SessionDescription:
    """Transport-agnostic SDP session description.

    Attributes:
        sdp: The SDP string.
        type: The SDP type (e.g. ``"offer"`` or ``"answer"``).
    """

    sdp: str
    type: str
