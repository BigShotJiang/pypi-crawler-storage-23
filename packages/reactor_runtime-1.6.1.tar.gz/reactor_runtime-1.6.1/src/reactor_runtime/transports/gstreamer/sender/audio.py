# Copyright (c) 2026 Reactor Technologies, Inc. All rights reserved.

"""
Audio sender: appsrc ! audioconvert ! audiorate ! encoder.
"""

from typing import Dict, Optional

from reactor_runtime.transports.gstreamer.encoders import EncoderFactory
from reactor_runtime.transports.gstreamer.gst import Gst
from reactor_runtime.transports.gstreamer.gst_helpers import (
    add_many,
    link_many,
    link_pads,
    make_element,
)

from .base import _SenderStreamBase


class AudioSender(_SenderStreamBase):
    """
    A Gst.Bin for audio sender: appsrc ! audioconvert ! audiorate ! encoder.

    The encoder is created via :class:`EncoderFactory`. The bin exposes
    a ghost pad on the encoder's src so it can be linked downstream
    (e.g. to webrtcbin).
    """

    def __init__(
        self,
        encoding_name: str,
        pt: int,
        format: Dict[str, Optional[str]],
        name: str = "audio_sender",
    ):
        super().__init__(name=name)

        self._appsrc = make_element("appsrc", "appsrc")
        self._appsrc.set_property("format", Gst.Format.TIME)
        self._appsrc.set_property("is-live", True)
        self._appsrc.set_property("do-timestamp", True)
        self._appsrc.set_property("block", True)

        audioconvert = make_element("audioconvert", "audioconvert")
        audiorate = make_element("audiorate", "audiorate")
        encoder = EncoderFactory.create(encoding_name, pt, format)

        add_many(
            self,
            self._appsrc,
            audioconvert,
            audiorate,
            encoder,
            sync_with_parent=True,
        )
        link_many(self._appsrc, audioconvert, audiorate)
        link_pads(audiorate.get_static_pad("src"), encoder.pad_sink())

        encoder_src = encoder.pad_src()
        if not encoder_src:
            raise RuntimeError("encoder has no src pad")
        ghost_src = Gst.GhostPad.new("src", encoder_src)
        if not ghost_src or not self.add_pad(ghost_src):
            raise RuntimeError("Failed to add ghost src pad to AudioSender")
        self._ghost_src: Gst.GhostPad = ghost_src
