# Copyright (c) 2026 Reactor Technologies, Inc. All rights reserved.

"""
Video sender: appsrc ! videoconvert ! queue ! encoder ! bwe.
"""

from typing import Dict, Optional

from reactor_runtime.transports.gstreamer.encoders import EncoderFactory
from reactor_runtime.transports.gstreamer.gst import Gst
from reactor_runtime.transports.gstreamer.gst_helpers import (
    add_many,
    link_many,
    link_pads,
    make_element,
)
from reactor_runtime.utils.log import get_logger

from .base import _SenderStreamBase

logger = get_logger(__name__)

# BWE bitrate defaults (kbps) when using rtpgccbwe
_DEFAULT_MIN_BITRATE_Kbps = 500
_DEFAULT_MAX_BITRATE_Kbps = 10000
_DEFAULT_BITRATE_Kbps = 4000


class VideoSender(_SenderStreamBase):
    """
    A Gst.Bin for video sender: appsrc ! videoconvert ! queue ! encoder ! bwe.

    The encoder is created via :class:`EncoderFactory`. The bin exposes
    a ghost pad on the bwe element's src so it can be linked downstream
    (e.g. to webrtcbin).
    """

    def __init__(
        self,
        encoding_name: str,
        pt: int,
        format: Dict[str, Optional[str]],
        name: str = "video_sender",
        min_bitrate_kbps: int = _DEFAULT_MIN_BITRATE_Kbps,
        max_bitrate_kbps: int = _DEFAULT_MAX_BITRATE_Kbps,
    ):
        super().__init__(name=name)

        self._appsrc = make_element("appsrc", "appsrc")
        self._appsrc.set_property("format", Gst.Format.TIME)
        self._appsrc.set_property("is-live", True)
        self._appsrc.set_property("do-timestamp", True)
        self._appsrc.set_property("block", True)

        videoconvert = make_element("videoconvert", "videoconvert")
        queue_el = make_element("queue", "queue")
        queue_el.set_property("max-size-buffers", 1)
        queue_el.set_property("leaky", "downstream")

        self._encoder = EncoderFactory.create(encoding_name, pt, format)
        self._current_bitrate_kbps = _DEFAULT_BITRATE_Kbps
        self._min_bitrate_kbps = min_bitrate_kbps
        self._max_bitrate_kbps = max_bitrate_kbps

        if Gst.ElementFactory.find("rtpgccbwe") is not None:
            bwe = make_element("rtpgccbwe", "bwe")
            bwe.set_property("min-bitrate", min_bitrate_kbps * 1000)
            bwe.set_property("max-bitrate", max_bitrate_kbps * 1000)
            bwe.connect(
                "notify::estimated-bitrate",
                self._on_bitrate_estimate,
            )
        else:
            bwe = make_element("identity", "identity")
            bwe.set_property("signal-handoffs", False)

        add_many(
            self,
            self._appsrc,
            videoconvert,
            queue_el,
            self._encoder,
            bwe,
            sync_with_parent=True,
        )
        link_many(self._appsrc, videoconvert, queue_el)
        link_pads(queue_el.get_static_pad("src"), self._encoder.pad_sink())
        link_pads(self._encoder.pad_src(), bwe.get_static_pad("sink"))

        bwe_src = bwe.get_static_pad("src")
        if not bwe_src:
            raise RuntimeError("bwe element has no src pad")
        ghost_src = Gst.GhostPad.new("src", bwe_src)
        if not ghost_src or not self.add_pad(ghost_src):
            raise RuntimeError("Failed to add ghost src pad to VideoSender")
        self._ghost_src: Gst.GhostPad = ghost_src

    def _on_bitrate_estimate(self, element: Gst.Element, pspec: object) -> None:
        """Handle bitrate estimate from rtpgccbwe (Google Congestion Control)."""
        estimated = element.get_property("estimated-bitrate")
        new_bitrate_kbps = estimated // 1000  # Convert to kbps

        # Only update if change is significant (>5%)
        if abs(new_bitrate_kbps - self._current_bitrate_kbps) > (
            self._current_bitrate_kbps * 0.05
        ):
            old_bitrate = self._current_bitrate_kbps
            new_bitrate_kbps = max(
                self._min_bitrate_kbps,
                min(self._max_bitrate_kbps, new_bitrate_kbps),
            )
            self._current_bitrate_kbps = new_bitrate_kbps

            self._encoder.set_target_bitrate(new_bitrate_kbps * 1000)
            direction = "↑" if new_bitrate_kbps > old_bitrate else "↓"
            logger.info(
                f"GCC bitrate {direction} {old_bitrate} → {new_bitrate_kbps} kbps"
            )
