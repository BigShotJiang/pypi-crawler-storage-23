# Copyright (c) 2026 Reactor Technologies, Inc. All rights reserved.

"""
Base class for sender bins (audio and video).
"""

from reactor_runtime.transports.gstreamer.gst import Gst
from reactor_runtime.transports.gstreamer.gst_helpers import link_pads


class _SenderStreamBase(Gst.Bin):
    """
    Base for sender bins. Subclasses build their pipeline and set
    self._appsrc and self._ghost_src.
    """

    def __init__(self, name: str):
        super().__init__(name=name)

    def get_appsrc(self) -> Gst.Element:
        """Return the internal appsrc element (e.g. to set caps)."""
        return self._appsrc

    def push_buffer(self, buf: Gst.Buffer) -> Gst.FlowReturn:
        """
        Push a buffer to the appsrc.

        Must be called from the thread that runs the GStreamer main loop.
        The caller is responsible for setting appsrc caps before pushing
        buffers with matching format.

        Returns:
            The flow return from appsrc (e.g. Gst.FlowReturn.OK).
        """
        return self._appsrc.emit("push-buffer", buf)

    def get_src_pad(self) -> Gst.Pad:
        """Return the bin's ghost src pad for linking downstream."""
        return self._ghost_src

    def link_src_to(self, sink_pad: Gst.Pad) -> None:
        """
        Link this bin's src pad to the given sink pad.

        Equivalent to: link_pads(self.get_src_pad(), sink_pad)
        """
        link_pads(self.get_src_pad(), sink_pad)
