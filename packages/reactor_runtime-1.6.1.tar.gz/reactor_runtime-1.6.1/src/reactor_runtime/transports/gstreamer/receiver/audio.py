# Copyright (c) 2026 Reactor Technologies, Inc. All rights reserved.

"""
Audio receiver: audio_decoder ! audioconvert ! capsfilter ! appsink.

Supports Opus via rtpopusdepay ! opusdec. Other codecs can be added later.
"""

from reactor_runtime.transports.gstreamer.gst import Gst
from reactor_runtime.transports.gstreamer.gst_helpers import (
    add_many,
    link_many,
    link_pads,
    make_element,
)

from .base import _ReceiverStreamBase


class AudioReceiver(_ReceiverStreamBase):
    """
    A Gst.Bin for audio receiver: audio_decoder ! audioconvert ! capsfilter ! appsink.

    For Opus (encoding_name="OPUS"): rtpopusdepay ! opusdec ! audioconvert ! capsfilter ! appsink.
    The bin exposes a ghost sink pad (RTP input) so it can be linked from a source pad
    (e.g. webrtcbin src). Use :meth:`set_on_new_sample` to set a callback when a new
    decoded frame is available.
    """

    def __init__(
        self,
        encoding_name: str,
        name: str = "audio_receiver",
    ):
        super().__init__(name=name)

        encoding_upper = encoding_name.upper()
        if encoding_upper == "OPUS":
            depay = make_element("rtpopusdepay", "rtpopusdepay")
            decoder = make_element("opusdec", "opusdec")
            add_many(self, depay, decoder, sync_with_parent=True)
            link_many(depay, decoder)
            first_sink = depay.get_static_pad("sink")
            last_src = decoder.get_static_pad("src")
        else:
            raise ValueError(
                "Unsupported audio encoding-name for receiver: %r" % encoding_name
            )

        audioconvert = make_element("audioconvert", "consumer_audioconvert")
        capsfilter = make_element("capsfilter", "audio_caps")
        capsfilter.set_property(
            "caps",
            Gst.Caps.from_string("audio/x-raw,format=S16LE,rate=48000,channels=2"),
        )
        self._appsink = make_element("appsink", "appsink")
        self._appsink.set_property("emit-signals", True)
        self._appsink.set_property("sync", False)
        self._appsink.set_property("max-buffers", 1)
        self._appsink.set_property("wait-on-eos", False)
        self._appsink.connect("new-sample", self._on_new_sample)

        add_many(
            self,
            audioconvert,
            capsfilter,
            self._appsink,
            sync_with_parent=True,
        )
        link_many(audioconvert, capsfilter, self._appsink)
        link_pads(last_src, audioconvert.get_static_pad("sink"))

        if not first_sink:
            raise RuntimeError("decoder/depay has no sink pad")
        ghost_sink = Gst.GhostPad.new("sink", first_sink)
        if not ghost_sink or not self.add_pad(ghost_sink):
            raise RuntimeError("Failed to add ghost sink pad to AudioReceiver")
        self._ghost_sink: Gst.GhostPad = ghost_sink
