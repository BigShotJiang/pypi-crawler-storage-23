from reactor_runtime.transports.gstreamer.gst import Gst
from reactor_runtime.transports.gstreamer.gst_helpers import (
    make_element,
    try_set_property,
)
from .base import BaseEncoderBin


class H265EncoderBin(BaseEncoderBin):
    """
    Encoder bin implementing:

        sink -> H265 encoder (NVENC or x265) ->
        rtph265pay(pt=...) -> src

    Designed for RTP/WebRTC pipelines.

    Notes:
        - H265 (HEVC) is not widely supported in browsers,
          but may be used in controlled environments.
        - No parser element is inserted here (unlike H264),
          assuming encoder produces RTP-compatible output.
        - Real-time tuning is critical to prevent latency buildup.
    """

    def __init__(
        self,
        pt: int,
        name: str = "h265_encoder_bin",
        initial_bitrate_bps: int = 1_500_000,
        key_int_max: int = 30,
        threads: int = 4,
        x265_speed_preset: str = "ultrafast",
        x265_tune: str = "zerolatency",
    ):
        """
        Args:
            pt:
                RTP payload type negotiated in SDP.

            key_int_max:
                Maximum GOP size (distance between keyframes).
                Smaller values improve recovery but increase bitrate.

            x265_speed_preset:
                Controls compression speed vs quality (x265 only).

            x265_tune:
                Usually "zerolatency" for WebRTC use cases.
        """
        super().__init__(name=name)

        self._pt = int(pt)

        # ---------------------------------------------------------
        # Prefer hardware encoder if available (NVENC),
        # fallback to software x265.
        # ---------------------------------------------------------
        self._enc_factory = self._pick_encoder_factory()

        self._enc = make_element(self._enc_factory, self._enc_factory)

        # RTP payloader
        self._pay = make_element("rtph265pay", "rtph265pay")

        # ---------------------------------------------------------
        # Apply real-time tuning
        # ---------------------------------------------------------
        if self._enc_factory == "nvh265enc":
            self._apply_nvenc_realtime_tuning(key_int_max=key_int_max)

            # NVENC typically expects bitrate in kbps
            self._set_bitrate_property(
                self._enc,
                initial_bitrate_bps,
                prefer_target_bitrate_bps=False,
                fallback_bitrate_is_kbps=True,
            )
        else:
            # Software x265 tuning
            self._apply_x265_realtime_tuning(
                key_int_max=key_int_max,
                threads=threads,
                speed_preset=x265_speed_preset,
                tune=x265_tune,
            )

            self._set_bitrate_property(
                self._enc,
                initial_bitrate_bps,
                prefer_target_bitrate_bps=False,
                fallback_bitrate_is_kbps=True,
            )

        # Set RTP payload type to match SDP negotiation
        self._pay.set_property("pt", self._pt)

        # config-interval=1 ensures VPS/SPS/PPS are periodically sent.
        # Important for:
        #   - Mid-stream decoder join
        #   - Recovery after packet loss
        try_set_property(self._pay, "config-interval", 1)

        # ---------------------------------------------------------
        # Build internal pipeline
        # ---------------------------------------------------------
        self.add(self._enc)
        self.add(self._pay)

        if not self._enc.link(self._pay):
            raise RuntimeError("Failed to link %s -> rtph265pay" % self._enc_factory)

        enc_sink = self._enc.get_static_pad("sink")
        pay_src = self._pay.get_static_pad("src")

        if not enc_sink or not pay_src:
            raise RuntimeError("Failed to fetch sink/src pads")

        # Expose ghost pads so bin behaves like a simple element:
        #   raw video in → RTP H265 out
        self._create_ghost_pads(enc_sink, pay_src)

    def _pick_encoder_factory(self) -> str:
        """
        Select encoder implementation:

            - nvh265enc (GPU-accelerated, preferred for performance)
            - x265enc (software fallback)

        Hardware encoding significantly reduces CPU load,
        especially at higher resolutions.
        """
        if Gst.ElementFactory.find("nvh265enc") is not None:
            return "nvh265enc"
        return "x265enc"

    def _apply_x265_realtime_tuning(
        self,
        key_int_max: int,
        threads: int,
        speed_preset: str,
        tune: str,
    ) -> None:
        """
        Configure x265 for low-latency operation.

        Important parameters:
            tune=zerolatency → disables lookahead
            key-int-max      → limits GOP size
            bframes=0        → avoids latency increase
        """
        try_set_property(self._enc, "speed-preset", speed_preset)
        try_set_property(self._enc, "tune", tune)
        try_set_property(self._enc, "key-int-max", int(key_int_max))
        try_set_property(self._enc, "threads", int(threads))

        # Disable B-frames (critical for low latency)
        try_set_property(self._enc, "bframes", 0)
        try_set_property(self._enc, "max-bframes", 0)

    def _apply_nvenc_realtime_tuning(self, key_int_max: int) -> None:
        """
        Configure NVIDIA NVENC for low-latency streaming.

        Key points:
            - CBR rate control
            - No B-frames
            - Frequent IDR frames
            - Repeated VPS/SPS/PPS insertion
        """
        try_set_property(self._enc, "zerolatency", True)
        try_set_property(self._enc, "rc-mode", "cbr")
        try_set_property(self._enc, "rate-control", "cbr")

        try_set_property(self._enc, "gop-size", int(key_int_max))
        try_set_property(self._enc, "iframeinterval", int(key_int_max))

        # Disable B-frames (adds latency)
        try_set_property(self._enc, "bframes", 0)
        try_set_property(self._enc, "max-bframes", 0)

        # Low-latency presets
        try_set_property(self._enc, "preset", "low-latency-hq")
        try_set_property(self._enc, "preset", "low-latency")
        try_set_property(self._enc, "tuning-info", "low-latency")

        # Ensure parameter sets are repeated in stream
        # Required for RTP interoperability
        try_set_property(self._enc, "repeat-sequence-header", True)
        try_set_property(self._enc, "insert-vps-sps-pps", True)
        try_set_property(self._enc, "insert-sps-pps", True)

    def set_target_bitrate(self, bitrate_bps: int) -> None:
        """
        Dynamically update encoder bitrate.

        Typically used with:
            - Transport-CC
            - REMB feedback
            - Custom congestion control

        Does not require SDP renegotiation.
        """
        self._set_bitrate_property(
            self._enc,
            bitrate_bps,
            prefer_target_bitrate_bps=False,
            fallback_bitrate_is_kbps=True,
        )
