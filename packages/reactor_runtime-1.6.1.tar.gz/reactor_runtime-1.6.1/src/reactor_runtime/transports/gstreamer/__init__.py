"""
GStreamer-based WebRTC transport implementation.

This package is an **internal** implementation detail of the transports
layer.  Runtime code should never import from here directly -- use
:class:`~reactor_runtime.transports.WebRTCTransport` with
:attr:`~reactor_runtime.transports.TransportType.GSTREAMER` instead.
"""

from reactor_runtime.transports.gstreamer.client import GStreamerTransport

__all__ = ["GStreamerTransport"]
