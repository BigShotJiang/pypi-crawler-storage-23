from reactor_runtime.transports.gstreamer.gst_helpers import (
    make_element,
    try_set_property,
)
from .base import BaseRTPDecoderBin


class VP8DecoderBin(BaseRTPDecoderBin):
    """
    RTP decoder bin implementing:

        sink (RTP VP8) ->
        rtpvp8depay ->
        vp8dec ->
        src (raw video)

    Designed for use with:
        - webrtcbin src pads
        - rtpbin receive chains
        - Custom RTP demux pipelines

    VP8 is widely supported and generally robust in WebRTC scenarios.
    """

    def __init__(self, name: str = "vp8_decoder_bin"):
        super().__init__(name=name)

        # ---------------------------------------------------------
        # RTP depayloader
        # ---------------------------------------------------------
        # Converts RTP packets into elementary VP8 bitstream.
        self._depay = make_element("rtpvp8depay", "rtpvp8depay")

        # ---------------------------------------------------------
        # VP8 decoder (libvpx based)
        # ---------------------------------------------------------
        # Produces raw video (typically I420).
        self._dec = make_element("vp8dec", "vp8dec")

        # ---------------------------------------------------------
        # Best-effort low-latency tuning
        # ---------------------------------------------------------
        # Decoders usually expose fewer knobs than encoders.
        # Threads can help parallel decoding on multi-core systems.
        try_set_property(self._dec, "threads", 4)

        # ---------------------------------------------------------
        # Build internal pipeline
        # ---------------------------------------------------------
        self.add(self._depay)
        self.add(self._dec)

        # Ensure depayloader output links correctly into decoder
        self._link_or_raise(self._depay, self._dec, "rtpvp8depay -> vp8dec")

        # ---------------------------------------------------------
        # Expose ghost pads
        # ---------------------------------------------------------
        # sink  → RTP input
        # src   → raw decoded video output
        depay_sink = self._depay.get_static_pad("sink")
        dec_src = self._dec.get_static_pad("src")

        if not depay_sink or not dec_src:
            raise RuntimeError("Failed to fetch sink/src pads")

        # Ghost pads allow this bin to behave like:
        #     RTP in → raw video out
        self._create_ghost_pads(depay_sink, dec_src)
