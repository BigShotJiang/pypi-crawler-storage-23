from reactor_runtime.transports.gstreamer.gst_helpers import (
    make_element,
    try_set_property,
)
from .base import BaseRTPDecoderBin


class VP9DecoderBin(BaseRTPDecoderBin):
    """
    RTP decoder bin implementing:

        sink (RTP VP9) ->
        rtpvp9depay ->
        vp9dec ->
        src (raw video)

    Designed for WebRTC receive pipelines.

    Notes:
        - VP9 profile handling is implicit: depayloader extracts profile
          information from RTP payload and passes it to vp9dec.
        - Decoder must tolerate dynamic resolution changes.
    """

    def __init__(self, name: str = "vp9_decoder_bin"):
        super().__init__(name=name)

        # ---------------------------------------------------------
        # RTP depayloader
        # ---------------------------------------------------------
        # Converts RTP VP9 packets into VP9 elementary bitstream.
        # Handles RTP-specific framing and aggregation.
        self._depay = make_element("rtpvp9depay", "rtpvp9depay")

        # ---------------------------------------------------------
        # VP9 decoder (libvpx based)
        # ---------------------------------------------------------
        # Produces raw video (I420 / Y444 / 10-bit variants depending on profile).
        self._dec = make_element("vp9dec", "vp9dec")

        # ---------------------------------------------------------
        # Best-effort low-latency tuning
        # ---------------------------------------------------------
        # Increase decoder threading to improve performance on multi-core systems.
        # Useful for higher resolutions (e.g., 1080p+).
        try_set_property(self._dec, "threads", 8)

        # ---------------------------------------------------------
        # Build internal pipeline
        # ---------------------------------------------------------
        self.add(self._depay)
        self.add(self._dec)

        # Ensure depayloader output links correctly into decoder.
        self._link_or_raise(self._depay, self._dec, "rtpvp9depay -> vp9dec")

        # ---------------------------------------------------------
        # Expose ghost pads
        # ---------------------------------------------------------
        # sink → RTP input
        # src  → raw decoded frames
        depay_sink = self._depay.get_static_pad("sink")
        dec_src = self._dec.get_static_pad("src")

        if not depay_sink or not dec_src:
            raise RuntimeError("Failed to fetch sink/src pads")

        # Ghost pads allow the bin to behave like a single element:
        #     RTP in → raw video out
        self._create_ghost_pads(depay_sink, dec_src)
