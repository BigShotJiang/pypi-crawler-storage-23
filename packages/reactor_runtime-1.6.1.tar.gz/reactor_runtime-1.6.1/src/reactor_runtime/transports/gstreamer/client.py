"""
GStreamer-based WebRTC transport implementation.

:class:`GStreamerTransport` implements the
:class:`~reactor_runtime.transports.interface.WebRTCTransport` ABC using
the ``GStreamer`` library.  All GStreamer-specific details (peer connection,
ICE gathering, data channels, pipelines, GObject connections) are encapsulated
here and **never** leak to runtime code.

.. note::

    ``send_media()`` currently forwards only the first video track from
    the :class:`MediaBundle` to the GStreamer appsrc.  Audio tracks are
    silently dropped.  Full multi-track support will require routing
    bundle tracks to separate GStreamer pads.
"""

import asyncio
import json
import threading
import queue
from dataclasses import dataclass
from typing import List, Optional, Tuple, Union, Any, Set, Dict
from urllib.parse import quote
from os import environ

import numpy as np

from reactor_runtime.transports.config import DEFAULT_STUN_SERVER
from reactor_runtime.transports.events import (
    ConnectedEvent,
    DisconnectedEvent,
    MessageEvent,
    VideoFrameEvent,
    WebRTCSupersededError,
)
from reactor_runtime.transports.interface import WebRTCTransport
from reactor_runtime.transports.media import MediaBundle, TrackKind
from reactor_runtime.transports.types import (
    IceServer,
    IceTransportPolicy,
    SessionDescription,
    TransportConfig,
)

from reactor_runtime.utils.log import get_logger
from reactor_runtime.transports.gstreamer.gst import Gst, GstSdp, GLib, GstWebRTC
from reactor_runtime.transports.gstreamer.gst_helpers import (
    add_many,
    link_pads,
    make_element,
)
from reactor_runtime.transports.gstreamer.signals import SignalManager
from reactor_runtime.transports.gstreamer.sender import VideoSender, AudioSender
from reactor_runtime.transports.gstreamer.receiver import VideoReceiver, AudioReceiver
from reactor_runtime.transports.gstreamer.sdp import (
    get_video_codec_from_sdp,
    detect_bundle_policy_from_sdp,
    fix_sdp_to_max_compat_if_bundle_invalid,
    normalize_sdp_for_supported_codecs,
    strip_ice_candidates_from_sdp,
)
from reactor_runtime.transports.gstreamer.sdp.ice import IceCandidate
from reactor_cli.utils.config import MAX_VALID_PORT, MIN_VALID_PORT

logger = get_logger(__name__)


# Default STUN server used when no custom ICE servers are configured
# ICE Gathering
ICE_GATHERING_TIMEOUT = 3000

# =============================================================================
# Helpers for converting transport-agnostic types to GStreamer expected ones
# =============================================================================


def _to_stun_turn_uris(servers: List[IceServer]) -> Tuple[List[str], List[str]]:
    """
    Convert IceServer configs into RFC-style URI lists:

      - STUN:
          "stun:host:port"   -> "stun://host:port"
          "stuns:host:port"  -> "stuns://host:port"
          (no credentials in STUN URIs)

      - TURN:
          "turn:host:port?transport=udp"  -> "turn://host:port?transport=udp"
          "turns:host:port?transport=tcp" -> "turns://host:port?transport=tcp"
          If username+credential are provided in IceServer, embed as:
              "turn://user:pass@host:port?transport=udp"

    Notes:
      - Credentials are percent-encoded to keep URIs valid.
      - Unknown schemes are ignored.
      - If a URL is already in "//" form, it is preserved (except credential injection for TURN).
    """
    stun_uris: List[str] = []
    turn_uris: List[str] = []

    def _split_scheme(rest: str) -> tuple[str, str]:
        # Split "stun:foo" into ("stun", "foo")
        i = rest.find(":")
        if i < 0:
            return "", rest
        return rest[:i].lower(), rest[i + 1 :]

    def _normalize_authority_url(raw: str) -> tuple[str, str, str]:
        """
        Returns: (scheme, authority_with_path, query_string_without_question_mark)

        Accepts:
          - "stun:host:port"
          - "turn:host:port?transport=udp"
          - "stun://host:port"
          - "turn://host:port?transport=udp"
        """
        raw = raw.strip()
        scheme, after = _split_scheme(raw)
        if not scheme:
            return "", "", ""

        # Handle already RFC-style: "scheme://..."
        if after.startswith("//"):
            # after == "//authority[?query]"
            authority_and_more = after[2:]
        else:
            # after == "authority[?query]" in legacy form
            authority_and_more = after

        if "?" in authority_and_more:
            authority, query = authority_and_more.split("?", 1)
        else:
            authority, query = authority_and_more, ""

        authority = authority.strip()
        query = query.strip()
        return scheme, authority, query

    for server in servers:
        user = server.username
        cred = server.credential

        for raw in server.urls:
            scheme, authority, query = _normalize_authority_url(raw)
            if scheme in ("stun", "stuns"):
                # STUN never includes credentials; just normalize to scheme://authority
                if not authority:
                    continue
                uri = f"{scheme}://{authority}"
                if query:
                    uri += f"?{query}"
                stun_uris.append(uri)
                continue

            if scheme not in ("turn", "turns"):
                continue

            if not authority:
                continue

            # Inject credentials for TURN if provided; otherwise just normalize.
            if user and cred:
                u = quote(user, safe="")
                p = quote(cred, safe="")
                uri = f"{scheme}://{u}:{p}@{authority}"
            else:
                uri = f"{scheme}://{authority}"

            if query:
                uri += f"?{query}"

            turn_uris.append(uri)

    return stun_uris, turn_uris


def _to_gst_transport_policy(
    policy: IceTransportPolicy,
) -> GstWebRTC.WebRTCICETransportPolicy:
    """Map :class:`IceTransportPolicy` to ``GstWebRTC.WebRTCICETransportPolicy``."""
    if policy == IceTransportPolicy.RELAY:
        return GstWebRTC.WebRTCICETransportPolicy.RELAY
    return GstWebRTC.WebRTCICETransportPolicy.ALL


# ---------------------------------------------------------------------------
# Internal queues
# ---------------------------------------------------------------------------


@dataclass
class _QueuedFrame:
    data: bytes
    w: int
    h: int
    duplicate: bool


# =============================================================================
# GStreamerTransport
# =============================================================================


class GStreamerTransport(WebRTCTransport):
    """WebRTC transport backed by the ``GStreamer`` library.

    Manages a single WebRTC connection lifecycle on a dedicated thread
    with its own GMain event loop.  Cooperative shutdown via a stop
    event allows fast superseding of connections.

    Do **not** instantiate directly -- use
    :meth:`WebRTCTransport.create`.
    """

    def __init__(self) -> None:
        super().__init__()

        """
        Initialize the WebRTC client.
        Do not call directly - use create() factory method.
        """

        # GStreamer initialization
        Gst.init(None)
        major, minor, micro, nano = Gst.version()
        logger.info(f"GStreamer version: {major}.{minor}.{micro} (nano={nano})")

        # Thread-safe stop flag
        self._stop_event = threading.Event()
        self._stopping = False

        # asyncio bridge
        self._loop: Optional[asyncio.AbstractEventLoop] = None
        self._gst_ready_fut: Optional[asyncio.Future[None]] = None
        self._answer_fut: Optional[asyncio.Future[str]] = None

        # GLib/GStreamer thread + dedicated context/loop
        self._gst_thread: Optional[threading.Thread] = None
        self._main_loop: Optional[GLib.MainLoop] = None
        self._main_ctx: Optional[GLib.MainContext] = None
        self._main_loop_ready = threading.Event()

        self._gst_sources: Set[GLib.Source] = set()
        self._gst_sources_lock = threading.Lock()

        # Pipeline objects (GLib thread only)
        self._pipeline: Optional[Gst.Pipeline] = None
        # Sender streams by name/mid
        self._video_senders: Dict[str, VideoSender] = {}
        self._audio_senders: Dict[str, AudioSender] = {}
        self._video_receivers: Dict[str, VideoReceiver] = {}
        self._audio_receivers: Dict[str, AudioReceiver] = {}
        self._webrtc: Optional[Gst.Element] = None
        self._data_channel = None

        # ICE
        self._ice_agent: Optional[GstWebRTC.WebRTCICE] = None
        self._remote_candidates: List[IceCandidate] = []
        self._ice_gathering_timeout_source: Optional[GLib.Source] = None
        self._transport_policy: GstWebRTC.WebRTCICETransportPolicy = (
            GstWebRTC.WebRTCICETransportPolicy.ALL
        )

        # Outgoing frame queue (thread-safe producer, GLib consumer)
        self._frame_q: "queue.Queue[_QueuedFrame]" = queue.Queue(maxsize=2)

        # GLib main loop (runs GStreamer event processing)
        self._signals = SignalManager()

        # Connection state
        self._connected = threading.Event()

        # Track if we were superseded (stopped during setup)
        self._was_superseded = False

        # Optional port range for ICE UDP binding
        self._port_range: Optional[Tuple[int, int]] = None

        # Answer future for async waiting
        self._answer_sdp: Optional[str] = None

        # Incoming video frame info
        self._incoming_width = 0
        self._incoming_height = 0

        # Frame timing/caps (GLib thread only)
        self._pts = 0
        self._frame_duration = Gst.SECOND // 30  # 30fps default
        self._outgoing_width = 0
        self._outgoing_height = 0

    # =========================================================================
    # Factory (implements the ABC hook)
    # =========================================================================

    @classmethod
    async def _create(
        cls,
        sdp_offer: str,
        sdp_type: str,
        config: Optional[TransportConfig],
    ) -> tuple["GStreamerTransport", SessionDescription]:
        """
        Create an :class:`GStreamerTransport` and perform the SDP exchange.
        """
        client = cls()

        ice_servers: Optional[List[IceServer]] = None
        if config:
            ice_servers = config.ice_servers
            client._port_range = config.port_range
            client._transport_policy = _to_gst_transport_policy(config.transport_policy)

        answer = await client._start_and_connect(sdp_offer, "offer", ice_servers)
        return client, answer

    # =========================================================================
    # Connection lifecycle
    # =========================================================================

    async def _start_and_connect(
        self,
        sdp_offer: str,
        sdp_type: str,
        ice_servers: Optional[List[IceServer]],
    ) -> SessionDescription:
        """
        Start the client thread and establish the WebRTC connection.

        Args:
            sdp_offer: The SDP offer string.
            sdp_type: The type of SDP.
            ice_servers: Optional list of ICE server configurations.

        Returns:
            The SDP answer.

        Raises:
            WebRTCSupersededError: If stop() was called during setup.
        """

        self._loop = asyncio.get_running_loop()
        self._gst_ready_fut = self._loop.create_future()
        self._answer_fut = self._loop.create_future()

        # Start GLib main loop thread
        self._gst_thread = threading.Thread(
            target=self._run_gst_thread,
            name="gst-thread",
            daemon=False,
        )

        logger.info(
            f"_start_and_connect() starting gst-thread [thread:{threading.current_thread().name}]"
        )
        self._gst_thread.start()

        # Wait for GLib main loop to be ready (no polling)
        logger.info(
            f"_start_and_connect() waiting for gst-thread to be ready [thread:{threading.current_thread().name}]"
        )
        await asyncio.wait_for(self._gst_ready_fut, timeout=5.0)

        if self._stop_event.is_set():
            raise WebRTCSupersededError("Client stopped before setup")

        # Schedule pipeline setup on GLib thread
        logger.info(
            f"_start_and_connect() trying to setup pipeline [thread:{threading.current_thread().name}]"
        )
        self._run_on_gst_thread(self._gst_setup_pipeline, sdp_offer, ice_servers)

        # Wait for answer SDP (no polling)
        logger.info(
            f"_start_and_connect() waiting for answer_sdp [thread:{threading.current_thread().name}]"
        )
        answer_sdp = await asyncio.wait_for(self._answer_fut, timeout=10.0)
        return SessionDescription(sdp=answer_sdp, type="answer")

    def _run_gst_thread(self) -> None:
        logger.info(f"_run_gst_thread() [thread:{threading.current_thread().name}]")

        # Create a dedicated MainContext for this thread (recommended)
        self._main_ctx = GLib.MainContext()
        self._main_ctx.push_thread_default()

        self._main_loop = GLib.MainLoop(context=self._main_ctx)

        # Signal readiness back to asyncio
        self._complete_future_threadsafe(self._gst_ready_fut, result=None)

        try:
            logger.info(
                f"_run_gst_thread() starting main loop [thread:{threading.current_thread().name}]"
            )
            self._main_loop.run()
        except Exception as e:
            self._fail_future_threadsafe(self._gst_ready_fut, e)
            self._fail_future_threadsafe(self._answer_fut, e)
        finally:
            try:
                self._main_ctx.pop_thread_default()
            except Exception:
                pass

    # =========================================================================
    # Thread-Safe Future helpers
    # =========================================================================

    def _complete_future_threadsafe(self, fut: Optional[asyncio.Future], result):
        loop = self._loop
        if loop is None or fut is None:
            return

        def _do():
            if not fut.done():
                fut.set_result(result)

        loop.call_soon_threadsafe(_do)

    def _fail_future_threadsafe(self, fut: Optional[asyncio.Future], exc: Exception):
        loop = self._loop
        if loop is None or fut is None:
            return

        def _do():
            if not fut.done():
                fut.set_exception(exc)

        loop.call_soon_threadsafe(_do)

    def _run_on_gst_thread(self, fn, *args, **kwargs) -> None:
        if self._main_ctx is None:
            return

        src = GLib.idle_source_new()
        self._track_source(src)

        def _cb(*_cb_args):
            try:
                if getattr(self, "_stopping", False):
                    return GLib.SOURCE_REMOVE

                fn(*args, **kwargs)

            except Exception as e:
                self._fail_future_threadsafe(self._answer_fut, e)
                try:
                    self._gst_request_stop()
                except Exception:
                    pass

            finally:
                self._untrack_source(src)

            return GLib.SOURCE_REMOVE  # False (one-shot)

        src.set_callback(_cb)
        src.attach(self._main_ctx)

    def _track_source(self, src: GLib.Source) -> None:
        with self._gst_sources_lock:
            self._gst_sources.add(src)

    def _untrack_source(self, src: GLib.Source) -> None:
        with self._gst_sources_lock:
            self._gst_sources.discard(src)

    # =========================================================================
    # GLib thread: Frame pushing (appsrc)
    # =========================================================================

    def _gst_arm_frame_pusher(self) -> None:
        if self._main_ctx is None:
            return

        def _drain(*_args) -> bool:
            if len(self._video_senders) == 0:
                return GLib.SOURCE_REMOVE

            if self._stopping:
                return GLib.SOURCE_REMOVE

            while True:
                try:
                    # TODO: make Queue send BundleMedia
                    item = self._frame_q.get_nowait()
                except queue.Empty:
                    break

                # When support BundleMedia, we need to send the frame to the correct video sender
                video_sender = self._video_senders["video_0"]

                # Caps changes happen only on GLib thread
                if item.w != self._outgoing_width or item.h != self._outgoing_height:
                    caps = Gst.Caps.from_string(
                        f"video/x-raw,format=RGB,width={item.w},height={item.h},framerate=30/1"
                    )
                    video_sender.get_appsrc().set_property("caps", caps)
                    self._outgoing_width = item.w
                    self._outgoing_height = item.h

                buf = Gst.Buffer.new_wrapped(item.data)
                buf.pts = self._pts
                buf.duration = self._frame_duration
                self._pts += self._frame_duration

                ret = video_sender.push_buffer(buf)
                if ret != Gst.FlowReturn.OK:
                    # Downstream might be stopping; just stop pushing
                    break

            return GLib.SOURCE_CONTINUE

        src = GLib.idle_source_new()
        self._track_source(src)
        src.set_callback(_drain)
        src.attach(self._main_ctx)

    def _require_webrtc(self) -> Gst.Element:
        if self._webrtc is None:
            raise RuntimeError("webrtcbin element is not initialized")
        return self._webrtc

    def _require_data_channel(self) -> Gst.Element:
        if self._data_channel is None:
            raise RuntimeError("DataChannel is not initialized")
        return self._data_channel

    # =========================================================================
    # GLib thread: Pipeline setup
    # =========================================================================
    def _gst_setup_pipeline(
        self,
        sdp_offer: str,
        ice_servers: Optional[List[IceServer]],
    ) -> None:
        """
        Setup GStreamer WebRTC pipeline using the offer.

        Args:
            sdp_offer: The SDP offer from the browser.

        """
        logger.info(f"_gst_setup_pipeline() [thread:{threading.current_thread().name}]")

        if self._stop_event.is_set():
            raise WebRTCSupersededError("Client stopped")

        # Create pipeline
        self._pipeline = Gst.Pipeline.new("pipeline")
        self._webrtc = make_element("webrtcbin", "webrtc")

        bundle_policy = detect_bundle_policy_from_sdp(sdp_offer)

        if bundle_policy.mode == "bundle-invalid":
            self._webrtc.set_property("bundle-policy", "max-compat")
            sdp_fixed, fixed_analysis = fix_sdp_to_max_compat_if_bundle_invalid(
                sdp_offer
            )

            logger.warning(
                f"Offer had invalid BUNDLE; trying to rewrite it to max-compat. Reason: {bundle_policy.reason}. SDP Offer: {sdp_offer}; SDP Fixed {sdp_fixed}"
            )

            sdp_offer = sdp_fixed
        else:
            self._webrtc.set_property("bundle-policy", bundle_policy.mode)

        # Normalize SDP for supported codecs
        sdp_offer = normalize_sdp_for_supported_codecs(sdp_offer)

        # Get video codec from SDP based on supported codecs list
        selected = get_video_codec_from_sdp(sdp_offer)
        encoding = selected["codec"]
        pt = selected["payload_type"]
        format = selected["parameters"]

        self._webrtc.set_property("latency", 30)

        # Setup ICE
        self._webrtc.set_property("ice-transport-policy", self._transport_policy)

        if ice_servers is not None:
            stun_servers, turn_uris = _to_stun_turn_uris(ice_servers)
            stun_server = stun_servers[0] if stun_servers else DEFAULT_STUN_SERVER
            self._webrtc.set_property("stun-server", stun_server)
            for turn_uri in turn_uris:
                self._webrtc.emit("add-turn-server", turn_uri)
        else:
            # Use default STUN server from google
            self._webrtc.set_property("stun-server", DEFAULT_STUN_SERVER)

        self._ice_agent = self._webrtc.get_property("ice-agent")
        if self._port_range is None:
            self._ice_agent.set_property("min-rtp-port", MIN_VALID_PORT)
            self._ice_agent.set_property("max-rtp-port", MAX_VALID_PORT)
        else:
            self._ice_agent.set_property("min-rtp-port", self._port_range[0])
            self._ice_agent.set_property("max-rtp-port", self._port_range[1])

        # This signal should be used for isolated test env (no influency related to user network)
        if _use_local_ip_addr():
            self._ice_agent.emit("add-local-ip-address", "127.0.0.1")

        self._pipeline.add(self._webrtc)

        # Create video sender
        video_sender = VideoSender(encoding, pt, format, name="video_0")

        self._video_senders["video_0"] = video_sender

        add_many(
            self._pipeline,
            video_sender,
            sync_with_parent=True,
        )

        webrtc_sinkpad = self._webrtc.request_pad_simple("sink_%u")
        if not webrtc_sinkpad:
            raise RuntimeError("Failed to request sink_%u pad from webrtcbin.")

        video_sender.link_src_to(webrtc_sinkpad)

        # Setup WebRTC handlers
        self._setup_webrtc_handlers()

        # Frame pusher (GLib thread)
        self._gst_arm_frame_pusher()

        # Start pipeline
        logger.info(
            f"_gst_setup_pipeline() set state to PLAYING [thread:{threading.current_thread().name}]"
        )
        ret = self._pipeline.set_state(Gst.State.PLAYING)
        if ret == Gst.StateChangeReturn.FAILURE:
            raise RuntimeError("Failed to start GStreamer pipeline")

        if self._stop_event.is_set():
            raise WebRTCSupersededError("Client stopped")

        # Set remote description (the offer)
        logger.info(
            f"_gst_setup_pipeline() set remote description [thread:{threading.current_thread().name}]"
        )
        self._gst_set_remote_description(sdp_offer)

    def _start_ice_gathering_timeout(self, time_ms=ICE_GATHERING_TIMEOUT) -> None:
        if self._ice_gathering_timeout_source is None:
            src = GLib.timeout_source_new(time_ms)

            def _cb(*_args):
                self._gst_on_ice_gathering_timeout()
                return False

            src.set_callback(_cb)
            src.attach(self._main_ctx)

            self._ice_gathering_timeout_source = src

    def _link_to_webrtc(self, element: Gst.Element):
        webrtc = self._require_webrtc()

        # Request pad no webrtcbin: sink_%u
        sinkpad = webrtc.request_pad_simple("sink_%u")
        if not sinkpad:
            raise RuntimeError("Failed to request sink_%u pad from webrtcbin.")

        srcpad = element.get_static_pad("src")
        if not srcpad:
            raise RuntimeError("Failed to get src pad from element.")

        if srcpad.link(sinkpad) != Gst.PadLinkReturn.OK:
            raise RuntimeError("Failed to link element -> webrtcbin(sink_%u).")

    def _setup_webrtc_handlers(self) -> None:
        """Setup signal handlers for webrtcbin."""
        webrtc = self._require_webrtc()
        self._signals.connect(webrtc, "on-data-channel", self._gst_on_data_channel)

        self._signals.connect(
            webrtc, "on-negotiation-needed", self._gst_on_negotiation_needed
        )
        self._signals.connect(webrtc, "on-ice-candidate", self._gst_on_ice_candidate)
        self._signals.connect(
            webrtc, "notify::ice-gathering-state", self._gst_on_ice_gathering_state
        )
        self._signals.connect(
            webrtc, "notify::ice-connection-state", self._gst_on_ice_connection_state
        )
        self._signals.connect(
            webrtc, "notify::connection-state", self._gst_on_connection_state
        )
        self._signals.connect(webrtc, "pad-added", self._gst_on_pad_added)

    def _setup_data_channel_handlers(self) -> None:
        """Setup handlers for the data channel."""
        data_channel = self._require_data_channel()

        self._signals.connect(data_channel, "on-open", self._gst_on_data_channel_open)
        self._signals.connect(data_channel, "on-close", self._gst_on_data_channel_close)
        self._signals.connect(
            data_channel, "on-message-string", self._gst_on_data_channel_message
        )

    # =========================================================================
    # WebRTC Signal Handlers
    # =========================================================================

    def _gst_on_negotiation_needed(self, element) -> None:
        """Handle negotiation-needed signal."""
        logger.debug("Negotiation needed")

    def _gst_on_ice_candidate(self, element, mline_index: int, candidate: str) -> None:
        """Handle ICE candidate (bundled in SDP, not trickled)."""
        logger.debug(f"ICE candidate: {candidate[:50]}...")

    def _gst_on_ice_gathering_state(self, element, pspec) -> None:
        """Handle ICE gathering state changes."""
        if self._stopping:
            return

        state = element.get_property("ice-gathering-state")
        logger.info(f"ICE gathering state: {state}")

        if state == GstWebRTC.WebRTCICEGatheringState.COMPLETE:
            self._gst_resolve_answer(reason="ice-completed")

    def _gst_on_connection_state(self, element, pspec) -> None:
        """Handle connection state changes."""
        if self._stopping:
            return

        state = element.get_property("connection-state")
        logger.info(f"Connection state: {state}")

        if state == GstWebRTC.WebRTCPeerConnectionState.CONNECTED:
            if not self._connected.is_set():
                self._connected.set()
                self._gst_emit_event(ConnectedEvent())
        elif state in (
            GstWebRTC.WebRTCPeerConnectionState.FAILED,
            GstWebRTC.WebRTCPeerConnectionState.CLOSED,
            GstWebRTC.WebRTCPeerConnectionState.DISCONNECTED,
        ):
            self._connected.clear()
            self._gst_emit_event(DisconnectedEvent(reason=str(state)))

    def _gst_on_ice_connection_state(self, element, pspec) -> None:
        """Handle ICE connection state changes."""
        if self._stopping:
            return

        state = element.get_property("ice-connection-state")
        logger.debug(
            f"_gst_on_ice_connection_state() ICE connection state changed [state:{state}]"
        )

    def _gst_on_ice_gathering_timeout(self) -> bool:
        logger.warning(
            "_gst_on_ice_gathering_timeout() trying to send answer with incomplete ICE"
        )

        self._gst_resolve_answer(reason="timeout")
        return False

    def _gst_on_data_channel(self, element, data_channel) -> None:
        logger.info("New data channel")
        self._data_channel = data_channel

        self._run_on_gst_thread(self._setup_data_channel_handlers)

    def _gst_on_pad_added(self, element, pad) -> None:
        if self._stopping or self._stop_event.is_set():
            return

        if pad.direction != Gst.PadDirection.SRC:
            return

        pad_name = pad.get_name()
        logger.debug(f"New incoming pad: {pad_name}")

        # Get the pad's capabilities to determine media type
        caps = pad.get_current_caps()
        if caps is None:
            # Try to get caps from pad template
            caps = pad.query_caps(None)

        if caps is None or caps.is_empty():
            logger.warning(f"No caps for pad {pad_name}")
            return

        struct = caps.get_structure(0)
        media_type = struct.get_name()

        # Only handle video (ignore audio for now)
        if not media_type.startswith("application/x-rtp"):
            logger.debug(f"Ignoring non-RTP pad: {media_type}")
            return

        # Check if it's video
        media = struct.get_string("media")
        if media != "video":
            logger.debug(f"Ignoring non-video media: {media}")
            return

        # Get encoding name to determine codec
        encoding = struct.get_string("encoding-name")
        logger.debug(f"Incoming video using {encoding} codec")

        mid = f"video_receiver_{pad_name}"
        video_receiver = VideoReceiver(encoding, name=mid)

        video_receiver.set_on_new_sample(self._gst_on_incoming_video_sample)

        self._video_receivers[mid] = video_receiver

        add_many(
            self._pipeline,
            video_receiver,
            sync_with_parent=True,
        )
        link_pads(pad, video_receiver.get_sink_pad())

    def _gst_on_incoming_video_sample(self, sink) -> Gst.FlowReturn:
        """
        Handle incoming decoded video frame from appsink.

        Converts GStreamer buffer to numpy array and emits VideoFrameEvent.
        """
        if self._stop_event.is_set() or self._stopping:
            return Gst.FlowReturn.EOS

        sample = sink.emit("pull-sample")
        if sample is None:
            return Gst.FlowReturn.OK

        buf = sample.get_buffer()
        caps = sample.get_caps()

        if buf is None or caps is None:
            return Gst.FlowReturn.OK

        # Get frame dimensions from caps
        struct = caps.get_structure(0)
        width = struct.get_int("width")[1]
        height = struct.get_int("height")[1]

        # Update dimensions if changed
        if width != self._incoming_width or height != self._incoming_height:
            logger.info(
                f"Video resolution changed: {self._incoming_width}x{self._incoming_height} -> {width}x{height}"
            )
            self._incoming_width = width
            self._incoming_height = height

        # Extract frame data
        success, map_info = buf.map(Gst.MapFlags.READ)
        if not success:
            return Gst.FlowReturn.OK

        try:
            # Create numpy array from buffer (RGB format)
            frame: np.ndarray = np.ndarray(
                shape=(height, width, 3), dtype=np.uint8, buffer=map_info.data
            ).copy()  # Copy to own the data

            # Emit video frame event
            self._gst_emit_event(VideoFrameEvent(frame=frame))

        finally:
            buf.unmap(map_info)

        return Gst.FlowReturn.OK

    # =========================================================================
    # Data Channel Handlers
    # =========================================================================

    def _gst_on_data_channel_open(self, channel) -> None:
        """Handle data channel open."""
        if self._stopping:
            return

        logger.info("Data channel opened")

    def _gst_on_data_channel_close(self, channel) -> None:
        """Handle data channel close."""
        logger.info("Data channel closed")

        if self._stopping is False:
            self._run_on_gst_thread(self._gst_request_stop)

    def _gst_on_data_channel_message(self, channel, message: str) -> None:
        """Handle incoming data channel message."""
        if self._stopping:
            return

        if not self._stop_event.is_set():
            self._gst_emit_event(MessageEvent(data=message))

    # =========================================================================
    # SDP Handling
    # =========================================================================

    def _gst_set_remote_description(self, sdp_offer: str) -> None:
        """Set the remote SDP description."""
        logger.debug(
            f"_gst_set_remote_description() [thread:{threading.current_thread().name}]"
        )
        webrtc = self._require_webrtc()

        sanitized_sdp, candidates = strip_ice_candidates_from_sdp(sdp_offer)
        self._remote_candidates = candidates

        res, sdpmsg = GstSdp.SDPMessage.new()
        GstSdp.sdp_message_parse_buffer(bytes(sanitized_sdp, "utf-8"), sdpmsg)

        offer = GstWebRTC.WebRTCSessionDescription.new(
            GstWebRTC.WebRTCSDPType.OFFER, sdpmsg
        )

        promise = Gst.Promise.new_with_change_func(self._gst_on_offer_set)
        logger.debug(
            f"_gst_set_remote_description() emitting set-remote-description with offer [thread:{threading.current_thread().name}]"
        )
        webrtc.emit("set-remote-description", offer, promise)

    def _gst_on_offer_set(self, p) -> None:
        """Callback when remote description is set."""
        logger.info(f"_gst_on_offer_set() [thread:{threading.current_thread().name}]")
        if self._webrtc is None:
            return

        self._run_on_gst_thread(self._gst_add_remote_candidates)

        # Create answer
        promise = Gst.Promise.new_with_change_func(self._gst_on_answer_created)
        logger.info(
            f"_gst_on_offer_set() emitting create-answer [thread:{threading.current_thread().name}]"
        )
        self._webrtc.emit("create-answer", None, promise)

    def _gst_on_answer_created(self, promise) -> None:
        """Callback when answer is created."""
        logger.info(
            f"_gst_on_answer_created() [thread:{threading.current_thread().name}]"
        )

        reply = promise.get_reply()

        if reply is None or self._webrtc is None:
            self._fail_future_threadsafe(
                self._answer_fut, RuntimeError("No reply for answer")
            )
            return

        answer = reply.get_value("answer")
        if answer is None:
            self._fail_future_threadsafe(
                self._answer_fut, RuntimeError("No answer in reply")
            )
            return

        # Set local description
        self._webrtc.emit("set-local-description", answer, None)

    def _gst_add_remote_candidates(self):
        logger.info(
            f"_gst_add_remote_candidates() [thread:{threading.current_thread().name}]"
        )

        bundle_policy = self._webrtc.get_property("bundle-policy")

        for c in self._remote_candidates:
            # if c.mline_index == 0:
            self._webrtc.emit(
                "add-ice-candidate",
                (
                    c.mline_index
                    if bundle_policy == GstWebRTC.WebRTCBundlePolicy.MAX_COMPAT
                    else 0
                ),
                c.candidate,
            )

        self._run_on_gst_thread(
            self._start_ice_gathering_timeout, ICE_GATHERING_TIMEOUT
        )

    def _gst_clear_ice_gathering_timeout(self) -> None:
        logger.info(
            f"_gst_clear_ice_gathering_timeout() [thread:{threading.current_thread().name}]"
        )
        if self._ice_gathering_timeout_source is not None:
            self._ice_gathering_timeout_source.destroy()
            self._ice_gathering_timeout_source = None

    def _gst_resolve_answer(self, reason: str) -> None:
        logger.info(
            f"_gst_resolve_answer() [reason:{reason}, thread:{threading.current_thread().name}]"
        )

        self._run_on_gst_thread(self._gst_clear_ice_gathering_timeout)

        webrtc = self._require_webrtc()
        local_desc = webrtc.get_property("local-description")
        if not local_desc:
            logger.warning("SDP ANSWER NOT READY!!!!")
            return

        answer_sdp = local_desc.sdp.as_text()
        self._answer_sdp = answer_sdp
        logger.info(
            f"_gst_resolve_answer() got sdp answer [thread:{threading.current_thread().name}]"
        )
        self._complete_future_threadsafe(self._answer_fut, answer_sdp)

    # =========================================================================
    # GStreamer thread: events
    # =========================================================================

    def _gst_emit_event(self, event: Any) -> None:
        """
        Thread-safe: schedule delivery on the asyncio loop thread.
        Can be called from Gst thread (or any thread).
        """
        loop = self._loop
        if loop is None:
            return

        loop.call_soon_threadsafe(self._emit_event, event)

    # =========================================================================
    # GStreamer thread: message sending
    # =========================================================================

    def _gst_send_datachannel_msg(self, text: str) -> None:
        if self._stopping or self._data_channel is None:
            return
        try:
            self._data_channel.emit("send-string", text)
        except Exception:
            pass

    # =========================================================================
    # Sending data (implements ABC)
    # =========================================================================

    def send_media(self, bundle: MediaBundle) -> bool:
        """Send a multi-track media bundle to the remote peer.

        Currently only the first video track is forwarded to the
        GStreamer appsrc.  Audio tracks are silently dropped.

        Thread-safe -- can be called from any thread.
        """
        if self._stop_event.is_set() or self._stopping:
            return False

        if len(self._video_senders) == 0:
            # Not ready yet; you can choose to buffer or reject
            return False

        video_tracks = bundle.get_tracks_by_kind(TrackKind.VIDEO)
        if not video_tracks:
            return False

        frame = video_tracks[0].data

        try:
            h, w = frame.shape[:2]
            data = frame.tobytes()
            try:
                self._frame_q.put_nowait(
                    _QueuedFrame(data=data, w=w, h=h, duplicate=False)
                )
            except queue.Full:
                return False
            return True
        except Exception as e:
            logger.warning(f"Failed to send frame: {e}")
            return False

    def send_message(self, data: Union[dict, str]) -> bool:
        """
        Send a message over the data channel.
        Thread-safe - can be called from any thread.

        Args:
            data: Dictionary to send as JSON, or string to send directly.

        Returns:
            True if message was sent, False if stopped or failed.
        """
        if self._stop_event.is_set() or self._stopping:
            return False
        text = json.dumps(data) if isinstance(data, dict) else data
        self._run_on_gst_thread(self._gst_send_datachannel_msg, text)
        return True

    # =========================================================================
    # Lifecycle (implements ABC)
    # =========================================================================

    def stop(self, timeout: float = 10.0) -> None:
        """
        Stop the WebRTC client.

        Args:
            timeout: Maximum time to wait for cleanup.
        """
        if self._stop_event.is_set():
            return

        self._stop_event.set()

        if not self._connected.is_set():
            self._was_superseded = True

        # Unblock any awaiters
        self._fail_future_threadsafe(
            self._answer_fut, WebRTCSupersededError("Client stopped")
        )
        self._fail_future_threadsafe(
            self._gst_ready_fut, WebRTCSupersededError("Client stopped")
        )

        # Schedule teardown on GLib thread
        if self._main_loop is not None and self._main_loop.is_running():
            self._run_on_gst_thread(self._gst_request_stop)

        # Join thread
        if self._gst_thread is not None and self._gst_thread.is_alive():
            self._gst_thread.join(timeout=timeout)
            if self._gst_thread.is_alive():
                logger.warning("GStreamer thread did not exit cleanly")

        self._gst_thread = None

    def _gst_destroy_all_sources(self) -> None:
        with self._gst_sources_lock:
            sources = list(self._gst_sources)
            self._gst_sources.clear()

        for src in sources:
            try:
                src.destroy()
            except Exception:
                pass

        if self._ice_gathering_timeout_source is not None:
            self._ice_gathering_timeout_source.destroy()
            self._ice_gathering_timeout_source = None

    def _gst_request_stop(self) -> None:
        """
        GLib thread only: begin shutdown sequence.
        """
        if self._stopping:
            return
        self._stopping = True

        self._gst_finalize_stop()

    def _gst_finalize_stop(self) -> None:
        """
        GLib thread only: set pipeline to NULL, drop refs, quit loop.
        """
        logger.info(f"_gst_finalize_stop() [thread:{threading.current_thread().name}]")
        try:
            self._gst_destroy_all_sources()

            self._signals.block_all()

            if self._pipeline is not None:
                self._pipeline.set_state(Gst.State.NULL)
                ret, cur, pend = self._pipeline.get_state(1 * Gst.SECOND)
                logger.info("NULL state result=%s cur=%s pend=%s", ret, cur, pend)

            self._signals.disconnect_all()
        finally:
            if self._main_loop is not None and self._main_loop.is_running():
                self._main_loop.quit()

    def is_connected(self) -> bool:
        """Return ``True`` if connected and not stopped."""
        return self._connected.is_set() and not self._stop_event.is_set()

    @property
    def is_stopped(self) -> bool:
        """``True`` if :meth:`stop` has been requested."""
        return self._stop_event.is_set()

    @property
    def was_superseded(self) -> bool:
        """``True`` if this transport was stopped during setup."""
        return self._was_superseded

    def __del__(self):
        """Ensure cleanup on garbage collection."""
        if not self._stop_event.is_set():
            try:
                self.stop(timeout=1.0)
            except Exception:
                pass


# =============================================================================
# Test environment helpers (local IP selection, GST test mode toggles)
# =============================================================================


def _use_local_ip_addr() -> bool:
    return environ.get("GST_TEST_ENV") == "true"
