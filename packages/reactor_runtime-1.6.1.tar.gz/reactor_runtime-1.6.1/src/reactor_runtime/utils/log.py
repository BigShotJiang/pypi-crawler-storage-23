"""Structured logging helpers for the Reactor Runtime.

Provides a thin wrapper around Python's :mod:`logging` that lets callers pass
``**kwargs`` which are automatically appended as ``key=value`` pairs:

    logger.info("Session created", session_id=sid, model=model_name)
    # => "Session created session_id=abc123 model=brightness-example"

This keeps call-sites concise while producing the same structured output that
the Go services emit via zerolog.
"""

import logging
from typing import Any

# Shared log format / date-format used across the runtime.
LOG_FORMAT = "%(asctime)s %(levelname)-8s %(name)s: %(message)s"
LOG_DATEFMT = "%Y-%m-%dT%H:%M:%S%z"

# Keep underscore-prefixed aliases so existing imports don't break.
_LOG_FORMAT = LOG_FORMAT
_LOG_DATEFMT = LOG_DATEFMT


class StructuredLogger:
    """Logger wrapper that formats ``**kwargs`` as ``key=value`` pairs."""

    __slots__ = ("_log",)

    def __init__(self, name: str) -> None:
        self._log: logging.Logger = logging.getLogger(name)

    # -- internal helpers --------------------------------------------------

    @staticmethod
    def _fmt(msg: str, kw: dict[str, Any]) -> str:
        if not kw:
            return msg
        pairs = " ".join(f"{k}={v}" for k, v in kw.items())
        return f"{msg} {pairs}"

    # -- public API --------------------------------------------------------

    def debug(self, msg: str, **kw: Any) -> None:
        if self._log.isEnabledFor(logging.DEBUG):
            self._log.debug(self._fmt(msg, kw))

    def info(self, msg: str, **kw: Any) -> None:
        if self._log.isEnabledFor(logging.INFO):
            self._log.info(self._fmt(msg, kw))

    def warning(self, msg: str, **kw: Any) -> None:
        if self._log.isEnabledFor(logging.WARNING):
            self._log.warning(self._fmt(msg, kw))

    def error(self, msg: str, **kw: Any) -> None:
        if self._log.isEnabledFor(logging.ERROR):
            self._log.error(self._fmt(msg, kw))

    def critical(self, msg: str, *, exc_info: bool = False, **kw: Any) -> None:
        self._log.critical(self._fmt(msg, kw), exc_info=exc_info)

    def exception(self, msg: str, **kw: Any) -> None:
        self._log.exception(self._fmt(msg, kw))

    # -- delegate common attributes so callers can still do e.g.
    #    ``logger.setLevel(...)`` when needed.

    @property
    def level(self) -> int:
        return self._log.level

    def setLevel(self, level: int) -> None:  # noqa: N802 – match stdlib API
        self._log.setLevel(level)

    def isEnabledFor(self, level: int) -> bool:  # noqa: N802
        return self._log.isEnabledFor(level)


def get_logger(name: str) -> StructuredLogger:
    """Return a :class:`StructuredLogger` for *name*.

    Typical usage at module level::

        from reactor_runtime.utils.log import get_logger

        logger = get_logger(__name__)
    """
    return StructuredLogger(name)
