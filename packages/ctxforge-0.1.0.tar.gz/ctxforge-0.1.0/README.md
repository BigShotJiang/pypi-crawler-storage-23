# ctxforge

AI project context standard and CLI tool — manage AI's project cognition like Poetry manages dependencies.

## Installation

```bash
pip install ctxforge
```

## Quick Start

```bash
cd your-project/
ctxforge init
ctxforge run "help me fix the auth bug"
```
