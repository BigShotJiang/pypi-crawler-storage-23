"""Tests for project scanner."""

from pathlib import Path

from ctxforge.analysis.scanner import scan_project


class TestScanProject:
    def test_basic_python_project(self, tmp_path: Path):
        """Scan a minimal Python project."""
        # Create project structure
        src = tmp_path / "src"
        src.mkdir()
        (src / "__init__.py").write_text("")
        (src / "main.py").write_text("print('hello')")
        (src / "utils.py").write_text("")
        (tmp_path / "pyproject.toml").write_text(
            '[project]\nname = "test-proj"\ndependencies = ["fastapi"]\n'
            '[build-system]\nbuild-backend = "hatchling.build"\n'
        )
        (tmp_path / "tests").mkdir()

        report = scan_project(tmp_path)

        assert report.project_name == tmp_path.name
        assert "python" in report.languages
        assert report.source_root == "src"
        assert report.test_root == "tests"
        assert "pyproject.toml" in report.config_files
        assert "fastapi" in report.frameworks

    def test_empty_directory(self, tmp_path: Path):
        """Scan an empty directory should not crash."""
        report = scan_project(tmp_path)
        assert report.project_name == tmp_path.name
        assert report.languages == []
