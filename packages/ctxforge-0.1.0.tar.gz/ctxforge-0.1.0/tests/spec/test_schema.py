"""Tests for cfproject.toml schema validation."""

import pytest

from ctxforge.spec.schema import CfProject, MetaConfig, ProjectConfig, TechConfig, StructureConfig


class TestMetaConfig:
    def test_default_spec_version(self):
        meta = MetaConfig()
        assert meta.spec_version == "1.0"

    def test_custom_spec_version(self):
        meta = MetaConfig(spec_version="2.0")
        assert meta.spec_version == "2.0"


class TestProjectConfig:
    def test_minimal(self):
        project = ProjectConfig(name="test")
        assert project.name == "test"
        assert project.description == ""
        assert project.tech.languages == []

    def test_full(self):
        project = ProjectConfig(
            name="my-app",
            description="A test app",
            version="1.0.0",
            tech=TechConfig(
                languages=["python"],
                frameworks=["fastapi"],
                runtime="python 3.12",
                package_manager="poetry",
            ),
            structure=StructureConfig(
                source_root="src/",
                entry_points=["src/main.py"],
                key_dirs={"src/api/": "API routes"},
            ),
        )
        assert project.tech.languages == ["python"]
        assert project.structure.key_dirs["src/api/"] == "API routes"


class TestCfProject:
    def test_minimal_valid(self):
        """Minimal cfproject.toml should be valid."""
        project = CfProject(
            project=ProjectConfig(name="test"),
        )
        assert project.meta.spec_version == "1.0"
        assert project.project.name == "test"

    def test_from_dict(self):
        """Should construct from a dict (simulating TOML parse)."""
        data = {
            "meta": {"spec_version": "1.0"},
            "project": {
                "name": "my-app",
                "description": "Test",
                "tech": {
                    "languages": ["python", "typescript"],
                    "frameworks": ["fastapi"],
                },
                "structure": {
                    "source_root": "src/",
                    "key_dirs": {
                        "src/api/": "API routes",
                        "src/models/": "Data models",
                    },
                },
            },
            "cli": {
                "detected": ["claude", "codex"],
                "active": "claude",
            },
        }
        project = CfProject.model_validate(data)
        assert project.project.tech.languages == ["python", "typescript"]
        assert project.cli is not None
        assert project.cli.active == "claude"

    def test_json_schema_export(self):
        """Should be able to export JSON Schema."""
        schema = CfProject.model_json_schema()
        assert "properties" in schema
        assert "project" in schema["properties"]
