"""Tests for cfproject.toml loading and validation."""

import pytest
from pathlib import Path

from ctxforge.spec.validator import load_cfproject, validate_cfproject
from ctxforge.exceptions import ProjectNotFoundError, InvalidProjectError


class TestValidateCfproject:
    def test_valid_minimal(self):
        data = {
            "meta": {"spec_version": "1.0"},
            "project": {"name": "test", "description": "A test"},
        }
        result = validate_cfproject(data)
        assert result.project.name == "test"

    def test_empty_dict(self):
        """Empty dict should still produce a valid CfProject with defaults."""
        result = validate_cfproject({})
        assert result.meta.spec_version == "1.0"
        assert result.project.name == ""

    def test_unknown_fields_ignored(self):
        """Unknown fields should not cause errors (forward compatibility)."""
        data = {
            "meta": {"spec_version": "1.0"},
            "project": {"name": "test", "description": ""},
            "future_section": {"key": "value"},
        }
        # Pydantic v2 ignores extra by default
        result = validate_cfproject(data)
        assert result.project.name == "test"


class TestLoadCfproject:
    def test_file_not_found(self, tmp_path: Path):
        with pytest.raises(ProjectNotFoundError):
            load_cfproject(tmp_path / "nonexistent.toml")

    def test_load_from_directory(self, tmp_path: Path):
        """Should auto-append cfproject.toml when given a directory."""
        toml_content = b'[meta]\nspec_version = "1.0"\n\n[project]\nname = "test"\n'
        (tmp_path / "cfproject.toml").write_bytes(toml_content)
        result = load_cfproject(tmp_path)
        assert result.project.name == "test"

    def test_load_from_file(self, tmp_path: Path):
        toml_path = tmp_path / "cfproject.toml"
        toml_content = b'[meta]\nspec_version = "1.0"\n\n[project]\nname = "direct"\n'
        toml_path.write_bytes(toml_content)
        result = load_cfproject(toml_path)
        assert result.project.name == "direct"
