"""Pydantic models for cfproject.toml — the ctxforge specification."""

from __future__ import annotations

from typing import Optional

from pydantic import BaseModel, Field

from ctxforge.analysis.scanner import ScanReport


# ─── Meta ────────────────────────────────────────────────────────────────────


class MetaConfig(BaseModel):
    spec_version: str = "1.0"


# ─── Project ─────────────────────────────────────────────────────────────────


class TechConfig(BaseModel):
    languages: list[str] = Field(default_factory=list)
    frameworks: list[str] = Field(default_factory=list)
    runtime: Optional[str] = None
    package_manager: Optional[str] = None


class IdentityConfig(BaseModel):
    type: Optional[str] = None  # backend-api | web-frontend | cli-tool | library | monorepo
    architecture_style: Optional[str] = None  # layered | hexagonal | microservices | ...
    maturity: Optional[str] = None  # prototype | development | production


class ConstraintsConfig(BaseModel):
    breaking_changes: Optional[bool] = None
    security_critical: Optional[bool] = None
    performance_sensitive: Optional[bool] = None
    test_required: Optional[bool] = None
    i18n: Optional[bool] = None


class StructureConfig(BaseModel):
    source_root: Optional[str] = None
    entry_points: list[str] = Field(default_factory=list)
    test_root: Optional[str] = None
    config_files: list[str] = Field(default_factory=list)
    key_dirs: dict[str, str] = Field(default_factory=dict)


class ProjectConfig(BaseModel):
    name: str = ""
    description: str = ""
    version: Optional[str] = None
    tech: TechConfig = Field(default_factory=TechConfig)
    structure: StructureConfig = Field(default_factory=StructureConfig)
    identity: Optional[IdentityConfig] = None
    constraints: Optional[ConstraintsConfig] = None

    @classmethod
    def from_scan_report(cls, report: ScanReport) -> ProjectConfig:
        """Build ProjectConfig from a static analysis ScanReport."""
        return cls(
            name=report.project_name,
            description="",
            tech=TechConfig(
                languages=report.languages,
                frameworks=report.frameworks,
                runtime=report.runtime,
                package_manager=report.package_manager,
            ),
            structure=StructureConfig(
                source_root=report.source_root,
                entry_points=report.entry_points,
                test_root=report.test_root,
                config_files=report.config_files,
                key_dirs=report.key_dirs,
            ),
        )


# ─── Conventions ─────────────────────────────────────────────────────────────


class ConventionsConfig(BaseModel):
    test_command: Optional[str] = None
    lint_command: Optional[str] = None
    format_command: Optional[str] = None
    commit_style: Optional[str] = None
    branch_strategy: Optional[str] = None


# ─── Context ─────────────────────────────────────────────────────────────────


class ContextOptionsConfig(BaseModel):
    auto_update: str = "review"  # "review" | "off"
    max_depth: int = 3
    exclude_patterns: list[str] = Field(
        default_factory=lambda: [
            "node_modules/",
            ".venv/",
            "__pycache__/",
            "*.pyc",
            ".git/",
        ]
    )


class ContextConfig(BaseModel):
    # top-level context file references (key = topic, value = relative path)
    files: dict[str, str] = Field(default_factory=dict)
    modules: dict[str, str] = Field(default_factory=dict)
    options: ContextOptionsConfig = Field(default_factory=ContextOptionsConfig)


# ─── CLI ─────────────────────────────────────────────────────────────────────


class CliToolConfig(BaseModel):
    command: str
    mode: Optional[str] = None
    flags: list[str] = Field(default_factory=list)


class CliConfig(BaseModel):
    detected: list[str] = Field(default_factory=list)
    active: Optional[str] = None
    tools: dict[str, CliToolConfig] = Field(default_factory=dict)


# ─── Top-level CfProject ────────────────────────────────────────────────────


class CfProject(BaseModel):
    meta: MetaConfig = Field(default_factory=MetaConfig)
    project: ProjectConfig = Field(default_factory=ProjectConfig)
    conventions: Optional[ConventionsConfig] = None
    context: ContextConfig = Field(default_factory=ContextConfig)
    cli: Optional[CliConfig] = None
