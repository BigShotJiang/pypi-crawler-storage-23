"""Load and validate cfproject.toml files."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from pydantic import ValidationError

from ctxforge.exceptions import InvalidProjectError, ProjectNotFoundError
from ctxforge.spec.schema import CfProject

try:
    import tomllib
except ModuleNotFoundError:
    import tomli as tomllib  # type: ignore[no-redef]


def load_cfproject(path: Path) -> CfProject:
    """Load and validate a cfproject.toml file.

    Args:
        path: Path to cfproject.toml or to the .cforge/ directory.

    Returns:
        Validated CfProject instance.

    Raises:
        ProjectNotFoundError: If the file doesn't exist.
        InvalidProjectError: If the file is malformed.
    """
    if path.is_dir():
        path = path / "cfproject.toml"

    if not path.exists():
        raise ProjectNotFoundError(f"cfproject.toml not found at {path}")

    try:
        with open(path, "rb") as f:
            data = tomllib.load(f)
    except Exception as e:
        raise InvalidProjectError(f"Failed to parse {path}: {e}") from e

    return validate_cfproject(data)


def validate_cfproject(data: dict[str, Any]) -> CfProject:
    """Validate a dict against the cfproject.toml schema.

    Args:
        data: Parsed TOML data.

    Returns:
        Validated CfProject instance.

    Raises:
        InvalidProjectError: If validation fails.
    """
    try:
        return CfProject.model_validate(data)
    except ValidationError as e:
        raise InvalidProjectError(f"Invalid cfproject.toml: {e}") from e
