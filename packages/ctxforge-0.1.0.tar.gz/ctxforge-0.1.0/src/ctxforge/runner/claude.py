"""Claude CLI runner (P1)."""
