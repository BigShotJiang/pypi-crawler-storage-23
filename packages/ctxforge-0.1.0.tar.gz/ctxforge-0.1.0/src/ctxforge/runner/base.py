"""CLI runner — abstract interface (P1)."""
