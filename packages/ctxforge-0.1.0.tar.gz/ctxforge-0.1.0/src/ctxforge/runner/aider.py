"""Aider CLI runner (P1)."""
