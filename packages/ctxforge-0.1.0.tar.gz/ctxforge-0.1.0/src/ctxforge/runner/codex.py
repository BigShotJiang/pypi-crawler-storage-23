"""Codex CLI runner (P1)."""
