"""Prompt builder — construct wrapped prompts with context (P1)."""
