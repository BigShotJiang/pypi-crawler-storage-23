"""CForge project — loads and holds project context (P1)."""
