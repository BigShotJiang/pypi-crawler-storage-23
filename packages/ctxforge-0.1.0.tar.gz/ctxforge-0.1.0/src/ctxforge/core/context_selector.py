"""Context selector — abstract interface and implementations (P1)."""
