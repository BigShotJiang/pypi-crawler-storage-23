"""Change detector — detect project changes for context updates (P4)."""
