"""ctxforge CLI application."""

import typer

from ctxforge.__version__ import __version__
from ctxforge.console.commands.init import init_command
from ctxforge.console.commands.review import review_command
from ctxforge.console.commands.run import run_command
from ctxforge.console.commands.update import update_command

app = typer.Typer(
    name="ctxrun",
    help="AI project context standard and CLI tool.",
    no_args_is_help=True,
    add_completion=False,
)


def version_callback(value: bool) -> None:
    if value:
        typer.echo(f"ctxforge {__version__}")
        raise typer.Exit()


@app.callback()
def main_callback(
    version: bool = typer.Option(
        False,
        "--version",
        "-V",
        help="Show version and exit.",
        callback=version_callback,
        is_eager=True,
    ),
) -> None:
    """AI project context standard and CLI tool."""


app.command(name="init")(init_command)
app.command(name="run")(run_command)
app.command(name="update")(update_command)
app.command(name="review")(review_command)


def main() -> None:
    app()
