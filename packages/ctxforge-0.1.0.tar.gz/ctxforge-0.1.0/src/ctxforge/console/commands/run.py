"""ctxforge run command."""

from typing import Optional

import typer
from rich.console import Console

console = Console()


def run_command(
    prompt: str = typer.Argument(..., help="The prompt to send to the AI CLI."),
    cli: Optional[str] = typer.Option(
        None,
        "--cli",
        help="Override the default AI CLI tool.",
    ),
) -> None:
    """Run a prompt through the AI CLI with project context injection."""
    console.print("[yellow]ctxforge run is not yet implemented (planned for P1).[/yellow]")
