"""ctxforge init command."""

from pathlib import Path

import typer
from rich.console import Console

from ctxforge.analysis.cli_detector import detect_ai_clis
from ctxforge.analysis.scanner import scan_project
from ctxforge.spec.schema import CfProject, CliConfig, ContextConfig, MetaConfig, ProjectConfig
from ctxforge.storage.context_writer import write_cfproject

console = Console()


def init_command(
    path: Path = typer.Argument(
        Path("."),
        help="Project root directory.",
        exists=True,
        file_okay=False,
        resolve_path=True,
    ),
) -> None:
    """Initialize ctxforge for a project. Analyzes the project and generates .cforge/ directory."""
    cforge_dir = path / ".cforge"
    if cforge_dir.exists():
        console.print("[yellow]Warning:[/yellow] .cforge/ already exists. Reinitializing.")

    console.print(f"[bold]Initializing ctxforge in[/bold] {path}\n")

    # Phase 1: Static analysis
    console.print("[dim]Phase 1: Static analysis...[/dim]")
    report = scan_project(path)

    console.print(f"  Languages: {', '.join(report.languages) or 'unknown'}")
    console.print(f"  Source root: {report.source_root or 'not detected'}")
    console.print(f"  Key dirs: {len(report.key_dirs)}")

    # Phase 1.5: CLI detection and user selection
    console.print("\n[dim]Detecting AI CLI tools...[/dim]")
    detected_clis = detect_ai_clis()

    if not detected_clis:
        console.print("[yellow]No AI CLI tools detected.[/yellow]")
        cli_config = CliConfig(detected=[], active=None)
    else:
        console.print(f"  Found: {', '.join(detected_clis)}")

        if len(detected_clis) == 1:
            active = detected_clis[0]
            console.print(f"  Using: [bold]{active}[/bold]")
        else:
            console.print("\nSelect default CLI:")
            for i, cli_name in enumerate(detected_clis, 1):
                console.print(f"  [{i}] {cli_name}")

            choice = typer.prompt("Choice", default="1")
            try:
                idx = int(choice) - 1
                active = detected_clis[idx]
            except (ValueError, IndexError):
                active = detected_clis[0]

        cli_config = CliConfig(detected=detected_clis, active=active)

    # Phase 3: Assemble output (no LLM in P0)
    console.print("\n[dim]Generating cfproject.toml...[/dim]")

    project_config = ProjectConfig.from_scan_report(report)
    cf_project = CfProject(
        meta=MetaConfig(),
        project=project_config,
        context=ContextConfig(),
        cli=cli_config,
    )

    cforge_dir.mkdir(exist_ok=True)
    write_cfproject(cforge_dir / "cfproject.toml", cf_project)

    console.print(f"\n[bold green]Done.[/bold green] Created {cforge_dir / 'cfproject.toml'}")
