"""ctxforge update command."""

from typing import Optional

import typer
from rich.console import Console

console = Console()


def update_command(
    target: Optional[str] = typer.Argument(
        None,
        help="Specific module to update (e.g. modules/auth).",
    ),
    full: bool = typer.Option(
        False,
        "--full",
        help="Full re-analysis instead of incremental update.",
    ),
) -> None:
    """Update project context incrementally."""
    console.print("[yellow]ctxforge update is not yet implemented (planned for P2).[/yellow]")
