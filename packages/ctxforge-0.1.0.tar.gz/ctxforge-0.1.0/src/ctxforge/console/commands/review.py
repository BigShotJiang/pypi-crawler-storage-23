"""ctxforge review command."""

import typer
from rich.console import Console

console = Console()


def review_command() -> None:
    """Review and approve pending context updates."""
    console.print("[yellow]ctxforge review is not yet implemented (planned for P4).[/yellow]")
