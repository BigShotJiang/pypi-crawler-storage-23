"""Git utilities (P1)."""
