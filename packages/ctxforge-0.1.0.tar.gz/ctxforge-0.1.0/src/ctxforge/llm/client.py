"""LLM client — litellm wrapper (P2)."""
