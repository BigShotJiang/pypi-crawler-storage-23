"""Top-level exceptions for ctxrun."""


class CForgeError(Exception):
    """Base exception for all ctxforge errors."""


class ProjectNotFoundError(CForgeError):
    """Raised when .cforge/ directory is not found."""


class InvalidProjectError(CForgeError):
    """Raised when cfproject.toml is invalid or malformed."""


class CliNotFoundError(CForgeError):
    """Raised when no AI CLI tool is detected."""
