"""Dependency file parser — extract frameworks, runtime, and package manager."""

from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from pathlib import Path

try:
    import tomllib
except ModuleNotFoundError:
    import tomli as tomllib  # type: ignore[no-redef]


# Known framework names to detect in dependency lists
KNOWN_FRAMEWORKS: dict[str, str] = {
    # Python
    "fastapi": "fastapi",
    "flask": "flask",
    "django": "django",
    "starlette": "starlette",
    "sqlalchemy": "sqlalchemy",
    "celery": "celery",
    "pytest": "pytest",
    "pydantic": "pydantic",
    # JavaScript / TypeScript
    "react": "react",
    "vue": "vue",
    "next": "next.js",
    "nuxt": "nuxt",
    "express": "express",
    "nestjs": "nestjs",
    "angular": "angular",
    "svelte": "svelte",
    # Go
    "gin": "gin",
    "echo": "echo",
    "fiber": "fiber",
    # Rust
    "actix-web": "actix-web",
    "axum": "axum",
    "tokio": "tokio",
}


@dataclass
class DependencyInfo:
    """Extracted dependency information."""

    dependencies: list[str] = field(default_factory=list)
    frameworks: list[str] = field(default_factory=list)
    runtime: str | None = None
    package_manager: str | None = None


def parse_dependencies(root: Path) -> DependencyInfo:
    """Parse dependency files in the project root.

    Tries each known dependency file format in order.
    """
    info = DependencyInfo()

    # Python: pyproject.toml
    pyproject = root / "pyproject.toml"
    if pyproject.exists():
        _parse_pyproject(pyproject, info)

    # Python: setup.py (basic extraction)
    setup_py = root / "setup.py"
    if setup_py.exists() and not info.package_manager:
        info.package_manager = "setuptools"

    # JavaScript: package.json
    package_json = root / "package.json"
    if package_json.exists():
        _parse_package_json(package_json, info)

    # Go: go.mod
    go_mod = root / "go.mod"
    if go_mod.exists():
        _parse_go_mod(go_mod, info)

    # Rust: Cargo.toml
    cargo_toml = root / "Cargo.toml"
    if cargo_toml.exists():
        _parse_cargo_toml(cargo_toml, info)

    # Detect frameworks from dependency names
    info.frameworks = _match_frameworks(info.dependencies)

    return info


def _parse_pyproject(path: Path, info: DependencyInfo) -> None:
    """Extract deps from pyproject.toml."""
    try:
        with open(path, "rb") as f:
            data = tomllib.load(f)
    except Exception:
        return

    # PEP 621 dependencies
    deps = data.get("project", {}).get("dependencies", [])
    for dep in deps:
        name = re.split(r"[>=<!\[\s;]", dep)[0].strip().lower()
        if name:
            info.dependencies.append(name)

    # Detect package manager
    build_backend = data.get("build-system", {}).get("build-backend", "")
    if "poetry" in build_backend:
        info.package_manager = "poetry"
    elif "hatchling" in build_backend:
        info.package_manager = "hatch"
    elif "setuptools" in build_backend:
        info.package_manager = "setuptools"
    elif "flit" in build_backend:
        info.package_manager = "flit"

    # Poetry-style deps
    poetry_deps = data.get("tool", {}).get("poetry", {}).get("dependencies", {})
    for name in poetry_deps:
        if name.lower() != "python":
            info.dependencies.append(name.lower())

    # Detect Python version
    python_req = data.get("project", {}).get("requires-python", "")
    if python_req:
        match = re.search(r"(\d+\.\d+)", python_req)
        if match:
            info.runtime = f"python {match.group(1)}"


def _parse_package_json(path: Path, info: DependencyInfo) -> None:
    """Extract deps from package.json."""
    try:
        with open(path) as f:
            data = json.load(f)
    except Exception:
        return

    for section in ["dependencies", "devDependencies"]:
        for name in data.get(section, {}):
            # Strip scope prefix
            clean = name.lstrip("@").split("/")[-1] if "/" in name else name
            info.dependencies.append(clean.lower())

    # Detect package manager
    if (path.parent / "pnpm-lock.yaml").exists():
        info.package_manager = "pnpm"
    elif (path.parent / "yarn.lock").exists():
        info.package_manager = "yarn"
    elif (path.parent / "bun.lockb").exists():
        info.package_manager = "bun"
    else:
        info.package_manager = "npm"

    # Detect runtime
    engines = data.get("engines", {})
    node_version = engines.get("node", "")
    if node_version:
        match = re.search(r"(\d+)", node_version)
        if match:
            info.runtime = f"node {match.group(1)}"


def _parse_go_mod(path: Path, info: DependencyInfo) -> None:
    """Extract deps from go.mod."""
    try:
        content = path.read_text()
    except Exception:
        return

    info.package_manager = "go modules"

    # Extract go version
    match = re.search(r"^go\s+(\d+\.\d+)", content, re.MULTILINE)
    if match:
        info.runtime = f"go {match.group(1)}"

    # Extract require statements
    for m in re.finditer(r"require\s+(\S+)", content):
        module = m.group(1).split("/")[-1].lower()
        info.dependencies.append(module)


def _parse_cargo_toml(path: Path, info: DependencyInfo) -> None:
    """Extract deps from Cargo.toml."""
    try:
        with open(path, "rb") as f:
            data = tomllib.load(f)
    except Exception:
        return

    info.package_manager = "cargo"
    info.runtime = "rust"

    for name in data.get("dependencies", {}):
        info.dependencies.append(name.lower())


def _match_frameworks(dependencies: list[str]) -> list[str]:
    """Match dependency names against known frameworks."""
    found: list[str] = []
    seen: set[str] = set()
    for dep in dependencies:
        framework = KNOWN_FRAMEWORKS.get(dep)
        if framework and framework not in seen:
            found.append(framework)
            seen.add(framework)
    return found
