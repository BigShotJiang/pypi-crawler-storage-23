"""Project directory scanner — static analysis entry point."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

from ctxforge.analysis.dep_parser import parse_dependencies, DependencyInfo
from ctxforge.analysis.lang_detector import detect_languages


# Default patterns to exclude from scanning
DEFAULT_EXCLUDES = frozenset(
    {
        "node_modules",
        ".venv",
        "venv",
        "__pycache__",
        ".git",
        ".hg",
        ".svn",
        "dist",
        "build",
        ".eggs",
        ".tox",
        ".mypy_cache",
        ".pytest_cache",
        ".ruff_cache",
        ".cforge",
    }
)


@dataclass
class ScanReport:
    """Result of static project analysis."""

    project_name: str = ""
    languages: list[str] = field(default_factory=list)
    frameworks: list[str] = field(default_factory=list)
    runtime: str | None = None
    package_manager: str | None = None
    source_root: str | None = None
    entry_points: list[str] = field(default_factory=list)
    test_root: str | None = None
    config_files: list[str] = field(default_factory=list)
    key_dirs: dict[str, str] = field(default_factory=dict)


def scan_project(root: Path, excludes: frozenset[str] | None = None) -> ScanReport:
    """Scan a project directory and produce a structured report.

    Args:
        root: Project root directory.
        excludes: Directory names to skip.

    Returns:
        ScanReport with detected project information.
    """
    if excludes is None:
        excludes = DEFAULT_EXCLUDES

    report = ScanReport()
    report.project_name = root.name

    # Collect all files (respecting excludes)
    all_files = _collect_files(root, excludes)

    # Detect languages
    report.languages = detect_languages(all_files)

    # Find source root
    report.source_root = _find_source_root(root)

    # Find test root
    report.test_root = _find_test_root(root)

    # Find config files
    report.config_files = _find_config_files(root)

    # Parse dependencies
    dep_info = parse_dependencies(root)
    report.frameworks = dep_info.frameworks
    report.runtime = dep_info.runtime
    report.package_manager = dep_info.package_manager

    # Detect key directories
    report.key_dirs = _detect_key_dirs(root, excludes)

    # Detect entry points
    report.entry_points = _find_entry_points(root, report.source_root)

    return report


def _collect_files(root: Path, excludes: frozenset[str]) -> list[Path]:
    """Collect all files under root, skipping excluded directories."""
    files: list[Path] = []
    for item in root.rglob("*"):
        if any(part in excludes for part in item.parts):
            continue
        if item.is_file():
            files.append(item)
    return files


def _find_source_root(root: Path) -> str | None:
    """Detect the source root directory."""
    candidates = ["src", "lib", "app"]
    for c in candidates:
        if (root / c).is_dir():
            return c
    # If there's a main package directory at root level
    for item in root.iterdir():
        if item.is_dir() and (item / "__init__.py").exists():
            return item.name
    return None


def _find_test_root(root: Path) -> str | None:
    """Detect the test directory."""
    candidates = ["tests", "test", "spec"]
    for c in candidates:
        if (root / c).is_dir():
            return c
    return None


def _find_config_files(root: Path) -> list[str]:
    """Find known configuration files in the project root."""
    known_configs = [
        "pyproject.toml",
        "setup.py",
        "setup.cfg",
        "package.json",
        "tsconfig.json",
        "go.mod",
        "Cargo.toml",
        "Makefile",
        "Dockerfile",
        "docker-compose.yml",
        "docker-compose.yaml",
        ".env.example",
        "alembic.ini",
        "tox.ini",
    ]
    found = []
    for name in known_configs:
        if (root / name).exists():
            found.append(name)
    return found


def _detect_key_dirs(root: Path, excludes: frozenset[str]) -> dict[str, str]:
    """Detect key directories (first-level subdirs under source root or project root)."""
    key_dirs: dict[str, str] = {}
    source_root = _find_source_root(root)
    base = root / source_root if source_root else root

    for item in sorted(base.iterdir()):
        if not item.is_dir():
            continue
        if item.name.startswith(".") or item.name in excludes:
            continue
        # Use relative path from project root
        rel = str(item.relative_to(root))
        if not rel.endswith("/"):
            rel += "/"
        key_dirs[rel] = ""  # Description will be filled by LLM in P2
    return key_dirs


def _find_entry_points(root: Path, source_root: str | None) -> list[str]:
    """Find likely entry point files."""
    candidates = [
        "main.py",
        "app.py",
        "__main__.py",
        "index.ts",
        "index.js",
        "main.ts",
        "main.go",
        "main.rs",
    ]
    found = []
    search_dirs = [root]
    if source_root:
        search_dirs.insert(0, root / source_root)

    for search_dir in search_dirs:
        for name in candidates:
            target = search_dir / name
            if target.exists():
                found.append(str(target.relative_to(root)))
    return found
