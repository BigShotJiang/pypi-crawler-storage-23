"""CForge object factory."""
