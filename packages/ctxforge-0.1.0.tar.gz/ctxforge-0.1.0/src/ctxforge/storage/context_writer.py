"""Write cfproject.toml and context files to disk."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import tomli_w

from ctxforge.spec.schema import CfProject


def write_cfproject(path: Path, project: CfProject) -> None:
    """Write a CfProject to a TOML file.

    Args:
        path: Target file path.
        project: Validated CfProject instance.
    """
    data = _to_toml_dict(project)
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "wb") as f:
        tomli_w.dump(data, f)


def _to_toml_dict(project: CfProject) -> dict[str, Any]:
    """Convert CfProject to a TOML-compatible dict, omitting None/empty values."""
    raw = project.model_dump(exclude_none=True)

    # Flatten context.files into context top level
    context = raw.get("context", {})
    files = context.pop("files", {})
    context.update(files)

    # Clean up empty dicts/lists recursively
    return _clean_empty(raw)


def _clean_empty(d: Any) -> Any:
    """Recursively remove empty dicts, empty lists, and None values."""
    if isinstance(d, dict):
        cleaned = {}
        for k, v in d.items():
            v = _clean_empty(v)
            if v is not None and v != {} and v != []:
                cleaned[k] = v
        return cleaned
    if isinstance(d, list):
        return [_clean_empty(item) for item in d if item is not None]
    return d
