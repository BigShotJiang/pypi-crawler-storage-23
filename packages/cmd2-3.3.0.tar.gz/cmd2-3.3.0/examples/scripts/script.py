"""Trivial example of a Python script which can be run inside a cmd2 application."""

print("This is a python script running ...")
