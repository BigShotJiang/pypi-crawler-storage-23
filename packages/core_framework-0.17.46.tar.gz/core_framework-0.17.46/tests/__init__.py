"""Testes do Core Framework."""
