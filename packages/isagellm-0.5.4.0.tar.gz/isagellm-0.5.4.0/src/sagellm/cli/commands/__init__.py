"""Commands package.

All commands are registered lazily in main.py to optimize startup performance.
"""
