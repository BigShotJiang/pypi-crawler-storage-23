# Single source of truth for sageLLM umbrella package version.
# All other version references must import from here.
# To bump version, edit only this file.

__version__ = "0.5.4.0"
