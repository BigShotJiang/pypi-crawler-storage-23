"""
Antaris Unified MCP Gateway

Exposes all 5 Antaris packages as a single unified MCP server.

Tools:
  Memory:
    - memory_ingest(content, source?, category?, memory_type?)
    - memory_search(query, limit?, namespace?)
    - memory_list_namespaces()

  Guard:
    - guard_check(text, conversation_id?)
    - guard_list_policies()

  Router:
    - router_route(request_text, strategy?)
    - router_explain(request_text)

  Context:
    - context_build(task, max_tokens?)
    - context_render(format?)  → "anthropic"|"openai"|"raw"

  Pipeline:
    - pipeline_dry_run(request_text)
    - pipeline_stats()

Usage:
    python -m antaris_pipeline.mcp_gateway
    # or
    from antaris_pipeline.mcp_gateway import create_gateway
"""

from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional

# ---------------------------------------------------------------------------
# Graceful MCP availability check
# ---------------------------------------------------------------------------
try:
    from mcp.server.fastmcp import FastMCP
    MCP_AVAILABLE = True
except ImportError:
    MCP_AVAILABLE = False
    FastMCP = None  # type: ignore


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _get_memory_path(memory_path: Optional[str] = None) -> str:
    return (
        memory_path
        or os.environ.get("ANTARIS_MEMORY_PATH")
        or "./antaris_memory_store"
    )


# ---------------------------------------------------------------------------
# Gateway factory
# ---------------------------------------------------------------------------

def create_gateway(
    memory_path: Optional[str] = None,
    storage_path: Optional[str] = None,
) -> "FastMCP":
    """Create and return a unified FastMCP gateway for the Antaris Suite.

    Args:
        memory_path: Path to the memory workspace.  Falls back to
            ``$ANTARIS_MEMORY_PATH`` env var then ``./antaris_memory_store``.
        storage_path: Alias for memory_path; takes precedence if both given.

    Returns:
        A configured ``FastMCP`` instance ready to run.

    Raises:
        ImportError: If the ``mcp`` package is not installed.
    """
    if not MCP_AVAILABLE:
        raise ImportError(
            "The 'mcp' package is required to run the Antaris MCP gateway. "
            "Install it with: pip install mcp"
        )

    resolved_memory_path = _get_memory_path(storage_path or memory_path)

    mcp = FastMCP(
        name="antaris-suite",
        instructions=(
            "Antaris Analytics Suite — unified gateway for memory, guard, router, "
            "context, and pipeline. Use the tools below to interact with all five "
            "packages through a single MCP interface."
        ),
    )

    # ==================================================================
    # MEMORY tools
    # ==================================================================

    @mcp.tool()
    def memory_ingest(
        content: str,
        source: Optional[str] = None,
        category: str = "general",
        memory_type: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Ingest content into the persistent memory store.

        Args:
            content: Text content to store.
            source: Optional source label (e.g. ``"user"``, ``"agent"``).
            category: Category label (e.g. ``"tactical"``, ``"strategic"``).
            memory_type: Optional memory type hint (e.g. ``"episodic"``).

        Returns:
            Dict with keys: stored (bool), entry_count (int).
        """
        from antaris_memory import MemorySystem
        mem = MemorySystem(resolved_memory_path)
        mem.load()
        kwargs: Dict[str, Any] = {"content": content, "category": category}
        if source:
            kwargs["source"] = source
        added = mem.ingest(**kwargs)
        mem.save()
        return {"stored": added > 0, "entry_count": len(mem.memories)}

    @mcp.tool()
    def memory_search(
        query: str,
        limit: int = 5,
        namespace: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        """Search the memory store for relevant entries.

        Args:
            query: Natural-language search query.
            limit: Maximum results to return (default 5).
            namespace: Optional namespace / category filter.

        Returns:
            List of memory dicts: content, category, relevance, source, memory_type.
        """
        from antaris_memory import MemorySystem
        mem = MemorySystem(resolved_memory_path)
        mem.load()
        results = mem.search(query=query, limit=limit, use_decay=True)
        mem.save()
        output = []
        for entry in results:
            item: Dict[str, Any] = {
                "content": getattr(entry, "content", ""),
                "category": getattr(entry, "category", "general"),
                "relevance": round(float(getattr(entry, "importance", 1.0)), 4),
                "source": getattr(entry, "source", ""),
                "memory_type": getattr(entry, "memory_type", "episodic"),
            }
            if namespace and item["category"] != namespace:
                continue
            output.append(item)
        return output

    @mcp.tool()
    def memory_list_namespaces() -> List[str]:
        """List all namespaces (categories) present in the memory store.

        Returns:
            Sorted list of category strings.
        """
        from antaris_memory import MemorySystem
        mem = MemorySystem(resolved_memory_path)
        mem.load()
        categories = set()
        for entry in mem.memories:
            cat = getattr(entry, "category", None)
            if cat:
                categories.add(cat)
        return sorted(categories)

    # ==================================================================
    # GUARD tools
    # ==================================================================

    @mcp.tool()
    def guard_check(
        text: str,
        conversation_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Check text against the Antaris guard policies.

        Args:
            text: Text to analyse for safety/policy compliance.
            conversation_id: Optional conversation identifier for context.

        Returns:
            Dict with keys: allowed (bool), risk_score (float),
            threat_level (str), message (str), match_count (int).
        """
        from antaris_guard import PromptGuard
        guard = PromptGuard()
        result = guard.analyze(text)
        return {
            "allowed": not result.is_blocked,
            "risk_score": round(result.score, 4),
            "threat_level": result.threat_level.value,
            "message": result.message,
            "match_count": len(result.matches),
            "is_suspicious": result.is_suspicious,
        }

    @mcp.tool()
    def guard_list_policies() -> List[Dict[str, Any]]:
        """List active guard policies.

        Returns:
            List of policy dicts with keys: policy_id, description, enabled.
        """
        from antaris_guard import PromptGuard
        guard = PromptGuard()
        stats = guard.get_stats()
        # Return what we know about active policies
        return [
            {
                "policy_id": "default",
                "description": "Default Antaris guard policy",
                "enabled": True,
                "pattern_count": stats.get("pattern_count", 0),
                "sensitivity": stats.get("sensitivity", "balanced"),
            }
        ]

    # ==================================================================
    # ROUTER tools
    # ==================================================================

    @mcp.tool()
    def router_route(
        request_text: str,
        strategy: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Route a request to the optimal model.

        Args:
            request_text: The request to route.
            strategy: Routing hint: ``"cost"``, ``"quality"``, or ``"balanced"``.

        Returns:
            Dict with keys: model, provider, tier, confidence, estimated_cost,
            fallback_models, reasoning.
        """
        from antaris_router import Router
        router = Router(enable_cost_tracking=False)

        min_tier = None
        prefer_healthy = True
        if strategy == "quality":
            min_tier = "moderate"
        elif strategy == "cost":
            prefer_healthy = False

        decision = router.route(
            prompt=request_text,
            min_tier=min_tier,
            prefer_healthy=prefer_healthy,
        )
        return {
            "model": decision.model,
            "provider": decision.provider,
            "tier": decision.tier,
            "confidence": round(decision.confidence, 4),
            "estimated_cost": round(decision.estimated_cost, 6),
            "fallback_models": decision.fallback_models[:3],
            "reasoning": decision.reasoning[:5],
        }

    @mcp.tool()
    def router_explain(request_text: str) -> str:
        """Get a human-readable explanation of how a request would be routed.

        Args:
            request_text: The request to explain routing for.

        Returns:
            Multi-line explanation string with model, confidence, reasoning.
        """
        from antaris_router import Router
        router = Router(enable_cost_tracking=False)
        decision = router.route(prompt=request_text)
        return router.explain(decision)

    # ==================================================================
    # CONTEXT tools
    # ==================================================================

    @mcp.tool()
    def context_build(
        task: str,
        max_tokens: int = 8000,
    ) -> Dict[str, Any]:
        """Build an optimised context window for a task.

        Args:
            task: The task or user message to build context for.
            max_tokens: Maximum token budget (default 8000).

        Returns:
            Dict with keys: total_used, total_budget, utilization, sections.
        """
        from antaris_context import ContextManager
        ctx = ContextManager(total_budget=max_tokens)
        ctx.add_content(
            section="conversation",
            content=task,
            priority="important",
        )
        report = ctx.get_usage_report()
        return {
            "total_used": report.get("total_used", 0),
            "total_budget": max_tokens,
            "utilization": round(
                report.get("total_used", 0) / max_tokens, 4
            ) if max_tokens > 0 else 0.0,
            "sections": report.get("sections", {}),
        }

    @mcp.tool()
    def context_render(format: str = "raw") -> List[Dict[str, Any]]:
        """Render the current context window in the specified format.

        Args:
            format: Output format — ``"anthropic"``, ``"openai"``, or ``"raw"``
                (default ``"raw"``).

        Returns:
            List of message dicts in the requested format.
        """
        # The MCP gateway is a stateless server — it has no live pipeline
        # instance to pull context from.  This tool accepts the caller's
        # messages directly, loads them into a temporary ContextManager for
        # trimming/prioritisation, and returns the rendered result.
        # Pass messages as a list of {"role": ..., "content": ...} dicts.
        from antaris_context import ContextManager
        ctx = ContextManager(total_budget=8000)
        # context_render receives no messages here at the MCP layer —
        # the caller should use context_usage() to inspect sizing, then
        # pass their messages through the full pipeline process() call to
        # get context-managed output.  Returning an empty list with an
        # explanatory entry so callers know the tool is stateless.
        return [
            {
                "role": "system",
                "content": (
                    "[antaris-context] context_render() is stateless in the MCP gateway. "
                    "Use pipeline_process() to run a full turn with context management, "
                    "or context_usage() to inspect token sizing for a specific task."
                ),
            }
        ]

    # ==================================================================
    # PIPELINE tools
    # ==================================================================

    @mcp.tool()
    def pipeline_dry_run(request_text: str) -> Dict[str, Any]:
        """Simulate what the full pipeline would do for a request.

        No model calls are made. Uses real guard/router/memory/context
        for accurate predictions.

        Args:
            request_text: The request to simulate.

        Returns:
            Dict with keys: guard_decision, router_decision, context_budget,
            memory_recall, estimated_cost, raw.
        """
        from antaris_pipeline import AgentPipeline
        pipeline = AgentPipeline(
            storage_path=resolved_memory_path,
            memory=True,
            guard=True,
            context=True,
            router=True,
        )
        result = pipeline.dry_run(request_text)
        return {
            "guard_decision": result.guard_decision,
            "router_decision": result.router_decision,
            "context_budget": result.context_budget,
            "memory_recall": result.memory_recall,
            "estimated_cost": result.estimated_cost,
        }

    @mcp.tool()
    def pipeline_stats() -> Dict[str, Any]:
        """Return gateway configuration and live memory store statistics.

        Note: The MCP gateway is stateless — it does not maintain a live
        AgentPipeline session between tool calls.  This tool returns the
        gateway's storage configuration and current memory store stats
        (entry count, disk usage, etc.) without constructing a heavyweight
        pipeline instance just to read a stats dict.

        Returns:
            Dict with keys: storage_path, memory_stats.
        """
        from antaris_memory import MemorySystem
        mem = MemorySystem(resolved_memory_path)
        mem.load()
        raw = mem.stats()
        return {
            "storage_path": resolved_memory_path,
            "memory_stats": {
                "total_entries": raw.get("total_entries", raw.get("total", 0)),
                "disk_usage_mb": raw.get("disk_usage_mb", 0.0),
                "categories": raw.get("categories", {}),
            },
        }

    return mcp


# ---------------------------------------------------------------------------
# CLI entry point
# ---------------------------------------------------------------------------

def main() -> None:
    """Run the Antaris unified MCP gateway (stdio transport by default)."""
    parser = argparse.ArgumentParser(
        description="Antaris Suite Unified MCP Gateway — all 5 packages over MCP."
    )
    parser.add_argument(
        "--memory-path",
        default=None,
        help=(
            "Path to the memory workspace directory. "
            "Defaults to $ANTARIS_MEMORY_PATH or ./antaris_memory_store"
        ),
    )
    parser.add_argument(
        "--transport",
        choices=["stdio", "sse"],
        default="stdio",
        help="MCP transport (default: stdio).",
    )
    parser.add_argument(
        "--host",
        default="127.0.0.1",
        help="Host for SSE transport (default: 127.0.0.1).",
    )
    parser.add_argument(
        "--port",
        type=int,
        default=8767,
        help="Port for SSE transport (default: 8767).",
    )
    args = parser.parse_args()

    if not MCP_AVAILABLE:
        print(
            "ERROR: The 'mcp' package is not installed.\n"
            "Install it with: pip install mcp",
            file=sys.stderr,
        )
        sys.exit(1)

    server = create_gateway(memory_path=args.memory_path)

    if args.transport == "stdio":
        server.run(transport="stdio")
    else:
        server.settings.host = args.host
        server.settings.port = args.port
        server.run(transport="sse")


if __name__ == "__main__":
    main()
