"""
Unified Pipeline Orchestrator for Antaris Analytics Suite 2.0

This is the core orchestration engine that unifies all 4 packages:
- antaris-memory: Intelligent storage and retrieval
- antaris-router: Smart model routing  
- antaris-guard: Security and safety
- antaris-context: Context window optimization

Key innovations:
- Cross-package intelligence flows
- Real-time telemetrics
- Dry-run mode for demos/debugging
- Performance SLA monitoring
"""

import json
import time
from concurrent.futures import ThreadPoolExecutor, TimeoutError as FutureTimeoutError
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Union
from uuid import uuid4

# Real package imports — actual class names from each package
from antaris_memory import MemorySystem, ContextPacketBuilder, SearchResult
from antaris_router import Router, RoutingDecision
from antaris_guard import PromptGuard, GuardResult, SensitivityLevel
from antaris_context import ContextManager

from .events import (
    AntarisEvent,
    EventType,
    ConfidenceBasis,
    PerformanceMetrics,
    EventEmitter,
)
from .telemetrics import TelemetricsCollector
from .config import PipelineConfig


class PipelineResult:
    """Result from pipeline processing."""

    def __init__(self):
        self.success: bool = False
        self.output: Optional[str] = None
        self.error: Optional[str] = None
        self.events: List[AntarisEvent] = []
        self.performance: Dict[str, Any] = {}
        self.dry_run: bool = False

        # Cross-package intelligence data
        self.memory_retrievals: List[Dict] = []
        self.routing_decision: Optional[Dict] = None
        self.guard_decisions: List[Dict] = []
        self.context_optimizations: Dict[str, Any] = {}

    def to_dict(self) -> Dict[str, Any]:
        """Convert result to dictionary for serialization."""
        return {
            "success": self.success,
            "output": self.output,
            "error": self.error,
            "events": [json.loads(event.model_dump_json()) for event in self.events],
            "performance": self.performance,
            "dry_run": self.dry_run,
            "memory_retrievals": self.memory_retrievals,
            "routing_decision": self.routing_decision,
            "guard_decisions": self.guard_decisions,
            "context_optimizations": self.context_optimizations,
        }


class AntarisPipeline(EventEmitter):
    """
    Unified orchestration pipeline for Antaris Suite 2.0.

    Coordinates all 4 packages with cross-optimization intelligence.
    All operations are synchronous — packages are zero-dependency and sync.
    """

    def __init__(
        self,
        memory: MemorySystem,
        router: Router,
        guard: PromptGuard,
        context: ContextManager,
        config: Optional[PipelineConfig] = None,
        session_id: Optional[str] = None,
    ):
        """Initialize pipeline with package instances."""

        self.session_id = session_id or f"pipeline_{int(time.time())}"
        super().__init__("pipeline", self.session_id)

        # Core package instances (real types)
        self.memory: MemorySystem = memory
        self.router: Router = router
        self.guard: PromptGuard = guard
        self.context: ContextManager = context
        self.config = config or PipelineConfig()

        # Telemetrics system
        output_file = Path(
            self.config.telemetrics.output_directory
        ) / f"telemetrics_{self.session_id}.jsonl"
        self.telemetrics = TelemetricsCollector(
            self.session_id,
            output_file=output_file,
            buffer_size=self.config.telemetrics.buffer_size,
            enable_analytics=self.config.telemetrics.enable_telemetrics,
        )
        self._setup_telemetrics()

        # Cross-package intelligence state
        self._performance_history: List[Dict] = []
        self._routing_feedback: Dict[str, List[float]] = {}
        self._security_patterns: Dict[str, int] = {}
        # High-risk inputs we should store more carefully
        self._high_risk_hashes: set = set()
        # Sprint 3: last routing result for cross-turn context budget allocation
        self._last_routing_result: Optional[Dict] = None
        # Sprint 3: current trace_id for cross-package correlation
        self._current_trace_id: Optional[str] = None
        # Bug fix: pluggable token estimator (default: heuristic char // 4)
        self._token_estimator = None  # type: Optional[Callable]

        # Persistent executor for memory search timeouts (Gemini R1 perf fix):
        # creating a new ThreadPoolExecutor per call adds OS thread churn on the
        # hot path. One shared executor is created here and shut down in close().
        self._search_executor = ThreadPoolExecutor(max_workers=1)

        self.emit_event(
            EventType.PIPELINE_START,
            payload={"config": self.config.model_dump(mode="json") if self.config else {}},
        )

    def _setup_telemetrics(self) -> None:
        """Setup telemetrics collection from all packages."""
        telemetrics_handler = self.telemetrics.collect_event

        # Hook into guard events if hook support is available
        if hasattr(self.guard, "add_hook"):
            def _guard_hook(result: GuardResult, text: str) -> None:
                """Forward guard events to telemetrics."""
                event_type = (
                    EventType.GUARD_DENY if result.is_blocked
                    else EventType.GUARD_ALLOW
                )
                self.emit_event(
                    event_type,
                    confidence=1.0 - result.score,
                    basis=ConfidenceBasis.PATTERN_MATCH,
                    payload={
                        "is_blocked": result.is_blocked,
                        "score": result.score,
                        "message": result.message,
                        "match_count": len(result.matches),
                    },
                )

            self.guard.add_hook("on_any", _guard_hook)

        # Register our own events into telemetrics
        self.add_handler(telemetrics_handler)

    # ── Main Entry Point ──────────────────────────────────────────────────

    def process(
        self,
        input_text: str,
        model_caller: Callable[[str], str],
        context_data: Optional[Dict] = None,
        dry_run: bool = False,
    ) -> "PipelineResult":
        """
        Process input through the unified pipeline.

        Flow: input → guard → memory → context → router → [model] → memory → guard → output

        All operations are synchronous. Pass model_caller=None to force dry_run.
        """
        start_time = time.time()
        result = PipelineResult()
        result.dry_run = dry_run

        # Sprint 3: assign trace_id for cross-package correlation
        trace_id = str(uuid4())
        self._current_trace_id = trace_id

        try:
            # Phase 1: Input Security Scan
            guard_input_result = self.guard_input_scan(input_text)
            result.guard_decisions.append(guard_input_result)

            if not guard_input_result.get("allowed", True):
                result.error = "Input blocked by security policies"
                result.success = False
                return result

            # Phase 2: Memory Retrieval
            memory_data = self.memory_retrieval(input_text, context_data)
            result.memory_retrievals = memory_data.get("retrievals", [])

            # Phase 3: Context Building (uses last routing result for budget allocation)
            context_result = self.context_building(
                input_text, memory_data, routing_result=self._last_routing_result
            )
            result.context_optimizations = context_result

            # Phase 4: Smart Routing Decision (uses memory performance feedback)
            routing_result = self.smart_routing(input_text, memory_data, context_result)
            result.routing_decision = routing_result

            # Phase 5: Model Execution (or dry-run simulation)
            if dry_run:
                model_output = self._simulate_model_call(input_text, routing_result)
                result.output = (
                    f"[DRY RUN] Would call {routing_result.get('selected_model')} "
                    f"with {len(input_text)} chars"
                )
            else:
                model_call_start = time.time()
                model_output = self._execute_model_call(
                    input_text, model_caller, routing_result
                )
                model_elapsed_ms = (time.time() - model_call_start) * 1000
                result.output = model_output

                # Sprint 3: Memory → Router feedback — record success + ingest performance
                selected_model = routing_result.get("selected_model", "unknown")
                # record_provider_event is a Sprint 7 addition — guard with hasattr
                if hasattr(self.router, "record_provider_event"):
                    self.router.record_provider_event(
                        selected_model, event="success", latency_ms=model_elapsed_ms
                    )
                # P2 fix: do NOT ingest routing performance data as a memory entry.
                # Ingesting "Model X completed in Nms" on every turn creates unbounded
                # near-duplicate entries that compete for the 20K active-set cap and
                # pollute semantic search results.  The router's quality tracker
                # (record_provider_event above) is the correct home for this signal.

            # Phase 6: Memory Storage with routing feedback (guard → memory flow)
            self.memory_storage(
                input_text, model_output, routing_result,
                input_guard_result=guard_input_result,
            )

            # Phase 7: Output Security Scan
            guard_output_result = self.guard_output_scan(model_output)
            result.guard_decisions.append(guard_output_result)

            if not guard_output_result.get("allowed", True):
                result.error = "Output blocked by security policies"
                result.success = False
                return result

            # Phase 8: Cross-Package Intelligence Updates
            self._update_cross_intelligence(
                input_text,
                model_output,
                memory_data,
                routing_result,
                context_result,
            )

            result.success = True

        except (TypeError, AttributeError, NameError, AssertionError,
                ImportError, MemoryError):
            # ── Pipeline Exception Policy ──────────────────────────────────
            # "Programming errors" re-raise unconditionally; "operational errors"
            # are caught below and surfaced as a failed PipelineResult.
            #
            # Re-raise (indicates broken invariants / code bugs):
            #   TypeError      — wrong type: caller or internal API mismatch
            #   AttributeError — attribute absent: object structure assumption wrong
            #   NameError      — name undefined: always a code bug
            #   AssertionError — explicit invariant violation
            #   ImportError    — missing package (late import): misconfigured env
            #   MemoryError    — OOM: must not be silently swallowed
            #
            # Catch-and-surface (operational failures the agent can recover from):
            #   OSError / IOError     — disk failures, file-not-found
            #   TimeoutError          — slow upstream or model timeout
            #   RouterExhaustedError  — all tiers tried, no model available
            #   ValueError            — invalid input from user or tool
            #   RuntimeError          — operational state errors
            #   KeyError              — escalate() hash not found (re-route from scratch)
            #
            # If you add a new exception type, decide which category it belongs to
            # and update this comment.
            raise
        except Exception as e:
            # Operational errors (OSError, TimeoutError, RouterExhaustedError,
            # ValueError for bad input, etc.) are caught here and surfaced as
            # a failed PipelineResult so the agent can decide how to recover.
            result.error = str(e)
            self.emit_event(
                EventType.PIPELINE_ERROR,
                payload={"error": str(e), "type": type(e).__name__, "input_length": len(input_text)},
            )

        finally:
            total_time = (time.time() - start_time) * 1000
            result.performance = {
                "total_latency_ms": total_time,
                "dry_run": dry_run,
            }
            self.emit_event(
                EventType.PIPELINE_COMPLETE,
                performance=PerformanceMetrics(latency_ms=total_time),
                payload={"success": result.success, "dry_run": dry_run},
            )

        return result

    # ── Phase 1: Input Guard ──────────────────────────────────────────────

    def guard_input_scan(self, input_text: str) -> Dict[str, Any]:
        """Phase 1: Input security scanning via antaris-guard.

        Crash behaviour (configurable via ``config.guard.fail_closed_on_crash``):
        - **fail_closed=True** (public/untrusted deployments): a crash during
          analysis DENIES the request and emits a CRITICAL telemetry event.
          Prevents a crafted input (e.g. catastrophic regex backtrack) from
          bypassing all security checks.
        - **fail_closed=False** (default, internal/trusted deployments): a
          crash ALLOWS the request with an ERROR log.  Uptime > strict enforcement.
        """
        scan_start = time.time()

        # Call PromptGuard.analyze() — the real API
        try:
            guard_result: GuardResult = self.guard.analyze(input_text)
        except Exception as exc:
            latency_ms = (time.time() - scan_start) * 1000
            fail_closed = getattr(self.config.guard, "fail_closed_on_crash", False)
            logger.error(
                "guard_input_scan crashed (fail_%s): %s",
                "closed" if fail_closed else "open", exc,
            )
            self.emit_event(
                EventType.PIPELINE_ERROR,
                payload={
                    "phase": "guard_input_scan",
                    "error": str(exc),
                    "type": type(exc).__name__,
                    "fail_closed": fail_closed,
                    "severity": "CRITICAL" if fail_closed else "ERROR",
                },
            )
            return {
                "allowed": not fail_closed,  # False = deny if fail_closed
                "confidence": 0.0,
                "basis": "guard_crash",
                "patterns_matched": [],
                "risk_score": 1.0 if fail_closed else 0.0,
                "threat_level": "blocked" if fail_closed else "safe",
                "is_suspicious": False,
                "message": (
                    "Security check failed — request denied." if fail_closed
                    else "Security check crashed — request allowed (fail-open mode)."
                ),
                "match_count": 0,
                "guard_crash": True,
            }

        latency_ms = (time.time() - scan_start) * 1000

        # Map GuardResult to structured dict
        patterns_matched = [
            m.get("type", "pattern_match") for m in guard_result.matches
        ]

        # allowed = input is NOT blocked
        allowed = not guard_result.is_blocked

        result_dict = {
            "allowed": allowed,
            "confidence": 1.0 - guard_result.score,  # high score = low confidence it's safe
            "basis": ConfidenceBasis.PATTERN_MATCH,
            "patterns_matched": patterns_matched,
            "risk_score": guard_result.score,
            "threat_level": guard_result.threat_level.value,
            "is_suspicious": guard_result.is_suspicious,
            "message": guard_result.message,
            "match_count": len(guard_result.matches),
        }

        # Track security patterns for cross-package intelligence
        for match in guard_result.matches:
            pattern_type = match.get("type", "unknown")
            self._security_patterns[pattern_type] = (
                self._security_patterns.get(pattern_type, 0) + 1
            )

        # Emit GUARD_SCAN event
        event_type = EventType.GUARD_DENY if guard_result.is_blocked else EventType.GUARD_SCAN
        self.emit_event(
            event_type,
            confidence=result_dict["confidence"],
            basis=ConfidenceBasis.PATTERN_MATCH,
            performance=PerformanceMetrics(latency_ms=latency_ms),
            payload={
                "direction": "input",
                "allowed": allowed,
                "risk_score": guard_result.score,
                "match_count": len(guard_result.matches),
                "threat_level": guard_result.threat_level.value,
                "message": guard_result.message,
            },
        )

        return result_dict

    # ── Phase 2: Memory Retrieval ─────────────────────────────────────────

    def memory_retrieval(
        self,
        input_text: str,
        context_data: Optional[Dict],
    ) -> Dict[str, Any]:
        """Phase 2: Memory retrieval with context awareness via antaris-memory."""

        retrieve_start = time.time()

        # Search memory for relevant entries using BM25 search with explain=True.
        # Bug fix: apply configurable timeout so slow disk I/O doesn't block every request.
        # Perf fix (Gemini R1): use the class-level executor instead of creating a new
        # ThreadPoolExecutor on every call — avoids OS thread churn on the hot path.
        timeout_s = self.config.memory.search_timeout_ms / 1000.0
        try:
            future = self._search_executor.submit(
                self.memory.search,
                query=input_text, limit=10, use_decay=True, explain=True,
            )
            search_results: List[SearchResult] = future.result(timeout=timeout_s)
        except FutureTimeoutError:
            search_results = []  # fall through to empty memory — log via telemetrics
            self.emit_event(EventType.MEMORY_RETRIEVE, payload={
                "warning": f"memory_search timed out after {self.config.memory.search_timeout_ms}ms",
                "fallback": "empty",
            })
        except Exception:
            search_results = []

        latency_ms = (time.time() - retrieve_start) * 1000

        # Serialize retrievals to plain dicts (MemoryEntry is not JSON-serializable)
        retrievals = []
        relevance_scores = []
        for sr in search_results:
            retrievals.append(
                {
                    "content": sr.entry.content,
                    "source": getattr(sr.entry, "source", "unknown"),
                    "category": getattr(sr.entry, "category", "general"),
                    "relevance": sr.relevance,
                    "score": sr.score,
                    "matched_terms": sr.matched_terms,
                }
            )
            relevance_scores.append(sr.relevance)

        # Build a context packet from retrieved memories
        context_packet = {}
        if search_results:
            try:
                packet = self.memory.build_context_packet(
                    task=input_text,
                    max_memories=10,
                    max_tokens=self.config.memory.context_packet_max_tokens,
                    min_relevance=0.05,
                )
                context_packet = {
                    "rendered": packet.render(),
                    "memory_count": len(packet.memories),
                    "token_estimate": self._estimate_tokens(packet.render()),
                }
            except Exception:
                # If build_context_packet fails (e.g. no memories), use minimal packet
                context_packet = {"rendered": "", "memory_count": 0, "token_estimate": 0}

        memory_data = {
            "retrievals": retrievals,
            "relevance_scores": relevance_scores,
            "context_packet": context_packet,
            "memory_count": len(self.memory.memories),
            "retrieved_count": len(retrievals),
        }

        # Emit MEMORY_RETRIEVE event
        self.emit_event(
            EventType.MEMORY_RETRIEVE,
            confidence=max(relevance_scores) if relevance_scores else 0.0,
            basis=ConfidenceBasis.STATISTICAL_MODEL,
            performance=PerformanceMetrics(latency_ms=latency_ms),
            payload={
                "retrieved_count": len(retrievals),
                "total_memories": len(self.memory.memories),
                "max_relevance": max(relevance_scores) if relevance_scores else 0.0,
                "avg_relevance": (
                    sum(relevance_scores) / len(relevance_scores)
                    if relevance_scores
                    else 0.0
                ),
            },
        )

        return memory_data

    # ── Phase 3: Context Building ─────────────────────────────────────────

    def context_building(
        self,
        input_text: str,
        memory_data: Dict[str, Any],
        routing_result: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Phase 3: Context window optimization via antaris-context.

        Sprint 3 (Router → Context): When routing_result is provided (from the
        prior turn), uses the selected model's context window size as the budget.
        """

        build_start = time.time()

        # Sprint 3: Router → Context — use selected model's context window for budget.
        # Bug fix: model_context_limits is now pulled from config (configurable)
        # instead of a hardcoded dict. New models work without code changes.
        model_context_limits = self.config.context.model_context_limits
        if routing_result and routing_result.get("selected_model"):
            budget = model_context_limits.get(
                routing_result["selected_model"],
                self.config.context.default_max_tokens,
            )
        else:
            budget = self.config.context.default_max_tokens

        # Clear any previous context content
        self.context.clear_all_content()

        # Add the user input as 'conversation' section content
        self.context.add_content(
            section="conversation",
            content=input_text,
            priority="important",
            compress=False,
        )

        # Add retrieved memory context into the 'memory' section
        context_packet = memory_data.get("context_packet", {})
        rendered_memory = context_packet.get("rendered", "")
        compression_applied = False

        if rendered_memory:
            fits = self.context.add_content(
                section="memory",
                content=rendered_memory,
                priority="normal",
                compress=True,
                query=input_text,
            )
            compression_applied = not fits  # If it didn't fully fit, compression happened

        # Get usage report
        usage_report = self.context.get_usage_report()
        total_used = usage_report.get("total_used", len(input_text))
        total_budget = budget  # Sprint 3: use model-informed budget
        utilization = total_used / total_budget if total_budget > 0 else 0.0

        # Optimize context if over budget
        optimization_report = {}
        if self.context.is_over_budget():
            optimization_report = self.context.optimize_context(
                query=input_text,
                target_utilization=0.85,
            )
            compression_applied = True

        latency_ms = (time.time() - build_start) * 1000

        # Sprint 3: compute compression_ratio for Context → Guard flow
        raw_input_size = len(input_text) + len(rendered_memory)
        compression_ratio = total_used / raw_input_size if raw_input_size > 0 else 1.0

        context_result = {
            "context_length": total_used,
            "budget_allocation": usage_report.get("sections", {}),
            "compression_applied": compression_applied,
            "optimization_score": 1.0 - max(0.0, utilization - 1.0),  # 1.0 when under budget
            "utilization": utilization,
            "memory_sections_filled": bool(rendered_memory),
            "optimization_report": optimization_report,
            "model_budget": total_budget,
            "compression_ratio": compression_ratio,
            "routing_result_used": routing_result is not None,
        }

        # Emit CONTEXT_BUILD event
        self.emit_event(
            EventType.CONTEXT_BUILD,
            confidence=context_result["optimization_score"],
            basis=ConfidenceBasis.RULE_BASED,
            performance=PerformanceMetrics(latency_ms=latency_ms),
            payload={
                "context_length": total_used,
                "utilization": utilization,
                "compression_applied": compression_applied,
                "memory_injected": bool(rendered_memory),
            },
        )

        return context_result

    # ── Phase 4: Smart Routing ─────────────────────────────────────────────

    def smart_routing(
        self,
        input_text: str,
        memory_data: Dict[str, Any],
        context_result: Dict[str, Any],
    ) -> Dict[str, Any]:
        """Phase 4: Smart model routing via antaris-router with cross-package intelligence."""

        route_start = time.time()

        # Sprint 3: Memory → Router — pass performance history to inform model selection
        performance_context = {
            "model_success_rates": self._routing_feedback,
            "recent_patterns": self._security_patterns,
        }

        # Build routing context from cross-package intelligence
        routing_context = {
            "memory_retrieved": memory_data.get("retrieved_count", 0),
            "context_length": context_result.get("context_length", 0),
            "context_utilization": context_result.get("utilization", 0.0),
            "compression_applied": context_result.get("compression_applied", False),
            **performance_context,
        }

        # Add historical routing performance averages if available
        if self._routing_feedback:
            routing_context["model_performance"] = {
                model: sum(scores) / len(scores)
                for model, scores in self._routing_feedback.items()
                if scores
            }

        # Use context constraints to influence routing
        # If context is large, we may want a higher-capacity model
        context_length = context_result.get("context_length", 0)
        estimate_input_tokens = max(100, self._estimate_tokens(input_text) + context_length // 4)
        estimate_output_tokens = 200

        # Call Router.route() with the prompt and context
        decision: RoutingDecision = self.router.route(
            prompt=input_text,
            context=routing_context,
            estimate_tokens=(estimate_input_tokens, estimate_output_tokens),
        )

        latency_ms = (time.time() - route_start) * 1000

        routing_result = {
            "selected_model": decision.model,
            "provider": decision.provider,
            "tier": decision.tier,
            "confidence": decision.confidence,
            "reasoning": decision.reasoning,
            "fallback_chain": decision.fallback_models,
            "estimated_cost": decision.estimated_cost,
            "classification": {
                "tier": decision.classification.tier,
                "confidence": decision.classification.confidence,
                "signals": decision.classification.signals,
            },
        }

        # Emit ROUTER_ROUTE event
        self.emit_event(
            EventType.ROUTER_ROUTE,
            confidence=decision.confidence,
            basis=ConfidenceBasis.RULE_BASED,
            performance=PerformanceMetrics(
                latency_ms=latency_ms,
                cost_usd=decision.estimated_cost,
            ),
            payload={
                "selected_model": decision.model,
                "provider": decision.provider,
                "tier": decision.tier,
                "confidence": decision.confidence,
                "estimated_cost": decision.estimated_cost,
                "reasoning": decision.reasoning[:3],  # First 3 reasons
                "trace_id": self._current_trace_id,
            },
        )

        # Sprint 3: cache for next turn's context budget allocation
        self._last_routing_result = routing_result

        return routing_result

    # ── Model Execution ───────────────────────────────────────────────────

    def _simulate_model_call(
        self,
        input_text: str,
        routing_result: Dict[str, Any],
    ) -> str:
        """Simulate model call for dry-run mode."""
        model = routing_result.get("selected_model", "unknown")
        return (
            f"[SIMULATED RESPONSE from {model}] "
            f"This would be the AI response to: {input_text[:50]}..."
        )

    def _execute_model_call(
        self,
        input_text: str,
        model_caller: Callable[[str], str],
        routing_result: Dict[str, Any],
    ) -> str:
        """Execute actual model call using the provided caller."""
        # TODO: Add retry logic, timeout handling per routing_result config
        return model_caller(input_text)

    # ── Memory Sanitization ───────────────────────────────────────────────

    @staticmethod
    def _sanitize_for_memory(text: str) -> str:
        """Strip OpenClaw-injected metadata blocks before storing to memory.

        Two regions are removed:
        - LEADING: ``## Context Packet ... *Packet built ...*``
        - TRAILING: ``Conversation info (untrusted metadata)``, ``Sender
          (untrusted metadata)``, ``<<<EXTERNAL_UNTRUSTED_CONTENT>>>``, etc.

        This is belt-and-suspenders — the JS plugin's ``stripContextPacket()``
        handles this upstream, but we guard here too so the storage layer is
        always clean regardless of how the pipeline is invoked.
        """
        import re as _re

        if not text:
            return text

        result = text

        # Strip leading context packet (ends with *Packet built ...* line)
        if "## Context Packet" in result:
            m = _re.search(r"\*Packet built [^\n]+\*", result)
            if m:
                after = result[m.end():]
                result = after.lstrip("\n").strip()

        # Strip middle metadata blocks that appear between the context packet
        # end and the actual user text (Conversation info, Sender, etc.)
        meta_headers = [
            "Conversation info (untrusted metadata)",
            "Sender (untrusted metadata)",
            "Untrusted context (metadata",
            "<<<EXTERNAL_UNTRUSTED_CONTENT>>>",
            "[System Message]",
            "[Queued messages while",
        ]

        # Timestamp-prefixed system messages: "[Thu 2026-02-19 04:01 PST] [System Message] ..."
        import re as _re2
        if _re2.match(r'^\[(?:Mon|Tue|Wed|Thu|Fri|Sat|Sun) \d{4}-\d{2}-\d{2}', result):
            end = result.find("\n\n")
            result = result[end:].lstrip("\n").strip() if end != -1 else ""
        for _ in range(10):  # safety cap — at most 10 blocks
            stripped = None
            for header in meta_headers:
                if result.startswith(header):
                    end = result.find("\n\n", len(header))
                    stripped = result[end:].lstrip("\n").strip() if end != -1 else ""
                    break
            if stripped is None:
                break  # no leading metadata block
            result = stripped
            if not result:
                break

        # Strip trailing metadata blocks injected by OpenClaw
        trailing_markers = [
            "\nConversation info (untrusted metadata)",
            "\nSender (untrusted metadata)",
            "\n<<<EXTERNAL_UNTRUSTED_CONTENT>>>",
            "\n[System Message]",
            "\n[Queued messages while",
            '\n```json\n{\n  "message_id"',
            "\nUntrusted context (metadata",
            "\nCurrent time:",
            "\nRead HEARTBEAT.md",
            "\nHEARTBEAT_OK",
        ]
        for marker in trailing_markers:
            idx = result.find(marker)
            if idx > 0:
                result = result[:idx].strip()

        return result or text  # fall back to full text if nothing remains

    # ── Phase 5: Memory Storage ───────────────────────────────────────────

    def memory_storage(
        self,
        input_text: str,
        output_text: str,
        routing_result: Dict[str, Any],
        input_guard_result: Optional[Dict[str, Any]] = None,
    ) -> None:
        """Phase 5: Store interaction in memory via antaris-memory.

        Sprint 3 (Guard → Memory): high-risk inputs are stored as security
        facts rather than episodic conversation memories.
        """

        store_start = time.time()

        # Build a single conversation entry with metadata embedded
        selected_model = routing_result.get("selected_model", "unknown")
        tier = routing_result.get("tier", "moderate")
        cost = routing_result.get("estimated_cost", 0.0)

        # Sprint 3: Guard → Memory — check risk_score from input guard scan
        risk_score = (input_guard_result or {}).get("risk_score", 0.0)

        if risk_score > 0.7:
            # High-risk: store security fact, NOT the actual input content
            # Use ingest_fact() if available (Sprint 2 API), otherwise ingest()
            security_note = f"High-risk input detected: risk_score={risk_score:.2f}"
            if hasattr(self.memory, "ingest_fact"):
                self.memory.ingest_fact(
                    security_note,
                    source=f"pipeline:security:{self.session_id}",
                    tags=["security", "high-risk"],
                    category="security",
                )
            else:
                self.memory.ingest(
                    security_note,
                    source=f"pipeline:security:{self.session_id}",
                    category="security",
                )
            ingested = 1
            category = "security_flagged"
        else:
            # Sanitize before storage: strip injected OpenClaw metadata blocks.
            # These blocks are prepended/appended by the framework and should
            # never reach the memory store. This is a last-resort guard at the
            # Python layer; the JS plugin's stripContextPacket() handles this
            # upstream, but belt-and-suspenders here catches any edge cases.
            clean_input = self._sanitize_for_memory(input_text)
            clean_output = self._sanitize_for_memory(output_text)

            # Normal path: store as episodic conversation memory
            self.memory.ingest(
                f"Turn: {clean_input[:200]}",
                source=f"pipeline:{self.session_id}",
                category="conversation",
            )

            # Also store the full interaction with routing metadata
            memory_content = (
                f"INPUT: {clean_input}\n"
                f"OUTPUT: {clean_output}\n"
                f"MODEL: {selected_model} tier={tier} cost=${cost:.6f}"
            )
            ingested = self.memory.ingest(
                content=memory_content,
                source=f"pipeline:{self.session_id}",
                category="conversation",
            )
            category = "conversation"

        # Save to persist (we save per-interaction; production could batch this)
        if ingested > 0:
            self.memory.save()

        latency_ms = (time.time() - store_start) * 1000

        # Emit MEMORY_INGEST event
        self.emit_event(
            EventType.MEMORY_INGEST,
            basis=ConfidenceBasis.RULE_BASED,
            performance=PerformanceMetrics(latency_ms=latency_ms),
            payload={
                "ingested": ingested,
                "category": category,
                "model_used": selected_model,
                "tier": tier,
            },
        )

    # ── Phase 6: Output Guard ─────────────────────────────────────────────

    def guard_output_scan(self, output_text: str) -> Dict[str, Any]:
        """Phase 6: Output security scanning via antaris-guard.

        Same crash policy as ``guard_input_scan`` — see that method's docstring.
        """
        scan_start = time.time()

        # Scan the model output for injected content or policy violations
        try:
            guard_result: GuardResult = self.guard.analyze(output_text)
        except Exception as exc:
            latency_ms = (time.time() - scan_start) * 1000
            fail_closed = getattr(self.config.guard, "fail_closed_on_crash", False)
            logger.error(
                "guard_output_scan crashed (fail_%s): %s",
                "closed" if fail_closed else "open", exc,
            )
            self.emit_event(
                EventType.PIPELINE_ERROR,
                payload={
                    "phase": "guard_output_scan",
                    "error": str(exc),
                    "type": type(exc).__name__,
                    "fail_closed": fail_closed,
                    "severity": "CRITICAL" if fail_closed else "ERROR",
                },
            )
            return {
                "allowed": not fail_closed,
                "confidence": 0.0,
                "policy_violations": [],
                "modifications": [],
                "risk_score": 1.0 if fail_closed else 0.0,
                "threat_level": "blocked" if fail_closed else "safe",
                "message": (
                    "Output security check failed — response suppressed." if fail_closed
                    else "Output security check crashed — response allowed (fail-open mode)."
                ),
                "guard_crash": True,
            }

        latency_ms = (time.time() - scan_start) * 1000

        allowed = not guard_result.is_blocked

        policy_violations = []
        modifications = []
        if guard_result.matches:
            for match in guard_result.matches:
                policy_violations.append(
                    {
                        "type": match.get("type", "unknown"),
                        "threat_level": match.get("threat_level", "safe"),
                        "position": match.get("position", 0),
                    }
                )

        result_dict = {
            "allowed": allowed,
            "confidence": 1.0 - guard_result.score,
            "modifications": modifications,
            "policy_violations": policy_violations,
            "risk_score": guard_result.score,
            "message": guard_result.message,
        }

        # Emit GUARD_SCAN event (output direction)
        event_type = EventType.GUARD_DENY if guard_result.is_blocked else EventType.GUARD_SCAN
        self.emit_event(
            event_type,
            confidence=result_dict["confidence"],
            basis=ConfidenceBasis.PATTERN_MATCH,
            performance=PerformanceMetrics(latency_ms=latency_ms),
            payload={
                "direction": "output",
                "allowed": allowed,
                "risk_score": guard_result.score,
                "match_count": len(guard_result.matches),
                "policy_violations": len(policy_violations),
            },
        )

        return result_dict

    # ── Phase 7: Cross-Package Intelligence ──────────────────────────────

    def _update_cross_intelligence(
        self,
        input_text: str,
        output_text: str,
        memory_data: Dict[str, Any],
        routing_result: Dict[str, Any],
        context_result: Dict[str, Any],
    ) -> None:
        """Phase 7: Update cross-package intelligence feedback loops."""

        # ── Memory → Router feedback ──────────────────────────────────────
        # Store routing performance data so future routing can use it
        selected_model = routing_result.get("selected_model")
        if selected_model:
            if selected_model not in self._routing_feedback:
                self._routing_feedback[selected_model] = []

            # Performance score: confidence * (1 - estimated_cost_normalized)
            confidence = routing_result.get("confidence", 0.5)
            cost = routing_result.get("estimated_cost", 0.01)
            # Normalize cost: assume $0.10 is "expensive" → 1.0
            cost_penalty = min(1.0, cost / 0.10)
            performance_score = confidence * (1.0 - 0.3 * cost_penalty)
            self._routing_feedback[selected_model].append(
                round(performance_score, 4)
            )

            # Keep only last 100 scores per model to avoid unbounded growth
            if len(self._routing_feedback[selected_model]) > 100:
                self._routing_feedback[selected_model] = (
                    self._routing_feedback[selected_model][-100:]
                )

        # ── Guard → Memory feedback ───────────────────────────────────────
        # If the input was suspicious, tag the stored memory for higher scrutiny
        security_patterns = self._security_patterns
        if security_patterns:
            # Store a routing performance feedback memory entry
            feedback_entry = (
                f"ROUTING_FEEDBACK model={selected_model} "
                f"confidence={routing_result.get('confidence', 0):.3f} "
                f"tier={routing_result.get('tier', 'unknown')} "
                f"security_flags={sum(security_patterns.values())}"
            )
            self.memory.ingest(
                content=feedback_entry,
                source=f"pipeline:cross_intel:{self.session_id}",
                category="routing_feedback",
            )

        # ── Context → Router feedback ─────────────────────────────────────
        # Inform our performance history about context efficiency
        utilization = context_result.get("utilization", 0.0)
        self._performance_history.append(
            {
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "session_id": self.session_id,
                "model": selected_model,
                "tier": routing_result.get("tier"),
                "context_utilization": utilization,
                "compression_applied": context_result.get("compression_applied", False),
                "memory_retrieved": memory_data.get("retrieved_count", 0),
                "estimated_cost": routing_result.get("estimated_cost", 0.0),
            }
        )

        # Keep performance history bounded
        if len(self._performance_history) > 500:
            self._performance_history = self._performance_history[-500:]

        # Sprint 3: Context → Guard — flag heavy compression as potential DoS vector
        compression_ratio = context_result.get("compression_ratio", 1.0)
        if compression_ratio < 0.3:
            # Compressing by 70%+ = unusually large input → context pressure event
            self._security_patterns["context_pressure"] = (
                self._security_patterns.get("context_pressure", 0) + 1
            )

    # ── Pluggable Token Estimator ─────────────────────────────────────────

    def set_token_estimator(self, fn) -> None:
        """Set a custom token estimator for accurate context budget calculations.

        By default, the pipeline uses a rough heuristic (len(text) // 4).
        For production use, inject an accurate estimator — e.g. tiktoken for
        OpenAI models or the Anthropic token counter.

        Args:
            fn: Callable[[str], int] that returns the token count for a string.

        Example::

            import tiktoken
            enc = tiktoken.get_encoding("cl100k_base")
            pipeline.set_token_estimator(lambda text: len(enc.encode(text)))
        """
        if not callable(fn):
            raise TypeError("token estimator must be a callable (str) -> int")
        self._token_estimator = fn

    def _estimate_tokens(self, text: str) -> int:
        """Estimate token count for text using the configured estimator.

        Falls back to the heuristic len(text) // 4 when no estimator is set.
        """
        if self._token_estimator is not None:
            try:
                return int(self._token_estimator(text))
            except Exception:
                pass  # fall through to heuristic
        return max(1, len(text) // 4)

    # ── Lifecycle Hooks ───────────────────────────────────────────────────

    def flush_to_memory(self, reason: str = "manual") -> int:
        """
        Flush critical in-session state to memory storage.
        Call this from before_compaction hooks to prevent memory loss on context compression.

        Returns number of entries ingested.
        """
        count = 0

        # Flush performance history summary
        if self._performance_history:
            summary = (
                f"Session performance summary ({len(self._performance_history)} turns): "
                f"models used: {list(self._routing_feedback.keys())}, "
                f"avg cost: ${sum(h.get('estimated_cost', 0) for h in self._performance_history) / len(self._performance_history):.6f}"
            )
            self.memory.ingest(
                content=summary,
                source=f"pipeline:compaction_flush:{self.session_id}",
                category="tactical",
            )
            count += 1

        # Flush security patterns if any
        if self._security_patterns:
            patterns_str = ", ".join(f"{k}:{v}" for k, v in self._security_patterns.items())
            self.memory.ingest(
                content=f"Security patterns this session: {patterns_str}",
                source=f"pipeline:compaction_flush:{self.session_id}",
                category="tactical",
            )
            count += 1

        if count > 0:
            self.memory.save()

        self.emit_event(
            EventType.PIPELINE_COMPLETE,
            payload={"flush_reason": reason, "entries_flushed": count},
        )
        return count

    def get_compaction_summary(self) -> str:
        """
        Return a formatted string of the most important session state.
        Intended for use as a ``prependContext`` return from a before_compaction hook.
        """
        lines = [f"## Antaris Pipeline Session Summary — {self.session_id}"]

        # Routing summary
        if self._routing_feedback:
            lines.append("\n### Model Routing (this session)")
            for model, scores in self._routing_feedback.items():
                if scores:
                    avg = sum(scores) / len(scores)
                    lines.append(f"- {model}: {len(scores)} calls, avg score {avg:.3f}")

        # Performance history summary
        if self._performance_history:
            total_cost = sum(h.get("estimated_cost", 0) for h in self._performance_history)
            avg_util = sum(h.get("context_utilization", 0) for h in self._performance_history) / len(self._performance_history)
            lines.append(f"\n### Performance ({len(self._performance_history)} turns)")
            lines.append(f"- Total estimated cost: ${total_cost:.6f}")
            lines.append(f"- Avg context utilization: {avg_util:.1%}")

        # Security patterns
        if self._security_patterns:
            lines.append("\n### Security Patterns Detected")
            for pattern, count in self._security_patterns.items():
                lines.append(f"- {pattern}: {count} occurrences")

        # Last routing result
        if self._last_routing_result:
            model = self._last_routing_result.get("selected_model", "unknown")
            tier = self._last_routing_result.get("tier", "unknown")
            lines.append(f"\n### Last Routing Decision")
            lines.append(f"- Model: {model} (tier: {tier})")

        return "\n".join(lines)

    def on_session_start(self, workspaceDir: str = None, summary: str = "") -> Dict[str, Any]:
        """
        Called from an OpenClaw ``session_start`` hook to restore context from memory.

        Searches memory for recent context and last-session entries, then returns
        a dict with ``prependContext`` containing the top 5 most relevant memories.
        If a non-empty ``summary`` is provided (compaction summary from previous session)
        it is prepended before the memory retrievals.

        Args:
            workspaceDir: Optional workspace directory hint for scoping memory search.
            summary: Optional compaction summary from the previous session.

        Returns:
            Dict with ``prependContext`` key (str) for OpenClaw hook consumption.
        """
        queries = ["recent context", "last session", "session summary", "tactical"]
        seen_ids: set = set()
        candidates: List[Dict] = []

        for query in queries:
            try:
                results = self.memory.search(query=query, limit=5, use_decay=True, explain=True)
                for sr in results:
                    entry_id = getattr(sr.entry, "id", None) or sr.entry.content[:40]
                    if entry_id not in seen_ids:
                        seen_ids.add(entry_id)
                        candidates.append(
                            {
                                "content": sr.entry.content,
                                "source": getattr(sr.entry, "source", "memory"),
                                "category": getattr(sr.entry, "category", "general"),
                                "relevance": sr.relevance,
                            }
                        )
            except Exception:
                continue

        # Sort by relevance, keep top 5
        candidates.sort(key=lambda x: x["relevance"], reverse=True)
        top5 = candidates[:5]

        context_parts: List[str] = []

        # Prepend compaction summary when provided
        if summary:
            context_parts.append("## Previous Session Summary\n")
            context_parts.append(summary.strip())
            context_parts.append("")

        if top5:
            context_parts.append("## Restored Session Context\n")
            for i, entry in enumerate(top5, 1):
                source = entry.get("source", "memory")
                category = entry.get("category", "general")
                context_parts.append(f"**[{i}] ({category} / {source})**")
                context_parts.append(entry["content"].strip())
                context_parts.append("")

        if not context_parts:
            return {"prependContext": ""}

        return {"prependContext": "\n".join(context_parts)}

    # ── Dry Run ───────────────────────────────────────────────────────────

    def dry_run(
        self, input_text: str, context_data: Optional[Dict] = None
    ) -> Dict[str, Any]:
        """
        Synchronous dry-run showing what the pipeline would do.
        Uses real package capabilities to produce accurate predictions.
        """
        dry_start = time.time()

        # Phase 1: Real guard scan (no side effects)
        guard_result: GuardResult = self.guard.analyze(input_text)
        guard_stats = self.guard.get_stats()

        # Phase 2: Real memory search (read-only)
        search_results = self.memory.search(
            query=input_text, limit=5, explain=True
        )
        memory_stats = self.memory.get_stats()

        # Phase 3: Real context assessment
        temp_context = ContextManager(
            total_budget=self.config.context.default_max_tokens
        )
        temp_context.add_content(
            section="conversation", content=input_text, priority="important"
        )
        context_usage = temp_context.get_usage_report()
        estimated_input_tokens = context_usage.get("total_used", self._estimate_tokens(input_text))

        # Phase 4: Real routing decision
        decision: RoutingDecision = self.router.route(
            prompt=input_text,
            estimate_tokens=(max(100, estimated_input_tokens), 200),
        )

        dry_run_time = (time.time() - dry_start) * 1000

        simulation = {
            "input": {
                "text": input_text[:100] + ("..." if len(input_text) > 100 else ""),
                "length": len(input_text),
                "context_provided": context_data is not None,
            },
            "guard_input": {
                "would_allow": not guard_result.is_blocked,
                "risk_score": guard_result.score,
                "threat_level": guard_result.threat_level.value,
                "patterns_active": guard_stats.get("pattern_count", 0),
                "sensitivity": guard_stats.get("sensitivity", "balanced"),
                "match_count": len(guard_result.matches),
                "message": guard_result.message,
            },
            "memory": {
                "would_retrieve": len(search_results),
                "total_in_store": memory_stats.get("total_memories", 0),
                "top_relevance": (
                    search_results[0].relevance if search_results else 0.0
                ),
                "matched_terms": (
                    search_results[0].matched_terms[:5] if search_results else []
                ),
            },
            "context": {
                "would_optimize": self.config.context.enable_compression,
                "estimated_input_tokens": estimated_input_tokens,
                "total_budget": self.config.context.default_max_tokens,
                "utilization": estimated_input_tokens / self.config.context.default_max_tokens,
                "template": self.config.context.enable_adaptive_budgeting,
            },
            "router": {
                "would_select": decision.model,
                "provider": decision.provider,
                "tier": decision.tier,
                "confidence": decision.confidence,
                "estimated_cost_usd": decision.estimated_cost,
                "fallback_chain": decision.fallback_models[:3],
                "reasoning": decision.reasoning[:3],
            },
            "guard_output": {
                "would_scan": self.config.guard.enable_output_scanning,
                "sensitivity": self.config.guard.default_policy_strictness,
            },
            "dry_run_time_ms": dry_run_time,
            "dry_run": True,
        }

        self.emit_event(
            EventType.PIPELINE_DRY_RUN,
            payload=simulation,
        )

        return simulation

    # ── Utilities ─────────────────────────────────────────────────────────

    def get_performance_stats(self) -> Dict[str, Any]:
        """Get comprehensive performance statistics."""
        return {
            "session_id": self.session_id,
            "total_requests": len(self._performance_history),
            "routing_feedback": {
                model: {
                    "avg_score": sum(scores) / len(scores) if scores else 0.0,
                    "sample_count": len(scores),
                }
                for model, scores in self._routing_feedback.items()
            },
            "security_patterns": self._security_patterns,
            "telemetrics_summary": self.telemetrics.get_summary(),
        }

    # ── Backward Compatibility Aliases ───────────────────────────────────────

    # Keep the old underscore versions as aliases for backward compatibility
    _guard_input_scan = guard_input_scan
    _memory_retrieval = memory_retrieval
    _context_building = context_building
    _smart_routing = smart_routing
    _guard_output_scan = guard_output_scan
    _memory_storage = memory_storage

    def get_intelligence_summary(self) -> Dict[str, Any]:
        """
        Sprint 3: Cross-package intelligence summary.

        Returns a unified view of all cross-package intelligence flows,
        including routing feedback, security posture, provider health,
        memory statistics, and context pressure events.
        """
        # provider_health and guard_posture are Sprint 7 additions — guard with hasattr
        provider_health = {}
        if hasattr(self.router, "get_provider_health"):
            provider_health = {
                model: self.router.get_provider_health(model)
                for model in self._routing_feedback
            }

        guard_posture = {}
        if hasattr(self.guard, "security_posture_score"):
            guard_posture = self.guard.security_posture_score()

        return {
            "routing_feedback": self._routing_feedback,
            "security_patterns": self._security_patterns,
            "context_pressure_events": self._security_patterns.get("context_pressure", 0),
            "provider_health": provider_health,
            "memory_stats": self.memory.stats() if hasattr(self.memory, "stats") else {},
            "guard_posture": guard_posture,
            "last_routing_result": self._last_routing_result,
            "current_trace_id": self._current_trace_id,
        }

    def close(self) -> None:
        """Gracefully shut down the pipeline and release resources.

        Call this when the pipeline is no longer needed (e.g., session end,
        process exit, or test teardown) to cleanly shut down the background
        thread pool used for memory search timeouts.

        Safe to call multiple times.
        """
        executor = getattr(self, "_search_executor", None)
        if executor is not None:
            executor.shutdown(wait=False)
            self._search_executor = None


# ── Convenience Factory ───────────────────────────────────────────────────

def create_pipeline(
    storage_path: Union[str, Path] = "./memory_store",
    memory_config: Optional[Dict] = None,
    router_config: Optional[Dict] = None,
    guard_config: Optional[Dict] = None,
    context_config: Optional[Dict] = None,
    pipeline_config: Optional[PipelineConfig] = None,
    session_id: Optional[str] = None,
) -> AntarisPipeline:
    """
    Create a pre-configured pipeline with all 4 packages.

    This is the main entry point for users who want the full Antaris Suite.

    Args:
        storage_path: Filesystem path for memory storage (required for MemorySystem).
        memory_config:  Extra kwargs forwarded to MemorySystem constructor.
        router_config:  Extra kwargs forwarded to Router constructor.
        guard_config:   Extra kwargs forwarded to PromptGuard constructor.
        context_config: Extra kwargs forwarded to ContextManager constructor.
        pipeline_config: Full PipelineConfig; built from defaults if not provided.
        session_id:     Optional session identifier.

    Returns:
        Fully initialized AntarisPipeline instance.
    """
    config = pipeline_config or PipelineConfig()
    storage_path = str(storage_path)

    # ── antaris-memory ────────────────────────────────────────────────────
    mem_kwargs: Dict[str, Any] = {
        "workspace": storage_path,
        "half_life": config.memory.decay_half_life_hours / 24.0,  # convert hours → days
        "use_sharding": True,
        "use_indexing": True,
    }
    if memory_config:
        mem_kwargs.update(memory_config)
    memory = MemorySystem(**mem_kwargs)

    # ── antaris-router ────────────────────────────────────────────────────
    router_kwargs: Dict[str, Any] = {
        "enable_cost_tracking": config.router.track_model_performance,
    }
    # config_path is optional; only pass if explicitly provided
    if router_config and "config_path" in router_config:
        router_kwargs["config_path"] = router_config.pop("config_path")
    if router_config:
        router_kwargs.update(router_config)
    router = Router(**router_kwargs)

    # ── antaris-guard ─────────────────────────────────────────────────────
    # Map pipeline strictness (0-1) to SensitivityLevel
    strictness = config.guard.default_policy_strictness
    if strictness >= 0.8:
        sensitivity = SensitivityLevel.STRICT
    elif strictness <= 0.4:
        sensitivity = SensitivityLevel.PERMISSIVE
    else:
        sensitivity = SensitivityLevel.BALANCED

    guard_kwargs: Dict[str, Any] = {"sensitivity": sensitivity}
    if guard_config:
        guard_kwargs.update(guard_config)
    guard = PromptGuard(**guard_kwargs)

    # ── antaris-context ───────────────────────────────────────────────────
    context_kwargs: Dict[str, Any] = {
        "total_budget": config.context.default_max_tokens,
        "template": "agent_with_tools",
    }
    if context_config:
        context_kwargs.update(context_config)
    context_mgr = ContextManager(**context_kwargs)

    return AntarisPipeline(
        memory=memory,
        router=router,
        guard=guard,
        context=context_mgr,
        config=config,
        session_id=session_id,
    )
