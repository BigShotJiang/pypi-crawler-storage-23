"""
Deterministic Profiles for Antaris Pipeline

Profiles are named presets that configure all four packages simultaneously,
giving users a single knob to tune the entire pipeline's behaviour.

Usage::

    from antaris_pipeline.profiles import Profile, apply_profile
    from antaris_pipeline import AgentPipeline

    pipeline = AgentPipeline(guard=True, router=True)
    apply_profile(pipeline, Profile.STRICT_SAFETY)
    # → guard: aggressive, router: always escalate, memory: conservative, context: tight

    apply_profile(pipeline, Profile.DEBUG)
    # → guard: log-only, router: log-only, memory: unrestricted, context: no compression

Built-in profiles
-----------------
STRICT_SAFETY  – Maximise safety; sacrifice cost and speed.
BALANCED       – Default behaviour; good all-around performance.
PERMISSIVE     – Minimal friction; optimise for throughput.
DEBUG          – Observe everything; block/route nothing.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from antaris_pipeline.agent_pipeline import AgentPipeline


# ---------------------------------------------------------------------------
# Profile enum
# ---------------------------------------------------------------------------

class Profile(str, Enum):
    """Named deterministic profiles."""
    STRICT_SAFETY = "strict_safety"
    BALANCED      = "balanced"
    PERMISSIVE    = "permissive"
    DEBUG         = "debug"


# ---------------------------------------------------------------------------
# ProfileSettings dataclass
# ---------------------------------------------------------------------------

@dataclass
class ProfileSettings:
    """
    All tunable knobs controlled by a profile.

    Fields
    ------
    guard_threshold
        Sensitivity threshold passed to guard (0.0 = accept everything,
        1.0 = block everything).
    guard_mode
        ``"block"`` – reject unsafe content; ``"monitor"`` – warn only;
        ``"log_all"`` – log every decision without blocking.
    router_confidence_threshold
        Minimum router confidence to accept a routing decision.
    router_always_escalate
        If True, the pipeline will escalate every low-confidence route to the
        highest-quality fallback model.
    memory_importance_floor
        Minimum importance score a memory must have to be recalled (0.0 = recall
        all memories; 1.0 = recall only perfectly important ones).
    memory_max_recall
        Maximum number of memories returned per turn.
    context_budget_multiplier
        Scales the base context token budget (0.5 = half budget; 2.0 = double).
    context_no_compress
        If True, context compression is disabled — full verbatim content.
    """

    guard_threshold:             float  = 0.7
    guard_mode:                  str    = "monitor"
    router_confidence_threshold: float  = 0.7
    router_always_escalate:      bool   = False
    memory_importance_floor:     float  = 0.0
    memory_max_recall:           int    = 5
    context_budget_multiplier:   float  = 1.0
    context_no_compress:         bool   = False

    def __post_init__(self) -> None:
        assert 0.0 <= self.guard_threshold <= 1.0, "guard_threshold must be in [0, 1]"
        assert self.guard_mode in ("block", "monitor", "log_all"), \
            f"guard_mode must be 'block', 'monitor', or 'log_all', got {self.guard_mode!r}"
        assert 0.0 <= self.router_confidence_threshold <= 1.0
        assert 0.0 <= self.memory_importance_floor <= 1.0
        assert self.memory_max_recall >= 1
        assert 0.5 <= self.context_budget_multiplier <= 2.0, \
            "context_budget_multiplier must be in [0.5, 2.0]"


# ---------------------------------------------------------------------------
# Built-in profiles
# ---------------------------------------------------------------------------

BUILTIN_PROFILES: dict[Profile, ProfileSettings] = {
    Profile.STRICT_SAFETY: ProfileSettings(
        guard_threshold=0.3,           # Low threshold → block more aggressively
        guard_mode="block",
        router_confidence_threshold=0.85,
        router_always_escalate=True,
        memory_importance_floor=0.5,   # Only recall high-importance memories
        memory_max_recall=3,
        context_budget_multiplier=0.5, # Tight context budgets
        context_no_compress=False,
    ),
    Profile.BALANCED: ProfileSettings(
        guard_threshold=0.7,
        guard_mode="monitor",
        router_confidence_threshold=0.7,
        router_always_escalate=False,
        memory_importance_floor=0.0,
        memory_max_recall=5,
        context_budget_multiplier=1.0,
        context_no_compress=False,
    ),
    Profile.PERMISSIVE: ProfileSettings(
        guard_threshold=0.95,          # High threshold → block very little
        guard_mode="monitor",
        router_confidence_threshold=0.5,
        router_always_escalate=False,
        memory_importance_floor=0.0,
        memory_max_recall=10,
        context_budget_multiplier=1.5, # Generous context budgets
        context_no_compress=False,
    ),
    Profile.DEBUG: ProfileSettings(
        guard_threshold=1.0,           # Block nothing
        guard_mode="log_all",
        router_confidence_threshold=0.0,
        router_always_escalate=False,
        memory_importance_floor=0.0,
        memory_max_recall=20,          # Retrieve everything
        context_budget_multiplier=2.0, # Maximum context
        context_no_compress=True,      # No compression — verbatim output
    ),
}


# ---------------------------------------------------------------------------
# apply_profile()
# ---------------------------------------------------------------------------

def apply_profile(pipeline: "AgentPipeline", profile: Profile) -> ProfileSettings:
    """
    Apply a named profile to a live AgentPipeline instance.

    This mutates pipeline settings *in place* — no restart required.

    Args:
        pipeline: An initialised AgentPipeline instance.
        profile:  The profile to apply (``Profile.STRICT_SAFETY``, etc.).

    Returns:
        The ProfileSettings that were applied (useful for inspection/logging).

    Raises:
        KeyError: If *profile* is not in BUILTIN_PROFILES.
    """
    settings = BUILTIN_PROFILES[profile]
    _apply_settings(pipeline, settings)
    return settings


def apply_custom_profile(pipeline: "AgentPipeline", settings: ProfileSettings) -> None:
    """
    Apply a custom ProfileSettings object to a live AgentPipeline instance.

    Args:
        pipeline: An initialised AgentPipeline instance.
        settings: A ``ProfileSettings`` dataclass instance with the desired values.
    """
    _apply_settings(pipeline, settings)


# ---------------------------------------------------------------------------
# Internal application logic
# ---------------------------------------------------------------------------

def _apply_settings(pipeline: "AgentPipeline", settings: ProfileSettings) -> None:
    """
    Mutate pipeline (and its underlying components) to match *settings*.

    We apply settings defensively: if an attribute does not exist we skip it
    rather than raising, so profiles continue to work across package versions.
    """
    import logging
    log = logging.getLogger(__name__)

    # ── Guard ────────────────────────────────────────────────────────────────
    if getattr(pipeline, "enable_guard", False):
        guard = _deep_get(pipeline, "pipeline.guard")
        if guard is not None:
            _try_set(guard, "threshold", settings.guard_threshold, log)
            _try_set(guard, "_threshold", settings.guard_threshold, log)
            _try_set(guard, "strictness", settings.guard_threshold, log)
            _try_set(guard, "default_policy_strictness", settings.guard_threshold, log)
        # Propagate guard_mode to AgentPipeline itself
        _try_set(pipeline, "guard_mode", settings.guard_mode, log)

    # ── Router ───────────────────────────────────────────────────────────────
    if getattr(pipeline, "enable_router", False):
        router = _deep_get(pipeline, "pipeline.router")
        if router is not None:
            _try_set(router, "confidence_threshold", settings.router_confidence_threshold, log)
            _try_set(router, "_confidence_threshold", settings.router_confidence_threshold, log)

        # Store escalation flag on pipeline for the AgentPipeline layer to check.
        # Use setattr directly — these tracking attrs may not pre-exist on pipeline.
        setattr(pipeline, "_profile_always_escalate", settings.router_always_escalate)

    # ── Memory ───────────────────────────────────────────────────────────────
    if getattr(pipeline, "enable_memory", False):
        # Expose as pipeline-level attributes so pre_turn() can use them.
        setattr(pipeline, "_profile_memory_importance_floor", settings.memory_importance_floor)
        setattr(pipeline, "_profile_memory_max_recall", settings.memory_max_recall)

        memory = _deep_get(pipeline, "pipeline.memory")
        if memory is not None:
            _try_set(memory, "importance_floor", settings.memory_importance_floor, log)
            _try_set(memory, "_importance_floor", settings.memory_importance_floor, log)

    # ── Context ──────────────────────────────────────────────────────────────
    if getattr(pipeline, "enable_context", False):
        ctx = _deep_get(pipeline, "pipeline.context")
        if ctx is not None:
            # Attempt to apply budget multiplier to whatever token-budget attribute exists.
            for attr in ("max_tokens", "_max_tokens", "budget", "default_max_tokens"):
                base = getattr(ctx, attr, None)
                if base is not None:
                    try:
                        setattr(ctx, attr, max(1000, int(float(base) * settings.context_budget_multiplier)))
                        break
                    except Exception:
                        continue

            # Compression flag
            _try_set(ctx, "enable_compression", not settings.context_no_compress, log)
            _try_set(ctx, "_enable_compression", not settings.context_no_compress, log)

        # Store on pipeline for inspection (use setattr — may not pre-exist).
        setattr(pipeline, "_profile_context_budget_multiplier", settings.context_budget_multiplier)
        setattr(pipeline, "_profile_context_no_compress", settings.context_no_compress)

    # Store the active profile for introspection (always set unconditionally).
    setattr(pipeline, "_active_profile_settings", settings)

    log.debug("apply_profile: applied settings %s", settings)


# ---------------------------------------------------------------------------
# Utility helpers
# ---------------------------------------------------------------------------

def _deep_get(obj: Any, path: str) -> Any:
    """Traverse a dotted attribute path, returning None if any step is missing."""
    for part in path.split("."):
        obj = getattr(obj, part, None)
        if obj is None:
            return None
    return obj


def _try_set(obj: Any, attr: str, value: Any, log: Any) -> bool:
    """Set obj.attr = value; return True on success, False on failure."""
    if not hasattr(obj, attr):
        return False
    try:
        setattr(obj, attr, value)
        return True
    except Exception as exc:
        log.debug("_try_set %s.%s = %r failed: %s", type(obj).__name__, attr, value, exc)
        return False


__all__ = [
    "Profile",
    "ProfileSettings",
    "BUILTIN_PROFILES",
    "apply_profile",
    "apply_custom_profile",
]
