"""
Sprint 2.9 Integration Tests — Cross-Package Intelligence + Deterministic Profiles

Tests all 3 intelligence flows and all 4 built-in profiles.
Uses REAL package instances; no core mocking of antaris internals.
"""

from __future__ import annotations

import sys
import tempfile
from pathlib import Path
from typing import Any, Dict
from unittest.mock import MagicMock, patch

import pytest

# Ensure all antaris packages are importable from the workspace
for pkg in ["antaris-memory", "antaris-router", "antaris-guard", "antaris-context", "antaris-pipeline"]:
    pkg_path = Path(__file__).parent.parent.parent / pkg
    if pkg_path.exists() and str(pkg_path) not in sys.path:
        sys.path.insert(0, str(pkg_path))

from antaris_pipeline import (
    AgentPipeline,
    CrossPackageIntelligence,
    Profile,
    ProfileSettings,
    BUILTIN_PROFILES,
    apply_profile,
    apply_custom_profile,
    create_pipeline,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def make_temp_dir() -> str:
    return tempfile.mkdtemp(prefix="antaris_sprint29_")


def make_pipeline(**kwargs) -> AgentPipeline:
    """Create a minimal pipeline suitable for testing."""
    return AgentPipeline(
        storage_path=make_temp_dir(),
        memory=True,
        guard=True,
        context=True,
        router=True,
        guard_mode="monitor",
        **kwargs,
    )


def _make_memory_data(retrievals: list | None = None) -> Dict[str, Any]:
    if retrievals is None:
        retrievals = [
            {"content": "def hello(): pass", "relevance": 0.9, "memory_type": "coding"},
            {"content": "Refactor the auth module", "relevance": 0.8, "memory_type": "coding"},
        ]
    return {"retrievals": retrievals, "retrieved_count": len(retrievals)}


# ---------------------------------------------------------------------------
# 1. Intelligence Flow: Memory → Router
# ---------------------------------------------------------------------------

class TestMemoryToRouter:
    """Flow 1: high recall quality boosts router confidence threshold."""

    def test_returns_dict_with_required_keys(self):
        router = MagicMock()
        router.confidence_threshold = 0.7
        memory_data = _make_memory_data()
        result = CrossPackageIntelligence.memory_to_router(memory_data, router, "write a python function")
        assert "task_type" in result
        assert "recall_quality" in result
        assert "boosted" in result
        assert "confidence_delta" in result

    def test_high_quality_coding_task_triggers_boost(self):
        router = MagicMock()
        router.confidence_threshold = 0.7
        memory_data = _make_memory_data([
            {"content": "code review", "relevance": 0.95},
            {"content": "python refactor", "relevance": 0.90},
        ])
        result = CrossPackageIntelligence.memory_to_router(
            memory_data, router, "implement a python class"
        )
        assert result["task_type"] == "coding"
        assert result["boosted"] is True
        assert result["confidence_delta"] < 0  # threshold was reduced
        assert result["new_threshold"] < result["original_threshold"]

    def test_low_quality_recall_no_boost(self):
        router = MagicMock()
        router.confidence_threshold = 0.7
        memory_data = _make_memory_data([
            {"content": "vague memory", "relevance": 0.2},
        ])
        result = CrossPackageIntelligence.memory_to_router(
            memory_data, router, "write python code"
        )
        assert result["boosted"] is False
        assert result["confidence_delta"] == 0.0

    def test_empty_retrievals_no_boost(self):
        router = MagicMock()
        router.confidence_threshold = 0.7
        result = CrossPackageIntelligence.memory_to_router(
            {"retrievals": []}, router, "implement function"
        )
        assert result["boosted"] is False

    def test_unknown_task_type_no_boost(self):
        router = MagicMock()
        router.confidence_threshold = 0.7
        memory_data = _make_memory_data([{"content": "xyz", "relevance": 0.9}])
        result = CrossPackageIntelligence.memory_to_router(
            memory_data, router, "zzzzz no keywords at all"
        )
        assert result["task_type"] is None
        assert result["boosted"] is False

    def test_boost_clamps_to_zero(self):
        """Threshold cannot go below 0.0."""
        router = MagicMock()
        router.confidence_threshold = 0.05
        memory_data = _make_memory_data([{"content": "code", "relevance": 0.99}])
        result = CrossPackageIntelligence.memory_to_router(
            memory_data, router, "implement a coding solution", boost_amount=0.5
        )
        if result["boosted"]:
            assert result["new_threshold"] >= 0.0


# ---------------------------------------------------------------------------
# 2. Intelligence Flow: Router → Context
# ---------------------------------------------------------------------------

class TestRouterToContext:
    """Flow 2: route cost/confidence adjusts context token budget."""

    def test_returns_dict_with_required_keys(self):
        ctx = MagicMock()
        ctx.max_tokens = 8000
        route = {"estimated_cost": 0.05, "confidence": 0.8}
        result = CrossPackageIntelligence.router_to_context(route, ctx)
        assert "estimated_cost" in result
        assert "confidence" in result
        assert "budget_multiplier" in result
        assert "new_budget" in result
        assert "actions" in result

    def test_high_cost_tightens_budget(self):
        ctx = MagicMock()
        ctx.max_tokens = 8000
        route = {"estimated_cost": 0.50, "confidence": 0.9}
        result = CrossPackageIntelligence.router_to_context(route, ctx)
        assert result["budget_multiplier"] < 1.0
        assert "tightened_budget" in " ".join(result["actions"])

    def test_low_confidence_expands_budget(self):
        ctx = MagicMock()
        ctx.max_tokens = 8000
        route = {"estimated_cost": 0.01, "confidence": 0.2}
        result = CrossPackageIntelligence.router_to_context(route, ctx)
        assert result["budget_multiplier"] > 1.0
        assert "expanded_budget" in " ".join(result["actions"])

    def test_both_conditions_compound(self):
        """High cost AND low confidence: effects both applied."""
        ctx = MagicMock()
        ctx.max_tokens = 8000
        route = {"estimated_cost": 0.50, "confidence": 0.2}
        result = CrossPackageIntelligence.router_to_context(route, ctx)
        assert len(result["actions"]) == 2

    def test_normal_conditions_no_change(self):
        ctx = MagicMock()
        ctx.max_tokens = 8000
        route = {"estimated_cost": 0.01, "confidence": 0.9}
        result = CrossPackageIntelligence.router_to_context(route, ctx)
        assert result["budget_multiplier"] == 1.0
        assert result["actions"] == []

    def test_budget_never_below_minimum(self):
        ctx = MagicMock()
        ctx.max_tokens = 1100
        route = {"estimated_cost": 1.0, "confidence": 0.9}
        result = CrossPackageIntelligence.router_to_context(route, ctx, base_budget=1100)
        assert result["new_budget"] >= 1000


# ---------------------------------------------------------------------------
# 3. Intelligence Flow: Guard → Memory
# ---------------------------------------------------------------------------

class TestGuardToMemory:
    """Flow 3: guard threats are persisted as mistake memories."""

    def test_safe_decision_no_ingestion(self):
        memory = MagicMock()
        result = CrossPackageIntelligence.guard_to_memory({"allowed": True}, memory)
        assert result["threat_detected"] is False
        assert result["memory_ingested"] is False
        memory.ingest.assert_not_called()

    def test_threat_triggers_memory_ingest(self):
        memory = MagicMock()
        memory.ingest = MagicMock()
        guard_decision = {
            "allowed": False,
            "message": "prompt injection detected",
            "evidence": ["IGNORE PREVIOUS INSTRUCTIONS"],
        }
        result = CrossPackageIntelligence.guard_to_memory(guard_decision, memory)
        assert result["threat_detected"] is True
        assert result["threat_summary"] is not None
        assert "Threat pattern detected" in result["threat_summary"]
        memory.ingest.assert_called_once()
        call_kwargs = memory.ingest.call_args[1]
        assert call_kwargs["memory_type"] == "mistake"
        assert call_kwargs["source"] == "guard_to_memory"
        assert call_kwargs["category"] == "security"
        assert "guard_threat" in call_kwargs["tags"]

    def test_threat_summary_includes_evidence(self):
        memory = MagicMock()
        guard_decision = {
            "allowed": False,
            "evidence": ["bypass security"],
        }
        result = CrossPackageIntelligence.guard_to_memory(guard_decision, memory)
        assert "bypass security" in result["threat_summary"]

    def test_ingest_failure_is_graceful(self):
        """Guard→Memory should not raise even when ingest() throws."""
        memory = MagicMock()
        memory.ingest = MagicMock(side_effect=RuntimeError("disk full"))
        guard_decision = {"allowed": False, "message": "threat"}
        result = CrossPackageIntelligence.guard_to_memory(guard_decision, memory)
        assert result["threat_detected"] is True
        assert result["memory_ingested"] is False  # failure recorded


# ---------------------------------------------------------------------------
# 4. Deterministic Profiles
# ---------------------------------------------------------------------------

class TestProfiles:
    """All 4 built-in profiles are correctly defined and applicable."""

    def test_all_profiles_exist(self):
        for p in (Profile.STRICT_SAFETY, Profile.BALANCED, Profile.PERMISSIVE, Profile.DEBUG):
            assert p in BUILTIN_PROFILES

    def test_strict_safety_values(self):
        s = BUILTIN_PROFILES[Profile.STRICT_SAFETY]
        assert s.guard_mode == "block"
        assert s.guard_threshold < 0.5          # aggressive
        assert s.router_always_escalate is True
        assert s.context_budget_multiplier <= 0.5  # tight

    def test_balanced_is_sensible_defaults(self):
        s = BUILTIN_PROFILES[Profile.BALANCED]
        assert s.guard_mode == "monitor"
        assert 0.5 <= s.guard_threshold <= 0.9
        assert s.router_always_escalate is False
        assert s.context_budget_multiplier == 1.0

    def test_permissive_is_relaxed(self):
        s = BUILTIN_PROFILES[Profile.PERMISSIVE]
        assert s.guard_threshold > 0.8          # block very little
        assert s.memory_max_recall >= 8
        assert s.context_budget_multiplier >= 1.0

    def test_debug_is_maximally_open(self):
        s = BUILTIN_PROFILES[Profile.DEBUG]
        assert s.guard_threshold == 1.0
        assert s.guard_mode == "log_all"
        assert s.context_no_compress is True
        assert s.memory_max_recall >= 10

    def test_profile_settings_validation_guard_threshold(self):
        with pytest.raises((AssertionError, ValueError)):
            ProfileSettings(guard_threshold=1.5)

    def test_profile_settings_validation_guard_mode(self):
        with pytest.raises((AssertionError, ValueError)):
            ProfileSettings(guard_mode="invalid_mode")

    def test_profile_settings_validation_budget_multiplier(self):
        with pytest.raises((AssertionError, ValueError)):
            ProfileSettings(context_budget_multiplier=0.1)

    def test_apply_profile_strict_safety(self):
        pipeline = make_pipeline()
        settings = apply_profile(pipeline, Profile.STRICT_SAFETY)
        assert settings is BUILTIN_PROFILES[Profile.STRICT_SAFETY]
        assert pipeline.guard_mode == "block"
        assert hasattr(pipeline, "_active_profile_settings")

    def test_apply_profile_debug(self):
        pipeline = make_pipeline()
        apply_profile(pipeline, Profile.DEBUG)
        assert pipeline.guard_mode == "log_all"
        assert pipeline._profile_context_no_compress is True

    def test_apply_profile_permissive(self):
        pipeline = make_pipeline()
        apply_profile(pipeline, Profile.PERMISSIVE)
        assert pipeline._profile_memory_max_recall >= 8

    def test_apply_profile_balanced(self):
        pipeline = make_pipeline()
        apply_profile(pipeline, Profile.BALANCED)
        assert pipeline.guard_mode == "monitor"

    def test_apply_custom_profile(self):
        pipeline = make_pipeline()
        custom = ProfileSettings(
            guard_threshold=0.55,
            guard_mode="block",
            router_confidence_threshold=0.6,
            router_always_escalate=False,
            memory_importance_floor=0.1,
            memory_max_recall=7,
            context_budget_multiplier=1.2,
            context_no_compress=False,
        )
        apply_custom_profile(pipeline, custom)
        assert pipeline._active_profile_settings is custom
        assert pipeline._profile_memory_max_recall == 7

    def test_apply_profile_returns_settings(self):
        pipeline = make_pipeline()
        result = apply_profile(pipeline, Profile.DEBUG)
        assert isinstance(result, ProfileSettings)
        assert result.guard_mode == "log_all"


# ---------------------------------------------------------------------------
# 5. Pipeline with Intelligence + Profile combined
# ---------------------------------------------------------------------------

class TestPipelineWithIntelligenceAndProfile:
    """End-to-end: AgentPipeline with CrossPackageIntelligence attached."""

    def setup_method(self):
        self.pipeline = AgentPipeline(
            storage_path=make_temp_dir(),
            memory=True,
            guard=True,
            context=True,
            router=True,
            guard_mode="monitor",
            intelligence=CrossPackageIntelligence(),
        )

    def test_pipeline_has_intelligence_attribute(self):
        assert self.pipeline.intelligence is not None
        assert isinstance(self.pipeline.intelligence, CrossPackageIntelligence)

    def test_pre_turn_succeeds_with_intelligence(self):
        result = self.pipeline.pre_turn("write a python function to sort a list")
        assert result.success is True

    def test_pre_turn_turn_state_populated(self):
        result = self.pipeline.pre_turn("implement a sorting algorithm in python")
        # turn_state should at least be a dict; intelligence keys may be present
        assert isinstance(result.turn_state, dict)

    def test_post_turn_succeeds_with_intelligence(self):
        pre = self.pipeline.pre_turn("write code")
        post = self.pipeline.post_turn(
            "write code",
            "Here is a python snippet: def hello(): pass",
            turn_state=pre.turn_state,
        )
        assert post.success is True

    def test_combined_profile_and_intelligence(self):
        """Applying a profile then running a turn should not break anything."""
        apply_profile(self.pipeline, Profile.BALANCED)
        result = self.pipeline.pre_turn("analyze this dataset")
        assert result.success is True

    def test_pipeline_without_intelligence_still_works(self):
        """Backward compat: no intelligence parameter → no cross-package flows."""
        pipeline = AgentPipeline(
            storage_path=make_temp_dir(),
            memory=True,
            guard=True,
            context=True,
        )
        assert pipeline.intelligence is None
        result = pipeline.pre_turn("hello world")
        assert result.success is True
