"""
Sprint 2.8: dry_run() tests for AgentPipeline.

Tests cover:
- DryRunResult dataclass fields present
- dry_run() returns DryRunResult
- guard_decision contains "would allow" or "would block"
- router_decision contains model name and confidence
- context_budget contains token info
- memory_recall contains count
- estimated_cost is a formatted string
- raw field contains underlying simulation data
- dry_run() handles errors gracefully (fallback result)
- dry_run() does NOT ingest to memory (no side effects)
- TelemetricsCollector.summary() Sprint 2.8 keys
- TelemetricsCollector.tail() returns list of dicts
- TelemetricsCollector.flush() returns buffer size

Run with: pytest tests/test_dry_run.py -v
"""

import pytest
from pathlib import Path
from unittest.mock import MagicMock, patch

from antaris_pipeline.agent_pipeline import DryRunResult, AgentPipeline
from antaris_pipeline.telemetrics import TelemetricsCollector
from antaris_pipeline.events import AntarisEvent, EventType, PerformanceMetrics


# ── DryRunResult dataclass ────────────────────────────────────────────────────

class TestDryRunResultDataclass:
    """DryRunResult is a proper dataclass with expected fields."""

    def test_dry_run_result_fields(self):
        """DryRunResult has all required fields."""
        result = DryRunResult(
            guard_decision="would allow",
            router_decision="would select gpt-4o-mini (confidence: 85%)",
            context_budget="would use 120/8000 tokens",
            memory_recall="would retrieve 3 memories",
            estimated_cost="$0.00012",
        )
        assert result.guard_decision == "would allow"
        assert result.router_decision == "would select gpt-4o-mini (confidence: 85%)"
        assert result.context_budget == "would use 120/8000 tokens"
        assert result.memory_recall == "would retrieve 3 memories"
        assert result.estimated_cost == "$0.00012"

    def test_dry_run_result_raw_defaults_empty_dict(self):
        """raw defaults to {} when not provided."""
        result = DryRunResult(
            guard_decision="would allow",
            router_decision="would select model (confidence: 0%)",
            context_budget="would use 0/0 tokens",
            memory_recall="would retrieve 0 memories",
            estimated_cost="$0.00000",
        )
        assert result.raw == {}

    def test_dry_run_result_raw_stores_data(self):
        """raw stores the provided dict."""
        raw = {"guard_input": {"would_allow": True}, "router": {"would_select": "haiku"}}
        result = DryRunResult(
            guard_decision="would allow",
            router_decision="would select haiku (confidence: 90%)",
            context_budget="would use 50/8000 tokens",
            memory_recall="would retrieve 0 memories",
            estimated_cost="$0.00001",
            raw=raw,
        )
        assert result.raw["guard_input"]["would_allow"] is True
        assert result.raw["router"]["would_select"] == "haiku"

    def test_dry_run_result_guard_block(self):
        """guard_decision can represent a blocked decision."""
        result = DryRunResult(
            guard_decision="would block (threat_level=high)",
            router_decision="would select model (confidence: 0%)",
            context_budget="would use 0/0 tokens",
            memory_recall="would retrieve 0 memories",
            estimated_cost="$0.00000",
        )
        assert "block" in result.guard_decision


# ── AgentPipeline.dry_run() ───────────────────────────────────────────────────

class TestAgentPipelineDryRun:
    """AgentPipeline.dry_run() returns correct DryRunResult."""

    @pytest.fixture
    def pipeline(self, tmp_path):
        """AgentPipeline with all components enabled."""
        return AgentPipeline(
            storage_path=tmp_path / "memory",
            memory=True,
            guard=True,
            context=True,
            router=True,
        )

    def test_dry_run_returns_dry_run_result(self, pipeline):
        """dry_run() returns a DryRunResult instance."""
        result = pipeline.dry_run("Hello, test input")
        assert isinstance(result, DryRunResult)

    def test_dry_run_guard_decision_is_string(self, pipeline):
        """guard_decision is a non-empty string."""
        result = pipeline.dry_run("Hello, test input")
        assert isinstance(result.guard_decision, str)
        assert len(result.guard_decision) > 0

    def test_dry_run_guard_decision_allow_or_block(self, pipeline):
        """guard_decision contains 'would allow' or 'would block'."""
        result = pipeline.dry_run("Normal test request")
        assert "would" in result.guard_decision

    def test_dry_run_router_decision_is_string(self, pipeline):
        """router_decision is a non-empty string."""
        result = pipeline.dry_run("Implement a REST API endpoint")
        assert isinstance(result.router_decision, str)
        assert "would select" in result.router_decision

    def test_dry_run_router_decision_has_confidence(self, pipeline):
        """router_decision includes confidence percentage."""
        result = pipeline.dry_run("Write a haiku about Python")
        assert "confidence" in result.router_decision
        assert "%" in result.router_decision

    def test_dry_run_context_budget_is_string(self, pipeline):
        """context_budget is a non-empty string."""
        result = pipeline.dry_run("Short request")
        assert isinstance(result.context_budget, str)
        assert "tokens" in result.context_budget

    def test_dry_run_context_budget_format(self, pipeline):
        """context_budget has the 'would use X/Y tokens' format."""
        result = pipeline.dry_run("Test request for context budget check")
        assert "would use" in result.context_budget
        assert "/" in result.context_budget

    def test_dry_run_memory_recall_is_string(self, pipeline):
        """memory_recall is a non-empty string."""
        result = pipeline.dry_run("Test memory recall")
        assert isinstance(result.memory_recall, str)
        assert "memories" in result.memory_recall

    def test_dry_run_estimated_cost_is_string(self, pipeline):
        """estimated_cost is a string starting with '$'."""
        result = pipeline.dry_run("Cost estimate test")
        assert isinstance(result.estimated_cost, str)
        assert result.estimated_cost.startswith("$")

    def test_dry_run_raw_contains_dict(self, pipeline):
        """raw field is a dict (with simulation data or error info)."""
        result = pipeline.dry_run("Test raw field")
        assert isinstance(result.raw, dict)

    def test_dry_run_no_memory_write(self, pipeline, tmp_path):
        """dry_run() does not write to memory (no side effects)."""
        from antaris_memory import MemorySystem
        mem = MemorySystem(str(tmp_path / "memory"))
        mem.load()
        count_before = len(mem.memories)

        pipeline.dry_run("This should not be stored in memory")

        mem2 = MemorySystem(str(tmp_path / "memory"))
        mem2.load()
        # dry_run should not have ingested anything extra
        # (it may do read-only searches but shouldn't ingest)
        assert len(mem2.memories) <= count_before + 2  # allow small tolerance

    def test_dry_run_graceful_fallback_on_error(self, tmp_path):
        """dry_run() returns a fallback DryRunResult if the pipeline errors."""
        pipeline = AgentPipeline(
            storage_path=tmp_path / "memory",
            memory=True,
            guard=True,
            context=True,
            router=True,
        )
        # Monkey-patch pipeline.dry_run to raise
        original_dry_run = pipeline.pipeline.dry_run
        pipeline.pipeline.dry_run = lambda *a, **kw: (_ for _ in ()).throw(
            RuntimeError("simulated pipeline error")
        )

        result = pipeline.dry_run("this should not crash")
        assert isinstance(result, DryRunResult)
        assert "error" in result.raw or "unavailable" in result.guard_decision

        # Restore
        pipeline.pipeline.dry_run = original_dry_run

    def test_dry_run_different_inputs(self, pipeline):
        """dry_run() handles multiple different request texts."""
        inputs = [
            "Hello",
            "Implement a distributed caching layer for a microservices application",
            "What is 2+2?",
        ]
        for text in inputs:
            result = pipeline.dry_run(text)
            assert isinstance(result, DryRunResult)
            assert result.guard_decision
            assert result.router_decision


# ── TelemetricsCollector Sprint 2.8 API ──────────────────────────────────────

def _make_event(module="memory", event_type=EventType.MEMORY_RETRIEVE):
    return AntarisEvent(
        session_id="test",
        module=module,
        event_type=event_type,
        confidence=0.8,
        performance=PerformanceMetrics(latency_ms=30.0, cost_usd=0.001),
        payload={"retrieved_count": 2, "tier": "simple"},
    )


class TestTelemetricsSummaryAPI:
    """TelemetricsCollector.summary() Sprint 2.8 key tests."""

    @pytest.fixture
    def collector(self, tmp_path):
        return TelemetricsCollector("s28", output_dir=tmp_path)

    def test_summary_returns_dict(self, collector):
        """summary() returns a dict."""
        assert isinstance(collector.summary(), dict)

    def test_summary_has_base_keys(self, collector):
        """summary() contains all base get_summary() keys."""
        s = collector.summary()
        for key in ["session_id", "total_events", "events_by_module"]:
            assert key in s

    def test_summary_has_avg_latency_by_module(self, collector):
        """summary() contains avg_latency_by_module."""
        collector.collect_event(_make_event())
        s = collector.summary()
        assert "avg_latency_by_module" in s
        assert isinstance(s["avg_latency_by_module"], dict)

    def test_summary_avg_latency_correct(self, collector):
        """avg_latency_by_module has correct value for memory module."""
        ev = AntarisEvent(
            session_id="t",
            module="memory",
            event_type=EventType.MEMORY_RETRIEVE,
            performance=PerformanceMetrics(latency_ms=100.0),
            payload={},
        )
        collector.collect_event(ev)
        s = collector.summary()
        assert s["avg_latency_by_module"].get("memory", 0) == 100.0

    def test_summary_has_guard_allow_rate(self, collector):
        """summary() contains guard_allow_rate between 0 and 1."""
        s = collector.summary()
        assert "guard_allow_rate" in s
        assert 0.0 <= s["guard_allow_rate"] <= 1.0

    def test_summary_guard_allow_rate_no_guard_events(self, collector):
        """guard_allow_rate defaults to 1.0 when no guard events exist."""
        collector.collect_event(_make_event())
        s = collector.summary()
        assert s["guard_allow_rate"] == 1.0

    def test_summary_has_router_tier_distribution(self, collector):
        """summary() contains router_tier_distribution dict."""
        s = collector.summary()
        assert "router_tier_distribution" in s
        assert isinstance(s["router_tier_distribution"], dict)

    def test_summary_router_tier_distribution_populated(self, collector):
        """router_tier_distribution is populated from router.route events."""
        ev = AntarisEvent(
            session_id="t",
            module="router",
            event_type=EventType.ROUTER_ROUTE,
            performance=PerformanceMetrics(latency_ms=10.0),
            payload={"tier": "moderate", "selected_model": "gpt-4o-mini"},
        )
        collector.collect_event(ev)
        s = collector.summary()
        assert s["router_tier_distribution"].get("moderate", 0) >= 1

    def test_summary_has_memory_recall_rate(self, collector):
        """summary() contains memory_recall_rate between 0 and 1."""
        s = collector.summary()
        assert "memory_recall_rate" in s
        assert 0.0 <= s["memory_recall_rate"] <= 1.0

    def test_summary_memory_recall_rate_no_events(self, collector):
        """memory_recall_rate is 0.0 when no memory.retrieve events exist."""
        s = collector.summary()
        assert s["memory_recall_rate"] == 0.0

    def test_summary_memory_recall_rate_populated(self, collector):
        """memory_recall_rate reflects hits (retrieved_count > 0)."""
        ev_hit = AntarisEvent(
            session_id="t", module="memory",
            event_type=EventType.MEMORY_RETRIEVE,
            payload={"retrieved_count": 3},
        )
        ev_miss = AntarisEvent(
            session_id="t", module="memory",
            event_type=EventType.MEMORY_RETRIEVE,
            payload={"retrieved_count": 0},
        )
        collector.collect_event(ev_hit)
        collector.collect_event(ev_miss)
        s = collector.summary()
        # 1 hit / 2 total = 0.5
        assert abs(s["memory_recall_rate"] - 0.5) < 0.01


class TestTelemetricsTailAPI:
    """TelemetricsCollector.tail() returns list of dicts."""

    @pytest.fixture
    def collector(self, tmp_path):
        c = TelemetricsCollector("tail_test", output_dir=tmp_path)
        for i in range(5):
            c.collect_event(_make_event(payload_override={"index": i}))
        return c

    def test_tail_returns_list(self, tmp_path):
        """tail() returns a list."""
        c = TelemetricsCollector("t1", output_dir=tmp_path)
        c.collect_event(_make_event())
        result = c.tail()
        assert isinstance(result, list)

    def test_tail_returns_dicts(self, tmp_path):
        """tail() items are dicts."""
        c = TelemetricsCollector("t2", output_dir=tmp_path)
        c.collect_event(_make_event())
        result = c.tail()
        for item in result:
            assert isinstance(item, dict)

    def test_tail_default_n20(self, tmp_path):
        """tail() with no args returns at most 20 items."""
        c = TelemetricsCollector("t3", output_dir=tmp_path)
        for _ in range(30):
            c.collect_event(_make_event())
        result = c.tail()
        assert len(result) <= 20

    def test_tail_n_respected(self, tmp_path):
        """tail(n=5) returns at most 5 items."""
        c = TelemetricsCollector("t4", output_dir=tmp_path)
        for _ in range(15):
            c.collect_event(_make_event())
        result = c.tail(n=5)
        assert len(result) <= 5

    def test_tail_empty_collector(self, tmp_path):
        """tail() on empty collector returns []."""
        c = TelemetricsCollector("t5", output_dir=tmp_path)
        assert c.tail() == []

    def test_tail_dicts_have_event_fields(self, tmp_path):
        """tail() items have expected event fields."""
        c = TelemetricsCollector("t6", output_dir=tmp_path)
        c.collect_event(_make_event())
        items = c.tail()
        for item in items:
            assert "event_type" in item
            assert "module" in item
            assert "session_id" in item


class TestTelemetricsFlushAPI:
    """TelemetricsCollector.flush() returns buffer size."""

    def test_flush_returns_int(self, tmp_path):
        """flush() returns an int."""
        c = TelemetricsCollector("f1", output_dir=tmp_path)
        result = c.flush()
        assert isinstance(result, int)

    def test_flush_returns_buffer_size(self, tmp_path):
        """flush() returns the number of events in the buffer."""
        c = TelemetricsCollector("f2", output_dir=tmp_path)
        for _ in range(3):
            c.collect_event(_make_event())
        assert c.flush() == 3

    def test_flush_empty_collector(self, tmp_path):
        """flush() on empty collector returns 0."""
        c = TelemetricsCollector("f3", output_dir=tmp_path)
        assert c.flush() == 0

    def test_flush_no_data_loss(self, tmp_path):
        """flush() does not lose events from buffer."""
        c = TelemetricsCollector("f4", output_dir=tmp_path)
        for _ in range(5):
            c.collect_event(_make_event())
        c.flush()
        # Events still in buffer
        assert len(c._event_buffer) == 5


# Fix: make _make_event accept payload_override
def _make_event(module="memory", event_type=EventType.MEMORY_RETRIEVE, payload_override=None):
    return AntarisEvent(
        session_id="test",
        module=module,
        event_type=event_type,
        confidence=0.8,
        performance=PerformanceMetrics(latency_ms=30.0, cost_usd=0.001),
        payload=payload_override or {"retrieved_count": 2, "tier": "simple"},
    )
