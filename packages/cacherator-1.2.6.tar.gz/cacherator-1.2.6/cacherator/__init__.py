from .cacherator import JSONCache, Cached

__version__ = "1.2.6"
__all__ = ["JSONCache", "Cached"]