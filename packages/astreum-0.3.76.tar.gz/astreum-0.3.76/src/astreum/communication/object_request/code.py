from enum import IntEnum


class ObjectRequestCode(IntEnum):
    OBJECT_GET = 0
    OBJECT_PUT = 1
