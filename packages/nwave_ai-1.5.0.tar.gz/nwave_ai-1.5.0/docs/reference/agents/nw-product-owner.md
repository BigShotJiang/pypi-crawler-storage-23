# nw-product-owner

Conducts UX journey design and requirements gathering with BDD acceptance criteria. Use when defining user stories, emotional arcs, or enforcing Definition of Ready.

**Wave:** Other
**Model:** inherit
**Max turns:** 50
**Tools:** Read, Write, Edit, Glob, Grep, Task

## Commands

- [`/nw:discover`](../commands/index.md)
- [`/nw:discuss`](../commands/index.md)
- [`/nw:finalize`](../commands/index.md)
- [`/nw:roadmap`](../commands/index.md)

## Skills

- [bdd-requirements](../../../nWave/skills/product-owner/bdd-requirements.md) — BDD requirements discovery methodology - Example Mapping, Three Amigos, conversational patterns, Given-When-Then translation, and collaborative specification
- [design-methodology](../../../nWave/skills/product-owner/design-methodology.md) — Apple LeanUX++ design workflow, journey schema, emotional arc patterns, and CLI UX patterns. Load when transitioning from discovery to visualization or when designing journey artifacts.
- [discovery-methodology](../../../nWave/skills/product-owner/discovery-methodology.md) — Question-first approach to understanding user journeys. Load when starting a new journey design or when the discovery phase needs deepening.
- [jtbd-bdd-integration](../../../nWave/skills/product-owner/jtbd-bdd-integration.md) — Translating JTBD analysis to BDD scenarios - job story to Given-When-Then patterns, forces-based test discovery, job-map-based test discovery, and property-shaped criteria
- [jtbd-core](../../../nWave/skills/product-owner/jtbd-core.md) — Core JTBD theory and job story format - job dimensions, job story template, job stories vs user stories, 8-step universal job map, outcome statements, and forces of progress
- [jtbd-interviews](../../../nWave/skills/product-owner/jtbd-interviews.md) — JTBD interview techniques - Switch interview methodology, timeline reconstruction, Four Forces extraction, functional/emotional/social job discovery, anti-patterns, and question banks
- [jtbd-opportunity-scoring](../../../nWave/skills/product-owner/jtbd-opportunity-scoring.md) — JTBD opportunity scoring and prioritization - outcome statement format, opportunity algorithm, scoring interpretation, feature prioritization, and opportunity matrix template
- [jtbd-workflow-selection](../../../nWave/skills/product-owner/jtbd-workflow-selection.md) — JTBD workflow classification and routing - ODI two-phase framework, five job types with workflow sequences, baseline type selection, workflow anti-patterns, and common recipes
- [leanux-methodology](../../../nWave/skills/product-owner/leanux-methodology.md) — LeanUX backlog management methodology - user story template, story sizing, story states, task types, Definition of Ready/Done, anti-pattern detection and remediation
- [persona-jtbd-analysis](../../../nWave/skills/product-owner/persona-jtbd-analysis.md) — Structured persona creation and JTBD analysis methodology - persona templates, ODI job step tables, pain point mapping, success metric quantification, and multi-persona segmentation
- [review-dimensions](../../../nWave/skills/product-owner/review-dimensions.md) — Requirements quality critique dimensions for peer review - confirmation bias detection, completeness validation, clarity checks, testability assessment, and priority validation
- [review-dimensions](../../../nWave/skills/software-crafter/review-dimensions.md) — Reviewer critique dimensions for peer review - implementation bias detection, test quality validation, completeness checks, and priority validation
- [shared-artifact-tracking](../../../nWave/skills/product-owner/shared-artifact-tracking.md) — Shared artifact registry, common artifact patterns, and integration validation. Load when tracking data that flows across journey steps or validating horizontal coherence.
- [ux-desktop-patterns](../../../nWave/skills/product-owner/ux-desktop-patterns.md) — Desktop application UI patterns for product owners. Load when designing native or cross-platform desktop applications, writing desktop-specific acceptance criteria, or evaluating panel layouts and keyboard workflows.
- [ux-emotional-design](../../../nWave/skills/product-owner/ux-emotional-design.md) — Emotional design and delight patterns for product owners. Load when designing onboarding flows, empty states, first-run experiences, or evaluating the emotional quality of an interface.
- [ux-principles](../../../nWave/skills/product-owner/ux-principles.md) — Core UX principles for product owners. Load when evaluating interface designs, writing acceptance criteria with UX requirements, or reviewing wireframes and mockups.
- [ux-tui-patterns](../../../nWave/skills/product-owner/ux-tui-patterns.md) — Terminal UI and CLI design patterns for product owners. Load when designing command-line tools, interactive terminal applications, or writing CLI-specific acceptance criteria.
- [ux-web-patterns](../../../nWave/skills/product-owner/ux-web-patterns.md) — Web UI design patterns for product owners. Load when designing web application interfaces, writing web-specific acceptance criteria, or evaluating responsive designs.
