# nw-data-engineer-reviewer

Use for review and critique tasks - Data architecture and pipeline review specialist. Runs on Haiku for cost efficiency.

**Wave:** Other
**Model:** haiku
**Max turns:** 30
**Tools:** Read, Glob, Grep, Task

## Skills

- [review-criteria](../../../nWave/skills/data-engineer-reviewer/review-criteria.md) — Evaluation criteria and scoring for data engineering artifact reviews
- [review-criteria](../../../nWave/skills/documentarist-reviewer/review-criteria.md) — Critique dimensions, severity framework, verdict decision matrix, and review output format for documentation assessment reviews
- [review-criteria](../../../nWave/skills/platform-architect-reviewer/review-criteria.md) — Quality dimensions and review checklist for devop reviews
- [review-criteria](../../../nWave/skills/product-discoverer-reviewer/review-criteria.md) — Evidence quality validation and decision gate criteria for product discovery reviews
- [review-criteria](../../../nWave/skills/product-owner-reviewer/review-criteria.md) — Review dimensions and bug patterns for journey artifact reviews
- [review-criteria](../../../nWave/skills/troubleshooter-reviewer/review-criteria.md) — Review dimensions and scoring for root cause analysis quality assessment
