---
name: opportunity-mapping
description: Opportunity Solution Trees, opportunity scoring, Lean Canvas, JTBD job mapping, and technique selection guide
---

# Opportunity Mapping

## Opportunity Solution Tree (OST)

Connects desired outcomes to opportunities to solution ideas:

```
Desired Outcome
  |
  +-- Opportunity 1 (score)
  |     +-- Solution Idea A
  |     +-- Solution Idea B
  |
  +-- Opportunity 2 (score)
  |     +-- Solution Idea C
  |
  +-- Opportunity 3 (score)
        +-- Solution Idea D
        +-- Solution Idea E
```

### Building the OST
1. Define desired outcome from customer research
2. Map opportunities from interview insights (min 5 distinct)
3. Score each using Opportunity Algorithm
4. Generate solution ideas for top 2-3
5. Seek real diversity in solutions (avoid variations of same idea)

## Opportunity Scoring Algorithm

**Formula**: Score = Importance + Max(0, Importance - Satisfaction)
Importance: 1-10 | Satisfaction: 1-10 | Max score: 20

| Score | Meaning | Action |
|-------|---------|--------|
| >8 | High importance, satisfaction gap -- underserved | Pursue |
| 5-8 | Moderate importance or partially served | Evaluate |
| <5 | Low importance or well-served | Deprioritize |

Process: gather importance + satisfaction from 5+ interviews, calculate per opportunity, rank, select top 2-3.

## Job Mapping (JTBD)

### Universal Job Map Steps

| Step | Goal | Outcome Format |
|------|------|---------------|
| Define | Determine what needs doing | Minimize time to identify [object] |
| Locate | Find inputs/information | Minimize time to gather [resources] |
| Prepare | Ready inputs for use | Minimize likelihood of missing [requirements] |
| Confirm | Verify readiness | Minimize likelihood of incorrect [categorization] |
| Execute | Perform core task | Minimize time from [start] to [completion] |
| Monitor | Track progress | Minimize uncertainty about [status] |
| Modify | Adjust if needed | Minimize effort to correct [issues] |
| Conclude | Complete the job | Minimize time from [completion] to [result] |

Outcome statement format: **[Direction] + [Metric] + [Object] + [Clarifier]**
Example: "Minimize the time it takes to identify which project budget a new expense should be allocated to"

## Lean Canvas

One-page business model for Phase 4 viability validation.

1. **Problem**: Top 3 problems (Phase 1 validated) | 2. **Customer Segments**: by JTBD
3. **UVP**: single clear message | 4. **Solution**: top 3 features for top problems
5. **Channels**: path to customers (Phase 4 validated) | 6. **Revenue Streams**: monetization
7. **Cost Structure**: key costs | 8. **Key Metrics**: activity metrics
9. **Unfair Advantage**: not easily copied

### 4 Big Risks

| Risk | Question | Validation |
|------|----------|-----------|
| Value | Will customers want this? | Interviews, fake doors |
| Usability | Can customers use this? | Prototype testing, task completion |
| Feasibility | Can we build this? | Spikes, expert review |
| Viability | Business model works? | Lean Canvas, stakeholder review |

## Technique Selection Guide

| Goal | Techniques |
|------|-----------|
| Validate problem | Mom Test, Job Mapping |
| Understand needs | Outcome Statements, Opportunity Mapping |
| Prioritize opportunities | OST, Opportunity Algorithm |
| Generate solutions | Ideation with OST constraints |
| Validate solution value | Hypothesis Testing, Prototypes |
| Test usability | Prototype testing, Task completion |
| Assess feasibility | 4 Risks, Spikes |
| Structure business model | Lean Canvas |
| Continuous learning | Weekly customer touchpoints |
