"""Tests for helper classes: DbCollections, VersionalLocker, DistributedCounters."""

from unittest.mock import MagicMock, patch

import pytest


class TestDbCollections:
    """Tests for DbCollections class."""

    def test_get_doc_collection_creates_indexes(self):
        """Test that get_doc_collection creates proper indexes."""
        from doc_store.doc_store import DbCollections

        mock_db = MagicMock()
        mock_coll = MagicMock()
        mock_db.get_collection.return_value = mock_coll

        db_colls = DbCollections(mock_db)
        result = db_colls.get_doc_collection("test_collection")

        mock_db.get_collection.assert_called_once_with("test_collection")
        assert mock_coll.create_index.call_count == 4  # id, tags, attrs, metrics

    def test_docs_collection_unique_indexes(self):
        """Test that docs collection has unique indexes for pdf_path and pdf_hash."""
        from doc_store.doc_store import DbCollections

        mock_db = MagicMock()
        mock_coll = MagicMock()
        mock_db.get_collection.return_value = mock_coll

        db_colls = DbCollections(mock_db)
        _ = db_colls.docs

        # Verify unique indexes were created
        index_calls = mock_coll.create_index.call_args_list
        unique_indexes = [call for call in index_calls if call[1].get("unique")]
        assert len(unique_indexes) >= 2

    def test_pages_collection_indexes(self):
        """Test that pages collection has proper indexes."""
        from doc_store.doc_store import DbCollections

        mock_db = MagicMock()
        mock_coll = MagicMock()
        mock_db.get_collection.return_value = mock_coll

        db_colls = DbCollections(mock_db)
        _ = db_colls.pages

        assert mock_coll.create_index.called

    def test_layouts_collection_indexes(self):
        """Test that layouts collection has proper indexes."""
        from doc_store.doc_store import DbCollections

        mock_db = MagicMock()
        mock_coll = MagicMock()
        mock_db.get_collection.return_value = mock_coll

        db_colls = DbCollections(mock_db)
        _ = db_colls.layouts

        assert mock_coll.create_index.called

    def test_blocks_collection_indexes(self):
        """Test that blocks collection has proper indexes."""
        from doc_store.doc_store import DbCollections

        mock_db = MagicMock()
        mock_coll = MagicMock()
        mock_db.get_collection.return_value = mock_coll

        db_colls = DbCollections(mock_db)
        _ = db_colls.blocks

        assert mock_coll.create_index.called

    def test_contents_collection_indexes(self):
        """Test that contents collection has proper indexes."""
        from doc_store.doc_store import DbCollections

        mock_db = MagicMock()
        mock_coll = MagicMock()
        mock_db.get_collection.return_value = mock_coll

        db_colls = DbCollections(mock_db)
        _ = db_colls.contents

        assert mock_coll.create_index.called

    def test_values_collection_indexes(self):
        """Test that values collection has proper indexes."""
        from doc_store.doc_store import DbCollections

        mock_db = MagicMock()
        mock_coll = MagicMock()
        mock_db.get_collection.return_value = mock_coll

        db_colls = DbCollections(mock_db)
        _ = db_colls.values

        assert mock_coll.create_index.called

    def test_tasks_collection_indexes(self):
        """Test that tasks collection has proper indexes."""
        from doc_store.doc_store import DbCollections

        mock_db = MagicMock()
        mock_coll = MagicMock()
        mock_db.get_collection.return_value = mock_coll

        db_colls = DbCollections(mock_db)
        _ = db_colls.tasks

        assert mock_coll.create_index.called

    def test_triggers_collection_indexes(self):
        """Test that triggers collection has proper indexes."""
        from doc_store.doc_store import DbCollections

        mock_db = MagicMock()
        mock_coll = MagicMock()
        mock_db.get_collection.return_value = mock_coll

        db_colls = DbCollections(mock_db)
        _ = db_colls.triggers

        assert mock_coll.create_index.called


class TestVersionalLocker:
    """Tests for VersionalLocker class."""

    def test_read_ahead_returns_zero_when_no_lock(self):
        """Test read_ahead returns 0 when no lock exists."""
        from doc_store.doc_store import VersionalLocker

        mock_db = MagicMock()
        mock_coll = MagicMock()
        mock_coll.locks = MagicMock()
        mock_coll.locks.find_one.return_value = None

        with patch("doc_store.doc_store.DbCollections", return_value=mock_coll):
            locker = VersionalLocker(mock_db)
            locker.coll.locks.find_one.return_value = None
            version = locker.read_ahead("test-key")

        assert version == 0

    def test_read_ahead_returns_version_when_lock_exists(self):
        """Test read_ahead returns version when lock exists."""
        from doc_store.doc_store import VersionalLocker

        mock_db = MagicMock()

        locker = VersionalLocker(mock_db)
        locker.coll.locks.find_one.return_value = {"key": "test-key", "version": 5}

        version = locker.read_ahead("test-key")
        assert version == 5

    def test_post_commit_creates_lock_when_version_zero(self):
        """Test post_commit creates new lock when version is 0."""
        from doc_store.doc_store import VersionalLocker

        mock_db = MagicMock()

        locker = VersionalLocker(mock_db)
        locker.coll.locks.insert_one = MagicMock()

        locker.post_commit("test-key", 0)
        locker.coll.locks.insert_one.assert_called_once()

    def test_post_commit_updates_lock_when_version_exists(self):
        """Test post_commit updates lock when version > 0."""
        from doc_store.doc_store import VersionalLocker

        mock_db = MagicMock()

        locker = VersionalLocker(mock_db)
        locker.coll.locks.update_one = MagicMock()
        locker.coll.locks.update_one.return_value.modified_count = 1

        locker.post_commit("test-key", 5)
        locker.coll.locks.update_one.assert_called_once()

    def test_post_commit_raises_on_version_mismatch(self):
        """Test post_commit raises LockMismatchError on version mismatch."""
        from doc_store.doc_store import LockMismatchError, VersionalLocker

        mock_db = MagicMock()

        locker = VersionalLocker(mock_db)
        locker.coll.locks.update_one = MagicMock()
        locker.coll.locks.update_one.return_value.modified_count = 0

        with pytest.raises(LockMismatchError):
            locker.post_commit("test-key", 5)

    def test_run_with_lock_executes_function(self):
        """Test run_with_lock executes the given function."""
        from doc_store.doc_store import VersionalLocker

        mock_db = MagicMock()

        locker = VersionalLocker(mock_db)
        locker.coll.locks.find_one.return_value = None
        locker.coll.locks.insert_one = MagicMock()

        func_called = []

        def test_func():
            func_called.append(True)

        locker.run_with_lock("test-key", test_func)
        assert len(func_called) == 1


class TestDistributedCounters:
    """Tests for DistributedCounters class."""

    def test_next_returns_incremented_value(self):
        """Test next returns incremented counter value."""
        from doc_store.doc_store import DistributedCounters

        mock_db = MagicMock()

        counter = DistributedCounters(mock_db)
        counter.coll.counters.find_one_and_update.return_value = {"value": 1}

        result = counter.next("test-counter")
        assert result == 1

    def test_next_increments_counter_multiple_times(self):
        """Test next increments counter on each call."""
        from doc_store.doc_store import DistributedCounters

        mock_db = MagicMock()

        counter = DistributedCounters(mock_db)

        # Simulate incrementing values
        counter.coll.counters.find_one_and_update.side_effect = [
            {"value": 1},
            {"value": 2},
            {"value": 3},
        ]

        assert counter.next("test-counter") == 1
        assert counter.next("test-counter") == 2
        assert counter.next("test-counter") == 3


class TestEntityClasses:
    """Tests for Entity dataclasses."""

    def test_doc_entity_creation(self):
        """Test DocEntity can be created with valid data."""
        from doc_store.doc_store import DocEntity

        entity = DocEntity(
            pdf_path="s3://bucket/doc.pdf",
            pdf_filename="doc.pdf",
            pdf_filesize=10000,
            pdf_hash="abc123",
            num_pages=5,
            page_width=612.0,
            page_height=792.0,
            metadata={"title": "Test"},
            orig_path=None,
            orig_filename=None,
            orig_filesize=None,
            orig_hash=None,
            tags=[],
        )

        assert entity.pdf_path == "s3://bucket/doc.pdf"
        assert entity.num_pages == 5

    def test_page_entity_creation(self):
        """Test PageEntity can be created with valid data."""
        from doc_store.doc_store import PageEntity

        entity = PageEntity(
            doc_id="doc-123",
            page_idx=0,
            image_path="s3://bucket/page.png",
            image_filesize=5000,
            image_hash="abc123",
            image_width=1200,
            image_height=1600,
            image_dpi=144,
            providers=[],
            tags=[],
        )

        assert entity.image_path == "s3://bucket/page.png"
        assert entity.image_width == 1200

    def test_block_entity_creation(self):
        """Test BlockEntity can be created with valid data."""
        from doc_store.doc_store import BlockEntity

        entity = BlockEntity(
            layout_id=None,
            provider=None,
            page_id="page-123",
            type="text",
            bbox=[0.1, 0.1, 0.9, 0.5],
            angle=None,
            score=0.95,
            image_path=None,
            image_filesize=None,
            image_hash=None,
            image_width=None,
            image_height=None,
            versions=[],
            tags=[],
        )

        assert entity.type == "text"
        assert entity.bbox == [0.1, 0.1, 0.9, 0.5]

    def test_content_entity_creation(self):
        """Test ContentEntity can be created with valid data."""
        from doc_store.doc_store import ContentEntity

        entity = ContentEntity(
            block_id="block-123",
            version="test__v1",
            page_id="page-123",
            format="text",
            content="Hello world",
            is_human_label=False,
            tags=[],
        )

        assert entity.content == "Hello world"
        assert entity.format == "text"

    def test_value_entity_creation(self):
        """Test ValueEntity can be created with valid data."""
        from doc_store.doc_store import ValueEntity

        entity = ValueEntity(
            elem_id="block-123",
            key="test__embed",
            type="str",
            value="test value",
        )

        assert entity.key == "test__embed"
        assert entity.value == "test value"

