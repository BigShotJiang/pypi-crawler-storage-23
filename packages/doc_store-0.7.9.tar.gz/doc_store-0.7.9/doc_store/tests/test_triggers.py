"""Tests for trigger operations."""

from unittest.mock import MagicMock, patch

import pytest


def create_mock_doc_store(username="testuser", is_admin=False):
    """Create a mock DocStore with specified configuration."""
    from doc_store.doc_store import DocStore

    mock_mongo = MagicMock()
    mock_db = MagicMock()
    mock_mongo.get_database.return_value = mock_db

    # Create mock collections
    mock_colls = MagicMock()
    for coll_name in [
        "docs", "pages", "layouts", "blocks", "contents",
        "values", "tasks", "known_users", "known_names",
        "embedding_models", "locks", "counters", "triggers",
        "eval_layouts", "eval_contents"
    ]:
        coll = MagicMock()
        coll.create_index = MagicMock()
        setattr(mock_colls, coll_name, coll)

    # Set up users
    default_users = [
        {"name": username, "aliases": [], "restricted": False, "is_admin": is_admin}
    ]

    # Set up known names with a tag for action validation
    known_names = [
        {
            "name": "testuser__sample_tag",
            "display_name": "Sample Tag",
            "description": "",
            "type": "tag",
            "value_type": "null",
            "min_value": 0,
            "max_value": 0,
            "options": {},
            "disabled": False,
        },
    ]

    mock_colls.known_users.find.return_value = default_users
    mock_colls.known_names.find.return_value = known_names

    with patch("doc_store.doc_store.get_mongo_client", return_value=mock_mongo), \
         patch("doc_store.doc_store.get_es_client") as mock_es, \
         patch("doc_store.doc_store.RedisStream") as mock_redis, \
         patch("doc_store.doc_store.KafkaWriter") as mock_kafka, \
         patch("doc_store.doc_store.get_username", return_value=username), \
         patch("doc_store.doc_store.DbCollections", return_value=mock_colls):

        store = DocStore(disable_events=True)
        store.coll = mock_colls
        store._all_users = None
        store._all_known_names = None

        return store, mock_colls


class TestTriggerOperations:
    """Tests for trigger operations."""

    def test_list_triggers_returns_empty(self):
        """Test list_triggers returns empty list when no triggers."""
        store, mock_colls = create_mock_doc_store()
        mock_colls.triggers.find.return_value = []

        result = store.list_triggers()

        assert result == []

    def test_list_triggers_returns_triggers(self):
        """Test list_triggers returns list of triggers."""
        from doc_store.interface import Trigger

        store, mock_colls = create_mock_doc_store()
        mock_colls.triggers.find.return_value = [
            {
                "id": "trigger-123",
                "name": "testuser__trigger1",
                "description": "Test trigger",
                "condition": {
                    "elem_type": "page",
                    "event_type": "insert",
                },
                "actions": [
                    {"action_type": "add_tag", "add_tag": "testuser__sample_tag"},
                ],
                "create_user": "testuser",
                "create_time": 1700000000000,
                "update_time": 1700000000000,
            },
        ]

        result = store.list_triggers()

        assert len(result) == 1
        assert isinstance(result[0], Trigger)

    def test_get_trigger_returns_trigger(self):
        """Test get_trigger returns trigger by ID."""
        from doc_store.interface import Trigger

        store, mock_colls = create_mock_doc_store()
        mock_colls.triggers.find_one.return_value = {
            "id": "trigger-123",
            "name": "testuser__trigger1",
            "description": "Test trigger",
            "condition": {
                "elem_type": "page",
                "event_type": "insert",
            },
            "actions": [
                {"action_type": "add_tag", "add_tag": "testuser__sample_tag"},
            ],
            "create_user": "testuser",
            "create_time": 1700000000000,
            "update_time": 1700000000000,
        }

        result = store.get_trigger("trigger-123")

        assert isinstance(result, Trigger)
        assert result.id == "trigger-123"

    def test_get_trigger_raises_not_found(self):
        """Test get_trigger raises error when not found."""
        from doc_store.interface import NotFoundError

        store, mock_colls = create_mock_doc_store()
        mock_colls.triggers.find_one.return_value = None

        with pytest.raises(NotFoundError):
            store.get_trigger("nonexistent")

    def test_insert_trigger_success(self):
        """Test insert_trigger creates a new trigger."""
        from doc_store.interface import Trigger, TriggerAction, TriggerCondition, TriggerInput

        store, mock_colls = create_mock_doc_store(is_admin=True)

        trigger_input = TriggerInput(
            name="testuser__new_trigger",
            description="New trigger",
            condition=TriggerCondition(
                elem_type="page",
                event_type="insert",
            ),
            actions=[
                TriggerAction(action_type="add_tag", add_tag="testuser__sample_tag"),
            ],
        )

        result = store.insert_trigger(trigger_input)

        assert isinstance(result, Trigger)
        assert result.name == "testuser__new_trigger"
        mock_colls.triggers.insert_one.assert_called_once()

    def test_insert_trigger_requires_admin(self):
        """Test insert_trigger requires admin privileges."""
        from doc_store.interface import TriggerAction, TriggerCondition, TriggerInput

        store, _ = create_mock_doc_store(is_admin=False)

        trigger_input = TriggerInput(
            name="testuser__trigger",
            condition=TriggerCondition(elem_type="page", event_type="insert"),
            actions=[TriggerAction(action_type="add_tag", add_tag="testuser__sample_tag")],
        )

        with pytest.raises(PermissionError):
            store.insert_trigger(trigger_input)

    def test_insert_trigger_validates_name(self):
        """Test insert_trigger validates trigger name format."""
        from doc_store.interface import TriggerAction, TriggerCondition, TriggerInput

        store, _ = create_mock_doc_store(is_admin=True)

        # Invalid prefix
        trigger_input = TriggerInput(
            name="wronguser__trigger",
            condition=TriggerCondition(elem_type="page", event_type="insert"),
            actions=[TriggerAction(action_type="add_tag", add_tag="testuser__sample_tag")],
        )

        with pytest.raises(ValueError, match="start with"):
            store.insert_trigger(trigger_input)

    def test_insert_trigger_validates_condition_elem_type(self):
        """Test insert_trigger validates condition elem_type."""
        from doc_store.interface import TriggerAction, TriggerCondition, TriggerInput

        store, _ = create_mock_doc_store(is_admin=True)

        trigger_input = TriggerInput(
            name="testuser__trigger",
            condition=TriggerCondition(elem_type="invalid", event_type="insert"),
            actions=[TriggerAction(action_type="add_tag", add_tag="testuser__sample_tag")],
        )

        with pytest.raises(ValueError, match="elem_type"):
            store.insert_trigger(trigger_input)

    def test_insert_trigger_validates_condition_event_type(self):
        """Test insert_trigger validates condition event_type."""
        from doc_store.interface import TriggerAction, TriggerCondition, TriggerInput

        store, _ = create_mock_doc_store(is_admin=True)

        trigger_input = TriggerInput(
            name="testuser__trigger",
            condition=TriggerCondition(elem_type="page", event_type="invalid"),
            actions=[TriggerAction(action_type="add_tag", add_tag="testuser__sample_tag")],
        )

        with pytest.raises(ValueError, match="event_type"):
            store.insert_trigger(trigger_input)

    def test_insert_trigger_validates_add_provider_elem_type(self):
        """Test insert_trigger validates add_provider is only for pages."""
        from doc_store.interface import TriggerAction, TriggerCondition, TriggerInput

        store, _ = create_mock_doc_store(is_admin=True)

        trigger_input = TriggerInput(
            name="testuser__trigger",
            condition=TriggerCondition(
                elem_type="block",  # Should be page
                event_type="add_provider",
                provider_added=["testuser__provider"],
            ),
            actions=[TriggerAction(action_type="add_tag", add_tag="testuser__sample_tag")],
        )

        with pytest.raises(ValueError, match="page"):
            store.insert_trigger(trigger_input)

    def test_insert_trigger_validates_add_version_elem_type(self):
        """Test insert_trigger validates add_version is only for blocks."""
        from doc_store.interface import TriggerAction, TriggerCondition, TriggerInput

        store, _ = create_mock_doc_store(is_admin=True)

        trigger_input = TriggerInput(
            name="testuser__trigger",
            condition=TriggerCondition(
                elem_type="page",  # Should be block
                event_type="add_version",
                version_added=["testuser__v1"],
            ),
            actions=[TriggerAction(action_type="add_tag", add_tag="testuser__sample_tag")],
        )

        with pytest.raises(ValueError, match="block"):
            store.insert_trigger(trigger_input)

    def test_insert_trigger_validates_tag_added_with_add_tag(self):
        """Test insert_trigger validates tag_added is required for add_tag event."""
        from doc_store.interface import TriggerAction, TriggerCondition, TriggerInput

        store, _ = create_mock_doc_store(is_admin=True)

        trigger_input = TriggerInput(
            name="testuser__trigger",
            condition=TriggerCondition(
                elem_type="page",
                event_type="add_tag",
                # Missing tag_added
            ),
            actions=[TriggerAction(action_type="add_tag", add_tag="testuser__sample_tag")],
        )

        with pytest.raises(ValueError, match="tag_added"):
            store.insert_trigger(trigger_input)

    def test_insert_trigger_validates_provider_added_with_add_provider(self):
        """Test insert_trigger validates provider_added is required for add_provider event."""
        from doc_store.interface import TriggerAction, TriggerCondition, TriggerInput

        store, _ = create_mock_doc_store(is_admin=True)

        trigger_input = TriggerInput(
            name="testuser__trigger",
            condition=TriggerCondition(
                elem_type="page",
                event_type="add_provider",
                # Missing provider_added
            ),
            actions=[TriggerAction(action_type="add_tag", add_tag="testuser__sample_tag")],
        )

        with pytest.raises(ValueError, match="provider_added"):
            store.insert_trigger(trigger_input)

    def test_insert_trigger_requires_at_least_one_action(self):
        """Test insert_trigger requires at least one action."""
        from doc_store.interface import TriggerCondition, TriggerInput

        store, _ = create_mock_doc_store(is_admin=True)

        trigger_input = TriggerInput(
            name="testuser__trigger",
            condition=TriggerCondition(elem_type="page", event_type="insert"),
            actions=[],  # No actions
        )

        with pytest.raises(ValueError, match="action"):
            store.insert_trigger(trigger_input)

    def test_insert_trigger_validates_add_tag_action(self):
        """Test insert_trigger validates add_tag action has tag specified."""
        from doc_store.interface import TriggerAction, TriggerCondition, TriggerInput

        store, _ = create_mock_doc_store(is_admin=True)

        trigger_input = TriggerInput(
            name="testuser__trigger",
            condition=TriggerCondition(elem_type="page", event_type="insert"),
            actions=[TriggerAction(action_type="add_tag")],  # Missing add_tag
        )

        with pytest.raises(ValueError, match="add_tag"):
            store.insert_trigger(trigger_input)

    def test_insert_trigger_validates_insert_task_action(self):
        """Test insert_trigger validates insert_task action has task input."""
        from doc_store.interface import TriggerAction, TriggerCondition, TriggerInput

        store, _ = create_mock_doc_store(is_admin=True)

        trigger_input = TriggerInput(
            name="testuser__trigger",
            condition=TriggerCondition(elem_type="page", event_type="insert"),
            actions=[TriggerAction(action_type="insert_task")],  # Missing insert_task
        )

        with pytest.raises(ValueError, match="insert_task"):
            store.insert_trigger(trigger_input)

    def test_insert_trigger_raises_duplicate(self):
        """Test insert_trigger raises on duplicate name."""
        import pymongo.errors

        from doc_store.interface import (
            AlreadyExistsError,
            TriggerAction,
            TriggerCondition,
            TriggerInput,
        )

        store, mock_colls = create_mock_doc_store(is_admin=True)
        mock_colls.triggers.insert_one.side_effect = pymongo.errors.DuplicateKeyError("")

        trigger_input = TriggerInput(
            name="testuser__trigger",
            condition=TriggerCondition(elem_type="page", event_type="insert"),
            actions=[TriggerAction(action_type="add_tag", add_tag="testuser__sample_tag")],
        )

        with pytest.raises(AlreadyExistsError):
            store.insert_trigger(trigger_input)

    def test_update_trigger_success(self):
        """Test update_trigger updates an existing trigger."""
        from doc_store.interface import Trigger, TriggerAction, TriggerCondition, TriggerInput

        store, mock_colls = create_mock_doc_store(is_admin=True)
        mock_colls.triggers.find_one_and_update.return_value = {
            "id": "trigger-123",
            "name": "testuser__updated_trigger",
            "description": "Updated description",
            "condition": {
                "elem_type": "page",
                "event_type": "insert",
            },
            "actions": [
                {"action_type": "add_tag", "add_tag": "testuser__sample_tag"},
            ],
            "create_user": "testuser",
            "create_time": 1700000000000,
            "update_time": 1700000001000,
        }

        trigger_input = TriggerInput(
            name="testuser__updated_trigger",
            description="Updated description",
            condition=TriggerCondition(elem_type="page", event_type="insert"),
            actions=[TriggerAction(action_type="add_tag", add_tag="testuser__sample_tag")],
        )

        result = store.update_trigger("trigger-123", trigger_input)

        assert isinstance(result, Trigger)
        assert result.description == "Updated description"

    def test_update_trigger_raises_not_found(self):
        """Test update_trigger raises when trigger not found."""
        from doc_store.interface import (
            NotFoundError,
            TriggerAction,
            TriggerCondition,
            TriggerInput,
        )

        store, mock_colls = create_mock_doc_store(is_admin=True)
        mock_colls.triggers.find_one_and_update.return_value = None

        trigger_input = TriggerInput(
            name="testuser__trigger",
            condition=TriggerCondition(elem_type="page", event_type="insert"),
            actions=[TriggerAction(action_type="add_tag", add_tag="testuser__sample_tag")],
        )

        with pytest.raises(NotFoundError):
            store.update_trigger("nonexistent", trigger_input)

    def test_delete_trigger_success(self):
        """Test delete_trigger removes a trigger."""
        store, mock_colls = create_mock_doc_store(is_admin=True)
        mock_colls.triggers.delete_one.return_value.deleted_count = 1

        store.delete_trigger("trigger-123")

        mock_colls.triggers.delete_one.assert_called_once_with({"id": "trigger-123"})

    def test_delete_trigger_raises_not_found(self):
        """Test delete_trigger raises when trigger not found."""
        from doc_store.interface import NotFoundError

        store, mock_colls = create_mock_doc_store(is_admin=True)
        mock_colls.triggers.delete_one.return_value.deleted_count = 0

        with pytest.raises(NotFoundError):
            store.delete_trigger("nonexistent")

    def test_delete_trigger_requires_admin(self):
        """Test delete_trigger requires admin privileges."""
        store, _ = create_mock_doc_store(is_admin=False)

        with pytest.raises(PermissionError):
            store.delete_trigger("trigger-123")


class TestTriggerConditionValidation:
    """Tests for trigger condition validation rules."""

    def test_page_providers_only_for_page(self):
        """Test page_providers can only be used with page elem_type."""
        from doc_store.interface import TriggerAction, TriggerCondition, TriggerInput

        store, _ = create_mock_doc_store(is_admin=True)

        trigger_input = TriggerInput(
            name="testuser__trigger",
            condition=TriggerCondition(
                elem_type="block",
                event_type="insert",
                page_providers=["testuser__provider"],
            ),
            actions=[TriggerAction(action_type="add_tag", add_tag="testuser__sample_tag")],
        )

        with pytest.raises(ValueError, match="page"):
            store.insert_trigger(trigger_input)

    def test_layout_provider_only_for_layout_and_block(self):
        """Test layout_provider can only be used with layout/block elem_type."""
        from doc_store.interface import TriggerAction, TriggerCondition, TriggerInput

        store, _ = create_mock_doc_store(is_admin=True)

        trigger_input = TriggerInput(
            name="testuser__trigger",
            condition=TriggerCondition(
                elem_type="page",
                event_type="insert",
                layout_provider=["testuser__provider"],
            ),
            actions=[TriggerAction(action_type="add_tag", add_tag="testuser__sample_tag")],
        )

        with pytest.raises(ValueError, match="layout.*block"):
            store.insert_trigger(trigger_input)

    def test_block_type_only_for_block(self):
        """Test block_type can only be used with block elem_type."""
        from doc_store.interface import TriggerAction, TriggerCondition, TriggerInput

        store, _ = create_mock_doc_store(is_admin=True)

        trigger_input = TriggerInput(
            name="testuser__trigger",
            condition=TriggerCondition(
                elem_type="page",
                event_type="insert",
                block_type=["text"],
            ),
            actions=[TriggerAction(action_type="add_tag", add_tag="testuser__sample_tag")],
        )

        with pytest.raises(ValueError, match="block"):
            store.insert_trigger(trigger_input)

    def test_block_versions_only_for_block(self):
        """Test block_versions can only be used with block elem_type."""
        from doc_store.interface import TriggerAction, TriggerCondition, TriggerInput

        store, _ = create_mock_doc_store(is_admin=True)

        trigger_input = TriggerInput(
            name="testuser__trigger",
            condition=TriggerCondition(
                elem_type="page",
                event_type="insert",
                block_versions=["testuser__v1"],
            ),
            actions=[TriggerAction(action_type="add_tag", add_tag="testuser__sample_tag")],
        )

        with pytest.raises(ValueError, match="block"):
            store.insert_trigger(trigger_input)

    def test_content_version_only_for_content(self):
        """Test content_version can only be used with content elem_type."""
        from doc_store.interface import TriggerAction, TriggerCondition, TriggerInput

        store, _ = create_mock_doc_store(is_admin=True)

        trigger_input = TriggerInput(
            name="testuser__trigger",
            condition=TriggerCondition(
                elem_type="page",
                event_type="insert",
                content_version=["testuser__v1"],
            ),
            actions=[TriggerAction(action_type="add_tag", add_tag="testuser__sample_tag")],
        )

        with pytest.raises(ValueError, match="content"):
            store.insert_trigger(trigger_input)

    def test_tag_added_only_for_add_tag_event(self):
        """Test tag_added can only be used with add_tag event_type."""
        from doc_store.interface import TriggerAction, TriggerCondition, TriggerInput

        store, _ = create_mock_doc_store(is_admin=True)

        trigger_input = TriggerInput(
            name="testuser__trigger",
            condition=TriggerCondition(
                elem_type="page",
                event_type="insert",
                tag_added=["testuser__some_tag"],
            ),
            actions=[TriggerAction(action_type="add_tag", add_tag="testuser__sample_tag")],
        )

        with pytest.raises(ValueError, match="add_tag"):
            store.insert_trigger(trigger_input)

    def test_page_providers_not_allowed_with_insert(self):
        """Test page_providers cannot be used with insert event_type."""
        from doc_store.interface import TriggerAction, TriggerCondition, TriggerInput

        store, _ = create_mock_doc_store(is_admin=True)

        trigger_input = TriggerInput(
            name="testuser__trigger",
            condition=TriggerCondition(
                elem_type="page",
                event_type="insert",
                page_providers=["testuser__provider"],
            ),
            actions=[TriggerAction(action_type="add_tag", add_tag="testuser__sample_tag")],
        )

        with pytest.raises(ValueError, match="insert"):
            store.insert_trigger(trigger_input)

    def test_block_versions_not_allowed_with_insert(self):
        """Test block_versions cannot be used with insert event_type."""
        from doc_store.interface import TriggerAction, TriggerCondition, TriggerInput

        store, _ = create_mock_doc_store(is_admin=True)

        trigger_input = TriggerInput(
            name="testuser__trigger",
            condition=TriggerCondition(
                elem_type="block",
                event_type="insert",
                block_versions=["testuser__v1"],
            ),
            actions=[TriggerAction(action_type="add_tag", add_tag="testuser__sample_tag")],
        )

        with pytest.raises(ValueError, match="insert"):
            store.insert_trigger(trigger_input)

    def test_validates_block_type_values(self):
        """Test validates block_type values are valid block types."""
        from doc_store.interface import TriggerAction, TriggerCondition, TriggerInput

        store, _ = create_mock_doc_store(is_admin=True)

        trigger_input = TriggerInput(
            name="testuser__trigger",
            condition=TriggerCondition(
                elem_type="block",
                event_type="insert",
                block_type=["invalid_type"],
            ),
            actions=[TriggerAction(action_type="add_tag", add_tag="testuser__sample_tag")],
        )

        with pytest.raises(ValueError, match="block type"):
            store.insert_trigger(trigger_input)

