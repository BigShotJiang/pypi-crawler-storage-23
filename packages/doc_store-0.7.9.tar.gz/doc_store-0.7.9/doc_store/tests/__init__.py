"""Tests for doc_store module."""

