"""Tests for task operations."""

from unittest.mock import MagicMock, patch

import pytest


def create_mock_doc_store(username="testuser", is_admin=False):
    """Create a mock DocStore with specified configuration."""
    from doc_store.doc_store import DocStore

    mock_mongo = MagicMock()
    mock_db = MagicMock()
    mock_mongo.get_database.return_value = mock_db

    # Create mock collections
    mock_colls = MagicMock()
    for coll_name in [
        "docs", "pages", "layouts", "blocks", "contents",
        "values", "tasks", "known_users", "known_names",
        "embedding_models", "locks", "counters", "triggers",
        "eval_layouts", "eval_contents"
    ]:
        coll = MagicMock()
        coll.create_index = MagicMock()
        setattr(mock_colls, coll_name, coll)

    # Set up users
    default_users = [
        {"name": username, "aliases": [], "restricted": False, "is_admin": is_admin}
    ]

    mock_colls.known_users.find.return_value = default_users
    mock_colls.known_names.find.return_value = []

    mock_redis = MagicMock()
    mock_redis.producer = MagicMock()
    mock_redis.manager = MagicMock()
    mock_redis.client = MagicMock()
    mock_redis.consumer_group = "test-group"

    with patch("doc_store.doc_store.get_mongo_client", return_value=mock_mongo), \
         patch("doc_store.doc_store.get_es_client") as mock_es, \
         patch("doc_store.doc_store.RedisStream", return_value=mock_redis), \
         patch("doc_store.doc_store.KafkaWriter") as mock_kafka, \
         patch("doc_store.doc_store.get_username", return_value=username), \
         patch("doc_store.doc_store.DbCollections", return_value=mock_colls):

        store = DocStore(disable_events=True)
        store.coll = mock_colls
        store.redis_stream = mock_redis
        store._all_users = None
        store._all_known_names = None

        return store, mock_colls, mock_redis


class TestTaskOperations:
    """Tests for task operations."""

    def test_insert_task_success(self):
        """Test insert_task creates a new task."""
        from doc_store.interface import Task, TaskInput

        store, mock_colls, mock_redis = create_mock_doc_store()
        mock_redis.producer.add.return_value = "message-id-123"

        task_input = TaskInput(
            command="test_command",
            args={"param": "value"},
            priority=1,
        )
        result = store.insert_task("block-123", task_input)

        assert isinstance(result, Task)
        assert result.command == "test_command"
        assert result.target == "block-123"
        mock_redis.producer.add.assert_called_once()

    def test_insert_task_validates_target(self):
        """Test insert_task validates target_id."""
        from doc_store.interface import TaskInput

        store, _, _ = create_mock_doc_store()

        with pytest.raises(ValueError, match="target_id"):
            store.insert_task("", TaskInput(command="test"))

    def test_insert_task_validates_command(self):
        """Test insert_task validates command."""
        from doc_store.interface import TaskInput

        store, _, _ = create_mock_doc_store()

        with pytest.raises(ValueError, match="command"):
            store.insert_task("block-123", TaskInput(command=""))

    def test_insert_task_validates_priority(self):
        """Test insert_task validates priority range."""
        from doc_store.interface import TaskInput

        store, _, _ = create_mock_doc_store()

        # Priority too low
        with pytest.raises(ValueError, match="priority"):
            store.insert_task("block-123", TaskInput(command="test", priority=-1))

        # Priority too high
        with pytest.raises(ValueError, match="priority"):
            store.insert_task("block-123", TaskInput(command="test", priority=10))

    def test_insert_task_validates_args_keys(self):
        """Test insert_task validates args keys are strings."""
        from doc_store.interface import TaskInput

        store, _, _ = create_mock_doc_store()

        # This would fail pydantic validation, but we test the logic
        task_input = TaskInput(command="test", args={"valid": "value"})
        task_input.args = {123: "invalid"}  # Force invalid key

        with pytest.raises(ValueError, match="strings"):
            store.insert_task("block-123", task_input)

    def test_insert_task_with_batch_id(self):
        """Test insert_task with batch_id stores in MongoDB."""
        from doc_store.interface import Task, TaskInput

        store, mock_colls, mock_redis = create_mock_doc_store()
        mock_redis.producer.add.return_value = "message-id-123"

        task_input = TaskInput(
            command="test_command",
            batch_id="batch-001",
        )
        result = store.insert_task("block-123", task_input)

        assert result.batch_id == "batch-001"
        mock_colls.tasks.insert_one.assert_called_once()

    def test_get_task_from_mongodb(self):
        """Test get_task retrieves task from MongoDB."""
        from doc_store.interface import Task

        store, mock_colls, _ = create_mock_doc_store()
        mock_colls.tasks.find_one.return_value = {
            "id": "test_cmd.1.123-456",
            "rid": 12345,
            "target": "block-123",
            "batch_id": "",
            "command": "test_cmd",
            "args": '{"param": "value"}',
            "priority": 1,
            "status": "new",
            "create_user": "testuser",
            "create_time": 1700000000000,
        }

        result = store.get_task("test_cmd.1.123-456")

        assert isinstance(result, Task)
        assert result.command == "test_cmd"

    def test_get_task_from_redis(self):
        """Test get_task retrieves task from Redis when not in MongoDB."""
        from doc_store.interface import Task

        store, mock_colls, mock_redis = create_mock_doc_store()
        mock_colls.tasks.find_one.return_value = None
        mock_redis.manager.get_message.return_value = {
            "target": "block-123",
            "command": "test_cmd",
            "args": '{"param": "value"}',
            "priority": 1,
            "create_user": "testuser",
            "create_time": 1700000000000,
        }

        result = store.get_task("test_cmd.1.message-123")

        assert isinstance(result, Task)
        mock_redis.manager.get_message.assert_called()

    def test_get_task_raises_not_found(self):
        """Test get_task raises error when task not found."""
        store, mock_colls, mock_redis = create_mock_doc_store()
        mock_colls.tasks.find_one.return_value = None
        mock_redis.manager.get_message.return_value = None

        with pytest.raises(ValueError, match="not found"):
            store.get_task("test_cmd.1.nonexistent")

    def test_get_task_old_format_raises(self):
        """Test get_task with old format task ID raises error."""
        store, mock_colls, _ = create_mock_doc_store()
        mock_colls.tasks.find_one.return_value = None

        with pytest.raises(ValueError, match="Old format"):
            store.get_task("old-message-id")

    def test_list_tasks_returns_tasks(self):
        """Test list_tasks returns list of tasks."""
        from doc_store.interface import Task

        store, mock_colls, _ = create_mock_doc_store()

        mock_cursor = MagicMock()
        mock_cursor.skip.return_value = mock_cursor
        mock_cursor.limit.return_value = mock_cursor
        mock_cursor.__iter__ = lambda self: iter([
            {
                "id": "task-1",
                "rid": 123,
                "target": "block-1",
                "batch_id": "",
                "command": "test_cmd",
                "args": "{}",
                "priority": 1,
                "status": "new",
                "create_user": "testuser",
            },
            {
                "id": "task-2",
                "rid": 456,
                "target": "block-2",
                "batch_id": "",
                "command": "test_cmd",
                "args": "{}",
                "priority": 1,
                "status": "done",
                "create_user": "testuser",
            },
        ])
        mock_colls.tasks.find.return_value = mock_cursor

        result = store.list_tasks(command="test_cmd")

        assert len(result) == 2
        assert all(isinstance(t, Task) for t in result)

    def test_list_tasks_with_filters(self):
        """Test list_tasks applies filters."""
        store, mock_colls, _ = create_mock_doc_store()

        mock_cursor = MagicMock()
        mock_cursor.skip.return_value = mock_cursor
        mock_cursor.limit.return_value = mock_cursor
        mock_cursor.__iter__ = lambda self: iter([])
        mock_colls.tasks.find.return_value = mock_cursor

        store.list_tasks(
            target="block-123",
            command="test_cmd",
            status="new",
            create_user="testuser",
            skip=10,
            limit=20,
        )

        # Verify query was built with filters
        call_args = mock_colls.tasks.find.call_args
        query = call_args[0][0]
        assert query.get("target") == "block-123"
        assert query.get("command") == "test_cmd"
        assert query.get("status") == "new"

    def test_grab_new_tasks_returns_tasks(self):
        """Test grab_new_tasks retrieves pending tasks."""
        from doc_store.interface import Task

        store, _, mock_redis = create_mock_doc_store()

        mock_consumer = MagicMock()
        mock_message = MagicMock()
        mock_message.id = "msg-123"
        mock_message.fields = {
            "target": "block-123",
            "command": "test_cmd",
            "args": "{}",
            "priority": 1,
            "create_user": "testuser",
            "create_time": 1700000000000,
        }
        mock_consumer.read_or_claim.return_value = [mock_message]
        mock_redis.get_consumer.return_value = mock_consumer

        result = store.grab_new_tasks("test_cmd", num=5)

        assert len(result) >= 1
        assert all(isinstance(t, Task) for t in result)

    def test_grab_new_tasks_validates_command(self):
        """Test grab_new_tasks validates command."""
        store, _, _ = create_mock_doc_store()

        with pytest.raises(ValueError, match="non-empty"):
            store.grab_new_tasks("")

    def test_grab_new_tasks_validates_hold_sec(self):
        """Test grab_new_tasks validates hold_sec minimum."""
        store, _, _ = create_mock_doc_store()

        with pytest.raises(ValueError, match="30 seconds"):
            store.grab_new_tasks("test_cmd", hold_sec=10)

    def test_update_task_done(self):
        """Test update_task marks task as done."""
        store, _, mock_redis = create_mock_doc_store()

        mock_consumer = MagicMock()
        mock_consumer.ack.return_value = 1
        mock_redis.get_consumer.return_value = mock_consumer

        store.update_task(
            task_id="test_cmd.1.msg-123",
            command="test_cmd",
            status="done",
        )

        mock_consumer.ack.assert_called_once()

    def test_update_task_error(self):
        """Test update_task marks task as error with message."""
        from doc_store.interface import Task

        store, mock_colls, mock_redis = create_mock_doc_store()

        mock_consumer = MagicMock()
        mock_consumer.ack.return_value = 1
        mock_redis.get_consumer.return_value = mock_consumer

        task = Task(
            id="test_cmd.1.msg-123",
            rid=123,
            target="block-123",
            batch_id="",
            command="test_cmd",
            args={},
            priority=1,
            status="new",
            create_user="testuser",
        )

        store.update_task(
            task_id="test_cmd.1.msg-123",
            command="test_cmd",
            status="error",
            error_message="Something went wrong",
            task=task,
        )

        mock_consumer.ack.assert_called_once()
        mock_colls.tasks.update_one.assert_called()

    def test_update_task_validates_task_id(self):
        """Test update_task validates task_id."""
        store, _, _ = create_mock_doc_store()

        with pytest.raises(ValueError, match="task ID"):
            store.update_task("", "test_cmd", "done")

    def test_update_task_validates_command(self):
        """Test update_task validates command."""
        store, _, _ = create_mock_doc_store()

        with pytest.raises(ValueError, match="command"):
            store.update_task("test_cmd.1.msg-123", "", "done")

    def test_update_task_validates_status(self):
        """Test update_task validates status values."""
        store, _, _ = create_mock_doc_store()

        with pytest.raises(ValueError, match="status"):
            store.update_task("test_cmd.1.msg-123", "test_cmd", "invalid")

    def test_update_task_error_requires_message(self):
        """Test update_task with error status requires error_message."""
        store, _, _ = create_mock_doc_store()

        with pytest.raises(ValueError, match="error_message"):
            store.update_task(
                "test_cmd.1.msg-123",
                "test_cmd",
                "error",
            )

    def test_update_task_error_requires_task(self):
        """Test update_task with error status requires task object."""
        store, _, _ = create_mock_doc_store()

        with pytest.raises(ValueError, match="task must be provided"):
            store.update_task(
                "test_cmd.1.msg-123",
                "test_cmd",
                "error",
                error_message="Error occurred",
            )

    def test_update_task_raises_mismatch(self):
        """Test update_task raises TaskMismatchError when ack fails."""
        from doc_store.interface import TaskMismatchError

        store, _, mock_redis = create_mock_doc_store()

        mock_consumer = MagicMock()
        mock_consumer.ack.return_value = 0
        mock_redis.get_consumer.return_value = mock_consumer

        with pytest.raises(TaskMismatchError):
            store.update_task(
                "test_cmd.1.msg-123",
                "test_cmd",
                "done",
            )

    def test_count_tasks_returns_counts(self):
        """Test count_tasks returns task counts."""
        from doc_store.interface import TaskCount

        store, _, mock_redis = create_mock_doc_store()
        mock_redis.client.keys.return_value = ["test_cmd.0", "test_cmd.1"]
        mock_redis.manager.groups_info.return_value = [
            {
                "name": "test-group",
                "entries-read": 100,
                "lag": 20,
                "pending": 5,
            }
        ]

        result = store.count_tasks()

        assert len(result) > 0
        assert all(isinstance(c, TaskCount) for c in result)

    def test_count_tasks_by_command(self):
        """Test count_tasks filters by command."""
        from doc_store.interface import TaskCount

        store, _, mock_redis = create_mock_doc_store()
        mock_redis.manager.groups_info.return_value = [
            {
                "name": "test-group",
                "entries-read": 50,
                "lag": 10,
                "pending": 2,
            }
        ]

        result = store.count_tasks(command="specific_cmd")

        assert all(c.command == "specific_cmd" for c in result if c.command)


class TestTaskIdParsing:
    """Tests for task ID parsing."""

    def test_parse_task_id_new_format(self):
        """Test _parse_task_id with new format."""
        store, _, _ = create_mock_doc_store()

        result = store._parse_task_id("test_cmd.1.msg-123-456")

        assert result is not None
        command, priority, message_id = result
        assert command == "test_cmd"
        assert priority == 1
        assert message_id == "msg-123-456"

    def test_parse_task_id_old_format(self):
        """Test _parse_task_id with old format returns None."""
        store, _, _ = create_mock_doc_store()

        result = store._parse_task_id("simple-message-id")

        assert result is None

    def test_build_task_id(self):
        """Test _build_task_id creates correct format."""
        store, _, _ = create_mock_doc_store()

        result = store._build_task_id("test_cmd", 1, "msg-123")

        assert result == "test_cmd.1.msg-123"

    def test_task_stream(self):
        """Test _task_stream creates correct stream name."""
        store, _, _ = create_mock_doc_store()

        result = store._task_stream("test_cmd", 2)

        assert result == "test_cmd.2"

