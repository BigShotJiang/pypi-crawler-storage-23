"""Tests for DocStore core operations: docs, pages, layouts, blocks, contents."""

import hashlib
import io
from unittest.mock import MagicMock, patch

import pytest
from bson import ObjectId
from PIL import Image


def create_mock_doc_store(
    username="testuser",
    is_admin=False,
    known_names=None,
):
    """Create a mock DocStore with specified configuration."""
    from doc_store.doc_store import DocStore

    mock_mongo = MagicMock()
    mock_db = MagicMock()
    mock_mongo.get_database.return_value = mock_db

    # Create mock collections
    mock_colls = MagicMock()
    for coll_name in [
        "docs", "pages", "layouts", "blocks", "contents",
        "values", "tasks", "known_users", "known_names",
        "embedding_models", "locks", "counters", "triggers",
        "eval_layouts", "eval_contents"
    ]:
        coll = MagicMock()
        coll.create_index = MagicMock()
        setattr(mock_colls, coll_name, coll)

    # Set up users
    default_users = [
        {"name": username, "aliases": [], "restricted": False, "is_admin": is_admin}
    ]

    # Set up known names
    default_known_names = known_names or []

    mock_colls.known_users.find.return_value = default_users
    mock_colls.known_names.find.return_value = default_known_names

    with patch("doc_store.doc_store.get_mongo_client", return_value=mock_mongo), \
         patch("doc_store.doc_store.get_es_client") as mock_es, \
         patch("doc_store.doc_store.RedisStream") as mock_redis, \
         patch("doc_store.doc_store.KafkaWriter") as mock_kafka, \
         patch("doc_store.doc_store.get_username", return_value=username), \
         patch("doc_store.doc_store.DbCollections", return_value=mock_colls):

        store = DocStore(disable_events=True)
        store.coll = mock_colls
        store._all_users = None
        store._all_known_names = None

        return store, mock_colls


def create_sample_image_bytes():
    """Create sample image bytes for testing."""
    img = Image.new("RGB", (100, 100), color="white")
    buffer = io.BytesIO()
    buffer.name = "test.png"
    img.save(buffer, format="PNG")
    return buffer.getvalue()


def create_sample_pdf_bytes():
    """Create minimal PDF bytes for testing."""
    return b"""%PDF-1.4
1 0 obj
<< /Type /Catalog /Pages 2 0 R >>
endobj
2 0 obj
<< /Type /Pages /Kids [3 0 R] /Count 1 >>
endobj
3 0 obj
<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Resources << >> >>
endobj
xref
0 4
0000000000 65535 f 
0000000009 00000 n 
0000000058 00000 n 
0000000115 00000 n 
trailer
<< /Size 4 /Root 1 0 R >>
startxref
206
%%EOF"""


class TestDocStoreInitialization:
    """Tests for DocStore initialization."""

    def test_docstore_initializes_successfully(self):
        """Test DocStore initializes without errors."""
        store, _ = create_mock_doc_store()
        assert store is not None
        assert store.username == "testuser"

    def test_docstore_sets_hostname_and_pid(self):
        """Test DocStore sets hostname and pid."""
        store, _ = create_mock_doc_store()
        assert store.hostname is not None
        assert store.pid > 0

    def test_docstore_context_manager(self):
        """Test DocStore can be used as context manager."""
        store, _ = create_mock_doc_store()

        with store as s:
            assert s is store

    def test_docstore_impersonate(self):
        """Test DocStore can impersonate another user."""
        store, _ = create_mock_doc_store(username="original")
        impersonated = store.impersonate("newuser")

        assert impersonated.username == "newuser"
        assert store.username == "original"

    def test_health_check_returns_status(self):
        """Test health_check returns health status."""
        store, _ = create_mock_doc_store()

        result = store.health_check()

        assert result["healthy"] is True
        assert "version" in result


class TestDocOperations:
    """Tests for document operations."""

    def test_get_doc_returns_doc(self):
        """Test get_doc returns document by ID."""
        from doc_store.interface import Doc

        store, mock_colls = create_mock_doc_store()
        mock_colls.docs.find_one.return_value = {
            "_id": ObjectId(),
            "id": "doc-test-123",
            "rid": 12345,
            "pdf_path": "s3://bucket/doc.pdf",
            "pdf_filename": "doc.pdf",
            "pdf_filesize": 10000,
            "pdf_hash": "abc123",
            "num_pages": 5,
            "page_width": 612.0,
            "page_height": 792.0,
            "metadata": {},
            "tags": [],
            "create_time": 1700000000000,
        }

        result = store.get_doc("doc-test-123")
        assert isinstance(result, Doc)
        assert result.id == "doc-test-123"

    def test_get_doc_raises_not_found(self):
        """Test get_doc raises error when doc not found."""
        from doc_store.interface import ElementNotFoundError

        store, mock_colls = create_mock_doc_store()
        mock_colls.docs.find_one.return_value = None

        with pytest.raises(ElementNotFoundError):
            store.get_doc("nonexistent-doc")

    def test_get_doc_by_pdf_path_returns_doc(self):
        """Test get_doc_by_pdf_path returns document."""
        from doc_store.interface import Doc

        store, mock_colls = create_mock_doc_store()
        mock_colls.docs.find_one.return_value = {
            "_id": ObjectId(),
            "id": "doc-test-123",
            "rid": 12345,
            "pdf_path": "s3://bucket/doc.pdf",
            "pdf_filename": "doc.pdf",
            "pdf_filesize": 10000,
            "pdf_hash": "abc123",
            "num_pages": 5,
            "page_width": 612.0,
            "page_height": 792.0,
            "metadata": {},
            "tags": [],
        }

        result = store.get_doc_by_pdf_path("s3://bucket/doc.pdf")
        assert isinstance(result, Doc)

    def test_get_doc_by_pdf_hash_returns_doc(self):
        """Test get_doc_by_pdf_hash returns document."""
        from doc_store.interface import Doc

        store, mock_colls = create_mock_doc_store()
        mock_colls.docs.find_one.return_value = {
            "_id": ObjectId(),
            "id": "doc-test-123",
            "rid": 12345,
            "pdf_path": "s3://bucket/doc.pdf",
            "pdf_filesize": 10000,
            "pdf_hash": "abc123",
            "num_pages": 5,
            "page_width": 612.0,
            "page_height": 792.0,
            "metadata": {},
            "tags": [],
        }

        result = store.get_doc_by_pdf_hash("ABC123")  # Should be lowercased
        assert isinstance(result, Doc)

    def test_insert_doc_validates_pdf_path(self):
        """Test insert_doc validates pdf_path format."""
        from doc_store.interface import DocInput

        store, _ = create_mock_doc_store()

        # Empty path
        with pytest.raises(ValueError, match="non-empty"):
            store.insert_doc(DocInput(pdf_path=""))

        # Non-S3 path
        with pytest.raises(ValueError, match="s3://"):
            store.insert_doc(DocInput(pdf_path="/local/path/doc.pdf"))

        # Non-PDF extension
        with pytest.raises(ValueError, match=".pdf"):
            store.insert_doc(DocInput(pdf_path="s3://bucket/doc.txt"))

    def test_insert_doc_validates_orig_path(self):
        """Test insert_doc validates orig_path format."""
        from doc_store.interface import DocInput

        store, _ = create_mock_doc_store()

        # Non-S3 path
        with pytest.raises(ValueError, match="s3://"):
            store.insert_doc(DocInput(
                pdf_path="s3://bucket/doc.pdf",
                orig_path="/local/path/doc.docx"
            ))

        # Wrong extension
        with pytest.raises(ValueError, match="docx|pptx"):
            store.insert_doc(DocInput(
                pdf_path="s3://bucket/doc.pdf",
                orig_path="s3://bucket/doc.txt"
            ))

    def test_insert_doc_raises_on_duplicate(self):
        """Test insert_doc raises error when doc already exists."""
        from doc_store.interface import DocExistsError, DocInput

        store, mock_colls = create_mock_doc_store()
        mock_colls.docs.find_one.return_value = {"id": "existing-doc"}

        with pytest.raises(DocExistsError):
            store.insert_doc(DocInput(pdf_path="s3://bucket/existing.pdf"))


class TestPageOperations:
    """Tests for page operations."""

    def test_get_page_returns_page(self):
        """Test get_page returns page by ID."""
        from doc_store.interface import Page

        store, mock_colls = create_mock_doc_store()
        mock_colls.pages.find_one.return_value = {
            "_id": ObjectId(),
            "id": "page-test-123",
            "rid": 12345,
            "doc_id": "doc-123",
            "page_idx": 0,
            "image_path": "s3://bucket/page.png",
            "image_filesize": 5000,
            "image_hash": "abc123",
            "image_width": 1200,
            "image_height": 1600,
            "providers": [],
            "tags": [],
        }

        result = store.get_page("page-test-123")
        assert isinstance(result, Page)
        assert result.id == "page-test-123"

    def test_get_page_raises_not_found(self):
        """Test get_page raises error when page not found."""
        from doc_store.interface import ElementNotFoundError

        store, mock_colls = create_mock_doc_store()
        mock_colls.pages.find_one.return_value = None

        with pytest.raises(ElementNotFoundError):
            store.get_page("nonexistent-page")

    def test_get_page_by_image_path_returns_page(self):
        """Test get_page_by_image_path returns page."""
        from doc_store.interface import Page

        store, mock_colls = create_mock_doc_store()
        mock_colls.pages.find_one.return_value = {
            "_id": ObjectId(),
            "id": "page-test-123",
            "rid": 12345,
            "image_path": "s3://bucket/page.png",
            "image_filesize": 5000,
            "image_hash": "abc123",
            "image_width": 1200,
            "image_height": 1600,
            "providers": [],
            "tags": [],
        }

        result = store.get_page_by_image_path("s3://bucket/page.png")
        assert isinstance(result, Page)

    def test_insert_page_validates_image_path(self):
        """Test insert_page validates image_path format."""
        from doc_store.interface import PageInput

        store, _ = create_mock_doc_store()

        # Empty path
        with pytest.raises(ValueError, match="non-empty"):
            store.insert_page(PageInput(image_path=""))

        # Non-S3 path
        with pytest.raises(ValueError, match="s3://"):
            store.insert_page(PageInput(image_path="/local/path/page.png"))

        # Wrong extension
        with pytest.raises(ValueError, match="jpg|png|webp"):
            store.insert_page(PageInput(image_path="s3://bucket/page.gif"))

    def test_insert_page_validates_doc_id_and_page_idx(self):
        """Test insert_page validates doc_id and page_idx together."""
        from doc_store.interface import PageInput

        store, mock_colls = create_mock_doc_store()

        # Empty doc_id with page_idx
        with pytest.raises(ValueError):
            store.insert_page(PageInput(
                image_path="s3://bucket/page.png",
                doc_id="",
                page_idx=0,
            ))

        # doc_id without page_idx
        with pytest.raises(ValueError, match="page_idx"):
            store.insert_page(PageInput(
                image_path="s3://bucket/page.png",
                doc_id="doc-123",
            ))

        # Negative page_idx
        mock_colls.docs.find_one.return_value = {"id": "doc-123", "num_pages": 5}
        with pytest.raises(ValueError, match="non-negative"):
            store.insert_page(PageInput(
                image_path="s3://bucket/page.png",
                doc_id="doc-123",
                page_idx=-1,
            ))

    def test_insert_page_validates_doc_exists(self):
        """Test insert_page validates that doc exists."""
        from doc_store.interface import PageInput

        store, mock_colls = create_mock_doc_store()
        mock_colls.docs.find_one.return_value = None

        with pytest.raises(ValueError, match="does not exist"):
            store.insert_page(PageInput(
                image_path="s3://bucket/page.png",
                doc_id="nonexistent-doc",
                page_idx=0,
            ))

    def test_insert_page_raises_on_duplicate(self):
        """Test insert_page raises error when page already exists."""
        from doc_store.interface import ElementExistsError, PageInput

        store, mock_colls = create_mock_doc_store()
        mock_colls.pages.find_one.return_value = {"id": "existing-page"}

        with pytest.raises(ElementExistsError):
            store.insert_page(PageInput(image_path="s3://bucket/existing.png"))


class TestLayoutOperations:
    """Tests for layout operations."""

    def test_get_layout_returns_layout(self):
        """Test get_layout returns layout by ID."""
        from doc_store.interface import Layout

        store, mock_colls = create_mock_doc_store()
        mock_colls.layouts.find_one.return_value = {
            "_id": ObjectId(),
            "id": "layout-test-123",
            "rid": 12345,
            "page_id": "page-123",
            "provider": "test__provider",
            "masks": [],
            "blocks": [],
            "relations": [],
            "contents": [],
            "is_human_label": False,
            "tags": [],
        }

        result = store.get_layout("layout-test-123")
        assert isinstance(result, Layout)
        assert result.id == "layout-test-123"

    def test_get_layout_raises_not_found(self):
        """Test get_layout raises error when layout not found."""
        from doc_store.interface import ElementNotFoundError

        store, mock_colls = create_mock_doc_store()
        mock_colls.layouts.find_one.return_value = None

        with pytest.raises(ElementNotFoundError):
            store.get_layout("nonexistent-layout")

    def test_get_layout_by_page_id_and_provider(self):
        """Test get_layout_by_page_id_and_provider returns layout."""
        from doc_store.interface import Layout

        store, mock_colls = create_mock_doc_store()
        mock_colls.layouts.find_one.return_value = {
            "_id": ObjectId(),
            "id": "layout-test-123",
            "rid": 12345,
            "page_id": "page-123",
            "provider": "test__provider",
            "masks": [],
            "blocks": [],
            "relations": [],
            "contents": [],
            "tags": [],
        }

        result = store.get_layout_by_page_id_and_provider("page-123", "test__provider")
        assert isinstance(result, Layout)

    def test_insert_layout_validates_provider(self):
        """Test insert_layout validates provider format."""
        from doc_store.interface import LayoutInput

        store, mock_colls = create_mock_doc_store()
        mock_colls.pages.find_one.return_value = {"id": "page-123"}
        mock_colls.layouts.find_one.return_value = None

        # Invalid provider format (no underscore prefix)
        with pytest.raises(ValueError, match="start with"):
            store.insert_layout(
                "page-123",
                "invalid_provider",
                LayoutInput(blocks=[])
            )

    def test_insert_layout_validates_page_exists(self):
        """Test insert_layout validates that page exists."""
        from doc_store.interface import LayoutInput

        store, mock_colls = create_mock_doc_store()
        mock_colls.pages.find_one.return_value = None

        with pytest.raises(ValueError, match="does not exist"):
            store.insert_layout(
                "nonexistent-page",
                "testuser__provider",
                LayoutInput(blocks=[])
            )

    def test_insert_layout_raises_on_duplicate(self):
        """Test insert_layout raises error when layout already exists."""
        from doc_store.interface import ElementExistsError, LayoutInput

        store, mock_colls = create_mock_doc_store()
        mock_colls.pages.find_one.return_value = {"id": "page-123"}
        mock_colls.layouts.find_one.return_value = {"id": "existing-layout"}

        with pytest.raises(ElementExistsError):
            store.insert_layout(
                "page-123",
                "testuser__provider",
                LayoutInput(blocks=[])
            )


class TestBlockOperations:
    """Tests for block operations."""

    def test_get_block_returns_block(self):
        """Test get_block returns block by ID."""
        from doc_store.interface import Block

        store, mock_colls = create_mock_doc_store()
        mock_colls.blocks.find_one.return_value = {
            "_id": ObjectId(),
            "id": "block-test-123",
            "rid": 12345,
            "page_id": "page-123",
            "type": "text",
            "bbox": "0.1000,0.1000,0.9000,0.5000",
            "angle": None,
            "versions": [],
            "tags": [],
        }

        result = store.get_block("block-test-123")
        assert isinstance(result, Block)
        assert result.id == "block-test-123"
        assert result.bbox == [0.1, 0.1, 0.9, 0.5]

    def test_get_block_raises_not_found(self):
        """Test get_block raises error when block not found."""
        from doc_store.interface import ElementNotFoundError

        store, mock_colls = create_mock_doc_store()
        mock_colls.blocks.find_one.return_value = None

        with pytest.raises(ElementNotFoundError):
            store.get_block("nonexistent-block")

    def test_get_super_block_creates_if_not_exists(self):
        """Test get_super_block creates super block if not exists."""
        from doc_store.interface import Block

        store, mock_colls = create_mock_doc_store()
        # First two find_one calls return None (no existing super block)
        # Third returns the page
        mock_colls.blocks.find_one.side_effect = [None, None]
        mock_colls.pages.find_one.return_value = {"id": "page-123"}
        mock_colls.blocks.insert_one.return_value = MagicMock()

        # Mock _insert_blocks to return a block
        with patch.object(store, "_insert_blocks") as mock_insert:
            mock_block = Block(
                id="block-super-123",
                rid=12345,
                page_id="page-123",
                type="super",
                bbox=[0.0, 0.0, 1.0, 1.0],
                angle=None,
                tags=[],
            )
            mock_insert.return_value = [mock_block]

            result = store.get_super_block("page-123")
            assert result.type == "super"
            assert result.bbox == [0.0, 0.0, 1.0, 1.0]

    def test_insert_block_validates_page_exists(self):
        """Test insert_block validates that page exists."""
        from doc_store.interface import BlockInput

        store, mock_colls = create_mock_doc_store()
        mock_colls.pages.find_one.return_value = None

        with pytest.raises(ValueError, match="does not exist"):
            store.insert_block(
                "nonexistent-page",
                BlockInput(type="text", bbox=[0.1, 0.1, 0.9, 0.5])
            )

    def test_insert_block_validates_bbox(self):
        """Test insert_block validates bbox format."""
        from doc_store.interface import BlockInput

        store, mock_colls = create_mock_doc_store()
        mock_colls.pages.find_one.return_value = {"id": "page-123"}

        # bbox outside range
        with pytest.raises(ValueError, match="0.0.*1.0"):
            store.insert_block(
                "page-123",
                BlockInput(type="text", bbox=[0.1, 0.1, 1.5, 0.5])
            )

        # bbox x1 >= x2
        with pytest.raises(ValueError, match="x1 >= x2"):
            store.insert_block(
                "page-123",
                BlockInput(type="text", bbox=[0.9, 0.1, 0.1, 0.5])
            )

        # bbox wrong length
        with pytest.raises(ValueError, match="4"):
            store.insert_block(
                "page-123",
                BlockInput(type="text", bbox=[0.1, 0.1, 0.9])
            )

    def test_insert_block_validates_type(self):
        """Test insert_block validates block type."""
        from doc_store.interface import BlockInput

        store, mock_colls = create_mock_doc_store()
        mock_colls.pages.find_one.return_value = {"id": "page-123"}

        # Unknown type
        with pytest.raises(ValueError, match="unknown block type"):
            store.insert_block(
                "page-123",
                BlockInput(type="invalid_type", bbox=[0.1, 0.1, 0.9, 0.5])
            )

    def test_insert_block_validates_angle(self):
        """Test insert_block validates angle values."""
        from doc_store.interface import BlockInput

        store, mock_colls = create_mock_doc_store()
        mock_colls.pages.find_one.return_value = {"id": "page-123"}

        # Invalid angle
        with pytest.raises(ValueError, match="angle"):
            store.insert_block(
                "page-123",
                BlockInput(type="text", bbox=[0.1, 0.1, 0.9, 0.5], angle=45)
            )

    def test_insert_blocks_returns_list(self):
        """Test insert_blocks returns list of blocks."""
        from doc_store.interface import Block, BlockInput

        store, mock_colls = create_mock_doc_store()
        mock_colls.pages.find_one.return_value = {"id": "page-123"}

        # Mock insert_one to not raise
        mock_colls.blocks.insert_one.return_value = MagicMock()

        blocks_input = [
            BlockInput(type="text", bbox=[0.1, 0.1, 0.4, 0.3]),
            BlockInput(type="title", bbox=[0.1, 0.4, 0.9, 0.5]),
        ]

        result = store.insert_blocks("page-123", blocks_input)
        assert len(result) == 2
        assert all(isinstance(b, Block) for b in result)


class TestContentOperations:
    """Tests for content operations."""

    def test_get_content_returns_content(self):
        """Test get_content returns content by ID."""
        from doc_store.interface import Content

        store, mock_colls = create_mock_doc_store()
        mock_colls.contents.find_one.return_value = {
            "_id": ObjectId(),
            "id": "content-test-123",
            "rid": 12345,
            "block_id": "block-123",
            "version": "test__v1",
            "page_id": "page-123",
            "format": "text",
            "content": "Hello world",
            "is_human_label": False,
            "tags": [],
        }

        result = store.get_content("content-test-123")
        assert isinstance(result, Content)
        assert result.id == "content-test-123"

    def test_get_content_raises_not_found(self):
        """Test get_content raises error when content not found."""
        from doc_store.interface import ElementNotFoundError

        store, mock_colls = create_mock_doc_store()
        mock_colls.contents.find_one.return_value = None

        with pytest.raises(ElementNotFoundError):
            store.get_content("nonexistent-content")

    def test_get_content_by_block_id_and_version(self):
        """Test get_content_by_block_id_and_version returns content."""
        from doc_store.interface import Content

        store, mock_colls = create_mock_doc_store()
        mock_colls.contents.find_one.return_value = {
            "_id": ObjectId(),
            "id": "content-test-123",
            "rid": 12345,
            "block_id": "block-123",
            "version": "test__v1",
            "format": "text",
            "content": "Hello world",
            "tags": [],
        }

        result = store.get_content_by_block_id_and_version("block-123", "test__v1")
        assert isinstance(result, Content)

    def test_insert_content_validates_version(self):
        """Test insert_content validates version format."""
        from doc_store.interface import ContentInput

        store, mock_colls = create_mock_doc_store()
        mock_colls.blocks.find_one.return_value = {"id": "block-123", "page_id": "page-123"}

        # Invalid version format
        with pytest.raises(ValueError, match="start with"):
            store.insert_content(
                "block-123",
                "invalid_version",
                ContentInput(format="text", content="Test")
            )

    def test_insert_content_validates_block_exists(self):
        """Test insert_content validates that block exists."""
        from doc_store.interface import ContentInput

        store, mock_colls = create_mock_doc_store()
        mock_colls.blocks.find_one.return_value = None

        with pytest.raises(ValueError, match="does not exist"):
            store.insert_content(
                "nonexistent-block",
                "testuser__v1",
                ContentInput(format="text", content="Test")
            )

    def test_insert_content_validates_format(self):
        """Test insert_content validates content format."""
        from doc_store.interface import ContentInput

        store, mock_colls = create_mock_doc_store()
        mock_colls.blocks.find_one.return_value = {"id": "block-123", "page_id": "page-123"}

        # Invalid format
        with pytest.raises(ValueError, match="format"):
            store.insert_content(
                "block-123",
                "testuser__v1",
                ContentInput(format="invalid_format", content="Test")
            )

    def test_insert_content_raises_on_duplicate(self):
        """Test insert_content raises error when content already exists."""
        from doc_store.interface import ContentInput, ElementExistsError

        store, mock_colls = create_mock_doc_store()
        mock_colls.blocks.find_one.return_value = {"id": "block-123", "page_id": "page-123"}

        # Simulate duplicate key error by returning None from insert
        mock_colls.contents.insert_one.side_effect = Exception("Duplicate")

        with patch.object(store, "_insert_elem", return_value=None):
            with pytest.raises(ElementExistsError):
                store.insert_content(
                    "block-123",
                    "testuser__v1",
                    ContentInput(format="text", content="Test")
                )


class TestValueOperations:
    """Tests for value operations."""

    def test_get_value_returns_value(self):
        """Test get_value returns value by ID."""
        from doc_store.interface import Value

        store, mock_colls = create_mock_doc_store()
        mock_colls.values.find_one.return_value = {
            "_id": ObjectId(),
            "id": "value-test-123",
            "rid": 12345,
            "elem_id": "block-123",
            "key": "test__embed",
            "type": "str",
            "value": "test value",
        }

        result = store.get_value("value-test-123")
        assert isinstance(result, Value)
        assert result.id == "value-test-123"

    def test_get_value_by_elem_id_and_key(self):
        """Test get_value_by_elem_id_and_key returns value."""
        from doc_store.interface import Value

        store, mock_colls = create_mock_doc_store()
        mock_colls.values.find_one.return_value = {
            "_id": ObjectId(),
            "id": "value-test-123",
            "rid": 12345,
            "elem_id": "block-123",
            "key": "test__embed",
            "type": "str",
            "value": "test value",
        }

        result = store.get_value_by_elem_id_and_key("block-123", "test__embed")
        assert isinstance(result, Value)

    def test_insert_value_validates_key(self):
        """Test insert_value validates key format."""
        from doc_store.interface import ValueInput

        store, _ = create_mock_doc_store()

        # Invalid key format
        with pytest.raises(ValueError, match="start with"):
            store.insert_value(
                "block-123",
                "invalid_key",
                ValueInput(value="test")
            )

    def test_insert_value_validates_value_type(self):
        """Test insert_value validates value type."""
        from doc_store.interface import ValueInput

        store, _ = create_mock_doc_store()

        # Invalid value type
        with pytest.raises(ValueError, match="string or numpy"):
            store.insert_value(
                "block-123",
                "testuser__key",
                ValueInput(value=123)  # Should be str or ndarray
            )

    def test_insert_value_with_ndarray(self):
        """Test insert_value handles numpy array."""
        import numpy as np

        from doc_store.interface import Value, ValueInput

        store, mock_colls = create_mock_doc_store()
        mock_colls.values.insert_one.return_value = MagicMock()

        vector = np.array([1.0, 2.0, 3.0])
        result = store.insert_value(
            "block-123",
            "testuser__embed",
            ValueInput(value=vector)
        )

        assert isinstance(result, Value)


class TestFindAndCount:
    """Tests for find and count operations."""

    def test_find_returns_elements(self):
        """Test find returns matching elements."""
        from doc_store.interface import Page

        store, mock_colls = create_mock_doc_store()
        mock_colls.pages.find.return_value = [
            {
                "id": "page-1",
                "rid": 123,
                "image_path": "s3://bucket/p1.png",
                "image_filesize": 5000,
                "image_hash": "abc",
                "image_width": 100,
                "image_height": 100,
                "providers": [],
                "tags": [],
            },
            {
                "id": "page-2",
                "rid": 456,
                "image_path": "s3://bucket/p2.png",
                "image_filesize": 5000,
                "image_hash": "def",
                "image_width": 100,
                "image_height": 100,
                "providers": [],
                "tags": [],
            },
        ]

        results = list(store.find("page", {}))
        assert len(results) == 2
        assert all(isinstance(r, Page) for r in results)

    def test_count_returns_count(self):
        """Test count returns document count."""
        store, mock_colls = create_mock_doc_store()
        mock_colls.pages.count_documents.return_value = 42

        result = store.count("page", {})
        assert result == 42

    def test_count_estimated_returns_estimate(self):
        """Test count with estimated=True returns estimated count."""
        store, mock_colls = create_mock_doc_store()
        mock_colls.pages.estimated_document_count.return_value = 1000

        result = store.count("page", estimated=True)
        assert result == 1000

    def test_distinct_values_returns_values(self):
        """Test distinct_values returns unique values."""
        store, mock_colls = create_mock_doc_store()
        mock_colls.pages.distinct.return_value = ["provider1", "provider2"]

        result = store.distinct_values("page", "providers")
        assert result == ["provider1", "provider2"]


class TestInternalMethods:
    """Tests for internal helper methods."""

    def test_new_id_generates_valid_id(self):
        """Test _new_id generates valid IDs for each element type."""
        from doc_store.interface import Block, Content, Doc, Layout, Page, Value

        store, _ = create_mock_doc_store()

        doc_id = store._new_id(Doc)
        assert doc_id.startswith("doc-")

        page_id = store._new_id(Page)
        assert page_id.startswith("page-")

        layout_id = store._new_id(Layout)
        assert layout_id.startswith("layout-")

        block_id = store._new_id(Block)
        assert block_id.startswith("block-")

        content_id = store._new_id(Content)
        assert content_id.startswith("content-")

        value_id = store._new_id(Value)
        assert value_id.startswith("value-")

    def test_get_elem_type_by_id(self):
        """Test _get_elem_type_by_id returns correct type."""
        from doc_store.interface import Block, Content, Doc, Layout, Page, Value

        store, _ = create_mock_doc_store()

        assert store._get_elem_type_by_id("doc-123") == Doc
        assert store._get_elem_type_by_id("page-123") == Page
        assert store._get_elem_type_by_id("layout-123") == Layout
        assert store._get_elem_type_by_id("block-123") == Block
        assert store._get_elem_type_by_id("content-123") == Content
        assert store._get_elem_type_by_id("value-123") == Value

    def test_parse_block_converts_bbox_string(self):
        """Test _parse_block converts bbox string to list."""
        store, _ = create_mock_doc_store()

        block_data = {
            "type": "text",
            "bbox": "0.1000,0.2000,0.8000,0.9000",
        }

        result = store._parse_block(block_data)
        assert result["bbox"] == [0.1, 0.2, 0.8, 0.9]
        assert result["angle"] is None

    def test_parse_block_handles_list_bbox(self):
        """Test _parse_block handles bbox as list."""
        store, _ = create_mock_doc_store()

        block_data = {
            "type": "text",
            "bbox": [0.1, 0.2, 0.8, 0.9],
            "angle": 90,
        }

        result = store._parse_block(block_data)
        assert result["bbox"] == [0.1, 0.2, 0.8, 0.9]
        assert result["angle"] == 90

    def test_check_name_validates_prefix(self):
        """Test _check_name validates name prefix."""
        store, _ = create_mock_doc_store()

        # Valid name
        store._check_name("provider", "testuser__mymodel")

        # Invalid prefix
        with pytest.raises(ValueError, match="start with"):
            store._check_name("provider", "wronguser__mymodel")

        # No prefix
        with pytest.raises(ValueError, match="start with"):
            store._check_name("provider", "mymodel")

    def test_check_basic_name_validates_characters(self):
        """Test _check_basic_name validates name characters."""
        store, _ = create_mock_doc_store()

        # Valid name
        store._check_basic_name("provider", "valid_name123")

        # Invalid characters
        with pytest.raises(ValueError, match="alphanumeric"):
            store._check_basic_name("provider", "invalid-name")

        with pytest.raises(ValueError, match="alphanumeric"):
            store._check_basic_name("provider", "invalid@name")

