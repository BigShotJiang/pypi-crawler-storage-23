"""Tests for evaluation operations: eval layouts and eval contents."""

from unittest.mock import MagicMock, patch

import pytest
from bson import ObjectId


def create_mock_doc_store(username="testuser", is_admin=False):
    """Create a mock DocStore with specified configuration."""
    from doc_store.doc_store import DocStore

    mock_mongo = MagicMock()
    mock_db = MagicMock()
    mock_mongo.get_database.return_value = mock_db

    # Create mock collections
    mock_colls = MagicMock()
    for coll_name in [
        "docs",
        "pages",
        "layouts",
        "blocks",
        "contents",
        "values",
        "tasks",
        "known_users",
        "known_names",
        "embedding_models",
        "locks",
        "counters",
        "triggers",
        "eval_layouts",
        "eval_contents",
    ]:
        coll = MagicMock()
        coll.create_index = MagicMock()
        setattr(mock_colls, coll_name, coll)

    # Set up users
    default_users = [{"name": username, "aliases": [], "restricted": False, "is_admin": is_admin}]

    mock_colls.known_users.find.return_value = default_users
    mock_colls.known_names.find.return_value = []

    with (
        patch("doc_store.doc_store.get_mongo_client", return_value=mock_mongo),
        patch("doc_store.doc_store.get_es_client") as mock_es,
        patch("doc_store.doc_store.RedisStream") as mock_redis,
        patch("doc_store.doc_store.KafkaWriter") as mock_kafka,
        patch("doc_store.doc_store.get_username", return_value=username),
        patch("doc_store.doc_store.DbCollections", return_value=mock_colls),
    ):

        store = DocStore(disable_events=True)
        store.coll = mock_colls
        store._all_users = None
        store._all_known_names = None

        return store, mock_colls


class TestEvalLayoutOperations:
    """Tests for eval layout operations."""

    def test_get_eval_layout_returns_eval_layout(self):
        """Test get_eval_layout returns eval layout by ID."""
        from doc_store.interface import EvalLayout

        store, mock_colls = create_mock_doc_store()
        mock_colls.eval_layouts.find_one.return_value = {
            "_id": ObjectId(),
            "id": "evallayout-test-123",
            "rid": 12345,
            "layout_id": "layout-123",
            "provider": "test__provider",
            "blocks": [],
            "relations": [],
            "status": "pending",
            "tags": [],
        }

        result = store.get_eval_layout("evallayout-test-123")

        assert isinstance(result, EvalLayout)
        assert result.id == "evallayout-test-123"

    def test_get_eval_layout_raises_not_found(self):
        """Test get_eval_layout raises error when not found."""
        from doc_store.interface import ElementNotFoundError

        store, mock_colls = create_mock_doc_store()
        mock_colls.eval_layouts.find_one.return_value = None

        with pytest.raises(ElementNotFoundError):
            store.get_eval_layout("nonexistent")

    def test_insert_eval_layout_success(self):
        """Test insert_eval_layout creates a new eval layout."""
        from doc_store.interface import EvalLayout, EvalLayoutBlock

        store, mock_colls = create_mock_doc_store()
        mock_colls.layouts.find_one.return_value = {
            "id": "layout-123",
            "page_id": "page-123",
            "provider": "test__provider",
        }
        mock_colls.eval_layouts.insert_one.return_value = MagicMock()

        blocks = [
            EvalLayoutBlock(
                id="block-1",
                type="text",
                bbox=[0.1, 0.1, 0.9, 0.5],
                format="text",
                content="Test content",
            )
        ]

        result = store.insert_eval_layout(
            layout_id="layout-123",
            provider="test__provider",
            blocks=blocks,
            relations=[],
        )

        assert isinstance(result, EvalLayout)
        mock_colls.eval_layouts.insert_one.assert_called_once()

    def test_insert_eval_layout_validates_layout_id(self):
        """Test insert_eval_layout validates layout_id."""
        store, _ = create_mock_doc_store()

        with pytest.raises(ValueError, match="layout_id"):
            store.insert_eval_layout(
                layout_id="",
                provider="test__provider",
            )

    def test_insert_eval_layout_validates_provider(self):
        """Test insert_eval_layout validates provider."""
        store, _ = create_mock_doc_store()

        with pytest.raises(ValueError, match="provider"):
            store.insert_eval_layout(
                layout_id="layout-123",
                provider="",
            )

    def test_insert_eval_layout_validates_layout_exists(self):
        """Test insert_eval_layout validates that layout exists."""
        store, mock_colls = create_mock_doc_store()
        mock_colls.layouts.find_one.return_value = None

        with pytest.raises(ValueError, match="does not exist"):
            store.insert_eval_layout(
                layout_id="nonexistent-layout",
                provider="test__provider",
            )

    def test_insert_eval_layout_with_empty_blocks(self):
        """Test insert_eval_layout with empty blocks list."""
        from doc_store.interface import EvalLayout

        store, mock_colls = create_mock_doc_store()
        mock_colls.layouts.find_one.return_value = {
            "id": "layout-123",
            "page_id": "page-123",
            "provider": "test__provider",
        }
        mock_colls.eval_layouts.insert_one.return_value = MagicMock()

        result = store.insert_eval_layout(
            layout_id="layout-123",
            provider="test__provider",
            blocks=None,
            relations=None,
        )

        assert isinstance(result, EvalLayout)
        assert result.blocks == []

    def test_insert_eval_layout_raises_on_duplicate(self):
        """Test insert_eval_layout raises error on duplicate."""
        from doc_store.interface import ElementExistsError

        store, mock_colls = create_mock_doc_store()
        mock_colls.layouts.find_one.return_value = {
            "id": "layout-123",
            "page_id": "page-123",
            "provider": "test__provider",
        }

        with patch.object(store, "_insert_elem", return_value=None):
            with pytest.raises(ElementExistsError):
                store.insert_eval_layout(
                    layout_id="layout-123",
                    provider="test__provider",
                )


class TestEvalContentOperations:
    """Tests for eval content operations."""

    def test_get_eval_content_returns_eval_content(self):
        """Test get_eval_content returns eval content by ID."""
        from doc_store.interface import EvalContent

        store, mock_colls = create_mock_doc_store()
        mock_colls.eval_contents.find_one.return_value = {
            "_id": ObjectId(),
            "id": "evalcontent-test-123",
            "rid": 12345,
            "content_id": "content-123",
            "version": "test__v1",
            "format": "text",
            "content": "Test content",
            "status": "pending",
            "tags": [],
        }

        result = store.get_eval_content("evalcontent-test-123")

        assert isinstance(result, EvalContent)
        assert result.id == "evalcontent-test-123"

    def test_get_eval_content_raises_not_found(self):
        """Test get_eval_content raises error when not found."""
        from doc_store.interface import ElementNotFoundError

        store, mock_colls = create_mock_doc_store()
        mock_colls.eval_contents.find_one.return_value = None

        with pytest.raises(ElementNotFoundError):
            store.get_eval_content("nonexistent")

    def test_insert_eval_content_success(self):
        """Test insert_eval_content creates a new eval content."""
        from doc_store.interface import EvalContent

        store, mock_colls = create_mock_doc_store()
        mock_colls.contents.find_one.return_value = {
            "id": "content-123",
            "block_id": "block-123",
            "version": "test__v1",
            "format": "text",
            "content": "Original content",
        }
        mock_colls.eval_contents.insert_one.return_value = MagicMock()

        result = store.insert_eval_content(
            content_id="content-123",
            version="test__eval_v1",
            format="text",
            content="Evaluated content",
        )

        assert isinstance(result, EvalContent)
        mock_colls.eval_contents.insert_one.assert_called_once()

    def test_insert_eval_content_validates_content_id(self):
        """Test insert_eval_content validates content_id."""
        store, _ = create_mock_doc_store()

        with pytest.raises(ValueError, match="content_id"):
            store.insert_eval_content(
                content_id="",
                version="test__v1",
                format="text",
                content="Content",
            )

    def test_insert_eval_content_validates_version(self):
        """Test insert_eval_content validates version."""
        store, _ = create_mock_doc_store()

        with pytest.raises(ValueError, match="version"):
            store.insert_eval_content(
                content_id="content-123",
                version="",
                format="text",
                content="Content",
            )

    def test_insert_eval_content_validates_content_exists(self):
        """Test insert_eval_content validates that content exists."""
        store, mock_colls = create_mock_doc_store()
        mock_colls.contents.find_one.return_value = None

        with pytest.raises(ValueError, match="does not exist"):
            store.insert_eval_content(
                content_id="nonexistent-content",
                version="test__v1",
                format="text",
                content="Content",
            )

    def test_insert_eval_content_raises_on_duplicate(self):
        """Test insert_eval_content raises error on duplicate."""
        from doc_store.interface import ElementExistsError

        store, mock_colls = create_mock_doc_store()
        mock_colls.contents.find_one.return_value = {
            "id": "content-123",
            "block_id": "block-123",
            "version": "test__v1",
        }

        with patch.object(store, "_insert_elem", return_value=None):
            with pytest.raises(ElementExistsError):
                store.insert_eval_content(
                    content_id="content-123",
                    version="test__v1",
                    format="text",
                    content="Content",
                )


class TestEvalBlockParsing:
    """Tests for eval block parsing."""

    def test_eval_layout_parses_blocks(self):
        """Test eval layout correctly parses blocks."""
        from doc_store.interface import EvalLayout, EvalLayoutBlock

        store, mock_colls = create_mock_doc_store()
        mock_colls.eval_layouts.find_one.return_value = {
            "_id": ObjectId(),
            "id": "evallayout-123",
            "rid": 12345,
            "layout_id": "layout-123",
            "provider": "test__provider",
            "blocks": [
                {
                    "id": "block-1",
                    "type": "text",
                    "bbox": [0.1, 0.2, 0.8, 0.9],
                    "angle": 0,
                    "format": "text",
                    "content": "Test content",
                },
                {
                    "id": "block-2",
                    "type": "table",
                    "bbox": [0.1, 0.1, 0.9, 0.5],
                    "angle": 90,
                    "format": "html",
                    "content": "<table></table>",
                },
            ],
            "relations": [],
            "status": "pending",
            "tags": [],
        }

        result = store.get_eval_layout("evallayout-123")

        assert len(result.blocks) == 2
        assert all(isinstance(b, EvalLayoutBlock) for b in result.blocks)
        assert result.blocks[0].type == "text"
        assert result.blocks[1].angle == 90
