"""Tests for tagging operations: tags, attributes, and metrics."""

from unittest.mock import MagicMock, patch

import pytest


def create_mock_doc_store(
    username="testuser",
    is_admin=False,
    known_names=None,
):
    """Create a mock DocStore with specified configuration."""
    from doc_store.doc_store import DocStore

    mock_mongo = MagicMock()
    mock_db = MagicMock()
    mock_mongo.get_database.return_value = mock_db

    # Create mock collections
    mock_colls = MagicMock()
    for coll_name in [
        "docs", "pages", "layouts", "blocks", "contents",
        "values", "tasks", "known_users", "known_names",
        "embedding_models", "locks", "counters", "triggers",
        "eval_layouts", "eval_contents"
    ]:
        coll = MagicMock()
        coll.create_index = MagicMock()
        setattr(mock_colls, coll_name, coll)

    # Set up users
    default_users = [
        {"name": username, "aliases": [], "restricted": False, "is_admin": is_admin}
    ]

    # Set up known names
    default_known_names = known_names or [
        {
            "name": "testuser__sample_tag",
            "display_name": "Sample Tag",
            "description": "",
            "type": "tag",
            "value_type": "null",
            "min_value": 0,
            "max_value": 0,
            "options": {},
            "disabled": False,
        },
        {
            "name": "sample_attr",
            "display_name": "Sample Attr",
            "description": "",
            "type": "attr",
            "value_type": "str",
            "min_value": 0,
            "max_value": 0,
            "options": {"opt1": {"display_name": "Option 1", "description": ""}},
            "disabled": False,
        },
        {
            "name": "int_attr",
            "display_name": "Int Attr",
            "description": "",
            "type": "attr",
            "value_type": "int",
            "min_value": 0,
            "max_value": 100,
            "options": {},
            "disabled": False,
        },
        {
            "name": "bool_attr",
            "display_name": "Bool Attr",
            "description": "",
            "type": "attr",
            "value_type": "bool",
            "min_value": 0,
            "max_value": 0,
            "options": {},
            "disabled": False,
        },
        {
            "name": "list_attr",
            "display_name": "List Attr",
            "description": "",
            "type": "attr",
            "value_type": "list_str",
            "min_value": 0,
            "max_value": 0,
            "options": {"opt1": {}, "opt2": {}},
            "disabled": False,
        },
        {
            "name": "sample_metric",
            "display_name": "Sample Metric",
            "description": "",
            "type": "metric",
            "value_type": "float",
            "min_value": 0.0,
            "max_value": 100.0,
            "options": {},
            "disabled": False,
        },
        {
            "name": "int_metric",
            "display_name": "Int Metric",
            "description": "",
            "type": "metric",
            "value_type": "int",
            "min_value": 0,
            "max_value": 1000,
            "options": {},
            "disabled": False,
        },
        {
            "name": "disabled_tag",
            "display_name": "Disabled Tag",
            "description": "",
            "type": "tag",
            "value_type": "null",
            "min_value": 0,
            "max_value": 0,
            "options": {},
            "disabled": True,
        },
    ]

    mock_colls.known_users.find.return_value = default_users
    mock_colls.known_names.find.return_value = default_known_names

    with patch("doc_store.doc_store.get_mongo_client", return_value=mock_mongo), \
         patch("doc_store.doc_store.get_es_client") as mock_es, \
         patch("doc_store.doc_store.RedisStream") as mock_redis, \
         patch("doc_store.doc_store.KafkaWriter") as mock_kafka, \
         patch("doc_store.doc_store.get_username", return_value=username), \
         patch("doc_store.doc_store.DbCollections", return_value=mock_colls):

        store = DocStore(disable_events=True)
        store.coll = mock_colls
        store._all_users = None
        store._all_known_names = None

        return store, mock_colls


class TestTagOperations:
    """Tests for tag operations."""

    def test_add_tag_success(self):
        """Test add_tag adds tag to element."""
        store, mock_colls = create_mock_doc_store()
        mock_colls.blocks.find_one_and_update.return_value = {
            "id": "block-123",
            "tags": ["testuser__sample_tag"],
        }

        store.add_tag("block-123", "testuser__sample_tag")

        mock_colls.blocks.find_one_and_update.assert_called_once()

    def test_add_tag_validates_tag_name(self):
        """Test add_tag validates tag name format."""
        store, _ = create_mock_doc_store()

        # Non-string tag
        with pytest.raises(ValueError, match="string"):
            store.add_tag("block-123", 123)

    def test_add_tag_validates_known_tag(self):
        """Test add_tag accepts known tags."""
        store, mock_colls = create_mock_doc_store()
        mock_colls.blocks.find_one_and_update.return_value = {
            "id": "block-123",
            "tags": ["testuser__sample_tag"],
        }

        # Known tag should work
        store.add_tag("block-123", "testuser__sample_tag")

    def test_add_tag_validates_prefix_for_unknown_tag(self):
        """Test add_tag validates prefix for unknown tags."""
        store, _ = create_mock_doc_store()

        # Unknown tag without valid prefix
        with pytest.raises(ValueError, match="start with"):
            store.add_tag("block-123", "unknown_tag")

    def test_add_tag_rejects_disabled_tag(self):
        """Test add_tag rejects disabled tags."""
        store, _ = create_mock_doc_store()

        with pytest.raises(ValueError, match="disabled"):
            store.add_tag("block-123", "disabled_tag")

    def test_del_tag_success(self):
        """Test del_tag removes tag from element."""
        store, mock_colls = create_mock_doc_store()
        mock_colls.blocks.find_one_and_update.return_value = {
            "id": "block-123",
            "tags": [],
        }

        store.del_tag("block-123", "testuser__sample_tag")

        mock_colls.blocks.find_one_and_update.assert_called_once()

    def test_batch_add_tag_success(self):
        """Test batch_add_tag adds tag to multiple elements."""
        store, mock_colls = create_mock_doc_store()
        mock_colls.blocks.find_one_and_update.return_value = {
            "id": "block-123",
            "tags": ["testuser__sample_tag"],
        }

        elem_ids = ["block-1", "block-2", "block-3"]
        store.batch_add_tag("block", "testuser__sample_tag", elem_ids)

        assert mock_colls.blocks.find_one_and_update.call_count == 3

    def test_batch_del_tag_success(self):
        """Test batch_del_tag removes tag from multiple elements."""
        store, mock_colls = create_mock_doc_store()
        mock_colls.blocks.find_one_and_update.return_value = {
            "id": "block-123",
            "tags": [],
        }

        elem_ids = ["block-1", "block-2"]
        store.batch_del_tag("block", "testuser__sample_tag", elem_ids)

        assert mock_colls.blocks.find_one_and_update.call_count == 2


class TestAttrOperations:
    """Tests for attribute operations."""

    def test_add_attr_string_success(self):
        """Test add_attr adds string attribute."""
        from doc_store.interface import AttrInput

        store, mock_colls = create_mock_doc_store()

        store.add_attr("block-123", "sample_attr", AttrInput(value="opt1"))

        mock_colls.blocks.update_one.assert_called_once()

    def test_add_attr_validates_known_attr(self):
        """Test add_attr validates attribute is known."""
        from doc_store.interface import AttrInput

        store, _ = create_mock_doc_store()

        with pytest.raises(ValueError, match="Unknown attr"):
            store.add_attr("block-123", "unknown_attr", AttrInput(value="test"))

    def test_add_attr_validates_string_value(self):
        """Test add_attr validates string value against options."""
        from doc_store.interface import AttrInput

        store, _ = create_mock_doc_store()

        # Unknown option for string attr
        with pytest.raises(ValueError, match="no option"):
            store.add_attr("block-123", "sample_attr", AttrInput(value="unknown_option"))

    def test_add_attr_validates_int_value(self):
        """Test add_attr validates int value."""
        from doc_store.interface import AttrInput

        store, mock_colls = create_mock_doc_store()

        # Valid int value
        store.add_attr("block-123", "int_attr", AttrInput(value=50))
        mock_colls.blocks.update_one.assert_called()

    def test_add_attr_validates_int_range(self):
        """Test add_attr validates int value range."""
        from doc_store.interface import AttrInput

        store, _ = create_mock_doc_store()

        # Out of range value
        with pytest.raises(ValueError, match="out of range"):
            store.add_attr("block-123", "int_attr", AttrInput(value=150))

    def test_add_attr_validates_int_type(self):
        """Test add_attr validates int value type."""
        from doc_store.interface import AttrInput

        store, _ = create_mock_doc_store()

        # Wrong type
        with pytest.raises(ValueError, match="requires int"):
            store.add_attr("block-123", "int_attr", AttrInput(value="not_an_int"))

    def test_add_attr_validates_bool_value(self):
        """Test add_attr validates bool value."""
        from doc_store.interface import AttrInput

        store, mock_colls = create_mock_doc_store()

        # Valid bool value
        store.add_attr("block-123", "bool_attr", AttrInput(value=True))
        mock_colls.blocks.update_one.assert_called()

    def test_add_attr_validates_bool_type(self):
        """Test add_attr validates bool value type."""
        from doc_store.interface import AttrInput

        store, _ = create_mock_doc_store()

        # Wrong type
        with pytest.raises(ValueError, match="requires bool"):
            store.add_attr("block-123", "bool_attr", AttrInput(value="not_a_bool"))

    def test_add_attr_validates_list_str_value(self):
        """Test add_attr validates list_str value."""
        from doc_store.interface import AttrInput

        store, mock_colls = create_mock_doc_store()

        # Valid list value
        store.add_attr("block-123", "list_attr", AttrInput(value=["opt1", "opt2"]))
        mock_colls.blocks.update_one.assert_called()

    def test_add_attr_validates_list_str_type(self):
        """Test add_attr validates list_str value type."""
        from doc_store.interface import AttrInput

        store, _ = create_mock_doc_store()

        # Wrong type
        with pytest.raises(ValueError, match="list of str"):
            store.add_attr("block-123", "list_attr", AttrInput(value="not_a_list"))

    def test_add_attr_validates_list_str_options(self):
        """Test add_attr validates list_str values against options."""
        from doc_store.interface import AttrInput

        store, _ = create_mock_doc_store()

        # Unknown option in list
        with pytest.raises(ValueError, match="no options"):
            store.add_attr("block-123", "list_attr", AttrInput(value=["opt1", "unknown"]))

    def test_add_attrs_multiple(self):
        """Test add_attrs adds multiple attributes."""
        store, mock_colls = create_mock_doc_store()

        attrs = {
            "int_attr": 50,
            "bool_attr": True,
        }
        store.add_attrs("block-123", attrs)

        mock_colls.blocks.update_one.assert_called_once()

    def test_del_attr_success(self):
        """Test del_attr removes attribute from element."""
        store, mock_colls = create_mock_doc_store()

        store.del_attr("block-123", "sample_attr")

        mock_colls.blocks.update_one.assert_called_once()

    def test_del_attr_validates_known_attr(self):
        """Test del_attr validates attribute is known."""
        store, _ = create_mock_doc_store()

        with pytest.raises(ValueError, match="Unknown attr"):
            store.del_attr("block-123", "unknown_attr")


class TestMetricOperations:
    """Tests for metric operations."""

    def test_add_metric_float_success(self):
        """Test add_metric adds float metric."""
        from doc_store.interface import MetricInput

        store, mock_colls = create_mock_doc_store()

        store.add_metric("block-123", "sample_metric", MetricInput(value=75.5))

        mock_colls.blocks.update_one.assert_called_once()

    def test_add_metric_int_success(self):
        """Test add_metric adds int metric."""
        from doc_store.interface import MetricInput

        store, mock_colls = create_mock_doc_store()

        store.add_metric("block-123", "int_metric", MetricInput(value=500))

        mock_colls.blocks.update_one.assert_called_once()

    def test_add_metric_validates_known_metric(self):
        """Test add_metric validates metric is known."""
        from doc_store.interface import MetricInput

        store, _ = create_mock_doc_store()

        with pytest.raises(ValueError, match="Unknown metric"):
            store.add_metric("block-123", "unknown_metric", MetricInput(value=50.0))

    def test_add_metric_validates_range(self):
        """Test add_metric validates value range."""
        from doc_store.interface import MetricInput

        store, _ = create_mock_doc_store()

        # Out of range
        with pytest.raises(ValueError, match="out of range"):
            store.add_metric("block-123", "sample_metric", MetricInput(value=150.0))

    def test_add_metric_validates_int_type(self):
        """Test add_metric validates int metric type."""
        from doc_store.interface import MetricInput

        store, _ = create_mock_doc_store()

        # Wrong type for int metric
        with pytest.raises(ValueError, match="requires int"):
            store.add_metric("block-123", "int_metric", MetricInput(value=50.5))

    def test_del_metric_success(self):
        """Test del_metric removes metric from element."""
        store, mock_colls = create_mock_doc_store()

        store.del_metric("block-123", "sample_metric")

        mock_colls.blocks.update_one.assert_called_once()

    def test_del_metric_validates_known_metric(self):
        """Test del_metric validates metric is known."""
        store, _ = create_mock_doc_store()

        with pytest.raises(ValueError, match="Unknown metric"):
            store.del_metric("block-123", "unknown_metric")


class TestTaggingOperation:
    """Tests for combined tagging operation."""

    def test_tagging_adds_tags(self):
        """Test tagging adds multiple tags."""
        from doc_store.interface import TaggingInput

        store, mock_colls = create_mock_doc_store()
        mock_colls.blocks.find_one_and_update.return_value = {
            "id": "block-123",
            "tags": ["testuser__sample_tag"],
        }

        tagging_input = TaggingInput(tags=["testuser__sample_tag"])
        store.tagging("block-123", tagging_input)

        assert mock_colls.blocks.find_one_and_update.called

    def test_tagging_adds_attrs_and_metrics(self):
        """Test tagging adds attributes and metrics."""
        from doc_store.interface import TaggingInput

        store, mock_colls = create_mock_doc_store()

        tagging_input = TaggingInput(
            attrs={"int_attr": 50},
            metrics={"sample_metric": 75.0},
        )
        store.tagging("block-123", tagging_input)

        mock_colls.blocks.update_one.assert_called()

    def test_tagging_deletes_tags(self):
        """Test tagging deletes tags."""
        from doc_store.interface import TaggingInput

        store, mock_colls = create_mock_doc_store()
        mock_colls.blocks.find_one_and_update.return_value = {
            "id": "block-123",
            "tags": [],
        }

        tagging_input = TaggingInput(del_tags=["testuser__sample_tag"])
        store.tagging("block-123", tagging_input)

        assert mock_colls.blocks.find_one_and_update.called

    def test_tagging_deletes_attrs_and_metrics(self):
        """Test tagging deletes attributes and metrics."""
        from doc_store.interface import TaggingInput

        store, mock_colls = create_mock_doc_store()

        tagging_input = TaggingInput(
            del_attrs=["sample_attr"],
            del_metrics=["sample_metric"],
        )
        store.tagging("block-123", tagging_input)

        mock_colls.blocks.update_one.assert_called()

    def test_tagging_combined_operations(self):
        """Test tagging handles combined add and delete operations."""
        from doc_store.interface import TaggingInput

        store, mock_colls = create_mock_doc_store()
        mock_colls.blocks.find_one_and_update.return_value = {
            "id": "block-123",
            "tags": ["testuser__sample_tag"],
        }

        tagging_input = TaggingInput(
            tags=["testuser__sample_tag"],
            attrs={"int_attr": 50},
            metrics={"sample_metric": 75.0},
            del_attrs=["bool_attr"],
        )
        store.tagging("block-123", tagging_input)

        # Should have called find_one_and_update for tags
        assert mock_colls.blocks.find_one_and_update.called

    def test_tagging_empty_input_does_nothing(self):
        """Test tagging with empty input does nothing."""
        from doc_store.interface import TaggingInput

        store, mock_colls = create_mock_doc_store()

        tagging_input = TaggingInput()
        store.tagging("block-123", tagging_input)

        # Should not call any update methods
        mock_colls.blocks.update_one.assert_not_called()
        mock_colls.blocks.find_one_and_update.assert_not_called()

    def test_tagging_validates_tags(self):
        """Test tagging validates tag names."""
        from doc_store.interface import TaggingInput

        store, _ = create_mock_doc_store()

        # Unknown tag with wrong prefix
        tagging_input = TaggingInput(tags=["unknown_prefix__tag"])

        with pytest.raises(ValueError):
            store.tagging("block-123", tagging_input)

    def test_tagging_validates_attrs(self):
        """Test tagging validates attribute names and values."""
        from doc_store.interface import TaggingInput

        store, _ = create_mock_doc_store()

        # Unknown attribute
        tagging_input = TaggingInput(attrs={"unknown_attr": "value"})

        with pytest.raises(ValueError, match="Unknown attr"):
            store.tagging("block-123", tagging_input)

    def test_tagging_validates_metrics(self):
        """Test tagging validates metric names and values."""
        from doc_store.interface import TaggingInput

        store, _ = create_mock_doc_store()

        # Unknown metric
        tagging_input = TaggingInput(metrics={"unknown_metric": 50.0})

        with pytest.raises(ValueError, match="Unknown metric"):
            store.tagging("block-123", tagging_input)

    def test_tagging_validates_del_attrs(self):
        """Test tagging validates del_attrs names."""
        from doc_store.interface import TaggingInput

        store, _ = create_mock_doc_store()

        # Unknown attribute to delete
        tagging_input = TaggingInput(del_attrs=["unknown_attr"])

        with pytest.raises(ValueError, match="Unknown attr"):
            store.tagging("block-123", tagging_input)

    def test_tagging_validates_del_metrics(self):
        """Test tagging validates del_metrics names."""
        from doc_store.interface import TaggingInput

        store, _ = create_mock_doc_store()

        # Unknown metric to delete
        tagging_input = TaggingInput(del_metrics=["unknown_metric"])

        with pytest.raises(ValueError, match="Unknown metric"):
            store.tagging("block-123", tagging_input)


class TestElementTypeDetection:
    """Tests for element type detection from ID."""

    def test_tag_operation_detects_page_type(self):
        """Test tag operations detect page element type."""
        store, mock_colls = create_mock_doc_store()
        mock_colls.pages.find_one_and_update.return_value = {
            "id": "page-123",
            "tags": ["testuser__sample_tag"],
        }

        store.add_tag("page-123", "testuser__sample_tag")

        mock_colls.pages.find_one_and_update.assert_called_once()

    def test_tag_operation_detects_doc_type(self):
        """Test tag operations detect doc element type."""
        store, mock_colls = create_mock_doc_store()
        mock_colls.docs.find_one_and_update.return_value = {
            "id": "doc-123",
            "tags": ["testuser__sample_tag"],
        }

        store.add_tag("doc-123", "testuser__sample_tag")

        mock_colls.docs.find_one_and_update.assert_called_once()

    def test_tag_operation_detects_layout_type(self):
        """Test tag operations detect layout element type."""
        store, mock_colls = create_mock_doc_store()
        mock_colls.layouts.find_one_and_update.return_value = {
            "id": "layout-123",
            "tags": ["testuser__sample_tag"],
        }

        store.add_tag("layout-123", "testuser__sample_tag")

        mock_colls.layouts.find_one_and_update.assert_called_once()

    def test_tag_operation_detects_content_type(self):
        """Test tag operations detect content element type."""
        store, mock_colls = create_mock_doc_store()
        mock_colls.contents.find_one_and_update.return_value = {
            "id": "content-123",
            "tags": ["testuser__sample_tag"],
        }

        store.add_tag("content-123", "testuser__sample_tag")

        mock_colls.contents.find_one_and_update.assert_called_once()

    def test_tag_operation_detects_block_in_layout_type(self):
        """Test tag operations detect block inside layout."""
        store, mock_colls = create_mock_doc_store()
        mock_colls.blocks.find_one_and_update.return_value = {
            "id": "layout-123.block-456",
            "tags": ["testuser__sample_tag"],
        }

        store.add_tag("layout-123.block-456", "testuser__sample_tag")

        mock_colls.blocks.find_one_and_update.assert_called_once()

    def test_tag_operation_detects_content_in_layout_type(self):
        """Test tag operations detect content inside layout."""
        store, mock_colls = create_mock_doc_store()
        mock_colls.contents.find_one_and_update.return_value = {
            "id": "layout-123.content-456",
            "tags": ["testuser__sample_tag"],
        }

        store.add_tag("layout-123.content-456", "testuser__sample_tag")

        mock_colls.contents.find_one_and_update.assert_called_once()

