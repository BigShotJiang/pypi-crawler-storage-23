"""Tests for management operations: users and known names."""

from unittest.mock import MagicMock, patch

import pytest


class MockDocStore:
    """Helper to create a mocked DocStore instance for testing."""

    @staticmethod
    def create(
        username="testuser",
        is_admin=False,
        known_names=None,
        users=None,
    ):
        """Create a mock DocStore with specified configuration."""
        from doc_store.doc_store import DocStore

        mock_mongo = MagicMock()
        mock_db = MagicMock()
        mock_mongo.get_database.return_value = mock_db

        # Create mock collections
        mock_colls = MagicMock()
        for coll_name in [
            "docs", "pages", "layouts", "blocks", "contents",
            "values", "tasks", "known_users", "known_names",
            "embedding_models", "locks", "counters", "triggers",
            "eval_layouts", "eval_contents"
        ]:
            coll = MagicMock()
            coll.create_index = MagicMock()
            setattr(mock_colls, coll_name, coll)

        # Set up users
        default_users = users or [
            {"name": username, "aliases": [], "restricted": False, "is_admin": is_admin}
        ]

        # Set up known names
        default_known_names = known_names or []

        mock_colls.known_users.find.return_value = default_users
        mock_colls.known_names.find.return_value = default_known_names

        with patch("doc_store.doc_store.get_mongo_client", return_value=mock_mongo), \
             patch("doc_store.doc_store.get_es_client") as mock_es, \
             patch("doc_store.doc_store.RedisStream") as mock_redis, \
             patch("doc_store.doc_store.KafkaWriter") as mock_kafka, \
             patch("doc_store.doc_store.get_username", return_value=username), \
             patch("doc_store.doc_store.DbCollections", return_value=mock_colls):

            store = DocStore(disable_events=True)
            store.coll = mock_colls

            # Set up user info cache
            store._all_users = None
            store._all_known_names = None

            return store, mock_colls


class TestUserManagement:
    """Tests for user management operations."""

    def test_list_users_returns_empty_list(self):
        """Test list_users returns empty list when no users exist."""
        store, mock_colls = MockDocStore.create()
        mock_colls.known_users.find.return_value = []

        result = store.list_users()
        assert result == []

    def test_list_users_returns_users(self):
        """Test list_users returns list of users."""
        user_data = [
            {"name": "user1", "aliases": [], "restricted": False, "is_admin": False},
            {"name": "user2", "aliases": ["alias"], "restricted": True, "is_admin": False},
        ]
        store, mock_colls = MockDocStore.create()
        mock_colls.known_users.find.return_value = user_data

        result = store.list_users()
        assert len(result) == 2
        assert result[0].name == "user1"
        assert result[1].name == "user2"

    def test_get_user_returns_user(self):
        """Test get_user returns user by name."""
        from doc_store.interface import User

        store, mock_colls = MockDocStore.create()
        mock_colls.known_users.find_one.return_value = {
            "name": "testuser",
            "aliases": [],
            "restricted": False,
            "is_admin": False,
        }

        result = store.get_user("testuser")
        assert isinstance(result, User)
        assert result.name == "testuser"

    def test_get_user_raises_not_found(self):
        """Test get_user raises NotFoundError when user doesn't exist."""
        from doc_store.interface import NotFoundError

        store, mock_colls = MockDocStore.create()
        mock_colls.known_users.find_one.return_value = None

        with pytest.raises(NotFoundError):
            store.get_user("nonexistent")

    def test_get_user_validates_name(self):
        """Test get_user validates name parameter."""
        store, mock_colls = MockDocStore.create()

        with pytest.raises(ValueError):
            store.get_user("")

        with pytest.raises(ValueError):
            store.get_user(None)

    def test_insert_user_success(self):
        """Test insert_user creates a new user."""
        from doc_store.interface import User, UserInput

        store, mock_colls = MockDocStore.create(is_admin=True)
        mock_colls.known_users.find_one.return_value = None

        user_input = UserInput(name="newuser", aliases=["alias1"])
        result = store.insert_user(user_input)

        assert isinstance(result, User)
        assert result.name == "newuser"
        mock_colls.known_users.insert_one.assert_called_once()

    def test_insert_user_requires_admin(self):
        """Test insert_user requires admin privileges."""
        from doc_store.interface import UserInput

        store, mock_colls = MockDocStore.create(is_admin=False)

        user_input = UserInput(name="newuser")

        with pytest.raises(PermissionError):
            store.insert_user(user_input)

    def test_insert_user_raises_on_duplicate(self):
        """Test insert_user raises AlreadyExistsError on duplicate."""
        from doc_store.interface import AlreadyExistsError, UserInput

        store, mock_colls = MockDocStore.create(is_admin=True)
        mock_colls.known_users.find_one.return_value = {"name": "existinguser"}

        user_input = UserInput(name="existinguser")

        with pytest.raises(AlreadyExistsError):
            store.insert_user(user_input)

    def test_insert_user_validates_empty_name(self):
        """Test insert_user validates empty name."""
        from doc_store.interface import UserInput

        store, mock_colls = MockDocStore.create(is_admin=True)

        user_input = UserInput(name="")

        with pytest.raises(ValueError):
            store.insert_user(user_input)

    def test_update_user_success(self):
        """Test update_user updates an existing user."""
        from doc_store.interface import User, UserUpdate

        store, mock_colls = MockDocStore.create(is_admin=True)
        mock_colls.known_users.find_one_and_update.return_value = {
            "name": "testuser",
            "aliases": ["new_alias"],
            "restricted": False,
            "is_admin": False,
        }

        update = UserUpdate(aliases=["new_alias"])
        result = store.update_user("testuser", update)

        assert isinstance(result, User)
        assert "new_alias" in result.aliases

    def test_update_user_requires_admin(self):
        """Test update_user requires admin privileges."""
        from doc_store.interface import UserUpdate

        store, mock_colls = MockDocStore.create(is_admin=False)

        update = UserUpdate(restricted=True)

        with pytest.raises(PermissionError):
            store.update_user("someuser", update)

    def test_update_user_raises_not_found(self):
        """Test update_user raises NotFoundError when user doesn't exist."""
        from doc_store.interface import NotFoundError, UserUpdate

        store, mock_colls = MockDocStore.create(is_admin=True)
        mock_colls.known_users.find_one_and_update.return_value = None
        mock_colls.known_users.find_one.return_value = None

        update = UserUpdate(restricted=True)

        with pytest.raises(NotFoundError):
            store.update_user("nonexistent", update)


class TestKnownNameManagement:
    """Tests for known name management operations."""

    def test_list_known_names_returns_empty_list(self):
        """Test list_known_names returns empty list when no names exist."""
        store, mock_colls = MockDocStore.create()
        mock_colls.known_names.find.return_value = []

        result = store.list_known_names()
        assert result == []

    def test_list_known_names_returns_names(self):
        """Test list_known_names returns list of known names."""
        name_data = [
            {
                "name": "test__tag1",
                "display_name": "Tag 1",
                "description": "",
                "type": "tag",
                "value_type": "null",
                "min_value": 0,
                "max_value": 0,
                "options": {},
                "disabled": False,
            },
        ]
        store, mock_colls = MockDocStore.create()
        mock_colls.known_names.find.return_value = name_data

        result = store.list_known_names()
        assert len(result) == 1
        assert result[0].name == "test__tag1"

    def test_insert_known_name_tag_success(self):
        """Test insert_known_name creates a new tag name."""
        from doc_store.interface import KnownName, KnownNameInput

        store, mock_colls = MockDocStore.create(is_admin=True)
        mock_colls.known_names.find_one.return_value = None

        name_input = KnownNameInput(
            name="testuser__newtag",
            display_name="New Tag",
            type="tag",
            value_type="null",
        )
        result = store.insert_known_name(name_input)

        assert isinstance(result, KnownName)
        assert result.name == "testuser__newtag"
        mock_colls.known_names.insert_one.assert_called_once()

    def test_insert_known_name_attr_success(self):
        """Test insert_known_name creates a new attribute name."""
        from doc_store.interface import KnownName, KnownNameInput

        store, mock_colls = MockDocStore.create(is_admin=True)
        mock_colls.known_names.find_one.return_value = None

        name_input = KnownNameInput(
            name="test_attr",
            display_name="Test Attr",
            type="attr",
            value_type="str",
        )
        result = store.insert_known_name(name_input)

        assert isinstance(result, KnownName)
        assert result.type == "attr"

    def test_insert_known_name_metric_success(self):
        """Test insert_known_name creates a new metric name."""
        from doc_store.interface import KnownName, KnownNameInput

        store, mock_colls = MockDocStore.create(is_admin=True)
        mock_colls.known_names.find_one.return_value = None

        name_input = KnownNameInput(
            name="test_metric",
            display_name="Test Metric",
            type="metric",
            value_type="float",
            min_value=0.0,
            max_value=100.0,
        )
        result = store.insert_known_name(name_input)

        assert isinstance(result, KnownName)
        assert result.type == "metric"

    def test_insert_known_name_requires_admin(self):
        """Test insert_known_name requires admin privileges."""
        from doc_store.interface import KnownNameInput

        store, mock_colls = MockDocStore.create(is_admin=False)

        name_input = KnownNameInput(
            name="testuser__newtag",
            type="tag",
            value_type="null",
        )

        with pytest.raises(PermissionError):
            store.insert_known_name(name_input)

    def test_insert_known_name_tag_requires_double_underscore(self):
        """Test insert_known_name tag requires double underscore separator."""
        from doc_store.interface import KnownNameInput

        store, mock_colls = MockDocStore.create(is_admin=True)
        mock_colls.known_names.find_one.return_value = None

        name_input = KnownNameInput(
            name="tagwithoutprefix",
            type="tag",
            value_type="null",
        )

        with pytest.raises(ValueError, match="__"):
            store.insert_known_name(name_input)

    def test_insert_known_name_validates_name_characters(self):
        """Test insert_known_name validates name contains only valid characters."""
        from doc_store.interface import KnownNameInput

        store, mock_colls = MockDocStore.create(is_admin=True)

        name_input = KnownNameInput(
            name="invalid@name",
            type="tag",
            value_type="null",
        )

        with pytest.raises(ValueError):
            store.insert_known_name(name_input)

    def test_insert_known_name_tag_requires_null_value_type(self):
        """Test insert_known_name tag requires null value_type."""
        from doc_store.interface import KnownNameInput

        store, mock_colls = MockDocStore.create(is_admin=True)

        name_input = KnownNameInput(
            name="test__tag",
            type="tag",
            value_type="str",  # Should be null for tags
        )

        with pytest.raises(ValueError):
            store.insert_known_name(name_input)

    def test_insert_known_name_attr_requires_valid_value_type(self):
        """Test insert_known_name attr requires valid value_type."""
        from doc_store.interface import KnownNameInput

        store, mock_colls = MockDocStore.create(is_admin=True)

        name_input = KnownNameInput(
            name="test_attr",
            type="attr",
            value_type="null",  # Should be str, list_str, int, or bool
        )

        with pytest.raises(ValueError):
            store.insert_known_name(name_input)

    def test_insert_known_name_metric_requires_numeric_value_type(self):
        """Test insert_known_name metric requires int or float value_type."""
        from doc_store.interface import KnownNameInput

        store, mock_colls = MockDocStore.create(is_admin=True)

        name_input = KnownNameInput(
            name="test_metric",
            type="metric",
            value_type="str",  # Should be int or float
        )

        with pytest.raises(ValueError):
            store.insert_known_name(name_input)

    def test_insert_known_name_raises_on_duplicate(self):
        """Test insert_known_name raises AlreadyExistsError on duplicate."""
        from doc_store.interface import AlreadyExistsError, KnownNameInput

        store, mock_colls = MockDocStore.create(is_admin=True)
        mock_colls.known_names.find_one.return_value = {"name": "test__existing"}

        name_input = KnownNameInput(
            name="test__existing",
            type="tag",
            value_type="null",
        )

        with pytest.raises(AlreadyExistsError):
            store.insert_known_name(name_input)

    def test_update_known_name_success(self):
        """Test update_known_name updates an existing name."""
        from doc_store.interface import KnownName, KnownNameUpdate

        store, mock_colls = MockDocStore.create(is_admin=True)
        mock_colls.known_names.find_one_and_update.return_value = {
            "name": "test__tag",
            "display_name": "Updated Tag",
            "description": "Updated description",
            "type": "tag",
            "value_type": "null",
            "min_value": 0,
            "max_value": 0,
            "options": {},
            "disabled": False,
        }

        update = KnownNameUpdate(display_name="Updated Tag")
        result = store.update_known_name("test__tag", update)

        assert isinstance(result, KnownName)
        assert result.display_name == "Updated Tag"

    def test_update_known_name_raises_not_found(self):
        """Test update_known_name raises NotFoundError when name doesn't exist."""
        from doc_store.interface import KnownNameUpdate, NotFoundError

        store, mock_colls = MockDocStore.create(is_admin=True)
        mock_colls.known_names.find_one_and_update.return_value = None
        mock_colls.known_names.find_one.return_value = None

        update = KnownNameUpdate(display_name="New Name")

        with pytest.raises(NotFoundError):
            store.update_known_name("nonexistent", update)

    def test_add_known_option_success(self):
        """Test add_known_option adds option to an attribute."""
        from doc_store.interface import KnownOptionInput

        store, mock_colls = MockDocStore.create(is_admin=True)
        mock_colls.known_names.find_one.return_value = {
            "name": "test_attr",
            "type": "attr",
            "value_type": "str",
            "options": {},
        }
        mock_colls.known_names.update_one.return_value.modified_count = 0

        option_input = KnownOptionInput(
            display_name="Option 1",
            description="First option",
        )
        store.add_known_option("test_attr", "opt1", option_input)

        assert mock_colls.known_names.update_one.called

    def test_add_known_option_raises_not_found(self):
        """Test add_known_option raises NotFoundError when attr doesn't exist."""
        from doc_store.interface import KnownOptionInput, NotFoundError

        store, mock_colls = MockDocStore.create(is_admin=True)
        mock_colls.known_names.find_one.return_value = None

        option_input = KnownOptionInput(display_name="Option 1")

        with pytest.raises(NotFoundError):
            store.add_known_option("nonexistent", "opt1", option_input)

    def test_add_known_option_validates_option_name(self):
        """Test add_known_option validates option name."""
        from doc_store.interface import KnownOptionInput

        store, mock_colls = MockDocStore.create(is_admin=True)

        option_input = KnownOptionInput(display_name="Option 1")

        with pytest.raises(ValueError):
            store.add_known_option("test_attr", "invalid@option", option_input)

    def test_del_known_option_success(self):
        """Test del_known_option removes option from an attribute."""
        store, mock_colls = MockDocStore.create(is_admin=True)

        store.del_known_option("test_attr", "opt1")

        mock_colls.known_names.update_one.assert_called_once()

