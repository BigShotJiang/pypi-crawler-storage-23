"""Tests for embedding operations."""

from unittest.mock import MagicMock, patch

import pytest


def create_mock_doc_store(username="testuser", is_admin=False):
    """Create a mock DocStore with specified configuration."""
    from doc_store.doc_store import DocStore

    mock_mongo = MagicMock()
    mock_db = MagicMock()
    mock_mongo.get_database.return_value = mock_db

    # Create mock collections
    mock_colls = MagicMock()
    for coll_name in [
        "docs", "pages", "layouts", "blocks", "contents",
        "values", "tasks", "known_users", "known_names",
        "embedding_models", "locks", "counters", "triggers",
        "eval_layouts", "eval_contents"
    ]:
        coll = MagicMock()
        coll.create_index = MagicMock()
        setattr(mock_colls, coll_name, coll)

    # Set up users
    default_users = [
        {"name": username, "aliases": [], "restricted": False, "is_admin": is_admin}
    ]

    mock_colls.known_users.find.return_value = default_users
    mock_colls.known_names.find.return_value = []

    mock_es = MagicMock()

    with patch("doc_store.doc_store.get_mongo_client", return_value=mock_mongo), \
         patch("doc_store.doc_store.get_es_client", return_value=mock_es), \
         patch("doc_store.doc_store.RedisStream") as mock_redis, \
         patch("doc_store.doc_store.KafkaWriter") as mock_kafka, \
         patch("doc_store.doc_store.get_username", return_value=username), \
         patch("doc_store.doc_store.DbCollections", return_value=mock_colls):

        store = DocStore(disable_events=True)
        store.coll = mock_colls
        store.es_client = mock_es
        store._all_users = None
        store._all_known_names = None
        store._embedding_models = None

        return store, mock_colls, mock_es


class TestEmbeddingModelOperations:
    """Tests for embedding model operations."""

    def test_list_embedding_models_returns_empty(self):
        """Test list_embedding_models returns empty list when no models."""
        store, mock_colls, _ = create_mock_doc_store()
        mock_colls.embedding_models.find.return_value = []

        result = store.list_embedding_models()

        assert result == []

    def test_list_embedding_models_returns_models(self):
        """Test list_embedding_models returns list of models."""
        from doc_store.interface import EmbeddingModel

        store, mock_colls, _ = create_mock_doc_store()
        mock_colls.embedding_models.find.return_value = [
            {
                "name": "model1",
                "dimension": 512,
                "normalized": True,
                "description": "Test model 1",
            },
            {
                "name": "model2",
                "dimension": 768,
                "normalized": False,
                "description": "Test model 2",
            },
        ]

        result = store.list_embedding_models()

        assert len(result) == 2
        assert all(isinstance(m, EmbeddingModel) for m in result)

    def test_get_embedding_model_returns_model(self):
        """Test get_embedding_model returns model by name."""
        from doc_store.interface import EmbeddingModel

        store, mock_colls, _ = create_mock_doc_store()
        mock_colls.embedding_models.find_one.return_value = {
            "name": "test_model",
            "dimension": 512,
            "normalized": True,
            "description": "Test model",
        }

        result = store.get_embedding_model("test_model")

        assert isinstance(result, EmbeddingModel)
        assert result.name == "test_model"
        assert result.dimension == 512

    def test_get_embedding_model_raises_not_found(self):
        """Test get_embedding_model raises error when not found."""
        from doc_store.interface import NotFoundError

        store, mock_colls, _ = create_mock_doc_store()
        mock_colls.embedding_models.find_one.return_value = None

        with pytest.raises(NotFoundError):
            store.get_embedding_model("nonexistent")

    def test_get_embedding_model_validates_name(self):
        """Test get_embedding_model validates name parameter."""
        store, _, _ = create_mock_doc_store()

        with pytest.raises(ValueError, match="non-empty"):
            store.get_embedding_model("")

    def test_insert_embedding_model_success(self):
        """Test insert_embedding_model creates a new model."""
        from doc_store.interface import EmbeddingModel

        store, mock_colls, mock_es = create_mock_doc_store(is_admin=True)

        model = EmbeddingModel(
            name="new_model",
            dimension=512,
            normalized=True,
            description="New model",
        )

        result = store.insert_embedding_model(model)

        assert result.name == "new_model"
        mock_colls.embedding_models.insert_one.assert_called_once()
        # Should create ES indices
        assert mock_es.indices.create.call_count == 2

    def test_insert_embedding_model_requires_admin(self):
        """Test insert_embedding_model requires admin privileges."""
        from doc_store.interface import EmbeddingModel

        store, _, _ = create_mock_doc_store(is_admin=False)

        model = EmbeddingModel(
            name="new_model",
            dimension=512,
            normalized=True,
        )

        with pytest.raises(PermissionError):
            store.insert_embedding_model(model)

    def test_insert_embedding_model_validates_name(self):
        """Test insert_embedding_model validates model name."""
        from doc_store.interface import EmbeddingModel

        store, _, _ = create_mock_doc_store(is_admin=True)

        model = EmbeddingModel(
            name="invalid@name",
            dimension=512,
            normalized=True,
        )

        with pytest.raises(ValueError, match="alphanumeric"):
            store.insert_embedding_model(model)

    def test_insert_embedding_model_validates_dimension(self):
        """Test insert_embedding_model validates dimension range."""
        from doc_store.interface import EmbeddingModel

        store, _, _ = create_mock_doc_store(is_admin=True)

        # Too small
        model = EmbeddingModel(
            name="model",
            dimension=0,
            normalized=True,
        )
        with pytest.raises(ValueError, match="dimension"):
            store.insert_embedding_model(model)

        # Too large
        model = EmbeddingModel(
            name="model",
            dimension=50000,
            normalized=True,
        )
        with pytest.raises(ValueError, match="dimension"):
            store.insert_embedding_model(model)

    def test_insert_embedding_model_raises_duplicate(self):
        """Test insert_embedding_model raises on duplicate."""
        import pymongo.errors

        from doc_store.interface import AlreadyExistsError, EmbeddingModel

        store, mock_colls, mock_es = create_mock_doc_store(is_admin=True)
        mock_colls.embedding_models.insert_one.side_effect = pymongo.errors.DuplicateKeyError("")

        model = EmbeddingModel(
            name="existing_model",
            dimension=512,
            normalized=True,
        )

        with pytest.raises(AlreadyExistsError):
            store.insert_embedding_model(model)

    def test_update_embedding_model_success(self):
        """Test update_embedding_model updates model."""
        from doc_store.interface import EmbeddingModel, EmbeddingModelUpdate

        store, mock_colls, _ = create_mock_doc_store(is_admin=True)
        mock_colls.embedding_models.find_one_and_update.return_value = {
            "name": "model",
            "dimension": 512,
            "normalized": True,
            "description": "Updated description",
        }

        update = EmbeddingModelUpdate(description="Updated description")
        result = store.update_embedding_model("model", update)

        assert isinstance(result, EmbeddingModel)
        assert result.description == "Updated description"

    def test_update_embedding_model_raises_not_found(self):
        """Test update_embedding_model raises when not found."""
        from doc_store.interface import EmbeddingModelUpdate, NotFoundError

        store, mock_colls, _ = create_mock_doc_store(is_admin=True)
        mock_colls.embedding_models.find_one_and_update.return_value = None

        update = EmbeddingModelUpdate(description="New desc")

        with pytest.raises(NotFoundError):
            store.update_embedding_model("nonexistent", update)


class TestEmbeddingOperations:
    """Tests for embedding operations."""

    def test_add_embeddings_success(self):
        """Test add_embeddings adds embeddings to elements."""
        from doc_store.interface import EmbeddingInput, EmbeddingModel

        store, mock_colls, mock_es = create_mock_doc_store()

        # Mock embedding model cache
        model = EmbeddingModel(
            name="test_model",
            dimension=3,
            normalized=True,
        )
        store._embedding_models = {"test_model": model}

        embeddings = [
            EmbeddingInput(elem_id="page-1", vector=[1.0, 0.0, 0.0]),
            EmbeddingInput(elem_id="page-2", vector=[0.0, 1.0, 0.0]),
        ]

        with patch("doc_store.doc_store.EsBulkWriter") as mock_writer:
            mock_instance = MagicMock()
            mock_writer.return_value = mock_instance

            store.add_embeddings("page", "test_model", embeddings)

            assert mock_instance.write.call_count == 2
            mock_instance.flush.assert_called_once()

    def test_add_embeddings_validates_elem_type(self):
        """Test add_embeddings validates element type."""
        from doc_store.interface import EmbeddingInput

        store, _, _ = create_mock_doc_store()

        with pytest.raises(ValueError, match="page.*block"):
            store.add_embeddings("content", "model", [])

    def test_add_embeddings_validates_model_exists(self):
        """Test add_embeddings validates model exists."""
        from doc_store.interface import EmbeddingInput, NotFoundError

        store, _, _ = create_mock_doc_store()
        store._embedding_models = {}

        with pytest.raises(NotFoundError):
            store.add_embeddings("page", "nonexistent_model", [])

    def test_add_embeddings_validates_elem_id(self):
        """Test add_embeddings validates elem_id is provided."""
        from doc_store.interface import EmbeddingInput, EmbeddingModel

        store, _, _ = create_mock_doc_store()

        model = EmbeddingModel(name="model", dimension=3, normalized=True)
        store._embedding_models = {"model": model}

        embeddings = [EmbeddingInput(elem_id="", vector=[1.0, 0.0, 0.0])]

        with pytest.raises(ValueError, match="elem_id"):
            store.add_embeddings("page", "model", embeddings)

    def test_add_embeddings_validates_vector_dimension(self):
        """Test add_embeddings validates vector dimension."""
        from doc_store.interface import EmbeddingInput, EmbeddingModel

        store, _, _ = create_mock_doc_store()

        model = EmbeddingModel(name="model", dimension=512, normalized=True)
        store._embedding_models = {"model": model}

        # Wrong dimension
        embeddings = [EmbeddingInput(elem_id="page-1", vector=[1.0, 0.0, 0.0])]

        with pytest.raises(ValueError, match="dim"):
            store.add_embeddings("page", "model", embeddings)

    def test_add_embeddings_normalizes_vectors(self):
        """Test add_embeddings normalizes vectors for normalized models."""
        from doc_store.interface import EmbeddingInput, EmbeddingModel

        store, _, _ = create_mock_doc_store()

        model = EmbeddingModel(name="model", dimension=3, normalized=True)
        store._embedding_models = {"model": model}

        embeddings = [EmbeddingInput(elem_id="page-1", vector=[3.0, 4.0, 0.0])]

        with patch("doc_store.doc_store.EsBulkWriter") as mock_writer:
            mock_instance = MagicMock()
            mock_writer.return_value = mock_instance

            store.add_embeddings("page", "model", embeddings)

            # Verify normalization (3, 4, 0) -> (0.6, 0.8, 0.0)
            call_args = mock_instance.write.call_args_list[0]
            written_vector = call_args[0][1]["vector"]
            assert abs(written_vector[0] - 0.6) < 0.001
            assert abs(written_vector[1] - 0.8) < 0.001

    def test_search_embeddings_success(self):
        """Test search_embeddings returns matching embeddings."""
        from doc_store.interface import Embedding, EmbeddingModel, EmbeddingQuery

        store, _, mock_es = create_mock_doc_store()

        model = EmbeddingModel(name="model", dimension=3, normalized=True)
        store._embedding_models = {"model": model}

        mock_es.search.return_value = {
            "hits": {
                "hits": [
                    {"_source": {"id": "page-1"}, "_score": 0.95},
                    {"_source": {"id": "page-2"}, "_score": 0.85},
                ]
            }
        }

        query = EmbeddingQuery(vector=[1.0, 0.0, 0.0], k=10)
        result = store.search_embeddings("page", "model", query)

        assert len(result) == 2
        assert all(isinstance(e, Embedding) for e in result)
        assert result[0].elem_id == "page-1"
        assert result[0].score == 0.95

    def test_search_embeddings_validates_elem_type(self):
        """Test search_embeddings validates element type."""
        from doc_store.interface import EmbeddingQuery

        store, _, _ = create_mock_doc_store()

        with pytest.raises(ValueError, match="page.*block"):
            store.search_embeddings("content", "model", EmbeddingQuery(vector=[], k=10))

    def test_search_embeddings_validates_model_exists(self):
        """Test search_embeddings validates model exists."""
        from doc_store.interface import EmbeddingQuery, NotFoundError

        store, _, _ = create_mock_doc_store()
        store._embedding_models = {}

        with pytest.raises(NotFoundError):
            store.search_embeddings("page", "nonexistent", EmbeddingQuery(vector=[], k=10))

    def test_search_embeddings_validates_vector_dimension(self):
        """Test search_embeddings validates vector dimension."""
        from doc_store.interface import EmbeddingModel, EmbeddingQuery

        store, _, _ = create_mock_doc_store()

        model = EmbeddingModel(name="model", dimension=512, normalized=True)
        store._embedding_models = {"model": model}

        # Wrong dimension
        query = EmbeddingQuery(vector=[1.0, 0.0, 0.0], k=10)

        with pytest.raises(ValueError, match="dim"):
            store.search_embeddings("page", "model", query)

    def test_search_embeddings_validates_k_range(self):
        """Test search_embeddings validates k range."""
        from doc_store.interface import EmbeddingModel, EmbeddingQuery

        store, _, _ = create_mock_doc_store()

        model = EmbeddingModel(name="model", dimension=3, normalized=True)
        store._embedding_models = {"model": model}

        # k too small
        with pytest.raises(ValueError, match="k must be"):
            store.search_embeddings("page", "model", EmbeddingQuery(vector=[1.0, 0.0, 0.0], k=0))

        # k too large
        with pytest.raises(ValueError, match="k must be"):
            store.search_embeddings("page", "model", EmbeddingQuery(vector=[1.0, 0.0, 0.0], k=20000))

    def test_search_embeddings_with_show_vector(self):
        """Test search_embeddings returns vectors when requested."""
        from doc_store.interface import EmbeddingModel, EmbeddingQuery

        store, _, mock_es = create_mock_doc_store()

        model = EmbeddingModel(name="model", dimension=3, normalized=True)
        store._embedding_models = {"model": model}

        mock_es.search.return_value = {
            "hits": {
                "hits": [
                    {"_source": {"id": "page-1", "vector": [1.0, 0.0, 0.0]}, "_score": 0.95},
                ]
            }
        }

        query = EmbeddingQuery(vector=[1.0, 0.0, 0.0], k=10, show_vector=True)
        result = store.search_embeddings("page", "model", query)

        assert result[0].vector == [1.0, 0.0, 0.0]

    def test_search_embeddings_normalizes_query(self):
        """Test search_embeddings normalizes query vector for normalized models."""
        from doc_store.interface import EmbeddingModel, EmbeddingQuery

        store, _, mock_es = create_mock_doc_store()

        model = EmbeddingModel(name="model", dimension=3, normalized=True)
        store._embedding_models = {"model": model}

        mock_es.search.return_value = {"hits": {"hits": []}}

        query = EmbeddingQuery(vector=[3.0, 4.0, 0.0], k=10)
        store.search_embeddings("page", "model", query)

        # Verify the query was normalized
        call_args = mock_es.search.call_args
        es_query = call_args[1]["body"]
        query_vector = es_query["knn"]["query_vector"]
        assert abs(query_vector[0] - 0.6) < 0.001
        assert abs(query_vector[1] - 0.8) < 0.001

