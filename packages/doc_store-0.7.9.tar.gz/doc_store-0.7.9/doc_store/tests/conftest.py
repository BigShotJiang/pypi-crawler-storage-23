"""Pytest configuration and shared fixtures for doc_store tests."""

import hashlib
import io
from unittest.mock import MagicMock, patch

import numpy as np
import pytest
from PIL import Image


@pytest.fixture
def mock_mongo_client():
    """Mock MongoDB client and database."""
    mock_client = MagicMock()
    mock_db = MagicMock()
    mock_client.get_database.return_value = mock_db
    return mock_client, mock_db


@pytest.fixture
def mock_es_client():
    """Mock Elasticsearch client."""
    mock_es = MagicMock()
    mock_es.indices = MagicMock()
    mock_es.search.return_value = {"hits": {"hits": []}}
    return mock_es


@pytest.fixture
def mock_redis_stream():
    """Mock Redis stream."""
    mock_stream = MagicMock()
    mock_stream.producer = MagicMock()
    mock_stream.manager = MagicMock()
    mock_stream.client = MagicMock()
    mock_stream.consumer_group = "test-group"
    return mock_stream


@pytest.fixture
def mock_kafka_writer():
    """Mock Kafka writer."""
    mock_kafka = MagicMock()
    return mock_kafka


@pytest.fixture
def sample_pdf_bytes():
    """Generate minimal valid PDF bytes for testing."""
    # Minimal valid PDF structure
    pdf_content = b"""%PDF-1.4
1 0 obj
<< /Type /Catalog /Pages 2 0 R >>
endobj
2 0 obj
<< /Type /Pages /Kids [3 0 R] /Count 1 >>
endobj
3 0 obj
<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Resources << >> >>
endobj
xref
0 4
0000000000 65535 f 
0000000009 00000 n 
0000000058 00000 n 
0000000115 00000 n 
trailer
<< /Size 4 /Root 1 0 R >>
startxref
206
%%EOF"""
    return pdf_content


@pytest.fixture
def sample_image_bytes():
    """Generate minimal valid image bytes for testing."""
    img = Image.new("RGB", (100, 100), color="white")
    buffer = io.BytesIO()
    img.save(buffer, format="PNG")
    return buffer.getvalue()


@pytest.fixture
def sample_jpg_bytes():
    """Generate minimal valid JPEG bytes for testing."""
    img = Image.new("RGB", (100, 100), color="white")
    buffer = io.BytesIO()
    img.save(buffer, format="JPEG")
    return buffer.getvalue()


@pytest.fixture
def mock_user_data():
    """Sample user data."""
    return {
        "name": "testuser",
        "aliases": ["alias1"],
        "restricted": False,
        "is_admin": False,
    }


@pytest.fixture
def mock_admin_user_data():
    """Sample admin user data."""
    return {
        "name": "adminuser",
        "aliases": [],
        "restricted": False,
        "is_admin": True,
    }


@pytest.fixture
def mock_known_name_tag():
    """Sample known tag name."""
    return {
        "name": "testuser__sample_tag",
        "display_name": "Sample Tag",
        "description": "A sample tag for testing",
        "type": "tag",
        "value_type": "null",
        "min_value": 0,
        "max_value": 0,
        "options": {},
        "disabled": False,
    }


@pytest.fixture
def mock_known_name_attr():
    """Sample known attribute name."""
    return {
        "name": "sample_attr",
        "display_name": "Sample Attr",
        "description": "A sample attribute for testing",
        "type": "attr",
        "value_type": "str",
        "min_value": 0,
        "max_value": 0,
        "options": {"opt1": {"display_name": "Option 1", "description": ""}},
        "disabled": False,
    }


@pytest.fixture
def mock_known_name_metric():
    """Sample known metric name."""
    return {
        "name": "sample_metric",
        "display_name": "Sample Metric",
        "description": "A sample metric for testing",
        "type": "metric",
        "value_type": "float",
        "min_value": 0.0,
        "max_value": 100.0,
        "options": {},
        "disabled": False,
    }


@pytest.fixture
def mock_doc_data():
    """Sample document data."""
    return {
        "id": "doc-test-123",
        "rid": 12345,
        "pdf_path": "s3://bucket/path/to/doc.pdf",
        "pdf_filename": "doc.pdf",
        "pdf_filesize": 10000,
        "pdf_hash": hashlib.sha256(b"test").hexdigest(),
        "num_pages": 5,
        "page_width": 612.0,
        "page_height": 792.0,
        "metadata": {"title": "Test Doc"},
        "orig_path": None,
        "orig_filename": None,
        "orig_filesize": None,
        "orig_hash": None,
        "tags": [],
        "attrs": {},
        "metrics": {},
        "create_time": 1700000000000,
        "update_time": 1700000000000,
    }


@pytest.fixture
def mock_page_data():
    """Sample page data."""
    return {
        "id": "page-test-123",
        "rid": 12345,
        "doc_id": "doc-test-123",
        "page_idx": 0,
        "image_path": "s3://bucket/path/to/page.png",
        "image_filesize": 5000,
        "image_hash": hashlib.sha256(b"test").hexdigest(),
        "image_width": 1200,
        "image_height": 1600,
        "image_dpi": 144,
        "providers": [],
        "tags": [],
        "attrs": {},
        "metrics": {},
        "create_time": 1700000000000,
        "update_time": 1700000000000,
    }


@pytest.fixture
def mock_block_data():
    """Sample block data."""
    return {
        "id": "block-test-123",
        "rid": 12345,
        "layout_id": None,
        "provider": None,
        "page_id": "page-test-123",
        "type": "text",
        "bbox": "0.1000,0.1000,0.9000,0.5000",
        "angle": None,
        "score": 0.95,
        "image_path": None,
        "image_filesize": None,
        "image_hash": None,
        "image_width": None,
        "image_height": None,
        "versions": [],
        "tags": [],
        "attrs": {},
        "metrics": {},
        "create_time": 1700000000000,
        "update_time": 1700000000000,
    }


@pytest.fixture
def mock_layout_data():
    """Sample layout data."""
    return {
        "id": "layout-test-123",
        "rid": 12345,
        "page_id": "page-test-123",
        "provider": "testuser__layout_v1",
        "masks": [],
        "blocks": [
            {
                "id": "layout-test-123.block-001",
                "type": "text",
                "bbox": "0.1000,0.1000,0.9000,0.5000",
                "angle": None,
            }
        ],
        "relations": [],
        "contents": [],
        "is_human_label": False,
        "tags": [],
        "attrs": {},
        "metrics": {},
        "create_time": 1700000000000,
        "update_time": 1700000000000,
    }


@pytest.fixture
def mock_content_data():
    """Sample content data."""
    return {
        "id": "content-test-123",
        "rid": 12345,
        "block_id": "block-test-123",
        "version": "testuser__ocr_v1",
        "page_id": "page-test-123",
        "format": "text",
        "content": "This is test content.",
        "is_human_label": False,
        "tags": [],
        "attrs": {},
        "metrics": {},
        "create_time": 1700000000000,
        "update_time": 1700000000000,
    }


@pytest.fixture
def mock_value_data():
    """Sample value data."""
    return {
        "id": "value-test-123",
        "rid": 12345,
        "elem_id": "block-test-123",
        "key": "testuser__embed_v1",
        "type": "str",
        "value": "test value",
        "create_time": 1700000000000,
        "update_time": 1700000000000,
    }


@pytest.fixture
def mock_task_data():
    """Sample task data."""
    return {
        "id": "test_cmd.1.123-456",
        "rid": 12345,
        "target": "block-test-123",
        "batch_id": "",
        "command": "test_cmd",
        "args": '{"param": "value"}',
        "priority": 1,
        "status": "new",
        "create_user": "testuser",
        "create_time": 1700000000000,
        "update_user": None,
        "update_time": None,
        "error_message": None,
    }


def create_mock_collection():
    """Create a mock MongoDB collection."""
    coll = MagicMock()
    coll.create_index = MagicMock()
    coll.find_one = MagicMock(return_value=None)
    coll.find = MagicMock(return_value=[])
    coll.insert_one = MagicMock()
    coll.update_one = MagicMock()
    coll.delete_one = MagicMock()
    coll.find_one_and_update = MagicMock(return_value=None)
    coll.aggregate = MagicMock(return_value=iter([]))
    coll.distinct = MagicMock(return_value=[])
    coll.count_documents = MagicMock(return_value=0)
    coll.estimated_document_count = MagicMock(return_value=0)
    return coll

