"""Data structures for aggregation queries."""

from typing import Any, Literal

from pydantic import BaseModel, Field

from .base import ElemType, InputModel

# 聚合操作类型
AggregateOp = Literal[
    "count",  # 计数
    "sum",  # 求和
    "avg",  # 平均值
    "min",  # 最小值
    "max",  # 最大值
    "first",  # 第一个值
    "last",  # 最后一个值
    "distinct",  # 去重计数
    "percentile",  # 百分位数
]

# 过滤操作类型
FilterOp = Literal[
    "eq",  # 等于
    "ne",  # 不等于
    "gt",  # 大于
    "gte",  # 大于等于
    "lt",  # 小于
    "lte",  # 小于等于
    "in",  # 在列表中
    "nin",  # 不在列表中
    "contains",  # 包含（字符串/数组）
    "regex",  # 正则匹配
    "between",  # 范围（闭区间）
    "exists",  # 字段存在
]

# 时间间隔类型
TimeInterval = Literal[
    "minute",
    "hour",
    "day",
    "week",
    "month",
    "quarter",
    "year",
]

# 排序方向
SortOrder = Literal["asc", "desc"]


class AggregateField(InputModel):
    """聚合字段定义。

    Attributes:
        field: 要聚合的字段名
        op: 聚合操作类型
        alias: 结果字段的别名，默认为 "{op}_{field}"
        options: 额外选项，如 percentile 的百分位值
    """

    field: str
    op: AggregateOp
    alias: str | None = None
    options: dict[str, Any] | None = None

    def get_alias(self) -> str:
        """获取结果字段的别名。"""
        return self.alias or f"{self.op}_{self.field}"


class FilterCondition(InputModel):
    """过滤条件定义。

    Attributes:
        field: 要过滤的字段名
        op: 过滤操作类型
        value: 过滤值
    """

    field: str
    op: FilterOp
    value: Any


class GroupBy(InputModel):
    """分组字段定义。

    Attributes:
        field: 分组字段名
        interval: 时间字段的分组间隔（仅用于时间类型字段）
        alias: 结果字段的别名
    """

    field: str
    interval: TimeInterval | None = None
    alias: str | None = None

    def get_alias(self) -> str:
        """获取结果字段的别名。"""
        if self.alias:
            return self.alias
        if self.interval:
            return f"{self.field}_{self.interval}"
        return self.field


class SortBy(InputModel):
    """排序定义。

    Attributes:
        field: 排序字段名（可以是聚合结果的别名）
        order: 排序方向，默认降序
    """

    field: str
    order: SortOrder = "desc"


class AggregateQuery(InputModel):
    """统一聚合查询结构。

    Attributes:
        elem_type: 要查询的元素类型
        filters: 聚合前的过滤条件列表
        group_by: 分组字段列表（支持多维分组）
        aggregates: 聚合操作列表
        having: 聚合后的过滤条件列表
        sort_by: 排序规则列表
        limit: 返回结果数量限制
        offset: 跳过的结果数量

    Example:
        >>> query = AggregateQuery(
        ...     elem_type="page",
        ...     filters=[
        ...         FilterCondition(field="tags", op="contains", value="invoice"),
        ...     ],
        ...     group_by=[
        ...         GroupBy(field="doc_id"),
        ...         GroupBy(field="create_time", interval="day"),
        ...     ],
        ...     aggregates=[
        ...         AggregateField(field="id", op="count", alias="page_count"),
        ...         AggregateField(field="image_filesize", op="sum", alias="total_size"),
        ...     ],
        ...     having=[
        ...         FilterCondition(field="page_count", op="gte", value=10),
        ...     ],
        ...     sort_by=[SortBy(field="total_size", order="desc")],
        ...     limit=100,
        ... )
    """

    elem_type: ElemType
    filters: list[FilterCondition] = Field(default_factory=list)
    group_by: list[GroupBy] = Field(default_factory=list)
    aggregates: list[AggregateField] = Field(default_factory=list)
    having: list[FilterCondition] = Field(default_factory=list)
    sort_by: list[SortBy] = Field(default_factory=list)
    limit: int | None = None
    offset: int | None = None


class AggregateResult(BaseModel):
    """聚合查询结果。

    Attributes:
        data: 聚合结果数据列表
        total: 结果总数
        query: 原始查询（用于调试）
    """

    data: list[dict[str, Any]]
    total: int
    query: AggregateQuery | None = None


class AggregateExplain(BaseModel):
    """聚合查询解释（用于调试）。

    Attributes:
        native_query: 翻译后的原生查询语法
        backend: 后端类型
    """

    native_query: Any
    backend: str
