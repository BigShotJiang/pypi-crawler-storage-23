"""
TiDB Adapter for DocStore

此模块提供 TiDB/MySQL 的数据库适配器，实现与 MongoDB 相同的操作接口。
可作为 DocStore 从 MongoDB 迁移到 TiDB 的参考实现。
"""

import json
import time
from typing import Any, Iterable, Literal, Sequence

from pydantic import BaseModel

# 假设使用 pymysql 或 mysql-connector-python
# 也可以使用 SQLAlchemy 或其他 ORM
try:
    import pymysql
    from pymysql.cursors import DictCursor
except ImportError:
    pymysql = None  # type: ignore

try:
    from sqlalchemy import create_engine, text
    from sqlalchemy.engine import Engine
    from sqlalchemy.orm import Session
except ImportError:
    create_engine = None  # type: ignore


# =====================================================
# 配置
# =====================================================

class TiDBConfig(BaseModel):
    """TiDB 连接配置"""
    host: str = "localhost"
    port: int = 4000
    user: str = "root"
    password: str = ""
    database: str = "doc_store"
    charset: str = "utf8mb4"
    
    @property
    def connection_string(self) -> str:
        return f"mysql+pymysql://{self.user}:{self.password}@{self.host}:{self.port}/{self.database}?charset={self.charset}"


# =====================================================
# JSON 工具函数
# =====================================================

def json_dumps(obj: Any) -> str:
    """将 Python 对象转换为 JSON 字符串"""
    if obj is None:
        return "null"
    return json.dumps(obj, ensure_ascii=False)


def json_loads(s: str | None) -> Any:
    """将 JSON 字符串转换为 Python 对象"""
    if s is None:
        return None
    return json.loads(s)


def parse_bbox(bbox_str: str) -> list[float]:
    """解析 bbox 字符串为列表"""
    if not bbox_str:
        return [0.0, 0.0, 1.0, 1.0]
    return [float(x) for x in bbox_str.split(",")]


def format_bbox(bbox: list[float]) -> str:
    """将 bbox 列表格式化为字符串"""
    return ",".join(f"{x:.4f}" for x in bbox)


# =====================================================
# TiDB Collection 适配器
# =====================================================

class TiDBCollection:
    """
    TiDB 表操作适配器，提供类似 MongoDB Collection 的接口
    """
    
    def __init__(self, engine: "Engine", table_name: str):
        self.engine = engine
        self.table_name = table_name
        
        # 定义需要 JSON 处理的字段
        self.json_fields = {"tags", "attrs", "metrics", "providers", "versions", 
                           "metadata", "options", "aliases", "args", "condition", 
                           "actions", "blocks", "relations"}
    
    def _process_row(self, row: dict) -> dict:
        """处理查询结果，将 JSON 字符串转换为 Python 对象"""
        if row is None:
            return None
        result = dict(row)
        for field in self.json_fields:
            if field in result and isinstance(result[field], str):
                result[field] = json_loads(result[field])
        # 处理 bbox
        if "bbox" in result and isinstance(result["bbox"], str):
            result["bbox"] = parse_bbox(result["bbox"])
        return result
    
    def _build_where_clause(self, filter: dict) -> tuple[str, dict]:
        """
        将 MongoDB 风格的查询条件转换为 SQL WHERE 子句
        
        支持的操作符:
        - 直接相等: {"field": value}
        - $in: {"field": {"$in": [values]}}
        - $nin: {"field": {"$nin": [values]}}
        - $gt, $gte, $lt, $lte: {"field": {"$gt": value}}
        - $ne: {"field": {"$ne": value}}
        - $exists: {"field": {"$exists": True/False}}
        - JSON 数组包含: {"tags": tag_value} 或 {"providers": provider_value}
        """
        if not filter:
            return "1=1", {}
        
        conditions = []
        params = {}
        
        for idx, (field, value) in enumerate(filter.items()):
            param_name = f"p{idx}"
            
            if isinstance(value, dict):
                # 操作符查询
                for op, op_value in value.items():
                    if op == "$in":
                        placeholders = ",".join(f":{param_name}_{i}" for i in range(len(op_value)))
                        conditions.append(f"{field} IN ({placeholders})")
                        for i, v in enumerate(op_value):
                            params[f"{param_name}_{i}"] = v
                    elif op == "$nin":
                        placeholders = ",".join(f":{param_name}_{i}" for i in range(len(op_value)))
                        conditions.append(f"{field} NOT IN ({placeholders})")
                        for i, v in enumerate(op_value):
                            params[f"{param_name}_{i}"] = v
                    elif op == "$gt":
                        conditions.append(f"{field} > :{param_name}")
                        params[param_name] = op_value
                    elif op == "$gte":
                        conditions.append(f"{field} >= :{param_name}")
                        params[param_name] = op_value
                    elif op == "$lt":
                        conditions.append(f"{field} < :{param_name}")
                        params[param_name] = op_value
                    elif op == "$lte":
                        conditions.append(f"{field} <= :{param_name}")
                        params[param_name] = op_value
                    elif op == "$ne":
                        conditions.append(f"{field} != :{param_name}")
                        params[param_name] = op_value
                    elif op == "$exists":
                        if op_value:
                            conditions.append(f"{field} IS NOT NULL")
                        else:
                            conditions.append(f"{field} IS NULL")
            elif field in ("tags", "providers", "versions"):
                # JSON 数组包含查询
                conditions.append(f"JSON_CONTAINS(COALESCE({field}, JSON_ARRAY()), JSON_QUOTE(:{param_name}), '$')")
                params[param_name] = value
            else:
                # 直接相等
                if value is None:
                    conditions.append(f"{field} IS NULL")
                else:
                    conditions.append(f"{field} = :{param_name}")
                    params[param_name] = value
        
        return " AND ".join(conditions), params
    
    def find_one(
        self,
        filter: dict[str, Any],
        projection: dict[str, int] | list[str] | None = None,
    ) -> dict[str, Any] | None:
        """查询单条记录"""
        where_clause, params = self._build_where_clause(filter)
        
        # 处理 projection
        if projection is None:
            columns = "*"
        elif isinstance(projection, list):
            columns = ", ".join(projection)
        else:
            columns = ", ".join(k for k, v in projection.items() if v)
        
        sql = f"SELECT {columns} FROM {self.table_name} WHERE {where_clause} LIMIT 1"
        
        with self.engine.connect() as conn:
            result = conn.execute(text(sql), params)
            row = result.mappings().first()
            return self._process_row(dict(row)) if row else None
    
    def find(
        self,
        filter: dict[str, Any],
        skip: int | None = None,
        limit: int | None = None,
        sort: list[tuple[str, int]] | None = None,
    ) -> Iterable[dict[str, Any]]:
        """查询多条记录"""
        where_clause, params = self._build_where_clause(filter)
        
        sql = f"SELECT * FROM {self.table_name} WHERE {where_clause}"
        
        # 排序
        if sort:
            order_parts = []
            for field, direction in sort:
                order_parts.append(f"{field} {'ASC' if direction == 1 else 'DESC'}")
            sql += f" ORDER BY {', '.join(order_parts)}"
        
        # 分页
        if limit is not None:
            sql += f" LIMIT {limit}"
        if skip is not None:
            sql += f" OFFSET {skip}"
        
        with self.engine.connect() as conn:
            result = conn.execute(text(sql), params)
            for row in result.mappings():
                yield self._process_row(dict(row))
    
    def insert_one(self, document: dict[str, Any]) -> str:
        """插入单条记录"""
        # 处理 JSON 字段
        processed_doc = {}
        for key, value in document.items():
            if key in self.json_fields and value is not None:
                processed_doc[key] = json_dumps(value)
            elif key == "bbox" and isinstance(value, list):
                processed_doc[key] = format_bbox(value)
            else:
                processed_doc[key] = value
        
        columns = ", ".join(processed_doc.keys())
        placeholders = ", ".join(f":{k}" for k in processed_doc.keys())
        
        sql = f"INSERT INTO {self.table_name} ({columns}) VALUES ({placeholders})"
        
        with self.engine.connect() as conn:
            conn.execute(text(sql), processed_doc)
            conn.commit()
        
        return document.get("id", "")
    
    def insert_many(
        self,
        documents: Sequence[dict[str, Any]],
        ordered: bool = True,
    ) -> list[str]:
        """插入多条记录"""
        ids = []
        for doc in documents:
            try:
                doc_id = self.insert_one(doc)
                ids.append(doc_id)
            except Exception as e:
                if ordered:
                    raise
                # 非顺序模式下继续
        return ids
    
    def update_one(
        self,
        filter: dict[str, Any],
        update: dict[str, Any],
        upsert: bool = False,
    ) -> int:
        """更新单条记录"""
        where_clause, where_params = self._build_where_clause(filter)
        
        # 解析 MongoDB 风格的更新操作
        set_parts = []
        update_params = {}
        
        if "$set" in update:
            for key, value in update["$set"].items():
                param_name = f"set_{key}"
                if key in self.json_fields and value is not None:
                    set_parts.append(f"{key} = :{param_name}")
                    update_params[param_name] = json_dumps(value)
                elif key == "bbox" and isinstance(value, list):
                    set_parts.append(f"{key} = :{param_name}")
                    update_params[param_name] = format_bbox(value)
                else:
                    set_parts.append(f"{key} = :{param_name}")
                    update_params[param_name] = value
        
        if "$unset" in update:
            for key in update["$unset"]:
                set_parts.append(f"{key} = NULL")
        
        if "$addToSet" in update:
            for key, value in update["$addToSet"].items():
                # 使用 JSON_ARRAY_APPEND
                param_name = f"add_{key}"
                set_parts.append(
                    f"{key} = CASE WHEN JSON_CONTAINS(COALESCE({key}, JSON_ARRAY()), JSON_QUOTE(:{param_name}), '$') "
                    f"THEN {key} ELSE JSON_ARRAY_APPEND(COALESCE({key}, JSON_ARRAY()), '$', :{param_name}) END"
                )
                update_params[param_name] = value
        
        if not set_parts:
            return 0
        
        sql = f"UPDATE {self.table_name} SET {', '.join(set_parts)} WHERE {where_clause}"
        
        with self.engine.connect() as conn:
            result = conn.execute(text(sql), {**update_params, **where_params})
            conn.commit()
            return result.rowcount
    
    def find_one_and_update(
        self,
        filter: dict[str, Any],
        update: dict[str, Any],
        projection: dict[str, int] | list[str] | None = None,
        upsert: bool = False,
        return_document: Literal["before", "after"] = "after",
    ) -> dict[str, Any] | None:
        """查找并更新记录"""
        # 先获取原始记录
        if return_document == "before":
            original = self.find_one(filter, projection)
        
        # 执行更新
        modified = self.update_one(filter, update, upsert)
        
        if modified == 0 and not upsert:
            return None
        
        if return_document == "after":
            return self.find_one(filter, projection)
        else:
            return original
    
    def delete_one(self, filter: dict[str, Any]) -> int:
        """删除单条记录"""
        where_clause, params = self._build_where_clause(filter)
        sql = f"DELETE FROM {self.table_name} WHERE {where_clause} LIMIT 1"
        
        with self.engine.connect() as conn:
            result = conn.execute(text(sql), params)
            conn.commit()
            return result.rowcount
    
    def delete_many(self, filter: dict[str, Any]) -> int:
        """删除多条记录"""
        where_clause, params = self._build_where_clause(filter)
        sql = f"DELETE FROM {self.table_name} WHERE {where_clause}"
        
        with self.engine.connect() as conn:
            result = conn.execute(text(sql), params)
            conn.commit()
            return result.rowcount
    
    def count_documents(self, filter: dict[str, Any]) -> int:
        """计数匹配记录"""
        where_clause, params = self._build_where_clause(filter)
        sql = f"SELECT COUNT(*) as count FROM {self.table_name} WHERE {where_clause}"
        
        with self.engine.connect() as conn:
            result = conn.execute(text(sql), params)
            row = result.mappings().first()
            return row["count"] if row else 0
    
    def estimated_document_count(self) -> int:
        """估算记录总数"""
        sql = """
        SELECT TABLE_ROWS 
        FROM information_schema.tables 
        WHERE table_schema = DATABASE() AND table_name = :table_name
        """
        
        with self.engine.connect() as conn:
            result = conn.execute(text(sql), {"table_name": self.table_name})
            row = result.mappings().first()
            return row["TABLE_ROWS"] if row else 0
    
    def distinct(
        self,
        field: str,
        filter: dict[str, Any] | None = None,
    ) -> list[Any]:
        """获取字段的唯一值"""
        where_clause, params = self._build_where_clause(filter or {})
        
        if field in ("tags", "providers", "versions"):
            # JSON 数组字段
            sql = f"""
            SELECT DISTINCT jt.value
            FROM {self.table_name}, 
                 JSON_TABLE(COALESCE({field}, JSON_ARRAY()), '$[*]' COLUMNS(value VARCHAR(255) PATH '$')) AS jt
            WHERE {where_clause}
            """
        else:
            sql = f"SELECT DISTINCT {field} FROM {self.table_name} WHERE {where_clause}"
        
        with self.engine.connect() as conn:
            result = conn.execute(text(sql), params)
            return [row[0] for row in result if row[0] is not None]
    
    def create_index(self, keys: list[tuple[str, int]], unique: bool = False) -> str:
        """创建索引"""
        index_name = f"idx_{'_'.join(k for k, _ in keys)}"
        columns = ", ".join(f"{k} {'ASC' if d == 1 else 'DESC'}" for k, d in keys)
        unique_str = "UNIQUE" if unique else ""
        
        sql = f"CREATE {unique_str} INDEX {index_name} ON {self.table_name} ({columns})"
        
        try:
            with self.engine.connect() as conn:
                conn.execute(text(sql))
                conn.commit()
        except Exception:
            pass  # 索引可能已存在
        
        return index_name


# =====================================================
# TiDB Database 适配器
# =====================================================

class TiDBDatabase:
    """
    TiDB 数据库适配器，提供类似 MongoDB Database 的接口
    """
    
    def __init__(self, config: TiDBConfig | None = None):
        if config is None:
            config = TiDBConfig()
        self.config = config
        self.engine = create_engine(config.connection_string, pool_pre_ping=True)
        self._collections: dict[str, TiDBCollection] = {}
    
    def get_collection(self, name: str) -> TiDBCollection:
        """获取集合（表）"""
        if name not in self._collections:
            self._collections[name] = TiDBCollection(self.engine, name)
        return self._collections[name]
    
    def __getattr__(self, name: str) -> TiDBCollection:
        """允许通过属性访问集合"""
        return self.get_collection(name)


# =====================================================
# Tag/Attr/Metric 操作辅助类
# =====================================================

class TaggingOperations:
    """
    标签、属性、指标操作辅助类
    封装 MongoDB $addToSet, $pull, $mergeObjects 等操作的 SQL 实现
    """
    
    def __init__(self, engine: "Engine"):
        self.engine = engine
    
    def add_tag(self, table: str, elem_id: str, tag: str) -> None:
        """添加标签"""
        sql = f"""
        UPDATE {table}
        SET tags = JSON_ARRAY_APPEND(COALESCE(tags, JSON_ARRAY()), '$', :tag),
            update_time = :update_time
        WHERE id = :elem_id
          AND NOT JSON_CONTAINS(COALESCE(tags, JSON_ARRAY()), JSON_QUOTE(:tag), '$')
        """
        with self.engine.connect() as conn:
            conn.execute(text(sql), {
                "elem_id": elem_id,
                "tag": tag,
                "update_time": int(time.time() * 1000)
            })
            conn.commit()
    
    def del_tag(self, table: str, elem_id: str, tag: str) -> None:
        """删除标签"""
        # 需要重建 tags 数组（排除指定标签）
        sql = f"""
        UPDATE {table}
        SET tags = (
            SELECT COALESCE(JSON_ARRAYAGG(jt.tag_value), JSON_ARRAY())
            FROM JSON_TABLE(COALESCE(tags, JSON_ARRAY()), '$[*]' COLUMNS(tag_value VARCHAR(255) PATH '$')) AS jt
            WHERE jt.tag_value != :tag
        ),
        update_time = :update_time
        WHERE id = :elem_id
        """
        with self.engine.connect() as conn:
            conn.execute(text(sql), {
                "elem_id": elem_id,
                "tag": tag,
                "update_time": int(time.time() * 1000)
            })
            conn.commit()
    
    def add_attr(self, table: str, elem_id: str, name: str, value: Any) -> None:
        """添加属性"""
        sql = f"""
        UPDATE {table}
        SET attrs = JSON_SET(COALESCE(attrs, JSON_OBJECT()), CONCAT('$.', :name), CAST(:value AS JSON)),
            update_time = :update_time
        WHERE id = :elem_id
        """
        with self.engine.connect() as conn:
            conn.execute(text(sql), {
                "elem_id": elem_id,
                "name": name,
                "value": json_dumps(value),
                "update_time": int(time.time() * 1000)
            })
            conn.commit()
    
    def add_attrs(self, table: str, elem_id: str, attrs: dict[str, Any]) -> None:
        """添加多个属性"""
        sql = f"""
        UPDATE {table}
        SET attrs = JSON_MERGE_PATCH(COALESCE(attrs, JSON_OBJECT()), :attrs),
            update_time = :update_time
        WHERE id = :elem_id
        """
        with self.engine.connect() as conn:
            conn.execute(text(sql), {
                "elem_id": elem_id,
                "attrs": json_dumps(attrs),
                "update_time": int(time.time() * 1000)
            })
            conn.commit()
    
    def del_attr(self, table: str, elem_id: str, name: str) -> None:
        """删除属性"""
        sql = f"""
        UPDATE {table}
        SET attrs = JSON_REMOVE(attrs, CONCAT('$.', :name)),
            update_time = :update_time
        WHERE id = :elem_id
        """
        with self.engine.connect() as conn:
            conn.execute(text(sql), {
                "elem_id": elem_id,
                "name": name,
                "update_time": int(time.time() * 1000)
            })
            conn.commit()
    
    def add_metric(self, table: str, elem_id: str, name: str, value: float | int) -> None:
        """添加指标"""
        sql = f"""
        UPDATE {table}
        SET metrics = JSON_SET(COALESCE(metrics, JSON_OBJECT()), CONCAT('$.', :name), :value),
            update_time = :update_time
        WHERE id = :elem_id
        """
        with self.engine.connect() as conn:
            conn.execute(text(sql), {
                "elem_id": elem_id,
                "name": name,
                "value": value,
                "update_time": int(time.time() * 1000)
            })
            conn.commit()
    
    def del_metric(self, table: str, elem_id: str, name: str) -> None:
        """删除指标"""
        sql = f"""
        UPDATE {table}
        SET metrics = JSON_REMOVE(metrics, CONCAT('$.', :name)),
            update_time = :update_time
        WHERE id = :elem_id
        """
        with self.engine.connect() as conn:
            conn.execute(text(sql), {
                "elem_id": elem_id,
                "name": name,
                "update_time": int(time.time() * 1000)
            })
            conn.commit()


# =====================================================
# 分布式锁和计数器
# =====================================================

class DistributedLock:
    """分布式锁（乐观锁实现）"""
    
    def __init__(self, engine: "Engine"):
        self.engine = engine
    
    def read_ahead(self, key: str) -> int:
        """读取锁版本"""
        sql = "SELECT version FROM locks WHERE `key` = :key"
        with self.engine.connect() as conn:
            result = conn.execute(text(sql), {"key": key})
            row = result.mappings().first()
            return row["version"] if row else 0
    
    def post_commit(self, key: str, version: int) -> bool:
        """提交锁版本，返回是否成功"""
        if version == 0:
            # 新建锁
            sql = "INSERT INTO locks (`key`, version) VALUES (:key, 1)"
            try:
                with self.engine.connect() as conn:
                    conn.execute(text(sql), {"key": key})
                    conn.commit()
                return True
            except Exception:
                return False
        else:
            # 更新锁
            sql = "UPDATE locks SET version = version + 1 WHERE `key` = :key AND version = :version"
            with self.engine.connect() as conn:
                result = conn.execute(text(sql), {"key": key, "version": version})
                conn.commit()
                return result.rowcount > 0


class DistributedCounter:
    """分布式计数器"""
    
    def __init__(self, engine: "Engine"):
        self.engine = engine
    
    def next(self, key: str) -> int:
        """获取下一个计数值"""
        sql = """
        INSERT INTO counters (`key`, value) VALUES (:key, 1)
        ON DUPLICATE KEY UPDATE value = value + 1
        """
        with self.engine.connect() as conn:
            conn.execute(text(sql), {"key": key})
            conn.commit()
        
        sql = "SELECT value FROM counters WHERE `key` = :key"
        with self.engine.connect() as conn:
            result = conn.execute(text(sql), {"key": key})
            row = result.mappings().first()
            return row["value"] if row else 1


# =====================================================
# 示例：使用 TiDB 适配器
# =====================================================

def example_usage():
    """示例用法"""
    # 创建数据库连接
    config = TiDBConfig(
        host="localhost",
        port=4000,
        user="root",
        password="",
        database="doc_store"
    )
    db = TiDBDatabase(config)
    
    # 获取集合
    docs = db.get_collection("docs")
    pages = db.get_collection("pages")
    
    # 插入文档
    doc_id = docs.insert_one({
        "id": "doc-123",
        "rid": 12345,
        "pdf_path": "s3://bucket/path/to/doc.pdf",
        "pdf_filesize": 12345,
        "pdf_hash": "abc123",
        "num_pages": 10,
        "page_width": 595.0,
        "page_height": 842.0,
        "metadata": {"title": "Test Document"},
        "tags": ["tag1", "tag2"],
        "attrs": {"difficulty": "easy"},
        "metrics": {"score": 0.95},
        "create_time": int(time.time() * 1000),
        "update_time": int(time.time() * 1000),
    })
    print(f"Inserted doc: {doc_id}")
    
    # 查询文档
    doc = docs.find_one({"id": "doc-123"})
    print(f"Found doc: {doc}")
    
    # 按标签查询
    tagged_docs = list(docs.find({"tags": "tag1"}))
    print(f"Docs with tag1: {len(tagged_docs)}")
    
    # 添加标签
    tagging = TaggingOperations(db.engine)
    tagging.add_tag("docs", "doc-123", "new_tag")
    
    # 添加属性
    tagging.add_attr("docs", "doc-123", "category", "research")
    
    # 统计
    count = docs.count_documents({"tags": "tag1"})
    print(f"Count of docs with tag1: {count}")
    
    # 获取唯一标签
    unique_tags = docs.distinct("tags")
    print(f"Unique tags: {unique_tags}")


if __name__ == "__main__":
    example_usage()


