from abc import ABC, abstractmethod
from typing import Literal

from pydantic import BaseModel

from .base import InputModel
from .task import TaskInput


class DocEvent(BaseModel):
    elem_id: str
    elem_type: Literal["doc", "page", "layout", "block", "content"]
    event_type: Literal["insert", "add_tag", "del_tag", "add_provider", "add_version"]
    event_user: str
    # --- Relative element ids ---
    doc_id: str | None = None
    page_id: str | None = None
    layout_id: str | None = None
    block_id: str | None = None
    # --- Fields for matching ---
    page_providers: list[str] | None = None
    layout_provider: str | None = None
    block_type: str | None = None
    block_versions: list[str] | None = None
    content_version: str | None = None
    tags: list[str] | None = None  # tags of current element
    page_tags: list[str] | None = None  # tags of current element's page
    # --- Specific to event types ---
    tag_added: list[str] | None = None
    tag_deleted: list[str] | None = None
    provider_added: str | None = None
    version_added: str | None = None


class TriggerCondition(BaseModel):
    elem_type: Literal["doc", "page", "layout", "block", "content"]
    # "add_tag" condition can also match "insert" event.
    event_type: Literal["insert", "add_tag", "del_tag", "add_provider", "add_version"]
    event_user: str | None = None
    page_providers: list[str] | None = None  # Match page with all these providers
    layout_provider: list[str] | None = None  # Match layout/block with any of these providers
    block_type: list[str] | None = None  # Match block with any of these types
    block_versions: list[str] | None = None  # Match block with all these versions
    content_version: list[str] | None = None  # Match content with any of these versions
    tags: list[str] | None = None  # Match element with all these tags
    page_tags: list[str] | None = None  # Match layout/block having page with all these tags
    # --- Specific to event types ---
    tag_added: list[str] | None = None  # Match add_tag event with any of these tags added
    tag_deleted: list[str] | None = None  # Match del_tag event with any of these tags deleted
    provider_added: list[str] | None = None  # Match add_provider event with any of these providers added
    version_added: list[str] | None = None  # Match add_version event with any of these versions added


class TriggerAction(BaseModel):
    action_type: Literal["add_tag", "insert_task"]
    add_tag: str | None = None  # Tag to add
    insert_task: TaskInput | None = None  # Task to insert


class TriggerInput(InputModel):
    name: str
    description: str
    condition: TriggerCondition
    actions: list[TriggerAction]
    disabled: bool = False
    display_order: float | None = None


class Trigger(TriggerInput):
    id: str
    create_user: str
    create_time: int
    update_time: int


class TriggerABC(ABC):
    """Abstract class for trigger operations."""

    @abstractmethod
    def list_triggers(self) -> list[Trigger]:
        """List all triggers in the system."""
        raise NotImplementedError()

    @abstractmethod
    def get_trigger(self, trigger_id: str) -> Trigger:
        """Get a trigger by ID."""
        raise NotImplementedError()

    @abstractmethod
    def insert_trigger(self, trigger_input: TriggerInput) -> Trigger:
        """Insert a new trigger to the system."""
        raise NotImplementedError()

    @abstractmethod
    def update_trigger(self, trigger_id: str, trigger_input: TriggerInput) -> Trigger:
        """Update an existing trigger in the system."""
        raise NotImplementedError()

    @abstractmethod
    def delete_trigger(self, trigger_id: str) -> None:
        """Delete a trigger from the system."""
        raise NotImplementedError()


class AioTriggerABC(ABC):
    """Async abstract class for trigger operations."""

    @abstractmethod
    async def list_triggers(self) -> list[Trigger]:
        """List all triggers in the system (async)."""
        raise NotImplementedError()

    @abstractmethod
    async def get_trigger(self, trigger_id: str) -> Trigger:
        """Get a trigger by ID (async)."""
        raise NotImplementedError()

    @abstractmethod
    async def insert_trigger(self, trigger_input: TriggerInput) -> Trigger:
        """Insert a new trigger to the system (async)."""
        raise NotImplementedError()

    @abstractmethod
    async def update_trigger(self, trigger_id: str, trigger_input: TriggerInput) -> Trigger:
        """Update an existing trigger in the system (async)."""
        raise NotImplementedError()

    @abstractmethod
    async def delete_trigger(self, trigger_id: str) -> None:
        """Delete a trigger from the system (async)."""
        raise NotImplementedError()
