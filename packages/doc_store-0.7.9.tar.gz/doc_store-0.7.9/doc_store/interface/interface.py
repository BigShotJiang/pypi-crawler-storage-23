import time
from typing import AsyncIterable, Callable, Iterable

from ..utils import BlockingThreadPool, secs_to_readable
from .base import AioBaseABC, BaseABC, ElemType, ElemTypeNames
from .block import AioBlockABC, Block, BlockABC, StandaloneBlockInput
from .content import AioContentABC, Content, ContentABC
from .doc import AioDocABC, Doc, DocABC, DocInput
from .elem import DocElement
from .embedding import AioEmbeddingABC, EmbeddingABC
from .error import (
    DocExistsError,
    ElementExistsError,
    ElementNotFoundError,
    PageExistsError,
)
from .eval import AioEvalABC, EvalABC
from .io import IO_ABC, AioIO_ABC
from .layout import AioLayoutABC, Layout, LayoutABC
from .management import AioManagementABC, ManagementABC
from .page import AioPageABC, Page, PageABC, PageInput
from .tagging import AioTaggingABC, TaggingABC
from .task import AioTaskABC, TaskABC
from .trigger import AioTriggerABC, TriggerABC
from .value import AioValueABC, Value, ValueABC


class DocStoreABC(
    BaseABC,
    DocABC,
    PageABC,
    LayoutABC,
    BlockABC,
    ContentABC,
    EvalABC,
    ValueABC,
    TaggingABC,
    TaskABC,
    IO_ABC,
    ManagementABC,
    EmbeddingABC,
    TriggerABC,
):
    """
    Abstract base class containing all abstract methods for DocStoreInterface.
    This class combines all specialized abstract classes.
    """


class AioDocStoreABC(
    AioBaseABC,
    AioDocABC,
    AioPageABC,
    AioLayoutABC,
    AioBlockABC,
    AioContentABC,
    AioEvalABC,
    AioValueABC,
    AioTaggingABC,
    AioTaskABC,
    AioIO_ABC,
    AioManagementABC,
    AioEmbeddingABC,
    AioTriggerABC,
):
    """
    Async abstract base class containing all async abstract methods for AioDocStoreInterface.
    This class combines all specialized async abstract classes.
    """


class DocStoreInterface(DocStoreABC):
    """Added non-abstract methods for DocStoreABC."""

    def get(self, elem_id: str) -> DocElement:
        """Get an element by its ID."""
        if elem_id.startswith("doc-"):
            return self.get_doc(elem_id)
        if elem_id.startswith("page-"):
            return self.get_page(elem_id)
        if elem_id.startswith("layout-"):
            if ".block-" in elem_id:
                return self.get_block(elem_id)
            if ".content-" in elem_id:
                return self.get_content(elem_id)
            return self.get_layout(elem_id)
        if elem_id.startswith("block-"):
            return self.get_block(elem_id)
        if elem_id.startswith("content-"):
            return self.get_content(elem_id)
        if elem_id.startswith("evallayout-"):
            return self.get_eval_layout(elem_id)
        if elem_id.startswith("evalcontent-"):
            return self.get_eval_content(elem_id)
        # TODO: fallback to block for now.
        return self.get_block(elem_id)

    def try_get(self, elem_id: str) -> DocElement | None:
        """Try to get a element by its ID, return None if not found."""
        try:
            return self.get(elem_id)
        except ElementNotFoundError:
            return None

    def doc_tags(self) -> list[str]:
        """Get all distinct tags for docs."""
        return self.distinct_values("doc", "tags")

    def page_tags(self) -> list[str]:
        """Get all distinct tags for pages."""
        return self.distinct_values("page", "tags")

    def page_providers(self) -> list[str]:
        """Get all distinct providers for pages."""
        return self.distinct_values("page", "providers")

    def layout_providers(self) -> list[str]:
        """Get all distinct layout providers."""
        return self.distinct_values("layout", "provider")

    def layout_tags(self) -> list[str]:
        """Get all distinct tags for layouts."""
        return self.distinct_values("layout", "tags")

    def block_tags(self) -> list[str]:
        """Get all distinct tags for blocks."""
        return self.distinct_values("block", "tags")

    def block_versions(self) -> list[str]:
        """Get all distinct versions for blocks."""
        return self.distinct_values("block", "versions")

    def content_versions(self) -> list[str]:
        """Get all distinct content versions."""
        return self.distinct_values("content", "version")

    def content_tags(self) -> list[str]:
        """Get all distinct tags for contents."""
        return self.distinct_values("content", "tags")

    def find_docs(
        self,
        query: dict | list[dict] | None = None,
        skip: int | None = None,
        limit: int | None = None,
    ) -> Iterable[Doc]:
        """List docs by filters."""
        query = query or {}
        for elem in self.find("doc", query, skip=skip, limit=limit):
            assert isinstance(elem, Doc)
            yield elem

    def find_pages(
        self,
        query: dict | list[dict] | None = None,
        doc_id: str | None = None,
        skip: int | None = None,
        limit: int | None = None,
    ) -> Iterable[Page]:
        """List pages by filters."""
        query = query or {}
        if doc_id is not None:
            if not isinstance(query, dict):
                raise ValueError("doc_id filter cannot be used with pipeline query.")
            query["doc_id"] = doc_id
        for elem in self.find("page", query, skip=skip, limit=limit):
            assert isinstance(elem, Page)
            yield elem

    def find_layouts(
        self,
        query: dict | list[dict] | None = None,
        page_id: str | None = None,
        skip: int | None = None,
        limit: int | None = None,
    ) -> Iterable[Layout]:
        """List layouts by filters."""
        query = query or {}
        if page_id is not None:
            if not isinstance(query, dict):
                raise ValueError("page_id filter cannot be used with pipeline query.")
            query["page_id"] = page_id
        for elem in self.find("layout", query, skip=skip, limit=limit):
            assert isinstance(elem, Layout)
            yield elem

    def find_blocks(
        self,
        query: dict | list[dict] | None = None,
        page_id: str | None = None,
        skip: int | None = None,
        limit: int | None = None,
    ) -> Iterable[Block]:
        """List blocks by filters."""
        query = query or {}
        if page_id is not None:
            if not isinstance(query, dict):
                raise ValueError("page_id filter cannot be used with pipeline query.")
            query["page_id"] = page_id
        for elem in self.find("block", query, skip=skip, limit=limit):
            assert isinstance(elem, Block)
            yield elem

    def find_contents(
        self,
        query: dict | list[dict] | None = None,
        page_id: str | None = None,
        block_id: str | None = None,
        skip: int | None = None,
        limit: int | None = None,
    ) -> Iterable[Content]:
        """List contents by filters."""
        query = query or {}
        if page_id is not None:
            if not isinstance(query, dict):
                raise ValueError("page_id filter cannot be used with pipeline query.")
            query["page_id"] = page_id
        if block_id is not None:
            if not isinstance(query, dict):
                raise ValueError("block_id filter cannot be used with pipeline query.")
            query["block_id"] = block_id
        for elem in self.find("content", query, skip=skip, limit=limit):
            assert isinstance(elem, Content)
            yield elem

    def find_values(
        self,
        query: dict | list[dict] | None = None,
        elem_id: str | None = None,
        key: str | None = None,
        skip: int | None = None,
        limit: int | None = None,
    ) -> Iterable[Value]:
        """List values by filters."""
        query = query or {}
        if elem_id is not None:
            if not isinstance(query, dict):
                raise ValueError("elem_id filter cannot be used with pipeline query.")
            query["elem_id"] = elem_id
        if key is not None:
            if not isinstance(query, dict):
                raise ValueError("key filter cannot be used with pipeline query.")
            query["key"] = key
        for elem in self.find("value", query, skip=skip, limit=limit):
            assert isinstance(elem, Value)
            yield elem

    def insert_local_doc(self, local_pdf_path: str) -> Doc:
        s3_pdf_path = self.upload_local_file("doc", local_pdf_path)
        try:
            return self.insert_doc(DocInput(pdf_path=s3_pdf_path))
        except DocExistsError as e:
            return self.get_doc_by_pdf_hash(e.pdf_hash) if e.pdf_hash else self.get_doc_by_pdf_path(e.pdf_path)

    def insert_local_page(self, local_image_path: str) -> Page:
        s3_image_path = self.upload_local_file("page", local_image_path)
        try:
            return self.insert_page(PageInput(image_path=s3_image_path))
        except PageExistsError as e:
            return self.get_page_by_image_hash(e.image_hash) if e.image_hash else self.get_page_by_image_path(e.image_path)

    def insert_local_block(self, type: str, local_image_path: str) -> Block:
        s3_image_path = self.upload_local_file("block", local_image_path)
        try:
            return self.insert_standalone_block(StandaloneBlockInput(type=type, image_path=s3_image_path))
        except ElementExistsError:
            return self.get_block_by_image_path(s3_image_path)

    def iterate(
        self,
        elem_type: ElemType | type,
        func: Callable[[int, DocElement], None],
        query: dict | list[dict] | None = None,
        query_from: ElemType | type | None = None,
        max_workers: int = 10,
        total: int | None = None,
    ) -> None:
        if isinstance(elem_type, type):
            elem_type_name = elem_type.__name__.lower()
            assert elem_type_name in ElemTypeNames
            elem_type = elem_type_name

        if isinstance(query_from, type):
            query_type_name = query_from.__name__.lower()
            assert query_type_name in ElemTypeNames
            query_from = query_type_name

        if query is None:
            query = {}

        if total is None:
            print("Estimating element count...")
            begin = time.time()
            cnt = self.count(
                elem_type=elem_type,
                query=query,
                query_from=query_from,
                estimated=True,
            )
            elapsed = round(time.time() - begin, 2)
            print(f"Estimation done. Found {cnt} elements in {elapsed} seconds.")
        else:
            cnt = max(0, total)

        print("Iterating over elements...")
        begin = time.time()
        cursor = self.find(
            elem_type=elem_type,
            query=query,
            query_from=query_from,
        )

        last_report_time = time.time()
        with BlockingThreadPool(max_workers) as executor:
            for idx, elem_data in enumerate(cursor):
                now = time.time()
                if idx > 0 and (now - last_report_time) > 10:
                    curr = str(idx).rjust(len(str(cnt)))
                    curr = f"{curr}/{cnt}" if cnt > 0 else curr
                    elapsed = round(now - begin, 2)
                    rps = round(idx / elapsed, 2) if elapsed > 0 else idx
                    message = f"Processed {curr} elements in {elapsed}s, {rps}r/s"
                    if cnt > 0:
                        prog = round(idx / cnt * 100, 2)
                        remaining_secs = int(elapsed * (cnt - idx) / idx)
                        rtime = secs_to_readable(remaining_secs)
                        message = f"[{prog:5.2f}%] {message}, remaining time: {rtime}"
                    print(message)
                    last_report_time = now
                executor.submit(func, idx, elem_data)
            executor.shutdown(wait=True)


class AioDocStoreInterface(AioDocStoreABC):
    """Added non-abstract async methods for AioDocStoreABC."""

    async def get(self, elem_id: str) -> DocElement:
        """Get an element by its ID (async)."""
        if elem_id.startswith("doc-"):
            return await self.get_doc(elem_id)
        if elem_id.startswith("page-"):
            return await self.get_page(elem_id)
        if elem_id.startswith("layout-"):
            if ".block-" in elem_id:
                return await self.get_block(elem_id)
            if ".content-" in elem_id:
                return await self.get_content(elem_id)
            return await self.get_layout(elem_id)
        if elem_id.startswith("block-"):
            return await self.get_block(elem_id)
        if elem_id.startswith("content-"):
            return await self.get_content(elem_id)
        if elem_id.startswith("evallayout-"):
            return await self.get_eval_layout(elem_id)
        if elem_id.startswith("evalcontent-"):
            return await self.get_eval_content(elem_id)
        # TODO: fallback to block for now.
        return await self.get_block(elem_id)

    async def try_get(self, elem_id: str) -> DocElement | None:
        """Try to get an element by its ID, return None if not found (async)."""
        try:
            return await self.get(elem_id)
        except ElementNotFoundError:
            return None

    async def doc_tags(self) -> list[str]:
        """Get all distinct tags for docs (async)."""
        return await self.distinct_values("doc", "tags")

    async def page_tags(self) -> list[str]:
        """Get all distinct tags for pages (async)."""
        return await self.distinct_values("page", "tags")

    async def page_providers(self) -> list[str]:
        """Get all distinct providers for pages (async)."""
        return await self.distinct_values("page", "providers")

    async def layout_providers(self) -> list[str]:
        """Get all distinct layout providers (async)."""
        return await self.distinct_values("layout", "provider")

    async def layout_tags(self) -> list[str]:
        """Get all distinct tags for layouts (async)."""
        return await self.distinct_values("layout", "tags")

    async def block_tags(self) -> list[str]:
        """Get all distinct tags for blocks (async)."""
        return await self.distinct_values("block", "tags")

    async def block_versions(self) -> list[str]:
        """Get all distinct versions for blocks (async)."""
        return await self.distinct_values("block", "versions")

    async def content_versions(self) -> list[str]:
        """Get all distinct content versions (async)."""
        return await self.distinct_values("content", "version")

    async def content_tags(self) -> list[str]:
        """Get all distinct tags for contents (async)."""
        return await self.distinct_values("content", "tags")

    async def find_docs(
        self,
        query: dict | list[dict] | None = None,
        skip: int | None = None,
        limit: int | None = None,
    ) -> AsyncIterable[Doc]:
        """List docs by filters (async)."""
        query = query or {}
        async for elem in self.find("doc", query, skip=skip, limit=limit):
            assert isinstance(elem, Doc)
            yield elem

    async def find_pages(
        self,
        query: dict | list[dict] | None = None,
        doc_id: str | None = None,
        skip: int | None = None,
        limit: int | None = None,
    ) -> AsyncIterable[Page]:
        """List pages by filters (async)."""
        query = query or {}
        if doc_id is not None:
            if not isinstance(query, dict):
                raise ValueError("doc_id filter cannot be used with pipeline query.")
            query["doc_id"] = doc_id
        async for elem in self.find("page", query, skip=skip, limit=limit):
            assert isinstance(elem, Page)
            yield elem

    async def find_layouts(
        self,
        query: dict | list[dict] | None = None,
        page_id: str | None = None,
        skip: int | None = None,
        limit: int | None = None,
    ) -> AsyncIterable[Layout]:
        """List layouts by filters (async)."""
        query = query or {}
        if page_id is not None:
            if not isinstance(query, dict):
                raise ValueError("page_id filter cannot be used with pipeline query.")
            query["page_id"] = page_id
        async for elem in self.find("layout", query, skip=skip, limit=limit):
            assert isinstance(elem, Layout)
            yield elem

    async def find_blocks(
        self,
        query: dict | list[dict] | None = None,
        page_id: str | None = None,
        skip: int | None = None,
        limit: int | None = None,
    ) -> AsyncIterable[Block]:
        """List blocks by filters (async)."""
        query = query or {}
        if page_id is not None:
            if not isinstance(query, dict):
                raise ValueError("page_id filter cannot be used with pipeline query.")
            query["page_id"] = page_id
        async for elem in self.find("block", query, skip=skip, limit=limit):
            assert isinstance(elem, Block)
            yield elem

    async def find_contents(
        self,
        query: dict | list[dict] | None = None,
        page_id: str | None = None,
        block_id: str | None = None,
        skip: int | None = None,
        limit: int | None = None,
    ) -> AsyncIterable[Content]:
        """List contents by filters (async)."""
        query = query or {}
        if page_id is not None:
            if not isinstance(query, dict):
                raise ValueError("page_id filter cannot be used with pipeline query.")
            query["page_id"] = page_id
        if block_id is not None:
            if not isinstance(query, dict):
                raise ValueError("block_id filter cannot be used with pipeline query.")
            query["block_id"] = block_id
        async for elem in self.find("content", query, skip=skip, limit=limit):
            assert isinstance(elem, Content)
            yield elem

    async def find_values(
        self,
        query: dict | list[dict] | None = None,
        elem_id: str | None = None,
        key: str | None = None,
        skip: int | None = None,
        limit: int | None = None,
    ) -> AsyncIterable[Value]:
        """List values by filters (async)."""
        query = query or {}
        if elem_id is not None:
            if not isinstance(query, dict):
                raise ValueError("elem_id filter cannot be used with pipeline query.")
            query["elem_id"] = elem_id
        if key is not None:
            if not isinstance(query, dict):
                raise ValueError("key filter cannot be used with pipeline query.")
            query["key"] = key
        async for elem in self.find("value", query, skip=skip, limit=limit):
            assert isinstance(elem, Value)
            yield elem

    async def insert_local_doc(self, local_pdf_path: str) -> Doc:
        """Insert a local PDF file as a doc (async)."""
        s3_pdf_path = await self.upload_local_file("doc", local_pdf_path)
        try:
            return await self.insert_doc(DocInput(pdf_path=s3_pdf_path))
        except DocExistsError as e:
            if e.pdf_hash:
                return await self.get_doc_by_pdf_hash(e.pdf_hash)
            return await self.get_doc_by_pdf_path(e.pdf_path)

    async def insert_local_page(self, local_image_path: str) -> Page:
        """Insert a local image file as a page (async)."""
        s3_image_path = await self.upload_local_file("page", local_image_path)
        try:
            return await self.insert_page(PageInput(image_path=s3_image_path))
        except PageExistsError as e:
            if e.image_hash:
                return await self.get_page_by_image_hash(e.image_hash)
            return await self.get_page_by_image_path(e.image_path)

    async def insert_local_block(self, type: str, local_image_path: str) -> Block:
        """Insert a local image file as a standalone block (async)."""
        s3_image_path = await self.upload_local_file("block", local_image_path)
        try:
            return await self.insert_standalone_block(StandaloneBlockInput(type=type, image_path=s3_image_path))
        except ElementExistsError:
            return await self.get_block_by_image_path(s3_image_path)
