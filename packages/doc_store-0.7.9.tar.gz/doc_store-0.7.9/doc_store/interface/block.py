import asyncio
import io
from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, AsyncIterable, Iterable, Literal

from PIL import Image

from ..s3 import head_s3_object, put_s3_object
from .base import InputModel
from .elem import DocElement
from .error import ElementNotFoundError
from .io import ImageInfo

if TYPE_CHECKING:
    from .content import Content, ContentInput
    from .page import Page


class BlockInput(InputModel):
    type: str
    bbox: list[float]
    angle: Literal[0, 90, 180, 270] | None = None
    score: float | None = None
    tags: list[str] | None = None


class StandaloneBlockInput(InputModel):
    type: str
    image_path: str
    image_info: ImageInfo | None = None
    tags: list[str] | None = None


def _crop_image(
    image: Image.Image,
    bbox: list[float],
    angle: Literal[0, 90, 180, 270] | None,
) -> Image.Image:
    """Crop block area from page image (pure computation)."""
    x1, y1, x2, y2 = bbox
    x1 = round(x1 * image.width)
    y1 = round(y1 * image.height)
    x2 = round(x2 * image.width)
    y2 = round(y2 * image.height)

    # Ensure crop area has at least 1 pixel in each dimension
    if x1 == x2:
        x1, x2 = (x1, x2 + 1) if x2 < image.width else (x1 - 1, x2)
    if y1 == y2:
        y1, y2 = (y1, y2 + 1) if y2 < image.height else (y1 - 1, y2)

    image = image.crop((x1, y1, x2, y2))
    if angle:
        image = image.rotate(angle, expand=True)
    return image


def _image_to_bytes(image: Image.Image) -> bytes:
    """Convert image to bytes (pure computation)."""
    with io.BytesIO() as output:
        image.save(output, format="PNG")
        return output.getvalue()


class Block(DocElement):
    """Block of a page, representing a specific area with a type."""

    layout_id: str | None = None
    provider: str | None = None

    page_id: str | None
    type: str
    bbox: list[float]  # [0, 0, 1, 1] for full page
    angle: Literal[None, 0, 90, 180, 270] = None
    score: float | None = None

    image_path: str | None = None
    image_filesize: int | None = None
    image_hash: str | None = None
    image_width: int | None = None
    image_height: int | None = None

    versions: list[str] = []

    @property
    def page(self) -> "Page | None":
        """Get the page associated with the block."""
        if self.page_id is None:
            return None
        return self.store.get_page(self.page_id)

    @property
    def image(self) -> Image.Image:
        """Get the image of the block."""
        if self.image_path is not None:
            return self.store.read_image(self.image_path)

        page = self.page
        if page is None:
            raise ValueError("Block does not have a page or image_path.")
        return _crop_image(page.image, self.bbox, self.angle)

    @property
    def image_bytes(self) -> bytes:
        """Get the image bytes of the block."""
        if self.image_path is not None:
            return self.store.read_file(self.image_path)
        return _image_to_bytes(self.image)

    @property
    def image_pub_link(self) -> str:
        """Get the public link of the block image."""

        image_ext = "png"  # default to png
        if self.image_path is not None:
            image_ext = self.image_path.split(".")[-1].lower()

        if image_ext in ["jpg", "jpeg"]:
            mime_type = "image/jpeg"
        elif image_ext in ["png"]:
            mime_type = "image/png"
        elif image_ext in ["webp"]:
            mime_type = "image/webp"
        else:
            raise ValueError(f"Unsupported image format: {image_ext}.")

        pub_path = f"ddp-blocks/{self.id}.{image_ext}"
        pub_s3_path = f"s3://pub-link/{pub_path}"
        pub_link_url = f"https://pub-link.shlab.tech/{pub_path}"

        s3_client = self.store.get_s3_client(pub_s3_path)
        if not head_s3_object(pub_s3_path, client=s3_client):
            put_s3_object(pub_s3_path, self.image_bytes, client=s3_client, ContentType=mime_type)
        return pub_link_url

    def try_get_content(self, version: str) -> "Content | None":
        """Try to get the content of the block by version."""
        return self.store.try_get_content_by_block_id_and_version(self.id, version)

    def get_content(self, version: str) -> "Content":
        """Get the content of the block by version."""
        return self.store.get_content_by_block_id_and_version(self.id, version)

    def find_contents(
        self,
        query: dict | None = None,
        skip: int | None = None,
        limit: int | None = None,
    ) -> Iterable["Content"]:
        """List contents of the block by filters."""
        return self.store.find_contents(
            query=query,
            block_id=self.id,
            skip=skip,
            limit=limit,
        )

    def insert_content(self, version: str, content_input: "ContentInput", upsert=False) -> "Content":
        """Insert content for the block, return the inserted content."""
        return self.store.insert_content(self.id, version, content_input, upsert)

    def upsert_content(self, version: str, content_input: "ContentInput") -> "Content":
        """Upsert content for the block, return the inserted or updated content."""
        return self.store.upsert_content(self.id, version, content_input)

    # ========== Async Methods ==========

    async def aio_page(self) -> "Page | None":
        """Get the page associated with the block (async)."""
        if self.page_id is None:
            return None
        return await self.aio_store.get_page(self.page_id)

    async def aio_image(self) -> Image.Image:
        """Get the image of the block (async)."""
        if self.image_path is not None:
            return await self.aio_store.read_image(self.image_path)
        page = await self.aio_page()
        if page is None:
            raise ValueError("Block does not have a page or image_path.")
        page_image = await self.aio_store.read_image(page.image_path)
        image = await asyncio.to_thread(_crop_image, page_image, self.bbox, self.angle)
        return image

    async def aio_image_bytes(self) -> bytes:
        """Get the image bytes of the block (async)."""
        if self.image_path is not None:
            return await self.aio_store.read_file(self.image_path)
        image = await self.aio_image()
        image_bytes = await asyncio.to_thread(_image_to_bytes, image)
        return image_bytes

    async def aio_try_get_content(self, version: str) -> "Content | None":
        """Try to get the content of the block by version (async)."""
        return await self.aio_store.try_get_content_by_block_id_and_version(self.id, version)

    async def aio_get_content(self, version: str) -> "Content":
        """Get the content of the block by version (async)."""
        return await self.aio_store.get_content_by_block_id_and_version(self.id, version)

    async def aio_find_contents(
        self,
        query: dict | None = None,
        skip: int | None = None,
        limit: int | None = None,
    ) -> AsyncIterable["Content"]:
        """List contents of the block by filters (async)."""
        async for content in self.aio_store.find_contents(
            query=query,
            block_id=self.id,
            skip=skip,
            limit=limit,
        ):
            yield content

    async def aio_insert_content(self, version: str, content_input: "ContentInput", upsert=False) -> "Content":
        """Insert content for the block (async)."""
        return await self.aio_store.insert_content(self.id, version, content_input, upsert)

    async def aio_upsert_content(self, version: str, content_input: "ContentInput") -> "Content":
        """Upsert content for the block (async)."""
        return await self.aio_store.upsert_content(self.id, version, content_input)


class BlockABC(ABC):
    """Abstract class for block operations."""

    @abstractmethod
    def get_block(self, block_id: str) -> Block:
        """Get a block by its ID."""
        raise NotImplementedError()

    @abstractmethod
    def get_block_by_image_path(self, image_path: str) -> Block:
        """Get a block by its image path."""
        raise NotImplementedError()

    @abstractmethod
    def get_super_block(self, page_id: str) -> Block:
        """Get the super block for a page."""
        raise NotImplementedError()

    @abstractmethod
    def insert_block(self, page_id: str, block_input: BlockInput) -> Block:
        """Insert a new block for a page."""
        raise NotImplementedError()

    @abstractmethod
    def insert_blocks(self, page_id: str, blocks: list[BlockInput]) -> list[Block]:
        """Insert multiple blocks for a page."""
        raise NotImplementedError()

    @abstractmethod
    def insert_standalone_block(self, block_input: StandaloneBlockInput) -> Block:
        """Insert a new standalone block (without page)."""
        raise NotImplementedError()

    def try_get_block(self, block_id: str) -> Block | None:
        """Try to get a block by its ID, return None if not found."""
        try:
            return self.get_block(block_id)
        except ElementNotFoundError:
            return None

    def try_get_block_by_image_path(self, image_path: str) -> Block | None:
        """Try to get a block by its image path, return None if not found."""
        try:
            return self.get_block_by_image_path(image_path)
        except ElementNotFoundError:
            return None


class AioBlockABC(ABC):
    """Async abstract class for block operations."""

    @abstractmethod
    async def get_block(self, block_id: str) -> Block:
        """Get a block by its ID (async)."""
        raise NotImplementedError()

    @abstractmethod
    async def get_block_by_image_path(self, image_path: str) -> Block:
        """Get a block by its image path (async)."""
        raise NotImplementedError()

    @abstractmethod
    async def get_super_block(self, page_id: str) -> Block:
        """Get the super block for a page (async)."""
        raise NotImplementedError()

    @abstractmethod
    async def insert_block(self, page_id: str, block_input: BlockInput) -> Block:
        """Insert a new block for a page (async)."""
        raise NotImplementedError()

    @abstractmethod
    async def insert_blocks(self, page_id: str, blocks: list[BlockInput]) -> list[Block]:
        """Insert multiple blocks for a page (async)."""
        raise NotImplementedError()

    @abstractmethod
    async def insert_standalone_block(self, block_input: StandaloneBlockInput) -> Block:
        """Insert a new standalone block (without page) (async)."""
        raise NotImplementedError()

    async def try_get_block(self, block_id: str) -> Block | None:
        """Try to get a block by its ID, return None if not found (async)."""
        try:
            return await self.get_block(block_id)
        except ElementNotFoundError:
            return None

    async def try_get_block_by_image_path(self, image_path: str) -> Block | None:
        """Try to get a block by its image path, return None if not found (async)."""
        try:
            return await self.get_block_by_image_path(image_path)
        except ElementNotFoundError:
            return None
