from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, Any, AsyncIterable, Iterable

from ..utils import decode_ndarray
from .base import Element, InputModel
from .error import ElementNotFoundError

if TYPE_CHECKING:
    from .elem import DocElement

ValueValueType = Any


class ValueInput(InputModel):
    value: Any
    type: str | None = None


class Value(Element):
    elem_id: str
    key: str
    type: str
    value: Any

    @property
    def elem(self) -> "DocElement":
        """Get the element associated with this value."""
        return self.store.get(self.elem_id)

    def decode(self) -> "Value":
        """Decode the value if it is encoded."""
        if self.type == "ndarray" and isinstance(self.value, str):
            self.value = decode_ndarray(self.value)
        return self

    # ========== Async Methods ==========

    async def aio_elem(self) -> "DocElement":
        """Get the element associated with this value (async)."""
        return await self.aio_store.get(self.elem_id)


class ElementWithValue(Element):
    """Base class for all elements with values."""

    def try_get_value(self, key: str) -> Value | None:
        """Try to get a value by key."""
        return self.store.try_get_value_by_elem_id_and_key(self.id, key)

    def get_value(self, key: str) -> Value:
        """Get a value by key."""
        return self.store.get_value_by_elem_id_and_key(self.id, key)

    def find_values(
        self,
        query: dict | None = None,
        skip: int | None = None,
        limit: int | None = None,
    ) -> Iterable[Value]:
        """Find all values of the element."""
        return self.store.find_values(
            query=query,
            elem_id=self.id,
            skip=skip,
            limit=limit,
        )

    def insert_value(self, key: str, value_input: ValueInput) -> Value:
        """Insert a value for the element."""
        return self.store.insert_value(self.id, key, value_input)

    # ========== Async Methods ==========

    async def aio_try_get_value(self, key: str) -> Value | None:
        """Try to get a value by key (async)."""
        return await self.aio_store.try_get_value_by_elem_id_and_key(self.id, key)

    async def aio_get_value(self, key: str) -> Value:
        """Get a value by key (async)."""
        return await self.aio_store.get_value_by_elem_id_and_key(self.id, key)

    async def aio_find_values(
        self,
        query: dict | None = None,
        skip: int | None = None,
        limit: int | None = None,
    ) -> AsyncIterable[Value]:
        """Find all values of the element (async)."""
        async for value in self.aio_store.find_values(
            query=query,
            elem_id=self.id,
            skip=skip,
            limit=limit,
        ):
            yield value

    async def aio_insert_value(self, key: str, value_input: ValueInput) -> Value:
        """Insert a value for the element (async)."""
        return await self.aio_store.insert_value(self.id, key, value_input)


class ValueABC(ABC):
    """Abstract class for value operations."""

    @abstractmethod
    def get_value(self, value_id: str) -> Value:
        """Get a value by its ID."""
        raise NotImplementedError()

    @abstractmethod
    def get_value_by_elem_id_and_key(self, elem_id: str, key: str) -> Value:
        """Get a value by its elem_id and key."""
        raise NotImplementedError()

    @abstractmethod
    def insert_value(self, elem_id: str, key: str, value_input: ValueInput) -> Value:
        """Insert a new value for a element."""
        raise NotImplementedError()

    def try_get_value(self, value_id: str) -> Value | None:
        """Try to get a value by its ID, return None if not found."""
        try:
            return self.get_value(value_id)
        except ElementNotFoundError:
            return None

    def try_get_value_by_elem_id_and_key(self, elem_id: str, key: str) -> Value | None:
        """Try to get a value by its elem_id and key, return None if not found."""
        try:
            return self.get_value_by_elem_id_and_key(elem_id, key)
        except ElementNotFoundError:
            return None


class AioValueABC(ABC):
    """Async abstract class for value operations."""

    @abstractmethod
    async def get_value(self, value_id: str) -> Value:
        """Get a value by its ID (async)."""
        raise NotImplementedError()

    @abstractmethod
    async def get_value_by_elem_id_and_key(self, elem_id: str, key: str) -> Value:
        """Get a value by its elem_id and key (async)."""
        raise NotImplementedError()

    @abstractmethod
    async def insert_value(self, elem_id: str, key: str, value_input: ValueInput) -> Value:
        """Insert a new value for a element (async)."""
        raise NotImplementedError()

    async def try_get_value(self, value_id: str) -> Value | None:
        """Try to get a value by its ID, return None if not found (async)."""
        try:
            return await self.get_value(value_id)
        except ElementNotFoundError:
            return None

    async def try_get_value_by_elem_id_and_key(self, elem_id: str, key: str) -> Value | None:
        """Try to get a value by its elem_id and key, return None if not found (async)."""
        try:
            return await self.get_value_by_elem_id_and_key(elem_id, key)
        except ElementNotFoundError:
            return None
