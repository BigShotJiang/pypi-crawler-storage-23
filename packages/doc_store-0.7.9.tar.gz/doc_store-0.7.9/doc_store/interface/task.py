from abc import ABC, abstractmethod
from typing import Any, Literal

from pydantic import BaseModel

from .base import Element, InputModel
from .error import ElementNotFoundError


class TaskInput(InputModel):
    command: str
    args: dict[str, Any] | None = None
    priority: int = 0
    batch_id: str | None = None


class TaskStats(InputModel):
    counts: dict[Literal["done", "error", "skipped"], int]


class Task(Element):
    target: str
    batch_id: str
    command: str
    args: dict[str, Any]
    priority: int
    status: str
    create_user: str
    update_user: str | None = None
    error_message: str | None = None


class TaskCount(BaseModel):
    command: str
    priority: int
    total: int
    pending: int
    running: int
    completed: int
    # failed: int


class ElementWithTask(Element):
    """Base class for all elements with tasks."""

    def list_tasks(
        self,
        query: dict | None = None,
        batch_id: str | None = None,
        command: str | None = None,
        status: str | None = None,
        create_user: str | None = None,
        skip: int | None = None,
        limit: int | None = None,
    ) -> list[Task]:
        """List tasks of the element by filters."""
        return self.store.list_tasks(
            query=query,
            target=self.id,
            batch_id=batch_id,
            command=command,
            status=status,
            create_user=create_user,
            skip=skip,
            limit=limit,
        )

    def insert_task(self, task_input: TaskInput) -> Task:
        """Insert a task for the element."""
        return self.store.insert_task(self.id, task_input)

    # ========== Async Methods ==========

    async def aio_list_tasks(
        self,
        query: dict | None = None,
        batch_id: str | None = None,
        command: str | None = None,
        status: str | None = None,
        create_user: str | None = None,
        skip: int | None = None,
        limit: int | None = None,
    ) -> list[Task]:
        """List tasks of the element by filters (async)."""
        return await self.aio_store.list_tasks(
            query=query,
            target=self.id,
            batch_id=batch_id,
            command=command,
            status=status,
            create_user=create_user,
            skip=skip,
            limit=limit,
        )

    async def aio_insert_task(self, task_input: TaskInput) -> Task:
        """Insert a task for the element (async)."""
        return await self.aio_store.insert_task(self.id, task_input)


class TaskABC(ABC):
    """Abstract class for task operations."""

    @abstractmethod
    def list_tasks(
        self,
        query: dict | None = None,
        target: str | None = None,
        batch_id: str | None = None,
        command: str | None = None,
        status: str | None = None,
        create_user: str | None = None,
        skip: int | None = None,
        limit: int | None = None,
    ) -> list[Task]:
        """List tasks by filters."""
        raise NotImplementedError()

    @abstractmethod
    def get_task(self, task_id: str) -> Task:
        """Get a task by its ID."""
        raise NotImplementedError()

    @abstractmethod
    def insert_task(self, target_id: str, task_input: TaskInput) -> Task:
        """Insert a new task into the database."""
        raise NotImplementedError()

    @abstractmethod
    def grab_new_tasks(self, command: str, num=10, hold_sec=3600) -> list[Task]:
        """Grab new tasks for processing."""
        raise NotImplementedError()

    @abstractmethod
    def update_task(
        self,
        task_id: str,
        command: str,
        status: Literal["done", "error", "skipped"],
        error_message: str | None = None,
        check_mismatch: bool = False,
        task: Task | None = None,
    ) -> None:
        """Update a task after processing."""
        raise NotImplementedError()

    @abstractmethod
    def count_tasks(self, command: str | None = None) -> list[TaskCount]:
        """Count tasks grouped by priority and status."""
        raise NotImplementedError()

    def write_task_stats(self, command: str) -> None:
        pass

    def try_get_task(self, task_id: str) -> Task | None:
        """Try to get a task by its ID, return None if not found."""
        try:
            return self.get_task(task_id)
        except ElementNotFoundError:
            return None

    def grab_new_task(self, command: str, hold_sec=3600) -> Task | None:
        """Grab a new task for processing."""
        grabbed_tasks = self.grab_new_tasks(command=command, num=1, hold_sec=hold_sec)
        return grabbed_tasks[0] if grabbed_tasks else None

    def update_grabbed_task(
        self,
        task: Task,
        status: Literal["done", "error", "skipped"],
        error_message: str | None = None,
    ) -> None:
        """Update a task after processing."""
        send_task = (status == "error") or bool(task.batch_id)
        return self.update_task(
            task_id=task.id,
            command=task.command,
            status=status,
            error_message=error_message,
            task=task if send_task else None,
        )


class AioTaskABC(ABC):
    """Async abstract class for task operations."""

    @abstractmethod
    async def list_tasks(
        self,
        query: dict | None = None,
        target: str | None = None,
        batch_id: str | None = None,
        command: str | None = None,
        status: str | None = None,
        create_user: str | None = None,
        skip: int | None = None,
        limit: int | None = None,
    ) -> list[Task]:
        """List tasks by filters (async)."""
        raise NotImplementedError()

    @abstractmethod
    async def get_task(self, task_id: str) -> Task:
        """Get a task by its ID (async)."""
        raise NotImplementedError()

    @abstractmethod
    async def insert_task(self, target_id: str, task_input: TaskInput) -> Task:
        """Insert a new task into the database (async)."""
        raise NotImplementedError()

    @abstractmethod
    async def grab_new_tasks(self, command: str, num: int = 10, hold_sec: int = 3600) -> list[Task]:
        """Grab new tasks for processing (async)."""
        raise NotImplementedError()

    @abstractmethod
    async def update_task(
        self,
        task_id: str,
        command: str,
        status: Literal["done", "error", "skipped"],
        error_message: str | None = None,
        check_mismatch: bool = False,
        task: Task | None = None,
    ) -> None:
        """Update a task after processing (async)."""
        raise NotImplementedError()

    @abstractmethod
    async def count_tasks(self, command: str | None = None) -> list[TaskCount]:
        """Count tasks grouped by priority and status (async)."""
        raise NotImplementedError()

    async def try_get_task(self, task_id: str) -> Task | None:
        """Try to get a task by its ID, return None if not found (async)."""
        try:
            return await self.get_task(task_id)
        except ElementNotFoundError:
            return None

    async def grab_new_task(self, command: str, hold_sec: int = 3600) -> Task | None:
        """Grab a new task for processing (async)."""
        grabbed_tasks = await self.grab_new_tasks(command=command, num=1, hold_sec=hold_sec)
        return grabbed_tasks[0] if grabbed_tasks else None

    async def update_grabbed_task(
        self,
        task: Task,
        status: Literal["done", "error", "skipped"],
        error_message: str | None = None,
    ) -> None:
        """Update a task after processing (async)."""
        send_task = (status == "error") or bool(task.batch_id)
        return await self.update_task(
            task_id=task.id,
            command=task.command,
            status=status,
            error_message=error_message,
            task=task if send_task else None,
        )
