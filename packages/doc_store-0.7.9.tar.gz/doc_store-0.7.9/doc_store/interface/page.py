from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, AsyncIterable, Iterable

from PIL import Image

from ..s3 import get_s3_presigned_url, head_s3_object, put_s3_object
from .base import InputModel
from .elem import DocElement
from .error import ElementNotFoundError
from .io import ImageInfo

if TYPE_CHECKING:
    from .block import Block, BlockInput
    from .content import Content
    from .doc import Doc
    from .layout import ContentBlockInput, Layout, LayoutInput


class PageInput(InputModel):
    image_path: str
    image_dpi: int | None = None
    image_info: ImageInfo | None = None
    doc_id: str | None = None
    page_idx: int | None = None
    tags: list[str] | None = None


class Page(DocElement):
    """Page of a doc."""

    doc_id: str | None = None
    page_idx: int | None = None
    image_path: str
    image_filesize: int
    image_hash: str
    image_width: int
    image_height: int
    image_dpi: int | None = None

    providers: list[str] = []

    # image_path before moving to S3
    old_image_path: str | None = None

    @property
    def image_bytes(self) -> bytes:
        """Get the image bytes of the page."""
        return self.store.read_file(self.image_path)

    @property
    def image(self) -> Image.Image:
        """Get the image of the page."""
        return self.store.read_image(self.image_path)

    @property
    def image_presigned_link(self) -> str:
        """Get the presigned link of the page image."""
        image_ext = self.image_path.split(".")[-1].lower()
        if image_ext in ["jpg", "jpeg"]:
            mime_type = "image/jpeg"
        elif image_ext in ["png"]:
            mime_type = "image/png"
        elif image_ext in ["webp"]:
            mime_type = "image/webp"
        else:
            raise ValueError(f"Unsupported image format: {image_ext}.")
        s3_client = self.store.get_s3_client(self.image_path)
        return get_s3_presigned_url(self.image_path, expires_in=86400, content_type=mime_type, client=s3_client)

    @property
    def image_pub_link(self) -> str:
        """Get the public link of the page image."""
        image_ext = self.image_path.split(".")[-1].lower()
        if image_ext in ["jpg", "jpeg"]:
            mime_type = "image/jpeg"
        elif image_ext in ["png"]:
            mime_type = "image/png"
        elif image_ext in ["webp"]:
            mime_type = "image/webp"
        else:
            raise ValueError(f"Unsupported image format: {image_ext}.")

        pub_path = f"ddp-pages/{self.id}.{image_ext}"
        pub_s3_path = f"s3://pub-link/{pub_path}"
        pub_link_url = f"https://pub-link.shlab.tech/{pub_path}"

        s3_client = self.store.get_s3_client(pub_s3_path)
        if not head_s3_object(pub_s3_path, client=s3_client):
            put_s3_object(pub_s3_path, self.image_bytes, client=s3_client, ContentType=mime_type)
        return pub_link_url

    @property
    def super_block(self) -> "Block":
        """Get the super block of the page."""
        return self.store.get_super_block(self.id)

    @property
    def doc(self) -> "Doc | None":
        """Get the doc associated with the page."""
        return self.store.get_doc(self.doc_id) if self.doc_id else None

    def try_get_layout(self, provider: str, expand: bool = False) -> "Layout | None":
        """Try to get the layout of the page by provider."""
        return self.store.try_get_layout_by_page_id_and_provider(self.id, provider, expand)

    def get_layout(self, provider: str, expand: bool = False) -> "Layout":
        """Get the layout of the page by provider."""
        return self.store.get_layout_by_page_id_and_provider(self.id, provider, expand)

    def find_layouts(
        self,
        query: dict | None = None,
        skip: int | None = None,
        limit: int | None = None,
    ) -> Iterable["Layout"]:
        """List layouts of the page by filters."""
        return self.store.find_layouts(
            query=query,
            page_id=self.id,
            skip=skip,
            limit=limit,
        )

    def find_blocks(
        self,
        query: dict | None = None,
        skip: int | None = None,
        limit: int | None = None,
    ) -> Iterable["Block"]:
        """List blocks of the page by filters."""
        return self.store.find_blocks(
            query=query,
            page_id=self.id,
            skip=skip,
            limit=limit,
        )

    def find_contents(
        self,
        query: dict | None = None,
        skip: int | None = None,
        limit: int | None = None,
    ) -> Iterable["Content"]:
        """List contents of the page by filters."""
        return self.store.find_contents(
            query=query,
            page_id=self.id,
            skip=skip,
            limit=limit,
        )

    def insert_layout(self, provider: str, layout_input: "LayoutInput", insert_blocks=False, upsert=False) -> "Layout":
        """Insert a layout for the page, return the inserted layout."""
        return self.store.insert_layout(self.id, provider, layout_input, insert_blocks, upsert)

    def upsert_layout(self, provider: str, layout_input: "LayoutInput", insert_blocks=False) -> "Layout":
        """Upsert a layout for the page, return the inserted or updated layout."""
        return self.store.upsert_layout(self.id, provider, layout_input, insert_blocks)

    def insert_block(self, block_input: "BlockInput") -> "Block":
        """Insert a block for the page, return the inserted block."""
        return self.store.insert_block(self.id, block_input)

    def insert_blocks(self, blocks: list["BlockInput"]) -> list["Block"]:
        """Insert multiple blocks for the page, return the inserted blocks."""
        return self.store.insert_blocks(self.id, blocks)

    def insert_content_blocks_layout(
        self,
        provider: str,
        content_blocks: list["ContentBlockInput"],
        upsert: bool = False,
    ) -> "Layout":
        """Insert a layout with content blocks for the page."""
        return self.store.insert_content_blocks_layout(
            self.id,
            provider,
            content_blocks,
            upsert,
        )

    # ========== Async Methods ==========

    async def aio_image_bytes(self) -> bytes:
        """Get the image bytes of the page (async)."""
        return await self.aio_store.read_file(self.image_path)

    async def aio_image(self) -> Image.Image:
        """Get the image of the page (async)."""
        return await self.aio_store.read_image(self.image_path)

    async def aio_doc(self) -> "Doc | None":
        """Get the doc associated with the page (async)."""
        if self.doc_id is None:
            return None
        return await self.aio_store.get_doc(self.doc_id)

    async def aio_try_get_layout(self, provider: str, expand: bool = False) -> "Layout | None":
        """Try to get the layout of the page by provider (async)."""
        return await self.aio_store.try_get_layout_by_page_id_and_provider(self.id, provider, expand)

    async def aio_get_layout(self, provider: str, expand: bool = False) -> "Layout":
        """Get the layout of the page by provider (async)."""
        return await self.aio_store.get_layout_by_page_id_and_provider(self.id, provider, expand)

    async def aio_find_layouts(
        self,
        query: dict | None = None,
        skip: int | None = None,
        limit: int | None = None,
    ) -> AsyncIterable["Layout"]:
        """List layouts of the page by filters (async)."""
        async for layout in self.aio_store.find_layouts(
            query=query,
            page_id=self.id,
            skip=skip,
            limit=limit,
        ):
            yield layout

    async def aio_find_blocks(
        self,
        query: dict | None = None,
        skip: int | None = None,
        limit: int | None = None,
    ) -> AsyncIterable["Block"]:
        """List blocks of the page by filters (async)."""
        async for block in self.aio_store.find_blocks(
            query=query,
            page_id=self.id,
            skip=skip,
            limit=limit,
        ):
            yield block

    async def aio_find_contents(
        self,
        query: dict | None = None,
        skip: int | None = None,
        limit: int | None = None,
    ) -> AsyncIterable["Content"]:
        """List contents of the page by filters (async)."""
        async for content in self.aio_store.find_contents(
            query=query,
            page_id=self.id,
            skip=skip,
            limit=limit,
        ):
            yield content

    async def aio_insert_layout(
        self, provider: str, layout_input: "LayoutInput", insert_blocks=False, upsert=False
    ) -> "Layout":
        """Insert a layout for the page (async)."""
        return await self.aio_store.insert_layout(self.id, provider, layout_input, insert_blocks, upsert)

    async def aio_upsert_layout(self, provider: str, layout_input: "LayoutInput", insert_blocks=False) -> "Layout":
        """Upsert a layout for the page (async)."""
        return await self.aio_store.upsert_layout(self.id, provider, layout_input, insert_blocks)

    async def aio_insert_block(self, block_input: "BlockInput") -> "Block":
        """Insert a block for the page (async)."""
        return await self.aio_store.insert_block(self.id, block_input)

    async def aio_insert_blocks(self, blocks: list["BlockInput"]) -> list["Block"]:
        """Insert multiple blocks for the page (async)."""
        return await self.aio_store.insert_blocks(self.id, blocks)

    async def aio_insert_content_blocks_layout(
        self,
        provider: str,
        content_blocks: list["ContentBlockInput"],
        upsert: bool = False,
    ) -> "Layout":
        """Insert a layout with content blocks for the page (async)."""
        return await self.aio_store.insert_content_blocks_layout(
            self.id,
            provider,
            content_blocks,
            upsert,
        )


class PageABC(ABC):
    """Abstract class for page operations."""

    @abstractmethod
    def get_page(self, page_id: str) -> Page:
        """Get a page by its ID."""
        raise NotImplementedError()

    @abstractmethod
    def get_page_by_image_path(self, image_path: str) -> Page:
        """Get a page by its image path."""
        raise NotImplementedError()

    @abstractmethod
    def get_page_by_image_hash(self, image_hash: str) -> Page:
        """Get a page by its image hash."""
        raise NotImplementedError()

    @abstractmethod
    def insert_page(self, page_input: PageInput, skip_hash_check: bool = False) -> Page:
        """Insert a new page into the database."""
        raise NotImplementedError()

    def try_get_page(self, page_id: str) -> Page | None:
        """Try to get a page by its ID, return None if not found."""
        try:
            return self.get_page(page_id)
        except ElementNotFoundError:
            return None

    def try_get_page_by_image_path(self, image_path: str) -> Page | None:
        """Try to get a page by its image path, return None if not found."""
        try:
            return self.get_page_by_image_path(image_path)
        except ElementNotFoundError:
            return None

    def try_get_page_by_image_hash(self, image_hash: str) -> Page | None:
        """Try to get a page by its image hash, return None if not found."""
        try:
            return self.get_page_by_image_hash(image_hash)
        except ElementNotFoundError:
            return None


class AioPageABC(ABC):
    """Async abstract class for page operations."""

    @abstractmethod
    async def get_page(self, page_id: str) -> Page:
        """Get a page by its ID (async)."""
        raise NotImplementedError()

    @abstractmethod
    async def get_page_by_image_path(self, image_path: str) -> Page:
        """Get a page by its image path (async)."""
        raise NotImplementedError()

    @abstractmethod
    async def get_page_by_image_hash(self, image_hash: str) -> Page:
        """Get a page by its image hash (async)."""
        raise NotImplementedError()

    @abstractmethod
    async def insert_page(self, page_input: PageInput, skip_hash_check: bool = False) -> Page:
        """Insert a new page into the database (async)."""
        raise NotImplementedError()

    async def try_get_page(self, page_id: str) -> Page | None:
        """Try to get a page by its ID, return None if not found (async)."""
        try:
            return await self.get_page(page_id)
        except ElementNotFoundError:
            return None

    async def try_get_page_by_image_path(self, image_path: str) -> Page | None:
        """Try to get a page by its image path, return None if not found (async)."""
        try:
            return await self.get_page_by_image_path(image_path)
        except ElementNotFoundError:
            return None

    async def try_get_page_by_image_hash(self, image_hash: str) -> Page | None:
        """Try to get a page by its image hash, return None if not found (async)."""
        try:
            return await self.get_page_by_image_hash(image_hash)
        except ElementNotFoundError:
            return None
