from abc import ABC, abstractmethod
from typing import Literal

from .base import DictModel, InputModel

EmbeddableElemType = Literal["page", "block"]


EmbeddingVectorType = list[float]


class EmbeddingInput(InputModel):
    elem_id: str
    vector: EmbeddingVectorType


class EmbeddingQuery(InputModel):
    vector: EmbeddingVectorType
    k: int
    show_vector: bool = False


class Embedding(DictModel):
    elem_id: str
    model: str
    vector: EmbeddingVectorType | None
    score: float | None = None


class EmbeddingModel(DictModel):
    name: str
    display_name: str
    description: str
    dimension: int
    normalized: bool


class EmbeddingModelUpdate(InputModel):
    display_name: str
    description: str


class EmbeddingABC(ABC):
    """Abstract class for embedding model operations."""

    @abstractmethod
    def list_embedding_models(self) -> list[EmbeddingModel]:
        """List all embedding models in the system."""
        raise NotImplementedError()

    @abstractmethod
    def get_embedding_model(self, name: str) -> EmbeddingModel:
        """Get an embedding model by name."""
        raise NotImplementedError()

    @abstractmethod
    def insert_embedding_model(self, embedding_model: EmbeddingModel) -> EmbeddingModel:
        """Insert a new embedding model to the system."""
        raise NotImplementedError()

    @abstractmethod
    def update_embedding_model(self, name: str, update: EmbeddingModelUpdate) -> EmbeddingModel:
        """Update an existing embedding model in the system."""
        raise NotImplementedError()

    @abstractmethod
    def add_embeddings(self, elem_type: EmbeddableElemType, model: str, embeddings: list[EmbeddingInput]) -> None:
        """Add embeddings to elements of same elem_type."""
        raise NotImplementedError()

    @abstractmethod
    def search_embeddings(self, elem_type: EmbeddableElemType, model: str, query: EmbeddingQuery) -> list[Embedding]:
        """Search embeddings for elements of same elem_type."""
        raise NotImplementedError()


class AioEmbeddingABC(ABC):
    """Async abstract class for embedding model operations."""

    @abstractmethod
    async def list_embedding_models(self) -> list[EmbeddingModel]:
        """List all embedding models in the system (async)."""
        raise NotImplementedError()

    @abstractmethod
    async def get_embedding_model(self, name: str) -> EmbeddingModel:
        """Get an embedding model by name (async)."""
        raise NotImplementedError()

    @abstractmethod
    async def insert_embedding_model(self, embedding_model: EmbeddingModel) -> EmbeddingModel:
        """Insert a new embedding model to the system (async)."""
        raise NotImplementedError()

    @abstractmethod
    async def update_embedding_model(self, name: str, update: EmbeddingModelUpdate) -> EmbeddingModel:
        """Update an existing embedding model in the system (async)."""
        raise NotImplementedError()

    @abstractmethod
    async def add_embeddings(self, elem_type: EmbeddableElemType, model: str, embeddings: list[EmbeddingInput]) -> None:
        """Add embeddings to elements of same elem_type (async)."""
        raise NotImplementedError()

    @abstractmethod
    async def search_embeddings(self, elem_type: EmbeddableElemType, model: str, query: EmbeddingQuery) -> list[Embedding]:
        """Search embeddings for elements of same elem_type (async)."""
        raise NotImplementedError()
