import json
import logging

__logger__ = logging.getLogger(__name__)


HTTP_100_CONTINUE = 100
HTTP_101_SWITCHING_PROTOCOLS = 101
HTTP_102_PROCESSING = 102
HTTP_103_EARLY_HINTS = 103
HTTP_200_OK = 200
HTTP_201_CREATED = 201
HTTP_202_ACCEPTED = 202
HTTP_203_NON_AUTHORITATIVE_INFORMATION = 203
HTTP_204_NO_CONTENT = 204
HTTP_205_RESET_CONTENT = 205
HTTP_206_PARTIAL_CONTENT = 206
HTTP_207_MULTI_STATUS = 207
HTTP_208_ALREADY_REPORTED = 208
HTTP_226_IM_USED = 226
HTTP_300_MULTIPLE_CHOICES = 300
HTTP_301_MOVED_PERMANENTLY = 301
HTTP_302_FOUND = 302
HTTP_303_SEE_OTHER = 303
HTTP_304_NOT_MODIFIED = 304
HTTP_305_USE_PROXY = 305
HTTP_306_RESERVED = 306
HTTP_307_TEMPORARY_REDIRECT = 307
HTTP_308_PERMANENT_REDIRECT = 308
HTTP_400_BAD_REQUEST = 400
HTTP_401_UNAUTHORIZED = 401
HTTP_402_PAYMENT_REQUIRED = 402
HTTP_403_FORBIDDEN = 403
HTTP_404_NOT_FOUND = 404
HTTP_405_METHOD_NOT_ALLOWED = 405
HTTP_406_NOT_ACCEPTABLE = 406
HTTP_407_PROXY_AUTHENTICATION_REQUIRED = 407
HTTP_408_REQUEST_TIMEOUT = 408
HTTP_409_CONFLICT = 409
HTTP_410_GONE = 410
HTTP_411_LENGTH_REQUIRED = 411
HTTP_412_PRECONDITION_FAILED = 412
HTTP_413_CONTENT_TOO_LARGE = 413
HTTP_414_URI_TOO_LONG = 414
HTTP_415_UNSUPPORTED_MEDIA_TYPE = 415
HTTP_416_RANGE_NOT_SATISFIABLE = 416
HTTP_417_EXPECTATION_FAILED = 417
HTTP_418_IM_A_TEAPOT = 418
HTTP_421_MISDIRECTED_REQUEST = 421
HTTP_422_UNPROCESSABLE_CONTENT = 422
HTTP_423_LOCKED = 423
HTTP_424_FAILED_DEPENDENCY = 424
HTTP_425_TOO_EARLY = 425
HTTP_426_UPGRADE_REQUIRED = 426
HTTP_428_PRECONDITION_REQUIRED = 428
HTTP_429_TOO_MANY_REQUESTS = 429
HTTP_431_REQUEST_HEADER_FIELDS_TOO_LARGE = 431
HTTP_451_UNAVAILABLE_FOR_LEGAL_REASONS = 451
HTTP_500_INTERNAL_SERVER_ERROR = 500
HTTP_501_NOT_IMPLEMENTED = 501
HTTP_502_BAD_GATEWAY = 502
HTTP_503_SERVICE_UNAVAILABLE = 503
HTTP_504_GATEWAY_TIMEOUT = 504
HTTP_505_HTTP_VERSION_NOT_SUPPORTED = 505
HTTP_506_VARIANT_ALSO_NEGOTIATES = 506
HTTP_507_INSUFFICIENT_STORAGE = 507
HTTP_508_LOOP_DETECTED = 508
HTTP_510_NOT_EXTENDED = 510
HTTP_511_NETWORK_AUTHENTICATION_REQUIRED = 511


class UnauthorizedError(Exception):
    pass


class NotFoundError(Exception):
    pass


class ElementNotFoundError(NotFoundError):
    pass


class AlreadyExistsError(Exception):
    pass


class ElementExistsError(AlreadyExistsError):
    pass


class DocExistsError(ElementExistsError):
    def __init__(self, message: str, pdf_path: str, pdf_hash: str | None):
        super().__init__(message)
        self.pdf_path = pdf_path
        self.pdf_hash = pdf_hash


class PageExistsError(ElementExistsError):
    def __init__(self, message: str, image_path: str, image_hash: str | None) -> None:
        super().__init__(message)
        self.image_path = image_path
        self.image_hash = image_hash


class TaskMismatchError(Exception):
    pass


class ReadOnlyError(Exception):
    """Raised when attempting to write to a read-only DocStore."""

    pass


def encode_error(e: Exception, logger: logging.Logger = __logger__) -> tuple[int, dict]:
    if isinstance(e, UnauthorizedError):
        return (
            HTTP_401_UNAUTHORIZED,
            {"error": "UnauthorizedError", "message": str(e)},
        )
    if isinstance(e, ElementNotFoundError):
        return (
            HTTP_404_NOT_FOUND,
            {"error": "ElementNotFoundError", "message": str(e)},
        )
    if isinstance(e, NotFoundError):
        return (
            HTTP_404_NOT_FOUND,
            {"error": "NotFoundError", "message": str(e)},
        )
    if isinstance(e, DocExistsError):
        return (
            HTTP_409_CONFLICT,
            {"error": "DocExistsError", "message": str(e), "pdf_path": e.pdf_path, "pdf_hash": e.pdf_hash},
        )
    if isinstance(e, PageExistsError):
        return (
            HTTP_409_CONFLICT,
            {"error": "PageExistsError", "message": str(e), "image_path": e.image_path, "image_hash": e.image_hash},
        )
    if isinstance(e, ElementExistsError):
        return (
            HTTP_409_CONFLICT,
            {"error": "ElementExistsError", "message": str(e)},
        )
    if isinstance(e, AlreadyExistsError):
        return (
            HTTP_409_CONFLICT,
            {"error": "AlreadyExistsError", "message": str(e)},
        )
    if isinstance(e, TaskMismatchError):
        return (
            HTTP_400_BAD_REQUEST,
            {"error": "TaskMismatchError", "message": str(e)},
        )
    if isinstance(e, ReadOnlyError):
        return (
            HTTP_403_FORBIDDEN,
            {"error": "ReadOnlyError", "message": str(e)},
        )
    if isinstance(e, PermissionError):
        return (
            HTTP_403_FORBIDDEN,
            {"error": "PermissionError", "message": str(e)},
        )
    if isinstance(e, ValueError):
        logger.error("Unhandled exception occurred", exc_info=e)
        return (
            HTTP_400_BAD_REQUEST,
            {"error": "ValueError", "message": str(e)},
        )
    logger.error("Unhandled exception occurred", exc_info=e)
    return (
        HTTP_500_INTERNAL_SERVER_ERROR,
        {"error": "InternalServerError", "message": str(e)},
    )


def decode_error(status_code: int, response_text: str) -> Exception:
    if status_code == HTTP_422_UNPROCESSABLE_CONTENT:
        return ValueError(f"Validation error: {response_text}")

    try:
        error_info = json.loads(response_text)
    except json.JSONDecodeError:
        return Exception(f"Status: {status_code}, response text: {response_text}")
    if not isinstance(error_info, dict):
        return Exception(f"Status: {status_code}, response text: {response_text}")

    error = error_info.get("error")
    message = error_info.get("message", "") or response_text

    if status_code == HTTP_401_UNAUTHORIZED:
        return UnauthorizedError(message)
    if status_code == HTTP_403_FORBIDDEN:
        if error == "ReadOnlyError":
            return ReadOnlyError(message)
        return PermissionError(message)
    if status_code == HTTP_404_NOT_FOUND:
        if error == "ElementNotFoundError":
            return ElementNotFoundError(message)
        # if error == "NotFoundError"
        return NotFoundError(message)
    if status_code == HTTP_409_CONFLICT:
        if error == "DocExistsError":
            pdf_path = error_info.get("pdf_path", "")
            pdf_hash = error_info.get("pdf_hash", None)
            return DocExistsError(message, pdf_path, pdf_hash)
        if error == "PageExistsError":
            image_path = error_info.get("image_path", "")
            image_hash = error_info.get("image_hash", None)
            return PageExistsError(message, image_path, image_hash)
        if error == "ElementExistsError":
            return ElementExistsError(message)
        # if error == "AlreadyExistsError"
        return AlreadyExistsError(message)
    if status_code == HTTP_400_BAD_REQUEST:
        if error == "TaskMismatchError":
            return TaskMismatchError(message)
        # if error == "ValueError"
        return ValueError(message)
    return Exception(f"Status: {status_code}, response text: {response_text}")
