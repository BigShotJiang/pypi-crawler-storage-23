from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, Any, AsyncIterable, Iterable, Literal

from pydantic import BaseModel

if TYPE_CHECKING:
    from .interface import AioDocStoreInterface, DocStoreInterface

ElemTypeNames = ("doc", "page", "layout", "block", "content", "value")
ElemType = Literal["doc", "page", "layout", "block", "content", "value"]


class InputModel(BaseModel):
    """Base class for input models."""

    pass


class DictModel(BaseModel):
    """Base class for dictionary-like models."""

    def keys(self):
        return self.__dict__.keys()

    def values(self):
        return self.__dict__.values()

    def items(self):
        return self.__dict__.items()

    def get(self, key: str, default: Any | None = None):
        return self.__dict__.get(key, default)

    def __len__(self) -> int:
        return len(self.__dict__)

    def __getitem__(self, key: str) -> Any:
        return getattr(self, key)

    def __setitem__(self, key: str, value: Any) -> None:
        setattr(self, key, value)


class Element(DictModel):
    """Base class for all store elements."""

    id: str
    rid: int
    create_time: int | None = None
    update_time: int | None = None
    _store: "DocStoreInterface | None" = None
    _aio_store: "AioDocStoreInterface | None" = None

    def __getstate__(self) -> dict:
        state = super().__getstate__()
        state["__pydantic_private__"]["_store"] = None
        state["__pydantic_private__"]["_aio_store"] = None
        return state

    @property
    def store(self) -> "DocStoreInterface":
        """Get the sync store associated with this element."""
        if not self._store:
            raise ValueError("Element does not have a sync store.")
        return self._store

    @store.setter
    def store(self, store: "DocStoreInterface") -> None:
        """Set the sync store for this element."""
        from .interface import DocStoreInterface

        if not isinstance(store, DocStoreInterface):
            raise TypeError("store must be an instance of DocStoreInterface.")
        self._store = store

    @property
    def aio_store(self) -> "AioDocStoreInterface":
        """Get the async store associated with this element."""
        if not self._aio_store:
            raise ValueError("Element does not have an async store. Use sync methods instead.")
        return self._aio_store

    @aio_store.setter
    def aio_store(self, aio_store: "AioDocStoreInterface") -> None:
        """Set the async store for this element."""
        from .interface import AioDocStoreInterface

        if not isinstance(aio_store, AioDocStoreInterface):
            raise TypeError("aio_store must be an instance of AioDocStoreInterface.")
        self._aio_store = aio_store


class BaseABC(ABC):
    """Base abstract class for common operations."""

    @abstractmethod
    def health_check(self, show_stats: bool = False) -> dict:
        """Check the health of the doc store."""
        raise NotImplementedError()

    @abstractmethod
    def find(
        self,
        elem_type: ElemType,
        query: dict | list[dict] | None = None,
        query_from: ElemType | None = None,
        skip: int | None = None,
        limit: int | None = None,
    ) -> Iterable[Element]:
        """Find elements of a specific type matching the query."""
        raise NotImplementedError()

    @abstractmethod
    def count(
        self,
        elem_type: ElemType,
        query: dict | list[dict] | None = None,
        query_from: ElemType | None = None,
        estimated: bool = False,
    ) -> int:
        """Count elements of a specific type matching the query."""
        raise NotImplementedError()

    @abstractmethod
    def distinct_values(
        self,
        elem_type: ElemType,
        field: Literal["tags", "providers", "provider", "versions", "version"],
        query: dict | None = None,
    ) -> list[str]:
        """Get all distinct values for a specific field of an element type."""
        raise NotImplementedError()


class AioBaseABC(ABC):
    """Async base abstract class for common operations."""

    @abstractmethod
    async def health_check(self, show_stats: bool = False) -> dict:
        """Check the health of the doc store (async)."""
        raise NotImplementedError()

    @abstractmethod
    async def find(
        self,
        elem_type: ElemType,
        query: dict | list[dict] | None = None,
        query_from: ElemType | None = None,
        skip: int | None = None,
        limit: int | None = None,
    ) -> AsyncIterable[Element]:
        """Find elements of a specific type matching the query (async)."""
        raise NotImplementedError()
        yield  # type: ignore

    @abstractmethod
    async def count(
        self,
        elem_type: ElemType,
        query: dict | list[dict] | None = None,
        query_from: ElemType | None = None,
        estimated: bool = False,
    ) -> int:
        """Count elements of a specific type matching the query (async)."""
        raise NotImplementedError()

    @abstractmethod
    async def distinct_values(
        self,
        elem_type: ElemType,
        field: Literal["tags", "providers", "provider", "versions", "version"],
        query: dict | None = None,
    ) -> list[str]:
        """Get all distinct values for a specific field of an element type (async)."""
        raise NotImplementedError()
