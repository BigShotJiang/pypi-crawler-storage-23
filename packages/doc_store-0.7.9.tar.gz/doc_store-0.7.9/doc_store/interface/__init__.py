"""Interface package for document store models and abstract classes."""

from .base import DictModel, Element, ElemType, InputModel
from .block import Block, BlockInput, StandaloneBlockInput
from .content import Content, ContentInput
from .doc import Doc, DocInput, DocPageInput
from .elem import DocElement
from .embedding import (
    EmbeddableElemType,
    Embedding,
    EmbeddingInput,
    EmbeddingModel,
    EmbeddingModelUpdate,
    EmbeddingQuery,
)
from .error import (
    AlreadyExistsError,
    DocExistsError,
    ElementExistsError,
    ElementNotFoundError,
    NotFoundError,
    PageExistsError,
    ReadOnlyError,
    TaskMismatchError,
    UnauthorizedError,
)
from .eval import EvalContent, EvalLayout, EvalLayoutBlock, EvalStatus
from .interface import AioDocStoreInterface, DocStoreInterface
from .io import S3Bucket
from .layout import ContentBlockInput, Layout, LayoutInput, MaskBlock
from .management import (
    KnownName,
    KnownNameInput,
    KnownNameUpdate,
    KnownOption,
    KnownOptionInput,
    User,
    UserInput,
    UserUpdate,
)
from .page import Page, PageInput
from .tagging import (
    AttrInput,
    AttrValueType,
    MetricInput,
    MetricValueType,
    TaggingInput,
)
from .task import Task, TaskCount, TaskInput
from .trigger import DocEvent, Trigger, TriggerAction, TriggerCondition, TriggerInput
from .value import Value, ValueInput

__all__ = [
    # Base types
    "AttrValueType",
    "MetricValueType",
    "InputModel",
    "ElemType",
    "EmbeddableElemType",
    "Element",
    "DictModel",
    "DocElement",
    # Data models
    "Doc",
    "DocInput",
    "DocPageInput",
    "Page",
    "PageInput",
    "Layout",
    "LayoutInput",
    "ContentBlockInput",
    "MaskBlock",
    "Block",
    "BlockInput",
    "StandaloneBlockInput",
    "Content",
    "ContentInput",
    "Value",
    "ValueInput",
    "Task",
    "TaskInput",
    "TaskCount",
    "Trigger",
    "TriggerInput",
    "TriggerCondition",
    "TriggerAction",
    "DocEvent",
    "EvalLayout",
    "EvalContent",
    "EvalLayoutBlock",
    "EvalStatus",
    "S3Bucket",
    "User",
    "KnownName",
    "KnownOption",
    "UserUpdate",
    "UserInput",
    "KnownOptionInput",
    "KnownNameInput",
    "KnownNameUpdate",
    "Embedding",
    "EmbeddingInput",
    "EmbeddingQuery",
    "EmbeddingModel",
    "EmbeddingModelUpdate",
    "AttrInput",
    "MetricInput",
    "TaggingInput",
    # Errors
    "DocExistsError",
    "PageExistsError",
    "ElementExistsError",
    "ElementNotFoundError",
    "NotFoundError",
    "ReadOnlyError",
    "TaskMismatchError",
    "UnauthorizedError",
    "AlreadyExistsError",
    # Interaces
    "DocStoreInterface",
    "AioDocStoreInterface",
]
