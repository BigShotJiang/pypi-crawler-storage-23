from abc import ABC, abstractmethod
from typing import Literal

from .base import DictModel, InputModel
from .error import NotFoundError


class User(DictModel):
    name: str
    aliases: list[str] = []
    restricted: bool = False
    is_admin: bool = False


class UserInput(InputModel):
    name: str
    aliases: list[str] = []
    restricted: bool = False


class UserUpdate(InputModel):
    aliases: list[str] | None = None
    restricted: bool | None = None
    is_admin: bool | None = None


class KnownOption(DictModel):
    name: str
    display_name: str
    description: str


class KnownOptionInput(InputModel):
    display_name: str = ""
    description: str = ""


class KnownName(DictModel):
    "Definition of tag/attribute/metric name."

    name: str
    display_name: str = ""
    description: str = ""
    type: Literal["tag", "attr", "metric", "project_tag", "dataset_tag", "model_tag"] = "tag"
    value_type: Literal["null", "int", "float", "str", "list_str", "bool"] = "null"
    min_value: float = 0
    max_value: float = 0
    options: list[KnownOption] = []
    disabled: bool = False


class KnownNameInput(InputModel):
    name: str
    display_name: str = ""
    description: str = ""
    type: Literal["tag", "attr", "metric", "project_tag", "dataset_tag", "model_tag"] = "tag"
    value_type: Literal["null", "int", "float", "str", "list_str", "bool"] = "null"
    min_value: float = 0
    max_value: float = 0


class KnownNameUpdate(InputModel):
    display_name: str | None = None
    description: str | None = None
    min_value: float | None = None
    max_value: float | None = None
    disabled: bool | None = None


class ManagementABC(ABC):
    """Abstract class for user, known names, and options management operations."""

    @abstractmethod
    def list_users(self) -> list[User]:
        """List all users in the system."""
        raise NotImplementedError()

    @abstractmethod
    def get_user(self, name: str) -> User:
        """Get a user by name."""
        raise NotImplementedError()

    @abstractmethod
    def insert_user(self, user_input: UserInput) -> User:
        """Add a new user to the system."""
        raise NotImplementedError()

    @abstractmethod
    def update_user(self, name: str, user_update: UserUpdate) -> User:
        """Update an existing user in the system."""
        raise NotImplementedError()

    @abstractmethod
    def list_known_names(self) -> list[KnownName]:
        """List all known tag/attribute/metric names in the system."""
        raise NotImplementedError()

    @abstractmethod
    def insert_known_name(self, known_name_input: KnownNameInput) -> KnownName:
        """Add a new known tag/attribute/metric name to the system."""
        raise NotImplementedError()

    @abstractmethod
    def update_known_name(self, name: str, known_name_update: KnownNameUpdate) -> KnownName:
        """Update an existing known tag/attribute/metric name in the system."""
        raise NotImplementedError()

    @abstractmethod
    def add_known_option(self, attr_name: str, option_name: str, option_input: KnownOptionInput) -> None:
        """Add/Update a new known option to a known attribute name."""
        raise NotImplementedError()

    @abstractmethod
    def del_known_option(self, attr_name: str, option_name: str) -> None:
        """Delete a known option from a known attribute name."""
        raise NotImplementedError()

    def try_get_user(self, name: str) -> User | None:
        """Try to get a user by its name, return None if not found."""
        try:
            return self.get_user(name)
        except NotFoundError:
            return None


class AioManagementABC(ABC):
    """Async abstract class for user, known names, and options management operations."""

    @abstractmethod
    async def list_users(self) -> list[User]:
        """List all users in the system (async)."""
        raise NotImplementedError()

    @abstractmethod
    async def get_user(self, name: str) -> User:
        """Get a user by name (async)."""
        raise NotImplementedError()

    @abstractmethod
    async def insert_user(self, user_input: UserInput) -> User:
        """Add a new user to the system (async)."""
        raise NotImplementedError()

    @abstractmethod
    async def update_user(self, name: str, user_update: UserUpdate) -> User:
        """Update an existing user in the system (async)."""
        raise NotImplementedError()

    @abstractmethod
    async def list_known_names(self) -> list[KnownName]:
        """List all known tag/attribute/metric names in the system (async)."""
        raise NotImplementedError()

    @abstractmethod
    async def insert_known_name(self, known_name_input: KnownNameInput) -> KnownName:
        """Add a new known tag/attribute/metric name to the system (async)."""
        raise NotImplementedError()

    @abstractmethod
    async def update_known_name(self, name: str, known_name_update: KnownNameUpdate) -> KnownName:
        """Update an existing known tag/attribute/metric name in the system (async)."""
        raise NotImplementedError()

    @abstractmethod
    async def add_known_option(self, attr_name: str, option_name: str, option_input: KnownOptionInput) -> None:
        """Add/Update a new known option to a known attribute name (async)."""
        raise NotImplementedError()

    @abstractmethod
    async def del_known_option(self, attr_name: str, option_name: str) -> None:
        """Delete a known option from a known attribute name (async)."""
        raise NotImplementedError()

    async def try_get_user(self, name: str) -> User | None:
        """Try to get a user by its name, return None if not found (async)."""
        try:
            return await self.get_user(name)
        except NotFoundError:
            return None
