from abc import ABC, abstractmethod

from .base import Element, ElemType, InputModel

AttrValueType = str | list[str] | int | bool


class AttrInput(InputModel):
    value: AttrValueType


MetricValueType = float | int


class MetricInput(InputModel):
    value: MetricValueType


# allow operating tags/attrs/metrics in one request
class TaggingInput(InputModel):
    elem_id: str | None = None
    tags: list[str] | None = None
    attrs: dict[str, AttrValueType] | None = None
    metrics: dict[str, MetricValueType] | None = None
    del_tags: list[str] | None = None
    del_attrs: list[str] | None = None
    del_metrics: list[str] | None = None


class ElementWithTags(Element):
    """Base class for all elements with tags."""

    tags: list[str] = []
    attrs: dict[str, AttrValueType] = {}
    metrics: dict[str, MetricValueType] = {}

    def add_tag(self, tag: str) -> None:
        """Add tag to an element."""
        self.store.add_tag(self.id, tag)
        if tag not in self.tags:
            self.tags = self.tags + [tag]

    def del_tag(self, tag: str) -> None:
        """Delete tag from an element."""
        self.store.del_tag(self.id, tag)
        if tag in self.tags:
            self.tags = [t for t in self.tags if t != tag]

    def add_attr(self, name: str, attr_input: AttrInput) -> None:
        """Add attribute to an element."""
        self.store.add_attr(self.id, name, attr_input)
        self.attrs = {**self.attrs, name: attr_input.value}

    def add_attrs(self, attrs: dict[str, AttrValueType]) -> None:
        """Add multiple attributes to an element."""
        self.store.add_attrs(self.id, attrs)
        self.attrs = {**self.attrs, **attrs}

    def del_attr(self, name: str) -> None:
        """Delete attribute from an element."""
        self.store.del_attr(self.id, name)
        self.attrs = {k: v for k, v in self.attrs.items() if k != name}

    def add_metric(self, name: str, metric_input: MetricInput) -> None:
        """Add metric to an element."""
        self.store.add_metric(self.id, name, metric_input)
        self.metrics = {**self.metrics, name: metric_input.value}

    def del_metric(self, name: str) -> None:
        """Delete metric from an element."""
        self.store.del_metric(self.id, name)
        self.metrics = {k: v for k, v in self.metrics.items() if k != name}

    def tagging(self, tagging_input: TaggingInput) -> None:
        """Add/Delete tags, attributes, and metrics to/from an element."""
        self.store.tagging(self.id, tagging_input)
        for tag in tagging_input.tags or []:
            if tag not in self.tags:
                self.tags = self.tags + [tag]
        if tagging_input.del_tags:
            self.tags = [t for t in self.tags if t not in tagging_input.del_tags]
        if tagging_input.attrs:
            self.attrs = {**self.attrs, **tagging_input.attrs}
        if tagging_input.del_attrs:
            self.attrs = {k: v for k, v in self.attrs.items() if k not in tagging_input.del_attrs}
        if tagging_input.metrics:
            self.metrics = {**self.metrics, **tagging_input.metrics}
        if tagging_input.del_metrics:
            self.metrics = {k: v for k, v in self.metrics.items() if k not in tagging_input.del_metrics}

    # ========== Async Methods ==========

    async def aio_add_tag(self, tag: str) -> None:
        """Add tag to an element (async)."""
        await self.aio_store.add_tag(self.id, tag)
        if tag not in self.tags:
            self.tags = self.tags + [tag]

    async def aio_del_tag(self, tag: str) -> None:
        """Delete tag from an element (async)."""
        await self.aio_store.del_tag(self.id, tag)
        if tag in self.tags:
            self.tags = [t for t in self.tags if t != tag]

    async def aio_add_attr(self, name: str, attr_input: AttrInput) -> None:
        """Add attribute to an element (async)."""
        await self.aio_store.add_attr(self.id, name, attr_input)
        self.attrs = {**self.attrs, name: attr_input.value}

    async def aio_add_attrs(self, attrs: dict[str, AttrValueType]) -> None:
        """Add multiple attributes to an element (async)."""
        await self.aio_store.add_attrs(self.id, attrs)
        self.attrs = {**self.attrs, **attrs}

    async def aio_del_attr(self, name: str) -> None:
        """Delete attribute from an element (async)."""
        await self.aio_store.del_attr(self.id, name)
        self.attrs = {k: v for k, v in self.attrs.items() if k != name}

    async def aio_add_metric(self, name: str, metric_input: MetricInput) -> None:
        """Add metric to an element (async)."""
        await self.aio_store.add_metric(self.id, name, metric_input)
        self.metrics = {**self.metrics, name: metric_input.value}

    async def aio_del_metric(self, name: str) -> None:
        """Delete metric from an element (async)."""
        await self.aio_store.del_metric(self.id, name)
        self.metrics = {k: v for k, v in self.metrics.items() if k != name}

    async def aio_tagging(self, tagging_input: TaggingInput) -> None:
        """Add/Delete tags, attributes, and metrics to/from an element (async)."""
        await self.aio_store.tagging(self.id, tagging_input)
        for tag in tagging_input.tags or []:
            if tag not in self.tags:
                self.tags = self.tags + [tag]
        if tagging_input.del_tags:
            self.tags = [t for t in self.tags if t not in tagging_input.del_tags]
        if tagging_input.attrs:
            self.attrs = {**self.attrs, **tagging_input.attrs}
        if tagging_input.del_attrs:
            self.attrs = {k: v for k, v in self.attrs.items() if k not in tagging_input.del_attrs}
        if tagging_input.metrics:
            self.metrics = {**self.metrics, **tagging_input.metrics}
        if tagging_input.del_metrics:
            self.metrics = {k: v for k, v in self.metrics.items() if k not in tagging_input.del_metrics}


class TaggingABC(ABC):
    """Abstract class for tagging, attribute, and metric operations."""

    @abstractmethod
    def add_tag(self, elem_id: str, tag: str) -> None:
        """Add tag to an element."""
        raise NotImplementedError()

    @abstractmethod
    def del_tag(self, elem_id: str, tag: str) -> None:
        """Delete tag from an element."""
        raise NotImplementedError()

    @abstractmethod
    def batch_add_tag(self, elem_type: ElemType, tag: str, elem_ids: list[str]) -> None:
        """Batch add tag to multiple elements."""
        raise NotImplementedError()

    @abstractmethod
    def batch_del_tag(self, elem_type: ElemType, tag: str, elem_ids: list[str]) -> None:
        """Batch delete tag from multiple elements."""
        raise NotImplementedError()

    @abstractmethod
    def add_attr(self, elem_id: str, name: str, attr_input: AttrInput) -> None:
        """Add an attribute to an element."""
        raise NotImplementedError()

    @abstractmethod
    def add_attrs(self, elem_id: str, attrs: dict[str, AttrValueType]) -> None:
        """Add multiple attributes to an element."""
        raise NotImplementedError()

    @abstractmethod
    def del_attr(self, elem_id: str, name: str) -> None:
        """Delete an attribute from an element."""
        raise NotImplementedError()

    @abstractmethod
    def add_metric(self, elem_id: str, name: str, metric_input: MetricInput) -> None:
        """Add a metric to an element."""
        raise NotImplementedError()

    @abstractmethod
    def del_metric(self, elem_id: str, name: str) -> None:
        """Delete a metric from an element."""
        raise NotImplementedError()

    @abstractmethod
    def tagging(self, elem_id: str, tagging_input: TaggingInput) -> None:
        """Add/Delete tags, attributes, and metrics to/from an element."""
        raise NotImplementedError()

    @abstractmethod
    def batch_tagging(self, elem_type: ElemType, inputs: list[TaggingInput]) -> None:
        """Batch add/delete tags, attributes, and metrics to/from multiple elements."""
        raise NotImplementedError()


class AioTaggingABC(ABC):
    """Async abstract class for tagging, attribute, and metric operations."""

    @abstractmethod
    async def add_tag(self, elem_id: str, tag: str) -> None:
        """Add tag to an element (async)."""
        raise NotImplementedError()

    @abstractmethod
    async def del_tag(self, elem_id: str, tag: str) -> None:
        """Delete tag from an element (async)."""
        raise NotImplementedError()

    @abstractmethod
    async def batch_add_tag(self, elem_type: ElemType, tag: str, elem_ids: list[str]) -> None:
        """Batch add tag to multiple elements (async)."""
        raise NotImplementedError()

    @abstractmethod
    async def batch_del_tag(self, elem_type: ElemType, tag: str, elem_ids: list[str]) -> None:
        """Batch delete tag from multiple elements (async)."""
        raise NotImplementedError()

    @abstractmethod
    async def add_attr(self, elem_id: str, name: str, attr_input: AttrInput) -> None:
        """Add an attribute to an element (async)."""
        raise NotImplementedError()

    @abstractmethod
    async def add_attrs(self, elem_id: str, attrs: dict[str, AttrValueType]) -> None:
        """Add multiple attributes to an element (async)."""
        raise NotImplementedError()

    @abstractmethod
    async def del_attr(self, elem_id: str, name: str) -> None:
        """Delete an attribute from an element (async)."""
        raise NotImplementedError()

    @abstractmethod
    async def add_metric(self, elem_id: str, name: str, metric_input: MetricInput) -> None:
        """Add a metric to an element (async)."""
        raise NotImplementedError()

    @abstractmethod
    async def del_metric(self, elem_id: str, name: str) -> None:
        """Delete a metric from an element (async)."""
        raise NotImplementedError()

    @abstractmethod
    async def tagging(self, elem_id: str, tagging_input: TaggingInput) -> None:
        """Add/Delete tags, attributes, and metrics to/from an element (async)."""
        raise NotImplementedError()

    @abstractmethod
    async def batch_tagging(self, elem_type: ElemType, inputs: list[TaggingInput]) -> None:
        """Batch add/delete tags, attributes, and metrics to/from multiple elements (async)."""
        raise NotImplementedError()
