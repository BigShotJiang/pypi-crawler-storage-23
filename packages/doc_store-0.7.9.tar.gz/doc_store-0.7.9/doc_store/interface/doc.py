from abc import ABC, abstractmethod
from typing import AsyncIterable, Iterable

from ..pdf_doc import PDFDocument
from .base import InputModel
from .elem import DocElement
from .error import ElementNotFoundError
from .io import OrigInfo, PDFInfo
from .page import Page, PageInput


class DocInput(InputModel):
    pdf_path: str
    pdf_filename: str | None = None
    pdf_info: PDFInfo | None = None
    orig_path: str | None = None
    orig_filename: str | None = None
    orig_info: OrigInfo | None = None
    tags: list[str] | None = None


class DocPageInput(InputModel):
    image_path: str
    image_dpi: int | None = None
    tags: list[str] | None = None


class Doc(DocElement):
    """Doc in the store."""

    pdf_path: str
    pdf_filename: str | None = None
    pdf_filesize: int
    pdf_hash: str
    num_pages: int
    page_width: float
    page_height: float
    metadata: dict = {}

    # Original file info (if exists)
    orig_path: str | None = None
    orig_filesize: int | None = None
    orig_filename: str | None = None
    orig_hash: str | None = None

    @property
    def pdf_bytes(self) -> bytes:
        """Get the PDF bytes of the doc."""
        return self.store.read_file(self.pdf_path)

    @property
    def pdf(self) -> PDFDocument:
        """Get the PDF document associated with the doc."""
        return PDFDocument(self.pdf_bytes)

    @property
    def pages(self) -> list[Page]:
        """Get all pages of the doc."""
        pages = list(self.find_pages())
        pages.sort(key=lambda p: p.page_idx or 0)
        return pages

    def find_pages(
        self,
        query: dict | None = None,
        skip: int | None = None,
        limit: int | None = None,
    ) -> Iterable[Page]:
        """List pages of the doc by filters."""
        return self.store.find_pages(
            query=query,
            doc_id=self.id,
            skip=skip,
            limit=limit,
        )

    def insert_page(self, page_idx: int, page_input: DocPageInput) -> Page:
        """Insert a page for the doc, return the inserted page."""
        return self.store.insert_page(
            PageInput(
                image_path=page_input.image_path,
                image_dpi=page_input.image_dpi,
                doc_id=self.id,
                page_idx=page_idx,
                tags=page_input.tags,
            )
        )

    # ========== Async Methods ==========

    async def aio_pdf_bytes(self) -> bytes:
        """Get the PDF bytes of the doc (async)."""
        return await self.aio_store.read_file(self.pdf_path)

    async def aio_find_pages(
        self,
        query: dict | None = None,
        skip: int | None = None,
        limit: int | None = None,
    ) -> AsyncIterable[Page]:
        """List pages of the doc by filters (async)."""
        async for page in self.aio_store.find_pages(
            query=query,
            doc_id=self.id,
            skip=skip,
            limit=limit,
        ):
            yield page

    async def aio_insert_page(self, page_idx: int, page_input: DocPageInput) -> Page:
        """Insert a page for the doc, return the inserted page (async)."""
        return await self.aio_store.insert_page(
            PageInput(
                image_path=page_input.image_path,
                image_dpi=page_input.image_dpi,
                doc_id=self.id,
                page_idx=page_idx,
                tags=page_input.tags,
            )
        )


class DocABC(ABC):
    """Abstract class for document operations."""

    @abstractmethod
    def get_doc(self, doc_id: str) -> Doc:
        """Get a doc by its ID."""
        raise NotImplementedError()

    @abstractmethod
    def get_doc_by_pdf_path(self, pdf_path: str) -> Doc:
        """Get a doc by its PDF path."""
        raise NotImplementedError()

    @abstractmethod
    def get_doc_by_pdf_hash(self, pdf_hash: str) -> Doc:
        """Get a doc by its PDF sha256sum hex-string."""
        raise NotImplementedError()

    @abstractmethod
    def insert_doc(self, doc_input: DocInput, skip_ext_check=False) -> Doc:
        """Insert a new doc into the database."""
        raise NotImplementedError()

    def try_get_doc(self, doc_id: str) -> Doc | None:
        """Try to get a doc by its ID, return None if not found."""
        try:
            return self.get_doc(doc_id)
        except ElementNotFoundError:
            return None

    def try_get_doc_by_pdf_path(self, pdf_path: str) -> Doc | None:
        """Try to get a doc by its PDF path, return None if not found."""
        try:
            return self.get_doc_by_pdf_path(pdf_path)
        except ElementNotFoundError:
            return None

    def try_get_doc_by_pdf_hash(self, pdf_hash: str) -> Doc | None:
        """Try to get a doc by its PDF sha256sum hex-string, return None if not found."""
        try:
            return self.get_doc_by_pdf_hash(pdf_hash)
        except ElementNotFoundError:
            return None


class AioDocABC(ABC):
    """Async abstract class for document operations."""

    @abstractmethod
    async def get_doc(self, doc_id: str) -> Doc:
        """Get a doc by its ID (async)."""
        raise NotImplementedError()

    @abstractmethod
    async def get_doc_by_pdf_path(self, pdf_path: str) -> Doc:
        """Get a doc by its PDF path (async)."""
        raise NotImplementedError()

    @abstractmethod
    async def get_doc_by_pdf_hash(self, pdf_hash: str) -> Doc:
        """Get a doc by its PDF sha256sum hex-string (async)."""
        raise NotImplementedError()

    @abstractmethod
    async def insert_doc(self, doc_input: DocInput, skip_ext_check=False) -> Doc:
        """Insert a new doc into the database (async)."""
        raise NotImplementedError()

    async def try_get_doc(self, doc_id: str) -> Doc | None:
        """Try to get a doc by its ID, return None if not found (async)."""
        try:
            return await self.get_doc(doc_id)
        except ElementNotFoundError:
            return None

    async def try_get_doc_by_pdf_path(self, pdf_path: str) -> Doc | None:
        """Try to get a doc by its PDF path, return None if not found (async)."""
        try:
            return await self.get_doc_by_pdf_path(pdf_path)
        except ElementNotFoundError:
            return None

    async def try_get_doc_by_pdf_hash(self, pdf_hash: str) -> Doc | None:
        """Try to get a doc by its PDF sha256sum hex-string, return None if not found (async)."""
        try:
            return await self.get_doc_by_pdf_hash(pdf_hash)
        except ElementNotFoundError:
            return None
