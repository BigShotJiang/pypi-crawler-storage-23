import asyncio
import hashlib
import io
import os
import time
from abc import ABC, abstractmethod
from contextlib import asynccontextmanager
from typing import Literal

import boto3
import httpx
from botocore.client import Config
from PIL import Image, ImageDraw

from ..pdf_doc import PDFDocument
from ..s3 import head_s3_object, put_s3_object, read_s3_object_bytes, split_s3_path
from ..utils import timed_property
from .base import DictModel, InputModel

Image.MAX_IMAGE_PIXELS = None


_UPLOAD_DIRS = {
    "doc": "s3://doc-store/docs-by-hash/",
    "page": "s3://doc-store/pages-by-hash/",
    "block": "s3://doc-store/blocks-by-hash/",
}

# bucket -> url
_ACCESSIBLE_URL: dict[str, str] = {}


class S3Bucket(DictModel):
    name: str
    endpoint_urls: list[str]
    addressing_style: str = "path"  # Enum(path, virtual)
    aws_access_key_id: str
    aws_secret_access_key: str


class ImageInfo(InputModel):
    image_filesize: int
    image_hash: str
    image_width: int
    image_height: int


class PDFInfo(InputModel):
    pdf_filesize: int
    pdf_hash: str
    num_pages: int
    page_width: float
    page_height: float
    metadata: dict


class OrigInfo(InputModel):
    orig_filesize: int
    orig_hash: str


def _read_local_file(file_path: str) -> bytes:
    if not os.path.isfile(file_path):
        raise ValueError(f"Local file {file_path} does not exist.")
    with open(file_path, "rb") as f:
        return f.read()


async def _aio_read_local_file(file_path: str) -> bytes:
    import aiofiles
    import aiofiles.os

    if not (await aiofiles.os.path.isfile(file_path)):
        raise ValueError(f"Local file {file_path} does not exist.")
    async with aiofiles.open(file_path, "rb") as file:
        return await file.read()


def _try_read_pdf(file_bytes: bytes) -> None:
    if PDFDocument(file_bytes).num_pages <= 0:
        raise ValueError("PDF document has no pages.")


def _open_image(file_bytes: bytes) -> Image.Image:
    image = Image.open(io.BytesIO(file_bytes))
    image = image.convert("RGB")  # Some broken image may raise.
    return image


def _open_image_with_fallback(file_bytes: bytes) -> Image.Image:
    image = Image.open(io.BytesIO(file_bytes))
    try:
        return image.convert("RGB")
    except Exception:
        # image is broken, return fake image
        fake_size = [*image.size]
        fake_image = Image.new("RGB", fake_size, (255, 255, 255))
        draw = ImageDraw.Draw(fake_image)
        draw.line((0, 0, *fake_size), fill=(255, 0, 0), width=10)
        draw.line((0, fake_size[1], fake_size[0], 0), fill=(255, 0, 0), width=10)
        return fake_image


def _try_read_image(file_bytes: bytes) -> None:
    image = Image.open(io.BytesIO(file_bytes))
    image.convert("RGB")  # Some broken image may raise.


def _sha256sum_hex(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _is_url_accessible(url: str) -> bool:
    try:
        # TODO: this may fail.
        _ = httpx.get(url, timeout=20.0)
        return True
    except httpx.RequestError:
        return False


def _get_accessible_url(bucket: S3Bucket) -> str:
    if bucket.name in _ACCESSIBLE_URL:
        return _ACCESSIBLE_URL[bucket.name]
    for url in bucket.endpoint_urls:
        if _is_url_accessible(url):
            _ACCESSIBLE_URL[bucket.name] = url
            return url
    raise ValueError(f"No accessible endpoint URL found for bucket {bucket.name}.")


class IO_ABC(ABC):
    """Base abstract class for io operations."""

    @timed_property(ttl=60)
    def s3_buckets(self) -> dict[str, S3Bucket]:
        return {bkt.name: bkt for bkt in self.list_s3_buckets()}

    @abstractmethod
    def list_s3_buckets(self) -> list[S3Bucket]:
        """List all S3 buckets in the system."""
        raise NotImplementedError()

    def stat_file_size(self, file_path: str, allow_local=True) -> int:
        if file_path.startswith("s3://"):
            s3_client = self.get_s3_client(file_path)
            obj = head_s3_object(file_path, client=s3_client)
            if obj is not None:
                return obj["ContentLength"]
        elif allow_local and os.path.isfile(file_path):
            return os.path.getsize(file_path)
        raise ValueError(f"File {file_path} does not exist or is not accessible.")

    def read_file(self, file_path: str, allow_local=True) -> bytes:
        if file_path.startswith("s3://"):
            s3_client = self.get_s3_client(file_path)
            return read_s3_object_bytes(file_path, client=s3_client)
        elif allow_local and os.path.isfile(file_path):
            with open(file_path, "rb") as f:
                return f.read()
        raise ValueError(f"File {file_path} does not exist or is not accessible.")

    def upload_local_file(self, file_type: Literal["doc", "page", "block"], file_path: str) -> str:
        file_ext = file_path.split(".")[-1].lower()
        if file_type == "doc" and file_ext != "pdf":
            raise ValueError("file_path must end with .pdf for doc type.")
        if file_type in ("page", "block") and file_ext not in ("jpg", "jpeg", "png", "webp"):
            raise ValueError("file_path must end with .jpg, .jpeg, .png, or .webp for page/block type.")
        file_bytes = _read_local_file(file_path)
        if file_type == "doc":
            _try_read_pdf(file_bytes)
        elif file_type in ("page", "block"):
            _try_read_image(file_bytes)
        file_hash = _sha256sum_hex(file_bytes)
        upload_file_path = f"{_UPLOAD_DIRS[file_type]}{file_hash}.{file_ext}"
        s3_client = self.get_s3_client(upload_file_path)
        if not head_s3_object(upload_file_path, client=s3_client):
            put_s3_object(upload_file_path, file_bytes, client=s3_client)
        return upload_file_path

    def read_image(self, file_path: str) -> Image.Image:
        image_content = self.read_file(file_path)
        return _open_image_with_fallback(image_content)

    def get_s3_client(self, path: str):
        bucket, _ = split_s3_path(path)
        config: S3Bucket | None = self.s3_buckets.get(bucket)
        if not config:
            raise ValueError(f"Bucket {bucket} not found in S3 config.")
        endpoint_url = _get_accessible_url(config)
        return boto3.client(
            "s3",
            aws_access_key_id=config.aws_access_key_id,
            aws_secret_access_key=config.aws_secret_access_key,
            endpoint_url=endpoint_url,
            config=Config(
                s3={"addressing_style": config.addressing_style},
                retries={"max_attempts": 8},
            ),
        )

    def _read_image_info(self, image_path: str) -> ImageInfo:
        """Insert a new page into the database."""
        if not image_path:
            raise ValueError("image_path must be non-empty.")
        if not image_path.startswith("s3://"):
            raise ValueError("image_path must start with 's3://'.")
        if not image_path.lower().endswith((".jpg", ".jpeg", ".png", ".webp")):
            raise ValueError("image_path must end with .jpg, .jpeg, .png or .webp")

        image_content = self.read_file(image_path, allow_local=False)
        image = _open_image(image_content)
        image_hash = _sha256sum_hex(image_content)

        return ImageInfo(
            image_filesize=len(image_content),
            image_hash=image_hash,
            image_width=image.width,
            image_height=image.height,
        )

    def _read_pdf_info(self, pdf_path: str, skip_ext_check: bool) -> PDFInfo:
        if not pdf_path:
            raise ValueError("pdf_path must be non-empty.")
        if not pdf_path.startswith("s3://"):
            raise ValueError("pdf_path must start with 's3://'.")
        if not skip_ext_check and not pdf_path.lower().endswith(".pdf"):
            raise ValueError("pdf_path must end with .pdf.")

        pdf_content = self.read_file(pdf_path, allow_local=False)
        pdf_document = PDFDocument(pdf_content)
        if pdf_document.num_pages <= 0:
            raise ValueError(f"PDF document at {pdf_path} has no pages.")

        return PDFInfo(
            pdf_filesize=len(pdf_content),
            pdf_hash=_sha256sum_hex(pdf_content),
            num_pages=pdf_document.num_pages,
            page_width=pdf_document.page_width,
            page_height=pdf_document.page_height,
            metadata=pdf_document.metadata,
        )

    def _read_orig_info(self, orig_path: str) -> OrigInfo:
        if not orig_path:
            raise ValueError("orig_path must not be empty if provided.")
        if not orig_path.startswith("s3://"):
            raise ValueError("orig_path must start with 's3://'.")
        if not orig_path.lower().endswith((".docx", ".doc", ".pptx", ".ppt")):
            raise ValueError("orig_path must end with .docx, .doc, .pptx, or .ppt.")
        orig_content = self.read_file(orig_path, allow_local=False)
        orig_filesize = len(orig_content)
        orig_hash = _sha256sum_hex(orig_content)
        return OrigInfo(orig_filesize=orig_filesize, orig_hash=orig_hash)


class AioIO_ABC(ABC):
    """Async base abstract class for io operations."""

    @abstractmethod
    async def list_s3_buckets(self) -> list[S3Bucket]:
        """List all S3 buckets in the system (async)."""
        raise NotImplementedError()

    async def s3_buckets(self) -> dict[str, S3Bucket]:
        now = time.time()
        if hasattr(self, "_s3_buckets") and hasattr(self, "_s3_buckets_exp"):
            buckets: dict[str, S3Bucket] = getattr(self, "_s3_buckets")
            expire_time: int = getattr(self, "_s3_buckets_exp")
            if now < expire_time:
                return buckets
        bucket_list = await self.list_s3_buckets()
        buckets = {bkt.name: bkt for bkt in bucket_list}
        setattr(self, "_s3_buckets", buckets)
        setattr(self, "_s3_buckets_exp", now + 60)
        return buckets

    @asynccontextmanager
    async def get_s3_client(self, path: str):
        import aioboto3

        bucket, _ = split_s3_path(path)
        s3_buckets = await self.s3_buckets()
        config: S3Bucket | None = s3_buckets.get(bucket)
        if not config:
            raise ValueError(f"Bucket {bucket} not found in S3 config.")
        endpoint_url = _get_accessible_url(config)  # TODO

        session = aioboto3.Session()
        async with session.client(  # type: ignore
            "s3",
            aws_access_key_id=config.aws_access_key_id,
            aws_secret_access_key=config.aws_secret_access_key,
            endpoint_url=endpoint_url,
            config=Config(
                s3={"addressing_style": config.addressing_style},
                retries={"max_attempts": 8},
            ),
        ) as client:
            yield client

    async def stat_file_size(self, file_path: str, allow_local: bool = True) -> int:
        """Get the size of a file (async)."""
        import aiofiles.os

        from ..aio_s3 import head_s3_object

        if file_path.startswith("s3://"):
            async with self.get_s3_client(file_path) as s3_client:
                obj = await head_s3_object(file_path, client=s3_client)
            if obj is not None:
                return obj["ContentLength"]
        elif allow_local:
            if await aiofiles.os.path.isfile(file_path):
                return await aiofiles.os.path.getsize(file_path)
        raise ValueError(f"File {file_path} does not exist or is not accessible.")

    async def read_file(self, file_path: str, allow_local: bool = True) -> bytes:
        """Read a file and return its bytes (async)."""
        from ..aio_s3 import read_s3_object_bytes

        if file_path.startswith("s3://"):
            async with self.get_s3_client(file_path) as s3_client:
                return await read_s3_object_bytes(file_path, client=s3_client)
        elif allow_local:
            return await _aio_read_local_file(file_path)
        raise ValueError(f"File {file_path} does not exist or is not accessible.")

    async def upload_local_file(self, file_type: Literal["doc", "page", "block"], file_path: str) -> str:
        """Upload a local file to S3 (async)."""
        from ..aio_s3 import head_s3_object, put_s3_object

        file_ext = file_path.split(".")[-1].lower()
        if file_type == "doc" and file_ext != "pdf":
            raise ValueError("file_path must end with .pdf for doc type.")
        if file_type in ("page", "block") and file_ext not in ("jpg", "jpeg", "png", "webp"):
            raise ValueError("file_path must end with .jpg, .jpeg, .png, or .webp for page/block type.")
        file_bytes = await _aio_read_local_file(file_path)
        if file_type == "doc":
            await asyncio.to_thread(_try_read_pdf, file_bytes)
        elif file_type in ("page", "block"):
            await asyncio.to_thread(_try_read_image, file_bytes)
        file_hash = await asyncio.to_thread(_sha256sum_hex, file_bytes)
        upload_file_path = f"{_UPLOAD_DIRS[file_type]}{file_hash}.{file_ext}"
        async with self.get_s3_client(upload_file_path) as s3_client:
            if not (await head_s3_object(upload_file_path, client=s3_client)):
                await put_s3_object(upload_file_path, file_bytes, client=s3_client)
        return upload_file_path

    async def read_image(self, file_path: str) -> Image.Image:
        """Read an image file and return PIL Image (async)."""
        image_content = await self.read_file(file_path)
        image = await asyncio.to_thread(_open_image_with_fallback, image_content)
        return image

    async def _read_image_info(self, image_path: str) -> ImageInfo:
        """Read image info from S3 path (async)."""
        if not image_path:
            raise ValueError("image_path must be non-empty.")
        if not image_path.startswith("s3://"):
            raise ValueError("image_path must start with 's3://'.")
        if not image_path.lower().endswith((".jpg", ".jpeg", ".png", ".webp")):
            raise ValueError("image_path must end with .jpg, .jpeg, .png or .webp")

        image_content = await self.read_file(image_path, allow_local=False)
        image = await asyncio.to_thread(_open_image, image_content)
        image_hash = await asyncio.to_thread(_sha256sum_hex, image_content)

        return ImageInfo(
            image_filesize=len(image_content),
            image_hash=image_hash,
            image_width=image.width,
            image_height=image.height,
        )

    async def _read_pdf_info(self, pdf_path: str, skip_ext_check: bool) -> PDFInfo:
        """Read PDF info from S3 path (async)."""
        if not pdf_path:
            raise ValueError("pdf_path must be non-empty.")
        if not pdf_path.startswith("s3://"):
            raise ValueError("pdf_path must start with 's3://'.")
        if not skip_ext_check and not pdf_path.lower().endswith(".pdf"):
            raise ValueError("pdf_path must end with .pdf.")

        pdf_content = await self.read_file(pdf_path, allow_local=False)
        pdf_document = await asyncio.to_thread(PDFDocument, pdf_content)
        if pdf_document.num_pages <= 0:
            raise ValueError(f"PDF document at {pdf_path} has no pages.")
        pdf_hash = await asyncio.to_thread(_sha256sum_hex, pdf_content)

        return PDFInfo(
            pdf_filesize=len(pdf_content),
            pdf_hash=pdf_hash,
            num_pages=pdf_document.num_pages,
            page_width=pdf_document.page_width,
            page_height=pdf_document.page_height,
            metadata=pdf_document.metadata,
        )

    async def _read_orig_info(self, orig_path: str) -> OrigInfo:
        """Read original file info from S3 path (async)."""
        if not orig_path:
            raise ValueError("orig_path must not be empty if provided.")
        if not orig_path.startswith("s3://"):
            raise ValueError("orig_path must start with 's3://'.")
        if not orig_path.lower().endswith((".docx", ".doc", ".pptx", ".ppt")):
            raise ValueError("orig_path must end with .docx, .doc, .pptx, or .ppt.")
        orig_content = await self.read_file(orig_path, allow_local=False)
        orig_filesize = len(orig_content)
        orig_hash = await asyncio.to_thread(_sha256sum_hex, orig_content)
        return OrigInfo(orig_filesize=orig_filesize, orig_hash=orig_hash)
